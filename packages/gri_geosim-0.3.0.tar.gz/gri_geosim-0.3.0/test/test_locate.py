"""Tests for locate module.

Tests verify observation to position estimate conversion using geolocation
algorithms.
"""

from __future__ import annotations

import numpy as np
from gri_nsepoch import Time
from gri_pos import Pos
from scipy.spatial.transform import Rotation

from gri_geosim.locate import _build_aoa_inputs, _build_fdoa_inputs, _build_tdoa_inputs
from gri_geosim.observations import AoaObservation, FdoaObservation, TdoaObservation

_TIME = Time(s=0.0)


def _make_aoa_obs(
    u: float = 0.1,
    v: float = 0.2,
    collector: Pos | None = None,
) -> AoaObservation:
    """Create an AOA observation."""
    if collector is None:
        collector = Pos.XYZ(1e6, 2e6, 3e6)
    return AoaObservation(
        time=_TIME,
        u=u,
        v=v,
        covariance=np.array([[1e-6, 0], [0, 1e-6]]),
        collector=collector,
        collector_rotation=Rotation.identity(),
        sensor_id="aoa",
    )


def _make_tdoa_obs(
    value: float = 1e-6,
    collector1: Pos | None = None,
    collector2: Pos | None = None,
) -> TdoaObservation:
    """Create a TDOA observation."""
    if collector1 is None:
        collector1 = Pos.XYZ(1e6, 2e6, 3e6)
    if collector2 is None:
        collector2 = Pos.XYZ(1.1e6, 2.1e6, 3.1e6)
    return TdoaObservation(
        time=_TIME,
        value=value,
        std_dev=1e-9,
        collector1=collector1,
        collector2=collector2,
        sensor_id="tdoa",
    )


def _make_fdoa_obs(
    value: float = 0.5,
    collector1: Pos | None = None,
    collector2: Pos | None = None,
) -> FdoaObservation:
    """Create an FDOA observation."""
    if collector1 is None:
        collector1 = Pos.XYZ(1e6, 2e6, 3e6)
    if collector2 is None:
        collector2 = Pos.XYZ(1.1e6, 2.1e6, 3.1e6)
    return FdoaObservation(
        time=_TIME,
        value=value,
        std_dev=0.1,
        collector1=collector1,
        collector2=collector2,
        collector1_vel=np.array([100.0, 200.0, 50.0]),
        collector2_vel=np.array([150.0, 180.0, 60.0]),
        frequency_hz=1e9,
        sensor_id="fdoa",
    )


# _build_tdoa_inputs


def test_build_tdoa_inputs_empty() -> None:
    """Verify empty TDOA list returns None tuple."""
    c1, c2, m, v = _build_tdoa_inputs([])

    assert c1 is None
    assert c2 is None
    assert m is None
    assert v is None


def test_build_tdoa_inputs_single() -> None:
    """Verify single TDOA observation builds correct arrays."""
    obs = _make_tdoa_obs(value=1.5e-6)
    c1, c2, m, v = _build_tdoa_inputs([obs])

    assert c1 is not None
    assert c2 is not None
    assert m is not None
    assert v is not None
    assert c1.shape == (1, 3)
    assert c2.shape == (1, 3)
    assert m.shape == (1,)
    assert v.shape == (1,)
    assert m[0] == 1.5e-6


def test_build_tdoa_inputs_multiple() -> None:
    """Verify multiple TDOA observations build stacked arrays."""
    obs1 = _make_tdoa_obs(value=1e-6)
    obs2 = _make_tdoa_obs(value=2e-6)
    c1, _c2, m, _v = _build_tdoa_inputs([obs1, obs2])

    assert c1 is not None
    assert m is not None
    assert c1.shape == (2, 3)
    assert m.shape == (2,)
    assert m[0] == 1e-6
    assert m[1] == 2e-6


# _build_aoa_inputs


def test_build_aoa_inputs_empty() -> None:
    """Verify empty AOA list returns None tuple."""
    xyz, rot, m, cov = _build_aoa_inputs([])

    assert xyz is None
    assert rot is None
    assert m is None
    assert cov is None


def test_build_aoa_inputs_single() -> None:
    """Verify single AOA observation builds correct arrays."""
    obs = _make_aoa_obs(u=0.3, v=0.4)
    xyz, _rot, m, cov = _build_aoa_inputs([obs])

    assert xyz is not None
    assert m is not None
    assert cov is not None
    assert xyz.shape == (1, 3)
    assert m.shape == (1, 2)
    assert cov.shape == (1, 2, 2)
    assert m[0, 0] == 0.3
    assert m[0, 1] == 0.4


def test_build_aoa_inputs_multiple() -> None:
    """Verify multiple AOA observations build stacked arrays."""
    obs1 = _make_aoa_obs(u=0.1, v=0.2)
    obs2 = _make_aoa_obs(u=0.3, v=0.4)
    xyz, _rot, m, cov = _build_aoa_inputs([obs1, obs2])

    assert xyz is not None
    assert m is not None
    assert cov is not None
    assert xyz.shape == (2, 3)
    assert m.shape == (2, 2)
    assert cov.shape == (2, 2, 2)


# _build_fdoa_inputs


def test_build_fdoa_inputs_empty() -> None:
    """Verify empty FDOA list returns None tuple with default frequency."""
    c1, c2, _v1, _v2, _m, _v, freq = _build_fdoa_inputs([])

    assert c1 is None
    assert c2 is None
    assert freq == 1.0e9  # Default


def test_build_fdoa_inputs_single() -> None:
    """Verify single FDOA observation builds correct arrays."""
    obs = _make_fdoa_obs(value=1.5)
    c1, c2, v1, v2, m, v, freq = _build_fdoa_inputs([obs])

    assert c1 is not None
    assert c2 is not None
    assert v1 is not None
    assert v2 is not None
    assert m is not None
    assert v is not None
    assert c1.shape == (1, 3)
    assert c2.shape == (1, 3)
    assert v1.shape == (1, 3)
    assert v2.shape == (1, 3)
    assert m.shape == (1,)
    assert v.shape == (1,)
    assert m[0] == 1.5
    assert freq == 1e9


def test_build_fdoa_inputs_multiple() -> None:
    """Verify multiple FDOA observations build stacked arrays."""
    obs1 = _make_fdoa_obs(value=1.0)
    obs2 = _make_fdoa_obs(value=2.0)
    c1, _c2, _v1, _v2, m, _v, _freq = _build_fdoa_inputs([obs1, obs2])

    assert c1 is not None
    assert m is not None
    assert c1.shape == (2, 3)
    assert m.shape == (2,)
    assert m[0] == 1.0
    assert m[1] == 2.0
