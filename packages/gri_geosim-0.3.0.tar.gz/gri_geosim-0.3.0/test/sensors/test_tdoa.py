"""Tests for TdoaSensor.

Tests verify TDOA sensor observation generation with paired platforms.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Time
from gri_pos import Pos

from gri_geosim import Emitter, Platform
from gri_geosim.observations import TdoaObservation
from gri_geosim.sensors import TdoaSensor

# Test positions
_PLATFORM1_POS = Pos.LLA(38.0, -77.0, 100.0)
_PLATFORM2_POS = Pos.LLA(39.0, -76.0, 100.0)
_TARGET_MIDPOINT = Pos.LLA(38.5, -76.5, 0.0)  # Roughly equidistant
_TARGET_NEAR_P1 = Pos.LLA(38.1, -76.9, 0.0)  # Closer to platform 1
_TARGET_NEAR_P2 = Pos.LLA(38.9, -76.1, 0.0)  # Closer to platform 2

_TIME = Time(s=0.0)


# Sensor initialization


@pytest.mark.parametrize(
    "tdoa_std_s",
    [1e-9, 1e-8, 1e-7],
    ids=["1ns", "10ns", "100ns"],
)
def test_initialization_with_noise(tdoa_std_s: float) -> None:
    """Verify sensor initializes with various noise levels."""
    sensor = TdoaSensor("test", tdoa_std_s=tdoa_std_s)

    assert sensor.tdoa_std_s == tdoa_std_s


def test_auto_generated_id() -> None:
    """Verify sensor generates unique ID if not provided."""
    sensor1 = TdoaSensor()
    sensor2 = TdoaSensor()

    assert sensor1.sensor_id.startswith("TDOA-")
    assert sensor2.sensor_id.startswith("TDOA-")
    assert sensor1.sensor_id != sensor2.sensor_id


# Paired platform


def test_requires_paired_platform() -> None:
    """Verify sensor requires paired platform for observation."""
    platform = Platform(_PLATFORM1_POS)
    sensor = TdoaSensor("tdoa")
    platform.add_sensor(sensor)

    emitter = Emitter(_TARGET_MIDPOINT)

    assert not sensor.can_observe(emitter, _TIME)

    obs = sensor.observe(emitter, _TIME)
    assert obs is None


def test_set_paired_platform() -> None:
    """Verify setting paired platform enables observation."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = TdoaSensor("tdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_TARGET_MIDPOINT)

    assert sensor.can_observe(emitter, _TIME)


def test_paired_platform_cannot_be_same() -> None:
    """Verify paired platform cannot be the same as sensor's platform."""
    platform = Platform(_PLATFORM1_POS)
    sensor = TdoaSensor("tdoa")
    platform.add_sensor(sensor)

    with pytest.raises(ValueError, match="same as sensor"):
        sensor.set_paired_platform(platform)


# Observation generation


def test_generates_tdoa_observation() -> None:
    """Verify sensor generates TDOA observation."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = TdoaSensor("tdoa", rng_seed=42)
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_TARGET_MIDPOINT)

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert isinstance(obs, TdoaObservation)
    assert obs.obs_type == "TDOA"


def test_observation_without_noise_repeatable() -> None:
    """Verify noise-free observations are repeatable."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = TdoaSensor("tdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_TARGET_MIDPOINT)

    obs1 = sensor.observe(emitter, _TIME, add_noise=False)
    obs2 = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs1 is not None
    assert obs2 is not None
    assert obs1.value == obs2.value


def test_observation_with_noise_varies() -> None:
    """Verify noisy observations vary between calls."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = TdoaSensor("tdoa", tdoa_std_s=1e-7, rng_seed=42)
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_TARGET_MIDPOINT)

    obs1 = sensor.observe(emitter, _TIME, add_noise=True)
    obs2 = sensor.observe(emitter, _TIME, add_noise=True)

    assert obs1 is not None
    assert obs2 is not None
    assert obs1.value != obs2.value


# TDOA value correctness


def test_tdoa_near_zero_for_equidistant() -> None:
    """Verify TDOA is near zero for equidistant target."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = TdoaSensor("tdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_TARGET_MIDPOINT)

    obs = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs is not None
    # Should be small (< 1 microsecond for roughly equidistant)
    assert abs(obs.value) < 1e-5


@pytest.mark.parametrize(
    ("target_pos", "expected_sign"),
    [
        (_TARGET_NEAR_P1, -1),  # Closer to P1 -> negative TDOA
        (_TARGET_NEAR_P2, +1),  # Closer to P2 -> positive TDOA
    ],
    ids=["closer_to_p1", "closer_to_p2"],
)
def test_tdoa_sign_correct(target_pos: Pos, expected_sign: int) -> None:
    """Verify TDOA sign indicates which platform is closer."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = TdoaSensor("tdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(target_pos)

    obs = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs is not None
    assert np.sign(obs.value) == expected_sign


def test_tdoa_magnitude_reasonable() -> None:
    """Verify TDOA magnitude is physically reasonable."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = TdoaSensor("tdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_TARGET_NEAR_P1)

    obs = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs is not None
    # For ~100 km baseline, max TDOA is ~300 microseconds
    assert abs(obs.value) < 1e-3


# Observation metadata


def test_observation_contains_collector_positions() -> None:
    """Verify observation contains both collector positions."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = TdoaSensor("tdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_TARGET_MIDPOINT)

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert np.allclose(obs.collector1.xyz, _PLATFORM1_POS.xyz, rtol=1e-6)
    assert np.allclose(obs.collector2.xyz, _PLATFORM2_POS.xyz, rtol=1e-6)


def test_observation_sensor_id() -> None:
    """Verify observation contains sensor ID."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = TdoaSensor("my_tdoa_sensor")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_TARGET_MIDPOINT, name="target1")

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert obs.sensor_id == "my_tdoa_sensor"
    assert obs.emitter_id == "target1"


def test_observation_variance() -> None:
    """Verify observation variance matches sensor configuration."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    tdoa_std = 1e-8
    sensor = TdoaSensor("tdoa", tdoa_std_s=tdoa_std)
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_TARGET_MIDPOINT)

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert np.isclose(obs.variance, tdoa_std**2)


# Platform requirement


def test_requires_platform() -> None:
    """Verify sensor requires platform attachment."""
    sensor = TdoaSensor("tdoa")
    emitter = Emitter(_TARGET_MIDPOINT)

    assert not sensor.can_observe(emitter, _TIME)


def test_repr() -> None:
    """Verify string representation."""
    sensor = TdoaSensor("test_sensor", tdoa_std_s=1e-9)

    assert "TdoaSensor" in repr(sensor)
    assert "test_sensor" in repr(sensor)
