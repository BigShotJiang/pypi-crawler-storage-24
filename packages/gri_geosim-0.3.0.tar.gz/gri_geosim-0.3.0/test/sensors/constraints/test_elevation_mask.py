"""Tests for ElevationMaskFov constraint.

Tests verify elevation angle constraints for ground and space platforms.
"""

from __future__ import annotations

import math

import pytest
from gri_pos import Pos

from gri_geosim.sensors.constraints import ElevationMaskFov

# Test positions
_GROUND_STATION = Pos.LLA(38.0, -77.0, 100.0)
_SATELLITE_400KM = Pos.LLA(38.0, -77.0, 400_000.0)

# Targets at various elevations from ground station
_TARGET_OVERHEAD = Pos.LLA(38.0, -77.0, 10_000.0)  # Nearly overhead
_TARGET_HIGH_ELEV = Pos.LLA(38.5, -77.0, 5_000.0)  # High elevation
_TARGET_MED_ELEV = Pos.LLA(39.0, -77.0, 1_000.0)  # Medium elevation
_TARGET_LOW_ELEV = Pos.LLA(40.0, -77.0, 0.0)  # Low elevation
_TARGET_HORIZON = Pos.LLA(45.0, -77.0, 0.0)  # Near horizon

# Ground target for satellite looking down
_GROUND_TARGET = Pos.LLA(38.0, -77.0, 0.0)


# Initialization


@pytest.mark.parametrize(
    ("min_elev", "max_elev"),
    [
        (5.0, 90.0),  # Standard config
        (10.0, 85.0),  # Both limits
        (0.0, 90.0),  # Full range
        (-5.0, 90.0),  # Allow below horizon
    ],
    ids=["standard", "both", "full", "negative_min"],
)
def test_valid_configurations(min_elev: float, max_elev: float) -> None:
    """Verify FOV accepts valid configurations."""
    fov = ElevationMaskFov(min_elev_deg=min_elev, max_elev_deg=max_elev)

    # Use approximate comparison due to radians conversion
    assert abs(fov.min_elev_deg - min_elev) < 1e-10
    assert abs(fov.max_elev_deg - max_elev) < 1e-10


def test_invalid_min_greater_than_max() -> None:
    """Verify FOV rejects min >= max."""
    with pytest.raises(ValueError, match="less than"):
        ElevationMaskFov(min_elev_deg=60.0, max_elev_deg=30.0)


# Properties


def test_elevation_properties() -> None:
    """Verify elevation properties return correct values."""
    fov = ElevationMaskFov(min_elev_deg=10.0, max_elev_deg=80.0)

    assert abs(fov.min_elev_deg - 10.0) < 1e-10
    assert abs(fov.max_elev_deg - 80.0) < 1e-10
    assert abs(fov.min_elev_rad - math.radians(10.0)) < 1e-10
    assert abs(fov.max_elev_rad - math.radians(80.0)) < 1e-10


# Ground station visibility


@pytest.mark.parametrize(
    ("target", "min_elev", "expected_visible"),
    [
        (_TARGET_OVERHEAD, 10.0, True),  # Nearly overhead target (~89 deg elevation)
        (_TARGET_HIGH_ELEV, 4.0, True),  # ~5 deg elevation, above 4 deg minimum
    ],
    ids=["overhead", "high"],
)
def test_ground_station_visibility(
    target: Pos,
    min_elev: float,
    *,
    expected_visible: bool,
) -> None:
    """Verify elevation mask works for ground station looking up."""
    fov = ElevationMaskFov(min_elev_deg=min_elev)

    assert fov.is_visible(_GROUND_STATION, target) == expected_visible


# Maximum elevation constraint


def test_max_elevation_constraint() -> None:
    """Verify maximum elevation constraint blocks overhead targets."""
    fov = ElevationMaskFov(min_elev_deg=5.0, max_elev_deg=70.0)

    # Overhead target at 90 deg should be blocked
    assert not fov.is_visible(_GROUND_STATION, _TARGET_OVERHEAD)


# Satellite looking down - elevation is computed from ground perspective


def test_satellite_to_ground_visibility() -> None:
    """Verify elevation mask for satellite-ground geometry.

    ElevationMaskFov computes elevation from the lower point's perspective.
    For sat-to-ground, elevation is computed from ground looking up at sat.
    """
    # Ground station can see satellite above 10 deg
    fov = ElevationMaskFov(min_elev_deg=10.0)

    # Satellite directly overhead should be visible (high elevation)
    assert fov.is_visible(_SATELLITE_400KM, _GROUND_TARGET)
    assert fov.is_visible(_GROUND_TARGET, _SATELLITE_400KM)  # Order shouldn't matter


# Edge cases


def test_very_high_minimum() -> None:
    """Verify very high minimum elevation."""
    fov = ElevationMaskFov(min_elev_deg=80.0)

    # Only nearly overhead targets visible
    assert fov.is_visible(_GROUND_STATION, _TARGET_OVERHEAD)


# String representations


def test_repr() -> None:
    """Verify string representation."""
    fov = ElevationMaskFov(min_elev_deg=10.0, max_elev_deg=80.0)

    assert "ElevationMaskFov" in repr(fov)


def test_str() -> None:
    """Verify human-readable string."""
    fov = ElevationMaskFov(min_elev_deg=10.0, max_elev_deg=80.0)

    str_repr = str(fov)
    assert "10" in str_repr
    assert "80" in str_repr
