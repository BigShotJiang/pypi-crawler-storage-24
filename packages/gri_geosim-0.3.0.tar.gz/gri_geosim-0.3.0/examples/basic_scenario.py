#!/usr/bin/env python3
"""Basic scenario example: multi-platform sensors observing ground emitters.

This example demonstrates:
- Ground-based emitters (stationary)
- An aircraft emitter (moving via waypoints)
- Multiple sensor platform types: ground stations, aircraft, and LEO satellite
- Running a single-instant simulation
- Accessing observations
- AOA sensor orientation: ENU for ground/aircraft, nadir for space-based
- Direction cosines (u, v) for space-based sensors vs azimuth/elevation for ground
"""

from __future__ import annotations

import math

from gri_nsepoch import Delta, Time
from gri_pos import Pos

from gri_geosim import Emitter, Platform, Scenario, filter_aoa
from gri_geosim.sensors import AoaSensor
from gri_geosim.trajectories import (
    Sgp4Trajectory,
    WaypointTrajectory,
)

# =============================================================================
# Ground-based emitters (targets to geolocate)
# =============================================================================

emitter1 = Emitter(
    Pos.LLA(38.2, -76.8, 0.0),  # Ground level
    frequency_hz=1.2e9,  # L-band
    name="EMITTER_GND_1",
)

emitter2 = Emitter(
    Pos.LLA(38.5, -77.2, 50.0),  # Slight elevation
    frequency_hz=2.4e9,  # S-band
    name="EMITTER_GND_2",
)

# Moving aircraft emitter
observation_time = Time.from_str("2024-01-15T12:00:00Z")
aircraft_trajectory = WaypointTrajectory(
    [
        (observation_time - Delta(s=1800), Pos.LLA(38.0, -77.5, 10000.0)),
        (observation_time, Pos.LLA(38.3, -77.0, 10000.0)),
        (observation_time + Delta(s=1800), Pos.LLA(38.6, -76.5, 10000.0)),
    ],
)
emitter_aircraft = Emitter(
    aircraft_trajectory,
    frequency_hz=9.4e9,  # X-band radar
    name="EMITTER_AIRCRAFT",
)

# =============================================================================
# Sensor platforms: ground, aircraft, and LEO satellite
# =============================================================================

# --- Ground stations (ENU orientation - measures azimuth/elevation) ---
ground1 = Platform(
    Pos.LLA(37.5, -76.0, 100.0),
    name="GND_SENSOR_1",
)
ground1.add_sensor(
    AoaSensor(
        "aoa_gnd1",
        azimuth_std_rad=0.001,
        elevation_std_rad=0.002,
        orientation="enu",  # Explicit ENU for ground station
    ),
)

ground2 = Platform(
    Pos.LLA(39.0, -78.0, 200.0),
    name="GND_SENSOR_2",
)
ground2.add_sensor(
    AoaSensor(
        "aoa_gnd2",
        azimuth_std_rad=0.001,
        elevation_std_rad=0.002,
        orientation="enu",  # Explicit ENU for ground station
    ),
)

# --- Airborne sensor (circling over the area, uses ENU orientation) ---
aircraft_sensor = Platform(
    WaypointTrajectory(
        [
            (observation_time - Delta(s=1800), Pos.LLA(38.8, -76.5, 8000.0)),
            (observation_time, Pos.LLA(38.2, -77.5, 8000.0)),
            (observation_time + Delta(s=1800), Pos.LLA(37.6, -76.5, 8000.0)),
        ],
        interpolation="cubic",
    ),
    name="AIRCRAFT_SENSOR",
)
aircraft_sensor.add_sensor(
    AoaSensor(
        "aoa_aircraft",
        azimuth_std_rad=0.0005,
        elevation_std_rad=0.001,
        orientation="enu",  # Aircraft uses horizon-relative frame
    ),
)

# --- LEO satellite sensor (nadir-pointing, measures direction cosines u,v) ---
# ISS TLE (International Space Station) - note: this TLE epoch should be
# close to observation_time for realistic results
iss_tle_line1 = "1 25544U 98067A   24015.50000000  .00016717  00000-0  10270-3 0  9993"
iss_tle_line2 = "2 25544  51.6400  10.5000 0001234  90.0000 270.0000 15.49500000000000"

leo_satellite = Platform(
    Sgp4Trajectory(iss_tle_line1, iss_tle_line2),
    name="LEO_SENSOR_SAT",
)
leo_satellite.add_sensor(
    AoaSensor(
        "aoa_leo",
        azimuth_std_rad=0.0001,
        elevation_std_rad=0.0002,
        orientation="nadir",  # Space-based sensor points toward Earth
    ),
)

# =============================================================================
# Create and run scenario
# =============================================================================

scenario = Scenario.for_instant(
    platforms=[ground1, ground2, aircraft_sensor, leo_satellite],
    emitters=[emitter1, emitter2, emitter_aircraft],
)

result = scenario.simulate_at(observation_time)

# =============================================================================
# Display results
# =============================================================================

print("Scenario Configuration:")
print(f"  Observation time: {observation_time}")
print(f"  Emitters: {len(scenario.emitters)}")
for em in scenario.emitters:
    print(f"    - {em}")
print(f"  Sensor platforms: {len(scenario.platforms)}")
for plat in scenario.platforms:
    print(f"    - {plat}")

print(f"\nGenerated {len(result)} observations:")
for obs in filter_aoa(result):
    emitter = obs.emitter_id or "unknown"
    # Space-based sensors (nadir orientation) show direction cosines (u, v)
    # Ground/aircraft sensors (ENU orientation) show azimuth/elevation
    if obs.sensor_id.startswith("aoa_leo"):
        # Direction cosines for space-based sensor
        print(
            f"  {obs.sensor_id} -> {emitter}: u={obs.u:+7.4f}, v={obs.v:+7.4f} "
            f"(az={math.degrees(obs.azimuth):+7.2f} deg, el={math.degrees(obs.elevation):+6.2f} deg)",
        )
    else:
        # Azimuth/elevation for ground and aircraft sensors
        az_deg = math.degrees(obs.azimuth)
        el_deg = math.degrees(obs.elevation)
        print(
            f"  {obs.sensor_id} -> {emitter}: az={az_deg:+7.2f} deg, el={el_deg:+6.2f} deg",
        )
