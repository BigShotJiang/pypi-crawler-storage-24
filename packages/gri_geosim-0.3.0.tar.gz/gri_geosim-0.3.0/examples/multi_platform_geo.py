#!/usr/bin/env python3
"""Multi-platform geolocation example using AOA, TDOA, and FDOA observations.

This example demonstrates a geolocation scenario combining multiple observation
types from diverse platforms:

Platforms:
- 2 LEO satellites in circular orbits (fast-moving, good FDOA geometry)
- 1 HEO satellite (Molniya-like: 500 km perigee, ~36,000 km apogee)
- 1 aircraft flying a circular holding pattern

Sensors:
- AOA sensors on all 4 platforms
- TDOA between spacecraft pairs: LEO1-LEO2, LEO1-HEO, LEO2-HEO
- FDOA between spacecraft pairs and aircraft-spacecraft pairs

The simulation runs at 3 time points (30 seconds apart), generating observations
and performing geolocation at each time using the locate() function.

Key techniques demonstrated:
- Using Pos.translate_aer() to position satellites at desired azimuth/elevation
- Using gri_utils.orbit.from_circular() and from_perigee_apogee() for orbit creation
- Combining AOA, TDOA, and FDOA for hybrid geolocation
- Using locate() with platform velocities for FDOA processing
- AOA sensor orientations: ENU for aircraft, nadir for space-based platforms
- Direction cosines (u, v) for space-based sensors vs azimuth/elevation for aircraft
"""

from __future__ import annotations

import math

import numpy as np
from gri_nsepoch import Delta, Time
from gri_pos import Pos
from gri_utils.constants import ER_M
from gri_utils.distance import slant_range
from gri_utils.orbit import from_circular, from_perigee_apogee

from gri_geosim import Emitter, Platform, Scenario, filter_aoa, filter_fdoa, filter_tdoa
from gri_geosim.locate import locate
from gri_geosim.sensors import AoaSensor, FdoaSensor, TdoaSensor
from gri_geosim.trajectories import (
    KeplerianTrajectory,
    WaypointTrajectory,
)

# =============================================================================
# Configuration
# =============================================================================

# Time configuration
START_TIME = Time.from_str("2024-06-15T12:00:00Z")
TIME_STEP = Delta(s=30)  # 30 seconds between observations
NUM_OBSERVATIONS = 3  # 3 time points over 1 minute

# Emitter configuration
EMITTER_LAT = 38.0  # degrees
EMITTER_LON = -77.0  # degrees
EMITTER_ALT = 0.0  # meters (ground level)
EMITTER_FREQ_HZ = 1.5e9  # 1.5 GHz (L-band)

# Aircraft configuration
AIRCRAFT_ALT_M = 10000.0  # 10 km altitude
AIRCRAFT_RADIUS_KM = 50.0  # Circular pattern radius
AIRCRAFT_PERIOD_MIN = 30.0  # Time for one orbit

# LEO configuration (2 satellites in different orbital planes)
LEO_ALTITUDE_KM = 500.0  # ~500 km altitude

# HEO configuration (Molniya-like elliptical orbit)
HEO_APOGEE_ALTITUDE_KM = 35786.0  # Geostationary altitude at apogee
HEO_PERIGEE_ALTITUDE_KM = 500.0  # Low perigee for true HEO

# Sensor noise parameters
AOA_AZ_STD_RAD = 0.001  # ~0.057 deg
AOA_EL_STD_RAD = 0.001  # ~0.057 deg
TDOA_STD_S = 1e-9  # 1 nanosecond
FDOA_STD_HZ = 0.1  # 0.1 Hz

# =============================================================================
# Create emitter
# =============================================================================

emitter = Emitter(
    Pos.LLA(EMITTER_LAT, EMITTER_LON, EMITTER_ALT),
    frequency_hz=EMITTER_FREQ_HZ,
    name="TARGET",
)

print("=" * 70)
print("MULTI-PLATFORM GEOLOCATION EXAMPLE")
print("=" * 70)
print("\nEmitter (True Position):")
print(f"  Name: {emitter.name}")
print(f"  Position: {EMITTER_LAT:.4f}N, {EMITTER_LON:.4f}E, {EMITTER_ALT:.0f}m")
print(f"  Frequency: {EMITTER_FREQ_HZ / 1e9:.3f} GHz")

# =============================================================================
# Create aircraft with circular holding pattern
# =============================================================================


def create_circular_waypoints(  # noqa: PLR0913
    center_lat: float,
    center_lon: float,
    altitude_m: float,
    radius_km: float,
    period_min: float,
    start_time: Time,
    duration_min: float,
    num_waypoints: int = 20,
) -> list[tuple[Time, Pos | np.ndarray]]:
    """Generate waypoints for a circular holding pattern.

    Args:
        center_lat: Center latitude in degrees.
        center_lon: Center longitude in degrees.
        altitude_m: Altitude in meters.
        radius_km: Radius of circular pattern in km.
        period_min: Time for one complete orbit in minutes.
        start_time: Start time of the pattern.
        duration_min: Total duration in minutes.
        num_waypoints: Number of waypoints to generate.

    Returns:
        List of (Time, Pos) tuples for the waypoint trajectory.
    """
    waypoints = []
    radius_deg = radius_km / 111.0  # Approximate km to degrees

    for i in range(num_waypoints):
        t = start_time + Delta(s=i * duration_min * 60 / (num_waypoints - 1))
        # Angular position around the circle based on elapsed time
        elapsed_min = i * duration_min / (num_waypoints - 1)
        angle = 2 * math.pi * elapsed_min / period_min
        lat = center_lat + radius_deg * math.cos(angle)
        lon = center_lon + radius_deg * math.sin(angle) / math.cos(
            math.radians(center_lat),
        )
        waypoints.append((t, Pos.LLA(lat, lon, altitude_m)))

    return waypoints


aircraft_waypoints = create_circular_waypoints(
    center_lat=EMITTER_LAT,
    center_lon=EMITTER_LON,
    altitude_m=AIRCRAFT_ALT_M,
    radius_km=AIRCRAFT_RADIUS_KM,
    period_min=AIRCRAFT_PERIOD_MIN,
    start_time=START_TIME - Delta(s=60),  # Start slightly before
    duration_min=15.0,  # Cover the observation window with margin
    num_waypoints=20,
)

aircraft = Platform(
    WaypointTrajectory(aircraft_waypoints, interpolation="cubic"),
    name="AIRCRAFT",
)

# =============================================================================
# Create LEO satellites using translate_aer and from_circular
# =============================================================================

# For good geolocation geometry, we want LEO satellites with good elevation angles
# from the emitter (30-60 degrees is ideal). We use:
#   1. Pos.translate_aer() to define where we want the satellite at observation time
#   2. gri_utils.orbit.from_circular() to create orbital elements through that point
#
# This approach guarantees the satellite will be at the desired position at START_TIME.

# Get emitter position for AER calculations
emitter_pos = Pos.LLA(EMITTER_LAT, EMITTER_LON, EMITTER_ALT)

# LEO 1: Northeast of emitter at 50 deg elevation
leo1_elevation_deg = 50.0
leo1_azimuth_deg = 45.0  # Northeast
leo1_slant_range_m = slant_range(
    emitter_pos.xyz,
    azimuth_deg=leo1_azimuth_deg,
    elevation_deg=leo1_elevation_deg,
    target_altitude_m=LEO_ALTITUDE_KM * 1000,
)
if leo1_slant_range_m is None:
    msg = "LEO1 slant range calculation failed - elevation angle too low"
    raise ValueError(msg)
leo1_target_pos = emitter_pos.translate_aer(
    (leo1_azimuth_deg, leo1_elevation_deg, leo1_slant_range_m),
)

# Create circular orbit through this point at START_TIME
leo1_elements = from_circular(leo1_target_pos.xyz, START_TIME.secs)
leo1 = Platform(
    KeplerianTrajectory(
        semi_major_axis_m=leo1_elements.semi_major_axis_m,
        eccentricity=leo1_elements.eccentricity,
        inclination_rad=leo1_elements.inclination_rad,
        raan_rad=leo1_elements.raan_rad,
        arg_periapsis_rad=leo1_elements.arg_periapsis_rad,
        mean_anomaly_rad=leo1_elements.mean_anomaly_rad,
        epoch=START_TIME,
    ),
    name="LEO1",
)

# LEO 2: Southeast of emitter at 45 deg elevation (different geometry for TDOA/FDOA)
leo2_elevation_deg = 45.0
leo2_azimuth_deg = 135.0  # Southeast
leo2_slant_range_m = slant_range(
    emitter_pos.xyz,
    azimuth_deg=leo2_azimuth_deg,
    elevation_deg=leo2_elevation_deg,
    target_altitude_m=LEO_ALTITUDE_KM * 1000,
)
if leo2_slant_range_m is None:
    msg = "LEO2 slant range calculation failed - elevation angle too low"
    raise ValueError(msg)
leo2_target_pos = emitter_pos.translate_aer(
    (leo2_azimuth_deg, leo2_elevation_deg, leo2_slant_range_m),
)

# Create circular orbit through this point at START_TIME
leo2_elements = from_circular(leo2_target_pos.xyz, START_TIME.secs)
leo2 = Platform(
    KeplerianTrajectory(
        semi_major_axis_m=leo2_elements.semi_major_axis_m,
        eccentricity=leo2_elements.eccentricity,
        inclination_rad=leo2_elements.inclination_rad,
        raan_rad=leo2_elements.raan_rad,
        arg_periapsis_rad=leo2_elements.arg_periapsis_rad,
        mean_anomaly_rad=leo2_elements.mean_anomaly_rad,
        epoch=START_TIME,
    ),
    name="LEO2",
)

# =============================================================================
# Create HEO satellite (Molniya-like elliptical orbit)
# =============================================================================

# HEO positioned at apogee over the emitter at observation time
# Using from_perigee_apogee to create a true elliptical orbit
heo_elevation_deg = 70.0  # High elevation for stable geometry
heo_azimuth_deg = 270.0  # West of emitter
heo_slant_range_m = slant_range(
    emitter_pos.xyz,
    azimuth_deg=heo_azimuth_deg,
    elevation_deg=heo_elevation_deg,
    target_altitude_m=HEO_APOGEE_ALTITUDE_KM * 1000,
)
if heo_slant_range_m is None:
    msg = "HEO slant range calculation failed - elevation angle invalid"
    raise ValueError(msg)
heo_apogee_pos = emitter_pos.translate_aer(
    (heo_azimuth_deg, heo_elevation_deg, heo_slant_range_m),
)

# Create orbit elements - specify apogee position and perigee radius
# Satellite will be at this apogee position at START_TIME
# (auto-detected as apogee since position radius > perigee radius)
heo_perigee_radius_m = ER_M + HEO_PERIGEE_ALTITUDE_KM * 1000
heo_elements = from_perigee_apogee(
    heo_apogee_pos.xyz,
    heo_perigee_radius_m,
    START_TIME.secs,
)
heo = Platform(
    KeplerianTrajectory(
        semi_major_axis_m=heo_elements.semi_major_axis_m,
        eccentricity=heo_elements.eccentricity,
        inclination_rad=heo_elements.inclination_rad,
        raan_rad=heo_elements.raan_rad,
        arg_periapsis_rad=heo_elements.arg_periapsis_rad,
        mean_anomaly_rad=heo_elements.mean_anomaly_rad,
        epoch=Time(s=heo_elements.epoch_unix_s),
    ),
    name="HEO",
)

# =============================================================================
# Add AOA sensors to all platforms
# =============================================================================

# Aircraft uses ENU orientation (measures azimuth/elevation from local horizon)
aircraft.add_sensor(
    AoaSensor(
        "aoa_aircraft",
        azimuth_std_rad=AOA_AZ_STD_RAD,
        elevation_std_rad=AOA_EL_STD_RAD,
        orientation="enu",  # Aircraft uses horizon-relative frame
    ),
)

# Space-based sensors use nadir orientation (measures direction cosines u, v)
leo1.add_sensor(
    AoaSensor(
        "aoa_leo1",
        azimuth_std_rad=AOA_AZ_STD_RAD,
        elevation_std_rad=AOA_EL_STD_RAD,
        orientation="nadir",  # Space-based sensor points toward Earth
    ),
)
leo2.add_sensor(
    AoaSensor(
        "aoa_leo2",
        azimuth_std_rad=AOA_AZ_STD_RAD,
        elevation_std_rad=AOA_EL_STD_RAD,
        orientation="nadir",  # Space-based sensor points toward Earth
    ),
)
heo.add_sensor(
    AoaSensor(
        "aoa_heo",
        azimuth_std_rad=AOA_AZ_STD_RAD,
        elevation_std_rad=AOA_EL_STD_RAD,
        orientation="nadir",  # Space-based sensor points toward Earth
    ),
)

# =============================================================================
# Add TDOA sensors (spacecraft pairs only)
# =============================================================================

# TDOA: LEO1-LEO2 (sensor on LEO1, paired with LEO2)
tdoa_leo1_leo2 = TdoaSensor("tdoa_leo1_leo2", tdoa_std_s=TDOA_STD_S)
leo1.add_sensor(tdoa_leo1_leo2)
tdoa_leo1_leo2.set_paired_platform(leo2)

# TDOA: LEO1-HEO (sensor on LEO1, paired with HEO)
tdoa_leo1_heo = TdoaSensor("tdoa_leo1_heo", tdoa_std_s=TDOA_STD_S)
leo1.add_sensor(tdoa_leo1_heo)
tdoa_leo1_heo.set_paired_platform(heo)

# TDOA: LEO2-HEO (sensor on LEO2, paired with HEO)
tdoa_leo2_heo = TdoaSensor("tdoa_leo2_heo", tdoa_std_s=TDOA_STD_S)
leo2.add_sensor(tdoa_leo2_heo)
tdoa_leo2_heo.set_paired_platform(heo)

# =============================================================================
# Add FDOA sensors
# =============================================================================

# FDOA between spacecraft pairs
# LEO1-HEO
fdoa_leo1_heo = FdoaSensor("fdoa_leo1_heo", fdoa_std_hz=FDOA_STD_HZ)
leo1.add_sensor(fdoa_leo1_heo)
fdoa_leo1_heo.set_paired_platform(heo)

# LEO2-HEO
fdoa_leo2_heo = FdoaSensor("fdoa_leo2_heo", fdoa_std_hz=FDOA_STD_HZ)
leo2.add_sensor(fdoa_leo2_heo)
fdoa_leo2_heo.set_paired_platform(heo)

# FDOA between aircraft and each spacecraft
# Aircraft-LEO1
fdoa_aircraft_leo1 = FdoaSensor("fdoa_aircraft_leo1", fdoa_std_hz=FDOA_STD_HZ)
aircraft.add_sensor(fdoa_aircraft_leo1)
fdoa_aircraft_leo1.set_paired_platform(leo1)

# Aircraft-LEO2
fdoa_aircraft_leo2 = FdoaSensor("fdoa_aircraft_leo2", fdoa_std_hz=FDOA_STD_HZ)
aircraft.add_sensor(fdoa_aircraft_leo2)
fdoa_aircraft_leo2.set_paired_platform(leo2)

# Aircraft-HEO
fdoa_aircraft_heo = FdoaSensor("fdoa_aircraft_heo", fdoa_std_hz=FDOA_STD_HZ)
aircraft.add_sensor(fdoa_aircraft_heo)
fdoa_aircraft_heo.set_paired_platform(heo)

# =============================================================================
# Create scenario
# =============================================================================

platforms = [aircraft, leo1, leo2, heo]
scenario = Scenario.for_instant(
    platforms=platforms,
    emitters=[emitter],
)

print(f"\nPlatforms ({len(platforms)}):")
for plat in platforms:
    sensor_summary = ", ".join(s.sensor_id for s in plat.sensors)
    print(f"  {plat.name}: {len(plat.sensors)} sensors ({sensor_summary})")

# =============================================================================
# Run simulation at multiple time points
# =============================================================================

observation_times = [
    START_TIME + Delta(s=i * TIME_STEP.secs) for i in range(NUM_OBSERVATIONS)
]

print(
    f"\nObservation Times ({NUM_OBSERVATIONS} points, {TIME_STEP.secs:.0f} sec apart):",
)
for i, t in enumerate(observation_times):
    print(f"  T{i + 1}: {t.iso}")

print("=" * 70)

# Store results for each time point
all_results = []

for obs_idx, obs_time in enumerate(observation_times):
    print(f"\n{'=' * 70}")
    print(f"TIME POINT {obs_idx + 1}: {obs_time.iso}")
    print("=" * 70)

    # Get platform positions and velocities at this time
    print("\nCollector Positions:")

    for plat in platforms:
        pos = plat.position_at(obs_time)
        vel = plat.velocity_at(obs_time)
        lla = pos.lla
        vel_mag = np.linalg.norm(vel)
        print(
            f"  {plat.name:12s}: {lla.lat_deg:+8.4f}N, {lla.lon_deg:+9.4f}E, "
            f"{lla.alt_m / 1000:10.1f} km | v={vel_mag:8.1f} m/s",
        )

    # Run simulation
    result = scenario.simulate_at(obs_time, add_noise=True)

    # Display observations by type
    print(f"\nObservations ({len(result)} total):")

    for obs in filter_aoa(result):
        # Access az/el for aircraft (ENU) sensor to trigger memoization
        # so __str__ will display az/el instead of u/v
        if obs.sensor_id == "aoa_aircraft":
            _ = obs.azimuth  # Trigger az/el computation for __str__
        print(f"    {obs.sensor_id:20s}: {obs}")

    for obs in filter_tdoa(result):
        print(f"    {obs.sensor_id:20s}: {obs}")

    for obs in filter_fdoa(result):
        print(f"    {obs.sensor_id:20s}: {obs}")

    # Perform geolocation
    print("\n  Geolocation Result:")
    try:
        ell = locate(
            result,
            initial_guess=Pos.LLA(EMITTER_LAT, EMITTER_LON, EMITTER_ALT),
        )
        est_lla = ell.lla
        true_pos = emitter.position_at(obs_time)
        true_lla = true_pos.lla

        # Compute error
        lat_err_m = (est_lla.lat_deg - true_lla.lat_deg) * 111000
        lon_err_m = (
            (est_lla.lon_deg - true_lla.lon_deg)
            * 111000
            * math.cos(math.radians(true_lla.lat_deg))
        )
        alt_err_m = est_lla.alt_m - true_lla.alt_m
        horiz_err_m = math.sqrt(lat_err_m**2 + lon_err_m**2)

        print(
            f"    Estimated: {est_lla.lat_deg:+10.6f}N, {est_lla.lon_deg:+11.6f}E, "
            f"{est_lla.alt_m:+10.1f} m",
        )
        print(
            f"    True:      {true_lla.lat_deg:+10.6f}N, {true_lla.lon_deg:+11.6f}E, "
            f"{true_lla.alt_m:+10.1f} m",
        )
        print(
            f"    Error:     N/S={lat_err_m:+8.1f}m, E/W={lon_err_m:+8.1f}m, "
            f"Alt={alt_err_m:+8.1f}m",
        )
        print(f"    Horizontal Error: {horiz_err_m:.1f} m")

        all_results.append(
            {
                "time": obs_time,
                "observations": result,
                "ell": ell,
                "horiz_err_m": horiz_err_m,
                "alt_err_m": alt_err_m,
            },
        )

    except Exception as e:
        print(f"    Geolocation failed: {e}")
        all_results.append(
            {
                "time": obs_time,
                "observations": result,
                "ell": None,
                "error": str(e),
            },
        )

# =============================================================================
# Summary
# =============================================================================

print(f"\n{'=' * 70}")
print("SUMMARY")
print("=" * 70)

print(
    f"\nEmitter True Position: {EMITTER_LAT:.4f}N, {EMITTER_LON:.4f}E, {EMITTER_ALT:.0f}m",
)
print("\nGeolocation Results:")

successful_results = [r for r in all_results if r.get("ell") is not None]
if successful_results:
    horiz_errors = [r["horiz_err_m"] for r in successful_results]
    alt_errors = [abs(r["alt_err_m"]) for r in successful_results]
    print(f"  Successful: {len(successful_results)}/{len(all_results)}")
    print(
        f"  Horizontal Error: mean={np.mean(horiz_errors):.1f}m, "
        f"max={np.max(horiz_errors):.1f}m",
    )
    print(
        f"  Altitude Error:   mean={np.mean(alt_errors):.1f}m, "
        f"max={np.max(alt_errors):.1f}m",
    )
else:
    print("  No successful geolocations")

print("=" * 70)
