#!/usr/bin/env python3
"""TDOA scenario example: satellite platforms measuring time differences.

This example demonstrates:
- Creating TDOA sensors with paired satellite platforms
- Generating TDOA observations from LEO/HEO satellites
- Single-instant simulation for TDOA-based geolocation of ground emitter
"""

from __future__ import annotations

from gri_nsepoch import Time
from gri_pos import Pos

from gri_geosim import Emitter, Platform, Scenario
from gri_geosim.sensors import TdoaSensor

# Create satellite platforms (LEO ~400-2000 km, HEO varies)
# Altitudes in meters - mix of LEO and HEO orbits
sat1 = Platform(
    Pos.LLA(38.0, -77.0, 550_000.0),
    name="LEO1",
)  # 550 km LEO
sat2 = Platform(
    Pos.LLA(40.0, -75.0, 800_000.0),
    name="LEO2",
)  # 800 km LEO
sat3 = Platform(
    Pos.LLA(36.0, -78.0, 1200_000.0),
    name="LEO3",
)  # 1200 km LEO
sat4 = Platform(
    Pos.LLA(39.0, -74.0, 35786_000.0),
    name="HEO1",
)  # GEO-like HEO

# Create TDOA sensors - each needs a paired platform
# TDOA = (range_to_this - range_to_paired) / c
tdoa_12 = TdoaSensor("tdoa_12", tdoa_std_s=1e-9)  # 1 ns accuracy
sat1.add_sensor(tdoa_12)
tdoa_12.set_paired_platform(sat2)

tdoa_13 = TdoaSensor("tdoa_13", tdoa_std_s=1e-9)
sat1.add_sensor(tdoa_13)
tdoa_13.set_paired_platform(sat3)

tdoa_14 = TdoaSensor("tdoa_14", tdoa_std_s=1e-9)
sat1.add_sensor(tdoa_14)
tdoa_14.set_paired_platform(sat4)

# Create ground-based emitter (altitude 10-100m above ground)
target = Emitter(
    Pos.LLA(38.2, -76.5, 50.0),  # 50m above ground
    name="GROUND_EMITTER",
    frequency_hz=1.0e9,
)

# Create scenario
scenario = Scenario.for_instant(
    platforms=[sat1, sat2, sat3, sat4],
    emitters=[target],
)

# Generate observations
observation_time = Time.from_str("2024-01-15T12:00:00Z")
result = scenario.simulate_at(observation_time)

print(f"Generated {len(result)} TDOA observations:")
for obs in result:
    tdoa_ns = obs.value * 1e9  # Convert to nanoseconds
    std_ns = obs.std_dev * 1e9
    print(f"  {obs.sensor_id}: {tdoa_ns:+.2f} ns (σ={std_ns:.2f} ns)")
