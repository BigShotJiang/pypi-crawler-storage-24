#!/usr/bin/env python3
"""Diagnostic script to test sensor calibration in isolation.

This script tests TDOA, AOA, and FDOA sensors separately to identify
which sensor type(s) have covariance calibration issues.

For each sensor type, we:
1. Create a minimal scenario with only that sensor type
2. Run Monte Carlo iterations
3. Compute containment rate (should be ~95%)
4. Report Mahalanobis distances

A properly calibrated sensor should achieve ~95% containment rate
(±5% due to statistical variation with 100 iterations).
"""

from __future__ import annotations

import math

import numpy as np
from gri_nsepoch import Time
from gri_pos import Pos
from gri_utils.constants import SIG_TO_95_3D
from gri_utils.distance import slant_range
from gri_utils.orbit import from_circular

from gri_geosim import Emitter, MonteCarlo, Platform, Scenario, locate
from gri_geosim.sensors import AoaSensor, ConeFov, FdoaSensor, TdoaSensor
from gri_geosim.trajectories import KeplerianTrajectory

# =============================================================================
# Constants
# =============================================================================

# 3D 95% threshold: sqrt(chi2.ppf(0.95, df=3))
MAHAL_95_THRESHOLD = SIG_TO_95_3D**0.5  # ~2.795

# Orbital altitude
LEO_ALTITUDE_KM = 550.0

# Noise parameters (same as comprehensive_scenario.py)
TDOA_NOISE_NS = 1000.0  # 1 microsecond
AOA_NOISE_DEG = 3.0  # 3 degrees
FDOA_NOISE_HZ = 3.0  # 3 Hz

# Monte Carlo iterations
MC_ITERATIONS = 100

# =============================================================================
# Common Setup
# =============================================================================

observation_time = Time.from_str("2024-06-15T14:30:00Z")

# Emitter position
emitter_position = Pos.LLA(38.9, -77.0, 50.0)
emitter = Emitter(
    emitter_position,
    name="TARGET",
    frequency_hz=1.575e9,
)


def create_leo_platform(
    name: str,
    azimuth_deg: float,
    elevation_deg: float,
) -> Platform:
    """Create a LEO satellite platform at specified AER from emitter."""
    range_m = slant_range(
        emitter_position.xyz,
        azimuth_deg=azimuth_deg,
        elevation_deg=elevation_deg,
        target_altitude_m=LEO_ALTITUDE_KM * 1000,
    )
    if range_m is None:
        msg = f"Slant range calculation failed for {name}"
        raise ValueError(msg)

    target_pos = emitter_position.translate_aer((azimuth_deg, elevation_deg, range_m))
    elements = from_circular(target_pos.xyz, observation_time.secs)
    orbit = KeplerianTrajectory(
        semi_major_axis_m=elements.semi_major_axis_m,
        eccentricity=elements.eccentricity,
        inclination_rad=elements.inclination_rad,
        raan_rad=elements.raan_rad,
        arg_periapsis_rad=elements.arg_periapsis_rad,
        mean_anomaly_rad=elements.mean_anomaly_rad,
        epoch=observation_time,
    )
    return Platform(orbit, name=name)


def run_mc_test(
    scenario: Scenario,
) -> tuple[float, float, float, int]:
    """Run Monte Carlo test and return containment stats.

    Returns:
        Tuple of (containment_rate, mean_mahal, median_mahal, num_valid)
    """
    mc = MonteCarlo(scenario, n_iterations=MC_ITERATIONS)
    mc_result = mc.run_at(observation_time)

    ellipsoids = []
    for iter_result in mc_result.observations_by_iteration():
        try:
            ell = locate(iter_result)
            ellipsoids.append(ell)
        except Exception:  # noqa: S110
            pass  # Skip failed locates - expected for some edge cases

    if not ellipsoids:
        return 0.0, float("nan"), float("nan"), 0

    # Compute Mahalanobis distances, handling singular matrices
    mahal_distances = []
    for ell in ellipsoids:
        try:
            mahal = ell.dist_mahalanobis(emitter_position)
            if np.isfinite(mahal):
                mahal_distances.append(mahal)
        except (np.linalg.LinAlgError, ValueError):
            pass

    if not mahal_distances:
        return 0.0, float("nan"), float("nan"), 0

    mahal_arr = np.array(mahal_distances)
    in_95_count = np.sum(mahal_arr < MAHAL_95_THRESHOLD)
    containment_rate = in_95_count / len(mahal_arr) * 100

    return (
        containment_rate,
        float(np.mean(mahal_arr)),
        float(np.median(mahal_arr)),
        len(mahal_arr),
    )


def print_header(title: str) -> None:
    """Print a formatted section header."""
    print("\n" + "=" * 60)
    print(f" {title}")
    print("=" * 60)


# =============================================================================
# Test 1: TDOA Only
# =============================================================================


def test_tdoa_only() -> tuple[float, float, float]:
    """Test TDOA sensors only."""
    print_header("TEST 1: TDOA ONLY")

    # Create two LEO platforms with well-separated geometry
    leo1 = create_leo_platform("LEO-1", azimuth_deg=30.0, elevation_deg=30.0)
    leo2 = create_leo_platform("LEO-2", azimuth_deg=150.0, elevation_deg=35.0)
    leo3 = create_leo_platform("LEO-3", azimuth_deg=270.0, elevation_deg=40.0)

    tdoa_std_s = TDOA_NOISE_NS * 1e-9

    # TDOA pairs: 1-2, 1-3, 2-3 (3 measurements for 3D position)
    tdoa12 = TdoaSensor("tdoa12", tdoa_std_s=tdoa_std_s)
    leo1.add_sensor(tdoa12)
    tdoa12.set_paired_platform(leo2)

    tdoa13 = TdoaSensor("tdoa13", tdoa_std_s=tdoa_std_s)
    leo1.add_sensor(tdoa13)
    tdoa13.set_paired_platform(leo3)

    tdoa23 = TdoaSensor("tdoa23", tdoa_std_s=tdoa_std_s)
    leo2.add_sensor(tdoa23)
    tdoa23.set_paired_platform(leo3)

    scenario = Scenario.for_instant(
        platforms=[leo1, leo2, leo3],
        emitters=[emitter],
    )

    print(f"  TDOA noise: {TDOA_NOISE_NS:.1f} ns ({TDOA_NOISE_NS * 0.3:.1f} m equiv.)")
    print("  Platforms: 3 LEO satellites")
    print("  Sensors: 3 TDOA pairs")

    containment, mean_mahal, median_mahal, num_valid = run_mc_test(scenario)

    print(f"\n  Results ({num_valid}/{MC_ITERATIONS} valid iterations):")
    print(f"    Containment rate: {containment:.1f}% (expected ~95%)")
    print(
        f"    Mean Mahalanobis: {mean_mahal:.2f} (threshold: {MAHAL_95_THRESHOLD:.3f})",
    )
    print(f"    Median Mahalanobis: {median_mahal:.2f}")

    return containment, mean_mahal, median_mahal


# =============================================================================
# Test 2: AOA Only
# =============================================================================


def test_aoa_only() -> tuple[float, float, float]:
    """Test AOA sensors only."""
    print_header("TEST 2: AOA ONLY")

    # Create two LEO platforms with well-separated geometry
    # Need at least 2 AOA measurements for 3D position
    leo1 = create_leo_platform("LEO-1", azimuth_deg=30.0, elevation_deg=30.0)
    leo2 = create_leo_platform("LEO-2", azimuth_deg=150.0, elevation_deg=35.0)

    aoa_std_rad = math.radians(AOA_NOISE_DEG)

    aoa1 = AoaSensor(
        "aoa1",
        azimuth_std_rad=aoa_std_rad,
        elevation_std_rad=aoa_std_rad,
        fov=ConeFov(half_angle_deg=60.0),
    )
    leo1.add_sensor(aoa1)

    aoa2 = AoaSensor(
        "aoa2",
        azimuth_std_rad=aoa_std_rad,
        elevation_std_rad=aoa_std_rad,
        fov=ConeFov(half_angle_deg=60.0),
    )
    leo2.add_sensor(aoa2)

    scenario = Scenario.for_instant(
        platforms=[leo1, leo2],
        emitters=[emitter],
    )

    print(f"  AOA noise: {AOA_NOISE_DEG:.1f} deg")
    print("  Platforms: 2 LEO satellites")
    print("  Sensors: 2 AOA sensors (nadir-pointing)")

    containment, mean_mahal, median_mahal, num_valid = run_mc_test(scenario)

    print(f"\n  Results ({num_valid}/{MC_ITERATIONS} valid iterations):")
    print(f"    Containment rate: {containment:.1f}% (expected ~95%)")
    print(
        f"    Mean Mahalanobis: {mean_mahal:.2f} (threshold: {MAHAL_95_THRESHOLD:.3f})",
    )
    print(f"    Median Mahalanobis: {median_mahal:.2f}")

    return containment, mean_mahal, median_mahal


# =============================================================================
# Test 3: FDOA + TDOA (FDOA needs position constraint)
# =============================================================================


def test_fdoa_with_tdoa() -> tuple[float, float, float]:
    """Test FDOA sensors with minimal TDOA for position constraint."""
    print_header("TEST 3: FDOA + TDOA (position constraint)")

    # Create two LEO platforms
    leo1 = create_leo_platform("LEO-1", azimuth_deg=30.0, elevation_deg=30.0)
    leo2 = create_leo_platform("LEO-2", azimuth_deg=150.0, elevation_deg=35.0)

    tdoa_std_s = TDOA_NOISE_NS * 1e-9

    # One TDOA for position constraint
    tdoa = TdoaSensor("tdoa", tdoa_std_s=tdoa_std_s)
    leo1.add_sensor(tdoa)
    tdoa.set_paired_platform(leo2)

    # FDOA for velocity/position refinement
    fdoa = FdoaSensor("fdoa", fdoa_std_hz=FDOA_NOISE_HZ)
    leo1.add_sensor(fdoa)
    fdoa.set_paired_platform(leo2)

    scenario = Scenario.for_instant(
        platforms=[leo1, leo2],
        emitters=[emitter],
    )

    print(f"  TDOA noise: {TDOA_NOISE_NS:.1f} ns")
    print(f"  FDOA noise: {FDOA_NOISE_HZ:.1f} Hz")
    print("  Platforms: 2 LEO satellites")
    print("  Sensors: 1 TDOA + 1 FDOA")

    containment, mean_mahal, median_mahal, num_valid = run_mc_test(scenario)

    print(f"\n  Results ({num_valid}/{MC_ITERATIONS} valid iterations):")
    print(f"    Containment rate: {containment:.1f}% (expected ~95%)")
    print(
        f"    Mean Mahalanobis: {mean_mahal:.2f} (threshold: {MAHAL_95_THRESHOLD:.3f})",
    )
    print(f"    Median Mahalanobis: {median_mahal:.2f}")

    return containment, mean_mahal, median_mahal


# =============================================================================
# Test 4: AOA + TDOA Combined
# =============================================================================


def test_aoa_tdoa_combined() -> tuple[float, float, float]:
    """Test AOA and TDOA sensors combined."""
    print_header("TEST 4: AOA + TDOA COMBINED")

    leo1 = create_leo_platform("LEO-1", azimuth_deg=30.0, elevation_deg=30.0)
    leo2 = create_leo_platform("LEO-2", azimuth_deg=150.0, elevation_deg=35.0)

    tdoa_std_s = TDOA_NOISE_NS * 1e-9
    aoa_std_rad = math.radians(AOA_NOISE_DEG)

    # AOA on both platforms
    aoa1 = AoaSensor(
        "aoa1",
        azimuth_std_rad=aoa_std_rad,
        elevation_std_rad=aoa_std_rad,
        fov=ConeFov(half_angle_deg=60.0),
    )
    leo1.add_sensor(aoa1)

    aoa2 = AoaSensor(
        "aoa2",
        azimuth_std_rad=aoa_std_rad,
        elevation_std_rad=aoa_std_rad,
        fov=ConeFov(half_angle_deg=60.0),
    )
    leo2.add_sensor(aoa2)

    # TDOA between platforms
    tdoa = TdoaSensor("tdoa", tdoa_std_s=tdoa_std_s)
    leo1.add_sensor(tdoa)
    tdoa.set_paired_platform(leo2)

    scenario = Scenario.for_instant(
        platforms=[leo1, leo2],
        emitters=[emitter],
    )

    print(f"  AOA noise: {AOA_NOISE_DEG:.1f} deg")
    print(f"  TDOA noise: {TDOA_NOISE_NS:.1f} ns")
    print("  Platforms: 2 LEO satellites")
    print("  Sensors: 2 AOA + 1 TDOA")

    containment, mean_mahal, median_mahal, num_valid = run_mc_test(scenario)

    print(f"\n  Results ({num_valid}/{MC_ITERATIONS} valid iterations):")
    print(f"    Containment rate: {containment:.1f}% (expected ~95%)")
    print(
        f"    Mean Mahalanobis: {mean_mahal:.2f} (threshold: {MAHAL_95_THRESHOLD:.3f})",
    )
    print(f"    Median Mahalanobis: {median_mahal:.2f}")

    return containment, mean_mahal, median_mahal


# =============================================================================
# Main
# =============================================================================

if __name__ == "__main__":
    import warnings

    warnings.filterwarnings("ignore", category=RuntimeWarning)

    print_header("SENSOR CALIBRATION DIAGNOSTIC")
    print(f"\n3D Mahalanobis 95% threshold: {MAHAL_95_THRESHOLD:.3f}")
    print(f"Monte Carlo iterations: {MC_ITERATIONS}")

    results = {}

    results["TDOA"] = test_tdoa_only()
    results["AOA"] = test_aoa_only()
    results["FDOA+TDOA"] = test_fdoa_with_tdoa()
    results["AOA+TDOA"] = test_aoa_tdoa_combined()

    print_header("SUMMARY")
    print("\nSensor Type      | Containment | Mean Mahal | Median Mahal")
    print("-" * 60)
    for name, (cont, mean_m, med_m) in results.items():
        status = "OK" if 85 <= cont <= 100 else "ISSUE"  # noqa: PLR2004
        print(
            f"{name:16} | {cont:6.1f}%     | {mean_m:10.2f} | {med_m:12.2f}  [{status}]",
        )

    print(
        f"\nExpected: ~95% containment, Mahalanobis ~{MAHAL_95_THRESHOLD:.2f} at boundary",
    )
    print(
        "\nIf containment < 85%, covariance is likely underestimated for that sensor type.",
    )
    print("If containment > 99%, covariance may be overestimated.")
