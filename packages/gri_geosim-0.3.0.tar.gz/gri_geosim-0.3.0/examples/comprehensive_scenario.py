#!/usr/bin/env python3
"""Comprehensive geolocation scenario demonstrating most gri-geosim capabilities.

This example demonstrates:
- Multiple platform types: LEO satellites, HEO satellite, and aircraft
- Multiple trajectory types: Keplerian orbits and waypoint interpolation
- All sensor types: AOA, TDOA, and FDOA
- FOV constraints: ConeFov for satellites, ElevationMaskFov for aircraft
- Atmospheric corrections (troposphere and ionosphere)
- Full geolocation pipeline: observations -> locate -> Ell
- Comparison to ground truth (containment, miss distance)
- Monte Carlo analysis with aggregated statistics
- Ellipsoid combination with smart_convolve() (iterative outlier rejection)

Scenario:
- 1 terrestrial emitter (ground-based target near Washington DC)
- 2 LEO satellites in circular orbits (~550 km altitude)
- 1 HEO satellite (Molniya-like: 500 km perigee, ~36,000 km apogee)
- 1 aircraft on a waypoint trajectory

Platform Geometry (AER from emitter):
- LEO-1: Az=30° (NE), El=25° - moderate elevation, northeast
- LEO-2: Az=120° (SE), El=40° - higher elevation, southeast
- HEO-1: Az=315° (NW), El=60° - high elevation, northwest
- Aircraft: Az=225° (SW), El=22° - moderate elevation, southwest

The platforms are positioned using the AER (Azimuth-Elevation-Range) technique:
1. slant_range() computes range at desired AE and altitude
2. Pos.translate_aer() places the platform at that AER
3. from_circular() creates orbital elements through that position

This ensures good geometric dilution of precision (GDOP) for accurate geolocation.

Sensor configuration:
- TDOA between LEO pairs and LEO-HEO pairs (3 TDOA sensors)
- FDOA between aircraft and each LEO (2 FDOA sensors, captures orbital Doppler)
- AOA from both LEOs and the aircraft (3 AOA sensors)

This example is designed to be easy to understand while showcasing nearly all
of gri-geosim's capabilities.
"""

from __future__ import annotations

import math

import numpy as np
from gri_convolve import smart_convolve
from gri_nsepoch import Delta, Time
from gri_pos import Pos
from gri_utils.distance import slant_range
from gri_utils.orbit import from_circular, from_perigee_apogee

from gri_geosim import (
    AtmosphereConfig,
    Emitter,
    IonoModel,
    MonteCarlo,
    Platform,
    Scenario,
    filter_aoa,
    filter_fdoa,
    filter_tdoa,
    locate,
)
from gri_geosim.sensors import (
    AoaSensor,
    ConeFov,
    ElevationMaskFov,
    FdoaSensor,
    TdoaSensor,
)
from gri_geosim.trajectories import (
    KeplerianTrajectory,
    WaypointTrajectory,
)

# =============================================================================
# Constants
# =============================================================================

# Orbital altitudes
LEO_ALTITUDE_KM = 550.0  # ~550 km (Starlink-like)
HEO_APOGEE_ALTITUDE_KM = 35_786.0  # Geostationary altitude (HEO apogee)
HEO_PERIGEE_ALTITUDE_KM = 500.0  # Low perigee for Molniya-like orbit

# Platform geometry from emitter (Azimuth, Elevation angles)
# Using diverse angles for good geometric dilution of precision (GDOP)
LEO1_AZIMUTH_DEG = 30.0  # Northeast-ish
LEO1_ELEVATION_DEG = 25.0  # Moderate elevation
LEO2_AZIMUTH_DEG = 120.0  # Southeast
LEO2_ELEVATION_DEG = 40.0  # Higher elevation
HEO_AZIMUTH_DEG = -45.0  # Northwest (315°)
HEO_ELEVATION_DEG = 60.0  # High elevation
AIRCRAFT_AZIMUTH_DEG = 225.0  # Southwest
AIRCRAFT_OFFSET_KM = 25.0  # Distance from emitter (~22° elevation at 10km alt)

# Noise parameters (realistic for space-based geolocation of ground targets)
# These drive the ellipsoid size (SMA ~300m, SMI ~100m)
TDOA_NOISE_NS = 1000.0  # 1 microsecond timing accuracy (~300m range equiv.)
AOA_NOISE_DEG = 3.0  # 3 degree pointing accuracy (typical for wide-area sensors)
FDOA_NOISE_HZ = 3.0  # 3 Hz Doppler accuracy

# Monte Carlo configuration
MC_ITERATIONS = 100

# Statistical thresholds
# Mahalanobis distance threshold for 95% containment
# For 2D ellipse: sqrt(chi2.ppf(0.95, df=2)) ≈ 2.448
# For 3D ellipsoid: sqrt(chi2.ppf(0.95, df=3)) ≈ 2.795
# dist_mahalanobis() uses 3D XYZ information matrix, so use 3D threshold
MAHAL_95_THRESHOLD = 2.795

# =============================================================================
# Observation Time
# =============================================================================

# Single observation instant
observation_time = Time.from_str("2024-06-15T14:30:00Z")

# =============================================================================
# Create Emitter (Ground-based target)
# =============================================================================

# Terrestrial emitter - a radio transmitter on the ground
# Located in the Eastern US (near Washington DC area)
emitter_position = Pos.LLA(38.9, -77.0, 50.0)  # ~50m above ground
emitter = Emitter(
    emitter_position,
    name="GROUND_TARGET",
    frequency_hz=1.575e9,  # L-band (GPS L1 frequency)
)

# =============================================================================
# Create LEO Satellites (Keplerian orbits via AER positioning)
# =============================================================================

# For good geolocation geometry, we position satellites at specific azimuth/elevation
# angles from the emitter using:
#   1. slant_range() to compute range at given AE and altitude
#   2. Pos.translate_aer() to get the satellite position at observation time
#   3. from_circular() to create orbital elements through that position
#
# This approach guarantees the satellite is at the desired AER at observation time
# and provides well-spread geometry for accurate geolocation.

# LEO-1: Northeast at moderate elevation (AZ=30°, EL=25°)
leo1_range_m = slant_range(
    emitter_position.xyz,
    azimuth_deg=LEO1_AZIMUTH_DEG,
    elevation_deg=LEO1_ELEVATION_DEG,
    target_altitude_m=LEO_ALTITUDE_KM * 1000,
)
if leo1_range_m is None:
    msg = "LEO1 slant range calculation failed - check elevation/altitude"
    raise ValueError(msg)
leo1_target_pos = emitter_position.translate_aer(
    (LEO1_AZIMUTH_DEG, LEO1_ELEVATION_DEG, leo1_range_m),
)
leo1_elements = from_circular(leo1_target_pos.xyz, observation_time.secs)
leo1_orbit = KeplerianTrajectory(
    semi_major_axis_m=leo1_elements.semi_major_axis_m,
    eccentricity=leo1_elements.eccentricity,
    inclination_rad=leo1_elements.inclination_rad,
    raan_rad=leo1_elements.raan_rad,
    arg_periapsis_rad=leo1_elements.arg_periapsis_rad,
    mean_anomaly_rad=leo1_elements.mean_anomaly_rad,
    epoch=observation_time,
)
leo1 = Platform(leo1_orbit, name="LEO-1")

# LEO-2: Southeast at higher elevation (AZ=120°, EL=40°)
leo2_range_m = slant_range(
    emitter_position.xyz,
    azimuth_deg=LEO2_AZIMUTH_DEG,
    elevation_deg=LEO2_ELEVATION_DEG,
    target_altitude_m=LEO_ALTITUDE_KM * 1000,
)
if leo2_range_m is None:
    msg = "LEO2 slant range calculation failed - check elevation/altitude"
    raise ValueError(msg)
leo2_target_pos = emitter_position.translate_aer(
    (LEO2_AZIMUTH_DEG, LEO2_ELEVATION_DEG, leo2_range_m),
)
leo2_elements = from_circular(leo2_target_pos.xyz, observation_time.secs)
leo2_orbit = KeplerianTrajectory(
    semi_major_axis_m=leo2_elements.semi_major_axis_m,
    eccentricity=leo2_elements.eccentricity,
    inclination_rad=leo2_elements.inclination_rad,
    raan_rad=leo2_elements.raan_rad,
    arg_periapsis_rad=leo2_elements.arg_periapsis_rad,
    mean_anomaly_rad=leo2_elements.mean_anomaly_rad,
    epoch=observation_time,
)
leo2 = Platform(leo2_orbit, name="LEO-2")

# =============================================================================
# Create HEO Satellite (Molniya-like elliptical orbit)
# =============================================================================

# HEO with apogee at geostationary altitude (AZ=-45°/315°, EL=60°)
# Position the satellite at apogee where it moves slowly - good for stable measurements
# The orbit has a low perigee (500 km) making it a true HEO
EARTH_RADIUS_M = 6_378_137.0
heo_range_m = slant_range(
    emitter_position.xyz,
    azimuth_deg=HEO_AZIMUTH_DEG,
    elevation_deg=HEO_ELEVATION_DEG,
    target_altitude_m=HEO_APOGEE_ALTITUDE_KM * 1000,
)
if heo_range_m is None:
    msg = "HEO slant range calculation failed - check elevation/altitude"
    raise ValueError(msg)
heo_apogee_pos = emitter_position.translate_aer(
    (HEO_AZIMUTH_DEG, HEO_ELEVATION_DEG, heo_range_m),
)

# Create orbit elements - specify apogee position and perigee radius
# Satellite will be at this apogee position at observation_time
# (auto-detected as apogee since position radius > perigee radius)
heo_perigee_radius_m = EARTH_RADIUS_M + HEO_PERIGEE_ALTITUDE_KM * 1000
heo_elements = from_perigee_apogee(
    heo_apogee_pos.xyz,
    heo_perigee_radius_m,
    observation_time.secs,
)
heo_orbit = KeplerianTrajectory(
    semi_major_axis_m=heo_elements.semi_major_axis_m,
    eccentricity=heo_elements.eccentricity,
    inclination_rad=heo_elements.inclination_rad,
    raan_rad=heo_elements.raan_rad,
    arg_periapsis_rad=heo_elements.arg_periapsis_rad,
    mean_anomaly_rad=heo_elements.mean_anomaly_rad,
    epoch=Time(s=heo_elements.epoch_unix_s),
)
heo = Platform(heo_orbit, name="HEO-1")

# =============================================================================
# Create Aircraft (Waypoint trajectory)
# =============================================================================

# Aircraft flying to the SOUTHWEST of the emitter at ~10 km altitude
# This provides geometric diversity from the space-based platforms
# Converting offset to lat/lon (approximate: 1 deg lat ≈ 111 km)
# Azimuth convention: 0=N, 90=E, 180=S, 270=W, so 225=SW
aircraft_offset_deg = AIRCRAFT_OFFSET_KM / 111.0
aircraft_center_lat = emitter_position.lla.lat_deg + aircraft_offset_deg * math.cos(
    math.radians(AIRCRAFT_AZIMUTH_DEG),
)
aircraft_center_lon = emitter_position.lla.lon_deg + aircraft_offset_deg * math.sin(
    math.radians(AIRCRAFT_AZIMUTH_DEG),
) / math.cos(math.radians(emitter_position.lla.lat_deg))

# Aircraft moving roughly northeast at ~250 m/s (typical commercial aircraft speed)
# Create waypoints that pass through the center position at observation time
aircraft_waypoints = [
    (
        observation_time - Delta(s=600),
        Pos.LLA(aircraft_center_lat - 0.3, aircraft_center_lon - 0.3, 10_000.0),
    ),
    (observation_time, Pos.LLA(aircraft_center_lat, aircraft_center_lon, 10_000.0)),
    (
        observation_time + Delta(s=600),
        Pos.LLA(aircraft_center_lat + 0.3, aircraft_center_lon + 0.3, 10_000.0),
    ),
]
aircraft_traj = WaypointTrajectory(aircraft_waypoints, interpolation="cubic")
aircraft = Platform(aircraft_traj, name="AIRCRAFT")

# =============================================================================
# Configure Sensors
# =============================================================================

# Convert noise parameters to sensor units
tdoa_std_s = TDOA_NOISE_NS * 1e-9
aoa_std_rad = math.radians(AOA_NOISE_DEG)

# --- AOA Sensors ---
# LEO satellites use nadir-pointing sensors with conical FOV
# (auto-detect orientation based on altitude)
leo1_aoa = AoaSensor(
    "aoa_leo1",
    azimuth_std_rad=aoa_std_rad,
    elevation_std_rad=aoa_std_rad,
    fov=ConeFov(half_angle_deg=60.0),  # 60° half-angle cone
)
leo1.add_sensor(leo1_aoa)

leo2_aoa = AoaSensor(
    "aoa_leo2",
    azimuth_std_rad=aoa_std_rad,
    elevation_std_rad=aoa_std_rad,
    fov=ConeFov(half_angle_deg=60.0),
)
leo2.add_sensor(leo2_aoa)

# Aircraft uses ENU-frame sensor with elevation mask
aircraft_aoa = AoaSensor(
    "aoa_aircraft",
    azimuth_std_rad=aoa_std_rad,
    elevation_std_rad=aoa_std_rad,
    fov=ElevationMaskFov(min_elev_deg=-60.0),  # Can see below horizon
)
aircraft.add_sensor(aircraft_aoa)

# --- TDOA Sensors ---
# LEO-1 to LEO-2 pair
tdoa_leo12 = TdoaSensor("tdoa_leo12", tdoa_std_s=tdoa_std_s)
leo1.add_sensor(tdoa_leo12)
tdoa_leo12.set_paired_platform(leo2)

# LEO-1 to HEO pair (long baseline)
tdoa_leo1_heo = TdoaSensor("tdoa_leo1_heo", tdoa_std_s=tdoa_std_s)
leo1.add_sensor(tdoa_leo1_heo)
tdoa_leo1_heo.set_paired_platform(heo)

# LEO-2 to HEO pair
tdoa_leo2_heo = TdoaSensor("tdoa_leo2_heo", tdoa_std_s=tdoa_std_s)
leo2.add_sensor(tdoa_leo2_heo)
tdoa_leo2_heo.set_paired_platform(heo)

# --- FDOA Sensors ---
# Aircraft to LEO pairs (aircraft velocity creates Doppler diversity)
# Note: LEO orbital velocity (~7.6 km/s) dominates over aircraft (~250 m/s)
fdoa_ac_leo1 = FdoaSensor("fdoa_ac_leo1", fdoa_std_hz=FDOA_NOISE_HZ)
aircraft.add_sensor(fdoa_ac_leo1)
fdoa_ac_leo1.set_paired_platform(leo1)

fdoa_ac_leo2 = FdoaSensor("fdoa_ac_leo2", fdoa_std_hz=FDOA_NOISE_HZ)
aircraft.add_sensor(fdoa_ac_leo2)
fdoa_ac_leo2.set_paired_platform(leo2)

# =============================================================================
# Create Scenario
# =============================================================================

scenario = Scenario.for_instant(
    platforms=[leo1, leo2, heo, aircraft],
    emitters=[emitter],
)

# =============================================================================
# Configure Atmosphere
# =============================================================================

# Enable both tropospheric and ionospheric corrections
# Using BENT model for ionosphere (fast, suitable for demonstration)
atmosphere = AtmosphereConfig(
    enable_tropo=True,
    enable_iono=True,
    iono_model=IonoModel.BENT,
)

# =============================================================================
# Print Scenario Setup
# =============================================================================


def print_header(title: str) -> None:
    """Print a formatted section header."""
    print("\n" + "=" * 70)
    print(f" {title}")
    print("=" * 70)


print_header("SCENARIO CONFIGURATION")

print("\nEmitter (Ground Target):")
print(f"  Position: {emitter_position.lla}")
print(f"  Frequency: {emitter.frequency_hz / 1e9:.3f} GHz")

print("\nPlatforms (with AER from emitter):")
for platform in [leo1, leo2, heo, aircraft]:
    pos = platform.position_at(observation_time)
    vel = platform.velocity_at(observation_time)
    vel_mag = np.linalg.norm(vel)
    alt_km = pos.lla.alt_m / 1000.0
    # Compute AER from emitter to platform
    aer = emitter_position.delta_aer(pos)
    print(f"  {platform.name}:")
    print(
        f"    Position: {pos.lla.lat_deg:.2f}°, {pos.lla.lon_deg:.2f}°, {alt_km:.1f} km",
    )
    print(
        f"    AER from emitter: Az={aer[0]:.1f}°, El={aer[1]:.1f}°, R={aer[2] / 1000:.0f} km",
    )
    print(f"    Velocity: {vel_mag:.1f} m/s")
    print(f"    Sensors: {[s.sensor_id for s in platform.sensors]}")

print("\nSensor Configuration:")
print(
    f"  TDOA noise: {TDOA_NOISE_NS:.1f} ns ({TDOA_NOISE_NS * 0.3:.1f} m range equiv.)",
)
print(f"  AOA noise:  {AOA_NOISE_DEG:.2f}°")
print(f"  FDOA noise: {FDOA_NOISE_HZ:.2f} Hz")

print("\nAtmosphere:")
print(f"  Troposphere: {atmosphere.enable_tropo}")
print(f"  Ionosphere:  {atmosphere.enable_iono} ({atmosphere.iono_model.name})")

# =============================================================================
# Single Simulation Run
# =============================================================================

print_header("SINGLE SIMULATION")

# Run simulation with noise
result = scenario.simulate_at(observation_time, add_noise=True, atmosphere=atmosphere)

print(f"\nGenerated {len(result)} observations:")
print(f"  AOA:  {len(filter_aoa(result))}")
print(f"  TDOA: {len(filter_tdoa(result))}")
print(f"  FDOA: {len(filter_fdoa(result))}")

# Show sample observations
print("\nSample Observations:")
for obs in filter_aoa(result)[:2]:
    print(
        f"  {obs.sensor_id}: az={math.degrees(obs.azimuth):.2f}°, el={math.degrees(obs.elevation):.2f}°",
    )

for obs in filter_tdoa(result)[:2]:
    print(f"  {obs.sensor_id}: {obs.value * 1e9:.2f} ns")

for obs in filter_fdoa(result)[:2]:
    print(f"  {obs.sensor_id}: {obs.value:.2f} Hz")

# =============================================================================
# Geolocation from Single Observation Set
# =============================================================================

print_header("GEOLOCATION RESULT")

# Locate emitter from observations
ell = locate(result)

print("\nEstimated Position:")
print(f"  Lat: {ell.lla.lat_deg:.4f}°")
print(f"  Lon: {ell.lla.lon_deg:.4f}°")
print(f"  Alt: {ell.lla.alt_m:.1f} m")

print("\nTrue Position:")
print(f"  Lat: {emitter_position.lla.lat_deg:.4f}°")
print(f"  Lon: {emitter_position.lla.lon_deg:.4f}°")
print(f"  Alt: {emitter_position.lla.alt_m:.1f} m")

# Compute errors
miss_distance_m = np.linalg.norm(ell.xyz - emitter_position.xyz)
lat_error = ell.lla.lat_deg - emitter_position.lla.lat_deg
lon_error = ell.lla.lon_deg - emitter_position.lla.lon_deg
alt_error = ell.lla.alt_m - emitter_position.lla.alt_m

print("\nErrors:")
print(f"  3D Miss Distance: {miss_distance_m:.1f} m")
print(f"  Lat Error: {lat_error * 111_000:.1f} m ({lat_error:.4f}°)")
print(
    f"  Lon Error: {lon_error * 111_000 * math.cos(math.radians(ell.lla.lat_deg)):.1f} m ({lon_error:.4f}°)",
)
print(f"  Alt Error: {alt_error:.1f} m")

# Ellipsoid statistics (2D horizontal ellipse + altitude)
print("\nUncertainty Ellipsoid (95% confidence):")
print(f"  Semi-Major Axis (2D): {ell.ellipse.sma_95:.1f} m")
print(f"  Semi-Minor Axis (2D): {ell.ellipse.smi_95:.1f} m")
print(f"  Altitude (1D): {ell.ellipse.alt_95:.1f} m")

# Check containment (is true position within 95% ellipsoid?)
# Note: Mahalanobis distance < MAHAL_95_THRESHOLD for 95% containment in 2D
mahal_dist = ell.dist_mahalanobis(emitter_position)
in_95_ellipsoid = mahal_dist < MAHAL_95_THRESHOLD  # ~95% for 2D
print("\nContainment Check:")
print(f"  Mahalanobis Distance: {mahal_dist:.2f}")
print(f"  Within 95% Ellipsoid: {in_95_ellipsoid}")

# =============================================================================
# Monte Carlo Analysis
# =============================================================================

print_header("MONTE CARLO ANALYSIS")

print(f"\nRunning {MC_ITERATIONS} iterations...")

mc = MonteCarlo(scenario, n_iterations=MC_ITERATIONS)


def progress_callback(current: int, total: int) -> None:
    """Print progress updates."""
    if current % 20 == 0 or current == total:
        print(f"  Progress: {current}/{total}")


mc_result = mc.run_at(
    observation_time,
    atmosphere=atmosphere,
    progress_callback=progress_callback,
)

# Locate from each iteration
print("\nLocating emitter for each iteration...")
ellipsoids = []
failed_locates = 0
for iter_result in mc_result.observations_by_iteration():
    try:
        ell = locate(iter_result)
        ellipsoids.append(ell)
    except Exception:
        failed_locates += 1

print(f"  Successful: {len(ellipsoids)}/{MC_ITERATIONS}")
if failed_locates > 0:
    print(f"  Failed: {failed_locates}")

# =============================================================================
# Smart Convolve Monte Carlo Results (with outlier rejection)
# =============================================================================

print_header("SMART CONVOLVE RESULTS (OUTLIER REJECTION)")

# smart_convolve iteratively removes outliers based on Mahalanobis distance
# Returns (solution, used_indices, discarded_indices) or None if too few remain
#
# NOTE: Convolution reduces random error by combining N estimates, shrinking
# the covariance by ~1/N. However, it does NOT reduce systematic bias.
# If estimates share common biases (same geometry, atmospheric model, etc.),
# the convolved ellipsoid will be very tight but may not contain the true
# position. High Mahalanobis distance here indicates systematic bias, not
# poor covariance calibration.
smart_result = None
if len(ellipsoids) >= 3:  # noqa: PLR2004
    smart_result = smart_convolve(ellipsoids, max_norm=2.0, min_pts=3)

    if smart_result is not None:
        smart_ell, used_indices, discarded_indices = smart_result
        print("\nSmart Convolved Position Estimate:")
        print(f"  Lat: {smart_ell.lla.lat_deg:.4f}°")
        print(f"  Lon: {smart_ell.lla.lon_deg:.4f}°")
        print(f"  Alt: {smart_ell.lla.alt_m:.1f} m")

        # Errors
        smart_miss = np.linalg.norm(smart_ell.xyz - emitter_position.xyz)
        print(f"\n  3D Miss Distance: {smart_miss:.1f} m")
        print(f"  SMA (95%): {smart_ell.ellipse.sma_95:.1f} m")
        print(f"  SMI (95%): {smart_ell.ellipse.smi_95:.1f} m")
        print(f"  Alt (95%): {smart_ell.ellipse.alt_95:.1f} m")

        print("\nOutlier Rejection Statistics:")
        print(f"  Ellipsoids Used: {len(used_indices)}/{len(ellipsoids)}")
        print(f"  Ellipsoids Discarded: {len(discarded_indices)}")

        # Check containment
        # NOTE: High Mahalanobis distance here often indicates systematic bias
        # (all iterations share common errors), not covariance miscalibration.
        # The individual iteration containment rate is the true calibration metric.
        smart_mahal = smart_ell.dist_mahalanobis(emitter_position)
        smart_in_95 = smart_mahal < MAHAL_95_THRESHOLD
        print(f"\n  Mahalanobis Distance: {smart_mahal:.2f}")
        print(f"  Within 95% Ellipsoid: {smart_in_95}")
        if not smart_in_95:
            print("    (High value indicates systematic bias shared across iterations)")
    else:
        print("\nSmart convolve failed (insufficient inliers)")

# =============================================================================
# Monte Carlo Statistics
# =============================================================================

print_header("MONTE CARLO STATISTICS")

# Compute miss distances for all ellipsoids
miss_distances = np.array(
    [np.linalg.norm(e.xyz - emitter_position.xyz) for e in ellipsoids],
)
sma_values = np.array([e.ellipse.sma_95 for e in ellipsoids])

# Containment analysis
mahal_distances = np.array([e.dist_mahalanobis(emitter_position) for e in ellipsoids])
in_95_count = np.sum(mahal_distances < MAHAL_95_THRESHOLD)
containment_rate = in_95_count / len(ellipsoids) * 100

print("\nMiss Distance Statistics:")
print(f"  Mean:   {np.mean(miss_distances):.1f} m")
print(f"  Median: {np.median(miss_distances):.1f} m")
print(f"  Std:    {np.std(miss_distances):.1f} m")
print(f"  Min:    {np.min(miss_distances):.1f} m")
print(f"  Max:    {np.max(miss_distances):.1f} m")

print("\nSMA (95%) Statistics:")
print(f"  Mean:   {np.mean(sma_values):.2f} m")
print(f"  Median: {np.median(sma_values):.2f} m")
print(f"  Std:    {np.std(sma_values):.3f} m")  # Higher precision - SMA varies slightly

print("\nContainment Analysis:")
print("  Expected 95% containment rate: 95.0%")
print(f"  Actual containment rate: {containment_rate:.1f}%")
print(f"  ({in_95_count}/{len(ellipsoids)} iterations within 95% ellipsoid)")

# Observation statistics from MC
print("\nObservation Statistics (from Monte Carlo):")
for obs_type in ["AOA", "TDOA", "FDOA"]:
    try:
        stats = mc_result.compute_statistics(obs_type=obs_type)
        if stats:
            print(f"  {obs_type}:")
            # Stats may be arrays (for multi-dimensional like AOA) or scalars
            mean_val = stats["mean"]
            std_val = stats["std"]
            if hasattr(mean_val, "__len__"):
                print(f"    Mean: {np.array2string(np.asarray(mean_val), precision=6)}")
                print(f"    Std:  {np.array2string(np.asarray(std_val), precision=6)}")
            else:
                print(f"    Mean: {mean_val:.6g}")
                print(f"    Std:  {std_val:.6g}")
    except (ValueError, KeyError):
        pass

print_header("SIMULATION COMPLETE")
print("\nThis example demonstrated:")
print("  - LEO and HEO satellites with Keplerian orbits (via AER positioning)")
print("  - Aircraft with waypoint trajectory")
print("  - AOA, TDOA, and FDOA sensor types")
print("  - Tropospheric and ionospheric corrections")
print("  - Single-instant geolocation with error analysis")
print("  - Monte Carlo simulation with 100 iterations")
print("  - Ellipsoid combination with smart_convolve() (outlier rejection)")
print("  - Statistical analysis of geolocation accuracy and containment")
