"""Waypoint trajectory for interpolated paths through known positions.

A WaypointTrajectory represents a platform following a path defined by
waypoints (time, position pairs). The position at any time is interpolated
from the waypoints using linear or cubic spline interpolation.

This is useful for aircraft, ships, ground vehicles, or any platform with
a known or planned route.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np
from gri_nsepoch import Delta, Time
from gri_pos import LLA, XYZ, Pos
from scipy.interpolate import CubicSpline, interp1d

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class WaypointTrajectory:
    """Trajectory interpolated from waypoints.

    Defines a path through a series of (time, position) waypoints. The
    position at any query time is interpolated from the waypoints.

    Supports two interpolation methods:
    - "linear": Linear interpolation between waypoints
    - "cubic": Cubic spline interpolation (smoother, but may overshoot)

    For times outside the waypoint range, extrapolation is used (which
    may produce unrealistic results for large extrapolations).

    Attributes:
        waypoints: List of (time, position) tuples defining the path.
        interpolation: Interpolation method used ("linear" or "cubic").

    Example:
        >>> from gri_pos import Pos
        >>> from gri_nsepoch import Time, Delta
        >>> waypoints = [
        ...     (Time(), Pos.LLA(38.0, -77.0, 1000.0)),
        ...     (Time() + Delta(s=3600), Pos.LLA(39.0, -76.0, 1000.0)),
        ... ]
        >>> traj = WaypointTrajectory(waypoints)
        >>> pos = traj.position_at(Time() + Delta(s=1800))  # Halfway
    """

    __slots__ = (
        "_interp_x",
        "_interp_y",
        "_interp_z",
        "_interpolation",
        "_positions_xyz",
        "_times_unix",
    )

    def __init__(
        self,
        waypoints: Sequence[
            tuple[Time, Pos | LLA | XYZ | np.ndarray | Sequence[float]]
        ],
        *,
        interpolation: Literal["linear", "cubic"] = "linear",
    ) -> None:
        """Initialize a waypoint trajectory.

        Args:
            waypoints: List of (time, position) tuples. Each position can be:
                - Pos object
                - LLA object (lat/lon/alt in degrees/meters)
                - XYZ object (ECEF meters)
                - numpy array (interpreted as XYZ meters)
                - Sequence of 3 floats (interpreted as XYZ meters)
            interpolation: Interpolation method. Options:
                - "linear": Linear interpolation (default)
                - "cubic": Cubic spline interpolation

        Raises:
            ValueError: If fewer than 2 waypoints provided.
            ValueError: If waypoint times are not strictly increasing.
            ValueError: If interpolation method is unknown.
        """
        if len(waypoints) < 2:  # noqa: PLR2004
            raise ValueError(
                f"At least 2 waypoints required, got {len(waypoints)}",
            )

        if interpolation not in ("linear", "cubic"):
            raise ValueError(
                f"Unknown interpolation method: {interpolation}. "
                "Expected 'linear' or 'cubic'.",
            )

        self._interpolation = interpolation

        # Extract times and positions
        times_unix = []
        positions_xyz = []

        for time_obj, position in waypoints:
            times_unix.append(time_obj.secs)

            # Convert position to XYZ
            if isinstance(position, Pos):
                xyz = position.xyz
            elif isinstance(position, (LLA, XYZ)):
                xyz = Pos(position).xyz
            elif isinstance(position, np.ndarray):
                xyz = np.asarray(position, dtype=np.float64)
            elif hasattr(position, "__len__") and len(position) == 3:  # type: ignore[arg-type]  # noqa: PLR2004
                xyz = np.array(position, dtype=np.float64)
            else:
                raise TypeError(
                    f"Unsupported position type: {type(position).__name__}. "
                    "Expected Pos, LLA, XYZ, numpy array, or sequence of 3 floats.",
                )

            positions_xyz.append(xyz)

        # Check times are strictly increasing
        self._times_unix = np.array(times_unix, dtype=np.float64)
        if not np.all(np.diff(self._times_unix) > 0):
            raise ValueError("Waypoint times must be strictly increasing")

        self._positions_xyz = np.array(positions_xyz, dtype=np.float64)

        # Build interpolators for each coordinate
        # Note: "extrapolate" is a valid value for fill_value but scipy stubs
        # don't properly type it as Literal["extrapolate"]
        if interpolation == "linear":
            self._interp_x = interp1d(
                self._times_unix,
                self._positions_xyz[:, 0],
                kind="linear",
                fill_value="extrapolate",  # type: ignore[arg-type]
            )
            self._interp_y = interp1d(
                self._times_unix,
                self._positions_xyz[:, 1],
                kind="linear",
                fill_value="extrapolate",  # type: ignore[arg-type]
            )
            self._interp_z = interp1d(
                self._times_unix,
                self._positions_xyz[:, 2],
                kind="linear",
                fill_value="extrapolate",  # type: ignore[arg-type]
            )
        else:  # cubic
            self._interp_x = CubicSpline(
                self._times_unix,
                self._positions_xyz[:, 0],
                extrapolate=True,
            )
            self._interp_y = CubicSpline(
                self._times_unix,
                self._positions_xyz[:, 1],
                extrapolate=True,
            )
            self._interp_z = CubicSpline(
                self._times_unix,
                self._positions_xyz[:, 2],
                extrapolate=True,
            )

    @property
    def interpolation(self) -> str:
        """Interpolation method used."""
        return self._interpolation

    @property
    def start_time_unix(self) -> float:
        """Unix time of the first waypoint."""
        return float(self._times_unix[0])

    @property
    def end_time_unix(self) -> float:
        """Unix time of the last waypoint."""
        return float(self._times_unix[-1])

    @property
    def num_waypoints(self) -> int:
        """Number of waypoints."""
        return len(self._times_unix)

    def position_at(self, time: Time) -> Pos:
        """Get platform position at a specific time.

        Interpolates position from waypoints.

        Args:
            time: Time instant for position query.

        Returns:
            Pos object with interpolated position in ECEF frame.
        """
        unix_s = time.secs

        x = float(self._interp_x(unix_s))
        y = float(self._interp_y(unix_s))
        z = float(self._interp_z(unix_s))

        return Pos.XYZ(np.array([x, y, z]))

    def velocity_at(self, time: Time) -> NDArray[np.floating]:
        """Get platform velocity at a specific time.

        For linear interpolation, velocity is constant between waypoints.
        For cubic interpolation, velocity is computed from the spline derivative.

        Args:
            time: Time instant for velocity query.

        Returns:
            Velocity vector [vx, vy, vz] in ECEF frame, meters per second.
        """
        unix_s = time.secs

        if self._interpolation == "cubic":
            # Use spline derivative
            vx = float(self._interp_x(unix_s, 1))  # type: ignore[call-arg]
            vy = float(self._interp_y(unix_s, 1))  # type: ignore[call-arg]
            vz = float(self._interp_z(unix_s, 1))  # type: ignore[call-arg]
        else:
            # Linear: compute velocity from nearby positions
            dt = 0.1  # Small time delta for numerical derivative
            pos1 = self.position_at(time)
            time2 = time + Delta(s=dt)
            pos2 = self.position_at(time2)

            velocity = (pos2.xyz - pos1.xyz) / dt
            return np.asarray(velocity, dtype=np.float64)

        return np.array([vx, vy, vz], dtype=np.float64)

    def state_at(self, time: Time) -> tuple[Pos, NDArray[np.floating]]:
        """Get both position and velocity at a specific time.

        Args:
            time: Time instant for state query.

        Returns:
            Tuple of (position, velocity).
        """
        return self.position_at(time), self.velocity_at(time)

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"WaypointTrajectory({self.num_waypoints} waypoints, "
            f"interpolation='{self._interpolation}')"
        )
