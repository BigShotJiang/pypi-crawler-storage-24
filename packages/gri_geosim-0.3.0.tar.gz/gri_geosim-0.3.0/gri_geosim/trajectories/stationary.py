"""Stationary trajectory for fixed-position platforms.

A StationaryTrajectory represents a platform that does not move, such as a
ground station or fixed sensor. Position is constant and velocity is zero.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import LLA, XYZ, Pos

if TYPE_CHECKING:
    from collections.abc import Sequence

    from gri_nsepoch import Time
    from numpy.typing import NDArray


class StationaryTrajectory:
    """Trajectory for a fixed-position platform.

    The position is constant regardless of time, and velocity is always zero.
    Useful for ground stations, fixed sensors, and stationary emitters.

    Attributes:
        position: The fixed position as a Pos object.

    Example:
        >>> from gri_pos import Pos
        >>> from gri_nsepoch import Time
        >>> traj = StationaryTrajectory(Pos.LLA(38.0, -77.0, 100.0))
        >>> pos = traj.position_at(Time())
        >>> vel = traj.velocity_at(Time())
        >>> np.allclose(vel, [0, 0, 0])
        True
    """

    __slots__ = ("_position", "_zero_velocity")

    def __init__(
        self,
        position: Pos | LLA | XYZ | np.ndarray | Sequence[float],
    ) -> None:
        """Initialize a stationary trajectory at a fixed position.

        Args:
            position: The fixed position. Accepts:
                - Pos object
                - LLA object (lat/lon/alt in degrees/meters)
                - XYZ object (ECEF meters)
                - numpy array (interpreted as XYZ meters)
                - Sequence of 3 floats (interpreted as XYZ meters)

        Raises:
            TypeError: If position type is not supported.
        """
        if isinstance(position, Pos):
            self._position = position
        elif isinstance(position, (LLA, XYZ)):
            self._position = Pos(position)
        elif isinstance(position, np.ndarray):
            self._position = Pos.XYZ(position)
        elif hasattr(position, "__len__") and len(position) == 3:  # type: ignore[arg-type]  # noqa: PLR2004
            self._position = Pos.XYZ(*position)
        else:
            raise TypeError(
                f"Unsupported position type: {type(position).__name__}. "
                "Expected Pos, LLA, XYZ, numpy array, or sequence of 3 floats.",
            )

        # Pre-allocate zero velocity array (read-only)
        self._zero_velocity = np.zeros(3, dtype=np.float64)
        self._zero_velocity.flags.writeable = False

    @property
    def position(self) -> Pos:
        """The fixed position of this trajectory."""
        return self._position

    def position_at(self, time: Time) -> Pos:  # noqa: ARG002
        """Get platform position at a specific time.

        For a stationary trajectory, this always returns the same position
        regardless of time.

        Args:
            time: Time instant (ignored for stationary trajectory).

        Returns:
            The fixed Pos object.
        """
        return self._position

    def velocity_at(self, time: Time) -> NDArray[np.floating]:  # noqa: ARG002
        """Get platform velocity at a specific time.

        For a stationary trajectory, this always returns zero velocity.

        Args:
            time: Time instant (ignored for stationary trajectory).

        Returns:
            Zero velocity vector [0, 0, 0] in ECEF m/s.
        """
        return self._zero_velocity

    def state_at(self, time: Time) -> tuple[Pos, NDArray[np.floating]]:  # noqa: ARG002
        """Get both position and velocity at a specific time.

        Args:
            time: Time instant (ignored for stationary trajectory).

        Returns:
            Tuple of (position, zero_velocity).
        """
        return self._position, self._zero_velocity

    def __repr__(self) -> str:
        """Return string representation."""
        return f"StationaryTrajectory({self._position})"
