"""Hermite trajectory for interpolated paths through known state vectors.

A HermiteTrajectory represents a platform whose path is defined by discrete
state vectors (position + velocity at known times). The state at any time is
interpolated using cubic Hermite splines, which match both position and velocity
at each knot point.

This is useful for platforms with ephemeris data from an external source (e.g.,
a high-fidelity propagator, SP3 precise ephemeris, or observed track data)
where you need smooth interpolation that respects the velocity information.

Compared to WaypointTrajectory:
- Hermite uses both position AND velocity at knots (higher fidelity)
- Waypoint cubic spline only matches positions (ignores velocity data)
- Hermite is C1-continuous; cubic spline is C2-continuous

Compared to KeplerianTrajectory:
- Hermite is data-driven (no physics assumptions between knots)
- Keplerian is physics-driven (two-body propagation from a single epoch)
- Hermite handles arbitrary motion including perturbed orbits and non-orbital paths
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import LLA, XYZ, Pos
from gri_utils.orbit import hermite_interpolate

if TYPE_CHECKING:
    from collections.abc import Sequence

    from gri_nsepoch import Time
    from numpy.typing import NDArray


class HermiteTrajectory:
    """Trajectory interpolated from state vectors using cubic Hermite splines.

    Defines a path through a series of (time, position, velocity) knots. The
    state at any query time is interpolated using Hermite splines that match
    both position and velocity at each knot.

    All positions and velocities are in the ECEF frame.

    Attributes:
        num_knots: Number of state vector knots.
        start_time_unix: Unix time of the first knot.
        end_time_unix: Unix time of the last knot.

    Example:
        >>> from gri_pos import Pos
        >>> from gri_nsepoch import Time, Delta
        >>> import numpy as np
        >>> vel = np.array([100.0, 0.0, 0.0])
        >>> knots = [
        ...     (Time(), Pos.LLA(38.0, -77.0, 400e3), vel),
        ...     (Time() + Delta(s=60), Pos.LLA(38.5, -76.5, 400e3), vel),
        ...     (Time() + Delta(s=120), Pos.LLA(39.0, -76.0, 400e3), vel),
        ... ]
        >>> traj = HermiteTrajectory(knots)
        >>> pos = traj.position_at(Time() + Delta(s=30))
    """

    __slots__ = ("_positions_xyz", "_times_unix", "_velocities_xyz")

    def __init__(
        self,
        knots: Sequence[
            tuple[
                Time,
                Pos | LLA | XYZ | NDArray[np.floating] | Sequence[float],
                NDArray[np.floating] | Sequence[float],
            ]
        ],
    ) -> None:
        """Initialize a Hermite trajectory from state vector knots.

        Args:
            knots: List of (time, position, velocity_ecef_ms) tuples.
                Each position can be a Pos, LLA, XYZ, numpy array, or
                sequence of 3 floats (interpreted as ECEF XYZ meters).
                Each velocity is [vx, vy, vz] in ECEF m/s.

        Raises:
            ValueError: If fewer than 2 knots provided.
            ValueError: If knot times are not strictly increasing.
        """
        if len(knots) < 2:  # noqa: PLR2004
            msg = f"At least 2 knots required, got {len(knots)}"
            raise ValueError(msg)

        times_unix = []
        positions_xyz = []
        velocities_xyz = []

        for time_obj, position, velocity in knots:
            times_unix.append(time_obj.secs)
            positions_xyz.append(_to_xyz(position))
            velocities_xyz.append(np.asarray(velocity, dtype=np.float64))

        self._times_unix = np.array(times_unix, dtype=np.float64)
        self._positions_xyz = np.array(positions_xyz, dtype=np.float64)
        self._velocities_xyz = np.array(velocities_xyz, dtype=np.float64)

        if not np.all(np.diff(self._times_unix) > 0):
            raise ValueError("Knot times must be strictly increasing")

    @property
    def num_knots(self) -> int:
        """Number of state vector knots."""
        return len(self._times_unix)

    @property
    def start_time_unix(self) -> float:
        """Unix time of the first knot."""
        return float(self._times_unix[0])

    @property
    def end_time_unix(self) -> float:
        """Unix time of the last knot."""
        return float(self._times_unix[-1])

    def position_at(self, time: Time) -> Pos:
        """Get platform position at a specific time.

        Args:
            time: Time instant for position query.

        Returns:
            Pos object with interpolated position in ECEF frame.
        """
        return self.state_at(time)[0]

    def velocity_at(self, time: Time) -> NDArray[np.floating]:
        """Get platform velocity at a specific time.

        Args:
            time: Time instant for velocity query.

        Returns:
            Velocity vector [vx, vy, vz] in ECEF frame, meters per second.
        """
        return self.state_at(time)[1]

    def state_at(self, time: Time) -> tuple[Pos, NDArray[np.floating]]:
        """Get both position and velocity at a specific time.

        More efficient than calling position_at and velocity_at separately
        as it only performs one interpolation.

        Args:
            time: Time instant for state query.

        Returns:
            Tuple of (position, velocity) where position is a Pos object
            in ECEF frame and velocity is [vx, vy, vz] in ECEF m/s.
        """
        state = hermite_interpolate(
            self._times_unix,
            self._positions_xyz,
            self._velocities_xyz,
            time.secs,
        )
        # hermite_interpolate returns OrbitState for scalar input
        if isinstance(state, list):
            raise TypeError("Expected single OrbitState from scalar time input")

        pos = Pos.XYZ(state.position_eci_m)
        vel = np.asarray(state.velocity_eci_ms, dtype=np.float64)
        return pos, vel

    def __repr__(self) -> str:
        """Return string representation."""
        return f"HermiteTrajectory({self.num_knots} knots)"


def _to_xyz(
    position: Pos | LLA | XYZ | NDArray[np.floating] | Sequence[float],
) -> NDArray[np.floating]:
    """Convert a position to an XYZ numpy array.

    Args:
        position: Position in any supported format.

    Returns:
        XYZ position as a numpy array of shape (3,).

    Raises:
        TypeError: If position type is not supported.
    """
    if isinstance(position, Pos):
        return np.asarray(position.xyz, dtype=np.float64)
    if isinstance(position, (LLA, XYZ)):
        return np.asarray(Pos(position).xyz, dtype=np.float64)
    if isinstance(position, np.ndarray):
        return np.asarray(position, dtype=np.float64)
    if hasattr(position, "__len__") and len(position) == 3:  # type: ignore[arg-type]  # noqa: PLR2004
        return np.array(position, dtype=np.float64)
    msg = (
        f"Unsupported position type: {type(position).__name__}. "
        "Expected Pos, LLA, XYZ, numpy array, or sequence of 3 floats."
    )
    raise TypeError(msg)
