"""Keplerian trajectory for two-body orbital mechanics.

A KeplerianTrajectory represents a satellite or spacecraft following a
Keplerian orbit. It uses gri-utils orbital mechanics for propagation and
coordinate conversion.

This is a fast propagator optimized for short-duration trajectories (minutes
to a few hours). It uses simplified two-body dynamics with no perturbations,
making it computationally efficient but less accurate over longer time spans.

For longer propagation periods (hours to days), use Sgp4Trajectory with TLE
data instead. SGP4 accounts for drag, J2 perturbations, and other effects
that become significant over extended durations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_nsepoch import Time
from gri_pos import Pos
from gri_utils.conversion import eci_to_ecef, eci_to_ecef_vel
from gri_utils.orbit import OrbitalElements, OrbitState, elements_to_state, from_tle

if TYPE_CHECKING:
    from numpy.typing import NDArray


class KeplerianTrajectory:
    """Trajectory using Keplerian two-body orbital mechanics.

    Propagates orbital elements forward or backward in time using the
    analytic two-body solution. Position and velocity are returned in
    the ECEF frame for compatibility with ground-based observations.

    This is a fast propagator intended for short-duration trajectories
    (minutes to a few hours). It uses simplified two-body dynamics with
    no perturbations, making it computationally efficient but less
    accurate over longer time spans.

    For longer propagation periods (hours to days), use Sgp4Trajectory
    instead. SGP4 accounts for drag, J2 perturbations, and other effects
    that become significant over extended durations.

    This class stores the orbital elements and computes state vectors
    on demand. It uses gri-utils for the actual propagation and
    coordinate conversions.

    Attributes:
        elements: The OrbitalElements defining this orbit.

    Example:
        >>> from gri_nsepoch import Time
        >>> import math
        >>> traj = KeplerianTrajectory(
        ...     semi_major_axis_m=6_778_000,  # ~400 km altitude
        ...     eccentricity=0.0001,
        ...     inclination_rad=math.radians(51.6),
        ...     raan_rad=0.0,
        ...     arg_periapsis_rad=0.0,
        ...     mean_anomaly_rad=0.0,
        ...     epoch=Time(),
        ... )
        >>> pos = traj.position_at(Time())
    """

    __slots__ = ("_elements",)

    def __init__(  # noqa: PLR0913
        self,
        semi_major_axis_m: float,
        eccentricity: float,
        inclination_rad: float,
        raan_rad: float,
        arg_periapsis_rad: float,
        mean_anomaly_rad: float,
        epoch: Time,
    ) -> None:
        """Initialize a Keplerian trajectory from orbital elements.

        Args:
            semi_major_axis_m: Semi-major axis in meters. Defines orbit size.
                For circular LEO, approximately 6.778e6 m (400 km altitude).
            eccentricity: Orbital eccentricity (dimensionless).
                0 = circular, 0 < e < 1 = elliptical.
            inclination_rad: Inclination in radians [0, pi].
                Angle between orbit plane and equatorial plane.
            raan_rad: Right Ascension of Ascending Node in radians [0, 2*pi).
                Orientation of the ascending node from vernal equinox.
            arg_periapsis_rad: Argument of periapsis in radians [0, 2*pi).
                Angle from ascending node to periapsis in orbit plane.
            mean_anomaly_rad: Mean anomaly at epoch in radians [0, 2*pi).
                Position along the orbit at the reference epoch.
            epoch: Reference time for the mean anomaly.

        Raises:
            ValueError: If eccentricity >= 1 (hyperbolic/parabolic not supported).
            ValueError: If semi_major_axis_m <= 0.
        """
        if semi_major_axis_m <= 0:
            raise ValueError(
                f"Semi-major axis must be positive, got {semi_major_axis_m}",
            )
        if eccentricity < 0 or eccentricity >= 1:
            msg = (
                f"Eccentricity must be in [0, 1) for elliptical orbits, "
                f"got {eccentricity}"
            )
            raise ValueError(msg)

        self._elements = OrbitalElements(
            semi_major_axis_m=semi_major_axis_m,
            eccentricity=eccentricity,
            inclination_rad=inclination_rad,
            raan_rad=raan_rad,
            arg_periapsis_rad=arg_periapsis_rad,
            mean_anomaly_rad=mean_anomaly_rad,
            epoch_unix_s=epoch.secs,
        )

    @classmethod
    def from_elements(
        cls,
        elements: OrbitalElements,
        epoch: Time,
    ) -> KeplerianTrajectory:
        """Create a trajectory from an existing OrbitalElements object.

        This is useful when you already have orbital elements from
        gri-utils or parsed from another source.

        Args:
            elements: OrbitalElements NamedTuple from gri-utils.
            epoch: Reference time for the mean anomaly (overrides
                elements.epoch_unix_s).

        Returns:
            KeplerianTrajectory with the given elements.

        Example:
            >>> from gri_utils.orbit import OrbitalElements
            >>> from gri_nsepoch import Time
            >>> elements = OrbitalElements(
            ...     semi_major_axis_m=7_000_000,
            ...     eccentricity=0.001,
            ...     inclination_rad=0.9,
            ...     raan_rad=0.0,
            ...     arg_periapsis_rad=0.0,
            ...     mean_anomaly_rad=0.0,
            ...     epoch_unix_s=0.0,  # Will be overridden by epoch
            ... )
            >>> traj = KeplerianTrajectory.from_elements(elements, Time())
        """
        return cls(
            semi_major_axis_m=elements.semi_major_axis_m,
            eccentricity=elements.eccentricity,
            inclination_rad=elements.inclination_rad,
            raan_rad=elements.raan_rad,
            arg_periapsis_rad=elements.arg_periapsis_rad,
            mean_anomaly_rad=elements.mean_anomaly_rad,
            epoch=epoch,
        )

    @classmethod
    def from_tle(cls, line1: str, line2: str) -> KeplerianTrajectory:
        """Create a Keplerian trajectory from TLE data.

        Parses Two-Line Element data and extracts orbital elements.
        Note that this uses simple Keplerian propagation, which does
        not account for drag or perturbations encoded in the TLE.
        For higher fidelity, use Sgp4Trajectory instead.

        Args:
            line1: First line of TLE data.
            line2: Second line of TLE data.

        Returns:
            KeplerianTrajectory with elements extracted from TLE.

        Raises:
            ValueError: If TLE data is invalid or cannot be parsed.

        Example:
            >>> tle1 = "1 25544U 98067A   24001.50000000 ..."
            >>> tle2 = "2 25544  51.6400  10.5000 ..."
            >>> traj = KeplerianTrajectory.from_tle(tle1, tle2)
        """
        elements = from_tle(line1, line2)

        # Create a Time object from the epoch
        epoch = Time(s=elements.epoch_unix_s)

        return cls(
            semi_major_axis_m=elements.semi_major_axis_m,
            eccentricity=elements.eccentricity,
            inclination_rad=elements.inclination_rad,
            raan_rad=elements.raan_rad,
            arg_periapsis_rad=elements.arg_periapsis_rad,
            mean_anomaly_rad=elements.mean_anomaly_rad,
            epoch=epoch,
        )

    @property
    def elements(self) -> OrbitalElements:
        """The orbital elements defining this trajectory."""
        return self._elements

    def position_at(self, time: Time) -> Pos:
        """Get satellite position at a specific time.

        Args:
            time: Time instant for position query.

        Returns:
            Pos object with satellite position in ECEF frame.
        """
        return self.state_at(time)[0]

    def velocity_at(self, time: Time) -> NDArray[np.floating]:
        """Get satellite velocity at a specific time.

        Args:
            time: Time instant for velocity query.

        Returns:
            Velocity vector [vx, vy, vz] in ECEF frame, meters per second.
        """
        return self.state_at(time)[1]

    def state_at(self, time: Time) -> tuple[Pos, NDArray[np.floating]]:
        """Get both position and velocity at a specific time.

        More efficient than calling position_at and velocity_at separately
        as it only performs one orbit propagation.

        Args:
            time: Time instant for state query.

        Returns:
            Tuple of (position, velocity) where position is a Pos object
            in ECEF frame and velocity is [vx, vy, vz] in ECEF m/s.
        """
        unix_s = time.secs

        # Propagate orbit in ECI frame (scalar time returns single OrbitState)
        state = elements_to_state(self._elements, unix_s)
        if not isinstance(state, OrbitState):
            raise TypeError("Expected single OrbitState from scalar time input")

        # Convert ECI to ECEF
        pos_ecef = eci_to_ecef(state.position_eci_m, unix_s)
        vel_ecef = eci_to_ecef_vel(
            state.position_eci_m,
            state.velocity_eci_ms,
            unix_s,
        )

        return Pos.XYZ(pos_ecef), np.asarray(vel_ecef, dtype=np.float64)

    def __repr__(self) -> str:
        """Return string representation."""
        e = self._elements
        return (
            f"KeplerianTrajectory(a={e.semi_major_axis_m:.0f}m, "
            f"e={e.eccentricity:.6f}, i={np.degrees(e.inclination_rad):.2f} deg)"
        )
