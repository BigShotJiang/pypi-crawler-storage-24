"""Trajectory protocol for platform motion.

A Trajectory defines how a platform moves through space over time. It provides
position and velocity at any given time instant, allowing the simulation to
query platform state during observation generation.

Implementations include:
- StationaryTrajectory: Fixed position, zero velocity
- KeplerianTrajectory: Two-body orbital mechanics (gri-utils)
- Sgp4Trajectory: SGP4/SDP4 TLE propagation (python-sgp4)
- WaypointTrajectory: Interpolated path through waypoints
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    import numpy as np
    from gri_nsepoch import Time
    from gri_pos import Pos
    from numpy.typing import NDArray


@runtime_checkable
class Trajectory(Protocol):
    """Protocol for platform motion trajectories.

    A Trajectory provides the position and velocity of a platform at any given
    time. Implementations handle the specifics of different motion models
    (stationary, orbital, waypoint-based, etc.).

    All positions are returned as Pos objects (ECEF frame).
    All velocities are returned as numpy arrays in ECEF frame (m/s).

    Example:
        >>> class MyTrajectory:
        ...     def position_at(self, time: Time) -> Pos: ...
        ...     def velocity_at(self, time: Time) -> NDArray: ...
        ...     def state_at(self, time: Time) -> tuple[Pos, NDArray]: ...
        >>>
        >>> # Check protocol conformance
        >>> isinstance(MyTrajectory(), Trajectory)
        True
    """

    def position_at(self, time: Time) -> Pos:
        """Get platform position at a specific time.

        Args:
            time: Time instant for position query.

        Returns:
            Pos object with platform position in ECEF frame.
        """
        ...

    def velocity_at(self, time: Time) -> NDArray[np.floating]:
        """Get platform velocity at a specific time.

        Args:
            time: Time instant for velocity query.

        Returns:
            Velocity vector [vx, vy, vz] in ECEF frame, meters per second.
            Shape: (3,)
        """
        ...

    def state_at(self, time: Time) -> tuple[Pos, NDArray[np.floating]]:
        """Get both position and velocity at a specific time.

        This method may be more efficient than calling position_at and
        velocity_at separately, as some trajectories can compute both
        in a single operation.

        Args:
            time: Time instant for state query.

        Returns:
            Tuple of (position, velocity) where:
            - position: Pos object in ECEF frame
            - velocity: numpy array [vx, vy, vz] in ECEF m/s, shape (3,)
        """
        ...
