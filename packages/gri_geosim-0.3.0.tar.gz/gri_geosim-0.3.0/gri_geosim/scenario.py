"""Scenario class for simulation orchestration.

A Scenario is the main entry point for running geolocation simulations.
It manages platforms, emitters, and the simulation execution to generate
observations.

The Scenario coordinates:
- Platforms with attached sensors
- Emitters (targets) to observe
- Time stepping through the simulation
- Collection of all generated observations
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from gri_nsepoch import Delta, Time

if TYPE_CHECKING:
    from .atmosphere import AtmosphereConfig
    from .emitter import Emitter
    from .observations import Observation
    from .platform import Platform


class Scenario:
    """Simulation orchestrator managing platforms, emitters, and execution.

    A Scenario defines the simulation parameters and entities, then
    generates observations by stepping through time and querying all
    sensor/emitter combinations.

    Attributes:
        start_time: Start time of the simulation.
        end_time: End time of the simulation.
        time_step: Time step between observations.
        platforms: List of platforms in the simulation.
        emitters: List of emitters (targets) in the simulation.

    Example:
        >>> from gri_geosim import Scenario, Platform, Emitter
        >>> from gri_geosim.sensors import AoaSensor
        >>> from gri_pos import Pos
        >>> from gri_nsepoch import Time, Delta
        >>>
        >>> # Create scenario
        >>> scenario = Scenario(
        ...     start_time=Time.from_str("2024-01-01T00:00:00Z"),
        ...     end_time=Time.from_str("2024-01-01T01:00:00Z"),
        ...     time_step=Delta(s=60.0),
        ... )
        >>>
        >>> # Add platform with sensor
        >>> ground = Platform.stationary(Pos.LLA(38.0, -77.0, 100.0), name="GND")
        >>> ground.add_sensor(AoaSensor("aoa", azimuth_std_rad=0.001))
        >>> scenario.add_platform(ground)
        >>>
        >>> # Add emitter
        >>> target = Emitter(position=Pos.LLA(39.0, -76.0, 0.0), name="TARGET")
        >>> scenario.add_emitter(target)
        >>>
        >>> # Run simulation
        >>> result = scenario.simulate()
    """

    __slots__ = (
        "_atmosphere",
        "_emitters",
        "_end_time",
        "_platforms",
        "_start_time",
        "_time_step",
    )

    def __init__(
        self,
        start_time: Time,
        end_time: Time,
        *,
        time_step: Delta | None = None,
        atmosphere: AtmosphereConfig | None = None,
    ) -> None:
        """Initialize a Scenario.

        Args:
            start_time: Start time of the simulation.
            end_time: End time of the simulation.
            time_step: Time step between observations. Defaults to 1 second.
            atmosphere: Default atmospheric configuration for the scenario.
                Can be overridden in simulate() or simulate_at() calls.

        Raises:
            ValueError: If end_time is before start_time.
        """
        if end_time <= start_time:
            raise ValueError(
                f"end_time ({end_time}) must be after start_time ({start_time})",
            )

        self._start_time = start_time
        self._end_time = end_time

        # Default time step to 1 second
        if time_step is None:
            time_step = Delta(s=1.0)
        self._time_step = time_step

        self._atmosphere = atmosphere
        self._platforms: list[Platform] = []
        self._emitters: list[Emitter] = []

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def start_time(self) -> Time:
        """Start time of the simulation."""
        return self._start_time

    @property
    def end_time(self) -> Time:
        """End time of the simulation."""
        return self._end_time

    @property
    def time_step(self) -> Delta:
        """Time step between observations."""
        return self._time_step

    @property
    def platforms(self) -> list[Platform]:
        """List of platforms in the simulation."""
        return list(self._platforms)

    @property
    def emitters(self) -> list[Emitter]:
        """List of emitters in the simulation."""
        return list(self._emitters)

    @property
    def atmosphere(self) -> AtmosphereConfig | None:
        """Default atmospheric configuration for the scenario."""
        return self._atmosphere

    @atmosphere.setter
    def atmosphere(self, config: AtmosphereConfig | None) -> None:
        """Set the default atmospheric configuration."""
        self._atmosphere = config

    # =========================================================================
    # Entity management
    # =========================================================================

    def add_platform(self, platform: Platform) -> None:
        """Add a platform to the scenario.

        Args:
            platform: Platform to add.
        """
        self._platforms.append(platform)

    def add_emitter(self, emitter: Emitter) -> None:
        """Add an emitter to the scenario.

        Args:
            emitter: Emitter to add.
        """
        self._emitters.append(emitter)

    def add_platforms(self, platforms: list[Platform]) -> None:
        """Add multiple platforms to the scenario.

        Args:
            platforms: List of platforms to add.
        """
        self._platforms.extend(platforms)

    def add_emitters(self, emitters: list[Emitter]) -> None:
        """Add multiple emitters to the scenario.

        Args:
            emitters: List of emitters to add.
        """
        self._emitters.extend(emitters)

    # =========================================================================
    # Factory methods
    # =========================================================================

    @classmethod
    def for_instant(
        cls,
        platforms: list[Platform] | None = None,
        emitters: list[Emitter] | None = None,
        atmosphere: AtmosphereConfig | None = None,
    ) -> Scenario:
        """Create a scenario configured for single-instant simulations.

        This factory creates a minimal Scenario intended for use with
        simulate_at(). The start_time and end_time are set to placeholder
        values and should not be used with simulate().

        Args:
            platforms: Optional list of platforms to add.
            emitters: Optional list of emitters to add.
            atmosphere: Optional default atmospheric configuration.

        Returns:
            Scenario configured for single-instant use.

        Example:
            >>> scenario = Scenario.for_instant(
            ...     platforms=[ground1, ground2, ground3],
            ...     emitters=[target],
            ... )
            >>> result = scenario.simulate_at(observation_time)
        """
        # Use placeholder times - simulate_at() ignores these
        placeholder = Time.from_str("2000-01-01T00:00:00Z")
        scenario = cls(
            start_time=placeholder,
            end_time=placeholder + Delta(s=1.0),
            atmosphere=atmosphere,
        )

        if platforms:
            scenario.add_platforms(platforms)
        if emitters:
            scenario.add_emitters(emitters)

        return scenario

    # =========================================================================
    # Simulation execution
    # =========================================================================

    def simulate(
        self,
        *,
        add_noise: bool = True,
        atmosphere: AtmosphereConfig | None = None,
    ) -> list[Observation]:
        """Run the simulation and generate observations.

        Steps through time from start_time to end_time at the specified
        time_step, generating observations for all sensor/emitter combinations.

        Args:
            add_noise: If True, add measurement noise to observations.
                If False, return ideal (noise-free) measurements.
            atmosphere: Atmospheric configuration for path delay corrections.
                If None, uses the scenario's default atmosphere (if set).
                Pass an explicit config to override the scenario default.

        Returns:
            List of all generated observations.

        Raises:
            ValueError: If no platforms or emitters are configured.

        Example:
            >>> from gri_geosim.atmosphere import AtmosphereConfig
            >>> # Run with atmospheric effects
            >>> config = AtmosphereConfig(enable_tropo=True, enable_iono=True)
            >>> result = scenario.simulate(atmosphere=config)
        """
        # Use scenario default if no override provided
        effective_atmosphere = (
            atmosphere if atmosphere is not None else self._atmosphere
        )

        if not self._platforms:
            msg = "No platforms configured. Add platforms with add_platform()."
            raise ValueError(msg)
        if not self._emitters:
            msg = "No emitters configured. Add emitters with add_emitter()."
            raise ValueError(msg)

        observations: list[Observation] = []

        # Step through time
        current_time = self._start_time
        while current_time <= self._end_time:
            # For each platform
            for platform in self._platforms:
                # For each sensor on the platform
                for sensor in platform.sensors:
                    # For each emitter
                    for emitter in self._emitters:
                        # Try to generate an observation
                        obs = sensor.observe(
                            emitter,
                            current_time,
                            add_noise=add_noise,
                            atmosphere=effective_atmosphere,
                        )
                        if obs is not None:
                            observations.append(obs)

            # Advance time
            current_time = current_time + self._time_step

        return observations

    def simulate_at(
        self,
        time: Time,
        *,
        add_noise: bool = True,
        atmosphere: AtmosphereConfig | None = None,
    ) -> list[Observation]:
        """Generate observations at a single time instant.

        This is useful for single-snapshot scenarios where multiple platforms
        observe one or more emitters at the same instant, generating a set of
        simultaneous observations (e.g., TDOAs across multiple collector pairs).

        Unlike simulate(), this method ignores start_time, end_time, and time_step,
        generating observations only at the specified time.

        Args:
            time: Time instant for observation generation.
            add_noise: If True, add measurement noise to observations.
                If False, return ideal (noise-free) measurements.
            atmosphere: Atmospheric configuration for path delay corrections.
                If None, uses the scenario's default atmosphere (if set).
                Pass an explicit config to override the scenario default.

        Returns:
            List of all observations at the specified time.

        Raises:
            ValueError: If no platforms or emitters are configured.

        Example:
            >>> from gri_nsepoch import Time
            >>> from gri_geosim.atmosphere import AtmosphereConfig
            >>> # Configure scenario with platforms and emitters
            >>> scenario = Scenario.for_instant(platforms=[g1, g2], emitters=[target])
            >>> # Generate single-instant observations with atmosphere
            >>> config = AtmosphereConfig(enable_tropo=True, enable_iono=True)
            >>> result = scenario.simulate_at(
            ...     Time.from_str("2024-01-01T12:00:00Z"),
            ...     atmosphere=config,
            ... )
        """
        # Use scenario default if no override provided
        effective_atmosphere = (
            atmosphere if atmosphere is not None else self._atmosphere
        )

        if not self._platforms:
            msg = "No platforms configured. Add platforms with add_platform()."
            raise ValueError(msg)
        if not self._emitters:
            msg = "No emitters configured. Add emitters with add_emitter()."
            raise ValueError(msg)

        observations: list[Observation] = []

        # For each platform
        for platform in self._platforms:
            # For each sensor on the platform
            for sensor in platform.sensors:
                # For each emitter
                for emitter in self._emitters:
                    # Try to generate an observation
                    obs = sensor.observe(
                        emitter,
                        time,
                        add_noise=add_noise,
                        atmosphere=effective_atmosphere,
                    )
                    if obs is not None:
                        observations.append(obs)

        return observations

    # =========================================================================
    # Dunder methods
    # =========================================================================

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"Scenario(platforms={len(self._platforms)}, "
            f"emitters={len(self._emitters)}, "
            f"time_step={self._time_step})"
        )

    def __str__(self) -> str:
        """Return human-readable string."""
        platform_count = len(self._platforms)
        sensor_count = sum(len(p.sensors) for p in self._platforms)
        emitter_count = len(self._emitters)
        return (
            f"Scenario: {platform_count} platform(s), {sensor_count} sensor(s), "
            f"{emitter_count} emitter(s)"
        )
