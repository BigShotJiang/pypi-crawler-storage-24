"""NoFov constraint - no field of view restriction.

Use this when the sensor has no geometric constraints and can
observe emitters at any angle.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gri_pos import Pos


class NoFov:
    """No field of view constraint - always visible.

    Use this when the sensor has no geometric constraints and can
    observe emitters at any angle.

    Example:
        >>> from gri_pos import Pos
        >>> fov = NoFov()
        >>> sensor = Pos.LLA(38.0, -77.0, 100.0)
        >>> emitter = Pos.LLA(39.0, -76.0, 0.0)
        >>> fov.is_visible(sensor, emitter)
        True
    """

    __slots__ = ()

    def is_visible(self, sensor_pos: Pos, emitter_pos: Pos) -> bool:  # noqa: ARG002
        """Check visibility - always returns True.

        Args:
            sensor_pos: Sensor position (unused).
            emitter_pos: Emitter position (unused).

        Returns:
            Always True.
        """
        return True

    def __repr__(self) -> str:
        """Return string representation."""
        return "NoFov()"

    def __str__(self) -> str:
        """Return human-readable string."""
        return "No FOV constraint"

    def __eq__(self, other: object) -> bool:
        """Check equality with another NoFov."""
        if not isinstance(other, NoFov):
            return NotImplemented
        return True

    def __hash__(self) -> int:
        """Return hash value."""
        return hash(type(self))
