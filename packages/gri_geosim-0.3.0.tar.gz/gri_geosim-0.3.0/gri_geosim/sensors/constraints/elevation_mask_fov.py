"""ElevationMaskFov constraint - elevation angle from local horizon.

Models elevation angle constraints from the local horizon. Automatically
detects which position is near Earth's surface and computes elevation
from that point's perspective.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import numpy as np
from gri_utils.constants import ER_M, PR_M
from gri_utils.conversion import get_aer

if TYPE_CHECKING:
    from gri_pos import Pos

# Surface radius bounds for elevation mask validation
# Allow 100m tolerance beyond WGS84 ellipsoid extremes
_MIN_SURFACE_RADIUS_M = PR_M - 100.0  # Polar radius - 100m
_MAX_SURFACE_RADIUS_M = ER_M + 100.0  # Equatorial radius + 100m


class ElevationMaskFov:
    """Elevation mask field of view constraint.

    Models elevation angle constraints from the local horizon. Automatically
    detects which position is near Earth's surface and computes elevation
    from that point's perspective.

    This works for:
    - Ground station looking at satellite: elevation from ground to sat
    - Satellite looking at ground emitter: elevation from ground to sat
    - Ground station looking at aircraft: elevation from ground to aircraft

    The elevation is always computed from the lower point's (near-surface)
    perspective, which is the natural "horizon" reference.

    Common uses:
    - Ground stations with horizon obstructions (min_elev > 0)
    - Satellite sensors requiring targets above limb (min_elev > 0)
    - Sensors avoiding zenith region (max_elev < 90)
    - Atmospheric refraction allowance (min_elev < 0)

    Attributes:
        min_elev_rad: Minimum elevation angle in radians.
        max_elev_rad: Maximum elevation angle in radians.

    Example:
        >>> from gri_pos import Pos
        >>> # Ground station can only see above 10 deg elevation
        >>> fov = ElevationMaskFov(min_elev_deg=10.0)
        >>> ground = Pos.LLA(38.0, -77.0, 100.0)
        >>> sat = Pos.LLA(38.1, -77.0, 400_000.0)
        >>> fov.is_visible(ground, sat)  # Checks elevation from ground
        True

        >>> # Satellite sensor - same check, elevation from ground perspective
        >>> fov_sat = ElevationMaskFov(min_elev_deg=2.0)
        >>> fov_sat.is_visible(sat, ground)  # Still checks from ground's view
        True
    """

    __slots__ = ("_max_elev_rad", "_min_elev_rad")

    def __init__(
        self,
        min_elev_deg: float = 0.0,
        max_elev_deg: float = 90.0,
    ) -> None:
        """Initialize elevation mask FOV.

        Args:
            min_elev_deg: Minimum elevation angle in degrees (-90 to 90).
                Default is 0 deg (horizon). Negative values allow for
                atmospheric refraction effects.
            max_elev_deg: Maximum elevation angle in degrees (-90 to 90).
                Default is 90 deg (zenith).

        Raises:
            ValueError: If angles are out of range or min >= max.
        """
        if min_elev_deg < -90 or min_elev_deg > 90:  # noqa: PLR2004
            raise ValueError(
                f"Minimum elevation must be in [-90, 90] degrees, got {min_elev_deg}",
            )
        if max_elev_deg < -90 or max_elev_deg > 90:  # noqa: PLR2004
            raise ValueError(
                f"Maximum elevation must be in [-90, 90] degrees, got {max_elev_deg}",
            )
        if min_elev_deg >= max_elev_deg:
            raise ValueError(
                f"Minimum elevation ({min_elev_deg} deg) must be less than "
                f"maximum elevation ({max_elev_deg} deg)",
            )

        self._min_elev_rad = math.radians(min_elev_deg)
        self._max_elev_rad = math.radians(max_elev_deg)

    @property
    def min_elev_rad(self) -> float:
        """Minimum elevation angle in radians."""
        return self._min_elev_rad

    @property
    def max_elev_rad(self) -> float:
        """Maximum elevation angle in radians."""
        return self._max_elev_rad

    @property
    def min_elev_deg(self) -> float:
        """Minimum elevation angle in degrees."""
        return math.degrees(self._min_elev_rad)

    @property
    def max_elev_deg(self) -> float:
        """Maximum elevation angle in degrees."""
        return math.degrees(self._max_elev_rad)

    def is_visible(self, sensor_pos: Pos, emitter_pos: Pos) -> bool:
        """Check if emitter is within elevation constraints.

        Automatically determines which position is near Earth's surface
        and computes elevation from that point's local horizon.

        Args:
            sensor_pos: Sensor position in ECEF frame.
            emitter_pos: Emitter position in ECEF frame.

        Returns:
            True if elevation angle is within [min_elev, max_elev].

        Raises:
            ValueError: If neither position is near Earth's surface.
                Use EarthOcclusionFov for space-to-space visibility.
        """
        sensor_xyz = sensor_pos.xyz
        emitter_xyz = emitter_pos.xyz

        # Compute radii to determine which is the ground reference
        sensor_radius = float(np.linalg.norm(sensor_xyz))
        emitter_radius = float(np.linalg.norm(emitter_xyz))

        # Use the lower point as the ground reference
        if sensor_radius <= emitter_radius:
            ground_xyz = sensor_xyz
            ground_radius = sensor_radius
            other_xyz = emitter_xyz
        else:
            ground_xyz = emitter_xyz
            ground_radius = emitter_radius
            other_xyz = sensor_xyz

        # Validate that the ground point is actually near Earth's surface
        if not (_MIN_SURFACE_RADIUS_M <= ground_radius <= _MAX_SURFACE_RADIUS_M):
            raise ValueError(
                f"Neither position is near Earth's surface "
                f"(radius {ground_radius:.0f} m not in "
                f"[{_MIN_SURFACE_RADIUS_M:.0f}, {_MAX_SURFACE_RADIUS_M:.0f}] m). "
                f"Use EarthOcclusionFov for space-to-space visibility checks.",
            )

        # Compute elevation from ground point to the other point
        aer = get_aer(ground_xyz, other_xyz)
        elev_rad = math.radians(aer[1])

        return self._min_elev_rad <= elev_rad <= self._max_elev_rad

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"ElevationMaskFov(min_elev_deg={self.min_elev_deg:.1f}, "
            f"max_elev_deg={self.max_elev_deg:.1f})"
        )

    def __str__(self) -> str:
        """Return human-readable string."""
        return f"Elevation mask: {self.min_elev_deg:.1f} to {self.max_elev_deg:.1f} deg"
