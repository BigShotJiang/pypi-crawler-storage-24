"""FovConstraint protocol for sensor visibility.

FOV constraints determine whether a sensor can observe an emitter based
on geometric relationships. All FOV classes implement this protocol.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from gri_pos import Pos


@runtime_checkable
class FovConstraint(Protocol):
    """Protocol for field-of-view constraints.

    FOV constraints determine whether an emitter is visible to a sensor
    based on geometric relationships between their positions.

    Implementations should be lightweight and fast, as visibility checks
    are performed frequently during simulations.

    Example:
        >>> class MyFov:
        ...     def is_visible(self, sensor_pos: Pos, emitter_pos: Pos) -> bool:
        ...         # Custom visibility logic
        ...         return True
        >>> fov = MyFov()
        >>> isinstance(fov, FovConstraint)
        True
    """

    def is_visible(self, sensor_pos: Pos, emitter_pos: Pos) -> bool:
        """Check if the emitter is visible from the sensor position.

        Args:
            sensor_pos: Sensor position in ECEF frame.
            emitter_pos: Emitter position in ECEF frame.

        Returns:
            True if emitter is within the sensor's field of view.
        """
        ...
