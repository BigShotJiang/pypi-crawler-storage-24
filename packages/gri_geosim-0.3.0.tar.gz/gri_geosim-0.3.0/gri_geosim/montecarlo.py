"""Monte Carlo simulation support for statistical analysis.

This module provides the MonteCarlo class for running multiple simulation
iterations with varying noise realizations. This is useful for:

- Generating test data for geolocation algorithms
- Statistical analysis of observation uncertainty
- Performance characterization of sensor configurations
- Sensitivity studies with parameter variations

The MonteCarlo class wraps a Scenario and provides methods for running
N iterations, collecting results, and computing statistics.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .montecarlo_result import MonteCarloResult

if TYPE_CHECKING:
    from collections.abc import Callable

    from gri_nsepoch import Time

    from .atmosphere import AtmosphereConfig
    from .observations import Observation
    from .scenario import Scenario


class MonteCarlo:
    """Monte Carlo simulation wrapper for running multiple iterations.

    Wraps a Scenario to run N iterations with different noise realizations,
    collecting results for statistical analysis.

    The MonteCarlo class supports:
    - Time-series simulations via run()
    - Single-instant simulations via run_at()
    - Custom parameter variation via callbacks

    Attributes:
        scenario: The underlying Scenario to simulate.
        n_iterations: Default number of iterations.

    Example:
        >>> from gri_geosim import Scenario, MonteCarlo, AtmosphereConfig
        >>> from gri_nsepoch import Time
        >>>
        >>> # Set up scenario with platforms and emitters
        >>> scenario = Scenario.for_instant(platforms=[p1, p2], emitters=[e1])
        >>>
        >>> # Run Monte Carlo at a single instant
        >>> mc = MonteCarlo(scenario, n_iterations=1000)
        >>> result = mc.run_at(Time.from_str("2024-01-01T12:00:00Z"))
        >>>
        >>> # Analyze results
        >>> stats = result.compute_statistics(obs_type="TDOA")
        >>> print(f"TDOA mean: {stats['mean']}, std: {stats['std']}")
    """

    __slots__ = ("_n_iterations", "_scenario")

    def __init__(
        self,
        scenario: Scenario,
        n_iterations: int = 100,
    ) -> None:
        """Initialize Monte Carlo simulation.

        Args:
            scenario: The Scenario to run multiple times.
            n_iterations: Default number of iterations. Can be overridden
                in run() and run_at() methods.

        Raises:
            ValueError: If n_iterations is not positive.
        """
        if n_iterations <= 0:
            raise ValueError(f"n_iterations must be positive, got {n_iterations}")

        self._scenario = scenario
        self._n_iterations = n_iterations

    @property
    def scenario(self) -> Scenario:
        """The underlying Scenario."""
        return self._scenario

    @property
    def n_iterations(self) -> int:
        """Default number of iterations."""
        return self._n_iterations

    def run(
        self,
        n_iterations: int | None = None,
        *,
        atmosphere: AtmosphereConfig | None = None,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> MonteCarloResult:
        """Run Monte Carlo simulation over the scenario's time range.

        Runs the scenario's simulate() method N times, each with different
        noise realizations.

        Args:
            n_iterations: Number of iterations. Uses default if None.
            atmosphere: Optional atmospheric configuration.
            progress_callback: Optional callback(current, total) for progress.

        Returns:
            MonteCarloResult containing all iteration results.

        Example:
            >>> result = mc.run(n_iterations=500)
            >>> print(f"Ran {result.n_iterations} iterations")
        """
        n = n_iterations if n_iterations is not None else self._n_iterations
        results: list[list[Observation]] = []

        for i in range(n):
            if progress_callback is not None:
                progress_callback(i, n)

            result = self._scenario.simulate(add_noise=True, atmosphere=atmosphere)
            results.append(result)

        if progress_callback is not None:
            progress_callback(n, n)

        return MonteCarloResult(results)

    def run_at(
        self,
        time: Time,
        n_iterations: int | None = None,
        *,
        atmosphere: AtmosphereConfig | None = None,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> MonteCarloResult:
        """Run Monte Carlo simulation at a single time instant.

        Runs the scenario's simulate_at() method N times at the same instant,
        each with different noise realizations. This is useful for analyzing
        the statistical distribution of observations at a specific geometry.

        Args:
            time: Time instant for all iterations.
            n_iterations: Number of iterations. Uses default if None.
            atmosphere: Optional atmospheric configuration.
            progress_callback: Optional callback(current, total) for progress.

        Returns:
            MonteCarloResult containing all iteration results.

        Example:
            >>> from gri_nsepoch import Time
            >>> t = Time.from_str("2024-01-01T12:00:00Z")
            >>> result = mc.run_at(t, n_iterations=1000)
            >>> stats = result.compute_statistics()
        """
        n = n_iterations if n_iterations is not None else self._n_iterations
        results: list[list[Observation]] = []

        for i in range(n):
            if progress_callback is not None:
                progress_callback(i, n)

            result = self._scenario.simulate_at(
                time,
                add_noise=True,
                atmosphere=atmosphere,
            )
            results.append(result)

        if progress_callback is not None:
            progress_callback(n, n)

        return MonteCarloResult(results)

    def run_ideal(
        self,
        *,
        atmosphere: AtmosphereConfig | None = None,
    ) -> list[Observation]:
        """Run a single noise-free simulation.

        Useful for getting the "true" observation values to compare
        against noisy Monte Carlo results.

        Args:
            atmosphere: Optional atmospheric configuration.

        Returns:
            List of noise-free observations.
        """
        return self._scenario.simulate(add_noise=False, atmosphere=atmosphere)

    def run_ideal_at(
        self,
        time: Time,
        *,
        atmosphere: AtmosphereConfig | None = None,
    ) -> list[Observation]:
        """Run a single noise-free simulation at a specific time.

        Useful for getting the "true" observation values to compare
        against noisy Monte Carlo results.

        Args:
            time: Time instant for observation generation.
            atmosphere: Optional atmospheric configuration.

        Returns:
            List of noise-free observations.
        """
        return self._scenario.simulate_at(time, add_noise=False, atmosphere=atmosphere)

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"MonteCarlo(scenario={self._scenario!r}, "
            f"n_iterations={self._n_iterations})"
        )

    def __str__(self) -> str:
        """Return human-readable string."""
        return f"MonteCarlo simulation ({self._n_iterations} iterations)"
