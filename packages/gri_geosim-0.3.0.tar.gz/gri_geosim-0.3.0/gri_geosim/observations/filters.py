"""Standalone filter functions for observation lists.

These functions filter lists of mixed observation types into type-safe
sublists.

Example:
    >>> from gri_geosim import filter_tdoa, filter_aoa
    >>> tdoa_obs = filter_tdoa(all_observations)
    >>> aoa_obs = filter_aoa(all_observations)
"""

from __future__ import annotations

from .aoa import AoaObservation
from .fdoa import FdoaObservation
from .tdoa import TdoaObservation

type Observation = TdoaObservation | AoaObservation | FdoaObservation


def filter_aoa(observations: list[Observation]) -> list[AoaObservation]:
    """Filter and return only AOA observations.

    Args:
        observations: List of mixed observation types.

    Returns:
        List of AOA observations with correct type.
    """
    return [obs for obs in observations if isinstance(obs, AoaObservation)]


def filter_tdoa(observations: list[Observation]) -> list[TdoaObservation]:
    """Filter and return only TDOA observations.

    Args:
        observations: List of mixed observation types.

    Returns:
        List of TDOA observations with correct type.
    """
    return [obs for obs in observations if isinstance(obs, TdoaObservation)]


def filter_fdoa(observations: list[Observation]) -> list[FdoaObservation]:
    """Filter and return only FDOA observations.

    Args:
        observations: List of mixed observation types.

    Returns:
        List of FDOA observations with correct type.
    """
    return [obs for obs in observations if isinstance(obs, FdoaObservation)]


def filter_by_sensor(
    observations: list[Observation],
    sensor_id: str,
) -> list[Observation]:
    """Filter observations by sensor ID.

    Args:
        observations: List of mixed observation types.
        sensor_id: ID of the sensor.

    Returns:
        List of observations from the specified sensor.
    """
    return [obs for obs in observations if obs.sensor_id == sensor_id]


def filter_by_emitter(
    observations: list[Observation],
    emitter_id: str,
) -> list[Observation]:
    """Filter observations by emitter ID.

    Args:
        observations: List of mixed observation types.
        emitter_id: ID of the emitter.

    Returns:
        List of observations of the specified emitter.
    """
    return [obs for obs in observations if obs.emitter_id == emitter_id]
