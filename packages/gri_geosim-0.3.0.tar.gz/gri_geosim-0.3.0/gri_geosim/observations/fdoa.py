"""Frequency Difference of Arrival observation."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import Pos

if TYPE_CHECKING:
    from gri_nsepoch import Time
    from numpy.typing import NDArray


class FdoaObservation:
    """Frequency Difference of Arrival observation.

    An FDOA observation measures the difference in Doppler shift between two
    collectors. The measurement is a scalar in Hz.

    Attributes:
        time: Timestamp of the observation.
        value: FDOA measurement in Hz.
        std_dev: Standard deviation of measurement in Hz.
        collector1: First collector position.
        collector2: Second collector position.
        collector1_vel: First collector velocity in ECEF m/s.
        collector2_vel: Second collector velocity in ECEF m/s.
        frequency_hz: Carrier frequency in Hz.
        sensor_id: ID of the sensor that generated this observation.
        emitter_id: ID of the emitter being observed (if known).

    Example:
        >>> obs = FdoaObservation(
        ...     time=time,
        ...     value=0.5,  # Hz
        ...     std_dev=0.1,  # Hz
        ...     collector1=Pos.LLA(38.0, -77.0, 400_000.0),
        ...     collector2=Pos.LLA(39.0, -76.0, 400_000.0),
        ...     collector1_vel=np.array([0.0, 7500.0, 0.0]),
        ...     collector2_vel=np.array([0.0, 7500.0, 0.0]),
        ...     frequency_hz=1e9,
        ...     sensor_id="fdoa_12",
        ... )
    """

    __slots__ = (
        "_collector1",
        "_collector1_vel",
        "_collector2",
        "_collector2_vel",
        "_emitter_id",
        "_frequency_hz",
        "_sensor_id",
        "_std_dev",
        "_time",
        "_value",
    )

    def __init__(  # noqa: PLR0913
        self,
        time: Time,
        value: float,
        std_dev: float,
        collector1: Pos,
        collector2: Pos,
        collector1_vel: NDArray[np.floating],
        collector2_vel: NDArray[np.floating],
        frequency_hz: float,
        sensor_id: str,
        emitter_id: str | None = None,
    ) -> None:
        """Initialize an FDOA observation.

        Args:
            time: Timestamp of the observation.
            value: FDOA measurement in Hz.
            std_dev: Standard deviation of measurement in Hz.
            collector1: First collector position.
            collector2: Second collector position.
            collector1_vel: First collector velocity in ECEF m/s, shape (3,).
            collector2_vel: Second collector velocity in ECEF m/s, shape (3,).
            frequency_hz: Carrier frequency in Hz.
            sensor_id: ID of the sensor that generated this observation.
            emitter_id: ID of the emitter being observed (if known).

        Raises:
            ValueError: If velocity array shapes are wrong.
        """
        self._time = time
        self._value = float(value)
        self._std_dev = float(std_dev)
        self._frequency_hz = float(frequency_hz)
        self._sensor_id = sensor_id
        self._emitter_id = emitter_id
        self._collector1 = Pos(collector1)
        self._collector2 = Pos(collector2)

        # Convert and validate velocity arrays
        self._collector1_vel = np.asarray(collector1_vel, dtype=np.float64, copy=True)
        self._collector2_vel = np.asarray(collector2_vel, dtype=np.float64, copy=True)

        for name, arr in [
            ("collector1_vel", self._collector1_vel),
            ("collector2_vel", self._collector2_vel),
        ]:
            if arr.shape != (3,):
                raise ValueError(f"{name} shape {arr.shape} != (3,)")

        # Make velocity arrays read-only
        self._collector1_vel.flags.writeable = False
        self._collector2_vel.flags.writeable = False

    @property
    def time(self) -> Time:
        """Timestamp of the observation."""
        return self._time

    @property
    def value(self) -> float:
        """FDOA measurement in Hz."""
        return self._value

    @property
    def std_dev(self) -> float:
        """Standard deviation of measurement in Hz."""
        return self._std_dev

    @property
    def variance(self) -> float:
        """Measurement variance in Hz**2."""
        return self._std_dev**2

    @property
    def obs_type(self) -> str:
        """Observation type identifier."""
        return "FDOA"

    @property
    def collector1(self) -> Pos:
        """First collector position."""
        return self._collector1

    @property
    def collector2(self) -> Pos:
        """Second collector position."""
        return self._collector2

    @property
    def collector1_vel(self) -> NDArray[np.floating]:
        """First collector velocity in ECEF m/s."""
        return self._collector1_vel

    @property
    def collector2_vel(self) -> NDArray[np.floating]:
        """Second collector velocity in ECEF m/s."""
        return self._collector2_vel

    @property
    def frequency_hz(self) -> float:
        """Carrier frequency in Hz."""
        return self._frequency_hz

    @property
    def sensor_id(self) -> str:
        """ID of the sensor that generated this observation."""
        return self._sensor_id

    @property
    def emitter_id(self) -> str | None:
        """ID of the emitter being observed (if known)."""
        return self._emitter_id

    def is_valid(self) -> bool:
        """Check if observation values are valid (finite)."""
        return bool(
            np.isfinite(self._value)
            and np.isfinite(self._std_dev)
            and np.isfinite(self._frequency_hz)
            and np.isfinite(self._collector1.xyz).all()
            and np.isfinite(self._collector2.xyz).all()
            and np.isfinite(self._collector1_vel).all()
            and np.isfinite(self._collector2_vel).all(),
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"FdoaObservation(sensor='{self._sensor_id}', "
            f"time={self._time}, value={self._value:.6g}Hz)"
        )

    def __str__(self) -> str:
        """Return human-readable string with auto-scaled units."""
        time_str = self._time.iso if hasattr(self._time, "iso") else str(self._time)
        # Auto-scale to appropriate frequency unit
        abs_val = abs(self._value)
        if abs_val < 1e3:  # noqa: PLR2004
            scaled = self._value
            unit = "Hz"
        elif abs_val < 1e6:  # noqa: PLR2004
            scaled = self._value / 1e3
            unit = "kHz"
        else:
            scaled = self._value / 1e6
            unit = "MHz"
        return f"FDOA @ {time_str}: {scaled:+.3f} {unit}"

    def __eq__(self, other: object) -> bool:
        """Check equality with another FdoaObservation."""
        if not isinstance(other, FdoaObservation):
            return NotImplemented
        return (
            self._time == other._time
            and self._value == other._value
            and self._std_dev == other._std_dev
            and self._frequency_hz == other._frequency_hz
            and self._sensor_id == other._sensor_id
            and self._emitter_id == other._emitter_id
            and self._collector1 == other._collector1
            and self._collector2 == other._collector2
            and np.array_equal(self._collector1_vel, other._collector1_vel)
            and np.array_equal(self._collector2_vel, other._collector2_vel)
        )

    def __hash__(self) -> int:
        """Return hash value."""
        return hash(
            (
                self._time,
                self._value,
                self._std_dev,
                self._frequency_hz,
                self._sensor_id,
                self._emitter_id,
                self._collector1.xyz.tobytes(),
                self._collector2.xyz.tobytes(),
                self._collector1_vel.tobytes(),
                self._collector2_vel.tobytes(),
            ),
        )
