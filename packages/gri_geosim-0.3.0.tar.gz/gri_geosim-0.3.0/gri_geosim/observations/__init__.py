"""Typed observation classes for geolocation measurements.

Each observation type carries all the collector state needed for geolocation,
making observations self-contained and eliminating the need to pass
platform positions/velocities separately to locators.

Observation Types:
    - TdoaObservation: Time Difference of Arrival
    - AoaObservation: Angle of Arrival
    - FdoaObservation: Frequency Difference of Arrival

The Observation type alias is a union of all observation types, making it
easy to add new observation types in the future.

Example:
    >>> from gri_geosim.observations import TdoaObservation, Observation
    >>> obs: Observation = TdoaObservation(...)
"""

from .aoa import AoaObservation
from .fdoa import FdoaObservation
from .filters import (
    filter_aoa,
    filter_by_emitter,
    filter_by_sensor,
    filter_fdoa,
    filter_tdoa,
)
from .tdoa import TdoaObservation

# Type alias for any observation type - add new types here
Observation = TdoaObservation | AoaObservation | FdoaObservation

__all__ = [
    "AoaObservation",
    "FdoaObservation",
    "Observation",
    "TdoaObservation",
    "filter_aoa",
    "filter_by_emitter",
    "filter_by_sensor",
    "filter_fdoa",
    "filter_tdoa",
]
