"""Angle of Arrival observation using sensor-frame direction cosines."""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Self

import numpy as np
from gri_memoize import MemoizedClass, memoize
from gri_pos import Pos
from gri_utils.conversion import xyz_enu_rotation, xyz_to_enu
from scipy.spatial.transform import Rotation

if TYPE_CHECKING:
    from gri_nsepoch import Time
    from numpy.typing import NDArray


class AoaObservation(MemoizedClass):
    """Angle of Arrival observation using sensor-frame direction cosines.

    An AOA observation measures the direction from collector to emitter as
    direction cosines (u, v) in the sensor's local reference frame. The third
    component w is implicit: w = +/-sqrt(1 - u^2 - v^2), with sign determined
    by z_positive.

    For space-based sensors, the sensor frame is typically nadir-pointing
    (+Z toward Earth). For ground-based sensors, it's typically ENU-aligned.

    Attributes:
        time: Timestamp of the observation.
        u: X component of direction cosine in sensor frame (unitless).
        v: Y component of direction cosine in sensor frame (unitless).
        z_positive: Whether target is in front of sensor boresight (+Z direction).
        covariance: 2x2 covariance matrix in direction cosine space (unitless).
        collector: Collector position.
        collector_rotation: Rotation from ECEF to sensor local frame.
        sensor_id: ID of the sensor that generated this observation.
        emitter_id: ID of the emitter being observed (if known).

    Example:
        >>> obs = AoaObservation(
        ...     time=time,
        ...     u=0.1,  # direction cosine
        ...     v=0.2,  # direction cosine
        ...     covariance=np.array([[1e-6, 0], [0, 1e-6]]),
        ...     collector=Pos.LLA(38.0, -77.0, 100.0),
        ...     collector_rotation=Rotation.identity(),
        ...     sensor_id="aoa_1",
        ... )

        For a simpler interface using azimuth/elevation angles:

        >>> obs = AoaObservation.from_azel(
        ...     time=time,
        ...     azimuth_rad=0.785,  # 45 degrees
        ...     elevation_rad=0.524,  # 30 degrees
        ...     std_dev_az_rad=0.001,
        ...     std_dev_el_rad=0.001,
        ...     collector=Pos.LLA(38.0, -77.0, 100.0),
        ...     sensor_id="aoa_1",
        ... )
    """

    __slots__ = (
        "_collector",
        "_collector_rotation",
        "_covariance",
        "_emitter_id",
        "_sensor_id",
        "_time",
        "_u",
        "_v",
        "_z_positive",
        "memoized_results",  # Required for MemoizedClass with __slots__
    )

    def __init__(  # noqa: PLR0913
        self,
        time: Time,
        u: float,
        v: float,
        covariance: NDArray[np.floating],
        collector: Pos,
        collector_rotation: Rotation,
        sensor_id: str,
        emitter_id: str | None = None,
        *,
        z_positive: bool = True,
    ) -> None:
        """Initialize an AOA observation.

        Args:
            time: Timestamp of the observation.
            u: X component of direction cosine in sensor frame.
            v: Y component of direction cosine in sensor frame.
            covariance: 2x2 covariance matrix in direction cosine space.
            collector: Collector position.
            collector_rotation: Rotation from ECEF to sensor local frame.
            sensor_id: ID of the sensor that generated this observation.
            emitter_id: ID of the emitter being observed (if known).
            z_positive: Whether target is in front of sensor boresight.

        Raises:
            ValueError: If covariance shape is wrong or direction cosines invalid.
        """
        self._time = time
        self._u = float(u)
        self._v = float(v)
        self._z_positive = z_positive
        self._sensor_id = sensor_id
        self._emitter_id = emitter_id
        self._collector_rotation = collector_rotation
        self._collector = Pos(collector)

        # Validate direction cosines (u^2 + v^2 <= 1)
        uv_mag_sq = self._u * self._u + self._v * self._v
        if uv_mag_sq > 1.0 + 1e-10:
            msg = f"Invalid direction cosines: u^2 + v^2 = {uv_mag_sq} > 1"
            raise ValueError(msg)

        # Convert and validate covariance (copy=True ensures independence)
        self._covariance = np.asarray(covariance, dtype=np.float64, copy=True)

        if self._covariance.shape != (2, 2):
            msg = f"covariance shape {self._covariance.shape} != (2, 2)"
            raise ValueError(msg)

        # Make array read-only
        self._covariance.flags.writeable = False

    @classmethod
    def from_azel(  # noqa: PLR0913
        cls,
        time: Time,
        azimuth_rad: float,
        elevation_rad: float,
        std_dev_az_rad: float,
        std_dev_el_rad: float,
        collector: Pos,
        sensor_id: str,
        emitter_id: str | None = None,
    ) -> Self:
        """Create an AOA observation from azimuth/elevation angles.

        Converts azimuth and elevation angles (in ENU frame at the collector
        position) to direction cosines in the ENU sensor frame. The ENU frame
        is used as the sensor orientation.

        This is the recommended way to create AOA observations from user data,
        as it handles the direction cosine and rotation math internally.

        Args:
            time: Timestamp of the observation.
            azimuth_rad: Azimuth angle in radians (bearing from north, clockwise).
            elevation_rad: Elevation angle in radians (above horizon).
            std_dev_az_rad: Standard deviation of azimuth measurement in radians.
            std_dev_el_rad: Standard deviation of elevation measurement in radians.
            collector: Collector position.
            sensor_id: ID of the sensor that generated this observation.
            emitter_id: ID of the emitter being observed (if known).

        Returns:
            AoaObservation with ENU sensor frame orientation.

        Example:
            >>> obs = AoaObservation.from_azel(
            ...     time=time,
            ...     azimuth_rad=0.785,
            ...     elevation_rad=0.524,
            ...     std_dev_az_rad=0.001,
            ...     std_dev_el_rad=0.001,
            ...     collector=Pos.LLA(38.0, -77.0, 100.0),
            ...     sensor_id="aoa_1",
            ... )
        """
        collector = Pos(collector)
        collector_xyz = np.asarray(collector.xyz, dtype=np.float64)

        # Build ENU rotation (ECEF -> ENU)
        enu_rot_matrix = xyz_enu_rotation(collector_xyz)
        collector_rotation = Rotation.from_matrix(enu_rot_matrix)

        # Convert az/el to direction cosines in ENU frame
        # u = cos(el) * sin(az)  (East component)
        # v = cos(el) * cos(az)  (North component)
        # w = sin(el)            (Up component)
        cos_el = math.cos(elevation_rad)
        sin_el = math.sin(elevation_rad)
        sin_az = math.sin(azimuth_rad)
        cos_az = math.cos(azimuth_rad)

        u = cos_el * sin_az
        v = cos_el * cos_az

        # Compute covariance in direction cosine space via Jacobian
        covariance = _azel_to_dc_covariance(
            sin_az,
            cos_az,
            sin_el,
            cos_el,
            std_dev_az_rad,
            std_dev_el_rad,
        )

        return cls(
            time=time,
            u=u,
            v=v,
            covariance=covariance,
            collector=collector,
            collector_rotation=collector_rotation,
            sensor_id=sensor_id,
            emitter_id=emitter_id,
            z_positive=sin_el >= 0,
        )

    # =========================================================================
    # Native properties (direction cosines)
    # =========================================================================

    @property
    def time(self) -> Time:
        """Timestamp of the observation."""
        return self._time

    @property
    def u(self) -> float:
        """X component of direction cosine in sensor frame."""
        return self._u

    @property
    def v(self) -> float:
        """Y component of direction cosine in sensor frame."""
        return self._v

    @property
    def z_positive(self) -> bool:
        """Whether target is in front of sensor boresight (+Z direction)."""
        return self._z_positive

    @property
    def direction_cosines(self) -> NDArray[np.floating]:
        """Direction cosines [u, v] in sensor frame."""
        return np.array([self._u, self._v])

    @property
    def value(self) -> NDArray[np.floating]:
        """Measurement as [u, v] array (direction cosines in sensor frame)."""
        return self.direction_cosines

    @property
    def covariance(self) -> NDArray[np.floating]:
        """2x2 covariance matrix in direction cosine space (unitless)."""
        return self._covariance

    @property
    def std_dev(self) -> NDArray[np.floating]:
        """Standard deviation [u, v] (unitless)."""
        return np.sqrt(np.diag(self._covariance))

    # =========================================================================
    # Derived angular properties
    # =========================================================================

    @memoize
    def _get_enu_unit_vector(self) -> NDArray[np.floating]:
        """Reconstruct unit direction vector in ENU frame at collector.

        Returns:
            Unit vector [East, North, Up] pointing toward emitter.
        """
        # Reconstruct full 3D unit vector in sensor frame
        w_sq = 1.0 - self._u * self._u - self._v * self._v
        w_mag = math.sqrt(max(0.0, w_sq))
        w = w_mag if self._z_positive else -w_mag
        sensor_unit = np.array([self._u, self._v, w])

        # Rotate from sensor frame to ECEF (inverse of sensor rotation)
        ecef_unit = self._collector_rotation.inv().apply(sensor_unit)

        # Convert ECEF direction to ENU at collector position
        collector_xyz = np.asarray(self._collector.xyz, dtype=np.float64)
        return xyz_to_enu(collector_xyz, ecef_unit)

    @property
    def azimuth(self) -> float:
        """Computed azimuth angle in radians (bearing from north, clockwise).

        This reconstructs the azimuth from direction cosines using the sensor
        rotation and ENU frame at the collector position.
        """
        enu_unit = self._get_enu_unit_vector()
        # Azimuth = atan2(East, North), normalized to [0, 2*pi)
        return float(math.atan2(enu_unit[0], enu_unit[1]) % (2.0 * math.pi))

    @property
    def elevation(self) -> float:
        """Computed elevation angle in radians (above horizon).

        This reconstructs the elevation from direction cosines using the sensor
        rotation and ENU frame at the collector position.
        """
        enu_unit = self._get_enu_unit_vector()
        # Elevation = asin(Up component), clamped for numerical safety
        return float(math.asin(np.clip(enu_unit[2], -1.0, 1.0)))

    # =========================================================================
    # Other properties
    # =========================================================================

    @property
    def obs_type(self) -> str:
        """Observation type identifier."""
        return "AOA"

    @property
    def collector(self) -> Pos:
        """Collector position."""
        return self._collector

    @property
    def collector_rotation(self) -> Rotation:
        """Rotation from ECEF to sensor local frame."""
        return self._collector_rotation

    @property
    def sensor_id(self) -> str:
        """ID of the sensor that generated this observation."""
        return self._sensor_id

    @property
    def emitter_id(self) -> str | None:
        """ID of the emitter being observed (if known)."""
        return self._emitter_id

    def is_valid(self) -> bool:
        """Check if observation values are valid (finite and within bounds)."""
        uv_mag_sq = self._u * self._u + self._v * self._v
        return bool(
            np.isfinite(self._u)
            and np.isfinite(self._v)
            and uv_mag_sq <= 1.0 + 1e-10
            and np.isfinite(self._covariance).all()
            and np.isfinite(self._collector.xyz).all(),
        )

    # =========================================================================
    # Dunder methods
    # =========================================================================

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"AoaObservation(sensor='{self._sensor_id}', "
            f"time={self._time}, u={self._u:.4f}, v={self._v:.4f})"
        )

    def __str__(self) -> str:
        """Return human-readable string.

        If azimuth/elevation have been accessed (triggering ENU vector computation),
        displays az/el in degrees. Otherwise displays native u/v direction cosines.
        """
        time_str = self._time.iso if hasattr(self._time, "iso") else str(self._time)
        # If az/el have been computed (enu vector is memoized), show those
        if self.memoized_results:
            az_deg = math.degrees(self.azimuth)
            el_deg = math.degrees(self.elevation)
            return f"AOA @ {time_str}: az={az_deg:.2f} deg, el={el_deg:.2f} deg"
        return f"AOA @ {time_str}: u={self._u:.4f}, v={self._v:.4f}"

    def __eq__(self, other: object) -> bool:
        """Check equality with another AoaObservation."""
        if not isinstance(other, AoaObservation):
            return NotImplemented
        return (
            self._time == other._time
            and self._u == other._u
            and self._v == other._v
            and self._z_positive == other._z_positive
            and self._sensor_id == other._sensor_id
            and self._emitter_id == other._emitter_id
            and np.array_equal(self._covariance, other._covariance)
            and self._collector == other._collector
            and np.array_equal(
                self._collector_rotation.as_quat(),
                other._collector_rotation.as_quat(),
            )
        )

    def __hash__(self) -> int:
        """Return hash value."""
        return hash(
            (
                self._time,
                self._u,
                self._v,
                self._z_positive,
                self._sensor_id,
                self._emitter_id,
                self._covariance.tobytes(),
                self._collector.xyz.tobytes(),
                self._collector_rotation.as_quat().tobytes(),
            ),
        )


def _azel_to_dc_covariance(  # noqa: PLR0913
    sin_az: float,
    cos_az: float,
    sin_el: float,
    cos_el: float,
    std_dev_az_rad: float,
    std_dev_el_rad: float,
) -> NDArray[np.floating]:
    """Transform angular standard deviations to direction cosine covariance.

    Uses the Jacobian of the (az, el) -> (u, v) transformation:
        u = cos(el) * sin(az)
        v = cos(el) * cos(az)

    The Jacobian becomes ill-conditioned near horizontal (el ~ 0) and
    vertical (el ~ +/-90 degrees) elevations. Eigenvalue regularization
    is applied to maintain numerical stability.

    Args:
        sin_az: Sine of azimuth angle.
        cos_az: Cosine of azimuth angle.
        sin_el: Sine of elevation angle.
        cos_el: Cosine of elevation angle.
        std_dev_az_rad: Standard deviation of azimuth in radians.
        std_dev_el_rad: Standard deviation of elevation in radians.

    Returns:
        2x2 covariance matrix in direction cosine space.
    """
    # Jacobian: J[i,j] = d(u,v)[i] / d(az,el)[j]
    jacobian = np.array(
        [
            [cos_el * cos_az, -sin_el * sin_az],
            [-cos_el * sin_az, -sin_el * cos_az],
        ],
    )

    # Angular covariance (diagonal)
    cov_angle = np.array(
        [
            [std_dev_az_rad**2, 0.0],
            [0.0, std_dev_el_rad**2],
        ],
    )

    # Transform: Cov_uv = J @ Cov_azel @ J.T
    cov_dc = jacobian @ cov_angle @ jacobian.T

    # Regularize to ensure numerical stability
    min_variance = min(std_dev_az_rad**2, std_dev_el_rad**2)
    min_eigenvalue = min_variance * 0.05  # 5% of smaller angular variance

    eigvals, eigvecs = np.linalg.eigh(cov_dc)
    eigvals_reg = np.maximum(eigvals, min_eigenvalue)

    if not np.allclose(eigvals, eigvals_reg):
        cov_dc = eigvecs @ np.diag(eigvals_reg) @ eigvecs.T

    return cov_dc
