"""MonteCarloResult class for holding Monte Carlo simulation outputs.

A MonteCarloResult contains all results from N iterations of a simulation,
with methods for statistical analysis and data extraction.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from collections.abc import Iterator

    from numpy.typing import NDArray

    from .observations import Observation


class MonteCarloResult:
    """Results from a Monte Carlo simulation run.

    Contains all results from N iterations, with methods for
    statistical analysis and data extraction.

    Attributes:
        results: List of observation lists from each iteration.
    """

    __slots__ = ("_results",)

    def __init__(
        self,
        results: list[list[Observation]] | None = None,
    ) -> None:
        """Initialize Monte Carlo result.

        Args:
            results: List of observation lists from each iteration.
        """
        self._results: list[list[Observation]] = results if results is not None else []

    @property
    def results(self) -> list[list[Observation]]:
        """List of observation lists from each iteration."""
        return self._results

    @property
    def n_iterations(self) -> int:
        """Number of iterations in the Monte Carlo run."""
        return len(self._results)

    @property
    def all_observations(self) -> list[Observation]:
        """Flat list of all observations from all iterations."""
        return [obs for iteration in self._results for obs in iteration]

    def observations_by_iteration(self) -> Iterator[list[Observation]]:
        """Iterate over observation lists by iteration.

        Yields:
            List of observations for each iteration.
        """
        yield from self._results

    def get_observation_values(
        self,
        sensor_id: str | None = None,
        obs_type: str | None = None,
    ) -> NDArray[np.floating]:
        """Extract observation values as a numpy array.

        Each row corresponds to one iteration, each column to one
        observation (in order within each iteration).

        Args:
            sensor_id: Optional filter by sensor ID.
            obs_type: Optional filter by observation type ("AOA", "TDOA", "FDOA").

        Returns:
            Array of shape (n_iterations, n_observations_per_iter).
            For scalar observations (TDOA, FDOA), values are floats.
            For vector observations (AOA), values are flattened.

        Raises:
            ValueError: If iterations have different numbers of observations.
        """
        values_per_iter = []

        for obs_list in self._results:
            filtered = obs_list

            # Apply filters
            if sensor_id is not None:
                filtered = [o for o in filtered if o.sensor_id == sensor_id]
            if obs_type is not None:
                filtered = [o for o in filtered if o.obs_type == obs_type]

            # Extract values (flatten vector observations)
            iter_values = []
            for obs in filtered:
                val = obs.value
                if isinstance(val, np.ndarray):
                    if val.ndim == 0:
                        iter_values.append(float(val))
                    else:
                        iter_values.extend(val.tolist())
                else:
                    # Scalar float (TDOA, FDOA)
                    iter_values.append(float(val))

            values_per_iter.append(iter_values)

        # Validate consistent shape
        if values_per_iter:
            n_vals = len(values_per_iter[0])
            if not all(len(v) == n_vals for v in values_per_iter):
                raise ValueError(
                    "Iterations have different numbers of observations. "
                    "This may indicate varying visibility conditions.",
                )

        return np.array(values_per_iter)

    def compute_statistics(
        self,
        sensor_id: str | None = None,
        obs_type: str | None = None,
    ) -> dict[str, NDArray[np.floating] | float]:
        """Compute statistics across iterations.

        Args:
            sensor_id: Optional filter by sensor ID.
            obs_type: Optional filter by observation type.

        Returns:
            Dictionary with keys:
            - "mean": Mean value(s) across iterations
            - "std": Standard deviation across iterations
            - "min": Minimum value(s)
            - "max": Maximum value(s)
            - "median": Median value(s)
            - "n_iterations": Number of iterations
            - "n_observations": Observations per iteration
        """
        values = self.get_observation_values(sensor_id=sensor_id, obs_type=obs_type)

        if values.size == 0:
            return {
                "mean": np.array([]),
                "std": np.array([]),
                "min": np.array([]),
                "max": np.array([]),
                "median": np.array([]),
                "n_iterations": 0,
                "n_observations": 0,
            }

        return {
            "mean": np.mean(values, axis=0),
            "std": np.std(values, axis=0),
            "min": np.min(values, axis=0),
            "max": np.max(values, axis=0),
            "median": np.median(values, axis=0),
            "n_iterations": values.shape[0],
            "n_observations": values.shape[1] if values.ndim > 1 else 1,
        }

    def __repr__(self) -> str:
        """Return string representation."""
        return f"MonteCarloResult(n_iterations={self.n_iterations})"
