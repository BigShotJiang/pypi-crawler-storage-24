"""TDOA-based geolocation solver.

Estimates 3D target position from multiple Time Difference of Arrival measurements
using weighted nonlinear least squares with analytical Jacobians.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from gri_utils.geolocation import default_initial_guess, whitened_least_squares
from gri_utils.observables import tdoa_with_gradient

from .locator_result import NAN_VELOCITY, LocatorResult

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def tdoa_locator(
    collector1_xyz: NDArray[np.floating] | Sequence,
    collector2_xyz: NDArray[np.floating] | Sequence,
    tdoa_measurements: NDArray[np.floating] | Sequence,
    tdoa_variances: NDArray[np.floating] | Sequence,
    xyz0: NDArray[np.floating] | Sequence | None = None,
    **least_squares_kwargs: Any,  # noqa: ANN401
) -> LocatorResult:
    """Geolocate a target from multiple TDOA observations.

    Uses weighted nonlinear least squares with analytical Jacobians to estimate
    the 3D target position from time-difference-of-arrival measurements.

    Each TDOA measurement is the time difference between signal arrival at two
    collectors: TDOA_ij = (range_to_i - range_to_j) / c. A positive value means
    the signal arrives at collector j first (emitter is closer to collector j).

    Args:
        collector1_xyz: First collector positions in ECEF meters. Shape (N, 3)
            for N measurements.
        collector2_xyz: Second collector positions in ECEF meters. Shape (N, 3).
        tdoa_measurements: Measured TDOAs in seconds. Shape (N,).
            TDOA_i = (range_to_collector1_i - range_to_collector2_i) / c.
        tdoa_variances: Variance of each TDOA measurement in seconds**2. Shape (N,).
        xyz0: Initial guess for target position in ECEF meters. Shape (3,).
            If None, uses centroid of all collectors clamped to Earth radius.
        **least_squares_kwargs: Additional arguments passed to
            scipy.optimize.least_squares (e.g., bounds, method, ftol, xtol).

    Returns:
        LocatorResult with:
            - position: Estimated target position in ECEF meters. Shape (3,).
            - velocity: NaN values (velocity not estimated by TDOA). Shape (3,).
            - covariance: 3x3 position covariance matrix in ECEF.
            - chi_squared: Sum of squared whitened residuals.

    Raises:
        ValueError: If fewer than 3 measurements provided (underdetermined in 3D).
        ValueError: If least_squares fails to converge.
        LinAlgError: If solution covariance is singular (poor geometry).

    Example:
        >>> import numpy as np
        >>> from gri_utils.geolocation import tdoa_locator
        >>>
        >>> # Three collector pairs (could reuse collectors)
        >>> c1 = np.array([6378137.0, 0.0, 0.0])
        >>> c2 = np.array([6378137.0, 1000.0, 0.0])
        >>> c3 = np.array([6378137.0, 0.0, 1000.0])
        >>> collector1 = np.array([c1, c1, c2])  # Pairs: 12, 13, 23
        >>> collector2 = np.array([c2, c3, c3])
        >>>
        >>> # TDOA measurements in seconds
        >>> tdoas = np.array([1e-6, 2e-6, 1e-6])
        >>>
        >>> # 10 ns timing uncertainty per measurement
        >>> variances = np.full(3, (10e-9)**2)
        >>>
        >>> result = tdoa_locator(collector1, collector2, tdoas, variances)
        >>> print(result.position, result.chi_squared)
    """
    collector1_xyz = np.asarray(collector1_xyz)
    collector2_xyz = np.asarray(collector2_xyz)
    tdoa_measurements = np.asarray(tdoa_measurements)
    tdoa_variances = np.asarray(tdoa_variances)

    n_measurements = tdoa_measurements.shape[0]

    min_measurements = 3
    if n_measurements < min_measurements:
        msg = f"{min_measurements} TDOA measurements required, got {n_measurements}"
        raise ValueError(msg)

    # Validate shapes
    if collector1_xyz.shape != (n_measurements, 3):
        msg = f"collector1_xyz shape {collector1_xyz.shape} != ({n_measurements}, 3)"
        raise ValueError(msg)

    if collector2_xyz.shape != (n_measurements, 3):
        msg = f"collector2_xyz shape {collector2_xyz.shape} != ({n_measurements}, 3)"
        raise ValueError(msg)

    if tdoa_variances.shape != (n_measurements,):
        msg = f"tdoa_variances shape {tdoa_variances.shape} != ({n_measurements},)"
        raise ValueError(msg)

    # Build diagonal covariance matrix (N x N)
    full_covariance = np.diag(tdoa_variances)

    def residual_and_jacobian(
        x: NDArray[np.floating],
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Compute residual and Jacobian together."""
        # Compute predicted TDOA and gradient for each pair
        predicted = np.empty(n_measurements)
        jacobian = np.empty((n_measurements, 3))

        for i in range(n_measurements):
            pred_i, grad_i = tdoa_with_gradient(
                x,
                collector1_xyz[i],
                collector2_xyz[i],
            )
            predicted[i] = pred_i
            jacobian[i] = grad_i

        residual = tdoa_measurements - predicted
        # Negative because residual = measurement - predicted
        return residual, -jacobian

    # Default initial guess: centroid clamped to Earth surface
    if xyz0 is None:
        all_collectors = np.vstack([collector1_xyz, collector2_xyz])
        initial_guess = default_initial_guess(all_collectors)
    else:
        initial_guess = np.asarray(xyz0)

    position, covariance, chi_squared = whitened_least_squares(
        residual_and_jacobian,
        initial_guess,
        full_covariance,
        **least_squares_kwargs,
    )

    return LocatorResult(position, NAN_VELOCITY, covariance, chi_squared)
