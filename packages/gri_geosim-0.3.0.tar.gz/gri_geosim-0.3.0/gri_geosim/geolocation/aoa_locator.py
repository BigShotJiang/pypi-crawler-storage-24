"""AOA-based geolocation solver.

Estimates 3D target position from multiple Angle of Arrival measurements
using weighted nonlinear least squares with analytical Jacobians.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from gri_utils.geolocation import default_initial_guess, whitened_least_squares
from gri_utils.observables import aoa_quat_with_gradient
from scipy.linalg import block_diag
from scipy.spatial.transform import Rotation

from .locator_result import NAN_VELOCITY, LocatorResult

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def aoa_locator(
    collector_xyz: NDArray[np.floating] | Sequence,
    collector_rotations: NDArray[np.floating] | Sequence | Rotation,
    aoa_measurements: NDArray[np.floating] | Sequence,
    aoa_covariances: NDArray[np.floating] | Sequence,
    xyz0: NDArray[np.floating] | Sequence | None = None,
    **least_squares_kwargs: Any,  # noqa: ANN401
) -> LocatorResult:
    """Geolocate a target from multiple AOA observations.

    Uses weighted nonlinear least squares with analytical Jacobians to estimate
    the 3D target position from angle-of-arrival measurements.

    Args:
        collector_xyz: Collector positions in ECEF. Shape (N, 3) for N collectors.
        collector_rotations: Collector orientations as quaternions [x, y, z, w]
            (scipy convention, scalar-last). Shape (N, 4) or scipy Rotation object.
        aoa_measurements: Measured AOA direction cosines (X, Y components of
            unit vector in collector's local frame). Shape (N, 2).
        aoa_covariances: Covariance of each AOA measurement. Shape (N, 2, 2).
        xyz0: Initial guess for target position in ECEF. Shape (3,).
            If None, uses centroid of collectors clamped to Earth radius.
        **least_squares_kwargs: Additional arguments passed to
            scipy.optimize.least_squares (e.g., bounds, method, ftol, xtol).

    Returns:
        LocatorResult with:
            - position: Estimated target position in ECEF meters. Shape (3,).
            - velocity: NaN values (velocity not estimated by AOA). Shape (3,).
            - covariance: 3x3 position covariance matrix in ECEF.
            - chi_squared: Sum of squared whitened residuals.

    Raises:
        ValueError: If fewer than 2 collectors provided.
        LinAlgError: If solution covariance is singular (poor geometry).

    Example:
        >>> import numpy as np
        >>> from scipy.spatial.transform import Rotation
        >>> from gri_utils.geolocation import aoa_locator
        >>>
        >>> # Two collectors on Earth's surface
        >>> collectors = np.array([
        ...     [6378137.0, 0.0, 0.0],
        ...     [6378137.0, 1000.0, 0.0],
        ... ])
        >>> # Identity rotations (local frame = ECEF)
        >>> rotations = Rotation.identity(2)
        >>> # AOA measurements pointing toward target
        >>> aoa = np.array([[0.1, 0.2], [0.15, 0.18]])
        >>> # 1 mrad measurement noise
        >>> cov = np.eye(2) * 0.001**2
        >>> covs = np.array([cov, cov])
        >>>
        >>> result = aoa_locator(collectors, rotations, aoa, covs)
        >>> print(result.position, result.chi_squared)
    """
    collector_xyz = np.asarray(collector_xyz)
    aoa_measurements = np.asarray(aoa_measurements)
    aoa_covariances = np.asarray(aoa_covariances)

    # Handle Rotation objects
    if isinstance(collector_rotations, Rotation):
        rotation = collector_rotations
    else:
        rotation = Rotation.from_quat(np.asarray(collector_rotations))

    n_collectors = collector_xyz.shape[0]

    min_collectors = 2
    if n_collectors < min_collectors:
        msg = f"At least {min_collectors} collectors required, got {n_collectors}"
        raise ValueError(msg)

    # Validate shapes
    if aoa_measurements.shape != (n_collectors, 2):
        msg = f"aoa_measurements shape {aoa_measurements.shape} != ({n_collectors}, 2)"
        raise ValueError(msg)

    if aoa_covariances.shape != (n_collectors, 2, 2):
        msg = f"aoa_covariances shape {aoa_covariances.shape} != ({n_collectors}, 2, 2)"
        raise ValueError(msg)

    # Build block-diagonal covariance matrix (2N x 2N)
    full_covariance = block_diag(*aoa_covariances)

    # Flatten measurements to (2N,) vector
    measurements_flat = aoa_measurements.ravel()

    def residual_and_jacobian(
        x: NDArray[np.floating],
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Compute residual and Jacobian together."""
        predicted, jacobians = aoa_quat_with_gradient(collector_xyz, x, rotation)
        residual = measurements_flat - predicted.ravel()
        # jacobians shape: (N, 2, 3) -> reshape to (2N, 3)
        # Negative because residual = measurement - predicted
        jacobian = -jacobians.reshape(-1, 3)
        return residual, jacobian

    # Default initial guess: centroid clamped to Earth surface
    if xyz0 is None:
        initial_guess = default_initial_guess(collector_xyz)
    else:
        initial_guess = np.asarray(xyz0)

    position, covariance, chi_squared = whitened_least_squares(
        residual_and_jacobian,
        initial_guess,
        full_covariance,
        **least_squares_kwargs,
    )

    return LocatorResult(position, NAN_VELOCITY, covariance, chi_squared)
