"""TDOA+AOA+FDOA geolocation solver.

Estimates 3D target position from any combination of TDOA, AOA, and FDOA
measurements with a known velocity constraint.

The solver estimates position from combined observables when velocity is known
(stationary target, INS data, etc.). Any combination of TDOA, AOA, and FDOA
can be provided, with at least 3 total measurements required for 3D position.

For combined TDOA+FDOA geolocation of a moving target, the typical workflow is:
    1. Use tdoa_locator to get position estimate
    2. Use fdoa_locator with fix_position to get velocity estimate

For stationary targets, use fix_velocity=np.zeros(3) and combine all observables.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from gri_utils.geolocation import default_initial_guess, whitened_least_squares
from gri_utils.observables import (
    aoa_quat_with_gradient,
    fdoa_with_gradient,
    tdoa_with_gradient,
)
from scipy.linalg import block_diag
from scipy.spatial.transform import Rotation

from .aoa_locator import aoa_locator
from .locator_result import LocatorResult
from .tdoa_locator import tdoa_locator

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def tdoa_aoa_fdoa_locator(  # noqa: PLR0913
    # TDOA inputs
    tdoa_collector1_xyz: NDArray[np.floating] | Sequence | None = None,
    tdoa_collector2_xyz: NDArray[np.floating] | Sequence | None = None,
    tdoa_measurements: NDArray[np.floating] | Sequence | None = None,
    tdoa_variances: NDArray[np.floating] | Sequence | None = None,
    # AOA inputs
    aoa_collector_xyz: NDArray[np.floating] | Sequence | None = None,
    aoa_rotations: NDArray[np.floating] | Sequence | Rotation | None = None,
    aoa_measurements: NDArray[np.floating] | Sequence | None = None,
    aoa_covariances: NDArray[np.floating] | Sequence | None = None,
    # FDOA inputs
    fdoa_collector1_xyz: NDArray[np.floating] | Sequence | None = None,
    fdoa_collector2_xyz: NDArray[np.floating] | Sequence | None = None,
    fdoa_measurements: NDArray[np.floating] | Sequence | None = None,
    fdoa_variances: NDArray[np.floating] | Sequence | None = None,
    freq_hz: float = 1e9,
    fdoa_collector1_vel: NDArray[np.floating] | Sequence | None = None,
    fdoa_collector2_vel: NDArray[np.floating] | Sequence | None = None,
    # Velocity constraint
    fix_velocity: NDArray[np.floating] | Sequence | None = None,
    # Initial guess
    xyz0: NDArray[np.floating] | Sequence | None = None,
    **least_squares_kwargs: Any,  # noqa: ANN401
) -> LocatorResult:
    """Geolocate target from combined AOA, TDOA, and/or FDOA with known velocity.

    Estimates position from combined FDOA, TDOA, and/or AOA measurements when
    the target velocity is known. Any subset of observables can be provided
    (at least one required). Use when velocity is known (stationary target,
    INS data, etc.). Defaults to zero velocity if fix_velocity not specified.

    If only TDOA or only AOA measurements are provided (no FDOA), this function
    delegates to the corresponding single-observable locator.

    Note:
        For velocity estimation from FDOA with known position, use
        `fdoa_locator(..., fix_position=known_pos)` instead.

    Args:
        tdoa_collector1_xyz: First TDOA collector positions in ECEF meters.
            Shape (N_tdoa, 3). None if no TDOA measurements.
        tdoa_collector2_xyz: Second TDOA collector positions in ECEF meters.
            Shape (N_tdoa, 3). None if no TDOA measurements.
        tdoa_measurements: Measured TDOAs in seconds. Shape (N_tdoa,).
            None if no TDOA measurements.
        tdoa_variances: Variance of each TDOA measurement in seconds**2.
            Shape (N_tdoa,). None if no TDOA measurements.
        aoa_collector_xyz: AOA collector positions in ECEF meters.
            Shape (N_aoa, 3). None if no AOA measurements.
        aoa_rotations: AOA collector orientations as quaternions [x, y, z, w]
            (scipy convention, scalar-last). Shape (N_aoa, 4) or scipy Rotation.
            None if no AOA measurements.
        aoa_measurements: Measured AOA direction cosines (X, Y components of
            unit vector in collector's local frame). Shape (N_aoa, 2).
            None if no AOA measurements.
        aoa_covariances: Covariance of each AOA measurement.
            Shape (N_aoa, 2, 2). None if no AOA measurements.
        fdoa_collector1_xyz: First FDOA collector positions in ECEF meters.
            Shape (N_fdoa, 3). None if no FDOA measurements.
        fdoa_collector2_xyz: Second FDOA collector positions in ECEF meters.
            Shape (N_fdoa, 3). None if no FDOA measurements.
        fdoa_measurements: Measured FDOAs in Hz. Shape (N_fdoa,).
            None if no FDOA measurements.
        fdoa_variances: Variance of each FDOA measurement in Hz**2.
            Shape (N_fdoa,). None if no FDOA measurements.
        freq_hz: Carrier frequency in Hz for FDOA. Default 1 GHz.
        fdoa_collector1_vel: First FDOA collector velocities in ECEF m/s.
            Shape (N_fdoa, 3). If None, collectors assumed stationary.
        fdoa_collector2_vel: Second FDOA collector velocities in ECEF m/s.
            Shape (N_fdoa, 3). If None, collectors assumed stationary.
        fix_velocity: Fixed target velocity in ECEF m/s. Shape (3,).
            If None, defaults to stationary target (zeros).
        xyz0: Initial guess for target position in ECEF meters. Shape (3,).
            If None, uses collector centroid.
        **least_squares_kwargs: Additional arguments passed to
            scipy.optimize.least_squares (e.g., bounds, method, ftol, xtol).

    Returns:
        LocatorResult with:
            - position: Estimated target position in ECEF meters. Shape (3,).
            - velocity: Fixed target velocity in ECEF m/s. Shape (3,).
            - covariance: 3x3 covariance matrix of estimated position.
            - chi_squared: Sum of squared whitened residuals.

    Raises:
        ValueError: If no measurements provided at all.
        ValueError: If input array shapes are inconsistent.
        LinAlgError: If solution covariance is singular (poor geometry).

    Example:
        Stationary target with combined TDOA+AOA+FDOA::

            # Estimate position knowing target is stationary
            result = tdoa_aoa_fdoa_locator(
                tdoa_collector1_xyz=tdoa_c1,
                tdoa_collector2_xyz=tdoa_c2,
                tdoa_measurements=tdoa_meas,
                tdoa_variances=tdoa_var,
                aoa_collector_xyz=aoa_xyz,
                aoa_rotations=aoa_rot,
                aoa_measurements=aoa_meas,
                aoa_covariances=aoa_cov,
                fdoa_collector1_xyz=fdoa_c1,
                fdoa_collector2_xyz=fdoa_c2,
                fdoa_measurements=fdoa_meas,
                fdoa_variances=fdoa_var,
                freq_hz=1e9,
                fdoa_collector1_vel=v1,
                fdoa_collector2_vel=v2,
                fix_velocity=np.zeros(3),
            )
            print(result.position, result.chi_squared)

        TDOA+FDOA fusion workflow for moving target::

            from gri_utils.geolocation import tdoa_locator, fdoa_locator

            # Step 1: Get position from TDOA
            tdoa_result = tdoa_locator(
                tdoa_c1, tdoa_c2, tdoa_meas, tdoa_var
            )

            # Step 2: Get velocity from FDOA with fixed position
            fdoa_result = fdoa_locator(
                fdoa_c1, fdoa_c2, fdoa_meas, fdoa_var, freq_hz,
                collector1_vel=v1,
                collector2_vel=v2,
                fix_position=tdoa_result.position,
            )
            print(fdoa_result.velocity, fdoa_result.chi_squared)
    """
    # Validate input groups are all-or-nothing
    _validate_input_groups(
        fdoa_collector1_xyz,
        fdoa_collector2_xyz,
        fdoa_measurements,
        fdoa_variances,
        tdoa_collector1_xyz,
        tdoa_collector2_xyz,
        tdoa_measurements,
        tdoa_variances,
        aoa_collector_xyz,
        aoa_rotations,
        aoa_measurements,
        aoa_covariances,
    )

    has_fdoa = fdoa_measurements is not None
    has_tdoa = tdoa_measurements is not None
    has_aoa = aoa_measurements is not None

    # Fixed velocity (explicit or default to stationary)
    fixed_vel = np.zeros(3) if fix_velocity is None else np.asarray(fix_velocity)

    # Must have at least one measurement type
    if not has_fdoa and not has_tdoa and not has_aoa:
        msg = "At least one of FDOA, TDOA, or AOA measurements must be provided"
        raise ValueError(msg)

    # Delegate to single-observable locators when appropriate
    if not has_fdoa:
        # No FDOA, just TDOA and/or AOA - velocity constraint is irrelevant
        if has_tdoa and not has_aoa:
            result = tdoa_locator(
                tdoa_collector1_xyz,  # type: ignore[arg-type]
                tdoa_collector2_xyz,  # type: ignore[arg-type]
                tdoa_measurements,  # type: ignore[arg-type]
                tdoa_variances,  # type: ignore[arg-type]
                xyz0=xyz0,
                **least_squares_kwargs,
            )
            # Replace NaN velocity with the fixed velocity
            return LocatorResult(
                result.position,
                fixed_vel,
                result.covariance,
                result.chi_squared,
            )

        if has_aoa and not has_tdoa:
            result = aoa_locator(
                aoa_collector_xyz,  # type: ignore[arg-type]
                aoa_rotations,  # type: ignore[arg-type]
                aoa_measurements,  # type: ignore[arg-type]
                aoa_covariances,  # type: ignore[arg-type]
                xyz0=xyz0,
                **least_squares_kwargs,
            )
            # Replace NaN velocity with the fixed velocity
            return LocatorResult(
                result.position,
                fixed_vel,
                result.covariance,
                result.chi_squared,
            )

        # Both TDOA and AOA but no FDOA - use hybrid_locator logic inline
        # (we don't import hybrid_locator to avoid circular dependency)

    # Combined solver for fix_velocity mode
    return _solve_fixed_velocity(
        fixed_vel,
        fdoa_collector1_xyz,
        fdoa_collector2_xyz,
        fdoa_measurements,
        fdoa_variances,
        freq_hz,
        fdoa_collector1_vel,
        fdoa_collector2_vel,
        tdoa_collector1_xyz,
        tdoa_collector2_xyz,
        tdoa_measurements,
        tdoa_variances,
        aoa_collector_xyz,
        aoa_rotations,
        aoa_measurements,
        aoa_covariances,
        xyz0,
        **least_squares_kwargs,
    )


def _validate_input_groups(  # noqa: PLR0913
    fdoa_c1: Any,  # noqa: ANN401
    fdoa_c2: Any,  # noqa: ANN401
    fdoa_meas: Any,  # noqa: ANN401
    fdoa_var: Any,  # noqa: ANN401
    tdoa_c1: Any,  # noqa: ANN401
    tdoa_c2: Any,  # noqa: ANN401
    tdoa_meas: Any,  # noqa: ANN401
    tdoa_var: Any,  # noqa: ANN401
    aoa_xyz: Any,  # noqa: ANN401
    aoa_rot: Any,  # noqa: ANN401
    aoa_meas: Any,  # noqa: ANN401
    aoa_cov: Any,  # noqa: ANN401
) -> None:
    """Validate that input groups are all-or-nothing."""
    fdoa_inputs = [fdoa_c1, fdoa_c2, fdoa_meas, fdoa_var]
    if sum(x is None for x in fdoa_inputs) not in (0, 4):
        msg = "FDOA inputs must be all provided or all None"
        raise ValueError(msg)

    tdoa_inputs = [tdoa_c1, tdoa_c2, tdoa_meas, tdoa_var]
    if sum(x is None for x in tdoa_inputs) not in (0, 4):
        msg = "TDOA inputs must be all provided or all None"
        raise ValueError(msg)

    aoa_inputs = [aoa_xyz, aoa_rot, aoa_meas, aoa_cov]
    if sum(x is None for x in aoa_inputs) not in (0, 4):
        msg = "AOA inputs must be all provided or all None"
        raise ValueError(msg)


def _solve_fixed_velocity(  # noqa: PLR0913, PLR0915, PLR0912, C901
    fixed_vel: NDArray[np.floating],
    fdoa_c1: NDArray[np.floating] | Sequence | None,
    fdoa_c2: NDArray[np.floating] | Sequence | None,
    fdoa_meas: NDArray[np.floating] | Sequence | None,
    fdoa_var: NDArray[np.floating] | Sequence | None,
    freq_hz: float,
    fdoa_v1: NDArray[np.floating] | Sequence | None,
    fdoa_v2: NDArray[np.floating] | Sequence | None,
    tdoa_c1: NDArray[np.floating] | Sequence | None,
    tdoa_c2: NDArray[np.floating] | Sequence | None,
    tdoa_meas: NDArray[np.floating] | Sequence | None,
    tdoa_var: NDArray[np.floating] | Sequence | None,
    aoa_xyz: NDArray[np.floating] | Sequence | None,
    aoa_rot: NDArray[np.floating] | Sequence | Rotation | None,
    aoa_meas: NDArray[np.floating] | Sequence | None,
    aoa_cov: NDArray[np.floating] | Sequence | None,
    xyz0: NDArray[np.floating] | Sequence | None,
    **least_squares_kwargs: Any,  # noqa: ANN401
) -> LocatorResult:
    """Solve for position with fixed velocity using combined observables."""
    has_fdoa = fdoa_meas is not None
    has_tdoa = tdoa_meas is not None
    has_aoa = aoa_meas is not None

    # Convert and validate FDOA
    if has_fdoa:
        fdoa_c1_arr = np.asarray(fdoa_c1)
        fdoa_c2_arr = np.asarray(fdoa_c2)
        fdoa_meas_arr = np.asarray(fdoa_meas)
        fdoa_var_arr = np.asarray(fdoa_var)
        n_fdoa = len(fdoa_meas_arr)

        if fdoa_c1_arr.shape != (n_fdoa, 3):
            msg = f"fdoa_collector1_xyz shape {fdoa_c1_arr.shape} != ({n_fdoa}, 3)"
            raise ValueError(msg)
        if fdoa_c2_arr.shape != (n_fdoa, 3):
            msg = f"fdoa_collector2_xyz shape {fdoa_c2_arr.shape} != ({n_fdoa}, 3)"
            raise ValueError(msg)
        if fdoa_var_arr.shape != (n_fdoa,):
            msg = f"fdoa_variances shape {fdoa_var_arr.shape} != ({n_fdoa},)"
            raise ValueError(msg)

        fdoa_v1_arr = np.zeros((n_fdoa, 3)) if fdoa_v1 is None else np.asarray(fdoa_v1)
        fdoa_v2_arr = np.zeros((n_fdoa, 3)) if fdoa_v2 is None else np.asarray(fdoa_v2)

        if fdoa_v1_arr.shape != (n_fdoa, 3):
            msg = f"fdoa_collector1_vel shape {fdoa_v1_arr.shape} != ({n_fdoa}, 3)"
            raise ValueError(msg)
        if fdoa_v2_arr.shape != (n_fdoa, 3):
            msg = f"fdoa_collector2_vel shape {fdoa_v2_arr.shape} != ({n_fdoa}, 3)"
            raise ValueError(msg)
    else:
        fdoa_c1_arr = np.empty((0, 3))
        fdoa_c2_arr = np.empty((0, 3))
        fdoa_meas_arr = np.empty(0)
        fdoa_var_arr = np.empty(0)
        fdoa_v1_arr = np.empty((0, 3))
        fdoa_v2_arr = np.empty((0, 3))
        n_fdoa = 0

    # Convert and validate TDOA
    if has_tdoa:
        tdoa_c1_arr = np.asarray(tdoa_c1)
        tdoa_c2_arr = np.asarray(tdoa_c2)
        tdoa_meas_arr = np.asarray(tdoa_meas)
        tdoa_var_arr = np.asarray(tdoa_var)
        n_tdoa = len(tdoa_meas_arr)

        if tdoa_c1_arr.shape != (n_tdoa, 3):
            msg = f"tdoa_collector1_xyz shape {tdoa_c1_arr.shape} != ({n_tdoa}, 3)"
            raise ValueError(msg)
        if tdoa_c2_arr.shape != (n_tdoa, 3):
            msg = f"tdoa_collector2_xyz shape {tdoa_c2_arr.shape} != ({n_tdoa}, 3)"
            raise ValueError(msg)
        if tdoa_var_arr.shape != (n_tdoa,):
            msg = f"tdoa_variances shape {tdoa_var_arr.shape} != ({n_tdoa},)"
            raise ValueError(msg)
    else:
        tdoa_c1_arr = np.empty((0, 3))
        tdoa_c2_arr = np.empty((0, 3))
        tdoa_meas_arr = np.empty(0)
        tdoa_var_arr = np.empty(0)
        n_tdoa = 0

    # Convert and validate AOA
    if has_aoa:
        aoa_xyz_arr = np.asarray(aoa_xyz)
        aoa_meas_arr = np.asarray(aoa_meas)
        aoa_cov_arr = np.asarray(aoa_cov)
        n_aoa = len(aoa_meas_arr)

        if aoa_xyz_arr.shape != (n_aoa, 3):
            msg = f"aoa_collector_xyz shape {aoa_xyz_arr.shape} != ({n_aoa}, 3)"
            raise ValueError(msg)
        if aoa_meas_arr.shape != (n_aoa, 2):
            msg = f"aoa_measurements shape {aoa_meas_arr.shape} != ({n_aoa}, 2)"
            raise ValueError(msg)
        if aoa_cov_arr.shape != (n_aoa, 2, 2):
            msg = f"aoa_covariances shape {aoa_cov_arr.shape} != ({n_aoa}, 2, 2)"
            raise ValueError(msg)

        aoa_rot_obj = (
            aoa_rot
            if isinstance(aoa_rot, Rotation)
            else Rotation.from_quat(np.asarray(aoa_rot))
        )
    else:
        aoa_xyz_arr = np.empty((0, 3))
        aoa_meas_arr = np.empty((0, 2))
        aoa_cov_arr = np.empty((0, 2, 2))
        aoa_rot_obj = Rotation.identity()
        n_aoa = 0

    # Build block-diagonal covariance: [TDOA diag, FDOA diag, AOA blocks]
    cov_blocks = []
    if n_tdoa > 0:
        cov_blocks.append(np.diag(tdoa_var_arr))
    if n_fdoa > 0:
        cov_blocks.append(np.diag(fdoa_var_arr))
    if n_aoa > 0:
        cov_blocks.extend(list(aoa_cov_arr))
    full_covariance = block_diag(*cov_blocks)

    def residual_and_jacobian(
        x: NDArray[np.floating],
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Compute combined residual and Jacobian for position estimation."""
        residuals = []
        jacobians = []

        # TDOA component
        if n_tdoa > 0:
            tdoa_pred = np.empty(n_tdoa)
            tdoa_jac = np.empty((n_tdoa, 3))
            for i in range(n_tdoa):
                tdoa_pred[i], tdoa_jac[i] = tdoa_with_gradient(
                    x,
                    tdoa_c1_arr[i],
                    tdoa_c2_arr[i],
                )
            residuals.append(tdoa_meas_arr - tdoa_pred)
            jacobians.append(-tdoa_jac)

        # FDOA component (position gradient only, velocity is fixed)
        if n_fdoa > 0:
            fdoa_pred = np.empty(n_fdoa)
            fdoa_jac = np.empty((n_fdoa, 3))
            for i in range(n_fdoa):
                pred_i, grad_pos_i, _ = fdoa_with_gradient(
                    x,
                    fixed_vel,
                    fdoa_c1_arr[i],
                    fdoa_c2_arr[i],
                    freq_hz,
                    collector1_vel=fdoa_v1_arr[i],
                    collector2_vel=fdoa_v2_arr[i],
                )
                fdoa_pred[i] = pred_i
                fdoa_jac[i] = grad_pos_i
            residuals.append(fdoa_meas_arr - fdoa_pred)
            jacobians.append(-fdoa_jac)

        # AOA component
        if n_aoa > 0:
            aoa_pred, aoa_jacs = aoa_quat_with_gradient(aoa_xyz_arr, x, aoa_rot_obj)
            aoa_residual = aoa_meas_arr.ravel() - aoa_pred.ravel()
            aoa_jacobian = -aoa_jacs.reshape(-1, 3)
            residuals.append(aoa_residual)
            jacobians.append(aoa_jacobian)

        return np.concatenate(residuals), np.vstack(jacobians)

    # Default initial guess from all collectors
    if xyz0 is None:
        all_collectors = []
        if n_tdoa > 0:
            all_collectors.extend([tdoa_c1_arr, tdoa_c2_arr])
        if n_fdoa > 0:
            all_collectors.extend([fdoa_c1_arr, fdoa_c2_arr])
        if n_aoa > 0:
            all_collectors.append(aoa_xyz_arr)
        initial_guess = default_initial_guess(np.vstack(all_collectors))
    else:
        initial_guess = np.asarray(xyz0)

    solution, covariance, chi_squared = whitened_least_squares(
        residual_and_jacobian,
        initial_guess,
        full_covariance,
        **least_squares_kwargs,
    )

    return LocatorResult(solution, fixed_vel, covariance, chi_squared)
