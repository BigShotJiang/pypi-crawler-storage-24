"""Result type for geolocation solvers.

Provides a consistent return type across all locators with position, velocity,
covariance, and fit quality metrics.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, NamedTuple

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


class LocatorResult(NamedTuple):
    """Result from a geolocation solver.

    All locators return this type for consistent API. The NamedTuple supports
    both named attribute access and tuple unpacking.

    Attributes:
        position: Estimated target position in ECEF meters. Shape (3,).
        velocity: Estimated target velocity in ECEF m/s. Shape (3,).
            Contains np.nan values if velocity was not estimated
            (e.g., from AOA or TDOA locators).
        covariance: Covariance matrix of estimated parameters.
            Shape (3, 3) for position-only or velocity-only estimation.
            Shape (6, 6) for joint position+velocity estimation, where
            [:3, :3] is position covariance, [3:, 3:] is velocity covariance,
            and off-diagonals are cross-covariance.
        chi_squared: Sum of squared whitened residuals at the solution.
            Under correct model assumptions, this follows a chi-squared
            distribution with (n_observations - n_parameters) degrees of
            freedom. Useful for statistical validation and outlier detection.

    Example:
        >>> result = aoa_locator(collectors, rotations, measurements, covariances)
        >>> # Named attribute access
        >>> print(f"Position: {result.position}")
        >>> print(f"Chi-squared: {result.chi_squared}")
        >>> # Tuple unpacking
        >>> pos, vel, cov, chi_sq = result
        >>> # Check if velocity was estimated
        >>> if not np.isnan(result.velocity).any():
        ...     print(f"Velocity: {result.velocity}")
    """

    position: NDArray[np.floating]
    velocity: NDArray[np.floating]
    covariance: NDArray[np.floating]
    chi_squared: float


# Constant for locators that don't estimate velocity
NAN_VELOCITY: NDArray[np.floating] = np.full(3, np.nan)
