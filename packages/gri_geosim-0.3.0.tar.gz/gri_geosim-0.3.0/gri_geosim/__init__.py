"""GRI GeoSim: Geometric/geolocation simulation library.

This library provides tools for simulating geolocation scenarios including:
- Satellite orbits with sensors
- Ground/air platforms with sensors
- Emitters (stationary or moving)
- AOA/TDOA/FDOA observable generation
- Geolocation algorithms
- Covariance ellipsoid analysis

Example usage:
    >>> from gri_geosim import Scenario, Platform, Emitter, filter_aoa, locate
    >>> from gri_geosim.sensors import AoaSensor
    >>> from gri_pos import Pos
    >>> from gri_nsepoch import Time
    >>>
    >>> # Create platform with sensor (Pos = stationary)
    >>> ground = Platform(Pos.LLA(38.0, -77.0, 100.0), name="GND")
    >>> ground.add_sensor(AoaSensor("aoa", azimuth_std_rad=0.001))
    >>>
    >>> # Create emitter and scenario
    >>> target = Emitter(Pos.LLA(39.0, -76.0, 0.0), name="TARGET")
    >>> scenario = Scenario.for_instant(platforms=[ground], emitters=[target])
    >>>
    >>> # Simulate and geolocate
    >>> observations = scenario.simulate_at(Time.from_str("2024-01-15T12:00:00Z"))
    >>> ell = locate(observations)
    >>> print(f"Position: {ell.lla}")
"""

from .atmosphere import AtmosphereConfig, AtmosphericCorrection, IonoModel
from .emitter import Emitter
from .geolocation import (
    LocatorResult,
    aoa_locator,
    fdoa_locator,
    tdoa_aoa_fdoa_locator,
    tdoa_aoa_locator,
    tdoa_locator,
)
from .locate import locate
from .montecarlo import MonteCarlo
from .montecarlo_result import MonteCarloResult
from .observations import (
    AoaObservation,
    FdoaObservation,
    Observation,
    TdoaObservation,
    filter_aoa,
    filter_by_emitter,
    filter_by_sensor,
    filter_fdoa,
    filter_tdoa,
)
from .platform import Platform
from .scenario import Scenario

__all__ = [
    "AoaObservation",
    "AtmosphereConfig",
    "AtmosphericCorrection",
    "Emitter",
    "FdoaObservation",
    "IonoModel",
    "LocatorResult",
    "MonteCarlo",
    "MonteCarloResult",
    "Observation",
    "Platform",
    "Scenario",
    "TdoaObservation",
    "aoa_locator",
    "fdoa_locator",
    "filter_aoa",
    "filter_by_emitter",
    "filter_by_sensor",
    "filter_fdoa",
    "filter_tdoa",
    "locate",
    "tdoa_aoa_fdoa_locator",
    "tdoa_aoa_locator",
    "tdoa_locator",
]
