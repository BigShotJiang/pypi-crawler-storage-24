# ruff: noqa: T201
"""Find all the unit tests and make sure none of the skips are commented in!

You can run this manually with:
> python .pre-commit-noskips.py
"""

import sys
from pathlib import Path


def _main() -> None:
    # Get the test directory, which should be adjascent to this script
    script_dir = Path(__file__)
    test_dir = script_dir.parent / "test"
    if not test_dir.exists():
        print("WARNING::: Didn't find a test directory!")
        sys.exit(0)
    tests = test_dir.rglob("test*.py")
    found = False
    for testfile in tests:
        with testfile.open("r") as fp:
            for idx, line in enumerate(fp, 1):
                if line.strip().startswith("#") and (
                    "pytest.skip" in line or "pytest.mark.skip" in line
                ):
                    print(
                        f"ERROR::: Line {idx} of {testfile.relative_to(test_dir)} "
                        "has a skip commented out:",
                    )
                    print(f" {idx}: {line}")
                    found = True
    if found:
        sys.exit(1)  # Error4 aborts the commit


if __name__ == "__main__":
    _main()
