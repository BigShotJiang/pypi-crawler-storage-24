# Partial stub for scipy
