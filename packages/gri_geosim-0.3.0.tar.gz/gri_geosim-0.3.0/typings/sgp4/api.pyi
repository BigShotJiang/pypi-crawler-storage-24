class Satrec:
    error: int
    satnum: str

    @staticmethod
    def twoline2rv(line1: str, line2: str) -> Satrec: ...
    def sgp4(
        self,
        jd: float,
        fr: float,
    ) -> tuple[int, tuple[float, float, float], tuple[float, float, float]]: ...
