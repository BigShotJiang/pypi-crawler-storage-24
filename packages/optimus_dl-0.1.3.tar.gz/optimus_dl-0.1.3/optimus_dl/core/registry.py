"""Registry system for dependency injection and component management.

This module provides a flexible registry pattern that allows components (models,
optimizers, data loaders, etc.) to be registered and instantiated from configuration.
The registry system is the foundation of Optimus-DL's modular architecture, enabling
easy component swapping and configuration-driven instantiation.

Example:
    Basic usage:

    ```python
    # Create a registry
    registry, register, build = make_registry("my_component")

    # Register a component
    @register("my_impl", MyConfig)
    class MyImplementation:
        def __init__(self, cfg: MyConfig):
            self.cfg = cfg

    # Build from config
    config = MyConfig(_name="my_impl", param=1)
    obj = build(config)
    ```
"""

import functools
import logging
import types
from dataclasses import (
    MISSING,
    dataclass,
    fields,
    is_dataclass,
)
from typing import (
    Any,
    TypeVar,
    Union,
    get_args,
    get_origin,
    get_type_hints,
    overload,
)

import omegaconf

# Global registry storage: maps registry_name -> {component_name -> (class, config_class)}
logger = logging.getLogger(__name__)
registries = {}


@dataclass
class RegistryConfigStrict:
    """Strict configuration base class for registry components.

    This is a minimal configuration class that only requires a `_name` field.
    Use this when you don't need additional configuration fields.

    Attributes:
        _name: The registered name of the component to instantiate.
    """

    _name: str | None = None


@dataclass
class RegistryConfig(dict[str, Any]):
    """Flexible configuration base class for registry components.

    This extends RegistryConfigStrict to allow arbitrary additional fields
    via dictionary inheritance. Use this when you need custom configuration
    parameters beyond static fields or for dynamic configurations.

    Attributes:
        _name: The registered name of the component to instantiate.
        extra_fields: Additional fields can be added as dictionary keys.
    """

    _name: str | None = None


C = TypeVar("C", bound=type)
T = TypeVar("T")
CorrectCfg = RegistryConfig | RegistryConfigStrict | omegaconf.DictConfig | dict


def validate_and_cast(cls: Any, cfg: Any, path: str = "") -> Any:
    """Recursively validates and casts config based on cls typings.

    Args:
        cls: The class or type to validate against.
        cfg: The configuration object to validate and cast.
        path: Path prefix to use in error messages, indicating the logical
            location of this config within a larger configuration structure.

    Returns:
        The casted and validated configuration, as an OmegaConf object if applicable.
    """
    res = _validate_and_cast_recursive(cls, cfg, path)
    # Only wrap in OmegaConf if it's a collection or dataclass at the top level.
    # Recursive calls return raw objects to ensure proper dataclass construction.
    if is_dataclass(cls) or get_origin(cls) in (list, dict, list, dict):
        return omegaconf.OmegaConf.create(res)
    return res


def _validate_and_cast_recursive(cls: Any, cfg: Any, path: str = "") -> Any:
    # Only return early for explicit NoneType. Optional/Union[..., None] cases
    # are handled in the Union branch below.
    if cfg is None and cls is type(None):
        return None

    origin = get_origin(cls)
    args = get_args(cls)

    # Handle Union / Optional
    is_union = origin is Union or (
        hasattr(types, "UnionType") and origin is types.UnionType
    )
    if is_union:
        # If NoneType is part of the union and the actual value is None,
        # treat it as a valid match for Optional[...] / Union[..., None].
        if type(None) in args and cfg is None:
            return None

        non_none_args = tuple(arg for arg in args if arg is not type(None))
        last_error: Exception | None = None
        for arg in non_none_args:
            try:
                return _validate_and_cast_recursive(arg, cfg, path)
            except (TypeError, ValueError, AttributeError, AssertionError) as e:
                last_error = e
                continue

        # No union member matched: raise a meaningful error instead of
        # silently converting an invalid value to None.
        type_list = " | ".join(getattr(a, "__name__", str(a)) for a in args)
        msg = (
            f"Config at {path or '<root>'} does not match any type in {type_list}: "
            f"{cfg!r}"
        )
        if last_error is not None:
            raise TypeError(msg) from last_error
        raise TypeError(msg)

    # If cfg is None but the type is not Optional (checked above), it's an error
    if cfg is None:
        raise TypeError(f"Config at {path or '<root>'} is None, but expected {cls}")

    # Handle List
    if origin is list or origin is list:
        if not isinstance(cfg, (list, omegaconf.ListConfig)):
            raise TypeError(f"Expected list at {path}, got {type(cfg)}")

        # If cls is a bare list, we pass items through as-is
        if not args:
            return cfg

        item_type = args[0]
        return [
            _validate_and_cast_recursive(item_type, item, f"{path}[{i}]")
            for i, item in enumerate(cfg)
        ]

    # Handle Dict
    if origin is dict or origin is dict:
        if not isinstance(cfg, (dict, omegaconf.DictConfig)):
            raise TypeError(f"Expected dict at {path}, got {type(cfg)}")

        # If cls is a bare dict, we pass items through as-is
        if not args:
            return cfg

        key_type, val_type = args
        return {
            _validate_and_cast_recursive(
                key_type, k, f"{path}.<key>"
            ): _validate_and_cast_recursive(val_type, v, f"{path}.{k}")
            for k, v in cfg.items()
        }

    # Handle Dataclasses
    if is_dataclass(cls):
        if not isinstance(cfg, (dict, omegaconf.DictConfig)):
            raise TypeError(
                f"Expected dict for dataclass {cls.__name__} at {path}, got {type(cfg)}"
            )

        field_hints = get_type_hints(cls)
        is_flexible = isinstance(cls, type) and issubclass(cls, dict)
        is_strict = isinstance(cls, type) and issubclass(cls, RegistryConfigStrict)

        if is_strict and not is_flexible:
            actual_keys = set(cfg.keys())
            expected_keys = set(field_hints.keys())
            if not actual_keys.issubset(expected_keys):
                raise ValueError(
                    f"Unknown keys at {path} for {cls.__name__}: {actual_keys - expected_keys}"
                )

        init_kwargs = {}
        extra_kwargs = {}
        for f in fields(cls):
            if f.name in cfg:
                init_kwargs[f.name] = _validate_and_cast_recursive(
                    field_hints[f.name],
                    cfg[f.name],
                    f"{path}.{f.name}" if path else f.name,
                )
            elif f.default is not MISSING:
                init_kwargs[f.name] = f.default
            elif f.default_factory is not MISSING:
                init_kwargs[f.name] = f.default_factory()

        if is_flexible:
            for k, v in cfg.items():
                if k not in init_kwargs:
                    extra_kwargs[k] = v

        obj = cls(**init_kwargs)
        if is_flexible:
            obj.update(extra_kwargs)
        return obj

    # Handle primitives
    if cls in (int, float, str, bool):
        value = cfg
        if omegaconf.OmegaConf.is_config(cfg):
            value = omegaconf.OmegaConf.to_container(cfg, resolve=True)

        try:
            if cls is bool and isinstance(value, str):
                return value.lower() in ("true", "1", "yes")
            return cls(value)
        except (ValueError, TypeError) as err:
            raise TypeError(f"Cannot cast {value} to {cls} at {path}") from err

    return cfg


def _get_cfg_path(cfg: CorrectCfg) -> list[str] | None:
    """Get the path of the configuration object."""
    if (
        not omegaconf.OmegaConf.is_config(cfg)
        or not hasattr(cfg, "_metadata")
        or not hasattr(cfg, "_parent")
    ):
        return None

    path = []
    cfg_met = []
    while cfg is not None and cfg._metadata.key is not None:
        path.append(str(cfg._metadata.key))

        if cfg in cfg_met:
            logger.error(f"Circular reference detected in config: {'.'.join(path)}")
            return None

        cfg_met.append(cfg)
        cfg = cfg._parent
    return path[::-1]


def make_registry(registry_name: str, base_class: type | type[Any] | None = None):
    """Create or retrieve a component registry.

    This function creates a new registry or retrieves an existing one. Each registry
    maintains a mapping of component names to their classes and configuration classes.
    The registry pattern enables dependency injection and configuration-driven
    component instantiation.

    Args:
        registry_name: Unique name for the registry (e.g., "model", "optimizer").
        base_class: Optional base class that all registered components must inherit
            from. Used for type checking. If None, any class can be registered.

    Returns:
        registry_dict (dict): The actual registry dictionary (for inspection/debugging)
        register (callable): Decorator function to register components
        build (callable): Function to build instances from configuration

    Example:
        ```python
        registry, register, build = make_registry("model", BaseModel)

        @register("llama", LlamaConfig)
        class Llama(BaseModel):
            def __init__(self, cfg: LlamaConfig):
                self.cfg = cfg

        # Later, build from config
        config = LlamaConfig(_name="llama", n_embd=512)
        model = build(config)

        ```
    Note:
        The registry is stored globally. Multiple calls with the same `registry_name`
        will return the same registry instance.
    """
    if registry_name in registries:
        registry = registries[registry_name]
    else:
        registries[registry_name] = {}
        registry = registries[registry_name]

    def register_arch(name: str, class_name: str, registered_class: type):
        """Register an architecture variant of a base class.

        This allows registering multiple variants (architectures) of a base class.
        For example, you might have a base "llama" model with variants like
        "llama-7b", "llama-13b", "llama-70b".

        Args:
            name: Name of the architecture variant.
            class_name: Name of the base class this variant belongs to.
            registered_class: The class implementing this architecture.

        Returns:
            A decorator function that takes a config factory method.

        Raises:
            AssertionError: If the architecture is already registered or if the
                base class doesn't exist or doesn't have a structured config.

        Example:
            ```python
            @register("llama", LlamaConfig)
            class Llama(BaseModel):
                pass

            @Llama.register_arch("7b")
            def llama_7b_config():
                return LlamaConfig(n_layers=32, n_embd=4096)

            ```"""
        full_name = f"{class_name}-{name}"

        assert (
            full_name not in registry
        ), f"Double registering of {full_name} in {registry_name} registry"

        base_registry = registry.get(class_name, None)
        assert (
            base_registry is not None
        ), f"Base class {class_name} not found in {registry_name} registry"
        assert (
            base_registry[1] is not None
        ), f"Base class {class_name} must have a structured config in {registry_name} registry to register architectures"

        def wrapper(method):
            cfg = method()
            assert (
                cfg is None
                or isinstance(cfg, RegistryConfig)
                or isinstance(cfg, RegistryConfigStrict)
            ), "Configs must be subclasses of RegistryConfig"
            registry[full_name] = (registered_class, cfg)
            return method

        return wrapper

    def register(name: str, cfg: type | None = None):
        """Register a component in the registry.

        This is the main decorator for registering components. It associates a
        component class with a name and optional configuration class.

        Args:
            name: Unique name to register the component under (e.g., "llama", "adamw").
            cfg: Optional configuration class that must be a subclass of
                RegistryConfig or RegistryConfigStrict. If None, the component
                will be instantiated without configuration.

        Returns:
            A decorator function that registers the decorated class.

        Raises:
            AssertionError: If the name is already registered or if cfg is not
                a valid config class.

        Example:
            ```python
            @register("my_model", MyModelConfig)
            class MyModel:
                def __init__(self, cfg: MyModelConfig):
                    self.cfg = cfg

            ```"""
        assert (
            name not in registry
        ), f"Double registering of {name} in {registry_name} registry"
        assert (
            cfg is None
            or issubclass(cfg, RegistryConfig)
            or issubclass(cfg, RegistryConfigStrict)
        ), "Configs must be subclasses of RegistryConfig or RegistryConfigStrict"

        def wrapper(registered_class: C) -> C:
            """Decorator that registers a class in the registry.

            Args:
                registered_class: The class to register.

            Returns:
                The same class (for use as a decorator).
            """
            registry[name] = (registered_class, cfg)
            registered_class.register_arch = functools.partial(
                register_arch,
                class_name=name,
                registered_class=registered_class,
            )
            return registered_class

        return wrapper

    @overload
    def build(
        cfg: CorrectCfg,
        cast_to: type[T],
        **kwargs: Any,
    ) -> T: ...

    @overload
    def build(
        cfg: CorrectCfg,
        cast_to: None = None,
        **kwargs: Any,
    ) -> Any: ...

    def build(
        cfg: CorrectCfg | None,
        cast_to: type[T] | None = None,
        **kwargs: Any,
    ) -> T | Any | None:
        """Build a component instance from configuration.

        This function instantiates a registered component based on its configuration.
        It handles merging default configuration values with provided overrides,
        and supports both structured configs and plain dictionaries.

        Args:
            cfg: Configuration object containing `_name` field specifying which
                component to build. Can be a RegistryConfig, dict, or None.
                If None, returns None. If a string, treats it as the component name.
            cast_to: Optional type to cast the result to. If provided, raises
                AssertionError if the built object is not an instance of this type.
            **kwargs: Additional keyword arguments passed to the component constructor.

        Returns:
            An instance of the registered component, or None if cfg is None.

        Raises:
            AssertionError: If the component name is not found in the registry, or
                if cast_to is provided and the built object is not of that type.

        Example:
            ```python
            config = RegistryConfig(_name="llama", n_embd=512)
            model = build(config, cast_to=BaseModel)
            assert isinstance(model, Llama)

            ```"""
        if cfg is None:
            return None
        cfg_orig = cfg
        if isinstance(cfg, str):
            name: str = cfg
            cfg = {}
        else:
            if not omegaconf.OmegaConf.is_config(cfg):
                cfg = omegaconf.OmegaConf.structured(cfg)
            name: str = cfg["_name"]
        assert name in registry, f"Unknown {name} in {registry_name} registry"
        registered_class, structured_cfg = registry[name]
        structured_cfg_original = structured_cfg
        is_strict = False
        if type(structured_cfg) is type:
            is_strict = issubclass(structured_cfg, RegistryConfigStrict)
            structured_cfg = omegaconf.OmegaConf.merge(
                omegaconf.OmegaConf.structured(structured_cfg), structured_cfg()
            )
        if structured_cfg is not None:
            if is_strict:
                expected_keys = set(structured_cfg.keys())
                try:
                    actual_keys = set(cfg.keys())
                except AttributeError as e:
                    raise ValueError(
                        f"Cannot get true keys for config {type(cfg)}: {cfg}"
                    ) from e

                maybe_path = ".".join(_get_cfg_path(cfg_orig) or ["<root>"])
                assert actual_keys.issubset(expected_keys), (
                    f"For {maybe_path} {structured_cfg_original} expected keys {expected_keys}, "
                    f"got {actual_keys},\n"
                    f"diff: {actual_keys - expected_keys}"
                )
            try:
                cfg = omegaconf.OmegaConf.merge(
                    structured_cfg,
                    omegaconf.OmegaConf.to_container(cfg=cfg, resolve=True),
                )
                if is_strict:
                    cfg = validate_and_cast(structured_cfg_original, cfg)
            except omegaconf.errors.ConfigTypeError:
                logger.error(f"{structured_cfg = }\n====\n{cfg = }")
                raise
            obj = registered_class(cfg, **kwargs)
        else:
            obj = registered_class(**kwargs)

        if cast_to is not None:
            assert isinstance(obj, cast_to), f"Expected {cast_to}, got {type(obj)}"
        if base_class is not None:
            assert isinstance(
                obj, base_class
            ), f"Expected {base_class}, got {type(obj)}"
        return obj

    return registry, register, build


@overload
def build(
    registry_name: str,
    cfg: CorrectCfg,
    cast_to: type[T],
    **kwargs: Any,
) -> T: ...


@overload
def build(
    registry_name: str,
    cfg: CorrectCfg,
    cast_to: None = None,
    **kwargs: Any,
) -> Any: ...


def build(
    registry_name: str,
    cfg: CorrectCfg | None,
    cast_to: type[T] | None = None,
    **kwargs: Any,
) -> T | Any | None:
    """Build a component from a named registry.

    This is a convenience function that builds a component from a registry by name.
    It's useful when you know the registry name but don't have the registry
    functions directly available.

    Args:
        registry_name: Name of the registry to build from (e.g., "model", "optimizer").
        cfg: Configuration object with `_name` field specifying the component.
        cast_to: Optional type to cast the result to.
        **kwargs: Additional arguments passed to the component constructor.

    Returns:
        An instance of the registered component.

    Raises:
        AssertionError: If the registry doesn't exist, the component name is not
            found, or if cast_to is provided and the object is not of that type.

    Example:
        ```python
        config = RegistryConfig(_name="llama", n_embd=512)
        model = build("model", config, cast_to=BaseModel)

        ```"""
    assert registry_name in registries, f"Unknown registry {registry_name}"
    _, _, build_fn = make_registry(registry_name)
    obj = build_fn(cfg, **kwargs)
    if cast_to is not None:
        assert isinstance(obj, cast_to), f"Expected {cast_to}, got {type(obj)}"
    return obj
