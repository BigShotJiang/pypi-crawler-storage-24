__version__ = "26.3.1"
__tool_name__ = "project_cleanup_tool"
__description__ = "Mend Cleanup Tool"
