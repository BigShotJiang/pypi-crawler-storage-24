# IBRAHIMpy (Intelligent Benchmark Relational Analysis for Heuristic Index Modeling)

[![PyPI version](https://badge.fury.io/py/ibrahimpy.svg)](https://badge.fury.io/py/ibrahimpy)
[![Python Versions](https://img.shields.io/pypi/pyversions/ibrahimpy.svg)](https://pypi.org/project/ibrahimpy/)
[![License](https://img.shields.io/github/license/AkmdAshraf/IBRAHIM.svg)](https://github.com/AkmdAshraf/IBRAHIM/blob/main/LICENSE)
[![Downloads](https://pepy.tech/badge/ibrahimpy)](https://pepy.tech/project/ibrahimpy)

A novel machine learning framework for multi-criteria decision analysis and benchmark-based ranking.

## 📊 Overview

IBRAHIMpy is an intelligent analytical model that evaluates multiple records based on many variables, determines the highest benchmark, and computes ranking scores. It combines elements of multi-criteria decision analysis (MCDA) with machine learning for robust, automated benchmarking.

### Key Features

- **Automatic Feature Direction Detection**: Determines whether variables should be maximized or minimized
- **Intelligent Benchmark Generation**: Creates ideal benchmark records based on feature directions
- **Flexible Weight Assignment**: Supports both automatic (ML-based) and manual weight specification
- **0-100 Scoring Scale**: Intuitive, normalized scores for easy interpretation
- **New Record Evaluation**: Compare any new record against the established benchmark
- **Visualization Tools**: Built-in plotting for ranking analysis

## 🚀 Installation

### From PyPI (Recommended)
```bash
pip install ibrahimpy