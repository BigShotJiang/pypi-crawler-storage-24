"""Unit tests for IBRAHIMpy model."""  # CHANGED comment

import unittest
import pandas as pd
import numpy as np
import sys
import os

# Add parent directory to path to import ibrahim
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from ibrahim import IBRAHIM  # Import stays SAME

class TestIBRAHIM(unittest.TestCase):
    """Test cases for IBRAHIMpy model."""  # CHANGED docstring
    
    def setUp(self):
        """Set up test data for IBRAHIMpy tests."""  # CHANGED docstring
        self.data = pd.DataFrame({
            'feature1': [1, 2, 3, 4, 5],
            'feature2': [5, 4, 3, 2, 1],
            'feature3': [2, 3, 4, 5, 6]
        })
    
    def test_initialization(self):
        """Test IBRAHIMpy model initialization."""  # CHANGED docstring
        model = IBRAHIM()  # Class name stays SAME
        self.assertIsNotNone(model)
    
    def test_fit(self):
        """Test IBRAHIMpy model fitting."""  # CHANGED docstring
        model = IBRAHIM()
        model.fit(self.data)
        self.assertTrue(model.is_fitted)
    
    def test_rank(self):
        """Test IBRAHIMpy model ranking."""  # CHANGED docstring
        model = IBRAHIM()
        model.fit(self.data)
        rankings = model.rank()
        self.assertIn('score', rankings.columns)
        self.assertIn('rank', rankings.columns)
    
    def test_compare_new(self):
        """Test IBRAHIMpy new record comparison."""  # CHANGED docstring
        model = IBRAHIM()
        model.fit(self.data)
        
        new_record = {'feature1': 3, 'feature2': 3, 'feature3': 4}
        result = model.compare_new(new_record)
        
        self.assertIn('score', result)
        self.assertIn('distance', result)
    
    def test_directions(self):
        """Test IBRAHIMpy manual directions."""  # CHANGED docstring
        model = IBRAHIM(auto_weights=False)
        directions = {'feature1': 'max', 'feature2': 'min', 'feature3': 'max'}
        model.fit(self.data, directions=directions)
        self.assertEqual(model.directions_, directions)
    
    def test_score_range(self):
        """Test IBRAHIMpy scores are between 0 and 100."""  # CHANGED docstring
        model = IBRAHIM(auto_weights=True)
        model.fit(self.data)
        rankings = model.rank()
        self.assertTrue(all(rankings['score'] >= 0))
        self.assertTrue(all(rankings['score'] <= 100))

if __name__ == '__main__':
    unittest.main()