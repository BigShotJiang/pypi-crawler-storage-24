"""IBRAHIM - Intelligent Benchmark Relational Analysis"""

# These imports will work once all files are created
from .model import IBRAHIM
from .utils import normalize_data, detect_directions, calculate_weights
from .visualization import plot_ranking, plot_feature_importance, plot_radar_comparison

__version__ = "0.1.0"
__all__ = [
    "IBRAHIM",
    "normalize_data", 
    "detect_directions", 
    "calculate_weights",
    "plot_ranking", 
    "plot_feature_importance", 
    "plot_radar_comparison"
]