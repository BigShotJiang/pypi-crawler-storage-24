"""Utility functions for IBRAHIM"""
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler, RobustScaler

def normalize_data(X, method='minmax'):
    """Normalize the input data"""
    if method == 'minmax':
        scaler = MinMaxScaler()
    elif method == 'zscore':
        scaler = StandardScaler()
    elif method == 'robust':
        scaler = RobustScaler()
    else:
        raise ValueError(f"Unknown method: {method}")
    
    X_scaled = pd.DataFrame(
        scaler.fit_transform(X),
        columns=X.columns,
        index=X.index
    )
    return X_scaled, scaler

def detect_directions(X_scaled, y=None, manual_directions=None):
    """Determine feature directions"""
    if manual_directions:
        return manual_directions
    
    directions = {}
    for col in X_scaled.columns:
        directions[col] = 'max'  # Default
    return directions

def calculate_weights(X_scaled, y=None, manual_weights=None, auto_weights=True, random_state=42):
    """Calculate feature weights"""
    if manual_weights:
        weights = manual_weights
    elif auto_weights:
        # Simple variance-based weights
        variances = X_scaled.var()
        weights = (variances / variances.sum()).to_dict()
    else:
        n_features = X_scaled.shape[1]
        weights = {col: 1/n_features for col in X_scaled.columns}
    
    # Normalize
    total = sum(weights.values())
    weights = {k: v/total for k, v in weights.items()}
    return weights