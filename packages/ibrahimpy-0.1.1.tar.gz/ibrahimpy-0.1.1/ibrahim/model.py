"""Core IBRAHIM model implementation"""
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestRegressor
from scipy import stats

class IBRAHIM:
    def __init__(self, auto_weights=True, normalization='minmax', 
                 distance_metric='euclidean', random_state=42):
        self.auto_weights = auto_weights
        self.normalization = normalization
        self.distance_metric = distance_metric
        self.random_state = random_state
        self.is_fitted = False
    
    def fit(self, X, y=None, directions=None, weights=None):
        self.feature_names_ = X.columns.tolist()
        self.n_features_ = X.shape[1]
        self.X_original_ = X.copy()
        
        # Simple minmax scaling for now
        self.scaler_ = MinMaxScaler()
        self.X_scaled_ = pd.DataFrame(
            self.scaler_.fit_transform(X),
            columns=X.columns,
            index=X.index
        )
        
        # Default directions (all max)
        self.directions_ = {col: 'max' for col in self.feature_names_}
        
        # Simple benchmark
        self.benchmark_ = {}
        for col in self.feature_names_:
            if self.directions_[col] == 'max':
                self.benchmark_[col] = self.X_scaled_[col].max()
            else:
                self.benchmark_[col] = self.X_scaled_[col].min()
        
        # Simple weights (equal)
        self.weights_ = {col: 1/self.n_features_ for col in self.feature_names_}
        
        self.is_fitted = True
        return self
    
    def calculate_distances(self, X=None):
        if X is None:
            X_scaled = self.X_scaled_
        else:
            X_scaled = pd.DataFrame(
                self.scaler_.transform(X),
                columns=X.columns,
                index=X.index
            )
        
        distances = []
        weight_vector = np.array([self.weights_[col] for col in self.feature_names_])
        benchmark_vector = np.array([self.benchmark_[col] for col in self.feature_names_])
        
        for idx in X_scaled.index:
            record = X_scaled.loc[idx].values
            dist = np.sqrt(np.sum(weight_vector * (record - benchmark_vector)**2))
            distances.append(dist)
        
        return np.array(distances)
    
    def rank(self, X=None):
        distances = self.calculate_distances(X)
        
        if X is None:
            ranking_df = self.X_original_.copy()
        else:
            ranking_df = X.copy()
        
        max_dist = distances.max()
        min_dist = distances.min()
        
        if max_dist > min_dist:
            scores = 100 * (1 - (distances - min_dist) / (max_dist - min_dist))
        else:
            scores = np.full_like(distances, 100)
        
        ranking_df['distance'] = distances
        ranking_df['score'] = scores
        ranking_df['rank'] = pd.Series(scores).rank(ascending=False, method='min').astype(int).values
        
        return ranking_df.sort_values('rank')
    
    def compare_new(self, new_record):
        new_df = pd.DataFrame([new_record])
        distance = self.calculate_distances(new_df)[0]
        
        existing = self.rank()
        all_distances = np.append(existing['distance'].values, distance)
        
        max_dist = all_distances.max()
        min_dist = all_distances.min()
        
        if max_dist > min_dist:
            score = 100 * (1 - (distance - min_dist) / (max_dist - min_dist))
        else:
            score = 100
        
        return {'score': score, 'distance': distance}
    
    def get_summary(self):
        ranking = self.rank()
        return {
            'n_features': self.n_features_,
            'score_stats': {
                'mean': ranking['score'].mean(),
                'min': ranking['score'].min(),
                'max': ranking['score'].max()
            }
        }