"""
MCP server for blq.

Provides tools, resources, and prompts for AI agent integration.

Usage:
    blq mcp serve                    # stdio transport (for Claude Desktop)
    blq mcp serve --transport sse    # SSE transport (for HTTP clients)
    blq mcp serve --safe-mode        # Disable state-modifying tools
    blq mcp serve -D exec,clean      # Disable specific tools

Security:
    Tools can be disabled via CLI flags:
        blq mcp serve --safe-mode    # Disables exec, clean, register_command, unregister_command
        blq mcp serve -D exec,clean  # Disable specific tools

    Or via .lq/config.toml:
        mcp:
          disabled_tools:
            - exec
            - clean
            - register_command
            - unregister_command

    Or via environment variable:
        BLQ_MCP_DISABLED_TOOLS=exec,clean,register_command
"""

from __future__ import annotations

import json
import os
import re as _re
import shlex
import subprocess
import sys
from typing import Any

import pandas as pd  # type: ignore[import-untyped]
from fastmcp import FastMCP

from blq.commands.ci_cmd import (
    _compute_diff,
    _find_baseline_run,
    _find_current_run,
    _generate_script,
)
from blq.commands.core import EventRef, get_all_suppressed_fingerprints
from blq.commands.management import resolve_ref
from blq.commands.query_cmd import parse_filter_expression
from blq.commands.report_cmd import _collect_report_data, _generate_markdown_report
from blq.output import format_context
from blq.storage import BlqStorage

# ============================================================================
# Security Configuration
# ============================================================================

# Tools that modify state and can be disabled for security (--safe-mode / -S)
# These are the tools disabled when running in safe mode
SAFE_MODE_DISABLED_TOOLS = {
    "exec",  # Can run arbitrary commands
    "clean",  # Can delete data
    "register_command",  # Can modify command registry
    "unregister_command",  # Can modify command registry
}

# Cache for disabled tools (loaded once at startup)
_disabled_tools: set[str] | None = None


def _init_disabled_tools(
    cli_disabled: str | None = None,
    safe_mode: bool = False,
) -> None:
    """Initialize disabled tools from CLI arguments.

    This must be called before any tools are invoked, typically at server startup.

    Args:
        cli_disabled: Comma-separated list of tools to disable from --disabled-tools
        safe_mode: If True, disable all tools in SAFE_MODE_DISABLED_TOOLS
    """
    global _disabled_tools

    disabled: set[str] = set()

    # Add safe mode tools first
    if safe_mode:
        disabled.update(SAFE_MODE_DISABLED_TOOLS)

    # Add CLI-specified tools
    if cli_disabled:
        disabled.update(t.strip() for t in cli_disabled.split(",") if t.strip())

    # Check environment variable
    env_disabled = os.environ.get("BLQ_MCP_DISABLED_TOOLS", "")
    if env_disabled:
        disabled.update(t.strip() for t in env_disabled.split(",") if t.strip())

    # Check .lq/config.toml
    try:
        from blq.cli import BlqConfig

        config = BlqConfig.find()
        if config and hasattr(config, "mcp_config"):
            mcp_config = config.mcp_config or {}
            disabled_list = mcp_config.get("disabled_tools", [])
            if isinstance(disabled_list, list):
                disabled.update(disabled_list)
    except Exception:
        pass

    _disabled_tools = disabled


def _load_disabled_tools() -> set[str]:
    """Get the set of disabled tools.

    If _init_disabled_tools() hasn't been called, loads from config/environment only.
    """
    global _disabled_tools
    if _disabled_tools is not None:
        return _disabled_tools

    # Fallback: initialize without CLI args
    _init_disabled_tools()
    return _disabled_tools or set()


def _check_tool_enabled(tool_name: str) -> None:
    """Check if a tool is enabled. Raises error if disabled."""
    disabled = _load_disabled_tools()
    if tool_name in disabled:
        raise PermissionError(
            f"Tool '{tool_name}' is disabled. "
            f"Enable it by removing from mcp.disabled_tools in .lq/config.toml "
            f"or BLQ_MCP_DISABLED_TOOLS environment variable."
        )


def _to_json_safe(value: Any) -> Any:
    """Convert pandas NA/NaT values to None and UUID to string for JSON serialization."""
    if pd.isna(value):
        return None
    # Handle UUID objects
    if hasattr(value, "hex") and hasattr(value, "int"):
        return str(value)
    return value


def _safe_int(value: Any) -> int | None:
    """Safely convert a value to int, returning None for NA/null values."""
    if pd.isna(value):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _compute_status(error_count: int, warning_count: int, exit_code: int | None) -> str:
    """Compute run status from counts and exit code."""
    if exit_code == -1:
        return "TIMEOUT"
    if error_count > 0:
        return "FAIL"
    if exit_code is not None and exit_code != 0:
        return "FAIL"
    if warning_count > 0:
        return "WARN"
    return "OK"


# Create the MCP server
mcp = FastMCP(
    "blq",
    instructions=(
        "Build Log Query - capture and query build/test logs. "
        "Use tools to run builds, query errors, and analyze results. "
        "Read blq://guide for detailed usage instructions. "
        "The database is shared with the CLI - users can run 'blq run build' "
        "and you can query the results, or vice versa. "
        "Start with status() or commands() to see current state. "
        "Use errors(), event(ref), and context(ref) to drill down into issues. "
        "Use output() to search/filter captured logs (not shell pipes). "
        "Docs: https://blq-cli.readthedocs.io/en/latest/"
    ),
)


def _get_storage() -> BlqStorage:
    """Get BlqStorage for current directory."""
    return BlqStorage.open()


def _get_suppress_condition(include_suppressed: bool = False) -> str | None:
    """Get SQL condition to exclude suppressed fingerprints.

    Args:
        include_suppressed: If True, return None (no filtering)

    Returns:
        SQL condition string like "(fingerprint IS NULL OR fingerprint NOT IN (...))"
        or None if no filtering needed.
    """
    if include_suppressed:
        return None

    try:
        from blq.cli import BlqConfig

        config = BlqConfig.find()
        if config is None:
            return None

        suppressed = get_all_suppressed_fingerprints(config)
        if not suppressed:
            return None

        fp_list = ", ".join(f"'{fp}'" for fp in suppressed)
        return f"(fingerprint IS NULL OR fingerprint NOT IN ({fp_list}))"
    except Exception:
        return None


def _parse_ref(ref: str, storage: Any = None) -> tuple[str | None, int, int]:
    """Parse event reference into (tag, run_serial, event_id).

    Supports relative references like +1:2 (event 2 in most recent run) or
    test:+1:3 (event 3 in most recent test run).

    Formats:
    - "tag:serial:event" -> (tag, serial, event)
    - "serial:event" -> (None, serial, event)
    - "+N:event" -> relative: event in Nth most recent run
    - "tag:+N:event" -> relative: event in Nth most recent run of tag

    Args:
        ref: Reference string to parse
        storage: Optional storage backend for resolving relative refs

    Returns:
        Tuple of (tag or None, run_serial, event_id)
    """
    parsed = EventRef.parse(ref)

    # Resolve relative references if storage provided
    if parsed.is_relative:
        if storage is None:
            storage = _get_storage()
        parsed = resolve_ref(parsed, storage)

    if parsed.event_id is None:
        raise ValueError(f"Invalid ref format: {ref}. Expected event reference with event_id")
    if parsed.run_id is None:
        raise ValueError(f"Invalid ref format: {ref}. Could not determine run_id")

    return parsed.tag, parsed.run_id, parsed.event_id


def _parse_run_ref(ref: str, storage: Any = None) -> tuple[str | None, int]:
    """Parse run reference into (tag, run_serial).

    Supports relative references like +1 (most recent run) or
    test:+1 (most recent test run).

    Formats:
    - "tag:serial" -> (tag, serial)
    - "serial" -> (None, serial)
    - "+N" -> relative: Nth most recent run
    - "tag:+N" -> relative: Nth most recent run of tag

    Args:
        ref: Reference string to parse
        storage: Optional storage backend for resolving relative refs

    Returns:
        Tuple of (tag or None, run_serial)
    """
    parsed = EventRef.parse(ref)

    # Resolve relative references if storage provided
    if parsed.is_relative:
        if storage is None:
            storage = _get_storage()
        parsed = resolve_ref(parsed, storage)

    if parsed.run_id is None:
        raise ValueError(f"Invalid ref format: {ref}. Could not determine run_id")

    return parsed.tag, parsed.run_id


# ============================================================================
# Implementation Functions
# (Separated from decorators so they can be called from resources/prompts)
# ============================================================================


def _build_preview(
    output_stats: dict[str, Any],
    status: str,
    has_errors: bool,
) -> dict[str, Any]:
    """Build preview field for a concise run/exec response.

    Returns a dict of fields to merge into the concise response.
    On failure or when errors are present, includes a ``preview`` showing
    the first and last few lines of output (head + separator + tail) so
    agents see both the first error and the summary line.

    On clean success (no errors, OK status), no preview is included.
    """
    head = output_stats.get("head", [])
    tail = output_stats.get("tail", [])
    total_lines = output_stats.get("lines", 0)
    preview_n = 3  # lines from each end

    result: dict[str, Any] = {}

    if (status == "OK" and not has_errors) or (not head and not tail):
        return result

    if total_lines <= preview_n * 2 + 1:
        # Short output — show all available lines (tail contains the last N,
        # but for short output head and tail overlap; use tail as the superset)
        result["preview"] = tail if len(tail) >= len(head) else head
    else:
        result["preview"] = (
            head[:preview_n]
            + [f"... ({total_lines - preview_n * 2} more lines, use output() to see full log)"]
            + tail[-preview_n:]
        )

    return result


def _resolve_command_lines(command: str, lines: str | None) -> str | None:
    """Resolve effective lines spec: explicit param > command config > None."""
    if lines is not None:
        return lines
    try:
        from blq.cli import BlqConfig

        config = BlqConfig.find()
        if config and command in config.commands:
            return config.commands[command].lines
    except Exception:
        pass
    return None


def _attach_output(concise: dict[str, Any], run_id: int | None, lines_spec: str | None) -> None:
    """Fetch output lines and attach to the concise response dict.

    When output is attached, the preview field is removed (output supersedes it).
    """
    if lines_spec is None or run_id is None:
        return
    result = _output_impl(run_id, lines=lines_spec)
    if "content" in result:
        concise["output"] = result["content"]
    elif "error" in result:
        concise["output"] = f"(output error: {result['error']})"
    else:
        concise["output"] = "(no captured output)"
    # Output supersedes preview
    concise.pop("preview", None)


def _run_impl(
    command: str,
    args: dict[str, str] | list[str] | None = None,
    extra: list[str] | None = None,
    timeout: int | None = None,
    lines: str | None = None,
) -> dict[str, Any]:
    """Implementation of run command (for registered commands).

    Args:
        command: Registered command name
        args: Either a dict of named arguments (recommended) or a list of CLI args
        extra: Passthrough arguments appended to command (when args is a dict)
        timeout: Command timeout in seconds
        lines: Line selection spec for output (e.g., '+20-' for last 20 lines)
    """
    # Build command for blq run (registered commands only)
    # Use sys.executable to ensure we use the same Python/venv as the MCP server
    cmd_parts = [sys.executable, "-m", "blq", "run", "--json", "--quiet"]
    if timeout:
        cmd_parts.extend(["--timeout", str(timeout)])
    cmd_parts.append(command)

    if args:
        if isinstance(args, dict):
            # Named arguments: convert to key=value format
            for key, value in args.items():
                cmd_parts.append(f"{key}={value}")
        else:
            # List of CLI args (backward compatible)
            cmd_parts.extend(args)

    # Add passthrough args after :: to ensure they're not parsed as placeholder values
    if extra:
        cmd_parts.append("::")
        cmd_parts.extend(extra)

    try:
        # Add buffer to subprocess timeout so CLI timeout fires first
        subprocess_timeout = timeout + 10 if timeout else None
        proc = subprocess.run(
            cmd_parts,
            capture_output=True,
            text=True,
            timeout=subprocess_timeout,
        )

        # Parse JSON output and return concise response
        if proc.stdout.strip():
            try:
                full_result = json.loads(proc.stdout)
                # Build concise response with essential fields
                run_id = full_result.get("run_id")
                source_name = full_result.get("source_name") or command
                exit_code = full_result.get("exit_code", 0)
                summary = full_result.get("summary", {})
                errors = full_result.get("errors", [])
                status = full_result.get("status", "FAIL" if exit_code != 0 else "OK")
                has_errors = exit_code != 0 or len(errors) > 0

                output_stats = full_result.get("output_stats", {})
                warnings = full_result.get("warnings", [])
                infos = full_result.get("infos", [])

                concise: dict[str, Any] = {
                    "run_ref": f"{source_name}:{run_id}" if run_id else None,
                    "cmd": full_result.get("command"),
                    "status": status,
                    "exit_code": exit_code,
                    "duration_sec": round(full_result.get("duration_sec", 0), 1),
                    "summary": summary,
                    "output_stats": {
                        "lines": output_stats.get("lines", 0),
                        "bytes": output_stats.get("bytes", 0),
                    },
                }

                # Include status_reason when present
                status_reason = full_result.get("status_reason")
                if status_reason:
                    concise["status_reason"] = status_reason

                # Include errors (capped at 10, summary has total count)
                if errors:
                    concise["errors"] = errors[:10]

                # Include warnings (top 5)
                if warnings:
                    concise["warnings"] = warnings[:5]

                # Include info/summary events
                if infos:
                    concise["infos"] = infos[:5]

                # Resolve lines spec: explicit param > command config > None
                effective_lines = _resolve_command_lines(command, lines)

                if effective_lines:
                    _attach_output(concise, run_id, effective_lines)
                else:
                    # Include preview on failure/warn
                    preview = _build_preview(output_stats, status, has_errors)
                    concise.update(preview)

                    # When no infos and no preview, fall back to output tail
                    if not infos and "preview" not in preview:
                        tail = output_stats.get("tail", [])
                        if tail:
                            concise["output_tail"] = tail[-3:]

                return concise
            except json.JSONDecodeError:
                pass

        # Check if this was a "not registered" error
        if "is not a registered command" in proc.stderr:
            return {
                "run_ref": None,
                "status": "FAIL",
                "exit_code": proc.returncode,
                "error": f"'{command}' is not registered. Use the run tool with exec mode.",
                "summary": {"total_events": 0, "errors": 0, "warnings": 0},
            }

        # Fallback: construct basic result
        return {
            "run_ref": None,
            "status": "FAIL" if proc.returncode != 0 else "OK",
            "exit_code": proc.returncode,
            "summary": {"total_events": 0, "errors": 0, "warnings": 0},
        }
    except subprocess.TimeoutExpired:
        return {
            "run_ref": None,
            "status": "FAIL",
            "exit_code": -1,
            "error": f"Command timed out after {timeout} seconds",
            "summary": {"total_events": 0, "errors": 0, "warnings": 0},
        }
    except Exception as e:
        return {
            "run_ref": None,
            "status": "FAIL",
            "exit_code": -1,
            "error": str(e),
            "summary": {"total_events": 0, "errors": 0, "warnings": 0},
        }


class _ExecTracker:
    """Track commands run via the exec tool within an MCP session."""

    def __init__(self) -> None:
        self._counts: dict[str, int] = {}  # normalized_cmd -> count
        self._originals: dict[str, str] = {}  # normalized_cmd -> first original form

    def record(self, command: str) -> int:
        """Record a command execution. Returns the occurrence count."""
        key = _normalize_cmd(command)
        self._counts[key] = self._counts.get(key, 0) + 1
        if key not in self._originals:
            self._originals[key] = command
        return self._counts[key]

    def get_original(self, command: str) -> str:
        """Get the first-seen form of a command."""
        return self._originals.get(_normalize_cmd(command), command)

    def reset(self) -> None:
        """Clear all tracking state."""
        self._counts.clear()
        self._originals.clear()


_exec_tracker = _ExecTracker()


def _find_matching_registered_command(full_cmd: str) -> tuple[str, list[str]] | None:
    """Check if command matches a registered command prefix.

    Args:
        full_cmd: Full command string to check

    Returns:
        Tuple of (command_name, extra_args) if match found, None otherwise
    """
    try:
        from blq.cli import BlqConfig

        config = BlqConfig.find()
        if config is None:
            return None

        normalized_full = _normalize_cmd(full_cmd)

        for name, cmd in config.commands.items():
            # Skip template commands (they don't have a fixed cmd)
            if cmd.cmd is None:
                continue
            normalized_registered = _normalize_cmd(cmd.cmd)

            # Check if full command starts with registered command
            if normalized_full.startswith(normalized_registered):
                # Extract extra args
                remainder = normalized_full[len(normalized_registered) :].strip()
                if remainder:
                    extra_args = remainder.split()
                else:
                    extra_args = []
                return name, extra_args

        return None
    except Exception:
        return None


def _exec_impl(
    command: str,
    args: list[str] | None = None,
    timeout: int | None = None,
    shell: bool = False,
    lines: str | None = None,
) -> dict[str, Any]:
    """Implementation of exec command (for ad-hoc shell commands).

    If the command matches a registered command prefix, uses run() instead
    for cleaner refs.

    Args:
        command: Shell command to run
        args: Additional arguments to append
        timeout: Timeout in seconds
        shell: If True, skip pipe detection and pass command as a single
               argument for shell interpretation
        lines: Line selection spec for output (e.g., '+20-' for last 20 lines)
    """
    # Build full command string
    full_cmd = command
    if args:
        full_cmd = f"{command} {' '.join(args)}"

    # Detect shell pipes/redirects unless shell=True
    if not shell:
        pipe_error = _detect_shell_pipes(full_cmd)
        if pipe_error is not None:
            return pipe_error

    # Check if this matches a registered command (skip for shell mode)
    if not shell:
        match = _find_matching_registered_command(full_cmd)
        if match:
            name, extra_args = match
            result = _run_impl(
                name, extra=extra_args if extra_args else None, timeout=timeout, lines=lines
            )
            result["matched_command"] = name
            if extra_args:
                result["extra_args"] = extra_args
            return result

    # No match - run as ad-hoc exec
    # Use sys.executable to ensure we use the same Python/venv as the MCP server
    cmd_parts = [sys.executable, "-m", "blq", "exec", "--json", "--quiet"]
    if timeout:
        cmd_parts.extend(["--timeout", str(timeout)])

    if shell:
        # Pass as single argument so CLI can forward to shell
        cmd_parts.extend(["--", full_cmd])
    else:
        # Split command into parts since CLI uses REMAINDER parsing
        cmd_parts.extend(shlex.split(command))
        if args:
            cmd_parts.extend(args)

    try:
        # Add buffer to subprocess timeout so CLI timeout fires first
        subprocess_timeout = timeout + 10 if timeout else None
        proc = subprocess.run(
            cmd_parts,
            capture_output=True,
            text=True,
            timeout=subprocess_timeout,
        )

        # Parse JSON output and return concise response
        if proc.stdout.strip():
            try:
                full_result = json.loads(proc.stdout)
                # Build concise response with essential fields
                run_id = full_result.get("run_id")
                source_name = full_result.get("source_name") or "exec"
                exit_code = full_result.get("exit_code", 0)
                summary = full_result.get("summary", {})
                errors = full_result.get("errors", [])
                status = full_result.get("status", "FAIL" if exit_code != 0 else "OK")
                has_errors = exit_code != 0 or len(errors) > 0

                output_stats = full_result.get("output_stats", {})
                warnings = full_result.get("warnings", [])
                infos = full_result.get("infos", [])

                concise: dict[str, Any] = {
                    "run_ref": f"{source_name}:{run_id}" if run_id else None,
                    "cmd": full_result.get("command"),
                    "status": status,
                    "exit_code": exit_code,
                    "duration_sec": round(full_result.get("duration_sec", 0), 1),
                    "summary": summary,
                    "output_stats": {
                        "lines": output_stats.get("lines", 0),
                        "bytes": output_stats.get("bytes", 0),
                    },
                }

                # Include status_reason when present
                status_reason = full_result.get("status_reason")
                if status_reason:
                    concise["status_reason"] = status_reason

                # Include errors (capped at 10, summary has total count)
                if errors:
                    concise["errors"] = errors[:10]

                # Include warnings (top 5)
                if warnings:
                    concise["warnings"] = warnings[:5]

                # Include info/summary events
                if infos:
                    concise["infos"] = infos[:5]

                if lines:
                    _attach_output(concise, run_id, lines)
                else:
                    # Include preview on failure/warn
                    preview = _build_preview(output_stats, status, has_errors)
                    concise.update(preview)

                    # When no infos and no preview, fall back to output tail
                    if not infos and "preview" not in preview:
                        tail = output_stats.get("tail", [])
                        if tail:
                            concise["output_tail"] = tail[-3:]

                # Recommend registration for repeated ad-hoc commands
                recommendation = _build_registration_recommendation(full_cmd)
                if recommendation is not None:
                    concise["recommendation"] = recommendation

                return concise
            except json.JSONDecodeError:
                pass

        # Fallback: construct basic result
        return {
            "run_ref": None,
            "status": "FAIL" if proc.returncode != 0 else "OK",
            "exit_code": proc.returncode,
            "summary": {"total_events": 0, "errors": 0, "warnings": 0},
        }
    except subprocess.TimeoutExpired:
        return {
            "run_ref": None,
            "status": "FAIL",
            "exit_code": -1,
            "error": f"Command timed out after {timeout} seconds",
            "summary": {"total_events": 0, "errors": 0, "warnings": 0},
        }
    except Exception as e:
        return {
            "run_ref": None,
            "status": "FAIL",
            "exit_code": -1,
            "error": str(e),
            "summary": {"total_events": 0, "errors": 0, "warnings": 0},
            "errors": [],
        }


def _query_impl(
    sql: str | None = None,
    filter: str | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    """Implementation of query command.

    Args:
        sql: Raw SQL query
        filter: Simple filter expressions (e.g., "severity=error", "ref_file~test")
        limit: Max rows to return
    """
    try:
        store = _get_storage()
        conn = store.connection

        # Build SQL from filter expressions if provided
        if filter and not sql:
            # Parse filter expressions (comma or space separated)
            expressions = []
            for expr in filter.replace(",", " ").split():
                expr = expr.strip()
                if expr:
                    try:
                        expressions.append(parse_filter_expression(expr))
                    except ValueError as e:
                        return {"columns": [], "rows": [], "row_count": 0, "error": str(e)}

            if expressions:
                where_clause = " AND ".join(expressions)
                sql = f"SELECT * FROM blq_load_events() WHERE {where_clause}"
            else:
                sql = "SELECT * FROM blq_load_events()"

        if not sql:
            return {
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": "Either sql or filter must be provided",
            }

        # Add LIMIT if not present (basic safety)
        sql_upper = sql.upper()
        if "LIMIT" not in sql_upper:
            sql = f"SELECT * FROM ({sql}) LIMIT {limit}"

        result = conn.sql(sql)
        columns = result.columns
        rows = result.fetchall()

        return {
            "columns": columns,
            "rows": [list(row) for row in rows],
            "row_count": len(rows),
        }
    except FileNotFoundError:
        return {"columns": [], "rows": [], "row_count": 0, "error": "No lq repository found"}
    except Exception as e:
        return {"columns": [], "rows": [], "row_count": 0, "error": str(e)}


def _errors_impl(
    limit: int = 20,
    run_id: int | None = None,
    source: str | None = None,
    file_pattern: str | None = None,
    include_suppressed: bool = False,
    all_runs: bool = False,
) -> dict[str, Any]:
    """Implementation of errors command."""
    try:
        storage = _get_storage()
        if not storage.has_data():
            return {"errors": [], "total_count": 0}

        # Build WHERE conditions
        conditions = ["severity = 'error'"]

        # Default to last run unless all_runs=True or specific run/source provided
        if run_id is not None:
            conditions.append(f"run_serial = {run_id}")
        elif source:
            conditions.append(f"source_name = '{source}'")
        elif not all_runs:
            # Default: only show errors from the most recent run
            last_run = storage.sql("SELECT MAX(run_serial) FROM blq_load_events()").fetchone()
            if last_run and last_run[0]:
                conditions.append(f"run_serial = {last_run[0]}")
        if file_pattern:
            conditions.append(f"ref_file LIKE '{file_pattern}'")

        # Apply suppression filter
        suppress_condition = _get_suppress_condition(include_suppressed)
        if suppress_condition:
            conditions.append(suppress_condition)

        where = " AND ".join(conditions)

        # Get total count
        count_result = storage.sql(
            f"SELECT COUNT(*) FROM blq_load_events() WHERE {where}"
        ).fetchone()
        total_count = count_result[0] if count_result else 0

        # Get errors - use ref column from view
        df = storage.sql(f"""
            SELECT * FROM blq_load_events()
            WHERE {where}
            ORDER BY run_serial DESC, event_id
            LIMIT {limit}
        """).df()

        error_list = []
        for _, row in df.iterrows():
            error_list.append(
                {
                    "ref": _to_json_safe(row.get("ref")),
                    "run_ref": _to_json_safe(row.get("run_ref")),
                    "ref_file": _to_json_safe(row.get("ref_file")),
                    "ref_line": _safe_int(row.get("ref_line")),
                    "ref_column": _safe_int(row.get("ref_column")),
                    "message": _to_json_safe(row.get("message")),
                    "tool_name": _to_json_safe(row.get("tool_name")),
                    "category": _to_json_safe(row.get("category")),
                }
            )

        return {"errors": error_list, "total_count": total_count}
    except FileNotFoundError:
        return {"errors": [], "total_count": 0}


def _warnings_impl(
    limit: int = 20,
    run_id: int | None = None,
    source: str | None = None,
    include_suppressed: bool = False,
    all_runs: bool = False,
) -> dict[str, Any]:
    """Implementation of warnings command."""
    try:
        storage = _get_storage()
        if not storage.has_data():
            return {"warnings": [], "total_count": 0}

        # Build WHERE conditions
        conditions = ["severity = 'warning'"]

        # Default to last run unless all_runs=True or specific run/source provided
        if run_id is not None:
            conditions.append(f"run_serial = {run_id}")
        elif source:
            conditions.append(f"source_name = '{source}'")
        elif not all_runs:
            # Default: only show warnings from the most recent run
            last_run = storage.sql("SELECT MAX(run_serial) FROM blq_load_events()").fetchone()
            if last_run and last_run[0]:
                conditions.append(f"run_serial = {last_run[0]}")

        # Apply suppression filter
        suppress_condition = _get_suppress_condition(include_suppressed)
        if suppress_condition:
            conditions.append(suppress_condition)

        where = " AND ".join(conditions)

        # Get total count
        count_result = storage.sql(
            f"SELECT COUNT(*) FROM blq_load_events() WHERE {where}"
        ).fetchone()
        total_count = count_result[0] if count_result else 0

        # Get warnings - use ref column from view
        df = storage.sql(f"""
            SELECT * FROM blq_load_events()
            WHERE {where}
            ORDER BY run_serial DESC, event_id
            LIMIT {limit}
        """).df()

        warning_list = []
        for _, row in df.iterrows():
            warning_list.append(
                {
                    "ref": _to_json_safe(row.get("ref")),
                    "run_ref": _to_json_safe(row.get("run_ref")),
                    "ref_file": _to_json_safe(row.get("ref_file")),
                    "ref_line": _safe_int(row.get("ref_line")),
                    "ref_column": _safe_int(row.get("ref_column")),
                    "message": _to_json_safe(row.get("message")),
                    "tool_name": _to_json_safe(row.get("tool_name")),
                    "category": _to_json_safe(row.get("category")),
                }
            )

        return {"warnings": warning_list, "total_count": total_count}
    except FileNotFoundError:
        return {"warnings": [], "total_count": 0}


def _try_extract_live_events(
    storage: BlqStorage,
    run_id: int | None,
    source: str | None,
    severity: str | None,
    file_pattern: str | None,
    limit: int,
    all_runs: bool,
) -> dict[str, Any] | None:
    """Try to extract events from a running process's live output.

    If the specified run/source refers to a pending (running) process,
    extract events from its live output file. Otherwise returns None
    to indicate normal database query should be used.

    Args:
        storage: Storage backend
        run_id: Specific run ID to check
        source: Source name to check
        severity: Severity filter
        file_pattern: File pattern filter
        limit: Max events to return
        all_runs: If True, don't try live extraction

    Returns:
        Dict with events if live extraction was performed, None otherwise
    """
    # Don't do live extraction when querying all runs
    if all_runs:
        return None

    # Determine which attempt to check
    attempt_info = None

    if run_id is not None:
        # Check if this specific run is pending
        result = storage.sql(f"""
            SELECT attempt_id, status, format_hint, tag, run_id
            FROM blq_load_attempts()
            WHERE run_id = {run_id}
        """).fetchone()
        if result and result[1] == "pending":
            attempt_info = {
                "attempt_id": result[0],
                "format_hint": result[2] or "auto",
                "tag": result[3],
                "run_id": result[4],
            }
    elif source:
        # Check if most recent run for this source is pending
        result = storage.sql(f"""
            SELECT attempt_id, status, format_hint, tag, run_id
            FROM blq_load_attempts()
            WHERE source_name = '{source}' OR tag = '{source}'
            ORDER BY started_at DESC
            LIMIT 1
        """).fetchone()
        if result and result[1] == "pending":
            attempt_info = {
                "attempt_id": result[0],
                "format_hint": result[2] or "auto",
                "tag": result[3],
                "run_id": result[4],
            }
    else:
        # Check if most recent run overall is pending
        result = storage.sql("""
            SELECT attempt_id, status, format_hint, tag, run_id
            FROM blq_load_attempts()
            ORDER BY started_at DESC
            LIMIT 1
        """).fetchone()
        if result and result[1] == "pending":
            attempt_info = {
                "attempt_id": result[0],
                "format_hint": result[2] or "auto",
                "tag": result[3],
                "run_id": result[4],
            }

    if not attempt_info:
        return None

    # Extract live events via the underlying BirdStore
    events = storage._store.extract_live_events(
        attempt_info["attempt_id"], attempt_info["format_hint"]
    )

    # Apply filters
    filtered_events = []
    for i, event in enumerate(events):
        # Severity filter
        if severity:
            event_severity = event.get("severity", "")
            if "," in severity:
                severities = [s.strip() for s in severity.split(",")]
                if event_severity not in severities:
                    continue
            elif event_severity != severity:
                continue

        # File pattern filter
        if file_pattern:
            ref_file = event.get("ref_file", "")
            if not ref_file or file_pattern.replace("%", "") not in ref_file:
                continue

        # Build event dict with run context
        run_ref = (
            f"{attempt_info['tag']}:{attempt_info['run_id']}"
            if attempt_info["tag"]
            else str(attempt_info["run_id"])
        )
        event_ref = f"{run_ref}:{i + 1}"

        filtered_events.append(
            {
                "ref": event_ref,
                "run_ref": run_ref,
                "severity": event.get("severity"),
                "ref_file": event.get("ref_file"),
                "ref_line": event.get("ref_line"),
                "ref_column": event.get("ref_column"),
                "message": event.get("message"),
                "tool_name": event.get("tool_name"),
                "category": event.get("category"),
                "fingerprint": event.get("fingerprint"),
                "log_line": event.get("log_line_start"),
                "test_name": event.get("test_name"),
                "is_live": True,  # Indicate these are from live extraction
            }
        )

    total_count = len(filtered_events)
    return {
        "events": filtered_events[:limit],
        "total_count": total_count,
        "is_live": True,
        "attempt_id": attempt_info["attempt_id"],
    }


def _events_impl(
    limit: int = 20,
    run_id: int | None = None,
    source: str | None = None,
    severity: str | None = None,
    file_pattern: str | None = None,
    include_suppressed: bool = False,
    all_runs: bool = False,
) -> dict[str, Any]:
    """Implementation of events command."""
    try:
        storage = _get_storage()
        if not storage.has_data():
            return {"events": [], "total_count": 0}

        # Check if we should extract live events from a running process
        live_events = _try_extract_live_events(
            storage, run_id, source, severity, file_pattern, limit, all_runs
        )
        if live_events is not None:
            return live_events

        # Build WHERE conditions for completed runs
        conditions: list[str] = []

        # Default to last run unless all_runs=True or specific run/source provided
        if run_id is not None:
            conditions.append(f"run_serial = {run_id}")
        elif source:
            conditions.append(f"source_name = '{source}'")
        elif not all_runs:
            # Default: only show events from the most recent run
            last_run = storage.sql("SELECT MAX(run_serial) FROM blq_load_events()").fetchone()
            if last_run and last_run[0]:
                conditions.append(f"run_serial = {last_run[0]}")
        if file_pattern:
            conditions.append(f"ref_file LIKE '{file_pattern}'")

        # Severity filter (can be single value or comma-separated list)
        if severity:
            if "," in severity:
                severities = [s.strip() for s in severity.split(",")]
                severity_list = ", ".join(f"'{s}'" for s in severities)
                conditions.append(f"severity IN ({severity_list})")
            else:
                conditions.append(f"severity = '{severity}'")

        # Apply suppression filter
        suppress_condition = _get_suppress_condition(include_suppressed)
        if suppress_condition:
            conditions.append(suppress_condition)

        where = " AND ".join(conditions) if conditions else "1=1"

        # Get total count
        count_result = storage.sql(
            f"SELECT COUNT(*) FROM blq_load_events() WHERE {where}"
        ).fetchone()
        total_count = count_result[0] if count_result else 0

        # Get events - use ref column from view
        df = storage.sql(f"""
            SELECT * FROM blq_load_events()
            WHERE {where}
            ORDER BY run_serial DESC, event_id
            LIMIT {limit}
        """).df()

        event_list = []
        for _, row in df.iterrows():
            event = {
                "ref": _to_json_safe(row.get("ref")),
                "run_ref": _to_json_safe(row.get("run_ref")),
                "severity": _to_json_safe(row.get("severity")),
                "ref_file": _to_json_safe(row.get("ref_file")),
                "ref_line": _safe_int(row.get("ref_line")),
                "ref_column": _safe_int(row.get("ref_column")),
                "message": _to_json_safe(row.get("message")),
                "tool_name": _to_json_safe(row.get("tool_name")),
                "category": _to_json_safe(row.get("category")),
                "fingerprint": _to_json_safe(row.get("fingerprint")),
                "log_line": _safe_int(row.get("log_line_start")),
            }
            # Include test_name if present (for test frameworks)
            test_name = _to_json_safe(row.get("test_name"))
            if test_name:
                event["test_name"] = test_name
            event_list.append(event)

        return {"events": event_list, "total_count": total_count}
    except FileNotFoundError:
        return {"events": [], "total_count": 0}


def _event_impl(ref: str) -> dict[str, Any] | None:
    """Implementation of event command."""
    try:
        tag, run_serial, event_id = _parse_ref(ref)
        store = _get_storage()

        # Build query using run_serial and event_id
        if tag is not None:
            where = f"tag = '{tag}' AND run_serial = {run_serial} AND event_id = {event_id}"
        else:
            where = f"run_serial = {run_serial} AND event_id = {event_id}"

        result = store.sql(f"SELECT * FROM blq_load_events() WHERE {where}").fetchone()

        if result is None:
            return None

        rel = store.sql("SELECT * FROM blq_load_events() LIMIT 0")
        columns = rel.columns  # type: ignore[union-attr]  # Always DuckDBPyRelation when no params
        event_data = dict(zip(columns, result))

        # Environment is now stored as MAP, convert to dict if needed
        environment = event_data.get("environment")
        if environment is not None and not isinstance(environment, dict):
            # Handle legacy JSON format
            try:
                environment = json.loads(environment)
            except (json.JSONDecodeError, TypeError):
                environment = None

        response: dict[str, Any] = {
            "ref": _to_json_safe(event_data.get("ref")),
            "run_ref": _to_json_safe(event_data.get("run_ref")),
            "run_serial": run_serial,
            "event_id": event_id,
            "severity": event_data.get("severity"),
            "ref_file": event_data.get("ref_file"),
            "ref_line": event_data.get("ref_line"),
            "ref_column": event_data.get("ref_column"),
            "message": event_data.get("message"),
            "tool_name": event_data.get("tool_name"),
            "category": event_data.get("category"),
            "fingerprint": event_data.get("fingerprint"),
            "raw_text": event_data.get("raw_text"),
            "log_line_start": event_data.get("log_line_start"),
            "log_line_end": event_data.get("log_line_end"),
            # Execution context
            "cwd": event_data.get("cwd"),
            "executable_path": event_data.get("executable_path"),
            "environment": environment,
            # System context
            "hostname": event_data.get("hostname"),
            "platform": event_data.get("platform"),
            "arch": event_data.get("arch"),
            # Git context
            "git_commit": event_data.get("git_commit"),
            "git_branch": event_data.get("git_branch"),
            "git_dirty": event_data.get("git_dirty"),
            # CI context
            "ci": event_data.get("ci"),
        }
        # Include test_name if present (for test frameworks)
        test_name = event_data.get("test_name")
        if test_name:
            response["test_name"] = test_name
        return response
    except (ValueError, FileNotFoundError):
        return None


def _context_impl(ref: str, lines: int = 5) -> dict[str, Any]:
    """Implementation of context command.

    Returns formatted text showing log context around the event,
    matching the CLI output format.
    """
    try:
        tag, run_serial, event_id = _parse_ref(ref)
        storage = _get_storage()

        # Build query using run_serial and event_id
        if tag is not None:
            where = f"tag = '{tag}' AND run_serial = {run_serial} AND event_id = {event_id}"
        else:
            where = f"run_serial = {run_serial} AND event_id = {event_id}"

        result = storage.sql(f"SELECT * FROM blq_load_events() WHERE {where}").fetchone()

        if result is None:
            return {"error": f"Event {ref} not found"}

        rel = storage.sql("SELECT * FROM blq_load_events() LIMIT 0")
        columns = rel.columns  # type: ignore[union-attr]  # Always DuckDBPyRelation when no params
        event_data = dict(zip(columns, result))

        log_line_start_raw = event_data.get("log_line_start")
        log_line_end_raw = event_data.get("log_line_end") or log_line_start_raw

        if log_line_start_raw is None:
            # For structured formats without line info, return message
            source_name = event_data.get("source_name")
            message = event_data.get("message")
            return {
                "context": f"Event {ref} (from structured format, no log line context)\n"
                f"  Source: {source_name}\n"
                f"  Message: {message}",
            }

        # Get raw output for this run
        output_bytes = storage.get_output(run_serial)
        if output_bytes is None:
            return {"error": "Raw log not available for this run"}

        # Decode output
        try:
            content = output_bytes.decode("utf-8", errors="replace")
        except Exception:
            content = output_bytes.decode("latin-1")

        log_lines = content.splitlines()

        # Format using shared function
        log_line_start = int(log_line_start_raw)
        log_line_end = int(log_line_end_raw) if log_line_end_raw else log_line_start
        formatted = format_context(
            log_lines,
            log_line_start,
            log_line_end,
            context=lines,
            ref=ref,
        )

        return {"context": formatted}
    except (ValueError, FileNotFoundError) as e:
        return {"error": f"Event not found: {e}"}


def _inspect_impl(
    ref: str,
    lines: int = 5,
    include_source: bool = True,
    include_git: bool = False,
    include_fingerprint: bool = False,
) -> dict[str, Any]:
    """Implementation of inspect command.

    Returns comprehensive event details with context and optional enrichment.

    Args:
        ref: Event reference in format "tag:serial:event" or "serial:event"
        lines: Lines of context before/after (default: 5)
        include_source: Include source file context (default: True)
        include_git: Include git context - blame and history (default: False)
        include_fingerprint: Include fingerprint history (default: False)

    Returns:
        Event details with log_context and optional enrichment fields
    """
    from blq.cli import BlqConfig
    from blq.git import get_file_context
    from blq.output import read_source_context

    try:
        tag, run_serial, event_id = _parse_ref(ref)
        storage = _get_storage()

        # Build query using run_serial and event_id
        if tag is not None:
            where = f"tag = '{tag}' AND run_serial = {run_serial} AND event_id = {event_id}"
        else:
            where = f"run_serial = {run_serial} AND event_id = {event_id}"

        result = storage.sql(f"SELECT * FROM blq_load_events() WHERE {where}").fetchone()

        if result is None:
            return {"error": f"Event {ref} not found"}

        rel = storage.sql("SELECT * FROM blq_load_events() LIMIT 0")
        columns = rel.columns  # type: ignore[union-attr]  # Always DuckDBPyRelation when no params
        event_data = dict(zip(columns, result))

        # Build response
        response: dict[str, Any] = {
            "ref": _to_json_safe(event_data.get("ref")),
            "run_ref": _to_json_safe(event_data.get("run_ref")),
            "severity": _to_json_safe(event_data.get("severity")),
            "ref_file": _to_json_safe(event_data.get("ref_file")),
            "ref_line": _safe_int(event_data.get("ref_line")),
            "ref_column": _safe_int(event_data.get("ref_column")),
            "message": _to_json_safe(event_data.get("message")),
            "tool_name": _to_json_safe(event_data.get("tool_name")),
            "category": _to_json_safe(event_data.get("category")),
            "code": _to_json_safe(event_data.get("code") or event_data.get("rule")),
            "fingerprint": _to_json_safe(event_data.get("fingerprint")),
        }

        # Log context (always included)
        log_line_start_raw = event_data.get("log_line_start")
        log_line_end_raw = event_data.get("log_line_end") or log_line_start_raw
        log_context = None

        if log_line_start_raw is not None:
            output_bytes = storage.get_output(run_serial)
            if output_bytes is not None:
                try:
                    content = output_bytes.decode("utf-8", errors="replace")
                except Exception:
                    content = output_bytes.decode("latin-1")
                log_lines = content.splitlines()
                start_line = int(log_line_start_raw)
                end_line = int(log_line_end_raw) if log_line_end_raw else start_line
                log_context = format_context(
                    log_lines,
                    start_line,
                    end_line,
                    context=lines,
                    header=f"Line {start_line}",
                )

        response["log_context"] = log_context

        # Get config for ref_root
        config = BlqConfig.find()
        ref_root = config.ref_root if config else None

        # Source context
        if include_source:
            source_context = None
            ref_file = event_data.get("ref_file")
            ref_line_val = event_data.get("ref_line")
            if ref_file and ref_line_val:
                source_context = read_source_context(
                    ref_file,
                    ref_line_val,
                    ref_root=ref_root,
                    context=lines,
                )
            response["source_context"] = source_context

        # Git context
        if include_git:
            git_context = None
            ref_file = event_data.get("ref_file")
            ref_line_val = event_data.get("ref_line")
            if ref_file:
                try:
                    from pathlib import Path

                    file_path = str(Path(ref_root) / ref_file) if ref_root else ref_file
                    ctx = get_file_context(file_path, line=ref_line_val, history_limit=2)

                    git_context = {"file": ref_file, "line": ref_line_val}

                    if ctx.last_author:
                        git_context["blame"] = {
                            "author": ctx.last_author,
                            "commit": ctx.last_commit,
                            "modified": (
                                ctx.last_modified.isoformat() if ctx.last_modified else None
                            ),
                        }

                    if ctx.recent_commits:
                        git_context["recent_commits"] = [
                            {
                                "hash": c.short_hash,
                                "author": c.author,
                                "time": c.time.isoformat(),
                                "message": c.message,
                            }
                            for c in ctx.recent_commits
                        ]
                except Exception:
                    pass

            response["git_context"] = git_context

        # Fingerprint history
        if include_fingerprint:
            fp_history = None
            fingerprint = event_data.get("fingerprint")
            if fingerprint:
                try:
                    # Use parameterized query for safety
                    fp_result = storage.sql(
                        """
                        SELECT run_serial, run_ref, timestamp, tag
                        FROM blq_load_events()
                        WHERE fingerprint = ?
                        ORDER BY timestamp ASC
                        """,
                        [fingerprint],
                    ).fetchall()

                    if fp_result:
                        first = fp_result[0]
                        last = fp_result[-1]

                        # Detect regression
                        is_regression = False
                        if len(fp_result) >= 2:
                            run_serials = [r[0] for r in fp_result]
                            for i in range(1, len(run_serials)):
                                if run_serials[i] - run_serials[i - 1] > 1:
                                    is_regression = True
                                    break

                        fp_history = {
                            "fingerprint": (
                                fingerprint[:16] + "..." if len(fingerprint) > 16 else fingerprint
                            ),
                            "first_seen": {
                                "run_ref": first[1],
                                "timestamp": first[2].isoformat() if first[2] else None,
                            },
                            "last_seen": {
                                "run_ref": last[1],
                                "timestamp": last[2].isoformat() if last[2] else None,
                            },
                            "occurrences": len(fp_result),
                            "is_regression": is_regression,
                        }
                except Exception:
                    pass

            response["fingerprint_history"] = fp_history

        return response
    except (ValueError, FileNotFoundError) as e:
        return {"error": f"Event not found: {e}"}


def _output_impl(
    run_id: int,
    stream: str | None = None,
    tail: int | None = None,
    head: int | None = None,
    grep: str | None = None,
    context: int = 0,
    lines: str | None = None,
    debug_formats: bool = False,
) -> dict[str, Any]:
    """Implementation of output command - get raw output for a run.

    Args:
        run_id: Run serial number
        stream: Stream name ('stdout', 'stderr', 'combined') or None for any
        tail: Return only last N lines
        head: Return only first N lines
        grep: Regex pattern to search for in output
        context: Lines of context around grep matches (default: 0)
        lines: Line spec (e.g., '100-200', '42 +/-5') - requires read_lines extension
        debug_formats: Show format detection diagnosis

    Returns:
        Output content and metadata
    """
    import re

    try:
        storage = _get_storage()

        # Get output info first
        info = storage.get_output_info(run_id)
        if not info:
            return {
                "run_id": run_id,
                "error": "No output found for this run",
                "streams": [],
            }

        # Get the raw output
        output_bytes = storage.get_output(run_id, stream)
        if output_bytes is None:
            return {
                "run_id": run_id,
                "error": "Output content not available",
                "streams": [s["stream"] for s in info],
            }

        # Decode
        try:
            content = output_bytes.decode("utf-8", errors="replace")
        except Exception:
            content = output_bytes.decode("latin-1")

        total_lines = len(content.splitlines())
        result: dict[str, Any] = {
            "run_id": run_id,
            "stream": stream or info[0]["stream"] if info else "combined",
            "byte_length": len(output_bytes),
            "total_lines": total_lines,
            "streams": [s["stream"] for s in info],
        }

        # Handle debug_formats mode
        if debug_formats:
            try:
                import duckdb

                conn = duckdb.connect()
                conn.execute("LOAD duck_hunt")
                diagnosis = conn.execute(
                    "SELECT * FROM duck_hunt_diagnose_parse(?)",
                    [content],
                ).fetchall()
                columns = ["format", "events", "score", "confidence"]
                result["format_diagnosis"] = [dict(zip(columns, row)) for row in diagnosis]
            except Exception as e:
                result["format_diagnosis_error"] = str(e)
            return result

        # Handle line selection (requires read_lines extension)
        if lines:
            try:
                import duckdb

                conn = duckdb.connect()
                conn.execute("LOAD read_lines")
                line_result = conn.execute(
                    "SELECT line_number, content FROM parse_lines(?, lines := ?)",
                    [content, lines],
                ).fetchall()
                result["content"] = "\n".join(f"{ln:>6}\t{c.rstrip()}" for ln, c in line_result)
                result["returned_lines"] = len(line_result)
            except Exception as e:
                result["error"] = f"Line selection failed (read_lines required): {e}"
            return result

        # Handle grep/search mode
        if grep:
            try:
                regex = re.compile(grep, re.IGNORECASE)
            except re.error as re_err:
                return {**result, "error": f"Invalid regex: {re_err}"}

            all_lines = content.splitlines()
            matches = [i for i, line in enumerate(all_lines) if regex.search(line)]

            if not matches:
                result["content"] = "(no matches found)"
                result["returned_lines"] = 0
                result["match_count"] = 0
                return result

            # Expand matches with context
            to_show = set()
            for m in matches:
                for i in range(max(0, m - context), min(len(all_lines), m + context + 1)):
                    to_show.add(i)

            output_lines = []
            for i in sorted(to_show):
                mark = ">>>" if i in matches else "   "
                output_lines.append(f"{mark} {i + 1:>5} | {all_lines[i]}")

            result["content"] = "\n".join(output_lines)
            result["returned_lines"] = len(output_lines)
            result["match_count"] = len(matches)
            return result

        # Standard head/tail mode
        all_lines = content.splitlines(keepends=True)

        if tail is not None and tail > 0:
            all_lines = all_lines[-tail:]
        elif head is not None and head > 0:
            all_lines = all_lines[:head]

        result["content"] = "".join(all_lines)
        result["returned_lines"] = len(all_lines)
        return result

    except FileNotFoundError:
        return {"run_id": run_id, "error": "No lq repository found", "streams": []}
    except Exception as e:
        return {"run_id": run_id, "error": str(e), "streams": []}


def _check_and_cleanup_orphans(storage: Any, min_age_seconds: float = 30.0) -> list[str]:
    """Check for orphaned processes and mark them.

    An orphan is a 'pending' attempt where the PID is no longer running.
    This happens when a process crashes or is killed without proper cleanup.

    Args:
        storage: BirdStore instance
        min_age_seconds: Only check attempts older than this to avoid race conditions

    Returns:
        List of attempt IDs that were marked as orphaned
    """
    try:
        # Check if storage has the orphan check methods (BirdStore)
        if not hasattr(storage, "mark_stale_as_orphaned"):
            return []

        orphaned: list[str] = storage.mark_stale_as_orphaned(min_age_seconds=min_age_seconds)
        return orphaned
    except Exception:
        # Don't let orphan checking break normal operations
        return []


def _status_impl() -> dict[str, Any]:
    """Implementation of status command."""
    try:
        storage = _get_storage()
        if not storage.has_data():
            return {"sources": []}

        # Check for orphaned processes (PIDs that are no longer running)
        # This runs automatically on status to keep the state clean
        orphaned = _check_and_cleanup_orphans(storage)

        # Get status for each source (includes pending/running via blq_load_source_status)
        runs_df = storage.sql("""
            SELECT * FROM blq_load_source_status()
            ORDER BY started_at DESC
        """).df()
        sources = []
        orphaned_count = len(orphaned)

        for _, row in runs_df.iterrows():
            error_count = _safe_int(row.get("error_count")) or 0
            warning_count = _safe_int(row.get("warning_count")) or 0
            run_status = _to_json_safe(row.get("status"))

            if run_status == "pending":
                status_str = "RUNNING"
            elif error_count > 0:
                status_str = "FAIL"
            elif warning_count > 0:
                status_str = "WARN"
            else:
                status_str = "OK"

            # Build run_ref from tag and run_id (serial number from blq_load_runs)
            tag = _to_json_safe(row.get("tag"))
            run_serial = _safe_int(row.get("run_id")) or 0
            if tag:
                run_ref = f"{tag}:{run_serial}"
            else:
                run_ref = str(run_serial)

            sources.append(
                {
                    "name": _to_json_safe(row.get("source_name")) or "unknown",
                    "status": status_str,
                    "error_count": error_count,
                    "warning_count": warning_count,
                    "last_run": str(_to_json_safe(row.get("started_at")) or ""),
                    "run_ref": run_ref,
                    "run_serial": run_serial,
                }
            )

        result: dict[str, Any] = {"sources": sources}
        if orphaned_count > 0:
            result["orphaned_cleaned"] = orphaned_count
        return result
    except FileNotFoundError:
        return {"sources": []}


def _build_event_summaries(events: list[dict[str, Any]]) -> dict[str, Any]:
    """Build aggregated summaries from a list of events.

    Returns:
        Dict with:
        - by_fingerprint: list of {fingerprint, count, example_message, example_ref}
        - by_file: list of {file, count}
    """
    # Aggregate by fingerprint
    fingerprint_counts: dict[str, dict[str, Any]] = {}
    for event in events:
        fp = event.get("fingerprint") or "unknown"
        if fp not in fingerprint_counts:
            fingerprint_counts[fp] = {
                "fingerprint": fp,
                "count": 0,
                "example_message": event.get("message"),
                "example_ref": event.get("ref"),
            }
        fingerprint_counts[fp]["count"] += 1

    # Aggregate by file
    file_counts: dict[str, int] = {}
    for event in events:
        ref_file = event.get("ref_file")
        if ref_file:
            file_counts[ref_file] = file_counts.get(ref_file, 0) + 1

    # Sort by count descending
    by_fingerprint = sorted(
        fingerprint_counts.values(),
        key=lambda x: int(x["count"]),  # type: ignore[arg-type]
        reverse=True,
    )
    by_file = sorted(
        [{"file": f, "count": c} for f, c in file_counts.items()],
        key=lambda x: int(x["count"]),  # type: ignore[call-overload]
        reverse=True,
    )

    return {
        "by_fingerprint": by_fingerprint[:10],  # Top 10
        "by_file": by_file[:10],  # Top 10
    }


def _get_affected_commits(files: list[str], limit: int = 5) -> list[dict[str, Any]]:
    """Get recent git commits that touched the affected files."""
    try:
        from blq.git import get_file_context

        # Collect unique commits across all files
        seen_commits: dict[str, dict[str, Any]] = {}
        for file_path in files[:5]:  # Limit files to check
            try:
                ctx = get_file_context(file_path, history_limit=3)
                for commit in ctx.recent_commits:
                    if commit.short_hash not in seen_commits:
                        seen_commits[commit.short_hash] = {
                            "hash": commit.short_hash,
                            "author": commit.author,
                            "time": commit.time.isoformat() if commit.time else None,
                            "message": commit.message,
                            "files": [file_path],
                        }
                    else:
                        seen_commits[commit.short_hash]["files"].append(file_path)
            except Exception:
                continue

        # Sort by time (most recent first) and limit
        commits = sorted(
            seen_commits.values(),
            key=lambda x: x.get("time") or "",
            reverse=True,
        )
        return commits[:limit]
    except Exception:
        return []


def _info_impl(ref: str) -> dict[str, Any]:
    """Implementation of info command - get detailed run info.

    Accepts run ref (e.g., 'test:5'), source name (e.g., 'test'), or invocation_id (UUID).
    When given a source name, returns the most recent run for that source.
    """
    try:
        storage = _get_storage()
        if not storage.has_data():
            return {"error": "No data available"}

        # Check if it's a UUID (invocation_id) or a run ref
        is_uuid = len(ref) == 36 and ref.count("-") == 4
        is_source_name = False
        tag = None
        run_serial = None

        if is_uuid:
            # Query by invocation_id
            df = storage.sql(f"""
                SELECT * FROM blq_load_runs()
                WHERE invocation_id = '{ref}'
            """).df()
        else:
            # Try to parse as run ref (supports relative refs like +1, test:+1)
            try:
                tag, run_serial = _parse_run_ref(ref, storage)
                if tag is not None:
                    df = storage.sql(f"""
                        SELECT * FROM blq_load_runs()
                        WHERE tag = '{tag}' AND run_id = {run_serial}
                    """).df()
                else:
                    df = storage.sql(f"""
                        SELECT * FROM blq_load_runs()
                        WHERE run_id = {run_serial}
                    """).df()
            except ValueError:
                # Not a valid run ref - try as source name
                is_source_name = True
                df = storage.sql(f"""
                    SELECT * FROM blq_load_attempts()
                    WHERE source_name = '{ref}'
                    ORDER BY started_at DESC
                    LIMIT 1
                """).df()

        # If not in completed runs, check pending attempts (unless already looked up by source name)
        if df.empty and not is_source_name:
            if is_uuid:
                df = storage.sql(f"""
                    SELECT * FROM blq_load_attempts()
                    WHERE attempt_id = '{ref}'
                """).df()
            else:
                if tag is not None:
                    df = storage.sql(f"""
                        SELECT * FROM blq_load_attempts()
                        WHERE source_name = '{tag}' AND run_id = {run_serial}
                    """).df()
                elif run_serial is not None:
                    df = storage.sql(f"""
                        SELECT * FROM blq_load_attempts()
                        WHERE run_id = {run_serial}
                    """).df()

        if df.empty:
            if is_source_name:
                return {"error": f"No runs found for source '{ref}'"}
            return {"error": f"Run {ref} not found"}

            # This is a pending/running attempt
            row = df.iloc[0]
            attempt_status = _to_json_safe(row.get("status"))
            attempt_id = _to_json_safe(row.get("attempt_id"))

            tag = _to_json_safe(row.get("tag"))
            run_serial = _safe_int(row.get("run_id")) or 0
            if tag:
                run_ref = f"{tag}:{run_serial}"
            else:
                run_ref = str(run_serial)

            # Map attempt status to display status
            if attempt_status == "pending":
                status_str = "RUNNING"
            elif attempt_status == "orphaned":
                status_str = "ORPHANED"
            else:
                status_str = "COMPLETED"

            return {
                "run_ref": run_ref,
                "run_serial": run_serial,
                "attempt_id": attempt_id,
                "invocation_id": None,  # Not yet completed
                "source_name": _to_json_safe(row.get("source_name")),
                "source_type": _to_json_safe(row.get("source_type")),
                "command": _to_json_safe(row.get("command")),
                "status": status_str,
                "exit_code": _safe_int(row.get("exit_code")),
                "error_count": 0,  # Not yet parsed
                "warning_count": 0,
                "info_count": 0,
                "event_count": 0,
                "started_at": str(_to_json_safe(row.get("started_at")) or ""),
                "completed_at": (
                    str(_to_json_safe(row.get("completed_at")) or "")
                    if attempt_status != "pending"
                    else None
                ),
                "cwd": _to_json_safe(row.get("cwd")),
                "executable_path": _to_json_safe(row.get("executable")),
                "hostname": _to_json_safe(row.get("hostname")),
                "platform": _to_json_safe(row.get("platform")),
                "arch": _to_json_safe(row.get("arch")),
                "git_branch": _to_json_safe(row.get("git_branch")),
                "git_commit": _to_json_safe(row.get("git_commit")),
                "git_dirty": _to_json_safe(row.get("git_dirty")),
                "ci": _to_json_safe(row.get("ci")),
                "outputs": [],  # Live output not yet finalized
                "is_running": attempt_status == "pending",
            }

        row = df.iloc[0]
        invocation_id = _to_json_safe(row.get("invocation_id"))

        # Build run_ref
        tag = _to_json_safe(row.get("tag"))
        run_serial = _safe_int(row.get("run_id")) or 0
        if tag:
            run_ref = f"{tag}:{run_serial}"
        else:
            run_ref = str(run_serial)

        # Get output details
        outputs = []
        if invocation_id:
            outputs_result = storage.sql(f"""
                SELECT stream, byte_length
                FROM outputs
                WHERE invocation_id = '{invocation_id}'
                ORDER BY stream
            """).fetchall()
            outputs = [{"stream": r[0], "bytes": r[1]} for r in outputs_result]

        return {
            "run_ref": run_ref,
            "run_serial": run_serial,
            "invocation_id": invocation_id,
            "source_name": _to_json_safe(row.get("source_name")),
            "source_type": _to_json_safe(row.get("source_type")),
            "command": _to_json_safe(row.get("command")),
            "status": _compute_status(
                _safe_int(row.get("error_count")) or 0,
                _safe_int(row.get("warning_count")) or 0,
                _safe_int(row.get("exit_code")),
            ),
            "exit_code": _safe_int(row.get("exit_code")),
            "error_count": _safe_int(row.get("error_count")) or 0,
            "warning_count": _safe_int(row.get("warning_count")) or 0,
            "info_count": _safe_int(row.get("info_count")) or 0,
            "event_count": _safe_int(row.get("event_count")) or 0,
            "started_at": str(_to_json_safe(row.get("started_at")) or ""),
            "completed_at": str(_to_json_safe(row.get("completed_at")) or ""),
            "cwd": _to_json_safe(row.get("cwd")),
            "executable_path": _to_json_safe(row.get("executable_path")),
            "hostname": _to_json_safe(row.get("hostname")),
            "platform": _to_json_safe(row.get("platform")),
            "arch": _to_json_safe(row.get("arch")),
            "git_branch": _to_json_safe(row.get("git_branch")),
            "git_commit": _to_json_safe(row.get("git_commit")),
            "git_dirty": bool(row.get("git_dirty")) if not pd.isna(row.get("git_dirty")) else None,
            "outputs": outputs,
        }
    except FileNotFoundError:
        return {"error": "No lq repository found"}
    except Exception as e:
        return {"error": str(e)}


def _history_impl(
    limit: int = 20, source: str | None = None, status: str | None = None
) -> dict[str, Any]:
    """Implementation of history command.

    Args:
        limit: Max runs to return
        source: Filter by source name
        status: Filter by run status ('running', 'completed', 'orphaned')
    """
    try:
        storage = _get_storage()
        if not storage.has_data():
            return {"runs": []}

        # Map user-friendly status names to database values
        status_map = {"running": "pending", "completed": "completed", "orphaned": "orphaned"}
        db_status = status_map.get(status) if status else None

        # Use blq_history_status() for status filtering (includes pending attempts)
        if db_status:
            status_sql = f"'{db_status}'"
            if source:
                runs_df = storage.sql(f"""
                    SELECT * FROM blq_history_status({status_sql}, {limit})
                    WHERE source_name = '{source}'
                """).df()
            else:
                runs_df = storage.sql(f"""
                    SELECT * FROM blq_history_status({status_sql}, {limit})
                """).df()
        else:
            # Include pending/running by using blq_load_attempts with event counts
            source_filter = (
                f"WHERE (tag = '{source}' OR source_name = '{source}')" if source else ""
            )
            runs_df = storage.sql(f"""
                SELECT
                    a.*,
                    COALESCE(e.error_count, 0) AS error_count,
                    COALESCE(e.warning_count, 0) AS warning_count
                FROM blq_load_attempts() a
                LEFT JOIN (
                    SELECT
                        invocation_id,
                        COUNT(*) FILTER (WHERE severity = 'error') AS error_count,
                        COUNT(*) FILTER (WHERE severity = 'warning') AS warning_count
                    FROM events
                    GROUP BY invocation_id
                ) e ON a.attempt_id = e.invocation_id
                {source_filter}
                ORDER BY a.started_at DESC
                LIMIT {limit}
            """).df()

        runs = []

        for _, row in runs_df.iterrows():
            # Get counts (may be None for status-filtered results from blq_history_status)
            error_count = _safe_int(row.get("error_count")) or 0
            warning_count = _safe_int(row.get("warning_count")) or 0

            # For status-filtered results, use the status from the query
            run_status = _to_json_safe(row.get("status"))

            if run_status == "pending":
                status_str = "RUNNING"
            elif run_status == "orphaned":
                status_str = "ORPHANED"
            else:
                # For completed runs, derive from error/warning counts
                if error_count > 0:
                    status_str = "FAIL"
                elif warning_count > 0:
                    status_str = "WARN"
                else:
                    status_str = "OK"

            # Build run_ref from tag and run_id (serial number from blq_load_runs)
            tag = _to_json_safe(row.get("tag"))
            run_serial = _safe_int(row.get("run_id")) or 0
            if tag:
                run_ref = f"{tag}:{run_serial}"
            else:
                run_ref = str(run_serial)

            runs.append(
                {
                    "run_ref": run_ref,
                    "run_serial": run_serial,
                    "source_name": _to_json_safe(row.get("source_name")) or "unknown",
                    "status": status_str,
                    "error_count": error_count,
                    "warning_count": warning_count,
                    "started_at": str(_to_json_safe(row.get("started_at")) or ""),
                    "exit_code": _safe_int(row.get("exit_code")),
                    "command": _to_json_safe(row.get("command")),
                    "cwd": _to_json_safe(row.get("cwd")),
                    "executable_path": _to_json_safe(row.get("executable_path")),
                    "hostname": _to_json_safe(row.get("hostname")),
                    "platform": _to_json_safe(row.get("platform")),
                    "arch": _to_json_safe(row.get("arch")),
                    "git_commit": _to_json_safe(row.get("git_commit")),
                    "git_branch": _to_json_safe(row.get("git_branch")),
                    "git_dirty": _to_json_safe(row.get("git_dirty")),
                    "ci": _to_json_safe(row.get("ci")),
                }
            )
        return {"runs": runs}
    except FileNotFoundError:
        return {"runs": []}


def _diff_impl(run1: int, run2: int) -> dict[str, Any]:
    """Implementation of diff command.

    Args:
        run1: First run serial number (baseline)
        run2: Second run serial number (comparison)
    """
    try:
        storage = _get_storage()

        # Get errors from each run using run_serial
        errors1 = storage.sql(f"""
            SELECT * FROM blq_load_events()
            WHERE severity = 'error' AND run_serial = {run1}
            LIMIT 1000
        """).df()
        errors2 = storage.sql(f"""
            SELECT * FROM blq_load_events()
            WHERE severity = 'error' AND run_serial = {run2}
            LIMIT 1000
        """).df()

        # Use fingerprints for comparison if available, else use file+line+message
        def get_error_key(row):
            fp = _to_json_safe(row.get("fingerprint"))
            if fp:
                return fp
            ref = _to_json_safe(row.get("ref_file"))
            line = _to_json_safe(row.get("ref_line"))
            msg = (_to_json_safe(row.get("message")) or "")[:50]
            return f"{ref}:{line}:{msg}"

        keys1 = set(get_error_key(row) for _, row in errors1.iterrows())
        keys2 = set(get_error_key(row) for _, row in errors2.iterrows())

        fixed_keys = keys1 - keys2
        new_keys = keys2 - keys1
        unchanged_keys = keys1 & keys2

        # Build fixed and new error lists
        fixed = []
        for _, row in errors1.iterrows():
            if get_error_key(row) in fixed_keys:
                fixed.append(
                    {
                        "ref_file": _to_json_safe(row.get("ref_file")),
                        "message": _to_json_safe(row.get("message")),
                    }
                )

        new_errors = []
        for _, row in errors2.iterrows():
            if get_error_key(row) in new_keys:
                new_errors.append(
                    {
                        "ref": _to_json_safe(row.get("ref")),
                        "ref_file": _to_json_safe(row.get("ref_file")),
                        "ref_line": _safe_int(row.get("ref_line")),
                        "message": _to_json_safe(row.get("message")),
                    }
                )

        return {
            "summary": {
                "run1_errors": len(errors1),
                "run2_errors": len(errors2),
                "fixed": len(fixed_keys),
                "new": len(new_keys),
                "unchanged": len(unchanged_keys),
            },
            "fixed": fixed,
            "new": new_errors,
        }
    except FileNotFoundError:
        return {
            "summary": {"run1_errors": 0, "run2_errors": 0, "fixed": 0, "new": 0, "unchanged": 0},
            "fixed": [],
            "new": [],
            "error": "No lq repository found",
        }


def _normalize_cmd(cmd: str) -> str:
    """Normalize command string for comparison (collapse whitespace)."""
    return " ".join(cmd.split())


def _derive_command_name(command: str) -> str:
    """Derive a short command name for registration suggestions."""
    parts = command.split()
    if not parts:
        return "cmd"
    name = os.path.basename(parts[0])
    # Handle "python -m <module>" pattern
    if name in ("python", "python3") and len(parts) >= 3 and parts[1] == "-m":
        return parts[2]
    return name or "cmd"


def _build_registration_recommendation(command: str) -> dict[str, Any] | None:
    """Build a recommendation to register a repeatedly exec'd command, or None."""
    disabled = _load_disabled_tools()
    if "register_command" in disabled:
        return None

    count = _exec_tracker.record(command)
    if count < 2:
        return None

    name = _derive_command_name(command)
    original_cmd = _exec_tracker.get_original(command)
    ordinal = {2: "2nd", 3: "3rd"}.get(count, f"{count}th")

    return {
        "message": (
            f"This is the {ordinal} time this command has been run via exec."
            " Consider registering it."
        ),
        "suggested_call": {
            "tool": "register_command",
            "args": {"name": name, "cmd": original_cmd},
        },
        "reason": (
            f"Registered commands have cleaner refs (e.g., '{name}:1'), "
            "support per-command config, and don't need repeated approval."
        ),
    }


# Shell metacharacters that indicate pipes, redirects, or command chains.
# We detect these to prevent silent failures when agents pass shell syntax
# to commands that are exec'd without a shell.
_SHELL_PIPE_PATTERN = _re.compile(
    r"""
    (?<!\d)           # not preceded by a digit (to allow 2>&1)
    (?:
        \|(?!\|)      # single pipe (but not ||)
      | >>            # append redirect
      | >(?!&)        # output redirect (but not >&)
      | <(?!<)        # input redirect (but not <<)
      | <<            # heredoc
      | \|\|          # or-chain
      | &&            # and-chain
      | ;             # command separator
    )
    """,
    _re.VERBOSE,
)

# Pattern to detect standalone 2>&1 (which blq captures anyway)
_ONLY_2_REDIRECT = _re.compile(r"^[^|;>&<]*2>&1\s*$")

# Patterns for common post-pipe filters → output() suggestions
_PIPE_SUGGESTIONS: list[tuple[_re.Pattern[str], str]] = [
    (
        _re.compile(r"\|\s*tail\s+(?:-n\s*|-)?(\d+)"),
        "output(run_id=RUN_ID, tail={0})",
    ),
    (
        _re.compile(r"\|\s*tail\b"),
        "output(run_id=RUN_ID, tail=20)",
    ),
    (
        _re.compile(r"\|\s*head\s+(?:-n\s*|-)?(\d+)"),
        "output(run_id=RUN_ID, head={0})",
    ),
    (
        _re.compile(r"\|\s*head\b"),
        "output(run_id=RUN_ID, head=20)",
    ),
    (
        _re.compile(r"""\|\s*grep\s+(?:-[a-zA-Z]+\s+)*['"]?([^'"|\s]+)['"]?"""),
        'output(run_id=RUN_ID, grep="{0}", context=3)',
    ),
]


def _detect_shell_pipes(command: str) -> dict[str, Any] | None:
    """Detect shell pipes, redirects, and command chains in a command string.

    Returns an error dict with base_command and suggestions if shell syntax
    is found, or None if the command is clean.

    Tolerates standalone ``2>&1`` since blq captures both streams anyway.
    """
    # Allow standalone 2>&1 (blq captures both streams)
    if _ONLY_2_REDIRECT.match(command):
        return None

    match = _SHELL_PIPE_PATTERN.search(command)
    if match is None:
        return None

    # Extract the base command (everything before the first metacharacter)
    metachar_pos = match.start()
    base_command = command[:metachar_pos].strip()

    # Build suggestions from matched pipe patterns
    suggestions: list[str] = []
    for pattern, template in _PIPE_SUGGESTIONS:
        m = pattern.search(command)
        if m:
            # Fill in captured groups
            suggestion = template
            for i, group in enumerate(m.groups()):
                if group is not None:
                    suggestion = suggestion.replace(f"{{{i}}}", group)
            suggestions.append(suggestion)

    # Build the suggested workflow
    workflow = [
        f'1. Run the base command: exec(command="{base_command}")',
        "2. Then filter the captured output:",
    ]
    if suggestions:
        for s in suggestions:
            workflow.append(f"   {s}")
    else:
        workflow.append("   output(run_id=RUN_ID, tail=N)  # last N lines")
        workflow.append('   output(run_id=RUN_ID, grep="PATTERN", context=3)  # search')

    detected = command[metachar_pos : metachar_pos + 10].strip()
    return {
        "error": (
            f"Shell syntax detected: '{detected}' in command. "
            "Commands are executed directly, not through a shell. "
            "Use the output() tool to filter captured logs instead."
        ),
        "base_command": base_command,
        "suggested_workflow": workflow,
        "hint": "Pass shell=True to force shell execution (advanced).",
    }


def _command_to_dict(cmd: Any) -> dict[str, Any]:
    """Convert RegisteredCommand to dict for JSON response."""
    result: dict[str, Any] = {
        "name": cmd.name,
        "description": cmd.description,
        "timeout": cmd.timeout,
        "capture": cmd.capture,
        "format": cmd.format,
    }
    if cmd.tpl:
        result["tpl"] = cmd.tpl
        result["defaults"] = cmd.defaults
    else:
        result["cmd"] = cmd.cmd
    if cmd.lines is not None:
        result["lines"] = cmd.lines
    return result


def _register_command_impl(
    name: str,
    cmd: str | None = None,
    tpl: str | None = None,
    defaults: dict[str, str] | None = None,
    description: str = "",
    timeout: int | None = None,
    capture: bool = True,
    force: bool = False,
    format: str | None = None,
    run_now: bool = False,
    lines: str | None = None,
) -> dict[str, Any]:
    """Implementation of register_command."""
    try:
        from blq.cli import BlqConfig, RegisteredCommand
        from blq.commands.core import detect_format_from_command

        # Validate: must have cmd or tpl, not both
        if cmd and tpl:
            return {
                "success": False,
                "error": "Provide either 'cmd' (simple command) or 'tpl' (template), not both.",
            }
        if not cmd and not tpl:
            return {
                "success": False,
                "error": "Must provide either 'cmd' (simple command) or 'tpl' (template command).",
            }

        config = BlqConfig.find()

        if config is None:
            return {"success": False, "error": "No lq repository found. Run 'blq init' first."}

        commands = config.commands
        is_template = tpl is not None
        command_str = tpl if is_template else cmd
        normalized_cmd = _normalize_cmd(command_str) if command_str else ""

        # Check for existing command with same name
        if name in commands and not force:
            existing = commands[name]
            # Compare based on command type
            if existing.tpl:
                existing_normalized = _normalize_cmd(existing.tpl)
                existing_is_template = True
            else:
                existing_normalized = _normalize_cmd(existing.cmd) if existing.cmd else ""
                existing_is_template = False

            # Same command type and content?
            if existing_is_template == is_template and existing_normalized == normalized_cmd:
                # Same command, just use it
                result: dict[str, Any] = {
                    "success": True,
                    "message": f"Using existing command '{name}' (identical)",
                    "existing": True,
                    "command": _command_to_dict(existing),
                }
                if run_now:
                    run_result = _run_impl(name, timeout=timeout)
                    result["run"] = run_result
                return result
            else:
                # Different command with same name
                existing_desc = existing.tpl or existing.cmd
                return {
                    "success": False,
                    "error": (
                        f"Command '{name}' already exists with different command. "
                        f"Existing: '{existing_desc}'. Use force=true to overwrite."
                    ),
                }

        # Check for existing command with same cmd/tpl but different name (only for simple commands)
        if cmd:
            for existing_name, existing in commands.items():
                if existing.cmd and _normalize_cmd(existing.cmd) == normalized_cmd and not force:
                    return {
                        "success": False,
                        "error": (
                            f"Command already registered as '{existing_name}'. "
                            f"Use run(command='{existing_name}') or force=true to re-register."
                        ),
                        "existing_name": existing_name,
                    }

        # Auto-detect format if not specified
        format_detected = False
        if format is None and command_str:
            format = detect_format_from_command(command_str)
            format_detected = True

        new_command = RegisteredCommand(
            name=name,
            cmd=cmd,
            tpl=tpl,
            defaults=defaults or {},
            description=description,
            timeout=timeout,
            capture=capture,
            format=format or "auto",
            lines=lines,
        )
        commands[name] = new_command
        config.save_commands()

        format_note = f" [format: {format} (detected)]" if format_detected else ""
        cmd_display = tpl if is_template else cmd
        result = {
            "success": True,
            "message": f"Registered command '{name}': {cmd_display}{format_note}",
            "existing": False,
            "format_detected": format_detected,
            "command": _command_to_dict(new_command),
        }
        if run_now:
            run_result = _run_impl(name, timeout=timeout)
            result["run"] = run_result
        return result
    except Exception as e:
        return {"success": False, "error": str(e)}


def _unregister_command_impl(name: str) -> dict[str, Any]:
    """Implementation of unregister_command."""
    try:
        from blq.cli import BlqConfig

        config = BlqConfig.find()

        if config is None:
            return {"success": False, "error": "No lq repository found."}

        commands = config.commands

        if name not in commands:
            return {"success": False, "error": f"Command '{name}' not found."}

        del commands[name]
        config.save_commands()

        return {"success": True, "message": f"Unregistered command '{name}'"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _commands_impl() -> dict[str, Any]:
    """Implementation of commands listing."""
    try:
        from blq.cli import BlqConfig

        config = BlqConfig.find()

        if config is None:
            return {"commands": []}

        commands = config.commands

        result = []
        for name, cmd in commands.items():
            entry: dict[str, Any] = {"name": name}
            if cmd.cmd:
                entry["cmd"] = cmd.cmd
            elif cmd.tpl:
                entry["tpl"] = cmd.tpl
                if cmd.defaults:
                    entry["defaults"] = cmd.defaults
            else:
                entry["error"] = "invalid: no cmd or tpl"
            entry["description"] = cmd.description
            entry["timeout"] = cmd.timeout
            entry["capture"] = cmd.capture
            entry["format"] = cmd.format
            result.append(entry)
        return {"commands": result}
    except Exception as e:
        return {"commands": [], "error": str(e)}


# ============================================================================
# Tools (thin wrappers around implementations)
# ============================================================================


@mcp.tool()
def run(
    command: str,
    args: dict[str, str] | list[str] | None = None,
    extra: list[str] | None = None,
    timeout: int | None = None,
    lines: str | None = None,
    # Batch mode parameters
    commands: list[str] | None = None,
    stop_on_failure: bool = True,
) -> dict[str, Any]:
    """Run a registered command and capture its output.

    Can run a single command or multiple commands in sequence (batch mode).

    Args:
        command: Registered command name (use the exec tool for ad-hoc commands)
        args: Command arguments - either a dict of named args (recommended)
              or a list of CLI args for backward compatibility
        extra: Passthrough arguments appended to command
        timeout: Timeout in seconds (default: no timeout)
        lines: Line selection for inline output (e.g., '+20-' for last 20 lines,
               '-50' for first 50, '100-200' for range). Overrides the command's
               configured lines default. When set, output is included directly
               in the response instead of requiring a separate output() call.
        commands: List of command names for batch mode (overrides `command`)
        stop_on_failure: In batch mode, stop after first failure (default: true)

    Returns:
        Run result with status, errors, and preview of output on failure.
        When lines is active (explicit or from command config), includes 'output' key.
        In batch mode, returns results for each command with overall status.
    """
    # Batch mode: run multiple commands in sequence
    if commands is not None:
        results = []
        overall_status = "OK"

        for cmd in commands:
            result = _run_impl(cmd, timeout=timeout, lines=lines)
            results.append({"command": cmd, "result": result})

            if result.get("status") == "FAIL":
                overall_status = "FAIL"
                if stop_on_failure:
                    break
            elif result.get("status") == "WARN" and overall_status == "OK":
                overall_status = "WARN"

        return {
            "status": overall_status,
            "results": results,
            "commands_run": len(results),
            "commands_requested": len(commands),
        }

    # Single command mode
    return _run_impl(command, args, extra, timeout, lines=lines)


@mcp.tool()
def exec(
    command: str,
    args: list[str] | None = None,
    timeout: int | None = None,
    shell: bool = False,
    lines: str | None = None,
) -> dict[str, Any]:
    """Execute an ad-hoc shell command and capture its output.

    IMPORTANT: Do NOT use shell pipes, redirects, or command chains
    (|, >, >>, <, &&, ||, ;) in the command string. Commands are executed
    directly without a shell. To filter output, run the command first, then
    use the output() tool with grep/tail/head parameters.

    If the command matches a registered command prefix, automatically uses
    run() instead for cleaner refs. For example, if 'test' is registered as
    'pytest tests/', then exec('pytest tests/ -v') will run as
    run(command='test', extra=['-v']).

    Note: This tool can be disabled via mcp.disabled_tools config.

    Args:
        command: Shell command to run (no pipes or redirects)
        args: Additional arguments to append
        timeout: Timeout in seconds (default: no timeout)
        shell: Advanced: set True to allow shell syntax (pipes, redirects).
               Prefer the two-step workflow: exec() then output() instead.
        lines: Line selection for inline output (e.g., '+20-' for last 20 lines,
               '-50' for first 50, '100-200' for range). When set, output is
               included directly in the response.

    Returns:
        Run result with status, errors, and warnings. If a registered command
        was matched, includes 'matched_command' and optionally 'extra_args'.
        When lines is active, includes 'output' key.
    """
    _check_tool_enabled("exec")
    return _exec_impl(command, args, timeout, shell=shell, lines=lines)


@mcp.tool()
def query(
    sql: str | None = None,
    filter: str | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    """Query stored log events with SQL or simple filter expressions.

    Use either `sql` for raw SQL queries or `filter` for simple expressions.

    Filter syntax:
        key=value      -> exact match (key = 'value')
        key=v1,v2      -> multiple values (key IN ('v1', 'v2'))
        key~pattern    -> contains (key ILIKE '%pattern%')
        key!=value     -> not equal (key != 'value')

    Multiple filters are AND'd together (space or comma separated).

    Args:
        sql: SQL query against blq_load_events() or other blq macros
        filter: Simple filter expressions (e.g., "severity=error ref_file~test")
        limit: Max rows to return (default: 100)

    Returns:
        Query results with columns, rows, and row_count

    Examples:
        query(sql="SELECT * FROM blq_load_events() WHERE severity = 'error'")
        query(filter="severity=error")
        query(filter="severity=error,warning ref_file~test")
        query(filter="tool_name=pytest", limit=50)
    """
    return _query_impl(sql=sql, filter=filter, limit=limit)


@mcp.tool()
def events(
    limit: int = 20,
    run_id: int | None = None,
    source: str | None = None,
    severity: str | None = None,
    file_pattern: str | None = None,
    all_runs: bool = False,
    # Batch mode
    run_ids: list[int] | None = None,
    limit_per_run: int = 10,
) -> dict[str, Any]:
    """Get events with optional severity filter.

    For errors only: use severity="error"
    For warnings only: use severity="warning"

    By default, shows events from the most recent run only.
    Use all_runs=True to show events from all runs.

    Args:
        limit: Max events to return (default: 20)
        run_id: Filter to specific run (by serial number, e.g., 1, 2, 3)
        source: Filter to specific source name
        severity: Filter by severity. Can be a single value (error, warning, info)
                  or comma-separated list (e.g., "error,warning")
        file_pattern: Filter by file path pattern (SQL LIKE)
        all_runs: Show events from all runs (default: False, shows only most recent)
        run_ids: List of run IDs for batch mode (returns events grouped by run)
        limit_per_run: Max events per run in batch mode (default: 10)

    Returns:
        Events list with total count. Each event includes a 'ref' field
        in format "tag:serial:event" or "serial:event".
        In batch mode, returns events grouped by run_id.
    """
    # Batch mode: get events from multiple runs
    if run_ids:
        runs = []
        total_events = 0

        for rid in run_ids:
            result = _events_impl(
                limit=limit_per_run,
                run_id=rid,
                source=source,
                severity=severity,
                file_pattern=file_pattern,
                include_suppressed=False,
                all_runs=True,  # In batch mode, we already have specific run_ids
            )
            event_count = len(result.get("events", []))
            total_events += event_count
            runs.append(
                {
                    "run_id": rid,
                    "event_count": event_count,
                    "events": result.get("events", []),
                }
            )

        return {
            "runs": runs,
            "total_events": total_events,
            "run_count": len(run_ids),
        }

    # Single run/all runs mode
    return _events_impl(
        limit, run_id, source, severity, file_pattern, include_suppressed=False, all_runs=all_runs
    )


@mcp.tool()
def inspect(
    ref: str,
    lines: int = 5,
    include_log_context: bool = True,
    include_source_context: bool = True,
    include_git_context: bool = False,
    include_fingerprint_history: bool = False,
    # Batch mode
    refs: list[str] | None = None,
) -> dict[str, Any]:
    """Get comprehensive event details with context and enrichment.

    Returns event details with optional context and enrichment:
    - log_context: Where the error appears in command output
    - source_context: Where the error is in source files
    - git_context: Git blame and recent commits for the file
    - fingerprint_history: Occurrence history and regression detection

    Args:
        ref: Event reference in format "tag:serial:event" (e.g., "build:1:3")
             or "serial:event" (e.g., "1:3")
        lines: Lines of context before/after (default: 5)
        include_log_context: Include surrounding log lines (default: true)
        include_source_context: Include source file context (default: true)
        include_git_context: Include git blame and history (default: false)
        include_fingerprint_history: Include fingerprint occurrence history (default: false)
        refs: List of event references for batch mode (overrides `ref`)

    Returns:
        Event details with ref, severity, ref_file, ref_line, ref_column,
        message, tool_name, category, code, fingerprint, and context/enrichment
        fields based on include_* flags.
        In batch mode, returns list of event details.
    """
    # Batch mode: get details for multiple events
    if refs:
        events_list: list[dict[str, Any]] = []
        found = 0

        for r in refs:
            result = _inspect_impl(
                r,
                lines,
                include_source=include_source_context,
                include_git=include_git_context,
                include_fingerprint=include_fingerprint_history,
            )
            if "error" not in result:
                found += 1
                # Optionally strip log context
                if not include_log_context:
                    result.pop("log_context", None)
                events_list.append({"ref": r, "event": result})
            else:
                events_list.append({"ref": r, "event": None, "error": result.get("error")})

        return {
            "events": events_list,
            "found": found,
            "total": len(refs),
        }

    # Single event mode
    result = _inspect_impl(
        ref,
        lines,
        include_source=include_source_context,
        include_git=include_git_context,
        include_fingerprint=include_fingerprint_history,
    )

    # Strip log context if not requested
    if not include_log_context:
        result.pop("log_context", None)

    return result


@mcp.tool()
def output(
    ref: str,
    stream: str | None = None,
    tail: int | None = None,
    head: int | None = None,
    grep: str | None = None,
    context: int = 0,
    lines: str | None = None,
    debug_formats: bool = False,
) -> dict[str, Any]:
    """Get raw output for a run with optional search and filtering.

    Retrieves the captured stdout/stderr from a command execution.
    Use tail or head to limit output size for large logs.
    Use grep to search for patterns with optional context lines.
    Use lines to select specific line ranges (requires read_lines extension).

    Args:
        ref: Run reference - can be run_id (e.g., '5'), tag:run_id (e.g., 'test:3'),
             or relative ref (e.g., '+1' for most recent, 'test:+1' for most recent test)
        stream: Stream name ('stdout', 'stderr', 'combined') or None for default
        tail: Return only last N lines
        head: Return only first N lines
        grep: Regex pattern to search for in output
        context: Lines of context around grep matches (default: 0)
        lines: Line spec (e.g., '100-200', '42 +/-5') - requires read_lines extension
        debug_formats: Show format detection diagnosis (which parsers matched)

    Returns:
        Output content and metadata including byte_length, total_lines, etc.
        With grep: includes match_count.
        With debug_formats: includes format_diagnosis list.
    """
    # Parse and resolve ref (supports relative refs like +1, test:+1)
    try:
        _, run_id = _parse_run_ref(ref)
    except ValueError as e:
        return {"error": str(e), "ref": ref}

    return _output_impl(run_id, stream, tail, head, grep, context, lines, debug_formats)


@mcp.tool()
def status() -> dict[str, Any]:
    """Get current status summary of all sources.

    Returns:
        Status summary with sources list
    """
    return _status_impl()


@mcp.tool()
def info(
    ref: str | None = None,
    head: int | None = None,
    tail: int | None = None,
    errors: bool = False,
    warnings: bool = False,
    severity: str | None = None,
    limit: int = 20,
    context: int | None = None,
) -> dict[str, Any]:
    """Get detailed information about a specific run.

    If ref is not provided, returns info about the most recent run.

    Args:
        ref: Run reference (e.g., 'test:5') or invocation_id (UUID).
             If not provided, uses the most recent run.
        head: Return first N lines of output
        tail: Return last N lines of output
        errors: Include error events
        warnings: Include warning events
        severity: Filter events by severity (e.g., 'error', 'error,warning')
        limit: Max events to return (default: 20)
        context: Show N lines of log context around each event (distinct from head/tail)

    Returns:
        Run info with optional output and events
    """
    # If no ref provided, get the most recent run
    if ref is None:
        return _last_impl(head, tail, errors, warnings, severity, limit, context)

    # Get info for specific run
    result = _info_impl(ref)

    # If additional output/events requested, fetch them
    needs_extra = (
        head is not None
        or tail is not None
        or errors
        or warnings
        or severity
        or context is not None
    )
    if needs_extra:
        run_serial = result.get("run_serial")
        is_running = result.get("is_running", False)
        attempt_id = result.get("attempt_id")

        if run_serial:
            try:
                storage = _get_storage()
                output_bytes = None
                log_lines = None

                # Load output if needed for head/tail or context
                if head is not None or tail is not None or context is not None:
                    # For running commands, read from live output directory
                    if is_running and attempt_id:
                        from blq.bird import BirdStore
                        from blq.commands.core import BlqConfig

                        config = BlqConfig.find()
                        if config:
                            bird_store = BirdStore.open(config.lq_dir)
                            try:
                                content = bird_store.read_live_output(
                                    attempt_id, "combined", tail=tail
                                )
                                if content:
                                    log_lines = content.splitlines()
                            finally:
                                bird_store.close()
                    else:
                        # For completed commands, read from blob storage
                        output_bytes = storage.get_output(run_serial)
                        if output_bytes:
                            try:
                                content = output_bytes.decode("utf-8", errors="replace")
                            except Exception:
                                content = output_bytes.decode("latin-1")
                            log_lines = content.splitlines()

                    if log_lines:
                        if head is not None:
                            result["head"] = log_lines[:head]
                        if tail is not None:
                            result["tail"] = log_lines[-tail:] if tail else log_lines

                # Get events if requested
                if errors or warnings or severity or context is not None:
                    sev_filter: str | None
                    if errors and warnings:
                        sev_filter = "error,warning"
                    elif errors:
                        sev_filter = "error"
                    elif warnings:
                        sev_filter = "warning"
                    elif context is not None:
                        # If context requested but no severity, default to errors
                        sev_filter = "error"
                    else:
                        sev_filter = severity

                    events_result = _events_impl(
                        limit=limit,
                        run_id=run_serial,
                        severity=sev_filter,
                    )
                    raw_events = events_result.get("events", [])

                    # Transform events based on whether context is requested
                    if context is not None and log_lines is not None:
                        # Compact format with context
                        events_list = []
                        errors_by_category: dict[str, int] = {}
                        for event in raw_events:
                            full_ref = event.get("ref") or ""
                            ref_file = event.get("ref_file")
                            ref_line = event.get("ref_line")
                            log_line = event.get("log_line")
                            category = event.get("category") or "other"

                            # Track category counts
                            errors_by_category[category] = errors_by_category.get(category, 0) + 1

                            # Use short ref: "test:47:242" -> "47:242"
                            parts = full_ref.split(":")
                            short_ref = ":".join(parts[-2:]) if len(parts) >= 2 else full_ref

                            # Build location
                            location = (
                                f"{ref_file}:{ref_line}" if ref_file and ref_line else ref_file
                            )

                            compact_event: dict[str, Any] = {
                                "ref": short_ref,
                                "location": location,
                            }

                            # Add context lines
                            if log_line is not None:
                                start = max(0, log_line - context - 1)
                                end = min(len(log_lines), log_line + context)
                                context_lines = []
                                for i in range(start, end):
                                    prefix = ">>> " if i == log_line - 1 else "    "
                                    context_lines.append(f"{prefix}{i + 1:4d} | {log_lines[i]}")
                                compact_event["context"] = "\n".join(context_lines)

                            events_list.append(compact_event)

                        result["events"] = events_list
                        result["errors_by_category"] = errors_by_category
                    else:
                        # Full format without context
                        result["events"] = raw_events

                    # Add aggregated summaries for failed runs
                    if raw_events and result.get("status") in ("FAIL", None):
                        summaries = _build_event_summaries(raw_events)
                        result["summary"] = summaries

                        # Get affected commits for files with errors
                        affected_files = [f["file"] for f in summaries.get("by_file", [])]
                        if affected_files:
                            commits = _get_affected_commits(affected_files)
                            if commits:
                                result["summary"]["affected_commits"] = commits
            except Exception:
                pass  # Silently skip if can't fetch additional data

    return result


def _last_impl(
    head: int | None = None,
    tail: int | None = None,
    errors: bool = False,
    warnings: bool = False,
    severity: str | None = None,
    limit: int = 20,
    context: int | None = None,
) -> dict[str, Any]:
    """Implementation of last command - get info about most recent run."""
    try:
        storage = _get_storage()
        if not storage.has_data():
            return {"error": "No data available"}

        # Get most recent run
        df = storage.sql("""
            SELECT * FROM blq_load_runs()
            ORDER BY run_id DESC
            LIMIT 1
        """).df()

        if df.empty:
            return {"error": "No runs found"}

        row = df.iloc[0]
        run_serial = _safe_int(row.get("run_id")) or 0
        invocation_id = _to_json_safe(row.get("invocation_id"))

        # Build run_ref
        tag = _to_json_safe(row.get("tag"))
        if tag:
            run_ref = f"{tag}:{run_serial}"
        else:
            run_ref = str(run_serial)

        result: dict[str, Any] = {
            "run_ref": run_ref,
            "run_serial": run_serial,
            "invocation_id": invocation_id,
            "source_name": _to_json_safe(row.get("source_name")),
            "command": _to_json_safe(row.get("command")),
            "status": _to_json_safe(row.get("status")),
            "exit_code": _safe_int(row.get("exit_code")),
            "error_count": _safe_int(row.get("error_count")) or 0,
            "warning_count": _safe_int(row.get("warning_count")) or 0,
            "started_at": _to_json_safe(row.get("started_at")),
            "git_branch": _to_json_safe(row.get("git_branch")),
            "git_commit": _to_json_safe(row.get("git_commit")),
        }

        # Load output if needed
        log_lines = None
        if head is not None or tail is not None or context is not None:
            output_bytes = storage.get_output(run_serial)
            if output_bytes:
                try:
                    content = output_bytes.decode("utf-8", errors="replace")
                except Exception:
                    content = output_bytes.decode("latin-1")
                log_lines = content.splitlines()

                if head is not None:
                    result["head"] = log_lines[:head]
                if tail is not None:
                    result["tail"] = log_lines[-tail:] if tail else log_lines

        # Get events if requested
        if errors or warnings or severity or context is not None:
            # Determine severity filter
            sev_filter: str | None
            if errors and warnings:
                sev_filter = "error,warning"
            elif errors:
                sev_filter = "error"
            elif warnings:
                sev_filter = "warning"
            elif context is not None:
                # If context requested but no severity, default to errors
                sev_filter = "error"
            else:
                sev_filter = severity

            conditions = [f"run_serial = {run_serial}"]
            if sev_filter and "," in sev_filter:
                severities = [s.strip() for s in sev_filter.split(",")]
                severity_list = ", ".join(f"'{s}'" for s in severities)
                conditions.append(f"severity IN ({severity_list})")
            elif sev_filter:
                conditions.append(f"severity = '{sev_filter}'")

            where = " AND ".join(conditions)
            events_df = storage.sql(f"""
                SELECT * FROM blq_load_events()
                WHERE {where}
                ORDER BY event_id
                LIMIT {limit}
            """).df()

            events_list = []
            errors_by_category: dict[str, int] = {}
            for _, erow in events_df.iterrows():
                full_ref = _to_json_safe(erow.get("ref")) or ""
                ref_file = _to_json_safe(erow.get("ref_file"))
                ref_line = _safe_int(erow.get("ref_line"))
                log_line = _safe_int(erow.get("log_line_start"))
                category = _to_json_safe(erow.get("category")) or "other"

                # Track category counts
                errors_by_category[category] = errors_by_category.get(category, 0) + 1

                if context is not None and log_lines is not None:
                    # Compact format when context is present
                    # Use short ref (strip tag prefix): "test:47:242" -> "47:242"
                    parts = full_ref.split(":")
                    short_ref = ":".join(parts[-2:]) if len(parts) >= 2 else full_ref

                    # Build location from file:line
                    location = f"{ref_file}:{ref_line}" if ref_file and ref_line else ref_file

                    event: dict[str, Any] = {
                        "ref": short_ref,
                        "location": location,
                    }

                    # Add context lines
                    if log_line is not None:
                        start = max(0, log_line - context - 1)
                        end = min(len(log_lines), log_line + context)
                        context_lines = []
                        for i in range(start, end):
                            prefix = ">>> " if i == log_line - 1 else "    "
                            context_lines.append(f"{prefix}{i + 1:4d} | {log_lines[i]}")
                        event["context"] = "\n".join(context_lines)
                else:
                    # Full format when no context
                    event = {
                        "ref": full_ref,
                        "severity": _to_json_safe(erow.get("severity")),
                        "ref_file": ref_file,
                        "ref_line": ref_line,
                        "message": _to_json_safe(erow.get("message")),
                        "log_line": log_line,
                    }

                events_list.append(event)

            result["events"] = events_list
            if context is not None:
                result["errors_by_category"] = errors_by_category

            # Add aggregated summaries for failed runs
            if events_list and result.get("status") in ("FAIL", None):
                # Convert events to dict format for summary builder
                raw_events = []
                for _, erow in events_df.iterrows():
                    raw_events.append(
                        {
                            "fingerprint": _to_json_safe(erow.get("fingerprint")),
                            "message": _to_json_safe(erow.get("message")),
                            "ref": _to_json_safe(erow.get("ref")),
                            "ref_file": _to_json_safe(erow.get("ref_file")),
                        }
                    )

                summaries = _build_event_summaries(raw_events)
                result["summary"] = summaries

                # Get affected commits for files with errors
                affected_files = [f["file"] for f in summaries.get("by_file", [])]
                if affected_files:
                    commits = _get_affected_commits(affected_files)
                    if commits:
                        result["summary"]["affected_commits"] = commits

        return result

    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def history(
    limit: int = 20, source: str | None = None, status: str | None = None
) -> dict[str, Any]:
    """Get run history.

    Args:
        limit: Max runs to return (default: 20)
        source: Filter to specific source name
        status: Filter by run status ('running', 'completed', 'orphaned')

    Returns:
        Run history list
    """
    return _history_impl(limit, source, status)


@mcp.tool()
def diff(run1: int, run2: int) -> dict[str, Any]:
    """Compare errors between two runs.

    Args:
        run1: First run serial number (baseline)
        run2: Second run serial number (comparison)

    Returns:
        Diff summary with fixed and new errors
    """
    return _diff_impl(run1, run2)


@mcp.tool()
def register_command(
    name: str,
    cmd: str | None = None,
    tpl: str | None = None,
    defaults: dict[str, str] | None = None,
    description: str = "",
    timeout: int | None = None,
    capture: bool = True,
    force: bool = False,
    format: str | None = None,
    run_now: bool = False,
    lines: str | None = None,
) -> dict[str, Any]:
    """Register a new command.

    If a command with the same name or same command string already exists,
    returns the existing command (and runs it if run_now=True) instead of
    failing. Use force=True to overwrite an existing command.

    Note: This tool can be disabled via mcp.disabled_tools config.

    Args:
        name: Command name (e.g., 'build', 'test')
        cmd: Command to run (for simple commands)
        tpl: Template command with {param} placeholders (alternative to cmd)
        defaults: Default values for template parameters (e.g., {"path": "tests/"})
        description: Command description
        timeout: Timeout in seconds (default: no timeout)
        capture: Whether to capture and parse logs (default: true)
        force: Overwrite existing command if it exists
        format: Log format for parsing (auto-detected from command if not specified)
        run_now: Run the command immediately after registering (default: false)
        lines: Default line selection for output (e.g., '+20-' for last 20 lines).
               Saved in command config; used automatically on each run unless overridden.

    Returns:
        Success status and registered command details. If run_now=True,
        also includes 'run' key with the run result.
    """
    _check_tool_enabled("register_command")
    return _register_command_impl(
        name, cmd, tpl, defaults, description, timeout, capture, force, format, run_now, lines
    )


@mcp.tool()
def unregister_command(name: str) -> dict[str, Any]:
    """Remove a registered command.

    Note: This tool can be disabled via mcp.disabled_tools config.

    Args:
        name: Command name to remove

    Returns:
        Success status
    """
    _check_tool_enabled("unregister_command")
    return _unregister_command_impl(name)


@mcp.tool()
def commands() -> dict[str, Any]:
    """List all registered commands.

    Returns:
        List of registered commands with their configuration
    """
    return _commands_impl()


def _clean_impl(
    mode: str = "data",
    confirm: bool = False,
    days: int | None = None,
    max_runs: int | None = None,
    max_size_mb: int | None = None,
) -> dict[str, Any]:
    """Implementation of clean command."""
    import shutil
    from pathlib import Path

    valid_modes = ["data", "prune", "schema", "full"]

    if mode not in valid_modes:
        return {
            "success": False,
            "error": f"Invalid mode '{mode}'. Valid modes: {', '.join(valid_modes)}",
        }

    if mode == "prune" and days is None and max_runs is None and max_size_mb is None:
        return {
            "success": False,
            "error": "Prune mode requires at least one of: days, max_runs, max_size_mb",
        }

    if not confirm:
        desc = {
            "data": "Clear run data but keep config and commands",
            "schema": "Recreate database schema (clears data, keeps config)",
            "full": "Delete and recreate entire .lq directory",
        }
        if mode == "prune":
            parts = []
            if days is not None:
                parts.append(f"older than {days} days")
            if max_runs is not None:
                parts.append(f"exceeding {max_runs} runs per source")
            if max_size_mb is not None:
                parts.append(f"exceeding {max_size_mb} MB total output")
            desc["prune"] = "Remove data " + " and ".join(parts)

        return {
            "success": False,
            "error": "Clean requires confirm=true to proceed. This is a destructive operation.",
            "mode": mode,
            "description": desc.get(mode, "Unknown mode"),
        }

    try:
        # Find .lq directory
        lq_dir = None
        current = Path.cwd()
        while current != current.parent:
            if (current / ".lq").exists():
                lq_dir = current / ".lq"
                break
            current = current.parent

        if lq_dir is None:
            return {"success": False, "error": "No .lq directory found"}

        if mode == "data":
            # Clear data tables but keep schema and config
            db_path = lq_dir / "blq.duckdb"
            if db_path.exists():
                import duckdb

                conn = duckdb.connect(str(db_path))
                conn.execute("DELETE FROM events")
                conn.execute("DELETE FROM outputs")
                conn.execute("DELETE FROM invocations")
                conn.execute("DELETE FROM sessions")
                conn.close()

            # Clear blobs
            blobs_dir = lq_dir / "blobs"
            if blobs_dir.exists():
                shutil.rmtree(blobs_dir)
                blobs_dir.mkdir()
                (blobs_dir / "content").mkdir()

            return {
                "success": True,
                "message": "Cleared all run data. Config and commands preserved.",
                "mode": mode,
            }

        elif mode == "prune":
            db_path = lq_dir / "blq.duckdb"
            if not db_path.exists():
                return {"success": False, "error": "No database found", "mode": mode}

            total_pruned = 0
            removed: dict[str, int] = {}

            with BlqStorage.open(lq_dir) as storage:
                if days is not None:
                    pruned = storage.prune(days=days)
                    total_pruned += pruned
                    removed["by_age"] = pruned

                if max_runs is not None:
                    pruned = storage.prune_by_max_runs(max_runs)
                    total_pruned += pruned
                    removed["by_max_runs"] = pruned

                if max_size_mb is not None:
                    pruned = storage.prune_by_size(max_size_mb)
                    total_pruned += pruned
                    removed["by_size"] = pruned

                blobs_deleted = 0
                bytes_freed = 0
                if total_pruned > 0:
                    blobs_deleted, bytes_freed = storage.cleanup_blobs()

            removed["total_invocations"] = total_pruned
            removed["blobs"] = blobs_deleted
            removed["bytes_freed"] = bytes_freed

            parts = []
            if days is not None:
                parts.append(f"age>{days}d")
            if max_runs is not None:
                parts.append(f"max_runs={max_runs}")
            if max_size_mb is not None:
                parts.append(f"max_size={max_size_mb}MB")

            return {
                "success": True,
                "message": f"Pruned {total_pruned} invocations ({', '.join(parts)}).",
                "mode": mode,
                "removed": removed,
            }

        elif mode == "schema":
            # Recreate database with fresh schema
            db_path = lq_dir / "blq.duckdb"
            if db_path.exists():
                db_path.unlink()

            # Clear blobs
            blobs_dir = lq_dir / "blobs"
            if blobs_dir.exists():
                shutil.rmtree(blobs_dir)
                blobs_dir.mkdir()
                (blobs_dir / "content").mkdir()

            # Recreate database with schema
            from blq.bird import BirdStore

            store = BirdStore.open(lq_dir)
            store.close()

            return {
                "success": True,
                "message": "Recreated database schema. Config files preserved.",
                "mode": mode,
            }

        elif mode == "full":
            # Full reinitialize
            shutil.rmtree(lq_dir)

            # Run init (use sys.executable for venv compatibility)
            init_proc = subprocess.run(
                [sys.executable, "-m", "blq", "init"],
                capture_output=True,
                text=True,
                cwd=lq_dir.parent,
            )

            if init_proc.returncode == 0:
                return {
                    "success": True,
                    "message": "Fully reinitialized .lq directory.",
                    "mode": mode,
                }
            else:
                return {
                    "success": False,
                    "error": f"Init failed: {init_proc.stderr}",
                    "mode": mode,
                }

        else:
            # Should never reach here since mode is validated
            return {"success": False, "error": f"Unhandled mode: {mode}"}

    except Exception as e:
        return {"success": False, "error": str(e), "mode": mode}


@mcp.tool()
def clean(
    mode: str = "data",
    confirm: bool = False,
    days: int | None = None,
    max_runs: int | None = None,
    max_size_mb: int | None = None,
) -> dict[str, Any]:
    """Database cleanup and maintenance.

    Note: This tool can be disabled via mcp.disabled_tools config.

    Args:
        mode: Cleanup mode:
            - "data": Clear all run data but keep config and commands
            - "prune": Remove data by age, run count, or size. Requires at least
              one of: days, max_runs, max_size_mb
            - "schema": Recreate database schema (clears data, keeps config files)
            - "full": Delete and recreate entire .lq directory
        confirm: Must be true to proceed (safety check)
        days: For prune mode, remove data older than this many days
        max_runs: For prune mode, keep at most N runs per source
        max_size_mb: For prune mode, keep total output under N MB

    Returns:
        Success status and message
    """
    _check_tool_enabled("clean")
    return _clean_impl(mode, confirm, days, max_runs, max_size_mb)


# ============================================================================
# CI Tool Implementations
# ============================================================================


def _report_impl(
    ref: str | None = None,
    baseline: str | None = None,
    warnings: bool = False,
    summary_only: bool = False,
    error_limit: int = 20,
    file_limit: int = 10,
) -> dict[str, Any]:
    """Implementation of report tool - generate markdown report.

    Args:
        ref: Run reference (e.g., 'test:5'). None for latest run.
        baseline: Baseline for comparison (run ID or branch name)
        warnings: Include warning details
        summary_only: Summary without individual error details
        error_limit: Max errors to include
        file_limit: Max files in breakdown
    """
    try:
        storage = _get_storage()

        # Resolve run_id from ref
        run_id = None
        if ref is not None:
            try:
                _, run_id = _parse_run_ref(ref, storage)
            except ValueError as e:
                return {"error": str(e), "ref": ref}

        # Find baseline
        baseline_id = None
        if baseline is not None:
            baseline_id = _find_baseline_run(storage, baseline)
            if baseline_id is None:
                return {
                    "error": f"Baseline '{baseline}' not found",
                    "hint": "Specify a run ID, branch name, or commit SHA",
                }

        # Collect data and generate report
        data = _collect_report_data(
            storage,
            run_id=run_id,
            baseline_id=baseline_id,
            error_limit=error_limit,
            file_limit=file_limit,
        )

        if data.run_id is None:
            return {"error": "No runs found"}

        report = _generate_markdown_report(
            data,
            include_warnings=warnings,
            include_details=not summary_only,
        )

        return {
            "report": report,
            "run_id": _safe_int(data.run_id),
            "source_name": _to_json_safe(data.source_name),
            "total_errors": _safe_int(data.total_errors) or 0,
            "total_warnings": _safe_int(data.total_warnings) or 0,
            "exit_code": _safe_int(data.exit_code),
            "has_baseline": baseline_id is not None,
        }
    except FileNotFoundError:
        return {"error": "No lq repository found"}
    except Exception as e:
        return {"error": str(e)}


def _ci_check_impl(
    baseline: str | None = None,
    fail_on_any: bool = False,
    run_id: int | None = None,
    source: str | None = None,
) -> dict[str, Any]:
    """Implementation of ci_check tool - check for regressions.

    Args:
        baseline: Baseline specifier (run ID, branch name, or commit SHA).
                  If not specified, tries main/master.
        fail_on_any: If True, fail on any errors (no baseline comparison)
        run_id: Specific run to check (None = auto-detect current)
        source: Source name to filter by
    """
    try:
        storage = _get_storage()

        # Find current run
        current_id: int
        if run_id is not None:
            current_id = run_id
        else:
            found = _find_current_run(storage)
            if found is None:
                return {"error": "No runs found", "status": "ERROR"}
            current_id = found

        # Handle fail_on_any mode (no baseline comparison)
        if fail_on_any:
            current_errors = storage.error_count(current_id)
            return {
                "status": "FAIL" if current_errors > 0 else "OK",
                "current_run_id": current_id,
                "current_errors": current_errors,
                "has_errors": current_errors > 0,
                "mode": "fail_on_any",
            }

        # Find baseline
        baseline_id = _find_baseline_run(storage, baseline)

        # Compute diff
        diff = _compute_diff(storage, baseline_id, current_id)

        result: dict[str, Any] = {
            "status": "FAIL" if diff.has_new_errors else "OK",
            "current_run_id": diff.current_run_id,
            "current_errors": diff.current_errors,
            "has_new_errors": diff.has_new_errors,
            "mode": "baseline_comparison",
        }

        if baseline_id is not None:
            result["baseline_run_id"] = diff.baseline_run_id
            result["baseline_errors"] = diff.baseline_errors
            result["fixed_count"] = len(diff.fixed)
            result["new_count"] = len(diff.new_errors)
            result["delta"] = diff.delta

            # Include new errors (limited)
            if diff.new_errors:
                result["new_errors"] = [
                    {
                        "ref_file": e.get("ref_file"),
                        "ref_line": e.get("ref_line"),
                        "message": (e.get("message") or "")[:100],
                        "fingerprint": e.get("fingerprint"),
                    }
                    for e in diff.new_errors[:20]
                ]
        else:
            result["baseline_warning"] = (
                f"Baseline '{baseline}' not found"
                if baseline
                else "No baseline found (no main/master branch runs)"
            )

        return result
    except FileNotFoundError:
        return {"error": "No lq repository found", "status": "ERROR"}
    except Exception as e:
        return {"error": str(e), "status": "ERROR"}


def _ci_generate_impl(
    commands_filter: list[str] | None = None,
    shell: str = "bash",
) -> dict[str, Any]:
    """Implementation of ci_generate tool - generate CI shell scripts.

    Returns script content rather than writing to disk,
    so the agent can decide what to do with it.

    Args:
        commands_filter: List of command names to generate scripts for.
                         None = all registered commands.
        shell: Shell to use (bash, sh, zsh)
    """
    try:
        from blq.cli import BlqConfig

        config = BlqConfig.find()
        if config is None:
            return {"error": "No lq repository found. Run 'blq init' first."}

        registered = config.commands
        if not registered:
            return {"error": "No registered commands found", "scripts": []}

        # Validate shell
        if shell not in ("bash", "sh", "zsh"):
            return {"error": f"Invalid shell '{shell}'. Use: bash, sh, zsh"}

        # Filter commands
        command_names = commands_filter or list(registered.keys())
        missing = set(command_names) - set(registered.keys())
        if missing:
            return {
                "error": f"Unknown commands: {', '.join(sorted(missing))}",
                "available": sorted(registered.keys()),
            }

        # Generate scripts
        scripts = []
        for name in sorted(command_names):
            cmd = registered[name]
            content = _generate_script(cmd, shell)
            scripts.append(
                {
                    "name": f"{name}.sh",
                    "command_name": name,
                    "content": content,
                    "is_template": cmd.is_template,
                    "description": cmd.description or "",
                }
            )

        return {
            "scripts": scripts,
            "count": len(scripts),
            "shell": shell,
        }
    except Exception as e:
        return {"error": str(e)}


# ============================================================================
# CI Tool Wrappers
# ============================================================================


@mcp.tool()
def report(
    ref: str | None = None,
    baseline: str | None = None,
    warnings: bool = False,
    summary_only: bool = False,
    error_limit: int = 20,
    file_limit: int = 10,
) -> dict[str, Any]:
    """Generate a markdown report summarizing build/test results.

    Produces a formatted report suitable for PR descriptions, CI summaries,
    or team communication. Optionally compares against a baseline run.

    Args:
        ref: Run reference (e.g., 'test:5', '+1'). Default: latest run.
        baseline: Baseline for comparison - run ID, branch name, or commit SHA.
        warnings: Include warning details in the report (default: false)
        summary_only: Generate summary without individual error details (default: false)
        error_limit: Max errors to include in details (default: 20)
        file_limit: Max files in breakdown table (default: 10)

    Returns:
        Report with 'report' key containing markdown content, plus metadata
        like run_id, total_errors, total_warnings.
    """
    return _report_impl(ref, baseline, warnings, summary_only, error_limit, file_limit)


@mcp.tool()
def ci_check(
    baseline: str | None = None,
    fail_on_any: bool = False,
    run_id: int | None = None,
) -> dict[str, Any]:
    """Check for regressions compared to a baseline run.

    Compares error fingerprints between the current run and a baseline to
    detect new errors (regressions) vs fixed errors (improvements).

    Without a baseline specified, auto-detects by looking for main/master
    branch runs.

    Args:
        baseline: Baseline to compare against - run ID, branch name, or
                  commit SHA. If not specified, tries main then master.
        fail_on_any: If true, check fails on any errors (no baseline needed)
        run_id: Specific run ID to check. Default: auto-detect current run
                by matching git commit or using latest.

    Returns:
        Check result with 'status' ('OK' or 'FAIL'), error counts,
        and details of new/fixed errors when baseline is available.
    """
    return _ci_check_impl(baseline, fail_on_any, run_id)


@mcp.tool()
def ci_generate(
    commands: list[str] | None = None,
    shell: str = "bash",
) -> dict[str, Any]:
    """Generate standalone shell scripts from registered commands.

    Creates shell script content for CI environments where blq may not be
    installed. Scripts include blq integration when available, with fallback
    to direct command execution.

    Returns script content (does not write to disk). Template commands get
    full argument parsing with --param flags.

    Args:
        commands: Command names to generate scripts for. Default: all commands.
        shell: Shell to use: 'bash', 'sh', or 'zsh' (default: 'bash')

    Returns:
        Generated scripts with 'scripts' list containing name, content,
        and metadata for each script.
    """
    return _ci_generate_impl(commands, shell)


# ============================================================================
# Resources
# ============================================================================


@mcp.resource("blq://status")
def resource_status() -> str:
    """Current status of all sources."""
    result = _status_impl()
    return json.dumps(result, indent=2, default=str)


@mcp.resource("blq://runs")
def resource_runs() -> str:
    """List of all runs."""
    result = _history_impl(limit=100)
    return json.dumps(result, indent=2, default=str)


@mcp.resource("blq://events")
def resource_events() -> str:
    """All stored events."""
    result = _errors_impl(limit=100)
    return json.dumps(result, indent=2, default=str)


@mcp.resource("blq://event/{ref}")
def resource_event(ref: str) -> str:
    """Single event details."""
    result = _event_impl(ref)
    return json.dumps(result, indent=2, default=str)


@mcp.resource("blq://errors")
def resource_errors() -> str:
    """Recent errors across all runs."""
    result = _errors_impl(limit=50)
    return json.dumps(result, indent=2, default=str)


@mcp.resource("blq://errors/{run_serial}")
def resource_errors_for_run(run_serial: str) -> str:
    """Errors for a specific run."""
    try:
        run_id = int(run_serial)
        result = _errors_impl(limit=100, run_id=run_id)
    except ValueError:
        result = {"errors": [], "total_count": 0, "error": f"Invalid run serial: {run_serial}"}
    return json.dumps(result, indent=2, default=str)


@mcp.resource("blq://warnings")
def resource_warnings() -> str:
    """Recent warnings across all runs."""
    result = _warnings_impl(limit=50)
    return json.dumps(result, indent=2, default=str)


@mcp.resource("blq://warnings/{run_serial}")
def resource_warnings_for_run(run_serial: str) -> str:
    """Warnings for a specific run."""
    try:
        run_id = int(run_serial)
        result = _warnings_impl(limit=100, run_id=run_id)
    except ValueError:
        result = {"warnings": [], "total_count": 0, "error": f"Invalid run serial: {run_serial}"}
    return json.dumps(result, indent=2, default=str)


@mcp.resource("blq://context/{ref}")
def resource_context(ref: str) -> str:
    """Log context around a specific event."""
    result = _context_impl(ref, lines=5)
    return json.dumps(result, indent=2, default=str)


@mcp.resource("blq://commands")
def resource_commands() -> str:
    """Registered commands."""
    try:
        from blq.cli import BlqConfig

        config = BlqConfig.find()
        if config is not None:
            commands = config.commands
            return json.dumps({"commands": commands}, indent=2, default=str)
    except Exception:
        pass
    return json.dumps({"commands": []}, indent=2)


@mcp.resource("blq://guide")
def resource_guide() -> str:
    """Agent usage guide for blq MCP tools."""
    try:
        from importlib import resources

        guide = resources.files("blq").joinpath("SKILL.md").read_text()
        return guide
    except Exception:
        return """# blq Quick Reference

## Key Tools
- status() - Overview of all sources
- commands() - Registered commands
- events(severity="error") - Get errors
- inspect(ref) - Error details with context (ref like "build:1:3")
- diff(run1, run2) - Compare runs
- run(command) - Run registered command (use args={} for template params)
- info() - Most recent run details (or info(ref) for specific run)
- clean(mode, confirm) - Database cleanup

## Workflow
1. commands() or status() to see current state
2. events(severity="error") to get recent errors
3. inspect(ref) to understand issues with full context
4. After fixes: diff(run1, run2) to verify

## Template Commands
Commands with `tpl` use placeholders: run(command="test", args={"path": "tests/unit/"})

Docs: https://blq-cli.readthedocs.io/en/latest/
"""


# ============================================================================
# Prompts
# ============================================================================


@mcp.prompt(name="fix-errors")
def fix_errors(run_id: int | None = None, file_pattern: str | None = None) -> str:
    """Guide through fixing build errors systematically."""
    # Get current errors
    error_result = _errors_impl(limit=20, run_id=run_id, file_pattern=file_pattern)
    status_result = _status_impl()

    # Build status table
    status_lines = [
        "| Source | Status | Errors | Warnings |",
        "|--------|--------|--------|----------|",
    ]
    for src in status_result.get("sources", []):
        status_lines.append(
            f"| {src['name']} | {src['status']} | {src['error_count']} | {src['warning_count']} |"
        )
    status_table = "\n".join(status_lines)

    # Build error list
    error_lines = []
    for i, err in enumerate(error_result.get("errors", []), 1):
        loc = f"{err.get('ref_file', '?')}:{err.get('ref_line', '?')}"
        if err.get("ref_column"):
            loc += f":{err['ref_column']}"
        error_lines.append(
            f"{i}. **ref: {err['ref']}** `{loc}`\n   ```\n   {err.get('message', '')}\n   ```"
        )
    error_list = "\n\n".join(error_lines) if error_lines else "No errors found."

    return f"""You are helping fix build errors in a software project.

## Current Status

{status_table}

## Errors to Fix

{error_list}

## Instructions

1. Read each error and understand the root cause
2. Use `event(ref="...")` for full context if the message is unclear
3. Use `context(ref="...")` to see surrounding log lines
4. Fix errors in dependency order:
   - Missing includes/declarations first
   - Then type errors
   - Then syntax errors
5. After fixing, run `run(command="...")` to verify
6. Repeat until build passes

Focus on fixing the root cause, not just suppressing warnings."""


@mcp.prompt(name="analyze-regression")
def analyze_regression(good_run: int | None = None, bad_run: int | None = None) -> str:
    """Help identify why a build started failing between two runs."""
    # Get run history to find good/bad runs if not specified
    hist = _history_impl(limit=10)
    runs = hist.get("runs", [])

    if not runs:
        return 'No runs found. Run a build first with `run(command="...")`.'

    if bad_run is None:
        bad_run = runs[0]["run_serial"] if runs else 1
    if good_run is None:
        # Find last passing run
        for r in runs[1:]:
            if r["status"] == "OK":
                good_run = r["run_serial"]
                break
        if good_run is None:
            good_run = bad_run - 1 if bad_run > 1 else 1

    # Get diff
    diff_result = _diff_impl(good_run, bad_run)
    summary = diff_result.get("summary", {})

    # Build new errors list
    new_error_lines = []
    for err in diff_result.get("new", []):
        loc = f"{err.get('ref_file', '?')}:{err.get('ref_line', '?')}"
        new_error_lines.append(f"- **ref: {err['ref']}** `{loc}`\n  {err.get('message', '')}")
    new_errors = "\n".join(new_error_lines) if new_error_lines else "None"

    return f"""You are analyzing why a build started failing.

## Run Comparison

| Metric | Run {good_run} (good) | Run {bad_run} (bad) | Delta |
|--------|--------------|-------------|-------|
| Errors | {summary.get("run1_errors", 0)} | {summary.get("run2_errors", 0)} | \
+{summary.get("new", 0)} |

## New Errors (not in Run {good_run})

{new_errors}

## Instructions

1. Review the new errors that appeared
2. Look for patterns (same file, same error type)
3. Use `event(ref="...")` for full error context
4. Identify the root cause
5. Suggest the minimal fix to restore the build"""


@mcp.prompt(name="summarize-run")
def summarize_run(run_id: int | None = None, format: str = "brief") -> str:
    """Generate a concise summary of a build/test run."""
    hist = _history_impl(limit=1)
    runs = hist.get("runs", [])

    if not runs:
        return 'No runs found. Run a build first with `run(command="...")`.'

    if run_id is None:
        run_id = runs[0]["run_serial"]

    # Get run info
    run_info = None
    for r in runs:
        if r["run_serial"] == run_id:
            run_info = r
            break

    if not run_info:
        run_info = runs[0]

    error_result = _errors_impl(limit=10, run_id=run_id)

    # Build error details
    error_lines = []
    for err in error_result.get("errors", []):
        loc = f"{err.get('ref_file', '?')}:{err.get('ref_line', '?')}"
        error_lines.append(f"- `{loc}` - {err.get('message', '')[:80]}")
    error_details = "\n".join(error_lines) if error_lines else "No errors"

    return f"""Summarize this build/test run.

## Run Details

- **Run:** {run_info["run_ref"]}
- **Status:** {run_info["status"]}
- **Errors:** {run_info.get("error_count", 0)}
- **Warnings:** {run_info.get("warning_count", 0)}

## Error Details

{error_details}

## Instructions

Generate a summary suitable for a GitHub PR comment:
- Lead with pass/fail status
- List the key errors (not all warnings)
- Suggest what might have caused the failure
- Keep it concise"""


@mcp.prompt(name="investigate-flaky")
def investigate_flaky(test_pattern: str | None = None, lookback: int = 10) -> str:
    """Help investigate intermittently failing tests."""
    hist = _history_impl(limit=lookback)
    runs = hist.get("runs", [])

    if not runs:
        return 'No runs found. Run tests first with `run(command="...")`.'

    # Build history table
    history_lines = ["| Run | Status | Errors |", "|-----|--------|--------|"]
    for r in runs:
        history_lines.append(f"| {r['run_ref']} | {r['status']} | {r.get('error_count', 0)} |")
    history_table = "\n".join(history_lines)

    return f"""You are investigating flaky (intermittently failing) tests.

## Test History (last {lookback} runs)

{history_table}

## Instructions

1. Look for patterns in failures
2. Use `errors(run_id=N)` to see errors for specific runs
3. Use `event(ref="...")` for detailed failure output
4. Look for:
   - Race conditions (concurrent, parallel, thread)
   - Timing issues (timeout, sleep, wait)
   - Resource contention (connection, file, lock)
5. Suggest fixes to make tests more deterministic"""


# ============================================================================
# Entry point
# ============================================================================


def serve(
    transport: str = "stdio",
    port: int = 8080,
    disabled_tools: str | None = None,
    safe_mode: bool = False,
) -> None:
    """Start the MCP server.

    Args:
        transport: Transport type ("stdio" or "sse")
        port: Port for SSE transport
        disabled_tools: Comma-separated list of tools to disable
        safe_mode: If True, disable state-modifying tools (exec, clean, register/unregister)
    """
    # Initialize disabled tools before starting the server
    _init_disabled_tools(cli_disabled=disabled_tools, safe_mode=safe_mode)

    if transport == "stdio":
        mcp.run()
    elif transport == "sse":
        mcp.run(transport="sse", port=port)
    else:
        raise ValueError(f"Unknown transport: {transport}")


if __name__ == "__main__":
    serve()
