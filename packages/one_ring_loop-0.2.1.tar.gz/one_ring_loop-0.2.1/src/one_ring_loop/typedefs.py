from __future__ import annotations

from collections.abc import Generator
from typing import TYPE_CHECKING

from one_ring_core.operations import IOOperation
from one_ring_core.results import IOCompletion, IOResult
from one_ring_core.typedefs import WorkerOperationID
from one_ring_loop.operations import Checkpoint

if TYPE_CHECKING:
    from one_ring_loop.operations import Park, WaitsOn


type TaskID = WorkerOperationID

type EventLoopOperation = IOOperation[IOResult] | WaitsOn | Park | Checkpoint
type Coro[T] = Generator[EventLoopOperation, IOCompletion[IOResult] | None, T]
