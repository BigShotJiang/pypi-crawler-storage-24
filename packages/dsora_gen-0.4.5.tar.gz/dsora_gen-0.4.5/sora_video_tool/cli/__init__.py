"""
CLI package — entry point `dsg`
  dsg setup           — cau hinh profiles va mo Chrome de dang nhap
  dsg setup --retry   — mo lai profile cu de dang nhap lai
  dsg run             — chay tu dong tao video
  dsg check           — kiem tra setup hien tai
  dsg open <alias>    — mo Chrome cho mot profile
  dsg update          — cap nhat package
  dsg help            — hien thi huong dan
"""
from __future__ import annotations

import click

from .common import ensure_playwright_browsers
from .setup import register_setup
from .run import register_run
from .commands import register_open, register_update, register_check, register_help, register_uninstall, register_add_profile
from .share import register_share
from .fix_mp4 import register_fix_mp4


@click.group()
def main() -> None:
    """Sora Video Tool — Tu dong tao video Sora theo batch."""
    ensure_playwright_browsers()


register_setup(main)
register_run(main)
register_share(main)
register_fix_mp4(main)
register_open(main)
register_add_profile(main)
register_update(main)
register_uninstall(main)
register_check(main)
register_help(main)

__all__ = ["main"]
