"""REPL module for aceiot-models-cli."""

# NOTE: Imports removed from __init__.py to avoid circular dependency
# with commands.base. Import directly from submodules instead:
#   from aceiot_models_cli.repl.core_new import AceIoTRepl

__all__ = ["AceIoTRepl"]
