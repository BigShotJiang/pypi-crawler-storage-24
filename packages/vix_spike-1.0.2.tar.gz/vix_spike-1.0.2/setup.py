"""
Setup script for vix-pricer package.

For modern installations, pyproject.toml is preferred.
This file is provided for backward compatibility.
"""

from setuptools import setup

# Read long description from README
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    long_description = "A Python library for pricing VIX options using shot noise models"

setup(
    name="VIX-Spike",
    version="1.0.2",
    author="VIX Spike VolOfVol Research Team",
    # author_email="your.email@example.com",  # Optional: add your email
    description="A Python library for pricing VIX options using shot noise models",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=["Pricer"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Office/Business :: Financial",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
        "scipy>=1.7.0",
        "pandas>=1.3.0",
        "tqdm>=4.60.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
            "mypy>=0.950",
        ],
    },
    keywords="vix options pricing finance derivatives monte-carlo fft shot-noise",
)
