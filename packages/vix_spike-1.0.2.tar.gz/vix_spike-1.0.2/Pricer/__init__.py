"""
VIX Pricer - VIX Option Pricing Library
========================================

A modular Python library for pricing VIX options using shot noise models.
Implements both FFT-based and Monte Carlo pricing methods.

Features:
---------
- Characteristic function computation for affine models
- Fast Fourier Transform (FFT) option pricing (Carr-Madan method)
- Monte Carlo simulation with Euler-Maruyama discretization
- Model validation framework
- Support for shot noise variance jumps

Author: VIX Spike VolOfVol Research Team
Version: 1.0.0
Date: March 2026
"""

from .model_config import ModelParameters, InitialConditions
from .characteristic_function import CharacteristicFunctionSolver
from .fft_pricing import FFTPricer
from .monte_carlo import MonteCarloSimulator
from .validator import ModelValidator
from .solvers import odeRK4

__version__ = "1.0.2"
__author__ = "VIX Spike VolOfVol Research Team"

__all__ = [
    "ModelParameters",
    "InitialConditions",
    "CharacteristicFunctionSolver",
    "FFTPricer",
    "MonteCarloSimulator",
    "ModelValidator",
    "odeRK4",
]
