"""
Тесты для Pydantic моделей.
"""

from smart_bot_factory.models import AIMetadata, EventData, parse_ai_metadata_safe


class TestEventData:
    def test_create_valid_event(self):
        """Тест создания валидного события."""
        event = EventData(тип="запись_на_консультацию", инфо="Завтра в 10:00")
        assert event.тип == "запись_на_консультацию"
        assert event.инфо == "Завтра в 10:00"

    def test_normalize_event_type(self):
        """Тест нормализации типа события."""
        event = EventData(тип="  ЗАПИСЬ_НА_КОНСУЛЬТАЦИЮ  ", инфо="Test")
        assert event.тип == "запись_на_консультацию"

    def test_event_with_extra_fields(self):
        """Тест события с дополнительными полями."""
        event = EventData(тип="test", инфо="info", custom_field="custom_value")
        assert event.тип == "test"
        assert (getattr(event, "model_extra", None) or {}).get("custom_field") == "custom_value"


class TestAIMetadata:
    def test_create_empty_metadata(self):
        """Тест создания пустых метаданных."""
        metadata = AIMetadata()
        assert metadata.этап is None
        assert metadata.качество is None
        assert metadata.события == []

    def test_create_metadata_with_stage(self):
        """Тест создания метаданных с этапом."""
        metadata = AIMetadata(этап="introduction")
        assert metadata.этап == "introduction"

    def test_validate_quality_valid(self):
        """Тест валидации качества (валидное значение)."""
        metadata = AIMetadata(качество=7)
        assert metadata.качество == 7

    def test_validate_quality_invalid(self):
        """Тест валидации качества (невалидное значение)."""
        metadata = AIMetadata(качество=15)
        assert metadata.качество is None

    def test_metadata_with_events(self):
        """Тест метаданных с событиями."""
        metadata = AIMetadata(
            события=[
                {"тип": "запись", "инфо": "Test 1"},
                {"тип": "уточнение", "инфо": "Test 2"},
            ]
        )
        assert len(metadata.события) == 2
        assert metadata.события[0].тип == "запись"

    def test_metadata_to_dict(self):
        """Тест конвертации в словарь."""
        metadata = AIMetadata(
            этап="qualification",
            качество=8,
            события=[{"тип": "test", "инфо": "info"}],
        )
        result = metadata.to_dict()

        assert result["этап"] == "qualification"
        assert result["качество"] == 8
        assert len(result["события"]) == 1

    def test_metadata_with_aliases(self):
        """Тест работы с alias'ами (stage вместо этап)."""
        metadata = AIMetadata(stage="introduction", quality=5)
        assert metadata.этап == "introduction"
        assert metadata.качество == 5


class TestParseSafe:
    def test_parse_valid_data(self):
        """Тест парсинга валидных данных."""
        data = {
            "этап": "introduction",
            "качество": 7,
            "события": [{"тип": "test", "инфо": "info"}],
        }
        result = parse_ai_metadata_safe(data)
        assert result["этап"] == "introduction"
        assert result["качество"] == 7

    def test_parse_invalid_data_fallback(self):
        """Тест fallback при невалидных данных."""
        data = {"invalid_key": "invalid_value"}
        result = parse_ai_metadata_safe(data)
        assert result == data

    def test_parse_empty_data(self):
        """Тест парсинга пустых данных."""
        result = parse_ai_metadata_safe({})
        assert isinstance(result, dict)
