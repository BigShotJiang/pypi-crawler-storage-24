"""
Тесты обратной совместимости после рефакторинга.
"""

from smart_bot_factory.handlers.converters import MessageConverter
from smart_bot_factory.models import parse_ai_metadata_safe


class TestBackwardCompatibility:
    def test_message_converter_still_works(self):
        """Старый код конвертации должен работать."""
        msg = {"role": "user", "content": "Test"}
        result = MessageConverter.openai_to_langchain(msg)
        assert result.content == "Test"

    def test_metadata_parsing_with_old_format(self):
        """Старый формат метаданных должен парситься."""
        old_format = {
            "этап": "introduction",
            "качество": 5,
            "события": [
                {"тип": "test", "инфо": "old format"},
            ],
        }
        result = parse_ai_metadata_safe(old_format)
        assert result["этап"] == "introduction"
        assert result["качество"] == 5
        assert len(result["события"]) == 1
        assert result["события"][0]["тип"] == "test"
        assert result["события"][0]["инфо"] == "old format"
