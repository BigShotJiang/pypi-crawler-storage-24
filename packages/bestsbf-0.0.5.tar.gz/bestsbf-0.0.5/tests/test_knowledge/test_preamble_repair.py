"""Тесты ИИ-шапок knowledge/*.txt."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from smart_bot_factory.integrations.openai.responce_models import KnowledgeTxtMetaModel
import smart_bot_factory.integrations.openai.knowledge.preamble_repair as pr
from smart_bot_factory.integrations.openai.knowledge.auto_index import _parse_preamble


def test_extract_body_no_yaml_returns_full_file():
    raw = "only content\n"
    assert pr.extract_body_for_repair(raw) == "only content\n"


def test_extract_body_after_yaml_closing():
    raw = "---\nname: A\ndescription: B\n---\n\nBODY LINE\n"
    assert pr.extract_body_for_repair(raw).strip() == "BODY LINE"


def test_build_knowledge_txt_file():
    d = KnowledgeTxtMetaModel(name="Тема", description="содержимое. Подгружать при вопросах про X.")
    t = pr.build_knowledge_txt_file(d, "LINE\n")
    assert t.startswith("---\n")
    assert "name:" in t
    assert "Тема" in t
    assert "description:" in t
    assert t.endswith("LINE\n")


def test_build_knowledge_txt_file_short_description():
    d = KnowledgeTxtMetaModel(name="Т", description="W")
    t = pr.build_knowledge_txt_file(d, "B")
    assert "---" in t
    assert "name:" in t
    assert "description:" in t


@pytest.mark.asyncio
async def test_repair_txt_if_needed_writes_valid_preamble(tmp_path, monkeypatch):
    path = tmp_path / "broken.txt"
    path.write_text("Содержимое без шапки.\nВторой абзац.\n", encoding="utf-8")

    draft = KnowledgeTxtMetaModel(
        name="Тест",
        description="текст файла. Подгружать при общих вопросах",
    )

    fake_chain = MagicMock()
    fake_chain.ainvoke = AsyncMock(return_value=draft)

    class FakePrompt:
        def __or__(self, other):
            return fake_chain

    monkeypatch.setattr(pr, "_PROMPT", FakePrompt())

    changed = await pr.repair_txt_if_needed(path, "sk-test", "gpt-5-mini")
    assert changed is True

    new_raw = path.read_text(encoding="utf-8")
    assert _parse_preamble(new_raw, "broken.txt") is not None
    assert "Содержимое без шапки" in new_raw
