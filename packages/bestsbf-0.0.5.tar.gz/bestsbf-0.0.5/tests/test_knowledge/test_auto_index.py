"""Тесты автоиндекса knowledge/*.txt."""

from pathlib import Path

from smart_bot_factory.integrations.openai.knowledge.auto_index import (
    build_router_index_from_txt_dir,
    knowledge_file_body,
    resolve_knowledge_index,
    _parse_preamble,
)


def test_build_index_from_my_bot_knowledge():
    kd = Path("bots/my-bot/knowledge")
    if not kd.is_dir():
        return
    md, entries = build_router_index_from_txt_dir(kd)
    assert len(entries) >= 1
    assert all("path" in e and e["path"].startswith("knowledge/") for e in entries)
    assert "## 1" in md
    assert "**Файл:**" in md
    assert "**Описание:**" in md


def test_yaml_frontmatter_preamble(tmp_path: Path):
    kdir = tmp_path / "knowledge"
    kdir.mkdir()
    text = (
        "---\n"
        "name: Заголовок\n"
        "description: Кратко о содержимом. Подгружать при вопросах про тест.\n"
        "---\n\n"
        "ТЕЛО\n"
    )
    (kdir / "doc.txt").write_text(text, encoding="utf-8")
    meta = _parse_preamble(text, "doc.txt")
    assert meta is not None
    assert meta.name == "Заголовок"
    assert "Кратко о содержимом" in meta.description
    assert "вопросах про тест" in meta.description
    assert knowledge_file_body(text).strip() == "ТЕЛО"
    md, entries = resolve_knowledge_index(tmp_path)
    assert len(entries) == 1
    assert "Заголовок" in md


def test_resolve_only_valid_yaml_txt(tmp_path: Path):
    kdir = tmp_path / "knowledge"
    kdir.mkdir()
    (kdir / "a.txt").write_text(
        "---\n"
        "name: Тема A\n"
        "description: кратко. Подгружать при запросе A.\n"
        "---\n\nbody\n",
        encoding="utf-8",
    )
    md, entries = resolve_knowledge_index(tmp_path)
    assert len(entries) == 1
    assert entries[0]["path"] == "knowledge/a.txt"
    assert "Тема A" in md
    assert "кратко" in md


def test_frontmatter_extra_keys_rejected(tmp_path: Path):
    text = (
        "---\n"
        "name: X\n"
        "description: Y\n"
        "file: other.txt\n"
        "---\n\nz\n"
    )
    assert _parse_preamble(text, "x.txt") is None
