"""Graph wiring: qdrant_rag branch and last-user extraction."""

from unittest.mock import AsyncMock, Mock

import pytest
from langchain.messages import AIMessage, HumanMessage, SystemMessage

from smart_bot_factory.integrations.openai.responce_models import MainResponseModel


@pytest.mark.asyncio
async def test_qdrant_rag_branch_runs_without_retriever():
    from smart_bot_factory.integrations import conversation_graph as cg
    from smart_bot_factory.utils.context import ctx

    saved_r = ctx.qdrant_rag_retriever
    saved_o = ctx.openai_client
    saved_p = ctx.rag_query_planner
    saved_bd = ctx.bot_config_dir
    ctx.qdrant_rag_retriever = None
    ctx.rag_query_planner = None
    ctx.bot_config_dir = None
    client = Mock()
    client.get_completion = AsyncMock(
        return_value=MainResponseModel(user_message="ok", service_info={}),
    )
    ctx.openai_client = client
    try:
        app = cg.create_dialog_pipeline_graph(
            include_knowledge_branch=False,
            include_qdrant_rag_branch=True,
        )
        state = cg.DialogPipelineState(
            messages=[
                SystemMessage(content="sys"),
                HumanMessage(content="hello"),
            ]
        )
        out = await app.ainvoke(state)
        final = cg.dialog_pipeline_state_from_ainvoke(out)
        assert final.user_message == "ok"
        assert final.rag_answer is None
    finally:
        ctx.qdrant_rag_retriever = saved_r
        ctx.openai_client = saved_o
        ctx.rag_query_planner = saved_p
        ctx.bot_config_dir = saved_bd


def test_last_user_text_from_langchain_messages():
    from smart_bot_factory.integrations import conversation_graph as cg

    msgs = [
        SystemMessage(content="s"),
        HumanMessage(content="first"),
        AIMessage(content="mid"),
        HumanMessage(content="last"),
    ]
    assert cg.last_user_text_from_langchain_messages(msgs) == "last"
