"""Флаги DIALOG_* и сборка веток LangGraph."""

from pathlib import Path
from unittest.mock import AsyncMock, Mock

import pytest

from smart_bot_factory.creation.bot_builder import BotBuilder
from smart_bot_factory.integrations import conversation_graph as cg


def _builder_stub(config_dir: Path, *, want_k: bool, want_r: bool, has_retriever: bool) -> BotBuilder:
    b = BotBuilder.__new__(BotBuilder)
    b.config_dir = config_dir
    b.config = Mock()
    b.config.DIALOG_KNOWLEDGE_ROUTER_ENABLED = want_k
    b.config.DIALOG_QDRANT_RAG_ENABLED = want_r
    b.qdrant_rag_retriever = object() if has_retriever else None
    return b


def test_branch_flags_both_off_despite_infra(tmp_path: Path) -> None:
    (tmp_path / "knowledge").mkdir()
    b = _builder_stub(tmp_path, want_k=False, want_r=False, has_retriever=True)
    k, r = b._dialog_graph_branch_flags()
    assert (k, r) == (False, False)


def test_branch_flags_knowledge_on_rag_off(tmp_path: Path) -> None:
    (tmp_path / "knowledge").mkdir()
    b = _builder_stub(tmp_path, want_k=True, want_r=False, has_retriever=True)
    k, r = b._dialog_graph_branch_flags()
    assert (k, r) == (True, False)


def test_branch_flags_rag_only(tmp_path: Path) -> None:
    b = _builder_stub(tmp_path, want_k=False, want_r=True, has_retriever=True)
    k, r = b._dialog_graph_branch_flags()
    assert (k, r) == (False, True)


def test_branch_flags_no_knowledge_dir(tmp_path: Path) -> None:
    b = _builder_stub(tmp_path, want_k=True, want_r=False, has_retriever=False)
    k, r = b._dialog_graph_branch_flags()
    assert (k, r) == (False, False)


def _edge_pairs(app: object) -> set[tuple[str, str]]:
    graph = app.get_graph()
    return {(e.source, e.target) for e in graph.edges}


def test_graph_edges_both_branches_off() -> None:
    app = cg.create_dialog_pipeline_graph(
        include_knowledge_branch=False,
        include_qdrant_rag_branch=False,
    )
    edges = _edge_pairs(app)
    assert ("__start__", "model") in edges
    assert ("model", "__end__") in edges
    assert len(edges) == 2


def test_graph_edges_rag_only_chain() -> None:
    app = cg.create_dialog_pipeline_graph(
        include_knowledge_branch=False,
        include_qdrant_rag_branch=True,
    )
    edges = _edge_pairs(app)
    assert ("__start__", "rag_query_planner") in edges
    assert ("rag_query_planner", "qdrant_rag") in edges
    assert ("qdrant_rag", "model") in edges
    assert ("model", "__end__") in edges
    assert ("__start__", "knowledge_router") not in {s for s, _ in edges}


def test_graph_edges_knowledge_then_model() -> None:
    app = cg.create_dialog_pipeline_graph(
        include_knowledge_branch=True,
        include_qdrant_rag_branch=False,
    )
    edges = _edge_pairs(app)
    assert ("__start__", "knowledge_router") in edges
    assert ("knowledge_router", "model") in edges
    assert ("model", "__end__") in edges
    assert ("rag_query_planner", "qdrant_rag") not in edges


def test_graph_edges_full_pipeline() -> None:
    app = cg.create_dialog_pipeline_graph(
        include_knowledge_branch=True,
        include_qdrant_rag_branch=True,
    )
    edges = _edge_pairs(app)
    assert ("__start__", "knowledge_router") in edges
    assert ("knowledge_router", "rag_query_planner") in edges
    assert ("rag_query_planner", "qdrant_rag") in edges
    assert ("qdrant_rag", "model") in edges


@pytest.mark.asyncio
async def test_graph_direct_model_when_both_branches_false() -> None:
    from smart_bot_factory.integrations.openai.responce_models import MainResponseModel
    from smart_bot_factory.utils.context import ctx

    app = cg.create_dialog_pipeline_graph(
        include_knowledge_branch=False,
        include_qdrant_rag_branch=False,
    )
    saved_o = ctx.openai_client
    client = Mock()
    client.get_completion = AsyncMock(
        return_value=MainResponseModel(user_message="hi", service_info={}),
    )
    ctx.openai_client = client
    try:
        from langchain.messages import HumanMessage, SystemMessage

        state = cg.DialogPipelineState(
            messages=[SystemMessage(content="s"), HumanMessage(content="u")],
        )
        out = await app.ainvoke(state)
        final = cg.dialog_pipeline_state_from_ainvoke(out)
        assert final.user_message == "hi"
    finally:
        ctx.openai_client = saved_o
