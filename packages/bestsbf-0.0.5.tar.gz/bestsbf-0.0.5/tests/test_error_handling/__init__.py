"""Тесты для error handling"""
