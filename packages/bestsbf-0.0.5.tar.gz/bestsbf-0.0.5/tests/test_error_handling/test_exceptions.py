"""
Тесты для кастомных исключений
"""

import pytest

from smart_bot_factory.error_handling import (
    BotBlockedError,
    OpenAIRateLimitError,
    SmartBotFactoryError,
    ValidationError,
)


class TestSmartBotFactoryError:
    def test_basic_error(self):
        """Тест базовой ошибки"""
        error = SmartBotFactoryError("Test error", error_code="TEST_001")
        assert error.message == "Test error"
        assert error.error_code == "TEST_001"
        assert str(error) == "Test error [TEST_001]"

    def test_error_with_context(self):
        """Тест ошибки с контекстом"""
        error = SmartBotFactoryError("Test error", error_code="TEST_002", user_id=123, session_id="abc")
        assert error.context["user_id"] == 123
        assert error.context["session_id"] == "abc"
        assert "user_id=123" in str(error)
        assert "session_id=abc" in str(error)


class TestBotBlockedError:
    def test_bot_blocked_error(self):
        """Тест ошибки блокировки бота"""
        error = BotBlockedError(user_id=12345)
        assert error.context["user_id"] == 12345
        assert error.error_code == "BOT_BLOCKED"
        assert "12345" in str(error)


class TestOtherErrors:
    def test_rate_limit_error(self):
        """Тест rate limit ошибки"""
        error = OpenAIRateLimitError("Too many requests")
        assert isinstance(error, SmartBotFactoryError)
        assert error.message == "Too many requests"

    def test_validation_error(self):
        """Тест ошибки валидации"""
        error = ValidationError("Invalid data", field="email")
        assert error.context["field"] == "email"
