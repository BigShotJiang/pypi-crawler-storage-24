"""
Тесты для retry механизма
"""

import pytest

from smart_bot_factory.error_handling import RetryStrategy, with_retry


class TestRetryStrategy:
    def test_calculate_delay_first_attempt(self):
        """Тест вычисления задержки для первой попытки"""
        strategy = RetryStrategy(delay=1.0, backoff_factor=2.0)
        delay = strategy.calculate_delay(1)
        assert delay == 1.0

    def test_calculate_delay_exponential(self):
        """Тест exponential backoff"""
        strategy = RetryStrategy(delay=1.0, backoff_factor=2.0)

        assert strategy.calculate_delay(1) == 1.0
        assert strategy.calculate_delay(2) == 2.0
        assert strategy.calculate_delay(3) == 4.0

    def test_calculate_delay_max_limit(self):
        """Тест ограничения максимальной задержки"""
        strategy = RetryStrategy(delay=1.0, backoff_factor=2.0, max_delay=5.0)

        # 10-я попытка даст 512 секунд, но ограничится 5.0
        delay = strategy.calculate_delay(10)
        assert delay == 5.0


class TestWithRetry:
    @pytest.mark.asyncio
    async def test_success_on_first_attempt(self):
        """Тест успешного выполнения с первой попытки"""
        call_count = {"count": 0}

        @with_retry(RetryStrategy(max_attempts=3))
        async def test_func():
            call_count["count"] += 1
            return "success"

        result = await test_func()

        assert result == "success"
        assert call_count["count"] == 1

    @pytest.mark.asyncio
    async def test_success_on_second_attempt(self):
        """Тест успешного выполнения со второй попытки"""
        call_count = {"count": 0}

        @with_retry(RetryStrategy(max_attempts=3, delay=0.1))
        async def test_func():
            call_count["count"] += 1
            if call_count["count"] < 2:
                raise ValueError("Temporary error")
            return "success"

        result = await test_func()

        assert result == "success"
        assert call_count["count"] == 2

    @pytest.mark.asyncio
    async def test_all_attempts_failed(self):
        """Тест когда все попытки исчерпаны"""
        call_count = {"count": 0}

        @with_retry(RetryStrategy(max_attempts=3, delay=0.1))
        async def test_func():
            call_count["count"] += 1
            raise ValueError("Permanent error")

        with pytest.raises(ValueError, match="Permanent error"):
            await test_func()

        assert call_count["count"] == 3

    @pytest.mark.asyncio
    async def test_specific_exception_retry(self):
        """Тест retry только для определенных исключений"""
        call_count = {"count": 0}

        @with_retry(RetryStrategy(max_attempts=3, delay=0.1, exceptions=(ValueError,)))
        async def test_func():
            call_count["count"] += 1
            if call_count["count"] == 1:
                raise ValueError("Retryable")
            elif call_count["count"] == 2:
                raise TypeError("Not retryable")

        # TypeError не должен retry'иться, поэтому упадет сразу
        with pytest.raises(TypeError):
            await test_func()

        assert call_count["count"] == 2

    def test_sync_function_retry(self):
        """Тест retry для синхронных функций"""
        call_count = {"count": 0}

        @with_retry(RetryStrategy(max_attempts=3, delay=0.1))
        def test_func():
            call_count["count"] += 1
            if call_count["count"] < 2:
                raise ValueError("Temporary")
            return "success"

        result = test_func()

        assert result == "success"
        assert call_count["count"] == 2
