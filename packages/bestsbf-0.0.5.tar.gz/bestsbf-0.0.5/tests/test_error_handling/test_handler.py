"""
Тесты для ErrorHandler
"""

import pytest

from smart_bot_factory.error_handling import (
    BotBlockedError,
    ErrorHandler,
    OpenAIRateLimitError,
    get_error_handler,
)


@pytest.fixture
def handler():
    """Фикстура ErrorHandler"""
    return ErrorHandler()


class TestErrorHandler:
    def test_classify_bot_blocked(self, handler):
        """Тест классификации bot_blocked"""
        error = BotBlockedError(user_id=123)
        error_type = handler._classify_error(error)
        assert error_type == "bot_blocked"

    def test_classify_rate_limit(self, handler):
        """Тест классификации rate_limit"""
        error = OpenAIRateLimitError("Rate limit exceeded")
        error_type = handler._classify_error(error)
        assert error_type == "rate_limit"

    def test_classify_unknown(self, handler):
        """Тест классификации unknown"""
        error = ValueError("Some error")
        error_type = handler._classify_error(error)
        assert error_type == "unknown"

    def test_metrics_update(self, handler):
        """Тест обновления метрик"""
        handler._update_metrics("bot_blocked")
        handler._update_metrics("bot_blocked")
        handler._update_metrics("rate_limit")

        metrics = handler.get_metrics()
        assert metrics["bot_blocked"] == 2
        assert metrics["rate_limit"] == 1
        assert metrics["total"] == 3

    def test_error_history(self, handler):
        """Тест истории ошибок"""
        error = BotBlockedError(user_id=123)
        handler._add_to_history(error, "bot_blocked", {"user_id": 123})

        history = handler.get_error_history()
        assert len(history) == 1
        assert history[0]["error_type"] == "bot_blocked"

    @pytest.mark.asyncio
    async def test_handle_with_suppress(self, handler):
        """Тест обработки с подавлением ошибки"""
        error = ValueError("Test error")

        # Не должно выбросить исключение
        result = await handler.handle(error, suppress=True)
        assert result is not None


class TestGlobalHandler:
    def test_get_global_handler(self):
        """Тест получения глобального handler"""
        handler1 = get_error_handler()
        handler2 = get_error_handler()

        # Должен быть singleton
        assert handler1 is handler2
