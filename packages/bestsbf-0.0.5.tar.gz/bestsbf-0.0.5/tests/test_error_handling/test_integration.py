"""
Интеграционные тесты error handling с остальной системой
"""

import pytest

from smart_bot_factory.error_handling import BotBlockedError, get_error_handler


@pytest.mark.asyncio
async def test_error_handler_metrics():
    """Тест сбора метрик ошибок"""
    handler = get_error_handler()
    handler.clear_metrics()

    await handler.handle(BotBlockedError(user_id=123), suppress=True)
    await handler.handle(BotBlockedError(user_id=456), suppress=True)
    await handler.handle(ValueError("Test"), suppress=True)

    metrics = handler.get_metrics()
    assert metrics["bot_blocked"] == 2
    assert metrics["unknown"] == 1
    assert metrics["total"] == 3
