"""Планировщик запроса Qdrant RAG и вспомогательные функции."""

from __future__ import annotations

from unittest.mock import AsyncMock, Mock

import pytest
from langchain.messages import HumanMessage, SystemMessage

from smart_bot_factory.integrations.openai.responce_models import RagQueryPlannerDecision


def test_normalize_rag_planner_decision_empty_query() -> None:
    from smart_bot_factory.rag.qdrant.query_planner import normalize_rag_planner_decision

    raw = RagQueryPlannerDecision(needs_rag=True, retrieval_query="   ", planner_note="x")
    d = normalize_rag_planner_decision(raw)
    assert d.needs_rag is False
    assert d.retrieval_query == ""


def test_build_selected_knowledge_topics_block() -> None:
    from smart_bot_factory.rag.qdrant.query_planner import build_selected_knowledge_topics_block

    md = "## 1 — Тема А\n\nfoo\n## 2 — Тема B\n"
    block = build_selected_knowledge_topics_block([1], md)
    assert "1:" in block
    assert "Тема А" in block
    empty = build_selected_knowledge_topics_block([], md)
    assert "не выбраны" in empty


@pytest.mark.asyncio
async def test_graph_skips_retrieve_when_planner_says_no_rag(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    from smart_bot_factory.integrations import conversation_graph as cg
    from smart_bot_factory.integrations.openai.responce_models import MainResponseModel
    from smart_bot_factory.utils.context import ctx

    class FakePlanner:
        async def plan(self, **_kwargs: object) -> RagQueryPlannerDecision:
            return RagQueryPlannerDecision(needs_rag=False, retrieval_query="", planner_note="")

    class FakeRetriever:
        def __init__(self) -> None:
            self.called = False

        async def aretrieve(self, _q: str) -> list[str]:
            self.called = True
            return ["should-not"]

    saved = (
        ctx.qdrant_rag_retriever,
        ctx.rag_query_planner,
        ctx.bot_config_dir,
        ctx.config,
        ctx.prompt_loader,
        ctx.openai_client,
    )
    monkeypatch.delenv("RAG_QUERY_PLANNER_DISABLED", raising=False)
    retriever = FakeRetriever()
    ctx.qdrant_rag_retriever = retriever
    ctx.rag_query_planner = FakePlanner()
    ctx.bot_config_dir = tmp_path
    ctx.config = Mock(BOT_ID="test-bot")
    ctx.prompt_loader = None
    client = Mock()
    client.get_completion = AsyncMock(return_value=MainResponseModel(user_message="ok", service_info={}))
    ctx.openai_client = client
    try:
        app = cg.create_dialog_pipeline_graph(
            include_knowledge_branch=False,
            include_qdrant_rag_branch=True,
        )
        state = cg.DialogPipelineState(
            messages=[
                SystemMessage(content="sys"),
                HumanMessage(content="привет"),
            ],
        )
        out = await app.ainvoke(state)
        final = cg.dialog_pipeline_state_from_ainvoke(out)
        assert final.user_message == "ok"
        assert retriever.called is False
        assert final.rag_answer is None
    finally:
        (
            ctx.qdrant_rag_retriever,
            ctx.rag_query_planner,
            ctx.bot_config_dir,
            ctx.config,
            ctx.prompt_loader,
            ctx.openai_client,
        ) = saved


@pytest.mark.asyncio
async def test_graph_runs_retrieve_with_planner_query(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    from smart_bot_factory.integrations import conversation_graph as cg
    from smart_bot_factory.integrations.openai.responce_models import MainResponseModel
    from smart_bot_factory.utils.context import ctx

    class FakePlanner:
        async def plan(self, **_kwargs: object) -> RagQueryPlannerDecision:
            return RagQueryPlannerDecision(
                needs_rag=True,
                retrieval_query="цены на услуги",
                planner_note="нужны тарифы",
            )

    class FakeRetriever:
        def __init__(self) -> None:
            self.last_query: str = ""

        async def aretrieve(self, q: str) -> list[str]:
            self.last_query = q
            return ["chunk-one"]

    saved = (
        ctx.qdrant_rag_retriever,
        ctx.rag_query_planner,
        ctx.bot_config_dir,
        ctx.config,
        ctx.prompt_loader,
        ctx.openai_client,
    )
    monkeypatch.delenv("RAG_QUERY_PLANNER_DISABLED", raising=False)
    retriever = FakeRetriever()
    ctx.qdrant_rag_retriever = retriever
    ctx.rag_query_planner = FakePlanner()
    ctx.bot_config_dir = tmp_path
    ctx.config = Mock(BOT_ID="test-bot")
    ctx.prompt_loader = None
    client = Mock()
    client.get_completion = AsyncMock(return_value=MainResponseModel(user_message="done", service_info={}))
    ctx.openai_client = client
    try:
        app = cg.create_dialog_pipeline_graph(
            include_knowledge_branch=False,
            include_qdrant_rag_branch=True,
        )
        state = cg.DialogPipelineState(
            messages=[
                SystemMessage(content="sys"),
                HumanMessage(content="сколько стоит?"),
            ],
        )
        out = await app.ainvoke(state)
        final = cg.dialog_pipeline_state_from_ainvoke(out)
        assert retriever.last_query == "цены на услуги"
        assert final.rag_answer is not None
        assert "chunk-one" in final.rag_answer
        assert final.user_message == "done"
        call_args = client.get_completion.call_args[0][0]
        joined = "\n".join(
            getattr(m, "content", "") if hasattr(m, "content") else str(m) for m in call_args
        )
        assert "chunk-one" in joined
        assert "Поисковый запрос к базе" in joined
    finally:
        (
            ctx.qdrant_rag_retriever,
            ctx.rag_query_planner,
            ctx.bot_config_dir,
            ctx.config,
            ctx.prompt_loader,
            ctx.openai_client,
        ) = saved


@pytest.mark.asyncio
async def test_graph_legacy_disabled_uses_last_user_message(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    """RAG_QUERY_PLANNER_DISABLED: без LLM, запрос в retrieval = последняя реплика."""
    from smart_bot_factory.integrations import conversation_graph as cg
    from smart_bot_factory.integrations.openai.responce_models import MainResponseModel
    from smart_bot_factory.utils.context import ctx

    class FakeRetriever:
        def __init__(self) -> None:
            self.last_query: str = ""

        async def aretrieve(self, q: str) -> list[str]:
            self.last_query = q
            return ["ok"]

    saved = (
        ctx.qdrant_rag_retriever,
        ctx.rag_query_planner,
        ctx.bot_config_dir,
        ctx.config,
        ctx.prompt_loader,
        ctx.openai_client,
    )
    monkeypatch.setenv("RAG_QUERY_PLANNER_DISABLED", "true")
    retriever = FakeRetriever()
    ctx.qdrant_rag_retriever = retriever
    ctx.rag_query_planner = None
    ctx.bot_config_dir = tmp_path
    ctx.config = Mock(BOT_ID="test-bot")
    ctx.prompt_loader = None
    client = Mock()
    client.get_completion = AsyncMock(return_value=MainResponseModel(user_message="x", service_info={}))
    ctx.openai_client = client
    try:
        app = cg.create_dialog_pipeline_graph(
            include_knowledge_branch=False,
            include_qdrant_rag_branch=True,
        )
        state = cg.DialogPipelineState(
            messages=[
                SystemMessage(content="sys"),
                HumanMessage(content="мой вопрос про цены"),
            ],
        )
        await app.ainvoke(state)
        assert retriever.last_query == "мой вопрос про цены"
    finally:
        monkeypatch.delenv("RAG_QUERY_PLANNER_DISABLED", raising=False)
        (
            ctx.qdrant_rag_retriever,
            ctx.rag_query_planner,
            ctx.bot_config_dir,
            ctx.config,
            ctx.prompt_loader,
            ctx.openai_client,
        ) = saved
