"""Qdrant RAG: settings resolution, indexer wiring (mocked Qdrant/Voyage)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


@dataclass(frozen=True)
class _DuckConfig:
    BOT_ID: str
    OPENAI_API_KEY: str
    OPENAI_BASE_URL: str
    OPENAI_ROUTER_MODEL: str


def _duck() -> _DuckConfig:
    return _DuckConfig(
        BOT_ID="testbot",
        OPENAI_API_KEY="sk-test",
        OPENAI_BASE_URL="",
        OPENAI_ROUTER_MODEL="gpt-5-mini",
    )


def test_resolve_qdrant_rag_config_no_data_dir(tmp_path: Path) -> None:
    from smart_bot_factory.rag.qdrant.settings import resolve_qdrant_rag_config

    assert resolve_qdrant_rag_config(tmp_path, _duck()) is None


def test_resolve_qdrant_rag_config_no_txt_files(tmp_path: Path) -> None:
    from smart_bot_factory.rag.qdrant.settings import resolve_qdrant_rag_config

    rag = tmp_path / "rag_data"
    rag.mkdir()
    assert resolve_qdrant_rag_config(tmp_path, _duck()) is None


def test_resolve_qdrant_rag_config_parser_only(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from smart_bot_factory.rag.qdrant.settings import resolve_qdrant_rag_config

    monkeypatch.setenv("QDRANT_RAG_DATA_SOURCE", "parser")
    p = tmp_path / "parser"
    p.mkdir()
    sub = p / "sub"
    sub.mkdir()
    (sub / "page.txt").write_text("hello from parser", encoding="utf-8")

    resolved = resolve_qdrant_rag_config(tmp_path, _duck())
    assert resolved is not None
    assert resolved.data_dirs == (p.resolve(),)
    assert resolved.data_dir == p.resolve()
    assert resolved.ingest_sources_include_parser is True


def test_resolve_qdrant_rag_config_parser_then_prefers_parser(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from smart_bot_factory.rag.qdrant.settings import (
        QDRANT_RAG_DATA_SOURCE_DEFAULT,
        resolve_qdrant_rag_config,
    )

    monkeypatch.delenv("QDRANT_RAG_DATA_SOURCE", raising=False)
    assert QDRANT_RAG_DATA_SOURCE_DEFAULT == "parser_then_rag_data"
    rag = tmp_path / "rag_data"
    rag.mkdir()
    (rag / "a.txt").write_text("r", encoding="utf-8")
    par = tmp_path / "parser"
    par.mkdir()
    (par / "b.txt").write_text("p", encoding="utf-8")

    resolved = resolve_qdrant_rag_config(tmp_path, _duck())
    assert resolved is not None
    assert resolved.data_dirs == (par.resolve(),)
    assert resolved.ingest_sources_include_parser is True


def test_resolve_qdrant_rag_config_both_dirs(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from smart_bot_factory.rag.qdrant.settings import resolve_qdrant_rag_config

    monkeypatch.setenv("QDRANT_RAG_DATA_SOURCE", "both")
    rag = tmp_path / "rag_data"
    rag.mkdir()
    (rag / "a.txt").write_text("r", encoding="utf-8")
    par = tmp_path / "parser"
    par.mkdir()
    (par / "b.txt").write_text("p", encoding="utf-8")

    resolved = resolve_qdrant_rag_config(tmp_path, _duck())
    assert resolved is not None
    assert len(resolved.data_dirs) == 2
    assert par.resolve() in resolved.data_dirs
    assert rag.resolve() in resolved.data_dirs
    assert resolved.ingest_sources_include_parser is True


def test_resolve_qdrant_rag_config_invalid_source(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from smart_bot_factory.rag.qdrant.settings import resolve_qdrant_rag_config

    monkeypatch.setenv("QDRANT_RAG_DATA_SOURCE", "nope")
    (tmp_path / "rag_data").mkdir()
    (tmp_path / "rag_data" / "x.txt").write_text("x", encoding="utf-8")
    with pytest.raises(ValueError, match="QDRANT_RAG_DATA_SOURCE"):
        resolve_qdrant_rag_config(tmp_path, _duck())


def test_resolve_qdrant_rag_config_no_voyage_key(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from smart_bot_factory.rag.qdrant.settings import resolve_qdrant_rag_config

    monkeypatch.delenv("VOYAGE_API_KEY", raising=False)
    rag = tmp_path / "rag_data"
    rag.mkdir()
    (rag / "a.txt").write_text("hello", encoding="utf-8")
    resolved = resolve_qdrant_rag_config(tmp_path, _duck())
    assert resolved is not None
    assert resolved.voyage_api_key == ""


def test_resolve_qdrant_rag_config_success(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from smart_bot_factory.rag.qdrant.settings import resolve_qdrant_rag_config

    monkeypatch.setenv("VOYAGE_API_KEY", "voyage-secret")
    monkeypatch.setenv("QDRANT_COLLECTION", "rag_x")
    rag = tmp_path / "rag_data"
    rag.mkdir()
    (rag / "a.txt").write_text("hello", encoding="utf-8")

    resolved = resolve_qdrant_rag_config(tmp_path, _duck())
    assert resolved is not None
    assert resolved.data_dir == rag.resolve()
    assert resolved.data_dirs == (rag.resolve(),)
    assert resolved.ingest_sources_include_parser is False
    assert resolved.qdrant_collection == "rag_x_testbot"
    assert resolved.voyage_api_key == "voyage-secret"
    assert resolved.qdrant_bm25_model == "Qdrant/bm25"
    assert resolved.qdrant_server_inference is True
    assert resolved.hybrid_top_k == 40
    assert resolved.openai_embed_model == "text-embedding-3-small"


def _runtime_cfg(bot_root: Path) -> "QdrantRagRuntimeConfig":
    from smart_bot_factory.rag.qdrant.settings import QdrantRagRuntimeConfig

    rag = bot_root / "rag_data"
    storage = bot_root / "rag_storage"
    storage.mkdir(parents=True, exist_ok=True)
    return QdrantRagRuntimeConfig(
        bot_config_dir=bot_root,
        bot_id="testbot",
        data_dir=rag.resolve(),
        data_dirs=(rag.resolve(),),
        ingest_sources_include_parser=False,
        docstore_path=storage / "docstore.json",
        qdrant_url="http://localhost:6333",
        qdrant_collection="rag_testbot",
        qdrant_server_inference=True,
        qdrant_dense_vector_name="dense",
        qdrant_sparse_vector_name="sparse",
        qdrant_bm25_model="Qdrant/bm25",
        voyage_api_key="vk",
        openai_embed_model="text-embedding-3-small",
        voyage_rerank_model="rerank-2.5",
        openai_api_key="sk",
        openai_base_url=None,
        hyde_model="gpt-5-mini",
        hyde_include_original=True,
        hyde_max_tokens=256,
        parent_chunk_size=1024,
        child_chunk_size=256,
        chunk_overlap=40,
        vector_top_k=20,
        bm25_top_k=20,
        hybrid_top_k=40,
        qdrant_upsert_batch_size=32,
        rerank_top_n=5,
        automerge_thresh=0.5,
    )


def test_ensure_qdrant_rag_index_calls_load_when_docstore_exists(tmp_path: Path) -> None:
    pytest.importorskip("llama_index.core")
    from smart_bot_factory.rag.qdrant.indexer import ensure_qdrant_rag_index

    bot_root = tmp_path / "bot"
    rag = bot_root / "rag_data"
    rag.mkdir(parents=True)
    (rag / "f.txt").write_text("x", encoding="utf-8")
    cfg = _runtime_cfg(bot_root)
    cfg.docstore_path.write_text("{}", encoding="utf-8")

    with patch("smart_bot_factory.rag.qdrant.indexer.load_qdrant_rag_index_verified") as mock_load:
        ensure_qdrant_rag_index(cfg)
    mock_load.assert_called_once_with(cfg)


def test_ensure_qdrant_rag_index_force_rebuild_calls_rebuild(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    pytest.importorskip("llama_index.core")
    from smart_bot_factory.rag.qdrant.indexer import ensure_qdrant_rag_index

    monkeypatch.setenv("QDRANT_FORCE_REBUILD_ON_START", "true")
    bot_root = tmp_path / "bot"
    rag = bot_root / "rag_data"
    rag.mkdir(parents=True)
    (rag / "f.txt").write_text("x", encoding="utf-8")
    cfg = _runtime_cfg(bot_root)
    cfg.docstore_path.write_text("{}", encoding="utf-8")

    with patch("smart_bot_factory.rag.qdrant.indexer.rebuild_qdrant_rag_index") as mock_rebuild:
        ensure_qdrant_rag_index(cfg)
    mock_rebuild.assert_called_once_with(cfg)


def test_ensure_qdrant_rag_index_calls_build_when_no_docstore(tmp_path: Path) -> None:
    pytest.importorskip("llama_index.core")
    from smart_bot_factory.rag.qdrant.indexer import ensure_qdrant_rag_index

    bot_root = tmp_path / "bot"
    rag = bot_root / "rag_data"
    rag.mkdir(parents=True)
    (rag / "f.txt").write_text("content for parser", encoding="utf-8")
    cfg = _runtime_cfg(bot_root)
    if cfg.docstore_path.is_file():
        cfg.docstore_path.unlink()

    with patch("smart_bot_factory.rag.qdrant.indexer.build_qdrant_rag_index") as mock_build:
        ensure_qdrant_rag_index(cfg)
    mock_build.assert_called_once_with(cfg)


def _fake_embed_nodes(
    nodes: object,
    embed_model: object,
    show_progress: bool = False,
) -> dict[str, list[float]]:
    from llama_index.core.schema import BaseNode

    out: dict[str, list[float]] = {}
    for n in nodes:
        if isinstance(n, BaseNode):
            out[n.node_id] = [0.1, 0.2, 0.3, 0.4]
    return out


@patch("smart_bot_factory.rag.qdrant.indexer.VectorStoreIndex.insert_nodes")
@patch("llama_index.core.indices.vector_store.base.embed_nodes", side_effect=_fake_embed_nodes)
@patch(
    "llama_index.core.indices.vector_store.base.resolve_embed_model",
    lambda em, callback_manager=None: em,
)
@patch("smart_bot_factory.rag.qdrant.indexer.ensure_hybrid_collection")
@patch("smart_bot_factory.rag.qdrant.indexer.dense_embedding_dimension", return_value=4)
@patch("smart_bot_factory.rag.qdrant.indexer.qdrant_rag_http_client")
@patch("smart_bot_factory.rag.qdrant.indexer.qdrant_rag_openai_embedding")
def test_build_qdrant_rag_index_wires_vector_index(
    mock_openai_embed_fn: MagicMock,
    mock_client_fn: MagicMock,
    mock_dim: MagicMock,
    mock_ensure: MagicMock,
    mock_embed_nodes_inner: MagicMock,
    mock_insert_nodes: MagicMock,
    tmp_path: Path,
) -> None:
    pytest.importorskip("llama_index.core")
    from smart_bot_factory.rag.qdrant.indexer import build_qdrant_rag_index

    bot_root = tmp_path / "bot"
    rag = bot_root / "rag_data"
    rag.mkdir(parents=True)
    (rag / "doc.txt").write_text("paragraph one.\n\nparagraph two.", encoding="utf-8")
    cfg = _runtime_cfg(bot_root)

    mock_embed = MagicMock()
    mock_embed.get_text_embedding.return_value = [0.1, 0.2, 0.3, 0.4]
    mock_openai_embed_fn.return_value = mock_embed
    mock_client_fn.return_value = MagicMock()

    build_qdrant_rag_index(cfg)

    mock_ensure.assert_called_once()
    mock_insert_nodes.assert_called_once()
    assert cfg.docstore_path.is_file()


@pytest.mark.asyncio
async def test_debug_query_raises_when_retriever_unavailable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("BOT_ID", "testbot")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-x")

    async def _none(*args: object, **kwargs: object) -> tuple[None, None]:
        return None, None

    monkeypatch.setattr(
        "smart_bot_factory.rag.qdrant.debug_query.create_qdrant_rag_retriever",
        _none,
    )
    from smart_bot_factory.rag.qdrant.debug_query import query

    with pytest.raises(RuntimeError, match="Qdrant RAG is not active"):
        await query(tmp_path, "hello")
