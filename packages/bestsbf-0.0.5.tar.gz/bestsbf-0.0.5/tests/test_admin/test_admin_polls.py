"""Тесты парсинга и валидации опросов (admin_polls)."""

from smart_bot_factory.admin import admin_polls as ap


def test_parse_poll_options_trims_and_skips_empty():
    text = "  A \n\nB\n  C  "
    assert ap._parse_poll_options(text) == ["A", "B", "C"]


def test_parse_poll_options_caps_at_max():
    lines = "\n".join(f"opt{i}" for i in range(15))
    assert len(ap._parse_poll_options(lines)) == ap.POLL_OPTIONS_MAX


def test_validate_question():
    assert ap._validate_question("") is not None
    assert ap._validate_question("   ") is not None
    assert ap._validate_question("x" * 301) is not None
    assert ap._validate_question("Нормальный вопрос?") is None


def test_validate_options():
    assert ap._validate_options(["a"]) is not None
    assert ap._validate_options(["a", "b"]) is None
    long = "x" * (ap.POLL_OPTION_MAX + 1)
    assert ap._validate_options(["a", long]) is not None
