# Changelog

## [Unreleased]

### Added

- **Централизованная система error handling:**
  - Кастомные исключения для всех типов ошибок
  - Автоматическая классификация ошибок
  - Structured logging с контекстом
  - Метрики ошибок для мониторинга
- **Retry механизм:** exponential backoff, стратегии для OpenAI, Supabase, Telegram, декоратор `@with_retry`
- **Error boundary:** context manager `async with error_boundary()`, fallback, подавление ошибок
- **Telegram middleware:** автоматическая обработка ошибок в handlers, уведомления пользователей
- Модуль `smart_bot_factory.error_handling` (exceptions, handler, context, retry, middleware, migration_utils)
- 🔥 Hot Reload для промптов:
  - File Watcher на базе `watchdog`
  - Debouncing для частых сохранений
  - Rate limiting: максимум 10 перезагрузок/мин
  - Настройка `ENABLE_PROMPT_HOT_RELOAD` в `.env`
  - Документация: `docs/HOT_RELOAD.md`

### Changed

- Рефакторинг `message_sender.py`, `bot_utils.py`: использование централизованного error handling
- OpenAI запросы с автоматическим retry; Supabase add_message, get_chat_history, update_session с retry
- `process_user_message` обёрнут в error_boundary; `_process_ai_response` обрабатывает ошибки через ErrorHandler
- Рефакторинг: удалено дублирование кода конвертации сообщений.
- Все конвертации унифицированы через `MessageConverter`.
- Удалены дублированные методы `_openai_to_langchain` и `_openai_messages_to_langchain` из `bot_testing.py`.

### Added

- Pydantic-модели для типобезопасности:
  - `AIMetadata` — метаданные ответа AI
  - `EventData` — модель события
  - `FileEventData` — модель файлового события
  - `SessionInfo` — информация о сессии
  - `Message` — модель сообщения
- Утилита `parse_ai_metadata_safe()` для безопасного парсинга метаданных с fallback на исходный dict.
- Константа `AIMetadataKey.FILE_EVENTS`.
- Тесты: `tests/test_models/`, `tests/test_backward_compatibility.py`, `tests/test_performance.py`.

### Fixed

- Улучшена валидация данных от AI в `message_processing._process_ai_response` через Pydantic с сохранением обратной совместимости.
