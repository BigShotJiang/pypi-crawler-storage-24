"""
Test Bot Bot - Умный Telegram бот на Smart Bot Factory
"""

from pathlib import Path

from smart_bot_factory.router import EventRouter
from smart_bot_factory.message import send_message_by_human
from smart_bot_factory.creation import BotBuilder

event_router = EventRouter()
bot_builder = BotBuilder()

# Поиск контекста (router + знания): включается только если есть папка knowledge
import importlib.util
_bot_dir = Path(__file__).parent / "bots" / Path(__file__).stem
_has_knowledge = (_bot_dir / "knowledge").is_dir() and any((_bot_dir / "knowledge").glob("*.txt"))
if _has_knowledge:
    _knowledge_context_file = _bot_dir / "knowledge" / "knowledge_context.py"
    if _knowledge_context_file.exists():
        _spec = importlib.util.spec_from_file_location("knowledge_context", _knowledge_context_file)
        _mod = importlib.util.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        bot_builder.enrich_context(_mod.knowledge_context_enricher)

@event_router.event_handler(once_only=True)
async def collect_contact(user_id: int, contact_data: str):
    """
    Обрабатывает получение контактных данных
    
    ИИ создает: {"тип": "collect_contact", "инфо": "+79001234567"}
    """
    await send_message_by_human(
        user_id=user_id,
        message_text=f"✅ Спасибо! Ваши данные сохранены: {contact_data}"
    )
    return {"status": "success", "contact": contact_data}

bot_builder.register_routers(event_router)
