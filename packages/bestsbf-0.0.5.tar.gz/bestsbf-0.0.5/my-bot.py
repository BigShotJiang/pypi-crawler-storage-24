"""Точка входа бота my-bot (Smart Bot Factory)."""


from smart_bot_factory.creation import BotBuilder
from smart_bot_factory.router import EventRouter

event_router = EventRouter()
bot_builder = BotBuilder()

bot_builder.register_routers(event_router)
