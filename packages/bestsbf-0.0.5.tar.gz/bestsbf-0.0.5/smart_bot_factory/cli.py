"""
CLI интерфейс для Smart Bot Factory
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import List, Optional

import click
from project_root_finder import root


@click.group()
def cli():
    """Smart Bot Factory - инструмент для создания умных чат-ботов"""
    pass


@cli.command()
@click.argument("bot_id")
@click.argument("template", required=False, default="base")
def create(bot_id: str, template: str = "base"):
    """Создать нового бота"""
    success = create_new_bot_structure(template, bot_id)
    if not success:
        sys.exit(1)


@cli.command()
def list():
    """Показать список доступных ботов"""
    bots = list_bots_in_bots_folder()
    if not bots:
        click.echo("🤖 Нет доступных ботов")
        return

    click.echo("🤖 Доступные боты:")
    for bot in sorted(bots):
        click.echo(f"  📱 {bot}")


@cli.command()
@click.argument("bot_id_or_file")
def run(bot_id_or_file: str):
    """Запустить бота (можно указать bot_id или имя файла запускалки, например mdclinica.py)"""
    try:
        # Определяем bot_id: если аргумент заканчивается на .py, извлекаем bot_id из имени файла
        if bot_id_or_file.endswith(".py"):
            # Убираем путь и расширение, оставляем только имя файла
            bot_id = Path(bot_id_or_file).stem
            bot_file = root / Path(bot_id_or_file)
            # Если указан путь, нормализуем его относительно корня проекта
            if not bot_file.is_absolute():
                bot_file = root / bot_file
        else:
            bot_id = bot_id_or_file
            bot_file = root / Path(f"{bot_id}.py")

        # Проверяем наличие основного файла бота в корневой директории
        if not bot_file.exists():
            raise click.ClickException(f"Файл {bot_file.name} не найден в корневой директории")

        # Проверяем существование бота
        bot_path = root / Path("bots") / bot_id
        if not bot_path.exists():
            raise click.ClickException(f"Бот {bot_id} не найден в папке bots/")

        # Проверяем наличие .env файла
        env_file = bot_path / ".env"
        if not env_file.exists():
            raise click.ClickException(f"Файл .env не найден для бота {bot_id}")

        # Настраиваем окружение для бота
        from dotenv import load_dotenv

        # Добавляем корень проекта в sys.path
        sys.path.insert(0, str(root))

        # Загружаем .env файл
        load_dotenv(env_file)
        click.echo(f"📄 Загружен .env файл: {env_file}")

        # Устанавливаем переменные окружения ПОСЛЕ загрузки .env (чтобы не перезаписалась)
        os.environ["BOT_ID"] = bot_id
        click.echo(f"🔧 Установлен BOT_ID в переменные окружения: {bot_id}")

        # Устанавливаем путь к промптам
        prompts_dir = bot_path / "prompts"
        if prompts_dir.exists():
            os.environ["PROMT_FILES_DIR"] = str(prompts_dir)
            click.echo(f"📝 Установлен путь к промптам: {prompts_dir}")

        # Импортируем модуль бота и запускаем через bot_builder.start()
        click.echo(f"🚀 Запускаем бота {bot_id}...")

        import asyncio
        import importlib.util

        # Загружаем модуль бота
        spec = importlib.util.spec_from_file_location(f"{bot_id}_bot", bot_file)
        if spec is None or spec.loader is None:
            raise click.ClickException(f"Не удалось загрузить модуль бота: {bot_file}")

        bot_module = importlib.util.module_from_spec(spec)

        # Выполняем модуль (это зарегистрирует все роутеры в глобальном scope)
        spec.loader.exec_module(bot_module)

        # Ищем bot_builder в модуле
        bot_builder = None
        if hasattr(bot_module, "bot_builder"):
            bot_builder = bot_module.bot_builder
        else:
            # Пытаемся найти BotBuilder в глобальных переменных модуля
            for attr_name in dir(bot_module):
                attr = getattr(bot_module, attr_name)
                if hasattr(attr, "start") and hasattr(attr, "build"):
                    bot_builder = attr
                    break

        if not bot_builder:
            raise click.ClickException(f"bot_builder не найден в файле {bot_id}.py")

        # Запускаем бота через bot_builder.start()
        asyncio.run(bot_builder.start())

    except KeyboardInterrupt:
        click.echo("\n⏹️ Остановка бота...")
        sys.exit(0)
    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        if "--verbose" in sys.argv or "-v" in sys.argv:
            import traceback

            click.echo(f"Стек ошибки: {traceback.format_exc()}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("bot_id")
@click.option("--file", help="Запустить тесты только из указанного файла")
@click.option("-v", "--verbose", is_flag=True, help="Подробный вывод")
@click.option("--max-concurrent", default=5, help="Максимальное количество потоков")
def test(bot_id: str, file: Optional[str] = None, verbose: bool = False, max_concurrent: int = 5):
    """Запустить тесты бота через BotBuilder"""
    try:
        # Проверяем существование бота
        bot_path = root / "bots" / bot_id
        if not bot_path.exists():
            raise click.ClickException(f"Бот {bot_id} не найден в папке {root}/bots/")

        # Проверяем наличие основного файла бота в корневой директории
        bot_file = root / f"{bot_id}.py"
        if not bot_file.exists():
            raise click.ClickException(f"Файл {bot_id}.py не найден в корневой директории")

        # Проверяем наличие тестов
        tests_dir = bot_path / "tests"
        if not tests_dir.exists():
            click.echo(f"⚠️ Тесты не найдены для бота {bot_id}")
            return

        # Ищем YAML файлы с тестами
        yaml_files = [str(f.name) for f in tests_dir.glob("*.yaml")]

        if not yaml_files:
            click.echo(f"⚠️ YAML тесты не найдены для бота {bot_id}")
            return

        click.echo(f"🧪 Запускаем тесты для бота {bot_id} через BotBuilder...")

        # Настраиваем окружение для бота
        from dotenv import load_dotenv

        # Добавляем корень проекта в sys.path
        sys.path.insert(0, str(root))

        # Загружаем .env файл
        env_file = bot_path / ".env"
        if env_file.exists():
            load_dotenv(env_file)
            click.echo(f"📄 Загружен .env файл: {env_file}")

        # Устанавливаем переменные окружения
        os.environ["BOT_ID"] = bot_id

        # Устанавливаем путь к промптам
        prompts_dir = bot_path / "prompts"
        if prompts_dir.exists():
            os.environ["PROMT_FILES_DIR"] = str(prompts_dir)

        # Настраиваем логирование
        import logging

        log_level = logging.INFO if verbose else logging.INFO
        logging.basicConfig(level=log_level, format="%(message)s")

        # Импортируем и запускаем тестирование через файл бота
        import asyncio
        import importlib.util

        # Загружаем модуль бота
        spec = importlib.util.spec_from_file_location(f"{bot_id}_bot", bot_file)
        if spec is None or spec.loader is None:
            raise click.ClickException(f"Не удалось загрузить модуль бота: {bot_file}")

        bot_module = importlib.util.module_from_spec(spec)

        # Добавляем необходимые переменные в модуль перед выполнением
        setattr(bot_module, "root", root)
        setattr(bot_module, "BOT_ID", bot_id)

        # Выполняем модуль
        spec.loader.exec_module(bot_module)

        # Ищем BotBuilder в модуле
        bot_builder = None
        if hasattr(bot_module, "bot_builder"):
            bot_builder = bot_module.bot_builder
        elif hasattr(bot_module, "builder"):
            bot_builder = bot_module.builder
        else:
            # Пытаемся найти BotBuilder в глобальных переменных модуля
            for attr_name in dir(bot_module):
                attr = getattr(bot_module, attr_name)
                if hasattr(attr, "test") and hasattr(attr, "build"):
                    bot_builder = attr
                    break

        if not bot_builder:
            raise click.ClickException(f"BotBuilder не найден в файле {bot_id}.py")

        # Запускаем тестирование через BotBuilder
        async def run_test():
            try:
                # ВАЖНО: Выполняем функцию main() из модуля для регистрации всех компонентов
                if hasattr(bot_module, "main") and callable(bot_module.main):
                    click.echo("🔧 Выполняем main() для регистрации компонентов...")

                    # Создаем задачу main(), но перехватываем вызов start()
                    original_start = bot_builder.start
                    start_called = False

                    async def mock_start():
                        nonlocal start_called
                        start_called = True
                        click.echo("✅ Компоненты зарегистрированы, переходим к тестированию")
                        return

                    # Временно заменяем start() на заглушку
                    bot_builder.start = mock_start

                    try:
                        # Выполняем main() - это зарегистрирует все компоненты и вызовет build()
                        await bot_module.main()
                    except Exception as e:
                        # Если main() завершился с ошибкой, но build() был вызван, продолжаем
                        if not bot_builder._initialized:
                            raise e
                        click.echo(f"⚠️ main() завершился с ошибкой, но build() выполнен: {e}")
                    finally:
                        # Восстанавливаем оригинальный start()
                        bot_builder.start = original_start
                else:
                    # Если нет main(), собираем бота вручную
                    click.echo("⚠️ Функция main() не найдена, собираем бота вручную...")
                    if not bot_builder._initialized:
                        await bot_builder.build()

                # Запускаем тестирование
                exit_code = await bot_builder.test(scenario_file=file, max_concurrent=max_concurrent, verbose=verbose)

                return exit_code

            except Exception as e:
                click.echo(f"❌ Ошибка при тестировании: {e}")
                import traceback

                if verbose:
                    click.echo(f"Стек ошибки: {traceback.format_exc()}")
                return 1

        # Запускаем асинхронную функцию
        exit_code = asyncio.run(run_test())

        if exit_code == 0:
            click.echo("✅ Все тесты пройдены")
        else:
            click.echo("❌ Есть ошибки в тестах")
            sys.exit(1)

    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        if verbose:
            import traceback

            click.echo(f"Стек ошибки: {traceback.format_exc()}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("bot_id")
def config(bot_id: str):
    """Настроить конфигурацию бота"""
    try:
        # Проверяем существование бота
        bot_path = root / Path("bots") / bot_id
        if not bot_path.exists():
            raise click.ClickException(f"Бот {bot_id} не найден в папке bots/")

        # Открываем .env файл в редакторе
        env_file = bot_path / ".env"
        if not env_file.exists():
            raise click.ClickException(f"Файл .env не найден для бота {bot_id}")

        # Определяем редактор
        editor = os.environ.get("EDITOR", "notepad" if os.name == "nt" else "nano")

        click.echo(f"⚙️ Открываем конфигурацию бота {bot_id}...")
        subprocess.run([editor, str(env_file)], check=True)

    except subprocess.CalledProcessError as e:
        click.echo(f"❌ Ошибка при открытии редактора: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("bot_id")
@click.option("--list", "list_prompts", is_flag=True, help="Показать список промптов")
@click.option("--edit", "edit_prompt", help="Редактировать промпт")
@click.option("--add", "add_prompt", help="Добавить новый промпт")
def prompts(
    bot_id: str,
    list_prompts: bool = False,
    edit_prompt: Optional[str] = None,
    add_prompt: Optional[str] = None,
):
    """Управление промптами бота"""
    try:
        # Проверяем существование бота
        bot_path = root / Path("bots") / bot_id
        if not bot_path.exists():
            raise click.ClickException(f"Бот {bot_id} не найден в папке bots/")

        prompts_dir = bot_path / "prompts"
        if not prompts_dir.exists():
            raise click.ClickException(f"Папка промптов не найдена для бота {bot_id}")

        if list_prompts or (not edit_prompt and not add_prompt):
            # Показываем список промптов (по умолчанию или с флагом --list)
            prompt_files = [f.name for f in prompts_dir.glob("*.txt")]

            if not prompt_files:
                click.echo("📝 Промпты не найдены")
                return

            click.echo(f"📝 Промпты бота {bot_id}:")
            for prompt_file in sorted(prompt_files):
                click.echo(f"  📄 {prompt_file[:-4]}")

            # Показываем справку только если не указан флаг --list
            if not list_prompts:
                click.echo()
                click.echo("Использование:")
                click.echo("  sbf prompts <bot_id> --edit <prompt_name>      # Редактировать промпт")
                click.echo("  sbf prompts <bot_id> --add <prompt_name>       # Добавить новый промпт")

        elif edit_prompt:
            # Редактируем промпт
            prompt_file = prompts_dir / f"{edit_prompt}.txt"
            if not prompt_file.exists():
                raise click.ClickException(f"Промпт {edit_prompt} не найден")

            editor = os.environ.get("EDITOR", "notepad" if os.name == "nt" else "nano")
            click.echo(f"✏️ Редактируем промпт {edit_prompt}...")
            subprocess.run([editor, str(prompt_file)], check=True)

        elif add_prompt:
            # Добавляем новый промпт
            prompt_file = prompts_dir / f"{add_prompt}.txt"
            if prompt_file.exists():
                raise click.ClickException(f"Промпт {add_prompt} уже существует")

            # Создаем файл с базовым содержимым
            prompt_file.write_text(
                f"# Промпт: {add_prompt}\n\nВведите содержимое промпта здесь...",
                encoding="utf-8",
            )

            # Открываем в редакторе
            editor = os.environ.get("EDITOR", "notepad" if os.name == "nt" else "nano")
            click.echo(f"📝 Создаем новый промпт {add_prompt}...")
            subprocess.run([editor, str(prompt_file)], check=True)

    except subprocess.CalledProcessError as e:
        click.echo(f"❌ Ошибка при открытии редактора: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        sys.exit(1)


@cli.command()
def path():
    """Показать путь к проекту"""
    click.echo(root)


@cli.command()
@click.argument("bot_id")
@click.option("--force", "-f", is_flag=True, help="Удалить без подтверждения")
def rm(bot_id: str, force: bool = False):
    """Удалить бота и все его файлы"""
    try:
        # Проверяем существование бота
        bot_path = root / Path("bots") / bot_id
        if not bot_path.exists():
            raise click.ClickException(f"🤖 Бот {bot_id} не найден в папке bots/")

        # Проверяем наличие основного файла бота в корневой директории
        bot_file = Path(f"{bot_id}.py")
        if not bot_file.exists():
            raise click.ClickException(f"📄 Файл {bot_id}.py не найден в корневой директории")

        # Показываем что будет удалено
        click.echo("🗑️ Будет удалено:")
        click.echo(f"  📄 Файл запускалки: {bot_file}")
        click.echo(f"  📁 Папка бота: {bot_path}")

        # Запрашиваем подтверждение если не указан --force
        if not force:
            if not click.confirm(f"⚠️ Вы уверены, что хотите удалить бота {bot_id}?"):
                click.echo("❌ Удаление отменено")
                return

        # Удаляем файл запускалки
        if bot_file.exists():
            bot_file.unlink()
            click.echo(f"✅ Файл {bot_file} удален")

        # Удаляем папку бота
        if bot_path.exists():
            import shutil

            shutil.rmtree(bot_path)
            click.echo(f"✅ Папка {bot_path} удалена")

        click.echo(f"🎉 Бот {bot_id} полностью удален")

    except Exception as e:
        click.echo(f"❌ Ошибка при удалении бота: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("source_bot_id")
@click.argument("new_bot_id")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Перезаписать существующего бота без подтверждения",
)
def copy(source_bot_id: str, new_bot_id: str, force: bool = False):
    """Скопировать существующего бота как шаблон"""
    try:
        # Проверяем существование исходного бота
        source_bot_path = root / "bots" / source_bot_id
        if not source_bot_path.exists():
            raise click.ClickException(f"Исходный бот {source_bot_id} не найден в папке bots/")

        # Проверяем наличие файла запускалки исходного бота
        source_bot_file = root / f"{source_bot_id}.py"
        if not source_bot_file.exists():
            raise click.ClickException(f"Файл запускалки {source_bot_id}.py не найден в корневой директории")

        # Проверяем, не существует ли уже новый бот
        new_bot_path = root / "bots" / new_bot_id
        new_bot_file = root / f"{new_bot_id}.py"

        if new_bot_path.exists() or new_bot_file.exists():
            if not force:
                if not click.confirm(f"Бот {new_bot_id} уже существует. Перезаписать?"):
                    click.echo("Копирование отменено")
                    return
            else:
                click.echo(f"⚠️ Перезаписываем существующего бота {new_bot_id}")

        # Копируем бота
        click.echo(f"📋 Копируем бота {source_bot_id} → {new_bot_id}...")
        copy_bot_template(source_bot_id, new_bot_id)

        click.echo(f"✅ Бот {new_bot_id} успешно скопирован из {source_bot_id}")
        click.echo("📝 Не забудьте настроить .env файл для нового бота")

    except Exception as e:
        click.echo(f"❌ Ошибка при копировании бота: {e}", err=True)
        sys.exit(1)


@cli.command()
def link():
    """Создать UTM-ссылку для бота"""
    try:
        # Проверяем наличие скрипта генерации ссылок
        link_script = Path(__file__).parent / "utm_link_generator.py"
        if not link_script.exists():
            raise click.ClickException("Скрипт utm_link_generator.py не найден")

        # Запускаем скрипт генерации ссылок
        click.echo("🔗 Запускаем генератор UTM-ссылок...")
        subprocess.run([sys.executable, str(link_script)], check=True)

    except subprocess.CalledProcessError as e:
        click.echo(f"❌ Ошибка при запуске генератора ссылок: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        sys.exit(1)


def create_new_bot_structure(template: str, bot_id: str) -> bool:
    """Создает новую структуру бота в папке bots/"""
    try:
        # Создаем папку bots если её нет
        bots_dir = root / Path("bots")
        bots_dir.mkdir(exist_ok=True)

        # Создаем папку для нового бота
        bot_dir = bots_dir / bot_id
        if bot_dir.exists():
            click.echo(f"⚠️ Бот {bot_id} уже существует")
            return False

        bot_dir.mkdir()

        # Создаем структуру папок
        (bot_dir / "prompts").mkdir()
        (bot_dir / "tests").mkdir()
        (bot_dir / "reports").mkdir()
        (bot_dir / "welcome_files").mkdir()
        (bot_dir / "files").mkdir()

        if template == "base":
            # Используем growthmed-october-24 как базовый шаблон
            copy_from_growthmed_template(bot_dir, bot_id)
        else:
            # Используем другой шаблон из папки bots
            copy_from_bot_template(template, bot_dir, bot_id)

        click.echo(f"✅ Бот {bot_id} создан в папке bots/{bot_id}/")
        click.echo("📝 Не забудьте настроить .env файл перед запуском")
        return True

    except Exception as e:
        click.echo(f"❌ Ошибка при создании бота: {e}")
        return False


def list_bots_in_bots_folder() -> List[str]:
    """Возвращает список ботов из папки bots/"""
    bots_dir = root / Path("bots")
    if not bots_dir.exists():
        return []

    bots = []
    for item in bots_dir.iterdir():
        if item.is_dir() and Path(f"{item.name}.py").exists():
            bots.append(item.name)

    return bots


def _create_knowledge_folder(bot_dir: Path) -> None:
    """Создаёт папку knowledge с примером .txt (строгий YAML frontmatter: name + description)."""
    knowledge_dir = bot_dir / "knowledge"
    knowledge_dir.mkdir(exist_ok=True)

    about_bot = """---
name: О боте (пример)
description: Общая информация о боте и возможностях. Подгружать при вопросах «что умеет бот», «расскажи о себе», «какие функции».
---

Это пример файла знаний. Сюда можно добавить описание бота, продуктов, команды и т.д.
Индекс для router-модели собирается автоматически из YAML-шапок всех knowledge/*.txt.
"""
    (knowledge_dir / "about_bot.txt").write_text(about_bot, encoding="utf-8")

    # Файл knowledge_context.py: подключается из запускалки через importlib, модель-роутер решает, нужен ли контекст
    knowledge_context_py = """\"\"\"
Обогатитель контекста: router-модель по запросу пользователя решает, подгружать ли файлы из knowledge/.
Подключается из файла запуска бота (importlib). Отдельный файл нужен для имён ботов с дефисом (например verify-bot).
\"\"\"
from pathlib import Path
from smart_bot_factory.integrations.openai.knowledge import get_knowledge_context_enricher

knowledge_context_enricher = get_knowledge_context_enricher(Path(__file__).parent.parent)
"""
    (knowledge_dir / "knowledge_context.py").write_text(knowledge_context_py, encoding="utf-8")


def _ensure_knowledge_context_file(bot_dir: Path) -> None:
    """Создаёт knowledge/knowledge_context.py в папке бота, если его ещё нет."""
    knowledge_dir = bot_dir / "knowledge"
    knowledge_dir.mkdir(exist_ok=True)
    if (knowledge_dir / "knowledge_context.py").exists():
        return
    knowledge_context_py = """\"\"\"
Обогатитель контекста: router-модель по запросу пользователя решает, подгружать ли файлы из knowledge/.
\"\"\"
from pathlib import Path
from smart_bot_factory.integrations.openai.knowledge import get_knowledge_context_enricher

knowledge_context_enricher = get_knowledge_context_enricher(Path(__file__).parent.parent)
"""
    (knowledge_dir / "knowledge_context.py").write_text(knowledge_context_py, encoding="utf-8")


def create_bot_template(bot_id: str) -> str:
    """Создает шаблон основного файла бота"""
    return f'''"""
{bot_id.replace("-", " ").title()} Bot - Умный Telegram бот на Smart Bot Factory
"""

from pathlib import Path

from smart_bot_factory.router import EventRouter
from smart_bot_factory.message import send_message_by_human
from smart_bot_factory.creation import BotBuilder

event_router = EventRouter()
bot_builder = BotBuilder()

# Поиск контекста (router + знания): включается только если есть папка knowledge
import importlib.util
_bot_dir = Path(__file__).parent / "bots" / Path(__file__).stem
_has_knowledge = (_bot_dir / "knowledge").is_dir() and any((_bot_dir / "knowledge").glob("*.txt"))
if _has_knowledge:
    _knowledge_context_file = _bot_dir / "knowledge" / "knowledge_context.py"
    if _knowledge_context_file.exists():
        _spec = importlib.util.spec_from_file_location("knowledge_context", _knowledge_context_file)
        _mod = importlib.util.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        bot_builder.enrich_context(_mod.knowledge_context_enricher)

@event_router.event_handler(once_only=True)
async def collect_contact(user_id: int, contact_data: str):
    """
    Обрабатывает получение контактных данных
    
    ИИ создает: {{"тип": "collect_contact", "инфо": "+79001234567"}}
    """
    await send_message_by_human(
        user_id=user_id,
        message_text=f"✅ Спасибо! Ваши данные сохранены: {{contact_data}}"
    )
    return {{"status": "success", "contact": contact_data}}

bot_builder.register_routers(event_router)
'''


def create_env_template(bot_id: str) -> str:
    """Шаблон .env: обязательные и частые ключи активны; остальные перечислены закомментированы с кратким описанием."""
    return f"""# =============================================================================
# Smart Bot Factory — переменные окружения бота
# Активные строки ниже — заполните секреты и при необходимости поправьте значения.
# Закомментированные (# VAR=...) — раскомментируйте при нужде; значения = типичные дефолты.
# =============================================================================

# --- Telegram: токен от @BotFather (обязательно) ---
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here

# --- Supabase: URL и anon key (обязательно для БД/истории) ---
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your_supabase_anon_key

# --- OpenAI: ключ API (обязательно); один ключ на диалог и вспомогательные вызовы ---
OPENAI_API_KEY=sk-your-openai-api-key

# Основная модель: ответы пользователю в диалоге
OPENAI_MODEL=gpt-5-mini
# Лимит токенов ответа основной модели
OPENAI_MAX_TOKENS=1500
# Температура сэмплирования основной модели
OPENAI_TEMPERATURE=0.7

# Router: выбор файлов knowledge/*.txt для подмешивания в контекст (дешёвая модель)
OPENAI_ROUTER_MODEL=gpt-5-mini
# Сколько последних реплик отдать router-модели (короткие ответы вроде «да, пришли»)
KNOWLEDGE_ROUTER_HISTORY_MESSAGES=6
# Краткий обзор prompts/ в knowledge/summary.md для роутера знаний; при отсутствии файла генерируется при старте (нужен OPENAI_API_KEY)
# PROMPTS_SUMMARY_MODEL=gpt-5-mini
# Опционально: лимит completion-токенов (gpt-5 с reasoning и structured output; пусто = лимит не задаётся со стороны клиента)
# PROMPTS_SUMMARY_MAX_COMPLETION_TOKENS=8192
# Символов на файл prompts/ в запрос генерации summary; 0 = не усечь
# PROMPTS_SUMMARY_EXCERPT_CHARS=100000
# LangGraph: узел выбора knowledge/*.txt (false — ветка отключена; при отсутствии папки knowledge/ всё равно не включается)
DIALOG_KNOWLEDGE_ROUTER_ENABLED=true
# LangGraph: цепочка Qdrant RAG после роутера (false — только основная модель и knowledge; без поднятого retriever не включается)
DIALOG_QDRANT_RAG_ENABLED=true

# Каталог с промптами относительно папки бота (обязателен для старта)
PROMT_FILES_DIR=prompts

# Уровень логов корня (DEBUG, INFO, …)
LOG_LEVEL=INFO

# Сколько последних сообщений диалога хранить/передавать в контекст (ограничение истории)
MAX_CONTEXT_MESSAGES=50

# Режим разметки исходящих сообщений Telegram (Markdown, HTML, …)
MESSAGE_PARSE_MODE=Markdown

# Папка с файлами после /start (имя каталога в папке бота; дефолт в коде: welcome_file)
WELCOME_FILE_URL=welcome_file
# Имя файла с текстом подписи к медиа приветствия
WELCOME_FILE_MSG=welcome_file_msg.txt

# ID админов через запятую (доступ к админ-командам); без этого админка недоступна
ADMIN_TELEGRAM_IDS=123456789,987654321
# Таймаут сессии админа в минутах
ADMIN_SESSION_TIMEOUT_MINUTES=30

# Показывать ли пользователю сырой JSON отладки
DEBUG_MODE=false

# Порог «качества лида» и таймаут сессии продаж в часах
LEAD_QUALIFICATION_THRESHOLD=7
SESSION_TIMEOUT_HOURS=24

# Логирование медленных операций (true — включить)
ENABLE_PERFORMANCE_LOGGING=false
# Не логировать события быстрее N мс
PERFORMANCE_LOG_MIN_MS=50
# Уровень детализации perf-логов: basic | detailed
PERFORMANCE_LOG_LEVEL=basic

# =============================================================================
# Необязательно — раскомментируйте при необходимости
# =============================================================================

# Базовый URL API OpenAI (пусто = официальный API; для OpenRouter и т.п. укажите URL)
# OPENAI_BASE_URL=

# Отдельная модель только для router знаний (если не задана — берётся OPENAI_ROUTER_MODEL)
# KNOWLEDGE_ROUTER_MODEL=gpt-5-mini

# Минимум сообщений в истории до сжатия и лимит токенов на историю в БД
# HISTORY_MIN_MESSAGES=4
# HISTORY_MAX_TOKENS=5000

# Пытаться ли парсить даты в сообщениях пользователя
# PARSE_DATE_FORMAT=true

# Автоперезагрузка промптов с диска при изменении файлов
# ENABLE_PROMPT_HOT_RELOAD=true

# ИИ-починка YAML-шапок knowledge/*.txt при сборке индекса
# KNOWLEDGE_AI_REPAIR_HEADERS=true
# ИИ-шапки knowledge/*.txt: description в промпте ограничен ~220 символов (сжато для роутера)
# Сколько символов тела файла отдавать модели для починки шапки
# KNOWLEDGE_PREAMBLE_BODY_CHARS=8000
# Макс. символов тела .txt при загрузке в индекс знаний
# KNOWLEDGE_FILE_MAX_CHARS=8000

# ---------- Qdrant RAG (uv sync --extra qdrant-rag; источник .txt см. QDRANT_RAG_DATA_SOURCE) ----------
# Планировщик запроса в RAG в LangGraph (пусто = OPENAI_ROUTER_MODEL); при false/пустом запросе от модели весь RAG пропускается
# RAG_QUERY_PLANNER_MODEL=gpt-5-mini
# true — без LLM-планировщика: в retrieval уходит последняя реплика пользователя (как раньше)
# RAG_QUERY_PLANNER_DISABLED=false
# Voyage: ключ для rerank (опционально; без ключа RAG работает без переранжирования)
# VOYAGE_API_KEY=
# Модель rerank Voyage
# VOYAGE_RERANK_MODEL=rerank-2.5

# Откуда брать тексты: parser_then_rag_data (по умолчанию) | parser | rag_data | both
# parser = bots/BOT_ID/parser/**/*.txt; rag_data = bots/BOT_ID/rag_data/**/*.txt
# QDRANT_RAG_DATA_SOURCE=parser_then_rag_data
# true — при старте бота полная пересборка Qdrant + docstore (отладка)
# QDRANT_FORCE_REBUILD_ON_START=false

# URL Qdrant и имя коллекции (к имени добавляется суффикс по BOT_ID)
# QDRANT_URL=http://localhost:6333
# QDRANT_COLLECTION=rag_knowledge

# true: sparse BM25 на сервере Qdrant (Document); false — нужен локальный sparse в клиенте
# QDRANT_SERVER_INFERENCE=true

# Имена векторов в коллекции (должны совпадать с уже созданной коллекцией)
# QDRANT_DENSE_VECTOR_NAME=dense
# QDRANT_SPARSE_VECTOR_NAME=sparse

# Модель sparse на стороне Qdrant (или алиас RAG_QDRANT_SPARSE_MODEL)
# RAG_QDRANT_BM25_MODEL=Qdrant/bm25

# Модель эмбеддингов для dense в Qdrant (OpenAI)
# RAG_OPENAI_EMBED_MODEL=text-embedding-3-small

# HyDE: модель гипотетического документа (пусто = OPENAI_ROUTER_MODEL)
# RAG_HYDE_MODEL=gpt-5-mini
# Добавлять ли исходный запрос к гипотезам HyDE
# RAG_HYDE_INCLUDE_ORIGINAL=true
# Макс. токенов ответа HyDE
# RAG_HYDE_MAX_TOKENS=256

# Top-K для dense, BM25 и итог после RRF
# RAG_VECTOR_TOP_K=20
# RAG_BM25_TOP_K=20
# RAG_HYBRID_TOP_K=40

# Батч upsert в Qdrant и сколько чанков после rerank отдать в промпт
# RAG_QDRANT_UPSERT_BATCH=32
# RAG_RERANK_TOP_N=5

# Иерархический чанкинг (родитель ~1024 / ребёнок ~256 токенов / перекрытие)
# RAG_PARENT_CHUNK_TOKENS=1024
# RAG_CHILD_CHUNK_TOKENS=256
# RAG_CHUNK_OVERLAP=40

# Порог AutoMerge в LlamaIndex (слияние родительских нод)
# RAG_AUTOMERGE_THRESH=0.5

# =============================================================================
# BOT_ID выставляется при запуске из имени файла запускалки (например python {bot_id}.py).
# =============================================================================
"""


def copy_from_growthmed_template(bot_dir: Path, bot_id: str):
    """Копирует шаблон из growthmed-october-24"""
    try:
        # Создаем основной файл бота в корневой директории проекта
        bot_file = root / Path(f"{bot_id}.py")
        bot_file.write_text(create_bot_template(bot_id), encoding="utf-8")

        # Создаем .env файл в папке бота (НЕ копируем из шаблона)
        env_file = bot_dir / ".env"
        env_file.write_text(create_env_template(bot_id), encoding="utf-8")

        # Папка knowledge — создаём сразу, чтобы не зависеть от последующих click.echo (эмодзи падают в cp1251)
        _create_knowledge_folder(bot_dir)

        # Копируем промпты из growthmed-october-24
        source_prompts = Path(__file__).parent / "configs" / "growthmed-october-24" / "prompts"
        target_prompts = bot_dir / "prompts"

        if source_prompts.exists():
            for prompt_file in source_prompts.glob("*.txt"):
                shutil.copy2(prompt_file, target_prompts / prompt_file.name)
            click.echo("📝 Промпты скопированы из growthmed-october-24")
        else:
            click.echo(f"⚠️ Папка промптов не найдена: {source_prompts}")
            # Fallback к базовым промптам
            create_basic_prompts(target_prompts)
            click.echo("📝 Созданы базовые промпты")

        # Копируем тесты из growthmed-october-24
        source_tests = Path(__file__).parent / "configs" / "growthmed-october-24" / "tests"
        target_tests = bot_dir / "tests"

        if source_tests.exists():
            for test_file in source_tests.glob("*"):
                if test_file.is_file():
                    shutil.copy2(test_file, target_tests / test_file.name)
            click.echo("🧪 Тесты скопированы из growthmed-october-24")

        # Копируем welcome_files из growthmed-october-24
        source_welcome = Path(__file__).parent / "configs" / "growthmed-october-24" / "welcome_file"
        target_welcome = bot_dir / "welcome_files"

        if source_welcome.exists():
            for welcome_file in source_welcome.glob("*"):
                if welcome_file.is_file():
                    shutil.copy2(welcome_file, target_welcome / welcome_file.name)
            click.echo("📁 Welcome файлы скопированы из growthmed-october-24")

        # Копируем files из growthmed-october-24
        source_files = Path(__file__).parent / "configs" / "growthmed-october-24" / "files"
        target_files = bot_dir / "files"

        if source_files.exists():
            for file_item in source_files.glob("*"):
                if file_item.is_file():
                    shutil.copy2(file_item, target_files / file_item.name)
            click.echo("📎 Файлы скопированы из growthmed-october-24")

    except Exception as e:
        click.echo(f"Ошибка при копировании шаблона: {e}")
        create_basic_prompts(bot_dir / "prompts")
        _create_knowledge_folder(bot_dir)  # на случай если упали до этого (напр. на эмодзи в echo)


def copy_bot_template(source_bot_id: str, new_bot_id: str):
    """Копирует существующего бота как шаблон для нового бота"""
    try:
        source_dir = root / "bots" / source_bot_id
        new_dir = root / "bots" / new_bot_id

        # Создаем папку для нового бота
        new_dir.mkdir(exist_ok=True)

        # Создаем структуру папок
        (new_dir / "prompts").mkdir(exist_ok=True)
        (new_dir / "tests").mkdir(exist_ok=True)
        (new_dir / "reports").mkdir(exist_ok=True)
        (new_dir / "welcome_files").mkdir(exist_ok=True)
        (new_dir / "files").mkdir(exist_ok=True)

        # Копируем основной файл бота в корневую директорию
        source_bot_file = root / f"{source_bot_id}.py"
        new_bot_file = root / f"{new_bot_id}.py"

        if source_bot_file.exists():
            shutil.copy2(source_bot_file, new_bot_file)

            # Заменяем название бота в файле
            content = new_bot_file.read_text(encoding="utf-8")
            content = content.replace(f'BotBuilder("{source_bot_id}")', f'BotBuilder("{new_bot_id}")')
            content = content.replace(f'EventRouter("{source_bot_id}")', f'EventRouter("{new_bot_id}")')
            content = content.replace(f'bot_id="{source_bot_id}"', f'bot_id="{new_bot_id}"')
            # Удаляем старые main() и __main__ блоки если они есть (для совместимости)
            import re

            # Удаляем async def main(): ... блок
            content = re.sub(r"async def main\(\):.*?(?=\n\n|\n# |\Z)", "", content, flags=re.DOTALL)
            # Удаляем if __name__ == "__main__": ... блок
            content = re.sub(r'if __name__ == ["\']__main__["\']:.*?(?=\n\n|\Z)', "", content, flags=re.DOTALL)

            # Если обогатитель знаний не подключён — добавляем блок загрузки knowledge_context.py
            if "enrich_context" not in content or "knowledge_context_enricher" not in content:
                if "from pathlib import Path" not in content:
                    content = content.replace(
                        "from smart_bot_factory.creation import BotBuilder",
                        "from pathlib import Path\n\nfrom smart_bot_factory.creation import BotBuilder",
                        1,
                    )
                enricher_block = '''
# Поиск контекста (router + знания): включается только если есть папка knowledge
import importlib.util
_bot_dir = Path(__file__).parent / "bots" / Path(__file__).stem
_has_knowledge = (_bot_dir / "knowledge").is_dir() and any((_bot_dir / "knowledge").glob("*.txt"))
if _has_knowledge:
    _knowledge_context_file = _bot_dir / "knowledge" / "knowledge_context.py"
    if _knowledge_context_file.exists():
        _spec = importlib.util.spec_from_file_location("knowledge_context", _knowledge_context_file)
        _mod = importlib.util.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        bot_builder.enrich_context(_mod.knowledge_context_enricher)
'''
                # Вставляем только если такого блока ещё нет
                if "_has_knowledge" not in content:
                    content = content.replace("bot_builder = BotBuilder()", "bot_builder = BotBuilder()" + enricher_block, 1)

            new_bot_file.write_text(content, encoding="utf-8")
            click.echo(f"   📄 Файл запускалки скопирован: {new_bot_id}.py")

        # Создаем шаблон .env файла (НЕ копируем существующий)
        new_env = new_dir / ".env"
        new_env.write_text(create_env_template(new_bot_id), encoding="utf-8")
        click.echo("   ⚙️ Создан шаблон .env файла")

        # Копируем промпты
        source_prompts = source_dir / "prompts"
        new_prompts = new_dir / "prompts"

        if source_prompts.exists():
            for prompt_file in source_prompts.glob("*.txt"):
                shutil.copy2(prompt_file, new_prompts / prompt_file.name)
            click.echo("   📝 Промпты скопированы")

        # Копируем тесты
        source_tests = source_dir / "tests"
        new_tests = new_dir / "tests"

        if source_tests.exists():
            for test_file in source_tests.glob("*"):
                if test_file.is_file():
                    shutil.copy2(test_file, new_tests / test_file.name)
            click.echo("   🧪 Тесты скопированы")

        # Копируем welcome_files
        source_welcome = source_dir / "welcome_files"
        new_welcome = new_dir / "welcome_files"

        if source_welcome.exists():
            for welcome_file in source_welcome.glob("*"):
                if welcome_file.is_file():
                    shutil.copy2(welcome_file, new_welcome / welcome_file.name)
            click.echo("   📁 Welcome файлы скопированы")

        # Копируем files
        source_files = source_dir / "files"
        new_files = new_dir / "files"

        if source_files.exists():
            for file_item in source_files.glob("*"):
                if file_item.is_file():
                    shutil.copy2(file_item, new_files / file_item.name)
            click.echo("   📎 Файлы скопированы")

        # Копируем knowledge (если есть), иначе создаём папку по умолчанию
        source_knowledge = source_dir / "knowledge"
        new_knowledge = new_dir / "knowledge"
        if source_knowledge.exists() and any(source_knowledge.glob("*.txt")):
            if new_knowledge.exists():
                shutil.rmtree(new_knowledge)
            shutil.copytree(source_knowledge, new_knowledge)
            click.echo("   📚 Папка knowledge скопирована")
        else:
            _create_knowledge_folder(new_dir)
            click.echo("   📚 Папка knowledge создана (шаблон)")
        # У нового бота должен быть knowledge_context.py (копируем из шаблона или создаём стандартный)
        source_kc = source_dir / "knowledge" / "knowledge_context.py"
        if source_kc.exists():
            (new_dir / "knowledge").mkdir(exist_ok=True)
            shutil.copy2(source_kc, new_dir / "knowledge" / "knowledge_context.py")
        else:
            _ensure_knowledge_context_file(new_dir)

    except Exception as e:
        click.echo(f"Ошибка при копировании бота: {e}")
        raise


def copy_from_bot_template(template: str, bot_dir: Path, bot_id: str):
    """Копирует шаблон из существующего бота (для команды create)"""
    try:
        template_dir = root / Path("bots") / template
        if not template_dir.exists():
            raise click.ClickException(f"Шаблон {template} не найден")

        # Копируем основной файл бота в корневую директорию
        template_bot_file = root / Path(f"{template}.py")
        if template_bot_file.exists():
            bot_file = root / Path(f"{bot_id}.py")
            shutil.copy2(template_bot_file, bot_file)

            # Заменяем название бота в файле
            content = bot_file.read_text(encoding="utf-8")
            content = content.replace(f'BotBuilder("{template}")', f'BotBuilder("{bot_id}")')
            content = content.replace(f'EventRouter("{template}")', f'EventRouter("{bot_id}")')
            content = content.replace(f'bot_id="{template}"', f'bot_id="{bot_id}"')
            # Удаляем старые main() и __main__ блоки если они есть (для совместимости)
            import re

            # Удаляем async def main(): ... блок
            content = re.sub(r"async def main\(\):.*?(?=\n\n|\n# |\Z)", "", content, flags=re.DOTALL)
            # Удаляем if __name__ == "__main__": ... блок
            content = re.sub(r'if __name__ == ["\']__main__["\']:.*?(?=\n\n|\Z)', "", content, flags=re.DOTALL)
            bot_file.write_text(content, encoding="utf-8")

        # Создаем .env файл в папке бота (НЕ копируем из шаблона)
        env_file = bot_dir / ".env"
        env_file.write_text(create_env_template(bot_id), encoding="utf-8")

        # Копируем промпты
        template_prompts = template_dir / "prompts"
        target_prompts = bot_dir / "prompts"

        if template_prompts.exists():
            for prompt_file in template_prompts.glob("*.txt"):
                shutil.copy2(prompt_file, target_prompts / prompt_file.name)

        # Копируем тесты
        template_tests = template_dir / "tests"
        target_tests = bot_dir / "tests"

        if template_tests.exists():
            for test_file in template_tests.glob("*"):
                if test_file.is_file():
                    shutil.copy2(test_file, target_tests / test_file.name)

        # knowledge: копируем из шаблона или создаём по умолчанию
        template_knowledge = template_dir / "knowledge"
        if template_knowledge.exists() and any(template_knowledge.glob("*.txt")):
            target_knowledge = bot_dir / "knowledge"
            if target_knowledge.exists():
                shutil.rmtree(target_knowledge)
            shutil.copytree(template_knowledge, target_knowledge)
            click.echo("📚 Папка knowledge скопирована из шаблона")
        else:
            _create_knowledge_folder(bot_dir)
            click.echo("📚 Папка knowledge создана (шаблон)")
        # knowledge_context.py: копируем из шаблона или создаём стандартный
        template_kc = template_dir / "knowledge" / "knowledge_context.py"
        if template_kc.exists():
            (bot_dir / "knowledge").mkdir(exist_ok=True)
            shutil.copy2(template_kc, bot_dir / "knowledge" / "knowledge_context.py")
        else:
            _ensure_knowledge_context_file(bot_dir)

        click.echo(f"📋 Шаблон скопирован из {template}")

    except Exception as e:
        click.echo(f"❌ Ошибка при копировании шаблона {template}: {e}")
        raise


def create_basic_prompts(prompts_dir: Path):
    """Создает базовые промпты"""
    # Системный промпт
    (prompts_dir / "system_prompt.txt").write_text(
        "Ты - помощник. Твоя задача помогать пользователям с их вопросами.\nБудь дружелюбным и полезным.",
        encoding="utf-8",
    )

    # Приветственное сообщение
    (prompts_dir / "welcome_message.txt").write_text("👋 Привет! Я ваш помощник.\n\nЧем могу помочь?", encoding="utf-8")

    # Финальные инструкции
    (prompts_dir / "final_instructions.txt").write_text(
        """<instruction>
КРИТИЧЕСКИ ВАЖНО: В НАЧАЛЕ КАЖДОГО своего ответа добавляй служебную информацию в формате:

{
  "этап": id,
  "качество": 1-10,
  "события": [
    {
      "тип": тип события,
      "инфо": детали события
    }
  ]
}

ДОСТУПНЫЕ ОБРАБОТЧИКИ СОБЫТИЙ:
- example_event: Пример обработчика события. Используй для демонстрации.
  Пример: {"тип": "example_event", "инфо": {"data": "пример данных"}}

ДОСТУПНЫЕ ЗАПЛАНИРОВАННЫЕ ЗАДАЧИ:
- example_task: Пример запланированной задачи. Используй для демонстрации.
  Пример: {"тип": "example_task", "инфо": "через 1 час: напомнить о чем-то"}

ДОСТУПНЫЕ ГЛОБАЛЬНЫЕ ОБРАБОТЧИКИ:
- global_announcement: Отправляет анонс всем пользователям. Используй для важных объявлений.
  Пример: {"тип": "global_announcement", "инфо": "3600"} - анонс через 1 час
  Формат: "инфо" содержит время в секундах для планирования.

Используй эти обработчики и задачи, когда это уместно в диалоге.
</instruction>""",
        encoding="utf-8",
    )


if __name__ == "__main__":
    cli()
