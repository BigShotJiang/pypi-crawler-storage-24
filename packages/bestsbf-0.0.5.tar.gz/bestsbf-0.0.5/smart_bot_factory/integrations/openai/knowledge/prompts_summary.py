"""
Краткий обзор файлов prompts/, попадающих в системный промпт: knowledge/summary.md.
При отсутствии или пустом файле — однократная генерация через OpenAI (как у роутера знаний).
"""
from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path
from typing import List

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

from ..responce_models import PromptsSummaryMarkdownModel
from .router import DEFAULT_KNOWLEDGE_ROUTER_MODEL

logger = logging.getLogger(__name__)

PROMPTS_SUMMARY_FILENAME = "summary.md"
def _excerpt_limit_chars() -> int:
    """Лимит символов на файл в запросе; 0 или меньше — без усечения."""
    raw = os.environ.get("PROMPTS_SUMMARY_EXCERPT_CHARS", "100000").strip()
    if not raw:
        return 100_000
    try:
        return int(raw)
    except ValueError:
        return 100_000

_SPECIAL_PROMPT_NAMES = frozenset(
    {
        "welcome_message.txt",
        "help_message.txt",
        "final_instructions.txt",
    },
)


def list_system_prompt_filenames(prompts_dir: Path) -> List[str]:
    """Тот же порядок имён файлов, что в ``PromptLoader._build_system_prompt``."""
    all_txt_files = list(prompts_dir.glob("*.txt"))
    prompt_files = [f.name for f in all_txt_files if f.name not in _SPECIAL_PROMPT_NAMES]
    numbered: List[str] = []
    other: List[str] = []
    for filename in prompt_files:
        if filename and filename[0].isdigit():
            numbered.append(filename)
        else:
            other.append(filename)
    numbered.sort(key=lambda x: int(x[0]))
    return numbered + sorted(other)


def _summary_file_path(bot_dir: Path) -> Path:
    return bot_dir / "knowledge" / PROMPTS_SUMMARY_FILENAME


def _resolve_summary_model(router_model: str) -> str:
    env_model = os.environ.get("PROMPTS_SUMMARY_MODEL", "").strip()
    if env_model:
        return env_model
    stripped = router_model.strip()
    if stripped:
        return stripped
    return DEFAULT_KNOWLEDGE_ROUTER_MODEL


def _build_prompts_bundle_for_llm(prompts_dir: Path) -> str:
    lines: List[str] = []
    for name in list_system_prompt_filenames(prompts_dir):
        fp = prompts_dir / name
        if not fp.is_file():
            lines.append(f"--- {name} ---\n(файл отсутствует)")
            continue
        try:
            raw = fp.read_text(encoding="utf-8")
        except OSError as err:
            logger.warning("prompts summary: не прочитать %s: %s", fp, err)
            lines.append(f"--- {name} ---\n(ошибка чтения)")
            continue
        excerpt = raw.strip()
        limit = _excerpt_limit_chars()
        if limit > 0 and len(excerpt) > limit:
            excerpt = excerpt[:limit] + "\n\n...[усечено]..."
        lines.append(f"--- {name} ---\n{excerpt}")
    return "\n\n".join(lines) if lines else "(нет файлов промптов в prompts/*.txt для системного блока)"


_SUMMARY_GEN_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """Реестр: какие смысловые блоки уже в системном промпте (источник — фрагменты во вводе). Роутеру нужно понять темы, не дублируя knowledge.
Ответ — JSON с полем markdown (русский).

Строго:
- Порядок пунктов списка = порядок файлов во вводе (сверху вниз). На каждый файл — ровно один пункт.
- Не писать имена файлов, расширения .txt и пути к каталогам — только суть блока своими словами.
- На пункт: одно короткое предложение или 10–25 слов: что задаёт блок (роль, продукт, возражения и т.д.). Можно 2 коротких оборота через точку с запятой. Без цитат и без пересказа всего текста файла.
- Запрещено: маркированные подсписки внутри строки, копипаст фраз из ввода.

В конце списка (без путей и имён файлов):
- JSON-ответ: user_message + service_info (код)
- final_instructions: да или нет; если да — одно короткое предложение что даёт (только если в метаданных «да»)
- инструменты: да или нет; если да — одно короткое предложение (только если в метаданных «да»)

Пример формы (содержание вымышленное):
- Роль бота и цели диалога; опора на внутренние знания, без выдумок
- Что за продукт, границы ответов, как использовать блоки знаний
- JSON-ответ: user_message + service_info (код)""",
        ),
        (
            "human",
            """final_instructions.txt непустой: {has_final}
описание инструментов непустое: {has_tools}

Файлы prompts/ (порядок склейки в системный промпт):

{bundle}""",
        ),
    ]
)


async def _generate_summary_markdown(
    prompts_dir: Path,
    api_key: str,
    model: str,
    has_final_instructions: bool,
    has_tools_description: bool,
) -> str:
    bundle = _build_prompts_bundle_for_llm(prompts_dir)
    gpt5_family = "gpt-5" in model.lower()
    max_completion_raw = os.environ.get("PROMPTS_SUMMARY_MAX_COMPLETION_TOKENS", "").strip()
    chat_kwargs: dict = {
        "model": model,
        "api_key": api_key,
        "temperature": 0,
        "max_retries": 2,
    }
    if gpt5_family:
        chat_kwargs["reasoning_effort"] = "minimal"
    if max_completion_raw:
        chat_kwargs["max_tokens"] = int(max_completion_raw)
    chat = ChatOpenAI(**chat_kwargs).with_structured_output(PromptsSummaryMarkdownModel)
    chain = _SUMMARY_GEN_PROMPT | chat
    result = await chain.ainvoke(
        {
            "has_final": "да" if has_final_instructions else "нет",
            "has_tools": "да" if has_tools_description else "нет",
            "bundle": bundle,
        }
    )
    return result.markdown.strip()


def _atomic_write_text(target: Path, text: str) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(
        suffix=".md",
        prefix="summary_",
        dir=str(target.parent),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(tmp, target)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


async def ensure_prompts_summary(
    bot_dir: Path,
    prompts_dir: Path,
    api_key: str,
    router_model: str,
    *,
    has_tools_description: bool,
) -> str:
    """
    Гарантирует наличие непустого ``knowledge/summary.md`` при необходимости.
    Возвращает текст для кэша в ``PromptLoader`` (может быть пустым при ошибке).
    """
    path = _summary_file_path(bot_dir)
    if path.is_file():
        try:
            existing = path.read_text(encoding="utf-8").strip()
        except OSError as err:
            logger.error("prompts summary: не прочитать %s: %s", path, err)
            existing = ""
        if existing:
            return existing

    key = str(api_key).strip()
    if not key:
        logger.debug("prompts summary: пустой API-ключ, пропуск генерации")
        return ""

    final_fp = prompts_dir / "final_instructions.txt"
    has_final_instructions = False
    if final_fp.is_file():
        try:
            has_final_instructions = bool(final_fp.read_text(encoding="utf-8").strip())
        except OSError:
            has_final_instructions = False

    model = _resolve_summary_model(router_model)
    try:
        md = await _generate_summary_markdown(
            prompts_dir,
            key,
            model,
            has_final_instructions,
            has_tools_description,
        )
    except Exception as err:
        logger.error("prompts summary: ошибка генерации: %s", err)
        return ""

    if not md.strip():
        logger.warning("prompts summary: модель вернула пустой текст")
        return ""

    try:
        _atomic_write_text(path, md.strip() + "\n")
    except OSError as err:
        logger.error("prompts summary: не записать %s: %s", path, err)
        return ""

    logger.info("prompts summary: записан %s", path)
    return md.strip()

