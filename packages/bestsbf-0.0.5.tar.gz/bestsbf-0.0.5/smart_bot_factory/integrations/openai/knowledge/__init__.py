"""Знания для OpenAI: индекс, ИИ-шапки, router, обогащение контекста."""

from __future__ import annotations

from typing import Any

from .auto_index import build_router_index_from_txt_dir, resolve_knowledge_index
from .router import DEFAULT_KNOWLEDGE_ROUTER_MODEL, KnowledgeRouterClient

__all__ = [
    "DEFAULT_KNOWLEDGE_ROUTER_MODEL",
    "KnowledgeRouterClient",
    "build_router_index_from_txt_dir",
    "get_knowledge_context_enricher",
    "get_shared_knowledge_context_enricher",
    "knowledge_langchain_system_messages_for_indices",
    "knowledge_system_messages_for_indices",
    "resolve_knowledge_index",
    "run_knowledge_router_pipeline",
    "select_knowledge_indices",
    "warmup_knowledge_cache",
]


def __getattr__(name: str) -> Any:
    if name == "get_knowledge_context_enricher":
        from .context_enricher import get_knowledge_context_enricher as fn

        return fn
    if name == "get_shared_knowledge_context_enricher":
        from .context_enricher import get_shared_knowledge_context_enricher as fn

        return fn
    if name == "warmup_knowledge_cache":
        from .context_enricher import warmup_knowledge_cache as fn

        return fn
    if name == "run_knowledge_router_pipeline":
        from .context_enricher import run_knowledge_router_pipeline as fn

        return fn
    if name == "select_knowledge_indices":
        from .context_enricher import select_knowledge_indices as fn

        return fn
    if name == "knowledge_langchain_system_messages_for_indices":
        from .context_enricher import knowledge_langchain_system_messages_for_indices as fn

        return fn
    if name == "knowledge_system_messages_for_indices":
        from .context_enricher import knowledge_system_messages_for_indices as fn

        return fn
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(
        [
            *globals().keys(),
            "get_knowledge_context_enricher",
            "get_shared_knowledge_context_enricher",
            "knowledge_langchain_system_messages_for_indices",
            "knowledge_system_messages_for_indices",
            "run_knowledge_router_pipeline",
            "select_knowledge_indices",
            "warmup_knowledge_cache",
        ]
    )
