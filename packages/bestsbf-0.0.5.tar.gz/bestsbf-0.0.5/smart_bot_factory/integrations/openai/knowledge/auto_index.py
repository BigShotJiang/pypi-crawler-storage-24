"""
Автосборка индекса знаний из YAML frontmatter в knowledge/*.txt.

Строгий формат (тело файла — всё после закрывающего ``---``):

  ---
  name: Краткий заголовок темы
  description: Сжато: суть и когда подключать (~до 220 символов); опционально «Подгружать при …».
  ---

Другие ключи во frontmatter запрещены. Легаси-шапки и context_files.md не поддерживаются.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import frontmatter
import yaml
from pydantic import ValidationError

from ..responce_models import KnowledgeTxtMetaModel

logger = logging.getLogger(__name__)


def _starts_with_yaml_frontmatter_opening(raw: str) -> bool:
    text = raw.lstrip("\ufeff")
    if not text:
        return False
    first_line = text.split("\n", 1)[0].strip()
    return first_line == "---"


def _split_yaml_frontmatter(raw: str) -> tuple[Optional[Dict[str, Any]], str]:
    """Если файл начинается с ``---``, парсит через python-frontmatter; иначе (None, raw)."""
    if not _starts_with_yaml_frontmatter_opening(raw):
        return None, raw
    try:
        post = frontmatter.loads(raw)
    except yaml.YAMLError:
        return None, raw
    meta = post.metadata
    if not isinstance(meta, dict):
        return None, raw
    return meta, post.content


def _parse_preamble(raw: str, actual_filename: str) -> Optional[KnowledgeTxtMetaModel]:
    fm_data, _body = _split_yaml_frontmatter(raw)
    if fm_data is None:
        return None
    try:
        return KnowledgeTxtMetaModel.model_validate(fm_data)
    except ValidationError as err:
        logger.debug("Пропуск %s: невалидный frontmatter: %s", actual_filename, err)
        return None


def knowledge_file_body(raw: str) -> str:
    """Тело файла — только после закрывающего ``---`` frontmatter; иначе весь текст."""
    fm_data, body = _split_yaml_frontmatter(raw)
    if fm_data is not None:
        return body.lstrip("\n")
    return raw


def _default_max_chars() -> int:
    raw = os.environ.get("KNOWLEDGE_FILE_MAX_CHARS", "8000").strip()
    try:
        return max(500, int(raw))
    except ValueError:
        return 8000


def _index_description_text(description: str) -> str:
    return " ".join(description.split())


def build_router_index_from_txt_dir(knowledge_dir: Path) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Сканирует knowledge_dir/*.txt, читает строгий YAML frontmatter, строит Markdown для router и entries.
    """
    if not knowledge_dir.is_dir():
        return "", []

    paths = sorted(p for p in knowledge_dir.glob("*.txt") if p.is_file())
    blocks: List[Tuple[Path, KnowledgeTxtMetaModel]] = []
    for path in paths:
        try:
            head = path.read_text(encoding="utf-8")
        except OSError as e:
            logger.error("Не прочитать %s: %s", path, e)
            continue
        meta = _parse_preamble(head, path.name)
        if meta is None:
            logger.debug("Пропуск %s: нет валидного YAML frontmatter (name + description)", path.name)
            continue
        blocks.append((path, meta))

    if not blocks:
        return "", []

    max_chars = _default_max_chars()
    entries: List[Dict[str, Any]] = []
    out_lines: List[str] = [
        "# Индекс файлов знаний",
        "",
        "По запросу пользователя и последним репликам диалога выбери номера блоков, которые нужно подгрузить в контекст.",
        "Ответ строго в формате JSON: `{\"indices\": [1]}` или `{\"indices\": []}`.",
        "",
        "Подгружай блок только если вопрос (или согласие вроде «да, расскажи») явно требует фактов из этого файла.",
        "",
        "---",
        "",
    ]

    for i, (path, meta) in enumerate(blocks, start=1):
        rel = f"knowledge/{path.name}"
        entries.append({"index": i, "path": rel, "max_chars": max_chars})
        desc_line = _index_description_text(meta.description)
        out_lines.append(f"## {i} — {meta.name}")
        out_lines.append("")
        out_lines.append(f"- **Файл:** `{rel}`")
        out_lines.append(f"- **Описание:** {desc_line}")
        out_lines.append("")

    return "\n".join(out_lines).strip(), entries


def resolve_knowledge_index(bot_dir: Path) -> Tuple[str, List[Dict[str, Any]]]:
    """Индекс только из knowledge/*.txt со строгим YAML frontmatter."""
    knowledge_dir = bot_dir / "knowledge"
    md, entries = build_router_index_from_txt_dir(knowledge_dir)
    if entries:
        logger.info("Индекс знаний: собран из %s файлов", len(entries))
    return md, entries
