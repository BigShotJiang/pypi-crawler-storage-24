"""
Router выбора файлов знаний по индексу (Markdown): отдельный ChatOpenAI на официальный OpenAI API
(без OpenRouter / без base_url). Инициализируется в BotBuilder рядом с LangChainOpenAIClient.

Контракт для вызывающего кода: ``index_markdown`` (сгенерированный индекс), ``dialog_snippet``,
``user_query`` → список индексов .txt. Экземпляр живёт в ``ctx.knowledge_router``; вызов
``select_indices`` идёт из ``context_enricher`` (граф и хук; корень бота — ``ctx.bot_config_dir``) — один клиент.
"""
from __future__ import annotations

import logging
import os
from typing import List, Literal

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

from ..responce_models import KnowledgeRouterIndicesModel

logger = logging.getLogger(__name__)

DEFAULT_KNOWLEDGE_ROUTER_MODEL = "gpt-5-mini"

KnowledgeRouterDialogMode = Literal["knowledge_only", "knowledge_and_rag"]

_ROUTER_HUMAN = """=== УЖЕ В БАЗОВОМ СИСТЕМНОМ ПРОМПТЕ (prompts/) ===
{prompts_summary}

=== ИНДЕКС ФАЙЛОВ (Markdown) ===
{index_markdown}

=== ПОСЛЕДНИЕ РЕПЛИКИ ДИАЛОГА ===
{dialog_snippet}

=== ПОСЛЕДНЕЕ СООБЩЕНИЕ ПОЛЬЗОВАТЕЛЯ ===
{user_query}"""

_SYSTEM_KNOWLEDGE_ONLY = """Ты роутер файлов знаний. По Markdown-индексу (номера ## 1, ## 2, …) решаешь, какие .txt подгрузить основной модели.

В этом пайплайне векторный RAG не используется — выбирай только из индекса файлов ниже.

Учитывай:
- блок «уже в базовом системном промпте» — не выбирай файлы знаний, если нужная информация уже описана там;
- полный индекс ниже;
- последние реплики диалога (согласия вроде «да, пришли», отсылки к прошлому);
- последнее сообщение пользователя.

Выбирай только индексы, которые реально нужны для ответа. Если знания не нужны — пустой список индексов."""

_SYSTEM_KNOWLEDGE_AND_RAG = """Ты роутер файлов знаний. По Markdown-индексу (номера ## 1, ## 2, …) решаешь, какие .txt подгрузить основной модели.

После твоего выбора в этом же ходе может выполняться отдельный поиск по векторной базе (RAG). Не дублируй то, что логичнее отдать RAG; если факт надёжно лежит в конкретном knowledge-файле — выбирай его индекс.

Учитывай:
- блок «уже в базовом системном промпте» — не выбирай файлы знаний, если нужная информация уже описана там;
- полный индекс ниже;
- последние реплики диалога (согласия вроде «да, пришли», отсылки к прошлому);
- последнее сообщение пользователя.

Выбирай только индексы, которые реально нужны для ответа. Если знания не нужны — пустой список индексов."""


def _router_prompt_for_mode(mode: KnowledgeRouterDialogMode) -> ChatPromptTemplate:
    system = _SYSTEM_KNOWLEDGE_AND_RAG if mode == "knowledge_and_rag" else _SYSTEM_KNOWLEDGE_ONLY
    return ChatPromptTemplate.from_messages(
        [
            ("system", system),
            ("human", _ROUTER_HUMAN),
        ]
    )


class KnowledgeRouterClient:
    """
    Клиент выбора индексов знаний. Создаётся в BotBuilder рядом с LangChainOpenAIClient.
    """

    def __init__(
        self,
        api_key: str,
        model: str,
        knowledge_dialog_mode: KnowledgeRouterDialogMode,
    ) -> None:
        self._model = model
        self._knowledge_dialog_mode = knowledge_dialog_mode
        gpt5_family = "gpt-5" in model.lower()
        chat = ChatOpenAI(
            model=model,
            api_key=api_key,
            temperature=0,
            max_tokens=256,
            max_retries=2,
            reasoning_effort="minimal" if gpt5_family else None,
        ).with_structured_output(KnowledgeRouterIndicesModel)
        self._chain = _router_prompt_for_mode(knowledge_dialog_mode) | chat
        logger.debug("KnowledgeRouterClient: model=%s, dialog_mode=%s", model, knowledge_dialog_mode)

    @classmethod
    def from_config_api_key(
        cls,
        api_key: str,
        *,
        knowledge_dialog_mode: KnowledgeRouterDialogMode,
    ) -> KnowledgeRouterClient:
        model = os.environ.get("KNOWLEDGE_ROUTER_MODEL", "").strip() or DEFAULT_KNOWLEDGE_ROUTER_MODEL
        return cls(api_key=api_key, model=model, knowledge_dialog_mode=knowledge_dialog_mode)

    async def select_indices(
        self,
        user_query: str,
        index_markdown: str,
        dialog_snippet: str,
        prompts_summary: str = "",
    ) -> List[int]:
        """Возвращает уникальные положительные индексы или [] при ошибке."""
        summary_for_prompt = (prompts_summary or "").strip()
        if not summary_for_prompt:
            summary_for_prompt = "(нет summary.md — см. knowledge/summary.md)"
        try:
            picked = await self._chain.ainvoke(
                {
                    "prompts_summary": summary_for_prompt,
                    "index_markdown": index_markdown,
                    "dialog_snippet": dialog_snippet,
                    "user_query": user_query,
                }
            )
            return _unique_positive_indices(picked.indices)
        except Exception as e:
            logger.error("Ошибка router-модели знаний: %s", e)
            return []


def _unique_positive_indices(indices: List[int]) -> List[int]:
    return list(dict.fromkeys(i for i in indices if i > 0))
