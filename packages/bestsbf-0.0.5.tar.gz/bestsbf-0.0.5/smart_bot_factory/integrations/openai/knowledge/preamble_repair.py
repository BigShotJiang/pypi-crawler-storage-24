"""
ИИ-генерация YAML frontmatter для knowledge/*.txt без валидной шапки (строго name + description).
Запись на диск: --- … --- + тело.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

import yaml
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

from ..responce_models import KnowledgeTxtMetaModel

from .auto_index import _parse_preamble, knowledge_file_body

logger = logging.getLogger(__name__)

_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """Ты помощник для оформления файлов знаний чат-бота. По фрагменту тела заполни два поля YAML frontmatter.
Ответ строго в JSON-схеме. Язык: русский.
description должен быть сжатым: для роутера, не пересказ тела.""",
        ),
        (
            "human",
            """Имя файла: {filename}

Фрагмент содержимого файла (тело):
---
{body_snippet}
---

Заполни:
- name — короткий заголовок темы для индекса (2–6 слов).
- description — одна строка, целиком не длиннее ~220 символов: в чём суть файла и при каких вопросах подключать; без перечисления всех разделов и без цитат из тела. В конце по желанию добавь коротко «Подгружать при …» (ещё 3–8 слов). Не дублируй name.""",
        ),
    ]
)


def extract_body_for_repair(raw: str) -> str:
    """После закрывающего ``---`` frontmatter; если frontmatter нет — весь текст."""
    return knowledge_file_body(raw)


def build_knowledge_txt_file(meta: KnowledgeTxtMetaModel, body: str) -> str:
    """Полный текст knowledge/*.txt: строгий YAML + тело."""
    payload = {"name": meta.name, "description": meta.description}
    fm = yaml.dump(
        payload,
        allow_unicode=True,
        default_flow_style=False,
        sort_keys=False,
    ).strip()
    body_stripped = body.lstrip("\n")
    return f"---\n{fm}\n---\n\n{body_stripped}"


def _repair_headers_enabled() -> bool:
    v = os.environ.get("KNOWLEDGE_AI_REPAIR_HEADERS", "true").strip().lower()
    return v not in ("0", "false", "no", "off")


def _body_snippet_max_chars() -> int:
    raw = os.environ.get("KNOWLEDGE_PREAMBLE_BODY_CHARS", "8000").strip()
    try:
        return max(500, int(raw))
    except ValueError:
        return 8000


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8", newline="\n")
    tmp.replace(path)


async def repair_txt_if_needed(path: Path, api_key: str, model: str) -> bool:
    """
    Если шапка невалидна — генерирует через ИИ и перезаписывает файл.
    Возвращает True, если файл был изменён.
    """
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as e:
        logger.error("Не прочитать %s: %s", path, e)
        return False

    if _parse_preamble(raw, path.name) is not None:
        return False

    body = extract_body_for_repair(raw).strip()
    if not body:
        logger.warning("Пропуск ИИ-шапки %s: пустое тело после извлечения", path.name)
        return False

    snippet = body[: _body_snippet_max_chars()]
    gpt5_family = "gpt-5" in model.lower()
    chat = ChatOpenAI(
        model=model,
        api_key=api_key,
        temperature=0,
        max_tokens=512,
        max_retries=2,
        reasoning_effort="minimal" if gpt5_family else None,
    ).with_structured_output(KnowledgeTxtMetaModel)
    chain = _PROMPT | chat

    try:
        draft = await chain.ainvoke({"filename": path.name, "body_snippet": snippet})
    except Exception as e:
        logger.error("ИИ-шапка для %s: ошибка модели: %s", path.name, e)
        return False

    if not isinstance(draft, KnowledgeTxtMetaModel):
        logger.error("ИИ-шапка для %s: неожиданный тип ответа", path.name)
        return False

    new_text = build_knowledge_txt_file(draft, body)
    try:
        _atomic_write_text(path, new_text)
    except OSError as e:
        logger.error("Не записать %s: %s", path, e)
        return False

    logger.info("ИИ добавил YAML frontmatter в knowledge/%s", path.name)
    return True


async def ensure_knowledge_preambles(knowledge_dir: Path, api_key: str, model: str) -> None:
    """Обходит knowledge/*.txt и чинит шапки через ИИ при необходимости."""
    if not _repair_headers_enabled():
        logger.debug("KNOWLEDGE_AI_REPAIR_HEADERS выключен, пропуск ИИ-шапок")
        return
    if not api_key:
        logger.warning("OPENAI_API_KEY пуст, ИИ-шапки knowledge пропущены")
        return
    if not knowledge_dir.is_dir():
        return

    for path in sorted(p for p in knowledge_dir.glob("*.txt") if p.is_file()):
        await repair_txt_if_needed(path, api_key, model)
