from __future__ import annotations

from typing import Any, Dict, List

from pydantic import BaseModel, ConfigDict, Field


class MainResponseModel(BaseModel):
    user_message: str = Field(..., description="Это текст, который отправишь пользователю.")

    service_info: Dict[str, Any] = Field(..., default_factory=dict, description="Служебная информация в json формате")


class AnalyzeSentimentResponseModel(BaseModel):
    sentiment: str = Field(..., description="Настроение клиента")
    interest_level: int = Field(..., description="Уровень заинтересованности клиента")
    purchase_readiness: int = Field(..., description="Готовность к покупке клиента")
    objections: List[str] = Field(..., description="Основные возражения или вопросы клиента")
    key_questions: List[str] = Field(..., description="Ключевые вопросы клиента")
    response_strategy: str = Field(..., description="Рекомендуемая стратегия ответа")


class GenerateFollowUpResponseModel(BaseModel):
    follow_up_message: str = Field(..., description="Следующее сообщение для отправки клиенту")
    follow_up_type: str = Field(..., description="Тип следующего сообщения")
    follow_up_data: Dict[str, Any] = Field(..., default_factory=dict, description="Данные для следующего сообщения")


class KnowledgeTxtMetaModel(BaseModel):
    """Строгий YAML frontmatter knowledge/*.txt: только name и description (парсинг и генерация ИИ)."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    name: str = Field(..., min_length=1, description="Краткий заголовок темы для индекса роутера (2–6 слов), на русском.")
    description: str = Field(
        ...,
        min_length=1,
        description=(
            "Сжатое описание для роутера: одна строка ~до 220 символов — суть файла и когда подключать; "
            "опционально хвост «Подгружать при …»; без пересказа всего содержимого."
        ),
    )


class KnowledgeRouterIndicesModel(BaseModel):
    """Выбор индексов файлов знаний (router по Markdown-индексу) для подмешивания в контекст."""

    indices: List[int] = Field(
        default_factory=list,
        description="Номера индексов из Markdown-индекса (## N); пустой список если знания не нужны.",
    )


class RagQueryPlannerDecision(BaseModel):
    """Решение планировщика: нужен ли RAG и какой запрос в векторную базу."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    needs_rag: bool = Field(..., description="True только если без векторного поиска не обойтись.")
    retrieval_query: str = Field(
        default="",
        description="Сфокусированный поисковый запрос на русском для RAG (не копипаста реплики дословно, если можно сузить).",
    )
    planner_note: str = Field(
        default="",
        description="1–2 коротких предложения по-русски: чего не хватает в промптах/выбранных знаниях и зачем ищем в базе.",
    )


class PromptsSummaryMarkdownModel(BaseModel):
    """Краткое описание базовых промптов (prompts/) для роутера знаний; пишется в knowledge/summary.md."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    markdown: str = Field(
        ...,
        min_length=1,
        description=(
            "Markdown-список по-русски: порядок пунктов = порядок файлов prompts/ во вводе; без имён файлов и путей; "
            "на каждый файл одно короткое предложение или 10–25 слов о содержании блока, без цитат; "
            "в конце строки про JSON-ответ и при необходимости final_instructions/инструменты."
        ),
    )
