"""
Граф диалога (LangGraph): сообщения в формате LangChain (SystemMessage / HumanMessage / AIMessage).

При ``include_knowledge_branch=True`` (если у бота есть ``knowledge/``): узел ``knowledge_router``
вызывает ``select_knowledge_indices``. При ``include_qdrant_rag_branch=True``: узел ``rag_query_planner``
решает, нужен ли RAG и формулирует ``rag_retrieval_query``; узел ``qdrant_rag`` вызывает полный цикл
retrieval только при непустом запросе и заполняет ``rag_query`` / ``rag_answer``. Узел ``model`` вставляет
файловые знания, при успешном RAG — краткое сообщение планировщика и чанки перед последним ``SystemMessage``.

Цепочка: ``knowledge_router`` (если есть) → ``rag_query_planner`` (если Qdrant RAG) → ``qdrant_rag`` → ``model``.

Прогрев: ``warmup_knowledge_cache``; ``ctx.bot_config_dir`` в ``_setup_context``.
"""
from __future__ import annotations

import logging
import os
from collections.abc import Mapping
from pathlib import Path
from typing import Annotated, Any, Dict, List, Optional

from langchain.messages import AIMessage, HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from pydantic import BaseModel, ConfigDict, Field

from ..utils.context import ctx

from .openai.responce_models import MainResponseModel

logger = logging.getLogger(__name__)

_QDRANT_RAG_SYSTEM_PREFIX = "Контекст из векторной базы знаний (RAG):\n\n"


def last_user_text_from_langchain_messages(messages: List[Any]) -> str:
    """Текст последнего сообщения пользователя (LangChain ``HumanMessage``)."""
    for m in reversed(messages):
        if isinstance(m, HumanMessage):
            content = m.content
            if isinstance(content, str) and content.strip():
                return content.strip()
    return ""


def _merge_service_info(left: Dict[str, Any], right: Dict[str, Any]) -> Dict[str, Any]:
    return {**left, **right}


def _index_of_last_system_message(messages: List[Any]) -> int:
    for i in range(len(messages) - 1, -1, -1):
        if isinstance(messages[i], SystemMessage):
            return i
    raise ValueError(
        "dialog graph model_node: в work нет SystemMessage; ожидается системный промпт в контексте"
    )


def _insert_knowledge_before_last_system(work: List[Any], knowledge_messages: List[Any]) -> None:
    """Вставляет ``knowledge_messages`` перед последним ``SystemMessage`` в ``work`` (на месте)."""
    if not knowledge_messages:
        return
    insert_at = _index_of_last_system_message(work)
    for km in reversed(knowledge_messages):
        work.insert(insert_at, km)


class DialogPipelineState(BaseModel):
    """Состояние пайплайна: диалог (LangChain), service_info, индексы знаний, RAG."""

    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    messages: Annotated[list[Any], add_messages] = Field(default_factory=list)
    last_main_response: Optional[MainResponseModel] = Field(
        default=None,
        description="Последний ответ основной модели; заполняет узел model.",
    )
    user_message: str = Field(
        default="",
        description="Текст для пользователя с последнего шага основной модели (дублирует user_message из ответа).",
    )
    service_info: Annotated[Dict[str, Any], _merge_service_info] = Field(default_factory=dict)
    indices: Optional[List[int]] = Field(
        default=None,
        description="Индексы выбранных файлов знаний; задаёт узел knowledge_router.",
    )
    rag_retrieval_query: Optional[str] = Field(
        default=None,
        description="Запрос в RAG от планировщика; None/пусто — полный пропуск цепочки retrieval.",
    )
    rag_planner_note: Optional[str] = Field(
        default=None,
        description="Краткая заметка планировщика для системного сообщения перед чанками RAG.",
    )
    rag_query: Optional[str] = Field(
        default=None,
        description="Фактически использованный запрос retrieval (дублирует rag_retrieval_query при успехе).",
    )
    rag_answer: Optional[str] = Field(
        default=None,
        description="Собранный контекст RAG; None если retrieval не выполнялся или не дал чанков.",
    )


_DIALOG_PIPELINE_STATE_KEYS = frozenset(DialogPipelineState.model_fields.keys())


def dialog_pipeline_state_from_ainvoke(invoke_result: object) -> DialogPipelineState:
    """
    Normalize ``CompiledGraph.ainvoke`` output to ``DialogPipelineState``.

    LangGraph may return a plain dict with extra keys; only fields of ``DialogPipelineState`` are kept.
    """
    if isinstance(invoke_result, DialogPipelineState):
        return invoke_result
    if not isinstance(invoke_result, Mapping):
        raise TypeError(
            f"dialog_pipeline_state_from_ainvoke: expected DialogPipelineState or mapping, got {type(invoke_result)!r}"
        )
    filtered = {k: invoke_result[k] for k in _DIALOG_PIPELINE_STATE_KEYS if k in invoke_result}
    return DialogPipelineState.model_validate(filtered)


def create_dialog_pipeline_graph(
    *,
    include_knowledge_branch: bool = False,
    include_qdrant_rag_branch: bool = False,
):
    """
    Собирает граф. Перед ``model``: ``knowledge_router`` (опционально), ``rag_query_planner`` и ``qdrant_rag``
    при включённом Qdrant RAG.
    """

    async def knowledge_router_node(state: DialogPipelineState) -> Dict[str, Any]:
        from .openai.knowledge.context_enricher import select_knowledge_indices

        selected = await select_knowledge_indices(state.messages)
        if not selected:
            return {}
        logger.debug("dialog graph: knowledge_router — индексы=%s", selected)
        return {"indices": selected}

    async def rag_query_planner_node(state: DialogPipelineState) -> Dict[str, Any]:
        from .openai.knowledge.auto_index import resolve_knowledge_index
        from .openai.knowledge.context_enricher import (
            DEFAULT_ROUTER_HISTORY_MESSAGES,
            dialog_snippet_from_langchain_messages,
            knowledge_storage_key_from_bot_dir_and_id,
            _prompts_summary_for_router,
        )

        from ..rag.qdrant.query_planner import build_selected_knowledge_topics_block

        bot_dir = ctx.bot_config_dir
        if bot_dir is None:
            logger.warning("dialog graph: rag_query_planner — нет ctx.bot_config_dir")
            return {}
        user_q = last_user_text_from_langchain_messages(state.messages)
        if not user_q.strip():
            return {}

        raw_disabled = os.environ.get("RAG_QUERY_PLANNER_DISABLED", "").strip().lower()
        if raw_disabled in ("true", "1", "yes"):
            logger.debug("dialog graph: rag_query_planner — отключён (RAG_QUERY_PLANNER_DISABLED)")
            return {"rag_retrieval_query": user_q.strip(), "rag_planner_note": None}

        planner = getattr(ctx, "rag_query_planner", None)
        if planner is None:
            logger.debug("dialog graph: rag_query_planner — клиент отсутствует, fallback на последнюю реплику")
            return {"rag_retrieval_query": user_q.strip(), "rag_planner_note": None}

        cfg = ctx.config
        bid = getattr(cfg, "BOT_ID", "") if cfg is not None else ""
        cache_key = knowledge_storage_key_from_bot_dir_and_id(Path(bot_dir), str(bid))
        pl = ctx.prompt_loader
        index_md = ""
        if pl is not None and pl.has_knowledge_cache(cache_key):
            index_md = pl.knowledge_index_markdown(cache_key)
        else:
            index_md, _ = resolve_knowledge_index(Path(bot_dir))
        prompts_summary = _prompts_summary_for_router(Path(bot_dir), cache_key)
        indices = list(state.indices) if state.indices else []
        topics_block = build_selected_knowledge_topics_block(indices, index_md)
        history_n = int(os.environ.get("KNOWLEDGE_ROUTER_HISTORY_MESSAGES", DEFAULT_ROUTER_HISTORY_MESSAGES))
        dialog_snippet = dialog_snippet_from_langchain_messages(state.messages, history_n)

        try:
            decision = await planner.plan(
                user_query=user_q,
                dialog_snippet=dialog_snippet,
                prompts_summary=prompts_summary,
                index_markdown=index_md,
                selected_knowledge_topics=topics_block,
            )
        except Exception as e:
            logger.error("dialog graph: rag_query_planner — ошибка LLM: %s", e)
            return {}

        if not decision.needs_rag or not decision.retrieval_query.strip():
            logger.debug("dialog graph: rag_query_planner — RAG не требуется")
            return {}

        note = decision.planner_note.strip()
        return {
            "rag_retrieval_query": decision.retrieval_query.strip(),
            "rag_planner_note": note if note else None,
        }

    async def qdrant_rag_node(state: DialogPipelineState) -> Dict[str, Any]:
        retriever = getattr(ctx, "qdrant_rag_retriever", None)
        if retriever is None:
            return {}
        question = (state.rag_retrieval_query or "").strip()
        if not question:
            return {}
        try:
            chunks = await retriever.aretrieve(question)
        except Exception as e:
            logger.error("dialog graph: qdrant_rag — ошибка retrieval: %s", e)
            return {}
        if not chunks:
            return {}
        merged = "\n\n---\n\n".join(chunks)
        logger.debug("dialog graph: qdrant_rag — чанков=%s", len(chunks))
        return {"rag_query": question, "rag_answer": merged}

    async def model_node(state: DialogPipelineState) -> Dict[str, Any]:
        work = state.messages.copy()
        if state.indices:
            from .openai.knowledge.context_enricher import knowledge_langchain_system_messages_for_indices

            extra = await knowledge_langchain_system_messages_for_indices(state.indices)
            _insert_knowledge_before_last_system(work, extra)
        if state.rag_answer is not None and state.rag_answer.strip():
            planner_parts: List[str] = []
            if state.rag_planner_note and state.rag_planner_note.strip():
                planner_parts.append(state.rag_planner_note.strip())
            rq = (state.rag_retrieval_query or state.rag_query or "").strip()
            if rq:
                planner_parts.append(f"Поисковый запрос к базе: {rq}")
            if planner_parts:
                planner_sys = SystemMessage(
                    content="Решение планировщика RAG:\n\n" + "\n\n".join(planner_parts),
                )
                _insert_knowledge_before_last_system(work, [planner_sys])
            rag_msg = SystemMessage(content=_QDRANT_RAG_SYSTEM_PREFIX + state.rag_answer.strip())
            _insert_knowledge_before_last_system(work, [rag_msg])

        response = await ctx.openai_client.get_completion(work)  # type: ignore[union-attr]
        logger.debug("dialog graph: model node завершён")
        return {
            "messages": [AIMessage(content=response.user_message)],
            "last_main_response": response,
            "user_message": response.user_message,
            "service_info": dict(response.service_info or {}),
        }

    graph = StateGraph(DialogPipelineState)
    graph.add_node("model", model_node)
    if include_qdrant_rag_branch:
        graph.add_node("qdrant_rag", qdrant_rag_node)
        graph.add_node("rag_query_planner", rag_query_planner_node)
    if include_knowledge_branch:
        graph.add_node("knowledge_router", knowledge_router_node)

    prev = START
    if include_knowledge_branch:
        graph.add_edge(prev, "knowledge_router")
        prev = "knowledge_router"
    if include_qdrant_rag_branch:
        graph.add_edge(prev, "rag_query_planner")
        graph.add_edge("rag_query_planner", "qdrant_rag")
        prev = "qdrant_rag"
    graph.add_edge(prev, "model")
    graph.add_edge("model", END)
    return graph.compile()
