from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from aiogram import Bot, Dispatcher

    from ..admin.admin_manager import AdminManager
    from ..analytics.analytics_manager import AnalyticsManager
    from ..config import Config
    from ..event.router_manager import RouterManager
    from ..integrations.openai.knowledge import KnowledgeRouterClient
    from ..integrations.openai.langchain_openai import LangChainOpenAIClient
    from ..integrations.openai.prompt_loader import PromptLoader
    from ..integrations.supabase_client import SupabaseClient
    from ..memory.memory_manager import MemoryManager
    from ..utils.conversation_manager import ConversationManager


class AppContext:
    def __init__(self):
        self.config: Optional[Config] = None
        # Корень конфигурации бота (prompts, knowledge/); для LangGraph и обогатителей.
        self.bot_config_dir: Optional[Path] = None
        self.supabase_client: Optional[SupabaseClient] = None
        self.openai_client: Optional[LangChainOpenAIClient] = None
        self.knowledge_router: Optional["KnowledgeRouterClient"] = None
        self.prompt_loader: Optional[PromptLoader] = None
        self.conversation_manager: Optional[ConversationManager] = None
        self.admin_manager: Optional[AdminManager] = None
        self.analytics_manager: Optional[AnalyticsManager] = None
        self.memory_manager: Optional[MemoryManager] = None
        self.router_manager: Optional[RouterManager] = None
        self.message_hooks: Dict[str, Any] = {}
        self.tools_prompt: str = ""
        self.start_handlers: List[Any] = []
        self.rag_pipeline: Optional[Any] = None  # ParserRagPipeline для /refresh_rag
        self.utm_triggers: List[Any] = []
        self.custom_event_processor = None  # Кастомный процессор событий
        self.custom_event_proceses = None  # DEPRECATED: используйте custom_event_processor
        self.bot: Optional[Bot] = None
        self.dp: Optional[Dispatcher] = None
        # Скомпилированный LangGraph диалога (BotBuilder.build → _setup_context).
        self.dialog_pipeline_app: Optional[Any] = None
        # Опционально: Qdrant-native RAG (Qdrant + Voyage), extra qdrant-rag; не путать с Supabase vector RAG.
        self.qdrant_rag_retriever: Optional[Any] = None
        # Планировщик запроса в Qdrant RAG (LangGraph: rag_query_planner → qdrant_rag).
        self.rag_query_planner: Optional[Any] = None


# глобальный, но единственный объект-контейнер
ctx = AppContext()
