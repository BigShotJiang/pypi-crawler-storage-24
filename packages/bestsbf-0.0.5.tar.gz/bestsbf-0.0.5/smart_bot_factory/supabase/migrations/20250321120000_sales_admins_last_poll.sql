-- Опросы: ссылка на «оригинальное» сообщение-опрос бота (для пересылки статистики админу).
-- В проекте таблица админов называется sales_admins (см. sync_admin в supabase_client).

ALTER TABLE sales_admins
ADD COLUMN IF NOT EXISTS last_poll_chat_id BIGINT,
ADD COLUMN IF NOT EXISTS last_poll_message_id BIGINT;
