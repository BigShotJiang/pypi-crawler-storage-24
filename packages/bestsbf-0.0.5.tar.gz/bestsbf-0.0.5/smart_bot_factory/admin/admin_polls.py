"""
Рассылка опросов: send_poll в личку админа с ботом → forward_message всем пользователям (единый poll_id).
"""

import asyncio
import logging
from typing import List

from aiogram import F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from postgrest.exceptions import APIError

from ..utils.context import ctx
from .states import AdminStates

logger = logging.getLogger(__name__)

# Выполнить в Supabase → SQL Editor, если колонок ещё нет (см. smart_bot_factory/supabase/migrations/)
POLL_DB_MIGRATION_SQL = (
    "ALTER TABLE sales_admins\n"
    "ADD COLUMN IF NOT EXISTS last_poll_chat_id BIGINT,\n"
    "ADD COLUMN IF NOT EXISTS last_poll_message_id BIGINT;"
)


def _is_missing_last_poll_columns_error(err: BaseException) -> bool:
    s = str(err).lower()
    return "last_poll_chat_id" in s and "does not exist" in s

poll_router = Router(name="admin_polls")

# Лимиты Telegram для опросов
POLL_QUESTION_MAX = 300
POLL_OPTION_MAX = 100
POLL_OPTIONS_MIN = 2
POLL_OPTIONS_MAX = 10

FORWARD_DELAY_SEC = 0.035


def _parse_poll_options(text: str) -> List[str]:
    lines = [ln.strip() for ln in text.strip().splitlines() if ln.strip()]
    return lines[:POLL_OPTIONS_MAX]


def _validate_question(q: str) -> str | None:
    s = q.strip()
    if not s:
        return "Вопрос не может быть пустым."
    if len(s) > POLL_QUESTION_MAX:
        return f"Вопрос длиннее {POLL_QUESTION_MAX} символов."
    return None


def _validate_options(opts: List[str]) -> str | None:
    if len(opts) < POLL_OPTIONS_MIN:
        return f"Нужно минимум {POLL_OPTIONS_MIN} варианта (каждый с новой строки)."
    if len(opts) > POLL_OPTIONS_MAX:
        return f"Не больше {POLL_OPTIONS_MAX} вариантов."
    for i, o in enumerate(opts):
        if len(o) > POLL_OPTION_MAX:
            return f"Вариант {i + 1} длиннее {POLL_OPTION_MAX} символов."
    return None


async def _filtered_broadcast_users():
    users = await ctx.supabase_client.get_users_by_segment(None)
    current_bot_id = ctx.supabase_client.bot_id
    out = []
    for user in users:
        tid = user["telegram_id"]
        if ctx.admin_manager.is_admin(tid):
            continue
        if user.get("username") == "test_user":
            continue
        if current_bot_id and user.get("bot_id") is not None and user.get("bot_id") != current_bot_id:
            continue
        out.append(tid)
    return out


@poll_router.message(Command(commands=["create_poll", "создать_опрос", "опрос"]))
async def cmd_create_poll(message: Message, state: FSMContext):
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return
    if not ctx.admin_manager.is_in_admin_mode(message.from_user.id):
        await message.answer("Включите режим администратора: /admin")
        return
    await state.set_state(AdminStates.create_poll_question)
    await message.answer(
        "📊 Новый опрос\n\n"
        "Отправьте текст вопроса (до 300 символов).\n"
        "Отмена: /cancel",
    )


@poll_router.message(StateFilter(AdminStates.create_poll_question), F.text)
async def poll_question_received(message: Message, state: FSMContext):
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return
    if message.text and message.text.startswith("/"):
        return
    err = _validate_question(message.text or "")
    if err:
        await message.answer(err)
        return
    await state.update_data(poll_question=message.text.strip())
    await state.set_state(AdminStates.create_poll_options)
    await message.answer(
        "Теперь отправьте варианты ответа — каждый с новой строки.\n"
        f"От {POLL_OPTIONS_MIN} до {POLL_OPTIONS_MAX} вариантов, до {POLL_OPTION_MAX} символов каждый.\n\n"
        "Отмена: /cancel",
    )


@poll_router.message(StateFilter(AdminStates.create_poll_options), F.text)
async def poll_options_received(message: Message, state: FSMContext):
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return
    if message.text and message.text.startswith("/"):
        return
    opts = _parse_poll_options(message.text or "")
    err = _validate_options(opts)
    if err:
        await message.answer(err)
        return
    data = await state.get_data()
    question = data.get("poll_question") or ""
    await state.update_data(poll_options=opts)
    await state.set_state(AdminStates.create_poll_confirm)
    preview = "\n".join(f"{i + 1}. {o}" for i, o in enumerate(opts))
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Разослать", callback_data="poll_send"),
                InlineKeyboardButton(text="❌ Отмена", callback_data="poll_cancel"),
            ]
        ]
    )
    await message.answer(
        f"Вопрос:\n{question}\n\nВарианты:\n{preview}\n\n"
        "Подтвердите рассылку всем пользователям бота (кроме админов и test_user).",
        reply_markup=kb,
    )


@poll_router.callback_query(F.data.in_({"poll_send", "poll_cancel"}), StateFilter(AdminStates.create_poll_confirm))
async def poll_confirm_callback(callback: CallbackQuery, state: FSMContext):
    if not ctx.admin_manager.is_admin(callback.from_user.id):
        await callback.answer("Нет доступа")
        return

    if callback.data == "poll_cancel":
        await state.clear()
        await state.set_state(AdminStates.admin_mode)
        await callback.message.edit_text("Создание опроса отменено.")
        await callback.answer()
        return

    if not ctx.bot:
        await callback.answer("Бот недоступен")
        return

    data = await state.get_data()
    question = data.get("poll_question")
    options = data.get("poll_options")
    if not question or not options:
        await callback.answer("Данные опроса потеряны, начните сначала: /create_poll")
        return

    await callback.answer()
    await callback.message.edit_text("⏳ Публикую опрос и выполняю рассылку…")

    admin_chat_id = callback.from_user.id

    try:
        poll_msg = await ctx.bot.send_poll(
            chat_id=admin_chat_id,
            question=question,
            options=options,
            is_anonymous=True,
        )
    except Exception as e:
        logger.exception("send_poll в ЛС админа не удался: %s", e)
        await callback.message.answer(
            "❌ Не удалось отправить опрос в ваш личный чат с ботом. "
            "Напишите боту /start в ЛС и повторите попытку. "
            f"Ошибка: {e!s}"
        )
        await state.clear()
        await state.set_state(AdminStates.admin_mode)
        return

    from_chat_id = poll_msg.chat.id
    message_id = poll_msg.message_id
    admin_id = admin_chat_id

    poll_db_columns_missing = False
    try:
        await ctx.supabase_client.set_admin_last_poll(admin_id, from_chat_id, message_id)
    except Exception as e:
        logger.error("Не удалось сохранить last_poll в БД: %s", e)
        poll_db_columns_missing = _is_missing_last_poll_columns_error(e)

    user_ids = await _filtered_broadcast_users()
    ok, fail = 0, 0
    for uid in user_ids:
        try:
            await ctx.bot.forward_message(chat_id=uid, from_chat_id=from_chat_id, message_id=message_id)
            ok += 1
        except Exception as ex:
            fail += 1
            logger.debug("forward опроса пользователю %s: %s", uid, ex)
        await asyncio.sleep(FORWARD_DELAY_SEC)

    await state.clear()
    await state.set_state(AdminStates.admin_mode)

    tail = (
        "Голоса агрегируются в исходном опросе в этом чате с ботом (выше). "
        "Повторно прислать опрос с актуальными цифрами: /poll_stats."
    )
    if poll_db_columns_missing:
        tail += (
            "\n\n⚠️ Ссылку на опрос в БД сохранить не удалось: нет колонок last_poll_* в sales_admins. "
            "Выполните в Supabase SQL Editor:\n\n"
            f"{POLL_DB_MIGRATION_SQL}"
        )

    await callback.message.answer(
        f"✅ Опрос разослан.\n"
        f"Получателей в базе: {len(user_ids)}\n"
        f"Успешно переслано: {ok}\n"
        f"Ошибок: {fail}\n\n"
        f"{tail}",
    )


@poll_router.message(Command(commands=["poll_stats", "стат_опрос", "результаты_опроса"]))
async def cmd_poll_stats(message: Message):
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return
    if not ctx.bot:
        await message.answer("Бот недоступен")
        return

    try:
        row = await ctx.supabase_client.get_admin_last_poll(message.from_user.id)
    except APIError as e:
        if _is_missing_last_poll_columns_error(e):
            await message.answer(
                "В таблице sales_admins нет колонок для опросов (last_poll_chat_id / last_poll_message_id).\n\n"
                "Откройте Supabase → SQL Editor и выполните:\n\n"
                f"{POLL_DB_MIGRATION_SQL}"
            )
            return
        raise
    if not row:
        await message.answer(
            "Нет сохранённого опроса для вашего админ-аккаунта. Создайте опрос: /create_poll"
        )
        return

    try:
        await ctx.bot.forward_message(
            chat_id=message.chat.id,
            from_chat_id=int(row["last_poll_chat_id"]),
            message_id=int(row["last_poll_message_id"]),
        )
        await message.answer(
            "Выше — пересланный опрос с текущими результатами голосования (Telegram считает голоса сам)."
        )
    except Exception as e:
        logger.exception("poll_stats forward: %s", e)
        await message.answer(
            f"Не удалось переслать опрос (возможно, сообщение удалено или недоступно). Ошибка: {e!s}"
        )


# Снятие подсветки кнопок, если пользователь нажал после смены состояния
@poll_router.callback_query(F.data.in_({"poll_send", "poll_cancel"}))
async def poll_stale_callback(callback: CallbackQuery):
    await callback.answer("Это меню устарело. Начните снова: /create_poll", show_alert=True)
