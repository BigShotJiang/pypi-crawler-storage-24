import logging
import re
import time
from collections import defaultdict, deque
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import Message, TelegramObject

from ..utils.context import ctx

logger = logging.getLogger(__name__)

MAX_MESSAGES = 3
WINDOW_SECONDS = 10


class RateLimitMiddleware(BaseMiddleware):
    """Middleware: rate-limit по user_id + игнорирование не-текстовых сообщений."""

    def __init__(self):
        super().__init__()
        self._timestamps: dict[int, deque[float]] = defaultdict(deque)

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        if not isinstance(event, Message) or not event.from_user:
            return await handler(event, data)

        # Пропускаем только текст и команды; всё остальное игнорируем
        if not event.text:
            logger.debug(f"🚫 Игнорируем не-текстовое сообщение от {event.from_user.id}")
            return

        if event.text.startswith("/"):
            return await handler(event, data)

        # Игнорируем сообщения без букв/цифр (emoji, стикеры-текст и т.д.)
        if not re.search(r"\w", event.text):
            logger.debug(f"🚫 Игнорируем emoji-сообщение от {event.from_user.id}: '{event.text}'")
            return

        # Админов не лимитируем
        if ctx.admin_manager and ctx.admin_manager.is_admin(event.from_user.id):
            return await handler(event, data)

        # Rate limit
        now = time.monotonic()
        uid = event.from_user.id
        q = self._timestamps[uid]

        while q and q[0] <= now - WINDOW_SECONDS:
            q.popleft()

        if len(q) >= MAX_MESSAGES:
            logger.warning(f"🛑 Rate limit: пользователь {uid} превысил {MAX_MESSAGES} сообщений за {WINDOW_SECONDS}с")
            return

        q.append(now)
        return await handler(event, data)
