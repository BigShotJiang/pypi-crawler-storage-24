from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject

from ..utils.context import ctx


class AdminMiddleware(BaseMiddleware):
    """Middleware для обновления информации об админах"""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        """Обработка middleware"""
        from_user = getattr(event, "from_user", None)
        if from_user is not None and ctx.admin_manager is not None:
            if ctx.admin_manager.is_admin(from_user.id):
                await ctx.admin_manager.update_admin_info(from_user)

        return await handler(event, data)
