from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

from ..utils.tool_router import ToolRouter
from .decorators.db import save_immediate_event

logger = logging.getLogger(__name__)


event_tool_router = ToolRouter(name="events")


@event_tool_router.tool
async def create_immediate_event(
    event_type: str,
    user_id: int,
    session_id: Optional[str] = None,
    event_data: Dict[str, Any] | None = None,
) -> str:
    """
    Инструмент create_immediate_event.

    Создаёт немедленное пользовательское событие в таблице scheduled_events.
    Параметры:
    - event_type: тип события (например, "collect_contact" или "bot_feedback")
    - user_id: ID пользователя
    - session_id: опциональный ID сессии
    - event_data: словарь с данными события (контакты, текст отзыва и т.п.)

    Возвращает ID созданного события.
    """

    data = event_data or {}
    try:
        data_str = json.dumps(data, ensure_ascii=False)
    except TypeError:
        # На всякий случай приводим к строке, если что-то не сериализуется в JSON
        data_str = str(data)

    event_id = await save_immediate_event(
        event_type=event_type,
        user_id=user_id,
        event_data=data_str,
        session_id=session_id,
    )

    logger.info(
        "📝 Инструмент create_immediate_event создал событие %s (type=%s, user_id=%s, session_id=%s)",
        event_id,
        event_type,
        user_id,
        session_id,
    )

    return event_id

