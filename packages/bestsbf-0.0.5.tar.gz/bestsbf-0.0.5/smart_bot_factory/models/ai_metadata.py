"""
Pydantic модели для метаданных AI и событий.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class EventData(BaseModel):
    """Модель для события от AI."""

    тип: Optional[str] = Field(None, description="Тип события (например, 'запись_на_консультацию')")
    инфо: Optional[str] = Field(None, description="Дополнительная информация о событии")

    event_type: Optional[str] = Field(None, description="Альтернативное название для 'тип'")
    event_info: Optional[str] = Field(None, description="Альтернативное название для 'инфо'")

    model_config = {"extra": "allow"}

    @model_validator(mode="before")
    @classmethod
    def fill_type_from_alias(cls, data: Any) -> Any:
        if isinstance(data, dict):
            if not data.get("тип") and data.get("event_type"):
                data = {**data, "тип": data["event_type"]}
            if data.get("инфо") is None and data.get("event_info") is not None:
                data = {**data, "инфо": data["event_info"]}
        return data

    @field_validator("тип", mode="before")
    @classmethod
    def normalize_type(cls, v: Any) -> Any:
        if v is not None and v != "":
            return v.strip().lower() if isinstance(v, str) else v
        return v


class FileEventData(BaseModel):
    """Модель для файлового события."""

    тип: str = Field(..., description="Тип файлового события (например, 'отправить_прайс')")
    инфо: Optional[str] = Field(None, description="Дополнительная информация")
    timing: Optional[str] = Field("after", description="Когда отправлять: before, with_message, after")

    model_config = {"extra": "allow"}


class AIMetadata(BaseModel):
    """Модель для метаданных ответа AI."""

    этап: Optional[str] = Field(None, alias="stage", description="Текущий этап диалога")
    качество: Optional[int] = Field(None, alias="quality", description="Оценка качества лида (0-10)")
    события: List[EventData] = Field(default_factory=list, alias="events", description="Список событий")
    файловые_события: List[FileEventData] = Field(default_factory=list, alias="file_events", description="Список файловых событий")
    service_info: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Служебная информация от OpenAI")

    model_config = {"populate_by_name": True, "extra": "allow"}

    @field_validator("качество", mode="before")
    @classmethod
    def validate_quality(cls, v: Any) -> Optional[int]:
        if v is None:
            return None
        try:
            quality = int(v)
            if quality < 0 or quality > 10:
                return None
            return quality
        except (ValueError, TypeError):
            return None

    @field_validator("события", mode="before")
    @classmethod
    def parse_events(cls, v: Any) -> List[EventData]:
        if not v:
            return []
        if isinstance(v, list):
            return [EventData(**item) if isinstance(item, dict) else item for item in v]
        return []

    def to_dict(self) -> Dict[str, Any]:
        """Конвертация в словарь (для обратной совместимости)."""
        result: Dict[str, Any] = {}

        if self.этап is not None:
            result["этап"] = self.этап
        if self.качество is not None:
            result["качество"] = self.качество
        if self.события:
            result["события"] = [{"тип": e.тип, "инфо": e.инфо} for e in self.события]
        if self.файловые_события:
            result["файловые_события"] = [{"тип": e.тип, "инфо": e.инфо, "timing": e.timing} for e in self.файловые_события]
        if self.service_info:
            result["service_info"] = self.service_info

        extra = getattr(self, "model_extra", None) or {}
        for key, value in extra.items():
            result[key] = value

        return result


class SessionInfo(BaseModel):
    """Модель информации о сессии."""

    id: str = Field(..., description="ID сессии")
    user_id: int = Field(..., description="ID пользователя")
    current_stage: Optional[str] = Field(None, description="Текущий этап")
    lead_quality: Optional[int] = Field(None, ge=0, le=10, description="Качество лида")
    created_at: str = Field(..., description="Дата создания")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Дополнительные данные")
    summary: Optional[str] = Field(None, description="Суммаризация истории")
    messages_len: int = Field(default=0, description="Количество сообщений")

    model_config = {"extra": "allow"}


class Message(BaseModel):
    """Модель сообщения."""

    role: str = Field(..., description="Роль: user, assistant, system")
    content: str = Field(..., description="Содержимое сообщения")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Метаданные сообщения")

    model_config = {"extra": "allow"}
