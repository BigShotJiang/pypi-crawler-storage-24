"""
Утилиты для работы с моделями.
"""

from typing import Any, Dict

from .ai_metadata import AIMetadata, EventData


def parse_ai_metadata_safe(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Безопасный парсинг метаданных AI с fallback на старый формат.

    Args:
        data: Словарь с метаданными

    Returns:
        Валидированный словарь метаданных
    """
    if not isinstance(data, dict):
        return data
    try:
        metadata_obj = AIMetadata(**data)
        return metadata_obj.to_dict()
    except Exception:
        return data


def validate_event(event: Dict[str, Any]) -> EventData:
    """
    Валидация отдельного события.

    Args:
        event: Словарь с данными события

    Returns:
        Объект EventData
    """
    return EventData(**event)
