from __future__ import annotations

import logging
import uuid
import warnings
from collections import OrderedDict
from itertools import repeat
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    List,
    Optional,
    Tuple,
    Type,
    Union,
)

import numpy as np
from langchain_community.vectorstores.utils import maximal_marginal_relevance
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore

if TYPE_CHECKING:
    import supabase


class SupabaseVectorStore(VectorStore):
    """`Supabase Postgres` vector store.

    It assumes you have the `pgvector`
    extension installed and a `match_documents` (or similar) function. For more details:
    https://integrations.langchain.com/vectorstores?integration_name=SupabaseVectorStore

    You can implement your own `match_documents` function in order to limit the search
    space to a subset of documents based on your own authorization or business logic.

    Note that the Supabase Python client does not yet support async operations.

    If you'd like to use `max_marginal_relevance_search`, please review the instructions
    below on modifying the `match_documents` function to return matched embeddings.


    Examples:

    .. code-block:: python

        from langchain_community.embeddings.openai import OpenAIEmbeddings
        from langchain_core.documents import Document
        from langchain_community.vectorstores import SupabaseVectorStore
        from supabase.client import create_client

        docs = [
            Document(page_content="foo", metadata={"id": 1}),
        ]
        embeddings = OpenAIEmbeddings()
        supabase_client = create_client("my_supabase_url", "my_supabase_key")
        vector_store = SupabaseVectorStore.from_documents(
            docs,
            embeddings,
            client=supabase_client,
            table_name="documents",
            query_name="match_documents",
            chunk_size=500,
        )

    To load from an existing table:

    .. code-block:: python

        from langchain_community.embeddings.openai import OpenAIEmbeddings
        from langchain_community.vectorstores import SupabaseVectorStore
        from supabase.client import create_client


        embeddings = OpenAIEmbeddings()
        supabase_client = create_client("my_supabase_url", "my_supabase_key")
        vector_store = SupabaseVectorStore(
            client=supabase_client,
            embedding=embeddings,
            table_name="documents",
            query_name="match_documents",
        )

    """

    def __init__(
        self,
        client: supabase.client.Client,
        embedding: Embeddings,
        table_name: str,
        chunk_size: int = 500,
        query_name: Union[str, None] = None,
        keyword_query_name: Union[str, None] = None,
        use_bm25_hybrid: bool = False,
    ) -> None:
        """Initialize with supabase client."""
        try:
            import supabase  # noqa: F401
        except ImportError:
            raise ImportError("Could not import supabase python package. Please install it with `pip install supabase`.")

        self._client = client
        self._embedding: Embeddings = embedding
        self.table_name = table_name or "documents"
        self.query_name = query_name or "match_documents"
        # Та же функция для keyword поиска, но с другими параметрами (перегрузка в PostgreSQL)
        self.keyword_query_name = keyword_query_name or (query_name or "match_documents")
        self.chunk_size = chunk_size or 500
        self.use_bm25_hybrid = use_bm25_hybrid
        # According to the SupabaseVectorStore JS implementation, the best chunk size
        # is 500. Though for large datasets it can be too large so it is configurable.

    @property
    def embeddings(self) -> Embeddings:
        return self._embedding

    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[Dict[Any, Any]]] = None,
        ids: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> List[str]:
        ids = ids or [str(uuid.uuid4()) for _ in texts]
        docs = self._texts_to_documents(texts, metadatas)

        vectors = self._embedding.embed_documents(list(texts))
        return self.add_vectors(vectors, docs, ids)

    @classmethod
    def from_texts(
        cls: Type["SupabaseVectorStore"],
        texts: List[str],
        embedding: Embeddings,
        metadatas: Optional[List[dict]] = None,
        client: Optional[supabase.client.Client] = None,
        table_name: Optional[str] = "documents",
        query_name: Union[str, None] = "match_documents",
        chunk_size: int = 500,
        ids: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> "SupabaseVectorStore":
        """Return VectorStore initialized from texts and embeddings."""

        if not client:
            raise ValueError("Supabase client is required.")

        if not table_name:
            raise ValueError("Supabase document table_name is required.")

        embeddings = embedding.embed_documents(texts)
        ids = [str(uuid.uuid4()) for _ in texts]
        docs = cls._texts_to_documents(texts, metadatas)
        cls._add_vectors(client, table_name, embeddings, docs, ids, chunk_size, **kwargs)

        return cls(
            client=client,
            embedding=embedding,
            table_name=table_name,
            query_name=query_name,
            chunk_size=chunk_size,
        )

    def add_vectors(
        self,
        vectors: List[List[float]],
        documents: List[Document],
        ids: List[str],
    ) -> List[str]:
        return self._add_vectors(self._client, self.table_name, vectors, documents, ids, self.chunk_size)

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        vector = self._embedding.embed_query(query)
        return self.similarity_search_by_vector(vector, k=k, filter=filter, **kwargs)

    def similarity_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        result = self.similarity_search_by_vector_with_relevance_scores(embedding, k=k, filter=filter, **kwargs)

        documents = [doc for doc, _ in result]

        return documents

    def similarity_search_with_relevance_scores(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        vector = self._embedding.embed_query(query)
        return self.similarity_search_by_vector_with_relevance_scores(vector, k=k, filter=filter, **kwargs)

    def match_args(self, query: List[float], filter: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        ret: Dict[str, Any] = dict(query_embedding=query)
        if filter:
            ret["filter"] = filter
        return ret

    def similarity_search_by_vector_with_relevance_scores(
        self,
        query: List[float],
        k: int,
        filter: Optional[Dict[str, Any]] = None,
        postgrest_filter: Optional[str] = None,
        score_threshold: Optional[float] = None,
    ) -> List[Tuple[Document, float]]:
        """
        Поиск документов по вектору с возможностью фильтрации и порога релевантности.
        """

        # Преобразуем MongoDB-style filter в PostgreSQL IN выражения
        if filter:
            for key, value in filter.items():
                if isinstance(value, dict) and "$in" in value:
                    in_values = value["$in"]
                    values_str = ",".join(f"'{str(v)}'" for v in in_values)
                    new_filter = f"metadata->>{key} IN ({values_str})"

                    if postgrest_filter:
                        postgrest_filter = f"({postgrest_filter}) AND ({new_filter})"
                    else:
                        postgrest_filter = new_filter

        # Подготовка аргументов для RPC
        match_documents_params = self.match_args(query, filter)
        query_builder = self._client.rpc(self.query_name, match_documents_params)

        # Применяем фильтр и лимит
        if postgrest_filter:
            query_builder = query_builder.filter(postgrest_filter)

        query_builder = query_builder.limit(k)

        # Выполнение запроса
        res = query_builder.execute()

        # Формируем результат в виде списка кортежей (Document, similarity)
        match_result = [
            (
                Document(
                    metadata={
                        **search.get("metadata", {}),
                        "id": search.get("id"),
                    },
                    page_content=search.get("content", ""),
                ),
                search.get("similarity", 0.0),
            )
            for search in res.data
            if search.get("content")
        ]

        # Фильтруем по порогу релевантности
        if score_threshold is not None:
            match_result = [(doc, similarity) for doc, similarity in match_result if similarity >= score_threshold]
            if not match_result:
                warnings.warn(f"No relevant docs were retrieved using the relevance score threshold {score_threshold}")

        return match_result

    def similarity_search_by_vector_returning_embeddings(
        self,
        query: List[float],
        k: int,
        filter: Optional[Dict[str, Any]] = None,
        postgrest_filter: Optional[str] = None,
    ) -> List[Tuple[Document, float, np.ndarray]]:
        match_documents_params = self.match_args(query, filter)
        query_builder = self._client.rpc(self.query_name, match_documents_params)

        if postgrest_filter:
            query_builder.params = query_builder.params.set("and", f"({postgrest_filter})")

        query_builder.params = query_builder.params.set("limit", k)

        res = query_builder.execute()

        match_result = [
            (
                Document(
                    metadata=search.get("metadata", {}),
                    page_content=search.get("content", ""),
                ),
                search.get("similarity", 0.0),
                # Supabase returns a vector type as its string represation (!).
                # This is a hack to convert the string to numpy array.
                np.fromstring(search.get("embedding", "").strip("[]"), np.float32, sep=","),
            )
            for search in res.data
            if search.get("content")
        ]

        return match_result

    @staticmethod
    def _texts_to_documents(
        texts: Iterable[str],
        metadatas: Optional[Iterable[Dict[Any, Any]]] = None,
    ) -> List[Document]:
        """Return list of Documents from list of texts and metadatas."""
        if metadatas is None:
            metadatas = repeat({})

        docs = [Document(page_content=text, metadata=metadata) for text, metadata in zip(texts, metadatas)]

        return docs

    @staticmethod
    def _add_vectors(
        client: supabase.client.Client,
        table_name: str,
        vectors: List[List[float]],
        documents: List[Document],
        ids: List[str],
        chunk_size: int,
        **kwargs: Any,
    ) -> List[str]:
        """Add vectors to Supabase table."""

        rows: List[Dict[str, Any]] = [
            {
                "id": ids[idx],
                "content": documents[idx].page_content,
                "embedding": embedding,
                "metadata": documents[idx].metadata,
                **kwargs,
            }
            for idx, embedding in enumerate(vectors)
        ]
        id_list: List[str] = []
        for i in range(0, len(rows), chunk_size):
            chunk = rows[i : i + chunk_size]

            result = client.from_(table_name).upsert(chunk).execute()

            if len(result.data) == 0:
                raise Exception("Error inserting: No rows added")

            # VectorStore.add_vectors returns ids as strings
            ids = [str(i.get("id")) for i in result.data if i.get("id")]

            id_list.extend(ids)

        return id_list

    def max_marginal_relevance_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        fetch_k: int = 20,
        lambda_mult: float = 0.5,
        **kwargs: Any,
    ) -> List[Document]:
        """Return docs selected using the maximal marginal relevance.

        Maximal marginal relevance optimizes for similarity to query AND diversity
        among selected documents.

        Args:
            embedding: Embedding to look up documents similar to.
            k: Number of Documents to return. Defaults to 4.
            fetch_k: Number of Documents to fetch to pass to MMR algorithm.
            lambda_mult: Number between 0 and 1 that determines the degree
                        of diversity among the results with 0 corresponding
                        to maximum diversity and 1 to minimum diversity.
                        Defaults to 0.5.
        Returns:
            List of Documents selected by maximal marginal relevance.
        """
        result = self.similarity_search_by_vector_returning_embeddings(embedding, fetch_k)

        matched_documents = [doc_tuple[0] for doc_tuple in result]
        matched_embeddings = [doc_tuple[2] for doc_tuple in result]

        mmr_selected = maximal_marginal_relevance(
            np.array([embedding], dtype=np.float32),
            matched_embeddings,
            k=k,
            lambda_mult=lambda_mult,
        )

        filtered_documents = [matched_documents[i] for i in mmr_selected]

        return filtered_documents

    def max_marginal_relevance_search(
        self,
        query: str,
        k: int = 4,
        fetch_k: int = 20,
        lambda_mult: float = 0.5,
        **kwargs: Any,
    ) -> List[Document]:
        """Return docs selected using the maximal marginal relevance.

        Maximal marginal relevance optimizes for similarity to query AND diversity
        among selected documents.

        Args:
            query: Text to look up documents similar to.
            k: Number of Documents to return. Defaults to 4.
            fetch_k: Number of Documents to fetch to pass to MMR algorithm.
            lambda_mult: Number between 0 and 1 that determines the degree
                        of diversity among the results with 0 corresponding
                        to maximum diversity and 1 to minimum diversity.
                        Defaults to 0.5.
        Returns:
            List of Documents selected by maximal marginal relevance.

        `max_marginal_relevance_search` requires that `query_name` returns matched
        embeddings alongside the match documents. The following function
        demonstrates how to do this:

        ```sql
        CREATE FUNCTION match_documents_embeddings(query_embedding vector(1536),
                                                   match_count int)
            RETURNS TABLE(
                id uuid,
                content text,
                metadata jsonb,
                embedding vector(1536),
                similarity float)
            LANGUAGE plpgsql
            AS $$
            # variable_conflict use_column
        BEGIN
            RETURN query
            SELECT
                id,
                content,
                metadata,
                embedding,
                1 -(docstore.embedding <=> query_embedding) AS similarity
            FROM
                docstore
            ORDER BY
                docstore.embedding <=> query_embedding
            LIMIT match_count;
        END;
        $$;
        ```
        """
        embedding = self._embedding.embed_query(query)
        docs = self.max_marginal_relevance_search_by_vector(embedding, k, fetch_k, lambda_mult=lambda_mult)
        return docs

    def delete(self, ids: Optional[List[str]] = None, **kwargs: Any) -> None:
        """Delete by vector IDs (bulk via .in_() where supported)."""
        if ids is None:
            raise ValueError("No ids provided to delete.")
        if not ids:
            return
        # PostgREST: один запрос на батч (лимит ~1000 значений в IN — разбиваем по 200)
        batch_size = 200
        for i in range(0, len(ids), batch_size):
            chunk = ids[i : i + batch_size]
            self._client.from_(self.table_name).delete().in_("id", chunk).execute()

    def _keyword_search(
        self,
        query: str,
        k: int,
        filter: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[Document, float]]:
        """
        Полнотекстовый поиск через keyword функцию.

        Args:
            query: Поисковый запрос
            k: Количество результатов
            filter: Фильтр по metadata

        Returns:
            Список кортежей (Document, similarity_score)
        """
        # Если включён улучшенный режим ранжирования, используем его
        if self.use_bm25_hybrid:
            return self._keyword_search_bm25_hybrid(query, k, filter)

        logger = logging.getLogger(__name__)

        if not self.keyword_query_name:
            logger.warning("Keyword query name not set, skipping keyword search")
            return []

        # Функция match_documents для полнотекстового поиска принимает: query_text, match_count, filter
        # Supabase RPC сортирует параметры по имени, поэтому используем алфавитный порядок
        # Порядок: filter, match_count, query_text (по алфавиту)
        params = OrderedDict(
            [
                ("filter", filter or {}),
                ("match_count", k),
                ("query_text", query),
            ]
        )

        logger.info(
            "🔍 Keyword search: function='%s', query='%s', k=%d, filter=%s",
            self.keyword_query_name,
            query[:50] + "..." if len(query) > 50 else query,
            k,
            filter,
        )

        try:
            logger.debug("📤 Calling RPC: %s with params: %s", self.keyword_query_name, dict(params))
            res = self._client.rpc(self.keyword_query_name, dict(params)).execute()

            # Детальное логирование для диагностики
            logger.debug("📤 RPC response: has_data=%s, data_type=%s", res.data is not None, type(res.data))
            if hasattr(res, "error"):
                logger.warning("⚠️ RPC response has error attribute: %s", res.error)

            raw_count = len(res.data) if res.data else 0
            logger.info("✅ Keyword search found %d raw results", raw_count)

            # Если результатов нет, попробуем диагностику
            if raw_count == 0:
                logger.warning(
                    "⚠️ No results from SQL function. For hybrid search you need a separate full-text (keyword) "
                    "function in Supabase (e.g. from match_keyword_template), not the vector function. "
                    "Create it in SQL Editor and set keyword_query_name when creating VectorStore."
                )
                logger.warning("  - Function: %s", self.keyword_query_name)
                logger.warning("  - Query length: %d chars", len(query))
                logger.warning("  - Query preview: %s", query[:100] + "..." if len(query) > 100 else query)
                logger.warning("  - Filter: %s", filter)
                logger.warning("  - k: %d", k)

                # Попробуем укороченный запрос для диагностики
                if len(query) > 100:
                    short_query = " ".join(query.split()[:10])  # Первые 10 слов
                    logger.info("🔍 Trying shortened query for diagnostics: '%s'", short_query)
                    test_params = OrderedDict(
                        [
                            ("filter", filter or {}),
                            ("match_count", k),
                            ("query_text", short_query),
                        ]
                    )
                    try:
                        test_res = self._client.rpc(self.keyword_query_name, dict(test_params)).execute()
                        test_count = len(test_res.data) if test_res.data else 0
                        logger.info("🔍 Shortened query result: %d results", test_count)
                    except Exception as test_e:
                        logger.warning("🔍 Test query failed: %s", test_e)

            keyword_results = []
            if res.data:
                for idx, search in enumerate(res.data):
                    logger.debug("📄 Processing result %d: keys=%s", idx + 1, list(search.keys()) if search else "None")
                    if not search:
                        logger.warning("⚠️ Empty result at index %d", idx)
                        continue

                    if search.get("content"):
                        doc = Document(
                            metadata={
                                **search.get("metadata", {}),
                                "id": search.get("id"),
                            },
                            page_content=search.get("content", ""),
                        )
                        score = float(search.get("similarity", 0.0))
                        keyword_results.append((doc, score))
                        logger.debug(
                            "📄 Keyword result: id=%s, similarity=%.4f, content_preview='%s'",
                            search.get("id"),
                            score,
                            search.get("content", "")[:100] + "..." if len(search.get("content", "")) > 100 else search.get("content", ""),
                        )
                    else:
                        logger.warning("⚠️ Result at index %d has no 'content' field: %s", idx, list(search.keys()))

            logger.info("📊 Keyword search: processed %d documents with content", len(keyword_results))

            return keyword_results
        except Exception as e:
            error_msg = str(e)
            logger.error("❌ Keyword search failed: function='%s', params=%s, error=%s", self.keyword_query_name, dict(params), error_msg)
            warnings.warn(f"Keyword search failed: {e}. Returning empty results.")
            return []

    def _keyword_search_bm25_hybrid(
        self,
        query: str,
        k: int,
        filter: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[Document, float]]:
        """
        Гибридный подход: SQL предфильтрация + BM25 ранжирование.
        Сначала получает топ-N результатов через SQL (работает на стороне БД),
        затем применяет BM25 только к этим результатам для более точного ранжирования.

        Args:
            query: Поисковый запрос
            k: Количество результатов
            filter: Фильтр по metadata

        Returns:
            Список кортежей (Document, similarity_score)
        """
        from langchain_community.retrievers import BM25Retriever

        logger = logging.getLogger(__name__)

        try:
            # 1. Сначала получаем больше результатов через SQL (например, 3-5x от k)
            # Это работает на стороне БД, без загрузки всех документов
            sql_k = max(k * 5, 50)  # Берём в 5 раз больше для последующего ранжирования, минимум 50

            params = OrderedDict(
                [
                    ("filter", filter or {}),
                    ("match_count", sql_k),
                    ("query_text", query),
                ]
            )

            logger.info("📊 Step 1: SQL pre-filtering (top %d candidates) for re-ranking...", sql_k)
            res = self._client.rpc(self.keyword_query_name, dict(params)).execute()

            if not res.data:
                logger.warning("No candidates found from SQL pre-filtering")
                return []

            logger.info("✅ SQL pre-filtering: found %d candidates", len(res.data))

            # 2. Создаём Document объекты только из предфильтрованных результатов
            documents = []
            for search in res.data:
                if search.get("content"):
                    doc = Document(
                        metadata={
                            **search.get("metadata", {}),
                            "id": search.get("id"),
                        },
                        page_content=search.get("content", ""),
                    )
                    documents.append(doc)

            if not documents:
                logger.warning("No valid documents with content found")
                return []

            # 3. Применяем дополнительное ранжирование к предфильтрованным документам
            logger.info("🔍 Step 2: Re-ranking on %d candidates (query='%s'...)...", len(documents), query[:50] + "..." if len(query) > 50 else query)

            # Создаём retriever из langchain-community
            retriever = BM25Retriever.from_documents(documents)
            retriever.k = k

            # Получаем результаты через invoke
            results = retriever.invoke(query)

            if not results:
                logger.warning("No results from re-ranking, returning empty list")
                return []

            # Получаем scores используя позицию в результатах
            # (более высокие позиции = более релевантные = выше score)
            # Нормализуем scores на основе позиции (1.0 для первого, убывает)
            keyword_results = []
            for idx, doc in enumerate(results):
                # Используем обратную позицию как score (1.0 для первого результата)
                score = 1.0 / (idx + 1)
                keyword_results.append((doc, float(score)))
                logger.debug(
                    "📄 Keyword result: id=%s, rank=%d, score=%.4f, content_preview='%s'",
                    doc.metadata.get("id"),
                    idx + 1,
                    score,
                    doc.page_content[:100] + "..." if len(doc.page_content) > 100 else doc.page_content,
                )

            logger.info("✅ Re-ranking: selected top %d results from %d candidates", len(keyword_results), len(documents))
            return keyword_results

        except ImportError:
            logger.error("❌ langchain-community not installed. Install it with: uv add langchain-community")
            warnings.warn("Advanced keyword search requires langchain-community. Falling back to SQL search.")
            # Fallback на обычный SQL поиск
            return self._keyword_search_fallback(query, k, filter)
        except Exception as e:
            logger.error(f"❌ Advanced keyword search failed: {e}", exc_info=True)
            warnings.warn(f"Advanced keyword search failed: {e}. Falling back to SQL search.")
            # Fallback на обычный SQL поиск
            return self._keyword_search_fallback(query, k, filter)

    def _keyword_search_fallback(
        self,
        query: str,
        k: int,
        filter: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[Document, float]]:
        """
        Fallback метод для keyword поиска через SQL (используется при ошибках).
        """
        logger = logging.getLogger(__name__)

        if not self.keyword_query_name:
            logger.warning("Keyword query name not set, skipping keyword search")
            return []

        params = OrderedDict(
            [
                ("filter", filter or {}),
                ("match_count", k),
                ("query_text", query),
            ]
        )

        try:
            res = self._client.rpc(self.keyword_query_name, dict(params)).execute()

            keyword_results = []
            for search in res.data:
                if search.get("content"):
                    doc = Document(
                        metadata={
                            **search.get("metadata", {}),
                            "id": search.get("id"),
                        },
                        page_content=search.get("content", ""),
                    )
                    score = float(search.get("similarity", 0.0))
                    keyword_results.append((doc, score))

            return keyword_results
        except Exception as e:
            logger.error(f"❌ Fallback keyword search failed: {e}")
            return []

    def _merge_hybrid_results(
        self,
        vector_results: List[Tuple[Document, float]],
        keyword_results: List[Tuple[Document, float]],
        alpha: float = 0.5,
    ) -> List[Tuple[Document, float]]:
        """
        Объединяет результаты векторного и keyword поиска с дедупликацией.
        Адаптировано из логики LangChain JS SupabaseHybridSearch.
        """

        # Нормализуем scores обоих поисков к диапазону [0, 1]
        def normalize_scores(results: List[Tuple[Document, float]]) -> List[Tuple[Document, float]]:
            if not results:
                return []

            scores = [score for _, score in results]
            min_score = min(scores)
            max_score = max(scores)
            score_range = max_score - min_score if max_score != min_score else 1.0

            return [(doc, (score - min_score) / score_range) for doc, score in results]

        normalized_vector = normalize_scores(vector_results)
        normalized_keyword = normalize_scores(keyword_results)

        # Объединяем результаты по id документа
        results_dict: Dict[str, Tuple[Document, float, float]] = {}

        # Добавляем векторные результаты с весом alpha
        for doc, normalized_score in normalized_vector:
            doc_id = str(doc.metadata.get("id")) if doc.metadata.get("id") is not None else f"content_{hash(doc.page_content)}"
            results_dict[doc_id] = (doc, normalized_score * alpha, 0.0)

        # Добавляем/обновляем keyword результаты с весом (1 - alpha)
        for doc, normalized_score in normalized_keyword:
            doc_id = str(doc.metadata.get("id")) if doc.metadata.get("id") is not None else f"content_{hash(doc.page_content)}"
            if doc_id in results_dict:
                existing_doc, vec_score, _ = results_dict[doc_id]
                results_dict[doc_id] = (existing_doc, vec_score, normalized_score * (1 - alpha))
            else:
                results_dict[doc_id] = (doc, 0.0, normalized_score * (1 - alpha))

        # Вычисляем финальные scores и сортируем
        final_results = []
        for doc, vec_score, kw_score in results_dict.values():
            final_score = vec_score + kw_score
            final_results.append((doc, final_score))

        # Сортируем по убыванию финального score
        final_results.sort(key=lambda x: x[1], reverse=True)

        return final_results

    def hybrid_search(
        self,
        query: str,
        k: int = 4,
        similarity_k: Optional[int] = None,
        keyword_k: Optional[int] = None,
        filter: Optional[Dict[str, Any]] = None,
        score_threshold: Optional[float] = None,
        alpha: float = 0.5,
        **kwargs: Any,
    ) -> List[Document]:
        """
        Hybrid search: комбинирует векторный и полнотекстовый поиск.

        Использует:
        - match_vectorstore(query_embedding vector, filter jsonb) - векторный поиск
        - match_vectorstore(query_embedding, filter JSONB) - keyword поиск
        """
        logger = logging.getLogger(__name__)

        if not 0.0 <= alpha <= 1.0:
            raise ValueError(f"alpha must be between 0.0 and 1.0, got {alpha}")

        similarity_k = similarity_k or k * 2
        keyword_k = keyword_k or k * 2

        logger.info(
            "🔍 Hybrid search: query='%s', k=%d, similarity_k=%d, keyword_k=%d, alpha=%.2f, filter=%s",
            query[:50] + "..." if len(query) > 50 else query,
            k,
            similarity_k,
            keyword_k,
            alpha,
            filter,
        )

        # 1. Векторный поиск
        logger.info("📊 Step 1: Vector search...")
        query_embedding = self._embedding.embed_query(query)
        vector_results = self.similarity_search_by_vector_with_relevance_scores(query_embedding, k=similarity_k, filter=filter, **kwargs)
        logger.info("✅ Vector search: found %d results", len(vector_results))
        for i, (doc, score) in enumerate(vector_results[:3], 1):
            logger.debug("  %d. score=%.4f, id=%s, preview='%s'", i, score, doc.metadata.get("id"), doc.page_content[:100])

        # 2. Keyword поиск
        logger.info("📊 Step 2: Keyword search...")
        keyword_results = self._keyword_search(query, k=keyword_k, filter=filter)
        logger.info("✅ Keyword search: found %d results", len(keyword_results))
        for i, (doc, score) in enumerate(keyword_results[:3], 1):
            logger.debug("  %d. score=%.4f, id=%s, preview='%s'", i, score, doc.metadata.get("id"), doc.page_content[:100])

        # 3. Объединение и дедупликация
        logger.info("📊 Step 3: Merging results (alpha=%.2f)...", alpha)
        combined_results = self._merge_hybrid_results(vector_results, keyword_results, alpha=alpha)
        logger.info("✅ Merged: %d unique documents after deduplication", len(combined_results))

        # 4. Фильтрация по порогу релевантности
        if score_threshold is not None:
            before_count = len(combined_results)
            combined_results = [(doc, score) for doc, score in combined_results if score >= score_threshold]
            logger.info("📊 Filtered by threshold %.2f: %d -> %d results", score_threshold, before_count, len(combined_results))
            if not combined_results:
                warnings.warn(f"No relevant docs were retrieved using the relevance score threshold {score_threshold}")

        # 5. Возвращаем топ-k документов
        final_results = [doc for doc, _ in combined_results[:k]]
        logger.info("🎯 Final hybrid search results: %d documents", len(final_results))
        for i, (doc, score) in enumerate(combined_results[:k], 1):
            logger.info(
                "  %d. id=%s, metadata=%s, content_preview='%s'",
                i,
                doc.metadata.get("id"),
                {k: v for k, v in doc.metadata.items() if k != "id"},
                doc.page_content[:150] + "..." if len(doc.page_content) > 150 else doc.page_content,
            )
            # Детальное логирование каждого чанка на debug уровне
            logger.debug(
                "📄 Chunk %d: id=%s, final_score=%.4f, metadata=%s, content_length=%d, content='%s'",
                i,
                doc.metadata.get("id"),
                score,
                doc.metadata,
                len(doc.page_content),
                doc.page_content,
            )

        return final_results

    def hybrid_search_with_relevance_scores(
        self,
        query: str,
        k: int = 4,
        similarity_k: Optional[int] = None,
        keyword_k: Optional[int] = None,
        filter: Optional[Dict[str, Any]] = None,
        score_threshold: Optional[float] = None,
        alpha: float = 0.5,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """
        Hybrid search с возвратом scores.
        """
        similarity_k = similarity_k or k * 2
        keyword_k = keyword_k or k * 2

        query_embedding = self._embedding.embed_query(query)
        vector_results = self.similarity_search_by_vector_with_relevance_scores(query_embedding, k=similarity_k, filter=filter, **kwargs)

        keyword_results = self._keyword_search(query, k=keyword_k, filter=filter)

        combined_results = self._merge_hybrid_results(vector_results, keyword_results, alpha=alpha)

        if score_threshold is not None:
            combined_results = [(doc, score) for doc, score in combined_results if score >= score_threshold]

        return combined_results[:k]
