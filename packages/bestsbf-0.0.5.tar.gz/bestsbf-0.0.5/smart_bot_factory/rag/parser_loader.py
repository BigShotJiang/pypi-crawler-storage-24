"""Ingestion файлов из папки парсера в RAG (VectorStore)."""

import logging
from pathlib import Path
from typing import List, Literal, Optional, Tuple

from langchain_text_splitters import RecursiveCharacterTextSplitter
from project_root_finder import root

from .vectorstore import VectorStore

logger = logging.getLogger(__name__)

DEFAULT_TABLE_NAME = "vectorstore"
INGEST_BATCH_SIZE = 600
Strategy = Literal["per_file", "merge"]


def _collect_txt_files(parser_dir: Path) -> List[Path]:
    """Собирает все .txt файлы в директории рекурсивно."""
    return sorted(parser_dir.rglob("*.txt"))


def _read_files(files: List[Path], encoding: str = "utf-8") -> List[Tuple[Path, str]]:
    """Читает содержимое файлов. Возвращает список (path, content)."""
    result: List[Tuple[Path, str]] = []
    for path in files:
        try:
            content = path.read_text(encoding=encoding)
            result.append((path, content))
        except Exception as exc:
            logger.warning("Пропуск файла %s: %s", path, exc)
    return result


class ParserIngester:
    """
    Загружает текстовые файлы из директории парсера бота в RAG (VectorStore).

    Два режима: per_file (один файл = один документ) и merge
    (всё склеить и разбить на чанки).
    """

    def __init__(
        self,
        *,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        encoding: str = "utf-8",
        table_name: str = DEFAULT_TABLE_NAME,
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.encoding = encoding
        self.table_name = table_name

    def ingest(
        self,
        bot_id: str,
        subfolder: Optional[str] = None,
        strategy: Strategy = "per_file",
        *,
        parser_dir: Optional[Path] = None,
        vector_store: Optional[VectorStore] = None,
    ) -> List[str]:
        """
        Загружает файлы из директории парсера в RAG.

        Args:
            bot_id: Идентификатор бота (путь: bots/{bot_id}/parser или .../parser/{subfolder}).
            subfolder: Подпапка внутри parser (игнорируется, если задан parser_dir).
            strategy: "per_file" — один файл = один документ; "merge" — склеить и разбить на чанки.
            parser_dir: Явный путь к директории с .txt. Если None — root / "bots" / bot_id / "parser" / subfolder.
        vector_store: Опционально переиспользовать существующий VectorStore (из ParserRagPipeline).

        Returns:
            Список id добавленных документов в хранилище.
        """
        if parser_dir is None:
            base = root / "bots" / bot_id / "parser"
            parser_dir = base / subfolder if subfolder else base

        parser_dir = Path(parser_dir)
        if not parser_dir.is_dir():
            raise FileNotFoundError(f"Директория парсера не найдена: {parser_dir}")

        files = _collect_txt_files(parser_dir)
        if not files:
            logger.warning("В %s не найдено .txt файлов", parser_dir)
            return []

        file_contents = _read_files(files, encoding=self.encoding)
        if not file_contents:
            logger.warning("Не удалось прочитать ни один файл из %s", parser_dir)
            return []

        base_metadata = {"bot_id": bot_id}
        texts: List[str] = []
        metadatas: List[dict] = []

        if strategy == "per_file":
            for path, content in file_contents:
                content_stripped = content.strip()
                if not content_stripped:
                    continue
                texts.append(content_stripped)
                try:
                    source = path.relative_to(parser_dir)
                except ValueError:
                    source = path.name
                metadatas.append({**base_metadata, "source": str(source)})
        else:
            combined = "\n\n".join(content for _, content in file_contents)
            splitter = RecursiveCharacterTextSplitter(
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
            )
            chunks = splitter.split_text(combined)
            for chunk in chunks:
                if not chunk.strip():
                    continue
                texts.append(chunk)
                metadatas.append({**base_metadata, "source": "merged"})

        if not texts:
            logger.warning("Нет контента для загрузки в RAG")
            return []

        store = vector_store or VectorStore(bot_id=bot_id, table_name=self.table_name)
        all_ids: List[str] = []
        for i in range(0, len(texts), INGEST_BATCH_SIZE):
            batch_texts = texts[i : i + INGEST_BATCH_SIZE]
            batch_metadatas = metadatas[i : i + INGEST_BATCH_SIZE]
            batch_ids = store.add_texts(batch_texts, metadatas=batch_metadatas)
            all_ids.extend(batch_ids)
        logger.info("Загружено в RAG: %d документов (strategy=%s)", len(all_ids), strategy)
        return all_ids


def ingest_parser_files(
    bot_id: str,
    subfolder: Optional[str] = None,
    strategy: Strategy = "per_file",
    *,
    parser_dir: Optional[Path] = None,
    chunk_size: int = 500,
    chunk_overlap: int = 50,
    encoding: str = "utf-8",
    table_name: str = DEFAULT_TABLE_NAME,
) -> List[str]:
    """
    Загружает файлы из директории парсера в RAG (удобная обёртка над ParserIngester).

    Args:
        bot_id: Идентификатор бота.
        subfolder: Подпапка внутри parser.
        strategy: "per_file" или "merge".
        parser_dir: Явный путь к директории (опционально).
        chunk_size, chunk_overlap, encoding, table_name: Параметры ингеста.

    Returns:
        Список id добавленных документов.
    """
    ingester = ParserIngester(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        encoding=encoding,
        table_name=table_name,
    )
    return ingester.ingest(bot_id, subfolder=subfolder, strategy=strategy, parser_dir=parser_dir)
