"""Пайплайн: ссылки → парсинг → очистка RAG → ингест в RAG."""

from __future__ import annotations

import asyncio
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from project_root_finder import root

from smart_bot_factory.site_parser import SiteParser, search_sitemap

from .parser_loader import DEFAULT_TABLE_NAME, ParserIngester, Strategy
from .vectorstore import VectorStore

logger = logging.getLogger(__name__)


@dataclass
class ParserRagRunResult:
    """Результат одного запуска пайплайна."""

    success: bool
    error: Optional[str] = None
    links_count: int = 0
    parsed_count: int = 0
    deleted_count: int = 0
    ingested_count: int = 0

    def _stats_line(self) -> str:
        return f"links={self.links_count}, parsed={self.parsed_count}, deleted={self.deleted_count}, ingested={self.ingested_count}"

    def to_short_message(self) -> str:
        if not self.success:
            return f"❌ Ошибка: {self.error}"
        return (
            f"✅ RAG обновлён: ссылок {self.links_count}, распарсено {self.parsed_count}, "
            f"удалено из RAG {self.deleted_count}, добавлено {self.ingested_count}"
        )

    def to_log_message(self) -> str:
        if not self.success:
            return f"Ошибка: {self.error}"
        return f"RAG обновлён: {self._stats_line()}"


class ParserRagPipeline:
    """
    Цепочка: получение ссылок (sitemap или список) → парсинг в папку parser →
    опционально очистка RAG по bot_id → ингест в RAG.
    """

    def __init__(
        self,
        bot_id: str,
        *,
        sitemap_url: Optional[str] = None,
        sitemap_regex: Optional[str] = None,
        sitemap_limit: Optional[int] = None,
        sitemap_include_source: bool = False,
        links: Optional[List[str]] = None,
        parser_subfolder: Optional[str] = None,
        ingest_strategy: Strategy = "per_file",
        clear_rag_before_ingest: bool = True,
        metadata_filter_for_delete: Optional[Dict[str, Any]] = None,
        parser_additional_instructions: Optional[str] = None,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        table_name: str = DEFAULT_TABLE_NAME,
        max_workers: int = 5,
        bot_config_dir: Optional[Path] = None,
        rebuild_qdrant_after_parser: bool = True,
    ):
        if not sitemap_url and not links:
            raise ValueError("Укажите sitemap_url или links")
        if sitemap_url and links:
            raise ValueError("Укажите только один источник: sitemap_url или links")
        self.bot_id = bot_id
        self.sitemap_url = sitemap_url
        self.sitemap_regex = sitemap_regex
        self.sitemap_limit = sitemap_limit
        self.sitemap_include_source = sitemap_include_source
        self.links = links or []
        self.parser_subfolder = parser_subfolder
        self.ingest_strategy = ingest_strategy
        self.clear_rag_before_ingest = clear_rag_before_ingest
        self.metadata_filter_for_delete = metadata_filter_for_delete or {}
        self.parser_additional_instructions = parser_additional_instructions
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.table_name = table_name
        self.max_workers = max_workers
        self._bot_config_dir = (
            Path(bot_config_dir).resolve()
            if bot_config_dir is not None
            else (root / "bots" / bot_id).resolve()
        )
        self.rebuild_qdrant_after_parser = rebuild_qdrant_after_parser
        self._vector_store: Optional[VectorStore] = None
        self._ingester: Optional[ParserIngester] = None
        self._lock = asyncio.Lock()

    def _get_vector_store(self) -> VectorStore:
        if self._vector_store is None:
            self._vector_store = VectorStore(bot_id=self.bot_id, table_name=self.table_name)
        return self._vector_store

    def _get_ingester(self) -> ParserIngester:
        if self._ingester is None:
            self._ingester = ParserIngester(
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
                table_name=self.table_name,
            )
        return self._ingester

    def _get_urls(self) -> List[str]:
        if self.sitemap_url:
            return search_sitemap(
                url=self.sitemap_url,
                regex=self.sitemap_regex,
                limit=self.sitemap_limit,
                include_source=self.sitemap_include_source,
            )
        return list(self.links)

    async def _parse_urls(self, urls: List[str]) -> int:
        parser = SiteParser(
            bot_id=self.bot_id,
            additional_instructions=self.parser_additional_instructions,
        )
        parse_result = await parser.parser(
            url=urls,
            sitemap=None,
            to_files=True,
            subfolder=self.parser_subfolder,
            max_workers=self.max_workers,
        )
        if isinstance(parse_result, list):
            return len(parse_result)
        return 1 if parse_result else 0

    def _clear_rag(self) -> int:
        store = self._get_vector_store()
        filter_dict = {"bot_id": self.bot_id, **self.metadata_filter_for_delete}
        return store.delete_by_metadata(filter_dict)

    async def _maybe_rebuild_qdrant(self, parsed_count: int) -> None:
        if parsed_count <= 0 or not self.rebuild_qdrant_after_parser:
            return
        from smart_bot_factory.rag.qdrant.bootstrap import qdrant_rag_dependencies_available

        if not qdrant_rag_dependencies_available():
            return

        bot_dir = self._bot_config_dir
        if not bot_dir.is_dir():
            logger.warning("Qdrant rebuild: каталог бота не найден: %s", bot_dir)
            return

        env_file = bot_dir / ".env"
        if env_file.is_file():
            load_dotenv(env_file)
        os.environ["BOT_ID"] = self.bot_id

        try:
            from smart_bot_factory.config import Config

            cfg_app = Config()
        except Exception as exc:
            logger.debug("Qdrant rebuild: пропуск (Config): %s", exc)
            return

        from smart_bot_factory.rag.qdrant.indexer import rebuild_qdrant_rag_index
        from smart_bot_factory.rag.qdrant.settings import resolve_qdrant_rag_config

        resolved = resolve_qdrant_rag_config(bot_dir, cfg_app)
        if resolved is None or not resolved.ingest_sources_include_parser:
            return

        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(None, lambda: rebuild_qdrant_rag_index(resolved))
            logger.info(
                "Qdrant RAG: индекс пересобран после парсера (коллекция=%s)",
                resolved.qdrant_collection,
            )
        except Exception:
            logger.exception("Qdrant RAG: ошибка пересборки после ParserRagPipeline")

    async def run(self) -> ParserRagRunResult:
        """
        Выполняет полный цикл: ссылки → парсинг → очистка RAG (если включено) → ингест.
        Один запуск за раз (asyncio.Lock).
        """
        result = ParserRagRunResult(success=False, links_count=0)
        async with self._lock:
            try:
                urls = self._get_urls()
                result.links_count = len(urls)
                if not urls:
                    result.success = True
                    result.error = "Нет ссылок для парсинга"
                    return result

                result.parsed_count = await self._parse_urls(urls)
                if result.parsed_count == 0:
                    result.success = False
                    result.error = "Нет успешно распарсенных страниц, RAG не изменён"
                    return result

                if self.clear_rag_before_ingest:
                    result.deleted_count = self._clear_rag()

                ingested_ids = self._get_ingester().ingest(
                    self.bot_id,
                    subfolder=self.parser_subfolder,
                    strategy=self.ingest_strategy,
                    vector_store=self._get_vector_store(),
                )
                result.ingested_count = len(ingested_ids)
                result.success = True
                await self._maybe_rebuild_qdrant(result.parsed_count)
                logger.info("ParserRagPipeline run: %s", result.to_log_message())
            except Exception as exc:
                logger.exception("ParserRagPipeline run failed")
                result.error = str(exc)
        return result


async def _run_pipeline_and_log(pipeline: ParserRagPipeline, label: str = "") -> None:
    """Один запуск pipeline.run() с логированием. Проброс CancelledError, остальные — в лог."""
    try:
        result = await pipeline.run()
        logger.info("Периодическое обновление RAG%s: %s", label, result.to_log_message())
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        logger.exception("Ошибка периодического обновления RAG%s: %s", label, exc)


async def periodic_rag_refresh(
    pipeline: ParserRagPipeline,
    interval_seconds: float,
    run_immediately: bool = False,
) -> None:
    """
    Фоновая задача: раз в interval_seconds вызывает pipeline.run().
    run_immediately: если True, первый run() сразу при старте, затем по интервалу.
    """
    logger.info(
        "Запущена периодическая задача обновления RAG, интервал %s с, run_immediately=%s",
        interval_seconds,
        run_immediately,
    )
    if run_immediately:
        await _run_pipeline_and_log(pipeline, " (старт)")
    while True:
        await asyncio.sleep(interval_seconds)
        await _run_pipeline_and_log(pipeline)
