"""Qdrant collection schema for hybrid (dense + sparse BM25 on server). Indexing goes through QdrantVectorStore.add."""

from __future__ import annotations

import logging

from qdrant_client import QdrantClient
from qdrant_client.http import models

from .settings import QdrantRagRuntimeConfig

logger = logging.getLogger(__name__)


def qdrant_rag_http_client(cfg: QdrantRagRuntimeConfig) -> QdrantClient:
    """cloud_inference=True sends models.Document to Qdrant for BM25 (no local FastEmbed)."""
    return QdrantClient(url=cfg.qdrant_url, cloud_inference=cfg.qdrant_server_inference)


def ensure_hybrid_collection(client: QdrantClient, cfg: QdrantRagRuntimeConfig, dense_dim: int) -> None:
    """Only direct create_collection: sparse_vectors_config + dense (allowed exception for hybrid schema)."""
    if client.collection_exists(cfg.qdrant_collection):
        return
    client.create_collection(
        collection_name=cfg.qdrant_collection,
        vectors_config={
            cfg.qdrant_dense_vector_name: models.VectorParams(
                size=dense_dim,
                distance=models.Distance.COSINE,
            ),
        },
        sparse_vectors_config={
            cfg.qdrant_sparse_vector_name: models.SparseVectorParams(
                index=models.SparseIndexParams(),
                modifier=models.Modifier.IDF,
            ),
        },
    )
    logger.info(
        "Qdrant RAG: создана коллекция %s (dense=%s, sparse=%s, IDF)",
        cfg.qdrant_collection,
        cfg.qdrant_dense_vector_name,
        cfg.qdrant_sparse_vector_name,
    )
