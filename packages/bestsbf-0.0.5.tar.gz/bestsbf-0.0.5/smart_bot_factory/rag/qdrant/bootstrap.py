"""Wire Qdrant RAG optional dependencies; build retriever for ctx."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Tuple

from ...config import Config
from .settings import QdrantRagRuntimeConfig, resolve_qdrant_rag_config

if TYPE_CHECKING:
    from .retriever import QdrantRagRetriever

logger = logging.getLogger(__name__)


def qdrant_rag_dependencies_available() -> bool:
    try:
        import llama_index.core  # noqa: F401
        import llama_index.embeddings.openai  # noqa: F401
        import llama_index.vector_stores.qdrant  # noqa: F401
        import qdrant_client  # noqa: F401
    except ImportError:
        return False
    return True


async def create_qdrant_rag_retriever(
    bot_config_dir: Path,
    config: Config,
) -> Tuple[Optional[QdrantRagRetriever], Optional[QdrantRagRuntimeConfig]]:
    """
    Returns (None, None) if Qdrant RAG is not configured or optional deps missing.
    Otherwise builds/loads index and returns retriever + resolved config (for logging).
    """
    if not qdrant_rag_dependencies_available():
        logger.warning(
            "Qdrant RAG: пакеты не установлены (установите проект с extra qdrant-rag)"
        )
        return None, None

    resolved = resolve_qdrant_rag_config(bot_config_dir, config)
    if resolved is None:
        return None, None

    from .indexer import ensure_qdrant_rag_index
    from .retriever import QdrantRagRetriever

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(None, lambda: ensure_qdrant_rag_index(resolved))
    except Exception as e:
        logger.error("Qdrant RAG: не удалось подготовить индекс: %s", e)
        raise

    retriever = QdrantRagRetriever(resolved)
    logger.info(
        "Qdrant RAG: retriever готов (коллекция=%s, BM25=%s, server_inference=%s, voyage_rerank=%s)",
        resolved.qdrant_collection,
        resolved.qdrant_bm25_model,
        resolved.qdrant_server_inference,
        bool(resolved.voyage_api_key.strip()),
    )
    return retriever, resolved
