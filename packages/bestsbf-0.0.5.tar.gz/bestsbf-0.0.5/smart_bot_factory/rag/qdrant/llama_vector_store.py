"""
Qdrant via LlamaIndex QdrantVectorStore: dense (OpenAI embeddings) + server BM25 (Document) + Fusion.RRF.

Application code uses QdrantVectorStore.add / .query only. Low-level QdrantClient calls for
hybrid upload and RRF search live inside this subclass; collection schema uses create_collection
(allowed exception for sparse vectors).
"""

from __future__ import annotations

from typing import Any, List, Optional, Tuple, cast

from llama_index.core.schema import BaseNode, MetadataMode
from llama_index.core.utils import iter_batch
from llama_index.core.vector_stores.types import (
    VectorStoreQuery,
    VectorStoreQueryMode,
    VectorStoreQueryResult,
)
from llama_index.core.vector_stores.utils import node_to_metadata_dict
from llama_index.vector_stores.qdrant import QdrantVectorStore
from qdrant_client import QdrantClient
from qdrant_client.http import models as rest
from qdrant_client.http.models import Filter

from .settings import QdrantRagRuntimeConfig


def _noop_sparse_batch(texts: List[str]) -> Tuple[List[List[int]], List[List[float]]]:
    """Disables stock FastEmbed hybrid encoders; sparse side uses server Document in _build_points."""
    return [[] for _ in texts], [[] for _ in texts]


class QdrantServerBm25VectorStore(QdrantVectorStore):
    """QdrantVectorStore with Qdrant server inference for sparse (BM25 Document) and RRF at query time."""

    def __init__(
        self,
        *,
        bm25_model: str,
        server_inference: bool,
        **kwargs: Any,
    ) -> None:
        if server_inference:
            # In server inference mode we do not compute sparse vectors locally.
            # Instead we send Qdrant "Document" objects and let Qdrant inference build BM25.
            super().__init__(
                sparse_doc_fn=_noop_sparse_batch,
                sparse_query_fn=_noop_sparse_batch,
                enable_hybrid=True,
                **kwargs,
            )
        else:
            # Local sparse mode: let the base QdrantVectorStore compute sparse vectors
            # via its default sparse encoders (requires optional deps like fastembed).
            super().__init__(enable_hybrid=True, **kwargs)

        # Must be set AFTER super().__init__() — QdrantVectorStore is a Pydantic model
        # and Pydantic resets the instance during __init__, discarding pre-set attributes.
        self._bm25_model: str = bm25_model
        self._server_inference: bool = server_inference

    @classmethod
    def class_name(cls) -> str:
        return "QdrantServerBm25VectorStore"

    def _build_points(
        self,
        nodes: List[BaseNode],
        sparse_vector_name: str,
    ) -> Tuple[List[Any], List[str]]:
        if not self._server_inference:
            return super()._build_points(nodes, sparse_vector_name)

        ids: List[str] = []
        points: List[Any] = []
        for node_batch in iter_batch(nodes, self.batch_size):
            node_ids: List[str] = []
            vectors: List[dict[str, Any]] = []
            payloads: List[dict[str, Any]] = []
            for node in node_batch:
                if not isinstance(node, BaseNode):
                    raise TypeError(f"Expected BaseNode, got {type(node)}")
                emb = node.get_embedding()
                if emb is None:
                    raise ValueError("Qdrant RAG: leaf node missing embedding before vector store add")
                text = node.get_content(metadata_mode=MetadataMode.EMBED)
                node_ids.append(node.node_id)
                vectors.append(
                    {
                        self.dense_vector_name: list(emb),
                        sparse_vector_name: rest.Document(
                            text=text,
                            model=self._bm25_model,
                        ),
                    }
                )
                payloads.append(
                    node_to_metadata_dict(
                        node,
                        remove_text=False,
                        flat_metadata=self.flat_metadata,
                    )
                )
            points.extend(
                [
                    rest.PointStruct(id=nid, payload=payload, vector=vector)
                    for nid, payload, vector in zip(node_ids, payloads, vectors)
                ]
            )
            ids.extend(node_ids)
        return points, ids

    def _query_server_bm25_hybrid(
        self,
        query: VectorStoreQuery,
        **kwargs: Any,
    ) -> VectorStoreQueryResult:
        query_embedding = cast(List[float], query.query_embedding)
        qdrant_filters = kwargs.get("qdrant_filters")
        if qdrant_filters is not None:
            query_filter = qdrant_filters
        else:
            built = self._build_query_filter(query)
            query_filter = cast(Optional[Filter], built)

        shard_identifier = kwargs.get("shard_identifier")
        shard_key = (
            self._generate_shard_key_selector(shard_identifier)
            if shard_identifier is not None
            else None
        )

        search_params = kwargs.get("search_params")
        if search_params is not None and isinstance(search_params, dict):
            search_params = rest.SearchParams(**search_params)
        search_params = cast(Optional[rest.SearchParams], search_params)

        question = query.query_str
        if question is None or not question.strip():
            return VectorStoreQueryResult(nodes=[], similarities=[], ids=[])

        sparse_limit = query.sparse_top_k or query.similarity_top_k
        fusion_limit = query.hybrid_top_k or query.similarity_top_k

        resp = self._client.query_points(
            collection_name=self.collection_name,
            prefetch=[
                rest.Prefetch(
                    query=list(query_embedding),
                    using=self.dense_vector_name,
                    limit=query.similarity_top_k,
                    filter=query_filter,
                    params=search_params,
                ),
                rest.Prefetch(
                    query=rest.Document(
                        text=question,
                        model=self._bm25_model,
                    ),
                    using=self.sparse_vector_name,
                    limit=sparse_limit,
                    filter=query_filter,
                    params=search_params,
                ),
            ],
            query=rest.FusionQuery(fusion=rest.Fusion.RRF),
            limit=fusion_limit,
            with_payload=True,
            query_filter=query_filter,
            shard_key_selector=shard_key,
            search_params=search_params,
        )
        return self.parse_to_query_result(resp.points)

    def query(
        self,
        query: VectorStoreQuery,
        **kwargs: Any,
    ) -> VectorStoreQueryResult:
        if not self._server_inference:
            return super().query(query, **kwargs)

        if (
            query.mode == VectorStoreQueryMode.HYBRID
            and query.query_embedding is not None
            and query.query_str is not None
            and query.query_str.strip()
        ):
            return self._query_server_bm25_hybrid(query, **kwargs)
        return super().query(query, **kwargs)


def qdrant_rag_vector_store(cfg: QdrantRagRuntimeConfig, client: QdrantClient) -> QdrantServerBm25VectorStore:
    """LlamaIndex vector store wired to cfg (names, batch, server BM25 model)."""
    return QdrantServerBm25VectorStore(
        collection_name=cfg.qdrant_collection,
        client=client,
        batch_size=cfg.qdrant_upsert_batch_size,
        dense_vector_name=cfg.qdrant_dense_vector_name,
        sparse_vector_name=cfg.qdrant_sparse_vector_name,
        bm25_model=cfg.qdrant_bm25_model,
        server_inference=cfg.qdrant_server_inference,
        index_doc_id=False,
    )
