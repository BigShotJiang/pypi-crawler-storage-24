"""OpenAI dense embeddings for Qdrant RAG (Voyage используется только для rerank)."""

from __future__ import annotations

from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding, OpenAIEmbeddingMode

from .settings import QdrantRagRuntimeConfig


def qdrant_rag_openai_embedding(cfg: QdrantRagRuntimeConfig) -> OpenAIEmbedding:
    """Симметричные эмбеддинги для индекса и гибридного поиска (dense в Qdrant)."""
    api_base = cfg.openai_base_url if cfg.openai_base_url and cfg.openai_base_url.strip() else None
    return OpenAIEmbedding(
        mode=OpenAIEmbeddingMode.SIMILARITY_MODE,
        model=cfg.openai_embed_model,
        api_key=cfg.openai_api_key,
        api_base=api_base,
        embed_batch_size=min(100, max(1, cfg.qdrant_upsert_batch_size)),
        max_retries=3,
        timeout=60.0,
    )


def dense_embedding_dimension(embed_model: BaseEmbedding) -> int:
    return len(embed_model.get_text_embedding("dimension_probe"))
