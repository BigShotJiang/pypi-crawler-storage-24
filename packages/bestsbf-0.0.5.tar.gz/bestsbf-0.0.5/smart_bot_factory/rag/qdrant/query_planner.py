"""
LLM-планировщик запроса в Qdrant RAG перед полным циклом retrieval (HyDE, hybrid, rerank).
"""
from __future__ import annotations

import logging
import os
import re
from typing import List, Literal

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

from ...integrations.openai.responce_models import RagQueryPlannerDecision
from ...integrations.openai.knowledge.router import DEFAULT_KNOWLEDGE_ROUTER_MODEL

logger = logging.getLogger(__name__)

RagPlannerDialogMode = Literal["rag_only", "with_knowledge"]

_PLANNER_HUMAN = """=== КРАТКО: БАЗОВЫЙ СИСТЕМНЫЙ ПРОМПТ (prompts/) ===
{prompts_summary}

=== ИНДЕКС ФАЙЛОВ ЗНАНИЙ (Markdown, для ориентира) ===
{index_markdown}

=== УЖЕ ВЫБРАНЫ ДЛЯ ЭТОГО ХОДА (файлы knowledge) ===
{selected_knowledge_topics}

=== ПОСЛЕДНИЕ РЕПЛИКИ ===
{dialog_snippet}

=== ПОСЛЕДНЕЕ СООБЩЕНИЕ ПОЛЬЗОВАТЕЛЯ ===
{user_query}"""


def normalize_rag_planner_decision(raw: RagQueryPlannerDecision) -> RagQueryPlannerDecision:
    """needs_rag без непустого запроса трактуем как отказ от RAG (как после LLM)."""
    if raw.needs_rag and not raw.retrieval_query.strip():
        return RagQueryPlannerDecision(
            needs_rag=False,
            retrieval_query="",
            planner_note=raw.planner_note,
        )
    return raw


_SYSTEM_WITH_KNOWLEDGE = """Ты планировщик запросов к векторной базе знаний (RAG).

Реши, нужен ли поиск в RAG для ответа на текущий запрос пользователя.

Нужен RAG (needs_rag=true), если:
- требуются конкретные факты об услугах, ценах, условиях, документах, которых нет в перечисленном базовом промпте и в уже выбранных файлах knowledge;
- пользователь спрашивает детали, которых нет в последних репликах и в кратком описании знаний.

НЕ нужен RAG (needs_rag=false), если:
- достаточно общего тона, приветствия, или информации уже есть в блоке «базовый промпт» или в выбранных темах knowledge;
- вопрос общий и не требует фактов из расширенной базы.

Если needs_rag=true, сформулируй retrieval_query: короткий самодостаточный поисковый запрос на русском (ключевые сущности + намерение).
planner_note: 1–2 предложения, зачем ищем (для системного контекста основной модели)."""

_SYSTEM_RAG_ONLY = """Ты планировщик запросов к векторной базе знаний (RAG). В этом пайплайне нет шага выбора файлов knowledge/*.txt перед тобой — ориентируйся на краткое описание базового промпта (prompts/), блок индекса knowledge (справочно) и диалог.

Реши, нужен ли поиск в RAG для ответа на текущий запрос пользователя.

Нужен RAG (needs_rag=true), если:
- нужны конкретные факты (услуги, цены, условия, документы), которых нет в базовом промпте и в последних репликах;
- пользователь уточняет детали, которых нет в уже известном контексте.

НЕ нужен RAG (needs_rag=false), если:
- достаточно тона, приветствия или ответа из базового промпта и истории;
- вопрос общий и не требует фактов из расширенной векторной базы.

Если needs_rag=true, сформулируй retrieval_query: короткий самодостаточный поисковый запрос на русском (ключевые сущности + намерение).
planner_note: 1–2 предложения, зачем ищем (для системного контекста основной модели)."""


def _planner_prompt_for_mode(mode: RagPlannerDialogMode) -> ChatPromptTemplate:
    system = _SYSTEM_WITH_KNOWLEDGE if mode == "with_knowledge" else _SYSTEM_RAG_ONLY
    return ChatPromptTemplate.from_messages(
        [
            ("system", system),
            ("human", _PLANNER_HUMAN),
        ]
    )


def build_selected_knowledge_topics_block(indices: List[int], index_markdown: str) -> str:
    """Краткие строки по выбранным индексам из Markdown-индекса (заголовки ## N — …)."""
    if not indices:
        return "(в этом ходу не выбраны файлы knowledge/*.txt)"
    uniq = sorted(set(i for i in indices if i > 0))
    if not uniq:
        return "(в этом ходу не выбраны файлы knowledge/*.txt)"
    lines: List[str] = []
    for idx in uniq:
        m = re.search(rf"^## {idx}\s+—\s+(.+)$", index_markdown, re.MULTILINE)
        title = m.group(1).strip() if m else f"индекс {idx}"
        lines.append(f"- {idx}: {title}")
    return "\n".join(lines)


class RagQueryPlannerClient:
    """Structured-output вызов для решения needs_rag + retrieval_query."""

    def __init__(self, api_key: str, model: str, planner_dialog_mode: RagPlannerDialogMode) -> None:
        self._model = model
        self._planner_dialog_mode = planner_dialog_mode
        gpt5_family = "gpt-5" in model.lower()
        chat = ChatOpenAI(
            model=model,
            api_key=api_key,
            temperature=0,
            max_tokens=512,
            max_retries=2,
            reasoning_effort="minimal" if gpt5_family else None,
        ).with_structured_output(RagQueryPlannerDecision)
        self._chain = _planner_prompt_for_mode(planner_dialog_mode) | chat
        logger.debug("RagQueryPlannerClient: model=%s, dialog_mode=%s", model, planner_dialog_mode)

    @classmethod
    def from_openai_settings(
        cls,
        api_key: str,
        router_model: str,
        *,
        planner_dialog_mode: RagPlannerDialogMode,
    ) -> RagQueryPlannerClient:
        env_model = os.environ.get("RAG_QUERY_PLANNER_MODEL", "").strip()
        base = router_model.strip() if router_model.strip() else DEFAULT_KNOWLEDGE_ROUTER_MODEL
        model = env_model if env_model else base
        return cls(api_key=api_key, model=model, planner_dialog_mode=planner_dialog_mode)

    async def plan(
        self,
        *,
        user_query: str,
        dialog_snippet: str,
        prompts_summary: str,
        index_markdown: str,
        selected_knowledge_topics: str,
    ) -> RagQueryPlannerDecision:
        raw = await self._chain.ainvoke(
            {
                "user_query": user_query,
                "dialog_snippet": dialog_snippet or "(нет)",
                "prompts_summary": prompts_summary.strip() or "(нет описания prompts/)",
                "index_markdown": index_markdown.strip() or "(нет индекса knowledge)",
                "selected_knowledge_topics": selected_knowledge_topics,
            }
        )
        return normalize_rag_planner_decision(raw)
