"""Qdrant-native RAG: server hybrid (Voyage dense + BM25 Document + RRF) + rerank. Extra ``qdrant-rag``."""

from .bootstrap import create_qdrant_rag_retriever, qdrant_rag_dependencies_available
from .settings import QdrantRagRuntimeConfig, resolve_qdrant_rag_config

__all__ = [
    "QdrantRagRuntimeConfig",
    "create_qdrant_rag_retriever",
    "qdrant_rag_dependencies_available",
    "resolve_qdrant_rag_config",
]
