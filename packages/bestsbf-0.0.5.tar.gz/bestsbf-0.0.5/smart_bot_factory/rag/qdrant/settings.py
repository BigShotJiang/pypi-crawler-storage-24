"""Paths and env-driven settings for Qdrant-native RAG (OpenAI dense, server BM25; Voyage rerank опционально)."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

from ...config import Config

RAG_DATA_DIRNAME = "rag_data"
PARSER_DIRNAME = "parser"
DOCSTORE_FILENAME = "docstore.json"
RAG_STORAGE_DIRNAME = "rag_storage"

# Источник .txt для индекса Qdrant: parser | rag_data | parser_then_rag_data | both
QDRANT_RAG_DATA_SOURCE_DEFAULT = "parser_then_rag_data"


def _sanitize_qdrant_collection_suffix(bot_id: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_-]+", "_", bot_id.strip())
    return s[:120] if s else "default"


def _parse_bool(raw: str, default: bool) -> bool:
    s = raw.strip().lower()
    if s in ("1", "true", "yes", "on"):
        return True
    if s in ("0", "false", "no", "off"):
        return False
    return default


def _dir_has_txt_recursive(directory: Path) -> bool:
    if not directory.is_dir():
        return False
    return any(directory.rglob("*.txt"))


def _resolve_qdrant_data_dirs(bot_config_dir: Path, mode: str) -> Optional[Tuple[Path, ...]]:
    """
    Возвращает корневые каталоги с .txt (рекурсивно) или None, если нечего индексировать.
    mode: parser | rag_data | parser_then_rag_data | both
    """
    rag_dir = bot_config_dir / RAG_DATA_DIRNAME
    parser_dir = bot_config_dir / PARSER_DIRNAME
    mode_n = mode.strip().lower()

    if mode_n == "rag_data":
        if _dir_has_txt_recursive(rag_dir):
            return (rag_dir.resolve(),)
        return None
    if mode_n == "parser":
        if _dir_has_txt_recursive(parser_dir):
            return (parser_dir.resolve(),)
        return None
    if mode_n == "parser_then_rag_data":
        if _dir_has_txt_recursive(parser_dir):
            return (parser_dir.resolve(),)
        if _dir_has_txt_recursive(rag_dir):
            return (rag_dir.resolve(),)
        return None
    if mode_n == "both":
        out: list[Path] = []
        if _dir_has_txt_recursive(parser_dir):
            out.append(parser_dir.resolve())
        if _dir_has_txt_recursive(rag_dir):
            out.append(rag_dir.resolve())
        return tuple(out) if out else None

    raise ValueError(
        f"QDRANT_RAG_DATA_SOURCE must be parser, rag_data, parser_then_rag_data, or both; got {mode!r}",
    )


@dataclass(frozen=True)
class QdrantRagRuntimeConfig:
    """Resolved config for one bot instance."""

    bot_config_dir: Path
    bot_id: str
    data_dir: Path
    data_dirs: Tuple[Path, ...]
    ingest_sources_include_parser: bool
    docstore_path: Path
    qdrant_url: str
    qdrant_collection: str
    qdrant_server_inference: bool
    qdrant_dense_vector_name: str
    qdrant_sparse_vector_name: str
    qdrant_bm25_model: str
    voyage_api_key: str
    openai_embed_model: str
    voyage_rerank_model: str
    openai_api_key: str
    openai_base_url: Optional[str]
    hyde_model: str
    hyde_include_original: bool
    hyde_max_tokens: int
    parent_chunk_size: int
    child_chunk_size: int
    chunk_overlap: int
    vector_top_k: int
    bm25_top_k: int
    hybrid_top_k: int
    qdrant_upsert_batch_size: int
    rerank_top_n: int
    automerge_thresh: float


def resolve_qdrant_rag_config(bot_config_dir: Path, config: Config) -> Optional[QdrantRagRuntimeConfig]:
    """
    Returns ``None`` если нет ни одного .txt в выбранных каталогах (см. QDRANT_RAG_DATA_SOURCE).
    ``VOYAGE_API_KEY`` опционален: без ключа rerank Voyage не вызывается, гибридный поиск остаётся.
    """
    mode = os.getenv("QDRANT_RAG_DATA_SOURCE", QDRANT_RAG_DATA_SOURCE_DEFAULT).strip()
    data_dirs = _resolve_qdrant_data_dirs(bot_config_dir, mode)
    if not data_dirs:
        return None

    parser_resolved = (bot_config_dir / PARSER_DIRNAME).resolve()
    ingest_sources_include_parser = any(p.resolve() == parser_resolved for p in data_dirs)

    voyage_key = os.getenv("VOYAGE_API_KEY", "").strip()

    storage_dir = bot_config_dir / RAG_STORAGE_DIRNAME
    docstore_path = storage_dir / DOCSTORE_FILENAME

    base_collection = os.getenv("QDRANT_COLLECTION", "rag_knowledge").strip() or "rag_knowledge"
    suffix = _sanitize_qdrant_collection_suffix(config.BOT_ID)
    qdrant_collection = f"{base_collection}_{suffix}"

    openai_base = config.OPENAI_BASE_URL.strip() or None
    hyde_model = os.getenv("RAG_HYDE_MODEL", "").strip() or config.OPENAI_ROUTER_MODEL
    hyde_include_original = _parse_bool(os.getenv("RAG_HYDE_INCLUDE_ORIGINAL", "true"), True)
    hyde_max_tokens = int(os.getenv("RAG_HYDE_MAX_TOKENS", "256"))

    vector_top_k = int(os.getenv("RAG_VECTOR_TOP_K", "20"))
    bm25_top_k = int(os.getenv("RAG_BM25_TOP_K", "20"))
    hybrid_top_k_raw = os.getenv("RAG_HYBRID_TOP_K", "").strip()
    hybrid_top_k = (
        int(hybrid_top_k_raw)
        if hybrid_top_k_raw
        else max(vector_top_k, bm25_top_k) * 2
    )

    bm25_model = (
        os.getenv("RAG_QDRANT_BM25_MODEL", "").strip()
        or os.getenv("RAG_QDRANT_SPARSE_MODEL", "").strip()
        or "Qdrant/bm25"
    )

    server_inference_raw = os.getenv("QDRANT_SERVER_INFERENCE", "true")
    qdrant_server_inference = _parse_bool(server_inference_raw, True)

    dense_name = os.getenv("QDRANT_DENSE_VECTOR_NAME", "dense").strip() or "dense"
    sparse_name = os.getenv("QDRANT_SPARSE_VECTOR_NAME", "sparse").strip() or "sparse"

    upsert_batch = int(os.getenv("RAG_QDRANT_UPSERT_BATCH", "32"))

    data_dir = data_dirs[0]

    return QdrantRagRuntimeConfig(
        bot_config_dir=bot_config_dir,
        bot_id=config.BOT_ID,
        data_dir=data_dir,
        data_dirs=data_dirs,
        ingest_sources_include_parser=ingest_sources_include_parser,
        docstore_path=docstore_path,
        qdrant_url=os.getenv("QDRANT_URL", "http://localhost:6333").strip(),
        qdrant_collection=qdrant_collection,
        qdrant_server_inference=qdrant_server_inference,
        qdrant_dense_vector_name=dense_name,
        qdrant_sparse_vector_name=sparse_name,
        qdrant_bm25_model=bm25_model,
        voyage_api_key=voyage_key,
        openai_embed_model=os.getenv("RAG_OPENAI_EMBED_MODEL", "text-embedding-3-small").strip()
        or "text-embedding-3-small",
        voyage_rerank_model=os.getenv("VOYAGE_RERANK_MODEL", "rerank-2.5").strip()
        or "rerank-2.5",
        openai_api_key=config.OPENAI_API_KEY,
        openai_base_url=openai_base,
        hyde_model=hyde_model,
        hyde_include_original=hyde_include_original,
        hyde_max_tokens=hyde_max_tokens,
        parent_chunk_size=int(os.getenv("RAG_PARENT_CHUNK_TOKENS", "1024")),
        child_chunk_size=int(os.getenv("RAG_CHILD_CHUNK_TOKENS", "256")),
        chunk_overlap=int(os.getenv("RAG_CHUNK_OVERLAP", "40")),
        vector_top_k=vector_top_k,
        bm25_top_k=bm25_top_k,
        hybrid_top_k=hybrid_top_k,
        qdrant_upsert_batch_size=upsert_batch,
        rerank_top_n=int(os.getenv("RAG_RERANK_TOP_N", "5")),
        automerge_thresh=float(os.getenv("RAG_AUTOMERGE_THRESH", "0.5")),
    )
