"""Debug CLI and programmatic entry: one Qdrant RAG query for a bot directory.

Run (with extra ``qdrant-rag``, Qdrant with server-side inference for ``Qdrant/bm25``, and a valid bot ``.env``)::

    uv run python -m smart_bot_factory.rag.qdrant.debug_query --bot-dir bots/my-bot "Вопрос"

Requires the same env as the bot: ``BOT_ID``, ``OPENAI_API_KEY``, Qdrant URL, и .txt в каталогах по ``QDRANT_RAG_DATA_SOURCE`` (например ``parser/`` или ``rag_data/``).
``VOYAGE_API_KEY`` опционален (rerank Voyage); без него поиск работает без переранжирования.
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

from .bootstrap import create_qdrant_rag_retriever
from .settings import QdrantRagRuntimeConfig

logger = logging.getLogger(__name__)

_BOT_ID_RE = re.compile(r"^[a-z0-9\-]+$")


@dataclass(frozen=True)
class _EnvBackedRagConfig:
    """Minimal duck config for ``resolve_qdrant_rag_config`` (same fields as used there)."""

    BOT_ID: str
    OPENAI_API_KEY: str
    OPENAI_BASE_URL: str
    OPENAI_ROUTER_MODEL: str


def _config_from_env(bot_id: str) -> _EnvBackedRagConfig:
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise ValueError("OPENAI_API_KEY is not set (load bot .env or export it).")
    base_url = os.getenv("OPENAI_BASE_URL", "").strip()
    router_model = os.getenv("OPENAI_ROUTER_MODEL", "gpt-5-mini").strip() or "gpt-5-mini"
    return _EnvBackedRagConfig(
        BOT_ID=bot_id,
        OPENAI_API_KEY=api_key,
        OPENAI_BASE_URL=base_url,
        OPENAI_ROUTER_MODEL=router_model,
    )


def _prepare_bot_env(bot_config_dir: Path, bot_id: Optional[str]) -> str:
    """Load ``bot_config_dir/.env``, set ``PROMT_FILES_DIR`` like BotBuilder, return resolved ``bot_id``."""
    bot_config_dir = bot_config_dir.resolve()
    if not bot_config_dir.is_dir():
        raise FileNotFoundError(f"Not a directory: {bot_config_dir}")

    env_file = bot_config_dir / ".env"
    if env_file.is_file():
        from dotenv import load_dotenv

        load_dotenv(env_file)

    resolved_id = (bot_id or os.getenv("BOT_ID", "")).strip()
    if not resolved_id:
        raise ValueError("BOT_ID is missing: pass --bot-id or set it in the bot .env.")
    if not _BOT_ID_RE.match(resolved_id):
        raise ValueError(
            f"BOT_ID must contain only lowercase letters, digits, hyphens: {resolved_id!r}"
        )

    os.environ["BOT_ID"] = resolved_id
    prompts_subdir = os.environ.get("PROMT_FILES_DIR", "prompts")
    prompts_dir = bot_config_dir / prompts_subdir
    os.environ["PROMT_FILES_DIR"] = str(prompts_dir)
    return resolved_id


async def query(
    bot_config_dir: Path,
    question: str,
    *,
    bot_id: Optional[str] = None,
) -> Tuple[List[str], Optional[QdrantRagRuntimeConfig]]:
    """
    Build the same retriever as the live bot and return ranked chunk texts plus resolved config.

    Raises if optional deps are missing, Qdrant RAG is disabled, or retrieval fails.
    """
    resolved_bot_id = _prepare_bot_env(bot_config_dir, bot_id)
    cfg = _config_from_env(resolved_bot_id)
    retriever, resolved = await create_qdrant_rag_retriever(bot_config_dir, cfg)  # type: ignore[arg-type]
    if retriever is None:
        raise RuntimeError(
            "Qdrant RAG is not active: install extra qdrant-rag, add parser/*.txt or rag_data/*.txt (see QDRANT_RAG_DATA_SOURCE), set OPENAI_API_KEY, "
            "and ensure Qdrant is reachable."
        )
    chunks = await retriever.aretrieve(question)
    return chunks, resolved


async def _async_main(argv: Optional[List[str]] = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    parser = argparse.ArgumentParser(description="Run one Qdrant RAG query for a bot directory.")
    parser.add_argument(
        "--bot-dir",
        type=Path,
        required=True,
        help="Path to bot config directory (contains rag_data/, optional .env).",
    )
    parser.add_argument(
        "--bot-id",
        default=None,
        help="Override BOT_ID (default: from .env after load).",
    )
    parser.add_argument(
        "question",
        nargs="?",
        default=None,
        help="User question. If omitted, read one line from stdin.",
    )
    args = parser.parse_args(argv)

    q = args.question
    if not q or not str(q).strip():
        q = sys.stdin.readline()
    q = (q or "").strip()
    if not q:
        logger.error("Empty question.")
        return 2

    try:
        chunks, resolved = await query(args.bot_dir, q, bot_id=args.bot_id)
    except Exception as e:
        logger.error("%s", e)
        return 1

    if resolved is not None:
        print(f"# collection={resolved.qdrant_collection} chunks={len(chunks)}", file=sys.stderr)
    for i, text in enumerate(chunks, start=1):
        print(f"--- {i} ---\n{text}\n")
    return 0


def main() -> None:
    raise SystemExit(asyncio.run(_async_main()))


if __name__ == "__main__":
    main()
