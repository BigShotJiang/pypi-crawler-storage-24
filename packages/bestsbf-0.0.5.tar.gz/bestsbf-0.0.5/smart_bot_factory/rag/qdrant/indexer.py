"""Hierarchical chunking + docstore + Qdrant via QdrantVectorStore / VectorStoreIndex."""

from __future__ import annotations

import logging
import os

from llama_index.core import SimpleDirectoryReader, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser, get_leaf_nodes
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.storage.storage_context import StorageContext

from .hybrid import ensure_hybrid_collection, qdrant_rag_http_client
from .openai_embed import dense_embedding_dimension, qdrant_rag_openai_embedding
from .llama_vector_store import qdrant_rag_vector_store
from .settings import QdrantRagRuntimeConfig

logger = logging.getLogger(__name__)


def _parse_bool(raw: str, default: bool) -> bool:
    s = raw.strip().lower()
    if s in ("1", "true", "yes", "on"):
        return True
    if s in ("0", "false", "no", "off"):
        return False
    return default


def _load_documents_from_data_dirs(data_dirs: tuple[Path, ...]) -> list:
    documents: list = []
    for d in data_dirs:
        if not d.is_dir():
            logger.warning("Qdrant RAG indexer: пропуск несуществующего каталога %s", d)
            continue
        batch = SimpleDirectoryReader(
            input_dir=str(d),
            recursive=True,
            required_exts=[".txt"],
        ).load_data()
        documents.extend(batch)
    return documents


def build_qdrant_rag_index(cfg: QdrantRagRuntimeConfig) -> None:
    """
    Читает все cfg.data_dirs (рекурсивно .txt), иерархический чанкинг parent/child,
    docstore, коллекция Qdrant, только листовые ноды в VectorStoreIndex.
    """
    documents = _load_documents_from_data_dirs(cfg.data_dirs)
    if not documents:
        raise ValueError(f"Qdrant RAG: нет документов в {cfg.data_dirs}")

    node_parser = HierarchicalNodeParser.from_defaults(
        chunk_sizes=[cfg.parent_chunk_size, cfg.child_chunk_size],
        chunk_overlap=cfg.chunk_overlap,
    )
    all_nodes = node_parser.get_nodes_from_documents(documents)
    leaf_nodes = get_leaf_nodes(all_nodes)
    logger.info(
        "Qdrant RAG indexer: каталогов=%s, документов=%s, всего нод=%s, leaf=%s",
        len(cfg.data_dirs),
        len(documents),
        len(all_nodes),
        len(leaf_nodes),
    )

    embed_model = qdrant_rag_openai_embedding(cfg)

    dim = dense_embedding_dimension(embed_model)
    client = qdrant_rag_http_client(cfg)
    ensure_hybrid_collection(client, cfg, dim)

    vector_store = qdrant_rag_vector_store(cfg, client)
    docstore = SimpleDocumentStore()
    docstore.add_documents(all_nodes, allow_update=True)

    storage_context = StorageContext.from_defaults(
        vector_store=vector_store,
        docstore=docstore,
    )
    index = VectorStoreIndex(
        nodes=[],
        storage_context=storage_context,
        embed_model=embed_model,
    )
    index.insert_nodes(leaf_nodes)

    cfg.docstore_path.parent.mkdir(parents=True, exist_ok=True)
    docstore.persist(str(cfg.docstore_path))
    logger.info("Qdrant RAG: docstore сохранён в %s", cfg.docstore_path)


def delete_qdrant_collection_if_exists(cfg: QdrantRagRuntimeConfig) -> None:
    """Удаляет коллекцию Qdrant целиком (полная пересборка индекса)."""
    client = qdrant_rag_http_client(cfg)
    if client.collection_exists(cfg.qdrant_collection):
        client.delete_collection(collection_name=cfg.qdrant_collection)
        logger.info("Qdrant RAG: удалена коллекция %s", cfg.qdrant_collection)


def rebuild_qdrant_rag_index(cfg: QdrantRagRuntimeConfig) -> None:
    """Удаляет docstore и коллекцию Qdrant, затем строит индекс заново."""
    if cfg.docstore_path.is_file():
        cfg.docstore_path.unlink()
        logger.info("Qdrant RAG: удалён docstore %s", cfg.docstore_path)
    delete_qdrant_collection_if_exists(cfg)
    build_qdrant_rag_index(cfg)


def load_qdrant_rag_index_verified(cfg: QdrantRagRuntimeConfig) -> None:
    """Ensure docstore exists on disk (Qdrant collection is assumed already populated)."""
    if not cfg.docstore_path.is_file():
        raise FileNotFoundError(f"Qdrant RAG: нет docstore: {cfg.docstore_path}")


def ensure_qdrant_rag_index(cfg: QdrantRagRuntimeConfig) -> None:
    """Build index if docstore missing; optional QDRANT_FORCE_REBUILD_ON_START; otherwise verify paths."""
    force = _parse_bool(os.getenv("QDRANT_FORCE_REBUILD_ON_START", "false"), False)
    if force:
        logger.info("Qdrant RAG: QDRANT_FORCE_REBUILD_ON_START=true — полная пересборка")
        rebuild_qdrant_rag_index(cfg)
        return
    if cfg.docstore_path.is_file():
        load_qdrant_rag_index_verified(cfg)
        return
    build_qdrant_rag_index(cfg)
