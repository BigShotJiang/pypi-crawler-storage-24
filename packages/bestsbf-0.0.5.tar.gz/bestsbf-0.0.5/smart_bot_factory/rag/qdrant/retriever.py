"""HyDE + QdrantVectorStore hybrid (dense + BM25 + RRF) + AutoMerge; rerank Voyage только при VOYAGE_API_KEY."""

from __future__ import annotations

import asyncio
import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

from llama_index.core.base.base_retriever import BaseRetriever
from llama_index.core.callbacks.base import CallbackManager
from llama_index.core.indices.query.query_transform import HyDEQueryTransform
from llama_index.core.retrievers import AutoMergingRetriever
from llama_index.core.schema import NodeWithScore, QueryBundle
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.storage.storage_context import StorageContext
from llama_index.core.vector_stores.types import VectorStoreQuery, VectorStoreQueryMode
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.llms.openai import OpenAI as LlamaOpenAILLM

from .hybrid import qdrant_rag_http_client
from .openai_embed import qdrant_rag_openai_embedding
from .llama_vector_store import QdrantServerBm25VectorStore, qdrant_rag_vector_store
from .settings import QdrantRagRuntimeConfig


class _QdrantFusionRetriever(BaseRetriever):
    """Hybrid retrieval via QdrantVectorStore.query (dense + server BM25 + RRF)."""

    def __init__(
        self,
        cfg: QdrantRagRuntimeConfig,
        embed_model: BaseEmbedding,
        docstore: SimpleDocumentStore,
        vector_store: QdrantServerBm25VectorStore,
    ) -> None:
        self._cfg = cfg
        self._embed_model = embed_model
        self._docstore = docstore
        self._vector_store = vector_store
        super().__init__(callback_manager=CallbackManager())

    def _retrieve(self, query_bundle: QueryBundle) -> List[NodeWithScore]:
        question = query_bundle.query_str
        emb_inputs = [s for s in query_bundle.embedding_strs if s and s.strip()]
        if not emb_inputs:
            emb_inputs = [question]
        dense = self._embed_model.get_agg_embedding_from_queries(emb_inputs)
        dense_list = list(dense)
        vs_query = VectorStoreQuery(
            query_embedding=dense_list,
            query_str=question,
            mode=VectorStoreQueryMode.HYBRID,
            similarity_top_k=self._cfg.vector_top_k,
            sparse_top_k=self._cfg.bm25_top_k,
            hybrid_top_k=self._cfg.hybrid_top_k,
        )
        result = self._vector_store.query(vs_query)
        nodes = result.nodes or []
        sims = result.similarities if result.similarities is not None else [0.0] * len(nodes)
        out: List[NodeWithScore] = []
        for node, score in zip(nodes, sims):
            nid = str(node.node_id)
            stored = self._docstore.get_document(nid, raise_error=False)
            resolved = stored if stored is not None else node
            s = float(score) if score is not None else 0.0
            out.append(NodeWithScore(node=resolved, score=s))
        return out


class QdrantRagRetriever:
    """Async-friendly retriever; HyDE + Qdrant + LlamaIndex run sync inside a thread pool."""

    def __init__(self, cfg: QdrantRagRuntimeConfig) -> None:
        self._cfg = cfg
        self._docstore = SimpleDocumentStore.from_persist_path(str(cfg.docstore_path))
        self._embed_model = qdrant_rag_openai_embedding(cfg)
        api_base = cfg.openai_base_url if cfg.openai_base_url and cfg.openai_base_url.strip() else None
        hyde_llm = LlamaOpenAILLM(
            model=cfg.hyde_model,
            temperature=0.0,
            max_tokens=cfg.hyde_max_tokens,
            api_key=cfg.openai_api_key,
            api_base=api_base,
            max_retries=3,
            timeout=60.0,
        )
        self._hyde_transform = HyDEQueryTransform(
            llm=hyde_llm,
            include_original=cfg.hyde_include_original,
        )
        self._voyage: Optional[object] = None
        if cfg.voyage_api_key.strip():
            try:
                import voyageai
            except ImportError as e:
                raise ImportError(
                    "VOYAGE_API_KEY задан, но пакет voyageai не установлен. "
                    "Установите зависимости: uv sync --extra qdrant-rag"
                ) from e
            self._voyage = voyageai.Client(api_key=cfg.voyage_api_key)

        client = qdrant_rag_http_client(cfg)
        vector_store = qdrant_rag_vector_store(cfg, client)
        fusion = _QdrantFusionRetriever(cfg, self._embed_model, self._docstore, vector_store)
        storage_context = StorageContext.from_defaults(docstore=self._docstore)
        self._auto_retriever = AutoMergingRetriever(
            vector_retriever=fusion,
            storage_context=storage_context,
            simple_ratio_thresh=cfg.automerge_thresh,
            verbose=False,
        )

    def _rerank(self, question: str, chunks: List[str], top_n: int) -> List[str]:
        if not chunks:
            return []
        limit = min(top_n, len(chunks))
        if self._voyage is None:
            return chunks[:limit]
        model = self._cfg.voyage_rerank_model.strip() or "rerank-2.5"
        result = self._voyage.rerank(
            query=question,
            documents=chunks,
            model=model,
            top_k=limit,
        )
        out: List[str] = []
        for item in result.results:
            idx = item.index
            if 0 <= idx < len(chunks):
                out.append(chunks[idx])
        return out

    def _retrieve_sync(self, question: str) -> List[str]:
        logger.info("Qdrant RAG query: %r", question)
        try:
            bundle = self._hyde_transform.run(question)
            if not any(s.strip() for s in bundle.embedding_strs):
                logger.warning("Qdrant RAG: HyDE вернул пустые строки, используем оригинальный вопрос")
                bundle = QueryBundle(query_str=question, embedding_strs=[question])
        except Exception as e:
            logger.warning("Qdrant RAG: HyDE упал (%s), используем оригинальный вопрос", e)
            bundle = QueryBundle(query_str=question, embedding_strs=[question])
        vector_nodes = self._auto_retriever.retrieve(bundle)
        fused: List[str] = []
        for nws in vector_nodes:
            text = nws.node.get_content()
            if text and text.strip():
                fused.append(text.strip())
        logger.debug("Qdrant RAG: retrieved %d chunks before rerank", len(fused))
        result = self._rerank(question, fused, self._cfg.rerank_top_n)
        logger.info("Qdrant RAG: returning %d chunks after rerank", len(result))
        return result

    async def aretrieve(self, question: str) -> List[str]:
        stripped = question.strip()
        if not stripped:
            return []
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, lambda: self._retrieve_sync(stripped))
