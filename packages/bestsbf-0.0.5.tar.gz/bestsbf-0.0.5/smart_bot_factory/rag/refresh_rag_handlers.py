"""Обработчики команды «Обновить RAG» для админов."""

import asyncio
import logging
from typing import Any, Optional

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from ..utils.context import ctx

logger = logging.getLogger(__name__)

refresh_rag_router = Router(name="refresh_rag")

REFRESH_RAG_COMMANDS = ("refresh_rag", "обновить_rag")


def _get_rag_pipeline() -> Optional[Any]:
    """Возвращает пайплайн обновления RAG из контекста (ParserRagPipeline или None)."""
    return getattr(ctx, "rag_pipeline", None)


async def _safe_send(chat_id: int, text: str, log_label: str = "уведомление") -> None:
    """Отправляет сообщение в чат; при ошибке только логирует."""
    bot = getattr(ctx, "bot", None)
    if not bot:
        return
    try:
        await bot.send_message(chat_id, text)
    except Exception:
        logger.exception("Не удалось отправить %s обновления RAG в чат %s", log_label, chat_id)


async def _run_pipeline_and_notify(chat_id: int) -> None:
    """Запускает pipeline.run() и отправляет результат в чат (для фонового режима)."""
    pipeline = _get_rag_pipeline()
    if not pipeline or not getattr(ctx, "bot", None):
        return
    try:
        result = await pipeline.run()
        await _safe_send(chat_id, result.to_short_message(), "результат")
    except Exception as exc:
        logger.exception("Ошибка при обновлении RAG в фоне")
        await _safe_send(chat_id, f"❌ Ошибка обновления RAG: {exc}", "сообщение об ошибке")


@refresh_rag_router.message(Command(commands=REFRESH_RAG_COMMANDS))
async def refresh_rag_command(message: Message) -> None:
    """Запускает обновление RAG (парсинг + очистка + ингест). Только для админов."""
    if not message.from_user:
        return
    if not ctx.admin_manager:
        await message.answer("❌ Менеджер админов не настроен.")
        return
    if not ctx.admin_manager.is_admin(message.from_user.id):
        await message.answer("⛔ Доступ только для администраторов.")
        return
    pipeline = _get_rag_pipeline()
    if pipeline is None:
        await message.answer("ℹ️ Обновление RAG не настроено для этого бота (rag_pipeline не задан).")
        return
    lock = getattr(pipeline, "_lock", None)
    if lock is not None and lock.locked():
        await message.answer("⏳ Обновление RAG уже выполняется, подождите.")
        return
    await message.answer("⏳ Обновление RAG запущено в фоне, результат придёт позже. Это может занять несколько минут.")
    asyncio.create_task(_run_pipeline_and_notify(message.chat.id))
