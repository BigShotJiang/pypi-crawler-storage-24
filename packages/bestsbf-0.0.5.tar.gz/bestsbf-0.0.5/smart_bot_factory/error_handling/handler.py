"""
Централизованный обработчик ошибок
"""

import asyncio
import logging
from collections import defaultdict
from typing import Any, Callable, Dict, Optional

from .retry import RetryStrategy

from .exceptions import (
    BotBlockedError,
    ConfigurationError,
    OpenAIError,
    OpenAIRateLimitError,
    SmartBotFactoryError,
    SupabaseError,
    TelegramError,
    TelegramRateLimitError,
    ValidationError,
)

logger = logging.getLogger(__name__)


class ErrorHandler:
    """
    Централизованный обработчик всех ошибок в библиотеке

    Основные возможности:
    - Классификация ошибок по типу
    - Structured logging
    - Метрики ошибок
    - Специфичная обработка по типу
    - Fallback механизмы
    """

    def __init__(self, config=None):
        """
        Args:
            config: Конфигурация бота (опционально)
        """
        self.config = config
        self.error_counts = defaultdict(int)
        self._error_history = []
        self.max_history = 100

        # Настройки retry (можно переопределить через config)
        self.enable_retry = getattr(config, "ENABLE_ERROR_RETRY", True) if config else True
        self.retry_strategies = self._init_retry_strategies()

    def _init_retry_strategies(self) -> Dict[str, RetryStrategy]:
        """Инициализация стратегий retry для разных типов ошибок"""
        from .retry import (
            OPENAI_RETRY_STRATEGY,
            RATE_LIMIT_RETRY_STRATEGY,
            SUPABASE_RETRY_STRATEGY,
            TELEGRAM_RETRY_STRATEGY,
        )

        return {
            "openai": OPENAI_RETRY_STRATEGY,
            "supabase": SUPABASE_RETRY_STRATEGY,
            "telegram": TELEGRAM_RETRY_STRATEGY,
            "rate_limit": RATE_LIMIT_RETRY_STRATEGY,
        }

    def get_retry_strategy(self, error_type: str) -> Optional[RetryStrategy]:
        """
        Получить стратегию retry для типа ошибки

        Args:
            error_type: Тип ошибки

        Returns:
            RetryStrategy или None
        """
        if not self.enable_retry:
            return None
        return self.retry_strategies.get(error_type)

    async def handle(
        self, error: Exception, context: Optional[Dict[str, Any]] = None, fallback: Optional[Callable] = None, suppress: bool = False
    ) -> Any:
        """
        Центральная точка обработки всех ошибок

        Args:
            error: Исключение для обработки
            context: Контекст ошибки (user_id, session_id, function и т.д.)
            fallback: Функция fallback, если ошибка не recoverable
            suppress: Подавлять ли исключение (True = не пробрасывать дальше)

        Returns:
            Результат fallback функции или None

        Raises:
            Exception: Если suppress=False, пробрасывает оригинальное исключение
        """
        context = context or {}

        # Классифицируем ошибку
        error_type = self._classify_error(error)

        # Логируем structured
        self._log_error(error, error_type, context)

        # Обновляем метрики
        self._update_metrics(error_type)

        # Сохраняем в историю
        self._add_to_history(error, error_type, context)

        # Специфичная обработка по типу
        result = None
        try:
            if error_type == "bot_blocked":
                result = await self._handle_bot_blocked(error, context)
            elif error_type == "rate_limit":
                result = await self._handle_rate_limit(error, context)
            elif error_type == "api_error":
                result = await self._handle_api_error(error, context)
            elif error_type == "timeout":
                result = await self._handle_timeout(error, context)
            elif error_type == "validation":
                result = await self._handle_validation(error, context)
            else:
                result = await self._handle_unknown(error, context)
        except Exception as handler_error:
            logger.error(f"Ошибка в обработчике ошибок: {handler_error}")

        # Fallback если есть
        if fallback:
            try:
                fallback_result = fallback(error, context) if not asyncio.iscoroutinefunction(fallback) else await fallback(error, context)
                return fallback_result
            except Exception as fallback_error:
                logger.error(f"Ошибка в fallback функции: {fallback_error}")

        # Если не suppress, пробрасываем дальше
        if not suppress:
            raise error

        return result

    def _classify_error(self, error: Exception) -> str:
        """
        Классифицирует ошибку по типу

        Returns:
            Строка с типом ошибки: bot_blocked, rate_limit, api_error, timeout, validation, unknown
        """
        # Проверяем кастомные исключения
        if isinstance(error, BotBlockedError):
            return "bot_blocked"
        if isinstance(error, (OpenAIRateLimitError, TelegramRateLimitError)):
            return "rate_limit"
        if isinstance(error, (OpenAIError, SupabaseError, TelegramError)):
            return "api_error"
        if isinstance(error, ValidationError):
            return "validation"
        if isinstance(error, ConfigurationError):
            return "configuration"

        # Проверяем по строковому представлению (для совместимости со старым кодом)
        error_str = str(error).lower()
        error_type_name = type(error).__name__

        if "bot was blocked" in error_str or "telegramforbiddenerror" in error_type_name.lower():
            return "bot_blocked"
        if "rate_limit" in error_str or "429" in error_str:
            return "rate_limit"
        if "timeout" in error_str or "timed out" in error_str:
            return "timeout"
        if any(keyword in error_str for keyword in ["connection", "network", "unreachable"]):
            return "connection"

        return "unknown"

    def _log_error(self, error: Exception, error_type: str, context: Dict):
        """
        Структурированное логирование ошибки
        """
        log_data = {"error_type": error_type, "error_class": type(error).__name__, "error_message": str(error), **context}

        # Добавляем контекст из SmartBotFactoryError
        if isinstance(error, SmartBotFactoryError):
            log_data["error_code"] = error.error_code
            log_data.update(error.context)

        logger.error(
            f"Error occurred: {error_type}",
            extra=log_data,
            exc_info=error_type == "unknown",  # Полный traceback только для unknown
        )

    def _update_metrics(self, error_type: str):
        """Обновляет счетчики ошибок для метрик"""
        self.error_counts[error_type] += 1
        self.error_counts["total"] += 1

    def _add_to_history(self, error: Exception, error_type: str, context: Dict):
        """Добавляет ошибку в историю (для отладки)"""
        import datetime

        self._error_history.append(
            {
                "timestamp": datetime.datetime.now().isoformat(),
                "error_type": error_type,
                "error_class": type(error).__name__,
                "error_message": str(error),
                "context": context,
            }
        )

        # Ограничиваем размер истории
        if len(self._error_history) > self.max_history:
            self._error_history = self._error_history[-self.max_history :]

    async def _handle_bot_blocked(self, error: Exception, context: Dict) -> Dict:
        """
        Обработка блокировки бота пользователем

        Returns:
            Словарь с результатом обработки
        """
        user_id = context.get("user_id")
        if not user_id:
            # Пытаемся извлечь из ошибки
            if isinstance(error, BotBlockedError):
                user_id = error.context.get("user_id")

        if not user_id:
            logger.warning("⚠️ Не удалось определить user_id для bot_blocked ошибки")
            return {"status": "blocked", "user_id": None}

        logger.warning(f"🚫 Бот заблокирован пользователем {user_id}")

        # Отмечаем в базе
        try:
            from ..utils.context import ctx

            if ctx.supabase_client:
                await ctx.supabase_client.mark_user_blocked(user_id)
                logger.info(f"✅ Пользователь {user_id} отмечен как заблокировавший бота")
        except Exception as e:
            logger.error(f"❌ Не удалось обновить статус блокировки в БД: {e}")

        return {"status": "blocked", "user_id": user_id}

    async def _handle_rate_limit(self, error: Exception, context: Dict) -> Dict:
        """
        Обработка rate limit ошибок

        Returns:
            Словарь с информацией о rate limit
        """
        logger.warning(f"⏱️ Rate limit exceeded: {error}")

        return {"status": "rate_limited", "error_type": type(error).__name__, "message": str(error)}

    async def _handle_api_error(self, error: Exception, context: Dict) -> Dict:
        """
        Обработка общих API ошибок

        Returns:
            Словарь с информацией об ошибке
        """
        logger.error(f"🔌 API error: {error}")

        return {"status": "api_error", "error_type": type(error).__name__, "message": str(error), "context": context}

    async def _handle_timeout(self, error: Exception, context: Dict) -> Dict:
        """Обработка timeout ошибок"""
        logger.warning(f"⏰ Timeout: {error}")
        return {"status": "timeout", "message": str(error)}

    async def _handle_validation(self, error: Exception, context: Dict) -> Dict:
        """Обработка ошибок валидации"""
        logger.warning(f"✋ Validation error: {error}")
        return {"status": "validation_error", "message": str(error)}

    async def _handle_unknown(self, error: Exception, context: Dict) -> Dict:
        """Обработка неизвестных ошибок"""
        logger.error(f"❓ Unknown error: {error}", exc_info=True)
        return {"status": "unknown_error", "message": str(error)}

    def get_metrics(self) -> Dict[str, int]:
        """
        Получить метрики ошибок

        Returns:
            Словарь с количеством ошибок по типам
        """
        return dict(self.error_counts)

    def get_error_history(self, limit: int = 10) -> list:
        """
        Получить последние ошибки из истории

        Args:
            limit: Максимальное количество ошибок для возврата

        Returns:
            Список последних ошибок
        """
        return self._error_history[-limit:]

    def clear_metrics(self):
        """Очистить счетчики метрик"""
        self.error_counts.clear()

    def clear_history(self):
        """Очистить историю ошибок"""
        self._error_history.clear()


# Глобальный singleton
_error_handler: Optional[ErrorHandler] = None


def get_error_handler() -> ErrorHandler:
    """
    Получить глобальный экземпляр ErrorHandler

    Returns:
        Singleton экземпляр ErrorHandler
    """
    global _error_handler
    if _error_handler is None:
        _error_handler = ErrorHandler()
    return _error_handler


def set_error_handler(handler: ErrorHandler):
    """
    Установить кастомный ErrorHandler

    Args:
        handler: Экземпляр ErrorHandler
    """
    global _error_handler
    _error_handler = handler
