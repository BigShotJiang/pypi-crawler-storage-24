"""
Context manager для обработки ошибок
"""

from contextlib import asynccontextmanager
from typing import Any, Callable, Dict, Optional

from .handler import get_error_handler


@asynccontextmanager
async def error_boundary(context: Optional[Dict[str, Any]] = None, fallback: Optional[Callable] = None, suppress: bool = False, error_handler=None):
    """
    Context manager для централизованной обработки ошибок

    Args:
        context: Контекст для логирования (user_id, session_id и т.д.)
        fallback: Функция fallback при ошибке
        suppress: Подавлять ли исключение (True = не пробрасывать)
        error_handler: Кастомный ErrorHandler (по умолчанию глобальный)

    Usage:
        async with error_boundary(context={"user_id": 123}):
            await risky_operation()

        # С fallback:
        async with error_boundary(
            context={"user_id": 123},
            fallback=lambda err, ctx: {"status": "error"}
        ):
            await risky_operation()

        # С подавлением ошибок:
        async with error_boundary(suppress=True):
            await risky_operation()  # Не упадет, даже если ошибка
    """
    handler = error_handler or get_error_handler()

    try:
        yield
    except Exception as e:
        await handler.handle(error=e, context=context, fallback=fallback, suppress=suppress)
        if not suppress:
            raise


def sync_error_boundary(context: Optional[Dict[str, Any]] = None, fallback: Optional[Callable] = None, suppress: bool = False, error_handler=None):
    """
    Синхронная версия error_boundary (для неасинхронного кода)

    Использование аналогично async версии, но без async/await
    """
    import asyncio
    from contextlib import contextmanager

    @contextmanager
    def _boundary():
        handler = error_handler or get_error_handler()

        try:
            yield
        except Exception as e:
            # Синхронная обработка
            result = asyncio.run(handler.handle(error=e, context=context, fallback=fallback, suppress=suppress))

            if suppress:
                return result

    return _boundary()
