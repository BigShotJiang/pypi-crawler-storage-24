"""
Утилиты для упрощения миграции на новую систему error handling
"""

from typing import Optional


def is_bot_blocked_error(error: Exception) -> bool:
    """
    Проверяет, является ли ошибка блокировкой бота (для обратной совместимости)

    Args:
        error: Исключение для проверки

    Returns:
        True если это ошибка блокировки бота
    """
    from .exceptions import BotBlockedError

    if isinstance(error, BotBlockedError):
        return True

    error_str = str(error).lower()
    error_type = type(error).__name__.lower()

    return "bot was blocked" in error_str or "telegramforbiddenerror" in error_type


def convert_to_custom_exception(error: Exception, context: Optional[dict] = None):
    """
    Конвертирует стандартное исключение в кастомное (если возможно)

    Args:
        error: Оригинальное исключение
        context: Контекст ошибки

    Returns:
        Кастомное исключение или оригинальное
    """
    from .exceptions import BotBlockedError, OpenAIRateLimitError, TelegramRateLimitError

    context = context or {}

    # Проверяем bot blocked
    if is_bot_blocked_error(error):
        user_id = context.get("user_id")
        if user_id:
            return BotBlockedError(user_id=user_id, **context)

    # Проверяем rate limit
    error_str = str(error).lower()
    if "rate limit" in error_str or "429" in error_str:
        if "openai" in error_str:
            return OpenAIRateLimitError(str(error), **context)
        return TelegramRateLimitError(str(error), **context)

    # Не удалось конвертировать, возвращаем оригинал
    return error
