"""
Централизованная система обработки ошибок для smart-bot-factory
"""

from .context import error_boundary, sync_error_boundary
from .exceptions import (
    APIError,
    BotBlockedError,
    BusinessLogicError,
    ConfigurationError,
    EventValidationError,
    FileError,
    FileNotFoundError,
    FileProcessingError,
    InvalidConfigError,
    MessageValidationError,
    MissingConfigError,
    OpenAIRateLimitError,
    OpenAITimeoutError,
    OpenAIError,
    SessionNotFoundError,
    SmartBotFactoryError,
    SupabaseConnectionError,
    SupabaseError,
    TelegramError,
    TelegramRateLimitError,
    UserNotFoundError,
    ValidationError,
)
from .handler import ErrorHandler, get_error_handler, set_error_handler
from .middleware import ErrorHandlingMiddleware
from .migration_utils import convert_to_custom_exception, is_bot_blocked_error
from .retry import (
    OPENAI_RETRY_STRATEGY,
    RATE_LIMIT_RETRY_STRATEGY,
    SUPABASE_RETRY_STRATEGY,
    TELEGRAM_RETRY_STRATEGY,
    RetryStrategy,
    with_retry,
)

__all__ = [
    # Exceptions
    "SmartBotFactoryError",
    "APIError",
    "OpenAIError",
    "OpenAIRateLimitError",
    "OpenAITimeoutError",
    "SupabaseError",
    "SupabaseConnectionError",
    "TelegramError",
    "BotBlockedError",
    "TelegramRateLimitError",
    "ValidationError",
    "MessageValidationError",
    "EventValidationError",
    "ConfigurationError",
    "MissingConfigError",
    "InvalidConfigError",
    "BusinessLogicError",
    "SessionNotFoundError",
    "UserNotFoundError",
    "FileError",
    "FileNotFoundError",
    "FileProcessingError",
    # Handler
    "ErrorHandler",
    "get_error_handler",
    "set_error_handler",
    # Context managers
    "error_boundary",
    "sync_error_boundary",
    # Retry
    "RetryStrategy",
    "with_retry",
    "OPENAI_RETRY_STRATEGY",
    "SUPABASE_RETRY_STRATEGY",
    "TELEGRAM_RETRY_STRATEGY",
    "RATE_LIMIT_RETRY_STRATEGY",
    # Migration utils
    "is_bot_blocked_error",
    "convert_to_custom_exception",
    # Middleware
    "ErrorHandlingMiddleware",
]
