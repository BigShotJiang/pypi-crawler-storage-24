"""
Кастомные исключения для smart-bot-factory
"""


class SmartBotFactoryError(Exception):
    """
    Базовое исключение для всех ошибок библиотеки

    Args:
        message: Описание ошибки
        error_code: Код ошибки для идентификации
        **context: Дополнительный контекст (user_id, session_id и т.д.)
    """

    def __init__(self, message: str, error_code: str = None, **context):
        self.message = message
        self.error_code = error_code or self.__class__.__name__
        self.context = context
        super().__init__(message)

    def __str__(self):
        if self.context:
            context_str = ", ".join(f"{k}={v}" for k, v in self.context.items())
            return f"{self.message} [{self.error_code}] ({context_str})"
        return f"{self.message} [{self.error_code}]"


# ============ API ERRORS ============


class APIError(SmartBotFactoryError):
    """Базовая ошибка для всех внешних API"""

    pass


class OpenAIError(APIError):
    """Ошибки OpenAI API"""

    pass


class OpenAIRateLimitError(OpenAIError):
    """Rate limit от OpenAI"""

    pass


class OpenAITimeoutError(OpenAIError):
    """Timeout при запросе к OpenAI"""

    pass


class SupabaseError(APIError):
    """Ошибки Supabase API"""

    pass


class SupabaseConnectionError(SupabaseError):
    """Ошибка подключения к Supabase"""

    pass


class TelegramError(APIError):
    """Ошибки Telegram Bot API"""

    pass


class BotBlockedError(TelegramError):
    """Пользователь заблокировал бота"""

    def __init__(self, user_id: int, **context):
        super().__init__(message=f"Бот заблокирован пользователем {user_id}", error_code="BOT_BLOCKED", user_id=user_id, **context)


class TelegramRateLimitError(TelegramError):
    """Rate limit от Telegram"""

    pass


# ============ VALIDATION ERRORS ============


class ValidationError(SmartBotFactoryError):
    """Ошибки валидации данных"""

    pass


class MessageValidationError(ValidationError):
    """Ошибка валидации сообщения"""

    pass


class EventValidationError(ValidationError):
    """Ошибка валидации события"""

    pass


# ============ CONFIGURATION ERRORS ============


class ConfigurationError(SmartBotFactoryError):
    """Ошибки конфигурации"""

    pass


class MissingConfigError(ConfigurationError):
    """Отсутствует обязательная конфигурация"""

    pass


class InvalidConfigError(ConfigurationError):
    """Невалидная конфигурация"""

    pass


# ============ BUSINESS LOGIC ERRORS ============


class BusinessLogicError(SmartBotFactoryError):
    """Ошибки бизнес-логики"""

    pass


class SessionNotFoundError(BusinessLogicError):
    """Сессия не найдена"""

    def __init__(self, session_id: str, **context):
        super().__init__(message=f"Сессия не найдена: {session_id}", error_code="SESSION_NOT_FOUND", session_id=session_id, **context)


class UserNotFoundError(BusinessLogicError):
    """Пользователь не найден"""

    def __init__(self, user_id: int, **context):
        super().__init__(message=f"Пользователь не найден: {user_id}", error_code="USER_NOT_FOUND", user_id=user_id, **context)


# ============ FILE ERRORS ============


class FileError(SmartBotFactoryError):
    """Ошибки работы с файлами"""

    pass


class FileNotFoundError(FileError):
    """Файл не найден"""

    pass


class FileProcessingError(FileError):
    """Ошибка обработки файла"""

    pass
