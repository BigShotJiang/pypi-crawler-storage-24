"""
Retry механизм для обработки временных сбоев
"""

import asyncio
import logging
from functools import wraps
from typing import Callable, Optional, Tuple, Type

logger = logging.getLogger(__name__)


class RetryStrategy:
    """
    Стратегия повторных попыток

    Args:
        max_attempts: Максимальное количество попыток (по умолчанию 3)
        delay: Начальная задержка между попытками в секундах (по умолчанию 1.0)
        backoff_factor: Множитель для exponential backoff (по умолчанию 2.0)
        max_delay: Максимальная задержка в секундах (по умолчанию 30.0)
        exceptions: Tuple с типами исключений для retry (по умолчанию все Exception)

    Example:
        # Retry для rate limit с большой задержкой
        strategy = RetryStrategy(
            max_attempts=5,
            delay=2.0,
            backoff_factor=3.0,
            exceptions=(OpenAIRateLimitError, TelegramRateLimitError)
        )
    """

    def __init__(
        self,
        max_attempts: int = 3,
        delay: float = 1.0,
        backoff_factor: float = 2.0,
        max_delay: float = 30.0,
        exceptions: Tuple[Type[Exception], ...] = (Exception,),
    ):
        self.max_attempts = max_attempts
        self.delay = delay
        self.backoff_factor = backoff_factor
        self.max_delay = max_delay
        self.exceptions = exceptions

    def calculate_delay(self, attempt: int) -> float:
        """
        Вычисляет задержку для текущей попытки с exponential backoff

        Args:
            attempt: Номер попытки (начиная с 1)

        Returns:
            Задержка в секундах
        """
        delay = self.delay * (self.backoff_factor ** (attempt - 1))
        return min(delay, self.max_delay)


def with_retry(strategy: Optional[RetryStrategy] = None):
    """
    Декоратор для автоматического retry при ошибках

    Args:
        strategy: Стратегия retry (если None, используется стратегия по умолчанию)

    Example:
        @with_retry(RetryStrategy(max_attempts=3))
        async def fetch_data():
            return await api.get_data()
    """
    if strategy is None:
        strategy = RetryStrategy()

    def decorator(func: Callable):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            last_exception = None
            current_delay = strategy.delay

            for attempt in range(1, strategy.max_attempts + 1):
                try:
                    logger.debug(f"Попытка {attempt}/{strategy.max_attempts}: {func.__name__}")
                    return await func(*args, **kwargs)

                except strategy.exceptions as e:
                    last_exception = e

                    # Если это последняя попытка, пробрасываем ошибку
                    if attempt == strategy.max_attempts:
                        logger.error(f"❌ Все {strategy.max_attempts} попытки исчерпаны для {func.__name__}: {e}")
                        break

                    # Вычисляем задержку для следующей попытки
                    current_delay = strategy.calculate_delay(attempt)

                    logger.warning(
                        f"⚠️ Попытка {attempt}/{strategy.max_attempts} не удалась для {func.__name__}: {e}. Повтор через {current_delay:.1f}s"
                    )

                    await asyncio.sleep(current_delay)

            # Все попытки исчерпаны, пробрасываем последнюю ошибку
            raise last_exception

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            """Синхронная версия wrapper"""
            import time

            last_exception = None
            current_delay = strategy.delay

            for attempt in range(1, strategy.max_attempts + 1):
                try:
                    logger.debug(f"Попытка {attempt}/{strategy.max_attempts}: {func.__name__}")
                    return func(*args, **kwargs)

                except strategy.exceptions as e:
                    last_exception = e

                    if attempt == strategy.max_attempts:
                        logger.error(f"❌ Все {strategy.max_attempts} попытки исчерпаны для {func.__name__}: {e}")
                        break

                    current_delay = strategy.calculate_delay(attempt)

                    logger.warning(
                        f"⚠️ Попытка {attempt}/{strategy.max_attempts} не удалась для {func.__name__}: {e}. Повтор через {current_delay:.1f}s"
                    )

                    time.sleep(current_delay)

            raise last_exception

        # Определяем, асинхронная ли функция
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator


# Предопределенные стратегии для разных случаев
OPENAI_RETRY_STRATEGY = RetryStrategy(max_attempts=3, delay=1.0, backoff_factor=2.0, exceptions=(Exception,))

SUPABASE_RETRY_STRATEGY = RetryStrategy(max_attempts=3, delay=0.5, backoff_factor=2.0, exceptions=(Exception,))

TELEGRAM_RETRY_STRATEGY = RetryStrategy(max_attempts=5, delay=1.0, backoff_factor=2.0, max_delay=10.0, exceptions=(Exception,))

RATE_LIMIT_RETRY_STRATEGY = RetryStrategy(max_attempts=5, delay=2.0, backoff_factor=3.0, max_delay=60.0, exceptions=(Exception,))
