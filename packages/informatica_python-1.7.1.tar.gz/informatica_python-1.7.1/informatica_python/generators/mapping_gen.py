from typing import List, Dict
from informatica_python.models import (
    MappingDef, FolderDef, SourceDef, TargetDef,
    TransformationDef, ConnectorDef, InstanceDef, MappletDef,
)
from informatica_python.utils.expression_converter import (
    convert_expression, convert_expression_vectorized,
    convert_sql_expression, convert_filter_vectorized,
    parse_join_condition, parse_lookup_condition,
    parse_aggregate_expression, PANDAS_AGG_MAP,
)
from informatica_python.utils.datatype_map import get_python_type
from informatica_python.utils.lib_adapters import (
    lib_merge, lib_sort, lib_groupby_agg, lib_groupby_first,
    lib_concat, lib_empty_df, lib_copy, lib_rank,
)


def _expand_mapplet_recursive(mapplet, mapplet_map, prefix, depth=0, max_depth=10, visited=None):
    if visited is None:
        visited = set()
    if depth > max_depth:
        return [], []
    if mapplet.name in visited:
        return [], []
    visited.add(mapplet.name)

    transforms = []
    connectors = []
    tx_names = {t.name for t in mapplet.transformations}

    for tx in mapplet.transformations:
        inlined = TransformationDef(
            name=f"{prefix}__{tx.name}",
            type=tx.type,
            description=tx.description,
            reusable=tx.reusable,
            fields=list(tx.fields),
            attributes=list(tx.attributes),
            groups=list(tx.groups),
            metadata_extensions=list(tx.metadata_extensions),
        )
        transforms.append(inlined)

    for conn in mapplet.connectors:
        from informatica_python.models import ConnectorDef
        new_from = f"{prefix}__{conn.from_instance}" if conn.from_instance in tx_names else conn.from_instance
        new_to = f"{prefix}__{conn.to_instance}" if conn.to_instance in tx_names else conn.to_instance
        connectors.append(ConnectorDef(
            from_instance=new_from,
            from_field=conn.from_field,
            from_instance_type=conn.from_instance_type,
            to_instance=new_to,
            to_field=conn.to_field,
            to_instance_type=conn.to_instance_type,
        ))

    for inst in getattr(mapplet, 'instances', []):
        if inst.type == "Mapplet" or (inst.transformation_type or "").lower() == "mapplet":
            nested_name = inst.transformation_name or inst.name
            nested_mapplet = mapplet_map.get(nested_name)
            if not nested_mapplet:
                continue
            nested_prefix = f"{prefix}__{inst.name}"
            nested_tx, nested_conn = _expand_mapplet_recursive(
                nested_mapplet, mapplet_map, nested_prefix,
                depth + 1, max_depth, visited.copy()
            )
            transforms.extend(nested_tx)
            connectors.extend(nested_conn)

    return transforms, connectors


def _inline_mapplets(mapping, folder):
    mapplet_map = {m.name: m for m in folder.mapplets}
    extra_transforms = []
    extra_connectors = []
    mapplet_instances = set()

    for inst in mapping.instances:
        if inst.type == "Mapplet" or (inst.transformation_type or "").lower() == "mapplet":
            mapplet_name = inst.transformation_name or inst.name
            mapplet = mapplet_map.get(mapplet_name)
            if not mapplet:
                continue
            mapplet_instances.add(inst.name)
            prefix = inst.name

            nested_tx, nested_conn = _expand_mapplet_recursive(
                mapplet, mapplet_map, prefix
            )
            extra_transforms.extend(nested_tx)
            extra_connectors.extend(nested_conn)

    rewired_connectors = []
    mapplet_internal_names = set()
    for inst_name in mapplet_instances:
        mapplet_name = None
        for inst in mapping.instances:
            if inst.name == inst_name:
                mapplet_name = inst.transformation_name or inst.name
                break
        mapplet = mapplet_map.get(mapplet_name) if mapplet_name else None
        if mapplet:
            for tx in mapplet.transformations:
                mapplet_internal_names.add(f"{inst_name}__{tx.name}")

    for conn in mapping.connectors:
        if conn.to_instance in mapplet_instances:
            first_tx = None
            for ec in extra_connectors:
                if ec.from_instance == conn.to_instance or ec.to_instance.startswith(f"{conn.to_instance}__"):
                    for et in extra_transforms:
                        if et.name.startswith(f"{conn.to_instance}__"):
                            has_input = any(
                                "INPUT" in (f.porttype or "").upper()
                                for f in et.fields
                                if f.name == conn.to_field
                            )
                            if has_input:
                                first_tx = et.name
                                break
                    if first_tx:
                        break
            if not first_tx:
                for et in extra_transforms:
                    if et.name.startswith(f"{conn.to_instance}__"):
                        first_tx = et.name
                        break
            if first_tx:
                from informatica_python.models import ConnectorDef
                rewired_connectors.append(ConnectorDef(
                    from_instance=conn.from_instance,
                    from_field=conn.from_field,
                    from_instance_type=conn.from_instance_type,
                    to_instance=first_tx,
                    to_field=conn.to_field,
                    to_instance_type=conn.to_instance_type,
                ))
            else:
                rewired_connectors.append(conn)
        elif conn.from_instance in mapplet_instances:
            last_tx = None
            for et in reversed(extra_transforms):
                if et.name.startswith(f"{conn.from_instance}__"):
                    has_output = any(
                        "OUTPUT" in (f.porttype or "").upper()
                        for f in et.fields
                        if f.name == conn.from_field
                    )
                    if has_output:
                        last_tx = et.name
                        break
            if not last_tx:
                for et in reversed(extra_transforms):
                    if et.name.startswith(f"{conn.from_instance}__"):
                        last_tx = et.name
                        break
            if last_tx:
                from informatica_python.models import ConnectorDef
                rewired_connectors.append(ConnectorDef(
                    from_instance=last_tx,
                    from_field=conn.from_field,
                    from_instance_type=conn.from_instance_type,
                    to_instance=conn.to_instance,
                    to_field=conn.to_field,
                    to_instance_type=conn.to_instance_type,
                ))
            else:
                rewired_connectors.append(conn)
        else:
            rewired_connectors.append(conn)

    return extra_transforms, extra_connectors + rewired_connectors, mapplet_instances


def _build_session_conn_overrides(mapping, folder):
    overrides = {}
    for session in folder.sessions:
        if session.mapping_name != mapping.name:
            continue
        for sti in session.transform_instances:
            inst_name = sti.instance_name or sti.transformation_name
            for conn_ref in sti.connections:
                conn_key = conn_ref.connection_name or conn_ref.variable
                if conn_key:
                    overrides[inst_name] = {
                        "connection_name": conn_ref.connection_name,
                        "connection_type": conn_ref.connection_type,
                        "connection_subtype": conn_ref.connection_subtype,
                        "variable": conn_ref.variable,
                    }
            for attr in sti.attributes:
                if attr.name == "Connection Information" and attr.value:
                    if inst_name not in overrides:
                        overrides[inst_name] = {}
                    overrides[inst_name]["connection_info"] = attr.value
                elif attr.name == "Source File Directory" and attr.value:
                    if inst_name not in overrides:
                        overrides[inst_name] = {}
                    overrides[inst_name]["source_file_directory"] = attr.value
                elif attr.name == "Source filename" and attr.value:
                    if inst_name not in overrides:
                        overrides[inst_name] = {}
                    overrides[inst_name]["source_filename"] = attr.value
                elif attr.name == "Output File Directory" and attr.value:
                    if inst_name not in overrides:
                        overrides[inst_name] = {}
                    overrides[inst_name]["output_file_directory"] = attr.value
                elif attr.name == "Output filename" and attr.value:
                    if inst_name not in overrides:
                        overrides[inst_name] = {}
                    overrides[inst_name]["output_filename"] = attr.value
    return overrides


def generate_mapping_code(mapping: MappingDef, folder: FolderDef,
                          data_lib: str = "pandas", mapping_index: int = 1,
                          validate_casts: bool = False) -> str:
    lines = []
    lines.append('"""')
    lines.append(f"Mapping: {mapping.name}")
    lines.append(f"Description: {mapping.description or 'N/A'}")
    lines.append(f"Auto-generated by informatica-python")
    lines.append('"""')
    lines.append("")
    lines.append("import numpy as np")
    lines.append("from helper_functions import *")
    lines.append("")
    lines.append("")

    inlined_transforms, inlined_connectors, mapplet_instance_names = _inline_mapplets(mapping, folder)

    all_transforms = list(mapping.transformations) + inlined_transforms
    if mapplet_instance_names:
        kept_originals = [c for c in mapping.connectors
                          if c.from_instance not in mapplet_instance_names
                          and c.to_instance not in mapplet_instance_names]
        all_connectors = kept_originals + inlined_connectors
    else:
        all_connectors = list(mapping.connectors)

    source_map = _build_source_map(mapping, folder)
    target_map = _build_target_map(mapping, folder)
    transform_map = {t.name: t for t in all_transforms}
    connector_graph = _build_connector_graph(all_connectors)
    instance_map = {i.name: i for i in mapping.instances}
    session_overrides = _build_session_conn_overrides(mapping, folder)

    lines.append(f"def run_{_safe_name(mapping.name)}(config):")
    lines.append(f'    """Execute mapping: {mapping.name}"""')
    lines.append(f"    start_time = log_mapping_start('{mapping.name}')")
    lines.append("")

    has_persistent_vars = any(
        getattr(v, 'is_persistent', 'NO').upper() == 'YES'
        for v in (mapping.variables or [])
    )
    if has_persistent_vars:
        lines.append("    # Load persistent state for mapping variables")
        lines.append("    load_persistent_state()")
        lines.append("")

    if mapping.variables:
        lines.append("    # Mapping Variables")
        for var in mapping.variables:
            safe_var = _safe_name(var.name.replace("$$", ""))
            default = var.default_value or "''"
            if var.datatype.lower() in ("integer", "bigint", "int"):
                default = var.default_value or "0"
            if getattr(var, 'is_persistent', 'NO').upper() == 'YES':
                has_persistent_vars = True
                lines.append(f"    {safe_var} = get_persistent_variable('{mapping.name}', '{safe_var}', {default})")
            else:
                lines.append(f"    {safe_var} = {default}")
        lines.append("")

    if session_overrides:
        lines.append("    # Session connection overrides")
        lines.append(f"    _sess_overrides = {repr(session_overrides)}")
        lines.append("")

    source_dfs = {}
    for src_name, src_def in source_map.items():
        safe = _safe_name(src_name)
        source_dfs[src_name] = f"df_{safe}"

    sq_transforms = [t for t in all_transforms
                     if t.type in ("Source Qualifier", "Application Source Qualifier")]
    if sq_transforms:
        for sq in sq_transforms:
            _generate_source_qualifier(lines, sq, source_map, source_dfs, connector_graph, instance_map, session_overrides)
    else:
        for src_name, src_def in source_map.items():
            safe = _safe_name(src_name)
            override = session_overrides.get(src_name, {})
            lines.append(f"    # Read source: {src_name}")
            if override.get("source_file_directory") or override.get("source_filename"):
                src_dir = override.get("source_file_directory", ".")
                src_file = override.get("source_filename", src_def.name)
                lines.append(f"    _src_path_{safe} = config.get('sources', {{}}).get('{src_def.name}', {{}}).get('file_path',")
                lines.append(f"        os.path.join('{src_dir}', '{src_file}'))")
                if src_def.flatfile:
                    _emit_flatfile_read(lines, safe, src_def, file_path_override=True)
                else:
                    lines.append(f"    df_{safe} = read_file(_src_path_{safe}, config.get('sources', {{}}).get('{src_def.name}', {{}}))")
            elif src_def.database_type and src_def.database_type != "Flat File":
                conn_name = override.get("connection_name") or (_safe_name(src_def.db_name) if src_def.db_name else "default")
                schema = src_def.owner_name or "dbo"
                lines.append(f"    df_{safe} = read_from_db(config, 'SELECT * FROM {schema}.{src_name}', '{conn_name}')")
            elif src_def.flatfile:
                _emit_flatfile_read(lines, safe, src_def)
            else:
                lines.append(f"    df_{safe} = read_file(config.get('sources', {{}}).get('{src_name}', {{}}).get('file_path', '{src_name}'),")
                lines.append(f"                          config.get('sources', {{}}).get('{src_name}', {{}}))")
            lines.append("")

    processing_order = _get_processing_order(all_transforms, connector_graph, sq_transforms)

    for tx in processing_order:
        if tx.type in ("Source Qualifier", "Application Source Qualifier"):
            continue
        _generate_transformation(lines, tx, connector_graph, source_dfs, transform_map, instance_map, data_lib)

    for tgt_name, tgt_def in target_map.items():
        _generate_target_write(lines, tgt_name, tgt_def, connector_graph, source_dfs, transform_map, instance_map, session_overrides, validate_casts=validate_casts)

    if has_persistent_vars:
        lines.append("    # Save persistent mapping variables")
        for var in mapping.variables:
            if getattr(var, 'is_persistent', 'NO').upper() == 'YES':
                safe_var = _safe_name(var.name.replace("$$", ""))
                lines.append(f"    set_persistent_variable('{mapping.name}', '{safe_var}', {safe_var})")
        lines.append("    save_persistent_state()")

    lines.append("")
    lines.append(f"    log_mapping_end('{mapping.name}', start_time)")
    lines.append(f"    logger.info('Mapping {mapping.name} completed successfully')")
    lines.append("")
    lines.append("")
    lines.append("if __name__ == '__main__':")
    lines.append("    import argparse as _ap")
    lines.append("    _parser = _ap.ArgumentParser()")
    lines.append("    _parser.add_argument('--param-file', default=None)")
    lines.append("    _parser.add_argument('--config', default='config.yml')")
    lines.append("    _args = _parser.parse_args()")
    lines.append("    config = load_config(_args.config, param_file=_args.param_file)")
    lines.append(f"    run_{_safe_name(mapping.name)}(config)")
    lines.append("")

    return "\n".join(lines)


def _safe_name(name):
    import re
    safe = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    if safe and safe[0].isdigit():
        safe = '_' + safe
    return safe.lower()


def _flatfile_config_dict(ff):
    cfg = {}
    if not ff:
        return cfg
    if ff.delimiter and ff.delimiter != ",":
        d = ff.delimiter
        DELIMITER_MAP = {
            "COMMA": ",", "TAB": "\\t", "PIPE": "|", "SEMICOLON": ";",
            "SPACE": " ", "TILDE": "~", "CARET": "^",
        }
        d = DELIMITER_MAP.get(d.upper(), d)
        cfg["delimiter"] = d
    if ff.is_fixed_width == "YES":
        cfg["fixed_width"] = True
    if ff.header_lines:
        cfg["header_lines"] = ff.header_lines
    if ff.skip_rows:
        cfg["skip_rows"] = ff.skip_rows
    if ff.text_qualifier:
        cfg["quotechar"] = ff.text_qualifier
    if ff.escape_character:
        cfg["escapechar"] = ff.escape_character
    if ff.strip_trailing_blanks == "YES":
        cfg["strip_trailing_blanks"] = True
    if ff.code_page:
        cfg["encoding"] = ff.code_page
    if ff.row_delimiter:
        cfg["lineterminator"] = ff.row_delimiter
    return cfg


def _emit_flatfile_read(lines, var_name, src_def, indent="    ", file_path_override=None):
    ff = src_def.flatfile
    fc = _flatfile_config_dict(ff)
    default_path = f"_src_path_{var_name}" if file_path_override else f"config.get('sources', {{}}).get('{src_def.name}', {{}}).get('file_path', '{src_def.name}')"
    if fc.get("fixed_width"):
        widths = []
        for fld in src_def.fields:
            widths.append(fld.precision if fld.precision else 10)
        lines.append(f"{indent}df_{var_name} = pd.read_fwf(")
        lines.append(f"{indent}    {default_path},")
        lines.append(f"{indent}    widths={widths},")
        hdr = fc.get("header_lines", 0)
        if hdr:
            lines.append(f"{indent}    header={hdr - 1},")
        else:
            lines.append(f"{indent}    header=None,")
        skip = fc.get("skip_rows", 0)
        if skip:
            lines.append(f"{indent}    skiprows={skip},")
        lines.append(f"{indent})")
        return

    file_cfg = {}
    if "delimiter" in fc:
        file_cfg["delimiter"] = fc["delimiter"]
    if "quotechar" in fc:
        file_cfg["quotechar"] = fc["quotechar"]
    if "escapechar" in fc:
        file_cfg["escapechar"] = fc["escapechar"]
    if "encoding" in fc:
        file_cfg["encoding"] = fc["encoding"]
    if "lineterminator" in fc:
        file_cfg["lineterminator"] = fc["lineterminator"]
    hdr = fc.get("header_lines", 0)
    if hdr:
        file_cfg["header"] = True
        file_cfg["header_row"] = hdr - 1
    if fc.get("skip_rows"):
        file_cfg["skip_rows"] = fc["skip_rows"]
    if fc.get("strip_trailing_blanks"):
        file_cfg["strip_trailing_blanks"] = True

    if file_cfg:
        lines.append(f"{indent}ff_cfg_{var_name} = {repr(file_cfg)}")
        lines.append(f"{indent}ff_cfg_{var_name}.update(config.get('sources', {{}}).get('{src_def.name}', {{}}))")
        if file_path_override:
            lines.append(f"{indent}df_{var_name} = read_file({default_path}, ff_cfg_{var_name})")
        else:
            lines.append(f"{indent}df_{var_name} = read_file(ff_cfg_{var_name}.get('file_path', '{src_def.name}'), ff_cfg_{var_name})")
    else:
        if file_path_override:
            lines.append(f"{indent}df_{var_name} = read_file({default_path}, config.get('sources', {{}}).get('{src_def.name}', {{}}))")
        else:
            lines.append(f"{indent}df_{var_name} = read_file(config.get('sources', {{}}).get('{src_def.name}', {{}}).get('file_path', '{src_def.name}'),")
            lines.append(f"{indent}                          config.get('sources', {{}}).get('{src_def.name}', {{}}))")


def _emit_flatfile_write(lines, var_name, tgt_def, indent="    ", file_path_override=None):
    ff = tgt_def.flatfile
    fc = _flatfile_config_dict(ff)
    default_path = f"_tgt_path_{var_name}" if file_path_override else f"config.get('targets', {{}}).get('{tgt_def.name}', {{}}).get('file_path', '{tgt_def.name}')"
    file_cfg = {}
    if "delimiter" in fc:
        file_cfg["delimiter"] = fc["delimiter"]
    if "quotechar" in fc:
        file_cfg["quotechar"] = fc["quotechar"]
    if "encoding" in fc:
        file_cfg["encoding"] = fc["encoding"]

    if file_cfg:
        lines.append(f"{indent}ff_cfg_{var_name} = {repr(file_cfg)}")
        lines.append(f"{indent}ff_cfg_{var_name}.update(config.get('targets', {{}}).get('{tgt_def.name}', {{}}))")
        if file_path_override:
            lines.append(f"{indent}write_file(df_target_{var_name}, {default_path}, ff_cfg_{var_name})")
        else:
            lines.append(f"{indent}write_file(df_target_{var_name}, ff_cfg_{var_name}.get('file_path', '{tgt_def.name}'), ff_cfg_{var_name})")
    else:
        if file_path_override:
            lines.append(f"{indent}write_file(df_target_{var_name}, {default_path}, config.get('targets', {{}}).get('{tgt_def.name}', {{}}))")
        else:
            lines.append(f"{indent}write_file(df_target_{var_name}, config.get('targets', {{}}).get('{tgt_def.name}', {{}}).get('file_path', '{tgt_def.name}'),")
            lines.append(f"{indent}          config.get('targets', {{}}).get('{tgt_def.name}', {{}}))")


def _build_source_map(mapping, folder):
    source_map = {}
    for inst in mapping.instances:
        if inst.type == "Source Definition":
            tx_name = inst.transformation_name or inst.name
            for src in folder.sources:
                if src.name == tx_name:
                    source_map[inst.name] = src
                    break
            else:
                source_map[inst.name] = SourceDef(name=tx_name)
    return source_map


def _build_target_map(mapping, folder):
    target_map = {}
    for inst in mapping.instances:
        if inst.type == "Target Definition":
            tx_name = inst.transformation_name or inst.name
            for tgt in folder.targets:
                if tgt.name == tx_name:
                    target_map[inst.name] = tgt
                    break
            else:
                target_map[inst.name] = TargetDef(name=tx_name)
    return target_map


def _build_connector_graph(connectors: List[ConnectorDef]) -> Dict:
    graph = {
        "from": {},
        "to": {},
    }
    for conn in connectors:
        key_from = conn.from_instance
        key_to = conn.to_instance
        if key_from not in graph["from"]:
            graph["from"][key_from] = []
        graph["from"][key_from].append(conn)
        if key_to not in graph["to"]:
            graph["to"][key_to] = []
        graph["to"][key_to].append(conn)
    return graph


def _get_processing_order(transformations, connector_graph, sq_transforms):
    sq_names = {t.name for t in sq_transforms}
    remaining = [t for t in transformations if t.name not in sq_names]

    ordered = []
    processed = set(sq_names)
    max_iterations = len(remaining) * 2 + 1

    for _ in range(max_iterations):
        if not remaining:
            break
        for tx in list(remaining):
            inputs = connector_graph.get("to", {}).get(tx.name, [])
            input_instances = {c.from_instance for c in inputs}
            if not input_instances or input_instances.issubset(processed):
                ordered.append(tx)
                processed.add(tx.name)
                remaining.remove(tx)

    ordered.extend(remaining)
    return ordered


def _generate_source_qualifier(lines, sq, source_map, source_dfs, connector_graph, instance_map, session_overrides=None):
    sq_safe = _safe_name(sq.name)
    sql_override = ""
    pre_sql = ""
    post_sql = ""
    for attr in sq.attributes:
        if attr.name == "Sql Query" and attr.value:
            sql_override = convert_sql_expression(attr.value)
        elif attr.name == "Pre SQL" and attr.value:
            pre_sql = convert_sql_expression(attr.value)
        elif attr.name == "Post SQL" and attr.value:
            post_sql = convert_sql_expression(attr.value)

    connected_sources = set()
    to_conns = connector_graph.get("to", {}).get(sq.name, [])
    for c in to_conns:
        if c.from_instance in source_map:
            connected_sources.add(c.from_instance)
    if not connected_sources:
        for src_name in source_map:
            if sq.name.upper().startswith("SQ_") and src_name.upper() in sq.name.upper():
                connected_sources.add(src_name)
        if not connected_sources and source_map:
            connected_sources.add(next(iter(source_map)))

    lines.append(f"    # Source Qualifier: {sq.name}")

    if pre_sql:
        lines.append(f"    # Pre-SQL")
        for sql_line in pre_sql.strip().split("\n"):
            lines.append(f"    # {sql_line}")
        lines.append(f"    execute_sql(config, '''{pre_sql}''')")
        lines.append("")

    if sql_override:
        src_name = next(iter(connected_sources)) if connected_sources else "source"
        src_def = source_map.get(src_name, SourceDef(name=src_name))
        sq_override = (session_overrides or {}).get(sq.name, {}) or (session_overrides or {}).get(src_name, {})
        conn_name = sq_override.get("connection_name") or (_safe_name(src_def.db_name) if src_def.db_name else "default")

        lines.append(f"    sql_{sq_safe} = '''")
        for sql_line in sql_override.strip().split("\n"):
            lines.append(f"    {sql_line}")
        lines.append(f"    '''")
        lines.append(f"    df_{sq_safe} = read_from_db(config, sql_{sq_safe}, '{conn_name}')")
    else:
        if len(connected_sources) == 1:
            src_name = next(iter(connected_sources))
            src_def = source_map.get(src_name, SourceDef(name=src_name))
            safe_src = _safe_name(src_name)
            src_override = (session_overrides or {}).get(sq.name, {}) or (session_overrides or {}).get(src_name, {})
            if src_def.database_type and src_def.database_type != "Flat File":
                conn_name = src_override.get("connection_name") or (_safe_name(src_def.db_name) if src_def.db_name else "default")
                schema = src_def.owner_name or "dbo"
                cols = ", ".join(f.name for f in src_def.fields) if src_def.fields else "*"
                lines.append(f"    df_{sq_safe} = read_from_db(config, 'SELECT {cols} FROM {schema}.{src_def.name}', '{conn_name}')")
            elif src_def.flatfile:
                _emit_flatfile_read(lines, sq_safe, src_def)
            else:
                lines.append(f"    df_{sq_safe} = read_file(config.get('sources', {{}}).get('{src_def.name}', {{}}).get('file_path', '{src_def.name}'),")
                lines.append(f"                              config.get('sources', {{}}).get('{src_def.name}', {{}}))")
        else:
            for src_name in connected_sources:
                src_def = source_map.get(src_name, SourceDef(name=src_name))
                safe_src = _safe_name(src_name)
                if src_def.database_type and src_def.database_type != "Flat File":
                    conn_name = _safe_name(src_def.db_name) if src_def.db_name else "default"
                    schema = src_def.owner_name or "dbo"
                    lines.append(f"    df_{safe_src} = read_from_db(config, 'SELECT * FROM {schema}.{src_def.name}', '{conn_name}')")
                elif src_def.flatfile:
                    _emit_flatfile_read(lines, safe_src, src_def)
                else:
                    lines.append(f"    df_{safe_src} = read_file(config.get('sources', {{}}).get('{src_def.name}', {{}}).get('file_path', '{src_def.name}'),")
                    lines.append(f"                              config.get('sources', {{}}).get('{src_def.name}', {{}}))")
            lines.append(f"    df_{sq_safe} = df_{_safe_name(next(iter(connected_sources)))}")

    source_dfs[sq.name] = f"df_{sq_safe}"

    if post_sql:
        lines.append(f"    # Post-SQL")
        lines.append(f"    execute_sql(config, '''{post_sql}''')")

    lines.append("")


def _generate_transformation(lines, tx, connector_graph, source_dfs, transform_map, instance_map, data_lib="pandas"):
    tx_safe = _safe_name(tx.name)
    tx_type = tx.type.lower().strip()

    input_conns = connector_graph.get("to", {}).get(tx.name, [])
    input_sources = set()
    for c in input_conns:
        input_sources.add(c.from_instance)

    input_df = None
    for src in input_sources:
        if src in source_dfs:
            input_df = source_dfs[src]
            break
    if not input_df:
        for src in input_sources:
            input_df = f"df_{_safe_name(src)}"
            break
    if not input_df:
        input_df = "df_input"

    lines.append(f"    # Transformation: {tx.name} (Type: {tx.type})")

    if tx_type == "expression":
        _gen_expression_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib)
    elif tx_type == "filter":
        _gen_filter_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib)
    elif tx_type in ("aggregator",):
        _gen_aggregator_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib)
    elif tx_type == "sorter":
        _gen_sorter_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib)
    elif tx_type in ("joiner",):
        _gen_joiner_transform(lines, tx, tx_safe, input_df, input_sources, source_dfs, connector_graph, data_lib)
    elif tx_type in ("lookup procedure", "lookup"):
        _gen_lookup_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib)
    elif tx_type == "router":
        _gen_router_transform(lines, tx, tx_safe, input_df, source_dfs)
    elif tx_type in ("union",):
        _gen_union_transform(lines, tx, tx_safe, input_sources, source_dfs, data_lib)
    elif tx_type in ("update strategy",):
        _gen_update_strategy(lines, tx, tx_safe, input_df, source_dfs)
    elif tx_type == "sequence generator":
        _gen_sequence_generator(lines, tx, tx_safe, input_df, source_dfs)
    elif tx_type in ("normalizer",):
        _gen_normalizer_transform(lines, tx, tx_safe, input_df, source_dfs)
    elif tx_type in ("rank",):
        _gen_rank_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib)
    elif tx_type in ("custom transformation",):
        _gen_custom_transform(lines, tx, tx_safe, input_df, input_sources, source_dfs, data_lib)
    elif tx_type in ("stored procedure",):
        _gen_stored_proc(lines, tx, tx_safe, input_df, source_dfs)
    elif tx_type in ("java",):
        _gen_java_transform(lines, tx, tx_safe, input_df, source_dfs)
    elif tx_type in ("sql",):
        _gen_sql_transform(lines, tx, tx_safe, input_df, source_dfs)
    else:
        lines.append(f"    # TODO: Unsupported transformation type '{tx.type}' - passing through")
        copy_expr = lib_copy(data_lib, input_df)
        lines.append(f"    df_{tx_safe} = {copy_expr}")
        source_dfs[tx.name] = f"df_{tx_safe}"

    lines.append("")


def _gen_expression_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib="pandas"):
    copy_expr = lib_copy(data_lib, input_df)
    lines.append(f"    df_{tx_safe} = {copy_expr}")
    has_expressions = False
    for fld in tx.fields:
        if fld.expression and fld.expression.strip() and fld.expression.strip() != fld.name:
            has_expressions = True
            expr_vec = convert_expression_vectorized(fld.expression, f"df_{tx_safe}")
            lines.append(f"    # {fld.name} = {fld.expression}")
            if fld.porttype and "OUTPUT" in fld.porttype.upper() and "INPUT" not in fld.porttype.upper():
                lines.append(f"    df_{tx_safe}['{fld.name}'] = {expr_vec}")
            else:
                lines.append(f"    df_{tx_safe}['{fld.name}'] = {expr_vec}")
    if not has_expressions:
        lines.append(f"    # Pass-through expression (no transformations)")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_filter_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib="pandas"):
    filter_condition = ""
    for attr in tx.attributes:
        if attr.name == "Filter Condition":
            filter_condition = attr.value
    if filter_condition:
        expr_vec = convert_filter_vectorized(filter_condition, input_df)
        lines.append(f"    # Filter: {filter_condition}")
        copy_expr = lib_copy(data_lib, f"{input_df}[{expr_vec}]")
        lines.append(f"    df_{tx_safe} = {copy_expr}")
    else:
        copy_expr = lib_copy(data_lib, input_df)
        lines.append(f"    df_{tx_safe} = {copy_expr}")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_aggregator_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib="pandas"):
    group_by_ports = []
    agg_ports = []
    for fld in tx.fields:
        pt = (fld.porttype or "").upper()
        if "INPUT" in pt and "OUTPUT" in pt:
            group_by_ports.append(fld.name)
        elif "OUTPUT" in pt and "INPUT" not in pt:
            agg_ports.append(fld)

    agg_dict = {}
    rename_map = {}
    computed_aggs = []
    for ap in agg_ports:
        expr_text = ap.expression or ap.name
        agg_func, agg_col = parse_aggregate_expression(expr_text)
        if agg_func and agg_col:
            pandas_func = PANDAS_AGG_MAP.get(agg_func, agg_func)
            if agg_col == "*":
                agg_col = group_by_ports[0] if group_by_ports else ap.name
                pandas_func = "count"
            if agg_col in agg_dict:
                temp_name = f"{agg_col}__{ap.name}"
                agg_dict[temp_name] = (agg_col, pandas_func)
                rename_map[temp_name] = ap.name
            else:
                agg_dict[ap.name] = (agg_col, pandas_func)
        else:
            computed_aggs.append((ap.name, expr_text))

    if group_by_ports and agg_dict:
        lines.append(f"    # Aggregator: group by {group_by_ports}")
        agg_expr = lib_groupby_agg(data_lib, input_df, group_by_ports, agg_dict)
        lines.append(f"    df_{tx_safe} = {agg_expr}")

        if rename_map:
            lines.append(f"    df_{tx_safe} = df_{tx_safe}.rename(columns={rename_map})")
    elif group_by_ports:
        lines.append(f"    # Aggregator: group by {group_by_ports}")
        first_expr = lib_groupby_first(data_lib, input_df, group_by_ports)
        lines.append(f"    df_{tx_safe} = {first_expr}")
    else:
        copy_expr = lib_copy(data_lib, input_df)
        lines.append(f"    df_{tx_safe} = {copy_expr}")

    for col_name, expr_text in computed_aggs:
        expr_py = convert_expression(expr_text)
        lines.append(f"    # Computed aggregate: {col_name} = {expr_text}")
        lines.append(f"    df_{tx_safe}['{col_name}'] = {expr_py}")

    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_sorter_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib="pandas"):
    sort_keys = []
    sort_dirs = []
    for fld in tx.fields:
        sort_keys.append(fld.name)
        sort_dirs.append(True)
    if sort_keys:
        sort_expr = lib_sort(data_lib, input_df, sort_keys, sort_dirs)
        lines.append(f"    df_{tx_safe} = {sort_expr}")
    else:
        copy_expr = lib_copy(data_lib, input_df)
        lines.append(f"    df_{tx_safe} = {copy_expr}")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_joiner_transform(lines, tx, tx_safe, input_df, input_sources, source_dfs, connector_graph=None, data_lib="pandas"):
    join_type = "inner"
    join_condition = ""
    for attr in tx.attributes:
        if attr.name == "Join Type":
            jt = attr.value.upper()
            if "FULL" in jt:
                join_type = "outer"
            elif "MASTER" in jt:
                join_type = "left"
            elif "DETAIL" in jt:
                join_type = "right"
        elif attr.name == "Join Condition":
            join_condition = attr.value

    master_fields = []
    detail_fields = []
    for fld in tx.fields:
        pt = (fld.porttype or "").upper()
        if "MASTER" in pt:
            master_fields.append(fld.name)
        elif "DETAIL" in pt:
            detail_fields.append(fld.name)

    left_keys, right_keys = parse_join_condition(join_condition)

    master_src = None
    detail_src = None
    input_conns = connector_graph.get("to", {}).get(tx.name, []) if connector_graph else []
    for conn in input_conns:
        to_field = conn.to_field
        if to_field in master_fields:
            master_src = conn.from_instance
        elif to_field in detail_fields:
            detail_src = conn.from_instance

    src_list = list(input_sources)
    if not master_src and not detail_src and len(src_list) >= 2:
        master_src = src_list[0]
        detail_src = src_list[1]
    elif not master_src and len(src_list) >= 1:
        master_src = src_list[0]
    if not detail_src:
        for s in src_list:
            if s != master_src:
                detail_src = s
                break

    if master_src and detail_src:
        df_master = source_dfs.get(master_src, f"df_{_safe_name(master_src)}")
        df_detail = source_dfs.get(detail_src, f"df_{_safe_name(detail_src)}")

        lines.append(f"    # Join ({join_type}): {join_condition or 'auto'}")
        if left_keys and right_keys:
            merge_expr = lib_merge(data_lib, df_detail, df_master,
                                   left_on=left_keys, right_on=right_keys, how=join_type)
            lines.append(f"    df_{tx_safe} = {merge_expr}")
        else:
            common_cols = [f for f in detail_fields if f in master_fields]
            if common_cols:
                merge_expr = lib_merge(data_lib, df_detail, df_master,
                                       on=common_cols, how=join_type)
                lines.append(f"    df_{tx_safe} = {merge_expr}")
            else:
                merge_expr = lib_merge(data_lib, df_detail, df_master, how=join_type)
                lines.append(f"    df_{tx_safe} = {merge_expr}")
    elif len(src_list) == 1:
        df1 = source_dfs.get(src_list[0], f"df_{_safe_name(src_list[0])}")
        copy_expr = lib_copy(data_lib, df1)
        lines.append(f"    df_{tx_safe} = {copy_expr}")
    else:
        copy_expr = lib_copy(data_lib, input_df)
        lines.append(f"    df_{tx_safe} = {copy_expr}")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_lookup_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib="pandas"):
    lookup_table = ""
    lookup_sql = ""
    lookup_condition = ""
    lookup_cache = "YES"
    lookup_policy = "ERROR"
    default_values = {}
    for attr in tx.attributes:
        if attr.name == "Lookup table name":
            lookup_table = attr.value
        elif attr.name == "Lookup Sql Override" and attr.value:
            lookup_sql = convert_sql_expression(attr.value)
        elif attr.name == "Lookup condition":
            lookup_condition = attr.value
        elif attr.name == "Lookup caching enabled":
            lookup_cache = attr.value
        elif attr.name == "Lookup policy on multiple match":
            lookup_policy = attr.value

    return_fields = [f for f in tx.fields if "RETURN" in (f.porttype or "").upper() or
                     ("LOOKUP" in (f.porttype or "").upper() and "OUTPUT" in (f.porttype or "").upper()
                      and "INPUT" not in (f.porttype or "").upper())]
    input_fields = [f for f in tx.fields if "INPUT" in (f.porttype or "").upper()]
    lookup_output_fields = [f for f in tx.fields if
                            "OUTPUT" in (f.porttype or "").upper()
                            and "INPUT" not in (f.porttype or "").upper()
                            and "RETURN" not in (f.porttype or "").upper()]

    all_output_fields = return_fields + lookup_output_fields

    lines.append(f"    # Lookup: {lookup_table or tx.name}")
    if lookup_sql:
        lines.append(f"    lkp_sql_{tx_safe} = '''")
        for sql_line in lookup_sql.strip().split("\n"):
            lines.append(f"    {sql_line}")
        lines.append(f"    '''")
        lines.append(f"    df_lkp_{tx_safe} = read_from_db(config, lkp_sql_{tx_safe}, 'default')")
    elif lookup_table:
        lines.append(f"    df_lkp_{tx_safe} = read_from_db(config, 'SELECT * FROM {lookup_table}', 'default')")
    else:
        empty_expr = lib_empty_df(data_lib)
        lines.append(f"    df_lkp_{tx_safe} = {empty_expr}")

    input_keys, lookup_keys = parse_lookup_condition(lookup_condition)

    if input_keys and lookup_keys:
        lines.append(f"    # Lookup condition: {lookup_condition}")

        lkp_cols = [f.name for f in all_output_fields]
        select_cols = list(set(lookup_keys + lkp_cols))
        lines.append(f"    lkp_select_cols_{tx_safe} = [c for c in {select_cols} if c in df_lkp_{tx_safe}.columns]")

        if lookup_policy and "FIRST" in lookup_policy.upper():
            lines.append(f"    df_lkp_{tx_safe} = df_lkp_{tx_safe}[lkp_select_cols_{tx_safe}].drop_duplicates(subset={lookup_keys}, keep='first')")
        elif lookup_policy and "LAST" in lookup_policy.upper():
            lines.append(f"    df_lkp_{tx_safe} = df_lkp_{tx_safe}[lkp_select_cols_{tx_safe}].drop_duplicates(subset={lookup_keys}, keep='last')")
        else:
            lines.append(f"    df_lkp_{tx_safe} = df_lkp_{tx_safe}[lkp_select_cols_{tx_safe}].drop_duplicates(subset={lookup_keys}, keep='first')")

        merge_expr = lib_merge(data_lib, input_df, f"df_lkp_{tx_safe}",
                               left_on=input_keys, right_on=lookup_keys,
                               how="left", suffixes=("", "_lkp"))
        lines.append(f"    df_{tx_safe} = {merge_expr}")

        drop_cols = [k for k in lookup_keys if k not in input_keys]
        if drop_cols:
            lines.append(f"    _lkp_drop = [c for c in {drop_cols} if c in df_{tx_safe}.columns]")
            lines.append(f"    if _lkp_drop:")
            lines.append(f"        df_{tx_safe} = df_{tx_safe}.drop(columns=_lkp_drop)")

        for rf in all_output_fields:
            lines.append(f"    if '{rf.name}' not in df_{tx_safe}.columns:")
            lines.append(f"        df_{tx_safe}['{rf.name}'] = None")
            if rf.default_value:
                lines.append(f"    df_{tx_safe}['{rf.name}'] = df_{tx_safe}['{rf.name}'].fillna({repr(rf.default_value)})")
    else:
        lines.append(f"    df_{tx_safe} = {input_df}.copy()")
        if all_output_fields:
            ret_names = [f.name for f in all_output_fields]
            lines.append(f"    # Lookup returns: {ret_names}")
            lines.append(f"    # Could not auto-parse lookup condition: {lookup_condition}")
            for rf in all_output_fields:
                default = repr(rf.default_value) if rf.default_value else "None"
                lines.append(f"    df_{tx_safe}['{rf.name}'] = {default}")

    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_router_transform(lines, tx, tx_safe, input_df, source_dfs):
    lines.append(f"    # Router groups:")
    group_conditions = {}
    for attr in tx.attributes:
        if "Group Filter Condition" in attr.name:
            group_conditions[attr.name] = attr.value

    if group_conditions:
        for i, (gname, cond) in enumerate(group_conditions.items()):
            expr_py = convert_expression(cond) if cond else "True"
            lines.append(f"    df_{tx_safe}_group{i} = {input_df}[{expr_py}].copy()  # {gname}")
            source_dfs[f"{tx.name}_group{i}"] = f"df_{tx_safe}_group{i}"
    lines.append(f"    df_{tx_safe} = {input_df}.copy()  # Default group")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_union_transform(lines, tx, tx_safe, input_sources, source_dfs, data_lib="pandas"):
    dfs_to_union = []
    for src in input_sources:
        df_name = source_dfs.get(src, f"df_{_safe_name(src)}")
        dfs_to_union.append(df_name)

    if len(dfs_to_union) > 1:
        df_list = ", ".join(dfs_to_union)
        concat_expr = lib_concat(data_lib, df_list)
        lines.append(f"    df_{tx_safe} = {concat_expr}")
    elif dfs_to_union:
        copy_expr = lib_copy(data_lib, dfs_to_union[0])
        lines.append(f"    df_{tx_safe} = {copy_expr}")
    else:
        empty_expr = lib_empty_df(data_lib)
        lines.append(f"    df_{tx_safe} = {empty_expr}")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_update_strategy(lines, tx, tx_safe, input_df, source_dfs):
    strategy_expr = "0"
    for attr in tx.attributes:
        if attr.name == "Update Strategy Expression":
            strategy_expr = attr.value
    strategy_map = {"0": "INSERT", "1": "UPDATE", "2": "DELETE", "3": "REJECT"}

    lines.append(f"    # Update Strategy: {tx.name}")
    lines.append(f"    df_{tx_safe} = {input_df}.copy()")

    if strategy_expr in strategy_map:
        strategy_name = strategy_map[strategy_expr]
        lines.append(f"    df_{tx_safe}['_update_strategy'] = '{strategy_name}'")
    else:
        dd_map = {
            "DD_INSERT": "INSERT", "DD_UPDATE": "UPDATE",
            "DD_DELETE": "DELETE", "DD_REJECT": "REJECT",
        }
        expr = strategy_expr
        for dd_const, label in dd_map.items():
            expr = expr.replace(dd_const, f"'{label}'")
        try:
            converted = convert_expression(expr)
            lines.append(f"    # Original expression: {strategy_expr}")
            lines.append(f"    def _resolve_strategy(row):")
            lines.append(f"        return {converted}")
            lines.append(f"    df_{tx_safe}['_update_strategy'] = df_{tx_safe}.apply(_resolve_strategy, axis=1)")
        except Exception:
            lines.append(f"    # Could not parse strategy expression: {strategy_expr}")
            lines.append(f"    df_{tx_safe}['_update_strategy'] = 'INSERT'")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_sequence_generator(lines, tx, tx_safe, input_df, source_dfs):
    start_val = "1"
    increment = "1"
    for attr in tx.attributes:
        if attr.name == "Start Value":
            start_val = attr.value or "1"
        elif attr.name == "Increment By":
            increment = attr.value or "1"

    seq_field = None
    for fld in tx.fields:
        if fld.porttype and "OUTPUT" in fld.porttype.upper() and "NEXTVAL" in fld.name.upper():
            seq_field = fld.name
            break
    if not seq_field:
        for fld in tx.fields:
            if fld.porttype and "OUTPUT" in fld.porttype.upper():
                seq_field = fld.name
                break

    lines.append(f"    df_{tx_safe} = {input_df}.copy()")
    if seq_field:
        lines.append(f"    df_{tx_safe}['{seq_field}'] = range({start_val}, {start_val} + len(df_{tx_safe}) * {increment}, {increment})")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_normalizer_transform(lines, tx, tx_safe, input_df, source_dfs):
    input_ports = []
    output_ports = []
    occurs_cols = []
    id_cols = []

    for fld in tx.fields:
        pt = (fld.porttype or "").upper()
        if "INPUT" in pt:
            input_ports.append(fld)
        if "OUTPUT" in pt:
            output_ports.append(fld)

    for fld in tx.fields:
        if fld.field_number > 0:
            occurs_cols.append(fld.name)

    if not occurs_cols:
        import re
        base_groups = {}
        for fld in input_ports:
            m = re.match(r'^(.+?)(\d+)$', fld.name)
            if m:
                base = m.group(1)
                idx = int(m.group(2))
                if base not in base_groups:
                    base_groups[base] = []
                base_groups[base].append(fld.name)
            else:
                id_cols.append(fld.name)

        if base_groups:
            longest_group = max(base_groups.values(), key=len)
            occurs_cols = longest_group
            id_cols = [f.name for f in input_ports if f.name not in occurs_cols]
        else:
            for fld in input_ports:
                pt = (fld.porttype or "").upper()
                if "INPUT" in pt and "OUTPUT" in pt:
                    id_cols.append(fld.name)
                elif "INPUT" in pt and "OUTPUT" not in pt:
                    occurs_cols.append(fld.name)

    if not id_cols:
        id_cols = [f.name for f in input_ports if f.name not in occurs_cols]

    gk_field = None
    for fld in output_ports:
        if "GK" in fld.name.upper() or "GENERATED" in fld.name.upper() or "KEY" in fld.name.upper():
            gk_field = fld.name
            break

    lines.append(f"    # Normalizer: unpivot repeated columns into rows")
    if occurs_cols and id_cols:
        lines.append(f"    df_{tx_safe} = {input_df}.melt(")
        lines.append(f"        id_vars={id_cols},")
        lines.append(f"        value_vars={occurs_cols},")
        lines.append(f"        var_name='_norm_variable',")
        lines.append(f"        value_name='_norm_value'")
        lines.append(f"    )")
        lines.append(f"    df_{tx_safe} = df_{tx_safe}.dropna(subset=['_norm_value']).reset_index(drop=True)")
    elif occurs_cols:
        lines.append(f"    df_{tx_safe} = {input_df}[{occurs_cols}].stack().reset_index(drop=True).to_frame('_norm_value')")
    else:
        lines.append(f"    df_{tx_safe} = {input_df}.copy()")

    if gk_field:
        lines.append(f"    df_{tx_safe}['{gk_field}'] = range(1, len(df_{tx_safe}) + 1)")

    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_rank_transform(lines, tx, tx_safe, input_df, source_dfs, data_lib="pandas"):
    rank_port = None
    group_by_ports = []
    top_bottom = "TOP"
    top_n = 0

    for fld in tx.fields:
        pt = (fld.porttype or "").upper()
        if "INPUT" in pt and "OUTPUT" in pt:
            group_by_ports.append(fld.name)

    for fld in tx.fields:
        if fld.expression and fld.expression.strip() and fld.name.upper() not in ("RANKINDEX",):
            rank_port = fld.name
            break
    if not rank_port:
        for fld in tx.fields:
            if fld.name.upper() == "RANKINDEX":
                continue
            pt = (fld.porttype or "").upper()
            if "INPUT" in pt and "OUTPUT" not in pt:
                rank_port = fld.name
                break

    for attr in tx.attributes:
        if attr.name == "Top/Bottom":
            top_bottom = attr.value
        elif attr.name == "Number Of Ranks":
            try:
                top_n = int(attr.value)
            except (ValueError, TypeError):
                top_n = 0

    ascending = top_bottom.upper() != "TOP"

    rank_out_field = "RANKINDEX"
    for fld in tx.fields:
        if fld.name.upper() == "RANKINDEX" or "RANK" in fld.name.upper():
            pt = (fld.porttype or "").upper()
            if "OUTPUT" in pt and "INPUT" not in pt:
                rank_out_field = fld.name
                break

    copy_expr = lib_copy(data_lib, input_df)
    lines.append(f"    df_{tx_safe} = {copy_expr}")
    if rank_port:
        rank_code = lib_rank(data_lib, f"df_{tx_safe}", group_by_ports, rank_port, ascending, rank_out_field)
        if group_by_ports:
            lines.append(f"    # Rank by '{rank_port}' within groups {group_by_ports}")
        else:
            lines.append(f"    # Rank by '{rank_port}' (no group-by)")
        lines.append(f"    {rank_code}")
        if top_n:
            lines.append(f"    df_{tx_safe} = df_{tx_safe}[df_{tx_safe}['{rank_out_field}'] <= {top_n}].reset_index(drop=True)")
    else:
        lines.append(f"    df_{tx_safe}['{rank_out_field}'] = range(1, len(df_{tx_safe}) + 1)")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_custom_transform(lines, tx, tx_safe, input_df, input_sources, source_dfs, data_lib="pandas"):
    is_union = False
    output_fields = []
    input_groups = {}

    for fld in tx.fields:
        if "OUTPUT" in (fld.porttype or "").upper():
            output_fields.append(fld)
        import re
        m = re.match(r'^(.+?)(\d+)$', fld.name)
        if m and "INPUT" in (fld.porttype or "").upper():
            group_idx = m.group(2)
            if group_idx not in input_groups:
                input_groups[group_idx] = []
            input_groups[group_idx].append(fld)

    if len(input_groups) > 1:
        is_union = True

    if is_union:
        dfs_to_union = []
        for src in input_sources:
            df_name = source_dfs.get(src, f"df_{_safe_name(src)}")
            dfs_to_union.append(df_name)
        if len(dfs_to_union) > 1:
            df_list = ", ".join(dfs_to_union)
            concat_expr = lib_concat(data_lib, df_list)
            lines.append(f"    df_{tx_safe} = {concat_expr}")
        elif dfs_to_union:
            copy_expr = lib_copy(data_lib, dfs_to_union[0])
            lines.append(f"    df_{tx_safe} = {copy_expr}")
        else:
            empty_expr = lib_empty_df(data_lib)
            lines.append(f"    df_{tx_safe} = {empty_expr}")
    else:
        lines.append(f"    # Custom transformation: {tx.name}")
        copy_expr = lib_copy(data_lib, input_df)
        lines.append(f"    df_{tx_safe} = {copy_expr}")

    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_stored_proc(lines, tx, tx_safe, input_df, source_dfs):
    proc_name = ""
    conn_name = "default"
    for attr in tx.attributes:
        if attr.name in ("Stored Procedure Name", "sp name"):
            proc_name = attr.value
        elif attr.name in ("Connection Name", "connection_name"):
            conn_name = attr.value or "default"

    input_params = []
    output_params = []
    for fld in tx.fields:
        pt = (fld.porttype or "").upper()
        if "INPUT" in pt and "OUTPUT" not in pt:
            input_params.append(fld.name)
        elif "OUTPUT" in pt:
            output_params.append(fld.name)

    lines.append(f"    # Stored Procedure: {proc_name or tx.name}")

    if input_params:
        param_dict_items = ", ".join(f"'{p}': {input_df}['{p}'].iloc[0] if '{p}' in {input_df}.columns and len({input_df}) > 0 else None" for p in input_params)
        lines.append(f"    _sp_params_{tx_safe} = {{{param_dict_items}}}")
    else:
        lines.append(f"    _sp_params_{tx_safe} = {{}}")

    if output_params:
        out_list = repr(output_params)
        lines.append(f"    _sp_out_names_{tx_safe} = {out_list}")
    else:
        lines.append(f"    _sp_out_names_{tx_safe} = []")

    lines.append(f"    df_{tx_safe}, _sp_out_vals_{tx_safe} = call_stored_procedure(")
    lines.append(f"        config, '{proc_name or tx.name}', params=_sp_params_{tx_safe},")
    lines.append(f"        connection_name='{conn_name}', output_params=_sp_out_names_{tx_safe})")

    if output_params:
        lines.append(f"    if df_{tx_safe}.empty and _sp_out_vals_{tx_safe}:")
        lines.append(f"        df_{tx_safe} = {input_df}.copy()")
        for op in output_params:
            lines.append(f"        if '{op}' in _sp_out_vals_{tx_safe}:")
            lines.append(f"            df_{tx_safe}['{op}'] = _sp_out_vals_{tx_safe}['{op}']")

    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_java_transform(lines, tx, tx_safe, input_df, source_dfs):
    lines.append(f"    # Java Transformation: {tx.name}")
    lines.append(f"    # TODO: Port Java logic to Python")
    lines.append(f"    df_{tx_safe} = {input_df}.copy()")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _gen_sql_transform(lines, tx, tx_safe, input_df, source_dfs):
    sql_query = ""
    for attr in tx.attributes:
        if attr.name == "Sql Query" and attr.value:
            sql_query = convert_sql_expression(attr.value)
    lines.append(f"    # SQL Transformation: {tx.name}")
    if sql_query:
        lines.append(f"    sql_{tx_safe} = '''{sql_query}'''")
        lines.append(f"    df_{tx_safe} = read_from_db(config, sql_{tx_safe}, 'default')")
    else:
        lines.append(f"    df_{tx_safe} = {input_df}.copy()")
    source_dfs[tx.name] = f"df_{tx_safe}"


def _generate_target_write(lines, tgt_name, tgt_def, connector_graph, source_dfs, transform_map, instance_map, session_overrides=None, validate_casts=False):
    tgt_safe = _safe_name(tgt_name)

    to_conns = connector_graph.get("to", {}).get(tgt_name, [])
    input_df = None
    for c in to_conns:
        if c.from_instance in source_dfs:
            input_df = source_dfs[c.from_instance]
            break
    if not input_df:
        for c in to_conns:
            input_df = f"df_{_safe_name(c.from_instance)}"
            break

    if not input_df:
        input_df = "df_output"

    col_mapping = {}
    for c in to_conns:
        col_mapping[c.to_field] = c.from_field

    lines.append(f"    # Write to target: {tgt_def.name}")
    if col_mapping:
        lines.append(f"    target_columns_{tgt_safe} = {col_mapping}")
        lines.append(f"    df_target_{tgt_safe} = {input_df}.rename(columns={{v: k for k, v in target_columns_{tgt_safe}.items()}})")
        target_cols = [f.name for f in tgt_def.fields] if tgt_def.fields else None
        if target_cols:
            lines.append(f"    available_cols = [c for c in {target_cols} if c in df_target_{tgt_safe}.columns]")
            lines.append(f"    if '_update_strategy' in df_target_{tgt_safe}.columns and '_update_strategy' not in available_cols:")
            lines.append(f"        available_cols.append('_update_strategy')")
            lines.append(f"    df_target_{tgt_safe} = df_target_{tgt_safe}[available_cols]")
    else:
        lines.append(f"    df_target_{tgt_safe} = {input_df}")

    _emit_type_casting(lines, tgt_safe, tgt_def, validate_casts=validate_casts)

    tgt_override = (session_overrides or {}).get(tgt_name, {})
    tgt_conn = tgt_override.get("connection_name")

    if tgt_override.get("output_file_directory") or tgt_override.get("output_filename"):
        out_dir = tgt_override.get("output_file_directory", ".")
        out_file = tgt_override.get("output_filename", tgt_def.name)
        lines.append(f"    _tgt_path_{tgt_safe} = config.get('targets', {{}}).get('{tgt_def.name}', {{}}).get('file_path',")
        lines.append(f"        os.path.join('{out_dir}', '{out_file}'))")
        if tgt_def.flatfile:
            _emit_flatfile_write(lines, tgt_safe, tgt_def, file_path_override=True)
        else:
            lines.append(f"    write_file(df_target_{tgt_safe}, _tgt_path_{tgt_safe}, config.get('targets', {{}}).get('{tgt_def.name}', {{}}))")
    elif tgt_def.database_type and tgt_def.database_type != "Flat File":
        conn_label = tgt_conn or "target"
        lines.append(f"    if '_update_strategy' in df_target_{tgt_safe}.columns:")
        key_cols = [f.name for f in tgt_def.fields if getattr(f, 'keytype', 'NOT A KEY') == 'PRIMARY KEY'] or None
        if key_cols:
            lines.append(f"        write_with_update_strategy(config, df_target_{tgt_safe}, '{tgt_def.name}', '{conn_label}', key_columns={key_cols})")
        else:
            lines.append(f"        write_with_update_strategy(config, df_target_{tgt_safe}, '{tgt_def.name}', '{conn_label}')")
        lines.append(f"    else:")
        lines.append(f"        write_to_db(config, df_target_{tgt_safe}, '{tgt_def.name}', '{conn_label}')")
    elif tgt_def.flatfile:
        _emit_flatfile_write(lines, tgt_safe, tgt_def)
    else:
        lines.append(f"    write_file(df_target_{tgt_safe}, config.get('targets', {{}}).get('{tgt_def.name}', {{}}).get('file_path', '{tgt_def.name}'),")
        lines.append(f"              config.get('targets', {{}}).get('{tgt_def.name}', {{}}))")


CAST_MAP = {
    "bigint": ("int", "Int64"),
    "integer": ("int", "Int32"),
    "int": ("int", "Int32"),
    "small integer": ("int", "Int16"),
    "smallint": ("int", "Int16"),
    "tinyint": ("int", "Int8"),
    "numeric": ("float", "float64"),
    "decimal": ("float", "float64"),
    "float": ("float", "float64"),
    "double": ("float", "float64"),
    "real": ("float", "float32"),
    "money": ("float", "float64"),
    "smallmoney": ("float", "float64"),
    "string": ("str", "object"),
    "nstring": ("str", "object"),
    "text": ("str", "object"),
    "ntext": ("str", "object"),
    "varchar": ("str", "object"),
    "nvarchar": ("str", "object"),
    "char": ("str", "object"),
    "nchar": ("str", "object"),
    "date/time": ("str", "datetime64[ns]"),
    "datetime": ("str", "datetime64[ns]"),
    "datetime2": ("str", "datetime64[ns]"),
    "date": ("str", "datetime64[ns]"),
    "timestamp": ("str", "datetime64[ns]"),
    "bit": ("bool", "boolean"),
    "boolean": ("bool", "boolean"),
}


def _emit_type_casting(lines, tgt_safe, tgt_def, validate_casts=False):
    cast_ops = []
    for fld in tgt_def.fields:
        dt_key = fld.datatype.lower().strip()
        if dt_key not in CAST_MAP:
            continue
        py_type, pd_dtype = CAST_MAP[dt_key]
        if pd_dtype in ("datetime64[ns]",):
            cast_ops.append((fld.name, "datetime", pd_dtype, fld.nullable == "NULL"))
        elif pd_dtype in ("Int64", "Int32", "Int16", "Int8"):
            cast_ops.append((fld.name, "int", pd_dtype, fld.nullable == "NULL"))
        elif pd_dtype in ("float64", "float32"):
            cast_ops.append((fld.name, "float", pd_dtype, fld.nullable == "NULL"))
        elif pd_dtype == "boolean":
            cast_ops.append((fld.name, "bool", pd_dtype, fld.nullable == "NULL"))

    if not cast_ops:
        return

    lines.append(f"    # Type casting for target fields")
    if validate_casts:
        lines.append(f"    _cast_warnings = []")
    for col_name, cast_type, pd_dtype, nullable in cast_ops:
        lines.append(f"    if '{col_name}' in df_target_{tgt_safe}.columns:")
        if validate_casts:
            lines.append(f"        _pre_null_{_safe_name(col_name)} = df_target_{tgt_safe}['{col_name}'].isna().sum()")
        if cast_type == "datetime":
            lines.append(f"        df_target_{tgt_safe}['{col_name}'] = pd.to_datetime(df_target_{tgt_safe}['{col_name}'], errors='coerce')")
        elif cast_type == "int":
            if nullable:
                lines.append(f"        df_target_{tgt_safe}['{col_name}'] = pd.to_numeric(df_target_{tgt_safe}['{col_name}'], errors='coerce').astype('{pd_dtype}')")
            else:
                lines.append(f"        df_target_{tgt_safe}['{col_name}'] = pd.to_numeric(df_target_{tgt_safe}['{col_name}'], errors='coerce').fillna(0).astype(int)")
        elif cast_type == "float":
            lines.append(f"        df_target_{tgt_safe}['{col_name}'] = pd.to_numeric(df_target_{tgt_safe}['{col_name}'], errors='coerce')")
        elif cast_type == "bool":
            lines.append(f"        df_target_{tgt_safe}['{col_name}'] = df_target_{tgt_safe}['{col_name}'].astype('{pd_dtype}')")
        if validate_casts:
            lines.append(f"        _post_null_{_safe_name(col_name)} = df_target_{tgt_safe}['{col_name}'].isna().sum()")
            lines.append(f"        _coerced_{_safe_name(col_name)} = int(_post_null_{_safe_name(col_name)} - _pre_null_{_safe_name(col_name)})")
            lines.append(f"        if _coerced_{_safe_name(col_name)} > 0:")
            lines.append(f"            _cast_warnings.append('{col_name}: {{}} values coerced to null during {cast_type} cast'.format(_coerced_{_safe_name(col_name)}))")
            lines.append(f"            logger.warning('Column {col_name}: %d values coerced to null during {cast_type} cast', _coerced_{_safe_name(col_name)})")
    if validate_casts:
        lines.append(f"    if _cast_warnings:")
        lines.append(f"        logger.warning('Data quality warnings for target {tgt_safe}: %s', '; '.join(_cast_warnings))")
