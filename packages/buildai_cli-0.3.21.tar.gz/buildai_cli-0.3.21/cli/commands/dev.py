"""Per-worktree development environment commands."""

from __future__ import annotations

import json
import os
import shlex
from pathlib import Path
from typing import Any

import typer

from cli.console import error, info, success
from cli.dev_context import (
    VALID_PROFILES,
    build_dev_context,
    current_context_snapshot,
    export_env_lines,
    find_context_path,
    load_dev_context,
    save_dev_context,
)

app = typer.Typer(
    name="dev",
    help="Manage the gitignored per-worktree environment context.",
    no_args_is_help=True,
)


def _context_file_path() -> Path | None:
    explicit_path = os.getenv("BUILDAI_CONTEXT_PATH", "").strip()
    if explicit_path:
        return Path(explicit_path).expanduser()
    return find_context_path()


def _db_target(context: dict[str, Any]) -> dict[str, Any]:
    value = context.get("database_target")
    return value if isinstance(value, dict) else {}


def _print_snapshot(snapshot: dict[str, Any]) -> None:
    db = _db_target(snapshot)
    path = _context_file_path()
    typer.echo(f"configured: {'yes' if snapshot.get('configured') else 'no'}")
    typer.echo(f"context_path: {path if path else 'unset'}")
    typer.echo(f"profile: {snapshot.get('profile') or 'unset'}")
    typer.echo(f"branch: {snapshot.get('branch') or 'unknown'}")
    typer.echo(f"preview_env_id: {snapshot.get('preview_env_id') or 'unknown'}")
    typer.echo(f"api_url: {snapshot.get('api_url') or 'unset'}")
    typer.echo(f"mcp_url: {snapshot.get('mcp_url') or 'unset'}")
    typer.echo(f"app_env: {snapshot.get('app_env') or 'unset'}")
    typer.echo(f"db_cluster: {db.get('cluster') or 'unset'}")
    typer.echo(f"db_instance: {db.get('instance') or 'unset'}")
    typer.echo(f"db_name: {db.get('database') or 'unset'}")
    typer.echo(f"db_user: {db.get('user') or 'unset'}")
    if "use_iam_auth" in db:
        typer.echo(f"db_iam_auth: {db['use_iam_auth']}")
    typer.echo(f"cli_access_profile: {snapshot.get('cli_access_profile') or 'unset'}")


@app.command("current")
def current(
    json_output: bool = typer.Option(False, "--json", help="Emit the resolved context as JSON."),
) -> None:
    """Show the current worktree environment context."""
    snapshot = current_context_snapshot()
    if json_output:
        typer.echo(json.dumps(snapshot, indent=2, sort_keys=True))
        return
    _print_snapshot(snapshot)


@app.command("use")
def use(
    profile: str = typer.Argument(..., help="Preset profile to save for this worktree."),
    api_url: str | None = typer.Option(None, "--api-url", help="Override API base URL."),
    mcp_url: str | None = typer.Option(None, "--mcp-url", help="Override MCP base URL."),
    data_url: str | None = typer.Option(None, "--data-url", help="Override internal app URL."),
    partners_url: str | None = typer.Option(
        None, "--partners-url", help="Override partner app URL."
    ),
    app_env: str | None = typer.Option(
        None, "--app-env", help="Override APP_ENV (development, preview, production, test)."
    ),
    db_cluster: str | None = typer.Option(
        None, "--db-cluster", help="Override AlloyDB cluster id."
    ),
    db_instance: str | None = typer.Option(
        None, "--db-instance", help="Override AlloyDB instance id."
    ),
    db_name: str | None = typer.Option(None, "--db-name", help="Override database name."),
    db_user: str | None = typer.Option(None, "--db-user", help="Override database user."),
    db_iam_auth: bool = typer.Option(False, "--db-iam-auth", help="Force IAM DB auth."),
    db_password_auth: bool = typer.Option(
        False, "--db-password-auth", help="Force password DB auth."
    ),
    cli_profile: str | None = typer.Option(
        None, "--cli-profile", help="Optional DAL/ops CLI access profile."
    ),
    yes: bool = typer.Option(False, "--yes", help="Skip the production confirmation prompt."),
) -> None:
    """Save the worktree environment context."""
    normalized_profile = profile.strip().lower()
    if normalized_profile not in VALID_PROFILES:
        error(f"Invalid profile '{profile}'. Valid: {', '.join(sorted(VALID_PROFILES))}.")
        raise typer.Exit(1)
    if db_iam_auth and db_password_auth:
        error("Choose only one of --db-iam-auth or --db-password-auth.")
        raise typer.Exit(1)
    if normalized_profile == "production" and not yes:
        confirmed = typer.confirm(
            "This will make this worktree default to production. Continue?", default=False
        )
        if not confirmed:
            raise typer.Exit(1)

    resolved_db_iam_auth: bool | None = None
    if db_iam_auth:
        resolved_db_iam_auth = True
    elif db_password_auth:
        resolved_db_iam_auth = False

    try:
        context = build_dev_context(
            profile=normalized_profile,
            api_url=api_url,
            mcp_url=mcp_url,
            data_url=data_url,
            partners_url=partners_url,
            app_env=app_env,
            db_cluster=db_cluster,
            db_instance=db_instance,
            db_name=db_name,
            db_user=db_user,
            db_iam_auth=resolved_db_iam_auth,
            cli_access_profile=cli_profile,
        )
        context_path = save_dev_context(context)
    except Exception as exc:
        error(str(exc))
        raise typer.Exit(1) from exc

    success(f"Saved worktree context to {context_path}")
    info('Run `eval "$(uv run buildai dev env)"` in your shell to export it immediately.')


@app.command("env")
def env() -> None:
    """Print shell exports for the current worktree context."""
    context = load_dev_context()
    if context is None:
        error("No worktree context found. Run `uv run buildai dev use <profile>` first.")
        raise typer.Exit(1)

    lines: list[str] = []
    context_path = _context_file_path()
    if context_path is not None:
        lines.append(f"export BUILDAI_CONTEXT_PATH={shlex.quote(str(context_path))}")
    lines.extend(export_env_lines(context))
    typer.echo("\n".join(lines))
