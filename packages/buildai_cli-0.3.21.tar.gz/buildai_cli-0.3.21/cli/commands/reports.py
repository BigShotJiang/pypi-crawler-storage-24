"""CLI commands for shareable productivity reports."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import typer

from cli.output import render
from cli.sdk_client import get_sdk_client

app = typer.Typer(
    name="reports",
    help="Create and list shareable productivity reports.",
    no_args_is_help=True,
)

_GCS_BUCKET = "gs://buildai-reports/shareable"
_LIVE_REPORT_PATHS = {
    "factory-report": "/shared/factory-report",
    "factory-index": "/shared/factory-index",
}


def _build_live_share_url(*, token: str, surface: str, base_url: str) -> str:
    normalized_base_url = base_url.rstrip("/")
    shared_path = _LIVE_REPORT_PATHS[surface]
    return f"{normalized_base_url}{shared_path}/{token}"


@app.command("create", help="Upload an HTML report and register it for sharing.")
def reports_create(
    file: Path = typer.Argument(..., help="Path to the HTML report file."),
    title: str = typer.Option(..., "--title", "-t", help="Report title."),
    partner_id: str = typer.Option(..., "--partner-id", "-p", help="Partner UUID."),
    password: str = typer.Option(..., "--password", help="Shared password for viewing."),
    factory_ids: list[str] = typer.Option(
        [], "--factory-id", "-f", help="Factory UUIDs to link (repeatable)."
    ),
) -> None:
    if not file.exists():
        typer.echo(f"File not found: {file}", err=True)
        raise typer.Exit(1)

    # Upload to GCS
    slug = file.stem
    gcs_uri = f"{_GCS_BUCKET}/{slug}.html"
    typer.echo(f"Uploading {file.name} to {gcs_uri}...", err=True)

    result = subprocess.run(
        ["gcloud", "storage", "cp", str(file), gcs_uri],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        typer.echo(f"Upload failed: {result.stderr}", err=True)
        raise typer.Exit(1)
    typer.echo("Upload complete.", err=True)

    # Register via API
    client = get_sdk_client()
    try:
        resp = client._http.post(
            "/shareable-reports",
            json={
                "partner_id": partner_id,
                "title": title,
                "report_uri": gcs_uri,
                "password": password,
                "factory_ids": factory_ids,
            },
        )
        data = resp.get("data", resp)
    finally:
        client.close()

    short_id = data.get("short_id", "")
    url = data.get("url", f"https://factory.build.ai/r/{short_id}")

    if sys.stdout.isatty():
        typer.echo("", err=True)
        typer.echo("Report created.", err=True)
        typer.echo(f"  URL:      {url}", err=True)
        typer.echo(f"  Password: {password}", err=True)
        typer.echo(f"  Short ID: {short_id}", err=True)
    else:
        typer.echo(url)


@app.command("list", help="List shareable reports for a partner.")
def reports_list(
    partner_id: str = typer.Argument(..., help="Partner UUID."),
) -> None:
    client = get_sdk_client()
    try:
        resp = client._http.get(f"/shareable-reports/by-partner/{partner_id}")
        data = resp.get("data", [])
    finally:
        client.close()

    render(
        data,
        format=None,
        columns=["short_id", "title", "url", "created_at"],
    )


@app.command(
    "live-link",
    help="Create or reuse a live shared report link for a factory or factory unit UUID.",
)
def reports_live_link(
    report_target_id: str = typer.Argument(
        ...,
        help="Factory UUID or factory_unit UUID.",
    ),
    surface: str = typer.Option(
        "factory-report",
        "--surface",
        help="Shared route surface: factory-report or factory-index.",
    ),
    base_url: str = typer.Option(
        "https://factory.build.ai",
        "--base-url",
        help="Public base URL to use for the shared link.",
    ),
) -> None:
    if surface not in _LIVE_REPORT_PATHS:
        typer.echo(
            f"Unsupported surface: {surface}. Expected one of: {', '.join(_LIVE_REPORT_PATHS)}",
            err=True,
        )
        raise typer.Exit(1)

    client = get_sdk_client()
    try:
        existing_resp = client._http.get(f"/factory-report-shares/{report_target_id}")
        existing = existing_resp.get("data", existing_resp)
        share = existing
        if share is None:
            create_resp = client._http.post(f"/factory-report-shares/{report_target_id}")
            share = create_resp.get("data", create_resp)
    finally:
        client.close()

    token = share.get("token")
    if not token:
        typer.echo("Could not create a live report share link.", err=True)
        raise typer.Exit(1)

    url = _build_live_share_url(token=token, surface=surface, base_url=base_url)
    if sys.stdout.isatty():
        typer.echo("", err=True)
        typer.echo("Live report link ready.", err=True)
        typer.echo(f"  Target:  {report_target_id}", err=True)
        typer.echo(f"  Surface: {surface}", err=True)
        typer.echo(f"  URL:     {url}", err=True)
    else:
        typer.echo(url)
