"""
External Datasets CLI - Manage external datasets (Ego4D, EPIC-Kitchens, etc.)

Thin wrapper over data.external module functions.
"""

import asyncio

import typer
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

from cli.console import console, success, error, info, warning
from cli.guard import require_write
from cli.context import get_cli_context

app = typer.Typer(name="external", help="Manage external datasets (Ego4D, EPIC-Kitchens, etc.)")


@app.command("list")
def list_datasets(ctx: typer.Context):
    """List registered external datasets."""
    settings = ctx.obj["settings"]

    async def _list():
        from data.external import datasets, import_service

        async with get_cli_context(settings) as (db, dal_ctx):
            try:
                dataset_list = await datasets.list_datasets(dal_ctx)
            except Exception as e:
                if "does not exist" in str(e):
                    error("External schema not found. Run migration first:")
                    info(
                        "  uv run buildai admin --write database migrate 034_create_external_schema.sql"
                    )
                    return
                raise

            known = import_service.get_known_datasets()

            if not dataset_list:
                info("No external datasets registered.")
                info("Use 'uv run buildai admin external register <name>' to add a dataset.")
                info(f"Available: {', '.join(known.keys())}")
                return

            table = Table(title="External Datasets")
            table.add_column("Name", style="cyan")
            table.add_column("Display Name")
            table.add_column("Videos", justify="right", style="green")
            table.add_column("Frames", justify="right")
            table.add_column("Duration (hrs)", justify="right")
            table.add_column("Version", style="dim")

            for ds in dataset_list:
                table.add_row(
                    ds.name,
                    ds.display_name,
                    str(ds.total_videos or 0),
                    str(ds.total_frames or "-"),
                    f"{ds.total_duration_hours:.1f}" if ds.total_duration_hours else "-",
                    ds.version or "-",
                )

            console.print(table)

    asyncio.run(_list())


@app.command("register")
def register_dataset(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Dataset name (e.g., 'ego4d', 'epic-kitchens')"),
):
    """Register a new external dataset."""
    require_write(ctx, "External dataset registration")
    settings = ctx.obj["settings"]

    async def _register():
        from data.external import datasets, import_service
        from data.models.external import ExternalDatasetCreate

        known = import_service.get_known_datasets()

        if name not in known:
            error(f"Unknown dataset: {name}")
            info(f"Available datasets: {', '.join(known.keys())}")
            raise typer.Exit(1)

        config = known[name]

        async with get_cli_context(settings) as (db, dal_ctx):
            # Check if already exists
            if await datasets.exists(dal_ctx, name):
                warning(f"Dataset '{name}' already registered.")
                ds = await datasets.get_by_name(dal_ctx, name)
                info(f"  ID: {ds.id}")
                info(f"  Videos: {ds.total_videos or 0}")
                return

            # Create dataset
            data = ExternalDatasetCreate(
                name=name,
                display_name=config["display_name"],
                description=config["description"],
                source_url=config["source_url"],
                license=config["license"],
                version=config["version"],
                video_bucket=config["video_bucket"],
                video_prefix=config["video_prefix"],
                manifest_uri=config["manifest_uri"],
            )

            ds = await datasets.create(dal_ctx, data)
            success(f"Registered dataset: {ds.name}")
            info(f"  ID: {ds.id}")
            info(f"  Video bucket: {ds.video_bucket}")

    asyncio.run(_register())


@app.command("import-clips")
def import_clips(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Dataset name to import"),
    limit: int = typer.Option(None, "--limit", "-l", help="Limit number of clips to import"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be imported"),
):
    """Import clips from BigQuery categorization tables."""
    if not dry_run:
        require_write(ctx, "External dataset clip import")
    settings = ctx.obj["settings"]

    async def _import():
        from data.external import import_service

        known = import_service.get_known_datasets()
        if name not in known:
            error(f"Unknown dataset: {name}")
            raise typer.Exit(1)

        if dry_run:
            # For dry run, just query BQ and show sample
            from google.cloud import bigquery

            config = known[name]
            bq_client = bigquery.Client(project=settings.gcp_project_id)
            limit_clause = f"LIMIT {limit or 5}"
            query = f"""
                SELECT video_id, original_id, video_uri
                FROM `{settings.gcp_project_id}.{config["bq_input_table"]}`
                {limit_clause}
            """
            result = bq_client.query(query).result()
            rows = list(result)

            info(f"Dry run - sample from {config['bq_input_table']}:")
            for row in rows:
                console.print(f"  {row['original_id']}: {row['video_uri'][:60]}...")
            return

        async with get_cli_context(settings) as (db, dal_ctx):
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task("Importing clips from BigQuery...", total=None)

                imported, total = await import_service.import_clips_from_bigquery(
                    dal_ctx, name, settings.gcp_project_id, limit=limit
                )

            success(f"Imported {imported} clips for {name}")
            info(f"Total in BigQuery: {total}")

    asyncio.run(_import())


@app.command("import-descriptions")
def import_descriptions(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Dataset name to import descriptions for"),
    limit: int = typer.Option(None, "--limit", "-l", help="Limit number of descriptions"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be imported"),
):
    """Import VLM descriptions from BigQuery output tables."""
    if not dry_run:
        require_write(ctx, "External dataset description import")
    settings = ctx.obj["settings"]

    async def _import():
        from data.external import import_service

        known = import_service.get_known_datasets()
        if name not in known:
            error(f"Unknown dataset: {name}")
            raise typer.Exit(1)

        if dry_run:
            # For dry run, just show BQ query info
            config = known[name]
            info(f"Would import from: {config['bq_output_table']}")
            info("Run without --dry-run to import.")
            return

        async with get_cli_context(settings) as (db, dal_ctx):
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task("Importing descriptions from BigQuery...", total=None)

                imported, total, skipped = await import_service.import_descriptions_from_bigquery(
                    dal_ctx, name, settings.gcp_project_id, limit=limit
                )

            success(f"Imported {imported} descriptions for {name}")
            if skipped:
                warning(f"Skipped {skipped} (clip not found - import clips first)")
            info(f"Total in BigQuery: {total}")

    asyncio.run(_import())


@app.command("stats")
def show_stats(ctx: typer.Context):
    """Show statistics for all external datasets."""
    settings = ctx.obj["settings"]

    async def _stats():
        from data.external import datasets, clips

        async with get_cli_context(settings) as (db, dal_ctx):
            try:
                dataset_list = await datasets.list_datasets(dal_ctx)
            except Exception as e:
                if "does not exist" in str(e):
                    error("External schema not found.")
                    return
                raise

            if not dataset_list:
                info("No external datasets registered.")
                return

            for ds in dataset_list:
                console.print(f"\n[bold cyan]{ds.display_name}[/bold cyan] ({ds.name})")
                console.print(f"  Version: {ds.version or 'N/A'}")
                console.print(f"  Video bucket: {ds.video_bucket}")

                # Get clip counts
                clip_count = await clips.count_by_dataset(dal_ctx, ds.id)
                console.print(f"  Clips: [green]{clip_count}[/green]")

                # Get split breakdown if clips exist
                if clip_count > 0:
                    for split in ["train", "val", "test"]:
                        split_count = await clips.count_by_dataset(dal_ctx, ds.id, split=split)
                        if split_count > 0:
                            console.print(f"    {split}: {split_count}")

                # Get description count
                desc_query = await dal_ctx.db.fetchrow(
                    """
                    SELECT COUNT(*) as count
                    FROM external.clip_descriptions d
                    JOIN external.clips c ON d.clip_id = c.id
                    WHERE c.dataset_id = $1
                    """,
                    ds.id,
                )
                desc_count = desc_query["count"] if desc_query else 0
                console.print(f"  Descriptions: [green]{desc_count}[/green]")

    asyncio.run(_stats())
