"""Per-worktree developer environment context for repo-local workflows."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DEV_CONTEXT_DIRNAME = ".buildai"
DEV_CONTEXT_FILENAME = "context.json"
DEV_CONTEXT_SUMMARY_FILENAME = "context.md"
VALID_PROFILES = {
    "local",
    "local-staging-api",
    "preview",
    "staging",
    "production",
    "custom",
}
_PREVIEW_MAX_LEN = 26


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _find_repo_root(start_path: Path | None = None) -> Path | None:
    current = (start_path or Path.cwd()).resolve()
    for candidate in (current, *current.parents):
        if (candidate / ".git").exists():
            return candidate
    return None


def find_context_path(start_path: Path | None = None) -> Path | None:
    repo_root = _find_repo_root(start_path)
    if repo_root is None:
        return None
    return repo_root / DEV_CONTEXT_DIRNAME / DEV_CONTEXT_FILENAME


def require_context_path(start_path: Path | None = None) -> Path:
    context_path = find_context_path(start_path)
    if context_path is None:
        raise RuntimeError("Not inside a git worktree for this repo.")
    return context_path


def load_dev_context(start_path: Path | None = None) -> dict[str, Any] | None:
    explicit_path = os.getenv("BUILDAI_CONTEXT_PATH", "").strip()
    if explicit_path:
        path = Path(explicit_path).expanduser()
    else:
        path = find_context_path(start_path)
    if path is None or not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def normalize_preview_env_id(branch_name: str, *, max_len: int = _PREVIEW_MAX_LEN) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", branch_name.lower())
    slug = re.sub(r"-+", "-", slug).strip("-")
    if not slug:
        slug = "preview"
    if len(slug) <= max_len:
        return slug
    digest = hashlib.sha256(branch_name.encode("utf-8")).hexdigest()[:8]
    prefix_len = max_len - 1 - len(digest)
    slug = f"{slug[:prefix_len]}-{digest}".rstrip("-")
    return slug


def _git_output(args: list[str], cwd: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception:
        return None
    if result.returncode != 0:
        return None
    value = result.stdout.strip()
    return value or None


def _repo_metadata(start_path: Path | None = None) -> dict[str, Any]:
    repo_root = _find_repo_root(start_path)
    cwd = (start_path or Path.cwd()).resolve()
    branch = _git_output(["branch", "--show-current"], cwd) if repo_root else None
    commit_sha = _git_output(["rev-parse", "HEAD"], cwd) if repo_root else None
    preview_env_id = normalize_preview_env_id(branch) if branch else None
    return {
        "repo_root": str(repo_root) if repo_root else None,
        "worktree_path": str(cwd),
        "branch": branch,
        "commit_sha": commit_sha,
        "preview_env_id": preview_env_id,
    }


def _default_database_target(app_env: str) -> dict[str, Any]:
    if app_env == "production":
        return {
            "cluster": "buildai-production",
            "instance": "buildai-primary",
            "database": "buildai-production-database",
            "use_iam_auth": True,
        }
    return {
        "cluster": "buildai-preview",
        "instance": "buildai-preview-primary",
        "database": "buildai-production-database",
        "use_iam_auth": True,
    }


def _profile_defaults(profile: str, metadata: dict[str, Any]) -> dict[str, Any]:
    env_id = metadata.get("preview_env_id")
    if profile == "local":
        return {
            "api_url": "http://127.0.0.1:8000",
            "mcp_url": "http://127.0.0.1:3001/mcp",
            "data_url": "https://localhost.data.build.ai:3000",
            "partners_url": "https://localhost.partners.build.ai:3000",
            "app_env": "development",
            "database_target": _default_database_target("development"),
        }
    if profile == "local-staging-api":
        return {
            "api_url": "https://staging.api.build.ai",
            "mcp_url": "https://staging.mcp.build.ai",
            "data_url": "https://localhost.data.build.ai:3000",
            "partners_url": "https://localhost.partners.build.ai:3000",
            "app_env": "preview",
            "database_target": _default_database_target("preview"),
        }
    if profile == "preview":
        if not env_id:
            raise RuntimeError("Cannot derive preview environment without a git branch.")
        return {
            "api_url": f"https://{env_id}.preview.api.build.ai",
            "mcp_url": f"https://{env_id}.preview.mcp.build.ai",
            "data_url": f"https://{env_id}.preview.data.build.ai",
            "partners_url": f"https://{env_id}.preview.partners.build.ai",
            "app_env": "preview",
            "database_target": _default_database_target("preview"),
        }
    if profile == "staging":
        return {
            "api_url": "https://staging.api.build.ai",
            "mcp_url": "https://staging.mcp.build.ai",
            "data_url": "https://staging.data.build.ai",
            "partners_url": "https://staging.partners.build.ai",
            "app_env": "preview",
            "database_target": _default_database_target("preview"),
        }
    if profile == "production":
        return {
            "api_url": "https://api.build.ai",
            "mcp_url": "https://mcp.data.build.ai",
            "data_url": "https://data.build.ai",
            "partners_url": "https://partners.build.ai",
            "app_env": "production",
            "database_target": _default_database_target("production"),
        }
    if profile == "custom":
        return {}
    raise ValueError(f"Unknown profile: {profile}")


def build_dev_context(
    *,
    profile: str,
    api_url: str | None = None,
    mcp_url: str | None = None,
    data_url: str | None = None,
    partners_url: str | None = None,
    app_env: str | None = None,
    db_cluster: str | None = None,
    db_instance: str | None = None,
    db_name: str | None = None,
    db_user: str | None = None,
    db_iam_auth: bool | None = None,
    cli_access_profile: str | None = None,
    start_path: Path | None = None,
) -> dict[str, Any]:
    profile = profile.strip().lower()
    if profile not in VALID_PROFILES:
        raise ValueError(
            f"Unknown profile: {profile}. Valid profiles: {', '.join(sorted(VALID_PROFILES))}."
        )
    metadata = _repo_metadata(start_path)
    defaults = _profile_defaults(profile, metadata)
    resolved_app_env = app_env or defaults.get("app_env") or "preview"
    database_target = dict(
        defaults.get("database_target") or _default_database_target(resolved_app_env)
    )
    if db_cluster:
        database_target["cluster"] = db_cluster
    if db_instance:
        database_target["instance"] = db_instance
    if db_name:
        database_target["database"] = db_name
    if db_user:
        database_target["user"] = db_user
    if db_iam_auth is not None:
        database_target["use_iam_auth"] = db_iam_auth

    context = {
        "version": 1,
        **metadata,
        "profile": profile,
        "api_url": api_url or defaults.get("api_url"),
        "mcp_url": mcp_url or defaults.get("mcp_url"),
        "data_url": data_url or defaults.get("data_url"),
        "partners_url": partners_url or defaults.get("partners_url"),
        "app_env": resolved_app_env,
        "database_target": database_target,
        "generated_at": _now_iso(),
    }
    if cli_access_profile:
        context["cli_access_profile"] = cli_access_profile
    return context


def _summary_markdown(context: dict[str, Any]) -> str:
    db = context.get("database_target") if isinstance(context.get("database_target"), dict) else {}
    lines = [
        "# Build AI Worktree Context",
        "",
        f"- profile: `{context.get('profile') or 'unset'}`",
        f"- branch: `{context.get('branch') or 'unknown'}`",
        f"- worktree: `{context.get('worktree_path') or 'unknown'}`",
        f"- preview env id: `{context.get('preview_env_id') or 'none'}`",
        f"- api url: `{context.get('api_url') or 'unset'}`",
        f"- app env: `{context.get('app_env') or 'unset'}`",
        f"- db cluster: `{db.get('cluster') or 'unset'}`",
        f"- db instance: `{db.get('instance') or 'unset'}`",
        f"- db name: `{db.get('database') or 'unset'}`",
    ]
    if db.get("user"):
        lines.append(f"- db user: `{db['user']}`")
    if "use_iam_auth" in db:
        lines.append(f"- db iam auth: `{db['use_iam_auth']}`")
    if context.get("cli_access_profile"):
        lines.append(f"- cli access profile: `{context['cli_access_profile']}`")
    lines.append("")
    return "\n".join(lines)


def save_dev_context(context: dict[str, Any], start_path: Path | None = None) -> Path:
    context_path = require_context_path(start_path)
    context_path.parent.mkdir(parents=True, exist_ok=True)
    context_path.write_text(json.dumps(context, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    summary_path = context_path.parent / DEV_CONTEXT_SUMMARY_FILENAME
    summary_path.write_text(_summary_markdown(context), encoding="utf-8")
    return context_path


def export_env_lines(context: dict[str, Any]) -> list[str]:
    app_env = str(context.get("app_env") or "").strip()
    db = context.get("database_target") if isinstance(context.get("database_target"), dict) else {}
    lines = [
        f"export BUILDAI_ENV_PROFILE={shlex.quote(str(context.get('profile') or ''))}",
        f"export BUILDAI_PREVIEW_ENV_ID={shlex.quote(str(context.get('preview_env_id') or ''))}",
    ]
    if context.get("api_url"):
        lines.append(f"export BUILDAI_API_URL={shlex.quote(str(context['api_url']))}")
    if context.get("mcp_url"):
        lines.append(f"export BUILDAI_MCP_URL={shlex.quote(str(context['mcp_url']))}")
    if app_env:
        lines.append(f"export APP_ENV={shlex.quote(app_env)}")
    if db.get("cluster"):
        lines.append(f"export ALLOYDB_CLUSTER={shlex.quote(str(db['cluster']))}")
    if db.get("instance"):
        lines.append(f"export ALLOYDB_INSTANCE={shlex.quote(str(db['instance']))}")
    if db.get("database"):
        lines.append(f"export DB_NAME={shlex.quote(str(db['database']))}")
    if db.get("user"):
        if app_env == "production":
            lines.append(f"export ALLOYDB_USER_PROD={shlex.quote(str(db['user']))}")
        else:
            lines.append(f"export ALLOYDB_USER_PREVIEW={shlex.quote(str(db['user']))}")
    if "use_iam_auth" in db:
        iam_value = "true" if bool(db["use_iam_auth"]) else "false"
        if app_env == "production":
            lines.append(f"export ALLOYDB_IAM_AUTH_PROD={iam_value}")
        else:
            lines.append(f"export ALLOYDB_IAM_AUTH_PREVIEW={iam_value}")
    if context.get("cli_access_profile"):
        lines.append(
            f"export BUILDAI_CLI_PROFILE={shlex.quote(str(context['cli_access_profile']))}"
        )
    return lines


def current_context_snapshot(start_path: Path | None = None) -> dict[str, Any]:
    metadata = _repo_metadata(start_path)
    configured = load_dev_context(start_path)
    snapshot: dict[str, Any] = {"configured": configured is not None}
    if configured is not None:
        snapshot.update(configured)
    snapshot.update(metadata)
    return snapshot
