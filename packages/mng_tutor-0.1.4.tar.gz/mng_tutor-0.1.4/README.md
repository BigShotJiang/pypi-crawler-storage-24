# mng-tutor

This package has been renamed to [imbue-mngr-tutor](https://pypi.org/project/imbue-mngr-tutor/).

Install the new package:

```
pip install imbue-mngr-tutor
```
