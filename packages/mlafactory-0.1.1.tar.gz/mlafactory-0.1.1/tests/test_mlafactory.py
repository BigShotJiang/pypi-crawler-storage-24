# tests/test_mlafactory.py
"""
Comprehensive test suite for mlafactory.

Coverage areas:
  - Inventory: get/put, async waiting, edge values
  - Machine: setup avoidance, cycle counting, task durations
  - MachineDispatcher: routing, queuing, unknown types
  - FactoryRunner: validation, run, splitting, seeds, edge cases
"""

import pytest
import simpy

from mlafactory.Machine import Machine
from mlafactory.Inventory import Inventory
from mlafactory.MachineDispatcher import MachineDispatcher
from mlafactory.FactoryRunner import FactoryRunner
from mlafactory.aux_files import InputValidationError


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def noop_callback(item):
    """No-op minmax callback for inventory tests."""
    pass


def make_env():
    return simpy.Environment()


def make_inventory(env, stock, callback=None):
    return Inventory(
        env=env,
        initial_stock=stock,
        minmax_callback=callback or noop_callback,
    )


def run_until(env, timeout=1000):
    env.run(until=timeout)


# ─────────────────────────────────────────────
# FIXTURES
# ─────────────────────────────────────────────

@pytest.fixture
def simple_bom():
    return {
        "bike": {
            "type": "bike",
            "bom": {
                "wheel": {"type": "wheel", "qty": 2},
                "frame": {"type": "frame", "qty": 1},
            },
        },
        "wheel": {
            "type": "wheel",
            "bom": {
                "rim": {"type": "raw", "qty": 1},
                "tire": {"type": "raw", "qty": 1},
            },
        },
        "frame": {
            "type": "frame",
            "bom": {
                "tube": {"type": "raw", "qty": 1},
            },
        },
    }


@pytest.fixture
def simple_stock_limits():
    return {
        "bike":  {"min": 2, "max": 10},
        "wheel": {"min": 4, "max": 20},
        "frame": {"min": 2, "max": 10},
        "rim":   {"min": 5, "max": 20},
        "tire":  {"min": 5, "max": 20},
        "tube":  {"min": 5, "max": 20},
    }


@pytest.fixture
def simple_reorder_delays():
    return {
        "rim":  {"reorder_delay": 5},
        "tire": {"reorder_delay": 5},
        "tube": {"reorder_delay": 5},
    }


@pytest.fixture
def simple_inventory():
    return {
        "bike": 0, "wheel": 0, "frame": 0,
        "rim": 10, "tire": 10, "tube": 10,
    }


@pytest.fixture
def simple_machines():
    return [
        {"name": "bk01", "type": "bike",  "setup_time": 1, "cycle_time": 5},
        {"name": "wl01", "type": "wheel", "setup_time": 1, "cycle_time": 3},
        {"name": "fr01", "type": "frame", "setup_time": 1, "cycle_time": 2},
    ]


def make_runner(
    bom, inventory, machines, stock_limits, reorder_delays,
    demand=None, months=1, hours=160, **kwargs
):
    """Helper to construct a FactoryRunner with sensible defaults."""
    if demand is None:
        demand = {"order_01": {"bike": 1}}
    return FactoryRunner(
        factory_name="test_factory",
        product_demand=demand,
        bom=bom,
        initial_inventory=inventory,
        machines=machines,
        stock_limits=stock_limits,
        reorder_delays=reorder_delays,
        months=months,
        hours_per_month=hours,
        show_output=False,
        show_debug=False,
        export_reports=False,
        output_dir="/tmp/",
        **kwargs,
    )


# ═════════════════════════════════════════════
# INVENTORY TESTS
# ═════════════════════════════════════════════

class TestInventoryGet:

    def test_immediate_fulfillment_returns_none(self):
        env = make_env()
        inv = make_inventory(env, {"part": 10})
        result = inv.get("part", 5)
        assert result.value is None

    def test_immediate_fulfillment_deducts_stock(self):
        env = make_env()
        inv = make_inventory(env, {"part": 10})
        inv.get("part", 3)
        assert inv.stock["part"] == 7

    def test_insufficient_stock_returns_event(self):
        env = make_env()
        inv = make_inventory(env, {"part": 2})
        event = inv.get("part", 5)
        assert event is not None
        assert not event.triggered

    def test_insufficient_stock_does_not_deduct(self):
        env = make_env()
        inv = make_inventory(env, {"part": 2})
        inv.get("part", 5)
        assert inv.stock["part"] == 2  # unchanged

    def test_exact_quantity_fulfills_immediately(self):
        env = make_env()
        inv = make_inventory(env, {"part": 5})
        result = inv.get("part", 5)
        assert result.value is None
        assert inv.stock["part"] == 0

    def test_zero_stock_item_returns_event(self):
        env = make_env()
        inv = make_inventory(env, {"part": 0})
        event = inv.get("part", 1)
        assert event is not None

    def test_unknown_item_returns_event(self):
        """Getting a non-existent item should not crash — defaultdict gives 0."""
        env = make_env()
        inv = make_inventory(env, {})
        event = inv.get("ghost", 1)
        assert event is not None

    def test_consumed_log_on_immediate_fulfillment(self):
        env = make_env()
        inv = make_inventory(env, {"part": 10})
        inv.get("part", 4)
        assert any(entry[1] == "part" and entry[2] == 4 for entry in inv.consumed)

    def test_callback_triggered_on_immediate_get(self):
        triggered = []
        env = make_env()
        inv = make_inventory(env, {"part": 10}, callback=lambda item: triggered.append(item))
        inv.get("part", 1)
        assert "part" in triggered


class TestInventoryPut:

    def test_put_increases_stock(self):
        env = make_env()
        inv = make_inventory(env, {"part": 5})
        inv.put("part", 10)
        assert inv.stock["part"] == 15

    def test_put_fulfills_waiting_get(self):
        env = make_env()
        inv = make_inventory(env, {"part": 0})
        event = inv.get("part", 5)
        assert not event.triggered
        inv.put("part", 5)
        assert event.triggered

    def test_put_partial_does_not_fulfill_waiting_get(self):
        env = make_env()
        inv = make_inventory(env, {"part": 0})
        event = inv.get("part", 10)
        inv.put("part", 5)        # not enough
        assert not event.triggered
        assert inv.stock["part"] == 5

    def test_put_fulfills_multiple_waiting_gets_in_order(self):
        env = make_env()
        inv = make_inventory(env, {"part": 0})
        evt1 = inv.get("part", 3)
        evt2 = inv.get("part", 3)
        inv.put("part", 3)
        assert evt1.triggered
        assert not evt2.triggered
        inv.put("part", 3)
        assert evt2.triggered

    def test_put_excess_stays_in_stock(self):
        env = make_env()
        inv = make_inventory(env, {"part": 0})
        inv.put("part", 20)
        assert inv.stock["part"] == 20

    def test_added_tracking(self):
        env = make_env()
        inv = make_inventory(env, {"part": 0})
        inv.put("part", 7)
        inv.put("part", 3)
        assert inv.added["part"] == 10

    def test_callback_triggered_on_put(self):
        triggered = []
        env = make_env()
        inv = make_inventory(env, {"part": 0}, callback=lambda item: triggered.append(item))
        inv.get("part", 1)        # queue a waiter
        inv.put("part", 1)        # fulfill it → callback
        assert triggered.count("part") >= 1


# ═════════════════════════════════════════════
# MACHINE TESTS
# ═════════════════════════════════════════════

class TestMachine:

    def _make_machine_with_dispatcher(self, setup_time=1, cycle_time=5):
        """Build a minimal Machine + stub dispatcher wired together."""
        env = make_env()

        class StubDispatcher:
            def __init__(self):
                self.ready_calls = []
            def machine_ready(self, m):
                self.ready_calls.append(m)

        dispatcher = StubDispatcher()
        m = Machine(
            env=env,
            name="test_machine",
            machine_type="widget",
            setup_time=setup_time,
            cycle_time=cycle_time,
            dispatcher=dispatcher,
        )
        return env, m, dispatcher

    def test_machine_processes_task(self):
        env, m, dispatcher = self._make_machine_with_dispatcher()
        done_event = env.event()
        task = {
            "component": "widget",
            "id": "t1",
            "event": done_event,
            "qty": 1,
            "details": {"type": "widget", "bom": {}},
        }
        m.idle.put(task)
        env.run(until=500)
        assert done_event.triggered

    def test_machine_counts_cycles(self):
        env, m, dispatcher = self._make_machine_with_dispatcher(cycle_time=1)
        done = env.event()
        task = {
            "component": "widget", "id": "t1",
            "event": done, "qty": 3,
            "details": {"type": "widget", "bom": {}},
        }
        m.idle.put(task)
        env.run(until=500)
        assert m.n_cycles == 3

    def test_setup_skipped_for_same_product(self):
        env, m, dispatcher = self._make_machine_with_dispatcher(setup_time=60, cycle_time=1)

        def run_two_tasks():
            e1 = env.event()
            e2 = env.event()
            t1 = {"component": "widget", "id": "t1", "event": e1, "qty": 1,
                  "details": {"type": "widget", "bom": {}}}
            t2 = {"component": "widget", "id": "t2", "event": e2, "qty": 1,
                  "details": {"type": "widget", "bom": {}}}
            m.idle.put(t1)
            yield e1
            m.idle.put(t2)
            yield e2

        env.process(run_two_tasks())
        env.run(until=5000)
        # Only one setup should have occurred
        assert m.n_setups == 1

    def test_setup_runs_on_product_switch(self):
        env, m, dispatcher = self._make_machine_with_dispatcher(setup_time=1, cycle_time=1)

        def run_two_tasks():
            e1 = env.event()
            e2 = env.event()
            t1 = {"component": "widget_A", "id": "t1", "event": e1, "qty": 1,
                  "details": {"type": "widget", "bom": {}}}
            t2 = {"component": "widget_B", "id": "t2", "event": e2, "qty": 1,
                  "details": {"type": "widget", "bom": {}}}
            m.idle.put(t1)
            yield e1
            m.idle.put(t2)
            yield e2

        env.process(run_two_tasks())
        env.run(until=5000)
        assert m.n_setups == 2

    def test_machine_notifies_dispatcher_on_completion(self):
        env, m, dispatcher = self._make_machine_with_dispatcher()
        done = env.event()
        task = {"component": "widget", "id": "t1", "event": done, "qty": 1,
                "details": {"type": "widget", "bom": {}}}
        m.idle.put(task)
        env.run(until=500)
        assert m in dispatcher.ready_calls

    def test_task_durations_accumulate(self):
        env, m, dispatcher = self._make_machine_with_dispatcher(setup_time=1, cycle_time=5)
        done = env.event()
        task = {"component": "widget", "id": "t1", "event": done, "qty": 2,
                "details": {"type": "widget", "bom": {}}}
        m.idle.put(task)
        env.run(until=500)
        assert m.task_durations["setup"] > 0
        assert m.task_durations["building"] > 0

    def test_time_units_converted_from_minutes(self):
        """setup_time and cycle_time should be stored as hours (divided by 60)."""
        env = make_env()
        m = Machine(env, "m", "t", setup_time=60, cycle_time=30,
                    dispatcher=None)
        assert m.setup_time == pytest.approx(1.0)
        assert m.cycle_time == pytest.approx(0.5)


# ═════════════════════════════════════════════
# MACHINE DISPATCHER TESTS
# ═════════════════════════════════════════════

class TestMachineDispatcher:

    def _make_dispatcher(self, n_machines=2, machine_type="widget"):
        env = make_env()

        class StubFactory:
            class inventory:
                stock = {"part": 100}
                @staticmethod
                def get(item, qty):
                    return None
                @staticmethod
                def put(item, qty):
                    pass

        machines = []
        for i in range(n_machines):
            m = Machine(env, f"m{i}", machine_type, 0, 1, None)
            machines.append(m)

        factory = StubFactory()
        dispatcher = MachineDispatcher(env, machines, factory)
        for m in machines:
            m.dispatcher = dispatcher
        return env, dispatcher, machines

    def test_task_routed_to_available_machine(self):
        env, dispatcher, machines = self._make_dispatcher(n_machines=1)
        task = {
            "component": "widget", "id": "t1", "qty": 1,
            "details": {"type": "widget", "bom": {}},
        }
        dispatcher.submit_task([task])
        env.run(until=500)
        assert machines[0].n_cycles >= 1

    def test_second_task_queues_when_all_busy(self):
        """With 1 machine and 2 simultaneous tasks, second should queue."""
        env, dispatcher, machines = self._make_dispatcher(n_machines=1)
        task1 = {"component": "widget", "id": "t1", "qty": 1,
                 "details": {"type": "widget", "bom": {}}}
        task2 = {"component": "widget", "id": "t2", "qty": 1,
                 "details": {"type": "widget", "bom": {}}}
        dispatcher.submit_task([task1])
        dispatcher.submit_task([task2])
        # Advance just enough for dispatch logic to run, but not finish tasks
        env.run(until=0.001)
        # Before running, second task should be in waiting queue
        assert len(dispatcher.waiting_tasks["widget"]) == 1

    def test_machine_returned_to_queue_after_task(self):
        env, dispatcher, machines = self._make_dispatcher(n_machines=1)
        task = {"component": "widget", "id": "t1", "qty": 1,
                "details": {"type": "widget", "bom": {}}}
        dispatcher.submit_task([task])
        env.run(until=500)
        assert len(dispatcher.machine_queues["widget"]) == 1

    def test_multiple_machines_utilised_concurrently(self):
        env, dispatcher, machines = self._make_dispatcher(n_machines=2)
        task1 = {"component": "widget", "id": "t1", "qty": 1,
                 "details": {"type": "widget", "bom": {}}}
        task2 = {"component": "widget", "id": "t2", "qty": 1,
                 "details": {"type": "widget", "bom": {}}}
        dispatcher.submit_task([task1])
        dispatcher.submit_task([task2])
        # Advance just enough for dispatch logic to run, but not finish tasks
        env.run(until=0.001)
        # Both machines should be busy immediately (queue empty)
        assert len(dispatcher.machine_queues["widget"]) == 0


# ═════════════════════════════════════════════
# FACTORY RUNNER — VALIDATION TESTS
# ═════════════════════════════════════════════

class TestFactoryRunnerValidation:

    def test_unknown_product_in_demand_raises(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            demand={"o1": {"nonexistent_product": 1}},
        )
        with pytest.raises(InputValidationError, match="not defined in BOM"):
            runner.prepare_and_validate()

    def test_missing_machine_type_raises(
        self, simple_bom, simple_inventory,
        simple_stock_limits, simple_reorder_delays
    ):
        machines_no_wheel = [
            {"name": "bk01", "type": "bike",  "setup_time": 1, "cycle_time": 5},
            {"name": "fr01", "type": "frame", "setup_time": 1, "cycle_time": 2},
            # No wheel machine
        ]
        runner = make_runner(
            simple_bom, simple_inventory, machines_no_wheel,
            simple_stock_limits, simple_reorder_delays,
        )
        with pytest.raises(InputValidationError, match="no machines"):
            runner.prepare_and_validate()

    def test_missing_stock_limits_raises(
        self, simple_bom, simple_inventory, simple_machines,
        simple_reorder_delays
    ):
        incomplete_limits = {"bike": {"min": 0, "max": 10}}  # missing wheel, frame, raws
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            incomplete_limits, simple_reorder_delays,
        )
        with pytest.raises(InputValidationError, match="Stock limits missing"):
            runner.prepare_and_validate()

    def test_raw_material_missing_reorder_delay_raises(
        self, simple_bom, simple_inventory, simple_machines, simple_stock_limits
    ):
        incomplete_delays = {"rim": {"reorder_delay": 5}}  # missing tire, tube
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, incomplete_delays,
        )
        with pytest.raises(InputValidationError, match="missing in component_info"):
            runner.prepare_and_validate()

    def test_no_machines_raises(
        self, simple_bom, simple_inventory,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, [],
            simple_stock_limits, simple_reorder_delays,
        )
        with pytest.raises(InputValidationError):
            runner.prepare_and_validate()

    def test_duplicate_order_id_raises(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            demand={"dup": {"bike": 1}, "dup": {"bike": 2}},  # Python dedupes keys
        )
        # Python dict deduplicates keys at parse time, so this
        # tests that single-key demand still runs without error
        result = runner.run()
        assert "production" in result

    def test_zero_quantity_order_raises(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            demand={"o1": {"bike": 0}},
        )
        with pytest.raises((InputValidationError, Exception)):
            runner.run()

    def test_negative_quantity_order_raises(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            demand={"o1": {"bike": -5}},
        )
        with pytest.raises((InputValidationError, Exception)):
            runner.run()


# ═════════════════════════════════════════════
# FACTORY RUNNER — RUN / OUTPUT TESTS
# ═════════════════════════════════════════════

class TestFactoryRunnerOutput:

    def test_result_has_required_keys(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
        )
        result = runner.run()
        assert {"simulation_time", "real_simulation_time",
                "production", "machines", "inventory"} <= result.keys()

    def test_production_rows_have_expected_keys(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
        )
        result = runner.run()
        required = {"product", "demand", "fulfilled", "fulfillment_ratio",
                    "production", "production_ratio", "inventory"}
        for row in result["production"]:
            assert required <= row.keys()

    def test_fulfillment_ratio_between_0_and_1(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
        )
        result = runner.run()
        for row in result["production"]:
            assert 0.0 <= row["fulfillment_ratio"] <= 1.0

    def test_simulation_time_matches_config(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            months=3, hours=160,
        )
        result = runner.run()
        assert result["simulation_time"] == 3 * 160

    def test_zero_initial_inventory_fulfillment_below_1(
        self, simple_bom, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        zero_inv = {"bike": 0, "wheel": 0, "frame": 0, "rim": 0, "tire": 0, "tube": 0}
        runner = make_runner(
            simple_bom, zero_inv, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            demand={"o1": {"bike": 500}},  # Impossible in 1 month
            months=1,
        )
        result = runner.run()
        bike_row = next(r for r in result["production"] if r["product"] == "bike")
        assert bike_row["fulfillment_ratio"] < 1.0

    def test_large_order_split_into_suborders(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        """Order qty > max_stock should be split; all suborders tracked."""
        max_stock = simple_stock_limits["bike"]["max"]  # 10
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            demand={"big_order": {"bike": max_stock * 3}},
            months=6,
        )
        result = runner.run()
        # Simulation should complete without error
        assert "production" in result

    def test_machines_summary_accounts_for_all_time(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        runner = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
        )
        result = runner.run()
        sim_time = result["simulation_time"]
        for row in result["machines"]:
            total = row.get("tt_setup", 0) + row.get("tt_build", 0) + row.get("tt_idle", 0)
            assert total == pytest.approx(sim_time, rel=1e-3), (
                f"Machine {row['name']} durations don't sum to simulation_time"
            )


# ═════════════════════════════════════════════
# FACTORY RUNNER — REPRODUCIBILITY
# ═════════════════════════════════════════════

class TestReproducibility:

    def test_same_seed_same_result(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        kwargs = dict(
            bom=simple_bom, inventory=simple_inventory, machines=simple_machines,
            stock_limits=simple_stock_limits, reorder_delays=simple_reorder_delays,
            months=2, inventory_seed=99,
        )
        r1 = make_runner(**kwargs).run()
        r2 = make_runner(**kwargs).run()
        assert r1["production"] == r2["production"]

    def test_different_seed_may_differ(
        self, simple_bom, simple_inventory, simple_machines,
        simple_stock_limits, simple_reorder_delays
    ):
        """With random inventory strategy, different seeds should produce
        different initial inventories (and thus potentially different results)."""
        r1 = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            inventory_strategy="random", inventory_seed=1,
        ).run()
        r2 = make_runner(
            simple_bom, simple_inventory, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            inventory_strategy="random", inventory_seed=999,
        ).run()
        # Not guaranteed to differ, but document the intent
        # (at minimum, both should complete without error)
        assert "production" in r1
        assert "production" in r2


# ═════════════════════════════════════════════
# FACTORY RUNNER — from_config
# ═════════════════════════════════════════════

class TestFromConfig:

    def test_missing_file_raises(self):
        with pytest.raises(FileNotFoundError):
            FactoryRunner.from_config("/nonexistent/path/config.yaml")

    def test_unsupported_extension_raises(self, tmp_path):
        cfg = tmp_path / "config.toml"
        cfg.write_text("factory_name = 'x'")
        with pytest.raises(ValueError, match="Unsupported config format"):
            FactoryRunner.from_config(str(cfg))

    def test_valid_yaml_loads(self, tmp_path, simple_bom, simple_inventory,
                               simple_machines, simple_stock_limits,
                               simple_reorder_delays):
        import yaml
        config = {
            "factory_name": "yaml_factory",
            "product_demand": {"o1": {"bike": 1}},
            "bom": simple_bom,
            "initial_inventory": simple_inventory,
            "machines": simple_machines,
            "stock_limits": simple_stock_limits,
            "reorder_delays": simple_reorder_delays,
            "months": 1,
            "hours_per_month": 160,
            "show_output": False,
            "show_debug": False,
            "export_reports": False,
            "output_dir": "/tmp/",
        }
        cfg_path = tmp_path / "config.yaml"
        cfg_path.write_text(yaml.dump(config))
        runner = FactoryRunner.from_config(str(cfg_path))
        assert isinstance(runner, FactoryRunner)

    def test_valid_json_loads(self, tmp_path, simple_bom, simple_inventory,
                               simple_machines, simple_stock_limits,
                               simple_reorder_delays):
        import json
        config = {
            "factory_name": "json_factory",
            "product_demand": {"o1": {"bike": 1}},
            "bom": simple_bom,
            "initial_inventory": simple_inventory,
            "machines": simple_machines,
            "stock_limits": simple_stock_limits,
            "reorder_delays": simple_reorder_delays,
            "months": 1,
            "hours_per_month": 160,
            "show_output": False,
            "show_debug": False,
            "export_reports": False,
            "output_dir": "/tmp/",
        }
        cfg_path = tmp_path / "config.json"
        cfg_path.write_text(json.dumps(config))
        runner = FactoryRunner.from_config(str(cfg_path))
        assert isinstance(runner, FactoryRunner)


# ═════════════════════════════════════════════
# INVENTORY STRATEGY TESTS
# ═════════════════════════════════════════════

class TestInventoryStrategy:

    def _run_with_strategy(self, strategy, simple_bom, simple_machines,
                            simple_stock_limits, simple_reorder_delays):
        inv = {"bike": 0, "wheel": 0, "frame": 0, "rim": 0, "tire": 0, "tube": 0}
        return make_runner(
            simple_bom, inv, simple_machines,
            simple_stock_limits, simple_reorder_delays,
            inventory_strategy=strategy,
        ).run()

    def test_strategy_max(self, simple_bom, simple_machines,
                           simple_stock_limits, simple_reorder_delays):
        result = self._run_with_strategy(
            "max", simple_bom, simple_machines, simple_stock_limits, simple_reorder_delays
        )
        assert "production" in result

    def test_strategy_min(self, simple_bom, simple_machines,
                           simple_stock_limits, simple_reorder_delays):
        result = self._run_with_strategy(
            "min", simple_bom, simple_machines, simple_stock_limits, simple_reorder_delays
        )
        assert "production" in result

    def test_strategy_random(self, simple_bom, simple_machines,
                              simple_stock_limits, simple_reorder_delays):
        result = self._run_with_strategy(
            "random", simple_bom, simple_machines, simple_stock_limits, simple_reorder_delays
        )
        assert "production" in result

    def test_unknown_strategy_defaults_to_zero(
        self, simple_bom, simple_machines, simple_stock_limits, simple_reorder_delays
    ):
        """Unknown strategy should default to 0 (no crash)."""
        result = self._run_with_strategy(
            "nonexistent", simple_bom, simple_machines,
            simple_stock_limits, simple_reorder_delays
        )
        assert "production" in result