import unittest

from mlafactory.FactoryRunner import FactoryRunner
from tests.unit_test_factory.one_prod_one_machine import (
    machines,
    initial_inventory,
    bom,
    orders_demand,
    stocks_limits,
    raw_components,
)


class MLATest(unittest.TestCase):
    def test_integration_format(self):
        simulator = FactoryRunner(
            months=1,
            hours_per_month=160,
            product_demand=orders_demand,
            bom=bom,
            initial_inventory=initial_inventory,
            machines=machines,
            stock_limits=stocks_limits,
            reorder_delays=raw_components,
            factory_name="bike",
            show_output=False,
            export_reports=False,
            output_dir="/tmp/",
        )
        result_dict = simulator.run()
        # one is bike, the other "total".
        self.assertTrue(len(result_dict['production']) == 2)
        expected_keys = {
            "demand",
            "fulfilled",
            "fulfillment_ratio",
            "inventory",
            "product",
            "production",
            "production_ratio",
        }
        for k in expected_keys:
            for res in result_dict['production']:
                self.assertTrue(k in res)
        self.assertTrue("production" in result_dict)
        self.assertTrue("machines" in result_dict)
        self.assertTrue("inventory" in result_dict)

    def test_integration_service_level_1(self):
        simulator = FactoryRunner(
            months=1,
            hours_per_month=160,
            product_demand=orders_demand,
            bom=bom,
            initial_inventory=initial_inventory,
            machines=machines,
            stock_limits=stocks_limits,
            reorder_delays=raw_components,
            factory_name="bike",
            show_output=False,
            export_reports=False,
            output_dir="/tmp/",
        )
        result_dict = simulator.run()
        expected_bike = {
            "demand": 50,
            "fulfilled": 50,
            "fulfillment_ratio": 1.0,
            "inventory": 10,
            "product": "Bike",
            "production": 60,
            "production_ratio": 1.2,
        }
        expected_total = {
            "demand": 50,
            "fulfilled": 50,
            "fulfillment_ratio": 1.0,
            "inventory": 10,
            "product": "TOTAL",
            "production": 60,
            "production_ratio": 1.2,
        }
        self.assertTrue(result_dict['production'][0] == expected_bike)
        self.assertTrue(result_dict['production'][1] == expected_total)

    def test_integration_service_level_0(self):
        N = 1_000_000
        orders_demand = {"00001": {"Bike": N}}
        simulator = FactoryRunner(
            months=1,
            hours_per_month=160,
            product_demand=orders_demand,
            bom=bom,
            initial_inventory=initial_inventory,
            machines=machines,
            stock_limits=stocks_limits,
            reorder_delays=raw_components,
            factory_name="bike",
            show_output=False,
            export_reports=False,
            output_dir="/tmp/",
        )
        result_dict = simulator.run()

        self.assertTrue(result_dict['production'][0]["fulfillment_ratio"] < 0.01)
        self.assertTrue(
            result_dict['production'][1]["fulfillment_ratio"]
            == result_dict['production'][0]["fulfillment_ratio"]
        )


if __name__ == "__main__":
    unittest.main()
