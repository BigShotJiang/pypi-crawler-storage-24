import random
from typing import List, Union

import numpy as np


def generate_wait_intervals(
    n_orders: int,
    mode: str = "fixed",
    params: Union[dict, None] = None,
    simulation_time: Union[int, None] = None,
) -> List[int]:
    """
    Generate a list of wait intervals between order submissions.

    Args:
        n_orders (int): Number of total orders.
        mode (str): One of "fixed", "random", "spread", or "distribution".
        params (dict): Parameters for the mode:
          * fixed: {"interval": int}
          * random: {"min": int, "max": int}
          * distribution: {"dist": str, "params": dict}
        simulation_time (int): Total simulation time (required for 'spread').

    Returns:
        List[int]: List of wait intervals, starting with 0.
    """
    if n_orders < 1:
        return []

    if params is None:
        params = {}

    wait_intervals = [0]  # First order happens immediately

    if n_orders == 1:
        return wait_intervals

    if mode == "fixed":
        interval = params.get("interval", 1)
        wait_intervals += [interval] * (n_orders - 1)

    elif mode == "random":
        min_v = params.get("min", 1)
        max_v = params.get("max", 5)
        wait_intervals += [random.randint(min_v, max_v) for _ in range(n_orders - 1)]

    elif mode == "spread":
        if simulation_time is None:
            raise ValueError("simulation_time is required for 'spread' mode")
        spread_interval = (
            simulation_time // (n_orders - 1) if n_orders > 1 else simulation_time
        )
        wait_intervals += [spread_interval] * (n_orders - 1)

    elif mode == "distribution":
        dist = params.get("dist", "poisson")
        dparams = params.get("params", {"lam": 3})
        for _ in range(n_orders - 1):
            if dist == "poisson":
                wait_intervals.append(np.random.poisson(dparams.get("lam", 3)))
            elif dist == "normal":
                val = max(
                    0,
                    int(
                        np.random.normal(dparams.get("mean", 5), dparams.get("std", 2))
                    ),
                )
                wait_intervals.append(val)
            else:
                raise ValueError(f"Unsupported distribution: {dist}")
    else:
        raise ValueError(f"Unknown mode: {mode}")

    return wait_intervals
