import argparse
import os
from importlib.resources import files


def check_path_exists(path: str) -> None:
    """Check if path exists"""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Path not found: {path}")


def check_file_exists(file_path: str) -> None:
    """Check if file exists"""
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"File not found or not a regular file: {file_path}")


# Get absolute path to the package (e.g., mlafactory)
data_file_path = files("mlafactory")
absolute_path = str(data_file_path)


def get_args():
    """
    Defines and parses command-line arguments for the mlafactory Simulation.

    Returns:
        argparse.Namespace: Parsed command-line arguments.
    """
    parser = argparse.ArgumentParser(
        description="Run the mlafactory Simulation. Simulates production "
        "workflows, inventory management, and order fulfillment "
        "in a manufacturing environment."
    )

    # ========================================================================
    # Factory Configuration
    # ========================================================================
    config_group = parser.add_argument_group("Factory Configuration")
    config_group.add_argument(
        "--factory-config",
        type=str,
        help="Path to a YAML/JSON file containing complete factory "
        "configuration (overrides individual file arguments if provided).",
    )
    config_group.add_argument(
        "--factory-name",
        type=str,
        default="Generic",
        help="Name of the factory for simulation identification. Default: 'Generic'.",
    )

    # ========================================================================
    # Input Files
    # ========================================================================
    input_group = parser.add_argument_group("Input Files")
    input_group.add_argument(
        "--input-folder",
        type=str,
        default=f"{absolute_path}/minimal_example/",
        help="Directory containing all input files. Default: bundled minimal example.",
    )

    file_args = parser.add_argument_group("Individual File Overrides")
    file_args.add_argument(
        "--bom-file",
        type=str,
        default="bom.json",
        help="Bill of Materials (JSON). Defines product components and quantities.",
    )
    file_args.add_argument(
        "--inventory-file",
        type=str,
        default="initial_inventory.json",
        help="Initial inventory levels (JSON).",
    )
    file_args.add_argument(
        "--reorder-file",
        type=str,
        default="reorder_delays.json",
        help="Supplier lead times for each component (JSON).",
    )
    file_args.add_argument(
        "--orders-file",
        type=str,
        default="orders_demand.json",
        help="Customer demand schedule (JSON).",
    )
    file_args.add_argument(
        "--machines-file",
        type=str,
        default="machines.json",
        help="Production machine specifications (JSON).",
    )
    file_args.add_argument(
        "--stock-file",
        type=str,
        default="stock_limits.json",
        help="Maximum inventory capacities (JSON).",
    )

    # ========================================================================
    # Simulation Parameters
    # ========================================================================
    sim_group = parser.add_argument_group("Simulation Parameters")
    sim_group.add_argument(
        "--months",
        type=int,
        default=12,
        help="Total simulation duration in months. Default: 12.",
    )
    sim_group.add_argument(
        "--hours-per-month",
        type=int,
        default=160,
        help="Working hours per month (8h/day * 20 days). Default: 160.",
    )

    # ========================================================================
    # Inventory Strategy
    # ========================================================================
    inventory_group = parser.add_argument_group("Inventory Strategy")
    inventory_group.add_argument(
        "--inventory-strategy",
        type=str,
        choices=["zero", "min", "max", "random"],
        default="max",
        help="Initial inventory population strategy: "
        "'zero'=empty, 'min'=safety stock, 'max'=full capacity, "
        "'random'=randomized. Default: 'max'.",
    )
    inventory_group.add_argument(
        "--inventory-seed",
        type=int,
        default=42,
        help="Random seed for 'random' inventory strategy. Default: 42.",
    )

    # ========================================================================
    # Order Scheduling
    # ========================================================================
    order_group = parser.add_argument_group("Order Scheduling")

    order_group.add_argument(
        "--order-mode",
        type=str,
        choices=["fixed", "random", "spread", "distribution"],
        default="fixed",
        help="Strategy for spacing out orders. "
        "Options: fixed, random, spread, distribution.",
    )

    order_group.add_argument(
        "--fixed-interval",
        type=int,
        default=3,
        help="Fixed hours between orders (use with --order-mode=fixed). Default: 3.",
    )
    order_group.add_argument(
        "--random-range",
        type=int,
        nargs=2,
        metavar=("MIN", "MAX"),
        default=[1, 5],
        help="Min/max hours for random intervals (use with "
        "--order-mode=random). Default: 1 5.",
    )
    order_group.add_argument(
        "--dist-type",
        type=str,
        choices=["poisson", "normal"],
        default="poisson",
        help="Used in 'distribution' mode. Options: poisson, normal.",
    )
    order_group.add_argument(
        "--poisson-lambda",
        type=float,
        default=3.0,
        help="Lambda for Poisson-distributed intervals. Default: 3.0.",
    )
    order_group.add_argument(
        "--normal-dist",
        type=float,
        nargs=2,
        metavar=("MEAN", "STDDEV"),
        default=[5.0, 2.0],
        help="Mean/stddev for Normal-distributed intervals. Default: 5.0 2.0.",
    )

    # ========================================================================
    # Output Options
    # ========================================================================
    output_group = parser.add_argument_group("Output Options")
    output_group.add_argument(
        "--output-dir",
        type=str,
        default="output/",
        help="Directory for report files. Default: './output/'.",
    )
    output_group.add_argument(
        "--debug", action="store_true", help="Enable detailed debug logging."
    )
    output_group.add_argument("--show-output", action="store_true", help="Show output.")
    output_group.add_argument(
        "--export-reports", action="store_true", help="Generate CSV/XLSX reports."
    )

    args = parser.parse_args()

    if args.order_mode == "distribution" and not args.dist_type:
        parser.error("--dist-type is required when --order-mode=distribution")

    if args.factory_config:
        check_file_exists(args.factory_config)
    else:
        check_path_exists(args.input_folder)  # check the folder itself exists too
        base_path = args.input_folder
        required_files = [
            args.bom_file,
            args.inventory_file,
            args.reorder_file,
            args.orders_file,
            args.machines_file,
            args.stock_file,
        ]
        for fname in required_files:
            check_file_exists(os.path.join(base_path, fname))

    return args
