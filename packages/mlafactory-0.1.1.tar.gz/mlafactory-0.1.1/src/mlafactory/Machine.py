"""
This module defines the Machine Production Simulation.
"""

import logging
from typing import Any
import simpy


class Machine:
    """
    Simulates a factory machine using SimPy.

    Each machine can process tasks to build components
    based on a Bill of Materials (BOM). The machine supports
    setup and production times, tracks statistics, and
    communicates completion back to a dispatcher.
    """

    def __init__(
        self,
        env: simpy.Environment,
        name: str,
        machine_type: str,
        setup_time: float,
        cycle_time: float,
        dispatcher: Any,
        setup_cost: float = 0.0,
        cycle_cost: float = 0.0,
    ):
        """
        Initialize a machine in the factory.

        Args:
            env (simpy.Environment): The SimPy simulation environment.
            name (str): Unique identifier for the machine.
            machine_type (str): Machine type used for task dispatching.
            setup_time (float): Time in minutes to switch setup (converted to
                hours).
            cycle_time (float): Time in minutes to produce one unit (converted
                to hours).
            dispatcher (Any): Dispatcher that manages machine assignment.
            setup_cost (float, optional): Cost per setup. Defaults to 0.0.
            cycle_cost (float, optional): Cost per minute of production.
                Defaults to 0.0.
        """
        self.env = env
        self.name = name
        self.machine_type = machine_type
        # Convert to simulation time units in minutes to (hours)
        self.setup_time = setup_time / 60
        self.cycle_time = cycle_time / 60

        # Dispatcher will assign this machine to tasks
        self.dispatcher = dispatcher

        self.idle = simpy.Store(env)
        self.env.process(self.run())

        # Optimization: avoid redundant setups by tracking last built component
        self.last_bom_key = None

        # Statistics
        self.n_setups = 0
        self.n_cycles = 0
        self.setup_events = []
        self.cycle_events = []

        self.setup_cost = setup_cost
        self.cycle_cost = cycle_cost

        self.current_task = ("idle", None, None)

        # Dictionary with duration per phase
        self.task_durations = {
            "setup": 0.0,
            "building": 0.0,
            "idle": 0.0,
        }

        self.last_start = self.env.now

    def _log(self, msg):
        """Log a message with the simulation timestamp if debug is enabled."""
        if logging.getLogger().isEnabledFor(logging.DEBUG):
            logging.debug("[%.2f] %s", self.env.now, msg)

    def run(self):
        """
        Main process that runs the machine.

        Waits for tasks, performs setup if needed, simulates production, and
        notifies dispatcher upon completion.
        """
        # TODO: Add try/except in case simulation ends abruptly (simpy.Interrupt)
        while True:
            task = yield self.idle.get()

            product = task["component"]
            building_id = task["id"]
            event = task["event"]
            qty = task["qty"]

            # Accumulate idle time
            self.task_durations["idle"] += self.env.now - self.last_start

            # Setup if switching products
            if self.last_bom_key != product:
                self.last_start = self.env.now
                self.last_bom_key = product

                self._log(
                    f"Machine {self.name} setup for {product} (task {building_id})"
                )

                self.n_setups += 1
                self.setup_events.append(self.env.now)
                self.current_task = ("setup", product, building_id)

                yield self.env.timeout(self.setup_time)
                self.task_durations["setup"] += self.env.now - self.last_start

            # Simulate production cycle
            self.last_start = self.env.now
            self._log(
                f"Machine {self.name} starts producing "
                f"{product} ({qty}) (task {building_id})"
            )

            self.current_task = ("building", product, building_id)
            yield self.env.timeout(self.cycle_time * qty)
            self.task_durations["building"] += self.env.now - self.last_start

            # Log completion
            self._log(
                f"Machine {self.name} finished {product} ({qty}) (task{building_id})"
            )

            # Signal task completion
            event.succeed((product, building_id))
            self.n_cycles += qty
            self.cycle_events.append(self.env.now)

            # Mark machine as available
            self.dispatcher.machine_ready(self)

            # Prepare for next idle period
            self.last_start = self.env.now
            self.current_task = ("idle", None, None)
