"""
This module defines the MachineDispatcher, responsible for managing a pool
of machines and dispatching tasks based on inventory readiness and machine
availability.
"""

import logging
from collections import defaultdict
from typing import Dict, List, Any

import simpy


class MachineDispatcher:
    """
    Manages a pool of machines and assigns tasks based on machine availability,
    machine type, and inventory readiness.
    """

    def __init__(self, env: simpy.Environment, machines: list, factory):
        """
        Initialize the MachineDispatcher.

        Args:
            env (simpy.Environment): The simulation environment.
            machines (List[Any]): A list of Machine objects to be managed.
            factory (Any): The factory reference with access to inventory.
        """

        self.env = env
        self.factory = factory

        self.machine_queues = defaultdict(list)
        self.waiting_tasks = defaultdict(list)

        for machine in machines:
            self.machine_queues[machine.machine_type].append(machine)

    def _log(self, msg):
        """Log a message with the simulation timestamp if debug is enabled."""
        if logging.getLogger().isEnabledFor(logging.DEBUG):
            logging.debug("[%.2f] %s", self.env.now, msg)

    def submit_task(self, task_list: List[Dict[str, Any]]) -> simpy.events.Event:
        """
        Submit a list of tasks (same type/BOM) to be scheduled and executed.

        Args:
            task_list (List[Dict[str, Any]]): A list of identical tasks to be
                processed in batch.

        Returns:
            simpy.Event: Event that will succeed when all tasks in the list
                are completed.
        """
        evt = self.env.event()
        self.env.process(self._handle_task_list(task_list, evt))
        return evt

    def request_inventory_batch(self, task: Dict, max_sets: int):
        """
        Attempt to reserve inventory for a batch of tasks. If no full set is
        available, wait for the minimum set to be restocked.

        Args:
            task (dict): A representative task with a 'details.bom' field.
            max_sets (int): Maximum number of BOM sets to attempt to reserve.

        Returns:
            int: Number of complete BOM sets successfully reserved.
        """
        bom = task["details"]["bom"]
        bom_items = list(bom.items())
        available_sets = max_sets

        # Determine how many full BOM sets we can reserve
        for item, details in bom_items:
            possible_sets = self.factory.inventory.stock.get(item, 0) // details["qty"]
            if possible_sets < available_sets:
                available_sets = possible_sets
                if available_sets == 0:  # Early exit
                    break

        available_sets = int(available_sets)

        if available_sets == 0:
            events = []
            for i, (item, details) in enumerate(bom_items):
                evt = self.factory.inventory.get(item, details["qty"])
                if evt is not None:
                    evt.metadata = {
                        "id": task["id"],
                        "item": item,
                        "qty": details["qty"],
                    }
                    events.append(evt)

            if events:
                yield simpy.AllOf(self.env, events)
            return 1

        # Reserve inventory
        for item, details in bom_items:
            self.factory.inventory.get(item, details["qty"] * available_sets)

        return available_sets

    def _handle_task_list(self, task_list: List[dict], evt: simpy.Event):
        """
        Internal process that handles a batch of identical tasks.

        Args:
            task_list (List[dict]): List of task dicts to be processed.
            evt (simpy.Event): Event to succeed once all tasks are completed.
        """

        def _on_task_complete(event):
            self.factory.inventory.put(event.metadata["item"], event.metadata["qty"])

        assert len(task_list) > 0, "Task list should not be empty"

        task = task_list[0]
        max_sets = len(task_list)
        total_tasks = len(task_list)
        task_idx = 0

        pending_events = []

        while task_idx < total_tasks:
            # Wait and reserve inventory for N sets
            actual_sets = yield self.env.process(
                self.request_inventory_batch(task, max_sets)
            )
            max_sets = max_sets - actual_sets

            sub_evt = self.env.event()
            curr_task = task_list[task_idx]
            sub_evt.metadata = {
                "id": curr_task["id"],
                "item": curr_task["component"],
                "qty": actual_sets,
            }
            curr_task["event"] = sub_evt
            curr_task["qty"] = actual_sets
            self._handle_task(curr_task)
            sub_evt.callbacks.append(_on_task_complete)
            pending_events.append(sub_evt)
            task_idx += actual_sets

        yield simpy.AllOf(self.env, pending_events)
        evt.succeed()

    def _handle_task(self, task: dict):
        """
        Dispatch a task to an idle machine if available; otherwise queue it.

        Args:
            task (dict): Task to be assigned to a machine.
        """
        mtype = task["details"]["type"]
        machine_queue = self.machine_queues[mtype]
        if machine_queue:
            machine = machine_queue.pop(0)
            machine.idle.put(task)
        else:
            self.waiting_tasks[mtype].append(task)

    def machine_ready(self, machine) -> None:
        """
        Notify the dispatcher that a machine is now idle and ready
        for new tasks.

        Args:
            machine (Any): The machine that has become idle.
        """
        mtype = machine.machine_type
        task_queue = self.waiting_tasks[mtype]
        if task_queue:
            task = task_queue.pop(0)
            machine.idle.put(task)
        else:
            self.machine_queues[mtype].append(machine)
