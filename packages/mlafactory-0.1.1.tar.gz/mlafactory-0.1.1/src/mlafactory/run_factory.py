from mlafactory.aux_arguments import get_args
from mlafactory.aux_files import load_json_inputs
from mlafactory.FactoryRunner import FactoryRunner


def main():
    args = get_args()

    if args.factory_config:
        # Load the simulator directly from the configuration file
        simulator = FactoryRunner.from_config(args.factory_config)
        simulator.run()
    else:
        # Load all inputs
        inputs = load_json_inputs(args.input_folder, args)

        params = {
            "interval": args.fixed_interval,
            "random_range": args.random_range,
            "dist_type": args.dist_type,
            "poisson_lambda": args.poisson_lambda,
            "normal_dist": args.normal_dist,
        }

        simulator = FactoryRunner(
            factory_name=args.factory_name,
            bom=inputs["bom"],
            initial_inventory=inputs["initial_inventory"],
            reorder_delays=inputs["reorder_delays"],
            product_demand=inputs["product_demand"],
            machines=inputs["machines"],
            stock_limits=inputs["stock_limits"],
            months=args.months,
            hours_per_month=args.hours_per_month,
            inventory_strategy=args.inventory_strategy,
            inventory_seed=args.inventory_seed,
            order_mode=args.order_mode,
            order_mode_params=params,
            output_dir=args.output_dir,
            show_debug=args.debug,
            show_output=args.show_output,
            export_reports=args.export_reports,
        )
        simulator.run()


if __name__ == "__main__":
    main()
