import logging
from collections import defaultdict
from typing import Callable, Dict, Optional

import simpy


class Inventory:
    """
    Inventory management for a simulation environment.

    Supports asynchronous `get` requests (with waiting) and `put` updates,
    tracks consumption and additions, and triggers min/max policy updates.
    """

    def __init__(
        self,
        env: simpy.Environment,
        initial_stock: Dict[str, float],
        minmax_callback: Callable[[str], None],
    ) -> None:
        """
        Initialize the inventory system.

        Args:
            env: SimPy environment.
            initial_stock: Dictionary with initial stock levels per item.
            minmax_callback: Function to call when stock levels change.
        """
        self.env = env
        self.minmax_callback = minmax_callback
        # Simple counter
        self.stock = defaultdict(float, initial_stock)
        self.consumed = []
        self.added = defaultdict(float)
        self._waiting = defaultdict(list)  # item → list of (qty, callback)

    def _log(self, msg: str) -> None:
        """
        Log a debug message with the current simulation time.

        Args:
            msg: The message to log.
        """
        if logging.getLogger().isEnabledFor(logging.DEBUG):
            logging.debug("[%.2f] %s", self.env.now, msg)

    def get(self, item: str, qty: float) -> Optional[simpy.Event]:
        """
        Request to consume a quantity of an item from inventory.

        If available, immediately deducts from stock.
        Otherwise, registers an event that will be triggered when
            stock is sufficient.

        Args:
            item: The item to consume.
            qty: The quantity to consume.

        Returns:
            None if fulfilled immediately, or a SimPy event if waiting
                is required.
        """
        # Fast path: immediately available
        if self.stock[item] >= qty:
            self.stock[item] -= qty
            self.consumed.append((self.env.now, item, qty))
            self.minmax_callback(item)
            event = self.env.event()
            event.succeed()  # already fulfilled
            return event

        # Async path: register callback
        event = self.env.event()
        self._waiting[item].append((qty, event))
        return event

    def put(self, item: str, qty: float):
        """
        Add a quantity of an item to inventory, and fulfill any pending gets.

        Args:
            item: The item to add.
            qty: The quantity to add.
        """
        self.stock[item] += qty
        self.added[item] += qty

        # Process waiting gets
        while self._waiting[item] and self.stock[item] >= self._waiting[item][0][0]:
            wait_qty, event = self._waiting[item].pop(0)
            if not event.triggered:
                self.stock[item] -= wait_qty
                self.consumed.append((self.env.now, item, wait_qty))
                event.succeed()
        self.minmax_callback(item)
