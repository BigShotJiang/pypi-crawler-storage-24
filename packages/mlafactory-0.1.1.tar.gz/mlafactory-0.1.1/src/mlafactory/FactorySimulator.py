"""
mlafactory Simulation

This module defines the `FactorySimulator` class, which simulates a factory
environment for producing a Component or final product.
It handles machine management, inventory control, and order processing using
the `simpy` simulation framework.

Author: oscar J. Castro-Lopez
Affiliation: University of Luxembourg
"""

import copy
import logging
import math

# from collections import deque
from typing import List, Dict, Union

import simpy
from mlafactory.aux_files import InputValidationError
from mlafactory.Inventory import Inventory
from mlafactory.Machine import Machine
from mlafactory.MachineDispatcher import MachineDispatcher


class FactorySimulator:
    """
    Simulates a factory system that handles inventory, production,
    and raw material reordering with support for dynamic product orders.
    """

    def __init__(
        self,
        env: simpy.Environment,
        factory_name: str,
        machines: List[Dict],
        inventory: Dict[str, float],
        reorder_delays: Dict[str, Dict[str, float]],
        bom: Dict[str, Dict],
        stock_limits: Dict[str, Dict[str, int]],
    ):
        """
        Initialize the FactorySimulator.

        Args:
            env: SimPy environment.
            factory_name: Name of the factory.
            machines: List of machine configuration dictionaries.
            inventory: Dictionary of initial inventory levels.
            reorder_delays: Delay times for reordering raw materials.
            bom: Bill of materials for building components.
            stock_limits: Min and max inventory levels for each item.
        """
        self.env = env
        self.factory_name = factory_name

        # setup machines
        self.machines = {}
        machine_instances = []
        for machine in machines:
            m = Machine(
                env,
                machine["name"],
                machine["type"],
                machine["setup_time"],
                machine["cycle_time"],
                None,
                machine.get("setup_cost", 0),
                machine.get("cycle_cost_per_minute", 0),
            )
            machine_instances.append(m)
            if m.machine_type not in self.machines:
                self.machines[m.machine_type] = {"machines": []}
            self.machines[m.machine_type]["machines"].append(m)

        # Dispatcher to assign work to machines
        self.machine_dispatcher = MachineDispatcher(env, machine_instances, self)
        for machine in machine_instances:
            machine.dispatcher = self.machine_dispatcher

        # Inventory tracking
        self.inventory = Inventory(env, inventory, self.maintain_stock_limits)
        self.initial_inventory = copy.deepcopy(inventory)

        self.is_working = {key: False for key in self.inventory.stock}
        self.stock_event = {key: 0 for key in self.inventory.stock}

        # BOM and stock policy
        self.reorder_delays = reorder_delays
        self.bom = bom
        self.stock_limits = stock_limits

        # Cached list of items to prepare stock for building
        self.item_list = {}

        # Orders and bookkeeping
        self.orders = []
        self.finished_orders = []
        self.consumed = []

        self.reorders_request = {key: 0 for key in self.reorder_delays.keys()}

        # Events to trigger decision logic
        self.new_order_event = env.event()
        self.new_inventory_event = env.event()

        # Optional monitoring
        if logging.getLogger().isEnabledFor(logging.DEBUG):
            self.env.process(self.monitor_state())
        # self.env.process(self.monitor_inventory(check_interval=50))

    def _log(self, msg: str) -> None:
        """Log a debug message with simulation time."""
        if logging.getLogger().isEnabledFor(logging.DEBUG):
            logging.debug("[%.2f] %s", self.env.now, msg)

    def monitor_state(self):
        """
        Monitor internal factory state periodically for debugging.
        """
        while True:
            self._log("Monitoring...")
            logging.debug(" Orders left: %s", len(self.orders))

            for k, q in self.machine_dispatcher.machine_queues.items():
                logging.debug("Machine Queue %s: %s %s", k, len(q), q)

            for k, q in self.machine_dispatcher.waiting_tasks.items():
                logging.debug(" Task Queue %s: %s %s", k, len(q), q)

            for machine_type, machine_list in self.machines.items():
                machine_msg = f"{machine_type} [ "
                for machine in machine_list["machines"]:
                    machine_msg += f"{machine.current_task}, "
                machine_msg += "]"
                logging.debug(machine_msg)

            stock_levels = {}
            for item, cont in self.inventory.stock.items():
                stock_levels[item] = cont
            logging.debug("  Inventory: %s", stock_levels)
            logging.debug("  Working: %s", self.is_working)
            logging.debug(
                "  Dispatcher Tasks: %s", self.machine_dispatcher.waiting_tasks
            )
            yield self.env.timeout(50)

    def initialize_factory(self):
        """
        Trigger building subcomponents and
        reorder raw materials if needed
        """
        for _, details in self.bom.items():
            for item in details.get("bom", {}).keys():
                self.maintain_stock_limits(item)

    def _is_order_valid(self, order_id: str, product: str, quantity: int) -> None:
        """
        Checks if an order is valid
        """
        # Check product is in BOM
        if product not in self.bom.keys():
            raise InputValidationError(f"{product} in order {order_id} not in BOM.")
        # Check quantity is not <= 0
        if quantity <= 0:
            raise InputValidationError(
                f"Order {order_id} of {product} has {quantity} <= 0."
            )
        # Check duplicated order IDs
        if any(o[0] == order_id for o in self.orders):
            raise InputValidationError(f"Duplicate order ID: {order_id}")

    def add_order(self, order_id: str, product: str, quantity: int) -> None:
        """
        Add a product order to the system.

        If quantity exceeds the product's max stock, split into suborders.
        """
        self._is_order_valid(order_id, product, quantity)
        max_stock = self.stock_limits[product]["max"]
        suborder_index = 1

        if quantity > max_stock:
            self._log(
                f"Order {order_id} exceeds max stock ({max_stock}). "
                "Splitting into suborders."
            )
            remaining = quantity
            while remaining > 0:
                sub_qty = min(remaining, max_stock)
                sub_id = f"{order_id}-{suborder_index:03d}"
                self._log(f"Sub-Order {sub_id} requesting {sub_qty} {product}(s)")
                self.env.process(self.order_dispatcher(sub_id, product, sub_qty))
                remaining -= sub_qty
                suborder_index += 1
        else:
            self._log(f"Order {order_id} requesting {quantity} {product}(s)")
            self.env.process(self.order_dispatcher(order_id, product, quantity))

    def order_dispatcher(self, order_id: str, product: str, quantity: int):
        """
        SimPy process to fulfill an order, triggering builds and consumption.
        """
        order = (order_id, product, quantity)
        self.orders.append(order)

        self.ensure_stock_for_order(order_id, product, quantity)

        result = self.inventory.get(product, quantity)
        if result is not None:
            yield result

        self._log(f"Fullfilled order {order_id} of {quantity} {product}(s)")
        self.orders.remove(order)  # remove from main order list
        self.finished_orders.append(order + (self.env.now,))
        self.maintain_stock_limits(product)

    def ensure_stock_for_order(
        self, order_id: str, product: str, quantity: int
    ) -> None:
        """
        Ensure that all required components are available for the given
        product.
        """
        stack = [(product, quantity)]
        while stack:
            curr_component, current_qty = stack.pop()
            curr_bom = self.bom.get(curr_component, {}).get("bom", None)
            if curr_bom is None:
                self.schedule_reorder(order_id, curr_component, current_qty)
            else:
                self.schedule_production(order_id, curr_component, current_qty)
                for sub_component, details in curr_bom.items():
                    stack.append((sub_component, details["qty"] * current_qty))

    def schedule_production(self, order_id: str, product: str, quantity: int) -> None:
        """Schedule a production task for a component."""
        current_qty = self.inventory.stock[product]
        # min_qty = self.stock_limits[product]["min"]
        max_qty = self.stock_limits[product]["max"]
        missing_qty = max_qty - current_qty
        if current_qty < quantity and missing_qty >= 1:
            self.env.process(self.request_build(product, missing_qty, order_id))

    def schedule_reorder(
        self,
        order_id: str,
        material: str,
        quantity: int,
    ) -> None:
        """Schedule a raw material reorder if needed."""
        current_qty = self.inventory.stock[material]
        max_qty = self.stock_limits[material]["max"]
        missing_qty = max_qty - current_qty
        if current_qty < quantity and missing_qty >= 1:
            self.env.process(self.request_reorder(material, missing_qty, order_id))

    def maintain_stock_limits(self, component: str) -> None:
        """Ensure the item's stock doesn't fall below the minimum."""
        if self.is_working[component]:
            return

        current_qty = self.inventory.stock[component]
        min_qty = self.stock_limits[component]["min"]
        max_qty = self.stock_limits[component]["max"]
        # check if orders pending:
        order_qty_needed = 0
        for order_id, product, quantity in self.orders:
            if product == component:
                order_qty_needed = quantity
                break

        if current_qty >= min_qty and current_qty > order_qty_needed:
            return
        missing_qty = max_qty - current_qty
        if missing_qty < 1:
            return
        is_raw = component in self.reorder_delays
        order_id = f"{component}_{self.stock_event[component]}"
        self.stock_event[component] += 1

        if is_raw:
            self.env.process(self.request_reorder(component, missing_qty, order_id))
        else:
            self.env.process(self.request_build(component, missing_qty, order_id))

    def request_build(
        self, product: str, qty: Union[int, float], order_id: Union[str, None]
    ):
        """
        Trigger a build process for a product using available machines.

        Args:
            product: Component to build.
            qty: Quantity to build.
            order_id: Optional order identifier.

        Yields:
            simpy.AllOf: Event that completes when all builds finish.
        """
        if self.is_working.get(product, False):
            return  # Already working, skip
        self.is_working[product] = True
        self._log(f"Request building {qty} {product}(s) for Order {order_id}")

        if isinstance(qty, float):
            qty = math.floor(qty)

        template = {"component": product, "details": self.bom[product]}
        task_list = [{"id": f"{order_id}_{i}", **template} for i in range(qty)]

        build_event = self.machine_dispatcher.submit_task(task_list)

        yield build_event
        self.is_working[product] = False
        self._log(
            f"Finished batch of {qty} {product}(s) "
            f"stock {self.inventory.stock[product]}"
        )
        # Trigger: Check if after building is lower than the min
        self.maintain_stock_limits(product)

    def request_reorder(
        self, material: str, qty: Union[int, float], order_id: Union[str, None]
    ):
        """
        Trigger a reorder of raw materials with delay simulation.

        Args:
            material: Raw material name.
            qty: Quantity to reorder.
            order_id: Order identifier (optional).
        """
        if self.is_working.get(material, False):
            return  # Already working, skip

        self.is_working[material] = True
        delay = self.reorder_delays[material]["reorder_delay"]
        self._log(f"Reordering {qty} {material}(s), ETA: {delay} for {order_id}")
        yield self.env.timeout(delay)
        self.inventory.put(material, qty)
        self._log(
            f"Restocked {material} ({qty}) for {order_id} - "
            f"Current Stock: {self.inventory.stock[material]}"
        )
        self.is_working[material] = False
        self.reorders_request[material] += 1
        self.maintain_stock_limits(material)
