import datetime
from collections import defaultdict
from pathlib import Path

import pandas as pd


def get_machines_summary(factory):
    """Get summary information from the machines."""
    machines_summary = []
    for machine_type, machine_dict in factory.machines.items():
        for machine in machine_dict["machines"]:
            machines_summary.append(
                {
                    "type": machine_type,
                    "name": machine.name,
                    "setup_time": machine.setup_time * 60,
                    "cycle_time": machine.cycle_time * 60,
                    "n_setups": machine.n_setups,
                    "n_cycles": machine.n_cycles,
                    "setup_cost": machine.setup_cost * machine.n_setups,
                    "cycle_cost": machine.cycle_cost
                    * (machine.n_cycles * (machine.cycle_time * 60)),
                    "tt_setup": machine.task_durations["setup"],
                    "tt_build": machine.task_durations["building"],
                    "tt_idle": machine.task_durations["idle"],
                }
            )
    return machines_summary


def get_inventory_summary(factory):
    """Get summary information from inventory."""
    inventory_summary = {}
    for name, value in factory.initial_inventory.items():
        inventory_summary[name] = {"initial": value, "consumed": 0}
    for name, value in factory.inventory.stock.items():
        inventory_summary.setdefault(name, {"initial": 0, "consumed": 0})
        inventory_summary[name]["final"] = value
    for consumed_item in factory.inventory.consumed:
        (_, name, qty) = consumed_item
        inventory_summary[name]["consumed"] += qty

    for name, value in factory.reorders_request.items():
        inventory_summary[name]["n_reorders"] = value
    return inventory_summary


def get_production_results(factory, product_demand):
    """Calculates service levels based on demand vs. production."""
    demand_summary = defaultdict(int)
    fulfilled_summary = defaultdict(int)
    inventory_summary = defaultdict(int)
    production_summary = defaultdict(int)

    # Aggregate demand
    for sales_content in product_demand.values():
        for product_type, quantity in sales_content.items():
            demand_summary[product_type] += quantity

    # Aggregate production
    for product_type in demand_summary.keys():
        inventory_summary[product_type] = factory.inventory.stock.get(product_type, 0)
        production_summary[product_type] = factory.inventory.stock.get(product_type, 0)
        fulfilled_summary[product_type] = 0

    for _, product_type, quantity, _ in factory.finished_orders:
        fulfilled_summary[product_type] += quantity
        production_summary[product_type] += quantity

    # Compute service levels
    production_results = [
        {
            "product": product_type,
            "demand": demand_summary[product_type],
            "fulfilled": fulfilled_summary[product_type],
            "inventory": inventory_summary[product_type],
            "production": production_summary[product_type],
            "fulfillment_ratio": (
                fulfilled_summary[product_type] / demand_summary[product_type]
                if demand_summary[product_type]
                else 0
            ),
            "production_ratio": (
                production_summary[product_type] / demand_summary[product_type]
                if demand_summary[product_type]
                else 0
            ),
        }
        for product_type in demand_summary.keys()
    ]

    return production_results


def save_reports_to_folder(
    factory,
    factory_name: str,
    reports_folder: str,
    production_df: pd.DataFrame,
    machines_df: pd.DataFrame,
    inventory_df: pd.DataFrame,
):
    """Save all simulation reports to a timestamped folder."""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    folder_path = Path(f"{reports_folder}{factory_name}_{timestamp}")
    folder_path.mkdir(parents=True, exist_ok=True)

    pd.DataFrame(factory.orders, columns=["ID", "Item", "Quantity"]).to_csv(
        folder_path / "orders_queue.csv", index=False
    )
    pd.DataFrame(
        factory.finished_orders, columns=["ID", "Item", "Quantity", "Time"]
    ).to_csv(folder_path / "orders_completed.csv", index=False)
    inventory_df = inventory_df.sort_values(by=["item"])
    production_df.to_csv(folder_path / "production_summary.csv", index=False)
    machines_df.to_csv(folder_path / "machines_summary.csv", index=False)
    inventory_df.to_csv(folder_path / "inventory_summary.csv", index=False)


def collect_results(factory, product_demand):
    """Extract all key summaries from the simulation."""
    production_summary = get_production_results(factory, product_demand)
    machines_summary = get_machines_summary(factory)
    inventory_summary = get_inventory_summary(factory)

    # Add total summary row
    # total fulfillment_ratio
    total_demand = sum(row["demand"] for row in production_summary)
    total_fulfilled = sum(row["fulfilled"] for row in production_summary)
    t_f_r = total_fulfilled / total_demand if total_demand else 0

    # total production_ratio
    t_p_r = sum(row["production_ratio"] for row in production_summary) / len(
        production_summary
    )
    production_summary.append(
        {
            "product": "TOTAL",
            "demand": sum(row["demand"] for row in production_summary),
            "fulfilled": sum(row["fulfilled"] for row in production_summary),
            "inventory": sum(row["inventory"] for row in production_summary),
            "production": sum(row["production"] for row in production_summary),
            "fulfillment_ratio": t_f_r,
            "production_ratio": t_p_r,
        }
    )

    return (production_summary, machines_summary, inventory_summary)
