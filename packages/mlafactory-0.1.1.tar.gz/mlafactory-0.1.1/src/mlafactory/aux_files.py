import json
import logging
import os


class InputValidationError(Exception):
    """Custom exception for input validation errors."""

    pass


def load_json(filepath):
    """Load JSON data from a file, with error handling."""
    try:
        with open(filepath, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.error("File not found: %s", filepath)
        raise InputValidationError(f"File not found: {filepath}")
    except json.JSONDecodeError:
        logging.error("Invalid JSON format: %s", filepath)
        raise InputValidationError(f"Invalid JSON format: {filepath}")


def load_json_inputs(base_path, args):
    """Load all required JSON input files for the simulation."""
    try:
        return {
            "product_demand": load_json(os.path.join(base_path, args.orders_file)),
            "initial_inventory": load_json(
                os.path.join(base_path, args.inventory_file)
            ),
            "bom": load_json(os.path.join(base_path, args.bom_file)),
            "reorder_delays": load_json(os.path.join(base_path, args.reorder_file)),
            "machines": load_json(os.path.join(base_path, args.machines_file)),
            "stock_limits": load_json(os.path.join(base_path, args.stock_file)),
        }
    except InputValidationError:
        raise  # already logged inside load_json
    except Exception as e:
        logging.error("Unexpected error loading inputs: %s", e)
        raise
