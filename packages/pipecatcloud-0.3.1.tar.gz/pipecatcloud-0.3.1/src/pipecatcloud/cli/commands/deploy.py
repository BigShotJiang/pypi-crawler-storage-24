#
# Copyright (c) 2025, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

import asyncio
from pathlib import Path
from typing import Optional

import typer
from loguru import logger
from rich.console import Group
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from pipecatcloud._utils.async_utils import synchronizer
from pipecatcloud._utils.auth_utils import requires_login
from pipecatcloud._utils.build_utils import (
    BuildStatus,
    create_deterministic_tarball,
    format_size,
    get_exclusions,
    poll_build_status,
    upload_to_s3,
)
from pipecatcloud._utils.console_utils import console
from pipecatcloud._utils.deploy_utils import (
    BuildConfig,
    DeployConfigParams,
    KrispVivaConfig,
    ScalingParams,
    interpret_deployment_status,
    with_deploy_config,
)
from pipecatcloud._utils.regions import get_region_codes, validate_region
from pipecatcloud.cli import PIPECAT_CLI_NAME
from pipecatcloud.cli.api import API
from pipecatcloud.cli.config import config
from pipecatcloud.constants import KRISP_VIVA_MODELS, Region

MAX_ALIVE_CHECKS = 120
ALIVE_CHECK_SLEEP = 5

# ----- Cloud Build Flow


async def _cloud_build_flow(
    build_config: BuildConfig,
    region: Optional[str],
    org: str,
    auto_yes: bool,
) -> Optional[str]:
    """
    Execute the cloud build flow.

    Args:
        build_config: Build configuration (context_dir, dockerfile, excludes)
        region: Target region for the build
        org: Organization ID
        auto_yes: Skip prompts (for CI/CD)

    Returns:
        build_id on success, None on failure
    """
    # Resolve region - fetch org default if not explicitly specified
    if region:
        region_display = f"[green]{region}[/green]"
    else:
        props, error = await API.properties(org)
        if error:
            console.error("Failed to fetch organization properties")
            return None
        region = props["defaultRegion"]
        region_display = f"[green]{region}[/green] [dim](organization default)[/dim]"

    context_dir = Path(build_config.context_dir).resolve()
    dockerfile_path = context_dir / build_config.dockerfile

    # Check for Dockerfile
    if not dockerfile_path.exists():
        console.error(
            f"No Dockerfile found at [bold]{dockerfile_path}[/bold]\n\n"
            "A Dockerfile is required for cloud builds.\n\n"
            "See the quickstart project for a reference Dockerfile:\n"
            "  https://github.com/pipecat-ai/pipecat-quickstart"
        )
        return None

    # Show build summary and confirm in interactive mode
    if not auto_yes:
        console.print(
            Panel(
                f"[bold white]Organization:[/bold white] [green]{org}[/green]\n"
                f"[bold white]Region:[/bold white] {region_display}\n"
                f"[bold white]Dockerfile:[/bold white] [green]{build_config.dockerfile}[/green]\n"
                f"[bold white]Context:[/bold white] [green]{context_dir}[/green]",
                title="Cloud Build",
                title_align="left",
                border_style="cyan",
            )
        )
        if not typer.confirm("Proceed with cloud build?", default=True):
            console.cancel()
            return None

    # Create deterministic tarball
    console.print("[dim]Creating build context...[/dim]")
    try:
        exclusions = get_exclusions(context_dir, build_config.exclude_patterns)
        build_context = create_deterministic_tarball(
            context_dir=str(context_dir),
            exclusions=exclusions,
            dockerfile_path=build_config.dockerfile,
        )
    except FileNotFoundError as e:
        console.error(str(e))
        return None
    except ValueError as e:
        console.error(str(e))
        return None

    console.print(
        f"[dim]Build context: {build_context.file_count} files, "
        f"{format_size(len(build_context.tarball))} compressed, "
        f"hash={build_context.context_hash}[/dim]"
    )

    # Check cache
    console.print("[dim]Checking build cache...[/dim]")
    cached_builds, cache_error = await API.build_list(
        org=org,
        context_hash=build_context.context_hash,
        region=region,
        status=BuildStatus.SUCCESS,
        limit=1,
    )

    if cached_builds and cached_builds.get("builds"):
        cached_build = cached_builds["builds"][0]
        del build_context  # Free tarball memory, no upload needed
        console.success(
            f"[bold white]Build ID:[/bold white] {cached_build['id']}\n"
            f"[bold white]Created:[/bold white] {cached_build.get('createdAt', 'N/A')}\n\n"
            f"[dim]Using cached build - no upload needed[/dim]",
            title="Cached Build Found",
        )
        return cached_build["id"]

    console.print("[dim]No cached build found, starting new build...[/dim]")

    # Get upload URL
    with console.status("[dim]Requesting upload URL...[/dim]", spinner="dots"):
        upload_data, error = await API.build_upload_url(org=org, region=region)
        if error or not upload_data:
            console.error("Failed to get upload URL")
            return None

    # Upload context
    with console.status(
        f"[dim]Uploading build context ({format_size(len(build_context.tarball))})...[/dim]",
        spinner="dots",
    ):
        success = await upload_to_s3(
            tarball=build_context.tarball,
            upload_url=upload_data["uploadUrl"],
            upload_fields=upload_data["uploadFields"],
        )

    # Free tarball memory now that upload is done
    del build_context

    if not success:
        console.error("Failed to upload build context to cloud storage")
        return None

    console.print("[green]Upload complete[/green]")

    # Create build
    with console.status("[dim]Starting build...[/dim]", spinner="dots"):
        build_result, error = await API.build_create(
            org=org,
            upload_id=upload_data["uploadId"],
            region=region,
            dockerfile_path=build_config.dockerfile,
        )

    if error or not build_result:
        console.error("Failed to start build")
        return None

    build_data = build_result.get("build", build_result)
    build_id = build_data.get("id")

    # Check if this was a cache hit on the server side
    if build_result.get("cached"):
        console.success(
            f"[bold white]Build ID:[/bold white] {build_id}\n\n"
            f"[dim]Server found matching cached build[/dim]",
            title="Using Cached Build",
        )
        return build_id

    console.print(f"[cyan]Build started: {build_id}[/cyan]")

    # Poll for completion
    last_status = None

    def status_callback(build):
        nonlocal last_status
        status = build.get("status", "unknown")
        if status != last_status:
            last_status = status

    with console.status(
        "[dim]Building image (this may take a few minutes)...[/dim]", spinner="bouncingBar"
    ):
        success, final_build = await poll_build_status(
            build_id=build_id,
            org=org,
            api_client=API,
            poll_interval=5.0,
            max_duration=600.0,
            status_callback=status_callback,
        )

    if success:
        duration = final_build.get("buildDurationSeconds")
        duration_str = f" ({duration}s)" if duration else ""
        console.success(
            f"[bold white]Build ID:[/bold white] {build_id}\n"
            f"[bold white]Duration:[/bold white] {duration_str.strip('() s') if duration else 'N/A'}",
            title=f"Build Complete{duration_str}",
        )
        return build_id
    else:
        error_msg = final_build.get("errorMessage", final_build.get("error", "Unknown error"))
        console.error(
            f"Build failed: {error_msg}\n\n"
            f"[dim]View logs with:[/dim] [bold]{PIPECAT_CLI_NAME} build logs {build_id}[/bold]"
        )
        return None


# ----- Command


async def _deploy(params: DeployConfigParams, org, force: bool = False):
    existing_agent = False

    # Check for an existing deployment with this agent name
    with Live(
        console.status("[dim]Checking for existing agent deployment...[/dim]", spinner="dots"),
        transient=True,
    ) as live:
        data, error = await API.agent(agent_name=params.agent_name, org=org, live=live)

        if error:
            live.stop()
            return typer.Exit(1)

        if data:
            existing_agent = True

            if not force:
                live.stop()
                if not typer.confirm(
                    f"Deployment for agent '{params.agent_name}' exists. Do you want to update it? Note: this will not interrupt any active sessions",
                    default=True,
                ):
                    console.cancel()
                    return typer.Exit()

    # Start the deployment process
    with Live(
        console.status("[dim]Preparing deployment...", spinner="dots"), transient=True
    ) as live:
        """
        # 1. Check that provided secret set exists
        """
        if params.secret_set:
            live.update(
                console.status(f"[dim]Verifying secret set {params.secret_set} exists...[/dim]")
            )
            secrets_exist, error = await API.secrets_list(
                secret_set=params.secret_set, org=org, live=live
            )

            if error:
                return typer.Exit()

            if not secrets_exist:
                live.stop()
                console.error(
                    f"Secret set [bold]'{params.secret_set}'[/bold] not found in namespace [bold]'{org}'[/bold]"
                )
                return typer.Exit()

        """
        # 2. Check that provided image pull secret exists
        """
        if params.image_credentials:
            live.update(
                console.status(
                    f"[dim]Verifying image pull secret {params.image_credentials} exists...[/dim]"
                )
            )
            creds_exist, error = await API.bubble_error().secrets_list(
                secret_set=params.image_credentials, org=org, live=live
            )

            if error:
                if error.get("code") == "400":
                    creds_exist = True
                else:
                    API.print_error()
                    return typer.Exit()

            if not creds_exist:
                live.stop()
                console.error(
                    f"Image pull secret with name [bold]'{params.image_credentials}'[/bold] not found in namespace [bold]'{org}'[/bold]"
                )

        live.update(
            console.status(
                f"[dim]{'Updating' if existing_agent else 'Pushing'} agent manifest for[/dim] [cyan]'{params.agent_name}'[/cyan]"
            )
        )

        result, error = await API.deploy(
            deploy_config=params, update=existing_agent, org=org, live=live
        )

        if error:
            return typer.Exit()

        if not existing_agent and not result:
            live.stop()
            console.error("A problem occured during deployment. Please contact support.")
            return typer.Exit()

        # Close the live display before starting the new polling phase
        live.stop()

    """
    # 3. Poll status until healthy
    """
    active_deployment_id = None
    is_ready = False
    last_status = None
    checks_performed = 0

    console.print(
        f"[bold cyan]{'Updating' if existing_agent else 'Pushing'}[/bold cyan] deployment for agent '{params.agent_name}'"
    )

    # Create a simple spinner for the polling phase
    deployment_status_message = "[dim]Waiting for deployment to become ready...[/dim]"
    with console.status(deployment_status_message, spinner="bouncingBar") as status:
        try:
            while checks_performed < MAX_ALIVE_CHECKS:
                logger.debug("Polling for deployment status")

                # Get deployment status
                agent_status, error = await API.agent(
                    agent_name=params.agent_name, org=org, live=None
                )

                logger.debug(f"Deployment status: {agent_status}")

                # Look for any error messages in the agent status
                # Exit out of the polling loop if we find an error
                status_errors = agent_status.get("errors", [])
                if status_errors and len(status_errors) > 0:
                    status.stop()
                    # Pluck the first error message
                    error_message = status_errors[0]
                    if "code" in error_message and "message" in error_message:
                        console.api_error(error_message, "Agent deployment failed")
                    else:
                        console.error(f"Deployment failed with an unknown error: {status_errors}")
                    return typer.Exit()

                if error:
                    status.stop()
                    console.error("Error checking deployment status")
                    return typer.Exit()

                # Capture the deployment ID for display
                desired_deployment_id = agent_status.get(
                    "desiredDeploymentId", agent_status.get("activeDeploymentId")
                )
                if desired_deployment_id and not active_deployment_id:
                    active_deployment_id = desired_deployment_id

                # Interpret status using conditions, availability, and revision info
                last_status = interpret_deployment_status(
                    agent_status, desired_deployment_id=desired_deployment_id
                )

                logger.debug(
                    f"Interpreted phase: {last_status.phase}, available: {last_status.is_available}"
                )

                if last_status.is_ready:
                    is_ready = True
                    break

                # Update spinner with current status message
                status.update(last_status.status_message)

                # Wait before checking again
                await asyncio.sleep(ALIVE_CHECK_SLEEP)
                checks_performed += 1

        except KeyboardInterrupt:
            status.stop()
            console.print(
                "\n[yellow]Deployment monitoring interrupted. The deployment may still be in progress.[/yellow]"
            )
            return typer.Exit()

    if is_ready:
        public_api_key = config.get("default_public_key")
        extra_message = ""
        if not public_api_key:
            extra_message = "\n\n[yellow]Note: if you have not already created a public API key (required to start a session), you can do so by running:\n[/yellow]"
            extra_message += (
                f"[bold yellow]`{PIPECAT_CLI_NAME} organizations keys create`[/bold yellow]"
            )

        console.success(
            f"Agent deployment [bold]'{params.agent_name}'[/bold] is ready\n\n"
            f"[white]Start a session with your new agent by running:\n[/white]"
            f"[bold]`{PIPECAT_CLI_NAME} agent start {params.agent_name}`[/bold]"
            f"{extra_message}",
            title_extra=f"{'Update' if existing_agent else 'Deployment'} complete",
        )
    elif last_status and last_status.is_available:
        # Timed out but service is available — soft warning, not a hard error
        timeout_seconds = MAX_ALIVE_CHECKS * ALIVE_CHECK_SLEEP
        console.print(
            Panel(
                f"Service is available and serving traffic, but the new deployment hasn't fully rolled out after {timeout_seconds}s.\n"
                f"This is normal for deployments with large images or high replica counts.\n\n"
                f"[bold]Check status:[/bold]  `{PIPECAT_CLI_NAME} agent status {params.agent_name}`\n"
                f"[bold]View logs:[/bold]    `{PIPECAT_CLI_NAME} agent logs {params.agent_name}`",
                title="Deployment still in progress",
                title_align="left",
                border_style="yellow",
            )
        )
    elif last_status and last_status.degraded_reason:
        # Timed out with degraded status
        console.print(
            Panel(
                f"Deployment is degraded: {last_status.degraded_reason}\n\n"
                f"[bold]Check status:[/bold]  `{PIPECAT_CLI_NAME} agent status {params.agent_name}`\n"
                f"[bold]View logs:[/bold]    `{PIPECAT_CLI_NAME} agent logs {params.agent_name}`",
                title="Deployment degraded",
                title_align="left",
                border_style="red",
            )
        )
    else:
        timeout_seconds = MAX_ALIVE_CHECKS * ALIVE_CHECK_SLEEP
        console.error(
            f"Deployment did not become available within {timeout_seconds} seconds.\n"
            f"Please check logs with `{PIPECAT_CLI_NAME} agent logs {params.agent_name}`"
        )

    return typer.Exit()


def create_deploy_command(app: typer.Typer):
    @app.command(name="deploy", help="Deploy agent to Pipecat Cloud")
    @synchronizer.create_blocking
    @requires_login
    @with_deploy_config
    async def deploy(
        deploy_config=typer.Option(None, hidden=True),
        agent_name: str = typer.Argument(
            None, help="Name of the agent to deploy e.g. 'my-agent'", show_default=False
        ),
        image: str = typer.Argument(
            None, help="Docker image location e.g. 'my-image:latest'", show_default=False
        ),
        credentials: str = typer.Option(
            None,
            "--credentials",
            "-c",
            help="Image pull secret to use for deployment",
            rich_help_panel="Deployment Configuration",
            show_default=False,
        ),
        min_agents: int = typer.Option(
            None,
            "--min-agents",
            "-min",
            help="Minimum number of agents to keep warm",
            rich_help_panel="Deployment Configuration",
            min=0,
        ),
        max_agents: int = typer.Option(
            None,
            "--max-agents",
            "-max",
            help="Maximum number of allowed agents",
            rich_help_panel="Deployment Configuration",
            min=1,
            max=50,
        ),
        secret_set: str = typer.Option(
            None,
            "--secrets",
            "-s",
            help="Secret set to use for deployment",
            rich_help_panel="Deployment Configuration",
        ),
        organization: str = typer.Option(
            None,
            "--organization",
            "-o",
            help="Organization to deploy to",
            rich_help_panel="Deployment Configuration",
        ),
        krisp: bool = typer.Option(
            False,
            "--enable-krisp",
            "-krisp",
            help="[DEPRECATED] Enable Krisp integration for this deployment. Use --krisp-viva-audio-filter instead",
            rich_help_panel="Deployment Configuration",
        ),
        managed_keys: bool = typer.Option(
            False,
            "--enable-managed-keys",
            help="Enable Managed Keys for this deployment",
            rich_help_panel="Deployment Configuration",
        ),
        krisp_viva_audio_filter: str = typer.Option(
            None,
            "--krisp-viva-audio-filter",
            help=f"Enable Krisp VIVA with audio filter model ({' or '.join(KRISP_VIVA_MODELS)})",
            rich_help_panel="Deployment Configuration",
        ),
        profile: str = typer.Option(
            None,
            "--profile",
            "-p",
            help="Agent profile to use for deployment",
            rich_help_panel="Deployment Configuration",
        ),
        region: Optional[Region] = typer.Option(
            None,
            "--region",
            "-r",
            help="Region for service deployment",
            rich_help_panel="Deployment Configuration",
        ),
        skip_confirm: bool = typer.Option(
            False,
            "--force",
            "-f",
            help="Force deployment / skip confirmation",
            rich_help_panel="Additional Options",
        ),
        yes: bool = typer.Option(
            False,
            "--yes",
            "-y",
            help="Automatic yes to all prompts (for CI/CD automation)",
            rich_help_panel="Additional Options",
        ),
        no_credentials: bool = typer.Option(
            False,
            "--no-credentials",
            "-nc",
            help="Deployment will not require an image pull secret",
            rich_help_panel="Additional Options",
        ),
        build_dir: str = typer.Option(
            None,
            "--build-dir",
            "-d",
            help="Build context directory (for cloud builds)",
            rich_help_panel="Cloud Build Options",
        ),
        dockerfile: str = typer.Option(
            None,
            "--dockerfile",
            help="Path to Dockerfile (for cloud builds)",
            rich_help_panel="Cloud Build Options",
        ),
        build_id: str = typer.Option(
            None,
            "--build-id",
            "-b",
            help="Use an existing cloud build ID",
            rich_help_panel="Cloud Build Options",
        ),
        # @deprecated
        min_instances: int = typer.Option(
            None,
            "--min-instances",
            help="[Deprecated] Use --min-agents instead",
            hidden=True,
            min=0,
        ),
        # @deprecated
        max_instances: int = typer.Option(
            None,
            "--max-instances",
            help="[Deprecated] Use --max-agents instead",
            hidden=True,
            min=1,
            max=50,
        ),
    ):
        # Handle @deprecated options
        if min_instances is not None:
            logger.warning("min_instances is deprecated, use min_agents instead")
            min_agents = min_instances

        if max_instances is not None:
            logger.warning("max_instances is deprecated, use max_agents instead")
            max_agents = max_instances

        if krisp:
            logger.warning(
                "--enable-krisp is deprecated, use --krisp-viva-audio-filter instead for the latest Krisp VIVA models."
            )

        org = organization or config.get("org")

        # Combine automation flags
        auto_yes = yes or skip_confirm

        # Compose deployment config from CLI options and config file (if provided)
        # Order of precedence:
        #   1. Arguments provided to the CLI deploy command
        #   2. Values from the config toml file
        #   3. CLI command defaults

        partial_config = deploy_config or DeployConfigParams()

        # Override any local config values from passed CLI arguments
        partial_config.agent_name = agent_name or partial_config.agent_name
        partial_config.image = image or partial_config.image
        partial_config.image_credentials = credentials or partial_config.image_credentials
        partial_config.secret_set = secret_set or partial_config.secret_set
        partial_config.scaling = ScalingParams(
            min_agents=min_agents if min_agents is not None else partial_config.scaling.min_agents,
            max_agents=max_agents if max_agents is not None else partial_config.scaling.max_agents,
        )
        partial_config.enable_krisp = krisp or partial_config.enable_krisp
        partial_config.enable_managed_keys = managed_keys or partial_config.enable_managed_keys
        partial_config.agent_profile = profile or partial_config.agent_profile

        # Override build config from CLI args
        if build_dir:
            partial_config.build_config.context_dir = build_dir
        if dockerfile:
            partial_config.build_config.dockerfile = dockerfile
        if build_id:
            partial_config.build_id = build_id

        # Handle region - if not specified, API will use org's default region
        deploy_region = region or partial_config.region
        partial_config.region = deploy_region  # Can be None, API will use org default

        # Validate region if explicitly provided
        if deploy_region and not await validate_region(deploy_region):
            valid_regions = await get_region_codes()
            console.error(
                f"Invalid region '{deploy_region}'. Valid regions are: {', '.join(valid_regions)}"
            )
            return typer.Exit(1)

        # Handle Krisp VIVA configuration
        if krisp_viva_audio_filter is not None:
            partial_config.krisp_viva = KrispVivaConfig(audio_filter=krisp_viva_audio_filter)

        # Assert agent name is provided
        if not partial_config.agent_name:
            console.error("Agent name is required")
            return typer.Exit()

        # Track if we're using cloud build (either from --build-id or interactive build)
        using_cloud_build = bool(partial_config.build_id)

        # Handle image: if not provided, offer cloud build
        if not partial_config.image and not partial_config.build_id:
            if auto_yes:
                # CI/CD mode: automatically use cloud build
                console.print("[cyan]No image specified, using Pipecat Cloud Build...[/cyan]")
                should_build = True
            else:
                # Interactive mode: offer choice
                console.print(
                    Panel(
                        "Pipecat Cloud can build your image automatically.\n\n"
                        "You can also provide a pre-built image with [bold]--image[/bold] or\n"
                        "an existing build with [bold]--build-id[/bold] in pcc-deploy.toml.",
                        title="[yellow]Image Required[/yellow]",
                        title_align="left",
                        border_style="yellow",
                    )
                )
                should_build = typer.confirm(
                    "Would you like to build with Pipecat Cloud?",
                    default=True,
                )

            if should_build:
                build_id = await _cloud_build_flow(
                    build_config=partial_config.build_config,
                    region=deploy_region,
                    org=org,
                    auto_yes=auto_yes,
                )

                if not build_id:
                    return typer.Exit(1)

                partial_config.build_id = build_id
                using_cloud_build = True
            else:
                console.cancel()
                return typer.Exit()

        # Assert credentials are provided if not using --no-credentials / force flag
        # Skip this check for cloud builds (they use managed credentials)
        if (
            not using_cloud_build
            and not no_credentials
            and not partial_config.image_credentials
            and not auto_yes
        ):
            console.error(
                "Deployments require an image pull secret [bold](--credentials)[/bold] to securely pull images from private repositories."
                "\nPlease provide an image pull secret name or use [bold][--no-credentials][/bold] to deploy without one.",
                subtitle="Learn more:https://docs.pipecat.daily.co/agents/secrets#image-pull-secrets",
                title_extra="Attempt to deploy without repository credentials",
            )
            return typer.Exit()

        # Create and display table
        table = Table(show_header=False, border_style="dim", show_edge=True, show_lines=True)
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        table.add_row("Min agents", str(partial_config.scaling.min_agents))
        if partial_config.scaling.max_agents:
            table.add_row("Max agents", str(partial_config.scaling.max_agents))
        else:
            table.add_row("Max agents", "[dim]Use existing or default[/dim]")

        # Resolve region display - fetch org default if not explicitly specified
        if partial_config.region:
            region_display = f"[green]{partial_config.region}[/green]"
        else:
            # Fetch org's default region to show user what will be used
            props, error = await API.properties(org)
            if error:
                return typer.Exit()
            region_display = (
                f"[green]{props['defaultRegion']}[/green] [dim](organization default)[/dim]"
            )

        # Build the image/build display line
        if using_cloud_build:
            image_display = (
                f"[bold white]Cloud Build:[/bold white] [green]{partial_config.build_id}[/green]"
            )
        else:
            image_display = f"[bold white]Image:[/bold white] [green]{partial_config.image}[/green]"

        # Build content items
        content_items = [
            f"[bold white]Agent name:[/bold white] [green]{partial_config.agent_name}[/green]",
            image_display,
            f"[bold white]Organization:[/bold white] [green]{org}[/green]",
            f"[bold white]Region:[/bold white] {region_display}",
            f"[bold white]Secret set:[/bold white] {'[dim]None[/dim]' if not partial_config.secret_set else '[green] ' + partial_config.secret_set + '[/green]'}",
        ]

        # Only show image pull secret for non-cloud builds
        if not using_cloud_build:
            content_items.append(
                f"[bold white]Image pull secret:[/bold white] {'[dim]None[/dim]' if not partial_config.image_credentials else '[green]' + partial_config.image_credentials + '[/green]'}"
            )

        content_items.extend(
            [
                f"[bold white]Agent profile:[/bold white] {'[dim]None[/dim]' if not partial_config.agent_profile else '[green]' + partial_config.agent_profile + '[/green]'}",
                f"[bold white]Krisp (deprecated):[/bold white] {'[dim]Disabled[/dim]' if not partial_config.enable_krisp else '[green]Enabled[/green]'}",
                f"[bold white]Krisp VIVA:[/bold white] {'[dim]Disabled[/dim]' if not partial_config.krisp_viva.audio_filter else '[green]Enabled (' + partial_config.krisp_viva.audio_filter + ')[/green]'}",
                f"[bold white]Managed Keys:[/bold white] {'[dim]Disabled[/dim]' if not partial_config.enable_managed_keys else '[green]Enabled[/green]'}",
                "\n[dim]Scaling configuration:[/dim]",
            ]
        )

        content = Group(
            *content_items,
            table,
            *(
                [
                    Text(
                        f"Note: Usage costs will apply for {partial_config.scaling.min_agents} reserved agent(s). Please see: https://www.daily.co/pricing/pipecat-cloud/",
                        style="red",
                    )
                ]
                if partial_config.scaling.min_agents
                else [
                    Text(
                        "Note: Deploying with 0 minimum agents may result in cold starts",
                        style="red",
                    )
                ]
            ),
        )

        console.print(
            Panel(content, title="Review deployment", title_align="left", border_style="yellow")
        )

        if not auto_yes and not typer.confirm(
            "\nDo you want to proceed with deployment?", default=True
        ):
            console.cancel()
            return typer.Abort()

        # Deploy method posts the deployment config to the API
        # and polls the deployment status until it's ready
        await _deploy(partial_config, org, auto_yes)

    return deploy
