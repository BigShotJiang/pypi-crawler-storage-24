from .lazy_action import lazy_action

__all__ = ["lazy_action"]
