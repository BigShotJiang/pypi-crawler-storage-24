# FedComp Index Scoring

![FedComp Index](https://fedcompindex.org/static/img/FedComp-Index-Tabularium-1.png)

Federal contractor posture scoring. Scores any federal contractor from 0 to 100 based on public award data from USASpending.gov.

Each contractor receives a FedComp Index score and a posture class:

- **Class 1** (score 60+) - dominant award volume, typically $100M+ over 5 years
- **Class 2** (score 40-59) - mid-tier, typically $5M-$100M
- **Class 3** (below 40) - emerging or low-volume

## Install

```bash
pip install fedcomp-index
```

## Usage

```python
from fedcomp_index import score_contractor, PostureClass

result = score_contractor(
    total_awards_usd=45_000_000,
    last_award_date="2025-09-15"
)

result.fedcomp_index    # 58
result.posture_class    # PostureClass.CLASS_2
result.volume_driver    # 55
result.recency_driver   # 100
```

## FedComp Index scoring methodology

Two drivers, no normalization:

| Driver | Weight | How it works |
|--------|--------|-------------|
| Award volume | 90% | log10 of total dollars won, mapped to 0-100 |
| Award recency | 10% | Last award date, bucketed by age |

The FedComp Index score is an absolute measure. A contractor scoring 60 always represents roughly the same award volume regardless of state or time period. Scores are not percentile-ranked against peers.

Posture classes use fixed thresholds tied to the score:

| Posture class | FedComp Index score | Typical award volume |
|---------------|--------------------|--------------------|
| Class 1 | 60-100 | $100M+ |
| Class 2 | 40-59 | $5M-$100M |
| Class 3 | 0-39 | Under $5M |

Full methodology: [fedcompindex.org/methodology](https://fedcompindex.org/methodology/)

## Data sources

All data is sourced from public federal records:

- [USASpending.gov](https://www.usaspending.gov/) - award history, dollar amounts, agencies, NAICS codes, PSC codes
- [SAM.gov](https://sam.gov/) - entity registration, certifications, CAGE/UEI
- [SBA.gov](https://www.sba.gov/) - small business certification verification

## Live rankings

Scored contractor rankings with dossier pages, proximity maps, and spectator tracking:

- [Nevada](https://fedcompindex.org/nv/) - 348 contractors scored

## Datasets

Pre-scored datasets available for download:

- [Nevada Federal Contractors - FedComp Index](https://huggingface.co/datasets/npetro6/nevada-federal-contractors) (HuggingFace)
- [Nevada Federal Contract Awards - Monthly](https://huggingface.co/datasets/npetro6/nevada-federal-awards) (HuggingFace)
- [Nevada Federal Contractors - FedComp Index](https://www.kaggle.com/datasets/npetro6/nevada-federal-contractors-fedcomp-index) (Kaggle)
- [Nevada Federal Contract Awards - Monthly](https://www.kaggle.com/datasets/npetro6/nevada-federal-awards-2026-02) (Kaggle)

## Also available on npm

```bash
npm install fedcomp-index-scoring
```

- [fedcomp-index](https://www.npmjs.com/package/fedcomp-index) - meta-package
- [fedcomp-index-scoring](https://www.npmjs.com/package/fedcomp-index-scoring) - scoring engine
- [fedcomp-index-data](https://www.npmjs.com/package/fedcomp-index-data) - pre-scored datasets

## Links

- Website: [https://fedcompindex.org/](https://fedcompindex.org/)
- Nevada Rankings: [https://fedcompindex.org/nv/](https://fedcompindex.org/nv/)
- Methodology: [https://fedcompindex.org/methodology/](https://fedcompindex.org/methodology/)
- Tabularium: [https://fedcompindex.org/tabularium/](https://fedcompindex.org/tabularium/)
- FAQ: [https://fedcompindex.org/faq/](https://fedcompindex.org/faq/)
- Source: [https://github.com/fedcompindex/FedCompIndex](https://github.com/fedcompindex/FedCompIndex)
- npm packages: [https://github.com/fedcompindex/fedcomp-index-npm](https://github.com/fedcompindex/fedcomp-index-npm)
- PyPI: [https://pypi.org/project/fedcomp-index/](https://pypi.org/project/fedcomp-index/)
- PyPI (Scoring): [https://pypi.org/project/fedcomp-index-scoring/](https://pypi.org/project/fedcomp-index-scoring/)
- PyPI (Data): [https://pypi.org/project/fedcomp-index-data/](https://pypi.org/project/fedcomp-index-data/)
- HuggingFace: [https://huggingface.co/datasets/npetro6/nevada-federal-contractors](https://huggingface.co/datasets/npetro6/nevada-federal-contractors)
- Kaggle: [https://www.kaggle.com/datasets/npetro6/nevada-federal-contractors-fedcomp-index](https://www.kaggle.com/datasets/npetro6/nevada-federal-contractors-fedcomp-index)

## Citation

```bibtex
@software{fedcomp_index,
  title = {FedComp Index},
  author = {FedComp Index},
  url = {https://fedcompindex.org/},
  year = {2026}
}
```

## License

MIT
