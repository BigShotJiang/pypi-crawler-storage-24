import re
from setuptools import setup, find_packages

# Read version from __init__.py (single source of truth)
with open('nerdcore/__init__.py') as f:
    _version = re.search(r"__version__\s*=\s*'([^']+)'", f.read()).group(1)

setup(
    name='nerdcore',
    version=_version,
    __description__="Nerd CLI is a Fivable-specific and highly configurable CLI tool for creating/running deployments, " \
                    "commands, and more.",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://bitbucket.org/fivable/nerd-cli.git',
    author='David Wallace Cooley Jr',
    author_email='david@fivable.com',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'openai', 'pyyaml', 'python-dotenv', 'python-Levenshtein',
        'termcolor', 'tiktoken', 'psutil', 'ruamel.yaml', 'asyncssh'
    ],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            'nerd=nerdcore.cli.main:main',
            'nerd-new=nerdcore.cli.nerd_new:main',
            'nerdcore=nerdcore.__main__:main',
        ],
    },
)
