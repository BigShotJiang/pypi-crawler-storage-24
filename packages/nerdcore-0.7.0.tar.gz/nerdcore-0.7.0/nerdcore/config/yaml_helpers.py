import os

import yaml
from ruamel.yaml import YAML

from nerdcore.defs import NERD_CONFIG_DEFAULTS_PATH
from nerdcore.errors import NerdUserError
from nerdcore.utils.nerd.theme_functions import print_t


def read_yaml_file(file_path, ruamel=False):
    try:
        with open(file_path, 'r') as file:
            if ruamel:
                ruamel_yaml = get_ruamel_yaml()
                return ruamel_yaml.load(file)
            else:
                return yaml.safe_load(file)
    except FileNotFoundError:
        raise NerdUserError(f"File not found at '{file_path}'")
    except yaml.YAMLError:
        raise NerdUserError(f"File at '{file_path}' is not a valid YAML file")


def write_yaml_file(file_path, data, ruamel=False):
    try:
        with open(file_path, 'w') as file:
            if ruamel:
                ruamel_yaml = get_ruamel_yaml()
                ruamel_yaml.dump(data, file)
            else:
                yaml.safe_dump(data, file)
    except Exception as e:
        raise NerdUserError(f"An error occurred while writing to the file: {str(e)}")


def get_ruamel_yaml() -> YAML:
    ruamel_yaml = YAML()
    ruamel_yaml.default_style = "'"
    ruamel_yaml.indent(sequence=4, offset=2)
    return ruamel_yaml


def get_nerd_config_defaults():
    nerd_config_defaults_file = os.path.join(NERD_CONFIG_DEFAULTS_PATH)
    return read_yaml_file(nerd_config_defaults_file, ruamel=True)

