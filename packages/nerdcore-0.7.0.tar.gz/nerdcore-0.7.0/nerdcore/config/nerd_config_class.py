import dataclasses
from dataclasses import dataclass, field
from typing import Optional

from nerdcore.config.yaml_helpers import get_nerd_config_defaults, read_yaml_file
from nerdcore.defs import NERD_MANIFEST_PATH, import_env_class
from nerdcore.errors import NerdUserError
from nerdcore.utils.nerd.theme_functions import print_t
from nerdcore.utils.nerd_config.nerd_config_validations import (
    validate_str, validate_bool,
)

ENV = import_env_class()


@dataclass
class NerdConfig:
    _instance = None
    _manifest_cache = None

    # Config fields (from nerdcore stor/defaults/nerd-config-defaults.yaml)
    DEPLOYMENT_TYPE: Optional[str] = field(default=None)
    SERVER_DEPLOY_SCRIPT: Optional[str] = field(default=None)
    COMPOSER_INSTALL: Optional[bool] = field(default=None)
    BACKUP_DATABASE: Optional[bool] = field(default=None)
    RUN_MIGRATIONS: Optional[bool] = field(default=None)
    NPM_BUILD_SCRIPT: Optional[str] = field(default=None)
    SCP_FILES: Optional[str] = field(default=None)

    env: Optional[object] = field(default=None)

    def __post_init__(self):
        self.DEPLOYMENT_TYPE = validate_str('DEPLOYMENT_TYPE', self.DEPLOYMENT_TYPE)
        self.SERVER_DEPLOY_SCRIPT = validate_str('SERVER_DEPLOY_SCRIPT', self.SERVER_DEPLOY_SCRIPT)
        self.COMPOSER_INSTALL = validate_bool('COMPOSER_INSTALL', self.COMPOSER_INSTALL)
        self.BACKUP_DATABASE = validate_bool('BACKUP_DATABASE', self.BACKUP_DATABASE)
        self.RUN_MIGRATIONS = validate_bool('RUN_MIGRATIONS', self.RUN_MIGRATIONS)
        self.NPM_BUILD_SCRIPT = validate_str('NPM_BUILD_SCRIPT', self.NPM_BUILD_SCRIPT)
        self.SCP_FILES = validate_str('SCP_FILES', self.SCP_FILES)

        self.env = ENV.get()

    @classmethod
    def load(cls, config_name: str) -> 'NerdConfig':
        if cls._instance is None:
            manifest = cls._read_manifest()
            if config_name not in manifest:
                raise NerdUserError(f"Config '{config_name}' not found in nerd-manifest.yaml")

            profile = manifest[config_name]
            config_dict = cls.filter_config_values(profile)
            config_dict = cls.apply_defaults(config_dict)

            try:
                cls._instance = NerdConfig(**config_dict)
            except (TypeError, ValueError) as e:
                raise NerdUserError(f"NerdConfig Validation - {e}")

        return cls._instance

    @classmethod
    def _read_manifest(cls):
        if cls._manifest_cache is None:
            cls._manifest_cache = read_yaml_file(NERD_MANIFEST_PATH, ruamel=True)
        return cls._manifest_cache

    @classmethod
    def reset(cls):
        cls._instance = None
        cls._manifest_cache = None

    @classmethod
    def filter_config_values(cls, config_values: dict) -> dict:
        config_properties = {f.name for f in dataclasses.fields(cls)}
        config_properties.discard('env')
        return {k: v for k, v in config_values.items() if k in config_properties}

    @classmethod
    def apply_defaults(cls, config_values: dict) -> dict:
        nerd_config_defaults = get_nerd_config_defaults()
        for attribute in nerd_config_defaults:
            if config_values.get(attribute, '**unset') == '**unset' and nerd_config_defaults[attribute] is not None:
                config_values[attribute] = nerd_config_defaults[attribute]
        return config_values
