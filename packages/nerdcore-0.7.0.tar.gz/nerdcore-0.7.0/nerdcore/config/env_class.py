import os

from dotenv import load_dotenv

from nerdcore.config.theme import light_mode_enabled, max_terminal_width, keywords, text_themes

load_dotenv()


class ENV:
    _instance = None

    # Theme attributes (imported from theme module, NOT env vars)
    light_mode_enabled = light_mode_enabled
    max_terminal_width = max_terminal_width
    keywords = (lambda words: sorted(words, key=len, reverse=True))(keywords)
    text_themes = text_themes

    # Framework vars (from .env.default)
    OPENAI_API_KEY: str = os.getenv('OPENAI_API_KEY', 'THIS-ONES-ON-YOU')
    BARNACLE_ELB_ARN: str = os.getenv('BARNACLE_ELB_ARN', 'placeholder')
    LEAD_ELB_ARN: str = os.getenv('LEAD_ELB_ARN', 'placeholder')
    STACKABLE_ELB_ARN: str = os.getenv('STACKABLE_ELB_ARN', 'placeholder')
    CUSTOM_PROP: str = os.getenv('CUSTOM_PROP', 'custom_value')

    @classmethod
    def get(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __getattr__(self, name):
        """Dynamic access for env vars not listed as static fields."""
        val = os.getenv(name)
        if val is None:
            raise AttributeError(f"ENV has no attribute '{name}' and no env var '{name}' found")
        return val
