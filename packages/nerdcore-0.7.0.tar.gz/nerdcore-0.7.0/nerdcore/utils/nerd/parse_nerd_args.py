from typing import List, Tuple, Dict

from nerdcore.help.help import run_default_help


def split_unknown_args(unknown_args: List[str]) -> Tuple[Dict[str, bool], List[str]]:
    from collections import OrderedDict
    unknown_named_args = OrderedDict()
    unknown_unnamed_args = []

    i = 0
    while i < len(unknown_args):
        arg = unknown_args[i]
        if arg.startswith('--') or arg.startswith('-'):
            if "=" in arg:
                key, value = arg.split("=", 1)  # Split on the first "="
            else:
                key = arg
                # Peek at next arg: consume it as value only if it's not a flag
                if i + 1 < len(unknown_args) and not unknown_args[i + 1].startswith('-'):
                    i += 1
                    value = unknown_args[i]
                else:
                    value = True
            unknown_named_args[key] = value
        else:
            unknown_unnamed_args.append(arg)
        i += 1

    return unknown_named_args, unknown_unnamed_args


def parse_nerd_args():
    import argparse

    # Create argument parser - use custom help
    parser = argparse.ArgumentParser(add_help=False)

    # Global flags
    parser.add_argument('-v', '--version', action='store_true')

    # Action flags - mutually exclusive, overrides default of "run"
    action_flags = parser.add_mutually_exclusive_group()
    action_flags.add_argument('-e', '--edit', action='store_true')
    action_flags.add_argument('-h', '--help', action='store_true')

    # Entity Type flags - mutually exclusive, overrides default of "command"
    entity_type_flags = parser.add_mutually_exclusive_group()
    entity_type_flags.add_argument('-d', '--deployment', action='store_true')

    # Entity is the name of the command or overridden entity_type
    parser.add_argument('entity_name', nargs='?')

    # Parse Arguments
    nerd_args, unknown_args = parser.parse_known_args()

    # Split unknown arguments into named and unnamed
    named_args, unnamed_args = split_unknown_args(unknown_args)

    # Handle -v/--version
    if nerd_args.version is True:
        from nerdcore.ncdefs import VERSION
        from nerdcore.utils.nerd.theme_functions import print_t
        print_t(f"Nerd CLI v{VERSION}", 'nerd')
        import sys
        sys.exit(0)

    # Action
    action = 'run'
    if nerd_args.edit is True:
        action = 'edit'
    elif nerd_args.help is True:
        action = 'help'

    # Entity Type
    entity_type = 'command'
    if nerd_args.deployment is True:
        entity_type = 'deployment'

    # Per-command help: nerd help <entity>
    if nerd_args.entity_name == 'help':
        if unnamed_args:
            # nerd help <entity> → per-command help
            target_entity = unnamed_args[0]
            return nerd_args, named_args, unnamed_args, 'help', target_entity, 'any'
        else:
            # nerd help (no args) → default help page
            run_default_help()

    # nerd -h (no entity) → default help
    if action == 'help' and nerd_args.entity_name is None:
        run_default_help()

    # nerd -h <entity> → per-command help, search all entity types
    if action == 'help':
        return nerd_args, named_args, unnamed_args, 'help', nerd_args.entity_name, 'any'

    # No entity specified and no flags → default help
    if entity_type == 'command' and nerd_args.entity_name is None:
        run_default_help()

    return nerd_args, named_args, unnamed_args, action, nerd_args.entity_name, entity_type
