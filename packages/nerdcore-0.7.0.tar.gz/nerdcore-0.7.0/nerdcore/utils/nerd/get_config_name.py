from typing import List

from nerdcore.config.yaml_helpers import read_yaml_file
from nerdcore.defs import NERD_MANIFEST_PATH
from nerdcore.errors import NerdUserError
from nerdcore.utils.nerd.theme_functions import print_t, input_t


def list_configs() -> List[str]:
    """List all nerd config profile names from the manifest."""
    manifest = read_yaml_file(NERD_MANIFEST_PATH, ruamel=True)
    return list(manifest.keys())


def config_exists(name: str) -> bool:
    """Check if a config profile exists in the manifest."""
    return name in list_configs()


def get_config_name(given_config_name: str = None, prompt_user: bool = False) -> str:
    """Retrieve the config name, prompting the user if needed."""

    def select_config_from_list() -> str:
        print_t("Please select from the available configs:", 'warning')
        configs = list_configs()
        for idx, config in enumerate(configs, start=1):
            print_t(f"{idx}. {config}", 'option')
        try:
            config_index = int(input_t("Enter the number of the config")) - 1
        except (ValueError, TypeError):
            raise NerdUserError("Invalid input. Please enter a number.")
        if config_index < 0 or config_index >= len(configs):
            raise NerdUserError("Selection out of range.")
        return configs[config_index]

    if given_config_name is None:
        if config_exists('default') and not prompt_user:
            print_t("No config name provided. Loading default nerd config...", 'config')
            config_name = 'default'
        else:
            config_name = select_config_from_list()
    elif not config_exists(given_config_name):
        print_t("Provided config name does not correspond to an existing configuration. Please select an existing "
                "config:", 'important')
        config_name = select_config_from_list()
    else:
        config_name = given_config_name

    return config_name
