import asyncssh
import os


def parse_ssh_config(config_path='~/.ssh/config'):
    """Parse SSH config file, return dict of {host_name: {options}}.

    IdentityFile values are always stored as lists (SSH allows multiple per host).
    All other option keys are lowercased; values are strings.
    """
    hosts = {}
    current_host = None
    path = os.path.expanduser(config_path)
    if not os.path.exists(path):
        return hosts
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split(None, 1)
            if len(parts) != 2:
                continue
            key, value = parts
            if key.lower() == 'host':
                current_host = value
                hosts[current_host] = {}
            elif current_host:
                key_lower = key.lower()
                if key_lower == 'identityfile':
                    hosts[current_host].setdefault(key_lower, []).append(value)
                else:
                    hosts[current_host][key_lower] = value
    return hosts


class SSHConnection:
    # NOTE: Not thread-safe. If multiple threads share the same event loop or create
    # connections with the same key, the dict may be corrupted. Current callers
    # (deploy-lead, server-inventory) use one event loop per thread with distinct keys.
    instances = {}

    def __init__(self, server_name, dir_name='generic'):
        self.server_name = server_name
        self.dir_name = dir_name
        self.ssh = None
        self.key = f"{server_name}_{dir_name}"
        self.instances[self.key] = self

    async def _connect(self):
        """Connect via asyncssh — reads ~/.ssh/config natively (ProxyJump, IdentityFile, etc.)."""
        self.ssh = await asyncssh.connect(self.server_name)

    async def execute_command(self, command):
        if self.ssh is None:
            await self._connect()
        process = await self.ssh.create_process(command)
        stdout, stderr = await process.communicate()
        return process.exit_status, stdout, stderr

    async def scp_file_to_server(self, local_path, remote_path):
        if self.ssh is None:
            await self._connect()
        async with self.ssh.start_sftp_client() as sftp:
            await sftp.put(local_path, remote_path)

    async def scp_file_from_server(self, remote_path, local_path):
        if self.ssh is None:
            await self._connect()
        os.makedirs(os.path.dirname(local_path), exist_ok=True)
        async with self.ssh.start_sftp_client() as sftp:
            await sftp.get(remote_path, local_path)

    async def close(self):
        if self.ssh:
            self.ssh.close()
            await self.ssh.wait_closed()
            self.ssh = None
        self.instances.pop(self.key, None)

    async def __aenter__(self):
        # Lazy-connect: _connect() is called on first execute_command()/scp call.
        # __aenter__ just returns self; __aexit__ ensures cleanup.
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
        return False
