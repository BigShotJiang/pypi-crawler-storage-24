from nerdcore.base_entities.command_class import Command
from nerdcore.help.help import _scan_entity_dirs, CATEGORY_ORDER, CATEGORY_LABELS
from nerdcore.utils.nerd.theme_functions import print_table, apply_t


class List(Command):
    help_text = "List available commands and deployments"
    category = "utility"

    named_arg_keys = ['all']
    all: bool = False

    def run(self):
        categories = _scan_entity_dirs(include_nerdcore=self.all)

        for cat_key in CATEGORY_ORDER:
            entries = categories.get(cat_key, [])
            if not entries:
                continue

            label = CATEGORY_LABELS.get(cat_key, cat_key.title())
            rows = []
            for name, help_text, entity_type in entries:
                type_tag = " (deployment)" if entity_type == 'deployment' else ""
                rows.append([f"{name}{type_tag}", help_text or ""])

            table = {
                "headers": ["Name", "Description"],
                "show_headers": False,
                "rows": rows,
            }
            print_table(table, apply_t(label, 'special'), min_col_width=[25, 40])
