from nerdcore.base_entities.command_class import Command
from nerdcore.ncdefs import VERSION
from nerdcore.utils.nerd.theme_functions import print_t


class Version(Command):
    help_text = "Print the nerdcore version"
    category = "utility"

    def run(self):
        print_t(f"Nerd CLI v{VERSION}", 'nerd')
