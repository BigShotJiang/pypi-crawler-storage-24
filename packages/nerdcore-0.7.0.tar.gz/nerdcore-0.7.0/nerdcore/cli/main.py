import os
import subprocess
import sys
import traceback

from nerdcore.errors import NerdError, NerdUserError


def main():
    """Entry point for the `nerd` CLI command.

    CRITICAL: sys.path.append(find_project_root()) must happen before ANY
    nerdcore.defs imports. Importing defs triggers find_project_root() at
    module level and sets ROOT_PATH. Importing theme_functions triggers
    defs AND import_env_class() at module level.

    The try/except wraps the ENTIRE body so that NerdError from
    find_project_root() and nerd_env_checks() are caught here.
    """
    # Fallback newline — nerdcore.defs.nl isn't available until after sys.path setup.
    # If find_project_root() raises before we import nl, except blocks still work.
    nl = "\n"

    try:
        # 1. Project root on sys.path (BEFORE any nerdcore.defs imports)
        from nerdcore.utils.ncdefs_utils import find_project_root
        project_root = find_project_root()
        if project_root not in sys.path:
            sys.path.append(project_root)

        # 2. Line-buffered stdout for real-time output
        sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 1)

        # 3. NOW safe to import everything else
        from nerdcore.defs import nl
        from nerdcore.utils.env.environment_checks import nerd_env_checks
        from nerdcore.utils.nerd.find_entity import find_entity
        from nerdcore.utils.nerd.parse_nerd_args import parse_nerd_args
        from nerdcore.utils.nerd.run_entities import run_deployment, run_command
        from nerdcore.utils.nerd.theme_functions import print_t

        # 4. Env checks
        nerd_env_checks()

        # 5. Parse args
        nerd_args, named_args, unnamed_args, action, entity_name, entity_type = parse_nerd_args()

        # 6. Find entity
        entity_path = find_entity(entity_name, entity_type)
        entity_name = os.path.splitext(os.path.basename(entity_path))[0]

        # 7. Dispatch
        if action == 'edit':
            subprocess.run(['vim', entity_path.strip()])

        elif action == 'help':
            from nerdcore.help.help import run_entity_help
            run_entity_help(entity_path.strip())

        elif action == 'run':
            print_t(f'{entity_type}: {entity_name}', 'quiet')

            if entity_type == 'command':
                extension = os.path.splitext(entity_path.strip())[1]
                if extension == ".py":
                    run_command(entity_path.strip(), entity_name, nerd_args, named_args, unnamed_args)
                elif extension == ".sh":
                    subprocess.call(['bash', entity_path.strip()] + sys.argv[2:])
                elif extension == ".bat":
                    subprocess.call([entity_path.strip()] + sys.argv[2:])
                else:
                    print_t(f"Unsupported entity_type: {extension}. find_entity should filter this.", 'error')
                    sys.exit(1)

            elif entity_type == 'deployment':
                run_deployment(entity_path.strip(), entity_name, nerd_args, named_args, unnamed_args)

            else:
                print_t(f'unsupported entity_type: {entity_type}', 'error')
                sys.exit(1)

        else:
            print_t(f'unsupported action: {action}', 'error')
            sys.exit(1)

    except KeyboardInterrupt:
        print(f"{nl}Exiting due to KeyboardInterrupt from user.")
        sys.exit(1)

    except NerdUserError as e:
        print(f"{nl}Error: {e}")
        sys.exit(1)

    except NerdError as e:
        print(f"{nl}Error: {e}")
        print(f"{nl}Error Trace:{nl}{nl.join(traceback.format_exc().splitlines())}")
        sys.exit(1)

    except Exception as e:
        print(f"{nl}Error: {e}")
        print(f"{nl}Error Trace:{nl}{nl.join(traceback.format_exc().splitlines())}")
        sys.exit(1)

    sys.exit(0)


if __name__ == '__main__':
    main()
