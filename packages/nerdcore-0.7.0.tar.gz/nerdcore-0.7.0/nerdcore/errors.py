#
# IMPORTANT: This module must remain import-free (no nerdcore dependencies).
# It is imported by ncdefs_utils.py, which is imported by defs.py, which is
# imported by almost everything. Adding nerdcore imports here WILL cause
# circular imports.
#


class NerdError(Exception):
    """Base error for nerdcore/nerdcli. Shows message + traceback in main()."""
    pass


class NerdUserError(NerdError):
    """User-facing error (bad input, missing config). Clean message, no traceback."""
    pass
