# Roadmap

## v1.1 — Near-term

- **Multi-forge support** — abstract GitLabClient into a forge interface, add GitHub and Bitbucket backends
- **DB maintenance** — periodic cleanup of stale data (closed/merged MRs, resolved vulns, old pipelines, acknowledged events older than N days)

## v2 — Future

- MR actions from MCP tools (approve, merge, comment)
- Claude Code plugin packaging (currently requires manual MCP server config)
- Agent visibility in webui (which repo is being worked on by which agent)
- Dispatch-to-agent from webui (send work to the Claude session that owns the MCP)
- Code review interface — better UX than GitLab's native review
- Branch creation/checkout across repos

## v3 — Maybe

- Multi-workspace — multiple root directories in a single instance
