
async def test_pinned_repos_empty_by_default(cache):
    assert await cache.get_pinned() == []


async def test_pin_and_unpin_repo(cache):
    await cache.pin_repo("repo-a")
    await cache.pin_repo("repo-b")
    assert await cache.get_pinned() == ["repo-a", "repo-b"]
    await cache.unpin_repo("repo-a")
    assert await cache.get_pinned() == ["repo-b"]


async def test_pin_idempotent(cache):
    await cache.pin_repo("repo-a")
    await cache.pin_repo("repo-a")
    assert await cache.get_pinned() == ["repo-a"]


async def test_repo_order_empty_by_default(cache):
    assert await cache.get_repo_order() == []


async def test_save_and_get_repo_order(cache):
    await cache.save_repo_order(["repo-c", "repo-a", "repo-b"])
    assert await cache.get_repo_order() == ["repo-c", "repo-a", "repo-b"]


async def test_clear_repo_order(cache):
    await cache.save_repo_order(["repo-a"])
    await cache.save_repo_order([])
    assert await cache.get_repo_order() == []


async def test_pull_status_storage(cache):
    await cache.store_pull_status("repo-a", "clean")
    await cache.store_pull_status("repo-b", "conflict")
    assert await cache.get_pull_status("repo-a") == "clean"
    assert await cache.get_pull_status("repo-b") == "conflict"
    assert await cache.get_pull_status("repo-unknown") is None


async def test_pull_status_all(cache):
    await cache.store_pull_status("repo-a", "clean")
    await cache.store_pull_status("repo-b", "up-to-date")
    result = await cache.get_all_pull_statuses()
    assert result == {"repo-a": "clean", "repo-b": "up-to-date"}
