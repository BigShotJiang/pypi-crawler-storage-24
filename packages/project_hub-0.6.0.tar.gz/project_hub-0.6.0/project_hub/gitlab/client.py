"""GitLab REST + GraphQL client for MRs, pipelines, vulnerabilities, and findings."""

from __future__ import annotations

import gitlab
import gitlab.exceptions

from ..core.models import MR, Job, Pipeline, Vulnerability


class AuthenticationError(Exception):
    """Raised when the GitLab API returns 401 Unauthorized."""


class GitLabClient:
    """Synchronous GitLab client wrapping python-gitlab REST and GraphQL APIs."""

    def __init__(self, instance: str, token: str):
        url = f"https://{instance}"
        self._gl = gitlab.Gitlab(url, private_token=token)
        self._gq = gitlab.GraphQL(url, token=token)
        self._instance = instance
        self._username: str | None = None
        self._auth_failed: bool = False

    def get_username(self) -> str | None:
        """Get the authenticated user's username. Cached after first call."""
        if self._username is None and not self._auth_failed:
            try:
                self._gl.auth()
                self._username = self._gl.user.username
            except Exception:
                self._auth_failed = True
        return self._username

    def _project(self, project_path: str):
        return self._gl.projects.get(project_path)

    _MR_QUERY = """
    query ProjectMRs($fullPath: ID!, $state: MergeRequestState) {
      project(fullPath: $fullPath) {
        mergeRequests(state: $state, first: 100, sort: UPDATED_DESC) {
          nodes {
            id
            iid
            title
            author { username }
            assignees { nodes { username } }
            reviewers { nodes { username } }
            state
            sourceBranch
            targetBranch
            webUrl
            userNotesCount
            approved
            createdAt
            updatedAt
            diffHeadSha
          }
        }
      }
    }
    """

    @staticmethod
    def _parse_mr_node(node: dict) -> MR:
        gid = node.get("id", "")
        assignee_nodes = (node.get("assignees") or {}).get("nodes") or []
        reviewer_nodes = (node.get("reviewers") or {}).get("nodes") or []
        return MR(
            id=int(gid.split("/")[-1]) if "/" in gid else 0,
            iid=int(node.get("iid", 0)),
            title=node.get("title", ""),
            author=(node.get("author") or {}).get("username", ""),
            state=node.get("state", "").lower(),
            source_branch=node.get("sourceBranch", ""),
            target_branch=node.get("targetBranch", ""),
            web_url=node.get("webUrl", ""),
            user_notes_count=node.get("userNotesCount", 0),
            approved=bool(node.get("approved")),
            created_at=node.get("createdAt", ""),
            updated_at=node.get("updatedAt", ""),
            repo_name="",
            sha=node.get("diffHeadSha"),
            assignees=[n["username"] for n in assignee_nodes if n.get("username")],
            reviewers=[n["username"] for n in reviewer_nodes if n.get("username")],
        )

    def list_merge_requests(self, project_path: str, state: str = "opened") -> list[MR]:
        """Fetch merge requests via GraphQL, defaulting to opened state."""
        import logging

        logger = logging.getLogger(__name__)

        try:
            variables: dict = {"fullPath": project_path, "state": state}
            response = self._gq.execute(self._MR_QUERY, variable_values=variables)

            project_data = (response or {}).get("project")
            if not project_data:
                return []
            nodes = project_data.get("mergeRequests", {}).get("nodes") or []
            mrs = [self._parse_mr_node(n) for n in nodes]
            logger.debug(f"list_merge_requests({project_path}): {len(mrs)} MRs")
            return mrs
        except gitlab.exceptions.GitlabAuthenticationError:
            raise AuthenticationError("GitLab token expired or invalid")
        except Exception as e:
            logger.error(f"list_merge_requests({project_path}) failed: {e}")
            return []

    def list_pipelines(
        self, project_path: str, ref: str | None = None, per_page: int = 20
    ) -> list[Pipeline]:
        """Fetch recent pipelines via REST, optionally filtered by ref."""
        import logging

        logger = logging.getLogger(__name__)

        try:
            project = self._project(project_path)
            kwargs: dict = {"get_all": False, "per_page": per_page}
            if ref is not None:
                kwargs["ref"] = ref
            raw = project.pipelines.list(**kwargs)
            pipelines = [
                Pipeline(
                    id=pip.id,
                    status=pip.status,
                    ref=pip.ref,
                    web_url=pip.web_url,
                    created_at=pip.created_at,
                    repo_name="",
                )
                for pip in raw
            ]
            logger.debug(f"list_pipelines({project_path}): {len(pipelines)} pipelines")
            return pipelines
        except gitlab.exceptions.GitlabAuthenticationError:
            raise AuthenticationError("GitLab token expired or invalid")
        except Exception as e:
            logger.error(f"list_pipelines({project_path}) failed: {e}")
            return []

    def get_pipeline_jobs(self, project_path: str, pipeline_id: int) -> list[Job]:
        """Fetch all jobs for a specific pipeline."""
        try:
            project = self._project(project_path)
            pipeline = project.pipelines.get(pipeline_id)
            raw = pipeline.jobs.list(get_all=True)
            return [
                Job(
                    id=job.id,
                    name=job.name,
                    status=job.status,
                    stage=job.stage,
                    web_url=job.web_url,
                )
                for job in raw
            ]
        except gitlab.exceptions.GitlabAuthenticationError:
            raise AuthenticationError("GitLab token expired or invalid")
        except Exception:
            return []

    def get_job_log(self, project_path: str, job_id: int) -> str:
        """Fetch the trace log of a specific job."""
        try:
            project = self._project(project_path)
            return (
                project.jobs.get(job_id, lazy=True)
                .trace()
                .decode("utf-8", errors="replace")
            )
        except gitlab.exceptions.GitlabAuthenticationError:
            raise AuthenticationError("GitLab token expired or invalid")
        except Exception:
            return ""

    _VULN_QUERY = """
    query ProjectVulnerabilities(
      $fullPath: ID!
      $severity: [VulnerabilitySeverity!]
    ) {
      project(fullPath: $fullPath) {
        vulnerabilities(
          first: 100
          severity: $severity
          sort: severity_desc
        ) {
          nodes {
            id
            title
            severity
            state
            reportType
            detectedAt
            webUrl
            primaryIdentifier {
              name
              externalType
              externalId
            }
            scanner {
              name
            }
            dismissalReason
            stateComment
            falsePositive
            solution
            location {
              ... on VulnerabilityLocationSast {
                file
                startLine
              }
              ... on VulnerabilityLocationDependencyScanning {
                file
                dependency { package { name } version }
              }
              ... on VulnerabilityLocationContainerScanning {
                image
                dependency { package { name } version }
              }
              ... on VulnerabilityLocationSecretDetection {
                file
                startLine
              }
            }
          }
        }
      }
    }
    """

    _VALID_SEVERITIES = {"LOW", "MEDIUM", "HIGH", "CRITICAL", "INFO", "UNKNOWN"}

    @staticmethod
    def _parse_vuln_location(loc: dict) -> str | None:
        if loc.get("file"):
            line = loc.get("startLine")
            return f"{loc['file']}:{line}" if line else loc["file"]
        if loc.get("image"):
            dep = loc.get("dependency") or {}
            pkg = (dep.get("package") or {}).get("name", "")
            ver = dep.get("version", "")
            return f"{loc['image']} ({pkg} {ver})".strip()
        return None

    @staticmethod
    def _parse_vuln_node(v: dict) -> Vulnerability:
        gid = v.get("id", "")
        identifier = v.get("primaryIdentifier") or {}
        return Vulnerability(
            id=int(gid.split("/")[-1]) if "/" in gid else 0,
            name=identifier.get("name") or v.get("title", ""),
            severity=(v.get("severity") or "").lower(),
            state=(v.get("state") or "").lower(),
            source=(v.get("reportType") or "").lower(),
            web_url=v.get("webUrl", ""),
            repo_name="",
            mitigation_state=(v.get("dismissalReason") or "").lower() or None,
            mitigation_details=v.get("stateComment") or None,
            location=GitLabClient._parse_vuln_location(v.get("location") or {}),
            solution=v.get("solution") or None,
        )

    def get_vulnerabilities(
        self, project_path: str, severity: str | None = None
    ) -> list[Vulnerability]:
        """Fetch project vulnerabilities via GraphQL, optionally filtered by severity."""
        import logging

        logger = logging.getLogger(__name__)

        try:
            severity_filter = None
            if severity:
                upper = severity.upper()
                if upper in self._VALID_SEVERITIES:
                    severity_filter = [upper]

            variables: dict = {"fullPath": project_path}
            if severity_filter:
                variables["severity"] = severity_filter

            response = self._gq.execute(self._VULN_QUERY, variable_values=variables)

            project_data = (response or {}).get("project")
            if not project_data:
                return []
            vuln_nodes = (
                project_data.get("vulnerabilities", {}).get("nodes") or []
            )

            results = [self._parse_vuln_node(v) for v in vuln_nodes]
            logger.debug(f"{project_path}: {len(results)} vulns")
            return results
        except gitlab.exceptions.GitlabAuthenticationError:
            raise AuthenticationError("GitLab token expired or invalid")
        except Exception as e:
            logger.error(
                f"get_vulnerabilities({project_path}) failed: {e}", exc_info=True
            )
            return []

    _FINDINGS_QUERY = """
    query PipelineFindings($fullPath: ID!, $pipelineIid: ID!) {
      project(fullPath: $fullPath) {
        pipeline(iid: $pipelineIid) {
          securityReportFindings(first: 100) {
            nodes {
              title
              severity
              identifiers { name externalId }
              solution
            }
          }
        }
      }
    }
    """

    def get_pipeline_findings(self, project_path: str, pipeline_id: int) -> set[str]:
        """Return set of identifier names from a pipeline's security findings."""
        import logging

        logger = logging.getLogger(__name__)
        try:
            project = self._project(project_path)
            pipeline = project.pipelines.get(pipeline_id)
            iid = str(pipeline.iid)

            response = self._gq.execute(
                self._FINDINGS_QUERY,
                variable_values={"fullPath": project_path, "pipelineIid": iid},
            )

            nodes = (
                (response or {})
                .get("project", {})
                .get("pipeline", {})
                .get("securityReportFindings", {})
                .get("nodes") or []
            )
            names: set[str] = set()
            for f in nodes:
                for ident in f.get("identifiers") or []:
                    if ident.get("name"):
                        names.add(ident["name"])
                    if ident.get("externalId"):
                        names.add(ident["externalId"])
            logger.debug(f"{project_path} pipeline {pipeline_id}: {len(names)} finding identifiers")
            return names
        except Exception as e:
            logger.debug(f"get_pipeline_findings({project_path}, {pipeline_id}) failed: {e}")
            return set()

    def get_default_branch(self, project_path: str) -> str | None:
        """Return the project's default branch name, or None on error."""
        try:
            project = self._project(project_path)
            return project.default_branch
        except Exception:
            return None

    def get_project_info(self, project_path: str) -> dict:
        """Return basic project metadata (name, URL, default branch)."""
        try:
            project = self._project(project_path)
            return {
                "name": project.name,
                "web_url": project.web_url,
                "default_branch": project.default_branch,
            }
        except gitlab.exceptions.GitlabAuthenticationError:
            raise AuthenticationError("GitLab token expired or invalid")
        except Exception:
            return {}
