-- Add assignees and reviewers columns to merge_requests (JSON arrays of usernames).
ALTER TABLE merge_requests ADD COLUMN assignees TEXT DEFAULT '[]';
ALTER TABLE merge_requests ADD COLUMN reviewers TEXT DEFAULT '[]';
