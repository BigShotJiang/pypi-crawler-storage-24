-- Baseline schema: all tables with CREATE TABLE IF NOT EXISTS.
-- Safe to run on fresh DBs and on existing DBs (no-op for existing tables).

CREATE TABLE IF NOT EXISTS cache_metadata (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS merge_requests (
    id INTEGER,
    iid INTEGER,
    title TEXT,
    author TEXT,
    state TEXT,
    source_branch TEXT,
    target_branch TEXT,
    web_url TEXT,
    user_notes_count INTEGER,
    approved INTEGER,
    created_at TEXT,
    updated_at TEXT,
    repo_name TEXT,
    sha TEXT
);

CREATE TABLE IF NOT EXISTS pipelines (
    id INTEGER,
    status TEXT,
    ref TEXT,
    web_url TEXT,
    created_at TEXT,
    repo_name TEXT,
    PRIMARY KEY (id, repo_name)
);

CREATE TABLE IF NOT EXISTS vulnerabilities (
    id INTEGER,
    name TEXT,
    severity TEXT,
    state TEXT,
    source TEXT,
    web_url TEXT,
    repo_name TEXT,
    mitigation_state TEXT,
    mitigation_details TEXT,
    location TEXT,
    solution TEXT,
    fixed_in_branch INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT,
    repo_name TEXT,
    summary TEXT,
    detail TEXT,
    created_at TEXT,
    seen INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS ui_state (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pull_status (
    repo_name TEXT PRIMARY KEY,
    status TEXT NOT NULL
);
