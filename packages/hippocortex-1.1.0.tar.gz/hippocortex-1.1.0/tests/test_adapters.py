"""Tests for Hippocortex adapters.

Tests adapter core, OpenAI Agents, LangGraph, CrewAI, AutoGen, and OpenClaw
adapters with mocked HTTP to verify:
- Capture fires correctly
- Synthesize injects context
- Fallback works (errors swallowed)
- No crash on server down
"""

import json
import pytest
import httpx
import respx

from hippocortex.adapters._base import HippocortexAdapter


API_KEY = "hx_test_adapter123"
BASE_URL = "https://api.hippocortex.dev/v1"

SYNTH_RESPONSE = {
    "ok": True,
    "data": {
        "packId": "p-test",
        "entries": [
            {
                "section": "procedures",
                "content": "Always check disk space before deploying",
                "confidence": 0.85,
            },
            {
                "section": "failures",
                "content": "OOM errors happen with batch size > 1000",
                "confidence": 0.72,
            },
        ],
        "budget": {
            "limit": 4000,
            "used": 200,
            "compressionRatio": 0.5,
            "entriesIncluded": 2,
            "entriesDropped": 0,
        },
    },
}

CAPTURE_RESPONSE = {
    "ok": True,
    "data": {"eventId": "ev-test", "status": "ingested", "salienceScore": 0.7},
}


# ── Adapter Core Tests ──

class TestHippocortexAdapter:
    @respx.mock
    @pytest.mark.asyncio
    async def test_capture_fires(self):
        route = respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        await adapter.capture("message", {"role": "user", "content": "hello"})

        assert route.called
        body = json.loads(route.calls[0].request.content)
        assert body["type"] == "message"
        assert body["payload"]["content"] == "hello"
        assert body["sessionId"].startswith("auto-")

    @respx.mock
    @pytest.mark.asyncio
    async def test_synthesize_returns_entries(self):
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json=SYNTH_RESPONSE)
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        entries = await adapter.synthesize("deploy service")

        assert len(entries) == 2
        assert entries[0].section == "procedures"
        assert entries[0].confidence == 0.85
        assert "disk space" in entries[0].content

    @respx.mock
    @pytest.mark.asyncio
    async def test_synthesize_returns_empty_on_error(self):
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(500, json={"ok": False, "error": {"code": "internal", "message": "boom"}})
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        entries = await adapter.synthesize("test")

        assert entries == []

    @respx.mock
    @pytest.mark.asyncio
    async def test_capture_swallows_errors(self):
        respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(500, json={"ok": False, "error": {"code": "internal", "message": "fail"}})
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        # Should NOT raise
        await adapter.capture("message", {"role": "user", "content": "test"})

    @respx.mock
    @pytest.mark.asyncio
    async def test_capture_swallows_network_errors(self):
        respx.post(f"{BASE_URL}/capture").mock(side_effect=httpx.ConnectError("connection refused"))

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        # Should NOT raise
        await adapter.capture("message", {"role": "user", "content": "test"})

    @respx.mock
    @pytest.mark.asyncio
    async def test_synthesize_returns_empty_on_network_error(self):
        respx.post(f"{BASE_URL}/synthesize").mock(side_effect=httpx.ConnectError("refused"))

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        entries = await adapter.synthesize("test")
        assert entries == []

    @pytest.mark.asyncio
    async def test_disabled_without_api_key(self):
        adapter = HippocortexAdapter(api_key="", base_url=BASE_URL)
        assert not adapter.enabled

        # Should be no-ops
        await adapter.capture("message", {"role": "user", "content": "test"})
        entries = await adapter.synthesize("test")
        assert entries == []

    @respx.mock
    @pytest.mark.asyncio
    async def test_inject_context(self):
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json=SYNTH_RESPONSE)
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        messages = [{"role": "user", "content": "deploy service"}]
        result = await adapter.inject_context(messages, "deploy service")

        assert len(result) == 2
        assert result[0]["role"] == "system"
        assert "Hippocortex Memory Context" in result[0]["content"]
        assert "disk space" in result[0]["content"]
        assert result[1] == messages[0]

    @respx.mock
    @pytest.mark.asyncio
    async def test_inject_context_no_entries(self):
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json={
                "ok": True,
                "data": {
                    "packId": "p-empty",
                    "entries": [],
                    "budget": {"limit": 4000, "used": 0, "compressionRatio": 0.0, "entriesIncluded": 0, "entriesDropped": 0},
                },
            })
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        messages = [{"role": "user", "content": "hello"}]
        result = await adapter.inject_context(messages, "hello")

        # Should return original messages unchanged
        assert result == messages

    @respx.mock
    @pytest.mark.asyncio
    async def test_custom_session_id(self):
        route = respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL, session_id="custom-123")
        assert adapter.session_id == "custom-123"

        await adapter.capture("message", {"role": "user", "content": "test"})
        body = json.loads(route.calls[0].request.content)
        assert body["sessionId"] == "custom-123"


# ── Sync Adapter Tests ──

class TestHippocortexAdapterSync:
    @respx.mock
    def test_capture_sync(self):
        route = respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        adapter.capture_sync("message", {"role": "user", "content": "hello"})

        assert route.called

    @respx.mock
    def test_synthesize_sync(self):
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json=SYNTH_RESPONSE)
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        entries = adapter.synthesize_sync("deploy")

        assert len(entries) == 2

    @respx.mock
    def test_capture_sync_swallows_errors(self):
        respx.post(f"{BASE_URL}/capture").mock(side_effect=httpx.ConnectError("refused"))

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        adapter.capture_sync("message", {"role": "user", "content": "test"})

    @respx.mock
    def test_inject_context_sync(self):
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json=SYNTH_RESPONSE)
        )

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)
        messages = [{"role": "user", "content": "deploy"}]
        result = adapter.inject_context_sync(messages, "deploy")

        assert len(result) == 2
        assert result[0]["role"] == "system"


# ── OpenClaw Adapter Tests ──

class TestOpenClawAdapter:
    @respx.mock
    @pytest.mark.asyncio
    async def test_on_message_captures(self):
        route = respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json={
                "ok": True,
                "data": {"packId": "p-e", "entries": [], "budget": {"limit": 4000, "used": 0, "compressionRatio": 0.0, "entriesIncluded": 0, "entriesDropped": 0}},
            })
        )

        from hippocortex.adapters.openclaw import create_middleware
        mw = create_middleware(api_key=API_KEY, base_url=BASE_URL)
        context = await mw.on_message("hello world")

        assert route.called
        body = json.loads(route.calls[0].request.content)
        assert body["payload"]["role"] == "user"
        assert body["payload"]["content"] == "hello world"

    @respx.mock
    @pytest.mark.asyncio
    async def test_on_message_returns_context(self):
        respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json=SYNTH_RESPONSE)
        )

        from hippocortex.adapters.openclaw import create_middleware
        mw = create_middleware(api_key=API_KEY, base_url=BASE_URL)
        context = await mw.on_message("deploy service")

        assert context is not None
        assert "Hippocortex Memory Context" in context
        assert "disk space" in context

    @respx.mock
    @pytest.mark.asyncio
    async def test_on_response_captures(self):
        route = respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )

        from hippocortex.adapters.openclaw import create_middleware
        mw = create_middleware(api_key=API_KEY, base_url=BASE_URL)
        await mw.on_response("Here is the deployment plan...")

        assert route.called
        body = json.loads(route.calls[0].request.content)
        assert body["payload"]["role"] == "assistant"

    @respx.mock
    @pytest.mark.asyncio
    async def test_on_tool_call_captures(self):
        route = respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )

        from hippocortex.adapters.openclaw import create_middleware
        mw = create_middleware(api_key=API_KEY, base_url=BASE_URL)
        await mw.on_tool_call("kubectl", {"command": "apply -f deploy.yaml"})

        assert route.called
        body = json.loads(route.calls[0].request.content)
        assert body["type"] == "tool_call"
        assert body["payload"]["tool_name"] == "kubectl"


# ── LangGraph Adapter Tests ──

class TestLangGraphAdapter:
    @respx.mock
    @pytest.mark.asyncio
    async def test_wrap_captures_input_output(self):
        capture_route = respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json={
                "ok": True,
                "data": {"packId": "p-e", "entries": [], "budget": {"limit": 4000, "used": 0, "compressionRatio": 0.0, "entriesIncluded": 0, "entriesDropped": 0}},
            })
        )

        from hippocortex.adapters import langgraph as hx_lg

        # Mock graph
        class MockGraph:
            async def ainvoke(self, input, config=None, **kwargs):
                return {"messages": [{"role": "assistant", "content": "Done!"}]}

        graph = MockGraph()
        wrapped = hx_lg.wrap(graph, api_key=API_KEY, base_url=BASE_URL)

        result = await wrapped.ainvoke({"messages": [{"role": "user", "content": "deploy"}]})

        assert result["messages"][0]["content"] == "Done!"
        # Should have captured user input and assistant output
        assert capture_route.call_count >= 2

    @respx.mock
    @pytest.mark.asyncio
    async def test_wrap_injects_context(self):
        respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json=SYNTH_RESPONSE)
        )

        from hippocortex.adapters import langgraph as hx_lg

        received_input = {}

        class MockGraph:
            async def ainvoke(self, input, config=None, **kwargs):
                received_input.update(input)
                return {"messages": [{"role": "assistant", "content": "Done!"}]}

        graph = MockGraph()
        wrapped = hx_lg.wrap(graph, api_key=API_KEY, base_url=BASE_URL)

        await wrapped.ainvoke({"messages": [{"role": "user", "content": "deploy"}]})

        # Should have injected a system message
        msgs = received_input.get("messages", [])
        assert len(msgs) == 2
        # First should be system message with context
        first = msgs[0]
        if isinstance(first, dict):
            assert first["role"] == "system"
            assert "Hippocortex" in first["content"]

    @respx.mock
    def test_wrap_sync_invoke(self):
        respx.post(f"{BASE_URL}/capture").mock(
            return_value=httpx.Response(200, json=CAPTURE_RESPONSE)
        )
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=httpx.Response(200, json={
                "ok": True,
                "data": {"packId": "p-e", "entries": [], "budget": {"limit": 4000, "used": 0, "compressionRatio": 0.0, "entriesIncluded": 0, "entriesDropped": 0}},
            })
        )

        from hippocortex.adapters import langgraph as hx_lg

        class MockGraph:
            def invoke(self, input, config=None, **kwargs):
                return {"messages": [{"role": "assistant", "content": "OK"}]}

        graph = MockGraph()
        wrapped = hx_lg.wrap(graph, api_key=API_KEY, base_url=BASE_URL)

        result = wrapped.invoke({"messages": [{"role": "user", "content": "test"}]})
        assert result["messages"][0]["content"] == "OK"


# ── Graceful Degradation Tests ──

class TestGracefulDegradation:
    @respx.mock
    @pytest.mark.asyncio
    async def test_adapter_survives_server_down(self):
        """Adapter must never crash even if server is completely unreachable."""
        respx.post(f"{BASE_URL}/capture").mock(side_effect=httpx.ConnectError("refused"))
        respx.post(f"{BASE_URL}/synthesize").mock(side_effect=httpx.ConnectError("refused"))

        adapter = HippocortexAdapter(api_key=API_KEY, base_url=BASE_URL)

        # All of these should complete without error
        await adapter.capture("message", {"role": "user", "content": "test"})
        entries = await adapter.synthesize("test")
        assert entries == []
        result = await adapter.inject_context(
            [{"role": "user", "content": "test"}], "test"
        )
        assert len(result) == 1  # Original message only

    @respx.mock
    @pytest.mark.asyncio
    async def test_openclaw_middleware_survives_server_down(self):
        respx.post(f"{BASE_URL}/capture").mock(side_effect=httpx.ConnectError("refused"))
        respx.post(f"{BASE_URL}/synthesize").mock(side_effect=httpx.ConnectError("refused"))

        from hippocortex.adapters.openclaw import create_middleware
        mw = create_middleware(api_key=API_KEY, base_url=BASE_URL)

        # Should not crash
        context = await mw.on_message("test")
        assert context is None
        await mw.on_response("response")
        await mw.on_tool_call("kubectl", {"cmd": "get pods"})

    @respx.mock
    @pytest.mark.asyncio
    async def test_langgraph_wrapper_survives_server_down(self):
        respx.post(f"{BASE_URL}/capture").mock(side_effect=httpx.ConnectError("refused"))
        respx.post(f"{BASE_URL}/synthesize").mock(side_effect=httpx.ConnectError("refused"))

        from hippocortex.adapters import langgraph as hx_lg

        class MockGraph:
            async def ainvoke(self, input, config=None, **kwargs):
                return {"messages": [{"role": "assistant", "content": "OK"}]}

        graph = MockGraph()
        wrapped = hx_lg.wrap(graph, api_key=API_KEY, base_url=BASE_URL)

        # Should still return the graph's result
        result = await wrapped.ainvoke({"messages": [{"role": "user", "content": "test"}]})
        assert result["messages"][0]["content"] == "OK"
