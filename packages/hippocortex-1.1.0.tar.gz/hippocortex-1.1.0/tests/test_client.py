"""Tests for the Hippocortex Python client."""

import json
import pytest
import httpx
import respx

from hippocortex import Hippocortex, HippocortexError, SyncHippocortex
from hippocortex.types import CaptureEvent


API_KEY = "hx_test_unit123"
BASE_URL = "https://api.hippocortex.dev/v1"


def _ok_response(data):
    """Create a standard OK API response."""
    return httpx.Response(
        200,
        json={"ok": True, "data": data, "meta": {"requestId": "r-1", "tenantId": "t-1", "durationMs": 5}},
    )


def _error_response(code, message, status=400):
    return httpx.Response(
        status,
        json={"ok": False, "error": {"code": code, "message": message}},
    )


class TestAsyncClient:
    @pytest.fixture
    def client(self):
        return Hippocortex(api_key=API_KEY, base_url=BASE_URL)

    @respx.mock
    @pytest.mark.asyncio
    async def test_capture(self, client):
        respx.post(f"{BASE_URL}/capture").mock(
            return_value=_ok_response({"eventId": "ev-1", "status": "ingested", "salienceScore": 0.8})
        )

        event = CaptureEvent(type="message", session_id="sess-1", payload={"role": "user", "content": "hello"})
        result = await client.capture(event)
        assert result.event_id == "ev-1"
        assert result.status == "ingested"
        assert result.salience_score == 0.8

    @respx.mock
    @pytest.mark.asyncio
    async def test_synthesize(self, client):
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=_ok_response({
                "packId": "p-1",
                "entries": [
                    {"section": "procedures", "content": "Use kubectl apply", "confidence": 0.9},
                ],
                "budget": {
                    "limit": 4000,
                    "used": 100,
                    "compressionRatio": 0.5,
                    "entriesIncluded": 1,
                    "entriesDropped": 0,
                },
            })
        )

        result = await client.synthesize("deploy")
        assert result.pack_id == "p-1"
        assert len(result.entries) == 1
        assert result.entries[0].section == "procedures"
        assert result.entries[0].confidence == 0.9

    @respx.mock
    @pytest.mark.asyncio
    async def test_learn(self, client):
        respx.post(f"{BASE_URL}/learn").mock(
            return_value=_ok_response({
                "runId": "run-1",
                "status": "completed",
                "artifacts": {"created": 3, "updated": 1, "unchanged": 0, "byType": {"task_schema": 2}},
                "stats": {"memoriesProcessed": 100, "patternsFound": 5, "compilationMs": 1200},
            })
        )

        result = await client.learn()
        assert result.status == "completed"
        assert result.artifacts_created == 3

    @respx.mock
    @pytest.mark.asyncio
    async def test_error_handling(self, client):
        respx.post(f"{BASE_URL}/capture").mock(
            return_value=_error_response("rate_limited", "Too many requests", 429)
        )

        event = CaptureEvent(type="message", session_id="s-1", payload={"role": "user", "content": "x"})
        with pytest.raises(HippocortexError) as exc_info:
            await client.capture(event)
        assert exc_info.value.code == "rate_limited"
        assert exc_info.value.status_code == 429

    def test_no_api_key_raises(self):
        with pytest.raises(ValueError, match="API key is required"):
            Hippocortex(api_key="")


class TestSyncClient:
    @respx.mock
    def test_capture_sync(self):
        respx.post(f"{BASE_URL}/capture").mock(
            return_value=_ok_response({"eventId": "ev-2", "status": "ingested"})
        )

        client = SyncHippocortex(api_key=API_KEY, base_url=BASE_URL)
        event = CaptureEvent(type="message", session_id="sess-2", payload={"role": "user", "content": "hi"})
        result = client.capture(event)
        assert result.event_id == "ev-2"

    @respx.mock
    def test_synthesize_sync(self):
        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=_ok_response({
                "packId": "p-2",
                "entries": [],
                "budget": {"limit": 4000, "used": 0, "compressionRatio": 0.0, "entriesIncluded": 0, "entriesDropped": 0},
            })
        )

        client = SyncHippocortex(api_key=API_KEY, base_url=BASE_URL)
        result = client.synthesize("test")
        assert result.pack_id == "p-2"
        assert len(result.entries) == 0
