"""Tests for the wrap() function."""

import os
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import httpx
import pytest
import respx

from hippocortex import wrap
from hippocortex.config import resolve_config, load_config


API_KEY = "hx_test_wrap123"
BASE_URL = "https://api.hippocortex.dev/v1"


def _ok_response(data):
    return httpx.Response(200, json={"ok": True, "data": data})


def _synth_response(entries=None):
    if entries is None:
        entries = []
    return _ok_response({
        "packId": "p-1",
        "entries": entries,
        "budget": {
            "limit": 4000,
            "used": 100,
            "compressionRatio": 0.5,
            "entriesIncluded": len(entries),
            "entriesDropped": 0,
        },
    })


def _capture_response():
    return _ok_response({"eventId": "ev-1", "status": "ingested"})


def _make_openai_client(response=None):
    """Create a fake OpenAI-like client."""
    if response is None:
        response = SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content="Hello back!", role="assistant"))],
        )
    create_mock = MagicMock(return_value=response)
    completions = SimpleNamespace(create=create_mock)
    chat = SimpleNamespace(completions=completions)
    client = SimpleNamespace(chat=chat)
    return client, create_mock


def _make_anthropic_client(response=None):
    """Create a fake Anthropic-like client."""
    if response is None:
        response = SimpleNamespace(
            content=[SimpleNamespace(type="text", text="I can help with that.")],
            role="assistant",
        )
    create_mock = MagicMock(return_value=response)
    messages = SimpleNamespace(create=create_mock)
    client = SimpleNamespace(messages=messages)
    return client, create_mock


class TestWrapNoConfig:
    def test_returns_unchanged_without_key(self, monkeypatch):
        monkeypatch.delenv("HIPPOCORTEX_API_KEY", raising=False)
        client, original_create = _make_openai_client()
        result = wrap(client)
        # Should not be wrapped
        assert result.chat.completions.create is original_create

    def test_returns_unknown_client_unchanged(self, monkeypatch):
        monkeypatch.setenv("HIPPOCORTEX_API_KEY", API_KEY)
        weird = SimpleNamespace(do_stuff=lambda: None)
        result = wrap(weird)
        assert result is weird


class TestWrapOpenAI:
    @respx.mock
    def test_wraps_and_synthesizes(self, monkeypatch):
        monkeypatch.setenv("HIPPOCORTEX_API_KEY", API_KEY)

        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=_synth_response([
                {"section": "procedures", "content": "Always greet warmly", "confidence": 0.9},
            ]),
        )
        respx.post(f"{BASE_URL}/capture").mock(return_value=_capture_response())

        client, create_mock = _make_openai_client()
        wrapped = wrap(client, session_id="test-s1")

        result = wrapped.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello"}],
        )

        # Original response returned
        assert hasattr(result, "choices")

        # create_mock should have been called with augmented messages
        call_kwargs = create_mock.call_args
        # The messages should include a system message
        called_messages = call_kwargs.kwargs.get("messages", call_kwargs.args[0].get("messages") if call_kwargs.args else [])
        assert any(
            m.get("role") == "system" and "Hippocortex" in m.get("content", "")
            for m in called_messages
        )

    @respx.mock
    def test_transparent_on_synthesize_failure(self, monkeypatch):
        monkeypatch.setenv("HIPPOCORTEX_API_KEY", API_KEY)

        respx.post(f"{BASE_URL}/synthesize").mock(side_effect=httpx.ConnectError("down"))
        respx.post(f"{BASE_URL}/capture").mock(side_effect=httpx.ConnectError("down"))

        openai_response = SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content="Works", role="assistant"))],
        )
        client, create_mock = _make_openai_client(openai_response)
        wrapped = wrap(client, session_id="test-s2")

        result = wrapped.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Still works?"}],
        )

        # Original response comes through
        assert result.choices[0].message.content == "Works"
        create_mock.assert_called_once()


class TestWrapAnthropic:
    @respx.mock
    def test_wraps_and_injects_system(self, monkeypatch):
        monkeypatch.setenv("HIPPOCORTEX_API_KEY", API_KEY)

        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=_synth_response([
                {"section": "context", "content": "User likes concise replies", "confidence": 0.8},
            ]),
        )
        respx.post(f"{BASE_URL}/capture").mock(return_value=_capture_response())

        client, create_mock = _make_anthropic_client()
        wrapped = wrap(client, session_id="test-s3")

        result = wrapped.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[{"role": "user", "content": "Explain memory"}],
        )

        assert hasattr(result, "content")
        call_kwargs = create_mock.call_args.kwargs
        assert "Hippocortex" in call_kwargs.get("system", "")

    @respx.mock
    def test_appends_to_existing_system(self, monkeypatch):
        monkeypatch.setenv("HIPPOCORTEX_API_KEY", API_KEY)

        respx.post(f"{BASE_URL}/synthesize").mock(
            return_value=_synth_response([
                {"section": "facts", "content": "Project uses Python", "confidence": 0.95},
            ]),
        )
        respx.post(f"{BASE_URL}/capture").mock(return_value=_capture_response())

        client, create_mock = _make_anthropic_client()
        wrapped = wrap(client, session_id="test-s4")

        wrapped.messages.create(
            model="claude-sonnet-4-20250514",
            system="You are a helpful assistant.",
            messages=[{"role": "user", "content": "Help"}],
        )

        call_kwargs = create_mock.call_args.kwargs
        system_val = call_kwargs.get("system", "")
        assert "Hippocortex" in system_val
        assert "You are a helpful assistant." in system_val


class TestConfig:
    def test_resolve_from_env(self, monkeypatch):
        monkeypatch.setenv("HIPPOCORTEX_API_KEY", "hx_test_env")
        config = resolve_config()
        assert config is not None
        assert config["apiKey"] == "hx_test_env"

    def test_resolve_explicit_takes_priority(self, monkeypatch):
        monkeypatch.setenv("HIPPOCORTEX_API_KEY", "hx_test_env")
        config = resolve_config(api_key="hx_test_explicit")
        assert config is not None
        assert config["apiKey"] == "hx_test_explicit"

    def test_resolve_returns_none_without_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("HIPPOCORTEX_API_KEY", raising=False)
        # Use tmp_path as cwd so no .hippocortex.json is found
        result = load_config(str(tmp_path))
        assert result is None

    def test_load_config_from_file(self, tmp_path):
        config_file = tmp_path / ".hippocortex.json"
        config_file.write_text('{"apiKey": "hx_test_file", "baseUrl": "http://localhost:8080/v1"}')
        result = load_config(str(tmp_path))
        assert result is not None
        assert result["apiKey"] == "hx_test_file"
        assert result["baseUrl"] == "http://localhost:8080/v1"


class TestSessionId:
    @respx.mock
    def test_auto_generates_session_id(self, monkeypatch):
        monkeypatch.setenv("HIPPOCORTEX_API_KEY", API_KEY)

        captured_bodies = []

        def capture_handler(request):
            import json
            captured_bodies.append(json.loads(request.content))
            return _capture_response()

        respx.post(f"{BASE_URL}/synthesize").mock(return_value=_synth_response())
        respx.post(f"{BASE_URL}/capture").mock(side_effect=capture_handler)

        client, _ = _make_openai_client()
        wrapped = wrap(client)  # No explicit session_id

        wrapped.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "test"}],
        )

        if captured_bodies:
            sid = captured_bodies[0].get("sessionId", "")
            assert sid.startswith("hx_")
