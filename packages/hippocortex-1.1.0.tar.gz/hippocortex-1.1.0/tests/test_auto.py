"""Tests for hippocortex.auto module."""

import os
import re
from types import SimpleNamespace
from typing import Any, Dict, List
from unittest.mock import MagicMock, patch

import pytest

from hippocortex.auto import (
    _extract_user_message,
    _build_context_text,
    _generate_session_id,
    _PATCHED_ATTR,
    _wrap_openai_stream,
    _wrap_anthropic_stream,
)


class TestGenerateSessionId:
    def test_format(self):
        sid = _generate_session_id()
        assert sid.startswith("hx_auto_")
        # Should have hostname_pid_timestamp format
        parts = sid.split("_")
        assert len(parts) >= 5  # hx, auto, hostname (may have underscores), pid, timestamp

    def test_contains_pid(self):
        sid = _generate_session_id()
        assert str(os.getpid()) in sid

    def test_stable_prefix(self):
        id1 = _generate_session_id()
        id2 = _generate_session_id()
        # Same hostname and pid
        prefix1 = "_".join(id1.split("_")[:-1])
        prefix2 = "_".join(id2.split("_")[:-1])
        assert prefix1 == prefix2


class TestExtractUserMessage:
    def test_string_content(self):
        messages = [
            {"role": "system", "content": "System"},
            {"role": "user", "content": "Hello"},
        ]
        assert _extract_user_message(messages) == "Hello"

    def test_last_user_message(self):
        messages = [
            {"role": "user", "content": "First"},
            {"role": "assistant", "content": "Reply"},
            {"role": "user", "content": "Second"},
        ]
        assert _extract_user_message(messages) == "Second"

    def test_multimodal_content(self):
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": "data:..."}},
                    {"type": "text", "text": "What is this?"},
                ],
            },
        ]
        assert _extract_user_message(messages) == "What is this?"

    def test_empty_messages(self):
        assert _extract_user_message([]) is None

    def test_no_user_message(self):
        messages = [
            {"role": "system", "content": "System"},
            {"role": "assistant", "content": "Reply"},
        ]
        assert _extract_user_message(messages) is None


class TestBuildContextText:
    def test_builds_formatted_context(self):
        result = SimpleNamespace(
            entries=[
                SimpleNamespace(section="procedures", content="Always greet warmly"),
                SimpleNamespace(section="facts", content="User prefers Python"),
            ]
        )
        text = _build_context_text(result)
        assert "[Hippocortex Memory Context]" in text
        assert "[procedures] Always greet warmly" in text
        assert "[facts] User prefers Python" in text

    def test_empty_entries(self):
        result = SimpleNamespace(entries=[])
        assert _build_context_text(result) == ""

    def test_no_entries_attr(self):
        result = SimpleNamespace()
        assert _build_context_text(result) == ""


class TestPatchedAttr:
    def test_patched_attr_is_string(self):
        assert isinstance(_PATCHED_ATTR, str)
        assert _PATCHED_ATTR == "_hippocortex_auto_patched"


class TestOpenAIStreamWrapper:
    def test_passes_through_chunks(self):
        chunks = [
            SimpleNamespace(
                choices=[SimpleNamespace(delta=SimpleNamespace(content="Hello"))]
            ),
            SimpleNamespace(
                choices=[SimpleNamespace(delta=SimpleNamespace(content=" world"))]
            ),
            SimpleNamespace(
                choices=[SimpleNamespace(delta=SimpleNamespace(content="!"))]
            ),
        ]

        hx = MagicMock()
        hx.capture = MagicMock()

        wrapped = _wrap_openai_stream(iter(chunks), hx, "test-session", "Hi there")

        collected = list(wrapped)
        assert len(collected) == 3
        assert collected[0].choices[0].delta.content == "Hello"
        assert collected[1].choices[0].delta.content == " world"
        assert collected[2].choices[0].delta.content == "!"

    def test_captures_after_stream_ends(self):
        chunks = [
            SimpleNamespace(
                choices=[SimpleNamespace(delta=SimpleNamespace(content="Response"))]
            ),
        ]

        hx = MagicMock()
        hx.capture = MagicMock()

        wrapped = _wrap_openai_stream(iter(chunks), hx, "test-session", "Question")
        list(wrapped)  # consume the stream

        # Should have captured user + assistant messages
        assert hx.capture.call_count == 2


class TestAnthropicStreamWrapper:
    def test_passes_through_events(self):
        events = [
            SimpleNamespace(type="content_block_delta", delta=SimpleNamespace(text="Hello")),
            SimpleNamespace(type="content_block_delta", delta=SimpleNamespace(text=" world")),
            SimpleNamespace(type="message_stop"),
        ]

        hx = MagicMock()
        hx.capture = MagicMock()

        wrapped = _wrap_anthropic_stream(iter(events), hx, "test-session", "Hi")

        collected = list(wrapped)
        assert len(collected) == 3

    def test_captures_after_stream_ends(self):
        events = [
            SimpleNamespace(type="content_block_delta", delta=SimpleNamespace(text="Answer")),
        ]

        hx = MagicMock()
        hx.capture = MagicMock()

        wrapped = _wrap_anthropic_stream(iter(events), hx, "test-session", "Question")
        list(wrapped)

        assert hx.capture.call_count == 2


class TestSilentMode:
    def test_silent_env_var(self, monkeypatch):
        monkeypatch.setenv("HIPPOCORTEX_SILENT", "1")
        # No output should be produced -- just verify the env var is respected
        assert os.environ.get("HIPPOCORTEX_SILENT") == "1"


class TestGracefulDegradation:
    def test_no_crash_without_openai(self):
        """The auto module should not crash if openai is not installed."""
        # This is implicitly tested by the module importing successfully
        # in the test environment
        from hippocortex import auto
        assert hasattr(auto, "_init")

    def test_no_crash_without_anthropic(self):
        """The auto module should not crash if anthropic is not installed."""
        from hippocortex import auto
        assert hasattr(auto, "_patch_anthropic")

    def test_no_crash_without_api_key(self, monkeypatch):
        """The module should warn but not crash without an API key."""
        monkeypatch.delenv("HIPPOCORTEX_API_KEY", raising=False)
        # Re-importing should be safe (idempotent)
        from hippocortex import auto
        assert True


class TestIdempotency:
    def test_double_import_is_safe(self):
        """Importing auto twice should not double-patch."""
        import hippocortex.auto
        import importlib
        # Re-import should be a no-op due to _initialized flag
        importlib.reload(hippocortex.auto)
        assert True
