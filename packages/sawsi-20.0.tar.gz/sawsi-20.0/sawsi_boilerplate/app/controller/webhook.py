from sawsi.handler.controller_decorator import controller
from {{app}}.service import subscription_service


@controller
def apple_update_subscription(signed_payload: str):
    """Apple App Store Server Notification v2 웹훅

    Apple이 구독 상태 변경(갱신, 취소, 환불 등) 시 호출.
    signed_payload(JWT)를 통으로 서비스에 전달하여 처리.
    """
    return subscription_service.handle_apple_webhook(signed_payload)


@controller
def google_update_subscription(message: dict):
    """Google Play Developer Notification (Pub/Sub) 웹훅

    Google이 구독 상태 변경 시 Pub/Sub 메시지로 전달.
    base64 인코딩된 message를 통으로 서비스에 전달하여 처리.
    """
    return subscription_service.handle_google_webhook(message)
