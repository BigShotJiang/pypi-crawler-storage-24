from typing import Optional
from sawsi.handler.controller_decorator import controller
from {{app}}.model.user import User
from {{app}}.model.toss_payment import TossPayment
from {{app}}.service import toss_payment_service


@controller
def confirm_toss_payment(
        user: User,
        payment_key: str, order_id: str, amount: float,
):
    """결제 승인

    클라이언트에서 토스 결제창 인증 완료 후 받은 값으로 승인 요청.
    결제 승인은 인증 후 10분 이내에 호출해야 함.
    """
    return toss_payment_service.confirm_toss_payment(
        payment_key=payment_key, order_id=order_id,
        amount=amount, user_id=user.id,
    )


@controller
def cancel_toss_payment(
        user: User,
        payment_key: str,
        cancel_reason: str,
        cancel_amount: Optional[float] = None,
):
    """결제 취소 (전체/부분)

    cancel_amount 미지정 시 전액 취소.
    """
    return toss_payment_service.cancel_toss_payment(
        payment_key=payment_key,
        cancel_reason=cancel_reason,
        cancel_amount=cancel_amount,
    )


@controller
def get_toss_payment(user: User, payment_key: str):
    """결제 조회"""
    return toss_payment_service.get_toss_payment(payment_key=payment_key)


@controller
def list_toss_payments(user: User, start_key: Optional[str] = None):
    """내 결제 내역 목록 조회"""
    items, end_key = TossPayment.query(
        pk_field='user_id', pk_value=user.id,
        sk_field='crt', reverse=True,
        start_key=start_key,
    )
    return {
        'items': [item.view() for item in items],
        'start_key': end_key,
    }
