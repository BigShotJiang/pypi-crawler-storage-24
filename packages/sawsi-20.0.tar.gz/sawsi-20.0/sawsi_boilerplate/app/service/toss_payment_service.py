"""
토스페이먼츠 일회성 결제 서비스

결제 흐름:
1. 클라이언트에서 토스 결제창 → 결제 인증 완료 → successUrl로 리다이렉트
2. successUrl에서 paymentKey, orderId, amount를 받아 서버로 전달
3. 서버에서 confirm_payment 호출 → 토스 API로 결제 승인 → DB 저장
"""
import base64
import requests
from typing import Optional

import api
from {{app}}.model.toss_payment import TossPayment

TOSS_SECRET_KEY = api.secret_manager.get_secret_value('toss_secret_key')
TOSS_BASE_URL = 'https://api.tosspayments.com/v1'


# ============================================================
# Public API
# ============================================================

def confirm_toss_payment(
        payment_key: str, order_id: str, amount: float,
        user_id: str,
) -> dict:
    """결제 승인

    클라이언트에서 결제 인증 후 받은 paymentKey, orderId, amount로
    토스 결제 승인 API를 호출하고 결과를 DB에 저장.

    Args:
        payment_key: 토스 paymentKey
        order_id: 가맹점 주문 ID
        amount: 결제 금액 (클라이언트 전달값과 일치해야 함)
        user_id: 사용자 ID

    Returns:
        status, payment 포함 dict
    """
    response = {'status': 'failed', 'payment': None}

    # 토스 결제 승인 API 호출
    result = _toss_confirm(payment_key, order_id, amount)
    if not result:
        return response

    if 'code' in result:
        # 에러 응답
        response['error_code'] = result.get('code')
        response['error_message'] = result.get('message')
        return response

    # DB 저장
    payment = _save_payment(result, user_id)
    response['status'] = 'succeed'
    response['payment'] = payment.view()
    return response


def cancel_toss_payment(
        payment_key: str,
        cancel_reason: str,
        cancel_amount: float = None,
) -> dict:
    """결제 취소 (전체/부분)

    cancel_amount를 지정하지 않으면 전액 취소.

    Args:
        payment_key: 토스 paymentKey
        cancel_reason: 취소 사유
        cancel_amount: 부분 취소 금액 (None이면 전액 취소)

    Returns:
        status, payment 포함 dict
    """
    response = {'status': 'failed', 'payment': None}

    result = _toss_cancel(payment_key, cancel_reason, cancel_amount)
    if not result:
        return response

    if 'code' in result:
        response['error_code'] = result.get('code')
        response['error_message'] = result.get('message')
        return response

    # 기존 결제 내역 업데이트
    payment = _update_payment_from_response(result)
    response['status'] = 'succeed'
    response['payment'] = payment.view() if payment else None
    return response


def get_toss_payment(payment_key: str) -> dict:
    """결제 조회

    토스 API에서 최신 상태를 조회하고 DB도 갱신.

    Args:
        payment_key: 토스 paymentKey

    Returns:
        status, payment 포함 dict
    """
    response = {'status': 'failed', 'payment': None}

    result = _toss_get(payment_key)
    if not result:
        return response

    if 'code' in result:
        response['error_code'] = result.get('code')
        response['error_message'] = result.get('message')
        return response

    payment = _update_payment_from_response(result)
    response['status'] = 'succeed'
    response['payment'] = payment.view() if payment else None
    return response



# ============================================================
# 토스 API 호출
# ============================================================

def _get_auth_header() -> dict:
    """토스 Basic Auth 헤더 생성: base64(secretKey + ':')"""
    credentials = base64.b64encode(f'{TOSS_SECRET_KEY}:'.encode()).decode()
    return {
        'Authorization': f'Basic {credentials}',
        'Content-Type': 'application/json',
    }


def _toss_confirm(payment_key: str, order_id: str, amount: float) -> Optional[dict]:
    """POST /v1/payments/confirm"""
    try:
        resp = requests.post(
            f'{TOSS_BASE_URL}/payments/confirm',
            headers=_get_auth_header(),
            json={
                'paymentKey': payment_key,
                'orderId': order_id,
                'amount': amount,
            },
            timeout=30,
        )
        return resp.json()
    except Exception as e:
        print(f'Toss confirm error: {e}')
        return None


def _toss_cancel(payment_key: str, cancel_reason: str, cancel_amount: float = None) -> Optional[dict]:
    """POST /v1/payments/{paymentKey}/cancel"""
    try:
        body = {'cancelReason': cancel_reason}
        if cancel_amount is not None:
            body['cancelAmount'] = cancel_amount

        resp = requests.post(
            f'{TOSS_BASE_URL}/payments/{payment_key}/cancel',
            headers=_get_auth_header(),
            json=body,
            timeout=30,
        )
        return resp.json()
    except Exception as e:
        print(f'Toss cancel error: {e}')
        return None


def _toss_get(payment_key: str) -> Optional[dict]:
    """GET /v1/payments/{paymentKey}"""
    try:
        resp = requests.get(
            f'{TOSS_BASE_URL}/payments/{payment_key}',
            headers=_get_auth_header(),
            timeout=10,
        )
        return resp.json()
    except Exception as e:
        print(f'Toss get error: {e}')
        return None


# ============================================================
# DB 저장/갱신
# ============================================================

def _save_payment(toss_response: dict, user_id: str) -> TossPayment:
    """토스 응답으로 TossPayment 생성"""
    payment = TossPayment(
        id=toss_response.get('paymentKey'),
        user_id=user_id,
        payment_key=toss_response.get('paymentKey'),
        order_id=toss_response.get('orderId'),
        order_name=toss_response.get('orderName', ''),
        status=toss_response.get('status', 'DONE'),
        method=toss_response.get('method'),
        currency=toss_response.get('currency', 'KRW'),
        total_amount=toss_response.get('totalAmount', 0),
        balance_amount=toss_response.get('balanceAmount', 0),
        supplied_amount=toss_response.get('suppliedAmount', 0),
        vat=toss_response.get('vat', 0),
        requested_at=toss_response.get('requestedAt'),
        approved_at=toss_response.get('approvedAt'),
        cancels=toss_response.get('cancels'),
        raw_response=toss_response,
    )
    payment.put()
    return payment


def _update_payment_from_response(toss_response: dict) -> Optional[TossPayment]:
    """토스 응답으로 기존 TossPayment 갱신"""
    payment_key = toss_response.get('paymentKey')
    if not payment_key:
        return None

    payment = TossPayment.get(payment_key)
    if not payment:
        # DB에 없으면 새로 생성 (user_id를 알 수 없으므로 빈값)
        return _save_payment(toss_response, user_id='')

    payment.status = toss_response.get('status', payment.status)
    payment.balance_amount = toss_response.get('balanceAmount', payment.balance_amount)
    payment.cancels = toss_response.get('cancels', payment.cancels)
    payment.raw_response = toss_response
    payment.update()
    return payment
