"""
Apple Sign-In 토큰 검증 서비스
"""
import jwt
import requests
from typing import Optional

# TODO: 실제 Apple Bundle ID로 교체
APPLE_BUNDLE_IDS = [
    'com.example.app',
    'com.example.app.dev',
]


class AppleUserInfo:
    """Apple 사용자 정보"""

    def __init__(self, sub: str, email: str = None, name: str = None):
        self.sub = sub  # Apple 고유 사용자 ID
        self.email = email
        self.name = name


# Apple 공개 키 캐시
_apple_public_keys = None


def _get_apple_public_keys():
    """Apple의 공개 키를 가져옵니다. JWT 검증에 사용."""
    global _apple_public_keys

    if _apple_public_keys is None:
        response = requests.get('https://appleid.apple.com/auth/keys', timeout=10)
        _apple_public_keys = response.json()

    return _apple_public_keys


def verify_apple_id_token(id_token: str, user_name: str = None) -> Optional[AppleUserInfo]:
    """
    Apple ID 토큰을 검증합니다.

    Apple Sign-In은 최초 로그인 시에만 이메일과 이름을 제공합니다.
    따라서 클라이언트에서 이름 정보를 별도로 전달받아야 합니다.

    :param id_token: Apple Sign-In에서 받은 Identity Token
    :param user_name: 클라이언트에서 전달받은 사용자 이름 (최초 로그인 시만 제공됨)
    :return: AppleUserInfo 또는 None (검증 실패 시)
    """
    try:
        # 토큰 헤더에서 key ID 추출
        unverified_header = jwt.get_unverified_header(id_token)
        kid = unverified_header.get('kid')

        if not kid:
            return None

        # Apple 공개 키 가져오기
        apple_keys = _get_apple_public_keys()

        # 일치하는 키 찾기
        public_key = None
        for key in apple_keys.get('keys', []):
            if key.get('kid') == kid:
                public_key = jwt.algorithms.RSAAlgorithm.from_jwk(key)
                break

        if not public_key:
            return None

        # 토큰 검증
        payload = jwt.decode(
            id_token,
            public_key,
            algorithms=['RS256'],
            audience=APPLE_BUNDLE_IDS,
            issuer='https://appleid.apple.com'
        )

        sub = payload.get('sub')
        if not sub:
            return None

        email = payload.get('email')

        return AppleUserInfo(
            sub=sub,
            email=email,
            name=user_name  # Apple은 이름을 토큰에 포함하지 않으므로 클라이언트에서 전달받음
        )

    except jwt.ExpiredSignatureError:
        print('Apple token expired')
        return None
    except jwt.InvalidTokenError as e:
        print(f'Apple token invalid: {e}')
        return None
    except Exception as e:
        print(f'Apple token verification error: {e}')
        return None
