"""
카카오 OAuth 토큰 검증 서비스
"""
import requests
from typing import Optional


class KakaoUserInfo:
    """카카오 사용자 정보"""

    def __init__(self, sub: str, email: str = None, name: str = None, profile_image: str = None):
        self.sub = sub  # 카카오 고유 사용자 ID
        self.email = email
        self.name = name
        self.profile_image = profile_image


def verify_kakao_access_token(access_token: str) -> Optional[KakaoUserInfo]:
    """
    카카오 Access 토큰으로 사용자 정보를 가져옵니다.

    카카오는 Access 토큰으로 사용자 정보 API를 호출하는 방식입니다.

    :param access_token: 카카오 OAuth에서 받은 Access 토큰
    :return: KakaoUserInfo 또는 None (검증 실패 시)
    """
    try:
        response = requests.get(
            'https://kapi.kakao.com/v2/user/me',
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=10
        )

        if response.status_code != 200:
            return None

        data = response.json()

        kakao_id = str(data.get('id'))
        if not kakao_id:
            return None

        kakao_account = data.get('kakao_account', {})
        profile = kakao_account.get('profile', {})

        email = kakao_account.get('email') if kakao_account.get('is_email_verified') else None

        return KakaoUserInfo(
            sub=kakao_id,
            email=email,
            name=profile.get('nickname', ''),
            profile_image=profile.get('profile_image_url')
        )

    except Exception as e:
        print(f'Kakao token verification error: {e}')
        return None
