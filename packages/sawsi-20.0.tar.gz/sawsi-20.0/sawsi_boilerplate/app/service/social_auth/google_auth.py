"""
Google OAuth 토큰 검증 서비스
"""
import requests
from typing import Optional
import api

GOOGLE_IOS_CLIENT_ID = api.secret_manager.get_secret_value('google_oauth_ios_client_id')
GOOGLE_ANDROID_CLIENT_ID = api.secret_manager.get_secret_value('google_oauth_android_client_id')
GOOGLE_WEB_CLIENT_ID = api.secret_manager.get_secret_value('google_oauth_web_client_id')


class GoogleUserInfo:
    """Google 사용자 정보"""

    def __init__(self, sub: str, email: str, name: str, picture: str = None):
        self.sub = sub  # Google 고유 사용자 ID
        self.email = email
        self.name = name
        self.picture = picture


def verify_google_id_token(id_token: str) -> Optional[GoogleUserInfo]:
    """
    Google ID 토큰을 검증합니다.

    :param id_token: Google Sign-In에서 받은 ID 토큰
    :return: GoogleUserInfo 또는 None (검증 실패 시)
    """
    try:
        response = requests.get(
            f'https://oauth2.googleapis.com/tokeninfo?id_token={id_token}',
            timeout=10
        )

        if response.status_code != 200:
            return None

        payload = response.json()

        # audience(aud) 검증 - 우리 앱의 Client ID와 일치해야 함
        aud = payload.get('aud')
        valid_client_ids = [GOOGLE_IOS_CLIENT_ID, GOOGLE_ANDROID_CLIENT_ID, GOOGLE_WEB_CLIENT_ID]
        if aud not in valid_client_ids:
            return None

        # 이메일 인증 여부 확인
        if payload.get('email_verified') != 'true':
            return None

        return GoogleUserInfo(
            sub=payload.get('sub'),
            email=payload.get('email'),
            name=payload.get('name', ''),
            picture=payload.get('picture')
        )

    except Exception as e:
        print(f'Google token verification error: {e}')
        return None


def verify_google_access_token(access_token: str) -> Optional[GoogleUserInfo]:
    """
    Google Access 토큰으로 사용자 정보를 가져옵니다. (백업 방식)

    :param access_token: Google OAuth에서 받은 Access 토큰
    :return: GoogleUserInfo 또는 None (검증 실패 시)
    """
    try:
        response = requests.get(
            'https://www.googleapis.com/oauth2/v2/userinfo',
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=10
        )

        if response.status_code != 200:
            return None

        payload = response.json()

        return GoogleUserInfo(
            sub=payload.get('id'),
            email=payload.get('email'),
            name=payload.get('name', ''),
            picture=payload.get('picture')
        )

    except Exception as e:
        print(f'Google access token verification error: {e}')
        return None
