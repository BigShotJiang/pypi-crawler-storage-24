import time
from typing import Optional
from sawsi.model.base import DynamoModel, sync
import api


@sync
class AppleRevocation(DynamoModel):
    """Apple 환불 내역"""
    __dynamo__ = api.dynamo
    _table = 'apple_revocation'
    _indexes = []

    original_transaction_id: str
    product_id: Optional[str] = None
    revocation_reason: Optional[int] = None
    revocation_date: Optional[int] = None
    raw_transaction: Optional[dict] = None
    environment: Optional[str] = None


@sync
class AppleSubscription(DynamoModel):
    """Apple 인앱 구독 상태"""
    __dynamo__ = api.dynamo
    _table = 'apple_subscription'
    _indexes = [
        ('user_id', 'crt'),
        ('original_transaction_id', 'crt'),
    ]

    user_id: str

    # 구독 상태
    product_id: str
    original_transaction_id: str
    transaction_id: str
    purchase_date_ms: int
    expires_date_ms: int

    # 혜택 상태
    is_trial_period: bool = False
    is_intro_offer: bool = False

    # 자동 갱신 관련
    auto_renew_status: int = -1  # 1: ON, 0: OFF, -1: UNKNOWN
    auto_renew_product_id: str = ''
    is_in_billing_retry: bool = False

    # 영수증 원본
    raw_receipt_json: Optional[dict] = None
    environment: str = 'Production'

    def is_active(self) -> bool:
        if self.is_refunded():
            return False
        now_ms = time.time() * 1000
        return self.expires_date_ms > now_ms

    def is_refunded(self) -> bool:
        revocation = AppleRevocation.get(self.original_transaction_id)
        return revocation is not None

    def view(self) -> dict:
        return {
            'id': self.id,
            'user_id': self.user_id,
            'product_id': self.product_id,
            'is_active': self.is_active(),
            'purchase_date_ms': self.purchase_date_ms,
            'expires_date_ms': self.expires_date_ms,
            'auto_renew_status': self.auto_renew_status,
            'environment': self.environment,
        }
