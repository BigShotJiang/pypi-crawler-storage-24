import api
from sawsi.model.base import DynamoModel, sync
from typing import Optional
from pydantic import fields, BaseModel
from secrets import token_urlsafe


class DeviceInfo(BaseModel):
    build_number: Optional[str] = None
    deviceName: Optional[str] = None

    version: Optional[str] = None
    platform_os: Optional[str] = None
    platform_version: Optional[str] = None
    language: Optional[str] = 'ko'


@sync
class UserSession(DynamoModel):
    __dynamo__ = api.dynamo
    _table = 'user_session'
    _indexes = [
        ('user_id', 'crt')
    ]
    id: str
    user_id: str
    source_ip: str
    device_info: Optional[DeviceInfo] = fields.Field(default_factory=DeviceInfo)

    # 보안 기능 추가 2025.12.22
    use_secure: bool = False
    otp_secret: Optional[str] = fields.Field(
        default_factory=lambda: token_urlsafe(32))  # UUID4 기반의 OTP 코드 (클라이언트와 서버가 같은 값을 공유하고 timestamp 기준으로 15초 윈도우 사용)
    # md5(timestamp + otp_secret) 한 값이 클라이언트에서 보낸 oc 값과 일치해야함. (otp_code)
    ts_offset: int = 0  # 클라이언트 사이드의 타임스탬프 차이 서버시간 - 클라시간
