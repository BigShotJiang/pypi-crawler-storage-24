import time
import uuid
from typing import Optional
from pydantic import fields
from sawsi.model.base import DynamoModel, sync
import api


@sync
class TossBillingKey(DynamoModel):
    """토스페이먼츠 빌링키 (자동결제용 카드 등록 정보)"""
    __dynamo__ = api.dynamo
    _table = 'toss_billing_key'
    _indexes = [
        ('user_id', 'crt'),
    ]

    id: str = fields.Field(default_factory=lambda: str(uuid.uuid4()))
    crt: float = fields.Field(default_factory=time.time)
    user_id: str

    billing_key: str  # 토스 billingKey
    customer_key: str  # 가맹점 고객 키

    # 카드 정보
    card_company: Optional[str] = None  # 카드사
    card_number: Optional[str] = None  # 마스킹된 카드번호
    card_type: Optional[str] = None  # 신용, 체크

    is_active: bool = True  # 삭제 시 False

    def view(self) -> dict:
        return {
            'id': self.id,
            'user_id': self.user_id,
            'billing_key': self.billing_key,
            'card_company': self.card_company,
            'card_number': self.card_number,
            'card_type': self.card_type,
            'is_active': self.is_active,
            'crt': self.crt,
        }


@sync
class TossSubscription(DynamoModel):
    """토스페이먼츠 정기결제 구독"""
    __dynamo__ = api.dynamo
    _table = 'toss_subscription'
    _indexes = [
        ('user_id', 'crt'),
        ('product_id', 'crt'),
    ]

    id: str = fields.Field(default_factory=lambda: str(uuid.uuid4()))
    crt: float = fields.Field(default_factory=time.time)
    user_id: str

    # 구독 식별
    product_id: str  # 구독 상품 ID
    product_name: str = ''
    billing_key: str  # 결제에 사용할 빌링키
    customer_key: str = ''  # 빌링키 발급 시 사용한 가맹점 고객 키

    # 결제 정보
    amount: float = 0
    currency: str = 'KRW'
    interval: str = 'MONTHLY'  # MONTHLY, YEARLY

    # 구독 상태: ACTIVE, CANCELED, EXPIRED, PAYMENT_FAILED
    status: str = 'ACTIVE'

    # 구독 기간
    current_period_start: Optional[float] = None  # unix timestamp
    current_period_end: Optional[float] = None  # unix timestamp
    canceled_at: Optional[float] = None

    # 최근 결제
    last_payment_key: Optional[str] = None
    last_paid_at: Optional[float] = None

    def is_active(self) -> bool:
        if self.status != 'ACTIVE':
            return False
        if self.current_period_end and time.time() > self.current_period_end:
            return False
        return True

    def view(self) -> dict:
        return {
            'id': self.id,
            'user_id': self.user_id,
            'product_id': self.product_id,
            'product_name': self.product_name,
            'amount': self.amount,
            'currency': self.currency,
            'interval': self.interval,
            'status': self.status,
            'is_active': self.is_active(),
            'current_period_start': self.current_period_start,
            'current_period_end': self.current_period_end,
            'canceled_at': self.canceled_at,
            'last_paid_at': self.last_paid_at,
            'crt': self.crt,
        }
