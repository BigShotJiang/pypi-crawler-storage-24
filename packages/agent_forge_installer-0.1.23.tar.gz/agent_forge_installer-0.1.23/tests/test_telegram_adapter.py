from __future__ import annotations

import queue
import threading

from agentforge.claude_runner import InvokeResult, PlanResult
from agentforge.telegram_adapter import ClawdiaBot


class _DummyQueue:
    def __init__(self) -> None:
        self.done_calls = 0

    def task_done(self) -> None:
        self.done_calls += 1


def _make_bot() -> ClawdiaBot:
    bot = object.__new__(ClawdiaBot)
    bot.config = {
        "memory": {"context_messages": 5},
        "telegram": {"max_message_length": 4096},
    }
    bot.bot_name = "clawdia"
    bot._get_recent_messages = lambda *args, **kwargs: []
    bot._save_usage = lambda *args, **kwargs: None
    bot._save_message = lambda *args, **kwargs: None
    bot._log_action = lambda *args, **kwargs: None
    bot._save_pending_retry = lambda *args, **kwargs: None
    bot._handle_worker_error = ClawdiaBot._handle_worker_error.__get__(bot, ClawdiaBot)
    return bot


def test_worker_plan_mode_notifies_background_start(monkeypatch) -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    enqueued: list[dict] = []
    stop_event = threading.Event()
    task_queue: queue.Queue = queue.Queue()

    monkeypatch.setattr(
        "agentforge.telegram_adapter.invoke_claude_plan",
        lambda **kwargs: PlanResult(
            is_plan=True,
            text="1. Do work",
            invoke_result=InvokeResult(text="[PLAN]\n1. Do work"),
        ),
    )

    bot._start_typing_loop = lambda *args, **kwargs: stop_event
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)
    bot._enqueue_task = lambda task: enqueued.append(task)

    task = {
        "session_id": "sess-1",
        "user_text": "please do it",
        "thread_cfg": {"name": "clawdia"},
        "chat_id": "chat",
        "thread_id": 123,
    }
    task_queue.put(task)
    task_queue.put(None)

    bot._worker("clawdia", task_queue)

    assert sent_messages == [
        "📋 *Plan d'exécution :*\n\n1. Do work",
        "⏳ Je travaille dessus en arrière-plan, je te reviens quand c'est terminé.",
    ]
    assert enqueued == [{**task, "_skip_plan_mode": True}]


def test_handle_worker_error_marks_background_execution_failure() -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    task_queue = _DummyQueue()
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)

    bot._handle_worker_error(
        RuntimeError("boom"),
        {"_skip_plan_mode": True},
        "chat",
        123,
        "clawdia",
        task_queue,
    )

    assert sent_messages == [
        "⚠️ *Exécution échouée :*\n\nSorry, I encountered an error. Please try again."
    ]
    assert task_queue.done_calls == 1
