"""Tests for agentforge.vault — structured memory vault."""

import os
import sqlite3
import sys
from argparse import Namespace
from pathlib import Path

import pytest

from agentforge import vault


@pytest.fixture(autouse=True)
def isolate_vault(tmp_root):
    """Point vault.DB_PATH to a temp location and init the schema."""
    db_path = tmp_root / "data" / "agent_vault.db"
    vault.DB_PATH = db_path
    vault.cmd_init(Namespace())
    yield db_path


def _write_entry(agent="archie", category="memory", title="test", content="test content",
                 tags="", source=""):
    args = Namespace(agent=agent, category=category, title=title,
                     content=content, tags=tags, source=source)
    vault.cmd_write(args)


class TestInit:
    def test_creates_db(self, isolate_vault):
        assert isolate_vault.exists()

    def test_idempotent(self, isolate_vault):
        vault.cmd_init(Namespace())  # should not raise


class TestWrite:
    def test_creates_entry(self, isolate_vault, capsys):
        _write_entry(content="Archie prefers opus model")
        out = capsys.readouterr().out
        assert "ID: 1" in out

    def test_multiple_entries(self, isolate_vault, capsys):
        _write_entry(content="first")
        _write_entry(content="second")
        out = capsys.readouterr().out
        assert "ID: 2" in out


class TestRead:
    def test_read_existing(self, isolate_vault, capsys):
        _write_entry(content="readable content", title="My Title")
        capsys.readouterr()  # clear write output

        vault.cmd_read(Namespace(id=1))
        out = capsys.readouterr().out
        assert "readable content" in out
        assert "My Title" in out

    def test_read_nonexistent(self, isolate_vault):
        with pytest.raises(SystemExit):
            vault.cmd_read(Namespace(id=999))


class TestSearch:
    def test_finds_match(self, isolate_vault, capsys):
        _write_entry(content="Martin prefers dark mode", title="UI preference")
        _write_entry(content="Victor uses sonnet model", title="Model config")
        capsys.readouterr()

        vault.cmd_search(Namespace(query="dark mode", agent=None, category=None, limit=10))
        out = capsys.readouterr().out
        assert "dark mode" in out.lower()
        assert "1 résultat" in out

    def test_no_results(self, isolate_vault, capsys):
        vault.cmd_search(Namespace(query="nonexistent_xyz", agent=None, category=None, limit=10))
        out = capsys.readouterr().out
        assert "Aucun résultat" in out

    def test_filter_by_agent(self, isolate_vault, capsys):
        _write_entry(agent="archie", content="archie fact")
        _write_entry(agent="clawdia", content="clawdia fact something")
        capsys.readouterr()

        vault.cmd_search(Namespace(query="fact", agent="archie", category=None, limit=10))
        out = capsys.readouterr().out
        assert "archie" in out
        assert "1 résultat" in out


class TestList:
    def test_list_all(self, isolate_vault, capsys):
        _write_entry(content="one")
        _write_entry(content="two")
        capsys.readouterr()

        vault.cmd_list(Namespace(agent=None, category=None, limit=20))
        out = capsys.readouterr().out
        assert "2 entrée(s)" in out

    def test_list_empty(self, isolate_vault, capsys):
        vault.cmd_list(Namespace(agent=None, category=None, limit=20))
        out = capsys.readouterr().out
        assert "Aucune entrée" in out

    def test_filter_by_category(self, isolate_vault, capsys):
        _write_entry(category="memory", content="a memory")
        _write_entry(category="preference", content="a pref")
        capsys.readouterr()

        vault.cmd_list(Namespace(agent=None, category="preference", limit=20))
        out = capsys.readouterr().out
        assert "1 entrée(s)" in out


class TestUpdate:
    def test_update_content(self, isolate_vault, capsys):
        _write_entry(content="old content", title="Old Title")
        capsys.readouterr()

        vault.cmd_update(Namespace(id=1, title="New Title", content="new content",
                                   tags=None, category=None))
        capsys.readouterr()

        vault.cmd_read(Namespace(id=1))
        out = capsys.readouterr().out
        assert "New Title" in out
        assert "new content" in out

    def test_update_nonexistent(self, isolate_vault):
        with pytest.raises(SystemExit):
            vault.cmd_update(Namespace(id=999, title=None, content=None,
                                       tags=None, category=None))


class TestDelete:
    def test_soft_delete(self, isolate_vault, capsys):
        _write_entry(content="to be deleted")
        capsys.readouterr()

        vault.cmd_delete(Namespace(id=1))
        out = capsys.readouterr().out
        assert "supprimée" in out

        # Should not be readable anymore
        with pytest.raises(SystemExit):
            vault.cmd_read(Namespace(id=1))


class TestStats:
    def test_stats_output(self, isolate_vault, capsys):
        _write_entry(agent="archie", content="a")
        _write_entry(agent="clawdia", content="b")
        capsys.readouterr()

        vault.cmd_stats(Namespace())
        out = capsys.readouterr().out
        assert "2" in out
        assert "archie" in out
        assert "clawdia" in out
