"""Claude Code CLI invocation."""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

MONTREAL = ZoneInfo("America/Montreal")

# Pricing per token (USD) — updated 2026-03-23
# Short names (as used in config.json) and full model IDs both supported.
_MODEL_PRICING: dict[str, dict[str, float]] = {
    "claude-opus-4-6": {
        "input": 15.00 / 1_000_000,
        "output": 75.00 / 1_000_000,
        "cache_write": 18.75 / 1_000_000,
        "cache_read": 1.50 / 1_000_000,
    },
    "claude-sonnet-4-6": {
        "input": 3.00 / 1_000_000,
        "output": 15.00 / 1_000_000,
        "cache_write": 3.75 / 1_000_000,
        "cache_read": 0.30 / 1_000_000,
    },
    "claude-haiku-4-5": {
        "input": 0.80 / 1_000_000,
        "output": 4.00 / 1_000_000,
        "cache_write": 1.00 / 1_000_000,
        "cache_read": 0.08 / 1_000_000,
    },
    "claude-haiku-4-5-20251001": {
        "input": 0.80 / 1_000_000,
        "output": 4.00 / 1_000_000,
        "cache_write": 1.00 / 1_000_000,
        "cache_read": 0.08 / 1_000_000,
    },
}
# Short aliases used in config.json ("sonnet", "opus", "haiku")
_MODEL_PRICING["sonnet"] = _MODEL_PRICING["claude-sonnet-4-6"]
_MODEL_PRICING["opus"] = _MODEL_PRICING["claude-opus-4-6"]
_MODEL_PRICING["haiku"] = _MODEL_PRICING["claude-haiku-4-5"]

_DEFAULT_PRICING = _MODEL_PRICING["claude-sonnet-4-6"]


@dataclass
class InvokeResult:
    """Result from a Claude CLI invocation."""

    text: str
    cost_usd: float | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    cache_write_tokens: int | None = None
    cache_read_tokens: int | None = None
    model: str | None = None


@dataclass
class PlanResult:
    """Result from a plan-mode invocation (first pass, no tools)."""

    is_plan: bool
    text: str
    invoke_result: InvokeResult


def _calc_cost(usage: dict, model: str) -> float:
    pricing = _MODEL_PRICING.get(model, _DEFAULT_PRICING)
    return (
        usage.get("input_tokens", 0) * pricing["input"]
        + usage.get("output_tokens", 0) * pricing["output"]
        + usage.get("cache_creation_input_tokens", 0) * pricing["cache_write"]
        + usage.get("cache_read_input_tokens", 0) * pricing["cache_read"]
    )

# Matches ccusage / Claude Code JSONL field name (see npm package ccusage).
_USAGE_LIMIT_RESET_MS_RE = re.compile(
    r'usageLimitResetTime["\']?\s*:\s*(\d{10,16})\b', re.IGNORECASE
)
_USAGE_LIMIT_RESET_SNAKE_RE = re.compile(
    r"usage_limit_reset_time\s*[:=]\s*(\d{10,16})\b", re.IGNORECASE
)
_RETRY_AFTER_SEC_RE = re.compile(
    r"(?:retry-after|retry_after)[\"']?\s*[:=]\s*[\"']?(\d+)\b", re.IGNORECASE
)
_ISO_Z_RE = re.compile(
    r"\b(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z)\b"
)


class RateLimitError(Exception):
    def __init__(self, retry_after_seconds: int = 3600):
        self.retry_after_seconds = retry_after_seconds


class ClaudeCodeLimitError(Exception):
    """Claude Code subscription usage limit reached (weekly/session cap)."""

    def __init__(self, *, restore_at: datetime | None = None) -> None:
        self.restore_at = restore_at
        if restore_at is not None and restore_at.tzinfo is None:
            raise ValueError("restore_at must be timezone-aware")


def _epoch_ms_or_s_to_utc(value: int) -> datetime:
    """Interpret Claude/ccusage timestamps (seconds or milliseconds since epoch)."""
    if value >= 10**12:
        sec = value / 1000.0
    else:
        sec = float(value)
    return datetime.fromtimestamp(sec, tz=timezone.utc)


def parse_retry_after_seconds(raw: str) -> int | None:
    """Parse Retry-After style delay in seconds from CLI output."""
    m = _RETRY_AFTER_SEC_RE.search(raw)
    if not m:
        return None
    sec = int(m.group(1))
    return sec if sec > 0 else None


def parse_quota_restore_at(raw: str) -> datetime | None:
    """
    Best-effort reset time from Claude Code / Anthropic stderr or stdout.

    Aligns with fields analyzed by ccusage (npm `ccusage`), e.g. usageLimitResetTime
    in local JSONL; the CLI sometimes echoes similar JSON.
    """
    if not raw:
        return None
    for pattern in (_USAGE_LIMIT_RESET_MS_RE, _USAGE_LIMIT_RESET_SNAKE_RE):
        m = pattern.search(raw)
        if m:
            try:
                return _epoch_ms_or_s_to_utc(int(m.group(1)))
            except (OSError, OverflowError, ValueError):
                pass
    for m in _ISO_Z_RE.finditer(raw):
        try:
            return datetime.fromisoformat(m.group(1).replace("Z", "+00:00"))
        except ValueError:
            continue
    return None


def format_claude_code_limit_user_message(
    restore_at: datetime | None,
    *,
    tz: ZoneInfo = MONTREAL,
) -> str:
    """User-facing text when Claude Code quota / subscription usage cap is hit."""
    if restore_at is not None:
        local = restore_at.astimezone(tz)
        label = local.tzname() or str(local.utcoffset() or "")
        return (
            f"Claude Code quota reached. Restore at {local:%Y-%m-%d %H:%M} {label}."
        )
    return (
        "Claude Code quota reached. No exact reset time was in the CLI output. "
        "Claude Code uses rolling windows (see 5-hour blocks in "
        "https://www.npmjs.com/package/ccusage — `npx ccusage@latest blocks`). "
        "Try again after your current window ends."
    )


def format_rate_limit_user_message(retry_after_seconds: int, *, tz: ZoneInfo = MONTREAL) -> str:
    when = datetime.now(tz) + timedelta(seconds=retry_after_seconds)
    label = when.tzname() or str(when.utcoffset() or "")
    return f"Anthropic rate limit reached. Retry around {when:%H:%M} {label}."


GENERIC_CLAUDE_INVOCATION_ERROR = "Sorry, I encountered an error. Please try again."

DAILY_NOTE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}\.md$")
MAX_CONTEXT_SECTION_CHARS = 8_000


def _resolve_context_base(root: str, thread_name: str) -> Path | None:
    if not thread_name:
        return None
    return Path(root) / "agents" / thread_name


def _read_optional_text(path: Path) -> str | None:
    try:
        text = path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        logging.debug("Skipping unreadable context file %s: %s", path, exc)
        return None
    if len(text) > MAX_CONTEXT_SECTION_CHARS:
        logging.debug(
            "Truncating context file %s from %s to %s characters",
            path,
            len(text),
            MAX_CONTEXT_SECTION_CHARS,
        )
        text = text[:MAX_CONTEXT_SECTION_CHARS].rstrip()
    return text or None


def _latest_daily_note_path(base_dir: Path) -> Path | None:
    daily_dir = base_dir / "daily"
    if not daily_dir.is_dir():
        return None

    candidates = sorted(
        path for path in daily_dir.glob("*.md") if DAILY_NOTE_RE.match(path.name)
    )
    return candidates[-1] if candidates else None


def _build_system_prompt_context(root: str, thread_name: str) -> str | None:
    sections: list[str] = []
    for path in (Path(root) / "CLAUDE.md", Path(root) / "CLAUDE.local.md"):
        content = _read_optional_text(path)
        if content:
            sections.append(content)

    base_dir = _resolve_context_base(root, thread_name)
    if base_dir is None:
        return "\n\n".join(sections) if sections else None

    for label, path in (
        ("Soul", base_dir / "soul.md"),
        ("Tasks", base_dir / "tasks.md"),
        ("Memory", base_dir / "memory.md"),
        ("Latest Daily Note", _latest_daily_note_path(base_dir)),
    ):
        if path is None:
            continue
        content = _read_optional_text(path)
        if content:
            sections.append(f"## {label}\n{content}")

    return "\n\n".join(sections) if sections else None


def invoke_claude(
    *,
    session_id: str,
    user_text: str,
    thread_cfg: dict,
    config: dict,
    recent_messages: list[tuple[str, str, str]],
    root: str,
) -> InvokeResult:
    """
    Invoke Claude Code CLI and return the response as an InvokeResult.

    Args:
        session_id: Conversation session identifier
        user_text: The user's message
        thread_cfg: Thread/agent config dict
        config: Full bot config
        recent_messages: List of (role, content, timestamp) tuples
        root: AGENTFORGE_ROOT path

    Returns:
        InvokeResult with text, cost_usd, and token counts

    Raises:
        RateLimitError: If Anthropic rate limit hit
        ClaudeCodeLimitError: If Claude Code subscription limit reached
    """
    model = thread_cfg.get("model", config["claude"]["model"])
    thread_name = thread_cfg.get("name", "")

    # Determine display name for this agent's history
    agent_display_name = (
        thread_name.capitalize()
        if thread_name and thread_name != "clawdia"
        else "Clawdia"
    )

    # Format conversation history
    history_lines = []
    for role, content, ts in recent_messages:
        prefix = "User" if role == "user" else agent_display_name
        history_lines.append(f"[{ts}] {prefix}: {content}")

    history_text = "\n".join(history_lines) if history_lines else "(No prior messages)"

    # Build the full prompt
    topic_context = thread_cfg.get("topic_context", "")
    topic_section = f"\n## Contexte du topic\n{topic_context}\n" if topic_context else ""
    prompt = f"""## Recent Conversation
{history_text}
{topic_section}
## Current Message
User: {user_text}

Respond to the user's current message. Be concise."""

    # Build claude command
    cfg = config["claude"]
    cmd = [
        str(Path(root) / ".local" / "bin" / "claude"),
        "-p",
        "--model", model,
        "--dangerously-skip-permissions",
        "--output-format", "json",
    ]

    system_prompt = _build_system_prompt_context(root, thread_name)
    if system_prompt:
        cmd += ["--system-prompt", system_prompt]

    if cfg.get("max_budget_usd"):
        cmd += ["--max-budget-usd", str(cfg["max_budget_usd"])]

    cmd.append(prompt)

    runner_env = {**os.environ}
    original_home = runner_env.get("HOME", "")
    if not runner_env.get("GH_CONFIG_DIR") and original_home:
        runner_env["GH_CONFIG_DIR"] = str(Path(original_home) / ".config" / "gh")
    runner_env["HOME"] = root
    runner_env["PATH"] = f"{root}/.local/bin:" + runner_env.get("PATH", "/usr/bin:/bin")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=1800,  # 30 minutes
            cwd=root,
            env=runner_env,
        )
        if result.returncode != 0:
            stderr = (result.stderr or "").strip()
            stdout = (result.stdout or "").strip()
            raw_for_parse = f"{stderr}\n{stdout}".strip()
            combined = raw_for_parse.lower()
            logging.error(
                f"Claude error (rc={result.returncode}): "
                f"stderr={stderr[:300]} stdout={stdout[:300]}"
            )
            # Claude Code subscription/session usage limit (ccusage models 5h billing windows;
            # see https://www.npmjs.com/package/ccusage — usageLimitResetTime in JSONL).
            claude_code_limit_signals = [
                "usage limit",
                "claude code limit",
                "subscription limit",
                "usage cap",
                "limit reached",
                "claude pro",
                "out of credits",
                "weekly usage",
                "exceeded your usage",
                "credit balance",
                "not enough credits",
                "session limit",
                "usage for claude",
                "claude code quota",
                "billing cycle",
            ]
            if any(kw in combined for kw in claude_code_limit_signals):
                logging.warning("Claude Code usage limit detected")
                restore_at = parse_quota_restore_at(raw_for_parse)
                raise ClaudeCodeLimitError(restore_at=restore_at)
            # rc=1 with empty stderr/stdout = most likely Claude Code limit
            if result.returncode == 1 and not stderr and not stdout:
                logging.warning("Claude Code rc=1 with no output — treating as usage limit")
                raise ClaudeCodeLimitError(restore_at=None)
            # Anthropic API rate limit
            rate_limit_signals = [
                "rate limit",
                "429",
                "quota exceeded",
                "overloaded",
                "too many requests",
            ]
            if any(kw in combined for kw in rate_limit_signals):
                logging.warning(f"Claude rate limited: {combined[:200]}")
                retry_sec = parse_retry_after_seconds(raw_for_parse) or 3600
                raise RateLimitError(retry_after_seconds=retry_sec)
            return InvokeResult(text=GENERIC_CLAUDE_INVOCATION_ERROR, model=model)

        # Parse JSON output to extract text and usage data
        raw_stdout = result.stdout.strip()
        if not raw_stdout:
            return InvokeResult(
                text="I processed your message but had no output. Try rephrasing?",
                model=model,
            )

        response_text = raw_stdout
        cost_usd: float | None = None
        input_tokens: int | None = None
        output_tokens: int | None = None
        cache_write_tokens: int | None = None
        cache_read_tokens: int | None = None

        try:
            parsed = json.loads(raw_stdout)
            response_text = parsed.get("result") or parsed.get("text") or raw_stdout
            if not response_text:
                response_text = "I processed your message but had no output. Try rephrasing?"
            usage = parsed.get("usage") or {}
            if usage:
                input_tokens = usage.get("input_tokens")
                output_tokens = usage.get("output_tokens")
                cache_write_tokens = usage.get("cache_creation_input_tokens")
                cache_read_tokens = usage.get("cache_read_input_tokens")
                cost_usd = parsed.get("cost_usd") or _calc_cost(usage, model)
        except (json.JSONDecodeError, AttributeError):
            logging.debug("Claude output was not JSON — using raw stdout as text")
            response_text = raw_stdout

        return InvokeResult(
            text=response_text,
            cost_usd=cost_usd,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_write_tokens=cache_write_tokens,
            cache_read_tokens=cache_read_tokens,
            model=model,
        )
    except subprocess.TimeoutExpired:
        logging.error("Claude timed out after 30 minutes")
        return InvokeResult(
            text=(
                "Désolée, cette tâche a pris trop longtemps (>30 min). "
                "Essaie de la découper en étapes plus courtes."
            ),
            model=model,
        )
    except (RateLimitError, ClaudeCodeLimitError):
        raise
    except Exception as e:
        logging.error(f"Failed to invoke Claude: {e}", exc_info=True)
        return InvokeResult(text="Sorry, something went wrong. Please try again later.", model=model)


_PLAN_MODE_SUFFIX = """

IMPORTANT — Response format:
You MUST prefix your response with exactly one of these tags on the first line:
- [REPLY] if you can answer fully with text only (no file edits, no shell commands, no tool use needed).
- [PLAN] if the request requires actions (creating/editing files, running commands, making API calls, etc.).

If [REPLY]: write your response directly after the tag.
If [PLAN]: describe what you would do as a numbered list of steps. Be specific about which files, commands, or actions. Do NOT execute anything — only describe the plan."""


def _parse_plan_response(text: str) -> tuple[bool, str]:
    """Parse a plan-mode response. Returns (is_plan, cleaned_text)."""
    stripped = text.strip()
    if stripped.startswith("[PLAN]"):
        return True, stripped[6:].strip()
    if stripped.startswith("[REPLY]"):
        return False, stripped[7:].strip()
    # Fallback: if it contains action-like language, treat as plan
    return False, stripped


def invoke_claude_plan(
    *,
    session_id: str,
    user_text: str,
    thread_cfg: dict,
    config: dict,
    recent_messages: list[tuple[str, str, str]],
    root: str,
) -> PlanResult:
    """First-pass invocation with no tools — classifies as reply or plan.

    Uses ``--allowedTools ""`` so Claude cannot execute anything.
    The system prompt instructs Claude to prefix with [REPLY] or [PLAN].

    Returns a PlanResult with is_plan flag and the text.
    Raises the same errors as invoke_claude.
    """
    model = thread_cfg.get("model", config["claude"]["model"])
    thread_name = thread_cfg.get("name", "")

    agent_display_name = (
        thread_name.capitalize()
        if thread_name and thread_name != "clawdia"
        else "Clawdia"
    )

    history_lines = []
    for role, content, ts in recent_messages:
        prefix = "User" if role == "user" else agent_display_name
        history_lines.append(f"[{ts}] {prefix}: {content}")

    history_text = "\n".join(history_lines) if history_lines else "(No prior messages)"

    topic_context = thread_cfg.get("topic_context", "")
    topic_section = f"\n## Contexte du topic\n{topic_context}\n" if topic_context else ""
    prompt = f"""## Recent Conversation
{history_text}
{topic_section}
## Current Message
User: {user_text}

Respond to the user's current message. Be concise.{_PLAN_MODE_SUFFIX}"""

    cfg = config["claude"]
    cmd = [
        str(Path(root) / ".local" / "bin" / "claude"),
        "-p",
        "--model", model,
        "--dangerously-skip-permissions",
        "--output-format", "json",
        "--allowedTools", "",
    ]

    system_prompt = _build_system_prompt_context(root, thread_name)
    if system_prompt:
        cmd += ["--system-prompt", system_prompt]

    # No budget needed — plan mode is text-only, very cheap
    cmd.append(prompt)

    runner_env = {**os.environ}
    original_home = runner_env.get("HOME", "")
    if not runner_env.get("GH_CONFIG_DIR") and original_home:
        runner_env["GH_CONFIG_DIR"] = str(Path(original_home) / ".config" / "gh")
    runner_env["HOME"] = root
    runner_env["PATH"] = f"{root}/.local/bin:" + runner_env.get("PATH", "/usr/bin:/bin")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,  # Plan mode should be fast — 2 min max
            cwd=root,
            env=runner_env,
        )
        if result.returncode != 0:
            stderr = (result.stderr or "").strip()
            stdout = (result.stdout or "").strip()
            raw_for_parse = f"{stderr}\n{stdout}".strip()
            combined = raw_for_parse.lower()
            logging.error(
                f"Claude plan-mode error (rc={result.returncode}): "
                f"stderr={stderr[:300]} stdout={stdout[:300]}"
            )
            claude_code_limit_signals = [
                "usage limit", "claude code limit", "subscription limit",
                "usage cap", "limit reached", "claude pro", "out of credits",
                "weekly usage", "exceeded your usage", "credit balance",
                "not enough credits", "session limit", "usage for claude",
                "claude code quota", "billing cycle",
            ]
            if any(kw in combined for kw in claude_code_limit_signals):
                restore_at = parse_quota_restore_at(raw_for_parse)
                raise ClaudeCodeLimitError(restore_at=restore_at)
            if result.returncode == 1 and not stderr and not stdout:
                raise ClaudeCodeLimitError(restore_at=None)
            rate_limit_signals = [
                "rate limit", "429", "quota exceeded", "overloaded", "too many requests",
            ]
            if any(kw in combined for kw in rate_limit_signals):
                retry_sec = parse_retry_after_seconds(raw_for_parse) or 3600
                raise RateLimitError(retry_after_seconds=retry_sec)
            ir = InvokeResult(text=GENERIC_CLAUDE_INVOCATION_ERROR, model=model)
            return PlanResult(is_plan=False, text=ir.text, invoke_result=ir)

        raw_stdout = result.stdout.strip()
        if not raw_stdout:
            ir = InvokeResult(
                text="I processed your message but had no output. Try rephrasing?",
                model=model,
            )
            return PlanResult(is_plan=False, text=ir.text, invoke_result=ir)

        response_text = raw_stdout
        cost_usd: float | None = None
        input_tokens: int | None = None
        output_tokens: int | None = None
        cache_write_tokens: int | None = None
        cache_read_tokens: int | None = None

        try:
            parsed = json.loads(raw_stdout)
            response_text = parsed.get("result") or parsed.get("text") or raw_stdout
            if not response_text:
                response_text = "I processed your message but had no output. Try rephrasing?"
            usage = parsed.get("usage") or {}
            if usage:
                input_tokens = usage.get("input_tokens")
                output_tokens = usage.get("output_tokens")
                cache_write_tokens = usage.get("cache_creation_input_tokens")
                cache_read_tokens = usage.get("cache_read_input_tokens")
                cost_usd = parsed.get("cost_usd") or _calc_cost(usage, model)
        except (json.JSONDecodeError, AttributeError):
            pass

        is_plan, cleaned = _parse_plan_response(response_text)
        ir = InvokeResult(
            text=cleaned,
            cost_usd=cost_usd,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_write_tokens=cache_write_tokens,
            cache_read_tokens=cache_read_tokens,
            model=model,
        )
        return PlanResult(is_plan=is_plan, text=cleaned, invoke_result=ir)

    except subprocess.TimeoutExpired:
        logging.error("Claude plan-mode timed out after 2 minutes")
        ir = InvokeResult(text=GENERIC_CLAUDE_INVOCATION_ERROR, model=model)
        return PlanResult(is_plan=False, text=ir.text, invoke_result=ir)
    except (RateLimitError, ClaudeCodeLimitError):
        raise
    except Exception as e:
        logging.error(f"Failed to invoke Claude plan-mode: {e}", exc_info=True)
        ir = InvokeResult(text="Sorry, something went wrong. Please try again later.", model=model)
        return PlanResult(is_plan=False, text=ir.text, invoke_result=ir)
