"""Agent management commands: create, list, remove."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

SOUL_TEMPLATE = """\
# IDENTITY OVERRIDE
You are {name_cap}. Your name is {name_cap}.

## Identity
- Name: {name_cap}
- Role: (describe this agent's role)

## Personality
- (describe personality traits)

## Language
- Technical English by default
- Switches to French if the user writes in French

## Principles
- (list guiding principles)

## Execution Mode
- Respond directly in the console (the telegram_adapter handles sending to Telegram).
- Never call `telegram_send.sh` for your main reply — that would cause duplicates.
- Use the shared `git-repos/` folder at the AgentForge root for repository clones and collaborative code work.

## Tasks
- Read `/agents/{name}/tasks.md` for recurring task instructions and rules

## Memory
- Read `/agents/{name}/memory.md` at the start of each session
- Write daily learnings to `/agents/{name}/daily/YYYY-MM-DD.md`
"""


def _resolve_root() -> Path:
    return Path(os.environ.get("AGENTFORGE_ROOT", "/home/clawdia"))


def _load_config(config_path: str | None = None) -> tuple[dict, Path]:
    """Load config.json and return (data, path)."""
    if config_path:
        p = Path(config_path)
    else:
        p = _resolve_root() / "bot" / "config.json"
    if not p.exists():
        print(f"Error: config not found at {p}")
        sys.exit(1)
    data = json.loads(p.read_text())
    return data, p


def _save_config(data: dict, path: Path) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def agent_create(
    name: str,
    *,
    model: str = "sonnet",
    thread_id: int | None = None,
    config_path: str | None = None,
) -> None:
    """Create a new agent: scaffold files + update config.json."""
    name = name.lower().strip()
    if not name.isalpha():
        print(f"Error: agent name must be alphabetic, got '{name}'")
        sys.exit(1)

    root = _resolve_root()
    agent_dir = root / "agents" / name
    shared_git_repos_dir = root / "git-repos"
    shared_git_repos_dir.mkdir(parents=True, exist_ok=True)

    # 1. Create agent directory structure
    if agent_dir.exists():
        print(f"Warning: agent directory already exists at {agent_dir}")
    else:
        agent_dir.mkdir(parents=True, exist_ok=True)
        (agent_dir / "daily").mkdir(exist_ok=True)
        (agent_dir / "plans").mkdir(exist_ok=True)

        # soul.md
        soul = SOUL_TEMPLATE.format(name=name, name_cap=name.capitalize())
        (agent_dir / "soul.md").write_text(soul)

        # memory.md
        (agent_dir / "memory.md").write_text(
            f"# Mémoire de {name.capitalize()}\n\n"
            "Faits et apprentissages accumulés au fil du temps.\n"
            "Mis à jour automatiquement par le cron de consolidation (dimanche 23h).\n"
            "Ne pas modifier manuellement — le cron consolide depuis les fichiers daily/.\n\n"
            "---\n"
        )

        # tasks.md
        (agent_dir / "tasks.md").write_text(
            f"# Tasks: {name.capitalize()}\n\n"
            "Recurring tasks, rules, and mission instructions for this agent.\n"
            "Add task definitions here as they are assigned.\n"
        )
        print(f"✅ Created agent files at {agent_dir}/")

    # 2. Update config.json if thread_id provided
    if thread_id is not None:
        config, config_path_resolved = _load_config(config_path)
        tid_str = str(thread_id)

        if tid_str in config.get("threads", {}):
            existing = config["threads"][tid_str].get("name", "unknown")
            print(f"Warning: thread {thread_id} already assigned to '{existing}'. Overwriting.")

        config.setdefault("threads", {})[tid_str] = {
            "name": name,
            "model": model,
            "context_messages": 10,
        }

        # Also add to telegram.topics for convenience
        config.setdefault("telegram", {}).setdefault("topics", {})[name] = thread_id

        _save_config(config, config_path_resolved)
        print(f"✅ Added thread {thread_id} → '{name}' (model={model}) to config.json")
    else:
        print(f"ℹ️  No --thread-id provided. Add manually to config.json when ready.")

    print(f"\nNext steps:")
    print(f"  1. Edit {agent_dir}/soul.md to define the agent's personality")
    print(f"  2. Use {shared_git_repos_dir}/ for repositories shared across all agents")
    print(f"  3. Create a Telegram bot via @BotFather and add its token to .env")
    print(f"  4. Add the bot to your Telegram group")
    if thread_id is None:
        print(f"  5. Run: agentforge agent create {name} --thread-id <ID> to register the thread")


def agent_list(*, config_path: str | None = None) -> None:
    """List all configured agents."""
    config, _ = _load_config(config_path)
    root = _resolve_root()

    threads = config.get("threads", {})
    agents = []
    for tid, tcfg in threads.items():
        if tid == "default":
            continue
        name = tcfg.get("name", "unnamed")
        model = tcfg.get("model", "?")
        soul_path = root / "agents" / name / "soul.md"
        has_soul = "✓" if soul_path.exists() else "✗"
        agents.append((tid, name, model, has_soul))

    if not agents:
        print("No agents configured.")
        return

    # Table header
    print(f"{'Thread':>8}  {'Name':<15}  {'Model':<10}  {'Soul'}")
    print(f"{'─' * 8}  {'─' * 15}  {'─' * 10}  {'─' * 4}")
    for tid, name, model, has_soul in sorted(agents, key=lambda x: x[1]):
        print(f"{tid:>8}  {name:<15}  {model:<10}  {has_soul}")


def agent_remove(
    name: str,
    *,
    keep_files: bool = False,
    config_path: str | None = None,
) -> None:
    """Remove an agent from config and optionally delete its files."""
    name = name.lower().strip()
    config, config_path_resolved = _load_config(config_path)

    # Remove from threads
    threads = config.get("threads", {})
    removed_tid = None
    for tid, tcfg in list(threads.items()):
        if tcfg.get("name") == name:
            del threads[tid]
            removed_tid = tid
            break

    # Remove from topics
    topics = config.get("telegram", {}).get("topics", {})
    if name in topics:
        del topics[name]

    # Remove from project_topics agents lists
    for pt_cfg in config.get("project_topics", {}).values():
        agents_list = pt_cfg.get("agents", [])
        if name in agents_list:
            agents_list.remove(name)

    _save_config(config, config_path_resolved)

    if removed_tid:
        print(f"✅ Removed '{name}' (thread {removed_tid}) from config.json")
    else:
        print(f"⚠️  Agent '{name}' not found in config threads")

    # Delete files
    if not keep_files:
        root = _resolve_root()
        agent_dir = root / "agents" / name
        if agent_dir.exists():
            import shutil
            shutil.rmtree(agent_dir)
            print(f"✅ Deleted {agent_dir}/")
        else:
            print(f"ℹ️  No agent directory at {agent_dir}")
    else:
        print(f"ℹ️  Agent files kept on disk (--keep-files)")
