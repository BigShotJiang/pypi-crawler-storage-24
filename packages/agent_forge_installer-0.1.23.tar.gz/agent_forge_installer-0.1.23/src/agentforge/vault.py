#!/usr/bin/env python3
"""
Vault — Mémoire structurée des agents Clawdia
SQLite + FTS5 pour le stockage et la recherche de connaissances cross-agents.

Division des responsabilités :
  agent_vault.db  → mémoire et connaissances des AGENTS (ce fichier)
  obsidian-brain/ → base de connaissance personnelle de MARTIN (inchangé)

Usage:
  vault.py init                         # Initialise la DB (idempotent)
  vault.py search "query" [options]     # Recherche FTS5
  vault.py write [options]              # Crée une entrée
  vault.py read <id>                    # Lit une entrée par ID
  vault.py list [options]               # Liste les entrées
  vault.py update <id> [options]        # Met à jour une entrée
  vault.py delete <id>                  # Supprime (soft delete)
  vault.py stats                        # Statistiques

Catégories disponibles:
  memory      — faits mémorisés sur Martin ou les interactions
  preference  — préférences et comportements de Martin
  knowledge   — connaissances factuelles sur un projet, outil, contexte
  note        — notes de travail d'un agent
  user-profile— profil utilisateur (Martin)

Agents disponibles:
  clawdia, victor, archie, catherine, christophe, shared
"""

import sqlite3
import argparse
import json
import sys
import os
from datetime import datetime, timezone
from pathlib import Path

AGENTFORGE_ROOT = os.environ.get('AGENTFORGE_ROOT', '/home/clawdia')
DB_PATH = Path(AGENTFORGE_ROOT) / 'data' / 'agent_vault.db'

SCHEMA = """
CREATE TABLE IF NOT EXISTS vault_entries (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent       TEXT    NOT NULL DEFAULT 'shared',
    category    TEXT    NOT NULL DEFAULT 'memory',
    title       TEXT    NOT NULL DEFAULT '',
    content     TEXT    NOT NULL,
    tags        TEXT    NOT NULL DEFAULT '',
    source      TEXT    NOT NULL DEFAULT '',
    created_at  TEXT    NOT NULL,
    updated_at  TEXT    NOT NULL,
    is_active   INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_vault_agent    ON vault_entries(agent);
CREATE INDEX IF NOT EXISTS idx_vault_category ON vault_entries(category);
CREATE INDEX IF NOT EXISTS idx_vault_active   ON vault_entries(is_active);

CREATE VIRTUAL TABLE IF NOT EXISTS vault_fts USING fts5(
    title,
    content,
    tags,
    agent,
    category,
    content='vault_entries',
    content_rowid='id'
);

CREATE TRIGGER IF NOT EXISTS vault_ai AFTER INSERT ON vault_entries
    WHEN new.is_active = 1 BEGIN
    INSERT INTO vault_fts(rowid, title, content, tags, agent, category)
    VALUES (new.id, new.title, new.content, new.tags, new.agent, new.category);
END;

CREATE TRIGGER IF NOT EXISTS vault_ad AFTER UPDATE OF is_active ON vault_entries
    WHEN old.is_active = 1 AND new.is_active = 0 BEGIN
    INSERT INTO vault_fts(vault_fts, rowid, title, content, tags, agent, category)
    VALUES ('delete', old.id, old.title, old.content, old.tags, old.agent, old.category);
END;

CREATE TRIGGER IF NOT EXISTS vault_au AFTER UPDATE ON vault_entries
    WHEN old.is_active = 1 AND new.is_active = 1 BEGIN
    INSERT INTO vault_fts(vault_fts, rowid, title, content, tags, agent, category)
    VALUES ('delete', old.id, old.title, old.content, old.tags, old.agent, old.category);
    INSERT INTO vault_fts(rowid, title, content, tags, agent, category)
    VALUES (new.id, new.title, new.content, new.tags, new.agent, new.category);
END;
"""


def get_db() -> sqlite3.Connection:
    """Open DB connection with row factory."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def cmd_init(args):
    """Initialize the database schema (idempotent)."""
    conn = get_db()
    conn.executescript(SCHEMA)
    conn.close()
    print(f"✅ Vault initialized at {DB_PATH}")


def cmd_write(args):
    """Create a new vault entry."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    conn = get_db()

    # Auto-init if DB doesn't exist yet
    if not DB_PATH.exists():
        conn.executescript(SCHEMA)

    cur = conn.execute(
        """INSERT INTO vault_entries
           (agent, category, title, content, tags, source, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            args.agent,
            args.category,
            args.title or "",
            args.content,
            args.tags or "",
            args.source or "",
            now,
            now,
        ),
    )
    conn.commit()
    entry_id = cur.lastrowid
    conn.close()
    print(f"✅ Entrée créée — ID: {entry_id}")
    print(f"   Agent: {args.agent} | Catégorie: {args.category}")
    if args.title:
        print(f"   Titre: {args.title}")


def cmd_read(args):
    """Read a vault entry by ID."""
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM vault_entries WHERE id = ? AND is_active = 1", (args.id,)
    ).fetchone()
    conn.close()

    if not row:
        print(f"❌ Entrée {args.id} introuvable ou supprimée.")
        sys.exit(1)

    print(f"{'─'*60}")
    print(f"ID      : {row['id']}")
    print(f"Agent   : {row['agent']}")
    print(f"Catég.  : {row['category']}")
    if row["title"]:
        print(f"Titre   : {row['title']}")
    print(f"Tags    : {row['tags'] or '—'}")
    print(f"Source  : {row['source'] or '—'}")
    print(f"Créé    : {row['created_at']}")
    print(f"Modifié : {row['updated_at']}")
    print(f"{'─'*60}")
    print(row["content"])
    print(f"{'─'*60}")


def cmd_search(args):
    """Full-text search across the vault."""
    conn = get_db()

    query = args.query

    # Build FTS query with optional filters applied post-search
    sql = """
        SELECT e.*
        FROM vault_entries e
        JOIN vault_fts f ON e.id = f.rowid
        WHERE vault_fts MATCH ?
          AND e.is_active = 1
    """
    params = [query]

    if args.agent:
        sql += " AND e.agent = ?"
        params.append(args.agent)

    if args.category:
        sql += " AND e.category = ?"
        params.append(args.category)

    sql += " ORDER BY rank LIMIT ?"
    params.append(args.limit)

    try:
        rows = conn.execute(sql, params).fetchall()
    except sqlite3.OperationalError as e:
        print(f"❌ Erreur de recherche: {e}")
        print("   Conseil: Si la DB est vide ou corrompue, relancez `vault.py init`")
        conn.close()
        sys.exit(1)

    conn.close()

    if not rows:
        print(f"🔍 Aucun résultat pour: «{query}»")
        return

    print(f"🔍 {len(rows)} résultat(s) pour «{query}»\n")
    for row in rows:
        print(f"  [{row['id']}] {row['agent']}/{row['category']}", end="")
        if row["title"]:
            print(f" — {row['title']}", end="")
        print()
        # Show first 200 chars of content
        content_preview = row["content"][:200].replace("\n", " ")
        if len(row["content"]) > 200:
            content_preview += "…"
        print(f"       {content_preview}")
        if row["tags"]:
            print(f"       🏷  {row['tags']}")
        print()


def cmd_list(args):
    """List vault entries with optional filters."""
    conn = get_db()

    sql = "SELECT * FROM vault_entries WHERE is_active = 1"
    params = []

    if args.agent:
        sql += " AND agent = ?"
        params.append(args.agent)

    if args.category:
        sql += " AND category = ?"
        params.append(args.category)

    sql += " ORDER BY updated_at DESC LIMIT ?"
    params.append(args.limit)

    rows = conn.execute(sql, params).fetchall()
    conn.close()

    if not rows:
        print("📭 Aucune entrée trouvée.")
        return

    filters = []
    if args.agent:
        filters.append(f"agent={args.agent}")
    if args.category:
        filters.append(f"catégorie={args.category}")
    filter_str = f" [{', '.join(filters)}]" if filters else ""
    print(f"📋 {len(rows)} entrée(s){filter_str}\n")

    for row in rows:
        title_str = f" — {row['title']}" if row["title"] else ""
        print(f"  [{row['id']}] {row['agent']}/{row['category']}{title_str}")
        content_preview = row["content"][:120].replace("\n", " ")
        if len(row["content"]) > 120:
            content_preview += "…"
        print(f"       {content_preview}")
        print(f"       📅 {row['updated_at'][:10]}", end="")
        if row["tags"]:
            print(f"  🏷  {row['tags']}", end="")
        print()


def cmd_update(args):
    """Update a vault entry."""
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM vault_entries WHERE id = ? AND is_active = 1", (args.id,)
    ).fetchone()

    if not row:
        print(f"❌ Entrée {args.id} introuvable ou supprimée.")
        conn.close()
        sys.exit(1)

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    new_title = args.title if args.title is not None else row["title"]
    new_content = args.content if args.content is not None else row["content"]
    new_tags = args.tags if args.tags is not None else row["tags"]
    new_category = args.category if args.category is not None else row["category"]

    conn.execute(
        """UPDATE vault_entries
           SET title=?, content=?, tags=?, category=?, updated_at=?
           WHERE id=?""",
        (new_title, new_content, new_tags, new_category, now, args.id),
    )
    conn.commit()
    conn.close()
    print(f"✅ Entrée {args.id} mise à jour.")


def cmd_delete(args):
    """Soft-delete a vault entry."""
    conn = get_db()
    conn.execute(
        "UPDATE vault_entries SET is_active = 0, updated_at = ? WHERE id = ?",
        (datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), args.id),
    )
    conn.commit()
    conn.close()
    print(f"🗑  Entrée {args.id} supprimée (soft delete).")


def cmd_stats(args):
    """Show vault statistics."""
    conn = get_db()

    total = conn.execute(
        "SELECT COUNT(*) FROM vault_entries WHERE is_active = 1"
    ).fetchone()[0]
    deleted = conn.execute(
        "SELECT COUNT(*) FROM vault_entries WHERE is_active = 0"
    ).fetchone()[0]

    by_agent = conn.execute(
        """SELECT agent, COUNT(*) as n
           FROM vault_entries WHERE is_active = 1
           GROUP BY agent ORDER BY n DESC"""
    ).fetchall()

    by_category = conn.execute(
        """SELECT category, COUNT(*) as n
           FROM vault_entries WHERE is_active = 1
           GROUP BY category ORDER BY n DESC"""
    ).fetchall()

    recent = conn.execute(
        """SELECT * FROM vault_entries WHERE is_active = 1
           ORDER BY created_at DESC LIMIT 5"""
    ).fetchall()

    conn.close()

    db_size = DB_PATH.stat().st_size // 1024 if DB_PATH.exists() else 0

    print(f"📊 Vault Stats — {DB_PATH}")
    print(f"{'─'*50}")
    print(f"Total d'entrées actives : {total}")
    print(f"Entrées supprimées      : {deleted}")
    print(f"Taille DB               : {db_size} KB")
    print()
    print("Par agent :")
    for row in by_agent:
        print(f"  {row['agent']:<15} {row['n']} entrée(s)")
    print()
    print("Par catégorie :")
    for row in by_category:
        print(f"  {row['category']:<15} {row['n']} entrée(s)")
    print()
    if recent:
        print("5 dernières entrées :")
        for row in recent:
            title_str = f" — {row['title']}" if row["title"] else ""
            print(f"  [{row['id']}] {row['agent']}/{row['category']}{title_str}")
            print(f"       {row['created_at'][:10]}")


def main():
    parser = argparse.ArgumentParser(
        description="Vault — Mémoire structurée des agents Clawdia (SQLite + FTS5)"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # init
    subparsers.add_parser("init", help="Initialise la DB (idempotent)")

    # write
    p_write = subparsers.add_parser("write", help="Crée une entrée")
    p_write.add_argument("--agent", default="shared",
        choices=["clawdia", "victor", "archie", "catherine", "christophe", "shared"],
        help="Agent propriétaire (défaut: shared)")
    p_write.add_argument("--category", default="memory",
        choices=["memory", "preference", "knowledge", "note", "user-profile"],
        help="Catégorie (défaut: memory)")
    p_write.add_argument("--title", default="", help="Titre court (optionnel)")
    p_write.add_argument("--content", required=True, help="Contenu de l'entrée")
    p_write.add_argument("--tags", default="", help="Tags séparés par virgule")
    p_write.add_argument("--source", default="", help="Source (URL, fichier, etc.)")

    # read
    p_read = subparsers.add_parser("read", help="Lit une entrée par ID")
    p_read.add_argument("id", type=int)

    # search
    p_search = subparsers.add_parser("search", help="Recherche FTS5")
    p_search.add_argument("query", help="Termes de recherche")
    p_search.add_argument("--agent", help="Filtrer par agent")
    p_search.add_argument("--category", help="Filtrer par catégorie")
    p_search.add_argument("--limit", type=int, default=10)

    # list
    p_list = subparsers.add_parser("list", help="Liste les entrées")
    p_list.add_argument("--agent", help="Filtrer par agent")
    p_list.add_argument("--category", help="Filtrer par catégorie")
    p_list.add_argument("--limit", type=int, default=20)

    # update
    p_update = subparsers.add_parser("update", help="Met à jour une entrée")
    p_update.add_argument("id", type=int)
    p_update.add_argument("--title")
    p_update.add_argument("--content")
    p_update.add_argument("--tags")
    p_update.add_argument("--category",
        choices=["memory", "preference", "knowledge", "note", "user-profile"])

    # delete
    p_delete = subparsers.add_parser("delete", help="Supprime (soft delete)")
    p_delete.add_argument("id", type=int)

    # stats
    subparsers.add_parser("stats", help="Statistiques de la DB")

    args = parser.parse_args()

    commands = {
        "init": cmd_init,
        "write": cmd_write,
        "read": cmd_read,
        "search": cmd_search,
        "list": cmd_list,
        "update": cmd_update,
        "delete": cmd_delete,
        "stats": cmd_stats,
    }

    commands[args.command](args)


if __name__ == "__main__":
    main()
