"""AluminatAI GPU agent package."""
__version__ = "0.2.0"
