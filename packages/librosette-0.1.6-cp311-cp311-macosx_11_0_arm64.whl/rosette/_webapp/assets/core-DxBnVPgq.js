function s(t, e, i, r) {
  if (typeof e == "function" ? t !== e || !r : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? r : i === "a" ? r.call(t) : r ? r.value : e.get(t);
}
function h(t, e, i, r, c) {
  if (typeof e == "function" ? t !== e || true : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return e.set(t, i), i;
}
var a, n, o, l, _;
const f = "__TAURI_TO_IPC_KEY__";
function u(t, e = false) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
class w {
  constructor(e) {
    a.set(this, void 0), n.set(this, 0), o.set(this, []), l.set(this, void 0), h(this, a, e || (() => {
    })), this.id = u((i) => {
      const r = i.index;
      if ("end" in i) {
        r == s(this, n, "f") ? this.cleanupCallback() : h(this, l, r);
        return;
      }
      const c = i.message;
      if (r == s(this, n, "f")) {
        for (s(this, a, "f").call(this, c), h(this, n, s(this, n, "f") + 1); s(this, n, "f") in s(this, o, "f"); ) {
          const d = s(this, o, "f")[s(this, n, "f")];
          s(this, a, "f").call(this, d), delete s(this, o, "f")[s(this, n, "f")], h(this, n, s(this, n, "f") + 1);
        }
        s(this, n, "f") === s(this, l, "f") && this.cleanupCallback();
      } else s(this, o, "f")[r] = c;
    });
  }
  cleanupCallback() {
    window.__TAURI_INTERNALS__.unregisterCallback(this.id);
  }
  set onmessage(e) {
    h(this, a, e);
  }
  get onmessage() {
    return s(this, a, "f");
  }
  [(a = /* @__PURE__ */ new WeakMap(), n = /* @__PURE__ */ new WeakMap(), o = /* @__PURE__ */ new WeakMap(), l = /* @__PURE__ */ new WeakMap(), f)]() {
    return `__CHANNEL__:${this.id}`;
  }
  toJSON() {
    return this[f]();
  }
}
async function p(t, e = {}, i) {
  return window.__TAURI_INTERNALS__.invoke(t, e, i);
}
class m {
  get rid() {
    return s(this, _, "f");
  }
  constructor(e) {
    _.set(this, void 0), h(this, _, e);
  }
  async close() {
    return p("plugin:resources|close", { rid: this.rid });
  }
}
_ = /* @__PURE__ */ new WeakMap();
export {
  w as Channel,
  m as Resource,
  f as SERIALIZE_TO_IPC_FN,
  p as invoke,
  u as transformCallback
};
