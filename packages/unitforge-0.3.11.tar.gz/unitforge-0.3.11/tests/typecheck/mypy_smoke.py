from typing import Any

from unitforge import (
    Area,
    AreaUnit,
    Distance,
    DistanceUnit,
    Energy,
    EnergyUnit,
    ForceArea,
    ForceAreaUnit,
    Force,
    ForceUnit,
    Matrix3,
    Moment,
    MomentUnit,
    Vector3,
)

force: Force = Force(12.0, ForceUnit.N)
distance: Distance = Distance(2.0, DistanceUnit.m)

force_in_n: float = force.to(ForceUnit.N)
force_scaled: Force = force * 2.0
force_ratio: float = force / Force(3.0, ForceUnit.N)
dynamic_product: Energy = force * distance

vector: Vector3 = Vector3.from_list([1.0, 2.0, 3.0], ForceUnit.N)
vector_first: Any = vector[0]
vector_norm: Any = vector.norm()
vector_cross: Vector3 = vector.cross(vector)

matrix: Matrix3 = Matrix3.from_list(
    [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
    ForceUnit.N,
)
column: Vector3 = matrix.get_column(0)
matrix.set_column(0, column)

force_area: ForceArea = Force(2.0, ForceUnit.N) * Area(3.0, AreaUnit.msq)
force_area_value: float = force_area.to(ForceAreaUnit.Nmsq)
force_from_div: Force = force_area / Area(3.0, AreaUnit.msq)
area_from_div: Area = force_area / Force(2.0, ForceUnit.N)

energy: Energy = dynamic_product
moment: Moment = energy
energy_unit: EnergyUnit = EnergyUnit.Nm
moment_unit: MomentUnit = energy_unit
