use ndarray::{arr1, arr2};
use unitforge::prelude::*;
use unitforge::{
    Distance, DistanceUnit, Force, ForceDistanceUnit, ForceUnit, Stiffness, StiffnessUnit,
};

#[test]
fn test_ndarray_dot_vector_vector_quantities() {
    let f = arr1(&[Force::new(2.0, ForceUnit::N), Force::new(3.0, ForceUnit::N)]);
    let d = arr1(&[
        Distance::new(4.0, DistanceUnit::m),
        Distance::new(5.0, DistanceUnit::m),
    ]);

    let res = f.dot(&d);
    let expected = 2.0 * 4.0 + 3.0 * 5.0;
    assert!((res.to(ForceDistanceUnit::Nm) - expected).abs() < 1e-10);
}

#[test]
fn test_ndarray_dot_matrix_vector_quantities() {
    let k = arr2(&[
        [
            Stiffness::new(2.0, StiffnessUnit::N_m),
            Stiffness::new(0.0, StiffnessUnit::N_m),
        ],
        [
            Stiffness::new(1.0, StiffnessUnit::N_m),
            Stiffness::new(3.0, StiffnessUnit::N_m),
        ],
    ]);
    let x = arr1(&[
        Distance::new(4.0, DistanceUnit::m),
        Distance::new(5.0, DistanceUnit::m),
    ]);

    let f = k.dot(&x);
    assert_eq!(f.len(), 2);
    assert!((f[0].to(ForceUnit::N) - 8.0).abs() < 1e-10);
    assert!((f[1].to(ForceUnit::N) - 19.0).abs() < 1e-10);
}

#[test]
fn test_ndarray_dot_matrix_matrix_quantities() {
    let k = arr2(&[
        [
            Stiffness::new(1.0, StiffnessUnit::N_m),
            Stiffness::new(2.0, StiffnessUnit::N_m),
        ],
        [
            Stiffness::new(3.0, StiffnessUnit::N_m),
            Stiffness::new(4.0, StiffnessUnit::N_m),
        ],
    ]);
    let x = arr2(&[
        [
            Distance::new(1.0, DistanceUnit::m),
            Distance::new(2.0, DistanceUnit::m),
        ],
        [
            Distance::new(3.0, DistanceUnit::m),
            Distance::new(4.0, DistanceUnit::m),
        ],
    ]);

    let f = k.dot(&x);
    assert_eq!(f.shape(), &[2, 2]);
    assert!((f[(0, 0)].to(ForceUnit::N) - 7.0).abs() < 1e-10);
    assert!((f[(0, 1)].to(ForceUnit::N) - 10.0).abs() < 1e-10);
    assert!((f[(1, 0)].to(ForceUnit::N) - 15.0).abs() < 1e-10);
    assert!((f[(1, 1)].to(ForceUnit::N) - 22.0).abs() < 1e-10);
}
