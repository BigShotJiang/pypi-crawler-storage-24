# BADAS - Beyond ADAS

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch 2.0+](https://img.shields.io/badge/pytorch-2.0+-ee4c2c.svg)](https://pytorch.org/)
[![PyPI](https://img.shields.io/pypi/v/badas.svg)](https://pypi.org/project/badas/)

**BADAS** (Beyond ADAS) is a deep learning framework for predicting collision likelihood in dashcam video sequences. It supports multiple vision transformer backbones and deployment formats optimized for real-time inference.

## Installation

```bash
pip install badas
```

Optional extras for faster video decoding or alternative backends:

```bash
pip install decord           # Fast video decoding (falls back to OpenCV)
pip install onnxruntime-gpu  # ONNX backend
```

## Quick Start

```python
from badas.inference import BADAS, BADASConfig

predictor = BADAS.from_pretrained("nexar-ai/BADAS-Open")

# Batch prediction on a video
results = predictor.predict_video("dashcam.mp4", stride=1)
for r in results:
    print(f"[{r['timestamp']:.2f}s]  {r['risk_level']:<6}  p={r['probability']:.3f}")

# Streaming / moving-window inference
for pred in predictor.predict_stream("dashcam.mp4", stride=1):
    if pred['probability'] > 0.7:
        print(f"WARNING: High collision risk at {pred['timestamp']:.2f}s")
```

## Prediction Output

Each prediction is a dict:

```python
{
    'frame_index': 100,
    'timestamp': 4.17,
    'probability': 0.823,
    'risk_level': 'high',   # 'low' | 'medium' | 'high'
    'smoothed': True,
}
```

## Inference Backends

| Format | Load | Notes |
|--------|------|-------|
| `.ckpt` / `.pt` | `BADAS("model.ckpt")` | Full model + config, supports `torch.compile` |
| `.onnx` | `BADAS("model.onnx")` | CPU/GPU via ONNX Runtime |
| `.trt` / `.engine` | `BADAS("model.trt")` | NVIDIA GPU, lowest latency |

## Configuration

```python
from badas.inference import BADAS, BADASConfig, SmoothingConfig

config = BADASConfig(
    use_compile=True,       # torch.compile — slow first run, fast thereafter
    startup_ramp=True,      # yield predictions before the full window is buffered
    smoothing=SmoothingConfig(
        enabled=True,
        alpha_rise=0.7,     # smoothing when risk increases
        alpha_fall=0.3,     # smoothing when risk decreases
    ),
)
predictor = BADAS("model.ckpt", config=config)
```

## Available Models

### Open Source

| Model | Size | Notes |
|-------|------|-------|
| `nexar-ai/BADAS-Open` | ViT-L | Publicly available |

```python
predictor = BADAS.from_pretrained("nexar-ai/BADAS-Open")
```

### Commercial (Nexar)

| Model | Size | Notes |
|-------|------|-------|
| `nexar-ai/badas-1.0` | ViT-L | |
| `nexar-ai/badas-1.5` | ViT-L | Best accuracy |
| `nexar-ai/badas-1.5-flash` | ViT-B | Fast |
| `nexar-ai/badas-1.5-flash-lite` | ViT-S | Fastest |

To request access, visit [nexar-ai.com/badas](https://www.nexar-ai.com/badas).

## Citation

```bibtex
@article{goldshmidt2025badas,
  title={BADAS: Context Aware Collision Prediction Using Real-World Dashcam Data},
  author={Goldshmidt, Roni and Scott, Hamish and Niccolini, Lorenzo and
          Zhu, Shizhan and Moura, Daniel and Zvitia, Orly},
  journal={arXiv preprint},
  year={2025}
}
```
