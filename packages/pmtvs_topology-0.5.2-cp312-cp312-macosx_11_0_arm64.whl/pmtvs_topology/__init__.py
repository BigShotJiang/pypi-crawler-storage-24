"""
pmtvs-topology — Topological data analysis primitives.

Rust backend (_core) required for hot-path functions.
"""

__version__ = "0.5.1"

try:
    from pmtvs_topology._core import (
        pairwise_distance_matrix,
        persistent_homology,
        persistence_statistics,
        wasserstein_distance,
    )
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-topology && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

BACKEND = "rust"

from pmtvs_topology.topology import (
    distance_matrix,
    persistent_homology_0d,
    persistent_homology_1d,
    persistent_homology,
    betti_numbers,
    persistence_entropy,
    persistence_landscape,
    bottleneck_distance,
)

__all__ = [
    "__version__",
    "BACKEND",
    "pairwise_distance_matrix",
    "persistence_statistics",
    "distance_matrix",
    "persistent_homology_0d",
    "persistent_homology_1d",
    "persistent_homology",
    "betti_numbers",
    "persistence_entropy",
    "persistence_landscape",
    "bottleneck_distance",
    "wasserstein_distance",
]
