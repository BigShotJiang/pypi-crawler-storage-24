"""Tests for the AgenticCalling SDK client."""
import pytest
import respx
import httpx
from agenticcalling import AgenticCalling
from agenticcalling.exceptions import (
    AuthenticationError,
    InsufficientBalanceError,
    RateLimitError,
    NotFoundError,
    ValidationError,
)

BASE_URL = "https://api.agenticcalling.ai"


@pytest.fixture
def client():
    return AgenticCalling(api_key="ac_test_key", base_url=BASE_URL)


class TestClientInit:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="api_key is required"):
            AgenticCalling(api_key="")

    def test_has_expected_resources(self, client):
        assert hasattr(client, "calls")
        assert hasattr(client, "lines")
        assert hasattr(client, "playbooks")
        assert hasattr(client, "sms")
        assert hasattr(client, "usage")

    def test_context_manager(self):
        with AgenticCalling(api_key="ac_test") as c:
            assert c.calls is not None


class TestCallsCreate:
    @respx.mock
    def test_create_call_minimal(self, client):
        respx.post(f"{BASE_URL}/v1/calls").mock(
            return_value=httpx.Response(
                201,
                json={
                    "call_id": "call_abc123",
                    "status": "queued",
                    "to": "+14155551234",
                    "objective": "Ask about hours",
                    "created_at": "2026-03-16T14:00:00Z",
                },
            )
        )

        call = client.calls.create(to="+14155551234", objective="Ask about hours")

        assert call.call_id == "call_abc123"
        assert call.status == "queued"
        assert call.to == "+14155551234"

    @respx.mock
    def test_create_call_returns_call_response(self, client):
        respx.post(f"{BASE_URL}/v1/calls").mock(
            return_value=httpx.Response(
                201,
                json={
                    "call_id": "call_xyz",
                    "status": "queued",
                    "to": "+14155551234",
                    "objective": "test",
                    "created_at": "2026-03-16T00:00:00Z",
                    "structured_data": {"price": 52},
                },
            )
        )

        call = client.calls.create(to="+14155551234", objective="test")
        assert call.structured_data == {"price": 52}

    @respx.mock
    def test_create_call_raises_on_401(self, client):
        respx.post(f"{BASE_URL}/v1/calls").mock(
            return_value=httpx.Response(
                401, json={"error": {"message": "Invalid API key"}}
            )
        )

        with pytest.raises(AuthenticationError):
            client.calls.create(to="+14155551234", objective="test")

    @respx.mock
    def test_create_call_raises_insufficient_balance(self, client):
        respx.post(f"{BASE_URL}/v1/calls").mock(
            return_value=httpx.Response(
                402,
                json={
                    "error": {
                        "code": "insufficient_balance",
                        "message": "You've used all 30 free minutes.",
                        "details": {
                            "minutes_used": 30.0,
                            "minutes_limit": 30.0,
                            "resets_at": "2026-04-01T00:00:00Z",
                            "upgrade_url": "https://agenticcalling.ai/dashboard/upgrade",
                        },
                        "suggestions": ["Upgrade to Pro", "Wait for reset"],
                    }
                },
            )
        )

        with pytest.raises(InsufficientBalanceError) as exc_info:
            client.calls.create(to="+14155551234", objective="test")

        err = exc_info.value
        assert err.upgrade_url == "https://agenticcalling.ai/dashboard/upgrade"
        assert err.minutes_used == 30.0
        assert len(err.suggestions) == 2

    @respx.mock
    def test_create_call_raises_rate_limit_with_retry_after(self, client):
        respx.post(f"{BASE_URL}/v1/calls").mock(
            return_value=httpx.Response(
                429,
                headers={"Retry-After": "30"},
                json={"error": {"message": "Rate limit exceeded"}},
            )
        )

        with pytest.raises(RateLimitError) as exc_info:
            client.calls.create(to="+14155551234", objective="test")

        assert exc_info.value.retry_after == 30

    @respx.mock
    def test_get_call(self, client):
        respx.get(f"{BASE_URL}/v1/calls/call_abc").mock(
            return_value=httpx.Response(
                200,
                json={
                    "call_id": "call_abc",
                    "status": "completed",
                    "to": "+14155551234",
                    "objective": "test",
                    "created_at": "2026-03-16T00:00:00Z",
                    "duration_seconds": 120,
                    "structured_data": {"price": 52},
                },
            )
        )

        call = client.calls.get("call_abc")
        assert call.status == "completed"
        assert call.duration_seconds == 120

    @respx.mock
    def test_get_call_not_found_raises_404(self, client):
        respx.get(f"{BASE_URL}/v1/calls/nonexistent").mock(
            return_value=httpx.Response(
                404, json={"error": {"message": "Call not found"}}
            )
        )

        with pytest.raises(NotFoundError):
            client.calls.get("nonexistent")


class TestBatchCalls:
    @respx.mock
    def test_create_batch(self, client):
        respx.post(f"{BASE_URL}/v1/calls/batch").mock(
            return_value=httpx.Response(
                201,
                json={
                    "batch_id": "batch_abc",
                    "status": "in_progress",
                    "total": 3,
                    "calls": [],
                },
            )
        )

        batch = client.calls.create_batch(
            targets=[
                {"to": "+14155551111", "objective": "Get quote"},
                {"to": "+14155552222", "objective": "Get quote"},
                {"to": "+14155553333", "objective": "Get quote"},
            ],
            concurrency=3,
        )

        assert batch.batch_id == "batch_abc"
        assert batch.total == 3


class TestLinesResource:
    @respx.mock
    def test_create_line(self, client):
        respx.post(f"{BASE_URL}/v1/lines").mock(
            return_value=httpx.Response(
                201,
                json={
                    "line_id": "line_abc",
                    "phone_number": "+14155550142",
                    "country": "US",
                },
            )
        )

        line = client.lines.create(country="US")
        assert line.phone_number == "+14155550142"
        assert line.country == "US"


class TestUsageWarningHeader:
    @respx.mock
    def test_usage_warning_header_triggers_warning(self, client):
        respx.get(f"{BASE_URL}/v1/usage").mock(
            return_value=httpx.Response(
                200,
                headers={"X-AC-Usage-Warning": "approaching_limit"},
                json={
                    "plan": "free",
                    "minutes_used": 25.0,
                    "minutes_limit": 30.0,
                    "minutes_remaining": 5.0,
                    "sms_sent": 10,
                    "resets_at": "2026-04-01T00:00:00Z",
                },
            )
        )

        import warnings

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            client.usage.get()
            assert len(w) == 1
            assert "approaching_limit" in str(w[0].message)


class TestSMSResource:
    @respx.mock
    def test_send_sms(self, client):
        respx.post(f"{BASE_URL}/v1/sms/send").mock(
            return_value=httpx.Response(
                201,
                json={
                    "sms_id": "sms_abc",
                    "status": "sent",
                    "to": "+14155551234",
                    "cost": 0.01,
                },
            )
        )

        sms = client.sms.send(to="+14155551234", message="Hello!")
        assert sms.sms_id == "sms_abc"
        assert sms.status == "sent"
