"""Playbooks resource."""
from __future__ import annotations
from typing import Any
from .._http import HTTPClient
from ..models import PlaybookResponse, ListResponse


class PlaybooksResource:
    def __init__(self, http: HTTPClient):
        self._http = http

    def create(
        self,
        *,
        name: str,
        strategy: str,
        base: str | None = None,
        behavior_rules: list[str] | None = None,
        extraction_schema: dict[str, Any] | None = None,
        voice_tone: str | None = None,
        success_criteria: str | None = None,
        params: dict | None = None,
        pod_id: str | None = None,
        overrides: dict | None = None,
    ) -> PlaybookResponse:
        """
        Create a playbook.

        Args:
            name: Display name
            strategy: Natural language conversation strategy
            base: Platform playbook to fork from (e.g. "platform.negotiation")
            behavior_rules: Hard constraints list
            extraction_schema: Fields to extract from conversation
            voice_tone: How the caller should sound
            success_criteria: What constitutes a successful call
            params: Default parameters
            pod_id: Multi-tenant isolation
            overrides: Override specific platform playbook fields
        """
        payload: dict[str, Any] = {"name": name, "strategy": strategy}
        if base:
            payload["base"] = base
        if behavior_rules:
            payload["behavior_rules"] = behavior_rules
        if extraction_schema:
            payload["extraction_schema"] = extraction_schema
        if voice_tone:
            payload["voice_tone"] = voice_tone
        if success_criteria:
            payload["success_criteria"] = success_criteria
        if params:
            payload["params"] = params
        if pod_id:
            payload["pod_id"] = pod_id
        if overrides:
            payload["overrides"] = overrides

        data = self._http.post("/v1/playbooks", json=payload)
        return PlaybookResponse.from_dict(data)

    def get(self, playbook_id: str) -> PlaybookResponse:
        """Get a playbook by ID."""
        data = self._http.get(f"/v1/playbooks/{playbook_id}")
        return PlaybookResponse.from_dict(data)

    def list(self, *, pod_id: str | None = None) -> ListResponse:
        """List all playbooks, optionally filtered by pod."""
        params: dict[str, Any] = {}
        if pod_id:
            params["pod_id"] = pod_id
        data = self._http.get("/v1/playbooks", params=params or None)
        playbooks = [PlaybookResponse.from_dict(p) for p in data.get("data", [])]
        return ListResponse(data=playbooks, count=data.get("count", len(playbooks)))

    def update(self, playbook_id: str, **kwargs) -> PlaybookResponse:
        """Update a playbook's configuration."""
        data = self._http.put(f"/v1/playbooks/{playbook_id}", json=kwargs)
        return PlaybookResponse.from_dict(data)

    def delete(self, playbook_id: str) -> None:
        """Delete a playbook."""
        self._http.delete(f"/v1/playbooks/{playbook_id}")
