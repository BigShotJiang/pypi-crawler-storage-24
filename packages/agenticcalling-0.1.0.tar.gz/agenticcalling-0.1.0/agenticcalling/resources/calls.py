"""Calls resource."""
from __future__ import annotations
from typing import Any
from .._http import HTTPClient
from ..models import CallResponse, BatchCallResponse, TranscriptResponse, ListResponse


class CallsResource:
    def __init__(self, http: HTTPClient):
        self._http = http

    def create(
        self,
        *,
        to: str,
        objective: str,
        context: str | None = None,
        from_line: str | None = None,
        persona_id: str | None = None,
        playbook_id: str | None = None,
        behavior_rules: list[str] | None = None,
        voice: str | None = None,
        language: str = "en",
        on_voicemail: str = "leave_message",
        on_screening: str = "navigate",
        max_duration_minutes: int = 30,
        schedule_at: str | None = None,
        retry_policy: dict | None = None,
        webhook_url: str | None = None,
        pod_id: str | None = None,
        client_id: str | None = None,
        sms_follow_up: dict | None = None,
        params: dict | None = None,
    ) -> CallResponse:
        """
        Create a new phone call.

        Args:
            to: Phone number to call (E.164 format, e.g. "+14155551234")
            objective: What the call should accomplish (required)
            context: Background information for the caller
            from_line: Specific PhoneLine ID to call from (optional)
            persona_id: Caller identity to use
            playbook_id: Specific playbook to use
            behavior_rules: Hard constraints (e.g. "Never agree above $60")
            voice: Voice preset
            language: Language code or "auto"
            on_voicemail: "leave_message" | "hang_up" | "retry"
            on_screening: "navigate" | "wait" | "hang_up"
            max_duration_minutes: Hard cap on call length
            schedule_at: ISO datetime to schedule call for later
            retry_policy: Custom retry configuration
            webhook_url: Call-specific webhook URL
            pod_id: Multi-tenant pod isolation
            client_id: Idempotency key
            sms_follow_up: SMS follow-up configuration
            params: Additional playbook params

        Returns:
            CallResponse with call_id and initial status

        Raises:
            InsufficientBalanceError: If account has no credits
            ValidationError: If parameters are invalid
        """
        payload: dict[str, Any] = {
            "to": to,
            "objective": objective,
        }
        if context is not None:
            payload["context"] = context
        if from_line is not None:
            payload["from_line"] = from_line
        if persona_id is not None:
            payload["persona_id"] = persona_id
        if playbook_id is not None:
            payload["playbook_id"] = playbook_id
        if behavior_rules is not None:
            payload["behavior_rules"] = behavior_rules
        if voice is not None:
            payload["voice"] = voice
        if language != "en":
            payload["language"] = language
        if on_voicemail != "leave_message":
            payload["on_voicemail"] = on_voicemail
        if on_screening != "navigate":
            payload["on_screening"] = on_screening
        if max_duration_minutes != 30:
            payload["max_duration_minutes"] = max_duration_minutes
        if schedule_at is not None:
            payload["schedule_at"] = schedule_at
        if retry_policy is not None:
            payload["retry_policy"] = retry_policy
        if webhook_url is not None:
            payload["webhook_url"] = webhook_url
        if pod_id is not None:
            payload["pod_id"] = pod_id
        if client_id is not None:
            payload["client_id"] = client_id
        if sms_follow_up is not None:
            payload["sms_follow_up"] = sms_follow_up
        if params is not None:
            payload["params"] = params

        data = self._http.post("/v1/calls", json=payload)
        return CallResponse.from_dict(data)

    def create_batch(
        self,
        *,
        targets: list[dict[str, Any]],
        concurrency: int = 5,
        voice: str | None = None,
        language: str = "en",
        playbook_id: str | None = None,
        webhook_url: str | None = None,
        pod_id: str | None = None,
        objective: str | None = None,
    ) -> BatchCallResponse:
        """
        Create a batch of concurrent calls.

        Args:
            targets: List of {to, objective, context} dicts
            concurrency: Max simultaneous calls (limited by plan)
            voice: Voice preset for all calls
            language: Language for all calls ("auto" for per-call detection)
            playbook_id: Playbook to use for all calls
            webhook_url: Webhook for all calls in this batch
            pod_id: Multi-tenant isolation
            objective: Shared objective if not in each target
        """
        payload: dict[str, Any] = {
            "targets": targets,
            "concurrency": concurrency,
            "language": language,
        }
        if voice is not None:
            payload["voice"] = voice
        if playbook_id is not None:
            payload["playbook_id"] = playbook_id
        if webhook_url is not None:
            payload["webhook_url"] = webhook_url
        if pod_id is not None:
            payload["pod_id"] = pod_id
        if objective is not None:
            payload["objective"] = objective

        data = self._http.post("/v1/calls/batch", json=payload)
        return BatchCallResponse.from_dict(data)

    def get(self, call_id: str) -> CallResponse:
        """Get call status and results."""
        data = self._http.get(f"/v1/calls/{call_id}")
        return CallResponse.from_dict(data)

    def get_transcript(self, call_id: str) -> TranscriptResponse:
        """Get full transcript with speaker labels and timestamps."""
        data = self._http.get(f"/v1/calls/{call_id}/transcript")
        return TranscriptResponse.from_dict(data)

    def get_batch(self, batch_id: str) -> BatchCallResponse:
        """Get batch status with per-call results."""
        data = self._http.get(f"/v1/calls/batch/{batch_id}")
        return BatchCallResponse.from_dict(data)

    def list(
        self,
        *,
        status: str | None = None,
        limit: int = 20,
        page_token: str | None = None,
        pod_id: str | None = None,
    ) -> ListResponse:
        """List calls with optional filtering."""
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        if page_token:
            params["page_token"] = page_token
        if pod_id:
            params["pod_id"] = pod_id

        data = self._http.get("/v1/calls", params=params)
        calls = [CallResponse.from_dict(c) for c in data.get("data", [])]
        return ListResponse(
            data=calls,
            count=data.get("count", len(calls)),
            next_page_token=data.get("next_page_token"),
        )

    def cancel(self, call_id: str) -> CallResponse:
        """Cancel a queued or scheduled call."""
        data = self._http.delete(f"/v1/calls/{call_id}/cancel")
        return CallResponse.from_dict(data)
