"""PhoneLines resource."""
from __future__ import annotations
from typing import Any
from .._http import HTTPClient
from ..models import PhoneLineResponse, ListResponse


class LinesResource:
    def __init__(self, http: HTTPClient):
        self._http = http

    def create(
        self,
        *,
        country: str = "US",
        area_code: str | None = None,
        display_name: str | None = None,
        default_persona_id: str | None = None,
        inbound_playbook_id: str | None = None,
        inbound_greeting: str | None = None,
        sms_enabled: bool = True,
        sms_auto_reply: bool = False,
        sms_auto_reply_message: str | None = None,
        voicemail_greeting: str | None = None,
        dnc_enabled: bool = True,
        pod_id: str | None = None,
        client_id: str | None = None,
    ) -> PhoneLineResponse:
        """Provision a new phone line."""
        payload: dict[str, Any] = {"country": country, "sms_enabled": sms_enabled}
        if area_code:
            payload["area_code"] = area_code
        if display_name:
            payload["display_name"] = display_name
        if default_persona_id:
            payload["default_persona_id"] = default_persona_id
        if inbound_playbook_id:
            payload["inbound_playbook_id"] = inbound_playbook_id
        if inbound_greeting:
            payload["inbound_greeting"] = inbound_greeting
        if sms_auto_reply:
            payload["sms_auto_reply"] = sms_auto_reply
        if sms_auto_reply_message:
            payload["sms_auto_reply_message"] = sms_auto_reply_message
        if voicemail_greeting:
            payload["voicemail_greeting"] = voicemail_greeting
        if not dnc_enabled:
            payload["dnc_enabled"] = False
        if pod_id:
            payload["pod_id"] = pod_id
        if client_id:
            payload["client_id"] = client_id

        data = self._http.post("/v1/lines", json=payload)
        return PhoneLineResponse.from_dict(data)

    def get(self, line_id: str) -> PhoneLineResponse:
        """Get a phone line by ID."""
        data = self._http.get(f"/v1/lines/{line_id}")
        return PhoneLineResponse.from_dict(data)

    def list(
        self, *, limit: int = 20, page_token: str | None = None
    ) -> ListResponse:
        """List all provisioned phone lines."""
        params: dict[str, Any] = {"limit": limit}
        if page_token:
            params["page_token"] = page_token
        data = self._http.get("/v1/lines", params=params)
        lines = [PhoneLineResponse.from_dict(line) for line in data.get("data", [])]
        return ListResponse(data=lines, count=data.get("count", len(lines)))

    def update(self, line_id: str, **kwargs) -> PhoneLineResponse:
        """Update a phone line's configuration."""
        data = self._http.put(f"/v1/lines/{line_id}", json=kwargs)
        return PhoneLineResponse.from_dict(data)

    def delete(self, line_id: str) -> None:
        """Release a phone line."""
        self._http.delete(f"/v1/lines/{line_id}")
