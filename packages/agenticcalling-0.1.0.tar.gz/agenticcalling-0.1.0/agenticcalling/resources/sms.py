"""SMS resource."""
from __future__ import annotations
from typing import Any
from .._http import HTTPClient
from ..models import SMSResponse, ListResponse


class SMSResource:
    def __init__(self, http: HTTPClient):
        self._http = http

    def send(
        self,
        *,
        to: str,
        message: str,
        from_line: str | None = None,
        pod_id: str | None = None,
        client_id: str | None = None,
    ) -> SMSResponse:
        """Send an SMS message."""
        payload: dict[str, Any] = {"to": to, "message": message}
        if from_line:
            payload["from_line"] = from_line
        if pod_id:
            payload["pod_id"] = pod_id
        if client_id:
            payload["client_id"] = client_id
        data = self._http.post("/v1/sms/send", json=payload)
        return SMSResponse.from_dict(data)

    def list_threads(
        self,
        *,
        line_id: str,
        limit: int = 20,
        page_token: str | None = None,
    ) -> ListResponse:
        """List SMS conversation threads for a phone line."""
        params: dict[str, Any] = {"line_id": line_id, "limit": limit}
        if page_token:
            params["page_token"] = page_token
        data = self._http.get("/v1/sms/threads", params=params)
        return ListResponse(data=data.get("data", []), count=data.get("count", 0))

    def get_thread(self, *, line_id: str, thread_id: str) -> dict:
        """Get a specific SMS thread with all messages."""
        return self._http.get(
            f"/v1/sms/threads/{thread_id}", params={"line_id": line_id}
        )
