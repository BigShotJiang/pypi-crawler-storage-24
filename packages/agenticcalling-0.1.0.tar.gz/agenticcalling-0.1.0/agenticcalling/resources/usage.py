"""Usage resource."""
from .._http import HTTPClient
from ..models import UsageResponse


class UsageResource:
    def __init__(self, http: HTTPClient):
        self._http = http

    def get(self) -> UsageResponse:
        """Get current usage and balance."""
        data = self._http.get("/v1/usage")
        return UsageResponse.from_dict(data)
