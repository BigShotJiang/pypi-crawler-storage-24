"""HTTP client for the SDK."""
from __future__ import annotations
import httpx
from .exceptions import (
    AgenticCallingError,
    AuthenticationError,
    InsufficientBalanceError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    ConflictError,
    ServerError,
)

API_BASE_URL = "https://api.agenticcalling.ai"


class HTTPClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = API_BASE_URL,
        timeout: float = 60.0,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "agenticcalling-python/0.1.0",
            },
            timeout=timeout,
        )

    def request(self, method: str, path: str, **kwargs) -> dict:
        """Make an HTTP request and return parsed JSON."""
        response = self._client.request(method, path, **kwargs)
        return self._handle_response(response)

    def get(self, path: str, params: dict | None = None) -> dict:
        return self.request("GET", path, params=params)

    def post(self, path: str, json: dict | None = None) -> dict:
        return self.request("POST", path, json=json)

    def put(self, path: str, json: dict | None = None) -> dict:
        return self.request("PUT", path, json=json)

    def delete(self, path: str) -> dict:
        return self.request("DELETE", path)

    def _handle_response(self, response: httpx.Response) -> dict:
        """Parse response and raise appropriate exceptions."""
        # Check for usage warnings
        usage_warning = response.headers.get("X-AC-Usage-Warning")
        if usage_warning:
            import warnings

            warnings.warn(
                f"AgenticCalling usage warning: {usage_warning}. Consider upgrading your plan.",
                UserWarning,
                stacklevel=3,
            )

        if response.status_code in (200, 201):
            return response.json()

        # Parse error body
        try:
            body = response.json()
        except Exception:
            body = {"error": {"message": response.text}}

        error_data = body.get("error", {})
        message = error_data.get("message", f"HTTP {response.status_code}")

        if response.status_code == 401:
            raise AuthenticationError(message, status_code=401, response_body=body)

        elif response.status_code == 402:
            raise InsufficientBalanceError(
                message,
                details=error_data.get("details", {}),
                suggestions=error_data.get("suggestions", []),
            )

        elif response.status_code == 404:
            raise NotFoundError(message, status_code=404, response_body=body)

        elif response.status_code == 409:
            raise ConflictError(message, status_code=409, response_body=body)

        elif response.status_code == 422:
            raise ValidationError(message, status_code=422, response_body=body)

        elif response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                message,
                retry_after=int(retry_after) if retry_after else None,
            )

        elif response.status_code >= 500:
            raise ServerError(
                message, status_code=response.status_code, response_body=body
            )

        else:
            raise AgenticCallingError(
                message, status_code=response.status_code, response_body=body
            )

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
