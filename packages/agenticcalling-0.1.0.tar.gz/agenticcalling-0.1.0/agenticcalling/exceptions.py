"""SDK exceptions."""
from __future__ import annotations


class AgenticCallingError(Exception):
    """Base exception for all AgenticCalling errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: dict | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body or {}


class AuthenticationError(AgenticCallingError):
    """Invalid API key (401)."""

    pass


class InsufficientBalanceError(AgenticCallingError):
    """No credits remaining (402)."""

    def __init__(
        self,
        message: str,
        details: dict | None = None,
        suggestions: list[str] | None = None,
    ):
        super().__init__(message, status_code=402)
        self.details = details or {}
        self.suggestions = suggestions or []
        self.upgrade_url = self.details.get(
            "upgrade_url", "https://agenticcalling.ai/dashboard/upgrade"
        )
        self.minutes_used = self.details.get("minutes_used", 0)
        self.minutes_limit = self.details.get("minutes_limit", 0)
        self.resets_at = self.details.get("resets_at")


class NotFoundError(AgenticCallingError):
    """Resource not found (404)."""

    pass


class RateLimitError(AgenticCallingError):
    """Rate limit exceeded (429)."""

    def __init__(self, message: str, retry_after: int | None = None):
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class ValidationError(AgenticCallingError):
    """Invalid request parameters (422)."""

    pass


class ConflictError(AgenticCallingError):
    """Resource conflict (409)."""

    pass


class ServerError(AgenticCallingError):
    """Server error (5xx)."""

    pass
