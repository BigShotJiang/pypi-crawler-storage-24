"""Main AgenticCalling client."""
from __future__ import annotations
from ._http import HTTPClient, API_BASE_URL
from .resources.calls import CallsResource
from .resources.lines import LinesResource
from .resources.playbooks import PlaybooksResource
from .resources.sms import SMSResource
from .resources.usage import UsageResource


class AgenticCalling:
    """
    AgenticCalling Python SDK.

    Usage:
        from agenticcalling import AgenticCalling

        client = AgenticCalling(api_key="ac_live_...")
        call = client.calls.create(
            to="+14155551234",
            objective="Ask about business hours",
        )
        print(f"Call {call.call_id}: {call.status}")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = API_BASE_URL,
        timeout: float = 60.0,
    ):
        """
        Initialize the client.

        Args:
            api_key: Your API key from agenticcalling.ai/dashboard
            base_url: Override the API base URL (for testing)
            timeout: Request timeout in seconds
        """
        if not api_key:
            raise ValueError("api_key is required")

        self._http = HTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
        )

        self.calls = CallsResource(self._http)
        self.lines = LinesResource(self._http)
        self.playbooks = PlaybooksResource(self._http)
        self.sms = SMSResource(self._http)
        self.usage = UsageResource(self._http)

    def close(self):
        """Close the HTTP client."""
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __repr__(self) -> str:
        return f"AgenticCalling(base_url={self._http._base_url!r})"
