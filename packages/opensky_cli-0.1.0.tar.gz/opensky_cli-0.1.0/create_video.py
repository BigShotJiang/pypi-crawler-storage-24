#!/usr/bin/env python3
"""Generate demo video for opensky LinkedIn post.

Simulates a real terminal session: running a multi-city flight search,
scanning routes, showing ranked results with TOP PICK highlight.
Matches the food-finder/cfo terminal design system.

Usage: python3 create_video.py
Output: ./opensky-demo.mp4
"""

import os, subprocess, math, io
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
import cairosvg

# ── Dimensions & Timing ──────────────────────────────────────────
W, H = 1080, 1080
FPS = 30

# ── Colors (neutral dark palette) ────────────────────────────────
BG      = (10, 10, 15)
WIN_BG  = (17, 17, 22)
CHROME  = (22, 22, 28)
WHITE   = (232, 232, 232)
LIGHT   = (208, 208, 208)
DIM     = (120, 120, 125)
FAINT   = (42, 42, 42)
GREEN   = (124, 223, 124)
BLUE    = (90, 159, 212)
ACCENT  = (139, 154, 123)
PROMPT  = (168, 216, 168)
CURSOR  = (232, 232, 232)

# ── Fonts ────────────────────────────────────────────────────────
FDIR   = os.path.expanduser("~/linkedin-posts/engine/carousel/fonts")
mono   = ImageFont.truetype(f"{FDIR}/JetBrainsMono-Regular.ttf", 22)
mono_b = ImageFont.truetype(f"{FDIR}/JetBrainsMono-Bold.ttf", 22)
sans   = ImageFont.truetype(f"{FDIR}/Inter-Bold.ttf", 15)
title_font = ImageFont.truetype(f"{FDIR}/Inter-ExtraBold.ttf", 48)
subtitle_font = ImageFont.truetype(f"{FDIR}/Inter-Regular.ttf", 24)

# ── Terminal Window Geometry ─────────────────────────────────────
MARGIN  = 32
WIN_W   = W - 2 * MARGIN
WIN_H   = 720
WIN_X   = MARGIN
WIN_Y   = 200
WIN_R   = 16
CHR_H   = 44
PAD     = 24
CX      = WIN_X + PAD
CY      = WIN_Y + CHR_H + PAD + 4
LH      = 32

# ── Title above terminal ────────────────────────────────────────
TITLE_PARTS = [("open", WHITE), ("sky", GREEN)]
TITLE_FULL = "opensky"
TITLE_Y = 50
SUBTITLE_TEXT = "Prompt to fly."
SUBTITLE_Y = 115

# ── Video Script ─────────────────────────────────────────────────
COMMAND = "opensky"
TYPE_START = 0.7
CHAR_DELAY = 0.03


# ── Event System ─────────────────────────────────────────────────
class Event:
    def __init__(self, time, kind, data=None):
        self.time = time
        self.kind = kind
        self.data = data


def add_typed_qa(events, t, label, label_color, answer_parts, char_delay=0.02):
    """Add a Q&A line with typing animation for the answer."""
    events.append(Event(t, "status", [(label, label_color)]))
    events.append(Event(t, "typing_start"))
    t_ch = t + 0.1
    for text, color in answer_parts:
        for ch in text:
            events.append(Event(t_ch, "type_answer", {"char": ch, "color": color}))
            t_ch += char_delay
    events.append(Event(t_ch + 0.08, "typing_stop"))
    return t_ch + 0.08


def build_events():
    events = []

    # Phase 0: empty prompt with cursor
    events.append(Event(0.0, "show_prompt"))

    # Phase 1: type the command
    t_type = TYPE_START
    for ch in COMMAND:
        events.append(Event(t_type, "type_char", ch))
        t_type += CHAR_DELAY
        if ch == ' ':
            t_type += 0.06

    enter_t = t_type + 0.15
    events.append(Event(enter_t, "enter"))

    # Phase 2: interactive Q&A with typing animation
    t = enter_t + 0.2
    t = add_typed_qa(events, t, "  Where from?   ", DIM,
                     [("Bangkok, Delhi, Mumbai, KL, Singapore, Bangalore", WHITE)], char_delay=0.015)
    t += 0.2
    t = add_typed_qa(events, t, "  Where to?     ", DIM,
                     [("Hamburg, Frankfurt, Berlin, Munich, Amsterdam, Copenhagen", WHITE)], char_delay=0.015)
    t += 0.15
    t = add_typed_qa(events, t, "  When?         ", DIM,
                     [("March 10-20 (10 days)", WHITE)], char_delay=0.015)
    t += 0.15
    t = add_typed_qa(events, t, "  Max price?    ", DIM,
                     [("\u20ac400", GREEN), (" \u00b7 economy \u00b7 1 stop max", LIGHT)], char_delay=0.015)
    t += 0.15
    t = add_typed_qa(events, t, "  Avoid?        ", DIM,
                     [("high-risk airspace", WHITE)], char_delay=0.015)

    # Phase 2b: AI parsing (instant transition, no empty frame)
    t += 0.2
    events.append(Event(t, "clear_status"))
    events.append(Event(t, "status", [("  Parsing search...", DIM)]))
    t += 0.35; events.append(Event(t, "status", [("  \u2713 ", GREEN), ("BKK DEL BOM KUL SIN BLR \u2192 HAM FRA BER MUC AMS CPH \u00b7 Mar 10-20", LIGHT)]))
    t += 0.2;  events.append(Event(t, "status", [("  \u2713 ", GREEN), ("\u20ac400 max \u00b7 economy \u00b7 1 stop \u00b7 no high-risk zones", LIGHT)]))

    # Phase 2c: scanning
    t += 0.25; events.append(Event(t, "status", [("", WHITE)]))
    t += 0.08; events.append(Event(t, "status", [("  Scanning 360 routes via Google Flights...", DIM)]))
    events.append(Event(t, "scanning_start", 1.0))
    t += 1.0;  events.append(Event(t, "scanning_end"))
    t += 0.1
    events.append(Event(t, "clear_status"))

    # Phase 3: results table (instant burst: summary + header together)
    t += 0.05; events.append(Event(t, "output", [("  6 origins \u00b7 6 destinations \u00b7 10 days = ", DIM), ("360 routes", WHITE)]))
    events.append(Event(t + 0.01, "output", [("", WHITE)]))
    events.append(Event(t + 0.02, "output", [("  #  Destination      Price   Origin       Duration", DIM)]))
    events.append(Event(t + 0.03, "output", [("  -  --------------  ------  -----------  --------", FAINT)]))
    t += 0.15; events.append(Event(t, "output_hl", [("  1  Amsterdam        ", ACCENT), ("\u20ac289", GREEN), ("   Bangkok       13h 40m", ACCENT)]))
    t += 0.15; events.append(Event(t, "output_zebra", [("  2  Frankfurt        ", LIGHT), ("\u20ac298", GREEN), ("   Bangkok       11h 30m", LIGHT)]))
    t += 0.15; events.append(Event(t, "output", [("  3  Berlin           ", LIGHT), ("\u20ac312", GREEN), ("   KL            14h 15m", LIGHT)]))
    t += 0.15; events.append(Event(t, "output_zebra", [("  4  Munich           ", LIGHT), ("\u20ac315", GREEN), ("   Delhi         10h 20m", LIGHT)]))
    t += 0.15; events.append(Event(t, "output", [("  5  Copenhagen       ", LIGHT), ("\u20ac345", GREEN), ("   Singapore     15h 10m", LIGHT)]))
    t += 0.15; events.append(Event(t, "output_zebra", [("  6  Hamburg          ", LIGHT), ("\u20ac357", GREEN), ("   Bangalore     16h 30m", LIGHT)]))

    # Recommendations
    t += 0.3;  events.append(Event(t, "output", [("", WHITE)]))
    t += 0.18; events.append(Event(t, "output_hl2", [("  TOP PICK  ", GREEN), (" Amsterdam \u20ac289", WHITE)]))
    t += 0.12; events.append(Event(t, "output", [("  Cheapest of 360 routes. Bangkok \u2192 AMS via Helsinki.", LIGHT)]))
    t += 0.3;  events.append(Event(t, "output", [("", WHITE)]))
    t += 0.18; events.append(Event(t, "output_hl_blue", [("  FASTEST   ", BLUE), (" Delhi \u2192 Munich \u20ac315", WHITE)]))
    t += 0.12; events.append(Event(t, "output", [("  10h 20m nonstop on Lufthansa. Arrives same day.", LIGHT)]))

    # Footer
    t += 0.25; events.append(Event(t, "output", [("", WHITE)]))
    t += 0.15; events.append(Event(t, "output", [("  [i] Prices as of today \u00b7 sorted by price + travel time", DIM)]))

    # Done - hold for reading
    t += 0.3;  events.append(Event(t, "done"))

    total_duration = t + 3.0
    events.sort(key=lambda e: e.time)
    return events, total_duration


# ── State ────────────────────────────────────────────────────────
class State:
    def __init__(self):
        self.prompt_visible = False
        self.typed = ""
        self.command_committed = False
        self.committed_command = ""
        self.status_lines = []
        self.output_lines = []  # list of (segments, hl_type, added_time)
        self.output_done = False
        self.hl2_time = None
        self.typing_active = False
        self.typing_buffer = []
        self.scanning = False
        self.scanning_start = 0.0
        self.scanning_duration = 0.0
        self.flash_time = None


# ── Background ───────────────────────────────────────────────────
def _make_orb(color, anchor_x, anchor_y, alpha_range=(0.15, 0.28), blur_range=(120, 180)):
    import random as _rnd
    r, g, b = color
    alpha = int(255 * _rnd.uniform(*alpha_range))
    blur_r = _rnd.randint(*blur_range)
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    jx = _rnd.randint(-int(W * 0.15), int(W * 0.15))
    jy = _rnd.randint(-int(H * 0.1), int(H * 0.1))
    cx = int(anchor_x * W) + jx
    cy = int(anchor_y * H) + jy
    rx = _rnd.randint(int(W * 0.3), int(W * 0.55))
    ry = _rnd.randint(int(H * 0.2), int(H * 0.4))
    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=(r, g, b, alpha))
    return layer.filter(ImageFilter.GaussianBlur(blur_r))


def _make_vignette(strength=100):
    mask = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(mask)
    mx, my = int(W * 0.15), int(H * 0.1)
    d.ellipse([mx, my, W - mx, H - my], fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(W // 4))
    vig = Image.new("RGBA", (W, H), (0, 0, 0, strength))
    vig.putalpha(Image.eval(mask, lambda x: max(0, strength - int(x * strength // 255))))
    return vig


def _make_grain(intensity=12, density=0.4):
    rng = np.random.default_rng(42)
    noise = rng.integers(-intensity, intensity + 1, size=(H, W), dtype=np.int16)
    m = rng.random(size=(H, W)) < density
    noise = noise * m
    arr = np.full((H, W, 4), 0, dtype=np.uint8)
    pos = noise > 0
    neg = noise < 0
    arr[pos, 0] = arr[pos, 1] = arr[pos, 2] = 255
    arr[pos, 3] = np.clip(noise[pos], 0, 255).astype(np.uint8)
    arr[neg, 3] = np.clip(-noise[neg], 0, 255).astype(np.uint8)
    return Image.fromarray(arr, "RGBA")


def draw_bg(img):
    import random
    random.seed(7)
    teal = (120, 160, 150)
    steel = (100, 130, 170)
    mint = (100, 185, 130)
    orbs = [
        (teal,  0.0, 0.0, (0.35, 0.50)),
        (steel, 1.0, 1.0, (0.30, 0.45)),
        (teal,  0.5, 0.0, (0.20, 0.32)),
        (mint,  0.5, 0.45, (0.14, 0.24)),
    ]
    for color, ax, ay, ar in orbs:
        img = Image.alpha_composite(img, _make_orb(color, ax, ay, alpha_range=ar))
    img = Image.alpha_composite(img, _make_vignette(strength=95))
    # Subtle green-tinted gradient at bottom for grounding
    bottom = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(bottom)
    for i in range(60):
        alpha = int(10 * (1 - i / 60))
        y = H - 60 + i
        bd.line([(0, y), (W, y)], fill=(80, 170, 110, alpha))
    img = Image.alpha_composite(img, bottom)
    img = Image.alpha_composite(img, _make_grain())
    return img


# ── Window ───────────────────────────────────────────────────────
def draw_window(img):
    if img.mode != "RGBA":
        img = img.convert("RGBA")

    # Soft drop shadow
    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.rounded_rectangle(
        [WIN_X, WIN_Y + 4, WIN_X + WIN_W, WIN_Y + WIN_H + 4],
        radius=WIN_R, fill=(0, 0, 0, 45)
    )
    shadow = shadow.filter(ImageFilter.GaussianBlur(12))
    img = Image.alpha_composite(img, shadow)

    # Frosted glass card
    card = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    cd = ImageDraw.Draw(card)
    cd.rounded_rectangle(
        [WIN_X, WIN_Y, WIN_X + WIN_W, WIN_Y + WIN_H],
        radius=WIN_R, fill=(255, 255, 255, 30)
    )
    cd.rounded_rectangle(
        [WIN_X, WIN_Y, WIN_X + WIN_W, WIN_Y + WIN_H],
        radius=WIN_R, outline=(255, 255, 255, 35), width=1
    )
    # Top specular highlight
    cd.line(
        [(WIN_X + WIN_R, WIN_Y + 1), (WIN_X + WIN_W - WIN_R, WIN_Y + 1)],
        fill=(255, 255, 255, 60), width=1
    )
    # Bottom grounding edge
    cd.line(
        [(WIN_X + WIN_R, WIN_Y + WIN_H - 1), (WIN_X + WIN_W - WIN_R, WIN_Y + WIN_H - 1)],
        fill=(0, 0, 0, 25), width=1
    )
    img = Image.alpha_composite(img, card)

    # Chrome title bar
    chrome = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    chd = ImageDraw.Draw(chrome)
    chd.rounded_rectangle(
        [WIN_X + 1, WIN_Y + 1, WIN_X + WIN_W - 1, WIN_Y + CHR_H],
        radius=WIN_R - 1, fill=(0, 0, 0, 20)
    )
    chd.rectangle(
        [WIN_X + 1, WIN_Y + CHR_H - WIN_R, WIN_X + WIN_W - 1, WIN_Y + CHR_H],
        fill=(0, 0, 0, 20)
    )
    chd.line(
        [(WIN_X, WIN_Y + CHR_H), (WIN_X + WIN_W, WIN_Y + CHR_H)],
        fill=(255, 255, 255, 12), width=1
    )
    img = Image.alpha_composite(img, chrome)

    # Inner shadow at top of content area for depth
    inner_sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    isd = ImageDraw.Draw(inner_sh)
    for i in range(18):
        alpha = int(12 * (1 - i / 18))
        isd.line(
            [(WIN_X + 2, WIN_Y + CHR_H + 1 + i), (WIN_X + WIN_W - 2, WIN_Y + CHR_H + 1 + i)],
            fill=(0, 0, 0, alpha)
        )
    img = Image.alpha_composite(img, inner_sh)

    draw = ImageDraw.Draw(img)
    # Traffic lights
    for i, color in enumerate([(255, 95, 87), (254, 188, 46), (40, 200, 64)]):
        cx = WIN_X + 22 + i * 24
        cy = WIN_Y + CHR_H // 2
        draw.ellipse([cx - 7, cy - 7, cx + 7, cy + 7], fill=color)
    # Window title
    draw.text(
        (WIN_X + WIN_W // 2, WIN_Y + CHR_H // 2),
        "opensky", fill=DIM, font=sans, anchor="mm"
    )

    return img


# ── Plane Icon ───────────────────────────────────────────────────
PLANE_SVG = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="{color}">
  <path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z"/>
</svg>'''

_plane_cache = None

def get_plane_icon(size=44):
    global _plane_cache
    if _plane_cache is not None:
        return _plane_cache
    r, g, b = GREEN
    svg = PLANE_SVG.format(color=f"rgb({r},{g},{b})")
    png = cairosvg.svg2png(bytestring=svg.encode(), output_width=size, output_height=size)
    _plane_cache = Image.open(io.BytesIO(png)).convert("RGBA")
    return _plane_cache


# ── Title ────────────────────────────────────────────────────────
ICON_GAP = 14  # gap between icon and text

def _title_total_width(draw):
    text_w = sum(draw.textlength(text, font=title_font) for text, _ in TITLE_PARTS)
    icon = get_plane_icon()
    return icon.width + ICON_GAP + text_w

def draw_title_glow(img):
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    total_w = _title_total_width(gd)
    text_x = (W - total_w) / 2 + get_plane_icon().width + ICON_GAP
    gd.text((text_x, TITLE_Y), TITLE_FULL, fill=(124, 223, 124, 55),
            font=title_font, anchor="la")
    glow = glow.filter(ImageFilter.GaussianBlur(35))
    return Image.alpha_composite(img, glow)


def draw_title_colored(img, draw):
    total_w = _title_total_width(draw)
    x = (W - total_w) / 2
    # Icon
    icon = get_plane_icon()
    icon_y = TITLE_Y + 2  # vertically align with text
    img.paste(icon, (int(x), icon_y), icon)
    x += icon.width + ICON_GAP
    # Text
    for text, color in TITLE_PARTS:
        draw.text((x, TITLE_Y), text, fill=color, font=title_font, anchor="la")
        x += draw.textlength(text, font=title_font)


# ── Helpers ──────────────────────────────────────────────────────
def draw_segments(draw, x, y, segments):
    for text, color in segments:
        bold = color in (GREEN, BLUE, PROMPT)
        f = mono_b if bold else mono
        draw.text((x, y), text, fill=color, font=f)
        x += draw.textlength(text, font=f)
    return x


# ── Static Background Cache ─────────────────────────────────────
_bg_cache = None


def get_static_bg():
    global _bg_cache
    if _bg_cache is not None:
        return _bg_cache.copy()

    img = Image.new("RGBA", (W, H), (*BG, 255))
    img = draw_bg(img)
    img = draw_title_glow(img)
    draw = ImageDraw.Draw(img)
    draw_title_colored(img, draw)
    draw.text((W // 2, SUBTITLE_Y), SUBTITLE_TEXT, fill=(155, 155, 160),
              font=subtitle_font, anchor="mt")
    img = draw_window(img)

    # Watermark
    draw = ImageDraw.Draw(img)
    draw.text(
        (WIN_X + WIN_W - 16, WIN_Y + WIN_H - 14),
        "@federicodeponte", fill=(50, 56, 64), font=sans, anchor="rm"
    )

    _bg_cache = img
    return _bg_cache.copy()


# ── Frame Renderer ───────────────────────────────────────────────
def render_frame(state, t):
    img = get_static_bg()
    draw = ImageDraw.Draw(img)

    y = CY
    cursor_blink = int(t * 1.875) % 2 == 0  # ~533ms blink cycle

    # Vertically offset during Q&A/parsing to reduce empty space
    if not state.output_lines:
        n = (1 if state.command_committed else (1 if state.prompt_visible else 0))
        n += len(state.status_lines)
        if state.scanning:
            n += 2
        content_h = n * LH + (4 if state.command_committed else 0)
        avail = WIN_H - CHR_H - 2 * PAD
        y += min(100, max(0, (avail - content_h) // 4))

    # Committed command line
    if state.command_committed:
        x = CX
        draw.text((x, y), "$ ", fill=PROMPT, font=mono_b)
        x += draw.textlength("$ ", font=mono_b)
        draw.text((x, y), state.committed_command, fill=WHITE, font=mono)
        y += LH + 4

    # Status lines (temporary, cleared on "clear_status")
    for i, segments in enumerate(state.status_lines):
        x_end = draw_segments(draw, CX, y, segments)
        if i == len(state.status_lines) - 1 and state.typing_active:
            x = x_end
            for ch, color in state.typing_buffer:
                bold = color in (GREEN, BLUE, PROMPT)
                f = mono_b if bold else mono
                draw.text((x, y), ch, fill=color, font=f)
                x += draw.textlength(ch, font=f)
            if len(state.typing_buffer) > 0 or cursor_blink:
                draw.rectangle([x, y + 2, x + 10, y + LH - 2], fill=CURSOR)
        y += LH

    # Progress bar during scanning
    if state.scanning:
        progress = min(1.0, (t - state.scanning_start) / state.scanning_duration)
        progress = 1 - (1 - progress) ** 2  # ease-out
        bar_x = CX + 24
        bar_y = y + 4
        bar_w = 560
        bar_h = 6
        draw.rounded_rectangle([bar_x, bar_y, bar_x + bar_w, bar_y + bar_h],
                               radius=2, fill=FAINT)
        fill_w = int(bar_w * progress)
        if fill_w > 4:
            # Soft glow behind progress bar fill
            glow_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            glow_draw = ImageDraw.Draw(glow_layer)
            glow_draw.rounded_rectangle(
                [bar_x - 4, bar_y - 6, bar_x + fill_w + 4, bar_y + bar_h + 6],
                radius=5, fill=(124, 223, 124, 35)
            )
            glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(8))
            img = Image.alpha_composite(img, glow_layer)
            draw = ImageDraw.Draw(img)
            draw.rounded_rectangle([bar_x, bar_y, bar_x + fill_w, bar_y + bar_h],
                                   radius=2, fill=GREEN)
        # Route counter (green count / dim total)
        routes_done = int(360 * progress)
        cx = bar_x + bar_w + 16
        draw.text((cx, bar_y - 4), str(routes_done), fill=GREEN, font=mono_b)
        cx += draw.textlength(str(routes_done), font=mono_b)
        draw.text((cx, bar_y - 4), "/360", fill=DIM, font=mono)
        y += bar_h + 12
        # Cycling route checks
        _routes = ["BKK\u2192HAM", "DEL\u2192FRA", "BOM\u2192MUC", "KUL\u2192BER",
                   "SIN\u2192AMS", "BLR\u2192CPH", "DEL\u2192HAM", "BKK\u2192AMS",
                   "SIN\u2192BER", "BOM\u2192FRA", "KUL\u2192CPH", "BLR\u2192MUC"]
        idx = int(t * 6) % len(_routes)
        draw.text((CX + 24, y), f"  {_routes[idx]}", fill=(60, 65, 60), font=mono)
        y += LH

    # Flash effect on scan completion (subtle green pulse)
    if state.flash_time is not None:
        elapsed = t - state.flash_time
        if elapsed < 0.18:
            flash_alpha = int(24 * (1 - elapsed / 0.18))
            flash = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            fd = ImageDraw.Draw(flash)
            fd.rounded_rectangle(
                [WIN_X + 1, WIN_Y + CHR_H + 1, WIN_X + WIN_W - 1, WIN_Y + WIN_H - 1],
                radius=WIN_R - 1, fill=(124, 223, 124, flash_alpha)
            )
            img = Image.alpha_composite(img, flash)
            draw = ImageDraw.Draw(img)

    # Output lines (permanent)
    for segments, hl_type, added_time in state.output_lines:
        if hl_type > 0:
            hl_x1 = CX - 6
            hl_x2 = WIN_X + WIN_W - PAD + 6
            hl_y1 = y - 3
            hl_y2 = y + LH + 1
            if hl_type == 2:
                # TOP PICK: glow pulse that fades over 0.4s
                glow_factor = 0.0
                if state.hl2_time is not None:
                    elapsed = t - state.hl2_time
                    if elapsed < 1.5:
                        glow_factor = 1.0 - (elapsed / 1.5)

                if glow_factor > 0:
                    glow_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                    glow_draw = ImageDraw.Draw(glow_layer)
                    glow_alpha = int(80 * glow_factor)
                    glow_draw.rounded_rectangle(
                        [hl_x1 - 14, hl_y1 - 14, hl_x2 + 14, hl_y2 + 14], radius=10,
                        fill=(124, 223, 124, glow_alpha)
                    )
                    glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(16))
                    img = Image.alpha_composite(img, glow_layer)

                fill_a = 18 + int(22 * glow_factor)
                outline_a = 65 + int(35 * glow_factor)
                hl_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                hl_draw = ImageDraw.Draw(hl_layer)
                hl_draw.rounded_rectangle(
                    [hl_x1, hl_y1, hl_x2, hl_y2], radius=4,
                    fill=(124, 223, 124, fill_a),
                    outline=(124, 223, 124, outline_a),
                    width=1
                )
                img = Image.alpha_composite(img, hl_layer)
            elif hl_type == 3:
                # Subtle blue highlight for FASTEST
                hl_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                hl_draw = ImageDraw.Draw(hl_layer)
                hl_draw.rounded_rectangle(
                    [hl_x1, hl_y1, hl_x2, hl_y2], radius=4,
                    fill=(90, 159, 212, 22),
                    outline=(90, 159, 212, 65),
                    width=1
                )
                img = Image.alpha_composite(img, hl_layer)
            elif hl_type == 4:
                # Zebra stripe for even data rows
                hl_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                hl_draw = ImageDraw.Draw(hl_layer)
                hl_draw.rounded_rectangle(
                    [hl_x1, hl_y1, hl_x2, hl_y2], radius=3,
                    fill=(255, 255, 255, 18)
                )
                img = Image.alpha_composite(img, hl_layer)
            else:
                # Subtle accent highlight for #1 data row
                hl_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                hl_draw = ImageDraw.Draw(hl_layer)
                hl_draw.rounded_rectangle(
                    [hl_x1, hl_y1, hl_x2, hl_y2], radius=4,
                    fill=(139, 154, 123, 30),
                    outline=(139, 154, 123, 80),
                    width=1
                )
                img = Image.alpha_composite(img, hl_layer)
            draw = ImageDraw.Draw(img)
        # Slide-in + fade animation for new rows
        row_age = t - added_time
        anim_dur = 0.2
        x_draw = CX
        if 0 < row_age < anim_dur:
            ease = row_age / anim_dur
            ease = 1 - (1 - ease) ** 3  # ease-out cubic
            x_draw = CX + int(20 * (1 - ease))
            # Fade: draw on alpha layer
            row_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            row_draw = ImageDraw.Draw(row_layer)
            draw_segments(row_draw, x_draw, y, segments)
            row_layer.putalpha(
                Image.eval(row_layer.getchannel("A"),
                           lambda a: int(a * (0.4 + 0.6 * ease))))
            img = Image.alpha_composite(img, row_layer)
            draw = ImageDraw.Draw(img)
        else:
            draw_segments(draw, x_draw, y, segments)
        y += LH

    # Current typing line (before enter)
    if state.prompt_visible and not state.command_committed:
        x = CX
        draw.text((x, y), "$ ", fill=PROMPT, font=mono_b)
        x += draw.textlength("$ ", font=mono_b)
        draw.text((x, y), state.typed, fill=WHITE, font=mono)
        x += draw.textlength(state.typed, font=mono)
        typing_active = len(state.typed) > 0 and len(state.typed) < len(COMMAND)
        if typing_active or cursor_blink:
            draw.rectangle([x, y + 2, x + 10, y + LH - 2], fill=CURSOR)

    # Prompt cursor after output done
    if state.output_done and cursor_blink:
        x = CX
        draw.text((x, y), "$ ", fill=PROMPT, font=mono_b)
        x += draw.textlength("$ ", font=mono_b)
        draw.rectangle([x, y + 2, x + 10, y + LH - 2], fill=CURSOR)

    return img.convert("RGB")


# ── Event Processing ─────────────────────────────────────────────
def apply_event(state, e):
    if e.kind == "show_prompt":
        state.prompt_visible = True
    elif e.kind == "type_char":
        state.typed += e.data
    elif e.kind == "enter":
        state.command_committed = True
        state.committed_command = state.typed
        state.typed = ""
    elif e.kind == "status":
        state.status_lines.append(list(e.data))
    elif e.kind == "clear_status":
        state.status_lines = []
    elif e.kind == "typing_start":
        state.typing_active = True
        state.typing_buffer = []
    elif e.kind == "type_answer":
        state.typing_buffer.append((e.data["char"], e.data["color"]))
    elif e.kind == "typing_stop":
        if state.status_lines and state.typing_buffer:
            segs, cur_text, cur_color = [], "", None
            for ch, color in state.typing_buffer:
                if color != cur_color:
                    if cur_text:
                        segs.append((cur_text, cur_color))
                    cur_text, cur_color = ch, color
                else:
                    cur_text += ch
            if cur_text:
                segs.append((cur_text, cur_color))
            state.status_lines[-1].extend(segs)
        state.typing_active = False
        state.typing_buffer = []
    elif e.kind == "scanning_start":
        state.scanning = True
        state.scanning_start = e.time
        state.scanning_duration = e.data
    elif e.kind == "scanning_end":
        state.scanning = False
        state.flash_time = e.time
    elif e.kind == "output":
        state.output_lines.append((e.data, 0, e.time))
    elif e.kind == "output_hl":
        state.output_lines.append((e.data, 1, e.time))
    elif e.kind == "output_hl2":
        state.output_lines.append((e.data, 2, e.time))
        state.hl2_time = e.time
    elif e.kind == "output_zebra":
        state.output_lines.append((e.data, 4, e.time))
    elif e.kind == "output_hl_blue":
        state.output_lines.append((e.data, 3, e.time))
    elif e.kind == "done":
        state.output_done = True


# ── Main ─────────────────────────────────────────────────────────
def main():
    events, duration = build_events()
    total_frames = int(duration * FPS)
    output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "opensky-demo.mp4")

    # Build final state for LinkedIn thumbnail (frame 0)
    thumb_state = State()
    for e in events:
        apply_event(thumb_state, e)

    print(f"Rendering {total_frames + 1} frames ({duration:.1f}s @ {FPS}fps)...")

    proc = subprocess.Popen(
        [
            "ffmpeg", "-y",
            "-f", "rawvideo", "-vcodec", "rawvideo",
            "-s", f"{W}x{H}", "-pix_fmt", "rgb24",
            "-r", str(FPS),
            "-i", "-",
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-crf", "18", "-preset", "medium",
            "-movflags", "+faststart",
            output_path,
        ],
        stdin=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    # Frame 0: final state as thumbnail (use late time so glow effects have settled)
    thumb = render_frame(thumb_state, duration - 0.5)
    proc.stdin.write(thumb.tobytes())

    # Normal animation
    state = State()
    event_idx = 0

    for frame_num in range(total_frames):
        t = frame_num / FPS
        while event_idx < len(events) and events[event_idx].time <= t:
            apply_event(state, events[event_idx])
            event_idx += 1

        img = render_frame(state, t)
        proc.stdin.write(img.tobytes())
        if frame_num % 60 == 0:
            pct = int(frame_num / total_frames * 100)
            print(f"  {pct}% ({frame_num}/{total_frames})")

    proc.stdin.close()
    proc.wait()
    print(f"\nDone! {output_path}")
    print(f"Duration: {duration:.1f}s | Size: {os.path.getsize(output_path) / 1024:.0f}KB")


if __name__ == "__main__":
    main()
