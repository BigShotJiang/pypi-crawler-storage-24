"""CLI tests for provider-related flags and error paths."""

import os
from datetime import date, timedelta
from unittest.mock import patch

from typer.testing import CliRunner

from opensky.cli import _parse_date, app

runner = CliRunner()


def test_invalid_provider_name():
    result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--provider", "fake"])
    assert result.exit_code == 1
    assert "Unknown provider: fake" in result.output


def test_duffel_missing_env_var():
    with patch.dict(os.environ, {}, clear=True):
        result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--source", "duffel"])
    assert result.exit_code == 1
    assert "not configured" in result.output


def test_amadeus_missing_env_vars():
    with patch.dict(os.environ, {}, clear=True):
        result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--source", "amadeus"])
    assert result.exit_code == 1
    assert "not configured" in result.output


def test_old_provider_flag_still_works():
    """--provider is an alias for --source."""
    with patch.dict(os.environ, {}, clear=True):
        result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--provider", "duffel"])
    assert result.exit_code == 1
    assert "not configured" in result.output


def test_past_date_rejected():
    result = runner.invoke(app, ["search", "BLR", "HAM", "2020-01-01"])
    assert result.exit_code == 1
    assert "in the past" in result.output


def test_invalid_date_rejected():
    result = runner.invoke(app, ["search", "BLR", "HAM", "not-a-date"])
    assert result.exit_code == 1
    assert "Cannot parse date" in result.output


def test_invalid_source_name():
    """--source with unknown provider gives clear error."""
    result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--source", "fake"])
    assert result.exit_code == 1
    assert "Unknown provider: fake" in result.output


def test_city_name_resolves_in_search():
    """City names resolve to IATA codes (exits at provider stage, not city resolution)."""
    result = runner.invoke(app, ["search", "bangalore", "hamburg", "2026-03-10", "--source", "fake"])
    # Should fail at provider validation, not city resolution
    assert "Unknown provider: fake" in result.output


def test_stops_invalid_value_rejected():
    result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--stops", "garbage"])
    assert result.exit_code == 1
    assert "Unknown stops value" in result.output


def test_stops_nonstop_alias_accepted():
    """'nonstop' and '0' are valid aliases for non_stop."""
    result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--stops", "nonstop", "--source", "fake"])
    assert "Unknown stops value" not in result.output
    assert "Unknown provider" in result.output  # fails at provider, not stops

    result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--stops", "0", "--source", "fake"])
    assert "Unknown stops value" not in result.output


# ── Cabin validation ──

def test_cabin_invalid_rejected():
    result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--class", "buisness"])
    assert result.exit_code == 1
    assert "Unknown class: buisness" in result.output
    assert "economy, premium, business, first" in result.output


def test_cabin_valid_passes_through():
    """Valid cabin classes pass validation (fail later at search stage)."""
    for cabin in ("economy", "premium", "business", "first"):
        result = runner.invoke(app, ["search", "BLR", "HAM", "2026-03-10", "--class", cabin, "--source", "fake"])
        assert "Unknown class" not in result.output


# ── Date parsing ──

def test_parse_date_iso():
    assert _parse_date("2026-03-15") == "2026-03-15"


def test_parse_date_tomorrow():
    expected = (date.today() + timedelta(days=1)).isoformat()
    assert _parse_date("tomorrow") == expected


def test_parse_date_today():
    assert _parse_date("today") == date.today().isoformat()


def test_parse_date_month_day():
    result = _parse_date("mar 15")
    assert result.endswith("-03-15")


def test_parse_date_full_month():
    result = _parse_date("march 15")
    assert result.endswith("-03-15")


def test_parse_date_next_monday():
    result = _parse_date("next monday")
    d = date.fromisoformat(result)
    assert d.weekday() == 0  # Monday
    assert d > date.today()


def test_parse_date_invalid():
    import pytest
    with pytest.raises(ValueError, match="Cannot parse date"):
        _parse_date("gibberish")


# ── Config init --quick ──

def test_config_init_quick(tmp_path):
    output = str(tmp_path / "test.toml")
    result = runner.invoke(app, ["config", "init", "--quick", "-o", output])
    assert result.exit_code == 0
    assert "Created" in result.output


# ── Welcome message ──

def test_no_args_shows_welcome():
    result = runner.invoke(app, [])
    assert result.exit_code == 0
    assert "Quick start" in result.output
    assert "opensky demo" in result.output


# ── No --install-completion ──

def test_no_install_completion_in_help():
    result = runner.invoke(app, ["--help"])
    assert "--install-completion" not in result.output
