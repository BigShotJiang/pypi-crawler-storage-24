"""Tests for airport resolution and city name lookup."""

import pytest

from opensky.airports import city_name, resolve_airport


def test_resolve_iata_code():
    assert resolve_airport("BLR") == "BLR"
    assert resolve_airport("blr") == "BLR"
    assert resolve_airport("HAM") == "HAM"


def test_resolve_city_name_exact():
    assert resolve_airport("bangalore") == "BLR"
    assert resolve_airport("Hamburg") == "HAM"


def test_resolve_city_name_case_insensitive():
    assert resolve_airport("BANGALORE") == "BLR"
    assert resolve_airport("hamburg") == "HAM"


def test_resolve_unknown_raises_non_interactive():
    with pytest.raises(ValueError, match="Unknown airport or city"):
        resolve_airport("zzzzzznotacity", interactive=False)


def test_resolve_unknown_raises_interactive():
    """Unknown airport raises ValueError even in interactive mode."""
    with pytest.raises(ValueError, match="Unknown airport or city"):
        resolve_airport("zzzzzznotacity")


def test_resolve_ambiguous_city_raises_non_interactive():
    """London has multiple airports, non-interactive raises ValueError."""
    with pytest.raises(ValueError, match="Ambiguous airport"):
        resolve_airport("london", interactive=False)


def test_resolve_ambiguous_city_has_suggestions():
    """ValueError message includes airport codes as suggestions."""
    with pytest.raises(ValueError) as exc_info:
        resolve_airport("london", interactive=False)
    msg = str(exc_info.value)
    assert "LHR" in msg or "LGW" in msg or "STN" in msg


def test_resolve_substring_ambiguous_raises_non_interactive():
    """Partial city name matching multiple cities raises ValueError."""
    with pytest.raises(ValueError, match="Ambiguous airport"):
        resolve_airport("frank", interactive=False)


def test_resolve_iata_case_insensitive():
    """Both 'del' and 'DEL' resolve to DEL (case-insensitive IATA lookup)."""
    assert resolve_airport("DEL") == "DEL"
    assert resolve_airport("del") == "DEL"


def test_city_name_known():
    assert city_name("BLR") == "Bangalore"
    assert city_name("HAM") == "Hamburg"
    assert city_name("DXB") == "Dubai"


def test_city_name_unknown():
    assert city_name("ZZZ") == "ZZZ"


def test_empty_query_raises_non_interactive():
    with pytest.raises(ValueError, match="cannot be empty"):
        resolve_airport("", interactive=False)
