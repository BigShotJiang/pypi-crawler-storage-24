"""Airport code resolution and city name lookup."""

from __future__ import annotations

import re
import sys

import airportsdata

_db: dict[str, dict] | None = None
_city_index: dict[str, list[str]] | None = None


def _get_db() -> dict[str, dict]:
    global _db
    if _db is None:
        _db = airportsdata.load("IATA")
    return _db


def _get_city_index() -> dict[str, list[str]]:
    """Build a lowercase city name -> list of IATA codes index."""
    global _city_index
    if _city_index is None:
        _city_index = {}
        for iata, info in _get_db().items():
            city = info.get("city", "").lower()
            if city:
                _city_index.setdefault(city, []).append(iata)
    return _city_index


def _is_commercial(code: str) -> bool:
    """Filter out military bases and non-commercial airports."""
    db = _get_db()
    info = db.get(code, {})
    name = info.get("name", "").lower()
    # Filter military, RAF, AFB, heliports
    skip = ("raf ", "afb ", "air force", "military", "heliport", "air base")
    return not any(kw in name for kw in skip)


def _pick_main_airport(codes: list[str], city: str) -> str | None:
    """If one airport is clearly the main commercial one, return it.

    Filters non-commercial airports first. Among remaining, prefers
    the airport whose name matches "[City] (International) Airport".
    For multi-country matches (e.g. London UK vs London Canada),
    picks the country with more airports (likely the major city).
    """
    db = _get_db()
    commercial = [c for c in codes if _is_commercial(c)]
    if not commercial:
        return None
    if len(commercial) == 1:
        return commercial[0]

    # Group by country, pick the country with the most airports
    by_country: dict[str, list[str]] = {}
    for c in commercial:
        country = db[c].get("country", "")
        by_country.setdefault(country, []).append(c)

    if len(by_country) > 1:
        # Pick the country group with most airports (London UK > London Canada)
        biggest = max(by_country.values(), key=len)
        if len(biggest) == 1:
            return biggest[0]
        commercial = biggest

    simple_pattern = re.compile(
        rf"^{re.escape(city)}\s+(international\s+)?airport$", re.IGNORECASE,
    )
    candidates = [c for c in commercial if simple_pattern.match(db[c].get("name", ""))]
    if len(candidates) == 1:
        return candidates[0]
    return None


def _format_options(codes: list[str]) -> list[tuple[str, str]]:
    """Return (code, label) pairs for airport codes."""
    db = _get_db()
    return [
        (c, f"{c}  {db[c].get('name', c)} ({db[c].get('country', '')})")
        for c in sorted(codes)
    ]


def _prompt_choice(codes: list[str], query: str) -> str:
    """Show numbered list and prompt user to pick an airport."""
    options = _format_options(codes)
    print(f"Multiple airports for '{query}':", file=sys.stderr)
    for i, (code, label) in enumerate(options, 1):
        print(f"  {i}. {label}", file=sys.stderr)
    while True:
        try:
            choice = input("Pick a number: ").strip()
        except (EOFError, KeyboardInterrupt):
            print(file=sys.stderr)
            sys.exit(1)
        if choice.isdigit() and 1 <= int(choice) <= len(options):
            return options[int(choice) - 1][0]
        print(f"Enter 1-{len(options)}.", file=sys.stderr)


def _ambiguity_error(codes: list[str], query: str) -> ValueError:
    """Build a ValueError with suggestions for non-interactive mode."""
    db = _get_db()
    labels = ", ".join(f"{c} ({db[c].get('city', c)})" for c in sorted(codes)[:10])
    return ValueError(f"Ambiguous airport '{query}'. Options: {labels}")


def resolve_airport(query: str, interactive: bool = True) -> str:
    """Resolve a city name or IATA code to an IATA code.

    - 3-letter uppercase code in airportsdata: return as-is
    - Otherwise: case-insensitive match against city names
    - Exactly one match: return it
    - Multiple matches from same city with one "main" airport: return it
    - Multiple matches + interactive + tty: prompt user to pick
    - Multiple matches otherwise: raise ValueError with suggestions
    - No match: raise ValueError (interactive) or sys.exit (legacy)
    """
    if not query or not query.strip():
        raise ValueError("Airport or city name cannot be empty.")

    db = _get_db()

    # Direct IATA code (case-insensitive)
    upper = query.upper()
    if len(upper) == 3 and upper in db:
        return upper

    # Fuzzy match against city names
    q = query.lower()
    idx = _get_city_index()

    # Exact city match first
    if q in idx:
        codes = idx[q]
        if len(codes) == 1:
            return codes[0]
        # Try to pick the main commercial airport
        main = _pick_main_airport(codes, query)
        if main:
            return main
        # Show only commercial airports with city + country
        commercial = [c for c in codes if _is_commercial(c)]
        if not commercial:
            commercial = codes
        if interactive and sys.stdin.isatty():
            return _prompt_choice(commercial, query)
        raise _ambiguity_error(commercial, query)

    # Substring match
    matches: list[str] = []
    for city, codes in idx.items():
        if q in city:
            matches.extend(codes)

    if len(matches) == 1:
        return matches[0]

    if len(matches) > 1:
        # Deduplicate while preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for code in matches:
            if code not in seen:
                seen.add(code)
                unique.append(code)
        if interactive and sys.stdin.isatty():
            return _prompt_choice(unique[:10], query)
        raise _ambiguity_error(unique, query)

    raise ValueError(f"Unknown airport or city: {query}")


def city_name(iata: str) -> str:
    """Return city name for an IATA code, or the code itself if not found."""
    db = _get_db()
    info = db.get(iata)
    return info["city"] if info and info.get("city") else iata
