from __future__ import annotations

import calendar
import sys
from datetime import date as date_cls, timedelta
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console

from opensky import __version__

app = typer.Typer(
    name="opensky",
    help="Search hundreds of flights in minutes, not hours.",
    no_args_is_help=False,
    add_completion=False,
)
console = Console()


VALID_PROVIDERS = ("google", "duffel", "amadeus")
VALID_CABINS = {"economy", "premium", "premium_economy", "business", "first"}

# Map friendly stops values to the internal names
STOPS_ALIASES: dict[str, str] = {
    "any": "any",
    "nonstop": "non_stop",
    "non_stop": "non_stop",
    "0": "non_stop",
    "1": "one_stop_or_fewer",
    "one_stop_or_fewer": "one_stop_or_fewer",
    "2": "two_or_fewer_stops",
    "two_or_fewer_stops": "two_or_fewer_stops",
}

# Day names for _parse_date
_DAYS = {name.lower(): i for i, name in enumerate(calendar.day_name)}
# Month names for _parse_date
_MONTHS = {name.lower(): i for i, name in enumerate(calendar.month_name) if name}
_MONTHS_ABBR = {name.lower(): i for i, name in enumerate(calendar.month_abbr) if name}


def _normalize_stops(value: str) -> str:
    """Map friendly stop values to internal names. Exits on invalid input."""
    result = STOPS_ALIASES.get(value)
    if result is None:
        console.print(f"[red]Unknown stops value: {value}. Use: any, nonstop, 0, 1, 2.[/red]")
        raise typer.Exit(1)
    return result


def _validate_cabin(value: str) -> str:
    """Validate cabin class. Exits on invalid input."""
    if value not in VALID_CABINS:
        console.print(f"[red]Unknown class: {value}. Use: economy, premium, business, first.[/red]")
        raise typer.Exit(1)
    return value


def _parse_date(s: str) -> str:
    """Parse flexible date input to YYYY-MM-DD.

    Accepts: YYYY-MM-DD, "tomorrow", "next monday", "mar 15", "march 15".
    Returns YYYY-MM-DD string. Raises ValueError on unrecognized input.
    """
    s = s.strip().lower()
    today = date_cls.today()

    # Standard ISO format
    try:
        date_cls.fromisoformat(s)
        return s
    except ValueError:
        pass

    # "today"
    if s == "today":
        return today.isoformat()

    # "tomorrow"
    if s == "tomorrow":
        return (today + timedelta(days=1)).isoformat()

    # "next monday", "next tuesday", etc.
    if s.startswith("next "):
        day_name = s[5:].strip()
        if day_name in _DAYS:
            target = _DAYS[day_name]
            days_ahead = (target - today.weekday()) % 7
            if days_ahead == 0:
                days_ahead = 7
            return (today + timedelta(days=days_ahead)).isoformat()

    # "mar 15", "march 15", "Mar 15"
    parts = s.split()
    if len(parts) == 2:
        month_str, day_str = parts
        month = _MONTHS.get(month_str) or _MONTHS_ABBR.get(month_str)
        if month and day_str.isdigit():
            day = int(day_str)
            # Pick year: this year if future, next year if past
            try:
                candidate = date_cls(today.year, month, day)
                if candidate < today:
                    candidate = date_cls(today.year + 1, month, day)
                return candidate.isoformat()
            except ValueError:
                pass

    raise ValueError(f"Cannot parse date: {s}. Use YYYY-MM-DD, tomorrow, next monday, mar 15, etc.")


def _friendly_date(iso_date: str) -> str:
    """Format '2026-03-10' as 'Mar 10'."""
    try:
        d = date_cls.fromisoformat(iso_date)
        return f"{d.strftime('%b')} {d.day}"
    except (ValueError, TypeError):
        return iso_date


def _validate_provider(provider: str | None) -> None:
    if provider is not None and provider not in VALID_PROVIDERS:
        console.print(f"[red]Unknown provider: {provider}. Choose from: {', '.join(VALID_PROVIDERS)}.[/red]")
        console.print("[dim]Set the required env vars (see README).[/dim]")
        raise typer.Exit(1)


def version_callback(value: bool) -> None:
    if value:
        console.print(f"opensky {__version__}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Annotated[
        Optional[bool],
        typer.Option("--version", "-v", callback=version_callback, is_eager=True),
    ] = None,
) -> None:
    if ctx.invoked_subcommand is None:
        console.print(
            "\n[bold]opensky[/bold] - Search hundreds of flights in minutes.\n\n"
            "Quick start:\n"
            "  [green]opensky demo[/green]                         See example output\n"
            "  [green]opensky config init[/green]                  Set up a multi-route scan\n"
            "  [green]opensky search city city YYYY-MM-DD[/green]  Search one route\n\n"
            "opensky --help for all options.\n"
        )


@app.command()
def search(
    origin: Annotated[str, typer.Argument(help="Origin airport or city name")],
    destination: Annotated[str, typer.Argument(help="Destination airport or city name")],
    date: Annotated[str, typer.Argument(help="Travel date (YYYY-MM-DD, tomorrow, mar 15, etc.)")],
    currency: Annotated[str, typer.Option("--currency", "-c", help="Currency code (EUR, USD, GBP, etc.)")] = "EUR",
    cabin: Annotated[str, typer.Option("--class", "--cabin", help="economy, premium, business, or first")] = "economy",
    stops: Annotated[str, typer.Option("--stops", help="nonstop, 1, 2, or any (default)")] = "any",
    max_price: Annotated[float, typer.Option("--max-price", help="Maximum price (e.g. 500). 0 = no limit")] = 0,
    include_risky: Annotated[bool, typer.Option("--include-risky", "--show-risky", help="Include flights through conflict zones")] = False,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
    csv_output: Annotated[bool, typer.Option("--csv", help="Output as CSV")] = False,
    fresh: Annotated[bool, typer.Option("--fresh", "--no-cache", help="Skip cached results, search fresh")] = False,
    proxy: Annotated[Optional[str], typer.Option("--proxy", help="HTTP proxy (e.g. http://host:port)")] = None,
    source: Annotated[Optional[str], typer.Option("--source", "--provider", "-p", help="Flight data source: google, duffel, amadeus")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Save results to file")] = None,
) -> None:
    """Search flights for a single route."""
    from opensky.airports import city_name, resolve_airport
    from opensky import display
    from opensky.models import RiskLevel
    from opensky.safety import zones_age_warning
    from opensky.search import SearchEngine

    try:
        origin = resolve_airport(origin)
        destination = resolve_airport(destination)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)
    stops = _normalize_stops(stops)
    cabin = _validate_cabin(cabin)

    origin_city = city_name(origin)
    dest_city = city_name(destination)

    # Parse flexible date input
    try:
        date = _parse_date(date)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    date_label = _friendly_date(date)

    # Validate date is not in the past
    d = date_cls.fromisoformat(date)
    if d < date_cls.today():
        console.print(f"[red]Date {date} is in the past.[/red]")
        raise typer.Exit(1)

    _validate_provider(source)

    warning = zones_age_warning()
    if warning:
        console.print(f"[yellow]{warning}[/yellow]")

    try:
        engine = SearchEngine(
            currency=currency,
            proxy=proxy,
            use_cache=not fresh,
            seat=cabin,
            stops=stops,
            provider=source,
        )
    except ValueError as e:
        msg = str(e)
        if "not set" in msg or "must both be set" in msg:
            console.print(f"[red]{source.capitalize() if source else 'Provider'} not configured. Set the required env vars (see README).[/red]")
        else:
            console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(f"[dim]Searching flights from {origin_city} to {dest_city} on {date_label}...[/dim]")

    # Always search unfiltered, then split safe/risky in CLI for messaging
    try:
        all_results = engine.search_scored(
            origin, destination, date,
            risk_threshold=None,
            max_price=max_price,
        )
    except Exception as e:
        console.print(f"[red]Search failed: {e}[/red]")
        raise typer.Exit(1)
    finally:
        engine.close()

    if not all_results:
        if max_price > 0:
            console.print(f"[dim]No flights found from {origin_city} to {dest_city} on {date_label} under {display.format_price(max_price, currency)}.[/dim]")
        else:
            console.print(f"[dim]No flights found from {origin_city} to {dest_city} on {date_label}.[/dim]")
        raise typer.Exit()

    safe = [sf for sf in all_results if sf.risk.risk_level < RiskLevel.HIGH_RISK]
    risky = [sf for sf in all_results if sf.risk.risk_level >= RiskLevel.HIGH_RISK]
    results = all_results if include_risky else safe

    if not results:
        console.print("[dim]No safe flights found. Use --include-risky to see all options.[/dim]")
        raise typer.Exit()

    results.sort(key=lambda x: x.score)

    if json_output:
        text = display.flights_json(results)
        if output:
            Path(output).write_text(text)
            console.print(f"Saved to {output}")
        else:
            print(text)
    elif csv_output:
        text = display.flights_csv(results)
        if output:
            Path(output).write_text(text)
            console.print(f"Saved to {output}")
        else:
            print(text)
    else:
        display.flights_table(results, title="Flights")
        if not include_risky and risky:
            console.print(
                f"[dim]{len(risky)} more flights available via conflict zones. "
                f"Use --include-risky to see all.[/dim]"
            )
        if output:
            text = display.flights_json(results)
            Path(output).write_text(text)
            console.print(f"Saved to {output}")


@app.command()
def scan(
    config_path: Annotated[str, typer.Option("--config", "-f", help="TOML config file")],
    workers: Annotated[int, typer.Option("--workers", "-w", help="Parallel searches (default: 3)")] = 3,
    delay: Annotated[float, typer.Option("--delay", help="Seconds between batches (default: 1.0)")] = 1.0,
    max_price: Annotated[float, typer.Option("--max-price", help="Maximum price, overrides config (0 = no limit)")] = 0,
    all_flights: Annotated[bool, typer.Option("--all-flights", "--detail", help="Show all individual flights instead of summary")] = False,
    include_risky: Annotated[bool, typer.Option("--include-risky", "--show-risky", help="Include flights through conflict zones")] = False,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
    csv_output: Annotated[bool, typer.Option("--csv", help="Output as CSV")] = False,
    fresh: Annotated[bool, typer.Option("--fresh", "--no-cache", help="Skip cached results, search fresh")] = False,
    proxy: Annotated[Optional[str], typer.Option("--proxy", help="HTTP proxy (e.g. http://host:port)")] = None,
    source: Annotated[Optional[str], typer.Option("--source", "--provider", "-p", help="Flight data source: google, duffel, amadeus")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Save results to file")] = None,
) -> None:
    """Search every combination of origins, destinations, and dates at once."""
    from opensky import display
    from opensky.config import load_config
    from opensky.models import RiskLevel
    from opensky.safety import zones_age_warning
    from opensky.search import SearchEngine

    _validate_provider(source)

    warning = zones_age_warning()
    if warning:
        console.print(f"[yellow]{warning}[/yellow]")

    try:
        cfg = load_config(config_path)
    except FileNotFoundError:
        console.print(f"[red]Config file not found: {config_path}[/red]")
        console.print("[dim]Run 'opensky config init' to create one.[/dim]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Invalid config file: {e}[/red]")
        raise typer.Exit(1)

    # CLI --max-price overrides config value
    if max_price > 0:
        cfg.search.max_price = max_price

    dates = cfg.search.date_range.dates()
    total = len(cfg.search.origins) * len(cfg.search.destinations) * len(dates)

    try:
        engine = SearchEngine(
            currency=cfg.search.currency,
            proxy=proxy,
            use_cache=not fresh,
            seat=cfg.search.cabin,
            stops=cfg.search.stops,
            provider=source,
        )
    except ValueError as e:
        msg = str(e)
        if "not set" in msg or "must both be set" in msg:
            console.print(f"[red]{source.capitalize() if source else 'Provider'} not configured. Set the required env vars (see README).[/red]")
        else:
            console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    names = ", ".join(p.name for p in engine._providers)
    provider_info = f" via {names}"

    console.print(
        f"Scanning {len(cfg.search.origins)} origins x "
        f"{len(cfg.search.destinations)} destinations x "
        f"{len(dates)} dates = {total} combos{provider_info}"
    )

    progress = display.scan_progress()
    with progress:
        task = progress.add_task("Scanning", total=total, errors=0)

        def on_progress(completed: int, total: int, errors: int) -> None:
            progress.update(task, completed=completed, errors=errors)

        scan_kwargs = {}
        if include_risky:
            scan_kwargs["risk_threshold_override"] = None

        try:
            results = engine.scan(
                cfg,
                workers=workers,
                delay=delay,
                on_progress=on_progress,
                **scan_kwargs,
            )
        except KeyboardInterrupt:
            console.print("\n[yellow]Scan interrupted. Cached results preserved for resume.[/yellow]")
            raise typer.Exit(1)
        finally:
            engine.close()

    if json_output:
        text = display.flights_json(results)
        if output:
            Path(output).write_text(text)
            console.print(f"Saved to {output}")
        else:
            print(text)
    elif csv_output:
        text = display.flights_csv(results)
        if output:
            Path(output).write_text(text)
            console.print(f"Saved to {output}")
        else:
            print(text)
    elif all_flights:
        display.flights_table(
            results,
            title=f"Scan Results ({len(results)} flights)",
        )
        if output:
            text = display.flights_json(results)
            Path(output).write_text(text)
            console.print(f"Saved to {output}")
    else:
        display.scan_summary(results, cfg.search.currency)
        if output:
            text = display.flights_json(results)
            Path(output).write_text(text)
            console.print(f"Saved to {output}")


@app.command()
def zones(
    update: Annotated[bool, typer.Option("--update", help="Fetch latest conflict zone data")] = False,
) -> None:
    """Display active conflict zones."""
    from opensky import display
    from opensky.safety import load_zones, save_cached_zones

    if update:
        import urllib.request

        url = "https://raw.githubusercontent.com/federicodeponte/opensky/main/src/opensky/data/conflict_zones.json"
        console.print(f"Fetching from {url}...")
        try:
            with urllib.request.urlopen(url, timeout=10) as resp:
                data = resp.read().decode()
            save_cached_zones(data)
            console.print("[green]Conflict zone data updated.[/green]")
        except Exception as e:
            console.print(f"[red]Update failed: {e}[/red]")
            console.print("Using bundled data instead.")

    zone_list = load_zones(force_bundled=not update)
    display.zones_table(zone_list)


@app.command()
def demo(
    include_risky: Annotated[bool, typer.Option("--include-risky", "--show-risky", help="Include flights through conflict zones")] = False,
    json_output: Annotated[bool, typer.Option("--json")] = False,
    csv_output: Annotated[bool, typer.Option("--csv")] = False,
) -> None:
    """See example output with bundled data (no API calls needed)."""
    import json
    from importlib import resources

    from opensky.airports import city_name
    from opensky import display
    from opensky._vendor.google_flights import SearchFlights
    from opensky.models import RiskLevel
    from opensky.providers.google import _convert_result
    from opensky.search import SearchEngine

    # Dynamic date: today + 7 days
    demo_date = (date_cls.today() + timedelta(days=7)).isoformat()
    demo_date_label = _friendly_date(demo_date)

    # Load bundled fixture
    fixture_path = resources.files("opensky") / "data" / "demo_flights.json"
    flights_data = json.loads(fixture_path.read_text())
    parsed = SearchFlights._deduplicate(
        [SearchFlights._parse_flight(f) for f in flights_data]
    )
    domain_results = [_convert_result(f, "EUR") for f in parsed]

    # Score through the real engine (safety filtering, scoring)
    engine = SearchEngine(currency="EUR", use_cache=False)
    from unittest.mock import MagicMock
    mock_provider = MagicMock()
    mock_provider.name = "google"
    mock_provider.search.return_value = domain_results
    engine._providers = [mock_provider]

    all_results = engine.search_scored(
        "BLR", "HAM", demo_date, risk_threshold=None,
    )
    engine.close()

    safe = [sf for sf in all_results if sf.risk.risk_level < RiskLevel.HIGH_RISK]
    risky = [sf for sf in all_results if sf.risk.risk_level >= RiskLevel.HIGH_RISK]
    results = all_results if include_risky else safe

    if not results:
        console.print("[dim]No flights to show.[/dim]")
        raise typer.Exit()

    results.sort(key=lambda x: x.score)

    origin_city = city_name("BLR")
    dest_city = city_name("HAM")
    console.print(f"[dim]Searching flights from {origin_city} to {dest_city} on {demo_date_label}...[/dim]\n")

    if json_output:
        print(display.flights_json(results))
    elif csv_output:
        print(display.flights_csv(results))
    else:
        display.flights_table(results, title="Flights")
        if not include_risky and risky:
            console.print(
                f"[dim]{len(risky)} more flights available via conflict zones. "
                f"Use --include-risky to see all.[/dim]"
            )

        # Mini scan summary with example data
        console.print()
        console.print("[bold]Scan summary (example)[/bold]")
        console.print(
            f"[dim]3 origins x 3 destinations x 5 dates = 45 combos[/dim]\n"
        )

        from rich.table import Table
        from rich.box import ROUNDED

        # Best per destination example
        table = Table(title="Best per Destination", box=ROUNDED, show_lines=False, pad_edge=True, title_style="bold")
        table.add_column("Destination", style="bold")
        table.add_column("Price", justify="right", style="bold green")
        table.add_column("Date")
        table.add_column("Route")

        d1 = _friendly_date((date_cls.today() + timedelta(days=9)).isoformat())
        d2 = _friendly_date((date_cls.today() + timedelta(days=8)).isoformat())
        d3 = _friendly_date((date_cls.today() + timedelta(days=10)).isoformat())

        table.add_row("Hamburg", "\u20ac357", d1, "Bangalore \u2192 Dubai \u2192 Hamburg")
        table.add_row("Frankfurt", "\u20ac298", d2, "Bangkok \u2192 Frankfurt")
        table.add_row("Amsterdam", "\u20ac289", d3, "Bangkok \u2192 Amsterdam")
        console.print(table)

        # Small date matrix
        dates_for_matrix = [
            (date_cls.today() + timedelta(days=7 + i)).isoformat()[5:]
            for i in range(5)
        ]

        matrix = Table(title="Prices by Date", box=ROUNDED, show_lines=False, pad_edge=True, title_style="bold")
        matrix.add_column("Destination", style="bold")
        for d in dates_for_matrix:
            matrix.add_column(d, justify="right")

        matrix.add_row("Hamburg", "\u20ac412", "[green bold]\u20ac357[/green bold]", "\u20ac389", "\u20ac445", "\u20ac401")
        matrix.add_row("Frankfurt", "[green bold]\u20ac298[/green bold]", "\u20ac312", "\u20ac345", "\u20ac378", "\u20ac401")
        matrix.add_row("Amsterdam", "\u20ac356", "\u20ac345", "\u20ac312", "[green bold]\u20ac289[/green bold]", "\u20ac345")
        console.print(matrix)

        console.print("\n[dim]Example data. Run opensky search or opensky scan for real results.[/dim]")


@app.command(name="cache")
def cache_cmd(
    action: Annotated[str, typer.Argument(help="Action: clear | stats")] = "stats",
) -> None:
    """Manage the search cache (clear or view stats)."""
    from opensky import cache as cache_mod

    if action == "clear":
        cache_mod.clear()
        console.print("Cache cleared.")
    elif action == "stats":
        s = cache_mod.stats()
        console.print(f"Entries: {s['size']}")
        console.print(f"Directory: {s['directory']}")
        console.print(f"Size: {s['volume'] / 1024:.1f} KB")
    else:
        console.print(f"[red]Unknown action: {action}. Use 'clear' or 'stats'.[/red]")


@app.command(name="config")
def config_cmd(
    action: Annotated[str, typer.Argument(help="Action: init")] = "init",
    output: Annotated[str, typer.Option("--output", "-o")] = "scan.toml",
    force: Annotated[bool, typer.Option("--force", "-f", help="Overwrite existing file")] = False,
    quick: Annotated[bool, typer.Option("--quick", help="Dump template without interactive prompts")] = False,
) -> None:
    """Generate a scan config file (interactive or template)."""
    from opensky.config import EXAMPLE_CONFIG

    if action != "init":
        console.print(f"[red]Unknown action: {action}. Use 'init'.[/red]")
        raise typer.Exit(1)

    p = Path(output)
    if p.exists() and not force:
        console.print(f"[yellow]{output} already exists. Use --force to overwrite, or -o to pick a different name.[/yellow]")
        raise typer.Exit(1)

    # Non-interactive: dump template
    if quick or not sys.stdin.isatty():
        p.write_text(EXAMPLE_CONFIG)
        console.print(f"Created {output}")
        return

    # Interactive config builder
    from opensky.airports import resolve_airport, city_name

    def _prompt_airports(label: str) -> list[tuple[str, str]]:
        """Prompt for comma-separated cities, resolve each. Returns (code, city) pairs."""
        while True:
            try:
                raw = input(f"{label} (comma-separated cities or codes): ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                raise typer.Exit(1)
            if not raw:
                console.print("[dim]Enter at least one city or airport code.[/dim]")
                continue
            results = []
            for part in raw.split(","):
                part = part.strip()
                if not part:
                    continue
                try:
                    code = resolve_airport(part, interactive=True)
                    results.append((code, city_name(code)))
                except (ValueError, SystemExit):
                    # resolve_airport might sys.exit on truly unknown, catch it
                    console.print(f"[red]Could not resolve '{part}'. Try again.[/red]")
                    results = []
                    break
            if results:
                return results

    def _prompt_date(label: str) -> str:
        """Prompt for a date, accepting flexible formats."""
        while True:
            try:
                raw = input(f"{label}: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                raise typer.Exit(1)
            if not raw:
                console.print("[dim]Enter a date (YYYY-MM-DD, tomorrow, mar 15, etc.)[/dim]")
                continue
            try:
                return _parse_date(raw)
            except ValueError:
                console.print("[red]Invalid date. Use YYYY-MM-DD, tomorrow, next monday, mar 15, etc.[/red]")

    console.print("[bold]opensky config init[/bold]\n")

    origins = _prompt_airports("Where are you flying from?")
    destinations = _prompt_airports("Where to?")

    start_date = _prompt_date("Start date (YYYY-MM-DD)")
    while True:
        end_date = _prompt_date("End date (YYYY-MM-DD)")
        if end_date >= start_date:
            break
        console.print("[red]End date must be on or after start date.[/red]")

    try:
        currency_input = input("Currency [EUR]: ").strip().upper()
    except (EOFError, KeyboardInterrupt):
        print()
        raise typer.Exit(1)
    currency = currency_input or "EUR"

    # Build TOML
    origin_codes = ", ".join(f'"{c}"' for c, _ in origins)
    origin_comments = ", ".join(name for _, name in origins)
    dest_codes = ", ".join(f'"{c}"' for c, _ in destinations)
    dest_comments = ", ".join(name for _, name in destinations)

    toml = f"""\
[search]
origins = [{origin_codes}]  # {origin_comments}
destinations = [{dest_codes}]  # {dest_comments}
cabin = "economy"
currency = "{currency}"
stops = "any"

[search.date_range]
start = "{start_date}"
end = "{end_date}"

[safety]
risk_threshold = "risky"

[scoring]
price_weight = 1.0
duration_weight = 0.5
"""
    p.write_text(toml)
    console.print(f"\nCreated {output}. Next: [green]opensky scan --config {output}[/green]")
