from __future__ import annotations

import sys
import tomllib
from datetime import date, timedelta
from pathlib import Path

from pydantic import BaseModel, field_validator


class DateRange(BaseModel):
    start: str
    end: str

    @field_validator("start", "end")
    @classmethod
    def validate_date(cls, v: str) -> str:
        date.fromisoformat(v)
        return v

    def dates(self) -> list[str]:
        s = date.fromisoformat(self.start)
        e = date.fromisoformat(self.end)
        result = []
        while s <= e:
            result.append(s.isoformat())
            s += timedelta(days=1)
        return result


class SearchConfig(BaseModel):
    origins: list[str]
    destinations: list[str]
    date_range: DateRange
    cabin: str = "economy"
    currency: str = "EUR"
    stops: str = "any"
    max_price: float = 0


_RISK_ALIASES: dict[str, str] = {
    "avoid": "do_not_fly",
    "risky": "high_risk",
    "caution": "caution",
    "do_not_fly": "do_not_fly",
    "high_risk": "high_risk",
}


class SafetyConfig(BaseModel):
    risk_threshold: str = "high_risk"

    @field_validator("risk_threshold")
    @classmethod
    def normalize_risk(cls, v: str) -> str:
        normalized = _RISK_ALIASES.get(v.lower().strip())
        if normalized is None:
            valid = ", ".join(_RISK_ALIASES.keys())
            raise ValueError(f"Unknown risk_threshold '{v}'. Use: {valid}")
        return normalized


class ScoringConfig(BaseModel):
    price_weight: float = 1.0
    duration_weight: float = 0.5


class ConnectionsConfig(BaseModel):
    final_destination: str = ""
    transit_hours: dict[str, float] = {}


class ScanConfig(BaseModel):
    search: SearchConfig
    safety: SafetyConfig = SafetyConfig()
    scoring: ScoringConfig = ScoringConfig()
    connections: ConnectionsConfig = ConnectionsConfig()


def _validate_date_range(cfg: ScanConfig) -> None:
    """Validate date range: start <= end, warn if start is in the past."""
    s = date.fromisoformat(cfg.search.date_range.start)
    e = date.fromisoformat(cfg.search.date_range.end)
    if s > e:
        raise ValueError(
            f"Start date {cfg.search.date_range.start} is after end date "
            f"{cfg.search.date_range.end}. Start must be before end."
        )
    if s < date.today():
        print(
            f"Warning: start date {cfg.search.date_range.start} is in the past.",
            file=sys.stderr,
        )


def load_config(path: str | Path) -> ScanConfig:
    p = Path(path)
    with open(p, "rb") as f:
        data = tomllib.load(f)
    cfg = ScanConfig(**data)

    _validate_date_range(cfg)

    # Resolve city names to IATA codes in origins/destinations
    from opensky.airports import resolve_airport

    try:
        cfg.search.origins = [resolve_airport(o, interactive=False) for o in cfg.search.origins]
        cfg.search.destinations = [resolve_airport(d, interactive=False) for d in cfg.search.destinations]
    except ValueError as e:
        raise ValueError(str(e)) from None

    return cfg


EXAMPLE_CONFIG = """\
[search]
# Airport codes (city names work in CLI: opensky search bangalore hamburg ...)
origins = ["BLR", "DEL", "BOM", "KUL", "BKK", "SIN"]  # Bangalore, Delhi, Mumbai, Kuala Lumpur, Bangkok, Singapore
destinations = ["HAM", "FRA", "MUC", "BER", "AMS", "CPH"]  # Hamburg, Frankfurt, Munich, Berlin, Amsterdam, Copenhagen
cabin = "economy"   # economy, premium_economy, business, first
currency = "EUR"
stops = "any"   # any, nonstop, 1, 2
# max_price = 500  # maximum price (0 = no limit)

[search.date_range]
start = "2026-03-10"
end = "2026-03-20"

[safety]
risk_threshold = "risky"   # hide flights at this level or above: avoid, risky, caution

[scoring]
price_weight = 1.0
duration_weight = 0.5

# Optional: if your final destination is one city, add ground travel time
# from each arrival airport. This helps scoring rank "fly to nearby city +
# short train" vs "fly direct but expensive".
[connections]
final_destination = "Hamburg"

[connections.transit_hours]
HAM = 0       # direct, no ground travel
HAJ = 1.5     # Hannover: 1.5h train to Hamburg
BER = 2       # Berlin: 2h train to Hamburg
FRA = 4       # Frankfurt: 4h train to Hamburg
MUC = 5.5
AMS = 5
CPH = 5
"""
