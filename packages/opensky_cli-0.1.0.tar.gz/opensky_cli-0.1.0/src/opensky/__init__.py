"""opensky - Find the cheapest, safest flights from your terminal."""

__version__ = "0.1.0"
