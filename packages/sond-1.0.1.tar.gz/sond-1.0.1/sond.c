#include <Python.h>
#include <windows.h>
#include <mmsystem.h>

#pragma comment(lib, "winmm.lib")

// play wav or mp3
static PyObject* play(PyObject* self, PyObject* args)
{
    const char* filename;

    if (!PyArg_ParseTuple(args,"s",&filename))
        return NULL;

    char command[256];

    sprintf(command,"open \"%s\" type mpegvideo alias mysound",filename);
    mciSendString(command,NULL,0,NULL);

    mciSendString("play mysound wait",NULL,0,NULL);

    Py_RETURN_NONE;
}

// async play
static PyObject* play_async(PyObject* self, PyObject* args)
{
    const char* filename;

    if (!PyArg_ParseTuple(args,"s",&filename))
        return NULL;

    char command[256];

    sprintf(command,"open \"%s\" type mpegvideo alias mysound",filename);
    mciSendString(command,NULL,0,NULL);

    mciSendString("play mysound",NULL,0,NULL);

    Py_RETURN_NONE;
}

// stop sound
static PyObject* stop(PyObject* self, PyObject* args)
{
    mciSendString("stop mysound",NULL,0,NULL);
    mciSendString("close mysound",NULL,0,NULL);

    Py_RETURN_NONE;
}

// pause
static PyObject* pause(PyObject* self, PyObject* args)
{
    mciSendString("pause mysound",NULL,0,NULL);
    Py_RETURN_NONE;
}

// resume
static PyObject* resume(PyObject* self, PyObject* args)
{
    mciSendString("resume mysound",NULL,0,NULL);
    Py_RETURN_NONE;
}

// volume 0-1000
static PyObject* volume(PyObject* self, PyObject* args)
{
    int v;

    if (!PyArg_ParseTuple(args,"i",&v))
        return NULL;

    char command[100];

    sprintf(command,"setaudio mysound volume to %d",v);

    mciSendString(command,NULL,0,NULL);

    Py_RETURN_NONE;
}

// delay then play
static PyObject* delay(PyObject* self, PyObject* args)
{
    int sec;
    const char* filename;

    if (!PyArg_ParseTuple(args,"is",&sec,&filename))
        return NULL;

    Sleep(sec * 1000);

    char command[256];

    sprintf(command,"open \"%s\" type mpegvideo alias mysound",filename);
    mciSendString(command,NULL,0,NULL);

    mciSendString("play mysound",NULL,0,NULL);

    Py_RETURN_NONE;
}

// fadeout
static PyObject* fadeout(PyObject* self, PyObject* args)
{
    int sec;

    if (!PyArg_ParseTuple(args,"i",&sec))
        return NULL;

    for(int i=1000;i>=0;i-=50)
    {
        char command[100];

        sprintf(command,"setaudio mysound volume to %d",i);
        mciSendString(command,NULL,0,NULL);

        Sleep(sec * 10);
    }

    mciSendString("stop mysound",NULL,0,NULL);

    Py_RETURN_NONE;
}

static PyMethodDef Methods[] = {

    {"play",play,METH_VARARGS,"Play sound"},
    {"play_async",play_async,METH_VARARGS,"Play sound async"},
    {"stop",stop,METH_VARARGS,"Stop sound"},
    {"pause",pause,METH_VARARGS,"Pause sound"},
    {"resume",resume,METH_VARARGS,"Resume sound"},
    {"volume",volume,METH_VARARGS,"Set volume"},
    {"delay",delay,METH_VARARGS,"Delay then play"},
    {"fadeout",fadeout,METH_VARARGS,"Fade out sound"},

    {NULL,NULL,0,NULL}
};

static struct PyModuleDef sondmodule = {

    PyModuleDef_HEAD_INIT,
    "sond",
    NULL,
    -1,
    Methods
};

PyMODINIT_FUNC PyInit_sond(void)
{
    return PyModule_Create(&sondmodule);
}