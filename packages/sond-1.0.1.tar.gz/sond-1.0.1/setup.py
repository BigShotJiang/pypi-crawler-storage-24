from setuptools import setup, Extension

module = Extension(
    "sond",
    sources=["sond.c"],
    libraries=["winmm"]
)

setup(
    name="sond",
    version="1.0.1",
    description="Simple sound library",
    author="YourName",
    ext_modules=[module]
)