# Agents

See [CONTRIBUTING.md](./CONTRIBUTING.md) for full setup and contribution guidelines.

## Registry Operations

Registry tools that interact with GCS buckets resolve credentials in this order: (1) `GCS_CREDENTIALS` environment variable (JSON service account key), (2) Application Default Credentials (e.g. `gcloud auth application-default login`). In CI and agent environments, `GCS_CREDENTIALS` may be aliased from `GCP_GSM_CREDENTIALS`. The service account should have read/write access to the dev bucket (`dev-airbyte-cloud-connector-metadata-service-2`) used in registry tests.

## 1Password CLI (`op`)

The `op` CLI is required to retrieve secrets delivered via 1Password share links (used by the `request_devin_secret` MCP tool). If `op` is not already installed, install it with:

```bash
# Install the 1Password CLI (Linux amd64)
curl -sSfo op.zip "https://cache.agilebits.com/dist/1P/op2/pkg/v2.30.3/op_linux_amd64_v2.30.3.zip" \
  && sudo unzip -od /usr/local/bin/ op.zip \
  && rm op.zip
```

After receiving a share link from the secret request workflow, retrieve the secret value with:

```bash
op read '<share_link_url>'
```

No sign-in is required for reading one-time share links.
