# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class FsDirReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'path': 'str'
    }

    attribute_map = {
        'path': 'path'
    }

    def __init__(self, path=None):
        r"""FsDirReq

        The model defined in huaweicloud sdk

        :param path: 文件系统内合法的目录全路径。单层目录长度不允许超过255，全路径长度不允许超过4096。
        :type path: str
        """
        
        

        self._path = None
        self.discriminator = None

        self.path = path

    @property
    def path(self):
        r"""Gets the path of this FsDirReq.

        文件系统内合法的目录全路径。单层目录长度不允许超过255，全路径长度不允许超过4096。

        :return: The path of this FsDirReq.
        :rtype: str
        """
        return self._path

    @path.setter
    def path(self, path):
        r"""Sets the path of this FsDirReq.

        文件系统内合法的目录全路径。单层目录长度不允许超过255，全路径长度不允许超过4096。

        :param path: The path of this FsDirReq.
        :type path: str
        """
        self._path = path

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, FsDirReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
