import logging
from .core import PyWebWizard
from .utils.logger import logging as log_util

class WebAgent:
    """
    High-level agent interface that orchestrates PyWebWizard with a 'Master-Subagent' approach.
    It receives high-level missions and decomposes them into tactical actions using AI and Vision.
    """

    def __init__(self, api_key: str, model: str = "gpt-4o", visual_mode: bool = True, **kwargs):
        """
        Initialize the WebAgent.
        
        :param api_key: OpenAI API key.
        :param model: AI model (default: gpt-4o for vision support).
        :param visual_mode: Whether to use Set-of-Marks and vision by default.
        """
        self.config = kwargs
        self.config['visual_mode'] = visual_mode
        self.wizard = PyWebWizard(
            openai_api_key=api_key,
            ai_model=model,
            **self.config
        )
        # Ensure verify_actions is enabled for OODA loop
        self.wizard.config['verify_actions'] = True

    def run_mission(self, mission: str):
        """
        Executes a high-level mission using the 'Master-Subagent' pattern.
        1. Master Phase: Decompose mission into tactical sub-tasks.
        2. Subagent Phase: Execute each sub-task using AI + Vision.
        """
        logging.info(f"🚀 MISSION START: {mission}")
        
        # 1. Master Phase (Decomposition)
        logging.info("[MASTER] Decomposing mission into tactical steps...")
        
        planning_prompt = f"""
        Act as a Master Web Agent. 
        Mission: "{mission}"
        Decompose this mission into a sequence of 2-4 tactical goals.
        Respond ONLY with a valid JSON array of strings. 
        Example: ["Go to amazon", "Search for laptop", "Extract price"]
        """
        
        try:
            # Plan using the existing AI client
            plan_response = self.wizard.ai_handler.ai.client.chat.completions.create(
                model=self.wizard.ai_handler.ai.model,
                messages=[{"role": "system", "content": "You are a tactical coordinator."}, 
                          {"role": "user", "content": planning_prompt}],
                temperature=0.0
            )
            raw_plan = plan_response.choices[0].message.content
            import re, json
            match = re.search(r"(\[.*\])", raw_plan, re.DOTALL)
            plan = json.loads(match.group(1)) if match else [mission]
            logging.info(f"[MASTER] Tactical Plan: {plan}")
        except Exception as e:
            logging.warning(f"[MASTER] Decomposition failed, falling back: {e}")
            plan = [mission]

        # 2. Subagent Phase (Execution)
        total_results = []
        final_summary = []
        
        for i, goal in enumerate(plan):
            logging.info(f"[SUBAGENT] Goal {i+1}/{len(plan)}: {goal}")
            try:
                results, summary = self.wizard.ask(goal)
                total_results.extend(results)
                if summary:
                    final_summary.append(summary)
            except Exception as e:
                logging.error(f"[SUBAGENT] Failed goal: {goal} - {e}")
                break

        status = "SUCCESS" if final_summary else "PARTIAL"
        if any("Blocker detected" in str(r.get('result')) for r in total_results):
            status = "BLOCKED"

        return {
            "mission": mission,
            "plan": plan,
            "status": status,
            "summary": " ".join(final_summary),
            "total_actions": len(total_results)
        }

    def close(self):
        """Cleans up browser resources."""
        if self.wizard.driver:
            self.wizard.driver.quit()
