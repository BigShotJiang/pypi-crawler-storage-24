import base64
import logging
from .utils.exceptions import ActionError

class AIHandler:
    """
    Handles AI-powered automation logic with vision capabilities.
    """
    
    def __init__(self, ai_controller):
        self.ai = ai_controller

    def analyze_image(self, image_path, prompt):
        """
        Sends an image to the AI controller for multimodal analysis.
        """
        logging.info(f"[AIHandler] Sending image for vision analysis: {image_path}")
        try:
            with open(image_path, "rb") as image_file:
                encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
                
            # Llamamos al controlador de IA con la imagen codificada
            # Se espera que el controlador maneje el formato correcto para GPT-4o
            response = self.ai.analyze_vision(
                encoded_image=encoded_string,
                prompt=prompt
            )
            return response
        except Exception as e:
            logging.error(f"[AIHandler] Vision analysis failed: {e}")
            raise ActionError(f"Vision analysis failed: {e}")

    # ... (Resto de métodos existentes: invoke_ai) ...
