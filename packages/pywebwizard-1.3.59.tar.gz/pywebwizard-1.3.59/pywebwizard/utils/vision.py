import logging
import base64
import os

def annotate_page(driver):
    """
    Injects a script to annotate interactive elements with numbered labels (Set-of-Marks).
    Returns a list of element mappings.
    """
    annotation_js = """
    (function() {
        // Remove existing annotations if any
        const existing = document.querySelectorAll('.pywebwizard-som-label');
        existing.forEach(el => el.remove());

        const interactiveSelector = 'a, button, input, select, textarea, [role="button"], [onclick]';
        const elements = Array.from(document.querySelectorAll(interactiveSelector)).filter(el => {
            const rect = el.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0 && window.getComputedStyle(el).visibility !== 'hidden';
        });

        const mapping = [];
        elements.forEach((el, index) => {
            const rect = el.getBoundingClientRect();
            const label = document.createElement('div');
            label.className = 'pywebwizard-som-label';
            label.innerText = index;
            label.style.position = 'fixed';
            label.style.left = (rect.left + window.scrollX) + 'px';
            label.style.top = (rect.top + window.scrollY) + 'px';
            label.style.backgroundColor = 'red';
            label.style.color = 'white';
            label.style.fontSize = '12px';
            label.style.fontWeight = 'bold';
            label.style.padding = '2px 5px';
            label.style.borderRadius = '3px';
            label.style.zIndex = '1000000';
            label.style.pointerEvents = 'none';
            document.body.appendChild(label);
            
            mapping.push({
                index: index,
                tag: el.tagName.toLowerCase(),
                text: el.innerText || el.value || el.placeholder || '',
                xpath: getXPath(el)
            });
        });

        function getXPath(element) {
            if (element.id !== '') return 'id("' + element.id + '")';
            if (element === document.body) return element.tagName;
            var ix = 0;
            var siblings = element.parentNode.childNodes;
            for (var i = 0; i < siblings.length; i++) {
                var sibling = siblings[i];
                if (sibling === element) return getXPath(element.parentNode) + '/' + element.tagName + '[' + (ix + 1) + ']';
                if (sibling.nodeType === 1 && sibling.tagName === element.tagName) ix++;
            }
        }

        return mapping;
    })();
    """
    return driver.execute_script(annotation_js)

def remove_annotations(driver):
    """Removes the Set-of-Marks labels from the page."""
    driver.execute_script("document.querySelectorAll('.pywebwizard-som-label').forEach(el => el.remove());")
