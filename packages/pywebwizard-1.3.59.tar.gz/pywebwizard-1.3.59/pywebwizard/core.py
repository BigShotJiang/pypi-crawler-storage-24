import os
import time
import yaml
import json
import re
import threading
import logging
import inspect
from copy import deepcopy
from typing import Dict, Any, List, Optional
from pykeepass import PyKeePass
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, WebDriverException, TimeoutException, \
    ElementNotInteractableException

from .utils.config import INTERFACES, DEFAULT_TIMEOUT, BROWSER_OPTIONS
from .utils.functions import is_valid_url, action_name, required_fields
from .utils.logger import logging as log_util
from .utils.ai_controller import AIController
from .utils.exceptions import ConfigFormatError, ConfigFileError, BrowserError, ActionError

from .dotdict import DotDict
from .cloudflare import CloudflareBypasser
from .actions import ActionsMixin
from .browser import BrowserManager
from .ai import AIHandler

class PyWebWizardBase(ActionsMixin):
    """
    Main class for Selenium management. Orchestrates actions and configuration.
    """

    def __init__(self, spell_file: str = None, headers: dict = None,
                 destruct_on_finish: bool = True, external_functions_mapping: dict = None,
                 keepass_file: str = None, keepass_password: str = None, undetectable: bool = False,
                 openai_endpoint: str = "https://api.openai.com/v1", openai_api_key: str = None, 
                 ai_model: str = "gpt-4", **kwargs):
        
        self.driver = None
        self.screenshots_dir = ""
        self.env_var_separator_start = "{{"
        self.env_var_separator_end = "}}"
        self.actions_map = {}
        self.headers = headers
        self.actions = []
        self.config = kwargs # Initialize config with kwargs
        self.environment = {}
        self._env_lock = threading.RLock()
        self.spell_file = spell_file
        
        if spell_file:
            self.actions, self.config, self.environment = self.load_spell(spell_file)
            
        self.destruct_on_finish = self.config.get('destroy', destruct_on_finish) is True
        self.external_functions_mapping = external_functions_mapping
        self.prepare_screenshots_dir()
        self._register_actions()
        
        self.cloudflare_enabled = self.config.get('cloudflare_bypass', False)
        self.cf_max_retries = self.config.get('cloudflare_retries', 3)
        self.keepass_file = keepass_file
        self.keepass_password = keepass_password
        self.keepass_db = None
        self.undetectable = self.config.get('undetectable', undetectable)
        
        self.ai_enabled = openai_api_key is not None
        if self.ai_enabled:
            self.ai_controller = AIController(openai_endpoint, openai_api_key, ai_model)
            self.ai_handler = AIHandler(self.ai_controller)
            logging.info("AI enabled successfully")
            
        if keepass_file and keepass_password:
            self._load_keepass(keepass_file, keepass_password)
            
        self._driver_setup()

    def __enter__(self):
        """
        Support for 'with' statement.
        """
        if not self._is_driver_alive():
            self._driver_setup()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Ensure resources are cleaned up when exiting the 'with' block.
        """
        self.save_spell()
        if self.driver and self.destruct_on_finish:
            try:
                self.driver.quit()
                logging.info("[DRIVER] Browser closed automatically (context manager)")
            except Exception:
                pass
        self.driver = None

    def _load_keepass(self, file, password):
        if os.path.isfile(file):
            try:
                self.keepass_db = PyKeePass(file, password=password)
                logging.info(f"[KEEPASS] KeePass database loaded from {file}")
            except Exception as e:
                logging.error(f"[KEEPASS] Failed to load KeePass database: {str(e)}")
                raise e
        else:
            raise FileNotFoundError(f"KeePass file not found: {file}")

    def _register_actions(self):
        for name in dir(self):
            attr = getattr(self, name)
            if callable(attr) and hasattr(attr, '_action_name'):
                self.actions_map[attr._action_name] = attr

    def _driver_setup(self):
        self.driver = BrowserManager.setup_driver(self.config, self.undetectable)

    def _is_driver_alive(self):
        if not self.driver:
            return False
        try:
            # Check if the session is still active
            if not self.driver.session_id:
                return False
            _ = self.driver.title
            return True
        except Exception:
            return False

    def _check_and_heal_driver(self):
        """
        Healing System: Auto-restores the driver if it's dead, 
        and tries to recover the last known URL.
        """
        if not self._is_driver_alive():
            logging.warning("[HEALING] Driver crash detected! Attempting auto-repair...")
            with self._env_lock:
                last_url = self.environment.get('__last_known_url')

            try:
                if self.driver:
                    self.driver.quit()
            except Exception:
                pass
            
            self.driver = None
            self._driver_setup()
            
            if last_url:
                logging.info(f"[HEALING] Navigating back to {last_url}")
                try:
                    self.driver.get(last_url)
                except Exception as e:
                    logging.error(f"[HEALING] Failed to recover URL {last_url}: {e}")
            else:
                logging.info("[HEALING] Driver restarted, but no URL history found.")
        
        # Track URL for future healing
        try:
            current_url = self.driver.current_url
            if current_url and current_url != "about:blank":
                with self._env_lock:
                    self.environment['__last_known_url'] = current_url
        except:
            pass

    def _execute_action(self, action: dict):
        action = self.prepare_action(action)
        action_name = action.get('action')
        
        if not action_name:
            raise ActionError("Action name is missing")
        if action_name not in self.actions_map:
            raise ActionError(f"Action '{action_name}' is not supported")
            
        # 1. Healing System: Ensure driver is healthy
        self._check_and_heal_driver()

        action_func = self.actions_map[action_name]

        # OODA Loop: Capture state before action
        state_before = {
            "url": self.driver.current_url if self._is_driver_alive() else None,
            "title": self.driver.title if self._is_driver_alive() else None
        }

        # 2. Vision Fallback Logic (Experimental)
        # If the action has a label or index (from SOM), we might want to prioritize it
        # or use it as fallback if the selector fails.
        
        try:
            # Execute
            result = action_func(action)
        except (NoSuchElementException, TimeoutException) as e:
            # Re-try with Vision if visual_mode is enabled
            if self.config.get('visual_mode') and 'query' in action:
                logging.info(f"[VISION] Selector failed. Attempting visual fallback for '{action.get('query')}'...")
                # We'll try to find the element by text in the visual mapping
                from .utils.vision import annotate_page, remove_annotations
                mapping = annotate_page(self.driver)
                # Find best match by text
                target_text = str(action.get('query')).lower()
                match = next((m for m in mapping if target_text in m['text'].lower()), None)
                remove_annotations(self.driver)
                
                if match:
                    logging.info(f"[VISION] Found visual match at label {match['index']}. Re-trying action with xpath.")
                    new_action = deepcopy(action)
                    new_action['interface'] = 'xpath'
                    new_action['query'] = match['xpath']
                    result = action_func(new_action)
                else:
                    raise e
            else:
                raise e

        # OODA Loop: Verify action effect
        if self.config.get('verify_actions', True) and action_name in ['click', 'navigate', 'fill', 'type', 'submit']:
            self._verify_action(action, state_before)

        return result

    def _solve_captcha(self):
        logging.info("[SOLVER] Analizando CAPTCHA visual mediante IA...")
        
        # 1. Intentar resolver por DOM/Selector primero
        if self._solve_by_selector():
            return True
            
        # 2. Fallback: Resolución visual con IA
        if self.ai_enabled:
            logging.info("[SOLVER] DOM fallido. Intentando resolución visual con IA...")
            screenshot_path = os.path.join(self.screenshots_dir, "captcha_debug.png")
            self.driver.save_screenshot(screenshot_path)
            
            # Enviar a la IA (gpt-4o con visión)
            prompt = "Esto es un CAPTCHA. Identifica los elementos solicitados y devuelve una lista de coordenadas (x, y) donde hacer clic para resolverlo."
            
            # Usar AIHandler para analizar la imagen
            try:
                # Nota: Suponemos que AIHandler tiene un método para analizar imágenes localmente
                response = self.ai_handler.analyze_image(screenshot_path, prompt)
                
                # Ejecutar clics basados en la respuesta de la IA (suponiendo que la IA devuelve coords)
                coords = self._parse_coords_from_ai(response)
                for x, y in coords:
                    self.driver.execute_script(f"document.elementFromPoint({x}, {y}).click();")
                return True
            except Exception as e:
                logging.error(f"[SOLVER] IA visual falló: {e}")
                
        return False

    def _solve_by_selector(self):
        mapping = self._execute_action({'action': 'inspect', 'debug': False})
        candidates = [m for m in mapping if any(word in (m.get('text') or '').lower() for word in ['verifi', 'puzzle', 'solve', 'confirm'])]
        if candidates:
            solver_target = candidates[0]
            logging.info(f"[SOLVER] Intentando resolver reto con selector: {solver_target.get('text', 'element')}")
            self._execute_action({'action': 'click', 'interface': 'xpath', 'query': solver_target['xpath']})
            return True
        return False

    def _parse_coords_from_ai(self, response):
        # Lógica simple para extraer [(x1,y1), (x2,y2)] de un string devuelto por la IA
        # Esto debería adaptarse al formato que devuelva tu prompt
        import re
        return re.findall(r'\((\d+),\s*(\d+)\)', response)

    def _verify_action(self, action: dict, state_before: dict):
        """
        Verifies if an action had an impact on the page state (OODA Loop).
        Detects blockers like CAPTCHAs or Cloudflare and attempts auto-resolution.
        """
        time.sleep(0.8)  # Organic wait
        if not self._is_driver_alive(): return

        state_after = {
            "url": self.driver.current_url,
            "title": self.driver.title,
            "source": self.driver.page_source.lower()
        }

        # 🛑 BLOCKER DETECTION
        blockers = {
            "cloudflare": ["checking your browser", "access denied", "cloudflare"],
            "captcha": ["recaptcha", "g-recaptcha", "captcha", "hcaptcha", "verify you are human"],
            "error_pages": ["404 not found", "502 bad gateway", "403 forbidden"]
        }

        for b_type, keywords in blockers.items():
            if any(kw in state_after['source'] or kw in state_after['title'].lower() for kw in keywords):
                logging.error(f"[OODA] Blocker detected: {b_type.upper()} on {state_after['url']}")
                
                # Intentar resolución automática
                if b_type == "captcha":
                    if self._solve_captcha():
                        logging.info("[OODA] CAPTCHA resolution triggered.")
                        return {"success": True, "blocker": b_type, "resolved": True}
                
                return {"success": False, "blocker": b_type}

        action_type = action.get('action')
        if action_type == 'navigate':
            if state_after['url'] == state_before['url'] and not action.get('force'):
                 logging.warning(f"[OODA] Navigation might have failed (URL unchanged)")
                 return {"success": False, "reason": "url_unchanged"}
        
        return {"success": True}

    def prepare_action(self, action: dict):
        with self._env_lock:
            return {self._get_env(k): self._get_env(v) for k, v in action.items()}

    def _get_env(self, value):
        if isinstance(value, dict):
            return {self._get_env(k): self._get_env(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._get_env(e) for e in value]
        if isinstance(value, str):
            pattern = rf"{re.escape(self.env_var_separator_start)}\s*([^\}}]+)\s*{re.escape(self.env_var_separator_end)}"
            def replace_match(match):
                expression = match.group(1).strip()
                if expression.startswith("[KP]@"):
                    return self._get_keepass_entry_password(expression.replace("[KP]@", "").strip())
                
                with self._env_lock:
                    dot_env = DotDict(self.environment)
                try:
                    # Usamos eval con el diccionario de entorno para permitir expresiones
                    return str(eval(expression, {}, dot_env))
                except Exception as e:
                    logging.warning(f"[ENV] Could not evaluate: {{{{ {expression} }}}} — Error: {str(e)}")
                    return match.group(0)
            return re.sub(pattern, replace_match, value)
        return value

    def _get_keepass_entry_password(self, entry_path):
        if not self.keepass_db:
            logging.error("[KEEPASS] Database not loaded")
            return ""
        try:
            path_parts = entry_path.strip("/").split("/")
            group = self.keepass_db.root_group
            for p in path_parts[:-1]:
                group = next(g for g in group.subgroups if g.name == p)
            entry = next(e for e in group.entries if e.title == path_parts[-1])
            return entry.password
        except Exception as e:
            logging.error(f"[KEEPASS] Entry '{entry_path}' not found: {str(e)}")
            return ""

    def load_spell(self, spell_file: str):
        if is_valid_url(spell_file):
            return self._load_url_config(spell_file)
        
        if not os.path.isabs(spell_file):
            paths_to_try = [
                os.path.join(os.getcwd(), spell_file),
                os.path.join(os.getcwd(), 'spells', os.path.basename(spell_file))
            ]
            for p in paths_to_try:
                if os.path.isfile(p):
                    spell_file = p
                    break
            else:
                raise FileNotFoundError(f"Spell file not found: {spell_file}")

        try:
            with open(spell_file, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f) if spell_file.endswith(('.yaml', '.yml')) else json.load(f)
            
            actions = data.get('start', [])
            config = self._flatten(data.get('config', {}))
            env = self._flatten(data.get('environment', {}))
            return actions, config, env
        except Exception as e:
            raise ConfigFormatError(f"Error loading spell: {str(e)}")

    def _flatten(self, data):
        if isinstance(data, list):
            res = {}
            for item in data:
                if isinstance(item, dict):
                    res.update(item)
            return res
        return data

    def save_spell(self, file_path=None, actions_override=None):
        if self.spell_file:
            return
            
        actions = actions_override if actions_override else self.actions
        if not actions: return
        
        if actions[-1].get("action") != "screenshot":
            actions.append({"action": "screenshot", "file_name": "final_state"})
            
        data = {'start': actions, 'environment': {k: v for k, v in self.environment.items() if k != 'page_html'}}
        
        os.makedirs("spells", exist_ok=True)
        file_path = file_path or os.path.join("spells", f"spell_{int(time.time())}.yaml")
        
        with open(file_path, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, allow_unicode=True, sort_keys=False)
        logging.info(f"[SAVE SPELL] Saved to: {file_path}")

    def save_session(self, file_path="session.json"):
        """Saves current browser cookies to a file."""
        if not self.driver: return
        cookies = self.driver.get_cookies()
        with open(file_path, 'w') as f:
            json.dump(cookies, f)
        logging.info(f"[SESSION] Cookies saved to {file_path}")

    def load_session(self, file_path="session.json"):
        """Loads cookies from a file into the current browser session."""
        if not self.driver or not os.path.exists(file_path): return
        with open(file_path, 'r') as f:
            cookies = json.load(f)
        for cookie in cookies:
            try:
                self.driver.add_cookie(cookie)
            except Exception:
                pass
        logging.info(f"[SESSION] Cookies loaded from {file_path}")

    def invoke(self):
        results = []
        for res in self.invoke_generator():
            results.append(res)
        return results

    def ask(self, task_description: str, max_cycles: int = 50, per_action_retries: int = 2):
        """
        AI Powered automation. Ask for a task to be performed.
        """
        if not self.ai_enabled:
            logging.error("AI is not enabled. Provide an OpenAI API key.")
            return None
        return self.ai_handler.invoke_ai(self, task_description, max_cycles, per_action_retries)

    invoke_ai = ask # Alias for compatibility

    def invoke_generator(self):
        if not self._is_driver_alive():
            self._driver_setup()
        
        logging.info(f"[START] Actions: {len(self.actions)}")
        done = 0
        try:
            for action in self.actions:
                try:
                    res = self._execute_action(action)
                    yield {"action": action, "result": res}
                    done += 1
                except Exception as e:
                    logging.error(f"[ERROR] Action '{action.get('action')}' failed: {str(e)}")
                    if action.get('optional'):
                        logging.info("[OPTIONAL] Continuing...")
                        continue
                    if self.config.get('continue_on_error'):
                        continue
                    break
        finally:
            # We only quit here if we are NOT in a context manager to avoid double-quit
            # or if the user called invoke() outside a 'with' block.
            # However, for simplicity and backward compatibility, we keep it but check driver
            if self.driver and self.destruct_on_finish:
                self.save_spell()
                self.driver.quit()
                self.driver = None
            logging.info(f"[END] Completed: {done}/{len(self.actions)}")

    def prepare_screenshots_dir(self):
        self.screenshots_dir = self.config.get('screenshots', 'screenshots')
        os.makedirs(self.screenshots_dir, exist_ok=True)

    def _navigate_with_cf_bypass(self, url):
        self.driver.get(url)
        cf = CloudflareBypasser(self.driver, max_retries=self.cf_max_retries)
        if cf.is_challenge_present():
            logging.info("[CLOUDFLARE] Bypassing...")
            cf.bypass()

    def _wait(self, interface, query, index=None, timeout=DEFAULT_TIMEOUT):
        _interface = self._is_valid_interface(interface)
        wait = WebDriverWait(self.driver, timeout)
        
        # Handle "string" interface as special case for text-based search
        if interface.lower() == "string":
            _xpath = f"//*[contains(text(), '{query}')]"
            locator = ("xpath", _xpath)
        else:
            locator = (_interface, query)
        
        try:
            self.driver.switch_to.default_content()
            return wait.until(EC.presence_of_element_located(locator))
        except Exception:
            pass

        # Try in Shadow DOMs
        if interface.lower() in ['id', 'css', 'name']:
            try:
                _selector = query if interface.lower() == 'css' else (f"#{query}" if interface.lower() == 'id' else f"[name='{query}']")
                _shadow_js = f"""
                function findInShadow(root, selector) {{
                    let el = root.querySelector(selector);
                    if (el) return el;
                    for (const node of root.querySelectorAll('*')) {{
                        if (node.shadowRoot) {{
                            el = findInShadow(node.shadowRoot, selector);
                            if (el) return el;
                        }}
                    }}
                    return null;
                }}
                return findInShadow(document, '{_selector}');
                """
                element = self.driver.execute_script(_shadow_js)
                if element: return element
            except Exception:
                pass

        # Deep search in all frames
        def _search_in_frame_recursive():
            try:
                return wait.until(EC.presence_of_element_located(locator))
            except Exception:
                pass
            
            for i, iframe in enumerate(self.driver.find_elements("tag name", "iframe")):
                try:
                    self.driver.switch_to.frame(iframe)
                    el = _search_in_frame_recursive()
                    if el: return el
                    self.driver.switch_to.parent_frame()
                except Exception:
                    self.driver.switch_to.parent_frame()
                    continue
            return None

        self.driver.switch_to.default_content()
        result = _search_in_frame_recursive()
        if result: return result

        self.driver.switch_to.default_content()
        raise NoSuchElementException(f"Element not found: {interface}='{query}' in any frame/shadow")

    def _log_action(self, action, message):
        name = action.get('action', 'ACTION').upper()
        logging.info(f"[{name}] {message}")

    def _prepare_page_info(self, html, ax_tree=None):
        info = {
            "url": self.driver.current_url,
            "title": self.driver.title,
            "html_snapshot": html[:10000] if len(html) > 10000 else html
        }
        if ax_tree:
            # We only send a subset of the AXTree to save tokens
            info["accessibility_tree"] = ax_tree[:100] # Limiting to 100 interaction elements
        return info

class PyWebWizard(PyWebWizardBase):
    """
    User-facing PyWebWizard class.
    """
    pass

# Aliases for backward compatibility
SeleniumManager = PyWebWizard
