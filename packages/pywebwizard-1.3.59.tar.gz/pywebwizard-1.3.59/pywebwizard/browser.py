import os
import time
import logging
import subprocess
import threading
from copy import deepcopy
from selenium import webdriver
import undetected_chromedriver as uc
from .utils.config import BROWSER_OPTIONS
from .utils.exceptions import BrowserError

# Global lock to prevent multiple threads from patching the UC binary simultaneously
_UC_LOCK = threading.Lock()

class BrowserManager:
    """
    Handles browser driver initialization and setup.
    """
    
    @staticmethod
    def setup_driver(config, undetectable=False):
        """
        Sets up the browser driver based on the configuration settings.
        """
        _selected_browser = config.get('browser', 'chrome')
        if _selected_browser not in BROWSER_OPTIONS:
            logging.error(f"[DRIVER] Browser not supported: {_selected_browser}")
            raise BrowserError(f"Browser not supported: {_selected_browser}")

        _browser_options = BROWSER_OPTIONS.get(_selected_browser)
        _undetection_available = _browser_options.get('undetectable', False)
        _exec_path = _browser_options.get('exec_path')
        
        # Tor Global Configuration
        _use_tor = config.get('tor', False) or _selected_browser == 'tor'
        _tor_proxy = BROWSER_OPTIONS.get('tor', {}).get('proxy', {'socks': '127.0.0.1', 'port': 9050})
        
        if _use_tor:
            _tor_service_path = BROWSER_OPTIONS.get('tor', {}).get('service_path')
            if _tor_service_path and os.path.isfile(_tor_service_path):
                try:
                    # Iniciamos el proceso de tor en segundo plano si existe
                    subprocess.Popen([_tor_service_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    logging.info("[TOR] Tor service started")
                    time.sleep(2) # Esperamos a que inicie
                except Exception as e:
                    logging.warning(f"[TOR] Error starting Tor service: {str(e)}")

        if undetectable and _undetection_available:
            options = uc.ChromeOptions()
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-infobars')
            options.add_argument('--disable-speech-api')
            options.add_argument('--disable-features=VoiceInteraction')
            options.add_argument('--disable-background-networking')
            options.add_argument('--disable-default-apps')
            options.add_argument('--disable-extensions')
            
            if config.get("hidden", False):
                options.add_argument('--headless')
            
            if _use_tor:
                options.add_argument(f'--proxy-server=socks5://{_tor_proxy.get("socks")}:{_tor_proxy.get("port")}')
                logging.info(f"[TOR] Routing through Tor proxy: {_tor_proxy.get('socks')}:{_tor_proxy.get('port')}")

            if _exec_path and os.path.isfile(_exec_path):
                options.binary_location = _exec_path
            
            logging.info("[DRIVER] Starting in undetectable mode")
            try:
                # Use a lock to prevent concurrent patching of the binary by multiple threads
                with _UC_LOCK:
                    # Force version 145 to match system's Chromium/Brave version
                    try:
                        drv = uc.Chrome(options=options, version_main=145)
                    except Exception as e:
                        logging.warning(f"[DRIVER] Error with version_main=145: {e}. Trying default...")
                        drv = uc.Chrome(options=options)
            except Exception as e:
                logging.error(f"[DRIVER] Failed to start undetectable chrome: {str(e)}")
                raise BrowserError(f"Undetectable Chrome failed: {str(e)}")
            
            BrowserManager._inject_stealth_scripts(drv)
            return drv
            
        else:
            _webdriver = _browser_options.get('webdriver')
            _options = _browser_options.get('options')()
            _options.add_argument('--no-sandbox')
            
            if _webdriver == webdriver.Chrome:
                _options.add_argument('--disable-speech-api')
                _options.add_argument('--disable-features=VoiceInteraction')
                _options.add_argument('--disable-background-networking')
                _options.add_argument('--disable-default-apps')
                try:
                    _options.add_experimental_option('excludeSwitches', ['enable-logging'])
                except:
                    pass
                
                if _use_tor:
                    _options.add_argument(f'--proxy-server=socks5://{_tor_proxy.get("socks")}:{_tor_proxy.get("port")}')

            if config.get("hidden", False):
                _options.add_argument("--headless")
            
            if _exec_path and os.path.isfile(_exec_path):
                _options.binary_location = _exec_path

            _proxy = _browser_options.get('proxy', {}) if not _use_tor else _tor_proxy
            
            if _proxy and _webdriver == webdriver.Firefox:
                from selenium.webdriver.common.proxy import Proxy, ProxyType
                proxy = Proxy()
                proxy.proxy_type = ProxyType.MANUAL
                proxy.socks_proxy = f"{_proxy.get('socks')}:{_proxy.get('port')}"
                proxy.socks_version = 5
                _options.proxy = proxy
                logging.info(f"[PROXY] Routing through: {_proxy.get('socks')}:{_proxy.get('port')}")
            
            logging.info(f"[DRIVER] Starting {_selected_browser} in detectable mode")
            # Use deepcopy to ensure each driver instance gets its own unique options object
            final_options = deepcopy(_options)
            dro = _webdriver(options=final_options)
            BrowserManager._inject_stealth_scripts(dro)
            return dro

    @staticmethod
    def _inject_stealth_scripts(driver):
        """Injects advanced stealth scripts to bypass bot detection."""
        stealth_js = """
        // Mask navigator.webdriver
        Object.defineProperty(navigator, 'webdriver', { get: () => false });

        // Add window.chrome
        window.chrome = { runtime: {}, loadTimes: Date.now, csi: () => {}, getProxyForUrl: () => {} };

        // Spoof languages and platform
        Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en', 'es'] });
        Object.defineProperty(navigator, 'platform', { get: () => 'Win32' });

        // Realistic hardware specs
        Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
        Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });

        // Spoof plugins
        Object.defineProperty(navigator, 'plugins', {
            get: () => [
                { description: "Portable Document Format", name: "Chrome PDF Plugin", filename: "internal-pdf-viewer" },
                { description: "", name: "Chrome PDF Viewer", filename: "mhjfbmdgcfjbbpaeojofohoefgieoaij" },
                { description: "", name: "Native Client", filename: "internal-nacl-plugin" }
            ],
        });

        // Spoof WebGL vendor/renderer for anti-fingerprinting
        const getParameter = WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter = function(parameter) {
            // UNMASKED_VENDOR_WEBGL
            if (parameter === 37445) return 'Google Inc. (Intel)';
            // UNMASKED_RENDERER_WEBGL
            if (parameter === 37446) return 'ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0)';
            return getParameter.apply(this, [parameter]);
        };

        // Fix permissions API
        if (window.navigator.permissions) {
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
                parameters.name === 'notifications' ?
                Promise.resolve({ state: Notification.permission }) :
                originalQuery(parameters)
            );
        }
        """
        try:
            # For Chrome/Brave/Edge
            if hasattr(driver, 'execute_cdp_cmd'):
                driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
                    'source': stealth_js
                })
            else:
                # Fallback for Firefox
                driver.execute_script(stealth_js)
        except Exception as e:
            logging.warning(f"[STEALTH] Failed to inject scripts: {e}")
