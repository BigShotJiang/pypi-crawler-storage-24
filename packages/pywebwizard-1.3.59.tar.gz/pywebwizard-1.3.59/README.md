# 🧙‍♂️ PyWebWizard: PyWebWizard Engine Edition (v1.3.59)

[![PyPI version](https://img.shields.io/pypi/v/pywebwizard?color=blue&logo=pypi)](https://pypi.org/project/pywebwizard/)
[![Downloads](https://static.pepy.tech/badge/pywebwizard)](https://pepy.tech/project/pywebwizard)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Versions](https://img.shields.io/pypi/pyversions/pywebwizard.svg)](https://pypi.org/project/pywebwizard/)

**PyWebWizard** is an industrial-grade autonomous navigation engine for stealthy web automation and resilient scraping. Designed for **resilience, stealth, and intelligence**, it enables orchestrating complex workflows via natural language missions or YAML "Spells", mimicking human behavior 100%.

---

## 💎 PyWebWizard Engine Technology Pillars

PyWebWizard integrates cutting-edge technologies to overcome the most advanced anti-bot defenses:

| Pillar | Technology | Status | Benefit |
| :--- | :--- | :--- | :--- |
| **Human Mimicry** | Bézier / Cadence | ✅ **Implemented** | 100% human-like mouse and keyboard interaction. |
| **VLM Perception** | Vision-Language Models | ✅ **Implemented** | Solves CAPTCHAs and reasons about UI layout. |
| **OODA Loop** | Dynamic Decision | 🟠 **In Progress** | Reasons and adapts to page changes in real-time. |
| **Dual Engine** | Selenium + Playwright | 🚀 **Roadmap** | Stealth for bypass, performance for scale. |

---

## 🚀 Features

-   **Dual Engine**: Seamless switching between Selenium (stealth) and Playwright (performance).
-   **VLM Perception**: AI-driven vision to solve CAPTCHAs and reason about UI layout.
-   **Human Mimicry**: Bézier mouse curves, randomized typing cadence, and realistic scroll patterns.
-   **OODA Loop Logic**: Dynamic decision-making based on visual and DOM feedback.

---

## 🔮 Examples: Spells & Missions

### 📜 YAML Spell (News Scraper)
```yaml
name: "News Scraper"
steps:
  - action: "open_url"
    url: "https://news.ycombinator.com"
  - action: "wait_for_selector"
    selector: ".athing"
  - action: "extract_list"
    selector: ".titleline > a"
    output_key: "headlines"
```

### 📝 JSON Mission (Search Automation)
```json
{
  "mission": "Search for PyWebWizard on Google",
  "steps": [
    { "action": "open_url", "url": "https://www.google.com" },
    { "action": "type", "selector": "textarea[name='q']", "text": "PyWebWizard Engine" },
    { "action": "press_key", "key": "Enter" },
    { "action": "wait", "seconds": 2 }
  ]
}
```

---

## 🛠️ Installation

```bash
pip install pywebwizard
```

## 🛡️ License

Software distributed under the **MIT** license.

---
*Designed with ❤️ by the Parendum team for the next generation of automation engineers.*
