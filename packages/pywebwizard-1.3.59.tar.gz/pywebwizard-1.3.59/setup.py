from setuptools import setup, find_packages
from pathlib import Path

# Definir la ruta base
base_dir = Path(__file__).resolve().parent

# Leer el contenido de los archivos externos
requirements_file = base_dir / 'requirements.txt'
readme_file = base_dir / 'README.md'

requirements = requirements_file.read_text().splitlines() if requirements_file.exists() else []
long_description = readme_file.read_text() if readme_file.exists() else ""

version="1.3.59"

setup(
    name="pywebwizard",
    version=version,
    long_description=long_description,
    long_description_content_type="text/markdown",
    description="Industrial-grade autonomous navigation engine for stealthy web automation and resilient scraping.",
    author="ConnorLilHomer",
    author_email="info@parendum.com",
    maintainer="ConnorLilHomer",
    maintainer_email="info@parendum.com",
    url="https://gitlab.com/connorlilhomer/pywebwizard",
    project_urls={
        "Documentation": "https://gitlab.com/connorlilhomer/pywebwizard/-/blob/main/README.md",
        "Source": "https://gitlab.com/connorlilhomer/pywebwizard",
        "Tracker": "https://gitlab.com/connorlilhomer/pywebwizard/-/issues",
    },
    download_url=f"https://gitlab.com/connorlilhomer/pywebwizard/-/archive/main/pywebwizard-{version}.tar.gz",
    packages=find_packages(exclude=["scripts", "devtools", "spells", "screenshots", "tests", "dist", "build"]),
    install_requires=requirements or [
        'selenium',
        'requests',
        'pyyaml',
        'playwright'
    ],
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: Browsers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License"
    ],
    license="MIT",
    keywords=[
        "web", "automation", "browser", "scraping", "python", "selenium",
        "headless", "browsing", "stealth", "anti-bot", "bypass", "resilient",
        "autonomous", "agent", "navigation", "crawler", "data extraction",
        "form automation", "captcha-bypass", "human-behavior", "OODA",
        "mimetismo", "automatización de navegadores", "robot", "SaaS",
        "professional-automation", "industrial-scraping"
    ],
    platforms=["Windows", "Linux", "MacOS"],
    python_requires='>=3.8, <3.15',
    include_package_data=False,
)
