from __future__ import annotations

import json
from pathlib import Path

from agentforge.cli.agent import agent_create


def test_agent_create_ensures_shared_git_repo_workspace(monkeypatch, tmp_path: Path) -> None:
    root = tmp_path
    (root / "bot").mkdir(parents=True, exist_ok=True)
    (root / "bot" / "config.json").write_text(
        json.dumps({"threads": {"default": {"model": "sonnet"}}, "telegram": {"topics": {}}}),
        encoding="utf-8",
    )

    monkeypatch.setenv("AGENTFORGE_ROOT", str(root))

    agent_create("builder")

    assert (root / "git-repos").is_dir()
    soul_text = (root / "agents" / "builder" / "soul.md").read_text(encoding="utf-8")
    assert "git-repos/" in soul_text
