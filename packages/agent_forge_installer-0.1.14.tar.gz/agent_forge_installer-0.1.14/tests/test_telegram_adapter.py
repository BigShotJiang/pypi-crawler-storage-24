"""Tests for telegram adapter identity checks."""

from agentforge.telegram_adapter import _verify_telegram_bot_identity


def test_verify_telegram_bot_identity_accepts_matching_username():
    result = _verify_telegram_bot_identity(
        "https://api.telegram.org/bottoken",
        "expected_bot",
        http_get_fn=lambda *_args, **_kwargs: {
            "ok": True,
            "result": {"username": "expected_bot"},
        },
    )
    assert result is True


def test_verify_telegram_bot_identity_rejects_mismatch():
    result = _verify_telegram_bot_identity(
        "https://api.telegram.org/bottoken",
        "expected_bot",
        http_get_fn=lambda *_args, **_kwargs: {
            "ok": True,
            "result": {"username": "other_bot"},
        },
    )
    assert result is False


def test_verify_telegram_bot_identity_tolerates_unverifiable():
    result = _verify_telegram_bot_identity(
        "https://api.telegram.org/bottoken",
        "expected_bot",
        http_get_fn=lambda *_args, **_kwargs: {
            "ok": False,
            "description": "Unauthorized",
        },
    )
    assert result is True
