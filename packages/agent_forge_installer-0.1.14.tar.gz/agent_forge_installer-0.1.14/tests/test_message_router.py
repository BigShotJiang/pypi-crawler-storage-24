"""Tests for agentforge.message_router — thread routing, mention parsing, topic context."""

import pytest

from agentforge.message_router import (
    build_topic_context,
    get_agent_thread_config,
    get_project_topic_config,
    get_thread_config,
    parse_mention,
)


class TestGetThreadConfig:
    """Test thread config resolution."""

    def test_known_thread(self, sample_config_dict):
        cfg = get_thread_config(13, sample_config_dict)
        assert cfg["name"] == "archie"
        assert cfg["model"] == "opus"

    def test_unknown_thread_falls_back_to_default(self, sample_config_dict):
        cfg = get_thread_config(999, sample_config_dict)
        assert cfg["model"] == "sonnet"
        assert cfg["context_messages"] == 5

    def test_none_thread_falls_back_to_default(self, sample_config_dict):
        cfg = get_thread_config(None, sample_config_dict)
        assert cfg["model"] == "sonnet"


class TestGetProjectTopicConfig:
    """Test project topic lookup."""

    def test_known_project_topic(self, sample_config_dict):
        cfg = get_project_topic_config(16, sample_config_dict)
        assert cfg is not None
        assert cfg["name"] == "dev"
        assert "archie" in cfg["agents"]

    def test_unknown_topic_returns_none(self, sample_config_dict):
        assert get_project_topic_config(999, sample_config_dict) is None

    def test_none_thread_returns_none(self, sample_config_dict):
        assert get_project_topic_config(None, sample_config_dict) is None


class TestGetAgentThreadConfig:
    """Test agent name → thread config lookup."""

    def test_known_agent(self, sample_config_dict):
        cfg = get_agent_thread_config("archie", sample_config_dict)
        assert cfg["model"] == "opus"

    def test_unknown_agent_falls_back(self, sample_config_dict):
        cfg = get_agent_thread_config("unknown_agent", sample_config_dict)
        assert cfg["name"] == "unknown_agent"
        assert cfg["model"] == "sonnet"


class TestParseMention:
    """Test @mention parsing in project topics."""

    @pytest.fixture
    def dev_project(self):
        return {
            "agents": ["archie", "victor"],
            "default_agent": "archie",
        }

    def test_exact_mention(self, dev_project):
        agent, text = parse_mention("@victor do the thing", dev_project)
        assert agent == "victor"
        assert "do the thing" in text
        assert "@victor" not in text

    def test_bot_username_prefix_match(self, dev_project):
        agent, text = parse_mention("@VictorClawdiaBot build it", dev_project)
        assert agent == "victor"
        assert "build it" in text

    def test_no_mention_uses_default(self, dev_project):
        agent, text = parse_mention("just do the work", dev_project)
        assert agent == "archie"
        assert text == "just do the work"

    def test_unknown_mention_uses_default(self, dev_project):
        agent, text = parse_mention("@catherine help me", dev_project)
        assert agent == "archie"
        assert "@catherine" in text  # not stripped since not in allowed list

    def test_mention_only_message(self, dev_project):
        agent, text = parse_mention("@victor", dev_project)
        assert agent == "victor"
        # Should return original text if cleaned text is empty
        assert text == "@victor"


class TestBuildTopicContext:
    """Test topic context string generation."""

    def test_context_string(self):
        project_cfg = {
            "label": "🏗 Dev",
            "agents": ["archie", "victor"],
        }
        ctx = build_topic_context(project_cfg, "archie")
        assert "🏗 Dev" in ctx
        assert "@victor" in ctx
        assert "@archie" not in ctx  # current agent excluded

    def test_single_agent_topic(self):
        project_cfg = {
            "label": "Solo",
            "agents": ["archie"],
        }
        ctx = build_topic_context(project_cfg, "archie")
        assert "Solo" in ctx
