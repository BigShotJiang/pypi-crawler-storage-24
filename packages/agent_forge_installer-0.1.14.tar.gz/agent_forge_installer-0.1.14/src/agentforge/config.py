"""AgentForge configuration module.

Loads and validates the bot config JSON file.
Config path: AGENTFORGE_CONFIG env var or $AGENTFORGE_ROOT/bot/config.json.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any


class ConfigError(Exception):
    """Raised when the config is missing required keys or is invalid."""


# ---------------------------------------------------------------------------
# Typed sub-configs
# ---------------------------------------------------------------------------

@dataclass
class TelegramConfig:
    token: str
    allowed_chat_ids: list[int]
    topics: dict[str, int]


@dataclass
class ClaudeConfig:
    model: str
    max_budget_usd: float


@dataclass
class HeartbeatConfig:
    interval_minutes: int
    max_budget_usd: float


@dataclass
class LoggingConfig:
    sheets_id: str


# ---------------------------------------------------------------------------
# Main config class
# ---------------------------------------------------------------------------

@dataclass
class AgentForgeConfig:
    telegram: TelegramConfig
    claude: ClaudeConfig
    threads: dict[str, Any]  # keyed by thread id (str), values are agent dicts
    heartbeat: HeartbeatConfig
    logging: LoggingConfig

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AgentForgeConfig":
        # Validate required keys
        tg = data.get("telegram", {})
        if not tg.get("allowed_chat_ids"):
            raise ConfigError("Missing required key: telegram.allowed_chat_ids")
        cl = data.get("claude", {})
        if not cl.get("model"):
            raise ConfigError("Missing required key: claude.model")

        telegram = TelegramConfig(
            token=tg.get("token", ""),
            allowed_chat_ids=tg.get("allowed_chat_ids", []),
            topics=tg.get("topics", {}),
        )
        claude = ClaudeConfig(
            model=cl["model"],
            max_budget_usd=float(cl.get("max_budget_usd", 0.5)),
        )
        hb = data.get("heartbeat", {})
        heartbeat = HeartbeatConfig(
            interval_minutes=int(hb.get("interval_minutes", 60)),
            max_budget_usd=float(hb.get("max_budget_usd", 0.1)),
        )
        lg = data.get("logging", {})
        logging_cfg = LoggingConfig(
            sheets_id=lg.get("sheets_id", ""),
        )
        return cls(
            telegram=telegram,
            claude=claude,
            threads=data.get("threads", {}),
            heartbeat=heartbeat,
            logging=logging_cfg,
        )

    @classmethod
    def load(cls, path: str | None = None) -> "AgentForgeConfig":
        if path is None:
            path = os.environ.get("AGENTFORGE_CONFIG")
        if path is None:
            root = os.environ.get("AGENTFORGE_ROOT", "/home/clawdia")
            path = os.path.join(root, "bot", "config.json")
        with open(path) as f:
            data = json.load(f)
        return cls.from_dict(data)


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_instance: AgentForgeConfig | None = None


def get_config(path: str | None = None) -> AgentForgeConfig:
    """Return the singleton AgentForgeConfig, loading it on first call."""
    global _instance
    if _instance is None:
        _instance = AgentForgeConfig.load(path)
    return _instance


def reset_config() -> None:
    """Reset the singleton (useful for tests)."""
    global _instance
    _instance = None
