# Google Scholar API 文档

通过 AI4Scholar 平台代理访问 Google Scholar 学术搜索。

## 基本信息

| 项目 | 说明 |
|------|------|
| Base URL | `https://ai4scholar.net` |
| 认证方式 | Bearer Token（API Key） |
| 积分消耗 | 1 积分/次 |
| 每页结果 | 固定 10 条（Google Scholar 限制） |

## 认证

所有请求需要在 Header 中携带 API Key：

```
Authorization: Bearer sk-user-xxxxx
```

API Key 可在 [AI4Scholar 控制台](https://ai4scholar.net/dashboard?view=api-keys) 获取。

---

## 接口列表

### 搜索文献

搜索 Google Scholar 学术文献，支持年份筛选。

**请求**

```
POST /google-scholar/v1/search
```

**请求参数（JSON Body）**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `query` | string | 是 | 搜索关键词 |
| `page` | number | 否 | 页码，默认 1 |
| `yearFrom` | number | 否 | 起始年份（如 2020），不填则不限 |
| `yearTo` | number | 否 | 结束年份（如 2025），不填则不限 |

**响应字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| `query` | string | 搜索关键词 |
| `page` | number | 当前页码 |
| `resultsCount` | number | 当前页返回条数 |
| `results` | array | 搜索结果列表 |

**results 中每条记录的字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| `title` | string | 论文标题 |
| `link` | string | 论文链接 |
| `publicationInfo` | string | 作者/出版信息（如 "Y LeCun, Y Bengio - nature, 2015"） |
| `year` | number/null | 发表年份 |
| `citedBy` | number/null | 被引用次数 |
| `snippet` | string | 摘要片段 |
| `pdfUrl` | string/null | PDF 下载链接（如有） |

---

## 使用示例

### cURL

```bash
# 基础搜索
curl -X POST "https://ai4scholar.net/google-scholar/v1/search" \
  -H "Authorization: Bearer sk-user-xxxxx" \
  -H "Content-Type: application/json" \
  -d '{"query": "deep learning"}'

# 带年份筛选
curl -X POST "https://ai4scholar.net/google-scholar/v1/search" \
  -H "Authorization: Bearer sk-user-xxxxx" \
  -H "Content-Type: application/json" \
  -d '{"query": "transformer attention", "page": 1, "yearFrom": 2023}'

# 翻页
curl -X POST "https://ai4scholar.net/google-scholar/v1/search" \
  -H "Authorization: Bearer sk-user-xxxxx" \
  -H "Content-Type: application/json" \
  -d '{"query": "CRISPR gene editing", "page": 2}'
```

### Python

```python
import requests

API_KEY = "sk-user-xxxxx"
BASE_URL = "https://ai4scholar.net"

def search_google_scholar(query, page=1, year_from=None, year_to=None):
    url = f"{BASE_URL}/google-scholar/v1/search"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {"query": query, "page": page}
    if year_from:
        payload["yearFrom"] = year_from
    if year_to:
        payload["yearTo"] = year_to

    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()
    return response.json()

# 搜索示例
result = search_google_scholar("deep learning", page=1, year_from=2023)

print(f"共 {result['resultsCount']} 条结果\n")
for item in result["results"]:
    print(f"  {item['title']}")
    print(f"  {item['publicationInfo']}")
    print(f"  Year: {item['year']}  Cited by: {item['citedBy']}")
    if item['pdfUrl']:
        print(f"  PDF: {item['pdfUrl']}")
    print()
```

### JavaScript / Node.js

```javascript
const API_KEY = "sk-user-xxxxx";

async function searchGoogleScholar(query, page = 1, yearFrom, yearTo) {
  const body = { query, page };
  if (yearFrom) body.yearFrom = yearFrom;
  if (yearTo) body.yearTo = yearTo;

  const res = await fetch("https://ai4scholar.net/google-scholar/v1/search", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text()}`);
  return res.json();
}

// 使用示例
const data = await searchGoogleScholar("deep learning", 1, 2023);
console.log(`共 ${data.resultsCount} 条结果`);
data.results.forEach((item) => {
  console.log(`${item.title} (${item.year}) - Cited by: ${item.citedBy}`);
});
```

---

## 响应示例

```json
{
  "query": "deep learning",
  "page": 1,
  "resultsCount": 10,
  "results": [
    {
      "title": "Deep learning",
      "link": "https://www.nature.com/articles/nature14539",
      "publicationInfo": "Y LeCun, Y Bengio, G Hinton - nature, 2015 - nature.com",
      "year": 2015,
      "citedBy": 107690,
      "snippet": "Deep learning allows computational models that are composed of multiple processing layers to learn...",
      "pdfUrl": "https://hal.science/hal-04206682/document"
    }
  ]
}
```

---

## 错误码

| HTTP 状态码 | 错误码 | 说明 |
|-------------|--------|------|
| 401 | `MISSING_API_KEY` | 缺少 Authorization header |
| 401 | `INVALID_API_KEY` | API Key 无效 |
| 402 | `INSUFFICIENT_CREDITS` | 积分不足 |
| 400 | `INVALID_REQUEST` | 缺少 query 参数 |
| 429 | `TOO_MANY_FAILED_REQUESTS` | 请求失败过多，被临时封禁 |
| 500 | `PROXY_ERROR` | 上游 API 调用失败 |

---

## 响应 Header

| Header | 说明 |
|--------|------|
| `X-Credits-Remaining` | 剩余积分 |
| `X-Credits-Charged` | 本次消耗积分 |

---

## 注意事项

1. 每页固定返回 10 条结果，这是 Google Scholar 的限制
2. 结果默认按相关性排列，不支持自定义排序
3. `pdfUrl` 不一定每条都有，取决于 Google Scholar 是否找到 PDF 链接
4. 建议合理使用翻页，避免过多请求
