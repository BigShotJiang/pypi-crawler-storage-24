# 科研画图 API（Nano Banana）

AI 驱动的科研绘图工具，支持智能生成、编辑修改、风格迁移、SVG 矢量图、迭代优化等多种模式。

## 基本信息

| 项目 | 说明 |
|------|------|
| 端点 | `POST /api/proxy/nano/generate` |
| Base URL | `https://ai4scholar.net` |
| 认证方式 | `Authorization: Bearer <API Key>` |
| 响应格式 | `application/json` |
| 超时 | 最长 5 分钟 |

---

## 积分定价

最终积分 = **基础积分 × 模型倍率 × 尺寸倍率**（向上取整）

### 基础积分（按 action）

| action | 功能说明 | 基础积分 |
|--------|----------|----------|
| `smart` | 智能生成（自动优化 prompt 后生成） | 2 |
| `generate` | 直接生成（按原始 prompt 生成） | 2 |
| `edit` | 编辑修改（基于参考图修改） | 2 |
| `style` | 风格迁移（将参考图转为指定风格） | 2 |
| `compose` | 多图合成（合并多张参考图） | 3 |
| `svg` | SVG 矢量图生成 | **1**（固定，不受模型/尺寸影响） |
| `iterate` | 迭代优化（AI 评价后自动改进） | 5 |
| `critic` | 图像评价（仅返回文字评价） | **1**（固定，不受模型/尺寸影响） |

### 模型倍率

| model | 对应模型 | 倍率 |
|-------|---------|------|
| `flash` | Gemini 2.5 Flash Image | 1.5× |
| `flash31` | Gemini 3.1 Flash Image Preview | 2× |
| `pro` | Gemini 3 Pro Image Preview | 5× |

### 尺寸倍率

| model \ imageSize | 512px | 1K | 2K | 4K |
|-------------------|-------|-----|-----|-----|
| `flash` | 1× | 1× | 1× | 1× |
| `flash31` | 0.5× | 1× | 1.5× | 2× |
| `pro` | 0.5× | 1× | 1.2× | 1.6× |

### 定价示例

| 场景 | 计算 | 积分 |
|------|------|------|
| `smart` + `flash` + `2K` | 2 × 1.5 × 1 = 3 | **3** |
| `generate` + `flash31` + `4K` | 2 × 2 × 2 = 8 | **8** |
| `generate` + `pro` + `1K` | 2 × 5 × 1 = 10 | **10** |
| `compose` + `flash31` + `2K` | 3 × 2 × 1.5 = 9 | **9** |
| `svg`（任意模型/尺寸） | 固定 | **1** |
| `critic`（任意模型/尺寸） | 固定 | **1** |

---

## 请求参数

**Content-Type**: `application/json`

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `action` | string | **是** | — | 操作类型：`smart` / `generate` / `edit` / `style` / `compose` / `svg` / `iterate` / `critic` |
| `prompt` | string | **是*** | — | 图像描述文字（`critic` 模式除外） |
| `model` | string | 否 | `"flash"` | 模型选择：`flash` / `flash31` / `pro` |
| `aspectRatio` | string | 否 | `"1:1"` | 宽高比 |
| `imageSize` | string | 否 | `"2K"` | 分辨率：`512px` / `1K` / `2K` / `4K` |
| `stylePreset` | string | 否 | — | 风格预设（`style` 模式用） |
| `images` | string[] | 否 | — | 参考图片 URL 列表（`edit` / `style` / `compose` / `iterate` / `critic` 用） |
| `lang` | string | 否 | — | 语言偏好：`"en"` / `"zh"` |

### 支持的宽高比

`1:1`, `1:4`, `1:8`, `2:3`, `3:2`, `3:4`, `4:1`, `4:3`, `4:5`, `5:4`, `8:1`, `9:16`, `16:9`, `21:9`

### 风格预设（stylePreset）

| 值 | 风格 |
|----|------|
| `vangogh` | 梵高星空 |
| `monet` | 莫奈印象 |
| `davinci` | 达芬奇手稿 |
| `ukiyoe` | 浮世绘 |
| `pixel` | 像素风 |
| `watercolor` | 水彩画 |
| `cyberpunk` | 赛博朋克 |
| `ghibli` | 吉卜力 |

---

## 各 action 详解

### `smart` — 智能生成

自动优化用户 prompt，生成更高质量的科研图像。返回优化后的 prompt 和图片。

```json
{
  "action": "smart",
  "prompt": "a diagram showing the architecture of a transformer model",
  "model": "flash31",
  "imageSize": "2K",
  "aspectRatio": "16:9"
}
```

### `generate` — 直接生成

按原始 prompt 直接生成，不做优化。

```json
{
  "action": "generate",
  "prompt": "a scientific diagram of DNA double helix structure with labeled components",
  "model": "flash",
  "imageSize": "2K"
}
```

### `edit` — 编辑修改

基于参考图片进行修改。

```json
{
  "action": "edit",
  "prompt": "add axis labels and a legend to this chart",
  "images": ["https://example.com/my-chart.png"],
  "model": "flash31"
}
```

### `style` — 风格迁移

将参考图片转换为指定艺术风格。

```json
{
  "action": "style",
  "prompt": "convert to scientific illustration style",
  "images": ["https://example.com/photo.jpg"],
  "stylePreset": "davinci",
  "model": "flash"
}
```

### `compose` — 多图合成

将多张图片合成为一张。

```json
{
  "action": "compose",
  "prompt": "combine these figures into a 2x2 grid layout with labels (a), (b), (c), (d)",
  "images": [
    "https://example.com/fig1.png",
    "https://example.com/fig2.png",
    "https://example.com/fig3.png",
    "https://example.com/fig4.png"
  ],
  "model": "flash31",
  "aspectRatio": "1:1"
}
```

### `svg` — SVG 矢量图

生成 SVG 格式的矢量图（适合论文插图、流程图等）。固定 1 积分。

```json
{
  "action": "svg",
  "prompt": "a flowchart showing the machine learning pipeline: data collection -> preprocessing -> training -> evaluation -> deployment"
}
```

### `iterate` — 迭代优化

AI 先评价图像，然后自动生成改进版本。

```json
{
  "action": "iterate",
  "prompt": "improve the quality and clarity of this scientific diagram",
  "images": ["https://example.com/draft-figure.png"],
  "model": "pro"
}
```

### `critic` — 图像评价

仅返回对图像的文字评价和改进建议，不生成新图片。固定 1 积分，不需要 prompt。

```json
{
  "action": "critic",
  "images": ["https://example.com/my-figure.png"]
}
```

---

## 响应字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `success` | boolean | 是否成功 |
| `imageUrl` | string \| null | 生成的图片 URL |
| `svgCode` | string \| null | SVG 源代码（`svg` 模式） |
| `svgUrl` | string \| null | SVG 文件 URL（`svg` 模式） |
| `optimizedPrompt` | string \| null | 优化后的 prompt（`smart` 模式） |
| `critique` | string \| null | 图像评价文字（`critic` / `iterate` 模式） |
| `creditCost` | number | 实际消耗积分 |

### 成功响应示例

```json
{
  "success": true,
  "imageUrl": "https://storage.example.com/generated/abc123.png",
  "optimizedPrompt": "A detailed architectural diagram of the Transformer model...",
  "creditCost": 3
}
```

### SVG 响应示例

```json
{
  "success": true,
  "svgCode": "<svg xmlns=\"http://www.w3.org/2000/svg\" ...>...</svg>",
  "svgUrl": "https://storage.example.com/svg/def456.svg",
  "creditCost": 1
}
```

---

## 使用示例

### cURL

```bash
# 智能生成
curl -X POST "https://ai4scholar.net/api/proxy/nano/generate" \
  -H "Authorization: Bearer sk-user-xxxxx" \
  -H "Content-Type: application/json" \
  -d '{
    "action": "smart",
    "prompt": "a neural network architecture diagram showing encoder-decoder structure",
    "model": "flash31",
    "imageSize": "2K",
    "aspectRatio": "16:9"
  }'

# SVG 流程图
curl -X POST "https://ai4scholar.net/api/proxy/nano/generate" \
  -H "Authorization: Bearer sk-user-xxxxx" \
  -H "Content-Type: application/json" \
  -d '{
    "action": "svg",
    "prompt": "a flowchart of the experimental methodology: hypothesis -> experiment design -> data collection -> analysis -> conclusion"
  }'

# 图像评价
curl -X POST "https://ai4scholar.net/api/proxy/nano/generate" \
  -H "Authorization: Bearer sk-user-xxxxx" \
  -H "Content-Type: application/json" \
  -d '{
    "action": "critic",
    "images": ["https://example.com/my-figure.png"]
  }'
```

### Python

```python
import requests

API_KEY = "sk-user-xxxxx"
BASE_URL = "https://ai4scholar.net"

def nano_generate(action, prompt=None, **kwargs):
    """调用 Nano Banana 科研画图 API"""
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {"action": action, **kwargs}
    if prompt:
        payload["prompt"] = prompt

    resp = requests.post(
        f"{BASE_URL}/api/proxy/nano/generate",
        headers=headers,
        json=payload,
        timeout=300,
    )
    resp.raise_for_status()
    return resp.json()


# 智能生成
result = nano_generate(
    "smart",
    prompt="a comparison chart of different optimization algorithms",
    model="flash31",
    imageSize="2K",
    aspectRatio="16:9",
)
print(f"图片: {result['imageUrl']}")
print(f"优化 Prompt: {result.get('optimizedPrompt')}")
print(f"消耗: {result['creditCost']} 积分")


# SVG 矢量图
result = nano_generate(
    "svg",
    prompt="a Venn diagram showing the relationship between AI, ML, and Deep Learning",
)
print(f"SVG URL: {result['svgUrl']}")
# 保存 SVG 文件
with open("output.svg", "w") as f:
    f.write(result["svgCode"])


# 风格迁移
result = nano_generate(
    "style",
    prompt="convert to watercolor painting style",
    images=["https://example.com/photo.jpg"],
    stylePreset="watercolor",
)
print(f"风格迁移: {result['imageUrl']}")


# 图像评价
result = nano_generate(
    "critic",
    images=["https://example.com/my-figure.png"],
)
print(f"评价: {result['critique']}")


# 编辑修改
result = nano_generate(
    "edit",
    prompt="increase font size of all labels and add grid lines",
    images=["https://example.com/chart.png"],
    model="flash31",
)
print(f"编辑后: {result['imageUrl']}")
```

### JavaScript / Node.js

```javascript
const API_KEY = "sk-user-xxxxx";

async function nanoGenerate(action, prompt, options = {}) {
  const body = { action, ...options };
  if (prompt) body.prompt = prompt;

  const res = await fetch("https://ai4scholar.net/api/proxy/nano/generate", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(`${err.error}: ${err.message}`);
  }
  return res.json();
}

// 智能生成
const result = await nanoGenerate("smart", "a bar chart comparing model accuracy", {
  model: "flash31",
  imageSize: "2K",
});
console.log(`Image: ${result.imageUrl}`);
console.log(`Cost: ${result.creditCost} credits`);

// SVG 生成
const svg = await nanoGenerate("svg", "a timeline of major AI milestones from 2012 to 2024");
console.log(`SVG: ${svg.svgUrl}`);
```

---

## 错误码

| HTTP 状态码 | 错误码 | 说明 |
|-------------|--------|------|
| 400 | `INVALID_REQUEST` | JSON 请求体无效 |
| 400 | `INVALID_ACTION` | 不支持的 action 类型 |
| 400 | `MISSING_PROMPT` | 缺少 prompt（非 critic 模式） |
| 401 | `MISSING_API_KEY` | 缺少 Authorization header |
| 401 | `INVALID_API_KEY` | API Key 无效 |
| 402 | `INSUFFICIENT_CREDITS` | 积分不足 |
| 429 | `TOO_MANY_FAILED_REQUESTS` | 触发防滥用保护 |
| 500 | `GENERATION_ERROR` | 生成失败（积分已退还） |

## 响应 Header

| Header | 说明 |
|--------|------|
| `X-Credits-Charged` | 本次消耗积分 |
| `X-Credits-Remaining` | 剩余积分 |

## 注意事项

1. 图片生成可能需要 10–60 秒，请设置足够的超时时间（建议 300 秒）
2. 生成失败时积分会自动退还
3. `images` 中的 URL 必须是公网可访问的图片链接
4. SVG 模式固定 1 积分，不受模型和尺寸参数影响
5. `pro` 模型质量最高但价格也最高（5× 倍率），建议先用 `flash` 测试效果
6. 生成的图片 URL 有效期较长，但建议及时下载保存
