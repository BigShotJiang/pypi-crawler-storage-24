# 本地模式使用指南 / Local Mode Guide

[English](#local-mode-guide) | [中文](#本地模式使用指南-1)

---

## Local Mode Guide

Local mode (stdio) runs the MCP server on your own machine. Compared to remote SSE mode, it has two key advantages:

- **PDF Download** — download papers directly to your computer
- **Campus Network Access** — leverage your institution's IP to download paywalled papers (Springer, Nature, Wiley, Elsevier, IEEE, etc.)

### Step 1: Install

```bash
pip install ai4scholar-mcp
```

If you already have it installed, upgrade to the latest version:

```bash
pip install --upgrade ai4scholar-mcp
```

### Step 2: Get API Key

Register at [ai4scholar.net](https://ai4scholar.net) and obtain your API Key. The key is required for search tools (PubMed, Semantic Scholar, Google Scholar).

### Step 3: Configure Your AI Client

Choose your client below and follow the configuration instructions.

> If you previously used SSE mode, replace the existing `ai4scholar` entry with the new stdio config below. For CLI-based clients (Claude Code, Gemini CLI), run the remove command first.

#### Cursor

Edit `.cursor/mcp.json` in your project (or global config):

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

#### Claude Desktop

Edit config file (Mac: `~/Library/Application Support/Claude/claude_desktop_config.json`, Windows: `%APPDATA%\Claude\claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

#### Claude Code

If you previously configured SSE mode, remove it first (add `--scope user` to remove global config):

```bash
claude mcp remove ai4scholar --scope user
```

Then add the local stdio server globally (available in all projects):

```bash
claude mcp add ai4scholar --scope user --transport stdio -e AI4SCHOLAR_API_KEY=<your-api-key> -- python -m ai4scholar_mcp.server
```

> Note: `--scope user` makes the config global. Without it, the config only applies to the current project directory. If you have project-level configs to clean up, run `claude mcp remove ai4scholar` in each project directory, or edit `~/.claude.json` directly.

#### VS Code (Copilot)

Edit `.vscode/mcp.json` in your project:

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

#### Gemini CLI

```bash
gemini mcp add ai4scholar -- python -m ai4scholar_mcp.server
```

Then set the environment variable before running Gemini CLI:

```bash
export AI4SCHOLAR_API_KEY=<your-api-key>
```

#### TRAE

Go to **MCP → Add → Manual Setup**, paste:

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

#### OpenClaw

Edit `~/.openclaw/config.json` and add to `mcpServers`:

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

### Step 4: Use It

Try these prompts with your AI assistant:

- "Search for recent papers on large language models"
- "Download the PDF for DOI 10.1038/s41586-024-07487-w"
- "Read the full text of arXiv paper 2301.00234"

Downloaded PDFs are saved to `./downloads/` in your current working directory by default.

### FAQ

**Q: `python` command not found?**

Try `python3` instead. Replace `"command": "python"` with `"command": "python3"` in the config, or for CLI commands use `python3 -m ai4scholar_mcp.server`.

**Q: Can I download paywalled papers?**

Yes, if you're on a campus network. The download requests go through your local IP, so if your institution has a subscription, it works automatically. Try `download_pdf_by_doi` with the paper's DOI.

**Q: Where are PDFs saved?**

By default in `./downloads/` relative to your working directory. You can specify a different path via the `save_path` parameter.

---
---

## 本地模式使用指南

本地模式（stdio）将 MCP 服务器运行在你自己的电脑上。相比远程 SSE 模式，有两大优势：

- **PDF 下载** — 论文直接下载到你的电脑
- **校园网权限** — 利用机构 IP 下载付费论文（Springer、Nature、Wiley、Elsevier、IEEE 等）

### 第一步：安装

```bash
pip install ai4scholar-mcp
```

如果已经安装过，请升级到最新版本：

```bash
pip install --upgrade ai4scholar-mcp
```

### 第二步：获取 API Key

在 [ai4scholar.net](https://ai4scholar.net) 注册并获取 API Key。搜索工具（PubMed、Semantic Scholar、Google Scholar）需要此密钥。

### 第三步：配置 AI 客户端

选择你使用的客户端，按照说明配置。

> 如果之前使用过 SSE 模式，请将配置中的 `ai4scholar` 条目替换为下面的 stdio 配置。CLI 工具（Claude Code、Gemini CLI）需要先执行删除命令。

#### Cursor

编辑项目中的 `.cursor/mcp.json`（或全局配置）：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

#### Claude Desktop

编辑配置文件（Mac: `~/Library/Application Support/Claude/claude_desktop_config.json`，Windows: `%APPDATA%\Claude\claude_desktop_config.json`）：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

#### Claude Code

如果之前配置过 SSE 模式，先删除旧配置（加 `--scope user` 删除全局配置）：

```bash
claude mcp remove ai4scholar --scope user
```

然后全局添加本地 stdio 服务（所有项目通用）：

```bash
claude mcp add ai4scholar --scope user --transport stdio -e AI4SCHOLAR_API_KEY=<your-api-key> -- python -m ai4scholar_mcp.server
```

> 注意：`--scope user` 使配置全局生效。不加则仅对当前项目目录有效。如需清理已有的项目级配置，请在对应项目目录下执行 `claude mcp remove ai4scholar`，或直接编辑 `~/.claude.json`。

#### VS Code (Copilot)

编辑项目中的 `.vscode/mcp.json`：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

#### Gemini CLI

```bash
gemini mcp add ai4scholar -- python -m ai4scholar_mcp.server
```

运行 Gemini CLI 前设置环境变量：

```bash
export AI4SCHOLAR_API_KEY=<your-api-key>
```

#### TRAE

进入 **MCP → 添加 → 手动添加**，粘贴以下配置：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

#### OpenClaw

编辑 `~/.openclaw/config.json`，在 `mcpServers` 中添加：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

### 第四步：开始使用

对 AI 助手说：

- "帮我搜索关于大语言模型的最新论文"
- "下载 DOI 为 10.1038/s41586-024-07487-w 的论文 PDF"
- "阅读 arXiv 论文 2301.00234 的全文"

下载的 PDF 默认保存在当前工作目录的 `./downloads/` 文件夹中。

### 常见问题

**Q：提示找不到 `python` 命令？**

请尝试使用 `python3`。将配置中的 `"command": "python"` 改为 `"command": "python3"`，命令行中使用 `python3 -m ai4scholar_mcp.server`。

**Q：能下载付费论文吗？**

可以，前提是你在校园网环境下。下载请求从你的本机 IP 发出，如果学校有订阅，就能自动利用机构权限。使用 `download_pdf_by_doi` 工具并提供论文的 DOI 即可。

**Q：PDF 下载到哪了？**

默认保存在当前工作目录下的 `./downloads/` 文件夹。可以通过 `save_path` 参数指定其他路径。
