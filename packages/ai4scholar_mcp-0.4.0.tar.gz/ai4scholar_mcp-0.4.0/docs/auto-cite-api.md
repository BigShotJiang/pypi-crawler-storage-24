# 文献自动标注 API（Auto-Cite）

输入一段学术文本，AI 自动识别需要引用的位置，搜索匹配参考文献，输出带引用标记的文本和格式化的参考文献列表。

## 基本信息

| 项目 | 说明 |
|------|------|
| 端点 | `POST /api/proxy/auto-cite` |
| Base URL | `https://ai4scholar.net` |
| 认证方式 | `Authorization: Bearer <API Key>` |
| 响应格式 | `text/event-stream`（SSE，Server-Sent Events） |
| 超时 | 最长 5 分钟 |

## 积分消耗

- **自动模式**：`minCitations` × 1 积分（默认 10 积分）
- **手动模式**：文本中 `[CITE]` 标记数 × 1 积分
- **处理失败或未找到文献**：全额退还

---

## 请求参数

**Content-Type**: `application/json`

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `text` | string | **是** | — | 学术文本，100–10,000 字符 |
| `mode` | string | 否 | `"auto"` | `"auto"`：自动识别引用位置；`"manual"`：用户在文本中手动放置 `[CITE]` 或 `[CITE:hint]` 标记 |
| `minCitations` | number | 否 | `10` | 自动模式下最少生成的引用数量 |
| `maxReferences` | number | 否 | — | 最多返回的参考文献数量 |
| `preferredVenues` | string[] | 否 | — | 优先匹配的期刊列表，如 `["Nature", "Science", "CVPR"]` |
| `field` | string | 否 | — | 学科领域，如 `"computer science"`, `"biology"` |
| `yearPreference` | number | 否 | — | 优先引用的年份附近的文献 |
| `excludePreprints` | boolean | 否 | `false` | 是否排除预印本（arXiv 等） |
| `excludeConferences` | boolean | 否 | `false` | 是否排除会议论文 |
| `citationStyle` | string | 否 | `"ieee"` | 引用格式，见下方支持列表 |

### 支持的引用格式（citationStyle）

| 值 | 格式 |
|----|------|
| `ieee` | IEEE |
| `apa` | APA 7th Edition |
| `apa6` | APA 6th Edition |
| `nature` | Nature |
| `vancouver` | Vancouver |
| `mla` | MLA 9th Edition |
| `chicago` | Chicago Author-Date |
| `harvard` | Harvard |
| `acs` | ACS (American Chemical Society) |
| `ama` | AMA (American Medical Association) |
| `acm` | ACM |
| `turabian` | Turabian |
| `cse` | CSE (Council of Science Editors) |
| `asce` | ASCE (American Society of Civil Engineers) |
| `gbt7714` | GB/T 7714（中国国标） |

### 手动模式标记语法

在 `mode: "manual"` 下，在文本中插入以下标记指定引用位置：

- `[CITE]` — 让 AI 自动选择合适的文献
- `[CITE:keyword]` — 提示 AI 搜索特定主题的文献，如 `[CITE:transformer attention mechanism]`

---

## SSE 响应

响应为标准的 Server-Sent Events 流，包含以下事件类型：

### `progress` 事件

处理进度更新，在整个流水线中会多次发送。

```
event: progress
data: {"step": "analyzing", "message": "正在分析文本...", "percent": 10}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `step` | string | 当前步骤标识 |
| `message` | string | 中文进度描述 |
| `percent` | number | 完成百分比（0–100） |

### `result` 事件

处理完成，返回最终结果。

```
event: result
data: {"annotatedText": "...", "references": [...], "candidates": {...}}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `annotatedText` | string | 带引用标记的文本，如 `"...has been shown [1] to improve..."` |
| `references` | Reference[] | 格式化的参考文献列表 |
| `candidates` | object | 每个引用位置的候选文献（供替换用） |

**Reference 对象字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| `number` | number | 参考文献编号 |
| `formatted` | string | 格式化后的引用文本 |
| `title` | string | 论文标题 |
| `authors` | string[] | 作者列表 |
| `year` | number | 发表年份 |
| `venue` | string | 期刊/会议名称 |
| `doi` | string | DOI |
| `relevanceScore` | number | 与原文的相关度（0–1） |

### `error` 事件

处理过程中发生错误（积分已自动退还）。

```
event: error
data: {"code": "PROCESSING_ERROR", "message": "处理过程中出现错误，积分已退还"}
```

---

## 使用示例

### cURL

```bash
curl -N -X POST "https://ai4scholar.net/api/proxy/auto-cite" \
  -H "Authorization: Bearer sk-user-xxxxx" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Deep learning has revolutionized many fields of artificial intelligence. Convolutional neural networks have achieved remarkable success in image recognition tasks. The attention mechanism has become a fundamental component in modern natural language processing systems. Transfer learning approaches have significantly reduced the amount of labeled data required for training.",
    "mode": "auto",
    "minCitations": 5,
    "citationStyle": "ieee"
  }'
```

### Python

```python
import requests
import json

API_KEY = "sk-user-xxxxx"
BASE_URL = "https://ai4scholar.net"

def auto_cite(text, mode="auto", min_citations=10, citation_style="ieee", **kwargs):
    """调用 Auto-Cite API，返回带引用的文本和参考文献列表"""
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "text": text,
        "mode": mode,
        "minCitations": min_citations,
        "citationStyle": citation_style,
        **kwargs,
    }

    resp = requests.post(
        f"{BASE_URL}/api/proxy/auto-cite",
        headers=headers,
        json=payload,
        stream=True,
    )
    resp.raise_for_status()

    result = None
    for line in resp.iter_lines(decode_unicode=True):
        if not line:
            continue

        if line.startswith("event: "):
            event_type = line[7:]
            continue

        if line.startswith("data: "):
            data = json.loads(line[6:])

            if event_type == "progress":
                print(f"[{data.get('percent', 0)}%] {data.get('message', '')}")

            elif event_type == "result":
                result = data

            elif event_type == "error":
                raise Exception(f"Auto-Cite error: {data.get('message')}")

    return result


# 使用示例
text = """
Deep learning has revolutionized many fields of artificial intelligence.
Convolutional neural networks have achieved remarkable success in image
recognition tasks. The attention mechanism has become a fundamental
component in modern natural language processing systems.
"""

result = auto_cite(text, min_citations=5, citation_style="apa")

print("\n=== Annotated Text ===")
print(result["annotatedText"])

print("\n=== References ===")
for ref in result["references"]:
    print(f"[{ref['number']}] {ref['formatted']}")
```

### Python（手动模式）

```python
text = """
Transformer architecture [CITE:transformer original paper] has become the
foundation of modern NLP. Pre-trained language models [CITE:BERT GPT]
have achieved state-of-the-art results on various benchmarks. Recent work
on vision transformers [CITE:ViT image transformer] has extended the
transformer paradigm to computer vision.
"""

result = auto_cite(text, mode="manual", citation_style="nature")
```

### JavaScript / Node.js

```javascript
const API_KEY = "sk-user-xxxxx";

async function autoCite(text, options = {}) {
  const resp = await fetch("https://ai4scholar.net/api/proxy/auto-cite", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ text, mode: "auto", minCitations: 10, ...options }),
  });

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let result = null;
  let eventType = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const lines = decoder.decode(value, { stream: true }).split("\n");
    for (const line of lines) {
      if (line.startsWith("event: ")) eventType = line.slice(7);
      if (line.startsWith("data: ")) {
        const data = JSON.parse(line.slice(6));
        if (eventType === "progress") {
          console.log(`[${data.percent}%] ${data.message}`);
        } else if (eventType === "result") {
          result = data;
        }
      }
    }
  }
  return result;
}

// 使用
const result = await autoCite("Deep learning has revolutionized...", {
  minCitations: 5,
  citationStyle: "ieee",
});
console.log(result.annotatedText);
result.references.forEach((r) => console.log(`[${r.number}] ${r.formatted}`));
```

---

## 错误码

| HTTP 状态码 | 错误码 | 说明 |
|-------------|--------|------|
| 400 | `INVALID_REQUEST` | JSON 请求体无效 |
| 400 | `MISSING_TEXT` | 缺少 `text` 字段 |
| 400 | `TEXT_TOO_SHORT` | 文本少于 100 字符 |
| 400 | `TEXT_TOO_LONG` | 文本超过 10,000 字符 |
| 400 | `NO_CITE_MARKERS` | 手动模式下未检测到 `[CITE]` 标记 |
| 401 | `MISSING_API_KEY` | 缺少 Authorization header |
| 401 | `INVALID_API_KEY` | API Key 无效 |
| 402 | `INSUFFICIENT_CREDITS` | 积分不足 |
| 429 | `TOO_MANY_FAILED_REQUESTS` | 触发防滥用保护 |

## 响应 Header

| Header | 说明 |
|--------|------|
| `X-Credits-Charged` | 本次消耗积分 |
| `X-Credits-Remaining` | 剩余积分 |

## 注意事项

1. 文本长度建议在 200–5,000 字符之间，过短可能导致引用点不足，过长会增加处理时间
2. SSE 流可能持续 30 秒到数分钟，请设置足够的超时时间
3. 处理过程中如果出错，积分会自动退还
4. 如果未找到任何匹配文献，积分也会全额退还
5. `preferredVenues` 不保证所有引用都来自指定期刊，仅作为优先级提示
