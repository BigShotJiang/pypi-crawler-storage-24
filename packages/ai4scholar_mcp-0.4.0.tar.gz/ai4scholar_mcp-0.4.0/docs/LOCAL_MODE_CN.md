# AI4Scholar MCP 本地安装教程

## 为什么选择本地模式？

本地模式（stdio）将 MCP 服务器运行在你自己的电脑上，相比云端 SSE 模式有两大优势：

- **PDF 下载** — 论文 PDF 直接下载到你的电脑，随时查看
- **校园网权限** — 在校园网环境下，可利用机构 IP 下载付费论文（Springer、Nature、Wiley、Elsevier、IEEE 等），无需额外付费

> 云端 SSE 模式仅支持搜索和文本提取，不支持 PDF 下载。如果你需要下载论文 PDF，请使用本地模式。

---

## 第一步：安装

确保你的电脑已安装 Python 3.10 或更高版本，然后执行：

```bash
pip install ai4scholar-mcp
```

如果之前安装过，请升级到最新版本：

```bash
pip install --upgrade ai4scholar-mcp
```

验证安装成功：

```bash
python -m ai4scholar_mcp.server --help
```

> 如果 `python` 命令不存在，请尝试 `python3`，后续配置中也需要相应替换。

---

## 第二步：获取 API Key

1. 访问 [ai4scholar.net](https://ai4scholar.net) 注册账号
2. 在个人中心获取 API Key

> API Key 用于搜索类工具（PubMed、Semantic Scholar、Google Scholar 等）。下载类工具不需要 API Key。

---

## 第三步：配置 AI 客户端

选择你使用的客户端，按照对应说明配置。

> 如果之前配置过 SSE 模式，请先删除旧的 `ai4scholar` 配置，再添加下面的 stdio 配置。

### Cursor

进入 **Settings → MCP** 添加服务器，或编辑项目中的 `.cursor/mcp.json`：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

将 `<your-api-key>` 替换为你的 API Key。

### Claude Desktop

编辑配置文件：

- Mac: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

### Claude Code

如果之前配置过 SSE 模式，先删除旧配置：

```bash
claude mcp remove ai4scholar --scope user
```

然后添加本地 stdio 服务（全局生效，所有项目通用）：

```bash
claude mcp add ai4scholar --scope user --transport stdio -e AI4SCHOLAR_API_KEY=<your-api-key> -- python -m ai4scholar_mcp.server
```

> `--scope user` 使配置全局生效。不加则仅对当前项目目录有效。
>
> 如果在多个项目目录下配置过旧的 SSE 模式，需要到对应目录执行 `claude mcp remove ai4scholar`，或者直接编辑 `~/.claude.json` 删除旧条目。

### VS Code (Copilot)

编辑项目中的 `.vscode/mcp.json`：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

### Gemini CLI

```bash
gemini mcp add ai4scholar -- python -m ai4scholar_mcp.server
```

运行 Gemini CLI 前设置环境变量：

```bash
export AI4SCHOLAR_API_KEY=<your-api-key>
```

### TRAE

进入 **MCP → 添加 → 手动添加**，粘贴以下配置：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

### Kimi Code

```bash
kimi mcp add --transport stdio ai4scholar -- python -m ai4scholar_mcp.server
```

或者编辑 `~/.kimi/mcp.json`：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

### OpenClaw

编辑 `~/.openclaw/config.json`，在 `mcpServers` 中添加：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "command": "python",
      "args": ["-m", "ai4scholar_mcp.server"],
      "env": {
        "AI4SCHOLAR_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

---

## 第四步：开始使用

配置完成后，重启你的 AI 客户端，然后尝试以下对话：

**搜索论文：**

- "帮我搜索关于大语言模型的最新论文"
- "在 PubMed 上搜索 CRISPR 基因编辑的综述文章"
- "用 Google Scholar 搜索 2024 年以来关于 AlphaFold 的论文"

**下载论文 PDF：**

- "下载 DOI 为 10.1038/s41586-024-07487-w 的论文 PDF"
- "下载 arXiv 论文 2301.00234"
- "下载 bioRxiv 论文 2024.01.15.575000"

**阅读论文全文：**

- "阅读 arXiv 论文 2301.00234 的全文并总结"
- "提取 DOI 为 10.1038/s41586-024-07487-w 的论文关键结论"

---

## 下载的 PDF 在哪里？

默认保存在当前工作目录下的 `./downloads/` 文件夹中。你也可以在对话中指定其他路径，例如：

- "下载 arXiv 论文 2301.00234，保存到 ~/Desktop"

---

## 常见问题

**Q：提示找不到 `python` 命令？**

请尝试使用 `python3`。将配置中的 `"command": "python"` 改为 `"command": "python3"`，命令行中使用 `python3 -m ai4scholar_mcp.server`。

**Q：能下载付费论文吗？**

可以，前提是你在校园网环境下。下载请求从你的本机 IP 发出，如果学校有订阅，就能自动利用机构权限。使用 `download_pdf_by_doi` 工具并提供论文的 DOI 即可。

**Q：支持哪些下载源？**

- Unpaywall 开放获取源（优先）
- 出版商网站直接下载（Springer、Nature、Wiley、Elsevier、IEEE、ACS、RSC、MDPI、Frontiers 等）
- 预印本服务器（arXiv、bioRxiv、medRxiv）

**Q：安装后工具没有出现？**

1. 确认安装了最新版本：`pip install --upgrade ai4scholar-mcp`
2. 确认配置文件中的 `command` 路径正确（`python` 或 `python3`）
3. 重启 AI 客户端

**Q：本地模式和云端 SSE 模式有什么区别？**

| 功能 | 本地模式（stdio） | 云端模式（SSE） |
|------|-------------------|-----------------|
| 搜索论文 | 支持 | 支持 |
| 阅读论文全文 | 支持 | 支持 |
| 下载 PDF 到本地 | 支持 | 不支持 |
| 校园网权限下载 | 支持 | 不支持 |
| 需要安装 Python | 是 | 否 |
| 需要 API Key | 是（搜索功能） | 是 |
