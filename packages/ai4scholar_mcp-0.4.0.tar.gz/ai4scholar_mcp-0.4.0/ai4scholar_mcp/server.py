# ai4scholar_mcp/server.py
import argparse
import os
from typing import List, Dict, Optional

import httpx
import uvicorn
from mcp.server.fastmcp import FastMCP
from mcp.server.sse import SseServerTransport
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
from .academic_platforms.arxiv import ArxivSearcher
from .academic_platforms.pubmed import PubMedSearcher
from .academic_platforms.biorxiv import BioRxivSearcher
from .academic_platforms.medrxiv import MedRxivSearcher
from .academic_platforms.google_scholar import GoogleScholarSearcher
# TODO: IACR 暂时注释，后续按需启用
# from .academic_platforms.iacr import IACRSearcher
from .academic_platforms.semantic import SemanticSearcher
# TODO: CrossRef 暂时注释，后续按需启用
# from .academic_platforms.crossref import CrossRefSearcher

# from .academic_platforms.hub import SciHubSearcher
from .academic_platforms.doi_downloader import DOIDownloader
from .academic_platforms.auto_cite import AutoCiter
from .academic_platforms.nano_draw import NanoDrawer
from .paper import Paper
from .context import current_api_key
import glob

# Initialize MCP server
mcp = FastMCP("ai4scholar_server")

# Instances of searchers
arxiv_searcher = ArxivSearcher()
pubmed_searcher = PubMedSearcher()
biorxiv_searcher = BioRxivSearcher()
medrxiv_searcher = MedRxivSearcher()
google_scholar_searcher = GoogleScholarSearcher()
# TODO: IACR 暂时注释，后续按需启用
# iacr_searcher = IACRSearcher()
semantic_searcher = SemanticSearcher()
# TODO: CrossRef 暂时注释，后续按需启用
# crossref_searcher = CrossRefSearcher()
# scihub_searcher = SciHubSearcher()
doi_downloader = DOIDownloader()
auto_citer = AutoCiter()
nano_drawer = NanoDrawer()


SSE_DOWNLOAD_HINT = (
    "该工具仅在本地模式（stdio）下可用。"
    "请通过 `pip install ai4scholar-mcp` 安装后在本地运行，"
    "即可下载 PDF 到您的电脑。在校园网环境下还可利用机构权限下载付费论文。"
)


def _is_sse_mode() -> bool:
    return current_api_key.get() is not None


def _cleanup_pdf(save_path: str, pattern: str) -> None:
    """Delete PDF files matching pattern in save_path (used after read in SSE mode)."""
    import os
    for f in glob.glob(os.path.join(save_path, pattern)):
        try:
            os.remove(f)
        except OSError:
            pass


# Asynchronous helper to adapt synchronous searchers
async def async_search(searcher, query: str, max_results: int, **kwargs) -> List[Dict]:
    async with httpx.AsyncClient() as client:
        # Assuming searchers use requests internally; we'll call synchronously for now
        if 'year' in kwargs:
            papers = searcher.search(query, year=kwargs['year'], max_results=max_results)
        else:
            papers = searcher.search(query, max_results=max_results)
        return [paper.to_dict() for paper in papers]


# Tool definitions
@mcp.tool()
async def search_arxiv(query: str, max_results: int = 10) -> List[Dict]:
    """在 arXiv 上搜索学术论文。

    Args:
        query: 搜索关键词（如 'machine learning'）。
        max_results: 最大返回论文数量（默认 10）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = await async_search(arxiv_searcher, query, max_results)
    return papers if papers else []


@mcp.tool()
async def search_pubmed(query: str, max_results: int = 10,
                        sort: str = "relevance",
                        min_date: Optional[str] = None,
                        max_date: Optional[str] = None) -> List[Dict]:
    """在 PubMed 上搜索生物医学论文，支持按日期排序和日期范围过滤。

    Args:
        query: 搜索关键词（如 'cancer treatment'）。
        max_results: 最大返回论文数量（默认 10）。
        sort: 排序方式 - 'relevance'（按相关性，默认）或 'date'（按日期，最新优先）。
        min_date: 最早日期过滤，格式 YYYY/MM/DD（如 '2024/01/01'）。
        max_date: 最晚日期过滤，格式 YYYY/MM/DD（如 '2025/12/31'）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = pubmed_searcher.search(
        query, max_results=max_results, sort=sort,
        min_date=min_date, max_date=max_date
    )
    return [p.to_dict() for p in papers] if papers else []


@mcp.tool()
async def get_pubmed_paper_detail(pmid: str) -> Dict:
    """通过 PMID 获取 PubMed 论文的详细信息。

    Args:
        pmid: PubMed ID（如 '39575807'）。
    Returns:
        论文元数据（字典格式），未找到则返回空字典。
    """
    async with httpx.AsyncClient() as client:
        paper = pubmed_searcher.get_paper_detail(pmid)
        return paper.to_dict() if paper else {}


@mcp.tool()
async def search_biorxiv(query: str, max_results: int = 10) -> List[Dict]:
    """在 bioRxiv 上搜索生物学预印本论文。

    Args:
        query: 搜索关键词（如 'gene editing'）。
        max_results: 最大返回论文数量（默认 10）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = await async_search(biorxiv_searcher, query, max_results)
    return papers if papers else []


@mcp.tool()
async def search_medrxiv(query: str, max_results: int = 10) -> List[Dict]:
    """在 medRxiv 上搜索医学与健康预印本论文。

    Args:
        query: 搜索关键词（如 'COVID-19 vaccine'）。
        max_results: 最大返回论文数量（默认 10）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = await async_search(medrxiv_searcher, query, max_results)
    return papers if papers else []


@mcp.tool()
async def search_google_scholar(query: str, max_results: int = 10,
                                year_from: Optional[int] = None,
                                year_to: Optional[int] = None) -> List[Dict]:
    """通过 AI4Scholar 代理在 Google Scholar 上搜索学术论文，支持年份过滤。

    Args:
        query: 搜索关键词（如 'deep learning'）。
        max_results: 最大返回论文数量（默认 10）。
        year_from: 起始年份过滤（如 2020），不填则不限。
        year_to: 结束年份过滤（如 2025），不填则不限。
    Returns:
        论文元数据列表（字典格式），包含标题、作者、摘要、引用数、PDF 链接等。
    """
    papers = google_scholar_searcher.search(
        query, max_results=max_results, year_from=year_from, year_to=year_to
    )
    return [p.to_dict() for p in papers] if papers else []


# TODO: IACR 暂时注释，后续按需启用
# @mcp.tool()
# async def search_iacr(
#     query: str, max_results: int = 10, fetch_details: bool = True
# ) -> List[Dict]:
#     """Search academic papers from IACR ePrint Archive.
#
#     Args:
#         query: Search query string (e.g., 'cryptography', 'secret sharing').
#         max_results: Maximum number of papers to return (default: 10).
#         fetch_details: Whether to fetch detailed information for each paper (default: True).
#     Returns:
#         List of paper metadata in dictionary format.
#     """
#     async with httpx.AsyncClient() as client:
#         papers = iacr_searcher.search(query, max_results, fetch_details)
#         return [paper.to_dict() for paper in papers] if papers else []


@mcp.tool()
async def download_arxiv(paper_id: str, save_path: str = "./downloads") -> str:
    """下载 arXiv 论文的 PDF 文件。

    Args:
        paper_id: arXiv 论文 ID（如 '2106.12345'）。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        下载的 PDF 文件路径。
    """
    if _is_sse_mode():
        return SSE_DOWNLOAD_HINT
    return arxiv_searcher.download_pdf(paper_id, save_path)


# PubMed 不支持 PDF 下载，注释掉
# @mcp.tool()
# async def download_pubmed(paper_id: str, save_path: str = "./downloads") -> str:
#     """Attempt to download PDF of a PubMed paper."""
#     try:
#         return pubmed_searcher.download_pdf(paper_id, save_path)
#     except NotImplementedError as e:
#         return str(e)


@mcp.tool()
async def download_biorxiv(paper_id: str, save_path: str = "./downloads") -> str:
    """下载 bioRxiv 论文的 PDF 文件。

    Args:
        paper_id: bioRxiv DOI。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        下载的 PDF 文件路径。
    """
    if _is_sse_mode():
        return SSE_DOWNLOAD_HINT
    return biorxiv_searcher.download_pdf(paper_id, save_path)


@mcp.tool()
async def download_medrxiv(paper_id: str, save_path: str = "./downloads") -> str:
    """下载 medRxiv 论文的 PDF 文件。

    Args:
        paper_id: medRxiv DOI。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        下载的 PDF 文件路径。
    """
    if _is_sse_mode():
        return SSE_DOWNLOAD_HINT
    return medrxiv_searcher.download_pdf(paper_id, save_path)


# TODO: IACR 暂时注释，后续按需启用
# @mcp.tool()
# async def download_iacr(paper_id: str, save_path: str = "./downloads") -> str:
#     """Download PDF of an IACR ePrint paper."""
#     return iacr_searcher.download_pdf(paper_id, save_path)


@mcp.tool()
async def download_pdf_by_doi(doi: str, save_path: str = "./downloads") -> str:
    """通过 DOI 下载论文 PDF。优先使用 Unpaywall 开放获取源，然后尝试出版商网站直接下载。
    在校园网环境下运行时，可利用机构 IP 权限下载付费论文。

    Args:
        doi: 论文的 DOI（如 '10.1038/s41586-024-07487-w'）。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        下载结果描述（成功时包含文件路径，失败时包含原因和建议）。
    """
    if _is_sse_mode():
        return SSE_DOWNLOAD_HINT
    success, message = doi_downloader.download(doi, save_path)
    return message


@mcp.tool()
async def read_arxiv_paper(paper_id: str, save_path: str = "./downloads") -> str:
    """下载并提取 arXiv 论文 PDF 的全文文本内容。

    Args:
        paper_id: arXiv 论文 ID（如 '2106.12345'）。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        提取的论文全文文本。
    """
    try:
        text = arxiv_searcher.read_paper(paper_id, save_path)
        if _is_sse_mode():
            _cleanup_pdf(save_path, f"{paper_id}*.pdf")
        return text
    except Exception as e:
        print(f"Error reading paper {paper_id}: {e}")
        return ""


# PubMed 不支持直接阅读全文，注释掉
# @mcp.tool()
# async def read_pubmed_paper(paper_id: str, save_path: str = "./downloads") -> str:
#     """Read and extract text content from a PubMed paper."""
#     return pubmed_searcher.read_paper(paper_id, save_path)


@mcp.tool()
async def read_biorxiv_paper(paper_id: str, save_path: str = "./downloads") -> str:
    """下载并提取 bioRxiv 论文 PDF 的全文文本内容。

    Args:
        paper_id: bioRxiv DOI。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        提取的论文全文文本。
    """
    try:
        text = biorxiv_searcher.read_paper(paper_id, save_path)
        if _is_sse_mode():
            _cleanup_pdf(save_path, f"{paper_id.replace('/', '_')}*.pdf")
        return text
    except Exception as e:
        print(f"Error reading paper {paper_id}: {e}")
        return ""


@mcp.tool()
async def read_medrxiv_paper(paper_id: str, save_path: str = "./downloads") -> str:
    """下载并提取 medRxiv 论文 PDF 的全文文本内容。

    Args:
        paper_id: medRxiv DOI。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        提取的论文全文文本。
    """
    try:
        text = medrxiv_searcher.read_paper(paper_id, save_path)
        if _is_sse_mode():
            _cleanup_pdf(save_path, f"{paper_id.replace('/', '_')}*.pdf")
        return text
    except Exception as e:
        print(f"Error reading paper {paper_id}: {e}")
        return ""


# TODO: IACR 暂时注释，后续按需启用
# @mcp.tool()
# async def read_iacr_paper(paper_id: str, save_path: str = "./downloads") -> str:
#     """Read and extract text content from an IACR ePrint paper PDF."""
#     try:
#         return iacr_searcher.read_paper(paper_id, save_path)
#     except Exception as e:
#         print(f"Error reading paper {paper_id}: {e}")
#         return ""


@mcp.tool()
async def search_semantic(query: str, year: Optional[str] = None, max_results: int = 10) -> List[Dict]:
    """在 Semantic Scholar 上搜索学术论文，支持年份过滤。

    Args:
        query: 搜索关键词（如 'machine learning'）。
        year: 可选年份过滤（如 '2019'、'2016-2020'、'2010-'、'-2015'）。
        max_results: 最大返回论文数量（默认 10）。
    Returns:
        论文元数据列表（字典格式）。
    """
    kwargs = {}
    if year is not None:
        kwargs['year'] = year
    papers = await async_search(semantic_searcher, query, max_results, **kwargs)
    return papers if papers else []


@mcp.tool()
async def download_semantic(paper_id: str, save_path: str = "./downloads") -> str:
    """下载 Semantic Scholar 论文的 PDF 文件。

    Args:
        paper_id: 论文标识符，支持以下格式：
            - Semantic Scholar ID（如 "649def34f8be52c8b66281af98ae884c09aef38b"）
            - DOI:<doi>（如 "DOI:10.18653/v1/N18-3011"）
            - ARXIV:<id>（如 "ARXIV:2106.15928"）
            - MAG:<id>（如 "MAG:112218234"）
            - ACL:<id>（如 "ACL:W12-3903"）
            - PMID:<id>（如 "PMID:19872477"）
            - PMCID:<id>（如 "PMCID:2323736"）
            - URL:<url>（如 "URL:https://arxiv.org/abs/2106.15928v1"）
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        下载的 PDF 文件路径。
    """ 
    if _is_sse_mode():
        return SSE_DOWNLOAD_HINT
    return semantic_searcher.download_pdf(paper_id, save_path)


@mcp.tool()
async def read_semantic_paper(paper_id: str, save_path: str = "./downloads") -> str:
    """下载并提取 Semantic Scholar 论文 PDF 的全文文本内容。

    Args:
        paper_id: 论文标识符，支持以下格式：
            - Semantic Scholar ID（如 "649def34f8be52c8b66281af98ae884c09aef38b"）
            - DOI:<doi>（如 "DOI:10.18653/v1/N18-3011"）
            - ARXIV:<id>（如 "ARXIV:2106.15928"）
            - MAG:<id>（如 "MAG:112218234"）
            - ACL:<id>（如 "ACL:W12-3903"）
            - PMID:<id>（如 "PMID:19872477"）
            - PMCID:<id>（如 "PMCID:2323736"）
            - URL:<url>（如 "URL:https://arxiv.org/abs/2106.15928v1"）
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        提取的论文全文文本。
    """
    try:
        text = semantic_searcher.read_paper(paper_id, save_path)
        if _is_sse_mode():
            _cleanup_pdf(save_path, f"semantic_{paper_id.replace('/', '_')}*.pdf")
        return text
    except Exception as e:
        print(f"Error reading paper {paper_id}: {e}")
        return ""


@mcp.tool()
async def get_semantic_citations(paper_id: str, limit: int = 100, offset: int = 0) -> List[Dict]:
    """获取引用了指定论文的所有论文（Semantic Scholar 引用图谱）。

    Args:
        paper_id: 论文标识符（SHA、DOI:<doi>、ARXIV:<id>、PMID:<id> 等）。
        limit: 最大返回引用数量（默认 100，最大 1000）。
        offset: 分页偏移量（默认 0）。
    Returns:
        引用列表，每条包含引用上下文、意图、是否有影响力及引用论文信息。
    """
    return semantic_searcher.get_paper_citations(paper_id, limit=limit, offset=offset)


@mcp.tool()
async def get_semantic_references(paper_id: str, limit: int = 100, offset: int = 0) -> List[Dict]:
    """获取指定论文引用的所有参考文献（Semantic Scholar）。

    Args:
        paper_id: 论文标识符（SHA、DOI:<doi>、ARXIV:<id>、PMID:<id> 等）。
        limit: 最大返回参考文献数量（默认 100，最大 1000）。
        offset: 分页偏移量（默认 0）。
    Returns:
        参考文献列表，每条包含引用上下文、意图、是否有影响力及被引论文信息。
    """
    return semantic_searcher.get_paper_references(paper_id, limit=limit, offset=offset)


@mcp.tool()
async def search_semantic_authors(query: str, limit: int = 10) -> List[Dict]:
    """按姓名搜索学者（Semantic Scholar）。

    Args:
        query: 学者姓名（如 'Yann LeCun'）。
        limit: 最大返回学者数量（默认 10）。
    Returns:
        学者列表，包含作者 ID、姓名、机构、论文数、引用数、h-index。
    """
    return semantic_searcher.search_authors(query, limit=limit)


@mcp.tool()
async def get_semantic_author_papers(author_id: str, limit: int = 100, offset: int = 0) -> List[Dict]:
    """获取指定学者的所有论文列表（Semantic Scholar）。

    Args:
        author_id: Semantic Scholar 作者 ID（如 '1741101'）。
        limit: 最大返回论文数量（默认 100，最大 1000）。
        offset: 分页偏移量（默认 0）。
    Returns:
        论文列表（字典格式）。
    """
    return semantic_searcher.get_author_papers(author_id, limit=limit, offset=offset)


@mcp.tool()
async def get_semantic_recommendations(positive_paper_ids: List[str],
                                       negative_paper_ids: List[str] = None,
                                       limit: int = 100) -> List[Dict]:
    """基于正面/负面论文示例获取论文推荐（Semantic Scholar）。

    Args:
        positive_paper_ids: 作为正面示例的论文 ID 列表。
        negative_paper_ids: 可选，作为负面示例的论文 ID 列表。
        limit: 最大推荐数量（默认 100，最大 500）。
    Returns:
        推荐论文列表（字典格式）。
    """
    return semantic_searcher.get_recommendations(
        positive_paper_ids, negative_paper_ids=negative_paper_ids, limit=limit
    )


@mcp.tool()
async def get_semantic_recommendations_for_paper(paper_id: str, limit: int = 100,
                                                  pool: str = "recent") -> List[Dict]:
    """基于单篇论文获取相似论文推荐（Semantic Scholar）。

    Args:
        paper_id: 论文标识符（SHA、DOI:<doi>、ARXIV:<id> 等）。
        limit: 最大推荐数量（默认 100，最大 500）。
        pool: 推荐池 - 'recent'（最近论文）或 'all-cs'（全部计算机科学论文），默认 'recent'。
    Returns:
        推荐论文列表（字典格式）。
    """
    return semantic_searcher.get_recommendations_for_paper(paper_id, limit=limit, pool=pool)


@mcp.tool()
async def search_semantic_snippets(query: str, limit: int = 10) -> List[Dict]:
    """在论文全文中搜索文本片段（Semantic Scholar）。

    片段为约 500 词的摘录，来源于论文标题、摘要和正文。

    Args:
        query: 搜索关键词。
        limit: 最大返回片段数量（默认 10）。
    Returns:
        片段匹配列表，每条包含片段文本、匹配分数及论文信息。
    """
    return semantic_searcher.search_snippets(query, limit=limit)


@mcp.tool()
async def get_pubmed_citations(pmid: str, limit: int = 20) -> List[Dict]:
    """获取引用了指定 PubMed 论文的所有论文。

    Args:
        pmid: PubMed ID（如 '30102808'）。
        limit: 最大返回引用论文数量（默认 20）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = pubmed_searcher.get_paper_citations(pmid, limit=limit)
    return [p.to_dict() for p in papers]


@mcp.tool()
async def get_pubmed_related(pmid: str, limit: int = 20) -> List[Dict]:
    """获取与指定 PubMed 论文相关的论文。

    Args:
        pmid: PubMed ID（如 '30102808'）。
        limit: 最大返回相关论文数量（默认 20）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = pubmed_searcher.get_related_papers(pmid, limit=limit)
    return [p.to_dict() for p in papers]


# TODO: CrossRef 暂时注释，后续按需启用
# @mcp.tool()
# async def search_crossref(query: str, max_results: int = 10, **kwargs) -> List[Dict]:
#     """Search academic papers from CrossRef database."""
#     papers = await async_search(crossref_searcher, query, max_results, **kwargs)
#     return papers if papers else []
#
#
# @mcp.tool()
# async def get_crossref_paper_by_doi(doi: str) -> Dict:
#     """Get a specific paper from CrossRef by its DOI."""
#     async with httpx.AsyncClient() as client:
#         paper = crossref_searcher.get_paper_by_doi(doi)
#         return paper.to_dict() if paper else {}
#
#
# @mcp.tool()
# async def download_crossref(paper_id: str, save_path: str = "./downloads") -> str:
#     """Attempt to download PDF of a CrossRef paper."""
#     try:
#         return crossref_searcher.download_pdf(paper_id, save_path)
#     except NotImplementedError as e:
#         return str(e)
#
#
# @mcp.tool()
# async def read_crossref_paper(paper_id: str, save_path: str = "./downloads") -> str:
#     """Attempt to read and extract text content from a CrossRef paper."""
#     return crossref_searcher.read_paper(paper_id, save_path)


# ---------------------------------------------------------------------------
# Auto-Cite tool
# ---------------------------------------------------------------------------

@mcp.tool()
async def auto_cite(
    text: str,
    mode: str = "auto",
    min_citations: int = 10,
    citation_style: str = "ieee",
    max_references: Optional[int] = None,
    preferred_venues: Optional[List[str]] = None,
    field: Optional[str] = None,
    year_preference: Optional[int] = None,
    exclude_preprints: bool = False,
    exclude_conferences: bool = False,
) -> Dict:
    """自动为学术文本标注参考文献。AI 识别需要引用的位置，搜索匹配文献，输出带引用标记的文本和格式化参考文献列表。

    Args:
        text: 学术文本（100–10,000 字符）。
        mode: 'auto'（自动识别引用位置）或 'manual'（在文本中用 [CITE] 或 [CITE:hint] 标记位置）。
        min_citations: 自动模式下最少引用数量（默认 10）。
        citation_style: 引用格式，支持 ieee/apa/nature/vancouver/mla/chicago/harvard/acs/ama/acm/gbt7714 等。
        max_references: 最多返回的参考文献数量。
        preferred_venues: 优先匹配的期刊列表（如 ['Nature', 'Science', 'CVPR']）。
        field: 学科领域（如 'computer science', 'biology'）。
        year_preference: 优先引用该年份附近的文献。
        exclude_preprints: 是否排除预印本（arXiv 等）。
        exclude_conferences: 是否排除会议论文。
    Returns:
        包含 annotatedText（带引用标记的文本）和 references（参考文献列表）的字典。
    """
    return auto_citer.cite(
        text=text,
        mode=mode,
        min_citations=min_citations,
        citation_style=citation_style,
        max_references=max_references,
        preferred_venues=preferred_venues,
        field=field,
        year_preference=year_preference,
        exclude_preprints=exclude_preprints,
        exclude_conferences=exclude_conferences,
    )


# ---------------------------------------------------------------------------
# Nano Draw tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def nano_generate(
    prompt: str,
    smart: bool = True,
    model: str = "flash",
    aspect_ratio: str = "1:1",
    image_size: str = "2K",
    lang: Optional[str] = None,
) -> Dict:
    """AI 生成科研图片。支持架构图、流程图、示意图、数据可视化等科研绘图。

    Args:
        prompt: 图片描述（如 'a diagram showing the architecture of a transformer model'）。
        smart: 是否启用智能模式（AI 自动优化 prompt，默认 True）。
        model: 模型选择 - 'flash'（快速）、'flash31'（平衡）、'pro'（最高质量）。
        aspect_ratio: 宽高比（如 '1:1', '16:9', '4:3', '3:2'）。
        image_size: 分辨率 - '512px', '1K', '2K', '4K'。
        lang: 语言偏好 - 'en' 或 'zh'。
    Returns:
        包含 imageUrl（图片链接）、optimizedPrompt（优化后提示词，smart 模式）、creditCost（消耗积分）。
    """
    action = "smart" if smart else "generate"
    return nano_drawer.draw(
        action=action, prompt=prompt, model=model,
        aspect_ratio=aspect_ratio, image_size=image_size, lang=lang,
    )


@mcp.tool()
async def nano_edit(
    prompt: str,
    images: List[str],
    action: str = "edit",
    model: str = "flash",
    aspect_ratio: str = "1:1",
    image_size: str = "2K",
    style_preset: Optional[str] = None,
) -> Dict:
    """编辑、风格迁移或合成科研图片。

    Args:
        prompt: 编辑指令（如 'add axis labels and a legend to this chart'）。
        images: 参考图片 URL 列表。
        action: 操作类型 - 'edit'（编辑修改）、'style'（风格迁移）、'compose'（多图合成）。
        model: 模型选择 - 'flash', 'flash31', 'pro'。
        aspect_ratio: 宽高比。
        image_size: 分辨率。
        style_preset: 风格预设（style 模式可用）- vangogh/monet/davinci/ukiyoe/pixel/watercolor/cyberpunk/ghibli。
    Returns:
        包含 imageUrl（结果图片链接）、creditCost（消耗积分）。
    """
    if action not in ("edit", "style", "compose"):
        return {"error": f"nano_edit 仅支持 edit/style/compose，不支持 '{action}'。"}
    return nano_drawer.draw(
        action=action, prompt=prompt, images=images, model=model,
        aspect_ratio=aspect_ratio, image_size=image_size, style_preset=style_preset,
    )


# ---------------------------------------------------------------------------
# SSE transport: Auth middleware + Starlette app factory
# ---------------------------------------------------------------------------

class AuthMiddleware(BaseHTTPMiddleware):
    """Bearer token authentication middleware.

    Extracts the Bearer token from the Authorization header and stores it
    in the per-request ContextVar so that downstream searchers can forward
    it to ai4scholar.net on behalf of each individual user.

    The /health endpoint is exempt from authentication.
    Requests without a Bearer token are rejected with 401.
    """

    async def dispatch(self, request: Request, call_next):
        if request.url.path == "/health":
            return await call_next(request)

        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return JSONResponse(
                {"error": "Missing or invalid Authorization header"},
                status_code=401,
            )

        token = auth_header[len("Bearer "):]
        if not token:
            return JSONResponse(
                {"error": "Empty API key"},
                status_code=401,
            )

        # Store the user's token in the request context so that
        # handle_sse can pick it up and set the ContextVar.
        request.state.api_key = token

        return await call_next(request)


def create_starlette_app(mcp_server) -> Starlette:
    """Create a Starlette application that serves the MCP server over SSE."""
    sse = SseServerTransport("/messages/")

    async def handle_sse(request: Request):
        # Store the user's API key (set by AuthMiddleware) in the
        # ContextVar so all tool calls within this SSE session use it.
        api_key = getattr(request.state, "api_key", None)
        if api_key:
            current_api_key.set(api_key)

        async with sse.connect_sse(
            request.scope, request.receive, request._send
        ) as streams:
            await mcp_server.run(
                streams[0], streams[1], mcp_server.create_initialization_options()
            )

    async def handle_messages(request: Request):
        await sse.handle_post_message(request.scope, request.receive, request._send)

    async def handle_health(request: Request):
        return JSONResponse({"status": "ok"})

    app = Starlette(
        routes=[
            Route("/sse", endpoint=handle_sse),
            Route("/messages/", endpoint=handle_messages, methods=["POST"]),
            Route("/health", endpoint=handle_health),
        ],
        middleware=[Middleware(AuthMiddleware)],
    )
    return app


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AI4Scholar MCP Server")
    parser.add_argument("--transport", choices=["stdio", "sse"], default="stdio",
                        help="Transport mode (default: stdio)")
    parser.add_argument("--host", default="0.0.0.0",
                        help="Host to bind SSE server (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000,
                        help="Port for SSE server (default: 8000)")
    args = parser.parse_args()

    if args.transport == "sse":
        app = create_starlette_app(mcp._mcp_server)
        uvicorn.run(app, host=args.host, port=args.port)
    else:
        mcp.run(transport="stdio")
