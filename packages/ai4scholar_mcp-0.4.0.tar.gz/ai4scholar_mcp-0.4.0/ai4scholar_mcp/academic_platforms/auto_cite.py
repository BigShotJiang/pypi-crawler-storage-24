import json
import os
import logging
from typing import Optional, Dict, List

import requests

from ..context import current_api_key

logger = logging.getLogger(__name__)

BASE_URL = "https://ai4scholar.net"


class AutoCiter:
    """Auto-Cite API client — automatically annotate academic text with citations."""

    SUPPORTED_STYLES = [
        "ieee", "apa", "apa6", "nature", "vancouver", "mla", "chicago",
        "harvard", "acs", "ama", "acm", "turabian", "cse", "asce", "gbt7714",
    ]

    def __init__(self):
        self.session = requests.Session()

    @staticmethod
    def _get_api_key() -> Optional[str]:
        api_key = current_api_key.get()
        if api_key:
            return api_key
        api_key = os.getenv("AI4SCHOLAR_API_KEY")
        if not api_key or api_key.strip() == "":
            return None
        return api_key.strip()

    def _get_headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        api_key = self._get_api_key()
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        return headers

    def cite(
        self,
        text: str,
        mode: str = "auto",
        min_citations: int = 10,
        citation_style: str = "ieee",
        max_references: Optional[int] = None,
        preferred_venues: Optional[List[str]] = None,
        field: Optional[str] = None,
        year_preference: Optional[int] = None,
        exclude_preprints: bool = False,
        exclude_conferences: bool = False,
    ) -> Dict:
        """Call the Auto-Cite API and return the result.

        Returns a dict with keys: annotatedText, references, candidates (on success),
        or a dict with key: error (on failure).
        """
        api_key = self._get_api_key()
        if not api_key:
            return {"error": "未设置 AI4SCHOLAR_API_KEY，无法调用 Auto-Cite API。"}

        payload: Dict = {
            "text": text,
            "mode": mode,
            "minCitations": min_citations,
            "citationStyle": citation_style,
        }
        if max_references is not None:
            payload["maxReferences"] = max_references
        if preferred_venues:
            payload["preferredVenues"] = preferred_venues
        if field:
            payload["field"] = field
        if year_preference is not None:
            payload["yearPreference"] = year_preference
        if exclude_preprints:
            payload["excludePreprints"] = True
        if exclude_conferences:
            payload["excludeConferences"] = True

        try:
            resp = self.session.post(
                f"{BASE_URL}/api/proxy/auto-cite",
                headers=self._get_headers(),
                json=payload,
                stream=True,
                timeout=300,
            )
            resp.raise_for_status()
        except requests.RequestException as e:
            logger.error(f"Auto-Cite API request failed: {e}")
            return {"error": f"Auto-Cite API 请求失败: {e}"}

        result = None
        event_type = ""

        for line in resp.iter_lines(decode_unicode=True):
            if not line:
                continue
            if line.startswith("event: "):
                event_type = line[7:]
                continue
            if line.startswith("data: "):
                try:
                    data = json.loads(line[6:])
                except json.JSONDecodeError:
                    continue

                if event_type == "result":
                    result = data
                elif event_type == "error":
                    return {"error": data.get("message", "Auto-Cite 处理失败")}

        if result is None:
            return {"error": "Auto-Cite API 未返回结果"}

        return result
