import os
import logging
from typing import Optional, Dict, List

import requests

from ..context import current_api_key

logger = logging.getLogger(__name__)

BASE_URL = "https://ai4scholar.net"

VALID_ACTIONS = {"smart", "generate", "edit", "style", "compose", "svg", "iterate", "critic"}
VALID_MODELS = {"flash", "flash31", "pro"}
VALID_IMAGE_SIZES = {"512px", "1K", "2K", "4K"}
VALID_STYLE_PRESETS = {
    "vangogh", "monet", "davinci", "ukiyoe",
    "pixel", "watercolor", "cyberpunk", "ghibli",
}


class NanoDrawer:
    """Nano Banana API client — AI-powered scientific figure generation."""

    def __init__(self):
        self.session = requests.Session()

    @staticmethod
    def _get_api_key() -> Optional[str]:
        api_key = current_api_key.get()
        if api_key:
            return api_key
        api_key = os.getenv("AI4SCHOLAR_API_KEY")
        if not api_key or api_key.strip() == "":
            return None
        return api_key.strip()

    def _get_headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        api_key = self._get_api_key()
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        return headers

    def draw(
        self,
        action: str,
        prompt: Optional[str] = None,
        model: str = "flash",
        aspect_ratio: str = "1:1",
        image_size: str = "2K",
        style_preset: Optional[str] = None,
        images: Optional[List[str]] = None,
        lang: Optional[str] = None,
    ) -> Dict:
        """Call the Nano Draw API.

        Returns a dict with imageUrl, svgCode, svgUrl, critique, creditCost, etc.
        """
        api_key = self._get_api_key()
        if not api_key:
            return {"error": "未设置 AI4SCHOLAR_API_KEY，无法调用 Nano Draw API。"}

        if action not in VALID_ACTIONS:
            return {"error": f"不支持的 action: {action}，可选值: {', '.join(sorted(VALID_ACTIONS))}"}

        payload: Dict = {"action": action}

        if prompt:
            payload["prompt"] = prompt
        if action != "critic" and not prompt:
            return {"error": f"action '{action}' 需要提供 prompt 参数。"}

        if action not in ("svg", "critic"):
            payload["model"] = model
            payload["aspectRatio"] = aspect_ratio
            payload["imageSize"] = image_size

        if style_preset:
            payload["stylePreset"] = style_preset
        if images:
            payload["images"] = images
        if lang:
            payload["lang"] = lang

        try:
            resp = self.session.post(
                f"{BASE_URL}/api/proxy/nano/generate",
                headers=self._get_headers(),
                json=payload,
                timeout=300,
            )
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as e:
            logger.error(f"Nano Draw API request failed: {e}")
            return {"error": f"Nano Draw API 请求失败: {e}"}
