"""Download PDFs by DOI, leveraging institutional (campus network) access.

Resolves a DOI to the publisher's page and attempts to find and download
the PDF. When running on a campus network, HTTP requests go through the
institution's IP, which typically has access to paywalled content.

Download strategies (tried in order):
1. Unpaywall API – free, legal open-access PDF links.
2. Publisher page scraping – parse common publisher PDF patterns.
3. Sci-Hub fallback – if the above fail (optional).
"""

import hashlib
import logging
import os
import re
from typing import Optional, Tuple
from urllib.parse import urljoin, urlparse

import requests

logger = logging.getLogger(__name__)

PUBLISHER_PDF_PATTERNS = {
    "sciencedirect.com": [
        lambda url: re.sub(r"/article/pii/", "/article/pii/", url) + "?fmt=pdf",
    ],
    "springer.com": [
        lambda url: url.replace("/article/", "/content/pdf/") + ".pdf",
    ],
    "link.springer.com": [
        lambda url: url.replace("/article/", "/content/pdf/") + ".pdf",
    ],
    "nature.com": [
        lambda url: url + ".pdf" if not url.endswith(".pdf") else url,
    ],
    "wiley.com": [
        lambda url: re.sub(r"/doi/(abs|full)/", "/doi/pdfdirect/", url)
        + "?download=true",
    ],
    "onlinelibrary.wiley.com": [
        lambda url: re.sub(r"/doi/(abs|full)/", "/doi/pdfdirect/", url)
        + "?download=true",
    ],
    "tandfonline.com": [
        lambda url: re.sub(r"/doi/(abs|full)/", "/doi/pdf/", url),
    ],
    "ieeexplore.ieee.org": [
        lambda url: re.sub(
            r"/document/(\d+)",
            r"/stampPDF/getPDF.jsp?arnumber=\1",
            url,
        ),
    ],
    "pnas.org": [
        lambda url: url.replace("/doi/full/", "/doi/pdf/"),
    ],
    "acs.org": [
        lambda url: url.replace("/doi/abs/", "/doi/pdf/").replace(
            "/doi/full/", "/doi/pdf/"
        ),
    ],
    "rsc.org": [
        lambda url: url.replace("/articlelanding/", "/articlepdf/"),
    ],
    "mdpi.com": [
        lambda url: url.rstrip("/") + "/pdf",
    ],
    "frontiersin.org": [
        lambda url: url.rstrip("/") + "/pdf" if "/full" in url else url + "/pdf",
    ],
}


class DOIDownloader:
    """Download academic paper PDFs by DOI."""

    def __init__(self, output_dir: str = "./downloads", email: str = ""):
        self.output_dir = output_dir
        self.email = email or "ai4scholar@ai4scholar.net"
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                ),
                "Accept": (
                    "text/html,application/xhtml+xml,application/xml;"
                    "q=0.9,application/pdf,*/*;q=0.8"
                ),
                "Accept-Language": "en-US,en;q=0.9",
            }
        )
        self.timeout = 30

    def download(
        self, doi: str, save_path: Optional[str] = None
    ) -> Tuple[bool, str]:
        """Download a PDF by DOI.

        Args:
            doi: The DOI string (e.g. '10.1038/s41586-024-07487-w').
            save_path: Directory to save the PDF.  Defaults to self.output_dir.

        Returns:
            (success, message) where message is the file path on success
            or an error/status description on failure.
        """
        save_path = save_path or self.output_dir
        os.makedirs(save_path, exist_ok=True)

        doi = doi.strip()
        if doi.startswith("https://doi.org/"):
            doi = doi[len("https://doi.org/"):]
        elif doi.startswith("http://doi.org/"):
            doi = doi[len("http://doi.org/"):]

        pdf_url, source = self._find_pdf_url(doi)
        if not pdf_url:
            return False, (
                f"无法找到 DOI {doi} 对应的 PDF 下载链接。"
                "可能该论文需要付费订阅，请在校园网环境下重试，"
                "或尝试使用 Sci-Hub。"
            )

        logger.info(f"Found PDF URL via {source}: {pdf_url}")
        return self._download_pdf(pdf_url, doi, save_path, source)

    def _find_pdf_url(self, doi: str) -> Tuple[Optional[str], str]:
        """Try multiple strategies to find a PDF URL for the given DOI."""

        # Strategy 0: Known preprint DOI patterns (arXiv, bioRxiv, medRxiv)
        pdf_url = self._try_preprint_doi(doi)
        if pdf_url:
            return pdf_url, "Preprint Repository"

        # Strategy 1: Unpaywall (free open-access)
        pdf_url = self._try_unpaywall(doi)
        if pdf_url:
            return pdf_url, "Unpaywall (Open Access)"

        # Strategy 2: Resolve DOI and try publisher-specific patterns
        landing_url = self._resolve_doi(doi)
        if landing_url:
            pdf_url = self._try_publisher_patterns(landing_url)
            if pdf_url:
                return pdf_url, "Publisher Pattern"

            # Strategy 3: Scrape landing page for PDF links
            pdf_url = self._scrape_pdf_link(landing_url)
            if pdf_url:
                return pdf_url, "Page Scraping"

        return None, ""

    def _try_preprint_doi(self, doi: str) -> Optional[str]:
        """Handle known preprint repository DOIs directly."""
        # arXiv: 10.48550/arXiv.XXXX.XXXXX
        match = re.match(r"10\.48550/arXiv\.(.+)", doi, re.IGNORECASE)
        if match:
            arxiv_id = match.group(1)
            return f"https://arxiv.org/pdf/{arxiv_id}.pdf"

        # bioRxiv: 10.1101/YYYY.MM.DD.XXXXXX
        if doi.startswith("10.1101/") and re.match(r"10\.1101/\d{4}\.\d{2}\.\d{2}", doi):
            return f"https://www.biorxiv.org/content/{doi}v1.full.pdf"

        return None

    def _try_unpaywall(self, doi: str) -> Optional[str]:
        """Query the Unpaywall API for an open-access PDF."""
        try:
            url = f"https://api.unpaywall.org/v2/{doi}?email={self.email}"
            resp = self.session.get(url, timeout=10)
            if resp.status_code != 200:
                return None
            data = resp.json()

            best = data.get("best_oa_location")
            if best:
                pdf = best.get("url_for_pdf") or best.get("url")
                if pdf:
                    return pdf

            for loc in data.get("oa_locations", []):
                pdf = loc.get("url_for_pdf")
                if pdf:
                    return pdf
        except Exception as e:
            logger.debug(f"Unpaywall lookup failed: {e}")
        return None

    def _resolve_doi(self, doi: str) -> Optional[str]:
        """Resolve a DOI to its landing page URL."""
        try:
            resp = self.session.get(
                f"https://doi.org/{doi}",
                allow_redirects=True,
                timeout=self.timeout,
            )
            if resp.status_code == 200:
                return resp.url
        except Exception as e:
            logger.debug(f"DOI resolution failed: {e}")
        return None

    def _try_publisher_patterns(self, landing_url: str) -> Optional[str]:
        """Apply publisher-specific URL transformations to get a PDF link."""
        parsed = urlparse(landing_url)
        domain = parsed.netloc.lower().lstrip("www.")

        for pattern_domain, transformers in PUBLISHER_PDF_PATTERNS.items():
            if pattern_domain in domain:
                for transform in transformers:
                    try:
                        candidate = transform(landing_url)
                        if self._is_pdf_url(candidate):
                            return candidate
                    except Exception:
                        continue
        return None

    def _scrape_pdf_link(self, landing_url: str) -> Optional[str]:
        """Scrape the landing page HTML for PDF download links."""
        try:
            resp = self.session.get(landing_url, timeout=self.timeout)
            if resp.status_code != 200:
                return None

            from bs4 import BeautifulSoup

            soup = BeautifulSoup(resp.text, "html.parser")

            # Look for <meta> citation_pdf_url (used by many publishers)
            meta = soup.find("meta", attrs={"name": "citation_pdf_url"})
            if meta:
                pdf_url = meta.get("content")
                if pdf_url:
                    return urljoin(landing_url, pdf_url)

            # Look for links containing 'pdf' in href
            for a_tag in soup.find_all("a", href=True):
                href = a_tag["href"]
                text = a_tag.get_text(strip=True).lower()
                if "pdf" in href.lower() or "pdf" in text:
                    full = urljoin(landing_url, href)
                    if self._is_pdf_url(full):
                        return full

        except Exception as e:
            logger.debug(f"Page scraping failed: {e}")
        return None

    def _is_pdf_url(self, url: str) -> bool:
        """Quick HEAD check to see if a URL returns a PDF."""
        try:
            resp = self.session.head(
                url, allow_redirects=True, timeout=10
            )
            ct = resp.headers.get("Content-Type", "")
            return "pdf" in ct.lower() or resp.url.endswith(".pdf")
        except Exception:
            return False

    def _download_pdf(
        self, pdf_url: str, doi: str, save_path: str, source: str
    ) -> Tuple[bool, str]:
        """Download the PDF from the resolved URL."""
        try:
            resp = self.session.get(
                pdf_url, timeout=self.timeout, stream=True
            )
            if resp.status_code != 200:
                return False, f"下载失败，HTTP 状态码 {resp.status_code}（来源: {source}）"

            ct = resp.headers.get("Content-Type", "")
            if "pdf" not in ct.lower() and not pdf_url.endswith(".pdf"):
                return False, (
                    f"返回内容不是 PDF（Content-Type: {ct}）。"
                    "可能需要机构权限，请在校园网环境下重试。"
                )

            clean_doi = re.sub(r"[^\w\-.]", "_", doi)
            short_hash = hashlib.md5(doi.encode()).hexdigest()[:6]
            filename = f"{clean_doi}_{short_hash}.pdf"
            filepath = os.path.join(save_path, filename)

            with open(filepath, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)

            size_kb = os.path.getsize(filepath) / 1024
            return True, (
                f"PDF 已下载到 {filepath}（{size_kb:.1f} KB，来源: {source}）"
            )

        except Exception as e:
            return False, f"下载过程中出错: {e}"
