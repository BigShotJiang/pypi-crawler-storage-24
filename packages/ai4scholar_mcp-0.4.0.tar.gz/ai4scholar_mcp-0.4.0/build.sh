cd /home/zhongru/projects/ai4s-mcp
docker compose build
docker compose up -d
