# AI4Scholar MCP

[English](README.md) | **中文**

学术论文搜索、下载与分析的 MCP 服务器。将 LLM 客户端（Claude Desktop 等）连接到 arXiv、PubMed、Semantic Scholar、bioRxiv、medRxiv，支持引用追踪、学者查找和论文推荐。

![License](https://img.shields.io/badge/license-MIT-blue.svg) ![Python](https://img.shields.io/badge/python-3.10+-blue.svg)

---

## 工具列表 (28)

> 详细参数和使用示例请查看 [工具参考文档](docs/TOOLS.md)。

| 平台 | 工具 | 功能 |
|------|------|------|
| **arXiv** | `search_arxiv`, `download_arxiv`, `read_arxiv_paper` | 搜索、下载 PDF、提取全文 |
| **PubMed** | `search_pubmed`, `get_pubmed_paper_detail`, `get_pubmed_citations`, `get_pubmed_related` | 搜索、论文详情、引用、相关论文 |
| **Semantic Scholar** | `search_semantic`, `download_semantic`, `read_semantic_paper`, `get_semantic_citations`, `get_semantic_references`, `search_semantic_authors`, `get_semantic_author_papers`, `get_semantic_recommendations`, `get_semantic_recommendations_for_paper`, `search_semantic_snippets` | 搜索、下载 PDF、提取全文、引用图谱、学者搜索、论文推荐、全文片段搜索 |
| **Google Scholar** | `search_google_scholar` | 搜索、支持年份过滤 |
| **bioRxiv** | `search_biorxiv`, `download_biorxiv`, `read_biorxiv_paper` | 搜索、下载 PDF、提取全文 |
| **medRxiv** | `search_medrxiv`, `download_medrxiv`, `read_medrxiv_paper` | 搜索、下载 PDF、提取全文 |
| **通用** | `download_pdf_by_doi` | 通过 DOI 下载论文 PDF（支持校园网机构权限） |
| **Auto-Cite** | `auto_cite` | 自动为学术文本标注参考文献引用 |
| **Nano Draw** | `nano_generate`, `nano_edit` | AI 科研画图：生成、编辑、风格迁移、多图合成 |

> **注意：** PDF 下载工具（`download_*`、`download_pdf_by_doi`）仅在**本地模式（stdio）**下可用。远程 SSE 模式仅支持搜索和文本提取。配置方法请参考 [本地模式使用指南](docs/LOCAL_MODE.md)。

---

## 安装

### 快速开始

```bash
uv add ai4scholar-mcp
```

配置 Claude Desktop（Mac: `~/Library/Application Support/Claude/claude_desktop_config.json`）：

```json
{
  "mcpServers": {
    "ai4scholar_server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/path/to/your/ai4s-mcp",
        "-m",
        "ai4scholar_mcp.server"
      ],
      "env": {
        "AI4SCHOLAR_API_KEY": "your-api-key"
      }
    }
  }
}
```

> 将 `/path/to/your/ai4s-mcp` 替换为实际路径。PubMed 和 Semantic Scholar 工具需要 `AI4SCHOLAR_API_KEY`。

### 本地使用（stdio）

通过 pip 安装后在本机运行，支持 PDF 下载，校园网环境下可利用机构权限下载付费论文。

```bash
pip install ai4scholar-mcp
```

> 详细配置指南（Cursor、Claude Desktop、Claude Code、VS Code、Gemini CLI、TRAE 等）请查看 [本地模式使用指南](docs/LOCAL_MODE.md)。

### 远程使用（SSE）

无需安装任何依赖，使用你的 [ai4scholar.net](https://ai4scholar.net) API Key 直接连接云端 SSE 服务。

#### Cursor

进入 **Settings → MCP** 添加服务器，或编辑项目中的 `.cursor/mcp.json`：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "url": "https://mcp.ai4scholar.net/sse",
      "headers": {
        "Authorization": "Bearer <your-ai4scholar-api-key>"
      }
    }
  }
}
```

#### TRAE

进入 **MCP → 添加 → 手动添加**，粘贴以下 JSON 配置：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "type": "sse",
      "url": "https://mcp.ai4scholar.net/sse",
      "headers": {
        "Authorization": "Bearer <your-ai4scholar-api-key>"
      }
    }
  }
}
```

#### Claude Desktop

编辑配置文件（Mac: `~/Library/Application Support/Claude/claude_desktop_config.json`，Windows: `%APPDATA%\Claude\claude_desktop_config.json`）：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "url": "https://mcp.ai4scholar.net/sse",
      "headers": {
        "Authorization": "Bearer <your-ai4scholar-api-key>"
      }
    }
  }
}
```

#### Claude Code

推荐使用 stdio 模式（需先安装）：

```bash
pip install ai4scholar-mcp
claude mcp add ai4scholar --scope user --transport stdio -e AI4SCHOLAR_API_KEY=<your-ai4scholar-api-key> -- python -m ai4scholar_mcp.server
```

> **注意：** `--scope user` 使配置全局生效。Claude Code 的 SSE 模式存在[已知问题](https://github.com/anthropics/claude-code/issues/7290)，推荐使用上述 stdio 方式。

#### Cherry Studio

1. 进入 **设置 → MCP 服务器 → 添加服务器**
2. 类型选择：**服务器发送事件 (SSE)**
3. URL：`https://mcp.ai4scholar.net/sse`
4. 请求头：`Authorization=Bearer <your-ai4scholar-api-key>`
5. 保存并启用

#### Chatbox

编辑配置文件（Linux/Mac: `~/.config/chatbox/config.json`，Windows: `%APPDATA%\chatbox\config.json`），在 `mcpServers` 中添加：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "url": "https://mcp.ai4scholar.net/sse",
      "headers": {
        "Authorization": "Bearer <your-ai4scholar-api-key>"
      }
    }
  }
}
```

#### Dify

1. 进入 **工具 → MCP → 添加 MCP 服务器 (HTTP)**
2. 填写：
   - **Server URL**：`https://mcp.ai4scholar.net/sse`
   - **名称**：`ai4scholar`
   - **Headers**：`Authorization: Bearer <your-ai4scholar-api-key>`
3. 保存后，工具将自动出现在你的 Workflow 和 Agent 中。

#### Gemini CLI

方式一 — 在终端中执行：

```bash
gemini mcp add --transport sse ai4scholar https://mcp.ai4scholar.net/sse --header "Authorization: Bearer <your-ai4scholar-api-key>"
```

方式二 — 编辑 `~/.gemini/settings.json`（或项目级 `.gemini/settings.json`）：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "url": "https://mcp.ai4scholar.net/sse",
      "headers": {
        "Authorization": "Bearer <your-ai4scholar-api-key>"
      }
    }
  }
}
```

#### Kimi Code

方式一 — 在终端中执行：

```bash
kimi mcp add --transport http ai4scholar https://mcp.ai4scholar.net/sse \
  --header "Authorization: Bearer <your-ai4scholar-api-key>"
```

方式二 — 编辑 `~/.kimi/mcp.json`：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "url": "https://mcp.ai4scholar.net/sse",
      "headers": {
        "Authorization": "Bearer <your-ai4scholar-api-key>"
      }
    }
  }
}
```

可通过 `kimi mcp test ai4scholar` 验证连接。

#### OpenCode

编辑项目中的 `opencode.json`（或全局配置 `~/.config/opencode/opencode.json`），在 `mcp` 中添加：

```json
{
  "mcp": {
    "ai4scholar": {
      "type": "remote",
      "url": "https://mcp.ai4scholar.net/sse",
      "enabled": true,
      "oauth": false,
      "headers": {
        "Authorization": "Bearer <your-ai4scholar-api-key>"
      }
    }
  }
}
```

> 注意：`"oauth": false` 用于禁用自动 OAuth 检测，直接使用 Headers 中的 Bearer Token 认证。

通过 `opencode mcp debug ai4scholar` 验证连接。

#### CC-Switch

[CC-Switch](https://github.com/farion1231/cc-switch) 是 Claude Code / Codex / Gemini CLI 的桌面配置管理工具，内置 MCP 管理面板：

1. 点击右上角 **MCP** 按钮
2. 添加服务器，传输类型选择 **SSE**
3. 填写：
   - **URL**：`https://mcp.ai4scholar.net/sse`
   - **Headers**：`Authorization: Bearer <your-ai4scholar-api-key>`
4. 选择要同步的客户端（Claude Code / Gemini CLI 等），启用即可

> 将 `<your-ai4scholar-api-key>` 替换为你在 [ai4scholar.net](https://ai4scholar.net) 注册获取的 API Key。

#### OpenClaw

编辑 `~/.openclaw/config.json`，在 `mcpServers` 中添加：

```json
{
  "mcpServers": {
    "ai4scholar": {
      "url": "https://mcp.ai4scholar.net/sse",
      "headers": {
        "Authorization": "Bearer <your-ai4scholar-api-key>"
      }
    }
  }
}
```

### 开发环境

```bash
git clone https://github.com/literaf/ai4s-mcp.git
cd ai4s-mcp
uv venv && source .venv/bin/activate
uv add -e .
```

---

## 贡献

1. Fork 本仓库
2. 创建功能分支
3. 在 `academic_platforms/` 中添加新平台，在 `tests/` 中更新测试
4. 提交 Pull Request

---

## 许可证

MIT 许可证。详见 [LICENSE](LICENSE)。
