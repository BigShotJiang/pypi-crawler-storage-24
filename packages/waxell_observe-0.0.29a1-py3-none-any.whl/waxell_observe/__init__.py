"""waxell-observe: Lightweight observability & governance for any AI agent framework.

Quick start — one line, everything auto-captured::

    import waxell_observe as waxell
    waxell.init()  # reads WAXELL_API_KEY & WAXELL_API_URL from env

    # Every OpenAI / Anthropic call is now traced automatically.
    response = openai.chat.completions.create(model="gpt-4o", messages=[...])

Three levels of control::

    # Level 1: Zero effort — just init()
    waxell.init()
    response = openai.chat.completions.create(...)  # auto-captured

    # Level 2: Decorator — adds structure + enrichment
    @waxell.observe(agent_name="my-chatbot")
    def chat(message):
        response = openai.chat.completions.create(...)
        waxell.score("helpfulness", 0.9)
        waxell.tag("intent", "question")
        return response

    # Level 3: Context manager — maximum control
    with waxell.context(agent_name="rag-pipeline", session_id="s1") as ctx:
        ctx.record_step("retrieval", output={"count": 5})
        response = openai.chat.completions.create(...)
        ctx.record_score("relevance", 0.85, data_type="numeric")

Drop-in import (alternative to init)::

    from waxell_observe.openai import openai      # patches on import
    from waxell_observe.anthropic import anthropic  # patches on import
"""

from waxell_observe.__about__ import __version__
from waxell_observe._init import init, shutdown
from waxell_observe.diagnose import diagnose
from waxell_observe.client import WaxellObserveClient
from waxell_observe.config import ObserveConfig

try:
    from waxell_observe.context import WaxellContext, HumanTurn, generate_session_id
except ImportError:
    raise ImportError(
        "waxell-observe core modules are not available for this platform. "
        "Install a pre-built wheel: pip install --only-binary=waxell-observe waxell-observe"
    )

# Convenience alias so users can write ``waxell.context(...)``
context = WaxellContext
from waxell_observe.decorator import observe, waxell_agent
from waxell_observe.tool import tool
from waxell_observe.decision import decision
from waxell_observe.retrieval import retrieval
from waxell_observe.reasoning import reasoning as reasoning_dec
from waxell_observe.retry import retry as retry_dec
from waxell_observe.step import step as step_dec
from waxell_observe.errors import ConfigurationError, ObserveError, PolicyViolationError
from waxell_observe.approval import (
    auto_approve,
    auto_deny,
    prompt_approval,
    extract_block_metadata,
    handle_policy_block,
)
from waxell_observe.instrumentors._context_var import _current_context
from waxell_observe.tracing import (
    flush_tracing,
    init_tracing,
    is_tracing_enabled,
    shutdown_tracing,
)
from waxell_observe.instrumentors._guard import PromptGuardError
from waxell_observe.types import (
    ApprovalDecision,
    LlmCallInfo,
    PolicyCheckResult,
    PromptGuardResult,
    RunCompleteResult,
    RunInfo,
)


# ---------------------------------------------------------------------------
# Top-level convenience functions (delegate to the current WaxellContext)
# ---------------------------------------------------------------------------


def score(
    name: str,
    value: float | str | bool,
    data_type: str = "numeric",
    comment: str = "",
) -> None:
    """Record a score on the current context (if active).

    This is a shorthand for ``ctx.record_score(...)`` that works without
    an explicit reference to the context -- it looks up the current
    ``WaxellContext`` via the ContextVar set by ``__aenter__`` or the
    ``@observe`` decorator.

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_score(name, value, data_type, comment)


def tag(key: str, value: str) -> None:
    """Set a tag on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.set_tag(key, value)


def metadata(key: str, value) -> None:
    """Set metadata on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.set_metadata(key, value)


def decide(
    name: str,
    chosen: str,
    options: list[str] | None = None,
    reasoning: str = "",
    confidence: float | None = None,
) -> None:
    """Record a decision on the current context (if active).

    One-liner for any provider — use this when you don't have an
    auto-instrumentor or the ``@decision`` decorator::

        waxell.decide("route_task", chosen="research",
                       options=["direct", "research", "multi_agent"],
                       reasoning="Complex query needs synthesis")

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        kwargs = dict(
            name=name,
            options=options or [],
            chosen=chosen,
            reasoning=reasoning,
            instrumentation_type="manual",
        )
        if confidence is not None:
            kwargs["confidence"] = confidence
        ctx.record_decision(**kwargs)


def step(name: str, output: dict | None = None) -> None:
    """Record an execution step on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_step(name, output)


def reason(
    step: str,
    thought: str,
    evidence: list[str] | None = None,
    conclusion: str = "",
) -> None:
    """Record a reasoning step on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_reasoning(
            step=step, thought=thought, evidence=evidence, conclusion=conclusion
        )


def retrieve(
    query: str,
    documents: list[dict],
    source: str = "",
    scores: list[float] | None = None,
) -> None:
    """Record a retrieval operation on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_retrieval(
            query=query, documents=documents, source=source, scores=scores
        )


def retry(
    attempt: int,
    reason: str,
    strategy: str = "retry",
    original_error: str = "",
    fallback_to: str = "",
) -> None:
    """Record a retry/fallback event on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_retry(
            attempt=attempt,
            reason=reason,
            strategy=strategy,
            original_error=original_error,
            fallback_to=fallback_to,
        )


def approval_request(
    action_type: str,
    approvers: list[str] | None = None,
    timeout_minutes: float | None = None,
    reason: str = "",
    metadata: dict | None = None,
) -> None:
    """Record an approval request on the current context (if active).

    Call after catching :class:`PolicyViolationError` to record that an
    approval workflow was initiated.  The event appears in the governance
    timeline alongside the original policy block.

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_approval_request(
            action_type=action_type,
            approvers=approvers,
            timeout_minutes=timeout_minutes,
            reason=reason,
            metadata=metadata,
        )


def approval_response(
    action_type: str,
    decision: str,
    approver: str = "",
    elapsed_seconds: float | None = None,
    metadata: dict | None = None,
) -> None:
    """Record an approval decision on the current context (if active).

    Call after the human-in-the-loop decides or the approval window expires.

    Args:
        action_type: The action that was awaiting approval.
        decision: ``"approved"``, ``"denied"``, or ``"timeout"``.
        approver: Who approved/denied (email, username).
        elapsed_seconds: Time from block to decision.
        metadata: Additional context.

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_approval_response(
            action_type=action_type,
            decision=decision,
            approver=approver,
            elapsed_seconds=elapsed_seconds,
            metadata=metadata,
        )


def user_message(content: str, *, metadata: dict | None = None) -> None:
    """Record an inbound user message on the current context (if active).

    Use in interactive agents (chat, REPL) to make user inputs visible
    in the trace alongside LLM calls and tool invocations.

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_user_message(content, metadata=metadata)


def agent_response(content: str, *, metadata: dict | None = None) -> None:
    """Record an outbound agent response on the current context (if active).

    Use in interactive agents to trace what the agent communicated
    back to the user.

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_agent_response(content, metadata=metadata)


def communication(
    *,
    channel: str,
    recipient: str = "",
    body: str = "",
    subject: str = "",
    metadata: dict | None = None,
) -> None:
    """Record an outbound communication on the current context (if active).

    Use to track messages sent via external channels (Slack, email, SMS, etc.)
    for communication governance policy evaluation.

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_communication(
            channel=channel,
            recipient=recipient,
            body=body,
            subject=subject,
            metadata=metadata,
        )


# Use a different name to avoid shadowing the built-in ``input``.
_builtin_input = input


def observed_input(prompt: str = "", *, action: str = "input") -> str:
    """Drop-in replacement for ``input()`` that auto-records a human_turn span.

    Swap ``input(...)`` for ``waxell.input(...)`` and the prompt, response,
    and wait time are captured automatically::

        import waxell_observe as waxell
        answer = waxell.input("Approve? (y/n): ")

    Falls back to plain ``input()`` if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        return ctx.input(prompt, action=action)
    return _builtin_input(prompt)


# Expose as ``waxell.input`` for the cleanest developer experience.
input = observed_input


class _NoOpHumanTurn:
    """Returned by ``human_turn()`` when no context is active."""

    def set_response(self, response: str) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc_info):
        return False


def human_turn(
    prompt: str = "",
    channel: str = "terminal",
    action: str = "",
    metadata: dict | None = None,
) -> "HumanTurn | _NoOpHumanTurn":
    """Capture a human-in-the-loop interaction as a timed IO span.

    Returns a context manager that records prompt, response, channel,
    and elapsed time when it exits::

        with waxell.human_turn(prompt="Proceed?", channel="terminal") as turn:
            answer = input("Proceed? (y/n): ")
            turn.set_response(answer)

    Works for any interactive pattern — terminal, Slack, UI, webhooks.
    Returns a no-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        return ctx.human_turn(
            prompt=prompt, channel=channel, action=action, metadata=metadata
        )
    return _NoOpHumanTurn()


def human_interaction(
    prompt: str = "",
    response: str = "",
    channel: str = "terminal",
    action: str = "",
    elapsed_seconds: float | None = None,
    metadata: dict | None = None,
) -> None:
    """Record a completed human interaction on the current context (if active).

    One-shot alternative to the ``human_turn()`` context manager — use when
    you already have the prompt, response, and timing data::

        waxell.human_interaction(
            prompt="Pick a target",
            response="staging",
            channel="slack",
            elapsed_seconds=12.5,
        )

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        elapsed_ms = elapsed_seconds * 1000 if elapsed_seconds is not None else None
        ctx.record_human_interaction(
            prompt=prompt,
            response=response,
            channel=channel,
            action=action,
            elapsed_ms=elapsed_ms,
            metadata=metadata,
        )


async def flush() -> None:
    """Flush buffered data on the current context (if active).

    Use in long-running contexts (REPLs, chat sessions) to make child
    run summaries visible in the UI before the parent exits.

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        await ctx.flush()


def flush_sync() -> None:
    """Synchronous version of :func:`flush`.

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.flush_sync()


def get_context():
    """Get the current WaxellContext, or None if not in a context."""
    return _current_context.get()


__all__ = [
    "__version__",
    "init",
    "shutdown",
    "WaxellObserveClient",
    "ObserveConfig",
    "WaxellContext",
    "HumanTurn",
    "context",
    "generate_session_id",
    "waxell_agent",
    "observe",
    # Decorators
    "tool",
    "decision",
    "retrieval",
    "reasoning_dec",
    "retry_dec",
    "step_dec",
    # Convenience functions
    "decide",
    "score",
    "tag",
    "metadata",
    "step",
    "reason",
    "retrieve",
    "retry",
    "approval_request",
    "approval_response",
    "user_message",
    "agent_response",
    "input",
    "human_turn",
    "human_interaction",
    "flush",
    "flush_sync",
    "get_context",
    "diagnose",
    # Approval handlers
    "prompt_approval",
    "auto_approve",
    "auto_deny",
    "extract_block_metadata",
    "handle_policy_block",
    # Errors
    "ConfigurationError",
    "ObserveError",
    "PolicyViolationError",
    # Types
    "ApprovalDecision",
    "LlmCallInfo",
    "PolicyCheckResult",
    "PromptGuardError",
    "PromptGuardResult",
    "RunCompleteResult",
    "RunInfo",
    # Tracing
    "init_tracing",
    "flush_tracing",
    "shutdown_tracing",
    "is_tracing_enabled",
]
