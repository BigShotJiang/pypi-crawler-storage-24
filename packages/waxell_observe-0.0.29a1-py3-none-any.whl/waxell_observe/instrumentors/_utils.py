"""Shared utilities for vector DB instrumentors."""

from __future__ import annotations


def normalize_distances(
    distances: list[float], metric: str = "l2"
) -> list[float]:
    """Convert distance values to 0-1 similarity scores.

    Args:
        distances: Raw distance values from the vector DB.
        metric: Distance metric used. One of "l2", "cosine", "ip".

    Returns:
        List of similarity scores in [0.0, 1.0] range.
    """
    if metric in ("cosine", "ip"):
        # Cosine distance is typically 0-2 (1 - cosine_similarity).
        # Inner product distance can vary.
        return [max(0.0, min(1.0, 1.0 - d)) for d in distances]
    # L2 (Euclidean) — unbounded, use inverse transform
    return [1.0 / (1.0 + d) for d in distances]
