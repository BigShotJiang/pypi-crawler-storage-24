"""Base class and shared helpers for waxell-observe auto-instrumentors.

Defines the interface that all library-specific instrumentors must implement.
This module has NO OpenTelemetry imports at module level, so it can be
imported safely regardless of whether OTel is installed.
"""

from abc import ABC, abstractmethod


def extract_prompt_preview(messages: list, max_len: int = 500) -> str:
    """Return a prompt preview from an LLM messages array.

    Finds the **last user-role message** so the preview shows what the
    user actually asked — not the system prompt.  Falls back to the first
    message if no user message exists.
    """
    if not messages:
        return ""

    # Walk backwards to find the last user message
    for msg in reversed(messages):
        if isinstance(msg, dict):
            role = msg.get("role", "")
            content = msg.get("content", "")
        elif hasattr(msg, "role"):
            role = getattr(msg, "role", "")
            content = getattr(msg, "content", "")
        else:
            continue

        if role == "user":
            # Content may be a string or a list of content blocks
            if isinstance(content, list):
                # e.g. [{"type": "text", "text": "..."}, ...]
                parts = []
                for block in content:
                    if isinstance(block, dict):
                        parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        parts.append(block)
                content = " ".join(p for p in parts if p)
            return str(content)[:max_len]

    # No user message found — fall back to first message content
    first = messages[0]
    if isinstance(first, dict):
        content = first.get("content", "")
    elif hasattr(first, "content"):
        content = getattr(first, "content", "")
    else:
        content = str(first)

    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                parts.append(block.get("text", ""))
            elif isinstance(block, str):
                parts.append(block)
        content = " ".join(p for p in parts if p)

    return str(content)[:max_len]


class BaseInstrumentor(ABC):
    """Abstract base class for library-specific instrumentors.

    Subclasses implement monkey-patching logic to intercept LLM SDK
    calls and emit spans/metrics.

    Each subclass maintains its own ``_instrumented`` guard to prevent
    double-patching.
    """

    _instrumented: bool = False

    @abstractmethod
    def instrument(self) -> bool:
        """Apply monkey-patches to the target library.

        Returns True if instrumentation was applied successfully,
        False if skipped (e.g. library not importable, already
        instrumented).
        """
        ...

    @abstractmethod
    def uninstrument(self) -> None:
        """Restore original (unpatched) methods on the target library."""
        ...

    @abstractmethod
    def is_instrumented(self) -> bool:
        """Return True if this instrumentor is currently active."""
        ...
