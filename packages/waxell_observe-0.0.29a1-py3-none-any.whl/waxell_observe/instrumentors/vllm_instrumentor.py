"""vLLM auto-instrumentor for waxell-observe.

Monkey-patches vllm.LLM.generate and vllm.LLM.chat to emit LLM call
spans for local model inference.

vLLM returns ``RequestOutput`` objects with:
  - ``prompt_token_ids``          -- list of input token ids
  - ``outputs[0].token_ids``      -- list of output token ids per completion
  - ``outputs[0].text``           -- generated text

Cost is always 0.0 for local inference.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class VLLMInstrumentor(BaseInstrumentor):
    """Instrumentor for the vLLM library (``vllm`` package).

    Patches ``LLM.generate`` and ``LLM.chat`` (if available in newer
    vLLM versions).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import vllm  # noqa: F401
        except ImportError:
            logger.debug("vllm package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping vLLM instrumentation")
            return False

        patched = False

        # Patch LLM.generate (always present)
        try:
            wrapt.wrap_function_wrapper(
                "vllm",
                "LLM.generate",
                _sync_generate_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch vllm.LLM.generate: %s", exc)

        # Patch LLM.chat (available in newer vLLM versions)
        try:
            wrapt.wrap_function_wrapper(
                "vllm",
                "LLM.chat",
                _sync_chat_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch vllm.LLM.chat (may not exist in this version): %s", exc)

        if not patched:
            logger.debug("Could not find any vLLM LLM methods to patch")
            return False

        self._instrumented = True
        logger.debug("vLLM LLM instrumented (generate + chat)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import vllm

            for attr in ("generate", "chat"):
                method = getattr(vllm.LLM, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(vllm.LLM, attr, method.__wrapped__)  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("vLLM LLM uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from vLLM RequestOutput objects
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from a vLLM LLM instance.

    Tries several attribute paths used across different vLLM versions.
    """
    # vLLM stores the model path/name in various attributes
    for attr in ("model", "model_config", "llm_engine"):
        try:
            val = getattr(instance, attr, None)
            if val is None:
                continue

            if isinstance(val, str):
                return val

            # model_config has a model attribute
            model_name = getattr(val, "model", None)
            if model_name and isinstance(model_name, str):
                return model_name
        except Exception:
            continue

    return "vllm-local"


def _extract_token_counts(results) -> tuple[int, int]:
    """Extract input and output token counts from a list of RequestOutput.

    Returns (tokens_in, tokens_out) for the first result.
    """
    if not results:
        return 0, 0

    try:
        first = results[0]
        tokens_in = len(getattr(first, "prompt_token_ids", []) or [])
        tokens_out = sum(
            len(getattr(o, "token_ids", []) or [])
            for o in getattr(first, "outputs", [])
        )
        return tokens_in, tokens_out
    except Exception:
        return 0, 0


def _extract_response_text(results) -> str:
    """Extract generated text from the first RequestOutput for logging."""
    if not results:
        return ""

    try:
        first = results[0]
        outputs = getattr(first, "outputs", [])
        if outputs:
            text = getattr(outputs[0], "text", "")
            return str(text)[:500] if text else ""
    except Exception:
        pass

    return ""


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``vllm.LLM.generate``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="vllm")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        results = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_token_counts(results)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)  # Local inference
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_vllm(results, model, kwargs, task="generate")
        except Exception:
            pass

        return results
    finally:
        span.end()


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``vllm.LLM.chat``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="vllm")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        results = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_token_counts(results)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)  # Local inference
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_vllm(results, model, kwargs, task="chat")
        except Exception:
            pass

        return results
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_vllm(
    results, request_model: str, kwargs: dict, task: str = "generate"
) -> None:
    """Record a vLLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    tokens_in, tokens_out = _extract_token_counts(results)

    # Extract prompt preview
    from ._base import extract_prompt_preview
    prompt_preview = ""
    if task == "chat":
        messages = kwargs.get("messages") or (args[0] if "args" in dir() else None)
        if isinstance(messages, list) and messages:
            prompt_preview = extract_prompt_preview(messages)
    else:
        prompts = kwargs.get("prompts") or kwargs.get("prompt")
        if prompts is None and "args" not in dir():
            prompts = ""
        if isinstance(prompts, str):
            prompt_preview = prompts[:500]
        elif isinstance(prompts, list) and prompts:
            prompt_preview = str(prompts[0])[:500]

    response_preview = _extract_response_text(results)

    call_data = {
        "model": request_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,  # Local inference is always free
        "task": f"vllm.{task}",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
