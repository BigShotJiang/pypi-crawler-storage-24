"""Anthropic auto-instrumentor for waxell-observe.

Monkey-patches ``anthropic.resources.messages.Messages.create``
(sync) and ``AsyncMessages.create`` (async) to emit OTel spans with
GenAI semantic convention attributes.

Streaming calls (``stream=True``) are wrapped to accumulate token counts
from Anthropic's event-based stream protocol:
  - ``message_start`` provides ``input_tokens``
  - ``content_block_delta`` provides text fragments
  - ``message_delta`` provides ``output_tokens``
  - ``message_stop`` signals stream completion

The wrapper classes proxy the stream transparently and record the LLM
call on stream completion.

Key differences from the OpenAI instrumentor:
  - Module path: ``anthropic.resources.messages`` (not ``chat.completions``)
  - Class names: ``Messages`` / ``AsyncMessages``
  - Token fields: ``response.usage.input_tokens`` / ``output_tokens``
    (not ``prompt_tokens`` / ``completion_tokens``)
  - Finish reason: ``response.stop_reason`` (not ``choices[].finish_reason``)
  - Provider name: ``"anthropic"``

All wrapper code is wrapped in try/except at the top level -- if span
creation fails, the original method is still called.  Never breaks the
user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AnthropicInstrumentor(BaseInstrumentor):
    """Instrumentor for the Anthropic Python SDK (``anthropic`` package).

    Patches ``messages.create`` for both sync and async clients.
    """

    _instrumented: bool = False
    _originals: dict = {}

    def instrument(self) -> bool:
        """Apply monkey-patches to Anthropic SDK messages methods.

        Returns True if patches were applied, False if the ``anthropic``
        package is not installed.
        """
        if self._instrumented:
            return True

        try:
            import anthropic.resources.messages  # noqa: F401
        except ImportError:
            logger.debug("anthropic package not installed -- skipping instrumentation")
            return False

        # Log detected version for diagnostics
        try:
            import anthropic
            _version = getattr(anthropic, "__version__", "unknown")
            logger.debug("Detected anthropic package version: %s", _version)
        except Exception:
            pass

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Anthropic instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "anthropic.resources.messages",
                "Messages.create",
                _sync_messages_wrapper,
            )

            wrapt.wrap_function_wrapper(
                "anthropic.resources.messages",
                "AsyncMessages.create",
                _async_messages_wrapper,
            )

            self._instrumented = True
            logger.debug("Anthropic messages instrumented (sync + async)")
            return True
        except Exception as exc:
            logger.warning(
                "Failed to instrument Anthropic SDK (possibly incompatible version): %s",
                exc,
            )
            return False

    def uninstrument(self) -> None:
        """Restore original Anthropic SDK methods."""
        if not self._instrumented:
            return

        try:
            import anthropic.resources.messages as mod

            # wrapt stores the original as __wrapped__
            if hasattr(mod.Messages.create, "__wrapped__"):
                mod.Messages.create = mod.Messages.create.__wrapped__  # type: ignore[attr-defined]
            if hasattr(mod.AsyncMessages.create, "__wrapped__"):
                mod.AsyncMessages.create = mod.AsyncMessages.create.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("Anthropic messages uninstrumented")

    def is_instrumented(self) -> bool:
        """Return True if Anthropic SDK is currently patched."""
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions (module-level so wrapt can pickle/reference them)
# ---------------------------------------------------------------------------


def _sync_messages_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Messages.create``."""
    # --- Prompt guard (pre-LLM check, includes Anthropic system prompt) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []),
            model=kwargs.get("model", ""),
            system=kwargs.get("system", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
                if hasattr(guard_result, "_redacted_system"):
                    kwargs["system"] = guard_result._redacted_system
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        # If our tracing infrastructure fails to import, just call through
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="anthropic")
    except Exception:
        # Span creation failed -- call original unmodified
        return wrapped(*args, **kwargs)

    if is_streaming:
        # Streaming: wrap the response to capture tokens on completion
        stream = wrapped(*args, **kwargs)
        try:
            from ._stream_wrappers import AnthropicSyncStreamWrapper

            return AnthropicSyncStreamWrapper(stream, span, model)
        except Exception:
            # Wrap failure -- return original stream so user code isn't affected
            try:
                span.end()
            except Exception:
                pass
            return stream

    # Non-streaming: full instrumentation
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Anthropic uses input_tokens / output_tokens (NOT prompt_tokens / completion_tokens)
            tokens_in = getattr(response.usage, 'input_tokens', getattr(response.usage, 'prompt_tokens', 0)) if response.usage else 0
            tokens_out = getattr(response.usage, 'output_tokens', getattr(response.usage, 'completion_tokens', 0)) if response.usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            # Anthropic uses stop_reason (NOT choices[].finish_reason)
            finish_reasons = [response.stop_reason] if response.stop_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API (never breaks the LLM call)
        try:
            _record_http_anthropic(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_messages_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncMessages.create``."""
    # --- Prompt guard (pre-LLM check, includes Anthropic system prompt) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []),
            model=kwargs.get("model", ""),
            system=kwargs.get("system", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
                if hasattr(guard_result, "_redacted_system"):
                    kwargs["system"] = guard_result._redacted_system
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="anthropic")
    except Exception:
        return await wrapped(*args, **kwargs)

    if is_streaming:
        # Streaming: wrap the async response to capture tokens on completion
        stream = await wrapped(*args, **kwargs)
        try:
            from ._stream_wrappers import AnthropicAsyncStreamWrapper

            return AnthropicAsyncStreamWrapper(stream, span, model)
        except Exception:
            # Wrap failure -- return original stream so user code isn't affected
            try:
                span.end()
            except Exception:
                pass
            return stream

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in = getattr(response.usage, 'input_tokens', getattr(response.usage, 'prompt_tokens', 0)) if response.usage else 0
            tokens_out = getattr(response.usage, 'output_tokens', getattr(response.usage, 'completion_tokens', 0)) if response.usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            finish_reasons = [response.stop_reason] if response.stop_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API (never breaks the LLM call)
        try:
            _record_http_anthropic(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_anthropic(response, request_model: str, kwargs: dict) -> None:
    """Record an Anthropic LLM call to the HTTP path (context or collector).

    This function is called AFTER the LLM call succeeds and OTel span
    attributes are set.  It MUST NOT raise -- callers wrap it in
    try/except.
    """
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    # Anthropic uses input_tokens / output_tokens (not prompt_tokens / completion_tokens)
    tokens_in = getattr(response.usage, 'input_tokens', getattr(response.usage, 'prompt_tokens', 0)) if response.usage else 0
    tokens_out = getattr(response.usage, 'output_tokens', getattr(response.usage, 'completion_tokens', 0)) if response.usage else 0
    response_model = getattr(response, "model", request_model)
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    from ._base import extract_prompt_preview
    messages = kwargs.get("messages", [])
    prompt_preview = extract_prompt_preview(messages)

    # Anthropic response content is a list of content blocks
    response_preview = ""
    if response.content:
        first_block = response.content[0]
        if hasattr(first_block, "text"):
            response_preview = first_block.text[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "messages.create",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data, provider="anthropic", _auto_instrumented=True)
    else:
        _collector.record_call(call_data)

    # Auto-capture tool_use decisions + tool calls from response
    try:
        if response.content:
            from ._auto_decision import record_tool_decisions, extract_tool_names_from_request

            tool_calls = []
            for block in response.content:
                if hasattr(block, "type") and block.type == "tool_use":
                    tool_calls.append({
                        "name": getattr(block, "name", "unknown"),
                        "input": getattr(block, "input", {}),
                        "id": getattr(block, "id", ""),
                    })
            if tool_calls:
                available = extract_tool_names_from_request(kwargs)
                record_tool_decisions(tool_calls=tool_calls, available_tools=available or None)
    except Exception:
        pass  # Never break user code

    # Auto-capture conversation IO
    try:
        from ._auto_conversation import record_conversation_io
        is_final = getattr(response, "stop_reason", "") == "end_turn"
        system_content = ""
        raw_system = kwargs.get("system", "")
        if isinstance(raw_system, str):
            system_content = raw_system
        elif isinstance(raw_system, list):
            system_content = " ".join(
                b.get("text", "") if isinstance(b, dict) else str(b)
                for b in raw_system
            )
        record_conversation_io(
            messages=messages,
            response_preview=response_preview,
            is_final_response=is_final,
            tokens_in_context=tokens_in,
            model=response_model,
            ctx=ctx,
            system_content=system_content,
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span, setting status to ERROR."""
    try:
        span.record_exception(exc)
        # Use lazy import for StatusCode to handle missing OTel
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        # OTel not available or span is NoOp -- that's fine
        pass
