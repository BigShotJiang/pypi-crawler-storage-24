"""Model context window limits for context utilization tracking.

Maps model names to their maximum context window sizes (in tokens).
Used by auto-conversation tracking to compute utilization percentages.
"""

from __future__ import annotations

MODEL_CONTEXT_LIMITS: dict[str, int] = {
    # OpenAI
    "gpt-4o": 128_000,
    "gpt-4o-mini": 128_000,
    "gpt-4-turbo": 128_000,
    "gpt-4-turbo-preview": 128_000,
    "gpt-4": 8_192,
    "gpt-4-32k": 32_768,
    "gpt-3.5-turbo": 16_385,
    "o1": 200_000,
    "o1-mini": 128_000,
    "o1-preview": 128_000,
    "o3": 200_000,
    "o3-mini": 200_000,
    "o4-mini": 200_000,
    # Anthropic
    "claude-opus-4": 200_000,
    "claude-sonnet-4": 200_000,
    "claude-3-5-sonnet": 200_000,
    "claude-3-5-haiku": 200_000,
    "claude-3-opus": 200_000,
    "claude-3-sonnet": 200_000,
    "claude-3-haiku": 200_000,
    # Google
    "gemini-2.0-flash": 1_048_576,
    "gemini-2.0-flash-lite": 1_048_576,
    "gemini-1.5-pro": 2_097_152,
    "gemini-1.5-flash": 1_048_576,
    # Mistral
    "mistral-large": 128_000,
    "mistral-large-latest": 128_000,
    "mistral-small": 128_000,
    "mistral-small-latest": 128_000,
    "mistral-medium": 32_000,
    "codestral": 32_000,
    "open-mistral-nemo": 128_000,
    # Cohere
    "command-r-plus": 128_000,
    "command-r": 128_000,
    "command-a": 256_000,
    # Meta (via Together/Groq/etc)
    "llama-3.1-405b": 128_000,
    "llama-3.1-70b": 128_000,
    "llama-3.1-8b": 128_000,
    "llama-3.2-90b": 128_000,
    "llama-3.2-11b": 128_000,
    "llama-3.2-3b": 128_000,
    "llama-3.2-1b": 128_000,
    "llama-3.3-70b": 128_000,
    "llama-4-scout": 512_000,
    "llama-4-maverick": 1_048_576,
    # Qwen (via Together/Ollama/etc)
    "qwen-2.5-72b": 128_000,
    "qwen-2.5-32b": 128_000,
    "qwen-2.5-7b": 128_000,
    "qwen-2.5-coder-32b": 128_000,
    # DeepSeek
    "deepseek-v3": 128_000,
    "deepseek-r1": 128_000,
    "deepseek-chat": 128_000,
    "deepseek-reasoner": 128_000,
}


def get_context_limit(model: str) -> int | None:
    """Return context window size for a model.

    Performs exact match first, then tries fuzzy matching by stripping
    common date suffixes (e.g. ``gpt-4o-2024-08-06`` -> ``gpt-4o``).

    Returns None if model is not recognized.
    """
    if not model:
        return None

    # Exact match
    lower = model.lower()
    if lower in MODEL_CONTEXT_LIMITS:
        return MODEL_CONTEXT_LIMITS[lower]

    # Try stripping date suffixes (YYYY-MM-DD or YYYYMMDD)
    import re

    stripped = re.sub(r"-?\d{4}-?\d{2}-?\d{2}$", "", lower).rstrip("-")
    if stripped and stripped in MODEL_CONTEXT_LIMITS:
        return MODEL_CONTEXT_LIMITS[stripped]

    # Try prefix matching (e.g. "gpt-4o-mini-2024" -> "gpt-4o-mini")
    for known in sorted(MODEL_CONTEXT_LIMITS.keys(), key=len, reverse=True):
        if lower.startswith(known):
            return MODEL_CONTEXT_LIMITS[known]

    return None
