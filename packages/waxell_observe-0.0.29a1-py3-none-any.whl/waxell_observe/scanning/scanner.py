"""Shared PII scanning module for MCP governance.

Extracted from ``mcp_governance.py`` so both client-side instrumentor
and server-side middleware can import from a single location.
"""

from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

logger = logging.getLogger("waxell")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TRUNCATE_SCAN_AT = 4096  # 4KB truncation for PII scanning (matches _TRUNCATE_AT in mcp_instrumentor.py)

# PII action severity for determining highest-severity action taken
_ACTION_SEVERITY = {"warn": 0, "redact": 1, "block": 2}


# ---------------------------------------------------------------------------
# PII Scanner Protocol and Default Implementation
# ---------------------------------------------------------------------------


@runtime_checkable
class PIIScanner(Protocol):
    """Protocol for pluggable PII scanners."""

    def scan(self, text: str) -> dict:
        """Scan text and return {"detected": bool, "count": int, "findings": list[dict]}."""
        ...


class RegexPIIScanner:
    """Default PII scanner wrapping _guard.py regex patterns.

    Each finding dict contains: ``type`` (str), ``category`` ("pii" or "credential"),
    and ``action`` ("warn", "block", or "redact").
    """

    def __init__(self, actions: dict[str, str] | None = None):
        """Create scanner with optional per-type action overrides.

        Args:
            actions: Maps PII/credential type to action. Example:
                ``{"ssn": "block", "email": "warn"}``. Default action is "warn".
        """
        self._actions = actions or {}

    def scan(self, text: str) -> dict:
        from ..instrumentors._guard import _detect_credentials, _detect_pii

        findings: list[dict] = []
        for violation in _detect_pii(text):
            pii_type = violation.split(": ")[1] if ": " in violation else "unknown"
            action = self._actions.get(pii_type, "warn")
            findings.append({"type": pii_type, "category": "pii", "action": action})
        for violation in _detect_credentials(text):
            cred_type = violation.split(": ")[1] if ": " in violation else "unknown"
            action = self._actions.get(cred_type, "warn")
            findings.append(
                {"type": cred_type, "category": "credential", "action": action}
            )
        return {
            "detected": bool(findings),
            "count": len(findings),
            "findings": findings,
        }


# ---------------------------------------------------------------------------
# PII Scanning
# ---------------------------------------------------------------------------


def scan_text_for_pii(
    text: str | None,
    scanner: PIIScanner | None = None,
    truncate_at: int = _TRUNCATE_SCAN_AT,
) -> dict:
    """Scan text for PII using a pluggable scanner.

    Args:
        text: Text to scan. If None or empty, returns not-detected immediately.
        scanner: Custom scanner implementing :class:`PIIScanner` protocol.
            If None, uses :class:`RegexPIIScanner` (wraps ``_guard.py`` patterns).
        truncate_at: Maximum bytes to scan (default 4KB). Longer text is truncated.

    Returns:
        Dict with ``detected`` (bool), ``count`` (int), ``findings`` (list[dict]).
        On scanner error, returns not-detected (fail-open).
    """
    if not text:
        return {"detected": False, "count": 0, "findings": []}

    try:
        # Truncate for performance
        scan_text = text[:truncate_at]

        if scanner is not None:
            return scanner.scan(scan_text)

        # Default: use _guard.py patterns
        return RegexPIIScanner().scan(scan_text)
    except Exception as exc:
        logger.warning("MCP PII scan failed: %s -- treating as no PII (fail-open)", exc)
        return {"detected": False, "count": 0, "findings": []}
