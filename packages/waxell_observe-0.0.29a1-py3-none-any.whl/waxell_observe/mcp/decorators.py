"""Per-tool governance decorator for FastMCP server tools.

Attaches a :class:`ToolGovernanceConfig` as metadata on the tool function.
The ``GovernanceMiddleware`` reads this config at runtime.
"""

from __future__ import annotations

import functools
from typing import Callable, TypeVar

from .config import ToolGovernanceConfig

F = TypeVar("F", bound=Callable)


def governance(
    *,
    approval_required: bool = False,
    pii_scan: str = "standard",
    policy_action: str | None = None,
    rate_limit: dict | None = None,
) -> Callable[[F], F]:
    """Per-tool governance decorator for FastMCP server tools.

    Attaches governance config as metadata on the tool function.
    The ``GovernanceMiddleware`` reads this config at runtime via
    ``tool.fn._waxell_governance``.

    Usage::

        @governance(approval_required=True, pii_scan="strict")
        @mcp.tool
        async def delete_user(user_id: str) -> str:
            ...

    Order-independent: can be applied above or below ``@mcp.tool``.

    Args:
        approval_required: Whether the tool call requires approval.
        pii_scan: PII scanning mode -- ``"none"``, ``"standard"``, or ``"strict"``.
        policy_action: Override policy action -- ``"allow"``, ``"block"``, ``"warn"``.
        rate_limit: Per-tool rate limit. Example:
            ``{"max_per_minute": 10, "max_per_hour": 100}``.

    Returns:
        Decorator that attaches ``_waxell_governance`` config to the function.
    """
    config = ToolGovernanceConfig(
        approval_required=approval_required,
        pii_scan=pii_scan,
        policy_action=policy_action,
        rate_limit=rate_limit,
    )

    def decorator(fn: F) -> F:
        # Set on the original function first
        fn._waxell_governance = config  # type: ignore[attr-defined]

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            return fn(*args, **kwargs)

        # Preserve on wrapper too, since FastMCP's @mcp.tool may wrap again
        wrapper._waxell_governance = config  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    return decorator
