"""Configuration dataclasses for MCP server-side governance middleware.

Provides per-tool and server-level configuration for the GovernanceMiddleware.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ToolGovernanceConfig:
    """Per-tool governance configuration.

    Applied via ``@governance`` decorator or constructor ``tool_configs`` dict.

    Attributes:
        approval_required: Whether the tool call requires approval before execution.
        pii_scan: PII scanning mode -- ``"none"``, ``"standard"``, or ``"strict"``.
        policy_action: Override policy action -- ``"allow"``, ``"block"``, or ``"warn"``.
            ``None`` means use the server-level default.
        rate_limit: Per-tool rate limit config. Example:
            ``{"max_per_minute": 10, "max_per_hour": 100}``.
    """

    approval_required: bool = False
    pii_scan: str = "standard"
    policy_action: str | None = None
    rate_limit: dict | None = None


@dataclass
class MiddlewareConfig:
    """Server-level governance defaults.

    Passed as ``policy_config`` dict to ``GovernanceMiddleware`` constructor
    and parsed into this dataclass.

    Attributes:
        default_pii_scan: Default PII scanning mode for unconfigured tools.
        default_policy_action: Default policy action for unconfigured tools.
        fail_open: If ``True``, governance errors let tool calls proceed.
            If ``False``, governance errors block tool calls.
    """

    default_pii_scan: str = "standard"
    default_policy_action: str = "allow"
    fail_open: bool = True
