"""GovernanceMiddleware for FastMCP servers.

Intercepts ``on_call_tool`` to apply policy checks, PII scanning, rate limiting,
caller identity extraction, and OTel span recording on every incoming tool call.

Usage::

    from fastmcp import FastMCP
    from waxell_observe.mcp import GovernanceMiddleware

    mcp = FastMCP("MyServer")
    mcp.add_middleware(GovernanceMiddleware(api_key="wax_sk_..."))
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import threading
import time
from collections import defaultdict
from datetime import datetime, timezone

from fastmcp.exceptions import ToolError
from fastmcp.server.middleware import Middleware, MiddlewareContext

from .config import MiddlewareConfig, ToolGovernanceConfig

logger = logging.getLogger("waxell")


# ---------------------------------------------------------------------------
# Rate Limiter
# ---------------------------------------------------------------------------


class RateLimiter:
    """Thread-safe sliding window rate limiter for per-tool governance.

    Uses ``threading.Lock`` and ``collections.defaultdict`` for thread safety
    across concurrent async tool calls.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._calls: dict[str, list[float]] = defaultdict(list)

    def check(
        self,
        tool_name: str,
        max_per_minute: int | None = None,
        max_per_hour: int | None = None,
    ) -> tuple[bool, int]:
        """Check if a tool call is within rate limits.

        Args:
            tool_name: Tool being rate-limited.
            max_per_minute: Maximum calls per 60-second window.
            max_per_hour: Maximum calls per 3600-second window.

        Returns:
            Tuple of ``(allowed, remaining)``. ``remaining`` is -1 when no limit
            is configured.
        """
        if max_per_minute is None and max_per_hour is None:
            return True, -1

        now = time.monotonic()
        with self._lock:
            # Clean entries older than 1 hour
            self._calls[tool_name] = [
                t for t in self._calls[tool_name] if now - t < 3600
            ]

            remaining = float("inf")

            # Check minute limit
            if max_per_minute is not None:
                recent_minute = sum(1 for t in self._calls[tool_name] if now - t < 60)
                if recent_minute >= max_per_minute:
                    return False, 0
                remaining = min(remaining, max_per_minute - recent_minute - 1)

            # Check hour limit
            if max_per_hour is not None:
                recent_hour = len(self._calls[tool_name])
                if recent_hour >= max_per_hour:
                    return False, 0
                remaining = min(remaining, max_per_hour - recent_hour - 1)

            self._calls[tool_name].append(now)
            return True, int(remaining)


# ---------------------------------------------------------------------------
# GovernanceMiddleware
# ---------------------------------------------------------------------------


class GovernanceMiddleware(Middleware):
    """Governance middleware for FastMCP servers.

    Applies policy checks, PII scanning, rate limiting, caller identity
    extraction, and OTel span recording on incoming tool calls.

    Works standalone without an API key -- OTel spans and PII scans work
    locally, policy checks skip gracefully when no controlplane is available.

    Args:
        api_key: Waxell API key for controlplane policy checks. Optional.
        api_url: Waxell API URL. Optional.
        policy_config: Server-level governance defaults as a dict.
            Parsed into :class:`MiddlewareConfig`.
        pii_scanner: Custom PII scanner implementing the ``PIIScanner`` protocol.
            If ``None``, uses :class:`RegexPIIScanner` (default regex patterns).
        tool_configs: Per-tool governance configs by tool name. Example:
            ``{"delete_user": ToolGovernanceConfig(approval_required=True)}``.
    """

    def __init__(
        self,
        api_key: str = "",
        api_url: str = "",
        policy_config: dict | None = None,
        pii_scanner: object | None = None,
        tool_configs: dict[str, ToolGovernanceConfig] | None = None,
    ) -> None:
        self.api_key = api_key
        self.api_url = api_url
        self.pii_scanner = pii_scanner
        self.tool_configs = tool_configs or {}
        self._initialized = False
        self._rate_limiter = RateLimiter()
        self._has_controlplane = bool(api_key)

        # Parse policy_config dict into MiddlewareConfig
        pc = policy_config or {}
        self._config = MiddlewareConfig(
            default_pii_scan=pc.get("default_pii_scan", "standard"),
            default_policy_action=pc.get("default_policy_action", "allow"),
            fail_open=pc.get("fail_open", True),
        )

    # -----------------------------------------------------------------
    # OTel initialization
    # -----------------------------------------------------------------

    def _ensure_initialized(self) -> None:
        """Auto-initialize OTel tracing on first tool call.

        Calls ``waxell_observe.init()`` which is idempotent.
        """
        if self._initialized:
            return
        try:
            import waxell_observe

            waxell_observe.init(
                api_key=self.api_key,
                api_url=self.api_url,
            )
        except Exception as exc:
            logger.warning(
                "GovernanceMiddleware: failed to auto-initialize OTel: %s", exc
            )
        self._initialized = True

    # -----------------------------------------------------------------
    # Tool config resolution
    # -----------------------------------------------------------------

    def _get_tool_config(
        self, tool_name: str, context: MiddlewareContext
    ) -> ToolGovernanceConfig:
        """Resolve per-tool governance config.

        Resolution order (highest priority wins):

        1. ``@governance`` decorator config on the tool function
        2. Constructor ``tool_configs[tool_name]`` dict
        3. Server-level defaults from ``self._config``
        """
        # Try @governance decorator on tool function
        try:
            fmcp_ctx = context.fastmcp_context
            if fmcp_ctx is not None:
                fastmcp_inst = fmcp_ctx.fastmcp
                # get_tool is async but we need sync access here.
                # Instead, check tool_configs first, then try the async path
                # in the caller. For now, we read from tool_configs.
                pass
        except Exception:
            pass

        # Try constructor tool_configs
        if tool_name in self.tool_configs:
            return self.tool_configs[tool_name]

        # Fall back to server-level defaults
        return ToolGovernanceConfig(
            pii_scan=self._config.default_pii_scan,
            policy_action=(
                self._config.default_policy_action
                if self._config.default_policy_action != "allow"
                else None
            ),
        )

    async def _get_tool_config_async(
        self, tool_name: str, context: MiddlewareContext
    ) -> ToolGovernanceConfig:
        """Resolve per-tool governance config (async version).

        Checks ``@governance`` decorator via ``get_tool()`` which is async in
        FastMCP 3.x.
        """
        # 1. Try @governance decorator on tool function
        try:
            fmcp_ctx = context.fastmcp_context
            if fmcp_ctx is not None:
                fastmcp_inst = fmcp_ctx.fastmcp
                tool = await fastmcp_inst.get_tool(tool_name)
                if tool is not None and hasattr(tool, "fn"):
                    fn = tool.fn
                    gov_config = getattr(fn, "_waxell_governance", None)
                    if isinstance(gov_config, ToolGovernanceConfig):
                        return gov_config
        except Exception as exc:
            logger.debug(
                "GovernanceMiddleware: could not read @governance config "
                "for tool %s: %s -- falling back to tool_configs",
                tool_name,
                exc,
            )

        # 2. Try constructor tool_configs
        if tool_name in self.tool_configs:
            return self.tool_configs[tool_name]

        # 3. Server-level defaults
        return ToolGovernanceConfig(
            pii_scan=self._config.default_pii_scan,
            policy_action=(
                self._config.default_policy_action
                if self._config.default_policy_action != "allow"
                else None
            ),
        )

    # -----------------------------------------------------------------
    # Caller identity extraction
    # -----------------------------------------------------------------

    def _extract_caller_identity(self, context: MiddlewareContext) -> dict:
        """Extract caller identity from FastMCP context.

        Returns a dict with available identity fields. Missing fields are omitted.
        Resilient to stdio transport (no HTTP headers) and missing context fields.
        """
        identity: dict[str, str] = {}

        try:
            fmcp_ctx = context.fastmcp_context
            if fmcp_ctx is None:
                return identity

            # MCP client identity
            client_id = getattr(fmcp_ctx, "client_id", None)
            if client_id:
                identity["client_id"] = str(client_id)

            session_id = getattr(fmcp_ctx, "session_id", None)
            if session_id:
                identity["session_id"] = str(session_id)

            request_id = getattr(fmcp_ctx, "request_id", None)
            if request_id:
                identity["request_id"] = str(request_id)

        except Exception as exc:
            logger.debug(
                "GovernanceMiddleware: caller identity extraction failed: %s", exc
            )

        # Try HTTP headers (available on HTTP/SSE transports, not stdio)
        try:
            from fastmcp.server.dependencies import get_http_headers

            headers = get_http_headers() or {}
            if headers:
                # X-Forwarded-For for IP behind proxies, else direct IP
                ip = headers.get("x-forwarded-for", "").split(",")[0].strip()
                if not ip:
                    ip = headers.get("x-real-ip", "")
                if ip:
                    identity["ip"] = ip

                user_agent = headers.get("user-agent", "")
                if user_agent:
                    identity["user_agent"] = user_agent
        except Exception:
            # stdio transport or headers not available -- expected
            pass

        return identity

    # -----------------------------------------------------------------
    # PII scanning helpers
    # -----------------------------------------------------------------

    def _build_pii_scanner(self, tool_config: ToolGovernanceConfig):
        """Build the PII scanner based on tool config.

        Returns a scanner instance or ``None`` if PII scanning is disabled.
        """
        if tool_config.pii_scan == "none":
            return None

        # Use custom scanner if provided
        if self.pii_scanner is not None:
            return self.pii_scanner

        from ..scanning import RegexPIIScanner

        if tool_config.pii_scan == "strict":
            return RegexPIIScanner(
                actions={
                    "ssn": "block",
                    "credit_card": "block",
                    "email": "block",
                    "phone": "block",
                    "aws_access_key": "block",
                    "aws_secret_key": "block",
                    "api_key": "block",
                    "private_key": "block",
                }
            )

        # Standard mode: warn on all
        return RegexPIIScanner()

    # -----------------------------------------------------------------
    # Main middleware hook
    # -----------------------------------------------------------------

    async def on_call_tool(self, context, call_next):
        """Intercept tool calls with governance pipeline.

        Sections:
        1. Extract tool_name and arguments
        2. Ensure OTel initialized
        3. Create server-side span (independent root trace)
        4. Record caller identity
        5. Get tool-specific config
        6. Rate limit check
        7. Policy check (skip if no controlplane)
        8. PII scan on inputs
        9. Execute tool
        10. PII scan on outputs
        11. Record audit trail
        12. Return result
        """
        from ..tracing._compat import NoOpSpan, _HAS_OTEL, get_tracer
        from ..tracing.attributes import MCPAttributes, WaxellAttributes

        # Section 1: Extract tool_name and arguments
        tool_name = context.message.name
        arguments = context.message.arguments or {}

        # Section 2: Ensure OTel initialized
        self._ensure_initialized()

        # Section 3: Create server-side span (independent root trace)
        span = NoOpSpan()
        try:
            tracer = get_tracer()
            span_attrs = {
                MCPAttributes.TOOL_NAME: tool_name,
                MCPAttributes.SERVER_SIDE: True,
                MCPAttributes.MIDDLEWARE_ACTIVE: True,
                MCPAttributes.METHOD_NAME: "tools/call",
                WaxellAttributes.SPAN_TYPE: "mcp_tool_call",
            }

            if _HAS_OTEL:
                from opentelemetry.trace import SpanKind
                from opentelemetry import context as otel_context

                # Create independent root trace (no propagation from client)
                empty_ctx = otel_context.Context()
                span = tracer.start_span(
                    f"mcp_server/tool {tool_name}",
                    kind=SpanKind.SERVER,
                    attributes=span_attrs,
                    context=empty_ctx,
                )
            else:
                span = tracer.start_span(f"mcp_server/tool {tool_name}")
        except Exception as exc:
            logger.debug("GovernanceMiddleware: span creation failed: %s", exc)

        # Outer try/except for fail-open semantics
        # All governance logic (sections 4-11) is wrapped here
        result_text = ""
        try:
            # Section 4: Record caller identity
            caller = self._extract_caller_identity(context)
            if caller.get("client_id"):
                span.set_attribute(MCPAttributes.CALLER_CLIENT_ID, caller["client_id"])
            if caller.get("session_id"):
                span.set_attribute(
                    MCPAttributes.CALLER_SESSION_ID, caller["session_id"]
                )
            if caller.get("ip"):
                span.set_attribute(MCPAttributes.CALLER_IP, caller["ip"])
            if caller.get("user_agent"):
                span.set_attribute(
                    MCPAttributes.CALLER_USER_AGENT, caller["user_agent"]
                )

            # Section 5: Get tool-specific config
            tool_config = await self._get_tool_config_async(tool_name, context)

            # Section 6: Rate limit check
            if tool_config.rate_limit:
                max_per_minute = tool_config.rate_limit.get("max_per_minute")
                max_per_hour = tool_config.rate_limit.get("max_per_hour")
                allowed, remaining = self._rate_limiter.check(
                    tool_name, max_per_minute, max_per_hour
                )
                if not allowed:
                    span.set_attribute(MCPAttributes.RATE_LIMITED, True)
                    span.set_attribute(MCPAttributes.GOVERNANCE_ACTION, "block")
                    span.set_attribute(MCPAttributes.GOVERNANCE_CHECKED, True)
                    span.set_attribute(
                        MCPAttributes.GOVERNANCE_TIMESTAMP,
                        datetime.now(timezone.utc).isoformat(),
                    )
                    span.end()
                    raise ToolError(f"Rate limit exceeded for tool '{tool_name}'")
                if remaining >= 0:
                    span.set_attribute(MCPAttributes.RATE_LIMIT_REMAINING, remaining)

            # Section 7: Policy check (skip if no controlplane)
            policy_result = None
            if self._has_controlplane:
                try:
                    from ..client import WaxellObserveClient

                    client = WaxellObserveClient(
                        api_key=self.api_key, api_url=self.api_url
                    )
                    policy_id = f"mcp:{tool_name}"
                    policy_result = await client.check_policy(
                        agent_name="",
                        workflow_name=policy_id,
                    )
                    span.set_attribute(
                        MCPAttributes.GOVERNANCE_ACTION, policy_result.action
                    )
                    if policy_result.reason:
                        span.set_attribute(
                            MCPAttributes.POLICY_REASON, policy_result.reason
                        )

                    # Handle policy actions
                    effective_action = policy_result.action
                    if tool_config.policy_action is not None:
                        effective_action = tool_config.policy_action

                    if effective_action == "block":
                        span.set_attribute(MCPAttributes.GOVERNANCE_CHECKED, True)
                        span.set_attribute(
                            MCPAttributes.GOVERNANCE_TIMESTAMP,
                            datetime.now(timezone.utc).isoformat(),
                        )
                        span.end()
                        raise ToolError(
                            f"Blocked by policy: "
                            f"{policy_result.reason or 'policy violation'}"
                        )

                    if effective_action == "warn":
                        logger.warning(
                            "GovernanceMiddleware: policy warning for %s: %s",
                            tool_name,
                            policy_result.reason or "no reason",
                        )

                    if effective_action == "throttle":
                        metadata = getattr(policy_result, "metadata", None) or {}
                        delay = float(metadata.get("throttle_delay_seconds", 1.0))
                        delay = min(delay, 30.0)  # Cap at 30s
                        span.set_attribute(
                            MCPAttributes.THROTTLE_DELAY_MS,
                            int(delay * 1000),
                        )
                        await asyncio.sleep(delay)

                except ToolError:
                    raise  # Let ToolError propagate
                except Exception as exc:
                    logger.warning(
                        "GovernanceMiddleware: policy check failed for %s: %s "
                        "-- allowing (fail-open)",
                        tool_name,
                        exc,
                    )
                    span.set_attribute(MCPAttributes.POLICY_SKIPPED, True)

            # Section 8: PII scan on inputs
            pii_input_result = None
            scanner = self._build_pii_scanner(tool_config)
            if scanner is not None:
                try:
                    from ..scanning import scan_text_for_pii

                    args_text = json.dumps(arguments, default=str)
                    pii_input_result = scan_text_for_pii(args_text, scanner=scanner)

                    if pii_input_result and pii_input_result.get("detected"):
                        span.set_attribute(MCPAttributes.PII_DETECTED, True)
                        span.set_attribute(
                            MCPAttributes.PII_COUNT,
                            pii_input_result.get("count", 0),
                        )
                        span.set_attribute(MCPAttributes.PII_SCAN_DIRECTION, "inputs")

                        # Check for block-level findings
                        findings = pii_input_result.get("findings", [])
                        has_block = any(f.get("action") == "block" for f in findings)
                        if has_block:
                            from ..scanning.scanner import _ACTION_SEVERITY

                            highest_action = max(
                                (f.get("action", "warn") for f in findings),
                                key=lambda a: _ACTION_SEVERITY.get(a, 0),
                            )
                            span.set_attribute(
                                MCPAttributes.PII_ACTION_TAKEN, highest_action
                            )
                            span.set_attribute(MCPAttributes.GOVERNANCE_CHECKED, True)
                            span.set_attribute(
                                MCPAttributes.GOVERNANCE_TIMESTAMP,
                                datetime.now(timezone.utc).isoformat(),
                            )
                            span.end()
                            raise ToolError(
                                "PII detected in tool inputs -- call blocked"
                            )

                        # Record action taken for non-blocking findings
                        if findings:
                            from ..scanning.scanner import _ACTION_SEVERITY

                            highest_action = max(
                                (f.get("action", "warn") for f in findings),
                                key=lambda a: _ACTION_SEVERITY.get(a, 0),
                            )
                            span.set_attribute(
                                MCPAttributes.PII_ACTION_TAKEN, highest_action
                            )

                except ToolError:
                    raise
                except Exception as exc:
                    logger.warning(
                        "GovernanceMiddleware: input PII scan failed for %s: %s "
                        "-- continuing (fail-open)",
                        tool_name,
                        exc,
                    )

            # Section 9: Execute tool via call_next
            result = await call_next(context)

            # Section 10: PII scan on outputs
            pii_output_result = None
            if scanner is not None:
                try:
                    from ..scanning import scan_text_for_pii

                    # Extract text from ToolResult
                    result_text = ""
                    if hasattr(result, "content"):
                        for item in result.content:
                            if hasattr(item, "text"):
                                result_text += item.text + " "
                    if not result_text:
                        result_text = str(result)

                    pii_output_result = scan_text_for_pii(result_text, scanner=scanner)

                    if pii_output_result and pii_output_result.get("detected"):
                        logger.warning(
                            "GovernanceMiddleware: PII detected in output of %s "
                            "(warn only -- tool already executed)",
                            tool_name,
                        )
                        # Update PII scan direction
                        if pii_input_result and pii_input_result.get("detected"):
                            span.set_attribute(MCPAttributes.PII_SCAN_DIRECTION, "both")
                        else:
                            span.set_attribute(MCPAttributes.PII_DETECTED, True)
                            span.set_attribute(
                                MCPAttributes.PII_SCAN_DIRECTION, "outputs"
                            )

                        # Update count to include output findings
                        input_count = (
                            pii_input_result.get("count", 0) if pii_input_result else 0
                        )
                        output_count = pii_output_result.get("count", 0)
                        span.set_attribute(
                            MCPAttributes.PII_COUNT, input_count + output_count
                        )

                except Exception as exc:
                    logger.warning(
                        "GovernanceMiddleware: output PII scan failed for %s: %s",
                        tool_name,
                        exc,
                    )

            # Section 11: Record audit trail
            span.set_attribute(MCPAttributes.GOVERNANCE_CHECKED, True)
            span.set_attribute(
                MCPAttributes.GOVERNANCE_TIMESTAMP,
                datetime.now(timezone.utc).isoformat(),
            )

            if policy_result is not None:
                span.set_attribute(
                    MCPAttributes.GOVERNANCE_ACTION, policy_result.action
                )
            else:
                span.set_attribute(MCPAttributes.GOVERNANCE_ACTION, "allow")

            # Params hash for audit fingerprinting
            if arguments:
                try:
                    params_json = json.dumps(arguments, sort_keys=True, default=str)
                    params_hash = hashlib.sha256(params_json.encode()).hexdigest()[:16]
                    span.set_attribute(MCPAttributes.PARAMS_HASH, params_hash)
                except Exception:
                    pass

            # Section 12: Return result
            return result

        except ToolError:
            # Let ToolError propagate -- this is an intentional block
            raise

        except Exception as exc:
            # Fail-open: governance error should not block the tool call
            if self._config.fail_open:
                logger.warning(
                    "GovernanceMiddleware: governance pipeline failed for %s: %s "
                    "-- executing tool without governance (fail-open)",
                    tool_name,
                    exc,
                )
                try:
                    span.set_attribute(MCPAttributes.POLICY_SKIPPED, True)
                    span.set_attribute(MCPAttributes.GOVERNANCE_CHECKED, False)
                except Exception:
                    pass
                return await call_next(context)
            raise

        finally:
            try:
                span.end()
            except Exception:
                pass
