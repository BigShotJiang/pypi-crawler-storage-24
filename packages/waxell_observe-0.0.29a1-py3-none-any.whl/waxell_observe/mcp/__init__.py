"""MCP server-side governance middleware for FastMCP.

Usage::

    from fastmcp import FastMCP
    from waxell_observe.mcp import GovernanceMiddleware, governance

    mcp = FastMCP("MyServer")
    mcp.add_middleware(GovernanceMiddleware(api_key="wax_sk_..."))

    @governance(approval_required=True)
    @mcp.tool
    async def dangerous_tool(input: str) -> str:
        ...
"""

from .config import MiddlewareConfig, ToolGovernanceConfig
from .decorators import governance
from .middleware import GovernanceMiddleware

__all__ = [
    "GovernanceMiddleware",
    "governance",
    "ToolGovernanceConfig",
    "MiddlewareConfig",
]
