"""OTel span attribute constants.

Uses raw strings instead of the semconv package constants,
since the OpenTelemetry semantic conventions package is beta
and constant names may change.
"""


class GenAIAttributes:
    """OpenTelemetry GenAI semantic convention attributes (gen_ai.*)."""

    OPERATION_NAME = "gen_ai.operation.name"
    PROVIDER_NAME = "gen_ai.provider.name"
    REQUEST_MODEL = "gen_ai.request.model"
    RESPONSE_MODEL = "gen_ai.response.model"
    REQUEST_TEMPERATURE = "gen_ai.request.temperature"
    REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
    USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
    RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons"
    INPUT_MESSAGES = "gen_ai.input.messages"
    OUTPUT_MESSAGES = "gen_ai.output.messages"
    AGENT_NAME = "gen_ai.agent.name"
    AGENT_ID = "gen_ai.agent.id"
    TOOL_NAME = "gen_ai.tool.name"
    TOOL_TYPE = "gen_ai.tool.type"


class WaxellAttributes:
    """Waxell-specific span attributes (waxell.*).

    Aligned with infra's TenantAwareSpanProcessor attributes.
    """

    AGENT_NAME = "waxell.agent_name"
    AGENT_ID = "waxell.agent_id"
    WORKFLOW_NAME = "waxell.workflow_name"
    RUN_ID = "waxell.run_id"
    TOOL = "waxell.tool"
    STEP_NAME = "waxell.step_name"
    STEP_POSITION = "waxell.step_position"
    TENANT_ID = "waxell.tenant_id"
    POLICY_RESULT = "waxell.policy_result"
    SESSION_ID = "waxell.session_id"
    USER_ID = "waxell.user_id"
    USER_GROUP = "waxell.user_group"

    # Span type (required by all Grafana dashboards)
    SPAN_TYPE = "waxell.span_type"

    # LLM attributes (aligned with dashboard TraceQL queries)
    LLM_MODEL = "waxell.llm.model"
    LLM_COST = "waxell.llm.cost"
    LLM_INPUT_TOKENS = "waxell.llm.input_tokens"
    LLM_OUTPUT_TOKENS = "waxell.llm.output_tokens"
    LLM_TOTAL_TOKENS = "waxell.llm.total_tokens"

    # Embedding attributes
    EMBEDDING_MODEL = "waxell.embedding.model"
    EMBEDDING_DIMENSIONS = "waxell.embedding.dimensions"
    EMBEDDING_INPUT_TOKENS = "waxell.embedding.input_tokens"
    EMBEDDING_INPUT_COUNT = "waxell.embedding.input_count"
    EMBEDDING_COST = "waxell.embedding.cost"

    # Guardrail attributes
    GUARDRAIL_NAME = "waxell.guardrail.name"
    GUARDRAIL_PASSED = "waxell.guardrail.passed"
    GUARDRAIL_ACTION = "waxell.guardrail.action"

    # Evaluation attributes
    EVAL_FRAMEWORK = "waxell.eval.framework"
    EVAL_METRIC_NAME = "waxell.eval.metric_name"
    EVAL_SCORE = "waxell.eval.score"
    EVAL_THRESHOLD = "waxell.eval.threshold"
    EVAL_PASSED = "waxell.eval.passed"
    EVAL_REASON = "waxell.eval.reason"
    EVAL_TEST_CASES_COUNT = "waxell.eval.test_cases_count"
    EVAL_METRICS_COUNT = "waxell.eval.metrics_count"
    EVAL_PASS_RATE = "waxell.eval.pass_rate"

    # Approval lifecycle attributes
    APPROVAL_ACTION_TYPE = "waxell.approval.action_type"
    APPROVAL_PHASE = "waxell.approval.phase"
    APPROVAL_APPROVER = "waxell.approval.approver"
    APPROVAL_ELAPSED_SECONDS = "waxell.approval.elapsed_seconds"

    # Custom tag/metadata prefixes (for user-defined searchable attributes)
    TAG_PREFIX = "waxell.tag."
    META_PREFIX = "waxell.meta."


class MCPAttributes:
    """MCP-specific span attributes.

    Combines OTel MCP semantic conventions (mcp.*) with
    waxell-specific attributes (waxell.mcp.*).
    """

    # OTel MCP semantic conventions
    METHOD_NAME = "mcp.method.name"  # e.g., "tools/call"
    SESSION_ID = "mcp.session.id"  # MCP session identifier
    # Network transport (OTel convention)
    NETWORK_TRANSPORT = "network.transport"  # "stdio", "sse", "http"

    # Waxell-specific MCP attributes
    SERVER_NAME = "waxell.mcp.server_name"  # e.g., "composio"
    TOOL_NAME = "waxell.mcp.tool_name"  # e.g., "search_documents"
    TRANSPORT = (
        "waxell.mcp.transport"  # same as network.transport but waxell-namespaced
    )
    POLICY_ID = (
        "waxell.mcp.policy_id"  # "mcp:{server}:{tool}" for Phase 2 policy matching
    )
    ARGUMENTS = "waxell.mcp.arguments"  # JSON string of tool arguments (truncated 4KB)
    RESULT = "waxell.mcp.result"  # JSON string of tool result (truncated 4KB)
    IS_ERROR = "waxell.mcp.is_error"  # bool
    ERROR_TYPE = "waxell.mcp.error_type"  # "transport_error", "server_error", "timeout", "tool_execution_error"
    CONTENT_COUNT = "waxell.mcp.content_count"  # number of content items in result
    TIMEOUT_MS = "waxell.mcp.timeout_ms"  # configured timeout in milliseconds

    # -- Governance: Policy attributes --
    GOVERNANCE_CHECKED = (
        "waxell.mcp.governance_checked"  # bool, True if policy was checked
    )
    GOVERNANCE_ACTION = (
        "waxell.mcp.governance_action"  # string: "allow", "block", "warn", "throttle"
    )
    POLICY_SKIPPED = "waxell.mcp.policy_skipped"  # bool, True if policy check was skipped (controlplane unreachable)
    POLICY_REASON = (
        "waxell.mcp.policy_reason"  # string, human-readable reason from policy engine
    )
    POLICY_RULE_IDS = (
        "waxell.mcp.policy_rule_ids"  # string, comma-separated IDs of matched rules
    )
    THROTTLE_DELAY_MS = (
        "waxell.mcp.throttle_delay_ms"  # int, throttle delay applied in milliseconds
    )

    # -- Governance: Approval attributes --
    APPROVAL_STATUS = "waxell.mcp.approval_status"  # string: "approved", "denied", "timeout", "not_required"
    APPROVAL_APPROVER = "waxell.mcp.approval_approver"  # string, who approved
    APPROVAL_ELAPSED_MS = (
        "waxell.mcp.approval_elapsed_ms"  # int, time spent waiting for approval
    )

    # -- Governance: PII scan attributes --
    PII_DETECTED = "waxell.mcp.pii_detected"  # bool, True if any PII/credentials found
    PII_COUNT = "waxell.mcp.pii_count"  # int, number of PII findings
    PII_SCAN_DIRECTION = (
        "waxell.mcp.pii_scan_direction"  # string: "inputs", "outputs", "both"
    )
    PII_ACTION_TAKEN = "waxell.mcp.pii_action_taken"  # string: "warn", "block", "redact" (highest severity)

    # -- Governance: Audit attributes --
    GOVERNANCE_TIMESTAMP = (
        "waxell.mcp.governance_timestamp"  # string, ISO 8601 timestamp
    )
    AUDIT_AGENT = "waxell.mcp.audit_agent"  # string, agent name that initiated the call
    AUDIT_USER = "waxell.mcp.audit_user"  # string, user ID if available
    PARAMS_HASH = "waxell.mcp.params_hash"  # string, SHA256 hash of tool arguments (truncated to 16 chars)
    BLOCKED_SYNTHETIC = "waxell.mcp.blocked_synthetic"  # bool, True if block returned synthetic CallToolResult

    # -- Security: Server identity attributes --
    SERVER_VERSION = (
        "waxell.mcp.server_version"  # string, server version from initialize response
    )
    SERVER_CAPABILITIES = (
        "waxell.mcp.server_capabilities"  # JSON string of server capabilities
    )
    SERVER_CONNECTION = (
        "waxell.mcp.server_connection"  # string, URL or command used to connect
    )
    SERVER_VERSION_CHANGED = "waxell.mcp.server_version_changed"  # bool, True if version differs from last session

    # -- Security: Fingerprint attributes --
    FINGERPRINT_HASH = "waxell.mcp.fingerprint_hash"  # string, current tool SHA256 hash
    FINGERPRINT_STATUS = "waxell.mcp.fingerprint_status"  # string: "match", "changed", "new", "first_observation", "skipped"
    FINGERPRINT_SKIPPED = (
        "waxell.mcp.fingerprint_skipped"  # bool, True if capture failed or disabled
    )
    FINGERPRINT_TOOL_COUNT = (
        "waxell.mcp.fingerprint_tool_count"  # int, number of tools observed
    )
    FINGERPRINT_CHANGES_DETECTED = (
        "waxell.mcp.fingerprint_changes_detected"  # int, number of changes found
    )
    FINGERPRINT_DIFF = (
        "waxell.mcp.fingerprint_diff"  # string, unified diff text, truncated to 2KB
    )

    # -- Security: Tool set integrity --
    TOOLS_ADDED = "waxell.mcp.tools_added"  # string, comma-separated names of new tools
    TOOLS_REMOVED = (
        "waxell.mcp.tools_removed"  # string, comma-separated names of removed tools
    )

    # -- Server-side middleware attributes --
    MIDDLEWARE_ACTIVE = "waxell.mcp.middleware_active"  # bool, True when governance middleware is processing
    SERVER_SIDE = "waxell.mcp.server_side"  # bool, True for server-side middleware spans (vs client-side)
    CALLER_CLIENT_ID = (
        "waxell.mcp.caller_client_id"  # string, MCP client_id from initialize
    )
    CALLER_SESSION_ID = "waxell.mcp.caller_session_id"  # string, MCP session ID
    CALLER_API_KEY_HASH = "waxell.mcp.caller_api_key_hash"  # string, SHA256 hash (first 8 chars) of caller's API key
    CALLER_IP = (
        "waxell.mcp.caller_ip"  # string, caller IP from HTTP headers (when available)
    )
    CALLER_USER_AGENT = (
        "waxell.mcp.caller_user_agent"  # string, user-agent header (when available)
    )
    RATE_LIMITED = "waxell.mcp.rate_limited"  # bool, True if rate limit was exceeded
    RATE_LIMIT_REMAINING = (
        "waxell.mcp.rate_limit_remaining"  # int, remaining calls in window
    )
