from splent_framework.fixtures.fixtures import *
