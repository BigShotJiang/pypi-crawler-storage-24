# Copyright 2020, castLabs GmbH

__version__ = '1.3.2'
