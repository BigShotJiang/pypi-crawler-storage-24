```{include} ../manuals/METRICS.md
```
