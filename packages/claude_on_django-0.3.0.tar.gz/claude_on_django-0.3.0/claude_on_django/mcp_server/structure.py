import os
import re
from typing import List, Optional
from pydantic import BaseModel, Field
import msgspec


class MCPMetadata(msgspec.Struct):
    project_name: str
    api_registrations: List[str]
    doc_paths: List[str]


class MCPResource(BaseModel):
    uri: str
    name: str
    description: Optional[str] = None


class MCPServerStructure:
    """
    Structure for an MCP server that gives agents real-time access
    to Django technical documentation and the project's API metadata.
    """

    def __init__(self, metadata: Optional[MCPMetadata] = None):
        self.metadata = metadata
        self.resources: List[MCPResource] = []

    def register_resource(self, resource: MCPResource):
        self.resources.append(resource)

    async def get_resource_content(self, uri: str) -> str:
        """Fetch content from the provided URI."""
        pass

    async def scan_api_metadata(self) -> List[str]:
        """
        Parse api.py / urls.py to extract registered endpoints.
        Returns a list of registered endpoints/metadata.
        """
        registrations = []

        # Scan for DRF router registrations and URL patterns
        for filename in ['urls.py', 'api.py']:
            api_file = os.path.join(os.getcwd(), 'app', filename)
            if os.path.exists(api_file):
                with open(api_file, 'r') as f:
                    content = f.read()

                # DRF router registrations
                router_matches = re.findall(
                    r"router\.register\(['\"]([^'\"]+)['\"]",
                    content,
                )
                for path in router_matches:
                    registrations.append(f"CRUD /{path}/")

                # URL path patterns
                path_matches = re.findall(
                    r"path\(['\"]([^'\"]+)['\"]",
                    content,
                )
                for path in path_matches:
                    registrations.append(f"ENDPOINT /{path}")

                # Bolt-style router decorators
                bolt_matches = re.findall(
                    r'@router\.(get|post|put|delete|patch)\(["\']([^"\']+)["\']',
                    content,
                )
                for method, path in bolt_matches:
                    registrations.append(f"{method.upper()} {path}")

        return registrations or (self.metadata.api_registrations if self.metadata else [])
