import shutil
import subprocess
from typing import Optional


class MCPSupport:
    """
    Support module for Django MCP Server integration.
    Ported from claude-on-rails MCPSupport.
    """

    @staticmethod
    def available() -> bool:
        return shutil.which("django-mcp-server") is not None

    @staticmethod
    def server_config(django_env: str = "development") -> dict:
        return {
            "name": "django",
            "type": "stdio",
            "command": "django-mcp-server",
            "args": [],
            "env": {"DJANGO_ENV": django_env},
        }

    @staticmethod
    def available_resources() -> list:
        return ["django", "drf", "celery", "channels"]

    @staticmethod
    def downloaded_resources() -> list:
        if MCPSupport.available():
            return MCPSupport.available_resources()
        return []

    @staticmethod
    def installation_instructions() -> list:
        instructions = []
        if not MCPSupport.available():
            instructions.append("Install Django MCP Server:")
            instructions.append("  pip install django-mcp-server")
            instructions.append("")
        return instructions


class MCPInstaller:
    """
    Interactive installer for Django MCP Server.
    Ported from claude-on-rails MCPInstaller.
    """

    def run(self):
        print("Claude-on-Django MCP Server Setup")
        print("=" * 50)

        if MCPSupport.available():
            print("Django MCP Server is already installed")
        else:
            self._handle_installation()

        print("\nSetup complete!")
        self._show_next_steps()

    def _handle_installation(self):
        print("\nDjango MCP Server provides your AI agents with:")
        print("  - Real-time Django documentation access")
        print("  - Version-specific API references")
        print("  - Framework guides (DRF, Celery, Channels)")
        print("  - Best practices and examples")

        response = input("\nWould you like to install Django MCP Server? (Y/n) ").strip().lower()
        if response in ("", "y", "yes"):
            self._install()
        else:
            print("\nSkipping installation.")
            print("You can run 'python manage.py setup_mcp' later to set it up.")

    def _install(self):
        print("\nInstalling Django MCP Server...")
        result = subprocess.run(
            ["pip", "install", "django-mcp-server"],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            print("Django MCP Server installed successfully!")
        else:
            print("Failed to install Django MCP Server")
            print("Please try running manually:")
            print("  pip install django-mcp-server")

    def _show_next_steps(self):
        print("\nNext steps:")
        if MCPSupport.available():
            print("1. Run the swarm generator to update your configuration:")
            print("   python manage.py claude_swarm_init")
            print("\n2. Start your enhanced Django development swarm")
        else:
            print("1. Complete the MCP Server setup when ready:")
            print("   python manage.py setup_mcp")
            print("\n2. Then run the swarm generator:")
            print("   python manage.py claude_swarm_init")
