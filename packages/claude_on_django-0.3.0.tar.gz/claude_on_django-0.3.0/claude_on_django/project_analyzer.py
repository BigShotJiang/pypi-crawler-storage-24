import os
from typing import Optional
from pydantic import BaseModel


class ProjectAnalysis(BaseModel):
    api_only: bool = False
    test_framework: Optional[str] = None
    has_drf: bool = False
    has_bolt: bool = False
    has_graphql: bool = False
    has_htmx: bool = False
    has_celery: bool = False
    has_channels: bool = False
    database: str = "sqlite3"
    deployment: str = "unknown"
    custom_patterns: dict = {}
    python_version: Optional[str] = None
    django_version: Optional[str] = None


class ProjectAnalyzer:
    """
    Analyzes a Django project structure to detect features,
    patterns, and configuration for intelligent agent topology.
    Ported from claude-on-rails ProjectAnalyzer.
    """

    def __init__(self, root_path: str):
        self.root_path = root_path

    def analyze(self) -> ProjectAnalysis:
        return ProjectAnalysis(
            api_only=self._api_only(),
            test_framework=self._detect_test_framework(),
            has_drf=self._has_drf(),
            has_bolt=self._has_bolt(),
            has_graphql=self._has_graphql(),
            has_htmx=self._has_htmx(),
            has_celery=self._has_celery(),
            has_channels=self._has_channels(),
            database=self._detect_database(),
            deployment=self._detect_deployment(),
            custom_patterns=self._detect_custom_patterns(),
            python_version=self._detect_python_version(),
            django_version=self._detect_django_version(),
        )

    def _api_only(self) -> bool:
        """Check if project is API-only (no templates directory or DRF-only)."""
        templates_dir = os.path.join(self.root_path, "templates")
        app_templates = any(
            os.path.isdir(os.path.join(self.root_path, d, "templates"))
            for d in os.listdir(self.root_path)
            if os.path.isdir(os.path.join(self.root_path, d))
            and not d.startswith(".")
        )
        return not os.path.isdir(templates_dir) and not app_templates

    def _detect_test_framework(self) -> Optional[str]:
        if os.path.exists(os.path.join(self.root_path, "pytest.ini")) or \
           os.path.exists(os.path.join(self.root_path, "pyproject.toml")):
            pyproject = os.path.join(self.root_path, "pyproject.toml")
            if os.path.exists(pyproject):
                with open(pyproject) as f:
                    if "pytest" in f.read():
                        return "pytest"
        if os.path.exists(os.path.join(self.root_path, "conftest.py")):
            return "pytest"
        if any(
            os.path.exists(os.path.join(self.root_path, d, "tests.py"))
            for d in os.listdir(self.root_path)
            if os.path.isdir(os.path.join(self.root_path, d))
        ):
            return "django"
        return None

    def _has_drf(self) -> bool:
        return self._in_requirements("djangorestframework") or \
               self._in_installed_apps("rest_framework")

    def _has_bolt(self) -> bool:
        return self._in_requirements("django-bolt") or \
               self._in_installed_apps("django_bolt")

    def _has_graphql(self) -> bool:
        return self._in_requirements("graphene-django") or \
               self._in_requirements("strawberry-graphql")

    def _has_htmx(self) -> bool:
        return self._in_requirements("django-htmx")

    def _has_celery(self) -> bool:
        return self._in_requirements("celery") or \
               os.path.exists(os.path.join(self.root_path, "celery.py"))

    def _has_channels(self) -> bool:
        return self._in_requirements("channels")

    def _detect_database(self) -> str:
        settings_files = self._find_settings_files()
        for sf in settings_files:
            try:
                with open(sf) as f:
                    content = f.read()
                    if "postgresql" in content or "psycopg" in content:
                        return "postgresql"
                    elif "mysql" in content:
                        return "mysql"
                    elif "sqlite3" in content:
                        return "sqlite3"
            except (IOError, OSError):
                continue
        return "sqlite3"

    def _detect_deployment(self) -> str:
        if os.path.exists(os.path.join(self.root_path, "k8s")) or \
           os.path.exists(os.path.join(self.root_path, "kubernetes")):
            return "kubernetes"
        if os.path.exists(os.path.join(self.root_path, "Dockerfile")):
            return "docker"
        if os.path.exists(os.path.join(self.root_path, "Procfile")):
            return "heroku"
        if os.path.exists(os.path.join(self.root_path, "fly.toml")):
            return "fly"
        if os.path.exists(os.path.join(self.root_path, "app.yaml")):
            return "gcloud"
        return "unknown"

    def _detect_custom_patterns(self) -> dict:
        patterns = {}
        pattern_dirs = {
            "has_services": "services",
            "has_forms": "forms",
            "has_serializers": "serializers",
            "has_permissions": "permissions",
            "has_middleware": "middleware",
            "has_signals": "signals",
            "has_tasks": "tasks",
            "has_management_commands": os.path.join("management", "commands"),
        }
        for key, dirname in pattern_dirs.items():
            for d in os.listdir(self.root_path):
                full = os.path.join(self.root_path, d, dirname)
                if os.path.isdir(full):
                    patterns[key] = True
                    break
        return patterns

    def _detect_python_version(self) -> Optional[str]:
        runtime = os.path.join(self.root_path, "runtime.txt")
        if os.path.exists(runtime):
            with open(runtime) as f:
                return f.read().strip()
        return None

    def _detect_django_version(self) -> Optional[str]:
        try:
            import django
            return django.get_version()
        except ImportError:
            return None

    def _in_requirements(self, package: str) -> bool:
        """Check if a package is in requirements files or pyproject.toml."""
        req_files = [
            os.path.join(self.root_path, "requirements.txt"),
            os.path.join(self.root_path, "requirements", "base.txt"),
            os.path.join(self.root_path, "pyproject.toml"),
            os.path.join(self.root_path, "Pipfile"),
        ]
        for rf in req_files:
            if os.path.exists(rf):
                try:
                    with open(rf) as f:
                        if package in f.read():
                            return True
                except (IOError, OSError):
                    continue
        return False

    def _in_installed_apps(self, app_name: str) -> bool:
        """Check if an app is in INSTALLED_APPS in settings."""
        for sf in self._find_settings_files():
            try:
                with open(sf) as f:
                    if app_name in f.read():
                        return True
            except (IOError, OSError):
                continue
        return False

    def _find_settings_files(self) -> list:
        """Find Django settings files in the project."""
        candidates = []
        for root, dirs, files in os.walk(self.root_path):
            # Skip hidden dirs and common non-project dirs
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("node_modules", "__pycache__", ".venv", "venv")]
            for f in files:
                if f == "settings.py" or (f.endswith(".py") and "settings" in root):
                    candidates.append(os.path.join(root, f))
        return candidates
