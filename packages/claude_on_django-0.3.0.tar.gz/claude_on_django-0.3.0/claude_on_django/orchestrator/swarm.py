import os
from typing import List, Optional, Any, Dict
from pydantic import BaseModel, Field
from pydantic_ai import Agent
import msgspec

from ..configuration import get_configuration, Configuration


class MessageSchema(msgspec.Struct):
    role: str
    content: str


class SwarmConfig(BaseModel):
    agent_teams_enabled: bool = Field(default=True)
    max_parallel_agents: int = 5


class AgentDefinition(BaseModel):
    name: str
    role: str
    system_prompt_path: str
    specialized_tools: List[str] = []


class SwarmOrchestrator:
    """
    Orchestration Engine for Claude-on-Django.
    Manages specialized subagents defined in .claude/agents/.
    Utilizes PydanticAI for agent definition and execution.
    """

    ROLES = [
        'architect', 'modeler', 'api_specialist', 'views',
        'services', 'qa_engineer', 'devops', 'tasks',
    ]

    def __init__(self, config: Optional[SwarmConfig] = None):
        self.config = config or SwarmConfig()
        self.agents: Dict[str, Agent] = {}
        self._initialize_agents()

    def _initialize_agents(self):
        """
        Dynamically loads agent configurations.
        Priority:
        1. .claude/agents/ (Project-specific)
        2. .claude-on-django/prompts/ (Project-generated)
        3. claude_on_django/agents/ (Package defaults)
        """
        app_config = get_configuration()
        model_name = app_config.default_model

        # Determine directories
        try:
            from django.conf import settings
            base_dir = getattr(settings, 'BASE_DIR', os.getcwd())
        except Exception:
            base_dir = os.getcwd()

        project_agents_dir = os.path.join(base_dir, '.claude', 'agents')
        generated_prompts_dir = os.path.join(base_dir, '.claude-on-django', 'prompts')

        import claude_on_django
        package_dir = os.path.dirname(claude_on_django.__file__)
        package_agents_dir = os.path.join(package_dir, 'agents')

        for role in self.ROLES:
            prompt = f"You are the {role.replace('_', ' ').title()} for Claude-on-Django."

            # 1. Project-specific (.claude/agents/)
            for search_dir in [project_agents_dir, generated_prompts_dir, package_agents_dir]:
                prompt_path = os.path.join(search_dir, f"{role}.md")
                if os.path.exists(prompt_path):
                    with open(prompt_path, 'r') as f:
                        prompt = f.read()
                    break

            self.agents[role] = Agent(
                model_name,
                system_prompt=prompt,
                model_settings={'max_tokens': 8192},
            )

    async def spawn_team(self, task: str, folders: List[str]) -> Any:
        """
        Spawn parallel teammates for multi-folder tasks.
        Leverages CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS.
        """
        if not self.config.agent_teams_enabled:
            return await self.run_task(task, "architect")

        results = []
        for folder in folders:
            subtask = f"Handle {task} specifically for files in {folder}"
            results.append(f"Team member spawned for {folder} to handle: {subtask}")
        return results

    async def run_task(self, task_description: str, agent_name: str) -> str:
        """Runs a specific task using a specialized agent."""
        if agent_name not in self.agents:
            raise ValueError(f"Agent '{agent_name}' not found. Available: {list(self.agents.keys())}")

        agent = self.agents[agent_name]
        try:
            result = await agent.run(task_description)
            if hasattr(result, 'data') and result.data is not None:
                if isinstance(result.data, str):
                    return result.data
                return str(result.data)

            res_str = str(result)
            if "AgentRunResult(output='" in res_str:
                import re
                match = re.search(r"AgentRunResult\(output='(.*?)'\)", res_str)
                if match:
                    return match.group(1)
            return res_str
        except Exception as e:
            return f"# Error running task with {agent_name}: {str(e)}"
