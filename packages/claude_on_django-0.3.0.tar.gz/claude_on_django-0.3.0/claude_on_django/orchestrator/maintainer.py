import datetime

class ClaudeMDMaintainer:
    """
    Automated CLAUDE.md maintainer that updates the project status
    and architectural decisions after every successful swarm run.
    """
    def __init__(self, file_path: str = "CLAUDE.md"):
        self.file_path = file_path

    def record_run(self, task: str, decision: str):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"\n### Run: {timestamp}\n- **Task**: {task}\n- **Decisions**: {decision}\n"

        with open(self.file_path, "a") as f:
            f.write(entry)

    def update_project_status(self, status: str):
        """
        Updates the primary project status description in CLAUDE.md.
        """
        with open(self.file_path, "r") as f:
            lines = f.readlines()

        new_lines = []
        in_status = False
        status_updated = False

        for line in lines:
            if line.startswith("## Current Status") or line.startswith("## Project Status"):
                in_status = True
                new_lines.append(line)
                new_lines.append(f"{status}\n")
                status_updated = True
                continue

            if in_status:
                if line.startswith("## "):
                    in_status = False
                    new_lines.append(line)
                # Skip other lines in the status section
                continue

            new_lines.append(line)

        if not status_updated:
            new_lines.append(f"\n## Project Status\n{status}\n")

        with open(self.file_path, "w") as f:
            f.writelines(new_lines)
