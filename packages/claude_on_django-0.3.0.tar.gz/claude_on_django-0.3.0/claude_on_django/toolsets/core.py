import os
import subprocess
from typing import List, Optional
import msgspec

class ToolOutput(msgspec.Struct):
    success: bool
    output: str
    error: Optional[str] = None

class FilesystemToolset:
    """Read/Write/Grep operations for Python and Rust files."""

    def read_file(self, path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    def write_file(self, path: str, content: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            f.write(content)

    def grep(self, pattern: str, directory: str = ".") -> str:
        try:
            result = subprocess.run(
                ["grep", "-rnE", pattern, directory],
                capture_output=True, text=True, check=False
            )
            return result.stdout
        except Exception as e:
            return str(e)

class BoltCommandToolset:
    """Execute Django-Bolt ecosystem commands."""

    def run_bolt(self) -> ToolOutput:
        return self._run_command(["python", "manage.py", "runbolt"])

    def build(self) -> ToolOutput:
        return self._run_command(["just", "build"])

    def test(self) -> ToolOutput:
        return self._run_command(["pytest"])

    def migrate(self) -> ToolOutput:
        return self._run_command(["python", "manage.py", "migrate"])

    def makemigrations(self) -> ToolOutput:
        return self._run_command(["python", "manage.py", "makemigrations"])

    def create_superuser(self, username: str, email: str) -> ToolOutput:
        return self._run_command(["python", "manage.py", "createsuperuser", "--noinput", "--username", username, "--email", email])

    def _run_command(self, cmd: List[str]) -> ToolOutput:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
            return ToolOutput(
                success=result.returncode == 0,
                output=result.stdout,
                error=result.stderr if result.returncode != 0 else None
            )
        except Exception as e:
            return ToolOutput(success=False, output="", error=str(e))
