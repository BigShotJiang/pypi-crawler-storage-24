#!/usr/bin/env python3
"""
Standalone CLI for django-generate.

Usage after pip install:
    django-generate
    django-generate --project-name MyApp --app-name myapp --item-name ticket
    django-generate --no-input --path ./myproject
"""
import os
import sys


def main():
    """Entry point for the django-generate console script."""
    # Bootstrap Django with minimal in-memory configuration
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', '__claude_on_django_cli__')

    import django
    from django.conf import settings

    if not settings.configured:
        settings.configure(
            INSTALLED_APPS=['claude_on_django'],
            DATABASES={'default': {
                'ENGINE': 'django.db.backends.sqlite3',
                'NAME': ':memory:',
            }},
            DEFAULT_AUTO_FIELD='django.db.models.BigAutoField',
        )
        django.setup()

    from django.core.management import call_command

    # Forward all CLI args to the management command
    argv = sys.argv[1:]
    call_command('claude_generate', *argv)


if __name__ == '__main__':
    main()
