import os
from pydantic import BaseModel, Field


class Configuration(BaseModel):
    """
    Global configuration for Claude-on-Django.
    Ported from claude-on-rails Configuration.
    """
    default_model: str = Field(
        default_factory=lambda: os.getenv("CLAUDE_ON_DJANGO_MODEL", "anthropic:claude-sonnet-4-6")
    )
    vibe_mode: bool = True
    session_directory: str = ".claude-on-django/sessions"
    log_directory: str = ".claude-on-django/logs"
    agent_teams_enabled: bool = Field(
        default_factory=lambda: bool(os.getenv("CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS"))
    )
    max_parallel_agents: int = 5


# Singleton configuration
_configuration = None


def get_configuration() -> Configuration:
    global _configuration
    if _configuration is None:
        _configuration = Configuration()
    return _configuration


def configure(**kwargs) -> Configuration:
    global _configuration
    _configuration = Configuration(**kwargs)
    return _configuration
