from typing import Any

from .configuration import get_configuration
from .project_analyzer import ProjectAnalysis


class SwarmBuilder:
    """
    Generates agent topology based on project analysis.
    Ported from claude-on-rails SwarmBuilder.
    """

    def __init__(self, project_analysis: ProjectAnalysis):
        self.analysis = project_analysis

    def build(self) -> dict:
        return {
            "version": 1,
            "swarm": {
                "name": "Django Development Team",
                "main": "architect",
                "instances": self._build_instances(),
            },
        }

    def _build_instances(self) -> dict:
        config = get_configuration()
        instances = {}

        # Always include architect
        instances["architect"] = self._build_architect(config)

        # Core agents
        instances["modeler"] = {
            "description": "Django models, migrations, and database optimization specialist",
            "directory": ".",
            "model": config.default_model,
            "allowed_tools": ["Read", "Edit", "Write", "Bash", "Grep", "Glob"],
            "prompt_file": ".claude-on-django/prompts/modeler.md",
        }

        instances["api_specialist"] = {
            "description": "REST API design, serialization, JWT/OAuth, and endpoint optimization specialist",
            "directory": ".",
            "model": config.default_model,
            "allowed_tools": ["Read", "Edit", "Write", "Bash", "Grep", "Glob"],
            "prompt_file": ".claude-on-django/prompts/api_specialist.md",
        }

        # Conditional agents
        if not self.analysis.api_only:
            instances["views"] = {
                "description": "Django views, templates, and UI components specialist",
                "directory": ".",
                "model": config.default_model,
                "allowed_tools": ["Read", "Edit", "Write", "Bash", "Grep", "Glob"],
                "prompt_file": ".claude-on-django/prompts/views.md",
            }

        if self.analysis.has_graphql:
            instances["graphql"] = {
                "description": "GraphQL schema, resolvers, and mutations specialist",
                "directory": ".",
                "model": config.default_model,
                "allowed_tools": ["Read", "Edit", "Write", "Bash", "Grep", "Glob"],
                "prompt_file": ".claude-on-django/prompts/graphql.md",
            }

        # Supporting agents
        instances["services"] = {
            "description": "Service objects, business logic, and design patterns specialist",
            "directory": ".",
            "model": config.default_model,
            "allowed_tools": ["Read", "Edit", "Write", "Bash", "Grep", "Glob"],
            "prompt_file": ".claude-on-django/prompts/services.md",
        }

        if self.analysis.has_celery:
            instances["tasks"] = {
                "description": "Celery tasks, async processing, and background jobs specialist",
                "directory": ".",
                "model": config.default_model,
                "allowed_tools": ["Read", "Edit", "Write", "Bash", "Grep", "Glob"],
                "prompt_file": ".claude-on-django/prompts/tasks.md",
            }

        instances["qa_engineer"] = {
            "description": f"{self.analysis.test_framework or 'pytest'} testing, fixtures, and test coverage specialist",
            "directory": ".",
            "model": config.default_model,
            "allowed_tools": ["Read", "Edit", "Write", "Bash", "Grep", "Glob"],
            "prompt_file": ".claude-on-django/prompts/qa_engineer.md",
        }

        instances["devops"] = {
            "description": "Deployment, Docker, CI/CD, and production configuration specialist",
            "directory": ".",
            "model": config.default_model,
            "allowed_tools": ["Read", "Edit", "Write", "Bash", "Grep", "Glob"],
            "prompt_file": ".claude-on-django/prompts/devops.md",
        }

        return instances

    def _build_architect(self, config: Any) -> dict:
        connections = ["modeler", "api_specialist"]
        if not self.analysis.api_only:
            connections.append("views")
        if self.analysis.has_graphql:
            connections.append("graphql")
        connections.append("services")
        if self.analysis.has_celery:
            connections.append("tasks")
        connections.append("qa_engineer")
        connections.append("devops")

        project_type = "API" if self.analysis.api_only else "full-stack"
        return {
            "description": f"Django architect coordinating {project_type} development",
            "directory": ".",
            "model": config.default_model,
            "connections": connections,
            "prompt_file": ".claude-on-django/prompts/architect.md",
            "vibe": config.vibe_mode,
        }
