import os
from django.core.management.base import BaseCommand
from django.conf import settings

from claude_on_django.project_analyzer import ProjectAnalyzer
from claude_on_django.swarm_builder import SwarmBuilder
from claude_on_django.mcp_server.support import MCPSupport


class Command(BaseCommand):
    help = 'Analyzes the Django project and generates .claude-on-django/ configuration with agent prompts.'

    def add_arguments(self, parser):
        parser.add_argument('--api-only', action='store_true', help='Force API-only mode')
        parser.add_argument('--skip-tests', action='store_true', help='Skip test agent')
        parser.add_argument('--skip-mcp', action='store_true', help='Skip MCP server setup')

    def handle(self, *args, **options):
        base_dir = getattr(settings, 'BASE_DIR', os.getcwd())

        # --- 1. Analyze project ---
        self.stdout.write(self.style.NOTICE("Analyzing Django project structure..."))
        analyzer = ProjectAnalyzer(str(base_dir))
        analysis = analyzer.analyze()

        if options.get('api_only'):
            analysis.api_only = True

        self.stdout.write(f"  Project type: {'API-only' if analysis.api_only else 'Full-stack Django'}")
        self.stdout.write(f"  Test framework: {analysis.test_framework or 'not detected'}")
        self.stdout.write(f"  Database: {analysis.database}")
        self.stdout.write(f"  DRF: {'Yes' if analysis.has_drf else 'No'}")
        self.stdout.write(f"  Django-Bolt: {'Yes' if analysis.has_bolt else 'No'}")
        self.stdout.write(f"  GraphQL: {'Yes' if analysis.has_graphql else 'No'}")
        self.stdout.write(f"  Celery: {'Yes' if analysis.has_celery else 'No'}")
        self.stdout.write(f"  Deployment: {analysis.deployment}")
        self.stdout.write(f"  MCP Server: {'Available' if MCPSupport.available() else 'Not available'}")

        # --- 2. Create directory structure ---
        claude_dir = os.path.join(base_dir, '.claude-on-django')
        prompts_dir = os.path.join(claude_dir, 'prompts')
        sessions_dir = os.path.join(claude_dir, 'sessions')
        os.makedirs(prompts_dir, exist_ok=True)
        os.makedirs(sessions_dir, exist_ok=True)

        # --- 3. Generate agent prompts ---
        self.stdout.write(self.style.NOTICE("\nGenerating agent prompts..."))
        self._create_agent_prompts(prompts_dir, analysis)

        # --- 4. Generate swarm config ---
        self.stdout.write(self.style.NOTICE("\nBuilding swarm topology..."))
        builder = SwarmBuilder(analysis)
        swarm_config = builder.build()

        agents = list(swarm_config['swarm']['instances'].keys())
        self.stdout.write("  Agents: " + ", ".join(agents))

        # --- 5. Create context.md ---
        context_path = os.path.join(claude_dir, 'context.md')
        self._write_context(context_path, analysis)
        self.stdout.write(self.style.SUCCESS(f"  Created {context_path}"))

        # --- 6. Update CLAUDE.md ---
        claude_md = os.path.join(base_dir, 'CLAUDE.md')
        if os.path.exists(claude_md):
            with open(claude_md) as f:
                content = f.read()
            if '.claude-on-django/context.md' not in content:
                with open(claude_md, 'a') as f:
                    f.write("\n/file:.claude-on-django/context.md\n")
                self.stdout.write(self.style.SUCCESS("  Added context reference to existing CLAUDE.md"))
        else:
            with open(claude_md, 'w') as f:
                f.write("# Claude-on-Django Project\n\n")
                f.write("## Architecture\n")
                f.write("- SwarmOrchestrator based on PydanticAI\n")
                f.write("- Django-Bolt ecosystem\n\n")
                f.write("/file:.claude-on-django/context.md\n")
            self.stdout.write(self.style.SUCCESS(f"  Created {claude_md}"))

        # --- 7. Update .gitignore ---
        gitignore = os.path.join(base_dir, '.gitignore')
        ignore_entries = "\n# Claude-on-Django\n.claude-on-django/sessions/\n"
        if os.path.exists(gitignore):
            with open(gitignore) as f:
                existing = f.read()
            if '.claude-on-django/sessions/' not in existing:
                with open(gitignore, 'a') as f:
                    f.write(ignore_entries)
        else:
            with open(gitignore, 'w') as f:
                f.write(ignore_entries)

        self.stdout.write(self.style.SUCCESS("\nClaude-on-Django initialization complete!"))
        self.stdout.write("\nNext steps:")
        self.stdout.write("  1. Review .claude-on-django/prompts/ and customize for your project")
        self.stdout.write("  2. Run: python manage.py claude_sandbox_generate")

    def _create_agent_prompts(self, prompts_dir: str, analysis):
        """Copy agent prompts from package defaults, with dynamic customization."""
        import claude_on_django
        package_dir = os.path.dirname(claude_on_django.__file__)
        package_agents_dir = os.path.join(package_dir, 'agents')

        agents = {
            'architect': {
                'title': 'Django Architect',
                'desc': 'High-level system design, project structure, and team coordination.',
            },
            'modeler': {
                'title': 'Django Modeler',
                'desc': 'Django models, migrations, and database optimization using async ORM.',
            },
            'api_specialist': {
                'title': 'API Specialist',
                'desc': 'High-performance REST API endpoints with DRF, JWT/OAuth authentication, serialization.',
            },
            'views': {
                'title': 'Views Specialist',
                'desc': 'Django views, templates, and UI components.',
            },
            'services': {
                'title': 'Services Specialist',
                'desc': 'Business logic, service layer, and design patterns.',
            },
            'qa_engineer': {
                'title': 'QA Engineer',
                'desc': f'Testing with {analysis.test_framework or "pytest"}, TDD, unit and integration tests.',
            },
            'devops': {
                'title': 'DevOps Engineer',
                'desc': 'Deployment, Docker, CI/CD, and production configuration.',
            },
            'tasks': {
                'title': 'Background Tasks Specialist',
                'desc': 'Celery tasks, async processing, and background jobs.',
            },
        }

        for role, info in agents.items():
            prompt_file = os.path.join(prompts_dir, f'{role}.md')
            if os.path.exists(prompt_file):
                self.stdout.write(self.style.WARNING(f"  {role}.md already exists, skipping"))
                continue

            # Try to copy from package defaults
            source = os.path.join(package_agents_dir, f'{role}.md')
            if os.path.exists(source):
                with open(source) as f:
                    content = f.read()
                with open(prompt_file, 'w') as f:
                    f.write(content)
            else:
                # Generate minimal prompt
                with open(prompt_file, 'w') as f:
                    f.write(f"# {info['title']} System Prompt\n\n")
                    f.write(f"You are the {info['title']} for Claude-on-Django.\n")
                    f.write(f"Responsibility: {info['desc']}\n\n")
                    f.write("## Performance Paradigm\n")
                    f.write("- **Asynchronous Operations**: Use async Django ORM methods (aget, afilter, acreate).\n")
                    f.write("- **Type Safety**: Use msgspec.Struct for API schemas.\n")
                    f.write("- **Authentication**: JWT for stateless APIs, OAuth2 for external providers.\n")

            self.stdout.write(self.style.SUCCESS(f"  Created {role}.md"))

    def _write_context(self, path: str, analysis):
        """Write project context file."""
        with open(path, 'w') as f:
            f.write("# Claude-on-Django Project Context\n\n")
            f.write(f"- **Project type**: {'API-only' if analysis.api_only else 'Full-stack Django'}\n")
            f.write(f"- **Test framework**: {analysis.test_framework or 'not configured'}\n")
            f.write(f"- **Database**: {analysis.database}\n")
            f.write(f"- **Django REST Framework**: {'Yes' if analysis.has_drf else 'No'}\n")
            f.write(f"- **Django-Bolt**: {'Yes' if analysis.has_bolt else 'No'}\n")
            f.write(f"- **GraphQL**: {'Yes' if analysis.has_graphql else 'No'}\n")
            f.write(f"- **Celery**: {'Yes' if analysis.has_celery else 'No'}\n")
            f.write(f"- **Channels**: {'Yes' if analysis.has_channels else 'No'}\n")
            f.write(f"- **HTMX**: {'Yes' if analysis.has_htmx else 'No'}\n")
            f.write(f"- **Deployment**: {analysis.deployment}\n")
            if analysis.custom_patterns:
                f.write(f"- **Custom patterns**: {', '.join(analysis.custom_patterns.keys())}\n")
