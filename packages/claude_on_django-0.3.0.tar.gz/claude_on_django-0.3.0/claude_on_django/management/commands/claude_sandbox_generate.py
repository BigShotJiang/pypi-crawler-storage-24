from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = 'Generate the sandbox test project using claude_generate with default parameters.'

    def add_arguments(self, parser):
        parser.add_argument('--path', type=str, default='examples/sandbox',
                            help='Path where to generate the sandbox')

    def handle(self, *args, **options):
        from django.core.management import call_command

        self.stdout.write("Generating sandbox project (testing claude_generate with defaults)...")
        call_command(
            'claude_generate',
            path=options['path'],
            project_name='Django-bolt',
            app_name='app',
            item_name='task',
            no_input=True,
            no_migrate=True,
            stdout=self.stdout,
            stderr=self.stderr,
        )
