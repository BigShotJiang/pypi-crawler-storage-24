import os
import re
import asyncio
from django.core.management.base import BaseCommand, CommandError


def _constraints(app_name: str) -> str:
    """Shared constraints injected into every AI prompt."""
    return f"""
IMPORTANT CONSTRAINTS — follow exactly:
- This is a SINGLE Django app called '{app_name}'.
- All imports use '{app_name}.models', '{app_name}.schemas', '{app_name}.api', '{app_name}.services.auth_service'.
- INSTALLED_APPS contains 'django_bolt', 'claude_on_django', '{app_name}'.
- ROOT_URLCONF = '{app_name}.urls'. There is NO 'config' or 'apps' package.
- settings.DJANGO_SETTINGS_MODULE = '{app_name}.settings'.
- Use django-bolt for API: BoltAPI, ModelViewSet, @action decorator, JWTAuthentication, IsAuthenticated, AllowAny guards.
- Use msgspec.Struct for all schemas (NOT DRF serializers). Import msgspec.
- Use create_jwt_for_user and Token from django_bolt for JWT tokens.
- Do NOT use djangorestframework, rest_framework, or django-rest-framework-simplejwt.
- Do NOT use django_filters or any package not in: django, django-bolt, pyjwt, msgspec.
- Do NOT use ImageField. Use URLField for avatar_url.
- Use django.contrib.auth.models.User directly, not get_user_model().
- Output ONLY Python code. No markdown, no comments before/after the code, no ```python fences.
- Keep code concise. No docstrings longer than one line. No verbose comments.
"""


class Command(BaseCommand):
    help = 'Generate a Django-Bolt project with CRUD, JWT auth, OAuth, and tests. Interactive or via arguments.'

    def add_arguments(self, parser):
        parser.add_argument('--path', type=str, default=None,
                            help='Output directory for the generated project')
        parser.add_argument('--project-name', type=str, default=None,
                            help='Display name for the project (e.g. Django-bolt)')
        parser.add_argument('--app-name', type=str, default=None,
                            help='Python module name for the Django app (e.g. myapp)')
        parser.add_argument('--item-name', type=str, default=None,
                            help='Main CRUD entity name (e.g. task, ticket, order)')
        parser.add_argument('--no-input', action='store_true',
                            help='Use defaults without prompting')
        parser.add_argument('--no-migrate', action='store_true',
                            help='Skip running makemigrations and migrate')

    def handle(self, *args, **options):
        project_name, app_name, item_name, path = self._resolve_options(options)

        # Validate
        if not app_name.isidentifier():
            raise CommandError(f"App name '{app_name}' is not a valid Python identifier.")
        if not item_name.isidentifier():
            raise CommandError(f"Item name '{item_name}' is not a valid Python identifier.")

        # Create directory structure
        os.makedirs(path, exist_ok=True)
        for d in [app_name, f'{app_name}/migrations', f'{app_name}/services', f'{app_name}/tests']:
            os.makedirs(os.path.join(path, d), exist_ok=True)

        self.stdout.write("")
        self.stdout.write(self.style.MIGRATE_HEADING("  Claude-on-Django Project Generator"))
        self.stdout.write("")
        self.stdout.write(f"  Project:  {project_name}")
        self.stdout.write(f"  App:      {app_name}")
        self.stdout.write(f"  Item:     {item_name}")
        self.stdout.write(f"  Path:     {os.path.abspath(path)}")
        self.stdout.write("")

        asyncio.run(self._generate_with_ai(path, app_name, item_name, project_name))

        # Run migrations unless skipped
        if not options.get('no_migrate'):
            self._run_migrations(path, app_name)

        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS("  Project generated successfully!"))
        self.stdout.write("")
        self.stdout.write(f"  cd {path}")
        self.stdout.write(f"  python manage.py runbolt --dev")
        self.stdout.write("")

    # ------------------------------------------------------------------ #
    #  Interactive / argument resolution
    # ------------------------------------------------------------------ #

    def _resolve_options(self, options):
        """Resolve options from arguments or interactive prompts."""
        no_input = options.get('no_input', False)

        if no_input:
            project_name = options.get('project_name') or 'Django-bolt'
            app_name = options.get('app_name') or 'app'
            item_name = options.get('item_name') or 'task'
            path = options.get('path') or f'./{self._slugify(project_name)}'
        else:
            project_name = self._prompt('Project name', options.get('project_name'), 'Django-bolt')
            app_name = self._prompt('App name (Python module)', options.get('app_name'), 'app')
            item_name = self._prompt('Main item name (CRUD entity)', options.get('item_name'), 'task')
            default_path = f'./{self._slugify(project_name)}'
            path = self._prompt('Output path', options.get('path'), default_path)

        item_name = item_name.lower()
        return project_name, app_name, item_name, path

    def _prompt(self, label: str, value, default: str) -> str:
        """Prompt user for input if value not provided via arguments."""
        if value is not None:
            return value
        user_input = input(f"  {label} [{default}]: ").strip()
        return user_input if user_input else default

    @staticmethod
    def _slugify(name: str) -> str:
        """Convert project name to a directory-friendly slug."""
        return re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')

    # ------------------------------------------------------------------ #
    #  Post-generation: migrations
    # ------------------------------------------------------------------ #

    def _run_migrations(self, path: str, app_name: str):
        """Run makemigrations and migrate in the generated project."""
        import subprocess
        import sys
        manage_py = os.path.join(path, 'manage.py')
        if not os.path.exists(manage_py):
            return
        env = {**os.environ, 'PYTHONPATH': os.pathsep.join([os.getcwd(), path])}
        self.stdout.write("  Running migrations...")
        subprocess.run([sys.executable, manage_py, 'makemigrations', app_name],
                       env=env, cwd=path, capture_output=True)
        subprocess.run([sys.executable, manage_py, 'migrate'],
                       env=env, cwd=path, capture_output=True)
        self.stdout.write(self.style.SUCCESS("  Migrations complete."))

    # ------------------------------------------------------------------ #
    #  AI generation
    # ------------------------------------------------------------------ #

    async def _generate_with_ai(self, path: str, app: str, item: str, project: str):
        from claude_on_django.orchestrator.swarm import SwarmOrchestrator
        orchestrator = SwarmOrchestrator()

        # Derived names
        Item = item.title()       # Task, Ticket
        items = item + 's'        # tasks, tickets
        constraints = _constraints(app)

        # Create __init__.py files
        for init in [f'{app}/__init__.py', f'{app}/migrations/__init__.py',
                      f'{app}/services/__init__.py', f'{app}/tests/__init__.py']:
            self._write(os.path.join(path, init), "")

        # -- manage.py --
        self.stdout.write("  [1/10] manage.py")
        manage_py = self._ai(await orchestrator.run_task(
            f"Generate manage.py. DJANGO_SETTINGS_MODULE='{app}.settings'. "
            "Insert parent directory into sys.path. Output ONLY code.", 'architect'))
        self._write(os.path.join(path, 'manage.py'), manage_py)

        # -- settings.py --
        self.stdout.write("  [2/10] settings.py")
        settings = self._ai(await orchestrator.run_task(
            f"Generate Django settings.py. {constraints}"
            f"Include: INSTALLED_APPS with 'django_bolt', 'claude_on_django', '{app}'. "
            "MIDDLEWARE (standard Django middleware). "
            f"ROOT_URLCONF='{app}.urls', TEMPLATES, "
            "DATABASES (sqlite3), AUTH_PASSWORD_VALIDATORS, "
            "STATIC_URL, DEFAULT_AUTO_FIELD. "
            "Do NOT include REST_FRAMEWORK or SIMPLE_JWT settings. "
            "Django-bolt handles JWT at the view level via JWTAuthentication guard. "
            "Keep it under 60 lines.", 'architect'))
        self._write(os.path.join(path, app, 'settings.py'), settings)

        # -- models.py --
        self.stdout.write("  [3/10] models.py")
        models = self._ai(await orchestrator.run_task(
            f"Generate Django models.py. {constraints}"
            "Models: "
            "1) UserProfile: OneToOneField(User), bio TextField, avatar_url URLField, "
            "   __str__ returns 'Profile(username)'. "
            f"2) Project: name CharField, description TextField, owner ForeignKey(User), "
            f"   created_at, updated_at, ordering=['-created_at'], __str__ returns name. "
            f"3) {Item}: title CharField, description TextField, project ForeignKey(Project, related_name='{items}'), "
            f"   assignee ForeignKey(User, null=True, related_name='assigned_{items}'), priority CharField with choices "
            "   (low/medium/high/critical, default=medium), status CharField with choices "
            "   (todo/in_progress/in_review/done, default=todo), is_completed BooleanField(default=False), "
            f"   created_at, updated_at, ordering=['-created_at'], __str__ returns title. "
            "Add @receiver post_save signal to create UserProfile when User is created. "
            f"Define Priority and Status as inner TextChoices classes on {Item}.", 'modeler'))
        self._write(os.path.join(path, app, 'models.py'), models)

        # -- schemas.py (msgspec.Struct) --
        self.stdout.write("  [4/10] schemas.py")
        schemas = self._ai(await orchestrator.run_task(
            f"Generate schemas.py using msgspec.Struct (NOT DRF serializers). {constraints}"
            f"Import from {app}.models: UserProfile, Project, {Item}. "
            "Schemas: "
            "1) UserSchema(msgspec.Struct): id (int), username (str), email (str), first_name (str), last_name (str). "
            "2) UserProfileSchema(msgspec.Struct): id (int), user (UserSchema), bio (str), avatar_url (str). "
            "3) RegisterSchema(msgspec.Struct): username (str), email (str), password (str), password_confirm (str). "
            "4) LoginSchema(msgspec.Struct): username (str), password (str). "
            f"5) ProjectSchema(msgspec.Struct): id (int), name (str), description (str), "
            f"   owner (UserSchema), {item}_count (int), created_at (str), updated_at (str). "
            f"6) ProjectCreateSchema(msgspec.Struct): name (str), description (str, default=''). "
            f"7) {Item}Schema(msgspec.Struct): id (int), title (str), description (str), project_id (int), "
            "   assignee_id (int | None), priority (str), status (str), is_completed (bool), "
            "   created_at (str), updated_at (str). "
            f"8) {Item}DetailSchema(msgspec.Struct): like {Item}Schema but with nested "
            "   assignee (UserSchema | None) and project (ProjectSchema). "
            f"9) {Item}CreateSchema(msgspec.Struct): title (str), description (str, default=''), "
            "   project (int), assignee (int | None, default=None), priority (str, default='medium'), "
            "   status (str, default='todo'). "
            "10) OAuthLoginSchema(msgspec.Struct): provider (str), access_token (str). "
            "11) RefreshSchema(msgspec.Struct): refresh (str). "
            "Add helper classmethods 'from_model(cls, obj)' on UserSchema, ProjectSchema, "
            f"{Item}Schema, {Item}DetailSchema, UserProfileSchema that convert Django model instances "
            "to schema instances. For datetime fields, use str(obj.created_at). "
            f"For ProjectSchema.from_model, set {item}_count=obj.{items}.count(). "
            "Keep it concise.", 'api_specialist'))
        self._write(os.path.join(path, app, 'schemas.py'), schemas)

        # -- auth_service.py --
        self.stdout.write("  [5/10] auth_service.py")
        auth_service = self._ai(await orchestrator.run_task(
            f"Generate {app}/services/auth_service.py. {constraints}"
            "Import User from django.contrib.auth.models. "
            "Import create_jwt_for_user from django_bolt. "
            "Import Token from django_bolt. "
            "Import settings from django.conf. "
            "Class AuthService with @staticmethod methods: "
            "1) get_tokens_for_user(user) -> dict: creates access token (expires_in=3600) and "
            "   refresh token (expires_in=604800, extra_claims={'token_type': 'refresh'}) "
            "   using create_jwt_for_user. Returns {access, refresh}. "
            "2) register_user(username, email, password) -> User: creates and returns user. "
            "3) authenticate_user(username, password) -> dict|None: gets user, checks password, "
            "   calls get_tokens_for_user, returns {access, refresh, user_id, username} or None. "
            "4) oauth_login(provider, access_token) -> dict: mock OAuth — creates/gets user with "
            "   username='{provider}_user_{access_token[:8]}', calls get_tokens_for_user, "
            "   returns {access, refresh, user_id, username, created}. "
            "5) refresh_tokens(refresh_token) -> dict|None: decodes token using "
            "   Token.decode(refresh_token, settings.SECRET_KEY), checks extras.get('token_type')=='refresh', "
            "   gets User by id=int(token.sub), calls get_tokens_for_user, returns {access, refresh}. "
            "   On any exception returns None. "
            "Keep it simple, under 60 lines.", 'services'))
        self._write(os.path.join(path, app, 'services', 'auth_service.py'), auth_service)

        # -- api.py (BoltAPI views) --
        self.stdout.write("  [6/10] api.py")
        api_py = self._ai(await orchestrator.run_task(
            f"Generate {app}/api.py using django-bolt BoltAPI. {constraints}"
            f"Import BoltAPI, ModelViewSet, JWTAuthentication, IsAuthenticated, AllowAny from django_bolt. "
            "Import action from django_bolt. "
            "Import JSON from django_bolt. "
            "Import Request from django_bolt. "
            "Import PageNumberPagination from django_bolt. "
            "Import get_current_user from django_bolt. "
            f"Import from {app}.models: Project, {Item}, UserProfile. "
            f"Import from {app}.schemas: (all schemas). "
            f"Import from {app}.services.auth_service: AuthService. "
            "Import msgspec. "
            "Create: api = BoltAPI() "
            "Auth endpoints (no auth required): "
            "1) @api.post('/api/auth/register'): validate RegisterSchema (decode request body with msgspec), "
            "   check password == password_confirm (return JSON with error, status_code=400 if mismatch), "
            "   check username uniqueness (return 400 if exists), "
            "   call AuthService.register_user, return JSON with UserSchema.from_model(user) data, status_code=201. "
            "2) @api.post('/api/auth/login'): decode LoginSchema from body, "
            "   call AuthService.authenticate_user, if None return JSON error status_code=401, else return JSON with result. "
            "3) @api.post('/api/auth/oauth'): decode OAuthLoginSchema from body, "
            "   validate provider is 'google' or 'apple' (400 if not), "
            "   call AuthService.oauth_login, return JSON with result. "
            "4) @api.post('/api/auth/refresh'): decode RefreshSchema from body, "
            "   call AuthService.refresh_tokens, if None return JSON error status_code=401, else return JSON with result. "
            "Profile endpoint (auth required): "
            "5) @api.get('/api/auth/profile', auth=[JWTAuthentication()], guards=[IsAuthenticated()]): "
            "   get user via get_current_user(request), get profile, return UserProfileSchema.from_model(profile). "
            "6) @api.patch('/api/auth/profile', auth=[JWTAuthentication()], guards=[IsAuthenticated()]): "
            "   get user, decode body, update profile fields (bio, avatar_url), save, return updated profile. "
            "CRUD ViewSets (auth required): "
            f"7) @api.viewset('/api/projects', auth=[JWTAuthentication()], guards=[IsAuthenticated()]): "
            "   class ProjectViewSet(ModelViewSet): "
            "   serializer_class = ProjectSchema, pagination_class = PageNumberPagination. "
            "   Override get_queryset to filter by owner (get user from get_current_user). "
            "   Override list to return paginated ProjectSchema.from_model results. "
            "   Override create to decode ProjectCreateSchema, save with owner=current_user, return ProjectSchema. "
            "   Override retrieve, update, partial_update, destroy appropriately. "
            f"8) @api.viewset('/api/{items}', auth=[JWTAuthentication()], guards=[IsAuthenticated()]): "
            f"   class {Item}ViewSet(ModelViewSet): "
            f"   serializer_class = {Item}Schema, pagination_class = PageNumberPagination. "
            "   Override get_queryset to filter by project__owner (current user). "
            f"   Support query param filtering: status, priority, assignee. "
            f"   Override list to return paginated {Item}Schema.from_model results. "
            f"   Override create to decode {Item}CreateSchema, save, return {Item}Schema. "
            f"   Override retrieve to return {Item}DetailSchema.from_model. "
            "   @action(methods=['PATCH'], detail=True): assign — get assignee_id from body, "
            f"   return 400 if missing, look up User (404 if not found), set {item}.assignee, save, return {Item}Schema. "
            "   @action(methods=['PATCH'], detail=True): complete — set is_completed=True, status='done', "
            f"   save, return {Item}Schema. "
            "IMPORTANT for request body parsing: use msgspec.json.decode(request.body, type=SchemaClass) to parse. "
            "IMPORTANT for getting current user: use 'user = await get_current_user(request)'. "
            "IMPORTANT for async ORM: use aget, afilter (via async for), asave, acreate, adelete.",
            'api_specialist'))
        self._write(os.path.join(path, app, 'api.py'), api_py)

        # -- urls.py --
        self.stdout.write("  [7/10] urls.py")
        urls = self._ai(await orchestrator.run_task(
            f"Generate {app}/urls.py. {constraints}"
            "Django-bolt handles API routing via BoltAPI decorators in api.py. "
            "This urls.py is only needed for ROOT_URLCONF. "
            "Just define: urlpatterns = [] "
            "Output ONLY code.", 'architect'))
        self._write(os.path.join(path, app, 'urls.py'), urls)

        # -- unit tests --
        self.stdout.write("  [8/10] test_models.py")
        unit_tests = self._ai(await orchestrator.run_task(
            f"Generate {app}/tests/test_models.py. {constraints}"
            "Import from django.test: TestCase. Import from django.contrib.auth.models: User. "
            f"Import from {app}.models: UserProfile, Project, {Item}. "
            f"Import from {app}.services.auth_service: AuthService. "
            "IMPORTANT — model fields: "
            "  UserProfile: user, bio (default ''), avatar_url (default ''). __str__ returns 'Profile(username)'. "
            "  Project: owner, name, description, created_at, updated_at. NO is_active field. "
            f"  {Item}: project, assignee, title, description, priority, status, is_completed, created_at, updated_at. "
            f"  {Item} has NO created_by field. Create {items} with {Item}.objects.create(project=p, title='X'). "
            "IMPORTANT — AuthService return types: "
            "  register_user(username, email, password) returns a User object (NOT a dict). "
            "  authenticate_user(username, password) returns dict {access, refresh, user_id, username} or None. "
            "  oauth_login(provider, access_token) takes exactly 2 args, returns dict {access, refresh, user_id, username, created}. "
            "  refresh_tokens(refresh_token) returns dict {access, refresh} or None. "
            "Test classes: "
            "1) UserProfileModelTest: test profile auto-created on User.create_user, "
            "   test str(profile) == 'Profile(username)', test bio and avatar_url defaults. "
            "2) ProjectModelTest: test create (assert name and owner), test __str__, test ordering (newest first). "
            f"3) {Item}ModelTest: test create defaults (priority='medium', status='todo', is_completed=False), test __str__, "
            "   test with assignee, test priority choices (low/medium/high/critical), test status choices (todo/in_progress/in_review/done). "
            "4) AuthServiceTest: "
            "   test_register_user: call register_user, assert returned User has correct username/email. "
            "   test_authenticate_success: create user, call authenticate_user, assertIn 'access' in result. "
            "   test_authenticate_wrong_password: call authenticate_user with wrong pass, assertIsNone(result). "
            "   test_authenticate_not_found: call authenticate_user with unknown user, assertIsNone(result). "
            "   test_oauth_login_creates_user: call oauth_login('google','tok123'), assertIn 'access', assertTrue created. "
            "   test_oauth_login_returns_existing: call oauth_login twice with same args, assertFalse created on second call. "
            "   test_refresh_tokens_valid: create user, authenticate, call refresh_tokens(result['refresh']), assertIn 'access'. "
            "   test_refresh_tokens_invalid: call refresh_tokens('bad'), assertIsNone(result). "
            "Keep under 120 lines.", 'qa_engineer'))
        self._write(os.path.join(path, app, 'tests', 'test_models.py'), unit_tests)

        # -- schema & service integration tests --
        self.stdout.write("  [9/10] test_api.py")
        integration_tests = self._ai(await orchestrator.run_task(
            f"Generate {app}/tests/test_api.py. {constraints}"
            "Import from django.test: TestCase. "
            "Import from django.contrib.auth.models: User. "
            f"Import from {app}.models: Project, {Item}, UserProfile. "
            f"Import from {app}.schemas: UserSchema, ProjectSchema, {Item}Schema, {Item}DetailSchema, "
            "   RegisterSchema, UserProfileSchema. "
            f"Import from {app}.services.auth_service: AuthService. "
            "Import msgspec. "
            "Since django-bolt runs on a Rust HTTP server, these tests validate schemas and services "
            "directly without HTTP transport. Use Django's TestCase. "
            "Test classes: "
            "1) SchemaTest: "
            "   test_user_schema_from_model: create User, call UserSchema.from_model(user), assert fields match. "
            f"   test_{item}_schema_from_model: create Project and {Item}, call {Item}Schema.from_model, assert fields. "
            f"   test_{item}_detail_schema: create {Item} with assignee, call {Item}DetailSchema.from_model, "
            "   assert nested assignee and project are populated. "
            "   test_project_schema_from_model: create Project, call ProjectSchema.from_model, assert fields. "
            f"   test_project_schema_{item}_count: create Project with 3 {items}, assert {item}_count==3. "
            "   test_register_schema_encode_decode: create RegisterSchema, encode to JSON, decode back, assert match. "
            "   test_user_profile_schema: create User (profile auto-created), call UserProfileSchema.from_model, assert fields. "
            "2) AuthFlowTest: "
            "   test_register_then_login: register user via AuthService, then authenticate, assert tokens returned. "
            "   test_login_returns_tokens: create user, authenticate, assert 'access' and 'refresh' in result. "
            "   test_login_wrong_password_returns_none: create user, authenticate with wrong pass, assertIsNone. "
            "   test_oauth_creates_user: call oauth_login, assert user created in DB. "
            "   test_oauth_returns_tokens: call oauth_login, assert 'access' and 'refresh' in result. "
            "   test_refresh_token_flow: authenticate, get refresh token, call refresh_tokens, assert new tokens returned. "
            "   test_refresh_invalid_token: call refresh_tokens('invalid'), assertIsNone. "
            f"3) {Item}ServiceTest: "
            f"   test_create_{item}: create Project and {Item}, assert fields. "
            f"   test_{item}_assignment: create {Item}, assign user, assert assignee set. "
            f"   test_{item}_completion: create {Item}, set is_completed=True, status='done', assert values. "
            f"   test_{item}_filtering_by_status: create {items} with different statuses, filter, assert correct results. "
            f"   test_{item}_filtering_by_priority: create {items} with different priorities, filter, assert correct results. "
            f"   test_owner_isolation: create {items} under different users' projects, filter by owner, assert isolation. "
            f"   test_{item}_cascade_delete: delete project, assert {items} deleted. "
            "Keep under 180 lines.", 'qa_engineer'))
        self._write(os.path.join(path, app, 'tests', 'test_api.py'), integration_tests)

        # -- static files --
        self.stdout.write("  [10/10] requirements.txt, README.md, Makefile")
        self._write(os.path.join(path, 'requirements.txt'), _requirements_txt())
        self._write(os.path.join(path, 'README.md'), _readme_md(project, app, item))
        self._write(os.path.join(path, 'Makefile'), _project_makefile(app))

    # ------------------------------------------------------------------ #
    #  Helpers
    # ------------------------------------------------------------------ #

    def _write(self, filepath: str, content: str):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w') as f:
            f.write(content)

    def _ai(self, content: str) -> str:
        """Clean AI response. Raise if the API returned an error."""
        if content.startswith("# Error"):
            raise CommandError(content)
        return self._clean(content)

    def _clean(self, content: str) -> str:
        if "```" in content:
            match = re.search(r'```(?:python|makefile|make)?\n(.*?)\n```', content, re.DOTALL)
            if match:
                return match.group(1)
            lines = content.split('\n')
            lines = [l for l in lines if not l.strip().startswith('```')]
            return '\n'.join(lines)
        return content


# ====================================================================== #
#  SHARED TEMPLATES
# ====================================================================== #

def _requirements_txt() -> str:
    return """\
django>=4.2
django-bolt>=0.7
msgspec>=0.18
pydantic>=2.0
pydantic-ai
claude-on-django
pytest>=7.0
pytest-django>=4.5
pytest-asyncio
"""


def _readme_md(project_name: str, app_name: str, item_name: str) -> str:
    Item = item_name.title()
    items = item_name + 's'
    return f"""\
# {project_name}

High-performance {Item} Management API powered by Django-Bolt (Rust + Django).
Generated by `claude-on-django` AI agents.

## Features
- User registration and profiles
- JWT authentication (django-bolt built-in)
- OAuth login (Google, Apple)
- Project CRUD with owner isolation
- {Item} CRUD with filtering (status, priority, assignee)
- {Item} assignment and completion endpoints
- Full unit tests (models, services)
- Full integration tests (schemas, service flows)
- Pagination support
- 60k+ RPS via Rust-powered endpoints

## Setup
```bash
pip install -r requirements.txt
python manage.py makemigrations {app_name}
python manage.py migrate
python manage.py test {app_name}
```

## Run Server
```bash
python manage.py runbolt --dev
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | User registration |
| POST | /api/auth/login | JWT login |
| POST | /api/auth/oauth | OAuth login (Google/Apple) |
| POST | /api/auth/refresh | Refresh JWT token |
| GET/PATCH | /api/auth/profile | User profile |
| GET/POST | /api/projects | List/Create projects |
| GET/PUT/PATCH/DELETE | /api/projects/{{id}} | Project detail |
| GET/POST | /api/{items} | List/Create {items} |
| GET/PUT/PATCH/DELETE | /api/{items}/{{id}} | {Item} detail |
| PATCH | /api/{items}/{{id}}/assign | Assign {item_name} |
| PATCH | /api/{items}/{{id}}/complete | Complete {item_name} |

## Testing
```bash
python manage.py test {app_name} -v 2
```

## Architecture
Built with [Django-Bolt](https://github.com/dj-bolt/django-bolt) — Rust-powered
endpoints via Actix Web + PyO3, msgspec schemas for 5-10x faster serialization.
"""


def _project_makefile(app_name: str) -> str:
    return f"""\
VENV_PYTHON ?= python3

.PHONY: help install migrate test run superuser clean

help:
\t@echo "Available targets:"
\t@echo "  install    - Install dependencies"
\t@echo "  migrate    - Run migrations"
\t@echo "  test       - Run tests"
\t@echo "  run        - Start development server (django-bolt)"
\t@echo "  superuser  - Create superuser"
\t@echo "  clean      - Remove database and cache"

install:
\tpip install -r requirements.txt

migrate:
\t$(VENV_PYTHON) manage.py makemigrations {app_name}
\t$(VENV_PYTHON) manage.py migrate

test:
\t$(VENV_PYTHON) manage.py test {app_name} -v 2

run:
\t$(VENV_PYTHON) manage.py runbolt --dev

superuser:
\t$(VENV_PYTHON) manage.py createsuperuser

clean:
\trm -f db.sqlite3
\tfind . -type d -name __pycache__ -exec rm -rf {{}} + 2>/dev/null || true
"""
