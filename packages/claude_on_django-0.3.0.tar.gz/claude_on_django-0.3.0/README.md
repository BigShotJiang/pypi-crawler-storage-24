# Claude-on-Django

An autonomous development framework that leverages AI agent teams for Django development. Developers describe what they want to build, and the swarm coordinates implementation across all Django layers automatically.

Ported from [claude-on-rails](https://github.com/obie/claude-on-rails) with full feature parity.

## How It Works

Claude-on-Django creates a team of specialized AI agents, each focused on a specific domain:

| Agent | Responsibility |
|-------|---------------|
| **Architect** | System design, coordination, project structure |
| **Modeler** | Django models, migrations, database optimization |
| **API Specialist** | REST API (DRF), JWT/OAuth authentication, serialization |
| **Views** | Templates, class-based views, UI (full-stack only) |
| **Services** | Business logic, service layer, design patterns |
| **QA Engineer** | Unit + integration tests, TDD, test coverage |
| **DevOps** | Docker, CI/CD, deployment, production config |
| **Tasks** | Celery, background jobs (when Celery detected) |

## Installation

```bash
pip install claude-on-django
```

Then initialize in your Django project:

```bash
python manage.py claude_swarm_init
```

This will:
- Analyze your project (detect DRF, Celery, GraphQL, HTMX, database, deployment)
- Generate agent prompts in `.claude-on-django/prompts/`
- Build a swarm topology matching your project features
- Create/update `CLAUDE.md` with project context

## Usage

### Natural Language Development

Describe what you want and the swarm handles implementation across all layers:

```bash
claude "Add user authentication with JWT and OAuth"
claude "Create a task management API with filtering and pagination"
claude "Optimize the dashboard queries for performance"
```

### Generate a Sandbox Project

Generate a complete example project with CRUD, JWT, OAuth, and full test coverage:

```bash
# Generates sandbox using Claude AI agents (requires ANTHROPIC_API_KEY with credits)
python manage.py claude_sandbox_generate --path examples/sandbox
```

The sandbox includes:
- User registration and profiles
- JWT authentication (SimpleJWT)
- OAuth login (Google, Apple)
- Project and Task CRUD with owner isolation
- Task filtering (status, priority, assignee)
- Task assignment and completion endpoints
- 23 unit tests (models, services, auth)
- 33 integration tests (all API endpoints, pagination, data isolation)

## Architecture

```
claude_on_django/
├── project_analyzer.py      # Detects Django project features
├── swarm_builder.py         # Generates agent topology from analysis
├── configuration.py         # Global settings with env var overrides
├── orchestrator/
│   ├── swarm.py             # SwarmOrchestrator (PydanticAI agents)
│   └── maintainer.py        # CLAUDE.md auto-updater
├── toolsets/
│   └── core.py              # Filesystem and command toolsets
├── mcp_server/
│   ├── structure.py         # MCP server for API metadata scanning
│   └── support.py           # MCP availability and installation
├── agents/                  # 8 agent system prompts (.md)
└── management/commands/
    ├── claude_swarm_init.py          # Project analysis + setup
    └── claude_sandbox_generate.py    # Sandbox project generator
```

### ProjectAnalyzer

Detects your Django project features:
- **Frameworks**: DRF, GraphQL (Graphene/Strawberry), HTMX, Channels
- **Background tasks**: Celery
- **Database**: PostgreSQL, MySQL, SQLite
- **Deployment**: Docker, Kubernetes, Heroku, Fly.io
- **Custom patterns**: services, serializers, permissions, middleware, signals

### SwarmBuilder

Generates a conditional agent topology based on analysis:
- API-only projects skip the Views agent
- Celery projects get a Tasks agent
- GraphQL projects get a GraphQL agent
- Architect connections are wired to all active agents

## Project Structure After Init

```
your-django-project/
├── CLAUDE.md                              # Project context for Claude
└── .claude-on-django/
    ├── context.md                         # Detected project features
    ├── sessions/                          # Agent session logs
    └── prompts/                           # Agent system prompts
        ├── architect.md
        ├── modeler.md
        ├── api_specialist.md
        ├── views.md
        ├── services.md
        ├── qa_engineer.md
        ├── devops.md
        └── tasks.md
```

## Configuration

### Environment Variables

```bash
# Required: Anthropic API key (for AI sandbox generation, the default)
ANTHROPIC_API_KEY=sk-ant-...

# Optional: Override the default model (default: anthropic:claude-sonnet-4-6)
CLAUDE_ON_DJANGO_MODEL=anthropic:claude-sonnet-4-6

# Optional: Enable experimental agent teams
CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1
```

### Python Configuration

```python
from claude_on_django import configure

configure(
    default_model="anthropic:claude-opus-4-6",
    vibe_mode=False,
    max_parallel_agents=3,
)
```

## Development

```bash
# Install dev dependencies
make dev-install

# Run package tests (21 tests)
make test

# Generate sandbox and run its tests (56 tests)
make sandbox-init
make sandbox-test

# Run swarm verification script
make sandbox-run

# Lint
make lint

# Build and publish
make build
make publish
```

## License

MIT License - see [LICENSE](LICENSE) for details.
