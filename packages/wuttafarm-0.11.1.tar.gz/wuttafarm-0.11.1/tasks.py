# -*- coding: utf-8; -*-
"""
Tasks for WuttaFarm
"""

import os
import shutil

from invoke import task


@task
def release(c, skip_tests=False):
    """
    Release a new version of WuttaFarm
    """
    if not skip_tests:
        # TODO
        # c.run("pytest")
        pass

    if os.path.exists("dist"):
        shutil.rmtree("dist")

    c.run("python -m build")
    c.run("twine upload dist/*")


@task
def update_style(c):
    """
    Build/update the `wuttafarm-buefy.css` file
    """
    os.chdir("style")
    # c.run("nvm use lts/krypton")
    c.run("npm install")
    c.run("npm run build")
    os.chdir(os.pardir)
    shutil.copy("style/dist/css/wuttafarm-buefy.css", "src/wuttafarm/web/static/css/")
