## -*- coding: utf-8; -*-
<%inherit file="/master/view.mako" />

<%def name="page_content()">

  % if instance.archived:
      <b-notification type="is-warning">
         This asset is archived.
         Archived assets should only be edited if they need corrections.
      </b-notification>
  % endif

  <div style="display: flex; margin-right: 0.5rem;">

    ## main form
    <div style="flex-grow: 1;">
      ${parent.page_content()}
    </div>

    ## location map
    % if map_polygon:
        <div ref="map" style="flex-grow: 2; height: 500px;" />
    % endif

  </div>

</%def>

<%def name="modify_vue_vars()">
  ${parent.modify_vue_vars()}
  % if map_polygon:
      <script>

        ThisPageData.map = null

        ThisPage.mounted = function() {

            this.map = new maplibregl.Map({
                container: this.$refs.map,
                style: 'https://tiles.openfreemap.org/styles/liberty',
                center: ${json.dumps(map_center)|n},
                zoom: 16,
            })

            this.map.on('load', () => {

                this.map.addSource('assetGeometry', {
                    'type': 'geojson',
                    'data': {
                        'type': 'Feature',
                        'geometry': {
                            'type': 'Polygon',
                            'coordinates': ${json.dumps(map_polygon)|n},
                        }
                    }
                })

                this.map.addLayer({
                    'id': 'assetGeometry',
                    'source': 'assetGeometry',
                    'type': 'line',
                    'paint': {
                        'line-color': 'orange',
                        'line-width': 2,
                    },
                })

                this.map.fitBounds(${json.dumps(map_bounds)|n}, {
                    linear: true,
                })

                this.map.addControl(new maplibregl.FullscreenControl())
                this.map.addControl(new maplibregl.NavigationControl(), 'top-left')
                this.map.addControl(new maplibregl.ScaleControl({
                    maxWidth: 80,
                    unit: 'imperial',
                }))
            })
        }

      </script>
  % endif
</%def>
