
<%def name="make_wuttafarm_components()">
  ${self.make_taxonomy_terms_picker_component()}
  ${self.make_equipment_types_picker_component()}
  ${self.make_assets_picker_component()}
  ${self.make_animal_type_picker_component()}
  ${self.make_material_types_picker_component()}
  ${self.make_quantity_editor_component()}
  ${self.make_quantities_editor_component()}
  ${self.make_plant_types_picker_component()}
  ${self.make_seasons_picker_component()}
</%def>

<%def name="make_taxonomy_terms_picker_component()">
  <script type="text/x-template" id="taxonomy-terms-picker-template">
    <div>
      <input type="hidden" :name="name" :value="JSON.stringify(value)" />

      <div style="display: flex; gap: 0.5rem; align-items: center;">

        <span>Add:</span>

        <b-autocomplete v-model="addName"
                        ref="addName"
                        :data="addNameData"
                        field="name"
                        open-on-focus
                        keep-first
                        @select="addNameSelected"
                        clear-on-select
                        style="flex-grow: 1;">
          <template #empty>No results found</template>
        </b-autocomplete>

        <b-button type="is-primary"
                  icon-pack="fas"
                  icon-left="plus"
                  @click="createInit()">
          New
        </b-button>

      </div>

      <${b}-table :data="value">

        <${b}-table-column field="name" v-slot="props">
          <span>{{ props.row.name }}</span>
        </${b}-table-column>

        <${b}-table-column v-slot="props">
            <a href="#"
               class="has-text-danger"
               @click.prevent="removeTerm(props.row)">
              <i class="fas fa-trash" /> &nbsp; Remove
            </a>
        </${b}-table-column>

      </${b}-table>

      <${b}-modal v-if="canCreate"
                  has-modal-card
                  % if request.use_oruga:
                  v-model:active="createShowDialog"
                  % else:
                  :active.sync="createShowDialog"
                  % endif
                  >
        <div class="modal-card">

          <header class="modal-card-head">
            <p class="modal-card-title">New {{ termTitle }} </p>
          </header>

          <section class="modal-card-body">
            <b-field label="Name" horizontal>
              <b-input v-model="createName"
                       ref="createName"
                       expanded
                       @keydown.native="createNameKeydown" />
            </b-field>
          </section>

          <footer class="modal-card-foot">
            <b-button type="is-primary"
                      @click="createSave()"
                      :disabled="createSaving || !createName"
                      icon-pack="fas"
                      icon-left="save">
              {{ createSaving ? "Working, please wait..." : "Save" }}
            </b-button>
            <b-button @click="createShowDialog = false">
              Cancel
            </b-button>
          </footer>
        </div>
      </${b}-modal>
    </div>
  </script>
  <script>
    const TaxonomyTermsPicker = {
        template: '#taxonomy-terms-picker-template',
        mixins: [WuttaRequestMixin],
        props: {
            name: String,
            value: Array,
            termTitle: String,
            terms: Array,
            canCreate: Boolean,
            createUrl: String,
        },
        data() {
            return {
                addName: '',
                createShowDialog: false,
                createName: null,
                createSaving: false,
            }
        },
        computed: {

            addNameData() {
                if (!this.addName) {
                    return this.terms
                }

                return this.terms.filter((term) => {
                    return term.name.toLowerCase().indexOf(this.addName.toLowerCase()) >= 0
                })
            },
        },
        methods: {

            addNameSelected(option) {
                if (!option) {
                    return
                }

                const uuids = this.value.map((term) => {
                    return term.uuid
                })

                if (!uuids.includes(option.uuid)) {
                    this.value.push(option)
                    this.$emit('input', this.value)
                }

                this.addName = null
            },

            createInit() {
                this.createName = this.addName
                this.createShowDialog = true
                this.$nextTick(() => {
                    this.$refs.createName.focus()
                })
            },

            createNameKeydown(event) {
                // nb. must prevent main form submit on ENTER
                // (since ultimately this lives within an outer form)
                // but also we can submit the modal pseudo-form
                if (event.which == 13) {
                    event.preventDefault()
                    this.createSave()
                }
            },

            createSave() {
                this.createSaving = true
                const params = {name: this.createName}
                this.wuttaPOST(this.createUrl, params, response => {
                    this.value.push(response.data)
                    this.$emit('input', this.value)
                    this.addName = null
                    this.createSaving = false
                    this.createShowDialog = false
                }, response => {
                    this.createSaving = false
                })
            },

            removeTerm(term) {
                const value = Array.from(this.value)
                const i = value.indexOf(term)
                value.splice(i, 1)
                this.$emit('input', value)
            },
        },
    }
    Vue.component('taxonomy-terms-picker', TaxonomyTermsPicker)
    <% request.register_component('taxonomy-terms-picker', 'TaxonomyTermsPicker') %>
  </script>
</%def>

<%def name="make_equipment_types_picker_component()">
  <script type="text/x-template" id="equipment-types-picker-template">
    <taxonomy-terms-picker v-model="proxyValue"
                           :name="name"
                           term-title="Equipment Type"
                           :terms="equipmentTypes"
                           :can-create="canCreate"
                           create-url="${url('equipment_types.ajax_create')}" />
  </script>
  <script>
    const EquipmentTypesPicker = {
        template: '#equipment-types-picker-template',
        props: {
            name: String,
            value: Array,
            equipmentTypes: Array,
            canCreate: Boolean,
        },
        data() {
            return {
                proxyValue: this.value || [],
            }
        },
    }
    Vue.component('equipment-types-picker', EquipmentTypesPicker)
    <% request.register_component('equipment-types-picker', 'EquipmentTypesPicker') %>
  </script>
</%def>

<%def name="make_assets_picker_component()">
  <script type="text/x-template" id="assets-picker-template">
    <div>
      <input type="hidden" :name="name" :value="value" />

      <div style="display: flex; gap: 0.5rem; align-items: center;">

        <span>Add:</span>

        <b-autocomplete v-model="addName"
                        ref="addName"
                        :data="addNameData"
                        field="name"
                        open-on-focus
                        keep-first
                        @select="addNameSelected"
                        clear-on-select
                        style="flex-grow: 1;">
          <template #empty>No results found</template>
        </b-autocomplete>

      </div>

      <${b}-table :data="assetData">

        <${b}-table-column field="name" v-slot="props">
          <span>{{ props.row.name }}</span>
        </${b}-table-column>

        <${b}-table-column v-slot="props">
            <a href="#"
               class="has-text-danger"
               @click.prevent="removeAsset(props.row)">
              <i class="fas fa-trash" /> &nbsp; Remove
            </a>
        </${b}-table-column>

      </${b}-table>
    </div>
  </script>
  <script>
    const AssetsPicker = {
        template: '#assets-picker-template',
        props: {
            name: String,
            value: Array,
            assets: Array,
        },
        data() {
            return {
                addName: '',
                internalAssets: this.assets.map((asset) => {
                    return {uuid: asset[0], name: asset[1]}
                }),
            }
        },
        computed: {
            assetData() {
                const data = []

                if (this.value) {
                    for (let asset of this.internalAssets) {
                        if (this.value.includes(asset.uuid)) {
                            data.push(asset)
                        }
                    }
                }

                return data
            },
            addNameData() {
                if (!this.addName) {
                    return this.internalAssets
                }

                return this.internalAssets.filter((asset) => {
                    return asset.name.toLowerCase().indexOf(this.addName.toLowerCase()) >= 0
                })
            },
        },
        methods: {

            addNameSelected(option) {
                const value = Array.from(this.value || [])

                if (!value.includes(option.uuid)) {
                    value.push(option.uuid)
                    this.$emit('input', value)
                }

                this.addName = null
            },

            removeAsset(asset) {
                let value = Array.from(this.value)
                const i = value.indexOf(asset.uuid)
                value.splice(i, 1)
                this.$emit('input', value)
            },
        },
    }
    Vue.component('assets-picker', AssetsPicker)
    <% request.register_component('assets-picker', 'AssetsPicker') %>
  </script>
</%def>

<%def name="make_animal_type_picker_component()">
  <script type="text/x-template" id="animal-type-picker-template">
    <div>
      <div style="display: flex; gap: 0.5rem;">

        <b-select :name="name"
                  :value="internalValue"
                  @input="val => $emit('input', val)"
                  style="flex-grow: 1;">
          <option v-for="atype in internalAnimalTypes"
                  :value="atype[0]">
            {{ atype[1] }}
          </option>
        </b-select>

        <b-button v-if="canCreate"
                  type="is-primary"
                  icon-pack="fas"
                  icon-left="plus"
                  @click="createInit()">
          New
        </b-button>

      </div>
      <${b}-modal v-if="canCreate"
                  has-modal-card
                  % if request.use_oruga:
                  v-model:active="createShowDialog"
                  % else:
                  :active.sync="createShowDialog"
                  % endif
                  >
        <div class="modal-card">

          <header class="modal-card-head">
            <p class="modal-card-title">New Animal Type</p>
          </header>

          <section class="modal-card-body">
            <b-field label="Name" horizontal>
              <b-input v-model="createName"
                       ref="createName"
                       expanded
                       @keydown.native="createNameKeydown" />
            </b-field>
          </section>

          <footer class="modal-card-foot">
            <b-button type="is-primary"
                      @click="createSave()"
                      :disabled="createSaving || !createName"
                      icon-pack="fas"
                      icon-left="save">
              {{ createSaving ? "Working, please wait..." : "Save" }}
            </b-button>
            <b-button @click="createShowDialog = false">
              Cancel
            </b-button>
          </footer>
        </div>
      </${b}-modal>
    </div>
  </script>
  <script>
    const AnimalTypePicker = {
        template: '#animal-type-picker-template',
        mixins: [WuttaRequestMixin],
        props: {
            name: String,
            value: String,
            animalTypes: Array,
            canCreate: Boolean,
        },
        data() {
            return {
                internalAnimalTypes: this.animalTypes,
                internalValue: this.value,
                createShowDialog: false,
                createName: null,
                createSaving: false,
            }
        },
        methods: {

            createInit(name) {
                this.createName = name || null
                this.createShowDialog = true
                this.$nextTick(() => {
                    this.$refs.createName.focus()
                })
            },

            createNameKeydown(event) {
                // nb. must prevent main form submit on ENTER
                // (since ultimately this lives within an outer form)
                // but also we can submit the modal pseudo-form
                if (event.which == 13) {
                    event.preventDefault()
                    this.createSave()
                }
            },

            createSave() {
                this.createSaving = true
                ## TODO
                % if not app.is_farmos_wrapper():
                const url = "${url('animal_types.ajax_create')}"
                % endif
                const params = {name: this.createName}
                this.wuttaPOST(url, params, response => {
                    this.internalAnimalTypes.push([response.data.uuid, response.data.name])
                    this.$nextTick(() => {
                        this.internalValue = response.data.uuid
                        this.createSaving = false
                        this.createShowDialog = false
                    })
                }, response => {
                    this.createSaving = false
                })
            },
        },
    }
    Vue.component('animal-type-picker', AnimalTypePicker)
    <% request.register_component('animal-type-picker', 'AnimalTypePicker') %>
  </script>
</%def>

<%def name="make_material_types_picker_component()">
  <script type="text/x-template" id="material-types-picker-template">
    <div>
      <input type="hidden" :name="name" :value="JSON.stringify(value)" />

      <div style="display: flex; gap: 0.5rem; align-items: center;">

        <span>Add:</span>

        <b-autocomplete v-model="addName"
                        ref="addName"
                        :data="addNameData"
                        field="name"
                        open-on-focus
                        keep-first
                        @select="addNameSelected"
                        clear-on-select
                        style="flex-grow: 1;">
          <template #empty>No results found</template>
        </b-autocomplete>

      </div>

      <${b}-table :data="materialTypeData">

        <${b}-table-column field="name" v-slot="props">
          <span>{{ props.row.name }}</span>
        </${b}-table-column>

        <${b}-table-column v-slot="props">
            <a href="#"
               class="has-text-danger"
               @click.prevent="removeMaterialType(props.row)">
              <i class="fas fa-trash" /> &nbsp; Remove
            </a>
        </${b}-table-column>

      </${b}-table>
    </div>
  </script>
  <script>
    const MaterialTypesPicker = {
        template: '#material-types-picker-template',
        props: {
            name: String,
            value: Array,
            materialTypes: Array,
        },
        data() {
            return {
                addName: '',
            }
        },
        computed: {
            materialTypeData() {
                const data = []

                if (this.value) {

                    const mtypes = new Map(this.materialTypes.map((mtype) => {
                        return [mtype.uuid, mtype.name]
                    }))

                    for (const mtype of this.value) {
                        if (mtypes.has(mtype.uuid)) {
                            data.push(mtype)
                        }
                    }
                }

                return data
            },
            addNameData() {
                if (!this.addName) {
                    return this.materialTypes
                }

                return this.materialTypes.filter((mtype) => {
                    return mtype.name.toLowerCase().indexOf(this.addName.toLowerCase()) >= 0
                })
            },
        },
        methods: {

            focus() {
                this.$refs.addName.focus()
            },

            addNameSelected(option) {
                if (!option) {
                    return
                }

                const value = Array.from(this.value || [])

                if (!value.includes(option)) {
                    value.push(option)
                    this.$emit('input', value)
                }

                this.addName = null
            },

            removeMaterialType(ptype) {
                const value = Array.from(this.value)
                const i = value.indexOf(ptype)
                value.splice(i, 1)
                this.$emit('input', value)
            },
        },
    }
    Vue.component('material-types-picker', MaterialTypesPicker)
    <% request.register_component('material-types-picker', 'MaterialTypesPicker') %>
  </script>
</%def>

<%def name="make_quantity_editor_component()">
  <script type="text/x-template" id="quantity-editor-template">
    <div>

      <b-field v-if="quantityType == 'material'"
               label="Material Types"
               horizontal>
        <material-types-picker v-model="value.material_types"
                               ref="materials"
                               :material-types="materialTypes" />
      </b-field>

      <b-field label="Measure" horizontal
               ## TODO: why is this needed?
               style="margin-bottom: 1rem;">
        <b-select v-model="value.measure"
                  ref="measure">
          <option v-for="m in measures"
                  :value="m.drupal_id">
            {{ m.name }}
          </option>
      </b-field>

      <b-field label="Value" horizontal
               ## TODO: why is this needed?
               style="margin-bottom: 1rem;">
        <b-input v-model="value.value"
                 ref="value"
                 @keydown.native="inputKeydown" />
      </b-field>

      <b-field label="Units" horizontal
               style="margin-bottom: 1rem;">

        <b-button v-if="value.units.uuid"
                  @click="changeUnit()">
          {{ value.units.name }} &nbsp; &nbsp; (click to change)
        </b-button>

        <b-autocomplete v-show="!value.units.uuid"
                        v-model="unitsName"
                        ref="unitsName"
                        :data="unitsNameData"
                        field="name"
                        open-on-focus
                        keep-first
                        @select="unitsNameSelected"
                        clear-on-select>
          <template #empty>No results found</template>
        </b-autocomplete>

      </b-field>

      <div class="buttons" style="margin-left: 8rem;">
        <b-button type="is-primary"
                  ref="save"
                  @click="save"
                  :disabled="saveDisabled">
          {{ creating ? "Create" : "Update" }} Quantity
        </b-button>
        <b-button @click="$emit('cancel')">
          Cancel
        </b-button>
      </div>

    </div>
  </script>
  <script>
    const QuantityEditor = {
        template: '#quantity-editor-template',
        props: {
            name: String,
            value: Object,
            quantityType: String,
            materialTypes: Array,
            measures: Array,
            units: Array,
            creating: {
                type: Boolean,
                default: false,
            }
        },
        data() {
            return {
                measure: this.value.measure,
                valueAmount: this.value.value,
                unit: this.value.units,
                unitsName: '',
            }
        },
        computed: {

            saveDisabled() {
                if (!this.value.measure) {
                    return true
                }
                if (!this.value.value) {
                    return true
                }
                if (!this.value.units.uuid) {
                    return true
                }
                return false
            },

            unitsNameData() {
                if (!this.unitsName) {
                    return this.units
                }
                return this.units.filter((unit) => {
                    return unit.name.toLowerCase().indexOf(this.unitsName.toLowerCase()) >= 0
                })
            },
        },
        methods: {

            focusForCreate() {
                if (this.value.quantity_type.drupal_id == 'material') {
                    this.$refs.materials.focus()
                } else {
                    this.$refs.measure.focus()
                }
            },

            focusValue() {
                this.$refs.value.focus()
            },

            changeUnit() {
                this.value.units = {}
                this.$emit('input', this.value)
                this.$nextTick(() => {
                    this.$refs.unitsName.focus()
                })
            },

            unitsNameSelected(option) {
                if (option) {
                    this.value.units = option
                    this.$emit('input', this.value)
                    this.unitsName = null
                    if (this.value.measure && this.value.value) {
                        this.$nextTick(() => {
                            this.$refs.save.$el.focus()
                        })
                    }
                }
            },

            inputKeydown(event) {
                // nb. must prevent main form submit on ENTER
                // (since ultimately this lives within an outer form)
                // but also we can submit the modal pseudo-form
                if (event.which == 13) {
                    event.preventDefault()
                    this.save()
                }
            },

            save() {
                this.$emit('save', this.value)
            },
        },
    }
    Vue.component('quantity-editor', QuantityEditor)
    <% request.register_component('quantity-editor', 'QuantityEditor') %>
  </script>
</%def>

<%def name="make_quantities_editor_component()">
  <script type="text/x-template" id="quantities-editor-template">
    <div>
      <input type="hidden" :name="name" :value="value ? JSON.stringify(value) : ''" />

      <${b}-table ref="table"
                  :data="value || []"
                  detailed
                  detail-key="uuid"
                  icon-pack="fas"
                  :show-detail-icon="false">

        <${b}-table-column field="as_text"
                           v-slot="props"
                           label="Quantity">
          <span>{{ props.row.as_text }}</span>
        </${b}-table-column>

        <${b}-table-column field="quantity_type"
                           v-slot="props"
                           label="Quantity Type">
          <span>{{ props.row.quantity_type.name }}</span>
        </${b}-table-column>

        <${b}-table-column v-slot="props">
          <div v-show="!editing[props.row.uuid]">
            <a href="#"
               @click.prevent="editInit(props.row)">
              <i class="fas fa-edit" /> Edit
            </a>
            &nbsp;
            <a href="#"
               class="has-text-danger"
               @click.prevent="removeQuantity(props.row)">
              <i class="fas fa-trash" /> Remove
            </a>
          </div>
        </${b}-table-column>

        <template #detail="props">
          <quantity-editor v-model="props.row"
                           :quantity-type="props.row.quantity_type.drupal_id"
                           :material-types="materialTypes"
                           :measures="measures"
                           :units="units"
                           @save="editSave"
                           @cancel="editCancel(props.row)" />
        </template>

      </${b}-table>

      <b-field grouped
               v-show="!creating">

        <b-select v-model="quantityType">
          <option v-for="qtype of quantityTypes"
                  :value="qtype.drupal_id">
            {{ qtype.name }}
          </option>
        </b-select>

        <b-button type="is-primary"
                  icon-pack="fas"
                  icon-left="plus"
                  @click="createInit()">
          Add New Quantity
        </b-button>

      </b-field>

      <quantity-editor v-show="creating"
                       v-model="newQuantity"
                       :quantity-type="quantityType"
                       :material-types="materialTypes"
                       ref="newQuantity"
                       creating
                       @save="createSave"
                       @cancel="createCancel"
                       :measures="measures"
                       :units="units" />

    </div>
  </script>
  <script>
    const QuantitiesEditor = {
        template: '#quantities-editor-template',
        props: {
            name: String,
            value: Array,
            quantityTypes: Array,
            materialTypes: Array,
            defaultQuantityType: {
                type: String,
                default: 'standard',
            },
            measures: Array,
            units: Array,
        },
        data() {

            const editing = {}
            if (this.value) {
                for (qty of this.value) {
                    editing[qty.uuid] = false
                }
            }

            const measureMap = {}
            for (let m of this.measures) {
                measureMap[m.drupal_id] = m.name
            }

            return {
                measureMap,
                quantityType: this.defaultQuantityType,
                editShowDialog: false,
                editNew: true,
                editQuantity: null,
                editMeasure: null,
                editValue: null,
                editUnits: null,
                editing: editing,
                creating: false,
                newQuantity: {
                    measure: null,
                    value: null,
                    units: {},
                },
                newCounter: 1,
            }
        },
        methods: {

            createSave(qty) {
                qty = Object.fromEntries(Object.entries(qty))

                qty.uuid = 'new_' + this.newCounter++
                qty.as_text = this.getQuantityText(qty)

                const value = Array.from(this.value || [])
                value.push(qty)
                this.$emit('input', value)

                this.creating = false
            },

            createCancel() {
                this.creating = false
            },

            createInit() {

                this.newQuantity.quantity_type = {
                    drupal_id: this.quantityType,
                    ## TODO: add support for other quantity types
                    name: "Standard",
                }

                this.newQuantity.measure = null
                this.newQuantity.value = null
                this.newQuantity.units = {}

                this.creating = true
                this.$nextTick(() => {
                    this.$refs.newQuantity.focusForCreate()
                })
            },

            editInit(qty) {
                this.$refs.table.openDetailRow(qty)
                this.editing[qty.uuid] = true
            },

            getQuantityText(qty) {
                let text = "( " + this.measureMap[qty.measure] + " ) "
                    + qty.value + " " + qty.units.name

                if (qty.quantity_type.drupal_id == 'material') {
                    const materials = qty.material_types.map((mtype) => {
                        return mtype.name
                    }).join(', ')
                    text = materials + " " + text
                }

                return text
            },

            editSave(qty) {
                qty.as_text = this.getQuantityText(qty)
                this.$emit('input', this.value)
                this.editing[qty.uuid] = false
                this.$refs.table.closeDetailRow(qty)
            },

            editCancel(qty) {
                this.$refs.table.closeDetailRow(qty)
                this.editing[qty.uuid] = false
            },

            removeQuantity(qty) {
                let value = Array.from(this.value)
                const i = value.indexOf(qty)
                value.splice(i, 1)
                this.$emit('input', value)
            },
        },
    }
    Vue.component('quantities-editor', QuantitiesEditor)
    <% request.register_component('quantities-editor', 'QuantitiesEditor') %>
  </script>
</%def>

<%def name="make_plant_types_picker_component()">
  <script type="text/x-template" id="plant-types-picker-template">
    <div>
      <input type="hidden" :name="name" :value="value" />

      <div style="display: flex; gap: 0.5rem; align-items: center;">

        <span>Add:</span>

        <b-autocomplete v-model="addName"
                        ref="addName"
                        :data="addNameData"
                        field="name"
                        open-on-focus
                        keep-first
                        @select="addNameSelected"
                        clear-on-select
                        style="flex-grow: 1;">
          <template #empty>No results found</template>
        </b-autocomplete>

        <b-button type="is-primary"
                  icon-pack="fas"
                  icon-left="plus"
                  @click="createInit()">
          New
        </b-button>

      </div>

      <${b}-table :data="plantTypeData">

        <${b}-table-column field="name" v-slot="props">
          <span>{{ props.row.name }}</span>
        </${b}-table-column>

        <${b}-table-column v-slot="props">
            <a href="#"
               class="has-text-danger"
               @click.prevent="removePlantType(props.row)">
              <i class="fas fa-trash" /> &nbsp; Remove
            </a>
        </${b}-table-column>

      </${b}-table>

      <${b}-modal v-if="canCreate"
                  has-modal-card
                  % if request.use_oruga:
                  v-model:active="createShowDialog"
                  % else:
                  :active.sync="createShowDialog"
                  % endif
                  >
        <div class="modal-card">

          <header class="modal-card-head">
            <p class="modal-card-title">New Plant Type</p>
          </header>

          <section class="modal-card-body">
            <b-field label="Name" horizontal>
              <b-input v-model="createName"
                       ref="createName"
                       expanded
                       @keydown.native="createNameKeydown" />
            </b-field>
          </section>

          <footer class="modal-card-foot">
            <b-button type="is-primary"
                      @click="createSave()"
                      :disabled="createSaving || !createName"
                      icon-pack="fas"
                      icon-left="save">
              {{ createSaving ? "Working, please wait..." : "Save" }}
            </b-button>
            <b-button @click="createShowDialog = false">
              Cancel
            </b-button>
          </footer>
        </div>
      </${b}-modal>
    </div>
  </script>
  <script>
    const PlantTypesPicker = {
        template: '#plant-types-picker-template',
        mixins: [WuttaRequestMixin],
        props: {
            name: String,
            value: Array,
            plantTypes: Array,
            canCreate: Boolean,
        },
        data() {
            return {
                internalPlantTypes: this.plantTypes.map((pt) => {
                    return {uuid: pt[0], name: pt[1]}
                }),

                addName: '',

                createShowDialog: false,
                createName: null,
                createSaving: false,
            }
        },
        computed: {
            plantTypeData() {
                const data = []

                if (this.value) {
                    for (let ptype of this.internalPlantTypes) {
                        if (this.value.includes(ptype.uuid)) {
                            data.push(ptype)
                        }
                    }
                }

                return data
            },
            addNameData() {
                if (!this.addName) {
                    return this.internalPlantTypes
                }

                return this.internalPlantTypes.filter((ptype) => {
                    return ptype.name.toLowerCase().indexOf(this.addName.toLowerCase()) >= 0
                })
            },
        },
        methods: {

            addNameSelected(option) {
                const value = Array.from(this.value || [])

                if (!value.includes(option.uuid)) {
                    value.push(option.uuid)
                    this.$emit('input', value)
                }

                this.addName = null
            },

            createInit() {
                this.createName = this.addName
                this.createShowDialog = true
                this.$nextTick(() => {
                    this.$refs.createName.focus()
                })
            },

            createNameKeydown(event) {
                // nb. must prevent main form submit on ENTER
                // (since ultimately this lives within an outer form)
                // but also we can submit the modal pseudo-form
                if (event.which == 13) {
                    event.preventDefault()
                    this.createSave()
                }
            },

            createSave() {
                this.createSaving = true
                ## TODO
                % if not app.is_farmos_wrapper():
                const url = "${url('plant_types.ajax_create')}"
                % endif
                const params = {name: this.createName}
                this.wuttaPOST(url, params, response => {
                    this.internalPlantTypes.push(response.data)
                    const value = Array.from(this.value || [])
                    value.push(response.data.uuid)
                    this.$emit('input', value)
                    this.addName = null
                    this.createSaving = false
                    this.createShowDialog = false
                }, response => {
                    this.createSaving = false
                })
            },

            removePlantType(ptype) {
                let value = Array.from(this.value)
                const i = value.indexOf(ptype.uuid)
                value.splice(i, 1)
                this.$emit('input', value)
            },
        },
    }
    Vue.component('plant-types-picker', PlantTypesPicker)
    <% request.register_component('plant-types-picker', 'PlantTypesPicker') %>
  </script>
</%def>

<%def name="make_seasons_picker_component()">
  <script type="text/x-template" id="seasons-picker-template">
    <div>
      <input type="hidden" :name="name" :value="value" />

      <div style="display: flex; gap: 0.5rem; align-items: center;">

        <span>Add:</span>

        <b-autocomplete v-model="addName"
                        ref="addName"
                        :data="addNameData"
                        field="name"
                        open-on-focus
                        keep-first
                        @select="addNameSelected"
                        clear-on-select
                        style="flex-grow: 1;">
          <template #empty>No results found</template>
        </b-autocomplete>

        <b-button type="is-primary"
                  icon-pack="fas"
                  icon-left="plus"
                  @click="createInit()">
          New
        </b-button>

      </div>

      <${b}-table :data="seasonData">

        <${b}-table-column field="name" v-slot="props">
          <span>{{ props.row.name }}</span>
        </${b}-table-column>

        <${b}-table-column v-slot="props">
            <a href="#"
               class="has-text-danger"
               @click.prevent="removeSeason(props.row)">
              <i class="fas fa-trash" /> &nbsp; Remove
            </a>
        </${b}-table-column>

      </${b}-table>

      <${b}-modal v-if="canCreate"
                  has-modal-card
                  % if request.use_oruga:
                  v-model:active="createShowDialog"
                  % else:
                  :active.sync="createShowDialog"
                  % endif
                  >
        <div class="modal-card">

          <header class="modal-card-head">
            <p class="modal-card-title">New Season</p>
          </header>

          <section class="modal-card-body">
            <b-field label="Name" horizontal>
              <b-input v-model="createName"
                       ref="createName"
                       expanded
                       @keydown.native="createNameKeydown" />
            </b-field>
          </section>

          <footer class="modal-card-foot">
            <b-button type="is-primary"
                      @click="createSave()"
                      :disabled="createSaving || !createName"
                      icon-pack="fas"
                      icon-left="save">
              {{ createSaving ? "Working, please wait..." : "Save" }}
            </b-button>
            <b-button @click="createShowDialog = false">
              Cancel
            </b-button>
          </footer>
        </div>
      </${b}-modal>
    </div>
  </script>
  <script>
    const SeasonsPicker = {
        template: '#seasons-picker-template',
        mixins: [WuttaRequestMixin],
        props: {
            name: String,
            value: Array,
            seasons: Array,
            canCreate: Boolean,
        },
        data() {
            return {
                internalSeasons: this.seasons.map((pt) => {
                    return {uuid: pt[0], name: pt[1]}
                }),

                addName: '',

                createShowDialog: false,
                createName: null,
                createSaving: false,
            }
        },
        computed: {
            seasonData() {
                const data = []

                if (this.value) {
                    for (let ptype of this.internalSeasons) {
                        if (this.value.includes(ptype.uuid)) {
                            data.push(ptype)
                        }
                    }
                }

                return data
            },
            addNameData() {
                if (!this.addName) {
                    return this.internalSeasons
                }

                return this.internalSeasons.filter((ptype) => {
                    return ptype.name.toLowerCase().indexOf(this.addName.toLowerCase()) >= 0
                })
            },
        },
        methods: {

            addNameSelected(option) {
                const value = Array.from(this.value || [])

                if (!value.includes(option.uuid)) {
                    value.push(option.uuid)
                    this.$emit('input', value)
                }

                this.addName = null
            },

            createInit() {
                this.createName = this.addName
                this.createShowDialog = true
                this.$nextTick(() => {
                    this.$refs.createName.focus()
                })
            },

            createNameKeydown(event) {
                // nb. must prevent main form submit on ENTER
                // (since ultimately this lives within an outer form)
                // but also we can submit the modal pseudo-form
                if (event.which == 13) {
                    event.preventDefault()
                    this.createSave()
                }
            },

            createSave() {
                this.createSaving = true
                ## TODO
                % if not app.is_farmos_wrapper():
                const url = "${url('seasons.ajax_create')}"
                % endif
                const params = {name: this.createName}
                this.wuttaPOST(url, params, response => {
                    this.internalSeasons.push(response.data)
                    const value = Array.from(this.value || [])
                    value.push(response.data.uuid)
                    this.$emit('input', value)
                    this.addName = null
                    this.createSaving = false
                    this.createShowDialog = false
                }, response => {
                    this.createSaving = false
                })
            },

            removeSeason(ptype) {
                let value = Array.from(this.value)
                const i = value.indexOf(ptype.uuid)
                value.splice(i, 1)
                this.$emit('input', value)
            },
        },
    }
    Vue.component('seasons-picker', SeasonsPicker)
    <% request.register_component('seasons-picker', 'SeasonsPicker') %>
  </script>
</%def>
