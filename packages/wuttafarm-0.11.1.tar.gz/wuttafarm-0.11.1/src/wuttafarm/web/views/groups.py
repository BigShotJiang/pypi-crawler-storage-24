# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Groups
"""

from wuttafarm.web.views.assets import AssetMasterView
from wuttafarm.db.model import GroupAsset


class GroupView(AssetMasterView):
    """
    Master view for Groups
    """

    model_class = GroupAsset
    route_prefix = "group_assets"
    url_prefix = "/assets/group"

    farmos_refurl_path = "/assets/group"
    farmos_bundle = "group"

    grid_columns = [
        "thumbnail",
        "drupal_id",
        "asset_name",
        "produces_eggs",
        "archived",
    ]

    def configure_form(self, f):
        super().configure_form(f)

        # produces_eggs
        f.fields.insert_after("asset_type", "produces_eggs")


def defaults(config, **kwargs):
    base = globals()

    GroupView = kwargs.get("GroupView", base["GroupView"])
    GroupView.defaults(config)


def includeme(config):
    defaults(config)
