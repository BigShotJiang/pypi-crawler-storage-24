# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Medical Logs
"""

from wuttafarm.web.views.logs import LogMasterView
from wuttafarm.db.model import MedicalLog


class MedicalLogView(LogMasterView):
    """
    Master view for Medical Logs
    """

    model_class = MedicalLog
    route_prefix = "logs_medical"
    url_prefix = "/logs/medical"

    farmos_bundle = "medical"
    farmos_refurl_path = "/logs/medical"

    labels = {
        "vet": "Veterinarian",
    }

    grid_columns = [
        "status",
        "drupal_id",
        "timestamp",
        "message",
        "assets",
        "vet",
        "owners",
    ]

    def configure_form(self, f):
        super().configure_form(f)

        # vet
        f.fields.insert_after("timestamp", "vet")


def defaults(config, **kwargs):
    base = globals()

    MedicalLogView = kwargs.get("MedicalLogView", base["MedicalLogView"])
    MedicalLogView.defaults(config)


def includeme(config):
    defaults(config)
