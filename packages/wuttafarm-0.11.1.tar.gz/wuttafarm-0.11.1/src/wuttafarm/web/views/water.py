# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Water Assets
"""

from wuttafarm.db.model import WaterAsset
from wuttafarm.web.views.assets import AssetMasterView


class WaterAssetView(AssetMasterView):
    """
    Master view for Plant Assets
    """

    model_class = WaterAsset
    route_prefix = "water_assets"
    url_prefix = "/assets/water"

    farmos_bundle = "water"
    farmos_refurl_path = "/assets/water"

    grid_columns = [
        "thumbnail",
        "drupal_id",
        "asset_name",
        "parents",
        "archived",
    ]


def defaults(config, **kwargs):
    base = globals()

    WaterAssetView = kwargs.get("WaterAssetView", base["WaterAssetView"])
    WaterAssetView.defaults(config)


def includeme(config):
    defaults(config)
