# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Harvest Logs
"""

from wuttafarm.web.views.logs import LogMasterView
from wuttafarm.db.model import HarvestLog


class HarvestLogView(LogMasterView):
    """
    Master view for Harvest Logs
    """

    model_class = HarvestLog
    route_prefix = "logs_harvest"
    url_prefix = "/logs/harvest"

    farmos_bundle = "harvest"
    farmos_refurl_path = "/logs/harvest"

    grid_columns = [
        "status",
        "drupal_id",
        "timestamp",
        "message",
        "assets",
        "quantities",
        "owners",
    ]


def defaults(config, **kwargs):
    base = globals()

    HarvestLogView = kwargs.get("HarvestLogView", base["HarvestLogView"])
    HarvestLogView.defaults(config)


def includeme(config):
    defaults(config)
