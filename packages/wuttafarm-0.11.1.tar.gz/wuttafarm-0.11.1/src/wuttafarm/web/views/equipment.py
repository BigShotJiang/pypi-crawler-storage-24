# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Plants
"""

from wuttafarm.db.model import EquipmentType, EquipmentAsset
from wuttafarm.web.views import TaxonomyMasterView
from wuttafarm.web.views.assets import AssetMasterView
from wuttafarm.web.forms.schema import EquipmentTypeRefs


class EquipmentTypeView(TaxonomyMasterView):
    """
    Master view for Equipment Types
    """

    model_class = EquipmentType
    route_prefix = "equipment_types"
    url_prefix = "/equipment-types"

    farmos_route_prefix = "farmos_equipment_types"
    farmos_entity_type = "taxonomy_term"
    farmos_bundle = "equipment_type"
    farmos_refurl_path = "/admin/structure/taxonomy/manage/equipment_type/overview"


class EquipmentAssetView(AssetMasterView):
    """
    Master view for Equipment Assets
    """

    model_class = EquipmentAsset
    route_prefix = "equipment_assets"
    url_prefix = "/assets/equipment"

    farmos_bundle = "equipment"
    farmos_refurl_path = "/assets/equipment"

    labels = {
        "equipment_types": "Equipment Type",
    }

    def configure_form(self, form):
        f = form
        super().configure_form(f)
        equipment = f.model_instance

        # equipment_types
        f.fields.insert_after("asset_name", "equipment_types")
        f.set_node("equipment_types", EquipmentTypeRefs(self.request))
        if not self.creating:
            # nb. must explcitly declare value for non-standard field
            f.set_default("equipment_types", equipment.equipment_types)

        # manufacturer
        f.fields.insert_after("equipment_types", "manufacturer")

        # model
        f.fields.insert_after("manufacturer", "model")

        # serial_number
        f.fields.insert_after("model", "serial_number")

    def objectify(self, form):
        equipment = super().objectify(form)
        data = form.validated

        self.set_equipment_types(equipment, data["equipment_types"])

        return equipment

    def set_equipment_types(self, equipment, desired):
        model = self.app.model
        session = self.Session()
        current = [str(etype.uuid) for etype in equipment.equipment_types]

        for etype in desired:
            if etype["uuid"] not in current:
                equipment_type = session.get(model.EquipmentType, etype["uuid"])
                assert equipment_type
                equipment.equipment_types.append(equipment_type)

        desired = [etype["uuid"] for etype in desired]
        for uuid in current:
            if uuid not in desired:
                equipment_type = session.get(model.EquipmentType, uuid)
                assert equipment_type
                equipment.equipment_types.remove(equipment_type)


def defaults(config, **kwargs):
    base = globals()

    EquipmentTypeView = kwargs.get("EquipmentTypeView", base["EquipmentTypeView"])
    EquipmentTypeView.defaults(config)

    EquipmentAssetView = kwargs.get("EquipmentAssetView", base["EquipmentAssetView"])
    EquipmentAssetView.defaults(config)


def includeme(config):
    defaults(config)
