# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Material Types
"""

from wuttafarm.web.views import TaxonomyMasterView
from wuttafarm.db.model import MaterialType


class MaterialTypeView(TaxonomyMasterView):
    """
    Master view for Material Types
    """

    model_class = MaterialType
    route_prefix = "material_types"
    url_prefix = "/material-types"

    farmos_route_prefix = "farmos_material_types"
    farmos_bundle = "material_type"
    farmos_refurl_path = "/admin/structure/taxonomy/manage/material_type/overview"


def defaults(config, **kwargs):
    base = globals()

    MaterialTypeView = kwargs.get("MaterialTypeView", base["MaterialTypeView"])
    MaterialTypeView.defaults(config)


def includeme(config):
    defaults(config)
