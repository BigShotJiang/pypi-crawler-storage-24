# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS Seeding Logs
"""

from wuttaweb.forms.schema import WuttaDateTime
from wuttaweb.forms.widgets import WuttaDateTimeWidget

from wuttafarm.web.views.farmos.logs import LogMasterView
from wuttafarm.web.grids import SimpleSorter, StringFilter


class SeedingLogView(LogMasterView):
    """
    View for farmOS seeding logs
    """

    model_name = "farmos_seeding_log"
    model_title = "farmOS Seeding Log"
    model_title_plural = "farmOS Seeding Logs"

    route_prefix = "farmos_logs_seeding"
    url_prefix = "/farmOS/logs/seeding"

    farmos_log_type = "seeding"
    farmos_refurl_path = "/logs/seeding"

    grid_columns = [
        "status",
        "drupal_id",
        "timestamp",
        "name",
        "assets",
        "locations",
        "purchase_date",
        "source",
        "is_group_assignment",
        "owners",
    ]

    def normalize_log(self, log, included):
        data = super().normalize_log(log, included)
        data.update(
            {
                "source": log["attributes"]["source"],
                "purchase_date": self.normal.normalize_datetime(
                    log["attributes"]["purchase_date"]
                ),
                "lot_number": log["attributes"]["lot_number"],
            }
        )
        return data

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # purchase_date
        g.set_renderer("purchase_date", "date")

    def configure_form(self, form):
        f = form
        super().configure_form(f)

        # source
        f.fields.insert_after("timestamp", "source")

        # purchase_date
        f.fields.insert_after("source", "purchase_date")
        f.set_node("purchase_date", WuttaDateTime())
        f.set_widget("purchase_date", WuttaDateTimeWidget(self.request))

        # lot_number
        f.fields.insert_after("purchase_date", "lot_number")


def defaults(config, **kwargs):
    base = globals()

    SeedingLogView = kwargs.get("SeedingLogView", base["SeedingLogView"])
    SeedingLogView.defaults(config)


def includeme(config):
    defaults(config)
