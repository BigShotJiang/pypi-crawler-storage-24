# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS Medical Logs
"""

from wuttafarm.web.views.farmos.logs import LogMasterView
from wuttafarm.web.grids import SimpleSorter, StringFilter


class MedicalLogView(LogMasterView):
    """
    View for farmOS medical logs
    """

    model_name = "farmos_medical_log"
    model_title = "farmOS Medical Log"
    model_title_plural = "farmOS Medical Logs"

    route_prefix = "farmos_logs_medical"
    url_prefix = "/farmOS/logs/medical"

    farmos_log_type = "medical"
    farmos_refurl_path = "/logs/medical"

    labels = {
        "vet": "Veterinarian",
    }

    grid_columns = [
        "status",
        "drupal_id",
        "timestamp",
        "name",
        "assets",
        "vet",
        "owners",
    ]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # vet
        g.set_sorter("vet", SimpleSorter("vet"))
        g.set_filter("vet", StringFilter)

    def configure_form(self, form):
        f = form
        super().configure_form(f)

        # vet
        f.fields.insert_after("timestamp", "vet")


def defaults(config, **kwargs):
    base = globals()

    MedicalLogView = kwargs.get("MedicalLogView", base["MedicalLogView"])
    MedicalLogView.defaults(config)


def includeme(config):
    defaults(config)
