# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Water Assets in farmOS
"""

from wuttafarm.web.views.farmos.assets import AssetMasterView


class WaterAssetView(AssetMasterView):
    """
    Master view for farmOS Water Assets
    """

    model_name = "farmos_water_assets"
    model_title = "farmOS Water Asset"
    model_title_plural = "farmOS Water Assets"

    route_prefix = "farmos_water_assets"
    url_prefix = "/farmOS/assets/water"

    farmos_asset_type = "water"
    farmos_refurl_path = "/assets/water"

    grid_columns = [
        "thumbnail",
        "drupal_id",
        "name",
        "archived",
    ]

    def get_xref_buttons(self, water):
        model = self.app.model
        session = self.Session()
        buttons = super().get_xref_buttons(water)

        if wf_water := (
            session.query(model.Asset)
            .filter(model.Asset.farmos_uuid == water["uuid"])
            .first()
        ):
            buttons.append(
                self.make_button(
                    f"View {self.app.get_title()} record",
                    primary=True,
                    url=self.request.route_url("water_assets.view", uuid=wf_water.uuid),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    WaterAssetView = kwargs.get("WaterAssetView", base["WaterAssetView"])
    WaterAssetView.defaults(config)


def includeme(config):
    defaults(config)
