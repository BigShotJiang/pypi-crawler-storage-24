# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS materials
"""

from wuttafarm.web.views.farmos.master import TaxonomyMasterView


class MaterialTypeView(TaxonomyMasterView):
    """
    Master view for Material Types in farmOS.
    """

    model_name = "farmos_material_type"
    model_title = "farmOS Material Type"
    model_title_plural = "farmOS Material Types"

    route_prefix = "farmos_material_types"
    url_prefix = "/farmOS/material-types"

    farmos_taxonomy_type = "material_type"
    farmos_refurl_path = "/admin/structure/taxonomy/manage/material_type/overview"

    def get_xref_buttons(self, material_type):
        buttons = super().get_xref_buttons(material_type)
        model = self.app.model
        session = self.Session()

        if wf_material_type := (
            session.query(model.MaterialType)
            .filter(model.MaterialType.farmos_uuid == material_type["uuid"])
            .first()
        ):
            buttons.append(
                self.make_button(
                    f"View {self.app.get_title()} record",
                    primary=True,
                    url=self.request.route_url(
                        "material_types.view", uuid=wf_material_type.uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    MaterialTypeView = kwargs.get("MaterialTypeView", base["MaterialTypeView"])
    MaterialTypeView.defaults(config)


def includeme(config):
    defaults(config)
