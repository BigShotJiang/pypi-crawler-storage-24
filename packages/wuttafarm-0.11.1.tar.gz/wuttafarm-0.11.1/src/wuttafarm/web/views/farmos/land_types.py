# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS land types
"""

from wuttafarm.web.views.farmos import FarmOSMasterView


class LandTypeView(FarmOSMasterView):
    """
    Master view for Land Types in farmOS.
    """

    model_name = "farmos_land_type"
    model_title = "farmOS Land Type"
    model_title_plural = "farmOS Land Types"

    route_prefix = "farmos_land_types"
    url_prefix = "/farmOS/land-types"

    grid_columns = [
        "label",
    ]

    sort_defaults = "label"

    form_fields = [
        "label",
    ]

    def get_grid_data(self, columns=None, session=None):
        land_types = self.farmos_client.resource.get("land_type", "land_type")
        return [self.normalize_land_type(t) for t in land_types["data"]]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # label
        g.set_link("label")
        g.set_searchable("label")

    def get_instance(self):
        land_type = self.farmos_client.resource.get_id(
            "land_type", "land_type", self.request.matchdict["uuid"]
        )
        self.raw_json = land_type
        return self.normalize_land_type(land_type["data"])

    def get_instance_title(self, land_type):
        return land_type["label"]

    def normalize_land_type(self, land_type):
        return {
            "uuid": land_type["id"],
            "drupal_id": land_type["attributes"]["drupal_internal__id"],
            "label": land_type["attributes"]["label"],
        }

    def get_xref_buttons(self, land_type):
        model = self.app.model
        session = self.Session()
        buttons = []

        if wf_land_type := (
            session.query(model.LandType)
            .filter(model.LandType.farmos_uuid == land_type["uuid"])
            .first()
        ):
            buttons.append(
                self.make_button(
                    f"View {self.app.get_title()} record",
                    primary=True,
                    url=self.request.route_url(
                        "land_types.view", uuid=wf_land_type.uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    LandTypeView = kwargs.get("LandTypeView", base["LandTypeView"])
    LandTypeView.defaults(config)


def includeme(config):
    defaults(config)
