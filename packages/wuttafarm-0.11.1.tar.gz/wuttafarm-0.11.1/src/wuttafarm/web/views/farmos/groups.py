# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS Groups
"""

import datetime

import colander

from wuttafarm.web.views.farmos import FarmOSMasterView
from wuttaweb.forms.schema import WuttaDateTime
from wuttaweb.forms.widgets import WuttaDateTimeWidget


class GroupView(FarmOSMasterView):
    """
    View for farmOS Groups
    """

    model_name = "farmos_group"
    model_title = "farmOS Group"
    model_title_plural = "farmOS Groups"

    route_prefix = "farmos_group_assets"
    url_prefix = "/farmOS/groups"

    farmos_refurl_path = "/assets/group"

    grid_columns = [
        "name",
        "is_fixed",
        "is_location",
        "archived",
        "changed",
    ]

    sort_defaults = "name"

    form_fields = [
        "name",
        "is_fixed",
        "is_location",
        "archived",
        "notes",
        "created",
        "changed",
    ]

    def get_grid_data(self, columns=None, session=None):
        groups = self.farmos_client.resource.get("asset", "group")
        return [self.normalize_group(a) for a in groups["data"]]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # name
        g.set_link("name")
        g.set_searchable("name")

        # is_fixed
        g.set_renderer("is_fixed", "boolean")

        # is_location
        g.set_renderer("is_location", "boolean")

        # changed
        g.set_renderer("changed", "datetime")

        # archived
        g.set_renderer("archived", "boolean")

    def get_instance(self):
        group = self.farmos_client.resource.get_id(
            "asset", "group", self.request.matchdict["uuid"]
        )
        self.raw_json = group
        return self.normalize_group(group["data"])

    def get_instance_title(self, group):
        return group["name"]

    def normalize_group(self, group):

        if created := group["attributes"].get("created"):
            created = datetime.datetime.fromisoformat(created)
            created = self.app.localtime(created)

        if changed := group["attributes"].get("changed"):
            changed = datetime.datetime.fromisoformat(changed)
            changed = self.app.localtime(changed)

        if self.farmos_4x:
            archived = group["attributes"]["archived"]
        else:
            archived = group["attributes"]["status"] == "archived"

        if notes := group["attributes"]["notes"]:
            notes = notes["value"]

        return {
            "uuid": group["id"],
            "drupal_id": group["attributes"]["drupal_internal__id"],
            "name": group["attributes"]["name"],
            "created": created,
            "changed": changed,
            "is_fixed": group["attributes"]["is_fixed"],
            "is_location": group["attributes"]["is_location"],
            "archived": archived,
            "notes": notes or colander.null,
        }

    def configure_form(self, form):
        f = form
        super().configure_form(f)

        # is_fixed
        f.set_node("is_fixed", colander.Boolean())

        # is_location
        f.set_node("is_location", colander.Boolean())

        # notes
        f.set_widget("notes", "notes")

        # created
        f.set_node("created", WuttaDateTime())
        f.set_widget("created", WuttaDateTimeWidget(self.request))

        # changed
        f.set_node("changed", WuttaDateTime())
        f.set_widget("changed", WuttaDateTimeWidget(self.request))

        # archived
        f.set_node("archived", colander.Boolean())

    def get_xref_buttons(self, group):
        model = self.app.model
        session = self.Session()

        buttons = [
            self.make_button(
                "View in farmOS",
                primary=True,
                url=self.app.get_farmos_url(f"/asset/{group['drupal_id']}"),
                target="_blank",
                icon_left="external-link-alt",
            ),
        ]

        if wf_group := (
            session.query(model.GroupAsset)
            .filter(model.GroupAsset.farmos_uuid == group["uuid"])
            .first()
        ):
            buttons.append(
                self.make_button(
                    f"View {self.app.get_title()} record",
                    primary=True,
                    url=self.request.route_url("group_assets.view", uuid=wf_group.uuid),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    GroupView = kwargs.get("GroupView", base["GroupView"])
    GroupView.defaults(config)


def includeme(config):
    defaults(config)
