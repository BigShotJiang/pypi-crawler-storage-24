"""add WebhookChange

Revision ID: dd4d4142b96d
Revises: dca5b48a5562
Create Date: 2026-03-10 22:31:54.324952

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "dd4d4142b96d"
down_revision: Union[str, None] = "dca5b48a5562"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # webhook_change
    op.create_table(
        "webhook_change",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("entity_type", sa.String(length=100), nullable=False),
        sa.Column("bundle", sa.String(length=100), nullable=False),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("deleted", sa.Boolean(), nullable=False),
        sa.Column("received", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_webhook_change")),
    )


def downgrade() -> None:

    # webhook_change
    op.drop_table("webhook_change")
