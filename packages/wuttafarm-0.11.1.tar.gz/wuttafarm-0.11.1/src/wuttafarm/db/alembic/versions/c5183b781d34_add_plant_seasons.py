"""add plant seasons

Revision ID: c5183b781d34
Revises: 5f474125a80e
Create Date: 2026-03-06 20:18:40.160531

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "c5183b781d34"
down_revision: Union[str, None] = "5f474125a80e"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # season
    op.create_table(
        "season",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("description", sa.String(length=255), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_season")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_season_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_season_farmos_uuid")),
        sa.UniqueConstraint("name", name=op.f("uq_season_name")),
    )
    op.create_table(
        "season_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column(
            "description", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_season_version")
        ),
    )
    op.create_index(
        op.f("ix_season_version_end_transaction_id"),
        "season_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_season_version_operation_type"),
        "season_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_season_version_pk_transaction_id",
        "season_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_season_version_pk_validity",
        "season_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_season_version_transaction_id"),
        "season_version",
        ["transaction_id"],
        unique=False,
    )

    # asset_plant_season
    op.create_table(
        "asset_plant_season",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("plant_asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("season_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["plant_asset_uuid"],
            ["asset_plant.uuid"],
            name=op.f("fk_asset_plant_season_plant_asset_uuid_asset_plant"),
        ),
        sa.ForeignKeyConstraint(
            ["season_uuid"],
            ["season.uuid"],
            name=op.f("fk_asset_plant_season_season_uuid_season"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_plant_season")),
    )
    op.create_table(
        "asset_plant_season_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "plant_asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "season_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_plant_season_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_plant_season_version_end_transaction_id"),
        "asset_plant_season_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_plant_season_version_operation_type"),
        "asset_plant_season_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_plant_season_version_pk_transaction_id",
        "asset_plant_season_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_plant_season_version_pk_validity",
        "asset_plant_season_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_plant_season_version_transaction_id"),
        "asset_plant_season_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # asset_plant_season
    op.drop_index(
        op.f("ix_asset_plant_season_version_transaction_id"),
        table_name="asset_plant_season_version",
    )
    op.drop_index(
        "ix_asset_plant_season_version_pk_validity",
        table_name="asset_plant_season_version",
    )
    op.drop_index(
        "ix_asset_plant_season_version_pk_transaction_id",
        table_name="asset_plant_season_version",
    )
    op.drop_index(
        op.f("ix_asset_plant_season_version_operation_type"),
        table_name="asset_plant_season_version",
    )
    op.drop_index(
        op.f("ix_asset_plant_season_version_end_transaction_id"),
        table_name="asset_plant_season_version",
    )
    op.drop_table("asset_plant_season_version")
    op.drop_table("asset_plant_season")

    # season
    op.drop_index(op.f("ix_season_version_transaction_id"), table_name="season_version")
    op.drop_index("ix_season_version_pk_validity", table_name="season_version")
    op.drop_index("ix_season_version_pk_transaction_id", table_name="season_version")
    op.drop_index(op.f("ix_season_version_operation_type"), table_name="season_version")
    op.drop_index(
        op.f("ix_season_version_end_transaction_id"), table_name="season_version"
    )
    op.drop_table("season_version")
    op.drop_table("season")
