"""add WaterAsset

Revision ID: de1197d24485
Revises: 9c53513f8862
Create Date: 2026-03-09 14:59:12.032318

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "de1197d24485"
down_revision: Union[str, None] = "9c53513f8862"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # asset_water
    op.create_table(
        "asset_water",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["uuid"], ["asset.uuid"], name=op.f("fk_asset_water_uuid_asset")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_water")),
    )
    op.create_table(
        "asset_water_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_water_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_water_version_end_transaction_id"),
        "asset_water_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_water_version_operation_type"),
        "asset_water_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_water_version_pk_transaction_id",
        "asset_water_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_water_version_pk_validity",
        "asset_water_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_water_version_transaction_id"),
        "asset_water_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # asset_water
    op.drop_index(
        op.f("ix_asset_water_version_transaction_id"), table_name="asset_water_version"
    )
    op.drop_index(
        "ix_asset_water_version_pk_validity", table_name="asset_water_version"
    )
    op.drop_index(
        "ix_asset_water_version_pk_transaction_id", table_name="asset_water_version"
    )
    op.drop_index(
        op.f("ix_asset_water_version_operation_type"), table_name="asset_water_version"
    )
    op.drop_index(
        op.f("ix_asset_water_version_end_transaction_id"),
        table_name="asset_water_version",
    )
    op.drop_table("asset_water_version")
    op.drop_table("asset_water")
