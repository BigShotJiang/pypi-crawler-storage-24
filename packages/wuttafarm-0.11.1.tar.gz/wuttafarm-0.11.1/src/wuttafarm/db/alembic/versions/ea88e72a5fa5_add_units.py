"""add Units

Revision ID: ea88e72a5fa5
Revises: 82a03f4ef1a4
Create Date: 2026-02-18 20:01:40.720138

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "ea88e72a5fa5"
down_revision: Union[str, None] = "82a03f4ef1a4"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # unit
    op.create_table(
        "unit",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("description", sa.String(length=255), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_unit")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_unit_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_unit_farmos_uuid")),
        sa.UniqueConstraint("name", name=op.f("uq_unit_name")),
    )
    op.create_table(
        "unit_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column(
            "description", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint("uuid", "transaction_id", name=op.f("pk_unit_version")),
    )
    op.create_index(
        op.f("ix_unit_version_end_transaction_id"),
        "unit_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_unit_version_operation_type"),
        "unit_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_unit_version_pk_transaction_id",
        "unit_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_unit_version_pk_validity",
        "unit_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_unit_version_transaction_id"),
        "unit_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # unit
    op.drop_index(op.f("ix_unit_version_transaction_id"), table_name="unit_version")
    op.drop_index("ix_unit_version_pk_validity", table_name="unit_version")
    op.drop_index("ix_unit_version_pk_transaction_id", table_name="unit_version")
    op.drop_index(op.f("ix_unit_version_operation_type"), table_name="unit_version")
    op.drop_index(op.f("ix_unit_version_end_transaction_id"), table_name="unit_version")
    op.drop_table("unit_version")
    op.drop_table("unit")
