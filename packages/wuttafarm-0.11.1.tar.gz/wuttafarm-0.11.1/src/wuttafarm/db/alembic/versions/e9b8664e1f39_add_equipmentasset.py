"""add EquipmentAsset

Revision ID: e9b8664e1f39
Revises: e5b27eac471c
Create Date: 2026-03-09 18:05:54.917562

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "e9b8664e1f39"
down_revision: Union[str, None] = "e5b27eac471c"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # asset_equipment
    op.create_table(
        "asset_equipment",
        sa.Column("manufacturer", sa.String(length=255), nullable=True),
        sa.Column("model", sa.String(length=255), nullable=True),
        sa.Column("serial_number", sa.String(length=255), nullable=True),
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["uuid"], ["asset.uuid"], name=op.f("fk_asset_equipment_uuid_asset")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_equipment")),
    )
    op.create_table(
        "asset_equipment_version",
        sa.Column(
            "manufacturer", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column("model", sa.String(length=255), autoincrement=False, nullable=True),
        sa.Column(
            "serial_number", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_equipment_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_equipment_version_end_transaction_id"),
        "asset_equipment_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_equipment_version_operation_type"),
        "asset_equipment_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_equipment_version_pk_transaction_id",
        "asset_equipment_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_equipment_version_pk_validity",
        "asset_equipment_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_equipment_version_transaction_id"),
        "asset_equipment_version",
        ["transaction_id"],
        unique=False,
    )

    # asset_equipment_equipment_type
    op.create_table(
        "asset_equipment_equipment_type",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("equipment_asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("equipment_type_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["equipment_asset_uuid"],
            ["asset_equipment.uuid"],
            name=op.f(
                "fk_asset_equipment_equipment_type_equipment_asset_uuid_asset_equipment"
            ),
        ),
        sa.ForeignKeyConstraint(
            ["equipment_type_uuid"],
            ["equipment_type.uuid"],
            name=op.f(
                "fk_asset_equipment_equipment_type_equipment_type_uuid_equipment_type"
            ),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_equipment_equipment_type")),
    )
    op.create_table(
        "asset_equipment_equipment_type_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "equipment_asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "equipment_type_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid",
            "transaction_id",
            name=op.f("pk_asset_equipment_equipment_type_version"),
        ),
    )
    op.create_index(
        op.f("ix_asset_equipment_equipment_type_version_end_transaction_id"),
        "asset_equipment_equipment_type_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_equipment_equipment_type_version_operation_type"),
        "asset_equipment_equipment_type_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_equipment_equipment_type_version_pk_transaction_id",
        "asset_equipment_equipment_type_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_equipment_equipment_type_version_pk_validity",
        "asset_equipment_equipment_type_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_equipment_equipment_type_version_transaction_id"),
        "asset_equipment_equipment_type_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # asset_equipment_equipment_type
    op.drop_index(
        op.f("ix_asset_equipment_equipment_type_version_transaction_id"),
        table_name="asset_equipment_equipment_type_version",
    )
    op.drop_index(
        "ix_asset_equipment_equipment_type_version_pk_validity",
        table_name="asset_equipment_equipment_type_version",
    )
    op.drop_index(
        "ix_asset_equipment_equipment_type_version_pk_transaction_id",
        table_name="asset_equipment_equipment_type_version",
    )
    op.drop_index(
        op.f("ix_asset_equipment_equipment_type_version_operation_type"),
        table_name="asset_equipment_equipment_type_version",
    )
    op.drop_index(
        op.f("ix_asset_equipment_equipment_type_version_end_transaction_id"),
        table_name="asset_equipment_equipment_type_version",
    )
    op.drop_table("asset_equipment_equipment_type_version")
    op.drop_table("asset_equipment_equipment_type")

    # asset_equipment
    op.drop_index(
        op.f("ix_asset_equipment_version_transaction_id"),
        table_name="asset_equipment_version",
    )
    op.drop_index(
        "ix_asset_equipment_version_pk_validity", table_name="asset_equipment_version"
    )
    op.drop_index(
        "ix_asset_equipment_version_pk_transaction_id",
        table_name="asset_equipment_version",
    )
    op.drop_index(
        op.f("ix_asset_equipment_version_operation_type"),
        table_name="asset_equipment_version",
    )
    op.drop_index(
        op.f("ix_asset_equipment_version_end_transaction_id"),
        table_name="asset_equipment_version",
    )
    op.drop_table("asset_equipment_version")
    op.drop_table("asset_equipment")
