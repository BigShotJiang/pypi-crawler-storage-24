"""add MaterialType

Revision ID: 1c89f3fbb521
Revises: 82a497e30a97
Create Date: 2026-03-08 14:38:04.538621

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "1c89f3fbb521"
down_revision: Union[str, None] = "82a497e30a97"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # material_type
    op.create_table(
        "material_type",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("description", sa.String(length=255), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_material_type")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_material_type_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_material_type_farmos_uuid")),
    )
    op.create_table(
        "material_type_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column(
            "description", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_material_type_version")
        ),
    )
    op.create_index(
        op.f("ix_material_type_version_end_transaction_id"),
        "material_type_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_material_type_version_operation_type"),
        "material_type_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_material_type_version_pk_transaction_id",
        "material_type_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_material_type_version_pk_validity",
        "material_type_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_material_type_version_transaction_id"),
        "material_type_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # material_type
    op.drop_index(
        op.f("ix_material_type_version_transaction_id"),
        table_name="material_type_version",
    )
    op.drop_index(
        "ix_material_type_version_pk_validity", table_name="material_type_version"
    )
    op.drop_index(
        "ix_material_type_version_pk_transaction_id", table_name="material_type_version"
    )
    op.drop_index(
        op.f("ix_material_type_version_operation_type"),
        table_name="material_type_version",
    )
    op.drop_index(
        op.f("ix_material_type_version_end_transaction_id"),
        table_name="material_type_version",
    )
    op.drop_table("material_type_version")
    op.drop_table("material_type")
