"""add LogGroup

Revision ID: 74d32b4ec210
Revises: 3bef7d380a38
Create Date: 2026-02-28 21:35:24.125784

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "74d32b4ec210"
down_revision: Union[str, None] = "3bef7d380a38"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log_group
    op.create_table(
        "log_group",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("log_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["asset_uuid"], ["asset.uuid"], name=op.f("fk_log_group_asset_uuid_asset")
        ),
        sa.ForeignKeyConstraint(
            ["log_uuid"], ["log.uuid"], name=op.f("fk_log_group_log_uuid_log")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_group")),
    )
    op.create_table(
        "log_group_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "log_uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=True
        ),
        sa.Column(
            "asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_group_version")
        ),
    )
    op.create_index(
        op.f("ix_log_group_version_end_transaction_id"),
        "log_group_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_group_version_operation_type"),
        "log_group_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_group_version_pk_transaction_id",
        "log_group_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_group_version_pk_validity",
        "log_group_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_group_version_transaction_id"),
        "log_group_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # log_group
    op.drop_index(
        op.f("ix_log_group_version_transaction_id"), table_name="log_group_version"
    )
    op.drop_index("ix_log_group_version_pk_validity", table_name="log_group_version")
    op.drop_index(
        "ix_log_group_version_pk_transaction_id", table_name="log_group_version"
    )
    op.drop_index(
        op.f("ix_log_group_version_operation_type"), table_name="log_group_version"
    )
    op.drop_index(
        op.f("ix_log_group_version_end_transaction_id"), table_name="log_group_version"
    )
    op.drop_table("log_group_version")
    op.drop_table("log_group")
