"""add Plant Assets and more Logs

Revision ID: 11e0e46f48a6
Revises: dd6351e69233
Create Date: 2026-02-18 18:11:46.536930

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "11e0e46f48a6"
down_revision: Union[str, None] = "dd6351e69233"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # plant_type
    op.create_table(
        "plant_type",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("description", sa.String(length=255), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_plant_type")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_plant_type_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_plant_type_farmos_uuid")),
        sa.UniqueConstraint("name", name=op.f("uq_plant_type_name")),
    )
    op.create_table(
        "plant_type_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column(
            "description", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_plant_type_version")
        ),
    )
    op.create_index(
        op.f("ix_plant_type_version_end_transaction_id"),
        "plant_type_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_plant_type_version_operation_type"),
        "plant_type_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_plant_type_version_pk_transaction_id",
        "plant_type_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_plant_type_version_pk_validity",
        "plant_type_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_plant_type_version_transaction_id"),
        "plant_type_version",
        ["transaction_id"],
        unique=False,
    )

    # asset_plant
    op.create_table(
        "asset_plant",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["uuid"], ["asset.uuid"], name=op.f("fk_asset_plant_uuid_asset")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_plant")),
    )
    op.create_table(
        "asset_plant_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_plant_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_plant_version_end_transaction_id"),
        "asset_plant_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_plant_version_operation_type"),
        "asset_plant_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_plant_version_pk_transaction_id",
        "asset_plant_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_plant_version_pk_validity",
        "asset_plant_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_plant_version_transaction_id"),
        "asset_plant_version",
        ["transaction_id"],
        unique=False,
    )

    # asset_plant_plant_type
    op.create_table(
        "asset_plant_plant_type",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("plant_asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("plant_type_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["plant_asset_uuid"],
            ["asset_plant.uuid"],
            name=op.f("fk_asset_plant_plant_type_plant_asset_uuid_asset_plant"),
        ),
        sa.ForeignKeyConstraint(
            ["plant_type_uuid"],
            ["plant_type.uuid"],
            name=op.f("fk_asset_plant_plant_type_plant_type_uuid_plant_type"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_plant_plant_type")),
    )
    op.create_table(
        "asset_plant_plant_type_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "plant_asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "plant_type_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_plant_plant_type_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_plant_plant_type_version_end_transaction_id"),
        "asset_plant_plant_type_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_plant_plant_type_version_operation_type"),
        "asset_plant_plant_type_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_plant_plant_type_version_pk_transaction_id",
        "asset_plant_plant_type_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_plant_plant_type_version_pk_validity",
        "asset_plant_plant_type_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_plant_plant_type_version_transaction_id"),
        "asset_plant_plant_type_version",
        ["transaction_id"],
        unique=False,
    )

    # log_asset
    op.create_table(
        "log_asset",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("log_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["asset_uuid"], ["asset.uuid"], name=op.f("fk_log_asset_asset_uuid_asset")
        ),
        sa.ForeignKeyConstraint(
            ["log_uuid"], ["log.uuid"], name=op.f("fk_log_asset_log_uuid_log")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_asset")),
    )
    op.create_table(
        "log_asset_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "log_uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=True
        ),
        sa.Column(
            "asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_asset_version")
        ),
    )
    op.create_index(
        op.f("ix_log_asset_version_end_transaction_id"),
        "log_asset_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_asset_version_operation_type"),
        "log_asset_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_asset_version_pk_transaction_id",
        "log_asset_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_asset_version_pk_validity",
        "log_asset_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_asset_version_transaction_id"),
        "log_asset_version",
        ["transaction_id"],
        unique=False,
    )

    # log_harvest
    op.create_table(
        "log_harvest",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["uuid"], ["log.uuid"], name=op.f("fk_log_harvest_uuid_log")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_harvest")),
    )
    op.create_table(
        "log_harvest_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_harvest_version")
        ),
    )
    op.create_index(
        op.f("ix_log_harvest_version_end_transaction_id"),
        "log_harvest_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_harvest_version_operation_type"),
        "log_harvest_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_harvest_version_pk_transaction_id",
        "log_harvest_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_harvest_version_pk_validity",
        "log_harvest_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_harvest_version_transaction_id"),
        "log_harvest_version",
        ["transaction_id"],
        unique=False,
    )

    # log_medical
    op.create_table(
        "log_medical",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["uuid"], ["log.uuid"], name=op.f("fk_log_medical_uuid_log")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_medical")),
    )
    op.create_table(
        "log_medical_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_medical_version")
        ),
    )
    op.create_index(
        op.f("ix_log_medical_version_end_transaction_id"),
        "log_medical_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_medical_version_operation_type"),
        "log_medical_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_medical_version_pk_transaction_id",
        "log_medical_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_medical_version_pk_validity",
        "log_medical_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_medical_version_transaction_id"),
        "log_medical_version",
        ["transaction_id"],
        unique=False,
    )

    # log_observation
    op.create_table(
        "log_observation",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["uuid"], ["log.uuid"], name=op.f("fk_log_observation_uuid_log")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_observation")),
    )
    op.create_table(
        "log_observation_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_observation_version")
        ),
    )
    op.create_index(
        op.f("ix_log_observation_version_end_transaction_id"),
        "log_observation_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_observation_version_operation_type"),
        "log_observation_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_observation_version_pk_transaction_id",
        "log_observation_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_observation_version_pk_validity",
        "log_observation_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_observation_version_transaction_id"),
        "log_observation_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # log_observation
    op.drop_index(
        op.f("ix_log_observation_version_transaction_id"),
        table_name="log_observation_version",
    )
    op.drop_index(
        "ix_log_observation_version_pk_validity", table_name="log_observation_version"
    )
    op.drop_index(
        "ix_log_observation_version_pk_transaction_id",
        table_name="log_observation_version",
    )
    op.drop_index(
        op.f("ix_log_observation_version_operation_type"),
        table_name="log_observation_version",
    )
    op.drop_index(
        op.f("ix_log_observation_version_end_transaction_id"),
        table_name="log_observation_version",
    )
    op.drop_table("log_observation_version")
    op.drop_table("log_observation")

    # log_medical
    op.drop_index(
        op.f("ix_log_medical_version_transaction_id"), table_name="log_medical_version"
    )
    op.drop_index(
        "ix_log_medical_version_pk_validity", table_name="log_medical_version"
    )
    op.drop_index(
        "ix_log_medical_version_pk_transaction_id", table_name="log_medical_version"
    )
    op.drop_index(
        op.f("ix_log_medical_version_operation_type"), table_name="log_medical_version"
    )
    op.drop_index(
        op.f("ix_log_medical_version_end_transaction_id"),
        table_name="log_medical_version",
    )
    op.drop_table("log_medical_version")
    op.drop_table("log_medical")

    # log_harvest
    op.drop_index(
        op.f("ix_log_harvest_version_transaction_id"), table_name="log_harvest_version"
    )
    op.drop_index(
        "ix_log_harvest_version_pk_validity", table_name="log_harvest_version"
    )
    op.drop_index(
        "ix_log_harvest_version_pk_transaction_id", table_name="log_harvest_version"
    )
    op.drop_index(
        op.f("ix_log_harvest_version_operation_type"), table_name="log_harvest_version"
    )
    op.drop_index(
        op.f("ix_log_harvest_version_end_transaction_id"),
        table_name="log_harvest_version",
    )
    op.drop_table("log_harvest_version")
    op.drop_table("log_harvest")

    # log_asset
    op.drop_index(
        op.f("ix_log_asset_version_transaction_id"), table_name="log_asset_version"
    )
    op.drop_index("ix_log_asset_version_pk_validity", table_name="log_asset_version")
    op.drop_index(
        "ix_log_asset_version_pk_transaction_id", table_name="log_asset_version"
    )
    op.drop_index(
        op.f("ix_log_asset_version_operation_type"), table_name="log_asset_version"
    )
    op.drop_index(
        op.f("ix_log_asset_version_end_transaction_id"), table_name="log_asset_version"
    )
    op.drop_table("log_asset_version")
    op.drop_table("log_asset")

    # asset_plant_plant_type
    op.drop_index(
        op.f("ix_asset_plant_plant_type_version_transaction_id"),
        table_name="asset_plant_plant_type_version",
    )
    op.drop_index(
        "ix_asset_plant_plant_type_version_pk_validity",
        table_name="asset_plant_plant_type_version",
    )
    op.drop_index(
        "ix_asset_plant_plant_type_version_pk_transaction_id",
        table_name="asset_plant_plant_type_version",
    )
    op.drop_index(
        op.f("ix_asset_plant_plant_type_version_operation_type"),
        table_name="asset_plant_plant_type_version",
    )
    op.drop_index(
        op.f("ix_asset_plant_plant_type_version_end_transaction_id"),
        table_name="asset_plant_plant_type_version",
    )
    op.drop_table("asset_plant_plant_type_version")
    op.drop_table("asset_plant_plant_type")

    # asset_plant
    op.drop_index(
        op.f("ix_asset_plant_version_transaction_id"), table_name="asset_plant_version"
    )
    op.drop_index(
        "ix_asset_plant_version_pk_validity", table_name="asset_plant_version"
    )
    op.drop_index(
        "ix_asset_plant_version_pk_transaction_id", table_name="asset_plant_version"
    )
    op.drop_index(
        op.f("ix_asset_plant_version_operation_type"), table_name="asset_plant_version"
    )
    op.drop_index(
        op.f("ix_asset_plant_version_end_transaction_id"),
        table_name="asset_plant_version",
    )
    op.drop_table("asset_plant_version")
    op.drop_table("asset_plant")

    # plant_type
    op.drop_index(
        op.f("ix_plant_type_version_transaction_id"), table_name="plant_type_version"
    )
    op.drop_index("ix_plant_type_version_pk_validity", table_name="plant_type_version")
    op.drop_index(
        "ix_plant_type_version_pk_transaction_id", table_name="plant_type_version"
    )
    op.drop_index(
        op.f("ix_plant_type_version_operation_type"), table_name="plant_type_version"
    )
    op.drop_index(
        op.f("ix_plant_type_version_end_transaction_id"),
        table_name="plant_type_version",
    )
    op.drop_table("plant_type_version")
    op.drop_table("plant_type")
