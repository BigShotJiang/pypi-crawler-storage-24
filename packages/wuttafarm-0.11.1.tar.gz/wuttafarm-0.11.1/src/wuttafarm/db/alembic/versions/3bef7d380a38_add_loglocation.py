"""add LogLocation

Revision ID: 3bef7d380a38
Revises: f3c7e273bfa3
Create Date: 2026-02-28 20:41:56.051847

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "3bef7d380a38"
down_revision: Union[str, None] = "f3c7e273bfa3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log_location
    op.create_table(
        "log_location",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("log_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["asset_uuid"],
            ["asset.uuid"],
            name=op.f("fk_log_location_asset_uuid_asset"),
        ),
        sa.ForeignKeyConstraint(
            ["log_uuid"], ["log.uuid"], name=op.f("fk_log_location_log_uuid_log")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_location")),
    )
    op.create_table(
        "log_location_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "log_uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=True
        ),
        sa.Column(
            "asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_location_version")
        ),
    )
    op.create_index(
        op.f("ix_log_location_version_end_transaction_id"),
        "log_location_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_location_version_operation_type"),
        "log_location_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_location_version_pk_transaction_id",
        "log_location_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_location_version_pk_validity",
        "log_location_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_location_version_transaction_id"),
        "log_location_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # log_location
    op.drop_index(
        op.f("ix_log_location_version_transaction_id"),
        table_name="log_location_version",
    )
    op.drop_index(
        "ix_log_location_version_pk_validity", table_name="log_location_version"
    )
    op.drop_index(
        "ix_log_location_version_pk_transaction_id", table_name="log_location_version"
    )
    op.drop_index(
        op.f("ix_log_location_version_operation_type"),
        table_name="log_location_version",
    )
    op.drop_index(
        op.f("ix_log_location_version_end_transaction_id"),
        table_name="log_location_version",
    )
    op.drop_table("log_location_version")
    op.drop_table("log_location")
