"""add WuttaFarmUser

Revision ID: 6c56bcd1c028
Revises: 2b6385d0fa17
Create Date: 2026-02-09 20:46:20.995903

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "6c56bcd1c028"
down_revision: Union[str, None] = "2b6385d0fa17"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # wuttafarm_user
    op.create_table(
        "wuttafarm_user",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["uuid"], ["user.uuid"], name=op.f("fk_wuttafarm_user_uuid_user")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_wuttafarm_user")),
    )
    op.create_table(
        "wuttafarm_user_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_wuttafarm_user_version")
        ),
    )
    op.create_index(
        op.f("ix_wuttafarm_user_version_end_transaction_id"),
        "wuttafarm_user_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_wuttafarm_user_version_operation_type"),
        "wuttafarm_user_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_wuttafarm_user_version_pk_transaction_id",
        "wuttafarm_user_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_wuttafarm_user_version_pk_validity",
        "wuttafarm_user_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_wuttafarm_user_version_transaction_id"),
        "wuttafarm_user_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # wuttafarm_user
    op.drop_index(
        op.f("ix_wuttafarm_user_version_transaction_id"),
        table_name="wuttafarm_user_version",
    )
    op.drop_index(
        "ix_wuttafarm_user_version_pk_validity", table_name="wuttafarm_user_version"
    )
    op.drop_index(
        "ix_wuttafarm_user_version_pk_transaction_id",
        table_name="wuttafarm_user_version",
    )
    op.drop_index(
        op.f("ix_wuttafarm_user_version_operation_type"),
        table_name="wuttafarm_user_version",
    )
    op.drop_index(
        op.f("ix_wuttafarm_user_version_end_transaction_id"),
        table_name="wuttafarm_user_version",
    )
    op.drop_table("wuttafarm_user_version")
    op.drop_table("wuttafarm_user")
