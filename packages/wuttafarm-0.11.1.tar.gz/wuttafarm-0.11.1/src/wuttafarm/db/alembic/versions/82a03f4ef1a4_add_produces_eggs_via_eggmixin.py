"""add produces_eggs via EggMixin

Revision ID: 82a03f4ef1a4
Revises: 11e0e46f48a6
Create Date: 2026-02-18 18:45:36.015144

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "82a03f4ef1a4"
down_revision: Union[str, None] = "11e0e46f48a6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # asset_animal
    op.add_column(
        "asset_animal", sa.Column("produces_eggs", sa.Boolean(), nullable=True)
    )
    op.add_column(
        "asset_animal_version",
        sa.Column("produces_eggs", sa.Boolean(), autoincrement=False, nullable=True),
    )

    # asset_group
    op.add_column(
        "asset_group", sa.Column("produces_eggs", sa.Boolean(), nullable=True)
    )
    op.add_column(
        "asset_group_version",
        sa.Column("produces_eggs", sa.Boolean(), autoincrement=False, nullable=True),
    )


def downgrade() -> None:

    # asset_group
    op.drop_column("asset_group_version", "produces_eggs")
    op.drop_column("asset_group", "produces_eggs")

    # asset_animal
    op.drop_column("asset_animal_version", "produces_eggs")
    op.drop_column("asset_animal", "produces_eggs")
