"""add Log.is_group_assignment

Revision ID: f3c7e273bfa3
Revises: 47d0ebd84554
Create Date: 2026-02-28 20:04:40.700474

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "f3c7e273bfa3"
down_revision: Union[str, None] = "47d0ebd84554"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log
    op.add_column("log", sa.Column("is_group_assignment", sa.Boolean(), nullable=True))
    op.add_column(
        "log_version",
        sa.Column(
            "is_group_assignment", sa.Boolean(), autoincrement=False, nullable=True
        ),
    )


def downgrade() -> None:

    # log
    op.drop_column("log_version", "is_group_assignment")
    op.drop_column("log", "is_group_assignment")
