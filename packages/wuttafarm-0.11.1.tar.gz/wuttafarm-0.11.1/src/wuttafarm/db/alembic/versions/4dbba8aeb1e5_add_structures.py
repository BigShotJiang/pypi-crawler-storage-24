"""add Structures

Revision ID: 4dbba8aeb1e5
Revises: e416b96467fc
Create Date: 2026-02-13 10:17:15.179202

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "4dbba8aeb1e5"
down_revision: Union[str, None] = "e416b96467fc"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # structure
    op.create_table(
        "structure",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("structure_type_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("is_location", sa.Boolean(), nullable=False),
        sa.Column("is_fixed", sa.Boolean(), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("image_url", sa.String(length=255), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["structure_type_uuid"],
            ["structure_type.uuid"],
            name=op.f("fk_structure_structure_type_uuid_structure_type"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_structure")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_structure_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_structure_farmos_uuid")),
        sa.UniqueConstraint("name", name=op.f("uq_structure_name")),
    )
    op.create_table(
        "structure_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column("active", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column(
            "structure_type_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("is_location", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("is_fixed", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("notes", sa.Text(), autoincrement=False, nullable=True),
        sa.Column(
            "image_url", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_structure_version")
        ),
    )
    op.create_index(
        op.f("ix_structure_version_end_transaction_id"),
        "structure_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_structure_version_operation_type"),
        "structure_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_structure_version_pk_transaction_id",
        "structure_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_structure_version_pk_validity",
        "structure_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_structure_version_transaction_id"),
        "structure_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # structure
    op.drop_index(
        op.f("ix_structure_version_transaction_id"), table_name="structure_version"
    )
    op.drop_index("ix_structure_version_pk_validity", table_name="structure_version")
    op.drop_index(
        "ix_structure_version_pk_transaction_id", table_name="structure_version"
    )
    op.drop_index(
        op.f("ix_structure_version_operation_type"), table_name="structure_version"
    )
    op.drop_index(
        op.f("ix_structure_version_end_transaction_id"), table_name="structure_version"
    )
    op.drop_table("structure_version")
    op.drop_table("structure")
