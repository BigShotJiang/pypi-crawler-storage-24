"""use shared base for Land Assets

Revision ID: d882682c82f9
Revises: d6e8d16d6854
Create Date: 2026-02-15 12:00:27.036011

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "d882682c82f9"
down_revision: Union[str, None] = "d6e8d16d6854"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # asset_parent
    op.create_table(
        "asset_parent",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("parent_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["asset_uuid"],
            ["asset.uuid"],
            name=op.f("fk_asset_parent_asset_uuid_asset"),
        ),
        sa.ForeignKeyConstraint(
            ["parent_uuid"],
            ["asset.uuid"],
            name=op.f("fk_asset_parent_parent_uuid_asset"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_parent")),
    )
    op.create_table(
        "asset_parent_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "parent_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_parent_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_parent_version_end_transaction_id"),
        "asset_parent_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_parent_version_operation_type"),
        "asset_parent_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_parent_version_pk_transaction_id",
        "asset_parent_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_parent_version_pk_validity",
        "asset_parent_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_parent_version_transaction_id"),
        "asset_parent_version",
        ["transaction_id"],
        unique=False,
    )

    # asset_land
    op.create_table(
        "asset_land",
        sa.Column("land_type_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["land_type_uuid"],
            ["land_type.uuid"],
            name=op.f("fk_asset_land_land_type_uuid_land_type"),
        ),
        sa.ForeignKeyConstraint(
            ["uuid"], ["asset.uuid"], name=op.f("fk_asset_land_uuid_asset")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_land")),
        sa.UniqueConstraint(
            "land_type_uuid", name=op.f("uq_asset_land_land_type_uuid")
        ),
    )
    op.create_table(
        "asset_land_version",
        sa.Column(
            "land_type_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_land_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_land_version_end_transaction_id"),
        "asset_land_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_land_version_operation_type"),
        "asset_land_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_land_version_pk_transaction_id",
        "asset_land_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_land_version_pk_validity",
        "asset_land_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_land_version_transaction_id"),
        "asset_land_version",
        ["transaction_id"],
        unique=False,
    )

    # land_asset_parent
    op.drop_index(
        op.f("ix_land_asset_parent_version_end_transaction_id"),
        table_name="land_asset_parent_version",
    )
    op.drop_index(
        op.f("ix_land_asset_parent_version_operation_type"),
        table_name="land_asset_parent_version",
    )
    op.drop_index(
        op.f("ix_land_asset_parent_version_pk_transaction_id"),
        table_name="land_asset_parent_version",
    )
    op.drop_index(
        op.f("ix_land_asset_parent_version_pk_validity"),
        table_name="land_asset_parent_version",
    )
    op.drop_index(
        op.f("ix_land_asset_parent_version_transaction_id"),
        table_name="land_asset_parent_version",
    )
    op.drop_table("land_asset_parent_version")
    op.drop_table("land_asset_parent")

    # land_asset
    op.drop_index(
        op.f("ix_land_asset_version_end_transaction_id"),
        table_name="land_asset_version",
    )
    op.drop_index(
        op.f("ix_land_asset_version_operation_type"), table_name="land_asset_version"
    )
    op.drop_index(
        op.f("ix_land_asset_version_pk_transaction_id"), table_name="land_asset_version"
    )
    op.drop_index(
        op.f("ix_land_asset_version_pk_validity"), table_name="land_asset_version"
    )
    op.drop_index(
        op.f("ix_land_asset_version_transaction_id"), table_name="land_asset_version"
    )
    op.drop_table("land_asset_version")
    op.drop_table("land_asset")


def downgrade() -> None:

    # land_asset
    op.create_table(
        "land_asset",
        sa.Column("uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("name", sa.VARCHAR(length=100), autoincrement=False, nullable=False),
        sa.Column("land_type_uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("is_location", sa.BOOLEAN(), autoincrement=False, nullable=False),
        sa.Column("is_fixed", sa.BOOLEAN(), autoincrement=False, nullable=False),
        sa.Column("notes", sa.TEXT(), autoincrement=False, nullable=True),
        sa.Column("archived", sa.BOOLEAN(), autoincrement=False, nullable=False),
        sa.Column("farmos_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("drupal_id", sa.INTEGER(), autoincrement=False, nullable=True),
        sa.ForeignKeyConstraint(
            ["land_type_uuid"],
            ["land_type.uuid"],
            name=op.f("fk_land_asset_land_type_uuid_land_type"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_land_asset")),
        sa.UniqueConstraint(
            "drupal_id",
            name=op.f("uq_land_asset_drupal_id"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
        sa.UniqueConstraint(
            "farmos_uuid",
            name=op.f("uq_land_asset_farmos_uuid"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
        sa.UniqueConstraint(
            "land_type_uuid",
            name=op.f("uq_land_asset_land_type_uuid"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
        sa.UniqueConstraint(
            "name",
            name=op.f("uq_land_asset_name"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
    )
    op.create_table(
        "land_asset_version",
        sa.Column("uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("name", sa.VARCHAR(length=100), autoincrement=False, nullable=True),
        sa.Column("land_type_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("is_location", sa.BOOLEAN(), autoincrement=False, nullable=True),
        sa.Column("is_fixed", sa.BOOLEAN(), autoincrement=False, nullable=True),
        sa.Column("notes", sa.TEXT(), autoincrement=False, nullable=True),
        sa.Column("archived", sa.BOOLEAN(), autoincrement=False, nullable=True),
        sa.Column("farmos_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("drupal_id", sa.INTEGER(), autoincrement=False, nullable=True),
        sa.Column("transaction_id", sa.BIGINT(), autoincrement=False, nullable=False),
        sa.Column(
            "end_transaction_id", sa.BIGINT(), autoincrement=False, nullable=True
        ),
        sa.Column("operation_type", sa.SMALLINT(), autoincrement=False, nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_land_asset_version")
        ),
    )
    op.create_index(
        op.f("ix_land_asset_version_transaction_id"),
        "land_asset_version",
        ["transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_version_pk_validity"),
        "land_asset_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_version_pk_transaction_id"),
        "land_asset_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_version_operation_type"),
        "land_asset_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_version_end_transaction_id"),
        "land_asset_version",
        ["end_transaction_id"],
        unique=False,
    )

    # land_asset_parent
    op.create_table(
        "land_asset_parent",
        sa.Column("uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("land_asset_uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("parent_asset_uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.ForeignKeyConstraint(
            ["land_asset_uuid"],
            ["land_asset.uuid"],
            name=op.f("fk_land_asset_parent_land_asset_uuid_land_asset"),
        ),
        sa.ForeignKeyConstraint(
            ["parent_asset_uuid"],
            ["land_asset.uuid"],
            name=op.f("fk_land_asset_parent_parent_asset_uuid_land_asset"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_land_asset_parent")),
    )
    op.create_table(
        "land_asset_parent_version",
        sa.Column("uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("land_asset_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("parent_asset_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("transaction_id", sa.BIGINT(), autoincrement=False, nullable=False),
        sa.Column(
            "end_transaction_id", sa.BIGINT(), autoincrement=False, nullable=True
        ),
        sa.Column("operation_type", sa.SMALLINT(), autoincrement=False, nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_land_asset_parent_version")
        ),
    )
    op.create_index(
        op.f("ix_land_asset_parent_version_transaction_id"),
        "land_asset_parent_version",
        ["transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_parent_version_pk_validity"),
        "land_asset_parent_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_parent_version_pk_transaction_id"),
        "land_asset_parent_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_parent_version_operation_type"),
        "land_asset_parent_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_parent_version_end_transaction_id"),
        "land_asset_parent_version",
        ["end_transaction_id"],
        unique=False,
    )

    # asset_land
    op.drop_table("asset_land")
    op.drop_index(
        op.f("ix_asset_land_version_transaction_id"), table_name="asset_land_version"
    )
    op.drop_index("ix_asset_land_version_pk_validity", table_name="asset_land_version")
    op.drop_index(
        "ix_asset_land_version_pk_transaction_id", table_name="asset_land_version"
    )
    op.drop_index(
        op.f("ix_asset_land_version_operation_type"), table_name="asset_land_version"
    )
    op.drop_index(
        op.f("ix_asset_land_version_end_transaction_id"),
        table_name="asset_land_version",
    )
    op.drop_table("asset_land_version")

    # asset_parent
    op.drop_index(
        op.f("ix_asset_parent_version_transaction_id"),
        table_name="asset_parent_version",
    )
    op.drop_index(
        "ix_asset_parent_version_pk_validity", table_name="asset_parent_version"
    )
    op.drop_index(
        "ix_asset_parent_version_pk_transaction_id", table_name="asset_parent_version"
    )
    op.drop_index(
        op.f("ix_asset_parent_version_operation_type"),
        table_name="asset_parent_version",
    )
    op.drop_index(
        op.f("ix_asset_parent_version_end_transaction_id"),
        table_name="asset_parent_version",
    )
    op.drop_table("asset_parent_version")
    op.drop_table("asset_parent")
