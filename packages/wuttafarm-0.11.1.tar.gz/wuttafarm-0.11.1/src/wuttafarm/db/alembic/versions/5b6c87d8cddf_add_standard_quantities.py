"""add Standard Quantities

Revision ID: 5b6c87d8cddf
Revises: 1f98d27cabeb
Create Date: 2026-02-19 15:42:19.691148

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "5b6c87d8cddf"
down_revision: Union[str, None] = "1f98d27cabeb"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # measure
    op.create_table(
        "measure",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("drupal_id", sa.String(length=20), nullable=True),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_measure")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_measure_drupal_id")),
        sa.UniqueConstraint("name", name=op.f("uq_measure_name")),
    )
    op.create_table(
        "measure_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column(
            "drupal_id", sa.String(length=20), autoincrement=False, nullable=True
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_measure_version")
        ),
    )
    op.create_index(
        op.f("ix_measure_version_end_transaction_id"),
        "measure_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_measure_version_operation_type"),
        "measure_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_measure_version_pk_transaction_id",
        "measure_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_measure_version_pk_validity",
        "measure_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_measure_version_transaction_id"),
        "measure_version",
        ["transaction_id"],
        unique=False,
    )

    # quantity
    op.create_table(
        "quantity",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("quantity_type_id", sa.String(length=50), nullable=False),
        sa.Column("measure_id", sa.String(length=20), nullable=False),
        sa.Column("value_numerator", sa.Integer(), nullable=False),
        sa.Column("value_denominator", sa.Integer(), nullable=False),
        sa.Column("units_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("label", sa.String(length=255), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["measure_id"],
            ["measure.drupal_id"],
            name=op.f("fk_quantity_measure_id_measure"),
        ),
        sa.ForeignKeyConstraint(
            ["quantity_type_id"],
            ["quantity_type.drupal_id"],
            name=op.f("fk_quantity_quantity_type_id_quantity_type"),
        ),
        sa.ForeignKeyConstraint(
            ["units_uuid"], ["unit.uuid"], name=op.f("fk_quantity_units_uuid_unit")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_quantity")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_quantity_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_quantity_farmos_uuid")),
    )
    op.create_table(
        "quantity_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "quantity_type_id", sa.String(length=50), autoincrement=False, nullable=True
        ),
        sa.Column(
            "measure_id", sa.String(length=20), autoincrement=False, nullable=True
        ),
        sa.Column("value_numerator", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "value_denominator", sa.Integer(), autoincrement=False, nullable=True
        ),
        sa.Column(
            "units_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("label", sa.String(length=255), autoincrement=False, nullable=True),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_quantity_version")
        ),
    )
    op.create_index(
        op.f("ix_quantity_version_end_transaction_id"),
        "quantity_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_quantity_version_operation_type"),
        "quantity_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_quantity_version_pk_transaction_id",
        "quantity_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_quantity_version_pk_validity",
        "quantity_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_quantity_version_transaction_id"),
        "quantity_version",
        ["transaction_id"],
        unique=False,
    )

    # quantity_standard
    op.create_table(
        "quantity_standard",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["uuid"], ["quantity.uuid"], name=op.f("fk_quantity_standard_uuid_quantity")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_quantity_standard")),
    )
    op.create_table(
        "quantity_standard_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_quantity_standard_version")
        ),
    )
    op.create_index(
        op.f("ix_quantity_standard_version_end_transaction_id"),
        "quantity_standard_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_quantity_standard_version_operation_type"),
        "quantity_standard_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_quantity_standard_version_pk_transaction_id",
        "quantity_standard_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_quantity_standard_version_pk_validity",
        "quantity_standard_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_quantity_standard_version_transaction_id"),
        "quantity_standard_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # quantity_standard
    op.drop_index(
        op.f("ix_quantity_standard_version_transaction_id"),
        table_name="quantity_standard_version",
    )
    op.drop_index(
        "ix_quantity_standard_version_pk_validity",
        table_name="quantity_standard_version",
    )
    op.drop_index(
        "ix_quantity_standard_version_pk_transaction_id",
        table_name="quantity_standard_version",
    )
    op.drop_index(
        op.f("ix_quantity_standard_version_operation_type"),
        table_name="quantity_standard_version",
    )
    op.drop_index(
        op.f("ix_quantity_standard_version_end_transaction_id"),
        table_name="quantity_standard_version",
    )
    op.drop_table("quantity_standard_version")
    op.drop_table("quantity_standard")

    # quantity
    op.drop_index(
        op.f("ix_quantity_version_transaction_id"), table_name="quantity_version"
    )
    op.drop_index("ix_quantity_version_pk_validity", table_name="quantity_version")
    op.drop_index(
        "ix_quantity_version_pk_transaction_id", table_name="quantity_version"
    )
    op.drop_index(
        op.f("ix_quantity_version_operation_type"), table_name="quantity_version"
    )
    op.drop_index(
        op.f("ix_quantity_version_end_transaction_id"), table_name="quantity_version"
    )
    op.drop_table("quantity_version")
    op.drop_table("quantity")

    # measure
    op.drop_index(
        op.f("ix_measure_version_transaction_id"), table_name="measure_version"
    )
    op.drop_index("ix_measure_version_pk_validity", table_name="measure_version")
    op.drop_index("ix_measure_version_pk_transaction_id", table_name="measure_version")
    op.drop_index(
        op.f("ix_measure_version_operation_type"), table_name="measure_version"
    )
    op.drop_index(
        op.f("ix_measure_version_end_transaction_id"), table_name="measure_version"
    )
    op.drop_table("measure_version")
    op.drop_table("measure")
