"""add MaterialQuantity

Revision ID: 9c53513f8862
Revises: 1c89f3fbb521
Create Date: 2026-03-08 18:14:05.587678

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "9c53513f8862"
down_revision: Union[str, None] = "1c89f3fbb521"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # quantity_material
    op.create_table(
        "quantity_material",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["uuid"], ["quantity.uuid"], name=op.f("fk_quantity_material_uuid_quantity")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_quantity_material")),
    )
    op.create_table(
        "quantity_material_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_quantity_material_version")
        ),
    )
    op.create_index(
        op.f("ix_quantity_material_version_end_transaction_id"),
        "quantity_material_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_quantity_material_version_operation_type"),
        "quantity_material_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_quantity_material_version_pk_transaction_id",
        "quantity_material_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_quantity_material_version_pk_validity",
        "quantity_material_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_quantity_material_version_transaction_id"),
        "quantity_material_version",
        ["transaction_id"],
        unique=False,
    )

    # quantity_material_material_type
    op.create_table(
        "quantity_material_material_type",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("quantity_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("material_type_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["material_type_uuid"],
            ["material_type.uuid"],
            name=op.f(
                "fk_quantity_material_material_type_material_type_uuid_material_type"
            ),
        ),
        sa.ForeignKeyConstraint(
            ["quantity_uuid"],
            ["quantity_material.uuid"],
            name=op.f(
                "fk_quantity_material_material_type_quantity_uuid_quantity_material"
            ),
        ),
        sa.PrimaryKeyConstraint(
            "uuid", name=op.f("pk_quantity_material_material_type")
        ),
    )
    op.create_table(
        "quantity_material_material_type_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "quantity_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "material_type_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid",
            "transaction_id",
            name=op.f("pk_quantity_material_material_type_version"),
        ),
    )
    op.create_index(
        op.f("ix_quantity_material_material_type_version_end_transaction_id"),
        "quantity_material_material_type_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_quantity_material_material_type_version_operation_type"),
        "quantity_material_material_type_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_quantity_material_material_type_version_pk_transaction_id",
        "quantity_material_material_type_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_quantity_material_material_type_version_pk_validity",
        "quantity_material_material_type_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_quantity_material_material_type_version_transaction_id"),
        "quantity_material_material_type_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # quantity_material_material_type
    op.drop_index(
        op.f("ix_quantity_material_material_type_version_transaction_id"),
        table_name="quantity_material_material_type_version",
    )
    op.drop_index(
        "ix_quantity_material_material_type_version_pk_validity",
        table_name="quantity_material_material_type_version",
    )
    op.drop_index(
        "ix_quantity_material_material_type_version_pk_transaction_id",
        table_name="quantity_material_material_type_version",
    )
    op.drop_index(
        op.f("ix_quantity_material_material_type_version_operation_type"),
        table_name="quantity_material_material_type_version",
    )
    op.drop_index(
        op.f("ix_quantity_material_material_type_version_end_transaction_id"),
        table_name="quantity_material_material_type_version",
    )
    op.drop_table("quantity_material_material_type_version")
    op.drop_table("quantity_material_material_type")

    # quantity_material
    op.drop_index(
        op.f("ix_quantity_material_version_transaction_id"),
        table_name="quantity_material_version",
    )
    op.drop_index(
        "ix_quantity_material_version_pk_validity",
        table_name="quantity_material_version",
    )
    op.drop_index(
        "ix_quantity_material_version_pk_transaction_id",
        table_name="quantity_material_version",
    )
    op.drop_index(
        op.f("ix_quantity_material_version_operation_type"),
        table_name="quantity_material_version",
    )
    op.drop_index(
        op.f("ix_quantity_material_version_end_transaction_id"),
        table_name="quantity_material_version",
    )
    op.drop_table("quantity_material_version")
    op.drop_table("quantity_material")
