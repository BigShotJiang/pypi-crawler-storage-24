"""remove AnimalType.changed

Revision ID: b8cd4a8f981f
Revises: aecfd9175624
Create Date: 2026-02-17 18:11:06.110003

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "b8cd4a8f981f"
down_revision: Union[str, None] = "aecfd9175624"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # animal_type
    op.drop_column("animal_type", "changed")


def downgrade() -> None:

    # animal_type
    op.add_column(
        "animal_type",
        sa.Column(
            "changed", postgresql.TIMESTAMP(), autoincrement=False, nullable=True
        ),
    )
