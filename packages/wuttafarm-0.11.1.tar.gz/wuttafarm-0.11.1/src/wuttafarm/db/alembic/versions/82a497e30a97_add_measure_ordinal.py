"""add Measure.ordinal

Revision ID: 82a497e30a97
Revises: c5183b781d34
Create Date: 2026-03-08 13:15:36.917747

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "82a497e30a97"
down_revision: Union[str, None] = "c5183b781d34"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # measure
    op.add_column("measure", sa.Column("ordinal", sa.Integer(), nullable=True))
    op.add_column(
        "measure_version",
        sa.Column("ordinal", sa.Integer(), autoincrement=False, nullable=True),
    )


def downgrade() -> None:

    # measure
    op.drop_column("measure_version", "ordinal")
    op.drop_column("measure", "ordinal")
