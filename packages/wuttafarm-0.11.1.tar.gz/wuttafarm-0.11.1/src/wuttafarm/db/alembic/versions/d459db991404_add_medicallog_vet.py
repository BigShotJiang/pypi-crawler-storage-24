"""add MedicalLog.vet

Revision ID: d459db991404
Revises: 9e875e5cbdc1
Create Date: 2026-02-28 22:17:57.001134

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "d459db991404"
down_revision: Union[str, None] = "9e875e5cbdc1"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log_medical
    op.add_column("log_medical", sa.Column("vet", sa.String(length=100), nullable=True))
    op.add_column(
        "log_medical_version",
        sa.Column("vet", sa.String(length=100), autoincrement=False, nullable=True),
    )


def downgrade() -> None:

    # log_medical
    op.drop_column("log_medical_version", "vet")
    op.drop_column("log_medical", "vet")
