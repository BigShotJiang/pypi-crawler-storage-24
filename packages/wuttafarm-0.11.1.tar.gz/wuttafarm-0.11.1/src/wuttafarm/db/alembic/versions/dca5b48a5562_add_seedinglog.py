"""add SeedingLog

Revision ID: dca5b48a5562
Revises: e9b8664e1f39
Create Date: 2026-03-10 09:52:13.999777

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "dca5b48a5562"
down_revision: Union[str, None] = "e9b8664e1f39"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log_seeding
    op.create_table(
        "log_seeding",
        sa.Column("source", sa.String(length=255), nullable=True),
        sa.Column("purchase_date", sa.DateTime(), nullable=True),
        sa.Column("lot_number", sa.String(length=255), nullable=True),
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["uuid"], ["log.uuid"], name=op.f("fk_log_seeding_uuid_log")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_seeding")),
    )
    op.create_table(
        "log_seeding_version",
        sa.Column("source", sa.String(length=255), autoincrement=False, nullable=True),
        sa.Column("purchase_date", sa.DateTime(), autoincrement=False, nullable=True),
        sa.Column(
            "lot_number", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_seeding_version")
        ),
    )
    op.create_index(
        op.f("ix_log_seeding_version_end_transaction_id"),
        "log_seeding_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_seeding_version_operation_type"),
        "log_seeding_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_seeding_version_pk_transaction_id",
        "log_seeding_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_seeding_version_pk_validity",
        "log_seeding_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_seeding_version_transaction_id"),
        "log_seeding_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # log_seeding
    op.drop_index(
        op.f("ix_log_seeding_version_transaction_id"), table_name="log_seeding_version"
    )
    op.drop_index(
        "ix_log_seeding_version_pk_validity", table_name="log_seeding_version"
    )
    op.drop_index(
        "ix_log_seeding_version_pk_transaction_id", table_name="log_seeding_version"
    )
    op.drop_index(
        op.f("ix_log_seeding_version_operation_type"), table_name="log_seeding_version"
    )
    op.drop_index(
        op.f("ix_log_seeding_version_end_transaction_id"),
        table_name="log_seeding_version",
    )
    op.drop_table("log_seeding_version")
    op.drop_table("log_seeding")
