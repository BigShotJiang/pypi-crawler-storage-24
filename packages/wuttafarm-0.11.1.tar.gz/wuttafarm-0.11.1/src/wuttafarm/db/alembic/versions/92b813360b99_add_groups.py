"""add Groups

Revision ID: 92b813360b99
Revises: 1b2d3224e5dc
Create Date: 2026-02-13 13:09:48.718064

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "92b813360b99"
down_revision: Union[str, None] = "1b2d3224e5dc"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # group
    op.create_table(
        "group",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("is_location", sa.Boolean(), nullable=False),
        sa.Column("is_fixed", sa.Boolean(), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_group")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_group_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_group_farmos_uuid")),
        sa.UniqueConstraint("name", name=op.f("uq_group_name")),
    )
    op.create_table(
        "group_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column("is_location", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("is_fixed", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("active", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("notes", sa.Text(), autoincrement=False, nullable=True),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_group_version")
        ),
    )
    op.create_index(
        op.f("ix_group_version_end_transaction_id"),
        "group_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_group_version_operation_type"),
        "group_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_group_version_pk_transaction_id",
        "group_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_group_version_pk_validity",
        "group_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_group_version_transaction_id"),
        "group_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # group
    op.drop_index(op.f("ix_group_version_transaction_id"), table_name="group_version")
    op.drop_index("ix_group_version_pk_validity", table_name="group_version")
    op.drop_index("ix_group_version_pk_transaction_id", table_name="group_version")
    op.drop_index(op.f("ix_group_version_operation_type"), table_name="group_version")
    op.drop_index(
        op.f("ix_group_version_end_transaction_id"), table_name="group_version"
    )
    op.drop_table("group_version")
    op.drop_table("group")
