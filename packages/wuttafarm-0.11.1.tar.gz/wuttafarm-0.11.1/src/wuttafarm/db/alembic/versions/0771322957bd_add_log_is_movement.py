"""add Log.is_movement

Revision ID: 0771322957bd
Revises: 12de43facb95
Create Date: 2026-03-02 20:21:03.889847

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "0771322957bd"
down_revision: Union[str, None] = "12de43facb95"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log
    op.add_column("log", sa.Column("is_movement", sa.Boolean(), nullable=True))
    op.add_column(
        "log_version",
        sa.Column("is_movement", sa.Boolean(), autoincrement=False, nullable=True),
    )


def downgrade() -> None:

    # log
    op.drop_column("log_version", "is_movement")
    op.drop_column("log", "is_movement")
