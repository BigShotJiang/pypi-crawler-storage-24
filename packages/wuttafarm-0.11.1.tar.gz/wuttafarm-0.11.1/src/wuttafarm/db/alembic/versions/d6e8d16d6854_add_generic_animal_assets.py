"""add generic, animal assets

Revision ID: d6e8d16d6854
Revises: 554e6168c339
Create Date: 2026-02-15 09:11:04.886362

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "d6e8d16d6854"
down_revision: Union[str, None] = "554e6168c339"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # animal
    op.drop_table("animal")
    op.drop_index(
        op.f("ix_animal_version_end_transaction_id"), table_name="animal_version"
    )
    op.drop_index(op.f("ix_animal_version_operation_type"), table_name="animal_version")
    op.drop_index(
        op.f("ix_animal_version_pk_transaction_id"), table_name="animal_version"
    )
    op.drop_index(op.f("ix_animal_version_pk_validity"), table_name="animal_version")
    op.drop_index(op.f("ix_animal_version_transaction_id"), table_name="animal_version")
    op.drop_table("animal_version")

    # asset
    op.create_table(
        "asset",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.Column("asset_type", sa.String(length=100), nullable=False),
        sa.Column("asset_name", sa.String(length=100), nullable=False),
        sa.Column("is_location", sa.Boolean(), nullable=False),
        sa.Column("is_fixed", sa.Boolean(), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("thumbnail_url", sa.String(length=255), nullable=True),
        sa.Column("image_url", sa.String(length=255), nullable=True),
        sa.Column("archived", sa.Boolean(), nullable=False),
        sa.ForeignKeyConstraint(
            ["asset_type"],
            ["asset_type.drupal_id"],
            name=op.f("fk_asset_asset_type_asset_type"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_asset_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_asset_farmos_uuid")),
    )
    op.create_table(
        "asset_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "asset_type", sa.String(length=100), autoincrement=False, nullable=True
        ),
        sa.Column(
            "asset_name", sa.String(length=100), autoincrement=False, nullable=True
        ),
        sa.Column("is_location", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("is_fixed", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("notes", sa.Text(), autoincrement=False, nullable=True),
        sa.Column(
            "thumbnail_url", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "image_url", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column("archived", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_version_end_transaction_id"),
        "asset_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_version_operation_type"),
        "asset_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_version_pk_transaction_id",
        "asset_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_version_pk_validity",
        "asset_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_version_transaction_id"),
        "asset_version",
        ["transaction_id"],
        unique=False,
    )

    # asset_animal
    op.create_table(
        "asset_animal",
        sa.Column("animal_type_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("birthdate", sa.DateTime(), nullable=True),
        sa.Column("sex", sa.String(length=1), nullable=True),
        sa.Column("is_sterile", sa.Boolean(), nullable=True),
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["animal_type_uuid"],
            ["animal_type.uuid"],
            name=op.f("fk_asset_animal_animal_type_uuid_animal_type"),
        ),
        sa.ForeignKeyConstraint(
            ["uuid"], ["asset.uuid"], name=op.f("fk_asset_animal_uuid_asset")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_animal")),
    )
    op.create_table(
        "asset_animal_version",
        sa.Column(
            "animal_type_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("birthdate", sa.DateTime(), autoincrement=False, nullable=True),
        sa.Column("sex", sa.String(length=1), autoincrement=False, nullable=True),
        sa.Column("is_sterile", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_animal_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_animal_version_end_transaction_id"),
        "asset_animal_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_animal_version_operation_type"),
        "asset_animal_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_animal_version_pk_transaction_id",
        "asset_animal_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_animal_version_pk_validity",
        "asset_animal_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_animal_version_transaction_id"),
        "asset_animal_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # asset_animal
    op.drop_index(
        op.f("ix_asset_animal_version_transaction_id"),
        table_name="asset_animal_version",
    )
    op.drop_index(
        "ix_asset_animal_version_pk_validity", table_name="asset_animal_version"
    )
    op.drop_index(
        "ix_asset_animal_version_pk_transaction_id", table_name="asset_animal_version"
    )
    op.drop_index(
        op.f("ix_asset_animal_version_operation_type"),
        table_name="asset_animal_version",
    )
    op.drop_index(
        op.f("ix_asset_animal_version_end_transaction_id"),
        table_name="asset_animal_version",
    )
    op.drop_table("asset_animal_version")
    op.drop_table("asset_animal")

    # asset
    op.drop_index(op.f("ix_asset_version_transaction_id"), table_name="asset_version")
    op.drop_index("ix_asset_version_pk_validity", table_name="asset_version")
    op.drop_index("ix_asset_version_pk_transaction_id", table_name="asset_version")
    op.drop_index(op.f("ix_asset_version_operation_type"), table_name="asset_version")
    op.drop_index(
        op.f("ix_asset_version_end_transaction_id"), table_name="asset_version"
    )
    op.drop_table("asset_version")
    op.drop_table("asset")

    # animal
    op.create_table(
        "animal",
        sa.Column("uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("name", sa.VARCHAR(length=100), autoincrement=False, nullable=False),
        sa.Column("animal_type_uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("birthdate", sa.DateTime(), autoincrement=False, nullable=True),
        sa.Column("sex", sa.VARCHAR(length=1), autoincrement=False, nullable=True),
        sa.Column("is_sterile", sa.BOOLEAN(), autoincrement=False, nullable=True),
        sa.Column("archived", sa.BOOLEAN(), autoincrement=False, nullable=False),
        sa.Column("notes", sa.TEXT(), autoincrement=False, nullable=True),
        sa.Column(
            "image_url", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.Column("farmos_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("drupal_id", sa.INTEGER(), autoincrement=False, nullable=True),
        sa.Column(
            "thumbnail_url", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.ForeignKeyConstraint(
            ["animal_type_uuid"],
            ["animal_type.uuid"],
            name=op.f("fk_animal_animal_type_uuid_animal_type"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_animal")),
        sa.UniqueConstraint(
            "drupal_id",
            name=op.f("uq_animal_drupal_id"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
        sa.UniqueConstraint(
            "farmos_uuid",
            name=op.f("uq_animal_farmos_uuid"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
    )
    op.create_table(
        "animal_version",
        sa.Column("uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("name", sa.VARCHAR(length=100), autoincrement=False, nullable=True),
        sa.Column("animal_type_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column(
            "birthdate", postgresql.TIMESTAMP(), autoincrement=False, nullable=True
        ),
        sa.Column("sex", sa.VARCHAR(length=1), autoincrement=False, nullable=True),
        sa.Column("is_sterile", sa.BOOLEAN(), autoincrement=False, nullable=True),
        sa.Column("archived", sa.BOOLEAN(), autoincrement=False, nullable=True),
        sa.Column("notes", sa.TEXT(), autoincrement=False, nullable=True),
        sa.Column(
            "image_url", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.Column("farmos_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("drupal_id", sa.INTEGER(), autoincrement=False, nullable=True),
        sa.Column("transaction_id", sa.BIGINT(), autoincrement=False, nullable=False),
        sa.Column(
            "end_transaction_id", sa.BIGINT(), autoincrement=False, nullable=True
        ),
        sa.Column("operation_type", sa.SMALLINT(), autoincrement=False, nullable=False),
        sa.Column(
            "thumbnail_url", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_animal_version")
        ),
    )
    op.create_index(
        op.f("ix_animal_version_transaction_id"),
        "animal_version",
        ["transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_animal_version_pk_validity"),
        "animal_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_animal_version_pk_transaction_id"),
        "animal_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        op.f("ix_animal_version_operation_type"),
        "animal_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        op.f("ix_animal_version_end_transaction_id"),
        "animal_version",
        ["end_transaction_id"],
        unique=False,
    )
