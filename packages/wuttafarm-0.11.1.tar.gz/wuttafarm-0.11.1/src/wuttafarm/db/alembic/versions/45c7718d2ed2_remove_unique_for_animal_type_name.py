"""remove unique for animal_type.name

Revision ID: 45c7718d2ed2
Revises: 5b6c87d8cddf
Create Date: 2026-02-27 16:53:59.310342

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "45c7718d2ed2"
down_revision: Union[str, None] = "5b6c87d8cddf"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # animal_type
    op.drop_constraint(op.f("uq_animal_type_name"), "animal_type", type_="unique")


def downgrade() -> None:

    # animal_type
    op.create_unique_constraint(
        op.f("uq_animal_type_name"),
        "animal_type",
        ["name"],
        postgresql_nulls_not_distinct=False,
    )
