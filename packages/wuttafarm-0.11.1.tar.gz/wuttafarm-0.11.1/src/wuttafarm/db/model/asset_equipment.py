# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Equipment
"""

import sqlalchemy as sa
from sqlalchemy import orm
from sqlalchemy.ext.associationproxy import association_proxy

from wuttjamaican.db import model

from wuttafarm.db.model.taxonomy import TaxonomyMixin
from wuttafarm.db.model.asset import AssetMixin, add_asset_proxies


class EquipmentType(TaxonomyMixin, model.Base):
    """
    Represents an "equipment type" (taxonomy term) from farmOS
    """

    __tablename__ = "equipment_type"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Equipment Type",
        "model_title_plural": "Equipment Types",
    }

    _equipment_assets = orm.relationship(
        "EquipmentAssetEquipmentType",
        cascade_backrefs=False,
        back_populates="equipment_type",
    )


class EquipmentAsset(AssetMixin, model.Base):
    """
    Represents an equipment asset from farmOS
    """

    __tablename__ = "asset_equipment"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Equipment Asset",
        "model_title_plural": "Equipment Assets",
        "farmos_asset_type": "equipment",
    }

    manufacturer = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Name of the manufacturer, if applicable.
        """,
    )

    model = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Model name for the equipment, if applicable.
        """,
    )

    serial_number = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Serial number for the equipment, if applicable.
        """,
    )

    _equipment_types = orm.relationship(
        "EquipmentAssetEquipmentType",
        cascade="all, delete-orphan",
        cascade_backrefs=False,
        back_populates="equipment_asset",
    )

    equipment_types = association_proxy(
        "_equipment_types",
        "equipment_type",
        creator=lambda pt: EquipmentAssetEquipmentType(equipment_type=pt),
    )


add_asset_proxies(EquipmentAsset)


class EquipmentAssetEquipmentType(model.Base):
    """
    Associates one or more equipment types with an equipment asset.
    """

    __tablename__ = "asset_equipment_equipment_type"
    __versioned__ = {}

    uuid = model.uuid_column()

    equipment_asset_uuid = model.uuid_fk_column("asset_equipment.uuid", nullable=False)
    equipment_asset = orm.relationship(
        EquipmentAsset,
        foreign_keys=equipment_asset_uuid,
        back_populates="_equipment_types",
    )

    equipment_type_uuid = model.uuid_fk_column("equipment_type.uuid", nullable=False)
    equipment_type = orm.relationship(
        EquipmentType,
        doc="""
        Reference to the equipment type.
        """,
        back_populates="_equipment_assets",
    )
