# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Groups
"""

from wuttjamaican.db import model

from wuttafarm.db.model.asset import AssetMixin, add_asset_proxies, EggMixin


class GroupAsset(AssetMixin, EggMixin, model.Base):
    """
    Represents a group asset from farmOS
    """

    __tablename__ = "asset_group"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Group Asset",
        "model_title_plural": "Group Assets",
        "farmos_asset_type": "group",
    }


add_asset_proxies(GroupAsset)
