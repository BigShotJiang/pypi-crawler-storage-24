# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Seeding Logs
"""

import sqlalchemy as sa

from wuttjamaican.db import model

from wuttafarm.db.model.log import LogMixin, add_log_proxies


class SeedingLog(LogMixin, model.Base):
    """
    Represents a Seeding Log from farmOS
    """

    __tablename__ = "log_seeding"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Seeding Log",
        "model_title_plural": "Seeding Logs",
        "farmos_log_type": "seeding",
    }

    source = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Where the seed was obtained, if applicable.
        """,
    )

    purchase_date = sa.Column(
        sa.DateTime(),
        nullable=True,
        doc="""
        When the seed was purchased, if applicable.
        """,
    )

    lot_number = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Lot number for the seed, if applicable.
        """,
    )


add_log_proxies(SeedingLog)
