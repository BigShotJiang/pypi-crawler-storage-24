# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for webhook changes
"""

import sqlalchemy as sa

from wuttjamaican.db import model
from wuttjamaican.util import make_utc


class WebhookChange(model.Base):
    """
    Represents a "change" (create/update/delete) notification which
    originated in farmOS and delivered via webhook.

    This table serves as a "FIFO queue" for processing the changes.
    """

    __tablename__ = "webhook_change"

    uuid = model.uuid_column()

    entity_type = sa.Column(sa.String(length=100), nullable=False)
    bundle = sa.Column(sa.String(length=100), nullable=False)
    farmos_uuid = sa.Column(model.UUID(), nullable=False)

    deleted = sa.Column(sa.Boolean(), nullable=False)

    received = sa.Column(
        sa.DateTime(),
        nullable=False,
        default=make_utc,
        doc="""
    Date and time when the change was obtained from the watcher thread.
    """,
    )

    def __str__(self):
        event_type = "delete" if self.deleted else "create/update"
        return f"{event_type} {self.entity_type}--{self.bundle}: {self.farmos_uuid}"
