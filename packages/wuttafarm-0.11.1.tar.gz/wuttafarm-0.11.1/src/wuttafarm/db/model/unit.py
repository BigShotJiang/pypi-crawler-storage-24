# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Units
"""

import sqlalchemy as sa

from wuttjamaican.db import model


class Measure(model.Base):
    """
    Represents a "measure" option (for quantities) from farmOS
    """

    __tablename__ = "measure"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Measure",
        "model_title_plural": "Measures",
    }

    uuid = model.uuid_column()

    ordinal = sa.Column(
        sa.Integer(),
        nullable=True,
        doc="""
        Ordinal (sequence number) for the measure.
        """,
    )

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        unique=True,
        doc="""
        Name of the measure.
        """,
    )

    drupal_id = sa.Column(
        sa.String(length=20),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the measure.
        """,
    )

    def __str__(self):
        return self.name or ""


class Unit(model.Base):
    """
    Represents an "unit" (taxonomy term) from farmOS
    """

    __tablename__ = "unit"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Unit",
        "model_title_plural": "Units",
    }

    uuid = model.uuid_column()

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        unique=True,
        doc="""
        Name of the unit.
        """,
    )

    description = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Optional description for the unit.
        """,
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the unit within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.Integer(),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the unit.
        """,
    )

    def __str__(self):
        return self.name or ""
