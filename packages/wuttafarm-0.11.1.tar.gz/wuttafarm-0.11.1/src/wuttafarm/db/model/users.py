# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Users (extension)
"""

import sqlalchemy as sa
from sqlalchemy import orm

from wuttjamaican.db import model


class WuttaFarmUser(model.Base):
    """
    WuttaFarm extension for the User model.
    """

    __tablename__ = "wuttafarm_user"
    __versioned__ = {}

    uuid = model.uuid_column(sa.ForeignKey("user.uuid"), default=None)

    user = orm.relationship(
        model.User,
        doc="""
        Reference to the User which this record extends.
        """,
        backref=orm.backref(
            "_wuttafarm",
            uselist=False,
            cascade="all, delete-orphan",
            cascade_backrefs=False,
            doc="""
            Reference to the WuttaFarm-specific extension record for
            the user.
            """,
        ),
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        doc="""
        UUID for the user within farmOS
        """,
    )

    drupal_id = sa.Column(
        sa.Integer(),
        nullable=True,
        doc="""
        Drupal internal ID for the user.
        """,
    )

    def __str__(self):
        return str(self.user or "")


WuttaFarmUser.make_proxy(model.User, "_wuttafarm", "farmos_uuid")
WuttaFarmUser.make_proxy(model.User, "_wuttafarm", "drupal_id")
