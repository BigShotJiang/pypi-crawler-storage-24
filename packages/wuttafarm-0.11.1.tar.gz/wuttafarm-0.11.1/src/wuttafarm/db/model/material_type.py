# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Material Types
"""

import sqlalchemy as sa
from sqlalchemy import orm
from sqlalchemy.ext.associationproxy import association_proxy

from wuttjamaican.db import model


class MaterialType(model.Base):
    """
    Represents a "material type" (taxonomy term) from farmOS
    """

    __tablename__ = "material_type"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Material Type",
        "model_title_plural": "Material Types",
    }

    uuid = model.uuid_column()

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        doc="""
        Name of the material type.
        """,
    )

    description = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Optional description for the material type.
        """,
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the material type within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.Integer(),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the material type.
        """,
    )

    _quantities = orm.relationship(
        "MaterialQuantityMaterialType",
        cascade="all, delete-orphan",
        cascade_backrefs=False,
        back_populates="material_type",
    )

    def _make_material_quantity(qty):
        from wuttafarm.db.model import MaterialQuantityMaterialType

        return MaterialQuantityMaterialType(quantity=qty)

    quantities = association_proxy(
        "_quantities",
        "quantity",
        creator=_make_material_quantity,
    )

    def __str__(self):
        return self.name or ""
