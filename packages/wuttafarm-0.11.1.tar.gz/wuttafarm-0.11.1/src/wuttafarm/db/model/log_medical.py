# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Medical Logs
"""

import sqlalchemy as sa

from wuttjamaican.db import model

from wuttafarm.db.model.log import LogMixin, add_log_proxies


class MedicalLog(LogMixin, model.Base):
    """
    Represents a Medical Log from farmOS
    """

    __tablename__ = "log_medical"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Medical Log",
        "model_title_plural": "Medical Logs",
        "farmos_log_type": "medical",
    }

    vet = sa.Column(
        sa.String(length=100),
        nullable=True,
        doc="""
        Name of the veterinarian, if applicable.
        """,
    )


add_log_proxies(MedicalLog)
