# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm enum values
"""

from collections import OrderedDict

from wuttjamaican.enum import *


FARMOS_INTEGRATION_MODE_WRAPPER = "wrapper"
FARMOS_INTEGRATION_MODE_MIRROR = "mirror"
FARMOS_INTEGRATION_MODE_NONE = "none"

FARMOS_INTEGRATION_MODE = OrderedDict(
    [
        (FARMOS_INTEGRATION_MODE_WRAPPER, "wrapper (API only)"),
        (FARMOS_INTEGRATION_MODE_MIRROR, "mirror (2-way sync)"),
        (FARMOS_INTEGRATION_MODE_NONE, "none (standalone)"),
    ]
)


ANIMAL_SEX = OrderedDict(
    [
        ("M", "Male"),
        ("F", "Female"),
    ]
)


LOG_STATUS = OrderedDict(
    [
        ("pending", "Pending"),
        ("done", "Done"),
        ("abandoned", "Abandoned"),
    ]
)
