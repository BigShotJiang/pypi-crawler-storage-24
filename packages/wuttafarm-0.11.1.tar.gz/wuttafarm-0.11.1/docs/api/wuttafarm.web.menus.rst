
``wuttafarm.web.menus``
=======================

.. automodule:: wuttafarm.web.menus
   :members:
