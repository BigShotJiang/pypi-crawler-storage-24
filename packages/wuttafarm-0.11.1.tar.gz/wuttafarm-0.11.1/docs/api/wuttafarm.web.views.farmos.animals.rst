
``wuttafarm.web.views.farmos.animals``
======================================

.. automodule:: wuttafarm.web.views.farmos.animals
   :members:
