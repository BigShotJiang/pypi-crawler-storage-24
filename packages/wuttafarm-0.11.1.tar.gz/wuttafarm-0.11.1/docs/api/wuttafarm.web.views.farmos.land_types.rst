
``wuttafarm.web.views.farmos.land_types``
=========================================

.. automodule:: wuttafarm.web.views.farmos.land_types
   :members:
