
``wuttafarm.web.views.farmos.groups``
=====================================

.. automodule:: wuttafarm.web.views.farmos.groups
   :members:
