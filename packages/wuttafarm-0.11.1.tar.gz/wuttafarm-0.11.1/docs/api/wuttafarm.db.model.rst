
``wuttafarm.db.model``
======================

.. automodule:: wuttafarm.db.model
   :members:
