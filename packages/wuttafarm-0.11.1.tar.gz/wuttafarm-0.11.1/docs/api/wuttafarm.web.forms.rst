
``wuttafarm.web.forms``
=======================

.. automodule:: wuttafarm.web.forms
   :members:
