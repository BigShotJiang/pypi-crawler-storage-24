
``wuttafarm.web.views.farmos.land_assets``
==========================================

.. automodule:: wuttafarm.web.views.farmos.land_assets
   :members:
