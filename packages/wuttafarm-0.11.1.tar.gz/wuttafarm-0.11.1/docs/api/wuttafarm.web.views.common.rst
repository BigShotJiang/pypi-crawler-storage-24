
``wuttafarm.web.views.common``
==============================

.. automodule:: wuttafarm.web.views.common
   :members:
