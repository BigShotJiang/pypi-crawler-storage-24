
WuttaFarm
=========

This is a Python web app (built with `WuttaWeb`_), to integrate with
and extend `farmOS`_.

.. _WuttaWeb: https://wuttaproject.org
.. _farmOS: https://farmos.org

It is just an experiment so far; the ideas I hope to play with
include:

- display farmOS data directly, via real-time API fetch
- add "mirror" schema and sync data from farmOS to app DB (and display it)
- possibly add more schema / extra features
- possibly sync data back to farmOS

.. image:: https://img.shields.io/badge/code%20style-black-000000.svg
   :target: https://github.com/psf/black


.. toctree::
   :maxdepth: 2
   :caption: Documentation:

   narr/install
   narr/auth
   narr/features
   narr/cli


.. toctree::
   :maxdepth: 1
   :caption: Package API:

   api/wuttafarm
   api/wuttafarm.app
   api/wuttafarm.auth
   api/wuttafarm.cli
   api/wuttafarm.cli.base
   api/wuttafarm.cli.import_farmos
   api/wuttafarm.cli.install
   api/wuttafarm.config
   api/wuttafarm.db
   api/wuttafarm.db.model
   api/wuttafarm.farmos
   api/wuttafarm.farmos.handler
   api/wuttafarm.importing
   api/wuttafarm.importing.farmos
   api/wuttafarm.install
   api/wuttafarm.web
   api/wuttafarm.web.app
   api/wuttafarm.web.forms
   api/wuttafarm.web.forms.schema
   api/wuttafarm.web.forms.widgets
   api/wuttafarm.web.menus
   api/wuttafarm.web.static
   api/wuttafarm.web.subscribers
   api/wuttafarm.web.util
   api/wuttafarm.web.views
   api/wuttafarm.web.views.auth
   api/wuttafarm.web.views.common
   api/wuttafarm.web.views.farmos
   api/wuttafarm.web.views.farmos.animals
   api/wuttafarm.web.views.farmos.animal_types
   api/wuttafarm.web.views.farmos.asset_types
   api/wuttafarm.web.views.farmos.groups
   api/wuttafarm.web.views.farmos.land_assets
   api/wuttafarm.web.views.farmos.land_types
   api/wuttafarm.web.views.farmos.logs_activity
   api/wuttafarm.web.views.farmos.log_types
   api/wuttafarm.web.views.farmos.master
   api/wuttafarm.web.views.farmos.structures
   api/wuttafarm.web.views.farmos.structure_types
   api/wuttafarm.web.views.farmos.users
  

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
