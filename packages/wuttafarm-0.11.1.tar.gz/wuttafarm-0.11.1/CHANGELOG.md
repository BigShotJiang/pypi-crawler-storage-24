
# Changelog
All notable changes to WuttaFarm will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## v0.11.1 (2026-03-21)

### Fix

- improve behavior when deleting mirrored record from farmOS
- use correct uuid when processing webhook to delete record

## v0.11.0 (2026-03-15)

### Feat

- show basic map for "fixed" assets

### Fix

- include LogQuantity changes when viewing Log revision

## v0.10.0 (2026-03-11)

### Feat

- add support for webhooks module in farmOS

### Fix

- remove print statement

## v0.9.0 (2026-03-10)

### Feat

- add schema, edit/sync support for Seeding Logs
- add schema, edit/sync support for Equipment Assets
- add schema, edit/sync support for Equipment Types
- add schema, edit/sync support for Water Assets
- add edit/sync support for Material Types + Material Quantities
- add edit/sync support for Material Types
- add edit/sync support for Log Quantities
- add edit/sync support for `Log.groups`
- add edit/sync support for `Log.locations`
- expose Assets field when editing a Log record
- add edit/sync support for Plant Seasons
- add edit/sync support for asset parents

### Fix

- avoid error when material type is unknown
- improve behavior when deleting a Standard Quantity
- cleanup grid views for All, Standard Quantities
- add ordinal for sorting Measures
- expose `is_location` and `is_fixed` for editing on Animal Asset
- allow "N/A" option for animal sex
- fix Assets column for All Logs subgrid when viewing asset

## v0.8.0 (2026-03-04)

### Feat

- improve support for exporting quantity, log data
- show related Quantity records when viewing a Measure
- show related Quantity records when viewing a Unit
- show link to Log record when viewing Quantity

### Fix

- bump version requirement for wuttaweb

## v0.7.0 (2026-03-04)

### Feat

- expose "group membership" for assets
- expose "current location" for assets
- add schema, sync support for `Log.is_movement`
- add schema, import support for `Asset.owners`
- add schema, import support for `Log.quick`
- show quantities when viewing log
- add sync support for `MedicalLog.vet`
- add schema, import support for `Log.quantities`
- add schema, import support for `Log.groups`
- add schema, import support for `Log.locations`
- add sync support for `Log.is_group_assignment`
- add support for exporting log status, timestamp to farmOS
- add support for log 'owners'
- add support for edit, import/export of plant type data
- add way to create animal type when editing animal
- add related version tables for asset/log revision history
- improve mirror/deletion for assets, logs, animal types
- auto-delete asset from farmOS if deleting via mirror app

### Fix

- show drupal ID column for asset types
- remove unique constraint for `LandAsset.land_type_uuid`
- move farmOS UUID field below the Drupal ID
- add links for Parents column in All Assets grid
- set timestamp for new log in quick eggs form
- set default grid pagesize to 50
- add placeholder for log 'quick' field
- define log grid columns to match farmOS
- make AllLogView inherit from LogMasterView
- rename views for "all records" (all assets, all logs etc.)
- ensure token refresh works regardless where API client is used
- render links for Plant Type column in Plant Assets grid
- fix land asset type
- prevent edit for asset types, land types when app is mirror
- add farmOS-style links for Parents column in Land Assets grid
- remove unique constraint for `AnimalType.name`
- prevent delete if animal type is still being referenced
- add reminder to restart if changing integration mode
- prevent edit for user farmos_uuid, drupal_id
- remove 'contains' verb for sex filter
- add enum, row hilite for log status
- fix Sex field when empty and deleting an animal
- add `get_farmos_client_for_user()` convenience function
- use current user token for auto-sync within web app
- set log type, status enums for log grids
- add more default perms for first site admin user
- only show quick form menu if perms allow
- expose config for farmOS OAuth2 client_id and scope
- add separate permission for each quick form view

## v0.6.0 (2026-02-25)

### Feat

- add common normalizer to simplify code in view, importer etc.
- overhaul farmOS log views; add Eggs quick form
- add basic CRUD for direct API views: animal types, animal assets
- use 'include' API param for better Animal Assets grid data
- add backend filters, sorting for farmOS animal types, assets
- include/exclude certain views, menus based on integration mode
- add Standard Quantities table, views, import
- add Quantity Types table, views, import
- add Units table, views, import/export

### Fix

- add `Notes` schema type
- add grid filter for animal birthdate
- add thumbnail to farmOS asset base view
- add setting to toggle "farmOS-style grid links"
- standardize a bit more for the farmOS Animal Assets view
- set *default* instead of configured menu handler
- expose farmOS integration mode, URL in app settings
- reword some menu entries
- add WuttaFarm -> farmOS export for Plant Assets
- fix default admin user perms, per new log schema

## v0.5.0 (2026-02-18)

### Feat

- add `produces_eggs` flag for animal, group assets
- add more assets (plant) and logs (harvest, medical, observation)
- refactor log models, views to use generic/common base

### Fix

- rename db model modules, for better convention
- add override for requests cert validation

## v0.4.1 (2026-02-17)

### Fix

- remove `AnimalType.changed` column

## v0.4.0 (2026-02-17)

### Feat

- add basic support for WuttaFarm → farmOS export
- convert group assets to use common base/mixin
- convert structure assets to use common base/mixin
- convert land assets to use common base/mixin
- add "generic" assets, new animal assets based on that

### Fix

- misc. field tweaks for asset forms
- show warning when viewing an archived asset
- fix some perms for all assets view
- fix initial admin perms per route renaming
- add parent relationships support for land assets
- cleanup Land views to better match farmOS
- cleanup Structure views to better match farmOS
- cleanup Group views to better match farmOS
- add / display thumbnail image for animals
- improve handling of 'archived' records for grid/form views
- use Male/Female dict enum for animal sex field
- prevent direct edit of `farmos_uuid` and `drupal_id` fields
- use same datetime display format as farmOS
- convert `active` flag to `archived`
- suppress output when user farmos/drupal keys are empty
- customize page footer to mention farmOS

## v0.3.1 (2026-02-14)

### Fix

- update sterile, archived flags per farmOS 4.x

## v0.3.0 (2026-02-13)

### Feat

- add native table for Activity Logs; import from farmOS API
- add native table for Groups; import from farmOS API
- add native table for Animals; import from farmOS API
- add native table for Structures; import from farmOS API
- add native table for Land Assets; import from farmOS API
- add native table for Log Types; import from farmOS API
- add native table for Structure Types; import from farmOS API
- add native table for Land Types; import from farmOS API
- add native table for Asset Types; import from farmOS API
- add extension table for Users; import from farmOS API
- add native table for Animal Types; import from farmOS API
- add "See raw JSON data" button for farmOS API views

### Fix

- always make 'farmos' system user in app setup
- avoid error for Create User form
- add more perms to Site Admin role in app setup
- rename `drupal_internal_id` => `drupal_id`

## v0.2.3 (2026-02-08)

### Fix

- add custom (built) buefy css to repo

## v0.2.2 (2026-02-08)

### Fix

- update project links for PyPI

## v0.2.1 (2026-02-08)

### Fix

- run web app via uvicorn/ASGI by default

## v0.2.0 (2026-02-08)

### Feat

- add view for farmOS activity logs
- add view for farmOS log types
- add view for farmOS structure types
- add view for farmOS land types
- add view for farmOS land assets
- add view for farmOS groups
- add view for farmOS asset types
- add view for farmOS structures
- add view for farmOS animal types
- add view for farmOS users

### Fix

- add pyramid_exclog dependency
- add menu option, "Go to farmOS"
- ensure Buefy version matches what we use for custom css

## v0.1.5 (2026-02-07)

### Fix

- fix built wheel to include custom buefy css

## v0.1.4 (2026-02-07)

### Fix

- add custom style to better match farmOS color scheme

## v0.1.3 (2026-02-06)

### Fix

- fix a couple more edge cases around oauth2 token refresh

## v0.1.2 (2026-02-06)

### Fix

- add support for farmOS/OAuth2 Authorization Code grant/workflow

## v0.1.1 (2026-02-05)

### Fix

- preserve oauth2 token so auto-refresh works correctly
- customize app installer to configure farmos_url
- add some more info when viewing animal
- require minimum version for wuttaweb

## v0.1.0 (2026-02-03)

### Feat

- initial basic app to prove display of API (animal) data
