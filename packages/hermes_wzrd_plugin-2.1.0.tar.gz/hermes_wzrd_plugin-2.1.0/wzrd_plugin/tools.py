"""WZRD plugin tool handlers.

Three tools. Free. No auth. WZRD is an attention prior, not a router.
Handlers follow Hermes v0.3.0 plugin API: args dict, return JSON string.
"""

import json
import httpx

from .config import WZRD_API_URL


async def wzrd_trending_handler(args: dict, **kwargs) -> str:
    """What models are moving right now?"""
    limit = min(args.get("limit", 10), 50)
    platform = args.get("platform", "")
    params = {"limit": limit}
    if platform:
        params["platform"] = platform

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{WZRD_API_URL}/v1/signals/momentum",
                params=params,
            )
            resp.raise_for_status()
            data = resp.json()

        return json.dumps({
            "count": data.get("count", 0),
            "models": data.get("models", []),
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


async def wzrd_candidates_handler(args: dict, **kwargs) -> str:
    """Momentum-informed candidates for a task. Attention prior, not routing."""
    task = args.get("task", "general")
    limit = min(args.get("limit", 5), 20)

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{WZRD_API_URL}/v1/signals/momentum",
                params={"limit": 50},
            )
            resp.raise_for_status()
            models = resp.json().get("models", [])

        if not models:
            return json.dumps({"candidates": [], "reason": "No data available."})

        # Platform affinity for task types
        task_platform = {
            "code": "github", "coding": "github",
            "chat": "openrouter", "conversation": "openrouter",
            "reasoning": "artificial_analysis", "math": "artificial_analysis",
        }.get(task.lower())

        # Eligibility gate: exclude observe/insufficient from candidates
        eligible = [
            m for m in models
            if m.get("confidence") not in ("insufficient",)
            and m.get("action") not in ("observe",)
        ]

        # If nothing is eligible, fall back to all with normal confidence
        if not eligible:
            eligible = [m for m in models if m.get("confidence") == "normal"]

        # Score: base × trend × platform affinity
        trend_mult = {
            "surging": 1.5, "accelerating": 1.2, "stable": 1.0,
            "decelerating": 0.7, "cooling": 0.4,
        }

        scored = []
        for m in eligible:
            base = m.get("score", 0)
            trend = trend_mult.get(m.get("trend", "stable"), 0.8)
            platform_boost = 1.3 if task_platform and m.get("platform") == task_platform else 1.0
            scored.append({
                "model": m.get("model", ""),
                "trend": m.get("trend", "unknown"),
                "confidence": m.get("confidence", "unknown"),
                "candidate_score": round(base * trend * platform_boost, 3),
            })

        scored.sort(key=lambda x: -x["candidate_score"])

        return json.dumps({
            "task": task,
            "candidates": scored[:limit],
            "evaluated": len(models),
            "eligible": len(eligible),
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


async def wzrd_compare_handler(args: dict, **kwargs) -> str:
    """Compare two models by adoption momentum."""
    model_a = args.get("model_a", "")
    model_b = args.get("model_b", "")

    if not model_a or not model_b:
        return json.dumps({"error": "Both model_a and model_b are required."})

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{WZRD_API_URL}/v1/signals/momentum",
                params={"limit": 100},
            )
            resp.raise_for_status()
            models = resp.json().get("models", [])

        def find(name: str):
            lo = name.lower()
            for m in models:
                if lo in m.get("model", "").lower():
                    return m
            return None

        a, b = find(model_a), find(model_b)

        def fmt(m, name):
            if not m:
                return {"model": name, "status": "not_tracked"}
            return {
                "model": m.get("model", name),
                "trend": m.get("trend", "unknown"),
                "score": m.get("score", 0),
                "confidence": m.get("confidence", "unknown"),
            }

        fa, fb = fmt(a, model_a), fmt(b, model_b)
        sa = fa.get("score", 0)
        sb = fb.get("score", 0)

        if sa > sb * 1.1:
            verdict = f"{fa['model']} has stronger momentum"
        elif sb > sa * 1.1:
            verdict = f"{fb['model']} has stronger momentum"
        else:
            verdict = "Similar momentum"

        return json.dumps({"a": fa, "b": fb, "verdict": verdict})
    except Exception as e:
        return json.dumps({"error": str(e)})
