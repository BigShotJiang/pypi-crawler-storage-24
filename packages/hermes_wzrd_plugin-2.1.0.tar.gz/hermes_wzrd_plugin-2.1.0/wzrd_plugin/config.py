"""WZRD plugin configuration."""

import os

WZRD_API_URL = os.getenv("WZRD_API_URL", "https://api.twzrd.xyz")
