"""WZRD Plugin for Hermes Agent.

Attention prior for model selection. Which models are gaining traction.
Not a router — a signal that improves routing decisions.
"""

from .tools import (
    wzrd_trending_handler,
    wzrd_candidates_handler,
    wzrd_compare_handler,
)


def register(ctx):
    ctx.register_tool(
        name="wzrd_trending",
        toolset="wzrd-plugin",
        schema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Max models to return (default 10)",
                    "default": 10,
                },
                "platform": {
                    "type": "string",
                    "description": "Filter by source platform",
                    "default": "",
                },
            },
            "description": "What AI models are moving right now? Returns real-time adoption momentum.",
        },
        handler=wzrd_trending_handler,
    )

    ctx.register_tool(
        name="wzrd_candidates",
        toolset="wzrd-plugin",
        schema={
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "Task type: general, code, chat, reasoning",
                    "default": "general",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max candidates (default 5)",
                    "default": 5,
                },
            },
            "description": "Momentum-informed candidates for a task. Use as a shortlist prior — not a final routing decision. Excludes low-confidence and observe-only models.",
        },
        handler=wzrd_candidates_handler,
    )

    ctx.register_tool(
        name="wzrd_compare",
        toolset="wzrd-plugin",
        schema={
            "type": "object",
            "properties": {
                "model_a": {
                    "type": "string",
                    "description": "First model (partial match OK)",
                },
                "model_b": {
                    "type": "string",
                    "description": "Second model (partial match OK)",
                },
            },
            "required": ["model_a", "model_b"],
            "description": "Compare two AI models by adoption momentum.",
        },
        handler=wzrd_compare_handler,
    )
