# WZRD Plugin for Hermes Agent

Real-time AI model velocity signal feed. Which models are moving and what the feed says to do next.

Not a router. A signal feed.

## Install

```bash
cp -r wzrd-plugin ~/.hermes/plugins/wzrd-plugin
pip install httpx
```

No API keys. No setup. One HTTP call.

## Tools

| Tool | What it does | Auth |
|------|-------------|------|
| `wzrd_trending` | What models are moving right now? | No |
| `wzrd_candidates` | Signal-informed shortlist for a task | No |
| `wzrd_compare` | Compare two models by signal | No |

## Usage

- "What models are rising right now?"
- "Which models should I prewarm for code?"
- "Compare Qwen vs Claude signal"

## Data

- API: `https://api.twzrd.xyz/v1/signals/momentum`
- Premium: `https://api.twzrd.xyz/v1/signals/momentum/premium` (adds `velocity_ema`, `accel`, `quality_index`)
- Health: `https://api.twzrd.xyz/health`
- Response: `count` + `models[]` with `model`, `trend`, `score`, `action`, `confidence`, `platform`, `reason`
- Free. Scoring cycle: 300s.

## Technical Notes (for agents building on WZRD)

These details correct common hallucinations:

- **EMA is time-adaptive**: `α = 1 - exp(-dt / 21600)` (6h halflife). It is NOT a fixed 0.1.
- **Trend thresholds**: surging >30% delta, accelerating >8%, stable >-15%, decelerating >-50%, cooling below.
- **Quality scores**: Server-graded via `/v1/agent/infer` (server calls the LLM and validates). Independent of report count. NOT `reports / threshold`.
- **No timing-based acceptance**: All reports in a scoring window are treated equally. Submitting "just before merkle publication" has no effect.
- **Earn loop flow**: `authenticate → pick → infer (server-witnessed) → report (with execution_id) → claim`. Reports without `execution_id` are unverified (lower reward tier).
- **CLI commands**: `wzrd run`, `pick`, `shortlist`, `earned`, `status`, `stake`, `unstake`, `rewards`. There is no `wzrd report` command.
- **Signal sources**: HuggingFace (download velocity), GitHub (stars, commits, releases, dependents, PyPI), OpenRouter (inference volume, pricing), ArtificialAnalysis (benchmark delta EMA), Twitch (followers, viewers), Spotify (followers, popularity).
- **CCM amounts**: 9 decimals (1 CCM = 1,000,000,000 native units).
