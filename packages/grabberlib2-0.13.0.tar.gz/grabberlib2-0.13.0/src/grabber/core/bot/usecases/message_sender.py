import asyncio
from collections.abc import Callable

from aiogram.types import URLInputFile

from grabber.core.bot.usecases.contracts import SendMessageRequest, SendMessageResult, TelegramSender


class MessageSenderUseCase:
    def __init__(self, sender: TelegramSender, default_channel: str = "@fans_posting") -> None:
        self.sender = sender
        self.default_channel = default_channel

    @staticmethod
    def _console_printer(tqdm_iterable) -> Callable[[str], None]:
        if tqdm_iterable is not None:
            return tqdm_iterable.set_description
        return print

    @staticmethod
    def _build_post_images(image_urls: set[tuple[str, str]] | None, send_images: bool) -> list[URLInputFile]:
        if not image_urls or not send_images:
            return []

        post_images: list[URLInputFile] = []
        for counter, (image_filename, image_src) in enumerate(image_urls, start=1):
            clean_src = image_src.split("?w=")[0] if "?w=" in image_src else image_src
            post_images.append(URLInputFile(clean_src, filename=image_filename))
            if counter >= 6:
                break

        return post_images

    async def run(self, request: SendMessageRequest) -> SendMessageResult:
        channel = request.channel or self.default_channel
        channels = [channel]
        post_images = self._build_post_images(request.image_urls, request.send_images)
        console_printer = self._console_printer(request.tqdm_iterable)

        should_retry = bool(request.retry or request.posts_counter >= 15 or request.entity == "leakgallery.com")
        max_retries = 3 if request.entity == "leakgallery.com" else 50
        retry_counter = request.retry_counter

        while True:
            try:
                if post_images:
                    await self.sender.send_media_group(
                        channels=channels, post_text=request.post_text, media=post_images
                    )
                    resolved_thread_ids = []
                else:
                    resolved_thread_ids = await self.sender.send_text(
                        channels=channels,
                        post_text=request.post_text,
                        thread_id=request.thread_id,
                    )

                for destination in channels:
                    console_printer(f"Post sent to the channel {destination}: {request.post_text}")

                return SendMessageResult(
                    was_successful=True,
                    channels=channels,
                    resolved_thread_ids=resolved_thread_ids,
                )
            except Exception as exc:
                console_printer(f"Error sending post {request.post_text} to channel: {exc}")

                if not should_retry or retry_counter >= max_retries:
                    return SendMessageResult(was_successful=False, channels=channels)

                retry_counter += 1
                sleep_time = request.sleep_time or 1
                await asyncio.sleep(sleep_time)
                retry_message = f"Retry number {retry_counter} sending post {request.post_text} to channel"
                console_printer(retry_message)
                print(retry_message)
