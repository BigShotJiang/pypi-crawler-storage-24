import asyncio
from dataclasses import dataclass

from telegraph import Telegraph

from grabber.core.extractor.infrastructure.checkpoints import MediaCheckpointService, build_checkpoint_service
from grabber.core.extractor.infrastructure.helpers import get_entity
from grabber.core.extractor.sources.registry import SourceDispatcher
from grabber.core.extractor.usecases import SourceRunRequest
from grabber.core.settings import TELEGRAPH_TOKEN


@dataclass(slots=True)
class SourcePostingRequest:
    sources: list[str]
    channel: str
    max_pages: int = 500
    final_dest: str = ""
    save_to_telegraph: bool = True
    is_tag: bool = False
    limit: int = 0
    is_video_enabled: bool = False


class SourcePostingUseCase:
    def __init__(
        self,
        source_dispatcher: SourceDispatcher | None = None,
        telegraph_token: str | None = None,
        checkpoint_service: MediaCheckpointService | None = None,
    ) -> None:
        self.source_dispatcher = source_dispatcher or SourceDispatcher()
        self.telegraph_token = telegraph_token or TELEGRAPH_TOKEN
        self.checkpoint_service = checkpoint_service or build_checkpoint_service()

    async def run(self, request: SourcePostingRequest) -> None:
        telegraph_client = Telegraph(access_token=self.telegraph_token)

        for source_url in request.sources:
            source_entity = get_entity([source_url])
            checkpoint_hint = self.checkpoint_service.get_hint(source_url)
            await self.source_dispatcher.dispatch(
                SourceRunRequest(
                    sources=[source_url],
                    entity=source_entity,
                    telegraph_client=telegraph_client,
                    final_dest=request.final_dest,
                    save_to_telegraph=request.save_to_telegraph,
                    is_tag=request.is_tag,
                    limit=request.limit,
                    is_video_enabled=request.is_video_enabled,
                    channel=request.channel,
                    max_pages=request.max_pages,
                    checkpoint_hint=checkpoint_hint,
                )
            )
            await asyncio.sleep(2)
