import multiprocessing
import pathlib

from environs import Env

env = Env()
env.read_env()
APP_ROOT = pathlib.Path(__file__).parent.parent.parent.parent
USER_MEDIA_ROOT_PATH = env.str("USER_MEDIA_ROOT", ".media")
MEDIA_ROOT = APP_ROOT / "media"
KEY = env.str("KEY", "default")
BOT_TOKEN = env.str("BOT_TOKEN", "")
TELEGRAPH_TOKEN = env.str("TELEGRAPH_TOKEN", "")
SHORT_NAME = env.str("SHORT_NAME", "")
AUTHOR_NAME = env.str("AUTHOR_NAME", "")
AUTHOR_URL = env.str("AUTHOR_URL", "")
DEFAULT_THREADS_NUMBER = multiprocessing.cpu_count()
MAX_IMAGES_PER_POST = env.int("MAX_IMAGES_PER_POST", 99)
CHECKPOINT_ENABLED = env.bool("CHECKPOINT_ENABLED", True)
CHECKPOINT_FILE_PATH = env.str("CHECKPOINT_FILE_PATH", "").strip()
CHECKPOINT_SERVER_MODE = env.bool("CHECKPOINT_SERVER_MODE", pathlib.Path.home().as_posix().startswith("/home/"))
CHECKPOINT_MAX_SEEN_PER_SOURCE = env.int("CHECKPOINT_MAX_SEEN_PER_SOURCE", 10000)
CHECKPOINT_RECENT_WINDOW = env.int("CHECKPOINT_RECENT_WINDOW", 200)
CHECKPOINT_CONSECUTIVE_SEEN_STOP = env.int("CHECKPOINT_CONSECUTIVE_SEEN_STOP", 20)
PORNHUB_COOKIES_FILE_PATH = env.str("PORNHUB_COOKIES_FILE_PATH", "").strip()
CHANNELS = {
    "@leaked_postings": "-1003339490008",
    "@heavenly_cosplays": "-1003798670269",
    "@heavenly_asians": "-1003746809315",
    "Golden Pron": "-1003835153909",
    # "@temp_coser_posting": "-1002568501820",
    # "@temp_asian_posting": "-1002825542994",
    # "@temp_onlyfans_posting": "-1002645848524",
    # "@mypronvideos": "-1002544067024",
}


def get_media_root() -> pathlib.Path:
    USER_MEDIA_ROOT_PATH = env.str("USER_MEDIA_ROOT", None)

    if USER_MEDIA_ROOT_PATH is not None:
        media_root = pathlib.Path(USER_MEDIA_ROOT_PATH)
    else:
        media_root = MEDIA_ROOT

    return media_root
