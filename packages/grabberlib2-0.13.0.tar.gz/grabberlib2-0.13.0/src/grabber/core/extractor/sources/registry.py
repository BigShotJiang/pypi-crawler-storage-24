import importlib
from collections.abc import Awaitable, Callable
from dataclasses import dataclass

from grabber.core.extractor.sources.asianviralhub import get_sources_for_asianviralhub
from grabber.core.extractor.sources.asiaontop import get_sources_for_asiaontop
from grabber.core.extractor.sources.buondua import get_sources_for_buondua
from grabber.core.extractor.sources.celeb_cx import get_sources_for_celebcx
from grabber.core.extractor.sources.chunmomo import get_sources_for_chunmomo
from grabber.core.extractor.sources.common import get_sources_for_common
from grabber.core.extractor.sources.coomer import get_sources_for_coomer
from grabber.core.extractor.sources.cosxuxi import get_sources_for_cosxuxi
from grabber.core.extractor.sources.ehentai import get_sources_for_ehentai
from grabber.core.extractor.sources.eporner import get_sources_for_eporner
from grabber.core.extractor.sources.erome import get_sources_for_erome
from grabber.core.extractor.sources.erome_tv import get_sources_for_erome_tv
from grabber.core.extractor.sources.erome_vip import get_sources_for_erome_vip
from grabber.core.extractor.sources.everia import get_sources_for_everia
from grabber.core.extractor.sources.fapachi import get_sources_for_fapachi
from grabber.core.extractor.sources.fapello import get_sources_for_fapello
from grabber.core.extractor.sources.fapello_pics import get_sources_for_fapello_pics
from grabber.core.extractor.sources.fapello_ru import get_sources_for_fapello_ru
from grabber.core.extractor.sources.fapello_su import get_sources_for_fapello_su
from grabber.core.extractor.sources.fapello_to import get_sources_for_fapello_to
from grabber.core.extractor.sources.fapexy import get_sources_for_fapexy
from grabber.core.extractor.sources.fapeza import get_sources_for_fapeza
from grabber.core.extractor.sources.fapodrop import get_sources_for_fapodrop
from grabber.core.extractor.sources.fapomania import get_sources_for_fapomania
from grabber.core.extractor.sources.faponic import get_sources_for_faponic
from grabber.core.extractor.sources.fuligirl import get_sources_for_fuligirl
from grabber.core.extractor.sources.graph import get_for_telegraph
from grabber.core.extractor.sources.hentai_club import get_sources_for_hentai_club
from grabber.core.extractor.sources.hotgirl2024 import get_sources_for_hotgirl2024
from grabber.core.extractor.sources.hotgirl_asia import get_sources_for_hotgirl_asia
from grabber.core.extractor.sources.hotgirl_china import get_sources_for_hotgirl_china
from grabber.core.extractor.sources.hotleaks import get_sources_for_hotleaks
from grabber.core.extractor.sources.ibradome.usecase import get_sources_for_ibradome
from grabber.core.extractor.sources.jrants import get_sources_for_jrant
from grabber.core.extractor.sources.kemono import get_sources_for_kemono
from grabber.core.extractor.sources.khd import get_sources_for_4khd
from grabber.core.extractor.sources.kup import get_sources_for_4kup
from grabber.core.extractor.sources.leakedzone import get_sources_for_leakedzone
from grabber.core.extractor.sources.leakgallery import get_sources_for_leakgallery
from grabber.core.extractor.sources.lewdweb import get_sources_for_lewdweb
from grabber.core.extractor.sources.lovecos import get_sources_for_lovecos
from grabber.core.extractor.sources.masterfap import get_sources_for_masterfap
from grabber.core.extractor.sources.misskon import get_sources_for_misskon
from grabber.core.extractor.sources.mitaku import get_sources_for_mitaku
from grabber.core.extractor.sources.notion import get_sources_for_notion
from grabber.core.extractor.sources.nsfw247 import get_sources_for_nsfw24
from grabber.core.extractor.sources.nudecosplay import get_sources_for_nudecosplay
from grabber.core.extractor.sources.nudogram import get_sources_for_nudogram
from grabber.core.extractor.sources.nudostar import get_sources_for_nudostar
from grabber.core.extractor.sources.picazor import get_sources_for_picazor
from grabber.core.extractor.sources.picsclub import get_sources_for_picsclub
from grabber.core.extractor.sources.pixibb import get_sources_for_pixibb
from grabber.core.extractor.sources.pornhub import get_sources_for_pornhub
from grabber.core.extractor.sources.rokuhentai import get_sources_for_rokuhentai
from grabber.core.extractor.sources.spacemiss import get_sources_for_spacemiss
from grabber.core.extractor.sources.sweetlicious import get_sources_for_sweetlicious
from grabber.core.extractor.sources.thefapnet import get_sources_for_the_fap_net
from grabber.core.extractor.sources.thefappening import get_sources_for_fappening
from grabber.core.extractor.sources.topfapgirls import get_sources_for_topfapgirls
from grabber.core.extractor.sources.ugirls import get_sources_for_ugirls
from grabber.core.extractor.sources.wildskirts import get_sources_for_wildskirts
from grabber.core.extractor.sources.xasiat import get_for_xasiat
from grabber.core.extractor.sources.xchina import get_sources_for_xchina
from grabber.core.extractor.sources.xiuren import get_sources_for_xiuren
from grabber.core.extractor.sources.xlust import get_sources_for_xlust
from grabber.core.extractor.sources.xmissy import get_sources_for_xmissy
from grabber.core.extractor.sources.xpics import get_sources_for_xpics
from grabber.core.extractor.usecases import SourceRunRequest, SourceUseCase
from grabber.core.sources.ouo import ouo_bypass

SourceHandler = Callable[..., Awaitable[None]]


async def run_ouo_source(
    sources: list[str],
    entity: str,
    **_: object,
) -> None:
    __ = entity
    await ouo_bypass(sources)


@dataclass(slots=True)
class FunctionSourceUseCase:
    handler: SourceHandler

    async def run(self, request: SourceRunRequest) -> None:
        await self.handler(**request.as_kwargs())


class SourceRegistry:
    def __init__(self) -> None:
        self.default_handler: SourceHandler = get_sources_for_common
        self._usecase_by_module: dict[str, SourceUseCase] = {}
        self._mapping: dict[str, SourceHandler] = {
            "4kup.net": get_sources_for_4kup,
            "asianviralhub.com": get_sources_for_asianviralhub,
            "asigirl.com": get_sources_for_common,
            "avjb.com": get_for_xasiat,
            "bestgirlsexy.com": get_sources_for_common,
            "buondua.com": get_sources_for_buondua,
            "celeb.cx": get_sources_for_celebcx,
            "chunmomo.net": get_sources_for_chunmomo,
            "coomer.st": get_sources_for_coomer,
            "cosplaytele.com": get_sources_for_common,
            "cosxuxi.club": get_sources_for_cosxuxi,
            "dvir.ru": get_sources_for_nudogram,
            "e-hentai.org": get_sources_for_ehentai,
            "en.jrants.com": get_sources_for_jrant,
            "en.xchina.co": get_sources_for_xchina,
            "erome.com": get_sources_for_erome,
            "erome.vip": get_sources_for_erome_vip,
            "es.erome.com": get_sources_for_erome,
            "everia.club": get_sources_for_everia,
            "fapachi.com": get_sources_for_fapachi,
            "fapello.com": get_sources_for_fapello,
            "fapello.pics": get_sources_for_fapello_pics,
            "fapello.ru": get_sources_for_fapello_ru,
            "fapello.su": get_sources_for_fapello_su,
            "fapello.to": get_sources_for_fapello_to,
            "fapexy.com": get_sources_for_fapexy,
            "fapeza.com": get_sources_for_fapeza,
            "faponic.com": get_sources_for_faponic,
            "fapodrop.com": get_sources_for_fapodrop,
            "fapomania.com": get_sources_for_fapomania,
            "forum.lewdweb.net": get_sources_for_lewdweb,
            "fuligirl.top": get_sources_for_fuligirl,
            "hentaiclub.net": get_sources_for_hentai_club,
            "hotgirl.asia": get_sources_for_hotgirl_asia,
            "hotgirl.biz": get_sources_for_nudecosplay,
            "hotgirlchina.com": get_sources_for_hotgirl_china,
            "hotleaks.tv": get_sources_for_hotleaks,
            "jrants.com": get_sources_for_jrant,
            "kemono.cr": get_sources_for_kemono,
            "leakedzone.com": get_sources_for_leakedzone,
            "leakgallery.com": get_sources_for_leakgallery,
            "misskon.com": get_sources_for_misskon,
            "mitaku.net": get_sources_for_mitaku,
            "new.pixibb.com": get_sources_for_pixibb,
            "notion": get_sources_for_notion,
            "nsfw247.to": get_sources_for_nsfw24,
            "nudebird.biz": get_sources_for_nudecosplay,
            "nudecosplay.biz": get_sources_for_nudecosplay,
            "nudogram.com": get_sources_for_nudogram,
            "nudostar.tv": get_sources_for_nudostar,
            "ouo": run_ouo_source,
            "ouo.io": run_ouo_source,
            "ouo.press": run_ouo_source,
            "picazor.com": get_sources_for_picazor,
            "picsclub.ru": get_sources_for_picsclub,
            "pornhub.com": get_sources_for_pornhub,
            "www.pornhub.com": get_sources_for_pornhub,
            "m.pornhub.com": get_sources_for_pornhub,
            "pt.jrants.com": get_sources_for_jrant,
            "rokuhentai.com": get_sources_for_rokuhentai,
            "sexy.pixibb.com": get_sources_for_pixibb,
            "spacemiss.com": get_sources_for_spacemiss,
            "telegra.ph": get_for_telegraph,
            "thefap.net": get_sources_for_the_fap_net,
            "thefappening.plus": get_sources_for_fappening,
            "topfapgirls.net": get_sources_for_topfapgirls,
            "ugirls.pics": get_sources_for_ugirls,
            "wildskirts.com": get_sources_for_wildskirts,
            "www.4khd.com": get_sources_for_4khd,
            "www.eporner.com": get_sources_for_eporner,
            "www.erome.com": get_sources_for_erome,
            "www.erome.tv": get_sources_for_erome_tv,
            "www.erome.vip": get_sources_for_erome_vip,
            "www.everiaclub.com": get_sources_for_everia,
            "www.fapello.ru": get_sources_for_fapello_ru,
            "www.hentaiclub.net": get_sources_for_hentai_club,
            "www.hotgirl2024.com": get_sources_for_hotgirl2024,
            "www.lovecos.net": get_sources_for_lovecos,
            "www.masterfap.net": get_sources_for_masterfap,
            "www.sweetlicious.net": get_sources_for_sweetlicious,
            "www.topfapgirls.net": get_sources_for_topfapgirls,
            "www.xasiat.com": get_for_xasiat,
            "www.xpics.me": get_sources_for_xpics,
            "www.wildskirts.com": get_sources_for_wildskirts,
            "xiuren.biz": get_sources_for_xiuren,
            "xlust.org": get_sources_for_xlust,
            "xmissy.nl": get_sources_for_xmissy,
            "xpics.me": get_sources_for_xpics,
            "youwu.lol": get_sources_for_fuligirl,
            "asiaon.top": get_sources_for_asiaontop,
            "ibradome.com": get_sources_for_ibradome,
            "leaknudes.com": get_sources_for_ibradome,
        }

    def resolve_handler(self, entity: str) -> SourceHandler:
        return self._mapping.get(entity, self.default_handler)

    def _resolve_usecase_from_handler(self, handler: SourceHandler) -> SourceUseCase | None:
        module_name = getattr(handler, "__module__", "")
        if not module_name:
            return None

        if module_name in self._usecase_by_module:
            return self._usecase_by_module[module_name]

        package_name = module_name.split(".")[-2] if "." in module_name else ""
        if not package_name:
            return None

        class_name = "".join(part[:1].upper() + part[1:] for part in package_name.split("_")) + "UseCase"
        try:
            module = importlib.import_module(module_name)
            usecase_cls = getattr(module, class_name, None)
            if usecase_cls is None:
                return None
            usecase: SourceUseCase = usecase_cls()
        except Exception:
            return None

        self._usecase_by_module[module_name] = usecase
        return usecase

    def resolve_usecase(self, entity: str) -> SourceUseCase:
        handler = self.resolve_handler(entity)
        usecase = self._resolve_usecase_from_handler(handler)
        if usecase is not None:
            return usecase
        return FunctionSourceUseCase(handler=handler)


class SourceDispatcher:
    def __init__(self, registry: SourceRegistry | None = None) -> None:
        self.registry = registry or SourceRegistry()

    async def dispatch(self, request: SourceRunRequest) -> None:
        usecase = self.registry.resolve_usecase(request.entity)
        await usecase.run(request)
