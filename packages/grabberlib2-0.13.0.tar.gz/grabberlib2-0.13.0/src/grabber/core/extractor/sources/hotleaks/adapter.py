from typing import Any

from .parser import get_sources_for_hotleaks


class HotleaksAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_hotleaks(**kwargs)


__all__ = ["HotleaksAdapter"]
