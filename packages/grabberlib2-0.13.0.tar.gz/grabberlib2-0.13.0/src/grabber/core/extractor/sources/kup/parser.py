from typing import cast

from bs4 import BeautifulSoup, Tag


class KupParser:
    @staticmethod
    def get_page_title(soup: BeautifulSoup) -> str:
        title = cast(Tag, soup.select_one("title")).get_text(separator=" ", strip=True)
        return title.split("– Beautiful")[0].rstrip()
