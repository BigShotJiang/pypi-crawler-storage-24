import pathlib
from typing import cast

from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph
from unidecode import unidecode

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.usecases import run_default_source

SPLIT_TEXT_MAPPING = {
    "nudebird.biz": "- Nude Bird",
    "nudecosplay.biz": "- nudecosplay.biz",
    "hotgirl.biz": "- Hotgirl.biz",
}


def build_page_title_factory(entity: str):
    split_text = SPLIT_TEXT_MAPPING[entity]

    def get_page_title(soup: BeautifulSoup) -> str:
        raw_title = cast(Tag, soup.find("title")).get_text(strip=True)
        page_title = raw_title.split(split_text)[0].strip().rstrip().split("/nudecosplay.biz/")[0]
        return unidecode(
            " ".join(
                f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}"
                for part in page_title.split("/")
            )
        )

    return get_page_title


async def get_sources_for_nudecosplay(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph,
    final_dest: pathlib.Path | None = None,
    save_to_telegraph: bool | None = False,
    is_tag: bool | None = False,
    limit: int | None = None,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        title_factory=build_page_title_factory(entity),
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest if final_dest else "",
        save_to_telegraph=save_to_telegraph,
        is_tag=is_tag,
        limit=limit,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
        tag_pagination_target="nudecosplay",
    )
