import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from tenacity import retry, retry_if_exception_type, wait_chain, wait_fixed
from url_parser import get_base_url, parse_url


class FapelloPicsAdapter:
    @retry(
        wait=wait_chain(
            *[wait_fixed(3) for _ in range(5)]
            + [wait_fixed(7) for _ in range(4)]
            + [wait_fixed(9) for _ in range(3)]
            + [wait_fixed(15)],
        ),
        reraise=True,
        retry=retry_if_exception_type(httpx.ReadTimeout),
    )
    async def get_response(
        self,
        url: str,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        async with httpx.AsyncClient(http2=True) as client:
            response = await client.get(url=url, headers=headers)

        if response.status_code >= 300:
            raise RuntimeError(f"Unable to retrieve {url}: {response.status_code}")

        return response

    async def get_pages_from_pagination(
        self,
        url: str,
        query: str,
        src_attr: str,
        headers: dict[str, str] | None = None,
    ) -> IndexedSet:
        images_tags = IndexedSet()
        base_url = get_base_url(url)
        response = await self.get_response(url=url, headers=headers)
        soup = BeautifulSoup(response.text, features="lxml")
        image_candidates = soup.select(query)
        if not image_candidates:
            return IndexedSet()
        first_tag = image_candidates[0]
        image_src = first_tag.attrs[src_attr]
        parsed_image_src = parse_url(image_src)
        image_filename = parsed_image_src["file"]
        last_image_counter_str = image_filename.split("/")[-1].split("_")[1]
        model_name = image_filename.split("/")[-1].split("_")[0]
        image_url_dir = parsed_image_src["dir"]
        max_image_counter = int(last_image_counter_str.split(".")[0])

        for image_counter in range(1, max_image_counter + 1):
            image_prefix = f"{image_counter}".zfill(4)
            img_filename = f"{model_name}_{image_prefix}.jpg"
            image_url = f"{base_url}{image_url_dir}{img_filename}"
            images_tags.add((image_prefix, f"{image_prefix}-{img_filename}", img_filename, image_url))

        return IndexedSet([item[1:] for item in images_tags])
