from typing import Any

from .parser import get_sources_for_fapello_to


class FapelloToAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_fapello_to(**kwargs)


__all__ = ["FapelloToAdapter"]
