from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag

from grabber.core.extractor.infrastructure.fetching.scraper import get_soup


class NudogramAdapter:
    pagination_query = "div.pagination div.pagination-holder ul li a"
    images_query = (
        "div.main-content div.main-container div#list_videos_common_videos_list "
        "div.box div.list-videos div.margin-fix div.item a div img"
    )

    async def fetch_page(self, url: str, headers: dict[str, str] | None = None) -> BeautifulSoup:
        return await get_soup(target_url=url, headers=headers, use_web_driver=True)

    async def get_images_from_pagination(
        self,
        url: str,
        headers: dict[str, str] | None = None,
    ) -> list[Tag]:
        pagination_links = IndexedSet([url])
        images_tags: IndexedSet = IndexedSet()

        first_page = await self.fetch_page(url=url, headers=headers)
        pagination_set = first_page.select(self.pagination_query)

        if not pagination_set:
            return list(first_page.select(self.images_query))

        for page_url in pagination_set:
            link = page_url.attrs.get("href", "").strip()
            if not link:
                continue
            if not link.startswith("https:"):
                link = f"https:{link}"
            pagination_links.add(link)

        for link in pagination_links:
            soup = await self.fetch_page(url=link, headers=headers)
            images_tags.update(*soup.select(self.images_query))

        return list(images_tags)
