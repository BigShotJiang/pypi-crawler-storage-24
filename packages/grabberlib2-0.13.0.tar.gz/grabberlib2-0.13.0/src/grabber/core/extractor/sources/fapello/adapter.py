from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup, Tag

from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint, hash_media_url, normalize_media_url
from grabber.core.settings import CHECKPOINT_CONSECUTIVE_SEEN_STOP


class FapelloAdapter:
    pagination_base_url = "https://fapello.com/ajax/model/{model_slug}/page-{page_number}/"

    def __init__(self) -> None:
        self._checkpoint_hint: SourceCheckpointHint | None = None

    def configure_checkpoint_hint(self, checkpoint_hint: SourceCheckpointHint | None) -> None:
        self._checkpoint_hint = checkpoint_hint

    async def get_media_from_pagination(
        self,
        url: str,
        headers: dict[str, str] | None = None,
        query: str = "",
        videos_query: str = "div.flex.justify-between.items-center video",
    ) -> tuple[list[Tag], list[Tag]]:
        parsed_url = urlparse(url)
        model_slug = parsed_url.path.replace("/", "")
        page_number = 1
        images_tags: list[Tag] = []
        videos_tags: list[Tag] = []
        processed_video_links: set[str] = set()
        seen_hashes = self._checkpoint_hint.seen_hashes if self._checkpoint_hint is not None else set()
        consecutive_seen = 0

        while True:
            target_url = self.pagination_base_url.format(model_slug=model_slug, page_number=page_number)
            page_response = httpx.get(url=target_url, headers=headers)
            page_content = page_response.content.decode("utf-8")
            if not page_content:
                break

            soup = BeautifulSoup(page_content, features="lxml")
            current_image_tags = soup.select(query)

            if seen_hashes:
                candidate_urls = []
                for tag in current_image_tags:
                    src = tag.attrs.get("src") or tag.attrs.get("data-src")
                    if not src:
                        continue
                    if not src.startswith("http"):
                        src = f"https:{src}" if src.startswith("//") else f"https://fapello.com{src}"
                    candidate_urls.append(src)

                if candidate_urls and all(
                    hash_media_url(normalize_media_url(candidate_url)) in seen_hashes
                    for candidate_url in candidate_urls
                ):
                    consecutive_seen += len(candidate_urls)
                    if consecutive_seen >= CHECKPOINT_CONSECUTIVE_SEEN_STOP:
                        break
                    page_number += 1
                    continue
                consecutive_seen = 0

            images_tags.extend([tag for tag in current_image_tags if ".svg" not in tag.attrs.get("src", "")])

            for tag in current_image_tags:
                if "icon-play.svg" not in tag.attrs.get("src", ""):
                    continue
                for a_tag in soup.select("div a"):
                    has_play_icon = any("icon-play.svg" in a_img.attrs.get("src", "") for a_img in a_tag.select("img"))
                    if not has_play_icon:
                        continue

                    link = a_tag.attrs.get("href", "")
                    if not link:
                        continue
                    if link in processed_video_links:
                        continue
                    processed_video_links.add(link)
                    response = httpx.get(url=link, headers=headers)
                    video_soup = BeautifulSoup(response.content, features="lxml")
                    videos_tags.extend(video_soup.select(videos_query))

            page_number += 1

        return images_tags, videos_tags
