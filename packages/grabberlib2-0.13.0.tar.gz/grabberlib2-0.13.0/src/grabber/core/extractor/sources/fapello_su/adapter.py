from typing import Any

from .parser import get_sources_for_fapello_su


class FapelloSuAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_fapello_su(**kwargs)


__all__ = ["FapelloSuAdapter"]
