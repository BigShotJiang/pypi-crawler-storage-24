import pathlib

from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_pages_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    pagination_query = "div.gtb table tr td a"
    images_pages_query = "div#gdt a"

    source_urls = [url]
    soup = await get_soup(url, headers=headers)

    for a_tag in soup.select(pagination_query):
        href = a_tag.attrs.get("href", "")
        if href:
            source_urls.append(href)

    image_links = []
    for page_url in list(dict.fromkeys(source_urls)):
        page_soup = await get_soup(page_url, headers=headers)
        for image_tag in page_soup.select(images_pages_query):
            href = image_tag.attrs.get("href", "")
            if href:
                image_links.append(href)

    return list(dict.fromkeys(image_links))


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-e-hentai.org"
    return title_tag.get_text(strip=True).split("- E-Hentai")[0].strip().rstrip()


async def get_sources_for_ehentai(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
