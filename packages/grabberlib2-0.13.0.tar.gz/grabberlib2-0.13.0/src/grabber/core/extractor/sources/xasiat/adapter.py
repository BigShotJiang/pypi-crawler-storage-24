from typing import Any

from .parser import get_for_xasiat


class XasiatAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_for_xasiat(**kwargs)


__all__ = ["XasiatAdapter"]
