import httpx
from bs4 import BeautifulSoup, Tag

from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint


class IbradomeAdapter:
    base_url = "https://ibradome.com/"

    def __init__(self) -> None:
        self._checkpoint_hint: SourceCheckpointHint | None = None

    def configure_checkpoint_hint(self, checkpoint_hint: SourceCheckpointHint | None) -> None:
        self._checkpoint_hint = checkpoint_hint

    async def get_media_from_page(
        self,
        url: str,
        headers: dict[str, str] | None = None,
        query: str = "",
        src_attr: str = "src",
    ) -> tuple[list[Tag], list[Tag]]:
        images_tags: list[Tag] = []
        videos_tags: list[Tag] = []

        target_url = url
        page_response = httpx.get(url=target_url, headers=headers)
        page_content = page_response.content.decode("utf-8")

        soup = BeautifulSoup(page_content, features="lxml")
        current_image_tags = soup.select(query)

        for tag in current_image_tags:
            src = tag.attrs.get(src_attr, "")

            if not src.startswith("http") and ".svg" not in src:
                src = f"{self.base_url}{src}"
                tag.attrs[src_attr] = src  # Update tag with absolute URL for downstream processing
                images_tags.append(tag)  # Add tag to images_tags since it has a valid src now

        return images_tags, videos_tags
