from typing import Any

from .parser import get_sources_for_xpics


class XpicsAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_xpics(**kwargs)


__all__ = ["XpicsAdapter"]
