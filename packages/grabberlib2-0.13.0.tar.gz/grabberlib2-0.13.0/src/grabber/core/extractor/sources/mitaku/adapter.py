from typing import Any

from .parser import get_sources_for_mitaku


class MitakuAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_mitaku(**kwargs)


__all__ = ["MitakuAdapter"]
