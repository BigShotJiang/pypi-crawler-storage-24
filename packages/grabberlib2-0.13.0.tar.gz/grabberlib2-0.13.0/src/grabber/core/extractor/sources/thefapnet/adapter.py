from typing import Any

from .parser import get_sources_for_the_fap_net


class ThefapnetAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_the_fap_net(**kwargs)


__all__ = ["ThefapnetAdapter"]
