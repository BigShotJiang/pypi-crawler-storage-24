import pathlib
from typing import cast

from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_tags
from grabber.core.extractor.usecases import run_default_source


async def get_images_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    page_nav_query = "div.page-link-box li a.page-numbers"
    tags, _ = await get_tags(url, headers=headers, query=page_nav_query, bypass_cloudflare=True)
    return [a.attrs["href"] for a in tags if tags]


def get_page_title(soup: BeautifulSoup) -> str:
    title = cast(Tag, soup.select_one("title")).get_text(strip=True)
    return title.strip().rstrip()


async def get_sources_for_mitaku(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        bypass_cloudflare=True,
        pagination_fetcher=get_images_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
