from typing import Any

from .parser import get_sources_for_fapachi


class FapachiAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_fapachi(**kwargs)


__all__ = ["FapachiAdapter"]
