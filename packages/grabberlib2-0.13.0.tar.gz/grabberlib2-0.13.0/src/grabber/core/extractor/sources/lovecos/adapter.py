from typing import Any

from .parser import get_sources_for_lovecos


class LovecosAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_lovecos(**kwargs)


__all__ = ["LovecosAdapter"]
