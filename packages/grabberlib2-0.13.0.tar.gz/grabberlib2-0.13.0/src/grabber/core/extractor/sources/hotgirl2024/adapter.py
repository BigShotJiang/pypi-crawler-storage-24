from typing import Any

from .parser import get_sources_for_hotgirl2024


class Hotgirl2024Adapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_hotgirl2024(**kwargs)


__all__ = ["Hotgirl2024Adapter"]
