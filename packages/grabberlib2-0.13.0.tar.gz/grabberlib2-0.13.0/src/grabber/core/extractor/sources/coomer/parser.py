from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

from boltons.setutils import IndexedSet

from grabber.core.extractor import ExtractorResult


@dataclass(frozen=True, slots=True)
class CoomerUserRef:
    service: str
    user_id: str


class CoomerParser:
    IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".avif")
    VIDEO_EXTENSIONS = (".mp4", ".m4v", ".mov", ".webm", ".mkv", ".avi", ".wmv", ".m3u8")
    PAGE_SIZE = 50
    MEDIA_BASE_URL = "https://n1.coomer.st/data"

    def parse_user_reference(self, source_url: str) -> CoomerUserRef:
        parsed = urlparse(source_url)
        path_parts = [part for part in parsed.path.split("/") if part]
        if len(path_parts) < 3 or path_parts[1] != "user" or not path_parts[2]:
            raise ValueError(f"Unsupported coomer source URL: {source_url}")

        return CoomerUserRef(service=path_parts[0], user_id=path_parts[2])

    def build_posts_endpoint(self, user_ref: CoomerUserRef, offset: int = 0) -> str:
        endpoint = f"https://coomer.st/api/v1/{user_ref.service}/user/{user_ref.user_id}/posts"
        if offset <= 0:
            return endpoint
        return f"{endpoint}?o={offset}"

    def build_profile_endpoint(self, user_ref: CoomerUserRef) -> str:
        return f"https://coomer.st/api/v1/{user_ref.service}/user/{user_ref.user_id}/profile"

    def normalize_media_url(self, raw_path: str) -> str | None:
        candidate = str(raw_path).strip()
        if not candidate:
            return None
        if candidate.startswith(("http://", "https://")):
            return candidate
        if candidate.startswith("//"):
            return f"https:{candidate}"
        if candidate.startswith("/"):
            return f"{self.MEDIA_BASE_URL}{candidate}"
        if candidate.startswith("data/"):
            return f"https://n1.coomer.st/{candidate}"
        if candidate.startswith("n1.coomer.st/"):
            return f"https://{candidate}"
        return None

    def extract_media_urls(self, posts: list[dict[str, Any]]) -> tuple[list[str], list[str]]:
        image_urls: list[str] = []
        video_urls: list[str] = []
        seen_urls: set[str] = set()

        for post in posts:
            for media_url in self._iter_post_media_urls(post):
                if media_url in seen_urls:
                    continue
                seen_urls.add(media_url)
                if self._is_video_url(media_url):
                    video_urls.append(media_url)
                elif self._is_image_url(media_url):
                    image_urls.append(media_url)

        return image_urls, video_urls

    def build_page_title(
        self,
        source_url: str,
        posts: list[dict[str, Any]],
        profile: dict[str, Any] | None = None,
    ) -> str:
        _ = posts
        if isinstance(profile, dict):
            profile_name = str(profile.get("name", "")).strip()
            if profile_name:
                return self._build_hashtags_from_name(profile_name)

        user_ref = self.parse_user_reference(source_url)
        return f"#coomer #{user_ref.service} #user_{user_ref.user_id}"

    def build_extractor_result(
        self,
        source_url: str,
        posts: list[dict[str, Any]],
        profile: dict[str, Any] | None = None,
    ) -> ExtractorResult | None:
        image_urls, video_urls = self.extract_media_urls(posts)
        if not image_urls and not video_urls:
            return None

        image_records = IndexedSet(
            (self._build_filename(index, image_url), image_url) for index, image_url in enumerate(image_urls, start=1)
        )
        video_records = IndexedSet(
            (self._build_filename(index, video_url), "", video_url)
            for index, video_url in enumerate(video_urls, start=1)
        )

        return ExtractorResult(
            page_title=self.build_page_title(source_url=source_url, posts=posts, profile=profile),
            ordered_unique_img_urls=image_records,
            ordered_unique_video_urls=video_records if video_records else None,
        )

    def _iter_post_media_urls(self, post: dict[str, Any]):
        top_level_file = post.get("file")
        if isinstance(top_level_file, dict):
            media_url = self.normalize_media_url(str(top_level_file.get("path", "")))
            if media_url is not None:
                yield media_url

        attachments = post.get("attachments", [])
        if not isinstance(attachments, list):
            return

        for attachment in attachments:
            if not isinstance(attachment, dict):
                continue
            media_url = self.normalize_media_url(str(attachment.get("path", "")))
            if media_url is not None:
                yield media_url

    def _build_filename(self, index: int, media_url: str) -> str:
        filename = media_url.split("/")[-1].split("?", 1)[0]
        if not filename:
            filename = f"media-{index}"
        return f"{index:04d}-{filename}"

    def _is_image_url(self, media_url: str) -> bool:
        cleaned = media_url.split("?", 1)[0].split("#", 1)[0].lower()
        return cleaned.endswith(self.IMAGE_EXTENSIONS)

    def _is_video_url(self, media_url: str) -> bool:
        cleaned = media_url.split("?", 1)[0].split("#", 1)[0].lower()
        return cleaned.endswith(self.VIDEO_EXTENSIONS)

    def _build_hashtags_from_name(self, profile_name: str) -> str:
        normalized_parts = [
            part.strip().replace(" ", "").replace(".", "_").replace("-", "_")
            for part in profile_name.replace(",", "/").split("/")
            if part.strip()
        ]
        if not normalized_parts:
            return "#coomer"
        return " ".join(f"#{part}" for part in normalized_parts)


__all__ = ["CoomerParser", "CoomerUserRef"]
