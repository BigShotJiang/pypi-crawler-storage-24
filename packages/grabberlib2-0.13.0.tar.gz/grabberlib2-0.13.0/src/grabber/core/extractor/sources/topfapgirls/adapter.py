from typing import Any

from .parser import get_sources_for_topfapgirls


class TopfapgirlsAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_topfapgirls(**kwargs)


__all__ = ["TopfapgirlsAdapter"]
