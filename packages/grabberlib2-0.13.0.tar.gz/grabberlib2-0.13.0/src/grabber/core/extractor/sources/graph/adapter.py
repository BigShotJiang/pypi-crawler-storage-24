from typing import Any

from .parser import get_for_telegraph


class GraphAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_for_telegraph(**kwargs)


__all__ = ["GraphAdapter"]
