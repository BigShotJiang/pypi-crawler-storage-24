from typing import Any

from .parser import get_sources_for_everia


class EveriaAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_everia(**kwargs)


__all__ = ["EveriaAdapter"]
