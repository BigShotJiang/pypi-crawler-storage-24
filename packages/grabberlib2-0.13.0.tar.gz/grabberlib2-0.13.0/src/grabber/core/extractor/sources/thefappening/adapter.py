from typing import Any

from .parser import get_sources_for_fappening


class ThefappeningAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_fappening(**kwargs)


__all__ = ["ThefappeningAdapter"]
