from typing import Any

from .parser import get_sources_for_fapodrop


class FapodropAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_fapodrop(**kwargs)


__all__ = ["FapodropAdapter"]
