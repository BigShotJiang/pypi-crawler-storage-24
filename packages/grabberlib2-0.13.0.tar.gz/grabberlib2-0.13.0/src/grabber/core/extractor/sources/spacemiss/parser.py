import pathlib
from typing import Any

from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_pages_from_pagination(url: str, headers: dict[str, Any] | None = None) -> list[str]:
    pagination_pages_query = "div.page-nav.td-pb-padding-side a.page"
    posts_query = (
        "div.td_block_inner.tdb-block-inner.td-fix-index div.td-module-meta-info > h3.entry-title.td-module-title > a"
    )
    all_posts = set()
    soup = await get_soup(url, headers=headers)

    pages = {a.attrs["href"] for a in soup.select(pagination_pages_query)}
    pages.add(url)

    for page in pages:
        soup = await get_soup(page, headers=headers)
        all_posts.update({a.attrs["href"] for a in soup.select(posts_query)})

    return list(all_posts)


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-spacemiss.com"
    return title_tag.get_text(strip=True).split("-")[0].strip().rstrip()


async def get_sources_for_spacemiss(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    is_tag: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        is_tag=is_tag,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
        tag_source_fetcher=get_pages_from_pagination,
    )
