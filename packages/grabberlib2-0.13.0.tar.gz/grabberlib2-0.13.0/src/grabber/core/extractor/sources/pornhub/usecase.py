from __future__ import annotations

import logging
import pathlib

from boltons.setutils import IndexedSet
from telegraph import Telegraph
from tqdm import tqdm

from grabber.core.extractor.infrastructure.checkpoints import MediaCheckpointService, build_checkpoint_service
from grabber.core.extractor.infrastructure.publishing import send_link_message_to_channel, send_local_video_to_channel
from grabber.core.extractor.usecases import SourceRunRequest, SourceUseCase
from grabber.core.settings import PORNHUB_COOKIES_FILE_PATH

from .adapter import PornhubAdapter
from .parser import PornhubParser

logger = logging.getLogger(__name__)


class PornhubUseCase(SourceUseCase):
    def __init__(
        self,
        adapter: PornhubAdapter | None = None,
        parser: PornhubParser | None = None,
        checkpoint_service: MediaCheckpointService | None = None,
    ) -> None:
        self.adapter = adapter or PornhubAdapter()
        self.parser = parser or PornhubParser()
        self.checkpoint_service = checkpoint_service or build_checkpoint_service()

    async def run(self, request: SourceRunRequest) -> None:
        channel = request.channel.strip()
        if not channel:
            raise RuntimeError("Pornhub source requires a target channel. Use --channel or bot channel selection.")

        cookies_file_path = (
            pathlib.Path(PORNHUB_COOKIES_FILE_PATH.strip()) if PORNHUB_COOKIES_FILE_PATH.strip() else None
        )
        if cookies_file_path is None:
            raise RuntimeError("PORNHUB_COOKIES_FILE_PATH is required for Pornhub source")
        if not cookies_file_path.exists() or not cookies_file_path.is_file():
            raise RuntimeError(f"PORNHUB_COOKIES_FILE_PATH does not exist or is not a file: {cookies_file_path}")

        progress = tqdm(request.sources, total=len(request.sources), desc="Processing Pornhub URLs...")
        for source_url in progress:
            try:
                normalized_url = self.parser.normalize_video_url(source_url)
                viewkey = self.parser.extract_viewkey(normalized_url)
            except Exception as exc:
                logger.warning("Invalid Pornhub URL skipped source=%s err=%s", source_url, exc)
                continue

            checkpoint_seed = IndexedSet([(self.parser.build_filename_prefix(viewkey), normalized_url)])
            decision = self.checkpoint_service.filter_media(
                source_url=normalized_url,
                ordered_unique_img_urls=IndexedSet(),
                ordered_unique_video_urls=checkpoint_seed,
            )
            if decision.new_videos is None or not decision.new_videos:
                logger.info("Checkpoint skipped already-seen Pornhub URL source=%s", normalized_url)
                continue

            try:
                resolved = await self.adapter.resolve_video(
                    source_url=normalized_url,
                    cookies_file_path=cookies_file_path,
                    filename_prefix=self.parser.build_filename_prefix(viewkey),
                    viewkey=viewkey,
                )
            except Exception as exc:
                logger.warning("Failed to resolve Pornhub URL source=%s err=%s", normalized_url, exc)
                continue

            caption = self.parser.build_caption(
                title=resolved.video_page_title,
                uploader=resolved.uploader,
                viewkey=resolved.viewkey,
            )
            sent_successfully = False
            try:
                if resolved.temp_file_path is not None:
                    sent_successfully = await send_local_video_to_channel(
                        channel=channel,
                        page_title=caption,
                        source_url=normalized_url,
                        local_file_path=resolved.temp_file_path,
                        video_filename=resolved.temp_file_path.name,
                        tqdm_iterable=progress,
                    )
                if not sent_successfully and resolved.should_fallback_to_link and resolved.direct_url:
                    sent_successfully = await send_link_message_to_channel(
                        channel=channel,
                        page_title=caption,
                        video_url=resolved.direct_url,
                        size_bytes=resolved.estimated_size_bytes,
                    )
            finally:
                if resolved.temp_file_path is not None:
                    try:
                        resolved.temp_file_path.unlink(missing_ok=True)
                        resolved.temp_file_path.parent.rmdir()
                    except Exception:
                        logger.debug("Could not cleanup temporary Pornhub file path=%s", resolved.temp_file_path)

            if sent_successfully:
                self.checkpoint_service.commit_media(
                    source_url=normalized_url,
                    media_records=checkpoint_seed,
                )


async def get_sources_for_pornhub(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs: object,
) -> None:
    usecase = PornhubUseCase()
    await usecase.run(
        SourceRunRequest(
            sources=sources,
            entity=entity,
            telegraph_client=telegraph_client,
            final_dest=final_dest,
            save_to_telegraph=bool(save_to_telegraph),
            is_tag=bool(kwargs.get("is_tag", False)),
            limit=kwargs.get("limit"),  # type: ignore[arg-type]
            is_video_enabled=bool(kwargs.get("is_video_enabled", False)),
            channel=str(kwargs.get("channel", "")),
            max_pages=int(kwargs.get("max_pages", 50)),
            checkpoint_hint=kwargs.get("checkpoint_hint"),  # type: ignore[arg-type]
        )
    )


__all__ = ["PornhubUseCase", "get_sources_for_pornhub"]
