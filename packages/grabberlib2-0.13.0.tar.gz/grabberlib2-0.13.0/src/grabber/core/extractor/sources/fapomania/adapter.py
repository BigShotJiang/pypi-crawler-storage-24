import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from url_parser import get_base_url, parse_url


class FapomaniaAdapter:
    async def get_all_images_tags(
        self,
        url: str,
        query: str,
        headers: dict[str, str],
    ) -> IndexedSet:
        images_tags = IndexedSet()
        base_url = get_base_url(url)
        soup = BeautifulSoup(httpx.get(url, headers=headers).content, features="lxml")
        tags = soup.select(query)
        if not tags:
            return IndexedSet()

        first_tag = tags[0]
        image_src = first_tag.attrs["src"]
        parsed_image_src = parse_url(image_src)
        image_filename = parsed_image_src["file"]
        last_image_counter_str = image_filename.split("/")[-1].split("_")[1]
        model_name = image_filename.split("/")[-1].split("_")[0]
        image_counter = int(last_image_counter_str)
        image_base_url = "{base_url}{url_dir}{image_filename}"

        for image_counter in range(1, image_counter + 1):
            image_prefix = f"{image_counter}".zfill(4)
            img_filename = f"{model_name}_{image_prefix}.jpg"
            image_url = image_base_url.format(
                base_url=base_url,
                url_dir=parsed_image_src["dir"],
                image_filename=img_filename,
            )
            images_tags.add((image_prefix, f"{image_prefix}-{img_filename}", f"{img_filename}", image_url))

        ordered_unique_img_urls = IndexedSet(sorted(images_tags, key=lambda x: list(x).pop(0)))
        return IndexedSet([item[1:] for item in ordered_unique_img_urls])
