import pathlib

from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_tags
from grabber.core.extractor.infrastructure.parsing.title import get_page_title
from grabber.core.extractor.usecases import run_default_source


async def get_images_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    page_nav_query = "div.page-link-box li a.page-numbers"
    tags, _ = await get_tags(url, headers=headers, query=page_nav_query)
    source_urls = [url]
    source_urls.extend([a.attrs["href"] for a in tags if tags])
    return list(dict.fromkeys(source_urls))


def get_post_title(soup: BeautifulSoup) -> str:
    return get_page_title(soup=soup, strings_to_remove=["- 4KHD", "- Page"])


async def get_sources_for_4khd(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_images_from_pagination,
        title_factory=get_post_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
