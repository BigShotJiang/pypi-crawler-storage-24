from __future__ import annotations

import json
from typing import Any

import httpx

from grabber.core.extractor import ExtractorResult
from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint

from .parser import CoomerParser


class CoomerAdapter:
    def __init__(self, max_pages: int = 50) -> None:
        self.max_pages = max_pages

    def configure_max_pages(self, max_pages: int) -> None:
        self.max_pages = max(1, max_pages)

    def fetch_posts_page(self, endpoint: str, headers: dict[str, str] | None = None) -> list[dict[str, Any]]:
        request_headers = dict(headers or {})
        request_headers["Accept"] = "text/css"
        response = httpx.get(url=endpoint, headers=request_headers, follow_redirects=True)
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                return []
            raise
        payload = response.json()
        return payload if isinstance(payload, list) else []

    def fetch_profile(self, endpoint: str, headers: dict[str, str] | None = None) -> dict[str, Any] | None:
        request_headers = dict(headers or {})
        request_headers["Accept"] = "text/css"
        response = httpx.get(url=endpoint, headers=request_headers, follow_redirects=True)
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                return None
            raise
        payload = response.json()
        return payload if isinstance(payload, dict) else None

    async def collect_result(
        self,
        source_url: str,
        headers: dict[str, str] | None,
        parser: CoomerParser,
        checkpoint_hint: SourceCheckpointHint | None = None,
    ) -> ExtractorResult | None:
        _ = checkpoint_hint
        user_ref = parser.parse_user_reference(source_url)
        profile = None
        try:
            profile = self.fetch_profile(endpoint=parser.build_profile_endpoint(user_ref), headers=headers)
        except httpx.HTTPError:
            profile = None

        collected_posts: list[dict[str, Any]] = []
        seen_post_ids: set[str] = set()
        seen_page_fingerprints: set[str] = set()
        seen_media_urls: set[str] = set()

        for page_index in range(self.max_pages):
            endpoint = parser.build_posts_endpoint(user_ref, offset=page_index * parser.PAGE_SIZE)
            posts = self.fetch_posts_page(endpoint=endpoint, headers=headers)
            if not posts:
                break

            page_fingerprint = json.dumps(posts, sort_keys=True, default=str)
            if page_fingerprint in seen_page_fingerprints:
                break
            seen_page_fingerprints.add(page_fingerprint)

            page_posts: list[dict[str, Any]] = []
            for post in posts:
                if not isinstance(post, dict):
                    continue
                post_id = str(post.get("id", ""))
                if post_id and post_id in seen_post_ids:
                    continue
                if post_id:
                    seen_post_ids.add(post_id)
                page_posts.append(post)

            if not page_posts:
                break

            page_image_urls, page_video_urls = parser.extract_media_urls(page_posts)
            if not page_image_urls and not page_video_urls:
                break

            page_media_urls = [*page_image_urls, *page_video_urls]
            new_media_urls = [media_url for media_url in page_media_urls if media_url not in seen_media_urls]
            if not new_media_urls:
                break

            seen_media_urls.update(new_media_urls)
            collected_posts.extend(page_posts)

        return parser.build_extractor_result(source_url=source_url, posts=collected_posts, profile=profile)


__all__ = ["CoomerAdapter"]
