import pathlib

from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import QUERY_MAPPING
from grabber.core.extractor.usecases import (
    DefaultSourceRunner,
    DefaultSourceRunRequest,
    SourceRunRequest,
    SourceUseCase,
)

from .adapter import FapezaAdapter
from .parser import FapezaParser


class FapezaUseCase(SourceUseCase):
    def __init__(
        self,
        adapter: FapezaAdapter | None = None,
        parser: FapezaParser | None = None,
        runner: DefaultSourceRunner | None = None,
    ) -> None:
        self.adapter = adapter or FapezaAdapter()
        self.parser = parser or FapezaParser()
        self.runner = runner or DefaultSourceRunner()

    async def run(self, request: SourceRunRequest) -> None:
        query, src_attr = QUERY_MAPPING[request.entity]
        self.adapter.configure_max_pages(request.max_pages)
        config = ExtractorConfig(
            query=query,
            src_attr=src_attr,
            pagination_fetcher=self.adapter.get_pages_from_pagination,
            title_factory=self.parser.get_page_title,
        )
        await self.runner.run(
            DefaultSourceRunRequest(
                sources=request.sources,
                entity=request.entity,
                telegraph_client=request.telegraph_client,
                config=config,
                final_dest=request.final_dest,
                save_to_telegraph=request.save_to_telegraph,
                is_tag=request.is_tag,
                limit=request.limit,
                channel=request.channel,
                max_pages=request.max_pages,
                checkpoint_hint=request.checkpoint_hint,
            )
        )


async def get_sources_for_fapeza(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    is_tag: bool | None = False,
    limit: int | None = None,
    **kwargs: object,
) -> None:
    usecase = FapezaUseCase()
    await usecase.run(
        SourceRunRequest(
            sources=sources,
            entity=entity,
            telegraph_client=telegraph_client,
            final_dest=final_dest,
            save_to_telegraph=bool(save_to_telegraph),
            is_tag=bool(is_tag),
            limit=limit,
            is_video_enabled=bool(kwargs.get("is_video_enabled", False)),
            channel=str(kwargs.get("channel", "")),
            max_pages=int(kwargs.get("max_pages", 50)),
            checkpoint_hint=kwargs.get("checkpoint_hint"),  # type: ignore[arg-type]
        )
    )


__all__ = ["FapezaAdapter", "FapezaParser", "FapezaUseCase", "get_sources_for_fapeza"]
