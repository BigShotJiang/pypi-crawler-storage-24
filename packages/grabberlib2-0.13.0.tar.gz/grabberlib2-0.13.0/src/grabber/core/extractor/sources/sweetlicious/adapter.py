from typing import Any

from .parser import get_sources_for_sweetlicious


class SweetliciousAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_sweetlicious(**kwargs)


__all__ = ["SweetliciousAdapter"]
