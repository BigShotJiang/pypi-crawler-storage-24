from typing import Any

from .parser import get_sources_for_pixibb


class PixibbAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_pixibb(**kwargs)


__all__ = ["PixibbAdapter"]
