import asyncio
import pathlib
from typing import cast

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph

from grabber.core.extractor import DefaultExtractor, ExtractorConfig, ExtractorResult
from grabber.core.extractor.constants import headers_mapping, query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_tags
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls

SPLIT_WORDS = [
    "- Bikini Girls",
    "- BestGirlSexy",
    "- CG Cosplay",
    "- Bikini Girl",
    "– Cup2D",
    "- Photo Album",
    "– Jrants Fotos",
    "– Big Boobs Japan",
    "– Big Boobs Asia",
    "- NudeCosplayGirls.com",
    "- Cosplay",
    "- Xiunice.com",
]


def get_common_page_title(soup: BeautifulSoup) -> str:
    page_title = cast(Tag, soup.find("title")).get_text(strip=True).rstrip()
    for split_word in SPLIT_WORDS:
        page_title = page_title.split(split_word)[0]
    if "Free Download" in page_title:
        page_title = page_title.split("- Free Download")[0].split("-")[0]
    return page_title


class CommonExtractor(DefaultExtractor):
    async def extract_source(self, source_url: str) -> ExtractorResult | None:
        src_attr = self.config.src_attr
        image_tags, soup = await get_tags(
            source_url,
            headers=self.headers,
            query=self.config.query,
        )

        if not image_tags and self.entity == "asigirl.com":
            queries_and_attrs = [
                ("a.gallery-item", "data-src"),
                ("a.swipebox", "href"),
                ("div.gallery-group a", "href"),
                ("div.gallery-container.justified-gallery a", "href"),
            ]
            for fallback_query, fallback_attr in queries_and_attrs:
                tags, soup = await get_tags(
                    source_url,
                    headers=self.headers,
                    query=fallback_query,
                )
                if tags:
                    image_tags = tags
                    src_attr = fallback_attr
                    break

        if self.entity in {"nudecosplaygirls.com", "vazounudes.com"}:
            image_tags = [
                tag
                for tag in image_tags
                if "emoji" not in tag.attrs.get("src", "") and "emoji" not in tag.attrs.get("data-lazy-src", "")
            ]

        if self.entity == "imgcup.com" and not image_tags:
            src_attr = "data-src"
            image_tags = soup.select(
                "div.penci-post-gallery-container div.inner-gallery-masonry-container div a div img"
            )

        if not image_tags:
            return None

        ordered_unique_video_urls = None
        if self.entity == "vazounudes.com":
            iframe_element = soup.find("iframe")
            if iframe_element:
                iframe_link = iframe_element.attrs["data-lazy-src"]
                video_tags, _ = await get_tags(
                    iframe_link,
                    headers=self.headers,
                    query="source",
                )
                unique_video_urls = IndexedSet()
                for video_tag in video_tags:
                    video_src = video_tag.attrs["src"]
                    video_name = video_src.split(".mp4")[0].strip().rstrip()
                    unique_video_urls.add((video_name, video_src))
                ordered_unique_video_urls = IndexedSet([a[1:] for a in sorted(unique_video_urls, key=lambda x: x[0])])

        if self.entity == "telegra.ph":
            video_query = "div.ql-editor figure div.figure_wrapper video"
            video_tags, _ = await get_tags(
                source_url,
                headers=self.headers,
                query=video_query,
            )
            unique_video_urls = IndexedSet()
            for idx, video_tag in enumerate(video_tags):
                video_src = video_tag.attrs["src"]
                video_prefix = f"{idx + 1}".zfill(4)
                video_filename = video_src.split(".mp4")[0].strip().rstrip()
                unique_video_urls.add((video_prefix, f"{video_prefix}-{video_filename}", video_src))
            ordered_unique_video_urls = IndexedSet([a[1:] for a in sorted(unique_video_urls, key=lambda x: x[0])])

        page_title = get_common_page_title(soup)
        ordered_unique_img_urls = await build_unique_img_urls(image_tags, src_attr)
        if not ordered_unique_img_urls:
            return None

        if self.save_to_telegraph:
            await asyncio.sleep(3)

        return ExtractorResult(
            page_title=page_title,
            ordered_unique_img_urls=ordered_unique_img_urls,
            ordered_unique_video_urls=ordered_unique_video_urls,
        )


async def get_sources_for_common(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph,
    final_dest: pathlib.Path | None = None,
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        title_factory=get_common_page_title,
    )

    extractor = CommonExtractor(
        sources=sources,
        entity=entity,
        config=config,
        final_dest=final_dest if final_dest else "",
        save_to_telegraph=bool(save_to_telegraph),
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
        telegraph_client=telegraph_client,
    )

    if entity not in headers_mapping:
        extractor.headers = headers_mapping["common"]

    await extractor.run()
