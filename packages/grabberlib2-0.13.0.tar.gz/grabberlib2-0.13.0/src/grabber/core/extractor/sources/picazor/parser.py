from __future__ import annotations

import json
import re
from dataclasses import dataclass
from html import unescape
from typing import Any
from urllib.parse import urlparse

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from unidecode import unidecode

from grabber.core.extractor import ExtractorResult


class PicazorAlbumParseError(RuntimeError):
    pass


@dataclass(slots=True)
class PicazorSourceRef:
    locale: str
    slug: str
    album_order: str | None
    is_album: bool


@dataclass(slots=True)
class PicazorMediaItem:
    id: str
    order: int | None
    path: str
    mime: str
    visible: bool


class PicazorParser:
    BASE_URL = "https://picazor.com"

    def parse_source_ref(self, source_url: str) -> PicazorSourceRef:
        parsed = urlparse(source_url)
        parts = [part for part in parsed.path.split("/") if part]
        if not parts:
            raise ValueError(f"Could not parse source path from URL: {source_url}")

        if len(parts) == 1:
            locale = "en"
            slug = parts[0]
            return PicazorSourceRef(locale=locale, slug=slug, album_order=None, is_album=False)

        locale = parts[0]
        slug = parts[1]
        is_album = len(parts) >= 4 and parts[2] == "albums"
        album_order = parts[3] if is_album else None

        return PicazorSourceRef(
            locale=locale,
            slug=slug,
            album_order=album_order,
            is_album=is_album,
        )

    def extract_album_media_from_payload(self, payload: str) -> tuple[list[PicazorMediaItem], str | None]:
        files_array_json = self._extract_json_array_by_markers(
            payload,
            markers=[
                '"files":[',
                '"files": [',
                '\\"files\\":[',
                '\\"files\\": [',
            ],
        )
        if files_array_json is None:
            raise PicazorAlbumParseError("Album payload is missing files array")

        files = self._decode_album_files_array(files_array_json)
        if files is None:
            raise PicazorAlbumParseError("Unable to decode album files payload")

        media_items: list[PicazorMediaItem] = []
        for item in files:
            if not isinstance(item, dict):
                continue

            path = item.get("path")
            if not isinstance(path, str) or not path:
                continue

            mime = item.get("mime")
            if not isinstance(mime, str) or not mime:
                mime = "video" if path.endswith(".mp4") else "photo"

            media_items.append(
                PicazorMediaItem(
                    id=str(item.get("id", "")),
                    order=self._safe_int(item.get("order")),
                    path=path,
                    mime=mime.lower(),
                    visible=bool(item.get("visible", True)),
                )
            )

        payload_description = self._search_first_group(
            payload,
            patterns=[
                r'"name":"description","content":"([^"]+)"',
                r'"property":"og:description","content":"([^"]+)"',
                r'"children":"([^"]+?)\s*-\s*Picazor[^\"]*"',
            ],
        )
        return media_items, payload_description

    def extract_title(self, html_or_payload: str, fallback_slug: str) -> str:
        source_text = html_or_payload.strip()

        if source_text and "<" in source_text and ">" in source_text:
            soup = BeautifulSoup(source_text, features="lxml")

            profile_title_node = soup.select_one("div.flex-1 p.text-sm")
            if profile_title_node and profile_title_node.get_text(strip=True):
                return self._normalize_title(profile_title_node.get_text(strip=True), fallback_slug=fallback_slug)

            description_tag = soup.select_one("meta[name='description']")
            if description_tag:
                description_value = description_tag.attrs.get("content")
                if isinstance(description_value, str) and description_value:
                    return self._normalize_title(description_value, fallback_slug=fallback_slug)

            title_tag = soup.select_one("title")
            if title_tag and title_tag.get_text(strip=True):
                return self._normalize_title(title_tag.get_text(strip=True), fallback_slug=fallback_slug)

        payload_title = self._search_first_group(
            source_text,
            patterns=[
                r'"name":"description","content":"([^"]+)"',
                r'"property":"og:description","content":"([^"]+)"',
                r'"children":"([^"]+?)\s*-\s*Picazor[^\"]*"',
            ],
        )
        if payload_title:
            return self._normalize_title(payload_title, fallback_slug=fallback_slug)

        return self._normalize_title(fallback_slug, fallback_slug=fallback_slug)

    def build_album_title(
        self,
        album_page_html: str,
        hinted_title: str | None,
        source_ref: PicazorSourceRef,
        items: list[PicazorMediaItem],
    ) -> str:
        album_header = self._extract_album_header(album_page_html)
        metadata_source = hinted_title or album_header or source_ref.slug

        model_name = self._extract_album_model_name(album_header or metadata_source, source_ref.slug)
        album_number = self._extract_album_number(album_header or metadata_source) or source_ref.album_order or "?"
        photos_count = self._extract_album_photo_count(album_header or metadata_source)
        if photos_count is None:
            photos_count = len([item for item in items if item.visible and not self._is_video(item)])

        hashtags = self._normalize_title(metadata_source, fallback_slug=source_ref.slug)
        return f"{model_name} album #{album_number} - {photos_count} Photos - {hashtags}"

    def build_media_items_from_profile_rows(self, rows: list[dict[str, Any]]) -> list[PicazorMediaItem]:
        media_items: list[PicazorMediaItem] = []

        for row in rows:
            path = row.get("path")
            if not isinstance(path, str) or not path:
                continue

            mime = row.get("mime")
            if not isinstance(mime, str) or not mime:
                mime = "video" if path.endswith(".mp4") else "photo"

            media_items.append(
                PicazorMediaItem(
                    id=str(row.get("id", "")),
                    order=self._safe_int(row.get("order")),
                    path=path,
                    mime=mime.lower(),
                    visible=bool(row.get("visible", True)),
                )
            )

        return media_items

    def build_extractor_result(self, title: str, items: list[PicazorMediaItem]) -> ExtractorResult | None:
        visible_items = [item for item in items if item.visible]
        if not visible_items:
            return None

        sortable: list[tuple[tuple[int, int], int, PicazorMediaItem]] = []
        for idx, item in enumerate(visible_items):
            if item.order is not None:
                sort_key = (0, -item.order)
            else:
                sort_key = (1, idx)
            sortable.append((sort_key, idx, item))

        sorted_items = [item for _, _, item in sorted(sortable, key=lambda entry: (entry[0], entry[1]))]

        seen_image_keys: set[tuple[str, str]] = set()
        seen_video_keys: set[tuple[str, str]] = set()
        image_records: IndexedSet = IndexedSet()
        video_records: IndexedSet = IndexedSet()

        for item in sorted_items:
            absolute_url = self._to_absolute_url(item.path)
            filename = self._build_filename(item.id, item.path)

            if self._is_video(item):
                dedupe_key = (item.id, absolute_url)
                if dedupe_key in seen_video_keys:
                    continue
                seen_video_keys.add(dedupe_key)
                video_records.add((filename, absolute_url))
                continue

            dedupe_key = (item.id, absolute_url)
            if dedupe_key in seen_image_keys:
                continue
            seen_image_keys.add(dedupe_key)
            image_records.add((filename, absolute_url))

        if not image_records and not video_records:
            return None

        ordered_unique_video_urls = video_records if video_records else None

        return ExtractorResult(
            page_title=title,
            ordered_unique_img_urls=image_records,
            ordered_unique_video_urls=ordered_unique_video_urls,
        )

    def _build_filename(self, item_id: str, path: str) -> str:
        filename = path.rsplit("/", 1)[-1]
        if not item_id:
            return filename
        return f"{item_id}-{filename}"

    def _to_absolute_url(self, path: str) -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        return f"{self.BASE_URL}{path}"

    def _is_video(self, item: PicazorMediaItem) -> bool:
        return "video" in item.mime or item.path.endswith(".mp4")

    def _normalize_title(self, raw_title: str, fallback_slug: str) -> str:
        decoded = unescape(raw_title).strip()
        normalized = decoded

        for marker in (" - Picazor", "| Picazor", " Nude", " Exclusive"):
            if marker in normalized:
                normalized = normalized.split(marker)[0]

        normalized = normalized.replace(",", "/")
        parts = [part.strip() for part in normalized.split("/") if part.strip()]

        hashtags = [f"#{part.replace(' ', '').replace('.', '_').replace('-', '_').replace('#', '')}" for part in parts]

        if not hashtags:
            hashtags = [f"#{fallback_slug.replace('-', '_')}"]

        return unidecode(" ".join(hashtags))

    def _search_first_group(self, source_text: str, patterns: list[str]) -> str | None:
        for pattern in patterns:
            match = re.search(pattern, source_text)
            if match:
                return match.group(1)
        return None

    def _extract_album_header(self, html_or_payload: str) -> str | None:
        source_text = html_or_payload.strip()
        if not source_text or "<" not in source_text or ">" not in source_text:
            return None

        soup = BeautifulSoup(source_text, features="lxml")
        header = soup.select_one("div.main-shell main div.mx-auto div > div h2")
        if header is None:
            return None

        text = header.get_text(strip=True)
        return text or None

    def _extract_album_model_name(self, source_text: str, fallback_slug: str) -> str:
        normalized_source = unescape(source_text).strip()
        model_name = normalized_source

        match = re.search(r"^(.*?)\s+Nude\s+Leaks?", normalized_source, flags=re.IGNORECASE)
        if match:
            model_name = match.group(1).strip()
        elif "|" in normalized_source:
            model_name = normalized_source.split("|", 1)[0].strip()
        elif "," in normalized_source:
            model_name = normalized_source.split(",", 1)[0].strip()

        if not model_name:
            model_name = fallback_slug.replace("-", " ").strip()

        model_name = model_name.split("|", 1)[0].split(",", 1)[0].strip()
        return unidecode(model_name)

    def _extract_album_number(self, source_text: str) -> str | None:
        match = re.search(r"#\s*(\d+)\b", source_text)
        if not match:
            return None
        return match.group(1)

    def _extract_album_photo_count(self, source_text: str) -> int | None:
        match = re.search(r"(\d+)\s+Photos?\b", source_text, flags=re.IGNORECASE)
        if not match:
            return None
        return self._safe_int(match.group(1))

    def _extract_json_array_by_marker(self, source_text: str, marker: str) -> str | None:
        marker_idx = source_text.find(marker)
        if marker_idx < 0:
            return None

        start_idx = marker_idx + len(marker) - 1
        depth = 0
        in_string = False
        escaped = False

        for idx in range(start_idx, len(source_text)):
            char = source_text[idx]

            if escaped:
                escaped = False
                continue

            if char == "\\":
                escaped = True
                continue

            if char == '"':
                in_string = not in_string
                continue

            if in_string:
                continue

            if char == "[":
                depth += 1
            elif char == "]":
                depth -= 1
                if depth == 0:
                    return source_text[start_idx : idx + 1]

        return None

    def _extract_json_array_by_markers(self, source_text: str, markers: list[str]) -> str | None:
        for marker in markers:
            extracted = self._extract_json_array_by_marker(source_text, marker)
            if extracted is not None:
                return extracted
        return None

    def _decode_album_files_array(self, files_array_json: str) -> list[dict[str, Any]] | None:
        candidates = [
            files_array_json,
            unescape(files_array_json),
            files_array_json.replace('\\"', '"').replace("\\/", "/"),
            unescape(files_array_json.replace('\\"', '"').replace("\\/", "/")),
        ]

        for candidate in candidates:
            decoded = self._try_decode_array(candidate)
            if decoded is not None:
                return decoded

        return None

    def _try_decode_array(self, candidate: str) -> list[dict[str, Any]] | None:
        if not candidate:
            return None

        for _ in range(2):
            try:
                decoded = json.loads(candidate)
            except json.JSONDecodeError:
                return None

            if isinstance(decoded, list):
                result: list[dict[str, Any]] = []
                for item in decoded:
                    if isinstance(item, dict):
                        result.append(item)
                return result

            if isinstance(decoded, str):
                candidate = decoded
                continue

            return None

        return None

    def _safe_int(self, value: object) -> int | None:
        if value is None:
            return None
        try:
            return int(str(value))
        except (TypeError, ValueError):
            return None


__all__ = [
    "PicazorAlbumParseError",
    "PicazorMediaItem",
    "PicazorParser",
    "PicazorSourceRef",
]
