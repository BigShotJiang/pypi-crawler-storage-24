"""Extractor source packages organized by usecase/adapter/parser layers."""
