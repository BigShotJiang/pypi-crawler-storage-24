import pathlib
from urllib.parse import urljoin

import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from telegraph import Telegraph
from url_parser import get_base_url, parse_url

from grabber.core.extractor import ExtractorConfig, ExtractorResult
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_pages_from_gallery(
    gallery_url: str,
    headers: dict[str, str] | None = None,
    query: str = "div.grid-view figure.gallery-item a img.gallery-img",
) -> IndexedSet:
    first_page_response = httpx.get(url=gallery_url, headers=headers)
    page_content = first_page_response.content.decode("utf-8")
    soup = BeautifulSoup(page_content, features="html.parser")
    raw_images = IndexedSet()
    image_links = IndexedSet()
    parsed_url = parse_url(gallery_url)
    model_id = parsed_url["file"]
    pagination_tags = soup.select("a[aria-label^='Go to page']")
    pagination_base_url = "https://fapello.ru/galleries/{model_id}?page={page_number}"

    if pagination_tags:
        first_page_number = int(pagination_tags[0].text.strip())
        last_page_number = int(pagination_tags[-1].text.strip())
    else:
        first_page_number = 1
        last_page_number = 1

    for page_number in range(first_page_number, last_page_number + 1):
        image_tags = soup.select(query)
        raw_images.update(*[tag for tag in image_tags if ".svg" not in tag.attrs.get("src", "")])

        if page_number < last_page_number:
            target_url = pagination_base_url.format(model_id=model_id, page_number=page_number + 1)
            page_response = httpx.get(url=target_url, headers=headers)
            page_content = page_response.content.decode("utf-8")
            soup = BeautifulSoup(page_content, features="html.parser")

    for idx, image_tag in enumerate(raw_images):
        if not hasattr(image_tag, "attrs") or len(image_tag.attrs.keys()) == 1:
            continue

        src_attr = "src" if "src" in image_tag.attrs else "data-src"
        image_src = image_tag.attrs[src_attr]
        parsed_image_url = parse_url(image_src)
        image_prefix = f"{idx + 1}".zfill(4)
        image_filename = parsed_image_url["file"]
        image_links.add((image_prefix, f"{image_prefix}-{image_filename}", f"{image_filename}", image_src))

    return IndexedSet([a[1:] for a in image_links])


async def collect_from_fapello_ru(
    source_url: str,
    headers: dict[str, str] | None = None,
) -> ExtractorResult | None:
    soup = await get_soup(target_url=source_url, headers=headers)
    base_url = get_base_url(source_url)
    gallery_link_tag = soup.select_one("a[href*='/galleries/']")
    if gallery_link_tag is None:
        return None

    gallery_url = urljoin(base_url, gallery_link_tag.attrs["href"])
    ordered_unique_img_urls = await get_pages_from_gallery(gallery_url=gallery_url, headers=headers)
    if not ordered_unique_img_urls:
        return None

    page_title = "".join(soup.select_one("div.flex-1.min-w-0 p").get_text(strip=True).split(","))
    page_title = " ".join(list({f"#{part.replace('.', '_').replace('-', '_')}" for part in page_title.split(" ")}))

    return ExtractorResult(
        page_title=page_title,
        ordered_unique_img_urls=ordered_unique_img_urls,
    )


async def get_sources_for_fapello_ru(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    config = ExtractorConfig(
        query="",
        src_attr="src",
        result_collector=collect_from_fapello_ru,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
