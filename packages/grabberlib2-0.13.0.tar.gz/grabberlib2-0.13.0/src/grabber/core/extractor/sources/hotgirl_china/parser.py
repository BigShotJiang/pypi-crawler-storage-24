import pathlib
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source


async def get_images_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    pagination_query = "nav.pagination.group div.wp-pagenavi a"
    first_page_query = "nav.pagination.group div.wp-pagenavi span.current"
    last_page_query = "nav.pagination.group div.wp-pagenavi a.last"

    soup = await get_soup(url, headers=headers)
    source_urls = [url]
    pagination_set = soup.select(pagination_query)

    if not pagination_set:
        return source_urls

    first_page_tag = soup.select_one(first_page_query)
    first_page_number = int(first_page_tag.get_text(strip=True)) if first_page_tag else 1

    last_page_tag = soup.select_one(last_page_query)
    if last_page_tag is not None:
        last_page_number = int(last_page_tag.attrs["href"].split("/", maxsplit=4)[-1].split("/")[0])
    else:
        page_numbers = [int(a.get_text(strip=True)) for a in pagination_set if a.get_text(strip=True).isdigit()]
        last_page_number = max(page_numbers) if page_numbers else first_page_number

    for index in range(first_page_number, last_page_number + 1):
        if index == 1:
            continue
        source_urls.append(urljoin(url, f"{index}/"))

    return list(dict.fromkeys(source_urls))


def get_page_title(soup: BeautifulSoup) -> str:
    title_tag = soup.select_one("title")
    if title_tag is None:
        return "post-hotgirlchina.com"
    return title_tag.get_text(strip=True).split("| Hot Girl China")[0].split("/mitaku.net/")[0].strip().rstrip()


async def get_sources_for_hotgirl_china(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_images_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
