import asyncio
import pathlib
from typing import Any, cast

import httpx
import requests
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph
from tenacity import retry, wait_chain, wait_fixed
from tqdm import tqdm
from unidecode import unidecode
from url_parser import get_url

from grabber.core.extractor.constants import headers_mapping
from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint, hash_media_url, normalize_media_url
from grabber.core.extractor.infrastructure.publishing.telegraph import send_post_to_telegram
from grabber.core.extractor.infrastructure.storage.downloader import run_downloader
from grabber.core.settings import CHECKPOINT_CONSECUTIVE_SEEN_STOP

NUMBERS_PATTERN = r"\d+(?:,\d+)*"


@retry(
    wait=wait_chain(
        *[wait_fixed(3) for _ in range(5)]
        + [wait_fixed(7) for _ in range(4)]
        + [wait_fixed(9) for _ in range(3)]
        + [wait_fixed(15)],
    ),
    reraise=True,
)
async def get_response(url: str, headers: dict[str, str]) -> dict[str, Any]:
    try:
        response = httpx.get(url=url, headers=headers)
        response.raise_for_status()
        response_data = response.json()
    except requests.exceptions.JSONDecodeError as exc:
        print(f"JSONDecodeError occurred for {url}: {exc}")
        raise
    except requests.HTTPError as exc:
        print(f"Request error occurred for {url}: {exc}")
        raise
    return cast(dict[str, Any], response_data)


async def get_pages_from_pagination(
    url: str,
    headers: dict[str, str],
    max_pages: int,
    checkpoint_hint: SourceCheckpointHint | None = None,
) -> tuple[IndexedSet, ...]:
    referer_header = {"Referer": url}
    headers.update(referer_header)
    parsed_url: dict[str, Any] = get_url(url)._asdict()
    url_file = parsed_url.get("file")

    if url_file is not None:
        model_name = url_file
    else:
        url_path = parsed_url["path"].replace("/", "")
        model_name = url_path

    first_video_endpoint_url = f"https://api.leakgallery.com/profile/{model_name}?type=Videos&sort=MostLiked"
    first_image_endpoint_url = f"https://api.leakgallery.com/profile/{model_name}?type=Photos&sort=MostRecent"
    base_media_url = "https://cdn.leakgallery.com/"
    video_endpoint_url = "https://api.leakgallery.com/profile/{model_name}/{page_number}?type=Videos&sort=MostLiked"
    image_endpoint_url = "https://api.leakgallery.com/profile/{model_name}/{page_number}?type=Photos&sort=MostRecent"
    page_number = 1
    video_response = httpx.get(first_video_endpoint_url, headers=headers)
    image_response = httpx.get(first_image_endpoint_url, headers=headers)
    video_response_data: dict[str, Any] = video_response.json()
    image_response_data: dict[str, Any] = image_response.json()
    media_data: list[dict[str, Any]] = [*video_response_data.get("medias", []), *image_response_data.get("medias", [])]
    images_tags = IndexedSet()
    videos_tags = IndexedSet()
    video_ids = IndexedSet()
    image_ids = IndexedSet()
    seen_hashes = checkpoint_hint.seen_hashes if checkpoint_hint is not None else set()
    consecutive_seen = 0

    while page_number <= max_pages and media_data:
        if seen_hashes:
            candidate_media_urls = [
                f"{base_media_url}{item.get('file_path', '')!s}" for item in media_data if item.get("file_path")
            ]
            if candidate_media_urls and all(
                hash_media_url(normalize_media_url(candidate_url)) in seen_hashes
                for candidate_url in candidate_media_urls
            ):
                consecutive_seen += len(candidate_media_urls)
                if consecutive_seen >= CHECKPOINT_CONSECUTIVE_SEEN_STOP:
                    break
                page_number += 1
                next_video_page_url = video_endpoint_url.format(model_name=model_name, page_number=page_number)
                next_image_page_url = image_endpoint_url.format(model_name=model_name, page_number=page_number)
                await asyncio.sleep(0.5)
                try:
                    video_response_data = await get_response(url=next_video_page_url, headers=headers)
                    image_response_data = await get_response(url=next_image_page_url, headers=headers)
                    media_data = [*video_response_data.get("medias", []), *image_response_data.get("medias", [])]
                except (Exception, httpx.HTTPStatusError, httpx.RequestError):
                    continue
                continue
            consecutive_seen = 0

        for idx, data in enumerate(media_data):
            media_url = data["file_path"]
            if ".mp4" in media_url:
                video_url = f"{base_media_url}{media_url}"
                video_id = data["id"]
                if video_id not in video_ids:
                    video_ids.add(video_id)
                    parsed_video_url = get_url(video_url)._asdict()
                    video_prefix = f"{idx + 1}".zfill(4)
                    video_filename = parsed_video_url["file"]
                    filename = f"{video_id}-{video_filename}"
                    videos_tags.add((video_prefix, f"{video_prefix}-{filename}", f"{filename}", video_url))
            else:
                image_url = f"{base_media_url}{media_url}"
                image_id = data["id"]
                if image_id not in image_ids:
                    image_ids.add(image_id)
                    parsed_image_url = get_url(image_url)._asdict()
                    image_prefix = f"{idx + 1}".zfill(4)
                    image_filename = parsed_image_url["file"]
                    filename = f"{image_id}-{image_filename}"

                    images_tags.add((image_prefix, f"{image_prefix}-{filename}", f"{filename}", image_url))

        page_number += 1
        next_video_page_url = video_endpoint_url.format(model_name=model_name, page_number=page_number)
        next_image_page_url = image_endpoint_url.format(model_name=model_name, page_number=page_number)

        await asyncio.sleep(0.5)  # To avoid hitting the server too hard
        try:
            video_response_data = await get_response(url=next_video_page_url, headers=headers)
            image_response_data = await get_response(url=next_image_page_url, headers=headers)
            media_data = [*video_response_data.get("medias", []), *image_response_data.get("medias", [])]
            print(f"Fetched page {page_number} for {model_name}, found {len(media_data)} items.")
        except (Exception, httpx.HTTPStatusError, httpx.RequestError) as exc:
            print(f"Error when requesting {next_video_page_url} or {next_image_page_url}: {exc}")
            continue

    ordered_unique_img_urls = IndexedSet([a[1:] for a in images_tags])
    ordered_unique_video_urls = IndexedSet([a[1:] for a in videos_tags])

    return ordered_unique_img_urls, ordered_unique_video_urls


async def get_sources_for_leakgallery(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs: Any,
) -> None:
    tqdm_sources_iterable = tqdm(
        sources,
        total=len(sources),
        desc="Retrieving URLs...",
    )
    headers = headers_mapping[entity] if entity in headers_mapping else headers_mapping["common"]
    page_title = ""
    title_folder_mapping = {}
    posts_sent_counter = 0
    titles = IndexedSet()
    ordered_unique_img_urls = None
    ordered_unique_video_urls = None
    all_sources: list[str] = []
    original_folder_path = final_dest
    channel = kwargs.get("channel", "")
    max_pages: int = kwargs.get("max_pages", 50)
    checkpoint_hint: SourceCheckpointHint | None = kwargs.get("checkpoint_hint")

    for source_url in tqdm_sources_iterable:
        final_dest = pathlib.Path(str(original_folder_path)) if final_dest else ""
        all_sources.append(source_url)

        ordered_unique_img_urls, ordered_unique_video_urls = await get_pages_from_pagination(
            url=source_url,
            headers=headers,
            max_pages=max_pages,
            checkpoint_hint=checkpoint_hint,
        )

        soup = BeautifulSoup(httpx.get(source_url, headers=headers).content, features="lxml")
        page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
        page_title = page_title.split("Exclusive")[0].replace("https:", "")
        page_title = " ".join(
            list(
                {
                    f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}"
                    for part in page_title.split("/")
                }
            )
        )
        titles.add(page_title)

        if final_dest:
            final_dest = pathlib.Path(final_dest) / unidecode(f"{page_title} - {entity}")
            if not final_dest.exists():
                final_dest.mkdir(parents=True, exist_ok=True)

            title_folder_mapping[page_title] = (ordered_unique_img_urls, final_dest)

        if save_to_telegraph:
            _ = await send_post_to_telegram(
                ordered_unique_img_urls=ordered_unique_img_urls,
                ordered_unique_video_urls=ordered_unique_video_urls,
                page_title=page_title,
                telegraph_client=telegraph_client,
                posts_sent_counter=posts_sent_counter,
                tqdm_sources_iterable=tqdm_sources_iterable,
                all_sources=all_sources,
                source_url=source_url,
                entity=entity,
                channel=channel,
            )
            page_title = ""

    if final_dest and ordered_unique_img_urls:
        await run_downloader(
            final_dest=final_dest,
            page_title=page_title,
            unique_img_urls=ordered_unique_img_urls,
            titles=titles,
            title_folder_mapping=title_folder_mapping,
            headers=headers,
        )


"""
scraper = cloudscraper.create_scraper(interpreter='nodejs')

base_url = "httpx://picazor.com"
url_page_1 = "https://picazor.com/api/files/teemori/sfiles?page=1"
page1 = scraper.get(url_page_1)
[d["path"] for d in page1.json()]

['/uploads/may25/sa3/teemori/fansly/bhqpk/teemori-fansly-6h0ds-9.jpg',
 '/uploads/may25/sa3/teemori/fansly/bhqpk/teemori-fansly-enl0f-8.jpg',
 '/uploads/may25/sa3/teemori/fansly/bhqpk/teemori-fansly-29ysw-7.jpg',
 '/uploads/may25/sa3/teemori/fansly/bhqpk/teemori-fansly-sytkf-6.jpg',
 '/uploads/may25/sa3/teemori/fansly/bhqpk/teemori-fansly-zcrer-5.jpg',
 '/uploads/may25/sa3/teemori/fansly/bhqpk/teemori-fansly-bsk8b-4.jpg',
 '/uploads/may25/sa3/teemori/fansly/bhqpk/teemori-fansly-7bbyk-3.jpg',
 '/uploads/may25/sa3/teemori/fansly/bhqpk/teemori-fansly-ju2nw-2.jpg',
 '/uploads/may25/sa3/teemori/fansly/bhqpk/teemori-fansly-93vp3-1.jpg',
 '/uploads/may25/sa3/teemori/fansly/klnil/teemori-fansly-lmryl-4.jpg',
 '/uploads/may25/sa3/teemori/fansly/klnil/teemori-fansly-fbl5a-3.jpg',
 '/uploads/may25/sa3/teemori/fansly/klnil/teemori-fansly-8fkzt-2.jpg']

full image URL will be: f{base_url}{path_from_list_above}

To grab
https://picazor.com/en/maria-bolona
https://picazor.com/en/kiakuromi
https://picazor.com/en/amber-chan
https://picazor.com/en/cami
https://picazor.com/en/joj-838 (with videos)
https://picazor.com/en/rainbunny
https://picazor.com/en/niparat-konyai
https://www.xpics.me/@ramierah
https://picazor.com/en/emma-lvxx
https://picazor.com/en/dollyliney
https://picazor.com/en/misaki-sai
https://picazor.com/en/dollifce


Huges

https://picazor.com/en/lady-melamori
https://picazor.com/en/potatogodzilla-3
https://picazor.com/en/vixenp
https://picazor.com/en/saizneko
https://picazor.com/en/hannapunzell

"""
