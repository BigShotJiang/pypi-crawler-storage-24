from typing import Any

from .parser import get_sources_for_4khd


class KhdAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_4khd(**kwargs)


__all__ = ["KhdAdapter"]
