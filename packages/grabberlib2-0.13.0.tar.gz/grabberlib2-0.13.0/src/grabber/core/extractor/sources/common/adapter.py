from typing import Any

from .parser import get_sources_for_common


class CommonAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_common(**kwargs)


__all__ = ["CommonAdapter"]
