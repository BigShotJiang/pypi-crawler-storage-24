from typing import Any

from .parser import get_sources_for_fapello_ru


class FapelloRuAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_fapello_ru(**kwargs)


__all__ = ["FapelloRuAdapter"]
