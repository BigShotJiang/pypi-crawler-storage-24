from typing import Any

from .parser import get_sources_for_erome_tv


class EromeTvAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_erome_tv(**kwargs)


__all__ = ["EromeTvAdapter"]
