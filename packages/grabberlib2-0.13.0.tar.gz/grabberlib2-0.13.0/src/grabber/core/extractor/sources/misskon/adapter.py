from typing import Any

from .parser import get_sources_for_misskon


class MisskonAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_misskon(**kwargs)


__all__ = ["MisskonAdapter"]
