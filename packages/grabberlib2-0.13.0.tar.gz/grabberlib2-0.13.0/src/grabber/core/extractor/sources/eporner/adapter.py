from typing import Any

from .parser import get_sources_for_eporner


class EpornerAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_eporner(**kwargs)


__all__ = ["EpornerAdapter"]
