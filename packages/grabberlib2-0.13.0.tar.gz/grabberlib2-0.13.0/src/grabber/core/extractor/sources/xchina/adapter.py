from typing import Any

from .parser import get_sources_for_xchina


class XchinaAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_xchina(**kwargs)


__all__ = ["XchinaAdapter"]
