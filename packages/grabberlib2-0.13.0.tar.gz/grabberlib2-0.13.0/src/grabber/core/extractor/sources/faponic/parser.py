from bs4 import BeautifulSoup

from grabber.core.extractor.infrastructure.parsing.title import get_page_title


class FaponicParser:
    @staticmethod
    def get_post_title(soup: BeautifulSoup) -> str:
        return get_page_title(soup=soup, strings_to_remove=["aka", "- Faponic", "Nude"])
