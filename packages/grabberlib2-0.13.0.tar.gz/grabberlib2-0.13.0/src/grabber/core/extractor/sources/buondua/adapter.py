from typing import Any

from .parser import get_sources_for_buondua


class BuonduaAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_buondua(**kwargs)


__all__ = ["BuonduaAdapter"]
