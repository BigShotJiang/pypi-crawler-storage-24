from typing import Any

from .parser import get_sources_for_xiuren


class XiurenAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_xiuren(**kwargs)


__all__ = ["XiurenAdapter"]
