from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag

from grabber.core.extractor import ExtractorResult
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls, build_unique_video_urls
from grabber.core.extractor.infrastructure.parsing.title import get_page_title


class IbradomeParser:
    @staticmethod
    def build_page_title(soup: BeautifulSoup) -> str:
        return get_page_title(soup=soup, strings_to_remove=["Nude", "OnlyFans", "PhotosIbradome"])

    async def parse_result(
        self,
        soup: BeautifulSoup,
        image_tags: list[Tag],
        src_attr: str,
        video_tags: list[Tag] | None = None,
    ) -> ExtractorResult | None:
        # Preserve website/DOM order so Telegraph chunks match source chronology.
        ordered_unique_video_urls = IndexedSet()

        ordered_unique_img_urls = await build_unique_img_urls(image_tags, src_attr)
        if not ordered_unique_img_urls:
            return None

        if video_tags is not None:
            ordered_unique_video_urls = await build_unique_video_urls(video_tags, src_attr)

        return ExtractorResult(
            page_title=self.build_page_title(soup),
            ordered_unique_img_urls=ordered_unique_img_urls,
            ordered_unique_video_urls=ordered_unique_video_urls,
        )
