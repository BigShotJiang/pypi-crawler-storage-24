from __future__ import annotations

import re
from urllib.parse import parse_qs, urlencode, urlparse


class PornhubParser:
    SUPPORTED_HOSTS = {"pornhub.com", "www.pornhub.com", "m.pornhub.com"}
    VIEWKEY_PATTERN = re.compile(r"(?:viewkey=|/viewkey/)([a-zA-Z0-9]+)")

    def normalize_video_url(self, source_url: str) -> str:
        parsed = urlparse(source_url.strip())
        host = parsed.netloc.lower()
        if host not in self.SUPPORTED_HOSTS:
            raise ValueError(f"Unsupported Pornhub host: {parsed.netloc}")

        viewkey = self.extract_viewkey(source_url)
        query = urlencode({"viewkey": viewkey})
        return f"https://www.pornhub.com/view_video.php?{query}"

    def extract_viewkey(self, source_url: str) -> str:
        parsed = urlparse(source_url.strip())
        query_values = parse_qs(parsed.query)
        viewkey_values = query_values.get("viewkey", [])
        if viewkey_values and viewkey_values[0].strip():
            return viewkey_values[0].strip()

        regex_match = self.VIEWKEY_PATTERN.search(source_url)
        if regex_match:
            return regex_match.group(1).strip()

        raise ValueError("Could not extract Pornhub viewkey from URL")

    @staticmethod
    def build_caption(
        title: str | None,
        uploader: str | None,
        viewkey: str,
    ) -> str:
        safe_title = (title or "Pornhub video").strip() or "Pornhub video"
        safe_uploader = (uploader or "unknown").strip() or "unknown"
        caption = f"{safe_title}\nUploader: {safe_uploader}\nViewkey: {viewkey}"
        return caption[:1024]

    @staticmethod
    def build_filename_prefix(viewkey: str) -> str:
        if viewkey.strip():
            return f"{viewkey}.mp4"
        return "pornhub-video.mp4"


__all__ = ["PornhubParser"]
