from typing import Any

from .parser import get_sources_for_fuligirl


class FuligirlAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_fuligirl(**kwargs)


__all__ = ["FuligirlAdapter"]
