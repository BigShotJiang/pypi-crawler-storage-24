import pathlib
from typing import cast
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.usecases import run_default_source


async def get_pages_from_pagination(url: str, headers: dict[str, str] | None = None) -> list[str]:
    base_url = "https://fapexy.com/ajax/model/{model_slug}/page-{page_number}/"
    parsed_url = urlparse(url)
    model_slug = parsed_url.path.replace("/", "")
    page_number = 1
    source_urls: list[str] = []

    while True:
        target_url = base_url.format(model_slug=model_slug, page_number=page_number)
        page_response = httpx.get(url=target_url, headers=headers)
        page_content = page_response.content.decode("utf-8")
        if not page_content.strip():
            break
        source_urls.append(target_url)
        page_number += 1

    return source_urls


def get_page_title(soup: BeautifulSoup) -> str:
    try:
        page_title = (
            cast(Tag, soup.select_one("div.content.mt-3 p.line-height-s")).get_text(strip=True).split("instagram")[0]
        )
    except Exception:
        page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
    else:
        page_title_secondary = (
            cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip().split("- Fapexy!")[0].strip()
        )
        page_title = f"{page_title} {page_title_secondary}" if page_title_secondary not in page_title else page_title
        page_title = " ".join(list({f"#{part.replace('.', '_').replace('-', '_')}" for part in page_title.split(" ")}))

    return page_title


async def get_sources_for_fapexy(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
