from typing import Any

from .parser import get_sources_for_lewdweb


class LewdwebAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_lewdweb(**kwargs)


__all__ = ["LewdwebAdapter"]
