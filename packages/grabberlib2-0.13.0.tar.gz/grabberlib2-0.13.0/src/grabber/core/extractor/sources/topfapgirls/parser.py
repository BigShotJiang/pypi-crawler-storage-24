from __future__ import annotations

import logging
import pathlib
import re
from typing import Any
from urllib.parse import parse_qs, urlencode, urljoin, urlparse, urlunparse

import cloudscraper
import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig, ExtractorResult
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls
from grabber.core.extractor.usecases import run_default_source

logger = logging.getLogger(__name__)

THUMB_SIZE_SUFFIX_PATTERN = re.compile(r"-\d+x\d+(?=\.[a-zA-Z0-9]+(?:$|\?))")
TAG_POST_LINK_SELECTORS = (
    "div.grid-item a[href]",
    "div.elementor-posts-container a[href]",
    "a.elementor-post__thumbnail__link[href]",
    "article a[href]",
    "a[href]",
)
TAG_MAX_LOAD_MORE_PAGES = 500
HEADLINE_SELECTOR = 'h3.entry-title[itemprop="headline"]'
LOAD_MORE_SELECTOR = "button#load-more[data-page]"
ALIAS_TOKEN_PATTERN = re.compile(r"[A-Za-z0-9._-]+")
LISTING_PATH_MARKERS = ("latest-photos-topfapgirls", "/model/", "/social-media/")
AJAX_ENDPOINT_PATTERN = re.compile(r"(/wp-admin/admin-ajax\.php\?[^\"'\s<>]+)", flags=re.IGNORECASE)
CLOUDFLARE_CHALLENGE_MARKERS = (
    "just a moment...",
    "_cf_chl_opt",
    "/cdn-cgi/challenge-platform/",
)


def _build_load_more_endpoint(source_url: str, page: int) -> str:
    parsed = urlparse(source_url)
    base_url = f"{parsed.scheme}://{parsed.netloc}"
    return f"{base_url}/wp-admin/admin-ajax.php?action=load_attachments&page={page}"


def _set_page_query_param(endpoint_url: str, page: int) -> str:
    parsed = urlparse(endpoint_url)
    query_values = parse_qs(parsed.query, keep_blank_values=True)
    if "page" in query_values:
        query_values["page"] = [str(page)]
    elif "paged" in query_values:
        query_values["paged"] = [str(page)]
    else:
        query_values["page"] = [str(page)]

    encoded_query = urlencode(query_values, doseq=True)
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, encoded_query, parsed.fragment))


def _extract_ajax_endpoints_from_html(html_text: str, source_url: str) -> list[str]:
    if not html_text.strip():
        return []
    matches = AJAX_ENDPOINT_PATTERN.findall(html_text)
    endpoints = IndexedSet()
    for raw_match in matches:
        candidate = raw_match.strip().replace("&amp;", "&")
        absolute_endpoint = urljoin(source_url, candidate)
        parsed = urlparse(absolute_endpoint)
        if not parsed.scheme.startswith("http"):
            continue
        if not parsed.netloc:
            continue
        if not parsed.path.endswith("/wp-admin/admin-ajax.php"):
            continue
        endpoints.add(absolute_endpoint)
    return list(endpoints)


def _has_load_more_button(soup: BeautifulSoup) -> bool:
    return soup.select_one(LOAD_MORE_SELECTOR) is not None


def _is_cloudflare_challenge_html(html_text: str) -> bool:
    normalized = html_text.lower()
    return any(marker in normalized for marker in CLOUDFLARE_CHALLENGE_MARKERS)


def _is_cloudflare_challenge_soup(soup: BeautifulSoup) -> bool:
    return _is_cloudflare_challenge_html(str(soup))


def _get_soup_via_cloudscraper(source_url: str, headers: dict[str, str] | None = None) -> BeautifulSoup:
    scraper = cloudscraper.create_scraper(interpreter="nodejs")
    response = scraper.get(url=source_url, headers=headers, timeout=30)
    return BeautifulSoup(response.text, features="lxml")


async def _get_topfapgirls_soup_with_fallback(
    source_url: str,
    headers: dict[str, str] | None = None,
) -> tuple[BeautifulSoup, str]:
    first_try_soup = await get_soup(source_url, headers=headers)
    if not _is_cloudflare_challenge_soup(first_try_soup):
        return first_try_soup, "httpx"

    challenge_soup = first_try_soup
    try:
        cloudscraper_soup = _get_soup_via_cloudscraper(source_url, headers=headers)
        challenge_soup = cloudscraper_soup
        if not _is_cloudflare_challenge_soup(cloudscraper_soup):
            return cloudscraper_soup, "cloudscraper"
    except Exception:
        pass

    try:
        webdriver_soup = await get_soup(source_url, headers=headers, use_web_driver=True)
        if not _is_cloudflare_challenge_soup(webdriver_soup):
            return webdriver_soup, "webdriver"
        challenge_soup = webdriver_soup
    except Exception:
        pass

    return challenge_soup, "challenge"


def _should_use_tag_expansion(sources: list[str], is_tag_requested: bool) -> bool:
    if is_tag_requested:
        return True
    for source_url in sources:
        source_path = urlparse(source_url).path.lower()
        if any(marker in source_path for marker in LISTING_PATH_MARKERS):
            return True
    return False


def _is_candidate_post_url(candidate_url: str, source_url: str) -> bool:
    parsed_candidate = urlparse(candidate_url)
    parsed_source = urlparse(source_url)

    if not parsed_candidate.netloc:
        return False
    if parsed_candidate.netloc != parsed_source.netloc:
        return False

    candidate_path = parsed_candidate.path.lower()
    if not candidate_path or candidate_path == "/":
        return False
    if candidate_path == parsed_source.path.lower():
        return False

    if candidate_path.startswith("/model/"):
        model_parts = [part for part in candidate_path.split("/") if part]
        # Keep /model/<slug>/ post pages; block only section root/index.
        if len(model_parts) <= 1:
            return False

    if candidate_path.startswith("/social-media/"):
        social_parts = [part for part in candidate_path.split("/") if part]
        # Keep /social-media/<network>/<slug>/ post pages; block section indexes.
        if len(social_parts) <= 2:
            return False

    blocked_prefixes = (
        "/category/",
        "/tag/",
        "/author/",
        "/wp-admin/",
        "/wp-json/",
        "/feed/",
    )
    if candidate_path.startswith(blocked_prefixes):
        return False

    blocked_exact_paths = {
        "/",
        "/about/",
        "/privacy-policy/",
        "/terms-of-use/",
        "/dmca/",
        "/contact/",
        "/sitemap.xml",
    }
    if candidate_path in blocked_exact_paths:
        return False

    return True


def _extract_post_links_from_html(html_text: str, source_url: str) -> list[str]:
    if not html_text.strip():
        return []
    soup = BeautifulSoup(html_text, features="html.parser")
    return _extract_post_links_from_soup(soup, source_url=source_url)


def _extract_post_links_from_soup(soup: BeautifulSoup, source_url: str) -> list[str]:
    post_links = IndexedSet()
    for query in TAG_POST_LINK_SELECTORS:
        for anchor in soup.select(query):
            href = anchor.attrs.get("href", "").strip()
            if not href:
                continue
            absolute_url = urljoin(source_url, href)
            if _is_candidate_post_url(absolute_url, source_url=source_url):
                post_links.add(absolute_url)
    return list(post_links)


def _request_topfapgirls_load_more_payload(
    endpoint_url: str,
    source_url: str,
    headers: dict[str, str] | None = None,
) -> str:
    request_headers = dict(headers or {})
    request_headers.setdefault("Referer", source_url)
    request_headers.setdefault("X-Requested-With", "XMLHttpRequest")
    request_headers.setdefault("Accept", "text/html, */*;q=0.8")

    try:
        response = httpx.get(endpoint_url, headers=request_headers, timeout=30)
        if response.status_code < 400 and response.text.strip():
            return response.text
    except Exception:
        pass

    parsed = urlparse(endpoint_url)
    payload = {key: values[-1] for key, values in parse_qs(parsed.query, keep_blank_values=True).items() if values}
    try:
        post_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", ""))
        post_response = httpx.post(post_url, data=payload, headers=request_headers, timeout=30)
        if post_response.status_code < 400:
            return post_response.text
    except Exception:
        return ""
    return ""


def _normalize_alias_token(raw_alias: str) -> str | None:
    cleaned_alias = raw_alias.strip().strip(".,;:!()[]{}<>\"'").replace(".", "_").replace("-", "_")
    if not cleaned_alias:
        return None
    if cleaned_alias.lower() in {
        "nude",
        "leaked",
        "onlyfans",
        "pics",
        "bonus",
        "mega",
        "link",
        "videos",
        "video",
        "photo",
        "photos",
        "gallery",
        "galleries",
        "exclusive",
        "content",
        "topfapgirls",
    }:
        return None
    return cleaned_alias


def extract_topfapgirls_model_aliases(headline_text: str) -> list[str]:
    normalized = " ".join(headline_text.strip().split())
    if not normalized:
        return []

    aliases: list[str] = []

    primary_split = re.split(r"\b(?:nude|leaked)\b|[–-]", normalized, maxsplit=1, flags=re.IGNORECASE)
    primary_candidate = primary_split[0].strip() if primary_split else ""
    primary_tokens = ALIAS_TOKEN_PATTERN.findall(primary_candidate)
    if primary_tokens:
        primary_alias = _normalize_alias_token(primary_tokens[0])
        if primary_alias:
            aliases.append(primary_alias)

    for match in re.finditer(r"\baka\b\s+([^\s–-]+)", normalized, flags=re.IGNORECASE):
        alias_candidate = _normalize_alias_token(match.group(1))
        if alias_candidate:
            aliases.append(alias_candidate)

    deduped_aliases = IndexedSet(aliases)
    return list(deduped_aliases)


def get_topfapgirls_page_title(soup: BeautifulSoup) -> str:
    headline_node = soup.select_one(HEADLINE_SELECTOR)
    if headline_node is not None:
        aliases = extract_topfapgirls_model_aliases(headline_node.get_text(strip=True))
        if aliases:
            return " ".join(f"#{alias}" for alias in aliases)

    title_node = soup.select_one("title")
    if title_node is None:
        return "#topfapgirls"

    fallback_title = title_node.get_text(strip=True)
    fallback_aliases = extract_topfapgirls_model_aliases(fallback_title)
    if fallback_aliases:
        return " ".join(f"#{alias}" for alias in fallback_aliases)
    return "#topfapgirls"


async def get_topfapgirls_sources_from_tag_page(
    source_url: str,
    headers: dict[str, str] | None = None,
    max_pages: int = TAG_MAX_LOAD_MORE_PAGES,
) -> list[str]:
    first_page_soup, fetch_mode = await _get_topfapgirls_soup_with_fallback(source_url, headers=headers)
    first_page_html = str(first_page_soup)
    has_load_more_button = _has_load_more_button(first_page_soup)
    if not has_load_more_button:
        logger.warning(
            "Topfapgirls tag expansion source=%s load_more=%s fetch_mode=%s action=passthrough",
            source_url,
            has_load_more_button,
            fetch_mode,
        )
        return [source_url]

    all_links = IndexedSet()
    first_page_links = _extract_post_links_from_soup(first_page_soup, source_url=source_url)
    for link in first_page_links:
        all_links.add(link)

    endpoint_candidates = IndexedSet()
    if has_load_more_button:
        discovered_endpoints = _extract_ajax_endpoints_from_html(first_page_html, source_url=source_url)
        default_endpoint_page_1 = _build_load_more_endpoint(source_url=source_url, page=1)
        endpoint_candidates = IndexedSet([default_endpoint_page_1, *discovered_endpoints])

    logger.warning(
        "Topfapgirls tag expansion source=%s first_page_links=%s load_more=%s endpoints=%s fetch_mode=%s",
        source_url,
        len(first_page_links),
        has_load_more_button,
        len(endpoint_candidates),
        fetch_mode,
    )

    safe_max_pages = max(2, min(max_pages, TAG_MAX_LOAD_MORE_PAGES))
    start_page = 1 if not first_page_links else 2
    last_payload_fingerprint = ""
    empty_payload_count = 0

    for page_number in range(start_page, safe_max_pages + 1):
        if not endpoint_candidates:
            break
        page_has_new_links = False
        for endpoint_template in endpoint_candidates:
            endpoint = _set_page_query_param(endpoint_template, page=page_number)
            payload = _request_topfapgirls_load_more_payload(endpoint, source_url=source_url, headers=headers)
            payload_fingerprint = payload.strip()
            if not payload_fingerprint:
                continue
            if payload_fingerprint == last_payload_fingerprint:
                continue
            last_payload_fingerprint = payload_fingerprint

            links = _extract_post_links_from_html(payload, source_url=source_url)
            if not links:
                continue
            for link in links:
                if link not in all_links:
                    page_has_new_links = True
                all_links.add(link)

        if not page_has_new_links:
            empty_payload_count += 1
        else:
            empty_payload_count = 0

        if empty_payload_count >= 2:
            break

    if all_links:
        return list(all_links)
    return [source_url]


def normalize_topfapgirls_image_url(image_url: str) -> str:
    return THUMB_SIZE_SUFFIX_PATTERN.sub("", image_url)


def with_full_size_topfapgirls_urls(ordered_unique_img_urls: IndexedSet) -> IndexedSet:
    rewritten_urls = IndexedSet()
    for media_record in ordered_unique_img_urls:
        if not media_record:
            continue
        media_url = media_record[-1]
        if not isinstance(media_url, str) or not media_url.strip():
            continue
        normalized_url = normalize_topfapgirls_image_url(media_url.strip())
        rewritten_urls.add((*media_record[:-1], normalized_url))
    return rewritten_urls


async def _collect_topfapgirls_result(
    source_url: str,
    headers: dict[str, str] | None,
    query: str,
    src_attr: str,
) -> ExtractorResult | None:
    soup, fetch_mode = await _get_topfapgirls_soup_with_fallback(source_url, headers=headers)
    if fetch_mode == "challenge":
        logger.warning(
            "Topfapgirls source=%s returned Cloudflare challenge on all fetch attempts; skipping",
            source_url,
        )
        return None

    image_tags = soup.select(query)
    if not image_tags:
        return None

    ordered_unique_img_urls = await build_unique_img_urls(
        image_tags=image_tags,
        src_attr=src_attr,
        entity="topfapgirls.net",
    )
    ordered_unique_img_urls = with_full_size_topfapgirls_urls(ordered_unique_img_urls)
    if not ordered_unique_img_urls:
        return None

    return ExtractorResult(
        page_title=get_topfapgirls_page_title(soup),
        ordered_unique_img_urls=ordered_unique_img_urls,
    )


async def get_sources_for_topfapgirls(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs: Any,
) -> None:
    query, src_attr = query_mapping[entity]
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        title_factory=get_topfapgirls_page_title,
        image_urls_post_processor=with_full_size_topfapgirls_urls,
        result_collector=lambda source_url, headers: _collect_topfapgirls_result(
            source_url=source_url,
            headers=headers,
            query=query,
            src_attr=src_attr,
        ),
    )
    max_pages = int(kwargs.get("max_pages", 50))
    is_tag_mode = _should_use_tag_expansion(sources=sources, is_tag_requested=bool(kwargs.get("is_tag", False)))

    async def topfapgirls_tag_fetcher(
        source_url: str,
        headers: dict[str, str] | None = None,
    ) -> list[str]:
        return await get_topfapgirls_sources_from_tag_page(
            source_url=source_url,
            headers=headers,
            max_pages=max_pages,
        )

    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        is_tag=is_tag_mode,
        limit=kwargs.get("limit"),
        channel=kwargs.get("channel", ""),
        max_pages=max_pages,
        tag_source_fetcher=topfapgirls_tag_fetcher,
    )


__all__ = [
    "extract_topfapgirls_model_aliases",
    "get_sources_for_topfapgirls",
    "get_topfapgirls_page_title",
    "get_topfapgirls_sources_from_tag_page",
    "normalize_topfapgirls_image_url",
    "with_full_size_topfapgirls_urls",
]
