from typing import Any

from .parser import get_sources_for_erome


class EromeAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_erome(**kwargs)


__all__ = ["EromeAdapter"]
