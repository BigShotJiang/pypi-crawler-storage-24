from typing import Any

from .parser import get_sources_for_nudecosplay


class NudecosplayAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_nudecosplay(**kwargs)


__all__ = ["NudecosplayAdapter"]
