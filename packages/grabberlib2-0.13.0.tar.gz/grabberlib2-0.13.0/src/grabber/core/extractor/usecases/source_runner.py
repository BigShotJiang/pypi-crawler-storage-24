import pathlib
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

from telegraph import Telegraph

from grabber.core.extractor.base import DefaultExtractor, ExtractorConfig
from grabber.core.extractor.constants import HEADERS_MAPPING
from grabber.core.extractor.infrastructure.fetching.scraper import get_pages_from_pagination

if TYPE_CHECKING:
    from grabber.core.extractor.infrastructure.checkpoints.contracts import SourceCheckpointHint

TagSourceFetcher = Callable[[str, dict[str, str] | None], Awaitable[list[str]]]


@dataclass(slots=True)
class DefaultSourceRunRequest:
    sources: list[str]
    entity: str
    telegraph_client: Telegraph | None = None
    config: ExtractorConfig | None = None
    final_dest: str | pathlib.Path = ""
    save_to_telegraph: bool = False
    is_tag: bool = False
    limit: int | None = None
    channel: str = ""
    max_pages: int = 50
    tag_pagination_target: str | None = None
    tag_source_fetcher: TagSourceFetcher | None = None
    checkpoint_hint: "SourceCheckpointHint | None" = None


class TagSourceExpander:
    def __init__(self, entity: str) -> None:
        self.entity = entity
        self.headers = HEADERS_MAPPING.get(entity, HEADERS_MAPPING["common"])

    @staticmethod
    async def expand_sources_from_tag_pages(
        sources: list[str],
        target: str,
        headers: dict[str, str] | None = None,
        limit: int | None = None,
    ) -> list[str]:
        seen = set()
        expanded_sources: list[str] = []

        for source_url in sources:
            urls = await get_pages_from_pagination(
                url=source_url,
                target=target,
                headers=headers,
            )
            for url in urls:
                if url in seen:
                    continue
                seen.add(url)
                expanded_sources.append(url)
                if limit and len(expanded_sources) >= limit:
                    return expanded_sources

        return expanded_sources or sources

    async def expand(
        self,
        sources: list[str],
        *,
        limit: int | None = None,
        tag_pagination_target: str | None = None,
        tag_source_fetcher: TagSourceFetcher | None = None,
    ) -> list[str]:
        if tag_source_fetcher is not None:
            target_sources: list[str] = []
            seen = set()
            for source_url in sources:
                source_urls = await tag_source_fetcher(source_url, self.headers)
                for expanded_source_url in source_urls:
                    if expanded_source_url in seen:
                        continue
                    seen.add(expanded_source_url)
                    target_sources.append(expanded_source_url)
            return target_sources[:limit] if limit else target_sources

        if tag_pagination_target:
            return await self.expand_sources_from_tag_pages(
                sources=sources,
                target=tag_pagination_target,
                headers=self.headers,
                limit=limit,
            )

        return sources


class DefaultSourceRunner:
    def __init__(self) -> None:
        self._expanders: dict[str, TagSourceExpander] = {}

    def _get_expander(self, entity: str) -> TagSourceExpander:
        if entity not in self._expanders:
            self._expanders[entity] = TagSourceExpander(entity=entity)
        return self._expanders[entity]

    async def run(self, request: DefaultSourceRunRequest) -> None:
        target_sources = request.sources

        if request.is_tag:
            expander = self._get_expander(request.entity)
            target_sources = await expander.expand(
                sources=request.sources,
                limit=request.limit,
                tag_pagination_target=request.tag_pagination_target,
                tag_source_fetcher=request.tag_source_fetcher,
            )

        extractor = DefaultExtractor(
            sources=target_sources,
            entity=request.entity,
            config=request.config,
            final_dest=request.final_dest,
            is_tag=False,
            limit=request.limit,
            save_to_telegraph=request.save_to_telegraph,
            channel=request.channel,
            max_pages=request.max_pages,
            telegraph_client=request.telegraph_client,
            checkpoint_hint=request.checkpoint_hint,
        )
        await extractor.run()


async def expand_sources_from_tag_pages(
    sources: list[str],
    target: str,
    headers: dict[str, str] | None = None,
    limit: int | None = None,
) -> list[str]:
    return await TagSourceExpander.expand_sources_from_tag_pages(
        sources=sources,
        target=target,
        headers=headers,
        limit=limit,
    )


async def run_default_source(
    sources: list[str],
    entity: str,
    *,
    telegraph_client: Telegraph | None = None,
    config: ExtractorConfig | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    is_tag: bool | None = False,
    limit: int | None = None,
    channel: str = "",
    max_pages: int = 50,
    tag_pagination_target: str | None = None,
    tag_source_fetcher: TagSourceFetcher | None = None,
    checkpoint_hint: "SourceCheckpointHint | None" = None,
) -> None:
    runner = DefaultSourceRunner()
    await runner.run(
        DefaultSourceRunRequest(
            sources=sources,
            entity=entity,
            telegraph_client=telegraph_client,
            config=config,
            final_dest=final_dest,
            save_to_telegraph=bool(save_to_telegraph),
            is_tag=bool(is_tag),
            limit=limit,
            channel=channel,
            max_pages=max_pages,
            tag_pagination_target=tag_pagination_target,
            tag_source_fetcher=tag_source_fetcher,
            checkpoint_hint=checkpoint_hint,
        )
    )
