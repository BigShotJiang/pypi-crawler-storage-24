from .scraper import get_pages_from_pagination, get_soup, get_tags, get_webdriver

__all__ = ["get_pages_from_pagination", "get_soup", "get_tags", "get_webdriver"]
