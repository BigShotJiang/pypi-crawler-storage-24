import asyncio
import logging
import pathlib
from asyncio import as_completed, sleep
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from typing import Any

from boltons.setutils import IndexedSet
from casefy.casefy import snakecase
from telegraph import Telegraph
from telegraph import exceptions as telegraph_exceptions
from tqdm import tqdm

from grabber.core.bot.core import send_message
from grabber.core.extractor.constants import DEFAULT_THREADS_NUMBER
from grabber.core.extractor.infrastructure.checkpoints import build_checkpoint_service
from grabber.core.extractor.infrastructure.helpers import print_albums_message, sort_file, split_every
from grabber.core.settings import AUTHOR_NAME, AUTHOR_URL, MAX_IMAGES_PER_POST, SHORT_NAME, get_media_root

logger = logging.getLogger(__name__)


def _set_progress(tqdm_iterable: tqdm | None, message: str) -> None:
    if tqdm_iterable is not None:
        tqdm_iterable.set_description(message)
    else:
        logger.info(message)


async def upload_file(
    file: pathlib.Path,
    telegraph_client: Telegraph,
    try_again: bool | None = True,
) -> str | None:
    source = None
    try:
        uploaded = telegraph_client.upload_file(file)
    except (
        Exception,
        telegraph_exceptions.TelegraphException,
        telegraph_exceptions.RetryAfterError,
    ) as exc:
        error_message = str(exc)
        if "try again" in error_message.lower() or "retry" in error_message.lower():
            await asyncio.sleep(5)
            if try_again:
                telegraph_client = await get_new_telegraph_client()
                return await upload_file(file=file, telegraph_client=telegraph_client, try_again=False)
        uploaded = None

    if uploaded:
        source = uploaded[0]["src"]

    return source


async def get_new_telegraph_client() -> Telegraph:
    telegraph_factory = Telegraph()
    resp = telegraph_factory.create_account(
        short_name=SHORT_NAME,
        author_name=AUTHOR_NAME,
        author_url=AUTHOR_URL,
        replace_token=True,
    )
    access_token = resp["access_token"]
    telegraph_client = Telegraph(access_token=access_token)
    return telegraph_client


async def telegraph_uploader(
    unique_img_urls: IndexedSet,
    page_title: str,
    posts_sent_counter: int = 0,
    telegraph_client: Telegraph | None = None,
    tqdm_iterable: tqdm = None,
    entity: str | None = "",
    send_to_telegram: bool | None = True,
    channel: str | None = "",
    source_url: str | None = None,
    **kwargs: Any,
) -> tuple[bool, list[str]]:
    was_successful = False
    checkpoint_service = build_checkpoint_service()
    use_checkpoint = bool(kwargs.get("use_checkpoint", False))

    if use_checkpoint and source_url:
        decision = checkpoint_service.filter_media(
            source_url=source_url,
            ordered_unique_img_urls=unique_img_urls,
            ordered_unique_video_urls=None,
        )
        unique_img_urls = decision.new_images
        if decision.skipped_images_count > 0:
            logger.info(
                "checkpoint_skipped_media=%s checkpoint_new_media=%s checkpoint_source_key=%s",
                decision.skipped_images_count,
                len(unique_img_urls),
                source_url,
            )
        if not unique_img_urls:
            _set_progress(tqdm_iterable, f"No new media for {page_title}; checkpoint skipped upload")
            return True, [channel or ""]

    if telegraph_client is None:
        telegraph_client = await get_new_telegraph_client()

    posts: list[str] = []
    _set_progress(tqdm_iterable, f"Creating Telegraph post for {page_title}...")
    html_post = await create_html_template(unique_img_urls, entity=entity)
    if not html_post.strip():
        _set_progress(tqdm_iterable, f"Skipping Telegraph post for {page_title}: no valid media content")
        return False, [channel or ""]
    _set_progress(tqdm_iterable, f"Uploading to Telegraph: {page_title}...")
    post_url = await create_page(
        title=page_title,
        html_content=html_post,
        tqdm_iterable=tqdm_iterable,
        telegraph_client=telegraph_client,
    )
    channels_sent: list[str] = [""]

    if not post_url:
        _set_progress(tqdm_iterable, f"Failed to create post for {page_title}")
        was_successful, channels_sent = False, [""]
        return was_successful, channels_sent

    telegraph_post = f"{page_title} - {post_url}"
    _set_progress(tqdm_iterable, f"Successfully created Telegraph post for {page_title}: {post_url}")
    posts.append(telegraph_post)

    if posts_sent_counter == 10:
        await asyncio.sleep(10)

    if send_to_telegram:
        _set_progress(tqdm_iterable, f"Sending Telegraph post to Telegram: {telegraph_post}...")
        try:
            was_successful, channels_sent = await send_message(
                post_text=telegraph_post,
                retry=True,
                posts_counter=posts_sent_counter,
                tqdm_iterable=tqdm_iterable,
                image_urls=set(unique_img_urls),
                entity=entity,
                channel=channel,
            )
            _set_progress(tqdm_iterable, f"Successfully sent Telegraph post to Telegram: {telegraph_post}")
        except Exception as exc:
            _set_progress(tqdm_iterable, f"Error sending Telegraph post to Telegram: {telegraph_post}: {exc}")
            _set_progress(tqdm_iterable, "Retrying...")
            await asyncio.sleep(20)
            was_successful, channels_sent = await send_message(
                post_text=telegraph_post,
                retry=True,
                posts_counter=posts_sent_counter,
                tqdm_iterable=tqdm_iterable,
                image_urls=set(unique_img_urls),
                entity=entity,
                channel=channel,
            )
    else:
        albums_dir = pathlib.Path.home() / ".albums_data"
        albums_dir.mkdir(parents=True, exist_ok=True)
        albums_file = albums_dir / "pages.txt"

        with albums_file.open("w") as f:
            _ = f.write("\n".join(posts))

        albums_links = albums_file.read_text().split("\n")
        await print_albums_message(albums_links)
        was_successful = True

    await print_albums_message(posts)
    _set_progress(tqdm_iterable, f"Finished processing {page_title}")
    if use_checkpoint and source_url and was_successful:
        checkpoint_service.commit_media(source_url=source_url, media_records=unique_img_urls)

    return was_successful, channels_sent


async def upload_folders_to_telegraph(
    folder_name: pathlib.Path | None,
    telegraph_client: Telegraph,
    limit: int | None = 0,
    send_to_channel: bool | None = False,
) -> None:
    folders = []

    if folder_name:
        root = get_media_root() / folder_name
        folders += [f for f in list(root.iterdir()) if f.is_dir()]
    else:
        root_folders = [folder for folder in get_media_root().iterdir() if folder.is_dir()]
        for folder in root_folders:
            if folder.is_dir():
                nested_folders = [f for f in folder.iterdir() if f.is_dir()]
                if nested_folders:
                    folders += nested_folders
                else:
                    folders = root_folders

    futures_to_folder = {}
    selected_folders = folders[:limit] if limit else folders
    with ThreadPoolExecutor(max_workers=DEFAULT_THREADS_NUMBER) as executor:
        future_counter = 0
        for folder in selected_folders:
            partial_upload = partial(
                upload_to_telegraph,
                folder,
                send_to_telegram=send_to_channel,
                telegraph_client=telegraph_client,
            )
            future = executor.submit(partial_upload)
            futures_to_folder[future] = folder
            future_counter += 1

        page_urls: list[tuple[str, str]] = []
        for future in tqdm(
            as_completed(futures_to_folder),
            total=future_counter,
            desc=f"Uploading {future_counter} albums to Telegraph...",
        ):
            result = future.result()
            page_urls.append(result)

        content = "\n".join([f"{page_url}" for page_url in page_urls])
        print(content)


async def create_page(
    title: str,
    html_content: str,
    tqdm_iterable: tqdm,
    telegraph_client: Telegraph,
    try_again: bool | None = True,
) -> str | None:
    source = None
    try:
        _set_progress(tqdm_iterable, f"Creating Telegraph page for {title}...")
        page = telegraph_client.create_page(
            title=title,
            html_content=html_content,
            author_name=AUTHOR_NAME,
            author_url=AUTHOR_URL,
        )
        source = page["url"]
        _set_progress(tqdm_iterable, f"Successfully created Telegraph page for {title}: {source}")
    except (
        Exception,
        telegraph_exceptions.TelegraphException,
        telegraph_exceptions.RetryAfterError,
    ) as exc:
        error_message = str(exc)
        _set_progress(tqdm_iterable, f"Error creating Telegraph page for {title}: {error_message}")
        await sleep(5)
        if try_again:
            telegraph_client = await get_new_telegraph_client()
            return await create_page(
                title=title,
                html_content=html_content,
                tqdm_iterable=tqdm_iterable,
                telegraph_client=telegraph_client,
                try_again=False,
            )

    return source


async def create_html_template(image_tags: IndexedSet, entity: str | None = "") -> str:
    if entity == "e-hentai.org":
        img_html_template = """<figure contenteditable="false"><img style="height:722px;width:1280px" src="{file_path}" data-original="{file_path}"><figcaption dir="auto" class="editable_text"></figcaption></figure>"""
    elif entity == "buondua.com":
        img_html_template = """<figure contenteditable="false"><img loading="lazy" referrerpolicy="strict-origin" width="1024" height="1365" src="{file_path}"><figcaption dir="auto" class="editable_text"></figcaption></figure>"""
    else:
        img_html_template = """<figure contenteditable="false"><img src="{file_path}" data-original="{file_path}"><figcaption dir="auto" class="editable_text"></figcaption></figure>"""

    video_html_template = (
        '<video src="{video_path}" preload="metadata" controls="controls" poster="{video_poster}" muted></video>'
    )

    template_tags: list[str] = []
    for media_record in image_tags:
        if isinstance(media_record, (tuple, list)):
            media_src = str(media_record[-1]) if media_record else ""
            poster = str(media_record[-2]) if len(media_record) >= 3 else ""
        else:
            media_src = str(media_record)
            poster = ""

        if not media_src or "http" not in media_src:
            continue

        poster_value = poster if poster.startswith("http") else ""
        if "mp4" in media_src and entity != "fapello.su":
            template_tags.append(video_html_template.format(video_path=media_src, video_poster=poster_value))
        else:
            template_tags.append(img_html_template.format(file_path=media_src))

    if not template_tags:
        return ""

    html_post = f"Source: <a href='{entity}'>{entity}</a>\n" if entity else ""
    html_post += "\n".join(template_tags)
    return html_post


async def upload_to_telegraph(
    folder: pathlib.Path,
    telegraph_client: Telegraph,
    page_title: str | None = "",
    send_to_telegram: bool | None = False,
) -> str:
    files = sorted(list(folder.iterdir()), key=sort_file)
    title = page_title or folder.name
    title = title.strip().rstrip()

    contents = []
    files_urls = []
    html_template = """<figure contenteditable="false"><img src="{file_path}"><figcaption dir="auto" class="editable_text" data-placeholder="{title}"></figcaption></figure>"""

    uploaded_files_url_path = pathlib.Path(f"{snakecase(title)}.txt")
    if uploaded_files_url_path.exists() and uploaded_files_url_path.stat().st_size > 0:
        contents = uploaded_files_url_path.read_text().split("\n")
    else:
        iterable_files = tqdm(
            files,
            total=len(files),
            desc=f"Uploading files for {folder.name}",
            leave=False,
        )
        image_title = f"{title}"
        for file in iterable_files:
            file_url = await upload_file(file, telegraph_client=telegraph_client)
            if not file_url:
                continue
            files_urls.append(file_url)
            contents.append(html_template.format(file_path=file_url, title=image_title))

    if contents:
        content = "\n".join(contents)
        try:
            page_url = create_page(
                title=title,
                html_content=content,
                telegraph_client=telegraph_client,
            )
        except telegraph_exceptions.TelegraphException as exc:
            return f"Error: {exc} - {title} - {folder}"

        post = f"{title} - {page_url}"

        if send_to_telegram:
            await send_message(post, image_urls=files_urls)

        pages_file = get_media_root() / "assets/pages.txt"

        if not pages_file.exists():
            pages_file.touch(exist_ok=True)

        with open(pages_file, "a") as f:
            f.write(f"{post}\n")

        return post

    return "No content, please try again later"


async def send_post_to_telegram(
    page_title: str,
    ordered_unique_img_urls: IndexedSet,
    posts_sent_counter: int,
    telegraph_client: Telegraph | None,
    tqdm_sources_iterable: tqdm,
    all_sources: list[str] | None,
    source_url: str,
    ordered_unique_video_urls: IndexedSet | None = None,
    entity: str | None = "",
    send_to_telegram: bool | None = True,
    channel: str | None = "",
    **kwargs: Any,
) -> list[str] | None:
    if not all_sources:
        all_sources = []

    checkpoint_service = build_checkpoint_service()
    checkpoint_decision = checkpoint_service.filter_media(
        source_url=source_url,
        ordered_unique_img_urls=ordered_unique_img_urls,
        ordered_unique_video_urls=ordered_unique_video_urls,
    )
    ordered_unique_img_urls = checkpoint_decision.new_images
    ordered_unique_video_urls = checkpoint_decision.new_videos

    logger.info(
        "checkpoint_skipped_media_images=%s checkpoint_skipped_media_videos=%s checkpoint_new_media_images=%s checkpoint_new_media_videos=%s checkpoint_source_key=%s",
        checkpoint_decision.skipped_images_count,
        checkpoint_decision.skipped_videos_count,
        len(ordered_unique_img_urls),
        len(ordered_unique_video_urls) if ordered_unique_video_urls is not None else 0,
        source_url,
    )

    has_new_images = len(ordered_unique_img_urls) > 0
    has_new_videos = ordered_unique_video_urls is not None and len(ordered_unique_video_urls) > 0
    if not has_new_images and not has_new_videos:
        _set_progress(tqdm_sources_iterable, f"No new media for {page_title}; checkpoint skipped publish")
        return all_sources

    total_imgs = len(ordered_unique_img_urls)
    videos_chunk_size = 2
    SLEEP_TIME = 5

    match total_imgs:
        case total_imgs if total_imgs in list(range(100, 150)):
            chunk_size = 50
        case total_imgs if total_imgs in list(range(150, 200)):
            chunk_size = 55
        case total_imgs if total_imgs in list(range(200, 250)):
            chunk_size = 60
        case total_imgs if total_imgs in list(range(250, 300)):
            chunk_size = 65
        case _:
            chunk_size = 70

    _set_progress(tqdm_sources_iterable, f"Uploading to Telegraph in chunks of {chunk_size} images...")

    if len(ordered_unique_img_urls) >= MAX_IMAGES_PER_POST:
        async for chunk in split_every(chunk_size, ordered_unique_img_urls):
            was_successful, _ = await telegraph_uploader(
                unique_img_urls=IndexedSet(chunk),
                page_title=page_title,
                posts_sent_counter=posts_sent_counter,
                telegraph_client=telegraph_client,
                tqdm_iterable=tqdm_sources_iterable,
                entity=entity,
                send_to_telegram=send_to_telegram,
                channel=channel,
                source_url=source_url,
                use_checkpoint=False,
            )
            if was_successful:
                checkpoint_service.commit_media(source_url=source_url, media_records=IndexedSet(chunk))
            else:
                logger.warning("Skipping checkpoint commit for failed image chunk source=%s", source_url)
            posts_sent_counter += 1
            _set_progress(tqdm_sources_iterable, f"Waiting {SLEEP_TIME} seconds before next chunk upload...")
            await asyncio.sleep(SLEEP_TIME)
    elif len(ordered_unique_img_urls) > 0:
        was_successful, _ = await telegraph_uploader(
            unique_img_urls=IndexedSet(ordered_unique_img_urls),
            page_title=page_title,
            posts_sent_counter=posts_sent_counter,
            telegraph_client=telegraph_client,
            tqdm_iterable=tqdm_sources_iterable,
            entity=entity,
            send_to_telegram=send_to_telegram,
            channel=channel,
            source_url=source_url,
            use_checkpoint=False,
        )
        if was_successful:
            checkpoint_service.commit_media(source_url=source_url, media_records=IndexedSet(ordered_unique_img_urls))
        else:
            logger.warning("Skipping checkpoint commit for failed image upload source=%s", source_url)
        await asyncio.sleep(SLEEP_TIME)
        posts_sent_counter += 1

    if ordered_unique_video_urls is not None and len(ordered_unique_video_urls) > 0:
        async for chunk in split_every(videos_chunk_size, ordered_unique_video_urls):
            was_successful, _ = await telegraph_uploader(
                unique_img_urls=IndexedSet(chunk),
                page_title=page_title,
                posts_sent_counter=posts_sent_counter,
                telegraph_client=telegraph_client,
                tqdm_iterable=tqdm_sources_iterable,
                entity=entity,
                send_to_telegram=send_to_telegram,
                channel=channel,
                source_url=source_url,
                use_checkpoint=False,
            )
            if was_successful:
                checkpoint_service.commit_media(source_url=source_url, media_records=IndexedSet(chunk))
            else:
                logger.warning("Skipping checkpoint commit for failed video chunk source=%s", source_url)
            posts_sent_counter += 1
            _set_progress(tqdm_sources_iterable, f"Waiting {SLEEP_TIME} seconds before next chunk upload...")
            await asyncio.sleep(SLEEP_TIME)

    return all_sources
