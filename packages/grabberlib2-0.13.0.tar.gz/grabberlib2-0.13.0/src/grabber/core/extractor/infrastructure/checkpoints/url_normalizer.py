from __future__ import annotations

import hashlib
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

TRACKING_QUERY_PREFIXES = (
    "utm_",
    "fbclid",
    "gclid",
    "mc_cid",
    "mc_eid",
)

TRACKING_QUERY_EXACT = {
    "ref",
    "source",
    "igshid",
}


def normalize_source_url(url: str) -> str:
    parsed = urlparse(url)
    host = parsed.netloc.lower()
    path = parsed.path.rstrip("/")
    if not path:
        path = "/"

    filtered_query: list[tuple[str, str]] = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=True):
        lower_key = key.lower()
        if lower_key.startswith(TRACKING_QUERY_PREFIXES):
            continue
        if lower_key in TRACKING_QUERY_EXACT:
            continue
        filtered_query.append((key, value))

    query = urlencode(filtered_query, doseq=True)
    normalized = parsed._replace(netloc=host, path=path, query=query, fragment="")
    return urlunparse(normalized)


def normalize_media_url(url: str) -> str:
    parsed = urlparse(url)
    host = parsed.netloc.lower()
    normalized = parsed._replace(netloc=host, fragment="")
    return urlunparse(normalized)


def hash_media_url(url: str) -> str:
    normalized = normalize_media_url(url)
    return hashlib.sha1(normalized.encode("utf-8")).hexdigest()
