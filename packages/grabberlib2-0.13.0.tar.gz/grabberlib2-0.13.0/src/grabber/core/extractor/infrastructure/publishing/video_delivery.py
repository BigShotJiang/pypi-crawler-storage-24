from __future__ import annotations

import asyncio
import logging
import pathlib
import tempfile
from dataclasses import dataclass
from typing import Any
from urllib.parse import unquote, urlparse

import aiofiles
import aiohttp
from aiogram import Bot
from aiogram.exceptions import TelegramEntityTooLarge, TelegramRetryAfter
from aiogram.types import FSInputFile, URLInputFile
from boltons.setutils import IndexedSet
from tqdm import tqdm

from grabber.core.extractor.infrastructure.checkpoints import build_checkpoint_service
from grabber.core.settings import BOT_TOKEN

logger = logging.getLogger(__name__)
CHUNK_SIZE = 1024 * 1024
URL_INPUT_MAX_BYTES = 20 * 1024 * 1024
BOT_UPLOAD_MAX_BYTES = 50 * 1024 * 1024


@dataclass(slots=True)
class VideoDeliveryStats:
    total_found: int
    total_after_checkpoint: int
    sent_count: int
    skipped_count: int
    fallback_download_count: int
    fallback_document_count: int
    failed_count: int
    link_only_count: int = 0


def _set_progress(tqdm_iterable: tqdm | None, message: str) -> None:
    if tqdm_iterable is not None:
        tqdm_iterable.set_description(message)
        return
    logger.info(message)


async def _run_with_retry_after(operation) -> Any:
    while True:
        try:
            return await operation()
        except TelegramRetryAfter as exc:
            sleep_seconds = max(1, int(getattr(exc, "retry_after", 1)))
            logger.warning("Telegram asked retry-after=%s seconds", sleep_seconds)
            await asyncio.sleep(sleep_seconds)


def _extract_video_src(media_record: object) -> str:
    if isinstance(media_record, (tuple, list)) and media_record:
        return str(media_record[-1]).strip()
    return str(media_record).strip()


def _extract_video_filename(media_record: object, index: int, source_url: str) -> str:
    if isinstance(media_record, (tuple, list)) and media_record:
        candidate = str(media_record[0]).strip()
        if candidate:
            filename = pathlib.Path(candidate).name
            if "." in filename:
                return filename
            return f"{filename}.mp4"

    parsed_name = pathlib.Path(unquote(urlparse(source_url).path)).name.strip()
    if parsed_name:
        return parsed_name
    return f"video-{index:03d}.mp4"


def _should_fallback_to_document(exc: Exception) -> bool:
    if isinstance(exc, TelegramEntityTooLarge):
        return True

    message = str(exc).lower()
    media_error_tokens = (
        "too large",
        "request entity too large",
        "video content type",
        "wrong file identifier",
        "failed to get http url content",
        "type of file mismatch",
    )
    return any(token in message for token in media_error_tokens)


def _parse_content_range_total(content_range: str | None) -> int | None:
    if not content_range or "/" not in content_range:
        return None

    maybe_total = content_range.rsplit("/", 1)[-1].strip()
    if not maybe_total.isdigit():
        return None
    return int(maybe_total)


async def _probe_remote_file_size(
    video_url: str,
    headers: dict[str, str] | None = None,
) -> int | None:
    timeout = aiohttp.ClientTimeout(total=None, sock_connect=15, sock_read=30)
    base_headers = headers or {}
    async with aiohttp.ClientSession(timeout=timeout, headers=base_headers) as session:
        try:
            async with session.head(video_url, allow_redirects=True) as response:
                content_length = response.headers.get("Content-Length", "").strip()
                if content_length.isdigit():
                    return int(content_length)
        except Exception:
            logger.debug("HEAD size probe failed for %s", video_url)

        try:
            range_headers = dict(base_headers)
            range_headers["Range"] = "bytes=0-0"
            async with session.get(video_url, headers=range_headers, allow_redirects=True) as response:
                content_length = response.headers.get("Content-Length", "").strip()
                if response.status == 200 and content_length.isdigit():
                    return int(content_length)

                total_from_range = _parse_content_range_total(response.headers.get("Content-Range"))
                if total_from_range is not None:
                    return total_from_range
        except Exception:
            logger.debug("Range size probe failed for %s", video_url)

    return None


def _format_size_bytes(size_bytes: int | None) -> str:
    if size_bytes is None:
        return "unknown"
    size_mb = size_bytes / (1024 * 1024)
    return f"{size_mb:.1f}MB"


async def _send_link_only_message(
    bot: Bot,
    channel: str,
    page_title: str,
    video_url: str,
    size_bytes: int | None,
) -> None:
    size_text = _format_size_bytes(size_bytes)
    text = f"{page_title}\nVideo too large for Telegram Bot API upload ({size_text}).\n{video_url}"
    await _run_with_retry_after(lambda: bot.send_message(chat_id=channel, text=text, disable_web_page_preview=True))


async def send_link_message_to_channel(
    channel: str,
    page_title: str,
    video_url: str,
    size_bytes: int | None = None,
) -> bool:
    if not channel.strip():
        logger.warning("Skipping link message send because channel is empty for %s", video_url)
        return False

    bot = Bot(token=BOT_TOKEN)
    async with bot.context():
        try:
            await _send_link_only_message(
                bot=bot,
                channel=channel,
                page_title=page_title,
                video_url=video_url,
                size_bytes=size_bytes,
            )
            return True
        except Exception as exc:
            logger.warning("Failed to send link message for %s: %s", video_url, exc)
            return False


async def send_local_video_to_channel(
    channel: str,
    page_title: str,
    source_url: str,
    local_file_path: pathlib.Path,
    video_filename: str | None = None,
    tqdm_iterable: tqdm | None = None,
) -> bool:
    if not channel.strip():
        logger.warning("Skipping local video send: missing channel for source=%s", source_url)
        return False
    if not local_file_path.exists():
        logger.warning("Skipping local video send: file not found=%s source=%s", local_file_path, source_url)
        return False

    filename = video_filename or local_file_path.name
    _set_progress(tqdm_iterable, f"Sending local video to Telegram channel {channel}")
    bot = Bot(token=BOT_TOKEN)
    async with bot.context():
        try:
            await _run_with_retry_after(
                lambda: bot.send_video(
                    chat_id=channel,
                    video=FSInputFile(path=local_file_path.as_posix(), filename=filename),
                    caption=page_title,
                    supports_streaming=True,
                )
            )
            return True
        except Exception as exc:
            if not _should_fallback_to_document(exc):
                logger.warning("Local send_video failed for source=%s path=%s err=%s", source_url, local_file_path, exc)
                return False
            logger.warning("Local send_video failed; using send_document fallback: %s", exc)
            try:
                await _run_with_retry_after(
                    lambda: bot.send_document(
                        chat_id=channel,
                        document=FSInputFile(path=local_file_path.as_posix(), filename=filename),
                        caption=page_title,
                    )
                )
                return True
            except Exception as fallback_exc:
                logger.warning(
                    "Local send_document fallback failed for source=%s path=%s err=%s",
                    source_url,
                    local_file_path,
                    fallback_exc,
                )
                return False


async def _download_video_to_path(
    video_url: str,
    destination_path: pathlib.Path,
    headers: dict[str, str] | None = None,
) -> pathlib.Path:
    timeout = aiohttp.ClientTimeout(total=None, sock_connect=30, sock_read=120)
    async with aiohttp.ClientSession(timeout=timeout, headers=headers or {}) as session:
        async with session.get(video_url) as response:
            response.raise_for_status()
            async with aiofiles.open(destination_path, "wb") as f:
                async for chunk in response.content.iter_chunked(CHUNK_SIZE):
                    if chunk:
                        await f.write(chunk)

    return destination_path


async def send_videos_to_channel(
    channel: str,
    page_title: str,
    source_url: str,
    ordered_unique_video_urls: IndexedSet,
    headers: dict[str, str] | None = None,
    tqdm_iterable: tqdm | None = None,
) -> VideoDeliveryStats:
    stats = VideoDeliveryStats(
        total_found=len(ordered_unique_video_urls),
        total_after_checkpoint=0,
        sent_count=0,
        skipped_count=0,
        fallback_download_count=0,
        fallback_document_count=0,
        failed_count=0,
    )
    if not channel.strip():
        stats.skipped_count = stats.total_found
        logger.warning("Skipping telegra.ph video send: missing --channel for source=%s", source_url)
        return stats

    checkpoint_service = build_checkpoint_service()
    decision = checkpoint_service.filter_media(
        source_url=source_url,
        ordered_unique_img_urls=IndexedSet(),
        ordered_unique_video_urls=ordered_unique_video_urls,
    )
    videos_to_send = decision.new_videos or IndexedSet()
    stats.total_after_checkpoint = len(videos_to_send)
    stats.skipped_count = decision.skipped_videos_count
    if not videos_to_send:
        _set_progress(tqdm_iterable, f"No new videos for {page_title}; checkpoint skipped send")
        return stats

    _set_progress(
        tqdm_iterable,
        f"Sending {len(videos_to_send)} telegra.ph videos to Telegram channel {channel}",
    )
    sent_records = IndexedSet()
    bot = Bot(token=BOT_TOKEN)
    async with bot.context():
        with tempfile.TemporaryDirectory(prefix="grabber-video-") as temp_dir:
            temp_root = pathlib.Path(temp_dir)
            for index, media_record in enumerate(videos_to_send, start=1):
                video_src = _extract_video_src(media_record)
                if not video_src:
                    logger.warning("Skipping empty video source for page=%s source=%s", page_title, source_url)
                    stats.failed_count += 1
                    continue

                video_filename = _extract_video_filename(media_record, index=index, source_url=video_src)
                caption = page_title
                remote_size_bytes = await _probe_remote_file_size(video_src, headers=headers)

                if remote_size_bytes is not None and remote_size_bytes > BOT_UPLOAD_MAX_BYTES:
                    logger.warning(
                        "Video exceeds Bot API upload limit; sending link only source=%s size=%s",
                        video_src,
                        _format_size_bytes(remote_size_bytes),
                    )
                    try:
                        await _send_link_only_message(
                            bot=bot,
                            channel=channel,
                            page_title=page_title,
                            video_url=video_src,
                            size_bytes=remote_size_bytes,
                        )
                        stats.sent_count += 1
                        stats.link_only_count += 1
                        sent_records.add(media_record)
                    except Exception as exc:
                        stats.failed_count += 1
                        logger.warning("Failed sending oversize link-only fallback for %s: %s", video_src, exc)
                    continue

                can_try_url_input = remote_size_bytes is None or remote_size_bytes <= URL_INPUT_MAX_BYTES

                if can_try_url_input:
                    try:
                        await _run_with_retry_after(
                            lambda: bot.send_video(
                                chat_id=channel,
                                video=URLInputFile(url=video_src, headers=headers or {}, filename=video_filename),
                                caption=caption,
                                supports_streaming=True,
                            )
                        )
                        stats.sent_count += 1
                        sent_records.add(media_record)
                        continue
                    except Exception as exc:
                        logger.warning("URL video send failed; trying temp download fallback: %s", exc)
                else:
                    logger.info(
                        "Skipping URLInputFile due to size >20MB source=%s size=%s",
                        video_src,
                        _format_size_bytes(remote_size_bytes),
                    )

                downloaded_file: pathlib.Path | None = None
                try:
                    downloaded_file = await _download_video_to_path(
                        video_url=video_src,
                        destination_path=temp_root / video_filename,
                        headers=headers,
                    )
                    stats.fallback_download_count += 1

                    downloaded_size_bytes = downloaded_file.stat().st_size
                    if downloaded_size_bytes > BOT_UPLOAD_MAX_BYTES:
                        logger.warning(
                            "Downloaded video exceeds Bot API upload limit; sending link only source=%s size=%s",
                            video_src,
                            _format_size_bytes(downloaded_size_bytes),
                        )
                        await _send_link_only_message(
                            bot=bot,
                            channel=channel,
                            page_title=page_title,
                            video_url=video_src,
                            size_bytes=downloaded_size_bytes,
                        )
                        stats.sent_count += 1
                        stats.link_only_count += 1
                        sent_records.add(media_record)
                        continue

                    try:
                        await _run_with_retry_after(
                            lambda: bot.send_video(
                                chat_id=channel,
                                video=FSInputFile(path=downloaded_file.as_posix(), filename=video_filename),
                                caption=caption,
                                supports_streaming=True,
                            )
                        )
                        stats.sent_count += 1
                        sent_records.add(media_record)
                        continue
                    except Exception as send_file_exc:
                        if not _should_fallback_to_document(send_file_exc):
                            raise
                        logger.warning("send_video from file failed; using send_document fallback: %s", send_file_exc)
                        stats.fallback_document_count += 1
                        await _run_with_retry_after(
                            lambda: bot.send_document(
                                chat_id=channel,
                                document=FSInputFile(path=downloaded_file.as_posix(), filename=video_filename),
                                caption=caption,
                            )
                        )
                        stats.sent_count += 1
                        sent_records.add(media_record)
                        continue
                except Exception as exc:
                    stats.failed_count += 1
                    logger.warning(
                        "Failed sending video for page=%s source=%s file=%s err=%s",
                        page_title,
                        source_url,
                        downloaded_file or video_filename,
                        exc,
                    )

    if sent_records:
        checkpoint_service.commit_media(source_url=source_url, media_records=sent_records)

    _set_progress(
        tqdm_iterable,
        (
            f"Finished telegra.ph video send for {page_title}: "
            f"sent={stats.sent_count} skipped={stats.skipped_count} "
            f"link_only={stats.link_only_count} failed={stats.failed_count}"
        ),
    )
    return stats


__all__ = [
    "VideoDeliveryStats",
    "send_link_message_to_channel",
    "send_local_video_to_channel",
    "send_videos_to_channel",
]
