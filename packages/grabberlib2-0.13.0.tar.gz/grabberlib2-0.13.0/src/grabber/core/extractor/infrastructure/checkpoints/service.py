from __future__ import annotations

import pathlib
from typing import Any

from boltons.setutils import IndexedSet

from grabber.core.settings import (
    CHECKPOINT_ENABLED,
    CHECKPOINT_FILE_PATH,
    CHECKPOINT_MAX_SEEN_PER_SOURCE,
    CHECKPOINT_RECENT_WINDOW,
    CHECKPOINT_SERVER_MODE,
)

from .contracts import CheckpointDecision, SourceCheckpointHint
from .jsonl_store import JsonlMediaCheckpointStore
from .url_normalizer import normalize_source_url


class MediaCheckpointService:
    def __init__(
        self,
        store: JsonlMediaCheckpointStore | None,
        *,
        enabled: bool,
    ) -> None:
        self.store = store
        self.enabled = enabled

    def get_hint(self, source_url: str) -> SourceCheckpointHint:
        source_key = normalize_source_url(source_url)
        if not self.enabled:
            return SourceCheckpointHint(seen_hashes=set(), recent_hashes=set(), updated_at=None)
        if self.store is None:
            return SourceCheckpointHint(seen_hashes=set(), recent_hashes=set(), updated_at=None)
        return self.store.get_hint(source_key)

    def filter_media(
        self,
        source_url: str,
        ordered_unique_img_urls: IndexedSet,
        ordered_unique_video_urls: IndexedSet | None = None,
    ) -> CheckpointDecision:
        if not self.enabled:
            return CheckpointDecision(
                new_images=ordered_unique_img_urls,
                new_videos=ordered_unique_video_urls,
                skipped_images_count=0,
                skipped_videos_count=0,
            )
        if self.store is None:
            return CheckpointDecision(
                new_images=ordered_unique_img_urls,
                new_videos=ordered_unique_video_urls,
                skipped_images_count=0,
                skipped_videos_count=0,
            )

        source_key = normalize_source_url(source_url)
        new_images = self._filter_indexed_set(source_key, ordered_unique_img_urls)
        skipped_images = max(0, len(ordered_unique_img_urls) - len(new_images))

        new_videos: IndexedSet | None = None
        skipped_videos = 0
        if ordered_unique_video_urls is not None:
            new_videos = self._filter_indexed_set(source_key, ordered_unique_video_urls)
            skipped_videos = max(0, len(ordered_unique_video_urls) - len(new_videos))

        return CheckpointDecision(
            new_images=new_images,
            new_videos=new_videos,
            skipped_images_count=skipped_images,
            skipped_videos_count=skipped_videos,
        )

    def commit_media(
        self,
        source_url: str,
        media_records: IndexedSet | None,
    ) -> None:
        if not self.enabled or not media_records:
            return
        if self.store is None:
            return

        source_key = normalize_source_url(source_url)
        urls = self._extract_urls(media_records)
        self.store.commit_seen(source_key, urls)

    def inspect(self, source_url: str) -> dict[str, object]:
        source_key = normalize_source_url(source_url)
        if not self.enabled or self.store is None:
            return {
                "source_key": source_key,
                "seen_count": 0,
                "recent_count": 0,
                "updated_at": None,
            }
        return self.store.inspect_source(source_key)

    def clear(self, source_url: str) -> None:
        if not self.enabled or self.store is None:
            return
        source_key = normalize_source_url(source_url)
        self.store.clear_source(source_key)

    def _filter_indexed_set(self, source_key: str, records: IndexedSet) -> IndexedSet:
        if not records:
            return IndexedSet()

        record_list = list(records)
        urls = [self._extract_url(record) for record in record_list]
        new_urls = set(self.store.filter_new(source_key, urls))

        filtered = IndexedSet()
        for record in record_list:
            media_url = self._extract_url(record)
            if media_url in new_urls:
                filtered.add(record)

        return filtered

    def _extract_urls(self, records: IndexedSet) -> list[str]:
        urls: list[str] = []
        for record in records:
            urls.append(self._extract_url(record))
        return urls

    def _extract_url(self, record: Any) -> str:
        if isinstance(record, (list, tuple)):
            if not record:
                return ""
            maybe_url = record[-1]
            return str(maybe_url)
        return str(record)


_singleton: MediaCheckpointService | None = None


def build_checkpoint_service() -> MediaCheckpointService:
    global _singleton
    if _singleton is None:
        checkpoint_file_path = CHECKPOINT_FILE_PATH.strip()
        is_enabled = CHECKPOINT_ENABLED and CHECKPOINT_SERVER_MODE and bool(checkpoint_file_path)
        store: JsonlMediaCheckpointStore | None = None
        if is_enabled:
            store = JsonlMediaCheckpointStore(
                file_path=pathlib.Path(checkpoint_file_path),
                max_seen_per_source=CHECKPOINT_MAX_SEEN_PER_SOURCE,
                recent_window=CHECKPOINT_RECENT_WINDOW,
            )
        _singleton = MediaCheckpointService(store=store, enabled=is_enabled)
    return _singleton
