"""Shared fixtures for CacheStack tests."""

import pytest
import pytest_asyncio

from cachestack import MemoryBackend, MemoryConfig, TieredCache


@pytest_asyncio.fixture
async def memory_cache():
    cache = MemoryBackend(MemoryConfig(policy="lru", maxsize=128))
    yield cache
    await cache.clear()


@pytest_asyncio.fixture
async def lfu_cache():
    cache = MemoryBackend(MemoryConfig(policy="lfu", maxsize=4))
    yield cache
    await cache.clear()


@pytest_asyncio.fixture
async def tiered_cache():
    l1 = MemoryBackend(MemoryConfig(maxsize=64))
    l2 = MemoryBackend(MemoryConfig(maxsize=256))
    cache = TieredCache([l1, l2])
    yield cache, l1, l2
    await cache.clear()
