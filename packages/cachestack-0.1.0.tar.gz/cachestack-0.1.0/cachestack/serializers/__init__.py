
import json
import pickle
from abc import ABC, abstractmethod
from typing import Any

class SerializationError(Exception):
    pass

class BaseSerializer(ABC):
    @abstractmethod
    def dumps(self, value: Any) -> bytes: ...
    @abstractmethod
    def loads(self, data: bytes) -> Any: ...

class PickleSerializer(BaseSerializer):
    def dumps(self, value: Any) -> bytes:
        return pickle.dumps(value, protocol=pickle.HIGHEST_PROTOCOL)
    def loads(self, data: bytes) -> Any:
        return pickle.loads(data)

class JsonSerializer(BaseSerializer):
    def dumps(self, value: Any) -> bytes:
        return json.dumps(value).encode("utf-8")
    def loads(self, data: bytes) -> Any:
        return json.loads(data.decode("utf-8"))

class MsgpackSerializer(BaseSerializer):
    def dumps(self, value: Any) -> bytes:
        import msgpack
        return msgpack.packb(value, use_bin_type=True)
    def loads(self, data: bytes) -> Any:
        import msgpack
        return msgpack.unpackb(data, raw=False)
