"""
CacheStack — A modern, async-first, multi-backend Python caching library.

Supports Memory, Redis, PostgreSQL, and Memcached backends with a unified API.
Includes tiered caching, stampede protection, and flexible decorators.

Quick start:

    from cachestack import MemoryBackend, cached

    cache = MemoryBackend()

    @cached(cache=cache, ttl=60)
    async def get_data(key: str):
        return await fetch_from_db(key)

Tiered caching:

    from cachestack import TieredCache, MemoryBackend, RedisBackend, RedisConfig

    cache = TieredCache([
        MemoryBackend(),
        RedisBackend(RedisConfig(dsn="redis://localhost")),
    ])
"""

from cachestack.base import (
    BaseCache,
    CacheError,
    BackendUnavailableError,
    SerializationError,
    SyncCacheMixin,
)
from cachestack.backends.memory import MemoryBackend, MemoryConfig
from cachestack.backends.redis import RedisBackend, RedisConfig
from cachestack.backends.postgres import PostgresBackend, PostgresConfig
from cachestack.backends.memcached import MemcachedBackend, MemcachedConfig
from cachestack.backends.file import FileBackend, FileConfig
from cachestack.tiered import TieredCache, WriteStrategy
from cachestack.decorators import cached, invalidate
from cachestack.serializers import (
    BaseSerializer,
    PickleSerializer,
    JsonSerializer,
    MsgpackSerializer,
)

__version__ = "0.1.0"
__author__ = "Sarthak Bhatkar"
__license__ = "MIT"

__all__ = [
    # Core
    "BaseCache",
    "CacheError",
    "BackendUnavailableError",
    "SerializationError",
    "SyncCacheMixin",
    # Backends
    "MemoryBackend",
    "MemoryConfig",
    "RedisBackend",
    "RedisConfig",
    "PostgresBackend",
    "PostgresConfig",
    "MemcachedBackend",
    "MemcachedConfig",
    "FileBackend",
    "FileConfig",
    # Tiered
    "TieredCache",
    "WriteStrategy",
    # Decorators
    "cached",
    "invalidate",
    # Serializers
    "BaseSerializer",
    "PickleSerializer",
    "JsonSerializer",
    "MsgpackSerializer",
]
