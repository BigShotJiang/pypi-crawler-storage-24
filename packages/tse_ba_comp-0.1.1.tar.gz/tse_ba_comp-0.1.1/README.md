# tse_ba_comp

A robust Python library for estimating Biological Age (BA) from clinical biomarkers. 

Developed by Mehrdad S. Beni & Gary Tse, this package evaluates and ensembles classical approaches (KDM, PCA-Dubina) against Machine Learning models (Elastic Net, Random Forest, XGBoost).

## Installation

Navigate to the project root directory and install via pip:

```bash
pip install .
```

## Basic Usage

You can pass a CSV file path or a Pandas DataFrame directly to the `run_pipeline` function.

```python
import tse_ba_comp

my_biomarkers = ["albumin", "alp", "bun", "creat", "hba1c", "glucose", "sbp"]

results = tse_ba_comp.run_pipeline(
    data="nhanes4_model_input.csv",
    age_col="age",
    biomarkers=my_biomarkers,
    out_dir="my_results_folder"
)

print(results["metrics"])
```

## Advanced Control & Hyperparameters

`tse_ba_comp` gives you complete programmatic control over model behavior. 

You can structure a dictionary (`ml_params`) to turn specific models on/off, set fixed parameters, or trigger an automated Grid Search over specific hyperparameter ranges.

```python
import tse_ba_comp

my_biomarkers = [
    "albumin", "alp", "bun", "creat", "hba1c", "lncrp",
    "lymph", "mcv", "glucose", "rdw", "totchol", "wbc", "sbp"
]

# Configure Machine Learning Behavior
ml_settings = {
    "grid_search": True,
    "cv_folds": 5,
    "elastic_net": {
        "run": True,
        "param_grid": {"alpha": [0.1, 1.0], "l1_ratio": [0.1, 0.5, 0.9]}
    },
    "random_forest": {
        "run": True,
        "param_grid": {"n_estimators": [100, 200], "max_depth": [None, 10]}
    },
    "xgboost": {
        "run": False  # Skip XGBoost
    }
}

results = tse_ba_comp.run_pipeline(
    data="nhanes4_model_input.csv",
    age_col="age",
    biomarkers=my_biomarkers,
    imputation_method="knn",       # Switch imputation to KNN
    test_size=0.3,                 # 30% holdout for testing
    random_state=101,              # Lock seed for reproducibility
    run_pca_model=False,           # Turn off PCA-Dubina entirely
    kdm_s2_floor=0.05,             # Tweak KDM variance floor
    ml_params=ml_settings,         # Apply ML settings
    ensemble_method="mean",        # Use Arithmetic Mean for Ensemble
    out_dir="advanced_results"
)

print(results["metrics"])
```

## Complete Parameter Reference

Below is a complete list of arguments you can pass to the `run_pipeline` function.

### Core Data Settings
* `data` (str or pandas.DataFrame): Path to your CSV file, or a loaded Pandas DataFrame.
* `biomarkers` (list of str): List of column names representing the biomarkers to be used.
* `age_col` (str): The column name containing chronological age. Default: `age`.

### Processing & Splitting
* `imputation_method` (str): How to handle missing data. Options: `median`, `mean`, `zero`, `knn`. Default: `median`.
* `test_size` (float): The fraction of the dataset to hold out for testing and evaluation. Default: `0.2` (20%).
* `random_state` (int): Random seed to ensure reproducible train/test splits. Default: `42`.

### Classical Model Toggles
* `run_kdm_model` (bool): Toggle the Klemera-Doubal Method. Default: `True`.
* `kdm_s2_floor` (float): Minimum variance floor for KDM calculations to prevent division by near-zero. Default: `0.1`.
* `run_pca_model` (bool): Toggle the PCA-Dubina method. Default: `True`.

### Machine Learning Settings
* `run_ml_models_flag` (bool): Toggle all Machine Learning models. Default: `True`.
* `cv_folds` (int): Number of cross-validation folds used during training. Default: `5`.
* `ml_params` (dict): A nested dictionary to configure specific ML models. If `None`, fast default settings are used. See the "ML Parameter Dictionary Structure" below.

### Ensemble & Outputs
* `ensemble_method` (str or None): How to combine the model predictions. Options: `median`, `mean`, or `None` (to skip ensemble). Default: `median`.
* `out_dir` (str or None): Directory path to save the generated scatter plots and prediction CSVs. If `None`, no files are saved to the disk.

---

## ML Parameter Dictionary Structure

When passing a dictionary to `ml_params`, you can use the following structure. If `grid_search` is `True`, the models will ignore static parameters and hunt for the best options inside the `param_grid`.

```python
{
    "grid_search": False,  # Set to True to enable hyperparameter tuning
    "cv_folds": 5,         # Cross-validation folds
    
    "elastic_net": {
        "run": True,
        "l1_ratio": 0.5,   # Used if grid_search is False
        "param_grid": {}   # Add lists of parameters here if grid_search is True
    },
    
    "random_forest": {
        "run": True,
        "n_estimators": 100, # Used if grid_search is False
        "max_depth": None,   # Used if grid_search is False
        "param_grid": {}
    },
    
    "xgboost": {
        "run": True,
        "n_estimators": 100, # Used if grid_search is False
        "learning_rate": 0.1,# Used if grid_search is False
        "max_depth": 6,      # Used if grid_search is False
        "param_grid": {}
    }
}
```

## Outputs

The `run_pipeline` function returns a dictionary with two keys:

1. `results["metrics"]`: A Pandas DataFrame containing the Pearson r, R², RMSE, and MAE for all executed models evaluated strictly on the test set.
2. `results["predictions"]`: A Pandas DataFrame mapping the Chronological Age to the estimated Biological Ages for every patient in the test set.
