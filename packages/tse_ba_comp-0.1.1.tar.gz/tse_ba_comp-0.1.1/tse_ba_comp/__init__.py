from .core import run_pipeline

__version__ = "0.1.1"
