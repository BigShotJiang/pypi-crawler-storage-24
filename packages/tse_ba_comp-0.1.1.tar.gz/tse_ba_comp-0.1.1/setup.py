from setuptools import setup, find_packages

setup(
    name="tse_ba_comp",
    version="0.1.1",
    description="A library for estimating Biological Age using classical and ML methods",
    author="Mehrdad S. Beni & Gary Tse",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "scikit-learn",
        "xgboost",
        "matplotlib",
        "scipy"
    ],
    python_requires='>=3.7',
)
