# debugger-help

Deep VPS monitoring agent for [debugger.help](https://debugger.help). Captures PM2, GPU metrics, Docker containers, system health, and streams everything to your dashboard in real time.

## Install

```bash
pip install debugger-help
```

With GPU monitoring:
```bash
pip install debugger-help[gpu]
```

With everything:
```bash
pip install debugger-help[all]
```

## Quick Start

```bash
export DEBUGGER_API_KEY="your-api-key"
export DEBUGGER_INGEST_URL="your-ingest-url"
debugger-agent
```

Or keep it running with PM2:
```bash
pm2 start "debugger-agent" --name debugger-agent
pm2 save
```

## What it captures

- PM2 process states, restart counts, logs, error logs
- GPU: VRAM per-process, temperature, power, utilization, clock speeds, throttle reasons, ECC errors
- CPU: per-core usage, load average, frequency, context switches
- Memory: RAM, swap, shared, buffers, cached
- Disk: usage per mount, I/O rates, inode usage
- Network: per-interface stats, TCP connection states, open ports, DNS resolution
- Processes: top CPU/memory consumers, zombies, open file descriptors
- Docker containers: status, CPU, memory, restart counts
- Systemd: failed units
- SSL certificates: expiry checks
- System logs: dmesg, OOM kills, journalctl errors
- File watchers: syslog, PM2 logs, custom log files

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DEBUGGER_API_KEY` | Yes | Your debugger.help API key |
| `DEBUGGER_INGEST_URL` | Yes | Your ingest endpoint URL |
| `DEBUGGER_SOURCE` | No | Source name (default: `vps-{hostname}`) |
| `DEBUGGER_INTERVAL` | No | Collection interval in seconds (default: `10`) |
| `DEBUGGER_WATCH_LOGS` | No | Comma-separated extra log file paths |
| `DEBUGGER_SSL_DOMAINS` | No | Comma-separated domains for SSL checks |

## License

MIT
