"""debugger.help VPS Agent — Deep system monitoring."""
__version__ = "3.0.0"
