"""
simple_params_groups.py
=======================
Demonstrates the advanced features of Paramify:
  - type: group  with inline nested parameters
  - include:     loading parameters from an external YAML file
  - value:       keyword (C++ compat; 'default:' is also accepted)
  - double / string  type aliases (C++ compat)
  - list[int] / list[string]  typed lists
  - scope: runtime  (excluded from CLI, accessible at runtime)
  - save_as()    exporting current state to a new YAML file
  - Dot-notation callbacks and setters for nested parameters
"""

from paramify import Paramify


class MyApp(Paramify):

    # Top-level callbacks
    def on_enabled_set(self, value):
        print(f"[callback] enabled → {value}")

    def on_sample_rate_set(self, value):
        print(f"[callback] sample_rate → {value}")

    def on_channels_set(self, value):
        print(f"[callback] channels → {value}")

    # Nested group callbacks  (dots replaced by underscores)
    def on_audio_volume_set(self, value):
        print(f"[callback] audio.volume → {value}")

    def on_audio_mute_set(self, value):
        print(f"[callback] audio.mute → {value}")

    # Parameters from the included camera YAML
    def on_camera_enabled_set(self, value):
        print(f"[callback] camera.enabled → {value}")

    def on_camera_gain_set(self, value):
        print(f"[callback] camera.gain → {value}")


if __name__ == '__main__':
    app = MyApp('config_groups.yaml')

    print(app)   # formatted overview
    print()

    # --- Flat (top-level) access ---
    print("enabled:    ", app.parameters.enabled)
    print("sample_rate:", app.parameters.sample_rate)
    print("channels:   ", app.parameters.channels)

    # --- Nested namespace access ---
    print("audio.volume:", app.parameters.audio.volume)
    print("audio.mute:  ", app.parameters.audio.mute)
    print("camera.enabled:", app.parameters.camera.enabled)
    print("camera.gain:   ", app.parameters.camera.gain)

    # runtime-only parameter (not exposed to CLI)
    print("codec (runtime):", app.parameters.codec)

    print()

    # --- Update via setters (trigger callbacks + persistence) ---
    app.set_sample_rate(48000.0)        # double setter
    app.set_channels([1, 2, 3, 4])      # list[int] setter
    app.set_audio_volume(0.5)           # nested setter
    app.set_audio_mute(True)            # nested setter
    app.set_camera_enabled(False)       # included-file param setter
    app.set_camera_gain(2.5)            # double setter in included file

    print()
    print("All parameters (flat dict):")
    for key, val in app.get_parameters().items():
        print(f"  {key}: {val}")

    print()

    # --- save_as: export current state to a new file ---
    app.save_as('/tmp/config_groups_saved.yaml')
    print("Saved current state to /tmp/config_groups_saved.yaml")
