"""
Tests for the 7 features added to align paramify-python with paramify-cpp:

  1. Groups / nested parameters (inline)
  2. YAML includes
  3. value: keyword (preferred over default:)
  4. Typed lists  (list[bool], list[int], list[float], list[double],
                   list[str], list[string])
  5. double / string type aliases
  6. scope: runtime  (excluded from CLI, accessible at runtime)
  7. save_as(path)
"""

import os
import unittest
import tempfile

from ruamel.yaml import YAML


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_yaml(content: str, suffix=".yaml") -> str:
    """Write *content* to a temp YAML file and return its path."""
    f = tempfile.NamedTemporaryFile(
        mode='w', suffix=suffix, delete=False, encoding='utf-8')
    f.write(content)
    f.close()
    return f.name


# ---------------------------------------------------------------------------
# 1. Inline groups
# ---------------------------------------------------------------------------

class TestGroups(unittest.TestCase):

    def setUp(self):
        self.config = {
            "parameters": [
                {"name": "top", "type": "int", "default": 1},
                {
                    "name": "camera",
                    "type": "group",
                    "parameters": [
                        {"name": "enabled", "type": "bool",   "default": True},
                        {"name": "fps",     "type": "int",    "default": 30},
                        {
                            "name": "isp",
                            "type": "group",
                            "parameters": [
                                {"name": "gain", "type": "float", "default": 2.0},
                            ],
                        },
                    ],
                },
            ]
        }

    def _make(self):
        from paramify import Paramify
        return Paramify(self.config, enable_cli=False)

    def test_flat_keys_in_get_parameters(self):
        app = self._make()
        params = app.get_parameters()
        self.assertIn("top", params)
        self.assertIn("camera.enabled", params)
        self.assertIn("camera.fps", params)
        self.assertIn("camera.isp.gain", params)

    def test_nested_namespace_access(self):
        app = self._make()
        self.assertTrue(app.parameters.camera.enabled)
        self.assertEqual(app.parameters.camera.fps, 30)
        self.assertEqual(app.parameters.camera.isp.gain, 2.0)

    def test_setter_uses_underscores(self):
        app = self._make()
        self.assertTrue(hasattr(app, "set_camera_enabled"))
        self.assertTrue(hasattr(app, "set_camera_fps"))
        self.assertTrue(hasattr(app, "set_camera_isp_gain"))

    def test_setter_updates_value(self):
        app = self._make()
        app.set_camera_fps(60)
        self.assertEqual(app.get_parameters()["camera.fps"], 60)
        self.assertEqual(app.parameters.camera.fps, 60)

    def test_type_error_on_bad_nested_value(self):
        app = self._make()
        with self.assertRaises(TypeError):
            app.set_camera_fps("not_an_int")

    def test_callback_fires_for_nested_param(self):
        from paramify import Paramify

        fired = []

        class App(Paramify):
            def on_camera_enabled_set(self, value):
                fired.append(value)

        app = App(self.config, enable_cli=False)
        app.set_camera_enabled(False)
        self.assertEqual(fired, [False])

    def test_no_group_entry_in_get_parameters(self):
        """Groups themselves must NOT appear as keys – only their leaf children."""
        app = self._make()
        params = app.get_parameters()
        self.assertNotIn("camera", params)
        self.assertNotIn("camera.isp", params)


# ---------------------------------------------------------------------------
# 2. YAML includes
# ---------------------------------------------------------------------------

class TestYAMLIncludes(unittest.TestCase):

    def _make_files(self):
        tmpdir = tempfile.mkdtemp()
        sub_name = "sub.yaml"
        sub_yaml = os.path.join(tmpdir, sub_name)
        with open(sub_yaml, 'w') as f:
            f.write(
                "parameters:\n"
                "  - name: gain\n"
                "    type: float\n"
                "    value: 3.0\n"
                "  - name: mute\n"
                "    type: bool\n"
                "    value: false\n"
            )

        main_yaml = os.path.join(tmpdir, "main.yaml")
        with open(main_yaml, 'w') as f:
            f.write(
                "parameters:\n"
                "  - name: top\n"
                "    type: int\n"
                "    value: 7\n"
                "  - name: audio\n"
                "    type: group\n"
                f"    include: \"{sub_name}\"\n"
            )
        return main_yaml, sub_yaml

    def tearDown(self):
        pass

    def test_included_params_visible(self):
        from paramify import Paramify
        main, sub = self._make_files()
        try:
            app = Paramify(main, enable_cli=False)
            params = app.get_parameters()
            self.assertIn("audio.gain", params)
            self.assertIn("audio.mute", params)
            self.assertEqual(params["audio.gain"], 3.0)
            self.assertFalse(params["audio.mute"])
        finally:
            os.unlink(main)
            os.unlink(sub)

    def test_included_setter_works(self):
        from paramify import Paramify
        main, sub = self._make_files()
        try:
            app = Paramify(main, enable_cli=False)
            app.set_audio_gain(5.0)
            self.assertEqual(app.parameters.audio.gain, 5.0)
        finally:
            os.unlink(main)
            os.unlink(sub)

    def test_circular_include_raises(self):
        from paramify import Paramify
        # A file that includes itself
        path = _write_yaml("")   # placeholder to get a path
        fname = os.path.basename(path)
        with open(path, 'w') as f:
            f.write(
                "parameters:\n"
                "  - name: self_ref\n"
                "    type: group\n"
                f"    include: \"{fname}\"\n"
            )
        try:
            with self.assertRaises(ValueError):
                Paramify(path, enable_cli=False)
        finally:
            os.unlink(path)

    def test_absolute_path_in_include_raises(self):
        from paramify import Paramify
        path = _write_yaml(
            "parameters:\n"
            "  - name: g\n"
            "    type: group\n"
            "    include: \"/etc/passwd\"\n"
        )
        try:
            with self.assertRaises(ValueError):
                Paramify(path, enable_cli=False)
        finally:
            os.unlink(path)

    def test_included_file_saved_on_change(self):
        from paramify import Paramify
        main, sub = self._make_files()
        try:
            app = Paramify(main, enable_cli=False)
            app.set_audio_gain(9.9)
            # Reload sub-file and verify gain was written
            yaml = YAML()
            with open(sub, 'r') as f:
                data = yaml.load(f)
            gains = {p['name']: p.get('value', p.get('default'))
                     for p in data['parameters']}
            self.assertAlmostEqual(gains['gain'], 9.9)
        finally:
            os.unlink(main)
            os.unlink(sub)


# ---------------------------------------------------------------------------
# 3. value: keyword (preferred over default:)
# ---------------------------------------------------------------------------

class TestValueKeyword(unittest.TestCase):

    def test_value_used_when_present(self):
        from paramify import Paramify
        config = {"parameters": [
            {"name": "x", "type": "int", "value": 99, "default": 1},
        ]}
        app = Paramify(config, enable_cli=False)
        self.assertEqual(app.get_parameters()["x"], 99)

    def test_default_used_as_fallback(self):
        from paramify import Paramify
        config = {"parameters": [
            {"name": "x", "type": "int", "default": 42},
        ]}
        app = Paramify(config, enable_cli=False)
        self.assertEqual(app.get_parameters()["x"], 42)

    def test_value_in_yaml_file(self):
        from paramify import Paramify
        path = _write_yaml(
            "parameters:\n"
            "  - name: x\n"
            "    type: int\n"
            "    value: 77\n"
        )
        try:
            app = Paramify(path, enable_cli=False)
            self.assertEqual(app.get_parameters()["x"], 77)
        finally:
            os.unlink(path)

    def test_save_writes_value_key(self):
        """After a change, 'value:' in the YAML must be updated."""
        from paramify import Paramify
        path = _write_yaml(
            "parameters:\n"
            "  - name: x\n"
            "    type: int\n"
            "    value: 1\n"
        )
        try:
            app = Paramify(path, enable_cli=False)
            app.set_x(55)
            yaml = YAML()
            with open(path, 'r') as f:
                data = yaml.load(f)
            self.assertEqual(data['parameters'][0]['value'], 55)
        finally:
            os.unlink(path)


# ---------------------------------------------------------------------------
# 4. Typed lists
# ---------------------------------------------------------------------------

class TestTypedLists(unittest.TestCase):

    def _app(self, type_str, default):
        from paramify import Paramify
        return Paramify(
            {"parameters": [{"name": "v", "type": type_str, "default": default}]},
            enable_cli=False,
        )

    # --- list[bool] ---
    def test_list_bool_valid(self):
        app = self._app("list[bool]", [True, False])
        self.assertEqual(app.get_parameters()["v"], [True, False])

    def test_list_bool_rejects_int(self):
        with self.assertRaises(ValueError):
            self._app("list[bool]", [1, 0])   # ints not accepted for list[bool]

    def test_list_bool_setter(self):
        app = self._app("list[bool]", [True])
        app.set_v([False, True, False])
        self.assertEqual(app.parameters.v, [False, True, False])

    # --- list[int] ---
    def test_list_int_valid(self):
        app = self._app("list[int]", [1, 2, 3])
        self.assertEqual(app.get_parameters()["v"], [1, 2, 3])

    def test_list_int_rejects_bool(self):
        with self.assertRaises(ValueError):
            self._app("list[int]", [True, False])

    def test_list_int_setter_type_error(self):
        app = self._app("list[int]", [1])
        with self.assertRaises(TypeError):
            app.set_v(["a", "b"])

    # --- list[float] ---
    def test_list_float_valid(self):
        app = self._app("list[float]", [1.0, 2.5])
        self.assertAlmostEqual(app.get_parameters()["v"][1], 2.5)

    def test_list_float_widens_int(self):
        """Integers in list[float] must be silently widened to float."""
        app = self._app("list[float]", [1, 2])
        for val in app.get_parameters()["v"]:
            self.assertIsInstance(val, float)

    # --- list[double] (alias for list[float]) ---
    def test_list_double_alias(self):
        app = self._app("list[double]", [3.14, 2.72])
        self.assertAlmostEqual(app.get_parameters()["v"][0], 3.14)

    # --- list[str] ---
    def test_list_str_valid(self):
        app = self._app("list[str]", ["hello", "world"])
        self.assertEqual(app.get_parameters()["v"], ["hello", "world"])

    def test_list_str_rejects_int(self):
        with self.assertRaises(ValueError):
            self._app("list[str]", [1, 2])

    # --- list[string] (alias for list[str]) ---
    def test_list_string_alias(self):
        app = self._app("list[string]", ["a", "b"])
        self.assertEqual(app.get_parameters()["v"], ["a", "b"])

    # --- untyped list (backward compat) ---
    def test_untyped_list(self):
        app = self._app("list", ["x", 1, True])
        self.assertEqual(len(app.get_parameters()["v"]), 3)


# ---------------------------------------------------------------------------
# 5. double / string type aliases
# ---------------------------------------------------------------------------

class TestTypeAliases(unittest.TestCase):

    def test_double_accepted(self):
        from paramify import Paramify
        app = Paramify(
            {"parameters": [{"name": "g", "type": "double", "default": 1.5}]},
            enable_cli=False,
        )
        self.assertAlmostEqual(app.get_parameters()["g"], 1.5)

    def test_double_int_widening(self):
        from paramify import Paramify
        app = Paramify(
            {"parameters": [{"name": "g", "type": "double", "default": 1.5}]},
            enable_cli=False,
        )
        app.set_g(2)    # int → float widening must succeed
        self.assertAlmostEqual(app.parameters.g, 2.0)
        self.assertIsInstance(app.parameters.g, float)

    def test_double_rejects_bool(self):
        from paramify import Paramify
        app = Paramify(
            {"parameters": [{"name": "g", "type": "double", "default": 1.0}]},
            enable_cli=False,
        )
        with self.assertRaises(TypeError):
            app.set_g(True)

    def test_string_accepted(self):
        from paramify import Paramify
        app = Paramify(
            {"parameters": [{"name": "s", "type": "string", "default": "hi"}]},
            enable_cli=False,
        )
        self.assertEqual(app.get_parameters()["s"], "hi")

    def test_string_setter(self):
        from paramify import Paramify
        app = Paramify(
            {"parameters": [{"name": "s", "type": "string", "default": "hi"}]},
            enable_cli=False,
        )
        app.set_s("hello world")
        self.assertEqual(app.parameters.s, "hello world")

    def test_string_type_error(self):
        from paramify import Paramify
        app = Paramify(
            {"parameters": [{"name": "s", "type": "string", "default": "hi"}]},
            enable_cli=False,
        )
        with self.assertRaises(TypeError):
            app.set_s(42)


# ---------------------------------------------------------------------------
# 6. scope: runtime
# ---------------------------------------------------------------------------

class TestScopeRuntime(unittest.TestCase):

    def setUp(self):
        self.config = {
            "description": "test",
            "parameters": [
                {"name": "a", "type": "int",  "default": 1, "scope": "all"},
                {"name": "b", "type": "int",  "default": 2, "scope": "cli"},
                {"name": "c", "type": "int",  "default": 3, "scope": "runtime"},
                {"name": "d", "type": "int",  "default": 4},   # default → all
            ]
        }

    def test_runtime_param_accessible(self):
        from paramify import Paramify
        app = Paramify(self.config, enable_cli=False)
        self.assertEqual(app.get_parameters()["c"], 3)

    def test_runtime_param_settable(self):
        from paramify import Paramify
        app = Paramify(self.config, enable_cli=False)
        app.set_c(99)
        self.assertEqual(app.get_parameters()["c"], 99)

    def test_runtime_param_has_no_cli_arg(self):
        """scope: runtime must NOT produce a CLI argument."""
        from paramify import Paramify
        app = Paramify(self.config, enable_cli=True)
        cli_dests = {action.dest for action in app.parser._actions}
        self.assertNotIn("c", cli_dests)

    def test_all_and_cli_params_have_cli_args(self):
        from paramify import Paramify
        app = Paramify(self.config, enable_cli=True)
        cli_dests = {action.dest for action in app.parser._actions}
        self.assertIn("a", cli_dests)
        self.assertIn("b", cli_dests)
        self.assertIn("d", cli_dests)

    def test_invalid_scope_raises(self):
        from paramify import Paramify
        bad = {"parameters": [
            {"name": "x", "type": "int", "default": 1, "scope": "invalid"}
        ]}
        with self.assertRaises(ValueError):
            Paramify(bad, enable_cli=False)


# ---------------------------------------------------------------------------
# 7. save_as
# ---------------------------------------------------------------------------

class TestSaveAs(unittest.TestCase):

    def test_save_as_creates_file(self):
        from paramify import Paramify
        src = _write_yaml(
            "parameters:\n"
            "  - name: x\n"
            "    type: int\n"
            "    value: 1\n"
        )
        dst = src + "_copy.yaml"
        try:
            app = Paramify(src, enable_cli=False)
            app.set_x(42)
            app.save_as(dst)
            self.assertTrue(os.path.exists(dst))
            yaml = YAML()
            with open(dst, 'r') as f:
                data = yaml.load(f)
            self.assertEqual(data['parameters'][0]['value'], 42)
        finally:
            os.unlink(src)
            if os.path.exists(dst):
                os.unlink(dst)

    def test_save_as_preserves_structure(self):
        from paramify import Paramify
        src = _write_yaml(
            "name: MyApp\n"
            "parameters:\n"
            "  - name: enabled\n"
            "    type: bool\n"
            "    value: true\n"
            "  - name: camera\n"
            "    type: group\n"
            "    parameters:\n"
            "      - name: fps\n"
            "        type: int\n"
            "        value: 30\n"
        )
        dst = src + "_out.yaml"
        try:
            app = Paramify(src, enable_cli=False)
            app.set_camera_fps(60)
            app.save_as(dst)
            yaml = YAML()
            with open(dst, 'r') as f:
                data = yaml.load(f)
            # Top-level structure preserved
            self.assertEqual(data['name'], 'MyApp')
            # Group structure preserved; inline fps updated
            group = next(p for p in data['parameters'] if p['name'] == 'camera')
            fps_param = next(p for p in group['parameters'] if p['name'] == 'fps')
            self.assertEqual(fps_param['value'], 60)
        finally:
            os.unlink(src)
            if os.path.exists(dst):
                os.unlink(dst)

    def test_save_as_requires_yaml_source(self):
        from paramify import Paramify
        app = Paramify(
            {"parameters": [{"name": "x", "type": "int", "default": 1}]},
            enable_cli=False,
        )
        with self.assertRaises(ValueError):
            app.save_as("/tmp/should_fail.yaml")


if __name__ == "__main__":
    unittest.main()
