# Version
__version__ = "0.2.0"

from paramify.core import Paramify

__all__ = ["Paramify"]
