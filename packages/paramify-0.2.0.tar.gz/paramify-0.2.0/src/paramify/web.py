import os
import sys
import json
import traceback
import threading
from typing import Any, Dict, Union
from bottle import Bottle, request, response, static_file

from paramify.core import Paramify


class ParamifyWeb(Paramify):
    def __init__(self,
                 config: Union[Dict[str, Any], str],
                 enable_cli: bool = True,
                 host: str = '0.0.0.0',
                 port: int = 5000):
        """
        Initialize the ParamifyWeb class, set up the Bottle app, and start the server in a separate thread.
        """
        super().__init__(config, enable_cli)
        self.host = host
        self.port = port

        self._base_dir = os.path.dirname(os.path.abspath(__file__))
        self._static_dir = os.path.join(self._base_dir, 'static')

        self.app = Bottle()
        self._setup_routes()
        self._start_server()

    def _setup_routes(self):
        """
        Define Bottle routes for serving the Vue app and handling parameter updates.
        """

        @self.app.route('/')
        @self.app.route('/<path:path>')
        def serve_frontend(path=None):
            if path and os.path.exists(os.path.join(self._static_dir, path)):
                return static_file(path, root=self._static_dir)
            return static_file('index.html', root=self._static_dir)

        @self.app.route('/api/config', method='GET')
        def get_config():
            # Build a flat parameter list from _param_defs so that
            # grouped and included parameters are all exposed correctly.
            flat_params = []
            for key, defn in self._param_defs.items():
                if defn['scope'] == 'cli':
                    continue
                entry = {
                    'name':        key,
                    'type':        defn['type'],
                    'scope':       defn['scope'],
                    'label':       defn.get('label', ''),
                    'description': defn.get('description', ''),
                    'default':     self._param_values.get(key),
                }
                if defn.get('ui'):
                    entry['ui'] = defn['ui']
                flat_params.append(entry)

            config_out = {
                'name':        self._config.get('name', ''),
                'description': self._config.get('description', ''),
                'parameters':  flat_params,
            }
            response.content_type = 'application/json'
            return json.dumps(config_out)

        @self.app.route('/api/update', method='POST')
        def update_parameter():
            try:
                body = request.body.read()
                data = json.loads(body) if body else None
            except Exception:
                data = None

            if not data or not isinstance(data, dict):
                response.status = 400
                response.content_type = 'application/json'
                return json.dumps({"status": "error", "message": "Invalid request format. Expected a dictionary."})

            try:
                for name, value in data.items():
                    # Frontend sends dotted keys (e.g. "camera.enabled");
                    # setters use underscores ("set_camera_enabled").
                    safe_name = name.replace('.', '_')
                    setter = getattr(self, f"set_{safe_name}", None)
                    if not setter:
                        response.status = 404
                        response.content_type = 'application/json'
                        return json.dumps({"status": "error", "message": f"Parameter '{name}' does not exist or has no setter"})
                    setter(value)

                response.content_type = 'application/json'
                return json.dumps({"status": "success", "message": "Parameters updated successfully"})
            except Exception as e:
                traceback.print_exc(file=sys.stderr)
                response.status = 400
                response.content_type = 'application/json'
                return json.dumps({"status": "error", "message": str(e)})

    def _start_server(self):
        """
        Start the Bottle app in a separate thread to avoid blocking the main thread.
        """
        server_thread = threading.Thread(
            target=self.app.run,
            kwargs={"host": self.host, "port": self.port, "quiet": True},
            daemon=True
        )
        server_thread.start()
