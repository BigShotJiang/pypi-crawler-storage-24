import os
import json
import argparse
from ruamel.yaml import YAML
from typing import Any, Dict, List, Optional, Set, Union


# ---------------------------------------------------------------------------
# Type system  (C++-compatible names accepted alongside Python names)
# ---------------------------------------------------------------------------

_SCALAR_TYPES: Dict[str, type] = {
    'bool':   bool,
    'int':    int,
    'float':  float,
    'double': float,   # C++ compat alias
    'str':    str,
    'string': str,     # C++ compat alias
}

_LIST_ELEM_TYPES: Dict[str, Optional[type]] = {
    'list':          None,   # untyped – backward compat
    'list[bool]':    bool,
    'list[int]':     int,
    'list[float]':   float,
    'list[double]':  float,  # C++ compat alias
    'list[str]':     str,
    'list[string]':  str,    # C++ compat alias
}

_VALID_SCOPES = {'all', 'cli', 'runtime'}


def _validate_value(name: str, value: Any, type_str: str) -> Any:
    """Validate *value* against *type_str*; return the (possibly coerced) value."""
    if type_str in _SCALAR_TYPES:
        py_type = _SCALAR_TYPES[type_str]
        if py_type is bool:
            if not isinstance(value, bool):
                raise TypeError(
                    f"Parameter '{name}': expected bool, got {type(value).__name__}")
            return value
        if py_type is int:
            # bool is a subclass of int in Python – reject it explicitly
            if isinstance(value, bool) or not isinstance(value, int):
                raise TypeError(
                    f"Parameter '{name}': expected int, got {type(value).__name__}")
            return value
        if py_type is float:
            if isinstance(value, bool):
                raise TypeError(
                    f"Parameter '{name}': expected float/double, got bool")
            if isinstance(value, int):          # int → float widening (matches C++)
                return float(value)
            if not isinstance(value, float):
                raise TypeError(
                    f"Parameter '{name}': expected float/double, got {type(value).__name__}")
            return value
        if py_type is str:
            if not isinstance(value, str):
                raise TypeError(
                    f"Parameter '{name}': expected string, got {type(value).__name__}")
            return value

    if type_str in _LIST_ELEM_TYPES:
        if not isinstance(value, list):
            raise TypeError(
                f"Parameter '{name}': expected list, got {type(value).__name__}")
        elem_type = _LIST_ELEM_TYPES[type_str]
        if elem_type is None:
            return list(value)   # untyped – accept as-is
        result = []
        for i, item in enumerate(value):
            if elem_type is bool:
                if not isinstance(item, bool):
                    raise TypeError(
                        f"Parameter '{name}[{i}]': expected bool, "
                        f"got {type(item).__name__}")
                result.append(item)
            elif elem_type is int:
                if isinstance(item, bool) or not isinstance(item, int):
                    raise TypeError(
                        f"Parameter '{name}[{i}]': expected int, "
                        f"got {type(item).__name__}")
                result.append(item)
            elif elem_type is float:
                if isinstance(item, bool):
                    raise TypeError(
                        f"Parameter '{name}[{i}]': expected float, got bool")
                if isinstance(item, int):
                    result.append(float(item))
                elif not isinstance(item, float):
                    raise TypeError(
                        f"Parameter '{name}[{i}]': expected float, "
                        f"got {type(item).__name__}")
                else:
                    result.append(item)
            elif elem_type is str:
                if not isinstance(item, str):
                    raise TypeError(
                        f"Parameter '{name}[{i}]': expected string, "
                        f"got {type(item).__name__}")
                result.append(item)
        return result

    raise ValueError(f"Unknown type '{type_str}' for parameter '{name}'")


# ---------------------------------------------------------------------------
# ParameterNamespace – nested attribute access  (params.camera.enabled)
# ---------------------------------------------------------------------------

class ParameterNamespace:
    """Hierarchical namespace mirroring the group structure of parameters."""

    def dict(self) -> Dict[str, Any]:
        """Return a flat dict with dot-notation keys."""
        result: Dict[str, Any] = {}
        for k, v in vars(self).items():
            if isinstance(v, ParameterNamespace):
                for sk, sv in v.dict().items():
                    result[f"{k}.{sk}"] = sv
            else:
                result[k] = v
        return result


# ---------------------------------------------------------------------------
# Paramify
# ---------------------------------------------------------------------------

class Paramify:
    def __init__(self, config: Union[Dict[str, Any], str], enable_cli: bool = True):
        """
        Initialise Paramify from a dict, JSON file, or YAML file.

        YAML features (compatible with paramify-cpp):
          - type: group  with nested  parameters:  or  include: <file>
          - value: (preferred) or default: for parameter values
          - types: bool | int | float | double | str | string |
                   list | list[bool] | list[int] | list[float] |
                   list[double] | list[str] | list[string]
          - scope: all | cli | runtime   (default: all)
        """
        self._file_path: Optional[str] = config if isinstance(config, str) else None
        self._yaml_loader = YAML()
        self._yaml_loader.preserve_quotes = True

        # Flat storage with dot-notation keys
        self._param_defs:   Dict[str, Dict] = {}
        self._param_values: Dict[str, Any]  = {}

        # Per-file YAML roots (for in-place save with formatting preserved)
        self._yaml_roots:    Dict[str, Any] = {}   # abs_path → yaml node
        self._file_prefixes: Dict[str, str] = {}   # abs_path → prefix used when loading

        self._config: Dict = {}

        # ---- Load -----------------------------------------------------------
        if isinstance(config, str):
            abs_path = os.path.abspath(config)
            if config.endswith(('.yaml', '.yml')):
                with open(config, 'r') as f:
                    config_data = self._yaml_loader.load(f)
                if config_data is None:
                    raise ValueError(f"YAML file '{config}' is empty.")
                self._yaml_roots[abs_path]    = config_data
                self._file_prefixes[abs_path] = ''
            elif config.endswith('.json'):
                try:
                    with open(config, 'r') as f:
                        config_data = json.load(f)
                except json.JSONDecodeError as e:
                    raise ValueError(f"Invalid JSON in '{config}': {e}")
            else:
                raise ValueError("Unsupported file format. Use a JSON or YAML file.")
        elif isinstance(config, dict):
            config_data = config
        else:
            raise ValueError("Config must be a dict or a valid JSON/YAML file path.")

        if not isinstance(config_data, dict) or 'parameters' not in config_data:
            raise ValueError("Invalid configuration format. Expected a 'parameters' key.")

        self._config = config_data

        base_dir = (os.path.dirname(os.path.abspath(self._file_path))
                    if self._file_path else os.getcwd())

        include_stack: Set[str] = set()
        if self._file_path:
            include_stack.add(os.path.abspath(self._file_path))

        self._load_params(
            config_data['parameters'],
            prefix='',
            base_dir=base_dir,
            source_file=self._file_path or '',
            source_prefix='',
            include_stack=include_stack,
        )

        self.parameters = self._build_namespace()

        for key in self._param_defs:
            self._add_parameter(key)

        if enable_cli:
            self._parse_cli_args()

    # -----------------------------------------------------------------------
    # Recursive parameter loading
    # -----------------------------------------------------------------------

    def _load_params(
        self,
        params_list,
        prefix: str,
        base_dir: str,
        source_file: str,
        source_prefix: str,
        include_stack: Set[str],
    ):
        if not isinstance(params_list, list):
            raise ValueError("'parameters' must be a list.")

        for param in params_list:
            if not isinstance(param, dict):
                raise ValueError("Each parameter entry must be a mapping.")

            ptype = param.get('type', '')

            if ptype == 'group':
                name = param.get('name')
                if not name:
                    raise ValueError("Group parameter is missing 'name'.")
                next_prefix = f"{prefix}{name}."

                # include: <file>  or  include: [file1, file2]
                inc = param.get('include')
                if inc is not None:
                    inc_files = [inc] if isinstance(inc, str) else list(inc)
                    for rel_path in inc_files:
                        if os.path.isabs(rel_path):
                            raise ValueError(
                                f"Absolute paths not allowed in include: {rel_path}")
                        full     = os.path.normpath(os.path.join(base_dir, rel_path))
                        abs_full = os.path.abspath(full)
                        if abs_full in include_stack:
                            raise ValueError(
                                f"Circular include detected: {abs_full}")
                        include_stack.add(abs_full)
                        with open(full, 'r') as f:
                            inc_data = self._yaml_loader.load(f)
                        if not isinstance(inc_data, dict) or \
                                'parameters' not in inc_data:
                            raise ValueError(
                                f"Included file '{rel_path}' must contain "
                                f"'parameters'.")
                        self._yaml_roots[abs_full]    = inc_data
                        self._file_prefixes[abs_full] = next_prefix
                        self._load_params(
                            inc_data['parameters'],
                            prefix=next_prefix,
                            base_dir=os.path.dirname(full),
                            source_file=full,
                            source_prefix=next_prefix,
                            include_stack=include_stack,
                        )
                        include_stack.discard(abs_full)

                # Inline parameters (may coexist with include)
                if 'parameters' in param:
                    self._load_params(
                        param['parameters'],
                        prefix=next_prefix,
                        base_dir=base_dir,
                        source_file=source_file,
                        source_prefix=source_prefix,
                        include_stack=include_stack,
                    )

            else:
                name = param.get('name')
                if not name:
                    raise ValueError("Parameter is missing 'name'.")
                type_str = param.get('type')
                if not type_str:
                    raise ValueError(f"Parameter '{name}' is missing 'type'.")
                if (type_str not in _SCALAR_TYPES and
                        type_str not in _LIST_ELEM_TYPES):
                    raise ValueError(
                        f"Unknown type '{type_str}' for parameter '{name}'.")

                full_key = f"{prefix}{name}"
                scope    = param.get('scope', 'all')
                if scope not in _VALID_SCOPES:
                    raise ValueError(
                        f"Invalid scope '{scope}' for '{full_key}'. "
                        f"Must be: all | cli | runtime")

                self._param_defs[full_key] = {
                    'name':          name,
                    'full_key':      full_key,
                    'type':          type_str,
                    'scope':         scope,
                    'description':   param.get('description', ''),
                    'label':         param.get('label', ''),
                    'ui':            param.get('ui', {}),
                    'source_file':   source_file,
                    'source_prefix': source_prefix,
                }

                # value: preferred over default: (matches C++ behaviour)
                raw = param.get('value', param.get('default'))
                if raw is not None:
                    try:
                        self._param_values[full_key] = _validate_value(
                            full_key, raw, type_str)
                    except TypeError as e:
                        raise ValueError(str(e))
                else:
                    self._param_values[full_key] = None   # optional parameter

    # -----------------------------------------------------------------------
    # ParameterNamespace construction
    # -----------------------------------------------------------------------

    def _build_namespace(self) -> ParameterNamespace:
        root = ParameterNamespace()
        for key, value in self._param_values.items():
            parts = key.split('.')
            ns = root
            for part in parts[:-1]:
                if not hasattr(ns, part):
                    setattr(ns, part, ParameterNamespace())
                ns = getattr(ns, part)
            setattr(ns, parts[-1], value)
        return root

    # -----------------------------------------------------------------------
    # Dynamic setters   set_<safe_name>   (dots → underscores)
    # -----------------------------------------------------------------------

    @staticmethod
    def _safe_name(key: str) -> str:
        return key.replace('.', '_')

    def _add_parameter(self, key: str):
        safe     = self._safe_name(key)
        type_str = self._param_defs[key]['type']

        def setter(self_ref, value: Any):
            validated = _validate_value(key, value, type_str)
            self_ref._param_values[key] = validated

            # Update namespace in-place
            parts = key.split('.')
            ns = self_ref.parameters
            for part in parts[:-1]:
                if not hasattr(ns, part):
                    setattr(ns, part, ParameterNamespace())
                ns = getattr(ns, part)
            setattr(ns, parts[-1], validated)

            # Callback  on_<safe_name>_set
            cb = f"on_{safe}_set"
            if hasattr(self_ref, cb) and callable(getattr(self_ref, cb)):
                getattr(self_ref, cb)(validated)

            # Persist
            if self_ref._file_path:
                self_ref._save_config(key)

        setattr(self, f"set_{safe}", setter.__get__(self))

    # -----------------------------------------------------------------------
    # CLI (argparse)
    # -----------------------------------------------------------------------

    def _parse_cli_args(self):
        self.parser = argparse.ArgumentParser(
            description=self._config.get('description', ''))

        for key, defn in self._param_defs.items():
            if defn['scope'] not in ('all', 'cli'):
                continue

            type_str = defn['type']
            safe     = self._safe_name(key)
            flag     = '--' + key.replace('.', '-').replace('_', '-')
            desc     = defn.get('description', '')
            current  = self._param_values.get(key)

            if type_str == 'bool':
                grp = self.parser.add_mutually_exclusive_group()
                grp.add_argument(flag, dest=safe, action='store_true',
                                 default=current or False, help=desc)
                grp.add_argument(
                    '--no-' + key.replace('.', '-').replace('_', '-'),
                    dest=safe, action='store_false',
                    help=f"Disable {key}")
            elif type_str in ('list', 'list[str]', 'list[string]'):
                self.parser.add_argument(flag, dest=safe, nargs='+',
                                         default=current or [], help=desc)
            elif type_str == 'list[int]':
                self.parser.add_argument(flag, dest=safe, nargs='+',
                                         type=int, default=current or [],
                                         help=desc)
            elif type_str in ('list[float]', 'list[double]'):
                self.parser.add_argument(flag, dest=safe, nargs='+',
                                         type=float, default=current or [],
                                         help=desc)
            elif type_str == 'list[bool]':
                self.parser.add_argument(flag, dest=safe, nargs='+',
                                         default=current or [], help=desc)
            elif type_str == 'int':
                self.parser.add_argument(flag, dest=safe, default=current,
                                         type=int, help=desc)
            elif type_str in ('float', 'double'):
                self.parser.add_argument(flag, dest=safe, default=current,
                                         type=float, help=desc)
            elif type_str in ('str', 'string'):
                self.parser.add_argument(flag, dest=safe, default=current,
                                         type=str, help=desc)

        args, _ = self.parser.parse_known_args()
        cli_args = vars(args)

        for key, defn in self._param_defs.items():
            if defn['scope'] not in ('all', 'cli'):
                continue
            safe = self._safe_name(key)
            if safe not in cli_args:
                continue
            val = cli_args[safe]
            if val is None:
                continue
            try:
                validated = _validate_value(key, val, defn['type'])
                self._param_values[key] = validated
                parts = key.split('.')
                ns = self.parameters
                for part in parts[:-1]:
                    if not hasattr(ns, part):
                        setattr(ns, part, ParameterNamespace())
                    ns = getattr(ns, part)
                setattr(ns, parts[-1], validated)
            except (TypeError, ValueError):
                pass

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    def get_parameters(self) -> Dict[str, Any]:
        """Return all parameters as a flat dict with dot-notation keys."""
        return dict(self._param_values)

    def save_as(self, path: str):
        """
        Save all parameters to *path* (a new YAML file).
        Uses the main file's YAML structure; include: references are preserved
        as-is (same behaviour as paramify-cpp save_as).
        """
        if not self._file_path or not self._file_path.endswith(('.yaml', '.yml')):
            raise ValueError("save_as requires a YAML source file.")
        abs_main = os.path.abspath(self._file_path)
        root = self._yaml_roots.get(abs_main)
        if root is None:
            with open(self._file_path, 'r') as f:
                root = self._yaml_loader.load(f)
        self._update_yaml_params(root.get('parameters', []), prefix='')
        with open(path, 'w') as f:
            self._yaml_loader.dump(root, f)

    # -----------------------------------------------------------------------
    # Persistence helpers
    # -----------------------------------------------------------------------

    def _save_config(self, changed_key: str):
        if not self._file_path:
            return
        defn        = self._param_defs[changed_key]
        source_file = defn['source_file'] or self._file_path
        if source_file.endswith(('.yaml', '.yml')):
            self._save_yaml_file(source_file)
        else:
            # JSON (or fallback)
            self._update_json_params(self._config.get('parameters', []), prefix='')
            with open(self._file_path, 'w') as f:
                json.dump(self._config, f, indent=4)

    def _save_yaml_file(self, file_path: str):
        abs_path = os.path.abspath(file_path)
        root = self._yaml_roots.get(abs_path)
        if root is None:
            with open(file_path, 'r') as f:
                root = self._yaml_loader.load(f)
            self._yaml_roots[abs_path] = root
        source_prefix = self._file_prefixes.get(abs_path, '')
        self._update_yaml_params(root.get('parameters', []), prefix=source_prefix)
        with open(file_path, 'w') as f:
            self._yaml_loader.dump(root, f)

    def _update_yaml_params(self, params_list, prefix: str):
        for param in params_list:
            if not isinstance(param, dict):
                continue
            if param.get('type') == 'group':
                name = param.get('name')
                if name and 'parameters' in param:
                    self._update_yaml_params(
                        param['parameters'], f"{prefix}{name}.")
                # include: files saved separately via _save_yaml_file
            else:
                name = param.get('name')
                if not name:
                    continue
                full_key = f"{prefix}{name}"
                val = self._param_values.get(full_key)
                if val is None:
                    continue
                if 'value' in param:
                    param['value'] = val
                elif 'default' in param:
                    param['default'] = val
                else:
                    param['value'] = val

    def _update_json_params(self, params_list, prefix: str):
        for param in params_list:
            if not isinstance(param, dict):
                continue
            if param.get('type') == 'group':
                name = param.get('name')
                if name and 'parameters' in param:
                    self._update_json_params(
                        param['parameters'], f"{prefix}{name}.")
            else:
                name = param.get('name')
                if not name:
                    continue
                full_key = f"{prefix}{name}"
                val = self._param_values.get(full_key)
                if val is None:
                    continue
                if 'value' in param:
                    param['value'] = val
                elif 'default' in param:
                    param['default'] = val
                else:
                    param['default'] = val

    # -----------------------------------------------------------------------
    # __str__
    # -----------------------------------------------------------------------

    def __str__(self):
        params = self.get_parameters()
        if not params:
            return (f"{self._config.get('name', self.__class__.__name__)} "
                    f"(no parameters)")

        def label_part(key):
            lbl = self._param_defs.get(key, {}).get('label', '')
            return f" ({lbl})" if lbl else ""

        max_len = max(len(k) + len(label_part(k)) for k in params)
        lines = []
        for key, value in params.items():
            lp  = label_part(key)
            pad = max_len - len(key) - len(lp)
            lines.append(f"   {key}{lp}{' ' * max(0, pad)}: {value}")

        app_name = self._config.get('name', self.__class__.__name__)
        return f"{app_name} initialized with:\n" + "\n".join(lines)
