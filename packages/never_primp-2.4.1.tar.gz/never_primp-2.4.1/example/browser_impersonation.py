"""
浏览器指纹伪装示例

演示如何使用不同浏览器配置文件伪装 TLS/HTTP2 指纹，
以通过 WAF/Cloudflare/Akamai Bot Manager 等风控系统。
"""
import never_primp

TLS_CHECK_URL = "https://tls.peet.ws/api/all"

# ─────────────────────────────────────────────
# 1. Chrome 最新版 (Windows)
# ─────────────────────────────────────────────
print("=" * 55)
print("  1. Chrome 143 on Windows")
print("=" * 55)

chrome_win = never_primp.Client(
    impersonate="chrome_143",
    impersonate_os="windows",
)

try:
    r = chrome_win.get(TLS_CHECK_URL, timeout=15.0)
    data = r.json()
    tls = data.get("tls", {})
    http2 = data.get("http2", {})
    print(f"  JA3  : {tls.get('ja3', 'N/A')[:50]}...")
    print(f"  JA4  : {tls.get('ja4', 'N/A')[:50]}...")
    print(f"  ALPN : {tls.get('alpn', 'N/A')}")
    print(f"  HTTP2: {http2.get('fingerprint', 'N/A')[:40]}...")
except Exception as e:
    print(f"  [网络] {e}")


# ─────────────────────────────────────────────
# 2. Firefox on macOS
# ─────────────────────────────────────────────
print("\n" + "=" * 55)
print("  2. Firefox 147 on macOS")
print("=" * 55)

firefox_mac = never_primp.Client(
    impersonate="firefox_147",
    impersonate_os="macos",
)

try:
    r = firefox_mac.get(TLS_CHECK_URL, timeout=15.0)
    data = r.json()
    tls = data.get("tls", {})
    print(f"  JA3  : {tls.get('ja3', 'N/A')[:50]}...")
    print(f"  JA4  : {tls.get('ja4', 'N/A')[:50]}...")
except Exception as e:
    print(f"  [网络] {e}")


# ─────────────────────────────────────────────
# 3. Safari on iOS (移动端)
# ─────────────────────────────────────────────
print("\n" + "=" * 55)
print("  3. Safari iOS 18.1.1 (Mobile)")
print("=" * 55)

safari_ios = never_primp.Client(
    impersonate="safari_ios_18.1.1",
    impersonate_os="ios",
)

try:
    r = safari_ios.get(TLS_CHECK_URL, timeout=15.0)
    data = r.json()
    tls = data.get("tls", {})
    print(f"  JA3  : {tls.get('ja3', 'N/A')[:50]}...")
    print(f"  JA4  : {tls.get('ja4', 'N/A')[:50]}...")
except Exception as e:
    print(f"  [网络] {e}")


# ─────────────────────────────────────────────
# 4. 请求级别 impersonate 临时切换
# ─────────────────────────────────────────────
print("\n" + "=" * 55)
print("  4. 请求级别临时切换浏览器指纹")
print("=" * 55)

# 默认使用 Chrome，某些请求临时切换到 Firefox
default_client = never_primp.Client(
    impersonate="chrome_143",
    impersonate_os="windows",
    timeout=15.0,
)

print("  默认: chrome_143/windows")
print("  GET /endpoint_a → chrome_143 (使用默认)")
print("  GET /endpoint_b → firefox_147 (临时覆盖，不影响主 Client)")
# 实际请求示例（不实际发送，仅演示 API）
# r_a = default_client.get("https://example.com/a")
# r_b = default_client.get("https://example.com/b",
#                            impersonate="firefox_147",
#                            impersonate_os="linux")


# ─────────────────────────────────────────────
# 5. 配合自定义 Headers（反检测增强）
# ─────────────────────────────────────────────
print("\n" + "=" * 55)
print("  5. 自定义 Header + 浏览器指纹（双重伪装）")
print("=" * 55)

stealth_client = never_primp.Client(
    impersonate="chrome_143",
    impersonate_os="windows",
    headers={
        # 额外的 Sec-CH-UA 客户端提示（与 Chrome 143 一致）
        "sec-ch-ua": '"Google Chrome";v="143", "Chromium";v="143", "Not-A.Brand";v="99"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
    },
    split_cookies=True,   # HTTP/2 风格：独立 Cookie 头（浏览器真实行为）
)

print("  TLS 指纹  : Chrome 143（BoringSSL cipher suites + extensions）")
print("  HTTP/2 指纹: Chrome 143 SETTINGS + WINDOW_UPDATE + HEADERS 帧顺序")
print("  请求头顺序: OrigHeaderMap 精确控制（anti-bot header-order detection）")
print("  Cookie 格式: split_cookies=True（每个 Cookie 独立头，浏览器真实行为）")

print("\n所有浏览器指纹示例完成！")
