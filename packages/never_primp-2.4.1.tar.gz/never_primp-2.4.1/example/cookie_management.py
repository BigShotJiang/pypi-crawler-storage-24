"""
Cookie 管理示例

演示：
1. 自动跨子域名 Cookie 共享（RFC 6265 domain matching）
2. export_cookies / import_cookies 跨会话持久化
3. get_cookies_for_domain 子域名感知查询
4. 访问真实网站时的 Cookie 自动管理
"""
import json
import tempfile
import os

import never_primp


# ─────────────────────────────────────────────
# 1. 子域名 Cookie 共享
# ─────────────────────────────────────────────
print("=" * 55)
print("  1. RFC 6265 子域名 Cookie 共享")
print("=" * 55)

client = never_primp.Client()

# 设置 domain 级别 cookie（发给 .example.com 所有子域名）
client.set_cookie("session_token", "abc123_secret",
                  url="https://example.com",
                  domain="example.com",
                  path="/")

client.set_cookie("user_id", "42",
                  url="https://example.com",
                  domain="example.com",
                  path="/")

# 验证：主域名可以获取
main_cookies = client.get_cookies("https://example.com/")
print(f"\n主域名 example.com 的 cookie:")
for k, v in main_cookies.items():
    print(f"  {k} = {v}")

# 验证：子域名自动继承（RFC 6265 domain matching）
api_cookies = client.get_cookies_for_domain("api.example.com")
print(f"\napi.example.com 继承的 cookie:")
for k, v in api_cookies.items():
    print(f"  {k} = {v}")

cdn_cookies = client.get_cookies_for_domain("cdn.static.example.com")
print(f"\ncdn.static.example.com 继承的 cookie:")
for k, v in cdn_cookies.items():
    print(f"  {k} = {v}")

assert api_cookies == cdn_cookies == main_cookies, "子域名应共享父域名 Cookie"
print("\n[OK] 子域名 Cookie 共享验证通过")


# ─────────────────────────────────────────────
# 2. Cookie 导出 / 导入（跨会话持久化）
# ─────────────────────────────────────────────
print("\n" + "=" * 55)
print("  2. 跨会话 Cookie 持久化")
print("=" * 55)

# 访问真实网站，自动接收 Set-Cookie
session = never_primp.Client(impersonate="chrome_143")
try:
    session.get("https://httpbin.org/cookies/set?login=true&user_id=999")
    auto_cookies = session.get_cookies("https://httpbin.org/cookies")
    print(f"\n自动接收的 cookie: {dict(auto_cookies)}")
except Exception as e:
    print(f"[网络] 跳过真实请求: {e}")

# 手动演示导出/导入
demo_client = never_primp.Client()
demo_client.set_cookie("auth_token", "eyJhbGci...",
                       url="https://api.mysite.com",
                       domain="mysite.com", path="/")
demo_client.set_cookie("csrf", "tok_xyz",
                       url="https://app.mysite.com",
                       domain="mysite.com", path="/")

# 导出
exported = demo_client.export_cookies()
print(f"\n导出的 cookies ({len(exported)} 条):")
for name, value, domain, path in exported:
    print(f"  [{domain}{path}] {name} = {value[:20]}...")

# 保存到文件（生产中可以用 JSON/pickle/数据库）
cookie_file = tempfile.mktemp(suffix=".json")
with open(cookie_file, "w") as f:
    json.dump(exported, f)
print(f"\nCookie 已保存到: {cookie_file}")

# 新会话恢复
new_client = never_primp.Client(impersonate="chrome_143")
with open(cookie_file) as f:
    saved_cookies = json.load(f)
new_client.import_cookies([tuple(c) for c in saved_cookies])

# 验证恢复
restored = new_client.get_all_cookies()
print(f"\n恢复的 cookies ({len(restored)} 条):")
for name, value, domain, path in restored:
    print(f"  [{domain}{path}] {name} = {value[:20]}...")

# 子域名也能获取到
api_check = new_client.get_cookies_for_domain("api.mysite.com")
app_check = new_client.get_cookies_for_domain("app.mysite.com")
print(f"\napi.mysite.com: {dict(api_check)}")
print(f"app.mysite.com: {dict(app_check)}")

os.unlink(cookie_file)
print("\n[OK] Cookie 跨会话持久化验证通过")


# ─────────────────────────────────────────────
# 3. Cookie 生命周期管理
# ─────────────────────────────────────────────
print("\n" + "=" * 55)
print("  3. Cookie 生命周期管理")
print("=" * 55)

mgr = never_primp.Client()
mgr.set_cookie("tmp", "val", url="https://example.com", domain="example.com")
mgr.set_cookie("keep", "val2", url="https://example.com", domain="example.com")

print(f"\n初始 ({len(mgr.get_all_cookies())} 条): {[c[0] for c in mgr.get_all_cookies()]}")

mgr.remove_cookie("tmp", "https://example.com/")
print(f"移除 tmp 后 ({len(mgr.get_all_cookies())} 条): {[c[0] for c in mgr.get_all_cookies()]}")

mgr.clear_cookies()
print(f"清空后 ({len(mgr.get_all_cookies())} 条): {mgr.get_all_cookies()}")

print("\n[OK] Cookie 生命周期管理验证通过")
print("\n所有 Cookie 管理测试完成！")
