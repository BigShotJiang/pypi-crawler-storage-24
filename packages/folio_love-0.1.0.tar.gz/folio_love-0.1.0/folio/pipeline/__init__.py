"""Conversion pipeline stages."""
