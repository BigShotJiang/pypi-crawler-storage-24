"""Output generation."""
