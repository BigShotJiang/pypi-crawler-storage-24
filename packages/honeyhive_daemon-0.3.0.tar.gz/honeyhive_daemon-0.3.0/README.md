# Coding Agent Exporters

Export sessions from coding agent platforms into HoneyHive for observability and evaluation.

## Claude Code Daemon

A local daemon that captures Claude Code activity via hooks and exports structured events to HoneyHive for observability and evaluation.

- Installs Claude Code hooks automatically at the user level
- Merges pre-hook and post-hook into single tool events with accurate duration
- Uses real tool names for event names (e.g. `tool.Bash`, `tool.Edit`, `tool.Grep`)
- Emits turn events (`turn.user`, `turn.agent`) as `model` type with `chat_history`
- Enriches tool events with thinking/reasoning context from the session transcript
- Uploads session transcripts as artifacts on session end or idle timeout
- Optionally emits lightweight git `chain.commit_link` events on `post-commit`
- Resilient event spooling — failed exports are retried every 5s

### Quickstart

```bash
pip install -e .
honeyhive-daemon run --key $HH_API_KEY --url $HH_API_URL --project my-project
```

The daemon stores local state in `~/.honeyhive/daemon/` and installs Claude hooks in `~/.claude/settings.json`.

### Running in the background

```bash
honeyhive-daemon run --key $HH_API_KEY --url $HH_API_URL &
```

To stop it:

```bash
honeyhive-daemon stop
```

`stop` sends SIGTERM to the running daemon via its PID file (`~/.honeyhive/daemon/daemon.pid`). Only one instance can run at a time — attempting to start a second will print an error and exit.

### Events

Each Claude Code session produces a tree of events in HoneyHive:

| Event name | Type | Description |
|------------|------|-------------|
| `session.start` | `session` | Root event. All other events are children of this. |
| `turn.user` | `model` | User prompt. `inputs.chat_history` accumulates the full conversation so far; `outputs.content` is the new message. |
| `turn.agent` | `model` | Assistant response. `inputs.chat_history` accumulates the full conversation so far; `outputs.content` is the new message. |
| `tool.{ToolName}` | `tool` | Tool use (e.g. `tool.Bash`, `tool.Edit`, `tool.Read`, `tool.Grep`). Pre and post hooks are merged into a single event with `start_time`/`end_time` duration. |
| `session.end` | `chain` | Marks session completion. Triggers transcript artifact upload. |
| `chain.commit_link` | `chain` | Git commit metadata (requires `--repo`). |

Tool events include `inputs.thinking` when a reasoning block precedes the tool call in the transcript. Pre-hook events that never receive a matching post-hook are exported as orphans after 60s.

### State directory

All daemon state lives under `~/.honeyhive/daemon/` (override with `HH_DAEMON_HOME`):

| File | Purpose |
|------|---------|
| `state/config.json` | Persisted daemon configuration |
| `state/sessions.json` | Session index (transcript paths, timestamps, artifact status) |
| `state/pending_tools.json` | Buffered pre-hook tool events awaiting their post-hook |
| `state/chat_histories.json` | Accumulated chat history per session for turn events |
| `spool/events.jsonl` | Retry queue for failed exports |
| `daemon.log` | Timestamped daemon log |
| `daemon.pid` | Process ID file |

### CLI reference

| Command | Description |
|---------|-------------|
| `honeyhive-daemon run` | Start the daemon, install hooks, and flush queued events. |
| `honeyhive-daemon stop` | Stop the running daemon. |
| `honeyhive-daemon status` | Show config and pending spool event count. |
| `honeyhive-daemon doctor` | Check that hooks and config are correctly installed. |

#### `run` options

| Flag | Env var | Description |
|------|---------|-------------|
| `--key` | `HH_API_KEY` | HoneyHive API key (required). |
| `--url` | `HH_API_URL` | HoneyHive base URL (default: `https://api.honeyhive.ai`). |
| `--project` | `HH_PROJECT` | HoneyHive project name (default: repo/directory name). |
| `--repo PATH` | | Git repo to attach commit events to. |
| `--ci` | | Enable CI mode. |

## Devin Exporter

Polls Devin's session API and exports session data into HoneyHive as session events. Supports incremental sync, automatic upserts, and both one-shot and continuous daemon modes.

### How it works

1. Fetches sessions from Devin using `updated_after` for incremental sync
2. Maps each Devin session to a HoneyHive session event via `POST /session/start`
3. On subsequent syncs, updates previously-synced sessions via `PUT /events`
4. Tracks sync state (last sync timestamp + session ID mapping) in a local JSON file

Auto-detects Devin API version from key prefix: `apk_*` uses v1, `cog_*` uses v3.

### Required Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DEVIN_API_KEY` | Yes | Devin API key. Prefix `apk_*` for v1 API, `cog_*` for v3 API. |
| `DEVIN_ORG_ID` | For v3 keys | Devin organization ID. Required when using `cog_*` keys. The script attempts auto-discovery via `/enterprise/self` but this requires enterprise-level access. |
| `HH_API_KEY` | Yes | HoneyHive API key. |
| `HH_API_URL` | Yes | HoneyHive data plane URL (e.g. `https://api.honeyhive.ai`). |
| `HH_PROJECT` | Yes | HoneyHive project name to export sessions into. |

### Optional Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `STATE_FILE_PATH` | `./sync_state.json` | Path to the JSON file that tracks sync state between runs. |
| `SYNC_INTERVAL_SECONDS` | `60` | Default polling interval for daemon mode (can also be set via `--interval`). |

### Usage

```bash
pip install -r devin/requirements.txt
```

**One-shot sync** (fetch and export, then exit):

```bash
python devin/devin_to_honeyhive.py
```

**Daemon mode** (continuous polling):

```bash
python devin/devin_to_honeyhive.py --daemon --interval 30
```

**Verbose logging:**

```bash
python devin/devin_to_honeyhive.py --verbose
```

### CLI Options

| Flag | Description |
|------|-------------|
| `--daemon` | Run continuously, polling at the configured interval. |
| `--interval SECONDS` | Polling interval in seconds (default: 60). |
| `--state-file PATH` | Path to sync state file (default: `./sync_state.json`). |
| `--verbose`, `-v` | Enable debug-level logging. |

### Data Mapping

Each Devin session is mapped to a HoneyHive session event:

| Devin Field | HoneyHive Field |
|-------------|-----------------|
| `session_id` | `user_properties.devin_session_id` |
| `title` | `session_name` |
| `status` | `metadata.devin_status` |
| `tags` | `metadata.devin_tags` |
| `url` | `metadata.devin_url` |
| `pull_requests` | `metadata.devin_pull_requests` |
| `acus_consumed` | `metrics.acus_consumed` |
| `created_at` | `start_time` |
| `updated_at` | `end_time` |

Session IDs are deterministically mapped using UUID5 so re-syncs are idempotent.

### GitHub Actions Workflow

The included workflow (`.github/workflows/devin-export-sync.yml`) runs the exporter automatically:

- **On push/PR** to `main` touching `devin/**` files: runs a one-shot sync
- **Manual dispatch** via Actions tab: choose oneshot or daemon mode with configurable interval

Required GitHub repo secrets (same as the environment variables above):

- `DEVIN_API_KEY`
- `DEVIN_ORG_ID`
- `HH_API_KEY`
- `HH_API_URL`
- `HH_PROJECT`

### Sync Frequency

The script supports polling intervals as low as 30 seconds. The practical minimum depends on Devin API rate limits and the number of sessions in your org. For typical usage, 30-60 second intervals work well.

### State Management

Sync state is stored in a JSON file (`sync_state.json` by default) containing:
- `last_sync_epoch`: timestamp of the last successful sync (used for incremental filtering)
- `synced_sessions`: mapping of Devin session IDs to HoneyHive event IDs and last-updated timestamps

If the state file is lost or corrupted, the next run performs a full re-sync. Session IDs are deterministic (UUID5), so re-creates are safe.
