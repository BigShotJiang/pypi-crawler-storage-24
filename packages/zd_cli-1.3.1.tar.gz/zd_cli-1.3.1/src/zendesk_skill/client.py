"""Zendesk API client with authentication and request handling."""

import base64
import json
import os
from pathlib import Path
from typing import Any

import httpx

# Config directory and file locations
CONFIG_DIR = Path.home() / ".config" / "zd-cli"
CONFIG_PATH = CONFIG_DIR / "config.json"
SECRETS_PATH = CONFIG_DIR / "secrets.json"  # Encrypted to secrets.json.enc
_LEGACY_CONFIG_DIR = Path.home() / ".claude" / ".zendesk-skill"

# Keys that are secrets and belong in secrets.json.enc, not config.json
_SECRET_KEYS = ("token", "oauth_client_id", "oauth_client_secret", "slack_webhook_url")


def _migrate_config_dir() -> None:
    """Migrate config from old ~/.claude/.zendesk-skill/ to new location."""
    if _LEGACY_CONFIG_DIR.exists() and not CONFIG_DIR.exists():
        import shutil
        import sys
        try:
            shutil.copytree(_LEGACY_CONFIG_DIR, CONFIG_DIR)
            print(
                f"[zd-cli] Migrated config from {_LEGACY_CONFIG_DIR} to {CONFIG_DIR}",
                file=sys.stderr,
            )
        except OSError as e:
            print(f"[zd-cli] Warning: failed to migrate config: {e}", file=sys.stderr)


_migration_done = False

# Default timeout for API requests
DEFAULT_TIMEOUT = 30.0

# Maximum redirects for attachment downloads
MAX_REDIRECTS = 5


class ZendeskClientError(Exception):
    """Base exception for Zendesk client errors."""


class ZendeskAuthError(ZendeskClientError):
    """Authentication error."""


class ZendeskAPIError(ZendeskClientError):
    """API request error."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


def _load_config_from_file() -> dict[str, str]:
    """Load configuration from config file."""
    global _migration_done
    if not _migration_done:
        _migrate_config_dir()
        _migration_done = True
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH) as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _get_encryption_key() -> bytes | None:
    """Return the Fernet encryption key, or None if encryption is disabled.

    Set ZD_ENCRYPTION=none to disable encryption entirely.
    """
    if os.environ.get("ZD_ENCRYPTION", "").lower() == "none":
        return None

    from zendesk_skill.crypto import derive_key, generate_salt

    config = _load_config_from_file()
    salt = config.get("encryption_salt")
    if not salt:
        salt = generate_salt()
        config["encryption_salt"] = salt
        _save_config(config)
    return derive_key(salt, "zd-cli")


def _load_secrets() -> dict:
    """Load secrets from encrypted secrets file."""
    from zendesk_skill.crypto import load_encrypted

    key = _get_encryption_key()
    return load_encrypted(SECRETS_PATH, key) or {}


def _save_secrets(secrets: dict) -> None:
    """Save secrets to encrypted secrets file."""
    from zendesk_skill.crypto import save_encrypted

    key = _get_encryption_key()
    save_encrypted(SECRETS_PATH, secrets, key)


_secrets_migrated = False


def _migrate_secrets_from_config() -> None:
    """One-time migration: extract secret keys from config.json into secrets.json.enc."""
    global _secrets_migrated
    if _secrets_migrated:
        return
    _secrets_migrated = True

    config = _load_config_from_file()
    secrets_to_migrate = {k: config[k] for k in _SECRET_KEYS if k in config}

    if not secrets_to_migrate:
        return

    # Merge with existing secrets (if any)
    existing = _load_secrets()
    existing.update(secrets_to_migrate)
    _save_secrets(existing)

    # Remove secret keys from config
    for k in _SECRET_KEYS:
        config.pop(k, None)
    _save_config(config)


def _get_credentials() -> tuple[str, str, str]:
    """Get credentials from environment variables or config file.

    Returns:
        Tuple of (email, token, subdomain)

    Raises:
        ZendeskAuthError: If required credentials are missing
    """
    # Try environment variables first
    email = os.environ.get("ZENDESK_EMAIL")
    token = os.environ.get("ZENDESK_TOKEN")
    subdomain = os.environ.get("ZENDESK_SUBDOMAIN")

    # Fall back to config file (non-secrets) and secrets file
    if not all([email, token, subdomain]):
        _migrate_secrets_from_config()
        config = _load_config_from_file()
        secrets = _load_secrets()
        email = email or config.get("email")
        token = token or secrets.get("token")
        subdomain = subdomain or config.get("subdomain")

    # Validate
    missing = []
    if not email:
        missing.append("email (ZENDESK_EMAIL)")
    if not token:
        missing.append("token (ZENDESK_TOKEN)")
    if not subdomain:
        missing.append("subdomain (ZENDESK_SUBDOMAIN)")

    if missing:
        raise ZendeskAuthError(
            f"Missing Zendesk credentials: {', '.join(missing)}. "
            f"Set environment variables or create config at {CONFIG_PATH}"
        )

    return email, token, subdomain


def _build_auth_header(email: str, token: str) -> str:
    """Build Basic auth header for Zendesk API.

    Zendesk uses email/token auth: {email}/token:{token}
    """
    auth_string = f"{email}/token:{token}"
    encoded = base64.b64encode(auth_string.encode()).decode()
    return f"Basic {encoded}"


def _save_config(config: dict) -> Path:
    """Save config dict to file, preserving permissions.

    Args:
        config: Config dictionary to save

    Returns:
        Path to the config file
    """
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)
    # Secure permissions (Unix only, no-op on Windows)
    try:
        CONFIG_PATH.chmod(0o600)
    except OSError:
        pass  # Windows doesn't support Unix permissions
    return CONFIG_PATH


def save_credentials(email: str, token: str, subdomain: str) -> Path:
    """Save Zendesk credentials.

    Email and subdomain go to config.json (not secret).
    Token goes to secrets.json.enc (encrypted).

    Args:
        email: Zendesk email
        token: Zendesk API token
        subdomain: Zendesk subdomain

    Returns:
        Path to the config file
    """
    # Non-secrets to config
    config = _load_config_from_file()
    config.update({"email": email, "subdomain": subdomain})
    _save_config(config)

    # Token to encrypted secrets
    secrets = _load_secrets()
    secrets["token"] = token
    _save_secrets(secrets)

    return CONFIG_PATH


def save_slack_config(webhook_url: str, channel: str) -> Path:
    """Save Slack webhook configuration.

    Channel goes to config.json, webhook URL goes to secrets.json.enc.

    Args:
        webhook_url: Slack incoming webhook URL
        channel: Default Slack channel (e.g., #channel-name)

    Returns:
        Path to the config file
    """
    config = _load_config_from_file()
    config["slack_channel"] = channel
    _save_config(config)

    secrets = _load_secrets()
    secrets["slack_webhook_url"] = webhook_url
    _save_secrets(secrets)

    return CONFIG_PATH


def get_slack_config() -> tuple[str, str] | None:
    """Get Slack configuration from environment, config, or secrets.

    Returns:
        Tuple of (webhook_url, channel) or None if not configured
    """
    # Try environment variables first
    webhook_url = os.environ.get("SLACK_WEBHOOK_URL")
    channel = os.environ.get("SLACK_CHANNEL")

    # Fall back to config (channel) and secrets (webhook)
    if not webhook_url or not channel:
        _migrate_secrets_from_config()
        config = _load_config_from_file()
        secrets = _load_secrets()
        webhook_url = webhook_url or secrets.get("slack_webhook_url")
        channel = channel or config.get("slack_channel")

    if webhook_url and channel:
        return webhook_url, channel
    return None


def get_slack_status() -> dict:
    """Get Slack configuration status.

    Returns:
        Dict with configured status and details
    """
    env_webhook = os.environ.get("SLACK_WEBHOOK_URL")
    env_channel = os.environ.get("SLACK_CHANNEL")
    env_vars_set = []
    if env_webhook:
        env_vars_set.append("SLACK_WEBHOOK_URL")
    if env_channel:
        env_vars_set.append("SLACK_CHANNEL")

    _migrate_secrets_from_config()
    config = _load_config_from_file()
    secrets = _load_secrets()
    config_webhook = secrets.get("slack_webhook_url")
    config_channel = config.get("slack_channel")

    # Determine source
    source = None
    configured = False
    if env_webhook and env_channel:
        source = "env"
        configured = True
    elif config_webhook and config_channel:
        source = "config"
        configured = True

    return {
        "configured": configured,
        "source": source,
        "channel": config_channel or env_channel,
        "env_vars_set": env_vars_set,
        "has_config": bool(config_webhook and config_channel),
    }


def delete_slack_config() -> bool:
    """Remove Slack configuration from config and secrets.

    Returns:
        True if Slack config was removed, False if it didn't exist
    """
    config = _load_config_from_file()
    secrets = _load_secrets()

    had_channel = "slack_channel" in config
    had_webhook = "slack_webhook_url" in secrets

    config.pop("slack_channel", None)
    if had_channel:
        _save_config(config)

    secrets.pop("slack_webhook_url", None)
    if had_webhook:
        _save_secrets(secrets)

    return had_channel or had_webhook


def delete_credentials() -> bool:
    """Delete credentials from config and secrets.

    Removes email/subdomain from config.json and deletes secrets file.

    Returns:
        True if credentials were deleted, False if nothing existed
    """
    from zendesk_skill.crypto import delete_encrypted

    deleted = False

    # Remove non-secret credential fields from config
    config = _load_config_from_file()
    if "email" in config or "subdomain" in config:
        config.pop("email", None)
        config.pop("subdomain", None)
        _save_config(config)
        deleted = True

    # Delete encrypted secrets file
    if delete_encrypted(SECRETS_PATH):
        deleted = True

    return deleted


def get_business_hours_config() -> dict | None:
    """Get business hours configuration from config file.

    Returns:
        Dict with business_hours and oncall config, or None if not configured.

    Example config:
        {
            "business_hours": {
                "timezone": "Europe/Berlin",
                "start_hour": 9,
                "end_hour": 18,
                "workdays": [0, 1, 2, 3, 4]  # Monday=0, Sunday=6
            },
            "oncall": {
                "enabled": true,
                "start_hour": 19,
                "end_hour": 9,
                "customers": ["acme.com"],  # Empty = all customers
                "priorities": ["urgent"]
            }
        }
    """
    config = _load_config_from_file()
    business_hours = config.get("business_hours")
    oncall = config.get("oncall")

    if not business_hours:
        return None

    return {
        "business_hours": business_hours,
        "oncall": oncall,
    }


def save_business_hours_config(
    timezone: str = "Europe/Berlin",
    start_hour: int = 9,
    end_hour: int = 18,
    workdays: list[int] | None = None,
    oncall_enabled: bool = False,
    oncall_start_hour: int = 19,
    oncall_end_hour: int = 9,
    oncall_customers: list[str] | None = None,
    oncall_priorities: list[str] | None = None,
) -> Path:
    """Save business hours configuration to config file.

    Args:
        timezone: Timezone name (e.g., "Europe/Berlin")
        start_hour: Business hours start (0-23)
        end_hour: Business hours end (0-23)
        workdays: List of workdays (0=Monday, 6=Sunday). Default: Mon-Fri
        oncall_enabled: Whether on-call tracking is enabled
        oncall_start_hour: On-call period start hour
        oncall_end_hour: On-call period end hour
        oncall_customers: Customer domains for on-call (empty = all)
        oncall_priorities: Ticket priorities for on-call

    Returns:
        Path to the config file
    """
    config = _load_config_from_file()

    config["business_hours"] = {
        "timezone": timezone,
        "start_hour": start_hour,
        "end_hour": end_hour,
        "workdays": workdays if workdays is not None else [0, 1, 2, 3, 4],
    }

    config["oncall"] = {
        "enabled": oncall_enabled,
        "start_hour": oncall_start_hour,
        "end_hour": oncall_end_hour,
        "customers": oncall_customers or [],
        "priorities": oncall_priorities or ["urgent"],
    }

    return _save_config(config)


def get_auth_status() -> dict:
    """Get current authentication configuration status.

    Returns:
        Dict with:
            - configured: bool - whether credentials are available
            - source: str | None - "env", "config", or None
            - config_path: str - path to config file
            - env_vars_set: list - which env vars are set
            - has_config_file: bool - whether config file exists
    """
    # Check environment variables
    env_email = os.environ.get("ZENDESK_EMAIL")
    env_token = os.environ.get("ZENDESK_TOKEN")
    env_subdomain = os.environ.get("ZENDESK_SUBDOMAIN")
    env_vars_set = []
    if env_email:
        env_vars_set.append("ZENDESK_EMAIL")
    if env_token:
        env_vars_set.append("ZENDESK_TOKEN")
    if env_subdomain:
        env_vars_set.append("ZENDESK_SUBDOMAIN")

    env_complete = all([env_email, env_token, env_subdomain])

    # Check config file + secrets
    has_config_file = CONFIG_PATH.exists()
    config_complete = False
    if has_config_file:
        _migrate_secrets_from_config()
        config = _load_config_from_file()
        secrets = _load_secrets()
        config_complete = all([
            config.get("email"),
            secrets.get("token"),
            config.get("subdomain"),
        ])

    # Determine source (env takes precedence)
    source = None
    configured = False
    if env_complete:
        source = "env"
        configured = True
    elif config_complete:
        source = "config"
        configured = True

    return {
        "configured": configured,
        "source": source,
        "config_path": str(CONFIG_PATH),
        "env_vars_set": env_vars_set,
        "has_config_file": has_config_file,
    }


def save_server_mode(
    server_url: str,
    server_provider: str | None = None,
    subdomain: str | None = None,
) -> dict:
    """Save server mode configuration to config file.

    Args:
        server_url: URL of the auth relay server
        server_provider: OAuth provider name on the server (optional)
        subdomain: Zendesk subdomain (optional, for server mode)

    Returns:
        The updated config dict
    """
    config = _load_config_from_file()
    config["mode"] = "server"
    config["server_url"] = server_url
    if server_provider:
        config["server_provider"] = server_provider
    if subdomain:
        config["subdomain"] = subdomain
    _save_config(config)
    return config


def get_server_config() -> dict:
    """Get server mode configuration from environment or config file.

    Returns:
        Dict with mode, server_url, server_provider, and subdomain
    """
    config = _load_config_from_file()
    return {
        "mode": config.get("mode", "local"),
        "server_url": os.environ.get("ZENDESK_SERVER_URL") or config.get("server_url"),
        "server_provider": config.get("server_provider"),
        "subdomain": os.environ.get("ZENDESK_SUBDOMAIN") or config.get("subdomain"),
    }


def clear_server_mode() -> dict:
    """Remove server mode configuration from config file.

    Returns:
        The updated config dict
    """
    config = _load_config_from_file()
    config.pop("mode", None)
    config.pop("server_url", None)
    config.pop("server_provider", None)
    _save_config(config)
    return config


class ZendeskClient:
    """Async HTTP client for Zendesk API."""

    def __init__(
        self,
        email: str | None = None,
        token: str | None = None,
        subdomain: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        auth_provider: Any = None,
    ):
        """Initialize the client.

        Args:
            email: Zendesk email (legacy, backwards compatible)
            token: Zendesk API token (legacy, backwards compatible)
            subdomain: Zendesk subdomain (legacy, backwards compatible)
            timeout: Request timeout in seconds
            auth_provider: An AuthProvider instance. If provided, email/token/subdomain
                are ignored. If not provided and email/token/subdomain are given, a
                TokenAuthProvider is created. If nothing is provided,
                resolve_auth_provider() is called to auto-detect credentials.
        """
        if auth_provider is not None:
            self._auth_provider = auth_provider
        elif email and token and subdomain:
            from zendesk_skill.auth.token_auth import TokenAuthProvider

            self._auth_provider = TokenAuthProvider(
                email=email, token=token, subdomain=subdomain
            )
        else:
            from zendesk_skill.auth.provider import resolve_auth_provider

            self._auth_provider = resolve_auth_provider()

        self.timeout = timeout
        self.base_url = f"https://{self._auth_provider.subdomain}.zendesk.com/api/v2"
        self._http_client: httpx.AsyncClient | None = None

    def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create the persistent HTTP client."""
        if self._http_client is None or self._http_client.is_closed:
            self._http_client = httpx.AsyncClient()
        return self._http_client

    async def close(self) -> None:
        """Close the persistent HTTP client."""
        if self._http_client is not None and not self._http_client.is_closed:
            await self._http_client.aclose()
            self._http_client = None

    def _get_headers(self) -> dict[str, str]:
        """Get headers for API requests."""
        headers = self._auth_provider.get_auth_headers()
        headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        return headers

    async def request(
        self,
        method: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Make an API request to Zendesk.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: API endpoint (without base URL)
            params: Query parameters
            json_data: JSON body data
            timeout: Request timeout override

        Returns:
            Parsed JSON response

        Raises:
            ZendeskAPIError: On API errors
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        client = self._get_http_client()

        try:
            response = await client.request(
                method=method,
                url=url,
                headers=self._get_headers(),
                params=params,
                json=json_data,
                timeout=timeout or self.timeout,
            )
            response.raise_for_status()
            return response.json()

        except httpx.HTTPStatusError as e:
            error_msg = self._format_http_error(e)
            raise ZendeskAPIError(error_msg, e.response.status_code) from e
        except httpx.TimeoutException as e:
            raise ZendeskAPIError(
                "Request timed out. The Zendesk API may be slow or unavailable."
            ) from e
        except httpx.RequestError as e:
            raise ZendeskAPIError(f"Request failed: {e}") from e

    def _format_http_error(self, error: httpx.HTTPStatusError) -> str:
        """Format HTTP error into user-friendly message."""
        status = error.response.status_code

        # Try to extract error details from response
        try:
            data = error.response.json()
            if "error" in data:
                detail = data.get("description", data["error"])
            elif "errors" in data:
                detail = "; ".join(str(e) for e in data["errors"])
            else:
                detail = str(data)
        except Exception:
            detail = error.response.text[:200] if error.response.text else ""

        if status == 401:
            return "Authentication failed. Check your Zendesk email and API token."
        elif status == 403:
            return f"Permission denied. You don't have access to this resource. {detail}"
        elif status == 404:
            return f"Resource not found. {detail}"
        elif status == 422:
            return f"Invalid request: {detail}"
        elif status == 429:
            return "Rate limit exceeded. Please wait before making more requests."
        elif status >= 500:
            return f"Zendesk server error ({status}). Try again later. {detail}"
        else:
            return f"API error ({status}): {detail}"

    async def get(
        self,
        endpoint: str,
        params: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Make a GET request."""
        return await self.request("GET", endpoint, params=params, timeout=timeout)

    async def post(
        self,
        endpoint: str,
        json_data: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Make a POST request."""
        return await self.request("POST", endpoint, json_data=json_data, timeout=timeout)

    async def put(
        self,
        endpoint: str,
        json_data: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Make a PUT request."""
        return await self.request("PUT", endpoint, json_data=json_data, timeout=timeout)

    async def delete(
        self,
        endpoint: str,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Make a DELETE request."""
        return await self.request("DELETE", endpoint, timeout=timeout)

    async def download_file(
        self,
        url: str,
        output_path: Path,
        timeout: float | None = None,
    ) -> Path:
        """Download a file (e.g., attachment) following redirects.

        Args:
            url: URL to download
            output_path: Where to save the file
            timeout: Request timeout override

        Returns:
            Path to downloaded file

        Raises:
            ZendeskAPIError: On download errors
        """
        # Downloads need redirect-following, use a dedicated client
        async with httpx.AsyncClient(
            follow_redirects=True,
            max_redirects=MAX_REDIRECTS,
        ) as download_client:
            try:
                response = await download_client.get(
                    url,
                    headers=self._auth_provider.get_auth_headers(),
                    timeout=timeout or self.timeout,
                )
                response.raise_for_status()

                # Ensure parent directory exists
                output_path.parent.mkdir(parents=True, exist_ok=True)

                # Write file
                with open(output_path, "wb") as f:
                    f.write(response.content)

                return output_path

            except httpx.HTTPStatusError as e:
                error_msg = self._format_http_error(e)
                raise ZendeskAPIError(error_msg, e.response.status_code) from e
            except httpx.TimeoutException as e:
                raise ZendeskAPIError("Download timed out.") from e
            except httpx.RequestError as e:
                raise ZendeskAPIError(f"Download failed: {e}") from e


# Module-level singleton for convenience
_client: ZendeskClient | None = None


def get_client() -> ZendeskClient:
    """Get or create the default Zendesk client singleton."""
    global _client
    if _client is None:
        _client = ZendeskClient()
    return _client


def reset_client() -> None:
    """Reset the client singleton (useful for testing)."""
    global _client
    _client = None
