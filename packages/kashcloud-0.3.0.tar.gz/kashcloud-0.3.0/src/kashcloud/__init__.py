"""KashCloud CLI -- AI terminal + agent infrastructure."""

__version__ = "0.3.0"
