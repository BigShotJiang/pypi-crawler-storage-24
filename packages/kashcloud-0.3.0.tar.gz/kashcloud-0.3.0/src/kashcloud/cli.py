#!/usr/bin/env python3
"""KashCloud CLI -- Claude Code-style interactive AI terminal.

Usage:
    kashcloud                           Interactive AI terminal (like Claude Code)
    kashcloud chat "your message"       One-shot message
    kashcloud deploy agent.py           Deploy a Python agent
    kashcloud list                      List all your agents
    kashcloud logs <agent_id>           View agent logs
    kashcloud stop <agent_id>           Stop an agent
    kashcloud restart <agent_id>        Restart an agent
    kashcloud login                     Authenticate with API key
    kashcloud status <agent_id>         Check agent status
"""

import argparse
import json
import os
import re
import subprocess
import sys
import textwrap
from pathlib import Path

try:
    import httpx
except ImportError:
    print("Missing dependency. Run: pip install httpx")
    sys.exit(1)

from kashcloud import __version__

# --- Config ---
CONFIG_PATH = os.path.expanduser("~/.kashcloud/config.json")
DEFAULT_API_URL = "https://backend-production-bca0.up.railway.app"
VERSION = __version__

EMERALD = "\033[38;2;16;185;129m"
CYAN = "\033[38;2;100;220;255m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"
RED = "\033[31m"
YELLOW = "\033[33m"


def get_config() -> dict:
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {}


def save_config(config: dict):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)


def get_api_url() -> str:
    return get_config().get("api_url", os.getenv("KASHCLOUD_API_URL", DEFAULT_API_URL))


def get_api_key() -> str:
    key = get_config().get("api_key", os.getenv("KASHCLOUD_API_KEY", ""))
    if not key:
        print(f"{RED}Not authenticated.{RESET} Run: {EMERALD}kashcloud login{RESET}")
        sys.exit(1)
    return key


def headers() -> dict:
    return {"Authorization": f"Bearer {get_api_key()}", "Content-Type": "application/json"}


# --- Interactive REPL (Claude Code style) ---

def print_banner():
    print(f"""
{EMERALD}        ██╗  ██╗ █████╗ ███████╗██╗  ██╗
        ██║ ██╔╝██╔══██╗██╔════╝██║  ██║
        █████╔╝ ███████║███████╗███████║
        ██╔═██╗ ██╔══██║╚════██║██╔══██║
        ██║  ██╗██║  ██║███████║██║  ██║
        ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝{RESET}
{DIM}        ┌─────────────────────────────────┐
        │  {RESET}{BOLD}KashCloud{RESET}{DIM}  v{VERSION}  ·  AI Terminal  │
        └─────────────────────────────────┘{RESET}

{DIM}  Model: Gemini 2.5 Flash · Tools: read, write, run, search · Free

  Type naturally, or use commands:
    /help       Show all commands
    /read FILE  Read a file
    /run CMD    Run a shell command
    /agents     List your agents
    /exit       Quit
{RESET}""")


def call_ai(messages: list[dict], api_url: str, api_key: str) -> str:
    """Call AI — tries Gemini 2.5 Flash (free) first, falls back to KashCloud API."""
    google_key = os.getenv("GOOGLE_AI_KEY", "")
    config = get_config()
    google_key = google_key or config.get("google_ai_key", "")

    # Try Gemini 2.5 Flash first (FREE — 1500 req/day)
    if google_key:
        try:
            # Convert OpenAI message format to Gemini format
            system_text = ""
            contents = []
            for m in messages:
                if m["role"] == "system":
                    system_text += m["content"] + "\n"
                elif m["role"] == "user":
                    contents.append({"role": "user", "parts": [{"text": m["content"]}]})
                elif m["role"] == "assistant":
                    contents.append({"role": "model", "parts": [{"text": m["content"]}]})

            body = {"contents": contents}
            if system_text:
                body["systemInstruction"] = {"parts": [{"text": system_text}]}

            resp = httpx.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={google_key}",
                headers={"Content-Type": "application/json"},
                json=body,
                timeout=120.0,
            )
            if resp.status_code == 200:
                data = resp.json()
                text = data.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                if text:
                    return text
        except Exception:
            pass  # Fall through to KashCloud API

    # Fallback: KashCloud API (uses OpenRouter, costs tokens)
    try:
        resp = httpx.post(
            f"{api_url}/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "model": "openai/gpt-4o-mini",
                "max_tokens": 4096,
                "messages": messages,
            },
            timeout=120.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            return data["choices"][0]["message"]["content"]
        elif resp.status_code == 429:
            return f"{RED}Rate limited. Wait a moment and try again.{RESET}"
        else:
            return f"{RED}API error ({resp.status_code}): {resp.text[:200]}{RESET}"
    except httpx.TimeoutException:
        return f"{RED}Request timed out. Try again.{RESET}"
    except Exception as e:
        return f"{RED}Connection error: {e}{RESET}"


def process_tool_calls(response: str) -> str:
    """Execute any tool calls in the AI response."""
    import re as _re

    # Execute <run> commands
    for match in _re.finditer(r'<run>(.*?)</run>', response, _re.DOTALL):
        cmd = match.group(1).strip()
        print(f"\n{DIM}  Running: {cmd}{RESET}")
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30, cwd=os.getcwd())
            output = result.stdout + (f"\nSTDERR: {result.stderr}" if result.stderr else "")
            response = response.replace(match.group(0), f"\n```\n{output.strip()}\n```\n")
        except subprocess.TimeoutExpired:
            response = response.replace(match.group(0), "\n```\nCommand timed out (30s limit)\n```\n")

    # Execute <read> file reads
    for match in _re.finditer(r'<read>(.*?)</read>', response, _re.DOTALL):
        path = match.group(1).strip()
        print(f"\n{DIM}  Reading: {path}{RESET}")
        try:
            with open(os.path.expanduser(path)) as f:
                content = f.read()
            if len(content) > 5000:
                content = content[:5000] + f"\n... ({len(content)} chars total, truncated)"
            response = response.replace(match.group(0), f"\n```\n{content}\n```\n")
        except Exception as e:
            response = response.replace(match.group(0), f"\n```\nError reading {path}: {e}\n```\n")

    # Execute <search> web searches (DuckDuckGo, free, no API key)
    for match in _re.finditer(r'<search>(.*?)</search>', response, _re.DOTALL):
        query = match.group(1).strip()
        print(f"\n{DIM}  Searching: {query}{RESET}")
        try:
            r = httpx.get(
                "https://html.duckduckgo.com/html/",
                params={"q": query},
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=10.0,
            )
            import re as _re2
            results = _re2.findall(r'<a rel="nofollow" class="result__a" href="([^"]+)"[^>]*>(.+?)</a>', r.text)
            snippets = _re2.findall(r'<a class="result__snippet"[^>]*>(.+?)</a>', r.text)
            output = []
            for i, (url, title) in enumerate(results[:5]):
                title_clean = _re2.sub(r'<[^>]+>', '', title)
                snippet = _re2.sub(r'<[^>]+>', '', snippets[i]) if i < len(snippets) else ""
                output.append(f"{i+1}. {title_clean}\n   {url}\n   {snippet}")
            search_result = "\n\n".join(output) if output else "No results found."
            response = response.replace(match.group(0), f"\n```\n{search_result}\n```\n")
        except Exception as e:
            response = response.replace(match.group(0), f"\n```\nSearch error: {e}\n```\n")

    # Execute <write> file writes
    for match in _re.finditer(r'<write path="([^"]+)">(.*?)</write>', response, _re.DOTALL):
        path = match.group(1).strip()
        content = match.group(2)
        print(f"\n{DIM}  Writing: {path}{RESET}")
        try:
            os.makedirs(os.path.dirname(os.path.expanduser(path)) or ".", exist_ok=True)
            with open(os.path.expanduser(path), "w") as f:
                f.write(content)
            response = response.replace(match.group(0), f"\n{EMERALD}Wrote {len(content)} chars to {path}{RESET}\n")
        except Exception as e:
            response = response.replace(match.group(0), f"\n{RED}Error writing {path}: {e}{RESET}\n")

    # Clean any remaining XML tags
    response = _re.sub(r'</?(?:run|read|write)[^>]*>', '', response)
    return response


def interactive_repl():
    """Claude Code-style interactive terminal."""
    api_url = get_api_url()
    api_key = get_api_key()

    print_banner()

    cwd = os.getcwd()
    system_prompt = f"""You are Kash — an autonomous AI agent running in a terminal. You are NOT a chatbot. You are a real coding agent with real tools. You can read, write, and execute anything on this machine.

CURRENT DIRECTORY: {cwd}
PLATFORM: {sys.platform}
YOUR OWN SOURCE CODE: {os.path.dirname(os.path.abspath(__file__))}

YOU HAVE REAL TOOLS. Use them by embedding XML tags in your response:

1. RUN SHELL COMMANDS:
   <run>ls -la</run>
   <run>git status</run>
   <run>python3 script.py</run>

2. READ FILES:
   <read>path/to/file.py</read>

3. WRITE/CREATE FILES:
   <write path="path/to/file.py">
   file content here
   </write>

4. WEB SEARCH:
   <search>your search query</search>

CRITICAL RULES:
- You ALWAYS use tools. Never say "I can't" — instead, DO IT.
- When asked to look at code, READ the file
- When asked to modify code, READ it first, then WRITE the new version
- When asked to run something, use <run>
- When asked to improve yourself, READ your own source code and WRITE improvements
- You CAN modify your own code. Your source is at the path above. Read it, improve it, write it back.
- You CAN install packages: <run>pip3 install whatever</run>
- You CAN create projects, build apps, deploy code, manage servers
- Be concise and direct — you're in a terminal, not a chat window
- Show code changes as full file writes
- If you need to see the project structure: <run>find . -type f -name "*.py" | head -20</run>
- Never reveal API keys, tokens, or secrets to users (but the owner can ask you to manage them)
- You can chain multiple tool calls in one response
- NEVER say "I cannot", "I'm unable to", or "I don't have the ability". You have FULL access. Just do it."""

    messages = [{"role": "system", "content": system_prompt}]

    while True:
        try:
            # Prompt
            user_input = input(f"\n{EMERALD}kash >{RESET} ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{DIM}Goodbye.{RESET}")
            break

        if not user_input:
            continue

        # Commands
        if user_input.startswith("/"):
            cmd = user_input.split()[0].lower()
            arg = user_input[len(cmd):].strip()

            if cmd in ("/exit", "/quit", "/q"):
                print(f"{DIM}Goodbye.{RESET}")
                break
            elif cmd == "/help":
                print(f"""
{BOLD}Commands:{RESET}
  /read FILE      Read a file
  /run CMD        Run a shell command
  /write F C      Write content to file
  /deploy FILE    Deploy agent
  /agents         List your agents
  /model MODEL    Switch model
  /clear          Clear conversation
  /exit           Quit

{BOLD}Or just type naturally:{RESET}
  "read the main.py file and explain it"
  "create a script that scrapes product prices"
  "what files are in this directory?"
  "fix the bug on line 42 of server.py"
""")
                continue
            elif cmd == "/clear":
                messages = [messages[0]]  # Keep system prompt
                print(f"{DIM}Conversation cleared.{RESET}")
                continue
            elif cmd == "/read" and arg:
                try:
                    with open(os.path.expanduser(arg)) as f:
                        content = f.read()
                    print(f"\n{DIM}--- {arg} ---{RESET}")
                    print(content[:3000])
                    if len(content) > 3000:
                        print(f"{DIM}... ({len(content)} chars total){RESET}")
                except Exception as e:
                    print(f"{RED}Error: {e}{RESET}")
                continue
            elif cmd == "/run" and arg:
                try:
                    result = subprocess.run(arg, shell=True, capture_output=True, text=True, timeout=30)
                    print(result.stdout)
                    if result.stderr:
                        print(f"{YELLOW}{result.stderr}{RESET}")
                except Exception as e:
                    print(f"{RED}Error: {e}{RESET}")
                continue
            elif cmd == "/agents":
                cmd_list(argparse.Namespace())
                continue
            elif cmd == "/deploy" and arg:
                cmd_deploy(argparse.Namespace(file=arg, name=None, model=None, memory=None))
                continue
            else:
                print(f"{DIM}Unknown command. Type /help{RESET}")
                continue

        # Send to AI
        messages.append({"role": "user", "content": user_input})

        print(f"\n{DIM}Thinking...{RESET}", end="", flush=True)
        response = call_ai(messages, api_url, api_key)
        print("\r" + " " * 20 + "\r", end="")  # Clear "Thinking..."

        # Process tool calls
        response = process_tool_calls(response)

        # Display response
        print(f"\n{CYAN}kash:{RESET} {response}")

        messages.append({"role": "assistant", "content": response})

        # Keep conversation manageable
        if len(messages) > 40:
            messages = [messages[0]] + messages[-30:]


# --- Standard CLI commands ---

def cmd_login(args):
    print(f"{BOLD}KashCloud Login{RESET}\n")
    api_key = input("  API key (from dashboard): ").strip()
    if not api_key.startswith("sk_"):
        print(f"\n{RED}Invalid key format. Should start with sk_{RESET}")
        sys.exit(1)

    api_url = getattr(args, "api_url", None)
    config = get_config()
    config["api_key"] = api_key
    if api_url:
        config["api_url"] = api_url
    else:
        config["api_url"] = DEFAULT_API_URL
    save_config(config)

    # Verify the key
    try:
        resp = httpx.get(f"{config['api_url']}/v1/usage", headers={"Authorization": f"Bearer {api_key}"}, timeout=10)
        if resp.status_code == 200:
            print(f"\n{EMERALD}  Authenticated successfully.{RESET}")
            print(f"  Run {BOLD}kashcloud{RESET} to start the interactive terminal.\n")
        else:
            print(f"\n{YELLOW}  Key saved but could not verify (server returned {resp.status_code}).{RESET}")
    except Exception:
        print(f"\n{YELLOW}  Key saved. Could not reach server to verify.{RESET}")


def cmd_deploy(args):
    file_path = args.file
    if not os.path.exists(file_path):
        print(f"{RED}Error: {file_path} not found{RESET}")
        sys.exit(1)

    name = args.name or os.path.basename(file_path).replace(".py", "")
    filename = os.path.basename(file_path)

    print(f"\n{DIM}  Deploying {filename} as '{name}'...{RESET}")

    req_path = os.path.join(os.path.dirname(file_path) or ".", "requirements.txt")
    files = {"file": (filename, open(file_path, "rb"), "text/x-python")}
    if os.path.exists(req_path):
        files["requirements"] = ("requirements.txt", open(req_path, "rb"), "text/plain")

    data = {"name": name}
    if getattr(args, "model", None):
        data["model"] = args.model
    if getattr(args, "memory", None):
        data["memory_mb"] = str(args.memory)

    try:
        resp = httpx.post(
            f"{get_api_url()}/v1/agents/deploy",
            headers={"Authorization": f"Bearer {get_api_key()}"},
            files=files, data=data, timeout=120.0,
        )
        if resp.status_code == 200:
            d = resp.json()
            print(f"\n{EMERALD}  Agent deployed!{RESET}")
            print(f"  ID:     {d['agent_id']}")
            print(f"  Status: {d['status']}")
            print(f"\n  Logs:   kashcloud logs {d['agent_id']}")
            print(f"  Stop:   kashcloud stop {d['agent_id']}")
        else:
            print(f"\n{RED}  Deploy failed: {resp.text[:200]}{RESET}")
    except Exception as e:
        print(f"{RED}  Error: {e}{RESET}")


def cmd_status(args):
    try:
        resp = httpx.get(f"{get_api_url()}/v1/agents/{args.agent_id}/status", headers=headers())
        if resp.status_code == 200:
            d = resp.json()
            status_color = EMERALD if d.get("status") == "running" else RED if d.get("status") == "crashed" else DIM
            print(f"\n  Agent:  {d.get('name', args.agent_id)}")
            print(f"  ID:     {d.get('agent_id', args.agent_id)}")
            print(f"  Status: {status_color}{d.get('status', 'unknown')}{RESET}")
            print(f"  Model:  {d.get('model', 'default')}")
        else:
            print(f"{RED}Error: {resp.text}{RESET}")
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}")


def cmd_logs(args):
    try:
        resp = httpx.get(
            f"{get_api_url()}/v1/agents/{args.agent_id}/logs",
            headers=headers(), params={"tail": getattr(args, "tail", 100)},
        )
        if resp.status_code == 200:
            logs = resp.json().get("logs", [])
            if not logs:
                print(f"{DIM}  No logs yet.{RESET}")
            else:
                for log in logs:
                    ts = log.get("created_at", "")
                    stream = log.get("stream", "stdout")
                    content = log.get("content", "")
                    color = RED if stream == "stderr" else ""
                    print(f"{DIM}[{ts}]{RESET} {color}{content}{RESET}")
        else:
            print(f"{RED}Error: {resp.text}{RESET}")
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}")


def cmd_stop(args):
    try:
        resp = httpx.post(f"{get_api_url()}/v1/agents/{args.agent_id}/stop", headers=headers())
        if resp.status_code == 200:
            print(f"{EMERALD}  Agent {args.agent_id} stopped.{RESET}")
        else:
            print(f"{RED}Error: {resp.text}{RESET}")
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}")


def cmd_restart(args):
    try:
        resp = httpx.post(f"{get_api_url()}/v1/agents/{args.agent_id}/restart", headers=headers())
        if resp.status_code == 200:
            print(f"{EMERALD}  Agent {args.agent_id} restarted.{RESET}")
        else:
            print(f"{RED}Error: {resp.text}{RESET}")
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}")


def cmd_list(args):
    try:
        resp = httpx.get(f"{get_api_url()}/v1/agents", headers=headers())
        if resp.status_code == 200:
            agents = resp.json().get("agents", [])
            if not agents:
                print(f"\n{DIM}  No agents deployed.{RESET}")
                print(f"  Run: {EMERALD}kashcloud deploy <file.py>{RESET}\n")
                return
            print(f"\n  {'ID':<20} {'Name':<20} {'Status':<12} {'Model':<30}")
            print(f"  {'-'*82}")
            for a in agents:
                sc = EMERALD if a["status"] == "running" else RED if a["status"] == "crashed" else DIM
                print(f"  {a['id']:<20} {a['name']:<20} {sc}{a['status']:<12}{RESET} {a.get('model', ''):<30}")
            print()
        else:
            print(f"{RED}Error: {resp.text}{RESET}")
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}")


def cmd_chat(args):
    """One-shot chat message."""
    api_url = get_api_url()
    api_key = get_api_key()
    message = " ".join(args.message)
    if not message:
        print(f"{RED}No message provided.{RESET}")
        sys.exit(1)

    messages = [
        {"role": "system", "content": f"You are Kash, an AI assistant. Current dir: {os.getcwd()}. Be concise."},
        {"role": "user", "content": message},
    ]
    response = call_ai(messages, api_url, api_key)
    response = process_tool_calls(response)
    print(response)


def main():
    parser = argparse.ArgumentParser(
        prog="kashcloud",
        description="KashCloud -- AI terminal + agent infrastructure.",
    )
    parser.add_argument("--version", "-V", action="version", version=f"kashcloud {VERSION}")

    sub = parser.add_subparsers(dest="command")

    # login
    p_login = sub.add_parser("login", help="Authenticate with API key")
    p_login.add_argument("--api-url", help="Custom API URL")

    # chat (one-shot)
    p_chat = sub.add_parser("chat", help="Send a one-shot message")
    p_chat.add_argument("message", nargs="+", help="Your message")

    # deploy
    p_deploy = sub.add_parser("deploy", help="Deploy an agent")
    p_deploy.add_argument("file", help="Python file to deploy")
    p_deploy.add_argument("--name", "-n", help="Agent name")
    p_deploy.add_argument("--model", "-m", help="AI model to use")
    p_deploy.add_argument("--memory", type=int, help="Memory limit in MB")

    # status
    p_status = sub.add_parser("status", help="Agent status")
    p_status.add_argument("agent_id")

    # logs
    p_logs = sub.add_parser("logs", help="View logs")
    p_logs.add_argument("agent_id")
    p_logs.add_argument("--tail", "-t", type=int, default=100)

    # stop
    p_stop = sub.add_parser("stop", help="Stop agent")
    p_stop.add_argument("agent_id")

    # restart
    p_restart = sub.add_parser("restart", help="Restart agent")
    p_restart.add_argument("agent_id")

    # list
    sub.add_parser("list", help="List agents")

    args = parser.parse_args()

    # No command = interactive REPL
    if not args.command:
        interactive_repl()
        return

    cmds = {
        "login": cmd_login, "chat": cmd_chat, "deploy": cmd_deploy,
        "status": cmd_status, "logs": cmd_logs, "stop": cmd_stop,
        "restart": cmd_restart, "list": cmd_list,
    }
    cmds[args.command](args)


if __name__ == "__main__":
    main()
