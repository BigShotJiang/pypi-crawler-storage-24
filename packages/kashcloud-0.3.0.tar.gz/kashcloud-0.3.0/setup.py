from setuptools import setup

setup(
    name="kashcloud",
    version="0.2.0",
    description="KashCloud — AI terminal + agent infrastructure. Like Claude Code, but yours.",
    long_description="Interactive AI terminal powered by Claude. Deploy persistent AI agents with one command. Model routing, memory, billing, scaling — all included.",
    author="KashCloud",
    author_email="hello@kashagent.com",
    url="https://kashagent.com/developers",
    py_modules=["main"],
    install_requires=["httpx>=0.28.0"],
    entry_points={"console_scripts": ["kashcloud=main:main"]},
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries",
        "Programming Language :: Python :: 3",
    ],
)
