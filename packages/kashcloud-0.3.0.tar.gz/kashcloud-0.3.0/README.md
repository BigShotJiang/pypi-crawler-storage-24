# KashCloud CLI

AI terminal + agent infrastructure. Like Claude Code, but yours.

## Install

```bash
pip install kashcloud
```

## Quick Start

```bash
# Authenticate
kashcloud login

# Interactive AI terminal (Claude Code-style)
kashcloud

# One-shot message
kashcloud chat "explain this codebase"

# Deploy a persistent AI agent
kashcloud deploy agent.py

# Manage agents
kashcloud list
kashcloud logs <agent_id>
kashcloud stop <agent_id>
kashcloud restart <agent_id>
```

## Interactive Terminal

Running `kashcloud` with no arguments launches an interactive AI terminal powered by Claude. It can:

- Read and write files in your project
- Run shell commands
- Explain and refactor code
- Deploy agents to KashCloud

### Terminal Commands

| Command | Description |
|---------|-------------|
| `/help` | Show all commands |
| `/read FILE` | Read a file |
| `/run CMD` | Run a shell command |
| `/deploy FILE` | Deploy an agent |
| `/agents` | List your agents |
| `/clear` | Clear conversation |
| `/exit` | Quit |

Or just type naturally: *"read main.py and explain it"*, *"fix the bug on line 42"*, *"create a REST API for user management"*.

## Agent Deployment

Deploy persistent Python agents that run 24/7 on KashCloud:

```bash
# Basic deploy
kashcloud deploy my_agent.py

# With options
kashcloud deploy my_agent.py --name "price-tracker" --model claude-sonnet --memory 512
```

Agents get:
- Persistent memory
- Automatic restarts
- Log streaming
- Model routing (cheap/mid/premium)

## Configuration

Config is stored at `~/.kashcloud/config.json`. You can also use environment variables:

- `KASHCLOUD_API_KEY` -- Your API key
- `KASHCLOUD_API_URL` -- Custom API endpoint

## Links

- Website: [kashagent.com](https://kashagent.com)
- Developer docs: [kashagent.com/docs](https://kashagent.com/docs)
- Dashboard: [kashagent.com/dashboard](https://kashagent.com/dashboard)

## License

MIT
