# -*- coding: utf-8 -*-
"""
Structured logging configuration for AtendentePro.

Set ATENDENTEPRO_LOG_FORMAT=json to emit JSON-formatted log lines.
Default is plain text (standard library behaviour).
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone


class JSONFormatter(logging.Formatter):
    """Emit each log record as a single JSON line."""

    def format(self, record: logging.LogRecord) -> str:
        entry = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info and record.exc_info[1] is not None:
            entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(entry, ensure_ascii=False)


_HANDLER_ATTR = "_atendentepro_logging"


def configure_logging() -> None:
    """Apply logging configuration based on environment variables.

    Call once at application startup. Safe to call multiple times (idempotent
    after the first effective call).
    """
    log_format = os.environ.get("ATENDENTEPRO_LOG_FORMAT", "text").strip().lower()
    log_level = os.environ.get("ATENDENTEPRO_LOG_LEVEL", "INFO").strip().upper()

    root = logging.getLogger()
    if any(getattr(h, _HANDLER_ATTR, False) for h in root.handlers):
        return

    handler = logging.StreamHandler()
    if log_format == "json":
        handler.setFormatter(JSONFormatter())
    else:
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))

    setattr(handler, _HANDLER_ATTR, True)
    root.addHandler(handler)
    root.setLevel(getattr(logging, log_level, logging.INFO))
