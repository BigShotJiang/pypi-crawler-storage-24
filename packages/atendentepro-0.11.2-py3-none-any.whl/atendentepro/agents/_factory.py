# -*- coding: utf-8 -*-
"""Shared factory logic for building AtendentePro agents."""

from __future__ import annotations

import logging
from typing import Any, List, Optional

from agents import Agent

from atendentepro.config import RECOMMENDED_PROMPT_PREFIX, SINGLE_REPLY_INSTRUCTION
from atendentepro.models import ContextNote

logger = logging.getLogger(__name__)


def _build_agent(
    *,
    name: str,
    instructions: str,
    handoff_description: str,
    handoffs: Optional[List[Any]] = None,
    tools: Optional[List[Any]] = None,
    guardrails: Optional[List[Any]] = None,
    style_instructions: str = "",
    single_reply: bool = False,
    model: Optional[str] = None,
) -> Agent[ContextNote]:
    """Common factory logic shared by all simple agent creators.

    Parameters
    ----------
    name:
        Display name of the agent.
    instructions:
        Base prompt (already includes any template-specific content).
        ``RECOMMENDED_PROMPT_PREFIX`` is prepended automatically.
    handoff_description:
        Short description shown when this agent is offered as a handoff.
    handoffs / tools / guardrails:
        Optional lists forwarded to the Agent constructor.
    style_instructions:
        Extra style/tone block appended to the prompt.
    single_reply:
        When *True* the ``SINGLE_REPLY_INSTRUCTION`` suffix is appended so
        the agent transfers back to triage after one response.
    model:
        Override the default LLM model for this agent.

    Returns
    -------
    Agent[ContextNote]
        A fully-configured agent instance.
    """
    full_instructions = f"{RECOMMENDED_PROMPT_PREFIX} {instructions}"

    if style_instructions:
        full_instructions += style_instructions

    if single_reply:
        full_instructions += SINGLE_REPLY_INSTRUCTION

    kwargs: dict[str, Any] = dict(
        name=name,
        handoff_description=handoff_description,
        instructions=full_instructions,
        tools=tools or [],
        handoffs=handoffs or [],
        input_guardrails=guardrails or [],
    )

    if model:
        kwargs["model"] = model

    logger.info(
        "Created agent: name=%s, tools=%d, handoffs=%d",
        name,
        len(kwargs["tools"]),
        len(kwargs["handoffs"]),
    )
    return Agent[ContextNote](**kwargs)
