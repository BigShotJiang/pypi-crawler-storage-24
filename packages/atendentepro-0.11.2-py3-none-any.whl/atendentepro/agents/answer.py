# -*- coding: utf-8 -*-
"""Answer Agent for AtendentePro."""

from __future__ import annotations

try:
    from typing import Any, TypeAlias
except ImportError:
    from typing_extensions import TypeAlias  # type: ignore[assignment]

from typing import List, Optional, TYPE_CHECKING

from agents import Agent

from atendentepro.models import ContextNote
from atendentepro.prompts import get_answer_prompt

from ._factory import _build_agent

if TYPE_CHECKING:
    from atendentepro.guardrails import GuardrailCallable


# Type alias for the Answer Agent
AnswerAgent: TypeAlias = Agent[ContextNote]


def create_answer_agent(
    answer_template: str = "",
    handoffs: Optional[List[Any]] = None,
    guardrails: Optional[List["GuardrailCallable"]] = None,
    name: str = "Answer Agent",
    custom_instructions: Optional[str] = None,
    style_instructions: str = "",
    single_reply: bool = False,
    model: Optional[str] = None,
) -> AnswerAgent:
    """
    Create an Answer Agent instance.

    The answer agent synthesizes final responses using collected data
    and the configured answer template.

    Args:
        answer_template: Template for answer formatting.
        handoffs: List of agents to hand off to.
        guardrails: List of input guardrails.
        name: Agent name.
        custom_instructions: Optional custom instructions to override default.
        style_instructions: Optional style/tone instructions to append.
        single_reply: If True, agent responds once then transfers to triage.
        model: LLM model name (e.g. "gpt-4.1", "deepseek-chat"). Uses SDK default if None.

    Returns:
        Configured Answer Agent instance.
    """
    base_instructions = custom_instructions or get_answer_prompt(
        answer_template=answer_template,
    )

    return _build_agent(
        name=name,
        instructions=base_instructions,
        handoff_description=(
            "Agente responsável por sintetizar a resposta técnica final usando os dados coletados. "
            "Após concluir a orientação, deve acionar o handoff para o Triage Agent a fim de encerrar o caso."
        ),
        handoffs=handoffs,
        guardrails=guardrails,
        style_instructions=style_instructions,
        single_reply=single_reply,
        model=model,
    )
