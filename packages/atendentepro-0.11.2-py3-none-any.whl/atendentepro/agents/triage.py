# -*- coding: utf-8 -*-
"""Triage Agent for AtendentePro."""

from __future__ import annotations

try:
    from typing import Any, TypeAlias
except ImportError:
    from typing_extensions import TypeAlias  # type: ignore[assignment]

from typing import List, Optional, TYPE_CHECKING

from agents import Agent

from atendentepro.models import ContextNote
from atendentepro.prompts import get_triage_prompt

from ._factory import _build_agent

if TYPE_CHECKING:
    from atendentepro.guardrails import GuardrailCallable


# Type alias for the Triage Agent
TriageAgent: TypeAlias = Agent[ContextNote]


def create_triage_agent(
    keywords_text: str = "",
    handoffs: Optional[List[Any]] = None,
    guardrails: Optional[List["GuardrailCallable"]] = None,
    name: str = "Triage Agent",
    custom_instructions: Optional[str] = None,
    style_instructions: str = "",
    model: Optional[str] = None,
) -> TriageAgent:
    """
    Create a Triage Agent instance.

    The triage agent is responsible for understanding user needs and
    directing them to the appropriate specialized agent.

    Args:
        keywords_text: Formatted keywords for agent routing.
        handoffs: List of agents to hand off to.
        guardrails: List of input guardrails.
        name: Agent name.
        custom_instructions: Optional custom instructions to override default.
        style_instructions: Optional style/tone instructions to append.
        model: LLM model name (e.g. "gpt-4.1", "deepseek-chat"). Uses SDK default if None.

    Returns:
        Configured Triage Agent instance.
    """
    base_instructions = custom_instructions or get_triage_prompt(keywords_text)

    return _build_agent(
        name=name,
        instructions=base_instructions,
        handoff_description="A triage agent that can delegate a customer's request to the appropriate agent.",
        handoffs=handoffs,
        guardrails=guardrails,
        style_instructions=style_instructions,
        model=model,
    )
