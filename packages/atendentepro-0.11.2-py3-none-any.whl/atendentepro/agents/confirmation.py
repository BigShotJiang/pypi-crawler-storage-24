# -*- coding: utf-8 -*-
"""Confirmation Agent for AtendentePro."""

from __future__ import annotations

try:
    from typing import Any, TypeAlias
except ImportError:
    from typing_extensions import TypeAlias  # type: ignore[assignment]

from typing import List, Optional, TYPE_CHECKING

from agents import Agent

from atendentepro.models import ContextNote
from atendentepro.prompts import get_confirmation_prompt

from ._factory import _build_agent

if TYPE_CHECKING:
    from atendentepro.guardrails import GuardrailCallable


# Type alias for the Confirmation Agent
ConfirmationAgent: TypeAlias = Agent[ContextNote]


def create_confirmation_agent(
    confirmation_about: str = "",
    confirmation_template: str = "",
    confirmation_format: str = "",
    handoffs: Optional[List[Any]] = None,
    guardrails: Optional[List["GuardrailCallable"]] = None,
    name: str = "Confirmation Agent",
    custom_instructions: Optional[str] = None,
    style_instructions: str = "",
    single_reply: bool = False,
    model: Optional[str] = None,
) -> ConfirmationAgent:
    """
    Create a Confirmation Agent instance.

    The confirmation agent validates hypotheses and provides yes/no answers
    with explanations based on configured rules.

    Args:
        confirmation_about: Scope description for confirmation.
        confirmation_template: Template for confirmation logic.
        confirmation_format: Response format template.
        handoffs: List of agents to hand off to.
        guardrails: List of input guardrails.
        name: Agent name.
        custom_instructions: Optional custom instructions to override default.
        style_instructions: Optional style/tone instructions to append.
        single_reply: If True, agent responds once then transfers to triage.
        model: LLM model name (e.g. "gpt-4.1", "deepseek-chat"). Uses SDK default if None.

    Returns:
        Configured Confirmation Agent instance.
    """
    base_instructions = custom_instructions or get_confirmation_prompt(
        confirmation_about=confirmation_about,
        confirmation_template=confirmation_template,
        confirmation_format=confirmation_format,
    )

    return _build_agent(
        name=name,
        instructions=base_instructions,
        handoff_description=(
            "Agente especializado em confirmar ou negar hipóteses específicas do usuário, "
            "explicando o motivo da decisão com base nas regras e políticas conhecidas do produto ou processo."
        ),
        handoffs=handoffs,
        guardrails=guardrails,
        style_instructions=style_instructions,
        single_reply=single_reply,
        model=model,
    )
