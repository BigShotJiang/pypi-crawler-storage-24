# -*- coding: utf-8 -*-
"""
Feedback tool functions: criar_ticket, enviar_email_confirmacao,
consultar_ticket, listar_meus_tickets, atualizar_ticket and FEEDBACK_TOOLS list.
"""

from __future__ import annotations

from agents import function_tool

from .storage import (
    Ticket,
    _allowed_ticket_types,
    _protocol_prefix,
    _gerar_protocolo,
    _salvar_ticket,
    _buscar_ticket,
    _listar_tickets,
    _email_config,
)
from .email import (
    _validar_email,
    _enviar_email,
    _gerar_email_confirmacao,
    _gerar_email_equipe,
    SMTP_CONFIGURED,
    FEEDBACK_EMAIL_DESTINO,
)

# Need to import the storage module itself to read mutable globals
from . import storage as _storage_mod


# =============================================================================
# Feedback Tools
# =============================================================================

@function_tool
def criar_ticket(
    tipo: str,
    descricao: str,
    email_usuario: str,
    nome_usuario: str = "",
    telefone_usuario: str = "",
    prioridade: str = "normal",
    categoria: str = "",
) -> str:
    """
    Cria um ticket de feedback, dúvida, reclamação ou sugestão.

    IMPORTANTE: Esta ferramenta registra solicitações para análise posterior.
    Use quando o usuário quer:
    - Tirar uma dúvida que precisa de pesquisa
    - Enviar feedback sobre produto/serviço
    - Fazer uma reclamação formal
    - Dar uma sugestão de melhoria
    - Fazer um elogio
    - Reportar um problema técnico

    Args:
        tipo: Tipo do ticket. Valores aceitos:
              - "duvida": Pergunta que precisa de pesquisa
              - "feedback": Opinião sobre produto/serviço
              - "reclamacao": Reclamação formal
              - "sugestao": Sugestão de melhoria
              - "elogio": Elogio ou agradecimento
              - "problema": Problema técnico ou bug
        descricao: Descrição detalhada da solicitação (mínimo 10 caracteres)
        email_usuario: Email do usuário para resposta e acompanhamento
        nome_usuario: Nome do usuário (opcional, mas recomendado)
        telefone_usuario: Telefone para contato alternativo (opcional)
        prioridade: Nível de urgência. Valores aceitos:
                   - "baixa": Pode aguardar
                   - "normal": Atendimento padrão (default)
                   - "alta": Requer atenção prioritária
                   - "urgente": Crítico, precisa de ação imediata
        categoria: Categoria adicional do ticket (opcional)

    Returns:
        Confirmação com número do protocolo e detalhes
    """
    # Validar tipo (se allowed_ticket_types estiver configurado)
    tipo_norm = tipo.lower().strip().replace("ã", "a").replace("ç", "c")

    # Read mutable global from storage module
    allowed = _storage_mod._allowed_ticket_types
    if allowed is not None and tipo_norm not in allowed:
        tipos_list = "\n".join(f"- `{t}`" for t in allowed)
        return f"""❌ **Tipo inválido:** {tipo}

📋 **Tipos aceitos:**
{tipos_list}

Por favor, escolha um dos tipos acima."""

    # Validar descrição
    if not descricao or len(descricao.strip()) < 10:
        return "❌ **Descrição muito curta.** Por favor, forneça mais detalhes (mínimo 10 caracteres)."

    # Validar email
    email_norm = email_usuario.strip().lower()
    if not _validar_email(email_norm):
        return f"❌ **Email inválido:** {email_usuario}\n\nPor favor, informe um email válido para que possamos responder."

    # Validar prioridade
    prioridades_validas = ["baixa", "normal", "alta", "urgente"]
    prioridade_norm = prioridade.lower().strip()
    if prioridade_norm not in prioridades_validas:
        prioridade_norm = "normal"

    # Auto-classificar prioridade para reclamações
    if tipo_norm == "reclamacao" and prioridade_norm == "normal":
        prioridade_norm = "alta"

    # Criar ticket
    protocolo = _gerar_protocolo()
    ticket = Ticket(
        protocolo=protocolo,
        tipo=tipo_norm,
        descricao=descricao.strip(),
        email_usuario=email_norm,
        nome_usuario=nome_usuario.strip() if nome_usuario else "",
        telefone_usuario=telefone_usuario.strip() if telefone_usuario else "",
        prioridade=prioridade_norm,
        status="aberto",
        categoria=categoria.strip() if categoria else "",
    )

    ticket.adicionar_historico(
        "Ticket criado",
        f"Tipo: {tipo_norm}, Prioridade: {prioridade_norm}"
    )

    _salvar_ticket(ticket)

    # Ícones
    icone_tipo = {
        "duvida": "❓",
        "feedback": "💬",
        "reclamacao": "📢",
        "sugestao": "💡",
        "elogio": "⭐",
        "problema": "⚠️",
        "outro": "📋",
    }.get(tipo_norm, "📋")

    icone_prioridade = {
        "baixa": "🟢",
        "normal": "🟡",
        "alta": "🟠",
        "urgente": "🔴",
    }.get(prioridade_norm, "🟡")

    tipo_display = {
        "duvida": "Dúvida",
        "feedback": "Feedback",
        "reclamacao": "Reclamação",
        "sugestao": "Sugestão",
        "elogio": "Elogio",
        "problema": "Problema",
        "outro": "Outro",
    }.get(tipo_norm, tipo_norm.title())

    return f"""
✅ **Ticket Criado com Sucesso!**

═══════════════════════════════════════
📋 **Protocolo:** {protocolo}
═══════════════════════════════════════

{icone_tipo} **Tipo:** {tipo_display}
{icone_prioridade} **Prioridade:** {prioridade_norm.upper()}
📅 **Data:** {ticket.data_criacao.strftime('%d/%m/%Y às %H:%M')}

👤 **Dados de Contato:**
- Nome: {nome_usuario or 'Não informado'}
- Email: {email_norm}
- Telefone: {telefone_usuario or 'Não informado'}

📝 **Descrição:**
{descricao[:200]}{'...' if len(descricao) > 200 else ''}

═══════════════════════════════════════

💡 **Guarde o protocolo {protocolo}** para consultar o status.

📧 Use `enviar_email_confirmacao("{protocolo}")` para enviar confirmação ao usuário.
"""


@function_tool
def enviar_email_confirmacao(protocolo: str) -> str:
    """
    Envia email de confirmação do ticket para o usuário.

    IMPORTANTE: Chame esta ferramenta APÓS criar o ticket para
    enviar a confirmação oficial por email.

    Args:
        protocolo: Número do protocolo do ticket (ex: TKT-20240106-ABC123)

    Returns:
        Confirmação do envio ou mensagem de erro
    """
    ticket = _buscar_ticket(protocolo)

    if not ticket:
        prefix = _storage_mod._protocol_prefix
        return f"""❌ **Ticket não encontrado:** {protocolo}

Verifique se o número do protocolo está correto.
Formato esperado: {prefix}-YYYYMMDD-XXXXXX"""

    # Enviar para usuário
    assunto = f"[{_storage_mod._email_config.get('brand_name', 'Atendimento')}] Ticket {ticket.protocolo} - Recebemos sua solicitação"
    corpo_html = _gerar_email_confirmacao(ticket)

    enviado_usuario = _enviar_email(ticket.email_usuario, assunto, corpo_html)

    # Enviar para equipe (se configurado)
    enviado_equipe = False
    if FEEDBACK_EMAIL_DESTINO:
        assunto_equipe = f"[NOVO TICKET] {ticket.tipo.upper()} - {ticket.protocolo}"
        corpo_equipe = _gerar_email_equipe(ticket)
        enviado_equipe = _enviar_email(FEEDBACK_EMAIL_DESTINO, assunto_equipe, corpo_equipe)

    # Registrar no histórico
    _ok = "✅"
    _fail = "❌"
    _fail_noconf = "❌ (não configurado)"
    usuario_status = _ok if enviado_usuario else _fail
    equipe_status = _ok if enviado_equipe else (_fail_noconf if not FEEDBACK_EMAIL_DESTINO else _fail)
    ticket.adicionar_historico(
        "Email de confirmação",
        f"Usuário: {usuario_status}, Equipe: {equipe_status}"
    )
    _salvar_ticket(ticket)

    if enviado_usuario:
        equipe_msg = "📧 Equipe também notificada!" if enviado_equipe else ""
        return f"""✅ **Email de confirmação enviado!**

📧 Destinatário: {ticket.email_usuario}
📋 Protocolo: {ticket.protocolo}
{equipe_msg}

O usuário receberá o email em alguns minutos.
"""
    else:
        return f"""⚠️ **Email não enviado** (SMTP não configurado)

📋 Protocolo: {ticket.protocolo}
📧 Destinatário: {ticket.email_usuario}

💡 Para habilitar envio de emails, configure as variáveis de ambiente:
- SMTP_HOST
- SMTP_PORT
- SMTP_USER
- SMTP_PASSWORD
- SMTP_FROM

O ticket foi criado e pode ser consultado pelo protocolo.
"""


@function_tool
def consultar_ticket(protocolo: str) -> str:
    """
    Consulta detalhes e status de um ticket pelo protocolo.

    Args:
        protocolo: Número do protocolo (ex: TKT-20240106-ABC123, SAC-20240106-XYZ789)

    Returns:
        Detalhes completos do ticket ou mensagem de não encontrado
    """
    ticket = _buscar_ticket(protocolo)

    if not ticket:
        prefix = _storage_mod._protocol_prefix
        return f"""❌ **Ticket não encontrado:** {protocolo}

Verifique se o número do protocolo está correto.
Formato esperado: {prefix}-YYYYMMDD-XXXXXX

💡 Use `listar_meus_tickets("email@exemplo.com")` para ver todos os seus tickets.
"""

    # Ícones
    icone_tipo = {
        "duvida": "❓",
        "feedback": "💬",
        "reclamacao": "📢",
        "sugestao": "💡",
        "elogio": "⭐",
        "problema": "⚠️",
        "outro": "📋",
    }.get(ticket.tipo.lower(), "📋")

    icone_status = {
        "aberto": "🟡",
        "em_andamento": "🔵",
        "aguardando_usuario": "🟠",
        "resolvido": "🟢",
        "fechado": "⚫",
        "cancelado": "🔴",
    }.get(ticket.status.lower(), "⚪")

    icone_prioridade = {
        "baixa": "🟢",
        "normal": "🟡",
        "alta": "🟠",
        "urgente": "🔴",
    }.get(ticket.prioridade.lower(), "🟡")

    tipo_display = ticket.tipo.replace("_", " ").title()
    status_display = ticket.status.replace("_", " ").upper()

    resultado = f"""
📋 **Consulta de Ticket**

═══════════════════════════════════════
🔖 **Protocolo:** {ticket.protocolo}
{icone_status} **Status:** {status_display}
═══════════════════════════════════════

{icone_tipo} **Tipo:** {tipo_display}
{icone_prioridade} **Prioridade:** {ticket.prioridade.upper()}

👤 **Solicitante:**
- Nome: {ticket.nome_usuario or 'Não informado'}
- Email: {ticket.email_usuario}
- Telefone: {ticket.telefone_usuario or 'Não informado'}

📅 **Datas:**
- Criado: {ticket.data_criacao.strftime('%d/%m/%Y às %H:%M')}
- Atualizado: {ticket.data_atualizacao.strftime('%d/%m/%Y às %H:%M')}

📝 **Descrição:**
{ticket.descricao}
"""

    if ticket.resposta:
        resultado += f"""
💬 **Resposta:**
{ticket.resposta}
"""

    if ticket.atendente:
        resultado += f"\n👨‍💼 **Atendente:** {ticket.atendente}"

    if ticket.historico:
        resultado += "\n\n📜 **Histórico:**\n"
        for h in ticket.historico[-5:]:  # Últimos 5 registros
            data = h.get("data", "")[:16].replace("T", " ")
            resultado += f"- [{data}] {h.get('acao', '')}"
            if h.get("detalhes"):
                resultado += f" - {h.get('detalhes')}"
            resultado += "\n"

    return resultado


@function_tool
def listar_meus_tickets(email: str, status: str = "") -> str:
    """
    Lista todos os tickets de um usuário pelo email.

    Args:
        email: Email do usuário
        status: Filtrar por status (opcional): aberto, em_andamento, resolvido, fechado

    Returns:
        Lista de tickets ou mensagem se não houver nenhum
    """
    if not _validar_email(email):
        return f"❌ **Email inválido:** {email}"

    tickets = _listar_tickets(email=email.lower(), status=status if status else None)

    if not tickets:
        msg = f"📭 **Nenhum ticket encontrado** para {email}"
        if status:
            msg += f" com status '{status}'"
        return msg

    resultado = f"""
📋 **Tickets de {email}**

Total: {len(tickets)} ticket(s)
{'Status: ' + status.upper() if status else ''}

═══════════════════════════════════════
"""

    for t in tickets[:10]:  # Mostrar até 10
        icone_status = {
            "aberto": "🟡",
            "em_andamento": "🔵",
            "aguardando_usuario": "🟠",
            "resolvido": "🟢",
            "fechado": "⚫",
            "cancelado": "🔴",
        }.get(t.status.lower(), "⚪")

        icone_tipo = {
            "duvida": "❓",
            "feedback": "💬",
            "reclamacao": "📢",
            "sugestao": "💡",
            "elogio": "⭐",
            "problema": "⚠️",
        }.get(t.tipo.lower(), "📋")

        resultado += f"""
{icone_status} **{t.protocolo}** {icone_tipo}
   📅 {t.data_criacao.strftime('%d/%m/%Y')} | {t.tipo.title()} | {t.status.replace('_', ' ').title()}
   📝 {t.descricao[:50]}{'...' if len(t.descricao) > 50 else ''}
"""

    if len(tickets) > 10:
        resultado += f"\n... e mais {len(tickets) - 10} ticket(s)"

    resultado += "\n═══════════════════════════════════════"
    resultado += "\n💡 Use `consultar_ticket(\"PROTOCOLO\")` para ver detalhes."

    return resultado


@function_tool
def atualizar_ticket(
    protocolo: str,
    status: str = "",
    resposta: str = "",
    atendente: str = "",
) -> str:
    """
    Atualiza o status ou adiciona resposta a um ticket.

    Args:
        protocolo: Número do protocolo do ticket
        status: Novo status (aberto, em_andamento, aguardando_usuario, resolvido, fechado, cancelado)
        resposta: Resposta ou comentário a adicionar
        atendente: Nome do atendente responsável

    Returns:
        Confirmação da atualização
    """
    ticket = _buscar_ticket(protocolo)

    if not ticket:
        return f"❌ **Ticket não encontrado:** {protocolo}"

    atualizacoes = []

    if status:
        status_validos = ["aberto", "em_andamento", "aguardando_usuario", "resolvido", "fechado", "cancelado"]
        status_norm = status.lower().strip().replace(" ", "_")
        if status_norm in status_validos:
            status_anterior = ticket.status
            ticket.status = status_norm
            ticket.adicionar_historico("Status alterado", f"{status_anterior} → {status_norm}")
            atualizacoes.append(f"Status: {status_norm.upper()}")

    if resposta:
        ticket.resposta = resposta.strip()
        ticket.adicionar_historico("Resposta adicionada", resposta[:50] + "...")
        atualizacoes.append("Resposta adicionada")

    if atendente:
        ticket.atendente = atendente.strip()
        ticket.adicionar_historico("Atendente atribuído", atendente)
        atualizacoes.append(f"Atendente: {atendente}")

    if not atualizacoes:
        return "⚠️ Nenhuma atualização fornecida. Informe status, resposta ou atendente."

    _salvar_ticket(ticket)

    return f"""✅ **Ticket atualizado!**

📋 **Protocolo:** {ticket.protocolo}

📝 **Atualizações:**
{chr(10).join('- ' + a for a in atualizacoes)}

📅 **Atualizado em:** {ticket.data_atualizacao.strftime('%d/%m/%Y às %H:%M')}
"""


# =============================================================================
# List of Tools
# =============================================================================

FEEDBACK_TOOLS = [
    criar_ticket,
    enviar_email_confirmacao,
    consultar_ticket,
    listar_meus_tickets,
    atualizar_ticket,
]
