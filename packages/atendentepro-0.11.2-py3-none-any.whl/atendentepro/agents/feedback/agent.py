# -*- coding: utf-8 -*-
"""
Feedback agent factory: create_feedback_agent.
"""

from __future__ import annotations

try:
    from typing import Any, TypeAlias
except ImportError:
    from typing_extensions import TypeAlias  # type: ignore[assignment]

from typing import Optional, List, TYPE_CHECKING

from agents import Agent

from atendentepro.config import RECOMMENDED_PROMPT_PREFIX
from atendentepro.models import ContextNote
from atendentepro.prompts.feedback import (
    get_feedback_prompt,
)

from .storage import configure_feedback_storage
from .tools import FEEDBACK_TOOLS

import logging
logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from atendentepro.guardrails import GuardrailCallable

# Type alias for the Feedback Agent
FeedbackAgent: TypeAlias = Agent[ContextNote]


def create_feedback_agent(
    protocol_prefix: str = "TKT",
    email_brand_color: str = "#4A90D9",
    email_brand_name: str = "Atendimento",
    email_sla_message: str = "Retornaremos em até 24h úteis.",
    ticket_types: Optional[List[str]] = None,
    handoffs: Optional[List[Any]] = None,
    tools: Optional[List[Any]] = None,
    guardrails: Optional[List["GuardrailCallable"]] = None,
    name: str = "Feedback Agent",
    custom_instructions: Optional[str] = None,
    style_instructions: str = "",
    single_reply: bool = False,
    model: Optional[str] = None,
) -> FeedbackAgent:
    """
    Create a Feedback Agent for collecting user feedback, questions, and complaints.

    The feedback agent handles:
    - Questions (dúvidas) that need research
    - Product/service feedback
    - Formal complaints (reclamações)
    - Improvement suggestions
    - Compliments (elogios)
    - Technical problems

    All interactions are tracked with unique protocol numbers.

    Args:
        protocol_prefix: Prefix for ticket protocols (e.g., "SAC", "TKT", "SUP").
        email_brand_color: Hex color for email branding (e.g., "#660099").
        email_brand_name: Brand name shown in emails.
        email_sla_message: SLA message shown in confirmation emails.
        ticket_types: Custom list of allowed ticket types (default: all).
        handoffs: List of agents to hand off to.
        tools: Additional custom tools.
        guardrails: List of input guardrails.
        name: Agent name.
        custom_instructions: Override default instructions.
        style_instructions: Optional style/tone instructions to append.
        single_reply: If True, agent responds once then transfers to triage.

    Returns:
        Configured Feedback Agent instance.

    Example:
        >>> feedback = create_feedback_agent(
        ...     protocol_prefix="SAC",
        ...     email_brand_color="#660099",
        ...     email_brand_name="Vivo Empresas",
        ... )
    """
    # Configure storage settings
    configure_feedback_storage(
        protocol_prefix=protocol_prefix,
        email_brand_color=email_brand_color,
        email_brand_name=email_brand_name,
        email_sla_message=email_sla_message,
        allowed_ticket_types=ticket_types,
    )

    # Build instructions using prompt builder
    if custom_instructions:
        instructions = f"{RECOMMENDED_PROMPT_PREFIX} {custom_instructions}"
    else:
        # Usar o prompt builder do módulo prompts
        instructions = f"{RECOMMENDED_PROMPT_PREFIX}\n{get_feedback_prompt(ticket_types=ticket_types, protocol_prefix=protocol_prefix, brand_name=email_brand_name, sla_message=email_sla_message)}"

    # Append style instructions if provided
    if style_instructions:
        instructions += style_instructions

    # Single reply mode: respond once then return to triage
    if single_reply:
        instructions += "\n\nIMPORTANTE: Após fornecer sua resposta, transfira IMEDIATAMENTE para o triage_agent. Você só pode dar UMA resposta antes de transferir."

    # Combine tools
    agent_tools = list(FEEDBACK_TOOLS)
    if tools:
        agent_tools.extend(tools)

    kwargs: dict = dict(
        name=name,
        handoff_description="Registra dúvidas, feedbacks, reclamações, sugestões e elogios dos usuários através de tickets com protocolo.",
        instructions=instructions,
        tools=agent_tools,
        handoffs=handoffs or [],
        input_guardrails=guardrails or [],
    )
    if model:
        kwargs["model"] = model
    logger.info("Created agent: name=%s, tools=%d, handoffs=%d", kwargs.get("name", "?"), len(kwargs.get("tools", [])), len(kwargs.get("handoffs", [])))
    return Agent[ContextNote](**kwargs)
