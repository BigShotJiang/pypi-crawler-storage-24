# -*- coding: utf-8 -*-
"""
Feedback email layer: SMTP configuration, email validation,
sending and HTML template generators.
"""

from __future__ import annotations

import logging
import os
import re
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional, Dict, Any

from .storage import Ticket, _email_config

logger = logging.getLogger(__name__)


# =============================================================================
# SMTP Configuration
# =============================================================================

# SMTP configuration from environment
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("SMTP_FROM", "sac@empresa.com")
FEEDBACK_EMAIL_DESTINO = os.getenv("FEEDBACK_EMAIL_DESTINO", "")

# Validate SMTP at import time and expose status (issue #28)
SMTP_CONFIGURED = bool(SMTP_USER and SMTP_PASSWORD)
if not SMTP_CONFIGURED:
    logger.warning(
        "SMTP not configured (SMTP_USER/SMTP_PASSWORD missing). "
        "Feedback emails will be disabled. Set env vars to enable."
    )
elif not FEEDBACK_EMAIL_DESTINO:
    logger.warning(
        "FEEDBACK_EMAIL_DESTINO not set. Feedback emails will have no default destination."
    )


# =============================================================================
# Email Helpers
# =============================================================================

def _validar_email(email: str) -> bool:
    """Validate email format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def _enviar_email(
    destinatario: str,
    assunto: str,
    corpo_html: str,
    corpo_texto: Optional[str] = None,
) -> bool:
    """
    Send email via SMTP.

    Returns:
        True if sent successfully, False otherwise
    """
    if not SMTP_CONFIGURED:
        logger.warning("SMTP not configured — email not sent")
        return False

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = assunto
        msg["From"] = SMTP_FROM
        msg["To"] = destinatario

        if corpo_texto:
            part_texto = MIMEText(corpo_texto, "plain", "utf-8")
            msg.attach(part_texto)

        part_html = MIMEText(corpo_html, "html", "utf-8")
        msg.attach(part_html)

        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)

        logger.info("Email enviado para destinatário")
        return True

    except Exception as e:
        logger.warning("Erro ao enviar email: %s", e)
        return False


def _gerar_email_confirmacao(ticket: Ticket) -> str:
    """Generate HTML email template for ticket confirmation."""
    tipo_display = {
        "duvida": "Dúvida",
        "feedback": "Feedback",
        "reclamacao": "Reclamação",
        "sugestao": "Sugestão",
        "elogio": "Elogio",
        "problema": "Problema",
        "outro": "Outro",
    }.get(ticket.tipo.lower(), ticket.tipo.title())

    prioridade_display = {
        "baixa": "🟢 Baixa",
        "normal": "🟡 Normal",
        "alta": "🟠 Alta",
        "urgente": "🔴 Urgente",
    }.get(ticket.prioridade.lower(), ticket.prioridade.title())

    nome = ticket.nome_usuario or "Cliente"
    brand_color = _email_config.get("brand_color", "#4A90D9")
    brand_name = _email_config.get("brand_name", "Atendimento")
    sla_message = _email_config.get("sla_message", "Retornaremos em breve.")

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #f5f5f5; padding: 20px;">
    <div style="background-color: {brand_color}; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="margin: 0; font-size: 24px;">{brand_name}</h1>
        <p style="margin: 10px 0 0 0; opacity: 0.9;">Ticket Registrado com Sucesso</p>
    </div>

    <div style="background-color: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <p style="font-size: 16px; color: #333;">Olá <strong>{nome}</strong>,</p>

        <p style="color: #666;">Recebemos sua solicitação e ela foi registrada com sucesso!</p>

        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid {brand_color};">
            <table style="width: 100%; border-collapse: collapse;">
                <tr>
                    <td style="padding: 8px 0; color: #666;">📋 Protocolo:</td>
                    <td style="padding: 8px 0; font-weight: bold; color: {brand_color};">{ticket.protocolo}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; color: #666;">📌 Tipo:</td>
                    <td style="padding: 8px 0;">{tipo_display}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; color: #666;">⚡ Prioridade:</td>
                    <td style="padding: 8px 0;">{prioridade_display}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; color: #666;">📅 Data:</td>
                    <td style="padding: 8px 0;">{ticket.data_criacao.strftime('%d/%m/%Y às %H:%M')}</td>
                </tr>
            </table>
        </div>

        <div style="background-color: #fff; padding: 15px; border: 1px solid #e0e0e0; border-radius: 8px; margin: 20px 0;">
            <p style="color: #666; margin: 0 0 10px 0; font-weight: bold;">📝 Descrição:</p>
            <p style="color: #333; margin: 0; line-height: 1.6;">{ticket.descricao}</p>
        </div>

        <p style="color: #666; font-size: 14px;">{sla_message}</p>

        <p style="color: #888; font-size: 13px; margin-top: 25px;">
            💡 Guarde o protocolo <strong>{ticket.protocolo}</strong> para acompanhamento.
        </p>

        <hr style="border: none; border-top: 1px solid #eee; margin: 25px 0;">

        <p style="color: #999; font-size: 12px; text-align: center; margin: 0;">
            Este email foi enviado automaticamente. Por favor, não responda.
        </p>
    </div>
</body>
</html>
"""


def _gerar_email_equipe(ticket: Ticket) -> str:
    """Generate HTML email template for team notification."""
    tipo_display = {
        "duvida": "❓ Dúvida",
        "feedback": "💬 Feedback",
        "reclamacao": "📢 Reclamação",
        "sugestao": "💡 Sugestão",
        "elogio": "⭐ Elogio",
        "problema": "⚠️ Problema",
        "outro": "📋 Outro",
    }.get(ticket.tipo.lower(), ticket.tipo.title())

    prioridade_colors = {
        "baixa": "#28a745",
        "normal": "#ffc107",
        "alta": "#fd7e14",
        "urgente": "#dc3545",
    }
    prioridade_color = prioridade_colors.get(ticket.prioridade.lower(), "#6c757d")

    brand_color = _email_config.get("brand_color", "#4A90D9")
    brand_name = _email_config.get("brand_name", "Atendimento")

    return f"""
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="background-color: {brand_color}; color: white; padding: 20px; text-align: center;">
        <h2 style="margin: 0;">🎫 Novo Ticket - {brand_name}</h2>
    </div>

    <div style="padding: 20px; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 15px;">
            <h3 style="margin: 0 0 15px 0; color: #333;">
                {tipo_display}
                <span style="background-color: {prioridade_color}; color: white; padding: 3px 10px; border-radius: 4px; font-size: 12px; margin-left: 10px;">
                    {ticket.prioridade.upper()}
                </span>
            </h3>

            <table style="width: 100%;">
                <tr>
                    <td style="padding: 5px 0; color: #666; width: 120px;">Protocolo:</td>
                    <td style="padding: 5px 0; font-weight: bold;">{ticket.protocolo}</td>
                </tr>
                <tr>
                    <td style="padding: 5px 0; color: #666;">Nome:</td>
                    <td style="padding: 5px 0;">{ticket.nome_usuario or 'Não informado'}</td>
                </tr>
                <tr>
                    <td style="padding: 5px 0; color: #666;">Email:</td>
                    <td style="padding: 5px 0;"><a href="mailto:{ticket.email_usuario}">{ticket.email_usuario}</a></td>
                </tr>
                <tr>
                    <td style="padding: 5px 0; color: #666;">Telefone:</td>
                    <td style="padding: 5px 0;">{ticket.telefone_usuario or 'Não informado'}</td>
                </tr>
                <tr>
                    <td style="padding: 5px 0; color: #666;">Data:</td>
                    <td style="padding: 5px 0;">{ticket.data_criacao.strftime('%d/%m/%Y às %H:%M')}</td>
                </tr>
            </table>
        </div>

        <div style="background-color: white; padding: 20px; border-radius: 8px;">
            <h4 style="margin: 0 0 10px 0; color: #666;">📝 Descrição:</h4>
            <p style="margin: 0; color: #333; line-height: 1.6; white-space: pre-wrap;">{ticket.descricao}</p>
        </div>
    </div>
</body>
</html>
"""
