# -*- coding: utf-8 -*-
"""
Feedback storage layer: Ticket dataclass, in-memory + JSON persistence,
protocol generation and configuration.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)


# =============================================================================
# Enums for Ticket Properties
# =============================================================================

class TicketType(str, Enum):
    """Default ticket types."""
    DUVIDA = "duvida"
    FEEDBACK = "feedback"
    RECLAMACAO = "reclamacao"
    SUGESTAO = "sugestao"
    ELOGIO = "elogio"
    PROBLEMA = "problema"
    OUTRO = "outro"


class TicketPriority(str, Enum):
    """Ticket priority levels."""
    BAIXA = "baixa"
    NORMAL = "normal"
    ALTA = "alta"
    URGENTE = "urgente"


class TicketStatus(str, Enum):
    """Ticket status states."""
    ABERTO = "aberto"
    EM_ANDAMENTO = "em_andamento"
    AGUARDANDO = "aguardando_usuario"
    RESOLVIDO = "resolvido"
    FECHADO = "fechado"
    CANCELADO = "cancelado"


# =============================================================================
# Ticket Data Model
# =============================================================================

@dataclass
class Ticket:
    """Represents a feedback/support ticket."""
    protocolo: str
    tipo: str
    descricao: str
    email_usuario: str
    nome_usuario: str = ""
    telefone_usuario: str = ""
    prioridade: str = "normal"
    status: str = "aberto"
    categoria: str = ""
    data_criacao: datetime = field(default_factory=datetime.now)
    data_atualizacao: datetime = field(default_factory=datetime.now)
    resposta: Optional[str] = None
    atendente: Optional[str] = None
    historico: List[Dict[str, Any]] = field(default_factory=list)

    def adicionar_historico(self, acao: str, detalhes: str = "") -> None:
        """Add entry to ticket history."""
        self.historico.append({
            "data": datetime.now().isoformat(),
            "acao": acao,
            "detalhes": detalhes,
        })
        self.data_atualizacao = datetime.now()


# =============================================================================
# Storage (in-memory + JSON file persistence)
# =============================================================================

_tickets_storage: Dict[str, Ticket] = {}

# Protocol prefix (can be customized per client)
_protocol_prefix: str = "TKT"

# Allowed ticket types (None = accept any type)
_allowed_ticket_types: Optional[List[str]] = None

# Storage path for persistence
_storage_path: Optional[Path] = None

# Email configuration
_email_config: Dict[str, Any] = {
    "enabled": True,
    "brand_color": "#4A90D9",
    "brand_name": "Atendimento",
    "sla_message": "Retornaremos em até 24h úteis.",
}


def configure_feedback_storage(
    protocol_prefix: str = "TKT",
    email_brand_color: str = "#4A90D9",
    email_brand_name: str = "Atendimento",
    email_sla_message: str = "Retornaremos em até 24h úteis.",
    allowed_ticket_types: Optional[List[str]] = None,
    storage_path: Optional[Path] = None,
) -> None:
    """
    Configure feedback storage settings.

    Args:
        protocol_prefix: Prefix for ticket protocols (e.g., "SAC", "TKT", "SUP")
        email_brand_color: Hex color for email template branding
        email_brand_name: Brand name for email template
        email_sla_message: SLA message shown in confirmation email
        allowed_ticket_types: List of allowed ticket types (None = accept any)
        storage_path: Path to JSON file for persistence (None = use default or env var)
    """
    global _protocol_prefix, _email_config, _allowed_ticket_types, _storage_path
    _protocol_prefix = protocol_prefix
    _email_config.update({
        "brand_color": email_brand_color,
        "brand_name": email_brand_name,
        "sla_message": email_sla_message,
    })
    _allowed_ticket_types = allowed_ticket_types

    # Set storage path from parameter, env var, or default
    if storage_path:
        _storage_path = Path(storage_path)
    else:
        env_path = os.getenv("FEEDBACK_STORAGE_PATH")
        if env_path:
            _storage_path = Path(env_path)
        else:
            # Default: current working directory
            _storage_path = Path.cwd() / "feedback_tickets.json"


def _get_storage_path() -> Path:
    """Get the storage path, initializing default if needed."""
    global _storage_path
    if _storage_path is None:
        env_path = os.getenv("FEEDBACK_STORAGE_PATH")
        if env_path:
            _storage_path = Path(env_path)
        else:
            _storage_path = Path.cwd() / "feedback_tickets.json"
    return _storage_path


def _load_tickets_from_file() -> None:
    """Load tickets from JSON file into memory."""
    global _tickets_storage
    storage_path = _get_storage_path()

    if not storage_path.exists():
        return

    try:
        with open(storage_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        tickets_data = data.get("tickets", {})
        _tickets_storage = {}

        for protocolo, ticket_data in tickets_data.items():
            # Convert dict back to Ticket dataclass
            ticket_data["data_criacao"] = datetime.fromisoformat(ticket_data["data_criacao"])
            ticket_data["data_atualizacao"] = datetime.fromisoformat(ticket_data["data_atualizacao"])
            _tickets_storage[protocolo.upper()] = Ticket(**ticket_data)
    except Exception as e:
        logger.warning("Erro ao carregar tickets do arquivo: %s", e)


def _save_tickets_to_file() -> None:
    """Save tickets from memory to JSON file."""
    global _tickets_storage
    storage_path = _get_storage_path()

    try:
        # Convert tickets to dict for JSON serialization
        tickets_data = {}
        for protocolo, ticket in _tickets_storage.items():
            ticket_dict = {
                "protocolo": ticket.protocolo,
                "tipo": ticket.tipo,
                "descricao": ticket.descricao,
                "email_usuario": ticket.email_usuario,
                "nome_usuario": ticket.nome_usuario,
                "telefone_usuario": ticket.telefone_usuario,
                "prioridade": ticket.prioridade,
                "status": ticket.status,
                "categoria": ticket.categoria,
                "data_criacao": ticket.data_criacao.isoformat(),
                "data_atualizacao": ticket.data_atualizacao.isoformat(),
                "resposta": ticket.resposta,
                "atendente": ticket.atendente,
                "historico": ticket.historico,
            }
            tickets_data[protocolo.upper()] = ticket_dict

        data = {"tickets": tickets_data}

        # Ensure directory exists
        storage_path.parent.mkdir(parents=True, exist_ok=True)

        with open(storage_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.warning("Erro ao salvar tickets no arquivo: %s", e)


def _gerar_protocolo() -> str:
    """Generate unique ticket protocol."""
    timestamp = datetime.now().strftime("%Y%m%d")
    unique_id = uuid.uuid4().hex[:6].upper()
    return f"{_protocol_prefix}-{timestamp}-{unique_id}"


def _salvar_ticket(ticket: Ticket) -> None:
    """Save ticket to storage (memory + file)."""
    _tickets_storage[ticket.protocolo.upper()] = ticket
    _save_tickets_to_file()


def _buscar_ticket(protocolo: str) -> Optional[Ticket]:
    """Find ticket by protocol."""
    # Load from file if storage is empty
    if not _tickets_storage:
        _load_tickets_from_file()
    return _tickets_storage.get(protocolo.upper())


def _listar_tickets(email: Optional[str] = None, status: Optional[str] = None) -> List[Ticket]:
    """List tickets, optionally filtered."""
    # Load from file if storage is empty
    if not _tickets_storage:
        _load_tickets_from_file()

    tickets = list(_tickets_storage.values())

    if email:
        tickets = [t for t in tickets if t.email_usuario.lower() == email.lower()]

    if status:
        tickets = [t for t in tickets if t.status.lower() == status.lower()]

    return sorted(tickets, key=lambda x: x.data_criacao, reverse=True)
