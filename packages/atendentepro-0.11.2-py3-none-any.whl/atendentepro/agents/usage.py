# -*- coding: utf-8 -*-
"""Usage Agent for AtendentePro."""

from __future__ import annotations

try:
    from typing import Any, TypeAlias
except ImportError:
    from typing_extensions import TypeAlias  # type: ignore[assignment]

from typing import List, Optional, TYPE_CHECKING

from agents import Agent

from atendentepro.models import ContextNote

from ._factory import _build_agent

if TYPE_CHECKING:
    from atendentepro.guardrails import GuardrailCallable


# Type alias for the Usage Agent
UsageAgent: TypeAlias = Agent[ContextNote]


DEFAULT_USAGE_INSTRUCTIONS = """
You are a helpful usage agent. You will answer questions about the usage of the system.
Respond in natural language and never mention internal agents, transfers, or reasoning steps.
"""


def create_usage_agent(
    handoffs: Optional[List[Any]] = None,
    guardrails: Optional[List["GuardrailCallable"]] = None,
    name: str = "Usage Agent",
    custom_instructions: Optional[str] = None,
    style_instructions: str = "",
    single_reply: bool = False,
    model: Optional[str] = None,
) -> UsageAgent:
    """
    Create a Usage Agent instance.

    The usage agent answers questions about system usage.

    Args:
        handoffs: List of agents to hand off to.
        guardrails: List of input guardrails.
        name: Agent name.
        custom_instructions: Optional custom instructions to override default.
        style_instructions: Optional style/tone instructions to append.
        single_reply: If True, agent responds once then transfers to triage.
        model: LLM model name (e.g. "gpt-4.1", "deepseek-chat"). Uses SDK default if None.

    Returns:
        Configured Usage Agent instance.
    """
    base_instructions = custom_instructions or DEFAULT_USAGE_INSTRUCTIONS

    return _build_agent(
        name=name,
        instructions=base_instructions,
        handoff_description="A usage agent that can answer questions about the usage of the system.",
        handoffs=handoffs,
        guardrails=guardrails,
        style_instructions=style_instructions,
        single_reply=single_reply,
        model=model,
    )
