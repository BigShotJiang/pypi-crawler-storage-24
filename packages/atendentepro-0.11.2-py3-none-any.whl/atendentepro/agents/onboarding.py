# -*- coding: utf-8 -*-
"""Onboarding Agent for AtendentePro."""

from __future__ import annotations

try:
    from typing import Any, TypeAlias
except ImportError:
    from typing_extensions import TypeAlias  # type: ignore[assignment]

from typing import List, Optional, TYPE_CHECKING

from agents import Agent

from atendentepro.models import ContextNote
from atendentepro.prompts import get_onboarding_prompt
from atendentepro.prompts.onboarding import OnboardingField

from ._factory import _build_agent

if TYPE_CHECKING:
    from atendentepro.guardrails import GuardrailCallable


# Type alias for the Onboarding Agent
OnboardingAgent: TypeAlias = Agent[ContextNote]


def create_onboarding_agent(
    required_fields: Optional[List[OnboardingField]] = None,
    handoffs: Optional[List[Any]] = None,
    tools: Optional[List[Any]] = None,
    guardrails: Optional[List["GuardrailCallable"]] = None,
    name: str = "Onboarding Agent",
    custom_instructions: Optional[str] = None,
    style_instructions: str = "",
    single_reply: bool = False,
    model: Optional[str] = None,
) -> OnboardingAgent:
    """
    Create an Onboarding Agent instance.

    The onboarding agent welcomes new users and guides them through
    the registration process.

    Args:
        required_fields: List of required fields for onboarding.
        handoffs: List of agents to hand off to.
        tools: List of tools available to the agent (e.g., find_user_on_csv).
        guardrails: List of input guardrails.
        name: Agent name.
        custom_instructions: Optional custom instructions to override default.
        style_instructions: Optional style/tone instructions to append.
        single_reply: If True, agent responds once then transfers to triage.
        model: LLM model name (e.g. "gpt-4.1", "deepseek-chat"). Uses SDK default if None.

    Returns:
        Configured Onboarding Agent instance.
    """
    base_instructions = custom_instructions or get_onboarding_prompt(
        required_fields=required_fields,
    )

    return _build_agent(
        name=name,
        instructions=base_instructions,
        handoff_description=(
            "Agente de onboarding responsável por acolher usuários não encontrados no cadastro "
            "e orientar o registro inicial."
        ),
        handoffs=handoffs,
        tools=tools,
        guardrails=guardrails,
        style_instructions=style_instructions,
        single_reply=single_reply,
        model=model,
    )
