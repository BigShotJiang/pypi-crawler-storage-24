# -*- coding: utf-8 -*-
"""Flow Agent for AtendentePro."""

from __future__ import annotations

try:
    from typing import Any, TypeAlias
except ImportError:
    from typing_extensions import TypeAlias  # type: ignore[assignment]

from typing import List, Optional, TYPE_CHECKING

from agents import Agent

from atendentepro.models import ContextNote
from atendentepro.prompts import get_flow_prompt

from ._factory import _build_agent

if TYPE_CHECKING:
    from atendentepro.guardrails import GuardrailCallable


# Type alias for the Flow Agent
FlowAgent: TypeAlias = Agent[ContextNote]


def create_flow_agent(
    flow_template: str = "",
    flow_keywords: str = "",
    handoffs: Optional[List[Any]] = None,
    guardrails: Optional[List["GuardrailCallable"]] = None,
    name: str = "Flow Agent",
    custom_instructions: Optional[str] = None,
    style_instructions: str = "",
    single_reply: bool = False,
    model: Optional[str] = None,
) -> FlowAgent:
    """
    Create a Flow Agent instance.

    The flow agent identifies topics and routes users to the interview agent.

    Args:
        flow_template: Template with available topics.
        flow_keywords: Keywords for topic identification.
        handoffs: List of agents to hand off to.
        guardrails: List of input guardrails.
        name: Agent name.
        custom_instructions: Optional custom instructions to override default.
        style_instructions: Optional style/tone instructions to append.
        single_reply: If True, agent responds once then transfers to triage.
        model: LLM model name (e.g. "gpt-4.1", "deepseek-chat"). Uses SDK default if None.

    Returns:
        Configured Flow Agent instance.
    """
    base_instructions = custom_instructions or get_flow_prompt(
        flow_template=flow_template, flow_keywords=flow_keywords,
    )

    return _build_agent(
        name=name,
        instructions=base_instructions,
        handoff_description="""
        Um agente de fluxo inteligente que:
        1. Se o usuário já especificou um tópico específico, vai direto para o interview_agent
        2. Se não especificou, apresenta a lista de tópicos para o usuário escolher
        3. Só transfere para triage se a resposta não for clara o suficiente
        """,
        handoffs=handoffs,
        guardrails=guardrails,
        style_instructions=style_instructions,
        single_reply=single_reply,
        model=model,
    )
