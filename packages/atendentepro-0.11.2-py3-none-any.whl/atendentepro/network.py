# -*- coding: utf-8 -*-
"""
Agent Network for AtendentePro.

Provides functions to create and configure the agent network with proper handoffs.
"""

from __future__ import annotations

import logging
import os
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, Union, cast, overload


# =============================================================================
# Agent Style Configuration
# =============================================================================

@dataclass
class AgentStyle:
    """
    Configuration for agent conversation style and tone.
    
    Allows customizing how agents communicate with users,
    including tone, language style, response length, and custom rules.
    
    Attributes:
        tone: Conversation tone (e.g., "profissional", "empático", "consultivo")
        language_style: Language formality ("formal", "informal", "neutro")
        response_length: Response verbosity ("conciso", "moderado", "detalhado")
        custom_rules: Additional custom rules as text
        
    Example:
        >>> style = AgentStyle(
        ...     tone="empático e acolhedor",
        ...     language_style="formal",
        ...     response_length="moderado",
        ...     custom_rules="Sempre se apresente como assistente da empresa."
        ... )
        >>> print(style.build_style_prompt())
    """
    
    tone: str = ""
    language_style: str = ""  # formal, informal, neutro
    response_length: str = ""  # conciso, moderado, detalhado
    custom_rules: str = ""
    
    def build_style_prompt(self) -> str:
        """
        Build style instructions to append to agent prompts.
        
        Returns:
            Formatted style instructions as a string.
        """
        parts = []
        
        if self.tone:
            parts.append(f"**Tom de conversa:** {self.tone}.")
        
        if self.language_style:
            style_map = {
                "formal": "Use linguagem formal e respeitosa, evitando gírias e expressões coloquiais.",
                "informal": "Use linguagem informal e descontraída, aproximando-se do usuário.",
                "neutro": "Use linguagem neutra e objetiva, focando na clareza.",
            }
            instruction = style_map.get(
                self.language_style.lower(), 
                f"Estilo de linguagem: {self.language_style}"
            )
            parts.append(f"**Linguagem:** {instruction}")
        
        if self.response_length:
            length_map = {
                "conciso": "Seja conciso e direto nas respostas, evitando informações desnecessárias.",
                "moderado": "Forneça respostas com nível médio de detalhe, equilibrando clareza e completude.",
                "detalhado": "Forneça respostas detalhadas e completas, explicando cada ponto relevante.",
            }
            instruction = length_map.get(
                self.response_length.lower(),
                f"Tamanho das respostas: {self.response_length}"
            )
            parts.append(f"**Respostas:** {instruction}")
        
        if self.custom_rules:
            parts.append(f"**Regras adicionais:**\n{self.custom_rules}")
        
        if not parts:
            return ""
        
        return "\n\n## Estilo de Comunicação\n" + "\n\n".join(parts)

@dataclass
class NetworkConfig:
    """
    Configuration object for create_standard_network().

    Groups the many parameters of ``create_standard_network()`` into a single,
    documented dataclass.  Callers can build a ``NetworkConfig`` and pass it
    directly, which is the recommended approach for new code.

    The legacy keyword-argument interface is still supported for backward
    compatibility.

    Example::

        cfg = NetworkConfig(
            templates_root=Path("./client_templates"),
            client="my_client",
            include_onboarding=True,
            global_style=AgentStyle(tone="profissional"),
        )
        network = create_standard_network(config=cfg)
    """

    # --- required -----------------------------------------------------------
    templates_root: Path = field(default_factory=lambda: Path("."))
    client: str = "standard"

    # --- agent inclusion flags ----------------------------------------------
    include_flow: bool = True
    include_interview: bool = True
    include_answer: bool = True
    include_knowledge: bool = True
    include_confirmation: bool = True
    include_usage: bool = True
    include_onboarding: bool = False
    include_escalation: bool = True
    include_feedback: bool = True

    # --- agent-specific configuration ---------------------------------------
    escalation_channels: str = ""
    feedback_protocol_prefix: str = "TKT"
    feedback_brand_color: str = "#4A90D9"
    feedback_brand_name: str = "Atendimento"
    feedback_storage_path: Optional[Path] = None
    custom_tools: Optional[Dict[str, List]] = None

    # --- style configuration ------------------------------------------------
    global_style: Optional[AgentStyle] = None
    agent_styles: Optional[Dict[str, AgentStyle]] = None
    load_style_from_template: bool = True
    triage_custom_instructions: Optional[str] = None

    # --- single reply mode --------------------------------------------------
    global_single_reply: bool = False
    single_reply_agents: Optional[Dict[str, bool]] = None

    # --- access filtering ---------------------------------------------------
    user_context: Optional[Any] = None  # UserContext (avoid import cycle at class level)
    agent_filters: Optional[Dict[str, Any]] = None  # Dict[str, AccessFilter]
    conditional_prompts: Optional[Dict[str, List[Any]]] = None  # Dict[str, List[FilteredPromptSection]]
    filtered_tools: Optional[Dict[str, List[Any]]] = None  # Dict[str, List[FilteredTool]]
    require_user_context_when_filtered: Optional[bool] = None
    require_guardrails_config: Optional[bool] = None

    # --- user loading -------------------------------------------------------
    user_loader: Optional[Callable] = None
    auto_load_user: bool = False

    # --- model configuration ------------------------------------------------
    agent_models: Optional[Dict[str, str]] = None


from atendentepro.agents import (
    create_triage_agent,
    create_flow_agent,
    create_interview_agent,
    create_answer_agent,
    create_knowledge_agent,
    create_confirmation_agent,
    create_usage_agent,
    create_onboarding_agent,
    create_escalation_agent,
    create_feedback_agent,
    configure_feedback_storage,
    TriageAgent,
    FlowAgent,
    InterviewAgent,
    AnswerAgent,
    KnowledgeAgent,
    ConfirmationAgent,
    UsageAgent,
    OnboardingAgent,
    EscalationAgent,
    FeedbackAgent,
)
from atendentepro.config import get_config
from atendentepro.guardrails import get_guardrails_for_agent, load_guardrail_config, set_guardrails_client
from atendentepro.license import require_activation
from atendentepro.templates import (
    TemplateManager,
    AgentStyleConfig,
    configure_template_manager,
    load_flow_config,
    load_interview_config,
    load_triage_config,
    load_knowledge_config,
    load_confirmation_config,
    load_onboarding_config,
    load_access_config,
    load_feedback_config,
    load_escalation_config,
    load_answer_config,
    load_style_config,
    AccessConfig,
    AccessFilterConfig,
)
from atendentepro.models import (
    UserContext,
    AccessFilter,
    AccessFilterResolver,
    FilteredPromptSection,
    FilteredTool,
)


def _agent_style_config_to_agent_style(cfg: AgentStyleConfig) -> AgentStyle:
    """Map template AgentStyleConfig to network AgentStyle (same fields)."""
    return AgentStyle(
        tone=cfg.tone,
        language_style=cfg.language_style,
        response_length=cfg.response_length,
        custom_rules=cfg.custom_rules,
    )


@dataclass
class AgentNetwork:
    """
    Container for all agents in the network.
    
    Provides access to individual agents and methods to configure
    the network for different clients.
    """
    
    triage: Optional[TriageAgent] = None
    flow: Optional[FlowAgent] = None
    interview: Optional[InterviewAgent] = None
    answer: Optional[AnswerAgent] = None
    knowledge: Optional[KnowledgeAgent] = None
    confirmation: Optional[ConfirmationAgent] = None
    usage: Optional[UsageAgent] = None
    onboarding: Optional[OnboardingAgent] = None
    escalation: Optional[EscalationAgent] = None
    feedback: Optional[FeedbackAgent] = None
    
    templates_root: Optional[Path] = None
    current_client: str = "standard"
    
    # User loading
    user_loader: Optional[Callable[[List], Optional["UserContext"]]] = None
    loaded_user_context: Optional["UserContext"] = None
    
    def get_all_agents(self) -> List:
        """Get list of all configured agents."""
        agents = []
        for attr in ["triage", "flow", "interview", "answer", "knowledge", 
                     "confirmation", "usage", "onboarding", "escalation", "feedback"]:
            agent = getattr(self, attr, None)
            if agent:
                agents.append(agent)
        return agents
    
    def add_escalation_to_all(self) -> None:
        """Add escalation agent as handoff to all other agents."""
        if not self.escalation:
            return
        
        for agent in self.get_all_agents():
            if agent != self.escalation and self.escalation not in agent.handoffs:
                agent.handoffs.append(self.escalation)
    
    def add_feedback_to_all(self) -> None:
        """Add feedback agent as handoff to all other agents."""
        if not self.feedback:
            return
        
        for agent in self.get_all_agents():
            if agent != self.feedback and self.feedback not in agent.handoffs:
                agent.handoffs.append(self.feedback)


def create_standard_network(
    templates_root: Optional[Path] = None,
    client: str = "standard",
    # Agents to include
    include_flow: bool = True,
    include_interview: bool = True,
    include_answer: bool = True,
    include_knowledge: bool = True,
    include_confirmation: bool = True,
    include_usage: bool = True,
    include_onboarding: bool = False,
    include_escalation: bool = True,
    include_feedback: bool = True,
    # Agent-specific configurations
    escalation_channels: str = "",
    feedback_protocol_prefix: str = "TKT",
    feedback_brand_color: str = "#4A90D9",
    feedback_brand_name: str = "Atendimento",
    feedback_storage_path: Optional[Path] = None,
    custom_tools: Optional[Dict[str, List]] = None,
    # Style configuration
    global_style: Optional[AgentStyle] = None,
    agent_styles: Optional[Dict[str, AgentStyle]] = None,
    load_style_from_template: bool = True,
    triage_custom_instructions: Optional[str] = None,
    # Single reply mode (auto-return to triage after one response)
    global_single_reply: bool = False,
    single_reply_agents: Optional[Dict[str, bool]] = None,
    # Access filtering (role/user based)
    user_context: Optional[UserContext] = None,
    agent_filters: Optional[Dict[str, AccessFilter]] = None,
    conditional_prompts: Optional[Dict[str, List[FilteredPromptSection]]] = None,
    filtered_tools: Optional[Dict[str, List[FilteredTool]]] = None,
    require_user_context_when_filtered: Optional[bool] = None,
    require_guardrails_config: Optional[bool] = None,
    # User loading
    user_loader: Optional[Callable[[List], Optional[UserContext]]] = None,
    auto_load_user: bool = False,
    # Model configuration
    agent_models: Optional[Dict[str, str]] = None,
    # --- NEW: config object (preferred) ---
    config: Optional[NetworkConfig] = None,
) -> AgentNetwork:
    """
    Create a standard agent network with proper handoff configuration.
    
    This creates a configurable network where you can enable/disable specific agents.
    The Triage agent is always included as it's the entry point.
    
    Default handoff configuration (when all agents are enabled):
    - Triage -> Flow, Confirmation, Knowledge, Usage, Escalation, Feedback
    - Flow -> Interview, Triage, Escalation, Feedback
    - Interview -> Answer, Escalation, Feedback
    - Answer -> Triage, Escalation, Feedback
    - Confirmation -> Triage, Escalation, Feedback
    - Knowledge -> Triage, Escalation, Feedback
    - Usage -> Triage, Escalation, Feedback
    - Escalation -> Triage, Feedback
    - Feedback -> Triage, Escalation
    
    Args:
        templates_root: Root directory for template configurations.
        client: Client key to load configurations for.
        include_flow: Whether to include the flow agent (default True).
        include_interview: Whether to include the interview agent (default True).
        include_answer: Whether to include the answer agent (default True).
        include_knowledge: Whether to include the knowledge agent (default True).
        include_confirmation: Whether to include the confirmation agent (default True).
        include_usage: Whether to include the usage agent (default True).
        include_onboarding: Whether to include the onboarding agent (default False).
        include_escalation: Whether to include the escalation agent (default True).
        include_feedback: Whether to include the feedback agent (default True).
        escalation_channels: Description of available escalation channels.
        feedback_protocol_prefix: Prefix for ticket protocols (e.g., "SAC", "TKT").
        feedback_brand_color: Brand color for feedback emails.
        feedback_brand_name: Brand name for feedback emails.
        feedback_storage_path: Path to JSON file for ticket persistence. Defaults to
            `<templates_root>/<client>/tickets.json`. Set to an absolute Path to
            store tickets in a custom location.
        custom_tools: Optional dict of custom tools by agent name.
        global_style: Style configuration applied to all agents (tone, language, etc.).
        agent_styles: Dict mapping agent names to specific styles (overrides global).
        load_style_from_template: If True (default), merge ``style_config.yaml`` for this
            client with explicit ``global_style`` / ``agent_styles``. Explicit arguments
            override YAML when both are set.
        triage_custom_instructions: If set, replaces the default triage body from
            ``get_triage_prompt`` (keywords from ``triage_config.yaml`` are not injected
            into the prompt in that case; embed any routing hints in this string if needed).
        global_single_reply: If True, all agents respond once then transfer to triage.
        single_reply_agents: Dict mapping agent names to single_reply mode (overrides global).
        user_context: User context for access filtering (user_id, role, metadata).
        agent_filters: Dict mapping agent names to AccessFilter (controls agent access).
        conditional_prompts: Dict mapping agent names to list of FilteredPromptSection.
        filtered_tools: Dict mapping agent names to list of FilteredTool.
        require_user_context_when_filtered: If True, or if None and env
                    ATENDENTEPRO_REQUIRE_USER_CONTEXT is set, raise when access filters
                    are configured but user_context is None. Use in production so
                    filters take effect.
        require_guardrails_config: If True, or if None and env
                    ATENDENTEPRO_REQUIRE_GUARDRAILS is set, log at ERROR if
                    guardrails_config.yaml is missing or has no scope for Triage.
        user_loader: Optional function to load user data from a persistent source (e.g. DB)
                    from messages. Should return UserContext with user_id, role, and metadata
                    (profile/statistics). Do not use for session_id or memory; use
                    session_id_factory or run_with_memory params for those. Loading can be
                    restricted to one agent: call run_with_user_context or run_with_memory
                    only for that agent (e.g. flow); run others with Runner.run without loader.
                    See create_user_loader().
        auto_load_user: If True, automatically loads user context before agent execution.
                        Requires user_loader to be configured.
        agent_models: Optional dict mapping agent names to model strings for per-agent
                    model selection (e.g. {"triage": "gpt-4.1-mini", "knowledge": "gpt-4.1"}).
                    Overrides the global default_model from config for the specified agents.
        
    Returns:
        Configured AgentNetwork instance.
        
    Raises:
        LicenseNotActivatedError: If the library is not activated.
        
    Example:
        # Create network without Knowledge agent
        network = create_standard_network(
            templates_root=Path("templates"),
            client="my_client",
            include_knowledge=False,
        )
        
        # Create network with role-based access filtering
        from atendentepro import UserContext, AccessFilter, FilteredPromptSection
        
        user = UserContext(user_id="user123", role="vendedor")
        
        network = create_standard_network(
            templates_root=Path("templates"),
            client="my_client",
            user_context=user,
            agent_filters={
                "knowledge": AccessFilter(allowed_roles=["admin", "vendedor"]),
                "escalation": AccessFilter(denied_roles=["cliente"]),
            },
            conditional_prompts={
                "knowledge": [
                    FilteredPromptSection(
                        content="\\n## Descontos\\nVocê pode oferecer até 15% de desconto.",
                        filter=AccessFilter(allowed_roles=["vendedor"]),
                    ),
                ],
            },
        )
        
        # Create network with custom communication style
        network = create_standard_network(
            templates_root=Path("templates"),
            client="my_client",
            global_style=AgentStyle(
                tone="profissional e consultivo",
                language_style="formal",
                response_length="moderado",
            ),
        )
    """
    # --- Resolve config: NetworkConfig takes precedence, kwargs are fallback ---
    if config is not None:
        templates_root = templates_root if templates_root is not None else config.templates_root
        client = client if client != "standard" else config.client
        include_flow = config.include_flow
        include_interview = config.include_interview
        include_answer = config.include_answer
        include_knowledge = config.include_knowledge
        include_confirmation = config.include_confirmation
        include_usage = config.include_usage
        include_onboarding = config.include_onboarding
        include_escalation = config.include_escalation
        include_feedback = config.include_feedback
        escalation_channels = config.escalation_channels
        feedback_protocol_prefix = config.feedback_protocol_prefix
        feedback_brand_color = config.feedback_brand_color
        feedback_brand_name = config.feedback_brand_name
        feedback_storage_path = config.feedback_storage_path if feedback_storage_path is None else feedback_storage_path
        custom_tools = config.custom_tools if custom_tools is None else custom_tools
        global_style = config.global_style if global_style is None else global_style
        agent_styles = config.agent_styles if agent_styles is None else agent_styles
        load_style_from_template = config.load_style_from_template
        triage_custom_instructions = config.triage_custom_instructions if triage_custom_instructions is None else triage_custom_instructions
        global_single_reply = config.global_single_reply
        single_reply_agents = config.single_reply_agents if single_reply_agents is None else single_reply_agents
        user_context = config.user_context if user_context is None else user_context
        agent_filters = config.agent_filters if agent_filters is None else agent_filters
        conditional_prompts = config.conditional_prompts if conditional_prompts is None else conditional_prompts
        filtered_tools = config.filtered_tools if filtered_tools is None else filtered_tools
        require_user_context_when_filtered = config.require_user_context_when_filtered if require_user_context_when_filtered is None else require_user_context_when_filtered
        require_guardrails_config = config.require_guardrails_config if require_guardrails_config is None else require_guardrails_config
        user_loader = config.user_loader if user_loader is None else user_loader
        auto_load_user = config.auto_load_user
        agent_models = config.agent_models if agent_models is None else agent_models

    # Ensure templates_root is set (required)
    if templates_root is None:
        raise TypeError("templates_root is required: pass it directly or via NetworkConfig.")

    # Verificar licença
    require_activation()

    # Configure template manager
    manager = configure_template_manager(templates_root, default_client=client)
    
    # Load access config from YAML if not provided via code
    yaml_access_config = None
    try:
        yaml_access_config = load_access_config(client)
    except FileNotFoundError:
        pass
    
    # Production: require user_context when any access filter is active
    _has_agent_filters = bool(agent_filters and len(agent_filters) > 0)
    _has_yaml_filters = False
    if yaml_access_config:
        _has_yaml_filters = (
            bool(yaml_access_config.agent_filters and len(yaml_access_config.agent_filters) > 0)
            or bool(yaml_access_config.conditional_prompts and len(yaml_access_config.conditional_prompts) > 0)
            or bool(yaml_access_config.tool_access and len(yaml_access_config.tool_access) > 0)
        )
    _has_active_filters = _has_agent_filters or _has_yaml_filters
    _require_ctx = require_user_context_when_filtered
    if _require_ctx is None:
        _require_ctx = (os.environ.get("ATENDENTEPRO_REQUIRE_USER_CONTEXT") or "").strip().lower() in ("1", "true", "yes")
    if _require_ctx and _has_active_filters and user_context is None:
        raise ValueError(
            "Filtros de acesso estao configurados (agent_filters, access_config.yaml ou filtered_tools), "
            "mas user_context nao foi fornecido. Em producao, passe user_context por request ou use "
            "user_loader que retorna contexto. Defina ATENDENTEPRO_REQUIRE_USER_CONTEXT=1 ou "
            "require_user_context_when_filtered=True para exigir contexto quando ha filtros."
        )
    
    # Production: require guardrails config (scope for at least Triage)
    _require_guardrails = require_guardrails_config
    if _require_guardrails is None:
        _require_guardrails = (os.environ.get("ATENDENTEPRO_REQUIRE_GUARDRAILS") or "").strip().lower() in ("1", "true", "yes")
    if _require_guardrails:
        _guardrail_log = logging.getLogger(__name__)
        _gr_config = load_guardrail_config(templates_root, client)
        _scopes = _gr_config.get("agent_scopes") or {}
        _triage_about = (_scopes.get("triage_agent") or {}).get("about") or ""
        if not _triage_about.strip():
            for _k, _v in _scopes.items():
                if isinstance(_v, dict) and ("triage" in _k.lower() or _k.lower() == "triage"):
                    _triage_about = (_v.get("about") or "").strip()
                    break
            if not _triage_about:
                _guardrail_log.error(
                    "ATENDENTEPRO_REQUIRE_GUARDRAILS ativo: guardrails_config.yaml nao encontrado ou sem "
                    "escopo para Triage (agent_scopes.triage_agent.about). Configure guardrails para producao."
                )
    
    # Unified access filter resolver
    _access_resolver = AccessFilterResolver(
        user_context=user_context,
        agent_filters=agent_filters,
        conditional_prompts=conditional_prompts,
        filtered_tools=filtered_tools,
        yaml_access_config=yaml_access_config,
    )

    # Thin wrappers kept for backward compatibility within this module
    def is_agent_allowed(agent_name: str) -> bool:
        """Check if agent should be included based on user context."""
        return _access_resolver.is_agent_allowed(agent_name)

    def get_conditional_prompts_for_agent(agent_name: str) -> str:
        """Get all allowed conditional prompt sections for an agent."""
        return _access_resolver.get_conditional_content(agent_name)

    def get_filtered_tools_for_agent(agent_name: str, base_tools: List) -> List:
        """Get tools filtered by user context."""
        return _access_resolver.get_filtered_tools(agent_name, base_tools)
    
    # Load configurations
    try:
        flow_config = load_flow_config(client)
        flow_template = flow_config.get_flow_template()
        flow_keywords = flow_config.get_flow_keywords()
    except FileNotFoundError:
        flow_template = ""
        flow_keywords = ""
    
    try:
        interview_config = load_interview_config(client)
        interview_questions = interview_config.interview_questions
    except FileNotFoundError:
        interview_questions = ""
    
    try:
        triage_config = load_triage_config(client)
        triage_keywords = triage_config.get_keywords_text()
    except FileNotFoundError:
        triage_keywords = ""
    
    try:
        knowledge_config = load_knowledge_config(client)
        knowledge_about = knowledge_config.about
        knowledge_template = knowledge_config.template
        knowledge_format = knowledge_config.format
        knowledge_instructions = knowledge_config.instructions
        _rag = knowledge_config.rag_config
        rag_max_results = _rag.max_results if _rag else None
        rag_similarity_threshold = _rag.similarity_threshold if _rag else None
        embeddings_path = (
            Path(knowledge_config.embeddings_path) 
            if knowledge_config.embeddings_path 
            else None
        )
        data_sources_description = knowledge_config.get_data_source_description()
        has_embeddings = knowledge_config.has_documents()
    except FileNotFoundError:
        knowledge_about = ""
        knowledge_template = ""
        knowledge_format = ""
        knowledge_instructions = ""
        rag_max_results = None
        rag_similarity_threshold = None
        embeddings_path = None
        data_sources_description = ""
        has_embeddings = False
    
    try:
        confirmation_config = load_confirmation_config(client)
        confirmation_about = confirmation_config.about
        confirmation_template = confirmation_config.template
        confirmation_format = confirmation_config.format
    except FileNotFoundError:
        confirmation_about = ""
        confirmation_template = ""
        confirmation_format = ""
    
    # Load feedback config
    try:
        feedback_config = load_feedback_config(client)
        feedback_protocol_prefix = feedback_config.protocol_prefix
        feedback_email_config = feedback_config.email
        feedback_ticket_types = feedback_config.get_ticket_type_names()
    except FileNotFoundError:
        feedback_protocol_prefix = feedback_protocol_prefix  # Use parameter default
        feedback_email_config = {}
        feedback_ticket_types = None
    
    # Load escalation config
    escalation_config_loaded = False
    try:
        escalation_config = load_escalation_config(client)
        escalation_business_hours = escalation_config.business_hours
        escalation_priority_keywords = escalation_config.priority
        escalation_triggers = escalation_config.triggers
        escalation_channels_config = escalation_config.channels
        escalation_config_loaded = True
    except FileNotFoundError:
        escalation_business_hours = None
        escalation_priority_keywords = {}
        escalation_triggers = {}
        escalation_channels_config = None
    
    # Load answer config
    try:
        answer_config = load_answer_config(client)
        answer_template = answer_config.get_answer_template()
    except FileNotFoundError:
        answer_template = ""
    
    # Load guardrails
    try:
        set_guardrails_client(client, templates_root=templates_root)
    except FileNotFoundError:
        pass
    
    # Get custom tools
    tools = custom_tools or {}
    
    # Merge style_config.yaml with explicit global_style / agent_styles (explicit wins)
    _effective_global: Optional[AgentStyle] = None
    _effective_agent_styles: Dict[str, AgentStyle] = {}
    if load_style_from_template:
        try:
            _style_cfg = load_style_config(client)
            _effective_global = _agent_style_config_to_agent_style(_style_cfg.global_style)
            for _name, _cfg in _style_cfg.agents.items():
                _effective_agent_styles[_name] = _agent_style_config_to_agent_style(_cfg)
        except FileNotFoundError:
            pass
    if global_style is not None:
        _effective_global = global_style
    if agent_styles:
        for _name, _style in agent_styles.items():
            _effective_agent_styles[_name] = _style
    
    # Style helper function
    def get_style_for_agent(agent_name: str) -> str:
        """Get style instructions for a specific agent."""
        if _effective_agent_styles and agent_name in _effective_agent_styles:
            return _effective_agent_styles[agent_name].build_style_prompt()
        if _effective_global:
            return _effective_global.build_style_prompt()
        return ""
    
    # Model helper function
    _config = get_config()
    _agent_models = agent_models or {}
    
    def get_model_for_agent(agent_name: str) -> Optional[str]:
        """Get model for a specific agent (per-agent override > global default_model)."""
        if agent_name in _agent_models:
            return _agent_models[agent_name]
        return _config.default_model
    
    # Single reply helper function
    def get_single_reply_for_agent(agent_name: str) -> bool:
        """Get single_reply setting for a specific agent."""
        # Agent-specific setting takes precedence
        if single_reply_agents and agent_name in single_reply_agents:
            return single_reply_agents[agent_name]
        # Fall back to global setting
        return global_single_reply
    
    # Helper to build full style instructions with conditional prompts
    def get_full_instructions(agent_name: str) -> str:
        """Get style + conditional prompt instructions for an agent."""
        style = get_style_for_agent(agent_name)
        conditional = get_conditional_prompts_for_agent(agent_name)
        return f"{style}{conditional}" if conditional else style
    
    # Create agents without handoffs first
    # Triage is always created (entry point)
    triage = create_triage_agent(
        keywords_text=triage_keywords,
        guardrails=get_guardrails_for_agent("Triage Agent", templates_root),
        style_instructions=get_full_instructions("triage"),
        model=get_model_for_agent("triage"),
        custom_instructions=triage_custom_instructions,
    )
    
    # Create optional agents based on include flags AND access filters
    flow = None
    if include_flow and is_agent_allowed("flow"):
        flow = create_flow_agent(
            flow_template=flow_template,
            flow_keywords=flow_keywords,
            guardrails=get_guardrails_for_agent("Flow Agent", templates_root),
            style_instructions=get_full_instructions("flow"),
            single_reply=get_single_reply_for_agent("flow"),
            model=get_model_for_agent("flow"),
        )
    
    interview = None
    if include_interview and is_agent_allowed("interview"):
        interview = create_interview_agent(
            interview_template=flow_template,
            interview_questions=interview_questions,
            tools=get_filtered_tools_for_agent("interview", tools.get("interview", [])),
            guardrails=get_guardrails_for_agent("Interview Agent", templates_root),
            style_instructions=get_full_instructions("interview"),
            single_reply=get_single_reply_for_agent("interview"),
            model=get_model_for_agent("interview"),
        )
    
    answer = None
    if include_answer and is_agent_allowed("answer"):
        answer = create_answer_agent(
            answer_template=answer_template,
            guardrails=get_guardrails_for_agent("Answer Agent", templates_root),
            style_instructions=get_full_instructions("answer"),
            single_reply=get_single_reply_for_agent("answer"),
            model=get_model_for_agent("answer"),
        )
    
    knowledge = None
    if include_knowledge and is_agent_allowed("knowledge"):
        knowledge = create_knowledge_agent(
            knowledge_about=knowledge_about,
            knowledge_template=knowledge_template,
            knowledge_format=knowledge_format,
            knowledge_instructions=knowledge_instructions,
            embeddings_path=embeddings_path,
            data_sources_description=data_sources_description,
            rag_max_results=rag_max_results,
            rag_similarity_threshold=rag_similarity_threshold,
            include_rag_tool=has_embeddings,
            tools=get_filtered_tools_for_agent("knowledge", tools.get("knowledge", [])),
            guardrails=get_guardrails_for_agent("Knowledge Agent", templates_root),
            style_instructions=get_full_instructions("knowledge"),
            single_reply=get_single_reply_for_agent("knowledge"),
            model=get_model_for_agent("knowledge"),
        )
    
    confirmation = None
    if include_confirmation and is_agent_allowed("confirmation"):
        confirmation = create_confirmation_agent(
            confirmation_about=confirmation_about,
            confirmation_template=confirmation_template,
            confirmation_format=confirmation_format,
            guardrails=get_guardrails_for_agent("Confirmation Agent", templates_root),
            style_instructions=get_full_instructions("confirmation"),
            single_reply=get_single_reply_for_agent("confirmation"),
            model=get_model_for_agent("confirmation"),
        )
    
    usage = None
    if include_usage and is_agent_allowed("usage"):
        usage = create_usage_agent(
            guardrails=get_guardrails_for_agent("Usage Agent", templates_root),
            style_instructions=get_full_instructions("usage"),
            single_reply=get_single_reply_for_agent("usage"),
            model=get_model_for_agent("usage"),
        )
    
    # Create escalation agent if requested and allowed
    escalation = None
    if include_escalation and is_agent_allowed("escalation"):
        # Format escalation triggers from config
        triggers_text = ""
        if escalation_triggers:
            trigger_parts = []
            if escalation_triggers.get("explicit_request"):
                trigger_parts.append(f"Pedidos explícitos: {', '.join(escalation_triggers['explicit_request'])}")
            if escalation_triggers.get("frustration"):
                trigger_parts.append(f"Indicadores de frustração: {', '.join(escalation_triggers['frustration'])}")
            if escalation_triggers.get("topics_requiring_human"):
                trigger_parts.append(f"Tópicos que requerem humano: {', '.join(escalation_triggers['topics_requiring_human'])}")
            triggers_text = "\n".join(trigger_parts) if trigger_parts else ""
        
        # Format escalation channels from config or use parameter
        if escalation_config_loaded and escalation_channels_config:
            # Format from config dict
            channel_parts = []
            if escalation_channels_config.get("phone", {}).get("enabled"):
                phone = escalation_channels_config["phone"]
                channel_parts.append(f"Telefone: {phone.get('number', '')} ({phone.get('hours', '')})")
            if escalation_channels_config.get("email", {}).get("enabled"):
                email = escalation_channels_config["email"]
                channel_parts.append(f"Email: {email.get('address', '')} ({email.get('sla', '')})")
            if escalation_channels_config.get("whatsapp", {}).get("enabled"):
                whatsapp = escalation_channels_config["whatsapp"]
                channel_parts.append(f"WhatsApp: {whatsapp.get('number', '')} ({whatsapp.get('hours', '')})")
            if channel_parts:
                channels_text = " | ".join(channel_parts)
            else:
                channels_text = escalation_channels  # Use parameter default
        else:
            channels_text = escalation_channels  # Use parameter default
        
        escalation = create_escalation_agent(
            escalation_triggers=triggers_text,
            escalation_channels=channels_text if isinstance(channels_text, str) else escalation_channels,
            business_hours=escalation_business_hours,
            priority_keywords_urgent=escalation_priority_keywords.get("urgent"),
            priority_keywords_high=escalation_priority_keywords.get("high"),
            tools=get_filtered_tools_for_agent("escalation", tools.get("escalation", [])),
            guardrails=get_guardrails_for_agent("Escalation Agent", templates_root),
            style_instructions=get_full_instructions("escalation"),
            single_reply=get_single_reply_for_agent("escalation"),
            model=get_model_for_agent("escalation"),
        )
    
    # Create feedback agent if requested and allowed
    feedback = None
    if include_feedback and is_agent_allowed("feedback"):
        # Use email config from YAML if available, otherwise use parameters
        email_color = feedback_email_config.get("brand_color", feedback_brand_color)
        email_name = feedback_email_config.get("brand_name", feedback_brand_name)
        email_sla = feedback_email_config.get("sla_message", "Retornaremos em até 24h úteis.")
        
        feedback = create_feedback_agent(
            protocol_prefix=feedback_protocol_prefix,
            email_brand_color=email_color,
            email_brand_name=email_name,
            email_sla_message=email_sla,
            ticket_types=feedback_ticket_types,
            tools=get_filtered_tools_for_agent("feedback", tools.get("feedback", [])),
            guardrails=get_guardrails_for_agent("Feedback Agent", templates_root),
            style_instructions=get_full_instructions("feedback"),
            single_reply=get_single_reply_for_agent("feedback"),
            model=get_model_for_agent("feedback"),
        )
        # Configure client-specific storage path for ticket persistence
        _storage = feedback_storage_path or (templates_root / client / "tickets.json")
        configure_feedback_storage(
            protocol_prefix=feedback_protocol_prefix,
            email_brand_color=email_color,
            email_brand_name=email_name,
            email_sla_message=email_sla,
            allowed_ticket_types=feedback_ticket_types,
            storage_path=_storage,
        )
    
    # Configure handoffs dynamically based on which agents are included
    # Helper function to filter None values
    Handoff = Union[TriageAgent, FlowAgent, InterviewAgent, AnswerAgent,
                     KnowledgeAgent, ConfirmationAgent, UsageAgent,
                     OnboardingAgent, EscalationAgent, FeedbackAgent]

    # Declarative handoff graph (issue #20)
    # Each key maps to its base handoff targets. Escalation and feedback
    # are appended automatically to all agents when enabled.
    _HANDOFF_GRAPH: Dict[str, List[str]] = {
        "triage":       ["flow", "interview", "confirmation", "knowledge", "usage"],
        "flow":         ["interview", "triage"],
        "interview":    ["answer", "knowledge"],
        "answer":       ["triage", "confirmation"],
        "confirmation": ["triage"],
        "knowledge":    ["triage", "flow"],
        "usage":        ["triage"],
        "escalation":   ["triage"],
        "feedback":     ["triage"],
    }

    agents_map: Dict[str, Optional[Handoff]] = {
        "triage": triage, "flow": flow, "interview": interview,
        "answer": answer, "knowledge": knowledge, "confirmation": confirmation,
        "usage": usage, "escalation": escalation, "feedback": feedback,
    }

    # Resolve graph: build handoff lists from declarative config
    for agent_name, target_names in _HANDOFF_GRAPH.items():
        agent = agents_map.get(agent_name)
        if agent is None:
            continue

        handoffs: List[Handoff] = [
            agents_map[t] for t in target_names
            if agents_map.get(t) is not None
        ]

        # Append escalation and feedback to all agents (when enabled)
        if escalation and agent_name != "escalation" and escalation not in handoffs:
            handoffs.append(escalation)
        if feedback and agent_name != "feedback" and feedback not in handoffs:
            handoffs.append(feedback)

        if agent_name == "triage":
            triage.handoffs = handoffs  # type: ignore[attr-defined]
        elif agent_name == "interview":
            agent.handoffs = cast(list, handoffs)
        else:
            agent.handoffs = handoffs
    
    network = AgentNetwork(
        triage=triage,
        flow=flow,
        interview=interview,
        answer=answer,
        knowledge=knowledge,
        confirmation=confirmation,
        usage=usage,
        escalation=escalation,
        feedback=feedback,
        templates_root=templates_root,
        current_client=client,
    )
    
    # Add onboarding if requested
    if include_onboarding and is_agent_allowed("onboarding"):
        try:
            onboarding_config = load_onboarding_config(client)
            from atendentepro.prompts.onboarding import OnboardingField as PromptField
            
            fields = [
                PromptField(
                    name=f.name,
                    prompt=f.prompt,
                    priority=f.priority,
                )
                for f in onboarding_config.required_fields
            ]
        except FileNotFoundError:
            fields = []
        
        onboarding = create_onboarding_agent(
            required_fields=fields,
            tools=get_filtered_tools_for_agent("onboarding", tools.get("onboarding", [])),
            guardrails=get_guardrails_for_agent("Onboarding Agent", templates_root),
            style_instructions=get_full_instructions("onboarding"),
            single_reply=get_single_reply_for_agent("onboarding"),
            model=get_model_for_agent("onboarding"),
        )
        
        network.onboarding = onboarding
        onboarding.handoffs = [triage]  # type: ignore[attr-defined]
    
    # Store user_loader in network for later use
    network.user_loader = user_loader
    
    return network


def create_custom_network(
    templates_root: Path,
    client: str,
    network_config: Dict[str, List[str]],
    custom_tools: Optional[Dict[str, List]] = None,
) -> AgentNetwork:
    """
    Create a custom agent network with specified handoff configuration.
    
    Args:
        templates_root: Root directory for template configurations.
        client: Client key to load configurations for.
        network_config: Dict mapping agent names to list of handoff agent names.
        custom_tools: Optional dict of custom tools by agent name.
        
    Returns:
        Configured AgentNetwork instance.
        
    Raises:
        LicenseNotActivatedError: If the library is not activated.
    """
    # Verificar licença (já é feito em create_standard_network, mas verificamos novamente)
    require_activation()
    
    # First create the standard network
    network = create_standard_network(
        templates_root=templates_root,
        client=client,
        include_onboarding="onboarding" in network_config,
        custom_tools=custom_tools,
    )
    
    # Map agent names to instances
    agent_map = {
        "triage": network.triage,
        "flow": network.flow,
        "interview": network.interview,
        "answer": network.answer,
        "knowledge": network.knowledge,
        "confirmation": network.confirmation,
        "usage": network.usage,
        "onboarding": network.onboarding,
        "escalation": network.escalation,
        "feedback": network.feedback,
    }
    
    # Apply custom handoff configuration
    for agent_name, handoff_names in network_config.items():
        agent = agent_map.get(agent_name)
        if agent:
            handoffs = [
                agent_map[h] for h in handoff_names
                if h in agent_map and agent_map[h] is not None
            ]
            agent.handoffs = handoffs  # type: ignore[assignment]
    
    return network

