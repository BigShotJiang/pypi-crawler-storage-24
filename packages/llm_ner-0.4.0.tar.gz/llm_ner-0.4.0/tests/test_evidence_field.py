"""Unit tests for :class:`~llmner.factories.EvidenceField` and validators."""

from __future__ import annotations

from llmner.factories import EvidenceField, is_null_value

# ---------------------------------------------------------------------------
# is_null_value
# ---------------------------------------------------------------------------


class TestIsNullValue:
    def test_none(self) -> None:
        assert is_null_value(None) is True

    def test_empty_string(self) -> None:
        assert is_null_value("") is True

    def test_null_string(self) -> None:
        assert is_null_value("null") is True
        assert is_null_value("NULL") is True
        assert is_null_value("  Null  ") is True

    def test_none_string(self) -> None:
        assert is_null_value("none") is True
        assert is_null_value("None") is True

    def test_nan_string(self) -> None:
        assert is_null_value("nan") is True

    def test_valid_values(self) -> None:
        assert is_null_value("hello") is False
        assert is_null_value("0") is False
        assert is_null_value(0) is False
        assert is_null_value(42) is False


# ---------------------------------------------------------------------------
# EvidenceField
# ---------------------------------------------------------------------------


class TestEvidenceField:
    def test_defaults_to_none(self) -> None:
        ef = EvidenceField()
        assert ef.value is None
        assert ef.evidence is None

    def test_with_values(self) -> None:
        ef = EvidenceField(value="John", evidence="John Smith")
        assert ef.value == "John"
        assert ef.evidence == "John Smith"
