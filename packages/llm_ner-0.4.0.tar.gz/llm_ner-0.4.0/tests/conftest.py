"""Pytest configuration and shared fixtures for llm-ner tests.

The accuracy tests require a running Ollama instance.  Mark them with
``@pytest.mark.integration`` and skip them in CI unless the server is
available.
"""

import pytest


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers",
        "integration: marks tests that require a live Ollama server "
        "(deselect with -m 'not integration')",
    )
