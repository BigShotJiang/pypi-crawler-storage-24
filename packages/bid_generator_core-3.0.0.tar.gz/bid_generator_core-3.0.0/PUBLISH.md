# Publishing to PyPI

This document describes how to publish `bid-generator-core` to PyPI.

## Prerequisites

1. **PyPI Account**: You need a [PyPI](https://pypi.org/) account
2. **Trusted Publishing** (Recommended): Configure trusted publishing via GitHub Actions
   - Go to [PyPI -> Account Settings -> Publishing](https://pypi.org/manage/account/publishing/)
   - Add a new pending publisher:
     - PyPI Project Name: `bid-generator-core`
     - Owner: your-github-username-or-org
     - Repository name: your-repo-name
     - Workflow name: `publish.yml`

## Method 1: Automated (GitHub Actions)

The easiest way to publish is via GitHub Actions:

```bash
# Tag a release
git tag v3.0.0
git push origin v3.0.0
```

The GitHub Action will:
1. Run all tests
2. Build the package
3. Publish to PyPI using trusted publishing

## Method 2: Manual Publishing

If you need to publish manually:

```bash
cd packages/bid-generator-core

# Run the publish script
./scripts/publish.sh

# Then upload manually
twine upload dist/*
```

Or step by step:

```bash
cd packages/bid-generator-core

# Clean previous builds
rm -rf dist/ build/ *.egg-info

# Install build tools
pip install build twine

# Build package
python -m build

# Check package
twine check dist/*

# Upload to PyPI
twine upload dist/*
```

## Version Management

Update the version in `pyproject.toml` before publishing:

```toml
[project]
version = "3.0.1"  # Update this
```

Follow [Semantic Versioning](https://semver.org/):
- MAJOR: Breaking changes
- MINOR: New features (backward compatible)
- PATCH: Bug fixes

## Testing Before Release

```bash
cd packages/bid-generator-core

# Install in editable mode
pip install -e ".[dev]"

# Run all tests
pytest tests/ -v

# Test the package build
python -m build
twine check dist/*
```

## After Publishing

1. Verify the package on PyPI: https://pypi.org/project/bid-generator-core/
2. Install and test from PyPI:
   ```bash
   pip install bid-generator-core
   python -c "from bid_generator_core import BidGenerator; print('OK')"
   ```
3. Update the SKILL.md if needed
4. Create a GitHub release with release notes
