"""Tests for constraint checking module."""

import pytest

from bid_generator_core import ConstraintChecker, PriorityDataManager, SourcePriority


class TestConstraintChecker:
    """Test ConstraintChecker class."""

    def test_init_without_priority_manager(self):
        """Test initialization without priority manager."""
        checker = ConstraintChecker()
        assert checker.priority_manager is None
        assert checker.violations == []
        assert checker.warnings == []

    def test_init_with_priority_manager(self, priority_manager):
        """Test initialization with priority manager."""
        checker = ConstraintChecker(priority_manager)
        assert checker.priority_manager is priority_manager

    def test_check_content_authenticity_empty(self, constraint_checker):
        """Test checking empty content."""
        passed, msg = constraint_checker.check_content_authenticity("", "field")
        assert passed is False
        assert "内容为空" in msg

    def test_check_content_authenticity_with_marker(self, constraint_checker):
        """Test content with missing marker passes."""
        passed, msg = constraint_checker.check_content_authenticity("【待补充：XXX】", "field")
        assert passed is True
        assert "已标注为待补充" in msg

    def test_check_content_authenticity_fabrication_indicators(self, constraint_checker):
        """Test detection of fabrication indicators."""
        indicators = ["可能", "大概", "或许", "推测", "估计", "应该"]

        for indicator in indicators:
            passed, msg = constraint_checker.check_content_authenticity(
                f"这是{indicator}正确的",
                "field"
            )
            assert passed is False, f"Failed for indicator: {indicator}"
            assert indicator in msg or "不确定性词汇" in msg
            assert len(constraint_checker.violations) > 0
            constraint_checker.violations.clear()

    def test_check_format_compliance(self, constraint_checker):
        """Test format compliance check."""
        template_requirements = {
            "page_setup": {"page_width": 21.0},
            "fonts": {"heading": {"name": "黑体", "size": 16}}
        }

        passed, issues = constraint_checker.check_format_compliance(None, template_requirements)
        # Currently returns True as full implementation requires document object
        assert passed is True

    def test_check_response_completeness_without_pm(self):
        """Test response completeness without priority manager."""
        checker = ConstraintChecker()
        passed, unresponded = checker.check_response_completeness()
        assert passed is True
        assert unresponded == []

    def test_check_response_completeness_with_unresponded(self, priority_manager):
        """Test response completeness with unresponded requirements."""
        checker = ConstraintChecker(priority_manager)
        priority_manager.add_substantial_requirement({
            "content": "要求1",
            "section": "测试"
        })

        passed, unresponded = checker.check_response_completeness()
        assert passed is False
        assert len(unresponded) == 1

    def test_check_response_completeness_all_responded(self, priority_manager):
        """Test response completeness when all responded."""
        checker = ConstraintChecker(priority_manager)
        priority_manager.add_substantial_requirement({
            "content": "要求1",
            "section": "测试"
        })
        priority_manager.mark_requirement_responded(0, "已响应", "source.json")

        passed, unresponded = checker.check_response_completeness()
        assert passed is True
        assert unresponded == []

    def test_check_missing_items_none(self, constraint_checker):
        """Test checking content without missing markers."""
        passed, items = constraint_checker.check_missing_items("这是正常内容")
        assert passed is True
        assert items == []

    def test_check_missing_items_with_markers(self, constraint_checker):
        """Test checking content with missing markers."""
        content = "这是【待补充：公司地址】和【待补充：联系人】"
        passed, items = constraint_checker.check_missing_items(content)
        assert passed is True
        assert len(items) == 2
        assert "公司地址" in items
        assert "联系人" in items
        assert len(constraint_checker.warnings) == 1

    def test_check_substantial_clauses_star_pattern(self, priority_manager):
        """Test detecting star pattern substantial clauses."""
        checker = ConstraintChecker(priority_manager)
        content = """
★投标人必须具有独立法人资格
★投标人必须提供三年财务报表
其他一般性要求
        """

        clauses = checker.check_substantial_clauses(content)
        # Should find at least 2 star clauses (may find more due to keyword matching)
        star_clauses = [c for c in clauses if c["is_star"]]
        assert len(star_clauses) >= 2
        assert all(c["type"] == "★号条款" for c in star_clauses)

    def test_check_substantial_clauses_mandatory_keywords(self, priority_manager):
        """Test detecting mandatory keyword clauses."""
        checker = ConstraintChecker(priority_manager)
        content = """
必须提供7×24小时技术支持。
不得转包或分包项目。
禁止使用盗版软件。
        """

        clauses = checker.check_substantial_clauses(content)
        # Should find at least 1 keyword clause
        keyword_clauses = [c for c in clauses if not c["is_star"]]
        assert len(keyword_clauses) >= 1
        # Check that at least one keyword is detected
        keyword_types = [c["type"] for c in keyword_clauses]
        assert any(kw in str(keyword_types) for kw in ["必须", "不得", "禁止"])

    def test_run_all_checks_empty(self, constraint_checker):
        """Test running all checks with no input."""
        results = constraint_checker.run_all_checks()

        assert results["content_authenticity"]["passed"] is True
        assert results["format_compliance"]["passed"] is True
        assert results["response_completeness"]["passed"] is True
        assert results["missing_items"]["passed"] is True
        assert results["overall_passed"] is True

    def test_run_all_checks_with_failures(self, constraint_checker):
        """Test running all checks with failures."""
        results = constraint_checker.run_all_checks(
            document_content="这可能是编造的",
        )

        assert results["content_authenticity"]["passed"] is False
        assert results["overall_passed"] is False

    def test_generate_check_report_empty(self, constraint_checker):
        """Test generating report with no violations."""
        constraint_checker.run_all_checks()
        report = constraint_checker.generate_check_report()

        assert "投标文件核心约束检查报告" in report
        assert "【检查结果】" in report
        assert "✅ 通过" in report

    def test_generate_check_report_with_violations(self, constraint_checker):
        """Test generating report with violations."""
        constraint_checker.check_content_authenticity("这可能是错误的", "field")
        constraint_checker.check_missing_items("【待补充：测试】")
        constraint_checker.check_results = {"overall_passed": False}

        report = constraint_checker.generate_check_report()

        assert "【违规项】" in report
        assert "【警告项】" in report
        assert "❌ 未通过" in report

    def test_get_violation_summary(self, constraint_checker):
        """Test getting violation summary."""
        constraint_checker.violations = [
            {"type": "内容真实性"},
            {"type": "内容真实性"},
            {"type": "格式合规性"}
        ]
        constraint_checker.warnings = [
            {"type": "缺失项标注"}
        ]

        summary = constraint_checker.get_violation_summary()

        assert summary["total_violations"] == 3
        assert summary["total_warnings"] == 1
        assert summary["violations_by_type"]["内容真实性"] == 2
        assert summary["violations_by_type"]["格式合规性"] == 1
        assert summary["warnings_by_type"]["缺失项标注"] == 1
