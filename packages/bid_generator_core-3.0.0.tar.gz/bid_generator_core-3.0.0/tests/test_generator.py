"""Tests for generator module."""

import json
from pathlib import Path

import pytest

from bid_generator_core import (
    BidGenerator,
    GenerationResult,
    generate_bid_document,
)


class TestGenerationResult:
    """Test GenerationResult dataclass."""

    def test_creation(self, temp_dir):
        """Test creating a GenerationResult."""
        result = GenerationResult(
            document_path=temp_dir / "test.docx",
            traceability_report={"sources": []},
            quality_report={"passed": True},
            success=True,
            message="Test message",
            missing_items=["item1", "item2"]
        )

        assert result.success is True
        assert result.message == "Test message"
        assert len(result.missing_items) == 2

    def test_to_dict(self, temp_dir):
        """Test converting to dict."""
        result = GenerationResult(
            document_path=temp_dir / "test.docx",
            traceability_report={"sources": []},
            quality_report={"passed": True},
            success=True
        )

        d = result.to_dict()
        assert d["success"] is True
        assert d["document_path"] == str(temp_dir / "test.docx")
        assert "traceability_report" in d
        assert "quality_report" in d


class TestBidGenerator:
    """Test BidGenerator class."""

    def test_init_auto_execute(self, sample_data_dir):
        """Test generator initialization with auto-execution."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        assert generator.priority_manager is not None
        assert generator.constraint_checker is not None
        assert generator.document is not None
        assert generator.output_dir is not None

    def test_init_no_auto_execute(self, sample_data_dir):
        """Test generator initialization without auto-execution."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=False
        )

        # Workflow should not be executed
        assert not generator.workflow_status["step1_tender_parsed"]
        assert generator.document is None

    def test_execute(self, sample_data_dir):
        """Test manual execution."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=False
        )

        result = generator.execute()
        assert result is generator  # Returns self
        assert generator.workflow_status["step1_tender_parsed"]
        assert generator.workflow_status["step5_quality_checked"]

    def test_load_existing_data(self, sample_data_dir):
        """Test loading data from directory."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        company_info = generator.priority_manager.get_data("company_info")
        assert company_info is not None
        assert company_info["name"] == "北京测试科技有限公司"

        project_info = generator.priority_manager.get_data("project_info")
        assert project_info is not None
        assert project_info["name"] == "测试采购项目"

    def test_load_data_with_override(self, sample_data_dir, sample_company_info):
        """Test loading data with override parameters."""
        override_info = {"name": "Override Company"}

        generator = BidGenerator(
            data_dir=sample_data_dir,
            company_info=override_info,
            auto_execute=True
        )

        # The override should be loaded, but data_dir takes precedence in P2
        # depending on implementation
        assert generator.priority_manager.get_data("company_info") is not None

    def test_save_document(self, sample_data_dir, temp_dir):
        """Test saving generated document."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        assert result.success is True
        assert result.document_path.exists()
        assert result.document_path.suffix == ".docx"

    def test_save_with_custom_path(self, sample_data_dir, temp_dir):
        """Test saving with custom output path."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        output_path = temp_dir / "custom_name.docx"
        result = generator.save(output_path=output_path)

        assert result.success is True
        assert result.document_path == output_path
        assert output_path.exists()

    def test_save_creates_traceability_report(self, sample_data_dir, temp_dir):
        """Test that save creates traceability report."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        traceability_path = result.document_path.with_suffix(".traceability.json")
        assert traceability_path.exists()

        with open(traceability_path, "r", encoding="utf-8") as f:
            report = json.load(f)
            assert "data_sources" in report
            assert "missing_items" in report

    def test_generate_returns_path(self, sample_data_dir, temp_dir):
        """Test generate method returns path."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        output_path = generator.generate(use_timestamp=False)

        assert isinstance(output_path, Path)
        assert output_path.exists()

    def test_generate_with_return_result(self, sample_data_dir, temp_dir):
        """Test generate method with return_result=True."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.generate(use_timestamp=False, return_result=True)

        assert isinstance(result, GenerationResult)
        assert result.success is True

    def test_standard_sections_structure(self):
        """Test that standard sections are defined."""
        assert len(BidGenerator.STANDARD_SECTIONS) == 4

        sections = [s["title"] for s in BidGenerator.STANDARD_SECTIONS]
        assert "一、投标函部分" in sections
        assert "二、商务部分" in sections
        assert "三、技术部分" in sections
        assert "四、其他部分" in sections

    def test_validate_output_dir_creates_directory(self, temp_dir):
        """Test that output directory is created if it doesn't exist."""
        new_dir = temp_dir / "new" / "nested" / "output"

        generator = BidGenerator(
            output_dir=new_dir,
            auto_execute=False
        )

        assert new_dir.exists()

    def test_validate_output_dir_existing_directory(self, temp_dir):
        """Test validation of existing output directory."""
        existing_dir = temp_dir / "existing"
        existing_dir.mkdir()

        generator = BidGenerator(
            output_dir=existing_dir,
            auto_execute=False
        )

        # Use resolve() to handle macOS /private prefix differences
        assert generator.output_dir.resolve() == existing_dir.resolve()


class TestGenerateBidDocument:
    """Test generate_bid_document convenience function."""

    def test_convenience_function(self, sample_data_dir, temp_dir):
        """Test the convenience function."""
        output_path = generate_bid_document(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
        )

        assert isinstance(output_path, Path)
        assert output_path.exists()
        assert output_path.suffix == ".docx"

    def test_convenience_function_with_tender(self, sample_data_dir, temp_dir, sample_tender_content):
        """Test with tender document."""
        tender_path = temp_dir / "tender.txt"
        tender_path.write_text(sample_tender_content, encoding="utf-8")

        output_path = generate_bid_document(
            data_dir=sample_data_dir,
            tender_doc_path=tender_path,
            output_dir=temp_dir,
        )

        assert output_path.exists()

    def test_convenience_function_with_override(self, sample_data_dir, temp_dir):
        """Test with company/project info override."""
        company_info = {"name": "Custom Company"}
        project_info = {"name": "Custom Project"}

        output_path = generate_bid_document(
            data_dir=sample_data_dir,
            company_info=company_info,
            project_info=project_info,
            output_dir=temp_dir,
        )

        assert output_path.exists()
        # The file name should reflect the custom info
        assert "Custom" in output_path.name or "北京测试" in output_path.name


class TestContentGeneration:
    """Test content generation methods."""

    def test_generate_response_letter_content(self, sample_data_dir):
        """Test generating response letter content."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        content = generator._generate_response_letter_content()

        assert "致：测试采购中心" in content
        assert "测试采购项目" in content
        assert "北京测试科技有限公司" in content
        assert "张三" in content  # legal representative

    def test_generate_legal_representative_content(self, sample_data_dir):
        """Test generating legal representative content."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        content = generator._generate_legal_representative_content()

        assert "北京测试科技有限公司" in content
        assert "张三" in content
        assert "男" in content
        assert "董事长" in content

    def test_generate_authorization_content(self, sample_data_dir):
        """Test generating authorization content."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        content = generator._generate_authorization_content()

        assert "北京测试科技有限公司" in content
        assert "张三" in content
        assert "测试采购项目" in content

    def test_generate_bid_summary_table(self, sample_data_dir):
        """Test generating bid summary table."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        table = generator._generate_bid_summary_table()

        assert table["type"] == "table"
        assert "项目名称" in table["headers"]
        assert "投标报价（万元）" in table["headers"]
        assert len(table["rows"]) == 1

    def test_generate_qualifications_content(self, sample_data_dir):
        """Test generating qualifications content."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        content = generator._generate_qualifications_content()

        assert "ISO9001质量管理体系认证" in content
        assert "CMMI5级认证" in content

    def test_generate_qualifications_content_empty(self):
        """Test generating qualifications with no data."""
        generator = BidGenerator(auto_execute=False)
        generator._apply_default_format()
        generator.priority_manager.add_data_source(
            name="qualifications",
            content={},
            priority=__import__("bid_generator_core").SourcePriority.P2
        )

        content = generator._generate_qualifications_content()

        assert "【待补充：资格证明文件】" in content

    def test_generate_project_cases_content(self, sample_data_dir):
        """Test generating project cases content."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        content = generator._generate_project_cases_content()

        assert "某市政府大数据平台项目" in content
        assert "500万元" in content
        assert "某企业ERP系统开发项目" in content

    def test_generate_team_content(self, sample_data_dir):
        """Test generating team content."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        content = generator._generate_team_content()

        assert "王五" in content
        assert "项目经理" in content
        assert "赵六" in content
        assert "技术负责人" in content

    def test_generate_technical_solution_content(self):
        """Test generating technical solution content."""
        generator = BidGenerator(auto_execute=False)

        content = generator._generate_technical_solution_content()

        assert "【待补充：技术方案/实施方案" in content

    def test_generate_service_commitment_content(self, sample_data_dir):
        """Test generating service commitment content."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            auto_execute=True
        )

        content = generator._generate_service_commitment_content()

        assert "北京测试科技有限公司" in content
        assert "严格按照招标文件" in content
        assert "2 小时内响应" in content
