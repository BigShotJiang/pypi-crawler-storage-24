"""Pytest fixtures for bid-generator-core tests."""

import json
import tempfile
from pathlib import Path

import pytest

from bid_generator_core import PriorityDataManager, SourcePriority, ConstraintChecker


@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def sample_company_info():
    """Return sample company info dict."""
    return {
        "name": "北京测试科技有限公司",
        "address": "北京市朝阳区测试路100号",
        "legal_representative": "张三",
        "legal_representative_gender": "男",
        "legal_representative_age": "45",
        "legal_representative_position": "董事长",
        "company_type": "有限责任公司",
        "establishment_date": "2018年5月10日",
        "business_term": "长期",
        "contact": "李四",
        "phone": "13800138000",
        "email": "contact@test.com"
    }


@pytest.fixture
def sample_project_info():
    """Return sample project info dict."""
    return {
        "name": "测试采购项目",
        "project_no": "TEST-2025-001",
        "bid_price": "85.5",
        "specification": "按采购文件要求",
        "delivery_time": "合同签订后30天内",
        "purchaser": "测试采购中心",
        "description": "这是一个测试项目"
    }


@pytest.fixture
def sample_qualifications():
    """Return sample qualifications dict."""
    return {
        "certificates": [
            {
                "name": "ISO9001质量管理体系认证",
                "number": "ISO9001-2024-001",
                "issue_date": "2024-01-01",
                "expiry_date": "2027-01-01",
                "issuer": "中国质量认证中心",
                "note": "有效期三年"
            },
            {
                "name": "CMMI5级认证",
                "number": "CMMI-2024-002",
                "issue_date": "2024-06-01",
                "expiry_date": "2027-06-01",
                "issuer": "CMMI研究院",
                "note": "软件开发能力成熟度"
            }
        ]
    }


@pytest.fixture
def sample_project_cases():
    """Return sample project cases dict."""
    return {
        "cases": [
            {
                "name": "某市政府大数据平台项目",
                "amount": "500万元",
                "contract_date": "2023-01-15",
                "completion_date": "2023-12-30",
                "client": "某市大数据管理局",
                "description": "建设市级大数据平台"
            },
            {
                "name": "某企业ERP系统开发项目",
                "amount": "200万元",
                "contract_date": "2022-06-01",
                "completion_date": "2023-03-15",
                "client": "某大型制造企业",
                "description": "定制开发企业资源管理系统"
            }
        ]
    }


@pytest.fixture
def sample_team_info():
    """Return sample team info dict."""
    return {
        "members": [
            {
                "name": "王五",
                "position": "项目经理",
                "qualifications": ["PMP", "高级工程师"],
                "experience": "10年项目管理经验"
            },
            {
                "name": "赵六",
                "position": "技术负责人",
                "qualifications": ["系统架构师", "Oracle认证专家"],
                "experience": "8年系统开发经验"
            }
        ]
    }


@pytest.fixture
def priority_manager():
    """Create a PriorityDataManager instance."""
    return PriorityDataManager()


@pytest.fixture
def constraint_checker(priority_manager):
    """Create a ConstraintChecker instance with priority manager."""
    return ConstraintChecker(priority_manager)


@pytest.fixture
def sample_data_dir(temp_dir, sample_company_info, sample_project_info,
                    sample_qualifications, sample_project_cases, sample_team_info):
    """Create a sample data directory with all JSON files."""
    data_dir = temp_dir / "data"
    data_dir.mkdir()

    # Write company_info.json
    with open(data_dir / "company_info.json", "w", encoding="utf-8") as f:
        json.dump(sample_company_info, f, ensure_ascii=False, indent=2)

    # Write project_info.json
    with open(data_dir / "project_info.json", "w", encoding="utf-8") as f:
        json.dump(sample_project_info, f, ensure_ascii=False, indent=2)

    # Write qualifications.json
    with open(data_dir / "qualifications.json", "w", encoding="utf-8") as f:
        json.dump(sample_qualifications, f, ensure_ascii=False, indent=2)

    # Write project_cases.json
    with open(data_dir / "project_cases.json", "w", encoding="utf-8") as f:
        json.dump(sample_project_cases, f, ensure_ascii=False, indent=2)

    # Write team_info.json
    with open(data_dir / "team_info.json", "w", encoding="utf-8") as f:
        json.dump(sample_team_info, f, ensure_ascii=False, indent=2)

    return data_dir


@pytest.fixture
def sample_tender_content():
    """Return sample tender document content."""
    return """
项目名称：测试采购项目
采购编号：TEST-2025-001

一、项目概况
采购人：测试采购中心
预算金额：100万元

二、资格要求
★投标人须具有独立法人资格
★投标人须具有ISO9001质量管理体系认证
投标人须具有良好的商业信誉

三、技术要求
必须提供7×24小时技术支持服务
严禁使用盗版软件

四、投标文件格式
请按照附件格式编制投标文件
"""
