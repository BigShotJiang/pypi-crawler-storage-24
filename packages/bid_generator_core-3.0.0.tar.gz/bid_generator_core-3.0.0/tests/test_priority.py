"""Tests for priority management module."""

import pytest

from bid_generator_core import PriorityDataManager, SourcePriority


class TestSourcePriority:
    """Test SourcePriority enum."""

    def test_priority_values(self):
        """Test that priorities have correct values."""
        assert SourcePriority.P0.value == "P0"
        assert SourcePriority.P1.value == "P1"
        assert SourcePriority.P2.value == "P2"
        assert SourcePriority.P3.value == "P3"

    def test_priority_ordering(self):
        """Test that priorities can be ordered."""
        priorities = [SourcePriority.P3, SourcePriority.P1, SourcePriority.P0, SourcePriority.P2]
        sorted_priorities = sorted(priorities, key=lambda p: p.value)
        assert sorted_priorities == [SourcePriority.P0, SourcePriority.P1, SourcePriority.P2, SourcePriority.P3]


class TestDataSource:
    """Test DataSource class."""

    def test_add_trace(self, priority_manager):
        """Test adding trace records."""
        priority_manager.add_data_source(
            name="test_source",
            content={"key": "value"},
            priority=SourcePriority.P2,
            source_path="/path/to/file.json",
            source_type="测试数据"
        )

        source = priority_manager.data_sources["test_source"]
        source.add_trace("read", "读取数据")

        assert len(source.traceability) == 1
        assert source.traceability[0]["action"] == "read"
        assert source.traceability[0]["details"] == "读取数据"


class TestPriorityDataManager:
    """Test PriorityDataManager class."""

    def test_add_data_source(self, priority_manager):
        """Test adding a data source."""
        priority_manager.add_data_source(
            name="company_info",
            content={"name": "Test Company"},
            priority=SourcePriority.P2,
            source_path="/data/company.json",
            source_type="公司信息"
        )

        assert "company_info" in priority_manager.data_sources
        source = priority_manager.data_sources["company_info"]
        assert source.content == {"name": "Test Company"}
        assert source.priority == SourcePriority.P2
        assert source.source_path == "/data/company.json"
        assert source.source_type == "公司信息"

    def test_get_data_existing(self, priority_manager):
        """Test getting existing data."""
        priority_manager.add_data_source(
            name="test_data",
            content={"key": "value"},
            priority=SourcePriority.P2
        )

        data = priority_manager.get_data("test_data")
        assert data == {"key": "value"}

    def test_get_data_nonexistent(self, priority_manager):
        """Test getting non-existent data returns default."""
        data = priority_manager.get_data("nonexistent")
        assert data is None

        data = priority_manager.get_data("nonexistent", default={})
        assert data == {}

    def test_get_data_adds_trace(self, priority_manager):
        """Test that getting data adds a trace record."""
        priority_manager.add_data_source(
            name="test_data",
            content={"key": "value"},
            priority=SourcePriority.P2
        )

        source = priority_manager.data_sources["test_data"]
        initial_traces = len(source.traceability)

        priority_manager.get_data("test_data")

        assert len(source.traceability) == initial_traces + 1
        assert source.traceability[-1]["action"] == "access"

    def test_get_priority_data(self, priority_manager):
        """Test getting data sources by priority."""
        priority_manager.add_data_source(
            name="p0_data",
            content={},
            priority=SourcePriority.P0
        )
        priority_manager.add_data_source(
            name="p2_data_1",
            content={},
            priority=SourcePriority.P2
        )
        priority_manager.add_data_source(
            name="p2_data_2",
            content={},
            priority=SourcePriority.P2
        )

        p0_sources = priority_manager.get_priority_data(SourcePriority.P0)
        assert len(p0_sources) == 1
        assert "p0_data" in p0_sources

        p2_sources = priority_manager.get_priority_data(SourcePriority.P2)
        assert len(p2_sources) == 2

    def test_resolve_conflict_p0_wins(self, priority_manager):
        """Test that P0 priority wins in conflict resolution."""
        priority_manager.add_data_source(
            name="p2_source",
            content={"field": "P2 value"},
            priority=SourcePriority.P2,
            source_type="P2数据"
        )
        priority_manager.add_data_source(
            name="p0_source",
            content={"field": "P0 value"},
            priority=SourcePriority.P0,
            source_type="P0数据"
        )

        value, source = priority_manager.resolve_conflict("field")
        assert value == "P0 value"
        assert "P0数据" in source

    def test_resolve_conflict_not_found(self, priority_manager):
        """Test conflict resolution when field not found."""
        priority_manager.add_data_source(
            name="source",
            content={"other": "value"},
            priority=SourcePriority.P2
        )

        value, source = priority_manager.resolve_conflict("missing_field")
        assert value is None
        assert source == "未找到"
        assert len(priority_manager.missing_items) == 1

    def test_record_missing(self, priority_manager):
        """Test recording missing items."""
        priority_manager.record_missing(
            field_name="test_field",
            reason="数据源中不存在",
            required_by="招标文件第三章"
        )

        assert len(priority_manager.missing_items) == 1
        item = priority_manager.missing_items[0]
        assert item["field"] == "test_field"
        assert item["reason"] == "数据源中不存在"
        assert item["required_by"] == "招标文件第三章"
        assert item["status"] == "待补充"
        assert "【待补充：test_field】" in item["marker"]

    def test_get_missing_marker(self, priority_manager):
        """Test getting missing item marker."""
        marker = priority_manager.get_missing_marker("field_name")
        assert marker == "【待补充：field_name】"

    def test_add_substantial_requirement(self, priority_manager):
        """Test adding substantial requirements."""
        priority_manager.add_substantial_requirement({
            "content": "投标人须具有独立法人资格",
            "section": "资格要求",
            "is_star": True
        })

        assert len(priority_manager.substantial_requirements) == 1
        req = priority_manager.substantial_requirements[0]
        assert req["content"] == "投标人须具有独立法人资格"
        assert req["section"] == "资格要求"
        assert req["is_star"] is True
        assert req["response_status"] == "待响应"

    def test_mark_requirement_responded(self, priority_manager):
        """Test marking requirement as responded."""
        priority_manager.add_substantial_requirement({
            "content": "测试要求",
            "section": "测试"
        })

        priority_manager.mark_requirement_responded(
            requirement_idx=0,
            response_content="已响应",
            source_path="data/company.json"
        )

        req = priority_manager.substantial_requirements[0]
        assert req["response_status"] == "已响应"
        assert req["response_content"] == "已响应"
        assert req["response_source"] == "data/company.json"

    def test_get_unresponded_requirements(self, priority_manager):
        """Test getting unresponded requirements."""
        priority_manager.add_substantial_requirement({
            "content": "要求1",
            "section": "测试"
        })
        priority_manager.add_substantial_requirement({
            "content": "要求2",
            "section": "测试"
        })

        unresponded = priority_manager.get_unresponded_requirements()
        assert len(unresponded) == 2

        priority_manager.mark_requirement_responded(0, "响应1", "source.json")

        unresponded = priority_manager.get_unresponded_requirements()
        assert len(unresponded) == 1

    def test_generate_traceability_report(self, priority_manager):
        """Test generating traceability report."""
        priority_manager.add_data_source(
            name="source1",
            content={"key": "value"},
            priority=SourcePriority.P2
        )
        priority_manager.record_missing("field1", "测试缺失")
        priority_manager.add_substantial_requirement({
            "content": "要求1",
            "section": "测试"
        })

        report = priority_manager.generate_traceability_report()

        assert "data_sources" in report
        assert "missing_items" in report
        assert "substantial_requirements" in report
        assert "access_traces" in report
        assert len(report["data_sources"]) == 1
        assert len(report["missing_items"]) == 1
        assert len(report["substantial_requirements"]) == 1

    def test_get_summary(self, priority_manager):
        """Test getting summary."""
        priority_manager.add_data_source(
            name="p0_source",
            content={},
            priority=SourcePriority.P0
        )
        priority_manager.add_data_source(
            name="p2_source",
            content={},
            priority=SourcePriority.P2
        )
        priority_manager.record_missing("field", "原因")
        priority_manager.add_substantial_requirement({
            "content": "要求",
            "section": "测试"
        })

        summary = priority_manager.get_summary()

        assert summary["total_sources"] == 2
        assert summary["by_priority"]["P0"] == 1
        assert summary["by_priority"]["P2"] == 1
        assert summary["missing_items_count"] == 1
        assert summary["substantial_requirements_count"] == 1
        assert summary["unresponded_count"] == 1

    def test_validate_content_authenticity_empty(self, priority_manager):
        """Test validating empty content."""
        assert priority_manager.validate_content_authenticity("") is False
        assert priority_manager.validate_content_authenticity("   ") is False

    def test_validate_content_authenticity_with_marker(self, priority_manager):
        """Test that content with marker is not authentic."""
        priority_manager.add_data_source(
            name="source",
            content={"key": "真实内容"},
            priority=SourcePriority.P2
        )
        assert priority_manager.validate_content_authenticity("【待补充：XXX】") is False
