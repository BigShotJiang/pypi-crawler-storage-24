"""Tests for bid-generator-core."""
