"""Integration tests for bid-generator-core.

These tests verify end-to-end workflows and real-world usage scenarios.
"""

import json
from pathlib import Path

import pytest

from bid_generator_core import BidGenerator, generate_bid_document, SourcePriority


class TestEndToEndWorkflow:
    """Test complete end-to-end workflows."""

    def test_full_workflow_with_all_data(self, sample_data_dir, temp_dir, sample_tender_content):
        """Test complete workflow with all data sources."""
        # Create tender document
        tender_path = temp_dir / "tender.txt"
        tender_path.write_text(sample_tender_content, encoding="utf-8")

        # Generate bid document
        generator = BidGenerator(
            data_dir=sample_data_dir,
            tender_doc_path=tender_path,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        # Verify document was created
        assert result.success is True
        assert result.document_path.exists()
        assert result.document_path.stat().st_size > 0

        # Verify traceability report
        assert result.traceability_report is not None
        assert len(result.traceability_report["data_sources"]) >= 3  # tender + data files

        # Verify quality report
        assert result.quality_report is not None

    def test_workflow_without_tender(self, sample_data_dir, temp_dir):
        """Test workflow without tender document (uses P2 data only)."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        assert result.success is True
        assert result.document_path.exists()

        # Check that no P0 sources were used
        summary = generator.priority_manager.get_summary()
        assert summary["by_priority"]["P0"] == 0
        assert summary["by_priority"]["P2"] >= 1

    def test_workflow_without_data_dir(self, temp_dir):
        """Test workflow with inline data (no data directory)."""
        company_info = {
            "name": "直接传入的公司",
            "legal_representative": "王总"
        }
        project_info = {
            "name": "直接传入的项目",
            "purchaser": "采购方"
        }

        generator = BidGenerator(
            company_info=company_info,
            project_info=project_info,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        assert result.success is True
        assert result.document_path.exists()

        # Check content
        content = generator._generate_response_letter_content()
        assert "直接传入的公司" in content
        assert "直接传入的项目" in content

    def test_convenience_function_full_workflow(self, sample_data_dir, temp_dir, sample_tender_content):
        """Test convenience function for full workflow."""
        tender_path = temp_dir / "tender.txt"
        tender_path.write_text(sample_tender_content, encoding="utf-8")

        output_path = generate_bid_document(
            data_dir=sample_data_dir,
            tender_doc_path=tender_path,
            output_dir=temp_dir,
        )

        assert output_path.exists()
        assert output_path.suffix == ".docx"

        # Check traceability report was created
        traceability_path = output_path.with_suffix(".traceability.json")
        assert traceability_path.exists()


class TestRealWorldScenarios:
    """Test real-world usage scenarios."""

    def test_multiple_generations_same_data(self, sample_data_dir, temp_dir):
        """Test generating multiple documents from same data."""
        # Generate first document
        result1 = generate_bid_document(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
        )

        # Small delay to ensure different timestamp (need at least 1s for HHMMSS format)
        import time
        time.sleep(1.1)

        # Generate second document (with timestamp, so different filename)
        result2 = generate_bid_document(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
        )

        # Both should succeed
        assert result1.exists()
        assert result2.exists()
        assert result1 != result2  # Different filenames due to timestamp

    def test_generation_with_missing_data(self, temp_dir):
        """Test generation when data is missing (should mark as 待补充)."""
        # Only provide company info, no project info
        company_info = {"name": "仅有公司信息"}

        generator = BidGenerator(
            company_info=company_info,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        assert result.success is True

        # Check content has markers (missing items result in 待补充 markers)
        content = generator._generate_response_letter_content()
        assert "【待补充" in content

    def test_priority_resolution_in_generation(self, sample_data_dir, temp_dir, sample_tender_content):
        """Test that P0 data takes precedence over P2 data."""
        from docx import Document

        # Create tender as .docx file (supported format)
        tender_path = temp_dir / "tender.docx"
        doc = Document()
        doc.add_paragraph("项目名称：招标文件中的项目名称")
        doc.add_paragraph("采购编号：TEST-2025-001")
        doc.add_paragraph("采购人：测试采购中心")
        doc.save(tender_path)

        # Generate with both tender and data_dir
        generator = BidGenerator(
            data_dir=sample_data_dir,
            tender_doc_path=tender_path,
            output_dir=temp_dir,
            auto_execute=True
        )

        # The tender (P0) should have been parsed
        summary = generator.priority_manager.get_summary()
        assert summary["by_priority"]["P0"] == 1

    def test_substantial_requirements_tracking(self, temp_dir, sample_tender_content):
        """Test tracking and responding to substantial requirements."""
        from docx import Document

        # Create tender as .docx file with substantial requirements
        tender_path = temp_dir / "tender.docx"
        doc = Document()
        doc.add_paragraph("★投标人必须具有独立法人资格")
        doc.add_paragraph("★投标人必须提供ISO9001认证")
        doc.add_paragraph("必须提供7×24小时技术支持")
        doc.save(tender_path)

        generator = BidGenerator(
            tender_doc_path=tender_path,
            output_dir=temp_dir,
            auto_execute=True
        )

        # Check substantial requirements were identified
        summary = generator.priority_manager.get_summary()
        assert summary["substantial_requirements_count"] > 0

        # The quality check should report unresponded requirements
        quality_report = generator.constraint_checker.check_results
        if quality_report:
            assert "response_completeness" in quality_report


class TestErrorHandling:
    """Test error handling and edge cases."""

    def test_nonexistent_data_dir(self, temp_dir):
        """Test handling of non-existent data directory."""
        nonexistent_dir = temp_dir / "does_not_exist"

        # Should not raise, should use default/empty data
        generator = BidGenerator(
            data_dir=nonexistent_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)
        assert result.success is True

    def test_nonexistent_tender_doc(self, sample_data_dir, temp_dir):
        """Test handling of non-existent tender document."""
        nonexistent_file = temp_dir / "nonexistent.pdf"

        generator = BidGenerator(
            data_dir=sample_data_dir,
            tender_doc_path=nonexistent_file,
            output_dir=temp_dir,
            auto_execute=True
        )

        # Should continue without tender
        result = generator.save(use_timestamp=False)
        assert result.success is True

    def test_empty_data_files(self, temp_dir):
        """Test handling of empty data files."""
        # Create empty JSON files
        data_dir = temp_dir / "empty_data"
        data_dir.mkdir()

        (data_dir / "company_info.json").write_text("{}", encoding="utf-8")
        (data_dir / "project_info.json").write_text("{}", encoding="utf-8")

        generator = BidGenerator(
            data_dir=data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)
        assert result.success is True

        # Content should have markers for missing fields
        content = generator._generate_response_letter_content()
        assert "【待补充" in content


class TestDocumentContent:
    """Test the actual content of generated documents."""

    def test_document_has_all_sections(self, sample_data_dir, temp_dir):
        """Test that document contains all standard sections."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        # Read document and check for sections
        from docx import Document
        doc = Document(result.document_path)

        full_text = "\n".join(para.text for para in doc.paragraphs)

        # Check for standard section titles
        assert "一、投标函部分" in full_text
        assert "投标函" in full_text
        assert "法定代表人身份证明" in full_text
        assert "二、商务部分" in full_text or "商务" in full_text
        assert "三、技术部分" in full_text or "技术" in full_text

    def test_document_has_company_info(self, sample_data_dir, temp_dir):
        """Test that document contains company information."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        from docx import Document
        doc = Document(result.document_path)
        full_text = "\n".join(para.text for para in doc.paragraphs)

        assert "北京测试科技有限公司" in full_text

    def test_document_has_tables(self, sample_data_dir, temp_dir):
        """Test that document contains tables."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        from docx import Document
        doc = Document(result.document_path)

        # Should have at least one table (bid summary)
        assert len(doc.tables) > 0


class TestTraceability:
    """Test traceability and reporting features."""

    def test_traceability_report_content(self, sample_data_dir, temp_dir):
        """Test that traceability report has correct content."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        report = result.traceability_report

        # Check structure
        assert "data_sources" in report
        assert "missing_items" in report
        assert "substantial_requirements" in report
        assert "access_traces" in report

        # Check data sources are recorded
        source_names = [s["name"] for s in report["data_sources"]]
        assert "company_info" in source_names
        assert "project_info" in source_names

        # Check priorities are recorded
        for source in report["data_sources"]:
            assert "priority" in source
            assert source["priority"] == "P2"  # Data files are P2

    def test_traceability_report_written_to_file(self, sample_data_dir, temp_dir):
        """Test that traceability report is written to file."""
        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )

        result = generator.save(use_timestamp=False)

        traceability_path = result.document_path.with_suffix(".traceability.json")
        assert traceability_path.exists()

        # Verify it's valid JSON
        with open(traceability_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            assert "data_sources" in data


class TestPerformance:
    """Basic performance tests."""

    def test_generation_is_reasonably_fast(self, sample_data_dir, temp_dir):
        """Test that generation completes in reasonable time."""
        import time

        start = time.time()

        generator = BidGenerator(
            data_dir=sample_data_dir,
            output_dir=temp_dir,
            auto_execute=True
        )
        result = generator.save(use_timestamp=False)

        elapsed = time.time() - start

        # Should complete in less than 10 seconds
        assert elapsed < 10.0
        assert result.success is True
