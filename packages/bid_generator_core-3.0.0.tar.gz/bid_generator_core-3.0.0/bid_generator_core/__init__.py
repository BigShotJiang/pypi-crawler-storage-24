"""
Bid Generator Core - 投标文件生成器核心库

A framework-agnostic library for generating professional bid proposal documents
with strict source priority management (P0-P3) and core constraint checking.

This package provides the core functionality without dependencies on any
AI framework or platform-specific SDK.
"""

from .core.generator import BidGenerator, GenerationResult, generate_bid_document
from .core.priority import PriorityDataManager, SourcePriority, DataSource
from .core.constraints import ConstraintChecker

__version__ = "3.0.0"
__author__ = "OpenClaw"

__all__ = [
    # Main generator
    "BidGenerator",
    "GenerationResult",
    "generate_bid_document",
    # Priority management
    "PriorityDataManager",
    "SourcePriority",
    "DataSource",
    # Constraint checking
    "ConstraintChecker",
]
