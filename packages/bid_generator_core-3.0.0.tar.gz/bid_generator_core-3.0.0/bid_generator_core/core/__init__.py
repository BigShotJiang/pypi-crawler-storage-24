"""Core modules for bid document generation."""
