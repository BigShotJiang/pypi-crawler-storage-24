"""
Core Constraint Checker - 核心约束检查器

实现投标文件生成的核心约束检查：
1. 内容真实性检查
2. 格式合规性检查
3. 响应完整性检查
4. 缺失项标注检查
"""

import re
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class ConstraintChecker:
    """核心约束检查器"""

    def __init__(self, priority_manager=None):
        """
        初始化约束检查器

        Args:
            priority_manager: 优先级数据管理器实例
        """
        self.priority_manager = priority_manager
        self.violations = []  # 违规记录
        self.warnings = []    # 警告记录
        self.check_results = {}  # 检查结果

    def check_content_authenticity(self, content: str, field_name: str,
                                   source_path: str = None) -> Tuple[bool, str]:
        """
        检查内容真实性

        Args:
            content: 待检查的内容
            field_name: 字段名称
            source_path: 内容来源路径

        Returns:
            (是否通过，说明)
        """
        if not content or content.strip() == "":
            return False, "内容为空"

        # 检查是否包含待补充标记
        if "【待补充：" in content:
            return True, "内容已标注为待补充"

        # 检查是否包含编造内容的特征词
        fabrication_indicators = [
            "可能", "大概", "或许", "推测", "估计", "应该",
            "approximately", "probably", "maybe", "estimated"
        ]

        for indicator in fabrication_indicators:
            if indicator in content.lower():
                self.violations.append({
                    "type": "内容真实性",
                    "field": field_name,
                    "issue": f"包含不确定性词汇：{indicator}",
                    "content": content[:100]
                })
                return False, f"包含不确定性词汇，可能为编造内容"

        # 如果提供了来源路径，验证来源
        if source_path and self.priority_manager:
            from .priority import SourcePriority
            if not self.priority_manager.validate_content_authenticity(content, [source_path]):
                self.warnings.append({
                    "type": "内容真实性",
                    "field": field_name,
                    "issue": "内容来源无法验证",
                    "content": content[:100]
                })
                return False, "内容来源无法验证"

        return True, "内容真实性检查通过"

    def check_format_compliance(self, document: Any, template_requirements: Dict) -> Tuple[bool, List[str]]:
        """
        检查格式合规性

        Args:
            document: 文档对象
            template_requirements: 模板格式要求字典

        Returns:
            (是否通过，问题列表)
        """
        issues = []

        # 检查页面设置
        if "page_setup" in template_requirements:
            page_setup = template_requirements["page_setup"]
            # 这里需要实际的文档对象来检查
            # 由于 python-docx 的限制，这里只做示例
            pass

        # 检查字体要求
        if "fonts" in template_requirements:
            fonts = template_requirements["fonts"]
            # 检查标题字体
            if "heading" in fonts:
                pass  # 需要实际检查文档

            # 检查正文字体
            if "body" in fonts:
                pass

        # 检查表格样式
        if "table_style" in template_requirements:
            table_style = template_requirements["table_style"]
            # 检查表格样式要求

        if issues:
            self.violations.append({
                "type": "格式合规性",
                "issues": issues
            })
            return False, issues

        return True, []

    def check_response_completeness(self) -> Tuple[bool, List[Dict]]:
        """
        检查响应完整性

        Returns:
            (是否通过，未响应要求列表)
        """
        if not self.priority_manager:
            return True, []

        unresponded = self.priority_manager.get_unresponded_requirements()

        if unresponded:
            self.violations.append({
                "type": "响应完整性",
                "count": len(unresponded),
                "requirements": unresponded
            })
            return False, unresponded

        return True, []

    def check_missing_items(self, content: str) -> Tuple[bool, List[str]]:
        """
        检查缺失项标注

        Args:
            content: 待检查的内容

        Returns:
            (是否通过，缺失项列表)
        """
        # 查找所有待补充标记
        missing_pattern = r"【待补充：(.*?)】"
        missing_items = re.findall(missing_pattern, content)

        if missing_items:
            self.warnings.append({
                "type": "缺失项标注",
                "count": len(missing_items),
                "items": missing_items
            })
            # 有缺失项但已标注，不算违规，只是警告
            return True, missing_items

        return True, []

    def check_substantial_clauses(self, tender_content: str) -> List[Dict]:
        """
        识别招标文件中的实质性条款

        Args:
            tender_content: 招标文件内容

        Returns:
            实质性条款列表
        """
        substantial_clauses = []

        # 识别★号条款
        star_pattern = r"★.*?(?:\n|$)"
        star_matches = re.findall(star_pattern, tender_content)
        for match in star_matches:
            substantial_clauses.append({
                "content": match.strip(),
                "type": "★号条款",
                "is_star": True
            })

        # 识别强制性表述
        mandatory_keywords = [
            "必须", "不得", "禁止", "严禁", "务必", "一定",
            "强制性", "实质性", "关键", "核心", "不可偏离"
        ]

        for keyword in mandatory_keywords:
            if keyword in tender_content:
                # 简单提取包含关键词的句子
                sentences = tender_content.split('。')
                for sentence in sentences:
                    if keyword in sentence and len(sentence.strip()) > 10:
                        substantial_clauses.append({
                            "content": sentence.strip() + "。",
                            "type": f"强制性表述 ({keyword})",
                            "is_star": False
                        })

        # 添加到优先级管理器
        if self.priority_manager:
            for clause in substantial_clauses:
                self.priority_manager.add_substantial_requirement(clause)

        logger.info(f"识别到 {len(substantial_clauses)} 条实质性条款")
        return substantial_clauses

    def run_all_checks(self, document_content: str = None,
                       template_requirements: Dict = None) -> Dict:
        """
        运行所有检查

        Args:
            document_content: 文档内容（可选）
            template_requirements: 模板要求（可选）

        Returns:
            检查结果字典
        """
        results = {
            "content_authenticity": {"passed": True, "issues": []},
            "format_compliance": {"passed": True, "issues": []},
            "response_completeness": {"passed": True, "issues": []},
            "missing_items": {"passed": True, "items": []},
            "overall_passed": True
        }

        # 内容真实性检查
        if document_content:
            passed, msg = self.check_content_authenticity(
                document_content, "文档整体内容"
            )
            results["content_authenticity"]["passed"] = passed
            results["content_authenticity"]["message"] = msg
            if not passed:
                results["overall_passed"] = False

        # 格式合规性检查
        if template_requirements:
            passed, issues = self.check_format_compliance(
                None, template_requirements
            )
            results["format_compliance"]["passed"] = passed
            results["format_compliance"]["issues"] = issues
            if not passed:
                results["overall_passed"] = False

        # 响应完整性检查
        passed, unresponded = self.check_response_completeness()
        results["response_completeness"]["passed"] = passed
        results["response_completeness"]["unresponded"] = unresponded
        if not passed:
            results["overall_passed"] = False

        # 缺失项标注检查
        if document_content:
            passed, items = self.check_missing_items(document_content)
            results["missing_items"]["passed"] = passed
            results["missing_items"]["items"] = items

        # 保存检查结果
        self.check_results = results

        # 记录日志
        if results["overall_passed"]:
            logger.info("✅ 所有核心约束检查通过")
        else:
            logger.error("❌ 核心约束检查未通过")
            for check_name, check_result in results.items():
                if check_name != "overall_passed" and not check_result.get("passed", True):
                    logger.error(f"  - {check_name}: {check_result.get('message', check_result.get('issues', []))}")

        return results

    def generate_check_report(self) -> str:
        """
        生成检查报告

        Returns:
            检查报告文本
        """
        report_lines = [
            "=" * 60,
            "投标文件核心约束检查报告",
            "=" * 60,
            ""
        ]

        # 违规记录
        if self.violations:
            report_lines.append("【违规项】")
            for i, violation in enumerate(self.violations, 1):
                report_lines.append(f"{i}. 类型：{violation.get('type', '未知')}")
                if 'field' in violation:
                    report_lines.append(f"   字段：{violation['field']}")
                if 'issue' in violation:
                    report_lines.append(f"   问题：{violation['issue']}")
            report_lines.append("")

        # 警告记录
        if self.warnings:
            report_lines.append("【警告项】")
            for i, warning in enumerate(self.warnings, 1):
                report_lines.append(f"{i}. 类型：{warning.get('type', '未知')}")
                if 'field' in warning:
                    report_lines.append(f"   字段：{warning['field']}")
                if 'issue' in warning:
                    report_lines.append(f"   问题：{warning['issue']}")
            report_lines.append("")

        # 检查结果
        if self.check_results:
            report_lines.append("【检查结果】")
            overall = "✅ 通过" if self.check_results.get("overall_passed") else "❌ 未通过"
            report_lines.append(f"总体结果：{overall}")

            for check_name, result in self.check_results.items():
                if check_name == "overall_passed":
                    continue
                status = "✅" if result.get("passed", True) else "❌"
                report_lines.append(f"  {status} {check_name}")

        report_lines.append("")
        report_lines.append("=" * 60)

        return "\n".join(report_lines)

    def get_violation_summary(self) -> Dict:
        """获取违规摘要"""
        return {
            "total_violations": len(self.violations),
            "total_warnings": len(self.warnings),
            "violations_by_type": self._count_by_type(self.violations),
            "warnings_by_type": self._count_by_type(self.warnings)
        }

    def _count_by_type(self, items: List[Dict]) -> Dict[str, int]:
        """按类型计数"""
        count = {}
        for item in items:
            item_type = item.get("type", "未知")
            count[item_type] = count.get(item_type, 0) + 1
        return count
