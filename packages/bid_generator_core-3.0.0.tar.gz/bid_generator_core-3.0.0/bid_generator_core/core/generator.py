"""
Bid Document Generator - 投标文件生成器

Framework-agnostic core implementation for generating professional bid proposal
documents with strict source priority management and core constraint checking.
"""

import os
import json
import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import logging

from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm
from docx.oxml.ns import qn
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT, WD_LINE_SPACING
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT

from .priority import PriorityDataManager, SourcePriority
from .constraints import ConstraintChecker

logger = logging.getLogger(__name__)


@dataclass
class GenerationResult:
    """生成结果数据类"""
    document_path: Path
    traceability_report: Dict
    quality_report: Dict
    success: bool
    message: str = ""
    missing_items: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "document_path": str(self.document_path),
            "traceability_report": self.traceability_report,
            "quality_report": self.quality_report,
            "success": self.success,
            "message": self.message,
            "missing_items": self.missing_items
        }


class BidGenerator:
    """
    投标文件生成器 - 框架无关核心实现

    Features:
    - Source priority management (P0-P3)
    - Core constraint checking
    - Content authenticity verification
    - Missing item marking
    """

    # 标准章节结构
    STANDARD_SECTIONS = [
        {
            "title": "一、投标函部分",
            "sections": ["投标函", "法定代表人身份证明", "授权委托书"]
        },
        {
            "title": "二、商务部分",
            "sections": [
                "开标一览表/投标报价表", "分项报价明细表", "商务条款响应/偏离表",
                "资格证明文件", "近年类似项目业绩表", "财务状况表", "信誉证明"
            ]
        },
        {
            "title": "三、技术部分",
            "sections": [
                "技术方案/实施方案", "技术规格响应/偏离表", "项目组织机构及人员配置",
                "进度计划", "质量保证措施", "安全文明施工措施", "售后服务承诺及方案"
            ]
        },
        {
            "title": "四、其他部分",
            "sections": ["招标文件要求的其他材料", "投标人认为需要说明的事项"]
        }
    ]

    def __init__(self,
                 data_dir: Optional[Union[str, Path]] = None,
                 tender_doc_path: Optional[Union[str, Path]] = None,
                 template_path: Optional[Union[str, Path]] = None,
                 company_info: Optional[Dict] = None,
                 project_info: Optional[Dict] = None,
                 output_dir: Optional[Union[str, Path]] = None,
                 auto_execute: bool = True):
        """
        初始化投标文件生成器

        Args:
            data_dir: 已有详细资料目录
            tender_doc_path: 招标文件路径
            template_path: 格式模板路径
            company_info: 公司信息（可选）
            project_info: 项目信息（可选）
            output_dir: 输出目录（可选）
            auto_execute: 是否自动执行工作流（默认True）
        """
        # 初始化核心组件
        self.priority_manager = PriorityDataManager()
        self.constraint_checker = ConstraintChecker(self.priority_manager)

        # 文档对象
        self.document: Optional[Document] = None
        self.template_requirements: Dict = {}
        self.current_date = datetime.now().strftime("%Y年%m月%d日")

        # 设置输出目录
        self.output_dir = self._validate_output_dir(output_dir)

        # 执行流程状态
        self.workflow_status = {
            "step1_tender_parsed": False,
            "step2_template_parsed": False,
            "step3_data_loaded": False,
            "step4_content_generated": False,
            "step5_quality_checked": False
        }

        # 存储输入参数
        self._data_dir = data_dir
        self._tender_doc_path = tender_doc_path
        self._template_path = template_path
        self._company_info = company_info
        self._project_info = project_info

        # 自动执行
        if auto_execute:
            self.execute()

    def execute(self) -> 'BidGenerator':
        """执行完整的工作流"""
        self._execute_workflow(
            self._data_dir,
            self._tender_doc_path,
            self._template_path,
            self._company_info,
            self._project_info
        )
        return self

    def _execute_workflow(self, data_dir, tender_doc_path, template_path,
                         company_info, project_info):
        """执行五步工作流程"""
        logger.info("=" * 60)
        logger.info("开始执行投标文件生成工作流")
        logger.info("=" * 60)

        try:
            # 第一步：解析招标文件（P0 优先级）
            logger.info("\n【第一步】解析招标文件...")
            self._parse_tender_document(tender_doc_path)
            self.workflow_status["step1_tender_parsed"] = True

            # 第二步：解析格式模板（P1 优先级）
            if template_path and os.path.exists(template_path):
                logger.info("\n【第二步】解析格式模板...")
                self._parse_template(template_path)
                self.workflow_status["step2_template_parsed"] = True
            else:
                logger.info("\n【第二步】无格式模板，使用默认格式")
                self._apply_default_format()
                self.workflow_status["step2_template_parsed"] = True

            # 第三步：读取已有资料（P2 优先级）
            logger.info("\n【第三步】读取已有详细资料...")
            self._load_existing_data(data_dir, company_info, project_info)
            self.workflow_status["step3_data_loaded"] = True

            # 第四步：内容整合与生成
            logger.info("\n【第四步】内容整合与生成...")
            self._generate_content()
            self.workflow_status["step4_content_generated"] = True

            # 第五步：质量检查
            logger.info("\n【第五步】质量检查...")
            self._quality_check()
            self.workflow_status["step5_quality_checked"] = True

            logger.info("\n" + "=" * 60)
            logger.info("工作流执行完成")
            logger.info("=" * 60)

        except Exception as e:
            logger.error(f"\n❌ 工作流执行失败：{str(e)}")
            raise

    def _parse_tender_document(self, tender_doc_path):
        """解析招标文件（P0 优先级）"""
        if not tender_doc_path or not os.path.exists(tender_doc_path):
            logger.warning("招标文件路径无效或文件不存在，跳过解析")
            return

        logger.info(f"解析招标文件：{tender_doc_path}")
        content = self._read_document_content(tender_doc_path)

        if not content:
            logger.warning("无法读取招标文件内容")
            return

        # 提取项目信息
        project_info = self._extract_tender_info(content)

        # 添加到 P0 数据源
        self.priority_manager.add_data_source(
            name="tender_document",
            content=content,
            priority=SourcePriority.P0,
            source_path=str(tender_doc_path),
            source_type="招标文件",
            metadata={"extracted_info": project_info}
        )

        # 识别实质性条款
        logger.info("识别实质性条款...")
        substantial_clauses = self.constraint_checker.check_substantial_clauses(content)
        logger.info(f"识别到 {len(substantial_clauses)} 条实质性条款")

        # 提取格式要求
        format_requirements = self._extract_format_requirements(content)
        if format_requirements:
            self.template_requirements.update(format_requirements)

        logger.info("✅ 招标文件解析完成")

    def _parse_template(self, template_path):
        """解析格式模板（P1 优先级）"""
        logger.info(f"解析格式模板：{template_path}")

        try:
            template_doc = Document(template_path)
            self.document = template_doc

            template_structure = self._extract_template_structure(template_doc)
            format_requirements = self._extract_format_from_template(template_doc)

            self.priority_manager.add_data_source(
                name="format_template",
                content=template_structure,
                priority=SourcePriority.P1,
                source_path=str(template_path),
                source_type="格式模板",
                metadata={"format_requirements": format_requirements}
            )

            self.template_requirements.update(format_requirements)
            logger.info("✅ 格式模板解析完成")

        except Exception as e:
            logger.error(f"模板解析失败：{str(e)}，使用默认格式")
            self._apply_default_format()

    def _load_existing_data(self, data_dir, company_info, project_info):
        """读取已有详细资料（P2 优先级）"""
        logger.info(f"从目录加载已有资料：{data_dir}")

        if not data_dir or not os.path.exists(data_dir):
            logger.warning("资料目录不存在，使用提供的信息字典")
            if company_info:
                self.priority_manager.add_data_source(
                    name="company_info",
                    content=company_info,
                    priority=SourcePriority.P2,
                    source_type="公司信息",
                    metadata={"source": "参数传入"}
                )
            if project_info:
                self.priority_manager.add_data_source(
                    name="project_info",
                    content=project_info,
                    priority=SourcePriority.P2,
                    source_type="项目信息",
                    metadata={"source": "参数传入"}
                )
            return

        data_dir = Path(data_dir)

        # 加载 JSON 数据文件
        data_files = {
            "company_info.json": ("company_info", "公司信息"),
            "project_info.json": ("project_info", "项目信息"),
            "qualifications.json": ("qualifications", "资质证书"),
            "project_cases.json": ("project_cases", "项目案例"),
            "team_info.json": ("team_info", "团队信息"),
        }

        for filename, (name, source_type) in data_files.items():
            file_path = data_dir / filename
            if file_path.exists():
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    self.priority_manager.add_data_source(
                        name=name,
                        content=data,
                        priority=SourcePriority.P2,
                        source_path=str(file_path),
                        source_type=source_type,
                        metadata={"file_type": "JSON"}
                    )
                    count = len(data) if isinstance(data, (list, dict)) else 1
                    logger.info(f"  ✓ 加载{source_type}：{count} 项")
                except Exception as e:
                    logger.warning(f"  ✗ 加载 {filename} 失败：{e}")

        logger.info("✅ 已有资料加载完成")

    def _generate_content(self):
        """内容整合与生成"""
        logger.info("开始生成投标文件内容")

        if not self.document:
            self.document = Document()
            self._apply_default_format()

        # 按标准章节结构生成
        for section in self.STANDARD_SECTIONS:
            logger.info(f"生成章节：{section['title']}")
            self._generate_section(section)

        logger.info("✅ 内容生成完成")

    def _quality_check(self) -> bool:
        """质量检查"""
        logger.info("运行质量检查...")

        doc_content = "投标文件内容"
        results = self.constraint_checker.run_all_checks(
            document_content=doc_content,
            template_requirements=self.template_requirements
        )

        report = self.constraint_checker.generate_check_report()
        logger.info("\n" + report)

        # 打印数据管理摘要
        summary = self.priority_manager.get_summary()
        logger.info("\n数据管理摘要:")
        logger.info(f"  - 数据源总数：{summary['total_sources']}")
        logger.info(f"  - P0(招标文件): {summary['by_priority']['P0']}")
        logger.info(f"  - P1(格式模板): {summary['by_priority']['P1']}")
        logger.info(f"  - P2(已有资料): {summary['by_priority']['P2']}")
        logger.info(f"  - 缺失项数量：{summary['missing_items_count']}")
        logger.info(f"  - 实质性要求：{summary['substantial_requirements_count']}")
        logger.info(f"  - 未响应要求：{summary['unresponded_count']}")

        return results.get("overall_passed", False)

    # Document Reading Methods
    def _read_document_content(self, file_path: Union[str, Path]) -> str:
        """读取文档内容（支持 PDF 和 Word）"""
        path = Path(file_path)
        ext = path.suffix.lower()

        if ext == '.pdf':
            return self._read_pdf_content(path)
        elif ext in ('.docx', '.doc'):
            return self._read_word_content(path)
        else:
            logger.warning(f"不支持的文件格式：{ext}")
            return ""

    def _read_pdf_content(self, file_path: Path) -> str:
        """读取 PDF 文件内容"""
        try:
            import PyPDF2
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                text = ''
                for page in pdf_reader.pages:
                    text += page.extract_text() + '\n'
                return text
        except ImportError:
            logger.warning("PyPDF2 未安装，无法解析 PDF")
            return ""
        except Exception as e:
            logger.error(f"读取 PDF 失败：{str(e)}")
            return ""

    def _read_word_content(self, file_path: Path) -> str:
        """读取 Word 文件内容"""
        try:
            doc = Document(file_path)
            return '\n'.join(para.text for para in doc.paragraphs)
        except Exception as e:
            logger.error(f"读取 Word 失败：{str(e)}")
            return ""

    # Information Extraction Methods
    def _extract_tender_info(self, content: str) -> Dict:
        """从招标文件内容中提取项目信息"""
        info = {}
        patterns = {
            "project_name": r"项目名称 [：:]\s*(.+?)(?:\n|$)",
            "project_no": r"(?:采购编号|项目编号)[：:]\s*(.+?)(?:\n|$)",
            "purchaser": r"(?:采购人|招标人)[：:]\s*(.+?)(?:\n|$)",
            "budget": r"(?:预算金额|最高限价)[：:]\s*(.+?)(?:\n|$)",
            "deadline": r"(?:投标截止时间|递交截止时间)[：:]\s*(.+?)(?:\n|$)",
        }

        for field, pattern in patterns.items():
            match = re.search(pattern, content, re.MULTILINE)
            if match:
                info[field] = match.group(1).strip()

        return info

    def _extract_format_requirements(self, content: str) -> Dict:
        """从招标文件中提取格式要求"""
        requirements = {}
        if "A4" in content:
            requirements["page_size"] = "A4"
        if "宋体" in content:
            requirements["font"] = "宋体"
        if "小四" in content or "12pt" in content.lower():
            requirements["font_size"] = "12pt"
        return requirements

    def _extract_template_structure(self, doc: Document) -> Dict:
        """提取模板结构"""
        structure = {"sections": [], "heading_styles": [], "tables": []}

        for para in doc.paragraphs:
            if para.style.name.startswith('Heading'):
                structure["sections"].append({
                    "level": para.style.name,
                    "text": para.text
                })

        for table in doc.tables:
            structure["tables"].append({
                "rows": len(table.rows),
                "cols": len(table.columns)
            })

        return structure

    def _extract_format_from_template(self, doc: Document) -> Dict:
        """从模板中提取格式要求"""
        requirements = {}

        if doc.sections:
            section = doc.sections[0]
            requirements["page_setup"] = {
                "page_width": section.page_width.cm,
                "page_height": section.page_height.cm,
                "top_margin": section.top_margin.cm,
                "bottom_margin": section.bottom_margin.cm,
                "left_margin": section.left_margin.cm,
                "right_margin": section.right_margin.cm,
            }

        if doc.paragraphs and doc.paragraphs[0].runs:
            run = doc.paragraphs[0].runs[0]
            requirements["fonts"] = {
                "body": {
                    "name": run.font.name,
                    "size": run.font.size.pt if run.font.size else 12
                }
            }

        return requirements

    # Formatting Methods
    def _apply_default_format(self):
        """应用默认格式设置"""
        if not self.document:
            self.document = Document()

        section = self.document.sections[0]
        section.page_width = Cm(21.0)
        section.page_height = Cm(29.7)
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(3.17)
        section.right_margin = Cm(3.17)

        self.template_requirements = {
            "page_size": "A4",
            "page_setup": {
                "page_width": 21.0, "page_height": 29.7,
                "top_margin": 2.54, "bottom_margin": 2.54,
                "left_margin": 3.17, "right_margin": 3.17,
            },
            "fonts": {
                "heading": {"name": "黑体", "size": 16},
                "body": {"name": "宋体", "size": 12}
            },
            "table_style": "三线表"
        }

        logger.info("应用默认格式设置")

    # Content Generation Methods
    def _generate_section(self, section: Dict):
        """生成单个章节"""
        section_title = section["title"]
        subsections = section["sections"]

        self._add_chapter_title(section_title)

        for subsection in subsections:
            self._generate_subsection(subsection, section_title)

    def _add_chapter_title(self, title: str):
        """添加章节标题"""
        para = self.document.add_paragraph()
        para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        para.space_before = Pt(18)
        para.space_after = Pt(18)

        run = para.add_run(title)
        run.font.size = Pt(22)
        run.font.bold = True
        run.font.name = '黑体'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')

    def _generate_subsection(self, subsection_name: str, parent_section: str):
        """生成小节内容"""
        para = self.document.add_paragraph()
        para.space_before = Pt(12)
        para.space_after = Pt(6)

        run = para.add_run(subsection_name)
        run.font.size = Pt(16)
        run.font.bold = True
        run.font.name = '黑体'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')

        content = self._get_subsection_content(subsection_name, parent_section)

        if isinstance(content, str):
            para = self.document.add_paragraph()
            para.space_before = Pt(6)
            para.space_after = Pt(6)
            para.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE

            run = para.add_run(content)
            run.font.size = Pt(12)
            run.font.name = '宋体'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        elif isinstance(content, dict) and content.get("type") == "table":
            self._add_table(content)

    def _get_subsection_content(self, subsection_name: str, parent_section: str):
        """获取小节内容"""
        content_mapping = {
            "投标函": self._generate_response_letter_content,
            "法定代表人身份证明": self._generate_legal_representative_content,
            "授权委托书": self._generate_authorization_content,
            "开标一览表/投标报价表": self._generate_bid_summary_table,
            "资格证明文件": self._generate_qualifications_content,
            "近年类似项目业绩表": self._generate_project_cases_content,
            "项目组织机构及人员配置": self._generate_team_content,
            "技术方案/实施方案": self._generate_technical_solution_content,
            "售后服务承诺及方案": self._generate_service_commitment_content,
        }

        for key, gen_func in content_mapping.items():
            if key in subsection_name:
                return gen_func()

        return f"【待补充：{parent_section} - {subsection_name}】"

    # Section Content Generators
    def _generate_response_letter_content(self) -> str:
        """生成投标函内容"""
        company_info = self.priority_manager.get_data("company_info", {})
        project_info = self.priority_manager.get_data("project_info", {})

        purchaser = project_info.get("purchaser", "【待补充：采购人】")
        project_name = project_info.get("name", "【待补充：项目名称】")
        project_no = project_info.get("project_no", "【待补充：采购编号】")

        return (
            f"致：{purchaser}\n\n"
            f'我方已仔细研究了"{project_name}"（采购编号：{project_no}）招标文件的全部内容，\n'
            f"包括澄清或者修改文件（如有）以及已提供的有关资料，我方完全理解并同意参加本次采购活动。\n\n"
            f"我方承诺：\n"
            f"1. 我方愿意按照招标文件规定的各项要求，向采购人提供所需的服务。\n"
            f"2. 我方投标报价详见开标一览表。\n"
            f"3. 一旦中标，我方将严格履行合同规定的责任和义务。\n\n"
            f"投标人：{company_info.get('name', '【待补充：公司名称】')}（盖章）\n"
            f"法定代表人：{company_info.get('legal_representative', '【待补充：法定代表人】')}（签字或盖章）\n"
            f"日期：{self.current_date}"
        )

    def _generate_legal_representative_content(self) -> str:
        """生成法定代表人身份证明内容"""
        company_info = self.priority_manager.get_data("company_info", {})

        return (
            f"投标人名称：{company_info.get('name', '【待补充：公司名称】')}\n"
            f"单位性质：{company_info.get('company_type', '【待补充：单位性质】')}\n"
            f"地址：{company_info.get('address', '【待补充：公司地址】')}\n"
            f"成立时间：{company_info.get('establishment_date', '【待补充：成立时间】')}\n"
            f"经营期限：{company_info.get('business_term', '【待补充：经营期限】')}\n\n"
            f"姓名：{company_info.get('legal_representative', '【待补充：法定代表人姓名】')} "
            f"性别：{company_info.get('legal_representative_gender', '【待补充：性别】')} "
            f"年龄：{company_info.get('legal_representative_age', '【待补充：年龄】')}\n"
            f"职务：{company_info.get('legal_representative_position', '【待补充：职务】')}\n\n"
            f"系 {company_info.get('name', '【待补充：公司名称】')} 的法定代表人。特此证明。"
        )

    def _generate_authorization_content(self) -> str:
        """生成授权委托书内容"""
        company_info = self.priority_manager.get_data("company_info", {})
        project_info = self.priority_manager.get_data("project_info", {})

        return (
            f"本授权书声明：注册于{company_info.get('address', '【待补充：公司地址】')}的{company_info.get('name', '【待补充：公司名称】')}\n"
            f"法定代表人{company_info.get('legal_representative', '【待补充：法定代表人姓名】')}代表本公司授权\n"
            f"{company_info.get('contact', '【待补充：被授权人】')}为本公司的合法代理人，\n"
            f'就"{project_info.get("name", "【待补充：项目名称】")}"项目的投标、\n'
            f"合同签订以及合同执行过程中的一切事务，以本公司名义全权处理。\n\n"
            f"本授权书自出具之日起生效，有效期至投标有效期结束。\n\n"
            f"法定代表人：（签字或盖章）\n"
            f"被授权人：（签字）\n"
            f"日期：{self.current_date}"
        )

    def _generate_bid_summary_table(self) -> Dict:
        """生成开标一览表（表格）"""
        project_info = self.priority_manager.get_data("project_info", {})

        return {
            "type": "table",
            "headers": ["项目名称", "采购编号", "投标报价（万元）", "交货期", "质量保证期"],
            "rows": [[
                project_info.get("name", "【待补充：项目名称】"),
                project_info.get("project_no", "【待补充：采购编号】"),
                project_info.get("bid_price", "【待补充：投标报价】"),
                project_info.get("delivery_time", "【待补充：交货期】"),
                project_info.get("warranty_period", "【待补充：质量保证期】")
            ]]
        }

    def _generate_qualifications_content(self) -> str:
        """生成资格证明文件内容"""
        qualifications = self.priority_manager.get_data("qualifications", {})

        if not qualifications:
            return "【待补充：资格证明文件】"

        content = "我方具备以下资格条件：\n\n"
        certificates = qualifications.get("certificates", [])
        for i, cert in enumerate(certificates, 1):
            content += f"{i}. {cert.get('name', '未知证书')}\n"
            if cert.get('note'):
                content += f"   说明：{cert['note']}\n"

        return content

    def _generate_project_cases_content(self) -> str:
        """生成近年类似项目业绩表内容"""
        project_cases = self.priority_manager.get_data("project_cases", {})

        if not project_cases:
            return "【待补充：近年类似项目业绩表】"

        content = "近年类似项目业绩：\n\n"
        cases = project_cases.get("cases", [])
        for i, case in enumerate(cases, 1):
            content += f"{i}. {case.get('name', '未知项目')}\n"
            content += f"   合同金额：{case.get('amount', '【待补充】')}\n"
            content += f"   完成时间：{case.get('completion_date', '【待补充】')}\n"
            content += f"   采购单位：{case.get('client', '【待补充】')}\n\n"

        return content

    def _generate_team_content(self) -> str:
        """生成项目组织机构及人员配置内容"""
        team_info = self.priority_manager.get_data("team_info", {})

        if not team_info:
            return "【待补充：项目组织机构及人员配置】"

        content = "项目团队配置：\n\n"
        members = team_info.get("members", [])
        for i, member in enumerate(members, 1):
            content += f"{i}. {member.get('name', '未知')} - {member.get('position', '未知职位')}\n"
            if member.get('qualifications'):
                content += f"   资质：{', '.join(member['qualifications'])}\n"

        return content

    def _generate_technical_solution_content(self) -> str:
        """生成技术方案内容"""
        return "【待补充：技术方案/实施方案 - 需根据招标文件技术要求详细编写】"

    def _generate_service_commitment_content(self) -> str:
        """生成服务承诺内容"""
        company_info = self.priority_manager.get_data("company_info", {})

        return (
            f"我方郑重承诺：\n\n"
            f"1. 严格按照招标文件和合同要求提供服务。\n"
            f"2. 保证服务质量达到招标文件规定的标准。\n"
            f"3. 提供完善的售后服务和技术支持。\n"
            f"4. 响应时间：接到通知后 2 小时内响应，24 小时内到达现场（如有需要）。\n"
            f"5. 质保期：按招标文件要求执行。\n\n"
            f"投标人：{company_info.get('name', '【待补充：公司名称】')}（盖章）\n"
            f"日期：{self.current_date}"
        )

    def _add_table(self, table_data: Dict):
        """添加表格到文档"""
        headers = table_data.get("headers", [])
        rows = table_data.get("rows", [])

        if not headers and not rows:
            return

        table = self.document.add_table(rows=len(rows) + 1, cols=len(headers))
        table.style = 'Table Grid'

        # 设置表头
        header_row = table.rows[0]
        for i, header in enumerate(headers):
            cell = header_row.cells[i]
            cell.text = header
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.font.bold = True
                    run.font.size = Pt(12)

        # 填充数据行
        for i, row_data in enumerate(rows):
            row = table.rows[i + 1]
            for j, cell_data in enumerate(row_data):
                cell = row.cells[j]
                cell.text = str(cell_data) if cell_data else "【待补充】"
                for paragraph in cell.paragraphs:
                    for run in paragraph.runs:
                        run.font.size = Pt(12)

    # Output Methods
    def _validate_output_dir(self, output_dir: Optional[Union[str, Path]]) -> Path:
        """验证并准备输出目录"""
        if output_dir:
            output_path = Path(output_dir).resolve()
        else:
            output_path = Path.cwd() / "outputs"
            output_path = output_path.resolve()

        logger.info(f"准备输出目录：{output_path}")

        if not output_path.exists():
            logger.info(f"输出目录不存在，将创建：{output_path}")
            output_path.mkdir(parents=True, exist_ok=True)

        if not os.access(output_path, os.W_OK):
            raise PermissionError(f"输出目录无写入权限：{output_path}")

        self._check_disk_space(output_path, min_space_mb=100)
        logger.info(f"✅ 输出目录验证通过：{output_path}")

        return output_path

    def _check_disk_space(self, path: Path, min_space_mb: int = 100):
        """检查磁盘空间是否足够"""
        try:
            stat = shutil.disk_usage(path)
            free_space_mb = stat.free / (1024 * 1024)

            if free_space_mb < min_space_mb:
                raise OSError(
                    f"磁盘空间不足。需要至少 {min_space_mb}MB，"
                    f"当前可用 {free_space_mb:.1f}MB"
                )

            logger.info(f"磁盘空间检查通过：可用 {free_space_mb:.1f}MB")

        except Exception as e:
            logger.warning(f"无法检查磁盘空间：{str(e)}")

    def save(self, output_path: Optional[Union[str, Path]] = None,
             use_timestamp: bool = True) -> GenerationResult:
        """
        保存生成的投标文件

        Args:
            output_path: 输出文件路径（可选）
            use_timestamp: 是否添加时间戳

        Returns:
            GenerationResult 包含生成结果和报告
        """
        try:
            if not output_path:
                company_info = self.priority_manager.get_data("company_info", {})
                project_info = self.priority_manager.get_data("project_info", {})

                company_name = company_info.get("name", "未知公司")
                project_name = project_info.get("name", "未知项目")

                if use_timestamp:
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"投标文件_{company_name}_{project_name}_{timestamp}.docx"
                else:
                    filename = f"投标文件_{company_name}_{project_name}.docx"

                output_path = self.output_dir / filename

            output_path = Path(output_path)

            # 保存文档
            self.document.save(output_path)
            logger.info(f"✅ 投标文件已生成：{output_path}")

            # 生成可追溯性报告
            traceability_report = self.priority_manager.generate_traceability_report()
            report_path = output_path.with_suffix('.traceability.json')
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(traceability_report, f, ensure_ascii=False, indent=2)
            logger.info(f"📊 可追溯性报告已保存：{report_path}")

            # 获取质量报告
            quality_report = self.constraint_checker.check_results

            # 获取缺失项
            missing_items = [
                item["marker"] for item in self.priority_manager.missing_items
            ]

            return GenerationResult(
                document_path=output_path,
                traceability_report=traceability_report,
                quality_report=quality_report,
                success=True,
                message="投标文件生成成功",
                missing_items=missing_items
            )

        except Exception as e:
            logger.error(f"❌ 生成投标文件时发生错误：{str(e)}")
            return GenerationResult(
                document_path=None,
                traceability_report={},
                quality_report={},
                success=False,
                message=f"生成失败：{str(e)}",
                missing_items=[]
            )

    def generate(self, **kwargs) -> Union[str, Path, GenerationResult]:
        """
        生成并返回结果（兼容旧版接口）

        Returns:
            根据参数返回文件路径或 GenerationResult
        """
        return_result = kwargs.pop('return_result', False)
        result = self.save(**kwargs)

        if result.success:
            # 兼容旧接口：如果返回详细结果
            if return_result:
                return result
            return result.document_path
        else:
            raise RuntimeError(result.message)


def generate_bid_document(
    data_dir: Optional[Union[str, Path]] = None,
    tender_doc_path: Optional[Union[str, Path]] = None,
    template_path: Optional[Union[str, Path]] = None,
    output_dir: Optional[Union[str, Path]] = None,
    company_info: Optional[Dict] = None,
    project_info: Optional[Dict] = None,
    **kwargs
) -> Union[str, Path, GenerationResult]:
    """
    便捷函数：生成投标文件

    Args:
        data_dir: 已有资料目录
        tender_doc_path: 招标文件路径
        template_path: 模板路径
        output_dir: 输出目录
        company_info: 公司信息
        project_info: 项目信息
        **kwargs: 其他参数

    Returns:
        生成的文件路径或 GenerationResult
    """
    generator = BidGenerator(
        data_dir=data_dir,
        tender_doc_path=tender_doc_path,
        template_path=template_path,
        output_dir=output_dir,
        company_info=company_info,
        project_info=project_info,
        auto_execute=True
    )

    return generator.generate(**kwargs)
