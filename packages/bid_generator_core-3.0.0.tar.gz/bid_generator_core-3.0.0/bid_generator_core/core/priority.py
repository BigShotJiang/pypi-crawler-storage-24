"""
Data Source Priority Manager - 资料来源优先级管理器

实现资料来源的优先级管理（P0-P3），确保内容真实性和可追溯性
"""

import os
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class SourcePriority(Enum):
    """资料来源优先级枚举"""
    P0 = "P0"  # 最高优先级 - 招标文件
    P1 = "P1"  # 格式模板
    P2 = "P2"  # 已有详细资料
    P3 = "P3"  # 行业通用规范


class DataSource:
    """数据源信息类"""

    def __init__(self, content: Any, priority: SourcePriority, source_path: str = None,
                 source_type: str = None, metadata: Dict = None):
        """
        初始化数据源

        Args:
            content: 数据内容
            priority: 优先级
            source_path: 来源文件路径
            source_type: 来源类型（如：招标文件、模板、公司资料等）
            metadata: 额外元数据
        """
        self.content = content
        self.priority = priority
        self.source_path = source_path
        self.source_type = source_type
        self.metadata = metadata or {}
        self.traceability = []  # 可追溯性记录

    def add_trace(self, action: str, details: str):
        """添加追溯记录"""
        from datetime import datetime
        self.traceability.append({
            "action": action,
            "details": details,
            "timestamp": str(datetime.now())
        })


class PriorityDataManager:
    """优先级数据管理器"""

    def __init__(self):
        """初始化优先级数据管理器"""
        self.data_sources: Dict[str, DataSource] = {}
        self.missing_items: List[Dict] = []  # 缺失项记录
        self.substantial_requirements: List[Dict] = []  # 实质性要求列表

    def add_data_source(self, name: str, content: Any, priority: SourcePriority,
                       source_path: str = None, source_type: str = None,
                       metadata: Dict = None):
        """
        添加数据源

        Args:
            name: 数据源名称
            content: 数据内容
            priority: 优先级
            source_path: 来源路径
            source_type: 来源类型
            metadata: 元数据
        """
        self.data_sources[name] = DataSource(
            content=content,
            priority=priority,
            source_path=source_path,
            source_type=source_type,
            metadata=metadata
        )
        logger.info(f"添加数据源：{name} (优先级：{priority.value}, 类型：{source_type})")

    def get_data(self, name: str, default: Any = None) -> Any:
        """
        获取数据

        Args:
            name: 数据源名称
            default: 默认值（如果数据不存在）

        Returns:
            数据内容
        """
        if name not in self.data_sources:
            logger.warning(f"数据源不存在：{name}")
            return default

        data_source = self.data_sources[name]
        data_source.add_trace("access", f"读取数据：{name}")
        return data_source.content

    def get_priority_data(self, priority: SourcePriority) -> Dict[str, DataSource]:
        """获取指定优先级的所有数据源"""
        return {
            name: source
            for name, source in self.data_sources.items()
            if source.priority == priority
        }

    def resolve_conflict(self, field_name: str) -> Tuple[Any, str]:
        """
        根据优先级解决字段冲突

        Args:
            field_name: 字段名称

        Returns:
            (数据值，来源说明)
        """
        # 按优先级排序查找
        for priority in [SourcePriority.P0, SourcePriority.P1, SourcePriority.P2, SourcePriority.P3]:
            sources = self.get_priority_data(priority)
            for name, source in sources.items():
                if isinstance(source.content, dict) and field_name in source.content:
                    value = source.content[field_name]
                    source.add_trace("conflict_resolution", f"字段 {field_name} 被选中")
                    return value, f"{source.source_type} ({source.source_path})"

        # 未找到
        self.record_missing(field_name, "所有数据源中均未找到该字段")
        return None, "未找到"

    def record_missing(self, field_name: str, reason: str, required_by: str = None):
        """
        记录缺失项

        Args:
            field_name: 缺失的字段/内容名称
            reason: 缺失原因
            required_by: 要求该内容的来源（如招标文件章节）
        """
        missing_item = {
            "field": field_name,
            "reason": reason,
            "required_by": required_by,
            "status": "待补充",
            "marker": f"【待补充：{field_name}】"
        }
        self.missing_items.append(missing_item)
        logger.warning(f"记录缺失项：{field_name} - {reason}")

    def get_missing_marker(self, field_name: str) -> str:
        """获取缺失项标记文本"""
        return f"【待补充：{field_name}】"

    def add_substantial_requirement(self, requirement: Dict):
        """
        添加实质性要求

        Args:
            requirement: 要求信息字典，应包含：
                - content: 要求内容
                - section: 所在章节
                - is_star: 是否★号条款
                - response_status: 响应状态
        """
        requirement["response_status"] = "待响应"
        self.substantial_requirements.append(requirement)
        logger.info(f"添加实质性要求：{requirement.get('content', '')[:50]}...")

    def mark_requirement_responded(self, requirement_idx: int, response_content: str,
                                   source_path: str):
        """
        标记要求已响应

        Args:
            requirement_idx: 要求索引
            response_content: 响应内容
            source_path: 响应内容来源路径
        """
        if 0 <= requirement_idx < len(self.substantial_requirements):
            req = self.substantial_requirements[requirement_idx]
            req["response_status"] = "已响应"
            req["response_content"] = response_content
            req["response_source"] = source_path
            logger.info(f"实质性要求已响应：{req['content'][:50]}...")
        else:
            logger.error(f"无效的要求索引：{requirement_idx}")

    def get_unresponded_requirements(self) -> List[Dict]:
        """获取所有未响应的实质性要求"""
        return [
            req for req in self.substantial_requirements
            if req.get("response_status") != "已响应"
        ]

    def generate_traceability_report(self) -> Dict:
        """
        生成可追溯性报告

        Returns:
            报告字典，包含：
                - data_sources: 数据源列表
                - missing_items: 缺失项列表
                - substantial_requirements: 实质性要求响应情况
                - access_traces: 访问追溯记录
        """
        report = {
            "data_sources": [],
            "missing_items": self.missing_items,
            "substantial_requirements": self.substantial_requirements,
            "access_traces": []
        }

        # 数据源信息
        for name, source in self.data_sources.items():
            report["data_sources"].append({
                "name": name,
                "priority": source.priority.value,
                "source_type": source.source_type,
                "source_path": source.source_path,
                "trace_count": len(source.traceability)
            })

            # 追溯记录
            for trace in source.traceability:
                report["access_traces"].append({
                    "data_source": name,
                    **trace
                })

        return report

    def validate_content_authenticity(self, content: str, allowed_sources: List[str] = None) -> bool:
        """
        验证内容真实性

        Args:
            content: 待验证的内容
            allowed_sources: 允许的来源路径列表（如果为 None，则检查所有 P2 优先级来源）

        Returns:
            是否真实（来源于已有资料）
        """
        if not content or content.strip() == "":
            return False

        # 如果内容包含待补充标记，认为不是真实内容
        if "【待补充：" in content:
            return False

        # 检查是否来源于允许的数据源
        if allowed_sources is None:
            allowed_sources = [
                source.source_path
                for source in self.data_sources.values()
                if source.priority == SourcePriority.P2
            ]

        # 简单验证：检查内容是否能在已有资料中找到
        # 这里可以实现更复杂的验证逻辑
        for source_name, source in self.data_sources.items():
            if source.priority == SourcePriority.P2:
                if isinstance(source.content, str) and content in source.content:
                    return True
                elif isinstance(source.content, dict):
                    # 检查字典值
                    for value in source.content.values():
                        if isinstance(value, str) and content in value:
                            return True

        # 如果没有找到确切来源，记录警告
        logger.warning(f"内容真实性无法验证：{content[:50]}...")
        return False  # 严格模式下，找不到来源就认为不真实

    def get_summary(self) -> Dict:
        """获取数据管理摘要"""
        return {
            "total_sources": len(self.data_sources),
            "by_priority": {
                "P0": len(self.get_priority_data(SourcePriority.P0)),
                "P1": len(self.get_priority_data(SourcePriority.P1)),
                "P2": len(self.get_priority_data(SourcePriority.P2)),
                "P3": len(self.get_priority_data(SourcePriority.P3)),
            },
            "missing_items_count": len(self.missing_items),
            "substantial_requirements_count": len(self.substantial_requirements),
            "unresponded_count": len(self.get_unresponded_requirements())
        }
