# Bid Generator Core

A framework-agnostic core library for generating professional bid proposal documents (投标文件) with strict source priority management and core constraint checking.

## Features

- **Source Priority Management (P0-P3)**: Strict hierarchy for data sources
  - P0: Tender document (highest priority)
  - P1: Format template
  - P2: Existing data (company info, qualifications, cases)
  - P3: Industry standards (reference only)

- **Core Constraints**:
  - Content authenticity - no fabrication
  - Format compliance - follow template
  - Response completeness - address all substantial clauses
  - Missing items marked as `【待补充：XXX】`

- **Five-Step Workflow**:
  1. Parse tender document
  2. Parse format template
  3. Load existing data
  4. Content generation
  5. Quality check

## Installation

```bash
pip install bid-generator-core
```

## Quick Start

```python
from bid_generator_core import BidGenerator, generate_bid_document

# Method 1: Using the generator class
generator = BidGenerator(
    data_dir="./data",
    tender_doc_path="./tender.pdf",
    template_path="./template.docx",
    output_dir="./outputs"
)

result = generator.save()
print(f"Document generated: {result.document_path}")
print(f"Missing items: {result.missing_items}")

# Method 2: Using the convenience function
output_path = generate_bid_document(
    data_dir="./data",
    tender_doc_path="./tender.pdf"
)
```

## Data Directory Structure

```
data/
├── company_info.json      # Company basic information
├── project_info.json      # Project details
├── qualifications.json    # Certifications and qualifications
├── team_info.json         # Team member information
└── project_cases.json     # Historical project cases
```

## Advanced Usage

```python
from bid_generator_core import BidGenerator, GenerationResult

# Custom configuration
generator = BidGenerator(
    data_dir="./data",
    tender_doc_path="./tender.pdf",
    template_path="./template.docx",
    company_info={"name": "My Company"},  # Override from JSON
    auto_execute=True
)

# Get detailed result
result: GenerationResult = generator.save(return_result=True)

# Access reports
print(result.traceability_report)  # Data source traceability
print(result.quality_report)       # Quality check results
```

## Framework Adapters

This core library is used by various framework adapters:

- **OpenClaw Skill**: See `adapters/openclaw/`
- **Claude Code Skill**: See `.claude/skills/bid-generator/`

## License

MIT License
