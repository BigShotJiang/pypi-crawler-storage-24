#!/bin/bash
set -e

# Script to publish bid-generator-core to PyPI

cd "$(dirname "$0")/.."

echo "=== Building bid-generator-core ==="

# Clean previous builds
rm -rf dist/ build/ *.egg-info

# Install build tools if needed
echo "=== Installing build tools ==="
python3 -m pip install --quiet build twine --break-system-packages

# Run tests
echo "=== Running tests ==="
python3 -m pip install -e ".[dev]" --break-system-packages
python3 -m pytest tests/ -v

# Build package
echo "=== Building package ==="
python3 -m build

# Check package
echo "=== Checking package ==="
python3 -m twine check dist/*

echo ""
echo "=== Package built successfully ==="
echo ""
echo "To publish to PyPI, run:"
echo "  twine upload dist/*"
echo ""
echo "Or use the GitHub Action by pushing a tag:"
echo "  git tag v3.0.0"
echo "  git push origin v3.0.0"
