import ast
import io
import sys
import threading
from typing import Any

try:
    from IPython.core.interactiveshell import InteractiveShell
except ImportError:  # pragma: no cover - optional dependency guard
    InteractiveShell = None  # type: ignore[assignment]


MAX_STDOUT_LENGTH = 10_000
MAX_STDERR_LENGTH = 5_000

# Module-level lock to serialize stdout/stderr redirection across ALL Python
# instances.  IPython writes to the global sys.stdout/sys.stderr, so concurrent
# redirects from different sessions would corrupt each other's captured output.
_STDOUT_REDIRECT_LOCK = threading.Lock()


def _validate_code_safety(code: str) -> str | None:
    blocked_import_roots = {
        "os",
        "subprocess",
        "socket",
        "ctypes",
        "multiprocessing",
        "importlib",
        "shutil",
        "sys",
        "pty",
    }
    blocked_calls = {
        "eval",
        "exec",
        "compile",
        "__import__",
        "open",
        "input",
        "getattr",
        "setattr",
        "delattr",
        "hasattr",
    }
    blocked_attrs = {
        "system",
        "popen",
        "spawn",
        "run",
        "call",
        "check_call",
        "check_output",
        "startfile",
        "remove",
        "unlink",
        "rmtree",
        "rmdir",
        "__subclasses__",
        "__bases__",
        "__globals__",
    }

    if "%" in code:
        return "Blocked unsafe magic command usage"

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None

    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and node.id == "__builtins__":
            return "Blocked unsafe access: __builtins__"

        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".", 1)[0]
                if root in blocked_import_roots:
                    return f"Blocked unsafe import: {root}"

        if isinstance(node, ast.ImportFrom):
            if node.module:
                root = node.module.split(".", 1)[0]
                if root in blocked_import_roots:
                    return f"Blocked unsafe import: {root}"

        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in blocked_calls:
                return f"Blocked unsafe call: {node.func.id}"
            if isinstance(node.func, ast.Attribute):
                attr = node.func.attr
                if attr in blocked_attrs or attr.startswith("__"):
                    return f"Blocked unsafe call: {attr}"

        if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            return f"Blocked unsafe attribute access: {node.attr}"

    return None


class PythonInstance:
    def __init__(self, session_id: str) -> None:
        if InteractiveShell is None:
            raise RuntimeError("IPython is required for python tool execution")

        self.session_id = session_id
        self.is_running = True
        self._execution_lock = threading.Lock()

        import os

        os.chdir("/workspace")

        self.shell = InteractiveShell()
        self.shell.init_completer()
        self.shell.init_history()
        self.shell.init_logger()

        self._setup_proxy_functions()

    def _setup_proxy_functions(self) -> None:
        try:
            from phantom.tools.proxy import proxy_actions

            proxy_functions = [
                "list_requests",
                "list_sitemap",
                "repeat_request",
                "scope_rules",
                "send_request",
                "view_request",
                "view_sitemap_entry",
            ]

            proxy_dict = {name: getattr(proxy_actions, name) for name in proxy_functions}
            self.shell.user_ns.update(proxy_dict)
        except ImportError:
            pass

    def _validate_session(self) -> dict[str, Any] | None:
        if not self.is_running:
            return {
                "session_id": self.session_id,
                "stdout": "",
                "stderr": "Session is not running",
                "result": None,
            }
        return None

    def _truncate_output(self, content: str, max_length: int, suffix: str) -> str:
        if len(content) > max_length:
            return content[:max_length] + suffix
        return content

    def _format_execution_result(
        self, execution_result: Any, stdout_content: str, stderr_content: str
    ) -> dict[str, Any]:
        stdout = self._truncate_output(
            stdout_content, MAX_STDOUT_LENGTH, "... [stdout truncated at 10k chars]"
        )

        if execution_result.result is not None:
            if stdout and not stdout.endswith("\n"):
                stdout += "\n"
            result_repr = repr(execution_result.result)
            result_repr = self._truncate_output(
                result_repr, MAX_STDOUT_LENGTH, "... [result truncated at 10k chars]"
            )
            stdout += result_repr

        stdout = self._truncate_output(
            stdout, MAX_STDOUT_LENGTH, "... [output truncated at 10k chars]"
        )

        stderr_content = stderr_content if stderr_content else ""
        stderr_content = self._truncate_output(
            stderr_content, MAX_STDERR_LENGTH, "... [stderr truncated at 5k chars]"
        )

        if (
            execution_result.error_before_exec or execution_result.error_in_exec
        ) and not stderr_content:
            stderr_content = "Execution error occurred"

        return {
            "session_id": self.session_id,
            "stdout": stdout,
            "stderr": stderr_content,
            "result": repr(execution_result.result)
            if execution_result.result is not None
            else None,
        }

    def _handle_execution_error(self, error: BaseException) -> dict[str, Any]:
        error_msg = str(error)
        error_msg = self._truncate_output(
            error_msg, MAX_STDERR_LENGTH, "... [error truncated at 5k chars]"
        )

        return {
            "session_id": self.session_id,
            "stdout": "",
            "stderr": error_msg,
            "result": None,
        }

    def _validate_code_safety(self, code: str) -> str | None:
        return _validate_code_safety(code)

    def execute_code(self, code: str, timeout: int = 30) -> dict[str, Any]:
        session_error = self._validate_session()
        if session_error:
            return session_error

        safety_error = self._validate_code_safety(code)
        if safety_error:
            return self._handle_execution_error(PermissionError(safety_error))

        with self._execution_lock:
            result_container: dict[str, Any] = {}
            stdout_capture = io.StringIO()
            stderr_capture = io.StringIO()
            cancelled = threading.Event()

            def _trace_calls(frame: Any, event: str, arg: Any) -> Any:
                if cancelled.is_set():
                    raise SystemExit("Execution timeout")
                return _trace_calls

            def _run_code() -> None:
                # Acquire the module-level lock inside the thread so that only
                # one Python instance redirects sys.stdout/stderr at a time.
                sys.settrace(_trace_calls)
                lock_acquired = False
                old_stdout, old_stderr = sys.stdout, sys.stderr
                try:
                    _STDOUT_REDIRECT_LOCK.acquire()
                    lock_acquired = True
                    sys.stdout = stdout_capture
                    sys.stderr = stderr_capture
                    execution_result = self.shell.run_cell(code, silent=False, store_history=True)
                    result_container["execution_result"] = execution_result
                    result_container["stdout"] = stdout_capture.getvalue()
                    result_container["stderr"] = stderr_capture.getvalue()
                except (KeyboardInterrupt, SystemExit) as e:
                    result_container["error"] = e
                except Exception as e:  # noqa: BLE001
                    result_container["error"] = e
                finally:
                    sys.stdout = old_stdout
                    sys.stderr = old_stderr
                    sys.settrace(None)
                    if lock_acquired:
                        try:
                            _STDOUT_REDIRECT_LOCK.release()
                        except RuntimeError:
                            # Lock may have been force-released on timeout.
                            pass
                cancelled.set()

            exec_thread = threading.Thread(target=_run_code, daemon=True)
            exec_thread.start()
            exec_thread.join(timeout=timeout)

            if exec_thread.is_alive():
                cancelled.set()
                try:
                    if _STDOUT_REDIRECT_LOCK.locked():
                        _STDOUT_REDIRECT_LOCK.release()
                except RuntimeError:
                    pass
                exec_thread.join(timeout=1)
                return self._handle_execution_error(
                    TimeoutError(f"Code execution timed out after {timeout} seconds")
                )

            if "error" in result_container:
                return self._handle_execution_error(result_container["error"])

            if "execution_result" in result_container:
                return self._format_execution_result(
                    result_container["execution_result"],
                    result_container.get("stdout", ""),
                    result_container.get("stderr", ""),
                )

            return self._handle_execution_error(RuntimeError("Unknown execution error"))

    def close(self) -> None:
        self.is_running = False
        self.shell.reset(new_session=False)

    def is_alive(self) -> bool:
        return self.is_running
