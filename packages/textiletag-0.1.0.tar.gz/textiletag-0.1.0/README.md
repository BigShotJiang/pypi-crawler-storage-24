# TextileTag Python SDK

Encode, decode, and validate 14-character TextileTag clothing codes.

## Install

```bash
pip install textiletag
```

## Usage

```python
from textiletag import encode, decode, validate, describe

# Encode a garment
code = encode(
    garment_type="TP", material="CO", wash="N", temp="C",
    dry="T", color="W", size="3", iron=1, bleach=2,
    dryclean=0, country="US",
)
print(code)  # 01TPCONCTW3AUS

# Decode a code
result = decode("01TPCONCTW3AUS")
print(result["garment_type_label"])  # Top
print(result["material_label"])      # Cotton

# Get human-readable description
print(describe("01TPCONCTW3AUS"))
# M white cotton top. Wash: Normal, cold water. Dry: Tumble Dry. ...

# Validate a code
errors = validate("INVALID")
print(errors)  # ['Must be 14 characters, got 7']

errors = validate("01TPCONCTW3AUS")
print(errors)  # [] (empty = valid)
```

## API

| Function | Description |
|---|---|
| `encode(...)` | Encode garment attributes into a 14-character code |
| `decode(code)` | Decode a code into a dictionary of fields and labels |
| `validate(code)` | Return a list of validation errors (empty = valid) |
| `describe(code)` | Return a human-readable description string |
| `encode_flags(iron, bleach, dryclean)` | Pack care flags into one character |
| `decode_flags(char)` | Unpack a care flags character |

## Links

- [TextileTag Spec](https://github.com/madhugoundla/TextileTag)
- [Web Demo](https://madhugoundla.github.io/TextileTag/)
