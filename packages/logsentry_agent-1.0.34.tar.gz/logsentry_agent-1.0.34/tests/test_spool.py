from pathlib import Path

from logsentry_agent.spool import SpoolQueue


def test_spool_enqueue_and_dequeue(tmp_path: Path):
    spool = SpoolQueue(tmp_path / "spool.db", max_mb=1)
    payload = {"events": [{"source": "test"}]}
    assert spool.enqueue(payload) is True

    batch = spool.dequeue_batch(10)
    assert len(batch) == 1
    row_id, stored = batch[0]
    assert stored == payload

    spool.delete([row_id])
    assert spool.pending_count() == 0


def test_spool_priority_eviction(tmp_path: Path):
    spool = SpoolQueue(tmp_path / "spool.db", max_mb=1, drop_priority=["low", "high"])
    large_payload = {"events": [{"message": "x" * 900_000}]}
    assert spool.enqueue(large_payload, priority="low") is True
    assert spool.enqueue(large_payload, priority="high") is True

    batch = spool.dequeue_batch(10)
    assert len(batch) == 1
    _, remaining = batch[0]
    assert remaining == large_payload


def test_spool_encrypts_payload(tmp_path: Path):
    key = SpoolQueue.derive_key("secret")
    spool = SpoolQueue(tmp_path / "spool.db", max_mb=1, encrypt=True, encryption_key=key)
    payload = {"events": [{"source": "test"}]}
    assert spool.enqueue(payload, priority="low") is True

    with spool._connect() as conn:
        row = conn.execute("SELECT payload FROM spool").fetchone()
    assert row is not None
    stored = row[0]
    assert "events" not in stored


def test_spool_dequeue_drops_corrupted_json_rows(tmp_path: Path):
    spool = SpoolQueue(tmp_path / "spool.db", max_mb=1)
    payload = {"events": [{"source": "test"}]}
    assert spool.enqueue(payload) is True

    with spool._connect() as conn:
        conn.execute(
            "INSERT INTO spool (payload, priority) VALUES (?, ?)",
            (
                '{"events":[{"source":"bad"}]}medium\ufffdw\ufffde{"events":[{"source":"junk"}]}',
                "low",
            ),
        )
        conn.commit()

    batch = spool.dequeue_batch(10)
    assert len(batch) == 2
    assert batch[0][1] == payload
    assert batch[1][1] == {"events": [{"source": "bad"}]}


def test_spool_dequeue_drops_unrecoverable_rows(tmp_path: Path):
    spool = SpoolQueue(tmp_path / "spool.db", max_mb=1)

    with spool._connect() as conn:
        conn.execute(
            "INSERT INTO spool (payload, priority) VALUES (?, ?)",
            ("medium\ufffdw\ufffdr\ufffde", "low"),
        )
        conn.commit()

    assert spool.dequeue_batch(10) == []
    assert spool.pending_count() == 0


def test_spool_tracks_tampered_rows(tmp_path: Path):
    spool = SpoolQueue(tmp_path / "spool.db", max_mb=1, mac_key="secret")
    assert spool.enqueue({"events": [{"source": "test"}]}) is True

    with spool._connect() as conn:
        conn.execute(
            "UPDATE spool SET payload = ? WHERE id = 1", ('{"events":[{"source":"tampered"}]}',)
        )
        conn.commit()

    assert spool.dequeue_batch(10) == []
    assert spool.last_invalid_count == 1
    assert spool.pending_count() == 0
