"""
AISecOps SDK Utilities
========================
Internal shared helpers — not part of the public API.
"""

from __future__ import annotations

import logging
import time
from typing import Any


def get_logger(name: str, level: str = "INFO") -> logging.Logger:
    """Return a ``logging.Logger`` configured to the given level."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    return logger


def truncate(text: str, max_len: int = 120) -> str:
    """Truncate *text* to *max_len* chars, appending '…' if cut."""
    return text if len(text) <= max_len else text[:max_len] + "…"


def safe_get(d: dict[str, Any], *keys: str, default: Any = None) -> Any:
    """Safely traverse nested dict with dotted keys; return *default* if missing."""
    current = d
    for key in keys:
        if not isinstance(current, dict):
            return default
        current = current.get(key, default)
    return current


def elapsed_ms(start: float) -> float:
    """Return milliseconds elapsed since *start* (``time.perf_counter()`` value)."""
    return round((time.perf_counter() - start) * 1000, 2)


def build_threat_summary(analysis: dict[str, Any]) -> str:
    """Format a one-line human-readable threat summary from analysis output."""
    level = analysis.get("threat_level", "unknown").upper()
    score = analysis.get("fusion_score", 0.0)
    tier = analysis.get("tier", "")
    action = analysis.get("recommended_action", "")
    parts = [f"Threat={level}", f"Score={score:.3f}"]
    if tier:
        parts.append(f"Tier={tier}")
    if action:
        parts.append(f"Action={action}")
    return " | ".join(parts)


def sanitize_prompt_for_log(prompt: str, max_len: int = 80) -> str:
    """
    Produce a log-safe version of a prompt string.

    Strips newlines and truncates to avoid log injection / noise.
    """
    one_line = " ".join(prompt.split())
    return truncate(one_line, max_len)
