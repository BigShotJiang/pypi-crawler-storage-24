"""
AISecOps SDK — Configuration
==============================
Centralised SDK settings. All values can be overridden via environment
variables or constructor arguments.

Environment variables
---------------------
AISECOPS_BASE_URL        URL of the AISecOps backend (default localhost:8000)
AISECOPS_API_KEY         Optional bearer token for authenticated deployments
AISECOPS_TENANT_ID       Default tenant identifier (default "default")
AISECOPS_SESSION_ID      Default session identifier (auto-generated if unset)
AISECOPS_TIMEOUT         HTTP timeout in seconds (default 30)
AISECOPS_STRICT_MODE     "true" → raise on suspicious prompts (default false)
AISECOPS_TELEMETRY       "false" → disable telemetry (default true)
AISECOPS_LOG_LEVEL       Log verbosity: DEBUG | INFO | WARNING | ERROR
"""

from __future__ import annotations

import os
import uuid
from dataclasses import dataclass, field


def _env_bool(key: str, default: bool) -> bool:
    val = os.getenv(key, "").lower()
    if val in ("1", "true", "yes"):
        return True
    if val in ("0", "false", "no"):
        return False
    return default


@dataclass
class SDKConfig:
    """
    SDK configuration object.

    Parameters
    ----------
    base_url : str
        URL of the running AISecOps backend.
    api_key : str | None
        Bearer token sent as ``Authorization: Bearer <api_key>``.
    tenant_id : str
        Tenant identifier sent with every request.
    session_id : str
        Session identifier. Defaults to a random UUID per ``SDKConfig`` instance.
    timeout : float
        HTTP timeout (seconds) for synchronous requests.
    strict_mode : bool
        If *True*, suspicious prompts raise :class:`SuspiciousPromptError`
        instead of allowing through with restrictions.
    enable_telemetry : bool
        If *True*, the SDK reports threat detections to the backend analytics
        endpoint for dashboard visibility.
    log_level : str
        Logging verbosity (``DEBUG`` | ``INFO`` | ``WARNING`` | ``ERROR``).
    """

    base_url: str = field(
        default_factory=lambda: os.getenv("AISECOPS_BASE_URL", "http://localhost:8000")
    )
    api_key: str | None = field(
        default_factory=lambda: os.getenv("AISECOPS_API_KEY")
    )
    tenant_id: str = field(
        default_factory=lambda: os.getenv("AISECOPS_TENANT_ID", "default")
    )
    session_id: str = field(
        default_factory=lambda: os.getenv(
            "AISECOPS_SESSION_ID", f"sdk-{uuid.uuid4().hex[:8]}"
        )
    )
    timeout: float = field(
        default_factory=lambda: float(os.getenv("AISECOPS_TIMEOUT", "30"))
    )
    strict_mode: bool = field(
        default_factory=lambda: _env_bool("AISECOPS_STRICT_MODE", False)
    )
    enable_telemetry: bool = field(
        default_factory=lambda: _env_bool("AISECOPS_TELEMETRY", True)
    )
    log_level: str = field(
        default_factory=lambda: os.getenv("AISECOPS_LOG_LEVEL", "INFO").upper()
    )

    # ---- Threat level thresholds (mirror the backend defaults) ----
    malicious_threshold: float = 0.75
    suspicious_threshold: float = 0.40

    def headers(self) -> dict[str, str]:
        """Build HTTP headers for every request to the backend."""
        h: dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def is_malicious(self, fusion_score: float) -> bool:
        return fusion_score >= self.malicious_threshold

    def is_suspicious(self, fusion_score: float) -> bool:
        return self.suspicious_threshold <= fusion_score < self.malicious_threshold

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")
