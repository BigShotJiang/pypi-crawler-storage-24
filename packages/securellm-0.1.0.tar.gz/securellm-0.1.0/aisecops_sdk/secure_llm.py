"""
AISecOps SDK — SecureLLM Drop-In Wrapper
==========================================
Wraps *any* LLM provider behind the full AISecOps security pipeline.

Supported providers
--------------------
* ``"ollama"``      — local Ollama server (default)
* ``"openai"``      — OpenAI Chat Completions API
* ``"anthropic"``   — Anthropic Claude Messages API
* ``"local"``       — Custom local model callable
* ``"custom"``      — Arbitrary HTTP endpoint

Quick start::

    from aisecops_sdk import SecureLLM

    llm = SecureLLM(provider="openai", model="gpt-4o")
    response = llm.chat("Explain quantum computing")
    print(response)

Streaming::

    for chunk in llm.stream_chat("Summarise the news today"):
        print(chunk, end="", flush=True)
"""

from __future__ import annotations

import json
import os
import time
from typing import Any, Callable, Generator, Iterator

from .client import AISecOpsClient
from .config import SDKConfig
from .exceptions import (
    AISecOpsError,
    ConfigurationError,
    OutputSanitizationError,
    SuspiciousPromptError,
    ThreatBlockedError,
)
from .utils import build_threat_summary, get_logger, sanitize_prompt_for_log

_LOGGER = get_logger("aisecops_sdk.secure_llm")


# --------------------------------------------------------------------------- #
# Provider dispatch helpers                                                     #
# --------------------------------------------------------------------------- #


def _call_openai(prompt: str, model: str, **kwargs: Any) -> str:
    """
    Call OpenAI Chat Completions API.
    Requires ``openai`` package and ``OPENAI_API_KEY`` env var.
    """
    try:
        import openai  # type: ignore[import]
    except ImportError as exc:
        raise ConfigurationError(
            "openai package not installed. Run: pip install openai"
        ) from exc

    api_key = kwargs.pop("api_key", None) or os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ConfigurationError(
            "OpenAI API key not set. Use SecureLLM(api_key=...) or set OPENAI_API_KEY."
        )

    client = openai.OpenAI(api_key=api_key)
    system_prompt = kwargs.pop("system_prompt", None)
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    resp = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=kwargs.pop("temperature", 0.7),
        max_tokens=kwargs.pop("max_tokens", 2048),
        **kwargs,
    )
    return resp.choices[0].message.content or ""


def _call_openai_stream(prompt: str, model: str, **kwargs: Any) -> Generator[str, None, None]:
    """Streaming OpenAI call — yields token strings."""
    try:
        import openai  # type: ignore[import]
    except ImportError as exc:
        raise ConfigurationError(
            "openai package not installed. Run: pip install openai"
        ) from exc

    api_key = kwargs.pop("api_key", None) or os.getenv("OPENAI_API_KEY")
    client = openai.OpenAI(api_key=api_key)
    system_prompt = kwargs.pop("system_prompt", None)
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    with client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=kwargs.pop("temperature", 0.7),
        max_tokens=kwargs.pop("max_tokens", 2048),
        stream=True,
        **kwargs,
    ) as stream:
        for event in stream:
            delta = event.choices[0].delta.content
            if delta:
                yield delta


def _call_anthropic(prompt: str, model: str, **kwargs: Any) -> str:
    """
    Call Anthropic Claude Messages API.
    Requires ``anthropic`` package and ``ANTHROPIC_API_KEY`` env var.
    """
    try:
        import anthropic  # type: ignore[import]
    except ImportError as exc:
        raise ConfigurationError(
            "anthropic package not installed. Run: pip install anthropic"
        ) from exc

    api_key = kwargs.pop("api_key", None) or os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise ConfigurationError(
            "Anthropic API key not set. Use SecureLLM(api_key=...) or set ANTHROPIC_API_KEY."
        )

    client = anthropic.Anthropic(api_key=api_key)
    system_prompt = kwargs.pop("system_prompt", None)
    msg = client.messages.create(
        model=model,
        max_tokens=kwargs.pop("max_tokens", 2048),
        system=system_prompt or anthropic.NOT_GIVEN,
        messages=[{"role": "user", "content": prompt}],
        **kwargs,
    )
    return msg.content[0].text if msg.content else ""


def _call_anthropic_stream(prompt: str, model: str, **kwargs: Any) -> Generator[str, None, None]:
    """Streaming Anthropic call — yields text strings."""
    try:
        import anthropic  # type: ignore[import]
    except ImportError as exc:
        raise ConfigurationError(
            "anthropic package not installed. Run: pip install anthropic"
        ) from exc

    api_key = kwargs.pop("api_key", None) or os.getenv("ANTHROPIC_API_KEY")
    client = anthropic.Anthropic(api_key=api_key)
    system_prompt = kwargs.pop("system_prompt", None)

    with client.messages.stream(
        model=model,
        max_tokens=kwargs.pop("max_tokens", 2048),
        system=system_prompt or anthropic.NOT_GIVEN,
        messages=[{"role": "user", "content": prompt}],
        **kwargs,
    ) as stream:
        for text in stream.text_stream:
            yield text


def _call_ollama(
    prompt: str,
    model: str,
    *,
    base_url: str = "http://localhost:11434",
    **kwargs: Any,
) -> str:
    """Call a locally running Ollama model."""
    import requests  # type: ignore[import]

    system_prompt = kwargs.pop("system_prompt", None)
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    resp = requests.post(
        f"{base_url.rstrip('/')}/api/chat",
        json={
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": kwargs.pop("temperature", 0.7),
                "num_predict": kwargs.pop("max_tokens", 2048),
            },
        },
        timeout=kwargs.pop("timeout", 60),
    )
    resp.raise_for_status()
    data = resp.json()
    return data.get("message", {}).get("content", "")


def _call_ollama_stream(
    prompt: str,
    model: str,
    *,
    base_url: str = "http://localhost:11434",
    **kwargs: Any,
) -> Generator[str, None, None]:
    """Streaming Ollama call — yields token strings."""
    import requests  # type: ignore[import]

    system_prompt = kwargs.pop("system_prompt", None)
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    with requests.post(
        f"{base_url.rstrip('/')}/api/chat",
        json={
            "model": model,
            "messages": messages,
            "stream": True,
            "options": {
                "temperature": kwargs.pop("temperature", 0.7),
                "num_predict": kwargs.pop("max_tokens", 2048),
            },
        },
        stream=True,
        timeout=kwargs.pop("timeout", 60),
    ) as resp:
        resp.raise_for_status()
        for raw_line in resp.iter_lines():
            if not raw_line:
                continue
            chunk = json.loads(raw_line)
            token = chunk.get("message", {}).get("content", "")
            if token:
                yield token


def _call_custom(
    prompt: str,
    model: str,
    *,
    endpoint: str,
    headers: dict[str, str] | None = None,
    **kwargs: Any,
) -> str:
    """POST prompt to a custom HTTP endpoint, return response text."""
    import requests  # type: ignore[import]

    body = {"prompt": prompt, "model": model, **kwargs}
    resp = requests.post(
        endpoint,
        json=body,
        headers=headers or {},
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    # Try common response fields
    for field in ("response", "text", "content", "output", "generated_text"):
        if field in data:
            return str(data[field])
    return str(data)


# --------------------------------------------------------------------------- #
# SecureLLM                                                                     #
# --------------------------------------------------------------------------- #


class SecureLLM:
    """
    Drop-in secure LLM wrapper with full AISecOps pipeline integration.

    The security pipeline applied on every call:

    1. **Threat detection** — prompt sent to ``/analyze``
    2. **Policy decision** — malicious → block, suspicious → restrict/warn
    3. **LLM call** — only if approved
    4. **Output sanitization** — response sent through ``/output-security``
    5. **Telemetry** — optional event report to analytics

    Parameters
    ----------
    model : str
        LLM model identifier (e.g. ``"gpt-4o"``, ``"claude-3-opus-20240229"``,
        ``"llama3:8b"``).
    provider : str
        One of ``"openai"``, ``"anthropic"``, ``"ollama"``, ``"local"``,
        ``"custom"``.
    config : SDKConfig | None
        SDK config. Falls back to env-variable defaults.
    api_key : str | None
        Provider API key (also readable from env vars).
    ollama_base_url : str
        Base URL for local Ollama server.
    custom_endpoint : str | None
        URL for ``provider="custom"`` calls.
    custom_fn : Callable | None
        Callable for ``provider="local"`` — signature ``fn(prompt, model) -> str``.
    system_prompt : str | None
        Default system prompt prepended to every LLM call.
    temperature : float
        Sampling temperature (0.0 – 2.0).
    max_tokens : int
        Maximum tokens in the LLM response.

    Examples
    --------
    OpenAI (requires ``pip install openai``)::

        from aisecops_sdk import SecureLLM
        llm = SecureLLM(provider="openai", model="gpt-4o")
        print(llm.chat("Summarise AI safety"))

    Anthropic (requires ``pip install anthropic``)::

        llm = SecureLLM(provider="anthropic", model="claude-3-opus-20240229")
        print(llm.chat("Explain transformers"))

    Local Ollama::

        llm = SecureLLM(provider="ollama", model="llama3:8b")
        print(llm.chat("Hello!"))

    Streaming::

        for token in llm.stream_chat("List 5 planets"):
            print(token, end="", flush=True)
    """

    def __init__(
        self,
        model: str = "llama3:8b",
        provider: str = "ollama",
        *,
        config: SDKConfig | None = None,
        api_key: str | None = None,
        ollama_base_url: str = "http://localhost:11434",
        custom_endpoint: str | None = None,
        custom_fn: Callable[[str, str], str] | None = None,
        system_prompt: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> None:
        self.model = model
        self.provider = provider.lower()
        self.config = config or SDKConfig()
        self._api_key = api_key
        self._ollama_base_url = ollama_base_url
        self._custom_endpoint = custom_endpoint
        self._custom_fn = custom_fn
        self.system_prompt = system_prompt
        self.temperature = temperature
        self.max_tokens = max_tokens

        # Validate provider
        _VALID_PROVIDERS = {"openai", "anthropic", "ollama", "local", "custom"}
        if self.provider not in _VALID_PROVIDERS:
            raise ConfigurationError(
                f"Unknown provider {self.provider!r}. Choose from {_VALID_PROVIDERS}."
            )

        # Backend security client
        self._client = AISecOpsClient(config=self.config)

        _LOGGER.info(
            "SecureLLM initialised — provider=%s model=%s backend=%s",
            self.provider,
            self.model,
            self.config.base_url,
        )

    # ------------------------------------------------------------------ #
    # Internal — LLM dispatch                                             #
    # ------------------------------------------------------------------ #

    def _call_llm(self, prompt: str, **overrides: Any) -> str:
        """Route the prompt to the configured LLM provider and return raw text."""
        kwargs = {
            "system_prompt": self.system_prompt,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "api_key": self._api_key,
            **overrides,
        }

        if self.provider == "openai":
            return _call_openai(prompt, self.model, **kwargs)

        elif self.provider == "anthropic":
            return _call_anthropic(prompt, self.model, **kwargs)

        elif self.provider == "ollama":
            kwargs["base_url"] = self._ollama_base_url
            return _call_ollama(prompt, self.model, **kwargs)

        elif self.provider == "local":
            if not self._custom_fn:
                raise ConfigurationError(
                    "provider='local' requires passing custom_fn= to SecureLLM()"
                )
            return self._custom_fn(prompt, self.model)

        elif self.provider == "custom":
            if not self._custom_endpoint:
                raise ConfigurationError(
                    "provider='custom' requires passing custom_endpoint= to SecureLLM()"
                )
            return _call_custom(prompt, self.model, endpoint=self._custom_endpoint, **kwargs)

        raise ConfigurationError(f"Unhandled provider: {self.provider!r}")

    def _call_llm_stream(self, prompt: str, **overrides: Any) -> Iterator[str]:
        """Route the prompt to the LLM provider and return a token stream."""
        kwargs = {
            "system_prompt": self.system_prompt,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "api_key": self._api_key,
            **overrides,
        }

        if self.provider == "openai":
            yield from _call_openai_stream(prompt, self.model, **kwargs)

        elif self.provider == "anthropic":
            yield from _call_anthropic_stream(prompt, self.model, **kwargs)

        elif self.provider == "ollama":
            kwargs["base_url"] = self._ollama_base_url
            yield from _call_ollama_stream(prompt, self.model, **kwargs)

        else:
            # Fallback: non-streaming call yielded as one chunk
            yield self._call_llm(prompt, **overrides)

    def _check_threat(self, prompt: str, analysis: dict[str, Any]) -> None:
        """
        Apply the security policy decision based on *analysis*.

        Raises
        ------
        ThreatBlockedError
            Prompt is malicious.
        SuspiciousPromptError
            Prompt is suspicious **and** ``strict_mode`` is enabled.
        """
        fusion_score: float = analysis.get("fusion_score", 0.0)
        threat_level: str = analysis.get("threat_level", "benign")
        tier: str = analysis.get("tier", "")

        _LOGGER.debug(
            "Threat check: %s | %s",
            sanitize_prompt_for_log(prompt),
            build_threat_summary(analysis),
        )

        if threat_level == "malicious" or self.config.is_malicious(fusion_score):
            # Report telemetry before raising
            self._client.report_telemetry(
                "threat_blocked",
                {
                    "fusion_score": fusion_score,
                    "tier": tier,
                    "provider": self.provider,
                    "model": self.model,
                },
            )
            raise ThreatBlockedError(
                prompt=prompt,
                fusion_score=fusion_score,
                reason=analysis.get("recommended_action", "Malicious content detected"),
            )

        if self.config.is_suspicious(fusion_score):
            self._client.report_telemetry(
                "suspicious_prompt",
                {"fusion_score": fusion_score, "tier": tier},
            )
            if self.config.strict_mode:
                raise SuspiciousPromptError(prompt=prompt, fusion_score=fusion_score, tier=tier)
            _LOGGER.warning(
                "⚠ Suspicious prompt (score=%.3f tier=%s) — allowed in non-strict mode",
                fusion_score,
                tier,
            )

    def _sanitize_output(self, raw_output: str, prompt: str) -> str:
        """
        Send *raw_output* through backend output-security and return safe text.

        If the backend is unavailable (e.g. during local testing without
        the backend running), the raw output is returned with a warning so
        SDK users can still evaluate without a live backend.
        """
        try:
            result = self._client.secure_output(raw_output)
        except Exception as exc:
            _LOGGER.warning("Output-security unreachable (%s). Returning raw LLM output.", exc)
            return raw_output

        if not result.get("safe_to_show", True):
            reason = result.get("reason", "Output failed security checks")
            raise OutputSanitizationError(reason)

        return result.get("sanitised_content", raw_output) or raw_output

    # ------------------------------------------------------------------ #
    # Public — chat                                                        #
    # ------------------------------------------------------------------ #

    def chat(
        self,
        prompt: str,
        *,
        skip_output_security: bool = False,
        **llm_overrides: Any,
    ) -> str:
        """
        Secure chat — runs the full security pipeline.

        Parameters
        ----------
        prompt : str
            User message.
        skip_output_security : bool
            Skip output sanitization (useful for batch scoring / testing).
        **llm_overrides
            Extra keyword arguments forwarded to the underlying LLM call.

        Returns
        -------
        str
            Sanitized LLM response.

        Raises
        ------
        ThreatBlockedError
            Prompt was classified as malicious.
        SuspiciousPromptError
            Prompt is suspicious and ``strict_mode=True``.
        OutputSanitizationError
            LLM response failed output security check.
        AISecOpsConnectionError
            Backend not reachable.
        """
        t_start = time.perf_counter()

        # ① Threat detection
        try:
            analysis = self._client.analyze(prompt)
        except Exception as exc:
            _LOGGER.warning(
                "Backend unreachable (%s). Skipping security check — proceeding with caution.",
                exc,
            )
            analysis = {"threat_level": "benign", "fusion_score": 0.0}

        # ② Policy decision
        self._check_threat(prompt, analysis)

        # ③ LLM call
        raw_response = self._call_llm(prompt, **llm_overrides)

        # ④ Output sanitization
        final = (
            self._sanitize_output(raw_response, prompt)
            if not skip_output_security
            else raw_response
        )

        # ⑤ Telemetry
        self._client.report_telemetry(
            "successful_chat",
            {
                "provider": self.provider,
                "model": self.model,
                "fusion_score": analysis.get("fusion_score", 0.0),
                "latency_ms": round((time.perf_counter() - t_start) * 1000, 1),
            },
        )

        return final

    def stream_chat(
        self,
        prompt: str,
        *,
        skip_output_security: bool = False,
        **llm_overrides: Any,
    ) -> Iterator[str]:
        """
        Streaming secure chat.

        Security checks run *before* streaming begins.  Each yielded value is
        a token string from the underlying LLM.  Output security is applied on
        the fully accumulated response after streaming finishes — an additional
        ``{"type": "security_result", ...}`` sentinel is **not** yielded (the
        stream simply raises on violation).

        Yields
        ------
        str
            Raw LLM token.

        Raises
        ------
        ThreatBlockedError
            Prompt was classified as malicious.
        OutputSanitizationError
            Accumulated output failed output security.
        """
        # ① Threat detection (blocking — must complete before yielding tokens)
        try:
            analysis = self._client.analyze(prompt)
        except Exception as exc:
            _LOGGER.warning("Backend unreachable (%s). Proceeding without security check.", exc)
            analysis = {"threat_level": "benign", "fusion_score": 0.0}

        # ② Policy decision
        self._check_threat(prompt, analysis)

        # ③ Stream tokens while accumulating
        accumulated: list[str] = []
        for token in self._call_llm_stream(prompt, **llm_overrides):
            accumulated.append(token)
            yield token

        # ④ Output sanitization on full response
        if not skip_output_security:
            full_response = "".join(accumulated)
            self._sanitize_output(full_response, prompt)  # raises if unsafe

    # ------------------------------------------------------------------ #
    # Async variants                                                       #
    # ------------------------------------------------------------------ #

    async def async_chat(
        self,
        prompt: str,
        *,
        skip_output_security: bool = False,
        **llm_overrides: Any,
    ) -> str:
        """Async wrapper around :meth:`chat` — runs in a thread-pool executor."""
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.chat(prompt, skip_output_security=skip_output_security, **llm_overrides),
        )

    # ------------------------------------------------------------------ #
    # LangChain compatibility                                              #
    # ------------------------------------------------------------------ #

    def _generate(self, prompts: list[str], **kwargs: Any) -> Any:  # noqa: ANN001
        """
        LangChain ``BaseLLM._generate`` compatibility shim.

        Install LangChain separately; the SDK does NOT depend on it::

            pip install langchain

        Example::

            from langchain.chains import LLMChain
            from langchain.prompts import PromptTemplate
            from aisecops_sdk import SecureLLM

            llm = SecureLLM(provider="openai", model="gpt-4o")
            chain = LLMChain(llm=llm, prompt=PromptTemplate.from_template("{query}"))
            chain.run(query="What is AI safety?")
        """
        try:
            from langchain.schema import LLMResult, Generation  # type: ignore[import]
        except ImportError as exc:
            raise ConfigurationError(
                "langchain not installed. Run: pip install langchain"
            ) from exc

        generations = [[Generation(text=self.chat(p, **kwargs))] for p in prompts]
        return LLMResult(generations=generations)

    @property
    def _llm_type(self) -> str:  # LangChain protocol
        return f"aisecops-{self.provider}"

    def __repr__(self) -> str:
        return (
            f"SecureLLM(provider={self.provider!r}, model={self.model!r}, "
            f"backend={self.config.base_url!r})"
        )
