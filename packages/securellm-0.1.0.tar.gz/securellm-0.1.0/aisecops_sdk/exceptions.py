"""
AISecOps SDK — Exception Hierarchy
===================================
All SDK exceptions inherit from ``AISecOpsError`` so callers can catch
the base class or narrow handling to a specific sub-type.
"""

from __future__ import annotations


class AISecOpsError(Exception):
    """Base class for all AISecOps SDK exceptions."""

    def __init__(self, message: str, details: dict | None = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def __repr__(self) -> str:  # noqa: D105
        return f"{type(self).__name__}(message={self.message!r}, details={self.details})"


class ThreatBlockedError(AISecOpsError):
    """
    Raised when the AISecOps backend classifies a prompt as **malicious**.

    Attributes
    ----------
    prompt : str
        The offensive prompt (may be truncated).
    fusion_score : float
        Risk score (0–1) that triggered the block.
    reason : str
        Human-readable reason for the block.
    """

    def __init__(
        self,
        prompt: str,
        fusion_score: float = 0.0,
        reason: str = "Prompt blocked by AISecOps threat detection",
        details: dict | None = None,
    ):
        self.prompt = prompt[:200]  # never log full prompt in exception
        self.fusion_score = fusion_score
        self.reason = reason
        super().__init__(
            f"BLOCKED — {reason} (score={fusion_score:.3f})",
            details={
                "prompt_preview": self.prompt,
                "fusion_score": fusion_score,
                "reason": reason,
                **(details or {}),
            },
        )


class SuspiciousPromptError(AISecOpsError):
    """
    Raised in strict mode when the prompt is **suspicious** (medium risk).

    In default mode suspicious prompts are allowed through with restrictions;
    enable strict mode via :class:`SDKConfig` to raise this instead.
    """

    def __init__(
        self,
        prompt: str,
        fusion_score: float = 0.0,
        tier: str = "suspicious",
        details: dict | None = None,
    ):
        self.prompt = prompt[:200]
        self.fusion_score = fusion_score
        self.tier = tier
        super().__init__(
            f"SUSPICIOUS prompt detected (score={fusion_score:.3f}, tier={tier})",
            details={
                "prompt_preview": self.prompt,
                "fusion_score": fusion_score,
                "tier": tier,
                **(details or {}),
            },
        )


class OutputSanitizationError(AISecOpsError):
    """Raised when the LLM response fails output security checks."""

    def __init__(self, reason: str = "Output failed security sanitization"):
        super().__init__(reason)


class ConnectionError(AISecOpsError):  # noqa: A001
    """Raised when the SDK cannot reach the AISecOps backend."""

    def __init__(self, base_url: str, cause: Exception | None = None):
        self.base_url = base_url
        self.cause = cause
        super().__init__(
            f"Cannot connect to AISecOps backend at {base_url!r}: {cause}",
            details={"base_url": base_url, "cause": str(cause)},
        )


class ConfigurationError(AISecOpsError):
    """Raised when SDK configuration is invalid or incomplete."""
