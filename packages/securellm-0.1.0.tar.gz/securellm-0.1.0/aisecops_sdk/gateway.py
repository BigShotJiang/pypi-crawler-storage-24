"""
AISecOps SDK — Universal Security Gateway
==========================================
``SecureGateway`` is a provider-agnostic AI security proxy.

Unlike :class:`SecureLLM` (which manages LLM calls client-side), the gateway
delegates **both** LLM invocation *and* security checks to the AISecOps
backend in a single HTTP call, making it ideal for server-side or edge
deployments where the calling process should not hold provider credentials.

Usage::

    from aisecops_sdk import SecureGateway

    gw = SecureGateway()
    result = gw.call(
        prompt="Explain transformers",
        provider="openai",
        model="gpt-4o",
    )
    print(result.response)
    print(result.allowed)

The backend endpoint: ``POST /secure-gateway``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .client import AISecOpsClient
from .config import SDKConfig
from .exceptions import ThreatBlockedError
from .utils import get_logger

_LOGGER = get_logger("aisecops_sdk.gateway")


@dataclass
class GatewayResult:
    """
    Structured result from a :class:`SecureGateway` call.

    Attributes
    ----------
    prompt : str
        Original user prompt.
    allowed : bool
        ``True`` if the request passed the security policy.
    response : str
        Sanitized LLM response (empty string if blocked).
    tier : str
        Threat tier assigned by the fusion engine.
    fusion_score : float
        Numeric risk score (0–1).
    recommended_action : str
        Backend's recommended action string.
    prefilter_triggered : bool
        Whether the pre-filter (keyword / regex) was tripped.
    prefilter_reason : str | None
        Reason for pre-filter trigger, if any.
    blocking_reason : str | None
        Human-readable reason for block, if blocked.
    output_security : dict
        Raw output-security metadata from the backend.
    upstream_response : dict | None
        Raw upstream provider response (may be None if blocked).
    latency_ms : float
        End-to-end backend latency in milliseconds.
    """

    prompt: str
    allowed: bool
    response: str
    tier: str = ""
    fusion_score: float = 0.0
    recommended_action: str = ""
    prefilter_triggered: bool = False
    prefilter_reason: str | None = None
    blocking_reason: str | None = None
    output_security: dict = field(default_factory=dict)
    upstream_response: dict | None = None
    latency_ms: float = 0.0

    def __str__(self) -> str:  # noqa: D105
        status = "✅ ALLOWED" if self.allowed else "🚫 BLOCKED"
        return (
            f"{status} | tier={self.tier} score={self.fusion_score:.3f} | "
            f"latency={self.latency_ms:.1f}ms"
        )


class SecureGateway:
    """
    Universal AI security gateway — delegates everything to the AISecOps backend.

    Parameters
    ----------
    config : SDKConfig | None
        SDK config. Falls back to environment variables.
    raise_on_block : bool
        If *True*, raise :class:`ThreatBlockedError` on blocked requests
        instead of returning an :attr:`GatewayResult.allowed` == ``False`` result.

    Examples
    --------
    Basic usage::

        gw = SecureGateway(raise_on_block=True)
        result = gw.call("Tell me about neural networks", provider="ollama", model="llama3:8b")
        print(result.response)

    Async usage::

        async with SecureGateway() as gw:
            result = await gw.async_call("Hello", provider="openai", model="gpt-4o")
    """

    def __init__(
        self,
        config: SDKConfig | None = None,
        *,
        raise_on_block: bool = False,
    ) -> None:
        self.config = config or SDKConfig()
        self.raise_on_block = raise_on_block
        self._client = AISecOpsClient(config=self.config)

    # ------------------------------------------------------------------ #
    # Context manager (async)                                              #
    # ------------------------------------------------------------------ #

    async def __aenter__(self) -> "SecureGateway":
        await self._client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self._client.__aexit__(*args)

    # ------------------------------------------------------------------ #
    # Core gateway call                                                    #
    # ------------------------------------------------------------------ #

    def call(
        self,
        prompt: str,
        *,
        provider: str = "ollama",
        model: str | None = None,
        session_id: str | None = None,
        tenant_id: str | None = None,
        extra_headers: dict[str, str] | None = None,
        body_extra: dict[str, Any] | None = None,
    ) -> GatewayResult:
        """
        Send a prompt through the universal security gateway.

        Parameters
        ----------
        prompt : str
            User input to analyze and route.
        provider : str
            LLM provider the backend should route to.
        model : str | None
            Model override. Uses the backend default if not set.
        session_id : str | None
            Optional session override.
        tenant_id : str | None
            Optional tenant override.
        extra_headers : dict | None
            Additional headers forwarded to the upstream provider by the backend.
        body_extra : dict | None
            Additional JSON fields merged into the upstream request body.

        Returns
        -------
        GatewayResult
            Structured security + LLM result.

        Raises
        ------
        ThreatBlockedError
            If ``raise_on_block=True`` and the prompt is malicious.
        AISecOpsConnectionError
            Backend not reachable.
        """
        raw = self._client.secure_gateway(
            prompt,
            provider=provider,
            model=model,
            session_id=session_id,
            tenant_id=tenant_id,
            extra_headers=extra_headers,
            body_extra=body_extra,
        )
        return self._build_result(prompt, raw)

    async def async_call(
        self,
        prompt: str,
        *,
        provider: str = "ollama",
        model: str | None = None,
        session_id: str | None = None,
        tenant_id: str | None = None,
        extra_headers: dict[str, str] | None = None,
        body_extra: dict[str, Any] | None = None,
    ) -> GatewayResult:
        """Async version of :meth:`call`."""
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.call(
                prompt,
                provider=provider,
                model=model,
                session_id=session_id,
                tenant_id=tenant_id,
                extra_headers=extra_headers,
                body_extra=body_extra,
            ),
        )

    # ------------------------------------------------------------------ #
    # Batch processing                                                      #
    # ------------------------------------------------------------------ #

    def batch_call(
        self,
        prompts: list[str],
        *,
        provider: str = "ollama",
        model: str | None = None,
    ) -> list[GatewayResult]:
        """
        Process multiple prompts through the gateway in sequence.

        Blocked prompts do **not** raise by default; they appear in the results
        list with ``allowed=False``.  Set ``raise_on_block=True`` to abort on
        the first block.
        """
        results: list[GatewayResult] = []
        for i, prompt in enumerate(prompts):
            _LOGGER.info("Batch gateway: %d/%d", i + 1, len(prompts))
            result = self.call(prompt, provider=provider, model=model)
            results.append(result)
        return results

    # ------------------------------------------------------------------ #
    # Internal                                                              #
    # ------------------------------------------------------------------ #

    def _build_result(self, prompt: str, raw: dict[str, Any]) -> GatewayResult:
        """Convert raw backend JSON into a :class:`GatewayResult`."""
        allowed: bool = raw.get("allowed", True)
        sanitised: str = raw.get("sanitised_content", "") or ""

        result = GatewayResult(
            prompt=prompt,
            allowed=allowed,
            response=sanitised,
            tier=raw.get("tier", ""),
            fusion_score=raw.get("fusion_score", 0.0),
            recommended_action=raw.get("recommended_action", ""),
            prefilter_triggered=raw.get("prefilter_triggered", False),
            prefilter_reason=raw.get("prefilter_reason"),
            blocking_reason=raw.get("blocking_reason"),
            output_security=raw.get("output_security") or {},
            upstream_response=raw.get("upstream_response"),
            latency_ms=raw.get("latency_ms", 0.0),
        )

        if not allowed and self.raise_on_block:
            raise ThreatBlockedError(
                prompt=prompt,
                fusion_score=result.fusion_score,
                reason=result.blocking_reason or "Blocked by security policy",
            )

        _LOGGER.info("%s", result)
        return result

    def __repr__(self) -> str:
        return f"SecureGateway(backend={self.config.base_url!r})"
