"""
AISecOps SDK
============
Developer-installable Python SDK for the AISecOps Security Gateway.

Quick start::

    from aisecops_sdk import SecureLLM

    llm = SecureLLM(provider="openai", model="gpt-4o")
    response = llm.chat("Explain quantum computing")
    print(response)
"""

from .client import AISecOpsClient
from .secure_llm import SecureLLM
from .gateway import SecureGateway
from .config import SDKConfig
from .exceptions import (
    AISecOpsError,
    ThreatBlockedError,
    SuspiciousPromptError,
    OutputSanitizationError,
    ConnectionError as AISecOpsConnectionError,
    ConfigurationError,
)

__version__ = "0.1.0"
__author__ = "AISecOps Team"
__all__ = [
    # Core
    "SecureLLM",
    "AISecOpsClient",
    "SecureGateway",
    "SDKConfig",
    # Exceptions
    "AISecOpsError",
    "ThreatBlockedError",
    "SuspiciousPromptError",
    "OutputSanitizationError",
    "AISecOpsConnectionError",
    "ConfigurationError",
    # Meta
    "__version__",
]
