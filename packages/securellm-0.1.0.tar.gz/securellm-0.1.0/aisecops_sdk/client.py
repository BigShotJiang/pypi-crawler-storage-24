"""
AISecOps SDK — Backend Client
===============================
``AISecOpsClient`` handles all HTTP communication with the AISecOps backend.
It supports both synchronous (``requests``) and asynchronous (``httpx``) calls
so the SDK works equally well in sync scripts and async frameworks.

Usage (sync)::

    from aisecops_sdk.client import AISecOpsClient
    client = AISecOpsClient()
    result = client.analyze("Tell me how to hack a system")
    print(result)

Usage (async)::

    from aisecops_sdk.client import AISecOpsClient
    async with AISecOpsClient() as client:
        result = await client.async_analyze("Hello world")
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any, AsyncIterator, Iterator

import httpx
import requests

from .config import SDKConfig
from .exceptions import (
    AISecOpsError,
    ConnectionError as AISecOpsConnectionError,
    OutputSanitizationError,
)
from .utils import elapsed_ms, get_logger

_LOGGER = get_logger("aisecops_sdk.client")


class AISecOpsClient:
    """
    HTTP client for the AISecOps backend REST API.

    Parameters
    ----------
    base_url : str | None
        Backend URL. Falls back to ``SDKConfig.base_url``.
    config : SDKConfig | None
        Full config object. If *None* an instance with env-variable defaults
        is created automatically.

    Examples
    --------
    >>> client = AISecOpsClient()
    >>> result = client.analyze("Hello world")
    >>> print(result["threat_level"])
    """

    def __init__(
        self,
        base_url: str | None = None,
        *,
        config: SDKConfig | None = None,
    ) -> None:
        self.config = config or SDKConfig()
        if base_url:
            self.config.base_url = base_url.rstrip("/")
        _LOGGER.setLevel(self.config.log_level)
        self._async_client: httpx.AsyncClient | None = None

    # ------------------------------------------------------------------ #
    # Context manager helpers (async)                                     #
    # ------------------------------------------------------------------ #

    async def __aenter__(self) -> "AISecOpsClient":
        self._async_client = httpx.AsyncClient(
            base_url=self.config.base_url,
            headers=self.config.headers(),
            timeout=self.config.timeout,
        )
        return self

    async def __aexit__(self, *_: Any) -> None:
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None

    # ------------------------------------------------------------------ #
    # Internal helpers                                                     #
    # ------------------------------------------------------------------ #

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Synchronous POST to ``{base_url}/{path}``."""
        url = f"{self.config.base_url}{path}"
        try:
            resp = requests.post(
                url,
                json=payload,
                headers=self.config.headers(),
                timeout=self.config.timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except requests.ConnectionError as exc:
            raise AISecOpsConnectionError(self.config.base_url, exc) from exc
        except requests.HTTPError as exc:
            raise AISecOpsError(f"Backend HTTP error: {exc}", details={"url": url}) from exc
        except Exception as exc:  # pragma: no cover
            raise AISecOpsError(f"Unexpected error calling {url}: {exc}") from exc

    async def _async_post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Asynchronous POST to ``{base_url}/{path}``."""
        client = self._async_client or httpx.AsyncClient(
            base_url=self.config.base_url,
            headers=self.config.headers(),
            timeout=self.config.timeout,
        )
        try:
            resp = await client.post(path, json=payload)
            resp.raise_for_status()
            return resp.json()
        except httpx.ConnectError as exc:
            raise AISecOpsConnectionError(self.config.base_url, exc) from exc
        except httpx.HTTPStatusError as exc:
            raise AISecOpsError(f"Backend HTTP error: {exc}", details={"url": str(exc.request.url)}) from exc
        finally:
            if not self._async_client:
                await client.aclose()

    # ------------------------------------------------------------------ #
    # Public — Prompt Analysis                                             #
    # ------------------------------------------------------------------ #

    def analyze(
        self,
        prompt: str,
        *,
        session_id: str | None = None,
        tenant_id: str | None = None,
        context: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Synchronously analyze a prompt for threats.

        Returns
        -------
        dict
            Backend response with keys: ``threat_level``, ``fusion_score``,
            ``tier``, ``recommended_action``, ``features``, …
        """
        t0 = time.perf_counter()
        payload = {
            "prompt": prompt,
            "session_id": session_id or self.config.session_id,
            "tenant_id": tenant_id or self.config.tenant_id,
            "context": context or [],
        }
        result = self._post("/analyze", payload)
        _LOGGER.debug(
            "analyze() completed in %.1f ms | threat=%s score=%.3f",
            elapsed_ms(t0),
            result.get("threat_level"),
            result.get("fusion_score", 0.0),
        )
        return result

    async def async_analyze(
        self,
        prompt: str,
        *,
        session_id: str | None = None,
        tenant_id: str | None = None,
        context: list[str] | None = None,
    ) -> dict[str, Any]:
        """Async version of :meth:`analyze`."""
        payload = {
            "prompt": prompt,
            "session_id": session_id or self.config.session_id,
            "tenant_id": tenant_id or self.config.tenant_id,
            "context": context or [],
        }
        return await self._async_post("/analyze", payload)

    # ------------------------------------------------------------------ #
    # Public — Secure Chat (full pipeline)                                 #
    # ------------------------------------------------------------------ #

    def secure_chat(
        self,
        prompt: str,
        *,
        session_id: str | None = None,
        tenant_id: str | None = None,
        model: str | None = None,
        system_prompt: str | None = None,
        context: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Run the full AISecOps secure pipeline (analysis + Ollama LLM + output
        sanitization) in one call.
        """
        payload = {
            "prompt": prompt,
            "session_id": session_id or self.config.session_id,
            "tenant_id": tenant_id or self.config.tenant_id,
            "context": context or [],
            "model": model,
            "system_prompt": system_prompt,
        }
        # strip Nones so the backend uses its defaults
        payload = {k: v for k, v in payload.items() if v is not None}
        return self._post("/secure-chat", payload)

    async def async_secure_chat(
        self,
        prompt: str,
        *,
        session_id: str | None = None,
        tenant_id: str | None = None,
        model: str | None = None,
        system_prompt: str | None = None,
        context: list[str] | None = None,
    ) -> dict[str, Any]:
        """Async version of :meth:`secure_chat`."""
        payload = {
            "prompt": prompt,
            "session_id": session_id or self.config.session_id,
            "tenant_id": tenant_id or self.config.tenant_id,
            "context": context or [],
            "model": model,
            "system_prompt": system_prompt,
        }
        payload = {k: v for k, v in payload.items() if v is not None}
        return await self._async_post("/secure-chat", payload)

    # ------------------------------------------------------------------ #
    # Public — Output Security                                             #
    # ------------------------------------------------------------------ #

    def secure_output(
        self,
        response_text: str,
        *,
        session_id: str | None = None,
        tenant_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Send *response_text* through the backend output-sanitization pipeline.

        Returns a dict with ``safe_to_show`` (bool) and ``sanitised_content``.
        """
        payload = {
            "response": response_text,
            "session_id": session_id or self.config.session_id,
            "tenant_id": tenant_id or self.config.tenant_id,
        }
        return self._post("/output-security", payload)

    async def async_secure_output(
        self,
        response_text: str,
        *,
        session_id: str | None = None,
        tenant_id: str | None = None,
    ) -> dict[str, Any]:
        """Async version of :meth:`secure_output`."""
        payload = {
            "response": response_text,
            "session_id": session_id or self.config.session_id,
            "tenant_id": tenant_id or self.config.tenant_id,
        }
        return await self._async_post("/output-security", payload)

    # ------------------------------------------------------------------ #
    # Public — Universal Secure Gateway                                    #
    # ------------------------------------------------------------------ #

    def secure_gateway(
        self,
        prompt: str,
        *,
        provider: str = "ollama",
        model: str | None = None,
        session_id: str | None = None,
        tenant_id: str | None = None,
        extra_headers: dict[str, str] | None = None,
        body_extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Universal AI security gateway endpoint.

        The backend runs threat detection → policy decision → LLM call →
        output sanitization, all in a single round-trip.
        """
        payload = {
            "prompt": prompt,
            "provider": provider,
            "model": model,
            "session_id": session_id or self.config.session_id,
            "tenant_id": tenant_id or self.config.tenant_id,
            "headers": extra_headers or {},
            "body_extra": body_extra or {},
        }
        payload = {k: v for k, v in payload.items() if v is not None}
        return self._post("/secure-gateway", payload)

    # ------------------------------------------------------------------ #
    # Public — Telemetry                                                   #
    # ------------------------------------------------------------------ #

    def report_telemetry(
        self,
        event_type: str,
        data: dict[str, Any],
    ) -> None:
        """
        Optionally send telemetry data to the backend analytics endpoint.

        Silently swallowed if ``config.enable_telemetry`` is *False* or if
        the backend is unreachable — telemetry must never break the caller.
        """
        if not self.config.enable_telemetry:
            return
        try:
            self._post(
                "/sdk/telemetry",
                {"event_type": event_type, "data": data},
            )
        except Exception:  # pragma: no cover
            _LOGGER.debug("Telemetry send skipped (backend unavailable)")

    # ------------------------------------------------------------------ #
    # Public — Health                                                      #
    # ------------------------------------------------------------------ #

    def health(self) -> dict[str, Any]:
        """Ping the backend health endpoint."""
        try:
            resp = requests.get(
                f"{self.config.base_url}/health",
                headers=self.config.headers(),
                timeout=self.config.timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except requests.ConnectionError as exc:
            raise AISecOpsConnectionError(self.config.base_url, exc) from exc

    # ------------------------------------------------------------------ #
    # Streaming                                                            #
    # ------------------------------------------------------------------ #

    def stream_secure_chat(
        self,
        prompt: str,
        *,
        session_id: str | None = None,
        tenant_id: str | None = None,
        model: str | None = None,
        system_prompt: str | None = None,
    ) -> Iterator[dict[str, Any]]:
        """
        Stream the secure-chat response as newline-delimited JSON chunks.

        The *first* chunk always contains the threat analysis result so callers
        can react before the full response arrives.

        Yields
        ------
        dict
            Parsed JSON chunk from the backend.

        Raises
        ------
        ThreatBlockedError
            If the first chunk indicates the prompt is malicious.
        """
        from .exceptions import ThreatBlockedError

        payload = {
            "prompt": prompt,
            "session_id": session_id or self.config.session_id,
            "tenant_id": tenant_id or self.config.tenant_id,
            "model": model,
            "system_prompt": system_prompt,
        }
        payload = {k: v for k, v in payload.items() if v is not None}

        url = f"{self.config.base_url}/secure-chat/stream"
        try:
            with requests.post(
                url,
                json=payload,
                headers=self.config.headers(),
                timeout=self.config.timeout,
                stream=True,
            ) as resp:
                resp.raise_for_status()
                for raw_line in resp.iter_lines():
                    if not raw_line:
                        continue
                    chunk = json.loads(raw_line)
                    if chunk.get("type") == "security_block":
                        raise ThreatBlockedError(
                            prompt=prompt,
                            fusion_score=chunk.get("fusion_score", 1.0),
                            reason=chunk.get("reason", "Blocked by security policy"),
                        )
                    yield chunk
        except requests.ConnectionError as exc:
            raise AISecOpsConnectionError(self.config.base_url, exc) from exc

    async def async_stream_secure_chat(
        self,
        prompt: str,
        *,
        session_id: str | None = None,
        tenant_id: str | None = None,
        model: str | None = None,
        system_prompt: str | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Async streaming variant — yields parsed JSON chunks.
        """
        from .exceptions import ThreatBlockedError

        payload = {
            "prompt": prompt,
            "session_id": session_id or self.config.session_id,
            "tenant_id": tenant_id or self.config.tenant_id,
            "model": model,
            "system_prompt": system_prompt,
        }
        payload = {k: v for k, v in payload.items() if v is not None}

        client = self._async_client or httpx.AsyncClient(
            base_url=self.config.base_url,
            headers=self.config.headers(),
            timeout=self.config.timeout,
        )
        try:
            async with client.stream("POST", "/secure-chat/stream", json=payload) as resp:
                resp.raise_for_status()
                async for raw_line in resp.aiter_lines():
                    if not raw_line:
                        continue
                    chunk = json.loads(raw_line)
                    if chunk.get("type") == "security_block":
                        raise ThreatBlockedError(
                            prompt=prompt,
                            fusion_score=chunk.get("fusion_score", 1.0),
                            reason=chunk.get("reason", "Blocked by security policy"),
                        )
                    yield chunk
        finally:
            if not self._async_client:
                await client.aclose()

    def __repr__(self) -> str:  # noqa: D105
        return f"AISecOpsClient(base_url={self.config.base_url!r})"
