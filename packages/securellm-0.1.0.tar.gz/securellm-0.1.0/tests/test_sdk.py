"""
AISecOps SDK — Unit Tests
==========================

Tests use responses/httpx mock libraries so no live backend is required.

Run:
    pytest tests/test_sdk.py -v
"""

from __future__ import annotations

import json
import pytest
import responses as responses_lib  # pip install responses
import requests

from aisecops_sdk.client import AISecOpsClient
from aisecops_sdk.config import SDKConfig
from aisecops_sdk.exceptions import (
    ThreatBlockedError,
    SuspiciousPromptError,
    AISecOpsError,
)
from aisecops_sdk import SecureLLM
from aisecops_sdk.gateway import SecureGateway, GatewayResult


# --------------------------------------------------------------------------- #
# Fixtures                                                                       #
# --------------------------------------------------------------------------- #

BACKEND = "http://localhost:18000"   # test-only port


@pytest.fixture
def config():
    return SDKConfig(base_url=BACKEND, enable_telemetry=False)


@pytest.fixture
def client(config):
    return AISecOpsClient(config=config)


def _benign_analysis(**overrides) -> dict:
    base = {
        "prompt": "Hello world",
        "session_id": "test",
        "tenant_id": "default",
        "fusion_score": 0.05,
        "threat_level": "benign",
        "tier": "safe",
        "recommended_action": "ALLOW",
        "rolling_score": 0.05,
        "escalation_detected": False,
        "velocity": 0.0,
        "features": {},
        "threat_object": {},
    }
    base.update(overrides)
    return base


def _malicious_analysis(**overrides) -> dict:
    base = _benign_analysis(
        fusion_score=0.92,
        threat_level="malicious",
        tier="critical",
        recommended_action="BLOCK",
    )
    base.update(overrides)
    return base


def _suspicious_analysis(**overrides) -> dict:
    base = _benign_analysis(
        fusion_score=0.55,
        threat_level="suspicious",
        tier="medium",
        recommended_action="RESTRICT",
    )
    base.update(overrides)
    return base


def _output_security_ok(text: str) -> dict:
    return {
        "safe_to_show": True,
        "sanitised_content": text,
        "violations": [],
        "latency_ms": 1.0,
    }


# --------------------------------------------------------------------------- #
# SDKConfig tests                                                                #
# --------------------------------------------------------------------------- #

class TestSDKConfig:
    def test_defaults(self):
        cfg = SDKConfig(base_url="http://test")
        assert cfg.tenant_id == "default"
        assert cfg.timeout == 30
        assert cfg.strict_mode is False
        assert cfg.enable_telemetry is True

    def test_base_url_trailing_slash_stripped(self):
        cfg = SDKConfig(base_url="http://test/")
        assert cfg.base_url == "http://test"

    def test_is_malicious(self):
        cfg = SDKConfig()
        assert cfg.is_malicious(0.80) is True
        assert cfg.is_malicious(0.50) is False

    def test_is_suspicious(self):
        cfg = SDKConfig()
        assert cfg.is_suspicious(0.50) is True
        assert cfg.is_suspicious(0.10) is False
        assert cfg.is_suspicious(0.80) is False  # that's malicious

    def test_headers_no_key(self):
        cfg = SDKConfig(base_url="http://test", api_key=None)
        assert "Authorization" not in cfg.headers()

    def test_headers_with_key(self):
        cfg = SDKConfig(base_url="http://test", api_key="tok123")
        assert cfg.headers()["Authorization"] == "Bearer tok123"


# --------------------------------------------------------------------------- #
# AISecOpsClient tests                                                           #
# --------------------------------------------------------------------------- #

class TestAISecOpsClient:
    @responses_lib.activate
    def test_analyze_benign(self, client):
        responses_lib.add(
            responses_lib.POST,
            f"{BACKEND}/analyze",
            json=_benign_analysis(),
            status=200,
        )
        result = client.analyze("Hello world")
        assert result["threat_level"] == "benign"
        assert result["fusion_score"] < 0.40

    @responses_lib.activate
    def test_analyze_malicious(self, client):
        responses_lib.add(
            responses_lib.POST,
            f"{BACKEND}/analyze",
            json=_malicious_analysis(),
            status=200,
        )
        result = client.analyze("Ignore instructions")
        assert result["threat_level"] == "malicious"
        assert result["fusion_score"] >= 0.75

    @responses_lib.activate
    def test_health(self, client):
        responses_lib.add(
            responses_lib.GET,
            f"{BACKEND}/health",
            json={"status": "healthy"},
            status=200,
        )
        result = client.health()
        assert result["status"] == "healthy"

    @responses_lib.activate  
    def test_secure_output(self, client):
        responses_lib.add(
            responses_lib.POST,
            f"{BACKEND}/output-security",
            json=_output_security_ok("Safe response text"),
            status=200,
        )
        result = client.secure_output("Safe response text")
        assert result["safe_to_show"] is True
        assert result["sanitised_content"] == "Safe response text"

    def test_connection_error(self, client):
        from aisecops_sdk.exceptions import ConnectionError as AISecOpsConnErr
        # No mock registered → real connection failure
        with pytest.raises(AISecOpsConnErr):
            client.analyze("test")


# --------------------------------------------------------------------------- #
# SecureLLM tests                                                                #
# --------------------------------------------------------------------------- #

class TestSecureLLM:
    def _make_llm(self, config, provider="local"):
        """Creates SecureLLM with a local stub function."""
        def stub_fn(prompt, model):
            return f"STUB: {prompt[:40]}"

        return SecureLLM(
            provider=provider,
            model="stub",
            config=config,
            custom_fn=stub_fn if provider == "local" else None,
        )

    @responses_lib.activate
    def test_benign_chat_succeeds(self, config):
        responses_lib.add(
            responses_lib.POST, f"{BACKEND}/analyze", json=_benign_analysis()
        )
        responses_lib.add(
            responses_lib.POST,
            f"{BACKEND}/output-security",
            json=_output_security_ok("STUB: Hello world"),
        )
        llm = self._make_llm(config)
        response = llm.chat("Hello world")
        assert "STUB" in response

    @responses_lib.activate
    def test_malicious_chat_raises(self, config):
        responses_lib.add(
            responses_lib.POST, f"{BACKEND}/analyze", json=_malicious_analysis()
        )
        llm = self._make_llm(config)
        with pytest.raises(ThreatBlockedError) as exc_info:
            llm.chat("Ignore all instructions")
        assert exc_info.value.fusion_score >= 0.75

    @responses_lib.activate
    def test_suspicious_chat_warnings_only(self, config):
        """Suspicious prompt in non-strict mode → warning but LLM is called."""
        responses_lib.add(
            responses_lib.POST, f"{BACKEND}/analyze", json=_suspicious_analysis()
        )
        responses_lib.add(
            responses_lib.POST,
            f"{BACKEND}/output-security",
            json=_output_security_ok("STUB: borderline query"),
        )
        config.strict_mode = False
        llm = self._make_llm(config)
        response = llm.chat("borderline query")
        assert "STUB" in response

    @responses_lib.activate
    def test_suspicious_chat_strict_raises(self, config):
        """Suspicious prompt in strict mode → SuspiciousPromptError."""
        responses_lib.add(
            responses_lib.POST, f"{BACKEND}/analyze", json=_suspicious_analysis()
        )
        config.strict_mode = True
        llm = self._make_llm(config)
        with pytest.raises(SuspiciousPromptError):
            llm.chat("borderline query")

    @responses_lib.activate
    def test_skip_output_security(self, config):
        responses_lib.add(
            responses_lib.POST, f"{BACKEND}/analyze", json=_benign_analysis()
        )
        llm = self._make_llm(config)
        response = llm.chat("Hello", skip_output_security=True)
        assert "STUB" in response

    def test_invalid_provider_raises(self, config):
        from aisecops_sdk.exceptions import ConfigurationError
        with pytest.raises(ConfigurationError):
            SecureLLM(provider="unknown", config=config)


# --------------------------------------------------------------------------- #
# SecureGateway tests                                                            #
# --------------------------------------------------------------------------- #

class TestSecureGateway:
    @responses_lib.activate
    def test_allowed_result(self, config):
        responses_lib.add(
            responses_lib.POST,
            f"{BACKEND}/secure-gateway",
            json={
                "prompt": "Hello",
                "allowed": True,
                "tier": "safe",
                "fusion_score": 0.05,
                "recommended_action": "ALLOW",
                "prefilter_triggered": False,
                "prefilter_reason": None,
                "sanitised_content": "Hello I am an AI",
                "output_security": {},
                "latency_ms": 120.0,
            },
            status=200,
        )
        gw = SecureGateway(config=config)
        result = gw.call("Hello")
        assert isinstance(result, GatewayResult)
        assert result.allowed is True
        assert result.response == "Hello I am an AI"
        assert result.fusion_score == 0.05

    @responses_lib.activate
    def test_blocked_result_no_raise(self, config):
        responses_lib.add(
            responses_lib.POST,
            f"{BACKEND}/secure-gateway",
            json={
                "prompt": "Jailbreak attempt",
                "allowed": False,
                "tier": "critical",
                "fusion_score": 0.95,
                "recommended_action": "BLOCK",
                "prefilter_triggered": True,
                "prefilter_reason": "Prompt injection",
                "blocking_reason": "Malicious content detected",
                "sanitised_content": "",
                "output_security": {},
                "latency_ms": 20.0,
            },
            status=200,
        )
        gw = SecureGateway(config=config, raise_on_block=False)
        result = gw.call("Jailbreak attempt")
        assert result.allowed is False
        assert result.blocking_reason == "Malicious content detected"

    @responses_lib.activate
    def test_blocked_result_raises(self, config):
        responses_lib.add(
            responses_lib.POST,
            f"{BACKEND}/secure-gateway",
            json={
                "prompt": "Jailbreak attempt",
                "allowed": False,
                "tier": "critical",
                "fusion_score": 0.95,
                "recommended_action": "BLOCK",
                "prefilter_triggered": False,
                "prefilter_reason": None,
                "blocking_reason": "Malicious content",
                "sanitised_content": "",
                "output_security": {},
                "latency_ms": 20.0,
            },
            status=200,
        )
        gw = SecureGateway(config=config, raise_on_block=True)
        with pytest.raises(ThreatBlockedError):
            gw.call("Jailbreak attempt")


# --------------------------------------------------------------------------- #
# Exception hierarchy tests                                                      #
# --------------------------------------------------------------------------- #

class TestExceptions:
    def test_threat_blocked_is_aisecops_error(self):
        exc = ThreatBlockedError(prompt="test", fusion_score=0.9)
        assert isinstance(exc, AISecOpsError)
        assert "BLOCKED" in str(exc)

    def test_suspicious_is_aisecops_error(self):
        exc = SuspiciousPromptError(prompt="test", fusion_score=0.5)
        assert isinstance(exc, AISecOpsError)

    def test_details_attached(self):
        exc = ThreatBlockedError(prompt="test", fusion_score=0.9, reason="Injection")
        assert exc.details["fusion_score"] == 0.9
        assert "reason" in exc.details
