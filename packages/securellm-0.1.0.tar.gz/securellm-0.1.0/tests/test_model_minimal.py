"""Minimal diagnostic - Step 1: Model Loading"""
import sys
from pathlib import Path
import torch
import json

sys.path.insert(0, str(Path(__file__).parent))

from fusion_engine.model import FusionMLP

print("Step 1: Loading model...")
model_path = "models/fusion_model.pt"
device = torch.device("cpu")

checkpoint = torch.load(model_path, map_location=device)
model = FusionMLP().to(device)
model.load_state_dict(checkpoint['model_state_dict'])
model.eval()

print("Model loaded successfully")
print(f"Checkpoint keys: {list(checkpoint.keys())}")

# Check weights
for name, param in model.named_parameters():
    print(f"{name}: mean={param.data.mean().item():.6f}, std={param.data.std().item():.6f}")

print("\nStep 2: Test with manual input...")
import numpy as np

# Manual malicious feature vector
features = torch.tensor([[0.9, 0.9, 0.0, 0.85, 0.0, 0.2]], dtype=torch.float32)
print(f"Input: {features.numpy()[0]}")

with torch.no_grad():
    logit = model(features).item()
    score = 1 / (1 + np.exp(-logit))

print(f"Logit: {logit:.6f}")
print(f"Score: {score:.6f}")

# Load threshold
with open("models/fusion_threshold.json", 'r') as f:
    threshold_data = json.load(f)
threshold = threshold_data['optimal_threshold']
print(f"Threshold: {threshold}")
print(f"Result: {'MALICIOUS' if score >= threshold else 'BENIGN'}")
