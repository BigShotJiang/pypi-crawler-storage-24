"""
AISecOps SDK — PyPI package setup.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
this_dir = Path(__file__).parent
long_description = (this_dir / "SDK_README.md").read_text(encoding="utf-8") if (this_dir / "SDK_README.md").exists() else ""

setup(
    name="securellm",
    version="0.1.0",
    description="AI Security Operations Platform — Python SDK & Security Gateway",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="AISecOps Team",
    url="https://github.com/Tarunvoff/LLM-FIREWALL",
    license="Apache-2.0",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords="ai security llm prompt-injection jailbreak sdk gateway",
    python_requires=">=3.10",

    # Include ONLY the SDK package on pip install
    packages=find_packages(include=["aisecops_sdk", "aisecops_sdk.*"]),

    install_requires=[
        "requests>=2.31.0",
        "httpx>=0.27.0",
        "pydantic>=2.7.0",
        "rich>=13.7.0",        # CLI colored output
    ],

    extras_require={
        # LLM provider extras — users pip install aisecops[openai] etc.
        "openai":    ["openai>=1.0.0"],
        "anthropic": ["anthropic>=0.25.0"],
        "langchain": ["langchain>=0.1.0"],
        # Full install: pip install aisecops[all]
        "all": [
            "openai>=1.0.0",
            "anthropic>=0.25.0",
            "langchain>=0.1.0",
        ],
        # Development extras
        "dev": [
            "pytest>=8.0.0",
            "pytest-asyncio>=0.23.0",
            "pytest-httpx>=0.30.0",
            "responses>=0.25.0",
            "black",
            "ruff",
        ],
    },

    entry_points={
        "console_scripts": [
            # Registers the `securellm` CLI command after pip install
            "securellm=aisecops_sdk.cli:main",
        ],
    },

    include_package_data=True,
    zip_safe=False,
)
