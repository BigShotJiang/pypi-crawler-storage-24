#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.11"
# dependencies = [
#   "click",
#   "rich-click",
#   "abx-pkg",
# ]
# ///
#
# Install a binary using pip package manager.
#
# Usage: on_Binary__11_pip_install.py --binary-id=<uuid> --machine-id=<uuid> --name=<name>
# Output: Binary JSONL record to stdout after installation
#
# Environment variables:
#     LIB_DIR: Library directory (default: ~/.config/abx/lib)

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))
from base.utils import enforce_lib_permissions

import rich_click as click
from abx_pkg import Binary, EnvProvider, PipProvider


@click.command()
@click.option("--binary-id", required=True, help="Binary UUID")
@click.option("--machine-id", required=True, help="Machine UUID")
@click.option("--name", required=True, help="Binary name to install")
@click.option("--binproviders", default="*", help="Allowed providers (comma-separated)")
@click.option("--overrides", default=None, help="JSON-encoded overrides dict")
def main(
    binary_id: str, machine_id: str, name: str, binproviders: str, overrides: str | None
):
    """Install binary using pip."""

    # Check if pip provider is allowed
    if binproviders != "*" and "pip" not in binproviders.split(","):
        click.echo(f"pip provider not allowed for {name}", err=True)
        sys.exit(0)

    # Get LIB_DIR from environment (optional)
    lib_dir = os.environ.get("LIB_DIR", "").strip()
    if not lib_dir:
        lib_dir = str(Path.home() / ".config" / "abx" / "lib")

    # Structure: lib/arm64-darwin/pip/venv (PipProvider will create venv automatically)
    pip_venv_path = Path(lib_dir) / "pip" / "venv"
    pip_venv_path.parent.mkdir(parents=True, exist_ok=True)
    venv_python = pip_venv_path / "bin" / "python"

    # Seed the pip venv with the same interpreter running this hook unless explicitly overridden.
    preferred_python = os.environ.get("PIP_VENV_PYTHON", "").strip()
    if not preferred_python and sys.version_info[:2] >= (3, 14):
        for candidate in ("python3.12", "python3.11", "python3.13"):
            candidate_path = shutil.which(candidate)
            if candidate_path:
                preferred_python = candidate_path
                break
    if not preferred_python:
        current_python = Path(sys.executable).resolve()
        if current_python.is_file():
            preferred_python = str(current_python)
        else:
            current_python = shutil.which(Path(sys.executable).name) or sys.executable
            if current_python:
                preferred_python = current_python
    if not preferred_python:
        for candidate in (
            "python3.12",
            "python3.11",
            "python3.10",
            "python3.13",
            "python3.14",
        ):
            candidate_path = shutil.which(candidate)
            if candidate_path:
                preferred_python = candidate_path
                break
    if preferred_python and not venv_python.exists():
        try:
            subprocess.run(
                [preferred_python, "-m", "venv", str(pip_venv_path), "--upgrade-deps"],
                check=True,
            )
        except Exception:
            # Fall back to PipProvider-managed venv creation
            pass

    # Use abx-pkg PipProvider to install binary with custom venv
    provider = PipProvider(pip_venv=pip_venv_path)
    if not provider.INSTALLER_BIN:
        click.echo("pip not available on this system", err=True)
        sys.exit(1)

    click.echo(f"Installing {name} via pip to venv at {pip_venv_path}...", err=True)

    try:
        # Parse overrides if provided
        overrides_dict = None
        if overrides:
            try:
                overrides_dict = json.loads(overrides)
                # Extract pip-specific overrides
                overrides_dict = overrides_dict.get("pip", {})
                click.echo(f"Using pip install overrides: {overrides_dict}", err=True)
            except json.JSONDecodeError:
                click.echo(
                    f"Warning: Failed to parse overrides JSON: {overrides}", err=True
                )

        binary = Binary(
            name=name,
            binproviders=[EnvProvider(), provider],
            overrides={"pip": overrides_dict} if overrides_dict else {},
        ).load_or_install()
    except Exception as e:
        click.echo(f"pip install failed: {e}", err=True)
        sys.exit(1)

    if not binary.abspath:
        click.echo(f"{name} not found after pip install", err=True)
        sys.exit(1)

    # Output Binary JSONL record to stdout
    record = {
        "type": "Binary",
        "name": name,
        "abspath": str(binary.abspath),
        "version": str(binary.version) if binary.version else "",
        "sha256": binary.sha256 or "",
        "binprovider": "pip",
    }
    print(json.dumps(record))

    # Emit PATH update for pip bin dir
    pip_bin_dir = str(pip_venv_path / "bin")
    current_path = os.environ.get("PATH", "")

    # Check if pip_bin_dir is already in PATH
    path_dirs = current_path.split(":")
    new_path = f"{pip_bin_dir}:{current_path}" if current_path else pip_bin_dir
    if pip_bin_dir in path_dirs:
        new_path = current_path
    print(
        json.dumps(
            {
                "type": "Machine",
                "config": {
                    "PATH": new_path,
                },
            }
        )
    )

    # Log human-readable info to stderr
    click.echo(f"Installed {name} at {binary.abspath}", err=True)
    click.echo(f"  version: {binary.version}", err=True)

    # Lock down lib/ so snapshot hooks can read/execute but not write
    enforce_lib_permissions()

    sys.exit(0)


if __name__ == "__main__":
    main()
