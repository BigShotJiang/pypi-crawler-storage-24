"""Outbox relay module."""
