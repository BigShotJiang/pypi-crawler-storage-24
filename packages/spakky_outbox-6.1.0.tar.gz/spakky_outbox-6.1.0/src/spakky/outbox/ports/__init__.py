"""Outbox ports module."""
