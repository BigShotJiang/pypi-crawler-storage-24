"""L10: Process / Flow slide."""
LAYOUT_ID = "L10"
LAYOUT_NAME = "Process"
LAYOUT_DESC = "4-step sequential workflow shown as chevrons."
from .core import *

def L10_process(prs, bk, T, logo, title=None, steps=None, descriptions=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L10 Process: 4-step sequential workflow shown as chevrons")
    S.title(title or "Process headline goes here")
    _steps = steps or ["Connect", "Configure", "Test", "Deploy"]
    _descs = descriptions or ["Add SIP trunk\nor phone numbers", "Write your SWML\ncall flow",
              "Run live calls\nin the sandbox", "Push to production\nwith one command"]
    S.process_steps(_steps, _descs)
    S.done()
