"""L03: Agenda / Contents slide."""
LAYOUT_ID = "L03"
LAYOUT_NAME = "Agenda"
LAYOUT_DESC = "Numbered list of topics to be covered. 5 items max."
from .core import *

def L03_agenda(prs, bk, T, logo, title=None, items=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L03 Agenda: numbered list of topics to be covered")
    S.title(title or "Agenda")
    S.numbered(
        items or ["Platform overview and market context",
         "Architecture and technical differentiation",
         "Customer outcomes and case studies",
         "Pricing and deployment model",
         "Next steps and Q&A"])
    S.done()
