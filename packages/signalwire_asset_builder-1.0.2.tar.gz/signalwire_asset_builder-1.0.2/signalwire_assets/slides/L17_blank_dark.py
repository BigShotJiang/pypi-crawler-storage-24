"""L17: Blank slide (dark gradient)."""
LAYOUT_ID = "L17"
LAYOUT_NAME = "Blank (Dark)"
LAYOUT_DESC = "Empty dark gradient slide with footer only."
from .core import *

def L17_blank_dark(prs, bk, T, logo, ai_notes=None):
    s = prs.slides.add_slide(bk)
    first_hex = GRADIENT_STOPS[0][1] if GRADIENT_STOPS else "010915"
    s.background.fill.solid()
    s.background.fill.fore_color.rgb = _hex_to_rgb(first_hex)
    gradient_rect_force(s)
    footer_bar(s, GRAD, logo)
