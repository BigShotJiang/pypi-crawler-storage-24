"""L08: Chart / Data Story slide."""
LAYOUT_ID = "L08"
LAYOUT_NAME = "Chart"
LAYOUT_DESC = "Data visualization with assertion headline and source citation."
from .core import *

def L08_chart(prs, bk, T, logo, title=None, caption=None, source=None, chart_label=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L08 Chart: data visualization with assertion headline and source citation")
    S.title(title or "Chart headline: state the takeaway")
    S.image_area(ML, 1.6, CW, 4.2,
                 chart_label or "[ Insert chart here ]")
    S.text(caption or "What does this data mean? One sentence.",
           ML, 6.0, w=8, h=0.5, size=16, color="muted", italic=True)
    S.text(source or "Source: data source, date",
           ML, 6.5, w=6, h=0.3, size=12, color="subtle")
    S.done()
