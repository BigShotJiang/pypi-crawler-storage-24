"""L05: Two-Column Comparison slide."""
LAYOUT_ID = "L05"
LAYOUT_NAME = "Two-Column"
LAYOUT_DESC = "Side-by-side comparison of two options or approaches."
from .core import *

def L05_two_col(prs, bk, T, logo, title=None, left_title=None, left_items=None, right_title=None, right_items=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L05 Two-Column: side-by-side comparison of two options or approaches")
    S.title(title or "Comparison headline goes here")
    _left_items = left_items or ["Left column point one", "Left column point two", "Left column point three"]
    _right_items = right_items or ["Right column point one", "Right column point two", "Right column point three"]
    S.two_col(
        left_title or "Column A", _left_items,
        right_title or "Column B", _right_items)
    S.done()
