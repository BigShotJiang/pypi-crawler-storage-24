"""L19: Icon Reference sheet."""
LAYOUT_ID = "L19"
LAYOUT_NAME = "Icon Reference"
LAYOUT_DESC = "Curated icon grid for brand asset reference."
from .core import *

def L19_icon_sheet(prs, bk, T, logo, ai_notes=None):
    """Icon reference sheet with curated icons in a grid. Skipped if no icons available."""
    if not ICONS_AVAILABLE and not os.path.exists(CURATED_TARBALL):
        return
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L19 Icon Reference: curated icon grid for brand asset reference")
    S.label("BRAND RESOURCES", top=0.35, color="muted")
    S.title("Icon Reference", top=0.65)

    color_hex = "%02X%02X%02X" % S.ec
    icon_size = 32
    cell_w = Inches(1.1)
    cell_h = Inches(0.9)
    start_y = Inches(1.5)
    col_count = 10
    row = 0
    col = 0

    all_icons = []
    for cat, icons in CURATED_ICONS.items():
        all_icons.extend(icons)

    s = S.s
    for name in all_icons:
        png = icon_to_png(name, color_hex, icon_size)
        if not png:
            continue
        x = ML + col * cell_w
        y = start_y + row * cell_h
        try:
            s.shapes.add_picture(io.BytesIO(png), x + Inches(0.3), y, height=Inches(0.35))
        except Exception:
            pass
        txt(s, x, y + Inches(0.38), cell_w, Inches(0.3),
            name, FONT_B, Pt(7), T["subtle"], align=PP_ALIGN.CENTER)
        col += 1
        if col >= col_count:
            col = 0
            row += 1

    S.done()
