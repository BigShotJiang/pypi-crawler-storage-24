"""L27: Thesis / Assertion slide — one bold claim with two proof blocks."""
LAYOUT_ID = "L27"
LAYOUT_NAME = "Thesis"
LAYOUT_DESC = "Single bold assertion backed by two evidence blocks."
from .core import *

def L27_thesis(prs, bk, T, logo, thesis=None, proof1_title=None, proof1_body=None,
               proof2_title=None, proof2_body=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L27 Thesis: single bold assertion backed by two evidence blocks")
    # Big assertion across the top
    S.text(thesis or "The control plane is the moat",
           ML, 0.5, w=CW, h=1.5, font="h", size=42, bold=True, line_spacing=1.1)
    # Two proof blocks side by side
    cw = 5.75; pad = Inches(0.4); cy = 2.4; ch = 3.8
    S.card(ML, cy, cw, ch, accent=T["emphasis"],
           title=proof1_title or "Evidence",
           body_text=proof1_body or "First proof point that supports the thesis with data or example.",
           body_size=18)
    rx = ML + Inches(cw) + Inches(0.4)
    S.card(rx, cy, cw, ch, accent=FUCHSIA,
           title=proof2_title or "Implication",
           body_text=proof2_body or "What this means for the customer, market, or competitive position.",
           body_size=18)
    S.done()
