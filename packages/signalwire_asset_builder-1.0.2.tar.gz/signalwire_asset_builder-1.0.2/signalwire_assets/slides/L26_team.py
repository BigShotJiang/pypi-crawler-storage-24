"""L26: Team slide with photo placeholders."""
LAYOUT_ID = "L26"
LAYOUT_NAME = "Team"
LAYOUT_DESC = "Leadership photos with names, titles, and key responsibilities."
from .core import *

def L26_team(prs, bk, T, logo, title=None, members=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L26 Team: leadership photos with names, titles, and key responsibilities")
    S.title(title or "Leadership Team")

    cw_t, gap, sy = 2.6, 0.45, 1.5

    members = members or [("Name", "CEO / Founder", "Created FreeSWITCH"),
                           ("Name", "Co-Founder", "Core platform"),
                           ("Name", "Co-Founder", "Developer experience"),
                           ("Name", "Role", "Key responsibility")]

    photo_w_in = 1.4
    for i, (name, title, desc) in enumerate(members):
        cx_in = 0.7 + (cw_t + gap) * i  # ML = 0.7"
        photo_x_in = cx_in + (cw_t - photo_w_in) / 2
        S.image_area(photo_x_in, sy, photo_w_in, photo_w_in, "[ Photo ]")
        ny_in = sy + photo_w_in + 0.3
        S.text(name, cx_in, ny_in, w=cw_t, h=0.4, font="h", size=20,
               bold=True, align=PP_ALIGN.CENTER)
        S.text(title, cx_in, ny_in + 0.4, w=cw_t, h=0.3, size=16,
               color="emphasis", align=PP_ALIGN.CENTER)
        S.text(desc, cx_in, ny_in + 0.8, w=cw_t, h=0.5, size=14,
               color="muted", align=PP_ALIGN.CENTER)

    S.done()
