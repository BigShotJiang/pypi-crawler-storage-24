"""L23: Logo Wall / social proof grid."""
LAYOUT_ID = "L23"
LAYOUT_NAME = "Logo Wall"
LAYOUT_DESC = "Customer and partner social proof grid."
from .core import *

def L23_logo_wall(prs, bk, T, logo, title=None, subtitle=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L23 Logo Wall: customer and partner social proof grid")
    S.title(title or "Trusted by")
    S.text(subtitle or "Enterprise and carrier-grade deployments worldwide",
           ML, 1.5, w=CW, h=0.5, size=18, color="muted")

    cw_l, ch_l, gap, sy = 3.6, 2.0, 0.3, 2.2
    label = "[ Logo ]"
    for row in range(2):
        for col in range(3):
            cx = ML + Inches((cw_l + gap) * col)
            cy = Inches(sy + (ch_l + gap) * row)
            S.image_area(cx, cy, cw_l, ch_l, label)

    S.done()
