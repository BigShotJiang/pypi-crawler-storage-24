"""
SignalWire Asset Builder — pip install signalwire-asset-builder

Usage:
    from signalwire_assets.slides import SlideBuilder, GRAD, LIGHT
    from signalwire_assets.slides import L04_content, L12_kpi, CATALOG

CLI:
    signalwire-assets slides list              # show all layouts
    signalwire-assets slides show L04          # view layout source
    signalwire-assets slides build             # build reference deck
"""

from .core import *  # noqa: F401,F403

# Import layout MODULES (not functions) to access metadata
from . import (
    L01_title as _m01, L02_section as _m02, L03_agenda as _m03, L04_content as _m04,
    L05_two_col as _m05, L06_image_text as _m06, L07_quote as _m07, L08_chart as _m08,
    L09_table as _m09, L10_process as _m10, L11_timeline as _m11, L12_kpi as _m12,
    L13_case_study as _m13, L14_architecture as _m14, L15_closing as _m15, L16_appendix as _m16,
    L17_blank_dark as _m17, L18_blank_light as _m18, L19_icon_sheet as _m19, L20_color_swatch as _m20,
    L21_bento_grid as _m21, L22_before_after as _m22, L23_logo_wall as _m23, L24_metric_dashboard as _m24,
    L25_full_bleed_image as _m25, L26_team as _m26, L27_thesis as _m27, L28_why_now as _m28,
    L29_competitive as _m29, L30_how_it_works as _m30,
)

# Ordered: main layouts, then resource, then blank
_LAYOUT_MODULES = [
    _m01, _m02, _m03, _m04, _m05, _m06, _m07, _m08,
    _m09, _m10, _m11, _m12, _m13, _m14, _m15, _m16,
    _m21, _m22, _m23, _m24, _m25, _m26,
    _m27, _m28, _m29, _m30,
    _m19, _m20, _m17, _m18,
]

# Build catalog from module metadata
CATALOG = {}
LAYOUT_INFO = []
for _mod in _LAYOUT_MODULES:
    _id = _mod.LAYOUT_ID
    _name = _mod.LAYOUT_NAME
    _desc = _mod.LAYOUT_DESC
    _fn = getattr(_mod, [a for a in dir(_mod) if a.startswith("L") and a[1:3].isdigit() and callable(getattr(_mod, a))][0])
    CATALOG[_id] = _fn
    CATALOG[_name.lower().replace(" / ", "_").replace(" ", "_").replace("(", "").replace(")", "")] = _fn
    LAYOUT_INFO.append({"id": _id, "name": _name, "desc": _desc, "fn": _fn, "module": _mod})

ALL_LAYOUTS = [i["fn"] for i in LAYOUT_INFO[:26]]
RESOURCE_LAYOUTS = [i["fn"] for i in LAYOUT_INFO[26:28]]
LAYOUT_NAMES = [i["name"] for i in LAYOUT_INFO]

# Now re-export layout functions by their canonical names
from .L01_title import L01_title  # noqa: F811,E402
from .L02_section import L02_section  # noqa: F811,E402
from .L03_agenda import L03_agenda  # noqa: F811,E402
from .L04_content import L04_content  # noqa: F811,E402
from .L05_two_col import L05_two_col  # noqa: F811,E402
from .L06_image_text import L06_image_text  # noqa: F811,E402
from .L07_quote import L07_quote  # noqa: F811,E402
from .L08_chart import L08_chart  # noqa: F811,E402
from .L09_table import L09_table  # noqa: F811,E402
from .L10_process import L10_process  # noqa: F811,E402
from .L11_timeline import L11_timeline  # noqa: F811,E402
from .L12_kpi import L12_kpi  # noqa: F811,E402
from .L13_case_study import L13_case_study  # noqa: F811,E402
from .L14_architecture import L14_architecture  # noqa: F811,E402
from .L15_closing import L15_closing  # noqa: F811,E402
from .L16_appendix import L16_appendix  # noqa: F811,E402
from .L17_blank_dark import L17_blank_dark  # noqa: F811,E402
from .L18_blank_light import L18_blank_light  # noqa: F811,E402
from .L19_icon_sheet import L19_icon_sheet  # noqa: F811,E402
from .L20_color_swatch import L20_color_swatch  # noqa: F811,E402
from .L21_bento_grid import L21_bento_grid  # noqa: F811,E402
from .L22_before_after import L22_before_after  # noqa: F811,E402
from .L23_logo_wall import L23_logo_wall  # noqa: F811,E402
from .L24_metric_dashboard import L24_metric_dashboard  # noqa: F811,E402
from .L25_full_bleed_image import L25_full_bleed_image  # noqa: F811,E402
from .L26_team import L26_team  # noqa: F811,E402
from .L27_thesis import L27_thesis  # noqa: F811,E402
from .L28_why_now import L28_why_now  # noqa: F811,E402
from .L29_competitive import L29_competitive  # noqa: F811,E402
from .L30_how_it_works import L30_how_it_works  # noqa: F811,E402

__version__ = "1.0.0"
