"""L16: Appendix / Reference slide."""
LAYOUT_ID = "L16"
LAYOUT_NAME = "Appendix"
LAYOUT_DESC = "Supplementary detail, methodology, or reference data."
from .core import *

def L16_appendix(prs, bk, T, logo, title=None, eyebrow_text=None, body=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L16 Appendix: supplementary detail, methodology, or reference data")
    S.label(eyebrow_text or "APPENDIX", top=0.35, color="muted")
    S.title(title or "Appendix title goes here", size=30, top=0.65)
    S.text(body or ("Add supporting detail, methodology, data tables, "
           "or supplementary analysis here. "
           "Body text stays at 18pt minimum for readability."),
           ML, 1.8, w=CW, h=4.8, size=18, color="text", line_spacing=1.4)
    S.done()
