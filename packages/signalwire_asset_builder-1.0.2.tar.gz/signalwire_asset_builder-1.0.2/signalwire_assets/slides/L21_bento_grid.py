"""L21: Bento Grid slide for multi-fact layouts."""
LAYOUT_ID = "L21"
LAYOUT_NAME = "Bento Grid"
LAYOUT_DESC = "Multi-fact dashboard with mixed card sizes."
from .core import *

def L21_bento_grid(prs, bk, T, logo, title=None, card1_title=None, card1_body=None,
                   card2_label=None, card2_value=None, card3_label=None, card3_value=None,
                   bottom_labels=None, bottom_descs=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L21 Bento Grid: multi-fact dashboard with mixed card sizes")
    S.title(title or "Key facts at a glance")

    y1 = Inches(1.3)
    w_big, h_big = 6.5, 2.8
    w_sm, h_sm = 5.2, 1.3

    # Large left card
    S.card(ML, y1, w_big, h_big, accent=T["emphasis"],
           title=card1_title or "Primary insight",
           body_text=card1_body or "The most important point on this slide.\nSupported by detail or a visual.",
           body_size=18)

    # Top right card
    rx = ML + Inches(w_big) + Inches(0.2)
    S.card(rx, y1, w_sm, h_sm, accent=FUCHSIA,
           title=card2_label or "Metric", title_size=18)
    S.text(card2_value or "2000+ customers",
           rx + Inches(0.2), y1 + Inches(0.55), w=w_sm - 0.4, h=0.5,
           font="h", size=28, bold=True)

    # Bottom right card
    by = y1 + Inches(h_sm) + Inches(0.2)
    S.card(rx, by, w_sm, h_sm, accent=BLUE,
           title=card3_label or "Metric", title_size=18)
    S.text(card3_value or "800ms latency",
           rx + Inches(0.2), by + Inches(0.55), w=w_sm - 0.4, h=0.5,
           font="h", size=28, bold=True)

    # Row 2: three equal cards
    y2 = y1 + Inches(h_big) + Inches(0.2)
    cw3 = 3.85; h3 = 2.2
    _bottom_labels = bottom_labels or ["85 people", "2.7B minutes", "800ms latency"]
    _bottom_descs = bottom_descs or ["Serving enterprise at scale", "Processed annually", "Sub-second, always"]
    accents = [T["emphasis"], FUCHSIA, BLUE]
    for i in range(3):
        cx = ML + Inches((cw3 + 0.2) * i)
        S.card(cx, y2, cw3, h3, accent=accents[i],
               title=_bottom_labels[i], title_size=24, body_text=_bottom_descs[i])

    S.done()
