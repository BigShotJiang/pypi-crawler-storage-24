"""
DTCG token loading and CSS custom-property generation.

Loads the SignalWire design tokens from either a caller-supplied dict or the
bundled DTCG file, then converts them into CSS custom properties scoped to
:root, [data-theme="dark"], and [data-theme="light"].
"""

import json
from importlib import resources as _pkg_resources


# ---------------------------------------------------------------------------
# Token loading
# ---------------------------------------------------------------------------

def load_tokens(tokens_dict=None):
    """Return the full DTCG token dict.

    Parameters
    ----------
    tokens_dict : dict, optional
        Pre-loaded token dict.  When *None* the bundled
        ``signalwire_assets/assets/signalwire-tokens.dtcg.json`` is read.
    """
    if tokens_dict is not None:
        return tokens_dict
    ref = _pkg_resources.files("signalwire_assets").joinpath(
        "assets", "signalwire-tokens.dtcg.json"
    )
    return json.loads(ref.read_text(encoding="utf-8"))


def _tv(obj, *keys):
    """Safe nested access into a DTCG token object, returning ``$value``."""
    for k in keys:
        obj = obj[k]
    return obj["$value"]


# ---------------------------------------------------------------------------
# CSS generation helpers
# ---------------------------------------------------------------------------

def _get_prefix_map(tokens):
    """Read the prefix map from DTCG. Single source of truth for CSS naming."""
    pm = tokens.get("shared", {}).get("prefix-map", {})
    result = {}
    for key, val in pm.items():
        if key.startswith("$"):
            continue
        if isinstance(val, dict) and "$value" in val:
            result[key] = val["$value"]
    return result


_PREFIX_MAP_CACHE = None


def _resolve_role_ref(ref_str):
    """Convert {group.key} token reference to CSS var() using DTCG prefix map."""
    global _PREFIX_MAP_CACHE
    PREFIX_MAP = _PREFIX_MAP_CACHE or {
        "foreground": "fg", "background": "bg", "border": "border",
        "code": "code", "code-block": "cb", "badge": "badge",
        "brand": "sw", "neutral": "sw", "fill": "fill",
        "callout": "callout", "syntax": "tok",
    }
    # Handle comma-separated lists (accent bar)
    if "," in ref_str and "{" in ref_str:
        parts = [_resolve_role_ref(p.strip()) for p in ref_str.split(",")]
        return ", ".join(parts)
    ref_str = ref_str.strip()
    if not ref_str.startswith("{"):
        return ref_str  # literal value
    inner = ref_str.strip("{}")
    if "." not in inner:
        return ref_str
    group, key = inner.split(".", 1)
    prefix = PREFIX_MAP.get(group, group)
    return f"var(--{prefix}-{key})"


def _flatten_with_prefixes(theme, pm):
    """Emit ``--prefix-key: value;`` lines for every token in *theme*."""
    lines = []
    for group_name, group in theme.items():
        if group_name.startswith("$") or not isinstance(group, dict):
            continue
        prefix = pm.get(group_name, group_name)
        for key, val in group.items():
            if key.startswith("$"):
                continue
            if isinstance(val, dict) and "$value" in val:
                lines.append(f"  --{prefix}-{key}: {val['$value']};")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Public: generate_css
# ---------------------------------------------------------------------------

def generate_css(tokens):
    """Turn a full DTCG token dict into a CSS string with custom properties."""
    shared = tokens["shared"]
    dark = tokens["dark"]
    light = tokens["light"]
    roles = shared.get("roles", {})

    global _PREFIX_MAP_CACHE
    _PREFIX_MAP_CACHE = _get_prefix_map(tokens)
    pm = _PREFIX_MAP_CACHE

    # Shared tokens (brand, code-block, syntax, typography, etc.)
    shared_vars = _flatten_with_prefixes(shared, pm)

    # Generate role CSS custom properties
    role_vars = ""
    for role_name, role_def in roles.items():
        if role_name.startswith("$"):
            continue
        if isinstance(role_def, dict) and "$value" in role_def:
            resolved = _resolve_role_ref(role_def["$value"])
            role_vars += f"  --role-{role_name}: {resolved};\n"

    return f"""/* Generated from DTCG tokens + role map + prefix map */
:root {{
{shared_vars}
  /* Font shorthands */
  --font-heading: var(--type-family-heading);
  --font-body: var(--type-family-prose);
  --font-code: var(--type-family-code);
{role_vars}}}

[data-theme="dark"] {{
{_flatten_with_prefixes(dark, pm)}
}}

[data-theme="light"] {{
{_flatten_with_prefixes(light, pm)}
}}"""
