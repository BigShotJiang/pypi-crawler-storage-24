
def format_cpf_cnpj(value: str) -> str:
    """Format a value as CPF/CNPJ when recognized, otherwise return it unchanged."""
    normalized = ''.join(filter(str.isalnum, value)).upper()

    if len(normalized) == 11 and normalized.isdigit():
        return f"{normalized[:3]}.{normalized[3:6]}.{normalized[6:9]}-{normalized[9:]}"

    if len(normalized) == 14:
        return f"{normalized[:2]}.{normalized[2:5]}.{normalized[5:8]}/{normalized[8:12]}-{normalized[12:]}"

    return value
