"""
`claude-session-sync start` コマンド実装

新しい Claude Code セッションを開始し、バックグラウンドで同期を行う。

フロー:
1. daemon をバックグラウンドで起動（push のみ）
2. `claude` を subprocess.run で実行（新規セッション）
3. Claude Code 終了後: daemon 停止 → push
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time

from claude_session_sync.commands.resume import (
    _reset_terminal,
    _start_push_daemon,
    _stop_push_daemon,
)


def run(args: argparse.Namespace) -> None:
    from claude_session_sync.config import Config
    from claude_session_sync.sync import push_sessions

    # 設定確認
    if not Config.exists():
        print("設定が見つかりません。先に `claude-session-sync init` を実行してください。")
        sys.exit(1)

    config = Config.load()

    # 作業ディレクトリ（明示指定がなければカレントディレクトリを使用）
    cwd: str = getattr(args, "cwd", None) or os.getcwd()
    cwd = os.path.abspath(cwd)
    if not os.path.isdir(cwd):
        print(f"エラー: ディレクトリが存在しません: {cwd}")
        sys.exit(1)
    print(f"作業ディレクトリ: {cwd}")

    # 1. daemon をバックグラウンドで起動
    daemon_pid = _start_push_daemon(config)
    if daemon_pid:
        print(f"バックグラウンド同期を開始しました (PID: {daemon_pid})")

    # 2. claude を実行（新規セッション）
    print("\n新しい Claude Code セッションを開始します...")
    try:
        result = subprocess.run(
            ["claude"],
            cwd=cwd,
        )
    except FileNotFoundError:
        print("エラー: claude コマンドが見つかりません。Claude Code がインストールされているか確認してください。")
        _stop_push_daemon()
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nClaude Code を終了します...")
    finally:
        _reset_terminal()

    # 3. Claude Code 終了後
    import signal as _signal
    _orig_sigint = _signal.signal(_signal.SIGINT, _signal.SIG_IGN)

    print("\nセッション終了。後処理を実行中...")

    try:
        # daemon を停止
        _stop_push_daemon()
        time.sleep(2)

        # push
        try:
            subprocess.run(
                ["git", "add", "-A", "."],
                cwd=config.sync_repo_dir,
                capture_output=True,
            )
            push_sessions(config, dry_run=False, skip_pull=True)
            print("✓ セッションをリモートに同期しました")
        except Exception as e:
            print(f"警告: push に失敗しました: {e}", file=sys.stderr)

        print("完了。")
    finally:
        _signal.signal(_signal.SIGINT, _orig_sigint)
