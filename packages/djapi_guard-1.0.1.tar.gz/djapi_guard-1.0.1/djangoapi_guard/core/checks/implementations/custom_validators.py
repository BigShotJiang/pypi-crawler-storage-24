from collections.abc import Callable

from django.http import HttpRequest, HttpResponse

from djangoapi_guard.core.checks.base import SecurityCheck
from djangoapi_guard.utils import log_activity


class CustomValidatorsCheck(SecurityCheck):
    """Check custom validators."""

    @property
    def check_name(self) -> str:
        return "custom_validators"

    def _log_validation_failure(self, request: HttpRequest) -> None:
        """Log suspicious activity for custom validation failure."""
        log_activity(
            request,
            self.logger,
            log_type="suspicious",
            reason="Custom validation failed",
            level=self.config.log_suspicious_level,
            passive_mode=self.config.passive_mode,
        )

    def _send_violation_event(self, request: HttpRequest, validator: Callable) -> None:
        """Send decorator violation event for custom validation failure."""
        if self.middleware.event_bus is None:
            return
        self.middleware.event_bus.send_middleware_event(
            event_type="decorator_violation",
            request=request,
            action_taken="request_blocked"
            if not self.config.passive_mode
            else "logged_only",
            reason="Custom validation failed",
            decorator_type="content_filtering",
            violation_type="custom_validation",
            validator_name=getattr(validator, "__name__", "anonymous"),
        )

    def check(self, request: HttpRequest) -> HttpResponse | None:
        """Check custom validators."""
        route_config = getattr(request, "_guard_route_config", None)
        if not route_config or not route_config.custom_validators:
            return None

        for validator in route_config.custom_validators:
            validation_response = validator(request)
            if validation_response:
                self._log_validation_failure(request)
                self._send_violation_event(request, validator)
                if not self.config.passive_mode and isinstance(
                    validation_response, HttpResponse
                ):
                    return validation_response
        return None
