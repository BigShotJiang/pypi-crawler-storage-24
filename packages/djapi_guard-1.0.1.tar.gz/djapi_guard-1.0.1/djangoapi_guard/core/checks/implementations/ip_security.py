from django.http import HttpRequest, HttpResponse

from djangoapi_guard.core.checks.base import SecurityCheck
from djangoapi_guard.core.checks.helpers import check_route_ip_access
from djangoapi_guard.decorators.base import RouteConfig
from djangoapi_guard.handlers.ipban_handler import ip_ban_manager
from djangoapi_guard.utils import is_ip_allowed, log_activity


class IpSecurityCheck(SecurityCheck):
    """Check IP-based security (banning, allowlist/blocklist)."""

    @property
    def check_name(self) -> str:
        return "ip_security"

    def _check_banned_ip(
        self, request: HttpRequest, client_ip: str, route_config: RouteConfig | None
    ) -> HttpResponse | None:
        """Check if IP is banned and handle accordingly."""
        if (
            self.middleware.route_resolver is not None
            and self.middleware.route_resolver.should_bypass_check(
                "ip_ban", route_config
            )
        ):
            return None

        if not ip_ban_manager.is_ip_banned(client_ip):
            return None

        log_activity(
            request,
            self.logger,
            log_type="suspicious",
            reason=f"Banned IP attempted access: {client_ip}",
            level=self.config.log_suspicious_level,
            passive_mode=self.config.passive_mode,
        )

        if not self.config.passive_mode:
            return self.middleware.create_error_response(
                status_code=403,
                default_message="IP address banned",
            )

        return None

    def _check_route_ip_restrictions(
        self, request: HttpRequest, client_ip: str, route_config: RouteConfig
    ) -> HttpResponse | None:
        """Check route-specific IP restrictions."""
        route_allowed = check_route_ip_access(client_ip, route_config, self.middleware)

        if route_allowed is None or route_allowed:
            return None

        log_activity(
            request,
            self.logger,
            log_type="suspicious",
            reason=f"IP not allowed by route config: {client_ip}",
            level=self.config.log_suspicious_level,
            passive_mode=self.config.passive_mode,
        )

        if self.middleware.event_bus is not None:
            self.middleware.event_bus.send_middleware_event(
                event_type="decorator_violation",
                request=request,
                action_taken="request_blocked"
                if not self.config.passive_mode
                else "logged_only",
                reason=f"IP {client_ip} blocked",
                decorator_type="access_control",
                violation_type="ip_restriction",
            )

        if not self.config.passive_mode:
            return self.middleware.create_error_response(
                status_code=403,
                default_message="Forbidden",
            )

        return None

    def _check_global_ip_restrictions(
        self, request: HttpRequest, client_ip: str
    ) -> HttpResponse | None:
        """Check global IP allowlist/blocklist."""
        is_allowed = is_ip_allowed(
            client_ip, self.config, self.middleware.geo_ip_handler
        )

        request._guard_is_whitelisted = is_allowed and bool(self.config.whitelist)

        if is_allowed:
            return None

        log_activity(
            request,
            self.logger,
            log_type="suspicious",
            reason=f"IP not allowed: {client_ip}",
            level=self.config.log_suspicious_level,
            passive_mode=self.config.passive_mode,
        )

        if self.middleware.event_bus is not None:
            self.middleware.event_bus.send_middleware_event(
                event_type="ip_blocked",
                request=request,
                action_taken="request_blocked"
                if not self.config.passive_mode
                else "logged_only",
                reason=f"IP {client_ip} not in global allowlist/blocklist",
                ip_address=client_ip,
                filter_type="global",
            )

        if not self.config.passive_mode:
            return self.middleware.create_error_response(
                status_code=403,
                default_message="Forbidden",
            )

        return None

    def check(self, request: HttpRequest) -> HttpResponse | None:
        """Check IP security (banning, allowlist/blocklist)."""
        client_ip = getattr(request, "_guard_client_ip", None)
        route_config = getattr(request, "_guard_route_config", None)
        if not client_ip:
            return None

        ban_response = self._check_banned_ip(request, client_ip, route_config)
        if ban_response:
            return ban_response

        if (
            self.middleware.route_resolver is not None
            and self.middleware.route_resolver.should_bypass_check("ip", route_config)
        ):
            return None

        if route_config:
            return self._check_route_ip_restrictions(request, client_ip, route_config)

        return self._check_global_ip_restrictions(request, client_ip)
