"""Faucet operations mixin."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from cobo_agentic_wallet._mixins.base import BaseClient


class FaucetMixin:
    """Faucet operations mixin."""

    _extract_result: Any
    _faucet_api: Any

    async def faucet_deposit(
        self: "BaseClient",
        *,
        address: str,
        token_id: str,
    ) -> Any:
        """Request test tokens for a given address."""
        from cobo_agentic_wallet_api.models.faucet_deposit_request import (
            FaucetDepositRequest,
        )

        request = FaucetDepositRequest(address=address, token_id=token_id)
        response = await self._faucet_api.deposit(request)
        return self._extract_result(response)

    async def list_faucet_tokens(self: "BaseClient") -> Any:
        """List available faucet tokens grouped by chain."""
        response = await self._faucet_api.list_tokens()
        return self._extract_result(response)
