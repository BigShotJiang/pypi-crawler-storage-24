"""Mixin classes for WalletAPIClient (auto-generated)."""

from cobo_agentic_wallet._mixins.base import BaseClient
from cobo_agentic_wallet._mixins.audit import AuditMixin
from cobo_agentic_wallet._mixins.coin_price import CoinPriceMixin
from cobo_agentic_wallet._mixins.delegation import DelegationMixin
from cobo_agentic_wallet._mixins.health import HealthMixin
from cobo_agentic_wallet._mixins.identity import IdentityMixin
from cobo_agentic_wallet._mixins.metadata import MetadataMixin
from cobo_agentic_wallet._mixins.policy import PolicyMixin
from cobo_agentic_wallet._mixins.transaction_record import TransactionRecordMixin
from cobo_agentic_wallet._mixins.transaction import TransactionMixin
from cobo_agentic_wallet._mixins.wallet import WalletMixin

# Composite mixin that includes all functionality
AllMixins = (
    AuditMixin,
    CoinPriceMixin,
    DelegationMixin,
    HealthMixin,
    IdentityMixin,
    MetadataMixin,
    PolicyMixin,
    TransactionRecordMixin,
    TransactionMixin,
    WalletMixin,
)

__all__ = [
    "BaseClient",
    "AuditMixin",
    "CoinPriceMixin",
    "DelegationMixin",
    "HealthMixin",
    "IdentityMixin",
    "MetadataMixin",
    "PolicyMixin",
    "TransactionRecordMixin",
    "TransactionMixin",
    "WalletMixin",
    "AllMixins",
]
