"""Transactionrecord operations mixin (auto-generated).

DO NOT EDIT MANUALLY. Run scripts/generate_mixins.py to regenerate.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from cobo_agentic_wallet._mixins.base import BaseClient


class TransactionRecordMixin:
    """Transactionrecord operations mixin (auto-generated)."""

    _extract_result: Any
    _transaction_records_api: Any

    async def get_transaction_record(self: "BaseClient", wallet_uuid: str, record_uuid: str) -> Any:
        """Get transaction record"""
        response = await self._transaction_records_api.get_transaction_record(
            wallet_uuid, record_uuid
        )
        return self._extract_result(response)

    async def list_transaction_records(
        self: "BaseClient",
        wallet_uuid: str,
        offset: int | None = None,
        limit: int | None = None,
        status: str | None = None,
        wallet_type: str | None = None,
        token_id: str | None = None,
        chain_id: str | None = None,
    ) -> Any:
        """List transaction records"""
        response = await self._transaction_records_api.list_transaction_records(
            wallet_uuid, offset, limit, status, wallet_type, token_id, chain_id
        )
        return self._extract_result(response)
