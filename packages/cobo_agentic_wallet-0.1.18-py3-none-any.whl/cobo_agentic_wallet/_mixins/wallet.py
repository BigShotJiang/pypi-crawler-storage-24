"""Wallet operations mixin (auto-generated).

DO NOT EDIT MANUALLY. Run scripts/generate_mixins.py to regenerate.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from cobo_agentic_wallet_api.models.wallet_address_create import WalletAddressCreate
from cobo_agentic_wallet_api.models.wallet_create import WalletCreate

if TYPE_CHECKING:
    from cobo_agentic_wallet._mixins.base import BaseClient


class WalletMixin:
    """Wallet operations mixin (auto-generated)."""

    _extract_result: Any
    _wallets_api: Any

    async def archive_wallet(self: "BaseClient", wallet_uuid: str) -> Any:
        """Archive wallet"""
        response = await self._wallets_api.archive_wallet(wallet_uuid)
        return self._extract_result(response)

    async def confirm_wallet_claim(self: "BaseClient", wallet_claim_confirm: Any) -> Any:
        """Confirm Wallet Claim"""
        response = await self._wallets_api.confirm_wallet_claim(wallet_claim_confirm)
        return self._extract_result(response)

    async def create_wallet(
        self: "BaseClient",
        wallet_type: Any,
        name: str,
        group_type: Any | None = None,
        main_node_id: str | None = None,
        backup_node_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        for_owner: bool | None = False,
    ) -> Any:
        """Create wallet"""
        wallet_create = WalletCreate(
            type=wallet_type,
            name=name,
            group_type=group_type,
            main_node_id=main_node_id,
            backup_node_id=backup_node_id,
            metadata=metadata,
            for_owner=for_owner,
        )
        response = await self._wallets_api.create_wallet(wallet_create)
        return self._extract_result(response)

    async def create_wallet_address(
        self: "BaseClient", wallet_uuid: str, *, chain_identifier: str
    ) -> Any:
        """Create wallet address"""
        wallet_address_create = WalletAddressCreate(chain_identifier=chain_identifier)
        response = await self._wallets_api.create_wallet_address(wallet_uuid, wallet_address_create)
        return self._extract_result(response)

    async def get_claim_info(self: "BaseClient", token: str) -> Any:
        """Get claim info by token"""
        response = await self._wallets_api.get_claim_info(token)
        return self._extract_result(response)

    async def get_wallet(
        self: "BaseClient", wallet_uuid: str, include_spend_summary: bool | None = None
    ) -> Any:
        """Get wallet"""
        response = await self._wallets_api.get_wallet(wallet_uuid, include_spend_summary)
        return self._extract_result(response)

    async def get_wallet_node_status(self: "BaseClient", wallet_uuid: str) -> Any:
        """Get node status"""
        response = await self._wallets_api.get_wallet_node_status(wallet_uuid)
        return self._extract_result(response)

    async def initiate_wallet_claim(self: "BaseClient", wallet_claim_initiate: Any) -> Any:
        """Initiate Wallet Claim"""
        response = await self._wallets_api.initiate_wallet_claim(wallet_claim_initiate)
        return self._extract_result(response)

    async def list_wallet_addresses(self: "BaseClient", wallet_uuid: str) -> Any:
        """List wallet addresses"""
        response = await self._wallets_api.list_wallet_addresses(wallet_uuid)
        return self._extract_result(response)

    async def list_wallet_balances(
        self: "BaseClient",
        wallet_uuid: str,
        address: str | None = None,
        token_ids: str | None = None,
        limit: int | None = None,
        before: str | None = None,
        after: str | None = None,
    ) -> Any:
        """List wallet balances"""
        response = await self._wallets_api.list_wallet_balances(
            wallet_uuid, address, token_ids, limit, before, after
        )
        return self._extract_result(response)

    async def list_wallets(
        self: "BaseClient",
        offset: int | None = None,
        limit: int | None = None,
        include_archived: bool | None = None,
    ) -> Any:
        """List all wallets"""
        response = await self._wallets_api.list_wallets(offset, limit, include_archived)
        return self._extract_result(response)

    async def update_wallet(self: "BaseClient", wallet_uuid: str, wallet_update: Any) -> Any:
        """Update wallet"""
        response = await self._wallets_api.update_wallet(wallet_uuid, wallet_update)
        return self._extract_result(response)
