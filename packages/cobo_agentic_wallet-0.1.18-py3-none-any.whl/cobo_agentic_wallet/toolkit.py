"""Agent toolkit base abstractions for Cobo Agent Wallet integrations."""

from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from cobo_agentic_wallet.errors import PolicyDenial
from cobo_agentic_wallet.tool_specs import get_tool_spec
from cobo_agentic_wallet_api.models.delegation_permission import DelegationPermission
from cobo_agentic_wallet_api.models.inline_policy_create import InlinePolicyCreate
from cobo_agentic_wallet_api.models.policy_type import PolicyType

ToolHandler = Callable[..., Awaitable[Any]]


@dataclass(frozen=True)
class ToolDefinition:
    """Framework-agnostic tool descriptor."""

    name: str
    description: str
    parameters: dict[str, Any]
    handler: ToolHandler


class AgentWalletToolkit:
    """Framework-agnostic adapter layer for exposing wallet APIs as agent tools.

    Framework-specific integrations (MCP, LangChain, OpenAI, Agno, etc.)
    consume these ``ToolDefinition`` objects and control how errors are surfaced
    to their respective runtimes.
    """

    def __init__(self, client: Any) -> None:
        self._client = client

    @property
    def client(self) -> Any:
        return self._client

    def get_tools(self) -> list[ToolDefinition]:
        """Return the canonical tool set for framework adapters."""
        return [
            self._list_wallets_tool(),
            self._get_balance_tool(),
            self._transfer_tokens_tool(),
            self._list_transactions_tool(),
            self._get_audit_logs_tool(),
            self._create_delegation_tool(),
        ]

    def _list_wallets_tool(self) -> ToolDefinition:
        async def list_wallets(
            *, limit: int = 50, offset: int = 0, include_archived: bool = False
        ) -> Any:
            return await self._client.list_wallets(
                limit=limit,
                offset=offset,
                include_archived=include_archived,
            )

        return self._build_tool_definition("list_wallets", list_wallets)

    def _get_balance_tool(self) -> ToolDefinition:
        async def get_balance(*, wallet_uuid: str) -> Any:
            return await self._client.get_wallet(wallet_uuid, include_spend_summary=True)

        return self._build_tool_definition("get_balance", get_balance)

    def _transfer_tokens_tool(self) -> ToolDefinition:
        async def transfer_tokens(
            *,
            wallet_uuid: str,
            dst_addr: str,
            token_id: str,
            amount: str,
            chain_id: str,
            request_id: str | None = None,
            fee: dict[str, Any] | None = None,
        ) -> Any:
            _ = fee  # Reserved for future use
            return await self._client.transfer_tokens(
                wallet_uuid,
                chain_id=chain_id,
                dst_addr=dst_addr,
                token_id=token_id,
                amount=amount,
                request_id=request_id,
            )

        return self._build_tool_definition("transfer_tokens", transfer_tokens)

    def _list_transactions_tool(self) -> ToolDefinition:
        async def list_transactions(
            *,
            wallet_uuid: str,
            limit: int = 50,
            offset: int = 0,
            status: str | None = None,
        ) -> Any:
            return await self._client.list_transactions(
                wallet_uuid,
                limit=limit,
                offset=offset,
                status=status,
            )

        return self._build_tool_definition("list_transactions", list_transactions)

    def _get_audit_logs_tool(self) -> ToolDefinition:
        async def get_audit_logs(
            *,
            wallet_id: str | None = None,
            principal_id: str | None = None,
            action: str | None = None,
            result: str | None = None,
            start_time: str | None = None,
            end_time: str | None = None,
            cursor: str | None = None,
            limit: int = 50,
        ) -> Any:
            return await self._client.list_audit_logs(
                wallet_id=wallet_id,
                principal_id=principal_id,
                action=action,
                result=result,
                start_time=start_time,
                end_time=end_time,
                cursor=cursor,
                limit=limit,
            )

        return self._build_tool_definition("get_audit_logs", get_audit_logs)

    def _create_delegation_tool(self) -> ToolDefinition:
        async def create_delegation(
            *,
            operator_id: str,
            wallet_id: str,
            permissions: list[str],
            policies: list[dict[str, Any]] | None = None,
            constraints: dict[str, Any] | None = None,
            expires_at: str | None = None,
        ) -> Any:
            # Convert string permissions to enum
            permissions_enum = [DelegationPermission(p) for p in permissions]
            # Build inline policies from both policies and constraints
            inline_policies: list[InlinePolicyCreate] = []
            if policies:
                for p in policies:
                    inline_policies.append(
                        InlinePolicyCreate(
                            name=p.get("name", "policy"),
                            type=PolicyType(p.get("type", "transfer")),
                            rules=p.get("rules", {}),
                        )
                    )
            if constraints:
                # Convert legacy constraints to inline policy
                inline_policies.append(
                    InlinePolicyCreate(
                        name="legacy-constraints",
                        type=PolicyType.TRANSFER,
                        rules=constraints,
                    )
                )
            return await self._client.create_delegation(
                operator_id=operator_id,
                wallet_id=wallet_id,
                permissions=permissions_enum,
                policies=inline_policies if inline_policies else None,
                expires_at=expires_at,
            )

        return self._build_tool_definition("create_delegation", create_delegation)

    @staticmethod
    def _build_tool_definition(name: str, handler: ToolHandler) -> ToolDefinition:
        spec = get_tool_spec(name)
        return ToolDefinition(
            name=spec.name,
            description=spec.description,
            parameters=copy.deepcopy(spec.parameters),
            handler=handler,
        )

    @staticmethod
    def _format_denial(error: PolicyDenial) -> str:
        """Format a policy denial into an LLM-readable guidance message."""

        lines = [f"Policy Denied [{error.code}]: {error.reason}"]
        for key, value in sorted(error.details.items()):
            lines.append(f"  {key}: {value}")
        if error.suggestion:
            lines.append(f"Suggestion: {error.suggestion}")
        return "\n".join(lines)
