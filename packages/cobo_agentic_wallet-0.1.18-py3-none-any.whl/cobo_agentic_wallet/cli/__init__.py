"""CLI package for Cobo Agent Wallet SDK."""

from __future__ import annotations

from typing import Any

__all__ = ["app"]


def __getattr__(name: str) -> Any:
    if name == "app":
        from cobo_agentic_wallet.cli.app import app

        return app
    raise AttributeError(name)
