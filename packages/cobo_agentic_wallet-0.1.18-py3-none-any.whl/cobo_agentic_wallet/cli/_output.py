"""CLI output utilities: table rendering and emit."""

from __future__ import annotations

import json
from decimal import Decimal, InvalidOperation, ROUND_FLOOR
from typing import Any

import typer

from cobo_agentic_wallet.cli._common import OutputFormat


def to_cell(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True, ensure_ascii=True)
    return str(value)


def render_table(headers: list[str], rows: list[list[str]]) -> str:
    widths = [len(header) for header in headers]
    for row in rows:
        for idx, cell in enumerate(row):
            widths[idx] = max(widths[idx], len(cell))

    def _line(cells: list[str]) -> str:
        return " | ".join(cell.ljust(widths[idx]) for idx, cell in enumerate(cells))

    separator = "-+-".join("-" * width for width in widths)
    lines = [_line(headers), separator]
    lines.extend(_line(row) for row in rows)
    return "\n".join(lines)


def _flatten_item(item: dict[str, Any]) -> dict[str, Any]:
    """Flatten simple nested dicts (all-scalar values, ≤3 keys) one level deep."""
    result: dict[str, Any] = {}
    for k, v in item.items():
        if (
            isinstance(v, dict)
            and len(v) <= 3
            and all(not isinstance(vv, (dict, list)) for vv in v.values())
        ):
            for nk, nv in v.items():
                result[f"{k}.{nk}"] = nv
        else:
            result[k] = v
    return result


def table_from_list(items: list[Any]) -> str:
    if not items:
        return "(empty)"

    if not all(isinstance(item, dict) for item in items):
        rows = [[str(idx), to_cell(item)] for idx, item in enumerate(items)]
        return render_table(["index", "value"], rows)

    flat_items = [_flatten_item(item) for item in items]
    headers: list[str] = []
    for item in flat_items:
        for key in item.keys():
            if key not in headers:
                headers.append(str(key))

    rows = [[to_cell(item.get(key, "")) for key in headers] for item in flat_items]
    return render_table(headers, rows)


def table_from_dict(payload: dict[str, Any]) -> str:
    list_key = next((k for k in ("data", "items") if isinstance(payload.get(k), list)), None)
    if list_key is not None:
        table = table_from_list(payload[list_key])
        footer_parts: list[str] = []
        for k, v in payload.items():
            if k == list_key:
                continue
            if k == "pagination" and isinstance(v, dict):
                for pk, pv in v.items():
                    if pv not in ("", None):
                        footer_parts.append(f"{pk}: {to_cell(pv)}")
            else:
                footer_parts.append(f"{k}: {to_cell(v)}")
        if footer_parts:
            return f"{table}\n\n" + "\n".join(footer_parts)
        return table

    rows = [[str(key), to_cell(value)] for key, value in payload.items()]
    if not rows:
        return "(empty)"
    return render_table(["field", "value"], rows)


def emit(payload: Any, output_format: OutputFormat) -> None:
    if output_format == OutputFormat.JSON:
        typer.echo(json.dumps(payload, indent=2, sort_keys=True, default=str, ensure_ascii=True))
        return

    if isinstance(payload, list):
        typer.echo(table_from_list(payload))
        return
    if isinstance(payload, dict):
        typer.echo(table_from_dict(payload))
        return

    typer.echo(str(payload))


def parse_decimal(raw: Any) -> Decimal | None:
    if raw is None:
        return None
    try:
        return Decimal(str(raw))
    except (InvalidOperation, ValueError):
        return None


def progress_bar(spent: Decimal, limit: Decimal, width: int = 12) -> str:
    ratio = max(Decimal("0"), min(Decimal("1"), spent / limit))
    filled = int((ratio * Decimal(width)).to_integral_value(rounding=ROUND_FLOOR))
    return "[" + ("#" * filled).ljust(width, ".") + "]"


def usage_cell(spent: Any, limit: Any) -> str:
    spent_dec = parse_decimal(spent)
    limit_dec = parse_decimal(limit)
    if spent_dec is None:
        return "n/a"
    if limit_dec is None or limit_dec <= 0:
        return f"{spent_dec} / -"
    return f"{spent_dec} / {limit_dec} ({progress_bar(spent_dec, limit_dec)})"


def render_wallet_status_table(payload: dict[str, Any]) -> str:
    wallet = payload.get("wallet")
    if not isinstance(wallet, dict):
        return table_from_dict(payload)

    lines = [
        f"wallet_uuid: {to_cell(wallet.get('uuid', ''))}",
        f"name: {to_cell(wallet.get('name', ''))}",
        f"owner_id: {to_cell(wallet.get('owner_id', ''))}",
        f"wallet_status: {to_cell(wallet.get('status', ''))}",
    ]

    summary = payload.get("spend_summary")
    if not isinstance(summary, list) or not summary:
        lines.append("spend_summary: (empty)")
        return "\n".join(lines)

    rows: list[list[str]] = []
    frozen_count = 0
    for item in summary:
        if not isinstance(item, dict):
            continue
        is_frozen = bool(item.get("frozen"))
        if is_frozen:
            frozen_count += 1
        rows.append(
            [
                to_cell(item.get("delegation_id", "")),
                to_cell(item.get("operator_id", "")),
                "yes" if is_frozen else "no",
                usage_cell(item.get("daily_spent"), item.get("daily_limit")),
                usage_cell(item.get("monthly_spent"), item.get("monthly_limit")),
            ],
        )
    lines.append(f"delegations: {len(rows)} total, {frozen_count} frozen")
    lines.append("")
    lines.append(
        render_table(
            ["delegation_id", "operator_id", "frozen", "daily_usage", "monthly_usage"],
            rows,
        ),
    )
    return "\n".join(lines)
