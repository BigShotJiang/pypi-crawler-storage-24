"""Persistent config helpers for onboarding CLI workflows.

Directory layout
~~~~~~~~~~~~~~~~
~/.cobo-agentic-wallet/
├── config                          # global: default_profile, etc.
└── profiles/
    └── profile_{agent_id}/
        ├── credentials             # per-agent: api_key, wallet_uuid, …
        └── tss-node/
            └── cobo-tss-node       # TSS binary + db/configs/logs/recovery
"""

from __future__ import annotations

import json
import logging
import os
import shutil
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

CONFIG_PATH_ENV_VAR = "CAW_CONFIG_PATH"

DEFAULT_CONFIG_DIR = ".cobo-agentic-wallet"
DEFAULT_GLOBAL_CONFIG_FILENAME = "config"
DEFAULT_CREDENTIALS_FILENAME = "credentials"
PROFILES_DIR_NAME = "profiles"
PROFILE_PREFIX = "profile_"
TSS_NODE_DIR_NAME = "tss-node"
TSS_NODE_BINARY_NAME = "cobo-tss-node"


# ---------------------------------------------------------------------------
# Base / global helpers
# ---------------------------------------------------------------------------


def resolve_base_dir() -> Path:
    """Return the root config directory (``~/.cobo-agentic-wallet``)."""
    return Path.home() / DEFAULT_CONFIG_DIR


def resolve_global_config_path() -> Path:
    """Return ``~/.cobo-agentic-wallet/config``."""
    return resolve_base_dir() / DEFAULT_GLOBAL_CONFIG_FILENAME


def load_global_config() -> dict[str, Any]:
    """Load global config.  Returns empty dict if file is missing."""
    path = resolve_global_config_path()
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        payload = json.load(fh)
    if not isinstance(payload, dict):
        return {}
    return payload


def save_global_config(payload: dict[str, Any]) -> Path:
    """Atomically write the global config and return the path."""
    path = resolve_global_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(f"{path.suffix}.tmp")
    with tmp_path.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, sort_keys=True, ensure_ascii=True)
        fh.write("\n")
    tmp_path.replace(path)
    os.chmod(path, 0o600)
    return path


# ---------------------------------------------------------------------------
# Legacy layout migration
# ---------------------------------------------------------------------------

_LEGACY_TSS_FILES = (".password", ".tss-env", ".tss-node.pid", "tss-node")
_LEGACY_TSS_DIRS = ("configs", "db", "logs", "recovery")


def _is_legacy_layout(base: Path) -> bool:
    """Detect the old flat layout: ``config`` contains ``agent_id`` (credentials)."""
    cfg = base / DEFAULT_GLOBAL_CONFIG_FILENAME
    if not cfg.exists():
        return False
    try:
        with cfg.open("r", encoding="utf-8") as fh:
            payload = json.load(fh)
        return isinstance(payload, dict) and "agent_id" in payload
    except (json.JSONDecodeError, OSError):
        return False


def maybe_migrate_legacy() -> str | None:
    """Migrate flat ``~/.cobo-agentic-wallet/`` to profile layout if needed.

    Returns the migrated agent_id, or ``None`` if no migration was performed.
    """
    base = resolve_base_dir()
    if not _is_legacy_layout(base):
        return None

    old_config = base / DEFAULT_GLOBAL_CONFIG_FILENAME
    with old_config.open("r", encoding="utf-8") as fh:
        creds: dict[str, Any] = json.load(fh)
    agent_id = str(creds.get("agent_id", "")).strip()
    if not agent_id:
        return None

    profile_dir = base / PROFILES_DIR_NAME / f"{PROFILE_PREFIX}{agent_id}"
    if profile_dir.exists():
        return agent_id

    logger.info("Migrating legacy config to profile: %s", agent_id)
    profile_dir.mkdir(parents=True, exist_ok=True)

    # Move credentials
    creds_dest = profile_dir / DEFAULT_CREDENTIALS_FILENAME
    shutil.copy2(old_config, creds_dest)
    os.chmod(creds_dest, 0o600)

    # Move TSS node files into profile tss-node/ directory
    tss_dest = profile_dir / TSS_NODE_DIR_NAME
    tss_dest.mkdir(parents=True, exist_ok=True)
    for name in _LEGACY_TSS_FILES:
        src = base / name
        if src.exists():
            shutil.move(str(src), str(tss_dest / name))
    for name in _LEGACY_TSS_DIRS:
        src = base / name
        if src.is_dir():
            shutil.move(str(src), str(tss_dest / name))

    # Rename old tss binary from "tss-node" to "cobo-tss-node"
    old_binary = tss_dest / "tss-node"
    new_binary = tss_dest / TSS_NODE_BINARY_NAME
    if old_binary.exists() and not new_binary.exists():
        old_binary.rename(new_binary)

    # Rewrite global config
    save_global_config({"default_profile": agent_id})

    logger.info("Migration complete: profile_%s", agent_id)
    return agent_id


# ---------------------------------------------------------------------------
# Profile helpers
# ---------------------------------------------------------------------------


def resolve_profile_dir(agent_id: str) -> Path:
    """Return ``~/.cobo-agentic-wallet/profiles/profile_{agent_id}``."""
    return resolve_base_dir() / PROFILES_DIR_NAME / f"{PROFILE_PREFIX}{agent_id}"


def resolve_credentials_path(agent_id: str) -> Path:
    """Return credentials file path for *agent_id*."""
    return resolve_profile_dir(agent_id) / DEFAULT_CREDENTIALS_FILENAME


def resolve_tss_binary_path(agent_id: str) -> Path:
    """Return the TSS node binary path inside a profile."""
    return resolve_profile_dir(agent_id) / TSS_NODE_DIR_NAME / TSS_NODE_BINARY_NAME


def get_default_profile() -> str | None:
    """Read ``default_profile`` from the global config (``None`` if unset).

    Automatically migrates a legacy flat layout on first access.
    """
    profile = load_global_config().get("default_profile")
    if profile:
        return profile
    try:
        return maybe_migrate_legacy()
    except OSError as exc:
        logger.debug("Legacy migration skipped: %s", exc)
        return None


def set_default_profile(agent_id: str) -> None:
    """Persist *agent_id* as the default profile in global config."""
    config = load_global_config()
    config["default_profile"] = agent_id
    save_global_config(config)


def list_profiles() -> list[str]:
    """Return all profile agent-id strings found on disk."""
    profiles_dir = resolve_base_dir() / PROFILES_DIR_NAME
    if not profiles_dir.is_dir():
        return []
    result: list[str] = []
    for entry in sorted(profiles_dir.iterdir()):
        if entry.is_dir() and entry.name.startswith(PROFILE_PREFIX):
            result.append(entry.name[len(PROFILE_PREFIX) :])
    return result


_ARCHIVE_SUFFIX = ".bak"


def list_archived_profiles() -> list[str]:
    """Return agent-id strings for archived (*.bak) profile directories."""
    profiles_dir = resolve_base_dir() / PROFILES_DIR_NAME
    if not profiles_dir.is_dir():
        return []
    prefix = PROFILE_PREFIX
    suffix = _ARCHIVE_SUFFIX
    result: list[str] = []
    for entry in sorted(profiles_dir.iterdir()):
        name = entry.name
        if entry.is_dir() and name.startswith(prefix) and name.endswith(suffix):
            result.append(name[len(prefix) : -len(suffix)])
    return result


# ---------------------------------------------------------------------------
# Backward-compatible config path resolution
# ---------------------------------------------------------------------------


def resolve_config_path(path: str | Path | None = None) -> Path:
    """Resolve the credentials file path.

    Priority:
      1. Explicit *path* argument
      2. ``CAW_CONFIG_PATH`` env var
      3. Default profile's credentials file
      4. Fallback: ``~/.cobo-agentic-wallet/credentials`` (prompts onboarding)
    """
    if path is not None:
        return Path(path).expanduser()
    env_path = os.getenv(CONFIG_PATH_ENV_VAR)
    if env_path:
        return Path(env_path).expanduser()
    active = get_default_profile()
    if active:
        return resolve_credentials_path(active)
    return resolve_base_dir() / DEFAULT_CREDENTIALS_FILENAME


# ---------------------------------------------------------------------------
# Per-profile credential CRUD (unchanged semantics, new default paths)
# ---------------------------------------------------------------------------


def config_exists(path: str | Path | None = None) -> bool:
    """Return whether the persisted credentials file exists."""
    return resolve_config_path(path).exists()


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    """Load per-profile credentials from disk."""
    config_path = resolve_config_path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    with config_path.open("r", encoding="utf-8") as fh:
        payload = json.load(fh)
    if not isinstance(payload, dict):
        raise ValueError(f"Invalid config payload: expected object, got {type(payload).__name__}")
    return payload


def save_config(payload: dict[str, Any], path: str | Path | None = None) -> Path:
    """Write credentials atomically and return the final path."""
    config_path = resolve_config_path(path)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = config_path.with_suffix(f"{config_path.suffix}.tmp")
    with tmp_path.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, sort_keys=True, ensure_ascii=True)
        fh.write("\n")
    tmp_path.replace(config_path)
    os.chmod(config_path, 0o600)
    return config_path


def update_config(path: str | Path | None = None, **kwargs: Any) -> dict[str, Any]:
    """Load credentials, merge updates, persist, and return the merged payload."""
    try:
        payload = load_config(path)
    except FileNotFoundError:
        payload = {}
    payload.update(kwargs)
    save_config(payload, path)
    return payload


def delete_config(path: str | Path | None = None) -> None:
    """Delete persisted credentials file if it exists."""
    config_path = resolve_config_path(path)
    if config_path.exists():
        config_path.unlink()
