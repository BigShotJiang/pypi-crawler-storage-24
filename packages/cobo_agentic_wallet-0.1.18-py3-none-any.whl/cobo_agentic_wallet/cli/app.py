"""Typer CLI application definition."""

from __future__ import annotations

from contextlib import suppress

import typer

from cobo_agentic_wallet.cli._common import (
    AGENT_WALLET_API_KEY,
    AGENT_WALLET_API_URL,
    AGENT_WALLET_TIMEOUT,
    CLIContext,
    OutputFormat,
)
from cobo_agentic_wallet.cli.config import load_config, resolve_credentials_path

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="Cobo Agentic Wallet CLI — manage wallets, transactions, delegations, and policies from the terminal.",
)


@app.callback()
def main(
    ctx: typer.Context,
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        envvar=AGENT_WALLET_API_KEY,
        help="API key for authentication. Falls back to AGENT_WALLET_API_KEY env variable, then the config file.",
    ),
    api_url: str = typer.Option(
        "http://localhost:8000",
        "--api-url",
        envvar=AGENT_WALLET_API_URL,
        help="Base URL of the Cobo Agentic Wallet service. Falls back to AGENT_WALLET_API_URL env variable, then the config file.",
    ),
    timeout: float = typer.Option(
        30.0,
        "--timeout",
        envvar=AGENT_WALLET_TIMEOUT,
        help="HTTP request timeout in seconds. Falls back to AGENT_WALLET_TIMEOUT env variable.",
    ),
    output_format: OutputFormat = typer.Option(
        OutputFormat.JSON,
        "--format",
        case_sensitive=False,
        help="Output format: json (default) or table.",
    ),
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="Agent profile (agent ID) to use. Falls back to default_profile in global config.",
    ),
) -> None:
    """Set global options applied to every command (API key, URL, timeout, output format)."""
    if ctx.resilient_parsing:
        return

    if not api_key or api_url == "http://localhost:8000":
        with suppress(FileNotFoundError, ValueError):
            config = load_config(resolve_credentials_path(profile)) if profile else load_config()
            if not api_key:
                api_key = str(config.get("api_key", "")).strip() or None
            if api_url == "http://localhost:8000" and config.get("api_url"):
                api_url = str(config["api_url"]).strip()

    ctx.obj = CLIContext(
        api_key=api_key or "",
        api_url=api_url,
        timeout=timeout,
        output_format=output_format,
        profile=profile,
    )


# Import and register command groups
from cobo_agentic_wallet.cli.commands import (  # noqa: E402
    address,
    agent,
    audit,
    delegation,
    faucet,
    fetch,
    meta,
    node,
    onboard,
    pending,
    policy,
    profile,
    tx,
    wallet,
)

app.add_typer(wallet.app, name="wallet", help="Create, list, inspect, update, and archive wallets.")
app.add_typer(address.app, name="address", help="List, create, and inspect wallet addresses.")
app.add_typer(
    tx.app,
    name="tx",
    help="Transfer tokens, call contracts, estimate fees, and query transaction history.",
)
app.add_typer(
    delegation.app,
    name="delegation",
    help="Grant operators access to a wallet and manage those delegations.",
)
app.add_typer(
    policy.app, name="policy", help="Create and manage transfer and contract call policies."
)
app.add_typer(
    pending.app,
    name="pending",
    help="List, approve, and reject operations awaiting manual approval.",
)
app.add_typer(agent.app, name="agent", help="Inspect agents and manage their API keys.")
app.add_typer(
    audit.app, name="audit", help="Query the audit log for allowed, denied, and error events."
)
app.command("fetch")(fetch.fetch_command)
app.add_typer(faucet.app, name="faucet", help="Request testnet tokens for development and testing.")
app.add_typer(node.app, name="node", help="Manage the TSS Node: status, start, stop, health, logs.")
app.add_typer(profile.app, name="profile", help="List, inspect, and switch agent profiles.")
app.add_typer(meta.app, name="meta", help="Query supported chains, tokens, and asset prices.")
app.add_typer(
    onboard.app, name="onboard", help="Set up a new wallet and validate your configuration."
)


@app.command("demo")
def demo(ctx: typer.Context) -> None:
    """Run an end-to-end quickstart demo: create a wallet, transfer tokens, and verify policy enforcement."""
    from cobo_agentic_wallet.cli.commands.onboard import demo as onboard_demo

    onboard_demo(ctx)
