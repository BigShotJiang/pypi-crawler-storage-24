"""CLI freeze/unfreeze domain utilities."""

from __future__ import annotations

from enum import Enum
from typing import Any, TYPE_CHECKING

import typer

if TYPE_CHECKING:
    from cobo_agentic_wallet.client import WalletAPIClient


class FreezeScope(str, Enum):
    OWNER = "owner"
    WALLET = "wallet"
    DELEGATION = "delegation"


async def list_all_owner_delegations(
    client: "WalletAPIClient",
    *,
    wallet_id: str | None = None,
) -> list[dict[str, Any]]:
    """List all delegations with pagination."""
    offset = 0
    limit = 200
    all_items: list[dict[str, Any]] = []
    while True:
        page = await client.list_delegations(
            wallet_id=wallet_id,
            offset=offset,
            limit=limit,
        )
        if not isinstance(page, list) or not page:
            break
        all_items.extend(item for item in page if isinstance(item, dict))
        if len(page) < limit:
            break
        offset += limit
    return all_items


async def infer_owner_id(client: "WalletAPIClient") -> str | None:
    """Infer owner ID from delegations."""
    items = await list_all_owner_delegations(client, wallet_id=None)
    if not items:
        return None
    owner_id = items[0].get("owner_id")
    return str(owner_id) if owner_id is not None else None


async def estimate_affected_count(
    client: "WalletAPIClient",
    *,
    scope: FreezeScope,
    delegation_id: str | None,
    wallet_id: str | None,
    frozen_state: bool,
) -> int:
    """Estimate number of delegations affected by freeze/unfreeze."""
    items = await list_all_owner_delegations(
        client, wallet_id=wallet_id if scope == FreezeScope.WALLET else None
    )
    if scope == FreezeScope.DELEGATION:
        items = [item for item in items if str(item.get("id", "")) == str(delegation_id)]

    count = 0
    for item in items:
        status_value = str(item.get("status", "")).lower()
        if status_value != "active":
            continue
        if bool(item.get("frozen")) == frozen_state:
            continue
        count += 1
    return count


def validate_scope_params(
    *,
    scope: FreezeScope,
    owner_id: str | None,
    wallet_id: str | None,
    delegation_id: str | None,
) -> None:
    """Validate freeze/unfreeze scope parameters."""
    if scope == FreezeScope.OWNER:
        if wallet_id is not None:
            raise typer.BadParameter("--wallet-id is only valid when --scope wallet.")
        if delegation_id is not None:
            raise typer.BadParameter("--delegation-id is only valid when --scope delegation.")
        return

    if scope == FreezeScope.WALLET:
        if wallet_id is None:
            raise typer.BadParameter("--wallet-id is required when --scope wallet.")
        if owner_id is not None:
            raise typer.BadParameter("--owner-id is only valid when --scope owner.")
        if delegation_id is not None:
            raise typer.BadParameter("--delegation-id is only valid when --scope delegation.")
        return

    if delegation_id is None:
        raise typer.BadParameter("--delegation-id is required when --scope delegation.")
    if owner_id is not None:
        raise typer.BadParameter("--owner-id is only valid when --scope owner.")
    if wallet_id is not None:
        raise typer.BadParameter("--wallet-id is only valid when --scope wallet.")
