"""Address management commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import run_command, resolve_wallet_uuid
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


async def _resolve_chain_identifier(client: WalletAPIClient, chain_id: str) -> str:
    """Resolve a chain ID (e.g. SOL, ETH) to its chain_identifier via the chain info API."""
    info = await client.get_chain_info_by_chain_id(chain_id)
    if isinstance(info, dict):
        identifier = info.get("chain_identifier") or info.get("chain_id")
        if identifier:
            return str(identifier)
    raise RuntimeError(
        f"Could not resolve chain_identifier for '{chain_id}'. "
        "Use 'caw meta chains' to list supported chains."
    )


@app.command("list")
def list_addresses(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
) -> None:
    """List all addresses for a wallet, including chain and address string."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_wallet_addresses(wallet_uuid)

    run_command(ctx, _operation)


@app.command("create")
def create_address(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    chain: str = typer.Option(
        ...,
        "--chain",
        help="Chain ID (e.g. ETH, SOL). The chain_identifier is resolved automatically. Use 'caw meta chains' to list supported chains.",
    ),
) -> None:
    """Derive a new address for a wallet on a given chain."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        chain_identifier = await _resolve_chain_identifier(client, chain)
        return await client.create_wallet_address(wallet_uuid, chain_identifier=chain_identifier)

    run_command(ctx, _operation)


@app.command("recent")
def recent_addresses(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
) -> None:
    """List the most recently used addresses for a wallet."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_recent_addresses(wallet_uuid, limit=limit)

    run_command(ctx, _operation)
