"""Metadata commands (chains, tokens, prices)."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("chains")
def list_chains(
    ctx: typer.Context,
    wallet_type: str = typer.Option(
        "MPC-UCW", "--wallet-type", help="Wallet type to query chains for (default: MPC-UCW)."
    ),
    chain_ids: str | None = typer.Option(
        None, "--chain-ids", help="Comma-separated chain IDs to look up (e.g. 'ETH,BASE,SOL')."
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    before: str | None = typer.Option(None, "--before", help="Cursor for previous page."),
    after: str | None = typer.Option(None, "--after", help="Cursor for next page."),
) -> None:
    """List supported chains and their chain IDs. Use chain IDs in transfer and contract call commands."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_chains(
            wallet_type=wallet_type, chain_ids=chain_ids, limit=limit, before=before, after=after
        )

    run_command(ctx, _operation)


@app.command("tokens")
def list_tokens(
    ctx: typer.Context,
    wallet_type: str = typer.Option(
        "MPC-UCW", "--wallet-type", help="Wallet type to query tokens for (default: MPC-UCW)."
    ),
    chain_ids: str | None = typer.Option(
        None, "--chain-ids", help="Comma-separated chain IDs to filter (e.g. 'ETH,BASE')."
    ),
    token_ids: str | None = typer.Option(
        None, "--token-ids", help="Comma-separated token IDs to look up"
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    before: str | None = typer.Option(None, "--before", help="Cursor for previous page."),
    after: str | None = typer.Option(None, "--after", help="Cursor for next page."),
) -> None:
    """List supported tokens and their token IDs. Use token IDs in transfer and balance commands."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_assets(
            wallet_type=wallet_type,
            chain_ids=chain_ids,
            token_ids=token_ids,
            limit=limit,
            before=before,
            after=after,
        )

    run_command(ctx, _operation)


@app.command("prices")
def get_prices(
    ctx: typer.Context,
    asset_coins: str = typer.Argument(
        ..., help="Comma-separated asset coin IDs to look up (e.g. 'ETH,BTC,USDC')."
    ),
    currency: str = typer.Option(
        "USD", "--currency", help="Quote currency for prices (default: USD)."
    ),
) -> None:
    """Get current market prices for one or more assets."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_asset_coin_prices(asset_coins, currency=currency)

    run_command(ctx, _operation)
