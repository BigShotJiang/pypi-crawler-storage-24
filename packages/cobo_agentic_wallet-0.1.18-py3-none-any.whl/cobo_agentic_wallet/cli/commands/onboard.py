"""Onboarding CLI — provision agent and create wallet.

Paths:
  caw onboard --token <TOKEN> --create-wallet   Path A: pair with token + create wallet
  caw onboard --token <TOKEN>                    Path B: pair with token only
  caw onboard --create-wallet                    Path C: provision (no token) + create wallet
"""

from __future__ import annotations

import asyncio
import json
from contextlib import suppress
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import typer

from cobo_agentic_wallet.cli._common import (
    CAW_CONFIG_PATH,
    extract_text,
    get_context,
    make_client,
    OutputFormat,
    progress,
    require_text,
    resolve_wallet_uuid,
    run_async_operation,
    run_with_client,
)
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.cli.config import (
    load_config,
    resolve_credentials_path,
    resolve_tss_binary_path,
    save_config,
    set_default_profile,
)
from cobo_agentic_wallet.cli.tss import (
    create_mpc_wallet,
    download_tss_node,
    init_tss_node,
    poll_wallet_status,
    start_tss_node,
)
from cobo_agentic_wallet.client import WalletAPIClient
from cobo_agentic_wallet.errors import APIError, PolicyDeniedError

app = typer.Typer(no_args_is_help=True)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _do_provision(
    *,
    context: Any,
    env: str | None = None,
    config_path_override: Path | None = None,
    show_progress: bool,
    step: str = "[1/1]",
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Provision agent without a pairing token (creates Principal + API key).

    Creates profile directory ``profiles/profile_{agent_id}/`` and persists
    credentials there (unless *config_path_override* is set for legacy mode).
    Returns (provision_result, config_payload).
    """

    async def _inner() -> tuple[dict[str, Any], dict[str, Any]]:
        progress(f"{step} Provisioning agent...", enabled=show_progress)
        bootstrap_client = make_client(context, allow_unauthenticated=True)
        try:
            provision_result = await bootstrap_client.provision_agent()
        finally:
            await bootstrap_client.close()
        if not isinstance(provision_result, dict):
            raise RuntimeError("Invalid provisioning response")

        agent_id = require_text(provision_result, "agent_id")
        api_key = require_text(provision_result, "api_key")
        status_value = extract_text(provision_result, "status") or ""
        progress(f"{step} Provisioning agent... done", enabled=show_progress)

        creds_path = config_path_override or resolve_credentials_path(agent_id)
        config_payload: dict[str, Any] = {
            "agent_id": agent_id,
            "api_key": api_key,
            "api_url": context.api_url,
            "env": env,
            "status": status_value,
            "onboarded_at": datetime.now(timezone.utc).isoformat(),
            "onboarding_session_id": None,
            "activation_secret": extract_text(provision_result, "activation_secret"),
        }
        save_config(config_payload, creds_path)
        if config_path_override is None:
            set_default_profile(agent_id)
        return provision_result, config_payload

    return run_async_operation(context, _inner)


def _do_pairing(
    *,
    context: Any,
    token: str,
    env: str | None = None,
    config_path_override: Path | None = None,
    show_progress: bool,
    step: str = "[1/1]",
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Pair with backend using token.

    Creates profile directory and persists credentials (unless
    *config_path_override* is set for legacy mode).
    Returns (provision_result, config_payload).
    """

    async def _inner() -> tuple[dict[str, Any], dict[str, Any]]:
        progress(f"{step} Registering with Cobo backend...", enabled=show_progress)
        bootstrap_client = make_client(context, allow_unauthenticated=True)
        try:
            provision_result = await bootstrap_client.provision_agent(token=token)
        finally:
            await bootstrap_client.close()
        if not isinstance(provision_result, dict):
            raise RuntimeError("Invalid provisioning response")

        agent_id = require_text(provision_result, "agent_id")
        api_key = require_text(provision_result, "api_key")
        onboarding_session_id = require_text(provision_result, "onboarding_session_id")
        status_value = extract_text(provision_result, "status") or ""
        if status_value.lower() != "active":
            raise RuntimeError(f"Unexpected provisioning status: {status_value}")
        progress(f"{step} Registering with Cobo backend... done", enabled=show_progress)

        creds_path = config_path_override or resolve_credentials_path(agent_id)
        config_payload: dict[str, Any] = {
            "agent_id": agent_id,
            "api_key": api_key,
            "api_url": context.api_url,
            "env": env,
            "status": status_value,
            "onboarded_at": datetime.now(timezone.utc).isoformat(),
            "onboarding_session_id": onboarding_session_id,
        }
        save_config(config_payload, creds_path)
        if config_path_override is None:
            set_default_profile(agent_id)
        return provision_result, config_payload

    return run_async_operation(context, _inner)


def _do_create_wallet(
    *,
    context: Any,
    agent_id: str,
    api_key: str,
    config_payload: dict[str, Any],
    tss_env: str | None,
    config_path_override: Path | None = None,
    vault_poll_interval: float = 2.0,
    vault_timeout: float = 300.0,
    show_progress: bool,
    step_offset: int = 0,
    total_steps: int = 4,
) -> dict[str, Any]:
    """Download TSS, init, start, create MPC wallet. Returns result dict."""

    creds_path = config_path_override or resolve_credentials_path(agent_id)
    tss_binary = (
        (config_path_override.parent / "tss-node" / "cobo-tss-node")
        if config_path_override
        else resolve_tss_binary_path(agent_id)
    )

    def _step(n: int) -> str:
        return f"[{step_offset + n}/{step_offset + total_steps}]"

    async def _inner() -> Any:
        progress(f"{_step(1)} Downloading TSS-Node...", enabled=show_progress)
        await asyncio.to_thread(
            download_tss_node,
            destination=tss_binary,
            tss_env=tss_env,
            reporter=lambda message: progress(f"[TSS] {message}", enabled=show_progress),
        )
        progress(f"{_step(1)} Downloading TSS-Node... done", enabled=show_progress)

        progress(f"{_step(2)} Initializing TSS-Node...", enabled=show_progress)
        init_result = await asyncio.to_thread(
            init_tss_node,
            tss_binary_path=tss_binary,
            config_path=creds_path,
        )
        progress(f"{_step(2)} Initializing TSS-Node... done", enabled=show_progress)
        main_node_id = require_text(init_result, "tss_node_id")

        progress(f"{_step(3)} Starting TSS-Node...", enabled=show_progress)
        await asyncio.to_thread(
            start_tss_node,
            tss_binary_path=tss_binary,
            tss_env=tss_env,
            reporter=lambda message: progress(f"[TSS] {message}", enabled=show_progress),
        )
        progress(f"{_step(3)} Starting TSS-Node... done", enabled=show_progress)

        progress(f"{_step(4)} Creating MPC wallet...", enabled=show_progress)
        client = make_client(context, api_key=api_key)
        try:
            wallet_payload = await create_mpc_wallet(
                client=client,
                main_node_id=main_node_id,
                for_owner=True,
            )
            wallet_uuid = require_text(wallet_payload, "wallet_uuid", "uuid", "id")
            wallet_status_payload = await poll_wallet_status(
                client=client,
                wallet_uuid=wallet_uuid,
                poll_interval_seconds=vault_poll_interval,
                timeout_seconds=vault_timeout,
            )
        finally:
            await client.close()
        progress(f"{_step(4)} Creating MPC wallet... done", enabled=show_progress)

        config_payload.update(
            {
                "wallet_uuid": wallet_uuid,
                "status": extract_text(wallet_status_payload, "status") or "active",
            }
        )
        save_config(config_payload, creds_path)
        return {
            "agent_id": agent_id,
            "status": config_payload["status"],
            "wallet_uuid": wallet_uuid,
            "onboarding_session_id": config_payload.get("onboarding_session_id"),
            "profile_dir": str(creds_path.parent),
        }

    return run_async_operation(context, _inner)


# ---------------------------------------------------------------------------
# Main entry: caw onboard [--token] [--create-wallet]
# ---------------------------------------------------------------------------


@app.callback(invoke_without_command=True)
def onboard_callback(
    ctx: typer.Context,
    token: str | None = typer.Option(
        None,
        "--token",
        help="Setup token from Console for agent provisioning.",
    ),
    create_wallet: bool = typer.Option(
        False,
        "--create-wallet",
        help="Download TSS node and create MPC wallet after pairing.",
    ),
    config_path: str | None = typer.Option(
        None,
        "--config",
        envvar=CAW_CONFIG_PATH,
        help="Legacy config path override. Normally profiles are auto-managed.",
    ),
    tss_env: str | None = typer.Option(
        None,
        "--env",
        envvar="CAW_ENV",
        help="Cobo environment: sandbox, dev, or prod.",
    ),
) -> None:
    """Onboard your agent wallet.

    \b
    Path A: caw onboard --token <TOKEN> --create-wallet
            Pair with token and create wallet (full onboarding).
    Path B: caw onboard --token <TOKEN>
            Pair with token only; wallet creation deferred.
    Path C: caw onboard --create-wallet
            Provision agent (no token) and create wallet.

    Credentials are stored per-profile under ~/.cobo-agentic-wallet/profiles/.
    """
    if ctx.invoked_subcommand is not None:
        return

    if not token and not create_wallet:
        typer.echo(
            "Provide --token for pairing and/or --create-wallet for wallet creation.\n"
            "See 'caw onboard --help' for details.",
            err=True,
        )
        raise typer.Exit(1)

    context = get_context(ctx)
    show_progress = context.output_format != OutputFormat.JSON
    legacy_path = Path(config_path).expanduser() if config_path else None

    # --- Path B: pairing only ---
    if token and not create_wallet:
        _, config_payload = _do_pairing(
            context=context,
            token=token,
            env=tss_env,
            config_path_override=legacy_path,
            show_progress=show_progress,
        )
        emit(
            {
                "agent_id": config_payload["agent_id"],
                "status": config_payload["status"],
                "onboarding_session_id": config_payload.get("onboarding_session_id"),
                "message": "Pairing complete. Run 'caw onboard --create-wallet' to create wallet.",
            },
            context.output_format,
        )
        return

    # --- Path C: provision (no token) + create wallet  [1/5]..[5/5] ---
    if create_wallet and not token:
        _, config_payload = _do_provision(
            context=context,
            env=tss_env,
            config_path_override=legacy_path,
            show_progress=show_progress,
            step="[1/5]",
        )
        agent_id = config_payload["agent_id"]
        result = _do_create_wallet(
            context=context,
            agent_id=agent_id,
            api_key=config_payload["api_key"],
            config_payload=config_payload,
            tss_env=tss_env,
            config_path_override=legacy_path,
            show_progress=show_progress,
            step_offset=1,
            total_steps=5,
        )
        emit(result, context.output_format)
        return

    # --- Path A: full flow (token + create wallet)  [1/5]..[5/5] ---
    assert token is not None
    _, config_payload = _do_pairing(
        context=context,
        token=token,
        env=tss_env,
        config_path_override=legacy_path,
        show_progress=show_progress,
        step="[1/5]",
    )
    agent_id = config_payload["agent_id"]
    result = _do_create_wallet(
        context=context,
        agent_id=agent_id,
        api_key=config_payload["api_key"],
        config_payload=config_payload,
        tss_env=tss_env,
        config_path_override=legacy_path,
        show_progress=show_progress,
        step_offset=1,
        total_steps=5,
    )
    emit(result, context.output_format)


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------


@app.command("self-test")
def self_test(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Option(
        None, "--wallet", help="Wallet UUID to test. Falls back to config file."
    ),
    config_path: str | None = typer.Option(
        None,
        "--config",
        envvar=CAW_CONFIG_PATH,
        help="Config path override. Falls back to CAW_CONFIG_PATH or active profile credentials.",
    ),
    token: str = typer.Option(
        "USDC", "--token", help="Token ID to use for test transfers (default: USDC)."
    ),
    chain: str = typer.Option(
        "BASE", "--chain", help="Chain ID to use for test transfers (default: BASE)."
    ),
    blocked_amount: str = typer.Option(
        "500",
        "--blocked-amount",
        help="Amount expected to be denied by policy (default: 500). Must exceed your max-per-tx limit.",
    ),
    allowed_amount: str = typer.Option(
        "2",
        "--allowed-amount",
        help="Amount expected to be allowed by policy (default: 2). Must be within your max-per-tx limit.",
    ),
    to: str = typer.Option(
        "0x1111111111111111111111111111111111111111",
        "--to",
        help="Destination address for test transfers.",
    ),
) -> None:
    """Validate that your wallet and policies are correctly configured.

    Runs two test transfers:

    \b
    - A transfer of --blocked-amount that should be denied by policy (pass = denied)
    - A transfer of --allowed-amount that should succeed (pass = submitted)

    Exits with code 1 if either check fails.
    """
    import dataclasses

    wallet_uuid = resolve_wallet_uuid(wallet_uuid)
    context = get_context(ctx)

    if not context.api_key and config_path is not None:
        with suppress(FileNotFoundError, ValueError):
            cfg = load_config(config_path)
            api_key_from_config = str(cfg.get("api_key", "")).strip() or None
            if api_key_from_config:
                context = dataclasses.replace(context, api_key=api_key_from_config)

    async def _operation(client: WalletAPIClient) -> Any:
        blocked: dict[str, Any]
        try:
            response = await client.transfer_tokens(
                wallet_uuid,
                chain_id=chain,
                dst_addr=to,
                token_id=token,
                amount=blocked_amount,
            )
            blocked = {
                "passed": False,
                "reason": "blocked transfer unexpectedly succeeded",
                "response": response,
            }
        except PolicyDeniedError as exc:
            blocked = {
                "passed": True,
                "code": exc.denial.code,
                "reason": exc.denial.reason,
                "details": exc.denial.details,
            }
        except APIError as exc:
            blocked = {
                "passed": False,
                "reason": f"blocked transfer failed with non-policy error ({exc.status_code})",
                "error": str(exc),
            }

        allowed: dict[str, Any]
        try:
            response = await client.transfer_tokens(
                wallet_uuid,
                chain_id=chain,
                dst_addr=to,
                token_id=token,
                amount=allowed_amount,
            )
            allowed_status = ""
            if isinstance(response, dict):
                allowed_status = (extract_text(response, "status") or "").lower()
            if allowed_status in {"denied", "failed", "rejected"}:
                allowed = {
                    "passed": False,
                    "reason": f"allowed transfer returned status={allowed_status}",
                    "response": response,
                }
            else:
                tx_identifier = ""
                if isinstance(response, dict):
                    tx_identifier = (
                        extract_text(response, "tx_id", "id", "request_id", "tx_hash") or ""
                    )
                allowed = {
                    "passed": True,
                    "status": allowed_status or "submitted",
                    "tx_id": tx_identifier or None,
                    "response": response,
                }
        except PolicyDeniedError as exc:
            allowed = {
                "passed": False,
                "reason": "allowed transfer was denied",
                "code": exc.denial.code,
                "details": exc.denial.details,
            }
        except APIError as exc:
            allowed = {
                "passed": False,
                "reason": f"allowed transfer failed ({exc.status_code})",
                "error": str(exc),
            }

        return {
            "wallet_uuid": wallet_uuid,
            "chain_id": chain,
            "token_id": token,
            "blocked_test": blocked,
            "allowed_test": allowed,
            "passed": bool(blocked.get("passed")) and bool(allowed.get("passed")),
        }

    result = run_with_client(context, _operation)
    emit(result, context.output_format)
    if isinstance(result, dict) and not result.get("passed", False):
        raise typer.Exit(code=1)


@app.command("health")
def health(ctx: typer.Context) -> None:
    """Check whether the Cobo Agentic Wallet service is reachable and healthy."""
    context = get_context(ctx)

    async def _operation() -> Any:
        client = make_client(context, allow_unauthenticated=True)
        try:
            return await client.health_check()
        finally:
            await client.close()

    result = run_async_operation(context, _operation)
    emit(result, context.output_format)


def demo(ctx: typer.Context) -> None:
    """Run the P11 quickstart demo workflow."""
    context = get_context(ctx)
    from cobo_agentic_wallet.demo import (
        DemoBackendUnavailableError,
        DemoExecutionError,
        format_demo_output,
        run_quickstart_demo,
    )

    try:
        result = asyncio.run(
            run_quickstart_demo(
                api_url=context.api_url,
                timeout=context.timeout,
            )
        )
    except DemoBackendUnavailableError as exc:
        payload = {
            "error": "BACKEND_UNAVAILABLE",
            "message": str(exc),
            "suggestion": exc.suggestion,
        }
        if context.output_format == OutputFormat.JSON:
            typer.echo(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True), err=True)
        else:
            typer.echo(f"{payload['message']}\nSuggestion: {payload['suggestion']}", err=True)
        raise typer.Exit(code=1) from exc
    except DemoExecutionError as exc:
        payload = {"error": "DEMO_FAILED", "message": str(exc)}
        if context.output_format == OutputFormat.JSON:
            typer.echo(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True), err=True)
        else:
            typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc

    if context.output_format == OutputFormat.TABLE:
        typer.echo(format_demo_output(result))
    else:
        emit(result, context.output_format)
