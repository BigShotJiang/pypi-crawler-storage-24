"""Audit log commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("logs")
def audit_logs(
    ctx: typer.Context,
    wallet: str | None = typer.Option(None, "--wallet", help="Filter by wallet UUID."),
    principal_id: str | None = typer.Option(
        None, "--principal-id", help="Filter by principal UUID."
    ),
    result: str | None = typer.Option(
        None, "--result", help="Filter by evaluation result: 'allowed', 'denied', or 'error'."
    ),
    action: str | None = typer.Option(
        None, "--action", help="Filter by action type (e.g. transfer, contract_call)."
    ),
    start_time: str | None = typer.Option(
        None, "--start-time", help="Start time filter (ISO 8601)."
    ),
    end_time: str | None = typer.Option(None, "--end-time", help="End time filter (ISO 8601)."),
    cursor: str | None = typer.Option(
        None, "--cursor", help="Pagination cursor from a previous response to fetch the next page."
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
) -> None:
    """Query the policy audit log. Each entry records whether an operation was allowed, denied, or errored, and which policy matched."""
    from datetime import datetime as dt

    parsed_start = dt.fromisoformat(start_time) if start_time else None
    parsed_end = dt.fromisoformat(end_time) if end_time else None

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_audit_logs(
            wallet_id=wallet,
            principal_id=principal_id,
            result=result,
            action=action,
            start_time=parsed_start,
            end_time=parsed_end,
            cursor=cursor,
            limit=limit,
        )

    run_command(ctx, _operation)
