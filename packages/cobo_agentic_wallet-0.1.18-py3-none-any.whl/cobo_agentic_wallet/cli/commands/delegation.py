"""Delegation management commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import get_context, run_with_client, resolve_wallet_uuid
from cobo_agentic_wallet.cli._freeze import (
    FreezeScope,
    estimate_affected_count,
    infer_owner_id,
    validate_scope_params,
)
from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.client import WalletAPIClient
from cobo_agentic_wallet_api.models.delegation_permission import DelegationPermission
from cobo_agentic_wallet_api.models.freeze_scope import FreezeScope as SDKFreezeScope
from cobo_agentic_wallet_api.models.inline_policy_create import InlinePolicyCreate
from cobo_agentic_wallet_api.models.policy_type import PolicyType

app = typer.Typer(no_args_is_help=True)


@app.command("create")
def create_delegation(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    to: str = typer.Option(..., "--to", help="Agent ID of the operator to grant access to."),
    max_tx: str = typer.Option(
        ...,
        "--max-tx",
        help="Maximum amount (in USD) the operator can transfer in a single transaction (e.g. '100').",
    ),
    permission: list[str] | None = typer.Option(
        None,
        "--permission",
        help="Permission to grant. Defaults to 'operator'. Can be repeated for multiple permissions (e.g. --permission write:transfer --permission read:wallet).",
    ),
    expires_at: str | None = typer.Option(
        None, "--expires-at", help="Expiration datetime (ISO 8601)."
    ),
) -> None:
    """Grant an operator agent access to a wallet with a per-transaction transfer limit.

    This creates a delegation that allows the specified operator to transfer tokens from the wallet,
    subject to the max-per-tx limit and any additional policies you configure.
    """
    from datetime import datetime as dt

    wallet_uuid = resolve_wallet_uuid(wallet_uuid)
    permission_list = permission or ["operator"]
    permissions_enum = [DelegationPermission(p) for p in permission_list]
    parsed_expires = dt.fromisoformat(expires_at) if expires_at else None
    policies = [
        InlinePolicyCreate(
            name="max_per_tx",
            type=PolicyType.TRANSFER,
            rules={"max_per_tx": max_tx},
        )
    ]

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.create_delegation(
            operator_id=to,
            wallet_id=wallet_uuid,
            permissions=permissions_enum,
            policies=policies,
            expires_at=parsed_expires,
        )

    run_command(ctx, _operation)


@app.command("list")
def list_delegations(
    ctx: typer.Context,
    operator_id: str | None = typer.Option(
        None, "--operator-id", help="Filter by operator principal UUID."
    ),
    wallet_id: str | None = typer.Option(None, "--wallet-id", help="Filter by wallet UUID."),
    status: str | None = typer.Option(
        None, "--status", help="Filter by delegation status (e.g. active, revoked, frozen)."
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    offset: int = typer.Option(0, min=0, help="Number of results to skip for pagination."),
) -> None:
    """List delegations you have granted to operators (as the wallet owner)."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_delegations(
            operator_id=operator_id,
            wallet_id=wallet_id,
            status=status,
            limit=limit,
            offset=offset,
        )

    run_command(ctx, _operation)


@app.command("get")
def get_delegation(
    ctx: typer.Context,
    delegation_id: str = typer.Argument(..., help="Delegation UUID from 'caw delegation list'."),
) -> None:
    """Get full details for a delegation, including operator, permissions, and policies."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_delegation(delegation_id)

    run_command(ctx, _operation)


@app.command("update")
def update_delegation(
    ctx: typer.Context,
    delegation_id: str = typer.Argument(..., help="Delegation UUID from 'caw delegation list'."),
    max_tx: str | None = typer.Option(
        None, "--max-tx", help="New maximum amount (in USD) per transaction."
    ),
) -> None:
    """Update a delegation's per-transaction transfer limit."""

    async def _operation(client: WalletAPIClient) -> Any:
        from cobo_agentic_wallet_api.models.delegation_update import DelegationUpdate

        policies = None
        if max_tx is not None:
            policies = [
                InlinePolicyCreate(
                    name="max_per_tx",
                    type=PolicyType.TRANSFER,
                    rules={"max_per_tx": max_tx},
                )
            ]
        update = DelegationUpdate(policies=policies)
        return await client.update_delegation(delegation_id, update)

    run_command(ctx, _operation)


@app.command("revoke")
def revoke_delegation(
    ctx: typer.Context,
    delegation_id: str = typer.Argument(..., help="Delegation UUID from 'caw delegation list'."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Permanently revoke a delegation. The operator will immediately lose access to the wallet."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Revoke delegation {delegation_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "delegation_id": delegation_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.revoke_delegation(delegation_id)

    run_command(ctx, _operation)


@app.command("received")
def received_delegations(
    ctx: typer.Context,
    owner_id: str | None = typer.Option(None, "--owner-id", help="Filter by the owner's agent ID."),
    wallet_id: str | None = typer.Option(None, "--wallet-id", help="Filter by wallet UUID."),
    status: str | None = typer.Option(
        None, "--status", help="Filter by delegation status (e.g. active, revoked, frozen)."
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    offset: int = typer.Option(0, min=0, help="Number of results to skip for pagination."),
) -> None:
    """List delegations granted to you by wallet owners (as the operator)."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_received_delegations(
            owner_id=owner_id,
            wallet_id=wallet_id,
            status=status,
            limit=limit,
            offset=offset,
        )

    run_command(ctx, _operation)


def _apply_freeze(
    ctx: typer.Context,
    *,
    frozen: bool,
    scope: FreezeScope,
    owner_id: str | None,
    wallet_id: str | None,
    delegation_id: str | None,
    reason: str | None,
    yes: bool,
    dry_run: bool,
) -> None:
    """Shared implementation for freeze and unfreeze commands."""
    context = get_context(ctx)
    validate_scope_params(
        scope=scope,
        owner_id=owner_id,
        wallet_id=wallet_id,
        delegation_id=delegation_id,
    )
    verb = "Freeze" if frozen else "Unfreeze"

    async def _operation(client: WalletAPIClient) -> Any:
        resolved_owner_id = owner_id
        if scope == FreezeScope.OWNER and resolved_owner_id is None:
            resolved_owner_id = await infer_owner_id(client)
            if resolved_owner_id is None:
                raise RuntimeError(
                    "Unable to infer owner_id automatically. Pass --owner-id for --scope owner."
                )

        estimated: int | None = None
        if dry_run or not yes:
            estimated = await estimate_affected_count(
                client,
                scope=scope,
                delegation_id=delegation_id,
                wallet_id=wallet_id,
                frozen_state=frozen,
            )
        if dry_run:
            assert estimated is not None
            return {"dry_run": True, "scope": scope.value, "estimated_count": estimated}
        if not yes:
            confirmed = typer.confirm(f"{verb} {estimated} delegation(s)?", default=False)
            if not confirmed:
                return {"cancelled": True, "scope": scope.value, "estimated_count": estimated}

        if frozen:
            return await client.freeze_delegations(
                scope=SDKFreezeScope(scope.value),
                owner_id=resolved_owner_id,
                wallet_id=wallet_id,
                delegation_id=delegation_id,
                reason=reason,
            )
        return await client.unfreeze_delegations(
            scope=SDKFreezeScope(scope.value),
            owner_id=resolved_owner_id,
            wallet_id=wallet_id,
            delegation_id=delegation_id,
            reason=reason,
        )

    result = run_with_client(context, _operation)
    emit(result, context.output_format)


@app.command("freeze")
def freeze(
    ctx: typer.Context,
    scope: FreezeScope = typer.Option(
        ...,
        "--scope",
        case_sensitive=False,
        help="Scope of the freeze: 'owner' (all delegations for an owner), 'wallet' (all delegations for a wallet), or 'delegation' (a single delegation).",
    ),
    owner_id: str | None = typer.Option(
        None,
        "--owner-id",
        help="Owner's agent ID. Required for --scope owner unless it can be inferred from the API key.",
    ),
    wallet_id: str | None = typer.Option(
        None,
        "--wallet-id",
        help="Wallet UUID. Required for --scope wallet.",
    ),
    delegation_id: str | None = typer.Option(
        None,
        "--delegation-id",
        help="Delegation UUID. Required for --scope delegation.",
    ),
    reason: str | None = typer.Option(
        None, "--reason", help="Optional reason for the freeze, stored in the audit log."
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview how many delegations would be frozen without applying the change.",
    ),
) -> None:
    """Suspend delegations to halt operator activity.

    Frozen delegations block all further transfers and contract calls by the operator.
    Use 'caw delegation unfreeze' to resume access.
    """
    _apply_freeze(
        ctx,
        frozen=True,
        scope=scope,
        owner_id=owner_id,
        wallet_id=wallet_id,
        delegation_id=delegation_id,
        reason=reason,
        yes=yes,
        dry_run=dry_run,
    )


@app.command("unfreeze")
def unfreeze(
    ctx: typer.Context,
    scope: FreezeScope = typer.Option(
        ...,
        "--scope",
        case_sensitive=False,
        help="Scope of the unfreeze: 'owner' (all delegations for an owner), 'wallet' (all delegations for a wallet), or 'delegation' (a single delegation).",
    ),
    owner_id: str | None = typer.Option(
        None,
        "--owner-id",
        help="Owner's agent ID. Required for --scope owner unless it can be inferred from the API key.",
    ),
    wallet_id: str | None = typer.Option(
        None,
        "--wallet-id",
        help="Wallet UUID. Required for --scope wallet.",
    ),
    delegation_id: str | None = typer.Option(
        None,
        "--delegation-id",
        help="Delegation UUID. Required for --scope delegation.",
    ),
    reason: str | None = typer.Option(
        None, "--reason", help="Optional reason for the unfreeze, stored in the audit log."
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview how many delegations would be unfrozen without applying the change.",
    ),
) -> None:
    """Resume frozen delegations to restore operator access."""
    _apply_freeze(
        ctx,
        frozen=False,
        scope=scope,
        owner_id=owner_id,
        wallet_id=wallet_id,
        delegation_id=delegation_id,
        reason=reason,
        yes=yes,
        dry_run=dry_run,
    )
