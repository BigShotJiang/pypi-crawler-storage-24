"""Agent management commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import get_context
from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)

# Sub-group for API key management
apikey_app = typer.Typer(no_args_is_help=True, help="API key management")
app.add_typer(apikey_app, name="api-key")


@app.command("status")
def agent_status(
    ctx: typer.Context,
    agent_id: str | None = typer.Option(None, "--agent-id", help="Agent ID to inspect (required)."),
) -> None:
    """Get the status of an agent (e.g. active, temporary) and its onboarding session details."""

    async def _operation(client: WalletAPIClient) -> Any:
        if agent_id is None:
            raise typer.BadParameter("--agent-id is required")
        return await client.get_agent_status(agent_id=agent_id)

    run_command(ctx, _operation)


@app.command("list")
def list_agents(
    ctx: typer.Context,
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    offset: int = typer.Option(0, min=0, help="Number of results to skip for pagination."),
) -> None:
    """List agents owned by the current user."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_my_agents(limit=limit, offset=offset)

    run_command(ctx, _operation)


@apikey_app.command("create")
def create_api_key(
    ctx: typer.Context,
    name: str = typer.Option(..., "--name", help="Display name for the API key."),
    agent_id: str | None = typer.Option(
        None, "--agent-id", help="Agent ID to create the key for. Defaults to the current agent."
    ),
    scopes: str | None = typer.Option(None, "--scopes", help="Comma-separated API key scopes."),
    expires_at: str | None = typer.Option(
        None, "--expires-at", help="Expiration datetime (ISO 8601)."
    ),
) -> None:
    """Create a new API key for an agent. The key value is returned once and cannot be retrieved again."""
    from datetime import datetime as dt

    parsed_scopes = [s.strip() for s in scopes.split(",")] if scopes else None
    parsed_expires = dt.fromisoformat(expires_at) if expires_at else None

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.create_api_key(
            name=name,
            principal_id=agent_id,
            scopes=parsed_scopes,
            expires_at=parsed_expires,
        )

    run_command(ctx, _operation)


@apikey_app.command("list")
def list_api_keys(
    ctx: typer.Context,
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    offset: int = typer.Option(0, min=0, help="Number of results to skip for pagination."),
) -> None:
    """List API keys for an agent."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_api_keys(limit=limit, offset=offset)

    run_command(ctx, _operation)


@apikey_app.command("revoke")
def revoke_api_key(
    ctx: typer.Context,
    api_key_id: str = typer.Argument(..., help="API key ID from 'caw agent api-key list'."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Permanently revoke an API key. Any requests using the key will immediately start failing."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Revoke API key {api_key_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "api_key_id": api_key_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.revoke_api_key(api_key_id)

    run_command(ctx, _operation)
