"""caw fetch — end-to-end x402 payment-aware HTTP fetch."""

from __future__ import annotations

import json
import logging
from typing import Any

import typer

from cobo_agentic_wallet.cli._common import (
    CLIContext,
    get_context,
    make_client,
    resolve_wallet_uuid,
    run_async_operation,
)

logger = logging.getLogger("caw.fetch")

PAYMENT_REQUIRED_HEADER = "payment-required"
PAYMENT_SIGNATURE_HEADER = "Payment-Signature"


def _setup_logging(verbose: bool) -> None:
    """Configure logging for caw fetch. Only affects the caw.fetch logger."""
    level = logging.DEBUG if verbose else logging.WARNING
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    caw_logger = logging.getLogger("caw")
    caw_logger.setLevel(level)
    if not caw_logger.handlers:
        caw_logger.addHandler(handler)


def _log_request(method: str, url: str, headers: dict[str, str], data: str | None) -> None:
    """Log outgoing HTTP request details."""
    logger.debug(">>> %s %s", method, url)
    for k, v in headers.items():
        logger.debug(">>> %s: %s", k, v)
    if data:
        logger.debug(">>> Body: %s", data)


def _log_response(status: int, headers: dict[str, str], body: str) -> None:
    """Log incoming HTTP response details."""
    logger.debug("<<< %s", status)
    for k, v in headers.items():
        logger.debug("<<< %s: %s", k, v)
    if body:
        preview = body[:500] + ("..." if len(body) > 500 else "")
        logger.debug("<<< Body (%d chars): %s", len(body), preview)


async def _fetch(
    url: str,
    wallet_uuid: str,
    context: CLIContext,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    data: str | None = None,
    output_format: str = "body",
) -> dict[str, Any]:
    """Execute the fetch flow: request -> handle 402 -> retry with payment."""
    import aiohttp

    request_headers = dict(headers or {})
    request_kwargs: dict[str, Any] = {
        "headers": request_headers,
    }
    if data is not None:
        request_kwargs["data"] = data

    async with aiohttp.ClientSession() as session:
        # Step 1: initial request
        _log_request(method, url, request_headers, data)
        async with session.request(method, url, **request_kwargs) as resp:
            resp_headers = dict(resp.headers)
            body = await resp.text()
            _log_response(resp.status, resp_headers, body)

            if resp.status != 402:
                result: dict[str, Any] = {
                    "status": resp.status,
                    "body": body,
                }
                if output_format == "full":
                    result["headers"] = resp_headers
                return result

            # Step 2: 402 Payment Required — extract header
            payment_required_value = resp.headers.get(PAYMENT_REQUIRED_HEADER)
            if not payment_required_value:
                return {
                    "status": 402,
                    "error": "Server returned 402 but no PAYMENT-REQUIRED header found.",
                    "body": body,
                }

        # Step 3: call CAW backend x402-payment API
        logger.debug("Received 402 Payment Required, requesting payment signature...")
        logger.debug("PAYMENT-REQUIRED: %s", payment_required_value)

        client = make_client(context, api_key=context.api_key)
        try:
            payment_result = await client.x402_payment(
                wallet_uuid,
                payment_required=payment_required_value,
                auto_select=True,
                sync=True,
            )
        finally:
            await client.close()

        logger.debug("Payment API response: %s", payment_result)

        # Extract payment_signature_raw from result
        if isinstance(payment_result, dict):
            status = payment_result.get("status")
            payment_signature_raw = payment_result.get("payment_signature_raw")
        else:
            status = getattr(payment_result, "status", None)
            payment_signature_raw = getattr(payment_result, "payment_signature_raw", None)

        if not payment_signature_raw:
            return {
                "status": 402,
                "error": f"Payment signing did not complete. Status: {status}",
                "payment_result": payment_result
                if isinstance(payment_result, dict)
                else str(payment_result),
            }

        logger.debug("Payment signature obtained, retrying request...")

        # Step 4: retry with payment header
        request_headers[PAYMENT_SIGNATURE_HEADER] = payment_signature_raw
        _log_request(method, url, request_headers, data)
        async with aiohttp.ClientSession() as session:
            async with session.request(method, url, **request_kwargs) as resp:
                resp_headers = dict(resp.headers)
                body = await resp.text()
                _log_response(resp.status, resp_headers, body)
                result = {
                    "status": resp.status,
                    "body": body,
                }
                if output_format == "full":
                    result["headers"] = resp_headers
                return result


def fetch_command(
    ctx: typer.Context,
    url: str = typer.Argument(..., help="URL to fetch."),
    wallet_uuid: str | None = typer.Option(
        None,
        "--wallet",
        "-w",
        help="Wallet UUID. Falls back to the wallet_uuid in the config file.",
    ),
    method: str = typer.Option(
        "GET",
        "--method",
        "-X",
        help="HTTP method (GET, POST, PUT, PATCH, DELETE, etc.).",
    ),
    header: list[str] | None = typer.Option(
        None,
        "--header",
        "-H",
        help="Extra HTTP header in 'Key: Value' format. Can be repeated.",
    ),
    data: str | None = typer.Option(
        None,
        "--data",
        "-d",
        help="Request body data.",
    ),
    output: str = typer.Option(
        "body",
        "--output",
        "-o",
        help="Output mode: 'body' (default, print response body only) or 'full' (include status and headers).",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable debug output (request/response headers, body, payment details).",
    ),
) -> None:
    """Fetch a URL with automatic x402 payment handling.

    Sends an HTTP request to the URL. If the server returns HTTP 402 with a
    PAYMENT-REQUIRED header, automatically signs the payment via the CAW
    backend and retries the request with the Payment-Signature header.

    Examples:

        caw fetch https://api.example.com/data

        caw fetch https://api.example.com/data -X POST -d '{"key": "value"}'

        caw fetch https://api.example.com/data --output full

        caw fetch https://api.example.com/data -v
    """
    _setup_logging(verbose)

    from cobo_agentic_wallet.cli.commands.tx import _ensure_tss_node_online

    context = get_context(ctx)
    wallet_uuid_resolved = resolve_wallet_uuid(wallet_uuid)
    _ensure_tss_node_online(ctx, wallet_uuid_resolved)

    parsed_headers = _parse_headers(header)

    async def _operation() -> Any:
        return await _fetch(
            url,
            wallet_uuid_resolved,
            context,
            method=method.upper(),
            headers=parsed_headers,
            data=data,
            output_format=output,
        )

    result = run_async_operation(context, _operation)
    if result is not None:
        _emit_fetch_result(result, output)


def _parse_headers(header: list[str] | None) -> dict[str, str]:
    """Parse header arguments like 'Key: Value' into a dict."""
    if not header:
        return {}
    parsed: dict[str, str] = {}
    for h in header:
        if ":" not in h:
            typer.echo(f"Invalid header format (expected 'Key: Value'): {h}", err=True)
            raise typer.Exit(code=1)
        key, value = h.split(":", 1)
        parsed[key.strip()] = value.strip()
    return parsed


def _emit_fetch_result(result: dict[str, Any], output: str) -> None:
    """Output the fetch result based on the output mode."""
    if "error" in result:
        typer.echo(json.dumps(result, indent=2, ensure_ascii=False), err=True)
        raise typer.Exit(code=1)

    if output == "full":
        typer.echo(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        body = result.get("body", "")
        # Try to pretty-print JSON responses
        try:
            parsed = json.loads(body)
            typer.echo(json.dumps(parsed, indent=2, ensure_ascii=False))
        except (json.JSONDecodeError, TypeError):
            typer.echo(body)

    # Exit with non-zero if the final response was not 2xx
    status = result.get("status", 0)
    if not (200 <= status < 300):
        raise typer.Exit(code=1)
