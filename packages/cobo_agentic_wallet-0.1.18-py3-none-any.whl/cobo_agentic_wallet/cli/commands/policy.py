"""Policy management commands."""

from __future__ import annotations

import json
from typing import Any

import typer

from cobo_agentic_wallet.cli._common import get_context
from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.client import WalletAPIClient
from cobo_agentic_wallet_api.models.pending_operation_type import PendingOperationType
from cobo_agentic_wallet_api.models.policy_update import PolicyUpdate
from cobo_agentic_wallet_api.models.policy_scope import PolicyScope
from cobo_agentic_wallet_api.models.policy_type import PolicyType

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_policies(
    ctx: typer.Context,
    scope: str = typer.Option(
        "delegation",
        "--scope",
        "-s",
        help="Policy scope to list: 'global' (apply to all wallets), 'wallet' (apply to one wallet), or 'delegation' (apply to one delegation).",
    ),
    wallet_id: str | None = typer.Option(
        None,
        "--wallet-id",
        help="Filter by wallet UUID (use with --scope wallet or --scope delegation).",
    ),
    delegation_id: str | None = typer.Option(
        None, "--delegation-id", help="Filter by delegation UUID (use with --scope delegation)."
    ),
    wallet_type: str | None = typer.Option(None, "--wallet-type", help="Filter by wallet type."),
    include_inactive: bool = typer.Option(
        False, "--include-inactive", help="Include inactive policies."
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    offset: int = typer.Option(0, min=0, help="Number of results to skip for pagination."),
) -> None:
    """List policies filtered by scope (global, wallet, or delegation)."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_policies(
            scope=PolicyScope(scope),
            wallet_id=wallet_id,
            delegation_id=delegation_id,
            wallet_type=wallet_type,
            include_inactive=include_inactive if include_inactive else None,
            limit=limit,
            offset=offset,
        )

    run_command(ctx, _operation)


@app.command("get")
def get_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID from 'caw policy list'."),
) -> None:
    """Get full details for a policy, including its rules and current activation status."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_policy(policy_id)

    run_command(ctx, _operation)


@app.command("create")
def create_policy(
    ctx: typer.Context,
    scope: str = typer.Option(
        "delegation",
        "--scope",
        help="Policy scope: 'global' (all wallets), 'wallet' (requires --wallet-id), or 'delegation' (requires --delegation-id).",
    ),
    wallet_id: str | None = typer.Option(
        None, "--wallet-id", help="Wallet UUID. Required when --scope is 'wallet'."
    ),
    delegation_id: str | None = typer.Option(
        None, "--delegation-id", help="Delegation UUID. Required when --scope is 'delegation'."
    ),
    name: str = typer.Option(..., "--name", help="Display name for the policy."),
    policy_type: str = typer.Option(
        ..., "--type", help="Policy type: 'transfer' or 'contract_call'."
    ),
    rules: str = typer.Option(
        ..., "--rules", help='Policy rules as a JSON object (e.g. \'{"max_per_tx": "100"}\').'
    ),
    priority: int = typer.Option(
        0, "--priority", help="Evaluation priority. Higher values are evaluated first."
    ),
    is_active: bool = typer.Option(
        True,
        "--active/--inactive",
        help="Whether the policy is active on creation. Use --inactive to create it in a disabled state.",
    ),
) -> None:
    """Create a new transfer or contract call policy.

    Policies are evaluated before every transfer or contract call. If a policy denies the
    operation, a PolicyDeniedError is returned. Use 'caw policy dry-run' to test before creating.
    """

    async def _operation(client: WalletAPIClient) -> Any:
        parsed_rules = json.loads(rules)
        if not isinstance(parsed_rules, dict):
            raise ValueError("--rules must be a JSON object")

        scope_enum = PolicyScope(scope)
        type_enum = PolicyType(policy_type)
        if scope_enum == PolicyScope.GLOBAL and (wallet_id or delegation_id):
            raise ValueError("global scope does not accept --wallet-id or --delegation-id")
        if scope_enum == PolicyScope.WALLET:
            if not wallet_id:
                raise ValueError("wallet scope requires --wallet-id")
            if delegation_id:
                raise ValueError("wallet scope does not accept --delegation-id")
        if scope_enum == PolicyScope.DELEGATION:
            if not delegation_id:
                raise ValueError("delegation scope requires --delegation-id")
            if wallet_id:
                raise ValueError("delegation scope does not accept --wallet-id")

        return await client.create_policy(
            scope=scope_enum,
            delegation_id=delegation_id,
            wallet_id=wallet_id,
            name=name,
            wallet_type=type_enum,
            rules=parsed_rules,
            priority=priority,
            is_active=is_active,
        )

    run_command(ctx, _operation)


@app.command("update")
def update_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID from 'caw policy list'."),
    name: str | None = typer.Option(None, "--name", help="New display name for the policy."),
    rules: str | None = typer.Option(
        None, "--rules", help='New policy rules as a JSON object (e.g. \'{"max_per_tx": "200"}\').'
    ),
) -> None:
    """Update a policy's name or rules."""

    async def _operation(client: WalletAPIClient) -> Any:
        parsed_rules = json.loads(rules) if rules else None
        update = PolicyUpdate(name=name, rules=parsed_rules)
        return await client.update_policy(policy_id, update)

    run_command(ctx, _operation)


@app.command("deactivate")
def deactivate_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID from 'caw policy list'."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Deactivate a policy so it is no longer evaluated. The policy is retained and can be reactivated via the API."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Deactivate policy {policy_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "policy_id": policy_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.deactivate_policy(policy_id)

    run_command(ctx, _operation)


@app.command("dry-run")
def dry_run_policy(
    ctx: typer.Context,
    wallet_id: str = typer.Argument(..., help="Wallet UUID to evaluate policies against."),
    operation_type: str = typer.Option(
        ...,
        "--operation-type",
        "--action",
        help="Operation type to simulate: 'transfer' or 'contract_call'.",
    ),
    amount: str = typer.Option(..., "--amount", help="Amount to evaluate (e.g. '50')."),
    chain_id: str = typer.Option(..., "--chain-id", help="Chain ID for the simulated operation."),
    token_id: str | None = typer.Option(
        None, "--token-id", help="Token ID for the simulated operation."
    ),
    delegation_id: str | None = typer.Option(
        None, "--delegation-id", help="Evaluate policies for this specific delegation."
    ),
    dst_addr: str | None = typer.Option(
        None, "--dst-addr", help="Destination address (for --operation-type transfer)."
    ),
    contract_addr: str | None = typer.Option(
        None, "--contract-addr", help="Contract address (for --operation-type contract_call)."
    ),
    calldata: str | None = typer.Option(
        None, "--calldata", help="Hex-encoded calldata (for --operation-type contract_call)."
    ),
    principal_id: str | None = typer.Option(
        None, "--principal-id", help="Evaluate as this agent ID. Defaults to the caller."
    ),
) -> None:
    """Simulate policy evaluation for a transfer or contract call without submitting it.

    Returns whether the operation would be allowed or denied, and which policy matched.
    Useful for testing policy rules before applying them to live traffic.
    """

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.dry_run_policy(
            wallet_id=wallet_id,
            operation_type=PendingOperationType(operation_type),
            amount=amount,
            chain_id=chain_id,
            delegation_id=delegation_id,
            token_id=token_id,
            dst_addr=dst_addr,
            contract_addr=contract_addr,
            calldata=calldata,
            principal_id=principal_id,
        )

    run_command(ctx, _operation)
