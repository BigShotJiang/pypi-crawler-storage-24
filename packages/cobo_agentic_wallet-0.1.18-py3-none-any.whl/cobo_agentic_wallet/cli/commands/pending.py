"""Pending operation commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import get_context
from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_pending(
    ctx: typer.Context,
    include_executing: bool = typer.Option(
        False, "--include-executing", help="Include operations that are already executing."
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    offset: int = typer.Option(0, min=0, help="Number of results to skip for pagination."),
) -> None:
    """List operations that are awaiting manual approval (e.g. transfers above a policy threshold)."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_pending_operations(
            include_executing=include_executing, limit=limit, offset=offset
        )

    run_command(ctx, _operation)


@app.command("get")
def get_pending(
    ctx: typer.Context,
    operation_id: str = typer.Argument(..., help="Pending operation UUID from 'caw pending list'."),
) -> None:
    """Get the details of a pending operation, including the operation type, amount, and policy that triggered the hold."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_pending_operation(operation_id)

    run_command(ctx, _operation)


@app.command("approve")
def approve(
    ctx: typer.Context,
    operation_id: str = typer.Argument(..., help="Pending operation UUID from 'caw pending list'."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Approve a pending operation so it proceeds to execution."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Approve pending operation {operation_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "operation_id": operation_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.approve_pending_operation(operation_id)

    run_command(ctx, _operation)


@app.command("reject")
def reject(
    ctx: typer.Context,
    operation_id: str = typer.Argument(..., help="Pending operation UUID from 'caw pending list'."),
    reason: str | None = typer.Option(
        None, "--reason", help="Reason for rejection, stored in the audit log."
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Reject a pending operation. The operation is cancelled and not executed."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Reject pending operation {operation_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "operation_id": operation_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.reject_pending_operation(operation_id, reason=reason)

    run_command(ctx, _operation)
