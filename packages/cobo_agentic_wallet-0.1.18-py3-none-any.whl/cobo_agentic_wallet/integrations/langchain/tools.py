"""LangChain integration helpers for Cobo Agent Wallet tools."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field, create_model

from cobo_agentic_wallet.toolkit import AgentWalletToolkit, ToolDefinition, ToolHandler

EXPECTED_TOOL_NAMES: tuple[str, ...] = (
    "list_wallets",
    "get_balance",
    "transfer_tokens",
    "list_transactions",
    "get_audit_logs",
    "create_delegation",
)

# JSON Schema type → Python annotation mapping
_JSON_TYPE_MAP: dict[str, type] = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
    "object": dict,
    "array": list,
    "null": type(None),
}


def build_tool_handler_map(toolkit: AgentWalletToolkit) -> dict[str, ToolHandler]:
    """Build a name->handler map from framework-agnostic toolkit definitions."""

    handlers = {tool.name: tool.handler for tool in toolkit.get_tools()}
    expected = set(EXPECTED_TOOL_NAMES)
    found = set(handlers.keys())
    missing = expected - found
    extra = found - expected

    if missing or extra:
        details: list[str] = []
        if missing:
            details.append(f"missing={sorted(missing)}")
        if extra:
            details.append(f"extra={sorted(extra)}")
        raise RuntimeError("Tool surface mismatch for LangChain integration: " + ", ".join(details))

    return handlers


def format_denial_text(toolkit: AgentWalletToolkit, denial: Any) -> str:
    """Render a policy denial in a text format suitable for LLM self-correction."""

    return toolkit._format_denial(denial)


def _literal_annotation(values: list[Any]) -> Any:
    """Build a runtime Literal annotation from schema constants/enums."""

    return Literal.__getitem__(tuple(values))


def _json_schema_type_to_annotation(prop: dict[str, Any]) -> Any:
    """Map a JSON Schema property to a Python type annotation."""

    if "const" in prop:
        return _literal_annotation([prop["const"]])

    enum_values = prop.get("enum")
    if isinstance(enum_values, list) and enum_values:
        return _literal_annotation(enum_values)

    json_type = prop.get("type", "string")

    if isinstance(json_type, list):
        annotations = [_JSON_TYPE_MAP.get(item_type, Any) for item_type in json_type]
        annotation = annotations[0] if annotations else Any
        for next_annotation in annotations[1:]:
            annotation = annotation | next_annotation
        return annotation

    if json_type == "array":
        items_schema = prop.get("items")
        item_annotation = (
            _json_schema_type_to_annotation(items_schema) if isinstance(items_schema, dict) else Any
        )
        return list[item_annotation]

    if json_type == "object":
        additional = prop.get("additionalProperties")
        if isinstance(additional, dict):
            return dict[str, _json_schema_type_to_annotation(additional)]
        return dict[str, Any]

    return _JSON_TYPE_MAP.get(json_type, str)


def _field_constraints_from_json_schema(prop: dict[str, Any]) -> dict[str, Any]:
    """Translate common JSON Schema constraints to Pydantic Field kwargs."""

    kwargs: dict[str, Any] = {}

    description = prop.get("description")
    if isinstance(description, str) and description:
        kwargs["description"] = description

    if "minimum" in prop:
        kwargs["ge"] = prop["minimum"]
    if "maximum" in prop:
        kwargs["le"] = prop["maximum"]
    if "exclusiveMinimum" in prop:
        kwargs["gt"] = prop["exclusiveMinimum"]
    if "exclusiveMaximum" in prop:
        kwargs["lt"] = prop["exclusiveMaximum"]

    if "minLength" in prop:
        kwargs["min_length"] = prop["minLength"]
    if "maxLength" in prop:
        kwargs["max_length"] = prop["maxLength"]
    if "pattern" in prop:
        kwargs["pattern"] = prop["pattern"]

    # Pydantic uses min_length/max_length for sequences.
    if "minItems" in prop:
        kwargs["min_length"] = prop["minItems"]
    if "maxItems" in prop:
        kwargs["max_length"] = prop["maxItems"]

    return kwargs


def build_args_schema(tool_def: ToolDefinition) -> type:
    """Create a Pydantic v2 BaseModel from a ToolDefinition's JSON Schema parameters.

    The generated model is used as the ``args_schema`` for a LangChain
    ``StructuredTool``, giving it proper input validation and type hints.
    """

    properties = tool_def.parameters.get("properties", {})
    required_fields = set(tool_def.parameters.get("required", []))

    field_definitions: dict[str, Any] = {}
    for name, prop in properties.items():
        annotation = _json_schema_type_to_annotation(prop)
        field_kwargs = _field_constraints_from_json_schema(prop)

        if name in required_fields:
            field_definitions[name] = (annotation, Field(**field_kwargs))
        elif "default" in prop:
            field_definitions[name] = (annotation, Field(default=prop["default"], **field_kwargs))
        else:
            field_definitions[name] = (annotation | None, Field(default=None, **field_kwargs))

    model_name = "".join(part.capitalize() for part in tool_def.name.split("_")) + "Input"
    return create_model(model_name, **field_definitions)


__all__ = [
    "EXPECTED_TOOL_NAMES",
    "build_tool_handler_map",
    "format_denial_text",
    "build_args_schema",
]
