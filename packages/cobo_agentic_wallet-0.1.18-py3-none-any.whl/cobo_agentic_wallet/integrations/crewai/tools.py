"""CrewAI integration helpers for Cobo Agent Wallet tools."""

from __future__ import annotations

from typing import Any

from cobo_agentic_wallet.toolkit import AgentWalletToolkit, ToolHandler

EXPECTED_TOOL_NAMES: tuple[str, ...] = (
    "list_wallets",
    "get_balance",
    "transfer_tokens",
    "list_transactions",
    "get_audit_logs",
    "create_delegation",
)


def build_tool_handler_map(toolkit: AgentWalletToolkit) -> dict[str, ToolHandler]:
    """Build a name->handler map from framework-agnostic toolkit definitions."""

    handlers = {tool.name: tool.handler for tool in toolkit.get_tools()}
    expected = set(EXPECTED_TOOL_NAMES)
    found = set(handlers.keys())
    missing = expected - found
    extra = found - expected

    if missing or extra:
        details: list[str] = []
        if missing:
            details.append(f"missing={sorted(missing)}")
        if extra:
            details.append(f"extra={sorted(extra)}")
        raise RuntimeError("Tool surface mismatch for CrewAI integration: " + ", ".join(details))

    return handlers


def format_denial_text(toolkit: AgentWalletToolkit, denial: Any) -> str:
    """Render a policy denial in a text format suitable for LLM self-correction."""

    return toolkit._format_denial(denial)


__all__ = [
    "EXPECTED_TOOL_NAMES",
    "build_tool_handler_map",
    "format_denial_text",
]
