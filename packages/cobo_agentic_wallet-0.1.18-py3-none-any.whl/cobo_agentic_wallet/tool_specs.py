"""Canonical tool metadata shared by toolkit and MCP layers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ToolSpec:
    """Framework-agnostic tool metadata."""

    name: str
    description: str
    parameters: dict[str, Any]


_TOOL_SPECS: tuple[ToolSpec, ...] = (
    ToolSpec(
        name="list_wallets",
        description="List wallets accessible to the caller.",
        parameters={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "minimum": 1, "maximum": 200, "default": 50},
                "offset": {"type": "integer", "minimum": 0, "default": 0},
                "include_archived": {"type": "boolean", "default": False},
            },
            "additionalProperties": False,
        },
    ),
    ToolSpec(
        name="get_balance",
        description="Get wallet balances for a specific wallet.",
        parameters={
            "type": "object",
            "properties": {"wallet_uuid": {"type": "string"}},
            "required": ["wallet_uuid"],
            "additionalProperties": False,
        },
    ),
    ToolSpec(
        name="transfer_tokens",
        description="Transfer tokens to a destination address with policy enforcement.",
        parameters={
            "type": "object",
            "properties": {
                "wallet_uuid": {"type": "string"},
                "chain_id": {
                    "type": "string",
                    "description": "Chain identifier that must match the token's network exactly, e.g. ETH, SETH, BSC_BNB. Do NOT guess; obtain from list_supported_chains or wallet address info.",
                },
                "dst_addr": {"type": "string"},
                "token_id": {"type": "string"},
                "amount": {"type": "string"},
                "request_id": {"type": "string"},
                "fee": {"type": "object"},
            },
            "required": ["wallet_uuid", "chain_id", "dst_addr", "token_id", "amount"],
            "additionalProperties": False,
        },
    ),
    ToolSpec(
        name="list_transactions",
        description="List transactions for a wallet with optional status filter.",
        parameters={
            "type": "object",
            "properties": {
                "wallet_uuid": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 200, "default": 50},
                "offset": {"type": "integer", "minimum": 0, "default": 0},
                "status": {"type": "string"},
            },
            "required": ["wallet_uuid"],
            "additionalProperties": False,
        },
    ),
    ToolSpec(
        name="get_audit_logs",
        description="Query audit logs with filters and cursor pagination.",
        parameters={
            "type": "object",
            "properties": {
                "wallet_id": {"type": "string"},
                "principal_id": {"type": "string"},
                "action": {"type": "string"},
                "result": {"type": "string"},
                "start_time": {"type": "string", "format": "date-time"},
                "end_time": {"type": "string", "format": "date-time"},
                "cursor": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 200, "default": 50},
            },
            "additionalProperties": False,
        },
    ),
    ToolSpec(
        name="create_delegation",
        description="Create delegation granting an operator scoped wallet permissions.",
        parameters={
            "type": "object",
            "properties": {
                "operator_id": {"type": "string"},
                "wallet_id": {"type": "string"},
                "permissions": {"type": "array", "items": {"type": "string"}, "minItems": 1},
                "constraints": {"type": "object"},
                "expires_at": {"type": "string", "format": "date-time"},
            },
            "required": ["operator_id", "wallet_id", "permissions"],
            "additionalProperties": False,
        },
    ),
)

_TOOL_SPEC_BY_NAME = {spec.name: spec for spec in _TOOL_SPECS}


def list_tool_specs() -> tuple[ToolSpec, ...]:
    """Return all canonical tool metadata."""

    return _TOOL_SPECS


def get_tool_spec(name: str) -> ToolSpec:
    """Lookup metadata by tool name."""

    return _TOOL_SPEC_BY_NAME[name]
