from .base import LowercaseStrEnum


class Engine(LowercaseStrEnum):
    """Computational chemistry engine."""

    AIMNET2 = "aimnet2"
    MACE = "mace"  # Deprecated
    OMOL25 = "omol25"
    ORB = "orb"
    TBLITE = "tblite"
    XTB = "xtb"
    TERACHEM = "terachem"
    GPU4PYSCF = "gpu4pyscf"
    PYSCF = "pyscf"
    PSI4 = "psi4"
    OPENFF = "openff"
    EGRET = "egret"
