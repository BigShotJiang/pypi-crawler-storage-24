# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         19/12/2025 - 3:31 p. m.
# Project:      zb-django
# Module Name:  foreignkey_field
# Description: 
# ****************************************************************
from django.core import exceptions, checks
from django.db import router
from django.db.models import ForeignKey
from django.db.models.signals import post_save, post_delete
from django.utils.translation import gettext_lazy as _

from zibanu.django.state_machine.lib.classes.state_machine import ZBStateMachine
from zibanu.django.state_machine.lib.utils import get_auth_user
from zibanu.django.state_machine.models import StateLog


class ZBSMForeignKey(ForeignKey):

    def __init__(
            self,
            to,
            on_delete,
            related_name=None,
            related_query_name=None,
            limit_choices_to=None,
            parent_link=False,
            to_field=None,
            db_constraint=True,
            state_machine_uuid=None,
            state_machine_add_log=False,
            **kwargs,
    ):
        super().__init__(
            to,
            on_delete,
            related_name=related_name,
            related_query_name=related_query_name,
            limit_choices_to=limit_choices_to,
            parent_link=parent_link,
            to_field=to_field,
            db_constraint=db_constraint,
            **kwargs
        )
        self.state_machine_uuid = state_machine_uuid
        self.state_machine_add_log = state_machine_add_log
        self.instance_old = None
        self.field_state = None
        self.field_state_old = None

    def check(self, **kwargs):
        return [
            *super().check(**kwargs),
            *self._check_state_machine()
        ]

    def validate(self, value, model_instance):
        super().validate(value, model_instance)
        self.instance_old = self._get_instance(model_instance=model_instance)
        self.field_state = getattr(model_instance, self.name, None)
        if self.instance_old is not None:
            self.field_state_old = getattr(self.instance_old, self.name, None)
        self._check_transition(value)
        if self.state_machine_uuid is not None and self.state_machine_add_log:
            post_save.connect(self._signal_save_log, sender=self.model)
        else:
            post_save.disconnect(self._signal_save_log, sender=self.model)

    def _check_state_machine(self):
        if self.state_machine_uuid is not None:
            state_machine = ZBStateMachine(state_machine_uuid=self.state_machine_uuid)
            if self.state_machine_add_log:
                post_delete.connect(self._signal_delete_log, sender=self.model)
            else:
                post_delete.disconnect(self._signal_delete_log, sender=self.model)
            if state_machine.state_machine_instance is None:
                return [
                    checks.Warning(
                        msg=_("The specified state_machine uuid is not a valid value and there is no state machine."),
                        hint=_("Change the value of state_machine_uuid to a correct one."),
                        obj=self,
                    )
                ]
            else:
                return []
        else:
            return []

    def _check_transition(self, value):
        source_state_uuid = None
        state_machine = ZBStateMachine(state_machine_uuid=self.state_machine_uuid)
        if self.instance_old is None:
            target_state_uuid = self.field_state.uuid if self.field_state is not None else None
        else:
            source_state_uuid = self.field_state_old.uuid if self.field_state_old is not None else None
            target_state_uuid = self.field_state.uuid if self.field_state is not None else None
        if not state_machine.transition_validate(source_state_uuid=source_state_uuid,
                                                 target_state_uuid=target_state_uuid):
            raise exceptions.ValidationError(
                _("Invalid state change or does not have the necessary role."),
                code="invalid_transition",
                params={"value": value},
            )

    def _get_instance(self, model_instance):
        using_instance = router.db_for_read(self.model, instance=model_instance)
        instance = self.model._base_manager.using(using_instance).filter(**{"id": model_instance.id}).first()
        return instance

    def _signal_save_log(self, sender, instance, created, **kwargs):
        sm_user_id = None
        sm_remarks = ""
        if getattr(instance, "sm_user_id", False):
            sm_user_id = instance.sm_user_id
        if getattr(instance, "sm_remarks", False):
            sm_remarks = instance.sm_remarks
        target_state = getattr(instance, self.name, None)
        if created:
            source_state = None
        else:
            source_state = self.field_state_old
        log = StateLog(app_label=sender._meta.app_label, model_name=sender._meta.model_name,
                       object_id=instance.pk, source_state=source_state, target_state=target_state,
                       remarks=sm_remarks, user=get_auth_user(user_id=sm_user_id))
        log.save()
        post_save.disconnect(self._signal_save_log, sender=self.model)

    def _signal_delete_log(self, sender, instance, **kwargs):
        logs = StateLog.objects.filter(app_label=sender._meta.app_label, model_name=sender._meta.model_name,
                                       object_id=instance.pk)
        if logs.exists():
            logs.delete()
        post_delete.disconnect(self._signal_delete_log, sender=self.model)
