# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         19/12/2025 - 3:31 p. m.
# Project:      zb-django
# Module Name:  __init__.py
# Description: 
# ****************************************************************
from .foreignkey_field import ZBSMForeignKey
