# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         17/12/2025 - 11:50 a. m.
# Project:      zb-django
# Module Name:  transition
# Description: 
# ****************************************************************
from zibanu.django.db import models


class Transition(models.Manager):

    def get_by_state_machine(self, source_state_uuid, target_state_uuid, state_machine_uuid):
        return self.filter(source_state__uuid__exact=source_state_uuid, target_state__uuid__exact=target_state_uuid,
                           state_machine__uuid__exact=state_machine_uuid)
