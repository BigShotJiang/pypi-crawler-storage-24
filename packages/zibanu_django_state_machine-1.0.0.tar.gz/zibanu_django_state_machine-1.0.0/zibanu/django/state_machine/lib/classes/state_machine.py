# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         17/12/2025 - 11:01 a. m.
# Project:      zb-django
# Module Name:  state_machine
# Description: 
# ****************************************************************
from zibanu.django.lib import get_request_from_stack, get_user
from zibanu.django.state_machine.models import StateMachine


class ZBStateMachine:

    def __init__(self, state_machine_uuid):
        self.state_machine_uuid = state_machine_uuid
        self.state_machine_instance = StateMachine.objects.filter(uuid=state_machine_uuid).first()

    def transition_validate(self, source_state_uuid, target_state_uuid):
        validate = False
        if self.state_machine_instance is not None:
            transitions = self.state_machine_instance.transitions.filter(source_state__uuid=source_state_uuid,
                                                                         target_state__uuid=target_state_uuid,
                                                                         enabled=True)
            validate = transitions.exists()
            if validate:
                transition = transitions.first()
                if transition.groups.exists():
                    request = get_request_from_stack()
                    if request is not None:
                        user = get_user(request.user)
                        if user.is_authenticated:
                            if user.is_superuser:
                                validate = validate and True
                            else:
                                transition_groups = transition.groups.all().values_list('id', flat=True)
                                validate = validate and user.groups.filter(id__in=transition_groups).exists()
                        else:
                            validate = validate and False
        return validate

    def get_initial_states(self):
        initial_states = []
        if self.state_machine_instance is not None:
            initial_states = self.state_machine_instance.transitions.filter(is_initial=True).values_list(
                "target_state__uuid",
                flat=True)
        return initial_states
