# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         26/12/2025 - 11:28 a. m.
# Project:      zb-django
# Module Name:  get_auth_user
# Description: 
# ****************************************************************
from django.contrib.auth import get_user_model

from zibanu.django.lib import get_request_from_stack, get_user


def get_auth_user(user_id: int = None):
    user = None
    request = get_request_from_stack()
    if request is not None:
        if request.user is not None and request.user.is_authenticated:
            user = get_user(user=request.user)
    if user_id is not None:
        local_user = get_user_model().objects.filter(pk=user_id).first()
        if local_user is not None:
            user = local_user
    return user
