# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         29/12/2025 - 11:24 a. m.
# Project:      zb-django
# Module Name:  urls
# Description: 
# ****************************************************************
from django.urls import path

from zibanu.django.state_machine.api.services import StateMachineService, StateService

urlpatterns = [
    path("state-machine/summary/", StateMachineService.as_view({"post": "summary"}), name="state_machine_summary"),
    path("state-machine/get/", StateMachineService.as_view({"post": "retrieve"}), name="state_machine_get"),
    path("state/summary/", StateService.as_view({"post": "summary"}), name="state_summary"),
    path("state/next/", StateService.as_view({"post": "next_state"}), name="state_next_state"),
]
