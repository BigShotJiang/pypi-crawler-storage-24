# -*- coding: utf-8 -*-

#  Developed by CQ Inversiones SAS. Copyright ©. 2019-2025. All rights reserved.
#  Desarrollado por CQ Inversiones SAS. Copyright ©. 2019-2025. Todos los derechos reservados.

# ****************************************************************
# IDE:          PyCharm
# Developed by: macercha
# Date:         9/12/25
# Project:      Zibanu Django
# Module Name:  apps
# Description:
# ****************************************************************
import threading
from django.apps import AppConfig
from django.conf import settings
from django.utils.translation import gettext_lazy as _

class ZbDjangoStateMachine(AppConfig):
    """
    Class inherited from django.apps.AppConfig to define configuration of zibanu.django.state_machine app.
    """
    default_auto_field = "django.db.models.AutoField"
    name = "zibanu.django.state_machine"
    verbose_name = _("Zibanu Django State Machine")
    label = "zb_state_machine"
    is_ready = False

    def ready(self):
        """
        Overwrite method to personalize or load settings and signals for the application.

        Returns
        -------

        """
        th_ready = threading.Thread(target=self.after_ready, name="after ready event")
        th_ready.start()


    def after_ready(self):
        """
        After ready thread event to call signals factory, or all that you need.

        Returns
        -------
        None
        """
        self.is_ready = True