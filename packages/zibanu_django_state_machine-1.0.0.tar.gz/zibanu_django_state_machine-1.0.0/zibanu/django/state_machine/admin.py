# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         15/12/2025 - 11:11 a. m.
# Project:      zb-django
# Module Name:  admin
# Description: 
# ****************************************************************
from django.contrib import admin

from zibanu.django.state_machine.admin_views.state_log import StateLogAdmin
from zibanu.django.state_machine.admin_views.state_machine import StateMachineAdmin
from zibanu.django.state_machine.admin_views.transitions import TransitionAdmin
from zibanu.django.state_machine.models import StateMachine, Transition, StateMachineProxy, StateLog

admin.site.register(StateMachine, StateMachineAdmin)
admin.site.register(StateMachineProxy, TransitionAdmin)
admin.site.register(StateLog, StateLogAdmin)
