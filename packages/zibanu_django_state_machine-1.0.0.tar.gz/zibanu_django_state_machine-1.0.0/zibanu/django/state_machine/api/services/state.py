# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         29/12/2025 - 12:12 p. m.
# Project:      zb-django
# Module Name:  state
# Description: 
# ****************************************************************
from django.core.exceptions import ValidationError as CoreValidationError, ObjectDoesNotExist
from django.utils.translation import gettext_lazy as _
from rest_framework import status
from rest_framework.response import Response

from zibanu.django.lib import ErrorMessages
from zibanu.django.rest_framework.exceptions import APIException
from zibanu.django.rest_framework.viewsets import ModelViewSet
from zibanu.django.state_machine.api.serializers import StateSummarySerializer, StateSerializer
from zibanu.django.state_machine.models import State


class StateService(ModelViewSet):
    model = State
    permission_classes = []
    serializer_class = StateSerializer

    def summary(self, request, *args, **kwargs):
        self.serializer_class = StateSummarySerializer
        state_machine_uuid = request.data.get("state_machine_uuid", None)
        is_initial = request.data.get("is_initial", False)
        if state_machine_uuid is not None:
            kwargs["state_machine__uuid"] = state_machine_uuid
        if is_initial:
            kwargs["t_transition__is_initial"] = True
        return super()._list(request, *args, **kwargs)

    def next_state(self, request, *args, **kwargs):
        try:
            self.serializer_class = StateSummarySerializer
            data_return = []
            state_uuid = request.data.get("state_uuid", None)
            if state_uuid is None:
                raise APIException(detail={_("state_uuid"): _("This field is required.")},
                                   status_code=status.HTTP_406_NOT_ACCEPTABLE)
            state = State.objects.filter(uuid=state_uuid).get()
            if state is not None:
                data_return = state.next_states()
            status_return = status.HTTP_200_OK if len(data_return) > 0 else status.HTTP_204_NO_CONTENT
        except APIException:
            raise
        except ObjectDoesNotExist as exc:
            raise APIException(detail=ErrorMessages.NOT_FOUND, code="doest_not_exists",
                               status_code=status.HTTP_404_NOT_FOUND) from exc
        except CoreValidationError as exc:
            raise APIException(detail=exc.message_dict, status_code=status.HTTP_406_NOT_ACCEPTABLE) from exc
        except Exception as exc:
            raise APIException(detail=str(exc), code="not_controlled_exception",
                               status_code=status.HTTP_500_INTERNAL_SERVER_ERROR) from exc
        else:
            return Response(data=data_return, status=status_return)
