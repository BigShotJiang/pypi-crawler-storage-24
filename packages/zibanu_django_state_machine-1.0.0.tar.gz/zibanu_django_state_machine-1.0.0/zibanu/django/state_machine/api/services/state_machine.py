# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         29/12/2025 - 11:17 a. m.
# Project:      zb-django
# Module Name:  state_machine
# Description: 
# ****************************************************************
from django.core.exceptions import ObjectDoesNotExist, ValidationError as CoreValidationError
from rest_framework import status
from rest_framework.response import Response

from zibanu.django.lib import ErrorMessages
from zibanu.django.rest_framework.exceptions import APIException
from zibanu.django.rest_framework.viewsets import ModelViewSet
from zibanu.django.state_machine.api.serializers import StateMachineSummarySerializer, StateMachineSerializer
from zibanu.django.state_machine.models import StateMachine


class StateMachineService(ModelViewSet):
    model = StateMachine
    permission_classes = []
    serializer_class = StateMachineSerializer

    def summary(self, request, *args, **kwargs):
        self.serializer_class = StateMachineSummarySerializer
        return super()._list(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        try:
            uuid = request.data.get("uuid", None)
            if uuid is None:
                raise APIException(detail=ErrorMessages.FIELD_REQUIRED, code="required",
                                   status_code=status.HTTP_406_NOT_ACCEPTABLE)
            data_record = self.get_queryset(uuid=uuid).get()
            data_return = self.get_serializer(data_record).data
            status_return = status.HTTP_200_OK
        except APIException:
            raise
        except ObjectDoesNotExist as exc:
            raise APIException(detail=ErrorMessages.NOT_FOUND, code="doest_not_exists",
                               status_code=status.HTTP_404_NOT_FOUND) from exc
        except CoreValidationError as exc:
            raise APIException(detail=exc.message_dict, status_code=status.HTTP_406_NOT_ACCEPTABLE) from exc
        except Exception as exc:
            raise APIException(detail=str(exc), status_code=status.HTTP_500_INTERNAL_SERVER_ERROR) from exc
        else:
            return Response(status=status_return, data=data_return)
