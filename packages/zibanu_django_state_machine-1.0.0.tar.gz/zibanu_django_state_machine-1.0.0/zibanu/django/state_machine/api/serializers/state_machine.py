# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         29/12/2025 - 11:19 a. m.
# Project:      zb-django
# Module Name:  state_machine
# Description: 
# ****************************************************************
from zibanu.django.rest_framework import serializers
from zibanu.django.state_machine.api.serializers.state import StateSummarySerializer
from zibanu.django.state_machine.models import StateMachine


class StateMachineSerializer(serializers.ModelSerializer):
    states = StateSummarySerializer(read_only=True, many=True)

    class Meta:
        model = StateMachine
        fields = ["id", "name", "description", "uuid", "states"]


class StateMachineSummarySerializer(serializers.ModelSerializer):
    class Meta:
        model = StateMachine
        fields = ["id", "name", "uuid"]
