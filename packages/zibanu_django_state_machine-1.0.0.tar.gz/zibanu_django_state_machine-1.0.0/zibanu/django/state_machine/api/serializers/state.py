# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         29/12/2025 - 11:53 a. m.
# Project:      zb-django
# Module Name:  states
# Description: 
# ****************************************************************
from zibanu.django.rest_framework import serializers
from zibanu.django.state_machine.models import State


class StateSerializer(serializers.ModelSerializer):
    class Meta:
        model = State
        fields = "__all__"


class StateSummarySerializer(serializers.ModelSerializer):
    class Meta:
        model = State
        fields = ["id", "name", "uuid"]
