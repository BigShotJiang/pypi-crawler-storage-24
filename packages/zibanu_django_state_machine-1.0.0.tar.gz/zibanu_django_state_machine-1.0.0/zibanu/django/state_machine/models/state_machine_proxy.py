# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         15/12/2025 - 12:39 p. m.
# Project:      zb-django
# Module Name:  state_machine_proxy
# Description: 
# ****************************************************************
from django.utils.translation import gettext_lazy as _

from zibanu.django.state_machine.models import StateMachine


class StateMachineProxy(StateMachine):
    class Meta:
        proxy = True
        verbose_name = _("Transition")
        verbose_name_plural = _("Transitions")
