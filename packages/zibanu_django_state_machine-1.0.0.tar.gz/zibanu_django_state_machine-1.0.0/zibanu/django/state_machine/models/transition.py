# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         12/12/2025 - 11:40 a. m.
# Project:      zb-django
# Module Name:  transition
# Description: 
# ****************************************************************
from django.contrib.auth.models import Group
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

from zibanu.django.db import models
from zibanu.django.state_machine.lib import managers
from zibanu.django.state_machine.models import State, StateMachine


class Transition(models.Model):
    state_machine = models.ForeignKey(StateMachine, related_name="transitions", related_query_name="transition",
                                      on_delete=models.CASCADE, verbose_name=_("State Machine"))
    source_state = models.ForeignKey(State, null=True, blank=True, on_delete=models.PROTECT,
                                     related_name="s_transitions", related_query_name="s_transition",
                                     verbose_name=_("Source State"), help_text=_("Previous state"))
    target_state = models.ForeignKey(State, on_delete=models.PROTECT, related_name="t_transitions",
                                     related_query_name="t_transition", verbose_name=_("Target State"),
                                     help_text=_("New state"))
    is_initial = models.BooleanField(default=False, verbose_name=_("Is Initial transition"))
    is_final = models.BooleanField(default=False, verbose_name=_("Is Final transition"))
    notify = models.BooleanField(default=False, verbose_name=_("Notify Users"))
    task = models.CharField(max_length=150, null=True, blank=True, verbose_name=_("Task Name"))
    timeout = models.IntegerField(default=0, blank=False, null=False, verbose_name=_("Timeout (Seconds)"))
    enabled = models.BooleanField(default=True, verbose_name=_("Enabled"))
    groups = models.ManyToManyField(Group, related_name="transitions", related_query_name="transition",
                                    through="TransitionGroup", verbose_name=_("Groups"),
                                    help_text=_("Indicate the groups that have access to the transition."))

    objects = managers.Transition()

    class Meta:
        verbose_name = _("Transition")
        verbose_name_plural = _("Transitions")
        constraints = [
            models.UniqueConstraint(fields=["state_machine", "source_state", "target_state"],
                                    name="UNQ_state_machine_states"),
        ]

    def clean(self):
        if self.task == "":
            self.task = None
        if self.is_initial:
            if self.source_state is not None:
                raise ValidationError({_("from_state"): _("This field is not required.")})
        else:
            if self.source_state is None:
                raise ValidationError({_("from_state"): _("This field is required.")})
            if self.target_state is None:
                raise ValidationError({_("state"): _("This field is required.")})
