# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         12/12/2025 - 11:40 a. m.
# Project:      zb-django
# Module Name:  state
# Description: 
# ****************************************************************
import uuid

from django.db.models import F
from django.utils.translation import gettext_lazy as _

from zibanu.django.db import models
from zibanu.django.state_machine.lib.utils import get_auth_user
from zibanu.django.state_machine.models import StateMachine


class State(models.Model):
    state_machine = models.ForeignKey(StateMachine, on_delete=models.CASCADE, related_name="states",
                                      related_query_name="state", verbose_name=_("State Machine"))
    name = models.CharField(max_length=50, verbose_name=_("Name"), help_text=_("The name of the state."))
    description = models.TextField(null=True, blank=True, verbose_name=_("Description"),
                                   help_text=_("The description of the state"))
    uuid = models.CharField(max_length=255, unique=True, default=uuid.uuid4, verbose_name=_("UUID"),
                            help_text=_("The UUID of the state"))

    class Meta:
        verbose_name = _("State")
        verbose_name_plural = _("States")

    def __str__(self):
        return self.name

    def next_states(self, user_id=None):
        transitions = self.s_transitions.all()
        user = get_auth_user(user_id=user_id)
        if user is not None and not user.is_superuser:
            user_groups = user.groups.all()
            transitions = transitions.filter(groups__in=user_groups)
        return transitions.values(sid=F("target_state_id"), name=F("target_state__name"),
                                  uuid=F("target_state__uuid"))
