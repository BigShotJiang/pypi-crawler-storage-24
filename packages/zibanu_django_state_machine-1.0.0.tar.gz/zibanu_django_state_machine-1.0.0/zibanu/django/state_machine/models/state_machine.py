# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         12/12/2025 - 11:40 a. m.
# Project:      zb-django
# Module Name:  state_machine
# Description: 
# ****************************************************************
import uuid
from django.utils.translation import gettext_lazy as _

from zibanu.django.db import models


class StateMachine(models.Model):
    name = models.CharField(max_length=150, verbose_name=_("Name"), help_text=_("The name of the state machine."))
    description = models.TextField(null=True, blank=True, verbose_name=_("Description"),
                                   help_text=_("The description of the state machine."))
    uuid = models.CharField(max_length=255, unique=True, default=uuid.uuid4, verbose_name=_("UUID"),
                            help_text=_("The UUID of the state machine."))

    class Meta:
        verbose_name = _("State Machine")
        verbose_name_plural = _("State Machines")

    def __str__(self):
        return self.name
