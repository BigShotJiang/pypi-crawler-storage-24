# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         12/12/2025 - 11:41 a. m.
# Project:      zb-django
# Module Name:  transition_rol
# Description: 
# ****************************************************************
from django.contrib.auth.models import Group

from zibanu.django.db import models
from zibanu.django.state_machine.models import Transition


class TransitionGroup(models.Model):
    transition = models.ForeignKey(Transition, on_delete=models.CASCADE)
    group = models.ForeignKey(Group, on_delete=models.CASCADE)

    class Meta:
        verbose_name = "Transition Group"
        verbose_name_plural = "Transition Groups"
