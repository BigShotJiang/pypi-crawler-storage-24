# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         23/12/2025 - 6:18 p. m.
# Project:      zb-django
# Module Name:  log_state
# Description: 
# ****************************************************************
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _
from zibanu.django.db import models
from zibanu.django.state_machine.models import State


class StateLog(models.Model):
    app_label = models.CharField(max_length=255, verbose_name=_("App Label"))
    model_name = models.CharField(max_length=255, verbose_name=_("Model Name"))
    object_id = models.PositiveIntegerField(verbose_name=_("Object ID"))
    source_state = models.ForeignKey(State, null=True, blank=True, on_delete=models.CASCADE,
                                     verbose_name=_("Source State"), related_name="s_logs", related_query_name="s_log")
    target_state = models.ForeignKey(State, on_delete=models.CASCADE, verbose_name=_("Target State"),
                                     related_name="t_logs", related_query_name="t_log")
    user = models.ForeignKey(get_user_model(), null=True, blank=True, on_delete=models.CASCADE,
                             verbose_name=_("User"), related_name="logs", related_query_name="log",
                             db_constraint=False, )
    remarks = models.CharField(max_length=255, null=True, blank=True, verbose_name=_("Remarks"), default="")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_("Created At"))

    class Meta:
        verbose_name = _("State Log")
        verbose_name_plural = _("State Logs")
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["app_label", "model_name", "object_id"], name="IX_SL_label_model_object"),
            models.Index(fields=["app_label", "model_name", "target_state", "user"],
                         name="IX_SL_label_model_target_user"),
        ]
