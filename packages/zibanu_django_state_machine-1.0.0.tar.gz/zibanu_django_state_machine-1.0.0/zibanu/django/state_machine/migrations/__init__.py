# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         12/12/2025 - 3:30 p. m.
# Project:      zb-django
# Module Name:  __init__.py
# Description: 
# ****************************************************************
