# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         15/12/2025 - 12:26 p. m.
# Project:      zb-django
# Module Name:  transitions
# Description: 
# ****************************************************************
import importlib

from django import forms
from django.contrib import admin
from django.contrib.admin.widgets import FilteredSelectMultiple
from django.contrib.auth.models import Group
from django.utils.translation import gettext_lazy as _

from zibanu.django.state_machine.models import Transition


class TransitionForm(forms.ModelForm):
    groups = forms.ModelMultipleChoiceField(queryset=Group.objects.all(), required=False,
                                            widget=FilteredSelectMultiple(_("Groups"), is_stacked=False))
    task = forms.ChoiceField(required=False, label=_("Task"))

    class Meta:
        model = Transition
        fields = ["source_state", "target_state", "is_initial", "is_final", "notify", "task", "timeout", "enabled",
                  "groups"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        try:
            import celery
            celery_app = celery.current_app
            tasks = sorted(name for name in celery_app.tasks
                           if not name.startswith('celery.'))
            task_choices = (("", "---------"),) + tuple(zip(tasks, tasks))
        except ImportError as celery:
            task_choices = (("", "---------"),)

        self.fields['task'].choices = task_choices


class TransitionInlineAdmin(admin.StackedInline):
    model = Transition
    extra = 0
    min_num = 1
    form = TransitionForm
    parent = None

    def get_formset(self, request, obj=None, **kwargs):
        self.parent = obj
        return super().get_formset(request, obj, **kwargs)

    def get_field_queryset(self, db, db_field, request):
        if db_field.name == "source_state":
            return self.parent.states.all()
        if db_field.name == "target_state":
            return self.parent.states.all()
        return super().get_field_queryset(db, db_field, request)


class TransitionAdmin(admin.ModelAdmin):
    list_display = ["name", "uuid"]
    search_fields = ["name", "uuid"]
    exclude = ["name", "description", "uuid"]
    inlines = [TransitionInlineAdmin]

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
