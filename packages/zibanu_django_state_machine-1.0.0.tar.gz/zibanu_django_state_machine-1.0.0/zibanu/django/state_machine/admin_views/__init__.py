# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         15/12/2025 - 11:12 a. m.
# Project:      zb-django
# Module Name:  __init__.py
# Description: 
# ****************************************************************
