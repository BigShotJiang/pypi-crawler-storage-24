# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         15/12/2025 - 11:13 a. m.
# Project:      zb-django
# Module Name:  state
# Description: 
# ****************************************************************
from django.contrib import admin

from zibanu.django.state_machine.models import State


class StateInline(admin.StackedInline):
    model = State
    min_num = 1
    extra = 0
