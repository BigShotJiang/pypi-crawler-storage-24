# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         27/12/2025 - 11:14 a. m.
# Project:      zb-django
# Module Name:  state_log
# Description: 
# ****************************************************************
from django.contrib import admin
from django.utils.translation import gettext_lazy as _


class StateLogAdmin(admin.ModelAdmin):
    list_display = ["app_label", "model_name", "object_id", "source_state", "target_state", "get_user", "created_at"]
    list_display_links = None
    search_fields = ["app_label", "model_name", "object_id"]
    list_filter = ["created_at", "app_label", "model_name"]
    ordering = ["app_label", "model_name", "object_id"]

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def get_user(self, obj):
        return obj.user.email if obj.user else None

    get_user.short_description = _("user")
    get_user.admin_order_field = "user__email"
