# ****************************************************************
# IDE:          PyCharm
# Developed by: "Jhony Alexander Gonzalez Cordoba"
# Date:         15/12/2025 - 11:13 a. m.
# Project:      zb-django
# Module Name:  state_machine
# Description: 
# ****************************************************************
from django.contrib import admin

from zibanu.django.state_machine.admin_views.state import StateInline
from zibanu.django.state_machine.models import StateMachine


class StateMachineAdmin(admin.ModelAdmin):
    list_display = ["name", "uuid"]
    search_fields = ["name", "uuid"]
    inlines = [StateInline]
