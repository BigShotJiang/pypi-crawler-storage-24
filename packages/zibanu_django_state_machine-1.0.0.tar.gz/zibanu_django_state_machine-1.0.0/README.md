# Zibanu Django State Machine
*zibanu.django.state_machine*

`zibanu.django.state_machine` is a Django application that provides a reusable state machine system for Zibanu Django projects.

It includes database models, Django admin integration, API endpoints, and helper modules to define workflows based on states and transitions. It can be used to model business processes such as document approval, order lifecycle, request validation, or any other entity that moves through a controlled sequence of states.

## Installation
Install the package with `pip`:

bash pip install zibanu-django-state-machine


## Dependencies
This package is intended to be used together with the Zibanu Django base package.

## Getting started
Add the application to `INSTALLED_APPS` in your Django settings:

INSTALLED_APPS += ["zibanu.django.state_machine"] 

If you want to expose the built-in API endpoints, include the package URLs in your project URL configuration.

## Package structure
The application is organized into the following modules and subpackages.

### Main application
* `zibanu.django.state_machine`

Main Django application package for the state machine system.

### Models
* `zibanu.django.state_machine.models`

Contains the core models used by the package:

* `StateMachine`
* `State`
* `Transition`
* `TransitionGroup`
* `StateMachineProxy`
* `StateLog`

These models define the workflow structure and allow transitions and history tracking across states.

### Admin
* `zibanu.django.state_machine.admin`

Registers the main models in the Django admin site.

### Admin views
* `zibanu.django.state_machine.admin_views`

Contains the custom admin classes used to manage state machine components.

Available modules:

* `state`
* `state_log`
* `state_machine`
* `transitions`

### API
* `zibanu.django.state_machine.api`

Namespace for API-related components.

#### Serializers
* `zibanu.django.state_machine.api.serializers`

Serialization layer for API operations.

Available modules:

* `state`
* `state_machine`

#### Services
* `zibanu.django.state_machine.api.services`

Service and view layer used to expose package functionality through HTTP endpoints.

Available modules:

* `state`
* `state_machine`

### Internal library
* `zibanu.django.state_machine.lib`

Internal helper package used by the application.

#### Classes
* `zibanu.django.state_machine.lib.classes`

Support classes related to state machine logic.

#### Fields
* `zibanu.django.state_machine.lib.fields`

Custom model field helpers.

Available modules:

* `foreignkey_field`

#### Managers
* `zibanu.django.state_machine.lib.managers`

Custom managers and queryset helpers.

Available modules:

* `transition`

#### Utils
* `zibanu.django.state_machine.lib.utils`

Utility functions used internally by the package.

Available modules:

* `get_auth_user`

### Migrations
* `zibanu.django.state_machine.migrations`

Contains the Django migration files for the package models.

### Localization
* `zibanu.django.state_machine.locale`

Translation resources for the application.

## Available API endpoints
The package provides the following endpoints:

* `state-machine/summary/`
* `state-machine/get/`
* `state/summary/`
* `state/next/`


