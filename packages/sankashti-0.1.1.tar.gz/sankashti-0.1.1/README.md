# Sankashti Python Module

A lightweight Python module to calculate **Sankashti Chaturthi** dates using astronomical calculations.

Sankashti Chaturthi is a sacred day dedicated to **Lord Ganesha**, observed on the **fourth lunar day (Krishna Paksha Chaturthi)** after the full moon.
This module determines Sankashti based on **moonrise and tithi calculations**.

## Installation

Install the module from PyPI:

```bash
pip install sankashti
```

## Usage

Once installed, you can simply import the module in Python:

```python
import sankashti

# Find the next Sankashti Chaturthi
print(sankashti.next_sankashti())

# Check if a specific date is Sankashti
print(sankashti.is_sankashti("2026-03-07"))

# Get all Sankashti dates for a given year
print(sankashti.sankashti_year(2026))
```

Example output:

```
{
 "date": "2026-03-07",
 "days_until": 5,
 "about": "Sankashti Chaturthi dedicated to Lord Ganesha"
}
```

## Features

* Accurate Sankashti detection using **tithi calculations**
* Moonrise-based validation
* Simple Python API
* Works for past and future dates
* Lightweight and easy to integrate into applications

## Example

```python
import sankashti

dates = sankashti.sankashti_year(2026)

for d in dates:
    print(d)
```

## Use Cases

This module can be used for:

* Hindu calendar applications
* Panchang software
* Devotional reminder apps
* Astronomy-based calendar calculations
* Educational or research tools

## Author

Developed and maintained by **Hari Prajwal** ❤️
