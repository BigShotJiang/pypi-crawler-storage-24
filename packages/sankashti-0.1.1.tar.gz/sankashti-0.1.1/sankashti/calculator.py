from datetime import datetime, timedelta, date
import pytz

from .astronomy import get_tithi, get_moonrise, jd_to_datetime

IST = pytz.timezone("Asia/Kolkata")

SANKASHTI_TITHI = 19
ABOUT_TEXT = (
    "Sankashti Chaturthi is a sacred day dedicated to Lord Ganesha, "
    "observed on the fourth lunar day (Krishna Paksha Chaturthi) "
    "after the full moon."
)


def _normalize_date(d):
    """
    Convert input into a Python date object.

    Accepts:
    - YYYY-MM-DD string
    - datetime
    - date
    """
    if isinstance(d, str):
        return datetime.fromisoformat(d).date()

    if isinstance(d, datetime):
        return d.date()

    if isinstance(d, date):
        return d

    raise ValueError("Date must be a string (YYYY-MM-DD), datetime, or date object")


def is_sankashti(d) -> bool:
    """
    Check whether a given date is Sankashti Chaturthi.

    Parameters
    ----------
    d : str | datetime | date

    Returns
    -------
    bool
        True if the date corresponds to Sankashti Chaturthi.
    """

    d = _normalize_date(d)

    moonrise_jd = get_moonrise(d)
    moonrise_dt = jd_to_datetime(moonrise_jd)

    tithi = get_tithi(moonrise_dt)

    return tithi == SANKASHTI_TITHI


def next_sankashti():
    """
    Find the next upcoming Sankashti Chaturthi.
    """

    today = datetime.now(IST).date()

    for i in range(40):
        check_date = today + timedelta(days=i)

        if is_sankashti(check_date):
            return {
                "date": check_date.isoformat(),
                "days_until": (check_date - today).days,
                "about": ABOUT_TEXT,
            }

    return None


def sankashti_year(year: int):
    """
    Get all Sankashti Chaturthi dates for a given year.
    """

    results = []

    current = date(year, 1, 1)
    end = date(year, 12, 31)

    while current <= end:

        if is_sankashti(current):
            results.append(
                {
                    "date": current.isoformat(),
                    "about": ABOUT_TEXT,
                }
            )

        current += timedelta(days=1)

    return results