# krait-k8s

K8s offensive security scanner by SpotterSec.

Coming soon. See [spottersec.com](https://spottersec.com).
