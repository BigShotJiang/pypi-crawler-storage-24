"""pqdc governance toolkit — install and manage all pq* developer tools

Namespace reserved by Piqued AI, LLC — https://pqdc.dev/pqdc
"""
__version__ = "0.0.1"
