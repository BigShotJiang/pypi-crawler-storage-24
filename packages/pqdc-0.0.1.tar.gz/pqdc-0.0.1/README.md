# pqdc

> pqdc governance toolkit — install and manage all pq* developer tools

**Namespace reserved by [Piqued AI, LLC](https://piqued-ai.com).**

Part of the [pqdc governance toolkit](https://pqdc.dev).
