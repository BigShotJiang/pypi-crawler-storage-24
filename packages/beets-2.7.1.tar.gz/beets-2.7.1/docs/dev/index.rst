For Developers
==============

This section contains information for developers. Read on if you're interested
in hacking beets itself or creating plugins for it.

See also the documentation for the MediaFile_ and Confuse_ libraries. These are
maintained by the beets team and used to read and write metadata tags and manage
configuration files, respectively.

.. _confuse: https://confuse.readthedocs.io/en/latest/

.. _mediafile: https://mediafile.readthedocs.io/en/latest/

.. toctree::
    :maxdepth: 3
    :titlesonly:

    plugins/index
    library
    paths
    importer
    cli
    ../api/index
