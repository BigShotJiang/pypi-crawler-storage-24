from collections import deque
import datetime as dt
from pathlib import Path
import re
from typing import Literal

import numpy as np
import numpy.typing as npt
import pandas as pd
from pybaselines import Baseline
from scipy.signal import find_peaks

SAMPLING_RATE: float = 12.5

def read_perkin_elmer(filepath: Path|str
                      )-> tuple[npt.NDArray[np.timedelta64],npt.NDArray[np.float64]] | None:
    """
    Read chromatogram of given path, perform baseline correction to return a corrected
    chromatogram.

    Parameters
    ----------
    filepath : Path or str
        Full path of the location of the chromatogram file.

    Returns
    -------
    time : 1D-ndarray of np.datetime64
        Time vector of chromatogram as array of np.datetime64.
    chromatogram : 1D-ndarray
        Corrected chromatogram.

    """
    n_header: int = 47
    n_footer: int = 530
    # start_time: dt.datetime = dt.datetime(1970, 1, 1)
    # start_time: dt.datetime = dt.datetime(year=1970, month=1, day=1)
    start_time = np.datetime64("1970-01-01")

    # Get information for chromatogram
    with open(filepath, 'r', encoding='utf-8') as file:
        footer = deque(file, maxlen=n_footer)

    sampling_info: str
    sampling_rate: float | bool = False
    for idx, line in enumerate(footer):
        if line.startswith('\"RATE\"'):
            sampling_info = footer[idx+2]
            sampling_rate = float(sampling_info.split('\"')[1])
    if not sampling_rate:
        print("Sampling rate not found in chromatogram!")
        global SAMPLING_RATE
        SAMPLING_RATE = sampling_rate
        print(f"Sampling rate to standard value of {sampling_rate:.1f}.")

    df_data: pd.DataFrame = pd.read_csv(filepath,
                                        engine='python',
                                        skiprows=n_header,
                                        skipfooter=n_footer)
    chromatogram: npt.NDArray[np.float64] = df_data.values[:, 0]
    samples: npt.NDArray[np.int64] = np.arange(chromatogram.shape[0])
    time: npt.NDArray[np.timedelta64] = start_time + samples * np.timedelta64(int(1e3 / sampling_rate), "ms")
    baseline_fitter = Baseline(time)
    baseline: npt.NDArray[np.float64] = baseline_fitter.asls(
        chromatogram,
        lam=1e6,  # smoothness 1e5 - 1e7 (higher = smoother baseline)
        p=0.001  # asymmetry 0.0001 - 0.01 (smaller = ignore peaks more)
    )[0]
    chromatogram_corrected: npt.NDArray[np.float64] = chromatogram - baseline

    return time, chromatogram_corrected


def strtime2dt(strtime: str) -> dt.datetime:
    """
    Conversion from stringtime to datetime.

    Parameters
    ----------
    strtime : str
        Time in form '%M:%S', '%M:%S.%f' or '%M:%S:%f'.

    Returns
    -------
    datetime : dt.datetime

    """
    start_time: dt.datetime = dt.datetime(year=1970, month=1, day=1)

    pattern = r"(\d+):(\d+)(?:[:.](\d{1,3}))?"
    match = re.split(pattern, strtime)
    if match:
        minutes = int(match[1])
        seconds = int(match[2])
        ms_str = match[3] if match[3] else "0"
        milliseconds = int(ms_str.ljust(3, '0')[:3])
        datetime: dt.datetime = start_time + dt.timedelta(minutes=minutes,
                                                          seconds=seconds,
                                                          milliseconds=milliseconds)
        return datetime
    else:
        print("Invalid time format")
        return start_time


def strtime2int(strtime: str) -> int:
    """
    Conversion from stringtime to datetime.

    Parameters
    ----------
    strtime : str
        Time in form '%M:%S', '%M:%S.%f' or '%M:%S:%f'.

    Returns
    -------
    index : int

    """
    pattern: str = r"(\d+):(\d+)(?:\.(\d{1,3}))?"
    match = re.split(pattern, strtime)
    if match:
        minutes = int(match[1])
        seconds = int(match[2])
        ms_str = match[3] if match[3] else "0"
        milliseconds = int(ms_str.ljust(3, '0')[:3])
        index = int(round((minutes * 60 * SAMPLING_RATE) + (seconds * SAMPLING_RATE) +
                          milliseconds))
        return index
    else:
        print("Invalid time format.")
        return 0


def int2dt(index: float) -> dt.datetime:
    """
    Conversion from index to datetime.

    Parameters
    ----------
    index : float
        Index of measurement in chromatogram.

    Returns
    -------
    datetime : dt.datetime
        Time as datetime object

    """
    start_time: dt.datetime = dt.datetime(1970, 1, 1)

    seconds, remainder = map(float, divmod(index, SAMPLING_RATE))
    milliseconds = int(remainder * 1000 / SAMPLING_RATE)
    minutes, seconds = map(int, divmod(seconds, 60))
    datetime: dt.datetime = start_time + dt.timedelta(minutes=minutes, seconds=seconds,
                                                      milliseconds=milliseconds)
    return datetime


def int2strtime(index: float) -> str:
    """
    Conversion from index to stringtime.

    Parameters
    ----------
    index : float
        Point of measurement in chromatogram.

    Returns
    -------
    strtime : str
        Time as string in form '%M:%S.f' like'4:30', '4:30.300'.

    """
    seconds, remainder = map(float, divmod(index, SAMPLING_RATE))
    milliseconds = int(remainder * 1000 / SAMPLING_RATE)
    minutes, seconds = map(int, divmod(seconds, 60))
    return f'{minutes}:{seconds:02d}.{milliseconds:03d}'


def list_peaks(chromatogram: npt.NDArray[np.float64],
               limit_left: str|int|None=None,
               limit_right: str|int|None=None,
               min_height: float = 2500,
               min_distance: float = 25,
               min_width: float = 5,
               return_type: Literal['int', 'time'] = 'int') -> list[int] | list[str]:
    """
    Find peaks in chromatogram and optionally return only those from a given range.

    Parameters
    ----------
    chromatogram: 1-D ndarray
        Chromatogram to find peaks within.
    limit_left : str or int or None, default = None
        Left limit for filtering peaks in chromatogram. If it is not None, point in
        chromatogram can be given as stringtime '4:30', '4:30.300' or index
    limit_right : str or int or None, default = None
        Right limit for filtering peaks in chromatogram. If it is not None, point in
        chromatogram can be given as stringtime '4:30', '4:30.300' or index value.
    min_height : float, default = 2500
        Minimum height of a peak for filtering peaks based on their height.
    min_distance : float, default = 25
        Minimum distance between two peaks for filtering by the distance between those.
    min_width : float, default = 5
        Minimum width of a peak for filtering.
    return_type : str or int, default = int
        Select if the peaks should be returned as index or stringtime

    Returns
    -------
    peaks : list of str or int
        List of found peaks, either as stringtime '4:30' or '4:30.300' or index value.
    """
    #TODO: only 
    peaks: list[int] = find_peaks(chromatogram,
                                  height=min_height,
                                  distance=min_distance,
                                  width=min_width)[0]

    if type(limit_left) == str and type(limit_right) == str:
        limit_left_int: int = strtime2int(limit_left)
        limit_right_int: int = strtime2int(limit_right)
        peaks = [peak for peak in peaks if limit_left_int <= peak <= limit_right_int]
    if type(limit_left) == int and type(limit_right) == int:
        peaks = [peak for peak in peaks if limit_left <= peak <= limit_right]

    if return_type == 'time':
        peaks_strtime: list[str] = []
        for peak in peaks:
            peaks_strtime.append(int2strtime(peak))
        return peaks_strtime
    else:
        return peaks


def integrate_peak(chromatogram: npt.NDArray[np.float64],
                   timepoint: int|str,
                   min_height: float=2500,
                   min_distance: float=25,
                   min_width: float=5,
                   wlen: int=30,
                   output_limit: bool=False
                   ) -> float|tuple[float, float, float]|None:
    """
    Integrate peak in chromatogram with automized window length adaption. Default
    settings for peak finding are set for gc with a good signal.

    Parameters
    ----------
    chromatogram : 1-D ndarray
        Chromatogram with peak.
    timepoint : str or int
        Point in chromatogram, where the peak is located. This point can differ from
        the exact location of the peak but must be inside the integration limits to
        work. Can be specified either as stringtime '4:30' or '4:30.300' or index value.
    min_height : float, default = 2500
        Minimum height of peak.
    min_distance : float, optional
        Minimum distance between two peaks.
    min_width: float, default = 5
        Minimum width of peak. If lower, peak is getting ignored as noise.
    wlen : int, default = 30
        Maximum window length for selection of integration limits.
    output_limit : bool, default = False
        Choose to output the limits of the integration of not.

    Returns
    -------
    peak_area : float
        Integrated area of peak.
    left_lim : float, optional
        Left integration limit.
    right_lim : float, optional
        Right integration limit.

    """
    if type(timepoint) == str:
        peak_select = strtime2int(timepoint)
    elif type(timepoint) == int or np.int64:
        peak_select = int(timepoint)
    else:
        print('Wrong input for timepoint. Use stringtime or int.')
        return None

    idx: int = 0
    while True:
        peaks, props = find_peaks(chromatogram,
                                  height=min_height,
                                  distance=min_distance,
                                  width=min_width,
                                  wlen=wlen)

        left_lims: npt.NDArray[np.int64] = props['left_bases']
        right_lims: npt.NDArray[np.int64] = props['right_bases']

        # Get limits for selected peak
        left_lim: int = 0
        right_lim: int = 0
        peak_matches: bool = False
        for left_lim, right_lim in zip(left_lims, right_lims):
            if left_lim < peak_select < right_lim:
                peak_matches = True
                break
        if not peak_matches:
            print(f"Timepoint {peak_select} or {int2strtime(peak_select)} not inside a"
                  f"peak. Try again with an adapted timepoint")

        limit_derivative: int = 100
        derivative_chromatogram: npt.NDArray[np.float64] = np.gradient(chromatogram)

        # Check for multiple peaks in integration range
        peaks_in_range: int = 0
        for peak in peaks:
            if left_lim < peak < right_lim:
                peaks_in_range += 1

        # Check if window for peak is 1. too wide: multiple peaks in window, 2. baseline
        # reached: derivative low, 3. baseline not reached but change of sign: saddle
        # point between two peaks 4. to narrow: derivative still high
        if peaks_in_range > 1:
            wlen -= 10
            idx += 1
            print("Narrowing integration limits to only integrate one peak.")
            if wlen < 20:
                print("Warning: Narrow window length.")
            if idx == 15:
                print(f"No good limits found: {left_lim}, {right_lim}")
                break
        elif (derivative_chromatogram[left_lim - 1] *
              derivative_chromatogram[left_lim + 1] < 0 and
              derivative_chromatogram[right_lim - 1] *
              derivative_chromatogram[right_lim + 1] < 0):
            break
        elif limit_derivative > abs(derivative_chromatogram[left_lim]) and \
                limit_derivative > abs(derivative_chromatogram[right_lim]):
            break
        else:
            # Derivative still high, end of peak not reached
            wlen += 10
            idx += 1
            if wlen > 200:
                print("Warning: Wide window length.")
            if idx == 15:
                print(f"No good limits found: {left_lim}, {right_lim}")

    area_peak: float = float(np.trapezoid(chromatogram[left_lim:right_lim]))
    if output_limit:
        return area_peak, left_lim, right_lim
    else:
        return area_peak


def integrate_peak_range(chromatogram: npt.NDArray[np.float64],
                    left_lim: str,
                    right_lim: str,
                    ) -> float:
    """
    Integrate all the peaks inside a given range of a chromatogram.

    Parameters
    ----------
    chromatogram : 1-D ndarray
        Chromatogram with peak(s) for integration.
    left_lim : str or float
        Left integration limit.
    right_lim : str or float
        Right integration limit.

    Returns
    -------
    area : float
        Sum of all peak areas inside the give range of the chromatogram.

    """
    peaks: list[int] = list_peaks(chromatogram, left_lim, right_lim)
    areas: list[float] = []
    for peak in peaks:
        area = integrate_peak(chromatogram, peak)
        areas.append(area)
    return sum(areas)
