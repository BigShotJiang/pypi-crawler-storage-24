from math import pi, log, sqrt
from typing import Final
import numpy as np
from .substances import Solvent, Solid

SEC_PER_MIN: Final[int] = 60  # s/min
ML_PER_M3: Final[float] = 1e6  # ml/m^3
INCH_TO_METER: Final[float] = 0.0254  # m/inch
RE_LAM_LIM: Final[int] = 2300  # -
DIFFUSION_LIQUID: Final[float] = 1e-9  # m^2/s

#NOTE: Interpolation values for twisting Bodenstein num calculation
dean_values: list[int] = [1, 2, 3, 10, 20, 30, 40, 50]
y_axis_values: list[float] = [30, 16, 14, 11, 10.5, 10, 9, 8]


class Reactor:
    def __init__(self,
                 inner_diameter_mm: float,
                 outer_diameter_inch: float,
                 length: float = 0.
                 ) -> None:
        """
        Reactor dimensions for later calculations.
        
        Parameters
        ----------

        inner_diameter_mm : float
            Internal reactor diameter in millimeter.
        outer_diameter_inch : float
            Outer reactor diameter in inch (1/16 or 1/8).
        length : float, optional
            Length of reactor in m. Not needed if length is getting calculated.
        """
        self.flow_rate: float | None = None
        self.velocity: float | None = None
        self.tau: float | None = None
        self.reynolds_num: float | None = None
        self.diffusion_axial: float | None = None
        self.bodenstein_num: float | None = None
        self.diffusion_axial_twisted: float | None = None
        self.bodenstein_num_twisted: float | None = None
        self.inner_diameter: float = inner_diameter_mm / 1e3
        self.outer_diameter: float = outer_diameter_inch * INCH_TO_METER
        self.length: float = length
        self.area: float = pi * self.inner_diameter * length
        self.cross_section_area: float = pi / 4 * self.inner_diameter**2


    def __str__(self) -> str:
        return (f"Reactor with an inner diameter of {self.inner_diameter * 1e3:.2f} mm,"
                f" outer diamter of {self.outer_diameter * 1e3:.2f} mm and a length of "
                f"{self.length:.2f} m")

    def bodenstein(self,
                   flow_rate_mlmin: float,
                   solvent: Solvent,
                   twisting_radius_mm: float | None = None
                   ) -> None:
        """
        Calculate the Bodenstein num of the previous defined reactor for a specific
        flow rate and solvent.

        Parameters
        ----------
        flow_rate_mlmin : float
            Total flow rate for reactor in ml/min
        solvent : Solvent
            Possible solvents like 'Solvent.ethanol' with their material properties from
            the substances.py file
        twisting_radius_mm : float, optional
            Radius of twisting when working with a twisted reactor based on Erdogan &
            Chatwin 1967.
        """

        self.flow_rate: float = flow_rate_mlmin / (SEC_PER_MIN * ML_PER_M3)
        self.velocity: float = self.flow_rate / self.cross_section_area
        self.tau: float = self.length / self.velocity

        rho: float = solvent.density
        eta: float = solvent.viscosity

        self.reynolds_num = rho * self.velocity * self.inner_diameter / eta
        self.diffusion_axial: float = (DIFFUSION_LIQUID +
                                       (self.velocity**2 *self.inner_diameter**2) /
                                       (192 * DIFFUSION_LIQUID))
        self.bodenstein_num: float = self.velocity * self.length / self.diffusion_axial
        print(f"Bodenstein number of straight reactor is {self.bodenstein_num:.1f}.")

        if twisting_radius_mm:
            twisting_radius: float = twisting_radius_mm / 1000
            dean_num: float = self.reynolds_num * sqrt(self.inner_diameter /
                                                             (2 * twisting_radius))
            if dean_num < 1 or dean_num > 50:
                print(f"Dean number {dean_num:.2f} is outside of the interpolation "
                      f"area of 1 to 50.")
            y_axis_value: float = np.interp(dean_num, dean_values, y_axis_values)
            self.diffusion_axial_twisted: float = (self.diffusion_axial /
                                                   ((1 / 192 * 10000) / y_axis_value))
            self.bodenstein_num_twisted: float = (self.velocity * self.length /
                                                     self.diffusion_axial_twisted)
            print(f"Bodenstein number of twisted reactor is "
                  f"{self.bodenstein_num_twisted:.1f}.")
    
    def time_to_stationary(self,
                           percent_steady: int,
                           n_nodes: int = 100,
                           ) -> tuple[float, float]:
        """
        Calculate time until steady state is reached to a certain percentage inside the
        reactor.

        Parameters
        ---------
        percent_steady : int
            Quantity value in percent at which the steady state is reached.
        n_nodes : int, default 100
            Number of spacial nodes for discretization.

        Returns
        -------
        tau_steady: float
            Number of residence times until the steady state to a certain percentage is
            reached.
        t_steady: float
            Time in seconds until the steady state to a certain percentage is
            reached.
        """

        # Use diffusion of twisted reactor if that has been previous calculated
        if self.diffusion_axial_twisted:
            diffusion_axial = self.diffusion_axial_twisted
        else:
            diffusion_axial = self.diffusion_axial

        n_residence_times = 3
        dx = self.length / (n_nodes - 1)
        dt = 0.5 * min(dx / self.velocity, dx**2 / (2 * diffusion_axial))
        t_max = n_residence_times * self.length / self.velocity
        steps = int(t_max / dt)

        # Initial concentration profile: fluid A = 0 everywhere
        conc: np.ndarray = np.zeros(n_nodes)
        conc_out: np.ndarray = np.zeros(steps)

        # Time stepping using explicit forward integration on advection-dispersion
        for idx in range(steps):
            conc[0] = 1.0  # inlet switched to fluid B (C=1)
            conc_n = conc.copy()
            for i in range(1, n_nodes-1):
                adv = -self.velocity * (conc[i] - conc[i-1]) / dx
                diff = diffusion_axial * (conc[i+1] - 2*conc[i] + conc[i-1]) / dx**2
                conc_n[i] = conc[i] + dt*(adv + diff)
            conc_n[-1] = conc_n[-2]
            conc = conc_n
            conc_out[idx] = conc[-1]

        # Compute breakthrough time
        value_steady: float = percent_steady / 100
        times = np.linspace(0, t_max, steps)
        t_steady: float = np.interp(value_steady, conc_out, times)
        tau_steady = t_steady / self.tau
        print(f"{percent_steady} % of stationary achieved after {tau_steady:.1f} "
              f"residence times or {t_steady:.1f} s.")
        return tau_steady, t_steady


    def preheating(self,
                   flow_rate_mlmin: float,
                   initial_temp_degc: float,
                   outlet_temp_degc: float,
                   cooling_temp_degc: float,
                   solvent: Solvent,
                   solid: Solid
                   ) -> float:
        """
        Calculate tube length to reach outlet temp.

        Parameters
        ----------
        flow_rate_mlmin : float
            Volume flow rate inside the reactor in ml/min.
        initial_temp_degc : float
            Initial temp of reactor in degree Celsius.
        outlet_temp_degc: float
            Outlet temp of reactor in degree Celsius.
        cooling_temp_degc : float
            Cooling temp of reactor in degree Celsius.
        solvent : Solvent
            Possible solvents like'Solvent.ethanol' with their material properties from
            the substances.py file.
        solid : Solid
            Possible solvents like 'Solid.ptfe' with their material properties from the
            substances.py file.

        Returns
        -------
        length : float
            Length of the reactor to reach outlet temperature.
        """

        flow_rate: float = flow_rate_mlmin / (SEC_PER_MIN * ML_PER_M3)

        rho, cp, eta, lamb = solvent.props()
        tube_lamb: float = solid.thermal_conductivity
        
        mass_flow_rate = flow_rate * rho
        velocity = flow_rate / self.cross_section_area

        reynolds_num = velocity * self.inner_diameter * rho / eta
        if reynolds_num > RE_LAM_LIM:
            print(f"Flow is not laminar with a Reynolds num of {reynolds_num:.0f}.")
        nusselt_num = 3.66
        alpha_inner = nusselt_num * lamb / self.inner_diameter
        heat_transfer_coefficient = 1 / (1 / alpha_inner + self.inner_diameter /
                                         (2 *tube_lamb) * log(self.outer_diameter /
                                                              self.inner_diameter))

        length_outlet_temp = (log((outlet_temp_degc - cooling_temp_degc)/
                                  (initial_temp_degc - cooling_temp_degc)) *
                              -(mass_flow_rate * cp) / (heat_transfer_coefficient * pi *
                                                        self.inner_diameter))
        print(f"{length_outlet_temp:.2f} m are needed to reach {outlet_temp_degc:.2f} "
              f"°C at the outlet.")
        self.length = length_outlet_temp
        return self.length
