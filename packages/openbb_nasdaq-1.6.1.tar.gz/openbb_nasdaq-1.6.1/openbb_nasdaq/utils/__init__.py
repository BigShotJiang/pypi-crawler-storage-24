"""NASDAQ provider utils."""
