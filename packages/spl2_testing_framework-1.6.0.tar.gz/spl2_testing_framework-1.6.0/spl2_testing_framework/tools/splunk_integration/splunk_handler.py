# Copyright 2026 Splunk Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import uuid

import requests
import splunklib.client as client
import splunklib.results as results

import time

from requests.auth import HTTPBasicAuth

_LOGGER = logging.getLogger(__name__)


class SplunkHandler:
    def __init__(self, config, auth):
        self._config = config
        self.splunk_config = config.get("SPLUNK_INSTANCE", {})
        self._auth = auth

    def setup(self):
        self._create_index()

    def process_event(self, event):
        host = f"test_{uuid.uuid4()}"

        self.push_to_hec(event, host)
        res = self.get_events_by_host_and_index(host)
        if not res:
            raise Exception("No event found.")

        if len(res) > 1:
            _LOGGER.error("Found more than one event, the result may not be correct")
        return res[0]

    def push_to_hec(self, data, host):
        sourcetype = data.get("sourcetype", "UNKNOWN")

        if sourcetype == "UNKNOWN":
            _LOGGER.warning("Source type is UNKNOWN. The result may be not correct")

        source = data.get("source", None)

        params = {
            "sourcetype": sourcetype,
            "index": self.splunk_config["index"],
            "host": host,
        }

        if source is not None:
            params["source"] = source

        event_data = data["_raw"].encode("utf-8")

        response = requests.post(
            url=self.splunk_config["url"],
            data=event_data,
            params=params,
            auth=self._auth,
            verify=False,
        )

        response.raise_for_status()

    def get_events_by_host_and_index(self, host):
        SPL_TEMPLATE = "| search index={index} host={host} | fields *"
        # Connect to Splunk
        service = client.connect(
            host=self.splunk_config["ip"],
            port=self.splunk_config["api_port"],
            username=self.splunk_config["username"],
            password=self.splunk_config["password"],
            app="search",
        )
        SPL = SPL_TEMPLATE.format(index=self.splunk_config["index"], host=host)

        results_all = []
        retry = 0
        while not results_all and retry < 20:
            kwargs = {"adhoc_search_level": "verbose"}
            job = service.jobs.create(SPL, **kwargs)
            while not job.is_done():
                time.sleep(0.25)
            results_splunk = job.results(output_mode="json")
            rr = results.JSONResultsReader(results_splunk)
            for result in rr:
                if isinstance(result, results.Message):
                    _LOGGER.info("%s: %s", result.type, result.message)
                elif isinstance(result, dict):
                    # Normal events are returned as dicts
                    results_all.append(result)
            retry = retry + 1
            time.sleep(0.25)
        return results_all

    def _create_index(self):
        response = requests.post(
            url=self.splunk_config["index_url"],
            data={"name": self.splunk_config["index"], "output_mode": "json"},
            auth=HTTPBasicAuth(
                self.splunk_config["username"], self.splunk_config["password"]
            ),
            verify=False,
        )
        return response.json()
