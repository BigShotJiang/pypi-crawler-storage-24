# Coding Mode

The guided workflow could not complete step **{failed_step}**:
> {fail_reason}

You are now authorized to read source code and propose a fix.

Before writing code, confirm configuration exploration is exhausted:
- For plausible monitor/scraper types, at least one concrete config variant was tried
- Type switching was not done after the first failed/incomplete run unless there was a hard mismatch
- Attempts and failure reasons were recorded
- Evidence trail is clear (observation, method, interpretation)

## Steps

1. Clean up the failed workspace: `ws del`
2. Clone the repo into a **private, randomized** working copy (do NOT use `~/.jobseek/repo/` — that belongs to `ws`):
   ```bash
   WORKDIR="/tmp/jobseek-fix-$(openssl rand -hex 4)"
   git clone https://github.com/colophon-group/jobseek.git "$WORKDIR"
   cd "$WORKDIR/apps/crawler"
   ```
   **Important:** Always randomize the clone path. Multiple agents may run concurrently —
   a fixed path like `/tmp/jobseek-fix` will cause agents to overwrite each other's work.
3. Identify the root cause in the source code (`src/core/monitors/`, `src/core/scrapers/`, `src/workspace/`)
4. Create a `fix-crawler/<description>` branch
5. Make the minimal code change that fixes the issue
6. Include the company's CSV config alongside the code change
7. Open a PR with:
   - What was tried during the guided workflow
   - Why it failed
   - What the code change does

## Guidelines

- Prefer extending existing monitor/scraper types over adding new ones
- Keep changes minimal — fix the specific issue, don't refactor
- Include tests for new code when feasible
- Label the PR `review-code`
