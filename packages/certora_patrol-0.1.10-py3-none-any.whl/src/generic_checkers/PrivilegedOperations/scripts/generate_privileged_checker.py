#!/usr/bin/env python3
"""
Script to generate Certora Privileged Operations Checker configuration and spec files.
"""

import argparse
import json
import os
import sys
from pathlib import Path

from src.parsers.orchestrator_argparse import parse_contract_files
from src.setup.signature_types import InheritanceGraph
from src.utils.logger import logger
from src.utils.types import ContractHandle


def detect_access_control_contracts(
    contracts: list[ContractHandle],
    inheritance_graph: InheritanceGraph,
):
    """Detect which contracts inherit from AccessControl or AccessControlUpgradeable by checking the inheritance graph."""
    contracts_with_access_control = {}  # Returns a dict: {contract_name: 'regular' or 'upgradeable'}

    logger.info(f"Inheritance graph has {len(inheritance_graph._graph)} contract entries")
    for handle in contracts:
        contract_name = handle.contract_name

        # Check which type of AccessControl this contract inherits from
        access_control_type = get_access_control_type(contract_name, inheritance_graph)
        if access_control_type:
            contracts_with_access_control[contract_name] = access_control_type
            logger.info(f"✓ Found {access_control_type} AccessControl inheritance in {contract_name}")

    return contracts_with_access_control


def get_access_control_type(
    contract_name: str,
    inheritance_graph: InheritanceGraph,
) -> str | None:
    """Check if a contract inherits from AccessControl or AccessControlUpgradeable and return the type."""
    # Check if this contract exists in the inheritance graph
    if inheritance_graph.find_handle_by_name(contract_name) is None:
        return None

    # BFS to check all parent contracts
    visited: set[str] = set()
    queue = [contract_name]
    found_type = None

    while queue:
        current = queue.pop(0)
        if current in visited:
            continue
        visited.add(current)

        if current == "AccessControlUpgradeable":
            found_type = "upgradeable"
            break
        elif current == "AccessControl":
            # Only set to regular if we haven't found upgradeable yet
            if not found_type:
                found_type = "regular"
            # Continue searching in case there's AccessControlUpgradeable higher up

        # Add parent contracts to queue
        current_handle = inheritance_graph.find_handle_by_name(current)
        if current_handle is not None:
            for parent_handle in inheritance_graph.get_parents(current_handle):
                if parent_handle.contract_name not in visited:
                    queue.append(parent_handle.contract_name)

    return found_type

def generate_access_control_spec(contracts_with_access_control, output_dir, contract_suffix=""):
    """Generate AccessControl single ownership spec for contracts that have it."""
    if not contracts_with_access_control:
        return None

    spec_sections = []

    # Process each contract based on its AccessControl type
    for contract_name, access_type in contracts_with_access_control.items():
        # Choose the appropriate template based on the type
        if access_type == "upgradeable":
            template_filename = "OZ_AccessControlUpgradeableSingle.spec"
        else:  # regular
            template_filename = "OZ_AccessControlSingle.spec"

        template_path = Path(__file__).parent.parent.parent.parent.parent / "certora" / "Summaries" / "OpenZeppelin" / template_filename

        if not template_path.exists():
            logger.warning(f"{template_filename} not found at {template_path}")
            continue

        with open(template_path, 'r') as f:
            template_content = f.read()

        # Replace $CONTRACT_NAME$ with actual contract name
        contract_spec = template_content.replace('$CONTRACT_NAME$', contract_name)
        spec_sections.append(f"// AccessControl single ownership spec for {contract_name} ({access_type})")
        spec_sections.append(contract_spec)

    if not spec_sections:
        logger.warning("No AccessControl specs generated")
        return None

    # Write the combined spec with suffix
    output_spec_name = f"access_control_single{contract_suffix}.spec"
    output_spec = output_dir / output_spec_name
    with open(output_spec, 'w') as f:
        f.write("// Auto-generated AccessControl single ownership specifications\n")
        f.write("// This file contains storage hooks and functions for contracts with AccessControl\n\n")

        # Add using declarations for each contract
        f.write("// Contract using declarations\n")
        for contract_name in contracts_with_access_control.keys():
            f.write(f"using {contract_name} as {contract_name};\n")
        f.write("\n")

        f.write("\n\n".join(spec_sections))

    logger.info(f"✓ Generated AccessControl spec: {output_spec}")
    return output_spec_name

def validate_args(args):
    """Validate command line arguments."""
    # Files are always required (for AccessControl detection)
    if not args.files:
        logger.error("At least one .sol file must be provided")
        sys.exit(1)

    contracts = parse_contract_files(args.files)

    for handle in contracts:
        if not handle.source_file.endswith('.sol'):
            logger.error(f"{handle.source_file} is not a .sol file")
            sys.exit(1)
        if not os.path.exists(handle.source_file):
            logger.error(f"File {handle.source_file} does not exist")
            sys.exit(1)

    if args.base_config:
        if not os.path.exists(args.base_config):
            logger.error(f"Base config file {args.base_config} does not exist")
            sys.exit(1)

    if not args.contract:
        logger.error("Main contract name is required")
        sys.exit(1)

    contract_names = [c.contract_name for c in contracts]
    if args.contract not in contract_names:
        logger.error(f"Main contract '{args.contract}' not found in provided files")
        logger.error(f"Available contracts: {', '.join(contract_names)}")
        sys.exit(1)

def process_templates(args, inheritance_graph: InheritanceGraph | None = None):
    """Process template files and generate configuration."""
    script_dir = Path(__file__).parent
    project_dir = script_dir.parent

    # Use args.output_dir if provided, else default
    output_dir = getattr(args, 'output_dir', None) or Path("certora_privileged_checker")
    contract_suffix = getattr(args, 'contract_suffix', "") or ""

    # Create output directory if it doesn't exist (don't delete if exists - for per-contract accumulation)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Detect contracts with AccessControl
    logger.info("Checking for AccessControl in contracts...")
    contracts = parse_contract_files(args.files)
    if not inheritance_graph:
        raise RuntimeError("Inheritance graph is empty or None - signature database was not properly populated")
    contracts_with_access_control = detect_access_control_contracts(contracts, inheritance_graph)

    # Generate AccessControl spec if needed (with suffix)
    access_control_spec = None
    if contracts_with_access_control:
        access_control_spec = generate_access_control_spec(contracts_with_access_control, output_dir, contract_suffix)
    else:
        logger.info("No AccessControl patterns detected")

    # Find all template conf files in the confs directory
    confs_dir = project_dir / "confs"
    template_files = list(confs_dir.glob("*.template.conf"))

    if not template_files:
        logger.error("No template configuration files found in confs directory")
        sys.exit(1)

    # Find all spec files in the specs directory
    specs_dir = project_dir / "specs"
    spec_files = list(specs_dir.glob("*.spec"))

    if not spec_files:
        logger.error("No specification files found in specs directory")
        sys.exit(1)

    # Process all spec files with suffix
    generated_specs = []
    for spec_file in spec_files:
        spec_output_name = f"{spec_file.stem}{contract_suffix}.spec"
        spec_output = output_dir / spec_output_name

        # Process spec file - add AccessControl import if needed
        with open(spec_file, 'r') as f:
            spec_content = f.read()

        # If this is privileged_operations.spec or privileged_writes.spec and we have AccessControl, add import and checks
        if spec_file.name in ["privileged_operations.spec", "privileged_writes.spec"] and access_control_spec:
            # Add import at the beginning of the spec
            import_statement = f'import "{access_control_spec}";\n\n'
            spec_content = import_statement + spec_content

            # Replace placeholder with actual AccessControl checks
            access_control_checks = []
            for contract_name in contracts_with_access_control:
                check = f"\trequire singleOwnership_{contract_name}(), \"We assume access control to have a single address per role in {contract_name} to detect privileged functionality.\";"
                access_control_checks.append(check)

            if access_control_checks:
                replacement = "\n".join(access_control_checks) + "\n"
                spec_content = spec_content.replace(
                    "\t// ACCESS_CONTROL_SINGLE_OWNERSHIP_CHECK_PLACEHOLDER",
                    replacement
                )
                logger.info(f"✓ Added AccessControl single ownership checks for {len(contracts_with_access_control)} contracts to {spec_output_name}")

            logger.info(f"✓ Added AccessControl import to {spec_output_name}")

        with open(spec_output, 'w') as f:
            f.write(spec_content)

        generated_specs.append(spec_output_name)

    # Process all template conf files
    generated_confs = []
    for template_file in template_files:
        # Generate output filename with suffix
        base_name = template_file.name.replace('.template.conf', '')
        output_filename = f"{base_name}{contract_suffix}.conf"
        conf_output = output_dir / output_filename

        # Process conf file
        with open(template_file, 'r') as f:
            conf_content = f.read()

        # Parse existing JSON to modify it
        try:
            # Replace placeholders before parsing JSON
            # Prefer base_config if provided, otherwise use files
            if args.base_config:
                conf_content = conf_content.replace('$BASE_CONFIG_OR_FILES$', f'"override_base_config": "{args.base_config}"')
            else:
                files_json = json.dumps(args.files)
                conf_content = conf_content.replace('$BASE_CONFIG_OR_FILES$', f'"files": {files_json}')
            conf_content = conf_content.replace('$CONTRACT$', args.contract)
            conf_content = conf_content.replace('$CONTRACT_SUFFIX$', contract_suffix)
            conf_data = json.loads(conf_content)

            # Add storage_extension_annotation if we have AccessControl contracts
            if contracts_with_access_control:
                conf_data["storage_extension_annotation"] = True
                logger.info(f"✓ Added storage_extension_annotation to {output_filename}")

            # Write the modified configuration
            with open(conf_output, 'w') as f:
                json.dump(conf_data, f, indent=4)

        except json.JSONDecodeError as e:
            # Fallback to simple replacement if JSON parsing fails
            logger.warning(f"Could not parse {template_file} as JSON, using simple replacement: {e}")
            # Prefer base_config if provided, otherwise use files
            if args.base_config:
                conf_content = conf_content.replace('$BASE_CONFIG_OR_FILES$', f'"override_base_config": "{args.base_config}"')
            else:
                files_json = json.dumps(args.files)
                conf_content = conf_content.replace('$BASE_CONFIG_OR_FILES$', f'"files": {files_json}')
            conf_content = conf_content.replace('$CONTRACT$', args.contract)
            conf_content = conf_content.replace('$CONTRACT_SUFFIX$', contract_suffix)

            with open(conf_output, 'w') as f:
                f.write(conf_content)

        generated_confs.append(output_filename)

    # Create runner script for all generated configurations
    runner_script = output_dir / "run_checker.sh"
    with open(runner_script, 'w') as f:
        f.write(f"#!/bin/bash\n")
        f.write(f"# Generated runner script for Certora Privileged Operations Checker\n")
        f.write(f"# This script will run all generated configurations\n\n")

        for conf_file in generated_confs:
            f.write(f"echo \"Running {conf_file}...\"\n")
            f.write(f"certoraRun certora_privileged_checker/{conf_file}\n")
            f.write(f"echo \"Completed {conf_file}\"\n\n")

    # Make runner script executable
    os.chmod(runner_script, 0o755)

    logger.info(f"Generated configuration in {output_dir}/")
    for conf_file in generated_confs:
        logger.info(f"Configuration: {output_dir / conf_file}")
    for spec_file in generated_specs:
        logger.info(f"Specification: {output_dir / spec_file}")
    logger.info(f"Runner script: {runner_script}")
    logger.info(f"To run all checkers, execute:")
    logger.info(f"  ./certora_privileged_checker/run_checker.sh")
    logger.info(f"Or run individual configurations:")
    for conf_file in generated_confs:
        logger.info(f"  certoraRun certora_privileged_checker/{conf_file}")

class PrivilegedChecker:
    """Wrapper class for privileged operations checker functionality."""

    def __init__(self, directory=".", verbose=False):
        """Initialize the checker with a directory and verbosity setting."""
        self.directory = Path(directory)
        self.verbose = verbose

    def generate_config(self, files, contract):
        """Generate privileged operations checker config and spec files."""
        # Change to the target directory
        original_cwd = os.getcwd()
        try:
            os.chdir(self.directory)

            # Create a mock args object
            class Args:
                def __init__(self, files, contract):
                    self.files = files
                    self.contract = contract

            args = Args(files, contract)
            validate_args(args)
            process_templates(args)

        finally:
            os.chdir(original_cwd)

def main():
    parser = argparse.ArgumentParser(
        description="Generate Certora External Call Checker configuration and spec files"
    )

    parser.add_argument(
        '--base-config',
        type=str,
        help='Path to base config file (mutually exclusive with files)'
    )

    parser.add_argument(
        'files',
        nargs='+',
        help='List of Solidity contract files (.sol) - always required for AccessControl detection'
    )

    parser.add_argument(
        'contract',
        help='Name of the main contract (without .sol extension)'
    )

    args = parser.parse_args()

    validate_args(args)
    process_templates(args)

if __name__ == "__main__":
    main()
