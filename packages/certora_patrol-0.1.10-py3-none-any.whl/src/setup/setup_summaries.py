#!/usr/bin/env python3
"""
Automatic Setup for Contract Summaries

This script detects if certain functions are called in the project contracts
and sets up appropriate summaries for verification.

Currently supported summaries:
- Math.mulDiv from OpenZeppelin Math.sol
- toString from OpenZeppelin ShortStrings.sol
- toString from OpenZeppelin Strings.sol
"""


import argparse
import json
import logging
import logging.handlers
import os
import re
import shutil
import asyncio
import sys
from collections import defaultdict, deque
from dataclasses import dataclass
from enum import Enum
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, TypedDict, Coroutine, Literal, Annotated
from pydantic import BaseModel, Field, ValidationError, Discriminator, ConfigDict

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.utils import logger
from src.utils.constants import ANTHROPIC_API_KEY_ENV
from src.utils.llm_util import MODEL_SONNET, call_llm_structured, call_llm_async_structured_cached

from src.setup.solidity_utils import DEPENDENCIES, find_all_library_files as util_find_all_library_files
from src.setup.solidity_utils import find_all_solidity_files as util_find_all_solidity_files

# Import method parser
from src.parsers.method_parser import MethodParser
from src.setup.signature_types import InheritanceGraph
from src.utils.types import ContractHandle


try:
    from dotenv import load_dotenv

    # Load .env from current working directory
    env_path = Path.cwd() / ".env"
    if not env_path.exists():
        api_key = os.getenv(ANTHROPIC_API_KEY_ENV)
        if api_key:
            print(f"✓ Using {ANTHROPIC_API_KEY_ENV} from environment variables")
        else:
            print(f"ERROR: .env file not found in current directory: {Path.cwd()}")
            print(f"       and {ANTHROPIC_API_KEY_ENV} not found in environment variables")
            print("Please either:")
            print(f"  1. Create a .env file in the current directory with {ANTHROPIC_API_KEY_ENV}=...")
            print(f"  2. Export {ANTHROPIC_API_KEY_ENV} as an environment variable")
            sys.exit(1)
    else:
        loaded = load_dotenv(env_path)
        if not loaded:
            print(f"ERROR: Failed to load .env file from: {env_path}")
            sys.exit(1)

        print(f"✓ Loaded .env from {env_path}")
except ImportError:
    print("ERROR: python-dotenv is required. Install with: pip install python-dotenv")
    sys.exit(1)

# Import local modules
from src.parsers import MethodParser
from src.parsers.type_analyzer import TypeAnalyzer, TypeCategory

class CacheStats(TypedDict):
    hits: int
    misses: int

class MatchAnalysis(BaseModel):
    """
    Result of your analysis on whether a contract method matches the given criteria.
    """
    is_match: bool = Field(description="True if the method matches the described criteria, False otherwise")
    explanation: str = Field(description="A BRIEF (no more than one sentence) describing why the method does or does not match")

class PrimitiveType(BaseModel):
    ty: Literal["primitive"]
    ty_name: Literal[
        "uint8", "uint16", "uint24", "uint32", "uint40", "uint48", "uint56", "uint64",
        "uint72", "uint80", "uint88", "uint96", "uint104", "uint112", "uint120", "uint128",
        "uint136", "uint144", "uint152", "uint160", "uint168", "uint176", "uint184", "uint192",
        "uint200", "uint208", "uint216", "uint224", "uint232", "uint240", "uint248", "uint256",
        "int8", "int16", "int24", "int32", "int40", "int48", "int56", "int64",
        "int72", "int80", "int88", "int96", "int104", "int112", "int120", "int128",
        "int136", "int144", "int152", "int160", "int168", "int176", "int184", "int192",
        "int200", "int208", "int216", "int224", "int232", "int240", "int248", "int256",
        "bytes1", "bytes2", "bytes3", "bytes4", "bytes5", "bytes6", "bytes7", "bytes8",
        "bytes9", "bytes10", "bytes11", "bytes12", "bytes13", "bytes14", "bytes15", "bytes16",
        "bytes17", "bytes18", "bytes19", "bytes20", "bytes21", "bytes22", "bytes23", "bytes24",
        "bytes25", "bytes26", "bytes27", "bytes28", "bytes29", "bytes30", "bytes31", "bytes32",
        "bool", "address"
    ]

class BuiltInArrayType(BaseModel):
    ty: Literal["primitive_array"]
    nm: Literal["bytes", "string"] = Field(description="The name of the built in array type")

class AggregateArrayType(BaseModel):
    ty: Literal["aggregate_array"]
    base: "SolidityType" = Field(description="The type of elements of the dynamic array")

class StaticArrayType(BaseModel):
    ty: Literal["static_array"]
    base: "SolidityType"  = Field(description="The type of elements of the static array")
    n_elems: int = Field(description="The number of elements in this static array")

ReferenceBase = Annotated[BuiltInArrayType | AggregateArrayType | StaticArrayType, Discriminator("ty")]

class ReferenceType(BaseModel):
    ty: Literal["ref"]
    value: ReferenceBase = Field(description="The reference type used as a parameter")
    location: Literal["calldata", "memory", "storage"] = Field(description="The location required")

SolidityType = Annotated[BuiltInArrayType | AggregateArrayType | PrimitiveType | StaticArrayType, Discriminator("ty")]

ParameterType = Annotated[ReferenceType | PrimitiveType, Discriminator("ty")]

def _pprint_solidity_type(t: SolidityType) -> str:
    match t.ty:
        case "primitive_array":
            return t.nm
        case "primitive":
            return t.ty_name
        case "aggregate_array":
            return _pprint_solidity_type(t.base) + "[]"
        case "static_array":
            return _pprint_solidity_type(t.base) + f"[{t.n_elems}]"

def _pprint_type(t: ParameterType) -> str:
    match t.ty:
        case "primitive":
            return t.ty_name
        case "ref":
            return _pprint_solidity_type(t.value)

class TypeAndName(BaseModel):
    """
    A formal parameter with a type and a name.
    """
    ty: ParameterType = Field(description="The type of the parameter.")
    name: str = Field(description="The name of the parameter")

class DecimalSummary(BaseModel):
    """
    Used to indicate that a method performs a decimal conversion and how to summarize it.
    """
    ty: Literal["decimal"]
    method_name: str = Field(description="The name of the analyzed method (without any parameters or return information)")
    param_list: list[TypeAndName] = Field(description="The method parameters for the summary")
    amount_parameter: str = Field(description="The name of the parameter in `param_list` that is being converted between decimals")
    return_type : PrimitiveType = Field(description="The return type of the analyzed function.")
    cvl_function_name: str = Field(description="The name of the function to use for the generated summary. Must be a valid, appropriately named CVL identifier.")

    explanation: str = Field(description="A BRIEF (no more than one sentence) justifying why this method is a decimal conversion")

    @property
    def summary_line(self) -> str:
        params = ", ".join([ f"{_pprint_type(p.ty)} {p.name}" for p in self.param_list ])
        return f"function _.{self.method_name}({params}) internal => {self.cvl_function_name}({self.amount_parameter}) expect {self.return_type.ty_name};"

    @property
    def cvl_function(self) -> str:
        param_ty : ParameterType | None = None
        for p in self.param_list:
            if p.name == self.amount_parameter:
                param_ty = p.ty
        if param_ty is None or not isinstance(param_ty, PrimitiveType):
            raise ValueError("Invalid analysis, amount param doesn't appear in list?")
        return f"function {self.cvl_function_name}({param_ty.ty_name} amount) returns {self.return_type.ty_name} {{ return amount; }}"

class InvalidSummary(BaseModel):
    """
    Used to indicate that the method is not a decimal conversion and why
    """
    ty: Literal["failed"]
    explanation: str = Field(description="A BREIF description of why the summary generation failed")

class DecimalAnalysisResult(BaseModel):
    """
    Communicate the result of the decimal conversion analysis.

    Only one of the result fields should be set.
    """
    res_failed: InvalidSummary | None = Field(description="The field used to communicate an unsuccesful result")
    res_success: DecimalSummary | None = Field(description="The field used to communicate a successful result")

class RecipeType(str, Enum):
    PRICE_COMPUTATION = "price_computation"
    NEW_CONTRACT = "new_contract"
    DECIMAL_CONVERSION = "decimal_conversion"
    NONLINEAR_OPERATIONS = "nonlinear_operations"
    INLINE_ASSEMBLY = "inline_assembly"
    CUSTOM = "custom"


@dataclass
class Recipe:
    """Recipe for LLM-based function analysis."""

    recipe_type: RecipeType
    characteristic: str  # Description of function characteristic to look for
    properties: Dict[
        str, Any
    ]  # Required method properties (visibility, stateMutability, etc.)
    summary_type: str  # How to summarize matching methods (e.g., "NONDET")


class SummarySetup:
    def __init__(self, verbose: int = 0, inheritance_graph: InheritanceGraph | None = None):
        self.verbose = verbose
        self.inheritance_graph: InheritanceGraph = inheritance_graph or InheritanceGraph()
        self.script_dir = Path(__file__).parent
        # Summaries folder is in certora directory
        self.summaries_dir = self.script_dir.parent.parent / "certora" / "Summaries"
        self.certora_dir = Path.cwd() / "certora"

        # LLM log path
        self.llm_log_path = Path(".certora_internal/llm.log")

        # Configure logger
        logger.set_verbosity(verbose)
        self.component = "SummarySetup"

        # Set up LLM logger with rotation
        self.llm_logger = self._setup_llm_logger()

        # Load function signatures from JSON file
        self.function_summaries = self._load_function_summaries()

        # Pre-compute Solidity file sets to avoid repeated calls
        self.solidity_files_with_dependencies = self.find_all_solidity_files(
            include_dependencies=True
        )
        self.solidity_files_no_dependencies = self.find_all_solidity_files(
            include_dependencies=False
        )
        self.solidity_files_libraries = self.find_all_library_files(
            include_test_files=False, include_dependencies=False
        )

        self.templates: set = set()  # Will update if any template files were processed

        # Initialize TypeAnalyzer for resolving user-defined types in function declarations
        self.type_analyzer: TypeAnalyzer = self._init_type_analyzer()

    def _init_type_analyzer(self) -> TypeAnalyzer:
        """Initialize TypeAnalyzer. Fatal error if initialization fails."""
        analyzer = TypeAnalyzer()
        if not analyzer.types_json.exists():
            raise FileNotFoundError(f"TypeAnalyzer: types JSON not found at {analyzer.types_json}")
        if not analyzer.parse_all():
            raise RuntimeError("TypeAnalyzer failed to parse type data")
        self.log("TypeAnalyzer initialized successfully", "DEBUG")
        return analyzer

    def log(self, message: str, level: str = "INFO"):
        """Log messages using centralized logger."""
        logger.log(message, level, self.component)

    def _setup_llm_logger(self) -> logging.Logger:
        """Set up a rotating file logger for LLM interactions."""
        llm_logger = logging.getLogger("llm_interactions")
        llm_logger.setLevel(logging.INFO)

        # Don't add handlers if they already exist (avoid duplicates)
        if not llm_logger.handlers:
            self.llm_log_path.parent.mkdir(parents=True, exist_ok=True)

            # Create rotating file handler (20MB max, keep 1 backup)
            handler = logging.handlers.RotatingFileHandler(
                filename=str(self.llm_log_path),
                maxBytes=20 * 1024 * 1024,  # 20MB
                backupCount=1,
                encoding="utf-8",
            )

            # Simple format - we'll format the messages ourselves
            formatter = logging.Formatter("%(message)s")
            handler.setFormatter(formatter)

            llm_logger.addHandler(handler)

        return llm_logger

    def _load_function_summaries(self) -> Dict[str, Dict[str, Any]]:
        """Load function summaries configuration from JSON file."""
        config_file = Path(__file__).parent / "function_summaries.json"

        try:
            with open(config_file, "r") as f:
                return json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(
                f"Function summaries config file not found: {config_file}\n"
                f"Please ensure function_summaries.json exists in the setup/ directory."
            )
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Invalid JSON in function summaries config file: {config_file}\n"
                f"Error: {e}"
            )

    def parse_call_graph_dot_file(
        self, dot_file: str
    ) -> Tuple[Dict[str, Set[str]], Set[str]]:
        """
        Parse a call-graph DOT file and extract the graph structure.
        Call-graph files use quoted node names: "contract1" -> "contract2"

        Returns:
            Tuple of (adjacency_list, nodes) where:
            - adjacency_list is a dict mapping source nodes to sets of target nodes
            - nodes is a set of all nodes in the graph
        """
        adjacency_list: dict = defaultdict(set)
        nodes: set = set()

        if not os.path.exists(dot_file):
            self.log(f"Call-graph DOT file not found: {dot_file}", "WARNING")
            return adjacency_list, nodes

        try:
            with open(dot_file, "r") as f:
                content = f.read()

            # Find all edges (format: "node1" -> "node2")
            edge_pattern = r'"([^"]+)"\s*->\s*"([^"]+)"'
            for match in re.finditer(edge_pattern, content):
                source, target = match.groups()
                adjacency_list[source].add(target)
                nodes.add(source)
                nodes.add(target)

            # Also find standalone nodes (format: "node"[attributes])
            node_pattern = r'"([^"]+)"\[.*?\]'
            for match in re.finditer(node_pattern, content):
                node = match.group(1)
                nodes.add(node)

            self.log(
                f"Parsed call-graph DOT file: {len(nodes)} nodes, {sum(len(targets) for targets in adjacency_list.values())} edges"
            )

        except Exception as e:
            self.log(f"Error parsing call-graph DOT file {dot_file}: {e}", "WARNING")

        return adjacency_list, nodes

    def _load_logic_contracts_from_json(self) -> Set[str]:
        """
        Load logic contract names from .certora_internal/all_logic_contracts.json

        Returns:
            Set of logic contract names, empty set if file doesn't exist or can't be parsed
        """
        logic_contracts_file = Path(".certora_internal") / "all_logic_contracts.json"

        if not logic_contracts_file.exists():
            self.log(f"Logic contracts file not found: {logic_contracts_file}", "DEBUG")
            return set()

        try:
            with open(logic_contracts_file, "r") as f:
                contracts_list = json.load(f)

            contracts = set(contracts_list)
            self.log(
                f"Loaded {len(contracts)} logic contracts from {logic_contracts_file}"
            )
            return contracts

        except json.JSONDecodeError as e:
            raise Exception(f"Error parsing JSON from {logic_contracts_file}: {e}")
        except Exception as e:
            raise Exception(f"Error reading {logic_contracts_file}: {e}")

    def find_reachable_nodes(
        self, graph: Dict[str, Set[str]], start_nodes: Set[str]
    ) -> Set[str]:
        """Find all nodes reachable from the given start nodes using BFS."""
        reachable = set()
        queue = deque(start_nodes)

        while queue:
            node = queue.popleft()
            if node in reachable:
                continue
            reachable.add(node)

            # Add all neighbors to the queue
            if node in graph:
                for neighbor in graph[node]:
                    if neighbor not in reachable:
                        queue.append(neighbor)

        return reachable

    def extract_method_names(self, nodes: Set[str]) -> Set[str]:
        """Extract method names from node labels.

        Slither node labels often contain contract and method info like:
        - "Contract.method()"
        - "method()"
        - "Contract::method"
        - "12345_method" (Slither's format with numeric prefix)
        """
        method_names = set()

        for node in nodes:
            # Remove parameters and clean up
            clean_node = re.sub(r"\([^)]*\)", "", node)

            # Handle Slither's numeric prefix format (e.g., "50193_toString")
            if "_" in clean_node and clean_node.split("_")[0].isdigit():
                # Extract the part after the numeric prefix
                parts = clean_node.split("_", 1)
                if len(parts) > 1:
                    method_name = parts[1].strip()
                    if method_name:
                        method_names.add(method_name)
            # Handle Contract.method or Contract::method format
            elif "." in clean_node or "::" in clean_node:
                parts = re.split(r"[.:]", clean_node)
                if parts:
                    method_name = parts[-1].strip()
                    if method_name:
                        method_names.add(method_name)
            else:
                # Just the method name (no prefix or separator)
                method_name = clean_node.strip()
                if method_name:
                    method_names.add(method_name)

        return method_names

    def analyze_call_graph(
        self, call_graph_file: str, target_functions: Set[str]
    ) -> Set[str]:
        """Analyze call graph to check which target functions are reachable.

        Args:
            call_graph_file: Path to the call graph DOT file
            target_functions: Set of function names to look for (e.g., {'toString', 'mulDiv'})

        Returns:
            Set of target functions that are reachable from root nodes
        """
        if not call_graph_file or not os.path.exists(call_graph_file):
            return set()

        self.log(f"Analyzing call graph: {call_graph_file}")
        graph, nodes = self.parse_call_graph_dot_file(call_graph_file)

        # Find root nodes (nodes with no incoming edges)
        all_targets = set()
        for targets in graph.values():
            all_targets.update(targets)
        root_nodes = nodes - all_targets

        if not root_nodes:
            # If no clear roots, consider all public/external functions as roots
            # Look for typical public function patterns
            root_nodes = {
                n
                for n in nodes
                if not n.startswith("_") and not n.startswith("internal")
            }

        self.log(f"Found {len(root_nodes)} root nodes in call graph")

        # Find all reachable nodes from roots
        reachable = self.find_reachable_nodes(graph, root_nodes)

        # Extract method names from reachable nodes
        reachable_methods = self.extract_method_names(reachable)

        # Check which target functions are reachable
        found_functions = target_functions & reachable_methods

        if found_functions:
            self.log(
                f"Found reachable target functions in call graph: {found_functions}",
                "SUCCESS",
            )

        return found_functions

    def find_all_solidity_files(
        self, include_test_files: bool = False, include_dependencies: bool = False
    ) -> List[str]:
        """Find all Solidity files in the current project.

        Args:
            include_test_files: Whether to include test (.t.sol) and script (.s.sol) files
            include_dependencies: Whether to include files in dependency directories
        """
        return util_find_all_solidity_files(
            include_test_files=include_test_files,
            include_dependencies=include_dependencies,
            verbose=self.verbose >= 1,
            log_func=self.log,
        )

    def find_all_library_files(
        self, include_test_files: bool = False, include_dependencies: bool = False
    ) -> List[str]:
        """Find all Solidity files that contain library definitions.

        Args:
            include_test_files: Whether to include test files
            include_dependencies: Whether to include dependency files

        Returns:
            List of file paths containing library definitions
        """
        return util_find_all_library_files(
            include_test_files=include_test_files,
            include_dependencies=include_dependencies,
            verbose=self.verbose >= 1,
            log_func=self.log,
        )

    def copy_summaries_folder(self) -> Path:
        """Copy the Summaries folder to certora directory."""
        source_summaries = self.summaries_dir
        target_summaries = self.certora_dir / "Summaries"

        # Create certora directory if it doesn't exist
        self.certora_dir.mkdir(parents=True, exist_ok=True)

        # Copy the Summaries directory
        if source_summaries.exists():
            if target_summaries.exists():
                shutil.rmtree(target_summaries)

            shutil.copytree(source_summaries, target_summaries)

            self.log(f"Copied Summaries folder to {target_summaries}")
        else:
            self.log(
                f"Source Summaries folder not found at {source_summaries}", "WARNING"
            )

        return target_summaries

    def _find_rounding_enum_value(self, contract_name) -> Optional[str]:
        """Find the correct Rounding enum value from all_user_defined_types.json.

        Returns:
            Either "Up" or "Ceil" depending on what's found in the Rounding enum
        """
        try:
            user_types_file = Path(".certora_internal/all_user_defined_types.json")
            if not user_types_file.exists():
                self.log("Warning: all_user_defined_types.json not found", "WARNING")
                return None

            with open(user_types_file, "r") as f:
                user_types = json.load(f)

            # Find the Rounding enum
            for type_info in user_types:
                if (
                    type_info.get("typeCategory") == "UserDefinedEnum"
                    and type_info.get("typeName") == "Rounding"
                    and type_info.get("main_contract") == contract_name
                ):
                    enum_members = type_info.get("enumMembers", [])
                    self.log(f"Found Rounding enum with members: {enum_members}")

                    # Extract member names from the objects
                    member_names = []
                    for member in enum_members:
                        if isinstance(member, dict) and "name" in member:
                            member_names.append(member["name"])
                        elif isinstance(member, str):
                            member_names.append(member)

                    # Check for Up or Ceil
                    if "Ceil" in member_names:
                        return "Ceil"
                    elif "Up" in member_names:
                        return "Up"
                    else:
                        self.log(
                            f"Warning: Rounding enum found but contains neither 'Up' nor 'Ceil'. Members: {member_names}",
                            "WARNING",
                        )
                        return None  # Default fallback

            self.log("Warning: Rounding enum not found in user types", "WARNING")
            return None

        except Exception as e:
            raise Exception(f"Error reading user types file: {e}")

    def process_template_in_place(
        self,
        template_file: Path,
        spec_path: Path,
        template_result_file: Path,
        contract_name: str,
    ) -> None:
        """Process a template file in place, creating the non-template version.

        Args:
            template_file: Path to the template file to process
        """
        # Read template content
        template_content = template_file.read_text()

        # Replace placeholders
        processed_content = template_content.replace("$CONTRACT_NAME$", contract_name)

        # Special handling for OZ_Math.template.spec
        if template_file.name == "OZ_Math.template.spec":
            rounding_value = self._find_rounding_enum_value(contract_name)
            if rounding_value is None:
                processed_content = processed_content.replace(
                    "$COMMENT_IF_NO_ROUNDING$", "//"
                )
                processed_content = processed_content.replace(
                    "$COMMENT_BLOCK_START_IF_NO_ROUNDING$", "/*"
                )
                processed_content = processed_content.replace(
                    "$COMMENT_BLOCK_END_IF_NO_ROUNDING$", "*/"
                )
            else:
                processed_content = processed_content.replace(
                    "$UINT_ROUND_UP$", rounding_value
                )
                processed_content = processed_content.replace(
                    "$COMMENT_IF_NO_ROUNDING$", ""
                )
                processed_content = processed_content.replace(
                    "$COMMENT_BLOCK_START_IF_NO_ROUNDING$", ""
                )
                processed_content = processed_content.replace(
                    "$COMMENT_BLOCK_END_IF_NO_ROUNDING$", ""
                )
            self.log(
                f"Processed OZ_Math template with Rounding value: {rounding_value}"
            )

        # Create output file
        output_file = template_result_file
        output_file.write_text(processed_content)

        self.log(
            f"Processed template {template_file.name} with contract name: {contract_name}"
        )

    def process_template_file(self, template_path: str) -> str:
        """Convert a template path to its processed path.

        Args:
            template_path: Path to the template file (e.g., "Summaries/PRB/PRB_Math.template.spec")

        Returns:
            Path to the processed spec file (e.g., "Summaries/PRB/PRB_Math.spec")
        """
        # Template files are processed later
        # Copy and return the path without .template
        new_path = template_path.replace(".template.spec", ".spec")
        shutil.copyfile(
            self.certora_dir / Path(template_path), self.certora_dir / Path(new_path)
        )
        return new_path

    def generate_contract_summaries_spec(self, contract_name: str, verified_functions: Set[str]) -> Path:
        """Generate a contract-specific summaries file with appropriate imports."""
        contract_summaries_path = self.certora_dir / f"summaries-{contract_name}.spec"

        # Create certora directory if it doesn't exist
        self.certora_dir.mkdir(parents=True, exist_ok=True)

        # Use a set to track unique import paths and avoid duplicates
        unique_imports = set()
        for func_name in verified_functions:
            func_info = self.function_summaries[func_name]
            import_path: str = func_info[
                "summary_file"
            ]  # e.g., "Summaries/OpenZeppelin/Math.spec"

            # Check if it's a template file that needs processing
            if import_path.endswith(".template.spec"):
                import_path = self.process_template_file(import_path)
                self.templates.add(import_path)

            unique_imports.add(import_path)

        # Check if contract-specific LLM summaries exist and add import
        llm_summaries_path = self.certora_dir / f"llm_summaries-{contract_name}.spec"
        if llm_summaries_path.exists():
            unique_imports.add(f"llm_summaries-{contract_name}.spec")

        # Convert to sorted list for deterministic output
        imports = [f'import "{import_path}";' for import_path in sorted(unique_imports)]

        # Write the contract-specific summaries file
        with open(contract_summaries_path, "w") as f:
            if imports:
                f.write(f"// Auto-generated summaries for {contract_name}\n")
                f.write("// Generated by setup_summaries.py\n\n")
                for imp in imports:
                    f.write(f"{imp}\n")
                self.log(
                    f"Generated {contract_summaries_path} with {len(imports)} import(s)",
                    "SUCCESS",
                )
            else:
                f.write(
                    f"// No summaries needed for {contract_name} - no matching function calls detected\n"
                )
                self.log(f"No summaries needed for {contract_name} - no matching function calls detected")

        return contract_summaries_path

    def update_spec_files(self, summaries_spec_path: Path):
        """Update all spec files in certora directories to import summaries.spec."""
        # Find all spec files in certora subdirectories
        spec_patterns = ["certora/**/*.spec", "certora/**/*.template.spec"]

        spec_files: list = []
        for pattern in spec_patterns:
            spec_files.extend(Path.cwd().glob(pattern))

        # Exclude the summaries.spec file itself, llm_summaries.spec, and any files in Summaries directory
        spec_files = [
            f
            for f in spec_files
            if f != summaries_spec_path
            and "Summaries" not in str(f)
            and "llm_summaries" not in str(f)
        ]

        updated_count = 0
        for spec_file in spec_files:
            try:
                with open(spec_file, "r") as f:
                    content = f.read()

                # Check if summaries.spec is already imported
                if "import.*summaries\\.spec" in content or "summaries.spec" in content:
                    self.log(f"Skipping {spec_file} - already imports summaries.spec")
                    continue

                # Calculate relative path from spec file to summaries.spec
                relative_path = os.path.relpath(summaries_spec_path, spec_file.parent)
                import_statement = f'import "{relative_path}";\n'

                # Simply add import at the very top of the file
                lines = content.split("\n")
                lines.insert(0, import_statement)

                # Write back the updated content
                with open(spec_file, "w") as f:
                    f.write("\n".join(lines))

                updated_count += 1
                self.log(f"Updated {spec_file} with summaries import")

            except Exception as e:
                raise Exception(f"Error updating {spec_file}: {e}")

        if updated_count > 0:
            self.log(
                f"Updated {updated_count} spec file(s) with summaries import", "SUCCESS"
            )
        else:
            self.log("No spec files needed updating")

    def should_process_file(self, file_path: str) -> bool:
        """Check if a file should be processed (not a dependency or internal file).

        Uses the same logic as other functionalities for consistency.
        """
        # Convert to Path for easier manipulation
        path = Path(file_path)
        path_str = str(path)

        # Skip .certora_internal directory
        if ".certora_internal" in path.parts:
            return False

        # Skip dependency directories
        if any(pattern in path_str for pattern in DEPENDENCIES):
            return False

        # Skip test and script files if not explicitly included
        if path.name.endswith(".t.sol") or path.name.endswith(".s.sol"):
            return False

        return True

    def _make_decimal_summary_call(
        self,
        prompt: str,
        model: str,
        max_tokens: int,
        max_retries: int = 10,
        log_to_file: bool = False,
        log_path: Path | None = None,
    ) -> Optional[DecimalAnalysisResult]:
        """Make an API call with exponential backoff retry for rate limits, with custom model and token settings."""
        # Convert Path to string if provided
        log_path_str = str(log_path) if log_path else None

        return call_llm_structured(
            prompt=prompt,
            ty=DecimalAnalysisResult,
            model=model,
            max_tokens=max_tokens,
            temperature=0.0,
            max_retries=max_retries,
            log_to_file=log_to_file,
            log_path=log_path_str,
            verbose=False,
        )

    async def _make_match_analysis_call(
        self,
        system_prompt: str,
        user_prompt: str,
        model: str,
        max_tokens: int,
        max_retries: int = 10,
        log_to_file: bool = False,
        log_path: Path | None = None,
    ) -> Optional[MatchAnalysis]:
        """Make an API call with exponential backoff retry for rate limits, with custom model and token settings."""
        # Convert Path to string if provided
        log_path_str = str(log_path) if log_path else None

        return await call_llm_async_structured_cached(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            ty=MatchAnalysis,
            model=model,
            max_tokens=max_tokens,
            temperature=0.0,
            max_retries=max_retries,
            log_to_file=log_to_file,
            log_path=log_path_str,
            verbose=False,
        )


    def _generate_function_declaration(self, method: Dict[str, Any], is_wildcard: bool) -> str:
        """Generate a CVL function declaration from structured method data.

        Uses parameter types, names, locations, and return types from the method dict
        (populated from Certora build data via all_methods.json).

        Returns:
            CVL function declaration string.
        """
        contract_name = method["contractName"] if not is_wildcard else "_"
        method_name = method["name"]

        # Map Solidity visibility to CVL visibility
        solidity_visibility = method["visibility"]
        cvl_visibility = "internal" if solidity_visibility == "public" else solidity_visibility

        def classify_solidity_type(sol_type: str) -> tuple[str, str]:
            """
            Classify a Solidity type and return the CVL type.
            Returns (cvl_type, classification) where classification is 'primitive', 'contract', 'struct', 'enum', or 'unknown'.
            """
            type_info = self.type_analyzer._resolve_type_from_string(sol_type)
            match type_info.category:
                case TypeCategory.PRIMITIVE:
                    return type_info.cvl_name, "primitive"
                case TypeCategory.CONTRACT:
                    return "address", "contract"
                case TypeCategory.BYTES:
                    return "bytes", "primitive"
                case TypeCategory.STRING:
                    return "string", "primitive"
                case TypeCategory.ARRAY:
                    return type_info.cvl_name, "primitive"
                case TypeCategory.STRUCT:
                    return type_info.cvl_name, "struct"
                case TypeCategory.ENUM:
                    return type_info.cvl_name, "enum"
                case _:
                    return sol_type, "unknown"

        def is_array_type(sol_type: str) -> bool:
            """Check if a type is any kind of array (dynamic, static, or nested)."""
            return bool(re.search(r"\[\d*\]", sol_type))

        # Extract structured data from the method dict
        param_types = method.get("fullSignature", [])
        param_names = method.get("paramNames", [])
        locations = method.get("location", [])
        return_types = method.get("returns", [])

        # Build CVL parameter list
        params = []
        for i, param_type in enumerate(param_types):
            param_name = param_names[i] if i < len(param_names) and param_names[i] else f"arg{i}"
            location = locations[i] if i < len(locations) else ""

            cvl_type, classification = classify_solidity_type(param_type)

            if classification == "primitive":
                # For internal functions, preserve memory/calldata location for reference types
                needs_location = cvl_type in ["bytes", "string"] or is_array_type(cvl_type)
                if cvl_visibility == "internal" and needs_location and location in ("memory", "calldata"):
                    params.append(f"{cvl_type} {location} {param_name}")
                else:
                    params.append(f"{cvl_type} {param_name}")
            elif classification == "contract":
                params.append(f"{cvl_type} {param_name}")
            elif classification == "struct":
                # Structs are reference types - need location for internal functions
                if cvl_visibility == "internal" and location in ("memory", "calldata"):
                    params.append(f"{cvl_type} {location} {param_name}")
                else:
                    params.append(f"{cvl_type} {param_name}")
            elif classification == "enum":
                params.append(f"{cvl_type} {param_name}")
            else:
                params.append(f"... /* {param_type} {param_name} - needs manual fix */")

        # Build CVL return type list
        returns = []
        for ret_type in return_types:
            cvl_type, classification = classify_solidity_type(ret_type)
            if classification in ("primitive", "contract", "struct", "enum"):
                returns.append(cvl_type)
            else:
                returns.append(f"... /* {ret_type} - needs manual fix */")

        param_list = ", ".join(params) if params else ""

        # Build the declaration — wildcard declarations must not include a `returns` clause
        if returns and not is_wildcard:
            return_list = ", ".join(returns)
            declaration = f"function {contract_name}.{method_name}({param_list}) {cvl_visibility} returns ({return_list})"
        else:
            declaration = f"function {contract_name}.{method_name}({param_list}) {cvl_visibility}"

        return declaration

    def _get_cache_key(self, prompt: str, model: str) -> str:
        """Generate a cache key from prompt and model."""
        import hashlib

        # Use hash to create a consistent key from prompt + model
        content = f"{model}::{prompt}"
        return hashlib.sha256(content.encode()).hexdigest()

    def _load_from_cache(
        self, prompt: str, model: str, method_info: str | None = None
    ) -> Optional[str]:
        """Load cached response if available."""
        cache_dir = Path(".certora_internal/llm_cache")
        if not cache_dir.exists():
            return None

        cache_key = self._get_cache_key(prompt, model)
        cache_file = cache_dir / f"{cache_key}.json"

        if cache_file.exists():
            try:
                with open(cache_file, "r") as f:
                    cache_data = json.load(f)
                    # Verify it's the same prompt/model (for debugging)
                    if cache_data.get("model") == model:
                        if method_info:
                            self.log(
                                f"Cache hit for {method_info} using {model}", "DEBUG"
                            )
                        else:
                            self.log(f"Cache hit for {model} query", "DEBUG")
                        return cache_data.get("response")
            except Exception as e:
                raise Exception(f"Error reading cache: {e}")

        return None

    def _save_to_cache(self, prompt: str, model: str, response: str):
        """Save response to cache."""
        cache_dir = Path(".certora_internal/llm_cache")
        cache_dir.mkdir(parents=True, exist_ok=True)

        cache_key = self._get_cache_key(prompt, model)
        cache_file = cache_dir / f"{cache_key}.json"

        try:
            cache_data = {
                "model": model,
                "prompt": prompt[:500],  # Store first 500 chars for debugging
                "response": response,
                "timestamp": datetime.now().isoformat(),
            }
            with open(cache_file, "w") as f:
                json.dump(cache_data, f, indent=2)
        except Exception as e:
            self.log(f"Error saving to cache: {e}", "DEBUG")

    async def _call_llm_model(
        self,
        model: str,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        log_path: Path,
        model_name: str,
        cache_stats: CacheStats | None = None,
        method_info: str | None = None,
    ) -> MatchAnalysis:
        """Call a specific LLM model and return parsed result, using cache when available."""
        # Check cache first (key is derived from the full prompt content)
        prompt = system_prompt + user_prompt
        cached_answer = self._load_from_cache(prompt, model, method_info)

        answer: MatchAnalysis | None = None
        try:
            if cached_answer is not None:
                answer = MatchAnalysis.model_validate_json(cached_answer)
                if cache_stats is not None:
                    cache_stats["hits"] += 1
                with open(log_path, "a") as f:
                    f.write(f"{model_name} Response (cached): {cached_answer}\n")
        except ValidationError:
            pass

        if answer is None:
            # Make API call
            if cache_stats is not None:
                cache_stats["misses"] += 1
            try:
                # Use the existing retry mechanism for rate limits
                answer = await self._make_match_analysis_call(
                    system_prompt, user_prompt, model, max_tokens, log_to_file=True, log_path=log_path
                )

                if answer is None:
                    # Rate limit or other error exceeded max retries
                    self.log(f"{model_name} analysis failed after retries", "WARNING")
                    return MatchAnalysis(is_match= False, explanation="")

                # Save to cache
                self._save_to_cache(prompt, model, answer.model_dump_json())

                with open(log_path, "a") as f:
                    f.write(f"{model_name} Response: {answer}\n")

            except Exception as e:
                self.log(f"{model_name} analysis failed: {e}", "WARNING")
                with open(log_path, "a") as f:
                    f.write(f"{model_name} Error: {e}\n")
                return MatchAnalysis(is_match =False, explanation="")

        # Parse the answer (whether from cache or API)
        return answer

    def _get_method_signature(self, method: Dict[str, Any], contract_code: str) -> str:
        """Extract the full method signature from contract code."""
        method_name = method["name"]
        expected_param_count = method.get("paramCount", 0)

        # Try to find the method signature in the contract code
        import re

        # Pattern to match function declaration with parameters
        pattern = rf"function\s+{re.escape(method_name)}\s*\(([^)]*)\)"

        # Find all matches for potential overloaded functions
        matches = list(re.finditer(pattern, contract_code))

        # If we have multiple matches, find the one with matching parameter count
        for match in matches:
            params = match.group(1).strip()

            # Count parameters in this match
            if params:
                # Split by comma but be careful with nested parentheses (for tuples, arrays, etc.)
                param_count = 1  # At least one parameter if params is not empty
                paren_depth = 0
                for char in params:
                    if char == "(" or char == "[":
                        paren_depth += 1
                    elif char == ")" or char == "]":
                        paren_depth -= 1
                    elif char == "," and paren_depth == 0:
                        param_count += 1
            else:
                param_count = 0

            # Check if this match has the expected parameter count
            if param_count != expected_param_count:
                continue  # Try next match

            # Clean up the parameters (remove variable names, keep only types)
            if params:
                # Simple cleanup - this could be more sophisticated
                param_parts = []
                for param in params.split(","):
                    param = param.strip()
                    # Take just the type part (first word(s) before variable name)
                    words = param.split()
                    if words:
                        # Handle types like "uint256", "address payable", etc.
                        if len(words) > 1 and words[1] in [
                            "memory",
                            "storage",
                            "calldata",
                            "payable",
                        ]:
                            param_parts.append(f"{words[0]} {words[1]}")
                        else:
                            param_parts.append(words[0])
                return f"{method_name}({', '.join(param_parts)})"
            else:
                return f"{method_name}()"

        # Fallback to just the method name if no matching signature found
        return method_name

    def _create_system_prompt(
        self,
        contract_code: str,
        contract_file: str,
        recipe: Recipe,
    ) -> str:
        """Create system prompt containing contract code and recipe framing. Shared across all methods in the same contract+recipe."""
        if recipe.recipe_type == RecipeType.NEW_CONTRACT:
            return f"""You are analyzing a Solidity contract to determine if specific methods create new contracts.

Contract file: {contract_file}

Contract code:
```solidity
{contract_code}
```

Look specifically for:
1. Use of the 'new' keyword followed by a contract name
2. Contract instantiation patterns
3. Factory pattern implementations

For each method you are asked about, set is_match to true if the method creates new contracts, false otherwise. Provide a single-sentence explanation."""
        else:
            return f"""You are analyzing a Solidity contract to determine if specific methods {recipe.characteristic}.

Contract file: {contract_file}

Contract code:
```solidity
{contract_code}
```

For each method you are asked about, set is_match to true if the method {recipe.characteristic}, false otherwise. Provide a single-sentence explanation."""

    def _create_user_prompt(
        self,
        method: Dict[str, Any],
        contract_code: str,
        recipe: Recipe,
    ) -> str:
        """Create user prompt containing method-specific details. Varies per method."""
        method_signature = self._get_method_signature(method, contract_code)

        if recipe.recipe_type == RecipeType.NEW_CONTRACT:
            return f"""Analyze the method '{method_signature}' and determine if it creates new contracts using the 'new' keyword.

Method signature: {method_signature}
- Visibility: {method["visibility"]}
- State Mutability: {method["stateMutability"]}"""
        else:
            return f"""Analyze the method '{method_signature}' and determine if it {recipe.characteristic}.

Method signature: {method_signature}
- Visibility: {method["visibility"]}
- State Mutability: {method["stateMutability"]}"""

    async def _analyze_method_with_llm(
        self,
        method: dict,
        contract_code: str,
        recipe: Recipe,
        cache_stats: CacheStats,
        llm_log_path: Path,
        method_full_name: str,
        system_prompt: str,
    ) -> Optional[dict]:
        # Stage 1: Fast filtering with Haiku
        user_prompt = self._create_user_prompt(method, contract_code, recipe)

        haiku_result = await self._call_llm_model(
            "claude-haiku-4-5-20251001",
            system_prompt,
            user_prompt,
            200,
            llm_log_path,
            "Haiku",
            cache_stats,
            method_full_name,
        )

        if haiku_result.is_match:
            self.log(
                f"Haiku: {method_full_name} potentially matches - checking with Sonnet"
            )

            # Stage 2: Confirmation with Sonnet
            sonnet_result = await self._call_llm_model(
                MODEL_SONNET,
                system_prompt,
                user_prompt,
                500,
                llm_log_path,
                "Sonnet",
                cache_stats,
                method_full_name,
            )

            if sonnet_result.is_match:
                # Store method with Sonnet's explanation (more detailed and accurate)
                method_with_summary = method.copy()
                method_with_summary["_summary_type"] = recipe.summary_type
                method_with_summary["_recipe_characteristic"] = (
                    recipe.characteristic
                )
                method_with_summary["_ai_explanation"] = sonnet_result.explanation
                self.log(
                    f"✓ Both LLMs agree: {method_full_name} matches criteria"
                )

                with open(self.llm_log_path, "a") as f:
                    f.write("Final Decision: MATCH (both models agree)\n")
                    f.write(
                        f"Using Sonnet's explanation: {sonnet_result.explanation}\n\n"
                    )
                return method_with_summary

            else:
                self.log(
                    f"✗ Disagreement: Haiku said yes, Sonnet said no for {method_full_name}"
                )
                with open(self.llm_log_path, "a") as f:
                    f.write("Final Decision: NO MATCH (Sonnet disagreed)\n\n")
        else:
            with open(self.llm_log_path, "a") as f:
                f.write("Haiku Decision: NO MATCH (skipping Sonnet)\n\n")
        return None


    async def _analyze_method_with_llm_gated(
        self,
        method: dict,
        contract_code: str,
        recipe: Recipe,
        cache_stats: CacheStats,
        llm_log_path: Path,
        method_full_name: str,
        system_prompt: str,
        processed: asyncio.Queue[None | Literal[True]],
        sem: asyncio.Semaphore,
    ) -> Optional[dict]:
        async with sem:
            l = await self._analyze_method_with_llm(
                method, contract_code, recipe, cache_stats, llm_log_path, method_full_name,
                system_prompt,
            )
            await processed.put(None)
            return l

    def analyze_with_llm(
        self,
        recipe: Recipe,
        contract_files: Set[str],
        methods_to_skip: Set[Tuple[str, str]] | None = None,
        main_contract: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Analyze methods using LLM based on a recipe.

        Args:
            recipe: Recipe containing characteristic, properties, and summary_type
            contract_files: Set of Solidity files to analyze
            methods_to_skip: Set of (contract, method) pairs to skip (already marked for
                summarization by non-LLM step or matched by previous LLM recipes)
            main_contract: Optional main contract name to filter methods by originatingContract

        Returns:
            List of methods that match the criteria, excluding methods in methods_to_skip
        """
        if methods_to_skip is None:
            methods_to_skip = set()

        # Load method information
        methods_file = Path(".certora_internal/all_methods.json")
        if not methods_file.exists():
            self.log(
                "all_methods.json not found. Run orchestrator with compilation analysis first.",
                "ERROR",
            )
            return []

        mp = MethodParser(str(methods_file))

        # Filter methods by properties and originatingContract
        all_methods = mp.get_all_methods()
        filtered_methods = []

        for method in all_methods:
            # Filter by originating contract if main_contract is specified
            if main_contract and method.get("originatingContract") != main_contract:
                continue
            method_key = (method["contractName"], method["name"])

            # Check if method matches required properties
            matches = True
            for prop, value in recipe.properties.items():
                if prop in method:
                    # Handle both single values and lists of values
                    if isinstance(value, list):
                        if method[prop] not in value:
                            matches = False
                            break
                    else:
                        if method[prop] != value:
                            matches = False
                            break

            if matches:
                # Skip methods with storage location parameters (internal-only, can't generate valid summaries)
                if any(loc == "storage" for loc in method.get("location", [])):
                    continue

                # Skip if this method was already matched by a previous recipe
                if method_key not in methods_to_skip:
                    filtered_methods.append(method)

        if not filtered_methods:
            self.log(f"No methods found matching properties: {recipe.properties}")
            return []

        self.log(
            f"Found {len(filtered_methods)} methods matching property filters (after duplicate filtering)"
        )

        self.log(f"Will send {len(filtered_methods)} methods to LLM for analysis")

        # Log session start to .certora_internal/llm.log
        llm_log_path = Path(".certora_internal/llm.log")
        llm_log_path.parent.mkdir(parents=True, exist_ok=True)

        with open(self.llm_log_path, "a") as f:
            f.write(f"\n{'=' * 80}\n")
            f.write(f"LLM Analysis Session: {datetime.now().isoformat()}\n")
            f.write(f"Recipe: {recipe.characteristic}\n")
            f.write(f"Properties: {recipe.properties}\n")
            f.write(f"{'=' * 80}\n\n")

        processed_count = 0
        cache_stats : CacheStats = {"hits": 0, "misses": 0}

        # Combine contract files and library files for processing
        all_files_to_process = set(contract_files) | set(self.solidity_files_libraries)

        # Process each contract/library file that contains filtered methods

        sem = asyncio.Semaphore(2)

        q : asyncio.Queue[None | Literal[True]] = asyncio.Queue()

        async def monitor_loop():
            processed = 0
            while True:
                d = await q.get()
                if d is None:
                    processed+=1
                    if processed % 50 == 0:
                        self.log(
                            f"LLM Progress: Processed {processed_count} methods so far..."
                        )
                else:
                    # other option is the poison pill `True`, we're done
                    return

        tasks : list[Coroutine[Any, Any, dict | None]] = []

        async def task_runner() -> list[dict | None]:
            try:
                return await asyncio.gather(*tasks)
            finally:
                # kill the queue
                await q.put(True)

        for contract_file in all_files_to_process:
            # Use consistent filtering logic
            if not self.should_process_file(contract_file):
                continue

            # Check if this file has any of our filtered methods
            contract_name = Path(contract_file).stem
            file_methods = [
                m for m in filtered_methods if m["contractName"] == contract_name
            ]

            if not file_methods:
                continue

            # Read the contract file
            try:
                with open(contract_file, "r") as f:
                    contract_code = f.read()
            except Exception as e:
                raise Exception(f"Error reading {contract_file}: {e}")

            # Compute system prompt once per contract file (shared across all methods)
            system_prompt = self._create_system_prompt(contract_code, contract_file, recipe)

            # Analyze each method with two-stage LLM approach
            for method in file_methods:
                # Get method signature for better logging
                method_signature = self._get_method_signature(method, contract_code)
                method_full_name = f"{contract_name}.{method_signature}"

                task = self._analyze_method_with_llm_gated(
                    method=method,
                    cache_stats=cache_stats,
                    contract_code=contract_code,
                    llm_log_path=llm_log_path,
                    method_full_name=method_full_name,
                    recipe=recipe,
                    system_prompt=system_prompt,
                    processed=q,
                    sem=sem,
                )
                tasks.append(task)

        async def entry() -> list[dict | None]:
            l, _ = await asyncio.gather(
                task_runner(),
                monitor_loop()
            )
            return l

        l = asyncio.run(entry())

        matching_methods = [ m for m in l if m is not None]
        cache_hits = cache_stats["hits"]
        cache_misses = cache_stats["misses"]

        # Log summary and final progress
        if processed_count > 0:
            total_calls = cache_hits + cache_misses
            hit_rate = (cache_hits / total_calls * 100) if total_calls > 0 else 0
            self.log(
                f"LLM Analysis Complete: Processed {processed_count} methods, found {len(matching_methods)} matches"
            )
            self.log(
                f"Cache statistics: {cache_hits} hits, {cache_misses} misses ({hit_rate:.1f}% hit rate)"
            )

        with open(self.llm_log_path, "a") as f:
            f.write(f"Total processed: {processed_count}\n")
            f.write(f"Total matches: {len(matching_methods)}\n")
            f.write(f"{'=' * 80}\n")

        return matching_methods

    def _get_function_signature(self, method: Dict[str, Any], is_wildcard: bool) -> str:
        """Get function signature for a method."""
        return self._generate_function_declaration(method, is_wildcard)

    def _generate_decimal_conversion_summary(
        self, method: Dict[str, Any], contract_files: List[str]
    ) -> tuple[str, str] | None:
        """Use LLM to generate decimal conversion summary and CVL function."""
        try:
            # Get function source code
            contract_name = method["contractName"]
            method_name = method["name"]

            # Find the contract file
            contract_file = None
            for file_path in contract_files:
                if Path(file_path).stem == contract_name:
                    contract_file = file_path
                    break

            if not contract_file:
                return None

            try:
                with open(contract_file, "r") as f:
                    contract_code = f.read()
            except:
                return None

            # Extract the function implementation
            import re

            pattern = rf"function\s+{re.escape(method_name)}\s*\([^)]*\).*?(?=function\s+\w+|contract\s+\w+|interface\s+\w+|library\s+\w+|$)"
            match = re.search(pattern, contract_code, re.DOTALL)

            if not match:
                return None

            function_code = match.group(0)

            # Get function signature
            func_sig = self._get_function_signature(method, is_wildcard=True)

            # TODO 1: unify with the regular function declaration generation logic xml,
            # TODO 2: Do not use wildcard
            # Create LLM prompt
            prompt = f"""
            You are analyzing a Solidity function for decimal/precision conversion and need to generate a CVL summary.

            CVL Instructions:
            - Function summaries can call CVL functions with specific parameters
            - For wildcard summaries: function _.methodName($PARAMETERS$) internal => cvl_function_name(specific_parameter) expect <return_type>;
            - The "expect <return_type>" clause is REQUIRED for wildcard summaries that call CVL functions
            - CVL functions are defined outside the methods block

            Function signature: {func_sig}
            Function implementation:
            ```solidity
            {function_code}
            ```

            This function converts amounts between different decimal precisions. I need you to:

            1. Deduce the parameters names and types.
            2. Identify which parameter represents the input amount to be converted. It has to be a primitive numeric type (e.g., uint256, int, etc.) of the summarized function. It MUST appear in the parameter list. If multiple such parameters exist, choose the one that is most likely to be the amount (e.g., named `amount`, `value`, `qty`, etc.). If no such parameter exists, return an "InvalidSummary".
            3. Determine the return type of the function being summarized. Common types are uint256, uint128, int256, etc. If uncertain, use uint256.

            The type of the amount parameter must must be a subtype (according to Solidity) of the return type. If you cannot follow these instructions, use InvalidSummary
            """

            # Call LLM using existing infrastructure

            try:
                # Use Claude Opus 4.5 for complex decimal conversion analysis
                opus_model = "claude-opus-4-5-20251101"
                response = self._make_decimal_summary_call(
                    prompt,
                    opus_model,
                    max_tokens=2000,
                    log_to_file=True,
                    log_path=self.llm_log_path,
                )
            except Exception as e:
                raise Exception(f"Failed to call LLM API: {e}")

            if not response:
                return None

            # Debug: log the raw response
            if self.verbose:
                self.log(
                    f"Raw LLM response for decimal conversion: {response.model_dump_json()}",
                    "DEBUG",
                )

            if response.res_failed:
                self.log(
                    f"Failed to summarize decimal conversion: {response.res_failed.explanation}",
                    "WARNING"
                )
                return None

            result = response.res_success
            if not result:
                self.log(
                    f"No result set for {method_name}",
                    "WARNING"
                )
                return None

            # Try to extract JSON from the response (sometimes LLM adds extra text)
            summary_line = result.summary_line.strip()
            cvl_function = result.cvl_function.strip()
            return (summary_line, cvl_function)
        except Exception as e:
            raise Exception(f"Error generating decimal conversion summary: {e}")

    def generate_contract_llm_summaries(self, matching_methods: List[Dict[str, Any]], contract_name: str) -> bool:
        """Generate llm_summaries-{contract_name}.spec file with CVL summaries for matching methods.

        Args:
            matching_methods: List of methods to summarize (each with '_summary_type' field)
            contract_name: Name of the contract to generate summaries for

        Returns:
            True if summaries were generated successfully
        """
        if not matching_methods:
            return False

        spec_path = self.certora_dir / f"llm_summaries-{contract_name}.spec"

        # Use pre-computed contract files (without dependencies, no test files)
        contract_files = self.solidity_files_no_dependencies

        # Generate CVL content
        content = [
            "// LLM-based method summaries",
            "// Auto-generated by setup_summaries.py",
            "",
            "methods {",
        ]

        # Group methods by summary type for better organization
        by_summary_type = defaultdict(list)
        for method in matching_methods:
            summary_type = method.get("_summary_type", "NONDET")
            by_summary_type[summary_type].append(method)

        # Sort summary types for deterministic output
        for summary_type in sorted(by_summary_type.keys()):
            methods = by_summary_type[summary_type]
            content.append(f"    // {summary_type} summaries")
            content.append("")

            # Sort methods within each summary type for deterministic output
            # Sort by contract name first, then method name
            sorted_methods = sorted(
                methods, key=lambda m: (m["contractName"], m["name"])
            )

            for method in sorted_methods:
                contract = method["contractName"]
                name = method["name"]
                # Add explanatory comment above the summary
                recipe_characteristic = method.get(
                    "_recipe_characteristic", "Unknown recipe"
                )
                ai_explanation = method.get(
                    "_ai_explanation", "No explanation provided"
                )

                # Build comment content
                comment_lines = []
                comment_lines.append(f"Recipe: {recipe_characteristic}")
                if ai_explanation and ai_explanation != "No explanation provided":
                    comment_lines.append(f"AI Analysis: {ai_explanation}")

                # Generate function declaration
                func_declaration = self._generate_function_declaration(method, is_wildcard=False)

                # Add helpful note if ellipsis is present
                if "..." in func_declaration and "/* " in func_declaration:
                    comment_lines.append(
                        "TODO: Manual fix needed - replace ellipsis with proper parameter types"
                    )

                # Generate block comment
                content.append("    /*")
                for line in comment_lines:
                    content.append(f"     * {line}")
                content.append("     */")

                # Generate appropriate CVL summary based on type
                if summary_type.upper() == "NONDET":
                    if method["stateMutability"] in ["view", "pure"]:
                        # For view/pure functions, return non-deterministic value (no returns clause for wildcard)
                        content.append(f"    {func_declaration} => NONDET;")
                    else:
                        self.log(
                            f"Warning: Cannot use NONDET for non-view method {contract}.{name}",
                            "WARNING",
                        )
                elif summary_type.upper() == "HAVOC_ALL_DELETE":
                    # For functions that should be deleted (like contract creation functions)
                    if method["visibility"] == "external":
                        content.append(f"    {func_declaration} => HAVOC_ALL DELETE;")
                    else:
                        self.log(
                            f"Warning: HAVOC_ALL_DELETE should only be used for external methods, but {contract}.{name} is {method['visibility']}",
                            "WARNING",
                        )
                elif summary_type.upper() == "DECIMAL_CONVERSION_IDENTITY":
                    # For decimal conversion functions - use LLM to generate summary and CVL function
                    if method["stateMutability"] in ["view", "pure"]:
                        summary_and_function = (
                            self._generate_decimal_conversion_summary(
                                method, contract_files
                            )
                        )
                        if summary_and_function:
                            summary_line, cvl_function = summary_and_function
                            content.append(
                                "    // WARNING: This summary assumes no decimal conversion (identity function)"
                            )
                            content.append(
                                "    // This is UNSOUND and very limiting - should be generalized in the future"
                            )
                            content.append(f"    {summary_line}")
                            # Store CVL function to be added at the end (using dict to avoid duplicates)
                            if not hasattr(self, "_cvl_functions"):
                                self._cvl_functions = {}  # Use dict with function signature as key
                            # Extract function name to use as key for deduplication
                            import re

                            func_name_match = re.search(
                                r"function\s+(\w+)\s*\(", cvl_function
                            )
                            if func_name_match:
                                func_name = func_name_match.group(1)
                                self._cvl_functions[func_name] = cvl_function
                        else:
                            # If LLM fails to generate decimal conversion summary, add comment with signature only
                            func_declaration = self._get_function_signature(method, is_wildcard=False)
                            content.append(
                                f"    // Excluded from decimal conversion analysis: {func_declaration}"
                            )
                    else:
                        self.log(
                            f"Warning: DECIMAL_CONVERSION_IDENTITY should only be used for view/pure methods, but {contract}.{name} is {method['stateMutability']}",
                            "WARNING",
                        )
                else:
                    self.log(f"Unknown summary type: {summary_type}", "WARNING")

                content.append("")  # Blank line after each summary

            content.append("")  # Extra blank line between summary types

        content.append("}")
        content.append("")

        # Add CVL functions for decimal conversion summaries if any
        if hasattr(self, "_cvl_functions") and self._cvl_functions:
            content.append("// CVL functions for decimal conversion summaries")
            content.append("")
            # Iterate over unique CVL functions (dict values)
            for cvl_function in self._cvl_functions.values():
                content.append(cvl_function)
                content.append("")

        # Ensure certora directory exists before writing
        self.certora_dir.mkdir(parents=True, exist_ok=True)

        # Write the spec file
        with open(spec_path, "w") as f:
            f.write("\n".join(content))

        self.log(f"Generated LLM summaries for {contract_name} in {spec_path}")

        return True

    def run_llm_analysis(
        self,
        contract_files: List[str],
        main_contracts: List[str],
        custom_recipe: Optional[str] = None,
        force_llm_regenerate: bool = False,
        previously_marked_for_summarization: Optional[Dict[str, Set[Tuple[str, str]]]] = None,
    ) -> bool:
        """Run LLM-based analysis with predefined or custom recipes.

        Args:
            contract_files: List of Solidity files to analyze
            main_contracts: List of main contract names to filter methods by
            custom_recipe: Optional JSON string with custom recipe
            force_llm_regenerate: Force regeneration of LLM summaries even if they exist
            previously_marked_for_summarization: Dict mapping contract names to sets of
                (contractName, method_name) tuples for methods already marked for
                summarization by non-LLM step (to avoid duplicate analysis)

        Returns:
            True if any summaries were generated
        """

        # Define recipes using dataclass
        recipes = []

        if custom_recipe:
            # Parse custom recipe from JSON
            try:
                recipe_data = json.loads(custom_recipe)
                recipes.append(
                    Recipe(
                        recipe_type=RecipeType.CUSTOM,
                        characteristic=recipe_data["characteristic"],
                        properties=recipe_data["properties"],
                        summary_type=recipe_data.get("summary_type", "NONDET"),
                    )
                )
                self.log(f"Using custom recipe: {recipe_data['characteristic']}")
            except Exception as e:
                raise Exception(f"Error parsing custom recipe: {e}")
        else:
            # Use default recipes
            recipes = [
                Recipe(
                    recipe_type=RecipeType.PRICE_COMPUTATION,
                    characteristic="computes a price",
                    properties={"stateMutability": "view"},
                    summary_type="NONDET",
                ),
                Recipe(
                    recipe_type=RecipeType.NEW_CONTRACT,
                    characteristic='creates a new contract using the "new" keyword',
                    properties={"visibility": "external"},
                    summary_type="HAVOC_ALL_DELETE",
                ),
                Recipe(
                    recipe_type=RecipeType.DECIMAL_CONVERSION,
                    characteristic='converts an amount from one precision or decimals to another precision or decimals, e.g., converting between token units. DO NOT INCLUDE methods that fetch a rate or a price, i.e. that rely on any kind of external information besides a call to "decimals" of e.g. an ERC20 token. Good example: `normalizeDecimals`. Bad example: `fetchRate` that contains a call to an oracle and then convert that rate. We want the underlying conversion logic, not the oracle interaction.',
                    properties={
                        "visibility": "internal",
                        "stateMutability": ["view", "pure"],
                    },
                    summary_type="DECIMAL_CONVERSION_IDENTITY",
                ),
                Recipe(
                    recipe_type=RecipeType.NONLINEAR_OPERATIONS,
                    characteristic="contains more than 3 non-linear operations (multiplication, division, exponentiation, or modulo)",
                    properties={"visibility": "internal", "stateMutability": "pure"},
                    summary_type="NONDET",
                ),
                Recipe(
                    recipe_type=RecipeType.INLINE_ASSEMBLY,
                    characteristic="contains inline assembly blocks with `mload` or `mstore` instructions",
                    properties={"visibility": "internal"},
                    summary_type="NONDET",
                ),
            ]

        # Sort recipes for deterministic order
        recipes_sorted = sorted(recipes, key=lambda r: r.characteristic)

        any_summaries_generated = False

        # Loop through each contract first, then recipes
        for contract_name in main_contracts:
            self.log(f"Processing LLM analysis for contract: {contract_name}")

            # Check if llm_summaries-{contract_name}.spec already exists
            llm_spec_path = self.certora_dir / f"llm_summaries-{contract_name}.spec"
            if self.verbose:
                self.log(
                    f"Checking LLM regeneration for {contract_name}: force_llm_regenerate={force_llm_regenerate}, file_exists={llm_spec_path.exists()}"
                )

            if not force_llm_regenerate and llm_spec_path.exists():
                self.log(
                    f"LLM summaries for {contract_name} already exist - skipping (use --force-llm-regenerate to regenerate)"
                )
                any_summaries_generated = True
                continue
            elif force_llm_regenerate:
                self.log(f"Force regeneration requested for {contract_name} - will regenerate LLM summaries")

            all_matches = []
            # Initialize with methods already marked for summarization by non-LLM step (if any)
            # plus track methods matched by LLM recipes to avoid duplicates within LLM analysis
            methods_to_skip = (
                previously_marked_for_summarization.get(contract_name, set()).copy()
                if previously_marked_for_summarization
                else set()
            )

            for recipe in recipes_sorted:
                self.log(f"Running LLM analysis for {contract_name}: {recipe.characteristic}")
                matches = self.analyze_with_llm(
                    recipe, set(contract_files), methods_to_skip, contract_name
                )
                if matches:
                    self.log(f"Found {len(matches)} methods in {contract_name} that {recipe.characteristic}")
                    for method in matches:
                        # Get method signature if we have contract code
                        method_display = f"{method['contractName']}.{method['name']}"
                        # Note: We don't have contract_code here easily, so we'll just use the name
                        # The detailed signature is already shown in the analysis logs
                        self.log(f"  - {method_display}")
                        # Track this method as matched (so other recipes won't re-match it)
                        methods_to_skip.add((method["contractName"], method["name"]))
                    all_matches.extend(matches)

            # Generate summaries for this contract if we found any matches
            if all_matches:
                # Check for duplicates in all_matches
                method_keys = [(m["contractName"], m["name"]) for m in all_matches]
                unique_keys = set(method_keys)
                if len(method_keys) != len(unique_keys):
                    self.log(
                        f"Warning: Found {len(method_keys) - len(unique_keys)} duplicate methods in all_matches for {contract_name}",
                        "WARNING",
                    )
                    # Remove duplicates while preserving order
                    seen = set()
                    unique_matches = []
                    for method in all_matches:
                        key = (method["contractName"], method["name"])
                        if key not in seen:
                            seen.add(key)
                            unique_matches.append(method)
                    all_matches = unique_matches
                    self.log(f"Deduplicated to {len(all_matches)} unique methods for {contract_name}")

                if self.generate_contract_llm_summaries(all_matches, contract_name):
                    any_summaries_generated = True

        return any_summaries_generated

    def _normalize_contract_name(self, name: str) -> str:
        """Normalize contract name by removing semicolons and anything after them."""
        return name.split(";")[0] if ";" in name else name

    def match_summaries_from_all_methods(
        self, main_contracts: List[str]
    ) -> Tuple[Dict[str, Set[str]], Dict[str, Set[Tuple[str, str]]]]:
        """Match function summaries against methods from all_methods.json.

        Args:
            main_contracts: List of main contract names to analyze

        Returns:
            Tuple of (function_keys_by_contract, method_tuples_by_contract):
            - function_keys_by_contract: Dict mapping contract names to sets of matched function summary keys
            - method_tuples_by_contract: Dict mapping contract names to sets of (contractName, method_name) tuples
        """
        # Load all_methods.json
        methods_file = Path(".certora_internal/all_methods.json")
        if not methods_file.exists():
            self.log("all_methods.json not found", "ERROR")
            return {}, {}

        mp = MethodParser(str(methods_file))

        function_keys_results = {}
        method_tuples_results = {}

        for contract_name in main_contracts:
            self.log(f"Matching summaries for {contract_name}...")
            # Filter to only methods that originate from this contract (compilation unit)
            contract_methods = mp.get_methods_by_originating_contract(contract_name)
            matched_functions = set()
            matched_method_tuples = set()

            for func_name, func_info in self.function_summaries.items():
                self.log(f"Checking for {func_info['description']} usage...", "DEBUG")

                # Match by name (disjunctive - match any name in list)
                if "names" in func_info:
                    for method in contract_methods:
                        if method["name"] in func_info["names"]:
                            # Optional: check library_name matches contractName
                            if "library_name" in func_info and func_info.get("library_name"):
                                if method["contractName"] == func_info["library_name"]:
                                    self.log(
                                        f"✓ Matched {func_info['description']} by name in {contract_name}"
                                    )
                                    matched_functions.add(func_name)
                                    matched_method_tuples.add((method["contractName"], method["name"]))
                                    break
                            else:
                                self.log(
                                    f"✓ Matched {func_info['description']} by name in {contract_name}"
                                )
                                matched_functions.add(func_name)
                                matched_method_tuples.add((method["contractName"], method["name"]))
                                break

                # Match by signature (disjunctive - match any signature in list)
                if "signatures" in func_info and func_name not in matched_functions:
                    for method in contract_methods:
                        method_sig = f"{method['name']}({','.join(method['fullSignature'])})"
                        if method_sig in func_info["signatures"]:
                            # Optional: check library_name matches contractName
                            if "library_name" in func_info and func_info.get("library_name"):
                                if method["contractName"] == func_info["library_name"]:
                                    self.log(
                                        f"✓ Matched {func_info['description']} by signature in {contract_name}: {method_sig}"
                                    )
                                    matched_functions.add(func_name)
                                    matched_method_tuples.add((method["contractName"], method["name"]))
                                    break
                            else:
                                self.log(
                                    f"✓ Matched {func_info['description']} by signature in {contract_name}: {method_sig}"
                                )
                                matched_functions.add(func_name)
                                matched_method_tuples.add((method["contractName"], method["name"]))
                                break

            function_keys_results[contract_name] = matched_functions
            method_tuples_results[contract_name] = matched_method_tuples
            self.log(f"Found {len(matched_functions)} summaries for {contract_name} ({len(matched_method_tuples)} method tuples)")

        return function_keys_results, method_tuples_results

    def run(
        self,
        contract_files: List[str] | None = None,
        skip_update: bool = False,
        include_test_files: bool = False,
        include_dependencies: bool = False,
        enable_llm: bool = False,
        force_llm_regenerate: bool = False,
        custom_recipe: Optional[str] = None,
    ) -> bool:
        """Run the complete setup process.

        Args:
            contract_files: List of contract files to analyze
            skip_update: Skip updating existing spec files
            include_test_files: Include test files in analysis
            include_dependencies: Include dependency files in analysis
            enable_llm: Enable LLM-based method analysis
            force_llm_regenerate: Force regeneration of LLM summaries
            custom_recipe: Optional custom LLM recipe JSON string
        """
        self.log("=== AUTOMATIC SUMMARY SETUP ===")

        # If no contract files provided, find all Solidity files
        if not contract_files:
            self.log("Searching for all Solidity files in the project...")
            contract_files = self.find_all_solidity_files(
                include_test_files=include_test_files,
                include_dependencies=include_dependencies,
            )

            if not contract_files:
                self.log("No Solidity files found in the project", "WARNING")
                return False

        # Step 1: Get main contract names
        main_contracts = self._load_logic_contracts_from_json()

        if not main_contracts:
            self.log("No main contracts found for analysis", "WARNING")
            return False

        self.log(f"Main contracts for analysis: {main_contracts}")

        # Step 2: Match function summaries from all_methods.json
        self.log("Matching function summaries from all_methods.json...")
        matched_functions, matched_method_tuples = self.match_summaries_from_all_methods(list(main_contracts))

        # Step 3: Copy summaries folder (needed for template processing)
        self.log("Copying Summaries folder...")
        self.certora_dir.mkdir(parents=True, exist_ok=True)
        self.copy_summaries_folder()

        # Step 4: Run LLM-based analysis if requested
        if enable_llm:
            self.log("Running LLM-based method analysis...")

            # Use the method tuples already computed during matching to avoid re-analyzing
            # methods that were already marked for summarization by the non-LLM step
            for contract_name in matched_method_tuples:
                num_tuples = len(matched_method_tuples[contract_name])
                if num_tuples > 0:
                    self.log(
                        f"Excluding {num_tuples} already-summarized method(s) from LLM analysis for {contract_name}",
                        "DEBUG"
                    )

            if self.run_llm_analysis(
                contract_files,
                main_contracts=list(main_contracts),
                custom_recipe=custom_recipe,
                force_llm_regenerate=force_llm_regenerate,
                previously_marked_for_summarization=matched_method_tuples,
            ):
                self.log("LLM-based summaries generated successfully", "SUCCESS")
        elif self.verbose:
            self.log("LLM analysis not enabled (use --enable-llm flag)", "INFO")

        # Step 5: Generate per-contract summaries and include LLM summaries import
        self.log("Generating contract-specific summaries...")
        contract_summaries = {}  # Track summaries per contract for reporting

        for contract_name, detected_functions in matched_functions.items():
            self.log(f"Processing summaries for {contract_name}...")

            # Generate contract-specific summaries file (even if empty)
            self.generate_contract_summaries_spec(contract_name, detected_functions)
            contract_summaries[contract_name] = detected_functions

            if not detected_functions:
                self.log(f"No summaries needed for {contract_name}", "INFO")

        # Report summary
        self.log("\n=== Summary Report ===")
        has_summaries = False
        for contract_name, summaries in contract_summaries.items():
            if summaries:
                has_summaries = True
                self.log(
                    f"✅ {contract_name}: {len(summaries)} summaries ({', '.join(sorted(summaries))})",
                    "SUCCESS",
                )
            else:
                self.log(f"ℹ️  {contract_name}: No summaries needed", "INFO")

        if not has_summaries:
            self.log("\nℹ️ Setup complete! No summaries were needed for any contract.", "INFO")
        else:
            self.log("\n✅ Setup complete!", "SUCCESS")

        return True


def main():
    parser = argparse.ArgumentParser(
        description="Automatic setup for contract summaries in Certora verification"
    )

    parser.add_argument(
        "contract_files",
        nargs="*",  # Changed from '+' to '*' to make it optional
        help="Solidity contract files to analyze (if not provided, analyzes all .sol files in project)",
    )

    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Enable verbose output (-v for basic, -vv for extra details)",
    )

    parser.add_argument(
        "--skip-update",
        action="store_true",
        help="Skip updating existing spec files with summaries import",
    )

    parser.add_argument(
        "--include-test-files",
        action="store_true",
        help="Include test (.t.sol) and script (.s.sol) files in analysis (default: excluded)",
    )

    parser.add_argument(
        "--include-dependencies",
        action="store_true",
        help="Include files in dependency directories (node_modules, lib, forge-std) in analysis (default: excluded)",
    )

    parser.add_argument(
        "--main-contract",
        type=str,
        help="Main contract name for template replacements (e.g., for PRB Math types)",
    )

    parser.add_argument(
        "--enable-llm",
        action="store_true",
        help="Enable LLM-based method analysis (requires ANTHROPIC_API_KEY in .env)",
    )

    parser.add_argument(
        "--force-llm-regenerate",
        action="store_true",
        help="Force regeneration of LLM summaries even if they already exist",
    )

    parser.add_argument(
        "--skip-non-llm",
        action="store_true",
        help="Skip all non-LLM processing (only run LLM analysis)",
    )

    parser.add_argument(
        "--llm-recipe", type=str, help="Custom recipe for LLM analysis (JSON format)"
    )

    args = parser.parse_args()

    # Validate contract files if provided
    if args.contract_files:
        for contract_file in args.contract_files:
            if not contract_file.endswith(".sol"):
                print(f"Error: {contract_file} is not a Solidity file", file=sys.stderr)
                sys.exit(1)
            if not Path(contract_file).exists():
                print(f"Error: {contract_file} does not exist", file=sys.stderr)
                sys.exit(1)

    # Run the setup
    setup = SummarySetup(verbose=args.verbose)

    # If skip-non-llm is set, only run LLM analysis
    if args.skip_non_llm:
        if args.enable_llm:
            setup.log("Running LLM analysis only (skipping non-LLM processing)")

            # Load main contracts
            main_contracts = setup._load_logic_contracts_from_json()
            if not main_contracts:
                print("Error: No main contracts found in logic_contracts.json", file=sys.stderr)
                sys.exit(1)

            success = setup.run_llm_analysis(
                contract_files=args.contract_files if args.contract_files else [],
                main_contracts=list(main_contracts),
                custom_recipe=args.llm_recipe,
                force_llm_regenerate=args.force_llm_regenerate,
            )
        else:
            print("Error: --skip-non-llm requires --enable-llm")
            sys.exit(1)
    else:
        success = setup.run(
            args.contract_files if args.contract_files else None,
            skip_update=args.skip_update,
            include_test_files=args.include_test_files,
            include_dependencies=args.include_dependencies,
            enable_llm=args.enable_llm,
            force_llm_regenerate=args.force_llm_regenerate,
            custom_recipe=args.llm_recipe,
        )

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
