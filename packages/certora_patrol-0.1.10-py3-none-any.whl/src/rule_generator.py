"""
Rule Generator Module - Handles generator caching and regeneration logic.

This module provides utilities for:
- Determining when generators need to be re-run
- Caching generator configuration
- Managing generator cache keys
- Running the actual generators for GenericRules, ExternalCallChecker, and PrivilegedOperations
"""

import hashlib
import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from src.setup.signature_types import InheritanceGraph
from src.utils.types import ContractHandle

# Import generator functions from generic_checkers folder
from src.generic_checkers.GenericRules.scripts.generate_generic_checker import validate_args as validate_generic_args, process_templates as process_generic_templates
from src.generic_checkers.ExternalCallChecker.scripts.generate_extcall_checker import validate_args as validate_extcall_args, process_templates as process_extcall_templates
from src.generic_checkers.PrivilegedOperations.scripts.generate_privileged_checker import validate_args as validate_privileged_args, process_templates as process_privileged_templates
from src.generic_checkers.InputValidationChecker.scripts.generate_input_validation_checker import validate_args as validate_input_validation_args, process_templates as process_input_validation_templates


@dataclass
class GeneratorConfig:
    """Configuration for rule generator caching."""
    main_contract: ContractHandle  # The main contract being verified
    base_config: Path
    additional_contracts: List[str] = field(default_factory=list)
    enable_extcall: bool = True
    extcall_mode: str = 'simple'
    extcall_check_non_zero: bool = False
    enable_privileged: bool = True
    enable_input_validation: bool = True
    extra_args: List[str] = field(default_factory=list)


class RuleGenerator:
    """Manages caching and regeneration logic for rule generators."""
    
    def __init__(self, certora_dir: Path, log_func=None):
        """
        Initialize RuleGeneratorCache.

        Args:
            certora_dir: Directory for Certora output files
            log_func: Logging function to use (defaults to print)
        """
        self.certora_dir = certora_dir
        self.log = log_func if log_func else lambda msg, level="INFO": print(f"[{level}] {msg}")

    def _get_cache_file_for_contract(self, config: GeneratorConfig) -> Path:
        """Get the cache file path for a specific contract configuration."""
        contract_name = config.main_contract.contract_name
        return Path(".certora_internal") / f".generator_cache_{contract_name}.json"
    
    def get_generator_cache_key(self, config: GeneratorConfig) -> str:
        """
        Generate a cache key for the generator configuration.
        
        Args:
            config: GeneratorConfig containing all configuration parameters
            
        Returns:
            A hash string representing the configuration
        """
        
        # Include all relevant configuration that affects generation
        config_parts = [
            # Main contract
            config.main_contract.to_config_str(),
            # Additional contracts (sorted for consistency)
            ','.join(sorted(config.additional_contracts)),
            # Generator settings
            f"extcall:{config.enable_extcall}:{config.extcall_mode}:{config.extcall_check_non_zero}",
            f"privileged:{config.enable_privileged}",
            f"input_validation:{config.enable_input_validation}",
            # Extra args that might affect generation
            ','.join(sorted(config.extra_args))
        ]
        
        config_str = '|'.join(config_parts)
        return hashlib.sha256(config_str.encode()).hexdigest()[:16]
    
    def should_regenerate(self, config: GeneratorConfig) -> bool:
        """
        Check if generators should be re-run based on configuration changes.

        Args:
            config: GeneratorConfig containing all configuration parameters

        Returns:
            True if regeneration is needed, False otherwise
        """
        current_key = self.get_generator_cache_key(config)
        cache_file = self._get_cache_file_for_contract(config)

        # Check if all generator directories exist
        required_dirs = ["certora_generic_checker"]
        if config.enable_extcall:
            required_dirs.append("certora_extcall_checker")
        if config.enable_privileged:
            required_dirs.append("certora_privileged_checker")
        if config.enable_input_validation:
            required_dirs.append("certora_input_validation_checker")

        for dir_name in required_dirs:
            if not (self.certora_dir / dir_name).exists():
                self.log(f"Generator directory {dir_name} missing - regeneration needed")
                return True

        # Check per-contract cache file
        if not cache_file.exists():
            self.log("No generator cache found - regeneration needed")
            return True

        try:
            with open(cache_file, 'r') as f:
                cache_data = json.load(f)

            cached_key = cache_data.get('config_key')
            if cached_key != current_key:
                self.log("Configuration changed - regeneration needed")
                self.log(f"  Previous: {cached_key}")
                self.log(f"  Current:  {current_key}")
                return True

            self.log("Configuration unchanged - using existing generated files")
            return False

        except (json.JSONDecodeError, KeyError):
            self.log("Invalid cache file - regeneration needed")
            return True
    
    def save_generator_cache(self, config: GeneratorConfig) -> None:
        """
        Save the current generator configuration to cache.

        Args:
            config: GeneratorConfig containing all configuration parameters
        """
        current_key = self.get_generator_cache_key(config)
        cache_file = self._get_cache_file_for_contract(config)

        cache_data = {
            'config_key': current_key,
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'contract_files': [config.main_contract.to_config_str()],
            'additional_contracts': config.additional_contracts,
            'enable_extcall': config.enable_extcall,
            'extcall_mode': config.extcall_mode,
            'extcall_check_non_zero': config.extcall_check_non_zero,
            'enable_privileged': config.enable_privileged,
            'enable_input_validation': config.enable_input_validation,
            'extra_args': config.extra_args
        }

        cache_file.parent.mkdir(parents=True, exist_ok=True)
        with open(cache_file, 'w') as f:
            json.dump(cache_data, f, indent=2)

        self.log(f"Saved generator cache for {config.main_contract.contract_name}")
    
    def find_generated_configs(self) -> List[Path]:
        """Find all generated configuration files in subdirectories.

        Returns:
            List[Path]: List of paths to generated .conf files
        """
        config_files = []

        # Look for certora_*_checker directories in the certora/ directory
        for checker_dir in self.certora_dir.glob("certora_*_checker"):
            if checker_dir.is_dir():
                # Find .conf files in the checker directory
                for conf_file in checker_dir.glob("*.conf"):
                    config_files.append(conf_file)
                    self.log(f"Found config: {conf_file}")

        return config_files

    def generate_sanity_specs(self, per_contract_summaries_specs: Dict[str, Path]):
        """Create per-contract sanity specs with summary imports.

        Args:
            per_contract_summaries_specs: Dict mapping contract names to their summary spec paths
        """
        sanity_spec = Path(__file__).parent.parent / "certora" / "sanity.spec"
        if sanity_spec.exists():
            self.log("Creating per-contract sanity specs with summary imports")
            for contract_name, summary_spec_path in per_contract_summaries_specs.items():
                target_spec = self.certora_dir / f"sanity-{contract_name}.spec"
                self.create_spec_with_summary_import(sanity_spec, target_spec, summary_spec_path)
        else:
            self.log("No sanity spec found, skipping summary injection.")

    def _compute_import_statement(self, spec_file_path: Path, summaries_spec_path: Path) -> str:
        """Compute the relative import statement from spec file to summaries spec.

        Args:
            spec_file_path: Path to the spec file that will contain the import
            summaries_spec_path: Path to the summaries spec file to import

        Returns:
            str: The import statement with correct relative path
        """
        import os
        try:
            import_path = os.path.relpath(summaries_spec_path, spec_file_path.parent)
        except Exception as e:
            self.log(f"Cannot create relative path for {summaries_spec_path} from {spec_file_path.parent}", "ERROR")
            raise Exception(f"Cannot compute relative import path: {e}")

        import_statement = f'import "{import_path}";\n'
        self.log(f"Computed import for {spec_file_path.name}: {import_statement.strip()}")
        return import_statement

    def _inject_import_to_spec(self, spec_file_path: Path, import_statement: str) -> None:
        """Inject import statement at the top of a spec file.

        Args:
            spec_file_path: Path to the spec file
            import_statement: Import statement to add
        """
        try:
            # Read the current content
            with open(spec_file_path, 'r') as f:
                content = f.read()

            # Check if import already exists
            if import_statement.strip() in content:
                self.log(f"Import already exists in {spec_file_path.name}")
                return

            # Add import at the top
            new_content = import_statement + content

            # Write back to file
            with open(spec_file_path, 'w') as f:
                f.write(new_content)

            self.log(f"Injected summaries import into {spec_file_path.name}")

        except Exception as e:
            self.log(f"Error injecting import into {spec_file_path}: {e}", "ERROR")
            raise

    def create_spec_with_summary_import(
        self, source_spec: Path, target_spec: Path, summary_spec: Optional[Path] = None
    ) -> Path:
        """Create a spec file by copying a source and optionally injecting a summary import.

        Args:
            source_spec: Path to the source spec file to copy
            target_spec: Path where the new spec should be created
            summary_spec: Optional path to summary spec to import. If provided and exists,
                          an import statement will be injected at the top.

        Returns:
            Path to the created spec file
        """
        if not source_spec.exists():
            raise FileNotFoundError(f"Source spec not found: {source_spec}")

        # Copy source to target
        shutil.copy2(source_spec, target_spec)

        # Inject summary import if provided and exists
        if summary_spec and summary_spec.exists():
            import_statement = self._compute_import_statement(target_spec, summary_spec)
            self._inject_import_to_spec(target_spec, import_statement)
            self.log(f"Created {target_spec.name} with summary import")
        else:
            self.log(f"Created {target_spec.name} (no summary import)")

        return target_spec

    def run_generic_rules_generator(
        self, config: GeneratorConfig, summary_spec: Optional[Path] = None
    ) -> bool:
        """Run the GenericRules generator to create required directory structure.

        Args:
            config: Generator configuration
            summary_spec: Optional path to summary spec for import injection
        """
        self.log("Running GenericRules generator...")

        try:
            contract_name = config.main_contract.contract_name
            output_dir = self.certora_dir / "certora_generic_checker"

            # Create a mock args object like the generator expects
            class MockArgs:
                def __init__(self, contract, base_config, out_dir, suffix):
                    self.files = None
                    self.contract = contract
                    self.base_config = base_config
                    self.output_dir = out_dir
                    self.contract_suffix = suffix

            args = MockArgs(contract_name, config.base_config, output_dir, f"_{contract_name}")

            # Validate arguments using the generator's validation
            validate_generic_args(args)

            # Process templates - writes directly to output_dir with contract suffix
            process_generic_templates(args)

            # Inject summary import into the main spec file
            if summary_spec and summary_spec.exists():
                spec_file = output_dir / f"generic_rules_{contract_name}.spec"
                if spec_file.exists():
                    import_stmt = self._compute_import_statement(spec_file, summary_spec)
                    self._inject_import_to_spec(spec_file, import_stmt)

            self.log("✓ GenericRules generator completed successfully")
            return True

        except SystemExit as e:
            raise Exception(f"GenericRules generator failed with exit code: {e.code}")
        except Exception as e:
            raise Exception(f"GenericRules generator failed with exception: {e}")
    
    def run_extcall_generator(
        self, config: GeneratorConfig, summary_spec: Optional[Path] = None
    ) -> bool:
        """Run the ExternalCallChecker generator.

        Args:
            config: Generator configuration
            summary_spec: Optional path to summary spec for import injection
        """
        self.log("Running ExternalCallChecker generator...")

        try:
            contract_name = config.main_contract.contract_name
            output_dir = self.certora_dir / "certora_extcall_checker"

            # Create a mock args object like the generator expects
            class MockArgs:
                def __init__(self, contract, mode, check_non_zero_targets, base_config, out_dir, suffix):
                    self.files = None
                    self.contract = contract
                    self.mode = mode
                    self.check_non_zero_targets = check_non_zero_targets
                    self.base_config = base_config
                    self.output_dir = out_dir
                    self.contract_suffix = suffix

            args = MockArgs(
                contract_name, config.extcall_mode, config.extcall_check_non_zero,
                config.base_config, output_dir, f"_{contract_name}"
            )

            # Validate and process - writes directly to output_dir with contract suffix
            validate_extcall_args(args)
            process_extcall_templates(args)

            # Inject summary import into the main spec file
            if summary_spec and summary_spec.exists():
                # Determine spec filename based on mode
                spec_base = "extcall_checker_simple" if config.extcall_mode == 'simple' else "extcall_checker_advanced"
                spec_file = output_dir / f"{spec_base}_{contract_name}.spec"
                if spec_file.exists():
                    import_stmt = self._compute_import_statement(spec_file, summary_spec)
                    self._inject_import_to_spec(spec_file, import_stmt)

            self.log("✓ ExternalCallChecker generator completed successfully")
            return True

        except SystemExit as e:
            raise Exception(f"ExternalCallChecker generator failed with exit code: {e.code}")
        except Exception as e:
            raise Exception(f"ExternalCallChecker generator failed with exception: {e}")
    
    def run_privileged_generator(
        self, config: GeneratorConfig, summary_spec: Optional[Path] = None,
        inheritance_graph: Optional[InheritanceGraph] = None,
    ) -> bool:
        """Run the PrivilegedOperations generator.

        Args:
            config: Generator configuration
            summary_spec: Optional path to summary spec for import injection
            inheritance_graph: Inheritance graph mapping contract -> set of parent contracts
        """
        self.log("Running PrivilegedOperations generator...")

        try:
            contract_name = config.main_contract.contract_name
            output_dir = self.certora_dir / "certora_privileged_checker"

            # Combine main contract file with additional contracts for the scene
            all_files = [config.main_contract.to_config_str()] + config.additional_contracts

            # Create a mock args object like the generator expects
            class MockArgs:
                def __init__(self, files, contract, base_config, out_dir, suffix):
                    self.files = files
                    self.contract = contract
                    self.base_config = base_config
                    self.output_dir = out_dir
                    self.contract_suffix = suffix

            args = MockArgs(all_files, contract_name, config.base_config, output_dir, f"_{contract_name}")

            # Validate and process - writes directly to output_dir with contract suffix
            validate_privileged_args(args)
            process_privileged_templates(args, inheritance_graph=inheritance_graph)

            # Inject summary import into the main spec files
            if summary_spec and summary_spec.exists():
                for spec_base in ["privileged_operations", "privileged_writes"]:
                    spec_file = output_dir / f"{spec_base}_{contract_name}.spec"
                    if spec_file.exists():
                        import_stmt = self._compute_import_statement(spec_file, summary_spec)
                        self._inject_import_to_spec(spec_file, import_stmt)

            self.log("✓ PrivilegedOperations generator completed successfully")
            return True

        except SystemExit as e:
            raise Exception(f"PrivilegedOperations generator failed with exit code: {e.code}")
        except Exception as e:
            raise Exception(f"PrivilegedOperations generator failed with exception: {e}")

    def run_input_validation_generator(
        self, config: GeneratorConfig, summary_spec: Optional[Path] = None
    ) -> bool:
        """Run the InputValidationChecker generator for the contract.

        Args:
            config: Generator configuration (should contain single contract)
            summary_spec: Optional path to summary spec for import injection
        """
        self.log("Running InputValidationChecker generator...")

        try:
            contract_name = config.main_contract.contract_name
            output_dir = self.certora_dir / "certora_input_validation_checker"

            # Create a mock args object like the generator expects
            class MockArgs:
                def __init__(self, contracts, base_config, out_dir):
                    self.files = None
                    self.contract = contracts[0] if contracts else "Contract"  # For backward compat
                    self.contracts = contracts  # All contracts to generate specs for
                    self.base_config = base_config
                    self.output_dir = out_dir

            args = MockArgs([contract_name], config.base_config, output_dir)

            # Validate and process - already creates per-contract outputs
            validate_input_validation_args(args)
            process_input_validation_templates(args)

            # Inject summary import into the spec file
            if summary_spec and summary_spec.exists():
                spec_file = output_dir / f"input_validation_{contract_name}.spec"
                if spec_file.exists():
                    import_stmt = self._compute_import_statement(spec_file, summary_spec)
                    self._inject_import_to_spec(spec_file, import_stmt)

            self.log("✓ InputValidationChecker generator completed successfully")
            return True

        except SystemExit as e:
            raise Exception(f"InputValidationChecker generator failed with exit code: {e.code}")
        except Exception as e:
            raise Exception(f"InputValidationChecker generator failed with exception: {e}")
        
    def run_all_generators(
        self, config: GeneratorConfig, summary_spec: Optional[Path] = None,
        inheritance_graph: Optional[InheritanceGraph] = None,
    ) -> bool:
        """Run all enabled generators automatically for a single contract.

        Args:
            config: Generator configuration (should contain single contract handle)
            summary_spec: Optional path to summary spec for import injection
            inheritance_graph: Inheritance graph mapping contract -> set of parent contracts

        Returns:
            True if all generators succeeded, False otherwise
        """
        self.log("=== RUNNING GENERATORS ===")

        # Always run GenericRules generator (required for warmup)
        if not self.run_generic_rules_generator(config, summary_spec):
            return False

        # Run ExternalCallChecker if enabled
        if config.enable_extcall:
            if not self.run_extcall_generator(config, summary_spec):
                self.log("ExternalCallChecker generation failed", "ERROR")
                return False

        # Run PrivilegedOperations if enabled
        if config.enable_privileged:
            if not self.run_privileged_generator(config, summary_spec, inheritance_graph=inheritance_graph):
                self.log("PrivilegedOperations generation failed", "ERROR")
                return False

        # Run InputValidationChecker if enabled
        if config.enable_input_validation:
            if not self.run_input_validation_generator(config, summary_spec):
                self.log("InputValidationChecker generation failed", "ERROR")
                return False

        # Save the generator cache after successful generation
        self.save_generator_cache(config)

        return True