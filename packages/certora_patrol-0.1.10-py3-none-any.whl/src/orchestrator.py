#!/usr/bin/env python3
"""
PreAudit Orchestrator Script

Intelligently runs Certora verification tools:
1. First runs sanity warmup to prime the cache
2. Then runs all generated configurations from PreAudit subtools
"""


import asyncio
import atexit
import json
import json5
import os
import shutil
import signal
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

# Setup path for local modules
scripts_dir_path = Path(__file__).parent.parent.resolve()
# Add project root to sys.path so we can import from src
sys.path.insert(0, str(scripts_dir_path))
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

from src.reporting.reporter import Reporter, JobRuleStats
from src.reporting.json_reporter import JsonReporter
from src.setup.setup_completeness_checker import SetupCompletenessChecker, SetupCompletenessReport
from src.parsers.orchestrator_argparse import create_parser, parse_contract_files
from src.rule_generator import GeneratorConfig, RuleGenerator

# Import local modules
from src.parsers.build_system_detector import BuildSystem, BuildSystemDetector
from src.build_systems.base import BuildSystemConfig
from src.build_systems.manager import BuildSystemManager
from src.setup.setup_prover import CompilationAnalysisError, SetupProver, SummarySetupError
from src.utils import logger
from src.utils.cloud_runner import CloudProverRunner
from src.utils.enhanced_config_manager import ConfigManager, FileContent, ProverJobSpec
from src.utils.local_runner import LocalProverRunner
from src.utils.scope import Scope
from src.setup.signature_manager import SignatureManager
from src.setup.call_resolution import CallResolutionPhase
from src.utils.types import ContractHandle

# Import required dependencies
from src.utils.prover_runner import ProverRunner
from src.utils.runner_types import ProverResult
from src.utils.types import ContractInfo

# AutoCVL integration (isolated in src/autocvl/)
from src.autocvl.runner import AutoCVLConfig, AutoCVLResult, AutoCVLRunner


class CertoraOrchestrator:
    TEST_RUN_PROVER_ARGS = {
        "verifyCache": "",
        "verifyTACDumps": "",
        "testMode": "",
        "checkRuleDigest": "",
        "callTraceHardFail": "on",
    }

    def __init__(
        self,
        verbose: int = 0,
        generator_config: dict | None = None,
        use_cache: bool = True,
        require_all_submissions: bool = True,
        retry_difficult: bool = False,
        skip_breadcrumbs: bool = False,
        skip_checkers: bool = False,
        skip_sanity_setup: bool = False,
        skip_call_resolution: bool = False,
        skip_setup_check: bool = False,
        certora_run_command: str = "certoraRun",
        use_local_runner: bool = False,
        max_configs: int | None = None,
        dummy_erc20: int | None = None,
        keep_intermediate_typechecker_files: bool = False,
        cancel_cloud_jobs_on_cleanup: bool = True,
        include_foundry_packages: bool = True,
        continue_on_warmup_failure: bool = False,
        build_system: Optional[str] = None,
        profile: Optional[str] = None,
        enable_autocvl: bool = False,
        autocvl_iterative: bool = False,
        autocvl_max_iterations: int = 3,
    ):
        self.verbose = verbose
        self.script_dir = Path(__file__).parent
        self.require_all_submissions = require_all_submissions
        self.retry_difficult = retry_difficult
        self.skip_breadcrumbs = skip_breadcrumbs
        self.skip_checkers = skip_checkers
        self.skip_sanity_setup = skip_sanity_setup
        self.skip_call_resolution = skip_call_resolution
        self.skip_setup_check = skip_setup_check
        self.certora_run_command = certora_run_command
        self.max_configs = max_configs
        self.requested_build_system = build_system  # Store requested build system
        self.requested_profile = profile  # Store requested build system profile (e.g. Foundry profile)
        self.dummy_erc20 = dummy_erc20
        self.keep_intermediate_typechecker_files = keep_intermediate_typechecker_files
        self.cancel_cloud_jobs_on_cleanup = cancel_cloud_jobs_on_cleanup
        self.include_foundry_packages = include_foundry_packages
        self.continue_on_warmup_failure = continue_on_warmup_failure

        # Store generator configuration
        self.generator_config_base = generator_config or {}

        # Extract commonly used values for backward compatibility
        self.extra_args = self.generator_config_base.get("extra_args", [])
        self.additional_contracts: List[str] = self.generator_config_base.get(
            "additional_contracts", []
        )

        # AutoCVL configuration
        self.enable_autocvl = enable_autocvl
        self.autocvl_iterative = autocvl_iterative
        self.autocvl_max_iterations = autocvl_max_iterations
        self.autocvl_results: Dict[str, AutoCVLResult] = {}

        # Build system detection and configuration
        self.build_system: Optional[BuildSystem] = None  # Will be set by setup_build_system_config()
        self.build_system_config: Optional[BuildSystemConfig] = None  # Populated with FoundryConfig or HardhatConfig

        # Track compilation configuration updates from setup_prover
        self.compilation_config_updates: Dict[str, Any] = {}
        self.import_patcher_applied: bool = False

        # Configure centralized logger
        logger.set_verbosity(verbose)
        self.component = "Orchestrator"

        # Store project root
        self.project_root = Path.cwd()

        # Create directory structure
        self.certora_dir = Path("certora")
        self.certora_dir.mkdir(exist_ok=True)

        # Contract handles (initialize before dummy contracts creation)
        self.contract_handles: List[ContractHandle] = []  # All detected contracts
        self.main_contract_handles: List[ContractHandle] = []  # Contracts to verify

        # Initialize rule generator cache
        self.rule_generator = RuleGenerator(self.certora_dir, self.log)

        # Set up timestamped report directory path (will be created when needed)
        from datetime import datetime

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.orchestration_timestamp = timestamp  # Store for use in conf msg fields
        self.reports_dir = (
            Path(".CertoraPatrolReports") / timestamp
        )
        self.reporter = Reporter(self.log, verbose, skip_breadcrumbs, self.reports_dir)
        self.json_reporter = JsonReporter(self.reports_dir)
        # Don't create directory yet - will create when first report is generated

        # Setup completeness checker for analyzing prover results
        self.setup_checker = SetupCompletenessChecker(log_func=self.log)
        self.aggregated_setup_report = SetupCompletenessReport(self.reports_dir)

        # Path to orchestrator_results.json (set by generate_final_reports)
        self.results_json_path: Optional[Path] = None

        # Cache management - now handled by ProverRunner with enhanced dependency tracking
        self.use_cache = use_cache

        if self.verbose >= 2:
            cache_status = "enabled" if use_cache else "disabled"
            self.log(f"Cache {cache_status}")

        # Initialize enhanced config manager and prover runner
        self.config_manager = ConfigManager(self.project_root)

        # Initialize and maintain scope for signature database management
        self.scope = Scope(self.project_root)
        self.signature_manager = SignatureManager(self.project_root)

        # Load existing signature database if available
        self._load_signature_database_to_scope()

        # Generate dummy ERC20 files if requested (after scope initialization)
        self.generate_dummy_erc20_files()

        self.prover_runner: ProverRunner
        if use_local_runner:
            self.prover_runner = LocalProverRunner(
                project_root=self.project_root,
                config_manager=self.config_manager,
                certora_run_path=certora_run_command,
                disable_cache=not use_cache,
            )
        else:
            self.prover_runner = CloudProverRunner(
                project_root=self.project_root,
                config_manager=self.config_manager,
                certora_run_path=certora_run_command,
                disable_cache=not use_cache,
                cancel_jobs_on_cleanup=self.cancel_cloud_jobs_on_cleanup,
            )

        # Initialize setup_prover_instance to None (will be set later by main())
        self.setup_prover_instance: SetupProver | None = None

        # Configure the prover runner's logger to use our logging system
        import logging

        logging.basicConfig(level=logging.INFO, format="%(message)s")
        logging.getLogger("urllib3").setLevel(logging.WARNING)
        logging.getLogger("requests").setLevel(logging.WARNING)
        logging.getLogger("httpx").setLevel(logging.WARNING)
        logging.getLogger("anthropic").setLevel(logging.WARNING)
        logging.getLogger("claude_agent_sdk").setLevel(logging.WARNING)
        logging.getLogger("sentence_transformers").setLevel(logging.WARNING)
        logging.getLogger("transformers_modules").setLevel(logging.ERROR)
        logging.getLogger("transformers").setLevel(logging.ERROR)

        # Set up the prover runner logger to output to console
        prover_logger = logging.getLogger("PreAudit.utils.cloud_runner")
        if not prover_logger.handlers:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(
                logging.Formatter("[%(name)s] %(levelname)s: %(message)s")
            )
            # prover_logger.addHandler(console_handler)
            prover_logger.setLevel(logging.INFO)

        # Suppress noisy credential messages from certora_login and related libraries
        # These include "Reading credentials from file" and "Keyring not available" messages
        logging.getLogger("certora_login").setLevel(logging.ERROR)
        logging.getLogger("prover_output_utility").setLevel(logging.ERROR)
        logging.getLogger("keyring").setLevel(logging.ERROR)

        # Store report statistics from parallel execution
        self.report_stats: Dict[
            str, Any
        ] = {}  # Store report statistics from parallel execution
        self.report_stats_lock: threading.Lock = (
            threading.Lock()
        )  # Lock for report stats

        # Store job results for signal handler access
        self.job_results: List[ProverResult] = []  # Store job results as they complete
        self.job_results_lock: threading.Lock = threading.Lock()  # Lock for job results

        # Test run job specs (created during warmup, run during verification phase)
        self._test_run_specs: List[ProverJobSpec[Any]] = []

        # Store execution info for JSON reporting
        self.execution_info: Dict[str, Any] = {}

        # Contracts that contain bytes mapping fields and the names of such fields (will be filled after compilation analysis)
        self.bytes_mappings: List[tuple[ContractHandle, List[str]]] = []

    def _get_all_files(self, contract_files: List[str]) -> List[str]:
        """Get all files including additional contracts for the scene."""
        return contract_files + self.additional_contracts

    def _get_all_files_with_imports(self, contract_files: List[str]) -> List[str]:
        """contract_files + self.additional_contracts + all imported files"""
        # TODO: add the imported files... via signature database or the build files?
        return self._get_all_files(contract_files)

    def _build_job_msg(self, contract_name: str, conf_file: Path) -> str:
        """Build the msg string for a prover job.

        Format: "Patrol <timestamp> <ContractName>: <conf_name>"
        """
        return ProverJobSpec.build_job_msg(self.orchestration_timestamp, contract_name, conf_file)

    def _get_jobs_dashboard_url(self) -> str:
        """Get the URL to view all jobs from this orchestration run."""
        return f"https://prover.certora.com/?text=Patrol+{self.orchestration_timestamp}"

    def log(self, message: str, level: str = "INFO"):
        """Log message using centralized logger."""
        logger.log(message, level, self.component)

    def ensure_git_config_files(self) -> None:
        """Ensure .gitattributes and .gitignore have recommended Certora settings."""
        project_dir = Path.cwd()

        # Define required lines for each file
        gitattributes_lines = [
            "*.spec linguist-language=Solidity",
            "*.conf linguist-detectable",
            "*.conf linguist-language=JSON5",
        ]

        gitignore_lines = [
            "**/.certora_internal",
            "**/.CertoraPatrolReports",
        ]

        # Helper function to ensure file has required lines
        def ensure_file_has_lines(file_path: Path, required_lines: list[str], file_description: str) -> None:
            try:
                # Read existing content if file exists
                if file_path.exists():
                    with open(file_path, "r") as f:
                        existing_content = f.read()
                    existing_lines = existing_content.splitlines()
                else:
                    existing_content = ""
                    existing_lines = []

                # Find missing lines
                missing_lines = [
                    line for line in required_lines
                    if line not in existing_lines
                ]

                if missing_lines:
                    # Determine if this is a new file before writing
                    is_new_file = not existing_lines

                    # Append missing lines
                    with open(file_path, "a") as f:
                        # Add newline before if file exists and doesn't end with newline
                        if existing_content and not existing_content.endswith('\n'):
                            f.write('\n')

                        # Add a comment header if this is a new section
                        if file_path.name == ".gitattributes" and existing_lines:
                            f.write('\n# Certora linguist settings\n')
                        elif file_path.name == ".gitignore" and existing_lines:
                            f.write('\n# Certora directories\n')

                        # Write missing lines
                        for line in missing_lines:
                            f.write(f'{line}\n')

                    if is_new_file:
                        self.log(f"Created {file_path.name} with Certora {file_description} settings")
                    else:
                        self.log(f"Updated {file_path.name} with missing Certora {file_description} settings")
                elif self.verbose >= 2:
                    self.log(f"{file_path.name} already up to date")

            except (PermissionError, OSError) as e:
                self.log(f"Warning: Could not update {file_path.name}: {e}", "WARNING")

        # Ensure .gitattributes
        gitattributes_path = project_dir / ".gitattributes"
        ensure_file_has_lines(gitattributes_path, gitattributes_lines, "linguist")

        # Ensure .gitignore
        gitignore_path = project_dir / ".gitignore"
        ensure_file_has_lines(gitignore_path, gitignore_lines, "ignore")

    def generate_dummy_erc20_files(self):
        """Generate dummy ERC20 files based on the dummy_erc20 parameter."""
        if self.dummy_erc20 is None or self.dummy_erc20 <= 0:
            return

        template_path = self.script_dir / "setup" / "mocks" / "DummyERC20.template.sol"
        if not template_path.exists():
            raise FileNotFoundError(f"DummyERC20 template not found at {template_path}")

        # Create mocks subdirectory
        mocks_dir = self.certora_dir / "mocks"
        mocks_dir.mkdir(exist_ok=True)

        # Read template content
        with open(template_path, "r") as f:
            template_content = f.read()

        # Generate dummy_erc20 number of files
        for i in range(1, self.dummy_erc20 + 1):
            # Replace {{NUM}} with the current number
            file_content = template_content.replace("{{NUM}}", str(i))

            # Create output filename
            output_filename = f"DummyERC20_{i}.sol"
            output_path = mocks_dir / output_filename

            # Write the file
            with open(output_path, "w") as f:
                f.write(file_content)

            self.contract_handles.append(ContractHandle.from_filepath(str(output_path)))
            self.log(f"Generated {output_path}")

            # Add to signature database
            contract_name = f"DummyERC20_{i}"
            dummy_contract_info = ContractInfo(
                name=contract_name,
                source_file=output_path,
                inherits_from=["DummyERC20Impl"]
            )
            self.scope.add_contract(dummy_contract_info)
            self.log(f"Added {contract_name} to signature database")

        # Copy DummyERC20Impl.sol to mocks directory
        impl_source = self.script_dir / "setup" / "mocks" / "DummyERC20Impl.sol"
        if not impl_source.exists():
            raise FileNotFoundError(f"DummyERC20Impl.sol not found at {impl_source}")

        impl_dest = mocks_dir / "DummyERC20Impl.sol"
        shutil.copy2(impl_source, impl_dest)
        self.contract_handles.append(ContractHandle.from_filepath(str(impl_dest)))
        self.log("Copied DummyERC20Impl.sol to mocks/")

        # Add DummyERC20Impl to signature database
        impl_contract_info = ContractInfo(
            name="DummyERC20Impl",
            source_file=impl_dest
        )
        self.scope.add_contract(impl_contract_info)
        self.log("Added DummyERC20Impl to signature database")

        self.log(f"Created {self.dummy_erc20} dummy ERC20 contract(s) in mocks/")

    def _load_signature_database_to_scope(self):
        """Universal function to load signature database from JSON to scope."""
        signature_db_path = self.project_root / ".certora_internal" / "preaudit_state" / "signature_database.json"
        if signature_db_path.exists():
            self.signature_manager.load_from_json(signature_db_path)
            loaded_database = self.signature_manager.get_signature_database()

            # Extend existing signature database instead of replacing it
            for contract_name, contract_info in loaded_database.get_all_contracts().items():
                self.scope.signature_database.add_contract(contract_info)

            for selector, signature in loaded_database.get_all_signatures().items():
                implementing_contracts = loaded_database.get_implementing_contracts(selector)
                for contract in implementing_contracts:
                    self.scope.signature_database.add_signature(signature, contract)

            self.log(f"✓ Extended signature database with data from: {signature_db_path}", level="DEBUG")
        elif self.verbose >= 2:
            self.log("ℹ️ No signature database found, keeping existing database")

    def setup_build_system_config(self):
        """
        Auto-detect and setup build system configuration (Foundry or Hardhat).

        This method:
        1. Auto-detects build system or uses explicit build system from self.requested_build_system
        2. Creates appropriate manager (FoundryManager or HardhatManager)
        3. Calls auto_detect_config() to find and parse config file
        4. Stores the config in self.build_system_config (polymorphic)
        """
        try:
            # Auto-detect or use explicit build system from init parameter
            if self.requested_build_system is None or self.requested_build_system == 'auto':
                detected = BuildSystemDetector.detect(Path.cwd())
                self.log(f"Auto-detected build system: {detected.value}")
            else:
                detected = BuildSystem(self.requested_build_system.lower())
                self.log(f"Using explicit build system: {detected.value}")

            if detected == BuildSystem.UNKNOWN:
                self.log("No build system detected, continuing without build config", "WARNING")
                self.build_system = BuildSystem.UNKNOWN
                self.build_system_config = None
                return

            self.build_system = detected

            # Create a minimal scope that accepts all files
            class MinimalScope:
                def is_file_in_scope(self, file_path):
                    return True

            project_root = Path.cwd()
            scope = MinimalScope()

            # Get appropriate manager class and create instance
            ManagerClass = BuildSystemDetector.get_manager_class(detected)
            manager: BuildSystemManager = ManagerClass(project_root, scope)

            # Auto-detect and parse config (polymorphic - returns FoundryConfig or HardhatConfig)
            self.log(f"Auto-detecting {detected.value} configuration...")
            self.build_system_config = manager.auto_detect_config(profile=self.requested_profile)

            # Log common info
            self.log(f"Solc version: {self.build_system_config.solc_version}")
            self.log(
                f"Optimizer: {self.build_system_config.optimizer} (runs: {self.build_system_config.optimizer_runs})"
            )
            if self.build_system_config.via_ir:
                self.log("Via IR: enabled")

        except Exception as e:
            self.log(f"Failed to setup build system configuration: {e}", "WARNING")
            self.log("Continuing without build system configuration", "WARNING")
            self.build_system = BuildSystem.UNKNOWN if 'BuildSystem' in dir() else None
            self.build_system_config = None

    def get_build_system_config_dict(self) -> Dict[str, Any]:
        """
        Get Certora-compatible configuration dictionary from detected build system.

        Returns:
            Dictionary with Certora config settings derived from Foundry or Hardhat config,
            or empty dict if no build system config is available.
        """
        if self.build_system_config:
            # Use polymorphic to_certora_dict() - eliminates branching!
            return self.build_system_config.to_certora_dict(
                convert_solc_to_certora_format=True,
                include_packages=self.include_foundry_packages
            )

        return {}

    def get_build_system_config_dict_with_updates(self) -> Dict[str, Any]:
        """
        Get Certora-compatible configuration dictionary from build system config,
        merged with any updates from compilation analysis.

        Returns:
            Dictionary with Certora config settings, including any updates
            applied during compilation (e.g., from import patcher or other
            compilation techniques).
        """
        # Start with base build system config
        config = self.get_build_system_config_dict()

        # Merge in compilation updates (which already started from build system config)
        # This ensures any modifications made during compilation are preserved
        if self.compilation_config_updates:
            config.update(self.compilation_config_updates)

        return config

    def _find_all_spec_files(self, spec_filename: str) -> List[Path]:
        """Find all instances of a spec file in the certora/ directory.

        Args:
            spec_filename: The name of the spec file (can include partial path)

        Returns:
            List of Path objects for all found instances
        """

        found_files: list = []
        spec_name = Path(spec_filename).name  # Get just the filename

        # Search only in the certora directory
        search_dir = self.certora_dir  # This is Path.cwd() / 'certora'

        if not search_dir.exists():
            return found_files

        # Recursively search for the spec file
        for root, dirs, files in os.walk(search_dir):
            # Skip .certora_internal directories (build artifacts)
            dirs[:] = [d for d in dirs if d != ".certora_internal"]

            root_path = Path(root)
            if spec_name in files:
                spec_path = root_path / spec_name
                found_files.append(spec_path)

        return found_files

    def _resolve_spec_file(self, spec_file: str) -> Path:
        """Resolve a spec file path ensuring it exists uniquely in the certora/ directory.

        Args:
            spec_file: The spec file path/name from the error message

        Returns:
            The resolved Path to the unique spec file

        Raises:
            Exception: If the spec file is not found or multiple instances exist
        """
        # Find all instances of this spec file
        found_files = self._find_all_spec_files(spec_file)

        if len(found_files) == 0:
            raise Exception(f"Spec file not found in certora/ directory: {spec_file}")

        if len(found_files) > 1:
            # Fatal error - duplicate spec files
            error_msg = f"FATAL ERROR: Multiple instances of spec file '{Path(spec_file).name}' found in certora/ directory:\n"
            for i, path in enumerate(found_files, 1):
                error_msg += f"  {i}. {path}\n"
            error_msg += (
                "\nEach spec file name must be unique within the certora/ directory."
            )
            error_msg += "\nPlease rename duplicate files to have unique names."
            self.log(error_msg, "ERROR")
            raise Exception(error_msg)

        # Exactly one file found
        return found_files[0]

    def handle_typechecker_errors(
        self, cmd: List[str], description: str, max_retries: int = 10
    ) -> bool:
        """Handle typechecker errors using the new copy-based approach.

        Args:
            cmd: The certoraRun command to execute
            description: Description of the operation
            max_retries: Maximum number of retry attempts

        Returns:
            Tuple of (success, job_url)
        """
        from typechecker_loop import TypecheckerLoop  # type: ignore[import-not-found]

        self.log(f"Starting typechecker loop for: {description}")

        # Create TypecheckerLoop instance
        typechecker = TypecheckerLoop(
            certora_dir=self.certora_dir,
            verbose=bool(self.verbose),
            keep_intermediate_files=self.keep_intermediate_typechecker_files
        )

        # Run the typechecker loop to fix any typechecker errors
        success, final_cmd = typechecker.run_typechecker_loop(cmd, max_retries)

        if success:
            self.log("✓ Typechecker loop completed successfully")
            return True
        else:
            self.log("✗ Typechecker loop failed", "ERROR")
            return False

    def base_config_path(self, main_contract: str) -> Path:
        return self.certora_dir / f"base-{main_contract}.conf"

    def create_warmup_spec(self, contract_name: str) -> Path:
        """Create a minimal warmup spec for a contract.

        Copies certora/trivial.spec and injects an import to the contract's summary spec.

        Args:
            contract_name: Name of the contract

        Returns:
            Path to the created warmup spec file
        """
        trivial_spec = scripts_dir_path / "certora" / "trivial.spec"
        warmup_spec = self.certora_dir / f"warmup-{contract_name}.spec"
        summary_spec = self.certora_dir / f"summaries-{contract_name}.spec"

        return self.rule_generator.create_spec_with_summary_import(
            trivial_spec, warmup_spec, summary_spec
        )

    def create_base_config(
        self, main_contract: str, spec_path: Path
    ) -> FileContent:
        """Create base configuration if it doesn't exist."""
        conf_path = self.base_config_path(main_contract)

        base_prover_args = {
            "quiet": "",  # Add quiet flag for base
        }

        # Prepare base-specific properties
        base_properties = {
            "wait_for_results": "none",
        }

        # Merge build system configuration with compilation updates
        foundry_dict = self.get_build_system_config_dict_with_updates()
        if foundry_dict:
            base_properties.update(foundry_dict)
            self.log(
                f"Merged build system config into base config: {list(foundry_dict.keys())}"
            )

        # Use ConfigManager to create the configuration with all settings at once
        final_config = self.config_manager.create_config(
            main_contract,
            self.contract_handles,
            self.additional_contracts,
            spec_path,
            conf_path=conf_path,
            additional_args=base_prover_args,
            properties=base_properties,
        )

        self.log(f"Created base config using ConfigManager: {final_config.path}")
        return final_config

    def _fix_config_with_typechecker(
        self, config_file: Path, description: str = ""
    ) -> bool:
        """Fix a single config file with typechecker and update it in place.

        Args:
            config_file: Path to the config file to fix
            description: Description for logging (e.g., "warmup HelloToken")

        Returns:
            bool: True if successful, False if failed
        """
        import shutil

        from typechecker_loop import TypecheckerLoop  # type: ignore[import-not-found]

        try:
            # Build command for typechecker
            cmd = [self.certora_run_command, str(config_file)] + self.extra_args

            # Create TypecheckerLoop instance
            typechecker = TypecheckerLoop(
                certora_dir=self.certora_dir,
                verbose=False,  # Use False to avoid excessive logging
                keep_intermediate_files=self.keep_intermediate_typechecker_files
            )

            # Run the typechecker loop to fix any typechecker errors
            desc_text = f" for {description}" if description else ""
            self.log(f"🔧 Running typechecker fixes{desc_text}: {config_file.name}")
            success, final_cmd = typechecker.run_typechecker_loop(cmd, max_rounds=10)

            if success:
                # Extract the fixed config file from final_cmd
                if len(final_cmd) > 1 and final_cmd[1] != str(config_file):
                    fixed_config_file = Path(final_cmd[1])
                    # Copy the fixed config back to the original location
                    shutil.copy2(fixed_config_file, config_file)
                    self.log(f"✓ Config fixed{desc_text}: {config_file.name}")
                else:
                    self.log(
                        f"✓ Config OK{desc_text}: {config_file.name} (no fixes needed)"
                    )
                return True
            else:
                self.log(
                    f"✗ Failed to fix config{desc_text}: {config_file.name}", "ERROR"
                )
                return False

        except Exception as e:
            self.log(
                f"✗ Error fixing config{desc_text} {config_file.name}: {e}", "ERROR"
            )
            return False

    def _pre_execute_typechecker_fix(self, job_spec) -> None:
        """Pre-execute callback to fix config with typechecker before job submission."""
        config_path = job_spec.config_file.path
        contract_name = job_spec.contract_name

        # Apply typechecker fix to the config
        if not self._fix_config_with_typechecker(
            config_path, f"{contract_name} {job_spec.phase}"
        ):
            raise Exception(f"Typechecker fix failed for {config_path.name}")

        self.log(
            f"✓ Pre-execute typechecker fix completed for {contract_name}: {config_path.name}",
            "DEBUG",
        )

    def merge_build_system_into_generated_configs(self, config_files: List[Path]):
        """
        Merge build system configuration into all generated config files.
        Args:
            config_files: List of paths to generated .conf files
        This method reads each config file, merges build system settings, and overwrites the file.
        """
        build_system_dict = self.get_build_system_config_dict_with_updates()

        if not build_system_dict:
            self.log("No build system config to merge into generated configs")
            return

        self.log(
            f"Merging build system config into {len(config_files)} generated config files..."
        )

        for config_file in config_files:
            try:
                # Read existing config
                with open(config_file, "r") as f:
                    config = json.load(f)

                # Merge build system settings (build system settings don't overwrite existing ones)
                for key, value in build_system_dict.items():
                    if key not in config:
                        config[key] = value

                # Write back
                with open(config_file, "w") as f:
                    json.dump(config, f, indent=2)

                if self.verbose:
                    self.log(f"  Merged build system config into {config_file.name}")

            except Exception as e:
                self.log(
                    f"Failed to merge build system config into {config_file}: {e}", "WARNING"
                )

        self.log("✓ Build system config merged into generated configs")

    def test_summary_compilation(
        self, main_contract: str
    ) -> bool:
        """Test that generated summaries compile correctly using ConfigManager.

        This runs a quick compilation check on just one contract to validate
        that llm_summaries.spec and other generated summaries have correct syntax.
        """
        suffix = main_contract
        sanity_spec_path = self.certora_dir / f"sanity-{suffix}.spec"

        # Prepare test configuration settings
        test_config_path = Path(f".certora_internal/test_compilation-{suffix}.conf")
        test_config_path.parent.mkdir(parents=True, exist_ok=True)

        # Prepare compilation-specific properties
        compilation_properties = {
            "build_cache": True,
            "compilation_steps_only": True,  # Just test compilation, don't run verification
            "msg": f"{main_contract} summary compilation test",
        }

        # Merge build system configuration with compilation updates
        build_system_dict = self.get_build_system_config_dict_with_updates()
        if build_system_dict:
            compilation_properties.update(build_system_dict)

        # Use ConfigManager to create test config with all settings at once
        final_config = self.config_manager.create_config(
            main_contract,
            self.contract_handles,
            [], # TODO: should we include also self.additional_contracts?
            sanity_spec_path,
            conf_path=test_config_path,
            properties=compilation_properties,
        )
        self.log(f"Running compilation test on {main_contract}...")

        # Build command for typechecker error handling
        cmd = [self.certora_run_command, str(final_config.path)]
        cmd.extend(self.extra_args)

        # Use the proper typechecker error handling loop
        success = self.handle_typechecker_errors(
            cmd, f"Compilation test on {main_contract}"
        )

        if success:
            self.log("✅ Summary compilation test passed")
            return True
        else:
            self.log("Summary compilation test failed", "ERROR")
            return False

    def generate_base_and_run_warmup(
        self,
        skip_warmup: bool = False,
    ) -> tuple[bool, List[ContractHandle]]:
        """Run sanity warmup to prime the cache.

        Returns:
            Tuple of (overall_success, list_of_successful_contracts).
            If skip_warmup is True, returns (True, all_main_contract_handles).
        """
        self.log("=== CACHE WARMUP PHASE ===")

        # Test compilation of summaries before running sanity
        self.log("Testing summary compilation...")

        # Track contracts that fail compilation test
        compilation_failed_contracts: set[str] = set()
        for contract_handle in self.main_contract_handles:
            if not self.test_summary_compilation(contract_handle.contract_name):
                self.log(
                    f"Summary compilation test failed for {contract_handle.contract_name} - please check llm_summaries.spec for syntax errors",
                    "ERROR",
                )
                compilation_failed_contracts.add(contract_handle.contract_name)

        # If all contracts failed compilation, return early
        if len(compilation_failed_contracts) == len(self.main_contract_handles):
            return (False, [])
        
        # If some contracts failed and continue_on_warmup_failure is False, return false early since we'll stop anyway
        if compilation_failed_contracts and not self.continue_on_warmup_failure:
            self.log(
                "Some contracts failed summary compilation and continue_on_warmup_failure is False - skipping warmup and returning failure",
                "ERROR",
            )
            successfully_compiled = [x for x in self.main_contract_handles if x.contract_name not in compilation_failed_contracts]
            self.log("Compiled contracts: " + ", ".join([ch.contract_name for ch in successfully_compiled]), "ERROR")
            self.log("Failed contracts: " + ", ".join(compilation_failed_contracts), "ERROR")
            return (False, successfully_compiled)

        try:
            self.log(
                f"🔀 Running split warmup for {len(self.main_contract_handles)} contracts in parallel"
            )

            # Create ProverJobSpec objects for warmup using ProverRunner pattern
            self.log("🚀 Preparing all sanity jobs in parallel...")

            # Build mapping from contract_name to ContractHandle for result tracking
            contract_name_to_handle: Dict[str, ContractHandle] = {
                ch.contract_name: ch for ch in self.main_contract_handles
            }

            # Track contracts that fail preparation (typechecker failures)
            prep_failed_contracts: set[str] = set()

            async def prepare_contract_warmup(contract_handle: ContractHandle) -> Optional[ProverJobSpec[Any]]:
                """Prepare warmup job spec for a single contract. Returns None if preparation fails."""
                contract_name = contract_handle.contract_name

                # Skip contracts that failed compilation test
                if contract_name in compilation_failed_contracts:
                    return None

                # Use sanity spec for typechecker fixes and loop-iter/hashing detection
                sanity_spec = self.certora_dir / f"sanity-{contract_name}.spec"
                enhanced_config = self.create_base_config(contract_name, sanity_spec)

                # If we will run call resolution, we have to remove the extra files from the .conf before running typechecker
                if not self.skip_call_resolution:
                    files_to_include = [contract_handle.to_config_str()] + self.additional_contracts
                    props = {"files": files_to_include}
                    self.log(f"Updating config {enhanced_config.path.name} to keep only contract {contract_handle.contract_name} and the --additional-contracts in the \"files\"")
                    self.config_manager.update_config_with_properties(enhanced_config.path, props)

                # Fix the base config with typechecker
                typechecker_success = await asyncio.to_thread(
                    self._fix_config_with_typechecker, enhanced_config.path, f"warmup {contract_name}"
                )
                if not typechecker_success:
                    self.log(
                        f"✗ Skipping warmup for {contract_name} due to typechecker failure",
                        "ERROR",
                    )
                    prep_failed_contracts.add(contract_name)
                    return None

                # Run call resolution for this contract using the enhanced config
                # It will update the underlying .conf and .spec files
                if not self.skip_call_resolution:
                    await self.run_single_contract_call_resolution(enhanced_config, contract_handle)

                # Detect and set suitable sanity flags (loop iter, hashing bounds)
                if not self.skip_sanity_setup:
                    await self.set_sanity_options(enhanced_config.path, contract_name)

                # Create test run config BEFORE switching to warmup-trivial spec,
                # because test flags need actual sanity rules to exercise
                test_config = self.config_manager.create_copy_with_prover_args(
                    enhanced_config.path, self.TEST_RUN_PROVER_ARGS, "_test_run"
                )
                self._test_run_specs.append(ProverJobSpec(
                    config_file=test_config,
                    contract_name=contract_name,
                    phase=f"Sanity Test Run - {contract_name}",
                    extra_args=self.extra_args,
                    msg=self._build_job_msg(contract_name, test_config.path),
                ))

                if skip_warmup:
                    return None

                # Switch to trivial warmup spec for the actual warmup job (only preprocessing)
                warmup_spec = self.create_warmup_spec(contract_name)
                self.config_manager.update_config_spec(enhanced_config.path, warmup_spec)

                # Create ProverJobSpec for warmup with fixed config
                return ProverJobSpec(
                    config_file=enhanced_config,
                    contract_name=contract_name,
                    phase="Sanity Warmup - warmup",
                    extra_args=self.extra_args,
                    msg=self._build_job_msg(contract_name, enhanced_config.path),
                )

            # Process all contracts in parallel and submit jobs
            async def prepare_and_run_warmup() -> List[ProverResult]:
                # Prepare all contracts in parallel
                tasks = [prepare_contract_warmup(handle) for handle in self.main_contract_handles]
                results = await asyncio.gather(*tasks)

                # Filter out None results (failed preparations)
                job_specs = [spec for spec in results if spec is not None]

                if skip_warmup or not job_specs:
                    return []

                # Submit and wait for all jobs
                return await self.prover_runner.submit_and_wait_for_jobs(job_specs)

            warmup_results = asyncio.run(prepare_and_run_warmup())

            # If skip_warmup, all contracts that passed prep are considered successful
            if skip_warmup:
                successful_contracts = [
                    ch for ch in self.main_contract_handles
                    if ch.contract_name not in compilation_failed_contracts
                    and ch.contract_name not in prep_failed_contracts
                ]
                all_success = len(successful_contracts) == len(self.main_contract_handles)
                return (all_success, successful_contracts)

            # Check results and track successful contracts
            all_success = True
            successful_contract_names: set[str] = set()
            for result in warmup_results:
                if result.success:
                    self.log(
                        f"✓ Completed: {result.job_handle.phase} for {result.job_handle.job_id.split('/')[-1]}"
                    )
                    if result.job_handle.job_id.startswith("http"):
                        self.log(f"📎 Job URL: {result.job_handle.job_id}")
                    # Track successful contract
                    successful_contract_names.add(result.job_spec.contract_name)
                else:
                    all_success = False
                    self.log(f"✗ Failed: {result.job_handle.phase}", "ERROR")

            self.log("✅ All sanity jobs completed")

            if not all_success:
                self.log(
                    "❌ Some sanity warmup jobs failed - please check the build status job URLs above for details",
                    "ERROR",
                )

            # Map successful contract names back to ContractHandle objects
            successful_contracts = [
                contract_name_to_handle[name]
                for name in successful_contract_names
                if name in contract_name_to_handle
            ]

            return (all_success, successful_contracts)

        finally:
            # Keep warmup config file for future adjustments
            pass

    async def run_single_contract_call_resolution(self, enhanced_config: FileContent, contract_handle: ContractHandle) -> bool:
        """Run call resolution for a single contract using its enhanced config."""
        try:
            # Initialize call resolution phase for this contract

            call_resolution_phase = CallResolutionPhase(
                scope=self.scope,
                prover_runner=self.prover_runner,
                config_manager=self.config_manager,
                config_file=enhanced_config.path,
                reports_dir=self.reports_dir,
                extra_args=self.extra_args,
                max_prover_invocations=10
            )

            # Execute call resolution
            self.log(f"🔗 Running call resolution for {contract_handle.contract_name}")
            await call_resolution_phase.execute(max_iterations=10)
            return True

        except Exception as e:
            self.log(f"⚠️ Call resolution failed for {contract_handle.contract_name}: {str(e)}", "WARNING")
            return False

    def run_all_configs(self, config_files: List[Path]) -> List[ProverResult]:
        """Run all configuration files and track results."""
        self.log("=== VERIFICATION PHASE ===")

        if not config_files:
            self.log("No configuration files found to run", "WARNING")
            return []

        results: list = []  # Collect ProverResult objects
        job_specs: list = []  # Collect ProverJobSpec objects

        # Apply max_configs limit if specified (for testing purposes)
        limited_config_files = config_files
        if self.max_configs and len(config_files) > self.max_configs:
            limited_config_files = config_files[: self.max_configs]
            self.log(
                f"🔢 Limiting to {self.max_configs} config files for testing (out of {len(config_files)} total)"
            )

        results = []  # Collect ProverResult objects
        job_specs = []  # Collect ProverJobSpec objects

        # Create ProverJobSpec objects for each contract
        for config_file in limited_config_files:
            tool_name = config_file.parent.name
            config_name = config_file.name
            contract_name = config_file.stem.split("-")[-1]
            try:
                # Create ProverJobSpec with msg field
                job_spec: ProverJobSpec[Any] = ProverJobSpec(
                    config_file=FileContent.from_file(config_file),
                    contract_name=contract_name,
                    phase=f"{tool_name}-{config_name}",
                    extra_args=self.extra_args,
                    msg=self._build_job_msg(contract_name, config_file),
                )

                job_specs.append(job_spec)
                self.log(
                    f"📝 Created job spec for {contract_name} with {tool_name}-{config_name}",
                    "DEBUG",
                )
            except Exception as e:
                self.log(
                    f"✗ Failed to create job spec for {contract_name}: {str(e)}",
                    "ERROR",
                )

        # Include test run specs (created during warmup with test prover flags)
        if self._test_run_specs:
            self.log(f"📝 Adding {len(self._test_run_specs)} test run job(s) to verification phase")
            job_specs.extend(self._test_run_specs)
            self._test_run_specs = []

        # Execute all jobs using parallel submission and waiting with immediate report generation
        # Use queue mode to enable dynamic addition of multi_assert_check follow-up jobs
        self.log(f"🔍 Created {len(job_specs)} job specifications")
        if job_specs:
            self.log(f"🚀 About to submit and wait for {len(job_specs)} jobs...")
            results = asyncio.run(
                self.prover_runner.submit_and_wait_for_jobs(
                    job_specs,
                    completion_callback=self._on_job_complete,
                    pre_execute_callback=self._pre_execute_typechecker_fix,
                    use_queue=True,
                )
            )
            self.log(f"✅ Received {len(results)} results from prover runner")
        else:
            self.log(
                "⚠️ No job specifications created - skipping verification phase",
                "WARNING",
            )
            results = []

        return results

    def _on_job_complete(self, result, job_queue=None) -> None:
        """Called immediately when each job completes to generate reports.

        If job_queue is provided, may add new jobs for multi_assert_check optimization.
        """
        # Store the result for signal handler access
        with self.job_results_lock:
            self.job_results.append(result)

        if (
            result.success
            and hasattr(result.job_handle, "job_id")
            and result.job_handle.job_id
        ):
            if result.job_handle.job_id.startswith("http"):
                try:
                    report_name = self._get_report_name_from_config_type(
                        result.job_handle.phase
                    )

                    # Generate detailed report for this job
                    stats: JobRuleStats = self.reporter.generate_report(
                        result.job_handle.job_id, report_name
                    )
                    with self.report_stats_lock:
                        if report_name in self.report_stats:
                            # Merge: existing stats from parent, new stats from retry
                            self._merge_job_stats(self.report_stats[report_name], stats)
                        else:
                            self.report_stats[report_name] = stats
                except Exception as e:
                    self.log(
                        f"⚠️ Failed to generate report for {result.job_handle.phase}: {e}",
                        "WARNING",
                    )

        # If queue is provided, check if we should add multi_assert_check jobs
        if job_queue is not None:
            multi_assert_jobs = self._create_multi_assert_jobs_if_needed(result)
            multi_assert_processed = len(multi_assert_jobs) > 0

            for new_job in multi_assert_jobs:
                job_queue.put_nowait(new_job)
            if multi_assert_jobs:
                self.log(
                    f"📥 Added {len(multi_assert_jobs)} multi_assert_check job(s) for {result.job_spec.contract_name}",
                    "INFO",
                )

            # Check if we should add difficult retry jobs (only if multi_assert didn't process)
            difficult_retry_jobs = self._create_difficult_retry_jobs_if_needed(
                result, multi_assert_processed
            )
            for new_job in difficult_retry_jobs:
                job_queue.put_nowait(new_job)
            if difficult_retry_jobs:
                self.log(
                    f"🔄 Added {len(difficult_retry_jobs)} difficult retry job(s) for {result.job_spec.contract_name}",
                    "INFO",
                )

        # Run setup completeness check (unless skipped)
        if not self.skip_setup_check and result.success:
            try:
                issues = self.setup_checker.analyze_result(result)
                if issues:
                    with self.report_stats_lock:
                        self.aggregated_setup_report.add_issues(issues)
                        self.log(
                            f"⚠️ Setup completeness: Found {len(issues)} issue(s) in {result.job_handle.phase}",
                            "WARNING",
                        )
                        # Save the report incrementally so it's available if the script exits prematurely
                        self._save_setup_completeness_report()
            except Exception as e:
                self.log(f"Setup completeness check failed: {e}", "WARNING")

    def _create_multi_assert_jobs_if_needed(self, result: ProverResult) -> List[ProverJobSpec]:
        """Create follow-up jobs with multi_assert_check=True if conditions are met.

        Conditions:
        1. The original config has multi_assert_check=False
        2. There are failed rules in the result

        Creates one job per unique failed rule name, with the methods that failed for that rule.
        Each job config will have:
        - rule: [rule_name]
        - methods: [method1, method2, ...]
        - multi_assert_check: True

        Returns a list of ProverJobSpec objects, or empty list if no follow-up jobs are needed.
        """
        if not result.success:
            # The run itself had an error
            return []

        # Get the config file path
        config_path = result.job_spec.config_file.path
        if not config_path.exists():
            return []

        try:
            # Parse the config file
            with open(config_path) as f:
                config_data = json5.load(f)

            multi_assert_check = config_data.get("multi_assert_check", None)
            if multi_assert_check is None or multi_assert_check is True:
                # multi_assert_check is missing, or is True, no follow-up needed
                return []

            # Group failed rules by rule_name, collecting methods for each
            rule_to_methods: Dict[str, Set[str]] = {}
            for rule_result in result.rule_results:
                if rule_result.failed:
                    rule_name = rule_result.rule_name
                    if rule_name not in rule_to_methods:
                        rule_to_methods[rule_name] = set()
                    if rule_result.method and not rule_result.method == "unknown_method":
                        rule_to_methods[rule_name].add(rule_result.method)

            if not rule_to_methods:
                # No failed rules with methods, no follow-up needed
                return []

            self.log(
                f"🔍 Found {len(rule_to_methods)} failed rule(s) for {result.job_spec.contract_name}: "
                f"{list(rule_to_methods.keys())}",
                "DEBUG",
            )

            # Create a job for each unique failed rule
            temp_dir = config_path.parent / ".multi_assert_configs"
            temp_dir.mkdir(exist_ok=True)

            new_jobs = []
            for rule_name, methods in rule_to_methods.items():
                # Create modified config with multi_assert_check=True and specific rule/methods
                new_config = config_data.copy()
                new_config["multi_assert_check"] = True
                new_config["rule"] = [rule_name]
                if methods:
                    new_config["method"] = list(methods)

                # Write the new config to a temp file
                # Use a unique name based on the original config and rule name
                new_config_path = temp_dir / f"{config_path.stem}_{rule_name}_multi_assert.conf"
                with open(new_config_path, "w") as f:
                    json.dump(new_config, f, indent=4)

                # Create new job spec
                contract_name = result.job_spec.contract_name
                new_job_spec = ProverJobSpec(
                    config_file=FileContent.from_file(new_config_path),
                    contract_name=contract_name,
                    phase=f"{result.job_spec.phase}_{rule_name}_multi_assert",
                    extra_args=result.job_spec.extra_args,
                    context=result.job_spec.context,
                    msg=self._build_job_msg(contract_name, new_config_path)
                )
                new_jobs.append(new_job_spec)

            return new_jobs

        except Exception as e:
            self.log(
                f"⚠️ Failed to create multi_assert_check jobs for {result.job_spec.contract_name}: {e}",
                "WARNING",
            )
            return []

    def _create_difficult_retry_jobs_if_needed(
        self, result: ProverResult, multi_assert_processed: bool
    ) -> List[ProverJobSpec]:
        """Create retry jobs for rules with timeout/unknown methods when job shows promise.

        LOOP PREVENTION: This method will NOT create retry jobs if the original job was itself
        a difficult retry (phase contains "_difficult_retry").

        "Hope" determination: Job is promising if at least one non-envfreeFuncsStaticCheck rule
        has a real result (VERIFIED or VIOLATED).

        Args:
            result: ProverResult from completed verification
            multi_assert_processed: Whether multi_assert already processed this config

        Returns:
            List of ProverJobSpec for retry jobs, empty if no retry needed
        """
        # 1. Check feature flag
        if not self.retry_difficult:
            return []

        # 2. LOOP PREVENTION: Check if this was already a difficult retry job
        if "_difficult_retry" in result.job_spec.phase:
            self.log(
                f"Skipping difficult retry for {result.job_spec.contract_name} - "
                f"job is already a retry (phase: {result.job_spec.phase})",
                "DEBUG"
            )
            return []

        # 3. Skip if multi_assert already processed this config
        if multi_assert_processed:
            self.log(
                f"Skipping difficult retry for {result.job_spec.contract_name} - "
                f"already processed by multi_assert",
                "DEBUG"
            )
            return []

        # 4. Check if job completed successfully
        if not result.success:
            return []

        # 5. Load and validate config
        config_path = result.job_spec.config_file.path
        if not config_path.exists():
            return []

        try:
            # 6. Check for "hope" (non-envfreeFuncsStaticCheck rules with real results)
            has_hope = False
            for rule_result in result.rule_results:
                if rule_result.rule_name == "envfreeFuncsStaticCheck":
                    continue
                if rule_result.status in ["VERIFIED", "VIOLATED"]:
                    has_hope = True
                    break

            if not has_hope:
                self.log(
                    f"No hope for {result.job_spec.contract_name} - "
                    f"no non-envfreeFuncsStaticCheck rules with real results",
                    "DEBUG"
                )
                return []

            # 7. Collect inconclusive methods (ALL rules including envfreeFuncsStaticCheck)
            rule_to_inconclusive_methods: Dict[str, Set[str]] = {}
            for rule_result in result.rule_results:
                if rule_result.status in ["TIMEOUT", "UNKNOWN"]:
                    rule_name = rule_result.rule_name
                    if rule_name not in rule_to_inconclusive_methods:
                        rule_to_inconclusive_methods[rule_name] = set()
                    if rule_result.method and not rule_result.method == "unknown_method":
                        rule_to_inconclusive_methods[rule_name].add(rule_result.method)

            if not rule_to_inconclusive_methods:
                return []

            # 8. Create retry jobs
            temp_dir = config_path.parent / ".difficult_retry_configs"
            temp_dir.mkdir(exist_ok=True)

            new_jobs = []
            total_methods = sum(len(methods) for methods in rule_to_inconclusive_methods.values())

            with open(config_path) as f:
                config_data = json5.load(f)

            for rule_name, methods in rule_to_inconclusive_methods.items():
                # Copy config and customize for this rule's retry
                new_config = config_data.copy()
                new_config["rule"] = [rule_name]
                if methods:
                    new_config["method"] = list(methods)

                # Write config
                new_config_path = temp_dir / f"{config_path.stem}_{rule_name}_difficult_retry.conf"
                with open(new_config_path, "w") as f:
                    json.dump(new_config, f, indent=4)

                # Create job spec
                contract_name = result.job_spec.contract_name
                new_job_spec = ProverJobSpec(
                    config_file=FileContent.from_file(new_config_path),
                    contract_name=contract_name,
                    phase=f"{result.job_spec.phase}_{rule_name}_difficult_retry",  # Phase contains "_difficult_retry"
                    extra_args=result.job_spec.extra_args,
                    context=result.job_spec.context,
                    msg=self._build_job_msg(contract_name, new_config_path)
                )
                new_jobs.append(new_job_spec)

            if new_jobs:
                self.log(
                    f"🔍 Creating {len(new_jobs)} difficult retry job(s) for {contract_name} "
                    f"({total_methods} timeout/unknown methods across {len(rule_to_inconclusive_methods)} rules)",
                    "INFO"
                )

            return new_jobs

        except Exception as e:
            self.log(
                f"⚠️ Failed to create difficult retry jobs for {result.job_spec.contract_name}: {e}",
                "WARNING"
            )
            return []

    def _merge_job_stats(self, parent_stats: JobRuleStats, retry_stats: JobRuleStats) -> None:
        """Merge retry job stats into parent stats.

        When a difficult_retry job completes, it covers rules that were TIMEOUT or UNKNOWN
        in the parent job. We merge the results by:
        1. Subtracting the retried rules from parent's timeout/unknown counts
        2. Adding retry's results (which may have resolved some rules)

        This ensures we don't double-count rules that were retried.

        This assumes we had just one pass for retrying.
        """
        # Total rules that were retried (these were timeout/unknown in parent)
        retried_count = (retry_stats.verified + retry_stats.violations +
                        retry_stats.timeout + retry_stats.unknown)

        # Reduce parent's timeout/unknown counts (these rules were retried)
        # Since we don't know exact split, reduce from unknown first, then timeout
        remaining_to_reduce = retried_count
        reduction_from_unknown = min(parent_stats.unknown, remaining_to_reduce)
        parent_stats.unknown -= reduction_from_unknown
        remaining_to_reduce -= reduction_from_unknown

        reduction_from_timeout = min(parent_stats.timeout, remaining_to_reduce)
        parent_stats.timeout -= reduction_from_timeout

        # Add retry's results
        parent_stats.verified += retry_stats.verified
        parent_stats.violations += retry_stats.violations
        parent_stats.timeout += retry_stats.timeout
        parent_stats.unknown += retry_stats.unknown

        # Merge violation_rules list
        parent_stats.violation_rules.extend(retry_stats.violation_rules)

    def _get_report_name_from_config_type(self, config_or_type: str) -> str:
        """Extract a clean report name from config_or_type."""
        if config_or_type == "sanity":
            return "sanity"
        else:
            # Handle contract splitting where keys are "config_path#contract_name"
            if "#" in config_or_type:
                config_path_str, contract_name = config_or_type.split("#", 1)
                config_path = Path(config_path_str)
                return f"{config_path.parent.name}_{config_path.stem}_{contract_name}"
            else:
                # Extract a clean name from the config path
                config_path = Path(config_or_type)
                return f"{config_path.parent.name}_{config_path.stem}"

    def _save_setup_completeness_report(self) -> None:
        """Save the setup completeness report to disk.

        This is called incrementally after each job to ensure the report is
        available even if the script exits prematurely.
        """
        try:
            self.aggregated_setup_report.save()
        except Exception as e:
            self.log(f"Failed to save setup completeness report: {e}", "WARNING")

    def generate_final_reports(
        self, verification_results: List[ProverResult] | None = None
    ) -> None:
        try:
            # Use provided results or stored job results
            if verification_results is None:
                with self.job_results_lock:
                    verification_results = self.job_results.copy()
            # Use stored report statistics from parallel execution
            with self.report_stats_lock:
                all_report_stats = self.report_stats.copy()

            # Generate final md reports
            setup_report = None if self.skip_setup_check else self.aggregated_setup_report
            self.reporter.generate_comprehensive_report(verification_results, all_report_stats, setup_report, self.bytes_mappings)
            self.reporter.generate_summarized_reports(verification_results, all_report_stats)
            self.reporter.generate_sanity_summary_table(verification_results)

            if setup_report and setup_report.has_issues and setup_report.md_path:
                self.log(f"⚠️ Setup completeness report: {setup_report.md_path}")

            # Generate JSON report for automated testing
            self.log("=== GENERATING JSON RESULT ===")
            json_data = self.json_reporter.generate_orchestrator_results_json(
                verification_results, all_report_stats, self._get_report_name_from_config_type, self.execution_info
            )
            json_file = self.json_reporter.save_orchestrator_results_json(json_data)
            self.results_json_path = json_file
            self.log(f"📄 JSON test results saved to: {json_file}")
        except Exception as e:
            self.log(f"❌ Failed to generate final reports: {e}", "ERROR")
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}", "ERROR")

    def print_summary(
        self, warmup_success: bool, verification_results: List[ProverResult]
    ):
        """Print execution summary."""
        self.log("=== EXECUTION SUMMARY ===")

        # Warmup result
        warmup_status = "✓ PASSED" if warmup_success else "✗ FAILED"
        self.log(f"Cache Warmup: {warmup_status}")

        # Verification results
        if verification_results:
            passed = sum(1 for result in verification_results if result.success)
            total = len(verification_results)

            self.log(f"Verification Results: {passed}/{total} configurations passed")

            # Show cache statistics (let ProverRunner handle cache details)
            try:
                cache_stats = self.prover_runner.get_cache_status(self.project_root)
                if cache_stats.get("cache_exists", False):
                    total_entries = cache_stats.get("total_entries", 0)
                    self.log(
                        f"Cache Performance: {total_entries} cached entries available"
                    )
            except Exception as e:
                self.log(f"Could not retrieve cache statistics: {e}", "DEBUG")

            for result in verification_results:
                status = "✓ PASSED" if result.success else "✗ FAILED"
                config_name = Path(result.job_handle.config_file).name
                self.log(f"  {config_name}: {status}")
        else:
            self.log("No verification configurations were run")

        if self.bytes_mappings:
            for line in self.reporter.bytes_mapping_warning(self.bytes_mappings):
                self.log(line, "WARNING")

    def _load_bytes_mappings(self) -> None:
        """Load bytes mappings from the persistent JSON file generated during compilation analysis."""
        import json
        from pathlib import Path

        bytes_mappings_file = Path(".certora_internal/bytes_mappings.json")

        if not bytes_mappings_file.exists():
            self.log("bytes_mappings.json not found - no bytes mappings detected", "DEBUG")
            self.bytes_mappings = []
            return

        try:
            with open(bytes_mappings_file, 'r') as f:
                data = json.load(f)

            # Convert JSON format to ContractHandle tuples
            self.bytes_mappings = []
            for entry in data:
                contract_handle = ContractHandle(
                    contract_name=entry["contract_name"],
                    source_file=entry["source_file"]
                )
                self.bytes_mappings.append((contract_handle, entry["bytes_mapping_fields"]))

            if self.bytes_mappings:
                self.log(f"Loaded {len(self.bytes_mappings)} contract(s) with bytes mappings from cache")

        except Exception as e:
            self.log(f"Warning: Failed to load bytes_mappings.json: {e}", "WARNING")
            self.bytes_mappings = []

    def _run_rule_generation_and_verification(
        self,
        skip_warmup: bool = False,
        start_time: float | None = None,
    ) -> bool:
        """Generate rules, execute verification, and handle results presentation.

        Returns:
            bool: Overall success of the verification process
        """
        # Log the dashboard URL where all jobs can be viewed (use SUCCESS level to always show)
        dashboard_url = self._get_jobs_dashboard_url()
        self.log("", "SUCCESS")
        self.log(f"📊 All jobs can be viewed at: {dashboard_url}", "SUCCESS")
        self.log("", "SUCCESS")

        if self.setup_prover_instance is None:
            self.log("❌ setup_prover_instance is None", "ERROR")
            return False
        try:
            contract_to_summary, updated_config_dict, import_patcher_applied = (
                self.setup_prover_instance.setup_prover(self.contract_handles, self.main_contract_handles)
            )
        except (CompilationAnalysisError, SummarySetupError) as e:
            self.log(f"❌ {e}", "ERROR")
            return False

        # Update orchestrator's scope with the signature database created by setup_prover
        self._load_signature_database_to_scope()

        # Store configuration updates for later use
        self.compilation_config_updates = updated_config_dict
        self.import_patcher_applied = import_patcher_applied
        self.rule_generator.generate_sanity_specs(contract_to_summary)

        # Load bytes mappings from persistent file (generated during compilation analysis)
        self._load_bytes_mappings()

        # Base Generation and Cache warmup (unless skipped)
        warmup_success, successful_contracts = self.generate_base_and_run_warmup(skip_warmup)

        # Always filter to successful contracts (handles compilation failures even when warmup "succeeds")
        if successful_contracts != self.main_contract_handles:
            failed_contract_names = [
                c.contract_name for c in self.main_contract_handles
                if c not in successful_contracts
            ]
            if failed_contract_names:
                self.log(
                    f"Continuing with {len(successful_contracts)} successful contract(s), "
                    f"skipping failed: {failed_contract_names}",
                    "WARNING"
                )
            self.main_contract_handles = successful_contracts

        if not warmup_success and not self.continue_on_warmup_failure:
            self.log("Cache warmup failed - stopping orchestration", "ERROR")
            return False

        # Verify we have contracts to continue with
        if not self.main_contract_handles:
            self.log("No contracts remaining after warmup failures - stopping orchestration", "ERROR")
            return False

        # If skip_checkers mode, run test run jobs and generate sanity report, then stop
        if self.skip_checkers:
            self.log("=== SANITY-ONLY MODE: Skipping rule generation and verification ===")

            test_run_results: List[ProverResult] = []
            if self._test_run_specs:
                self.log(f"Running {len(self._test_run_specs)} sanity test run job(s)...")
                test_run_results = asyncio.run(
                    self.prover_runner.submit_and_wait_for_jobs(self._test_run_specs)
                )
                self._test_run_specs = []

            self.generate_final_reports(test_run_results)

            if start_time is not None:
                elapsed = time.time() - start_time
                self.log(f"Total execution time: {elapsed:.1f}s")

            self.log("Sanity-only mode complete. Skipping rule generation and full verification.")
            return warmup_success

        # Generate checkers - run per contract to inject summaries during generation
        for contract in self.main_contract_handles:
            contract_name = contract.contract_name
            base_config = self.base_config_path(contract_name)
            summary_spec = contract_to_summary.get(contract_name)

            config = GeneratorConfig(
                main_contract=contract,
                base_config=base_config,
                **self.generator_config_base,
            )

            # Check if this contract needs regeneration (per-contract caching)
            if not self.rule_generator.should_regenerate(config):
                self.log(f"Skipping generation for {contract_name} - using cached files")
                continue

            inheritance_graph = self.scope.signature_database.build_inheritance_graph()
            self.log(f"Built inheritance graph with {len(inheritance_graph._graph)} contracts for {contract_name}")
            success = self.rule_generator.run_all_generators(
                config, summary_spec=summary_spec, inheritance_graph=inheritance_graph
            )
            if not success:
                self.log(f"❌ Rule generation failed for {contract_name} - stopping orchestration", "ERROR")
                return False

        # Run AutoCVL if enabled (generates additional specs and configs)
        if self.enable_autocvl:
            autocvl_success = asyncio.run(self.run_autocvl())
            if not autocvl_success:
                self.log("⚠️ AutoCVL failed — continuing without AutoCVL specs", "WARNING")

        # Phase 2: Find and run all configurations
        config_files = self.rule_generator.find_generated_configs()
        self.log(
            f"🔍 DEBUG: Found {len(config_files)} config files, about to call run_all_configs"
        )

        # Merge build system configuration into all generated configs
        self.merge_build_system_into_generated_configs(config_files)

        verification_results = self.run_all_configs(config_files)

        # Check if configuration execution failed due to submission failures
        if not verification_results and config_files and self.require_all_submissions:
            self.log(
                "❌ Orchestration failed due to verification submission failures",
                "ERROR",
            )
            return False

        # Phase 3: Generate comprehensive reports (jobs are already completed since run_all_configs is blocking)
        if verification_results:
            self.log(f"📋 Total jobs: {len(verification_results)}")

            if self.verbose:
                for result in verification_results:
                    if isinstance(result.job_handle, str):
                        continue  # Skip string handles
                    job_id = result.job_handle.job_id
                    if job_id.startswith("http"):
                        self.log(f"  - {result.job_handle.phase}: {job_id}")
                    else:
                        self.log(f"  - {result.job_handle.phase}: {job_id} (local)")

            # Generate reports for completed jobs
            self.generate_final_reports(verification_results)
        else:
            self.log("No jobs were submitted - skipping report generation", "WARNING")

        # Summary and analysis of overall results
        if start_time is not None:
            elapsed = time.time() - start_time
            self.print_summary(warmup_success, verification_results)
            self.log(f"Total execution time: {elapsed:.1f}s")

        # Determine failed results based on return codes and output, not just result.success
        failed_results = [
            result for result in verification_results if result.is_failure()
        ]
        if failed_results and self.require_all_submissions:
            self.log(
                f"❌ {len(failed_results)} configuration(s) failed to submit",
                "ERROR",
            )
            # Log details of failed configurations
            for result in failed_results:
                if hasattr(result, "job_handle") and result.job_handle:
                    config_file = Path(result.job_handle.config_file).name
                    error_msg = getattr(result, "error_message", "Unknown error")

                    # Enhanced logging with additional diagnostic info
                    log_parts = [f"  ✗ Failed config: {config_file} - {error_msg}"]

                    # Add duration if available
                    if hasattr(result, "duration") and result.duration:
                        log_parts.append(f"Duration: {result.duration:.1f}s")

                    # Add job URL if available
                    if hasattr(result, "job_url") and result.job_url:
                        log_parts.append(f"URL: {result.job_url}")

                    # Add return code if available in output_data
                    if hasattr(result, "output_data") and result.output_data:
                        if "return_code" in result.output_data:
                            log_parts.append(
                                f"Return code: {result.output_data['return_code']}"
                            )

                        # Add truncated certoraRun output for debugging
                        if "output" in result.output_data:
                            output = str(result.output_data["output"])
                            if output.strip():
                                # Truncate output to avoid log spam but keep enough for debugging
                                output_preview = (
                                    output[:500] + "..."
                                    if len(output) > 500
                                    else output
                                )
                                log_parts.append(f"certoraRun output: {output_preview}")

                    # Add job status if available
                    if result.job_handle.status:
                        log_parts.append(f"Status: {result.job_handle.status.value}")

                    self.log(" | ".join(log_parts), "ERROR")
                else:
                    self.log(
                        f"  ✗ Failed config: Unknown config file - {getattr(result, 'error_message', 'Unknown error')}",
                        "ERROR",
                    )
            self.log(
                "Orchestration failed due to submission failures (use --allow-submission-failures to continue)",
                "ERROR",
            )
            return False
        elif failed_results:
            self.log(
                f"⚠️ {len(failed_results)} configuration(s) failed to submit but continuing",
                "WARNING",
            )
            # Log details of failed configurations for warnings too
            for result in failed_results:
                if hasattr(result, "job_handle") and result.job_handle:
                    config_file = Path(result.job_handle.config_file).name
                    error_msg = getattr(result, "error_message", "Unknown error")
                    self.log(
                        f"  ⚠️ Failed config: {config_file} - {error_msg}", "WARNING"
                    )
                else:
                    self.log(
                        f"  ⚠️ Failed config: Unknown config file - {getattr(result, 'error_message', 'Unknown error')}",
                        "WARNING",
                    )

        # Return success if warmup passed and at least one verification passed
        overall_success = (
            warmup_success
            and any(
                not result.is_failure() for result in verification_results
            )
            if verification_results
            else warmup_success
        )
        return overall_success

    def run_orchestration(
        self,
        skip_warmup: bool = False,
    ) -> bool:
        """Run the complete orchestration process."""
        start_time = time.time()
        self.log("Starting PreAudit orchestration")
        self.log(f"📁 Generated specs will be stored in: {self.certora_dir}")

        # Setup build system configuration (Foundry or Hardhat)
        self.setup_build_system_config()

        # Phase II: Generate rules, execute verification, and handle results
        return self._run_rule_generation_and_verification(
            skip_warmup, start_time
        )

    async def run_autocvl(self) -> bool:
        """
        Run AutoCVL for all main contracts if enabled.

        Returns:
            bool: True if all AutoCVL runs succeeded or AutoCVL is disabled
        """
        if not self.enable_autocvl:
            self.log("AutoCVL disabled, skipping")
            return True

        self.log("=== Running AutoCVL ===", "INFO")

        # Create AutoCVL config
        autocvl_config = AutoCVLConfig(
            iterative=self.autocvl_iterative,
            max_iterations=self.autocvl_max_iterations,
        )

        # Create runner
        runner = AutoCVLRunner(
            autocvl_config=autocvl_config,
            certora_dir=self.certora_dir,
            log_func=self.log,
        )

        # Build base config paths mapping
        base_config_paths = {
            contract.contract_name: self.base_config_path(contract.contract_name)
            for contract in self.main_contract_handles
        }

        # Get solc settings from build system config
        solc = "solc"
        remappings: List[str] = []
        via_ir = False

        if self.build_system_config:
            solc = self.build_system_config.solc_version or "solc"
            via_ir = self.build_system_config.via_ir or False
            remappings = getattr(self.build_system_config, "packages", None) or []

        try:
            # Run AutoCVL for all contracts
            self.autocvl_results = await runner.run_for_contracts(
                contract_handles=self.main_contract_handles,
                base_config_paths=base_config_paths,
                solc=solc,
                remappings=remappings,
                via_ir=via_ir,
            )

            # Log summary
            success_count = sum(1 for r in self.autocvl_results.values() if r.success)
            total_count = len(self.autocvl_results)
            self.log(f"✓ AutoCVL completed: {success_count}/{total_count} contracts succeeded", "SUCCESS")

            return all(r.success for r in self.autocvl_results.values())

        except Exception as e:
            self.log(f"✗ AutoCVL failed: {e}", "ERROR")
            return False

    async def set_sanity_options(
        self, conf: Path, contract_name: Optional[str] = None
    ) -> None:
        """
        Set sanity options for a configuration file using SanityPhase.

        Args:
            conf: Path to the configuration file to optimize
            contract_name: Optional contract name. If not provided, will be extracted from config file
        """
        # Import sanity phase
        from src.setup.sanity import SanityPhase

        try:
            self.log(f"Starting sanity optimization for config: {conf}")

            # Extract contract name from config file if not provided
            if contract_name is None:
                contract_name = self.config_manager.extract_contract_name_from_config(conf)
                self.log(f"Extracted contract name from config: {contract_name}")

            # Create SanityPhase instance
            sanity_phase = SanityPhase(
                contract_name=contract_name,
                config_file=conf,
                prover_runner=self.prover_runner,
                config_manager=self.config_manager,
                orchestration_timestamp=self.orchestration_timestamp,
                extra_args=self.extra_args,
            )

            # Execute sanity phase
            await sanity_phase.execute()

            self.log(f"✅ Sanity optimization completed for {contract_name}")

        except Exception as e:
            self.log(f"❌ Error during sanity optimization for {conf}: {e}", "ERROR")
            raise

    def cleanup_running_jobs(self):
        """Cancel all running jobs to save cloud costs."""
        import asyncio

        try:
            # Check if there's already a running event loop
            try:
                asyncio.get_running_loop()
                # We're in an async context, run in a separate thread
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        asyncio.run,
                        self.prover_runner.cleanup_all_running_jobs()
                    )
                    cancelled_count = future.result(timeout=30)
            except RuntimeError:
                # No running loop, safe to use asyncio.run
                cancelled_count = asyncio.run(self.prover_runner.cleanup_all_running_jobs())

            if cancelled_count > 0:
                self.log(f"✅ Cancelled {cancelled_count} running jobs")
            else:
                self.log("No running jobs to cancel")
        except Exception as e:
            self.log(f"❌ Error during job cleanup: {e}", "ERROR")


# Global variable to hold orchestrator instance for signal handling
_orchestrator_instance = None
# Progress display instance (set by src.preaudit for spinner cleanup on Ctrl+C)
_progress_display = None


def signal_handler(signum, frame):
    """Handle SIGINT (Ctrl+C) by cancelling running jobs and generating partial reports."""
    _ = signum, frame  # Suppress unused variable warnings

    # Stop the progress spinner before printing (clears the spinner line)
    if _progress_display is not None:
        _progress_display.stop(show_100=False)

    print("\nReceived interrupt signal (Ctrl+C)")
    if _orchestrator_instance:
        # First, cancel running jobs to save costs
        _orchestrator_instance.cleanup_running_jobs()

        # Then generate partial reports for any completed jobs
        with _orchestrator_instance.job_results_lock:
            has_job_results = len(_orchestrator_instance.job_results) > 0

        if has_job_results:
            print("📊 Generating partial report for completed jobs...")
            try:
                _orchestrator_instance.generate_final_reports()
                print("✅ Partial report generated successfully")
            except Exception as e:
                print(f"❌ Failed to generate partial report: {e}")
        else:
            print("ℹ️ No completed jobs to report")

    print("👋 Exiting...")
    sys.exit(1)


def main():
    # Create argument parser
    parser = create_parser()

    # Parse arguments
    args = parser.parse_args()

    # Handle cache-only operations first (before file validation)
    if args.cache_status:
        from src.utils.enhanced_config_manager import ConfigManager

        ConfigManager.print_cache_status(Path.cwd())
        sys.exit(0)

    contract_handles = []
    if args.contract_files_and_name:
        try:
            contract_handles = parse_contract_files(args.contract_files_and_name)
        except ValueError as e:
            print(f"{e}")
            print(f"Error while parsing provided contract files, the correct syntax is path/to/ContractFilename.sol:ContractName, where ContractName can be omitted when it is the same as ContractFilename.")
            sys.exit(1)
    else:
        print(
            "No contract files specified - auto-detecting build system..."
        )

    if not contract_handles:
        # Auto-detect build system and use appropriate parser
        try:
            # Detect build system (Foundry or Hardhat)
            build_system = BuildSystemDetector.detect(Path.cwd())

            if build_system == BuildSystem.UNKNOWN:
                print("Error: No build system detected (Foundry or Hardhat)")
                print("Expected foundry.toml or hardhat.config.{js,ts}")
                sys.exit(1)

            print(f"Detected build system: {build_system.value}")

            # Get contract extractor instance for the detected build system
            contract_extractor = BuildSystemDetector.get_contract_extractor(
                build_system,
                Path.cwd(),
                profile=args.profile,
            )

            # Parse ambiguous_files if provided
            ambiguous_contract_handles = []
            if args.ambiguous_files:
                ambiguous_contract_handles = parse_contract_files(args.ambiguous_files)

            # Get logic contracts and matching files from detected build system
            contract_handles = contract_extractor.extract_logic_contracts_and_files(
                ambiguous_contract_handles,
                auto_resolve_ambiguous=args.auto_ambiguous_contracts_resolve
            )

        except Exception as e:
            print(f"Error during contract auto-detection: {e}")
            import traceback

            print(f"Traceback: {traceback.format_exc()}")
            sys.exit(1)

    # Handle extra args from --extra-args argument
    if args.extra_args:
        # Split the quoted string into individual arguments
        import shlex

        final_extra_args = shlex.split(args.extra_args)
    else:
        final_extra_args = []

    # Create generator configuration
    generator_config_base = {
        "enable_extcall": not args.disable_extcall,
        "extcall_mode": args.extcall_mode,
        "extcall_check_non_zero": args.extcall_check_non_zero,
        "enable_privileged": not args.disable_privileged,
        "extra_args": final_extra_args,
        "additional_contracts": args.additional_contracts or [],
    }

    # Create orchestrator first
    orchestrator = CertoraOrchestrator(
        verbose=args.verbose,
        generator_config=generator_config_base,
        use_cache=not args.no_cache,
        require_all_submissions=args.require_all_submissions,
        retry_difficult=args.retry_difficult,
        skip_breadcrumbs=args.skip_breadcrumbs,
        skip_checkers=args.skip_checkers,
        skip_sanity_setup=args.skip_sanity_setup,
        skip_call_resolution=args.skip_call_resolution,
        skip_setup_check=args.skip_setup_check,
        certora_run_command=args.certora_run_command,
        use_local_runner=args.use_local_runner,
        max_configs=args.max_configs,
        dummy_erc20=args.dummy_erc20,
        keep_intermediate_typechecker_files=args.keep_intermediate_typechecker_files,
        cancel_cloud_jobs_on_cleanup=not args.no_cancel_jobs_on_cleanup,
        include_foundry_packages=not args.exclude_foundry_packages,
        continue_on_warmup_failure=args.continue_on_warmup_failure,
        build_system=args.build_system,
        profile=args.profile,
        enable_autocvl=args.enable_autocvl,
        autocvl_iterative=args.autocvl_iterative,
        autocvl_max_iterations=args.autocvl_max_iterations,
    )

    # Ensure git config files have recommended Certora settings
    orchestrator.ensure_git_config_files()

    # Store execution info for JSON reporting - automatically captures all arguments
    orchestrator.execution_info = {
        "command_line": sys.argv,
        "parsed_args": vars(args),  # All arguments automatically
        "files": [ch.source_file for ch in contract_handles],
        "contract_names": [ch.contract_name for ch in contract_handles],
    }

    # Create setup prover instance and configure it with orchestrator dependencies
    setup_prover = SetupProver(
        log=orchestrator.log,
        certora_dir=orchestrator.certora_dir,
        script_dir=orchestrator.script_dir,
        additional_contracts=orchestrator.additional_contracts,
        extra_args=orchestrator.extra_args,
        skip_llm=args.skip_llm,
        force_llm_regenerate=args.force_llm_regenerate,
        stop_after_summaries=args.stop_after_summaries,
        scope=orchestrator.scope,
        verbose=orchestrator.verbose,
        certora_run_command=args.certora_run_command,
        contract_names=[ch.contract_name for ch in contract_handles],
        get_build_system_config_dict=orchestrator.get_build_system_config_dict,
        solc_default_version=args.solc_default,
    )

    # Assign the configured setup_prover to the orchestrator
    orchestrator.setup_prover_instance = setup_prover

    # Set up global instance and signal handler for job cancellation on Ctrl+C
    global _orchestrator_instance
    _orchestrator_instance = orchestrator
    signal.signal(signal.SIGINT, signal_handler)

    # Also register cleanup on normal exit
    atexit.register(orchestrator.cleanup_running_jobs)

    # Handle cache clearing
    if args.clear_cache:
        from src.utils.enhanced_config_manager import ConfigManager as CacheConfigManager

        CacheConfigManager.clear_cache_and_print(Path.cwd())

    # Add detected contracts to orchestrator instance (may already contain dummy contracts)
    orchestrator.contract_handles.extend(contract_handles)

    # Determine main contracts to verify
    if args.main_contracts:
        try:
            orchestrator.main_contract_handles = parse_contract_files(args.main_contracts)
        except ValueError as e:
            print(f"{e}")
            sys.exit(1)
    else:
        # If no main contracts specified, use all detected contracts
        orchestrator.main_contract_handles = contract_handles

    # Run orchestration
    success = orchestrator.run_orchestration(
        skip_warmup=args.skip_warmup
    )

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
