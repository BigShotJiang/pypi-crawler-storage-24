import numpy as np
import pytest
from pmtvs_physics import hurst_viscosity


def test_persistent_series_high_viscosity():
    """Trending series has H close to 1 — high viscosity."""
    series = np.cumsum(np.ones(200))
    v = hurst_viscosity(series)
    assert not np.isnan(v), "Should not be NaN for 200-pt series"
    assert v > 0.7, f"Trend should have H > 0.7, got {v:.3f}"


def test_short_series_returns_nan():
    """Series shorter than 50 observations → NaN."""
    assert np.isnan(hurst_viscosity(np.ones(10)))
    assert np.isnan(hurst_viscosity(np.array([])))
    assert np.isnan(hurst_viscosity(np.ones(49)))


def test_output_in_unit_interval():
    """All valid outputs must be in [0, 1]."""
    rng = np.random.default_rng(42)
    for _ in range(10):
        n      = rng.integers(50, 300)
        series = rng.normal(0, 1, n)
        v      = hurst_viscosity(series)
        if not np.isnan(v):
            assert 0.0 <= v <= 1.0, f"H={v:.4f} outside [0,1]"


def test_nan_in_series_handled():
    """NaN values in input are stripped before computation."""
    rng    = np.random.default_rng(42)
    series = rng.normal(0, 1, 200).tolist()
    series[10] = float('nan')
    series[50] = float('nan')
    v = hurst_viscosity(np.array(series))
    # Should still compute on the 198 finite values
    assert not np.isnan(v)
