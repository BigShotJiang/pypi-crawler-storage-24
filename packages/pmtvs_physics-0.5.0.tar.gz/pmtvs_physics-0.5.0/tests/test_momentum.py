import numpy as np
import pytest
from pmtvs_physics import (
    compute_momentum,
    compute_reynolds_analog,
    classify_flow_regime,
    compute_dissipation_rate,
)


def test_momentum_multiplication():
    assert compute_momentum(5.0, 3.0) == pytest.approx(15.0)
    assert compute_momentum(0.0, 3.0) == pytest.approx(0.0)
    assert compute_momentum(2.5, 4.0) == pytest.approx(10.0)


def test_momentum_nan_on_invalid():
    assert np.isnan(compute_momentum(-1.0, 3.0))
    assert np.isnan(compute_momentum(float('nan'), 3.0))
    assert np.isnan(compute_momentum(5.0, float('nan')))


def test_reynolds_high_momentum_high_re():
    re = compute_reynolds_analog(100.0, 0.5)
    assert re > 10.0, f"High momentum should give Re > 10, got {re:.2f}"


def test_reynolds_high_viscosity_low_re():
    re = compute_reynolds_analog(1.0, 0.9)
    assert re < 2.0, f"High viscosity should give Re < 2, got {re:.2f}"


def test_reynolds_nan_viscosity_uses_epsilon():
    """NaN viscosity falls back to epsilon — should not raise."""
    re = compute_reynolds_analog(5.0, float('nan'))
    assert np.isfinite(re), "NaN viscosity should use epsilon fallback"
    assert re > 0


def test_reynolds_nan_momentum_returns_nan():
    assert np.isnan(compute_reynolds_analog(float('nan'), 0.5))


def test_flow_regime_classification():
    assert classify_flow_regime(0.5)         == 'laminar'
    assert classify_flow_regime(5.0)         == 'transitional'
    assert classify_flow_regime(50.0)        == 'turbulent'
    assert classify_flow_regime(float('nan')) == 'unknown'


def test_flow_regime_boundaries():
    assert classify_flow_regime(1.0)  == 'laminar'       # at threshold
    assert classify_flow_regime(10.0) == 'transitional'  # at threshold
    assert classify_flow_regime(10.1) == 'turbulent'


def test_dissipation_formula():
    d = compute_dissipation_rate(0.7, 2.0)
    assert d == pytest.approx(0.7 * 4.0)  # 0.7 × 2² = 2.8


def test_dissipation_zero_gradient():
    assert compute_dissipation_rate(0.7, 0.0) == pytest.approx(0.0)


def test_dissipation_nan_viscosity():
    assert np.isnan(compute_dissipation_rate(float('nan'), 2.0))
