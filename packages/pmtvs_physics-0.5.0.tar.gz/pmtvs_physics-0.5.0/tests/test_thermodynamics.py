import numpy as np
import pytest
from pmtvs_physics import detect_phase_transition, free_energy_slope


def test_sign_change_detected():
    F  = np.array([5.0, 3.0, 1.0, -0.5, -2.0])
    Cv = np.array([0.1, 0.2, 0.5,  0.3,  0.1])
    r  = detect_phase_transition(F, Cv)
    assert r['transition_detected']
    assert r['transition_window'] == 3


def test_pre_transition_warning():
    """Cv peaks at window 1, F goes negative at window 3."""
    F  = np.array([5.0, 3.0, 1.0, -0.5, -2.0])
    Cv = np.array([0.1, 2.5, 0.3,  0.1,  0.1])
    r  = detect_phase_transition(F, Cv)
    assert r['pre_transition_warning']
    assert r['heat_capacity_peak_window'] == 1
    assert r['transition_window'] == 3


def test_no_transition_when_f_positive():
    F  = np.array([5.0, 4.0, 3.0, 2.0, 1.0])
    Cv = np.array([0.1, 0.1, 0.1, 0.1, 0.1])
    r  = detect_phase_transition(F, Cv)
    assert not r['transition_detected']
    assert r['transition_window'] is None
    assert not r['pre_transition_warning']


def test_immediate_transition():
    """F is negative from the first window."""
    F  = np.array([-1.0, -2.0, -3.0])
    Cv = np.array([ 0.1,  0.1,  0.1])
    r  = detect_phase_transition(F, Cv)
    assert r['transition_detected']
    assert r['transition_window'] == 0


def test_free_energy_slope_negative():
    """Declining F should have negative slope."""
    F = np.array([5.0, 3.0, 1.0, -1.0, -3.0])
    s = free_energy_slope(F)
    assert s < 0, f"Declining F should have negative slope, got {s}"


def test_free_energy_slope_positive():
    """Rising F should have positive slope."""
    F = np.array([-3.0, -1.0, 1.0, 3.0, 5.0])
    s = free_energy_slope(F)
    assert s > 0, f"Rising F should have positive slope, got {s}"


def test_free_energy_slope_short_series():
    """Fewer than 3 finite values → NaN."""
    assert np.isnan(free_energy_slope(np.array([1.0, 2.0])))
    assert np.isnan(free_energy_slope(np.array([float('nan')] * 5)))


def test_nan_in_free_energy_handled():
    """NaN values in F are skipped for slope computation."""
    F = np.array([5.0, float('nan'), 1.0, float('nan'), -3.0])
    s = free_energy_slope(F)
    assert np.isfinite(s), "Should compute slope on finite values"
