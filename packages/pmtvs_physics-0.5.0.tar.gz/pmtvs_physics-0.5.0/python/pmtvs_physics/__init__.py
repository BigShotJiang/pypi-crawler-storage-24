"""
pmtvs-physics: Physics analogs for signal manifold analysis.

Pure math functions. Arrays in, scalars/arrays out.
No file IO. No orchestration. No pipeline awareness.

Novel physics analogs applied to manifold departure:
    Reynolds number → laminar vs turbulent departure
    Phase transitions → thermodynamic melting of geometric order
    Dissipation rate → irreversible geometric structure loss
"""

from .viscosity import hurst_viscosity
from .momentum import (
    compute_momentum,
    compute_reynolds_analog,
    classify_flow_regime,
    compute_dissipation_rate,
)
from .thermodynamics import (
    detect_phase_transition,
    free_energy_slope,
)

__all__ = [
    "hurst_viscosity",
    "compute_momentum",
    "compute_reynolds_analog",
    "classify_flow_regime",
    "compute_dissipation_rate",
    "detect_phase_transition",
    "free_energy_slope",
]

BACKEND = "python"
