"""
Momentum, Reynolds analog, and dissipation rate
for manifold departure flow.
"""

import numpy as np


def compute_momentum(
    velocity_magnitude: float,
    effective_dim:      float,
) -> float:
    """
    Momentum analog for manifold departure.

    momentum = velocity_magnitude × effective_dim

    effective_dim acts as the "mass" of the system:
    a system moving in higher-dimensional feature space
    has more inertia — harder to stop or redirect.

    Args:
        velocity_magnitude: speed of departure (L2 norm of
                             feature vector velocity)
        effective_dim:      participation ratio from eigendecomp
                             measures dimensionality of motion

    Returns:
        float >= 0 — momentum analog
        NaN if inputs are invalid
    """
    v = float(velocity_magnitude)
    m = float(effective_dim)
    if np.isnan(v) or np.isnan(m) or v < 0 or m < 0:
        return float('nan')
    return v * m


def compute_reynolds_analog(
    momentum:  float,
    viscosity: float,
    epsilon:   float = 1e-10,
) -> float:
    """
    Reynolds number analog for manifold departure flow.

    Re = momentum / viscosity
       = (velocity × effective_dim) / Hurst_departure

    Interpretation:
        Re >> 1: turbulent departure — likely irreversible
        Re << 1: laminar departure — system may recover
        Re ≈ 1:  transitional — critical region

    Novel: no existing literature applies Reynolds number
    to manifold-geometric system monitoring.

    Args:
        momentum:   momentum analog (from compute_momentum)
        viscosity:  viscosity analog (from hurst_viscosity)
        epsilon:    floor for viscosity to avoid division by zero

    Returns:
        float >= 0 — Reynolds analog
        NaN if momentum is NaN or invalid
    """
    m = float(momentum)
    v = float(viscosity)
    if np.isnan(m) or m < 0:
        return float('nan')
    if np.isnan(v) or v < 0:
        v = epsilon
    return m / max(v, epsilon)


def classify_flow_regime(
    reynolds_analog:     float,
    laminar_threshold:   float = 1.0,
    turbulent_threshold: float = 10.0,
) -> str:
    """
    Classify departure flow regime from Reynolds analog.

    Args:
        reynolds_analog:     from compute_reynolds_analog
        laminar_threshold:   Re below this → laminar
        turbulent_threshold: Re above this → turbulent

    Returns:
        'laminar' | 'transitional' | 'turbulent' | 'unknown'

    Note: thresholds are initial estimates.
    Calibrate against known outcomes on FD001-004.
    Document calibrated values in CANONICAL_CONFIGS.md.
    """
    re = float(reynolds_analog)
    if np.isnan(re):
        return 'unknown'
    if re <= laminar_threshold:
        return 'laminar'
    if re > turbulent_threshold:
        return 'turbulent'
    return 'transitional'


def compute_dissipation_rate(
    viscosity:          float,
    velocity_gradient:  float,
) -> float:
    """
    Dissipation rate analog.

    ε = viscosity × velocity_gradient²

    Classical: ε = ν × (∂u/∂x)²  (Navier-Stokes dissipation)
    In Ørthon: ε = Hurst_departure × (ΔV/Δwindow)²

    Measures how fast the system is losing geometric structure.
    High dissipation = rapid irreversible departure.

    Args:
        viscosity:          Hurst-based viscosity analog [0, 1]
        velocity_gradient:  rate of change of velocity magnitude

    Returns:
        float >= 0 — dissipation rate analog
        NaN if viscosity is invalid
    """
    v  = float(viscosity)
    g  = float(velocity_gradient)
    if np.isnan(v) or v < 0:
        return float('nan')
    return v * g * g
