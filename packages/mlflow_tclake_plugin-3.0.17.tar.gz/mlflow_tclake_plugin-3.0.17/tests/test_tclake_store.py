# -*-coding:utf-8-*-
"""
mlflow_tclake_plugin.tclake_store 单元测试

使用 unittest.mock 隔离腾讯云 SDK，不依赖真实网络环境。
"""
import json
import pytest
from unittest.mock import MagicMock, patch

from mlflow.entities.model_registry import ModelVersionTag
from mlflow.exceptions import MlflowException
from mlflow.store.entities.paged_list import PagedList

from mlflow_tclake_plugin.tclake_store import (
    TCLakeStore,
    _get_create_time_from_audit,
    _get_last_updated_time_from_audit,
    _get_description,
    _get_tags,
    _make_model,
    _make_model_version,
    _get_model_version_name,
    _set_kv_to_properties,
    _get_kv_from_properties,
    _set_run_id_to_properties,
    _get_run_id_from_properties,
    _set_run_link_to_properties,
    _get_run_link_from_properties,
    _get_model_id_from_properties,
    _add_deployment_job_id_to_properties,
    _add_deployment_status_to_properties,
    _add_model_id_to_properties,
    _get_asset_tag,
    _parse_page_token,
    _create_page_token,
    _get_model_version,
    _set_model_version,
    _is_test_environment,
    get_tencent_cloud_headers,
    TCLAKE_MLFLOW_DEPLOYMENT_JOB_ID_KEY,
    TCLAKE_MLFLOW_DEPLOYMENT_STATUS_KEY,
)


# ────────────────────────────────────────────────
# 辅助函数测试
# ────────────────────────────────────────────────

class TestGetCreateTimeFromAudit:
    def test_returns_timestamp(self):
        audit = {"CreatedAt": "1700000000"}
        assert _get_create_time_from_audit(audit) == 1700000000

    def test_returns_none_when_audit_is_none(self):
        assert _get_create_time_from_audit(None) is None

    def test_returns_none_when_created_at_missing(self):
        assert _get_create_time_from_audit({}) is None


class TestGetLastUpdatedTimeFromAudit:
    def test_returns_last_modified_at(self):
        audit = {"CreatedAt": "100", "LastModifiedAt": "200"}
        assert _get_last_updated_time_from_audit(audit) == 200

    def test_falls_back_to_created_at_when_last_modified_is_none(self):
        audit = {"CreatedAt": "100", "LastModifiedAt": None}
        assert _get_last_updated_time_from_audit(audit) == 100

    def test_returns_none_when_audit_is_none(self):
        assert _get_last_updated_time_from_audit(None) is None

    def test_returns_none_when_fields_missing(self):
        assert _get_last_updated_time_from_audit({}) is None


class TestGetDescription:
    def test_returns_comment(self):
        assert _get_description({"Comment": "desc"}) == "desc"

    def test_returns_none_when_resp_is_none(self):
        assert _get_description(None) is None

    def test_returns_none_when_comment_missing(self):
        assert _get_description({}) is None


class TestGetTags:
    def test_parses_tag_list(self):
        raw = [
            {"LabelName": "env", "LabelValue": "prod"},
            {"LabelName": "team", "LabelValue": "ml"},
        ]
        tags = _get_tags(raw)
        assert len(tags) == 2
        assert tags[0].key == "env" and tags[0].value == "prod"
        assert tags[1].key == "team" and tags[1].value == "ml"

    def test_returns_empty_for_empty_list(self):
        assert _get_tags([]) == []


class TestMakeModel:
    def _resp(self, name="mymodel", created="100", modified="200", comment="desc", guid="g1"):
        return {
            "Name": name,
            "Audit": {"CreatedAt": created, "LastModifiedAt": modified},
            "Comment": comment,
            "AssetGuid": guid,
        }

    def test_fields_are_correct(self):
        model = _make_model(self._resp(), [])
        assert model.name == "mymodel"
        assert model.creation_timestamp == 100
        assert model.last_updated_timestamp == 200
        assert model.description == "desc"
        # MLflow 3.x 中 RegisteredModel.tags 为 dict {key: RegisteredModelTag}
        assert len(model.tags) == 0

    def test_tags_are_set(self):
        tags_raw = [{"LabelName": "k", "LabelValue": "v"}]
        model = _make_model(self._resp(), tags_raw)
        assert len(model.tags) == 1
        # tags 是 dict，通过 key 访问
        assert "k" in model.tags


class TestMakeModelVersion:
    def _entity(self, version=1, uri="s3://bucket/model", run_id="run1",
                run_link="http://link", model_id="mid1", aliases=None):
        props = []
        _set_run_id_to_properties(run_id, props)
        _set_run_link_to_properties(run_link, props)
        _add_model_id_to_properties(model_id, props)
        return {
            "Version": version,
            "Uri": uri,
            "Comment": "v desc",
            "Audit": {"CreatedAt": "300", "LastModifiedAt": "400"},
            "Properties": props,
            "Aliases": aliases or [],
            "Tags": [],
            "AssetGuid": "ag1",
        }

    def test_fields_are_correct(self):
        mv = _make_model_version(self._entity(), "cat.sch.model")
        assert mv.name == "cat.sch.model"
        assert mv.version == "1"
        assert mv.source == "s3://bucket/model"
        assert mv.run_id == "run1"
        assert mv.run_link == "http://link"
        assert mv.model_id == "mid1"
        assert mv.status == "READY"

    def test_aliases_are_set(self):
        mv = _make_model_version(self._entity(aliases=["champion"]), "m")
        assert "champion" in mv.aliases


class TestGetModelVersionName:
    def test_joins_three_part_name(self):
        entity = {"CatalogName": "cat", "SchemaName": "sch", "ModelName": "mod"}
        assert _get_model_version_name(entity) == "cat.sch.mod"


class TestKVProperties:
    def test_set_and_get(self):
        props = []
        _set_kv_to_properties("key1", "val1", props)
        assert _get_kv_from_properties(props, "key1") == "val1"

    def test_none_value_not_added(self):
        props = []
        _set_kv_to_properties("key1", None, props)
        assert len(props) == 0

    def test_missing_key_returns_none(self):
        assert _get_kv_from_properties([], "missing") is None

    def test_none_props_returns_none(self):
        assert _get_kv_from_properties(None, "k") is None


class TestRunIdProperties:
    def test_set_get_run_id(self):
        props = []
        _set_run_id_to_properties("run-abc", props)
        assert _get_run_id_from_properties(props) == "run-abc"

    def test_set_get_run_link(self):
        props = []
        _set_run_link_to_properties("http://mlflow/run/1", props)
        assert _get_run_link_from_properties(props) == "http://mlflow/run/1"

    def test_set_get_model_id(self):
        props = []
        _add_model_id_to_properties("model-xyz", props)
        assert _get_model_id_from_properties(props) == "model-xyz"


class TestDeploymentProperties:
    def test_deployment_job_id(self):
        props = []
        _add_deployment_job_id_to_properties("job-1", props)
        assert _get_kv_from_properties(props, TCLAKE_MLFLOW_DEPLOYMENT_JOB_ID_KEY) == "job-1"

    def test_deployment_status(self):
        props = []
        _add_deployment_status_to_properties("Deployed", props)
        assert _get_kv_from_properties(props, TCLAKE_MLFLOW_DEPLOYMENT_STATUS_KEY) == "Deployed"

    def test_none_status_not_added(self):
        props = []
        _add_deployment_status_to_properties(None, props)
        assert len(props) == 0


class TestModelVersionConversion:
    def test_get_model_version_returns_string(self):
        assert _get_model_version(3) == "3"

    def test_set_model_version_returns_int(self):
        assert _set_model_version("5") == 5


class TestPageToken:
    def test_create_and_parse(self):
        token = _create_page_token(10, "search_id_abc")
        parsed = _parse_page_token(token)
        assert parsed["offset"] == 10
        assert parsed["search_id"] == "search_id_abc"


class TestGetAssetTag:
    def test_empty_list_creates_new_tag(self):
        tag = ModelVersionTag("env", "prod")
        result = _get_asset_tag([], tag)
        assert len(result) == 1
        assert result[0]["LabelName"] == "env"
        assert result[0]["LabelValue"] == "prod"
        assert result[0]["CreateCustomLabel"] is True

    def test_same_key_value_returns_none(self):
        existing = [{"LabelName": "env", "LabelValue": "prod",
                     "LabelId": "1", "LabelValueId": "2"}]
        tag = ModelVersionTag("env", "prod")
        assert _get_asset_tag(existing, tag) is None

    def test_same_key_different_value_updates(self):
        existing = [{"LabelName": "env", "LabelValue": "test",
                     "LabelId": "1", "LabelValueId": "2"}]
        tag = ModelVersionTag("env", "prod")
        result = _get_asset_tag(existing, tag)
        assert result is not None
        env_tag = next(t for t in result if t["LabelName"] == "env")
        assert env_tag["LabelValue"] == "prod"

    def test_new_key_appended_to_existing(self):
        existing = [{"LabelName": "env", "LabelValue": "prod",
                     "LabelId": "1", "LabelValueId": "2"}]
        tag = ModelVersionTag("team", "ml")
        result = _get_asset_tag(existing, tag)
        assert len(result) == 2
        names = [t["LabelName"] for t in result]
        assert "env" in names and "team" in names


class TestIsTestEnvironment:
    def test_returns_false_when_not_set(self, monkeypatch):
        monkeypatch.delenv("IS_WEDATA_TEST", raising=False)
        assert _is_test_environment() is False

    def test_returns_true_for_true_string(self, monkeypatch):
        monkeypatch.setenv("IS_WEDATA_TEST", "true")
        assert _is_test_environment() is True

    def test_returns_true_for_one_string(self, monkeypatch):
        monkeypatch.setenv("IS_WEDATA_TEST", "1")
        assert _is_test_environment() is True


class TestGetTencentCloudHeaders:
    def test_returns_empty_in_non_test_env(self, monkeypatch):
        monkeypatch.delenv("IS_WEDATA_TEST", raising=False)
        assert get_tencent_cloud_headers() == {}

    def test_raises_when_test_user_id_missing(self, monkeypatch):
        monkeypatch.setenv("IS_WEDATA_TEST", "1")
        monkeypatch.delenv("TEST_USER_ID", raising=False)
        with pytest.raises(MlflowException, match="TEST_USER_ID"):
            get_tencent_cloud_headers()

    def test_returns_user_id_header_in_test_env(self, monkeypatch):
        monkeypatch.setenv("IS_WEDATA_TEST", "1")
        monkeypatch.setenv("TEST_USER_ID", "uid123")
        headers = get_tencent_cloud_headers()
        assert headers.get("X-Qcloud-User-Id") == "uid123"


# ────────────────────────────────────────────────
# TCLakeStore 单元测试
# ────────────────────────────────────────────────

def _make_store_env(monkeypatch):
    """设置 TCLakeStore 初始化所需的最小环境变量"""
    monkeypatch.setenv("KERNEL_WEDATA_CLOUD_SDK_SECRET_ID", "test_sid")
    monkeypatch.setenv("KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY", "test_sk")
    monkeypatch.setenv("WEDATA_WORKSPACE_ID", "ws-001")
    monkeypatch.delenv("IS_WEDATA_TEST", raising=False)


def _build_store(monkeypatch):
    """构建带 mock SDK 客户端的 TCLakeStore"""
    _make_store_env(monkeypatch)
    with patch("mlflow_tclake_plugin.tclake_store.WedataClient"), \
         patch("mlflow_tclake_plugin.tclake_store.TcCatalogClient"), \
         patch("mlflow_tclake_plugin.tclake_store.credential.Credential"):
        store = TCLakeStore.__new__(TCLakeStore)
        store.workspace_id = "ws-001"
        store.sub_account_uin = ""
        store.owner_uin = ""
        store.default_catalog_name = "default"
        store.default_schema_name = "default"
        store.headers = {}
        from cachetools import TTLCache
        store.cache = TTLCache(maxsize=100, ttl=300)
        store.client = MagicMock()
        store.tccatalog_client = MagicMock()
        return store


def _model_resp(name="mymodel", guid="g1"):
    return {
        "Name": name,
        "Audit": {"CreatedAt": "1000", "LastModifiedAt": "2000"},
        "Comment": "test model",
        "AssetGuid": guid,
    }


def _version_entity(version=1, uri="s3://bucket/v1", aliases=None):
    props = []
    _set_run_id_to_properties("run-1", props)
    _set_run_link_to_properties("http://link", props)
    _add_model_id_to_properties("mid-1", props)
    return {
        "Version": version,
        "Uri": uri,
        "Comment": "",
        "Audit": {"CreatedAt": "1000", "LastModifiedAt": "2000"},
        "Properties": props,
        "Aliases": aliases or [],
        "Tags": [],
        "AssetGuid": "vg1",
        "CatalogName": "default",
        "SchemaName": "default",
        "ModelName": "mymodel",
    }


class TestTCLakeStoreSplitModelName:
    def test_single_segment_uses_default_catalog_and_schema(self, monkeypatch):
        store = _build_store(monkeypatch)
        assert store._split_model_name("mymodel") == ["default", "default", "mymodel"]

    def test_two_segments_uses_default_catalog(self, monkeypatch):
        store = _build_store(monkeypatch)
        assert store._split_model_name("sch.model") == ["default", "sch", "model"]

    def test_three_segments_returned_as_is(self, monkeypatch):
        store = _build_store(monkeypatch)
        assert store._split_model_name("cat.sch.model") == ["cat", "sch", "model"]

    def test_four_segments_raises(self, monkeypatch):
        store = _build_store(monkeypatch)
        with pytest.raises(MlflowException):
            store._split_model_name("a.b.c.d")


class TestTCLakeStoreCreateRegisteredModel:
    def test_create_without_tags(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"Model": _model_resp()})
        result = store.create_registered_model("mymodel")
        assert result.name == "mymodel"
        store._call.assert_called_once()
        assert store._call.call_args[0][0] == "CreateModel"

    def test_create_with_tags(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"Model": _model_resp()})
        store._batch_vote_asset_tag = MagicMock()
        result = store.create_registered_model("mymodel", tags=[ModelVersionTag("env", "prod")])
        store._batch_vote_asset_tag.assert_called_once()
        assert result.name == "mymodel"

    def test_raises_when_model_already_exists(self, monkeypatch):
        from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
        store = _build_store(monkeypatch)
        exc = TencentCloudSDKException(
            code="FailedOperation.MetalakeAlreadyExistsError",
            message="already exists"
        )
        store._call = MagicMock(side_effect=exc)
        with pytest.raises(MlflowException) as exc_info:
            store.create_registered_model("mymodel")
        # MLflow 3.x error_code 返回字符串名称
        assert exc_info.value.error_code == "RESOURCE_ALREADY_EXISTS"


class TestTCLakeStoreGetRegisteredModel:
    def test_get_model_calls_get_model_api(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"Model": _model_resp()})
        store._list_tag_by_asset = MagicMock(return_value=[])
        result = store.get_registered_model("mymodel")
        assert result.name == "mymodel"
        assert store._call.call_args[0][0] == "GetModel"


class TestTCLakeStoreUpdateRegisteredModel:
    def test_update_description(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"Model": _model_resp()})
        store._list_tag_by_asset = MagicMock(return_value=[])
        store.update_registered_model("mymodel", "new desc")
        assert store._call.call_args[0][0] == "UpdateModelComment"
        assert store._call.call_args[0][1]["NewComment"] == "new desc"


class TestTCLakeStoreRenameRegisteredModel:
    def test_rename_calls_update_model_name_api(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"Model": _model_resp(name="newmodel")})
        store._list_tag_by_asset = MagicMock(return_value=[])
        result = store.rename_registered_model("mymodel", "newmodel")
        assert result.name == "newmodel"
        assert store._call.call_args[0][0] == "UpdateModelName"
        assert store._call.call_args[0][1]["NewName"] == "newmodel"


class TestTCLakeStoreDeleteRegisteredModel:
    def test_delete_succeeds(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"Result": True})
        store.delete_registered_model("mymodel")
        store._call.assert_called_once()

    def test_raises_when_delete_fails(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"Result": False})
        with pytest.raises(MlflowException):
            store.delete_registered_model("mymodel")


class TestTCLakeStoreSearchRegisteredModels:
    def test_first_search_builds_page(self, monkeypatch):
        store = _build_store(monkeypatch)
        models = [_make_model(_model_resp(name=f"m{i}"), []) for i in range(5)]
        store._fetch_all_models = MagicMock(return_value=models)
        result = store.search_registered_models(
            filter_string=None, max_results=10, order_by=None, page_token=None
        )
        assert isinstance(result, PagedList)
        assert len(result) == 5

    def test_raises_for_non_positive_max_results(self, monkeypatch):
        store = _build_store(monkeypatch)
        with pytest.raises(MlflowException):
            store.search_registered_models(max_results=0)

    def test_empty_result_returns_empty_paged_list(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._fetch_all_models = MagicMock(return_value=[])
        result = store.search_registered_models(
            filter_string=None, max_results=10, order_by=None, page_token=None
        )
        assert len(result) == 0
        assert result.token is None


class TestTCLakeStoreCreateModelVersion:
    def test_raises_when_model_id_is_none(self, monkeypatch):
        store = _build_store(monkeypatch)
        with pytest.raises(MlflowException, match="model_id"):
            store.create_model_version("mymodel", "s3://bucket/v1", model_id=None)

    def test_create_succeeds(self, monkeypatch):
        store = _build_store(monkeypatch)
        entity = _version_entity()
        store._call = MagicMock(return_value={})
        store._get_latest_model_version = MagicMock(return_value=entity)

        with patch("mlflow_tclake_plugin.tclake_store._add_model_signature_to_properties") as mock_sig, \
             patch("mlflow_tclake_plugin.tclake_store._add_model_artifact_path_to_properties") as mock_path:
            mock_sig.side_effect = lambda src, props: props
            mock_path.side_effect = lambda src, props: props
            result = store.create_model_version(
                "mymodel", "s3://bucket/v1", run_id="run-1", model_id="mid-1"
            )
        assert result.version == "1"
        assert result.source == "s3://bucket/v1"


class TestTCLakeStoreGetModelVersion:
    def test_get_version_returns_correct_version(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"ModelVersion": _version_entity()})
        store._list_tag_by_asset = MagicMock(return_value=[])
        result = store.get_model_version("mymodel", "1")
        assert result.version == "1"


class TestTCLakeStoreUpdateModelVersion:
    def test_update_description(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"ModelVersion": _version_entity()})
        store._list_tag_by_asset = MagicMock(return_value=[])
        store.update_model_version("mymodel", "1", "new version desc")
        assert store._call.call_args[0][0] == "UpdateModelVersionComment"
        assert store._call.call_args[0][1]["NewComment"] == "new version desc"


class TestTCLakeStoreDeleteModelVersion:
    def test_delete_succeeds(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"Result": True})
        store.delete_model_version("mymodel", "1")
        store._call.assert_called_once()

    def test_raises_when_delete_fails(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._call = MagicMock(return_value={"Result": False})
        with pytest.raises(Exception):
            store.delete_model_version("mymodel", "1")


class TestTCLakeStoreSearchModelVersions:
    def test_first_search_returns_paged_list(self, monkeypatch):
        store = _build_store(monkeypatch)
        entity = _version_entity()
        mv = _make_model_version(entity, "default.default.mymodel")
        store._fetch_all_model_versions = MagicMock(return_value=[mv])
        result = store.search_model_versions(
            filter_string=None, max_results=10, order_by=None, page_token=None
        )
        assert isinstance(result, PagedList)
        assert len(result) == 1

    def test_raises_when_max_results_exceeds_threshold(self, monkeypatch):
        from mlflow.store.model_registry import SEARCH_MODEL_VERSION_MAX_RESULTS_THRESHOLD
        store = _build_store(monkeypatch)
        with pytest.raises(MlflowException):
            store.search_model_versions(max_results=SEARCH_MODEL_VERSION_MAX_RESULTS_THRESHOLD + 1)


class TestTCLakeStoreTagOperations:
    def test_set_registered_model_tag(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_registered_model = MagicMock(return_value={"AssetGuid": "g1"})
        store._list_tag_by_asset = MagicMock(return_value=[])
        store._batch_vote_asset_tag = MagicMock()
        store.set_registered_model_tag("mymodel", ModelVersionTag("env", "prod"))
        store._batch_vote_asset_tag.assert_called_once()

    def test_delete_registered_model_tag_noop_when_key_not_found(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_registered_model = MagicMock(return_value={"AssetGuid": "g1"})
        store._list_tag_by_asset = MagicMock(return_value=[])
        store._batch_vote_asset_tag = MagicMock()
        store.delete_registered_model_tag("mymodel", "notexist")
        store._batch_vote_asset_tag.assert_not_called()

    def test_delete_registered_model_tag_calls_batch_when_key_exists(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_registered_model = MagicMock(return_value={"AssetGuid": "g1"})
        store._list_tag_by_asset = MagicMock(return_value=[
            {"LabelName": "env", "LabelValue": "prod", "LabelId": "1", "LabelValueId": "2"}
        ])
        store._batch_vote_asset_tag = MagicMock()
        store.delete_registered_model_tag("mymodel", "env")
        store._batch_vote_asset_tag.assert_called_once()

    def test_set_model_version_tag(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_model_version = MagicMock(return_value=_version_entity())
        store._list_tag_by_asset = MagicMock(return_value=[])
        store._batch_vote_asset_tag = MagicMock()
        store.set_model_version_tag("mymodel", "1", ModelVersionTag("env", "prod"))
        store._batch_vote_asset_tag.assert_called_once()

    def test_delete_model_version_tag(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_model_version = MagicMock(return_value=_version_entity())
        store._list_tag_by_asset = MagicMock(return_value=[
            {"LabelName": "env", "LabelValue": "prod", "LabelId": "1", "LabelValueId": "2"}
        ])
        store._batch_vote_asset_tag = MagicMock()
        store.delete_model_version_tag("mymodel", "1", "env")
        store._batch_vote_asset_tag.assert_called_once()


class TestTCLakeStoreAliasOperations:
    def test_set_alias_raises_when_alias_already_exists(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_model_version_by_alias = MagicMock(return_value=_version_entity(aliases=["champion"]))
        with pytest.raises(MlflowException, match="champion"):
            store.set_registered_model_alias("mymodel", "champion", "1")

    def test_set_alias_succeeds(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_model_version_by_alias = MagicMock(return_value=None)
        store._call = MagicMock(return_value={})
        store.set_registered_model_alias("mymodel", "champion", "1")
        assert store._call.call_args[0][0] == "UpdateModelVersionAliases"
        assert "champion" in store._call.call_args[0][1]["AddedAliases"]

    def test_delete_alias_raises_when_alias_not_found(self, monkeypatch):
        store = _build_store(monkeypatch)
        store.get_model_version_by_alias = MagicMock(return_value=None)
        with pytest.raises(MlflowException):
            store.delete_registered_model_alias("mymodel", "champion")

    def test_delete_alias_succeeds(self, monkeypatch):
        store = _build_store(monkeypatch)
        mv = _make_model_version(_version_entity(), "mymodel")
        store.get_model_version_by_alias = MagicMock(return_value=mv)
        store._call = MagicMock(return_value={})
        store.delete_registered_model_alias("mymodel", "champion")
        assert store._call.call_args[0][0] == "UpdateModelVersionAliases"
        assert "champion" in store._call.call_args[0][1]["RemovedAliases"]

    def test_get_model_version_by_alias_raises_when_not_found(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_model_version_by_alias = MagicMock(return_value=None)
        with pytest.raises(MlflowException):
            store.get_model_version_by_alias("mymodel", "champion")

    def test_get_model_version_by_alias_returns_version(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_model_version_by_alias = MagicMock(return_value=_version_entity(aliases=["champion"]))
        store._list_tag_by_asset = MagicMock(return_value=[])
        result = store.get_model_version_by_alias("mymodel", "champion")
        assert result.version == "1"


class TestTCLakeStoreGetModelVersionDownloadUri:
    def test_returns_source_field(self, monkeypatch):
        store = _build_store(monkeypatch)
        store._get_model_version = MagicMock(return_value=_version_entity(uri="s3://bucket/model_v1"))
        store._list_tag_by_asset = MagicMock(return_value=[])
        uri = store.get_model_version_download_uri("mymodel", "1")
        assert uri == "s3://bucket/model_v1"


class TestTCLakeStoreTransitionModelVersionStage:
    def test_raises_not_implemented(self, monkeypatch):
        store = _build_store(monkeypatch)
        with pytest.raises(NotImplementedError):
            store.transition_model_version_stage("mymodel", "1", "Production", False)


class TestTCLakeStorePagination:
    def test_pagination_splits_correctly(self, monkeypatch):
        store = _build_store(monkeypatch)
        models = [_make_model(_model_resp(name=f"m{i}"), []) for i in range(10)]
        store._fetch_all_models = MagicMock(return_value=models)

        page1 = store.search_registered_models(
            filter_string=None, max_results=4, order_by=None, page_token=None
        )
        assert len(page1) == 4
        assert page1.token is not None

        page2 = store.search_registered_models(
            filter_string=None, max_results=4, order_by=None, page_token=page1.token
        )
        assert len(page2) == 4
        assert page2.token is not None

        page3 = store.search_registered_models(
            filter_string=None, max_results=4, order_by=None, page_token=page2.token
        )
        assert len(page3) == 2
        assert page3.token is None

    def test_invalid_page_token_raises(self, monkeypatch):
        store = _build_store(monkeypatch)
        import base64
        bad_token = base64.b64encode(
            json.dumps({"offset": 0, "search_id": "nonexistent"}).encode()
        ).decode()
        with pytest.raises(MlflowException, match="Invalid page token"):
            store.search_registered_models(
                filter_string=None, max_results=10, order_by=None, page_token=bad_token
            )
