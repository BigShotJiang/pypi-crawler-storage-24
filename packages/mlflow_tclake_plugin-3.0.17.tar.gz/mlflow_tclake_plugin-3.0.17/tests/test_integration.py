# -*-coding:utf-8-*-
"""
mlflow-tclake-plugin 集成测试

前置条件（通过环境变量配置，缺失则自动跳过）：
  TENCENTCLOUD_ENDPOINT              - wedata API 端点（如 wedata.tencentcloudapi.com）
  TENCENTCLOUD_TCCATALOG_ENDPOINT    - tccatalog API 端点（如 tccatalog.tencentcloudapi.com）
  KERNEL_WEDATA_CLOUD_SDK_SECRET_ID  - 腾讯云 SecretId
  KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY - 腾讯云 SecretKey
  WEDATA_WORKSPACE_ID                - WeData 工作空间 ID
  MLFLOW_TRACKING_URI                - MLflow Tracking 服务地址
  WEDATA_MODEL_NAME_PREFIX           - 测试使用的模型名称前缀（如 catalog.schema.）
  IS_WEDATA_TEST                     - 设为 "1" 使用测试header
  TEST_USER_ID                       - IS_WEDATA_TEST=1 时必须提供

运行方式：
  export TENCENTCLOUD_ENDPOINT=xxx
  export TENCENTCLOUD_TCCATALOG_ENDPOINT=xxx
  export KERNEL_WEDATA_CLOUD_SDK_SECRET_ID=xxx
  export KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY=xxx
  export WEDATA_WORKSPACE_ID=xxx
  export MLFLOW_TRACKING_URI=http://127.0.0.1:5000
  export WEDATA_MODEL_NAME_PREFIX=catalog.schema.
  export IS_WEDATA_TEST=1
  export TEST_USER_ID=xxx
  pytest tests/test_integration.py -v
"""
import os
import random
import string
import uuid

import pytest
import mlflow
from mlflow import MlflowClient
from mlflow.exceptions import MlflowException
from dotenv import load_dotenv

# ────────────────────────────────────────────────
# 跳过条件：缺少必要环境变量时跳过所有集成测试
# ────────────────────────────────────────────────

_REQUIRED_ENVS = [
    "TENCENTCLOUD_ENDPOINT",
    "TENCENTCLOUD_TCCATALOG_ENDPOINT",
    "KERNEL_WEDATA_CLOUD_SDK_SECRET_ID",
    "KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY",
    "WEDATA_WORKSPACE_ID",
    "MLFLOW_TRACKING_URI",
    "WEDATA_MODEL_NAME_PREFIX",
]

# 加载 .env（不覆盖已有环境变量）
load_dotenv(
    dotenv_path=os.path.join(os.path.dirname(__file__), "../.env"),
    override=False,
)

_missing = [e for e in _REQUIRED_ENVS if not os.getenv(e)]
pytestmark = pytest.mark.skipif(
    bool(_missing),
    reason=f"集成测试所需环境变量未设置: {_missing}",
)

_REGISTRY_URI = "tclake:" + os.getenv("TCLAKE_REGION", "ap-guangzhou")
_TRACKING_URI = os.getenv("MLFLOW_TRACKING_URI", "http://127.0.0.1:5000")

_MODEL_NAME_PREFIX = os.getenv("WEDATA_MODEL_NAME_PREFIX", "")


def _random_model_name() -> str:
    """生成随机5位小写字母后缀，拼接到 prefix 后作为完整模型名"""
    suffix = "".join(random.choices(string.ascii_lowercase, k=5))
    return _MODEL_NAME_PREFIX + suffix


@pytest.fixture(scope="module", autouse=True)
def setup_mlflow():
    """为所有集成测试配置 MLflow 客户端"""
    mlflow.set_registry_uri(_REGISTRY_URI)
    mlflow.set_tracking_uri(_TRACKING_URI)
    yield


@pytest.fixture(scope="module")
def client():
    return MlflowClient()


# ────────────────────────────────────────────────
# Registered Model CRUD
# ────────────────────────────────────────────────

class TestRegisteredModelCRUD:
    def test_create_and_get_registered_model(self, client):
        name = _random_model_name()
        try:
            model = client.create_registered_model(name, description="integration test model")
            assert model.description == "integration test model"

            fetched = client.get_registered_model(name)
        finally:
            try:
                client.delete_registered_model(name)
                pass
            except Exception:
                pass

    def test_create_model_already_exists_raises(self, client):
        name = _random_model_name()
        try:
            client.create_registered_model(name)
            with pytest.raises(MlflowException):
                client.create_registered_model(name)
        finally:
            try:
                client.delete_registered_model(name)
            except Exception:
                pass

    def test_update_registered_model_description(self, client):
        name = _random_model_name()
        try:
            client.create_registered_model(name, description="original")
            client.update_registered_model(name, description="updated")
            fetched = client.get_registered_model(name)
            assert fetched.description == "updated"
        finally:
            try:
                client.delete_registered_model(name)
            except Exception:
                pass

    def test_rename_registered_model(self, client):
        old_name = _random_model_name()
        new_name = _random_model_name()
        try:
            client.create_registered_model(old_name)
            client.rename_registered_model(old_name, new_name.split(".")[2])
            client.get_registered_model(new_name)
            with pytest.raises(MlflowException):
                client.get_registered_model(old_name)
        finally:
            for n in [old_name, new_name]:
                try:
                    client.delete_registered_model(n)
                except Exception:
                    pass

    def test_delete_registered_model(self, client):
        name = _random_model_name()
        client.create_registered_model(name)
        client.delete_registered_model(name)
        with pytest.raises(MlflowException):
            client.get_registered_model(name)

    def test_search_registered_models_returns_created_model(self, client):
        name = _random_model_name()
        try:
            client.create_registered_model(name)
            results = client.search_registered_models()
            names = [m.name for m in results]
            assert name.split(".")[2] in names
        finally:
            try:
                client.delete_registered_model(name)
            except Exception:
                pass


# ────────────────────────────────────────────────
# Registered Model Tags
# ────────────────────────────────────────────────

class TestRegisteredModelTags:
    def test_set_and_get_tag(self, client):
        name = _random_model_name()
        try:
            client.create_registered_model(name)
            client.set_registered_model_tag(name, "env", "test")
            model = client.get_registered_model(name)
            assert "env" in model.tags
            assert model.tags["env"] == "test"
        finally:
            try:
                client.delete_registered_model(name)
            except Exception:
                pass

    def test_delete_tag(self, client):
        name = _random_model_name()
        try:
            client.create_registered_model(name)
            client.set_registered_model_tag(name, "env", "test")
            client.delete_registered_model_tag(name, "env")
            model = client.get_registered_model(name)
            assert "env" not in model.tags
        finally:
            try:
                client.delete_registered_model(name)
            except Exception:
                pass


# ────────────────────────────────────────────────
# Model Version CRUD
# ────────────────────────────────────────────────

class TestModelVersionCRUD:
    """
    模型版本集成测试依赖通过 MLflow Tracking 记录的 artifact，
    需要 MLFLOW_TRACKING_URI 指向可用的 Tracking 服务。
    """

    @pytest.fixture
    def registered_model_name(self, client):
        """使用 WEDATA_MODEL_NAME_PREFIX 加随机后缀生成模型名，测试结束后清理"""
        name = _random_model_name()
        client.create_registered_model(name)
        yield name
        # 清理：删除所有版本后删除模型
        try:
            versions = client.search_model_versions(f"name='{name}'")
            for v in versions:
                try:
                    client.delete_model_version(name, v.version)
                except Exception:
                    pass
            client.delete_registered_model(name)
        except Exception:
            pass

    @pytest.fixture
    def logged_model_uri(self):
        """
        在 MLflow Tracking 中记录一个简单的 sklearn 模型，返回其 artifact URI。
        依赖 sklearn，缺少时跳过。
        """
        pytest.importorskip("sklearn", reason="sklearn not installed")
        from sklearn.linear_model import LogisticRegression
        from sklearn.datasets import load_iris
        import mlflow.sklearn

        X, y = load_iris(return_X_y=True)
        model = LogisticRegression(max_iter=200)
        model.fit(X, y)

        from mlflow.models.signature import infer_signature
        signature = infer_signature(X, model.predict(X))

        mlflow.set_experiment("integration_test_experiment")
        with mlflow.start_run() as run:
            mlflow.sklearn.log_model(model, name="model", signature=signature)
            run_id = run.info.run_id

        artifact_uri = f"runs:/{run_id}/model"
        return artifact_uri, run_id

    def test_create_and_get_model_version(self, client, registered_model_name, logged_model_uri):
        source, run_id = logged_model_uri

        mv = client.create_model_version(
            name=registered_model_name,
            source=source,
            run_id=run_id,
            description="integration test version",
        )
        assert mv.name == registered_model_name
        assert mv.version is not None

        fetched = client.get_model_version(registered_model_name, mv.version)
        assert fetched.version == mv.version
        assert fetched.source == source

    def test_update_model_version_description(self, client, registered_model_name, logged_model_uri):
        source, run_id = logged_model_uri
        mv = client.create_model_version(
            name=registered_model_name,
            source=source,
            run_id=run_id,
        )
        client.update_model_version(registered_model_name, mv.version, description="updated desc")
        fetched = client.get_model_version(registered_model_name, mv.version)
        assert fetched.description == "updated desc"

    def test_delete_model_version(self, client, registered_model_name, logged_model_uri):
        source, run_id = logged_model_uri
        mv = client.create_model_version(
            name=registered_model_name,
            source=source,
            run_id=run_id,
        )
        client.delete_model_version(registered_model_name, mv.version)
        with pytest.raises(MlflowException):
            client.get_model_version(registered_model_name, mv.version)

    def test_get_model_version_download_uri(self, client, registered_model_name, logged_model_uri):
        source, run_id = logged_model_uri
        mv = client.create_model_version(
            name=registered_model_name,
            source=source,
            run_id=run_id,
        )
        uri = client.get_model_version_download_uri(registered_model_name, mv.version)
        assert uri is not None
        assert len(uri) > 0


# ────────────────────────────────────────────────
# Model Version Tags
# ────────────────────────────────────────────────

class TestModelVersionTags:
    @pytest.fixture
    def model_and_version(self, client):
        """使用 WEDATA_MODEL_NAME 创建模型版本，测试结束后清理"""
        pytest.importorskip("sklearn", reason="sklearn not installed")
        from sklearn.linear_model import LogisticRegression
        from sklearn.datasets import load_iris
        import mlflow.sklearn

        name = _random_model_name()
        client.create_registered_model(name)

        X, y = load_iris(return_X_y=True)
        model = LogisticRegression(max_iter=200)
        model.fit(X, y)

        from mlflow.models.signature import infer_signature
        signature = infer_signature(X, model.predict(X))

        mlflow.set_experiment("integration_test_experiment")
        with mlflow.start_run() as run:
            mlflow.sklearn.log_model(model, name="model", signature=signature)
            run_id = run.info.run_id

        source = f"runs:/{run_id}/model"
        mv = client.create_model_version(name=name, source=source, run_id=run_id)
        yield name, mv.version

        try:
            client.delete_model_version(name, mv.version)
            client.delete_registered_model(name)
        except Exception:
            pass

    def test_set_and_get_version_tag(self, client, model_and_version):
        name, version = model_and_version
        client.set_model_version_tag(name, version, "stage", "staging")
        mv = client.get_model_version(name, version)
        assert "stage" in mv.tags
        assert mv.tags["stage"] == "staging"

    def test_delete_version_tag(self, client, model_and_version):
        name, version = model_and_version
        client.set_model_version_tag(name, version, "stage", "staging")
        client.delete_model_version_tag(name, version, "stage")
        mv = client.get_model_version(name, version)
        assert "stage" not in mv.tags


# ────────────────────────────────────────────────
# Model Version Aliases
# ────────────────────────────────────────────────

class TestModelVersionAliases:
    @pytest.fixture
    def model_and_version(self, client):
        """使用 WEDATA_MODEL_NAME 创建模型版本，测试结束后清理"""
        pytest.importorskip("sklearn", reason="sklearn not installed")
        from sklearn.linear_model import LogisticRegression
        from sklearn.datasets import load_iris
        import mlflow.sklearn

        name = _random_model_name()
        client.create_registered_model(name)

        X, y = load_iris(return_X_y=True)
        model = LogisticRegression(max_iter=200)
        model.fit(X, y)

        from mlflow.models.signature import infer_signature
        signature = infer_signature(X, model.predict(X))

        mlflow.set_experiment("integration_test_experiment")
        with mlflow.start_run() as run:
            mlflow.sklearn.log_model(model, name="model", signature=signature)
            run_id = run.info.run_id

        source = f"runs:/{run_id}/model"
        mv = client.create_model_version(name=name, source=source, run_id=run_id)
        yield name, mv.version

        try:
            client.delete_model_version(name, mv.version)
            client.delete_registered_model(name)
        except Exception:
            pass

    def test_set_and_get_alias(self, client, model_and_version):
        name, version = model_and_version
        alias = f"champion_{uuid.uuid4().hex[:6]}"
        client.set_registered_model_alias(name, alias, version)
        mv = client.get_model_version_by_alias(name, alias)
        assert mv.version == version

    def test_set_duplicate_alias_raises(self, client, model_and_version):
        name, version = model_and_version
        alias = f"champion_{uuid.uuid4().hex[:6]}"
        client.set_registered_model_alias(name, alias, version)
        with pytest.raises(MlflowException):
            client.set_registered_model_alias(name, alias, version)
        # 清理
        client.delete_registered_model_alias(name, alias)

    def test_delete_alias(self, client, model_and_version):
        name, version = model_and_version
        alias = f"champion_{uuid.uuid4().hex[:6]}"
        client.set_registered_model_alias(name, alias, version)
        client.delete_registered_model_alias(name, alias)
        with pytest.raises(MlflowException):
            client.get_model_version_by_alias(name, alias)

    def test_get_alias_not_found_raises(self, client, model_and_version):
        name, _ = model_and_version
        with pytest.raises(MlflowException):
            client.get_model_version_by_alias(name, "nonexistent_alias")