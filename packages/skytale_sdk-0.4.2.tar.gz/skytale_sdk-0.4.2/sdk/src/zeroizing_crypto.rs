use mls_rs::{CipherSuite, CryptoProvider};
use mls_rs_crypto_rustcrypto::RustCryptoProvider;

/// Defense-in-depth wrapper around `RustCryptoProvider`.
///
/// Delegates all `CryptoProvider` trait methods to the inner
/// `RustCryptoProvider`. This indirection layer exists so that future
/// zeroization hooks (e.g., wrapping cipher suite providers to zeroize
/// intermediate key material) can be added without changing call sites.
#[derive(Debug, Clone, Default)]
pub struct ZeroizingCryptoProvider(RustCryptoProvider);

impl CryptoProvider for ZeroizingCryptoProvider {
    type CipherSuiteProvider = <RustCryptoProvider as CryptoProvider>::CipherSuiteProvider;

    fn supported_cipher_suites(&self) -> Vec<CipherSuite> {
        self.0.supported_cipher_suites()
    }

    fn cipher_suite_provider(
        &self,
        cipher_suite: CipherSuite,
    ) -> Option<Self::CipherSuiteProvider> {
        self.0.cipher_suite_provider(cipher_suite)
    }
}
