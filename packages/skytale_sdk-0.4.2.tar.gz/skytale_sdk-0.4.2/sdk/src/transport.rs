use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};

use async_trait::async_trait;
use dashmap::DashMap;
use tokio::sync::mpsc;
use tokio_stream::wrappers::ReceiverStream;
use zeroize::{Zeroize, Zeroizing};

use crate::SdkError;

/// Maximum incoming payload size (512 KB) before MLS processing.
const MAX_INCOMING_PAYLOAD_SIZE: usize = 512 * 1024;

/// MIME type marker for cover traffic messages.
const COVER_PAYLOAD_TYPE: &str = "application/x-skytale-cover";

/// Generated protobuf types from DataPlaneService.
pub mod slim_proto {
    tonic::include_proto!("dataplane.proto.v1");
}

use slim_proto::data_plane_service_client::DataPlaneServiceClient;
use slim_proto::{
    content, message, ApplicationPayload, Content, Message, Name, Publish, SessionHeader,
    SessionMessageType, SessionType, SlimHeader, StringName, Subscribe,
};

/// Errors from transport operations.
#[derive(Debug, thiserror::Error)]
pub enum TransportError {
    #[error("gRPC transport error: {0}")]
    Grpc(#[from] tonic::transport::Error),

    #[error("gRPC status error: {0}")]
    Status(#[from] tonic::Status),

    #[error("send error: outbound channel closed")]
    SendFailed,

    #[error("mock transport error: {0}")]
    Mock(String),
}

/// An incoming message dispatched from the gRPC stream.
#[derive(Debug, Clone)]
pub struct IncomingMessage {
    pub channel_id: [u8; 32],
    pub session_message_type: i32,
    pub payload: Vec<u8>,
}

/// Trait abstracting message transport for the SDK.
///
/// Implemented by `GrpcTransport` (production) and `MockTransport` (testing).
#[async_trait]
pub trait Transport: Send + Sync + 'static {
    /// Subscribe to a channel. Returns a receiver for incoming messages.
    async fn subscribe(
        &self,
        channel_name: (&str, &str, &str),
        channel_id: [u8; 32],
    ) -> Result<mpsc::Receiver<IncomingMessage>, TransportError>;

    /// Publish a message to a channel.
    async fn publish(
        &self,
        channel_name: (&str, &str, &str),
        session_message_type: SessionMessageType,
        content: Content,
    ) -> Result<(), TransportError>;
}

/// Validate that a gRPC endpoint uses HTTPS for remote connections.
///
/// Delegates to `validate_url_security` for proper URL parsing to prevent
/// bypasses like `http://localhost.evil.com`.
pub(crate) fn validate_grpc_endpoint(endpoint: &str) -> Result<(), SdkError> {
    crate::client::validate_url_security(endpoint).map_err(SdkError::Auth)
}

/// Parse the `exp` claim from a JWT (base64url-encoded middle segment).
///
/// Returns `None` if the token format is invalid or the `exp` field is missing.
fn jwt_expiry(token: &str) -> Option<u64> {
    let parts: Vec<&str> = token.split('.').collect();
    if parts.len() != 3 {
        return None;
    }
    // base64url decode the payload (middle segment).
    use base64::Engine;
    let payload_bytes = base64::engine::general_purpose::URL_SAFE_NO_PAD
        .decode(parts[1])
        .ok()?;
    let value: serde_json::Value = serde_json::from_slice(&payload_bytes).ok()?;
    value.get("exp")?.as_u64()
}

/// gRPC transport client for the DataPlaneService bidirectional stream.
///
/// # Example
///
/// ```no_run
/// # async fn example() -> Result<(), Box<dyn std::error::Error>> {
/// use skytale_sdk::transport::GrpcTransport;
/// let transport = GrpcTransport::connect("https://relay.skytale.sh:5000", None).await?;
/// # Ok(())
/// # }
/// ```
pub struct GrpcTransport {
    outbound_tx: mpsc::Sender<Message>,
    channel_receivers: Arc<DashMap<[u8; 32], mpsc::Sender<IncomingMessage>>>,
}

impl GrpcTransport {
    /// Connect to the supernode's gRPC DataPlaneService.
    ///
    /// When `jwt` is `Some`, injects a `Bearer` authorization header on every
    /// outgoing gRPC request via a tonic interceptor.
    pub async fn connect(
        endpoint: &str,
        jwt: Option<Zeroizing<String>>,
    ) -> Result<Self, TransportError> {
        let (outbound_tx, outbound_rx) = mpsc::channel::<Message>(64);
        let outbound_stream = ReceiverStream::new(outbound_rx);

        let channel = tonic::transport::Channel::from_shared(endpoint.to_string())
            .map_err(|_| {
                TransportError::Status(tonic::Status::invalid_argument("invalid endpoint URI"))
            })?
            .connect()
            .await?;

        let response = if let Some(token) = jwt {
            let expiry = jwt_expiry(token.as_str());
            if let Some(exp) = expiry {
                tracing::info!(expires_at = exp, "JWT token loaded");
            } else {
                tracing::warn!("could not parse JWT expiry — token will not be refreshed");
            }

            // SECURITY NOTE: The JWT persists in the tonic MetadataValue for the
            // lifetime of this transport. tonic::metadata::MetadataValue does not
            // support Zeroize. Mitigation: JWTs should have short TTLs (5 min).
            let mut bearer_str = format!("Bearer {}", token.as_str());
            let auth_value: tonic::metadata::MetadataValue<_> =
                bearer_str.parse().map_err(|_| {
                    bearer_str.zeroize();
                    TransportError::Status(tonic::Status::internal("invalid JWT token format"))
                })?;
            bearer_str.zeroize();
            let mut client = DataPlaneServiceClient::with_interceptor(
                channel,
                move |mut req: tonic::Request<()>| {
                    // Reject requests if the JWT has expired rather than sending
                    // a stale token that would produce opaque gRPC failures.
                    if let Some(exp) = expiry {
                        let now = SystemTime::now()
                            .duration_since(UNIX_EPOCH)
                            .unwrap_or_default()
                            .as_secs();
                        if now >= exp {
                            return Err(tonic::Status::unauthenticated(
                                "JWT has expired — reconnect with a fresh token",
                            ));
                        }
                        if now + 60 >= exp {
                            tracing::warn!(
                                expires_in_secs = exp.saturating_sub(now),
                                "JWT expires within 60 seconds"
                            );
                        }
                    }
                    req.metadata_mut()
                        .insert("authorization", auth_value.clone());
                    Ok(req)
                },
            );
            client.open_channel(outbound_stream).await?
        } else {
            let mut client = DataPlaneServiceClient::new(channel);
            client.open_channel(outbound_stream).await?
        };

        let mut inbound = response.into_inner();

        let channel_receivers: Arc<DashMap<[u8; 32], mpsc::Sender<IncomingMessage>>> =
            Arc::new(DashMap::new());

        let receivers = channel_receivers.clone();
        tokio::spawn(async move {
            while let Ok(Some(msg)) = inbound.message().await {
                if let Some(incoming) = parse_incoming_message(&msg) {
                    if let Some(tx) = receivers.get(&incoming.channel_id) {
                        if tx.try_send(incoming).is_err() {
                            tracing::warn!("incoming message channel full, message dropped");
                        }
                    }
                }
            }
        });

        // Spawn SDK-to-relay cover traffic.
        let cover_tx = outbound_tx.clone();
        spawn_sdk_cover_task(cover_tx);

        Ok(Self {
            outbound_tx,
            channel_receivers,
        })
    }
}

#[async_trait]
impl Transport for GrpcTransport {
    /// Subscribe to a channel. Returns a receiver for incoming messages on that channel.
    ///
    /// `channel_name` is a 3-component string name `(org, channel, subchannel)`.
    /// `channel_id` is the 32-byte hash that identifies this channel locally.
    async fn subscribe(
        &self,
        channel_name: (&str, &str, &str),
        channel_id: [u8; 32],
    ) -> Result<mpsc::Receiver<IncomingMessage>, TransportError> {
        let (tx, rx) = mpsc::channel::<IncomingMessage>(64);
        self.channel_receivers.insert(channel_id, tx);

        let msg = Message {
            message_type: Some(message::MessageType::Subscribe(Subscribe {
                header: Some(make_header(channel_name)),
            })),
            metadata: Default::default(),
        };
        self.outbound_tx
            .send(msg)
            .await
            .map_err(|_| TransportError::SendFailed)?;

        Ok(rx)
    }

    /// Publish a message (application data or MLS operation) to a channel.
    async fn publish(
        &self,
        channel_name: (&str, &str, &str),
        session_message_type: SessionMessageType,
        content: Content,
    ) -> Result<(), TransportError> {
        let msg = Message {
            message_type: Some(message::MessageType::Publish(Publish {
                header: Some(make_header(channel_name)),
                session: Some(SessionHeader {
                    session_type: SessionType::Multicast as i32,
                    session_message_type: session_message_type as i32,
                    session_id: 0,
                    message_id: 0,
                }),
                msg: Some(content),
            })),
            metadata: Default::default(),
        };
        self.outbound_tx
            .send(msg)
            .await
            .map_err(|_| TransportError::SendFailed)?;
        Ok(())
    }
}

fn make_header(channel_name: (&str, &str, &str)) -> SlimHeader {
    SlimHeader {
        source: None,
        destination: Some(Name {
            name: None,
            str_name: Some(StringName {
                str_component_0: channel_name.0.to_string(),
                str_component_1: channel_name.1.to_string(),
                str_component_2: channel_name.2.to_string(),
            }),
        }),
        identity: String::new(),
        fanout: 0,
        recv_from: None,
        forward_to: None,
        incoming_conn: None,
        error: None,
    }
}

/// Extract an IncomingMessage from a gRPC Message, if it contains a Publish payload.
fn parse_incoming_message(msg: &Message) -> Option<IncomingMessage> {
    let publish = match &msg.message_type {
        Some(message::MessageType::Publish(p)) => p,
        _ => return None,
    };

    // Derive channel_id from destination name components via SHA-256.
    // Uses "/" separators to match the supernode's hash_name().
    let channel_id = if let Some(dest) = &publish.header.as_ref()?.destination {
        if let Some(str_name) = &dest.str_name {
            let mut hasher = <sha2::Sha256 as sha2::Digest>::new();
            sha2::Digest::update(&mut hasher, str_name.str_component_0.as_bytes());
            sha2::Digest::update(&mut hasher, b"/");
            sha2::Digest::update(&mut hasher, str_name.str_component_1.as_bytes());
            sha2::Digest::update(&mut hasher, b"/");
            sha2::Digest::update(&mut hasher, str_name.str_component_2.as_bytes());
            let hash: [u8; 32] = sha2::Digest::finalize(hasher).into();
            hash
        } else {
            return None;
        }
    } else {
        return None;
    };

    let session_message_type = publish
        .session
        .as_ref()
        .map(|s| s.session_message_type)
        .unwrap_or(0);

    // Extract payload bytes from the Content oneof.
    // The supernode appends an 8-byte LE sequence number to relayed payloads;
    // strip it so mls-rs receives clean MLS ciphertext.
    let payload = match &publish.msg {
        Some(content) => match &content.content_type {
            Some(slim_proto::content::ContentType::AppPayload(app)) => {
                // Discard relay-to-SDK cover traffic.
                if app.payload_type == COVER_PAYLOAD_TYPE {
                    return None;
                }
                strip_seq_suffix(&app.blob)
            }
            Some(slim_proto::content::ContentType::CommandPayload(cmd)) => {
                strip_seq_suffix(&extract_mls_content(cmd))
            }
            None => Vec::new(),
        },
        None => Vec::new(),
    };

    if payload.len() > MAX_INCOMING_PAYLOAD_SIZE {
        tracing::warn!(size = payload.len(), "incoming payload too large, dropping");
        return None;
    }

    Some(IncomingMessage {
        channel_id,
        session_message_type,
        payload,
    })
}

/// Strip the trailing 8-byte LE sequence number appended by the supernode.
///
/// Returns the original bytes unchanged if the payload is too short (≤8 bytes).
fn strip_seq_suffix(data: &[u8]) -> Vec<u8> {
    if data.len() > 8 {
        data[..data.len() - 8].to_vec()
    } else {
        data.to_vec()
    }
}

/// Extract MLS content bytes from command payloads that carry them.
fn extract_mls_content(cmd: &slim_proto::CommandPayload) -> Vec<u8> {
    use slim_proto::command_payload::CommandPayloadType;
    match &cmd.command_payload_type {
        Some(CommandPayloadType::GroupAdd(p)) => p
            .mls
            .as_ref()
            .map(|m| m.mls_content.clone())
            .unwrap_or_default(),
        Some(CommandPayloadType::GroupRemove(p)) => p
            .mls
            .as_ref()
            .map(|m| m.mls_content.clone())
            .unwrap_or_default(),
        Some(CommandPayloadType::GroupWelcome(p)) => p
            .mls
            .as_ref()
            .map(|m| m.mls_content.clone())
            .unwrap_or_default(),
        Some(CommandPayloadType::GroupProposal(p)) => p.mls_proposal.clone(),
        Some(CommandPayloadType::JoinReply(p)) => p.key_package.clone().unwrap_or_default(),
        _ => Vec::new(),
    }
}

// ---------------------------------------------------------------------------
// SDK-to-relay cover traffic
// ---------------------------------------------------------------------------

/// Spawns a background task that sends cover traffic as SLIM Publish messages
/// to the relay at jittered intervals.
///
/// Cover messages use `payload_type: "application/x-skytale-cover"` so the
/// relay can identify and discard them without processing.
///
/// The task stops automatically when `outbound_tx` is closed (transport dropped).
fn spawn_sdk_cover_task(outbound_tx: mpsc::Sender<Message>) -> tokio::task::JoinHandle<()> {
    tokio::spawn(async move {
        loop {
            let delay = sdk_cover_jittered_delay();
            tokio::time::sleep(delay).await;

            let size = sdk_cover_select_size();
            let msg = build_sdk_cover_message(size);

            if outbound_tx.send(msg).await.is_err() {
                tracing::debug!("SDK cover traffic task stopping (channel closed)");
                break;
            }
            tracing::trace!(size, "sent SDK cover frame");
        }
    })
}

/// Jittered delay using exponential distribution (Poisson-process timing).
fn sdk_cover_jittered_delay() -> std::time::Duration {
    use std::time::Duration;
    let base_ms: f64 = 5000.0;
    let jitter_ms: f64 = 2000.0;
    let u: f64 = rand::random();
    let exp_sample = -base_ms * (1.0 - u).ln();
    let max_ms = base_ms + 3.0 * jitter_ms;
    let total_ms = exp_sample.clamp(10.0, max_ms);
    Duration::from_millis(total_ms as u64)
}

/// Selects a random bucket size using weighted distribution matching real traffic patterns.
fn sdk_cover_select_size() -> usize {
    let bucket_sizes: [usize; 8] = [256, 512, 1024, 2048, 4096, 8192, 16384, 32768];
    let weights = [0.25f64, 0.25, 0.20, 0.12, 0.08, 0.05, 0.03, 0.02];
    let total: f64 = weights.iter().sum();
    let mut r: f64 = rand::random::<f64>() * total;
    for (i, &w) in weights.iter().enumerate() {
        r -= w;
        if r <= 0.0 {
            return bucket_sizes[i];
        }
    }
    bucket_sizes[0]
}

/// Builds a SLIM Publish message filled with random data for cover traffic.
fn build_sdk_cover_message(size: usize) -> Message {
    use rand::RngExt;

    let rand_hex = || format!("{:016x}", rand::random::<u64>());

    // Random payload sized to approximate the target bucket.
    let payload_size = size.saturating_sub(64);
    let mut payload = vec![0u8; payload_size];
    rand::rng().fill(&mut payload);

    Message {
        message_type: Some(message::MessageType::Publish(Publish {
            header: Some(SlimHeader {
                source: None,
                destination: Some(Name {
                    name: None,
                    str_name: Some(StringName {
                        str_component_0: rand_hex(),
                        str_component_1: rand_hex(),
                        str_component_2: rand_hex(),
                    }),
                }),
                identity: String::new(),
                fanout: 0,
                recv_from: None,
                forward_to: None,
                incoming_conn: None,
                error: None,
            }),
            session: Some(SessionHeader {
                session_type: SessionType::Multicast as i32,
                session_message_type: SessionMessageType::Msg as i32,
                session_id: 0,
                message_id: 0,
            }),
            msg: Some(Content {
                content_type: Some(content::ContentType::AppPayload(ApplicationPayload {
                    payload_type: COVER_PAYLOAD_TYPE.to_string(),
                    blob: payload,
                })),
            }),
        })),
        metadata: Default::default(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;

    #[test]
    fn test_sdk_cover_jittered_delay_bounds() {
        for _ in 0..100 {
            let d = sdk_cover_jittered_delay();
            assert!(d.as_millis() >= 10, "delay too short: {}ms", d.as_millis());
            assert!(
                d.as_millis() <= 11000,
                "delay too long: {}ms",
                d.as_millis()
            );
        }
    }

    #[test]
    fn test_sdk_cover_jittered_delay_variance() {
        let delays: Vec<_> = (0..20).map(|_| sdk_cover_jittered_delay()).collect();
        let unique: HashSet<_> = delays.iter().map(|d| d.as_millis()).collect();
        assert!(unique.len() > 1, "all 20 delays were identical");
    }

    #[test]
    fn test_sdk_cover_select_size_valid() {
        let valid: HashSet<usize> = [256, 512, 1024, 2048, 4096, 8192, 16384, 32768].into();
        for _ in 0..1000 {
            let s = sdk_cover_select_size();
            assert!(valid.contains(&s), "unexpected size: {s}");
        }
    }

    #[test]
    fn test_sdk_cover_select_size_distribution() {
        let mut seen: HashSet<usize> = HashSet::new();
        for _ in 0..10000 {
            seen.insert(sdk_cover_select_size());
        }
        assert_eq!(seen.len(), 8, "not all 8 bucket sizes appeared: {seen:?}");
    }

    #[test]
    fn test_build_sdk_cover_message_has_cover_type() {
        let msg = build_sdk_cover_message(1024);
        let publish = match msg.message_type {
            Some(message::MessageType::Publish(p)) => p,
            _ => panic!("expected Publish"),
        };
        let app = match publish.msg.unwrap().content_type {
            Some(content::ContentType::AppPayload(a)) => a,
            _ => panic!("expected AppPayload"),
        };
        assert_eq!(app.payload_type, COVER_PAYLOAD_TYPE);
    }

    #[test]
    fn test_build_sdk_cover_message_has_random_destination() {
        let msg1 = build_sdk_cover_message(256);
        let msg2 = build_sdk_cover_message(256);
        let dest = |m: Message| -> String {
            let p = match m.message_type {
                Some(message::MessageType::Publish(p)) => p,
                _ => panic!("expected Publish"),
            };
            let sn = p.header.unwrap().destination.unwrap().str_name.unwrap();
            format!(
                "{}/{}/{}",
                sn.str_component_0, sn.str_component_1, sn.str_component_2
            )
        };
        assert_ne!(
            dest(msg1),
            dest(msg2),
            "two cover messages had the same destination"
        );
    }

    #[test]
    fn test_parse_incoming_discards_cover() {
        let cover_msg = build_sdk_cover_message(512);
        let result = parse_incoming_message(&cover_msg);
        assert!(result.is_none(), "cover message should be discarded");
    }
}
