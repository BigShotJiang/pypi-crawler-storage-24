"""LlamaIndex -- encrypted channel tools.

Demonstrates the LlamaIndex integration with mock transport.
Note: requires `pip install llama-index-core` to actually run with an agent.

Usage:
    python examples/mock_llamaindex.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._llamaindex import create_manager

mgr = SkytaleChannelManager(identity=b"llamaindex-agent", mock=True)
mgr.create("org/llamaindex/research")
print("Created channel: org/llamaindex/research")

# Send and receive directly (tools() requires llama-index-core installed)
mgr.send("org/llamaindex/research", "Hello from LlamaIndex agent!")
print("Sent message via manager")

channels = mgr.list_channels()
print(f"Active channels: {channels}")

try:
    from skytale_sdk.integrations._llamaindex import tools
    li_tools = tools(mgr)
    print(f"Tools: {[t.metadata.name for t in li_tools]}")
except ImportError:
    print("llama-index-core not installed -- pip install skytale-sdk[llamaindex]")

mgr.close()
print("Done!")
