"""OpenAI Agents SDK -- encrypted channel tools.

Demonstrates the OpenAI Agents SDK integration with mock transport.
Note: requires `pip install openai-agents` to actually run with an agent.

Usage:
    python examples/mock_openai_agents.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._openai_agents import create_manager

mgr = SkytaleChannelManager(identity=b"oai-agent", mock=True)
mgr.create("org/research/results")
print("Created channel: org/research/results")

# Send and receive directly (tools() requires openai-agents installed)
mgr.send("org/research/results", "Hello from OpenAI agent!")
print("Sent message via manager")

channels = mgr.list_channels()
print(f"Active channels: {channels}")

try:
    from skytale_sdk.integrations._openai_agents import tools
    oai_tools = tools(mgr)
    print(f"Tools: {[t.__name__ if hasattr(t, '__name__') else str(t) for t in oai_tools]}")
except ImportError:
    print("openai-agents not installed -- pip install skytale-sdk[openai-agents]")

mgr.close()
print("Done!")
