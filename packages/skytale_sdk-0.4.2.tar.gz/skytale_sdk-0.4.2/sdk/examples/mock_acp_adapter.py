"""ACP adapter -- task-based messaging.

Demonstrates the IBM ACP protocol adapter with mock transport.

Usage:
    python examples/mock_acp_adapter.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._acp import SkytaleACPAdapter

mgr = SkytaleChannelManager(identity=b"acp-agent", mock=True)
adapter = SkytaleACPAdapter(mgr, agent_id="analyzer-42")

# Create a task (maps to an MLS-encrypted channel)
adapter.create_task("analysis-job-1")
print("Created ACP task: analysis-job-1")

# Send a structured ACP message
adapter.send_message("analysis-job-1", {
    "status": "complete",
    "result": "3 anomalies detected in dataset",
})
print("Sent ACP message")

# Receive messages (empty in single-agent mock)
msgs = adapter.receive_messages("analysis-job-1", timeout=0.5)
print(f"Received: {msgs}")

mgr.close()
print("Done!")
