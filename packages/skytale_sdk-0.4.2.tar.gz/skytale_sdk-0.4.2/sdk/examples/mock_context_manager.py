"""Context manager for automatic cleanup.

Demonstrates the ``with`` statement which ensures ``close()`` is called
even if an exception occurs.

Usage:
    python examples/mock_context_manager.py
"""

from skytale_sdk import SkytaleChannelManager

# The context manager calls close() automatically on exit
with SkytaleChannelManager(identity=b"ctx-agent", mock=True) as mgr:
    mgr.create("acme/team/general")
    mgr.send("acme/team/general", "Hello with auto-cleanup!")
    channels = mgr.list_channels()
    print(f"Inside context: {channels}")

# mgr.close() was called automatically
print("Context exited -- resources cleaned up")
