"""NLIP adapter -- natural language sessions with submessages.

Demonstrates the NLIP protocol adapter with mock transport.

Usage:
    python examples/mock_nlip_adapter.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._nlip import SkytaleNLIPAdapter

mgr = SkytaleChannelManager(identity=b"nlip-agent", mock=True)
adapter = SkytaleNLIPAdapter(mgr, agent_id="nlip-agent-1")

# Create a session
adapter.create_session("session-42")
print("Created NLIP session: session-42")

# Send a simple text message
adapter.send_message("session-42", "Analysis complete: 3 anomalies found")
print("Sent NLIP text message")

# Send a multimodal message
adapter.send_multimodal("session-42", [
    {"subMessageType": "content", "contentType": "text",
     "content": "See the attached analysis."},
    {"subMessageType": "content", "contentType": "application/json",
     "content": {"anomalies": 3, "confidence": 0.95}},
])
print("Sent NLIP multimodal message")

# Receive messages (empty in single-agent mock)
msgs = adapter.receive_messages("session-42", timeout=0.5)
print(f"Received: {msgs}")

mgr.close()
print("Done!")
