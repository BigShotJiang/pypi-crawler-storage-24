"""Environment variable configuration.

Demonstrates enabling mock mode via the SKYTALE_MOCK environment variable
instead of passing ``mock=True`` to the constructor. This pattern is
useful for testing pipelines where you want the same code to work in
dev (mock) and production (real relay).

Usage:
    SKYTALE_MOCK=1 python examples/mock_env_var.py
"""

import os

# Set the env var before importing (simulates CI/test environment)
os.environ["SKYTALE_MOCK"] = "1"

from skytale_sdk import SkytaleChannelManager

# No mock=True needed -- picked up from SKYTALE_MOCK env var
mgr = SkytaleChannelManager(identity=b"env-agent")

mgr.create("acme/test/ci-channel")
mgr.send("acme/test/ci-channel", "Hello from env-var mock mode!")
channels = mgr.list_channels()
print(f"Mock mode via env var: channels={channels}")

mgr.close()

# Clean up env var
del os.environ["SKYTALE_MOCK"]
print("Done!")
