"""Quickstart with mock mode -- no relay needed.

Demonstrates creating a channel, sending a message, and listing channels
using the in-memory mock transport.

Usage:
    python examples/mock_quickstart.py
"""

from skytale_sdk import SkytaleChannelManager

mgr = SkytaleChannelManager(identity=b"demo-agent", mock=True)

# Create a channel
mgr.create("acme/team/general")
print("Created channel: acme/team/general")

# Send a message
mgr.send("acme/team/general", "Hello from mock mode!")
print("Sent message")

# List active channels
channels = mgr.list_channels()
print(f"Active channels: {channels}")

# Receive (will be empty in single-agent mock — messages go to other members)
msgs = mgr.receive("acme/team/general", timeout=0.5)
print(f"Received: {msgs}")

mgr.close()
print("Done!")
