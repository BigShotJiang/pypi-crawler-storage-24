"""LMOS adapter -- WoT Thing actions and events.

Demonstrates the Eclipse LMOS protocol adapter with mock transport.

Usage:
    python examples/mock_lmos_adapter.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._lmos import SkytaleLMOSAdapter

mgr = SkytaleChannelManager(identity=b"lmos-agent", mock=True)
adapter = SkytaleLMOSAdapter(mgr, thing_id="urn:lmos:agent:analyzer")

# Create a channel to a target Thing
adapter.create_channel("peer-thing-1")
print("Created LMOS channel to peer-thing-1")

# Invoke an action
adapter.invoke_action("peer-thing-1", "analyze", {"dataset": "sales-q4"})
print("Invoked LMOS action: analyze")

# Send action status
adapter.send_action_status(
    "peer-thing-1", "analyze", "completed",
    {"result": "3 anomalies found"},
)
print("Sent action status")

# Send an event
adapter.send_event("peer-thing-1", "anomaly_detected", {"count": 3})
print("Sent LMOS event")

# Receive messages (empty in single-agent mock)
msgs = adapter.receive_messages("peer-thing-1", timeout=0.5)
print(f"Received: {msgs}")

mgr.close()
print("Done!")
