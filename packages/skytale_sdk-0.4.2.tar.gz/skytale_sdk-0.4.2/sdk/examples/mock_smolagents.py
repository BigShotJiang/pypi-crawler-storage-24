"""smolagents -- encrypted channel tools.

Demonstrates the Hugging Face smolagents integration with mock transport.
Note: requires `pip install smolagents` to actually run with an agent.

Usage:
    python examples/mock_smolagents.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._smolagents import create_manager

mgr = SkytaleChannelManager(identity=b"sm-agent", mock=True)
mgr.create("org/hf/pipeline")
print("Created channel: org/hf/pipeline")

# Send and receive directly (tools() requires smolagents installed)
mgr.send("org/hf/pipeline", "Pipeline result ready")
print("Sent message via manager")

channels = mgr.list_channels()
print(f"Active channels: {channels}")

try:
    from skytale_sdk.integrations._smolagents import tools
    sm_tools = tools(mgr)
    print(f"Tools: {[t.name for t in sm_tools]}")
except ImportError:
    print("smolagents not installed -- pip install skytale-sdk[smolagents]")

mgr.close()
print("Done!")
