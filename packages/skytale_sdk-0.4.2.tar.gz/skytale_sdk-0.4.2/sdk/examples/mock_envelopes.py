"""Envelope serialization round-trip.

Demonstrates creating, serializing, and deserializing multi-protocol
Envelope messages without needing a relay connection.

Usage:
    python examples/mock_envelopes.py
"""

import json

from skytale_sdk.envelope import Envelope, Protocol

# A2A envelope
a2a_payload = json.dumps({"parts": [{"type": "text", "text": "Hello A2A"}]}).encode()
a2a_env = Envelope(Protocol.A2A, "application/json", a2a_payload)
print(f"A2A envelope: protocol={a2a_env.protocol.value}, size={len(a2a_env.payload)}B")

# Serialize and deserialize
wire = a2a_env.serialize()
restored = Envelope.deserialize(wire)
assert restored == a2a_env
print(f"Round-trip OK: {len(wire)} bytes on wire")

# SLIM envelope with metadata
slim_env = Envelope(
    Protocol.SLIM,
    "application/octet-stream",
    b"\x01\x02\x03",
    metadata={"topic": "sensors", "priority": "high"},
)
wire2 = slim_env.serialize()
restored2 = Envelope.deserialize(wire2)
assert restored2 == slim_env
print(f"SLIM envelope with metadata: {restored2.metadata}")

# MCP envelope
mcp_payload = json.dumps({"jsonrpc": "2.0", "method": "ping", "id": 1}).encode()
mcp_env = Envelope(Protocol.MCP, "application/json", mcp_payload)
wire3 = mcp_env.serialize()
restored3 = Envelope.deserialize(wire3)
print(f"MCP round-trip: method={json.loads(restored3.payload)['method']}")

# ACP envelope
acp_payload = json.dumps({"taskId": "t-1", "status": "running"}).encode()
acp_env = Envelope(Protocol.ACP, "application/json", acp_payload)
wire4 = acp_env.serialize()
restored4 = Envelope.deserialize(wire4)
print(f"ACP round-trip: taskId={json.loads(restored4.payload)['taskId']}")

print("\nAll protocol envelopes round-tripped successfully!")
