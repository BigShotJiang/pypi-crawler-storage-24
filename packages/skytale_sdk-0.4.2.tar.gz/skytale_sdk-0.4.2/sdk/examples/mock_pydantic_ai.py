"""Pydantic AI -- encrypted channel tools.

Demonstrates the Pydantic AI integration with mock transport.
Note: requires `pip install pydantic-ai` to actually run with an agent.

Usage:
    python examples/mock_pydantic_ai.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._pydantic_ai import tools

mgr = SkytaleChannelManager(identity=b"pai-agent", mock=True)
mgr.create("org/analysis/reports")
print("Created channel: org/analysis/reports")

# Get tools (would pass to Agent('model', tools=...))
pai_tools = tools(mgr)
print(f"Tools: {[f.__name__ for f in pai_tools]}")

# Call tools directly
result = pai_tools[0]("org/analysis/reports", "Report ready")
print(f"Send result: {result}")

result = pai_tools[2]()
print(f"Channels result: {result}")

mgr.close()
print("Done!")
