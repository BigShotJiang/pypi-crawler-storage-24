"""Agno -- encrypted channel toolkit.

Demonstrates the Agno integration with mock transport.
Note: requires `pip install agno` to actually run with an agent.

Usage:
    python examples/mock_agno.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._agno import create_manager

mgr = SkytaleChannelManager(identity=b"agno-agent", mock=True)
mgr.create("org/agno/tasks")
print("Created channel: org/agno/tasks")

# Send and receive directly (toolkit() requires agno installed)
mgr.send("org/agno/tasks", "Task completed")
print("Sent message via manager")

channels = mgr.list_channels()
print(f"Active channels: {channels}")

try:
    from skytale_sdk.integrations._agno import toolkit
    tk = toolkit(mgr)
    print(f"Toolkit name: {tk.name}")
except ImportError:
    print("agno not installed -- pip install skytale-sdk[agno]")

mgr.close()
print("Done!")
