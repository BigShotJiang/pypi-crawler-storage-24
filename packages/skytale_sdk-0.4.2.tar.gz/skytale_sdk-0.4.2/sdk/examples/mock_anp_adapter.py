"""ANP adapter -- DID-based sessions and messages.

Demonstrates the ANP protocol adapter with mock transport.

Usage:
    python examples/mock_anp_adapter.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._anp import SkytaleANPAdapter

mgr = SkytaleChannelManager(identity=b"anp-agent", mock=True)
adapter = SkytaleANPAdapter(mgr, did="did:web:agent.example.com")

# Create a session with a peer
adapter.create_session("did:web:peer.example.com")
print("Created ANP session with peer")

# Send a message
adapter.send_message("did:web:peer.example.com", {
    "action": "analyze",
    "data": {"dataset": "sales-q4"},
})
print("Sent ANP message")

# Send an RPC call
adapter.send_rpc("did:web:peer.example.com", "getStatus", {"verbose": True})
print("Sent ANP RPC call")

# Receive messages (empty in single-agent mock)
msgs = adapter.receive_messages("did:web:peer.example.com", timeout=0.5)
print(f"Received: {msgs}")

mgr.close()
print("Done!")
