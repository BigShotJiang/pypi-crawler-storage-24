"""Strands Agents (AWS) -- encrypted channel tools.

Demonstrates the Strands Agents integration with mock transport.
Note: requires `pip install strands-agents` to actually run with an agent.

Usage:
    python examples/mock_strands.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._strands import create_manager

mgr = SkytaleChannelManager(identity=b"strands-agent", mock=True)
mgr.create("org/strands/research")
print("Created channel: org/strands/research")

# Send and receive directly (tools() requires strands-agents installed)
mgr.send("org/strands/research", "Hello from Strands agent!")
print("Sent message via manager")

channels = mgr.list_channels()
print(f"Active channels: {channels}")

try:
    from skytale_sdk.integrations._strands import tools
    st_tools = tools(mgr)
    print(f"Tools: {[t.__name__ if hasattr(t, '__name__') else str(t) for t in st_tools]}")
except ImportError:
    print("strands-agents not installed -- pip install skytale-sdk[strands]")

mgr.close()
print("Done!")
