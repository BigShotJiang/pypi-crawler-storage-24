"""SLIM adapter -- publish/subscribe messaging.

Demonstrates the SLIM protocol adapter with mock transport.

Usage:
    python examples/mock_slim_adapter.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._slim import SLIMAdapter

mgr = SkytaleChannelManager(identity=b"slim-agent", mock=True)
adapter = SLIMAdapter(mgr)

# Subscribe to a channel (creates it)
adapter.subscribe("acme/sensors/temperature")
print("Subscribed to: acme/sensors/temperature")

# Publish a message
adapter.publish(
    "acme/sensors/temperature",
    b'{"sensor": "thermostat-1", "temp_c": 22.5}',
    content_type="application/json",
)
print("Published sensor reading")

# Receive (empty in single-agent mock)
msgs = adapter.receive("acme/sensors/temperature", timeout=0.5)
print(f"Received: {len(msgs)} messages")

mgr.close()
print("Done!")
