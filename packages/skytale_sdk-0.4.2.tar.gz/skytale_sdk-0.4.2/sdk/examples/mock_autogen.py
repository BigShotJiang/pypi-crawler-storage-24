"""AutoGen -- encrypted channel tools.

Demonstrates the AutoGen integration with mock transport.
Note: requires `pip install autogen-agentchat` to actually run with an agent.

Usage:
    python examples/mock_autogen.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._autogen import create_manager

mgr = SkytaleChannelManager(identity=b"autogen-agent", mock=True)
mgr.create("org/autogen/research")
print("Created channel: org/autogen/research")

# Send and receive directly (tools() requires autogen-agentchat installed)
mgr.send("org/autogen/research", "Hello from AutoGen agent!")
print("Sent message via manager")

channels = mgr.list_channels()
print(f"Active channels: {channels}")

try:
    from skytale_sdk.integrations._autogen import tools
    ag_tools = tools(mgr)
    print(f"Tools: {[t.__name__ if hasattr(t, '__name__') else str(t) for t in ag_tools]}")
except ImportError:
    print("autogen-agentchat not installed -- pip install skytale-sdk[autogen]")

mgr.close()
print("Done!")
