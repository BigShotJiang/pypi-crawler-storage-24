"""A2A adapter -- contexts, messages, and agent card.

Demonstrates the Google A2A protocol adapter with mock transport.

Usage:
    python examples/mock_a2a_adapter.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._a2a import SkytaleA2AAdapter

mgr = SkytaleChannelManager(identity=b"a2a-agent", mock=True)
adapter = SkytaleA2AAdapter(mgr, agent_id="researcher-bot")

# Create a context (maps to an MLS-encrypted channel)
adapter.create_context("research-session-1")
print("Created A2A context: research-session-1")

# Send a structured A2A message
adapter.send_message("research-session-1", [
    {"type": "text", "text": "Analysis complete: 3 anomalies found"},
])
print("Sent A2A message")

# Get agent card extension metadata
card = adapter.agent_card_extension()
print(f"Agent card: {card}")

# Receive messages (empty in single-agent mock)
msgs = adapter.receive_messages("research-session-1", timeout=0.5)
print(f"Received: {msgs}")

mgr.close()
print("Done!")
