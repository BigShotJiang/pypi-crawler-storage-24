"""Google ADK -- encrypted channel tools.

Demonstrates the Google ADK integration with mock transport.
Note: requires `pip install google-adk` to actually run with an agent.

Usage:
    python examples/mock_google_adk.py
"""

from skytale_sdk import SkytaleChannelManager
from skytale_sdk.integrations._google_adk import tools

mgr = SkytaleChannelManager(identity=b"adk-agent", mock=True)
mgr.create("org/google/gemini")
print("Created channel: org/google/gemini")

# Get tools (would pass to Agent(tools=...))
adk_tools = tools(mgr)
print(f"Tools: {[f.__name__ for f in adk_tools]}")

# Call tools directly -- ADK tools return dicts
result = adk_tools[0]("org/google/gemini", "Gemini analysis complete")
print(f"Send result: {result}")

result = adk_tools[2]()
print(f"Channels result: {result}")

mgr.close()
print("Done!")
