"""AutoGen integration: expose Skytale channels as agent tools.

Usage::

    from skytale_sdk.integrations import _autogen as skytale_ag

    mgr = skytale_ag.create_manager(identity=b"my-agent")
    mgr.create("org/ns/chan")
    agent = AssistantAgent(tools=skytale_ag.tools(mgr))
"""

from __future__ import annotations

from typing import Optional

from skytale_sdk.channels import SkytaleChannelManager


def create_manager(**kwargs) -> SkytaleChannelManager:
    """Create a ``SkytaleChannelManager`` with the given options.

    Accepts the same keyword arguments as ``SkytaleChannelManager``.

    Returns:
        A configured channel manager.
    """
    return SkytaleChannelManager(**kwargs)


def tools(manager: SkytaleChannelManager) -> list:
    """Return AutoGen tools bound to *manager*.

    Requires ``autogen-agentchat>=0.4.0``. Install with::

        pip install skytale-sdk[autogen]

    Args:
        manager: A ``SkytaleChannelManager`` managing the channels.

    Returns:
        List of six ``FunctionTool``-wrapped functions:
        ``skytale_send``, ``skytale_receive``, ``skytale_channels``,
        ``skytale_create_channel``, ``skytale_invite``, ``skytale_join``.
    """
    from autogen_core.tools import FunctionTool

    def skytale_send(channel: str, message: str) -> str:
        """Send an encrypted message to a Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
            message: Message text to send.
        """
        manager.send(channel, message)
        return f"Message sent to {channel}"

    def skytale_receive(channel: str, timeout: Optional[float] = 5.0) -> str:
        """Receive encrypted messages from a Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
            timeout: Seconds to wait for messages (default 5).
        """
        msgs = manager.receive(channel, timeout=timeout or 5.0)
        if not msgs:
            return f"No new messages on {channel}"
        return "\n".join(f"[{channel}] {m}" for m in msgs)

    def skytale_channels() -> str:
        """List all active Skytale encrypted channels."""
        channels = manager.list_channels()
        if not channels:
            return "No active channels"
        return ", ".join(channels)

    def skytale_create_channel(channel: str) -> str:
        """Create a new encrypted Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
        """
        manager.create(channel)
        return f"Channel {channel} created"

    def skytale_invite(channel: str, max_uses: int = 1, ttl: int = 3600) -> str:
        """Create an invite token for a Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
            max_uses: How many times the token can be used (default 1).
            ttl: Token lifetime in seconds (default 3600).
        """
        token = manager.invite(channel, max_uses=max_uses, ttl=ttl)
        return f"Invite token for {channel}: {token}"

    def skytale_join(channel: str, token: str) -> str:
        """Join a Skytale channel using an invite token.

        Args:
            channel: Channel name in org/namespace/service format.
            token: Invite token (skt_inv_...) from the channel owner.
        """
        manager.join_with_token(channel, token)
        return f"Joined channel {channel}"

    return [
        FunctionTool(skytale_send, description="Send an encrypted message to a Skytale channel."),
        FunctionTool(skytale_receive, description="Receive encrypted messages from a Skytale channel."),
        FunctionTool(skytale_channels, description="List all active Skytale encrypted channels."),
        FunctionTool(skytale_create_channel, description="Create a new encrypted Skytale channel."),
        FunctionTool(skytale_invite, description="Create an invite token for a Skytale channel."),
        FunctionTool(skytale_join, description="Join a Skytale channel using an invite token."),
    ]
