"""Google ADK integration: expose Skytale channels as ADK agent tools.

Usage::

    from skytale_sdk.integrations import _google_adk as skytale_adk

    mgr = skytale_adk.create_manager(identity=b"my-agent")
    mgr.create("org/ns/chan")
    agent = Agent(model='gemini-2.0-flash', name='agent',
                  tools=skytale_adk.tools(mgr))
"""

from __future__ import annotations

from skytale_sdk.channels import SkytaleChannelManager


def create_manager(**kwargs) -> SkytaleChannelManager:
    """Create a ``SkytaleChannelManager`` with the given options.

    Accepts the same keyword arguments as ``SkytaleChannelManager``.

    Returns:
        A configured channel manager.
    """
    return SkytaleChannelManager(**kwargs)


def tools(manager: SkytaleChannelManager) -> list:
    """Return plain functions suitable for Google ADK ``Agent(tools=[...])``.

    Google ADK auto-wraps plain functions as ``FunctionTool`` instances.
    Functions return dicts with a ``status`` key for structured output.

    Install with::

        pip install skytale-sdk[google-adk]

    Args:
        manager: A ``SkytaleChannelManager`` managing the channels.

    Returns:
        List of six functions:
        ``skytale_send``, ``skytale_receive``, ``skytale_channels``,
        ``skytale_create_channel``, ``skytale_invite``, ``skytale_join``.
    """

    def skytale_send(channel: str, message: str) -> dict:
        """Send an encrypted message to a Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
            message: Message text to send.
        """
        manager.send(channel, message)
        return {"status": "sent", "channel": channel}

    def skytale_receive(channel: str, timeout: float = 5.0) -> dict:
        """Receive encrypted messages from a Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
            timeout: Seconds to wait for messages (default 5).
        """
        msgs = manager.receive(channel, timeout=timeout or 5.0)
        return {"status": "ok", "messages": msgs}

    def skytale_channels() -> dict:
        """List all active Skytale encrypted channels."""
        channels = manager.list_channels()
        return {"status": "ok", "channels": channels}

    def skytale_create_channel(channel: str) -> dict:
        """Create a new encrypted Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
        """
        manager.create(channel)
        return {"status": "created", "channel": channel}

    def skytale_invite(channel: str, max_uses: int = 1, ttl: int = 3600) -> dict:
        """Create an invite token for a Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
            max_uses: How many times the token can be used (default 1).
            ttl: Token lifetime in seconds (default 3600).
        """
        token = manager.invite(channel, max_uses=max_uses, ttl=ttl)
        return {"status": "ok", "channel": channel, "token": token}

    def skytale_join(channel: str, token: str) -> dict:
        """Join a Skytale channel using an invite token.

        Args:
            channel: Channel name in org/namespace/service format.
            token: Invite token (skt_inv_...) from the channel owner.
        """
        manager.join_with_token(channel, token)
        return {"status": "joined", "channel": channel}

    return [
        skytale_send,
        skytale_receive,
        skytale_channels,
        skytale_create_channel,
        skytale_invite,
        skytale_join,
    ]
