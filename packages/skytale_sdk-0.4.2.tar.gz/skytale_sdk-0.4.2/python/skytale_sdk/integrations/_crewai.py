"""CrewAI integration: expose Skytale encrypted channels as CrewAI tools.

Usage::

    from skytale_sdk.integrations import _crewai as skytale_crew

    mgr = skytale_crew.create_manager(identity=b"analyst")
    mgr.create("org/ns/chan")
    analyst = Agent(role="Analyst", tools=skytale_crew.tools(mgr))
"""

from __future__ import annotations

from typing import Optional

from skytale_sdk.channels import SkytaleChannelManager


def create_manager(**kwargs) -> SkytaleChannelManager:
    """Create a ``SkytaleChannelManager`` with the given options.

    Accepts the same keyword arguments as ``SkytaleChannelManager``.

    Returns:
        A configured channel manager.
    """
    return SkytaleChannelManager(**kwargs)


def tools(manager: SkytaleChannelManager) -> list:
    """Return CrewAI-compatible tools bound to *manager*.

    Requires ``crewai>=0.80.0``. Install with::

        pip install skytale-sdk[crewai]

    Args:
        manager: A ``SkytaleChannelManager`` managing the channels.

    Returns:
        List of six ``BaseTool`` instances:
        ``SkytaleSendTool``, ``SkytaleReceiveTool``, ``SkytaleChannelsTool``,
        ``SkytaleCreateChannelTool``, ``SkytaleInviteTool``, ``SkytaleJoinTool``.
    """
    from crewai.tools import BaseTool
    from pydantic import BaseModel, Field

    class SendInput(BaseModel):
        channel: str = Field(description="Channel name (org/namespace/service)")
        message: str = Field(description="Message text to send")

    class ReceiveInput(BaseModel):
        channel: str = Field(description="Channel name (org/namespace/service)")
        timeout: float = Field(default=5.0, description="Seconds to wait")

    class SkytaleSendTool(BaseTool):
        name: str = "skytale_send"
        description: str = (
            "Send an encrypted message to an AI agent channel. "
            "Messages are end-to-end encrypted using the MLS protocol."
        )
        args_schema: type[BaseModel] = SendInput

        def _run(self, channel: str, message: str) -> str:
            manager.send(channel, message)
            return f"Message sent to {channel}"

    class SkytaleReceiveTool(BaseTool):
        name: str = "skytale_receive"
        description: str = (
            "Receive encrypted messages from an AI agent channel. "
            "Returns all messages received since the last check."
        )
        args_schema: type[BaseModel] = ReceiveInput

        def _run(
            self, channel: str, timeout: Optional[float] = 5.0
        ) -> str:
            msgs = manager.receive(channel, timeout=timeout or 5.0)
            if not msgs:
                return f"No new messages on {channel}"
            return "\n".join(f"[{channel}] {m}" for m in msgs)

    class SkytaleChannelsTool(BaseTool):
        name: str = "skytale_channels"
        description: str = (
            "List all active Skytale encrypted channels that this "
            "agent has created or joined."
        )

        def _run(self) -> str:
            channels = manager.list_channels()
            if not channels:
                return "No active channels"
            return ", ".join(channels)

    class CreateChannelInput(BaseModel):
        channel: str = Field(description="Channel name (org/namespace/service)")

    class InviteInput(BaseModel):
        channel: str = Field(description="Channel name (org/namespace/service)")
        max_uses: int = Field(default=1, description="How many times the token can be used")
        ttl: int = Field(default=3600, description="Token lifetime in seconds")

    class JoinInput(BaseModel):
        channel: str = Field(description="Channel name (org/namespace/service)")
        token: str = Field(description="Invite token (skt_inv_...) from the channel owner")

    class SkytaleCreateChannelTool(BaseTool):
        name: str = "skytale_create_channel"
        description: str = (
            "Create a new MLS-encrypted Skytale channel and start "
            "listening for messages."
        )
        args_schema: type[BaseModel] = CreateChannelInput

        def _run(self, channel: str) -> str:
            manager.create(channel)
            return f"Channel {channel} created"

    class SkytaleInviteTool(BaseTool):
        name: str = "skytale_invite"
        description: str = (
            "Create an invite token for a Skytale channel. Share the "
            "token with another agent so they can join."
        )
        args_schema: type[BaseModel] = InviteInput

        def _run(self, channel: str, max_uses: int = 1, ttl: int = 3600) -> str:
            token = manager.invite(channel, max_uses=max_uses, ttl=ttl)
            return f"Invite token for {channel}: {token}"

    class SkytaleJoinTool(BaseTool):
        name: str = "skytale_join"
        description: str = (
            "Join a Skytale channel using an invite token. The MLS key "
            "exchange happens automatically."
        )
        args_schema: type[BaseModel] = JoinInput

        def _run(self, channel: str, token: str) -> str:
            manager.join_with_token(channel, token)
            return f"Joined channel {channel}"

    return [
        SkytaleSendTool(),
        SkytaleReceiveTool(),
        SkytaleChannelsTool(),
        SkytaleCreateChannelTool(),
        SkytaleInviteTool(),
        SkytaleJoinTool(),
    ]
