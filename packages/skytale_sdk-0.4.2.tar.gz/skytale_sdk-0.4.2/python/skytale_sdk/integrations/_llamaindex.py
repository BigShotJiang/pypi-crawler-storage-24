"""LlamaIndex integration: expose Skytale encrypted channels as LlamaIndex tools.

Usage::

    from skytale_sdk.integrations import _llamaindex as skytale_li

    mgr = skytale_li.create_manager(identity=b"my-agent")
    mgr.create("org/ns/chan")
    agent = AgentWorkflow.from_tools_or_functions(skytale_li.tools(mgr), llm=llm)
"""

from __future__ import annotations

from typing import Optional

from skytale_sdk.channels import SkytaleChannelManager


def create_manager(**kwargs) -> SkytaleChannelManager:
    """Create a ``SkytaleChannelManager`` with the given options.

    Accepts the same keyword arguments as ``SkytaleChannelManager``.

    Returns:
        A configured channel manager.
    """
    return SkytaleChannelManager(**kwargs)


def tools(manager: SkytaleChannelManager) -> list:
    """Return LlamaIndex-compatible tools bound to *manager*.

    Requires ``llama-index-core>=0.11.0``. Install with::

        pip install skytale-sdk[llamaindex]

    Args:
        manager: A ``SkytaleChannelManager`` managing the channels.

    Returns:
        List of six ``FunctionTool`` instances:
        ``skytale_send``, ``skytale_receive``, ``skytale_channels``,
        ``skytale_create_channel``, ``skytale_invite``, ``skytale_join``.
    """
    from llama_index.core.tools import FunctionTool

    def skytale_send(channel: str, message: str) -> str:
        """Send an encrypted message to an AI agent channel.

        Use this tool to send a message to other agents listening on the
        specified Skytale encrypted channel. Messages are end-to-end
        encrypted using the MLS protocol.

        Args:
            channel: Channel name in org/namespace/service format
                (e.g. "acme/research/results").
            message: The message text to send.
        """
        manager.send(channel, message)
        return f"Message sent to {channel}"

    def skytale_receive(channel: str, timeout: Optional[float] = 5.0) -> str:
        """Receive encrypted messages from an AI agent channel.

        Use this tool to check for new messages on the specified Skytale
        encrypted channel. Returns all messages received since the last
        check, or waits up to *timeout* seconds for new ones.

        Args:
            channel: Channel name in org/namespace/service format.
            timeout: Seconds to wait for messages (default 5).
        """
        msgs = manager.receive(channel, timeout=timeout or 5.0)
        if not msgs:
            return f"No new messages on {channel}"
        return "\n".join(f"[{channel}] {m}" for m in msgs)

    def skytale_channels() -> str:
        """List all active Skytale encrypted channels.

        Returns the names of channels this agent has created or joined.
        """
        channels = manager.list_channels()
        if not channels:
            return "No active channels"
        return ", ".join(channels)

    def skytale_create_channel(channel: str) -> str:
        """Create a new encrypted Skytale channel.

        Creates an MLS-encrypted channel and starts listening for messages.

        Args:
            channel: Channel name in org/namespace/service format
                (e.g. "acme/research/results").
        """
        manager.create(channel)
        return f"Channel {channel} created"

    def skytale_invite(channel: str, max_uses: int = 1, ttl: int = 3600) -> str:
        """Create an invite token for a Skytale channel.

        The returned token can be shared with another agent who calls
        skytale_join to join the channel.

        Args:
            channel: Channel name in org/namespace/service format.
            max_uses: How many times the token can be used (default 1).
            ttl: Token lifetime in seconds (default 3600).
        """
        token = manager.invite(channel, max_uses=max_uses, ttl=ttl)
        return f"Invite token for {channel}: {token}"

    def skytale_join(channel: str, token: str) -> str:
        """Join a Skytale channel using an invite token.

        Uses the invite token to join the channel. The MLS key exchange
        happens automatically through the API server.

        Args:
            channel: Channel name in org/namespace/service format.
            token: Invite token (skt_inv_...) from the channel owner.
        """
        manager.join_with_token(channel, token)
        return f"Joined channel {channel}"

    return [
        FunctionTool.from_defaults(skytale_send, name="skytale_send", description="Send an encrypted message to an AI agent channel."),
        FunctionTool.from_defaults(skytale_receive, name="skytale_receive", description="Receive encrypted messages from an AI agent channel."),
        FunctionTool.from_defaults(skytale_channels, name="skytale_channels", description="List all active Skytale encrypted channels."),
        FunctionTool.from_defaults(skytale_create_channel, name="skytale_create_channel", description="Create a new encrypted Skytale channel."),
        FunctionTool.from_defaults(skytale_invite, name="skytale_invite", description="Create an invite token for a Skytale channel."),
        FunctionTool.from_defaults(skytale_join, name="skytale_join", description="Join a Skytale channel using an invite token."),
    ]
