"""AWS Strands Agents integration: expose Skytale channels as Strands tools.

Usage::

    from skytale_sdk.integrations import _strands as skytale_st

    mgr = skytale_st.create_manager(identity=b"my-agent")
    mgr.create("org/ns/chan")
    agent = Agent(tools=skytale_st.tools(mgr))
"""

from __future__ import annotations

from skytale_sdk.channels import SkytaleChannelManager


def create_manager(**kwargs) -> SkytaleChannelManager:
    """Create a ``SkytaleChannelManager`` with the given options.

    Accepts the same keyword arguments as ``SkytaleChannelManager``.

    Returns:
        A configured channel manager.
    """
    return SkytaleChannelManager(**kwargs)


def tools(manager: SkytaleChannelManager) -> list:
    """Return Strands Agents tools bound to *manager*.

    Requires ``strands-agents>=0.1.0``. Install with::

        pip install skytale-sdk[strands]

    Args:
        manager: A ``SkytaleChannelManager`` managing the channels.

    Returns:
        List of six ``@tool``-decorated functions:
        ``skytale_send``, ``skytale_receive``, ``skytale_channels``,
        ``skytale_create_channel``, ``skytale_invite``, ``skytale_join``.
    """
    from strands import tool

    @tool
    def skytale_send(channel: str, message: str) -> str:
        """Send an encrypted message to a Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
            message: Message text to send.
        """
        manager.send(channel, message)
        return f"Message sent to {channel}"

    @tool
    def skytale_receive(channel: str, timeout: float = 5.0) -> str:
        """Receive encrypted messages from a Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
            timeout: Seconds to wait for messages (default 5).
        """
        msgs = manager.receive(channel, timeout=timeout)
        if not msgs:
            return f"No new messages on {channel}"
        return "\n".join(f"[{channel}] {m}" for m in msgs)

    @tool
    def skytale_channels() -> str:
        """List all active Skytale encrypted channels."""
        channels = manager.list_channels()
        if not channels:
            return "No active channels"
        return ", ".join(channels)

    @tool
    def skytale_create_channel(channel: str) -> str:
        """Create a new encrypted Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
        """
        manager.create(channel)
        return f"Channel {channel} created"

    @tool
    def skytale_invite(channel: str, max_uses: int = 1, ttl: int = 3600) -> str:
        """Create an invite token for a Skytale channel.

        Args:
            channel: Channel name in org/namespace/service format.
            max_uses: How many times the token can be used (default 1).
            ttl: Token lifetime in seconds (default 3600).
        """
        token = manager.invite(channel, max_uses=max_uses, ttl=ttl)
        return f"Invite token for {channel}: {token}"

    @tool
    def skytale_join(channel: str, token: str) -> str:
        """Join a Skytale channel using an invite token.

        Args:
            channel: Channel name in org/namespace/service format.
            token: Invite token (skt_inv_...) from the channel owner.
        """
        manager.join_with_token(channel, token)
        return f"Joined channel {channel}"

    return [
        skytale_send,
        skytale_receive,
        skytale_channels,
        skytale_create_channel,
        skytale_invite,
        skytale_join,
    ]
