"""Agno integration: expose Skytale channels as an Agno toolkit.

Usage::

    from skytale_sdk.integrations import _agno as skytale_agno

    mgr = skytale_agno.create_manager(identity=b"my-agent")
    mgr.create("org/ns/chan")
    agent = Agent(model=OpenAIChat(id="gpt-4.1"),
                  tools=[skytale_agno.toolkit(mgr)])
"""

from __future__ import annotations

from skytale_sdk.channels import SkytaleChannelManager


def create_manager(**kwargs) -> SkytaleChannelManager:
    """Create a ``SkytaleChannelManager`` with the given options.

    Accepts the same keyword arguments as ``SkytaleChannelManager``.

    Returns:
        A configured channel manager.
    """
    return SkytaleChannelManager(**kwargs)


def toolkit(manager: SkytaleChannelManager):
    """Return an Agno ``Toolkit`` bound to *manager*.

    Requires ``agno>=1.0.0``. Install with::

        pip install skytale-sdk[agno]

    Args:
        manager: A ``SkytaleChannelManager`` managing the channels.

    Returns:
        A ``SkytaleToolkit`` instance with ``send``, ``receive``,
        ``channels``, ``create_channel``, ``invite``, and ``join``
        methods registered as tools.
    """
    from agno.tools import Toolkit

    class SkytaleToolkit(Toolkit):
        def __init__(self):
            super().__init__(name="skytale")
            self._manager = manager
            self.register(self.send)
            self.register(self.receive)
            self.register(self.channels)
            self.register(self.create_channel)
            self.register(self.invite)
            self.register(self.join)

        def send(self, channel: str, message: str) -> str:
            """Send an encrypted message to a Skytale channel.

            Args:
                channel: Channel name in org/namespace/service format.
                message: Message text to send.
            """
            self._manager.send(channel, message)
            return f"Message sent to {channel}"

        def receive(self, channel: str, timeout: float = 5.0) -> str:
            """Receive encrypted messages from a Skytale channel.

            Args:
                channel: Channel name in org/namespace/service format.
                timeout: Seconds to wait for messages (default 5).
            """
            msgs = self._manager.receive(channel, timeout=timeout or 5.0)
            if not msgs:
                return f"No new messages on {channel}"
            return "\n".join(f"[{channel}] {m}" for m in msgs)

        def channels(self) -> str:
            """List all active Skytale encrypted channels."""
            chs = self._manager.list_channels()
            if not chs:
                return "No active channels"
            return ", ".join(chs)

        def create_channel(self, channel: str) -> str:
            """Create a new encrypted Skytale channel.

            Args:
                channel: Channel name in org/namespace/service format.
            """
            self._manager.create(channel)
            return f"Channel {channel} created"

        def invite(self, channel: str, max_uses: int = 1, ttl: int = 3600) -> str:
            """Create an invite token for a Skytale channel.

            Args:
                channel: Channel name in org/namespace/service format.
                max_uses: How many times the token can be used (default 1).
                ttl: Token lifetime in seconds (default 3600).
            """
            token = self._manager.invite(channel, max_uses=max_uses, ttl=ttl)
            return f"Invite token for {channel}: {token}"

        def join(self, channel: str, token: str) -> str:
            """Join a Skytale channel using an invite token.

            Args:
                channel: Channel name in org/namespace/service format.
                token: Invite token (skt_inv_...) from the channel owner.
            """
            self._manager.join_with_token(channel, token)
            return f"Joined channel {channel}"

    return SkytaleToolkit()
