use ndarray::{Array1, Array2};
use ndarray_linalg::UPLO;
use ndarray_linalg::{Cholesky, Inverse, Solve};
use sprs::{CsMat, TriMat};

/// Represents the resolved analytical outputs from evaluating a fully optimized variance structure.
#[derive(Debug, Clone)]
pub struct ModelCoefficients {
    /// The REML criterion at convergence (-2 log restricted-likelihood).
    pub reml_crit: f64,
    /// The estimated residual variance (σ²).
    pub sigma2: f64,
    /// The estimated fixed-effect coefficients (β).
    pub beta: Array1<f64>,
    /// The conditional modes of the random effects (b).
    pub b: Array1<f64>,
    /// The spherical random effects (u).
    pub u: Array1<f64>,
    /// Standard errors of the fixed-effect coefficients.
    pub beta_se: Array1<f64>,
    /// t-statistics for the fixed-effect coefficients.
    pub beta_t: Array1<f64>,
    /// The fitted conditional values (Xβ + Zb).
    pub fitted: Array1<f64>,
    /// The unscaled conditional residuals (y - Xβ - Zb).
    pub residuals: Array1<f64>,
    /// The Cholesky factor of the unscaled fixed-effects variance matrix (L_x).
    pub l_x: Array2<f64>,
    /// The unscaled variance-covariance matrix of the fixed effects.
    pub v_beta_unscaled: Array2<f64>,
}

/// Encapsulates the core dense/sparse design matrices for Linear Mixed-Effects modeling evaluations.
///
/// Supports optional prior observation weights via `weights`. When provided, all
/// cross-products are pre-computed as weighted versions (X'WX, X'Wy, Z'WZ, Z'Wy).
pub struct LmmData {
    /// Dense fixed-effects design matrix ($X$).
    pub x: Array2<f64>,
    /// Sparse transposed random-effects design matrix ($Z^T$).
    pub zt: CsMat<f64>,
    /// Dependent variable vector ($y$).
    pub y: Array1<f64>,
    /// Collection of random effect dimensional tracking blocks.
    pub re_blocks: Vec<crate::model_matrix::ReBlock>,
    /// Optional prior observation weights (length n).
    pub weights: Option<Array1<f64>>,

    // Cached effective matrices that are independent of theta
    // When weights are present, these are the weighted versions.
    /// Effective Dense fixed-effects design matrix ($X$), optionally scaled by observation weights.
    pub x_eff: Array2<f64>,
    /// Effective Sparse transposed random-effects design matrix ($Z^T$), optionally scaled by observation weights.
    pub zt_eff: CsMat<f64>,
    /// Effective Dependent variable vector ($y$), optionally scaled by observation weights.
    pub y_eff: Array1<f64>,
    /// Cross product of the transposed design matrix ($Z^T Z$). This is `zt_eff * zt_eff^T`.
    pub zt_z: CsMat<f64>,
    /// Cross product of the fixed-effects design matrix ($X^T X$). This is `x_eff^T * x_eff`.
    pub xt_x: Array2<f64>,
    /// Cross product of the fixed-effects design matrix and the dependent variable ($X^T y$). This is `x_eff^T * y_eff`.
    pub xt_y: Array1<f64>,
}

impl LmmData {
    /// Create `LmmData` containing unweighted structural design matrices.
    pub fn new(
        x: Array2<f64>,
        zt: CsMat<f64>,
        y: Array1<f64>,
        re_blocks: Vec<crate::model_matrix::ReBlock>,
    ) -> Self {
        Self::new_weighted(x, zt, y, re_blocks, None)
    }

    /// Create LmmData with optional observation weights.
    ///
    /// When `weights` is Some, cross-products are computed as X'WX, X'Wy, Z'WZ, Z'Wy
    /// where W = diag(weights). This is equivalent to scaling rows by sqrt(w).
    pub fn new_weighted(
        x: Array2<f64>,
        zt: CsMat<f64>,
        y: Array1<f64>,
        re_blocks: Vec<crate::model_matrix::ReBlock>,
        weights: Option<Array1<f64>>,
    ) -> Self {
        match &weights {
            Some(w) => {
                // Weighted cross-products: scale X and y by sqrt(w)
                let sqrt_w = w.mapv(|wi| wi.sqrt());
                let n = x.nrows();
                let p = x.ncols();

                // X_w = diag(sqrt_w) * X
                let mut x_w = Array2::<f64>::zeros((n, p));
                for i in 0..n {
                    for j in 0..p {
                        x_w[[i, j]] = x[[i, j]] * sqrt_w[i];
                    }
                }
                let y_w = &y * &sqrt_w;

                // Z_w^T = Z^T * diag(sqrt_w), which means scaling columns of Zt
                let zt_w = weight_sparse_cols(&zt, &sqrt_w);

                let zt_z = &zt_w * &zt_w.transpose_view();
                let xt_x = x_w.t().dot(&x_w);
                let xt_y = x_w.t().dot(&y_w);

                LmmData {
                    x,
                    zt,
                    y,
                    re_blocks,
                    weights,
                    x_eff: x_w,
                    zt_eff: zt_w,
                    y_eff: y_w,
                    zt_z,
                    xt_x,
                    xt_y,
                }
            }
            None => {
                let zt_z = &zt * &zt.transpose_view();
                let xt_x = x.t().dot(&x);
                let xt_y = x.t().dot(&y);

                LmmData {
                    x_eff: x.clone(),
                    zt_eff: zt.clone(),
                    y_eff: y.clone(),
                    x,
                    zt,
                    y,
                    re_blocks,
                    weights,
                    zt_z,
                    xt_x,
                    xt_y,
                }
            }
        }
    }

    /// Evaluate the objective reml (or deviance) for a fixed parameter set of variances `theta`.
    pub fn log_reml_deviance(&self, theta: &[f64], reml: bool) -> f64 {
        self.evaluate(theta, reml).reml_crit
    }

    /// Computes the complete profiled analytical output for a specific parameter vector `theta`,
    /// including coefficient values (fixed β, random $u$/$b$), deviance limits and scaling components.
    pub fn evaluate(&self, theta: &[f64], reml: bool) -> ModelCoefficients {
        let n = self.y.len() as f64;
        let p = self.x.ncols() as f64;
        let q = self.zt.rows();

        // When weights are present, we work with the weighted versions of Z^T
        // When weights are present, we work with the weighted versions of Z^T
        // and X which have been precalculated and stored in the struct.
        let zt_eff = &self.zt_eff;
        let x_eff = &self.x_eff;
        let y_eff = &self.y_eff;

        let mut lam_tri = TriMat::new((q, q));

        let mut row_offset = 0;
        let mut theta_offset = 0;

        for block in &self.re_blocks {
            let m = block.m;
            let k = block.k;

            for group in 0..m {
                let offset = row_offset + group * k;
                let mut idx = 0;
                for j in 0..k {
                    for i in j..k {
                        lam_tri.add_triplet(offset + i, offset + j, theta[theta_offset + idx]);
                        idx += 1;
                    }
                }
            }
            row_offset += m * k;
            theta_offset += block.theta_len;
        }
        let lambda: CsMat<f64> = lam_tri.to_csr();

        // A = Lambda^T Z^T W Z Lambda + I (using pre-weighted Zt)
        // Since zt_z = zt_eff * zt_eff^T is constant w.r.t theta, we use the precomputed self.zt_z
        let lam_t = lambda.transpose_view();
        let a_part1 = &lam_t * &self.zt_z;
        let a_part2 = &a_part1 * &lambda;

        let mut eye_tri = TriMat::new((q, q));
        for i in 0..q {
            eye_tri.add_triplet(i, i, 1.0);
        }
        let eye: CsMat<f64> = eye_tri.to_csr();
        let a = &a_part2 + &eye;

        // LDLT of A
        use sprs::SymmetryCheck;
        use sprs_ldl::Ldl;
        let ldl = Ldl::new()
            .check_symmetry(SymmetryCheck::DontCheckSymmetry)
            .numeric(a.view())
            .expect("LDLT of A failed");

        // V_y = Lambda^T Z_w^T y_w
        // zt_eff is CsMat, y_eff is Array1
        let mut zt_y = Array1::<f64>::zeros(q);
        for (val, (i, _j)) in zt_eff.iter() {
            zt_y[i] += val * y_eff[_j]; // Note: Zt is q x n, so iter gives (val, (row_in_Zt, col_in_Zt)). col_in_Zt corresponds to observation index in y
        }

        let mut v_y = Array1::<f64>::zeros(q);
        for (val, (i, _j)) in lam_t.iter() {
            // lam_t is q x q
            v_y[i] += val * zt_y[_j];
        }

        let w_y_vec: Vec<f64> = ldl.solve(v_y.to_vec());
        let w_y = Array1::from_vec(w_y_vec);

        // V = Lambda^T Z_w^T X_w
        let p_usize = p as usize;
        let mut v_cols = Vec::with_capacity(p_usize);
        let mut w_cols = Vec::with_capacity(p_usize);

        for j in 0..p_usize {
            let x_col = x_eff.column(j);
            let mut zt_x_j = Array1::<f64>::zeros(q);
            for (val, (row, col)) in zt_eff.iter() {
                zt_x_j[row] += val * x_col[col];
            }

            let mut v_j = Array1::<f64>::zeros(q);
            for (val, (row, col)) in lam_t.iter() {
                v_j[row] += val * zt_x_j[col];
            }

            let w_j_vec: Vec<f64> = ldl.solve(v_j.to_vec());
            let w_j = Array1::from_vec(w_j_vec);

            v_cols.push(v_j);
            w_cols.push(w_j);
        }

        let mut rzx_t_rzx = Array2::<f64>::zeros((p_usize, p_usize));
        for i in 0..p_usize {
            for j in 0..p_usize {
                let dot = v_cols[i].dot(&w_cols[j]);
                rzx_t_rzx[[i, j]] = dot;
            }
        }

        let mut rzx_t_cu = Array1::<f64>::zeros(p_usize);
        for i in 0..p_usize {
            let dot = v_cols[i].dot(&w_y);
            rzx_t_cu[i] = dot;
        }

        let a_x = &self.xt_x - &rzx_t_rzx;
        let l_x = a_x.cholesky(UPLO::Lower).expect("Cholesky of A_x failed");

        let rhs_beta = &self.xt_y - &rzx_t_cu;

        let c_beta = l_x.solve(&rhs_beta).expect("Solve for c_beta failed");
        let beta = l_x.t().solve(&c_beta).expect("Solve for beta failed");

        // Compute norms
        let y_norm2: f64 = y_eff.iter().map(|&x| x * x).sum();

        let mut cu_norm2 = 0.0;
        for i in 0..v_y.len() {
            cu_norm2 += v_y[i] * w_y[i];
        }

        let mut c_beta_norm2 = 0.0;
        for i in 0..beta.len() {
            c_beta_norm2 += beta[i] * rhs_beta[i];
        }

        let r2 = y_norm2 - cu_norm2 - c_beta_norm2;

        let reml_df = if reml { n - p } else { n };
        let sigma2 = r2 / reml_df;

        let mut log_det_a = 0.0;
        for &d in ldl.d() {
            log_det_a += d.ln();
        }

        let mut log_det_l_x = 0.0;
        for i in 0..l_x.nrows() {
            log_det_l_x += l_x[[i, i]].ln();
        }

        let twopi = std::f64::consts::PI * 2.0;
        let mut deviance = reml_df * (twopi * sigma2).ln() + log_det_a + reml_df;

        if reml {
            deviance += 2.0 * log_det_l_x;
        }

        let reml_crit = deviance;

        let mut u = Array1::<f64>::zeros(q);
        for i in 0..q {
            let mut w_beta_i = 0.0;
            for j in 0..p_usize {
                w_beta_i += w_cols[j][i] * beta[j];
            }
            u[i] = w_y[i] - w_beta_i;
        }
        let mut b = Array1::<f64>::zeros(q);
        for (val, (row, col)) in lambda.iter() {
            b[row] += val * u[col];
        }

        // Standard Errors for Fixed Effects
        let mut beta_se = Array1::<f64>::zeros(p_usize);
        let mut beta_t = Array1::<f64>::zeros(p_usize);

        let inv_lx = l_x.inv().expect("Inverse of L_x failed");
        let v_beta_unscaled = inv_lx.t().dot(&inv_lx);

        for i in 0..p_usize {
            let var_i = sigma2 * v_beta_unscaled[[i, i]];
            beta_se[i] = var_i.sqrt();
            beta_t[i] = beta[i] / beta_se[i];
        }

        // Fitted Values and Residuals (on original unweighted scale)
        let x_beta = self.x.dot(&beta);
        let n_obs = self.y.len();
        let mut z_b_vec = vec![0.0f64; n_obs];
        for (j, row_vec) in self.zt.outer_iterator().enumerate() {
            for (i, &val) in row_vec.iter() {
                z_b_vec[i] += val * b[j];
            }
        }
        let z_b = Array1::from_vec(z_b_vec);
        let fitted = &x_beta + &z_b;
        let residuals = &self.y - &fitted;

        ModelCoefficients {
            reml_crit,
            sigma2,
            beta,
            b,
            u,
            beta_se,
            beta_t,
            fitted,
            residuals,
            l_x,
            v_beta_unscaled,
        }
    }
}

/// Multiply each column i of a sparse CSR matrix (q×n) by scale[i].
fn weight_sparse_cols(sp: &CsMat<f64>, scale: &Array1<f64>) -> CsMat<f64> {
    let (rows, cols) = sp.shape();
    let mut tri = TriMat::new((rows, cols));
    for (row_idx, row_vec) in sp.outer_iterator().enumerate() {
        for (col_idx, &val) in row_vec.iter() {
            tri.add_triplet(row_idx, col_idx, val * scale[col_idx]);
        }
    }
    tri.to_csr()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model_matrix::ReBlock;
    use ndarray::array;
    use sprs::TriMat;

    #[test]
    fn test_weighted_lmm_evaluation() {
        let x = array![[1.0, 2.0], [1.0, 3.0], [1.0, 4.0]];

        let mut zt_tri = TriMat::new((3, 3));
        for i in 0..3 {
            zt_tri.add_triplet(i, i, 1.0);
        }
        let zt = zt_tri.to_csr();

        let y = array![2.0, 4.0, 6.0];

        let re_blocks = vec![ReBlock {
            m: 3,
            k: 1,
            theta_len: 1,
            group_name: "G".to_string(),
            effect_names: vec!["(Intercept)".to_string()],
            group_map: std::collections::HashMap::new(),
        }];

        let weights = array![0.5, 1.0, 2.0];

        let lmm_weighted = LmmData::new_weighted(
            x.clone(),
            zt.clone(),
            y.clone(),
            re_blocks.clone(),
            Some(weights),
        );
        let theta = vec![1.0];
        let coefs = lmm_weighted.evaluate(&theta, true);

        assert_eq!(coefs.beta.len(), 2);
        assert_eq!(coefs.b.len(), 3);
        assert!(coefs.sigma2 > -1e-10);
    }
}
