pyinfra is a Python CLI / API to configure anything with a shell (server via ssh, docker container, local machine) using idempotent operations (template file /X, create database Y, install package Z).

Use:

- use `uv` for all commands, ie `uv run pyinfra ...`, `uv run pytest ...`
- always run `scripts/dev-format.sh` after making batches of changes
