---
name: generatechangelog
---

Generate pyinfra changelog for release:

- get previous v3.x tag
- use github mcp to pull commit messages, and github usernames
- generate changelog in a similar format to CHANGELOG.md (grab the first ~100 lines to get an idea)
- ask human overlord to confirm then prepend it to CHANGELOG.md
