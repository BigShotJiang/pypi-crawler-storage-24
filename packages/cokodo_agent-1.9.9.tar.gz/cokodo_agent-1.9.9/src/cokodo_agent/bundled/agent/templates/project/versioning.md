# Versioning (cokodo-agent / protocol)

> **Project info**: How CLI and bundled protocol versions are defined. **Do not hardcode** `3.2.x` in cokodo-agent code — use `cokodo_agent.config` only.

## Single source

| What | Where |
|------|--------|
| CLI package version (`co version` first line) | PyPI metadata → `config.VERSION` |
| Built-in protocol version (`co version` → Built-in) | `bundled/agent/manifest.json` `"version"` at import → `config.BUNDLED_PROTOCOL_VERSION` |
| Lint banner / scripts | `config.PROTOCOL_COMPLIANCE_BANNER` |

## For maintainers

1. Bump **protocol** → edit **`bundled/agent/manifest.json`** `version` (optional: `config._FALLBACK_PROTOCOL_VERSION` if manifest may be missing).
2. Bump **CLI** → `pyproject.toml` + `__init__.py` per release SOP.
3. In Python code → `from cokodo_agent.config import BUNDLED_PROTOCOL_VERSION, PROTOCOL_COMPLIANCE_BANNER, VERSION`.

## Longer doc

See repository **`docs/protocol-version-config.md`** (Chinese + tables) for full detail.

---

*Template seeded by `co init` / `co scaffold`; safe to customize for your team.*
