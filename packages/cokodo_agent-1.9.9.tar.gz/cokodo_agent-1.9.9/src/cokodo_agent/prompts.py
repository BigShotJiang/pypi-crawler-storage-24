"""Interactive prompts for configuration."""

from typing import Any, Dict, List, Optional, cast

import questionary
from questionary import Style

from cokodo_agent.config import AI_TOOLS, TECH_STACKS

# Custom style
custom_style = Style(
    [
        ("qmark", "fg:cyan bold"),
        ("question", "bold"),
        ("answer", "fg:cyan"),
        ("pointer", "fg:cyan bold"),
        ("highlighted", "fg:cyan bold"),
        ("selected", "fg:green"),
    ]
)


def prompt_config(
    default_name: Optional[str] = None,
    default_stack: Optional[str] = None,
    default_tools: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Interactive prompts for project configuration.

    Args:
        default_name: Default project name
        default_stack: Default tech stack
        default_tools: Pre-selected tool keys (e.g. from --tools flag).
                       When provided, these tools are pre-checked in addition
                       to (or instead of) the built-in defaults.

    Returns:
        Configuration dictionary
    """

    # Project name
    project_name = questionary.text(
        "Project name:",
        default=default_name or "",
        style=custom_style,
    ).ask()

    if project_name is None:
        raise KeyboardInterrupt("User cancelled")

    # Description
    description = questionary.text(
        "Brief description (optional):",
        default="",
        style=custom_style,
    ).ask()

    if description is None:
        raise KeyboardInterrupt("User cancelled")

    # Tech stack
    stack_choices = [questionary.Choice(title=name, value=key) for key, name in TECH_STACKS.items()]

    default_stack_value = default_stack if default_stack in TECH_STACKS else None

    tech_stack = questionary.select(
        "Primary tech stack:",
        choices=stack_choices,
        default=default_stack_value,
        style=custom_style,
    ).ask()

    if tech_stack is None:
        raise KeyboardInterrupt("User cancelled")

    # Determine which tools are pre-checked.
    # If the caller passed explicit defaults, use those; otherwise default to "cokodo".
    pre_checked: set[str]
    if default_tools is not None:
        pre_checked = set(default_tools)
    else:
        pre_checked = {"cokodo"}

    # AI tools
    tool_choices = [
        questionary.Choice(
            title=cast(str, info["name"]),
            value=key,
            checked=(key in pre_checked),
        )
        for key, info in AI_TOOLS.items()
    ]

    ai_tools = questionary.checkbox(
        "IDE adapters to generate (Space to toggle, Enter to confirm):",
        choices=tool_choices,
        style=custom_style,
        validate=lambda x: len(x) > 0 or "Please select at least one option",
    ).ask()

    if ai_tools is None:
        raise KeyboardInterrupt("User cancelled")

    # Ensure at least one is selected
    if not ai_tools:
        ai_tools = ["cokodo"]  # Fallback to cokodo

    return {
        "project_name": project_name,
        "description": description,
        "tech_stack": tech_stack,
        "ai_tools": ai_tools,
    }
