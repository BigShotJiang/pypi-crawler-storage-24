# 📁 AzerAI File Management Plugin

Azərbaycan dilində qabaqcıl səsli AI asistenti üçün fayl idarəetmə plugini.

## Xüsusiyyətlər

- 📂 **Fayl siyahısı** - Dizindəki faylları göstər
- 📁 **Qovluq yarat** - Yeni qovluqlar yaradın
- 🗑️ **Fayl sil** - Faylları silin
- 📊 **Fayl məlumatları** - Fayl haqqında detallı məlumat
- 🔍 **Fayl axtarışı** - Patternlə fayl axtarın
- 🎵 **Arxa plan musiqisi** - Əməliyyat zamanı D4 notası
- 🎤 **Mikrofon kontrolü** - Əməliyyat zamanı danışığı bloklayır

## Quraşdırma

```bash
pip install azerai-file-management
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"Desktop fayllarını göstər"` - Fayl siyahısı
- `"Yeni qovluq yarat"` - Qovluq yarat
- `"Fayl sil"` - Fayl sil
- `"Fayl məlumatları"` - Fayl haqqında məlumat
- `"Fayl axtar"` - Fayl axtar

## Fayl struktur

```
azerai_file_management/
├── plugins/
│   └── file_management/
│       ├── __init__.py
│       └── main.py
└── __init__.py
```

## Xüsusiyyətlər

### 📂 **Fayl Siyahısı**
- Dizindəki faylları və qovluqları siyahılayır
- Gizli faylları göstərmə seçimi
- Fayl ölçüsü və tipi məlumatları

### 📁 **Qovluq Yaratma**
- Yeni qovluqlar yaradır
- Alt qovluq strukturu dəstəyi
- Mövcud qovluqları yoxlayır

### 🗑️ **Fayl Silmə**
- Təhlükəsiz fayl silmə
- Sistemdən tamamilə çıxarır
 Saxlama məkanı azaldır

### 📊 **Fayl Məlumatları**
- Fayl ölçüsü
- Yaradılma tarixi
- Dəyişdirilmə tarixi
- Fayl tipi

### 🔍 **Fayl Axtarışı**
- Pattern axtarışı (wildcard dəstəyi)
- Geniş qovluq axtarışı
- Nəticə limiti

## Asılılıqlar

- `livekit-agents>=1.0.0` - AI agent framework
- `sounddevice>=0.4.6` - Audio çalma
- `scipy>=1.11.0` - Audio işləmə
- `numpy>=1.24.0` - Riyazi əməliyyatlar

## Lisenziya

MIT License
