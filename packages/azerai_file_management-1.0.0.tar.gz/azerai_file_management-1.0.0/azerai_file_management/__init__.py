"""
AzerAI File Management Plugin - Fayl idarəetmə plugini

Plugin əsaslı, çoxdilli AI asistenti üçün fayl idarəetmə modulu.
"""

__version__ = "1.0.0"
__author__ = "AzStudio Dev"
__email__ = "dev@azstudio.ai"

from .plugins.file_management.main import (
    list_files,
    create_directory,
    delete_file,
    get_file_info,
    search_files
)

__all__ = [
    "list_files",
    "create_directory",
    "delete_file",
    "get_file_info",
    "search_files"
]
