"""
AzerAI File Management Plugin - Plugin package
"""
