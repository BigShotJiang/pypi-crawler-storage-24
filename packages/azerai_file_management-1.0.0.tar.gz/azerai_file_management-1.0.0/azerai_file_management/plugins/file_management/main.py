import logging
import os
import subprocess
import threading
import time
import asyncio
import json
import shutil
from datetime import datetime
from pathlib import Path
from livekit.agents import RunContext, function_tool
import sounddevice as sd
import scipy.io.wavfile as wavfile
import numpy as np


def play_file_opener_music(stop_event):
    """
    Dosya işlemleri için stop_event ayarlanana kadar arka plan müziği çalar.
    """
    try:
        # Arka plan müziği için dizin ve dosya oluştur
        music_dir = Path("plugins/file_management/music")
        music_dir.mkdir(exist_ok=True)
        music_file = music_dir / "file_opener.wav"
        
        if not music_file.exists():
            # Dosya işlemleri için hoş bir sürekli ton oluştur
            sample_rate = 44100
            duration = 10.0  # Daha uzun sürekli çalma için 10 saniye
            frequency = 293  # D4 notası - produktiv, çalışma tonu
            
            t = np.linspace(0, duration, int(sample_rate * duration), False)
            # Hoş bir ses harmonikleri oluştur
            wave = 0.3 * np.sin(2 * np.pi * frequency * t) + \
                   0.1 * np.sin(2 * np.pi * frequency * 2 * t) + \
                   0.05 * np.sin(2 * np.pi * frequency * 3 * t)
            
            # Daha yumuşak yapmak için nazik zarf uygula ama tamamen solma
            envelope = 0.7 + 0.3 * np.sin(2 * np.pi * 0.5 * t)  # Gentle modulation
            wave = wave * envelope
            
            # WAV dosyası olarak kaydet
            wavfile.write(music_file, sample_rate, (wave * 32767).astype(np.int16))
        
        # Müzik dosyasını kesintisiz döngüde çal
        sample_rate, data = wavfile.read(str(music_file))
        
        while not stop_event.is_set():
            try:
                sd.play(data, sample_rate)
                # Sesin bitmesini bekle ama stop_event'i periyodik olarak kontrol et
                audio_duration = len(data) / sample_rate
                start_time = time.time()
                
                while time.time() - start_time < audio_duration:
                    if stop_event.is_set():
                        sd.stop()
                        return
                    time.sleep(0.1)  # Her 100ms'de bir kontrol et
                    
            except Exception as e:
                logging.error("Error playing background music: %s", e)
                break
                
    except ImportError:
        logging.warning("numpy not available for background music generation")
    except Exception as e:
        logging.error("Error in background music thread: %s", e)


@function_tool()
async def list_files(
    ctx: RunContext,  # type: ignore
    directory_path: str = ".",
    show_hidden: bool = False
) -> str:
    """
    Belirtilen dizindeki dosyaları listeler.
    
    Args:
        directory_path: Listelenecek dizin yolu
        show_hidden: Gizli dosyalar gösterilsin mi
    
    Returns:
        Dosya listesi
    """
    logger = logging.getLogger("file-management-plugin")
    
    try:
        logger.debug("=== FILE LIST START ===")
        
        if not os.path.exists(directory_path):
            return f"Dizin bulunamadı: {directory_path}"
        
        files = []
        directories = []
        
        for item in os.listdir(directory_path):
            if not show_hidden and item.startswith('.'):
                continue
                
            item_path = os.path.join(directory_path, item)
            if os.path.isdir(item_path):
                directories.append(f"📁 {item}/")
            else:
                size = os.path.getsize(item_path)
                files.append(f"📄 {item} ({size} bytes)")
        
        result = f"""📂 FILE LIST RESULTS

📁 Directory: {directory_path}
📊 Total items: {len(directories) + len(files)}
⏰ Query time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📁 Directories ({len(directories)}):
{chr(10).join(directories)}

📄 Files ({len(files)}):
{chr(10).join(files)}

✅ File list completed"""
        
        logger.info(f"File list completed: {directory_path}")
        return result
        
    except Exception as e:
        logger.error(f"Error listing files: {e}")
        return f"Dosya listesi alınamadı: {str(e)}"


@function_tool()
async def create_directory(
    ctx: RunContext,  # type: ignore
    directory_path: str
) -> str:
    """
    Yeni dizin oluşturur.
    
    Args:
        directory_path: Oluşturulacak dizin yolu
    
    Returns:
        Oluşturma sonucu
    """
    logger = logging.getLogger("file-management-plugin")
    
    try:
        logger.debug("=== DIRECTORY CREATE START: set_audio_enabled(False) called ===")
        ctx.session.input.set_audio_enabled(False)

        stop_music = threading.Event()
        music_thread = threading.Thread(
            target=play_file_opener_music, 
            args=(stop_music,),
            daemon=True
        )
        music_thread.start()
        
        try:
            logger.debug(f"=== DIRECTORY CREATE: Creating {directory_path} ===")
            
            result = await asyncio.to_thread(
                lambda: os.makedirs(directory_path, exist_ok=True)
            )
            
            result_text = f"""📁 DIRECTORY CREATE RESULTS

📂 Path: {directory_path}
✅ Status: Created successfully
🔧 Operation: Directory creation
📊 Information:
- Directory structure created
- Parent directories verified
- Path accessible
⏰ Operation time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""
            
            logger.debug(f"=== DIRECTORY CREATE COMPLETE ===")
            return result_text
            
        except Exception as e:
            logger.debug(f"=== DIRECTORY CREATE ERROR: {str(e)} ===")
            return f"Dizin oluşturma başarısız: {str(e)}"
        finally:
            stop_music.set()
            sd.stop()
            logger.debug("=== DIRECTORY CREATE FINALLY: set_audio_enabled(True) called ===")
            ctx.session.input.set_audio_enabled(True)
        
    except Exception as e:
        logging.error(f"Directory create error: {e}")
        return f"Dizin oluşturma hatası: {str(e)}"


@function_tool()
async def delete_file(
    ctx: RunContext,  # type: ignore
    file_path: str
) -> str:
    """
    Dosya siler.
    
    Args:
        file_path: Silinecek dosya yolu
    
    Returns:
        Silme sonucu
    """
    logger = logging.getLogger("file-management-plugin")
    
    try:
        logger.debug("=== FILE DELETE START: set_audio_enabled(False) called ===")
        ctx.session.input.set_audio_enabled(False)

        stop_music = threading.Event()
        music_thread = threading.Thread(
            target=play_file_opener_music, 
            args=(stop_music,),
            daemon=True
        )
        music_thread.start()
        
        try:
            logger.debug(f"=== FILE DELETE: Deleting {file_path} ===")
            
            if not os.path.exists(file_path):
                return f"Dosya bulunamadı: {file_path}"
            
            result = await asyncio.to_thread(
                lambda: os.remove(file_path)
            )
            
            result_text = f"""🗑️ FILE DELETE RESULTS

📄 File: {file_path}
✅ Status: Deleted successfully
🔧 Operation: File deletion
📊 Information:
- File removed from system
- Storage space freed
- Operation completed
⏰ Operation time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""
            
            logger.debug(f"=== FILE DELETE COMPLETE ===")
            return result_text
            
        except Exception as e:
            logger.debug(f"=== FILE DELETE ERROR: {str(e)} ===")
            return f"Dosya silme başarısız: {str(e)}"
        finally:
            stop_music.set()
            sd.stop()
            logger.debug("=== FILE DELETE FINALLY: set_audio_enabled(True) called ===")
            ctx.session.input.set_audio_enabled(True)
        
    except Exception as e:
        logging.error(f"File delete error: {e}")
        return f"Dosya silme hatası: {str(e)}"


@function_tool()
async def get_file_info(
    ctx: RunContext,  # type: ignore
    file_path: str
) -> str:
    """
    Dosya bilgilerini alır.
    
    Args:
        file_path: Bilgisi alınacak dosya yolu
    
    Returns:
        Dosya bilgileri
    """
    try:
        logger.debug(f"=== FILE INFO: Getting info for {file_path} ===")
        
        if not os.path.exists(file_path):
            return f"Dosya bulunamadı: {file_path}"
        
        stat = os.stat(file_path)
        path_obj = Path(file_path)
        
        size = stat.st_size
        modified = datetime.fromtimestamp(stat.st_mtime)
        created = datetime.fromtimestamp(stat.st_ctime)
        
        result = f"""📄 FILE INFORMATION

📂 File: {file_path}
📊 Size: {size} bytes
📅 Modified: {modified.strftime('%Y-%m-%d %H:%M:%S')}
📋 Created: {created.strftime('%Y-%m-%d %H:%M:%S')}
🏷️ Extension: {path_obj.suffix}
📁 Directory: {path_obj.parent}
⏰ Query time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

✅ File information retrieved"""
        
        logger.info(f"File info retrieved: {file_path}")
        return result
        
    except Exception as e:
        logger.error(f"Error getting file info: {e}")
        return f"Dosya bilgisi alınamadı: {str(e)}"


@function_tool()
async def search_files(
    ctx: RunContext,  # type: ignore
    pattern: str,
    search_path: str = ".",
    max_results: int = 50
) -> str:
    """
    Dosya araması yapar.
    
    Args:
        pattern: Aranacak desen (wildcard destekler)
        search_path: Arama yapılacak dizin
        max_results: Maksimum sonuç sayısı
    
    Returns:
        Arama sonuçları
    """
    logger = logging.getLogger("file-management-plugin")
    
    try:
        logger.debug("=== FILE SEARCH START: set_audio_enabled(False) called ===")
        ctx.session.input.set_audio_enabled(False)

        stop_music = threading.Event()
        music_thread = threading.Thread(
            target=play_file_opener_music, 
            args=(stop_music,),
            daemon=True
        )
        music_thread.start()
        
        try:
            logger.debug(f"=== FILE SEARCH: Searching {pattern} in {search_path} ===")
            
            import fnmatch
            
            matches = []
            
            for root, dirs, files in os.walk(search_path):
                for filename in files:
                    if fnmatch.fnmatch(filename.lower(), pattern.lower()):
                        full_path = os.path.join(root, filename)
                        matches.append(full_path)
                        
                        if len(matches) >= max_results:
                            break
                
                if len(matches) >= max_results:
                    break
            
            result_text = f"""🔍 FILE SEARCH RESULTS

🔍 Pattern: {pattern}
📁 Search path: {search_path}
📊 Results found: {len(matches)}
⏰ Search time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📄 Matching files:
{chr(10).join(matches[:max_results])}

✅ File search completed"""
            
            logger.debug(f"=== FILE SEARCH COMPLETE: {len(matches)} results ===")
            return result_text
            
        except Exception as e:
            logger.debug(f"=== FILE SEARCH ERROR: {str(e)} ===")
            return f"Dosya araması başarısız: {str(e)}"
        finally:
            stop_music.set()
            sd.stop()
            logger.debug("=== FILE SEARCH FINALLY: set_audio_enabled(True) called ===")
            ctx.session.input.set_audio_enabled(True)
        
    except Exception as e:
        logging.error(f"File search error: {e}")
        return f"Dosya arama hatası: {str(e)}"
