"""
HTML styling and display helpers for volumetrics tables.
"""

from __future__ import annotations

import re
from itertools import groupby as _groupby

import pandas as pd


class StyledHTML:
    """Wrapper so Jupyter renders raw HTML via _repr_html_."""

    def __init__(self, html: str):
        self._html = html

    def _repr_html_(self):
        return self._html


def run_label(pv, fallback: str = "?") -> str:
    """Build a consistent display label for a run."""
    return f"{pv.model} | {pv.grid} | {pv.metadata.get('date_raw', fallback)}"


def theme(dark: bool = False) -> dict[str, str]:
    """Return colour palette for light or dark mode."""
    if dark:
        return {
            "bg":        "#1b1b1b",
            "bg_header": "#242424",
            "fg":        "#e0e0e0",
            "fg_dim":    "#888888",
            "fg_accent": "#cccccc",
            "border":    "#333333",
            "sep":       "#555555",
            "stripe":    "#212121",
        }
    return {
        "bg":        "#ffffff",
        "bg_header": "#f0f3f8",
        "fg":        "#1e293b",
        "fg_dim":    "#64748b",
        "fg_accent": "#334155",
        "border":    "#cbd5e1",
        "sep":       "#334155",
        "stripe":    "#f8fafc",
    }


def streamlit_theme() -> dict[str, str]:
    """Return colour palette using Streamlit CSS variables.

    The returned values reference Streamlit's injected custom properties,
    so the table automatically matches whatever theme is active (light,
    dark, or custom) without needing explicit detection.
    """
    return {
        "bg":        "var(--background-color)",
        "bg_header": "var(--secondary-background-color)",
        "fg":        "var(--text-color)",
        "fg_dim":    "color-mix(in srgb, var(--text-color) 60%, transparent)",
        "fg_accent": "color-mix(in srgb, var(--text-color) 85%, transparent)",
        "border":    "color-mix(in srgb, var(--text-color) 15%, transparent)",
        "sep":       "color-mix(in srgb, var(--text-color) 30%, transparent)",
        "stripe":    "color-mix(in srgb, var(--secondary-background-color) 50%,"
                     " var(--background-color))",
    }


def insert_subtotals(df: pd.DataFrame) -> tuple[pd.DataFrame, set[int]]:
    """
    Insert subtotal rows at each group break in a MultiIndex DataFrame.
    Returns (new_df, set_of_sum_row_positions).
    """
    nlevels = df.index.nlevels
    ncols = len(df.columns)

    rows: list[tuple[tuple, list]] = []
    sum_positions: set[int] = set()

    orig = []
    for idx, vals in zip(df.index, df.values):
        orig.append((idx if isinstance(idx, tuple) else (idx,), list(vals)))

    def _emit_group(items: list, level: int):
        if level == nlevels - 1:
            for idx_tuple, vals in items:
                rows.append((idx_tuple, vals))
            return

        for _key, group_iter in _groupby(items, key=lambda x: x[0][level]):
            group = list(group_iter)
            _emit_group(group, level + 1)

            if len(group) > 1:
                sums = [0.0] * ncols
                for _, vals in group:
                    for j in range(ncols):
                        try:
                            sums[j] += float(vals[j])
                        except (ValueError, TypeError):
                            pass

                idx_parts = list(group[0][0])
                for k in range(level + 1, nlevels):
                    idx_parts[k] = "Sum" if k == level + 1 else ""
                sum_positions.add(len(rows))
                rows.append((tuple(idx_parts), sums))

    _emit_group(orig, 0)

    # Grand total row
    if len(orig) > 1:
        sums = [0.0] * ncols
        for _, vals in orig:
            for j in range(ncols):
                try:
                    sums[j] += float(vals[j])
                except (ValueError, TypeError):
                    pass
        idx_parts = ["Total"] + [""] * (nlevels - 1)
        sum_positions.add(len(rows))
        rows.append((tuple(idx_parts), sums))

    if rows:
        idx = pd.MultiIndex.from_tuples(
            [r[0] for r in rows], names=df.index.names
        )
        new_df = pd.DataFrame(
            [r[1] for r in rows], index=idx, columns=df.columns
        )
        return new_df, sum_positions
    return df, set()


def style_table(
    df: pd.DataFrame,
    fmt: str = "{:,.2f}",
    dark: bool = False,
    title: str = "",
    subtitle: str = "",
    subtotals: bool = False,
    streamlit: bool = False,
) -> StyledHTML:
    """
    Style a DataFrame for display with integrated header and theming.

    When *streamlit=True*, CSS variables from the Streamlit runtime are
    used so the table automatically follows the active theme.  The *dark*
    parameter is ignored in that case.
    """
    t = streamlit_theme() if streamlit else theme(dark)

    sum_row_indices: set[int] = set()
    if subtotals and isinstance(df.index, pd.MultiIndex) and df.index.nlevels >= 2:
        df, sum_row_indices = insert_subtotals(df)

    styles = [
        {"selector": "table", "props": [
            ("border-collapse", "collapse"),
            ("background-color", t["bg"]),
            ("color", t["fg"]),
            ("font-size", "14px"),
            ("width", "100%"),
            ("font-family", "'Segoe UI', system-ui, -apple-system, sans-serif"),
        ]},
        {"selector": "th", "props": [
            ("padding", "8px 14px"),
            ("background-color", t["bg_header"]),
            ("color", t["fg_dim"]),
            ("font-weight", "500"),
            ("font-size", "13px"),
            ("border-bottom", f"2px solid {t['border']}"),
            ("white-space", "nowrap"),
            ("text-align", "left"),
        ]},
        {"selector": "th.col_heading", "props": [
            ("text-align", "right"),
            ("min-width", "105px"),
        ]},
        {"selector": "td", "props": [
            ("padding", "6px 14px"),
            ("text-align", "right"),
            ("color", t["fg"]),
            ("min-width", "105px"),
            ("border-bottom", f"1px solid {t['border']}"),
        ]},
        {"selector": "th.row_heading", "props": [
            ("text-align", "left"),
            ("font-weight", "normal"),
            ("color", t["fg_dim"]),
            ("background-color", t["bg"]),
        ]},
        {"selector": "tbody tr:nth-child(even)", "props": [
            ("background-color", t["stripe"]),
        ]},
        {"selector": "tbody tr:nth-child(odd)", "props": [
            ("background-color", t["bg"]),
        ]},
    ]

    # Two-line metric column headers: label (accent) + dimmed unit
    _RE_COL_UNIT = re.compile(r"^(.+?)\s*\[(.+)\]$")
    col_rename = {}
    for col in df.columns:
        m = _RE_COL_UNIT.match(str(col))
        if m:
            label, unit = m.group(1).strip(), m.group(2).strip()
            col_rename[col] = (
                f'<span style="color:{t["fg_accent"]};'
                f'font-weight:600">{label}</span><br>'
                f'<span style="font-weight:400;color:{t["fg_dim"]};'
                f'font-size:12px">{unit}</span>'
            )
    if col_rename:
        df = df.rename(columns=col_rename)

    # Capture index level names for injection into header row
    idx_labels = []
    if isinstance(df.index, pd.MultiIndex):
        idx_labels = [str(n) if n else "" for n in df.index.names]
        df.index.names = [""] * df.index.nlevels
    elif df.index.name:
        idx_labels = [str(df.index.name)]
        df.index.name = ""

    styles.append({
        "selector": "thead tr:nth-child(2)",
        "props": [("display", "none")],
    })

    # Group separator borders for MultiIndex
    if isinstance(df.index, pd.MultiIndex) and df.index.nlevels >= 2:
        level0 = df.index.get_level_values(0)
        for i in range(1, len(level0)):
            if level0[i] != level0[i - 1]:
                if i not in sum_row_indices:
                    styles.append({
                        "selector": f"tbody tr:nth-child({i + 1})",
                        "props": [("border-top", f"2px solid {t['sep']}")],
                    })

    # Sum-row styling
    for ri in sum_row_indices:
        n = ri + 1
        styles.append({
            "selector": f"tbody tr:nth-child({n})",
            "props": [
                ("background-color", f"{t['bg_header']} !important"),
                ("border-top", f"1px solid {t['border']}"),
            ],
        })
        styles.append({
            "selector": f"tbody tr:nth-child({n}) td",
            "props": [
                ("font-style", "italic"),
                ("color", t["fg_accent"]),
            ],
        })
        styles.append({
            "selector": f"tbody tr:nth-child({n}) th.row_heading",
            "props": [
                ("font-style", "italic"),
                ("color", t["fg_accent"]),
                ("background-color", t["bg_header"]),
            ],
        })

    table_html = df.style.format(fmt).set_table_styles(styles).to_html()

    # Post-process: inject index labels into blank header cells
    if idx_labels:
        def _replace_blank(match):
            _replace_blank.idx += 1
            i = _replace_blank.idx - 1
            if i < len(idx_labels) and idx_labels[i]:
                lbl = idx_labels[i]
                return f'<th class="{match.group(1)}">{lbl}</th>'
            return match.group(0)

        _replace_blank.idx = 0
        html_parts = table_html.split("</tr>", 1)
        if len(html_parts) == 2:
            first_row = re.sub(
                r'<th class="(blank[^"]*)"[^>]*>\s*&nbsp;\s*</th>',
                _replace_blank,
                html_parts[0],
            )
            table_html = first_row + "</tr>" + html_parts[1]

    # Build integrated header + table wrapper
    header_html = ""
    if title or subtitle:
        header_html = (
            f'<div style="background:{t["bg_header"]};'
            f'padding:10px 14px;border-bottom:1px solid {t["border"]}">'
        )
        if title:
            header_html += (
                f'<div style="color:{t["fg"]};font-weight:600;'
                f'font-size:16px;font-family:\'Segoe UI\',system-ui,sans-serif">'
                f'{title}</div>'
            )
        if subtitle:
            header_html += (
                f'<div style="color:{t["fg_dim"]};font-size:12px;'
                f'margin-top:2px;font-family:\'Segoe UI\',system-ui,sans-serif">'
                f'{subtitle}</div>'
            )
        header_html += '</div>'

    wrapper = (
        f'<div style="display:inline-block;border:1px solid {t["border"]};'
        f'border-radius:6px;overflow:hidden;background:{t["bg"]}">'
        f'{header_html}{table_html}</div>'
    )

    return StyledHTML(wrapper)
