"""
Query engine: volumes, pivot, table, summary_table.

All functions operate on the unified flat detailed records.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .constants import VOLUME_COLS, resolve_metric, resolve_category, cat_to_df_col


# ---------------------------------------------------------------------------
# DataFrame construction
# ---------------------------------------------------------------------------

def build_detailed_df(data: dict) -> pd.DataFrame:
    """Build a DataFrame from the flat detailed records."""
    records = data.get("detailed", [])
    if not records:
        return pd.DataFrame()

    df = pd.DataFrame(records)
    for col in VOLUME_COLS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


def _apply_filter(df: pd.DataFrame, col: str, val) -> pd.DataFrame:
    """Filter a DataFrame column by a single value or list of values."""
    if val is None or col not in df.columns:
        return df
    if isinstance(val, str):
        return df[df[col] == val]
    if isinstance(val, (list, tuple)):
        return df[df[col].isin(val)]
    return df[df[col] == val]


# ---------------------------------------------------------------------------
# volumes()
# ---------------------------------------------------------------------------

def volumes(
    data: dict,
    metric: str | list[str] = "stoiip",
    by: str | list[str] | None = None,
    zone: str | list[str] | None = None,
    facies: str | list[str] | None = None,
    region: str | list[str] | None = None,
    case: str | list[str] | None = None,
    exclude_zero: bool = True,
) -> pd.DataFrame:
    """
    Flexible volume query on the flat detailed records.

    Parameters
    ----------
    metric : str or list[str]
    by : str or list[str], optional — group-by categories
    zone, facies, region, case : filters
    exclude_zero : bool
    """
    multi = isinstance(metric, list)
    metrics = metric if multi else [metric]
    cols = [resolve_metric(m) for m in metrics]

    df = build_detailed_df(data)
    if df.empty:
        if by is None:
            return pd.DataFrame(
                {col: [0] for col in cols}, index=["Total"]
            )
        return pd.DataFrame()

    # Apply filters
    df = _apply_filter(df, "zone", zone)
    df = _apply_filter(df, "facies", facies)
    df = _apply_filter(df, "region", region)
    df = _apply_filter(df, "case", case)

    if by is None:
        # Totals
        valid_cols = [c for c in cols if c in df.columns]
        totals = {c: [df[c].sum()] for c in valid_cols}
        return pd.DataFrame(totals, index=["Total"])

    if isinstance(by, str):
        by = [by]

    group_cols = []
    for b in by:
        cat = resolve_category(b)
        gc = cat_to_df_col(cat)
        if gc in df.columns:
            group_cols.append(gc)

    valid_cols = [c for c in cols if c in df.columns]
    if not group_cols or not valid_cols:
        return pd.DataFrame()

    result = df.groupby(group_cols, sort=False)[valid_cols].sum()
    if exclude_zero:
        result = result[(result != 0).any(axis=1)]
    return result


# ---------------------------------------------------------------------------
# pivot()
# ---------------------------------------------------------------------------

def pivot(
    data: dict,
    metric: str = "stoiip",
    rows: str = "zone",
    columns: str = "facies",
    zone: str | list[str] | None = None,
    facies: str | list[str] | None = None,
    region: str | list[str] | None = None,
    case: str | list[str] | None = None,
    margins: bool = True,
    exclude_zero_rows: bool = True,
    exclude_zero_cols: bool = True,
) -> pd.DataFrame:
    """Create a pivot table — ideal for presentations."""
    col = resolve_metric(metric)
    df = build_detailed_df(data)
    if df.empty:
        return pd.DataFrame()

    df = _apply_filter(df, "zone", zone)
    df = _apply_filter(df, "facies", facies)
    df = _apply_filter(df, "region", region)
    df = _apply_filter(df, "case", case)

    row_key = cat_to_df_col(resolve_category(rows))
    col_key = cat_to_df_col(resolve_category(columns))

    if row_key not in df.columns or col_key not in df.columns or col not in df.columns:
        raise ValueError("Required columns not found in detailed data.")

    pt = pd.pivot_table(
        df, values=col, index=row_key, columns=col_key,
        aggfunc="sum", fill_value=0,
        margins=margins, margins_name="Total",
    )

    if exclude_zero_cols:
        pt = pt.loc[:, (pt != 0).any(axis=0)]
    if exclude_zero_rows:
        mask = (pt != 0).any(axis=1)
        if "Total" in pt.index:
            mask.loc["Total"] = True
        pt = pt[mask]
    return pt


# ---------------------------------------------------------------------------
# table()
# ---------------------------------------------------------------------------

def table(
    data: dict,
    metric: str = "stoiip",
    by: list[str] | None = None,
    zone: str | list[str] | None = None,
    facies: str | list[str] | None = None,
    region: str | list[str] | None = None,
    case: str | list[str] | None = None,
    margins: bool = True,
    exclude_zero: bool = True,
    ordered_category_keys: list[str] | None = None,
) -> pd.DataFrame:
    """
    N-dimensional pivot table.

    Order of ``by`` controls layout:
    - All categories except last → row index (MultiIndex if 2+)
    - Last category → column headers
    """
    col = resolve_metric(metric)
    df = build_detailed_df(data)
    if df.empty:
        return pd.DataFrame()

    if by is None:
        by = list(ordered_category_keys or data.get("categories", {}).keys())
    if isinstance(by, str):
        by = [by]

    df = _apply_filter(df, "zone", zone)
    df = _apply_filter(df, "facies", facies)
    df = _apply_filter(df, "region", region)
    df = _apply_filter(df, "case", case)

    df_cols = []
    for b in by:
        cat = resolve_category(b)
        gc = cat_to_df_col(cat)
        if gc in df.columns:
            df_cols.append(gc)

    if not df_cols or col not in df.columns:
        return pd.DataFrame()

    if len(df_cols) == 1:
        pt = pd.pivot_table(
            df, values=col, columns=df_cols[0],
            aggfunc="sum", fill_value=0,
            margins=margins, margins_name="Total",
        )
    else:
        row_cols = df_cols[:-1]
        col_col = df_cols[-1]
        pt = pd.pivot_table(
            df, values=col,
            index=row_cols, columns=col_col,
            aggfunc="sum", fill_value=0,
            margins=margins, margins_name="Total",
        )

    if exclude_zero:
        keep_cols = (pt != 0).any(axis=0)
        if "Total" in pt.columns:
            keep_cols["Total"] = True
        pt = pt.loc[:, keep_cols]

        keep_rows = (pt != 0).any(axis=1)
        if isinstance(pt.index, pd.MultiIndex):
            for i, idx in enumerate(pt.index):
                if "Total" in (idx if isinstance(idx, tuple) else (idx,)):
                    keep_rows.iloc[i] = True
        elif "Total" in pt.index:
            keep_rows.loc["Total"] = True
        pt = pt[keep_rows]

    return pt


# ---------------------------------------------------------------------------
# summary_table()  — multi-case, multi-metric
# ---------------------------------------------------------------------------

def summary_table(
    data: dict | None = None,
    runs: list | None = None,
    metrics: list[str] | None = None,
    labels: list[str] | None = None,
    zone: str | list[str] | None = None,
    facies: str | list[str] | None = None,
    region: str | list[str] | None = None,
    case: str | list[str] | None = None,
    exclude_zero: bool = True,
) -> pd.DataFrame:
    """
    Multi-case, multi-metric summary table.

    Rows = cases, columns = metrics (with units).
    Filters (zone, facies, region, case) are applied before aggregation.

    Parameters
    ----------
    data : dict, optional
        Unified data structure (for single-line multi-case exports).
    runs : list of PetrelVolumetrics, optional
        Multiple pivot-format instances to compare.
    metrics : list of metric short names
    labels : list of display labels for each case/run
    zone, facies, region, case : filters applied before aggregation
    """
    if metrics is None:
        metrics = ["bulk", "net", "pore", "hcpv_oil", "hcpv_gas", "stoiip", "giip"]

    cols = [resolve_metric(m) for m in metrics]

    frames = []

    if data is not None:
        # Multi-case from single data structure
        df = build_detailed_df(data)
        if df.empty:
            return pd.DataFrame()

        df = _apply_filter(df, "zone", zone)
        df = _apply_filter(df, "facies", facies)
        df = _apply_filter(df, "region", region)
        df = _apply_filter(df, "case", case)

        valid_cols = [c for c in cols if c in df.columns]

        if "case" in df.columns:
            case_names = df["case"].unique().tolist()
            for i, cn in enumerate(case_names):
                label = labels[i] if labels and i < len(labels) else cn
                case_df = df[df["case"] == cn]
                totals = {c: case_df[c].sum() for c in valid_cols}
                frames.append(pd.DataFrame(totals, index=[label]))
        else:
            label = labels[0] if labels else "Total"
            totals = {c: df[c].sum() for c in valid_cols}
            frames.append(pd.DataFrame(totals, index=[label]))

    elif runs is not None:
        # Multiple PetrelVolumetrics instances
        for i, pv in enumerate(runs):
            if labels and i < len(labels):
                label = labels[i]
            else:
                label = f"{pv.model} | {pv.grid}"

            run_df = build_detailed_df(pv._data)
            if run_df.empty:
                continue

            run_df = _apply_filter(run_df, "zone", zone)
            run_df = _apply_filter(run_df, "facies", facies)
            run_df = _apply_filter(run_df, "region", region)

            valid_cols = [c for c in cols if c in run_df.columns]
            totals = {c: run_df[c].sum() for c in valid_cols}
            frames.append(pd.DataFrame(totals, index=[label]))

    if not frames:
        return pd.DataFrame()

    result = pd.concat(frames)

    if exclude_zero:
        # Drop all-zero columns
        result = result.loc[:, (result != 0).any(axis=0)]

    result.index.name = "case"
    return result
