"""
Parser for the Petrel **pivot** volumetrics export format.

This format has one case per export, with summary sections
(Zones, Facies, Contact regions) and a detailed results table.
"""

from __future__ import annotations

from .constants import VOLUME_COLS
from .parser_common import (
    find_row, normalise_cat_label, cat_key_to_record_col,
)
from .storage import try_float
from .parser_single_line import _compute_derived_totals


def parse_pivot(rows: list[list[str]], case_row: int, meta: dict) -> dict:
    """Parse a pivot-format Petrel export into the unified data structure."""
    header = [c.strip() for c in rows[case_row]]

    vol_col_indices = []
    param_col_indices = []
    folder_col_idx = None
    for ci, ch in enumerate(header):
        if ci == 0:
            continue
        if ch in VOLUME_COLS:
            vol_col_indices.append(ci)
        elif ch == "Folder":
            folder_col_idx = ci
        elif ch.startswith("$"):
            param_col_indices.append(ci)

    # Find first data row after header
    idx_case_data = case_row + 1
    while idx_case_data < len(rows) and (
        not rows[idx_case_data] or not rows[idx_case_data][0].strip()
    ):
        idx_case_data += 1

    case_data_row = rows[idx_case_data] if idx_case_data < len(rows) else []
    case_name = case_data_row[0].strip() if case_data_row else ""

    # Case-level volumes (totals)
    case_volumes = {}
    for ci in vol_col_indices:
        if ci < len(case_data_row):
            case_volumes[header[ci]] = try_float(case_data_row[ci])

    # Parameters
    case_params = {}
    for ci in param_col_indices:
        if ci < len(case_data_row):
            case_params[header[ci]] = try_float(case_data_row[ci])

    case_folder = ""
    if folder_col_idx and folder_col_idx < len(case_data_row):
        case_folder = case_data_row[folder_col_idx].strip()

    # ---- Summary sections ----
    idx_totals = find_row(rows, "Totals all result types", idx_case_data)
    if idx_totals is None:
        idx_totals = idx_case_data + 2

    idx_detailed = find_row(rows, "Detailed results", idx_totals)
    search_end = idx_detailed if idx_detailed else len(rows)

    summary_sections: dict[str, list[dict]] = {}
    section_order: list[str] = []
    vol_headers = [header[ci] for ci in vol_col_indices]

    i = idx_totals + 1
    current_section = None
    while i < search_end:
        r = rows[i]
        if not r or not r[0].strip():
            current_section = None
            i += 1
            continue

        cell0 = r[0].strip()

        if len(r) == 1 or (len(r) > 1 and not r[1].strip()):
            current_section = cell0
            if current_section not in summary_sections:
                summary_sections[current_section] = []
                section_order.append(current_section)
            i += 1
            continue

        if current_section is not None and len(r) > 1:
            entry = {"name": cell0}
            vols = {}
            for j, vh in enumerate(vol_headers):
                col_idx = j + 1
                if col_idx < len(r):
                    vols[vh] = try_float(r[col_idx])
            entry["volumes"] = vols
            summary_sections[current_section].append(entry)

        i += 1

    # Normalise section keys
    normalised_summary: dict = {}
    for sec_name in section_order:
        key = normalise_cat_label(sec_name)
        normalised_summary[key] = summary_sections[sec_name]

    # ---- Detailed results ----
    detailed_data: list[dict] = []
    if idx_detailed is not None:
        idx_det_hdr = None
        for i in range(idx_detailed + 1, min(idx_detailed + 5, len(rows))):
            r = rows[i]
            if r and len(r) > 3 and "Bulk volume" in "\t".join(r):
                idx_det_hdr = i
                break

        if idx_det_hdr is not None:
            det_header = [c.strip() for c in rows[idx_det_hdr]]
            cat_cols = []
            det_vol_start = None
            for ci, ch in enumerate(det_header):
                if ch in VOLUME_COLS:
                    if det_vol_start is None:
                        det_vol_start = ci
                elif det_vol_start is None:
                    cat_cols.append((ci, ch))

            det_vol_headers = [
                det_header[ci]
                for ci in range(det_vol_start or 0, len(det_header))
                if ci < len(det_header) and det_header[ci] in VOLUME_COLS
            ]

            # Normalise category column names
            cat_key_map = {}
            for ci, ch in cat_cols:
                low = ch.lower().replace(" ", "_")
                if "zone" in low:
                    cat_key_map[ch] = "zone"
                elif "facies" in low or "faci" in low:
                    cat_key_map[ch] = "facies"
                elif "contact" in low or "region" in low:
                    cat_key_map[ch] = "region"
                else:
                    cat_key_map[ch] = low

            for i in range(idx_det_hdr + 1, len(rows)):
                r = rows[i]
                if not r or not r[0].strip():
                    continue
                entry = {"case": case_name}
                for ci, ch in cat_cols:
                    norm_key = cat_key_map.get(ch, ch)
                    if ci < len(r):
                        entry[norm_key] = r[ci].strip()
                for j, vh in enumerate(det_vol_headers):
                    col_idx = (det_vol_start or 0) + j
                    if col_idx < len(r):
                        entry[vh] = try_float(r[col_idx])
                # Fill missing volume columns
                for vc in VOLUME_COLS:
                    if vc not in entry:
                        entry[vc] = 0
                _compute_derived_totals(entry)
                detailed_data.append(entry)

    # Build categories from summary sections
    categories = {}
    for sec_key, sec_data in normalised_summary.items():
        categories[sec_key] = [e["name"] for e in sec_data]

    # If no detailed data, generate from summary sections
    if not detailed_data and normalised_summary:
        for sec_key, sec_data in normalised_summary.items():
            record_col = cat_key_to_record_col(sec_key)
            for entry in sec_data:
                rec = {"case": case_name, record_col: entry["name"]}
                rec.update(entry.get("volumes", {}))
                for vc in VOLUME_COLS:
                    if vc not in rec:
                        rec[vc] = 0
                _compute_derived_totals(rec)
                detailed_data.append(rec)

    return {
        "metadata": meta,
        "format": "pivot",
        "cases": [case_name],
        "parameters": {case_name: case_params},
        "categories": categories,
        "detailed": detailed_data,
        "aliases": {},
        # Legacy fields for backward compat
        "_legacy_case": {
            "name": case_name,
            "volumes": case_volumes,
            "parameters": case_params,
            "folder": case_folder,
        },
        "_legacy_summary": normalised_summary,
    }
