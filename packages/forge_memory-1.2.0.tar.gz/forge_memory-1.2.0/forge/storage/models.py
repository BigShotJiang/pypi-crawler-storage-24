"""Dataclass models for all Forge entities."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, UTC


@dataclass
class Failure:
    workspace_id: str
    pattern: str
    avoid_hint: str
    hint_quality: str          # near_miss | preventable | environmental
    q: float = 0.5
    times_seen: int = 1
    times_helped: int = 0
    times_warned: int = 0
    tags: list[str] = field(default_factory=list)
    projects_seen: list[str] = field(default_factory=list)
    source: str = "manual"     # auto | manual | organic
    review_flag: bool = False
    active: bool = True
    observed_error: str | None = None
    likely_cause: str | None = None
    last_used: datetime | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    id: int | None = None


@dataclass
class Decision:
    workspace_id: str
    statement: str
    q: float = 0.5
    status: str = "active"     # active | superseded | revisiting
    rationale: str | None = None
    alternatives: list[str] = field(default_factory=list)
    superseded_by: int | None = None
    tags: list[str] = field(default_factory=list)
    last_used: datetime | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    id: int | None = None


@dataclass
class Rule:
    workspace_id: str
    rule_text: str
    scope: str | None = None
    enforcement_mode: str = "warn"  # block | warn | log
    active: bool = True
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    id: int | None = None


@dataclass
class Knowledge:
    workspace_id: str
    title: str
    content: str
    source: str = "seeded"     # seeded | organic
    q: float = 0.5
    tags: list[str] = field(default_factory=list)
    promoted_from: int | None = None
    last_used: datetime | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    id: int | None = None


@dataclass
class Session:
    session_id: str
    workspace_id: str
    warnings_injected: list[str] = field(default_factory=list)
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    ended_at: datetime | None = None
    failures_encountered: int = 0
    q_updates_count: int = 0
    promotions_count: int = 0
    config_hash: str | None = None
    document_hash: str | None = None
    unified_fitness: float | None = None
    id: int | None = None


@dataclass
class TeamRun:
    workspace_id: str
    run_id: str
    complexity: str | None = None      # SIMPLE | MEDIUM | COMPLEX
    team_config: str | None = None     # e.g. "sonnet:2 + haiku:1"
    duration_min: float | None = None
    success_rate: float | None = None
    retry_rate: float | None = None
    scope_violations: int = 0
    verdict: str | None = None
    agents: list[dict] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    id: int | None = None


@dataclass
class Agent:
    agent_id: str
    workspace_id: str
    session_id: str
    team_name: str | None = None
    role: str | None = None
    model: str | None = None
    pane_id: str | None = None
    pid: int | None = None
    status: str = "active"           # active | completed | timed_out | error
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    ended_at: datetime | None = None
    id: int | None = None


@dataclass
class ModelChoice:
    workspace_id: str
    session_id: str
    task_category: str
    selected_model: str
    agent_name: str | None = None
    outcome: float | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    id: int | None = None


@dataclass
class Experiment:
    workspace_id: str
    experiment_type: str = "auto"      # auto | manual | ablation
    config_snapshot: str = ""          # JSON
    config_hash: str = ""
    document_hashes: dict[str, str] = field(default_factory=dict)
    document_hash: str = ""
    unified_fitness: float = 0.0
    qwhr: float | None = None
    token_efficiency: float | None = None
    promotion_precision: float | None = None
    to_success_rate: float | None = None
    to_retry_rate: float | None = None
    to_scope_violations: float | None = None
    sessions_evaluated: int = 0
    team_runs_evaluated: int = 0
    notes: str | None = None
    recorded_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    id: int | None = None
