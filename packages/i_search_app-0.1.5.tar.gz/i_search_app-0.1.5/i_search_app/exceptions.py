__all__ = [
    "AccessDeniedError",
    "AfcException",
    "AfcFileNotFoundError",
    "AlreadyMountedError",
    "AmfiError",
    "ArbitrationError",
    "ArgumentError",
    "BadCommandError",
    "BadDevError",
    "CannotStopSessionError",
    "CloudConfigurationAlreadyPresentError",
    "ConnectionFailedError",
    "ConnectionFailedToUsbmuxdError",
    "ConnectionTerminatedError",
    "CoreDeviceError",
    "DeprecationError",
    "DeveloperModeError",
    "DeveloperModeIsNotEnabledError",
    "DeviceAlreadyInUseError",
    "DeviceHasPasscodeSetError",
    "DeviceNotFoundError",
    "DeviceVersionNotSupportedError",
    "DisableMemoryLimitError",
    "DvtDirListError",
    "DvtException",
    "ExtractingStackshotError",
    "FatalPairingError",
    "FeatureNotSupportedError",
    "GetProhibitedError",
    "IRecvError",
    "IRecvNoDeviceConnectedError",
    "IncorrectModeError",
    "InspectorEvaluateError",
    "InternalError",
    "InvalidConnectionError",
    "InvalidHostIDError",
    "InvalidServiceError",
    "LaunchingApplicationError",
    "LockdownError",
    "MessageNotSupportedError",
    "MissingValueError",
    "MuxException",
    "MuxVersionError",
    "NoDeviceConnectedError",
    "NotEnoughDiskSpaceError",
    "NotMountedError",
    "NotPairedError",
    "NotTrustedError",
    "NotificationTimeoutError",
    "OSNotSupportedError",
    "PairingDialogResponsePendingError",
    "PairingError",
    "PasscodeRequiredError",
    "PasswordRequiredError",
    "ProfileError",
    "PyMobileDevice3Exception",
    "QuicProtocolNotSupportedError",
    "RSDRequiredError",
    "RemoteAutomationNotEnabledError",
    "RemotePairingCompletedError",
    "SetProhibitedError",
    "StartServiceError",
    "SysdiagnoseTimeoutError",
    "TSSError",
    "TunneldConnectionError",
    "UnrecognizedSelectorError",
    "UnsupportedCommandError",
    "UserDeniedPairingError",
    "WdaError",
    "WebInspectorNotEnabledError",
    "WirError",
]

from typing import Optional


class PyMobileDevice3Exception(Exception):
    pass


class DeviceVersionNotSupportedError(PyMobileDevice3Exception):
    pass


class IncorrectModeError(PyMobileDevice3Exception):
    pass


class NotTrustedError(PyMobileDevice3Exception):
    pass


class PairingError(PyMobileDevice3Exception):
    pass


class NotPairedError(PyMobileDevice3Exception):
    pass


class CannotStopSessionError(PyMobileDevice3Exception):
    pass


class PasswordRequiredError(PairingError):
    pass


class StartServiceError(PyMobileDevice3Exception):
    def __init__(self, service_name: str, message: str) -> None:
        super().__init__()
        self.service_name = service_name
        self.message = message


class FatalPairingError(PyMobileDevice3Exception):
    pass


class NoDeviceConnectedError(PyMobileDevice3Exception):
    pass


class InterfaceIndexNotFoundError(PyMobileDevice3Exception):
    def __init__(self, address: str):
        super().__init__()
        self.address = address


class DeviceNotFoundError(PyMobileDevice3Exception):
    def __init__(self, udid: str):
        super().__init__()
        self.udid = udid


class TunneldConnectionError(PyMobileDevice3Exception):
    pass


class MuxException(PyMobileDevice3Exception):
    pass


class MuxVersionError(MuxException):
    pass


class BadCommandError(MuxException):
    pass


class BadDevError(MuxException):
    pass


class ConnectionFailedError(MuxException):
    pass


class ConnectionFailedToUsbmuxdError(ConnectionFailedError):
    pass


class ArgumentError(PyMobileDevice3Exception):
    pass


class AfcException(PyMobileDevice3Exception, OSError):
    def __init__(self, message: str, status: str, filename: Optional[str] = None) -> None:
        OSError.__init__(self, status, message)
        self.status = status
        self.filename = filename


class AfcFileNotFoundError(AfcException):
    pass


class DvtException(PyMobileDevice3Exception):
    pass


class UnrecognizedSelectorError(DvtException):
    pass


class DvtDirListError(DvtException):
    pass


class NotMountedError(PyMobileDevice3Exception):
    pass


class AlreadyMountedError(PyMobileDevice3Exception):
    pass


class MissingManifestError(PyMobileDevice3Exception):
    pass


class UnsupportedCommandError(PyMobileDevice3Exception):
    pass


class ExtractingStackshotError(PyMobileDevice3Exception):
    pass


class ChannelClosedError(PyMobileDevice3Exception):
    pass


class ConnectionTerminatedError(PyMobileDevice3Exception):
    pass


class StreamClosedError(ConnectionTerminatedError):
    pass


class WebInspectorNotEnabledError(PyMobileDevice3Exception):
    pass


class RemoteAutomationNotEnabledError(PyMobileDevice3Exception):
    pass


class WirError(PyMobileDevice3Exception):
    pass


class InternalError(PyMobileDevice3Exception):
    pass


class ArbitrationError(PyMobileDevice3Exception):
    pass


class DeviceAlreadyInUseError(ArbitrationError):

    @property
    def message(self):
        return self.args[0].get("message")

    @property
    def owner(self):
        return self.args[0].get("owner")

    @property
    def result(self):
        return self.args[0].get("result")


class DeveloperModeIsNotEnabledError(PyMobileDevice3Exception):
    pass


class DeveloperDiskImageNotFoundError(PyMobileDevice3Exception):
    pass


class DeveloperModeError(PyMobileDevice3Exception):
    pass


class LockdownError(PyMobileDevice3Exception):
    def __init__(self, message: str, identifier: Optional[str] = None) -> None:
        super().__init__(message)
        self.identifier = identifier


class GetProhibitedError(LockdownError):
    pass


class SetProhibitedError(LockdownError):
    pass


class PairingDialogResponsePendingError(PairingError):
    pass


class UserDeniedPairingError(PairingError):
    pass


class InvalidHostIDError(PairingError):
    pass


class MissingValueError(LockdownError):
    pass


class InvalidConnectionError(LockdownError):
    pass


class PasscodeRequiredError(LockdownError):
    pass


class AmfiError(PyMobileDevice3Exception):
    pass


class DeviceHasPasscodeSetError(AmfiError):
    pass


class NotificationTimeoutError(PyMobileDevice3Exception, TimeoutError):
    pass


class ProfileError(PyMobileDevice3Exception):
    pass


class CloudConfigurationAlreadyPresentError(ProfileError):
    pass


class IRecvError(PyMobileDevice3Exception):
    pass


class IRecvNoDeviceConnectedError(IRecvError):
    pass


class MessageNotSupportedError(PyMobileDevice3Exception):
    pass


class InvalidServiceError(LockdownError):
    pass


class InspectorEvaluateError(PyMobileDevice3Exception):
    def __init__(
        self,
        class_name: str,
        message: str,
        line: Optional[int] = None,
        column: Optional[int] = None,
        stack: Optional[list[str]] = None,
    ):
        super().__init__()
        self.class_name = class_name
        self.message = message
        self.line = line
        self.column = column
        self.stack = stack

    def __str__(self) -> str:
        stack_trace = "\n".join([f"\t - {frame}" for frame in self.stack])
        return f"{self.class_name}: {self.message}.\nLine: {self.line} Column: {self.column}\nStack: {stack_trace}"


class LaunchingApplicationError(PyMobileDevice3Exception):
    pass


class AppInstallError(PyMobileDevice3Exception):
    pass


class AppNotInstalledError(PyMobileDevice3Exception):
    pass


class CoreDeviceError(PyMobileDevice3Exception):
    pass


class AccessDeniedError(PyMobileDevice3Exception):
    pass


class NoSuchBuildIdentityError(PyMobileDevice3Exception):
    pass


class MobileActivationException(PyMobileDevice3Exception):
    pass


class NotEnoughDiskSpaceError(PyMobileDevice3Exception):
    pass


class DeprecationError(PyMobileDevice3Exception):
    pass


class RSDRequiredError(PyMobileDevice3Exception):
    def __init__(self, identifier: str) -> None:
        self.identifier = identifier
        super().__init__()


class SysdiagnoseTimeoutError(PyMobileDevice3Exception, TimeoutError):
    pass


class SupportError(PyMobileDevice3Exception):
    def __init__(self, os_name):
        self.os_name = os_name
        super().__init__()


class OSNotSupportedError(SupportError):
    pass


class FeatureNotSupportedError(SupportError):
    def __init__(self, os_name, feature):
        super().__init__(os_name)
        self.feature = feature


class QuicProtocolNotSupportedError(PyMobileDevice3Exception):
    pass


class RemotePairingCompletedError(PyMobileDevice3Exception):
    pass


class DisableMemoryLimitError(PyMobileDevice3Exception):
    pass


class ProtocolError(PyMobileDevice3Exception):
    pass


class TSSError(PyMobileDevice3Exception):
    pass


class WdaError(PyMobileDevice3Exception):
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code
