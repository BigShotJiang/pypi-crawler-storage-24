import logging
import platform
import plistlib
import uuid
from collections.abc import Generator
from contextlib import suppress
from pathlib import Path
from typing import Optional

from i_search_app import usbmux
from i_search_app.common import get_home_folder
from i_search_app.exceptions import MuxException, NotPairedError
from i_search_app.osu.os_utils import get_os_utils
from i_search_app.usbmux import PlistMuxConnection

logger = logging.getLogger(__name__)
OSUTILS = get_os_utils()
PAIRING_RECORD_EXT = "plist"


def generate_host_id(hostname: Optional[str] = None) -> str:
    hostname = platform.node() if hostname is None else hostname
    host_id = uuid.uuid3(uuid.NAMESPACE_DNS, hostname)
    return str(host_id).upper()


async def get_usbmux_pairing_record(identifier: str, usbmux_address: Optional[str] = None):
    with suppress(NotPairedError, MuxException):
        mux = await usbmux.create_mux(usbmux_address=usbmux_address)
        try:
            if isinstance(mux, PlistMuxConnection):
                pair_record = await mux.get_pair_record(identifier)
                if pair_record is not None:
                    return pair_record
        finally:
            await mux.close()
    return None


def get_itunes_pairing_record(identifier: str) -> Optional[dict]:
    filename = OSUTILS.pair_record_path / f"{identifier}.plist"
    try:
        with open(filename, "rb") as f:
            pair_record = plistlib.load(f)
    except (PermissionError, FileNotFoundError, plistlib.InvalidFileException):
        return None
    return pair_record


def get_local_pairing_record(identifier: str, pairing_records_cache_folder: Path) -> Optional[dict]:
    logger.debug("Looking for i_search_app pairing record")
    path = pairing_records_cache_folder / f"{identifier}.{PAIRING_RECORD_EXT}"
    if not path.exists():
        logger.debug(f"No i_search_app pairing record found for device {identifier}")
        return None
    return plistlib.loads(path.read_bytes())


async def get_preferred_pair_record(
    identifier: str, pairing_records_cache_folder: Path, usbmux_address: Optional[str] = None
) -> dict:
    # usbmuxd
    pair_record = await get_usbmux_pairing_record(identifier=identifier, usbmux_address=usbmux_address)
    if pair_record is not None:
        return pair_record

    # iTunes
    pair_record = get_itunes_pairing_record(identifier)
    if pair_record is not None:
        return pair_record

    # local storage
    return get_local_pairing_record(identifier, pairing_records_cache_folder)


def create_pairing_records_cache_folder(pairing_records_cache_folder: Optional[Path] = None) -> Path:
    if pairing_records_cache_folder is None:
        pairing_records_cache_folder = get_home_folder()
    else:
        pairing_records_cache_folder.mkdir(parents=True, exist_ok=True)
    OSUTILS.chown_to_non_sudo_if_needed(pairing_records_cache_folder)
    return pairing_records_cache_folder


def get_remote_pairing_record_filename(identifier: str) -> str:
    return f"remote_{identifier}"


def iter_remote_pair_records() -> Generator[Path, None, None]:
    return get_home_folder().glob("remote_*")


def iter_remote_paired_identifiers() -> Generator[str, None, None]:
    for file in iter_remote_pair_records():
        yield file.parts[-1].split("remote_", 1)[1].split(".", 1)[0]
