import logging
from pathlib import Path
from typing import Annotated, Literal

import typer
from tqdm import tqdm
from typer_injector import InjectingTyper

from i_search_app.cli.cli_common import ServiceProviderDep, async_command
from i_search_app.services.mobilebackup2 import Mobilebackup2Service

logger = logging.getLogger(__name__)


cli = InjectingTyper(
    name="backup2",
    help="Create, inspect, and restore MobileBackup2 backups.",
    no_args_is_help=True,
)


SourceOption = Annotated[
    str,
    typer.Option(help="The UDID of the source device."),
]
PasswordOption = Annotated[
    str,
    typer.Option(
        "--password",
        "-p",
        help="Backup password.",
    ),
]
BackupDirectoryArg = Annotated[
    Path,
    typer.Argument(
        exists=True,
        file_okay=False,
    ),
]
BackupDirectoryOption = Annotated[
    Path,
    typer.Option(
        "--backup-directory",
        "-b",
        exists=True,
        file_okay=False,
    ),
]


@cli.command()
@async_command
async def backup(
    service_provider: ServiceProviderDep,
    backup_directory: BackupDirectoryArg,
    full: Annotated[
        bool,
        typer.Option(
            help="Whether to do a full backup. If full is True, any previous backup attempts will be discarded.",
        ),
    ] = False,
) -> None:

    async with Mobilebackup2Service(service_provider) as backup_client:
        with tqdm(total=100, dynamic_ncols=True) as pbar:

            def update_bar(percentage) -> None:
                pbar.n = percentage
                pbar.refresh()

            await backup_client.backup(full=full, backup_directory=str(backup_directory), progress_callback=update_bar)


@cli.command()
@async_command
async def restore(
    service_provider: ServiceProviderDep,
    backup_directory: BackupDirectoryArg,
    system: Annotated[
        bool,
        typer.Option(help="Restore system files."),
    ] = False,
    reboot: Annotated[
        bool,
        typer.Option(help="Reboot the device when done."),
    ] = True,
    copy: Annotated[
        bool,
        typer.Option(help="Create a copy of backup folder before restoring."),
    ] = False,
    settings: Annotated[
        bool,
        typer.Option(help="Restore device settings."),
    ] = True,
    remove: Annotated[
        bool,
        typer.Option(help="Remove items which aren't being restored."),
    ] = False,
    skip_apps: Annotated[
        bool,
        typer.Option(help="Do not trigger re-installation of apps after restore."),
    ] = False,
    password: PasswordOption = "",
    source: SourceOption = "",
) -> None:
    async with Mobilebackup2Service(service_provider) as backup_client:
        with tqdm(total=100, dynamic_ncols=True) as pbar:

            def update_bar(percentage) -> None:
                pbar.n = percentage
                pbar.refresh()

            await backup_client.restore(
                backup_directory=str(backup_directory),
                progress_callback=update_bar,
                system=system,
                reboot=reboot,
                copy=copy,
                settings=settings,
                remove=remove,
                password=password,
                source=source,
                skip_apps=skip_apps,
            )