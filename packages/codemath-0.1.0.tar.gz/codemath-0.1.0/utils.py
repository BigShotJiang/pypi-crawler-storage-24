def is_prime(n):
    """
    Check if a number is prime.
    
    Args:
        n (int): Number to check
        
    Returns:
        bool: True if prime, False otherwise
    """
    if n <= 1:
        return False
    
    for i in range(2, int(n/2 + 1)):
        if n % i == 0:
            return False
    
    return True