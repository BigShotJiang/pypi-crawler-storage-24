---
name: agentboard
description: Read and update the shared agentboard kanban board. Use when starting tasks, completing work, or checking for user-added items.
---

# Agentboard Skill

You have access to a shared kanban board at `.agentboard/board.json`. Both you and the user can read and write this file. The user sees changes in real-time via a web UI.

## Reading the board

Before making any changes, always read the current board state first:

```
Read .agentboard/board.json
```

Look for:
- Tasks with `created_by: "user"` that you haven't seen before (the user added them via the UI)
- Tasks in `backlog` or `todo` that you should pick up
- Current state of tasks you're working on

## Writing to the board

When you modify the board, follow these rules:

1. **Always read first** to avoid overwriting user changes
2. **Set `updated_by` to `"agent"`** on every write
3. **Set `updated_at`** to the current ISO8601 timestamp
4. **Keep task titles short and imperative** (e.g., "Add error handling to API", not "I will add error handling")

### Moving a task

When you start working on a task, move it to `in_progress`:

```json
{
  "column": "in_progress",
  "updated_at": "2026-01-01T00:00:00+00:00"
}
```

When you finish, move it to `done`.

### Adding a task

Add new tasks with `created_by: "agent"`:

```json
{
  "id": "t_<8 random hex chars>",
  "title": "Short imperative title",
  "description": "",
  "tag": "feature|bug|chore|docs|test|design",
  "priority": "high|medium|low",
  "assigned_to": "agent|human|null",
  "column": "backlog",
  "created_at": "<ISO8601>",
  "updated_at": "<ISO8601>",
  "created_by": "agent",
  "order": 0
}
```

### Valid columns

- `backlog` - Not yet planned
- `todo` - Planned, ready to start
- `in_progress` - Currently being worked on
- `done` - Completed

### Valid tags

`feature`, `bug`, `chore`, `docs`, `test`, `design`

### Valid priorities

`high`, `medium`, `low`, or `null`

### Assignment

Tasks can be assigned to `"human"` or `"agent"` via the `assigned_to` field (or `null` for unassigned).

- When you create a task for the human to do (manual steps, reviews, decisions), set `assigned_to: "human"`
- When you pick up a task to work on, set `assigned_to: "agent"`
- Check for tasks with `assigned_to: "agent"` that the user assigned to you via the UI

## Workflow

1. At the start of a session, read the board and acknowledge any user-added tasks
2. Check for tasks assigned to you (`assigned_to: "agent"`) and prioritize those
3. When picking up a task, move it to `in_progress` and set `assigned_to: "agent"`
4. When done with a task, move it to `done`
5. If you discover sub-tasks, add them to `backlog` or `todo`
6. If a task requires human action, set `assigned_to: "human"` (e.g., "Review PR", "Test on device", "Approve design")
7. Respect user prioritization: if the user moved something to `todo`, pick it up next

## Data format

The full board schema:

```json
{
  "version": 1,
  "project": "project-name",
  "created_at": "ISO8601",
  "updated_at": "ISO8601",
  "updated_by": "agent|user",
  "columns": ["backlog", "todo", "in_progress", "done"],
  "tasks": [...]
}
```

Write the entire board object back when saving. Use atomic writes when possible.
