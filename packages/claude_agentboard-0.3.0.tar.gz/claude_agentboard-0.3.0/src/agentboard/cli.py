"""CLI commands for agentboard."""

from __future__ import annotations

import click

from agentboard.board import (
    COLUMNS,
    PRIORITIES,
    TAGS,
    find_board_root,
    init_board,
    load_board,
    board_path,
)


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """Bidirectional kanban board for AI agents and humans."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(serve)


@cli.command()
@click.option("--host", default="127.0.0.1", help="Host to bind to.")
@click.option("--port", default=5555, type=int, help="Port to bind to.")
@click.option("--no-open", is_flag=True, help="Don't open browser automatically.")
@click.option("--stt-url", default=None, help="STT server URL (overrides global config).")
def serve(host, port, no_open, stt_url):
    """Start the agentboard web UI (default command)."""
    root = find_board_root()
    if root is None:
        click.echo("No .agentboard/ found. Run 'agentboard init' first.")
        raise SystemExit(1)
    from agentboard.config import get_stt_url
    from agentboard.server import serve as run_server
    resolved_stt = get_stt_url(stt_url)
    if resolved_stt:
        click.echo(f"STT endpoint: {resolved_stt}")
    else:
        click.echo("STT not configured. Run 'agentboard voice' to set up voice input.")
    run_server(host=host, port=port, open_browser=not no_open, stt_url=resolved_stt)


@cli.command()
@click.option("--project", default="", help="Project name (defaults to directory name).")
def init(project):
    """Initialize a new agentboard in the current directory."""
    bp = init_board(project=project)
    click.echo(f"Initialized agentboard at {bp}")


@cli.command()
def status():
    """Print a summary of tasks per column."""
    root = find_board_root()
    if root is None:
        click.echo("No .agentboard/ found. Run 'agentboard init' first.")
        raise SystemExit(1)
    board = load_board(board_path(root))
    click.echo(f"Project: {board.project or '(unnamed)'}")
    click.echo(f"Updated: {board.updated_at} by {board.updated_by}")
    click.echo("")
    total = 0
    for col in board.columns:
        tasks = board.tasks_in_column(col)
        count = len(tasks)
        total += count
        label = col.replace("_", " ").title()
        click.echo(f"  {label:15s} {count}")
    click.echo(f"  {'Total':15s} {total}")


@cli.command()
@click.argument("title")
@click.option("--column", type=click.Choice(COLUMNS), default="backlog", help="Column to add task to.")
@click.option("--tag", type=click.Choice(TAGS), default=None, help="Task tag.")
@click.option("--priority", type=click.Choice(PRIORITIES), default=None, help="Task priority.")
@click.option("--assign", type=click.Choice(["human", "agent"]), default=None, help="Assign task to human or agent.")
def add(title, column, tag, priority, assign):
    """Add a task to the board."""
    root = find_board_root()
    if root is None:
        click.echo("No .agentboard/ found. Run 'agentboard init' first.")
        raise SystemExit(1)
    bp = board_path(root)
    board = load_board(bp)
    task = board.add_task(title=title, column=column, tag=tag, priority=priority, assigned_to=assign, created_by="user")
    from agentboard.board import save_board
    save_board(board, bp)
    click.echo(f"Added task {task.id}: {task.title} -> {column}")


@cli.command()
def voice():
    """Set up voice input by finding a local STT server."""
    from agentboard.config import discover_stt, load_config, save_config

    click.echo("Scanning for local STT servers...")
    found = discover_stt()

    if not found:
        click.echo("No STT servers found.")
        click.echo("\nMake sure a Whisper-compatible server is running, e.g.:")
        click.echo("  whisper-server --port 8080")
        click.echo("  uvicorn faster_whisper_server:app --port 8000")
        click.echo("\nOr set manually:")
        click.echo("  agentboard config --stt-url http://localhost:PORT/v1/audio/transcriptions")
        return

    if len(found) == 1:
        url = found[0]
        click.echo(f"Found STT server: {url}")
    else:
        click.echo("Found multiple STT servers:")
        for i, url in enumerate(found, 1):
            click.echo(f"  {i}. {url}")
        choice = click.prompt("Which one?", type=int, default=1)
        url = found[choice - 1]

    if click.confirm(f"Save '{url}' as global STT endpoint?", default=True):
        config = load_config()
        config["stt_url"] = url
        save_config(config)
        click.echo(f"Saved to ~/.config/agentboard/config.json")


@cli.command()
@click.option("--stt-url", default=None, help="Set the global STT server URL.")
@click.option("--unset-stt", is_flag=True, help="Remove the STT URL from global config.")
def config(stt_url, unset_stt):
    """View or update global agentboard configuration."""
    from agentboard.config import load_config, save_config, CONFIG_FILE

    cfg = load_config()

    if stt_url:
        cfg["stt_url"] = stt_url
        save_config(cfg)
        click.echo(f"Saved stt_url: {stt_url}")
        return

    if unset_stt:
        cfg.pop("stt_url", None)
        save_config(cfg)
        click.echo("Removed stt_url from config.")
        return

    # Show current config
    click.echo(f"Config file: {CONFIG_FILE}")
    if not cfg:
        click.echo("(empty)")
    else:
        for key, value in cfg.items():
            click.echo(f"  {key}: {value}")
