"""Bidirectional kanban board for AI agents and humans."""

__version__ = "0.2.0"
