"""Dataclasses for mailbot API entities."""

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, Generic, List, Optional, TypeVar

T = TypeVar("T")


@dataclass
class PaginationMeta:
    """Pagination metadata returned by list endpoints."""

    page: int
    limit: int
    total: int


@dataclass
class ApiResponse(Generic[T]):
    """Generic API response envelope."""

    data: T
    meta: Optional[PaginationMeta] = None


@dataclass
class Inbox:
    """Inbox entity."""

    id: str
    account_id: str
    address: str
    username: str
    display_name: Optional[str]
    domain: str
    status: str
    permissions: List[str]
    daily_send_limit: int
    sends_today: int
    created_at: str


@dataclass
class Message:
    """Message entity."""

    id: str
    inbox_id: str
    thread_id: str
    message_id_header: str
    from_address: str
    to_addresses: List[str]
    subject: Optional[str]
    body_text: Optional[str]
    direction: str
    created_at: str


@dataclass
class Thread:
    """Thread entity."""

    id: str
    inbox_id: str
    subject: Optional[str]
    last_message_at: Optional[str]
    message_count: int
    labels: List[str] = field(default_factory=list)
    created_at: str = ""


@dataclass
class Webhook:
    """Webhook configuration entity."""

    id: str
    account_id: str
    url: str
    events: List[str]
    secret: str
    active: bool
    created_at: str


@dataclass
class ComplianceDetails:
    """Compliance result payload."""

    spf: str
    dkim: str
    dmarc: str
    content_class: str
    readiness_score: int
    blocked_reasons: Optional[List[str]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the dataclass to a dictionary."""

        return asdict(self)
