"""SDK-specific exception hierarchy."""


class MailBotError(Exception):
    """Base exception for mailbot SDK failures."""


class AuthError(MailBotError):
    """Raised when the API key is invalid."""


class ComplianceError(MailBotError):
    """Raised when a send is blocked by compliance checks."""


class RateLimitError(MailBotError):
    """Raised when the API rate-limits the client."""


class NotFoundError(MailBotError):
    """Raised when a requested resource is missing."""
