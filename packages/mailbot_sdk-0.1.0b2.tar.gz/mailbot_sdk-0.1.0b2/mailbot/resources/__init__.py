"""mailbot resource exports."""

from .audit_log import AuditLogResource
from .compliance import ComplianceResource
from .domains import DomainsResource
from .engagement import EngagementResource
from .inboxes import InboxesResource
from .messages import MessagesResource
from .threads import ThreadsResource
from .usage import UsageResource
from .webhooks import WebhooksResource

__all__ = [
    "AuditLogResource",
    "ComplianceResource",
    "DomainsResource",
    "EngagementResource",
    "InboxesResource",
    "MessagesResource",
    "ThreadsResource",
    "UsageResource",
    "WebhooksResource",
]
