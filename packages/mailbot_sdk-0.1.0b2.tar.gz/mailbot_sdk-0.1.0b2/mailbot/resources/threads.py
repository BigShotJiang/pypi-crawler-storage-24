"""Thread resource methods."""


class ThreadsResource:
    """Thread listing and retrieval methods."""

    def __init__(self, client):
        self._client = client

    def list(self, inbox_id: str, **params):
        """List threads for an inbox."""

        return self._client.request("GET", f"/inboxes/{inbox_id}/threads", params=params)

    def get(self, inbox_id: str, thread_id: str):
        """Get a single thread."""

        return self._client.request("GET", f"/inboxes/{inbox_id}/threads/{thread_id}")["data"]
