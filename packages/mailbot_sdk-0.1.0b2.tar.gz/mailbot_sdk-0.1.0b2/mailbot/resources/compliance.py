"""Compliance resource methods."""


class ComplianceResource:
    """Compliance and readiness methods."""

    def __init__(self, client):
        self._client = client

    def check(self, domain: str):
        """Check SPF, DKIM, and DMARC for a domain."""

        return self._client.request("GET", "/compliance/check", params={"domain": domain})["data"]

    def readiness(self, inbox_id: str):
        """Fetch readiness details for an inbox."""

        return self._client.request("GET", f"/compliance/readiness/{inbox_id}")["data"]
