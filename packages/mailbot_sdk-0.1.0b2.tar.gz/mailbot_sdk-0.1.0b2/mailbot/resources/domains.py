"""Domain resource methods."""


class DomainsResource:
    """Custom domain management methods."""

    def __init__(self, client):
        self._client = client

    def create(self, *, domain: str):
        """Register a domain and get DNS records to configure."""

        return self._client.request("POST", "/domains", json={"domain": domain})["data"]

    def list(self):
        """List domains for the current account."""

        return self._client.request("GET", "/domains")

    def get(self, domain_id: str):
        """Fetch one domain and its DNS records."""

        return self._client.request("GET", f"/domains/{domain_id}")["data"]

    def verify(self, domain_id: str):
        """Trigger DNS verification for a domain."""

        return self._client.request("POST", f"/domains/{domain_id}/verify")

    def delete(self, domain_id: str):
        """Delete a domain when it is no longer used by active inboxes."""

        return self._client.request("DELETE", f"/domains/{domain_id}")["data"]
