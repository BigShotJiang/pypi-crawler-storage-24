"""Engagement resource methods."""


class EngagementResource:
    """Engagement event and aggregate stats methods."""

    def __init__(self, client):
        self._client = client

    def get_events(self, inbox_id=None, event=None, limit=50, page=1):
        """List engagement events for the current account."""

        params = {"inbox_id": inbox_id, "event": event, "limit": limit, "page": page}
        return self._client.request("GET", "/engagement/events", params=params)

    def events(self, inbox_id=None, event=None, limit=50, page=1):
        """List engagement events for the current account."""

        return self.get_events(inbox_id=inbox_id, event=event, limit=limit, page=page)

    def get_stats(self, inbox_id=None, period="7d"):
        """Fetch aggregate engagement stats."""

        params = {"inbox_id": inbox_id, "period": period}
        return self._client.request("GET", "/engagement/stats", params=params)

    def stats(self, inbox_id=None, period="7d"):
        """Fetch aggregate engagement stats."""

        return self.get_stats(inbox_id=inbox_id, period=period)

    def get_message_engagement(self, message_id):
        """Fetch the engagement timeline for a single message."""

        return self._client.request("GET", f"/engagement/messages/{message_id}")["data"]

    def message_timeline(self, message_id):
        """Fetch the engagement timeline for a single message."""

        return self.get_message_engagement(message_id)
