"""Webhook resource methods."""


class WebhooksResource:
    """Webhook create/list/delete methods."""

    def __init__(self, client):
        self._client = client

    def create(self, **payload):
        """Create a webhook endpoint."""

        return self._client.request("POST", "/webhooks", json=payload)["data"]

    def list(self):
        """List webhooks."""

        return self._client.request("GET", "/webhooks")["data"]

    def delete(self, webhook_id: str):
        """Delete a webhook."""

        return self._client.request("DELETE", f"/webhooks/{webhook_id}")["data"]
