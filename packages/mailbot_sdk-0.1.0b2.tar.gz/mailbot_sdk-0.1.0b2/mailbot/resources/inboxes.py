"""Inbox resource methods."""


class InboxesResource:
    """Inbox management methods."""

    def __init__(self, client):
        self._client = client

    def create(self, **payload):
        """Create a new inbox."""

        return self._client.request("POST", "/inboxes", json=payload)["data"]

    def list(self, **params):
        """List inboxes for the current account."""

        return self._client.request("GET", "/inboxes", params=params)

    def get(self, inbox_id: str):
        """Fetch an inbox by ID."""

        return self._client.request("GET", f"/inboxes/{inbox_id}")["data"]

    def delete(self, inbox_id: str):
        """Disable an inbox."""

        return self._client.request("DELETE", f"/inboxes/{inbox_id}")["data"]
