"""Usage resource methods."""


class UsageResource:
    """Usage and quota reporting methods."""

    def __init__(self, client):
        self._client = client

    def get(self, **params):
        """Fetch usage statistics for the current account."""

        return self._client.request("GET", "/usage", params=params)["data"]
