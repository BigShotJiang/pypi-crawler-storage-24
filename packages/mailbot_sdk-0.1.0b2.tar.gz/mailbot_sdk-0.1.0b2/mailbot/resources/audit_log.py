"""Audit-log resource methods."""


class AuditLogResource:
    """Audit-log listing methods."""

    def __init__(self, client):
        self._client = client

    def list(self, **params):
        """List audit entries for the current account."""

        return self._client.request("GET", "/audit-log", params=params)
