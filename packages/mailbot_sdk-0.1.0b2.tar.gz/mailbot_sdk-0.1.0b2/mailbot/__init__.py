"""Top-level exports for the mailbot Python SDK."""

from .client import MailBot
from .exceptions import AuthError, ComplianceError, MailBotError, NotFoundError, RateLimitError

__all__ = [
    "MailBot",
    "MailBotError",
    "AuthError",
    "ComplianceError",
    "RateLimitError",
    "NotFoundError",
]
