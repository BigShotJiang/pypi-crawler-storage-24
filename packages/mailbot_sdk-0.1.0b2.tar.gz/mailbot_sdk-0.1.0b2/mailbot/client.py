"""Top-level mailbot Python SDK client."""

from .http import HttpClient
from .resources.audit_log import AuditLogResource
from .resources.compliance import ComplianceResource
from .resources.domains import DomainsResource
from .resources.engagement import EngagementResource
from .resources.inboxes import InboxesResource
from .resources.messages import MessagesResource
from .resources.threads import ThreadsResource
from .resources.usage import UsageResource
from .resources.webhooks import WebhooksResource


class MailBot:
    """mailbot API client with sync and async transport support."""

    def __init__(self, api_key: str, base_url: str = "https://agentmail.omyop.com/v1", timeout: float = 30.0):
        self.http = HttpClient(api_key=api_key, base_url=base_url, timeout=timeout)
        self.inboxes = InboxesResource(self.http)
        self.domains = DomainsResource(self.http)
        self.messages = MessagesResource(self.http)
        self.threads = ThreadsResource(self.http)
        self.webhooks = WebhooksResource(self.http)
        self.compliance = ComplianceResource(self.http)
        self.audit_log = AuditLogResource(self.http)
        self.usage = UsageResource(self.http)
        self.engagement = EngagementResource(self.http)

    def close(self) -> None:
        """Close the sync HTTP client."""

        self.http.close()

    async def __aenter__(self):
        """Enter async context management."""

        return self

    async def __aexit__(self, exc_type, exc, tb):
        """Close the async HTTP client on context exit."""

        await self.http.aclose()
