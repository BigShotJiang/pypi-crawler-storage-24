# mailbot

Python SDK source for the mailbot API.

Default API base: `https://agentmail.omyop.com/v1`

Current status: package is prepared for public install once registry credentials are available.

## Sync quick start

```python
from mailbot import MailBot

client = MailBot(api_key="mb_xxx")
inbox = client.inboxes.create(username="support-bot")
```

## Domain onboarding

```python
domain = client.domains.create(domain="myapp.com")
print(domain["dns_records"])

records = client.domains.get(domain["id"])
print(records["dns_records"])

verified = client.domains.verify(domain["id"])
print(verified["data"]["status"])
print(verified["next_step"])
```

## Async quick start

```python
import asyncio
from mailbot import MailBot

async def main():
    async with MailBot(api_key="mb_xxx") as client:
        await client.http.arequest("GET", "/usage")

asyncio.run(main())
```

## Webhook handling

```python
import hmac
import hashlib

def verify_webhook(body: bytes, signature: str, secret: str) -> bool:
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)
```

## Compliance checking

```python
client.compliance.check(domain="example.com")
client.compliance.readiness(inbox_id="inbox_123")
```

## CI/email testing

```python
result = client.messages.wait_for(
    "inbox_123",
    direction="inbound",
    subject_contains="Verify your account",
    timeout_ms=20000,
)

print(result["data"]["subject"])
```

## Error handling

```python
from mailbot import MailBot, AuthError, RateLimitError

client = MailBot(api_key="mb_xxx")

try:
    client.inboxes.list()
except AuthError:
    print("Invalid API key")
except RateLimitError:
    print("Too many requests")
```
