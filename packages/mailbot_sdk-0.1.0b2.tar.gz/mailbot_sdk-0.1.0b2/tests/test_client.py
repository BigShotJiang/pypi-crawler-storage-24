import unittest
from unittest.mock import MagicMock

from mailbot.client import MailBot


class ClientTests(unittest.TestCase):
    def test_client_exposes_resources(self) -> None:
        client = MailBot(api_key="mb_test")
        self.assertIsNotNone(client.inboxes)
        self.assertIsNotNone(client.messages)
        self.assertIsNotNone(client.domains)

    def test_resource_calls_use_http_client(self) -> None:
        client = MailBot(api_key="mb_test")
        client.http.request = MagicMock(return_value={"data": {"id": "inbox_1"}})

        result = client.inboxes.create(username="support-bot")

        self.assertEqual(result["id"], "inbox_1")
        client.http.request.assert_called_once()

    def test_wait_for_message_uses_query_params(self) -> None:
        client = MailBot(api_key="mb_test")
        client.http.request = MagicMock(return_value={"data": {"id": "msg_1"}})

        result = client.messages.wait_for(
            "inbox_1",
            subject_contains="Verify your account",
            timeout_ms=20000,
            after="2026-03-13T10:00:00.000Z",
        )

        self.assertEqual(result["data"]["id"], "msg_1")
        client.http.request.assert_called_once_with(
            "GET",
            "/inboxes/inbox_1/messages/wait",
            params={
                "direction": "inbound",
                "subject_contains": "Verify your account",
                "timeout_ms": 20000,
                "after": "2026-03-13T10:00:00.000Z",
            },
        )

    def test_domains_create_posts_expected_payload(self) -> None:
        client = MailBot(api_key="mb_test")
        client.http.request = MagicMock(return_value={"data": {"id": "dom_1", "domain": "myapp.com"}})

        result = client.domains.create(domain="myapp.com")

        self.assertEqual(result["domain"], "myapp.com")
        client.http.request.assert_called_once_with(
            "POST",
            "/domains",
            json={"domain": "myapp.com"},
        )


if __name__ == "__main__":
    unittest.main()
