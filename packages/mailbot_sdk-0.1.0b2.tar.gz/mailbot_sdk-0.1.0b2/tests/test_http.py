import asyncio
import unittest
from unittest.mock import AsyncMock, MagicMock

import httpx

from mailbot.http import HttpClient


class HttpClientTests(unittest.TestCase):
    def test_sync_request_uses_httpx_client(self) -> None:
        client = HttpClient(api_key="mb_test")
        client._client = MagicMock()
        client._client.request.return_value = httpx.Response(200, json={"ok": True})

        result = client.request("GET", "/health")

        self.assertEqual(result, {"ok": True})
        client._client.request.assert_called_once()

    def test_async_request_uses_async_client(self) -> None:
        async def run_test() -> None:
            client = HttpClient(api_key="mb_test")
            client._async_client = AsyncMock()
            client._async_client.request.return_value = httpx.Response(200, json={"ok": True})

            result = await client.arequest("GET", "/health")

            self.assertEqual(result, {"ok": True})
            client._async_client.request.assert_awaited_once()

        asyncio.run(run_test())


if __name__ == "__main__":
    unittest.main()
