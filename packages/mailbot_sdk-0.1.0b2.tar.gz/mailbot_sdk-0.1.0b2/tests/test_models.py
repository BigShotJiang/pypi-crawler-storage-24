import unittest

from mailbot.models import ComplianceDetails


class ModelTests(unittest.TestCase):
    def test_compliance_details_serialization(self) -> None:
        details = ComplianceDetails(
            spf="pass",
            dkim="pass",
            dmarc="pass",
            content_class="transactional",
            readiness_score=100,
        )

        self.assertEqual(details.to_dict()["readiness_score"], 100)


if __name__ == "__main__":
    unittest.main()
