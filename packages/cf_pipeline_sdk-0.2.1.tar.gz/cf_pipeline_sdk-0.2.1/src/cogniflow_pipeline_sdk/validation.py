import argparse
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from cf_ontology.rdf_document import load_rdf_document_input


def _load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def _parse_context(ctx_node: Any, base_dir: Path, error: List[str]) -> Dict[str, str]:
    prefixes: Dict[str, str] = {}
    if isinstance(ctx_node, dict):
        for key, value in ctx_node.items():
            if isinstance(value, str):
                prefixes[key] = value
        return prefixes

    if not isinstance(ctx_node, list):
        return prefixes

    for entry in ctx_node:
        if isinstance(entry, dict):
            for key, value in entry.items():
                if isinstance(value, str):
                    prefixes[key] = value
        elif isinstance(entry, str):
            ref = entry
            ref_path = Path(ref)
            if not ref_path.is_absolute() and not ref.startswith("http"):
                ref_path = base_dir / ref
            try:
                ref_json = _load_json(ref_path)
            except Exception as exc:
                error.append(f"Failed to load context '{ref}': {exc}")
                return prefixes
            if "@context" in ref_json:
                nested = _parse_context(ref_json["@context"], ref_path.parent, error)
                prefixes.update(nested)

    return prefixes


def _expand_iri(prefixes: Dict[str, str], value: str) -> str:
    if value.startswith("http://") or value.startswith("https://"):
        return value
    if ":" not in value:
        return value
    prefix, suffix = value.split(":", 1)
    base = prefixes.get(prefix)
    if not base:
        return value
    return f"{base}{suffix}"


def _type_matches(prefixes: Dict[str, str], type_node: Any, expected: str) -> bool:
    expected_iri = _expand_iri(prefixes, expected)
    if isinstance(type_node, str):
        return _expand_iri(prefixes, type_node) == expected_iri
    if isinstance(type_node, list):
        return any(_expand_iri(prefixes, entry) == expected_iri for entry in type_node if isinstance(entry, str))
    return False


def _to_id_list(node: Any) -> List[str]:
    ids: List[str] = []
    if isinstance(node, list):
        for entry in node:
            if isinstance(entry, dict) and "@id" in entry:
                ids.append(entry["@id"])
            elif isinstance(entry, str):
                ids.append(entry)
    elif isinstance(node, dict):
        if "@id" in node:
            ids.append(node["@id"])
    elif isinstance(node, str):
        ids.append(node)
    return ids


def _extract_id(node: Any) -> Optional[str]:
    if isinstance(node, dict):
        return node.get("@id")
    if isinstance(node, str):
        return node
    return None


def _extract_types(prefixes: Dict[str, str], node: Any) -> List[str]:
    if isinstance(node, list):
        out: List[str] = []
        for entry in node:
            iri = _extract_id(entry)
            if iri:
                out.append(_expand_iri(prefixes, iri))
        return out
    iri = _extract_id(node)
    return [_expand_iri(prefixes, iri)] if iri else []


def _extract_values(node: Any) -> List[Any]:
    if isinstance(node, list):
        return node
    if node is None:
        return []
    return [node]


def _extract_literal_value(node: Any) -> Any:
    if isinstance(node, dict) and "@value" in node:
        return node["@value"]
    return node


def _extract_boolean(node: Any) -> Optional[bool]:
    value = _extract_literal_value(node)
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "1"}:
            return True
        if lowered in {"false", "0"}:
            return False
    return None


def _resolve_node(node: Any, by_id: Dict[str, Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if isinstance(node, dict):
        node_id = node.get("@id")
        if isinstance(node_id, str):
            return by_id.get(node_id, node)
        return node
    if isinstance(node, str):
        return by_id.get(node)
    return None


def _extract_table_schema(
    prefixes: Dict[str, str],
    by_id: Dict[str, Dict[str, Any]],
    contract: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    schema = _resolve_node(contract.get("cf:tableSchema"), by_id)
    if not isinstance(schema, dict):
        return None

    columns: List[Dict[str, Any]] = []
    for column_id in _to_id_list(schema.get("cf:hasColumn")):
        column = by_id.get(column_id)
        if not isinstance(column, dict):
            continue

        entry: Dict[str, Any] = {}
        name = column.get("cf:columnName")
        if isinstance(name, str) and name:
            entry["name"] = name

        column_types = _extract_types(prefixes, column.get("cf:columnElementType"))
        if column_types:
            entry["type"] = column_types[0]

        nullable = _extract_boolean(column.get("cf:columnNullable"))
        if nullable is not None:
            entry["nullable"] = nullable

        if entry:
            columns.append(entry)

    columns.sort(key=lambda entry: (entry.get("name", ""), entry.get("type", "")))

    return {"columns": columns}


def _extract_value_contract(
    prefixes: Dict[str, str],
    by_id: Dict[str, Dict[str, Any]],
    owner: Dict[str, Any],
    *,
    step_id: str,
    owner_id: str,
    owner_kind: str,
    legacy_types: List[str],
) -> Optional[Dict[str, Any]]:
    contract = _resolve_node(owner.get("cf:valueContract"), by_id)
    if not isinstance(contract, dict):
        return None

    contract_types = _extract_types(prefixes, contract.get("cf:elementType"))
    if legacy_types and contract_types and set(legacy_types).isdisjoint(contract_types):
        legacy_property = "cf:portType" if owner_kind == "port" else "cf:parameterType"
        raise ValueError(
            f"{owner_kind.capitalize()} contract type mismatch in "
            f"step '{step_id}' {owner_kind} '{owner_id}': {legacy_property} {legacy_types} "
            f"does not intersect cf:valueContract/cf:elementType {contract_types}."
        )

    contract_out: Dict[str, Any] = {}
    if contract_types:
        contract_out["element_types"] = contract_types

    shape_kinds = _extract_types(prefixes, contract.get("cf:shapeKind"))
    if shape_kinds:
        contract_out["shape_kind"] = shape_kinds[0]

    table_schema = _extract_table_schema(prefixes, by_id, contract)
    if table_schema is not None:
        contract_out["table_schema"] = table_schema

    return contract_out or None


def _extract_port_spec(
    prefixes: Dict[str, str],
    by_id: Dict[str, Dict[str, Any]],
    port_id: str,
    *,
    step_id: str,
    include_multi: bool,
) -> Optional[Dict[str, Any]]:
    port = by_id.get(port_id)
    if not isinstance(port, dict):
        return None

    out: Dict[str, Any] = {
        "id": _expand_iri(prefixes, port_id),
        "key": None,
        "types": [],
    }
    if include_multi:
        out["multi"] = False

    if "cf:portKey" in port:
        keys = _extract_types(prefixes, port["cf:portKey"])
        out["key"] = keys[0] if keys else None

    port_types: List[str] = []
    if "cf:portType" in port:
        port_types = _extract_types(prefixes, port["cf:portType"])

    if "cf:portName" in port and isinstance(port["cf:portName"], str):
        out["name"] = port["cf:portName"]

    if include_multi and "cf:isMultiPort" in port and isinstance(port["cf:isMultiPort"], bool):
        out["multi"] = port["cf:isMultiPort"]

    value_contract = _extract_value_contract(
        prefixes,
        by_id,
        port,
        step_id=step_id,
        owner_id=out["id"],
        owner_kind="port",
        legacy_types=port_types,
    )
    if value_contract is not None:
        out["value_contract"] = value_contract
        if value_contract.get("element_types"):
            out["types"] = list(value_contract["element_types"])
    elif port_types:
        out["types"] = port_types

    return out


def generate_validation_spec(step_files: Iterable[str], only_prefix: str | None = None) -> Dict[str, Any]:
    spec: Dict[str, Any] = {
        "schema_version": 1,
        "steps": {},
    }

    for path_str in step_files:
        path = Path(path_str)
        if path.suffix.lower() == ("." + "json" + "ld"):
            raise ValueError(f"Legacy step documents are no longer supported: {path}")
        doc, base_path, _, _ = load_rdf_document_input(path, label="step document")
        if "@context" not in doc or "@graph" not in doc:
            raise ValueError(f"RDF document missing @context or @graph: {path}")

        error: List[str] = []
        prefixes = _parse_context(doc["@context"], base_path or path.parent, error)
        if error:
            raise ValueError(error[0])

        graph = doc["@graph"]
        if not isinstance(graph, list):
            raise ValueError(f"@graph must be a list in {path}")

        by_id: Dict[str, Dict[str, Any]] = {}
        for entry in graph:
            if isinstance(entry, dict) and "@id" in entry:
                by_id[entry["@id"]] = entry

        for entry in graph:
            if not isinstance(entry, dict):
                continue
            if "@id" not in entry or "@type" not in entry:
                continue
            if not _type_matches(prefixes, entry["@type"], "cf:ProcessingStep"):
                continue

            step_id = _expand_iri(prefixes, entry["@id"])
            if only_prefix and not step_id.startswith(only_prefix):
                continue

            param_ids: List[str] = []
            input_ids: List[str] = []
            output_ids: List[str] = []
            required_ids: Dict[str, bool] = {}

            if "cf:hasParameter" in entry:
                param_ids.extend(_to_id_list(entry["cf:hasParameter"]))
            if "cf:hasInput" in entry:
                input_ids.extend(_to_id_list(entry["cf:hasInput"]))
            if "cf:hasOutput" in entry:
                output_ids.extend(_to_id_list(entry["cf:hasOutput"]))
            if "cf:requiresParameter" in entry:
                for req in _to_id_list(entry["cf:requiresParameter"]):
                    required_ids[req] = True

            params_out: List[Dict[str, Any]] = []
            for pid in param_ids:
                param = by_id.get(pid)
                if not param:
                    continue
                name = param.get("cf:parameterName")
                if not isinstance(name, str) or not name:
                    name = pid
                entry_out: Dict[str, Any] = {
                    "id": _expand_iri(prefixes, pid),
                    "name": name,
                    "required": pid in required_ids,
                }
                legacy_types: List[str] = []
                if "cf:parameterType" in param:
                    legacy_types = _extract_types(prefixes, param["cf:parameterType"])
                value_contract = _extract_value_contract(
                    prefixes,
                    by_id,
                    param,
                    step_id=step_id,
                    owner_id=entry_out["id"],
                    owner_kind="parameter",
                    legacy_types=legacy_types,
                )
                if value_contract is not None:
                    entry_out["value_contract"] = value_contract
                    contract_types = value_contract.get("element_types") or []
                    entry_out["type"] = contract_types[0] if contract_types else None
                elif legacy_types:
                    entry_out["type"] = legacy_types[0]
                if "cf:defaultValue" in param:
                    entry_out["default"] = param["cf:defaultValue"]
                if "cf:minValue" in param:
                    entry_out["min"] = param["cf:minValue"]
                if "cf:maxValue" in param:
                    entry_out["max"] = param["cf:maxValue"]
                if "cf:allowedValue" in param:
                    entry_out["allowed"] = _extract_values(param["cf:allowedValue"])
                params_out.append(entry_out)

            inputs_out: List[Dict[str, Any]] = []
            for iid in input_ids:
                out = _extract_port_spec(
                    prefixes,
                    by_id,
                    iid,
                    step_id=step_id,
                    include_multi=True,
                )
                if out is None:
                    continue
                inputs_out.append(out)

            outputs_out: List[Dict[str, Any]] = []
            for oid in output_ids:
                out = _extract_port_spec(
                    prefixes,
                    by_id,
                    oid,
                    step_id=step_id,
                    include_multi=False,
                )
                if out is None:
                    continue
                outputs_out.append(out)

            spec["steps"][step_id] = {
                "parameters": params_out,
                "inputs": inputs_out,
                "outputs": outputs_out,
            }

    return spec


def write_validation_spec(step_files: Iterable[str], out_path: str, only_prefix: str | None = None,
                          pretty: bool = True) -> None:
    spec = generate_validation_spec(step_files, only_prefix=only_prefix)
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as fh:
        if pretty:
            json.dump(spec, fh, indent=2, sort_keys=False)
            fh.write("\n")
        else:
            json.dump(spec, fh, separators=(",", ":"), sort_keys=False)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate validation spec from step RDF documents.")
    parser.add_argument("--steps", action="append", required=True, help="Path to step RDF document (.nq, repeatable).")
    parser.add_argument("--out", required=True, help="Output JSON path.")
    parser.add_argument("--only", default=None, help="Only include step IRIs with this prefix.")
    parser.add_argument("--compact", action="store_true", help="Write compact JSON without indentation.")
    args = parser.parse_args()

    write_validation_spec(args.steps, args.out, only_prefix=args.only, pretty=not args.compact)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
