# -*- coding: utf-8 -*-
from __future__ import annotations

import asyncio
import io
import os
import shutil
import tarfile
import zipfile
from pathlib import Path

from agent_teams.logger import get_logger
from agent_teams.net.clients import create_async_http_client
from agent_teams.tools.workspace_tools.github_cli_errors import (
    DownloadFailedError,
    ExtractionFailedError,
    GitHubCliNotFoundError,
    UnsupportedPlatformError,
)

LOGGER = get_logger(__name__)

VERSION = "2.88.1"
BIN_DIR = Path.home() / ".agent-teams" / "bin"
_gh_path_cache: Path | None = None
_gh_path_lock = asyncio.Lock()

PLATFORM_MAP = {
    "arm64-darwin": {"platform": "macOS_arm64", "extension": "zip"},
    "arm64-linux": {"platform": "linux_arm64", "extension": "tar.gz"},
    "x64-darwin": {"platform": "macOS_amd64", "extension": "zip"},
    "x64-linux": {"platform": "linux_amd64", "extension": "tar.gz"},
    "x64-windows": {"platform": "windows_amd64", "extension": "zip"},
}

_ARCH_ALIASES = {
    "x86_64": "x64",
    "amd64": "x64",
    "x64": "x64",
    "aarch64": "arm64",
    "arm64": "arm64",
}

_SYSTEM_ALIASES = {
    "darwin": "darwin",
    "linux": "linux",
    "windows": "windows",
}


def _get_platform_key() -> str:
    import platform

    raw_arch = platform.machine().strip().lower()
    raw_system = platform.system().strip().lower()

    arch = _ARCH_ALIASES.get(raw_arch, raw_arch)
    system = _SYSTEM_ALIASES.get(raw_system, raw_system)
    if (
        system.startswith("mingw")
        or system.startswith("msys")
        or system.startswith("cygwin")
    ):
        system = "windows"

    return f"{arch}-{system}"


async def get_gh_path() -> Path:
    global _gh_path_cache

    if _gh_path_cache and _gh_path_cache.is_file():
        return _gh_path_cache

    system_path = resolve_system_gh_path()
    if system_path is not None:
        LOGGER.info("Using system GitHub CLI at %s", system_path)
        _gh_path_cache = system_path
        return system_path

    local_path = get_bundled_gh_path()
    if local_path is not None:
        _gh_path_cache = local_path
        return local_path

    async with _gh_path_lock:
        if _gh_path_cache and _gh_path_cache.is_file():
            return _gh_path_cache
        system_path = resolve_system_gh_path()
        if system_path is not None:
            LOGGER.info("Using system GitHub CLI at %s", system_path)
            _gh_path_cache = system_path
            return system_path
        local_path = get_bundled_gh_path()
        if local_path is not None:
            _gh_path_cache = local_path
            return local_path
        download_target = _bundled_gh_target_path()
        try:
            await _download_gh(download_target)
            _gh_path_cache = download_target
            return download_target
        except Exception as exc:
            LOGGER.warning("Failed to download bundled GitHub CLI: %s", exc)

    raise GitHubCliNotFoundError()


def clear_gh_path_cache() -> None:
    global _gh_path_cache
    _gh_path_cache = None


def resolve_system_gh_path() -> Path | None:
    system_gh = shutil.which("gh")
    if not system_gh:
        return None
    system_path = Path(system_gh)
    if not system_path.is_file():
        return None
    return system_path


def get_bundled_gh_path() -> Path | None:
    local_path = _bundled_gh_target_path()
    if local_path.is_file():
        return local_path
    return None


def _bundled_gh_target_path() -> Path:
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    extension = ".exe" if os.name == "nt" else ""
    return BIN_DIR / f"gh{extension}"


async def _download_gh(target: Path) -> None:
    key = _get_platform_key()
    config = PLATFORM_MAP.get(key)
    if config is None:
        raise UnsupportedPlatformError(key)

    filename = f"gh_{VERSION}_{config['platform']}.{config['extension']}"
    url = f"https://github.com/cli/cli/releases/download/v{VERSION}/{filename}"

    async with create_async_http_client(follow_redirects=True) as client:
        response = await client.get(url)
        if response.status_code != 200:
            raise DownloadFailedError(url, response.status_code)
        content = response.content

    if config["extension"] == "tar.gz":
        _extract_tarball(content, target)
    else:
        _extract_zip(content, target)

    if os.name != "nt":
        os.chmod(target, 0o755)


def _extract_tarball(content: bytes, target: Path) -> None:
    with tarfile.open(fileobj=io.BytesIO(content)) as tar:
        for member in tar.getmembers():
            if member.isfile() and (
                member.name.endswith("/bin/gh") or member.name.endswith("/bin/gh.exe")
            ):
                extracted = tar.extractfile(member)
                if extracted is None:
                    break
                target.write_bytes(extracted.read())
                return
        raise ExtractionFailedError("gh not found in tarball")


def _extract_zip(content: bytes, target: Path) -> None:
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        for name in archive.namelist():
            if name.endswith("/bin/gh") or name.endswith("/bin/gh.exe"):
                with archive.open(name) as source_handle:
                    target.write_bytes(source_handle.read())
                return
        raise ExtractionFailedError("gh not found in zip")
