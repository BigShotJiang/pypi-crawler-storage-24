# jse_tools

Utilities for ingesting and processing Johannesburg Stock Exchange market data.

Includes:

- ticker ingestion
- data pipelines
- market regime detection
