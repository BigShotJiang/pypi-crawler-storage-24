import json
import os

class CheckpointManager:

    def __init__(self, checkpoint_file="pipeline_state.json"):
        self.checkpoint_file = checkpoint_file

    def save_state(self, state):
        with open(self.checkpoint_file, "w") as f:
            json.dump(state, f, indent=4)

    def load_state(self):
        if not os.path.exists(self.checkpoint_file):
            return None

        with open(self.checkpoint_file) as f:
            return json.load(f)

    def clear(self):
        if os.path.exists(self.checkpoint_file):
            os.remove(self.checkpoint_file)
