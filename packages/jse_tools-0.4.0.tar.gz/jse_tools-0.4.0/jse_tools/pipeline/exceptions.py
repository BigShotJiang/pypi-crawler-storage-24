class PipelineError(Exception):
    """Base pipeline exception."""


class PipelineInitializationError(PipelineError):
    pass


class NetworkFetchError(PipelineError):
    pass


class ValidationFailure(PipelineError):
    pass


class CheckpointRecoveryError(PipelineError):
    pass
