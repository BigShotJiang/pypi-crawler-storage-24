from .componenttestcase import ComponentTestCase, ComponentTestCase2, ComponentTestCase3
from heaserver.service.testcase.mixin import GetAllMixin


class TestGetAllRootItems(ComponentTestCase, GetAllMixin):  # type: ignore
    pass


class TestGetAllRootItems2(ComponentTestCase2, GetAllMixin):  # type: ignore
    pass


class TestGetAllRootItems3(ComponentTestCase3, GetAllMixin):  # type: ignore
    pass


class MongoReturnAttrTestCase(ComponentTestCase):

    async def test_return_attr_from_request(self):
        """Make sure get returns only the attributes in the return_attr query parameter."""
        resp = await self.client.get((self._href / '').with_query(return_attr=['id', 'display_name']).path_qs,
                                     headers={'Accept': 'application/json'})
        self.assertCountEqual([{'display_name': 'Reximus',
                                'id': '666f6f2d6261722d71757578',
                                'type': 'heaobject.registry.Component'},
                               {'display_name': 'Luximus',
                                'id': '0123456789ab0123456789ab',
                                'type': 'heaobject.registry.Component'}],
                               await resp.json())
