"""Custom exceptions for Wizard.AI SDK"""

class WizardError(Exception):
    """Base exception for all Wizard.AI errors"""
    pass

class AuthenticationError(WizardError):
    """Raised when API key is invalid"""
    pass

class APIError(WizardError):
    """Raised when API returns an error"""
    pass

class RateLimitError(WizardError):
    """Raised when rate limit is exceeded"""
    pass