from __future__ import annotations

from refinery.lib.types import Param, buf
from refinery.units import Arg, Unit


class sep(Unit):
    """
    Insert a separator between chunks; the default separator is a line break.

    If any of the input `refinery.lib.frame.Chunk`s is currently out of scope, `refinery.sep`
    makes them visible by default. This can be prevented by using the `-s` flag.
    """

    def __init__(
        self, separator: Param[buf, Arg(help='Separator; the default is a line break.')] = B'\n',
        scoped: Param[bool, Arg.Switch('-s', help=(
            'Maintain chunk scope; i.e. do not turn all input chunks visible.'))] = False
    ):
        super().__init__(separator=separator, scoped=scoped)
        self.separate = False

    def filter(self, chunks):
        it = iter(chunks)
        try:
            chunk = next(it)
        except StopIteration:
            return
        self.separate = True
        for upcoming in it:
            if not self.args.scoped:
                chunk.visible = True
            yield chunk
            chunk = upcoming
        self.separate = False
        yield chunk

    def process(self, data):
        yield data
        if self.separate:
            yield self.args.separator
