from __future__ import annotations

from refinery.units.formats.pe import OverlayUnit


class peoverlay(OverlayUnit):
    """
    Return the overlay of a PE file.

    Returns anything that may have been appended to the file. This does not include digital
    signatures. Use `refinery.pestrip` to obtain only the body of the PE file after removing
    the overlay.
    """
    def process(self, data: bytearray) -> bytearray:
        size = self._get_size(data)
        try:
            data[:size] = []
        except Exception:
            return data[size:]
        else:
            return data
