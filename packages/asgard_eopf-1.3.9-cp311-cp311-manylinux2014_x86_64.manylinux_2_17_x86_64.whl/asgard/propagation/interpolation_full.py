#!/usr/bin/env python
# coding: utf8
# Copyright 2022-2026 CS GROUP
# Licensed to CS GROUP (CS) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# CS licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""
Orbit interpolation module
"""

import logging
import time

import numpy as np

from asgard.models.time import TimeReference
from asgard.propagation.interpolation import AbstractInterpolator

# isort: off
# Orekit wrappers needs to be imported before any org.orekit module
import asgard.wrappers.orekit
from java.util import ArrayList
from org.hipparchus.analysis.polynomials import SmoothStepFactory
from org.hipparchus.geometry.euclidean.threed import Vector3D
from org.hipparchus.ode.nonstiff import DormandPrince853Integrator
from org.orekit.forces.gravity import HolmesFeatherstoneAttractionModel
from org.orekit.forces.gravity.potential import GravityFieldFactory
from org.orekit.frames import FramesFactory
from org.orekit.models.earth import ReferenceEllipsoid
from org.orekit.orbits import CartesianOrbit
from org.orekit.orbits import OrbitBlender
from org.orekit.orbits import OrbitType
from org.orekit.propagation import SpacecraftState
from org.orekit.propagation import SpacecraftStateInterpolator
from org.orekit.propagation import ToleranceProvider
from org.orekit.propagation.numerical import NumericalPropagator
from org.orekit.time import AbsoluteDate
from org.orekit.time import AbstractTimeInterpolator
from org.orekit.utils import AbsolutePVCoordinates
from org.orekit.utils import Constants
from org.orekit.utils import IERSConventions


def to_vec3d(array: np.ndarray[tuple[int], np.dtype[np.float64]]) -> Vector3D:
    return Vector3D(float(array[0]), float(array[1]), float(array[2]))


def from_vec3d(vec3d: Vector3D) -> list[float]:
    return [vec3d.getX(), vec3d.getY(), vec3d.getZ()]


class InterpolatorJava(AbstractInterpolator):
    """
    Orbit interpolator expects input orbit in Earth-Fixed frame (ITRF).
    It converts position/velocity coordinates internally to EME2000 for interpolation.
    Its interpolate method returns transformed position/velocity coordinates
    back in Earth-Fixed frame (ITRF).

    This is the "full" Java version allowing deeper parameters tuning.
    """

    def __init__(self, orbit: dict, time_reference: TimeReference):
        assert isinstance(orbit["times"], dict)
        assert orbit["frame"] == "EF", "OrbitInterpolator expect Earth-Fixed frame (ITRF)"
        self.time_reference = time_reference
        frames_loader = time_reference.context.getFrames()
        orbit_time_ref: str = orbit.get("time_ref", "GPS")
        epoch, offsets = self.time_reference.epoch_offsets(orbit["times"][orbit_time_ref])
        positions = np.array(orbit["positions"], dtype="float64")
        velocities = np.array(orbit["velocities"], dtype="float64")
        assert positions.size == offsets.size * 3
        assert velocities.size == offsets.size * 3
        # io_frame = FramesFactory.getITRF(IERSConventions.IERS_2010, True)
        self.io_frame = frames_loader.getITRF(IERSConventions.IERS_2010, True)
        # working_frame = FramesFactory.getEME2000()
        working_frame = frames_loader.getEME2000()
        self.states = ArrayList().of_(SpacecraftState)
        for idx in range(offsets.size):
            date = AbsoluteDate(epoch, float(offsets[idx]))
            pos, vel = to_vec3d(positions[idx]), to_vec3d(velocities[idx])
            pv = AbsolutePVCoordinates(self.io_frame, date, pos, vel).getPVCoordinates(working_frame)
            self.states.add(SpacecraftState(CartesianOrbit(pv, working_frame, date, Constants.IERS2010_EARTH_MU)))

        initial_state = self.states.get(0)
        initial_orbit = initial_state.getOrbit()
        frame = initial_orbit.getFrame()
        earth_ellipsoid = ReferenceEllipsoid.getIers2010(self.io_frame)
        gravity_field = GravityFieldFactory.getNormalizedProvider(20, 20)
        # tol = ToleranceProvider.getDefaultToleranceProvider(1e-2).getTolerances(initial_orbit, OrbitType.CARTESIAN)
        # integrator = DormandPrince853Integrator(1e-3, 1e3, tol[0], tol[1])
        integrator = DormandPrince853Integrator(1e-3, 1e3, 0.01, 0.0)
        propagator = NumericalPropagator(integrator)
        propagator.setOrbitType(OrbitType.CARTESIAN)
        propagator.addForceModel(HolmesFeatherstoneAttractionModel(earth_ellipsoid.getBodyFrame(), gravity_field))
        propagator.setInitialState(initial_state)
        orbit_blender = OrbitBlender(SmoothStepFactory.getQuadratic(), propagator, frame)
        self.interpolator = SpacecraftStateInterpolator(AbstractTimeInterpolator.DEFAULT_INTERPOLATION_POINTS,
                    AbstractTimeInterpolator.DEFAULT_EXTRAPOLATION_THRESHOLD_SEC, frame, orbit_blender,
                    None, None, None, None)

    def interpolate(
        self, times: dict
    ) -> tuple[np.ndarray[tuple[int, int], np.dtype[np.float64]], np.ndarray[tuple[int, int], np.dtype[np.float64]]]:
        epoch, offsets = self.time_reference.epoch_offsets(times)
        positions = np.zeros(shape=(offsets.size, 3), dtype="float64")
        velocities = np.zeros(shape=(offsets.size, 3), dtype="float64")
        t0 = time.perf_counter()
        logging.debug("SpacecraftStateInterpolator.interpolate request %i dates", offsets.size)
        for idx in range(offsets.size):
            date = AbsoluteDate(epoch, float(offsets[idx]))
            state = self.interpolator.interpolate(date, self.states)
            pv = state.getPVCoordinates(self.io_frame)
            positions[idx] = from_vec3d(pv.getPosition())
            velocities[idx] = from_vec3d(pv.getVelocity())

        dt = time.perf_counter() - t0
        logging.debug("SpacecraftStateInterpolator.interpolate done in %.3g seconds", dt)
        return positions, velocities
