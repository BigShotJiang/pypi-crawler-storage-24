#!/usr/bin/env python
# coding: utf8
# Copyright 2022-2026 CS GROUP
# Licensed to CS GROUP (CS) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# CS licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""
Orbit interpolation module
"""

import logging
import time

import numpy as np

from asgard.core.time import DEFAULT_UNIT, JD_TO_SECONDS
from asgard.models.time import TimeReference

# isort: off
# Orekit wrappers needs to be imported before any org.orekit module
from asgard.wrappers.orekit import to_nio_view  # type: ignore
from org.orekit.tools import OrbitInterpolator  # type: ignore


def is_sparse_orbit(orbit: dict, threshold: float = 600) -> bool:
    """
    :param orbit: orbit dictionary (see `asgard.core.schema.ORBIT_STATE_VECTORS_SCHEMA`)
    :param threshold: seconds in floating point to compare mean absolute time offests, default to 10 minutes.
    :return: boolean whether the orbit is considered sparse wrt. the threshold.
    """
    assert "times" in orbit
    orbit_time = orbit["times"]
    assert isinstance(orbit_time, dict)
    orbit_time_ref = orbit.get("time_ref", "GPS")
    unit = orbit_time.get("unit", DEFAULT_UNIT)
    assert orbit_time_ref in orbit_time
    offsets = orbit_time[orbit_time_ref]["offsets"]
    assert isinstance(offsets, np.ndarray)
    if unit == "d":
        threshold /= JD_TO_SECONDS
    dt = offsets[:-1] - offsets[1:]
    return np.abs(dt).mean() > threshold


def is_pure_absolute_orbit(orbit: dict) -> bool:
    """
    :param orbit: orbit dictionary (see `asgard.core.schema.ORBIT_STATE_VECTORS_SCHEMA`)
    :return: boolean whether the orbit contains ANX only.
    """
    return "absolute_orbit" in orbit and len(orbit["absolute_orbit"]) == len(set(orbit["absolute_orbit"]))


class AbstractInterpolator:
    """
    OrbitInterpolator expect input orbit in Earth-Fixed frame (ITRF).
    It converts position/velocity coordinates internally to EME2000 for interpolation.
    Its interpolate method returns transformed position/velocity coordinates
    back in Earth-Fixed frame (ITRF).
    """

    def __init__(self, orbit: dict, time_reference: TimeReference):
        """
        :param orbit: Input orbit dict (see `asgard.core.schema.ORBIT_STATE_VECTORS_SCHEMA`)
        :param time_reference: `asgard.models.time.TimeReference` instance
        """
        pass

    def interpolate(
        self, times: dict
    ) -> tuple[np.ndarray[tuple[int, int], np.dtype[np.float64]], np.ndarray[tuple[int, int], np.dtype[np.float64]]]:
        """
        :param times: Input time array structure (see `asgard.core.schema.TIME_ARRAY_SCHEMA_2D`)
        :return: `tuple(positions, velocities)` 3D vectors in Earth-Fixed frame (ITRF) of shape `(offsets.size, 3)`
        """
        raise NotImplementedError


class Interpolator(AbstractInterpolator):
    """
    OrbitInterpolator expect input orbit in Earth-Fixed frame (ITRF).
    It converts position/velocity coordinates internally to EME2000 for interpolation.
    Its interpolate method returns transformed position/velocity coordinates
    back in Earth-Fixed frame (ITRF).
    """

    def __init__(self, orbit: dict, time_reference: TimeReference):
        """
        :param orbit: Input orbit dict (see `asgard.core.schema.ORBIT_STATE_VECTORS_SCHEMA`)
        :param time_reference: `asgard.models.time.TimeReference` instance
        """
        assert isinstance(orbit["times"], dict)
        assert orbit["frame"] == "EF", "OrbitInterpolator expect Earth-Fixed frame (ITRF)"
        self.time_reference = time_reference
        time_ref: str = orbit.get("time_ref", "GPS")
        epoch, offsets = self.time_reference.epoch_offsets(orbit["times"][time_ref])
        positions = np.array(orbit["positions"], dtype="float64")
        velocities = np.array(orbit["velocities"], dtype="float64")
        assert positions.size == offsets.size * 3
        assert velocities.size == offsets.size * 3
        self.interpolator = OrbitInterpolator(
            epoch, to_nio_view(offsets), to_nio_view(positions), to_nio_view(velocities)
        )

    def interpolate(
        self, times: dict
    ) -> tuple[np.ndarray[tuple[int, int], np.dtype[np.float64]], np.ndarray[tuple[int, int], np.dtype[np.float64]]]:
        """
        :param times: Input time array structure (see `asgard.core.schema.TIME_ARRAY_SCHEMA_2D`)
        :return: `tuple(positions, velocities)` 3D vectors in Earth-Fixed frame (ITRF) of shape `(offsets.size, 3)`
        """
        epoch, offsets = self.time_reference.epoch_offsets(times)
        positions = np.zeros(shape=(offsets.size, 3), dtype="float64")
        velocities = np.zeros(shape=(offsets.size, 3), dtype="float64")
        t0 = time.perf_counter()
        logging.debug("OrbitInterpolator.interpolate request %i dates", offsets.size)
        self.interpolator.interpolate(epoch, to_nio_view(offsets), to_nio_view(positions), to_nio_view(velocities))
        dt = time.perf_counter() - t0
        logging.debug("OrbitInterpolator.interpolate done in %.3g seconds", dt)
        return positions, velocities
