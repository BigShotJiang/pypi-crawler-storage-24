import argparse
import time
import cv2
import os
import numpy as np
import sys
from colorama import init, Cursor
from PIL import Image, ImageDraw, ImageFont
import threading
import queue
import pyvirtualcam
from pygrabber.dshow_graph import FilterGraph
import platform

init(autoreset=True)

def get_font_path():
    # 1. Проверяем локальную папку assets (твой приоритет)
    base_dir = os.path.dirname(os.path.abspath(__file__))
    local_font = os.path.join(base_dir, "assets", "Consolas.ttf")
    
    if os.path.exists(local_font):
        return local_font
    
    # 2. Если локально нет, ищем в системных путях Windows
    if platform.system() == "Windows":
        sys_font = os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Fonts", "consola.ttf")
        if os.path.exists(sys_font):
            return sys_font
            
    # 3. Если совсем ничего не нашли, возвращаем None (PIL использует дефолт)
    return None

FONT_PATH = get_font_path()

IMAGE_EXTS = {'.bmp', '.dib', '.jpeg', '.jpg', '.jpe', '.jp2', '.png',
              '.webp', '.pbm', '.pgm', '.ppm', '.sr', '.ras', '.tiff',
              '.tif', '.exr', '.hdr', '.pic'}

VIDEO_EXTS = {'.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv', '.webm',
              '.mpeg', '.mpg', '.m4v', '.3gp', '.3g2', '.mj2', '.gif'}

asciiStyled = False

sourceIsVideo = False

mainQueue = queue.Queue()

char_w, char_h = 10, 20

#рампы ascii

listOfBlockCharRamp = [
    [
    ["█","█"],
    ["█","█"]],
    
    [["█","█"],
    ["█","▓"]],
    
    [["█","▓"],
    ["▓","█"]],
    
    [["█","▓"],
    ["▓","▓"]],
     
    [["▓","▓"],
    ["▓","▓"]],
      
    [["▓","▓"],
    ["▓","▒"]],
    
    [["▓","▒"],
    ["▒","▓"]],
    
    [["▓","▒"],
    ["▒","▒"]],
    
    [["▒","▒"],
    ["▒","▒"]],
    
    [["▒","▒"],
    ["▒","░"]],
    
    [["▒","░"],
    ["░","▒"]],
    
    [["▒","░"],
    ["░","░"]],
    
    [["░","░"],
    ["░","░"]],
    
    [["░","░"],
    ["░"," "]],
    
    [["░"," "],
    [" ","░"]],
    
    [["░"," "],
    [" "," "]],
    
    [[" "," "],
    [" "," "]]]
listOfBlockCharRamp.reverse()

charRamp = "█▓▒░ "
listOfCharRamp = list(charRamp[::-1])
asciiStyledCharRamp = list(""" .:x@""")
asciiStyledCharRamp_16level = list(""" .:-=+*%#@ROWMQB""")

#функции сбора карт спрайтов

def precompute_charSprites(font_path, font_size, args):
    """Создает массив NumPy со всеми символами."""
    font = ImageFont.truetype(font_path, font_size)
    global char_w, char_h

    newCharList = asciiStyledCharRamp_16level if args.level == 16 else asciiStyledCharRamp

    # Создаем пустой "куб": [количество_символов, высота, ширина]
    sprites = np.zeros((256, char_h, char_w), dtype=np.uint8)
    
    for i in range(256):
        charIdx = min(int(i/(256/len(newCharList))), len(newCharList) - 1)

        char = newCharList[charIdx]

        img = Image.new('L', (char_w, char_h), 0)
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), char, font=font, fill=255)

        sprites[i] = np.array(img)
        
    return sprites, (char_w, char_h)

def precompute_blockSprites(font_path, font_size, char_list):
    """Создает массив NumPy со всеми символами."""
    font = ImageFont.truetype(font_path, font_size)
    global char_w, char_h 
    
    # Создаем пустой "куб": [количество_символов, высота, ширина]
    sprites = np.zeros((256, char_h, char_w), dtype=np.uint8)
    
    for i in range(256):
        charIdx = min(int(i/(256/len(char_list))), len(char_list) - 1)

        char = char_list[charIdx]

        img = Image.new('L', (char_w, char_h), 0)
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), char, font=font, fill=255)

        sprites[i] = np.array(img)
        
    return sprites, (char_w, char_h)

def precompute_bigBlockSprites(font_path, font_size, char_list):
    """Создает массив NumPy со всеми символами."""
    font = ImageFont.truetype(font_path, font_size)
    global char_w, char_h
    full_w, full_h = char_w * 2, char_h * 2
    
    # Создаем пустой "куб": [количество_символов, высота, ширина]
    sprites = np.zeros((256, full_h, full_w), dtype=np.uint8)
    
    for i in range(256):
        charIdx = min(int(i/(256/len(char_list))), len(char_list) - 1)
        block = char_list[charIdx]

        final_sprite = Image.new('L', (full_w, full_h), 0)

        # Проходим по матрице 2x2 и собираем блок
        for row in range(2):
            for col in range(2):
                char = block[row][col]
                
                # 1. Создаем временную картинку для ОДНОГО символа (строго под его размер)
                char_img = Image.new('L', (char_w, char_h), 0)
                char_draw = ImageDraw.Draw(char_img)
                
                # 2. Рисуем символ (если он вылезет за char_w, он просто обрежется)
                char_draw.text((0, 0), char, font=font, fill=255)
                
                # 3. Вклеиваем этот "чистый" символ в нужную четверть большого спрайта
                final_sprite.paste(char_img, (col * char_w, row * char_h))

        sprites[i] = np.array(final_sprite)
        
    return sprites, (full_w, full_h)

def fast_numpy_render(ascii_codes, sprites_cube):
    indices = np.array(ascii_codes, dtype=np.intp)
    blocks = sprites_cube[indices]
    rows, cols, ch, cw = blocks.shape
    rendered = blocks.transpose(0, 2, 1, 3).reshape(rows * ch, cols * cw)
    
    return rendered

def getListOfAvailableDevices():
    graph = FilterGraph()
    devices = graph.get_input_devices()
    print("Доступные камеры:")
    for i, device in enumerate(devices):
        print(f"[{i}] {device}")

def getFps(args):
    path = getattr(args, 'path', None)
    delay = getattr(args, 'delay', None)
    index = getattr(args, 'index', None)
    
    if path:
        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            print("Не удалось открыть видео")
            sys.exit(1)
        fps = cap.get(cv2.CAP_PROP_FPS)
        cap.release()
        return fps
    elif delay:
        return 1 / delay
    elif index:
        cap = cv2.VideoCapture(index)
        if not cap.isOpened():
            print("Не удалось открыть видео")
            sys.exit(1)
        fps = cap.get(cv2.CAP_PROP_FPS)
        cap.release()
        print(fps)
        return fps
    else:
        return 30.0

def queueManager(args):
    isVirtualCamUsed = False
    filePaths = []
    toFileQueue = queue.Queue()
    toVirtualCamQueue = queue.Queue()
    threads = []

    if args.ascii:
        sprites_cube, char_size = precompute_charSprites(FONT_PATH, 19, args) 
    elif args.level == 16:
        sprites_cube, char_size = precompute_bigBlockSprites(FONT_PATH, 19, listOfBlockCharRamp)
    else:
        sprites_cube, char_size = precompute_blockSprites(FONT_PATH, 19, listOfCharRamp)

    for output in args.output:
        if output == "virtual":
            isVirtualCamUsed = True
            break

    for output in args.output:
        if output != "virtual":
            filePaths.append(output)

    if isVirtualCamUsed:
        virtualCamThread = threading.Thread(target=virtualCamOutput, args=(toVirtualCamQueue, getFps(args)), daemon=True)
        virtualCamThread.start()
        threads.append(virtualCamThread)

    if filePaths and sourceIsVideo:
        imageToVideoFileThread = threading.Thread(target=imageToVideoFile, args=(toFileQueue, filePaths, getFps(args), args), daemon=True)
        imageToVideoFileThread.start()
        threads.append(imageToVideoFileThread)

    while True:
        queuePrope = mainQueue.get()

        if queuePrope is None:  # Сигнал завершения
            toFileQueue.put((None, None))
            toVirtualCamQueue.put((None, None))
            break

        queuePrope = queuePrope if args.level != 16 else cv2.resize(queuePrope, (int(queuePrope.shape[1]//2), int(queuePrope.shape[0]//2)))

        size = (queuePrope.shape[0] * char_size[1], queuePrope.shape[1] * char_size[0])

        rendered = fast_numpy_render(queuePrope, sprites_cube)

        if isVirtualCamUsed:
            toVirtualCamQueue.put((rendered, size))
        
        if filePaths:
            if sourceIsVideo:
                toFileQueue.put((rendered, size))
            else:
                imageToImageFile(rendered, filePaths)
                
    for t in threads:
        t.join()

def virtualCamOutput(toVirtualCamQueue, fps):
    vcam = None
    try:
        while True:
            rendered_frame, size = toVirtualCamQueue.get()

            if rendered_frame is None: # Сигнал завершения
                break

            frame_rgb = cv2.cvtColor(rendered_frame, cv2.COLOR_GRAY2RGB)
            
            if vcam is None:
                h, w = size
                vcam = pyvirtualcam.Camera(width=w, height=h, fps=fps)
                print(f"\n[V-CAM] Трансляция запущена: {w}x{h} @ {fps} FPS")

            vcam.send(frame_rgb)
            
            vcam.sleep_until_next_frame()
            
            toVirtualCamQueue.task_done()
    except Exception as e:
        print(f"\n[V-CAM] Ошибка: {e}")
    finally:
        if vcam:
            vcam.close()

def imageToImageFile(image,filePaths):
    try:
        for path in filePaths:
            Image.fromarray(image).save(path)
        print(f"\nФайл '{filePaths}' успешно сохранен.")
    except Exception as e:
        print(f"\nОшибка сохранения файла '{filePaths}': {e}")

def imageToVideoFile(fileQueue, filePath, fps, args):
    writer = None
    writers = []
    
    try:
        while True:
            image, size = fileQueue.get()

            if image is None: 
                break

            img = Image.fromarray(image).convert('RGB')
            arr = np.asarray(img)
            frame_data = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR) 
            if frame_data is None: break # Сигнал завершения
            
            if not writers:
                height, width = size
                fourcc = cv2.VideoWriter_fourcc(*'mp4v')
                if fps < 30:
                        for path in filePath:
                            writers.append(cv2.VideoWriter(path, fourcc, 30, (width, height)))
                else:
                    for path in filePath:
                        writers.append(cv2.VideoWriter(path, fourcc, fps, (width, height)))
            if fps < 30:
                for _ in range(int(30/fps)):
                    for writer in writers:
                        writer.write(frame_data)
            else:
                for writer in writers:
                    writer.write(frame_data)
            fileQueue.task_done()
        for writer in writers:
            writer.release()
        print(f"\nФайл '{filePath}' успешно сохранен.")
    except Exception as e:
        print(f"\nОшибка сохранения видео файла '{filePath}': {e}")

def addBaseArgumentsToParsers(parser):
    parser.add_argument("-a","--ascii", action="store_true", help="Использовать классический стиль ASCII")
    parser.add_argument("--level", choices=[2, 5, 16], default=5, type=int, help="Уровень детализации")
    parser.add_argument("--normalize", action="store_true", help="Нормализация яркости")
    parser.add_argument("--scale", type=float, default=1.0, help="Масштаб изображения (например, 0.5 для уменьшения вдвое)")
    parser.add_argument("-q","--quiet", action="store_true", help="Отключить вывод в терминал")
    parser.add_argument(
    "-o", "--output", 
    action="append", 
    metavar="DEST",
    help="Направление вывода. Может быть путем к файлу (видео/картинка) "
         "или ключевым словом 'virtual' для трансляции в виртуальную камеру. "
         "Можно указывать несколько раз."
    )

def imread_unicode(path):
    try:
        data = np.fromfile(path, np.uint8)
    except Exception as e:
        print(f"Ошибка чтения файла '{path}': {e}")
        return None
    return cv2.imdecode(data, cv2.IMREAD_COLOR)

def normalize_image(gray_img):
    return cv2.normalize(gray_img, None, 0, 255, cv2.NORM_MINMAX)

def getTerminalSize(args):
    if args.size:
        return args.size, args.size // 2
    else:
        term_size = os.get_terminal_size()
        return term_size.columns, term_size.lines

def resizeImageToTerminal(gray_img, termCol, termRows):
    origHeight, origWidth = gray_img.shape
    ratio = origWidth / origHeight

    if termCol / termRows >= ratio:
        newHeight = termRows - 1
        newWidth = int(termRows * ratio) * 2
        if newWidth > termCol:
            newWidth = termCol
            newHeight = int(termCol / ratio / 2)
    else:
        newHeight = int(termCol / ratio / 2) 
        newWidth = termCol 

    return cv2.resize(gray_img, (int(newWidth), int(newHeight)), interpolation=cv2.INTER_NEAREST)

#функции конвертации в ASCII

def ascii_conversion_16level_of_details(gray_img):
    char_array = np.array(listOfBlockCharRamp if not asciiStyled else asciiStyledCharRamp_16level)
    smallerGrayImg = cv2.resize(gray_img, (int(gray_img.shape[1]//2), int(gray_img.shape[0]//2)) if not asciiStyled else (gray_img.shape[1], gray_img.shape[0]), interpolation=cv2.INTER_NEAREST)
    indices = smallerGrayImg // int(255 / len(char_array) + 1) 

    char_matrix = char_array[indices]
    
    if not asciiStyled:
        matrix_rows, matrix_cols, _, _ = char_matrix.shape

        reorderedCharMatrix = char_matrix.transpose(0,2,1,3).reshape(matrix_rows * 2, matrix_cols * 2)

        return '\n'.join([''.join(row) for row in reorderedCharMatrix])
    else:
        return '\n'.join([''.join(row) for row in char_matrix])

def ascii_conversion_5level_of_details(gray_img):
    char_array = np.array(listOfCharRamp if not asciiStyled else asciiStyledCharRamp)
    indices = gray_img // int(255 / len(char_array) + 1) 

    char_matrix = char_array[indices]

    return '\n'.join([''.join(row) for row in char_matrix])

def ascii_conversion_2level_of_details(gray_img):
    char_array = np.array([" ", "█"] if not asciiStyled else [" ", "@"])
    indices = gray_img // int(255 / len(char_array) + 1) 

    char_matrix = char_array[indices]

    return '\n'.join([''.join(row) for row in char_matrix])

#Функции вывода в терминал

def imageToChar(args, asciiConversionFunction):
    try:

        img = imread_unicode(args.path)
        if img is None:
            print("Не удалось загрузить изображение")
            sys.exit(1)

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Получаем размер терминала
        termCol, termRows = getTerminalSize(args)

        origHeight, origWidth = gray.shape
        ratio = origWidth / origHeight

        # Масштабируем под размер консоли
        resized = resizeImageToTerminal(gray, termCol, termRows)
        
        if args.normalize:
            resized = normalize_image(resized)
        
        if args.output:
            mainQueue.put(resized)

        if not args.quiet:
            ascii_art = asciiConversionFunction(resized)
            sys.stdout.write(ascii_art)
            sys.stdout.flush()
        
    except Exception as exception:
        print(f"Ошибка при воспроизведении видео {exception}")
        sys.exit(1)
    finally:
        mainQueue.put(None)

def videoTochar(args, asciiConversionFunction):
    cap = cv2.VideoCapture(args.path)
    if not cap.isOpened():
        print("Не удалось открыть видео")
        sys.exit(1)

    fps = cap.get(cv2.CAP_PROP_FPS)

    ret, frame = cap.read()

    if ret:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        termCol, termRows = getTerminalSize(args)

        newWidth, newHeight = resizeImageToTerminal(gray, termCol, termRows).shape

    else:
        print("Ошибка считывания кадров")
        cap.release()
        sys.exit(1)

    try:
        while True:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            try:
                while True:
                    start = time.perf_counter()

                    ret, frame = cap.read()
                    if not ret:
                        break
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

                    resized = cv2.resize(gray, (int(newWidth * args.scale), int(newHeight * args.scale)), interpolation=cv2.INTER_NEAREST)
                    if args.normalize:
                        resized = normalize_image(resized)

                    if args.output:
                        mainQueue.put(resized)

                    if not args.quiet:
                        ascii_art = asciiConversionFunction(resized)
                        sys.stdout.write(Cursor.POS(1, 1))
                        sys.stdout.write(ascii_art)
                        sys.stdout.flush()  

                        end = time.perf_counter()
                        timeCount = end - start

                        if 1/fps - timeCount > 0:
                            time.sleep(1/fps - timeCount)

            except:
                print("Ошибка при воспроизведении видео")
                cap.release()
                sys.exit(1)
                

            if not args.loop:
                break

    except KeyboardInterrupt:
        cap.release()
        sys.exit(0)
    finally:
        mainQueue.put(None)
        cap.release()

def getFrameToChar(args, asciiConversionFunction):
    try:
        cap = cv2.VideoCapture(args.path)
        if not cap.isOpened():
            print("Не удалось открыть видео")
            sys.exit(1)

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if args.index < 1 or args.index > total_frames:
            print(f"Ошибка: индекс кадра должен быть от 1 до {total_frames}")
            cap.release()
            sys.exit(1)
            
        cap.set(cv2.CAP_PROP_POS_FRAMES, args.index - 1)
        
        ret, frame = cap.read()

        if ret:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            termCol, termRows = getTerminalSize(args)

            resized = resizeImageToTerminal(gray, termCol, termRows)
            if args.normalize:
                resized = normalize_image(resized)

            if args.output:
                mainQueue.put(resized)

            if not args.quiet:
                ascii_art = asciiConversionFunction(resized)
                sys.stdout.write(ascii_art)
                sys.stdout.flush()
            
        else:
            cap.release()
    except Exception as exception:
        print(f"Ошибка считывания кадра: {exception}")
        sys.exit(1)
    finally:
        mainQueue.put(None) 

def slideshowToChar(args, asciiConversionFunction):
    max_cols, max_rows = 0, 0
    termCol, termRows = getTerminalSize(args)

    for imgPath in args.files:
        img = imread_unicode(imgPath)
        if img is not None:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            resized = resizeImageToTerminal(gray, termCol, termRows)
            h, w = resized.shape
            if w > max_cols: max_cols = w
            if h > max_rows: max_rows = h

    while True:
        try:
            for imgPath in args.files:
                start = time.perf_counter()
                
                img = imread_unicode(imgPath)
                if img is None:
                    print("Не удалось загрузить изображение")
                    sys.exit(1)

                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

                termCol, termRows = getTerminalSize(args)

                resized = resizeImageToTerminal(gray, termCol, termRows)

                if args.normalize:
                    resized = normalize_image(resized)
                
                canvas = np.zeros((max_rows, max_cols), dtype=np.uint8)
                
                # Вычисляем координаты для вставки (центрирование)
                h, w = resized.shape
                y_off = (max_rows - h) // 2
                x_off = (max_cols - w) // 2
                canvas[y_off:y_off+h, x_off:x_off+w] = resized

                if args.output:
                    mainQueue.put(canvas)

                if not args.quiet:
                    ascii_art = asciiConversionFunction(canvas)
                    sys.stdout.write(Cursor.POS(1, 1))
                    sys.stdout.write(ascii_art)
                    sys.stdout.flush()

                    end = time.perf_counter()
                    timeCount = end - start

                    if args.delay - timeCount > 0:
                        time.sleep(args.delay - timeCount)

            if not args.loop:
                break
        except KeyboardInterrupt:
            sys.exit(0)
    
    mainQueue.put(None)

def streamToChar(args, asciiConversionFunction):
    cap = cv2.VideoCapture(args.index, cv2.CAP_DSHOW)
    #time.sleep(1)
    if not cap.isOpened():
        print("Не удалось открыть устройство ")
        sys.exit(1)
    
    w = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    h = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
    
    # 2. Если разрешение слишком маленькое или странное, пробуем поставить HD
    if w < 1280 or h < 720:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    print(f"Сигнал захвачен: {int(w)}x{int(h)}")

    # 3. "Умный" прогрев с проверкой валидности
    valid_signal = False
    for _ in range(30):
        ret, frame = cap.read()
        if ret and frame is not None:
            if np.average(frame) > 0.5: # Если в кадре не абсолютная тьма
                valid_signal = True
                break
        time.sleep(0.05)
    if not valid_signal:
        print("Предупреждение: Сигнал не валиден (черный экран)")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0

    ret, frame = cap.read()

    if ret:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        termCol, termRows = getTerminalSize(args)

        newWidth, newHeight = resizeImageToTerminal(gray, termCol, termRows).shape

    else:
        print("Ошибка считывания кадров")
        cap.release()
        sys.exit(1)

    try:
        while True:
            start = time.perf_counter()

            ret, frame = cap.read()
            if not ret:
                #break
                time.sleep(0.1)
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            resized = cv2.resize(gray, (int(newWidth * args.scale), int(newHeight * args.scale)), interpolation=cv2.INTER_NEAREST)
            if args.normalize:
                resized = normalize_image(resized)

            if args.output:
                mainQueue.put(resized)

            if not args.quiet:
                ascii_art = asciiConversionFunction(resized)
                sys.stdout.write(Cursor.POS(1, 1))
                sys.stdout.write(ascii_art)
                sys.stdout.flush()
            
                end = time.perf_counter()
                timeCount = end - start

                if 1/fps - timeCount > 0:
                    time.sleep(1/fps - timeCount)

    except KeyboardInterrupt:
        cap.release()
    
    except Exception as exception:
        print(f"Ошибка при воспроизведении видео {exception}")
        cap.release()
        sys.exit(1)

    finally:
        mainQueue.put(None)
        cap.release()

#Главная функция        

def main():
    parser = argparse.ArgumentParser(description="ASCII Video/Image Player")
    global asciiStyled
    global sourceIsVideo

    subparsers = parser.add_subparsers(dest="command", required=True)

    #технический аргумент для определения размера терминала, не отображается в справке
    parser.add_argument("-s", "--size", type=int, help=argparse.SUPPRESS)

    # Команда play
    play = subparsers.add_parser("play")
    # Общие аргументы для всех команд
    addBaseArgumentsToParsers(play)
    #уникальные аргументы для данной команды
    play.add_argument("path", help="Путь к файлу")
    play.add_argument("--loop", action="store_true", help="Зациклить видео")

    # Команда frame
    frame = subparsers.add_parser("frame")
    # Общие аргументы для всех команд
    addBaseArgumentsToParsers(frame)
    #уникальные аргументы для данной команды
    frame.add_argument("path", help="Путь к видео")
    frame.add_argument("--index", type=int, default=1, help="Номер кадра для вывода (начиная с 1)")

    # Команда slideshow
    slideshow = subparsers.add_parser("slideshow")
    # Общие аргументы для всех команд
    addBaseArgumentsToParsers(slideshow)
    #уникальные аргументы для данной команды
    slideshow.add_argument("files", nargs="+", help="Список путей к изображениям")
    slideshow.add_argument("--delay", type=float, default=2.0)
    slideshow.add_argument("--loop", action="store_true", help="Зациклить слайдшоу")

    # Команда stream
    stream = subparsers.add_parser("stream")
    # Общие аргументы для всех команд
    addBaseArgumentsToParsers(stream)
    #уникальные аргументы для данной команды
    stream.add_argument("index", type=int, nargs='?', help="Индекс видеоустройства (например, 0 для первой камеры)")
    stream.add_argument("-l", "--list", action="store_true", help="Показать список доступных устройств")

    args = parser.parse_args()

    #обработка общих команд
    ascii_func = ascii_conversion_5level_of_details 
    asciiStyled = args.ascii

    if args.level == 2:
        ascii_func = ascii_conversion_2level_of_details
    elif args.level == 16:
        ascii_func = ascii_conversion_16level_of_details

    if args.command == "play":
        _, ext = os.path.splitext(args.path)

        if ext.lower() in IMAGE_EXTS:
            if args.output:
                queueManagerThread = threading.Thread(target=queueManager, args=(args,), daemon=True)
                queueManagerThread.start()
            imageToChar(args, ascii_func)
            if args.output:
                queueManagerThread.join()
        elif ext.lower() in VIDEO_EXTS:
            sourceIsVideo = True
            if args.output:
                queueManagerThread = threading.Thread(target=queueManager, args=(args,), daemon=True)
                queueManagerThread.start()
            videoTochar(args, ascii_func)
            if args.output:
                queueManagerThread.join()
        else:
            print("Ошибка расширения файла")
            sys.exit(1)
    
    elif args.command == "frame":
        _, ext = os.path.splitext(args.path)

        if ext.lower() not in VIDEO_EXTS:
            print("Ошибка: для команды frame требуется видеофайл")
            sys.exit(1)
        
        if args.output:
            queueManagerThread = threading.Thread(target=queueManager, args=(args,), daemon=True)
            queueManagerThread.start()
        getFrameToChar(args, ascii_func)
        if args.output:
                queueManagerThread.join()

    elif args.command == "slideshow":

        for imgPath in args.files:
            if not os.path.isfile(imgPath):
                print(f"Ошибка: файл {imgPath} не найден")
                sys.exit(1)
            _, ext = os.path.splitext(imgPath)
            if ext.lower() not in IMAGE_EXTS:
                print(f"Ошибка: файл {imgPath} не является изображением")
                sys.exit(1)
        
        sourceIsVideo = True
        if args.output:
            queueManagerThread = threading.Thread(target=queueManager, args=(args,), daemon=True)
            queueManagerThread.start()
        slideshowToChar(args, ascii_func)
        if args.output:
            queueManagerThread.join()

    elif args.command == "stream":
        sourceIsVideo = True
        if not args.list and args.index is not None:
            if args.output:
                queueManagerThread = threading.Thread(target=queueManager, args=(args,), daemon=True)
                queueManagerThread.start()
            streamToChar(args, ascii_func)
            if args.output:
                queueManagerThread.join()

        elif args.list:
            getListOfAvailableDevices()
        else:
            print("Ошибка: для команды stream необходимо указать индекс устройства или использовать флаг --list")
            sys.exit(1)

if __name__ == "__main__":
    main()
