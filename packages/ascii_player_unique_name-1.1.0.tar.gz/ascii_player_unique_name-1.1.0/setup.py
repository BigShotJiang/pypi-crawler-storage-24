from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ascii-player-unique-name",
    version="1.1.0",
    py_modules=["videoPlayer"],
    description="Fast ASCII video player and streaming engine with virtual camera support",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True, # Обязательно для работы MANIFEST.in
    package_data={
        "": ["assets/*.ttf"], # Явно указываем шрифты
    },
    install_requires=[
        "opencv-python",
        "numpy",
        "pillow",
        "colorama",
        "pyvirtualcam",
        "pygrabber",
    ],
    entry_points={
        'console_scripts': [
            'ascii=videoPlayer:main',
        ],
    },
)