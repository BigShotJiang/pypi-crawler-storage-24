"""Replay and anchor orchestration helpers extracted from `hiveos.observe`."""

from __future__ import annotations

import json


def _infer_transition(anchor_category):
    category = str(anchor_category or "").strip().lower()
    if category == "checkpoint.state":
        return ("checkpoint.resume", "decision")
    if category == "tool.result":
        return ("tool_result.resume", "decision")
    if category == "model.response":
        return ("model_response.resume", "decision")
    if category == "output.commit":
        return ("response_resume", "turn.finish")
    if category == "decision.branch":
        return ("decision_resume", "step.generic")
    if category == "step.generic":
        return ("step_resume", "step.generic")
    return ("unknown", "unknown")


def _build_resume_envelope(
    *,
    base_run_id,
    from_step_id,
    from_checkpoint_id,
    anchor_category,
    validation_mode,
    validation_checks,
):
    anchor_id = str(from_checkpoint_id or from_step_id or "").strip() or None
    anchor_type = "checkpoint_id" if from_checkpoint_id else ("step_id" if from_step_id else None)
    closure_status = "pass" if bool(anchor_id) else "fail"
    closure_reasons = [] if bool(anchor_id) else ["anchor required for replayable resume boundary"]
    resume_phase, next_transition = _infer_transition(anchor_category)
    if not anchor_id:
        resume_phase = "unknown"
        next_transition = "unknown"
    state_sufficiency = "insufficient"
    committed_state_ref = "none"
    if from_checkpoint_id:
        state_sufficiency = "full"
        committed_state_ref = f"checkpoint://{from_checkpoint_id}"
    elif from_step_id:
        state_sufficiency = "partial"
        committed_state_ref = f"step://{from_step_id}"
    rank = "weak_anchor"
    score = 0.25
    rationale = []
    if state_sufficiency == "full" and closure_status == "pass":
        rank = "stable_anchor"
        score = 0.95
        rationale.append("checkpoint boundary with full state sufficiency")
    elif state_sufficiency == "partial" and closure_status == "pass":
        rank = "semi_stable_anchor"
        score = 0.65
        rationale.append("step boundary with partial state sufficiency")
    else:
        rationale.append("anchor/state requirements not fully satisfied")
    if str(validation_mode or "").strip().lower() == "deterministic":
        score = min(1.0, score + 0.05)
        rationale.append("deterministic validation mode selected")
    admission_reasons = []
    if closure_status != "pass":
        admission_reasons.append("historical closure failed")
    if str(resume_phase) == "unknown" or str(next_transition) == "unknown":
        admission_reasons.append("transitional clarity unavailable")
    if str(state_sufficiency) == "insufficient":
        admission_reasons.append("state sufficiency is insufficient")
    if str((validation_checks or {}).get("status") or "").strip().lower() == "fail":
        admission_reasons.append("validation checks failed")
    return {
        "resume_contract_version": "1.0",
        "parent_run_id": base_run_id,
        "anchor_id": anchor_id,
        "anchor_ref_type": anchor_type,
        "boundary_type": anchor_category or None,
        "historical_closure": {"status": closure_status, "reasons": closure_reasons},
        "transition": {
            "resume_phase": resume_phase,
            "next_expected_transition": next_transition,
        },
        "state": {
            "committed_state_ref": committed_state_ref,
            "state_sufficiency": state_sufficiency,
        },
        "side_effects": {
            "unresolved_count": 0 if closure_status == "pass" else 1,
            "idempotency_risk": "unknown" if state_sufficiency != "full" else "low",
        },
        "stability": {
            "rank": rank,
            "score": float(score),
            "rationale": rationale,
        },
        "validation_mode": validation_mode,
        "admission": {
            "allowed": len(admission_reasons) == 0,
            "reasons": admission_reasons,
        },
    }


def canonical_anchor_type_for_event(event):
    event_type = str(event.get("event_type") or "").strip()
    if event_type == "observe_checkpoint":
        return "checkpoint.state"
    if event_type == "observe_output":
        return "output.commit"
    if event_type != "observe_step":
        return None
    step_type = str(event.get("step_type") or "").strip().lower()
    payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
    phase = str(payload.get("phase") or "").strip().lower()
    if step_type == "branch":
        return "decision.branch"
    if step_type == "tool_call":
        if phase == "start":
            return "tool.request"
        if phase == "end":
            return "tool.result"
        return "tool.result"
    if step_type in {"model", "llm"}:
        if phase in {"start", "request"}:
            return "model.request"
        if phase in {"end", "response"}:
            return "model.response"
    return "step.generic"


def run_has_step_id(run_id, step_id, *, event_limit=50000, read_run_record, read_trace_events_for_run, read_trace_events):
    rid = str(run_id or "").strip()
    sid = str(step_id or "").strip()
    if not rid or not sid:
        return False
    record = read_run_record(rid) or {}
    preferred_log = str(record.get("trace_log_path") or "").strip()
    events = read_trace_events_for_run(rid, limit=max(1, min(50000, int(event_limit))), trace_log_path=preferred_log)
    if not events:
        events = read_trace_events(limit=max(1, min(50000, int(event_limit))), filters={"run_id": rid})
    for event in events:
        if str(event.get("step_id") or "").strip() == sid:
            return True
    return False


def run_has_checkpoint_id(
    run_id,
    checkpoint_id,
    *,
    event_limit=50000,
    read_run_record,
    read_trace_events_for_run,
    read_trace_events,
):
    rid = str(run_id or "").strip()
    cid = str(checkpoint_id or "").strip()
    if not rid or not cid:
        return False
    record = read_run_record(rid) or {}
    preferred_log = str(record.get("trace_log_path") or "").strip()
    events = read_trace_events_for_run(rid, limit=max(1, min(50000, int(event_limit))), trace_log_path=preferred_log)
    if not events:
        events = read_trace_events(limit=max(1, min(50000, int(event_limit))), filters={"run_id": rid})
    for event in events:
        if str(event.get("event_type") or "") != "observe_checkpoint":
            continue
        payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
        if str(payload.get("checkpoint_id") or "").strip() == cid:
            return True
    return False


def resolve_replay_plan(
    args,
    *,
    read_run_record,
    run_has_step_id,
    run_has_checkpoint_id,
    resolve_ui_url_for_command,
    collect_run_anchors_fn=None,
):
    base_run_id = str(args.run_id or "").strip()
    if not base_run_id:
        raise SystemExit("run_id is required")
    base = read_run_record(base_run_id)
    if not base:
        raise SystemExit(f"run_id not found: {base_run_id}")
    base_argv = base.get("argv")
    if isinstance(base_argv, list) and base_argv:
        replay_command = [str(part) for part in base_argv if str(part)]
    else:
        replay_command = str(base.get("command") or "").strip()
    if not replay_command:
        raise SystemExit(f"run command missing for run_id: {base_run_id}")
    run_name = str(args.run_name or "").strip()
    if not run_name:
        run_name = f"replay:{base_run_id}"
    from_step_id = str(getattr(args, "from_step_id", "") or "").strip()
    from_checkpoint_id = str(getattr(args, "from_checkpoint_id", "") or "").strip()
    use_recommended = bool(getattr(args, "recommended", False))
    validation_mode = str(getattr(args, "validation_mode", "") or "tolerant").strip().lower()
    if validation_mode not in {"deterministic", "tolerant"}:
        raise SystemExit("validation_mode must be one of: deterministic, tolerant")
    if use_recommended and (from_step_id or from_checkpoint_id):
        raise SystemExit("--recommended cannot be combined with explicit anchor flags")
    recommendation_used = {}
    if use_recommended and (not from_step_id) and (not from_checkpoint_id):
        if collect_run_anchors_fn is None:
            raise SystemExit("recommended anchor resolution unavailable")
        anchors_payload = collect_run_anchors_fn(base_run_id, event_limit=5000) or {}
        recommended = list(anchors_payload.get("recommended_replay_anchors") or [])
        selected = None
        for item in recommended:
            if bool(item.get("admission_allowed")):
                selected = item
                break
        if not selected:
            raise SystemExit("no admissible recommended replay anchors found on source run")
        from_checkpoint_id = str(selected.get("from_checkpoint_id") or "").strip()
        from_step_id = str(selected.get("from_step_id") or "").strip()
        recommendation_used = {
            "anchor_id": str(selected.get("anchor_id") or "").strip() or None,
            "anchor_type": str(selected.get("anchor_type") or "").strip() or None,
            "stability_rank": str(selected.get("stability_rank") or "").strip() or None,
            "stability_score": float(selected.get("stability_score") or 0.0),
            "admission_allowed": bool(selected.get("admission_allowed")),
        }
        if from_checkpoint_id:
            recommendation_used["anchor_ref_type"] = "checkpoint_id"
        elif from_step_id:
            recommendation_used["anchor_ref_type"] = "step_id"
    if from_step_id and from_checkpoint_id:
        raise SystemExit("Choose only one of --from-step-id or --from-checkpoint-id")
    if validation_mode == "deterministic" and (not from_step_id) and (not from_checkpoint_id):
        raise SystemExit("deterministic validation-mode requires --from-step-id or --from-checkpoint-id")
    if from_step_id and not run_has_step_id(base_run_id, from_step_id):
        raise SystemExit(f"step_id not found on source run: {from_step_id}")
    if from_checkpoint_id and not run_has_checkpoint_id(base_run_id, from_checkpoint_id):
        raise SystemExit(f"checkpoint_id not found on source run: {from_checkpoint_id}")
    raw_selected = list(getattr(args, "select_step", []) or [])
    if raw_selected and from_checkpoint_id:
        raise SystemExit("--select-step cannot be used with --from-checkpoint-id")
    if raw_selected and not from_step_id:
        raise SystemExit("--select-step currently requires --from-step-id")
    selected_steps = []
    seen_selected = set()
    for raw in raw_selected:
        sid = str(raw or "").strip()
        if not sid or sid in seen_selected:
            continue
        if not run_has_step_id(base_run_id, sid):
            raise SystemExit(f"selected step_id not found on source run: {sid}")
        seen_selected.add(sid)
        selected_steps.append(sid)
    replay_cwd = str(args.cwd or "").strip() or str(base.get("cwd") or "").strip() or None
    record_fields = {
        "replay_of_run_id": base_run_id,
        "source": "replay",
        "replay_validation_mode": validation_mode,
    }
    if from_step_id:
        record_fields["replay_from_step_id"] = from_step_id
        record_fields["replay_anchor_type"] = "step_id"
        record_fields["replay_anchor_category"] = "step.generic"
    if from_checkpoint_id:
        record_fields["replay_from_checkpoint_id"] = from_checkpoint_id
        record_fields["replay_anchor_type"] = "checkpoint_id"
        record_fields["replay_anchor_category"] = "checkpoint.state"
    anchor_category = None
    if from_checkpoint_id:
        anchor_category = "checkpoint.state"
    elif from_step_id:
        anchor_category = "step.generic"
    branch_preview = {
        "mode": "selected_subgraph_preview" if selected_steps else "full_replay_preview",
        "selected_step_ids": selected_steps,
        "preview_only": bool(selected_steps),
        "selection_validation": {
            "anchor_step_id": from_step_id or None,
            "requires_anchor_step": bool(selected_steps),
            "selected_count": len(selected_steps),
        },
    }
    validation_checks = {
        "mode": validation_mode,
        "anchor_present": bool(from_step_id or from_checkpoint_id),
        "anchor_type": "checkpoint_id" if from_checkpoint_id else ("step_id" if from_step_id else None),
        "selected_step_count": len(selected_steps),
        "status": "pass",
        "notes": [],
    }
    if validation_mode == "deterministic":
        if not validation_checks["anchor_present"]:
            validation_checks["status"] = "fail"
            validation_checks["notes"].append("anchor required for deterministic mode")
        else:
            validation_checks["notes"].append("anchor present")
    else:
        validation_checks["notes"].append("tolerant mode allows non-anchored replay")
    if selected_steps:
        record_fields["replay_selected_step_ids"] = list(selected_steps)
    if recommendation_used:
        record_fields["replay_recommended_anchor"] = dict(recommendation_used)
    resume_envelope = _build_resume_envelope(
        base_run_id=base_run_id,
        from_step_id=from_step_id,
        from_checkpoint_id=from_checkpoint_id,
        anchor_category=anchor_category,
        validation_mode=validation_mode,
        validation_checks=validation_checks,
    )
    return {
        "base_run_id": base_run_id,
        "replay_command": replay_command,
        "run_name": run_name,
        "replay_cwd": replay_cwd,
        "from_step_id": from_step_id,
        "from_checkpoint_id": from_checkpoint_id,
        "validation_mode": validation_mode,
        "validation_checks": validation_checks,
        "anchor_category": anchor_category,
        "branch_preview": branch_preview,
        "resume_envelope": resume_envelope,
        "recommendation_used": recommendation_used,
        "record_fields": record_fields,
        "ui_url": resolve_ui_url_for_command(args),
    }


def execute_replay_from_plan(plan, *, timeout_sec=None, run_command_observed, build_ui_url):
    result = run_command_observed(
        plan["replay_command"],
        run_name=plan["run_name"],
        cwd=plan["replay_cwd"],
        timeout_sec=timeout_sec,
        agent_id="observer.replay",
        open_ui_url=plan["ui_url"],
        record_fields=plan["record_fields"],
    )
    line = (
        f"run_id={result['run_id']} status={result['status']} duration_ms={result['duration_ms']} "
        f"replay_of={plan['base_run_id']}"
    )
    if plan["from_step_id"]:
        line += f" from_step_id={plan['from_step_id']}"
    if plan["from_checkpoint_id"]:
        line += f" from_checkpoint_id={plan['from_checkpoint_id']}"
    if plan.get("anchor_category"):
        line += f" anchor_type={plan['anchor_category']}"
    line += f" validation_mode={plan['validation_mode']}"
    checks = plan.get("validation_checks") if isinstance(plan.get("validation_checks"), dict) else {}
    if checks:
        line += f" validation_status={checks.get('status')}"
    print(line)
    if plan["ui_url"]:
        print(f"ui={build_ui_url(plan['ui_url'], result['run_id'])}")
    return int(result["exit_code"])


def handle_trace_replay(args, *, resolve_replay_plan_fn, execute_replay_from_plan_fn):
    plan = resolve_replay_plan_fn(args)
    return execute_replay_from_plan_fn(plan, timeout_sec=args.timeout_sec or None)


def handle_trace_replay_plan(
    args,
    *,
    resolve_replay_plan_fn,
    execute_replay_from_plan_fn,
    write_replay_plan_artifact_fn=None,
):
    plan = resolve_replay_plan_fn(args)
    payload = {
        "replay_of_run_id": plan["base_run_id"],
        "run_name": plan["run_name"],
        "replay_command": plan["replay_command"],
        "replay_cwd": plan["replay_cwd"],
        "from_step_id": plan["from_step_id"] or None,
        "from_checkpoint_id": plan["from_checkpoint_id"] or None,
        "validation_mode": plan["validation_mode"],
        "validation_checks": plan.get("validation_checks") or {},
        "anchor_type": plan.get("anchor_category") or None,
        "branch_preview": plan.get("branch_preview") or {},
        "resume_envelope": plan.get("resume_envelope") or {},
        "recommendation_used": plan.get("recommendation_used") or {},
        "record_fields": plan["record_fields"],
        "source_window": {
            "source_run_id": plan["base_run_id"],
            "anchor": {
                "anchor_type": "checkpoint_id"
                if plan["from_checkpoint_id"]
                else ("step_id" if plan["from_step_id"] else None),
                "anchor_id": plan["from_checkpoint_id"] or plan["from_step_id"] or None,
                "canonical_anchor_type": plan.get("anchor_category") or None,
            },
            "selected_step_ids": list(
                ((plan.get("branch_preview") or {}).get("selected_step_ids") or [])
            ),
            "selection_mode": str(((plan.get("branch_preview") or {}).get("mode") or "")).strip() or None,
            "validation_mode": plan["validation_mode"],
        },
        "does_execute": False,
    }
    emit_artifact = bool(getattr(args, "emit_artifact", False))
    artifact_path = str(getattr(args, "artifact_path", "") or "").strip()
    if artifact_path:
        emit_artifact = True
    if emit_artifact:
        if write_replay_plan_artifact_fn is None:
            raise SystemExit("replay-plan artifact writer is unavailable")
        payload["artifact_path"] = write_replay_plan_artifact_fn(payload, artifact_path=artifact_path)
    if bool(args.apply):
        if bool(args.json):
            raise SystemExit("Choose only one of --apply or --json")
        if bool((plan.get("branch_preview") or {}).get("preview_only")):
            raise SystemExit("--select-step is preview-only in replay-plan for now; rerun without --apply")
        resume_envelope = payload.get("resume_envelope") if isinstance(payload.get("resume_envelope"), dict) else {}
        admission = resume_envelope.get("admission") if isinstance(resume_envelope.get("admission"), dict) else {}
        if not bool(admission.get("allowed")):
            reasons = ", ".join([str(item) for item in (admission.get("reasons") or []) if str(item).strip()]) or "resume admission failed"
            raise SystemExit(f"replay admission denied: {reasons}")
        if payload.get("artifact_path"):
            print(f"artifact={payload['artifact_path']}")
        return execute_replay_from_plan_fn(plan, timeout_sec=args.timeout_sec or None)
    if args.json:
        print(json.dumps(payload, separators=(",", ":")))
        return 0
    print(
        f"replay_of={payload['replay_of_run_id']} run_name={payload['run_name']} "
        f"anchor_step={payload['from_step_id']} anchor_checkpoint={payload['from_checkpoint_id']} "
        f"anchor_type={payload['anchor_type']} validation_mode={payload['validation_mode']}"
    )
    checks = payload.get("validation_checks") if isinstance(payload.get("validation_checks"), dict) else {}
    if checks:
        notes = ",".join([str(item) for item in (checks.get("notes") or []) if str(item).strip()]) or "-"
        print(f"validation_status={checks.get('status')} validation_notes={notes}")
    resume_envelope = payload.get("resume_envelope") if isinstance(payload.get("resume_envelope"), dict) else {}
    if resume_envelope:
        admission = resume_envelope.get("admission") if isinstance(resume_envelope.get("admission"), dict) else {}
        print(
            f"resume_admission={bool(admission.get('allowed'))} "
            f"stability_rank={((resume_envelope.get('stability') or {}).get('rank'))}"
        )
    recommendation = payload.get("recommendation_used") if isinstance(payload.get("recommendation_used"), dict) else {}
    if recommendation:
        print(
            f"recommended_anchor={recommendation.get('anchor_id')} "
            f"recommended_rank={recommendation.get('stability_rank')}"
        )
    branch = payload.get("branch_preview") if isinstance(payload.get("branch_preview"), dict) else {}
    if branch:
        selected = ",".join([str(item) for item in (branch.get("selected_step_ids") or []) if str(item).strip()]) or "-"
        print(f"branch_mode={branch.get('mode')} selected_steps={selected} preview_only={bool(branch.get('preview_only'))}")
    if payload.get("artifact_path"):
        print(f"artifact={payload['artifact_path']}")
    print(f"command={payload['replay_command']}")
    print(f"cwd={payload['replay_cwd']}")
    print("next=hive trace replay <run_id> [--from-step-id <id> | --from-checkpoint-id <id>] --no-open")
    return 0


def collect_run_anchors(run_id, *, event_limit=5000, read_run_record, read_trace_events_for_run, read_trace_events):
    rid = str(run_id or "").strip()
    if not rid:
        raise ValueError("run_id is required")
    limit = max(1, min(50000, int(event_limit or 5000)))
    record = read_run_record(rid) or {}
    preferred_log = str(record.get("trace_log_path") or "").strip()
    events = read_trace_events_for_run(rid, limit=limit, trace_log_path=preferred_log)
    if not events:
        events = read_trace_events(limit=limit, filters={"run_id": rid})
    step_ids = []
    step_seen = set()
    checkpoint_ids = []
    ckpt_seen = set()
    anchors = []
    anchor_seen = set()
    step_anchor_types = {}
    anchor_type_counts = {}
    for event in events:
        anchor_type = canonical_anchor_type_for_event(event)
        step_id = str(event.get("step_id") or "").strip()
        if step_id and step_id not in step_seen:
            step_seen.add(step_id)
            step_ids.append(step_id)
        if step_id and anchor_type:
            types = step_anchor_types.setdefault(step_id, [])
            if anchor_type not in types:
                types.append(anchor_type)
        if str(event.get("event_type") or "") == "observe_checkpoint":
            payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
            checkpoint_id = str(payload.get("checkpoint_id") or "").strip()
            if checkpoint_id and checkpoint_id not in ckpt_seen:
                ckpt_seen.add(checkpoint_id)
                checkpoint_ids.append(checkpoint_id)
        anchor_id = ""
        checkpoint_id = ""
        tool_call_id = str(event.get("tool_call_id") or "").strip()
        if str(event.get("event_type") or "") == "observe_checkpoint":
            payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
            checkpoint_id = str(payload.get("checkpoint_id") or "").strip()
            anchor_id = checkpoint_id
        elif step_id:
            anchor_id = step_id
        if anchor_type and anchor_id:
            key = (anchor_type, anchor_id)
            if key not in anchor_seen:
                anchor_seen.add(key)
                anchors.append(
                    {
                        "anchor_id": anchor_id,
                        "anchor_type": anchor_type,
                        "step_id": step_id or None,
                        "checkpoint_id": checkpoint_id or None,
                        "tool_call_id": tool_call_id or None,
                        "event_type": str(event.get("event_type") or ""),
                        "timestamp": str(event.get("timestamp") or ""),
                    }
                )
            anchor_type_counts[anchor_type] = int(anchor_type_counts.get(anchor_type) or 0) + 1
    recommended = []
    for anchor in anchors:
        checkpoint_id = str(anchor.get("checkpoint_id") or "").strip()
        step_id = str(anchor.get("step_id") or "").strip()
        resume = _build_resume_envelope(
            base_run_id=rid,
            from_step_id=step_id if (not checkpoint_id) else "",
            from_checkpoint_id=checkpoint_id,
            anchor_category=str(anchor.get("anchor_type") or "").strip(),
            validation_mode="tolerant",
            validation_checks={"status": "pass"},
        )
        stability = resume.get("stability") if isinstance(resume.get("stability"), dict) else {}
        admission = resume.get("admission") if isinstance(resume.get("admission"), dict) else {}
        recommended.append(
            {
                "anchor_id": str(anchor.get("anchor_id") or "").strip(),
                "anchor_type": str(anchor.get("anchor_type") or "").strip(),
                "timestamp": str(anchor.get("timestamp") or "").strip() or None,
                "from_step_id": step_id or None,
                "from_checkpoint_id": checkpoint_id or None,
                "stability_rank": str(stability.get("rank") or "").strip() or "weak_anchor",
                "stability_score": float(stability.get("score") or 0.0),
                "admission_allowed": bool(admission.get("allowed")),
                "admission_reasons": list(admission.get("reasons") or []),
            }
        )
    recommended.sort(
        key=lambda item: (
            int(bool(item.get("admission_allowed"))),
            float(item.get("stability_score") or 0.0),
            str(item.get("timestamp") or ""),
        ),
        reverse=True,
    )
    return {
        "run_id": rid,
        "step_ids": step_ids,
        "checkpoint_ids": checkpoint_ids,
        "step_count": len(step_ids),
        "checkpoint_count": len(checkpoint_ids),
        "anchors": anchors,
        "anchor_count": len(anchors),
        "step_anchor_types": step_anchor_types,
        "anchor_type_counts": anchor_type_counts,
        "recommended_replay_anchors": recommended[:10],
    }


def handle_trace_anchors(args, *, maybe_auto_reconcile, read_run_record, collect_run_anchors_fn):
    maybe_auto_reconcile()
    run_id = str(args.run_id or "").strip()
    if not run_id:
        raise SystemExit("run_id is required")
    record = read_run_record(run_id)
    if not record:
        raise SystemExit(f"run_id not found: {run_id}")
    payload = collect_run_anchors_fn(run_id, event_limit=args.event_limit)
    if args.json:
        print(json.dumps(payload, separators=(",", ":")))
        return 0
    print(
        f"run_id={payload['run_id']} step_count={payload['step_count']} checkpoint_count={payload['checkpoint_count']} "
        f"anchor_count={int(payload.get('anchor_count') or 0)}"
    )
    if payload["step_ids"]:
        print("step_ids:")
        for item in payload["step_ids"]:
            print(f"  {item}")
    if payload["checkpoint_ids"]:
        print("checkpoint_ids:")
        for item in payload["checkpoint_ids"]:
            print(f"  {item}")
    recommended = list(payload.get("recommended_replay_anchors") or [])
    if recommended:
        print("recommended_replay_anchors:")
        for item in recommended[:5]:
            print(
                f"  anchor_id={item.get('anchor_id')} anchor_type={item.get('anchor_type')} "
                f"rank={item.get('stability_rank')} score={item.get('stability_score')} "
                f"admission={item.get('admission_allowed')}"
            )
    if (not payload["step_ids"]) and (not payload["checkpoint_ids"]):
        print("No anchors found on run.")
    return 0
