<div align="center">

# 🍍 Pineapplee

<p><strong>A clean, fast, local file server — right in your browser.</strong></p>

<p>
  <a href="https://pypi.org/project/pineapplee/"><img src="https://img.shields.io/pypi/v/pineapplee?color=f59e0b&logo=python&logoColor=white" alt="PyPI version"></a>
  <a href="https://pypi.org/project/pineapplee/"><img src="https://img.shields.io/pypi/pyversions/pineapplee?color=3b82f6" alt="Python"></a>
  <a href="https://pypi.org/project/pineapplee/"><img src="https://img.shields.io/pypi/dm/pineapplee?color=8b5cf6" alt="Downloads"></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-10b981.svg" alt="License: MIT"></a>
</p>

<p>
  <a href="https://pypi.org/project/pineapplee/">PyPI</a> ·
  <a href="https://github.com/ApoorvDixitt/Pinapplee">GitHub</a> ·
  <a href="https://github.com/ApoorvDixitt/Pinapplee/issues">Report a Bug</a>
</p>

</div>

---

Pineapplee turns any folder on your machine into a shareable web interface — browse, upload, download, and manage files from any device on your network, or share publicly with a single flag.

---

## ✨ Features

| | |
|---|---|
| 📁 **Browse & Navigate** | Clean file listing with sortable columns, breadcrumb trail, and folder navigation |
| ⬆️ **Upload** | Drag-and-drop files or entire folders — with real-time progress |
| ⬇️ **Download** | Single files or bulk ZIP archives |
| 👁️ **Preview** | Images, video, audio, PDFs, and text files — all in-browser |
| ✏️ **Rename & Delete** | Manage files without leaving the browser |
| 🌍 **Public Share** | One flag to expose your server publicly via Cloudflare Tunnel — no account needed |
| 🔒 **Safe by default** | Path traversal protection, symlink validation, upload size limits |

---

## 🚀 Quick Start

```bash
pip install pineapplee
```

Already installed? Stay up to date:

```bash
pip install --upgrade pineapplee
```

```bash
# Serve the current directory
pineapplee

# Serve a specific path
pineapplee ~/Downloads

# Different port
pineapplee --port 9000

# Share publicly over the internet
pineapplee --public

# Check installed version
pineapplee --version
```

Open **`http://localhost:8089`** — and you're in.

---

## 📖 Usage

```
usage: pineapplee [-h] [-v] [--port PORT] [--public] [directory]

positional arguments:
  directory         Directory to serve (default: current directory)

options:
  -h, --help        show this help message and exit
  -v, --version     show installed version and exit
  --port, -p      Port to listen on (default: 8089)
  --public        Expose publicly via Cloudflare Tunnel
```

### Local network sharing

Pineapple binds to `0.0.0.0`, so any device on your LAN can reach it at the Network URL printed in the terminal:

```
  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
  ┃ 🍍 Pineapple File Server                  ┃
  ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
  ┃                                           ┃
  ┃   📂 Serving     /Users/you/Documents     ┃
  ┃   🔗 Local       http://localhost:8089    ┃
  ┃   🌐 Network     http://192.168.1.5:8089  ┃
  ┃   📦 Max upload  500 MB                   ┃
  ┃                                           ┃
  ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
  ┃   Press Ctrl+C to stop                    ┃
  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
```

### Public sharing

```bash
pineapplee --public
```

On first run this downloads the `cloudflared` binary (~50 MB, cached to `~/.pineapplee/bin/`). A public `trycloudflare.com` URL is printed — share it with anyone, anywhere.

---

## 🔒 Security

- All file paths are validated and confined to the served directory
- Symlinks pointing outside the root are silently ignored
- Upload size capped at 500 MB by default
- Hidden files (dotfiles, `__pycache__`, `node_modules`, `.egg-info`, etc.) are never shown

> **Note:** Pineapple is designed for local and trusted-network use. Do not expose it to the public internet without understanding the implications.

---

## 📋 Requirements

- Python ≥ 3.8
- Flask ≥ 2.0

---

## 📄 License

MIT © [KalaaKaar](https://github.com/ApoorvDixitt)
