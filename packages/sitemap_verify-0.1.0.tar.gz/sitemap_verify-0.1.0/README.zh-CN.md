# sitemap-verify（中文说明）

用于验证 Sitemap 协议合规性并检查 URL 可达性的 Python 3.10+ 工具/库。

## 功能

- 异步库 API：`validate_target(...)`
- CLI 命令：`sitemap-verify check <target>`
- 基于 SQLite 的运行期持久化，适合长时间 sitemap 检查
- 支持通过 `--resume-from <sqlite 文件>` 恢复中断任务
- 支持输入类型：XML `urlset`、`sitemapindex`、text sitemap、RSS、Atom
- 结合 XSD（`xmlschema`）与协议语义校验
- 默认递归处理 sitemap 索引，并支持深度/数量限制
- URL 可达性分级：
  - `2xx` => 通过
  - `3xx` / `429` => `warn`
  - `4xx` / `5xx` / 网络错误 => `error`
- 统一 `error` / `warn` 报告，支持 JSON 输出

## 环境要求

- Python 3.10+
- `uv`（依赖与环境管理）

## 快速开始

```bash
uv sync --dev
uv run sitemap-verify check path/to/sitemap.xml
```

从 PyPI 安装：

```bash
pip install sitemap-verify
```

校验远程 sitemap：

```bash
uv run sitemap-verify check https://example.com/sitemap.xml --mode url --format json
```

按域名校验（先读 `robots.txt`，找不到则回退 `/sitemap.xml`）：

```bash
uv run sitemap-verify check example.com --mode domain
```

开启日志、进度并写入结果文件：

```bash
uv run sitemap-verify check https://example.com/sitemap.xml \
  --mode url \
  --probe-method get \
  --format json \
  --output reports/result.json \
  --log-file logs/run.log \
  --verbose \
  --show-progress
```

将运行状态写入 SQLite，并在异常中断后恢复：

```bash
uv run sitemap-verify check https://example.com/sitemap.xml \
  --mode url \
  --store reports/example-run.sqlite3

uv run sitemap-verify check https://example.com/sitemap.xml \
  --mode url \
  --resume-from reports/example-run.sqlite3
```

如果未显式传入 `--store`，CLI 会默认在 `reports/` 下创建带时间戳的 SQLite 文件。
恢复运行时会重新解析 sitemap，但如果 SQLite 中已经存在某个 URL 的可达性结果，
则直接复用并跳过对应网络探测。

## 可达性探测模式

- `--probe-method get`（默认）：始终使用 GET（建议，适合对 HEAD 支持不好的站点）
- `--probe-method head`：仅用 HEAD
- `--probe-method auto`：先 HEAD，若 HEAD 返回 `405/501` 或 `4xx/5xx`（`429` 除外）则回退 GET

## 库调用示例

```python
import asyncio

from sitemap_verify import validate_target


async def main() -> None:
    report = await validate_target(
        "https://example.com/sitemap.xml",
        mode="url",
        recursive=True,
        check_reachability=True,
        probe_method="get",
        store_path="reports/example-run.sqlite3",
    )
    print(report.model_dump())


asyncio.run(main())
```

可选持久化参数：

- `store_path`：将本次校验状态写入指定 SQLite 文件
- `resume_from`：从已有的中断 SQLite 文件恢复，并复用已写入的 URL 可达性结果

如果不传 `store_path`，`validate_target(...)` 会默认在 `reports/` 下生成带时间戳的
SQLite 文件。

## 开发命令

运行测试：

```bash
uv run pytest
```

运行静态检查：

```bash
uv run ruff check .
```

## 项目结构

- `src/sitemap_verify/`：主代码与 CLI 入口
- `src/sitemap_verify/schemas/`：内置 XSD 文件
- `tests/`：自动化测试
- `docs/feat/`：功能设计与计划记录
- `docs/agent-lessons/`：历史经验记录

## 发布流程

- 先更新 `pyproject.toml` 中的 `project.version`
- 将发布相关变更合并到 `main`
- 创建并推送对应版本标签，例如 `v0.1.0`
- GitHub Actions 会使用 `uv` 构建包、运行测试、校验分发产物、执行 `pip install` 冒烟测试，并通过 PyPI Trusted Publishing 发布

示例：

```bash
git tag v0.1.0
git push origin v0.1.0
```

## 许可证

本项目使用 MIT 许可证，详见 `LICENSE`。
