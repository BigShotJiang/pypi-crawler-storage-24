# Contributing

## Setup

```bash
uv sync --dev
```

## Local Checks

Before opening a pull request, run:

```bash
uv run ruff check .
uv run pytest
```

## Pull Requests

- Keep changes focused and minimal
- Add or update tests when behavior changes
- Update `README.md` when commands or user-facing behavior change
- Record recurring fixed agent mistakes in `docs/agent-lessons/` when useful