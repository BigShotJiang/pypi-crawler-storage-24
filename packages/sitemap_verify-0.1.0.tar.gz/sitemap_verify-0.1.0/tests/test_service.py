from __future__ import annotations

from pathlib import Path

import httpx
import pytest

import sitemap_verify.service as service_module
from sitemap_verify import validate_target
from sitemap_verify.loader import probe_url


@pytest.mark.asyncio
async def test_validate_local_urlset(tmp_path: Path) -> None:
    sitemap = tmp_path / "sitemap.xml"
    sitemap.write_text(
        """
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
          <url><loc>https://example.com/</loc></url>
          <url><loc>https://example.com/about</loc></url>
        </urlset>
        """,
        encoding="utf-8",
    )

    report = await validate_target(str(sitemap), check_reachability=False)

    assert report.summary.errors == 0
    assert report.summary.urls_discovered == 2
    assert report.document_kinds == ["urlset"]


@pytest.mark.asyncio
async def test_xsd_error_is_reported(tmp_path: Path) -> None:
    sitemap = tmp_path / "bad.xml"
    sitemap.write_text(
        """
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
          <url><lastmod>2026-01-01</lastmod></url>
        </urlset>
        """,
        encoding="utf-8",
    )

    report = await validate_target(str(sitemap), check_reachability=False)

    assert report.summary.errors > 0
    assert any(item.code == "xsd_validation" for item in report.diagnostics)


@pytest.mark.asyncio
async def test_reachability_severity_with_pytest_httpx(httpx_mock) -> None:
    sitemap_url = "https://example.com/sitemap.xml"
    redirected_url = "https://example.com/redirect"
    broken_url = "https://example.com/missing"
    throttled_url = "https://example.com/throttled"
    ok_url = "https://example.com/"

    httpx_mock.add_response(
        method="GET",
        url=sitemap_url,
        text=(
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            f"<url><loc>{ok_url}</loc></url>"
            f"<url><loc>{redirected_url}</loc></url>"
            f"<url><loc>{throttled_url}</loc></url>"
            f"<url><loc>{broken_url}</loc></url>"
            "</urlset>"
        ),
    )
    httpx_mock.add_response(method="HEAD", url=ok_url, status_code=200)
    httpx_mock.add_response(method="HEAD", url=redirected_url, status_code=301)
    httpx_mock.add_response(method="HEAD", url=throttled_url, status_code=429)
    httpx_mock.add_response(method="HEAD", url=broken_url, status_code=404)
    httpx_mock.add_response(method="GET", url=broken_url, status_code=404)

    report = await validate_target(
        sitemap_url,
        mode="url",
        check_reachability=True,
        probe_method="auto",
    )

    checks = {item.url: item.level for item in report.url_checks}
    assert checks[ok_url] == "ok"
    assert checks[redirected_url] == "warn"
    assert checks[throttled_url] == "warn"
    assert checks[broken_url] == "error"


@pytest.mark.asyncio
async def test_reachability_fallback_from_head_404_to_get_200(httpx_mock) -> None:
    sitemap_url = "https://example.com/sitemap.xml"
    flaky_head_url = "https://example.com/head-unsupported"

    httpx_mock.add_response(
        method="GET",
        url=sitemap_url,
        text=(
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            f"<url><loc>{flaky_head_url}</loc></url>"
            "</urlset>"
        ),
    )
    httpx_mock.add_response(method="HEAD", url=flaky_head_url, status_code=404)
    httpx_mock.add_response(method="GET", url=flaky_head_url, status_code=200)

    report = await validate_target(
        sitemap_url,
        mode="url",
        check_reachability=True,
        probe_method="auto",
    )
    checks = {item.url: item.level for item in report.url_checks}
    assert checks[flaky_head_url] == "ok"


@pytest.mark.asyncio
async def test_reachability_default_get_mode(httpx_mock) -> None:
    sitemap_url = "https://example.com/sitemap.xml"
    url = "https://example.com/only-get"
    httpx_mock.add_response(
        method="GET",
        url=sitemap_url,
        text=(
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            f"<url><loc>{url}</loc></url>"
            "</urlset>"
        ),
    )
    httpx_mock.add_response(method="GET", url=url, status_code=200)

    report = await validate_target(sitemap_url, mode="url", check_reachability=True)
    checks = {item.url: item.level for item in report.url_checks}
    assert checks[url] == "ok"


@pytest.mark.asyncio
async def test_probe_url_returns_non_empty_error_message_for_empty_httpx_message() -> None:
    async def _handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("", request=request)

    transport = httpx.MockTransport(_handler)
    async with httpx.AsyncClient(transport=transport) as client:
        status, error = await probe_url(client, "https://example.com/fail", probe_method="get")

    assert status is None
    assert error == "ReadTimeout"


@pytest.mark.asyncio
async def test_reachability_empty_error_message_does_not_crash(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sitemap = tmp_path / "empty-error.xml"
    url = "https://example.com/empty-message"
    sitemap.write_text(
        (
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            f"<url><loc>{url}</loc></url>"
            "</urlset>"
        ),
        encoding="utf-8",
    )

    async def _fake_probe_url(*_args, **_kwargs) -> tuple[int | None, str | None]:
        return None, ""

    monkeypatch.setattr(service_module, "probe_url", _fake_probe_url)

    report = await validate_target(str(sitemap), check_reachability=True, probe_method="get")

    assert len(report.url_checks) == 1
    assert report.url_checks[0].url == url
    assert report.url_checks[0].level == "error"
    assert report.url_checks[0].message == "HTTP probe failed: unknown error."
    assert any(
        item.code == "url_reachability" and item.location == url
        for item in report.diagnostics
    )


@pytest.mark.asyncio
async def test_reachability_worker_exception_is_converted_to_error_result(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sitemap = tmp_path / "worker-exception.xml"
    url = "https://example.com/unexpected-error"
    sitemap.write_text(
        (
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            f"<url><loc>{url}</loc></url>"
            "</urlset>"
        ),
        encoding="utf-8",
    )

    async def _boom_probe_url(*_args, **_kwargs) -> tuple[int | None, str | None]:
        raise RuntimeError("boom")

    monkeypatch.setattr(service_module, "probe_url", _boom_probe_url)

    report = await validate_target(str(sitemap), check_reachability=True, probe_method="get")

    assert len(report.url_checks) == 1
    assert report.url_checks[0].level == "error"
    assert "Unexpected reachability failure (RuntimeError): boom" in report.url_checks[0].message
    assert any(
        item.code == "url_reachability" and item.location == url
        for item in report.diagnostics
    )


@pytest.mark.asyncio
async def test_recursive_sitemap_index(httpx_mock) -> None:
    index_url = "https://example.com/sitemap.xml"
    child_url = "https://example.com/child.xml"

    httpx_mock.add_response(
        method="GET",
        url=index_url,
        text=(
            '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            f"<sitemap><loc>{child_url}</loc></sitemap>"
            "</sitemapindex>"
        ),
    )
    httpx_mock.add_response(
        method="GET",
        url=child_url,
        text=(
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            "<url><loc>https://example.com/post</loc></url>"
            "</urlset>"
        ),
    )

    report = await validate_target(index_url, mode="url", recursive=True, check_reachability=False)

    assert report.summary.sitemaps_checked == 2
    assert "https://example.com/post" in report.discovered_urls


@pytest.mark.asyncio
async def test_domain_robots_relative_sitemap(httpx_mock) -> None:
    robots_url = "https://example.com/robots.txt"
    sitemap_url = "https://example.com/nested/sitemap.xml"

    httpx_mock.add_response(
        method="GET",
        url=robots_url,
        text="User-agent: *\nSitemap: /nested/sitemap.xml\n",
    )
    httpx_mock.add_response(
        method="GET",
        url=sitemap_url,
        text=(
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            "<url><loc>https://example.com/a</loc></url>"
            "</urlset>"
        ),
    )

    report = await validate_target("example.com", mode="domain", check_reachability=False)
    assert report.summary.sitemaps_checked == 1
    assert "https://example.com/a" in report.discovered_urls


@pytest.mark.asyncio
async def test_progress_callback_receives_messages(tmp_path: Path) -> None:
    sitemap = tmp_path / "progress.xml"
    sitemap.write_text(
        """
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
          <url><loc>https://example.com/</loc></url>
        </urlset>
        """,
        encoding="utf-8",
    )
    messages: list[str] = []

    await validate_target(
        str(sitemap),
        check_reachability=False,
        progress_callback=messages.append,
    )

    assert any("Resolving target" in item for item in messages)
    assert any("Validated" in item for item in messages)
