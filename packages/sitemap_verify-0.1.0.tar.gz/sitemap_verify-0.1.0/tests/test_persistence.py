from __future__ import annotations

import sqlite3
from collections import defaultdict
from pathlib import Path

import pytest

import sitemap_verify.service as service_module
import sitemap_verify.store as store_module
from sitemap_verify import validate_target


@pytest.mark.asyncio
async def test_validate_target_persists_results_to_sqlite(tmp_path: Path) -> None:
    sitemap = tmp_path / "sitemap.xml"
    store_path = tmp_path / "validation.sqlite3"
    sitemap.write_text(
        """
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
          <url><loc>https://example.com/</loc></url>
          <url><loc>https://example.com/about</loc></url>
        </urlset>
        """,
        encoding="utf-8",
    )

    report = await validate_target(
        str(sitemap),
        check_reachability=False,
        store_path=store_path,
    )

    assert report.summary.urls_discovered == 2
    assert store_path.exists()

    connection = sqlite3.connect(store_path)
    try:
        discovered_count = connection.execute(
            "SELECT COUNT(*) FROM discovered_urls"
        ).fetchone()[0]
        sitemap_count = connection.execute(
            "SELECT COUNT(*) FROM checked_sitemaps"
        ).fetchone()[0]
    finally:
        connection.close()

    assert discovered_count == 2
    assert sitemap_count == 1


@pytest.mark.asyncio
async def test_resume_reuses_cached_url_checks_after_interrupted_run(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sitemap = tmp_path / "resume.xml"
    store_path = tmp_path / "resume.sqlite3"
    first_url = "https://example.com/first"
    second_url = "https://example.com/second"
    sitemap.write_text(
        (
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            f"<url><loc>{first_url}</loc></url>"
            f"<url><loc>{second_url}</loc></url>"
            "</urlset>"
        ),
        encoding="utf-8",
    )

    calls: dict[str, list[str]] = defaultdict(list)
    phase = "first"

    async def _fake_probe_url(*_args, **_kwargs) -> tuple[int | None, str | None]:
        url = _args[1]
        calls[phase].append(url)
        return 200, None

    original_record_url_check = store_module.ValidationStore.record_url_check
    stored_results = 0

    def _record_then_crash(
        self: store_module.ValidationStore,
        result,
    ) -> None:
        nonlocal stored_results
        original_record_url_check(self, result)
        stored_results += 1
        if stored_results == 1:
            raise RuntimeError("simulated interruption")

    monkeypatch.setattr(service_module, "probe_url", _fake_probe_url)
    monkeypatch.setattr(store_module.ValidationStore, "record_url_check", _record_then_crash)

    with pytest.raises(RuntimeError, match="simulated interruption"):
        await validate_target(
            str(sitemap),
            check_reachability=True,
            concurrency=1,
            store_path=store_path,
        )

    monkeypatch.setattr(store_module.ValidationStore, "record_url_check", original_record_url_check)
    phase = "second"

    report = await validate_target(
        str(sitemap),
        check_reachability=True,
        concurrency=1,
        resume_from=store_path,
    )

    assert first_url in calls["first"]
    assert calls["second"] == [second_url]
    assert report.summary.urls_checked == 2
    assert {item.url for item in report.url_checks} == {first_url, second_url}


@pytest.mark.asyncio
async def test_resume_without_reachability_excludes_cached_checks(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sitemap = tmp_path / "no-reachability.xml"
    store_path = tmp_path / "no-reachability.sqlite3"
    url = "https://example.com/only-once"
    sitemap.write_text(
        (
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            f"<url><loc>{url}</loc></url>"
            "</urlset>"
        ),
        encoding="utf-8",
    )

    async def _fake_probe_url(*_args, **_kwargs) -> tuple[int | None, str | None]:
        return 200, None

    monkeypatch.setattr(service_module, "probe_url", _fake_probe_url)

    await validate_target(
        str(sitemap),
        check_reachability=True,
        store_path=store_path,
    )
    report = await validate_target(
        str(sitemap),
        check_reachability=False,
        resume_from=store_path,
    )

    assert report.summary.urls_discovered == 1
    assert report.summary.urls_checked == 0
    assert report.url_checks == []
