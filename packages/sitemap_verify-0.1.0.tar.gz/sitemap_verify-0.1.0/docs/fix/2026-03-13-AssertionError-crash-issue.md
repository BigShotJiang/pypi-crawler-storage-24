# 2026-03-13 AssertionError 崩溃问题（合并版）

## 背景与复现

运行以下命令时程序异常退出：

`uv run sitemap-verify check https://www.coohom.com/sitemap.xml --mode url --format json --probe-method get --output reports/result.json --log-file logs/run.log --verbose true --show-progress --timeout 200`

关键报错堆栈：

```txt
File "D:\seo-ai\sitemap-verify\src\sitemap_verify\service.py", line 257, in _check
  assert status is not None
AssertionError
```

该异常由 `aiometer` 并发任务组包装后向上抛出，导致整批任务失败。

## 根因分析

根因不是编码本身，而是异常契约处理不完整：

1. `probe_url` 异常分支返回 `(None, str(exc))`，但 `str(exc)` 在某些 HTTP 异常下可能为空字符串。
2. 上层 `_check` 用 `if error:`（字符串真值）判断失败，空字符串会误判为“无错误”。
3. 随后执行 `assert status is not None`，在 `status is None` 时触发 `AssertionError`。
4. 并发 worker 内未对未预期异常做结构化降级，导致任务组整体中断。

## 本次修复实施（已完成）

1. 修复 reachability 主逻辑（`src/sitemap_verify/service.py`）  

- 失败判定改为 `status is None`，不再依赖 `if error:`。  
- 删除运行时 `assert status is not None`。  
- `status is None` 且错误文案为空时，使用兜底消息：`HTTP probe failed: unknown error.`。

1. 加固并发 worker 健壮性（`src/sitemap_verify/service.py`）  

- 对单 URL worker 增加 `except Exception` 兜底。  
- 将异常转换为 `UrlCheckResult(level="error")`，避免单任务炸毁整批任务。

1. 统一 probe 错误消息契约（`src/sitemap_verify/loader.py`）  

- 异常消息标准化：`str(exc).strip() or exc.__class__.__name__`。  
- 保证 `probe_url` 异常分支 message 非空。

1. 工程约定更新（`AGENTS.md`）  

- 禁止在外部 I/O 运行时路径使用 `assert` 作为控制流。  
- 并发 worker 必须将异常降级为结构化结果，避免整批失败。

1. 经验沉淀  

- 已新增 `docs/agent-lessons/2026-03-13-reachability-assertion-crash.md`。

## 回归测试与验收

新增回归测试（`tests/test_service.py`）：

1. `test_probe_url_returns_non_empty_error_message_for_empty_httpx_message`  

- 验证 `httpx` 空消息异常会被标准化为非空文案（如 `ReadTimeout`）。

1. `test_reachability_empty_error_message_does_not_crash`  

- 验证 `(status=None, error="")` 不会崩溃，会落为结构化 `error` 结果。

1. `test_reachability_worker_exception_is_converted_to_error_result`  

- 验证 worker 内未预期异常不会中断批量任务，会产出结构化错误。

验收结果：`tests/test_service.py` 共 `11 passed`。

## 同类风险扫描报告（原 2026-03-13-assertion-risk-scan-report 合并）

扫描范围：

- `src/` 运行时代码
- `tests/` 现有测试
- `aiometer` 并发 URL reachability 路径

扫描结论：

1. 本次 crash 路径中的 runtime assert 已修复。  
2. `src/` 未发现其他 runtime `assert`（测试中的断言不在此范围）。  
3. reachability 并发路径已具备单任务异常降级能力。

扫描命令：

- `rg -n "\\bassert\\b|ExceptionGroup|aiometer\\.amap|probe_url\\(" src tests`

建议（按优先级）：

1. 高优：所有 `(value, error)` 契约必须以状态字段判断，禁止依赖 message 真值。  
2. 高优：Code Review 加入检查项：外部 I/O 路径禁用 runtime assert；并发 worker 必须异常降级。  
3. 中优：沉淀异步 worker 负向测试模板（空错误消息、未预期异常、批量连续性）。  
4. 低优：考虑引入统一异常消息归一化 helper。

## 后续 Action

1. 持续在新增并发校验流程中复用“单任务异常降级”模式。  
2. 将上述高优规则纳入提测前检查。  
3. 如需进一步优化，可按扫描建议追加全项目并发路径硬化改造。
