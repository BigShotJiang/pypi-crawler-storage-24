# Sitemap Verify v1 Final Plan And Todo

## Summary

This project delivers a sitemap validation tool with both a CLI and an async library API.
Validation is based on mature open-source libraries for parsing, schema validation, URI checks,
HTTP access, and concurrency control.

Final scope:

1. Validate sitemap protocol compliance and report `error` / `warn`.
2. Validate discovered URL reachability and report `error` / `warn`.
3. Cover all protocol-related elements on sitemaps.org that are relevant to validation:
   XML sitemap (`urlset`), sitemap index (`sitemapindex`), text sitemap, RSS, Atom,
   namespace and field constraints, size/count limits, and sitemap location scope.
4. Keep only async library entry points (no sync API).
5. Use multiple small git commits during implementation.

Confirmed decisions:

- Keep all planned new dependencies.
- Use `pytest-httpx` for HTTP mocking in tests.
- XSD validation results must be included in graded diagnostics (`error` / `warn`).
- Do not implement ping submission to search engines.
- Recursive sitemap index traversal is enabled by default.

## Dependency Plan

Runtime dependencies:

- `httpx`: async HTTP client for loading sitemap targets and probing URLs.
- `lxml`: XML parsing and robust element handling.
- `xmlschema`: XSD-based validation for sitemap XML structure.
- `feedparser`: parsing RSS/Atom feeds.
- `rfc3986`: URL syntax validation.
- `isodate`: W3C datetime/date parsing for `lastmod`.
- `aiometer`: async concurrency control for reachability probing.
- `protego`: robots.txt parsing and sitemap discovery.
- `pydantic`: typed public report models and JSON serialization.

Development dependencies:

- `pytest`: test runner.
- `pytest-asyncio`: async tests.
- `pytest-httpx`: HTTP mocking.
- `ruff`: linting and style checks.

Dependency management rules:

- Use `uv add` and `uv add --dev`.
- Avoid manual edits to dependency lists where possible.

## Architecture And Interfaces

Public library API:

- `async def validate_target(...) -> ValidationReport`

Core options:

- `mode`: `auto | path | url | domain`
- `recursive`: default `True`
- `max_depth`: recursion depth guard
- `max_sitemaps`: processed document guard
- `check_reachability`: default `True`
- `concurrency`, `timeout`: HTTP probe controls

CLI API:

- `sitemap-verify check <target>`
- Options: mode, recursive switch, depth/count guards, reachability switch, timeout,
  concurrency, output format (`text|json`)
- Exit code:
  - non-zero when any `error` exists
  - zero when only `warn` or no diagnostics

Diagnostic model:

- Only `error` and `warn` are used for protocol/report diagnostics.
- Reachability checks include per-URL status with `ok | warn | error`.
- Only non-`ok` reachability outcomes are promoted into report diagnostics.

Validation report includes:

- target metadata
- checked sitemaps list
- discovered URL list
- URL check list
- diagnostics list
- summary counters

## Validation Rules

Parsing and input support:

- XML sitemap (`urlset`)
- XML sitemap index (`sitemapindex`)
- text sitemap (one URL per line)
- RSS and Atom feeds (link extraction)
- gzip-compressed content with UTF-8 decoding checks

XSD validation:

- Validate XML sitemap documents against bundled local XSD files.
- Map each XSD issue to a diagnostic entry.
- Severity mapping:
  - structural/required/type violations => `error`
  - non-critical schema-recognition issues => `warn`

Semantic protocol validation:

- namespace recommendation for standard sitemap namespace
- `loc` presence and non-empty checks
- URL syntax checks (`http`/`https`, whitespace invalidation)
- scope checks against sitemap location (scheme/host/port/path)
- `lastmod` datetime/date validity
- `changefreq` allowed values
- `priority` numeric range `[0.0, 1.0]`
- max URLs per sitemap (`50,000`)
- max uncompressed size (`50MB`)
- duplicate fields and duplicate `loc` warnings
- unknown element/field warnings

Reachability grading:

- `2xx` => `ok`
- `3xx` and `429` => `warn`
- `4xx`, `5xx`, or network errors => `error`

Domain mode discovery:

- Fetch `https://<domain>/robots.txt`
- Extract `Sitemap:` entries via `protego`
- Fallback to `https://<domain>/sitemap.xml` when not found

## Test Plan

Unit and integration tests cover:

1. Local XML sitemap validation success path.
2. XSD-required-field failures and graded diagnostics.
3. Reachability severity mapping (`ok`/`warn`/`error`) using `pytest-httpx`.
4. Recursive sitemap index traversal and discovered URL aggregation.

Verification commands:

- `uv run ruff check src tests`
- `uv run pytest -q`

## Todo List

Completed:

- [x] Add and lock runtime dependencies with `uv`.
- [x] Add `pytest-httpx` as dev dependency.
- [x] Replace legacy simple parser entry with async validation pipeline.
- [x] Implement target resolution and content loader (path/url/domain).
- [x] Implement robots sitemap discovery with fallback.
- [x] Implement parser support for XML/Text/RSS/Atom.
- [x] Add embedded sitemap XSD resources.
- [x] Implement XSD validator and issue-to-diagnostic mapping.
- [x] Implement semantic protocol validators.
- [x] Implement recursive sitemap index traversal with safeguards.
- [x] Implement async reachability checks with severity grading.
- [x] Implement CLI `check` command with text/json output.
- [x] Add async tests with `pytest-httpx`.
- [x] Update `README.md` with new CLI and library usage.

Remaining enhancement candidates (future):

- [ ] Add richer CLI filtering by diagnostic code/level.
- [ ] Add machine-readable output file option (`--output` path).
- [ ] Add larger fixture matrix for edge cases (gzip corruption, mixed hosts, scope conflicts).
- [ ] Add optional reporting profile presets for strict vs relaxed policy.

## Git Commit Checklist

Target commit sequence:

1. dependency setup
2. core async pipeline implementation
3. docs and usage updates
4. optional follow-up polish

Actual commits should remain small and review-friendly.
