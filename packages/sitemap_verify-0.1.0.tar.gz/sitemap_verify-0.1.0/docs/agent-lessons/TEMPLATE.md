# Agent Lesson Template

Use one file per lesson.

Suggested file name:

`YYYY-MM-DD-short-topic.md`

## Summary

One or two sentences describing the mistake and the corrected outcome.

## What Went Wrong

- What the agent did incorrectly
- What assumption was wrong
- What impact it caused

## Root Cause

- Missing repository context
- Misread requirement
- Incorrect tool choice
- Incomplete verification
- Other confirmed cause

## Correct Fix

- What was changed to fix the issue
- Why this fix is correct

## Prevention Checklist

- What to check before making a similar change next time
- What files or project conventions must be verified first
- What tool or verification step should be mandatory

## Signals To Notice Earlier

- Clues that should have indicated the approach was wrong
- Warnings from file structure, docs, tests, or user wording

## Related Files

- List the relevant files in this repository

## Optional Example

```md
# 2026-03-13-folder-purpose.md

## Summary

Used the wrong documentation folder name for historical agent mistakes, then renamed it to match the actual purpose.

## What Went Wrong

- Treated the folder like a bug tracker
- Chose a name based on generic engineering terminology instead of the user's stated intent
- This caused the docs structure to drift from the real workflow

## Root Cause

- Misread the semantic intent of the folder
- Optimized for a common label instead of the actual use case

## Correct Fix

- Renamed the folder to `docs/agent-lessons/`
- Updated project documentation to define it as a record of corrected past mistakes

## Prevention Checklist

- Confirm whether a folder tracks open issues, technical debt, or lessons learned
- Prefer names that reflect workflow purpose, not generic terminology
- Re-read the user's wording before renaming project structure

## Signals To Notice Earlier

- The user described the folder as helping the agent avoid repeating fixed mistakes
- "bug-track" and "tech-debt" did not match that meaning closely enough

## Related Files

- `AGENTS.md`
- `docs/agent-lessons/`
