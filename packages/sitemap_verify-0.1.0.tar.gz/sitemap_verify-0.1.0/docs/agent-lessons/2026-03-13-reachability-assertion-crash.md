# 2026-03-13-reachability-assertion-crash

## Summary

Reachability worker used a runtime `assert` after probing URLs, which caused a crash when error text was empty and bypassed the intended error branch. The fix converts all such cases into structured error results.

## What Went Wrong

- Used `if error:` truthiness to decide failure instead of checking the probe status contract.
- Kept `assert status is not None` in production I/O flow.
- In concurrent `aiometer` workers, one unexpected exception propagated and failed the whole batch.

## Root Cause

- Incomplete contract handling for `(status, error)` return values from `probe_url`.
- Runtime assertion was used as control flow for external network behavior.
- Missing regression tests for empty exception message and unexpected worker exceptions.

## Correct Fix

- Replaced truthy `error` check with `status is None` branch in reachability worker.
- Removed runtime assertion and returned structured `UrlCheckResult(level="error")`.
- Added worker-level exception fallback to prevent one URL failure from aborting all checks.
- Standardized `probe_url` exception message so HTTP errors always return a non-empty message.
- Added regression tests for empty error message and unexpected worker exceptions.

## Prevention Checklist

- Verify error contracts with explicit state checks (`status is None`) instead of string truthiness.
- Do not use `assert` in runtime code paths that handle network/file/parsing input.
- In concurrent workers, convert each failure to a structured result and keep the batch running.
- Add a regression test for every production crash signature.

## Signals To Notice Earlier

- Stack trace pointed directly to `assert status is not None` under worker fan-out.
- Log showed no `Reachability check failed` entry before crash, indicating the error branch was skipped.
- `httpx` exception strings can be empty (`str(exc) == ""`) in real timeout/request error cases.

## Related Files

- `src/sitemap_verify/service.py`
- `src/sitemap_verify/loader.py`
- `tests/test_service.py`
- `AGENTS.md`
