# Changelog

All notable changes to this project should be documented in this file.

## [Unreleased]

- Added SQLite-backed validation persistence to reduce runtime memory growth
- Added `--store` and `--resume-from` support for interrupted run recovery
- Switched final report export to rebuild from persisted SQLite data
- Added persistence and resume regression tests

## [0.1.0] - 2026-03-13

- Added the initial project skeleton
- Added sitemap validation package and CLI
- Added tests, lint configuration, and GitHub workflow
- Added GitHub issue and pull request templates
