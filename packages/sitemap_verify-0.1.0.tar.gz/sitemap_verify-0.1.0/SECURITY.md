# Security Policy

## Reporting a Vulnerability

Do not open public GitHub issues for security vulnerabilities.

Instead, report the issue privately to the maintainers with:

- A clear description of the problem
- Reproduction steps or proof of concept
- Expected impact
- Suggested mitigation, if known

The maintainers should acknowledge the report, confirm severity, and coordinate a fix before public disclosure.