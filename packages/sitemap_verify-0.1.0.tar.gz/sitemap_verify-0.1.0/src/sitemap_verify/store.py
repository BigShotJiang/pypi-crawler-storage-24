from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from .models import Diagnostic, UrlCheckResult, ValidationReport, ValidationSummary


@dataclass(slots=True)
class StoreBootstrap:
    path: Path
    resumed: bool


class ValidationStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._connection = sqlite3.connect(path)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA foreign_keys = ON")
        self._create_schema()

    def close(self) -> None:
        self._connection.close()

    def initialize_new(
        self,
        *,
        target: str,
        input_kind: str,
        resolved_target: str,
    ) -> None:
        existing = self._fetch_run_info()
        if existing is not None:
            raise ValueError(
                f"SQLite store already contains validation data: {self.path}. "
                "Use --resume-from to continue an interrupted run."
            )

        self._connection.execute(
            """
            INSERT INTO run_info (
                id,
                target,
                input_kind,
                resolved_target,
                started_at,
                resumed_at,
                completed_at
            )
            VALUES (1, ?, ?, ?, ?, NULL, NULL)
            """,
            (target, input_kind, resolved_target, _utc_now()),
        )
        self._connection.commit()

    def initialize_resume(
        self,
        *,
        target: str,
        input_kind: str,
        resolved_target: str,
    ) -> None:
        row = self._fetch_run_info()
        if row is None:
            raise ValueError(f"SQLite store is missing run metadata: {self.path}")

        if row["resolved_target"] != resolved_target or row["input_kind"] != input_kind:
            raise ValueError(
                "Resume target does not match the SQLite store metadata. "
                f"Expected {row['input_kind']}:{row['resolved_target']}, "
                f"got {input_kind}:{resolved_target}."
            )

        self._connection.execute("DELETE FROM checked_sitemaps")
        self._connection.execute("DELETE FROM discovered_urls")
        self._connection.execute("DELETE FROM diagnostics")
        self._connection.execute(
            """
            UPDATE run_info
            SET target = ?, started_at = ?, resumed_at = ?, completed_at = NULL
            WHERE id = 1
            """,
            (target, _utc_now(), _utc_now()),
        )
        self._connection.commit()

    def mark_completed(self) -> None:
        self._connection.execute(
            "UPDATE run_info SET completed_at = ? WHERE id = 1",
            (_utc_now(),),
        )
        self._connection.commit()

    def count_checked_sitemaps(self) -> int:
        row = self._connection.execute("SELECT COUNT(*) AS count FROM checked_sitemaps").fetchone()
        return int(row["count"])

    def record_checked_sitemap(self, *, source: str, document_kind: str) -> None:
        self._connection.execute(
            """
            INSERT OR IGNORE INTO checked_sitemaps (source, document_kind)
            VALUES (?, ?)
            """,
            (source, document_kind),
        )
        self._connection.commit()

    def record_diagnostics(self, diagnostics: Iterable[Diagnostic]) -> None:
        rows = [
            (item.level, item.code, item.message, item.location)
            for item in diagnostics
        ]
        if not rows:
            return
        self._connection.executemany(
            """
            INSERT INTO diagnostics (level, code, message, location)
            VALUES (?, ?, ?, ?)
            """,
            rows,
        )
        self._connection.commit()

    def record_discovered_urls(self, urls: Iterable[str]) -> None:
        rows = [(url,) for url in urls]
        if not rows:
            return
        self._connection.executemany(
            "INSERT OR IGNORE INTO discovered_urls (url) VALUES (?)",
            rows,
        )
        self._connection.commit()

    def get_cached_url_check(self, url: str) -> UrlCheckResult | None:
        row = self._connection.execute(
            """
            SELECT url, status, level, message
            FROM url_checks
            WHERE url = ?
            """,
            (url,),
        ).fetchone()
        if row is None:
            return None

        return UrlCheckResult(
            url=row["url"],
            status=row["status"],
            level=row["level"],
            message=row["message"],
        )

    def record_url_check(self, result: UrlCheckResult) -> None:
        self._connection.execute(
            """
            INSERT INTO url_checks (url, status, level, message)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(url) DO UPDATE SET
                status = excluded.status,
                level = excluded.level,
                message = excluded.message
            """,
            (result.url, result.status, result.level, result.message),
        )
        self._connection.commit()

    def list_current_urls(self) -> list[str]:
        rows = self._connection.execute(
            """
            SELECT url
            FROM discovered_urls
            ORDER BY id
            """
        ).fetchall()
        return [str(row["url"]) for row in rows]

    def build_report(self, *, include_url_checks: bool) -> ValidationReport:
        run_info = self._fetch_run_info()
        if run_info is None:
            raise ValueError(f"SQLite store is missing run metadata: {self.path}")

        checked_rows = self._connection.execute(
            """
            SELECT source, document_kind
            FROM checked_sitemaps
            ORDER BY id
            """
        ).fetchall()
        checked_sitemaps = [str(row["source"]) for row in checked_rows]

        document_kinds: list[str] = []
        for row in checked_rows:
            document_kind = str(row["document_kind"])
            if document_kind not in document_kinds:
                document_kinds.append(document_kind)

        discovered_urls = self.list_current_urls()
        diagnostics = [
            Diagnostic(
                level=row["level"],
                code=row["code"],
                message=row["message"],
                location=row["location"],
            )
            for row in self._connection.execute(
                """
                SELECT level, code, message, location
                FROM diagnostics
                ORDER BY id
                """
            ).fetchall()
        ]

        url_checks: list[UrlCheckResult] = []
        if include_url_checks:
            url_checks = [
                UrlCheckResult(
                    url=row["url"],
                    status=row["status"],
                    level=row["level"],
                    message=row["message"],
                )
                for row in self._connection.execute(
                    """
                    SELECT checks.url, checks.status, checks.level, checks.message
                    FROM discovered_urls AS urls
                    JOIN url_checks AS checks ON checks.url = urls.url
                    ORDER BY urls.id
                    """
                ).fetchall()
            ]
            diagnostics.extend(
                Diagnostic(
                    level=item.level,
                    code="url_reachability",
                    message=item.message,
                    location=item.url,
                )
                for item in url_checks
                if item.level != "ok"
            )

        summary = ValidationSummary(
            errors=sum(1 for item in diagnostics if item.level == "error"),
            warnings=sum(1 for item in diagnostics if item.level == "warn"),
            urls_discovered=len(discovered_urls),
            urls_checked=len(url_checks),
            sitemaps_checked=len(checked_sitemaps),
        )

        return ValidationReport(
            target=str(run_info["target"]),
            input_kind=str(run_info["input_kind"]),
            checked_sitemaps=checked_sitemaps,
            document_kinds=document_kinds,
            discovered_urls=discovered_urls,
            url_checks=url_checks,
            diagnostics=diagnostics,
            summary=summary,
        )

    def _fetch_run_info(self) -> sqlite3.Row | None:
        return self._connection.execute(
            """
            SELECT target, input_kind, resolved_target, started_at, resumed_at, completed_at
            FROM run_info
            WHERE id = 1
            """
        ).fetchone()

    def _create_schema(self) -> None:
        self._connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS run_info (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                target TEXT NOT NULL,
                input_kind TEXT NOT NULL,
                resolved_target TEXT NOT NULL,
                started_at TEXT NOT NULL,
                resumed_at TEXT,
                completed_at TEXT
            );

            CREATE TABLE IF NOT EXISTS checked_sitemaps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL UNIQUE,
                document_kind TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS discovered_urls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS url_checks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL UNIQUE,
                status INTEGER,
                level TEXT NOT NULL,
                message TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS diagnostics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                level TEXT NOT NULL,
                code TEXT NOT NULL,
                message TEXT NOT NULL,
                location TEXT
            );
            """
        )
        self._connection.commit()


def bootstrap_store(
    *,
    target: str,
    input_kind: str,
    resolved_target: str,
    store_path: Path | None,
    resume_from: Path | None,
) -> tuple[ValidationStore, StoreBootstrap]:
    if store_path is not None and resume_from is not None and store_path != resume_from:
        raise ValueError("--store and --resume-from must reference the same SQLite file.")

    active_path = resume_from or store_path or default_store_path(target)
    active_path.parent.mkdir(parents=True, exist_ok=True)

    store = ValidationStore(active_path)
    if resume_from is not None:
        store.initialize_resume(
            target=target,
            input_kind=input_kind,
            resolved_target=resolved_target,
        )
        return store, StoreBootstrap(path=active_path, resumed=True)

    store.initialize_new(
        target=target,
        input_kind=input_kind,
        resolved_target=resolved_target,
    )
    return store, StoreBootstrap(path=active_path, resumed=False)


def default_store_path(target: str) -> Path:
    timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    slug = _slugify_target(target)
    return Path("reports") / f"{slug}-{timestamp}.sqlite3"


def _slugify_target(target: str) -> str:
    safe = [
        character.lower() if character.isalnum() else "-"
        for character in target.strip()
    ]
    collapsed = "".join(safe).strip("-")
    while "--" in collapsed:
        collapsed = collapsed.replace("--", "-")
    return collapsed or "validation"


def _utc_now() -> str:
    return datetime.now(tz=timezone.utc).replace(microsecond=0).isoformat()
