from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from lxml import etree
from pydantic import BaseModel, ConfigDict

DiagnosticLevel = Literal["error", "warn"]
UrlCheckLevel = Literal["ok", "warn", "error"]
DocumentKind = Literal["urlset", "sitemapindex", "text", "rss", "atom"]
TargetMode = Literal["auto", "path", "url", "domain"]
ProbeMethod = Literal["auto", "head", "get"]

SITEMAP_NAMESPACE = "http://www.sitemaps.org/schemas/sitemap/0.9"
MAX_URLS_PER_SITEMAP = 50_000
MAX_UNCOMPRESSED_BYTES = 52_428_800
ALLOWED_CHANGEFREQ = {
    "always",
    "hourly",
    "daily",
    "weekly",
    "monthly",
    "yearly",
    "never",
}


class Diagnostic(BaseModel):
    model_config = ConfigDict(extra="forbid")
    level: DiagnosticLevel
    code: str
    message: str
    location: str | None = None


class UrlCheckResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    url: str
    status: int | None = None
    level: UrlCheckLevel
    message: str


class ValidationSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")
    errors: int = 0
    warnings: int = 0
    urls_discovered: int = 0
    urls_checked: int = 0
    sitemaps_checked: int = 0


class ValidationReport(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target: str
    input_kind: str
    checked_sitemaps: list[str]
    document_kinds: list[DocumentKind]
    discovered_urls: list[str]
    url_checks: list[UrlCheckResult]
    diagnostics: list[Diagnostic]
    summary: ValidationSummary

    @property
    def has_errors(self) -> bool:
        return self.summary.errors > 0

    @property
    def has_warnings(self) -> bool:
        return self.summary.warnings > 0


@dataclass(slots=True)
class SitemapEntry:
    location: str
    loc: str = ""
    has_loc: bool = False
    lastmod: str | None = None
    changefreq: str | None = None
    priority: str | None = None
    duplicate_fields: list[str] = field(default_factory=list)
    unknown_tags: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ParsedSitemap:
    kind: DocumentKind
    source: str
    entries: list[SitemapEntry]
    namespace: str | None = None
    uncompressed_size: int = 0
    is_gzipped: bool = False
    unknown_tags: list[str] = field(default_factory=list)
    xml_root: etree._Element | None = None
