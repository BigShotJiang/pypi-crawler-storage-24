from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib import parse

import aiometer
import httpx

from .loader import (
    build_http_client,
    discover_sitemaps,
    load_local_content,
    load_remote_content,
    probe_url,
    resolve_target,
)
from .models import (
    Diagnostic,
    ProbeMethod,
    TargetMode,
    UrlCheckResult,
    ValidationReport,
)
from .parser import parse_sitemap_document
from .store import ValidationStore, bootstrap_store
from .validators import validate_document
from .xsd_validator import XsdValidator

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class PendingSitemap:
    source: str
    depth: int


async def validate_target(
    target: str,
    *,
    mode: TargetMode = "auto",
    recursive: bool = True,
    max_depth: int = 3,
    max_sitemaps: int = 200,
    check_reachability: bool = True,
    probe_method: ProbeMethod = "get",
    concurrency: int = 20,
    timeout: float = 10.0,
    store_path: str | Path | None = None,
    resume_from: str | Path | None = None,
    progress_callback: Callable[[str], None] | None = None,
) -> ValidationReport:
    _notify(progress_callback, f"Resolving target: {target}")
    resolved = resolve_target(target, mode=mode)
    _notify(progress_callback, f"Resolved target kind: {resolved.kind}")
    pending: deque[PendingSitemap] = deque()
    visited: set[str] = set()
    xsd_validator = XsdValidator()
    store, bootstrap = bootstrap_store(
        target=target,
        input_kind=resolved.kind,
        resolved_target=_resolved_target_key(resolved.kind, resolved.value),
        store_path=Path(store_path) if store_path is not None else None,
        resume_from=Path(resume_from) if resume_from is not None else None,
    )
    if bootstrap.resumed:
        _notify(progress_callback, f"Resuming validation from SQLite store: {bootstrap.path}")
    else:
        _notify(progress_callback, f"Persisting validation data to SQLite store: {bootstrap.path}")

    try:
        async with build_http_client(timeout=timeout, concurrency=concurrency) as client:
            if resolved.kind == "path":
                pending.append(PendingSitemap(source=resolved.value, depth=0))
            elif resolved.kind == "url":
                pending.append(PendingSitemap(source=resolved.value, depth=0))
            else:
                _notify(
                    progress_callback,
                    f"Discovering sitemap URLs via robots.txt for {resolved.value}",
                )
                seed_urls, discovery_warnings = await discover_sitemaps(client, resolved.value)
                store.record_diagnostics(
                    Diagnostic(
                        level="warn",
                        code="robots_discovery",
                        message=message,
                        location=resolved.value,
                    )
                    for message in discovery_warnings
                )
                for seed in seed_urls:
                    pending.append(PendingSitemap(source=seed, depth=0))
                _notify(progress_callback, f"Discovered {len(seed_urls)} sitemap seed(s)")

            while pending:
                item = pending.popleft()
                visit_key = item.source.strip()
                if visit_key in visited:
                    continue
                visited.add(visit_key)
                _notify(progress_callback, f"Loading sitemap: {item.source}")

                if store.count_checked_sitemaps() >= max_sitemaps:
                    store.record_diagnostics(
                        [
                            Diagnostic(
                                level="warn",
                                code="max_sitemaps_reached",
                                message=f"Stopped after reaching max_sitemaps={max_sitemaps}.",
                            )
                        ]
                    )
                    break

                try:
                    if _is_http_url(item.source):
                        loaded = await load_remote_content(client, item.source)
                    elif resolved.kind in {"url", "domain"}:
                        loaded = await load_remote_content(client, item.source)
                    else:
                        loaded = load_local_content(item.source)
                except (httpx.HTTPError, ValueError, OSError) as exc:
                    logger.exception("Failed to load sitemap %s", item.source)
                    store.record_diagnostics(
                        [
                            Diagnostic(
                                level="error",
                                code="load_failed",
                                message=str(exc),
                                location=item.source,
                            )
                        ]
                    )
                    continue

                try:
                    document = parse_sitemap_document(
                        loaded.content,
                        source=loaded.source,
                        uncompressed_size=loaded.uncompressed_size,
                        is_gzipped=loaded.is_gzipped,
                    )
                except ValueError as exc:
                    logger.exception("Failed to parse sitemap %s", loaded.source)
                    store.record_diagnostics(
                        [
                            Diagnostic(
                                level="error",
                                code="parse_failed",
                                message=str(exc),
                                location=loaded.source,
                            )
                        ]
                    )
                    continue

                store.record_checked_sitemap(source=document.source, document_kind=document.kind)
                _notify(progress_callback, f"Parsed {document.kind}: {document.source}")

                xsd_diagnostics = xsd_validator.validate(document)
                store.record_diagnostics(xsd_diagnostics)
                if xsd_diagnostics:
                    _notify(
                        progress_callback,
                        f"XSD diagnostics for {document.source}: {len(xsd_diagnostics)}",
                    )

                has_fatal_xsd = any(item.level == "error" for item in xsd_diagnostics)
                if has_fatal_xsd:
                    _notify(
                        progress_callback,
                        f"Skipping semantic checks due to XSD errors: {document.source}",
                    )
                    continue

                semantic_diagnostics, urls, child_sitemaps = validate_document(
                    document,
                    base_url=loaded.base_url,
                )
                store.record_diagnostics(semantic_diagnostics)
                store.record_discovered_urls(urls)
                _notify(
                    progress_callback,
                    (
                        f"Validated {document.source}: urls={len(urls)} "
                        f"children={len(child_sitemaps)} diagnostics={len(semantic_diagnostics)}"
                    ),
                )

                if recursive and document.kind == "sitemapindex":
                    if item.depth >= max_depth:
                        store.record_diagnostics(
                            [
                                Diagnostic(
                                    level="warn",
                                    code="max_depth_reached",
                                    message=(
                                        "Skipping nested sitemap beyond "
                                        f"max_depth={max_depth}."
                                    ),
                                    location=document.source,
                                )
                            ]
                        )
                    else:
                        for child in child_sitemaps:
                            if child not in visited:
                                pending.append(
                                    PendingSitemap(source=child, depth=item.depth + 1)
                                )
                        _notify(
                            progress_callback,
                            f"Queued {len(child_sitemaps)} child sitemap(s) from {document.source}",
                        )

            discovered_urls = store.list_current_urls()
            if check_reachability and discovered_urls:
                _notify(
                    progress_callback,
                    f"Checking reachability for {len(discovered_urls)} URL(s)",
                )
                await _persist_reachability_checks(
                    client,
                    store,
                    discovered_urls,
                    probe_method=probe_method,
                    concurrency=concurrency,
                    progress_callback=progress_callback,
                )

        store.mark_completed()
        return store.build_report(include_url_checks=check_reachability)
    finally:
        store.close()


async def _persist_reachability_checks(
    client: httpx.AsyncClient,
    store: ValidationStore,
    urls: list[str],
    *,
    probe_method: ProbeMethod,
    concurrency: int,
    progress_callback: Callable[[str], None] | None,
) -> None:
    pending_urls: list[str] = []
    for url in urls:
        cached = store.get_cached_url_check(url)
        if cached is None:
            pending_urls.append(url)
            continue

        _notify(progress_callback, f"Reused reachability result for {url}")

    if not pending_urls:
        return

    async def _check(url: str) -> UrlCheckResult:
        try:
            status, error = await probe_url(client, url, probe_method=probe_method)
            if status is None:
                message = (error or "").strip() or "HTTP probe failed: unknown error."
                logger.warning("Reachability check failed for %s: %s", url, message)
                return UrlCheckResult(url=url, status=None, level="error", message=message)

            _notify(progress_callback, f"Reachability {url} -> HTTP {status}")
            if 200 <= status < 300:
                return UrlCheckResult(
                    url=url,
                    status=status,
                    level="ok",
                    message=f"HTTP {status} OK",
                )
            if 300 <= status < 400 or status == 429:
                return UrlCheckResult(
                    url=url,
                    status=status,
                    level="warn",
                    message=f"HTTP {status} reachable with warning.",
                )
            return UrlCheckResult(
                url=url,
                status=status,
                level="error",
                message=f"HTTP {status} indicates unreachable content.",
            )
        except Exception as exc:  # pragma: no cover - defensive safeguard for concurrent workers
            detail = str(exc).strip()
            message = f"Unexpected reachability failure ({exc.__class__.__name__})"
            if detail:
                message = f"{message}: {detail}"
            logger.exception("Unexpected reachability check error for %s", url)
            return UrlCheckResult(url=url, status=None, level="error", message=message)

    async with aiometer.amap(_check, pending_urls, max_at_once=concurrency) as mapped:
        async for item in mapped:
            store.record_url_check(item)


def _is_http_url(value: str) -> bool:
    parsed = parse.urlsplit(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def _notify(progress_callback: Callable[[str], None] | None, message: str) -> None:
    logger.info(message)
    if progress_callback is not None:
        progress_callback(message)


def _resolved_target_key(kind: str, value: str) -> str:
    if kind == "path":
        return str(Path(value).resolve())
    return value
