from __future__ import annotations

from importlib.resources import files

import xmlschema

from .models import Diagnostic, ParsedSitemap


class XsdValidator:
    def __init__(self) -> None:
        schema_root = files("sitemap_verify.schemas")
        self._urlset = xmlschema.XMLSchema11(str(schema_root / "sitemap.xsd"))
        self._sitemap_index = xmlschema.XMLSchema11(str(schema_root / "siteindex.xsd"))

    def validate(self, document: ParsedSitemap) -> list[Diagnostic]:
        if document.xml_root is None:
            return []
        if document.kind == "urlset":
            schema = self._urlset
        elif document.kind == "sitemapindex":
            schema = self._sitemap_index
        else:
            return []

        diagnostics: list[Diagnostic] = []
        for error in schema.iter_errors(document.xml_root):
            reason = getattr(error, "reason", "") or str(error)
            diagnostics.append(
                Diagnostic(
                    level=_map_level(reason),
                    code="xsd_validation",
                    message=reason,
                    location=_map_location(document.source, error.path),
                )
            )
        return diagnostics


def _map_level(reason: str) -> str:
    text = reason.lower()
    if "not an element of the schema" in text:
        return "warn"
    return "error"


def _map_location(source: str, path: str | None) -> str:
    if path:
        return f"{source}::{path}"
    return source
