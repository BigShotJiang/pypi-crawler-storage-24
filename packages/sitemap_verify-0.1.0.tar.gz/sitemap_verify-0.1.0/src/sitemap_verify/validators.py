from __future__ import annotations

from collections import Counter
from urllib import parse

import isodate
from rfc3986 import api, exceptions
from rfc3986 import validators as rfc_validators

from .models import (
    ALLOWED_CHANGEFREQ,
    MAX_UNCOMPRESSED_BYTES,
    MAX_URLS_PER_SITEMAP,
    SITEMAP_NAMESPACE,
    Diagnostic,
    ParsedSitemap,
)

URL_VALIDATOR = rfc_validators.Validator().allow_schemes("http", "https").require_presence_of(
    "scheme",
    "host",
)


def validate_document(
    document: ParsedSitemap, *, base_url: str | None
) -> tuple[list[Diagnostic], list[str], list[str]]:
    diagnostics: list[Diagnostic] = []
    urls: list[str] = []
    child_sitemaps: list[str] = []
    hostnames: set[str] = set()

    if document.kind in {"urlset", "sitemapindex"} and document.namespace != SITEMAP_NAMESPACE:
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="namespace_nonstandard",
                message=(
                    "Sitemap XML should use the official namespace "
                    f"{SITEMAP_NAMESPACE!r}."
                ),
                location=document.source,
            )
        )

    if document.uncompressed_size > MAX_UNCOMPRESSED_BYTES:
        diagnostics.append(
            Diagnostic(
                level="error",
                code="sitemap_too_large",
                message="Uncompressed sitemap exceeds the 50MB protocol limit.",
                location=document.source,
            )
        )

    if (
        document.kind in {"urlset", "sitemapindex", "text"}
        and len(document.entries) > MAX_URLS_PER_SITEMAP
    ):
        diagnostics.append(
            Diagnostic(
                level="error",
                code="too_many_entries",
                message="Sitemap contains more than 50,000 entries.",
                location=document.source,
            )
        )

    if not document.entries:
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="empty_sitemap",
                message="Sitemap does not contain any entries.",
                location=document.source,
            )
        )

    for tag in sorted(set(document.unknown_tags)):
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="unexpected_element",
                message=f"Unexpected child element <{tag}> was ignored.",
                location=document.source,
            )
        )

    for entry in document.entries:
        diagnostics.extend(_validate_entry(entry, document=document, base_url=base_url))
        if entry.loc and _is_absolute_http_url(entry.loc):
            hostnames.add(_hostname(entry.loc))
            if document.kind == "sitemapindex":
                child_sitemaps.append(entry.loc)
            else:
                urls.append(entry.loc)

    if base_url is None and len(hostnames) > 1:
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="mixed_hosts",
                message=(
                    "Entries span multiple hosts. "
                    "For local files the sitemap source URL is unknown, "
                    "so protocol scope cannot be fully verified."
                ),
                location=document.source,
            )
        )

    duplicate_locations = [
        loc for loc, count in Counter(urls + child_sitemaps).items() if count > 1
    ]
    for location in sorted(duplicate_locations):
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="duplicate_loc",
                message="Duplicate <loc> value found.",
                location=location,
            )
        )

    return diagnostics, urls, child_sitemaps


def _validate_entry(entry, *, document: ParsedSitemap, base_url: str | None) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []

    for field_name in sorted(set(entry.duplicate_fields)):
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="duplicate_field",
                message=f"Duplicate <{field_name}> field was ignored after the first value.",
                location=entry.location,
            )
        )

    for field_name in sorted(set(entry.unknown_tags)):
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="unexpected_field",
                message=f"Unexpected field <{field_name}> was ignored.",
                location=entry.location,
            )
        )

    if not entry.has_loc:
        diagnostics.append(
            Diagnostic(
                level="error",
                code="missing_loc",
                message="Entry is missing the required <loc> element.",
                location=entry.location,
            )
        )
        return diagnostics

    if not entry.loc:
        diagnostics.append(
            Diagnostic(
                level="error",
                code="empty_loc",
                message="Entry <loc> value is empty.",
                location=entry.location,
            )
        )
        return diagnostics

    diagnostics.extend(_validate_url(entry.loc, location=entry.location))

    if base_url and _is_absolute_http_url(entry.loc):
        scope_error = validate_scope(entry.loc, base_url)
        if scope_error:
            diagnostics.append(
                Diagnostic(
                    level="error",
                    code="scope_mismatch",
                    message=scope_error,
                    location=entry.location,
                )
            )

    if entry.lastmod and not _is_valid_lastmod(entry.lastmod):
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="invalid_lastmod",
                message="lastmod is not a valid W3C Datetime value.",
                location=entry.location,
            )
        )

    if (
        document.kind == "urlset"
        and entry.changefreq
        and entry.changefreq not in ALLOWED_CHANGEFREQ
    ):
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="invalid_changefreq",
                message="changefreq is not one of the protocol-defined values.",
                location=entry.location,
            )
        )

    if document.kind == "urlset" and entry.priority and not _is_valid_priority(entry.priority):
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="invalid_priority",
                message="priority must be a decimal value between 0.0 and 1.0.",
                location=entry.location,
            )
        )

    if len(entry.loc) > 2_048:
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="url_too_long",
                message="URL exceeds the 2,048-character recommendation in the sitemap protocol.",
                location=entry.location,
            )
        )

    return diagnostics


def _validate_url(url: str, *, location: str) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []

    if any(character.isspace() for character in url):
        diagnostics.append(
            Diagnostic(
                level="error",
                code="whitespace_in_url",
                message="URL contains unescaped whitespace.",
                location=location,
            )
        )
        return diagnostics

    try:
        reference = api.uri_reference(url)
        URL_VALIDATOR.validate(reference)
    except exceptions.RFC3986Exception as exc:
        diagnostics.append(
            Diagnostic(
                level="error",
                code="invalid_url",
                message=f"URL is not a valid absolute HTTP(S) URI: {exc}",
                location=location,
            )
        )

    return diagnostics


def validate_scope(url: str, base_url: str) -> str | None:
    base = parse.urlsplit(base_url)
    candidate = parse.urlsplit(url)

    if candidate.scheme.lower() != base.scheme.lower():
        return "URL scheme does not match the sitemap scheme."

    if _netloc_key(candidate) != _netloc_key(base):
        return "URL host or port does not match the sitemap location."

    base_prefix = _directory_prefix(base.path)
    candidate_path = candidate.path or "/"
    if not candidate_path.startswith(base_prefix):
        return "URL path falls outside the sitemap location scope."

    return None


def _directory_prefix(path: str) -> str:
    normalized = path or "/"
    if normalized.endswith("/"):
        return normalized
    if "/" not in normalized:
        return "/"
    parent = normalized.rsplit("/", 1)[0]
    return f"{parent}/" if parent else "/"


def _netloc_key(parts) -> tuple[str, int]:
    scheme = parts.scheme.lower()
    host = (parts.hostname or "").lower()
    port = parts.port or (443 if scheme == "https" else 80)
    return host, port


def _hostname(url: str) -> str:
    parsed = parse.urlsplit(url)
    return (parsed.hostname or parsed.netloc).lower()


def _is_absolute_http_url(url: str) -> bool:
    parsed = parse.urlsplit(url)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def _is_valid_lastmod(value: str) -> bool:
    try:
        isodate.parse_datetime(value)
    except Exception:
        try:
            isodate.parse_date(value)
        except Exception:
            return False
    else:
        return True
    try:
        isodate.parse_date(value)
    except Exception:
        return False
    return True


def _is_valid_priority(value: str) -> bool:
    try:
        parsed = float(value)
    except ValueError:
        return False
    return 0.0 <= parsed <= 1.0
