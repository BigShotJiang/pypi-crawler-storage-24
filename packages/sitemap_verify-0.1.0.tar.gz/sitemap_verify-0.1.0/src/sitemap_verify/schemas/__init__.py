# Package marker for embedded schema resources.
