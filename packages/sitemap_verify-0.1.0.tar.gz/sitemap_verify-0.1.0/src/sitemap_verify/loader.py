from __future__ import annotations

import gzip
from dataclasses import dataclass
from pathlib import Path
from urllib import parse

import httpx
from protego import Protego

from .models import ProbeMethod, TargetMode

USER_AGENT = "sitemap-verify/0.1.0 (+https://www.sitemaps.org/protocol.html)"
GZIP_MAGIC = b"\x1f\x8b"


@dataclass(slots=True)
class ResolvedTarget:
    raw: str
    kind: str
    value: str


@dataclass(slots=True)
class LoadedContent:
    source: str
    input_kind: str
    content: str
    base_url: str | None
    uncompressed_size: int
    is_gzipped: bool


@dataclass(slots=True)
class FetchResult:
    url: str
    status: int
    body: bytes
    content_type: str | None


def resolve_target(target: str, mode: TargetMode = "auto") -> ResolvedTarget:
    if mode not in {"auto", "path", "url", "domain"}:
        raise ValueError(f"Unsupported mode: {mode}")

    if mode == "path":
        return ResolvedTarget(raw=target, kind="path", value=str(Path(target)))
    if mode == "url":
        return ResolvedTarget(raw=target, kind="url", value=target)
    if mode == "domain":
        return ResolvedTarget(raw=target, kind="domain", value=normalize_domain_target(target))

    parsed = parse.urlsplit(target)
    if parsed.scheme in {"http", "https"}:
        return ResolvedTarget(raw=target, kind="url", value=target)

    candidate = Path(target)
    if candidate.exists() or _looks_like_path(target):
        return ResolvedTarget(raw=target, kind="path", value=str(candidate))

    return ResolvedTarget(raw=target, kind="domain", value=normalize_domain_target(target))


def normalize_domain_target(target: str) -> str:
    value = target.strip()
    if not value:
        raise ValueError("Domain target cannot be empty.")

    if "://" not in value:
        value = f"https://{value}"

    parsed = parse.urlsplit(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"Invalid domain target: {target}")

    return parsed.netloc


def build_http_client(*, timeout: float, concurrency: int) -> httpx.AsyncClient:
    limits = httpx.Limits(max_connections=concurrency, max_keepalive_connections=concurrency)
    return httpx.AsyncClient(
        follow_redirects=True,
        headers={"User-Agent": USER_AGENT},
        timeout=timeout,
        limits=limits,
    )


def load_local_content(path_text: str) -> LoadedContent:
    path = Path(path_text)
    data = path.read_bytes()
    text, is_gzipped = decode_sitemap_bytes(data, source=str(path))
    return LoadedContent(
        source=str(path.resolve()),
        input_kind="path",
        content=text,
        base_url=None,
        uncompressed_size=len(text.encode("utf-8")),
        is_gzipped=is_gzipped,
    )


async def load_remote_content(client: httpx.AsyncClient, url: str) -> LoadedContent:
    response = await fetch_url(client, url, method="GET")
    text, is_gzipped = decode_sitemap_bytes(response.body, source=response.url)
    return LoadedContent(
        source=response.url,
        input_kind="url",
        content=text,
        base_url=response.url,
        uncompressed_size=len(text.encode("utf-8")),
        is_gzipped=is_gzipped,
    )


async def fetch_url(client: httpx.AsyncClient, url: str, method: str = "GET") -> FetchResult:
    response = await client.request(method, url)
    return FetchResult(
        url=str(response.url),
        status=response.status_code,
        body=response.content,
        content_type=response.headers.get("Content-Type"),
    )


async def discover_sitemaps(client: httpx.AsyncClient, domain: str) -> tuple[list[str], list[str]]:
    base = f"https://{domain}"
    warnings: list[str] = []
    discovered: list[str] = []
    robots_url = f"{base}/robots.txt"

    try:
        robots = await fetch_url(client, robots_url, method="GET")
    except httpx.HTTPError as exc:
        warnings.append(f"Failed to fetch robots.txt: {exc}")
    else:
        if 200 <= robots.status < 300:
            body_text, _ = decode_sitemap_bytes(robots.body, source=robots.url, treat_as_text=True)
            robots_parser = Protego.parse(body_text)
            discovered.extend(parse.urljoin(base, value) for value in robots_parser.sitemaps)
        elif robots.status != 404:
            warnings.append(f"robots.txt returned HTTP {robots.status}")

    if not discovered:
        discovered.append(f"{base}/sitemap.xml")

    return discovered, warnings


def decode_sitemap_bytes(data: bytes, source: str, treat_as_text: bool = False) -> tuple[str, bool]:
    is_gzipped = data.startswith(GZIP_MAGIC)
    payload = data

    if is_gzipped:
        try:
            payload = gzip.decompress(data)
        except gzip.BadGzipFile as exc:
            raise ValueError(f"Invalid gzip content in {source}: {exc}") from exc
        except OSError as exc:
            raise ValueError(f"Unable to decompress gzip sitemap {source}: {exc}") from exc

    if payload.startswith(b"\xef\xbb\xbf"):
        payload = payload[3:]

    try:
        text = payload.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError(f"Invalid UTF-8 content in {source}: {exc}") from exc

    if treat_as_text:
        return text, is_gzipped

    return text, is_gzipped


async def probe_url(
    client: httpx.AsyncClient, url: str, *, probe_method: ProbeMethod = "get"
) -> tuple[int | None, str | None]:
    try:
        if probe_method == "get":
            response = await client.get(url, follow_redirects=True)
        elif probe_method == "head":
            response = await client.head(url, follow_redirects=True)
        elif probe_method == "auto":
            response = await client.head(url, follow_redirects=True)
            if response.status_code in {405, 501} or (
                response.status_code >= 400 and response.status_code != 429
            ):
                response = await client.get(url, follow_redirects=True)
        else:
            raise ValueError(f"Unsupported probe method: {probe_method}")
        return response.status_code, None
    except httpx.HTTPError as exc:
        message = str(exc).strip() or exc.__class__.__name__
        return None, message


def _looks_like_path(target: str) -> bool:
    suffixes = {".xml", ".gz", ".txt"}
    path = Path(target)
    return (
        any(target.endswith(suffix) for suffix in suffixes)
        or "\\" in target
        or "/" in target
        or target.startswith(".")
        or bool(path.drive)
    )
