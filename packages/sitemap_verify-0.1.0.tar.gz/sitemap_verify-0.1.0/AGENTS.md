# Information for Coding AGENTS

## Project struct

Current repository layout:

- `pyproject.toml`: project metadata and Python version constraint.
- `README.md`: top-level English documentation for CLI and library usage.
- `README.zh-CN.md`: top-level Chinese documentation.
- `src/`: main source code directory.
- `src/sitemap_verify/`: validation package, CLI, and SQLite-backed persistence logic.
- `docs/agent-lessons/`: notes about past agent mistakes that have already been fixed, so the same mistakes are not repeated.
- `docs/agent-lessons/TEMPLATE.md`: template file of the lesson.
- `docs/feat/`: feature planning notes.
- `tests/`: automated tests, including persistence and resume coverage.

When adding implementation code, prefer keeping runtime code under `src/` and documentation under `docs/`.

## Tech Stack

- Language: Python 3.12
- Project metadata: `pyproject.toml`
- Packaging/build system: currently minimal Python project layout driven by `pyproject.toml`
- Runtime persistence: standard-library `sqlite3`
- Documentation: Markdown files under `README.md` and `docs/`

## Language

Python：version == 3.12

### dependence

Use `uv` for dependency management.

Recommended commands:

- Add runtime dependency: `uv add <package>`
- Add development dependency: `uv add --dev <package>`
- Sync environment from lock metadata: `uv sync`
- Run Python entrypoints or scripts in the managed environment: `uv run <command>`

Do not edit dependency lists manually unless there is a specific reason. Prefer `uv` commands so the project metadata stays consistent.

## Engineering conventions

- Keep application code in `src/`.
- Keep feature documentation in `docs/feat/` and agent lessons learned in `docs/agent-lessons/`.
- Update `README.md` when the project gains runnable commands, setup steps, or user-facing behavior.
- Keep CLI and library persistence behavior documented in both `README.md` and `README.zh-CN.md`.
- Do not use `assert` for runtime control flow in code paths that process external I/O (network, files, parsing); return structured errors instead.
- In concurrent worker flows (for example, `aiometer` task fan-out), catch unexpected exceptions per item and convert them into structured results so one failure does not crash the whole batch.
- For interruption recovery features, prefer persisting item-level progress incrementally so partial work survives process crashes.
- After completing a coherent set of changes and running relevant checks, commit at an appropriate time with a clear, descriptive commit message.


