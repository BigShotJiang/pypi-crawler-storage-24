## Summary

Describe the change in one or two sentences.

## Testing

- [ ] `uv run ruff check .`
- [ ] `uv run pytest`

## Checklist

- [ ] Scope is focused
- [ ] Tests were added or updated if behavior changed
- [ ] Documentation was updated if needed