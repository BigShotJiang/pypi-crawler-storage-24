#  Pyrogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#
#  This file is part of Pyrogram.
#
#  Pyrogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Pyrogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Pyrogram.  If not, see <http://www.gnu.org/licenses/>.

from typing import Optional, Tuple

from pyrogram import raw, types
from ..object import Object


class KeyboardButton(Object):
    """One button of the reply keyboard.
    For simple text buttons String can be used instead of this object to specify text of the button.
    Optional fields are mutually exclusive.

    Parameters:
        text (``str``):
            Text of the button. If none of the optional fields are used, it will be sent as a message when
            the button is pressed.

        request_contact (``bool``, *optional*):
            If True, the user's phone number will be sent as a contact when the button is pressed.
            Available in private chats only.

        request_location (``bool``, *optional*):
            If True, the user's current location will be sent when the button is pressed.
            Available in private chats only.

        web_app (:obj:`~pyrogram.types.WebAppInfo`, *optional*):
            If specified, the described `Web App <https://core.telegram.org/bots/webapps>`_ will be launched when the
            button is pressed. The Web App will be able to send a “web_app_data” service message. Available in private
            chats only.

        icon_custom_emoji_id (``str``, *optional*):
            Unique identifier of the custom emoji shown before the text of the button.

        style (``str``, *optional*):
            Style of the button. Must be one of "danger", "success" or "primary".

    """

    _ALLOWED_STYLES = {"danger", "success", "primary"}

    def __init__(
        self,
        text: str,
        request_contact: bool = None,
        request_location: bool = None,
        web_app: "types.WebAppInfo" = None,
        icon_custom_emoji_id: str = None,
        style: str = None
    ):
        super().__init__()

        self.text = str(text)
        self.request_contact = request_contact
        self.request_location = request_location
        self.web_app = web_app
        self.icon_custom_emoji_id = icon_custom_emoji_id
        self.style = self._normalize_style(style)

    @classmethod
    def _normalize_style(cls, style):
        if style is None:
            return None

        normalized = str(style).strip().lower()

        if normalized not in cls._ALLOWED_STYLES:
            raise ValueError(
                f"Invalid button style '{style}'. Use one of: {', '.join(sorted(cls._ALLOWED_STYLES))}"
            )

        return normalized

    @staticmethod
    def _read_style(raw_style: Optional["raw.types.KeyboardButtonStyle"]) -> Tuple[Optional[str], Optional[str]]:
        if raw_style is None:
            return None, None

        if getattr(raw_style, "bg_primary", False):
            return "primary", None

        if getattr(raw_style, "bg_danger", False):
            return "danger", None

        if getattr(raw_style, "bg_success", False):
            return "success", None

        icon = getattr(raw_style, "icon", None)

        if icon is not None:
            return None, str(icon)

        return None, None

    def _build_raw_style(self) -> Optional["raw.types.KeyboardButtonStyle"]:
        if self.style is None and self.icon_custom_emoji_id is None:
            return None

        icon = int(self.icon_custom_emoji_id) if self.icon_custom_emoji_id is not None else None

        return raw.types.KeyboardButtonStyle(
            bg_primary=self.style == "primary",
            bg_danger=self.style == "danger",
            bg_success=self.style == "success",
            icon=icon
        )

    @staticmethod
    def read(b):
        button_style, icon_custom_emoji_id = KeyboardButton._read_style(getattr(b, "style", None))

        if isinstance(b, raw.types.KeyboardButton):
            if button_style is None and icon_custom_emoji_id is None:
                return b.text

            return KeyboardButton(
                text=b.text,
                icon_custom_emoji_id=icon_custom_emoji_id,
                style=button_style
            )

        if isinstance(b, raw.types.KeyboardButtonRequestPhone):
            return KeyboardButton(
                text=b.text,
                request_contact=True,
                icon_custom_emoji_id=icon_custom_emoji_id,
                style=button_style
            )

        if isinstance(b, raw.types.KeyboardButtonRequestGeoLocation):
            return KeyboardButton(
                text=b.text,
                request_location=True,
                icon_custom_emoji_id=icon_custom_emoji_id,
                style=button_style
            )

        if isinstance(b, raw.types.KeyboardButtonSimpleWebView):
            return KeyboardButton(
                text=b.text,
                web_app=types.WebAppInfo(
                    url=b.url
                ),
                icon_custom_emoji_id=icon_custom_emoji_id,
                style=button_style
            )

    def write(self):
        style = self._build_raw_style()

        if self.request_contact:
            return raw.types.KeyboardButtonRequestPhone(
                text=self.text,
                style=style
            )
        elif self.request_location:
            return raw.types.KeyboardButtonRequestGeoLocation(
                text=self.text,
                style=style
            )
        elif self.web_app:
            return raw.types.KeyboardButtonSimpleWebView(
                text=self.text,
                url=self.web_app.url,
                style=style
            )
        else:
            return raw.types.KeyboardButton(
                text=self.text,
                style=style
            )
