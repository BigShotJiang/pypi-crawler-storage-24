"""LLM router for chat examples — routes requests to providers by model key."""

import dataclasses
from typing import Any

from flowra.llm import LLMProvider, LLMRequest, LLMResponse

__all__ = ["ChatLLMRouter", "ModelEntry"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ModelEntry:
    provider: LLMProvider
    model_id: str
    additional_config: dict[str, Any] = dataclasses.field(default_factory=dict)


class ChatLLMRouter(LLMProvider):
    __slots__ = ("__models",)

    def __init__(self, models: dict[str, ModelEntry]) -> None:
        self.__models = models

    @property
    def available_models(self) -> list[str]:
        return sorted(self.__models)

    async def call(self, request: LLMRequest) -> LLMResponse:
        entry = self.__models[request.model]
        actual_request = dataclasses.replace(
            request,
            model=entry.model_id,
            additional_config={**entry.additional_config, **request.additional_config},
        )
        return await entry.provider.call(actual_request)
