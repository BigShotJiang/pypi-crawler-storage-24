"""Pure state-machine agent demo using Agent base class.

Same menu/calc/echo demo as menu_agent.py, but using the Agent base class
with type-based references and direct Goto/Call/Spawn constructors.

Usage:
    uv run python -m examples.menu_agent_class
"""

import asyncio
import dataclasses

from examples.tools import eval_expression
from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentResult,
    AppendOnlyList,
    Call,
    Goto,
    Scalar,
    Spawn,
    StepSpec,
    slot,
    step,
)
from flowra.runtime import AgentRuntime, InMemorySessionStorage

# -- Specs & Results ----------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class UserInput(StepSpec):
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class PromptResult(AgentResult):
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class DoneResult(AgentResult):
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class QuitResult(AgentResult):
    pass


# -- Calculator ---------------------------------------------------------------


def _calculate(expression: str) -> str:
    try:
        return eval_expression(expression)
    except Exception as e:
        return f"Error: {e}"


class CalcAgent(Agent):
    history: AppendOnlyList[str] = slot("history")

    @step
    async def prompt(self) -> PromptResult:
        return PromptResult(text="calc> ")

    @step
    async def compute(self, spec: UserInput) -> PromptResult | QuitResult:
        expr = spec.text.strip()
        if expr.lower() in ("q", "quit", "back"):
            return QuitResult()
        result = _calculate(expr)
        self.history.append(f"{expr} = {result}")
        return PromptResult(text=f"  = {result}\ncalc> ")


# -- Echo ---------------------------------------------------------------------


class EchoAgent(Agent):
    count: Scalar[int] = slot("count")

    @step
    async def prompt(self) -> PromptResult:
        return PromptResult(text="echo> ")

    @step
    async def compute(self, spec: UserInput) -> PromptResult | QuitResult:
        text = spec.text.strip()
        if text.lower() in ("q", "quit", "back"):
            return QuitResult()
        self.count.set(self.count.get(0) + 1)
        return PromptResult(text=f"  echo: {text}\necho> ")


# -- Menu (root) --------------------------------------------------------------

_MENU_TEXT = """
=== Menu ===
1. Calculator
2. Echo
q. Quit
choice> """


class MenuAgent(Agent):
    mode: Scalar[str] = slot("mode")

    @step
    async def prompt(self) -> PromptResult | Spawn:
        current = self.mode.get("")
        if current == "calc":
            return Spawn(
                children=[Call(agent=CalcAgent, step=CalcAgent.prompt, storage_key="calc")],
                then=self.forward,
            )
        if current == "echo":
            return Spawn(
                children=[Call(agent=EchoAgent, step=EchoAgent.prompt, storage_key="echo")],
                then=self.forward,
            )
        return PromptResult(text=_MENU_TEXT)

    @step
    async def compute(self, spec: UserInput) -> Goto | DoneResult | PromptResult | Spawn:
        current = self.mode.get("")
        if not current:
            choice = spec.text.strip().lower()
            if choice == "1":
                self.mode.set("calc")
                return Goto(step=self.prompt)
            if choice == "2":
                self.mode.set("echo")
                return Goto(step=self.prompt)
            if choice in ("q", "quit"):
                return DoneResult(text="Bye!")
            return PromptResult(text=f"  Unknown: {spec.text!r}\nchoice> ")
        if current == "calc":
            call = Call(agent=CalcAgent, step=CalcAgent.compute, spec=spec, storage_key="calc")
        else:
            call = Call(agent=EchoAgent, step=EchoAgent.compute, spec=spec, storage_key="echo")
        return Spawn(children=[call], then=self.handle_child)

    @step
    async def forward(self, cr: list[PromptResult | QuitResult]) -> PromptResult | QuitResult:
        return cr[0]

    @step
    async def handle_child(self, cr: list[PromptResult | QuitResult]) -> Goto | PromptResult:
        child_result = cr[0]
        if isinstance(child_result, QuitResult):
            self.mode.set("")
            return Goto(step=self.prompt)
        return child_result


# -- Main ---------------------------------------------------------------------


async def main() -> None:
    agents: dict[str, AgentDefinitionRef] = {
        "menu": MenuAgent,
        "calc": CalcAgent,
        "echo": EchoAgent,
    }
    storage = InMemorySessionStorage()
    runtime = AgentRuntime(agents=agents, storage=storage)

    step_name = "prompt"
    spec: StepSpec | None = None
    while True:
        result = await runtime.run(agent="menu", step=step_name, spec=spec)
        if isinstance(result, DoneResult):
            print(result.text)
            break
        assert isinstance(result, PromptResult)
        user_input = await asyncio.to_thread(input, result.text)
        step_name = "compute"
        spec = UserInput(text=user_input)


if __name__ == "__main__":
    asyncio.run(main())
