"""Textual TUI chat with interrupt support.

Demonstrates ChatAgent with real-time interrupt mechanic:
- Send messages at any time (even while agent is thinking)
- New messages interrupt the current run and get merged into a follow-up
- on_message_accepted hook tracks which messages the agent has consumed

Usage:
    uv run python examples/tui_chat.py
    uv run python examples/tui_chat.py --model claude-sonnet-4-5@20250929

Logs are written to tui_chat.log in the current directory.
"""

import argparse
import asyncio
import dataclasses
import json
import logging
import os
import pathlib
import random
import uuid
from typing import Any, ClassVar, Literal

from rich.markdown import Markdown
from rich.text import Text
from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.events import Key
from textual.widgets import Footer, Header, Input, RichLog, Static

from examples.app_agent import AppAgent, AppConfig
from examples.llm_logging import log_after_llm_call, log_before_llm_call, setup_file_logging
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate, random_numbers
from examples.tools.switch_model import create_switch_model_tool
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.lib.tool_loop import CACHE_ALL, AfterToolCallResult, ToolLoopAgentContext, ToolLoopHooks
from flowra.llm import (
    LLMProvider,
    LLMRequest,
    LLMResponse,
    SystemMessage,
    TextBlock,
    ThinkingBlock,
    ToolResultBlock,
    ToolUseBlock,
    Usage,
)
from flowra.runtime import AgentRuntime, FileSessionStorage
from flowra.tools import ToolRegistry, get_local_tool

# -- Logging ------------------------------------------------------------------

_fh = setup_file_logging("tui_chat")

log = logging.getLogger("tui_chat")
log.setLevel(logging.DEBUG)
log.addHandler(_fh)

# -- Thinking phrases ---------------------------------------------------------

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()

THINKING_PHRASES = [
    "Checking that now...",
    "Pulling everything together...",
    "Looking into it...",
    "Having a think...",
    "Sorting through the details...",
    "Running the numbers...",
    "Connecting the dots...",
    "Pondering the possibilities...",
    "Working through it...",
    "Mulling it over...",
]

# -- Pending message tracking -------------------------------------------------


@dataclasses.dataclass
class PendingMessage:
    id: str
    text: str
    accepted: bool = False


# -- TUI App ------------------------------------------------------------------

_DEFAULT_SESSION_DIR = ".chat_sessions"
_LAST_SESSION_FILE = ".last-session"
_INPUT_HISTORY_FILE = ".chat_input_history"
_UI_LOG_FILE = "ui_log.jsonl"
_MAX_HISTORY_ENTRIES = 500


class UILog:
    """Append-only JSONL log of UI events for replay on resume."""

    def __init__(self, path: str) -> None:
        self._path = path

    def append(self, event: dict[str, Any]) -> None:
        os.makedirs(os.path.dirname(self._path) or ".", exist_ok=True)
        with open(self._path, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")

    def load(self) -> list[dict[str, Any]]:
        if not os.path.exists(self._path):
            return []
        events: list[dict[str, Any]] = []
        with open(self._path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    events.append(json.loads(line))
        return events


class InputHistory:
    """Persistent input history shared across all sessions."""

    def __init__(self, path: str) -> None:
        self._path = path
        self._entries: list[str] = self._load()
        self._index = len(self._entries)
        self._draft = ""

    def _load(self) -> list[str]:
        if not os.path.exists(self._path):
            return []
        with open(self._path, encoding="utf-8") as f:
            return [line for line in f.read().splitlines() if line]

    def _save(self) -> None:
        os.makedirs(os.path.dirname(self._path) or ".", exist_ok=True)
        entries = self._entries[-_MAX_HISTORY_ENTRIES:]
        with open(self._path, "w", encoding="utf-8") as f:
            f.write("\n".join(entries) + "\n")

    def add(self, text: str) -> None:
        if text and (not self._entries or self._entries[-1] != text):
            self._entries.append(text)
            self._save()
        self._index = len(self._entries)
        self._draft = ""

    def navigate_up(self, current_text: str) -> str | None:
        if not self._entries:
            return None
        if self._index == len(self._entries):
            self._draft = current_text
        if self._index > 0:
            self._index -= 1
            return self._entries[self._index]
        return None

    def navigate_down(self, current_text: str) -> str | None:
        if self._index < len(self._entries) - 1:
            self._index += 1
            return self._entries[self._index]
        if self._index == len(self._entries) - 1:
            self._index = len(self._entries)
            return self._draft
        return None


def _read_last_session(base_dir: str) -> str | None:
    path = os.path.join(base_dir, _LAST_SESSION_FILE)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return f.read().strip() or None


def _write_last_session(base_dir: str, session_id: str) -> None:
    os.makedirs(base_dir, exist_ok=True)
    with open(os.path.join(base_dir, _LAST_SESSION_FILE), "w") as f:
        f.write(session_id)


class ChatTUI(App):
    CSS = """
    #main-area {
        height: 1fr;
    }
    #chat-log {
        height: 1fr;
        border: solid $primary;
        padding: 0 1;
    }
    #stats-panel {
        width: 28;
        border: solid $accent;
        padding: 0 1;
        height: 1fr;
    }
    #message-input {
        dock: bottom;
        margin: 0 0;
    }
    """

    BINDINGS: ClassVar[list[Binding]] = [  # type: ignore[assignment]
        Binding("ctrl+c", "quit", "Quit"),
        Binding("escape", "cancel", "Cancel"),
    ]

    def __init__(self, model_key: str, session_dir: str, session_id: str | None = None) -> None:
        super().__init__()
        self._model_key = model_key
        self._session_dir = session_dir
        self._session_id = session_id or uuid.uuid4().hex[:12]
        self._is_resume = session_id is not None
        self._pending: list[PendingMessage] = []
        self._new_message_event = asyncio.Event()
        self._agent_running = False
        self._thinking_timer: Any = None
        self._thinking_phrase_index = 0
        self._runtime: AgentRuntime | None = None
        self._tool_registry: ToolRegistry | None = None
        self._router: LLMProvider | None = None
        self._run_counter = 0
        self._interrupt_reason: Literal["follow_up", "cancel"] | None = None
        self._suppressed_response: bool = False
        self._total_usage: Usage | None = None
        self._input_history = InputHistory(os.path.join(session_dir, _INPUT_HISTORY_FILE))
        self._ui_log = UILog(os.path.join(session_dir, self._session_id, _UI_LOG_FILE))

    async def on_mount(self) -> None:
        _write_last_session(self._session_dir, self._session_id)
        self._router = create_router()
        switch_model_tool = create_switch_model_tool(self._router)
        self._tool_registry = await ToolRegistry.create(
            [get_local_tool(calculate), get_local_tool(random_numbers), get_local_tool(switch_model_tool)]
        )

        def on_message_accepted(meta: dict[str, Any] | None) -> None:
            if meta and "message_ids" in meta:
                ids = meta["message_ids"]
                log.info("HOOK on_message_accepted  ids=%s", ids)
                id_set = set(ids)
                for m in self._pending:
                    if m.id in id_set:
                        m.accepted = True
            else:
                log.info("HOOK on_message_accepted  meta=%s", meta)

        chat_log = self.query_one("#chat-log", RichLog)

        def on_text_reasoning(text: TextBlock, context: ToolLoopAgentContext) -> None:
            log.info("HOOK on_text_reasoning  text=%r", text.text[:120])
            chat_log.write(Text(text.text, style="dim italic"))

        def on_thinking(thinking: ThinkingBlock, context: ToolLoopAgentContext) -> None:
            log.info("HOOK on_thinking  text=%r", thinking.text[:120])
            label = Text.assemble(("  [thinking] ", "bold magenta"), (thinking.text, "magenta"))
            chat_log.write(label)
            self._ui_log.append({"type": "thinking", "text": thinking.text})

        def on_before_llm_call(request: LLMRequest, context: ToolLoopAgentContext) -> None:
            n_msgs = len(request.messages)
            n_tools = len(request.tools or [])
            log.info("HOOK on_before_llm_call  messages=%d  tools=%d", n_msgs, n_tools)
            log_before_llm_call(request, context)

        def on_after_llm_call(request: LLMRequest, response: LLMResponse, context: ToolLoopAgentContext) -> None:
            blocks_summary = ", ".join(type(b).__name__ for b in response.message.blocks)
            log.info("HOOK on_after_llm_call  stop=%s  blocks=[%s]", response.stop_reason, blocks_summary)
            log_after_llm_call(request, response, context)

        def on_after_tool_call(
            tool_use: ToolUseBlock, result: ToolResultBlock, context: ToolLoopAgentContext
        ) -> AfterToolCallResult:
            log.info(
                "HOOK on_after_tool_call  tool=%s  input=%s  result=%s  is_error=%s  interrupt_reason=%s",
                tool_use.name,
                json.dumps(tool_use.input, ensure_ascii=False),
                result.content[:120],
                result.is_error,
                self._interrupt_reason,
            )
            input_str = json.dumps(tool_use.input, ensure_ascii=False)
            label = Text.assemble(
                ("  tool ", "bold cyan"), (tool_use.name, "bold yellow"), (" ", ""), (input_str, "cyan")
            )
            chat_log.write(label)
            self._ui_log.append({"type": "tool_call", "name": tool_use.name, "input": input_str})
            if result.is_error and "interrupted" in result.content.lower():
                if self._interrupt_reason == "cancel":
                    chat_log.write(Text("    \u2715 cancelled", style="bold red"))
                else:
                    chat_log.write(Text("    \u21a9 interrupted by follow-up", style="dim"))
            elif result.is_error:
                chat_log.write(Text(f"    error: {result.content}", style="bold red"))
            else:
                chat_log.write(Text(f"    => {result.content}", style="green"))
            self._ui_log.append({"type": "tool_result", "content": result.content, "is_error": result.is_error})
            return AfterToolCallResult()

        app_config = AppConfig(
            default_model=self._model_key,
            system_messages=lambda: [
                SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
            ],
            cache_strategy=CACHE_ALL,
            on_model_changed=self._on_model_changed,
        )

        hooks = ToolLoopHooks(
            on_message_accepted=on_message_accepted,
            on_text_reasoning=on_text_reasoning,
            on_thinking=on_thinking,
            on_before_llm_call=on_before_llm_call,
            on_after_llm_call=on_after_llm_call,
            on_after_tool_call=on_after_tool_call,
        )

        storage = FileSessionStorage(base_dir=self._session_dir, session_id=self._session_id)
        self._runtime = AgentRuntime(
            agents={"app": AppAgent},
            storage=storage,
            services={
                ToolRegistry: self._tool_registry,
                AppConfig: app_config,
                ToolLoopHooks: hooks,
                LLMProvider: self._router,
            },
        )

        log.info("APP mounted  session=%s  model=%s  resume=%s", self._session_id, self._model_key, self._is_resume)

        title = f"Session {self._session_id}"
        if self._is_resume:
            title += " (resumed)"
        chat_log.write(Text(title, style="bold blue"))
        chat_log.write(Text("Type a message and press Enter. Send while thinking to interrupt.\n", style="dim"))

        self._update_title()
        self.query_one("#message-input", Input).focus()
        self._worker_loop()

        if self._is_resume:
            self._restore_from_ui_log()

        if self._is_resume and await self._runtime.has_pending_execution():
            log.info("RESUME  detected pending execution, resuming")
            chat_log.write(Text("Resuming interrupted execution...", style="yellow"))
            self._resume_pending()

    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Horizontal(id="main-area"):
                yield RichLog(id="chat-log", wrap=True, markup=True)
                yield Static(self._render_stats(), id="stats-panel")
            yield Input(id="message-input", placeholder="Type a message... (Enter to send)")
        yield Footer()

    def _on_model_changed(self, model_key: str) -> None:
        self._model_key = model_key
        self._update_title()
        self._ui_log.append({"type": "model_changed", "model": model_key})

    def _update_title(self) -> None:
        self.title = f"Session {self._session_id}"
        self.sub_title = self._model_key

    def on_key(self, event: Key) -> None:
        inp = self.query_one("#message-input", Input)
        if not inp.has_focus:
            return
        if event.key == "up":
            entry = self._input_history.navigate_up(inp.value)
            if entry is not None:
                inp.value = entry
                inp.cursor_position = len(entry)
            event.prevent_default()
        elif event.key == "down":
            entry = self._input_history.navigate_down(inp.value)
            if entry is not None:
                inp.value = entry
                inp.cursor_position = len(entry)
            event.prevent_default()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        text = event.value.strip()
        if not text:
            return
        event.input.clear()
        self._input_history.add(text)

        msg = PendingMessage(id=uuid.uuid4().hex[:12], text=text)
        self._pending.append(msg)
        self._append_user(text)

        log.info("USER input  id=%s  text=%r  agent_running=%s", msg.id, text, self._agent_running)

        if self._agent_running:
            assert self._runtime is not None
            self._interrupt_reason = "follow_up"
            log.info("INTERRUPT  sending follow-up interrupt signal")
            self._runtime.interrupt()

        self._new_message_event.set()

    def _append_user(self, text: str, *, log_event: bool = True) -> None:
        chat_log = self.query_one("#chat-log", RichLog)
        chat_log.write(Text.assemble(("You: ", "bold green"), (text, "")))
        if log_event:
            self._ui_log.append({"type": "user", "text": text})

    def _append_assistant(self, text: str, usage: Usage | None = None, *, log_event: bool = True) -> None:
        chat_log = self.query_one("#chat-log", RichLog)
        chat_log.write("")
        chat_log.write(Text("Assistant:", style="bold blue"))
        chat_log.write(Markdown(text))
        if log_event:
            self._ui_log.append({"type": "assistant", "text": text})
        if usage:
            parts: list[tuple[str, str]] = [
                (f"{usage.input_tokens}", "bold"),
                (" in ", "dim"),
                (f"{usage.output_tokens}", "bold"),
                (" out", "dim"),
            ]
            if usage.cache_read_input_tokens:
                parts.extend(
                    [
                        (" | ", "dim"),
                        (f"{usage.cache_read_input_tokens}", "bold green"),
                        (" cache-read", "dim"),
                    ]
                )
            if usage.cache_creation_input_tokens:
                parts.extend(
                    [
                        (" | ", "dim"),
                        (f"{usage.cache_creation_input_tokens}", "bold yellow"),
                        (" cache-create", "dim"),
                    ]
                )
            if usage.cost_usd is not None:
                parts.extend(
                    [
                        (" | ", "dim"),
                        (f"${usage.cost_usd:.4f}", "bold cyan"),
                    ]
                )
            chat_log.write(Text.assemble(*parts))
            self._total_usage = self._total_usage + usage if self._total_usage is not None else usage
            self._update_stats()
            if log_event:
                self._ui_log.append(
                    {
                        "type": "usage",
                        "input_tokens": usage.input_tokens,
                        "output_tokens": usage.output_tokens,
                        "cache_read_input_tokens": usage.cache_read_input_tokens,
                        "cache_creation_input_tokens": usage.cache_creation_input_tokens,
                        "cost_usd": usage.cost_usd,
                    }
                )
        chat_log.write("")

    def _render_stats(self) -> Text:
        u = self._total_usage
        if u is None:
            return Text.assemble(
                ("Session totals\n", "bold underline"),
                ("─" * 24 + "\n", "dim"),
                ("No usage yet", "dim"),
            )
        lines: list[tuple[str, str]] = [
            ("Session totals\n", "bold underline"),
            ("─" * 24 + "\n", "dim"),
            ("In:     ", "dim"),
            (f"{u.input_tokens:,}\n", "bold"),
            ("Out:    ", "dim"),
            (f"{u.output_tokens:,}\n", "bold"),
        ]
        if u.cache_read_input_tokens:
            lines.extend([("C-read: ", "dim"), (f"{u.cache_read_input_tokens:,}\n", "bold green")])
        if u.cache_creation_input_tokens:
            lines.extend([("C-write:", "dim"), (f" {u.cache_creation_input_tokens:,}\n", "bold yellow")])
        lines.extend([("─" * 24 + "\n", "dim")])
        if u.cost_usd is not None:
            lines.extend([("Cost:   ", "dim"), (f"${u.cost_usd:.4f}\n", "bold cyan")])
        return Text.assemble(*lines)

    def _update_stats(self) -> None:
        try:
            panel = self.query_one("#stats-panel", Static)
            panel.update(self._render_stats())
        except Exception:
            pass

    def _show_thinking(self) -> None:
        log.info("UI _show_thinking  existing_timer=%s", self._thinking_timer is not None)
        if self._thinking_timer is not None:
            self._thinking_timer.stop()
        self._thinking_phrase_index = random.randrange(len(THINKING_PHRASES))
        self._update_thinking_line()
        self._thinking_timer = self.set_interval(2.0, self._rotate_thinking)

    def _rotate_thinking(self) -> None:
        self._thinking_phrase_index = (self._thinking_phrase_index + 1) % len(THINKING_PHRASES)
        self._update_thinking_line()

    def _update_thinking_line(self) -> None:
        inp = self.query_one("#message-input", Input)
        inp.placeholder = f"⠋ {THINKING_PHRASES[self._thinking_phrase_index]}"

    def _hide_thinking(self) -> None:
        log.info("UI _hide_thinking  timer=%s", self._thinking_timer is not None)
        if self._thinking_timer is not None:
            self._thinking_timer.stop()
            self._thinking_timer = None
        inp = self.query_one("#message-input", Input)
        inp.placeholder = "Type a message... (Enter to send)"

    @work
    async def _worker_loop(self) -> None:
        assert self._runtime is not None
        while True:
            await self._new_message_event.wait()
            self._new_message_event.clear()

            unsent = [m for m in self._pending if not m.accepted]
            if not unsent:
                log.info("WORKER woke up but no unsent messages, going back to sleep")
                continue

            self._run_counter += 1
            run_id = self._run_counter
            merged = "\n".join(m.text for m in unsent)
            if self._suppressed_response:
                merged += (
                    "\n\n<system-reminder>"
                    "Your previous response was not shown to the user "
                    "because a follow-up message arrived before you finished. "
                    "Take it into account when responding."
                    "</system-reminder>"
                )
                self._suppressed_response = False
            meta = {"message_ids": [m.id for m in unsent]}

            log.info(
                "RUN #%d START  unsent_ids=%s  merged=%r",
                run_id,
                [m.id for m in unsent],
                merged[:200],
            )

            self._show_thinking()
            self._agent_running = True
            try:
                result = await self._runtime.run(
                    agent=AppAgent,
                    step=AppAgent.process_message,
                    spec=ChatSpec(user_message=merged, meta=meta),
                )
                if isinstance(result, ChatResult):
                    log.info(
                        "RUN #%d DONE  response=%r  usage=%s",
                        run_id,
                        (result.response or "")[:200],
                        result.usage,
                    )
                else:
                    log.info("RUN #%d DONE  result_type=%s", run_id, type(result).__name__)

            except Exception as e:
                log.exception("RUN #%d ERROR  %s", run_id, e)
                chat_log = self.query_one("#chat-log", RichLog)
                chat_log.write(Text(f"Error: {e}", style="bold red"))
                result = None
            finally:
                self._agent_running = False
                self._interrupt_reason = None

            # Check if new messages arrived during the run
            unsent_after = [m for m in self._pending if not m.accepted]
            if unsent_after:
                log.info(
                    "RUN #%d  post-run unsent_ids=%s — suppressing result, scheduling follow-up",
                    run_id,
                    [m.id for m in unsent_after],
                )
                self._suppressed_response = True
                self._new_message_event.set()
            else:
                log.info("RUN #%d  no pending messages after run, showing result", run_id)
                self._hide_thinking()
                if isinstance(result, ChatResult) and result.response:
                    self._append_assistant(result.response, result.usage)
                self._update_title()

    def _restore_from_ui_log(self) -> None:
        chat_log = self.query_one("#chat-log", RichLog)
        for event in self._ui_log.load():
            match event.get("type"):
                case "user":
                    self._append_user(event["text"], log_event=False)
                case "assistant":
                    self._append_assistant(event["text"], log_event=False)
                case "thinking":
                    label = Text.assemble(("  [thinking] ", "bold magenta"), (event["text"], "magenta"))
                    chat_log.write(label)
                case "tool_call":
                    label = Text.assemble(
                        ("  tool ", "bold cyan"),
                        (event["name"], "bold yellow"),
                        (" ", ""),
                        (event["input"], "cyan"),
                    )
                    chat_log.write(label)
                case "tool_result":
                    if event.get("is_error"):
                        chat_log.write(Text(f"    error: {event['content']}", style="bold red"))
                    else:
                        chat_log.write(Text(f"    => {event['content']}", style="green"))
                case "usage":
                    usage = Usage(
                        input_tokens=event["input_tokens"],
                        output_tokens=event["output_tokens"],
                        cache_read_input_tokens=event.get("cache_read_input_tokens", 0),
                        cache_creation_input_tokens=event.get("cache_creation_input_tokens", 0),
                        cost_usd=event.get("cost_usd"),
                    )
                    self._total_usage = self._total_usage + usage if self._total_usage is not None else usage
                case "model_changed":
                    self._model_key = event["model"]
                    self._update_title()
                case _:
                    pass
        self._update_stats()

    @work
    async def _resume_pending(self) -> None:
        assert self._runtime is not None
        self._show_thinking()
        self._agent_running = True
        try:
            result = await self._runtime.resume()
            log.info("RESUME DONE  result_type=%s", type(result).__name__)
        except Exception as e:
            log.exception("RESUME ERROR  %s", e)
            chat_log = self.query_one("#chat-log", RichLog)
            chat_log.write(Text(f"Error: {e}", style="bold red"))
            result = None
        finally:
            self._agent_running = False

        self._hide_thinking()
        if isinstance(result, ChatResult) and result.response:
            self._append_assistant(result.response, result.usage)

    def action_cancel(self) -> None:
        if self._agent_running:
            assert self._runtime is not None
            self._interrupt_reason = "cancel"
            log.info("INTERRUPT  sending cancel interrupt signal (Escape)")
            self._runtime.interrupt()

    async def action_quit(self) -> None:
        log.info("APP quit")
        if self._tool_registry is not None:
            await self._tool_registry.close()
        self.exit()


def main() -> None:
    parser = argparse.ArgumentParser(description="TUI chat with interrupt support")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Model key (e.g. anthropic/sonnet)")
    parser.add_argument("--session-dir", default=_DEFAULT_SESSION_DIR, help="Directory for session storage")
    parser.add_argument("--resume", metavar="SESSION_ID", help="Resume a session ('last' for most recent)")
    args = parser.parse_args()

    session_id: str | None = None
    if args.resume == "last":
        session_id = _read_last_session(args.session_dir)
        if session_id is None:
            print("No previous session found.")
            return
    elif args.resume:
        session_id = args.resume

    app = ChatTUI(model_key=args.model, session_dir=args.session_dir, session_id=session_id)
    app.run()


if __name__ == "__main__":
    main()
