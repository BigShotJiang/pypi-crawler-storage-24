"""Pure state-machine agent demo using runtime.

Menu agent: user picks "calc" or "echo", then interacts with the chosen sub-agent.
Agents contain NO I/O — each step returns a prompt or result.
The single input loop in main() handles all user interaction.

Usage:
    uv run python -m examples.menu_agent
"""

import asyncio
import dataclasses

from examples.tools import eval_expression
from flowra.agent import (
    AgentDefinition,
    AgentDefinitionRef,
    AgentInstance,
    AgentResult,
    AppendOnlyList,
    Call,
    Goto,
    Scalar,
    ServiceLocator,
    SlotContainer,
    SlotDef,
    SlotKind,
    Spawn,
    StepResult,
    StepSpec,
)
from flowra.runtime import AgentRuntime, InMemorySessionStorage

# -- Specs & Results ----------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class UserInput(StepSpec):
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class PromptResult(AgentResult):
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class DoneResult(AgentResult):
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class QuitResult(AgentResult):
    pass


_SHARED_TYPE_REGISTRY: dict[str, type] = {
    "UserInput": UserInput,
    "PromptResult": PromptResult,
    "DoneResult": DoneResult,
    "QuitResult": QuitResult,
}

# -- Calculator ---------------------------------------------------------------


def _calculate(expression: str) -> str:
    try:
        return eval_expression(expression)
    except Exception as e:
        return f"Error: {e}"


def _calc_agent() -> AgentDefinition:
    def create(sl: ServiceLocator, slot_containers: dict[str, SlotContainer]) -> AgentInstance:
        history = slot_containers["history"]
        assert isinstance(history, AppendOnlyList)

        async def call_step(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "prompt":
                return PromptResult(text="calc> ")
            if step == "compute":
                assert isinstance(spec, UserInput)
                expr = spec.text.strip()
                if expr.lower() in ("q", "quit", "back"):
                    return QuitResult()
                result = _calculate(expr)
                history.append(f"{expr} = {result}")
                return PromptResult(text=f"  = {result}\ncalc> ")
            msg = f"Unknown step: {step}"
            raise ValueError(msg)

        return AgentInstance(call_step=call_step)

    return AgentDefinition(
        steps={},
        create_instance=create,
        slots={"history": _append_only_slot("history")},
        type_registry=_SHARED_TYPE_REGISTRY,
    )


# -- Echo ---------------------------------------------------------------------


def _echo_agent() -> AgentDefinition:
    def create(sl: ServiceLocator, slot_containers: dict[str, SlotContainer]) -> AgentInstance:
        count = slot_containers["count"]
        assert isinstance(count, Scalar)

        async def call_step(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "prompt":
                return PromptResult(text="echo> ")
            if step == "compute":
                assert isinstance(spec, UserInput)
                text = spec.text.strip()
                if text.lower() in ("q", "quit", "back"):
                    return QuitResult()
                count.set(count.get(0) + 1)
                return PromptResult(text=f"  echo: {text}\necho> ")
            msg = f"Unknown step: {step}"
            raise ValueError(msg)

        return AgentInstance(call_step=call_step)

    return AgentDefinition(
        steps={},
        create_instance=create,
        slots={"count": _scalar_slot("count")},
        type_registry=_SHARED_TYPE_REGISTRY,
    )


# -- Menu (root) --------------------------------------------------------------

_MENU_TEXT = """
=== Menu ===
1. Calculator
2. Echo
q. Quit
choice> """


def _menu_agent() -> AgentDefinition:
    def create(sl: ServiceLocator, slot_containers: dict[str, SlotContainer]) -> AgentInstance:
        mode = slot_containers["mode"]
        assert isinstance(mode, Scalar)

        async def call_step(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "prompt":
                current = mode.get("")
                if current == "calc":
                    return Spawn(
                        children=[Call(step="prompt", agent="calc", storage_key="calc")],
                        then="forward",
                    )
                if current == "echo":
                    return Spawn(
                        children=[Call(step="prompt", agent="echo", storage_key="echo")],
                        then="forward",
                    )
                return PromptResult(text=_MENU_TEXT)

            if step == "compute":
                assert isinstance(spec, UserInput)
                current = mode.get("")
                if not current:
                    choice = spec.text.strip().lower()
                    if choice == "1":
                        mode.set("calc")
                        return Goto(step="prompt")
                    if choice == "2":
                        mode.set("echo")
                        return Goto(step="prompt")
                    if choice in ("q", "quit"):
                        return DoneResult(text="Bye!")
                    return PromptResult(text=f"  Unknown: {spec.text!r}\nchoice> ")
                return Spawn(
                    children=[Call(step="compute", agent=current, spec=spec, storage_key=current)],
                    then="handle_child",
                )

            if step == "forward":
                assert cr is not None
                return cr[0]

            if step == "handle_child":
                assert cr is not None
                child_result = cr[0]
                if isinstance(child_result, QuitResult):
                    mode.set("")
                    return Goto(step="prompt")
                return child_result

            msg = f"Unknown step: {step}"
            raise ValueError(msg)

        return AgentInstance(call_step=call_step)

    return AgentDefinition(
        steps={},
        create_instance=create,
        slots={"mode": _scalar_slot("mode")},
        type_registry=_SHARED_TYPE_REGISTRY,
    )


def _scalar_slot(key: str) -> SlotDef:
    return SlotDef(key=key, kind=SlotKind.SCALAR, value_type=object)


def _append_only_slot(key: str) -> SlotDef:
    return SlotDef(key=key, kind=SlotKind.APPEND_ONLY, value_type=object)


# -- Main ---------------------------------------------------------------------


async def main() -> None:
    agents: dict[str, AgentDefinitionRef] = {
        "menu": _menu_agent(),
        "calc": _calc_agent(),
        "echo": _echo_agent(),
    }
    storage = InMemorySessionStorage()
    runtime = AgentRuntime(agents=agents, storage=storage)

    step = "prompt"
    spec: StepSpec | None = None
    while True:
        result = await runtime.run(agent="menu", step=step, spec=spec)
        if isinstance(result, DoneResult):
            print(result.text)
            break
        assert isinstance(result, PromptResult)
        user_input = await asyncio.to_thread(input, result.text)
        step = "compute"
        spec = UserInput(text=user_input)


if __name__ == "__main__":
    asyncio.run(main())
