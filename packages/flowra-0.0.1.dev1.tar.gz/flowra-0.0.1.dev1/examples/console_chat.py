"""Interactive console chat with LLM and calculator tool.

Demonstrates ChatAgent with session persistence and resume via FileSessionStorage.

Usage:
    uv run python examples/console_chat.py
    uv run python examples/console_chat.py --model anthropic/haiku
    uv run python examples/console_chat.py --resume last
    uv run python examples/console_chat.py --resume <session_id>
    uv run python examples/console_chat.py --input "What is 2+2?"

Crash recovery demo:
    CRASH_CHANCE=0.5 uv run python examples/console_chat.py --input "What is 2+2?"
    uv run python examples/console_chat.py --resume last
"""

import argparse
import asyncio
import json
import os
import pathlib
import uuid

from examples.app_agent import AppAgent, AppConfig
from examples.llm_logging import log_after_llm_call, log_before_llm_call, setup_file_logging
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate, random_numbers
from examples.tools.switch_model import create_switch_model_tool
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.lib.tool_loop import ToolLoopHooks
from flowra.llm import LLMProvider, SystemMessage, TextBlock, Usage
from flowra.runtime import AgentRuntime, FileSessionStorage
from flowra.tools import ToolRegistry, get_local_tool

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()
_SESSION_DIR = ".chat_sessions"
_LAST_SESSION_FILE = os.path.join(_SESSION_DIR, ".last-session")
_USAGE_LOG_FILE = "usage_log.jsonl"


def _format_usage(usage: Usage) -> str:
    parts = [f"{usage.input_tokens} in, {usage.output_tokens} out"]
    if usage.cache_read_input_tokens:
        parts.append(f"{usage.cache_read_input_tokens} cache-read")
    if usage.cache_creation_input_tokens:
        parts.append(f"{usage.cache_creation_input_tokens} cache-create")
    if usage.cost_usd is not None:
        parts.append(f"${usage.cost_usd:.4f}")
    return " | ".join(parts)


def _usage_log_path(session_id: str) -> str:
    return os.path.join(_SESSION_DIR, session_id, _USAGE_LOG_FILE)


def _load_total_usage(session_id: str) -> Usage | None:
    path = _usage_log_path(session_id)
    if not os.path.exists(path):
        return None
    total: Usage | None = None
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            event = json.loads(line)
            usage = Usage(
                input_tokens=event["input_tokens"],
                output_tokens=event["output_tokens"],
                cache_read_input_tokens=event.get("cache_read_input_tokens", 0),
                cache_creation_input_tokens=event.get("cache_creation_input_tokens", 0),
                cost_usd=event.get("cost_usd"),
            )
            total = total + usage if total is not None else usage
    return total


def _save_usage(session_id: str, usage: Usage) -> None:
    path = _usage_log_path(session_id)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(
            json.dumps(
                {
                    "input_tokens": usage.input_tokens,
                    "output_tokens": usage.output_tokens,
                    "cache_read_input_tokens": usage.cache_read_input_tokens,
                    "cache_creation_input_tokens": usage.cache_creation_input_tokens,
                    "cost_usd": usage.cost_usd,
                }
            )
            + "\n"
        )


setup_file_logging("console_chat")


def _print_result(result: ChatResult, session_id: str, total_usage: Usage | None) -> Usage | None:
    if result.response:
        print(f"Assistant: {result.response}")
    if result.usage:
        _save_usage(session_id, result.usage)
        total_usage = total_usage + result.usage if total_usage is not None else result.usage
        turn_line = f"  Turn:  {_format_usage(result.usage)}"
        total_line = f"  Total: {_format_usage(total_usage)}"
        print(f"\033[2m{turn_line}\033[0m")
        print(f"\033[2m{total_line}\033[0m")
    return total_usage


def _read_last_session() -> str | None:
    if not os.path.exists(_LAST_SESSION_FILE):
        return None
    with open(_LAST_SESSION_FILE) as f:
        return f.read().strip() or None


def _write_last_session(session_id: str) -> None:
    os.makedirs(_SESSION_DIR, exist_ok=True)
    with open(_LAST_SESSION_FILE, "w") as f:
        f.write(session_id)


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Model key (e.g. anthropic/sonnet)")
    parser.add_argument("--resume", metavar="SESSION_ID", help="Resume a session ('last' for most recent)")
    parser.add_argument("--input", metavar="MESSAGE", help="Send a single message and exit (batch mode)")
    args = parser.parse_args()

    session_id: str | None = None
    if args.resume == "last":
        session_id = _read_last_session()
        if session_id is None:
            print("No previous session found.")
            return
    elif args.resume:
        session_id = args.resume

    if session_id is None:
        session_id = uuid.uuid4().hex[:12]

    _write_last_session(session_id)
    print(f"Session: {session_id}")

    total_usage = _load_total_usage(session_id)

    router = create_router()
    switch_model_tool = create_switch_model_tool(router)

    async with await ToolRegistry.create(
        [get_local_tool(calculate), get_local_tool(random_numbers), get_local_tool(switch_model_tool)]
    ) as registry:
        app_config = AppConfig(
            default_model=args.model,
            system_messages=lambda: [
                SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
            ],
        )

        hooks = ToolLoopHooks(
            on_before_llm_call=log_before_llm_call,
            on_after_llm_call=log_after_llm_call,
        )
        storage = FileSessionStorage(base_dir=_SESSION_DIR, session_id=session_id)
        runtime = AgentRuntime(
            agents={"app": AppAgent},
            storage=storage,
            services={
                ToolRegistry: registry,
                AppConfig: app_config,
                ToolLoopHooks: hooks,
                LLMProvider: router,
            },
        )

        if args.resume and await runtime.has_pending_execution():
            print("Resuming interrupted execution...")
            result = await runtime.resume()
            if isinstance(result, ChatResult):
                total_usage = _print_result(result, session_id, total_usage)

        if args.input:
            result = await runtime.run(
                agent=AppAgent,
                step=AppAgent.process_message,
                spec=ChatSpec(user_message=args.input),
            )
            if isinstance(result, ChatResult):
                total_usage = _print_result(result, session_id, total_usage)
            return

        while True:
            user_input = input("You: ")
            if not user_input:
                break

            result = await runtime.run(
                agent=AppAgent,
                step=AppAgent.process_message,
                spec=ChatSpec(user_message=user_input),
            )

            if isinstance(result, ChatResult):
                total_usage = _print_result(result, session_id, total_usage)


if __name__ == "__main__":
    asyncio.run(main())
