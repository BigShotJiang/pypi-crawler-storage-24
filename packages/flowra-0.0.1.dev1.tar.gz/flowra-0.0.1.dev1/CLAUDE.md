# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

- `make deps` — install dependencies (`uv sync`; in CI with `MODE=ci` uses `--locked --no-cache`)
- `make lock` — upgrade all dependencies (`uv lock --upgrade`)
- `make lint` — ruff check + ruff format + pyright (auto-fixes locally; in CI with `MODE=ci` checks only)
- `make test` — run all tests in parallel (`-n auto`)
- `make test name="some_name"` — filter tests by name (`-k`)
- `make test parallel=0` — run tests sequentially
- `make test args="-vv"` — pass extra pytest arguments
- `make check` — lint + test
- `make example1` — run menu agent (functional style)
- `make example2` — run menu agent (class-based style)
- `make chat` — run interactive console chat example
- `make chat resume=last` — resume the last chat session
- `make chat resume=<session_id>` — resume a specific session
- `make chat input="..."` — send a single message (batch mode)
- `make chat crash=0.5 input="..."` — crash recovery demo
- `make chat-tui` — run TUI chat with interrupt support
- `make chat-tui resume=last` — resume the last TUI session

## Architecture

Python 3.12+ library. Package manager: **uv**. All config in `pyproject.toml`.

### LLM abstraction (`flowra/llm/`)

Provider-agnostic interface for calling LLMs:

- `LLMProvider` (abc) — single method `async call(LLMRequest) -> LLMResponse`
- `LLMRequest` — model, messages, tools, json_schema, temperature, max_tokens, stop_sequences
- `LLMResponse` — message (AssistantMessage), stop_reason, usage
- `Usage` — input_tokens, output_tokens, cache_read_input_tokens, cache_creation_input_tokens, cost_usd. Token contract: `input_tokens` excludes cached tokens
- Messages: `SystemMessage`, `UserMessage`, `AssistantMessage` — system messages must be at the beginning of the messages list
- Blocks: `TextBlock` (with `cache: bool` for prompt caching), `ImageBlock`, `ToolUseBlock`, `ToolResultBlock`
- `Tool` — name, description, input_schema, output_schema, cache

Providers live in `flowra/llm/providers/`. Currently: `AnthropicVertexProvider`, `OpenAIProvider`, `GoogleVertexProvider`.

Pricing utilities live in `flowra/llm/pricing/` — per-protocol cost estimation (anthropic, openai, google). Providers use these to populate `Usage.cost_usd`.

## Code Review

Review prompts live in `docs/review_prompts/`:

- `step1_structure.md` — package structure and responsibility
- `step2_code_style.md` — code style rules (**canonical source of all style rules**)
- `step3_documentation.md` — documentation completeness and quality
- `step4_doc_readability.md` — documentation readability (as a first-time reader)
- `step5_doc_audit.md` — documentation audit against source code
- `step6_tests.md` — test quality and coverage

### Tests

Test directory structure mirrors `flowra/`. E2E tests use `_e2e` suffix (e.g., `test_anthropic_e2e.py`). Environment variables loaded from `.env` via Makefile.
