import dataclasses

from flowra.lib import LLMConfig
from flowra.lib.tool_loop import (
    AfterToolCallResult,
    BeforeToolCallResult,
    StartIterationResult,
    ToolLoopAgent,
    ToolLoopAgentContext,
    ToolLoopConfig,
    ToolLoopHooks,
    ToolLoopResult,
    ToolLoopSpec,
    ToolLoopStatus,
)
from flowra.lib.tool_loop._tool_call_agent import ToolCallAgent
from flowra.llm import (
    AssistantMessage,
    LLMProvider,
    LLMRequest,
    LLMResponse,
    StopReason,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.runtime import AgentRuntime
from flowra.tools import ToolRegistry, get_local_tool, tool


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class FinishParams:
    pass


@tool("finish")
def finish_tool(params: FinishParams, context: ToolLoopAgentContext) -> str:
    """Tool that requests finish."""
    context.request_finish()
    return "Finishing"


class TestToolLoopAgentContext:
    async def test_request_finish_in_tool(self) -> None:
        # Mock LLM provider that returns tool use then END_TURN
        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    # First call: return tool use
                    return LLMResponse(
                        message=AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="finish", input={})]),
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Should not be called again after tool requests finish
                raise RuntimeError("LLM called after finish requested")

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(finish_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=100,
            )
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            # Verify that LLM was called only once (tool requested finish)
            assert provider.call_count == 1
            assert isinstance(result, ToolLoopResult)
            assert result.status == ToolLoopStatus.FINISH_REQUESTED
            # Messages: user (from spec), assistant (tool use), user (tool result)
            assert len(result.messages) == 3

    async def test_max_iterations_exceeded(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class NoopParams:
            pass

        @tool("noop")
        def noop_tool(params: NoopParams) -> str:
            """Tool that does nothing."""
            return "OK"

        # Mock LLM provider that always returns tool use
        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                return LLMResponse(
                    message=AssistantMessage(
                        blocks=[ToolUseBlock(id=f"call_{self.call_count}", name="noop", input={})]
                    ),
                    stop_reason=StopReason.TOOL_USE,
                )

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(noop_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=3,
            )
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            assert isinstance(result, ToolLoopResult)
            assert result.status == ToolLoopStatus.MAX_ITERATIONS
            # Should have called LLM 3 times before hitting limit
            assert provider.call_count == 3

    async def test_on_after_tool_call_amends_result(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class ErrorParams:
            pass

        @tool("error_tool")
        def error_tool(params: ErrorParams) -> str:
            """Tool that returns an error."""
            raise RuntimeError("Internal error")

        # Hook that sanitizes error messages
        def sanitize_errors_hook(
            tool_use: ToolUseBlock, result: ToolResultBlock, context: ToolLoopAgentContext
        ) -> AfterToolCallResult:
            if result.is_error and "Internal error" in result.content:
                # Replace internal error with user-friendly message
                amended = ToolResultBlock(
                    tool_use_id=result.tool_use_id,
                    content="An error occurred. Please try again.",
                    is_error=True,
                    metadata={"sanitized": True},
                )
                return AfterToolCallResult(amended_result=amended)
            return AfterToolCallResult()  # No changes

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        message=AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="error_tool", input={})]),
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="Done")]), stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(error_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=100,
            )
            hooks = ToolLoopHooks(on_after_tool_call=sanitize_errors_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            assert isinstance(result, ToolLoopResult)
            assert result.status == ToolLoopStatus.COMPLETED
            # Should have 4 messages: user (from spec), assistant (tool use), user (amended result), assistant (done)
            assert len(result.messages) == 4

            # Check that error message was sanitized
            user_msg = result.messages[2]
            assert isinstance(user_msg, UserMessage)
            assert len(user_msg.blocks) == 1
            result_block = user_msg.blocks[0]
            assert isinstance(result_block, ToolResultBlock)
            assert result_block.is_error
            assert result_block.content == "An error occurred. Please try again."
            assert "Internal error" not in result_block.content
            # Check metadata was preserved
            assert result_block.metadata.get("sanitized") is True

    async def test_on_after_tool_call_can_request_finish(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class DoneParams:
            pass

        @tool("done")
        def done_tool(params: DoneParams) -> str:
            """Tool that signals completion."""
            return "Task completed"

        # Hook that requests finish when seeing "done" tool
        def finish_on_done_hook(
            tool_use: ToolUseBlock, result: ToolResultBlock, context: ToolLoopAgentContext
        ) -> AfterToolCallResult:
            if tool_use.name == "done":
                context.request_finish()
            return AfterToolCallResult()

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    # First call: return tool use
                    return LLMResponse(
                        message=AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="done", input={})]),
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Should not be called again after hook requests finish
                raise RuntimeError("LLM called after finish requested")

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(done_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=100,
            )
            hooks = ToolLoopHooks(on_after_tool_call=finish_on_done_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            # Verify that LLM was called only once (hook requested finish)
            assert provider.call_count == 1
            assert isinstance(result, ToolLoopResult)
            assert result.status == ToolLoopStatus.FINISH_REQUESTED
            # Messages: user (from spec), assistant (tool use), user (tool result)
            assert len(result.messages) == 3

    async def test_on_after_tool_call_adds_additional_messages(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CalculateParams:
            value: int

        @tool("calculate")
        def calculate_tool(params: CalculateParams) -> str:
            """Simple calculation tool."""
            return f"Result: {params.value * 2}"

        # Hook that adds a system reminder as additional message
        def after_tool_hook(
            tool_use: ToolUseBlock, result: ToolResultBlock, context: ToolLoopAgentContext
        ) -> AfterToolCallResult:
            # Add a system reminder as additional message
            reminder = UserMessage(
                blocks=[TextBlock(text=f"[System: Tool '{tool_use.name}' executed successfully]")],
                metadata={"transient": True},
            )
            return AfterToolCallResult(
                amended_result=None,  # Keep original result
                additional_messages=[reminder],
            )

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        message=AssistantMessage(
                            blocks=[ToolUseBlock(id="call_1", name="calculate", input={"value": 5})]
                        ),
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="Done")]), stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(calculate_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=100,
            )
            hooks = ToolLoopHooks(on_after_tool_call=after_tool_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            assert isinstance(result, ToolLoopResult)
            # Should have 5 messages:
            # 1. UserMessage (from spec)
            # 2. AssistantMessage (tool use)
            # 3. UserMessage (tool result)
            # 4. UserMessage (additional reminder with metadata)
            # 5. AssistantMessage (done)
            assert len(result.messages) == 5

            # Third message should be UserMessage with tool results
            assert isinstance(result.messages[2], UserMessage)

            # Fourth message should be the additional reminder
            reminder_msg = result.messages[3]
            assert isinstance(reminder_msg, UserMessage)
            # Check metadata was attached to the reminder
            assert reminder_msg.metadata.get("transient") is True
            # Check it's the system reminder
            assert len(reminder_msg.blocks) == 1
            assert isinstance(reminder_msg.blocks[0], TextBlock)
            assert "Tool 'calculate' executed successfully" in reminder_msg.blocks[0].text

    async def test_on_after_tool_call_async_amends_result(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class FetchParams:
            url: str

        @tool("fetch")
        def fetch_tool(params: FetchParams) -> str:
            """Fetch data from URL."""
            return f"Data from {params.url}"

        # Async hook that simulates async processing
        async def async_after_tool_hook(
            tool_use: ToolUseBlock, result: ToolResultBlock, context: ToolLoopAgentContext
        ) -> AfterToolCallResult:
            # Simulate async operation (e.g., logging to database)
            import asyncio

            await asyncio.sleep(0.001)
            # Add metadata about async processing
            amended = ToolResultBlock(
                tool_use_id=result.tool_use_id,
                content=result.content,
                is_error=result.is_error,
                metadata={**result.metadata, "async_processed": True},
            )
            return AfterToolCallResult(amended_result=amended)

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        message=AssistantMessage(
                            blocks=[ToolUseBlock(id="call_1", name="fetch", input={"url": "https://example.com"})]
                        ),
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="Done")]), stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(fetch_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=100,
            )
            hooks = ToolLoopHooks(on_after_tool_call=async_after_tool_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            assert isinstance(result, ToolLoopResult)
            # Should have 4 messages: user (from spec), assistant (tool use), user (amended result), assistant (done)
            assert len(result.messages) == 4

            # Check that async hook processed the result
            user_msg = result.messages[2]
            assert isinstance(user_msg, UserMessage)
            assert len(user_msg.blocks) == 1
            result_block = user_msg.blocks[0]
            assert isinstance(result_block, ToolResultBlock)
            assert not result_block.is_error
            assert result_block.content == "Data from https://example.com"
            # Check metadata was added by async hook
            assert result_block.metadata.get("async_processed") is True

    async def test_all_hooks_are_called(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class SimpleParams:
            value: int

        @tool("simple")
        def simple_tool(params: SimpleParams) -> str:
            """Simple tool."""
            return f"Result: {params.value}"

        # Track hook calls
        hook_calls: list[str] = []

        def before_llm_hook(request: LLMRequest, context: ToolLoopAgentContext) -> None:
            hook_calls.append("before_llm")

        def after_llm_hook(request: LLMRequest, response: LLMResponse, context: ToolLoopAgentContext) -> None:
            hook_calls.append("after_llm")

        def before_tool_hook(tool_use: ToolUseBlock, context: ToolLoopAgentContext) -> BeforeToolCallResult:
            hook_calls.append(f"before_tool:{tool_use.name}")
            return BeforeToolCallResult()

        def after_tool_hook(
            tool_use: ToolUseBlock, result: ToolResultBlock, context: ToolLoopAgentContext
        ) -> AfterToolCallResult:
            hook_calls.append(f"after_tool:{tool_use.name}")
            return AfterToolCallResult()

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        message=AssistantMessage(
                            blocks=[ToolUseBlock(id="call_1", name="simple", input={"value": 42})]
                        ),
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="Done")]), stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(simple_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=100,
            )
            hooks = ToolLoopHooks(
                on_before_llm_call=before_llm_hook,
                on_after_llm_call=after_llm_hook,
                on_before_tool_call=before_tool_hook,
                on_after_tool_call=after_tool_hook,
            )
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            assert isinstance(result, ToolLoopResult)
            # Verify all hooks were called in correct order
            assert hook_calls == [
                "before_llm",  # First LLM call
                "after_llm",
                "before_tool:simple",  # Tool execution
                "after_tool:simple",
                "before_llm",  # Second LLM call
                "after_llm",
            ]

    async def test_async_hooks_are_called(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class AsyncParams:
            pass

        @tool("async_op")
        def async_op_tool(params: AsyncParams) -> str:
            """Async operation."""
            return "OK"

        # Track hook calls
        hook_calls: list[str] = []

        async def async_before_llm_hook(request: LLMRequest, context: ToolLoopAgentContext) -> None:
            import asyncio

            await asyncio.sleep(0.001)
            hook_calls.append("async_before_llm")

        async def async_after_llm_hook(
            request: LLMRequest, response: LLMResponse, context: ToolLoopAgentContext
        ) -> None:
            import asyncio

            await asyncio.sleep(0.001)
            hook_calls.append("async_after_llm")

        async def async_before_tool_hook(tool_use: ToolUseBlock, context: ToolLoopAgentContext) -> BeforeToolCallResult:
            import asyncio

            await asyncio.sleep(0.001)
            hook_calls.append(f"async_before_tool:{tool_use.name}")
            return BeforeToolCallResult()

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        message=AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="async_op", input={})]),
                        stop_reason=StopReason.TOOL_USE,
                    )
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="Done")]), stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(async_op_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=100,
            )
            hooks = ToolLoopHooks(
                on_before_llm_call=async_before_llm_hook,
                on_after_llm_call=async_after_llm_hook,
                on_before_tool_call=async_before_tool_hook,
            )
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            assert isinstance(result, ToolLoopResult)
            # Verify async hooks were called
            assert hook_calls == [
                "async_before_llm",
                "async_after_llm",
                "async_before_tool:async_op",
                "async_before_llm",
                "async_after_llm",
            ]

    async def test_before_tool_call_amends_tool_use(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CalcParams:
            value: int

        @tool("calc")
        def calc_tool(params: CalcParams) -> str:
            """Calculator tool."""
            return f"Calculated: {params.value * 10}"

        # Hook that modifies tool parameters
        def modify_params_hook(tool_use: ToolUseBlock, context: ToolLoopAgentContext) -> BeforeToolCallResult:
            # Double the value parameter
            if tool_use.name == "calc" and "value" in tool_use.input:
                original_value = tool_use.input["value"]
                amended = ToolUseBlock(
                    id=tool_use.id,
                    name=tool_use.name,
                    input={"value": original_value * 2},
                    metadata={**tool_use.metadata, "modified": True},
                )
                return BeforeToolCallResult(amended_tool_use=amended)
            return BeforeToolCallResult()

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    # LLM requests value=5
                    return LLMResponse(
                        message=AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="calc", input={"value": 5})]),
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="Done")]), stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(calc_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=100,
            )
            hooks = ToolLoopHooks(on_before_tool_call=modify_params_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            assert isinstance(result, ToolLoopResult)
            # Should have 4 messages: user (from spec), assistant (tool use), user (result), assistant (done)
            assert len(result.messages) == 4

            # Check that tool was executed with modified parameter (5 * 2 = 10)
            user_msg = result.messages[2]
            assert isinstance(user_msg, UserMessage)
            assert len(user_msg.blocks) == 1
            result_block = user_msg.blocks[0]
            assert isinstance(result_block, ToolResultBlock)
            # Tool received doubled value: 10 * 10 = 100
            assert result_block.content == "Calculated: 100"

    async def test_start_iteration_hook_adds_messages(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class SimpleParams:
            pass

        @tool("simple")
        def simple_tool(params: SimpleParams) -> str:
            """Simple tool."""
            return "OK"

        # Hook that adds iteration context
        def start_iteration_hook(iteration: int, context: ToolLoopAgentContext) -> StartIterationResult:
            # Add a system message with iteration number
            reminder = UserMessage(
                blocks=[TextBlock(text=f"[Iteration {iteration} started]")],
                metadata={"transient": True, "iteration": iteration},
            )
            return StartIterationResult(additional_messages=[reminder])

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        message=AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="simple", input={})]),
                        stop_reason=StopReason.TOOL_USE,
                    )
                # Second call - end turn
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="Done")]), stop_reason=StopReason.END_TURN
                )

        provider = MockProvider()

        async with await ToolRegistry.create([get_local_tool(simple_tool)]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
                max_iterations=100,
            )
            hooks = ToolLoopHooks(on_start_iteration=start_iteration_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent, "tool_call": ToolCallAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="test"),
            )

            assert isinstance(result, ToolLoopResult)
            # Should have 6 messages:
            # 1. UserMessage (from spec)
            # 2. UserMessage (iteration 1 reminder)
            # 3. AssistantMessage (tool use)
            # 4. UserMessage (tool result)
            # 5. UserMessage (iteration 2 reminder)
            # 6. AssistantMessage (done)
            assert len(result.messages) == 6

            # Check user message from spec
            user_msg = result.messages[0]
            assert isinstance(user_msg, UserMessage)
            assert isinstance(user_msg.blocks[0], TextBlock)
            assert user_msg.blocks[0].text == "test"

            # Check first iteration reminder
            reminder1 = result.messages[1]
            assert isinstance(reminder1, UserMessage)
            assert reminder1.metadata.get("transient") is True
            assert reminder1.metadata.get("iteration") == 1
            assert len(reminder1.blocks) == 1
            assert isinstance(reminder1.blocks[0], TextBlock)
            assert "[Iteration 1 started]" in reminder1.blocks[0].text

            # Check second iteration reminder
            reminder2 = result.messages[4]
            assert isinstance(reminder2, UserMessage)
            assert reminder2.metadata.get("iteration") == 2
            assert isinstance(reminder2.blocks[0], TextBlock)
            assert "[Iteration 2 started]" in reminder2.blocks[0].text

            # Verify that LLM received the reminder messages
            assert len(provider.requests) == 2
            # First request should have 2 messages (user message from spec + iteration 1 reminder)
            assert len(provider.requests[0].messages) == 2
            # Second request should have 5 messages (user, reminder1, assistant, user_result, reminder2)
            assert len(provider.requests[1].messages) == 5


class TestToolLoopAgentEndTurn:
    async def test_simple_end_turn_returns_completed(self) -> None:
        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="Hello!")]),
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        async with await ToolRegistry.create([]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
            )
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="Hi"),
            )

            assert isinstance(result, ToolLoopResult)
            assert result.status == ToolLoopStatus.COMPLETED
            assert result.stop_reason == StopReason.END_TURN
            assert result.result_message is not None
            assert isinstance(result.result_message.blocks[0], TextBlock)
            assert result.result_message.blocks[0].text == "Hello!"
            # Messages: user + assistant
            assert len(result.messages) == 2

    async def test_on_message_accepted_receives_meta(self) -> None:
        received_meta: list[dict | None] = []

        def accepted_hook(meta: dict | None) -> None:
            received_meta.append(meta)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="OK")]),
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        async with await ToolRegistry.create([]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
            )
            hooks = ToolLoopHooks(on_message_accepted=accepted_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="Hi", meta={"msg_id": "123"}),
            )

            assert len(received_meta) == 1
            assert received_meta[0] == {"msg_id": "123"}

    async def test_on_message_accepted_async_hook(self) -> None:
        received_meta: list[dict | None] = []

        async def async_accepted_hook(meta: dict | None) -> None:
            import asyncio

            await asyncio.sleep(0.001)
            received_meta.append(meta)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="OK")]),
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        async with await ToolRegistry.create([]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
            )
            hooks = ToolLoopHooks(on_message_accepted=async_accepted_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="Hi", meta={"msg_id": "456"}),
            )

            assert len(received_meta) == 1
            assert received_meta[0] == {"msg_id": "456"}

    async def test_on_text_reasoning_fires_for_text_blocks(self) -> None:
        seen_texts: list[str] = []

        def reasoning_hook(text: TextBlock, context: ToolLoopAgentContext) -> None:
            seen_texts.append(text.text)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="First"), TextBlock(text="Second")]),
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        async with await ToolRegistry.create([]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
            )
            hooks = ToolLoopHooks(on_text_reasoning=reasoning_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="Hi"),
            )

            assert seen_texts == ["First", "Second"]

    async def test_on_result_message_continues_loop(self) -> None:
        from flowra.lib.tool_loop import ResultMessageResult

        call_count = 0

        def result_hook(message: AssistantMessage, context: ToolLoopAgentContext) -> ResultMessageResult:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return ResultMessageResult(continue_messages=[UserMessage(blocks=[TextBlock(text="Continue please")])])
            return ResultMessageResult()

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.llm_calls = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.llm_calls += 1
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text=f"Response {self.llm_calls}")]),
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        async with await ToolRegistry.create([]) as registry:
            config = ToolLoopConfig(
                llm_config=LLMConfig(model="test"),
                session_messages=[],
            )
            hooks = ToolLoopHooks(on_result_message=result_hook)
            runtime = AgentRuntime(
                agents={"loop": ToolLoopAgent},
                services={
                    ToolRegistry: registry,
                    ToolLoopConfig: config,
                    ToolLoopHooks: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ToolLoopAgent,
                step="start",
                spec=ToolLoopSpec(user_message="Hi"),
            )

            assert isinstance(result, ToolLoopResult)
            assert result.status == ToolLoopStatus.COMPLETED
            assert provider.llm_calls == 2
