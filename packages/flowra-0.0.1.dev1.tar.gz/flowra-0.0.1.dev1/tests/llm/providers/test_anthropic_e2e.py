import base64
import json
import os

import pytest
from anthropic import AsyncAnthropicVertex
from google.oauth2 import service_account

from flowra.llm import (
    LLMRequest,
    StopReason,
    SystemMessage,
    TextBlock,
    Tool,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider
from flowra.llm.schema_validation import strip_markdown_code_block


@pytest.fixture
def provider() -> AnthropicVertexProvider:
    project = os.environ["VERTEX_PROJECT_NAME"]
    location = os.environ["VERTEX_LOCATION"]
    creds_json = base64.b64decode(os.environ["VERTEX_CREDENTIALS"].encode()).decode()
    creds_info = json.loads(creds_json)
    creds = service_account.Credentials.from_service_account_info(creds_info).with_scopes(
        ["https://www.googleapis.com/auth/cloud-platform.read-only"]
    )
    client = AsyncAnthropicVertex(region=location, project_id=project, credentials=creds)
    return AnthropicVertexProvider(client=client)


async def test_simple_text_response(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    assert len(response.message.blocks) > 0
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "hello" in text.lower()


async def test_system_message(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            SystemMessage(blocks=[TextBlock(text="You are a bot that only replies with the word 'pong'.")]),
            UserMessage(blocks=[TextBlock(text="ping")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "pong" in text.lower()


async def test_multiple_system_messages(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            SystemMessage(blocks=[TextBlock(text="You are a bot that only replies in uppercase.")]),
            SystemMessage(blocks=[TextBlock(text="You must always start your reply with 'OK:'.")]),
            UserMessage(blocks=[TextBlock(text="hi")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert text.startswith("OK:")
    # After "OK:" the rest should be uppercase
    after_prefix = text[3:].strip()
    assert after_prefix == after_prefix.upper()


async def test_tool_use(provider: AnthropicVertexProvider) -> None:
    tool = Tool(
        name="get_weather",
        description="Get the current weather for a city.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    )
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="What's the weather in Paris?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "get_weather"
    assert tool_uses[0].input["city"].lower() == "paris"
    assert tool_uses[0].id != ""


async def test_tool_use_roundtrip(provider: AnthropicVertexProvider) -> None:
    tool = Tool(
        name="get_temperature",
        description="Get temperature for a city. Returns temperature in Celsius.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string"},
            },
            "required": ["city"],
        },
    )

    # First call: LLM should request tool use
    request1 = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response1 = await provider.call(request1)
    print(response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_use = next(b for b in response1.message.blocks if isinstance(b, ToolUseBlock))

    # Second call: provide tool result, LLM should respond with text
    request2 = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
            response1.message,
            UserMessage(blocks=[ToolResultBlock(tool_use_id=tool_use.id, content="15")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response2 = await provider.call(request2)
    print(response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "15" in text


async def test_json_schema(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="List three European capital cities.")]),
        ],
        json_schema={
            "type": "object",
            "properties": {
                "cities": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["cities"],
        },
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    parsed = json.loads(strip_markdown_code_block(text))
    assert "cities" in parsed
    assert isinstance(parsed["cities"], list)
    assert len(parsed["cities"]) == 3


async def test_stop_sequence(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Count from 1 to 10, one number per line.")]),
        ],
        stop_sequences=["5"],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.STOP_SEQUENCE
    assert response.stop_sequence == "5"
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "5" not in text


async def test_usage_is_returned(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Say hi")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.usage is not None
    assert response.usage.input_tokens > 0
    assert response.usage.output_tokens > 0


async def test_prompt_caching_does_not_error(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            SystemMessage(blocks=[TextBlock(text="You are a helpful assistant. " * 500, cache=True)]),
            UserMessage(blocks=[TextBlock(text="Say hello")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    assert response.usage is not None


async def test_max_tokens_truncation(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Write a long essay about the history of mathematics.")]),
        ],
        max_tokens=5,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.MAX_TOKENS
