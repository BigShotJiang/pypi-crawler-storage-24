import json

import pytest

from flowra.llm import (
    LLMRequest,
    StopReason,
    SystemMessage,
    TextBlock,
    Tool,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.openai import OpenAIProvider


@pytest.fixture
def provider() -> OpenAIProvider:
    import os

    from openai import AsyncOpenAI

    return OpenAIProvider(client=AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"]))


async def test_simple_text_response(provider: OpenAIProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    assert len(response.message.blocks) > 0
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "hello" in text.lower()


async def test_system_message(provider: OpenAIProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            SystemMessage(blocks=[TextBlock(text="You are a bot that only replies with the word 'pong'.")]),
            UserMessage(blocks=[TextBlock(text="ping")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "pong" in text.lower()


async def test_tool_use(provider: OpenAIProvider) -> None:
    tool = Tool(
        name="get_weather",
        description="Get the current weather for a city.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    )
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="What's the weather in Paris?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "get_weather"
    assert tool_uses[0].input["city"].lower() == "paris"
    assert tool_uses[0].id != ""


async def test_tool_use_roundtrip(provider: OpenAIProvider) -> None:
    tool = Tool(
        name="get_temperature",
        description="Get temperature for a city. Returns temperature in Celsius.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string"},
            },
            "required": ["city"],
        },
    )

    request1 = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response1 = await provider.call(request1)
    print(response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_use = next(b for b in response1.message.blocks if isinstance(b, ToolUseBlock))

    request2 = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
            response1.message,
            UserMessage(blocks=[ToolResultBlock(tool_use_id=tool_use.id, content="15")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response2 = await provider.call(request2)
    print(response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "15" in text


async def test_json_schema(provider: OpenAIProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="List three European capital cities.")]),
        ],
        json_schema={
            "type": "object",
            "properties": {
                "cities": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["cities"],
        },
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    parsed = json.loads(text)
    assert "cities" in parsed
    assert isinstance(parsed["cities"], list)
    assert len(parsed["cities"]) == 3


async def test_stop_sequence(provider: OpenAIProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="Count from 1 to 10, one number per line.")]),
        ],
        stop_sequences=["5"],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason in (StopReason.END_TURN, StopReason.STOP_SEQUENCE)
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    # If stop sequence triggered, "5" should not be in the text
    if response.stop_reason == StopReason.STOP_SEQUENCE:
        assert "5" not in text


async def test_usage_is_returned(provider: OpenAIProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="Say hi")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.usage is not None
    assert response.usage.input_tokens > 0
    assert response.usage.output_tokens > 0


async def test_max_tokens_truncation(provider: OpenAIProvider) -> None:
    request = LLMRequest(
        model="gpt-4.1-mini",
        messages=[
            UserMessage(blocks=[TextBlock(text="Write a long essay about the history of mathematics.")]),
        ],
        max_tokens=5,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.MAX_TOKENS
