import dataclasses
from typing import Any, Protocol

from ...llm import (
    AssistantMessage,
    LLMRequest,
    LLMResponse,
    TextBlock,
    ThinkingBlock,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from .context import ToolLoopAgentContext

__all__ = [
    "AfterToolCallResult",
    "BeforeToolCallResult",
    "OnAfterLLMCall",
    "OnAfterLLMCallAsync",
    "OnAfterToolCall",
    "OnAfterToolCallAsync",
    "OnBeforeLLMCall",
    "OnBeforeLLMCallAsync",
    "OnBeforeToolCall",
    "OnBeforeToolCallAsync",
    "OnMessageAccepted",
    "OnMessageAcceptedAsync",
    "OnResultMessage",
    "OnResultMessageAsync",
    "OnStartIteration",
    "OnStartIterationAsync",
    "OnTextReasoning",
    "OnTextReasoningAsync",
    "OnThinking",
    "OnThinkingAsync",
    "OnUserMessage",
    "OnUserMessageAsync",
    "ResultMessageResult",
    "StartIterationResult",
    "ToolLoopHooks",
    "UserMessageResult",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class UserMessageResult:
    """Result of on_user_message hook.

    Allows replacing or augmenting the initial user message before the tool loop starts.

    Attributes:
        messages: List of user messages to use instead of the original user message.
            These are added to turn_messages at the start of the loop.
    """

    messages: list[UserMessage]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class StartIterationResult:
    """Result of on_start_iteration hook.

    Allows adding messages at the start of each iteration.

    Attributes:
        additional_messages: User messages to insert before calling LLM.
            These messages are appended to turn history and persist across iterations
            and into session history. Useful for adding dynamic context or system reminders.
    """

    additional_messages: list[UserMessage] = dataclasses.field(default_factory=list)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class BeforeToolCallResult:
    """Result of on_before_tool_call hook.

    Allows modifying tool use before execution.

    Attributes:
        amended_tool_use: If provided, replaces the original tool use block.
            Useful for modifying tool parameters, injecting context, or validation.
    """

    amended_tool_use: ToolUseBlock | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AfterToolCallResult:
    """Result of on_after_tool_call hook.

    Allows modifying tool results and adding extra messages after tool execution.

    Attributes:
        amended_result: If provided, replaces the original tool result.
            Useful for modifying error messages, adding context, or filtering output.
        additional_messages: Messages to insert after the UserMessage containing tool results.
            Useful for adding system reminders, intermediate feedback, or contextual notes.
    """

    amended_result: ToolResultBlock | None = None
    additional_messages: list[UserMessage] = dataclasses.field(default_factory=list)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ResultMessageResult:
    """Result of on_result_message hook.

    Allows continuing the tool loop after LLM returns END_TURN.

    Attributes:
        continue_messages: User messages to insert after the result message.
            If not empty, the loop continues instead of transitioning to done.
            Useful for prompting continued reasoning, asking follow-up questions, etc.
    """

    continue_messages: list[UserMessage] = dataclasses.field(default_factory=list)


class OnUserMessage(Protocol):
    """Protocol for synchronous user message hook.

    Hook called once at the start of the tool loop, before the first iteration.
    Receives the user message from the spec and returns a list of messages
    to use as the initial turn messages.

    Args:
        user_message: The original user message built from the spec.

    Returns:
        UserMessageResult with the list of messages to add to turn_messages.
    """

    def __call__(self, user_message: UserMessage) -> UserMessageResult: ...


class OnUserMessageAsync(Protocol):
    """Protocol for asynchronous user message hook.

    Hook called once at the start of the tool loop, before the first iteration.
    Receives the user message from the spec and returns a list of messages
    to use as the initial turn messages. Async version.

    Args:
        user_message: The original user message built from the spec.

    Returns:
        UserMessageResult with the list of messages to add to turn_messages.
    """

    async def __call__(self, user_message: UserMessage) -> UserMessageResult: ...


class OnStartIteration(Protocol):
    """Protocol for synchronous iteration start hook.

    Hook called at the start of each tool loop iteration. Allows adding
    transient messages before LLM call.

    Args:
        iteration: Current iteration number (1-indexed).
        context: ToolLoopAgentContext for requesting finish or checking state.

    Returns:
        StartIterationResult with optional additional_messages.
    """

    def __call__(self, iteration: int, context: ToolLoopAgentContext) -> StartIterationResult: ...


class OnStartIterationAsync(Protocol):
    """Protocol for asynchronous iteration start hook.

    Hook called at the start of each tool loop iteration. Allows adding
    transient messages before LLM call. Async version for hooks that need
    to perform async operations.

    Args:
        iteration: Current iteration number (1-indexed).
        context: ToolLoopAgentContext for requesting finish or checking state.

    Returns:
        StartIterationResult with optional additional_messages.
    """

    async def __call__(self, iteration: int, context: ToolLoopAgentContext) -> StartIterationResult: ...


class OnBeforeLLMCall(Protocol):
    """Protocol for synchronous pre-LLM call hook.

    Hook called before each LLM request. Useful for logging, monitoring, or debugging.

    Args:
        request: The LLM request about to be sent.
        context: ToolLoopAgentContext for requesting finish or checking state.
    """

    def __call__(self, request: LLMRequest, context: ToolLoopAgentContext) -> None: ...


class OnBeforeLLMCallAsync(Protocol):
    """Protocol for asynchronous pre-LLM call hook.

    Hook called before each LLM request. Async version for hooks that need
    to perform async operations (e.g., logging to external services).

    Args:
        request: The LLM request about to be sent.
        context: ToolLoopAgentContext for requesting finish or checking state.
    """

    async def __call__(self, request: LLMRequest, context: ToolLoopAgentContext) -> None: ...


class OnAfterLLMCall(Protocol):
    """Protocol for synchronous post-LLM call hook.

    Hook called after receiving LLM response. Useful for logging, monitoring, or debugging.

    Args:
        request: The original LLM request.
        response: The LLM response received.
        context: ToolLoopAgentContext for requesting finish or checking state.
    """

    def __call__(self, request: LLMRequest, response: LLMResponse, context: ToolLoopAgentContext) -> None: ...


class OnAfterLLMCallAsync(Protocol):
    """Protocol for asynchronous post-LLM call hook.

    Hook called after receiving LLM response. Async version for hooks that need
    to perform async operations (e.g., logging to external services).

    Args:
        request: The original LLM request.
        response: The LLM response received.
        context: ToolLoopAgentContext for requesting finish or checking state.
    """

    async def __call__(self, request: LLMRequest, response: LLMResponse, context: ToolLoopAgentContext) -> None: ...


class OnResultMessage(Protocol):
    """Protocol for synchronous result message hook.

    Hook called when LLM returns END_TURN. Allows adding messages to continue reasoning
    instead of finishing the loop.

    Args:
        message: The assistant message with the result.
        context: ToolLoopAgentContext for requesting finish or checking state.

    Returns:
        ResultMessageResult with optional additional_messages.
        If additional_messages is not empty, the loop continues instead of finishing.
    """

    def __call__(self, message: AssistantMessage, context: ToolLoopAgentContext) -> ResultMessageResult: ...


class OnResultMessageAsync(Protocol):
    """Protocol for asynchronous result message hook.

    Hook called when LLM returns END_TURN. Allows adding messages to continue reasoning
    instead of finishing the loop. Async version for hooks that need to perform async operations.

    Args:
        message: The assistant message with the result.
        context: ToolLoopAgentContext for requesting finish or checking state.

    Returns:
        ResultMessageResult with optional additional_messages.
        If additional_messages is not empty, the loop continues instead of finishing.
    """

    async def __call__(self, message: AssistantMessage, context: ToolLoopAgentContext) -> ResultMessageResult: ...


class OnBeforeToolCall(Protocol):
    """Protocol for synchronous pre-tool call hook.

    Hook called before each tool execution. Allows modifying tool use parameters.

    Args:
        tool_use: The tool use block about to be executed.
        context: ToolLoopAgentContext for requesting finish or checking state.

    Returns:
        BeforeToolCallResult with optional amended_tool_use.
    """

    def __call__(self, tool_use: ToolUseBlock, context: ToolLoopAgentContext) -> BeforeToolCallResult: ...


class OnBeforeToolCallAsync(Protocol):
    """Protocol for asynchronous pre-tool call hook.

    Hook called before each tool execution. Allows modifying tool use parameters.
    Async version for hooks that need to perform async operations.

    Args:
        tool_use: The tool use block about to be executed.
        context: ToolLoopAgentContext for requesting finish or checking state.

    Returns:
        BeforeToolCallResult with optional amended_tool_use.
    """

    async def __call__(self, tool_use: ToolUseBlock, context: ToolLoopAgentContext) -> BeforeToolCallResult: ...


class OnAfterToolCall(Protocol):
    """Protocol for synchronous tool result processing hook.

    Hook called after each tool execution. Allows modifying tool results
    and adding extra messages.

    Args:
        tool_use: The original tool use block from the LLM.
        result: The tool execution result block.
        context: ToolLoopAgentContext for requesting finish or checking state.

    Returns:
        AfterToolCallResult with optional amended_result and additional_messages.
    """

    def __call__(
        self, tool_use: ToolUseBlock, result: ToolResultBlock, context: ToolLoopAgentContext
    ) -> AfterToolCallResult: ...


class OnAfterToolCallAsync(Protocol):
    """Protocol for asynchronous tool result processing hook.

    Hook called after each tool execution. Allows modifying tool results
    and adding extra messages. Async version for hooks that need to perform
    async operations (e.g., API calls, database queries).

    Args:
        tool_use: The original tool use block from the LLM.
        result: The tool execution result block.
        context: ToolLoopAgentContext for requesting finish or checking state.

    Returns:
        AfterToolCallResult with optional amended_result and additional_messages.
    """

    async def __call__(
        self, tool_use: ToolUseBlock, result: ToolResultBlock, context: ToolLoopAgentContext
    ) -> AfterToolCallResult: ...


class OnTextReasoning(Protocol):
    """Hook called for each text block in the assistant's response.

    Fires for text blocks regardless of stop reason — allows observing
    the LLM's reasoning even when the response also contains tool calls.

    Args:
        text: The text block from the assistant's response.
        context: ToolLoopAgentContext for requesting finish or checking state.
    """

    def __call__(self, text: TextBlock, context: ToolLoopAgentContext) -> None: ...


class OnTextReasoningAsync(Protocol):
    """Async version of OnTextReasoning."""

    async def __call__(self, text: TextBlock, context: ToolLoopAgentContext) -> None: ...


class OnThinking(Protocol):
    """Hook called for each thinking block in the assistant's response.

    Fires for thinking blocks produced by models with thinking/reasoning enabled
    (e.g. Gemini 3.1 with thinking). Allows observing the model's internal
    chain-of-thought reasoning.

    Args:
        thinking: The thinking block from the assistant's response.
        context: ToolLoopAgentContext for requesting finish or checking state.
    """

    def __call__(self, thinking: ThinkingBlock, context: ToolLoopAgentContext) -> None: ...


class OnThinkingAsync(Protocol):
    """Async version of OnThinking."""

    async def __call__(self, thinking: ThinkingBlock, context: ToolLoopAgentContext) -> None: ...


class OnMessageAccepted(Protocol):
    """Hook called after user message is accepted into session and flushed.

    Fires once per tool loop start, after the user message has been
    appended to turn_messages and persisted via flush. Useful for
    tracking which messages the agent has accepted (e.g. in interrupt scenarios).

    Args:
        meta: Optional metadata from the spec, typically containing message IDs.
    """

    def __call__(self, meta: dict[str, Any] | None) -> None: ...


class OnMessageAcceptedAsync(Protocol):
    """Async version of OnMessageAccepted."""

    async def __call__(self, meta: dict[str, Any] | None) -> None: ...


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolLoopHooks:
    """All lifecycle hooks for ToolLoopAgent.

    Provided as a DI service — no need to thread hooks through config layers.
    """

    on_user_message: OnUserMessage | OnUserMessageAsync | None = None
    on_message_accepted: OnMessageAccepted | OnMessageAcceptedAsync | None = None
    on_start_iteration: OnStartIteration | OnStartIterationAsync | None = None
    on_before_llm_call: OnBeforeLLMCall | OnBeforeLLMCallAsync | None = None
    on_after_llm_call: OnAfterLLMCall | OnAfterLLMCallAsync | None = None
    on_result_message: OnResultMessage | OnResultMessageAsync | None = None
    on_text_reasoning: OnTextReasoning | OnTextReasoningAsync | None = None
    on_thinking: OnThinking | OnThinkingAsync | None = None
    on_before_tool_call: OnBeforeToolCall | OnBeforeToolCallAsync | None = None
    on_after_tool_call: OnAfterToolCall | OnAfterToolCallAsync | None = None
