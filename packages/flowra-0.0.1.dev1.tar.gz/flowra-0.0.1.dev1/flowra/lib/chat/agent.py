from typing import ClassVar

from ...agent import Agent, AgentDefinitionRef, AppendOnlyList, Call, ServiceLocator, Spawn, slot, step
from ...llm import Message, TextBlock
from ..config_value import resolve_config_value
from ..tool_loop import ToolLoopAgent, ToolLoopConfig, ToolLoopResult, ToolLoopSpec
from .config import ChatConfig
from .hook_executor import execute_save_turn_messages_hook
from .hooks import ChatHooks
from .spec import ChatResult, ChatSpec

__all__ = ["ChatAgent"]


class ChatAgent(Agent):
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "tool_loop": ToolLoopAgent,
    }

    __session_messages: AppendOnlyList[Message] = slot("session_messages")

    def __init__(
        self,
        services: ServiceLocator,
        config: ChatConfig,
        hooks: ChatHooks | None = None,
    ) -> None:
        self.__config = config
        self.__hooks = hooks or ChatHooks()
        services.provide(
            ToolLoopConfig,
            ToolLoopConfig(
                llm_config=config.llm_config,
                session_messages=self.__combined_session_messages,
                json_schema=config.json_schema,
                allowed_tools=config.allowed_tools,
                denied_tools=config.denied_tools,
                max_iterations=config.max_iterations,
                cache_strategy=config.cache_strategy,
                max_consecutive_errors=config.max_consecutive_errors,
            ),
        )

    async def __combined_session_messages(self) -> list[Message]:
        system = await resolve_config_value(self.__config.system_messages)
        return system + self.__session_messages.get_all()

    @step("process_message")
    async def process_message(self, spec: ChatSpec) -> Spawn:
        return Spawn(
            children=[
                Call(
                    agent=ToolLoopAgent,
                    step=ToolLoopAgent.start,
                    spec=ToolLoopSpec(user_message=spec.user_message, meta=spec.meta),
                ),
            ],
            then=self.collect_result,
        )

    @step("collect_result")
    async def collect_result(self, result: ToolLoopResult) -> ChatResult:
        messages = result.messages
        hook_result = await execute_save_turn_messages_hook(self.__hooks.on_save_turn_messages, messages)
        if hook_result is not None:
            messages = hook_result
        self.__session_messages.extend(messages)

        response: str | None = None
        if result.result_message is not None:
            texts = [block.text for block in result.result_message.blocks if isinstance(block, TextBlock)]
            if texts:
                response = "\n".join(texts)

        return ChatResult(response=response, usage=result.usage)
