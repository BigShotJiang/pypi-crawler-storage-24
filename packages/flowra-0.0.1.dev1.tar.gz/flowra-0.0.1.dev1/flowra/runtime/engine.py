import asyncio
import dataclasses
from collections.abc import Awaitable, Callable, Iterable
from typing import Any

from ..agent import (
    NEW_SCOPE,
    AgentDefinition,
    AgentInstance,
    AgentRegistry,
    AgentResult,
    Call,
    Goto,
    Spawn,
    StepResult,
    StepSpec,
)
from .execution import ChildResult, ExecutionNode, ExecutionStatus
from .runtime_scope import RuntimeScope

__all__ = [
    "AdvanceResult",
    "Completed",
    "Engine",
    "InstanceFactory",
    "Progressed",
    "ScopeFactory",
    "ScopeRestoreCallback",
]

type ScopeFactory = Callable[[dict[type, Any]], RuntimeScope]
type ScopeRestoreCallback = Callable[[RuntimeScope, str | None, str, str], Awaitable[None]]
type InstanceFactory = Callable[[AgentDefinition, RuntimeScope, dict[type, Any]], AgentInstance]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Completed:
    result: AgentResult | None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Progressed:
    pass


type AdvanceResult = Completed | Progressed


class Engine:
    __slots__ = (
        "__instance_factory",
        "__live_storage_keys",
        "__registry",
        "__scope_factory",
        "__scope_restore",
        "__services",
    )

    def __init__(
        self,
        registry: AgentRegistry,
        scope_factory: ScopeFactory,
        instance_factory: InstanceFactory,
        services: dict[type, Any] | None = None,
        scope_restore: ScopeRestoreCallback | None = None,
    ) -> None:
        self.__registry = registry
        self.__scope_factory = scope_factory
        self.__instance_factory = instance_factory
        self.__services: dict[type, Any] = services or {}
        self.__live_storage_keys: set[str] = set()
        self.__scope_restore = scope_restore

    def register_live_storage_keys(self, root: ExecutionNode) -> None:
        if root.status != ExecutionStatus.COMPLETED and root.storage_key is not None:
            self.__acquire_storage_key(root.storage_key)
        if root.children:
            for child in root.children:
                self.register_live_storage_keys(child)

    async def build_root(
        self,
        agent: str,
        step: str,
        spec: StepSpec | None = None,
        *,
        storage_key: str | None = None,
        node_id: str = "root",
    ) -> ExecutionNode:
        defn = self.__registry.get(agent)
        return await self.__create_node(
            node_id=node_id,
            agent_name=agent,
            defn=defn,
            step=step,
            spec=spec,
            parent_services={},
            parent=None,
            storage_key=storage_key,
        )

    async def advance(self, root: ExecutionNode) -> AdvanceResult:
        # Propagate completions from the previous cycle. This prunes children
        # whose dirty scopes have already been saved by __save_post_advance.
        self.__propagate_completions(root)

        if root.status == ExecutionStatus.COMPLETED:
            return Completed(result=root.result)

        actionable = self.__collect_actionable(root)
        if not actionable:
            msg = "No actionable nodes found but root is not completed"
            raise RuntimeError(msg)

        step_results = await self.__execute_nodes(actionable)

        for node, step_result in zip(actionable, step_results):
            await self.__apply_result(node, step_result)

        # Re-read status — __apply_result may have set it to COMPLETED.
        match ExecutionStatus(root.status):
            case ExecutionStatus.COMPLETED:
                return Completed(result=root.result)
            case ExecutionStatus.PENDING_STEP | ExecutionStatus.WAITING_CHILDREN:
                return Progressed()

    def __collect_actionable(self, node: ExecutionNode) -> list[ExecutionNode]:
        result: list[ExecutionNode] = []
        match node.status:
            case ExecutionStatus.PENDING_STEP:
                result.append(node)
            case ExecutionStatus.WAITING_CHILDREN:
                assert node.children is not None
                for child in node.children:
                    result.extend(self.__collect_actionable(child))
            case ExecutionStatus.COMPLETED:
                pass
        return result

    async def __execute_nodes(self, nodes: Iterable[ExecutionNode]) -> list[StepResult]:
        return list(await asyncio.gather(*(self.__execute_node(node) for node in nodes)))

    @staticmethod
    async def __execute_node(node: ExecutionNode) -> StepResult:
        assert node.pending_step is not None
        plain_results = [cr.result for cr in node.child_results] if node.child_results is not None else None
        return await node.instance.call_step(node.pending_step, node.pending_spec, plain_results)

    async def __apply_result(self, node: ExecutionNode, step_result: StepResult) -> None:
        match step_result:
            case AgentResult() | None:
                node.status = ExecutionStatus.COMPLETED
                node.result = step_result
                node.pending_step = None
                node.pending_spec = None
                node.child_results = None
                self.__release_storage_key(node)

            case Goto(agent=agent_ref, step=next_step, spec=next_spec, storage_key=sk):
                ctx = node.agent_name
                resolved = self.__registry.resolve(agent_ref, context=ctx) if agent_ref is not None else None
                needs_new_agent = resolved is not None and resolved.name != node.agent_name
                needs_new_scope = (
                    sk is NEW_SCOPE
                    or (sk is None and needs_new_agent)
                    or (isinstance(sk, str) and sk != node.storage_key)
                )

                if needs_new_scope:
                    self.__release_storage_key(node)
                    if isinstance(sk, str):
                        new_key = sk
                    else:
                        node.goto_counter += 1
                        new_key = f"{node.node_id}:goto:{node.goto_counter}"
                    self.__acquire_storage_key(new_key)
                    node.storage_key = new_key

                    inherited = node.scope.get_inherited_services()
                    new_scope = self.__scope_factory(inherited)
                    merged = {**self.__services, **inherited}
                    defn = resolved.definition if needs_new_agent and resolved is not None else node.defn
                    new_instance = self.__instance_factory(defn, new_scope, merged)
                    effective_agent = resolved.name if needs_new_agent and resolved is not None else node.agent_name
                    if self.__scope_restore is not None:
                        await self.__scope_restore(new_scope, new_key, node.node_id, effective_agent)

                    node.scope = new_scope
                    node.instance = new_instance
                    if needs_new_agent:
                        assert resolved is not None
                        node.agent_name = resolved.name
                        node.defn = defn
                elif needs_new_agent:
                    assert resolved is not None
                    inherited = node.scope.get_inherited_services()
                    new_scope = self.__scope_factory(inherited)
                    merged = {**self.__services, **inherited}
                    new_instance = self.__instance_factory(resolved.definition, new_scope, merged)
                    if self.__scope_restore is not None:
                        await self.__scope_restore(new_scope, node.storage_key, node.node_id, resolved.name)

                    node.agent_name = resolved.name
                    node.defn = resolved.definition
                    node.instance = new_instance
                    node.scope = new_scope

                node.pending_step = next_step
                node.pending_spec = next_spec
                node.child_results = None

            case Spawn(children=calls, then=then_step):
                node.status = ExecutionStatus.WAITING_CHILDREN
                node.pending_step = None
                node.pending_spec = None
                node.child_results = None
                node.then_step = then_step
                node.children = []
                parent_services = node.scope.get_services()
                for child_index, call in enumerate(calls):
                    child = await self.__create_child_node(call, node.defn, parent_services, node, child_index)
                    node.children.append(child)

    def __propagate_completions(self, root: ExecutionNode) -> None:
        if root.status != ExecutionStatus.WAITING_CHILDREN:
            return
        assert root.children is not None

        for child in root.children:
            self.__propagate_completions(child)

        if all(c.status == ExecutionStatus.COMPLETED for c in root.children):
            root.child_results = [
                ChildResult(agent_name=c.agent_name, result=c.result) for c in root.children if c.result is not None
            ]
            root.status = ExecutionStatus.PENDING_STEP
            root.pending_step = root.then_step
            root.pending_spec = None
            root.then_step = None
            root.children = None

    def __acquire_storage_key(self, storage_key: str) -> None:
        if storage_key in self.__live_storage_keys:
            msg = f"Duplicate storage_key: {storage_key!r}"
            raise ValueError(msg)
        self.__live_storage_keys.add(storage_key)

    def __release_storage_key(self, node: ExecutionNode) -> None:
        if node.storage_key is not None and node.storage_key in self.__live_storage_keys:
            self.__live_storage_keys.discard(node.storage_key)

    async def __create_node(
        self,
        node_id: str,
        agent_name: str,
        defn: AgentDefinition,
        step: str,
        spec: StepSpec | None,
        parent_services: dict[type, Any],
        parent: ExecutionNode | None,
        storage_key: str | None = None,
    ) -> ExecutionNode:
        if storage_key is not None:
            self.__acquire_storage_key(storage_key)
        merged = {**self.__services, **parent_services}
        scope = self.__scope_factory(merged)
        instance = self.__instance_factory(defn, scope, merged)
        if self.__scope_restore is not None:
            await self.__scope_restore(scope, storage_key, node_id, agent_name)
        return ExecutionNode(
            node_id=node_id,
            storage_key=storage_key,
            agent_name=agent_name,
            defn=defn,
            instance=instance,
            scope=scope,
            status=ExecutionStatus.PENDING_STEP,
            pending_step=step,
            pending_spec=spec,
            parent=parent,
        )

    async def __create_child_node(
        self,
        call: Call,
        parent_defn: AgentDefinition,
        parent_services: dict[type, Any],
        parent: ExecutionNode,
        child_index: int,
    ) -> ExecutionNode:
        child_node_id = f"{parent.node_id}.{child_index}"
        if isinstance(call.storage_key, str) or call.storage_key is None:
            storage_key = call.storage_key
        else:
            storage_key = f"{child_node_id}:auto"
        merged = {**self.__services, **parent_services}
        if call.agent is None:
            if storage_key is not None:
                self.__acquire_storage_key(storage_key)
                scope = self.__scope_factory(merged)
            else:
                scope = parent.scope.fork(parent_services=merged)
            instance = self.__instance_factory(parent_defn, scope, merged)
            if self.__scope_restore is not None:
                await self.__scope_restore(scope, storage_key, child_node_id, parent.agent_name)
            return ExecutionNode(
                node_id=child_node_id,
                storage_key=storage_key,
                agent_name=parent.agent_name,
                defn=parent_defn,
                instance=instance,
                scope=scope,
                status=ExecutionStatus.PENDING_STEP,
                pending_step=call.step,
                pending_spec=call.spec,
                parent=parent,
            )
        resolved = self.__registry.resolve(call.agent, context=parent.agent_name)
        return await self.__create_node(
            node_id=child_node_id,
            agent_name=resolved.name,
            defn=resolved.definition,
            step=call.step,
            spec=call.spec,
            parent_services=parent_services,
            parent=parent,
            storage_key=storage_key,
        )
