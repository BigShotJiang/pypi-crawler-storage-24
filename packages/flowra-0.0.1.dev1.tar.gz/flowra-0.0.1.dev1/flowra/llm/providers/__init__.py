from types import ModuleType

_MODULES = {"anthropic_vertex", "google_vertex", "openai"}


def __getattr__(name: str) -> ModuleType:
    if name in _MODULES:
        import importlib

        return importlib.import_module(f".{name}", __name__)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
