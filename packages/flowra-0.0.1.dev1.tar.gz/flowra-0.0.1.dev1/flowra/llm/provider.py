import abc

from .request import LLMRequest
from .response import LLMResponse

__all__ = ["LLMProvider"]


class LLMProvider(abc.ABC):
    __slots__ = ()

    @abc.abstractmethod
    async def call(self, request: LLMRequest) -> LLMResponse: ...
