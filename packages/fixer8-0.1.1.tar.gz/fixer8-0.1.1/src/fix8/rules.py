RULES = {

    # ================= Espaços em torno de operadores =================

    "E201": ("delete", " "),  # whitespace after '('
    "E202": ("delete", " "),  # whitespace before ')'
    "E203": ("delete", " "),  # whitespace before ':'
    "E211": ("delete", " "),  # whitespace before '('
    "E221": ("delete", " "),  # multiple spaces before operator
    "E222": ("delete", " "),  # multiple spaces after operator

    "E223": ("add", " "),     # missing whitespace around operator
    "E224": ("add", " "),
    "E225": ("add", " "),
    "E226": ("add", " "),
    "E227": ("add", " "),
    "E228": ("add", " "),
    "E231": ("add", " "),     # missing whitespace after ',', ';', ':'

    "E241": ("delete", " "),  # multiple spaces after ','
    "E242": ("delete", " "),

    "E251": ("add", " "),
    "E252": ("delete", " "),


    # ================= Linhas em branco =================

    "E301": ("add_line", 1),  # expected 1 blank line
    "E302": ("add_line", 2),  # expected 2 blank lines
    "E303": ("delete_blank", None),  # too many blank lines
    "E304": ("delete", None),   # blank line after decorator
    "E305": ("add_line", 2),  # expected 2 blank lines after class/function

    "W293": ("delete", None),   # blank line contains whitespace
    "W391": ("delete", None),   # blank line at end of file


    # ================= Final de arquivo =================

    "W292": ("add", "\n"),      # newline at end of file


    # ================= Espaços desnecessários =================

    #"W291": ("delete", None),  # trailing whitespace
    #"W191": ("delete", None),  # indentation contains tabs


    # ================= Indentação =================

    #"E111": ("delete", None),  # indentation not multiple of four
    #"E114": ("delete", None),
    #"E116": ("delete", None),
    #"E117": ("delete", None),

    #"E121": ("delete", None),
    #"E122": ("delete", None),
    #"E123": ("delete", None),

    #"E124": ("delete", None),
    #"E125": ("delete", None),
    #"E126": ("delete", None),
    #"E127": ("delete", None),
    #"E128": ("delete", None),


    # ================= Outras formatações =================

    #"E701": ("split", None),  # multiple statements on one line
    #"E702": ("split", None),
    #"E703": ("split", None),
    #"E704": ("add", " "),

    #"E711": ("replace", "is None comparison"),
    #"E712": ("replace", "comparison operators"),
    #"E713": ("replace", "not in comparison"),
    #"E714": ("replace", "ambiguous operator"),

    #"E721": ("replace", "type() check"),
    #"E731": ("replace", "lambda assignment"),

    #"E741": ("replace", "ambiguous variable name"),
    #"E742": ("replace", "ambiguous class name"),
    #"E743": ("replace", "ambiguous function name"),


    # ================= Comentários =================

    "E261": ("add", " "),      # two spaces before inline comment
    "E262": ("delete", " "),   # inline comment start
    "E265": ("add", " "),      # block comment "# "

    "E266": ("delete", None),  # too many leading '#'

    "E271": ("add", " "),      # multiple spaces after keyword
    "E272": ("delete", " "),


    # ================= F-codes =================

    #"F401": ("delete", None),
    #"F403": ("delete", None),
    #"F405": ("delete", None),
    #"F821": ("delete", None),
    #"F822": ("delete", None),
    #"F823": ("delete", None),


    # ================= Linhas longas =================

    #"E501": ("wrap", 79),
    #"E502": ("split", None),


    # ================= Bugbear =================

    #"B001": ("replace", "bugbear warning"),
    #"B002": ("replace", "bugbear warning"),
    #"B003": ("replace", "bugbear warning"),
    #"B004": ("replace", "bugbear warning"),
    #"B005": ("replace", "bugbear warning"),


    # ================= Comprehensions =================

    #"C400": ("replace", "comprehension warning"),
    #"C401": ("replace", "comprehension warning"),
    #"C402": ("replace", "comprehension warning"),
    #"C403": ("replace", "comprehension warning"),
    #"C404": ("replace", "comprehension warning"),


    # ================= Outros =================

    #"W605": ("replace", "invalid escape sequence"),

    #"W504": ("split", None),
}