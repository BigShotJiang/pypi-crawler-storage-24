"""Basic Anycast Agent example.

Run with:
    python -m examples.basic_agent
"""

import asyncio
from anycast_agent import AnycastAgent, AgentInfo


async def main():
    agent = AnycastAgent(
        rendezvous_url="wss://agents.anycast.com/rendezvous",
        token="agt_your_token_here",
    )

    @agent.on_connect
    async def on_connect(info: AgentInfo):
        print(f"Connected as {info.agent_id} ({info.name})")

    @agent.on_disconnect
    async def on_disconnect(reason: str):
        print(f"Disconnected: {reason}")

    @agent.on_peer
    async def on_peer(agent_id: str, status: str):
        print(f"Peer {agent_id} is {status}")

    @agent.on_error
    async def on_error(err):
        print(f"Error: {err} (code={err.code}, fatal={err.fatal})")

    # Connect and run until interrupted
    try:
        info = await agent.connect()
        print(f"Agent ID: {info.agent_id}")
        print(f"Tenant: {info.tenant_id}")

        # Request a connection to another agent
        # session_id = agent.request_connection("target-agent-id")
        # print(f"Requested connection, session: {session_id}")

        await agent.run_forever()
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        await agent.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
