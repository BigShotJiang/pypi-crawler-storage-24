"""Anycast Agent SDK — Python client for Anycast Agents P2P connectivity."""

from .agent import AnycastAgent
from .types import AgentInfo, AgentOptions, ConnectionState
from .exceptions import (
    AnycastError,
    AnycastAuthError,
    AnycastConnectionError,
    AnycastTimeoutError,
)

__all__ = [
    "AnycastAgent",
    "AgentInfo",
    "AgentOptions",
    "ConnectionState",
    "AnycastError",
    "AnycastAuthError",
    "AnycastConnectionError",
    "AnycastTimeoutError",
]

__version__ = "0.1.0"
