"""Anycast Agent exceptions."""


class AnycastError(Exception):
    """Base error for Anycast Agent SDK."""

    def __init__(self, message: str, code: str, fatal: bool = False):
        super().__init__(message)
        self.code = code
        self.fatal = fatal


class AnycastConnectionError(AnycastError):
    """Raised when the WebSocket connection fails."""

    def __init__(self, message: str):
        super().__init__(message, code="CONNECTION_FAILED", fatal=False)


class AnycastAuthError(AnycastError):
    """Raised when authentication with the rendezvous server fails."""

    def __init__(self, message: str):
        super().__init__(message, code="AUTH_FAILED", fatal=True)


class AnycastTimeoutError(AnycastError):
    """Raised when the connection or registration times out."""

    def __init__(self, message: str = "Connection timeout"):
        super().__init__(message, code="TIMEOUT", fatal=False)
