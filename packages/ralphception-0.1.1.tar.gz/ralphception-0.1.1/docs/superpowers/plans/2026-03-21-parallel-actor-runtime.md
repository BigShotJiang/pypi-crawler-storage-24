# Parallel Actor Runtime Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the current serial shared-runtime mission loop with a single long-running actor-based orchestrator that runs Socratic intake up front, then autonomously plans, schedules parallel worktrees, selects the best merge candidates, and audits to completion.

**Architecture:** This plan treats the approved spec as a breaking-architecture rewrite, not an incremental extension of the existing `headless.py` supervisor. The implementation is divided into independently reviewable chunks: durable mission store and models, intake/spec approval flow, planner outputs, scheduler and worker pool, merge agent, and audit/cutover. Each chunk is designed to produce working, testable software before the next chunk begins.

**Tech Stack:** Python 3.12, Pydantic models, Typer/Textual frontends, Codex CLI app-server backend, git worktrees, JSON durable state under `.ralphception/`, `pytest`, `ty`

---

## Scope Note

The spec covers multiple subsystems. Do not execute this as one giant uninterrupted coding pass. Treat each chunk below as its own reviewable implementation slice. If you need to split further, split along chunk boundaries rather than inventing new architectural seams mid-implementation.

## Planned File Structure

### New runtime packages

- Create: `src/ralphception/actor_runtime/__init__.py`
- Create: `src/ralphception/actor_runtime/orchestrator.py`
- Create: `src/ralphception/actor_runtime/intake_actor.py`
- Create: `src/ralphception/actor_runtime/planner_actor.py`
- Create: `src/ralphception/actor_runtime/scheduler_actor.py`
- Create: `src/ralphception/actor_runtime/worker_actor.py`
- Create: `src/ralphception/actor_runtime/merge_actor.py`
- Create: `src/ralphception/actor_runtime/audit_actor.py`

### New durable model modules

- Create: `src/ralphception/models/mission.py`
- Create: `src/ralphception/models/todos.py`
- Create: `src/ralphception/models/commit_intents.py`

### New storage helpers

- Create: `src/ralphception/storage/mission_store.py`
- Create: `src/ralphception/storage/todos.py`
- Create: `src/ralphception/storage/commit_intents.py`

### Existing files to adapt

- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/cli.py`
- Modify: `src/ralphception/git/worktrees.py`
- Modify: `src/ralphception/git/merge.py`
- Modify: `src/ralphception/models/__init__.py`
- Modify: `src/ralphception/config.py`
- Modify: `README.md`

### Legacy runtime files to deprecate or shrink

- Modify: `src/ralphception/headless.py`
  Goal: either reduce it to a compatibility shim over the new orchestrator or remove its orchestration responsibilities entirely.

### Tests

- Create: `tests/unit/test_actor_runtime_models.py`
- Create: `tests/unit/test_scheduler_actor.py`
- Create: `tests/unit/test_merge_actor.py`
- Create: `tests/unit/test_mission_store.py`
- Create: `tests/integration/test_actor_runtime_resume.py`
- Create: `tests/integration/test_actor_runtime_parallel.py`
- Create: `tests/integration/test_actor_runtime_merge_selection.py`
- Create: `tests/e2e/test_actor_runtime_terminal.py`
- Modify: `tests/unit/test_runtime_supervisor.py`
- Modify: `tests/unit/test_codex_client.py`
- Modify: `tests/integration/test_headless_supervisor.py`
- Modify: `tests/integration/test_startup_flow.py`
- Modify: `tests/e2e/test_core_runtime.py`

## Chunk 1: Mission Store and Durable Models

### Task 1: Add mission, todo, and commit-intent models

**Files:**
- Create: `src/ralphception/models/mission.py`
- Create: `src/ralphception/models/todos.py`
- Create: `src/ralphception/models/commit_intents.py`
- Modify: `src/ralphception/models/__init__.py`
- Test: `tests/unit/test_actor_runtime_models.py`

- [ ] **Step 1: Write the failing model-contract tests**

```python
def test_todo_node_requires_dependency_ids_to_be_unique() -> None:
    TodoNode(
        todo_id="todo-1",
        title="Add scheduler",
        dependency_ids=["todo-0", "todo-0"],
        status="ready",
        commit_intent_id="intent-1",
        scope_hints=["src/ralphception/actor_runtime/scheduler_actor.py"],
    )
```

```python
def test_commit_intent_rejects_empty_todo_membership() -> None:
    CommitIntent(
        intent_id="intent-1",
        message="feat: add scheduler",
        todo_ids=[],
        ordering_after=[],
    )
```

- [ ] **Step 2: Run the new model tests to verify they fail**

Run: `uv run pytest tests/unit/test_actor_runtime_models.py -q`
Expected: FAIL because the new model modules do not exist yet.

- [ ] **Step 3: Write the minimal durable models**

```python
class TodoNode(DurableModel):
    todo_id: str
    title: str
    dependency_ids: list[str]
    status: Literal["blocked", "ready", "assigned", "running", "completed", "failed", "dropped"]
    commit_intent_id: str
    scope_hints: list[str]
    assigned_worker_id: str | None = None
```

```python
class CommitIntent(DurableModel):
    intent_id: str
    message: str
    todo_ids: list[str]
    ordering_after: list[str]
    winning_candidate_id: str | None = None
```

```python
class MissionSession(DurableModel):
    mission_id: str
    repo_root: str
    phase: Literal["intake", "spec_review", "planning", "scheduling", "merging", "audit", "completed", "failed"]
    approved_spec_version: int | None = None
```

- [ ] **Step 4: Run the model tests and fix validation edge cases until they pass**

Run: `uv run pytest tests/unit/test_actor_runtime_models.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/models/mission.py src/ralphception/models/todos.py src/ralphception/models/commit_intents.py src/ralphception/models/__init__.py tests/unit/test_actor_runtime_models.py
git commit -m "feat: add actor runtime durable models"
```

### Task 2: Add a mission store for actor snapshots and durable state

**Files:**
- Create: `src/ralphception/storage/mission_store.py`
- Create: `src/ralphception/storage/todos.py`
- Create: `src/ralphception/storage/commit_intents.py`
- Test: `tests/unit/test_mission_store.py`

- [ ] **Step 1: Write failing persistence tests for mission session, todo DAG, and commit intents**

```python
def test_mission_store_round_trips_todo_graph(tmp_path: Path) -> None:
    store = MissionStore(tmp_path)
    todo = TodoNode(...)
    store.write_todos([todo])
    assert store.read_todos() == [todo]
```

- [ ] **Step 2: Run the persistence tests to verify they fail**

Run: `uv run pytest tests/unit/test_mission_store.py -q`
Expected: FAIL because `MissionStore` does not exist yet.

- [ ] **Step 3: Implement the minimal store API**

```python
class MissionStore:
    def write_session(self, session: MissionSession) -> None: ...
    def read_session(self) -> MissionSession | None: ...
    def write_todos(self, todos: list[TodoNode]) -> None: ...
    def read_todos(self) -> list[TodoNode]: ...
    def write_commit_intents(self, intents: list[CommitIntent]) -> None: ...
    def read_commit_intents(self) -> list[CommitIntent]: ...
```

- [ ] **Step 4: Run the new persistence tests and then the existing storage smoke tests**

Run: `uv run pytest tests/unit/test_mission_store.py tests/unit/test_storage_bootstrap.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/storage/mission_store.py src/ralphception/storage/todos.py src/ralphception/storage/commit_intents.py tests/unit/test_mission_store.py
git commit -m "feat: add actor mission store"
```

## Chunk 2: Intake Actor and Spec Approval Gate

### Task 3: Introduce the intake actor and explicit spec-approval runtime phase

**Files:**
- Create: `src/ralphception/actor_runtime/intake_actor.py`
- Create: `src/ralphception/actor_runtime/orchestrator.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/cli.py`
- Test: `tests/integration/test_startup_flow.py`
- Test: `tests/e2e/test_core_runtime.py`

- [ ] **Step 1: Add a failing integration test that requires Socratic intake before spec approval**

```python
def test_terminal_launch_enters_intake_before_any_plan_artifacts(tmp_path: Path) -> None:
    result = run_terminal(repo_root=repo_root, frontend=frontend)
    assert "Socratic intake" in frontend.output_text()
    assert not (repo_root / ".ralphception" / "plans" / "mission-plan.json").exists()
```

- [ ] **Step 2: Run the targeted startup/runtime tests to verify they fail**

Run: `uv run pytest tests/integration/test_startup_flow.py tests/e2e/test_core_runtime.py -q`
Expected: FAIL because launch still routes directly through the current startup/dashboard flow.

- [ ] **Step 3: Implement the minimal intake actor and wire it into runtime launch**

```python
class IntakeActor:
    def next_prompt(self, session: MissionSession) -> IntakePrompt | None: ...
    def apply_answer(self, session: MissionSession, answer: str) -> MissionSession: ...
    def finalize_spec(self, session: MissionSession) -> ApprovedSpec: ...
```

```python
class ActorOrchestrator:
    def run_until_blocked(self, frontend: RuntimeFrontend) -> MissionSession: ...
```

- [ ] **Step 4: Re-run the targeted intake/spec-approval tests**

Run: `uv run pytest tests/integration/test_startup_flow.py tests/e2e/test_core_runtime.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/actor_runtime/intake_actor.py src/ralphception/actor_runtime/orchestrator.py src/ralphception/runtime/supervisor.py src/ralphception/runtime/terminal.py src/ralphception/app.py src/ralphception/cli.py tests/integration/test_startup_flow.py tests/e2e/test_core_runtime.py
git commit -m "feat: add socratic intake actor and spec approval gate"
```

## Chunk 3: Planner Outputs, Todo DAG, and Commit Intents

### Task 4: Expand planning output from plan-only to plan + todo DAG + commit intents + execution policy

**Files:**
- Create: `src/ralphception/actor_runtime/planner_actor.py`
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/models/mission.py`
- Modify: `src/ralphception/storage/mission_store.py`
- Test: `tests/integration/test_actor_runtime_resume.py`
- Test: `tests/unit/test_headless_contracts.py`

- [ ] **Step 1: Write failing planner-output tests**

```python
def test_planner_actor_writes_todo_graph_and_commit_intents(tmp_path: Path) -> None:
    planner = PlannerActor(store=MissionStore(repo_root))
    planner.plan(approved_spec)
    assert store.read_todos()
    assert store.read_commit_intents()
```

- [ ] **Step 2: Run the targeted planner tests to verify they fail**

Run: `uv run pytest tests/unit/test_headless_contracts.py tests/integration/test_actor_runtime_resume.py -q`
Expected: FAIL because the planner still only writes plan artifacts.

- [ ] **Step 3: Implement the new planner contract**

```python
class PlannerOutput(DurableModel):
    plan_markdown_path: str
    plan_json_path: str
    todo_ids: list[str]
    commit_intent_ids: list[str]
    execution_policy: ExecutionPolicy
```

```python
class PlannerActor:
    def plan(self, approved_spec: ApprovedSpec) -> PlannerOutput: ...
```

- [ ] **Step 4: Re-run planner and resume tests**

Run: `uv run pytest tests/unit/test_headless_contracts.py tests/integration/test_actor_runtime_resume.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/actor_runtime/planner_actor.py src/ralphception/headless.py src/ralphception/models/mission.py src/ralphception/storage/mission_store.py tests/unit/test_headless_contracts.py tests/integration/test_actor_runtime_resume.py
git commit -m "feat: add planner outputs for todos and commit intents"
```

## Chunk 4: Scheduler, Worker Pool, and Parallel Worktrees

### Task 5: Replace single-child runtime state with scheduler-managed worker pool

**Files:**
- Create: `src/ralphception/actor_runtime/scheduler_actor.py`
- Create: `src/ralphception/actor_runtime/worker_actor.py`
- Modify: `src/ralphception/git/worktrees.py`
- Modify: `src/ralphception/config.py`
- Test: `tests/unit/test_scheduler_actor.py`
- Test: `tests/integration/test_actor_runtime_parallel.py`

- [ ] **Step 1: Write failing tests for ready-queue batching and active worker limits**

```python
def test_scheduler_batches_multiple_compatible_todos_into_one_worker() -> None:
    scheduler = SchedulerActor(max_parallel_children=4)
    assignments = scheduler.plan_assignments(todos=ready_todos, active_workers=[])
    assert assignments[0].todo_ids == ["todo-1", "todo-2"]
```

```python
def test_scheduler_respects_max_parallel_children() -> None:
    assert len(assignments) <= 4
```

- [ ] **Step 2: Run scheduler and parallel integration tests to verify they fail**

Run: `uv run pytest tests/unit/test_scheduler_actor.py tests/integration/test_actor_runtime_parallel.py -q`
Expected: FAIL because the runtime still tracks one `current_child_run_id`.

- [ ] **Step 3: Implement scheduler and worker assignment flow**

```python
class SchedulerActor:
    def plan_assignments(self, *, todos: list[TodoNode], active_workers: list[WorkerAssignment]) -> list[WorkerAssignment]:
        ...
```

```python
class WorkerActor:
    def start(self, assignment: WorkerAssignment) -> WorkerCandidate: ...
```

```python
class WorkerAssignment(DurableModel):
    worker_id: str
    worktree_path: str
    todo_ids: list[str]
    claimed_commit_intent_ids: list[str]
```

- [ ] **Step 4: Re-run the scheduler/parallel tests**

Run: `uv run pytest tests/unit/test_scheduler_actor.py tests/integration/test_actor_runtime_parallel.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/actor_runtime/scheduler_actor.py src/ralphception/actor_runtime/worker_actor.py src/ralphception/git/worktrees.py src/ralphception/config.py tests/unit/test_scheduler_actor.py tests/integration/test_actor_runtime_parallel.py
git commit -m "feat: add scheduler actor and parallel worker pool"
```

## Chunk 5: Merge Agent and Final Commit Assembly

### Task 6: Add merge-agent candidate selection by commit intent

**Files:**
- Create: `src/ralphception/actor_runtime/merge_actor.py`
- Modify: `src/ralphception/git/merge.py`
- Modify: `src/ralphception/storage/commit_intents.py`
- Test: `tests/unit/test_merge_actor.py`
- Test: `tests/integration/test_actor_runtime_merge_selection.py`

- [ ] **Step 1: Write failing tests for competing candidates on the same commit intent**

```python
def test_merge_agent_selects_best_candidate_for_intent() -> None:
    decision = merge_actor.choose_candidate(intent, [candidate_a, candidate_b])
    assert decision.selected_candidate_id == "candidate-b"
    assert "candidate-a" in decision.rejected_candidate_ids
```

- [ ] **Step 2: Run merge-agent tests to verify they fail**

Run: `uv run pytest tests/unit/test_merge_actor.py tests/integration/test_actor_runtime_merge_selection.py -q`
Expected: FAIL because merge is still child-run-centric.

- [ ] **Step 3: Implement merge-agent selection and final commit mapping**

```python
class MergeAgent:
    def choose_candidate(self, intent: CommitIntent, candidates: list[WorkerCandidate]) -> MergeDecision: ...
    def land_intent(self, decision: MergeDecision) -> str: ...
```

- [ ] **Step 4: Re-run merge-agent tests**

Run: `uv run pytest tests/unit/test_merge_actor.py tests/integration/test_actor_runtime_merge_selection.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/actor_runtime/merge_actor.py src/ralphception/git/merge.py src/ralphception/storage/commit_intents.py tests/unit/test_merge_actor.py tests/integration/test_actor_runtime_merge_selection.py
git commit -m "feat: add merge agent for commit intent selection"
```

## Chunk 6: Audit Reopen, Resume, Frontend Cutover, and Documentation

### Task 7: Rework audit and resume around the actor runtime

**Files:**
- Create: `src/ralphception/actor_runtime/audit_actor.py`
- Modify: `src/ralphception/actor_runtime/orchestrator.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/ui/app.py`
- Test: `tests/integration/test_actor_runtime_resume.py`
- Test: `tests/e2e/test_actor_runtime_terminal.py`

- [ ] **Step 1: Write failing tests for crash-resume and audit-triggered replanning**

```python
def test_actor_runtime_resumes_active_workers_after_restart(tmp_path: Path) -> None:
    restarted = resume_mission(repo_root)
    assert restarted.scheduler_snapshot.active_worker_ids == ["worker-1", "worker-2"]
```

```python
def test_audit_reopens_scheduler_without_human_prompt(tmp_path: Path) -> None:
    result = run_terminal(...)
    assert "Audit reopened planning" in result.output_text()
```

- [ ] **Step 2: Run the targeted resume/audit/frontend tests to verify they fail**

Run: `uv run pytest tests/integration/test_actor_runtime_resume.py tests/e2e/test_actor_runtime_terminal.py -q`
Expected: FAIL because resume and audit still rely on the serial supervisor flow.

- [ ] **Step 3: Implement audit actor, orchestrator resume, and frontend cutover**

```python
class AuditActor:
    def evaluate(self, mission: MissionSession) -> AuditSnapshot: ...
```

```python
class ActorOrchestrator:
    def resume(self) -> MissionSession: ...
```

- [ ] **Step 4: Re-run the targeted actor-runtime tests, then the full suite**

Run: `uv run pytest tests/integration/test_actor_runtime_resume.py tests/e2e/test_actor_runtime_terminal.py -q`
Expected: PASS

Run: `uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

Run: `uv run ty check src tests`
Expected: `All checks passed!`

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/actor_runtime/audit_actor.py src/ralphception/actor_runtime/orchestrator.py src/ralphception/runtime/terminal.py src/ralphception/runtime/supervisor.py src/ralphception/ui/app.py tests/integration/test_actor_runtime_resume.py tests/e2e/test_actor_runtime_terminal.py README.md
git commit -m "feat: cut frontends over to actor runtime"
```

## Chunk Review Loop

After each chunk:

1. run the chunk-local tests listed in the steps
2. inspect the diff for accidental architectural spillover
3. update `README.md` only when the chunk changes user-visible behavior or architecture claims
4. do not start the next chunk until the current one is green and reviewable

## Final Verification Checklist

- [ ] `uv run pytest tests/unit tests/integration tests/e2e -q`
- [ ] `uv run ty check src tests`
- [ ] run one real terminal mission with a simple prompt and verify unattended completion
- [ ] run one real terminal mission, interrupt it mid-flight, and verify clean resume semantics
- [ ] verify `.ralphception/` cleanup and `.worktrees/` cleanup for terminal completion paths
- [ ] update README diagrams to match the new actor pipeline once the old serial runtime is actually gone

## Execution Notes

- Keep `headless.py` as a compatibility shim only as long as needed for the cutover. Do not build new orchestration logic into it.
- Prefer adding new actor-runtime modules rather than overloading `runtime/supervisor.py` with more state-machine code.
- Preserve meaningful git history with one commit per task or sub-task group, not one monolithic rewrite commit.
- If a chunk reveals the actor boundaries are wrong, stop and update the spec before continuing.
