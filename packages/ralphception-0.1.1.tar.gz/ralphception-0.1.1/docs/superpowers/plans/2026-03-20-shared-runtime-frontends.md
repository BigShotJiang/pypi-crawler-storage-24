# Shared Runtime Frontends Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the split TUI/headless orchestration with one long-running runtime supervisor and two frontends: Textual TUI and traditional terminal.

**Architecture:** Introduce a shared `RuntimeSupervisor` plus a small frontend protocol. Move autonomous mission progression, recovery, review gating, and runtime state transitions into the supervisor. Rebuild the existing TUI as a frontend over that supervisor and replace the current `headless` entrypoint with a log-and-prompt terminal frontend. Keep `headless` only as a thin alias to `terminal` during migration if that materially reduces churn.

**Tech Stack:** Python 3.12+, `typer`, `textual`, existing `WorkflowEngine`, `RecoveryService`, approvals/bundles/merge/audit services, deterministic fake Codex session backend, `pytest`, `git worktree`

---

## File Map

- Create: `src/ralphception/runtime/__init__.py`
  Shared runtime package exports.
- Create: `src/ralphception/runtime/supervisor.py`
  Long-running supervisor, runtime states, shared orchestration loop, and frontend callbacks.
- Create: `src/ralphception/runtime/frontends.py`
  Frontend protocol, prompt/result models, and shared rendering helpers.
- Create: `src/ralphception/runtime/terminal.py`
  Traditional terminal frontend implementation: log streaming plus blocking prompts.
- Create: `tests/unit/test_runtime_supervisor.py`
  Unit tests for supervisor transitions and parity-sensitive runtime decisions.
- Create: `tests/integration/test_terminal_frontend.py`
  Integration tests for terminal bootstrap, review prompts, and long-running mission flow.
- Modify: `src/ralphception/app.py`
  Replace split launch/runtime logic with supervisor startup and frontend selection.
- Modify: `src/ralphception/cli.py`
  Add `terminal` entrypoint, rewire default/TUI launch, and optionally keep `headless` as an alias.
- Modify: `src/ralphception/headless.py`
  Reduce to a compatibility shim or remove after callers/tests are migrated.
- Modify: `src/ralphception/ui/app.py`
  Turn the Textual app into a runtime frontend over supervisor state instead of a parallel runtime owner.
- Modify: `src/ralphception/ui/screens/startup.py`
  Convert startup capture into frontend prompt handling that feeds the shared supervisor.
- Modify: `src/ralphception/ui/screens/review.py`
  Convert review/recovery actions into frontend prompt handling that feeds the shared supervisor.
- Modify: `src/ralphception/workflow/recovery.py`
  Keep recovery logic reusable from the shared supervisor and frontends.
- Modify: `tests/integration/test_startup_flow.py`
  Update TUI integration coverage to assert parity with the shared supervisor.
- Modify: `tests/integration/test_headless_supervisor.py`
  Migrate current headless mission tests onto the shared supervisor / terminal path or replace with terminal integration coverage.
- Modify: `tests/unit/test_cli_bootstrap.py`
  Update CLI expectations for `terminal` and any transitional `headless` alias.
- Modify: `tests/unit/test_dashboard_app.py`
  Keep dashboard rendering/regression coverage while removing runtime ownership assumptions.
- Modify: `tests/e2e/test_core_runtime.py`
  Assert end-to-end parity across TUI-visible and terminal-visible runtime behavior.
- Modify: `README.md`
  Document one runtime with two frontends and update command examples.

## Chunk 1: Shared Runtime Contract

### Task 1: Introduce the supervisor and frontend protocol

**Files:**
- Create: `src/ralphception/runtime/__init__.py`
- Create: `src/ralphception/runtime/frontends.py`
- Create: `src/ralphception/runtime/supervisor.py`
- Test: `tests/unit/test_runtime_supervisor.py`

- [ ] **Step 1: Write the failing supervisor-state tests**

```python
def test_supervisor_routes_unbootstrapped_workspace_to_startup_request(tmp_path: Path) -> None:
    supervisor = RuntimeSupervisor(repo_root=tmp_path, frontend=StubFrontend())
    outcome = supervisor.step()
    assert outcome.kind == "startup_prompt"
```

```python
def test_supervisor_routes_pending_spec_to_review_request(tmp_path: Path) -> None:
    repo_root = bootstrapped_repo_with_spec(tmp_path)
    supervisor = RuntimeSupervisor(repo_root=repo_root, frontend=StubFrontend())
    outcome = supervisor.step()
    assert outcome.kind == "review_prompt"
    assert outcome.review_kind == "spec_review"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/unit/test_runtime_supervisor.py -q`
Expected: FAIL because the shared runtime package and supervisor do not exist.

- [ ] **Step 3: Write the minimal implementation**

Create:

- `FrontendEvent`, `FrontendPrompt`, and `FrontendDecision` models in `src/ralphception/runtime/frontends.py`
- a `RuntimeFrontend` protocol with methods like `emit_event(...)`, `emit_status(...)`, `prompt_startup(...)`, `prompt_review(...)`, and `finish(...)`
- a `RuntimeSupervisor` that can resolve:
  - bootstrap needed
  - review needed
  - autonomous dashboard/mission progression possible

The supervisor should become the only place that decides runtime mode.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/unit/test_runtime_supervisor.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/runtime tests/unit/test_runtime_supervisor.py
git commit -m "feat: add shared runtime supervisor"
```

## Chunk 2: Terminal Frontend

### Task 2: Replace `headless` with a real terminal frontend over the supervisor

**Files:**
- Create: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/cli.py`
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/headless.py`
- Test: `tests/integration/test_terminal_frontend.py`
- Test: `tests/unit/test_cli_bootstrap.py`

- [ ] **Step 1: Write the failing terminal frontend tests**

```python
def test_terminal_frontend_prompts_for_startup_inputs(tmp_path: Path) -> None:
    frontend = ScriptedTerminalFrontend(inputs=["port parser", ""])
    result = run_terminal(repo_root=tmp_path, frontend=frontend)
    assert "Seed prompt" in frontend.output_text()
    assert result.mode == "running"
```

```python
def test_cli_terminal_runs_shared_supervisor() -> None:
    result = CliRunner().invoke(app, ["terminal", "--seed-prompt", "port parser"])
    assert result.exit_code == 0
    assert "Runtime:" in result.stdout
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/integration/test_terminal_frontend.py tests/unit/test_cli_bootstrap.py -q`
Expected: FAIL because there is no terminal frontend or `terminal` CLI command.

- [ ] **Step 3: Write the minimal implementation**

Implement a terminal frontend that:

- prints status/log lines as the supervisor emits them
- blocks on focused prompts only when startup or review input is required
- stays attached until terminal completion or failure

Rewire CLI behavior:

- `ralphception terminal` is the canonical traditional frontend
- `ralphception headless` becomes either a thin alias to `terminal` or a removed command with a clear migration error

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/integration/test_terminal_frontend.py tests/unit/test_cli_bootstrap.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/runtime/terminal.py src/ralphception/cli.py src/ralphception/app.py src/ralphception/headless.py tests/integration/test_terminal_frontend.py tests/unit/test_cli_bootstrap.py
git commit -m "feat: add terminal runtime frontend"
```

## Chunk 3: Migrate Mission Orchestration Into The Supervisor

### Task 3: Move autonomous mission looping, approvals, merge, and audit reopen into the shared runtime

**Files:**
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/workflow/recovery.py`
- Modify: `src/ralphception/headless.py`
- Modify: `tests/integration/test_headless_supervisor.py`
- Modify: `tests/unit/test_runtime_supervisor.py`

- [ ] **Step 1: Write the failing mission-parity tests**

```python
def test_supervisor_completes_fake_mission_through_terminal_frontend(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend()
    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )
    assert result.mode == "completed"
    assert result.child_run_ids == ("run-child-1", "run-child-1-replacement-1")
```

```python
def test_supervisor_resume_path_matches_runtime_recovery(tmp_path: Path) -> None:
    repo_root = repo_with_recoverable_run(tmp_path)
    result = run_terminal(repo_root=repo_root, use_fake_session_manager=True)
    assert "Resumed run-root" in result.log_text
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/integration/test_headless_supervisor.py tests/unit/test_runtime_supervisor.py -q`
Expected: FAIL because orchestration is still split between `headless.py` and the TUI launch path.

- [ ] **Step 3: Write the minimal implementation**

Move into `RuntimeSupervisor`:

- startup bootstrap handling
- recovery/read vs repair handling
- spec/plan/execute/merge/audit progression
- approval gates and reopen loops
- fake-session mission execution

Reduce `src/ralphception/headless.py` to either:

- a thin compatibility wrapper over supervisor + terminal frontend, or
- a temporary import-compatibility layer pending deletion

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/integration/test_headless_supervisor.py tests/unit/test_runtime_supervisor.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/runtime/supervisor.py src/ralphception/workflow/recovery.py src/ralphception/headless.py tests/integration/test_headless_supervisor.py tests/unit/test_runtime_supervisor.py
git commit -m "refactor: move mission loop into shared supervisor"
```

## Chunk 4: Rebuild The TUI As A Frontend

### Task 4: Make Textual render supervisor state instead of owning runtime transitions

**Files:**
- Modify: `src/ralphception/ui/app.py`
- Modify: `src/ralphception/ui/screens/startup.py`
- Modify: `src/ralphception/ui/screens/review.py`
- Modify: `src/ralphception/app.py`
- Modify: `tests/integration/test_startup_flow.py`
- Modify: `tests/unit/test_dashboard_app.py`

- [ ] **Step 1: Write the failing TUI parity tests**

```python
def test_tui_launch_uses_supervisor_for_startup_review_and_dashboard(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    launch = resolve_runtime_view(repo_root)
    assert launch.runtime is not None
    assert launch.frontend_kind == "tui"
```

```python
def test_dashboard_selection_does_not_advance_runtime_without_supervisor_signal() -> None:
    app = RalphceptionDashboardApp(controller)
    # selecting a node should update the selection only
    ...
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/integration/test_startup_flow.py tests/unit/test_dashboard_app.py -q`
Expected: FAIL because the Textual path still resolves and advances runtime locally.

- [ ] **Step 3: Write the minimal implementation**

Update the TUI path so:

- startup screen gathers input and sends it to the supervisor
- review screen gathers decisions and sends them to the supervisor
- dashboard displays supervisor-owned state and event streams
- TUI rendering no longer owns launch branching or mission advancement

Keep the existing dashboard refresh-loop regression tests green.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/integration/test_startup_flow.py tests/unit/test_dashboard_app.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/ui/app.py src/ralphception/ui/screens/startup.py src/ralphception/ui/screens/review.py src/ralphception/app.py tests/integration/test_startup_flow.py tests/unit/test_dashboard_app.py
git commit -m "refactor: make textual ui a runtime frontend"
```

## Chunk 5: CLI, Docs, And End-To-End Parity

### Task 5: Finish the migration and verify both frontends against the same runtime

**Files:**
- Modify: `README.md`
- Modify: `tests/e2e/test_core_runtime.py`
- Modify: `tests/unit/test_cli_bootstrap.py`
- Modify: `src/ralphception/cli.py`
- Modify: `src/ralphception/app.py`

- [ ] **Step 1: Write the failing parity and docs-adjacent tests**

```python
def test_terminal_and_tui_frontends_observe_same_mission_completion(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    terminal_result = run_terminal(...)
    tui_result = run_tui_probe(...)
    assert terminal_result.root_run_status == tui_result.root_run_status
```

```python
def test_cli_help_exposes_terminal_as_primary_non_tui_frontend() -> None:
    result = CliRunner().invoke(app, ["--help"])
    assert "terminal" in result.stdout
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/e2e/test_core_runtime.py tests/unit/test_cli_bootstrap.py -q`
Expected: FAIL because docs, CLI, and parity coverage still reflect the old split.

- [ ] **Step 3: Write the minimal implementation**

Update:

- README command examples and mental model
- CLI help and command names
- end-to-end tests so terminal and TUI are validated against the same supervisor semantics

If `headless` remains as an alias, mark it transitional in docs and tests.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/e2e/test_core_runtime.py tests/unit/test_cli_bootstrap.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add README.md src/ralphception/cli.py src/ralphception/app.py tests/e2e/test_core_runtime.py tests/unit/test_cli_bootstrap.py
git commit -m "docs: align runtime frontends and cli"
```

## Chunk 6: Final Verification

### Task 6: Run the full suite and a real terminal mission smoke test

**Files:**
- Modify: only if verification exposes gaps

- [ ] **Step 1: Run the complete automated suite**

Run: `uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS with zero failures.

- [ ] **Step 2: Run type checks**

Run: `uv run ty check src tests`
Expected: `All checks passed!`

- [ ] **Step 3: Run a terminal frontend mission in a disposable git clone**

Run:

```bash
XDG_STATE_HOME="$(mktemp -d)" \
uv run ralphception terminal \
  --repo-root "$(mktemp -d)" \
  --seed-prompt "find any bugs" \
  --approve-all \
  --fake-session-manager
```

Expected:

- the process stays attached until terminal completion
- it logs startup/spec/plan/execute/merge/audit progression
- it prompts only if configured to require input
- it exits with a terminal success summary

- [ ] **Step 4: Inspect git/worktree state for the exercised clone**

Run:

```bash
git -C <clone> status --short --branch
git -C <clone> worktree list --porcelain
```

Expected:

- authoritative-root behavior matches the merge design
- no unexpected runtime divergence exists between terminal and TUI semantics

- [ ] **Step 5: Commit any final verification-driven fixes**

```bash
git add -A
git commit -m "test: verify shared runtime frontends"
```
