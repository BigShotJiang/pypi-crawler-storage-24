# Mission Cleanup Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make completed Ralphception missions clean themselves up and require explicit prompting only for genuinely in-progress mission overrides.

**Architecture:** Keep the behavior in the shared runtime. The root mission supervisor owns completion cleanup and launch-time conflict resolution. The terminal frontend only renders the conflict prompt and returns the user’s decision. Worktree cleanup continues to flow through the existing coordinator so managed worktrees remain bounded and safe.

**Tech Stack:** Python 3.12+, `typer`, shared runtime supervisor, mission loop in `src/ralphception/headless.py`, git worktree coordinator, `pytest`

---

## File Map

- Modify: `src/ralphception/runtime/supervisor.py`
  Add state-aware launch conflict handling and completed-residue cleanup.
- Modify: `src/ralphception/runtime/terminal.py`
  Prompt for `resume` / `override` / `abort` when a conflicting active mission exists.
- Modify: `src/ralphception/headless.py`
  Perform root mission cleanup after terminal completion.
- Modify: `src/ralphception/app.py`
  Keep terminal and headless entrypoints aligned with the shared runtime changes.
- Modify: `tests/integration/test_terminal_frontend.py`
  Add terminal flow coverage for conflict prompting and post-completion freshness.
- Modify: `tests/integration/test_headless_supervisor.py`
  Assert completion cleanup and restored repo root.
- Modify: `tests/unit/test_cli_bootstrap.py`
  Update CLI expectations if prompt conflicts become interactive instead of immediate errors.

## Chunk 1: Lock Behavior With Tests

### Task 1: Add failing integration tests for cleanup and conflict prompting

**Files:**
- Modify: `tests/integration/test_terminal_frontend.py`
- Modify: `tests/integration/test_headless_supervisor.py`

- [ ] **Step 1: Write the failing tests**
- [ ] **Step 2: Run the targeted tests and confirm they fail for the expected reasons**
- [ ] **Step 3: Commit the test-only red state if needed for review checkpoints**

## Chunk 2: Implement Shared Runtime Cleanup

### Task 2: Clean root mission state on terminal completion

**Files:**
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/git/worktrees.py`

- [ ] **Step 1: Add minimal completion cleanup implementation**
- [ ] **Step 2: Restore authoritative root before cleaning integration worktrees**
- [ ] **Step 3: Delete repo-local `.ralphception/` state only after worktree cleanup succeeds**
- [ ] **Step 4: Run the targeted cleanup tests and confirm they pass**

## Chunk 3: Implement Active-Mission Override Prompting

### Task 3: Prompt only when the existing mission is still active

**Files:**
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/app.py`
- Modify: `tests/integration/test_terminal_frontend.py`
- Modify: `tests/unit/test_cli_bootstrap.py`

- [ ] **Step 1: Replace unconditional prompt-conflict failure with an active-mission conflict step**
- [ ] **Step 2: Add terminal prompt handling for `resume`, `override`, and `abort`**
- [ ] **Step 3: Keep non-interactive entrypoints deterministic when no frontend is attached**
- [ ] **Step 4: Run the targeted conflict tests and confirm they pass**

## Chunk 4: Verify Full Runtime Behavior

### Task 4: Re-run terminal and fake-session end-to-end flows

**Files:**
- Modify: `README.md` if behavior text changed materially

- [ ] **Step 1: Run targeted integration tests**
- [ ] **Step 2: Run the full unit/integration/e2e suite**
- [ ] **Step 3: Run a disposable `uv run ralphception terminal --seed-prompt 'find any bugs' --approve-all --fake-session-manager` mission and confirm it leaves a fresh workspace**
- [ ] **Step 4: Commit with a focused message**
