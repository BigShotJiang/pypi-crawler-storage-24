# Ralphception Bootstrap Loop Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the helper-only bootstrap loop for dogfooding `ralphception` itself: deterministic `.ralphception/bootstrapping/` artifacts, prompt rendering, findings sync, a fresh-iteration runner, and a local untracked `ralph.sh` installer.

**Architecture:** Keep the shell script thin and disposable. All durable logic lives in tracked Python modules under `src/ralphception/bootstrap/` that model the ledger contracts, seed/sync artifacts, render the Codex prompt, and prepare one `codex exec` iteration at a time. The helper integrates with existing runtime services for findings and approvals instead of inventing a parallel state model.

**Tech Stack:** Python 3.12+, `uv`, `pytest`, `pydantic`, existing `ralphception` storage/audit/approval modules, `codex exec`

---

## File Structure

- `src/ralphception/bootstrap/__init__.py`
  Package export surface for bootstrap-loop helpers.
- `src/ralphception/bootstrap/contracts.py`
  Pydantic models for `inputs.json`, `gaps.json`, `approval-request.json`, plus deterministic plan-item reference helpers.
- `src/ralphception/bootstrap/storage.py`
  Helper-only `.ralphception/bootstrapping/` directory creation, seeding, atomic load/save helpers, finish-criteria writes, and sync into the canonical findings store.
- `src/ralphception/bootstrap/prompting.py`
  Prompt rendering from authoritative inputs plus the bundled bootstrap template.
- `src/ralphception/bootstrap/runner.py`
  One-iteration orchestration: seed if missing, stop on pending approval, write `prompt.txt`, build the `codex exec` command, and update latest-summary pointers.
- `src/ralphception/bootstrap/script.py`
  Install or refresh the local-only `ralph.sh` file and update `.git/info/exclude` so the script stays untracked.
- `src/ralphception/bundled_skills/bootstrap.loop.md`
  The tracked iteration prompt template consumed by `prompting.py`.
- `tests/unit/test_bootstrap_contracts.py`
  Contract validation, slug generation, plan-item refs, and seed-finding defaults.
- `tests/unit/test_bootstrap_storage.py`
  Bootstrapping directory creation, manifest writes, finish-criteria writes, and findings sync.
- `tests/unit/test_bootstrap_prompting.py`
  Prompt rendering and required-input coverage.
- `tests/unit/test_bootstrap_script.py`
  Local script installation and `.git/info/exclude` updates.
- `tests/integration/test_bootstrap_runner.py`
  End-to-end bootstrap iteration preparation, approval short-circuiting, prompt emission, and command building.
- `README.md`
  Optional helper-only usage note for `.ralphception/bootstrapping/` and the local `ralph.sh` flow.
- Local-only `ralph.sh` (untracked)
  Thin shell wrapper that calls the tracked Python bootstrap runner.
- Local-only `.git/info/exclude`
  Add `/ralph.sh` so the helper remains untracked.

## Chunk 1: Contracts And Ledger Storage

### Task 1: Implement bootstrap ledger contracts and deterministic identifiers

**Files:**
- Create: `src/ralphception/bootstrap/__init__.py`
- Create: `src/ralphception/bootstrap/contracts.py`
- Test: `tests/unit/test_bootstrap_contracts.py`

- [ ] **Step 1: Write the failing contract tests**

```python
from pathlib import Path

import pytest
from pydantic import ValidationError

from ralphception.bootstrap.contracts import (
    BootstrapFinding,
    BootstrapInputs,
    make_plan_item_ref,
    slugify_heading,
)


def test_slugify_heading_matches_spec_rule() -> None:
    assert (
        slugify_heading("### Task 14: Implement startup flow, first-run bootstrap, and artifact review screens")
        == "task-14-implement-startup-flow-first-run-bootstrap-and-artifact-review-screens"
    )


def test_make_plan_item_ref_uses_sha1_of_normalized_checkbox_text() -> None:
    ref = make_plan_item_ref(
        plan_path=Path("docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"),
        heading="### Task 14: Implement startup flow, first-run bootstrap, and artifact review screens",
        checkbox_text="- [ ] **Step 3: Implement startup and review flow**",
    )
    assert (
        ref
        == "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
        "#task-14-implement-startup-flow-first-run-bootstrap-and-artifact-review-screens/"
        "59a3096afd6833963d77087065353060024bb6e7"
    )


def test_bootstrap_finding_rejects_non_runtime_status_values() -> None:
    with pytest.raises(ValidationError):
        BootstrapFinding(
            gap_id="bootstrap-cli-resume",
            title="Resume CLI gap",
            severity="P1",
            bootstrap_kind="ux_gap",
            audit_kind="feature_gap",
            status="closed",
            rationale=None,
            evidence_paths=["src/ralphception/cli.py"],
            plan_item_refs=[],
        )


def test_inputs_default_to_schema_version_one_and_repo_globs() -> None:
    inputs = BootstrapInputs.default()
    assert inputs.schema_version == 1
    assert inputs.authoritative_spec_paths == [
        "docs/superpowers/specs/2026-03-15-ralphception-design.md",
        "docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md",
    ]
    assert inputs.authoritative_plan_path == "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
    assert inputs.authoritative_readme_paths == ["README.md"]
    assert inputs.authoritative_code_globs == ["src/ralphception/**"]
    assert inputs.authoritative_test_globs == ["tests/unit/**", "tests/integration/**", "tests/e2e/**"]
    assert inputs.notes == []
    assert inputs.updated_at is not None
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/unit/test_bootstrap_contracts.py -v`
Expected: FAIL because `ralphception.bootstrap.contracts` does not exist.

- [ ] **Step 3: Implement the contract models and helpers**

Include:
- `BootstrapInputs`, `BootstrapFinding`, `BootstrapGapLedger`, and `BootstrapApprovalRequest`
- `schema_version = 1` defaults
- deterministic `slugify_heading()` and `make_plan_item_ref()` helpers
- strict validation for runtime-aligned severities/statuses
- required `updated_at`, `authoritative_plan_path`, and runtime-contract fields on manifest and ledger models
- default authoritative code/test globs from the spec

```python
def slugify_heading(heading: str) -> str:
    normalized = heading.lower()
    normalized = re.sub(r"[^a-z0-9]+", "-", normalized)
    return normalized.strip("-")


def make_plan_item_ref(*, plan_path: Path, heading: str, checkbox_text: str) -> str:
    section_slug = slugify_heading(heading)
    normalized_text = " ".join(
        checkbox_text.replace("- [ ]", "").replace("- [x]", "").split()
    ).strip()
    digest = hashlib.sha1(normalized_text.encode("utf-8")).hexdigest()
    return f"{plan_path.as_posix()}#{section_slug}/{digest}"
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/unit/test_bootstrap_contracts.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/bootstrap/__init__.py src/ralphception/bootstrap/contracts.py tests/unit/test_bootstrap_contracts.py
git commit -m "feat: add bootstrap ledger contracts"
```

### Task 2: Implement bootstrap storage, seeding, and findings sync

**Files:**
- Create: `src/ralphception/bootstrap/storage.py`
- Test: `tests/unit/test_bootstrap_storage.py`

- [ ] **Step 1: Write the failing storage tests**

```python
import json
from pathlib import Path

from ralphception.bootstrap.storage import (
    ensure_bootstrap_dirs,
    seed_bootstrap_state,
    sync_gap_ledger_to_findings,
)


def test_seed_bootstrap_state_writes_manifest_gap_ledger_and_finish_criteria(tmp_path: Path) -> None:
    repo_root = tmp_path
    state = seed_bootstrap_state(repo_root)
    boot = repo_root / ".ralphception" / "bootstrapping"
    assert (boot / "inputs.json").exists()
    assert (boot / "gaps.json").exists()
    assert (boot / "gaps.md").exists()
    assert (boot / "finish-criteria.md").exists()
    assert state.inputs.authoritative_spec_paths == [
        "docs/superpowers/specs/2026-03-15-ralphception-design.md",
        "docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md",
    ]
    assert state.inputs.authoritative_plan_path == "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
    assert state.inputs.authoritative_readme_paths == ["README.md"]
    assert state.inputs.notes == []
    assert state.gaps.findings[0].gap_id == "bootstrap-cli-resume"
    assert state.gaps.authoritative_plan_path == "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
    assert state.gaps.updated_at is not None
    assert state.required_verification_commands == [
        "uv run pytest tests/unit tests/integration tests/e2e -q",
        "uv run ty check src tests",
    ]
    finish_criteria = (boot / "finish-criteria.md").read_text(encoding="utf-8")
    assert "docs/superpowers/specs/2026-03-15-ralphception-design.md" in finish_criteria
    assert "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md" in finish_criteria
    assert "uv run pytest tests/unit tests/integration tests/e2e -q" in finish_criteria
    assert "there are no open P0, P1, or P2 gaps" in finish_criteria


def test_sync_gap_ledger_to_findings_persists_canonical_audit_findings(tmp_path: Path) -> None:
    state = seed_bootstrap_state(tmp_path)
    sync_gap_ledger_to_findings(tmp_path, state.gaps, stage_id="stage-audit")
    stored = json.loads(
        (tmp_path / ".ralphception" / "findings" / "bootstrap-cli-resume.json").read_text(encoding="utf-8")
    )
    assert stored["severity"] == "P1"
    assert stored["kind"] == "feature_gap"
    assert stored["status"] == "open"


def test_ensure_bootstrap_dirs_does_not_modify_runtime_bootstrap_contract(tmp_path: Path) -> None:
    boot_dir = ensure_bootstrap_dirs(tmp_path)
    assert boot_dir == tmp_path / ".ralphception" / "bootstrapping"
    assert (tmp_path / ".ralphception" / "events").exists()
    assert (tmp_path / ".ralphception" / "bootstrapping" / "iterations").exists()
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/unit/test_bootstrap_storage.py -v`
Expected: FAIL because bootstrap storage helpers do not exist.

- [ ] **Step 3: Implement helper-only storage and findings sync**

Reuse:
- `src/ralphception/storage/bootstrap.py` for the base `.ralphception/` tree
- `src/ralphception/storage/files.py` for atomic JSON/Markdown writes
- `src/ralphception/audit/service.py` for canonical finding persistence

Include:
- helper-only `bootstrapping/` directory creation without changing `bootstrap_workspace()` defaults
- initial `inputs.json`, `gaps.json`, `gaps.md`, and `finish-criteria.md` seeding
- deterministic initial findings from the approved spec
- exact seeding of the two authoritative specs, the core runtime plan, `README.md`, and the default code/test globs before the first Codex iteration
- exact seeding of `inputs.json.notes = []` on first run so later backlog/exclusion headings are explicit instead of implicit
- populated `updated_at` timestamps and `authoritative_plan_path` on seeded manifest and ledger objects
- `finish-criteria.md` content that repeats authoritative spec/plan paths, lists accepted and `wontfix` items, includes the required verification commands, and states the stop rule in plain language
- `BootstrapState.required_verification_commands` derived from the seeded finish-criteria contract so prompt rendering and iteration summaries use one deterministic source
- sync from bootstrap findings into `.ralphception/findings/*.json`

```python
def ensure_bootstrap_dirs(repo_root: Path) -> Path:
    repo_root = bootstrap_workspace(repo_root)
    boot_dir = repo_root / ".ralphception" / "bootstrapping"
    ensure_directory_tree_durable(boot_dir / "iterations")
    return boot_dir


def sync_gap_ledger_to_findings(repo_root: Path, ledger: BootstrapGapLedger, *, stage_id: str) -> None:
    audit = AuditService(repo_root)
    for finding in ledger.findings:
        audit.persist_finding(
            finding.to_audit_finding(run_id="run-root"),
            stage_id=stage_id,
            source="bootstrap.storage",
        )
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/unit/test_bootstrap_storage.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/bootstrap/storage.py tests/unit/test_bootstrap_storage.py
git commit -m "feat: add bootstrap ledger storage and sync"
```

## Chunk 2: Prompt Rendering And Iteration Orchestration

### Task 3: Implement the bootstrap prompt template and renderer

**Files:**
- Create: `src/ralphception/bundled_skills/bootstrap.loop.md`
- Create: `src/ralphception/bootstrap/prompting.py`
- Test: `tests/unit/test_bootstrap_prompting.py`

- [ ] **Step 1: Write the failing prompt-rendering tests**

```python
from datetime import datetime, timezone
from pathlib import Path

from ralphception.bootstrap.contracts import BootstrapApprovalRequest
from ralphception.bootstrap.storage import seed_bootstrap_state
from ralphception.bootstrap.prompting import render_iteration_prompt


def test_render_iteration_prompt_includes_authoritative_inputs(tmp_path: Path) -> None:
    state = seed_bootstrap_state(tmp_path)
    prompt = render_iteration_prompt(tmp_path, state)
    assert "docs/superpowers/specs/2026-03-15-ralphception-design.md" in prompt
    assert "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md" in prompt
    assert "bootstrap-cli-resume" in prompt
    assert "gaps.json" in prompt
    assert "gaps.md" in prompt
    assert "classify every newly discovered gap" in prompt.lower()
    assert "stop for approval when a material spec or plan change is proposed" in prompt.lower()
    assert "uv run pytest tests/unit tests/integration tests/e2e -q" in prompt


def test_render_iteration_prompt_mentions_pending_approval_request(tmp_path: Path) -> None:
    state = seed_bootstrap_state(tmp_path)
    state.approval_request = BootstrapApprovalRequest(
        approval_kind="spec_review",
        run_id="run-root",
        artifact_paths=["docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md"],
        bundle_id=None,
        bundle_version=1,
        scope_hash="sha256:test",
        waived_finding_ids=None,
        rationale=None,
        requested_at=datetime(2026, 3, 17, tzinfo=timezone.utc),
    )
    prompt = render_iteration_prompt(tmp_path, state)
    assert "approval-request.json" in prompt
    assert "stop for human review" in prompt.lower()
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/unit/test_bootstrap_prompting.py -v`
Expected: FAIL because the prompt template and renderer do not exist.

- [ ] **Step 3: Implement the bundled prompt template and renderer**

Include:
- a tracked markdown template in `src/ralphception/bundled_skills/bootstrap.loop.md`
- rendering of authoritative spec/plan/README paths, latest summary path, `gaps.json`, `gaps.md`, verification commands, and approval-request state
- the template must embed the approved loop instructions: read authoritative inputs first, classify gaps, update `gaps.json`/`gaps.md`, guard `finish-criteria.md`, write an iteration summary, halt for material spec/plan changes, and never claim completion without running verification
- no shell logic inside the template; keep it focused on the iteration contract

```python
def render_iteration_prompt(repo_root: Path, state: BootstrapState) -> str:
    template = (
        importlib.resources.files("ralphception.bundled_skills") / "bootstrap.loop.md"
    ).read_text(encoding="utf-8")
    return template.format(
        repo_root=repo_root,
        spec_paths="\n".join(state.inputs.authoritative_spec_paths),
        plan_path=state.inputs.authoritative_plan_path,
        readme_paths="\n".join(state.inputs.authoritative_readme_paths),
        code_globs="\n".join(state.inputs.authoritative_code_globs),
        test_globs="\n".join(state.inputs.authoritative_test_globs),
        latest_summary=state.inputs.latest_iteration_summary_path or "(none yet)",
        gaps_json_text=state.gaps.model_dump_json(indent=2),
        gaps_md_text=state.gaps_markdown,
        verification_commands="\n".join(state.required_verification_commands),
        approval_request_path=state.approval_request_path if state.approval_request else "(none)",
    )
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/unit/test_bootstrap_prompting.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/bundled_skills/bootstrap.loop.md src/ralphception/bootstrap/prompting.py tests/unit/test_bootstrap_prompting.py
git commit -m "feat: add bootstrap loop prompt rendering"
```

### Task 4: Implement one-iteration bootstrap runner and Codex command preparation

**Files:**
- Create: `src/ralphception/bootstrap/runner.py`
- Test: `tests/integration/test_bootstrap_runner.py`

- [ ] **Step 1: Write the failing runner integration tests**

```python
from pathlib import Path

from ralphception.bootstrap.runner import prepare_bootstrap_iteration


def test_prepare_bootstrap_iteration_seeds_state_and_writes_prompt(tmp_path: Path) -> None:
    result = prepare_bootstrap_iteration(tmp_path)
    assert result.should_run_codex is True
    assert result.command[:2] == ["codex", "exec"]
    assert (tmp_path / ".ralphception" / "bootstrapping" / "prompt.txt").exists()


def test_prepare_bootstrap_iteration_stops_when_approval_request_is_pending(tmp_path: Path) -> None:
    result = prepare_bootstrap_iteration(tmp_path)
    (tmp_path / ".ralphception" / "bootstrapping" / "approval-request.json").write_text(
        '{"approval_kind":"spec_review","run_id":"run-root","artifact_paths":[],"bundle_id":null,"bundle_version":1,"scope_hash":"sha256:test","waived_finding_ids":null,"rationale":null,"requested_at":"2026-03-17T00:00:00Z"}',
        encoding="utf-8",
    )
    blocked = prepare_bootstrap_iteration(tmp_path)
    assert blocked.should_run_codex is False
    assert blocked.reason == "awaiting_review"


def test_record_iteration_updates_latest_summary_pointer(tmp_path: Path) -> None:
    first = prepare_bootstrap_iteration(tmp_path)
    summary = first.record_iteration_summary("Closed one gap.", verification_lines=["uv run pytest ... PASS"])
    reread = prepare_bootstrap_iteration(tmp_path)
    assert reread.inputs.latest_iteration_summary_path == str(summary.relative_to(tmp_path))
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/integration/test_bootstrap_runner.py -v`
Expected: FAIL because the runner does not exist.

- [ ] **Step 3: Implement the runner and command builder**

Include:
- seed state on first run
- short-circuit before Codex when `approval-request.json` exists
- prompt writing to `.ralphception/bootstrapping/prompt.txt`
- deterministic `codex exec` command building from `RalphceptionConfig.codex` with `--cd`, `--dangerously-bypass-approvals-and-sandbox`, model, reasoning config, and stdin prompt
- load repo config with `load_config(config_path(repo_root))` and fall back to `DEFAULT_CONFIG` the same way the main runtime does
- latest iteration summary pointer updates

```python
def build_codex_exec_command(repo_root: Path, *, codex_config: CodexConfig) -> list[str]:
    return [
        "codex",
        "exec",
        "--cd",
        str(repo_root),
        "--dangerously-bypass-approvals-and-sandbox",
        "--model",
        codex_config.model,
        "-c",
        f'model_reasoning_effort="{codex_config.reasoning}"',
        "-c",
        'model_verbosity="low"',
        "-",
    ]
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/integration/test_bootstrap_runner.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/bootstrap/runner.py tests/integration/test_bootstrap_runner.py
git commit -m "feat: add bootstrap iteration runner"
```

## Chunk 3: Local Helper Installation And Operator Docs

### Task 5: Install the local-only `ralph.sh` helper and document the flow

**Files:**
- Create: `src/ralphception/bootstrap/script.py`
- Modify: `README.md`
- Test: `tests/unit/test_bootstrap_script.py`
- Local-only: `.git/info/exclude`
- Local-only: `ralph.sh`

- [ ] **Step 1: Write the failing script-installation tests**

```python
from pathlib import Path

from ralphception.bootstrap.script import install_local_bootstrap_script


def test_install_local_bootstrap_script_writes_ralph_sh_and_updates_info_exclude(tmp_path: Path) -> None:
    (tmp_path / ".git" / "info").mkdir(parents=True)
    install_local_bootstrap_script(tmp_path)
    script_path = tmp_path / "ralph.sh"
    assert script_path.exists()
    assert script_path.read_text(encoding="utf-8").startswith("#!/usr/bin/env bash")
    assert "/ralph.sh" in (tmp_path / ".git" / "info" / "exclude").read_text(encoding="utf-8")
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/unit/test_bootstrap_script.py -v`
Expected: FAIL because the script installer does not exist.

- [ ] **Step 3: Implement the installer and update operator docs**

Include:
- `install_local_bootstrap_script(repo_root)` that writes an untracked `ralph.sh`
- append `/ralph.sh` to `.git/info/exclude` if missing
- `ralph.sh` should call `uv run python -m ralphception.bootstrap.runner` to prepare the prompt/command and then execute the prepared `codex exec` command in a fresh loop
- update `README.md` with a short helper-only section for `.ralphception/bootstrapping/` and the manual “ask the user to run `./ralph.sh`” handoff

```bash
#!/usr/bin/env bash
set -euo pipefail

uv run python -m ralphception.bootstrap.runner --install-or-run "$@"
```

- [ ] **Step 4: Run focused and full verification**

Run: `uv run pytest tests/unit/test_bootstrap_script.py tests/unit/test_bootstrap_contracts.py tests/unit/test_bootstrap_storage.py tests/unit/test_bootstrap_prompting.py tests/integration/test_bootstrap_runner.py -v`
Expected: PASS

Run: `uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

Run: `uv run ty check src tests`
Expected: SUCCESS with no reported type errors

- [ ] **Step 5: Commit tracked changes and keep `ralph.sh` untracked**

```bash
git add src/ralphception/bootstrap/script.py README.md tests/unit/test_bootstrap_script.py
git commit -m "feat: add local bootstrap helper installer"
```

Do not `git add ralph.sh`.
