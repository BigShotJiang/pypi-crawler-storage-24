# Ralphception Core Runtime Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the first working `ralphception` core runtime: a Codex-native Python orchestrator with tracked `.ralphception/` artifacts, recursive runs, approvals, worktrees, merge coordination, resume/recovery, verification/audit loops, and a mouse-enabled TUI.

**Architecture:** The implementation is split into small, testable subsystems: domain models and storage first, then the Codex adapter and workflow engine, then execution isolation and recovery, and finally the TUI and end-to-end fixtures. The first implementation plan covers only the core runtime; packaging/release automation stays as follow-on delivery work.

**Tech Stack:** Python 3.12+, `uv`, `ty`, `pytest`, `textual`, `pydantic`, `tomllib`, `codex_app_server` Python SDK, `git worktree`, `mise`

---

## Scope

This plan covers the core runtime only. It intentionally excludes the appendix delivery work from the design spec:

- PyPI trusted-publisher workflow
- final `uvx` packaging polish
- pre-commit and developer-task automation polish

Those are follow-on items after the runtime is working end-to-end.

## File Structure

Planned package layout:

- `pyproject.toml`
  Project metadata, dependencies, console entry point, tool configuration.
- `.mise.toml`
  Developer task runner for install, test, typecheck, lint, and TUI run commands.
- `src/ralphception/__init__.py`
  Package version marker.
- `src/ralphception/cli.py`
  Typer entry point for `ralphception`, `resume`, and supporting commands.
- `src/ralphception/app.py`
  High-level app bootstrap that wires config, workspace detection, storage, and TUI startup.
- `src/ralphception/config.py`
  Config loading, validation, defaults, atomic writes, timeout settings.
- `src/ralphception/paths.py`
  Canonical repo-root, XDG, and `.ralphception/` path resolution.
- `src/ralphception/models/artifacts.py`
  `ArtifactRef`, `TodoArtifact`, citation shapes.
- `src/ralphception/models/runtime.py`
  `Run`, `Stage`, `Task`, `ExecutionBundle`, `ApprovalRecord`, `Checkpoint`, `ChildAssignment`.
- `src/ralphception/models/session.py`
  `ChildSessionRef`, `AgentRef`, session-failure enums.
- `src/ralphception/models/worktree.py`
  `WorktreeHandoff`, merge-readiness values, cleanup state.
- `src/ralphception/models/events.py`
  Event envelope, event kinds, event payload helpers.
- `src/ralphception/models/verification.py`
  `VerificationSpec`, `VerificationResult`, audit finding types.
- `src/ralphception/storage/bootstrap.py`
  First-run `.ralphception/` creation and path bootstrap.
- `src/ralphception/storage/files.py`
  Atomic file IO helpers and JSON/Markdown persistence primitives.
- `src/ralphception/storage/events.py`
  Event log writer, reader, replay support, dedupe.
- `src/ralphception/storage/checkpoints.py`
  Durable checkpoint persistence and load logic.
- `src/ralphception/storage/artifacts.py`
  Shared artifact promotion rules and canonical writes.
- `src/ralphception/storage/lease.py`
  Single-writer workspace lease logic in XDG state.
- `src/ralphception/codex/client.py`
  Thin wrapper around the Codex Python SDK/app-server startup.
- `src/ralphception/codex/session_manager.py`
  Session manager contract implementation and raw-event normalization.
- `src/ralphception/skills/registry.py`
  Bundled-skill lookup and repo-local override resolution.
- `src/ralphception/skills/contracts.py`
  Skill invocation/result schemas and validation.
- `src/ralphception/workflow/engine.py`
  Run graph orchestration, scheduling, approvals, and stage transitions.
- `src/ralphception/workflow/approvals.py`
  Spec review, execution bundle, and finding-waiver approval handling.
- `src/ralphception/workflow/bundles.py`
  Execution bundle creation, state transitions, scope-hash logic.
- `src/ralphception/workflow/recovery.py`
  Resume, retry, restart, replace, and stale-lease reconciliation.
- `src/ralphception/git/worktrees.py`
  Worktree coordinator implementation.
- `src/ralphception/git/merge.py`
  Merge coordinator implementation and stale-bundle evaluation.
- `src/ralphception/verification/service.py`
  Verification task construction, execution, and result persistence.
- `src/ralphception/audit/service.py`
  Audit finding creation, update, reopen, and waiver preparation.
- `src/ralphception/ui/app.py`
  Textual app shell and global state wiring.
- `src/ralphception/ui/screens/*.py`
  Startup, main dashboard, artifact review, blocked/recovery interactions.
- `src/ralphception/ui/widgets/*.py`
  Workflow tree, detail pane, event feed, command bar.
- `src/ralphception/testing/fakes.py`
  Fake Codex/session/worktree services for integration tests.
- `tests/unit/...`
  Unit tests split by responsibility: config, artifact/runtime/session/worktree models, storage, bundle logic, approvals, verification.
- `tests/integration/...`
  Integration tests for workflow, session manager, worktrees, merge, resume.
- `tests/e2e/fixtures/...`
  Fixture repos for generic and porting flows.

## Chunk 1: Package, Config, Storage, And Domain Models

### Task 1: Create the Python project scaffold

**Files:**
- Create: `pyproject.toml`
- Create: `.mise.toml`
- Create: `src/ralphception/__init__.py`
- Create: `src/ralphception/cli.py`
- Create: `src/ralphception/app.py`
- Test: `tests/unit/test_cli_bootstrap.py`

- [x] **Step 1: Write the failing CLI bootstrap test**

```python
from typer.testing import CliRunner

from ralphception.cli import app


def test_cli_help_exposes_primary_commands() -> None:
    result = CliRunner().invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "resume" in result.stdout
```

- [x] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py -v`
Expected: FAIL because the package and CLI do not exist yet.

- [x] **Step 3: Create the minimal project files**

Use:
- `pyproject.toml` with `ralphception = "ralphception.cli:app"`
- `.mise.toml` tasks for `install`, `test`, `typecheck`, `run`
- Typer-based `src/ralphception/cli.py`
- `src/ralphception/app.py` with a placeholder `run_app()`

- [x] **Step 4: Run the test to verify it passes**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add pyproject.toml .mise.toml src/ralphception/__init__.py src/ralphception/cli.py src/ralphception/app.py tests/unit/test_cli_bootstrap.py
git commit -m "feat: scaffold ralphception python cli"
```

### Task 2: Implement config defaults and atomic config writes

**Files:**
- Create: `src/ralphception/config.py`
- Create: `src/ralphception/paths.py`
- Test: `tests/unit/test_config.py`

- [x] **Step 1: Write failing config tests**

```python
def test_default_config_contains_required_sections(tmp_path) -> None:
    config = write_default_config(tmp_path)
    assert config.codex.model == "gpt-5.4"
    assert config.verification.command_timeout_seconds == 1800
    assert config.ui.mouse is True


def test_write_config_is_atomic(tmp_path) -> None:
    config_path = tmp_path / ".ralphception" / "config.toml"
    write_config_atomically(config_path, DEFAULT_CONFIG)
    assert config_path.exists()
    assert ".tmp" not in "".join(p.name for p in config_path.parent.iterdir())


def test_invalid_config_is_preserved_and_reported(tmp_path) -> None:
    config_path = tmp_path / ".ralphception" / "config.toml"
    config_path.parent.mkdir(parents=True)
    config_path.write_text("[codex\nmodel='broken'\n", encoding="utf-8")
    result = load_config(config_path)
    assert result.is_error is True
    assert config_path.exists()
```

- [x] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/unit/test_config.py -v`
Expected: FAIL because config and path helpers do not exist.

- [x] **Step 3: Implement config and path modules**

Include:
- repo-root detection from git top level
- canonical XDG workspace-hash path resolution from the repo root
- `.ralphception/config.toml` default generation
- full `[codex]`, `[execution]`, `[verification]`, and `[ui]` defaults
- `verification.command_timeout_seconds`
- atomic temp-file-then-rename writes
- typed config validation
- broken-config preservation plus diagnostic result object

- [x] **Step 4: Run the config tests**

Run: `uv run pytest tests/unit/test_config.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/config.py src/ralphception/paths.py tests/unit/test_config.py
git commit -m "feat: add config and workspace path handling"
```

### Task 3: Implement durable model types

**Files:**
- Create: `src/ralphception/models/artifacts.py`
- Create: `src/ralphception/models/runtime.py`
- Create: `src/ralphception/models/session.py`
- Create: `src/ralphception/models/worktree.py`
- Create: `src/ralphception/models/events.py`
- Create: `src/ralphception/models/verification.py`
- Test: `tests/unit/test_runtime_models.py`
- Test: `tests/unit/test_session_models.py`
- Test: `tests/unit/test_worktree_models.py`
- Test: `tests/unit/test_verification_models.py`

- [x] **Step 1: Write failing model validation tests**

```python
def test_execution_bundle_rejects_unknown_state() -> None:
    with pytest.raises(ValidationError):
        ExecutionBundle(bundle_id="b1", run_id="r1", bundle_version=1, state="bad")


def test_finding_waiver_requires_rationale() -> None:
    with pytest.raises(ValidationError):
        ApprovalRecord(
            approval_id="a1",
            run_id="r1",
            approval_kind="finding_waiver",
            waived_finding_ids=["f1"],
            rationale=None,
        )


def test_verification_result_requires_command_result_fields() -> None:
    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="v1",
            run_id="r1",
            task_id="t1",
            status="passed",
            command_results=[{"command": "pytest"}],
        )
```

- [x] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/unit/test_runtime_models.py tests/unit/test_session_models.py tests/unit/test_worktree_models.py tests/unit/test_verification_models.py -v`
Expected: FAIL because the model modules do not exist.

- [x] **Step 3: Implement typed models**

Use Pydantic models for:
- artifact references and TODO artifacts
- runtime objects and checkpoints
- child-session and agent contracts
- worktree handoff contracts
- event envelope and required event kinds
- verification specs/results and audit findings
- shared enums, nullability rules, and replacement lineage

- [x] **Step 4: Run the model tests**

Run: `uv run pytest tests/unit/test_runtime_models.py tests/unit/test_session_models.py tests/unit/test_worktree_models.py tests/unit/test_verification_models.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/models/artifacts.py src/ralphception/models/runtime.py src/ralphception/models/session.py src/ralphception/models/worktree.py src/ralphception/models/events.py src/ralphception/models/verification.py tests/unit/test_runtime_models.py tests/unit/test_session_models.py tests/unit/test_worktree_models.py tests/unit/test_verification_models.py
git commit -m "feat: add core durable models"
```

### Task 4: Implement storage bootstrap, atomic persistence, events, and checkpoints

**Files:**
- Create: `src/ralphception/storage/bootstrap.py`
- Create: `src/ralphception/storage/files.py`
- Create: `src/ralphception/storage/events.py`
- Create: `src/ralphception/storage/checkpoints.py`
- Test: `tests/unit/test_storage_bootstrap.py`
- Test: `tests/unit/test_event_store.py`

- [x] **Step 1: Write failing storage tests**

```python
def test_bootstrap_creates_required_ralphception_directories(tmp_path) -> None:
    root = bootstrap_workspace(tmp_path)
    assert (root / ".ralphception" / "events").exists()
    assert (root / ".ralphception" / "verification").exists()


def test_event_store_deduplicates_event_ids(tmp_path) -> None:
    store = EventStore(tmp_path)
    store.append(event_id="e1", run_id="r1", sequence=1, event_type="run.started")
    store.append(event_id="e1", run_id="r1", sequence=1, event_type="run.started")
    assert store.read_run("r1") == [store.read_run("r1")[0]]


def test_checkpoint_persists_recovery_state(tmp_path) -> None:
    checkpoint = write_checkpoint(
        tmp_path,
        run_id="r1",
        authoritative_root="/repo",
        bundle_version=3,
        active_worktrees=["/repo/.wt/a"],
    )
    assert checkpoint.bundle_version == 3
    assert checkpoint.authoritative_root == "/repo"
```

- [x] **Step 2: Run the storage tests**

Run: `uv run pytest tests/unit/test_storage_bootstrap.py tests/unit/test_event_store.py -v`
Expected: FAIL because storage modules do not exist.

- [x] **Step 3: Implement storage primitives**

Include:
- `.ralphception/` bootstrap
- per-run append-only JSONL event logs
- canonical sequence allocation, dedupe, and replay helpers
- checkpoint writes at explicit safe points
- checkpoint persistence of event offsets, latest bundle version, active worktrees, and authoritative root
- JSON/Markdown atomic write helpers

- [x] **Step 4: Run the storage tests**

Run: `uv run pytest tests/unit/test_storage_bootstrap.py tests/unit/test_event_store.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/storage/bootstrap.py src/ralphception/storage/files.py src/ralphception/storage/events.py src/ralphception/storage/checkpoints.py tests/unit/test_storage_bootstrap.py tests/unit/test_event_store.py
git commit -m "feat: add storage bootstrap events and checkpoints"
```

## Chunk 2: Session Manager, Skills, Bundles, And Workflow Engine

### Task 5: Implement the Codex app-server wrapper and session manager

**Files:**
- Create: `src/ralphception/codex/client.py`
- Create: `src/ralphception/codex/session_manager.py`
- Create: `src/ralphception/testing/fakes.py`
- Test: `tests/integration/test_session_manager.py`

- [x] **Step 1: Write failing session manager tests**

```python
def test_start_session_normalizes_run_started_event() -> None:
    manager = build_fake_session_manager()
    event = manager.start_session(run_id="run-1")
    assert event.event_type == "run.started"
    assert event.run_id == "run-1"


def test_spawn_agent_is_agent_only_and_child_runs_use_start_session() -> None:
    manager = build_fake_session_manager()
    agent_ref = manager.spawn_agent(task_id="task-1", goal="inspect tests")
    child_session = manager.start_session(run_id="run-child-1")
    assert agent_ref.parent_task_id == "task-1"
    assert child_session.run_id == "run-child-1"


def test_session_manager_maps_all_required_failures() -> None:
    manager = build_fake_session_manager()
    assert manager.normalize_error(FakeTransportError()) == "transport_error"
    assert manager.normalize_error(FakeProtocolError()) == "protocol_error"
    assert manager.normalize_error(FakeExpiredSession()) == "session_expired"
```

- [x] **Step 2: Run the tests to verify failure**

Run: `uv run pytest tests/integration/test_session_manager.py -v`
Expected: FAIL because the Codex adapter modules do not exist.

- [x] **Step 3: Implement the Codex wrapper**

Include:
- app-server startup and shutdown
- `stream_raw_events`
- raw-event normalization
- `start_session`, `resume_session`, `run_turn`, `spawn_agent`, `abort_session`
- normalization of `startup_failed`, `session_expired`, `transport_error`, `protocol_error`, and `model_unavailable`
- fake session objects for tests

- [x] **Step 4: Run the session manager tests**

Run: `uv run pytest tests/integration/test_session_manager.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/codex/client.py src/ralphception/codex/session_manager.py src/ralphception/testing/fakes.py tests/integration/test_session_manager.py
git commit -m "feat: add codex session manager"
```

### Task 6: Implement the skill registry and result contracts

**Files:**
- Create: `src/ralphception/skills/registry.py`
- Create: `src/ralphception/skills/contracts.py`
- Create: `src/ralphception/bundled_skills/brainstorm.default.md`
- Create: `src/ralphception/bundled_skills/spec.write.md`
- Create: `src/ralphception/bundled_skills/plan.write.md`
- Create: `src/ralphception/bundled_skills/execute.task.md`
- Create: `src/ralphception/bundled_skills/merge.coordinator.md`
- Create: `src/ralphception/bundled_skills/audit.review.md`
- Create: `src/ralphception/bundled_skills/run.summary.md`
- Test: `tests/unit/test_skill_registry.py`

- [x] **Step 1: Write failing skill tests**

```python
def test_registry_prefers_exact_repo_override(tmp_path) -> None:
    write_skill(tmp_path / ".ralphception/skills/spec.write.md", "# override")
    registry = SkillRegistry(tmp_path)
    assert registry.load("spec.write").source == "repo"


def test_invalid_override_falls_back_to_bundled_skill(tmp_path) -> None:
    write_skill(tmp_path / ".ralphception/skills/spec.write.md", "")
    registry = SkillRegistry(tmp_path)
    assert registry.load("spec.write").source == "bundled"


def test_skill_result_requires_artifact_update_schema() -> None:
    with pytest.raises(ValidationError):
        SkillResult(status="success", artifact_updates=[{"apply_mode": "replace"}])
```

- [x] **Step 2: Run the tests**

Run: `uv run pytest tests/unit/test_skill_registry.py -v`
Expected: FAIL because the skill modules do not exist.

- [x] **Step 3: Implement the registry and schema validation**

Include:
- stable skill ids
- bundled asset lookup
- `.ralphception/skills/<skill-id>.md` override resolution
- validated invocation input schema
- validated skill response schema with `status`, `artifact_updates`, `suggested_next`, `findings`, `markdown_body`, allowed `apply_mode`, and fallback warning handling

- [x] **Step 4: Run the tests**

Run: `uv run pytest tests/unit/test_skill_registry.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/skills/registry.py src/ralphception/skills/contracts.py src/ralphception/bundled_skills/*.md tests/unit/test_skill_registry.py
git commit -m "feat: add skill registry and response contracts"
```

### Task 7: Implement execution bundles, approvals, and scope-hash rules

**Files:**
- Create: `src/ralphception/workflow/bundles.py`
- Create: `src/ralphception/workflow/approvals.py`
- Test: `tests/unit/test_bundles.py`
- Test: `tests/unit/test_approvals.py`

- [x] **Step 1: Write failing bundle and approval tests**

```python
def test_scope_hash_ignores_todo_ordering() -> None:
    assert compute_scope_hash(todo_list_a) == compute_scope_hash(todo_list_b)


def test_spec_review_requires_spec_bundle_only() -> None:
    approval = create_spec_review(spec_artifacts=[spec_ref], plan_artifacts=[])
    assert approval.approval_kind == "spec_review"
    assert approval.artifact_bundle_refs == [spec_ref]


def test_finding_waiver_requires_ids_and_rationale() -> None:
    with pytest.raises(ValidationError):
        create_finding_waiver([])
```

- [x] **Step 2: Run the tests**

Run: `uv run pytest tests/unit/test_bundles.py tests/unit/test_approvals.py -v`
Expected: FAIL because bundle and approval logic does not exist.

- [x] **Step 3: Implement bundle and approval services**

Include:
- scope-hash normalization
- bundle state transitions
- `spec_review`, `execution_bundle`, and `finding_waiver`
- approval persistence into `.ralphception/approvals/`
- bundle storage under `.ralphception/runs/<run-id>/bundles/`
- approval snapshots under `.ralphception/approvals/<approval-id>/`
- `bundle.created`, `bundle.state_changed`, and `bundle.assigned` event emission

- [x] **Step 4: Run the tests**

Run: `uv run pytest tests/unit/test_bundles.py tests/unit/test_approvals.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/workflow/bundles.py src/ralphception/workflow/approvals.py tests/unit/test_bundles.py tests/unit/test_approvals.py
git commit -m "feat: add execution bundle and approval logic"
```

### Task 8: Implement the workflow engine and scheduler

**Files:**
- Create: `src/ralphception/workflow/engine.py`
- Test: `tests/integration/test_workflow_engine.py`

- [x] **Step 1: Write failing workflow tests**

```python
def test_engine_blocks_plan_execution_until_execution_bundle_approval() -> None:
    engine = build_engine_without_execution_approval()
    assert engine.can_enter_execute_stage() is False


def test_engine_records_replacement_lineage_on_replace() -> None:
    engine = build_engine()
    replacement = engine.replace_run("run-child-a")
    assert replacement.supersedes_run_id == "run-child-a"


def test_engine_uses_latest_consumable_bundle_for_new_children() -> None:
    engine = build_engine_with_bundle_versions([2, 3])
    child = engine.schedule_child_run(goal="implement parser")
    assert child.bundle_version == 3
```

- [x] **Step 2: Run the workflow tests**

Run: `uv run pytest tests/integration/test_workflow_engine.py -v`
Expected: FAIL because the engine module does not exist.

- [x] **Step 3: Implement the workflow engine**

Include:
- stage transitions
- child-run and agent scheduling
- `spec_review` before plan generation
- approval gates
- pre-approval out-of-bounds write detection
- out-of-scope transition to `awaiting_approval`
- checkpoint writes
- replacement lineage via `supersedes_run_id`

- [x] **Step 4: Run the workflow tests**

Run: `uv run pytest tests/integration/test_workflow_engine.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/workflow/engine.py tests/integration/test_workflow_engine.py
git commit -m "feat: add workflow engine and scheduling"
```

## Chunk 3: Worktrees, Merge, Verification, Audit, And Recovery

### Task 9: Implement the worktree coordinator

**Files:**
- Create: `src/ralphception/git/worktrees.py`
- Test: `tests/integration/test_worktree_coordinator.py`

- [x] **Step 1: Write failing worktree tests**

```python
def test_create_child_worktree_returns_branch_and_path(tmp_path): ...

def test_switch_authoritative_root_updates_lease(tmp_path): ...

def test_cleanup_worktree_retains_when_requested(tmp_path): ...
```

- [x] **Step 2: Run the worktree tests**

Run: `uv run pytest tests/integration/test_worktree_coordinator.py -v`
Expected: FAIL because the worktree coordinator does not exist.

- [x] **Step 3: Implement the coordinator**

Include:
- child and integration worktree creation
- run-to-worktree mapping
- authoritative-root switching
- cleanup and retention behavior

- [x] **Step 4: Run the tests**

Run: `uv run pytest tests/integration/test_worktree_coordinator.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/git/worktrees.py tests/integration/test_worktree_coordinator.py
git commit -m "feat: add worktree coordinator"
```

### Task 10: Implement the merge coordinator and stale-bundle handling

**Files:**
- Create: `src/ralphception/git/merge.py`
- Test: `tests/integration/test_merge_coordinator.py`

- [x] **Step 1: Write failing merge tests**

```python
def test_validate_handoff_marks_stale_when_bundle_is_outdated() -> None:
    result = validate_handoff(handoff_bundle_version=2, latest_bundle_version=3)
    assert result == "stale"


def test_merge_rejects_forbidden_shared_ralphception_paths() -> None:
    handoff = make_handoff(touched_paths=[".ralphception/specs/spec.md"])
    assert validate_handoff_paths(handoff) == "blocked"


def test_partial_merge_recovery_reconciles_branch_and_lease() -> None:
    outcome = reconcile_partial_merge(branch_moved=True, lease_updated=False)
    assert outcome.requires_lease_fix is True
```

- [x] **Step 2: Run the merge tests**

Run: `uv run pytest tests/integration/test_merge_coordinator.py -v`
Expected: FAIL because merge coordination does not exist.

- [x] **Step 3: Implement merge coordination**

Include:
- handoff validation
- stale-bundle policy
- artifact promotion
- `finalize_merge`
- conflict-resolution spawning
- partial-merge recovery rules
- durable merge-record outputs under `.ralphception/merge/`

- [x] **Step 4: Run the merge tests**

Run: `uv run pytest tests/integration/test_merge_coordinator.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/git/merge.py tests/integration/test_merge_coordinator.py
git commit -m "feat: add merge coordinator"
```

### Task 11: Implement verification and audit services

**Files:**
- Create: `src/ralphception/verification/service.py`
- Create: `src/ralphception/audit/service.py`
- Test: `tests/unit/test_verification_service.py`
- Test: `tests/unit/test_audit_service.py`

- [x] **Step 1: Write failing verification and audit tests**

```python
def test_verification_builds_task_scoped_spec_with_timeout() -> None:
    spec = build_verification_spec(scope="task", timeout_seconds=1800)
    assert spec.scope == "task"
    assert spec.required is True


def test_verification_result_records_command_details() -> None:
    result = record_verification_result(command="pytest", exit_code=0, cwd="/repo")
    assert result.command_results[0]["command"] == "pytest"
    assert result.command_results[0]["cwd"] == "/repo"


def test_audit_finding_waiver_requires_human_approval() -> None:
    finding = create_finding(severity="P1")
    assert can_waive_finding(finding, actor="engine") is False
```

- [x] **Step 2: Run the tests**

Run: `uv run pytest tests/unit/test_verification_service.py tests/unit/test_audit_service.py -v`
Expected: FAIL because these services do not exist.

- [x] **Step 3: Implement verification and audit**

Include:
- verification spec creation from precedence rules
- execution context selection
- command result shaping
- mirroring `VerificationResult` records into the event stream
- audit finding persistence, reopen behavior, and waiver preparation

- [x] **Step 4: Run the tests**

Run: `uv run pytest tests/unit/test_verification_service.py tests/unit/test_audit_service.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/verification/service.py src/ralphception/audit/service.py tests/unit/test_verification_service.py tests/unit/test_audit_service.py
git commit -m "feat: add verification and audit services"
```

### Task 12: Implement lease handling and recovery flows

**Files:**
- Create: `src/ralphception/storage/lease.py`
- Create: `src/ralphception/workflow/recovery.py`
- Test: `tests/integration/test_recovery.py`

- [x] **Step 1: Write failing recovery tests**

```python
def test_resume_read_mode_does_not_take_lease() -> None:
    result = resume(mode="read")
    assert result.lease_taken is False


def test_resume_repair_mode_can_steal_stale_lease() -> None:
    result = resume(mode="repair", stale_lease=True)
    assert result.lease_taken is True


def test_replace_creates_new_run_with_supersedes_link() -> None:
    replacement = replace_run("run-old")
    assert replacement.supersedes_run_id == "run-old"
```

- [x] **Step 2: Run the recovery tests**

Run: `uv run pytest tests/integration/test_recovery.py -v`
Expected: FAIL because lease and recovery modules do not exist.

- [x] **Step 3: Implement lease and recovery logic**

Include:
- workspace lease acquisition and heartbeat
- healthy-lease refusal
- read vs repair resume modes
- retry, restart, and replace flows
- session-lost recovery and checkpoint reconciliation
- stale or missing XDG repair
- corrupt or partial event-log blocking

- [x] **Step 4: Run the tests**

Run: `uv run pytest tests/integration/test_recovery.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/storage/lease.py src/ralphception/workflow/recovery.py tests/integration/test_recovery.py
git commit -m "feat: add lease and recovery flows"
```

## Chunk 4: TUI, Bootstrap Flow, And End-to-End Fixtures

### Task 13: Implement the Textual application shell and widgets

**Files:**
- Create: `src/ralphception/ui/app.py`
- Create: `src/ralphception/ui/widgets/workflow_tree.py`
- Create: `src/ralphception/ui/widgets/detail_pane.py`
- Create: `src/ralphception/ui/widgets/event_feed.py`
- Create: `src/ralphception/ui/widgets/command_bar.py`
- Test: `tests/unit/test_ui_commands.py`

- [x] **Step 1: Write failing TUI command tests**

```python
def test_help_lists_core_commands() -> None:
    state = run_help_command()
    assert "/artifacts" in state.output
    assert "/replace" in state.output


def test_artifacts_command_selects_pending_bundle() -> None:
    state = run_artifacts_command(selected_run="run-root")
    assert state.selected_bundle_version == 3


def test_model_command_updates_config() -> None:
    state = run_model_command("gpt-5.4")
    assert state.config.codex.model == "gpt-5.4"
```

- [x] **Step 2: Run the tests**

Run: `uv run pytest tests/unit/test_ui_commands.py -v`
Expected: FAIL because the UI modules do not exist.

- [x] **Step 3: Implement the Textual shell**

Include:
- header, workflow tree, detail pane, event feed, and command bar
- `/model`, `/resume`, `/status`, `/artifacts`, `/approve`, `/retry`, `/restart`, `/replace`, `/abort`, `/help`
- blocked-node reasons and next actions
- selected-node actions in the detail pane
- event-log hydration on resume

- [x] **Step 4: Run the UI tests**

Run: `uv run pytest tests/unit/test_ui_commands.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/ui/app.py src/ralphception/ui/widgets/workflow_tree.py src/ralphception/ui/widgets/detail_pane.py src/ralphception/ui/widgets/event_feed.py src/ralphception/ui/widgets/command_bar.py tests/unit/test_ui_commands.py
git commit -m "feat: add textual dashboard and command handling"
```

### Task 14: Implement startup flow, first-run bootstrap, and artifact review screens

**Files:**
- Create: `src/ralphception/ui/screens/startup.py`
- Create: `src/ralphception/ui/screens/review.py`
- Modify: `src/ralphception/app.py`
- Test: `tests/integration/test_startup_flow.py`

- [x] **Step 1: Write failing startup tests**

```python
def test_first_run_captures_seed_prompt_and_source_repos() -> None:
    flow = start_first_run(seed_prompt="port parser", source_repos=["/src/repo"])
    assert flow.outer_run_id is not None
    assert flow.source_repos == ["/src/repo"]


def test_spec_review_requires_spec_review_approval() -> None:
    flow = build_review_flow()
    assert flow.can_enter_plan_generation is False


def test_review_screen_can_diff_pending_execution_bundle() -> None:
    screen = open_review_screen(bundle_version=3)
    assert "bundle diff" in screen.rendered_text
```

- [x] **Step 2: Run the startup tests**

Run: `uv run pytest tests/integration/test_startup_flow.py -v`
Expected: FAIL because startup and review screens do not exist.

- [x] **Step 3: Implement startup and review flow**

Include:
- first-run bootstrap
- source repo capture
- spec review gate
- execution bundle review and approval
- artifact diff flow for spec and execution bundle review
- blocked-state recovery interactions

- [x] **Step 4: Run the startup tests**

Run: `uv run pytest tests/integration/test_startup_flow.py -v`
Expected: PASS

- [x] **Step 5: Commit**

```bash
git add src/ralphception/ui/screens/startup.py src/ralphception/ui/screens/review.py src/ralphception/app.py tests/integration/test_startup_flow.py
git commit -m "feat: add startup and approval review flows"
```

### Task 15: Build fixture repos and end-to-end runtime tests

**Files:**
- Create: `tests/e2e/fixtures/generic_repo/pyproject.toml`
- Create: `tests/e2e/fixtures/generic_repo/src/app.py`
- Create: `tests/e2e/fixtures/source_repo/tests/test_port_me.py`
- Create: `tests/e2e/fixtures/source_repo/src/port_me.ts`
- Create: `tests/e2e/fixtures/target_repo/pyproject.toml`
- Create: `tests/e2e/fixtures/target_repo/src/__init__.py`
- Create: `tests/e2e/test_core_runtime.py`

- [x] **Step 1: Write failing end-to-end tests**

```python
def test_generic_seed_prompt_creates_ralphception_artifacts() -> None:
    result = run_fixture_flow("generic_repo")
    assert result.ralphception_dir.exists()


def test_porting_flow_treats_source_repo_as_read_only() -> None:
    result = run_fixture_flow("target_repo", source_repo="source_repo")
    assert result.source_repo_modified is False


def test_resume_rebuilds_state_from_events_and_checkpoint() -> None:
    result = resume_fixture_flow("target_repo")
    assert result.replayed_run_tree is True


def test_audit_loop_reopens_work_when_p1_gap_exists() -> None:
    result = run_fixture_flow("target_repo", inject_gap="P1")
    assert result.execution_reopened is True
```

- [x] **Step 2: Run the E2E tests**

Run: `uv run pytest tests/e2e/test_core_runtime.py -v`
Expected: FAIL because fixtures and the assembled runtime do not exist yet.

- [x] **Step 3: Implement the fixture repos and finish missing glue**

Include:
- tiny generic repo fixture
- tiny source and target repo fixtures
- fake or stub Codex execution where deterministic behavior is needed
- audit-loop reopening scenario

- [x] **Step 4: Run the E2E tests**

Run: `uv run pytest tests/e2e/test_core_runtime.py -v`
Expected: PASS

- [x] **Step 5: Run the core verification suite**

Run: `uv run pytest tests/unit tests/integration tests/e2e -v`
Expected: PASS

Run: `uv run ty check`
Expected: SUCCESS with no reported type errors

- [x] **Step 6: Commit**

```bash
git add tests/e2e/fixtures tests/e2e/test_core_runtime.py
git commit -m "feat: add end-to-end core runtime coverage"
```

### Task 16: Wire the top-level runtime into actual orchestration

**Files:**
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/ui/app.py`
- Modify: `README.md`
- Test: `tests/integration/test_startup_flow.py`
- Test: `tests/e2e/test_core_runtime.py`

- [x] **Step 1: Make the top-level runtime do more than open an idle dashboard**

Include:
- clarify and implement the intended behavior after startup, spec approval, and bundle approval so `uv run ralphception` can advance work instead of remaining permanently pending
- wire the dashboard launch path to a real orchestration or recovery entry point instead of leaving `/resume` unconfigured in dashboard mode
- add coverage that proves a bootstrapped workspace can progress into actual work from the supported top-level entrypoint

## Follow-On Delivery Backlog

Not part of this implementation plan:

- `.github/workflows/release.yml` trusted-publisher workflow
- `pre-commit` hook set
- final `uvx`/README polish
- optional untracked `ralph.sh` bootstrap helper for dogfooding the loop on `ralphception` itself
