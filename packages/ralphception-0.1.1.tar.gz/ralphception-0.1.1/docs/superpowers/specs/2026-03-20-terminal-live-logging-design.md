# Terminal Live Logging Design

## Goal

Make `uv run ralphception terminal --seed-prompt ...` continuously narrate mission progress in a readable way while the shared runtime is executing real work.

## Problem

The real Codex backend now starts correctly, but the terminal surface remains mostly silent after startup. The shared mission supervisor persists useful state and events under `.ralphception/`, yet the terminal frontend receives almost no `FrontendEvent`s beyond bootstrap/resume. The result is a process that looks hung even when a root run, stage transitions, and Codex sessions are progressing.

## Recommended Approach

Add high-level progress emission inside the shared mission supervisor in `headless.py`, rather than building a terminal-only polling loop.

This keeps one runtime and two frontends intact:

- the supervisor remains the source of truth for mission state
- the terminal frontend keeps acting as a simple log sink
- the TUI can reuse the same events later if desired

The default output should stay readable and mission-oriented, not raw-event-heavy.

## Event Model

Emit focused `FrontendEvent` messages for:

- stage transitions
- turn start and turn completion
- artifact generation milestones
- approval actions
- child run creation and worktree assignment
- verification start and result
- merge start and merge completion
- audit reopen decisions
- terminal completion/failure summaries

These messages should be emitted directly at the same points where the supervisor mutates durable state, so the logs reflect actual authoritative progress rather than inferred status.

## Non-Goals

- no raw Codex event spam by default
- no separate terminal orchestrator
- no polling-based log follower for the default path
- no redesign of the TUI surface in this change

## Logging Shape

Default messages should be short and stable. Examples:

- `Stage: spec`
- `Turn started: run-root spec attempt 1`
- `Turn completed: run-root spec`
- `Approved: spec_review`
- `Child run created: run-child-1`
- `Verification passed: run-child-1 execute`
- `Merged: run-child-1`
- `Audit reopened execution with run-child-1-replacement-1`
- `Mission completed: run-root`

The terminal frontend already prints any `FrontendEvent.message`, so the implementation should focus on emitting the right messages, not on changing terminal rendering semantics.

## Files

- `src/ralphception/headless.py`
  Add frontend-aware logging helpers and call them at stage and turn boundaries.
- `src/ralphception/runtime/terminal.py`
  Keep rendering simple; only adjust if tests show duplicated or missing status lines.
- `tests/integration/test_terminal_frontend.py`
  Add behavioral tests for readable live log output.
- `README.md`
  Document that terminal mode now streams high-level mission progress.

## Risks

The main risk is log duplication from mixing `emit_status()` and explicit `emit_event()` calls. The fix should keep `emit_status()` for coarse runtime mode changes and use explicit events for mission progress. Tests should assert for presence of meaningful progress lines without depending on every exact line.

## Success Criteria

- A real `uv run ralphception terminal --seed-prompt ...` run prints continuous high-level progress instead of appearing idle.
- The new logs come from the shared runtime, not terminal-specific polling.
- Existing fake-backend and TUI-adjacent behavior remains intact.
