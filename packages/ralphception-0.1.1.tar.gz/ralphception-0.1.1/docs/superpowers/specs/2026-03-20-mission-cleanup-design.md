# Mission Cleanup Design

Date: 2026-03-20
Status: Approved for implementation

## Summary

Ralphception should treat a completed root mission as fully finished. Terminal and TUI launches should not encounter a leftover resumable mission after success or terminal failure. On terminal completion, the shared runtime should restore the primary checkout as the authoritative root, remove managed child and integration worktrees, and delete the repo-local `.ralphception/` runtime state. Only genuinely in-progress missions should trigger a conflict prompt when a different `--seed-prompt` is supplied.

## Problem

The shared runtime currently marks the root run `completed` but leaves mission state behind:

- `.ralphception/` remains populated
- the authoritative root can still point at the integration worktree
- the next launch still sees an old root mission and treats the workspace as resumable

That makes the next `uv run ralphception terminal --seed-prompt ...` fail or behave unexpectedly, even though the prior mission already finished. The prompt-conflict error is exposing stale completion residue rather than a healthy runtime boundary.

## Goals

- Remove completed root mission state automatically from the shared runtime.
- Restore a fresh launch state after mission completion.
- Keep conflict handling only for in-progress missions.
- Make terminal mode prompt the user before replacing a genuinely active mission.
- Keep the behavior shared across terminal and TUI by implementing it below the frontend layer.

## Non-Goals

- Preserving completed missions for later inspection.
- Adding archival/export flows for completed runtime state.
- Introducing a background daemon or external metadata store.

## Design

### Completion Cleanup

When the root mission reaches terminal success or terminal failure:

1. determine the primary checkout root for the workspace
2. move the authoritative root back to that primary checkout if the mission currently owns an integration worktree
3. clean all managed child and integration worktrees for the mission
4. delete repo-local `.ralphception/` runtime state
5. return a terminal result that points at the restored primary checkout

The cleanup should live in the shared mission runtime so both frontends observe the same semantics.

### Launch Semantics

When launching with a `--seed-prompt`:

- if no root mission exists, bootstrap a new mission
- if an in-progress root mission exists with the same prompt, resume it
- if an in-progress root mission exists with a different prompt, prompt for:
  - `resume`
  - `override`
  - `abort`
- if a completed root mission still exists, treat that as pending cleanup residue, clear it, and continue with the requested prompt

### Override Behavior

`override` should only apply to in-progress missions. It should:

- clean the existing Ralphception repo-local state
- clean managed worktrees owned by the prior root mission
- restore the primary checkout as authoritative
- start a fresh mission with the new prompt

This keeps the behavior explicit and safe while avoiding silent prompt replacement.

## Components

### `src/ralphception/headless.py`

- Add a post-terminal cleanup path for the root mission.
- Ensure the terminal result reports the restored primary checkout root.

### `src/ralphception/runtime/supervisor.py`

- Replace the unconditional prompt-conflict exception with state-aware conflict resolution.
- Distinguish active mission conflicts from completed-residue cleanup.

### `src/ralphception/runtime/terminal.py`

- Add an explicit blocking prompt for in-progress prompt conflicts.
- Keep the default non-conflict path fully automatic.

### `src/ralphception/git/worktrees.py`

- Reuse or extend existing authoritative-root switching and managed worktree cleanup helpers.

## Testing

- terminal integration test that a completed mission run leaves the workspace fresh for a new prompt
- terminal integration test that an in-progress conflicting prompt blocks for `resume` / `override`
- end-to-end fake-session mission test that completion removes `.ralphception/` and reports the primary checkout

## Risks

- cleanup must not delete unmanaged files or non-Ralphception worktrees
- authoritative root restoration must happen before cleaning the integration worktree
- deleting `.ralphception/` must not race with terminal result rendering
