# Ralphception Bootstrap Loop Design

Date: 2026-03-17
Status: Draft for review

## Summary

`ralphception` should have a repo-local bootstrap finisher for implementing `ralphception` itself. The bootstrap entry point is an untracked `ralph.sh` script at the repo root that repeatedly launches fresh Codex sessions against the repository's durable state until the documented runtime is either implemented or explicitly re-scoped.

The script is not the orchestrator. It is a loop driver. The durable system of record remains the repository: specs, plans, tests, implementation, and a bootstrapping ledger under `.ralphception/bootstrapping/`.

This is follow-on developer tooling for dogfooding and finishing `ralphception` itself. It is not retroactively part of the 2026-03-15 core runtime deliverable, which intentionally deferred an optional `ralph.sh` helper to later work.

This spec defines that later work. It should be implemented from its own follow-on bootstrap plan after approval, rather than by silently treating the original core-runtime plan as amended in place.

## Problem Statement

The core runtime exists and is tested, but the repository is still short of the full product shape described in the main design and runtime plan. The most important gaps today are:

- the top-level `ralphception resume` CLI command is still a stub
- the startup and review screens are controller-backed but remain minimal compared to the promised interactive operator flow
- the runtime plan lists `src/ralphception/storage/artifacts.py`, but that module does not exist
- the repository needs a disciplined way to reconcile code, tests, plans, and specs without trusting any single long-lived Codex session

The bootstrap loop exists to close those gaps by repeatedly reconciling the written docs with the implementation and by updating the docs when the loop learns something real.

## Goals

- Provide a fresh-context completion loop for `ralphception` itself.
- Reconcile `spec -> plan -> code -> tests -> docs` on every iteration.
- Allow the loop to either implement missing behavior or update specs and plans when the current docs are ahead of the intended scope.
- Produce a durable gap ledger that survives session restarts.
- Stop only when no open `P0`, `P1`, or `P2` gaps remain and no in-scope plan items are left unchecked.
- Keep the bootstrap mechanism local and disposable: `ralph.sh` stays untracked unless there is a later decision to productize it.

## Non-Goals

- Turning `ralph.sh` into the long-term user-facing orchestration product.
- Replacing the existing Python runtime with a shell script.
- Freezing the current docs as immutable truth.
- Solving every future backlog item in the first bootstrap cycle.

## Operating Model

The bootstrap loop follows the Ralph pattern: fresh sessions, file-based handoff, and repeated verification.

```mermaid
flowchart TD
    A["ralph.sh"] --> B["Fresh Codex iteration"]
    B --> C["Read spec, plan, code, tests, and prior gap ledger"]
    C --> D["Write updated gap ledger"]
    D --> E{"Best next move?"}
    E --> F["Implement missing code or tests"]
    E --> G["Update spec or plan"]
    E --> H["Move item to explicit backlog with rationale"]
    F --> I["Run verification"]
    G --> I
    H --> I
    I --> J["Audit remaining gaps"]
    J --> K{"Any open P0/P1/P2 or unchecked in-scope plan items?"}
    K -- yes --> B
    K -- no --> L["Exit success"]
```

The loop must prefer small converging steps over large rewrites. Each iteration should choose the highest-leverage unresolved slice and leave behind durable evidence of what changed and why.

## Durable Artifacts

The bootstrap loop should write to `.ralphception/bootstrapping/`:

- `gaps.md`
  Human-readable current gap ledger, grouped by severity and subsystem.
- `gaps.json`
  Machine-readable gap ledger for later iterations.
- `finish-criteria.md`
  The active completion contract for the loop.
- `inputs.json`
  Machine-readable authoritative input manifest for the current iteration set.
- `iterations/<timestamp>.md`
  One summary per iteration with what changed, what was verified, and what remains.
- `references.md`
  Optional notes on external Ralph-loop guidance and local implementation conventions.

These artifacts are bootstrap state, not end-user runtime state. They exist to let each fresh Codex iteration pick up where the prior one left off without inheriting its context window.

The `bootstrapping/` directory is helper-only:

- runtime resume, dashboard, approvals, and normal end-user flows may ignore it unless a later product decision promotes it into first-class runtime state
- it exists to help finish `ralphception` itself, not to change the current runtime storage contract for normal users

Ownership rules:

- `ralph.sh` and its Codex iterations are the only writers of `.ralphception/bootstrapping/`
- the main runtime remains authoritative for `.ralphception/runs/`, `.ralphception/events/`, `.ralphception/approvals/`, `.ralphception/verification/`, `.ralphception/findings/`, and related runtime state
- the bootstrap loop may read runtime artifacts, but it should not invent a competing runtime state model under `bootstrapping/`
- if the bootstrap loop learns that the README or runtime storage docs are stale, it should update those docs to mention `.ralphception/bootstrapping/` explicitly
- the canonical store for durable runtime findings remains `.ralphception/findings/`; `gaps.json` is the bootstrap loop's working ledger and must be synchronized into the canonical findings store before approvals or final finish checks

Minimum machine-readable contracts:

- `inputs.json`
  Contains `schema_version`, `updated_at`, `authoritative_spec_paths`, `authoritative_plan_path`, `authoritative_readme_paths`, `authoritative_code_globs`, `authoritative_test_globs`, `latest_iteration_summary_path`, and `notes`.
- `gaps.json`
  Contains `schema_version`, `updated_at`, `authoritative_plan_path`, and `findings`.
- each `findings` entry contains `gap_id`, `title`, `severity`, `bootstrap_kind`, `audit_kind`, `status`, `rationale`, `evidence_paths`, `plan_item_refs`, and `updated_at`
- valid `status` values are `open`, `accepted`, `resolved`, and `wontfix`
- valid `severity` values are `P0`, `P1`, `P2`, and `P3`

Schema version rules:

- both `inputs.json` and `gaps.json` start at `schema_version = 1`
- `schema_version` is local to the bootstrap ledger and does not replace the runtime event or model schema versions
- backward-compatible additions may keep the same version if older iterations can still parse the file safely
- incompatible field changes must bump the schema version and the iteration must either migrate the file in place or stop with a clear error
- `ralph.sh` must refuse to continue if it encounters an unsupported bootstrap schema version

`gaps.md` is the human rendering of `gaps.json` and should be regenerated from the same underlying findings data instead of drifting as a separate hand-maintained view.

Findings sync rule:

- after each successful iteration, the bootstrap loop must mirror every `gaps.json` finding into the canonical `.ralphception/findings/` representation before evaluating finish criteria or writing approval records
- if a finding exists in both places, the bootstrap loop updates the canonical finding to match the ledger
- if a canonical finding exists without a matching ledger entry, the next iteration must either import it into `gaps.json` or record why it is out of scope for bootstrap work

Status meaning must stay aligned with the runtime:

- `open`
  Work remains and still blocks finish criteria if severity is `P0`, `P1`, or `P2`.
- `accepted`
  The gap is acknowledged and intentionally left for later by an approved defer or waiver decision.
- `resolved`
  The gap is closed by implementation, verification, or doc correction.
- `wontfix`
  The gap is intentionally removed from active scope and should not reopen unless the authoritative docs change again.

## Approval Gate Preservation

The bootstrap loop must preserve the runtime's human approval model instead of bypassing it.

Rules:

- if an iteration proposes a material change to an authoritative spec or plan, the loop must write the proposed document changes, update the gap ledger, and stop in an awaiting-review state
- if an iteration proposes a material change to an authoritative spec or plan, the loop must also write any matching runtime approval inputs needed for the next run to persist a canonical `ApprovalRecord`
- material changes include scope changes, changed acceptance criteria, changed finish criteria, new accepted or `wontfix` items, or any rewrite that would alter what "done" means
- non-material sync changes, such as marking already-finished plan checkboxes complete or updating README truthfulness to match implemented behavior, may proceed in the same loop iteration
- after a material doc change is approved by the user, the next `ralph.sh` run must persist the matching canonical `ApprovalRecord` and any required bundle snapshot under `.ralphception/approvals/` before continuing

Approval integration rules:

- spec changes that alter authoritative scope or acceptance criteria require the same `spec_review` approval shape used by the runtime
- plan or execution changes that alter the executable slice must leave the relevant execution bundle in `awaiting_approval` until approval is recorded
- finding waivers or explicit future defers must map onto the runtime's `finding_waiver` approval path and leave the affected finding in `accepted` or `wontfix`, never silently dropped
- the bootstrap loop may reuse runtime approval helpers directly; if it does not, it must still produce equivalent on-disk approval artifacts and snapshots

Approval handshake:

- when the loop stops for approval, it must write `.ralphception/bootstrapping/approval-request.json`
- that file must contain `approval_kind`, `run_id`, `artifact_paths`, `bundle_id`, `bundle_version`, `scope_hash`, `waived_finding_ids`, `rationale`, and `requested_at`
- for `spec_review`, `artifact_paths` must point at the current authoritative spec artifacts and the next run must call the same `create_spec_review(...)` and `persist_approval(...)` flow used by the runtime, producing `.ralphception/approvals/<approval-id>.json` plus the snapshot directory
- for `execution_bundle`, the loop must leave the target bundle JSON in `awaiting_approval`, then after user approval call the runtime's execution-bundle approval flow so the canonical approval record and snapshots exist before work resumes
- for `finding_waiver`, the loop must write the approval request with `waived_finding_ids` and `rationale`, then after approval call the runtime's finding-waiver approval flow so the resulting record is durable under `.ralphception/approvals/`
- after the canonical approval record is written, the loop clears `approval-request.json`, updates `gaps.json`, and continues from the same authoritative inputs

Material-change checklist:

- changing any goal, non-goal, acceptance-criteria, or finish-criteria section in an authoritative spec or plan is material
- changing `inputs.json.authoritative_spec_paths`, `inputs.json.authoritative_plan_path`, or backlog-exclusion rules is material
- adding a new plan item, removing a plan item, or changing an open plan item into `accepted` or `wontfix` is material
- marking an already-completed plan checkbox as `- [x]` based on implemented work is not material by itself
- typo fixes, formatting-only edits, and README truthfulness updates that do not change scope are not material

## Gap Taxonomy And Decision Rules

Every discovered gap must be classified before action:

- `implementation_gap`
  The docs describe intended behavior that should exist in code now.
- `verification_gap`
  Code exists, but tests or type coverage are insufficient for confidence.
- `ux_gap`
  The runtime behavior exists internally, but the promised operator path is still thin or manual.
- `doc_gap`
  Code and behavior are real, but specs, plans, README, or status docs are stale.
- `scope_gap`
  The current spec or plan is ahead of the intended v1 and should be narrowed, deferred, or restated.

For deterministic storage, the bootstrap loop must map this taxonomy onto the existing runtime finding model:

- `implementation_gap` -> `AuditFinding.kind = "feature_gap"` or `"bug"`
- `verification_gap` -> `AuditFinding.kind = "test_gap"`
- `ux_gap` -> `AuditFinding.kind = "feature_gap"` unless it is actually wrong behavior, in which case `"bug"`
- `doc_gap` -> `AuditFinding.kind = "spec_drift"`
- `scope_gap` -> `AuditFinding.kind = "spec_drift"` plus an explicit rationale in `gaps.md` and any updated plan or spec

The bootstrap taxonomy is therefore a decision aid for the loop prompt, while the persisted severity model remains `P0` through `P3` and the persisted finding kinds stay aligned with the current `AuditFinding` contract.

Decision rules:

- If the gap is real and in-scope, implement it.
- If the docs are wrong or ahead of the intended slice, update the docs and record the rationale.
- If something is being moved to a later slice or removed from scope, write it down explicitly instead of silently dropping it.
- If a gap can be reduced first by tests or narrower acceptance criteria, do that before large implementation work.

## Plan Item Contract

The bootstrap loop needs a deterministic meaning for "remaining plan work." For this repository, the source of truth is:

- the latest active plan document under `docs/superpowers/plans/`
- its checkbox items using `- [ ]` and `- [x]`
- any explicit defer or supersession note written into the plan or the gap ledger

Rules:

- an item is `open` when its checkbox is `- [ ]` and it has not been explicitly accepted for later work, marked `wontfix`, or superseded
- an item is `closed` when its checkbox is `- [x]`
- an item is `accepted` when the plan or gap ledger records that it moved out of the active finish criteria for a future slice, with rationale
- an item is `wontfix` when the plan or gap ledger records that it left the intended scope entirely, with rationale
- "in-scope plan items" means all open items in the latest active bootstrap-relevant plan, excluding items explicitly marked accepted, `wontfix`, or superseded

If the original runtime plan becomes inaccurate, the loop may either update it directly or write a newer superseding plan. It must then record which plan file is authoritative in `finish-criteria.md`.

For deterministic plan discovery:

- `inputs.json.authoritative_plan_path` is the machine-readable source of truth
- `finish-criteria.md` must repeat that path in a human-readable form
- if a newer plan supersedes the older one, the loop must update both files in the same iteration
- defer or supersession notes are only considered valid if they appear in the authoritative plan file or in `gaps.json` with `status = "accepted"` or `status = "wontfix"` and a rationale
- sections under a markdown heading exactly named `Follow-On Delivery Backlog` are excluded from in-scope plan work unless a later authoritative plan explicitly promotes those items into a non-backlog section
- if a plan uses another exclusion heading in the future, the loop may only treat it as out of scope after that heading is named in `inputs.json.notes` and the change is reflected in an iteration summary

To create stable `plan_item_refs` from markdown checkboxes, the bootstrap loop must derive each reference as:

`<relative-plan-path>#<section-slug>/<sha1(normalized-checkbox-text)>`

Where:

- `relative-plan-path` is relative to the repo root
- `section-slug` is the nearest markdown heading above the checkbox, normalized by lowercasing the heading text, replacing each maximal run of non-`[a-z0-9]` characters with a single `-`, and trimming leading or trailing `-`
- `normalized-checkbox-text` is the checkbox text with the `- [ ]` or `- [x]` marker removed, internal whitespace collapsed, and leading/trailing whitespace trimmed

This reference is used only by the bootstrap ledger and does not require changing the existing plan file format.

## Initial Seed Findings

The first bootstrap iteration should seed `gaps.json` with at least these verified findings:

- `gap_id = bootstrap-cli-resume`, `severity = P1`, `status = open`, `bootstrap_kind = ux_gap`, `audit_kind = feature_gap`, `plan_item_refs = ["docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md#task-1-create-the-python-project-scaffold/007b80da0ec5a5f6d0faf362d046c17b19189f1f"]`
  CLI resume gap: `src/ralphception/cli.py` exposes `resume()` but does not wire real recovery behavior.
- `gap_id = bootstrap-startup-screen`, `severity = P1`, `status = open`, `bootstrap_kind = ux_gap`, `audit_kind = feature_gap`, `plan_item_refs = ["docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md#task-14-implement-startup-flow-first-run-bootstrap-and-artifact-review-screens/59a3096afd6833963d77087065353060024bb6e7"]`
  Startup UX gap: `src/ralphception/ui/screens/startup.py` summarizes bootstrap state but does not provide the full interactive first-run capture promised by the design.
- `gap_id = bootstrap-review-screen`, `severity = P1`, `status = open`, `bootstrap_kind = ux_gap`, `audit_kind = feature_gap`, `plan_item_refs = ["docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md#task-14-implement-startup-flow-first-run-bootstrap-and-artifact-review-screens/59a3096afd6833963d77087065353060024bb6e7"]`
  Review UX gap: `src/ralphception/ui/screens/review.py` provides controller-backed summaries and approvals, but the operator experience is still minimal compared to the intended review flow.
- `gap_id = bootstrap-storage-artifacts-module`, `severity = P2`, `status = open`, `bootstrap_kind = implementation_gap`, `audit_kind = feature_gap`, `plan_item_refs = []`
  Storage-plan gap: `src/ralphception/storage/artifacts.py` is listed in the runtime plan but missing from the implementation.

If a finding has no matching checkbox-backed `plan_item_ref`, the loop may leave `plan_item_refs` empty, but it must explain that in the finding rationale. The loop may also discover that some of these belong in a later milestone, but it must record that conclusion explicitly.

## Finish Criteria

The bootstrap loop is done only when all of the following are true:

- there are no `open` `P0`, `P1`, or `P2` gaps in `gaps.json`
- there are no unchecked in-scope plan items in the active runtime plan
- `finish-criteria.md` names the currently authoritative plan file and any explicitly accepted or `wontfix` items
- every accepted or narrowed item is recorded with rationale
- verification passes for the repository's active quality gates
- the README and planning docs no longer overstate what the implementation provides

If the loop reaches a point where remaining work is real but intentionally future-facing, it must move that work into explicit backlog state and remove it from the active finish criteria.

For deterministic doc-truth checks:

- "planning docs" means the authoritative spec paths and authoritative plan path named in `inputs.json`
- "overstate" means an authoritative doc or README claims a capability is implemented, interactive, resumable, or fully wired when the current code and tests do not support that claim
- the doc-truth finish criterion is satisfied when there are no `open` `doc_gap` findings with evidence paths under `README.md` or the authoritative spec/plan files

`finish-criteria.md` must include at minimum:

- authoritative spec path list
- authoritative plan path
- accepted and `wontfix` item list with rationale
- required verification commands
- current stop rule in plain language

Each `iterations/<timestamp>.md` summary must include at minimum:

- iteration timestamp
- authoritative input files used
- changes made
- verification commands run and outcomes
- gap ids resolved, opened, accepted, or marked `wontfix`
- next recommended slice if the loop is not done

`inputs.json.latest_iteration_summary_path` must point to the newest timestamped iteration summary so the next Codex iteration has a deterministic handoff file.

## Inputs Manifest Lifecycle

`inputs.json` is the machine-readable contract for what the next iteration should read.

Update rules:

- on the first run, seed it with the initial authoritative spec paths, plan path, README path, code globs, test globs, and `latest_iteration_summary_path = null`
- after every completed iteration, update `latest_iteration_summary_path` to the summary just written
- if an iteration creates or materially revises an authoritative spec or plan and that change is approved, the next iteration must update `authoritative_spec_paths` or `authoritative_plan_path` to the approved file set
- when a manifest pointer changes, the iteration summary must record both the old pointer and the new pointer
- no path becomes authoritative merely because it exists; it becomes authoritative only when `inputs.json` is updated to point at it
- if a file is superseded, it may remain on disk, but the loop must treat only the files named in `inputs.json` as normative on the next run

Default authoritative globs:

- `authoritative_code_globs = ["src/ralphception/**"]`
- `authoritative_test_globs = ["tests/unit/**", "tests/integration/**", "tests/e2e/**"]`

If a later iteration adds code or tests outside those globs, it must update `inputs.json` in the same iteration before those paths become authoritative.

## Script Contract

`ralph.sh` should:

- run from the repository root
- create `.ralphception/bootstrapping/` if it does not exist
- launch Codex in full-access, no-approval mode
- point Codex at the files named in `inputs.json`, plus the current gap ledger and the latest iteration summary
- require each iteration to update the ledger, make one coherent slice of progress, and run verification
- exit non-zero if verification fails or if the iteration cannot produce a durable summary

On the first run, `inputs.json` should be seeded with:

- `docs/superpowers/specs/2026-03-15-ralphception-design.md`
- `docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md`
- `docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md`
- `README.md`
- the active `src/ralphception/**` and `tests/**` trees

Later iterations may update the manifest if a new plan or spec supersedes an older one, but they must do so explicitly.

The script should remain intentionally small. Most of the behavior belongs in the loop prompt and the durable repo artifacts, not in shell control flow.

Concrete invocation pattern:

- `ralph.sh` should prefer `codex exec` for each fresh iteration because it is the Codex-supported non-interactive entry point for one-shot runs
- `--dangerously-bypass-approvals-and-sandbox` applies only to command/sandbox prompts inside a normal iteration; it does not bypass the bootstrap loop's own human review gate
- if `.ralphception/bootstrapping/approval-request.json` exists and has not yet been satisfied by a canonical runtime approval record, `ralph.sh` must stop before launching a new Codex iteration and ask the human to review the pending change
- the baseline command shape is:

```bash
codex exec \
  --cd /absolute/path/to/repo \
  --dangerously-bypass-approvals-and-sandbox \
  --model gpt-5.4 \
  -c model_reasoning_effort=\"high\" \
  -c model_verbosity=\"low\" \
  - < .ralphception/bootstrapping/prompt.txt
```

- `prompt.txt` is rendered from the loop prompt contract plus the current authoritative inputs listed in `inputs.json`
- if the bootstrap helper later switches to a Python SDK or `codex app-server` wrapper, it must preserve the same fresh-iteration semantics and artifact contracts defined here

## Loop Prompt Contract

The Codex prompt used by `ralph.sh` must be explicit enough that each iteration is mechanically auditable.

Required prompt inputs:

- the files named in `inputs.json`
- the current `gaps.json` and `gaps.md`
- the latest iteration summary from `inputs.json.latest_iteration_summary_path`, if present
- the current approval request file, if present
- the repo working tree

Required prompt instructions:

- read the authoritative inputs before making changes
- classify every newly discovered gap using the bootstrap taxonomy and map it to the runtime finding kind
- choose one coherent next slice unless the iteration is only reconciling approval state
- update `gaps.json` and regenerate `gaps.md`
- update `finish-criteria.md` only when finish criteria or authoritative inputs materially change
- write an iteration summary with changes made, verification run, findings changed, and next recommended slice
- stop for approval when a material spec or plan change is proposed
- never claim completion without running the required verification commands

Required prompt outputs after each successful iteration:

- updated repo files for the chosen slice
- updated `gaps.json`
- regenerated `gaps.md`
- updated `inputs.json` when authoritative pointers or latest summary path changed
- a new `iterations/<timestamp>.md` summary
- `approval-request.json` if and only if the loop is awaiting human review

Success criteria for one iteration:

- durable artifacts are internally consistent
- verification results are recorded in the iteration summary
- the next run can determine authoritative inputs and remaining gaps without chat history

## Verification Requirements

Every iteration must run the repository's normal quality checks for the files it changed, and the final iteration must run the full repo gates at minimum:

- `uv run pytest tests/unit tests/integration tests/e2e -q`
- `uv run ty check`

If the repository later adds stronger default gates, `ralph.sh` should follow the repo's declared quality bar instead of hard-coding a weaker one.

## Recovery And Idempotence

The bootstrap loop must be restartable:

- if a session dies, the next run reads `.ralphception/bootstrapping/` and continues
- if an iteration partially updates the ledger but does not finish, the next iteration reconciles the partial state instead of assuming success
- the script should not depend on one long-lived shell process or one long-lived Codex chat

This is the main reason to keep the ledger on disk and keep each iteration small.

## Risks

- A vague prompt will cause the loop to churn. The prompt must force explicit gap classification and finish-criteria tracking.
- If the loop is allowed to narrow scope silently, it can fake completion. Deferred work must always be recorded with rationale.
- If the loop does not re-run verification every iteration, it can regress the runtime while appearing to make progress.

## References

- Geoffrey Huntley, "ralph" and "loop" pattern guidance
- [https://ghuntley.com/ralph/](https://ghuntley.com/ralph/)
- [https://ghuntley.com/loop/](https://ghuntley.com/loop/)
- [https://loop-until-done.dev/](https://loop-until-done.dev/)
