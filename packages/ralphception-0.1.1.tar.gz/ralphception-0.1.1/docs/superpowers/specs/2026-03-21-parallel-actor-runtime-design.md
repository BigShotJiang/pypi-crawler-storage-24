# Parallel Actor Runtime Design

## Goal

Replace Ralphception's current serial shared-runtime mission loop with a single long-running orchestrator built as an explicit actor pipeline:

- Socratic intake at mission start
- one user approval on the spec
- autonomous planning, todo generation, batching, parallel worker execution, merge selection, and audit
- no user interruption after spec approval unless the process is terminally broken

## Current State

The current runtime is structurally closer to a serial supervisor than to the intended Ralphception product:

- the shared runtime centers on a root run plus at most one active child run
- `headless.py` tracks one `current_child_run_id` and a historical list of child run ids
- audit reopen creates one replacement child run at a time
- worktrees exist, but worker scheduling is not parallel
- `max_parallel_children` exists in config but is not consumed by the runtime
- todo artifacts are modeled, but the runtime does not actually emit or schedule a real todo graph
- merge behavior is still child-run-centric rather than commit-intent-centric

That structure is enough for alpha verification, but it is the wrong foundation for the intended unattended "Ralph loops of Ralph loops" product.

## Product Requirements

The new runtime must satisfy these product-level requirements:

1. Ralphception starts with an interactive Socratic loop immediately when the user launches it.
2. That loop converges on a spec draft and pauses for one explicit user approval.
3. After spec approval, Ralphception auto-proceeds into planning and execution without another human checkpoint.
4. The planner emits a plan, a todo DAG, commit intents, and execution policy.
5. The scheduler batches multiple todos into child runs dynamically based on dependency readiness and scope compatibility.
6. Child runs operate in separate worktrees and can run in parallel.
7. Multiple child runs may produce candidates related to the same commit intent.
8. The merge agent chooses the best candidate output for each commit intent, discards inferior alternatives, and writes meaningful final commits onto `main`.
9. The process should not stop for ordinary worker failures, merge conflicts, or audit findings. It should replan, rebatch, retry, or reopen automatically.
10. The process should only stop for terminal breakage: cases where the orchestrator cannot continue coherently.

## Selected Architecture

Ralphception should be rebuilt around one long-running orchestrator process with durable internal actors, not around the current serial supervisor and not around a multi-process distributed queue system.

The orchestrator owns mission lifecycle, actor scheduling, persistence, and frontend updates. Actors are logical components inside that process, each with explicit contracts and durable snapshots so the system can recover after restart.

This is a breaking architectural change by design. The goal is not to preserve current root-run and child-run semantics exactly. The goal is to establish the right product architecture for unattended parallel execution.

## High-Level Actor Pipeline

```mermaid
flowchart TD
    A["User starts Ralphception"] --> B["Socratic Intake Actor"]
    B --> C["Spec Approval Gate"]
    C --> D["Planner Actor"]
    D --> E["Todo DAG + Commit Intents + Execution Policy"]
    E --> F["Scheduler Actor"]
    F --> G1["Worker Actor / Worktree A"]
    F --> G2["Worker Actor / Worktree B"]
    F --> G3["Worker Actor / Worktree C"]
    G1 --> H["Merge Agent"]
    G2 --> H
    G3 --> H
    H --> I["Audit Actor"]
    I --> J{"Blocking findings remain?"}
    J -- yes --> D
    J -- no --> K["Mission complete"]
```

## Actor Responsibilities

### 1. Socratic Intake Actor

The Socratic intake actor is the only interactive actor at mission start.

Responsibilities:

- ask one question at a time
- refine the mission until the request is concrete enough to spec
- draft the spec artifact
- hand control to the approval gate

Rules:

- it starts immediately when the user launches Ralphception
- it behaves like the `brainstorming` loop: clarification first, design/spec second
- it should not emit todos, commit intents, or worker assignments
- it ends when the spec is explicit enough for user approval

### 2. Spec Approval Gate

The spec approval gate is the last required human checkpoint.

Responsibilities:

- present the spec draft
- accept approval or revision feedback
- freeze the approved spec version

Rules:

- once approved, the user can walk away
- no later planning, todo, commit-intent, merge, or audit step should require human approval by default

### 3. Planner Actor

The planner actor starts only after spec approval.

Responsibilities:

- derive the implementation plan from the approved spec
- emit a todo DAG
- emit commit intents
- emit execution policy for the scheduler

Outputs:

- mission plan document
- machine-readable plan contract
- todo DAG
- commit intents
- execution policy

The planner owns structure. It is where commit boundaries are decided. The merge agent should not have to invent the intended commit structure from scratch.

### 4. Scheduler Actor

The scheduler actor is the center of parallel execution.

Responsibilities:

- maintain ready, running, blocked, failed, and completed todo state
- choose which todos are runnable based on dependency satisfaction
- batch multiple compatible todos into one child-run assignment
- maintain an active worker set up to the configured concurrency budget
- refill worker slots as batches complete
- split or retry batches when execution outcomes show that a batch was too broad or unstable

The scheduler replaces the current single `current_child_run_id` model with a real worker pool.

### 5. Worker Actors

Each worker actor corresponds to one active child run and one active worktree.

Responsibilities:

- receive a batch of compatible todos
- implement the assigned scope in its worktree
- run verification required by the execution policy
- produce candidate artifacts for merge review
- report per-todo outcomes, not just one opaque child-run summary

Important rule:

- one child run can own multiple todos
- the scheduler decides the batching, not the planner

### 6. Merge Agent

The merge agent is a decision-making actor, not just a git command wrapper.

Responsibilities:

- review worker outputs against commit intents
- compare competing or overlapping candidates
- select the best candidate when multiple workers contribute to the same intent
- discard inferior alternatives
- assemble meaningful final commits that match repo commit style
- land those commits onto `main`

Important rule:

- batching is for execution throughput
- final commit shape is for repo quality

That means a worker batch does not imply a final commit boundary. The merge agent is allowed to split successful work back out into cleaner final commits.

### 7. Audit Actor

The audit actor validates whether the mission is truly done.

Responsibilities:

- review landed commits against the approved spec
- record findings
- decide whether blocking findings remain
- reopen the planner and scheduler only for the affected surface

The audit actor should reopen execution automatically. It should not pause for user input unless the system is terminally broken.

## Durable Mission Store

The orchestrator should persist mission state in repo-local durable storage under `.ralphception/`, but the structure should be revised for actor-based execution.

Recommended top-level durable artifacts:

```text
.ralphception/
|- mission/
|  |- session.json
|  |- policy.json
|  `- phase.json
|- specs/
|  `- approved-spec.md
|- plans/
|  |- mission-plan.md
|  `- mission-plan.json
|- todos/
|  |- todo-dag.json
|  `- todo-status.json
|- commits/
|  |- intents.json
|  `- merge-decisions.json
|- actors/
|  |- intake.json
|  |- planner.json
|  |- scheduler.json
|  |- merge.json
|  `- audit.json
|- workers/
|  `- <worker-id>/
|     |- assignment.json
|     |- candidate.json
|     |- verification/
|     `- handoff.json
|- findings/
|  `- open-findings.json
`- events/
   `- mission.jsonl
```

### Why this store exists

This store gives the orchestrator enough state to resume after crash or restart without human reconstruction:

- approved spec version
- plan and planner outputs
- todo DAG and current todo statuses
- active and historical worker assignments
- merge candidates and merge decisions
- audit findings and reopen reasons
- actor snapshots and event log

## Core Durable Models

The runtime should introduce or formalize these first-class models:

- `MissionSession`
  Tracks mission identity, repo root, lifecycle phase, policy, and top-level status.

- `ApprovedSpec`
  Immutable spec content after approval.

- `PlanContract`
  The machine-readable planning output.

- `TodoNode`
  Includes `todo_id`, title, dependency ids, scope hints, status, owning commit intent, owning worker id if assigned, retry metadata, and evidence links.

- `CommitIntent`
  Includes intent id, target commit message, commit ordering constraints, todo membership, style constraints, and current winning candidate.

- `ExecutionPolicy`
  Includes concurrency budget, batching heuristics, retry budget, and merge competition rules.

- `WorkerAssignment`
  Includes worker id, worktree path, batch todo ids, claimed commit intents, verification requirements, and status.

- `WorkerCandidate`
  Includes touched paths, verification evidence, todo outcome summary, and references to produced artifacts.

- `MergeDecision`
  Includes selected candidate, rejected candidates, rationale, final commit mapping, and landed commit hashes.

- `AuditSnapshot`
  Includes findings, reopen targets, and completion decision.

## Todo DAG Semantics

The planner emits an explicit todo DAG.

Rules:

- todos are first-class durable artifacts
- dependencies are explicit, not inferred post hoc
- only todos with satisfied dependencies enter the scheduler's ready queue
- todos may be grouped into batches, but their identity and status remain independent

The todo DAG is the unit of scheduling truth. It is the structure that lets Ralphception parallelize safely without pretending file-level inference is enough.

## Commit Intent Semantics

Commit intents are also emitted by the planner up front.

Each commit intent defines:

- the logical change to be represented in the final history
- the desired commit message or message template
- the todos that belong to that logical change
- ordering constraints relative to other commit intents
- repo-style constraints the merge agent should honor

This separates two concerns cleanly:

- execution batching for throughput
- final commits for review quality

## Scheduler Semantics

The scheduler should use the todo DAG and execution policy to manage a pool of active worker slots.

Recommended scheduling loop:

1. scan the DAG for ready todos
2. exclude todos blocked by active incompatible scope
3. score candidate batches by:
   - shared commit intent
   - compatible scope size
   - verification cost
   - dependency locality
4. assign the best batches to available worker slots
5. persist assignment state before launching workers
6. on worker completion:
   - mark todo outcomes
   - release scopes
   - queue merge review
   - refill available slots

### Concurrency Model

The configured concurrency budget should bound the number of active worker runs, but actual use should be dynamic.

That means:

- the policy may allow up to `N` workers
- the scheduler may use fewer when the DAG is narrow or scopes conflict
- the scheduler may increase parallelism when independent ready work exists

## Worker Output Semantics

A worker should never return a single coarse "done/not done" result for the whole batch.

It must return:

- which todos were completed
- which todos failed
- touched paths
- verification results
- claimed commit intents
- candidate artifacts for merge review

This allows the orchestrator to:

- split successful work back out from a partially failed batch
- retry only the failed slice
- avoid throwing away good work unnecessarily

## Merge Agent Semantics

The merge agent owns final commit quality.

Recommended merge-agent loop:

1. collect candidates for each commit intent
2. compare candidates against:
   - approved spec
   - commit intent requirements
   - verification evidence
   - repo commit style
3. select the strongest candidate
4. discard inferior candidates
5. map accepted work to final commits on `main`
6. persist merge decisions and landed commit hashes

### Competing Candidates

Competing candidates should be allowed, but not required for every todo.

They should mainly arise from:

- retries
- replacements
- batch splitting
- explicit rework after audit

The system should not duplicate all work by default.

## Failure and Autonomy Rules

The orchestrator should be fully autonomous after spec approval.

### It should not stop for:

- ordinary worker failure
- merge conflict that can be resolved through rebatching or rework
- rejected candidate output
- audit findings
- planner outputs that require internal correction

### It should stop only for terminal breakage:

- unrecoverable store corruption
- inability to reconstruct actor state coherently
- missing or invalid approved spec after approval
- irrecoverable backend failure after retry budget exhaustion
- contradictory mission state that the orchestrator cannot safely resolve

The system should prefer internal recovery over user prompts.

## Resume and Recovery

Because the chosen architecture is one long-running orchestrator, durability is still required.

On restart, the orchestrator should reconstruct:

- approved spec
- plan outputs
- todo DAG state
- active worker assignments
- worktree mappings
- merge review backlog
- audit state
- actor snapshots

Then it should continue autonomously without re-running the Socratic loop or asking the user to restate intent.

## Frontend Implications

The TUI and terminal frontend should remain thin surfaces over the same orchestrator.

### Terminal frontend

Should show:

- Socratic loop prompts during intake
- spec approval prompt
- then continuous actor/scheduler/worker/merge/audit logs

### TUI frontend

Should show:

- active phase
- ready/running/completed todo counts
- active worker worktrees
- candidate merge decisions
- audit reopen state

Neither frontend should contain orchestration logic.

## Testing Strategy

This architecture should be tested at three levels.

### Unit tests

For:

- todo DAG validation
- scheduler batching rules
- commit-intent matching
- merge-agent candidate selection
- actor snapshot reconstruction

### Integration tests

For:

- planner -> scheduler handoff
- scheduler -> worker assignment lifecycle
- worker -> merge candidate lifecycle
- audit-triggered reopen
- crash and resume mid-mission

### End-to-end tests

For:

- Socratic intake -> spec approval -> autonomous execution -> merge -> audit -> completion
- parallel worker execution with competing candidates
- unattended reroute after batch failure

## Explicit Non-Goals

This design does not try to preserve today's runtime model as a compatibility target.

Specifically, it does not optimize for:

- keeping `run-root` plus one active child as the core abstraction
- reusing the current serial state machine as the scheduler
- asking the user to manually resolve ordinary runtime failures after spec approval

## Summary

Ralphception should move from a serial supervisor with child-run helpers to a true actor-based orchestrator.

The key architectural commitments are:

- Socratic clarification at launch
- one spec approval gate
- planner-emitted todo DAG and commit intents
- scheduler-owned batching and parallel worker execution
- merge-agent-owned final commit selection
- audit-driven reopen without human interruption
- one long-running orchestrator with durable internal actor state

That architecture matches the intended product more directly than an incremental evolution of the current serial loop.
