#!/usr/bin/env bash
set -euo pipefail

cd -- "$(dirname "$0")"

iteration=1
while true; do
  echo "== Ralph loop iteration ${iteration} =="

  if uv run python -m ralphception.bootstrap.runner --loop-once "$@"; then
    status=0
  else
    status=$?
  fi

  case "$status" in
    0)
      echo "Ralph loop complete."
      exit 0
      ;;
    10)
      iteration=$((iteration + 1))
      ;;
    11)
      echo "Ralph loop is waiting for review."
      exit 0
      ;;
    *)
      echo "Ralph loop failed with exit code ${status}."
      exit "$status"
      ;;
  esac
done
