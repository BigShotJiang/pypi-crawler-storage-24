from datetime import datetime, timezone
from pathlib import Path

from ralphception.bootstrap.contracts import BootstrapApprovalRequest
from ralphception.bootstrap.prompting import render_iteration_prompt
from ralphception.bootstrap.storage import seed_bootstrap_state


def test_render_iteration_prompt_includes_authoritative_inputs(tmp_path: Path) -> None:
    _write_text(
        tmp_path / "docs" / "superpowers" / "specs" / "2026-03-15-ralphception-design.md",
        "# Core Design\n\nDesign spec body.\n",
    )
    _write_text(
        tmp_path
        / "docs"
        / "superpowers"
        / "specs"
        / "2026-03-17-ralphception-bootstrap-loop-design.md",
        "# Bootstrap Loop Design\n\nBootstrap spec body.\n",
    )
    _write_text(
        tmp_path / "docs" / "superpowers" / "plans" / "2026-03-15-ralphception-core-runtime.md",
        "# Core Runtime Plan\n\n- [ ] Pending runtime work.\n",
    )
    _write_text(
        tmp_path / "README.md",
        "# Ralphception\n\nREADME truthfulness guidance.\n",
    )

    state = seed_bootstrap_state(tmp_path)
    latest_summary_path = ".ralphception/bootstrapping/iterations/2026-03-17T12-00-00Z.md"
    _write_text(
        tmp_path / latest_summary_path,
        "# Iteration Summary\n\nPrevious slice summary.\n",
    )
    state.inputs = state.inputs.model_copy(
        update={"latest_iteration_summary_path": latest_summary_path},
    )

    prompt = render_iteration_prompt(tmp_path, state)

    assert "docs/superpowers/specs/2026-03-15-ralphception-design.md" in prompt
    assert "# Core Design" in prompt
    assert "docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md" in prompt
    assert "# Bootstrap Loop Design" in prompt
    assert "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md" in prompt
    assert "# Core Runtime Plan" in prompt
    assert "README.md" in prompt
    assert "README truthfulness guidance." in prompt
    assert "src/ralphception/**" in prompt
    assert "tests/unit/**" in prompt
    assert ".ralphception/bootstrapping/iterations/2026-03-17T12-00-00Z.md" in prompt
    assert "Previous slice summary." in prompt
    assert "gaps.json" in prompt
    assert "gaps.md" in prompt
    assert "bootstrap-cli-resume" in prompt
    assert "uv run pytest tests/unit tests/integration tests/e2e -q" in prompt
    assert "uv run ty check src tests" in prompt
    assert "read the authoritative inputs before making changes" in prompt.lower()
    assert "classify every newly discovered gap" in prompt.lower()
    assert "update gaps.json and regenerate gaps.md" in prompt.lower()
    assert "guard finish-criteria.md" in prompt.lower()
    assert "write an iteration summary" in prompt.lower()
    assert "stop for approval when a material spec or plan change is proposed" in prompt.lower()
    assert "never claim completion without running the required verification commands" in prompt.lower()


def test_render_iteration_prompt_mentions_pending_approval_request(tmp_path: Path) -> None:
    state = seed_bootstrap_state(tmp_path)
    state.approval_request = BootstrapApprovalRequest(
        approval_kind="spec_review",
        run_id="run-root",
        artifact_paths=["docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md"],
        bundle_id="bundle-1",
        bundle_version=1,
        scope_hash="sha256:test",
        waived_finding_ids=None,
        rationale=None,
        requested_at=datetime(2026, 3, 17, tzinfo=timezone.utc),
    )

    prompt = render_iteration_prompt(tmp_path, state)

    assert "approval-request.json" in prompt
    assert "spec_review" in prompt
    assert "stop for human review" in prompt.lower()
    assert "docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md" in prompt


def test_render_iteration_prompt_reads_pending_approval_request_from_disk(tmp_path: Path) -> None:
    state = seed_bootstrap_state(tmp_path)
    approval_request_json = """{
  "approval_kind": "spec_review",
  "run_id": "run-root",
  "artifact_paths": [
    "docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md"
  ],
  "bundle_id": "bundle-2",
  "bundle_version": 1,
  "scope_hash": "sha256:disk",
  "waived_finding_ids": null,
  "rationale": null,
  "requested_at": "2026-03-17T00:00:00Z"
}
"""
    _write_text(
        tmp_path / ".ralphception" / "bootstrapping" / "approval-request.json",
        approval_request_json,
    )

    prompt = render_iteration_prompt(tmp_path, state)

    assert "approval-request.json" in prompt
    assert "stop for human review" in prompt.lower()
    assert '"approval_kind": "spec_review"' in prompt
    assert '"scope_hash": "sha256:disk"' in prompt


def _write_text(path: Path, contents: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(contents, encoding="utf-8")
