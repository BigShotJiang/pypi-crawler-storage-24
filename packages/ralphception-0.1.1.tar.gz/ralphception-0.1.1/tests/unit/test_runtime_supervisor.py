from __future__ import annotations

import hashlib
from pathlib import Path
from unittest.mock import patch

from ralphception.config import DEFAULT_CONFIG
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.models.artifacts import ArtifactRef
from ralphception.runtime.supervisor import RuntimeSupervisor, _default_session_manager_factory
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.ui.screens.startup import StartupBootstrapController


def test_supervisor_routes_unbootstrapped_workspace_to_startup_request(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)

    supervisor = RuntimeSupervisor(repo_root=repo_root)

    outcome = supervisor.step()

    assert outcome.kind == "startup_prompt"
    assert outcome.startup_prompt is not None
    assert outcome.startup_prompt.repo_root == repo_root


def test_supervisor_routes_pending_spec_to_review_request(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Review before planning.\n",
    )

    supervisor = RuntimeSupervisor(repo_root=repo_root)

    outcome = supervisor.step()

    assert outcome.kind == "review_prompt"
    assert outcome.review_prompt is not None
    assert outcome.review_prompt.review_kind == "spec_review"


def test_supervisor_routes_bootstrapped_workspace_to_dashboard_state(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )

    supervisor = RuntimeSupervisor(repo_root=repo_root)

    outcome = supervisor.step()

    assert outcome.kind == "dashboard"
    assert outcome.engine is not None


def test_default_session_manager_factory_uses_codex_cli_backend_when_available(tmp_path: Path) -> None:
    with patch("ralphception.runtime.supervisor.codex_cli_available", return_value=True):
        manager = _default_session_manager_factory(tmp_path, DEFAULT_CONFIG)

    assert isinstance(manager, CodexSessionManager)


def test_default_session_manager_factory_returns_none_without_codex_cli(tmp_path: Path) -> None:
    with patch("ralphception.runtime.supervisor.codex_cli_available", return_value=False):
        manager = _default_session_manager_factory(tmp_path, DEFAULT_CONFIG)

    assert manager is None


def write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    artifact_version: int,
    content: str,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=artifact_version,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )
