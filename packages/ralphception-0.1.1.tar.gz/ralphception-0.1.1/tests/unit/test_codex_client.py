from __future__ import annotations

from collections import deque
from pathlib import Path
from typing import cast

import pytest

from ralphception.codex.client import (
    AppServerRpcError,
    AppServerTransportProtocol,
    CodexAppServerClient,
    SubprocessAppServerTransport,
    codex_cli_available,
)
from ralphception.config import DEFAULT_CONFIG


def test_codex_cli_available_checks_for_codex_binary(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("ralphception.codex.client.shutil.which", lambda name: "/usr/local/bin/codex")

    assert codex_cli_available() is True


def test_codex_app_server_client_uses_transport_for_initialize_and_thread_start() -> None:
    transport = FakeTransport(
        responses=[
            {"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}},
            {
                "id": 2,
                "result": {
                    "thread": {"id": "thread-123"},
                    "cwd": "/tmp/workspace",
                    "model": "gpt-5.4",
                    "approvalPolicy": "never",
                    "sandbox": "danger-full-access",
                },
            },
        ],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    session = client.thread_start(cwd="/tmp/workspace", config=DEFAULT_CONFIG.codex)

    assert session.thread_id == "thread-123"
    assert session.workspace_path == "/tmp/workspace"
    assert transport.started is True
    assert transport.requests[0][0] == "initialize"
    assert transport.requests[1][0] == "thread/start"
    request_payload = transport.requests[1][1]
    assert request_payload["baseInstructions"]
    assert request_payload["developerInstructions"]
    assert request_payload["config"] == {
        "features.child_agents_md": False,
        "features.plugins": False,
        "skills.bundled.enabled": False,
    }


def test_codex_app_server_client_applies_scoped_instructions_to_resume_and_fork() -> None:
    transport = FakeTransport(
        responses=[
            {"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}},
            {
                "id": 2,
                "result": {
                    "thread": {"id": "thread-123"},
                    "cwd": "/tmp/workspace",
                    "model": "gpt-5.4",
                    "approvalPolicy": "never",
                    "sandbox": "danger-full-access",
                },
            },
            {
                "id": 3,
                "result": {
                    "thread": {"id": "thread-456"},
                    "cwd": "/tmp/workspace",
                    "model": "gpt-5.4",
                    "approvalPolicy": "never",
                    "sandbox": "danger-full-access",
                },
            },
        ],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    client.thread_resume("thread-123", cwd="/tmp/workspace", config=DEFAULT_CONFIG.codex)
    client.thread_fork("thread-123", cwd="/tmp/workspace", config=DEFAULT_CONFIG.codex)

    resume_payload = transport.requests[1][1]
    fork_payload = transport.requests[2][1]

    assert resume_payload["baseInstructions"]
    assert resume_payload["developerInstructions"]
    assert resume_payload["config"] == {
        "features.child_agents_md": False,
        "features.plugins": False,
        "skills.bundled.enabled": False,
    }
    assert fork_payload["baseInstructions"]
    assert fork_payload["developerInstructions"]
    assert fork_payload["config"] == {
        "features.child_agents_md": False,
        "features.plugins": False,
        "skills.bundled.enabled": False,
    }


def test_codex_app_server_client_normalizes_transport_notifications() -> None:
    transport = FakeTransport(
        responses=[{"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}}],
        notifications=[
            {
                "method": "turn/completed",
                "params": {
                    "threadId": "thread-123",
                    "turnId": "turn-456",
                },
            },
        ],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    client.initialize()
    notification = client.next_notification()

    assert notification.method == "turn/completed"
    assert notification.thread_id == "thread-123"
    assert notification.turn_id == "turn-456"


def test_codex_app_server_client_prepares_transport_for_threads_on_initialize() -> None:
    transport = FakeTransport(
        responses=[{"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}}],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    client.initialize()

    assert transport.prepared_for_threads is True


def test_codex_app_server_client_does_not_wrap_keyboard_interrupt_notifications() -> None:
    class InterruptingTransport(FakeTransport):
        def next_notification(self) -> dict:
            raise KeyboardInterrupt

    transport = InterruptingTransport(
        responses=[{"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}}],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    client.initialize()

    with pytest.raises(KeyboardInterrupt):
        client.next_notification()


def test_subprocess_transport_raises_rpc_errors_from_server_responses(tmp_path: Path) -> None:
    transport = SubprocessAppServerTransport(process_factory=lambda: FakeProcess(stdout_lines=[
        '{"id":1,"error":{"code":-32601,"message":"unknown method"}}',
    ]))

    with pytest.raises(AppServerRpcError, match="unknown method"):
        transport.request("initialize", {"clientInfo": {"name": "tests", "version": "0.0.0"}})


def test_subprocess_transport_disables_child_agents_md_by_default() -> None:
    transport = SubprocessAppServerTransport()

    assert transport._command == ("codex", "app-server", "--disable", "child_agents_md", "--listen", "stdio://")


def test_subprocess_transport_spawns_with_isolated_codex_home(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    source_codex_home = tmp_path / "source-codex-home"
    source_codex_home.mkdir()
    (source_codex_home / "auth.json").write_text('{"access_token":"secret"}', encoding="utf-8")
    monkeypatch.setenv("CODEX_HOME", str(source_codex_home))
    monkeypatch.setenv("HOME", "/Users/tester")

    captured: dict[str, object] = {}

    def fake_popen(*args, **kwargs):
        captured["command"] = args[0]
        captured["env"] = kwargs["env"]
        return FakeProcess(stdout_lines=[])

    monkeypatch.setattr("ralphception.codex.client.subprocess.Popen", fake_popen)

    transport = SubprocessAppServerTransport()
    transport.start()

    spawned_env = cast(dict[str, str], captured["env"])
    isolated_home = Path(spawned_env["CODEX_HOME"])

    assert spawned_env["HOME"] == spawned_env["CODEX_HOME"]
    assert isolated_home != source_codex_home
    assert (isolated_home / "auth.json").read_text(encoding="utf-8") == '{"access_token":"secret"}'
    assert "plugins = false" in (isolated_home / "config.toml").read_text(encoding="utf-8")
    assert "[skills.bundled]" in (isolated_home / "config.toml").read_text(encoding="utf-8")
    assert "enabled = false" in (isolated_home / "config.toml").read_text(encoding="utf-8")


def test_subprocess_transport_prepare_for_threads_prunes_embedded_system_skills(tmp_path: Path) -> None:
    transport = SubprocessAppServerTransport(process_factory=lambda: FakeProcess(stdout_lines=[]))
    isolated_home = tmp_path / "isolated-codex-home"
    system_dir = isolated_home / "skills" / ".system" / "skill-creator"
    system_dir.mkdir(parents=True)
    transport._isolated_codex_home = isolated_home

    transport.prepare_for_threads()

    assert not (isolated_home / "skills" / ".system").exists()


class FakeTransport:
    def __init__(
        self,
        *,
        responses: list[dict],
        notifications: list[dict] | None = None,
    ) -> None:
        self.responses = deque(responses)
        self.notifications = deque(notifications or [])
        self.requests: list[tuple[str, dict]] = []
        self.started = False
        self.closed = False
        self.prepared_for_threads = False

    def start(self) -> None:
        self.started = True

    def close(self) -> None:
        self.closed = True

    def prepare_for_threads(self) -> None:
        self.prepared_for_threads = True

    def request(self, method: str, params: dict) -> dict:
        self.requests.append((method, params))
        return self.responses.popleft()

    def next_notification(self) -> dict:
        return self.notifications.popleft()


class FakePipe:
    def __init__(self, lines: list[str]) -> None:
        self._lines = deque(lines)
        self.writes: list[str] = []

    def write(self, value: str) -> int:
        self.writes.append(value)
        return len(value)

    def flush(self) -> None:
        return None

    def readline(self) -> str:
        if self._lines:
            return self._lines.popleft() + "\n"
        return ""

    def read(self) -> str:
        remaining = "\n".join(self._lines)
        self._lines.clear()
        return remaining


class FakeProcess:
    def __init__(self, *, stdout_lines: list[str]) -> None:
        self.stdin = FakePipe([])
        self.stdout = FakePipe(stdout_lines)
        self.stderr = FakePipe([])
        self.returncode: int | None = None

    def poll(self) -> int | None:
        return self.returncode

    def terminate(self) -> None:
        self.returncode = 0

    def wait(self, timeout: float | None = None) -> int:
        self.returncode = 0
        return 0
