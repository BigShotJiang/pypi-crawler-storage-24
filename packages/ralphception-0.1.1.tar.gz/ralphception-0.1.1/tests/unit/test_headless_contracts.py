from __future__ import annotations

import json
from pathlib import Path

from ralphception.headless import _load_plan_contract


def test_load_plan_contract_ignores_placeholder_verification_commands(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    plans_dir.mkdir(parents=True)
    contract_path = plans_dir / "mission-plan.json"
    contract_path.write_text(
        json.dumps(
            {
                "execution_goal": "Find a bug",
                "verification_commands": [
                    "uv run pytest tests/unit/test_runtime_supervisor.py -q",
                    "uv run pytest <targeted test file or test node> -q",
                    "uv run pytest <updated targeted tests> -q",
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    contract = _load_plan_contract(contract_path, default_goal="fallback goal")

    assert contract.execution_goal == "Find a bug"
    assert contract.verification_commands == [
        "uv run pytest tests/unit/test_runtime_supervisor.py -q",
    ]


def test_load_plan_contract_parses_todos_commit_intents_and_execution_policy(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    plans_dir.mkdir(parents=True)
    contract_path = plans_dir / "mission-plan.json"
    contract_path.write_text(
        json.dumps(
            {
                "execution_goal": "Implement the parser artifact.",
                "verification_commands": ['uv run pytest tests/unit/test_runtime_supervisor.py -q'],
                "todos": [
                    {
                        "todo_id": "todo-1",
                        "title": "Implement parser artifact",
                        "dependency_ids": [],
                        "status": "ready",
                        "commit_intent_id": "intent-1",
                        "scope_hints": ["src/parser.py"],
                    }
                ],
                "commit_intents": [
                    {
                        "intent_id": "intent-1",
                        "message": "feat: add parser artifact",
                        "todo_ids": ["todo-1"],
                        "ordering_after": [],
                    }
                ],
                "execution_policy": {
                    "max_parallel_children": 3,
                    "batch_by_scope": True,
                    "allow_commit_split": True,
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    contract = _load_plan_contract(contract_path, default_goal="fallback goal")

    assert [todo.todo_id for todo in contract.todos] == ["todo-1"]
    assert [intent.intent_id for intent in contract.commit_intents] == ["intent-1"]
    assert contract.execution_policy.max_parallel_children == 3


def test_load_plan_contract_normalizes_richer_planner_schema(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    plans_dir.mkdir(parents=True)
    contract_path = plans_dir / "mission-plan.json"
    contract_path.write_text(
        json.dumps(
            {
                "execution_goal": "Document the system architecture.",
                "verification_commands": [
                    {
                        "command": "nix fmt",
                        "purpose": "Keep formatting consistent.",
                    },
                    {
                        "command": "nix flake check --all-systems",
                        "purpose": "Verify the flake.",
                    },
                ],
                "todos": [
                    {
                        "id": "baseline-architecture-inventory",
                        "title": "Inventory the current architecture",
                        "files": ["flake.nix", "README.md"],
                        "commands": ["rg -n architecture ."],
                        "verification_gate": ["Confirm the host list matches the flake outputs."],
                    },
                    {
                        "id": "document-modules-and-package-wiring",
                        "title": "Document module and package wiring",
                        "files": ["docs/architecture.md"],
                        "commands": ["sed -n '1,200p' docs/architecture.md"],
                        "verification_gate": ["The documentation should reflect the package wiring."],
                    },
                ],
                "commit_intents": [
                    {
                        "scope": "docs",
                        "summary": "add an architecture overview",
                    },
                    {
                        "scope": "lib",
                        "summary": "annotate flake outputs and loader composition flow",
                    },
                ],
                "execution_policy": {
                    "mode": "documentation-first, behavior-preserving",
                    "allowed_changes": ["Markdown documentation", "Comments"],
                    "forbidden_changes": ["Behavior changes"],
                    "verification_strategy": "Run the targeted nix checks.",
                    "completion_definition": "All gates pass.",
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    contract = _load_plan_contract(contract_path, default_goal="fallback goal")

    assert contract.execution_goal == "Document the system architecture."
    assert contract.verification_commands == [
        "nix fmt",
        "nix flake check --all-systems",
    ]
    assert [todo.todo_id for todo in contract.todos] == [
        "baseline-architecture-inventory",
        "document-modules-and-package-wiring",
    ]
    assert contract.todos[0].status == "ready"
    assert contract.todos[1].dependency_ids == ["baseline-architecture-inventory"]
    assert contract.todos[0].scope_hints == ["flake.nix", "README.md"]
    assert [intent.intent_id for intent in contract.commit_intents] == ["intent-1", "intent-2"]
    assert contract.commit_intents[0].message == "docs: add an architecture overview"
    assert contract.commit_intents[0].todo_ids == ["baseline-architecture-inventory"]
    assert contract.commit_intents[1].ordering_after == ["intent-1"]
    assert contract.commit_intents[1].todo_ids == ["document-modules-and-package-wiring"]
    assert contract.execution_policy == contract.execution_policy.__class__()
