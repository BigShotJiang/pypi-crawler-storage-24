from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

import pytest

from ralphception.config import DEFAULT_CONFIG, load_config, write_config_atomically
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import (
    ExecutionBundle,
    ExecutionBundleState,
    Run,
    RunStageStatus,
    Stage,
    StageKind,
)
from ralphception.models.session import ChildSessionRef
from ralphception.storage.events import EventStore
from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import ResumeResult


def test_help_command_lists_core_commands(tmp_path: Path) -> None:
    controller = build_controller(tmp_path)

    result = controller.handle_command("/help")

    assert result.ok is True
    assert "/model" in result.message
    assert "/resume" in result.message
    assert "/abort" in result.message


def test_artifacts_command_selects_pending_bundle(tmp_path: Path) -> None:
    controller = build_controller(
        tmp_path,
        bundles=[
            make_bundle(bundle_id="bundle-1", bundle_version=1, state="approved"),
            make_bundle(bundle_id="bundle-2", bundle_version=2, state="awaiting_approval"),
        ],
    )

    result = controller.handle_command("/artifacts")

    assert result.ok is True
    assert controller.selected_node_id == "bundle:bundle-2"
    assert "bundle-2" in result.message


def test_model_command_updates_config(tmp_path: Path) -> None:
    config_file = tmp_path / ".ralphception" / "config.toml"
    write_config_atomically(config_file, DEFAULT_CONFIG)
    controller = build_controller(tmp_path)

    result = controller.handle_command("/model gpt-5.5")
    persisted = load_config(config_file)

    assert result.ok is True
    assert persisted.config is not None
    assert persisted.config.codex.model == "gpt-5.5"
    assert controller.config.codex.model == "gpt-5.5"


def test_malformed_quoted_command_returns_friendly_error(tmp_path: Path) -> None:
    controller = build_controller(tmp_path)

    result = controller.handle_command('/model "gpt-5.5')

    assert result.ok is False
    assert "Malformed command" in result.message


def test_invalid_command_returns_error(tmp_path: Path) -> None:
    controller = build_controller(tmp_path)

    result = controller.handle_command("/wat")

    assert result.ok is False
    assert "Unknown command" in result.message


def test_status_command_reports_workflow_summary(tmp_path: Path) -> None:
    controller = build_controller(
        tmp_path,
        bundles=[
            make_bundle(bundle_id="bundle-1", bundle_version=1, state="approved"),
            make_bundle(bundle_id="bundle-2", bundle_version=2, state="awaiting_approval"),
        ],
        stages=[
            make_stage(stage_kind="intake", status="completed"),
            make_stage(stage_kind="plan", status="awaiting_approval"),
            make_stage(stage_kind="execute", status="pending"),
        ],
    )

    result = controller.handle_command("/status")

    assert result.ok is True
    assert "run-root is running" in result.message
    assert "3 stages" in result.message
    assert "2 blocked" in result.message
    assert "2 bundles" in result.message


def test_blocked_stage_detail_includes_reason_and_next_actions(tmp_path: Path) -> None:
    controller = build_controller(
        tmp_path,
        stages=[
            make_stage(stage_kind="intake", status="completed"),
            make_stage(stage_kind="plan", status="awaiting_approval"),
            make_stage(stage_kind="execute", status="awaiting_approval"),
        ],
    )

    controller.select_node("stage:plan")
    detail = controller.selected_detail()

    assert detail is not None
    assert detail.blocked_reason is not None
    assert "approval" in detail.blocked_reason.lower()
    assert "/approve" in detail.next_actions


def test_approve_command_marks_pending_bundle_approved(tmp_path: Path) -> None:
    controller = build_controller(
        tmp_path,
        bundles=[
            make_bundle(bundle_id="bundle-1", bundle_version=1, state="approved"),
            make_bundle(bundle_id="bundle-2", bundle_version=2, state="awaiting_approval"),
        ],
    )

    controller.select_node("bundle:bundle-2")
    result = controller.handle_command("/approve")

    assert result.ok is True
    assert "Approved bundle bundle-2" in result.message
    assert controller.selected_node_id == "bundle:bundle-2"
    assert controller.engine._bundles_by_id["bundle-2"].state == "approved"


def test_approve_command_rejects_when_no_bundle_is_pending(tmp_path: Path) -> None:
    controller = build_controller(
        tmp_path,
        bundles=[make_bundle(bundle_id="bundle-1", bundle_version=1, state="approved")],
    )

    result = controller.handle_command("/approve")

    assert result.ok is False
    assert "No bundle is waiting for approval" in result.message


def test_resume_hydrates_event_feed_from_event_store(tmp_path: Path) -> None:
    store = EventStore(tmp_path)
    store.append(
        event_id="event-1",
        run_id="run-root",
        event_type="run.created",
        source="tests",
        payload={"goal": "ship ui", "parent_run_id": None},
    )
    store.append(
        event_id="event-2",
        run_id="run-root",
        event_type="run.started",
        source="tests",
        payload={"goal": "ship ui", "parent_run_id": None},
    )
    recovery = FakeRecoveryService(
        result=ResumeResult(
            run_id="run-root",
            mode="read",
            lease_taken=False,
            lease=None,
            checkpoint_reconciled=True,
            xdg_state_repaired=False,
            recommended_action="restart",
        ),
    )
    controller = build_controller(tmp_path, recovery_service=recovery, event_store=store)

    result = controller.handle_command("/resume")

    assert result.ok is True
    assert recovery.resume_calls == [("run-root", "read")]
    assert [entry.event_type for entry in controller.event_entries] == [
        "run.created",
        "run.started",
    ]
    assert "/restart" in result.message


@pytest.mark.parametrize("command", ["/resume", "/retry", "/restart"])
def test_commands_reject_when_recovery_service_is_missing(
    tmp_path: Path,
    command: str,
) -> None:
    controller = build_controller(tmp_path)

    result = controller.handle_command(command)

    assert result.ok is False
    assert result.message == "Recovery service is not configured."


def test_replace_command_rejects_when_recovery_service_is_missing(tmp_path: Path) -> None:
    child_run = make_run(
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Child task",
        status="failed",
        stage_ids=[],
        codex_session_ref=None,
    )
    controller = build_controller(tmp_path, child_runs=[child_run])
    controller.select_node("run:run-child-1")

    result = controller.handle_command("/replace")

    assert result.ok is False
    assert result.message == "Recovery service is not configured."


def test_retry_command_uses_recovery_service_for_selected_run(tmp_path: Path) -> None:
    recovery = FakeRecoveryService(result=make_resume_result())
    controller = build_controller(tmp_path, recovery_service=recovery)

    result = controller.handle_command("/retry")

    assert result.ok is True
    assert recovery.retry_calls == ["run-root"]
    assert controller.selected_node_id == "run:run-root"
    assert "moved back to pending" in result.message


def test_restart_command_uses_recovery_service_for_selected_run(tmp_path: Path) -> None:
    recovery = FakeRecoveryService(result=make_resume_result())
    controller = build_controller(tmp_path, recovery_service=recovery)

    result = controller.handle_command("/restart")

    assert result.ok is True
    assert recovery.restart_calls == ["run-root"]
    assert controller.selected_node_id == "run:run-root"
    assert "Restarted run-root" in result.message


def test_replace_command_creates_replacement_for_selected_child_run(tmp_path: Path) -> None:
    recovery = FakeRecoveryService(result=make_resume_result())
    child_run = make_run(
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Child task",
        status="failed",
        stage_ids=[],
        codex_session_ref=None,
    )
    controller = build_controller(
        tmp_path,
        child_runs=[child_run],
        recovery_service=recovery,
    )
    controller.select_node("run:run-child-1")

    result = controller.handle_command("/replace")

    assert result.ok is True
    assert recovery.replace_calls == ["run-child-1"]
    assert controller.selected_node_id == "run:run-child-1-replacement-1"
    assert "Created replacement run run-child-1-replacement-1" in result.message


def test_abort_command_marks_selected_run_aborted(tmp_path: Path) -> None:
    child_run = make_run(
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Child task",
        status="running",
    )
    controller = build_controller(tmp_path, child_runs=[child_run])
    controller.select_node("run:run-child-1")

    result = controller.handle_command("/abort")

    assert result.ok is True
    assert controller.engine.run("run-child-1").status == "aborted"
    assert controller.selected_node_id == "run:run-child-1"
    assert "Aborted run-child-1" in result.message


def build_controller(
    repo_root: Path,
    *,
    bundles: list[ExecutionBundle] | None = None,
    child_runs: list[Run] | None = None,
    stages: list[Stage] | None = None,
    recovery_service: FakeRecoveryService | None = None,
    event_store: EventStore | None = None,
):
    from ralphception.ui.app import DashboardController

    config_file = repo_root / ".ralphception" / "config.toml"
    if not config_file.exists():
        write_config_atomically(config_file, DEFAULT_CONFIG)

    root_run = make_run()
    workflow_engine = WorkflowEngine(
        repo_root=repo_root,
        root_run=root_run,
        child_runs=child_runs or [],
        stages=stages
        or [
            make_stage(stage_kind="intake", status="completed"),
            make_stage(stage_kind="plan", status="pending"),
            make_stage(stage_kind="execute", status="pending"),
        ],
        bundles=bundles or [make_bundle()],
    )
    return DashboardController(
        repo_root=repo_root,
        engine=workflow_engine,
        recovery_service=recovery_service,
        event_store=event_store,
    )


class FakeRecoveryService:
    def __init__(self, *, result: ResumeResult) -> None:
        self.result = result
        self.resume_calls: list[tuple[str, str]] = []
        self.retry_calls: list[str] = []
        self.restart_calls: list[str] = []
        self.replace_calls: list[str] = []

    def resume(self, *, run_id: str, mode: Literal["read", "repair"]) -> ResumeResult:
        self.resume_calls.append((run_id, mode))
        return self.result

    def retry_run(self, run_id: str) -> Run:
        self.retry_calls.append(run_id)
        return make_run(run_id=run_id, status="pending")

    def restart_run(self, run_id: str) -> Run:
        self.restart_calls.append(run_id)
        return make_run(run_id=run_id, status="running")

    def replace_run(self, run_id: str) -> Run:
        self.replace_calls.append(run_id)
        return Run.model_validate(
            {
                **make_run(
                    run_id=f"{run_id}-replacement-1",
                    parent_run_id="run-root",
                    supersedes_run_id=run_id,
                    goal=f"Replacement for {run_id}",
                    status="pending",
                    stage_ids=[],
                    codex_session_ref=None,
                ).model_dump(mode="python"),
            },
        )


def make_run(
    *,
    run_id: str = "run-root",
    parent_run_id: str | None = None,
    supersedes_run_id: str | None = None,
    goal: str = "Ship the textual dashboard",
    status: RunStageStatus = "running",
    stage_ids: list[str] | None = None,
    codex_session_ref: ChildSessionRef | None | Literal["default"] = "default",
) -> Run:
    now = datetime(2026, 3, 15, 12, 0, tzinfo=timezone.utc)
    return Run(
        run_id=run_id,
        parent_run_id=parent_run_id,
        supersedes_run_id=supersedes_run_id,
        goal=goal,
        status=status,
        stage_ids=["stage-intake", "stage-plan", "stage-execute"] if stage_ids is None else stage_ids,
        config_snapshot={"codex": {"model": DEFAULT_CONFIG.codex.model}},
        codex_session_ref=make_session_ref(run_id=run_id)
        if codex_session_ref == "default"
        else codex_session_ref,
        artifact_refs=[make_artifact_ref()],
        created_at=now,
        updated_at=now,
    )


def make_stage(*, stage_kind: StageKind, status: RunStageStatus) -> Stage:
    now = datetime(2026, 3, 15, 12, 0, tzinfo=timezone.utc)
    started_at = None if status in {"pending", "awaiting_approval"} else now
    completed_at = now if status == "completed" else None
    return Stage(
        stage_id=f"stage-{stage_kind}",
        run_id="run-root",
        stage_kind=stage_kind,
        status=status,
        task_ids=[],
        started_at=started_at,
        completed_at=completed_at,
    )


def make_bundle(
    *,
    bundle_id: str = "bundle-1",
    bundle_version: int = 1,
    state: ExecutionBundleState = "draft",
) -> ExecutionBundle:
    return ExecutionBundle(
        bundle_id=bundle_id,
        run_id="run-root",
        bundle_version=bundle_version,
        state=state,
        artifact_refs=[make_artifact_ref()],
        base_bundle_id=None,
        scope_hash="sha256:bundle",
        created_at=datetime(2026, 3, 15, 12, 0, tzinfo=timezone.utc),
        assigned_run_ids=[],
    )


def make_artifact_ref() -> ArtifactRef:
    return ArtifactRef(
        artifact_kind="spec",
        artifact_path="docs/spec.md",
        artifact_version=1,
        content_hash="sha256:artifact",
    )


def make_session_ref(*, run_id: str = "run-root") -> ChildSessionRef:
    return ChildSessionRef(
        run_id=run_id,
        codex_thread_id="thread-1",
        codex_session_id="session-1",
        workspace_path="/repo",
        resumable=True,
        last_seen_at=datetime(2026, 3, 15, 12, 0, tzinfo=timezone.utc),
    )


def make_resume_result() -> ResumeResult:
    return ResumeResult(
        run_id="run-root",
        mode="read",
        lease_taken=False,
        lease=None,
        checkpoint_reconciled=True,
        xdg_state_repaired=False,
        recommended_action="restart",
    )
