from datetime import datetime, timezone
from typing import Any, cast

import pytest
from pydantic import ValidationError

from ralphception.models.session import AgentRef, ChildSessionRef, SessionFailureKind


def test_child_session_ref_captures_resumable_session_metadata() -> None:
    session_ref = ChildSessionRef(
        run_id="run-child-1",
        codex_thread_id="thread-1",
        codex_session_id="session-1",
        workspace_path="/repo/.worktrees/child-1",
        resumable=True,
        last_seen_at=utc_now(),
    )

    assert session_ref.resumable is True
    assert session_ref.workspace_path.endswith("child-1")


def test_agent_ref_requires_session_reference_and_valid_status() -> None:
    session_ref = ChildSessionRef(
        run_id="run-child-1",
        codex_thread_id="thread-1",
        codex_session_id="session-1",
        workspace_path="/repo/.worktrees/child-1",
        resumable=True,
        last_seen_at=utc_now(),
    )

    agent = AgentRef(
        agent_id="agent-1",
        parent_run_id="run-1",
        parent_task_id="task-1",
        codex_session_ref=session_ref,
        goal="Summarize failing tests",
        status="running",
        created_at=utc_now(),
        updated_at=utc_now(),
    )

    assert agent.status == "running"
    assert agent.codex_session_ref == session_ref

    with pytest.raises(ValidationError):
        AgentRef(
            agent_id="agent-2",
            parent_run_id="run-1",
            parent_task_id="task-1",
            codex_session_ref=cast(Any, None),
            goal="Summarize failing tests",
            status="running",
            created_at=utc_now(),
            updated_at=utc_now(),
        )

    with pytest.raises(ValidationError):
        AgentRef(
            agent_id="agent-3",
            parent_run_id="run-1",
            parent_task_id="task-1",
            codex_session_ref=session_ref,
            goal="Summarize failing tests",
            status=cast(Any, "done"),
            created_at=utc_now(),
            updated_at=utc_now(),
        )


def test_session_failure_kind_exposes_canonical_normalized_values() -> None:
    assert {failure_kind.value for failure_kind in SessionFailureKind} == {
        "startup_failed",
        "session_expired",
        "transport_error",
        "protocol_error",
        "model_unavailable",
    }

    assert SessionFailureKind.STARTUP_FAILED.value == "startup_failed"


def utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
