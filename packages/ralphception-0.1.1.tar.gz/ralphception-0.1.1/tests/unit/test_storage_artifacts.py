from pathlib import Path

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.worktree import WorktreeHandoff
from ralphception.storage.artifacts import promote_child_scoped_artifacts, promoted_artifact_refs


def test_promoted_artifact_refs_include_code_and_child_scoped_outputs() -> None:
    handoff = make_handoff(
        artifact_refs=[
            artifact_ref("src/parser.py", "code"),
            artifact_ref(".ralphception/runs/run-child-1/summary.md", "summary"),
            artifact_ref(".ralphception/specs/runtime.md", "spec"),
        ],
        verification_artifact_refs=[
            artifact_ref(".ralphception/runs/run-child-1/verify.json", "verification"),
        ],
    )

    promoted = promoted_artifact_refs(
        handoff=handoff,
        stripped_paths=[
            ".ralphception/runs/run-child-1/summary.md",
            ".ralphception/runs/run-child-1/verify.json",
            ".ralphception/specs/runtime.md",
        ],
    )

    assert promoted == [
        artifact_ref("src/parser.py", "code"),
        artifact_ref(".ralphception/runs/run-child-1/summary.md", "summary"),
        artifact_ref(".ralphception/runs/run-child-1/verify.json", "verification"),
    ]


def test_promote_child_scoped_artifacts_writes_declared_stripped_outputs_only(tmp_path: Path) -> None:
    handoff = make_handoff(
        artifact_refs=[artifact_ref(".ralphception/runs/run-child-1/summary.md", "summary")],
        verification_artifact_refs=[],
    )
    loaded_paths: list[str] = []

    written_paths = promote_child_scoped_artifacts(
        destination_root=tmp_path,
        handoff=handoff,
        stripped_paths=[
            ".ralphception/runs/run-child-1/summary.md",
            ".ralphception/runs/run-child-1/extra.md",
        ],
        load_artifact_bytes=lambda artifact_path: _load_bytes(artifact_path, loaded_paths),
    )

    summary_path = tmp_path / ".ralphception" / "runs" / "run-child-1" / "summary.md"
    extra_path = tmp_path / ".ralphception" / "runs" / "run-child-1" / "extra.md"

    assert loaded_paths == [".ralphception/runs/run-child-1/summary.md"]
    assert written_paths == [summary_path]
    assert summary_path.read_text(encoding="utf-8") == "artifact:.ralphception/runs/run-child-1/summary.md"
    assert not extra_path.exists()


def _load_bytes(artifact_path: str, loaded_paths: list[str]) -> bytes:
    loaded_paths.append(artifact_path)
    return f"artifact:{artifact_path}".encode("utf-8")


def make_handoff(
    *,
    artifact_refs: list[ArtifactRef],
    verification_artifact_refs: list[ArtifactRef],
) -> WorktreeHandoff:
    return WorktreeHandoff(
        child_run_id="run-child-1",
        worktree_path="/tmp/run-child-1",
        branch_name="codex/run-child-1",
        base_branch="main",
        head_commit="abc1234",
        goal="Implement parser",
        artifact_refs=artifact_refs,
        verification_artifact_refs=verification_artifact_refs,
        consumed_bundle_version=2,
        touched_paths=["src/parser.py"],
        verification_summary="tests passed",
        merge_readiness="ready",
        cleanup_state="pending",
    )


def artifact_ref(path: str, kind: str) -> ArtifactRef:
    return ArtifactRef(
        artifact_kind=kind,
        artifact_path=path,
        artifact_version=1,
        content_hash=f"sha256:{path}",
    )
