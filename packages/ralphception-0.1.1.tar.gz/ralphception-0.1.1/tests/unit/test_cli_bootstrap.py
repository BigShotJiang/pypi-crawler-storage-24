from pathlib import Path
from unittest.mock import patch

import ralphception.app as runtime_app
from typer.testing import CliRunner

from ralphception.cli import app
from ralphception.runtime.supervisor import (
    RuntimeBackendUnavailableError,
    RuntimeLaunchAbortedError,
    RuntimePromptConflictError,
    RuntimeResumeRequiredError,
    RuntimeResumeUnavailableError,
)
from ralphception.workflow.recovery import ResumeResult


def test_cli_help_exposes_primary_commands() -> None:
    result = CliRunner().invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "resume" in result.stdout
    assert "terminal" in result.stdout
    assert "headless" in result.stdout


def test_cli_without_subcommand_runs_app() -> None:
    with patch.object(runtime_app, "run_app") as run_app:
        result = CliRunner().invoke(app, [])

    assert result.exit_code == 0
    run_app.assert_called_once_with()


def test_cli_resume_defaults_to_read_mode() -> None:
    with patch.object(
        runtime_app,
        "resume_app",
        return_value=ResumeResult(
            run_id="run-root",
            mode="read",
            lease_taken=False,
            lease=None,
            checkpoint_reconciled=True,
            xdg_state_repaired=False,
            recommended_action=None,
        ),
    ) as resume_app:
        result = CliRunner().invoke(app, ["resume"])

    assert result.exit_code == 0
    resume_app.assert_called_once_with(mode="read")
    assert "Resumed run-root in read mode." in result.stdout


def test_cli_resume_accepts_repair_mode() -> None:
    with patch.object(
        runtime_app,
        "resume_app",
        return_value=ResumeResult(
            run_id="run-root",
            mode="repair",
            lease_taken=True,
            lease=None,
            checkpoint_reconciled=False,
            xdg_state_repaired=True,
            recommended_action="restart",
        ),
    ) as resume_app:
        result = CliRunner().invoke(app, ["resume", "repair"])

    assert result.exit_code == 0
    resume_app.assert_called_once_with(mode="repair")
    assert "Resumed run-root in repair mode." in result.stdout
    assert "Next action: /restart." in result.stdout


def test_cli_headless_passes_options_through_to_runtime() -> None:
    fake_result = object()
    with patch.object(runtime_app, "run_headless", return_value=fake_result) as run_headless, patch.object(
        runtime_app,
        "_render_headless_result",
        return_value="Headless run completed.",
    ) as render_headless:
        result = CliRunner().invoke(
            app,
            [
                "headless",
                "--seed-prompt",
                "port parser",
                "--source-repo",
                "/tmp/source",
                "--approve-all",
                "--approver",
                "automation",
                "--fake-session-manager",
            ],
        )

    assert result.exit_code == 0
    run_headless.assert_called_once_with(
        repo_root=None,
        seed_prompt="port parser",
        source_repos=("/tmp/source",),
        approve_all=True,
        approver="automation",
        use_fake_session_manager=True,
    )
    render_headless.assert_called_once_with(fake_result)
    assert "Headless run completed." in result.stdout


def test_cli_terminal_runs_shared_supervisor() -> None:
    fake_result = object()
    with patch.object(runtime_app, "run_terminal", return_value=fake_result) as run_terminal, patch.object(
        runtime_app,
        "_render_terminal_result",
        return_value="Runtime: running",
    ) as render_terminal:
        result = CliRunner().invoke(
            app,
            ["terminal", "--seed-prompt", "port parser"],
        )

    assert result.exit_code == 0
    run_terminal.assert_called_once_with(
        repo_root=None,
        seed_prompt="port parser",
        source_repos=(),
        resume=False,
        approve_all=False,
        approver="terminal",
        use_fake_session_manager=False,
    )
    render_terminal.assert_called_once_with(fake_result)
    assert "Runtime: running" in result.stdout


def test_cli_terminal_reports_seed_prompt_conflict_cleanly() -> None:
    with patch.object(
        runtime_app,
        "run_terminal",
        side_effect=RuntimePromptConflictError(
            repo_root=Path("/tmp/repo"),
            existing_seed_prompt="existing mission",
            requested_seed_prompt="find any bugs",
        ),
    ):
        result = CliRunner().invoke(
            app,
            ["terminal", "--seed-prompt", "find any bugs"],
        )

    assert result.exit_code == 1
    assert "existing mission" in result.stdout


def test_cli_terminal_passes_resume_flag_through_to_runtime() -> None:
    fake_result = object()
    with patch.object(runtime_app, "run_terminal", return_value=fake_result) as run_terminal, patch.object(
        runtime_app,
        "_render_terminal_result",
        return_value="Runtime: running",
    ):
        result = CliRunner().invoke(
            app,
            ["terminal", "--resume"],
        )

    assert result.exit_code == 0
    run_terminal.assert_called_once_with(
        repo_root=None,
        seed_prompt=None,
        source_repos=(),
        resume=True,
        approve_all=False,
        approver="terminal",
        use_fake_session_manager=False,
    )


def test_cli_terminal_reports_resume_required_cleanly() -> None:
    with patch.object(
        runtime_app,
        "run_terminal",
        side_effect=RuntimeResumeRequiredError(
            repo_root=Path("/tmp/repo"),
            run_id="run-root",
            seed_prompt="find any bugs",
            run_status="failed",
            current_stage="execute",
        ),
    ):
        result = CliRunner().invoke(
            app,
            ["terminal", "--seed-prompt", "find any bugs"],
        )

    assert result.exit_code == 1
    assert "Use --resume to attach" in result.stdout


def test_cli_terminal_reports_missing_resume_target_cleanly() -> None:
    with patch.object(
        runtime_app,
        "run_terminal",
        side_effect=RuntimeResumeUnavailableError(repo_root=Path("/tmp/repo")),
    ):
        result = CliRunner().invoke(
            app,
            ["terminal", "--resume"],
        )

    assert result.exit_code == 1
    assert "no existing mission to resume" in result.stdout


def test_cli_terminal_reports_launch_abort_cleanly() -> None:
    with patch.object(
        runtime_app,
        "run_terminal",
        side_effect=RuntimeLaunchAbortedError("Launch aborted."),
    ):
        result = CliRunner().invoke(
            app,
            ["terminal", "--seed-prompt", "find any bugs"],
        )

    assert result.exit_code == 1
    assert "Launch aborted." in result.stdout


def test_cli_terminal_reports_backend_unavailable_cleanly() -> None:
    with patch.object(
        runtime_app,
        "run_terminal",
        side_effect=RuntimeBackendUnavailableError(),
    ):
        result = CliRunner().invoke(
            app,
            ["terminal", "--seed-prompt", "find any bugs"],
        )

    assert result.exit_code == 1
    assert "No Codex session backend" in result.stdout


def test_cli_headless_reports_backend_unavailable_cleanly() -> None:
    with patch.object(
        runtime_app,
        "run_headless",
        side_effect=RuntimeBackendUnavailableError(),
    ):
        result = CliRunner().invoke(
            app,
            ["headless", "--seed-prompt", "find any bugs"],
        )

    assert result.exit_code == 1
    assert "No Codex session backend" in result.stdout
