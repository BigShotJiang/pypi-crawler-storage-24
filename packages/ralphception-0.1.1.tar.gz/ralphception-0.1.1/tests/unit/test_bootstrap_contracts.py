from pathlib import Path
from datetime import datetime, timezone
from typing import Any, cast

import pytest
from pydantic import ValidationError

from ralphception.bootstrap.contracts import (
    BootstrapApprovalRequest,
    BootstrapFinding,
    BootstrapGapLedger,
    BootstrapInputs,
    make_plan_item_ref,
    slugify_heading,
)


def test_slugify_heading_matches_spec_rule() -> None:
    assert (
        slugify_heading("### Task 14: Implement startup flow, first-run bootstrap, and artifact review screens")
        == "task-14-implement-startup-flow-first-run-bootstrap-and-artifact-review-screens"
    )


def test_make_plan_item_ref_uses_sha1_of_normalized_checkbox_text() -> None:
    ref = make_plan_item_ref(
        plan_path=Path("docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"),
        heading="### Task 14: Implement startup flow, first-run bootstrap, and artifact review screens",
        checkbox_text="- [ ] **Step 3: Implement startup and review flow**",
    )
    assert (
        ref
        == "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
        "#task-14-implement-startup-flow-first-run-bootstrap-and-artifact-review-screens/"
        "59a3096afd6833963d77087065353060024bb6e7"
    )


def test_bootstrap_finding_rejects_non_runtime_status_values() -> None:
    with pytest.raises(ValidationError):
        BootstrapFinding(
            gap_id="bootstrap-cli-resume",
            title="Resume CLI gap",
            severity="P1",
            bootstrap_kind="ux_gap",
            audit_kind="feature_gap",
            status=cast(Any, "closed"),
            rationale=None,
            evidence_paths=["src/ralphception/cli.py"],
            plan_item_refs=[],
        )


def test_bootstrap_finding_requires_rationale_when_plan_item_refs_are_empty() -> None:
    with pytest.raises(ValidationError):
        BootstrapFinding(
            gap_id="bootstrap-storage-artifacts-module",
            title="Storage-plan gap",
            severity="P2",
            bootstrap_kind="implementation_gap",
            audit_kind="feature_gap",
            status="open",
            rationale=None,
            evidence_paths=["src/ralphception/storage/artifacts.py"],
            plan_item_refs=[],
        )


def test_bootstrap_gap_ledger_rejects_duplicate_gap_ids() -> None:
    finding = BootstrapFinding(
        gap_id="bootstrap-cli-resume",
        title="Resume CLI gap",
        severity="P1",
        bootstrap_kind="ux_gap",
        audit_kind="feature_gap",
        status="open",
        rationale="Tracks the same unresolved finding twice for validation coverage.",
        evidence_paths=["src/ralphception/cli.py"],
        plan_item_refs=[
            "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
            "#task-1-create-the-python-project-scaffold/007b80da0ec5a5f6d0faf362d046c17b19189f1f"
        ],
    )

    with pytest.raises(ValidationError):
        BootstrapGapLedger(
            updated_at=utc_now(),
            authoritative_plan_path="docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md",
            findings=[finding, finding],
        )


def test_bootstrap_approval_request_requires_waiver_fields_for_finding_waiver() -> None:
    with pytest.raises(ValidationError):
        BootstrapApprovalRequest(
            approval_kind="finding_waiver",
            run_id="run-bootstrap-1",
            artifact_paths=[],
            bundle_id=None,
            bundle_version=None,
            scope_hash=None,
            waived_finding_ids=None,
            rationale=None,
            requested_at=utc_now(),
        )


def test_bootstrap_approval_request_rejects_waiver_fields_for_non_waiver_requests() -> None:
    with pytest.raises(ValidationError):
        BootstrapApprovalRequest(
            approval_kind="spec_review",
            run_id="run-bootstrap-1",
            artifact_paths=["docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md"],
            bundle_id="bundle-1",
            bundle_version=1,
            scope_hash="sha256:scope",
            waived_finding_ids=["bootstrap-cli-resume"],
            rationale="waiver state should not be present",
            requested_at=utc_now(),
        )


def test_inputs_default_to_schema_version_one_and_repo_globs() -> None:
    inputs = BootstrapInputs.default()

    assert inputs.schema_version == 1
    assert inputs.authoritative_spec_paths == [
        "docs/superpowers/specs/2026-03-15-ralphception-design.md",
        "docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md",
    ]
    assert inputs.authoritative_plan_path == "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
    assert inputs.authoritative_readme_paths == ["README.md"]
    assert inputs.authoritative_code_globs == ["src/ralphception/**"]
    assert inputs.authoritative_test_globs == ["tests/unit/**", "tests/integration/**", "tests/e2e/**"]
    assert inputs.notes == []
    assert inputs.updated_at is not None


def utc_now() -> datetime:
    return datetime.now(timezone.utc)
