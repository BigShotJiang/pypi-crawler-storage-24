import hashlib
import subprocess
from dataclasses import replace
from pathlib import Path
from typing import TypedDict

import pytest

from ralphception.config import (
    DEFAULT_CONFIG,
    load_config,
    write_config_atomically,
    write_default_config,
)
from ralphception.paths import (
    resolve_repo_root,
    resolve_workspace_identity_root,
    resolve_xdg_state_home,
    workspace_state_dir,
)


class ConfigDocumentOverrides(TypedDict, total=False):
    sandbox: str
    approval_policy: str
    max_parallel_children: int | str
    command_timeout_seconds: int | str


SEMANTIC_VALUE_CASES: tuple[tuple[ConfigDocumentOverrides, str], ...] = (
    ({"max_parallel_children": -1}, "execution.max_parallel_children"),
    ({"command_timeout_seconds": 0}, "verification.command_timeout_seconds"),
    ({"sandbox": '"unsafe-custom"'}, "codex.sandbox"),
    ({"approval_policy": '"sometimes"'}, "codex.approval_policy"),
)


def test_default_config_contains_required_sections(tmp_path: Path) -> None:
    config = write_default_config(tmp_path)

    assert config.codex.model == "gpt-5.4"
    assert config.verification.command_timeout_seconds == 1800
    assert config.ui.mouse is True
    assert (tmp_path / ".ralphception" / "config.toml").exists()


def test_write_config_is_atomic(tmp_path: Path) -> None:
    config_path = tmp_path / ".ralphception" / "config.toml"
    write_config_atomically(config_path, DEFAULT_CONFIG)
    assert config_path.exists()
    assert ".tmp" not in "".join(path.name for path in config_path.parent.iterdir())


def test_config_strings_with_embedded_newlines_round_trip(tmp_path: Path) -> None:
    config_path = tmp_path / ".ralphception" / "config.toml"
    config = replace(
        DEFAULT_CONFIG,
        codex=replace(DEFAULT_CONFIG.codex, model="gpt-5\npreview"),
    )

    write_config_atomically(config_path, config)
    result = load_config(config_path)

    assert result.is_error is False
    assert result.config == config


def test_invalid_config_is_preserved_and_reported(tmp_path: Path) -> None:
    config_path = tmp_path / ".ralphception" / "config.toml"
    config_path.parent.mkdir(parents=True)
    config_path.write_text("[codex\nmodel='broken'\n", encoding="utf-8")

    result = load_config(config_path)

    assert result.is_error is True
    assert result.diagnostic is not None
    assert config_path.exists()


def test_non_utf8_config_is_preserved_and_reported(tmp_path: Path) -> None:
    config_path = tmp_path / ".ralphception" / "config.toml"
    config_path.parent.mkdir(parents=True)
    config_path.write_bytes(b"\xff\xfe[codex]\nmodel='broken'\n")

    result = load_config(config_path)

    assert result.is_error is True
    assert result.diagnostic is not None
    assert config_path.exists()


def test_invalid_config_value_types_are_reported(tmp_path: Path) -> None:
    config_path = tmp_path / ".ralphception" / "config.toml"
    config_path.parent.mkdir(parents=True)
    write_config_document(
        config_path,
        command_timeout_seconds='"1800"',
    )

    result = load_config(config_path)

    assert result.is_error is True
    assert result.diagnostic is not None
    assert config_path.exists()


@pytest.mark.parametrize(
    ("field_overrides", "expected_fragment"),
    SEMANTIC_VALUE_CASES,
)
def test_invalid_config_semantic_values_are_reported(
    tmp_path: Path,
    field_overrides: ConfigDocumentOverrides,
    expected_fragment: str,
) -> None:
    config_path = tmp_path / ".ralphception" / "config.toml"
    config_path.parent.mkdir(parents=True)
    write_config_document(config_path, **field_overrides)

    result = load_config(config_path)

    assert result.is_error is True
    assert result.diagnostic is not None
    assert expected_fragment in result.diagnostic
    assert config_path.exists()


def test_resolve_repo_root_uses_git_top_level(tmp_path: Path) -> None:
    repo_path = make_git_repo(tmp_path)
    nested_path = repo_path / "src" / "ralphception"
    nested_path.mkdir(parents=True)

    assert resolve_repo_root(nested_path) == repo_path.resolve()


def test_workspace_state_dir_hashes_canonical_repo_root(tmp_path: Path) -> None:
    repo_path = make_git_repo(tmp_path)
    nested_path = repo_path / "tests" / "unit"
    nested_path.mkdir(parents=True)
    xdg_state_home = tmp_path / "xdg-state"

    expected_hash = hashlib.sha256(
        str(repo_path.resolve()).encode("utf-8"),
    ).hexdigest()

    assert workspace_state_dir(nested_path, xdg_state_home=xdg_state_home) == (
        xdg_state_home / "ralphception" / expected_hash
    )


def test_relative_xdg_state_home_env_is_ignored(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    mocked_home = tmp_path / "home"
    mocked_home.mkdir()
    monkeypatch.setenv("HOME", str(mocked_home))
    monkeypatch.setenv("XDG_STATE_HOME", "relative-state")

    assert resolve_xdg_state_home() == mocked_home / ".local" / "state"


def test_tilde_xdg_state_home_env_is_ignored(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    mocked_home = tmp_path / "home"
    mocked_home.mkdir()
    monkeypatch.setenv("HOME", str(mocked_home))
    monkeypatch.setenv("XDG_STATE_HOME", "~/state")

    assert resolve_xdg_state_home() == mocked_home / ".local" / "state"


def test_workspace_state_dir_uses_shared_repo_identity_for_git_worktrees(
    tmp_path: Path,
) -> None:
    repo_path = make_git_repo(tmp_path, with_commit=True)
    worktree_path = tmp_path / "linked-worktree"
    subprocess.run(
        [
            "git",
            "worktree",
            "add",
            "-b",
            "feature/task-2-config-fixes",
            str(worktree_path),
        ],
        check=True,
        cwd=repo_path,
        capture_output=True,
        text=True,
    )
    nested_path = worktree_path / "src" / "ralphception"
    nested_path.mkdir(parents=True)
    xdg_state_home = tmp_path / "xdg-state"
    expected_dir = xdg_state_home / "ralphception" / hashlib.sha256(
        str(repo_path.resolve()).encode("utf-8"),
    ).hexdigest()

    assert workspace_state_dir(repo_path, xdg_state_home=xdg_state_home) == expected_dir
    assert workspace_state_dir(nested_path, xdg_state_home=xdg_state_home) == expected_dir


def test_separate_git_dir_worktrees_share_workspace_identity(tmp_path: Path) -> None:
    repo_path, shared_git_dir = make_separate_git_dir_repo(tmp_path)
    worktree_path = tmp_path / "separate-linked-worktree"
    subprocess.run(
        [
            "git",
            "worktree",
            "add",
            "-b",
            "feature/task-2-separate-git-dir",
            str(worktree_path),
        ],
        check=True,
        cwd=repo_path,
        capture_output=True,
        text=True,
    )
    nested_path = worktree_path / "src" / "ralphception"
    nested_path.mkdir(parents=True)
    xdg_state_home = tmp_path / "xdg-state"
    expected_dir = xdg_state_home / "ralphception" / hashlib.sha256(
        str(shared_git_dir.resolve()).encode("utf-8"),
    ).hexdigest()

    assert resolve_workspace_identity_root(repo_path) == shared_git_dir.resolve()
    assert resolve_workspace_identity_root(nested_path) == shared_git_dir.resolve()
    assert workspace_state_dir(repo_path, xdg_state_home=xdg_state_home) == expected_dir
    assert workspace_state_dir(nested_path, xdg_state_home=xdg_state_home) == expected_dir


def make_git_repo(tmp_path: Path, *, with_commit: bool = False) -> Path:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    subprocess.run(
        ["git", "init"],
        check=True,
        cwd=repo_path,
        capture_output=True,
        text=True,
    )
    if with_commit:
        (repo_path / "README.md").write_text("repo\n", encoding="utf-8")
        subprocess.run(
            ["git", "add", "README.md"],
            check=True,
            cwd=repo_path,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            [
                "git",
                "-c",
                "commit.gpgsign=false",
                "-c",
                "user.name=Test User",
                "-c",
                "user.email=test@example.com",
                "commit",
                "-m",
                "init",
            ],
            check=True,
            cwd=repo_path,
            capture_output=True,
            text=True,
        )
    return repo_path


def make_separate_git_dir_repo(tmp_path: Path) -> tuple[Path, Path]:
    repo_path = tmp_path / "separate-git-repo"
    shared_git_dir = tmp_path / "shared.git"
    subprocess.run(
        ["git", "init", "--separate-git-dir", str(shared_git_dir), str(repo_path)],
        check=True,
        capture_output=True,
        text=True,
    )
    (repo_path / "README.md").write_text("repo\n", encoding="utf-8")
    subprocess.run(
        ["git", "add", "README.md"],
        check=True,
        cwd=repo_path,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        [
            "git",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-m",
            "init",
        ],
        check=True,
        cwd=repo_path,
        capture_output=True,
        text=True,
    )
    return repo_path, shared_git_dir


def write_config_document(
    config_path: Path,
    *,
    sandbox: str = '"danger-full-access"',
    approval_policy: str = '"never"',
    max_parallel_children: int | str = 4,
    command_timeout_seconds: int | str = 1800,
) -> None:
    config_path.write_text(
        f"""
[codex]
model = "gpt-5.4"
reasoning = "high"
latency_profile = "fast"
sandbox = {sandbox}
approval_policy = {approval_policy}

[execution]
use_worktrees_for_edit_runs = true
max_parallel_children = {max_parallel_children}
audit_reopen_priorities = ["P0", "P1", "P2"]

[verification]
command_timeout_seconds = {command_timeout_seconds}

[ui]
show_event_timestamps = true
mouse = true
""".strip(),
        encoding="utf-8",
    )
