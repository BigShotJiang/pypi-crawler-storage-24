from __future__ import annotations

from pathlib import Path

from ralphception.models.commit_intents import CommitIntent
from ralphception.models.mission import MissionSession
from ralphception.models.todos import TodoNode
from ralphception.storage.mission_store import MissionStore


def test_mission_store_round_trips_todo_graph(tmp_path: Path) -> None:
    store = MissionStore(tmp_path)
    todo = TodoNode(
        todo_id="todo-1",
        title="Add scheduler",
        dependency_ids=[],
        status="ready",
        commit_intent_id="intent-1",
        scope_hints=["src/ralphception/actor_runtime/scheduler_actor.py"],
    )

    store.write_todos([todo])

    assert store.read_todos() == [todo]


def test_mission_store_round_trips_session_and_commit_intents(tmp_path: Path) -> None:
    store = MissionStore(tmp_path)
    session = MissionSession(
        mission_id="mission-1",
        repo_root=str(tmp_path),
        phase="planning",
        approved_spec_version=1,
    )
    intent = CommitIntent(
        intent_id="intent-1",
        message="feat: add scheduler",
        todo_ids=["todo-1"],
        ordering_after=[],
    )

    store.write_session(session)
    store.write_commit_intents([intent])

    assert store.read_session() == session
    assert store.read_commit_intents() == [intent]
