import json
from datetime import datetime, timezone
from pathlib import Path
from typing import NotRequired, TypedDict

import pytest

from ralphception.models.events import Event
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventLogCorruptionError, EventStore


class RunEventKwargs(TypedDict):
    event_id: str
    run_id: str
    event_type: str
    sequence: int | None
    occurred_at: NotRequired[datetime]
    source: str
    payload: dict[str, str | None]


def test_event_store_append_treats_identical_duplicate_event_id_as_idempotent_retry(tmp_path) -> None:
    store = EventStore(tmp_path)

    first = store.append(**run_event_kwargs(event_id="event-1", run_id="run-1"))
    duplicate = store.append(**run_event_kwargs(event_id="event-1", run_id="run-1"))
    events = store.read_run("run-1")

    assert (tmp_path / ".ralphception" / "events" / "run-1.jsonl").is_file()
    assert duplicate == first
    assert events == [first]


def test_event_store_append_rejects_conflicting_duplicate_event_id(tmp_path) -> None:
    store = EventStore(tmp_path)

    store.append(**run_event_kwargs(event_id="event-1", run_id="run-1"))

    with pytest.raises(EventLogCorruptionError, match="conflicting duplicate event_id"):
        store.append(
            **run_event_kwargs(
                event_id="event-1",
                run_id="run-1",
                event_type="run.started",
            ),
        )


def test_event_store_append_treats_duplicate_without_occurred_at_as_idempotent_retry(tmp_path) -> None:
    store = EventStore(tmp_path)

    first = store.append(**run_event_kwargs(event_id="event-1", run_id="run-1"))
    duplicate = store.append(
        **run_event_kwargs(
            event_id="event-1",
            run_id="run-1",
            include_occurred_at=False,
        ),
    )

    assert duplicate == first


def test_event_store_appends_and_reads_events_in_sequence_order(tmp_path) -> None:
    store = EventStore(tmp_path)

    first = store.append(**run_event_kwargs(event_id="event-1", run_id="run-1"))
    second = store.append(
        **run_event_kwargs(
            event_id="event-2",
            run_id="run-1",
            event_type="run.started",
        ),
    )

    events = store.read_run("run-1")

    assert isinstance(events[0], Event)
    assert [event.event_id for event in events] == ["event-1", "event-2"]
    assert [event.sequence for event in events] == [1, 2]
    assert list(store.replay_run("run-1")) == [first, second]


def test_event_store_append_fsyncs_log_before_return(tmp_path, monkeypatch) -> None:
    store = EventStore(tmp_path)
    fsync_calls: list[int] = []

    def record_fsync(fd: int) -> None:
        fsync_calls.append(fd)

    monkeypatch.setattr("os.fsync", record_fsync)

    event = store.append(**run_event_kwargs(event_id="event-1", run_id="run-1"))

    assert event.sequence == 1
    assert len(fsync_calls) >= 2


def test_event_store_append_allocates_sequence_from_raw_log_tail_not_deduped_view(tmp_path) -> None:
    first = build_event(event_id="event-1", run_id="run-1", sequence=1)
    duplicate = build_event(event_id="event-1", run_id="run-1", sequence=2)
    write_raw_events(tmp_path, "run-1", [first, duplicate])

    store = EventStore(tmp_path)
    appended = store.append(
        **run_event_kwargs(
            event_id="event-2",
            run_id="run-1",
            event_type="run.status_changed",
        ),
    )

    assert appended.sequence == 3
    assert read_raw_sequences(store.run_path("run-1")) == [1, 2, 3]
    assert [event.event_id for event in store.read_run("run-1")] == ["event-1", "event-2"]
    assert [event.sequence for event in store.read_run("run-1")] == [1, 3]


def test_event_store_rejects_duplicate_or_non_monotonic_explicit_sequence(tmp_path) -> None:
    store = EventStore(tmp_path)

    store.append(**run_event_kwargs(event_id="event-1", run_id="run-1", sequence=1))

    with pytest.raises(ValueError, match="sequence"):
        store.append(**run_event_kwargs(event_id="event-2", run_id="run-1", sequence=1))

    with pytest.raises(ValueError, match="sequence"):
        store.append(**run_event_kwargs(event_id="event-3", run_id="run-1", sequence=0))


def test_event_store_raises_clear_error_for_torn_jsonl_tail(tmp_path) -> None:
    store = EventStore(tmp_path)
    log_path = store.run_path("run-1")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    first = build_event(event_id="event-1", run_id="run-1", sequence=1)
    log_path.write_text(
        json.dumps(first.model_dump(mode="json"), sort_keys=True) + "\n" + '{"event_id":"broken"',
        encoding="utf-8",
    )

    with pytest.raises(EventLogCorruptionError, match="run-1"):
        store.read_run("run-1")


def test_event_store_raises_clear_error_for_duplicate_persisted_sequence(tmp_path) -> None:
    write_raw_events(
        tmp_path,
        "run-1",
        [
            build_event(event_id="event-1", run_id="run-1", sequence=1),
            build_event(event_id="event-2", run_id="run-1", sequence=1, event_type="run.started"),
        ],
    )

    with pytest.raises(EventLogCorruptionError, match="duplicate sequence"):
        EventStore(tmp_path).read_run("run-1")


def test_event_store_raises_clear_error_for_first_sequence_not_equal_to_one(tmp_path) -> None:
    write_raw_events(
        tmp_path,
        "run-1",
        [build_event(event_id="event-1", run_id="run-1", sequence=0)],
    )

    with pytest.raises(EventLogCorruptionError, match="sequence 1"):
        EventStore(tmp_path).read_run("run-1")


def test_event_store_raises_clear_error_for_gap_in_persisted_sequence(tmp_path) -> None:
    write_raw_events(
        tmp_path,
        "run-1",
        [
            build_event(event_id="event-1", run_id="run-1", sequence=1),
            build_event(event_id="event-2", run_id="run-1", sequence=3, event_type="run.started"),
        ],
    )

    with pytest.raises(EventLogCorruptionError, match="expected sequence 2"):
        EventStore(tmp_path).read_run("run-1")


def test_event_store_raises_clear_error_for_out_of_order_persisted_sequence(tmp_path) -> None:
    write_raw_events(
        tmp_path,
        "run-1",
        [
            build_event(event_id="event-1", run_id="run-1", sequence=2, event_type="run.started"),
            build_event(event_id="event-2", run_id="run-1", sequence=1),
        ],
    )

    with pytest.raises(EventLogCorruptionError, match="non-monotonic sequence"):
        EventStore(tmp_path).read_run("run-1")


def test_event_store_read_run_deduplicates_duplicate_event_ids_with_valid_sequence_history(
    tmp_path,
) -> None:
    first = build_event(event_id="event-1", run_id="run-1", sequence=1)
    duplicate = build_event(event_id="event-1", run_id="run-1", sequence=2)
    write_raw_events(tmp_path, "run-1", [first, duplicate])

    events = EventStore(tmp_path).read_run("run-1")

    assert events == [first]


def test_event_store_raises_clear_error_for_conflicting_duplicate_event_id(tmp_path) -> None:
    write_raw_events(
        tmp_path,
        "run-1",
        [
            build_event(event_id="event-1", run_id="run-1", sequence=1),
            build_event(event_id="event-1", run_id="run-1", sequence=2, event_type="run.started"),
        ],
    )

    with pytest.raises(EventLogCorruptionError, match="conflicting duplicate event_id"):
        EventStore(tmp_path).read_run("run-1")


def run_event_kwargs(
    *,
    event_id: str,
    run_id: str,
    event_type: str = "run.created",
    sequence: int | None = None,
    include_occurred_at: bool = True,
) -> RunEventKwargs:
    kwargs: RunEventKwargs = {
        "event_id": event_id,
        "run_id": run_id,
        "event_type": event_type,
        "sequence": sequence,
        "source": "tests",
        "payload": {
            "goal": f"goal for {run_id}",
            "parent_run_id": None,
        },
    }
    if include_occurred_at:
        kwargs["occurred_at"] = datetime(2026, 3, 15, 12, 0, tzinfo=timezone.utc)
    return kwargs


def build_event(
    *,
    event_id: str,
    run_id: str,
    sequence: int,
    event_type: str = "run.created",
) -> Event:
    return Event(
        event_id=event_id,
        schema_version=1,
        run_id=run_id,
        stage_id=None,
        task_id=None,
        event_type=event_type,
        sequence=sequence,
        occurred_at=datetime(2026, 3, 15, 12, 0, tzinfo=timezone.utc),
        source="tests",
        payload={
            "goal": f"goal for {run_id}",
            "parent_run_id": None,
        },
    )


def write_raw_events(tmp_path: Path, run_id: str, events: list[Event]) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    log_path = repo_root / ".ralphception" / "events" / f"{run_id}.jsonl"
    log_path.write_text(
        "\n".join(json.dumps(event.model_dump(mode="json"), sort_keys=True) for event in events) + "\n",
        encoding="utf-8",
    )


def read_raw_sequences(log_path: Path) -> list[int]:
    return [
        json.loads(line)["sequence"]
        for line in log_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
