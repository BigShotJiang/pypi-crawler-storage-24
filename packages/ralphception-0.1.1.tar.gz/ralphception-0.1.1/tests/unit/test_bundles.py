import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from ralphception.models.artifacts import ArtifactRef
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.workflow.bundles import (
    ScopeHashArtifact,
    assign_bundle,
    bundle_path,
    compute_scope_hash,
    create_bundle,
    is_bundle_consumable,
    read_bundle,
    transition_bundle_state,
)


def test_scope_hash_ignores_todo_ordering() -> None:
    todo_list_a = [
        ScopeHashArtifact(
            artifact_path=".ralphception/todos/root.json",
            content=[
                {
                    "todo_id": "todo-2",
                    "title": "Verify the event log",
                    "acceptance_criteria": ["bundle.assigned is emitted"],
                    "execution_notes": "Run this after the happy path.",
                },
                {
                    "todo_id": "todo-1",
                    "title": "Persist the bundle",
                    "acceptance_criteria": ["bundle is written under runs/<run-id>/bundles"],
                    "execution_notes": "Touch the filesystem last.",
                },
            ],
        ),
    ]
    todo_list_b = [
        ScopeHashArtifact(
            artifact_path=".ralphception/todos/root.json",
            content=[
                {
                    "todo_id": "todo-1",
                    "title": "Persist the bundle",
                    "acceptance_criteria": ["bundle is written under runs/<run-id>/bundles"],
                    "execution_notes": "Do the disk write after the service returns.",
                },
                {
                    "todo_id": "todo-2",
                    "title": "Verify the event log",
                    "acceptance_criteria": ["bundle.assigned is emitted"],
                    "execution_notes": "Run verification at the end.",
                },
            ],
        ),
    ]

    assert compute_scope_hash(todo_list_a) == compute_scope_hash(todo_list_b)


def test_scope_hash_changes_when_requirements_change() -> None:
    bundle_a = [
        ScopeHashArtifact(
            artifact_path=".ralphception/specs/runtime.md",
            content="# Runtime Spec\n\n- Requirement: child scheduling consumes only approved bundles.\n",
        ),
        ScopeHashArtifact(
            artifact_path=".ralphception/events/run-1.jsonl",
            content='{"event_id":"1","event_type":"bundle.created"}\n',
        ),
    ]
    bundle_b = [
        ScopeHashArtifact(
            artifact_path=".ralphception/events/run-1.jsonl",
            content='{"event_id":"2","event_type":"bundle.state_changed"}\n',
        ),
        ScopeHashArtifact(
            artifact_path=".ralphception/specs/runtime.md",
            content="# Runtime Spec\n\n- Requirement: child scheduling consumes approved or derived bundles.\n",
        ),
    ]

    assert compute_scope_hash(bundle_a) != compute_scope_hash(bundle_b)


def test_scope_hash_uses_stable_artifact_path_order() -> None:
    bundle_a = [
        ScopeHashArtifact(
            artifact_path=".ralphception/plans/runtime.md",
            content="# Plan\n\n- Persist the execution bundle.\n",
        ),
        ScopeHashArtifact(
            artifact_path=".ralphception/specs/runtime.md",
            content="# Spec\n\n- Scheduling consumes only approved bundles.\n",
        ),
    ]
    bundle_b = list(reversed(bundle_a))

    assert compute_scope_hash(bundle_a) == compute_scope_hash(bundle_b)


def test_create_bundle_persists_under_run_directory_and_emits_created_event(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    artifact_refs = [
        write_artifact(
            repo_root,
            artifact_kind="plan",
            artifact_path=".ralphception/plans/runtime.md",
            content="# Plan\n\n- Add execution bundle persistence.\n",
        ),
        write_artifact(
            repo_root,
            artifact_kind="spec",
            artifact_path=".ralphception/specs/runtime.md",
            content="# Spec\n\n- Scheduling consumes only approved or derived bundles.\n",
        ),
        write_artifact(
            repo_root,
            artifact_kind="todo",
            artifact_path=".ralphception/todos/root.json",
            content=[
                {
                    "todo_id": "todo-2",
                    "title": "Verify approval snapshots",
                    "acceptance_criteria": ["approval copies artifacts into approvals/<id>/"],
                },
                {
                    "todo_id": "todo-1",
                    "title": "Persist bundle records",
                    "acceptance_criteria": ["bundle records live under runs/<run-id>/bundles/"],
                },
            ],
        ),
    ]

    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-1",
        run_id="run-1",
        bundle_version=1,
        state="draft",
        artifact_refs=artifact_refs,
        stage_id="stage-plan-1",
        created_at=utc_now(),
    )

    persisted = read_bundle(repo_root, run_id="run-1", bundle_id="bundle-1")
    events = EventStore(repo_root).read_run("run-1")

    assert bundle_path(repo_root, "run-1", "bundle-1").is_file()
    assert persisted == bundle
    assert bundle.scope_hash.startswith("sha256:")
    assert events[0].event_type == "bundle.created"
    assert events[0].stage_id == "stage-plan-1"
    assert events[0].payload["bundle_id"] == "bundle-1"
    assert events[0].payload["bundle_version"] == 1


@pytest.mark.parametrize(
    ("run_id", "bundle_id", "escaped_path"),
    [
        ("../escape", "bundle-1", ".ralphception/escape/bundles/bundle-1.json"),
        ("run-1", "../escape", ".ralphception/runs/run-1/escape.json"),
    ],
)
def test_create_bundle_rejects_invalid_identifiers_without_writing_outside_storage(
    tmp_path: Path,
    run_id: str,
    bundle_id: str,
    escaped_path: str,
) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    artifact_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Spec\n\n- Reject invalid bundle identifiers.\n",
    )

    with pytest.raises(ValueError, match="invalid .*identifier"):
        create_bundle(
            repo_root,
            bundle_id=bundle_id,
            run_id=run_id,
            bundle_version=1,
            state="draft",
            artifact_refs=[artifact_ref],
            stage_id="stage-plan-1",
            created_at=utc_now(),
        )

    assert not (repo_root / escaped_path).exists()


def test_create_bundle_rolls_back_record_when_event_append_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    artifact_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Spec\n\n- Roll back bundle creation on append failure.\n",
    )

    def fail_append(*args: object, **kwargs: object) -> None:
        raise RuntimeError("event append failed")

    monkeypatch.setattr("ralphception.workflow.bundles.EventStore.append", fail_append)

    with pytest.raises(RuntimeError, match="event append failed"):
        create_bundle(
            repo_root,
            bundle_id="bundle-1",
            run_id="run-1",
            bundle_version=1,
            state="draft",
            artifact_refs=[artifact_ref],
            stage_id="stage-plan-1",
            created_at=utc_now(),
        )

    assert not bundle_path(repo_root, "run-1", "bundle-1").exists()
    assert not EventStore(repo_root).run_path("run-1").exists()


def test_create_bundle_requires_artifact_files_exist(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)

    with pytest.raises(FileNotFoundError):
        create_bundle(
            repo_root,
            bundle_id="bundle-1",
            run_id="run-1",
            bundle_version=1,
            state="draft",
            artifact_refs=[
                ArtifactRef(
                    artifact_kind="spec",
                    artifact_path=".ralphception/specs/runtime.md",
                    artifact_version=1,
                    content_hash="sha256:spec:runtime.md",
                ),
            ],
            stage_id="stage-plan-1",
            created_at=utc_now(),
        )


def test_transition_bundle_state_persists_and_emits_state_changed_event(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-1",
        run_id="run-1",
        bundle_version=1,
        state="draft",
        artifact_refs=[
            write_artifact(
                repo_root,
                artifact_kind="spec",
                artifact_path=".ralphception/specs/runtime.md",
                content="# Spec\n\n- Require explicit execution-bundle approval.\n",
            ),
        ],
        stage_id="stage-spec-1",
        created_at=utc_now(),
    )

    approved = transition_bundle_state(
        repo_root,
        bundle=bundle,
        next_state="approved",
        stage_id="stage-merge-1",
    )

    persisted = read_bundle(repo_root, run_id="run-1", bundle_id="bundle-1")
    events = EventStore(repo_root).read_run("run-1")

    assert approved.state == "approved"
    assert is_bundle_consumable(approved) is True
    assert persisted == approved
    assert [event.event_type for event in events] == ["bundle.created", "bundle.state_changed"]
    assert events[1].payload["from_state"] == "draft"
    assert events[1].payload["to_state"] == "approved"

    with pytest.raises(ValueError, match="cannot transition"):
        transition_bundle_state(
            repo_root,
            bundle=approved,
            next_state="draft",
            stage_id="stage-merge-1",
        )


def test_transition_bundle_state_restores_previous_record_when_event_append_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-1",
        run_id="run-1",
        bundle_version=1,
        state="draft",
        artifact_refs=[
            write_artifact(
                repo_root,
                artifact_kind="spec",
                artifact_path=".ralphception/specs/runtime.md",
                content="# Spec\n\n- Preserve prior state on event failure.\n",
            ),
        ],
        stage_id="stage-spec-1",
        created_at=utc_now(),
    )

    def fail_append(*args: object, **kwargs: object) -> None:
        raise RuntimeError("event append failed")

    monkeypatch.setattr("ralphception.workflow.bundles.EventStore.append", fail_append)

    with pytest.raises(RuntimeError, match="event append failed"):
        transition_bundle_state(
            repo_root,
            bundle=bundle,
            next_state="approved",
            stage_id="stage-merge-1",
        )

    persisted = read_bundle(repo_root, run_id="run-1", bundle_id="bundle-1")
    events = EventStore(repo_root).read_run("run-1")

    assert persisted.state == "draft"
    assert [event.event_type for event in events] == ["bundle.created"]


def test_assign_bundle_requires_consumable_state_and_emits_assignment_event(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-1",
        run_id="run-1",
        bundle_version=1,
        state="draft",
        artifact_refs=[
            write_artifact(
                repo_root,
                artifact_kind="spec",
                artifact_path=".ralphception/specs/runtime.md",
                content="# Spec\n\n- Assignment records the consumed bundle version.\n",
            ),
        ],
        stage_id="stage-spec-1",
        created_at=utc_now(),
    )

    assert is_bundle_consumable(bundle) is False
    with pytest.raises(ValueError, match="consumable"):
        assign_bundle(
            repo_root,
            bundle=bundle,
            assigned_run_id="run-child-1",
            stage_id="stage-execute-1",
        )

    approved = transition_bundle_state(
        repo_root,
        bundle=bundle,
        next_state="approved",
        stage_id="stage-execute-1",
    )
    assigned = assign_bundle(
        repo_root,
        bundle=approved,
        assigned_run_id="run-child-1",
        stage_id="stage-execute-1",
    )

    events = EventStore(repo_root).read_run("run-1")

    assert assigned.assigned_run_ids == ["run-child-1"]
    assert [event.event_type for event in events] == [
        "bundle.created",
        "bundle.state_changed",
        "bundle.assigned",
    ]
    assert events[-1].payload["assigned_run_id"] == "run-child-1"


def test_assign_bundle_rejects_invalid_assigned_run_id_without_mutating_bundle(
    tmp_path: Path,
) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    bundle = transition_bundle_state(
        repo_root,
        bundle=create_bundle(
            repo_root,
            bundle_id="bundle-1",
            run_id="run-1",
            bundle_version=1,
            state="draft",
            artifact_refs=[
                write_artifact(
                    repo_root,
                    artifact_kind="spec",
                    artifact_path=".ralphception/specs/runtime.md",
                    content="# Spec\n\n- Reject unsafe assigned run ids.\n",
                ),
            ],
            stage_id="stage-spec-1",
            created_at=utc_now(),
        ),
        next_state="approved",
        stage_id="stage-execute-1",
    )

    with pytest.raises(ValueError, match="invalid .*identifier"):
        assign_bundle(
            repo_root,
            bundle=bundle,
            assigned_run_id="../run-child-1",
            stage_id="stage-execute-1",
        )

    persisted = read_bundle(repo_root, run_id="run-1", bundle_id="bundle-1")
    assert persisted.assigned_run_ids == []


def test_assign_bundle_restores_previous_record_when_event_append_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    approved = transition_bundle_state(
        repo_root,
        bundle=create_bundle(
            repo_root,
            bundle_id="bundle-1",
            run_id="run-1",
            bundle_version=1,
            state="draft",
            artifact_refs=[
                write_artifact(
                    repo_root,
                    artifact_kind="spec",
                    artifact_path=".ralphception/specs/runtime.md",
                    content="# Spec\n\n- Keep assignment state atomic.\n",
                ),
            ],
            stage_id="stage-spec-1",
            created_at=utc_now(),
        ),
        next_state="approved",
        stage_id="stage-execute-1",
    )

    def fail_append(*args: object, **kwargs: object) -> None:
        raise RuntimeError("event append failed")

    monkeypatch.setattr("ralphception.workflow.bundles.EventStore.append", fail_append)

    with pytest.raises(RuntimeError, match="event append failed"):
        assign_bundle(
            repo_root,
            bundle=approved,
            assigned_run_id="run-child-1",
            stage_id="stage-execute-1",
        )

    persisted = read_bundle(repo_root, run_id="run-1", bundle_id="bundle-1")
    events = EventStore(repo_root).read_run("run-1")

    assert persisted.assigned_run_ids == []
    assert [event.event_type for event in events] == [
        "bundle.created",
        "bundle.state_changed",
    ]


def write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    content: object,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, str):
        target.write_text(content, encoding="utf-8")
    else:
        target.write_text(json.dumps(content, indent=2) + "\n", encoding="utf-8")

    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=1,
        content_hash=f"sha256:{artifact_kind}:{target.name}",
    )


def utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
