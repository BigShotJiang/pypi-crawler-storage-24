from __future__ import annotations

from pathlib import Path
from typing import Any, cast

import pytest
from pydantic import ValidationError

from ralphception.models.artifacts import ArtifactRef
from ralphception.skills.contracts import (
    SkillArtifactUpdate,
    SkillInvocation,
    SkillResult,
)
from ralphception.skills.registry import BUNDLED_SKILL_IDS, BundledSkillAsset, SkillRegistry


def test_registry_prefers_exact_repo_override(tmp_path: Path) -> None:
    write_skill(tmp_path / ".ralphception/skills/spec.write.md", "# override")

    registry = SkillRegistry(tmp_path)
    resolved = registry.load("spec.write")

    assert resolved.source == "repo"
    assert resolved.warnings == []
    assert resolved.markdown_body == "# override"


def test_invalid_override_falls_back_to_bundled_skill(tmp_path: Path) -> None:
    write_skill(tmp_path / ".ralphception/skills/spec.write.md", "")

    registry = SkillRegistry(tmp_path)
    resolved = registry.load("spec.write")

    assert resolved.source == "bundled"
    assert resolved.warnings
    assert resolved.warnings[0].code == "override_invalid"


def test_unreadable_override_falls_back_to_bundled_skill(tmp_path: Path) -> None:
    override_path = tmp_path / ".ralphception/skills/spec.write.md"
    override_path.parent.mkdir(parents=True, exist_ok=True)
    override_path.write_bytes(b"\xff")

    registry = SkillRegistry(tmp_path)
    resolved = registry.load("spec.write")

    assert resolved.source == "bundled"
    assert resolved.warnings
    assert resolved.warnings[0].code == "override_unreadable"


@pytest.mark.parametrize("skill_id", BUNDLED_SKILL_IDS)
def test_registry_loads_non_empty_bundled_skill_assets(skill_id: str, tmp_path: Path) -> None:
    registry = SkillRegistry(tmp_path)
    resolved = registry.load(skill_id)

    assert resolved.source == "bundled"
    assert resolved.markdown_body.strip()


def test_registry_rejects_unknown_skill_id(tmp_path: Path) -> None:
    registry = SkillRegistry(tmp_path)

    with pytest.raises(ValidationError):
        registry.load("unknown.skill")


def test_registry_rejects_duplicate_bundled_skill_ids(tmp_path: Path) -> None:
    with pytest.raises(ValidationError):
        SkillRegistry(
            tmp_path,
            bundled_assets=[
                BundledSkillAsset(skill_id="spec.write", resource_name="spec.write.md"),
                BundledSkillAsset(skill_id="spec.write", resource_name="plan.write.md"),
            ],
        )


def test_skill_invocation_requires_known_expected_output_mode() -> None:
    with pytest.raises(ValidationError):
        SkillInvocation(
            run_id="run-1",
            stage_id="stage-1",
            goal="Create the plan",
            current_task_description="Write the implementation plan",
            target_repo_path=Path("/repo"),
            source_repo_paths=[Path("/repo")],
            relevant_artifact_refs=[make_artifact_ref()],
            effective_config_snapshot={"codex": {"model": "gpt-5.4"}},
            expected_output_mode=cast(Any, "outline"),
        )


def test_skill_result_requires_artifact_update_schema() -> None:
    with pytest.raises(ValidationError):
        SkillResult(
            status="success",
            artifact_updates=cast(Any, [{"apply_mode": "replace"}]),
            suggested_next=[],
            findings=[],
            markdown_body="Produced a plan.",
        )


def test_skill_result_rejects_unknown_apply_mode() -> None:
    with pytest.raises(ValidationError):
        SkillArtifactUpdate(
            artifact_kind="plan",
            artifact_path=".ralphception/plans/task.md",
            apply_mode=cast(Any, "merge"),
            content="new body",
        )


def test_skill_result_rejects_invalid_structured_patch_shape() -> None:
    with pytest.raises(ValidationError):
        SkillArtifactUpdate(
            artifact_kind="plan",
            artifact_path=".ralphception/plans/task.md",
            apply_mode="structured_patch",
            structured_patch=cast(
                Any,
                [
                    {
                        "op": "replace_range",
                        "start_line": 5,
                        "end_line": 4,
                        "content": "updated block",
                    }
                ],
            ),
        )


def test_skill_result_rejects_invalid_insert_after_patch_shape() -> None:
    with pytest.raises(ValidationError):
        SkillArtifactUpdate(
            artifact_kind="plan",
            artifact_path=".ralphception/plans/task.md",
            apply_mode="structured_patch",
            structured_patch=cast(
                Any,
                [
                    {
                        "op": "insert_after",
                        "start_line": 5,
                        "end_line": 6,
                        "content": "new line",
                    }
                ],
            ),
        )


def write_skill(path: Path, markdown_body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(markdown_body, encoding="utf-8")


def make_artifact_ref() -> ArtifactRef:
    return ArtifactRef(
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content_hash="sha256:spec",
    )
