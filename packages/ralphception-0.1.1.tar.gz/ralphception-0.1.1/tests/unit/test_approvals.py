import json
from datetime import datetime, timezone
from pathlib import Path

import pytest
from pydantic import ValidationError

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ApprovalRecord, ExecutionBundle
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.workflow.approvals import (
    approval_path,
    approval_snapshot_dir,
    create_execution_bundle_approval,
    create_finding_waiver,
    create_spec_review,
    persist_approval,
    read_approval,
)


def test_spec_review_requires_spec_bundle_only() -> None:
    spec_ref = make_artifact_ref(
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
    )
    plan_ref = make_artifact_ref(
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
    )

    approval = create_spec_review(
        approval_id="approval-spec-1",
        run_id="run-1",
        approver="user",
        spec_artifacts=[spec_ref],
        plan_artifacts=[],
        bundle_version=2,
        scope_hash="sha256:scope",
        approved_at=utc_now(),
    )

    assert approval.approval_kind == "spec_review"
    assert approval.artifact_bundle_refs == [spec_ref]

    with pytest.raises(ValidationError):
        create_spec_review(
            approval_id="approval-spec-2",
            run_id="run-1",
            approver="user",
            spec_artifacts=[spec_ref],
            plan_artifacts=[plan_ref],
            bundle_version=2,
            scope_hash="sha256:scope",
            approved_at=utc_now(),
        )


def test_execution_bundle_approval_persists_record_and_snapshot(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Spec\n\n- Snapshot approved artifacts.\n",
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        content="# Plan\n\n- Persist approvals into the repo-local store.\n",
    )
    bundle = ExecutionBundle(
        bundle_id="bundle-2",
        run_id="run-1",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref, plan_ref],
        base_bundle_id=None,
        scope_hash="sha256:scope-2",
        created_at=utc_now(),
        assigned_run_ids=[],
    )

    approval = create_execution_bundle_approval(
        approval_id="approval-exec-1",
        approver="user",
        bundle=bundle,
        approved_at=utc_now(),
    )
    persisted = persist_approval(repo_root, approval)
    loaded = read_approval(repo_root, approval_id="approval-exec-1")

    assert persisted == approval
    assert loaded == approval
    assert approval_path(repo_root, "approval-exec-1").is_file()
    assert (
        approval_snapshot_dir(repo_root, "approval-exec-1")
        / ".ralphception"
        / "specs"
        / "runtime.md"
    ).read_text(encoding="utf-8") == "# Spec\n\n- Snapshot approved artifacts.\n"
    assert (
        approval_snapshot_dir(repo_root, "approval-exec-1")
        / ".ralphception"
        / "plans"
        / "runtime.md"
    ).read_text(encoding="utf-8") == "# Plan\n\n- Persist approvals into the repo-local store.\n"


def test_approval_paths_reject_invalid_identifiers_without_writing_outside_storage(
    tmp_path: Path,
) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    approval = ApprovalRecord(
        approval_id="../approval-escape",
        run_id="run-1",
        approval_kind="finding_waiver",
        artifact_bundle_refs=None,
        bundle_version=None,
        scope_hash=None,
        approved_at=utc_now(),
        approver="user",
        waived_finding_ids=["finding-1"],
        rationale="approved risk",
    )

    with pytest.raises(ValueError, match="invalid .*identifier"):
        persist_approval(repo_root, approval)

    assert not (repo_root / ".ralphception" / "approval-escape.json").exists()
    with pytest.raises(ValueError, match="invalid .*identifier"):
        approval_path(repo_root, "../approval-escape")
    with pytest.raises(ValueError, match="invalid .*identifier"):
        approval_snapshot_dir(repo_root, "../approval-escape")


def test_persist_approval_uses_explicit_snapshot_refs_override(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Spec\n\n- Snapshot only the override refs.\n",
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        content="# Plan\n\n- This file should not be snapshotted.\n",
    )
    approval = ApprovalRecord(
        approval_id="approval-exec-override",
        run_id="run-1",
        approval_kind="execution_bundle",
        artifact_bundle_refs=[spec_ref, plan_ref],
        bundle_version=2,
        scope_hash="sha256:scope-2",
        approved_at=utc_now(),
        approver="user",
        waived_finding_ids=None,
        rationale=None,
    )

    persist_approval(repo_root, approval, snapshot_refs=[spec_ref])

    assert (
        approval_snapshot_dir(repo_root, "approval-exec-override")
        / ".ralphception"
        / "specs"
        / "runtime.md"
    ).is_file()
    assert not (
        approval_snapshot_dir(repo_root, "approval-exec-override")
        / ".ralphception"
        / "plans"
        / "runtime.md"
    ).exists()


def test_finding_waiver_requires_ids_and_rationale() -> None:
    with pytest.raises(ValidationError):
        create_finding_waiver(
            approval_id="approval-waiver-1",
            run_id="run-1",
            approver="user",
            waived_finding_ids=[],
            rationale="Valid reason",
            approved_at=utc_now(),
        )

    with pytest.raises(ValidationError):
        create_finding_waiver(
            approval_id="approval-waiver-2",
            run_id="run-1",
            approver="user",
            waived_finding_ids=["finding-1"],
            rationale="   ",
            approved_at=utc_now(),
        )


def test_create_finding_waiver_rejects_invalid_run_id() -> None:
    with pytest.raises(ValueError, match="invalid .*identifier"):
        create_finding_waiver(
            approval_id="approval-waiver-3",
            run_id="../run-1",
            approver="user",
            waived_finding_ids=["finding-1"],
            rationale="approved risk",
            approved_at=utc_now(),
        )


def make_artifact_ref(*, artifact_kind: str, artifact_path: str) -> ArtifactRef:
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=1,
        content_hash=f"sha256:{artifact_kind}:{Path(artifact_path).name}",
    )


def write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    content: object,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, str):
        target.write_text(content, encoding="utf-8")
    else:
        target.write_text(json.dumps(content, indent=2) + "\n", encoding="utf-8")
    return make_artifact_ref(artifact_kind=artifact_kind, artifact_path=artifact_path)


def utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
