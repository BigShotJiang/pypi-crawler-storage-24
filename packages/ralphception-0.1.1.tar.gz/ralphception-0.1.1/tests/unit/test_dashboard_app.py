from __future__ import annotations

import asyncio
from types import SimpleNamespace

from textual.app import App

from ralphception.runtime.supervisor import RuntimeSupervisor
from ralphception.ui.app import RalphceptionDashboardApp
from ralphception.ui.widgets.workflow_tree import WorkflowTreeEntry, WorkflowTreeWidget


class _StubController:
    def __init__(self, *, selected_node_id: str | None) -> None:
        self.selected_node_id = selected_node_id
        self.selected: list[str] = []

    def select_node(self, node_id: str) -> None:
        self.selected.append(node_id)
        self.selected_node_id = node_id


def test_tree_selection_does_not_refresh_when_node_is_already_selected() -> None:
    controller = _StubController(selected_node_id="run:run-root")
    app = RalphceptionDashboardApp(controller)  # type: ignore[arg-type]
    refresh_calls: list[str] = []
    app._refresh_view = lambda **kwargs: refresh_calls.append("refresh")  # type: ignore[method-assign]
    entry = WorkflowTreeEntry(
        node_id="run:run-root",
        parent_id=None,
        label="run-root",
        status="pending",
    )
    event = SimpleNamespace(node=SimpleNamespace(data=entry))

    app.on_tree_node_selected(event)  # type: ignore[arg-type]

    assert controller.selected == []
    assert refresh_calls == []


def test_tree_selection_refreshes_when_user_picks_a_different_node() -> None:
    controller = _StubController(selected_node_id="run:run-root")
    app = RalphceptionDashboardApp(controller)  # type: ignore[arg-type]
    refresh_calls: list[str] = []
    app._refresh_view = lambda **kwargs: refresh_calls.append("refresh")  # type: ignore[method-assign]
    entry = WorkflowTreeEntry(
        node_id="stage:spec",
        parent_id="run:run-root",
        label="spec stage",
        status="pending",
    )
    event = SimpleNamespace(node=SimpleNamespace(data=entry))

    app.on_tree_node_selected(event)  # type: ignore[arg-type]

    assert controller.selected == ["stage:spec"]
    assert refresh_calls == ["refresh"]


def test_dashboard_app_keeps_shared_supervisor_reference(tmp_path) -> None:
    controller = _StubController(selected_node_id="run:run-root")
    supervisor = RuntimeSupervisor(repo_root=tmp_path)

    app = RalphceptionDashboardApp(controller, supervisor=supervisor)  # type: ignore[arg-type]

    assert app.supervisor is supervisor


class _WorkflowTreeHarness(App[None]):
    def compose(self):
        yield WorkflowTreeWidget(id="workflow-tree")


def test_workflow_tree_preserves_expanded_nodes_across_refresh() -> None:
    entries = [
        WorkflowTreeEntry(node_id="run:run-root", parent_id=None, label="run-root", status="running"),
        WorkflowTreeEntry(node_id="stage:execute", parent_id="run:run-root", label="execute", status="running"),
        WorkflowTreeEntry(node_id="task:turn-1", parent_id="stage:execute", label="turn-1", status="running"),
    ]
    app = _WorkflowTreeHarness()

    async def exercise() -> bool:
        async with app.run_test() as pilot:
            tree = app.query_one(WorkflowTreeWidget)
            tree.load_entries(entries, selected_node_id="task:turn-1")
            stage_node = next(
                child for child in tree.root.children if child.data and child.data.node_id == "stage:execute"
            )
            stage_node.expand()
            await pilot.pause()
            tree.load_entries(entries, selected_node_id="task:turn-1")
            await pilot.pause()
            refreshed_stage = next(
                child for child in tree.root.children if child.data and child.data.node_id == "stage:execute"
            )
            return refreshed_stage.is_expanded

    assert asyncio.run(exercise()) is True
