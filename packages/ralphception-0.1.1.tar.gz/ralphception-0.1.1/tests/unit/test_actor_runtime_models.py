from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from ralphception.models.commit_intents import CommitIntent
from ralphception.models.mission import MissionSession
from ralphception.models.todos import TodoNode


def test_todo_node_requires_dependency_ids_to_be_unique() -> None:
    with pytest.raises(ValidationError):
        TodoNode(
            todo_id="todo-1",
            title="Add scheduler",
            dependency_ids=["todo-0", "todo-0"],
            status="ready",
            commit_intent_id="intent-1",
            scope_hints=["src/ralphception/actor_runtime/scheduler_actor.py"],
        )


def test_commit_intent_rejects_empty_todo_membership() -> None:
    with pytest.raises(ValidationError):
        CommitIntent(
            intent_id="intent-1",
            message="feat: add scheduler",
            todo_ids=[],
            ordering_after=[],
        )


def test_mission_session_accepts_required_fields() -> None:
    session = MissionSession(
        mission_id="mission-1",
        repo_root=str(Path("/tmp/repo")),
        phase="planning",
        approved_spec_version=2,
    )

    assert session.phase == "planning"
    assert session.approved_spec_version == 2
