import hashlib
import json
from pathlib import Path

from ralphception.bootstrap.storage import (
    ensure_bootstrap_dirs,
    seed_bootstrap_state,
    sync_gap_ledger_to_findings,
)


def test_seed_bootstrap_state_writes_manifest_gap_ledger_and_finish_criteria(tmp_path: Path) -> None:
    repo_root = tmp_path

    state = seed_bootstrap_state(repo_root)

    boot = repo_root / ".ralphception" / "bootstrapping"
    assert (boot / "inputs.json").exists()
    assert (boot / "gaps.json").exists()
    assert (boot / "gaps.md").exists()
    assert (boot / "finish-criteria.md").exists()

    assert state.inputs.authoritative_spec_paths == [
        "docs/superpowers/specs/2026-03-15-ralphception-design.md",
        "docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md",
    ]
    assert state.inputs.authoritative_plan_path == (
        "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
    )
    assert state.inputs.authoritative_readme_paths == ["README.md"]
    assert state.inputs.authoritative_code_globs == ["src/ralphception/**"]
    assert state.inputs.authoritative_test_globs == [
        "tests/unit/**",
        "tests/integration/**",
        "tests/e2e/**",
    ]
    assert state.inputs.notes == []
    assert state.inputs.updated_at is not None

    assert [finding.gap_id for finding in state.gaps.findings] == [
        "bootstrap-cli-resume",
        "bootstrap-startup-screen",
        "bootstrap-review-screen",
        "bootstrap-storage-artifacts-module",
    ]
    assert [finding.severity for finding in state.gaps.findings] == ["P1", "P1", "P1", "P2"]
    assert [finding.bootstrap_kind for finding in state.gaps.findings] == [
        "ux_gap",
        "ux_gap",
        "ux_gap",
        "implementation_gap",
    ]
    assert [finding.audit_kind for finding in state.gaps.findings] == [
        "feature_gap",
        "feature_gap",
        "feature_gap",
        "feature_gap",
    ]
    assert [finding.status for finding in state.gaps.findings] == ["open", "open", "open", "open"]
    assert state.gaps.authoritative_plan_path == (
        "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
    )
    assert state.gaps.updated_at is not None

    assert state.required_verification_commands == [
        "uv run pytest tests/unit tests/integration tests/e2e -q",
        "uv run ty check src tests",
    ]

    stored_inputs = json.loads((boot / "inputs.json").read_text(encoding="utf-8"))
    assert stored_inputs["authoritative_spec_paths"] == state.inputs.authoritative_spec_paths
    assert stored_inputs["authoritative_plan_path"] == state.inputs.authoritative_plan_path
    assert stored_inputs["authoritative_readme_paths"] == state.inputs.authoritative_readme_paths
    assert stored_inputs["authoritative_code_globs"] == state.inputs.authoritative_code_globs
    assert stored_inputs["authoritative_test_globs"] == state.inputs.authoritative_test_globs
    assert stored_inputs["notes"] == []
    assert stored_inputs["updated_at"] is not None

    stored_gaps = json.loads((boot / "gaps.json").read_text(encoding="utf-8"))
    assert stored_gaps["authoritative_plan_path"] == state.gaps.authoritative_plan_path
    assert stored_gaps["updated_at"] is not None
    assert [finding["gap_id"] for finding in stored_gaps["findings"]] == [
        "bootstrap-cli-resume",
        "bootstrap-startup-screen",
        "bootstrap-review-screen",
        "bootstrap-storage-artifacts-module",
    ]

    gaps_markdown = (boot / "gaps.md").read_text(encoding="utf-8")
    assert "bootstrap-cli-resume" in gaps_markdown
    assert "bootstrap-storage-artifacts-module" in gaps_markdown
    assert "P1" in gaps_markdown
    assert "P2" in gaps_markdown

    finish_criteria = (boot / "finish-criteria.md").read_text(encoding="utf-8")
    assert "docs/superpowers/specs/2026-03-15-ralphception-design.md" in finish_criteria
    assert "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md" in finish_criteria
    assert "uv run pytest tests/unit tests/integration tests/e2e -q" in finish_criteria
    assert "uv run ty check src tests" in finish_criteria
    assert "there are no open P0, P1, or P2 gaps" in finish_criteria
    assert "Accepted Items" in finish_criteria
    assert "Wontfix Items" in finish_criteria


def test_sync_gap_ledger_to_findings_persists_canonical_audit_findings(tmp_path: Path) -> None:
    state = seed_bootstrap_state(tmp_path)

    sync_gap_ledger_to_findings(tmp_path, state.gaps, stage_id="stage-audit")

    stored = json.loads(
        (
            tmp_path / ".ralphception" / "findings" / "bootstrap-cli-resume.json"
        ).read_text(encoding="utf-8"),
    )
    assert stored["severity"] == "P1"
    assert stored["kind"] == "feature_gap"
    assert stored["status"] == "open"


def test_sync_gap_ledger_to_findings_hashes_evidence_file_contents(tmp_path: Path) -> None:
    state = seed_bootstrap_state(tmp_path)
    evidence_path = tmp_path / "docs" / "evidence.txt"
    evidence_path.parent.mkdir(parents=True)
    first_contents = "first version\n"
    second_contents = "second version\n"
    evidence_path.write_text(first_contents, encoding="utf-8")

    updated_finding = state.gaps.findings[0].model_copy(
        update={"evidence_paths": [str(evidence_path.relative_to(tmp_path))]},
    )
    ledger = state.gaps.model_copy(
        update={"findings": [updated_finding, *state.gaps.findings[1:]]},
    )

    sync_gap_ledger_to_findings(tmp_path, ledger, stage_id="stage-audit")
    first_hash = json.loads(
        (
            tmp_path / ".ralphception" / "findings" / "bootstrap-cli-resume.json"
        ).read_text(encoding="utf-8"),
    )["evidence_refs"][0]["content_hash"]

    evidence_path.write_text(second_contents, encoding="utf-8")

    sync_gap_ledger_to_findings(tmp_path, ledger, stage_id="stage-audit")
    second_hash = json.loads(
        (
            tmp_path / ".ralphception" / "findings" / "bootstrap-cli-resume.json"
        ).read_text(encoding="utf-8"),
    )["evidence_refs"][0]["content_hash"]

    assert first_hash == f"sha256:{hashlib.sha256(first_contents.encode('utf-8')).hexdigest()}"
    assert second_hash == f"sha256:{hashlib.sha256(second_contents.encode('utf-8')).hexdigest()}"
    assert second_hash != first_hash


def test_ensure_bootstrap_dirs_does_not_modify_runtime_bootstrap_contract(tmp_path: Path) -> None:
    boot_dir = ensure_bootstrap_dirs(tmp_path)

    assert boot_dir == tmp_path / ".ralphception" / "bootstrapping"
    assert (tmp_path / ".ralphception" / "events").exists()
    assert (tmp_path / ".ralphception" / "bootstrapping" / "iterations").exists()
