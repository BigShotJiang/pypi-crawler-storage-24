from __future__ import annotations

import json
import subprocess
from pathlib import Path

from ralphception.runtime.terminal import ScriptedTerminalFrontend, run_terminal
from ralphception.storage.lease import lease_path
from ralphception.testing.fakes import FakeHeadlessTurnWriter, build_fake_session_manager


def test_terminal_run_completes_full_mission_and_cleans_runtime_state(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend()

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="Port parser",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )

    assert result.mode == "completed"
    assert result.root_run_id == "run-root"
    assert result.authoritative_repo_root == str(repo_root)
    assert "Runtime: completed" in frontend.output_text()
    assert not (repo_root / ".ralphception").exists()
    assert not (repo_root / ".ralphception" / "runs" / "run-root" / "headless-state.json").exists()
    assert not (repo_root / ".ralphception" / "runs" / "run-root" / "startup.json").exists()
    assert not lease_path(repo_root, xdg_state_home=tmp_path / "xdg-state").exists()
    assert git_status(repo_root) == ""
    assert git_author(repo_root) == "Test User <test@example.com>"
    assert git_subject(repo_root) == "feat: Implement the parser artifact"
    worktrees_root = repo_root / ".worktrees"
    assert not worktrees_root.exists() or list(worktrees_root.iterdir()) == []


def test_terminal_run_starts_fresh_after_completed_mission_cleanup(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    first_frontend = ScriptedTerminalFrontend()

    first = run_terminal(
        repo_root=repo_root,
        seed_prompt="Port parser",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=first_frontend,
    )
    second_frontend = ScriptedTerminalFrontend()
    restarted = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=second_frontend,
    )

    assert first.mode == "completed"
    assert restarted.mode == "completed"
    assert "Resumed run-root" not in second_frontend.output_text()
    assert "Bootstrapped run-root" in second_frontend.output_text()


def test_terminal_run_completes_when_repo_tracks_runtime_event_log(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path, track_runtime_event_log=True)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend()

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )

    assert result.mode == "completed"
    assert "Runtime: completed" in frontend.output_text()


def test_terminal_run_accepts_string_artifact_handoffs_from_execute_stage(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend()

    class StringArtifactWriter(FakeHeadlessTurnWriter):
        def handle_turn(self, session, input_text: str, turn_counter: int) -> None:
            super().handle_turn(session, input_text, turn_counter)
            if '"stage": "execute"' not in input_text:
                return
            run_id = "run-child-1-replacement-1" if "-replacement-" in input_text else "run-child-1"
            handoff_path = Path(session.workspace_path) / ".ralphception" / "runs" / run_id / "handoff.json"
            payload = json.loads(handoff_path.read_text(encoding="utf-8"))
            payload["artifacts"] = ["src/parser.py", f".ralphception/runs/{run_id}/handoff.json"]
            handoff_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def session_manager_factory(resolved_repo_root: Path, config):
        writer = StringArtifactWriter()
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        frontend=frontend,
        session_manager_factory=session_manager_factory,
    )

    assert result.mode == "completed"
    assert "Mission completed: run-root" in frontend.output_text()


def test_terminal_run_accepts_object_merge_readiness_from_execute_stage(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend()

    class ObjectMergeReadinessWriter(FakeHeadlessTurnWriter):
        def handle_turn(self, session, input_text: str, turn_counter: int) -> None:
            super().handle_turn(session, input_text, turn_counter)
            if '"stage": "execute"' not in input_text:
                return
            run_id = "run-child-1-replacement-1" if "-replacement-" in input_text else "run-child-1"
            handoff_path = Path(session.workspace_path) / ".ralphception" / "runs" / run_id / "handoff.json"
            payload = json.loads(handoff_path.read_text(encoding="utf-8"))
            payload["merge_readiness"] = {
                "ready": True,
                "notes": "Only the requested files were added.",
            }
            handoff_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def session_manager_factory(resolved_repo_root: Path, config):
        writer = ObjectMergeReadinessWriter()
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        frontend=frontend,
        session_manager_factory=session_manager_factory,
    )

    assert result.mode == "completed"
    assert "Mission completed: run-root" in frontend.output_text()


def make_git_repo(tmp_path: Path, *, track_runtime_event_log: bool = False) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    run_git(repo_root, "init", "-b", "main")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    if track_runtime_event_log:
        tracked_event_log = repo_root / ".ralphception" / "events" / "run-root.jsonl"
        tracked_event_log.parent.mkdir(parents=True, exist_ok=True)
        tracked_event_log.write_text("", encoding="utf-8")
    run_git(repo_root, "add", "README.md")
    if track_runtime_event_log:
        run_git(repo_root, "add", ".ralphception/events/run-root.jsonl")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "initial",
    )
    run_git(repo_root, "config", "user.name", "Test User")
    run_git(repo_root, "config", "user.email", "test@example.com")
    return repo_root


def run_git(repo_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )


def git_status(repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", "status", "--short"],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def git_author(repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", "log", "-1", "--format=%an <%ae>"],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def git_subject(repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", "log", "-1", "--format=%s"],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()
