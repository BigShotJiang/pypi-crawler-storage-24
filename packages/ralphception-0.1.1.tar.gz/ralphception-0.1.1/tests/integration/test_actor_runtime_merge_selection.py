from __future__ import annotations

from pathlib import Path

from ralphception.actor_runtime.merge_actor import MergeAgent, WorkerCandidate
from ralphception.models.commit_intents import CommitIntent
from ralphception.storage.commit_intents import read_commit_intents, write_commit_intents


def test_merge_agent_records_selected_candidate_for_commit_intent(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    intent = CommitIntent(
        intent_id="intent-1",
        message="feat: add scheduler actor",
        todo_ids=["todo-1"],
        ordering_after=[],
    )
    write_commit_intents(repo_root, [intent])
    agent = MergeAgent(repo_root=repo_root)

    decision = agent.choose_candidate(
        intent,
        [
            WorkerCandidate(
                candidate_id="candidate-a",
                commit_intent_id="intent-1",
                summary="Initial implementation",
                touched_paths=["src/ralphception/actor_runtime/scheduler_actor.py"],
                verification_passed=True,
            ),
            WorkerCandidate(
                candidate_id="candidate-b",
                commit_intent_id="intent-1",
                summary="Broader implementation with tests",
                touched_paths=[
                    "src/ralphception/actor_runtime/scheduler_actor.py",
                    "tests/unit/test_scheduler_actor.py",
                ],
                verification_passed=True,
            ),
        ],
    )
    agent.record_decision(intent, decision)

    stored_intents = read_commit_intents(repo_root)

    assert stored_intents[0].winning_candidate_id == "candidate-b"
    assert agent.land_intent(decision) == "feat: add scheduler actor"
