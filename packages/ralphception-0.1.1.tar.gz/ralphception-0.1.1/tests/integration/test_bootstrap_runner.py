import json
from types import SimpleNamespace
from pathlib import Path

from ralphception.bootstrap.runner import (
    install_or_run,
    prepare_bootstrap_iteration,
    run_loop_once,
)
from ralphception.config import DEFAULT_CONFIG, RalphceptionConfig, write_config_atomically


def test_prepare_bootstrap_iteration_seeds_state_writes_prompt_and_uses_default_command(
    tmp_path: Path,
) -> None:
    result = prepare_bootstrap_iteration(tmp_path)

    prompt_path = tmp_path / ".ralphception" / "bootstrapping" / "prompt.txt"

    assert result.should_run_codex is True
    assert result.reason == "ready"
    assert result.command == [
        "codex",
        "exec",
        "--cd",
        str(tmp_path),
        "--dangerously-bypass-approvals-and-sandbox",
        "--model",
        DEFAULT_CONFIG.codex.model,
        "-c",
        f'model_reasoning_effort="{DEFAULT_CONFIG.codex.reasoning}"',
        "-c",
        'model_verbosity="low"',
        "-",
    ]
    assert prompt_path.exists()
    assert result.inputs.latest_iteration_summary_path is None
    assert result.inputs.authoritative_plan_path in prompt_path.read_text(encoding="utf-8")
    assert (tmp_path / ".ralphception" / "bootstrapping" / "inputs.json").exists()
    assert (tmp_path / ".ralphception" / "config.toml").exists()


def test_prepare_bootstrap_iteration_uses_repo_config_values_for_command(tmp_path: Path) -> None:
    custom_config = RalphceptionConfig(
        codex=DEFAULT_CONFIG.codex.__class__(
            model="gpt-5.7-mini",
            reasoning="medium",
            latency_profile=DEFAULT_CONFIG.codex.latency_profile,
            sandbox=DEFAULT_CONFIG.codex.sandbox,
            approval_policy=DEFAULT_CONFIG.codex.approval_policy,
        ),
        execution=DEFAULT_CONFIG.execution,
        verification=DEFAULT_CONFIG.verification,
        ui=DEFAULT_CONFIG.ui,
    )
    write_config_atomically(tmp_path / ".ralphception" / "config.toml", custom_config)

    result = prepare_bootstrap_iteration(tmp_path)

    assert result.command == [
        "codex",
        "exec",
        "--cd",
        str(tmp_path),
        "--dangerously-bypass-approvals-and-sandbox",
        "--model",
        "gpt-5.7-mini",
        "-c",
        'model_reasoning_effort="medium"',
        "-c",
        'model_verbosity="low"',
        "-",
    ]


def test_prepare_bootstrap_iteration_rewrites_invalid_config_with_default(tmp_path: Path) -> None:
    config_path = tmp_path / ".ralphception" / "config.toml"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text("[codex]\nmodel = 12\n", encoding="utf-8")

    result = prepare_bootstrap_iteration(tmp_path)

    assert result.command[6] == DEFAULT_CONFIG.codex.model
    assert f'reasoning = "{DEFAULT_CONFIG.codex.reasoning}"' in config_path.read_text(
        encoding="utf-8",
    )


def test_prepare_bootstrap_iteration_stops_when_approval_request_is_pending(tmp_path: Path) -> None:
    first = prepare_bootstrap_iteration(tmp_path)
    assert first.should_run_codex is True

    approval_path = tmp_path / ".ralphception" / "bootstrapping" / "approval-request.json"
    approval_path.write_text(
        """{
  "approval_kind": "spec_review",
  "run_id": "run-root",
  "artifact_paths": [
    "docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md"
  ],
  "bundle_id": "bundle-1",
  "bundle_version": 1,
  "scope_hash": "sha256:test",
  "waived_finding_ids": null,
  "rationale": null,
  "requested_at": "2026-03-17T00:00:00Z"
}
""",
        encoding="utf-8",
    )

    blocked = prepare_bootstrap_iteration(tmp_path)

    assert blocked.should_run_codex is False
    assert blocked.reason == "awaiting_review"
    assert blocked.command == []


def test_record_iteration_updates_latest_summary_pointer(tmp_path: Path) -> None:
    first = prepare_bootstrap_iteration(tmp_path)

    summary_path = first.record_iteration_summary(
        "Closed one gap.",
        verification_lines=["uv run pytest tests/integration/test_bootstrap_runner.py -v: PASS"],
    )
    reread = prepare_bootstrap_iteration(tmp_path)
    summary_text = summary_path.read_text(encoding="utf-8")

    assert reread.inputs.latest_iteration_summary_path == str(summary_path.relative_to(tmp_path))
    assert "Closed one gap." in summary_text
    assert "uv run pytest tests/integration/test_bootstrap_runner.py -v: PASS" in summary_text


def test_prepare_bootstrap_iteration_syncs_gap_ledger_into_canonical_findings(
    tmp_path: Path,
) -> None:
    result = prepare_bootstrap_iteration(tmp_path)

    findings_dir = tmp_path / ".ralphception" / "findings"
    resume_finding_path = findings_dir / "bootstrap-cli-resume.json"

    assert result.should_run_codex is True
    assert resume_finding_path.exists()
    resume_finding = json.loads(resume_finding_path.read_text(encoding="utf-8"))
    assert resume_finding["finding_id"] == "bootstrap-cli-resume"
    assert resume_finding["run_id"] == "run-root"
    assert len(list(findings_dir.glob("*.json"))) == 4


def test_prepare_bootstrap_iteration_reports_done_when_no_blocking_work_remains(
    tmp_path: Path,
) -> None:
    _mark_bootstrap_done(tmp_path)

    result = prepare_bootstrap_iteration(tmp_path)

    assert result.should_run_codex is False
    assert result.reason == "done"
    assert result.command == []


def test_prepare_bootstrap_iteration_ignores_nested_backlog_items_when_done(
    tmp_path: Path,
) -> None:
    _mark_bootstrap_done(
        tmp_path,
        plan_contents=(
            "# Bootstrap Plan\n\n"
            "## Active Work\n\n"
            "- [x] Close the remaining bootstrap gaps.\n\n"
            "## Follow-On Delivery Backlog\n\n"
            "### Post-launch ideas\n\n"
            "- [ ] Nice-to-have backlog item.\n"
        ),
    )

    result = prepare_bootstrap_iteration(tmp_path)

    assert result.should_run_codex is False
    assert result.reason == "done"
    assert result.command == []


def test_install_or_run_executes_prepared_codex_command_and_installs_script(tmp_path: Path) -> None:
    calls: dict[str, object] = {}

    def fake_run(
        command: list[str],
        *,
        cwd: Path,
        input: str,
        text: bool,
        check: bool,
    ) -> SimpleNamespace:
        calls["command"] = command
        calls["cwd"] = cwd
        calls["input"] = input
        calls["text"] = text
        calls["check"] = check
        return SimpleNamespace(returncode=0)

    exit_code = install_or_run(tmp_path, run_command=fake_run)

    assert exit_code == 0
    assert calls["command"] == [
        "codex",
        "exec",
        "--cd",
        str(tmp_path),
        "--dangerously-bypass-approvals-and-sandbox",
        "--model",
        DEFAULT_CONFIG.codex.model,
        "-c",
        f'model_reasoning_effort="{DEFAULT_CONFIG.codex.reasoning}"',
        "-c",
        'model_verbosity="low"',
        "-",
    ]
    assert calls["cwd"] == tmp_path
    assert calls["text"] is True
    assert calls["check"] is False
    assert "bootstrap-cli-resume" in str(calls["input"])
    assert (tmp_path / "ralph.sh").exists()


def test_install_or_run_skips_codex_when_review_is_pending(tmp_path: Path) -> None:
    (tmp_path / ".git" / "info").mkdir(parents=True)
    prepare_bootstrap_iteration(tmp_path)
    approval_path = tmp_path / ".ralphception" / "bootstrapping" / "approval-request.json"
    approval_path.write_text(
        """{
  "approval_kind": "spec_review",
  "run_id": "run-root",
  "artifact_paths": [],
  "bundle_id": "bundle-1",
  "bundle_version": 1,
  "scope_hash": "sha256:test",
  "waived_finding_ids": null,
  "rationale": null,
  "requested_at": "2026-03-17T00:00:00Z"
}
""",
        encoding="utf-8",
    )
    launched = False

    def fake_run(
        command: list[str],
        *,
        cwd: Path,
        input: str,
        text: bool,
        check: bool,
    ) -> SimpleNamespace:
        nonlocal launched
        launched = True
        return SimpleNamespace(returncode=0)

    exit_code = install_or_run(tmp_path, run_command=fake_run)

    assert exit_code == 0
    assert launched is False


def test_run_loop_once_returns_continue_when_work_remains(tmp_path: Path) -> None:
    launched = False

    def fake_run(
        command: list[str],
        *,
        cwd: Path,
        input: str,
        text: bool,
        check: bool,
    ) -> SimpleNamespace:
        nonlocal launched
        launched = True
        return SimpleNamespace(returncode=0)

    exit_code = run_loop_once(tmp_path, run_command=fake_run)

    assert exit_code == 10
    assert launched is True


def test_run_loop_once_returns_done_without_launching_when_finish_criteria_are_satisfied(
    tmp_path: Path,
) -> None:
    _mark_bootstrap_done(tmp_path)
    launched = False

    def fake_run(
        command: list[str],
        *,
        cwd: Path,
        input: str,
        text: bool,
        check: bool,
    ) -> SimpleNamespace:
        nonlocal launched
        launched = True
        return SimpleNamespace(returncode=0)

    exit_code = run_loop_once(tmp_path, run_command=fake_run)

    assert exit_code == 0
    assert launched is False


def test_run_loop_once_returns_done_after_iteration_closes_remaining_work(tmp_path: Path) -> None:
    def fake_run(
        command: list[str],
        *,
        cwd: Path,
        input: str,
        text: bool,
        check: bool,
    ) -> SimpleNamespace:
        _mark_bootstrap_done(tmp_path)
        return SimpleNamespace(returncode=0)

    exit_code = run_loop_once(tmp_path, run_command=fake_run)

    assert exit_code == 0


def _mark_bootstrap_done(repo_root: Path, *, plan_contents: str | None = None) -> None:
    prepared = prepare_bootstrap_iteration(repo_root)
    plan_path = repo_root / prepared.inputs.authoritative_plan_path
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    plan_path.write_text(
        plan_contents
        or "# Bootstrap Plan\n\n## Active Work\n\n- [x] Close the remaining bootstrap gaps.\n",
        encoding="utf-8",
    )

    gaps_path = repo_root / ".ralphception" / "bootstrapping" / "gaps.json"
    gaps = json.loads(gaps_path.read_text(encoding="utf-8"))
    for finding in gaps["findings"]:
        finding["status"] = "resolved"
    gaps_path.write_text(json.dumps(gaps, indent=2) + "\n", encoding="utf-8")
