from __future__ import annotations
	
import json
import queue
from pathlib import Path
import threading
import time
from typing import cast
from unittest.mock import patch

import pytest

import ralphception.headless as headless_module
from ralphception.codex.client import CodexTurnRef, normalize_notification
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.config import RalphceptionConfig
from ralphception.models.runtime import Run
from ralphception.runtime.supervisor import (
    RuntimeBackendUnavailableError,
    RuntimeLaunchAbortedError,
    RuntimeSupervisor,
)
from ralphception.runtime.terminal import ScriptedTerminalFrontend, TerminalRunResult, run_terminal
from ralphception.testing.fakes import (
    FakeCodexClient,
    FakeHeadlessTurnWriter,
    FakeNotification,
    build_fake_session_manager,
)
from ralphception.ui.screens.startup import StartupBootstrapController


def test_terminal_frontend_prompts_for_startup_inputs(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=["port parser", ""])

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert "Seed prompt" in frontend.output_text()
    assert result.mode == "completed"


def test_terminal_frontend_with_seed_prompt_fails_fast_without_backend(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)

    with patch("ralphception.runtime.supervisor.codex_cli_available", return_value=False):
        with pytest.raises(RuntimeBackendUnavailableError, match="No Codex session backend"):
            run_terminal(
                repo_root=repo_root,
                seed_prompt="find any bugs",
                frontend=ScriptedTerminalFrontend(),
            )


def test_terminal_frontend_prompts_before_starting_new_mission_when_workspace_has_active_mission(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="existing mission",
        source_repos=[],
    )
    frontend = ScriptedTerminalFrontend(inputs=["start"])

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert "Use --resume to attach to it instead." in frontend.output_text()
    assert "Starting a new mission will clear the current Ralphception runtime state." in frontend.output_text()
    assert "Mission action [start/abort]:" in frontend.output_text()
    assert result.mode == "completed"


def test_terminal_frontend_same_prompt_still_prompts_before_starting_new_session(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )

    frontend = ScriptedTerminalFrontend(inputs=["abort"])

    with pytest.raises(RuntimeLaunchAbortedError, match="Launch aborted"):
        run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            use_fake_session_manager=True,
        )

    assert "Use --resume to attach to it instead." in frontend.output_text()
    assert "Mission action [start/abort]:" in frontend.output_text()


def test_terminal_frontend_resume_can_pause_at_pending_review_without_crashing(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    initial_frontend = ScriptedTerminalFrontend(inputs=["find any bugs", "", "pause"])

    initial = run_terminal(
        repo_root=repo_root,
        frontend=initial_frontend,
        use_fake_session_manager=True,
    )

    paused_frontend = ScriptedTerminalFrontend(inputs=["pause"])
    resumed = run_terminal(
        repo_root=repo_root,
        frontend=paused_frontend,
        approve_all=True,
        use_fake_session_manager=True,
        resume=True,
    )

    assert initial.mode == "running"
    assert resumed.mode == "running"
    assert resumed.root_run_id == "run-root"
    assert "Review action" in paused_frontend.output_text()
    assert not (repo_root / ".ralphception" / "plans" / "mission-plan.json").exists()


def test_terminal_frontend_streams_high_level_mission_progress(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend()

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    output = frontend.output_text()

    assert "Stage: spec" in output
    assert "Turn started: run-root spec attempt 1" in output
    assert "Approved: spec_review" in output
    assert "Child run created: run-child-1" in output
    assert "Verification passed: run-child-1 execute" in output
    assert "Merged: run-child-1" in output
    assert "Mission completed: run-root" in output
    assert result.mode == "completed"


def test_terminal_frontend_streams_live_turn_progress_from_raw_backend_events(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend()

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))
        writer = FakeHeadlessTurnWriter()

        def turn_handler(session, input_text: str, turn_counter: int) -> None:
            command = "git status --short"
            message_id = f"message-{turn_counter}"
            command_id = f"command-{turn_counter}"
            fake_client.notifications.extend(
                [
                    FakeNotification(
                        method="item/started",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {"type": "agentMessage", "id": message_id, "text": ""},
                        },
                    ),
                    FakeNotification(
                        method="item/agentMessage/delta",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "itemId": message_id,
                            "delta": "Inspecting the workspace.",
                        },
                    ),
                    FakeNotification(
                        method="item/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "agentMessage",
                                "id": message_id,
                                "text": "Inspecting the workspace.",
                            },
                        },
                    ),
                    FakeNotification(
                        method="item/started",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "commandExecution",
                                "id": command_id,
                                "command": command,
                                "status": "inProgress",
                            },
                        },
                    ),
                    FakeNotification(
                        method="item/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "commandExecution",
                                "id": command_id,
                                "command": command,
                                "status": "completed",
                                "exitCode": 0,
                            },
                        },
                    ),
                ],
            )
            writer.handle_turn(session, input_text, turn_counter)

        fake_client.turn_handler = turn_handler
        return CodexSessionManager(
            workspace_path=str(resolved_repo_root),
            config=config,
            client=fake_client,
        )

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        frontend=frontend,
        approve_all=True,
        session_manager_factory=session_manager_factory,
    )

    output = frontend.output_text()

    assert "Agent: Inspecting the workspace." in output
    assert "Command started: git status --short" in output
    assert "Command completed (exit 0): git status --short" in output
    assert result.mode == "completed"


def test_terminal_frontend_emits_live_progress_before_turn_completion(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend()
    observed: dict[str, object] = {}

    class BlockingFakeCodexClient(FakeCodexClient):
        def __init__(self, *, workspace_path: str) -> None:
            super().__init__(workspace_path=workspace_path)
            self._notification_queue: queue.Queue[FakeNotification] = queue.Queue()

        def turn_start(
            self,
            thread_id: str,
            input_text: str,
            *,
            cwd: str | None,
            config,
        ) -> CodexTurnRef:
            if thread_id not in self._sessions_by_thread_id:
                raise RuntimeError(f"missing thread {thread_id}")
            self.turn_counter += 1
            turn_id = f"turn-{self.turn_counter}"
            session = self._sessions_by_thread_id[thread_id]
            self._notification_queue.put(
                FakeNotification(
                    method="turn/started",
                    payload={"threadId": thread_id, "turn": {"id": turn_id, "status": "running"}},
                ),
            )
            if self.turn_handler is not None:
                self.turn_handler(session, input_text, self.turn_counter)
            return CodexTurnRef(thread_id=thread_id, turn_id=turn_id)

        def next_notification(self):
            notification = self._notification_queue.get(timeout=5)
            return normalize_notification(notification.method, notification.payload)

        def enqueue(self, notification: FakeNotification) -> None:
            self._notification_queue.put(notification)

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        fake_client = BlockingFakeCodexClient(workspace_path=str(resolved_repo_root))
        writer = FakeHeadlessTurnWriter()

        def turn_handler(session, input_text: str, turn_counter: int) -> None:
            command = "git status --short"
            message_id = f"message-{turn_counter}"
            command_id = f"command-{turn_counter}"
            writer.handle_turn(session, input_text, turn_counter)

            def publish() -> None:
                fake_client.enqueue(
                    FakeNotification(
                        method="item/started",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {"type": "agentMessage", "id": message_id, "text": ""},
                        },
                    ),
                )
                fake_client.enqueue(
                    FakeNotification(
                        method="item/agentMessage/delta",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "itemId": message_id,
                            "delta": "Inspecting the workspace.",
                        },
                    ),
                )
                fake_client.enqueue(
                    FakeNotification(
                        method="item/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "agentMessage",
                                "id": message_id,
                                "text": "Inspecting the workspace.",
                            },
                        },
                    ),
                )
                fake_client.enqueue(
                    FakeNotification(
                        method="item/started",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "commandExecution",
                                "id": command_id,
                                "command": command,
                                "status": "inProgress",
                            },
                        },
                    ),
                )
                time.sleep(0.2)
                fake_client.enqueue(
                    FakeNotification(
                        method="item/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "commandExecution",
                                "id": command_id,
                                "command": command,
                                "status": "completed",
                                "exitCode": 0,
                            },
                        },
                    ),
                )
                fake_client.enqueue(
                    FakeNotification(
                        method="turn/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turn": {"id": f"turn-{turn_counter}", "status": "completed"},
                        },
                    ),
                )

            threading.Thread(target=publish, daemon=True).start()

        fake_client.turn_handler = turn_handler
        return CodexSessionManager(
            workspace_path=str(resolved_repo_root),
            config=config,
            client=fake_client,
        )

    def run_terminal_in_thread() -> None:
        observed["result"] = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            session_manager_factory=session_manager_factory,
        )

    worker = threading.Thread(target=run_terminal_in_thread, daemon=True)
    worker.start()

    time.sleep(0.05)
    output = frontend.output_text()

    assert "Agent: Inspecting the workspace." in output
    assert "Command started: git status --short" in output
    assert "Turn completed: run-root spec" not in output

    worker.join(timeout=5)
    assert worker.is_alive() is False
    assert cast(TerminalRunResult, observed["result"]).mode == "completed"


def test_terminal_frontend_returns_failed_result_when_child_verification_fails(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend()
    original_run_verification_command = headless_module._run_verification_command

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        result = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            use_fake_session_manager=True,
        )
    finally:
        monkeypatch.undo()

    assert result.mode == "failed"
    assert "Verification failed: run-child-1 execute" in frontend.output_text()
    assert "Runtime: failed" in frontend.output_text()

    child_run = Run.model_validate_json(
        (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").read_text(encoding="utf-8")
    )
    assert child_run.status == "failed"

    step = RuntimeSupervisor(
        repo_root=repo_root,
        session_manager_factory=lambda resolved_repo_root, config: build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    ).step()
    assert step.kind == "review_prompt"
    assert step.review_prompt is not None
    assert step.review_prompt.review_kind == "recovery"
    assert step.review_prompt.run_id == "run-child-1"


def test_terminal_frontend_prompts_before_starting_new_mission_when_workspace_has_failed_mission(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend()
    original_run_verification_command = headless_module._run_verification_command

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        failed = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            use_fake_session_manager=True,
        )
    finally:
        monkeypatch.undo()

    assert failed.mode == "failed"

    next_frontend = ScriptedTerminalFrontend(inputs=["abort"])
    with pytest.raises(RuntimeLaunchAbortedError, match="Launch aborted"):
        run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=next_frontend,
            approve_all=True,
            use_fake_session_manager=True,
        )

    assert "Use --resume to attach to it instead." in next_frontend.output_text()
    assert "Mission action [start/abort]:" in next_frontend.output_text()


def test_terminal_frontend_can_resume_failed_mission_through_recovery(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend()
    original_run_verification_command = headless_module._run_verification_command
    writer = FakeHeadlessTurnWriter()

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        failed = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            session_manager_factory=session_manager_factory,
        )
    finally:
        monkeypatch.undo()

    assert failed.mode == "failed"

    writer.audit_turns = 1
    resumed_frontend = ScriptedTerminalFrontend(inputs=["replace"])
    resumed = run_terminal(
        repo_root=repo_root,
        frontend=resumed_frontend,
        approve_all=True,
        session_manager_factory=session_manager_factory,
        resume=True,
    )

    assert resumed.mode == "completed"
    assert "Recovery review" in resumed_frontend.output_text()
    assert "Run: run-child-1" in resumed_frontend.output_text()
    assert "Mission completed: run-root" in resumed_frontend.output_text()


def test_terminal_frontend_resume_can_pause_at_recovery_review_without_reporting_child_as_root(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend()
    original_run_verification_command = headless_module._run_verification_command
    writer = FakeHeadlessTurnWriter()

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        failed = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            session_manager_factory=session_manager_factory,
        )
    finally:
        monkeypatch.undo()

    assert failed.mode == "failed"

    paused_frontend = ScriptedTerminalFrontend(inputs=["pause"])
    resumed = run_terminal(
        repo_root=repo_root,
        frontend=paused_frontend,
        approve_all=True,
        session_manager_factory=session_manager_factory,
        resume=True,
    )

    assert resumed.mode == "running"
    assert resumed.root_run_id == "run-root"
    assert "Recovery review" in paused_frontend.output_text()
    assert "Run: run-child-1" in paused_frontend.output_text()


def test_terminal_frontend_reconciles_legacy_failed_runtime_state_on_resume(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    writer = FakeHeadlessTurnWriter()
    original_run_verification_command = headless_module._run_verification_command

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        failed = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=ScriptedTerminalFrontend(),
            approve_all=True,
            session_manager_factory=session_manager_factory,
        )
    finally:
        monkeypatch.undo()

    assert failed.mode == "failed"

    root_run_path = repo_root / ".ralphception" / "runs" / "run-root" / "run.json"
    child_run_path = repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json"
    headless_state_path = repo_root / ".ralphception" / "runs" / "run-root" / "headless-state.json"

    root_run = Run.model_validate_json(root_run_path.read_text(encoding="utf-8"))
    child_run = Run.model_validate_json(child_run_path.read_text(encoding="utf-8"))
    headless_state = cast(dict[str, object], json.loads(headless_state_path.read_text(encoding="utf-8")))

    root_run_path.write_text(
        root_run.model_copy(update={"status": "failed"}).model_dump_json(indent=2),
        encoding="utf-8",
    )
    child_run_path.write_text(
        child_run.model_copy(update={"status": "running"}).model_dump_json(indent=2),
        encoding="utf-8",
    )
    headless_state["current_stage"] = "failed"
    headless_state["terminal_outcome"] = "failed"
    headless_state_path.write_text(json.dumps(headless_state, indent=2), encoding="utf-8")

    writer.audit_turns = 1
    resumed_frontend = ScriptedTerminalFrontend(inputs=["replace"])
    resumed = run_terminal(
        repo_root=repo_root,
        frontend=resumed_frontend,
        approve_all=True,
        session_manager_factory=session_manager_factory,
        resume=True,
    )

    assert resumed.mode == "completed"
    assert "Recovery review" in resumed_frontend.output_text()
    assert "Run: run-child-1" in resumed_frontend.output_text()
    assert "Mission completed: run-root" in resumed_frontend.output_text()


def make_git_repo(tmp_path: Path) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    run_git(repo_root, "init", "-b", "main")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    run_git(repo_root, "add", "README.md")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "initial",
    )
    return repo_root


def run_git(repo_root: Path, *args: str) -> None:
    import subprocess

    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
