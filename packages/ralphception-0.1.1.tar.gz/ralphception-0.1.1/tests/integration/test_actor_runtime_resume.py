from __future__ import annotations

import json
from pathlib import Path

from ralphception.actor_runtime.planner_actor import PlannerActor
from ralphception.models.mission import ExecutionPolicy, MissionSession, PlannerOutput
from ralphception.storage.mission_store import MissionStore


def test_planner_actor_writes_todo_graph_and_commit_intents(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    specs_dir = repo_root / ".ralphception" / "specs"
    plans_dir.mkdir(parents=True)
    specs_dir.mkdir(parents=True)
    approved_spec_path = specs_dir / "mission-spec.md"
    approved_spec_path.write_text("# Approved Spec\n", encoding="utf-8")
    (plans_dir / "mission-plan.md").write_text("# Mission Plan\n", encoding="utf-8")
    (plans_dir / "mission-plan.json").write_text(
        json.dumps(
            {
                "execution_goal": "Implement the parser artifact.",
                "verification_commands": ['uv run pytest tests/unit/test_runtime_supervisor.py -q'],
                "todos": [
                    {
                        "todo_id": "todo-1",
                        "title": "Implement parser artifact",
                        "dependency_ids": [],
                        "status": "ready",
                        "commit_intent_id": "intent-1",
                        "scope_hints": ["src/parser.py"],
                    },
                    {
                        "todo_id": "todo-2",
                        "title": "Add parser regression test",
                        "dependency_ids": ["todo-1"],
                        "status": "blocked",
                        "commit_intent_id": "intent-1",
                        "scope_hints": ["tests/test_parser.py"],
                    },
                ],
                "commit_intents": [
                    {
                        "intent_id": "intent-1",
                        "message": "feat: add parser artifact",
                        "todo_ids": ["todo-1", "todo-2"],
                        "ordering_after": [],
                    }
                ],
                "execution_policy": {
                    "max_parallel_children": 2,
                    "batch_by_scope": True,
                    "allow_commit_split": True,
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    store = MissionStore(repo_root)
    store.write_session(
        MissionSession(
            mission_id="run-root",
            repo_root=str(repo_root),
            phase="planning",
            approved_spec_version=1,
        )
    )

    output = PlannerActor(repo_root=repo_root, store=store).plan(approved_spec_path=approved_spec_path)

    assert output == PlannerOutput(
        plan_markdown_path=".ralphception/plans/mission-plan.md",
        plan_json_path=".ralphception/plans/mission-plan.json",
        todo_ids=["todo-1", "todo-2"],
        commit_intent_ids=["intent-1"],
        execution_policy=ExecutionPolicy(
            max_parallel_children=2,
            batch_by_scope=True,
            allow_commit_split=True,
        ),
    )
    assert [todo.todo_id for todo in store.read_todos()] == ["todo-1", "todo-2"]
    assert [intent.intent_id for intent in store.read_commit_intents()] == ["intent-1"]
    assert store.read_planner_output() == output
