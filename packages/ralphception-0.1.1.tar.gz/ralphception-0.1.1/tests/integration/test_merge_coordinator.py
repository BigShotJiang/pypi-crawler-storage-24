import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from ralphception.git.merge import (
    MergeCoordinator,
    reconcile_partial_merge,
    validate_handoff,
    validate_handoff_paths,
)
from ralphception.git.worktrees import WorktreeCoordinator
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ChildAssignment, ExecutionBundle
from ralphception.storage.checkpoints import checkpoint_path
from ralphception.models.worktree import WorktreeHandoff
from ralphception.storage.events import EventStore
from ralphception.storage.lease import read_workspace_lease, write_workspace_lease
from ralphception.workflow.bundles import create_bundle


def test_validate_handoff_marks_stale_when_bundle_is_outdated(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-3",
        run_id="run-root",
        bundle_version=3,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(repo_root, consumed_bundle_version=2)

    result = validate_handoff(
        repo_root=repo_root,
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[artifact_ref(".ralphception/specs/runtime.md", "spec", content_hash="sha256:older-spec")],
        newest_required_verification_passed=True,
    )

    assert result.status == "stale"
    assert "newer execution bundle" in result.reasons[0]


def test_validate_handoff_allows_in_scope_revalidation_when_version_only_advanced(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    dependency = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-3",
        run_id="run-root",
        bundle_version=3,
        state="approved",
        artifact_refs=[dependency],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(repo_root, consumed_bundle_version=2)

    result = validate_handoff(
        repo_root=repo_root,
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[dependency],
        newest_required_verification_passed=True,
        changed_dependency_paths=[],
    )

    assert result.status == "ready"
    assert result.requires_revalidation is True


def test_validate_handoff_blocks_non_consumable_latest_bundle(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-3",
        run_id="run-root",
        bundle_version=3,
        state="draft",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(repo_root, consumed_bundle_version=2)

    result = validate_handoff(
        repo_root=repo_root,
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[spec_ref],
        newest_required_verification_passed=True,
    )

    assert result.status == "blocked"
    assert result.reasons == ["latest bundle is not consumable"]


def test_validate_handoff_allows_revalidation_when_no_dependencies_changed(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-3",
        run_id="run-root",
        bundle_version=3,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(repo_root, consumed_bundle_version=2)

    result = validate_handoff(
        repo_root=repo_root,
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
    )

    assert result.status == "ready"
    assert result.requires_revalidation is True


def test_validate_handoff_marks_touched_scope_changes_stale_before_verification(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-3",
        run_id="run-root",
        bundle_version=3,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(repo_root, consumed_bundle_version=2)

    result = validate_handoff(
        repo_root=repo_root,
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[spec_ref],
        newest_required_verification_passed=False,
        acceptance_criteria_changed=True,
        changed_touched_paths=["src/parser.py"],
    )

    assert result.status == "stale"
    assert result.requires_revalidation is False


def test_validate_handoff_blocks_outdated_handoff_until_newest_verification_passes(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-3",
        run_id="run-root",
        bundle_version=3,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(repo_root, consumed_bundle_version=2)

    result = validate_handoff(
        repo_root=repo_root,
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=False,
    )

    assert result.status == "blocked"
    assert result.reasons == ["newest required merge verification has not passed"]
    assert result.requires_revalidation is True


def test_merge_rejects_forbidden_shared_ralphception_paths(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    handoff = make_handoff(
        repo_root,
        touched_paths=[".ralphception/specs/spec.md"],
        artifact_refs=[artifact_ref(".ralphception/specs/spec.md", "spec", content_hash="sha256:forbidden")],
    )

    result = validate_handoff_paths(handoff)

    assert result.status == "blocked"
    assert result.forbidden_paths == [".ralphception/specs/spec.md"]


def test_validate_handoff_paths_blocks_child_event_log_paths(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    handoff = make_handoff(
        repo_root,
        touched_paths=[".ralphception/events/run-child-1.jsonl"],
        artifact_refs=[
            artifact_ref(
                ".ralphception/events/run-child-1.jsonl",
                "event_log",
                content_hash="sha256:event-log",
            ),
        ],
    )

    result = validate_handoff_paths(handoff)

    assert result.status == "blocked"
    assert result.forbidden_paths == [".ralphception/events/run-child-1.jsonl"]


def test_finalize_merge_squash_merges_child_commit_and_records_artifact_promotion(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Port parser module",
    )
    child_file = child.worktree_path / "src" / "parser.py"
    child_file.parent.mkdir(parents=True)
    child_file.write_text("VALUE = 1\n", encoding="utf-8")
    run_git(child.worktree_path, "add", "src/parser.py")
    run_git(
        child.worktree_path,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "add parser",
    )
    head_commit = git_output(child.worktree_path, "rev-parse", "HEAD")
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=head_commit,
        consumed_bundle_version=2,
        artifact_refs=[artifact_ref("src/parser.py", "code", content_hash="sha256:parser-v1")],
        touched_paths=["src/parser.py"],
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
    )

    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )
    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_passes,
    )

    assert outcome.status == "merged"
    assert (outcome.integration_worktree_path / "src" / "parser.py").read_text(encoding="utf-8") == "VALUE = 1\n"
    lease = read_workspace_lease(repo_root, xdg_state_home=xdg_state_home)
    assert lease is not None
    assert lease.authoritative_repository_root == outcome.integration_worktree_path
    assert outcome.promoted_artifact_refs == handoff.artifact_refs
    merge_record = json.loads(outcome.merge_record_path.read_text(encoding="utf-8"))
    assert merge_record["status"] == "merged"
    assert merge_record["merge_commit"] == git_output(repo_root, "rev-parse", "main")
    events = EventStore(outcome.integration_worktree_path).read_run("run-root")
    assert [event.event_type for event in events][-2:] == ["artifact.promoted", "merge.completed"]


def test_finalize_merge_uses_contextual_commit_message_from_assignment(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Repair terminal resume flow",
    )
    child_file = child.worktree_path / "src" / "terminal.py"
    child_file.parent.mkdir(parents=True)
    child_file.write_text("VALUE = 1\n", encoding="utf-8")
    run_git(child.worktree_path, "add", "src/terminal.py")
    run_git(
        child.worktree_path,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "worker change",
    )
    head_commit = git_output(child.worktree_path, "rev-parse", "HEAD")
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=head_commit,
        consumed_bundle_version=2,
        artifact_refs=[artifact_ref("src/terminal.py", "code", content_hash="sha256:terminal-v1")],
        touched_paths=["src/terminal.py"],
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
        final_commit_message="fix: repair terminal resume flow",
    )

    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )
    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_passes,
    )

    assert outcome.status == "merged"
    assert git_output(repo_root, "log", "-1", "--pretty=%s", "main") == "fix: repair terminal resume flow"


def test_finalize_merge_promotes_child_scoped_outputs_via_parent_merge(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Port parser module",
    )
    child_file = child.worktree_path / "src" / "parser.py"
    child_file.parent.mkdir(parents=True)
    child_file.write_text("VALUE = 1\n", encoding="utf-8")
    child_summary = child.worktree_path / ".ralphception" / "runs" / "run-child-1" / "summary.md"
    child_summary.parent.mkdir(parents=True)
    child_summary.write_text("child summary\n", encoding="utf-8")
    run_git(child.worktree_path, "add", "src/parser.py", ".ralphception/runs/run-child-1/summary.md")
    run_git(
        child.worktree_path,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "add parser and child summary",
    )
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    summary_ref = artifact_ref(
        ".ralphception/runs/run-child-1/summary.md",
        "child_summary",
        content_hash="sha256:summary-v1",
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=git_output(child.worktree_path, "rev-parse", "HEAD"),
        consumed_bundle_version=2,
        artifact_refs=[
            artifact_ref("src/parser.py", "code", content_hash="sha256:parser-v1"),
            summary_ref,
        ],
        touched_paths=["src/parser.py", ".ralphception/runs/run-child-1/summary.md"],
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
    )
    child_summary.write_text("mutated after handoff\n", encoding="utf-8")
    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )

    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_passes,
    )

    assert outcome.status == "merged"
    assert summary_ref in outcome.promoted_artifact_refs
    assert (
        outcome.integration_worktree_path / ".ralphception" / "runs" / "run-child-1" / "summary.md"
    ).read_text(encoding="utf-8") == "child summary\n"


def test_finalize_merge_blocks_outdated_handoff_without_durable_merge_context(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Port parser module",
    )
    child_file = child.worktree_path / "src" / "parser.py"
    child_file.parent.mkdir(parents=True)
    child_file.write_text("VALUE = 1\n", encoding="utf-8")
    run_git(child.worktree_path, "add", "src/parser.py")
    run_git(
        child.worktree_path,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "add parser",
    )
    spec_ref = make_spec_artifact(repo_root)
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    latest_bundle = create_bundle(
        repo_root,
        bundle_id="bundle-3",
        run_id="run-root",
        bundle_version=3,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=git_output(child.worktree_path, "rev-parse", "HEAD"),
        consumed_bundle_version=2,
        artifact_refs=[artifact_ref("src/parser.py", "code", content_hash="sha256:parser-v1")],
        touched_paths=["src/parser.py"],
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
    )
    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )

    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=latest_bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_passes,
    )

    assert outcome.status == "merged"
    merge_context = repo_root / ".ralphception" / "runs" / "run-child-1" / "merge_context.json"
    assert merge_context.exists()


def test_finalize_merge_blocks_when_merge_verification_fails(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Port parser module",
    )
    child_file = child.worktree_path / "src" / "parser.py"
    child_file.parent.mkdir(parents=True)
    child_file.write_text("VALUE = 1\n", encoding="utf-8")
    run_git(child.worktree_path, "add", "src/parser.py")
    run_git(
        child.worktree_path,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "add parser",
    )
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=git_output(child.worktree_path, "rev-parse", "HEAD"),
        consumed_bundle_version=2,
        artifact_refs=[artifact_ref("src/parser.py", "code", content_hash="sha256:parser-v1")],
        touched_paths=["src/parser.py"],
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
    )
    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )

    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_fails,
    )

    assert outcome.status == "blocked"
    assert outcome.reasons == ["merge-time verification failed"]
    assert git_output(repo_root, "rev-parse", "main") == git_output(repo_root, "rev-parse", "HEAD")


def test_finalize_merge_promotes_child_scoped_verification_outputs(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Port parser module",
    )
    child_file = child.worktree_path / "src" / "parser.py"
    child_file.parent.mkdir(parents=True)
    child_file.write_text("VALUE = 1\n", encoding="utf-8")
    verification_output = child.worktree_path / ".ralphception" / "runs" / "run-child-1" / "verify.json"
    verification_output.parent.mkdir(parents=True)
    verification_output.write_text("{\"status\": \"passed\"}\n", encoding="utf-8")
    run_git(child.worktree_path, "add", "src/parser.py", ".ralphception/runs/run-child-1/verify.json")
    run_git(
        child.worktree_path,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "add parser and verification output",
    )
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    verification_ref = artifact_ref(
        ".ralphception/runs/run-child-1/verify.json",
        "verification_result",
        content_hash="sha256:verify-v1",
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=git_output(child.worktree_path, "rev-parse", "HEAD"),
        consumed_bundle_version=2,
        artifact_refs=[artifact_ref("src/parser.py", "code", content_hash="sha256:parser-v1")],
        touched_paths=["src/parser.py", ".ralphception/runs/run-child-1/verify.json"],
    )
    handoff = WorktreeHandoff(
        child_run_id=handoff.child_run_id,
        worktree_path=handoff.worktree_path,
        branch_name=handoff.branch_name,
        base_branch=handoff.base_branch,
        head_commit=handoff.head_commit,
        goal=handoff.goal,
        artifact_refs=handoff.artifact_refs,
        verification_artifact_refs=[verification_ref],
        consumed_bundle_version=handoff.consumed_bundle_version,
        touched_paths=handoff.touched_paths,
        verification_summary=handoff.verification_summary,
        merge_readiness=handoff.merge_readiness,
        cleanup_state=handoff.cleanup_state,
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
    )
    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )

    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_passes,
    )

    assert outcome.status == "merged"
    assert verification_ref in outcome.promoted_artifact_refs
    merge_record = json.loads(outcome.merge_record_path.read_text(encoding="utf-8"))
    assert any(
        record["artifact_path"] == ".ralphception/runs/run-child-1/verify.json"
        for record in merge_record["promoted_artifact_refs"]
    )


def test_finalize_merge_blocks_underreported_forbidden_shared_ralphception_change(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Port parser module",
    )
    forbidden = child.worktree_path / ".ralphception" / "specs" / "spec.md"
    forbidden.parent.mkdir(parents=True, exist_ok=True)
    forbidden.write_text("forbidden child spec edit\n", encoding="utf-8")
    run_git(child.worktree_path, "add", ".ralphception/specs/spec.md")
    run_git(
        child.worktree_path,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "forbidden shared spec edit",
    )
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=git_output(child.worktree_path, "rev-parse", "HEAD"),
        consumed_bundle_version=2,
        artifact_refs=[artifact_ref("src/parser.py", "code", content_hash="sha256:parser-v1")],
        touched_paths=["src/parser.py"],
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
    )
    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )

    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_passes,
    )

    assert outcome.status == "blocked"
    assert (repo_root / ".ralphception" / "specs" / "spec.md").exists() is False


def test_finalize_merge_switches_authoritative_root_when_operator_checkout_is_dirty(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    (repo_root / "README.md").write_text("repo dirty\n", encoding="utf-8")
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Port parser module",
    )
    child_file = child.worktree_path / "src" / "parser.py"
    child_file.parent.mkdir(parents=True)
    child_file.write_text("VALUE = 1\n", encoding="utf-8")
    run_git(child.worktree_path, "add", "src/parser.py")
    run_git(
        child.worktree_path,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "add parser",
    )
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=git_output(child.worktree_path, "rev-parse", "HEAD"),
        consumed_bundle_version=2,
        artifact_refs=[artifact_ref("src/parser.py", "code", content_hash="sha256:parser-v1")],
        touched_paths=["src/parser.py"],
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
    )
    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )

    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_passes,
    )

    assert outcome.status == "merged"
    lease = read_workspace_lease(repo_root, xdg_state_home=xdg_state_home)
    assert lease is not None
    assert lease.authoritative_repository_root == outcome.integration_worktree_path
    assert (repo_root / "src" / "parser.py").exists() is False
    assert checkpoint_path(repo_root, "run-root", "checkpoint-1").exists()
    assert outcome.merge_record_path.is_relative_to(outcome.integration_worktree_path)
    integration_events = EventStore(outcome.integration_worktree_path).read_run("run-root")
    assert integration_events[-1].event_type == "merge.completed"
    assert (
        outcome.integration_worktree_path / ".ralphception" / "runs" / "run-child-1" / "assignment.json"
    ).exists()


def test_finalize_merge_treats_internal_ralphception_changes_as_dirty(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    internal_note = repo_root / ".ralphception" / "plans" / "draft.md"
    internal_note.parent.mkdir(parents=True, exist_ok=True)
    internal_note.write_text("internal plan note\n", encoding="utf-8")
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Port parser module",
    )
    child_file = child.worktree_path / "src" / "parser.py"
    child_file.parent.mkdir(parents=True)
    child_file.write_text("VALUE = 1\n", encoding="utf-8")
    run_git(child.worktree_path, "add", "src/parser.py")
    run_git(
        child.worktree_path,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "add parser",
    )
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=git_output(child.worktree_path, "rev-parse", "HEAD"),
        consumed_bundle_version=2,
        artifact_refs=[artifact_ref("src/parser.py", "code", content_hash="sha256:parser-v1")],
        touched_paths=["src/parser.py"],
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
    )
    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )

    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_passes,
    )

    assert outcome.status == "merged"
    lease = read_workspace_lease(repo_root, xdg_state_home=xdg_state_home)
    assert lease is not None
    assert lease.authoritative_repository_root == outcome.integration_worktree_path
    assert checkpoint_path(repo_root, "run-root", "checkpoint-1").exists()


def test_finalize_merge_requests_conflict_resolution_child_run(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    run_git(repo_root, "checkout", "-b", "codex/seed")
    (repo_root / "README.md").write_text("seed branch\n", encoding="utf-8")
    run_git(repo_root, "add", "README.md")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "seed branch change",
    )
    run_git(repo_root, "checkout", "main")
    (repo_root / "README.md").write_text("main branch\n", encoding="utf-8")
    run_git(repo_root, "add", "README.md")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "main branch change",
    )
    worktrees = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = worktrees.create_child_worktree(
        run_id="run-child-1",
        base_ref="codex/seed",
        target_branch="run-child-1",
        goal="Port parser module",
    )
    spec_ref = make_spec_artifact(repo_root)
    bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref],
        stage_id="stage-execute-1",
        created_at=utc_now(),
    )
    handoff = make_handoff(
        repo_root,
        child_run_id="run-child-1",
        worktree_path=child.worktree_path,
        branch_name=child.branch_name,
        head_commit=git_output(child.worktree_path, "rev-parse", "HEAD"),
        consumed_bundle_version=2,
        artifact_refs=[artifact_ref("README.md", "code", content_hash="sha256:readme-v2")],
        touched_paths=["README.md"],
    )
    write_child_assignment(
        repo_root,
        child_run_id="run-child-1",
        goal=handoff.goal,
        bundle_version=2,
    )
    requested_goals: list[str] = []
    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="stage-merge-1",
        target_branch="main",
        xdg_state_home=xdg_state_home,
    )

    outcome = coordinator.finalize_merge(
        handoff=handoff,
        latest_bundle=bundle,
        latest_goal=handoff.goal,
        dependency_refs=[],
        newest_required_verification_passed=True,
        run_merge_verification=merge_verification_passes,
        spawn_conflict_run=requested_goals.append,
    )

    assert outcome.status == "conflict"
    assert requested_goals == ["Resolve merge conflicts for run-child-1 into main"]
    assert git_output(outcome.integration_worktree_path, "status", "--short") == ""


def test_partial_merge_recovery_retries_when_integration_never_updated() -> None:
    outcome = reconcile_partial_merge(
        integration_updated=False,
        branch_moved=False,
        lease_updated=False,
        checkout_updated=False,
        requires_authoritative_root_shift=False,
    )

    assert outcome.resume_action == "retry_merge"
    assert outcome.requires_lease_fix is False
    assert outcome.requires_checkout_fix is False


def test_partial_merge_recovery_reconciles_updated_integration_before_branch_move() -> None:
    outcome = reconcile_partial_merge(
        integration_updated=True,
        branch_moved=False,
        lease_updated=False,
        checkout_updated=False,
        requires_authoritative_root_shift=False,
    )

    assert outcome.resume_action == "complete_or_rollback_integration"


def test_partial_merge_recovery_reconciles_branch_and_lease() -> None:
    outcome = reconcile_partial_merge(
        integration_updated=True,
        branch_moved=True,
        lease_updated=False,
        checkout_updated=False,
        requires_authoritative_root_shift=True,
    )

    assert outcome.resume_action == "reconcile_branch_and_lease"
    assert outcome.requires_lease_fix is True
    assert outcome.requires_checkout_fix is False


def make_handoff(
    repo_root: Path,
    *,
    child_run_id: str = "run-child-1",
    worktree_path: Path | None = None,
    branch_name: str = "codex/run-child-1",
    head_commit: str = "a" * 40,
    consumed_bundle_version: int = 2,
    artifact_refs: list[ArtifactRef] | None = None,
    touched_paths: list[str] | None = None,
) -> WorktreeHandoff:
    return WorktreeHandoff(
        child_run_id=child_run_id,
        worktree_path=str(worktree_path or (repo_root / ".worktrees" / child_run_id)),
        branch_name=branch_name,
        base_branch="main",
        head_commit=head_commit,
        goal="Port parser module",
        artifact_refs=artifact_refs
        or [artifact_ref("src/parser.py", "code", content_hash="sha256:parser-v1")],
        verification_artifact_refs=[],
        consumed_bundle_version=consumed_bundle_version,
        touched_paths=touched_paths or ["src/parser.py"],
        verification_summary="typecheck and tests passed",
        merge_readiness="ready",
        cleanup_state="pending",
    )


def artifact_ref(path: str, kind: str, *, content_hash: str) -> ArtifactRef:
    return ArtifactRef(
        artifact_kind=kind,
        artifact_path=path,
        artifact_version=1,
        content_hash=content_hash,
    )


def make_spec_artifact(repo_root: Path) -> ArtifactRef:
    return artifact_ref(".ralphception/specs/runtime.md", "spec", content_hash="sha256:spec-v1")


def write_child_assignment(
    repo_root: Path,
    *,
    child_run_id: str,
    goal: str,
    bundle_version: int,
    dependency_refs: list[ArtifactRef] | None = None,
    acceptance_criteria_refs: list[ArtifactRef] | None = None,
    final_commit_message: str | None = None,
) -> Path:
    assignment = ChildAssignment(
        assignment_id=f"assignment-{child_run_id}",
        goal=goal,
        acceptance_criteria_refs=acceptance_criteria_refs or [],
        dependency_refs=dependency_refs or [],
        bundle_version=bundle_version,
        final_commit_message=final_commit_message,
    )
    path = repo_root / ".ralphception" / "runs" / child_run_id / "assignment.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(assignment.model_dump_json(indent=2) + "\n", encoding="utf-8")
    return path


def make_git_repo(tmp_path: Path) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    run_git(repo_root, "init", "-b", "main")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    spec_path = repo_root / ".ralphception" / "specs" / "runtime.md"
    spec_path.parent.mkdir(parents=True)
    spec_path.write_text("# Runtime spec\n", encoding="utf-8")
    run_git(repo_root, "add", "README.md", ".ralphception/specs/runtime.md")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "init",
    )
    return repo_root


def git_output(cwd: Path, *args: str) -> str:
    return run_git(cwd, *args).stdout.strip()


def run_git(cwd: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        check=True,
        cwd=cwd,
        capture_output=True,
        text=True,
    )


def merge_verification_passes(_: Path) -> bool:
    return True


def merge_verification_fails(_: Path) -> bool:
    return False


def utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
