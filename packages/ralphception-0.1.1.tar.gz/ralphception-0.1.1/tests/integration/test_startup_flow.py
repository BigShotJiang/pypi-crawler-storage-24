from __future__ import annotations

import asyncio
import hashlib
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
from unittest.mock import patch

import pytest
from textual.app import App
from textual.containers import VerticalScroll
from textual.widgets import Button, RichLog, Static, TextArea

from ralphception.app import resolve_runtime_view, run_headless
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.mission import MissionSession
from ralphception.models.runtime import Run, RunStageStatus, Stage, StageKind
from ralphception.models.session import ChildSessionRef
from ralphception.runtime.terminal import ScriptedTerminalFrontend, run_terminal
from ralphception.runtime.supervisor import RuntimeBackendUnavailableError
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic
from ralphception.storage.mission_store import MissionStore
from ralphception.testing.fakes import build_fake_session_manager
from ralphception.ui.screens.review import ArtifactReviewController, ReviewScreen
from ralphception.ui.screens.startup import (
    StartupBootstrapController,
    StartupScreen,
    load_startup_record,
)
from ralphception.workflow.recovery import ResumeResult
from ralphception.workflow.approvals import (
    create_execution_bundle_approval,
    create_spec_review,
    persist_approval,
    read_approval,
)
from ralphception.workflow.bundles import create_bundle, read_bundle
from ralphception.workflow.engine import WorkflowEngine


def test_first_run_captures_seed_prompt_and_source_repos(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    source_repo = repo_root / "source-repo"
    source_repo.mkdir()
    controller = StartupBootstrapController(repo_root)

    launch = resolve_runtime_view(repo_root)
    result = controller.start_first_run(
        seed_prompt="port parser",
        source_repos=[source_repo],
    )
    persisted = load_startup_record(repo_root)
    events = EventStore(repo_root).read_run(result.outer_run_id)
    next_launch = resolve_runtime_view(repo_root)

    assert launch.mode == "startup"
    assert launch.supervisor is not None
    assert launch.frontend_kind == "tui"
    assert result.outer_run_id == "run-root"
    assert result.seed_prompt == "port parser"
    assert result.source_repos == [str(source_repo.resolve())]
    assert persisted == result
    assert [event.event_type for event in events] == ["run.created"]
    assert next_launch.mode == "dashboard"
    assert next_launch.supervisor is not None
    assert next_launch.frontend_kind == "tui"


def test_startup_screen_captures_first_run_interactively(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    source_repo = repo_root / "source-repo"
    source_repo.mkdir()
    screen = StartupScreen(StartupBootstrapController(repo_root))
    app = StartupScreenHarness(screen)

    return_value, _ = asyncio.run(
        submit_startup_form(
            app,
            seed_prompt="port parser",
            source_repos=str(source_repo),
        )
    )

    persisted = load_startup_record(repo_root)
    launch = resolve_runtime_view(repo_root)

    assert return_value == "bootstrapped"
    assert persisted is not None
    assert persisted.seed_prompt == "port parser"
    assert persisted.source_repos == [str(source_repo.resolve())]
    assert launch.mode == "dashboard"


def test_startup_screen_rejects_blank_seed_prompt(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    screen = StartupScreen(StartupBootstrapController(repo_root))
    app = StartupScreenHarness(screen)

    _, feedback = asyncio.run(submit_startup_form(app, seed_prompt="   ", source_repos=""))

    assert feedback == "Seed prompt is required."
    assert load_startup_record(repo_root) is None
    assert resolve_runtime_view(repo_root).mode == "startup"


def test_terminal_launch_enters_socratic_intake_before_any_plan_artifacts(tmp_path: Path) -> None:
    repo_root = tmp_path / "terminal-intake-repo"
    repo_root.mkdir()
    _init_git_repo_with_commit(repo_root)
    frontend = ScriptedTerminalFrontend(inputs=["find any bugs", "", "pause"])

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        use_fake_session_manager=True,
    )

    session = MissionStore(repo_root).read_session()
    launch = resolve_runtime_view(repo_root)

    assert result.mode == "running"
    assert "Socratic intake" in frontend.output_text()
    assert "Review action" in frontend.output_text()
    assert session == MissionSession(
        mission_id="run-root",
        repo_root=str(repo_root),
        phase="spec_review",
        approved_spec_version=None,
    )
    assert not (repo_root / ".ralphception" / "plans" / "mission-plan.json").exists()
    assert launch.mode == "review"


def test_spec_review_requires_spec_review_approval(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Review before planning.\n",
    )

    launch = resolve_runtime_view(repo_root)

    assert launch.mode == "review"
    assert launch.review_controller is not None
    assert launch.review_controller.can_enter_plan_generation is False
    target = launch.review_controller.current_target()
    assert target is not None
    assert target.kind == "spec_review"

    diff = launch.review_controller.diff_current_target()
    approval = launch.review_controller.approve_current_target(approver="user")

    assert "Runtime Spec" in diff.rendered_text
    assert approval.approval_kind == "spec_review"
    assert launch.review_controller.can_enter_plan_generation is True


def test_review_screen_can_diff_pending_execution_bundle(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Bundle approval is explicit.\n",
    )
    persist_approval(
        repo_root,
        create_spec_review(
            approval_id="approval-spec-1",
            run_id="run-root",
            approver="user",
            spec_artifacts=[spec_ref],
            bundle_version=1,
            scope_hash="sha256:spec-scope",
            approved_at=utc_now(),
        ),
    )
    plan_v1_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n- Reuse approved bundle.\n",
    )
    approved_bundle = create_bundle(
        repo_root,
        bundle_id="bundle-1",
        run_id="run-root",
        bundle_version=1,
        state="approved",
        artifact_refs=[spec_ref, plan_v1_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )
    persist_approval(
        repo_root,
        create_execution_bundle_approval(
            approval_id="approval-exec-1",
            approver="user",
            bundle=approved_bundle,
            approved_at=utc_now(),
        ),
    )
    plan_v2_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=2,
        content="# Runtime Plan\n\n- Review the pending bundle diff.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_v2_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )

    launch = resolve_runtime_view(repo_root)

    assert launch.mode == "review"
    assert launch.review_controller is not None
    target = launch.review_controller.current_target()
    assert target is not None
    assert target.kind == "execution_bundle"
    diff = launch.review_controller.diff_current_target()
    assert "Reuse approved bundle" in diff.rendered_text
    assert "Review the pending bundle diff" in diff.rendered_text
    assert isinstance(launch.screen, ReviewScreen)
    assert "Execution bundle review" in launch.screen.rendered_text()


def test_review_screen_allows_approving_pending_bundle_from_ui(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Bundle approval is explicit.\n",
    )
    persist_approval(
        repo_root,
        create_spec_review(
            approval_id="approval-spec-1",
            run_id="run-root",
            approver="user",
            spec_artifacts=[spec_ref],
            bundle_version=1,
            scope_hash="sha256:spec-scope",
            approved_at=utc_now(),
        ),
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n- Approve the pending execution bundle.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )

    launch = resolve_runtime_view(repo_root)
    assert isinstance(launch.screen, ReviewScreen)
    app = ReviewScreenHarness(launch.screen)

    async def exercise() -> tuple[str, str]:
        async with app.run_test() as pilot:
            await pilot.click("#review-target-execution-bundle-2")
            await pilot.click("#review-action-approve")
            await pilot.pause()
            feedback = str(app.query_one("#review-feedback", Static).renderable)
            details = str(app.query_one("#review-details", Static).renderable)
        return feedback, details

    feedback, details = asyncio.run(exercise())
    persisted_bundle = read_bundle(repo_root, run_id="run-root", bundle_id="bundle-2")

    assert "Approved execution_bundle target." in feedback
    assert persisted_bundle.state == "approved"
    assert "Review queue is clear." in details


def test_review_screen_prompts_for_feedback_before_requesting_changes(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Bundle approval is explicit.\n",
    )
    persist_approval(
        repo_root,
        create_spec_review(
            approval_id="approval-spec-1",
            run_id="run-root",
            approver="user",
            spec_artifacts=[spec_ref],
            bundle_version=1,
            scope_hash="sha256:spec-scope",
            approved_at=utc_now(),
        ),
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n- Feedback is required before requesting changes.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )

    launch = resolve_runtime_view(repo_root)
    assert isinstance(launch.screen, ReviewScreen)
    app = ReviewScreenHarness(launch.screen)

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.click("#review-target-execution-bundle-2")
            await pilot.click("#review-action-request-changes")
            await pilot.pause()
            return str(app.query_one("#review-feedback", Static).renderable)

    feedback = asyncio.run(exercise())
    persisted_bundle = read_bundle(repo_root, run_id="run-root", bundle_id="bundle-2")

    assert feedback == "Provide feedback before requesting changes."
    assert persisted_bundle.state == "awaiting_approval"
    assert not (repo_root / ".ralphception" / "reviews" / "execution_bundle-bundle-2.md").exists()


def test_review_screen_records_feedback_without_approving_bundle(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Bundle approval is explicit.\n",
    )
    persist_approval(
        repo_root,
        create_spec_review(
            approval_id="approval-spec-1",
            run_id="run-root",
            approver="user",
            spec_artifacts=[spec_ref],
            bundle_version=1,
            scope_hash="sha256:spec-scope",
            approved_at=utc_now(),
        ),
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n- Feedback is persisted until approval.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )

    launch = resolve_runtime_view(repo_root)
    assert isinstance(launch.screen, ReviewScreen)
    app = ReviewScreenHarness(launch.screen)

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.click("#review-target-execution-bundle-2")
            app.query_one("#review-feedback-input", TextArea).load_text("Please tighten the execution scope.")
            await pilot.click("#review-action-request-changes")
            await pilot.pause()
            return str(app.query_one("#review-feedback", Static).renderable)

    feedback = asyncio.run(exercise())
    persisted_bundle = read_bundle(repo_root, run_id="run-root", bundle_id="bundle-2")
    feedback_note = (repo_root / ".ralphception" / "reviews" / "execution_bundle-bundle-2.md").read_text(
        encoding="utf-8"
    )

    assert feedback == "Recorded feedback for execution_bundle target."
    assert persisted_bundle.state == "awaiting_approval"
    assert "Please tighten the execution scope." in feedback_note
    assert "Execution bundle target" in feedback_note


def test_review_controller_approves_pending_execution_bundle_and_unblocks_execute_stage(
    tmp_path: Path,
) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Bundle approval is explicit.\n",
    )
    persist_approval(
        repo_root,
        create_spec_review(
            approval_id="approval-spec-1",
            run_id="run-root",
            approver="user",
            spec_artifacts=[spec_ref],
            bundle_version=1,
            scope_hash="sha256:spec-scope",
            approved_at=utc_now(),
        ),
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n- Approve the pending execution bundle.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )

    launch = resolve_runtime_view(repo_root)
    assert launch.review_controller is not None

    assert launch.review_controller.can_enter_execution is False
    approval = launch.review_controller.approve_current_target(approver="user")
    persisted_bundle = read_bundle(repo_root, run_id="run-root", bundle_id="bundle-2")
    persisted_approval = read_approval(repo_root, approval_id=approval.approval_id)

    assert approval.approval_kind == "execution_bundle"
    assert persisted_approval == approval
    assert persisted_bundle.state == "approved"
    assert launch.review_controller.can_enter_execution is True
    assert launch.engine is not None
    assert launch.engine.stage("execute").status == "pending"


@pytest.mark.parametrize("child_status", ["blocked", "session_lost"])
def test_resolve_runtime_view_routes_to_review_for_recovery_eligible_child_runs(
    tmp_path: Path,
    child_status: RunStageStatus,
) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    child_run = make_run(
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Recover child",
        status=child_status,
        codex_session_ref=make_session_ref(run_id="run-child-1"),
    )
    persist_run_record(repo_root, child_run)

    launch = resolve_runtime_view(repo_root)

    assert launch.mode == "review"
    assert launch.review_controller is not None
    target = launch.review_controller.current_target()
    assert target is not None
    assert target.kind == "recovery"
    assert target.run_id == "run-child-1"


def test_resolve_runtime_view_wires_recovery_service_for_review_mode(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    child_run = make_run(
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Recover child",
        status="session_lost",
        codex_session_ref=make_session_ref(run_id="run-child-1"),
    )
    persist_run_record(repo_root, child_run)

    launch = resolve_runtime_view(repo_root)

    assert launch.mode == "review"
    assert launch.review_controller is not None
    assert launch.review_controller.recovery_service is not None


def test_retry_recovery_action_persists_run_state_across_runtime_reload(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    child_run = make_run(
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Recover child",
        status="failed",
        codex_session_ref=make_session_ref(run_id="run-child-1"),
    )
    persist_run_record(repo_root, child_run)

    launch = resolve_runtime_view(repo_root)
    assert launch.review_controller is not None

    retried = launch.review_controller.apply_recovery_action("run-child-1", "retry")
    reloaded = resolve_runtime_view(repo_root)
    persisted = Run.model_validate_json(
        (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").read_text(encoding="utf-8")
    )

    assert isinstance(retried, Run)
    assert retried.status == "pending"
    assert persisted.status == "pending"
    assert reloaded.mode == "dashboard"


def test_restart_recovery_action_persists_run_state_across_runtime_reload(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    original_session = make_session_ref(run_id="run-child-1")
    child_run = make_run(
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Recover child",
        status="session_lost",
        codex_session_ref=original_session,
    )
    persist_run_record(repo_root, child_run)

    launch = resolve_runtime_view(
        repo_root,
        session_manager_factory=build_fake_session_manager_for_repo,
    )
    assert launch.review_controller is not None

    restarted = launch.review_controller.apply_recovery_action("run-child-1", "restart")
    reloaded = resolve_runtime_view(
        repo_root,
        session_manager_factory=build_fake_session_manager_for_repo,
    )
    persisted = Run.model_validate_json(
        (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").read_text(encoding="utf-8")
    )

    assert isinstance(restarted, Run)
    assert restarted.status == "running"
    assert restarted.codex_session_ref is not None
    assert restarted.codex_session_ref.codex_thread_id != original_session.codex_thread_id
    assert persisted.status == "running"
    assert persisted.codex_session_ref == restarted.codex_session_ref
    assert reloaded.mode == "dashboard"


def test_resolve_runtime_view_starts_execution_for_approved_bundle(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Start execution from the launch path.\n",
    )
    persist_approval(
        repo_root,
        create_spec_review(
            approval_id="approval-spec-1",
            run_id="run-root",
            approver="user",
            spec_artifacts=[spec_ref],
            bundle_version=1,
            scope_hash="sha256:spec-scope",
            approved_at=utc_now(),
        ),
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n- Launch path schedules the first child run.\n",
    )
    approved_bundle = create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="approved",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )
    persist_approval(
        repo_root,
        create_execution_bundle_approval(
            approval_id="approval-exec-2",
            approver="user",
            bundle=read_bundle(repo_root, run_id="run-root", bundle_id=approved_bundle.bundle_id),
            approved_at=utc_now(),
        ),
    )

    launch = resolve_runtime_view(
        repo_root,
        session_manager_factory=build_fake_session_manager_for_repo,
    )

    assert launch.mode == "dashboard"
    assert launch.engine is not None
    assert launch.engine.stage("execute").status == "running"
    assert launch.dashboard_app is not None
    assert launch.dashboard_app.controller.recovery_service is not None
    child_run = launch.engine.run("run-child-1")
    assert child_run.goal == "Execute approved bundle v2 for port parser."
    assert child_run.codex_session_ref is not None
    assert (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").exists()


def test_run_headless_bootstraps_workspace_without_tui(tmp_path: Path) -> None:
    with patch("ralphception.runtime.supervisor.codex_cli_available", return_value=False):
        with pytest.raises(RuntimeBackendUnavailableError, match="No Codex session backend"):
            run_headless(
                repo_root=tmp_path,
                seed_prompt="port parser",
                source_repos=(),
            )

    assert load_startup_record(tmp_path) is None


def test_run_headless_auto_approves_review_targets_and_starts_execution(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    init_git_repo(repo_root)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Headless mode approves reviews.\n",
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n- Headless mode starts execution.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )

    result = run_headless(
        repo_root=repo_root,
        approve_all=True,
        approver="automation",
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert result.actions == (
        "approved:spec_review",
        "approved:execution_bundle",
        "merged:run-child-1",
        "reopened:audit",
        "merged:run-child-1-replacement-1",
    )
    assert result.review_target_kind is None
    assert result.root_run_status == "completed"
    assert result.child_run_ids == ("run-child-1", "run-child-1-replacement-1")
    assert not (repo_root / ".ralphception" / "runs" / "run-root" / "run.json").exists()
    assert resolve_runtime_view(repo_root).mode == "startup"


def test_review_screen_exposes_blocked_run_recovery_actions(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    session_manager = build_fake_session_manager(workspace_path=str(repo_root))
    session_manager.start_session(run_id="run-root", goal="Coordinate startup review")
    root_session = session_manager.get_session_ref("run-root")
    assert root_session is not None
    child_session = make_session_ref(run_id="run-child-1")
    child_run = make_run(
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Recover child",
        status="session_lost",
        codex_session_ref=child_session,
    )
    engine = WorkflowEngine(
        repo_root=repo_root,
        root_run=make_run(
            run_id="run-root",
            goal="Coordinate startup review",
            status="running",
            codex_session_ref=root_session,
        ),
        child_runs=[child_run],
        stages=[
            make_stage(stage_kind="intake", status="completed"),
            make_stage(stage_kind="spec", status="completed"),
            make_stage(stage_kind="plan", status="completed"),
            make_stage(stage_kind="execute", status="completed"),
        ],
        session_manager=session_manager,
    )
    recovery_service = FakeRecoveryService()
    controller = ArtifactReviewController(
        repo_root=repo_root,
        engine=engine,
        recovery_service=recovery_service,
    )

    target = controller.current_target()
    restarted = controller.apply_recovery_action("run-child-1", "restart")

    assert target is not None
    assert target.kind == "recovery"
    assert controller.recovery_actions("run-child-1") == ("/resume", "/restart")
    assert isinstance(restarted, Run)
    assert restarted.status == "running"
    assert recovery_service.restart_calls == ["run-child-1"]


def test_review_screen_resume_action_uses_recovery_service_for_session_lost_run(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    session_manager = build_fake_session_manager(workspace_path=str(repo_root))
    session_manager.start_session(run_id="run-root", goal="Coordinate startup review")
    root_session = session_manager.get_session_ref("run-root")
    assert root_session is not None
    engine = WorkflowEngine(
        repo_root=repo_root,
        root_run=make_run(
            run_id="run-root",
            goal="Coordinate startup review",
            status="running",
            codex_session_ref=root_session,
        ),
        child_runs=[
            make_run(
                run_id="run-child-1",
                parent_run_id="run-root",
                goal="Recover child",
                status="session_lost",
                codex_session_ref=make_session_ref(run_id="run-child-1"),
            ),
        ],
        stages=[
            make_stage(stage_kind="intake", status="completed"),
            make_stage(stage_kind="spec", status="completed"),
            make_stage(stage_kind="plan", status="completed"),
            make_stage(stage_kind="execute", status="completed"),
        ],
        session_manager=session_manager,
    )
    recovery_service = FakeRecoveryService()
    controller = ArtifactReviewController(
        repo_root=repo_root,
        engine=engine,
        recovery_service=recovery_service,
    )

    resumed = controller.apply_recovery_action("run-child-1", "resume")

    assert isinstance(resumed, ResumeResult)
    assert resumed.run_id == "run-child-1"
    assert resumed.mode == "read"
    assert recovery_service.resume_calls == [("run-child-1", "read")]
    assert recovery_service.replace_calls == []


def test_review_screen_allows_selecting_recovery_target_and_restart_from_ui(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    session_manager = build_fake_session_manager(workspace_path=str(repo_root))
    session_manager.start_session(run_id="run-root", goal="Coordinate startup review")
    root_session = session_manager.get_session_ref("run-root")
    assert root_session is not None
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Recovery actions stay in the review queue.\n",
    )
    persist_approval(
        repo_root,
        create_spec_review(
            approval_id="approval-spec-1",
            run_id="run-root",
            approver="user",
            spec_artifacts=[spec_ref],
            bundle_version=1,
            scope_hash="sha256:spec-scope",
            approved_at=utc_now(),
        ),
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n- Review queue remains interactive.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )
    child_run = make_run(
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Recover child",
        status="session_lost",
        codex_session_ref=make_session_ref(run_id="run-child-1"),
    )
    engine = WorkflowEngine(
        repo_root=repo_root,
        root_run=make_run(
            run_id="run-root",
            goal="Coordinate startup review",
            status="running",
            codex_session_ref=root_session,
        ),
        child_runs=[child_run],
        stages=[
            make_stage(stage_kind="intake", status="completed"),
            make_stage(stage_kind="spec", status="completed"),
            make_stage(stage_kind="plan", status="completed"),
            make_stage(stage_kind="execute", status="completed"),
        ],
        bundles=[read_bundle(repo_root, run_id="run-root", bundle_id="bundle-2")],
        approvals=[read_approval(repo_root, approval_id="approval-spec-1")],
        session_manager=session_manager,
    )
    recovery_service = FakeRecoveryService()
    screen = ReviewScreen(
        ArtifactReviewController(
            repo_root=repo_root,
            engine=engine,
            recovery_service=recovery_service,
        )
    )
    app = ReviewScreenHarness(screen)

    async def exercise() -> tuple[str, str]:
        async with app.run_test() as pilot:
            await pilot.click("#review-target-recovery-run-child-1")
            await pilot.pause()
            details_before = str(app.query_one("#review-details", Static).renderable)
            await pilot.click("#review-action-restart")
            await pilot.pause()
            feedback = str(app.query_one("#review-feedback", Static).renderable)
        return feedback, details_before

    feedback, details_before = asyncio.run(exercise())

    assert "Recovery target" in details_before
    assert "/restart" in details_before
    assert feedback == "Applied /restart to run-child-1."
    assert recovery_service.restart_calls == ["run-child-1"]


def test_review_screen_uses_independent_scroll_containers_for_targets_and_document(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    session_manager = build_fake_session_manager(workspace_path=str(repo_root))
    session_manager.start_session(run_id="run-root", goal="Coordinate startup review")
    root_session = session_manager.get_session_ref("run-root")
    assert root_session is not None
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n" + "\n".join(f"- baseline line {index}" for index in range(80)),
    )
    persist_approval(
        repo_root,
        create_spec_review(
            approval_id="approval-spec-1",
            run_id="run-root",
            approver="user",
            spec_artifacts=[spec_ref],
            bundle_version=1,
            scope_hash="sha256:spec-scope",
            approved_at=utc_now(),
        ),
    )
    baseline_plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n" + "\n".join(f"- baseline plan line {index}" for index in range(120)),
    )
    approved_bundle = create_bundle(
        repo_root,
        bundle_id="bundle-1",
        run_id="run-root",
        bundle_version=1,
        state="approved",
        artifact_refs=[spec_ref, baseline_plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )
    persist_approval(
        repo_root,
        create_execution_bundle_approval(
            approval_id="approval-exec-1",
            approver="user",
            bundle=approved_bundle,
            approved_at=utc_now(),
        ),
    )
    pending_plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=2,
        content="# Runtime Plan\n\n" + "\n".join(f"- pending plan line {index}" for index in range(160)),
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, pending_plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )
    child_runs = [
        make_run(
            run_id=f"run-child-{index}",
            parent_run_id="run-root",
            goal=f"Recover child {index}",
            status="session_lost",
            codex_session_ref=make_session_ref(run_id=f"run-child-{index}"),
        )
        for index in range(1, 18)
    ]
    engine = WorkflowEngine(
        repo_root=repo_root,
        root_run=make_run(
            run_id="run-root",
            goal="Coordinate startup review",
            status="running",
            codex_session_ref=root_session,
        ),
        child_runs=child_runs,
        stages=[
            make_stage(stage_kind="intake", status="completed"),
            make_stage(stage_kind="spec", status="completed"),
            make_stage(stage_kind="plan", status="completed"),
            make_stage(stage_kind="execute", status="blocked"),
        ],
        bundles=[read_bundle(repo_root, run_id="run-root", bundle_id="bundle-2")],
        approvals=[
            read_approval(repo_root, approval_id="approval-spec-1"),
            read_approval(repo_root, approval_id="approval-exec-1"),
        ],
        session_manager=session_manager,
    )
    screen = ReviewScreen(ArtifactReviewController(repo_root=repo_root, engine=engine))
    app = ReviewScreenHarness(screen)

    async def exercise() -> tuple[float, float]:
        async with app.run_test(size=(100, 18)) as pilot:
            target_scroll = app.query_one("#review-targets-scroll", VerticalScroll)
            document = app.query_one("#review-document", RichLog)
            target_scroll.scroll_to(y=6, animate=False)
            await pilot.pause()
            target_scroll_y = target_scroll.scroll_y
            document.action_scroll_down()
            await pilot.pause()
            return target_scroll_y, document.scroll_y

    target_scroll_y, document_scroll_y = asyncio.run(exercise())

    assert target_scroll_y > 0
    assert document_scroll_y > 0


def test_review_diff_handles_missing_current_artifact_file(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Bundle approval is explicit.\n",
    )
    persist_approval(
        repo_root,
        create_spec_review(
            approval_id="approval-spec-1",
            run_id="run-root",
            approver="user",
            spec_artifacts=[spec_ref],
            bundle_version=1,
            scope_hash="sha256:spec-scope",
            approved_at=utc_now(),
        ),
    )
    plan_v1_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=1,
        content="# Runtime Plan\n\n- Reuse approved bundle.\n",
    )
    approved_bundle = create_bundle(
        repo_root,
        bundle_id="bundle-1",
        run_id="run-root",
        bundle_version=1,
        state="approved",
        artifact_refs=[spec_ref, plan_v1_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )
    persist_approval(
        repo_root,
        create_execution_bundle_approval(
            approval_id="approval-exec-1",
            approver="user",
            bundle=approved_bundle,
            approved_at=utc_now(),
        ),
    )
    missing_plan_ref = ArtifactRef(
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        artifact_version=2,
        content_hash="sha256:missing-plan",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, missing_plan_ref],
        stage_id="stage-plan",
        created_at=utc_now(),
    )
    (repo_root / ".ralphception" / "plans" / "runtime.md").unlink()

    launch = resolve_runtime_view(repo_root)
    assert launch.review_controller is not None

    diff = launch.review_controller.diff_current_target()

    assert "Runtime Plan" in diff.rendered_text
    assert "missing from workspace" in diff.rendered_text


@dataclass
class FakeRecoveryService:
    resume_calls: list[tuple[str, str]] = field(default_factory=list)
    restart_calls: list[str] = field(default_factory=list)
    replace_calls: list[str] = field(default_factory=list)

    def retry_run(self, run_id: str) -> Run:
        raise AssertionError("retry_run should not be called in this test")

    def resume(self, *, run_id: str, mode: Literal["read", "repair"]) -> ResumeResult:
        self.resume_calls.append((run_id, mode))
        return ResumeResult(
            run_id=run_id,
            mode=mode,
            lease_taken=False,
            lease=None,
            checkpoint_reconciled=True,
            xdg_state_repaired=False,
            recommended_action="restart",
        )

    def restart_run(self, run_id: str) -> Run:
        self.restart_calls.append(run_id)
        return make_run(
            run_id=run_id,
            parent_run_id="run-root",
            goal="Recover child",
            status="running",
            codex_session_ref=make_session_ref(run_id=run_id),
        )

    def replace_run(self, run_id: str) -> Run:
        self.replace_calls.append(run_id)
        raise AssertionError("replace_run should not be called in this test")


class StartupScreenHarness(App[str | None]):
    def __init__(self, screen: StartupScreen) -> None:
        super().__init__()
        self._screen = screen

    def on_mount(self) -> None:
        self.push_screen(self._screen)


class ReviewScreenHarness(App[str | None]):
    def __init__(self, screen: ReviewScreen) -> None:
        super().__init__()
        self._screen = screen

    def on_mount(self) -> None:
        self.push_screen(self._screen)


async def submit_startup_form(
    app: StartupScreenHarness,
    *,
    seed_prompt: str,
    source_repos: str,
) -> tuple[str | None, str]:
    async with app.run_test() as pilot:
        app.query_one("#startup-seed-prompt", TextArea).load_text(seed_prompt)
        app.query_one("#startup-source-repos", TextArea).load_text(source_repos)
        await pilot.click("#startup-submit")
        await pilot.pause()
        feedback = str(app.query_one("#startup-feedback", Static).renderable)
    return app.return_value, feedback


def write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    artifact_version: int,
    content: str,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=artifact_version,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )


def persist_run_record(repo_root: Path, run: Run) -> None:
    write_json_atomic(
        repo_root / ".ralphception" / "runs" / run.run_id / "run.json",
        run.model_dump(mode="json"),
    )


def init_git_repo(repo_root: Path) -> None:
    subprocess.run(["git", "init", "-b", "main"], cwd=repo_root, check=True, capture_output=True, text=True)
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo_root, check=True, capture_output=True, text=True)
    subprocess.run(
        [
            "git",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-m",
            "initial",
        ],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )


def build_fake_session_manager_for_repo(repo_root: Path, config) -> object:
    return build_fake_session_manager(workspace_path=str(repo_root), config=config)


def _init_git_repo_with_commit(repo_root: Path) -> None:
    subprocess.run(["git", "init", "-b", "main"], check=True, cwd=repo_root, capture_output=True, text=True)
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], check=True, cwd=repo_root, capture_output=True, text=True)
    subprocess.run(
        [
            "git",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-m",
            "initial",
        ],
        check=True,
        cwd=repo_root,
        capture_output=True,
        text=True,
    )


def make_run(
    *,
    run_id: str,
    goal: str,
    status: RunStageStatus,
    parent_run_id: str | None = None,
    codex_session_ref: ChildSessionRef | None,
) -> Run:
    now = utc_now()
    return Run(
        run_id=run_id,
        parent_run_id=parent_run_id,
        supersedes_run_id=None,
        goal=goal,
        status=status,
        stage_ids=["stage-intake", "stage-spec", "stage-plan", "stage-execute"],
        config_snapshot={"codex": {"model": "gpt-5.4"}},
        codex_session_ref=codex_session_ref,
        artifact_refs=[],
        created_at=now,
        updated_at=now,
    )


def make_stage(*, stage_kind: StageKind, status: RunStageStatus) -> Stage:
    now = utc_now()
    started_at = None if status in {"pending", "awaiting_approval"} else now
    completed_at = now if status == "completed" else None
    return Stage(
        stage_id=f"stage-{stage_kind}",
        run_id="run-root",
        stage_kind=stage_kind,
        status=status,
        task_ids=[],
        started_at=started_at,
        completed_at=completed_at,
    )


def make_session_ref(*, run_id: str) -> ChildSessionRef:
    return ChildSessionRef(
        run_id=run_id,
        codex_thread_id=f"thread-{run_id}",
        codex_session_id=f"session-{run_id}",
        workspace_path="/repo",
        resumable=True,
        last_seen_at=utc_now(),
    )


def utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
