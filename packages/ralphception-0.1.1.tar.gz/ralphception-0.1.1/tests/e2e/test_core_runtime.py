from __future__ import annotations

import hashlib
import shutil
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import cast

from ralphception.app import resolve_runtime_view
from ralphception.audit.service import AuditService
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ApprovalRecord, ExecutionBundle, Run, Stage
from ralphception.models.verification import AuditFinding, FindingSeverity
from ralphception.runtime.terminal import ScriptedTerminalFrontend, run_terminal
from ralphception.storage.files import write_json_atomic
from ralphception.testing.fakes import build_fake_session_manager
from ralphception.ui.app import DashboardController
from ralphception.workflow.bundles import create_bundle
from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import RecoveryService

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def test_generic_seed_prompt_creates_ralphception_artifacts(tmp_path: Path) -> None:
    result = run_fixture_flow(tmp_path, "generic_repo")

    assert result.ralphception_dir.exists()


def test_porting_flow_treats_source_repo_as_read_only(tmp_path: Path) -> None:
    result = run_fixture_flow(tmp_path, "target_repo", source_repo_name="source_repo")

    assert result.source_repo_modified is False


def test_resume_rebuilds_state_from_events_and_checkpoint(tmp_path: Path) -> None:
    result = resume_fixture_flow(tmp_path, "target_repo")

    assert result.replayed_run_tree is True
    assert result.event_feed_before_resume == 0
    assert result.event_feed_after_resume > result.event_feed_before_resume


def test_launch_path_starts_execution_for_approved_bundle(tmp_path: Path) -> None:
    repo_root = _copy_fixture_repo(tmp_path, "target_repo")
    source_root = _copy_fixture_repo(tmp_path, "source_repo")

    _bootstrap_runtime(repo_root, source_root=source_root)
    spec_ref = _write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/porting-spec.md",
        content=_spec_text(repo_root, source_root),
    )
    _approve_current_review_target(repo_root)

    plan_ref = _write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/porting-plan.md",
        content=_plan_text(repo_root, source_root),
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=_utc_now(),
    )
    _approve_current_review_target(repo_root)

    launch = resolve_runtime_view(
        repo_root,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )

    assert launch.mode == "dashboard"
    assert launch.engine is not None
    assert launch.engine.stage("execute").status == "running"
    assert launch.dashboard_app is not None
    assert launch.dashboard_app.controller.recovery_service is not None
    assert any(entry.node_id == "run:run-child-1" for entry in launch.dashboard_app.controller.workflow_entries())
    assert (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").exists()


def test_audit_loop_does_not_reopen_work_for_p3_gap(tmp_path: Path) -> None:
    result = run_fixture_flow(tmp_path, "target_repo", source_repo_name="source_repo", inject_gap="P3")

    assert result.execution_reopened is False


def test_audit_loop_reopens_work_when_p1_gap_exists(tmp_path: Path) -> None:
    result = run_fixture_flow(tmp_path, "target_repo", source_repo_name="source_repo", inject_gap="P1")

    assert result.execution_reopened is True


def test_terminal_frontend_completion_returns_tui_launch_to_fresh_startup_state(tmp_path: Path, monkeypatch) -> None:
    repo_root = tmp_path / "terminal-runtime-repo"
    repo_root.mkdir()
    _init_git_repo_with_commit(repo_root)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend()

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )
    launch = resolve_runtime_view(repo_root)

    assert result.mode == "completed"
    assert "Runtime: completed" in frontend.output_text()
    assert launch.mode == "startup"
    assert launch.supervisor is not None
    assert result.authoritative_repo_root is not None
    assert launch.supervisor.repo_root == Path(result.authoritative_repo_root)
    assert launch.engine is None


def test_terminal_auto_proceeds_after_spec_approval_without_approve_all(tmp_path: Path, monkeypatch) -> None:
    repo_root = tmp_path / "terminal-spec-gate-repo"
    repo_root.mkdir()
    _init_git_repo_with_commit(repo_root)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=["approve"])

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        use_fake_session_manager=True,
        frontend=frontend,
    )

    assert result.mode == "completed"
    assert "Approved: spec_review" in frontend.output_text()
    assert "Approved: execution_bundle" in frontend.output_text()
    assert "Mission completed: run-root" in frontend.output_text()


@dataclass(frozen=True, slots=True)
class FixtureFlowResult:
    ralphception_dir: Path
    source_repo_modified: bool
    execution_reopened: bool


@dataclass(frozen=True, slots=True)
class ResumeFlowResult:
    replayed_run_tree: bool
    event_feed_before_resume: int
    event_feed_after_resume: int


@dataclass(slots=True)
class PreparedWorkspace:
    repo_root: Path
    source_root: Path | None
    source_digest_before: str | None
    engine: WorkflowEngine
    child_run_id: str
    plan_ref: ArtifactRef


def run_fixture_flow(
    tmp_path: Path,
    fixture_name: str,
    *,
    source_repo_name: str | None = None,
    inject_gap: FindingSeverity | None = None,
) -> FixtureFlowResult:
    if source_repo_name is None:
        repo_root = _copy_fixture_repo(tmp_path, fixture_name)
        _bootstrap_runtime(repo_root)
        ralphception_dir = repo_root / ".ralphception"
        assert (ralphception_dir / "config.toml").exists()
        assert (ralphception_dir / "runs" / "run-root" / "startup.json").exists()
        assert (ralphception_dir / "runs" / "run-root" / "intake.md").exists()
        return FixtureFlowResult(
            ralphception_dir=ralphception_dir,
            source_repo_modified=False,
            execution_reopened=False,
        )

    prepared = _prepare_execution_workspace(
        tmp_path,
        fixture_name,
        source_repo_name=source_repo_name,
    )
    execution_reopened = False
    if inject_gap is not None:
        execution_reopened = _reopen_execution_for_gap(prepared, inject_gap)

    source_repo_modified = prepared.source_root is not None and (
        _tree_digest(prepared.source_root) != prepared.source_digest_before
    )
    return FixtureFlowResult(
        ralphception_dir=prepared.repo_root / ".ralphception",
        source_repo_modified=source_repo_modified,
        execution_reopened=execution_reopened,
    )


def resume_fixture_flow(tmp_path: Path, fixture_name: str) -> ResumeFlowResult:
    prepared = _prepare_execution_workspace(
        tmp_path,
        fixture_name,
        source_repo_name="source_repo",
    )
    rebuilt_launch = resolve_runtime_view(prepared.repo_root)
    assert rebuilt_launch.engine is not None
    rebuilt_engine = _engine_with_fake_sessions(rebuilt_launch.engine, prepared.repo_root)
    recovery_service = RecoveryService(
        engine=rebuilt_engine,
        process_id=4242,
        xdg_state_home=tmp_path / "xdg-state",
        clock=_utc_now,
    )
    resume_result = recovery_service.resume(run_id="run-root", mode="read")
    controller = DashboardController(
        repo_root=prepared.repo_root,
        engine=rebuilt_engine,
        recovery_service=recovery_service,
    )
    controller.event_entries = []
    event_feed_before_resume = len(controller.event_entries)
    command_result = controller.handle_command("/resume")
    replayed_run_tree = (
        resume_result.checkpoint_reconciled
        and command_result.ok
        and bool(controller.event_entries)
        and any(entry.node_id == f"run:{prepared.child_run_id}" for entry in controller.workflow_entries())
    )
    return ResumeFlowResult(
        replayed_run_tree=replayed_run_tree,
        event_feed_before_resume=event_feed_before_resume,
        event_feed_after_resume=len(controller.event_entries),
    )


def _prepare_execution_workspace(
    tmp_path: Path,
    fixture_name: str,
    *,
    source_repo_name: str,
) -> PreparedWorkspace:
    repo_root = _copy_fixture_repo(tmp_path, fixture_name)
    source_root = _copy_fixture_repo(tmp_path, source_repo_name)
    source_digest_before = _tree_digest(source_root)

    _bootstrap_runtime(repo_root, source_root=source_root)
    spec_ref = _write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/porting-spec.md",
        content=_spec_text(repo_root, source_root),
    )
    _approve_current_review_target(repo_root)

    plan_ref = _write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/porting-plan.md",
        content=_plan_text(repo_root, source_root),
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=_utc_now(),
    )
    _approve_current_review_target(repo_root)

    launch = resolve_runtime_view(repo_root)
    assert launch.engine is not None
    engine = _engine_with_fake_sessions(launch.engine, repo_root)
    engine.schedule_child_run(goal="Port the source fixture into the target fixture.")
    child_run_id = "run-child-1"
    _write_ported_module(repo_root, source_root)
    child_run = engine.run(child_run_id)
    completed_child = engine.update_run(
        child_run_id,
        status="completed",
        codex_session_ref=child_run.codex_session_ref,
        updated_at=_utc_now(),
    )
    _persist_run_record(repo_root, completed_child)
    return PreparedWorkspace(
        repo_root=repo_root,
        source_root=source_root,
        source_digest_before=source_digest_before,
        engine=engine,
        child_run_id=child_run_id,
        plan_ref=plan_ref,
    )


def _bootstrap_runtime(repo_root: Path, *, source_root: Path | None = None) -> None:
    launch = resolve_runtime_view(repo_root)
    assert launch.mode == "startup"
    assert launch.startup_controller is not None
    launch.startup_controller.start_first_run(
        seed_prompt=_seed_prompt(repo_root, source_root),
        source_repos=[] if source_root is None else [source_root],
    )
    next_launch = resolve_runtime_view(repo_root)
    assert next_launch.mode == "dashboard"


def _approve_current_review_target(repo_root: Path) -> None:
    launch = resolve_runtime_view(repo_root)
    assert launch.review_controller is not None
    diff = launch.review_controller.diff_current_target()
    assert diff.rendered_text
    launch.review_controller.approve_current_target(approver="user")


def _copy_fixture_repo(tmp_path: Path, fixture_name: str) -> Path:
    source = FIXTURES_DIR / fixture_name
    destination = tmp_path / fixture_name
    shutil.copytree(source, destination)
    subprocess.run(
        ["git", "init"],
        check=True,
        cwd=destination,
        capture_output=True,
        text=True,
    )
    return destination


def _init_git_repo_with_commit(repo_root: Path) -> None:
    subprocess.run(["git", "init", "-b", "main"], check=True, cwd=repo_root, capture_output=True, text=True)
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], check=True, cwd=repo_root, capture_output=True, text=True)
    subprocess.run(
        [
            "git",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-m",
            "initial",
        ],
        check=True,
        cwd=repo_root,
        capture_output=True,
        text=True,
    )


def _engine_with_fake_sessions(engine: WorkflowEngine, repo_root: Path) -> WorkflowEngine:
    return WorkflowEngine(
        repo_root=repo_root,
        root_run=engine.root_run,
        stages=list(cast(dict[str, Stage], getattr(engine, "_stages_by_kind")).values()),
        child_runs=[run for run in engine.runs() if run.run_id != engine.root_run.run_id],
        bundles=list(cast(dict[str, ExecutionBundle], getattr(engine, "_bundles_by_id")).values()),
        approvals=list(cast(list[ApprovalRecord], getattr(engine, "_approvals"))),
        session_manager=build_fake_session_manager(workspace_path=str(repo_root)),
        authoritative_root=str(repo_root),
    )


def _build_fake_session_manager_for_repo(repo_root: Path, config) -> object:
    return build_fake_session_manager(workspace_path=str(repo_root), config=config)


def _write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    content: str,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=1,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )


def _persist_run_record(repo_root: Path, run: Run) -> None:
    write_json_atomic(
        repo_root / ".ralphception" / "runs" / run.run_id / "run.json",
        run.model_dump(mode="json"),
    )


def _write_ported_module(repo_root: Path, source_root: Path) -> None:
    source_text = (source_root / "src" / "port_me.ts").read_text(encoding="utf-8")
    target = repo_root / "src" / "ported_from_source.py"
    target.write_text(
        (
            "def port_me(value: str) -> str:\n"
            '    """Deterministic fixture port from the TypeScript source repo."""\n'
            "    return value.strip().upper()\n"
            f"\n# Source excerpt hash: {hashlib.sha256(source_text.encode('utf-8')).hexdigest()}\n"
        ),
        encoding="utf-8",
    )


def _reopen_execution_for_gap(prepared: PreparedWorkspace, severity: FindingSeverity) -> bool:
    audit_service = AuditService(prepared.repo_root)
    finding = AuditFinding(
        finding_id=f"finding-{severity.lower()}-gap",
        run_id="run-root",
        severity=severity,
        kind="test_gap",
        title="Ported behavior is missing parity coverage.",
        evidence_refs=[prepared.plan_ref],
        status="resolved",
        created_at=_utc_now(),
        resolved_at=_utc_now(),
    )
    audit_service.persist_finding(finding, stage_id="stage-audit")
    reopened = audit_service.reopen_finding(
        finding,
        stage_id="stage-audit",
        reopened_at=_utc_now(),
    )
    if not audit_service.blocks_completion([reopened]):
        return False
    replacement = prepared.engine.replace_run(
        prepared.child_run_id,
        goal="Address reopened audit finding.",
    )
    _persist_run_record(prepared.repo_root, replacement)
    return reopened.status == "open" and replacement.supersedes_run_id == prepared.child_run_id


def _tree_digest(repo_root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(repo_root.rglob("*")):
        if not path.is_file():
            continue
        digest.update(str(path.relative_to(repo_root)).encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _seed_prompt(repo_root: Path, source_root: Path | None) -> str:
    if source_root is None:
        return f"Inspect and plan work for {repo_root.name}."
    return f"Port behavior from {source_root.name} into {repo_root.name} without editing the source repo."


def _spec_text(repo_root: Path, source_root: Path) -> str:
    source_file = source_root / "src" / "port_me.ts"
    return (
        "# Porting Spec\n\n"
        f"- Target repo: {repo_root.name}\n"
        f"- Source repo: {source_root.name}\n"
        f"- Source file: {source_file}\n"
        "- Source repo is read-only input.\n"
        "- Port trim-and-uppercase behavior into Python.\n"
    )


def _plan_text(repo_root: Path, source_root: Path) -> str:
    return (
        "# Porting Plan\n\n"
        f"- Read {source_root / 'src' / 'port_me.ts'}.\n"
        f"- Write {repo_root / 'src' / 'ported_from_source.py'}.\n"
        "- Preserve the source repo exactly as-is.\n"
        "- Reopen execution if audit finds an unresolved P1 gap.\n"
    )


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)
