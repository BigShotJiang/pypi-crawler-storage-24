"""Application bootstrap for Ralphception."""

from __future__ import annotations

from collections.abc import Callable
import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from textual.app import App
from textual.screen import Screen

from ralphception.codex.client import codex_cli_available
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.config import DEFAULT_CONFIG, RalphceptionConfig, load_config, write_config_atomically
from ralphception.headless import HeadlessRunResult
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ApprovalRecord, ExecutionBundle, Run, Stage
from ralphception.models.session import ChildSessionRef
from ralphception.paths import config_path
from ralphception.runtime.supervisor import RuntimeSupervisor
from ralphception.runtime.terminal import TerminalRunResult, run_terminal as run_terminal_frontend
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.files import write_json_atomic
from ralphception.ui.app import DashboardController, RalphceptionDashboardApp
from ralphception.ui.screens import (
    ArtifactReviewController,
    ReviewScreen,
    StartupBootstrapController,
    StartupScreen,
    _BOOTSTRAPPED_RESULT,
    _REVIEWED_RESULT,
    load_startup_record,
)
from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import ResumeMode, ResumeResult, RecoveryService

_RUNTIME_STAGE_ORDER = (
    ("intake", "completed"),
    ("spec", "completed"),
    ("plan", "pending"),
    ("execute", "pending"),
    ("merge", "pending"),
    ("audit", "pending"),
)

SessionManagerFactory = Callable[[Path, RalphceptionConfig], object]


@dataclass(frozen=True, slots=True)
class RuntimeLaunchState:
    """Resolved startup mode for the current workspace."""

    mode: Literal["startup", "review", "dashboard"]
    frontend_kind: Literal["tui"] = "tui"
    supervisor: RuntimeSupervisor | None = None
    screen: Screen[None] | None = None
    dashboard_app: RalphceptionDashboardApp | None = None
    engine: WorkflowEngine | None = None
    startup_controller: StartupBootstrapController | None = None
    review_controller: ArtifactReviewController | None = None


class _ScreenHostApp(App[str | None]):
    """Simple host app for startup and review screens."""

    def __init__(self, screen: Screen[None]) -> None:
        super().__init__()
        self._screen = screen

    def on_mount(self) -> None:
        self.push_screen(self._screen)


def resolve_runtime_view(
    repo_root: Path,
    *,
    session_manager_factory: SessionManagerFactory | None = None,
) -> RuntimeLaunchState:
    """Resolve the current startup mode for a workspace."""
    repo_root = bootstrap_workspace(repo_root)
    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        session_manager_factory=session_manager_factory,
    )
    step = supervisor.step()
    if step.kind == "startup_prompt":
        startup_controller = StartupBootstrapController(repo_root)
        return RuntimeLaunchState(
            mode="startup",
            supervisor=supervisor,
            screen=StartupScreen(startup_controller),
            startup_controller=startup_controller,
        )

    engine = step.engine or supervisor.build_engine()
    recovery_service = supervisor.build_recovery_service(engine=engine)
    review_controller = supervisor.build_review_controller(engine=engine)
    if step.kind == "review_prompt":
        return RuntimeLaunchState(
            mode="review",
            supervisor=supervisor,
            screen=ReviewScreen(review_controller),
            engine=engine,
            review_controller=review_controller,
        )

    _advance_workspace_engine(repo_root, engine)
    dashboard_app = RalphceptionDashboardApp(
        DashboardController(
            repo_root=repo_root,
            engine=engine,
            recovery_service=recovery_service,
            supervisor=supervisor,
        ),
        supervisor=supervisor,
    )
    return RuntimeLaunchState(
        mode="dashboard",
        supervisor=supervisor,
        dashboard_app=dashboard_app,
        engine=engine,
    )


def run_app() -> None:
    """Run the Ralphception Textual runtime view."""
    repo_root = Path.cwd()
    mouse_enabled = _load_or_create_config(repo_root).ui.mouse
    while True:
        launch = resolve_runtime_view(repo_root)
        if launch.dashboard_app is not None:
            result = launch.dashboard_app.run(mouse=launch.dashboard_app.controller.config.ui.mouse)
            if result in {"review", "startup"}:
                continue
            return
        if launch.screen is None:
            raise RuntimeError("runtime launch did not resolve a screen")
        result = _ScreenHostApp(launch.screen).run(mouse=mouse_enabled)
        if result not in {_BOOTSTRAPPED_RESULT, _REVIEWED_RESULT}:
            return


def resume_app(
    *,
    repo_root: Path | None = None,
    mode: ResumeMode = "read",
) -> ResumeResult:
    """Resume the current workspace's root run through the recovery layer."""
    resolved_repo_root = Path.cwd() if repo_root is None else repo_root
    launch = resolve_runtime_view(resolved_repo_root)
    if launch.engine is None:
        raise RuntimeError("workspace has no resumable run yet")
    recovery_service = RecoveryService(
        engine=launch.engine,
        process_id=os.getpid(),
    )
    return recovery_service.resume(run_id=launch.engine.root_run.run_id, mode=mode)


def run_headless(
    *,
    repo_root: Path | None = None,
    seed_prompt: str | None = None,
    source_repos: tuple[str, ...] = (),
    approve_all: bool = False,
    approver: str = "headless",
    use_fake_session_manager: bool = False,
    session_manager_factory: SessionManagerFactory | None = None,
) -> HeadlessRunResult:
    """Run the headless mission supervisor without opening the Textual UI."""
    resolved_session_manager_factory = _resolve_headless_session_manager_factory(
        session_manager_factory=session_manager_factory,
        use_fake_session_manager=use_fake_session_manager,
    )
    resolved_repo_root = Path.cwd() if repo_root is None else repo_root
    return RuntimeSupervisor(
        repo_root=resolved_repo_root,
        seed_prompt=seed_prompt,
        source_repos=source_repos,
        approve_all=approve_all,
        approver=approver,
        session_manager_factory=resolved_session_manager_factory,
    ).run()


def run_terminal(
    *,
    repo_root: Path | None = None,
    seed_prompt: str | None = None,
    source_repos: tuple[str, ...] = (),
    resume: bool = False,
    approve_all: bool = False,
    approver: str = "terminal",
    use_fake_session_manager: bool = False,
    session_manager_factory: SessionManagerFactory | None = None,
) -> TerminalRunResult:
    """Run the traditional terminal frontend over the shared runtime."""
    return run_terminal_frontend(
        repo_root=repo_root,
        seed_prompt=seed_prompt,
        source_repos=source_repos,
        resume=resume,
        approve_all=approve_all,
        approver=approver,
        use_fake_session_manager=use_fake_session_manager,
        session_manager_factory=session_manager_factory,
    )


def _resolve_headless_session_manager_factory(
    *,
    session_manager_factory: SessionManagerFactory | None,
    use_fake_session_manager: bool,
) -> SessionManagerFactory | None:
    if session_manager_factory is not None:
        return session_manager_factory
    if not use_fake_session_manager:
        return None

    from ralphception.testing.fakes import build_fake_headless_session_manager

    def _factory(repo_root: Path, config: RalphceptionConfig) -> object:
        return build_fake_headless_session_manager(workspace_path=str(repo_root), config=config)

    return _factory


def _render_headless_result(result: HeadlessRunResult) -> str:
    """Render a stable text summary for CLI headless runs."""
    lines: list[str] = [f"Headless mode: {result.mode}"]
    lines.append(
        "Actions: "
        + (", ".join(result.actions) if result.actions else "none")
    )
    if result.review_target_kind is not None:
        lines.append(f"Pending review target: {result.review_target_kind}")
    if result.root_run_id is not None and result.root_run_status is not None:
        lines.append(f"Root run: {result.root_run_id} ({result.root_run_status})")
    if result.authoritative_repo_root is not None:
        lines.append(f"Repository root: {result.authoritative_repo_root}")
    if result.child_run_ids:
        lines.append("Child runs: " + ", ".join(result.child_run_ids))
    if result.completed_stages:
        lines.append("Completed stages: " + ", ".join(result.completed_stages))
    if result.audit_reopened:
        lines.append("Audit reopened: yes")
    return "\n".join(lines)


def _render_terminal_result(result: TerminalRunResult) -> str:
    lines: list[str] = [f"Runtime: {result.mode}"]
    if result.root_run_id is not None:
        lines.append(f"Root run: {result.root_run_id}")
    if result.authoritative_repo_root is not None:
        lines.append(f"Repository root: {result.authoritative_repo_root}")
    return "\n".join(lines)


def _build_workspace_engine(
    repo_root: Path,
    *,
    config: RalphceptionConfig | None = None,
    session_manager_factory: SessionManagerFactory | None = None,
) -> WorkflowEngine:
    startup_record = load_startup_record(repo_root)
    if startup_record is None:
        raise RuntimeError("workspace bootstrap state is missing")

    resolved_config = _load_or_create_config(repo_root) if config is None else config
    spec_artifacts = _discover_artifacts(repo_root / ".ralphception" / "specs", artifact_kind="spec")
    root_run = Run(
        run_id=startup_record.outer_run_id,
        parent_run_id=None,
        supersedes_run_id=None,
        goal=startup_record.seed_prompt,
        status="pending",
        stage_ids=[f"stage-{stage_kind}" for stage_kind, _ in _RUNTIME_STAGE_ORDER],
        config_snapshot={
            "codex": {"model": resolved_config.codex.model},
            "source_repos": startup_record.source_repos,
        },
        codex_session_ref=None,
        artifact_refs=spec_artifacts or [startup_record.intake_artifact],
        created_at=startup_record.created_at,
        updated_at=startup_record.created_at,
    )
    stages = [
        Stage(
            stage_id=f"stage-{stage_kind}",
            run_id=root_run.run_id,
            stage_kind=stage_kind,
            status=status if stage_kind != "spec" or spec_artifacts else "pending",
            task_ids=[],
            started_at=startup_record.created_at if status == "completed" and (stage_kind != "spec" or spec_artifacts) else None,
            completed_at=startup_record.created_at if status == "completed" and (stage_kind != "spec" or spec_artifacts) else None,
        )
        for stage_kind, status in _RUNTIME_STAGE_ORDER
    ]
    return WorkflowEngine(
        repo_root=repo_root,
        root_run=root_run,
        stages=stages,
        child_runs=_load_child_runs(repo_root, root_run.run_id),
        bundles=_load_bundles(repo_root, root_run.run_id),
        approvals=_load_approvals(repo_root),
        session_manager=_build_session_manager(
            repo_root,
            resolved_config,
            session_manager_factory=session_manager_factory,
        ),
    )


def _build_session_manager(
    repo_root: Path,
    config: RalphceptionConfig,
    *,
    session_manager_factory: SessionManagerFactory | None,
) -> object:
    factory = session_manager_factory or _default_session_manager_factory
    return factory(repo_root, config)


def _default_session_manager_factory(repo_root: Path, config: RalphceptionConfig) -> object:
    if not codex_cli_available():
        return None
    return CodexSessionManager(workspace_path=str(repo_root), config=config)


def _advance_workspace_engine(repo_root: Path, engine: WorkflowEngine) -> None:
    if not engine.can_enter_execute_stage():
        return
    if engine.session_manager is None:
        _persist_run_record(repo_root, engine.root_run)
        return

    run_ids_before = {run.run_id for run in engine.runs()}
    if any(run_id != engine.root_run.run_id for run_id in run_ids_before):
        _persist_run_record(repo_root, engine.root_run)
        return

    engine.schedule_child_run(goal=_initial_execution_goal(engine))
    root_session_ref = _ensure_root_session(engine)
    root_run = engine.update_run(
        engine.root_run.run_id,
        status="running",
        codex_session_ref=root_session_ref,
        updated_at=_now_utc(),
    )
    _persist_run_record(repo_root, root_run)
    for run in engine.runs():
        if run.run_id not in run_ids_before:
            _persist_run_record(repo_root, run)


def _initial_execution_goal(engine: WorkflowEngine) -> str:
    bundle = max(
        (bundle for bundle in engine._bundles_by_id.values() if bundle.state in {"approved", "derived_in_scope"}),
        key=lambda candidate: candidate.bundle_version,
    )
    return f"Execute approved bundle v{bundle.bundle_version} for {engine.root_run.goal}."


def _persist_run_record(repo_root: Path, run: Run) -> None:
    write_json_atomic(
        repo_root / ".ralphception" / "runs" / run.run_id / "run.json",
        run.model_dump(mode="json"),
    )


def _ensure_root_session(engine: WorkflowEngine) -> ChildSessionRef:
    if engine.root_run.codex_session_ref is not None:
        return engine.root_run.codex_session_ref

    if engine.session_manager is None:
        raise RuntimeError("session manager is required to start the root run")

    start_session = getattr(engine.session_manager, "start_session", None)
    get_session_ref = getattr(engine.session_manager, "get_session_ref", None)
    if not callable(start_session) or not callable(get_session_ref):
        raise RuntimeError("session manager does not support root session startup")

    start_session(
        run_id=engine.root_run.run_id,
        goal=engine.root_run.goal,
        parent_run_id=engine.root_run.parent_run_id,
        workspace_path=str(engine.repo_root),
    )
    session_ref = get_session_ref(engine.root_run.run_id)
    if session_ref is None:
        raise RuntimeError("session manager did not return a root session reference")
    return session_ref


def _now_utc():
    from datetime import datetime, timezone

    return datetime.now(timezone.utc)


def _discover_artifacts(directory: Path, *, artifact_kind: str) -> list[ArtifactRef]:
    if not directory.exists():
        return []
    artifact_refs: list[ArtifactRef] = []
    for index, path in enumerate(sorted(directory.glob("**/*")), start=1):
        if not path.is_file():
            continue
        content = path.read_text(encoding="utf-8")
        artifact_refs.append(
            ArtifactRef(
                artifact_kind=artifact_kind,
                artifact_path=str(path.relative_to(directory.parent.parent)),
                artifact_version=index,
                content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
            ),
        )
    return artifact_refs


def _load_bundles(repo_root: Path, run_id: str) -> list[ExecutionBundle]:
    bundle_dir = repo_root / ".ralphception" / "runs" / run_id / "bundles"
    if not bundle_dir.exists():
        return []
    return [
        ExecutionBundle.model_validate(json.loads(path.read_text(encoding="utf-8")))
        for path in sorted(bundle_dir.glob("*.json"))
    ]


def _load_child_runs(repo_root: Path, root_run_id: str) -> list[Run]:
    runs_dir = repo_root / ".ralphception" / "runs"
    if not runs_dir.exists():
        return []

    child_runs: list[Run] = []
    for path in sorted(runs_dir.glob("*/run.json")):
        run = Run.model_validate(json.loads(path.read_text(encoding="utf-8")))
        if run.run_id == root_run_id:
            continue
        child_runs.append(run)
    return child_runs


def _load_approvals(repo_root: Path) -> list[ApprovalRecord]:
    approval_dir = repo_root / ".ralphception" / "approvals"
    if not approval_dir.exists():
        return []
    approvals: list[ApprovalRecord] = []
    for path in sorted(approval_dir.glob("*.json")):
        approvals.append(ApprovalRecord.model_validate(json.loads(path.read_text(encoding="utf-8"))))
    return approvals


def _load_or_create_config(repo_root: Path) -> RalphceptionConfig:
    cfg_path = config_path(repo_root)
    if not cfg_path.exists():
        write_config_atomically(cfg_path, DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    loaded = load_config(cfg_path)
    if loaded.config is None:
        write_config_atomically(cfg_path, DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    return loaded.config
