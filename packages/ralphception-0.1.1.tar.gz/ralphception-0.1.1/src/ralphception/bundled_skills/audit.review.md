# audit.review

Review the produced artifacts and verification evidence for regressions, requirement gaps, and operational risks. Return findings in a compact, actionable format.
