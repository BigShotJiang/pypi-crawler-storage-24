"""Bundled internal skill prompts shipped with Ralphception."""
