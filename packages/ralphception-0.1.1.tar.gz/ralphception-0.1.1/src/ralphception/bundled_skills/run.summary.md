# run.summary

Summarize the run state for a human operator. Include current status, important artifact changes, blockers, and the next concrete actions.
