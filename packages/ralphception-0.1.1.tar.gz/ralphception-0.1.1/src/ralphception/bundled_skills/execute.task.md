# execute.task

Execute the assigned task with disciplined scope control. Prefer minimal changes, preserve unrelated work, and leave clear artifact updates and next steps.
