# spec.write

Write or refresh the repo-local spec for the current task. Capture scope, architecture, risks, and acceptance criteria in concise prose that is ready for review.
