# Ralphception Bootstrap Loop Iteration

Repository root: `{repo_root}`

You are running one fresh bootstrap iteration for `ralphception` itself. Treat the repository files plus `.ralphception/bootstrapping/` as the durable source of truth for this iteration. Do not rely on prior chat history.

## Read First

Read the authoritative inputs before making changes, then reconcile the repo working tree against the current bootstrap ledger and latest summary.

### Authoritative spec inputs

{spec_paths}

{spec_inputs}

### Authoritative plan input

- {plan_path}

{plan_input}

### Authoritative README inputs

{readme_paths}

{readme_inputs}

### Authoritative code globs

{code_globs}

### Authoritative test globs

{test_globs}

### Latest iteration summary

Path: `{latest_summary_path}`

````markdown
{latest_summary_text}
````

### Current `gaps.json`

Path: `{gaps_json_path}`

````json
{gaps_json_text}
````

### Current `gaps.md`

Path: `{gaps_md_path}`

````markdown
{gaps_md_text}
````

### Guarded `finish-criteria.md`

Path: `{finish_criteria_path}`

Guard `finish-criteria.md`. Update it only when finish criteria or authoritative inputs materially change.

````markdown
{finish_criteria_text}
````

### Required verification commands

{verification_commands}

### Approval request state

Path: `{approval_request_path}`

{approval_request_instruction}

````text
{approval_request_text}
````

## Required Loop Behavior

- Read the authoritative inputs before making changes.
- Classify every newly discovered gap using the bootstrap taxonomy (`implementation_gap`, `verification_gap`, `ux_gap`, `doc_gap`, `scope_gap`) and map it to the runtime finding kind.
- Choose one coherent next slice unless the iteration is only reconciling approval state.
- Update gaps.json and regenerate gaps.md.
- Guard finish-criteria.md and update it only when finish criteria or authoritative inputs materially change.
- Write an iteration summary with changes made, verification run, findings changed, and the next recommended slice.
- Stop for approval when a material spec or plan change is proposed.
- If an approval request is pending, stop for human review until it is satisfied.
- Never claim completion without running the required verification commands.

## Required Outputs

- Updated repo files for the chosen slice.
- Updated `gaps.json`.
- Regenerated `gaps.md`.
- Updated `inputs.json` when authoritative pointers or the latest summary path changed.
- A new `.ralphception/bootstrapping/iterations/<timestamp>.md` summary.
- `approval-request.json` if and only if the loop is awaiting human review.
