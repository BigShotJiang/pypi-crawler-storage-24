# plan.write

Turn the approved spec into a concrete implementation plan. Break work into small, testable steps with explicit files, commands, and verification gates.
