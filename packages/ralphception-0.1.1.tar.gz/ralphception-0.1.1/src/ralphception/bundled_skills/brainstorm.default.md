# brainstorm.default

Clarify the user goal, constraints, and success criteria. Offer a small set of viable approaches, recommend one, and explain the tradeoffs before implementation begins.
