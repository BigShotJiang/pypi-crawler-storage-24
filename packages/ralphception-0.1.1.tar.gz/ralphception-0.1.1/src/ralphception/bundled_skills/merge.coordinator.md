# merge.coordinator

Assess merge readiness for the current worktree, summarize blockers, and produce a concrete handoff for safe integration back into the target branch.
