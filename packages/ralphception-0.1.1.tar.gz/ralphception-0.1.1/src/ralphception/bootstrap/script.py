"""Local bootstrap helper installer."""

from __future__ import annotations

import stat
from pathlib import Path

from ralphception.storage.files import write_text_atomic

_SCRIPT_NAME = "ralph.sh"
_SCRIPT_TEMPLATE = """#!/usr/bin/env bash
set -euo pipefail

cd -- "$(dirname "$0")"

iteration=1
while true; do
  echo "== Ralph loop iteration ${iteration} =="

  if uv run python -m ralphception.bootstrap.runner --loop-once "$@"; then
    status=0
  else
    status=$?
  fi

  case "$status" in
    0)
      echo "Ralph loop complete."
      exit 0
      ;;
    10)
      iteration=$((iteration + 1))
      ;;
    11)
      echo "Ralph loop is waiting for review."
      exit 0
      ;;
    *)
      echo "Ralph loop failed with exit code ${status}."
      exit "$status"
      ;;
  esac
done
"""


def install_local_bootstrap_script(repo_root: Path) -> Path:
    """Write the repo-local bootstrap loop helper."""
    repo_root = repo_root.resolve(strict=False)
    script_path = repo_root / _SCRIPT_NAME
    write_text_atomic(script_path, _SCRIPT_TEMPLATE)
    script_path.chmod(script_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return script_path


__all__ = ["install_local_bootstrap_script"]
