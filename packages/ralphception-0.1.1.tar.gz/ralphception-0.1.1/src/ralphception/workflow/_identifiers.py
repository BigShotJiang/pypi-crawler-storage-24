"""Validation helpers for storage-facing workflow identifiers."""

from __future__ import annotations


def validate_storage_identifier(value: str, *, field_name: str) -> str:
    """Require a single safe path component for storage-facing identifiers."""
    normalized = value.replace("\\", "/")
    parts = normalized.split("/")
    if not value or "\x00" in value or len(parts) != 1 or any(part in {"", ".", ".."} for part in parts):
        raise ValueError(f"invalid {field_name} identifier: {value!r}")
    return value
