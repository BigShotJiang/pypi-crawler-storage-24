"""Workflow orchestration for root runs, child scheduling, and approvals."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import (
    ApprovalRecord,
    Checkpoint,
    ChildAssignment,
    ExecutionBundle,
    Run,
    RunStageStatus,
    Stage,
    StageKind,
)
from ralphception.models.session import ChildSessionRef
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.checkpoints import write_checkpoint
from ralphception.storage.events import EventStore
from ralphception.workflow._identifiers import validate_storage_identifier
from ralphception.workflow.bundles import assign_bundle, is_bundle_consumable


class WorkflowEngine:
    """Coordinate workflow stage gates, child-run scheduling, and replacements."""

    def __init__(
        self,
        *,
        repo_root: Path,
        root_run: Run,
        stages: Sequence[Stage],
        child_runs: Sequence[Run] = (),
        bundles: Sequence[ExecutionBundle] = (),
        approvals: Sequence[ApprovalRecord] = (),
        session_manager: object | None = None,
        authoritative_root: str | None = None,
        active_worktrees: Sequence[str] = (),
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self.repo_root = bootstrap_workspace(repo_root)
        self.root_run = root_run
        self.session_manager = session_manager
        self.authoritative_root = authoritative_root or str(self.repo_root)
        self.active_worktrees = list(active_worktrees)
        self._clock = clock or _utc_now
        self._runs_by_id = {root_run.run_id: root_run}
        self._runs_by_id.update({run.run_id: run for run in child_runs})
        self._stages_by_kind = {stage.stage_kind: stage for stage in stages}
        self._bundles_by_id = {bundle.bundle_id: bundle for bundle in bundles}
        self._approvals = list(approvals)
        self._assignments: list[ChildAssignment] = []
        self._assignment_counter = 0
        self._checkpoint_counter = 0
        self.last_checkpoint: Checkpoint | None = None

        self._sync_approval_gates()

    def run(self, run_id: str) -> Run:
        return self._runs_by_id[run_id]

    def runs(self) -> tuple[Run, ...]:
        return tuple(self._runs_by_id.values())

    def stage(self, stage_kind: StageKind) -> Stage:
        return self._stages_by_kind[stage_kind]

    def update_run(
        self,
        run_id: str,
        *,
        status: RunStageStatus,
        codex_session_ref: ChildSessionRef | None,
        updated_at: datetime,
    ) -> Run:
        current = self.run(run_id)
        data = current.model_dump(mode="python")
        data["status"] = status
        data["codex_session_ref"] = codex_session_ref
        data["updated_at"] = updated_at
        updated = Run(**data)
        self._runs_by_id[run_id] = updated
        if run_id == self.root_run.run_id:
            self.root_run = updated
        return updated

    def can_enter_plan_stage(self) -> bool:
        allowed = any(
            approval.run_id == self.root_run.run_id and approval.approval_kind == "spec_review"
            for approval in self._approvals
        )
        self._set_gate_stage("plan", allowed=allowed)
        return allowed

    def can_enter_execute_stage(self) -> bool:
        approved_bundle_versions = {
            bundle.bundle_version for bundle in self._bundles_by_id.values() if bundle.state == "approved"
        }
        allowed = any(
            approval.run_id == self.root_run.run_id
            and approval.approval_kind == "execution_bundle"
            and approval.bundle_version in approved_bundle_versions
            for approval in self._approvals
        )
        self._set_gate_stage("execute", allowed=allowed)
        return allowed

    def schedule_child_run(
        self,
        *,
        goal: str,
        acceptance_criteria_refs: list[ArtifactRef] | None = None,
        dependency_refs: list[ArtifactRef] | None = None,
    ) -> ChildAssignment:
        if not self.can_enter_execute_stage():
            raise RuntimeError("execute stage is blocked pending execution-bundle approval")

        latest_bundle = self._latest_consumable_bundle()
        self._start_stage("execute")

        child_run_id = self._next_run_id()
        validate_storage_identifier(child_run_id, field_name="run_id")
        assignment = ChildAssignment(
            assignment_id=self._next_assignment_id(),
            goal=goal,
            acceptance_criteria_refs=acceptance_criteria_refs or [],
            dependency_refs=dependency_refs or latest_bundle.artifact_refs,
            bundle_version=latest_bundle.bundle_version,
        )

        assigned_bundle = assign_bundle(
            self.repo_root,
            bundle=latest_bundle,
            assigned_run_id=child_run_id,
            stage_id=self.stage("execute").stage_id,
        )
        self._bundles_by_id[assigned_bundle.bundle_id] = assigned_bundle

        now = self._clock()
        child_session_ref = self._start_child_session(run_id=child_run_id, goal=goal)
        child_run = Run(
            run_id=child_run_id,
            parent_run_id=self.root_run.run_id,
            supersedes_run_id=None,
            goal=goal,
            status="pending",
            stage_ids=[],
            config_snapshot=deepcopy(self.root_run.config_snapshot),
            codex_session_ref=child_session_ref,
            artifact_refs=list(assigned_bundle.artifact_refs),
            created_at=now,
            updated_at=now,
        )
        self._runs_by_id[child_run_id] = child_run
        self._assignments.append(assignment)
        self.root_run = self._replace_run_record(self.root_run.run_id, updated_at=now)
        self._write_checkpoint(checkpoint_kind="child_scheduled", bundle_version=assignment.bundle_version)
        return assignment

    def replace_run(self, run_id: str, *, goal: str | None = None) -> Run:
        if run_id == self.root_run.run_id:
            raise ValueError("root run replacement is not supported")

        replaced = self.run(run_id)
        now = self._clock()
        replacement = Run(
            run_id=self._next_replacement_run_id(run_id),
            parent_run_id=replaced.parent_run_id,
            supersedes_run_id=replaced.run_id,
            goal=goal or replaced.goal,
            status="pending",
            stage_ids=[],
            config_snapshot=deepcopy(replaced.config_snapshot),
            codex_session_ref=None,
            artifact_refs=list(replaced.artifact_refs),
            created_at=now,
            updated_at=now,
        )
        self._runs_by_id[replacement.run_id] = replacement
        self.root_run = self._replace_run_record(self.root_run.run_id, updated_at=now)
        return replacement

    def _sync_approval_gates(self) -> None:
        self.can_enter_plan_stage()
        self.can_enter_execute_stage()

    def _set_gate_stage(self, stage_kind: StageKind, *, allowed: bool) -> None:
        if stage_kind not in self._stages_by_kind:
            return
        current = self._stages_by_kind[stage_kind]
        if allowed:
            if current.status != "awaiting_approval":
                return
            next_status = "pending"
        else:
            if current.status != "pending":
                return
            next_status = "awaiting_approval"

        if current.status == next_status:
            return
        self._stages_by_kind[stage_kind] = self._stage_with_status(current, status=next_status)

    def _start_stage(self, stage_kind: StageKind) -> None:
        if stage_kind not in self._stages_by_kind:
            return
        current = self._stages_by_kind[stage_kind]
        if current.status == "running":
            return
        self._stages_by_kind[stage_kind] = self._stage_with_status(
            current,
            status="running",
            started_at=current.started_at or self._clock(),
            completed_at=None,
        )

    def _stage_with_status(
        self,
        stage: Stage,
        *,
        status: str,
        started_at: datetime | None = None,
        completed_at: datetime | None = None,
    ) -> Stage:
        data = stage.model_dump(mode="python")
        data["status"] = status
        if status in {"pending", "awaiting_approval"}:
            data["started_at"] = None
            data["completed_at"] = None
        else:
            data["started_at"] = started_at
            data["completed_at"] = completed_at
        return Stage(**data)

    def _replace_run_record(self, run_id: str, *, updated_at: datetime) -> Run:
        run = self._runs_by_id[run_id]
        data = run.model_dump(mode="python")
        data["updated_at"] = updated_at
        updated = Run(**data)
        self._runs_by_id[run_id] = updated
        return updated

    def _latest_consumable_bundle(self) -> ExecutionBundle:
        try:
            return max(
                (bundle for bundle in self._bundles_by_id.values() if is_bundle_consumable(bundle)),
                key=lambda bundle: bundle.bundle_version,
            )
        except ValueError as exc:
            raise RuntimeError("no consumable execution bundle is available") from exc

    def _next_run_id(self) -> str:
        index = 1
        while True:
            candidate = f"run-child-{index}"
            if candidate not in self._runs_by_id:
                return candidate
            index += 1

    def _next_replacement_run_id(self, run_id: str) -> str:
        index = 1
        while True:
            candidate = f"{run_id}-replacement-{index}"
            if candidate not in self._runs_by_id:
                return candidate
            index += 1

    def _next_assignment_id(self) -> str:
        self._assignment_counter += 1
        return f"assignment-{self._assignment_counter}"

    def _next_checkpoint_id(self) -> str:
        self._checkpoint_counter += 1
        return f"checkpoint-{self._checkpoint_counter}"

    def _event_offsets(self) -> dict[str, int]:
        store = EventStore(self.repo_root)
        return {run_id: len(store.read_run(run_id)) for run_id in self._runs_by_id}

    def _start_child_session(self, *, run_id: str, goal: str) -> ChildSessionRef | None:
        if self.session_manager is None:
            return None

        start_session = getattr(self.session_manager, "start_session", None)
        get_session_ref = getattr(self.session_manager, "get_session_ref", None)
        if not callable(start_session) or not callable(get_session_ref):
            return None

        start_session(
            run_id=run_id,
            goal=goal,
            parent_run_id=self.root_run.run_id,
            workspace_path=str(self.repo_root),
        )
        session_ref = get_session_ref(run_id)
        if session_ref is None:
            raise RuntimeError("session manager did not create a child run session reference")
        return session_ref

    def _write_checkpoint(self, *, checkpoint_kind: str, bundle_version: int) -> Checkpoint:
        checkpoint = write_checkpoint(
            self.repo_root,
            checkpoint_id=self._next_checkpoint_id(),
            run_id=self.root_run.run_id,
            checkpoint_kind=checkpoint_kind,
            event_offsets=self._event_offsets(),
            bundle_version=bundle_version,
            authoritative_root=self.authoritative_root,
            active_worktrees=list(self.active_worktrees),
            created_at=self._clock(),
        )
        self.last_checkpoint = checkpoint
        return checkpoint


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)
