"""Recovery helpers for run resumption, lease repair, and checkpoint reconciliation."""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Literal

from ralphception.models.runtime import Checkpoint, Run, RunStageStatus
from ralphception.models.session import ChildSessionRef
from ralphception.storage.events import EventLogCorruptionError, EventStore
from ralphception.storage.files import write_json_atomic
from ralphception.storage.lease import (
    WorkspaceLease,
    acquire_workspace_lease,
    heartbeat_workspace_lease,
    lease_path,
)
from ralphception.workflow.engine import WorkflowEngine

ResumeMode = Literal["read", "repair"]
RecoveryAction = Literal["retry", "restart", "replace"] | None


class RecoveryBlockedError(RuntimeError):
    """Raised when recovery detects durable state that cannot be resumed safely."""


@dataclass(frozen=True, slots=True)
class ResumeResult:
    run_id: str
    mode: ResumeMode
    lease_taken: bool
    lease: WorkspaceLease | None
    checkpoint_reconciled: bool
    xdg_state_repaired: bool
    recommended_action: RecoveryAction


class RecoveryService:
    """Resume and repair durable workflow state without duplicating engine behavior."""

    def __init__(
        self,
        *,
        engine: WorkflowEngine,
        process_id: int,
        xdg_state_home: Path | None = None,
        clock: Callable[[], datetime] | None = None,
        lease_timeout: timedelta = timedelta(minutes=5),
    ) -> None:
        self.engine = engine
        self.process_id = process_id
        self.xdg_state_home = xdg_state_home
        self._clock = clock or _utc_now
        self.lease_timeout = lease_timeout
        self._active_lease_run_id: str | None = None

    def resume(self, *, run_id: str, mode: ResumeMode) -> ResumeResult:
        run = self.engine.run(run_id)
        checkpoint = self._latest_checkpoint()
        self._validate_event_logs(checkpoint)

        workspace_lease_path = lease_path(self.engine.repo_root, xdg_state_home=self.xdg_state_home)
        xdg_state_repaired = mode == "repair" and not workspace_lease_path.parent.exists()
        lease: WorkspaceLease | None = None

        if mode == "repair":
            lease = acquire_workspace_lease(
                self.engine.repo_root,
                run_id=self.engine.root_run.run_id,
                process_id=self.process_id,
                authoritative_repository_root=self._authoritative_root(),
                xdg_state_home=self.xdg_state_home,
                heartbeat_at=self._clock(),
                timeout=self.lease_timeout,
            )
            self._active_lease_run_id = lease.run_id

        return ResumeResult(
            run_id=run_id,
            mode=mode,
            lease_taken=lease is not None,
            lease=lease,
            checkpoint_reconciled=checkpoint is not None,
            xdg_state_repaired=xdg_state_repaired,
            recommended_action=self._recommended_action(run),
        )

    def heartbeat(self) -> WorkspaceLease:
        if self._active_lease_run_id is None:
            raise RuntimeError("repair-mode resume has not acquired a workspace lease")
        return heartbeat_workspace_lease(
            self.engine.repo_root,
            run_id=self._active_lease_run_id,
            xdg_state_home=self.xdg_state_home,
            heartbeat_at=self._clock(),
        )

    def retry_run(self, run_id: str) -> Run:
        run = self.engine.run(run_id)
        updated = self._update_run(
            run_id,
            status="pending",
            codex_session_ref=None,
            updated_at=self._clock(),
        )
        self._persist_run(updated)
        return updated

    def restart_run(self, run_id: str) -> Run:
        run = self.engine.run(run_id)
        session_ref = self._start_run_session(run)
        updated = self._update_run(
            run_id,
            status="running",
            codex_session_ref=session_ref,
            updated_at=self._clock(),
        )
        self._persist_run(updated)
        return updated

    def replace_run(self, run_id: str) -> Run:
        replacement = self.engine.replace_run(run_id)
        self._persist_run(self.engine.root_run)
        self._persist_run(replacement)
        return replacement

    def _validate_event_logs(self, checkpoint: Checkpoint | None) -> None:
        store = EventStore(self.engine.repo_root)
        try:
            for run in self.engine.runs():
                store.read_run(run.run_id)
        except EventLogCorruptionError as exc:
            raise RecoveryBlockedError(str(exc)) from exc

        if checkpoint is None:
            return

        for run_id, expected_offset in checkpoint.event_offsets.items():
            actual_offset = len(store.read_run(run_id))
            if actual_offset < expected_offset:
                raise RecoveryBlockedError(
                    f"checkpoint offset for run {run_id!r} regressed from {expected_offset} to {actual_offset}",
                )

    def _latest_checkpoint(self) -> Checkpoint | None:
        checkpoint_dir = (
            self.engine.repo_root
            / ".ralphception"
            / "runs"
            / self.engine.root_run.run_id
            / "checkpoints"
        )
        if not checkpoint_dir.exists():
            return None

        checkpoints = [
            Checkpoint.model_validate(json.loads(path.read_text(encoding="utf-8")))
            for path in checkpoint_dir.glob("*.json")
        ]
        if not checkpoints:
            return None
        return max(
            checkpoints,
            key=lambda checkpoint: (checkpoint.created_at, _checkpoint_sequence(checkpoint.checkpoint_id)),
        )

    def _recommended_action(self, run: Run) -> RecoveryAction:
        if run.status == "failed":
            return "retry"
        if run.status == "session_lost":
            return "restart"
        if run.status in {"blocked", "recovery_blocked"}:
            return "replace"
        return None

    def _authoritative_root(self) -> Path:
        return Path(self.engine.authoritative_root).resolve(strict=False)

    def _start_run_session(self, run: Run) -> ChildSessionRef:
        if self.engine.session_manager is None:
            raise RuntimeError("session manager is required to restart a run")
        start_session = getattr(self.engine.session_manager, "start_session", None)
        get_session_ref = getattr(self.engine.session_manager, "get_session_ref", None)
        if not callable(start_session) or not callable(get_session_ref):
            raise RuntimeError("session manager does not support restart")

        start_session(
            run_id=run.run_id,
            goal=run.goal,
            parent_run_id=run.parent_run_id,
            workspace_path=str(self.engine.repo_root),
        )
        session_ref = get_session_ref(run.run_id)
        if session_ref is None:
            raise RuntimeError("session manager did not return a resumed session reference")
        return session_ref

    def _update_run(
        self,
        run_id: str,
        *,
        status: RunStageStatus,
        codex_session_ref: ChildSessionRef | None,
        updated_at: datetime,
    ) -> Run:
        return self.engine.update_run(
            run_id,
            status=status,
            codex_session_ref=codex_session_ref,
            updated_at=updated_at,
        )

    def _persist_run(self, run: Run) -> None:
        write_json_atomic(
            self.engine.repo_root / ".ralphception" / "runs" / run.run_id / "run.json",
            run.model_dump(mode="json"),
        )


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _checkpoint_sequence(checkpoint_id: str) -> int:
    try:
        return int(checkpoint_id.rsplit("-", 1)[1])
    except (IndexError, ValueError):
        return -1


__all__ = [
    "RecoveryBlockedError",
    "RecoveryService",
    "ResumeResult",
]
