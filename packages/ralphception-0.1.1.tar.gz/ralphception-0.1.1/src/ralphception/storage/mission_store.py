"""Mission store for actor-runtime durable artifacts."""

from __future__ import annotations

import json
from pathlib import Path

from ralphception.models.commit_intents import CommitIntent
from ralphception.models.mission import MissionSession, PlannerOutput
from ralphception.models.todos import TodoNode
from ralphception.storage.commit_intents import read_commit_intents, write_commit_intents
from ralphception.storage.files import write_json_atomic
from ralphception.storage.todos import read_todo_graph, write_todo_graph


class MissionStore:
    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root

    def write_session(self, session: MissionSession) -> Path:
        return write_json_atomic(self._session_path(), session.model_dump(mode="json"))

    def read_session(self) -> MissionSession | None:
        path = self._session_path()
        if not path.exists():
            return None
        return MissionSession.model_validate(json.loads(path.read_text(encoding="utf-8")))

    def write_todos(self, todos: list[TodoNode]) -> Path:
        return write_todo_graph(self.repo_root, todos)

    def read_todos(self) -> list[TodoNode]:
        return read_todo_graph(self.repo_root)

    def write_commit_intents(self, intents: list[CommitIntent]) -> Path:
        return write_commit_intents(self.repo_root, intents)

    def read_commit_intents(self) -> list[CommitIntent]:
        return read_commit_intents(self.repo_root)

    def write_planner_output(self, output: PlannerOutput) -> Path:
        return write_json_atomic(self._planner_output_path(), output.model_dump(mode="json"))

    def read_planner_output(self) -> PlannerOutput | None:
        path = self._planner_output_path()
        if not path.exists():
            return None
        return PlannerOutput.model_validate(json.loads(path.read_text(encoding="utf-8")))

    def _session_path(self) -> Path:
        return self.repo_root / ".ralphception" / "mission" / "session.json"

    def _planner_output_path(self) -> Path:
        return self.repo_root / ".ralphception" / "mission" / "planner-output.json"
