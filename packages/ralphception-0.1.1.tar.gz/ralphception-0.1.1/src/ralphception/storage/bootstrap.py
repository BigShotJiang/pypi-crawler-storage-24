"""Bootstrap helpers for the repo-local Ralphception storage tree."""

from __future__ import annotations

from pathlib import Path

from ralphception.paths import project_dir

from .files import ensure_directory_tree_durable

REQUIRED_STORAGE_DIRECTORIES: tuple[str, ...] = (
    "events",
    "verification",
    "specs",
    "plans",
    "todos",
    "approvals",
    "runs",
    "skills",
    "findings",
    "merge",
)


def bootstrap_workspace(repo_root: Path) -> Path:
    """Ensure the tracked repo-local storage tree exists and return the repo root."""
    repo_root = repo_root.resolve(strict=False)
    storage_root = project_dir(repo_root)
    ensure_directory_tree_durable(storage_root)

    for directory in REQUIRED_STORAGE_DIRECTORIES:
        ensure_directory_tree_durable(storage_root / directory)

    return repo_root
