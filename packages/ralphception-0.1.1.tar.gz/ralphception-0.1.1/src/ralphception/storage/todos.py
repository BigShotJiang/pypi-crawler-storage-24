"""Todo graph storage helpers for the actor runtime."""

from __future__ import annotations

import json
from pathlib import Path

from pydantic import TypeAdapter

from ralphception.models.todos import TodoNode
from ralphception.storage.files import write_json_atomic

_TODO_LIST_ADAPTER = TypeAdapter(list[TodoNode])


def todo_graph_path(repo_root: Path) -> Path:
    return repo_root / ".ralphception" / "todos" / "todo-dag.json"


def write_todo_graph(repo_root: Path, todos: list[TodoNode]) -> Path:
    return write_json_atomic(
        todo_graph_path(repo_root),
        [todo.model_dump(mode="json") for todo in todos],
    )


def read_todo_graph(repo_root: Path) -> list[TodoNode]:
    path = todo_graph_path(repo_root)
    if not path.exists():
        return []
    return _TODO_LIST_ADAPTER.validate_python(json.loads(path.read_text(encoding="utf-8")))
