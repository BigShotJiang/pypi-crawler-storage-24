"""Helpers for promoting child-scoped artifacts during merge integration."""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Sequence

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.worktree import WorktreeHandoff

from .files import write_file_atomic


def promote_child_scoped_artifacts(
    destination_root: Path,
    handoff: WorktreeHandoff,
    stripped_paths: Sequence[str],
    load_artifact_bytes: Callable[[str], bytes],
) -> list[Path]:
    """Restore declared child-scoped .ralphception artifacts after stripping them."""
    written_paths: list[Path] = []
    declared_paths = {
        artifact_ref.artifact_path
        for artifact_ref in _iter_handoff_artifact_refs(handoff)
    }
    for relative_path in stripped_paths:
        if not _is_child_scoped_ralphception_path(relative_path, handoff.child_run_id):
            continue
        if relative_path not in declared_paths:
            continue
        destination_path = destination_root / relative_path
        write_file_atomic(destination_path, load_artifact_bytes(relative_path))
        written_paths.append(destination_path)
    return written_paths


def promoted_artifact_refs(
    handoff: WorktreeHandoff,
    stripped_paths: Sequence[str],
) -> list[ArtifactRef]:
    """Filter handoff refs down to the artifacts promoted into the merge result."""
    promoted: list[ArtifactRef] = []
    stripped_path_set = set(stripped_paths)
    for artifact_ref in _iter_handoff_artifact_refs(handoff):
        artifact_path = artifact_ref.artifact_path
        if artifact_path in stripped_path_set:
            if _is_child_scoped_ralphception_path(artifact_path, handoff.child_run_id):
                promoted.append(artifact_ref)
            continue
        if not _is_ralphception_path(artifact_path):
            promoted.append(artifact_ref)
    return promoted


def is_ralphception_path(path: str) -> bool:
    """Return whether a path lives under the repo-local Ralphception state root."""
    return path == ".ralphception" or path.startswith(".ralphception/")


def is_child_scoped_ralphception_path(path: str, child_run_id: str) -> bool:
    """Return whether a path is a child-run-scoped artifact path safe to promote."""
    return path.startswith(f".ralphception/runs/{child_run_id}/")


def _iter_handoff_artifact_refs(handoff: WorktreeHandoff) -> list[ArtifactRef]:
    return [*handoff.artifact_refs, *handoff.verification_artifact_refs]


def _is_ralphception_path(path: str) -> bool:
    return is_ralphception_path(path)


def _is_child_scoped_ralphception_path(path: str, child_run_id: str) -> bool:
    return is_child_scoped_ralphception_path(path, child_run_id)
