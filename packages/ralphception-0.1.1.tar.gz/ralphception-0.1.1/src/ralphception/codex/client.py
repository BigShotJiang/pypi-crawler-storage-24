"""Thin adapter over the Codex app-server CLI transport."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass, is_dataclass
from enum import Enum
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from typing import Any, Protocol, runtime_checkable

from ralphception.config import CodexConfig

_FIRST_CAMEL_BOUNDARY = re.compile(r"(.)([A-Z][a-z]+)")
_SECOND_CAMEL_BOUNDARY = re.compile(r"([a-z0-9])([A-Z])")
_THREAD_BASE_INSTRUCTIONS = (
    "You are Ralphception's embedded coding agent. Work only from this thread's "
    "instructions, the current workspace, and files inside the repository. Do not "
    "assume any outer chat history or desktop-specific guidance."
)
_THREAD_DEVELOPER_INSTRUCTIONS = (
    "This thread is running inside Ralphception's autonomous runtime. Follow the "
    "stage contract and prompt exactly, make the required repo-local changes, and "
    "produce the requested artifacts. Do not bootstrap external skill systems or "
    "desktop agent workflows unless this thread explicitly asks for them."
)
_THREAD_CONFIG_OVERRIDES = {
    "features.child_agents_md": False,
    "features.plugins": False,
    "skills.bundled.enabled": False,
}
_ISOLATED_CONFIG_TOML = """forced_login_method = 'chatgpt'
[features]
plugins = false
[skills.bundled]
enabled = false
"""


@dataclass(frozen=True, slots=True)
class RawCodexEvent:
    method: str
    payload: dict[str, Any]
    thread_id: str | None = None
    turn_id: str | None = None


@dataclass(frozen=True, slots=True)
class CodexThreadSession:
    thread_id: str
    session_id: str
    workspace_path: str
    model: str
    approval_policy: str | None = None
    sandbox: str | None = None


@dataclass(frozen=True, slots=True)
class CodexTurnRef:
    thread_id: str
    turn_id: str


class CodexClientError(RuntimeError):
    """Base exception for Ralphception's Codex client boundary."""


class CodexStartupFailedError(CodexClientError):
    """Raised when the app-server cannot be launched or initialized."""


class CodexSessionExpiredError(CodexClientError):
    """Raised when a stored Codex thread/session can no longer be resumed."""


class CodexTransportError(CodexClientError):
    """Raised when the app-server transport closes unexpectedly."""


class CodexProtocolError(CodexClientError):
    """Raised when the SDK returns an unexpected JSON-RPC or protocol failure."""


class CodexModelUnavailableError(CodexClientError):
    """Raised when the configured model is not available."""


class AppServerRpcError(RuntimeError):
    """Raised when the app-server returns a JSON-RPC error response."""

    def __init__(self, message: str, *, code: int | None = None) -> None:
        super().__init__(message)
        self.code = code


class TransportClosedError(RuntimeError):
    """Raised when the app-server closes the stdio transport unexpectedly."""


@runtime_checkable
class CodexClientProtocol(Protocol):
    def start(self) -> None: ...

    def initialize(self) -> None: ...

    def close(self) -> None: ...

    def thread_start(
        self,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession: ...

    def thread_resume(
        self,
        thread_id: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession: ...

    def thread_fork(
        self,
        thread_id: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession: ...

    def turn_start(
        self,
        thread_id: str,
        input_text: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexTurnRef: ...

    def turn_interrupt(self, thread_id: str, turn_id: str) -> None: ...

    def next_notification(self) -> RawCodexEvent: ...

    def stream_until_methods(self, methods: Iterable[str] | str) -> list[RawCodexEvent]: ...

    def model_list(self) -> tuple[str, ...]: ...


@runtime_checkable
class AppServerTransportProtocol(Protocol):
    def start(self) -> None: ...

    def close(self) -> None: ...

    def prepare_for_threads(self) -> None: ...

    def request(self, method: str, params: Mapping[str, Any] | None = None) -> dict[str, Any]: ...

    def next_notification(self) -> dict[str, Any]: ...


def codex_cli_available() -> bool:
    return shutil.which("codex") is not None


def normalize_notification(method: str, payload: Any) -> RawCodexEvent:
    normalized_payload = _coerce_mapping(payload)
    thread_id = _extract_string(normalized_payload.get("thread_id"))
    if thread_id is None:
        thread_id = _extract_nested_id(normalized_payload, "thread")
    turn_id = _extract_string(normalized_payload.get("turn_id"))
    if turn_id is None:
        turn_id = _extract_nested_id(normalized_payload, "turn")
    return RawCodexEvent(
        method=method,
        payload=normalized_payload,
        thread_id=thread_id,
        turn_id=turn_id,
    )


class SubprocessAppServerTransport(AppServerTransportProtocol):
    """Launch and speak JSON-RPC to ``codex app-server`` over stdio."""

    def __init__(
        self,
        *,
        command: tuple[str, ...] | None = None,
        process_factory: Any | None = None,
    ) -> None:
        self._command = command or (
            "codex",
            "app-server",
            "--disable",
            "child_agents_md",
            "--listen",
            "stdio://",
        )
        self._process_factory = process_factory or self._spawn_default_process
        self._process: Any | None = None
        self._isolated_codex_home: Path | None = None
        self._next_request_id = 1
        self._pending_notifications: list[dict[str, Any]] = []

    def start(self) -> None:
        if self._process is not None and self._process.poll() is None:
            return
        self._process = self._process_factory()

    def close(self) -> None:
        if self._process is None:
            return
        try:
            self._process.terminate()
            self._process.wait(timeout=5)
        finally:
            self._process = None
            self._cleanup_isolated_codex_home()

    def prepare_for_threads(self) -> None:
        self._prune_embedded_skills_cache()

    def request(self, method: str, params: Mapping[str, Any] | None = None) -> dict[str, Any]:
        self.start()
        request_id = self._next_request_id
        self._next_request_id += 1
        self._write_message(
            {
                "jsonrpc": "2.0",
                "id": request_id,
                "method": method,
                "params": dict(params or {}),
            },
        )
        while True:
            message = self._read_message()
            if "method" in message and "id" not in message:
                self._pending_notifications.append(message)
                continue
            if message.get("id") != request_id:
                continue
            error = message.get("error")
            if isinstance(error, dict):
                raise AppServerRpcError(
                    _extract_string(error.get("message")) or "app-server request failed",
                    code=error.get("code") if isinstance(error.get("code"), int) else None,
                )
            return message

    def next_notification(self) -> dict[str, Any]:
        self.start()
        if self._pending_notifications:
            return self._pending_notifications.pop(0)
        while True:
            message = self._read_message()
            if "method" in message and "id" not in message:
                return message

    def _spawn_default_process(self) -> subprocess.Popen[str]:
        return subprocess.Popen(
            self._command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=self._build_subprocess_env(),
        )

    def _write_message(self, message: Mapping[str, Any]) -> None:
        process = self._require_process()
        stdin = getattr(process, "stdin", None)
        if stdin is None:
            raise TransportClosedError("app-server stdin is unavailable")
        stdin.write(json.dumps(message) + "\n")
        stdin.flush()

    def _read_message(self) -> dict[str, Any]:
        process = self._require_process()
        stdout = getattr(process, "stdout", None)
        if stdout is None:
            raise TransportClosedError("app-server stdout is unavailable")
        line = stdout.readline()
        if line == "":
            stderr = getattr(process, "stderr", None)
            stderr_text = stderr.read() if stderr is not None else ""
            raise TransportClosedError(stderr_text.strip() or "Codex app-server closed the transport")
        try:
            message = json.loads(line)
        except json.JSONDecodeError as exc:
            raise AppServerRpcError(f"invalid JSON-RPC message from app-server: {exc}") from exc
        if not isinstance(message, dict):
            raise AppServerRpcError("app-server returned a non-object JSON-RPC message")
        return message

    def _require_process(self) -> Any:
        if self._process is None:
            raise TransportClosedError("app-server transport is not running")
        return self._process

    def _build_subprocess_env(self) -> dict[str, str]:
        env = dict(os.environ)
        isolated_codex_home = self._ensure_isolated_codex_home()
        isolated_root = str(isolated_codex_home)
        env["CODEX_HOME"] = isolated_root
        env["HOME"] = isolated_root
        env.pop("CODEX_THREAD_ID", None)
        return env

    def _ensure_isolated_codex_home(self) -> Path:
        if self._isolated_codex_home is not None:
            return self._isolated_codex_home

        isolated_home = Path(tempfile.mkdtemp(prefix="ralphception-codex-home-"))
        source_home = _resolve_codex_home()
        auth_source = source_home / "auth.json"
        if auth_source.is_file():
            shutil.copy2(auth_source, isolated_home / "auth.json")
        (isolated_home / "config.toml").write_text(_ISOLATED_CONFIG_TOML, encoding="utf-8")
        self._isolated_codex_home = isolated_home
        return isolated_home

    def _cleanup_isolated_codex_home(self) -> None:
        if self._isolated_codex_home is None:
            return
        shutil.rmtree(self._isolated_codex_home, ignore_errors=True)
        self._isolated_codex_home = None

    def _prune_embedded_skills_cache(self) -> None:
        if self._isolated_codex_home is None:
            return
        shutil.rmtree(self._isolated_codex_home / "skills" / ".system", ignore_errors=True)


class CodexAppServerClient(CodexClientProtocol):
    """Lazy adapter around ``codex app-server`` over stdio JSON-RPC."""

    def __init__(self, *, cwd: str | None = None, transport: AppServerTransportProtocol | None = None) -> None:
        self._cwd = cwd
        self._transport = transport or SubprocessAppServerTransport()
        self.started = False
        self.initialized = False
        self.closed = False

    def start(self) -> None:
        if self.started:
            return
        try:
            self._transport.start()
        except BaseException as exc:
            self._raise_translated_error(exc, startup=True)
        self.started = True
        self.closed = False

    def initialize(self) -> None:
        self.start()
        if self.initialized:
            return
        try:
            self._transport.request(
                "initialize",
                {
                    "clientInfo": {"name": "ralphception", "version": "0.0.0"},
                    "capabilities": {"experimentalApi": True, "suppressNotifications": []},
                },
            )
            self._transport.prepare_for_threads()
        except BaseException as exc:
            self._raise_translated_error(exc, startup=True)
        self.initialized = True

    def close(self) -> None:
        try:
            self._transport.close()
        except BaseException as exc:
            self._raise_translated_error(exc, startup=False)
        finally:
            self.started = False
            self.initialized = False
            self.closed = True

    def thread_start(
        self,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession:
        self._ensure_ready()
        payload = _compact(
            {
                "approvalPolicy": config.approval_policy,
                "baseInstructions": _THREAD_BASE_INSTRUCTIONS,
                "config": _THREAD_CONFIG_OVERRIDES,
                "cwd": cwd,
                "developerInstructions": _THREAD_DEVELOPER_INSTRUCTIONS,
                "model": config.model,
                "sandbox": config.sandbox,
                "experimentalRawEvents": False,
                "persistExtendedHistory": True,
            },
        )
        try:
            response = self._request("thread/start", payload)
        except BaseException as exc:
            self._raise_translated_error(exc, startup=False)
        return self._coerce_thread_session(response)

    def thread_resume(
        self,
        thread_id: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession:
        self._ensure_ready()
        payload = _compact(
            {
                "threadId": thread_id,
                "approvalPolicy": config.approval_policy,
                "baseInstructions": _THREAD_BASE_INSTRUCTIONS,
                "config": _THREAD_CONFIG_OVERRIDES,
                "cwd": cwd,
                "developerInstructions": _THREAD_DEVELOPER_INSTRUCTIONS,
                "model": config.model,
                "sandbox": config.sandbox,
                "persistExtendedHistory": True,
            },
        )
        try:
            response = self._request("thread/resume", payload)
        except BaseException as exc:
            self._raise_translated_error(exc, startup=False)
        return self._coerce_thread_session(response)

    def thread_fork(
        self,
        thread_id: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession:
        self._ensure_ready()
        payload = _compact(
            {
                "threadId": thread_id,
                "approvalPolicy": config.approval_policy,
                "baseInstructions": _THREAD_BASE_INSTRUCTIONS,
                "config": _THREAD_CONFIG_OVERRIDES,
                "cwd": cwd,
                "developerInstructions": _THREAD_DEVELOPER_INSTRUCTIONS,
                "model": config.model,
                "sandbox": config.sandbox,
                "persistExtendedHistory": True,
            },
        )
        try:
            response = self._request("thread/fork", payload)
        except BaseException as exc:
            self._raise_translated_error(exc, startup=False)
        return self._coerce_thread_session(response)

    def turn_start(
        self,
        thread_id: str,
        input_text: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexTurnRef:
        self._ensure_ready()
        payload = _compact(
            {
                "threadId": thread_id,
                "input": [{"type": "text", "text": input_text}],
                "approvalPolicy": config.approval_policy,
                "cwd": cwd,
                "effort": config.reasoning,
                "model": config.model,
                "sandboxPolicy": _sandbox_policy(config.sandbox, cwd or self._cwd),
            },
        )
        try:
            response = self._request("turn/start", payload)
        except BaseException as exc:
            self._raise_translated_error(exc, startup=False)
        data = _coerce_mapping(response)
        turn = data.get("turn")
        if not isinstance(turn, dict):
            raise CodexProtocolError("turn/start response did not include a turn payload")
        turn_id = _extract_string(turn.get("id"))
        if turn_id is None:
            raise CodexProtocolError("turn/start response did not include turn.id")
        return CodexTurnRef(thread_id=thread_id, turn_id=turn_id)

    def turn_interrupt(self, thread_id: str, turn_id: str) -> None:
        self._ensure_ready()
        try:
            self._request("turn/interrupt", {"threadId": thread_id, "turnId": turn_id})
        except BaseException as exc:
            self._raise_translated_error(exc, startup=False)

    def next_notification(self) -> RawCodexEvent:
        self._ensure_ready()
        try:
            notification = self._transport.next_notification()
        except BaseException as exc:
            self._raise_translated_error(exc, startup=False)
        method = notification.get("method")
        if not isinstance(method, str):
            raise CodexProtocolError("notification missing method")
        return normalize_notification(method, notification.get("params"))

    def stream_until_methods(self, methods: Iterable[str] | str) -> list[RawCodexEvent]:
        self._ensure_ready()
        target_methods = {methods} if isinstance(methods, str) else set(methods)
        notifications: list[RawCodexEvent] = []
        while True:
            notification = self.next_notification()
            notifications.append(notification)
            if notification.method in target_methods:
                return notifications

    def model_list(self) -> tuple[str, ...]:
        self._ensure_ready()
        try:
            response = self._request("model/list", {})
        except BaseException as exc:
            self._raise_translated_error(exc, startup=False)
        data = _coerce_mapping(response)
        raw_models = data.get("data")
        if not isinstance(raw_models, list):
            raise CodexProtocolError("model/list response did not include data")
        model_names: list[str] = []
        for raw_model in raw_models:
            if not isinstance(raw_model, dict):
                continue
            model_name = _extract_string(raw_model.get("model"))
            if model_name is not None:
                model_names.append(model_name)
        return tuple(model_names)

    def _ensure_ready(self) -> None:
        if not self.started:
            self.start()
        if not self.initialized:
            self.initialize()

    def _request(self, method: str, params: Mapping[str, Any] | None = None) -> dict[str, Any]:
        response = self._transport.request(method, params)
        return _coerce_mapping(response.get("result"))

    def _coerce_thread_session(self, response: Any) -> CodexThreadSession:
        data = _coerce_mapping(response)
        thread = data.get("thread")
        if not isinstance(thread, dict):
            raise CodexProtocolError("thread response did not include thread")
        thread_id = _extract_string(thread.get("id"))
        if thread_id is None:
            raise CodexProtocolError("thread response did not include thread.id")
        session_id = _extract_string(data.get("session_id")) or thread_id
        workspace_path = _extract_string(data.get("cwd")) or _extract_string(thread.get("cwd")) or self._cwd or ""
        if not workspace_path:
            raise CodexProtocolError("thread response did not include cwd")
        return CodexThreadSession(
            thread_id=thread_id,
            session_id=session_id,
            workspace_path=workspace_path,
            model=_extract_string(data.get("model")) or "",
            approval_policy=_extract_string(data.get("approval_policy")),
            sandbox=_coerce_sandbox(data.get("sandbox")),
        )

    def _raise_translated_error(self, exc: BaseException, *, startup: bool) -> None:
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise exc
        if isinstance(exc, CodexClientError):
            raise exc
        if startup and isinstance(exc, (FileNotFoundError, ImportError, ModuleNotFoundError, OSError)):
            raise CodexStartupFailedError(str(exc)) from exc
        if isinstance(exc, TransportClosedError) or exc.__class__.__name__ == "TransportClosedError":
            raise CodexTransportError(str(exc)) from exc

        message = str(exc)
        lowered = message.lower()
        if _looks_like_session_expired(lowered):
            raise CodexSessionExpiredError(message) from exc
        if _looks_like_model_unavailable(lowered):
            raise CodexModelUnavailableError(message) from exc
        if _looks_like_protocol_error(exc, lowered):
            raise CodexProtocolError(message) from exc
        if startup:
            raise CodexStartupFailedError(message) from exc
        raise CodexProtocolError(message) from exc


def _compact(values: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in values.items() if value is not None}


def _resolve_codex_home() -> Path:
    env_home = os.environ.get("CODEX_HOME")
    if env_home:
        return Path(env_home).expanduser()
    return Path.home() / ".codex"


def _coerce_mapping(value: Any) -> dict[str, Any]:
    normalized = _normalize_value(value)
    if isinstance(normalized, dict):
        return normalized
    return {"value": normalized}


def _normalize_value(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return _normalize_value(value.model_dump(by_alias=True, mode="json"))
    if is_dataclass(value):
        return _normalize_value(asdict(value))
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {_to_snake_case(str(key)): _normalize_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_normalize_value(item) for item in value]
    return value


def _to_snake_case(value: str) -> str:
    with_boundaries = _FIRST_CAMEL_BOUNDARY.sub(r"\1_\2", value)
    normalized = _SECOND_CAMEL_BOUNDARY.sub(r"\1_\2", with_boundaries)
    return normalized.replace("-", "_").lower()


def _extract_string(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None


def _extract_nested_id(payload: Mapping[str, Any], key: str) -> str | None:
    nested = payload.get(key)
    if not isinstance(nested, dict):
        return None
    nested_id = nested.get("id")
    return _extract_string(nested_id)


def _coerce_sandbox(value: Any) -> str | None:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        sandbox_type = value.get("type")
        if sandbox_type == "danger_full_access" or sandbox_type == "dangerFullAccess":
            return "danger-full-access"
        if sandbox_type == "workspace_write" or sandbox_type == "workspaceWrite":
            return "workspace-write"
        if sandbox_type == "read_only" or sandbox_type == "readOnly":
            return "read-only"
    return None


def _sandbox_policy(sandbox: str, cwd: str | None) -> dict[str, Any]:
    if sandbox == "danger-full-access":
        return {"type": "dangerFullAccess"}
    if sandbox == "read-only":
        return {"type": "readOnly", "access": {"type": "fullAccess"}}
    writable_root = cwd or "."
    return {
        "type": "workspaceWrite",
        "writableRoots": [writable_root],
        "readOnlyAccess": {"type": "fullAccess"},
        "networkAccess": True,
        "excludeTmpdirEnvVar": False,
        "excludeSlashTmp": False,
    }


def _looks_like_session_expired(lowered: str) -> bool:
    return (
        "session expired" in lowered
        or "thread expired" in lowered
        or "thread not found" in lowered
        or "session not found" in lowered
        or "thread not loaded" in lowered
    )


def _looks_like_model_unavailable(lowered: str) -> bool:
    return "model" in lowered and (
        "unavailable" in lowered or "not found" in lowered or "unsupported" in lowered
    )


def _looks_like_protocol_error(exc: BaseException, lowered: str) -> bool:
    name = exc.__class__.__name__
    return (
        "json-rpc" in lowered
        or "json rpc" in lowered
        or name
        in {
            "JsonRpcError",
            "AppServerRpcError",
            "InvalidRequestError",
            "MethodNotFoundError",
            "InvalidParamsError",
            "InternalRpcError",
            "ParseError",
        }
        or name.endswith("RpcError")
        or name.endswith("JsonRpcError")
    )
