"""Textual dashboard package for Ralphception."""

__all__: list[str] = []
