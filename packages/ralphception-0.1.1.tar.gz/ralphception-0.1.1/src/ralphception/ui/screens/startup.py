"""First-run bootstrap capture and startup screen helpers."""

from __future__ import annotations

import hashlib
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import Screen
from textual.widgets import Button, Static, TextArea

from ralphception.models.artifacts import ArtifactRef
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic, write_markdown_atomic

_ROOT_RUN_ID = "run-root"
_BOOTSTRAPPED_RESULT = "bootstrapped"


class StartupRecord(BaseModel):
    """Persisted first-run bootstrap state."""

    outer_run_id: str
    seed_prompt: str
    source_repos: list[str]
    intake_artifact: ArtifactRef
    created_at: datetime


def startup_record_path(repo_root: Path, *, run_id: str = _ROOT_RUN_ID) -> Path:
    """Return the durable startup record path for the root run."""
    repo_root = bootstrap_workspace(repo_root)
    return repo_root / ".ralphception" / "runs" / run_id / "startup.json"


def intake_artifact_path(repo_root: Path, *, run_id: str = _ROOT_RUN_ID) -> Path:
    """Return the durable intake artifact path for the root run."""
    repo_root = bootstrap_workspace(repo_root)
    return repo_root / ".ralphception" / "runs" / run_id / "intake.md"


def load_startup_record(repo_root: Path, *, run_id: str = _ROOT_RUN_ID) -> StartupRecord | None:
    """Load the persisted first-run bootstrap state if present."""
    path = startup_record_path(repo_root, run_id=run_id)
    if not path.exists():
        return None
    return StartupRecord.model_validate_json(path.read_text(encoding="utf-8"))


class StartupBootstrapController:
    """Capture first-run inputs into the durable workspace state."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = bootstrap_workspace(repo_root)

    def needs_bootstrap(self) -> bool:
        """Return whether the current workspace still needs first-run capture."""
        return load_startup_record(self.repo_root) is None

    def start_first_run(
        self,
        *,
        seed_prompt: str,
        source_repos: Sequence[Path | str],
    ) -> StartupRecord:
        """Persist the initial seed prompt and source repositories."""
        normalized_seed_prompt = seed_prompt.strip()
        if not normalized_seed_prompt:
            raise ValueError("seed_prompt must not be blank")

        normalized_source_repos = [
            str(Path(repo_path).expanduser().resolve(strict=False))
            for repo_path in source_repos
        ]
        created_at = datetime.now(timezone.utc)
        intake_markdown = _render_intake_markdown(
            seed_prompt=normalized_seed_prompt,
            source_repos=normalized_source_repos,
        )
        intake_path = intake_artifact_path(self.repo_root)
        write_markdown_atomic(intake_path, intake_markdown)
        record = StartupRecord(
            outer_run_id=_ROOT_RUN_ID,
            seed_prompt=normalized_seed_prompt,
            source_repos=normalized_source_repos,
            intake_artifact=_artifact_ref_for_text(
                artifact_kind="intake",
                artifact_path=str(intake_path.relative_to(self.repo_root)),
                artifact_version=1,
                content=intake_markdown,
            ),
            created_at=created_at,
        )
        write_json_atomic(startup_record_path(self.repo_root), record.model_dump(mode="json"))
        EventStore(self.repo_root).append(
            event_id=f"run-created-{record.outer_run_id}",
            run_id=record.outer_run_id,
            event_type="run.created",
            source="ui.startup",
            payload={
                "goal": record.seed_prompt,
                "parent_run_id": None,
            },
            occurred_at=record.created_at,
        )
        return record

    def summary_text(self) -> str:
        """Return the current startup summary for the screen."""
        record = load_startup_record(self.repo_root)
        if record is None:
            return (
                "First-run bootstrap\n\n"
                "Seed prompt: pending\n"
                "Source repos: pending\n"
                "Next step: capture the root prompt and any source repositories."
            )
        source_lines = "\n".join(f"- {repo_path}" for repo_path in record.source_repos) or "- none"
        return (
            "First-run bootstrap complete\n\n"
            f"Run: {record.outer_run_id}\n"
            f"Seed prompt: {record.seed_prompt}\n"
            "Source repos:\n"
            f"{source_lines}"
        )


class StartupScreen(Screen[None]):
    """Interactive screen for first-run bootstrap capture."""

    def __init__(self, controller: StartupBootstrapController) -> None:
        super().__init__()
        self.controller = controller

    def compose(self) -> ComposeResult:
        with Vertical(id="startup-screen"):
            yield Static(
                "First-run bootstrap\n\n"
                "Enter the seed prompt for this workspace and, if needed, one source "
                "repository path per line.",
                id="startup-intro",
            )
            yield Static("Seed prompt", classes="startup-label")
            yield TextArea("", id="startup-seed-prompt")
            yield Static("Source repositories", classes="startup-label")
            yield TextArea("", id="startup-source-repos")
            yield Button("Bootstrap workspace", id="startup-submit", variant="primary")
            yield Static("", id="startup-feedback")
            yield Static(self.rendered_text(), id="startup-summary")

    def rendered_text(self) -> str:
        """Return the screen text shown during bootstrap."""
        return self.controller.summary_text()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id != "startup-submit":
            return

        seed_prompt = self.query_one("#startup-seed-prompt", TextArea).text
        source_repos = self.query_one("#startup-source-repos", TextArea).text

        try:
            self.controller.start_first_run(
                seed_prompt=seed_prompt,
                source_repos=_parse_source_repos(source_repos),
            )
        except ValueError as exc:
            if str(exc) == "seed_prompt must not be blank":
                self._set_feedback("Seed prompt is required.")
            else:
                self._set_feedback(str(exc))
            return

        self._set_feedback("Bootstrap complete. Launching the workspace dashboard.")
        self._refresh_summary()
        self.app.exit(result=_BOOTSTRAPPED_RESULT)

    def _refresh_summary(self) -> None:
        self.query_one("#startup-summary", Static).update(self.rendered_text())

    def _set_feedback(self, message: str) -> None:
        self.query_one("#startup-feedback", Static).update(message)


def _render_intake_markdown(*, seed_prompt: str, source_repos: Sequence[str]) -> str:
    source_lines = "\n".join(f"- {repo_path}" for repo_path in source_repos) or "- none"
    return (
        "# Intake\n\n"
        f"Seed prompt: {seed_prompt}\n\n"
        "Source repositories:\n"
        f"{source_lines}\n"
    )


def _artifact_ref_for_text(
    *,
    artifact_kind: str,
    artifact_path: str,
    artifact_version: int,
    content: str,
) -> ArtifactRef:
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=artifact_version,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )


def _parse_source_repos(raw_text: str) -> list[str]:
    normalized_paths: list[str] = []
    for line in raw_text.replace(",", "\n").splitlines():
        candidate = line.strip()
        if candidate:
            normalized_paths.append(candidate)
    return normalized_paths


__all__ = [
    "StartupBootstrapController",
    "StartupRecord",
    "StartupScreen",
    "_BOOTSTRAPPED_RESULT",
    "intake_artifact_path",
    "load_startup_record",
    "startup_record_path",
]
