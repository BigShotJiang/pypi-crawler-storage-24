"""Event feed widget for replayed runtime events."""

from __future__ import annotations

from dataclasses import dataclass

from textual.widgets import Static


@dataclass(frozen=True, slots=True)
class EventFeedEntry:
    """Single rendered event-feed row."""

    sequence: int
    event_type: str
    text: str


class EventFeedWidget(Static):
    """Static panel showing recent event-log activity."""

    def set_entries(self, entries: list[EventFeedEntry]) -> None:
        """Render durable events in replay order."""
        if not entries:
            self.update("No events recorded yet.")
            return
        self.update("\n".join(f"{entry.sequence:04d}  {entry.text}" for entry in entries))
