"""Workflow tree widget for the Ralphception dashboard."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from textual.widgets import Tree


@dataclass(frozen=True, slots=True)
class WorkflowTreeEntry:
    """A single workflow node rendered in the dashboard tree."""

    node_id: str
    parent_id: str | None
    label: str
    status: str


class WorkflowTreeWidget(Tree[WorkflowTreeEntry]):
    """Tree view of the current workflow structure."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__("Workflow", *args, **kwargs)
        self.show_root = True
        self._loaded_entries: tuple[WorkflowTreeEntry, ...] = ()
        self._loaded_selected_node_id: str | None = None

    def load_entries(
        self,
        entries: list[WorkflowTreeEntry],
        *,
        selected_node_id: str | None = None,
    ) -> None:
        """Replace tree contents with the supplied workflow snapshot."""
        snapshot = tuple(entries)
        if snapshot == self._loaded_entries and selected_node_id == self._loaded_selected_node_id:
            return

        if not entries:
            self.clear()
            self.root.set_label("Workflow")
            self.root.data = None
            self._loaded_entries = ()
            self._loaded_selected_node_id = selected_node_id
            return

        root_entry = entries[0]
        expanded_node_ids = self._expanded_node_ids()
        expanded_node_ids.update(_ancestor_node_ids(entries, selected_node_id))
        self.clear()
        self.root.set_label(_label(root_entry))
        self.root.data = root_entry
        self.root.expand()

        tree_nodes: dict[str, Any] = {root_entry.node_id: self.root}
        for entry in entries[1:]:
            parent = tree_nodes.get(entry.parent_id or root_entry.node_id, self.root)
            tree_nodes[entry.node_id] = parent.add(_label(entry), data=entry)

        for node_id, node in tree_nodes.items():
            if node_id != root_entry.node_id and node_id in expanded_node_ids:
                node.expand()

        if selected_node_id and selected_node_id in tree_nodes:
            self.select_node(tree_nodes[selected_node_id])

        self._loaded_entries = snapshot
        self._loaded_selected_node_id = selected_node_id

    def _expanded_node_ids(self) -> set[str]:
        expanded: set[str] = set()
        for node in self.root.children:
            self._collect_expanded(node, expanded)
        return expanded

    def _collect_expanded(self, node: Any, expanded: set[str]) -> None:
        entry = getattr(node, "data", None)
        if entry is not None and getattr(node, "is_expanded", False):
            expanded.add(entry.node_id)
        for child in getattr(node, "children", ()):
            self._collect_expanded(child, expanded)


def _label(entry: WorkflowTreeEntry) -> str:
    return f"{entry.label} [{entry.status}]"


def _ancestor_node_ids(entries: list[WorkflowTreeEntry], node_id: str | None) -> set[str]:
    if node_id is None:
        return set()
    by_id = {entry.node_id: entry for entry in entries}
    expanded: set[str] = set()
    current = by_id.get(node_id)
    while current is not None and current.parent_id is not None:
        expanded.add(current.parent_id)
        current = by_id.get(current.parent_id)
    return expanded
