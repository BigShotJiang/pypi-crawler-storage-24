"""Detail pane widget for workflow selections."""

from __future__ import annotations

from dataclasses import dataclass

from textual.widgets import Static


@dataclass(frozen=True, slots=True)
class DetailContent:
    """Renderable detail view for the selected workflow node."""

    title: str
    lines: tuple[str, ...]
    blocked_reason: str | None = None
    next_actions: tuple[str, ...] = ()
    actions: tuple[str, ...] = ()


class DetailPaneWidget(Static):
    """Static panel that renders selected-node details and actions."""

    def show_detail(self, detail: DetailContent | None) -> None:
        """Render detail pane content for the active selection."""
        if detail is None:
            self.update("No workflow node selected.")
            return

        parts = [detail.title, "", *detail.lines]
        if detail.blocked_reason:
            parts.extend(["", f"Blocked reason: {detail.blocked_reason}"])
        if detail.next_actions:
            parts.extend(["", f"Next actions: {' '.join(detail.next_actions)}"])
        if detail.actions:
            parts.extend(["", f"Commands: {' '.join(detail.actions)}"])
        self.update("\n".join(parts))
