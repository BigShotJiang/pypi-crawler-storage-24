"""Command entry widget for dashboard slash commands."""

from __future__ import annotations

from textual.widgets import Input


class CommandBarWidget(Input):
    """Bottom-of-screen slash-command input."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(
            placeholder="Enter a slash command. Try /help",
            *args,
            **kwargs,
        )
