"""Merge coordination and stale-handoff validation helpers."""

from __future__ import annotations

import json
import shutil
import subprocess
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Literal, Sequence

from ralphception.git.worktrees import IntegrationRootUnavailable, WorktreeCoordinator
from ralphception.git.identity import resolve_git_commit_identity
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ChildAssignment, ExecutionBundle
from ralphception.storage.checkpoints import write_checkpoint
from ralphception.models.worktree import WorktreeHandoff
from ralphception.storage.artifacts import (
    is_child_scoped_ralphception_path,
    is_ralphception_path,
    promote_child_scoped_artifacts,
    promoted_artifact_refs as collect_promoted_artifact_refs,
)
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic
from ralphception.workflow.bundles import is_bundle_consumable

HandoffStatus = Literal["ready", "stale", "blocked"]
PathStatus = Literal["ready", "blocked"]
MergeStatus = Literal["merged", "conflict", "stale", "blocked"]
ResumeAction = Literal[
    "retry_merge",
    "complete_or_rollback_integration",
    "reconcile_branch_and_checkout",
    "reconcile_branch_and_lease",
    "merge_consistent",
]


@dataclass(frozen=True, slots=True)
class HandoffValidationResult:
    status: HandoffStatus
    reasons: list[str]
    requires_revalidation: bool = False


@dataclass(frozen=True, slots=True)
class HandoffPathValidationResult:
    status: PathStatus
    reasons: list[str]
    forbidden_paths: list[str]
    stripped_paths: list[str]


@dataclass(frozen=True, slots=True)
class PartialMergeRecoveryOutcome:
    integration_updated: bool
    branch_moved: bool
    lease_updated: bool
    checkout_updated: bool
    requires_authoritative_root_shift: bool
    requires_lease_fix: bool
    requires_checkout_fix: bool
    resume_action: ResumeAction


@dataclass(frozen=True, slots=True)
class MergeOutcome:
    status: MergeStatus
    reasons: list[str]
    merge_record_path: Path
    integration_worktree_path: Path
    promoted_artifact_refs: list[ArtifactRef]
    merge_commit: str | None = None
    requires_revalidation: bool = False
    recovery: PartialMergeRecoveryOutcome | None = None


@dataclass(frozen=True, slots=True)
class MergeEligibilityContext:
    latest_goal: str
    changed_dependency_paths: list[str]
    acceptance_criteria_changed: bool
    changed_touched_paths: list[str]


class MergeCoordinator:
    """Validate and integrate a child handoff through a clean integration worktree."""

    def __init__(
        self,
        *,
        repo_root: Path,
        run_id: str,
        stage_id: str,
        target_branch: str,
        xdg_state_home: Path | None = None,
    ) -> None:
        self.repo_root = bootstrap_workspace(repo_root)
        self.run_id = run_id
        self.stage_id = stage_id
        self.target_branch = target_branch
        self.xdg_state_home = xdg_state_home
        self._worktrees = WorktreeCoordinator(
            repo_root=self.repo_root,
            xdg_state_home=xdg_state_home,
        )

    def finalize_merge(
        self,
        *,
        handoff: WorktreeHandoff,
        latest_bundle: ExecutionBundle,
        latest_goal: str,
        dependency_refs: Sequence[ArtifactRef],
        newest_required_verification_passed: bool,
        changed_dependency_paths: Sequence[str] | None = None,
        acceptance_criteria_changed: bool = False,
        changed_touched_paths: Sequence[str] | None = None,
        run_merge_verification: Callable[[Path], bool] | None = None,
        spawn_conflict_run: Callable[[str], object] | None = None,
    ) -> MergeOutcome:
        del latest_bundle, dependency_refs
        latest_bundle = self._latest_consumable_bundle()
        assignment = self._read_child_assignment(handoff.child_run_id)
        if handoff.consumed_bundle_version != assignment.bundle_version:
            return self._write_outcome_record(
                record_root=self.repo_root,
                handoff=handoff,
                status="blocked",
                reasons=["handoff bundle version does not match durable child assignment"],
                integration_worktree_path=Path(handoff.worktree_path),
                promoted_artifact_refs=[],
                merge_commit=None,
                requires_revalidation=False,
                recovery=None,
            )
        if handoff.goal != assignment.goal:
            return self._write_outcome_record(
                record_root=self.repo_root,
                handoff=handoff,
                status="blocked",
                reasons=["handoff goal does not match durable child assignment"],
                integration_worktree_path=Path(handoff.worktree_path),
                promoted_artifact_refs=[],
                merge_commit=None,
                requires_revalidation=False,
                recovery=None,
            )
        computed_changed_dependency_paths = self._changed_artifact_paths(
            assignment.dependency_refs,
            latest_bundle.artifact_refs,
        )
        changed_acceptance_paths = self._changed_artifact_paths(
            assignment.acceptance_criteria_refs,
            latest_bundle.artifact_refs,
        )
        effective_latest_goal = assignment.goal
        effective_changed_dependency_paths = computed_changed_dependency_paths
        effective_acceptance_criteria_changed = bool(changed_acceptance_paths)
        effective_changed_touched_paths = sorted(
            {
                *computed_changed_dependency_paths,
                *changed_acceptance_paths,
            },
        )
        if latest_bundle.bundle_version > assignment.bundle_version:
            merge_context = self._ensure_merge_context(
                child_run_id=handoff.child_run_id,
                assignment=assignment,
                latest_goal=latest_goal,
                changed_dependency_paths=changed_dependency_paths,
                acceptance_criteria_changed=acceptance_criteria_changed,
                changed_touched_paths=changed_touched_paths,
                computed_changed_dependency_paths=computed_changed_dependency_paths,
                changed_acceptance_paths=changed_acceptance_paths,
            )
            effective_latest_goal = merge_context.latest_goal
            effective_changed_dependency_paths = sorted(
                {
                    *computed_changed_dependency_paths,
                    *merge_context.changed_dependency_paths,
                },
            )
            effective_acceptance_criteria_changed = (
                effective_acceptance_criteria_changed or merge_context.acceptance_criteria_changed
            )
            effective_changed_touched_paths = sorted(
                {
                    *effective_changed_dependency_paths,
                    *changed_acceptance_paths,
                    *merge_context.changed_touched_paths,
                },
            )
        reported_path_validation = validate_handoff_paths(handoff)
        diff_path_validation = _validate_candidate_paths(
            handoff.child_run_id,
            self._child_diff_paths(handoff),
        )
        path_validation = _combine_path_validations(
            reported_path_validation,
            diff_path_validation,
        )
        if path_validation.status == "blocked":
            return self._write_outcome_record(
                record_root=self.repo_root,
                handoff=handoff,
                status="blocked",
                reasons=path_validation.reasons,
                integration_worktree_path=Path(handoff.worktree_path),
                promoted_artifact_refs=[],
                merge_commit=None,
                requires_revalidation=False,
                recovery=None,
            )

        normalized_handoff = WorktreeHandoff(
            child_run_id=handoff.child_run_id,
            worktree_path=handoff.worktree_path,
            branch_name=handoff.branch_name,
            base_branch=handoff.base_branch,
            head_commit=handoff.head_commit,
            goal=assignment.goal,
            artifact_refs=handoff.artifact_refs,
            verification_artifact_refs=handoff.verification_artifact_refs,
            consumed_bundle_version=assignment.bundle_version,
            touched_paths=handoff.touched_paths,
            verification_summary=handoff.verification_summary,
            merge_readiness=handoff.merge_readiness,
            cleanup_state=handoff.cleanup_state,
        )
        handoff_validation = validate_handoff(
            repo_root=self.repo_root,
            handoff=normalized_handoff,
            latest_bundle=latest_bundle,
            latest_goal=effective_latest_goal,
            dependency_refs=list(assignment.dependency_refs),
            newest_required_verification_passed=newest_required_verification_passed,
            changed_dependency_paths=effective_changed_dependency_paths,
            acceptance_criteria_changed=effective_acceptance_criteria_changed,
            changed_touched_paths=effective_changed_touched_paths,
        )
        if handoff_validation.status != "ready":
            return self._write_outcome_record(
                record_root=self.repo_root,
                handoff=handoff,
                status=handoff_validation.status,
                reasons=handoff_validation.reasons,
                integration_worktree_path=Path(handoff.worktree_path),
                promoted_artifact_refs=[],
                merge_commit=None,
                requires_revalidation=handoff_validation.requires_revalidation,
                recovery=None,
            )

        operator_dirty = self._is_dirty_checkout(self.repo_root, include_ralphception=True)
        if operator_dirty:
            self._write_dirty_workspace_checkpoint(
                handoff=handoff,
                bundle_version=latest_bundle.bundle_version,
            )

        try:
            integration = self._worktrees.create_integration_worktree(
                run_id=self.run_id,
                target_branch=self.target_branch,
            )
        except IntegrationRootUnavailable:
            return self._write_outcome_record(
                record_root=self.repo_root,
                handoff=handoff,
                status="blocked",
                reasons=["unable to establish a clean integration worktree"],
                integration_worktree_path=Path(handoff.worktree_path),
                promoted_artifact_refs=[],
                merge_commit=None,
                requires_revalidation=False,
                recovery=None,
            )
        integration_path = integration.worktree_path
        reusing_current_checkout = integration_path.resolve(strict=False) == self.repo_root.resolve(strict=False)
        base_commit = self._git_output(self.repo_root, "rev-parse", self.target_branch)

        merge_result = self._run_git_checked(
            integration_path,
            "merge",
            "--squash",
            "--no-commit",
            handoff.head_commit,
        )
        if merge_result.returncode != 0:
            if _is_merge_conflict(merge_result):
                self._cleanup_conflicted_integration(integration_path)
                if spawn_conflict_run is not None:
                    spawn_conflict_run(
                        f"Resolve merge conflicts for {handoff.child_run_id} into {self.target_branch}",
                    )
                return self._write_outcome_record(
                    record_root=self.repo_root,
                    handoff=handoff,
                    status="conflict",
                    reasons=["child handoff requires conflict resolution before merge"],
                    integration_worktree_path=integration_path,
                    promoted_artifact_refs=[],
                    merge_commit=None,
                    requires_revalidation=handoff_validation.requires_revalidation,
                    recovery=None,
                )
            raise subprocess.CalledProcessError(
                merge_result.returncode,
                merge_result.args,
                output=merge_result.stdout,
                stderr=merge_result.stderr,
            )

        if path_validation.stripped_paths:
            self._strip_paths(integration_path, path_validation.stripped_paths)
            restored_artifacts = promote_child_scoped_artifacts(
                destination_root=integration_path,
                handoff=handoff,
                stripped_paths=path_validation.stripped_paths,
                load_artifact_bytes=lambda artifact_path: self._git_blob_bytes(
                    self.repo_root,
                    handoff.head_commit,
                    artifact_path,
                ),
            )
            for destination_path in restored_artifacts:
                self._run_git(
                    integration_path,
                    "add",
                    "--",
                    str(destination_path.relative_to(integration_path)),
                )

        promoted_artifact_refs = collect_promoted_artifact_refs(
            handoff=handoff,
            stripped_paths=path_validation.stripped_paths,
        )

        has_staged_changes = self._run_git_checked(
            integration_path,
            "diff",
            "--cached",
            "--quiet",
        ).returncode != 0

        merge_commit: str | None = None
        integration_updated = has_staged_changes
        branch_moved = False
        lease_updated = False
        checkout_updated = False
        requires_authoritative_root_shift = operator_dirty and has_staged_changes and not reusing_current_checkout
        event_root = self.repo_root
        record_root = self.repo_root

        if has_staged_changes:
            self._commit_squash_merge(
                integration_path,
                handoff=handoff,
                final_commit_message=_resolve_final_commit_message(assignment),
            )
            merge_commit = self._git_output(integration_path, "rev-parse", "HEAD")
            pre_branch_recovery = reconcile_partial_merge(
                integration_updated=True,
                branch_moved=False,
                lease_updated=False,
                checkout_updated=False,
                requires_authoritative_root_shift=operator_dirty and not reusing_current_checkout,
            )
            self._write_progress_record(
                record_root=self.repo_root,
                handoff=handoff,
                phase="integration_updated",
                merge_commit=merge_commit,
                recovery=pre_branch_recovery,
            )
            verification_runner = run_merge_verification
            if verification_runner is None:
                raise RuntimeError("merge-time verification runner is required")
            verification_passed = verification_runner(integration_path)
            if not verification_passed:
                recovery = reconcile_partial_merge(
                    integration_updated=True,
                    branch_moved=False,
                    lease_updated=False,
                    checkout_updated=False,
                    requires_authoritative_root_shift=operator_dirty and not reusing_current_checkout,
                )
                return self._write_outcome_record(
                    record_root=self.repo_root,
                    handoff=handoff,
                    status="blocked",
                    reasons=["merge-time verification failed"],
                    integration_worktree_path=integration_path,
                    promoted_artifact_refs=promoted_artifact_refs,
                    merge_commit=merge_commit,
                    requires_revalidation=handoff_validation.requires_revalidation,
                    recovery=recovery,
                )

            operator_branch = self._current_branch(self.repo_root)
            if not operator_dirty and operator_branch == self.target_branch:
                self._run_git(
                    self.repo_root,
                    "-c",
                    "commit.gpgsign=false",
                    "merge",
                    "--ff-only",
                    merge_commit,
                )
                branch_moved = True
                checkout_updated = True
            else:
                self._run_git(
                    self.repo_root,
                    "update-ref",
                    f"refs/heads/{self.target_branch}",
                    merge_commit,
                    base_commit,
                )
                branch_moved = True
                post_branch_recovery = reconcile_partial_merge(
                    integration_updated=True,
                    branch_moved=True,
                    lease_updated=False,
                    checkout_updated=False,
                    requires_authoritative_root_shift=operator_dirty and not reusing_current_checkout,
                )
                self._write_progress_record(
                    record_root=self.repo_root,
                    handoff=handoff,
                    phase="branch_moved",
                    merge_commit=merge_commit,
                    recovery=post_branch_recovery,
                )
                if operator_dirty:
                    if reusing_current_checkout:
                        checkout_updated = True
                    else:
                        self._sync_runtime_state_to_integration_root(integration_path)
                        shifted_root = self._worktrees.switch_authoritative_root(
                            run_id=self.run_id,
                            new_root=integration_path,
                        )
                        lease_updated = True
                        event_root = shifted_root
                        record_root = shifted_root
                        post_shift_recovery = reconcile_partial_merge(
                            integration_updated=True,
                            branch_moved=True,
                            lease_updated=True,
                            checkout_updated=False,
                            requires_authoritative_root_shift=True,
                        )
                        self._write_progress_record(
                            record_root=record_root,
                            handoff=handoff,
                            phase="lease_shifted",
                            merge_commit=merge_commit,
                            recovery=post_shift_recovery,
                        )

            self._emit_artifact_promotion_events(
                event_root,
                handoff.child_run_id,
                promoted_artifact_refs,
            )
        else:
            merge_commit = base_commit
            branch_moved = False

        self._event_store(event_root).append(
            event_id=f"merge.completed-{uuid.uuid4().hex}",
            run_id=self.run_id,
            stage_id=self.stage_id,
            task_id=None,
            event_type="merge.completed",
            source="git.merge",
            payload={
                "child_run_id": handoff.child_run_id,
                "target_branch": self.target_branch,
                "merge_commit": merge_commit,
            },
        )

        recovery = reconcile_partial_merge(
            integration_updated=integration_updated,
            branch_moved=branch_moved,
            lease_updated=lease_updated,
            checkout_updated=checkout_updated,
            requires_authoritative_root_shift=requires_authoritative_root_shift,
        )
        return self._write_outcome_record(
            record_root=record_root,
            handoff=handoff,
            status="merged",
            reasons=[],
            integration_worktree_path=integration_path,
            promoted_artifact_refs=promoted_artifact_refs,
            merge_commit=merge_commit,
            requires_revalidation=handoff_validation.requires_revalidation,
            recovery=recovery,
        )

    def _emit_artifact_promotion_events(
        self,
        event_root: Path,
        child_run_id: str,
        promoted_artifact_refs: Sequence[ArtifactRef],
    ) -> None:
        events = self._event_store(event_root)
        for artifact_ref in promoted_artifact_refs:
            events.append(
                event_id=f"artifact.promoted-{uuid.uuid4().hex}",
                run_id=self.run_id,
                stage_id=self.stage_id,
                task_id=None,
                event_type="artifact.promoted",
                source="git.merge",
                payload={
                    "artifact_path": artifact_ref.artifact_path,
                    "artifact_kind": artifact_ref.artifact_kind,
                    "producing_run_id": child_run_id,
                    "target_branch": self.target_branch,
                },
            )

    def _commit_squash_merge(
        self,
        integration_path: Path,
        *,
        handoff: WorktreeHandoff,
        final_commit_message: str,
    ) -> None:
        author_name, author_email = resolve_git_commit_identity(integration_path)
        self._run_git(
            integration_path,
            "-c",
            "commit.gpgsign=false",
            "-c",
            f"user.name={author_name}",
            "-c",
            f"user.email={author_email}",
            "commit",
            "-m",
            final_commit_message,
        )

    def _cleanup_conflicted_integration(self, integration_path: Path) -> None:
        self._run_git_checked(integration_path, "merge", "--abort")
        self._run_git(
            integration_path,
            "restore",
            "--source=HEAD",
            "--staged",
            "--worktree",
            "--",
            ".",
        )

    def _child_diff_paths(self, handoff: WorktreeHandoff) -> list[str]:
        merge_base = self._git_output(
            self.repo_root,
            "merge-base",
            self.target_branch,
            handoff.head_commit,
        )
        diff_output = self._git_output(
            self.repo_root,
            "diff",
            "--name-status",
            "--find-renames",
            merge_base,
            handoff.head_commit,
        )
        paths: list[str] = []
        for line in diff_output.splitlines():
            paths.extend(_extract_diff_paths(line))
        return sorted(dict.fromkeys(paths))

    def _latest_consumable_bundle(self) -> ExecutionBundle:
        bundles_dir = self.repo_root / ".ralphception" / "runs" / self.run_id / "bundles"
        if not bundles_dir.exists():
            raise RuntimeError(f"no bundles found for run {self.run_id}")
        consumable_bundles: list[ExecutionBundle] = []
        for bundle_path in sorted(bundles_dir.glob("*.json")):
            payload = json.loads(bundle_path.read_text(encoding="utf-8"))
            bundle = ExecutionBundle.model_validate(payload)
            if is_bundle_consumable(bundle):
                consumable_bundles.append(bundle)
        if not consumable_bundles:
            raise RuntimeError(f"no consumable bundles found for run {self.run_id}")
        return max(consumable_bundles, key=lambda bundle: bundle.bundle_version)

    def _event_offsets(self) -> dict[str, int]:
        store = self._event_store(self.repo_root)
        events_dir = self.repo_root / ".ralphception" / "events"
        if not events_dir.exists():
            return {}
        return {
            event_path.stem: len(store.read_run(event_path.stem))
            for event_path in sorted(events_dir.glob("*.jsonl"))
        }

    def _next_checkpoint_id(self) -> str:
        checkpoints_dir = self.repo_root / ".ralphception" / "runs" / self.run_id / "checkpoints"
        next_index = 1
        if checkpoints_dir.exists():
            for checkpoint_path in checkpoints_dir.glob("checkpoint-*.json"):
                try:
                    next_index = max(
                        next_index,
                        int(checkpoint_path.stem.removeprefix("checkpoint-")) + 1,
                    )
                except ValueError:
                    continue
        return f"checkpoint-{next_index}"

    def _read_child_assignment(self, child_run_id: str) -> ChildAssignment:
        path = self.repo_root / ".ralphception" / "runs" / child_run_id / "assignment.json"
        return ChildAssignment.model_validate(json.loads(path.read_text(encoding="utf-8")))

    def _read_merge_context(self, child_run_id: str) -> MergeEligibilityContext:
        path = self.repo_root / ".ralphception" / "runs" / child_run_id / "merge_context.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        return MergeEligibilityContext(
            latest_goal=str(payload["latest_goal"]),
            changed_dependency_paths=[str(path) for path in payload.get("changed_dependency_paths", [])],
            acceptance_criteria_changed=bool(payload.get("acceptance_criteria_changed", False)),
            changed_touched_paths=[str(path) for path in payload.get("changed_touched_paths", [])],
        )

    def _ensure_merge_context(
        self,
        *,
        child_run_id: str,
        assignment: ChildAssignment,
        latest_goal: str,
        changed_dependency_paths: Sequence[str] | None,
        acceptance_criteria_changed: bool,
        changed_touched_paths: Sequence[str] | None,
        computed_changed_dependency_paths: Sequence[str],
        changed_acceptance_paths: Sequence[str],
    ) -> MergeEligibilityContext:
        path = self.repo_root / ".ralphception" / "runs" / child_run_id / "merge_context.json"
        if path.exists():
            return self._read_merge_context(child_run_id)
        context = MergeEligibilityContext(
            latest_goal=latest_goal or assignment.goal,
            changed_dependency_paths=sorted(
                {
                    *computed_changed_dependency_paths,
                    *(changed_dependency_paths or []),
                },
            ),
            acceptance_criteria_changed=acceptance_criteria_changed or bool(changed_acceptance_paths),
            changed_touched_paths=sorted(
                {
                    *(changed_touched_paths or []),
                    *computed_changed_dependency_paths,
                    *changed_acceptance_paths,
                },
            ),
        )
        path.parent.mkdir(parents=True, exist_ok=True)
        write_json_atomic(
            path,
            {
                "latest_goal": context.latest_goal,
                "changed_dependency_paths": context.changed_dependency_paths,
                "acceptance_criteria_changed": context.acceptance_criteria_changed,
                "changed_touched_paths": context.changed_touched_paths,
            },
        )
        return context

    def _changed_artifact_paths(
        self,
        baseline_refs: Sequence[ArtifactRef],
        latest_refs: Sequence[ArtifactRef],
    ) -> list[str]:
        if not baseline_refs:
            return []
        latest_by_key = {
            (artifact_ref.artifact_path, artifact_ref.artifact_kind): artifact_ref
            for artifact_ref in latest_refs
        }
        changed_paths: set[str] = set()
        for baseline_ref in baseline_refs:
            latest_ref = latest_by_key.get((baseline_ref.artifact_path, baseline_ref.artifact_kind))
            if latest_ref is None:
                changed_paths.add(baseline_ref.artifact_path)
                continue
            if (
                latest_ref.content_hash != baseline_ref.content_hash
                or latest_ref.artifact_version != baseline_ref.artifact_version
            ):
                changed_paths.add(baseline_ref.artifact_path)
        return sorted(changed_paths)

    def _sync_runtime_state_to_integration_root(self, integration_path: Path) -> None:
        source_root = self.repo_root / ".ralphception"
        destination_root = integration_path / ".ralphception"
        for source_path in source_root.rglob("*"):
            relative_path = source_path.relative_to(source_root)
            destination_path = destination_root / relative_path
            if source_path.is_dir():
                destination_path.mkdir(parents=True, exist_ok=True)
                continue
            destination_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_path, destination_path)

    def _active_worktrees(self, handoff: WorktreeHandoff) -> list[str]:
        active_paths = {str(self.repo_root), handoff.worktree_path}
        worktrees_root = self.repo_root / ".worktrees"
        if worktrees_root.exists():
            active_paths.update(
                str(candidate)
                for candidate in worktrees_root.iterdir()
                if candidate.is_dir()
            )
        return sorted(active_paths)

    def _write_dirty_workspace_checkpoint(
        self,
        *,
        handoff: WorktreeHandoff,
        bundle_version: int,
    ) -> None:
        write_checkpoint(
            self.repo_root,
            checkpoint_id=self._next_checkpoint_id(),
            run_id=self.run_id,
            checkpoint_kind="safe_point",
            event_offsets=self._event_offsets(),
            bundle_version=bundle_version,
            authoritative_root=str(self.repo_root),
            active_worktrees=self._active_worktrees(handoff),
        )

    def _event_store(self, repo_root: Path) -> EventStore:
        return EventStore(repo_root)

    def _strip_paths(self, integration_path: Path, paths: Sequence[str]) -> None:
        tracked_paths = [path for path in paths if self._path_exists_in_head(integration_path, path)]
        if tracked_paths:
            self._run_git(
                integration_path,
                "restore",
                "--source=HEAD",
                "--staged",
                "--worktree",
                "--",
                *tracked_paths,
            )
        for path in paths:
            if path in tracked_paths:
                continue
            self._run_git(
                integration_path,
                "rm",
                "-r",
                "--cached",
                "--ignore-unmatch",
                "--",
                path,
            )
            absolute_path = integration_path / path
            if absolute_path.is_dir():
                shutil.rmtree(absolute_path, ignore_errors=True)
            elif absolute_path.exists() or absolute_path.is_symlink():
                absolute_path.unlink(missing_ok=True)

    def _is_dirty_checkout(self, checkout_path: Path, *, include_ralphception: bool = False) -> bool:
        result = self._run_git_checked(checkout_path, "status", "--porcelain=v1", "--untracked-files=all")
        for line in result.stdout.splitlines():
            candidate_paths = _extract_status_paths(line)
            if any(
                _is_merge_dirty_path(path, include_ralphception=include_ralphception)
                for path in candidate_paths
            ):
                return True
        return False

    def _current_branch(self, checkout_path: Path) -> str:
        return self._git_output(checkout_path, "rev-parse", "--abbrev-ref", "HEAD")

    def _path_exists_in_head(self, checkout_path: Path, path: str) -> bool:
        result = self._run_git_checked(
            checkout_path,
            "ls-tree",
            "-r",
            "--name-only",
            "HEAD",
            "--",
            path,
        )
        return bool(result.stdout.strip())

    def _write_outcome_record(
        self,
        *,
        record_root: Path,
        handoff: WorktreeHandoff,
        status: MergeStatus,
        reasons: list[str],
        integration_worktree_path: Path,
        promoted_artifact_refs: list[ArtifactRef],
        merge_commit: str | None,
        requires_revalidation: bool,
        recovery: PartialMergeRecoveryOutcome | None,
    ) -> MergeOutcome:
        record_root = bootstrap_workspace(record_root)
        record_path = record_root / ".ralphception" / "merge" / f"{self.stage_id}-{handoff.child_run_id}.json"
        payload = {
            "run_id": self.run_id,
            "stage_id": self.stage_id,
            "target_branch": self.target_branch,
            "child_run_id": handoff.child_run_id,
            "status": status,
            "reasons": reasons,
            "merge_commit": merge_commit,
            "integration_worktree_path": str(integration_worktree_path),
            "requires_revalidation": requires_revalidation,
            "promoted_artifact_refs": [
                artifact_ref.model_dump(mode="json") for artifact_ref in promoted_artifact_refs
            ],
            "recovery": asdict(recovery) if recovery is not None else None,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        write_json_atomic(record_path, payload)
        return MergeOutcome(
            status=status,
            reasons=reasons,
            merge_record_path=record_path,
            integration_worktree_path=integration_worktree_path,
            promoted_artifact_refs=promoted_artifact_refs,
            merge_commit=merge_commit,
            requires_revalidation=requires_revalidation,
            recovery=recovery,
        )

    def _write_progress_record(
        self,
        *,
        record_root: Path,
        handoff: WorktreeHandoff,
        phase: str,
        merge_commit: str,
        recovery: PartialMergeRecoveryOutcome,
    ) -> Path:
        record_root = bootstrap_workspace(record_root)
        record_path = record_root / ".ralphception" / "merge" / f"{self.stage_id}-{handoff.child_run_id}.json"
        payload = {
            "run_id": self.run_id,
            "stage_id": self.stage_id,
            "target_branch": self.target_branch,
            "child_run_id": handoff.child_run_id,
            "status": "in_progress",
            "phase": phase,
            "merge_commit": merge_commit,
            "recovery": asdict(recovery),
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        write_json_atomic(record_path, payload)
        return record_path

    def _run_git(self, cwd: Path, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", *args],
            check=True,
            cwd=cwd,
            capture_output=True,
            text=True,
        )

    def _run_git_checked(self, cwd: Path, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", *args],
            check=False,
            cwd=cwd,
            capture_output=True,
            text=True,
        )

    def _git_output(self, cwd: Path, *args: str) -> str:
        return self._run_git(cwd, *args).stdout.strip()

    def _git_blob_bytes(self, cwd: Path, revision: str, relative_path: str) -> bytes:
        result = subprocess.run(
            ["git", "show", f"{revision}:{relative_path}"],
            check=True,
            cwd=cwd,
            capture_output=True,
        )
        return result.stdout


def validate_handoff(
    *,
    repo_root: Path,
    handoff: WorktreeHandoff,
    latest_bundle: ExecutionBundle,
    latest_goal: str,
    dependency_refs: Sequence[ArtifactRef],
    newest_required_verification_passed: bool,
    changed_dependency_paths: Sequence[str] | None = None,
    acceptance_criteria_changed: bool = False,
    changed_touched_paths: Sequence[str] | None = None,
) -> HandoffValidationResult:
    del repo_root
    if not is_bundle_consumable(latest_bundle):
        return HandoffValidationResult(
            status="blocked",
            reasons=["latest bundle is not consumable"],
        )
    if handoff.merge_readiness != "ready":
        return HandoffValidationResult(
            status="blocked",
            reasons=[f"handoff is not merge-ready: {handoff.merge_readiness}"],
        )

    if handoff.consumed_bundle_version > latest_bundle.bundle_version:
        return HandoffValidationResult(
            status="blocked",
            reasons=["handoff consumed a bundle newer than the latest consumable bundle"],
        )

    requires_revalidation = handoff.consumed_bundle_version < latest_bundle.bundle_version
    if not requires_revalidation:
        return HandoffValidationResult(status="ready", reasons=[])

    stale_reasons: list[str] = []
    if handoff.goal != latest_goal:
        stale_reasons.append("newer execution bundle materially changed the child goal")

    if acceptance_criteria_changed:
        stale_reasons.append("newer execution bundle materially changed the child acceptance criteria")

    if _touch_scope_changed(
        handoff.touched_paths,
        changed_touched_paths,
    ):
        stale_reasons.append("newer execution bundle materially changed the child touched artifact set")

    if changed_dependency_paths:
        stale_reasons.append(
            "newer execution bundle materially changed dependent artifacts: "
            + ", ".join(sorted(dict.fromkeys(changed_dependency_paths))),
        )
    elif not _dependency_snapshot_matches_latest(latest_bundle.artifact_refs, dependency_refs):
        stale_reasons.append("newer execution bundle materially changed dependent artifacts")

    if stale_reasons:
        return HandoffValidationResult(
            status="stale",
            reasons=stale_reasons,
            requires_revalidation=False,
        )

    if not newest_required_verification_passed:
        return HandoffValidationResult(
            status="blocked",
            reasons=["newest required merge verification has not passed"],
            requires_revalidation=True,
        )

    return HandoffValidationResult(
        status="ready",
        reasons=["newer execution bundle requires revalidation against the newest verification"],
        requires_revalidation=True,
    )


def validate_handoff_paths(handoff: WorktreeHandoff) -> HandoffPathValidationResult:
    return _validate_candidate_paths(
        handoff.child_run_id,
        [
            *handoff.touched_paths,
            *(artifact_ref.artifact_path for artifact_ref in handoff.artifact_refs),
            *(artifact_ref.artifact_path for artifact_ref in handoff.verification_artifact_refs),
        ],
    )


def reconcile_partial_merge(
    *,
    integration_updated: bool,
    branch_moved: bool,
    lease_updated: bool,
    checkout_updated: bool,
    requires_authoritative_root_shift: bool,
) -> PartialMergeRecoveryOutcome:
    requires_lease_fix = branch_moved and requires_authoritative_root_shift and not lease_updated
    requires_checkout_fix = branch_moved and not requires_authoritative_root_shift and not checkout_updated
    if not integration_updated:
        resume_action: ResumeAction = "retry_merge"
    elif not branch_moved:
        resume_action = "complete_or_rollback_integration"
    elif requires_lease_fix:
        resume_action = "reconcile_branch_and_lease"
    elif requires_checkout_fix:
        resume_action = "reconcile_branch_and_checkout"
    else:
        resume_action = "merge_consistent"
    return PartialMergeRecoveryOutcome(
        integration_updated=integration_updated,
        branch_moved=branch_moved,
        lease_updated=lease_updated,
        checkout_updated=checkout_updated,
        requires_authoritative_root_shift=requires_authoritative_root_shift,
        requires_lease_fix=requires_lease_fix,
        requires_checkout_fix=requires_checkout_fix,
        resume_action=resume_action,
    )


def _dependency_snapshot_matches_latest(
    latest_artifact_refs: Sequence[ArtifactRef],
    dependency_refs: Sequence[ArtifactRef],
) -> bool:
    if not dependency_refs:
        return True

    latest_by_path = {(artifact_ref.artifact_path, artifact_ref.artifact_kind): artifact_ref for artifact_ref in latest_artifact_refs}
    for dependency_ref in dependency_refs:
        latest_ref = latest_by_path.get((dependency_ref.artifact_path, dependency_ref.artifact_kind))
        if latest_ref is None:
            return False
        if (
            latest_ref.content_hash != dependency_ref.content_hash
            or latest_ref.artifact_version != dependency_ref.artifact_version
        ):
            return False
    return True


def _is_merge_conflict(result: subprocess.CompletedProcess[str]) -> bool:
    combined_output = "\n".join(part for part in [result.stdout, result.stderr] if part)
    return "CONFLICT" in combined_output or "Automatic merge failed" in combined_output


def _touch_scope_changed(
    handoff_touched_paths: Sequence[str],
    changed_touched_paths: Sequence[str] | None,
) -> bool:
    if not changed_touched_paths:
        return False
    changed_paths = {_normalize_repo_path(path) for path in changed_touched_paths}
    handoff_paths = {_normalize_repo_path(path) for path in handoff_touched_paths}
    if not handoff_paths:
        return bool(changed_paths)
    return not handoff_paths.isdisjoint(changed_paths)


def _validate_candidate_paths(
    child_run_id: str,
    candidate_paths: Sequence[str],
) -> HandoffPathValidationResult:
    normalized_paths = {_normalize_repo_path(path) for path in candidate_paths}
    forbidden_paths = sorted(
        path
        for path in normalized_paths
        if is_ralphception_path(path) and not is_child_scoped_ralphception_path(path, child_run_id)
    )
    stripped_paths = sorted(
        path for path in normalized_paths if is_child_scoped_ralphception_path(path, child_run_id)
    )

    if forbidden_paths:
        return HandoffPathValidationResult(
            status="blocked",
            reasons=["merge blocked by forbidden shared .ralphception edits"],
            forbidden_paths=forbidden_paths,
            stripped_paths=stripped_paths,
        )
    return HandoffPathValidationResult(
        status="ready",
        reasons=[],
        forbidden_paths=[],
        stripped_paths=stripped_paths,
    )


def _combine_path_validations(
    *validations: HandoffPathValidationResult,
) -> HandoffPathValidationResult:
    forbidden_paths = sorted(
        {
            path
            for validation in validations
            for path in validation.forbidden_paths
        },
    )
    stripped_paths = sorted(
        {
            path
            for validation in validations
            for path in validation.stripped_paths
        },
    )
    if forbidden_paths:
        return HandoffPathValidationResult(
            status="blocked",
            reasons=["merge blocked by forbidden shared .ralphception edits"],
            forbidden_paths=forbidden_paths,
            stripped_paths=stripped_paths,
        )
    return HandoffPathValidationResult(
        status="ready",
        reasons=[],
        forbidden_paths=[],
        stripped_paths=stripped_paths,
    )


def _extract_diff_paths(line: str) -> list[str]:
    if not line:
        return []
    parts = line.split("\t")
    if len(parts) < 2:
        return []
    status = parts[0]
    if status.startswith(("R", "C")) and len(parts) >= 3:
        return [_normalize_repo_path(parts[1]), _normalize_repo_path(parts[2])]
    return [_normalize_repo_path(parts[1])]


def _normalize_repo_path(path: str) -> str:
    normalized = path.replace("\\", "/").strip()
    while normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized.strip("/")


def _is_managed_internal_path(path: str) -> bool:
    return is_ralphception_path(path) or path == ".worktrees" or path.startswith(".worktrees/")


def _is_merge_dirty_path(path: str, *, include_ralphception: bool) -> bool:
    if path == ".worktrees" or path.startswith(".worktrees/"):
        return False
    if include_ralphception and (path == ".ralphception" or path.startswith(".ralphception/")):
        return True
    return not _is_managed_internal_path(path)


def _extract_status_paths(line: str) -> list[str]:
    if len(line) < 4:
        return []
    path_section = line[3:]
    if " -> " in path_section:
        before, after = path_section.split(" -> ", 1)
        return [_normalize_repo_path(before), _normalize_repo_path(after)]
    return [_normalize_repo_path(path_section)]


def normalize_final_commit_message(message: str) -> str:
    normalized = " ".join(message.strip().split())
    if not normalized:
        raise ValueError("final commit message must not be blank")
    return normalized


def _resolve_final_commit_message(assignment: ChildAssignment) -> str:
    if assignment.final_commit_message is not None:
        return normalize_final_commit_message(assignment.final_commit_message)
    return normalize_final_commit_message(f"chore: {assignment.goal.rstrip('.')}")


__all__ = [
    "HandoffPathValidationResult",
    "HandoffValidationResult",
    "MergeCoordinator",
    "MergeOutcome",
    "PartialMergeRecoveryOutcome",
    "normalize_final_commit_message",
    "reconcile_partial_merge",
    "validate_handoff",
    "validate_handoff_paths",
]
