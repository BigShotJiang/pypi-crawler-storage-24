"""Git helpers for runtime worktree orchestration."""

from .identity import GitIdentityError, resolve_git_commit_identity
from .merge import (
    HandoffPathValidationResult,
    HandoffValidationResult,
    MergeCoordinator,
    MergeOutcome,
    PartialMergeRecoveryOutcome,
    reconcile_partial_merge,
    validate_handoff,
    validate_handoff_paths,
)
from .worktrees import (
    CleanupFailed,
    CheckoutRootInvalid,
    CreatedChildWorktree,
    CreatedIntegrationWorktree,
    IntegrationRootUnavailable,
    WorktreeMappingUnavailable,
    RunWorktreeMapping,
    WorktreeAssignment,
    WorktreeCoordinator,
    WorktreeCoordinatorError,
    WorktreeCreateFailed,
    read_worktree_assignment,
)

__all__ = [
    "CleanupFailed",
    "CheckoutRootInvalid",
    "CreatedChildWorktree",
    "CreatedIntegrationWorktree",
    "GitIdentityError",
    "HandoffPathValidationResult",
    "HandoffValidationResult",
    "IntegrationRootUnavailable",
    "MergeCoordinator",
    "MergeOutcome",
    "PartialMergeRecoveryOutcome",
    "WorktreeMappingUnavailable",
    "RunWorktreeMapping",
    "WorktreeAssignment",
    "WorktreeCoordinator",
    "WorktreeCoordinatorError",
    "WorktreeCreateFailed",
    "resolve_git_commit_identity",
    "reconcile_partial_merge",
    "read_worktree_assignment",
    "validate_handoff",
    "validate_handoff_paths",
]
