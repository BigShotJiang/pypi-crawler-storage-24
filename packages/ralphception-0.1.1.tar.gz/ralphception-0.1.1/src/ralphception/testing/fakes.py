"""Fake Codex client and session-manager builders for integration tests."""

from __future__ import annotations

from collections import deque
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path
import re

from ralphception.config import CodexConfig, DEFAULT_CONFIG, RalphceptionConfig
from ralphception.codex.client import (
    CodexClientProtocol,
    CodexModelUnavailableError,
    CodexProtocolError,
    CodexSessionExpiredError,
    CodexStartupFailedError,
    CodexThreadSession,
    CodexTransportError,
    CodexTurnRef,
    RawCodexEvent,
    normalize_notification,
)
from ralphception.codex.session_manager import CodexSessionManager

FakeStartupFailure = CodexStartupFailedError
FakeExpiredSession = CodexSessionExpiredError
FakeTransportError = CodexTransportError
FakeProtocolError = CodexProtocolError
FakeModelUnavailableError = CodexModelUnavailableError
TurnHandler = Callable[[CodexThreadSession, str, int], None]

_CONTRACT_RE = re.compile(
    r"HEADLESS_CONTRACT_START\s*(?P<json>\{.*?\})\s*HEADLESS_CONTRACT_END",
    re.DOTALL,
)


@dataclass(frozen=True, slots=True)
class FakeNotification:
    method: str
    payload: dict[str, object]


@dataclass(slots=True)
class FakeCodexClient(CodexClientProtocol):
    available_models: tuple[str, ...] = ("gpt-5.4",)
    workspace_path: str = "/repo"
    started: bool = False
    initialized: bool = False
    closed: bool = False
    resumed_thread_ids: list[str] = field(default_factory=list)
    interruptions: list[tuple[str, str]] = field(default_factory=list)
    thread_counter: int = 0
    turn_counter: int = 0
    notifications: deque[FakeNotification] = field(default_factory=deque)
    turn_handler: TurnHandler | None = None
    _sessions_by_thread_id: dict[str, CodexThreadSession] = field(default_factory=dict)

    def start(self) -> None:
        self.started = True
        self.closed = False

    def initialize(self) -> None:
        if not self.started:
            raise FakeStartupFailure("client must be started before initialize")
        self.initialized = True

    def close(self) -> None:
        self.closed = True
        self.started = False
        self.initialized = False

    def thread_start(
        self,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession:
        self.thread_counter += 1
        session = CodexThreadSession(
            thread_id=f"thread-{self.thread_counter}",
            session_id=f"session-{self.thread_counter}",
            workspace_path=cwd or self.workspace_path,
            model=config.model,
            approval_policy=config.approval_policy,
            sandbox=config.sandbox,
        )
        self._sessions_by_thread_id[session.thread_id] = session
        return session

    def thread_resume(
        self,
        thread_id: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession:
        session = self._sessions_by_thread_id.get(thread_id)
        if session is None:
            raise FakeExpiredSession(f"thread {thread_id!r} is no longer available")
        self.resumed_thread_ids.append(thread_id)
        if cwd is None or cwd == session.workspace_path:
            return session
        updated = CodexThreadSession(
            thread_id=session.thread_id,
            session_id=session.session_id,
            workspace_path=cwd,
            model=config.model,
            approval_policy=config.approval_policy,
            sandbox=config.sandbox,
        )
        self._sessions_by_thread_id[thread_id] = updated
        return updated

    def thread_fork(
        self,
        thread_id: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession:
        if thread_id not in self._sessions_by_thread_id:
            raise FakeExpiredSession(f"thread {thread_id!r} is no longer available")
        return self.thread_start(cwd=cwd, config=config)

    def turn_start(
        self,
        thread_id: str,
        input_text: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexTurnRef:
        if thread_id not in self._sessions_by_thread_id:
            raise FakeExpiredSession(f"thread {thread_id!r} is no longer available")
        self.turn_counter += 1
        turn_id = f"turn-{self.turn_counter}"
        session = self._sessions_by_thread_id[thread_id]
        self.notifications.append(
            FakeNotification(
                method="turn/started",
                payload={
                    "threadId": thread_id,
                    "turn": {
                        "id": turn_id,
                        "status": "running",
                    },
                },
            ),
        )
        if self.turn_handler is not None:
            try:
                self.turn_handler(session, input_text, self.turn_counter)
            except Exception as exc:
                self.notifications.append(
                    FakeNotification(
                        method="error",
                        payload={
                            "threadId": thread_id,
                            "turn": {
                                "id": turn_id,
                                "status": "failed",
                            },
                            "error": {
                                "message": str(exc),
                            },
                        },
                    ),
                )
                return CodexTurnRef(thread_id=thread_id, turn_id=turn_id)
        self.notifications.append(
            FakeNotification(
                method="turn/completed",
                payload={
                    "threadId": thread_id,
                    "turn": {
                        "id": turn_id,
                        "status": "completed",
                    },
                },
            ),
        )
        return CodexTurnRef(thread_id=thread_id, turn_id=turn_id)

    def turn_interrupt(self, thread_id: str, turn_id: str) -> None:
        self.interruptions.append((thread_id, turn_id))

    def next_notification(self) -> RawCodexEvent:
        if not self.notifications:
            raise FakeTransportError("notification queue is empty")
        notification = self.notifications.popleft()
        return normalize_notification(notification.method, notification.payload)

    def stream_until_methods(self, methods: Iterable[str] | str) -> list[RawCodexEvent]:
        target_methods = {methods} if isinstance(methods, str) else set(methods)
        events: list[RawCodexEvent] = []
        while True:
            event = self.next_notification()
            events.append(event)
            if event.method in target_methods:
                return events

    def model_list(self) -> tuple[str, ...]:
        return self.available_models


def build_fake_session_manager(
    *,
    available_models: tuple[str, ...] = ("gpt-5.4",),
    workspace_path: str = "/repo",
    config: RalphceptionConfig = DEFAULT_CONFIG,
    turn_handler: TurnHandler | None = None,
) -> CodexSessionManager:
    fake_client = FakeCodexClient(
        available_models=available_models,
        workspace_path=workspace_path,
        turn_handler=turn_handler,
    )
    return CodexSessionManager(
        workspace_path=workspace_path,
        config=config,
        client=fake_client,
        clock=_fixed_utc_now,
    )


def build_fake_headless_session_manager(
    *,
    available_models: tuple[str, ...] = ("gpt-5.4",),
    workspace_path: str = "/repo",
    config: RalphceptionConfig = DEFAULT_CONFIG,
) -> CodexSessionManager:
    writer = FakeHeadlessTurnWriter()
    return build_fake_session_manager(
        available_models=available_models,
        workspace_path=workspace_path,
        config=config,
        turn_handler=writer.handle_turn,
    )


@dataclass(slots=True)
class FakeHeadlessTurnWriter:
    audit_turns: int = 0

    def handle_turn(self, session: CodexThreadSession, input_text: str, turn_counter: int) -> None:
        del turn_counter
        contract = _extract_contract(input_text)
        if contract is None:
            return
        stage = str(contract["stage"])
        workspace = Path(session.workspace_path)
        if stage == "spec":
            output_path = workspace / str(contract["output_path"])
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(
                "# Mission Spec\n\n"
                "- Goal: Port parser.\n"
                "- Acceptance: produce a tracked implementation artifact and pass verification.\n",
                encoding="utf-8",
            )
            return
        if stage == "plan":
            plan_path = workspace / str(contract["plan_path"])
            plan_path.parent.mkdir(parents=True, exist_ok=True)
            plan_path.write_text(
                "# Mission Plan\n\n"
                "1. Implement the parser artifact.\n"
                "2. Run verification.\n"
                "3. Merge and audit.\n",
                encoding="utf-8",
            )
            contract_path = workspace / str(contract["plan_contract_path"])
            contract_path.parent.mkdir(parents=True, exist_ok=True)
            contract_path.write_text(
                json.dumps(
                    {
                        "execution_goal": "Implement the parser artifact.",
                        "verification_commands": ['python -c "print(\'headless verification\')"'],
                    },
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
                encoding="utf-8",
            )
            return
        if stage == "execute":
            run_id = str(contract["run_id"])
            handoff_path = workspace / str(contract["handoff_path"])
            handoff_path.parent.mkdir(parents=True, exist_ok=True)
            source_path = workspace / "src" / "parser.py"
            source_path.parent.mkdir(parents=True, exist_ok=True)
            touched_paths = ["src/parser.py"]
            summary = "Implemented parser artifact."
            if "-replacement-" in run_id:
                tests_path = workspace / "tests" / "test_parser.py"
                tests_path.parent.mkdir(parents=True, exist_ok=True)
                tests_path.write_text("def test_parser_placeholder():\n    assert True\n", encoding="utf-8")
                source_path.write_text("VALUE = 2\n", encoding="utf-8")
                touched_paths.append("tests/test_parser.py")
                summary = "Resolved audit gap by adding parser coverage."
            else:
                source_path.write_text("VALUE = 1\n", encoding="utf-8")
            handoff_path.write_text(
                json.dumps(
                    {
                        "summary": summary,
                        "artifacts": [{"path": "src/parser.py", "kind": "code"}],
                        "touched_paths": touched_paths,
                        "merge_readiness": "ready",
                    },
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
                encoding="utf-8",
            )
            return
        if stage == "audit":
            audit_path = workspace / str(contract["audit_path"])
            audit_path.parent.mkdir(parents=True, exist_ok=True)
            if self.audit_turns == 0:
                payload = {
                    "findings": [
                        {
                            "finding_id": "audit-gap-1",
                            "severity": "P1",
                            "kind": "test_gap",
                            "title": "Parser change needs regression coverage.",
                            "status": "open",
                            "evidence_paths": [],
                        }
                    ]
                }
            else:
                payload = {"findings": []}
            self.audit_turns += 1
            audit_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _extract_contract(input_text: str) -> dict[str, object] | None:
    match = _CONTRACT_RE.search(input_text)
    if match is None:
        return None
    return json.loads(match.group("json"))


def _fixed_utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
