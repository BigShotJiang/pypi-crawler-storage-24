"""CLI entry point for Ralphception."""

from pathlib import Path
from typing import Annotated, Literal

import typer

import ralphception.app as runtime_app
from ralphception.runtime.supervisor import (
    RuntimeBackendUnavailableError,
    RuntimeLaunchAbortedError,
    RuntimePromptConflictError,
    RuntimeResumeRequiredError,
    RuntimeResumeUnavailableError,
)
from ralphception.workflow.recovery import ResumeResult

app = typer.Typer(help="Ralphception core runtime CLI.")


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """Start the Ralphception application."""

    if ctx.invoked_subcommand is None:
        runtime_app.run_app()


@app.command()
def resume(
    mode: Annotated[Literal["read", "repair"], typer.Argument()] = "read",
) -> None:
    """Resume the current workspace's root run."""
    result = runtime_app.resume_app(mode=mode)
    typer.echo(_render_resume_result(result))


@app.command()
def terminal(
    repo_root: Annotated[Path | None, typer.Option("--repo-root")] = None,
    seed_prompt: Annotated[str | None, typer.Option("--seed-prompt")] = None,
    source_repos: Annotated[list[str] | None, typer.Option("--source-repo")] = None,
    resume: Annotated[bool, typer.Option("--resume")] = False,
    approve_all: Annotated[bool, typer.Option("--approve-all")] = False,
    approver: Annotated[str, typer.Option("--approver")] = "terminal",
    fake_session_manager: Annotated[bool, typer.Option("--fake-session-manager")] = False,
) -> None:
    """Run the shared terminal frontend."""
    try:
        result = runtime_app.run_terminal(
            repo_root=repo_root,
            seed_prompt=seed_prompt,
            source_repos=tuple(source_repos or ()),
            resume=resume,
            approve_all=approve_all,
            approver=approver,
            use_fake_session_manager=fake_session_manager,
        )
    except (
        RuntimeBackendUnavailableError,
        RuntimeLaunchAbortedError,
        RuntimePromptConflictError,
        RuntimeResumeRequiredError,
        RuntimeResumeUnavailableError,
    ) as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1) from exc
    typer.echo(runtime_app._render_terminal_result(result))


@app.command()
def headless(
    repo_root: Annotated[Path | None, typer.Option("--repo-root")] = None,
    seed_prompt: Annotated[str | None, typer.Option("--seed-prompt")] = None,
    source_repos: Annotated[list[str] | None, typer.Option("--source-repo")] = None,
    approve_all: Annotated[bool, typer.Option("--approve-all")] = False,
    approver: Annotated[str, typer.Option("--approver")] = "headless",
    fake_session_manager: Annotated[bool, typer.Option("--fake-session-manager")] = False,
) -> None:
    """Run the headless mission supervisor without opening the Textual UI."""
    try:
        result = runtime_app.run_headless(
            repo_root=repo_root,
            seed_prompt=seed_prompt,
            source_repos=tuple(source_repos or ()),
            approve_all=approve_all,
            approver=approver,
            use_fake_session_manager=fake_session_manager,
        )
    except (RuntimeBackendUnavailableError, RuntimeLaunchAbortedError, RuntimePromptConflictError) as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1) from exc
    typer.echo(runtime_app._render_headless_result(result))


def _render_resume_result(result: ResumeResult) -> str:
    message = f"Resumed {result.run_id} in {result.mode} mode."
    if result.recommended_action is not None:
        message = f"{message} Next action: /{result.recommended_action}."
    return message
