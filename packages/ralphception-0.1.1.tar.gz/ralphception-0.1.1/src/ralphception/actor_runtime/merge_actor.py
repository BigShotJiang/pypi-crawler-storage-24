"""Merge-agent candidate selection for commit intents."""

from __future__ import annotations

from pathlib import Path

from pydantic import Field, field_validator

from ralphception.git.merge import normalize_final_commit_message
from ralphception.models.artifacts import DurableModel
from ralphception.models.commit_intents import CommitIntent
from ralphception.storage.commit_intents import update_commit_intent_winner


class WorkerCandidate(DurableModel):
    candidate_id: str
    commit_intent_id: str
    summary: str
    touched_paths: list[str] = Field(default_factory=list)
    verification_passed: bool = True

    @field_validator("candidate_id", "commit_intent_id", "summary")
    @classmethod
    def _validate_non_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("worker candidate fields must not be blank")
        return value


class MergeDecision(DurableModel):
    intent_id: str
    selected_candidate_id: str
    rejected_candidate_ids: list[str]
    commit_message: str
    rationale: str

    @field_validator("intent_id", "selected_candidate_id", "commit_message", "rationale")
    @classmethod
    def _validate_non_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("merge decision fields must not be blank")
        return value


class MergeAgent:
    """Select the strongest candidate for a commit intent and record the result."""

    def __init__(self, *, repo_root: Path | None = None) -> None:
        self.repo_root = repo_root

    def choose_candidate(self, intent: CommitIntent, candidates: list[WorkerCandidate]) -> MergeDecision:
        matching = [candidate for candidate in candidates if candidate.commit_intent_id == intent.intent_id]
        if not matching:
            raise ValueError(f"no candidates matched commit intent {intent.intent_id!r}")

        ordered = sorted(
            matching,
            key=lambda candidate: (
                candidate.verification_passed,
                len(candidate.touched_paths),
                candidate.candidate_id,
            ),
        )
        selected = ordered[-1]
        rejected = [candidate.candidate_id for candidate in ordered[:-1]]
        rationale = (
            f"selected {selected.candidate_id} for {intent.intent_id} based on verification state "
            f"and touched-path coverage"
        )
        return MergeDecision(
            intent_id=intent.intent_id,
            selected_candidate_id=selected.candidate_id,
            rejected_candidate_ids=rejected,
            commit_message=normalize_final_commit_message(intent.message),
            rationale=rationale,
        )

    def record_decision(self, intent: CommitIntent, decision: MergeDecision) -> CommitIntent:
        if self.repo_root is None:
            raise RuntimeError("repo_root is required to record merge decisions")
        return update_commit_intent_winner(
            self.repo_root,
            intent_id=intent.intent_id,
            candidate_id=decision.selected_candidate_id,
        )

    def land_intent(self, decision: MergeDecision) -> str:
        return normalize_final_commit_message(decision.commit_message)
