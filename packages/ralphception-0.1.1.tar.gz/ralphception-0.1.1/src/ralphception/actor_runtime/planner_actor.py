"""Planner actor for durable plan outputs."""

from __future__ import annotations

from pathlib import Path

from ralphception.headless import _load_plan_contract, _preferred_artifact_path
from ralphception.models.mission import PlannerOutput
from ralphception.storage.mission_store import MissionStore


class PlannerActor:
    """Persist todo and commit-intent outputs derived from the approved plan contract."""

    def __init__(self, *, repo_root: Path, store: MissionStore | None = None) -> None:
        self.repo_root = repo_root
        self.store = store or MissionStore(repo_root)

    def plan(self, *, approved_spec_path: Path) -> PlannerOutput:
        if not approved_spec_path.exists():
            fallback_spec_path = _preferred_artifact_path(
                approved_spec_path.parent,
                preferred_name=approved_spec_path.name,
            )
            if not fallback_spec_path.exists():
                raise FileNotFoundError(f"approved spec is missing: {approved_spec_path}")
            approved_spec_path = fallback_spec_path

        plans_dir = self.repo_root / ".ralphception" / "plans"
        plan_markdown_path = _preferred_artifact_path(plans_dir, preferred_name="mission-plan.md")
        plan_json_path = plans_dir / "mission-plan.json"
        contract = _load_plan_contract(
            plan_json_path,
            default_goal=f"Implement {approved_spec_path.stem}.",
        )

        self.store.write_todos(contract.todos)
        self.store.write_commit_intents(contract.commit_intents)
        output = PlannerOutput(
            plan_markdown_path=str(plan_markdown_path.relative_to(self.repo_root)),
            plan_json_path=str(plan_json_path.relative_to(self.repo_root)),
            todo_ids=[todo.todo_id for todo in contract.todos],
            commit_intent_ids=[intent.intent_id for intent in contract.commit_intents],
            execution_policy=contract.execution_policy,
        )
        self.store.write_planner_output(output)
        return output
