"""Scheduler batching logic for ready todo execution."""

from __future__ import annotations

from collections import defaultdict

from ralphception.actor_runtime.worker_actor import WorkerAssignment
from ralphception.models.mission import ExecutionPolicy
from ralphception.models.todos import TodoNode


class SchedulerActor:
    """Plans worker assignments for ready todo batches."""

    def __init__(self, *, max_parallel_children: int) -> None:
        self.max_parallel_children = max_parallel_children

    @classmethod
    def from_execution_policy(cls, policy: ExecutionPolicy) -> "SchedulerActor":
        return cls(max_parallel_children=policy.max_parallel_children)

    def plan_assignments(
        self,
        *,
        todos: list[TodoNode],
        active_workers: list[WorkerAssignment],
    ) -> list[WorkerAssignment]:
        available_slots = max(0, self.max_parallel_children - len(active_workers))
        if available_slots == 0:
            return []

        claimed_todo_ids = {todo_id for worker in active_workers for todo_id in worker.todo_ids}
        ready_todos = [
            todo
            for todo in todos
            if todo.status == "ready" and todo.todo_id not in claimed_todo_ids
        ]
        grouped: dict[tuple[str, str], list[TodoNode]] = defaultdict(list)
        for todo in ready_todos:
            grouped[(todo.commit_intent_id, _scope_group(todo.scope_hints))].append(todo)

        assignments: list[WorkerAssignment] = []
        worker_index = len(active_workers) + 1
        for key in sorted(grouped):
            if len(assignments) >= available_slots:
                break
            batch = sorted(grouped[key], key=lambda todo: todo.todo_id)
            assignments.append(
                WorkerAssignment(
                    worker_id=f"worker-{worker_index}",
                    run_id=f"run-worker-{worker_index}",
                    goal="; ".join(todo.title for todo in batch),
                    todo_ids=[todo.todo_id for todo in batch],
                    claimed_commit_intent_ids=sorted({todo.commit_intent_id for todo in batch}),
                )
            )
            worker_index += 1
        return assignments


def _scope_group(scope_hints: list[str]) -> str:
    if not scope_hints:
        return ""
    first_hint = scope_hints[0].strip().replace("\\", "/")
    return first_hint.split("/", 1)[0] if first_hint else ""
