"""Actor-runtime orchestrator for intake and spec approval."""

from __future__ import annotations

from pathlib import Path

from ralphception.actor_runtime.intake_actor import IntakeActor
from ralphception.headless import HeadlessMissionSupervisor, HeadlessRunResult
from ralphception.runtime.frontends import FrontendEvent, RuntimeFrontend


class ActorOrchestrator:
    """Shared orchestrator fronting the legacy downstream executor."""

    def __init__(
        self,
        *,
        repo_root: Path,
        primary_repo_root: Path,
        seed_prompt: str | None,
        source_repos: tuple[str, ...],
        approve_all: bool,
        approver: str,
        session_manager_factory,
    ) -> None:
        self.repo_root = repo_root
        self.primary_repo_root = primary_repo_root
        self.seed_prompt = seed_prompt
        self.source_repos = source_repos
        self.approve_all = approve_all
        self.approver = approver
        self.session_manager_factory = session_manager_factory
        self.intake_actor = IntakeActor(repo_root)
        self.actions: list[str] = []

    def run_until_blocked(self, *, frontend: RuntimeFrontend | None = None) -> HeadlessRunResult:
        session = self.intake_actor.load_session()
        if session is None:
            self._emit(frontend, "Socratic intake")
            if self.seed_prompt is None or not self.seed_prompt.strip():
                if frontend is None:
                    return HeadlessRunResult(
                        mode="startup",
                        actions=(),
                        authoritative_repo_root=str(self.repo_root),
                    )
                decision = frontend.prompt_startup(self.intake_actor.next_prompt(None))
                self.seed_prompt = decision.seed_prompt
                self.source_repos = decision.source_repos
            session = self.intake_actor.apply_answer(
                seed_prompt=self.seed_prompt or "",
                source_repos=self.source_repos,
            )
            self._emit(frontend, f"Bootstrapped {session.mission_id}")
        elif session.phase in {"intake", "spec_review"}:
            self._emit(frontend, "Socratic intake")

        if session.phase in {"intake", "spec_review"}:
            review_result = self._run_spec_gate(frontend=frontend)
            if review_result is not None:
                return self._with_accumulated_actions(review_result)
            announce_resume = False
        else:
            announce_resume = True

        downstream = self._build_downstream_supervisor(
            approve_all=True,
            announce_resume=announce_resume,
        )
        return self._with_accumulated_actions(downstream.run(frontend=frontend))

    def _run_spec_gate(self, *, frontend: RuntimeFrontend | None) -> HeadlessRunResult | None:
        supervisor = self._build_downstream_supervisor(approve_all=self.approve_all)
        supervisor._frontend = frontend
        supervisor._announce_stage("spec")
        review_result = supervisor._run_spec_stage(frontend=frontend)
        self.actions.extend(supervisor.actions)
        if review_result is not None:
            self.intake_actor.mark_ready_for_spec_review()
            return review_result
        self.intake_actor.approve_spec(artifact_version=1)
        self._emit(frontend, "Spec approved. Proceeding autonomously.")
        return None

    def _build_downstream_supervisor(
        self,
        *,
        approve_all: bool,
        announce_resume: bool = True,
    ) -> HeadlessMissionSupervisor:
        return HeadlessMissionSupervisor(
            repo_root=self.repo_root,
            primary_repo_root=self.primary_repo_root,
            seed_prompt=self.seed_prompt,
            source_repos=self.source_repos,
            approve_all=approve_all,
            approver=self.approver,
            session_manager_factory=self.session_manager_factory,
            announce_resume=announce_resume,
        )

    def _emit(self, frontend: RuntimeFrontend | None, message: str) -> None:
        if frontend is None:
            return
        frontend.emit_event(FrontendEvent(message=message))

    def _with_accumulated_actions(self, result: HeadlessRunResult) -> HeadlessRunResult:
        if not self.actions:
            return result
        return result.model_copy(update={"actions": (*self.actions, *result.actions)})
