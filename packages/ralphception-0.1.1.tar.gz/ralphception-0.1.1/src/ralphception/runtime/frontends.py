"""Shared runtime frontend contracts and prompt models."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Protocol

from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import ResumeMode

ReviewKind = Literal["spec_review", "execution_bundle", "recovery"]
ConflictAction = Literal["resume", "override", "abort"]
RuntimeStepKind = Literal["startup_prompt", "review_prompt", "conflict_prompt", "dashboard", "completed", "failed"]


@dataclass(frozen=True, slots=True)
class FrontendEvent:
    message: str
    level: Literal["info", "warning", "error"] = "info"
    run_id: str | None = None
    stage_kind: str | None = None


@dataclass(frozen=True, slots=True)
class StartupPrompt:
    repo_root: Path
    message: str = "Seed prompt required to bootstrap this workspace."


@dataclass(frozen=True, slots=True)
class ReviewPrompt:
    review_kind: ReviewKind
    run_id: str
    summary_text: str
    recommended_actions: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class MissionConflictPrompt:
    repo_root: Path
    run_id: str
    existing_seed_prompt: str
    requested_seed_prompt: str | None = None
    run_status: str | None = None
    current_stage: str | None = None

    @property
    def message(self) -> str:
        details: list[str] = []
        if self.run_status is not None:
            details.append(f"status={self.run_status}")
        if self.current_stage is not None:
            details.append(f"stage={self.current_stage}")
        suffix = f" ({', '.join(details)})" if details else ""
        return (
            f"Workspace {self.repo_root} already has mission {self.run_id}{suffix} "
            f"for seed prompt {self.existing_seed_prompt!r}. Use --resume to attach to it instead. "
            "Starting a new mission will clear the current Ralphception runtime state."
        )


@dataclass(frozen=True, slots=True)
class StartupDecision:
    seed_prompt: str
    source_repos: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ReviewDecision:
    action: Literal["approve", "resume", "retry", "restart", "replace", "abort", "pause"]
    approver: str | None = None
    resume_mode: ResumeMode = "read"


@dataclass(frozen=True, slots=True)
class MissionConflictDecision:
    action: ConflictAction


@dataclass(frozen=True, slots=True)
class RuntimeStep:
    kind: RuntimeStepKind
    startup_prompt: StartupPrompt | None = None
    review_prompt: ReviewPrompt | None = None
    conflict_prompt: MissionConflictPrompt | None = None
    engine: WorkflowEngine | None = None


class RuntimeFrontend(Protocol):
    def emit_event(self, event: FrontendEvent) -> None: ...

    def emit_status(self, step: RuntimeStep) -> None: ...

    def prompt_startup(self, prompt: StartupPrompt) -> StartupDecision: ...

    def prompt_review(self, prompt: ReviewPrompt) -> ReviewDecision: ...

    def prompt_conflict(self, prompt: MissionConflictPrompt) -> MissionConflictDecision: ...

    def finish(self, step: RuntimeStep) -> None: ...


def format_review_actions(actions: Sequence[str]) -> tuple[str, ...]:
    return tuple(actions)


__all__ = [
    "ConflictAction",
    "FrontendEvent",
    "MissionConflictDecision",
    "MissionConflictPrompt",
    "ReviewDecision",
    "ReviewKind",
    "ReviewPrompt",
    "RuntimeFrontend",
    "RuntimeStep",
    "StartupDecision",
    "StartupPrompt",
]
