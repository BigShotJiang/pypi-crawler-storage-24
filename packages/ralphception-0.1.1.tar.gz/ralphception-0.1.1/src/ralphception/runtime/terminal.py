"""Traditional terminal frontend over the shared runtime supervisor."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, cast

from ralphception.config import RalphceptionConfig
from ralphception.runtime.frontends import (
    FrontendEvent,
    MissionConflictDecision,
    MissionConflictPrompt,
    ReviewDecision,
    ReviewPrompt,
    RuntimeStep,
    StartupDecision,
    StartupPrompt,
)
from ralphception.runtime.supervisor import RuntimeResumeUnavailableError, RuntimeSupervisor


@dataclass(frozen=True, slots=True)
class TerminalRunResult:
    mode: Literal["running", "completed", "failed"]
    root_run_id: str | None = None
    authoritative_repo_root: str | None = None
    log_text: str = ""


@dataclass(slots=True)
class TerminalFrontend:
    """Simple log-and-prompt terminal surface."""

    input_func: Callable[[str], str] = input
    write_func: Callable[[str], None] = print
    _output_lines: list[str] = field(default_factory=list)

    def emit_event(self, event: FrontendEvent) -> None:
        self._write(event.message)

    def emit_status(self, step: RuntimeStep) -> None:
        self._write(f"Runtime: {step.kind}")

    def prompt_startup(self, prompt: StartupPrompt) -> StartupDecision:
        self._write(prompt.message)
        seed_prompt = self.input_func("Seed prompt: ").strip()
        source_repo_input = self.input_func("Source repos (comma separated, optional): ").strip()
        source_repos = tuple(
            candidate.strip()
            for candidate in source_repo_input.split(",")
            if candidate.strip()
        )
        return StartupDecision(seed_prompt=seed_prompt, source_repos=source_repos)

    def prompt_review(self, prompt: ReviewPrompt) -> ReviewDecision:
        self._write(prompt.summary_text)
        response = self.input_func("Review action: ").strip() or "approve"
        normalized_action = _normalize_review_action(response)
        return ReviewDecision(action=normalized_action, approver="terminal")

    def prompt_conflict(self, prompt: MissionConflictPrompt) -> MissionConflictDecision:
        self._write(prompt.message)
        response = self.input_func("Mission action [start/abort]: ").strip() or "abort"
        return MissionConflictDecision(action=_normalize_conflict_action(response))

    def finish(self, step: RuntimeStep) -> None:
        self._write(f"Finished: {step.kind}")

    def output_text(self) -> str:
        return "\n".join(self._output_lines)

    def _write(self, text: str) -> None:
        self._output_lines.append(text)
        self.write_func(text)


@dataclass(slots=True)
class ScriptedTerminalFrontend(TerminalFrontend):
    """Deterministic terminal frontend for integration tests."""

    scripted_inputs: list[str] = field(default_factory=list)

    def __init__(self, *, inputs: Sequence[str] = ()) -> None:
        self.scripted_inputs = list(inputs)
        TerminalFrontend.__init__(self, input_func=self._consume_input, write_func=lambda text: None)

    def _consume_input(self, prompt: str) -> str:
        self._output_lines.append(prompt)
        if not self.scripted_inputs:
            raise RuntimeError(f"no scripted input available for prompt {prompt!r}")
        return self.scripted_inputs.pop(0)


def run_terminal(
    *,
    repo_root: Path | None = None,
    seed_prompt: str | None = None,
    source_repos: tuple[str, ...] = (),
    resume: bool = False,
    approve_all: bool = False,
    approver: str = "terminal",
    use_fake_session_manager: bool = False,
    session_manager_factory=None,
    frontend: TerminalFrontend | None = None,
) -> TerminalRunResult:
    resolved_repo_root = Path.cwd() if repo_root is None else repo_root
    resolved_frontend = frontend or TerminalFrontend()
    resolved_session_manager_factory = _resolve_terminal_session_manager_factory(
        session_manager_factory=session_manager_factory,
        use_fake_session_manager=use_fake_session_manager,
    )
    supervisor = RuntimeSupervisor(
        repo_root=resolved_repo_root,
        seed_prompt=seed_prompt,
        source_repos=source_repos,
        approve_all=approve_all,
        approver=approver,
        session_manager_factory=resolved_session_manager_factory,
    )
    if resume:
        while True:
            step = supervisor.step()
            if step.kind == "startup_prompt":
                raise RuntimeResumeUnavailableError(repo_root=supervisor.repo_root)
            if step.kind == "review_prompt":
                decision = resolved_frontend.prompt_review(cast(ReviewPrompt, step.review_prompt))
                if decision.action == "pause":
                    root_run_id = (
                        step.engine.root_run.run_id
                        if step.engine is not None
                        else cast(ReviewPrompt, step.review_prompt).run_id
                    )
                    resolved_frontend.emit_status(RuntimeStep(kind="review_prompt"))
                    return TerminalRunResult(
                        mode="running",
                        root_run_id=root_run_id,
                        authoritative_repo_root=str(supervisor.repo_root),
                        log_text=resolved_frontend.output_text(),
                    )
                supervisor.apply_review_decision(decision, engine=step.engine)
                continue
            if step.kind == "dashboard":
                break
            raise RuntimeError(f"unsupported terminal resume step: {step.kind}")
    else:
        supervisor.ensure_new_launch_allowed(frontend=resolved_frontend)
    result = supervisor.run(frontend=resolved_frontend)
    resolved_frontend.emit_status(RuntimeStep(kind=result.mode))
    return TerminalRunResult(
        mode="completed" if result.mode == "completed" else ("failed" if result.mode == "failed" else "running"),
        root_run_id=result.root_run_id,
        authoritative_repo_root=result.authoritative_repo_root,
        log_text=resolved_frontend.output_text(),
    )


def _resolve_terminal_session_manager_factory(
    *,
    session_manager_factory,
    use_fake_session_manager: bool,
):
    if session_manager_factory is not None:
        return session_manager_factory
    if not use_fake_session_manager:
        return None

    from ralphception.testing.fakes import build_fake_headless_session_manager

    def _factory(repo_root: Path, config: RalphceptionConfig) -> object:
        return build_fake_headless_session_manager(workspace_path=str(repo_root), config=config)

    return _factory


def _normalize_review_action(
    raw_value: str,
) -> Literal["approve", "resume", "retry", "restart", "replace", "abort", "pause"]:
    normalized = raw_value.strip().lower()
    allowed = {"approve", "resume", "retry", "restart", "replace", "abort", "pause"}
    if normalized in allowed:
        return cast(Literal["approve", "resume", "retry", "restart", "replace", "abort", "pause"], normalized)
    return "approve"


def _normalize_conflict_action(raw_value: str) -> Literal["resume", "override", "abort"]:
    normalized = raw_value.strip().lower()
    if normalized in {"start", "new", "override"}:
        return "override"
    if normalized == "abort":
        return "abort"
    return "abort"
