"""Shared runtime mode resolution and orchestration entrypoints."""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, cast

from ralphception.codex.client import codex_cli_available
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.config import DEFAULT_CONFIG, RalphceptionConfig, load_config, write_config_atomically
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ApprovalRecord, ExecutionBundle, Run, RunStageStatus, Stage
from ralphception.paths import config_path
from ralphception.runtime.frontends import FrontendEvent, MissionConflictPrompt, ReviewDecision, ReviewPrompt, RuntimeStep, StartupPrompt
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.files import write_json_atomic
from ralphception.ui.screens.review import ArtifactReviewController
from ralphception.ui.screens.startup import StartupBootstrapController, load_startup_record
from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import RecoveryService, ResumeResult

_RUNTIME_STAGE_ORDER = (
    ("intake", "completed"),
    ("spec", "completed"),
    ("plan", "pending"),
    ("execute", "pending"),
    ("merge", "pending"),
    ("audit", "pending"),
)


class RuntimePromptConflictError(RuntimeError):
    """Raised when a requested seed prompt conflicts with an existing root mission."""

    def __init__(
        self,
        *,
        repo_root: Path,
        existing_seed_prompt: str,
        requested_seed_prompt: str,
        run_id: str = "run-root",
        run_status: str | None = None,
        current_stage: str | None = None,
    ) -> None:
        self.repo_root = repo_root
        self.existing_seed_prompt = existing_seed_prompt
        self.requested_seed_prompt = requested_seed_prompt
        self.run_id = run_id
        self.run_status = run_status
        self.current_stage = current_stage
        super().__init__(str(self))

    def __str__(self) -> str:
        details: list[str] = []
        if self.run_status is not None:
            details.append(f"status={self.run_status}")
        if self.current_stage is not None:
            details.append(f"stage={self.current_stage}")
        suffix = f" ({', '.join(details)})" if details else ""
        return (
            f"Workspace {self.repo_root} already has active root mission {self.run_id}{suffix} with seed prompt "
            f"{self.existing_seed_prompt!r}; refusing to ignore requested seed prompt "
            f"{self.requested_seed_prompt!r}. Resume without --seed-prompt or clear/reset "
            "the Ralphception workspace state before starting a new mission."
        )


class RuntimeLaunchAbortedError(RuntimeError):
    """Raised when the user aborts launch during conflict resolution."""


class RuntimeResumeRequiredError(RuntimeError):
    """Raised when a workspace already has a mission and the user did not opt into resume."""

    def __init__(
        self,
        *,
        repo_root: Path,
        run_id: str,
        seed_prompt: str,
        run_status: str | None = None,
        current_stage: str | None = None,
    ) -> None:
        self.repo_root = repo_root
        self.run_id = run_id
        self.seed_prompt = seed_prompt
        self.run_status = run_status
        self.current_stage = current_stage
        super().__init__(str(self))

    def __str__(self) -> str:
        details: list[str] = []
        if self.run_status is not None:
            details.append(f"status={self.run_status}")
        if self.current_stage is not None:
            details.append(f"stage={self.current_stage}")
        suffix = f" ({', '.join(details)})" if details else ""
        return (
            f"Workspace {self.repo_root} already has mission {self.run_id}{suffix} for seed prompt "
            f"{self.seed_prompt!r}. Use --resume to attach to it, or clear/reset the Ralphception "
            "workspace state before starting a new mission."
        )


class RuntimeResumeUnavailableError(RuntimeError):
    """Raised when resume was requested but there is no resumable mission in the workspace."""

    def __init__(self, *, repo_root: Path) -> None:
        self.repo_root = repo_root
        super().__init__(str(self))

    def __str__(self) -> str:
        return (
            f"Workspace {self.repo_root} has no existing mission to resume. "
            "Start a new mission with --seed-prompt instead."
        )


class RuntimeBackendUnavailableError(RuntimeError):
    """Raised when terminal execution is requested without any usable backend."""

    def __init__(self) -> None:
        super().__init__(
            "No Codex session backend is available for terminal execution. "
            "Install/configure the backend or use --fake-session-manager for deterministic local verification.",
        )


@dataclass(frozen=True, slots=True)
class ExistingRootMission:
    run_id: str
    seed_prompt: str
    run_status: str | None
    current_stage: str | None
    terminal_outcome: str | None

    @property
    def is_completed(self) -> bool:
        return self.terminal_outcome == "completed" or self.run_status == "completed"

    @property
    def is_failed(self) -> bool:
        return self.terminal_outcome == "failed" or self.run_status == "failed"

    @property
    def is_terminal(self) -> bool:
        return self.is_completed or self.is_failed


class RuntimeSupervisor:
    """Resolve the current shared runtime state for a workspace."""

    def __init__(
        self,
        *,
        repo_root: Path,
        seed_prompt: str | None = None,
        source_repos: tuple[str, ...] = (),
        approve_all: bool = False,
        approver: str = "terminal",
        session_manager_factory=None,
    ) -> None:
        self.primary_repo_root = bootstrap_workspace(repo_root)
        self.repo_root = _resolve_authoritative_repo_root(self.primary_repo_root)
        self.seed_prompt = seed_prompt
        self.source_repos = source_repos
        self.approve_all = approve_all
        self.approver = approver
        self._session_manager_factory = session_manager_factory
        self.config = _load_or_create_config(self.repo_root)

    def step(self) -> RuntimeStep:
        self._cleanup_terminal_residue(frontend=None)
        self._reconcile_failed_runtime_state()
        startup_controller = StartupBootstrapController(self.repo_root)
        if startup_controller.needs_bootstrap():
            return RuntimeStep(
                kind="startup_prompt",
                startup_prompt=StartupPrompt(repo_root=self.repo_root),
            )

        engine = self.build_engine()
        review_controller = self.build_review_controller(engine=engine)
        target = review_controller.current_target()
        if target is not None:
            return RuntimeStep(
                kind="review_prompt",
                review_prompt=ReviewPrompt(
                    review_kind=target.kind,
                    run_id=target.run_id,
                    summary_text=review_controller.summary_text(),
                    recommended_actions=review_controller.recovery_actions(target.run_id)
                    if target.kind == "recovery"
                    else ("approve",),
                ),
                engine=engine,
            )

        return RuntimeStep(kind="dashboard", engine=engine)

    def build_engine(self) -> WorkflowEngine:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            raise RuntimeError("workspace bootstrap state is missing")

        spec_artifacts = _discover_artifacts(self.repo_root / ".ralphception" / "specs", artifact_kind="spec")
        root_run_path = self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "run.json"
        if root_run_path.exists():
            root_run = Run.model_validate_json(root_run_path.read_text(encoding="utf-8"))
            if spec_artifacts and not any(ref.artifact_kind == "spec" for ref in root_run.artifact_refs):
                root_run = root_run.model_copy(update={"artifact_refs": [*root_run.artifact_refs, *spec_artifacts]})
        else:
            root_run = Run(
                run_id=startup_record.outer_run_id,
                parent_run_id=None,
                supersedes_run_id=None,
                goal=startup_record.seed_prompt,
                status="pending",
                stage_ids=[f"stage-{stage_kind}" for stage_kind, _ in _RUNTIME_STAGE_ORDER],
                config_snapshot={
                    "codex": {"model": self.config.codex.model},
                    "source_repos": startup_record.source_repos,
                },
                codex_session_ref=None,
                artifact_refs=spec_artifacts or [startup_record.intake_artifact],
                created_at=startup_record.created_at,
                updated_at=startup_record.created_at,
            )
        headless_state = _load_headless_state(self.repo_root, root_run.run_id)
        raw_completed_stages = headless_state.get("completed_stages", [])
        completed_stages = (
            set(cast(list[str], raw_completed_stages))
            if isinstance(raw_completed_stages, list)
            else set()
        )
        current_stage = headless_state.get("current_stage")
        stages = [
            Stage(
                stage_id=f"stage-{stage_kind}",
                run_id=root_run.run_id,
                stage_kind=stage_kind,
                status=resolved_status,
                task_ids=[],
                started_at=startup_record.created_at
                if resolved_status in {"completed", "running"}
                else None,
                completed_at=startup_record.created_at
                if resolved_status == "completed"
                else None,
            )
            for stage_kind, status in _RUNTIME_STAGE_ORDER
            for resolved_status in [
                _stage_status_for_kind(
                    stage_kind=stage_kind,
                    default_status=cast(RunStageStatus, status if stage_kind != "spec" or spec_artifacts else "pending"),
                    completed_stages=completed_stages,
                    current_stage=current_stage,
                )
            ]
        ]
        return WorkflowEngine(
            repo_root=self.repo_root,
            root_run=root_run,
            stages=stages,
            child_runs=_load_child_runs(self.repo_root, root_run.run_id),
            bundles=_load_bundles(self.repo_root, root_run.run_id),
            approvals=_load_approvals(self.repo_root),
            session_manager=_build_session_manager(
                self.repo_root,
                self.config,
                session_manager_factory=self._session_manager_factory,
            ),
        )

    def build_recovery_service(self, *, engine: WorkflowEngine | None = None) -> RecoveryService:
        return RecoveryService(
            engine=self.build_engine() if engine is None else engine,
            process_id=os.getpid(),
        )

    def build_review_controller(self, *, engine: WorkflowEngine | None = None) -> ArtifactReviewController:
        resolved_engine = self.build_engine() if engine is None else engine
        return ArtifactReviewController(
            repo_root=self.repo_root,
            engine=resolved_engine,
            recovery_service=self.build_recovery_service(engine=resolved_engine),
        )

    def apply_review_decision(
        self,
        decision: ReviewDecision,
        *,
        engine: WorkflowEngine | None = None,
    ) -> None:
        controller = self.build_review_controller(engine=engine)
        target = controller.current_target()
        if target is None:
            raise RuntimeError("no review target is pending")
        if decision.action == "pause":
            return

        if target.kind == "recovery":
            if decision.action not in {"resume", "retry", "restart", "replace"}:
                raise RuntimeError(f"unsupported recovery action: {decision.action}")
            outcome = controller.apply_recovery_action(
                target.run_id,
                cast(Literal["resume", "retry", "restart", "replace"], decision.action),
            )
            if isinstance(outcome, Run):
                self._sync_headless_state_after_recovery(run=outcome)
            elif isinstance(outcome, ResumeResult):
                self._clear_headless_terminal_outcome(run_id=outcome.run_id)
            return

        if decision.action != "approve":
            raise RuntimeError(f"unsupported review action for {target.kind}: {decision.action}")
        controller.approve_target(target, approver=decision.approver or "terminal")

    def run(self, *, frontend=None):
        self._cleanup_terminal_residue(frontend=frontend)
        session_manager = self._require_execution_backend()
        self._reconcile_requested_seed_prompt(frontend=frontend)
        from ralphception.actor_runtime.orchestrator import ActorOrchestrator

        mission = ActorOrchestrator(
            repo_root=self.repo_root,
            primary_repo_root=self.primary_repo_root,
            seed_prompt=self.seed_prompt,
            source_repos=self.source_repos,
            approve_all=self.approve_all,
            approver=self.approver,
            session_manager_factory=lambda repo_root, config: session_manager,
        )
        return mission.run_until_blocked(frontend=frontend)

    def ensure_new_launch_allowed(self, *, frontend=None) -> None:
        self._cleanup_terminal_residue(frontend=None)
        mission = self._load_existing_root_mission()
        if mission is None:
            return
        if frontend is None:
            raise RuntimeResumeRequiredError(
                repo_root=self.repo_root,
                run_id=mission.run_id,
                seed_prompt=mission.seed_prompt,
                run_status=mission.run_status,
                current_stage=mission.current_stage,
            )
        decision = frontend.prompt_conflict(
            MissionConflictPrompt(
                repo_root=self.repo_root,
                run_id=mission.run_id,
                existing_seed_prompt=mission.seed_prompt,
                run_status=mission.run_status,
                current_stage=mission.current_stage,
            ),
        )
        if decision.action == "override":
            from ralphception.headless import cleanup_mission_workspace

            cleanup_mission_workspace(
                repo_root=self.repo_root,
                primary_repo_root=self.primary_repo_root,
                root_run_id=mission.run_id,
            )
            self._reset_to_primary_repo_root()
            return
        raise RuntimeLaunchAbortedError("Launch aborted.")

    def ensure_resume_target_exists(self) -> ExistingRootMission:
        self._cleanup_terminal_residue(frontend=None)
        mission = self._load_existing_root_mission()
        if mission is None:
            raise RuntimeResumeUnavailableError(repo_root=self.repo_root)
        return mission

    def _require_execution_backend(self) -> object:
        session_manager = _build_session_manager(
            self.repo_root,
            self.config,
            session_manager_factory=self._session_manager_factory,
        )
        if session_manager is None:
            raise RuntimeBackendUnavailableError()
        return session_manager

    def _cleanup_terminal_residue(self, *, frontend) -> None:
        mission = self._load_existing_root_mission()
        if mission is None or not mission.is_completed:
            return
        from ralphception.headless import cleanup_mission_workspace

        cleanup_mission_workspace(
            repo_root=self.repo_root,
            primary_repo_root=self.primary_repo_root,
            root_run_id=mission.run_id,
        )
        self._reset_to_primary_repo_root()
        if frontend is not None:
            frontend.emit_event(FrontendEvent(message=f"Cleared completed runtime state for {mission.run_id}"))

    def _reconcile_failed_runtime_state(self) -> None:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            return

        state = _load_headless_state(self.repo_root, startup_record.outer_run_id)
        current_stage = state.get("current_stage")
        terminal_outcome = state.get("terminal_outcome")
        if current_stage != "failed" and terminal_outcome != "failed":
            return

        resume_stage = _infer_resume_stage(state)
        current_child_run_id = state.get("current_child_run_id")
        if resume_stage == "execute" and isinstance(current_child_run_id, str):
            child_run_path = self.repo_root / ".ralphception" / "runs" / current_child_run_id / "run.json"
            if child_run_path.exists():
                child_run = Run.model_validate_json(child_run_path.read_text(encoding="utf-8"))
                if child_run.status in {"pending", "running"}:
                    write_json_atomic(
                        child_run_path,
                        child_run.model_copy(update={"status": "failed"}).model_dump(mode="json"),
                    )

        root_run_path = self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "run.json"
        if root_run_path.exists():
            root_run = Run.model_validate_json(root_run_path.read_text(encoding="utf-8"))
            if root_run.status == "failed":
                write_json_atomic(
                    root_run_path,
                    root_run.model_copy(update={"status": "running"}).model_dump(mode="json"),
                )

        state["current_stage"] = resume_stage
        state["terminal_outcome"] = None
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "headless-state.json",
            state,
        )

    def _reconcile_requested_seed_prompt(self, *, frontend) -> None:
        if self.seed_prompt is None:
            return
        requested_seed_prompt = self.seed_prompt.strip()
        if not requested_seed_prompt:
            return
        mission = self._load_existing_root_mission()
        if mission is None:
            return
        if mission.seed_prompt.strip() == requested_seed_prompt:
            return
        if mission.is_completed:
            self._cleanup_terminal_residue(frontend=frontend)
            return
        if frontend is None:
            raise RuntimePromptConflictError(
                repo_root=self.repo_root,
                existing_seed_prompt=mission.seed_prompt,
                requested_seed_prompt=requested_seed_prompt,
                run_id=mission.run_id,
                run_status=mission.run_status,
                current_stage=mission.current_stage,
            )
        decision = frontend.prompt_conflict(
            MissionConflictPrompt(
                repo_root=self.repo_root,
                run_id=mission.run_id,
                existing_seed_prompt=mission.seed_prompt,
                requested_seed_prompt=requested_seed_prompt,
                run_status=mission.run_status,
                current_stage=mission.current_stage,
            ),
        )
        if decision.action == "resume":
            self.seed_prompt = mission.seed_prompt
            return
        if decision.action == "override":
            from ralphception.headless import cleanup_mission_workspace

            cleanup_mission_workspace(
                repo_root=self.repo_root,
                primary_repo_root=self.primary_repo_root,
                root_run_id=mission.run_id,
            )
            self._reset_to_primary_repo_root()
            return
        raise RuntimeLaunchAbortedError("Launch aborted.")

    def _load_existing_root_mission(self) -> ExistingRootMission | None:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            return None
        root_run_path = self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "run.json"
        run_status: str | None = None
        if root_run_path.exists():
            run_status = Run.model_validate_json(root_run_path.read_text(encoding="utf-8")).status
        headless_state = _load_headless_state(self.repo_root, startup_record.outer_run_id)
        terminal_outcome = headless_state.get("terminal_outcome")
        current_stage = headless_state.get("current_stage")
        return ExistingRootMission(
            run_id=startup_record.outer_run_id,
            seed_prompt=startup_record.seed_prompt.strip(),
            run_status=run_status,
            current_stage=current_stage if isinstance(current_stage, str) else None,
            terminal_outcome=terminal_outcome if isinstance(terminal_outcome, str) else None,
        )

    def _reset_to_primary_repo_root(self) -> None:
        self.repo_root = self.primary_repo_root
        self.config = _load_or_create_config(self.repo_root)

    def _sync_headless_state_after_recovery(self, *, run: Run) -> None:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            return
        state = _load_headless_state(self.repo_root, startup_record.outer_run_id)
        if not state:
            return
        child_run_ids = state.get("child_run_ids")
        normalized_child_run_ids = (
            [run_id for run_id in child_run_ids if isinstance(run_id, str)]
            if isinstance(child_run_ids, list)
            else []
        )
        if run.run_id not in normalized_child_run_ids:
            normalized_child_run_ids.append(run.run_id)
        state["child_run_ids"] = normalized_child_run_ids
        state["current_child_run_id"] = run.run_id
        state["current_stage"] = "execute"
        state["terminal_outcome"] = None
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "headless-state.json",
            state,
        )

    def _clear_headless_terminal_outcome(self, *, run_id: str) -> None:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            return
        state = _load_headless_state(self.repo_root, startup_record.outer_run_id)
        if not state:
            return
        state["current_stage"] = "execute"
        state["terminal_outcome"] = None
        state["current_child_run_id"] = run_id
        child_run_ids = state.get("child_run_ids")
        normalized_child_run_ids = (
            [child_run_id for child_run_id in child_run_ids if isinstance(child_run_id, str)]
            if isinstance(child_run_ids, list)
            else []
        )
        if run_id not in normalized_child_run_ids:
            normalized_child_run_ids.append(run_id)
        state["child_run_ids"] = normalized_child_run_ids
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "headless-state.json",
            state,
        )


def _build_session_manager(
    repo_root: Path,
    config: RalphceptionConfig,
    *,
    session_manager_factory,
) -> object:
    factory = session_manager_factory or _default_session_manager_factory
    return factory(repo_root, config)


def _default_session_manager_factory(repo_root: Path, config: RalphceptionConfig) -> object:
    if not codex_cli_available():
        return None
    return CodexSessionManager(workspace_path=str(repo_root), config=config)


def _load_bundles(repo_root: Path, run_id: str) -> list[ExecutionBundle]:
    bundle_dir = repo_root / ".ralphception" / "runs" / run_id / "bundles"
    if not bundle_dir.exists():
        return []
    return [
        ExecutionBundle.model_validate(json.loads(path.read_text(encoding="utf-8")))
        for path in sorted(bundle_dir.glob("*.json"))
    ]


def _load_child_runs(repo_root: Path, root_run_id: str) -> list[Run]:
    runs_dir = repo_root / ".ralphception" / "runs"
    if not runs_dir.exists():
        return []

    child_runs: list[Run] = []
    for path in sorted(runs_dir.glob("*/run.json")):
        run = Run.model_validate(json.loads(path.read_text(encoding="utf-8")))
        if run.run_id == root_run_id:
            continue
        child_runs.append(run)
    return child_runs


def _load_approvals(repo_root: Path) -> list[ApprovalRecord]:
    approval_dir = repo_root / ".ralphception" / "approvals"
    if not approval_dir.exists():
        return []
    approvals: list[ApprovalRecord] = []
    for path in sorted(approval_dir.glob("*.json")):
        approvals.append(ApprovalRecord.model_validate(json.loads(path.read_text(encoding="utf-8"))))
    return approvals


def _discover_artifacts(directory: Path, *, artifact_kind: str) -> list[ArtifactRef]:
    if not directory.exists():
        return []
    artifact_refs: list[ArtifactRef] = []
    for index, path in enumerate(sorted(directory.glob("**/*")), start=1):
        if not path.is_file():
            continue
        content = path.read_text(encoding="utf-8")
        artifact_refs.append(
            ArtifactRef(
                artifact_kind=artifact_kind,
                artifact_path=str(path.relative_to(directory.parent.parent)),
                artifact_version=index,
                content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
            ),
        )
    return artifact_refs


def _load_or_create_config(repo_root: Path) -> RalphceptionConfig:
    cfg_path = config_path(repo_root)
    if not cfg_path.exists():
        write_config_atomically(cfg_path, DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    loaded = load_config(cfg_path)
    if loaded.config is None:
        write_config_atomically(cfg_path, DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    return loaded.config


def _resolve_authoritative_repo_root(repo_root: Path) -> Path:
    worktree_path = repo_root / ".ralphception" / "runs" / "run-root" / "worktree.json"
    if not worktree_path.exists():
        return repo_root
    payload = json.loads(worktree_path.read_text(encoding="utf-8"))
    candidate = payload.get("worktree_path")
    if payload.get("kind") != "integration" or not isinstance(candidate, str):
        return repo_root
    resolved = Path(candidate).resolve(strict=False)
    if not resolved.exists():
        return repo_root
    return bootstrap_workspace(resolved)


def _load_headless_state(repo_root: Path, run_id: str) -> dict[str, object]:
    path = repo_root / ".ralphception" / "runs" / run_id / "headless-state.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _infer_resume_stage(state: dict[str, object]) -> str:
    completed = state.get("completed_stages")
    completed_stages = (
        {stage_name for stage_name in completed if isinstance(stage_name, str)}
        if isinstance(completed, list)
        else set()
    )
    for stage_name in ("intake", "spec", "plan", "execute", "merge", "audit"):
        if stage_name not in completed_stages:
            return stage_name
    return "audit"


def _stage_status_for_kind(
    *,
    stage_kind: str,
    default_status: RunStageStatus,
    completed_stages: set[str],
    current_stage: object,
) -> RunStageStatus:
    if stage_kind in completed_stages:
        return "completed"
    if current_stage == stage_kind:
        return "running"
    return default_status


__all__ = ["RuntimeSupervisor"]
