"""Verification task construction, persistence, and event mirroring."""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import Task
from ralphception.models.verification import (
    VerificationCommandResult,
    VerificationResult,
    VerificationScope,
    VerificationSpec,
    VerificationStatus,
)
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic, write_text_atomic
from ralphception.workflow._identifiers import validate_storage_identifier

TIMEOUT_EXIT_CODE = 124


@dataclass(frozen=True, slots=True)
class VerificationTaskBundle:
    task: Task
    spec: VerificationSpec
    spec_ref: ArtifactRef
    result: VerificationResult
    result_ref: ArtifactRef


@dataclass(frozen=True, slots=True)
class PersistedVerificationResult:
    result: VerificationResult
    result_ref: ArtifactRef


class VerificationService:
    """Construct verification tasks and persist their durable records."""

    def __init__(self, repo_root: Path, *, event_store: EventStore | None = None) -> None:
        self.repo_root = bootstrap_workspace(repo_root)
        self._event_store = event_store or EventStore(self.repo_root)

    def create_task_bundle(
        self,
        *,
        verification_id: str,
        run_id: str,
        stage_id: str,
        task_id: str,
        requested_by: str,
        scope: VerificationScope,
        config_default_commands: Sequence[str] = (),
        plan_defined_commands: Sequence[str] = (),
        audit_stage_required_commands: Sequence[str] = (),
        merge_stage_required_commands: Sequence[str] = (),
        active_bundle_exact_commands: Sequence[str] | None = None,
        required: bool = True,
        success_criteria: str | None = None,
        created_at: datetime | None = None,
    ) -> VerificationTaskBundle:
        created_at = created_at or datetime.now(timezone.utc)
        commands = _resolve_commands(
            config_default_commands=config_default_commands,
            plan_defined_commands=plan_defined_commands,
            audit_stage_required_commands=audit_stage_required_commands,
            merge_stage_required_commands=merge_stage_required_commands,
            active_bundle_exact_commands=active_bundle_exact_commands,
        )
        spec = VerificationSpec(
            verification_id=verification_id,
            run_id=run_id,
            task_id=task_id,
            requested_by=requested_by,
            scope=scope,
            required=required,
            commands=commands,
            success_criteria=success_criteria or "All commands exit 0 before the configured timeout.",
            created_at=created_at,
        )
        spec_ref = self._write_model_artifact(
            path=self.spec_path(verification_id),
            artifact_kind="verification_spec",
            model=spec,
        )

        pending_result = VerificationResult(
            verification_id=verification_id,
            run_id=run_id,
            task_id=task_id,
            status="pending",
            command_results=[],
            started_at=None,
            completed_at=None,
        )
        result_ref = self._write_model_artifact(
            path=self.result_path(verification_id),
            artifact_kind="verification_result",
            model=pending_result,
        )

        task = Task(
            task_id=task_id,
            run_id=run_id,
            stage_id=stage_id,
            task_kind="verification",
            status="queued",
            owner="workflow_engine",
            input_refs=[spec_ref],
            output_refs=[result_ref],
            started_at=None,
            completed_at=None,
        )

        return VerificationTaskBundle(
            task=task,
            spec=spec,
            spec_ref=spec_ref,
            result=pending_result,
            result_ref=result_ref,
        )

    def select_execution_context(
        self,
        *,
        scope: VerificationScope,
        authoritative_root: Path,
        child_worktree: Path | None = None,
        integration_worktree: Path | None = None,
    ) -> Path:
        if scope in {"task", "child_run"}:
            if child_worktree is None:
                raise ValueError("child_worktree is required for task and child_run verification")
            return child_worktree
        if scope == "merge":
            if integration_worktree is None:
                raise ValueError("integration_worktree is required for merge verification")
            return integration_worktree
        return authoritative_root

    def shape_command_result(
        self,
        *,
        verification_id: str,
        command_index: int,
        command: str,
        cwd: Path,
        exit_code: int | None,
        duration_ms: int,
        stdout: str,
        stderr: str,
        timed_out: bool = False,
    ) -> VerificationCommandResult:
        stdout_ref = self._write_text_artifact(
            path=self.command_output_path(verification_id, command_index, stream="stdout"),
            artifact_kind="verification_stdout",
            content=stdout,
        )
        stderr_ref = self._write_text_artifact(
            path=self.command_output_path(verification_id, command_index, stream="stderr"),
            artifact_kind="verification_stderr",
            content=stderr,
        )
        final_exit_code = TIMEOUT_EXIT_CODE if timed_out else exit_code
        if timed_out:
            status = "errored"
        elif final_exit_code == 0:
            status = "passed"
        elif final_exit_code is None:
            raise ValueError("exit_code is required unless the command timed out")
        else:
            status = "failed"

        return VerificationCommandResult(
            command=command,
            cwd=str(cwd),
            exit_code=final_exit_code,
            status=status,
            duration_ms=duration_ms,
            stdout_ref=stdout_ref,
            stderr_ref=stderr_ref,
        )

    def persist_result(
        self,
        *,
        stage_id: str,
        spec: VerificationSpec,
        command_results: Sequence[VerificationCommandResult],
        started_at: datetime,
        completed_at: datetime,
        source: str = "verification_service",
    ) -> PersistedVerificationResult:
        result = VerificationResult(
            verification_id=spec.verification_id,
            run_id=spec.run_id,
            task_id=spec.task_id,
            status=_verification_status_for(command_results),
            command_results=list(command_results),
            started_at=started_at,
            completed_at=completed_at,
        )
        result_ref = self._write_model_artifact(
            path=self.result_path(spec.verification_id),
            artifact_kind="verification_result",
            model=result,
        )
        self._event_store.append(
            event_id=_new_event_id("verification", spec.verification_id),
            run_id=spec.run_id,
            stage_id=stage_id,
            task_id=spec.task_id,
            event_type="verification.completed",
            source=source,
            payload={
                "verification_id": spec.verification_id,
                "status": result.status,
                "result_ref": result_ref.artifact_path,
            },
            occurred_at=completed_at,
        )
        return PersistedVerificationResult(result=result, result_ref=result_ref)

    def spec_path(self, verification_id: str) -> Path:
        validated_verification_id = validate_storage_identifier(
            verification_id,
            field_name="verification_id",
        )
        return (
            self.repo_root
            / ".ralphception"
            / "verification"
            / f"{validated_verification_id}.spec.json"
        )

    def result_path(self, verification_id: str) -> Path:
        validated_verification_id = validate_storage_identifier(
            verification_id,
            field_name="verification_id",
        )
        return (
            self.repo_root
            / ".ralphception"
            / "verification"
            / f"{validated_verification_id}.result.json"
        )

    def command_output_path(self, verification_id: str, command_index: int, *, stream: str) -> Path:
        validated_verification_id = validate_storage_identifier(
            verification_id,
            field_name="verification_id",
        )
        return (
            self.repo_root
            / ".ralphception"
            / "verification"
            / validated_verification_id
            / f"command-{command_index:03d}.{stream}.log"
        )

    def _write_model_artifact(
        self,
        *,
        path: Path,
        artifact_kind: str,
        model: VerificationSpec | VerificationResult,
    ) -> ArtifactRef:
        payload = model.model_dump(mode="json")
        write_json_atomic(path, payload)
        content = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
        return ArtifactRef(
            artifact_kind=artifact_kind,
            artifact_path=str(path.relative_to(self.repo_root)),
            artifact_version=1,
            content_hash=_content_hash(content),
        )

    def _write_text_artifact(self, *, path: Path, artifact_kind: str, content: str) -> ArtifactRef:
        write_text_atomic(path, content)
        return ArtifactRef(
            artifact_kind=artifact_kind,
            artifact_path=str(path.relative_to(self.repo_root)),
            artifact_version=1,
            content_hash=_content_hash(content.encode("utf-8")),
        )


def _resolve_commands(
    *,
    config_default_commands: Sequence[str],
    plan_defined_commands: Sequence[str],
    audit_stage_required_commands: Sequence[str],
    merge_stage_required_commands: Sequence[str],
    active_bundle_exact_commands: Sequence[str] | None,
) -> list[str]:
    if active_bundle_exact_commands is not None:
        return _dedupe_commands(active_bundle_exact_commands)
    return _dedupe_commands(
        [
            *merge_stage_required_commands,
            *audit_stage_required_commands,
            *plan_defined_commands,
            *config_default_commands,
        ],
    )


def _dedupe_commands(commands: Sequence[str]) -> list[str]:
    resolved: list[str] = []
    seen: set[str] = set()
    for command in commands:
        normalized = command.strip()
        if not normalized or normalized in seen:
            continue
        resolved.append(normalized)
        seen.add(normalized)
    return resolved


def _verification_status_for(
    command_results: Sequence[VerificationCommandResult],
) -> VerificationStatus:
    statuses = {result.status for result in command_results}
    if "errored" in statuses:
        return "errored"
    if "failed" in statuses:
        return "failed"
    if statuses == {"passed"}:
        return "passed"
    if statuses & {"pending", "running"}:
        return "running"
    return "pending"


def _content_hash(content: bytes) -> str:
    return f"sha256:{hashlib.sha256(content).hexdigest()}"


def _new_event_id(prefix: str, identifier: str) -> str:
    return f"{prefix}-{identifier}-{uuid.uuid4().hex}"
