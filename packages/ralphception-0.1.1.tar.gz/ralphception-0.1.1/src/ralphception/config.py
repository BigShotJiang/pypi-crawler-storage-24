"""Config defaults, validation, and atomic persistence for Ralphception."""

from __future__ import annotations

import os
import tempfile
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from ralphception.paths import config_path

ALLOWED_SANDBOX_VALUES = frozenset(
    {"danger-full-access", "workspace-write", "read-only"},
)
ALLOWED_APPROVAL_POLICY_VALUES = frozenset(
    {"never", "on-request", "on-failure", "untrusted"},
)
STRING_ESCAPE_SEQUENCES = str.maketrans(
    {
        "\\": "\\\\",
        '"': '\\"',
        "\b": "\\b",
        "\t": "\\t",
        "\n": "\\n",
        "\f": "\\f",
        "\r": "\\r",
    },
)


@dataclass(frozen=True, slots=True)
class CodexConfig:
    model: str
    reasoning: str
    latency_profile: str
    sandbox: str
    approval_policy: str


@dataclass(frozen=True, slots=True)
class ExecutionConfig:
    use_worktrees_for_edit_runs: bool
    max_parallel_children: int
    audit_reopen_priorities: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class VerificationConfig:
    command_timeout_seconds: int


@dataclass(frozen=True, slots=True)
class UIConfig:
    show_event_timestamps: bool
    mouse: bool


@dataclass(frozen=True, slots=True)
class RalphceptionConfig:
    codex: CodexConfig
    execution: ExecutionConfig
    verification: VerificationConfig
    ui: UIConfig


@dataclass(frozen=True, slots=True)
class ConfigLoadResult:
    config: RalphceptionConfig | None
    diagnostic: str | None = None

    @property
    def is_error(self) -> bool:
        return self.config is None


class ConfigValidationError(ValueError):
    """Raised when a config file is syntactically valid TOML but invalid data."""


DEFAULT_CONFIG = RalphceptionConfig(
    codex=CodexConfig(
        model="gpt-5.4",
        reasoning="high",
        latency_profile="fast",
        sandbox="danger-full-access",
        approval_policy="never",
    ),
    execution=ExecutionConfig(
        use_worktrees_for_edit_runs=True,
        max_parallel_children=4,
        audit_reopen_priorities=("P0", "P1", "P2"),
    ),
    verification=VerificationConfig(command_timeout_seconds=1800),
    ui=UIConfig(show_event_timestamps=True, mouse=True),
)


def write_default_config(repo_root: Path) -> RalphceptionConfig:
    """Write the default config into a repository's .ralphception directory."""
    write_config_atomically(config_path(repo_root), DEFAULT_CONFIG)
    return DEFAULT_CONFIG


def write_config_atomically(config_file: Path, config: RalphceptionConfig) -> None:
    """Persist a config using a temp-file-then-rename atomic write."""
    config_file.parent.mkdir(parents=True, exist_ok=True)
    payload = render_config(config)

    file_descriptor, temp_name = tempfile.mkstemp(
        dir=config_file.parent,
        prefix=f"{config_file.name}.",
        suffix=".tmp",
        text=True,
    )
    temp_path = Path(temp_name)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, config_file)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def load_config(config_file: Path) -> ConfigLoadResult:
    """Load and validate a Ralphception config without mutating the file."""
    try:
        document = config_file.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        return ConfigLoadResult(
            config=None,
            diagnostic=f"failed to decode config at {config_file}: {exc}",
        )
    except OSError as exc:
        return ConfigLoadResult(
            config=None,
            diagnostic=f"unable to read config at {config_file}: {exc}",
        )

    try:
        raw_config = tomllib.loads(document)
    except tomllib.TOMLDecodeError as exc:
        return ConfigLoadResult(
            config=None,
            diagnostic=f"failed to parse config at {config_file}: {exc}",
        )

    try:
        return ConfigLoadResult(config=_parse_config(raw_config))
    except ConfigValidationError as exc:
        return ConfigLoadResult(
            config=None,
            diagnostic=f"invalid config at {config_file}: {exc}",
        )


def render_config(config: RalphceptionConfig) -> str:
    """Serialize a config model to TOML."""
    lines = [
        "[codex]",
        f'model = "{_quote(config.codex.model)}"',
        f'reasoning = "{_quote(config.codex.reasoning)}"',
        f'latency_profile = "{_quote(config.codex.latency_profile)}"',
        f'sandbox = "{_quote(config.codex.sandbox)}"',
        f'approval_policy = "{_quote(config.codex.approval_policy)}"',
        "",
        "[execution]",
        f"use_worktrees_for_edit_runs = {_render_bool(config.execution.use_worktrees_for_edit_runs)}",
        f"max_parallel_children = {config.execution.max_parallel_children}",
        "audit_reopen_priorities = "
        f"[{', '.join(_render_string(item) for item in config.execution.audit_reopen_priorities)}]",
        "",
        "[verification]",
        f"command_timeout_seconds = {config.verification.command_timeout_seconds}",
        "",
        "[ui]",
        f"show_event_timestamps = {_render_bool(config.ui.show_event_timestamps)}",
        f"mouse = {_render_bool(config.ui.mouse)}",
        "",
    ]
    return "\n".join(lines)


def _parse_config(raw_config: Mapping[str, Any]) -> RalphceptionConfig:
    codex = _require_table(raw_config, "codex")
    execution = _require_table(raw_config, "execution")
    verification = _require_table(raw_config, "verification")
    ui = _require_table(raw_config, "ui")

    return RalphceptionConfig(
        codex=CodexConfig(
            model=_require_str(codex, "model", section="codex"),
            reasoning=_require_str(codex, "reasoning", section="codex"),
            latency_profile=_require_str(codex, "latency_profile", section="codex"),
            sandbox=_require_allowed_str(
                codex,
                "sandbox",
                section="codex",
                allowed_values=ALLOWED_SANDBOX_VALUES,
            ),
            approval_policy=_require_allowed_str(
                codex,
                "approval_policy",
                section="codex",
                allowed_values=ALLOWED_APPROVAL_POLICY_VALUES,
            ),
        ),
        execution=ExecutionConfig(
            use_worktrees_for_edit_runs=_require_bool(
                execution,
                "use_worktrees_for_edit_runs",
                section="execution",
            ),
            max_parallel_children=_require_positive_int(
                execution,
                "max_parallel_children",
                section="execution",
            ),
            audit_reopen_priorities=_require_str_list(
                execution,
                "audit_reopen_priorities",
                section="execution",
            ),
        ),
        verification=VerificationConfig(
            command_timeout_seconds=_require_positive_int(
                verification,
                "command_timeout_seconds",
                section="verification",
            ),
        ),
        ui=UIConfig(
            show_event_timestamps=_require_bool(
                ui,
                "show_event_timestamps",
                section="ui",
            ),
            mouse=_require_bool(ui, "mouse", section="ui"),
        ),
    )


def _require_table(raw_config: Mapping[str, Any], section: str) -> Mapping[str, Any]:
    value = raw_config.get(section)
    if not isinstance(value, dict):
        raise ConfigValidationError(f"missing or invalid [{section}] section")
    return value


def _require_str(
    raw_config: Mapping[str, Any],
    key: str,
    *,
    section: str,
) -> str:
    value = raw_config.get(key)
    if not isinstance(value, str):
        raise ConfigValidationError(f"{section}.{key} must be a string")
    return value


def _require_bool(
    raw_config: Mapping[str, Any],
    key: str,
    *,
    section: str,
) -> bool:
    value = raw_config.get(key)
    if type(value) is not bool:
        raise ConfigValidationError(f"{section}.{key} must be a boolean")
    return value


def _require_int(
    raw_config: Mapping[str, Any],
    key: str,
    *,
    section: str,
) -> int:
    value = raw_config.get(key)
    if type(value) is not int:
        raise ConfigValidationError(f"{section}.{key} must be an integer")
    return value


def _require_positive_int(
    raw_config: Mapping[str, Any],
    key: str,
    *,
    section: str,
) -> int:
    value = _require_int(raw_config, key, section=section)
    if value <= 0:
        raise ConfigValidationError(f"{section}.{key} must be greater than 0")
    return value


def _require_allowed_str(
    raw_config: Mapping[str, Any],
    key: str,
    *,
    section: str,
    allowed_values: frozenset[str],
) -> str:
    value = _require_str(raw_config, key, section=section)
    if value not in allowed_values:
        choices = ", ".join(sorted(allowed_values))
        raise ConfigValidationError(f"{section}.{key} must be one of: {choices}")
    return value


def _require_str_list(
    raw_config: Mapping[str, Any],
    key: str,
    *,
    section: str,
) -> tuple[str, ...]:
    value = raw_config.get(key)
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ConfigValidationError(f"{section}.{key} must be a list of strings")
    return tuple(value)


def _quote(value: str) -> str:
    return value.translate(STRING_ESCAPE_SEQUENCES)


def _render_string(value: str) -> str:
    return f'"{_quote(value)}"'


def _render_bool(value: bool) -> str:
    return "true" if value else "false"
