"""Path helpers for Ralphception repository and runtime state locations."""

from __future__ import annotations

import hashlib
import os
import subprocess
from pathlib import Path

APP_NAME = "ralphception"
PROJECT_DIRNAME = ".ralphception"


def resolve_repo_root(start_path: Path) -> Path:
    """Resolve the canonical git top-level directory for a workspace path."""
    return Path(_git_output(start_path, "rev-parse", "--show-toplevel")).resolve(strict=True)


def resolve_workspace_identity_root(start_path: Path) -> Path:
    """Resolve the shared repository identity root across linked git worktrees."""
    common_dir = Path(
        _git_output(start_path, "rev-parse", "--path-format=absolute", "--git-common-dir"),
    ).resolve(strict=True)
    if common_dir.name == ".git":
        return common_dir.parent
    return common_dir


def project_dir(repo_root: Path) -> Path:
    """Return the repo-local Ralphception directory."""
    return repo_root / PROJECT_DIRNAME


def config_path(repo_root: Path) -> Path:
    """Return the repo-local Ralphception config path."""
    return project_dir(repo_root) / "config.toml"


def resolve_xdg_state_home(*, xdg_state_home: Path | None = None) -> Path:
    """Resolve the XDG state base directory."""
    if xdg_state_home is not None:
        return xdg_state_home.expanduser().resolve(strict=False)

    configured_home = os.environ.get("XDG_STATE_HOME")
    if configured_home:
        configured_state_home = Path(configured_home)
        if configured_state_home.is_absolute():
            return configured_state_home.resolve(strict=False)

    return (Path.home() / ".local" / "state").resolve(strict=False)


def workspace_hash(repo_root: Path) -> str:
    """Return the stable workspace hash for a canonical repository root."""
    canonical_root = repo_root.resolve(strict=True)
    return hashlib.sha256(str(canonical_root).encode("utf-8")).hexdigest()


def workspace_state_dir(
    start_path: Path,
    *,
    xdg_state_home: Path | None = None,
) -> Path:
    """Return the XDG state directory for the repository containing start_path."""
    repo_root = resolve_workspace_identity_root(start_path)
    return resolve_xdg_state_home(xdg_state_home=xdg_state_home) / APP_NAME / workspace_hash(
        repo_root,
    )


def _git_output(start_path: Path, *args: str) -> str:
    candidate = start_path if start_path.is_dir() else start_path.parent
    result = subprocess.run(
        ["git", *args],
        check=False,
        cwd=candidate,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        message = result.stderr.strip() or result.stdout.strip() or "unknown git error"
        raise RuntimeError(f"failed to run git {' '.join(args)} for {candidate}: {message}")
    return result.stdout.strip()
