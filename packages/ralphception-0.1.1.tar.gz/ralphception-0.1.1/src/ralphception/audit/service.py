"""Audit finding persistence, status rules, and waiver preparation."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, Sequence

from ralphception.config import DEFAULT_CONFIG
from ralphception.models.runtime import ApprovalRecord
from ralphception.models.verification import AuditFinding, AuditFindingStatus
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic
from ralphception.workflow._identifiers import validate_storage_identifier
from ralphception.workflow.approvals import create_finding_waiver

_BLOCKING_SEVERITIES = frozenset({"P0", "P1", "P2"})


@dataclass(frozen=True, slots=True)
class PreparedFindingWaiver:
    finding: AuditFinding
    approval: ApprovalRecord
    required_run_state: Literal["awaiting_approval"] = "awaiting_approval"


class AuditService:
    """Persist durable findings and enforce audit-state transitions."""

    def __init__(
        self,
        repo_root: Path,
        *,
        reopen_priorities: Sequence[str] | None = None,
        event_store: EventStore | None = None,
    ) -> None:
        self.repo_root = bootstrap_workspace(repo_root)
        self.reopen_priorities = tuple(
            reopen_priorities or DEFAULT_CONFIG.execution.audit_reopen_priorities,
        )
        self._event_store = event_store or EventStore(self.repo_root)

    def persist_finding(
        self,
        finding: AuditFinding,
        *,
        stage_id: str,
        source: str = "audit_service",
    ) -> AuditFinding:
        path = self.finding_path(finding.finding_id)
        event_type = "audit.finding_created" if not path.exists() else "audit.finding_status_changed"
        write_json_atomic(path, finding.model_dump(mode="json"))
        self._event_store.append(
            event_id=_new_event_id("audit", finding.finding_id),
            run_id=finding.run_id,
            stage_id=stage_id,
            task_id=None,
            event_type=event_type,
            source=source,
            payload={
                "finding_id": finding.finding_id,
                "severity": finding.severity,
                "kind": finding.kind,
                "status": finding.status,
            },
            occurred_at=finding.resolved_at or finding.created_at,
        )
        return finding

    def reopen_finding(
        self,
        finding: AuditFinding,
        *,
        stage_id: str,
        reopened_at: datetime | None = None,
        source: str = "audit_service",
    ) -> AuditFinding:
        if finding.status == "open" or finding.severity not in self.reopen_priorities:
            return finding
        reopened_at = reopened_at or datetime.now(timezone.utc)
        reopened = AuditFinding(
            finding_id=finding.finding_id,
            run_id=finding.run_id,
            severity=finding.severity,
            kind=finding.kind,
            title=finding.title,
            evidence_refs=finding.evidence_refs,
            status="open",
            created_at=reopened_at,
            resolved_at=None,
        )
        return self.persist_finding(
            reopened,
            stage_id=stage_id,
            source=source,
        )

    def blocks_completion(self, findings: Sequence[AuditFinding]) -> bool:
        return any(
            finding.status == "open" and finding.severity in _BLOCKING_SEVERITIES
            for finding in findings
        )

    def transition_finding_status(
        self,
        finding: AuditFinding,
        *,
        new_status: AuditFindingStatus,
        actor: Literal["human", "autonomous"],
        stage_id: str,
        changed_at: datetime | None = None,
        supported_by_verification: bool = False,
        supported_by_merge: bool = False,
        source: str = "audit_service",
    ) -> AuditFinding:
        changed_at = changed_at or datetime.now(timezone.utc)

        if (
            new_status in {"accepted", "wontfix"}
            and finding.status == "open"
            and finding.severity in _BLOCKING_SEVERITIES
            and actor != "human"
        ):
            raise PermissionError("Only human approval may accept or wontfix blocking findings")

        if (
            new_status == "resolved"
            and actor == "autonomous"
            and not (supported_by_verification or supported_by_merge)
        ):
            raise PermissionError(
                "Autonomous resolution must be supported by verification or merged changes",
            )

        if new_status == "open":
            return self.reopen_finding(
                finding,
                stage_id=stage_id,
                reopened_at=changed_at,
                source=source,
            )

        transitioned = AuditFinding(
            finding_id=finding.finding_id,
            run_id=finding.run_id,
            severity=finding.severity,
            kind=finding.kind,
            title=finding.title,
            evidence_refs=finding.evidence_refs,
            status=new_status,
            created_at=finding.created_at,
            resolved_at=changed_at,
        )
        return self.persist_finding(
            transitioned,
            stage_id=stage_id,
            source=source,
        )

    def prepare_waiver(
        self,
        finding: AuditFinding,
        *,
        approval_id: str,
        approver: str,
        rationale: str,
        prepared_at: datetime | None = None,
    ) -> PreparedFindingWaiver:
        if finding.status != "open":
            raise ValueError("Waiver requests require an open finding")
        approval = create_finding_waiver(
            approval_id=approval_id,
            run_id=finding.run_id,
            approver=approver,
            waived_finding_ids=[finding.finding_id],
            rationale=rationale,
            approved_at=prepared_at,
        )
        return PreparedFindingWaiver(finding=finding, approval=approval)

    def finding_path(self, finding_id: str) -> Path:
        validated_finding_id = validate_storage_identifier(
            finding_id,
            field_name="finding_id",
        )
        return self.repo_root / ".ralphception" / "findings" / f"{validated_finding_id}.json"


def _new_event_id(prefix: str, identifier: str) -> str:
    return f"{prefix}-{identifier}-{uuid.uuid4().hex}"
