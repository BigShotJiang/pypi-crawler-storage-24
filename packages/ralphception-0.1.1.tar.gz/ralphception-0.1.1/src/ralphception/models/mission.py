"""Durable mission session and planner contracts for the actor runtime."""

from __future__ import annotations

from typing import Literal

from pydantic import Field, field_validator

from .artifacts import DurableModel

MissionPhase = Literal[
    "intake",
    "spec_review",
    "planning",
    "scheduling",
    "merging",
    "audit",
    "completed",
    "failed",
]


class MissionSession(DurableModel):
    mission_id: str
    repo_root: str
    phase: MissionPhase
    approved_spec_version: int | None = Field(default=None, ge=1)

    @field_validator("mission_id", "repo_root")
    @classmethod
    def _validate_non_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("mission session fields must not be blank")
        return value


class ExecutionPolicy(DurableModel):
    max_parallel_children: int = Field(default=1, ge=1)
    batch_by_scope: bool = True
    allow_commit_split: bool = True


class PlannerOutput(DurableModel):
    plan_markdown_path: str
    plan_json_path: str
    todo_ids: list[str] = Field(min_length=1)
    commit_intent_ids: list[str] = Field(min_length=1)
    execution_policy: ExecutionPolicy = Field(default_factory=ExecutionPolicy)

    @field_validator("plan_markdown_path", "plan_json_path")
    @classmethod
    def _validate_non_blank_paths(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("planner output paths must not be blank")
        return value
