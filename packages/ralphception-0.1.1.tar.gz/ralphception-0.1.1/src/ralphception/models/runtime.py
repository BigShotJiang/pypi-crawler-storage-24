"""Core runtime durable model contracts."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import Field, NonNegativeInt, model_validator

from .artifacts import ArtifactRef, DurableModel
from .session import ChildSessionRef

RunStageStatus = Literal[
    "pending",
    "running",
    "completed",
    "awaiting_approval",
    "blocked",
    "session_lost",
    "recovery_blocked",
    "failed",
    "aborted",
]
StageKind = Literal["intake", "brainstorm", "spec", "plan", "execute", "merge", "audit"]
TaskKind = Literal["turn", "child_run", "agent", "merge", "verification", "artifact_promotion"]
TaskStatus = Literal["queued", "running", "succeeded", "blocked", "session_lost", "failed", "aborted"]
TaskOwner = Literal["workflow_engine", "codex_session_manager", "merge_stage", "audit_stage", "ui"]
ExecutionBundleState = Literal["draft", "approved", "derived_in_scope", "awaiting_approval", "superseded"]
ApprovalKind = Literal["spec_review", "execution_bundle", "finding_waiver"]

_ACTIVE_RUN_SESSION_STATUSES = {
    "running",
    "completed",
    "awaiting_approval",
    "blocked",
    "session_lost",
    "recovery_blocked",
}
_TERMINAL_STAGE_STATUSES = {"completed", "failed", "aborted"}


def _validate_execution_timestamps(
    *,
    status: str,
    pending_status: str,
    terminal_statuses: set[str],
    started_at: datetime | None,
    completed_at: datetime | None,
) -> None:
    if status != pending_status and started_at is None:
        raise ValueError("started_at is required after execution begins")
    if status in terminal_statuses and completed_at is None:
        raise ValueError("completed_at is required for terminal statuses")
    if status not in terminal_statuses and completed_at is not None:
        raise ValueError("completed_at must be null before the object is terminal")
    if started_at is None and completed_at is not None:
        raise ValueError("completed_at requires started_at")


def _validate_timestamp_order(
    *,
    started_at: datetime | None,
    completed_at: datetime | None,
) -> None:
    if started_at is not None and completed_at is not None and completed_at < started_at:
        raise ValueError("completed_at cannot be earlier than started_at")


class Run(DurableModel):
    run_id: str
    parent_run_id: str | None
    supersedes_run_id: str | None
    goal: str
    status: RunStageStatus
    stage_ids: list[str]
    config_snapshot: dict[str, Any]
    codex_session_ref: ChildSessionRef | None
    artifact_refs: list[ArtifactRef]
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="after")
    def validate_run_contract(self) -> "Run":
        if self.codex_session_ref is None and not (
            self.status == "pending" or (self.status == "failed" and not self.stage_ids)
        ):
            raise ValueError(
                "codex_session_ref is required unless the run is pending or failed before orchestration started",
            )
        if self.updated_at < self.created_at:
            raise ValueError("updated_at must be greater than or equal to created_at")
        return self


class Stage(DurableModel):
    stage_id: str
    run_id: str
    stage_kind: StageKind
    status: RunStageStatus
    task_ids: list[str]
    started_at: datetime | None
    completed_at: datetime | None

    @model_validator(mode="after")
    def validate_stage_lifecycle(self) -> "Stage":
        _validate_timestamp_order(started_at=self.started_at, completed_at=self.completed_at)
        if self.status == "pending":
            if self.started_at is not None or self.completed_at is not None:
                raise ValueError("pending stages cannot have started_at or completed_at")
            return self
        if self.status == "awaiting_approval":
            if self.completed_at is not None:
                raise ValueError("completed_at must be null before the object is terminal")
            return self
        if self.status in {"running", "blocked", "session_lost", "recovery_blocked"}:
            if self.started_at is None:
                raise ValueError("started_at is required after execution begins")
            if self.completed_at is not None:
                raise ValueError("completed_at must be null before the object is terminal")
            return self
        if self.status == "aborted":
            if self.completed_at is None:
                raise ValueError("completed_at is required for terminal statuses")
            return self
        _validate_execution_timestamps(
            status=self.status,
            pending_status="pending",
            terminal_statuses={"completed", "failed"},
            started_at=self.started_at,
            completed_at=self.completed_at,
        )
        return self


class Task(DurableModel):
    task_id: str
    run_id: str
    stage_id: str
    task_kind: TaskKind
    status: TaskStatus
    owner: TaskOwner
    input_refs: list[ArtifactRef]
    output_refs: list[ArtifactRef]
    started_at: datetime | None
    completed_at: datetime | None

    @model_validator(mode="after")
    def validate_task_lifecycle(self) -> "Task":
        if self.task_kind == "verification":
            if len(self.input_refs) != 1 or len(self.output_refs) != 1:
                raise ValueError(
                    "verification tasks require exactly one input ref and one output ref",
                )
            if self.input_refs[0].artifact_kind != "verification_spec":
                raise ValueError("verification tasks require a verification_spec input ref")
            if self.output_refs[0].artifact_kind != "verification_result":
                raise ValueError("verification tasks require a verification_result output ref")
        _validate_timestamp_order(started_at=self.started_at, completed_at=self.completed_at)
        if self.status == "queued":
            if self.started_at is not None or self.completed_at is not None:
                raise ValueError("queued tasks cannot have started_at or completed_at")
            return self
        if self.status == "running":
            if self.started_at is None:
                raise ValueError("started_at is required after execution begins")
            if self.completed_at is not None:
                raise ValueError("completed_at must be null before the task is terminal")
            return self
        if self.status in {"blocked", "session_lost"}:
            if self.completed_at is not None:
                raise ValueError("completed_at must be null before the task is terminal")
            return self
        if self.status in {"failed", "aborted"}:
            if self.completed_at is None:
                raise ValueError("completed_at is required for terminal statuses")
            return self
        if self.status == "succeeded":
            if self.started_at is None:
                raise ValueError("started_at is required after execution begins")
            if self.completed_at is None:
                raise ValueError("completed_at is required for terminal statuses")
        return self


class ChildAssignment(DurableModel):
    assignment_id: str
    goal: str
    acceptance_criteria_refs: list[ArtifactRef]
    dependency_refs: list[ArtifactRef]
    bundle_version: int = Field(ge=1)
    final_commit_message: str | None = None


class ExecutionBundle(DurableModel):
    bundle_id: str
    run_id: str
    bundle_version: int = Field(ge=1)
    state: ExecutionBundleState
    artifact_refs: list[ArtifactRef]
    base_bundle_id: str | None
    scope_hash: str
    created_at: datetime
    assigned_run_ids: list[str]

    @model_validator(mode="after")
    def validate_lineage(self) -> "ExecutionBundle":
        if self.state == "derived_in_scope":
            if self.base_bundle_id is None:
                raise ValueError("derived_in_scope bundles require base_bundle_id")
            return self
        if self.state != "superseded" and self.base_bundle_id is not None:
            raise ValueError("only derived_in_scope and superseded bundles may carry base_bundle_id")
        return self


class ApprovalRecord(DurableModel):
    approval_id: str
    run_id: str
    approval_kind: ApprovalKind
    artifact_bundle_refs: list[ArtifactRef] | None
    bundle_version: int | None = Field(default=None, ge=1)
    scope_hash: str | None
    approved_at: datetime
    approver: str
    waived_finding_ids: list[str] | None
    rationale: str | None

    @model_validator(mode="after")
    def validate_approval_contract(self) -> "ApprovalRecord":
        if self.approval_kind == "finding_waiver":
            if not self.waived_finding_ids:
                raise ValueError("finding_waiver approvals require waived_finding_ids")
            if any(not finding_id.strip() for finding_id in self.waived_finding_ids):
                raise ValueError("finding_waiver approvals require non-blank waived_finding_ids")
            if self.rationale is None or not self.rationale.strip():
                raise ValueError("finding_waiver approvals require rationale")
            has_bundle_context = (
                self.artifact_bundle_refs is not None
                or self.bundle_version is not None
                or self.scope_hash is not None
            )
            if has_bundle_context:
                if (
                    self.artifact_bundle_refs is None
                    or self.bundle_version is None
                    or self.scope_hash is None
                ):
                    raise ValueError(
                        "finding_waiver bundle context must include artifact_bundle_refs, bundle_version, and scope_hash together",
                    )
                if not self.artifact_bundle_refs:
                    raise ValueError("finding_waiver bundle context requires non-empty artifact_bundle_refs")
            return self

        if self.artifact_bundle_refs is None or self.bundle_version is None or self.scope_hash is None:
            raise ValueError("non-waiver approvals require artifact bundle fields")
        if not self.artifact_bundle_refs:
            raise ValueError("non-waiver approvals require non-empty artifact_bundle_refs")
        if self.waived_finding_ids is not None or self.rationale is not None:
            raise ValueError("waiver fields must be null unless approval_kind is finding_waiver")
        return self


class Checkpoint(DurableModel):
    checkpoint_id: str
    run_id: str
    checkpoint_kind: str
    event_offsets: dict[str, NonNegativeInt]
    bundle_version: int = Field(ge=1)
    authoritative_root: str
    active_worktrees: list[str]
    created_at: datetime
