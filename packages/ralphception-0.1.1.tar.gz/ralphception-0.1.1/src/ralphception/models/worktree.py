"""Worktree handoff durable model contracts."""

from __future__ import annotations

from typing import Literal

from pydantic import Field, model_validator

from .artifacts import ArtifactRef, DurableModel

MergeReadiness = Literal["ready", "needs_revision", "blocked"]
CleanupState = Literal["pending", "retained", "cleaned"]


class WorktreeHandoff(DurableModel):
    child_run_id: str
    worktree_path: str
    branch_name: str
    base_branch: str
    head_commit: str
    goal: str
    artifact_refs: list[ArtifactRef]
    verification_artifact_refs: list[ArtifactRef]
    consumed_bundle_version: int = Field(ge=1)
    touched_paths: list[str]
    verification_summary: str
    merge_readiness: MergeReadiness
    cleanup_state: CleanupState

    @model_validator(mode="after")
    def validate_cleanup_invariants(self) -> "WorktreeHandoff":
        if self.merge_readiness in {"needs_revision", "blocked"} and self.cleanup_state == "cleaned":
            raise ValueError("non-mergeable handoffs must not be marked cleaned")
        return self
