"""Verification and audit durable model contracts."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import Field, field_validator, model_validator

from .artifacts import ArtifactRef, DurableModel

VerificationScope = Literal["task", "child_run", "run", "merge", "audit"]
VerificationStatus = Literal["pending", "running", "passed", "failed", "errored"]
VerificationCommandStatus = Literal["pending", "running", "passed", "failed", "errored"]
AuditFindingStatus = Literal["open", "accepted", "resolved", "wontfix"]
FindingSeverity = Literal["P0", "P1", "P2", "P3"]
FindingKind = Literal["bug", "test_gap", "feature_gap", "spec_drift", "integration_risk"]

_TERMINAL_VERIFICATION_STATUSES = {"passed", "failed", "errored"}


def _validate_timestamp_order(
    *,
    started_at: datetime | None,
    completed_at: datetime | None,
) -> None:
    if started_at is not None and completed_at is not None and completed_at < started_at:
        raise ValueError("completed_at cannot be earlier than started_at")


class VerificationSpec(DurableModel):
    verification_id: str
    run_id: str
    task_id: str
    requested_by: str
    scope: VerificationScope
    required: bool
    commands: list[str] = Field(min_length=1)
    success_criteria: str
    created_at: datetime

    @field_validator("commands")
    @classmethod
    def validate_commands_are_non_blank(cls, value: list[str]) -> list[str]:
        if any(not command.strip() for command in value):
            raise ValueError("commands must not contain blank values")
        return value


class VerificationCommandResult(DurableModel):
    command: str
    cwd: str
    exit_code: int | None
    status: VerificationCommandStatus
    duration_ms: int | None = Field(default=None, ge=0)
    stdout_ref: ArtifactRef | None
    stderr_ref: ArtifactRef | None

    @field_validator("command", "cwd")
    @classmethod
    def validate_non_blank_strings(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("command and cwd must not be blank")
        return value

    @model_validator(mode="after")
    def validate_status_consistency(self) -> "VerificationCommandResult":
        if self.status in {"pending", "running"}:
            if (
                self.exit_code is not None
                or self.duration_ms is not None
                or self.stdout_ref is not None
                or self.stderr_ref is not None
            ):
                raise ValueError(
                    "pending or running command results cannot include completion data",
                )
            return self
        if self.duration_ms is None or self.stdout_ref is None or self.stderr_ref is None:
            raise ValueError("terminal command results require duration and output refs")
        if self.status == "passed" and self.exit_code != 0:
            raise ValueError("passed command results require exit_code 0")
        if self.status in {"failed", "errored"} and (
            self.exit_code is None or self.exit_code == 0
        ):
            raise ValueError("failed or errored command results require a non-zero exit_code")
        return self


class VerificationResult(DurableModel):
    verification_id: str
    run_id: str
    task_id: str
    status: VerificationStatus
    command_results: list[VerificationCommandResult]
    started_at: datetime | None
    completed_at: datetime | None

    @model_validator(mode="after")
    def validate_lifecycle(self) -> "VerificationResult":
        if self.status == "pending":
            if self.command_results:
                raise ValueError("pending verification results cannot have command results")
            if self.started_at is not None or self.completed_at is not None:
                raise ValueError("pending verification results cannot have timestamps")
            return self
        _validate_timestamp_order(started_at=self.started_at, completed_at=self.completed_at)
        if self.status != "pending" and self.started_at is None:
            raise ValueError("started_at is required after verification starts")
        if self.status in _TERMINAL_VERIFICATION_STATUSES and self.completed_at is None:
            raise ValueError("completed_at is required for terminal verification statuses")
        if self.status not in _TERMINAL_VERIFICATION_STATUSES and self.completed_at is not None:
            raise ValueError("completed_at must be null before verification is terminal")
        if self.started_at is None and self.completed_at is not None:
            raise ValueError("completed_at requires started_at")
        command_statuses = {result.status for result in self.command_results}
        if self.status == "running":
            if not command_statuses.issubset({"pending", "running", "passed"}):
                raise ValueError(
                    "running verification results can only contain pending, running, or passed command results",
                )
            return self
        if {"pending", "running"} & command_statuses:
            raise ValueError("terminal verification results cannot contain pending or running command results")
        if self.status == "passed":
            if not self.command_results:
                raise ValueError("passed verification results require at least one command result")
            if command_statuses != {"passed"}:
                raise ValueError("passed verification results require all command results to be passed")
        if self.status == "failed":
            if not self.command_results:
                raise ValueError("failed verification results require at least one command result")
            if "failed" not in command_statuses:
                raise ValueError("failed verification results require at least one failed command result")
            if "errored" in command_statuses:
                raise ValueError("failed verification results cannot contain errored command results")
        if self.status == "errored":
            if not self.command_results:
                raise ValueError("errored verification results require at least one command result")
            if "errored" not in command_statuses:
                raise ValueError(
                    "errored verification results require at least one errored command result",
                )
        return self


class AuditFinding(DurableModel):
    finding_id: str
    run_id: str
    severity: FindingSeverity
    kind: FindingKind
    title: str
    evidence_refs: list[ArtifactRef]
    status: AuditFindingStatus
    created_at: datetime
    resolved_at: datetime | None

    @model_validator(mode="after")
    def validate_resolution_state(self) -> "AuditFinding":
        if self.status == "open":
            if self.resolved_at is not None:
                raise ValueError("resolved_at must be null while a finding is open")
            return self
        if self.resolved_at is None:
            raise ValueError("resolved_at is required once a finding is no longer open")
        if self.resolved_at < self.created_at:
            raise ValueError("resolved_at cannot be earlier than created_at")
        return self
