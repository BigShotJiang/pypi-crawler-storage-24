"""Stable bundled-skill lookup with repo-local override support."""

from __future__ import annotations

from importlib import resources
from pathlib import Path
from typing import Literal, Sequence, cast, get_args

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, ValidationError, field_validator, model_validator

from ralphception.paths import project_dir

StableSkillId = Literal[
    "brainstorm.default",
    "spec.write",
    "plan.write",
    "execute.task",
    "merge.coordinator",
    "audit.review",
    "run.summary",
]
BUNDLED_SKILL_IDS = cast(tuple[StableSkillId, ...], get_args(StableSkillId))

_STABLE_SKILL_ID_ADAPTER = TypeAdapter(StableSkillId)


class SkillRegistryModel(BaseModel):
    """Shared base model configuration for registry metadata."""

    model_config = ConfigDict(extra="forbid")


class BundledSkillAsset(SkillRegistryModel):
    skill_id: StableSkillId
    resource_name: str

    @field_validator("resource_name")
    @classmethod
    def _require_markdown_resource(cls, value: str) -> str:
        value = value.strip()
        if not value.endswith(".md"):
            raise ValueError("resource_name must point to a markdown asset")
        return value


class SkillResolutionWarning(SkillRegistryModel):
    code: Literal["override_invalid", "override_unreadable"]
    skill_id: StableSkillId
    override_path: Path
    message: str


class ResolvedSkill(SkillRegistryModel):
    skill_id: StableSkillId
    source: Literal["bundled", "repo"]
    path: Path
    markdown_body: str
    warnings: list[SkillResolutionWarning] = Field(default_factory=list)

    @field_validator("markdown_body")
    @classmethod
    def _require_non_empty_markdown_body(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("markdown_body must not be empty")
        return value


class BundledSkillCatalog(SkillRegistryModel):
    assets: tuple[BundledSkillAsset, ...]

    @model_validator(mode="after")
    def _validate_assets(self) -> BundledSkillCatalog:
        seen_skill_ids: set[str] = set()
        package_root = resources.files("ralphception.bundled_skills")

        for asset in self.assets:
            if asset.skill_id in seen_skill_ids:
                raise ValueError(f"duplicate bundled skill id: {asset.skill_id}")
            seen_skill_ids.add(asset.skill_id)

            if not package_root.joinpath(asset.resource_name).is_file():
                raise ValueError(f"missing bundled skill asset: {asset.resource_name}")

        return self


DEFAULT_BUNDLED_ASSETS = tuple(
    BundledSkillAsset(skill_id=skill_id, resource_name=f"{skill_id}.md")
    for skill_id in BUNDLED_SKILL_IDS
)


class SkillRegistry:
    """Resolve bundled internal skills and repo-local overrides."""

    def __init__(
        self,
        repo_root: Path,
        *,
        bundled_assets: Sequence[BundledSkillAsset] | None = None,
    ) -> None:
        self._repo_root = repo_root.resolve(strict=False)
        assets = DEFAULT_BUNDLED_ASSETS if bundled_assets is None else tuple(bundled_assets)
        self._catalog = BundledSkillCatalog(assets=assets)
        self._assets_by_id = {asset.skill_id: asset for asset in self._catalog.assets}
        self._repo_skill_dir = project_dir(self._repo_root) / "skills"

    @property
    def known_skill_ids(self) -> tuple[StableSkillId, ...]:
        return tuple(self._assets_by_id)

    def load(self, skill_id: str) -> ResolvedSkill:
        validated_skill_id = _STABLE_SKILL_ID_ADAPTER.validate_python(skill_id)
        override_path = self._repo_skill_dir / f"{validated_skill_id}.md"

        try:
            return self._load_repo_override(validated_skill_id, override_path)
        except FileNotFoundError:
            return self._load_bundled(validated_skill_id)
        except ValidationError as error:
            warning = self._make_warning(
                code="override_invalid",
                skill_id=validated_skill_id,
                override_path=override_path,
                message=str(error),
            )
            return self._load_bundled(validated_skill_id, warnings=[warning])
        except (OSError, UnicodeError) as error:
            warning = self._make_warning(
                code="override_unreadable",
                skill_id=validated_skill_id,
                override_path=override_path,
                message=str(error),
            )
            return self._load_bundled(validated_skill_id, warnings=[warning])

    def _load_repo_override(self, skill_id: StableSkillId, override_path: Path) -> ResolvedSkill:
        markdown_body = override_path.read_text(encoding="utf-8")
        return ResolvedSkill(
            skill_id=skill_id,
            source="repo",
            path=override_path,
            markdown_body=markdown_body,
        )

    def _load_bundled(
        self,
        skill_id: StableSkillId,
        *,
        warnings: list[SkillResolutionWarning] | None = None,
    ) -> ResolvedSkill:
        asset = self._assets_by_id[skill_id]
        asset_path = resources.files("ralphception.bundled_skills").joinpath(asset.resource_name)

        return ResolvedSkill(
            skill_id=skill_id,
            source="bundled",
            path=Path(str(asset_path)),
            markdown_body=asset_path.read_text(encoding="utf-8"),
            warnings=[] if warnings is None else warnings,
        )

    @staticmethod
    def _make_warning(
        *,
        code: Literal["override_invalid", "override_unreadable"],
        skill_id: StableSkillId,
        override_path: Path,
        message: str,
    ) -> SkillResolutionWarning:
        return SkillResolutionWarning(
            code=code,
            skill_id=skill_id,
            override_path=override_path,
            message=message,
        )
