from setuptools import setup, find_packages

setup(
    name="ad-supermath",
    version="0.1.0",
    description="A custom Python math utility library with statistics, geometry, finance and random utilities",
    author="Yashvi Harsora",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[],
    license="MIT"
)