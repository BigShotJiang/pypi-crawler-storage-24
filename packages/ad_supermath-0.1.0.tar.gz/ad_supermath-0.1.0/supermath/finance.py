import math

# Finance utilities for SuperMath

# 1. Calculate simple interest
def simple_interest(principal, rate, time):
    return (principal * rate * time) / 100


# 2. Calculate compound interest
def compound_interest(principal, rate, time):
    return principal * (1 + rate/100) ** time - principal


# 3. Calculate total amount after compound interest
def compound_amount(principal, rate, time):
    return principal * (1 + rate/100) ** time


# 4. Calculate profit
def profit(cost_price, selling_price):
    return selling_price - cost_price


# 5. Calculate loss
def loss(cost_price, selling_price):
    return cost_price - selling_price


# 6. Calculate profit percentage
def profit_percentage(cost_price, selling_price):
    return ((selling_price - cost_price) / cost_price) * 100


# 7. Calculate loss percentage
def loss_percentage(cost_price, selling_price):
    return ((cost_price - selling_price) / cost_price) * 100


# 8. Calculate discount amount
def discount_amount(price, discount_percent):
    return price * discount_percent / 100


# 9. Calculate final price after discount
def discounted_price(price, discount_percent):
    return price - (price * discount_percent / 100)


# 10. Calculate GST amount
def gst_amount(price, gst_percent):
    return price * gst_percent / 100


# 11. Calculate price including GST
def price_with_gst(price, gst_percent):
    return price + (price * gst_percent / 100)


# 12. Calculate EMI (Equated Monthly Installment)
def emi(principal, annual_rate, months):
    monthly_rate = annual_rate / (12 * 100)
    return (principal * monthly_rate * (1 + monthly_rate) ** months) / ((1 + monthly_rate) ** months - 1)