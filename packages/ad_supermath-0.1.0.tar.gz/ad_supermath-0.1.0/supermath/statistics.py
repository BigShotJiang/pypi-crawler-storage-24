# Statistics utilities for SuperMath


# 1. Calculate mean (average)
def mean(numbers):
    return sum(numbers) / len(numbers)

# 2. Find median value
def median(numbers):
    nums = sorted(numbers)
    n = len(nums)

    if n % 2 == 0:
        return (nums[n//2 - 1] + nums[n//2]) / 2
    else:
        return nums[n//2]

# 3. Find mode (most frequent value)

def mode(numbers):
    return max(set(numbers), key=numbers.count)

# 4. Find range of data
def data_range(numbers):
    return max(numbers) - min(numbers)

# 5. Calculate variance
def variance(numbers):
    m = mean(numbers)
    return sum((x - m) ** 2 for x in numbers) / len(numbers)

# 6. Calculate standard deviation
def standard_deviation(numbers):
    return variance(numbers) ** 0.5

# 7. Find percentile
def percentile(numbers, p):
    nums = sorted(numbers)
    k = (len(nums)-1) * (p/100)
    f = int(k)
    c = f + 1

    if c >= len(nums):
        return nums[f]

    return nums[f] + (nums[c] - nums[f]) * (k - f)