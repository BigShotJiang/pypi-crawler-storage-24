import math

# Geometry utilities for SuperMath

# 1. Calculate area of circle
def circle_area(radius):
    return math.pi * radius ** 2

# 2. Calculate circumference of circle
def circle_circumference(radius):
    return 2 * math.pi * radius

# 3. Calculate rectangle area
def rectangle_area(length, width):
    return length * width

# 4. Calculate rectangle perimeter
def rectangle_perimeter(length, width):
    return 2 * (length + width)

# 5. Calculate triangle area
def triangle_area(base, height):
    return 0.5 * base * height

# 6. Calculate triangle perimeter
def triangle_perimeter(a, b, c):
    return a + b + c

# 7. Calculate square area
def square_area(side):
    return side * side

# 8. Calculate square perimeter
def square_perimeter(side):
    return 4 * side

# 9. Calculate cylinder volume
def cylinder_volume(radius, height):
    return math.pi * radius ** 2 * height

# 10. Calculate sphere volume
def sphere_volume(radius):
    return (4/3) * math.pi * radius ** 3

# 11. Calculate sphere surface area
def sphere_surface_area(radius):
    return 4 * math.pi * radius ** 2

# 12. Distance between two points
def distance(x1, y1, x2, y2):
    return math.sqrt((x2-x1)**2 + (y2-y1)**2)