import random
import string

# Random utilities for SuperMath

# 1. Generate random integer in range
def random_int(min_val, max_val):
    return random.randint(min_val, max_val)


# 2. Generate random float between 0 and 1
def random_float():
    return random.random()


# 3. Generate random float in range
def random_float_range(min_val, max_val):
    return random.uniform(min_val, max_val)


# 4. Select random element from list
def random_choice(items):
    return random.choice(items)


# 5. Shuffle a list
def shuffle_list(items):
    random.shuffle(items)
    return items


# 6. Generate random boolean
def random_bool():
    return random.choice([True, False])


# 7. Generate random character
def random_char():
    return random.choice(string.ascii_letters)


# 8. Generate random digit
def random_digit():
    return random.choice(string.digits)


# 9. Generate random string
def random_string(length):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))


# 10. Generate random password
def random_password(length):
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(random.choice(chars) for _ in range(length))


# 11. Generate random color (hex)
def random_color():
    return "#{:06x}".format(random.randint(0, 0xFFFFFF))


# 12. Randomly pick multiple items
def random_sample(items, count):
    return random.sample(items, count)