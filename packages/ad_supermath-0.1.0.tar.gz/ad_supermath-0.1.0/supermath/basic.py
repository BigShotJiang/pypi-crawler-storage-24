# Basic math utilities for SuperMath


# 1. Calculate percentage
def percentage(value, total):
    return (value / total) * 100

# 2. square 
def square(x):
    return x*x

# 3. cube
def cube(x):
    return x*x*x

# 4. even numbers
def is_even(num):
    return num%2==0

# 5. odd numbers 
def is_odd(num):
    return num%2!=0

# 6. Limit value
def clamp(value, min_value, max_value):
    return max(min_value, min(value, max_value))

# 7. average
def average(numbers):
    return sum(numbers) / len(numbers)

# 8. factorial
def factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# 9. GCD (Greatest Common Divisor (Euclidean algorithm))
def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

# 10. LCM (Least Common Multiple)
def lcm(a, b):
    return abs(a * b) // gcd(a, b)

# 11. map-range (Map value from one range to another)
def map_range(value, in_min, in_max, out_min, out_max):
    return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

# 12. normalized value (Normalize value between 0 and 1)
def normalize(value, min_val, max_val):
    return (value - min_val) / (max_val - min_val)

# 13. round (Round number to given decimal places)
def round_to(value, decimals=0):
    return round(value, decimals)

# 14. sign  (check the sign of the number- positive/negative)
def sign(num):
    if num > 0:
        return 1
    elif num < 0:
        return -1
    else:
        return 0
    
# 15. swap (Swap two values)
def swap(a, b):
    return b, a