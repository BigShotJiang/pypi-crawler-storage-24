# SuperMath 📊

SuperMath is a custom Python utility library that provides useful mathematical, statistical, geometry, finance, and random utility functions in one place.

It is designed to make common calculations easier and more accessible for developers, students, and data enthusiasts.

---

## Features

SuperMath includes multiple modules:

### Basic Utilities

- percentage
- average
- square
- cube
- factorial
- gcd
- lcm
- map_range
- normalize
- round_to
- sign
- swap

### Statistics

- mean
- median
- mode
- data_range
- variance
- standard_deviation
- percentile

### Geometry

- circle_area
- circle_circumference
- rectangle_area
- rectangle_perimeter
- triangle_area
- triangle_perimeter
- square_area
- square_perimeter
- cylinder_volume
- sphere_volume
- sphere_surface_area
- distance

### Finance

- simple_interest
- compound_interest
- compound_amount
- profit
- loss
- profit_percentage
- loss_percentage
- discount_amount
- discounted_price
- gst_amount
- price_with_gst
- emi

### Random Utilities

- random_int
- random_float
- random_float_range
- random_choice
- shuffle_list
- random_bool
- random_char
- random_digit
- random_string
- random_password
- random_color
- random_sample

---

## Installation

```bash
pip install supermath
```
