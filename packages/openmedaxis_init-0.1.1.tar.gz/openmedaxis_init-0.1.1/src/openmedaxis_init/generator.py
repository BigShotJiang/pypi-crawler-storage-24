import re
import shutil
import subprocess
from importlib.resources import files
from pathlib import Path


def _normalize_package_name(name: str) -> str:
    package = name.strip().lower().replace("-", "_").replace(" ", "_")
    package = re.sub(r"[^a-zA-Z0-9_]", "", package)
    if not package:
        raise ValueError("Project name produced an empty package name.")
    if package[0].isdigit():
        package = f"app_{package}"
    return package


def _render_text(content: str, context: dict[str, str]) -> str:
    for key, value in context.items():
        content = content.replace(f"{{{{ {key} }}}}", value)
    return content


def _copy_template_tree(
    template_root: Path,
    target_root: Path,
    context: dict[str, str],
) -> None:
    for src in template_root.rglob("*"):
        rel = src.relative_to(template_root)

        rel_str = str(rel)
        if rel_str.startswith("src/app"):
            rel_str = rel_str.replace("src/app", f"src/{context['package_name']}", 1)

        if rel_str.endswith(".template"):
            rel_str = rel_str[: -len(".template")]

        dst = target_root / rel_str

        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
            continue

        dst.parent.mkdir(parents=True, exist_ok=True)

        if src.suffix == ".template":
            text = src.read_text(encoding="utf-8")
            rendered = _render_text(text, context)
            dst.write_text(rendered, encoding="utf-8")
        else:
            shutil.copy2(src, dst)


def _run(cmd: list[str], cwd: Path) -> None:
    result = subprocess.run(cmd, cwd=cwd)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}")


def _resolve_openmedaxis_dependency(openmedaxis_version: str | None) -> str:
    if not openmedaxis_version or openmedaxis_version == "latest":
        return "openmedaxis"
    return f"openmedaxis=={openmedaxis_version}"


def _uv_torch_block(torch_backend: str) -> str:
    if torch_backend == "cu118":
        return """
[tool.uv.sources]
torch = [{ index = "pytorch-cu118" }]
torchvision = [{ index = "pytorch-cu118" }]
torchaudio = [{ index = "pytorch-cu118" }]

[[tool.uv.index]]
name = "pytorch-cu118"
url = "https://download.pytorch.org/whl/cu118"
explicit = true
""".strip()

    if torch_backend == "cpu":
        return """
[tool.uv.sources]
torch = [{ index = "pytorch-cpu" }]
torchvision = [{ index = "pytorch-cpu" }]
torchaudio = [{ index = "pytorch-cpu" }]

[[tool.uv.index]]
name = "pytorch-cpu"
url = "https://download.pytorch.org/whl/cpu"
explicit = true
""".strip()

    raise ValueError(f"Unsupported torch backend: {torch_backend}")


def _modern_packages() -> list[str]:
    return [
        "lightning==2.5.2",
        "nibabel==5.4.0",
        "numpy==2.1.2",
        "scipy==1.16.0",
        "torchmetrics==1.7.3",
        "tqdm==4.67.1",
    ]


def _torch_packages() -> list[str]:
    return [
        "torch==2.6.0",
        "torchvision==0.21.0",
        "torchaudio==2.6.0",
    ]


def _install_template_stack(
    cwd: Path,
    template: str,
    openmedaxis_dependency: str,
) -> None:
    _run(["uv", "add", openmedaxis_dependency], cwd=cwd)

    if template == "modern":
        _run(["uv", "add", *_torch_packages()], cwd=cwd)
        _run(["uv", "add", *_modern_packages()], cwd=cwd)
        return

    raise ValueError(f"Unsupported template: {template}")


def generate_project(
    target_dir: Path,
    template: str,
    torch_backend: str,
    openmedaxis_version: str | None,
) -> None:
    if target_dir.exists():
        raise FileExistsError(f"Target directory already exists: {target_dir}")

    project_name = target_dir.name
    package_name = _normalize_package_name(project_name)
    oma_dep = _resolve_openmedaxis_dependency(openmedaxis_version)

    context = {
        "project_name": project_name,
        "package_name": package_name,
        "uv_torch_block": _uv_torch_block(torch_backend),
    }

    template_root = Path(files("openmedaxis_init").joinpath("templates/base"))
    target_dir.mkdir(parents=True, exist_ok=False)

    _copy_template_tree(template_root, target_dir, context)

    print(f"[1/4] Project created at: {target_dir}")
    print("[2/4] Creating project environment...")
    _run(["uv", "sync", "--python", "3.11"], cwd=target_dir)

    print(f"[3/4] Installing template '{template}' with torch backend '{torch_backend}'...")
    _install_template_stack(
        cwd=target_dir,
        template=template,
        openmedaxis_dependency=oma_dep,
    )

    print("[4/4] Running smoke test...")
    _run(
        [
            "uv",
            "run",
            "python",
            "-c",
            (
                "import sys, importlib.metadata as m, torch; "
                "print('Python:', sys.version); "
                "print('OpenMedAxis:', m.version('openmedaxis')); "
                "print('Torch:', torch.__version__); "
                "print('CUDA available:', torch.cuda.is_available()); "
                "print('CUDA version:', torch.version.cuda)"
            ),
        ],
        cwd=target_dir,
    )

    print("\nDone.")
    print(f"Next:\n  cd {project_name}\n  uv run python -m {package_name}.train")