import argparse
from pathlib import Path

from openmedaxis_init.generator import generate_project


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="openmedaxis-init",
        description="Create a new OpenMedAxis project.",
    )
    parser.add_argument("name", help="Project folder name")

    parser.add_argument(
        "--template",
        choices=["modern"],
        default="modern",
        help="Project template to use.",
    )

    parser.add_argument(
        "--torch-backend",
        choices=["cu118", "cpu"],
        default="cu118",
        help="Torch backend to configure.",
    )

    parser.add_argument(
        "--oma",
        help="OpenMedAxis version. Default: latest",
    )

    args = parser.parse_args()

    target_dir = Path(args.name).resolve()
    generate_project(
        target_dir=target_dir,
        template=args.template,
        torch_backend=args.torch_backend,
        openmedaxis_version=args.oma,
    )