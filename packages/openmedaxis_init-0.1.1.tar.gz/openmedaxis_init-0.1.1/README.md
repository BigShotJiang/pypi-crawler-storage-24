# openmedaxis-init

Project scaffolder for OpenMedAxis.