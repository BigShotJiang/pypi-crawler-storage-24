from datetime import timedelta
from io import BytesIO
from typing import Dict, Iterator, List, Optional

from minio import Minio
from minio.error import S3Error
from urllib3 import BaseHTTPResponse

from sneakydog_object_storage_service.base import ObjectInfo, StorageBackend, StorageConfig
from sneakydog_object_storage_service.exceptions import (
    ConfigError,
    DownloadError,
    ObjectNotFoundError,
    UploadError,
)


class MinIOStorage(StorageBackend):
    """MinIO/S3 存储 (MinIO SDK 实现)"""

    def __init__(self, config: StorageConfig):
        super().__init__(config)
        cfg = config.config

        access_key = cfg.get("access_key")
        secret_key = cfg.get("secret_key")
        endpoint = cfg.get("endpoint")
        secure = cfg.get("secure", True)

        if not access_key or not secret_key:
            raise ConfigError("MinIO requires access_key and secret_key")

        # 创建 MinIO 客户端
        self.client = Minio(
            endpoint=endpoint,
            access_key=access_key,
            secret_key=secret_key,
            secure=secure,
        )

        self.bucket_name = cfg.get("bucket_name")

        # 可选：自动创建 bucket
        if cfg.get("create_bucket_if_not_exists", False):
            if not self.client.bucket_exists(self.bucket_name):
                self.client.make_bucket(self.bucket_name)

    # ========== 上传 / 下载 ==========

    def put_object(
        self,
        key: str,
        bytes_data,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        try:
            self.client.put_object(
                bucket_name=self.bucket_name,
                object_name=key,
                data=BytesIO(bytes_data),
                length=len(bytes_data),
                content_type=content_type,
                metadata=metadata,
            )
            return True
        except S3Error as e:
            raise UploadError(f"MinIO upload failed: {str(e)}")

    def get_object(self, key: str) -> bytes:
        try:
            response: BaseHTTPResponse = self.client.get_object(self.bucket_name, key)
            with response:
                return response.read()
        except S3Error as e:
            if e.code == "NoSuchKey":
                raise ObjectNotFoundError(f"Object not found: {key}")
            else:
                raise DownloadError(f"MinIO download failed: {str(e)}")

    def get_object_stream(self, key: str, chunk_size: int = 8 * 1024) -> Iterator[bytes]:
        response = None
        try:
            response = self.client.get_object(self.bucket_name, key)
            yield from response.stream(chunk_size)
        except S3Error as e:
            if e.code == "NoSuchKey":
                return
            raise
        finally:
            if response:
                response.close()
                response.release_conn()

    def delete(self, key: str) -> bool:
        try:
            self.client.remove_object(self.bucket_name, key)
            return True
        except S3Error as e:
            raise Exception(f"MinIO delete failed: {str(e)}")

    def exists(self, key: str) -> bool:
        try:
            self.client.stat_object(self.bucket_name, key)
            return True
        except S3Error:
            return False

    def list_objects(self, prefix: Optional[str] = None, max_keys: int = 1000) -> List[ObjectInfo]:
        objects = []
        try:
            for obj in self.client.list_objects(
                self.bucket_name, prefix=prefix or "", recursive=True
            ):
                objects.append(
                    ObjectInfo(
                        key=obj.object_name,
                        size=obj.size,
                        last_modified=obj.last_modified,
                        etag=obj.etag,
                        content_type=None,
                    )
                )
                if len(objects) >= max_keys:
                    break
        except S3Error as e:
            raise Exception(f"MinIO list failed: {str(e)}")
        return objects

    def get_object_info(self, key: str) -> ObjectInfo:
        try:
            obj_stat = self.client.stat_object(self.bucket_name, key)
            return ObjectInfo(
                key=key,
                size=obj_stat.size,
                last_modified=obj_stat.last_modified,
                etag=obj_stat.etag,
                content_type=obj_stat.content_type,
                metadata=obj_stat.metadata,
            )
        except S3Error as e:
            if e.code == "NoSuchKey":
                raise ObjectNotFoundError(f"Object not found: {key}")
            else:
                raise Exception(f"MinIO stat failed: {str(e)}")

    def presigned_url(self, key: str, expires_in: timedelta = timedelta(days=7)) -> str:
        try:
            return self.client.presigned_get_object(self.bucket_name, key, expires=expires_in)
        except S3Error as e:
            raise Exception(f"MinIO presigned URL failed: {str(e)}")

    # ========== 分片上传 ==========

    def initiate_multipart_upload(
        self,
        key: str,
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> str:
        try:
            upload_id = self.client._create_multipart_upload(
                self.bucket_name, key, content_type=content_type, metadata=metadata
            )
            return upload_id
        except S3Error as e:
            raise UploadError(f"MinIO initiate multipart failed: {str(e)}")

    def upload_part(self, key: str, upload_id: str, part_number: int, bytes_data) -> str:
        try:
            etag = self.client._upload_part(
                self.bucket_name, key, upload_id, part_number, BytesIO(bytes_data), len(bytes_data)
            )
            return etag
        except S3Error as e:
            raise UploadError(f"MinIO upload part failed: {str(e)}")

    def complete_multipart_upload(self, key: str, upload_id: str, parts: list) -> str:
        try:
            multipart_info = {
                "Parts": [{"PartNumber": p["part_number"], "ETag": p["etag"]} for p in parts]
            }
            etag = self.client._complete_multipart_upload(
                self.bucket_name, key, upload_id, multipart_info
            )
            return etag
        except S3Error as e:
            raise UploadError(f"MinIO complete multipart failed: {str(e)}")

    def abort_multipart_upload(self, key: str, upload_id: str) -> bool:
        try:
            self.client._abort_multipart_upload(self.bucket_name, key, upload_id)
            return True
        except S3Error as e:
            raise Exception(f"MinIO abort multipart failed: {str(e)}")
