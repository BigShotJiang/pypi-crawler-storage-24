from datetime import datetime, timedelta
from pathlib import Path
from typing import Iterator, Optional

from sneakydog_object_storage_service.base import ObjectInfo, StorageBackend, StorageConfig
from sneakydog_object_storage_service.exceptions import ObjectNotFoundError, PermissionDeniedError


class LocalStorage(StorageBackend):
    """本地文件存储"""

    def __init__(self, config: StorageConfig):
        super().__init__(config)
        self.root_path = Path(config.config.get("root_path", "./storage"))
        self.root_path.mkdir(parents=True, exist_ok=True)

    def _get_full_path(self, key: str) -> Path:
        """获取完整路径"""
        # 防止路径遍历攻击
        key = key.lstrip("/")
        full_path = (self.root_path / key).resolve()
        if not str(full_path).startswith(str(self.root_path.resolve())):
            raise PermissionDeniedError(f"Invalid path: {key}")
        return full_path

    def put_object(
        self,
        key: str,
        data: bytes,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        """上传文件"""
        try:
            path = self._get_full_path(key)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "wb") as f:
                f.write(data)

            # 保存元数据 (可选)
            if metadata:
                meta_path = path.with_suffix(path.suffix + ".meta")
                import json

                with open(meta_path, "w") as f:
                    json.dump(metadata, f)

            return True
        except Exception as e:
            raise Exception(f"Upload failed: {str(e)}")

    def get_object(self, key: str) -> bytes:
        """下载文件"""
        path = self._get_full_path(key)
        if not path.exists():
            raise ObjectNotFoundError(f"Object not found: {key}")
        with open(path, "rb") as f:
            return f.read()

    def get_object_stream(self, key, chunk_size: int = 8 * 1024) -> Iterator[bytes]:
        path = self._get_full_path(key)
        with open(path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                yield chunk

    def delete(self, key: str) -> bool:
        """删除文件"""
        path = self._get_full_path(key)
        if not path.exists():
            raise ObjectNotFoundError(f"Object not found: {key}")
        path.unlink()

        # 删除元数据文件
        meta_path = path.with_suffix(path.suffix + ".meta")
        if meta_path.exists():
            meta_path.unlink()

        return True

    def exists(self, key: str) -> bool:
        """检查文件是否存在"""
        path = self._get_full_path(key)
        return path.exists() and path.is_file()

    def list_objects(self, prefix: Optional[str] = None, max_keys: int = 1000) -> list[ObjectInfo]:
        """列出对象"""
        objects = []
        search_path = self.root_path / prefix if prefix else self.root_path

        for path in search_path.rglob("*"):
            if path.is_file() and not path.name.endswith(".meta"):
                try:
                    rel_path = path.relative_to(self.root_path)
                    stat = path.stat()
                    objects.append(
                        ObjectInfo(
                            key=str(rel_path),
                            size=stat.st_size,
                            last_modified=datetime.fromtimestamp(stat.st_mtime),
                            content_type=None,
                        )
                    )
                    if len(objects) >= max_keys:
                        break
                except Exception:
                    continue

        return objects

    def get_object_info(self, key: str) -> ObjectInfo:
        """获取对象元信息"""
        path = self._get_full_path(key)
        if not path.exists():
            raise ObjectNotFoundError(f"Object not found: {key}")

        stat = path.stat()
        return ObjectInfo(
            key=key,
            size=stat.st_size,
            last_modified=datetime.fromtimestamp(stat.st_mtime),
            content_type=None,
        )

    def presigned_url(self, key: str, expires_in: timedelta = timedelta(days=7)) -> str:
        """本地存储不支持预签名 URL，返回 file:// 路径"""
        path = self._get_full_path(key)
        return f"file://{path.absolute()}"
