# x402-gateway

Hosted payment gateway middleware for the x402 protocol. Drop-in USDC billing for APIs.

**Status:** In development. Package name reserved.

Coming soon from [SynthInsight Labs](https://synthinsightlabs.com).
