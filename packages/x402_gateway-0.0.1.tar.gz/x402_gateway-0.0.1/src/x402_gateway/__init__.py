"""x402-gateway: Hosted payment gateway for the x402 protocol."""

__version__ = "0.0.1"
