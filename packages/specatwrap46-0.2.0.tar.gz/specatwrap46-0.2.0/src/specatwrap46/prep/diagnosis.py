"""
Diagnosis filter classes.

This module provides filter classes for preprocessing diagnosis parquet files.
"""

from abc import ABC, abstractmethod
import polars as pl


class BaseFilter(ABC):
    """
    Abstract base class for parquet file filters.

    Each filter type (diagnosis, procedure, medication, etc.) should inherit
    from this class and implement the apply() method with their specific
    filtering and transformation logic.
    """

    @abstractmethod
    def apply(self, lf: pl.LazyFrame) -> pl.LazyFrame:
        """
        Apply filtering and preprocessing logic to a LazyFrame.

        Args:
            lazy_frame: Input Polars LazyFrame to filter/transform

        Returns:
            Transformed Polars LazyFrame
        """
        pass

    def get_name(self) -> str:
        """
        Get the name of this filter type.

        Returns:
            Filter type name (defaults to class name without 'Filter' suffix)
        """
        class_name = self.__class__.__name__
        if class_name.endswith("Filter"):
            return class_name[:-6].lower()
        return class_name.lower()


class DiagnosisFilter(BaseFilter):
    """
    Filter for diagnosis parquet files.

    Applies diagnosis-specific filtering and column transformations:
    - Filters by birthdate (year > 1980)
    - Filters by region (Region Sjælland)
    - Renames columns to standardized event log format
    """

    CASE_ATTR = {
        k: f"case:{v}"
        for k, v in {
            "BORGER_FOEDSELSDATO": "BDay",
            "PNR": "PNR",
            "BORGER_KOEN": "gender"
        }.items()
    }

    EVENT_ATTR = {
        "TORRA_DIAG": "TDiag",
        "ADIAG": "ADiag",
        "ADIAG_TEKST": "diagText",
        "KONT_ANS_GEO_REG_TEKST": "region",
        "KONT_LPR_ENTITY_ID": "org:id",
        "KONT_INST_EJERTYPE": "org:type",
        "KONT_STARTTIDSPUNKT": "startTime",
        "KONT_SLUTTIDSPUNKT": "endTime",
        # "BORGER_ALDER_AAR_IND": "patient:age",
        "PRIORITET_TEKST": "priority",
        "KONT_TYPE_TEKST": "contact_type",
    }

    def apply(self, lf: pl.LazyFrame) -> pl.LazyFrame:
        """
        Apply diagnosis-specific filtering and transformations.

        Args:
            lazy_frame: Input LazyFrame containing diagnosis data

        Returns:
            Filtered and transformed LazyFrame
        """

        lf = self._add_torra_diag(lf)

        return (
            lf.filter(pl.col("TORRA_DIAG").list.len() > 0)
            .with_columns(pl.col("TORRA_DIAG").list.join(", "))
            .select(list((self.CASE_ATTR | self.EVENT_ATTR).keys()))
            .rename(self.CASE_ATTR | self.EVENT_ATTR)
        )

    def _add_torra_diag(self, lazy_frame: pl.LazyFrame) -> pl.LazyFrame:
        col = pl.col("ADIAG")

        def starts_with(prefixes: list[str], label: str) -> pl.Expr:
            pattern = f"^(?:{'|'.join(prefixes)})"
            return (
                pl.when(col.str.contains(pattern))
                .then(pl.lit(label))
                .otherwise(pl.lit(None))
            )

        return lazy_frame.with_columns(
            TORRA_DIAG=pl.concat_list(
                [
                    starts_with(
                        ["DJ41", "DJ42", "DJ43", "DJ44", "DJ45", "DJ46"], "LUNG"
                    ),
                    starts_with(
                        [
                            "DL405",
                            "DM05",
                            "DM06",
                            "DM07",
                            "DM15",
                            "DM16",
                            "DM17",
                            "DM45",
                            "DM47",
                            "DM50",
                            "DM51",
                            "DM53",
                            "DM54",
                            "DM80",
                            "DM81",
                            "DM82",
                        ],
                        "MUSCULOSKELETAL",
                    ),
                    starts_with(
                        ["DE03", "DE05", "DE10", "DE11", "DE12", "DE13", "DE14"],
                        "ENDOCRINE",
                    ),
                    starts_with(["DE03", "DE05"], "THYROIDEA"),
                    starts_with(["DE10", "DE11", "DE12", "DE13", "DE14"], "DIABETES"),
                    starts_with(["DG30", "DG318", "DG319", "DF"], "MENTAL"),
                    # CANCER: Matches DC but explicitly excludes DC44
                    pl.when(col.str.contains("^DC") & ~col.str.contains("^DC44"))
                    .then(pl.lit("CANCER"))
                    .otherwise(pl.lit(None)),
                    starts_with(
                        [
                            "DI60",
                            "DI61",
                            "DI62",
                            "DI63",
                            "DI64",
                            "DI69",
                            "DG20",
                            "DG35",
                            "DG40",
                            "DG43",
                        ],
                        "NEUROLOGICAL",
                    ),
                    starts_with(
                        [
                            "DK30",
                            "DK50",
                            "DK51",
                            "DK58",
                            "DK70",
                            "DK71",
                            "DK72",
                            "DK73",
                            "DK74",
                            "DK75",
                            "DK76",
                            "DK860",
                            "DK861",
                        ],
                        "GASTROINTESTINAL",
                    ),
                    starts_with(
                        [
                            "DI20",
                            "DI21",
                            "DI22",
                            "DI23",
                            "DI24",
                            "DI25",
                            "DI47",
                            "DI48",
                            "DI49",
                            "DI50",
                            "DI05",
                            "DI06",
                            "DI07",
                            "DI08",
                            "DI34",
                            "DI35",
                            "DI36",
                            "DI37",
                            "DI441",
                            "DI442",
                            "DI443",
                            "DI444",
                            "DI445",
                            "DI446",
                            "DI447",
                            "DI452",
                            "DI453",
                            "DI454",
                            "DI455",
                            "DI456",
                            "DI457",
                            "DI458",
                            "DI459",
                        ],
                        "CARDIOVASCULAR",
                    ),
                    starts_with(
                        [
                            "DN03",
                            "DN04",
                            "DN05",
                            "DN11",
                            "DN12",
                            "DN18",
                            "DN19",
                            "DZ49",
                            "DN80",
                            "DZ992",
                            "DN393",
                            "DN394",
                        ],
                        "GENITURINARY",
                    ),
                    starts_with(
                        [
                            "DH40",
                            "DH91",
                            "DL40",
                            "DH540",
                            "DH541",
                            "DH542",
                            "DH543",
                            "DH547",
                            "DH900",
                            "DH902",
                            "DH903",
                            "DH905",
                            "DH906",
                            "DH908",
                        ],
                        "SENSORY ORGANS",
                    ),
                    starts_with(
                        ["DL23", "DL24", "DL25", "DJ30", "DL500", "DJ450"], "ALLERGY"
                    ),
                ]
            ).list.drop_nulls()
        )

    def print_torra_diag_method(self) -> None:
        """Print the _add_torra_diag method to stdout."""
        method_code = """    def _add_torra_diag(self, lazy_frame: pl.LazyFrame) -> pl.LazyFrame:
        col = pl.col("ADIAG")

        def starts_with(prefixes: list[str], label: str) -> pl.Expr:
            pattern = f"^(?:{'|'.join(prefixes)})"
            return (
                pl.when(col.str.contains(pattern))
                .then(pl.lit(label))
                .otherwise(pl.lit(None))
            )

        return lazy_frame.with_columns(
            TORRA_DIAG=pl.concat_list(
                [
                    starts_with(
                        ["DJ41", "DJ42", "DJ43", "DJ44", "DJ45", "DJ46"], "LUNG"
                    ),
                    starts_with(
                        [
                            "DL405",
                            "DM05",
                            "DM06",
                            "DM07",
                            "DM15",
                            "DM16",
                            "DM17",
                            "DM45",
                            "DM47",
                            "DM50",
                            "DM51",
                            "DM53",
                            "DM54",
                            "DM80",
                            "DM81",
                            "DM82",
                        ],
                        "MUSCULOSKELETAL",
                    ),
                    starts_with(
                        ["DE03", "DE05", "DE10", "DE11", "DE12", "DE13", "DE14"],
                        "ENDOCRINE",
                    ),
                    starts_with(["DE03", "DE05"], "THYROIDEA"),
                    starts_with(["DE10", "DE11", "DE12", "DE13", "DE14"], "DIABETES"),
                    starts_with(["DG30", "DG318", "DG319", "DF"], "MENTAL"),
                    # CANCER: Matches DC but explicitly excludes DC44
                    pl.when(col.str.contains("^DC") & ~col.str.contains("^DC44"))
                    .then(pl.lit("CANCER"))
                    .otherwise(pl.lit(None)),
                    starts_with(
                        [
                            "DI60",
                            "DI61",
                            "DI62",
                            "DI63",
                            "DI64",
                            "DI69",
                            "DG20",
                            "DG35",
                            "DG40",
                            "DG43",
                        ],
                        "NEUROLOGICAL",
                    ),
                    starts_with(
                        [
                            "DK30",
                            "DK50",
                            "DK51",
                            "DK58",
                            "DK70",
                            "DK71",
                            "DK72",
                            "DK73",
                            "DK74",
                            "DK75",
                            "DK76",
                            "DK860",
                            "DK861",
                        ],
                        "GASTROINTESTINAL",
                    ),
                    starts_with(
                        [
                            "DI20",
                            "DI21",
                            "DI22",
                            "DI23",
                            "DI24",
                            "DI25",
                            "DI47",
                            "DI48",
                            "DI49",
                            "DI50",
                            "DI05",
                            "DI06",
                            "DI07",
                            "DI08",
                            "DI34",
                            "DI35",
                            "DI36",
                            "DI37",
                            "DI441",
                            "DI442",
                            "DI443",
                            "DI444",
                            "DI445",
                            "DI446",
                            "DI447",
                            "DI452",
                            "DI453",
                            "DI454",
                            "DI455",
                            "DI456",
                            "DI457",
                            "DI458",
                            "DI459",
                        ],
                        "CARDIOVASCULAR",
                    ),
                    starts_with(
                        [
                            "DN03",
                            "DN04",
                            "DN05",
                            "DN11",
                            "DN12",
                            "DN18",
                            "DN19",
                            "DZ49",
                            "DN80",
                            "DZ992",
                            "DN393",
                            "DN394",
                        ],
                        "GENITURINARY",
                    ),
                    starts_with(
                        [
                            "DH40",
                            "DH91",
                            "DL40",
                            "DH540",
                            "DH541",
                            "DH542",
                            "DH543",
                            "DH547",
                            "DH900",
                            "DH902",
                            "DH903",
                            "DH905",
                            "DH906",
                            "DH908",
                        ],
                        "SENSORY ORGANS",
                    ),
                    starts_with(
                        ["DL23", "DL24", "DL25", "DJ30", "DL500", "DJ450"], "ALLERGY"
                    ),
                ]
            ).list.drop_nulls()
        )"""
        print(method_code)
