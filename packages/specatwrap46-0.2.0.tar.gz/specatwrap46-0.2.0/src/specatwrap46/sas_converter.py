"""
SAS to Parquet converter module.

This module provides functionality to convert large SAS7BDAT files to Parquet format
in a memory-efficient way by processing the data in chunks.
"""

import sys
import time
from pathlib import Path
from typing import Optional
import shutil
import click
import pyreadstat
import polars as pl


# Table-specific column mappings
TABLE_TYPE_COLUMNS = {
    "diagnosis": [
        "BORGER_FOEDSELSDATO",
        "PNR",
        "ADIAG",
        "ADIAG_TEKST",
        "KONT_ANS_GEO_REG_TEKST",
        "KONT_LPR_ENTITY_ID",
        "KONT_INST_EJERTYPE",
        "KONT_STARTTIDSPUNKT",
        "KONT_SLUTTIDSPUNKT",
        "PRIORITET_TEKST",
        "KONT_TYPE_TEKST",
        "BORGER_KOEN"
    ],
}


def convert_sas_to_parquet(
    input_file: Path,
    output_path: Path,
    chunk_size: int = 100000,
    compression: str = "zstd",
    encoding: Optional[str] = None,
    overwrite: bool = False,
    verbose: bool = False,
    cols: Optional[list[str]] = None,
):
    """
    Convert a SAS7BDAT file to Parquet format in chunks.

    Parameters
    ----------
    input_file : Path
        Path to the SAS file (.sas7bdat)
    output_path : Path
        Path to output directory for Parquet files
    chunk_size : int, optional
        Number of rows to read per chunk (default: 100000)
    compression : str, optional
        Parquet compression algorithm (default: 'zstd')
    encoding : str, optional
        File encoding (default: auto-detect)
    overwrite : bool, optional
        Whether to overwrite existing output directory (default: False)
    verbose : bool, optional
        Enable verbose output (default: False)
    cols : list[str], optional
        List of columns to read from the SAS file (default: None, reads all columns)

    Raises
    ------
    FileNotFoundError
        If the input file does not exist
    ValueError
        If the input file is not a .sas7bdat file or output path is invalid
    PermissionError
        If there are permission issues with files/directories
    MemoryError
        If there's insufficient memory (suggest smaller chunk_size)
    """
    # Validate input file
    if not input_file.exists():
        click.secho(f"✗ Error: Input file not found: {input_file}", fg="red", err=True)
        sys.exit(1)

    if input_file.suffix.lower() != ".sas7bdat":
        click.secho("✗ Error: Input file must be a .sas7bdat file", fg="red", err=True)
        sys.exit(1)

    # Handle output directory
    output_path = Path(output_path)

    if output_path.exists():
        if not output_path.is_dir():
            click.secho(
                f"✗ Error: Output path exists and is not a directory: {output_path}",
                fg="red",
                err=True,
            )
            sys.exit(1)

        if overwrite:
            if verbose:
                click.echo(f"Removing existing directory: {output_path}")
            shutil.rmtree(output_path)
            output_path.mkdir(parents=True, exist_ok=True)
        else:
            # Check if directory has parquet files
            existing_parquet = list(output_path.glob("*.parquet"))
            if existing_parquet:
                click.secho(
                    f"⚠ Warning: Output directory already contains {len(existing_parquet)} .parquet file(s)",
                    fg="yellow",
                )
                if not click.confirm(
                    "Do you want to continue and potentially mix files?"
                ):
                    click.echo("Aborted.")
                    sys.exit(0)
    else:
        output_path.mkdir(parents=True, exist_ok=True)

    # Display processing information
    click.echo(f"Processing: {input_file}")
    click.echo(f"Output directory: {output_path}")
    if verbose:
        click.echo(f"Chunk size: {chunk_size:,} rows")
        click.echo(f"Compression: {compression}")
        click.echo(f"Encoding: {encoding if encoding else 'auto-detect'}")
    click.echo()

    # Process file in chunks
    click.echo("Converting SAS to Parquet...")

    reader = pyreadstat.read_file_in_chunks(
        pyreadstat.read_sas7bdat,
        str(input_file),
        chunksize=chunk_size,
        encoding=encoding,
        output_format="polars",
        usecols=cols,
    )

    chunk_num = 0
    total_rows = 0
    num_columns = 0

    chunk_start_time = time.time()
    for df_polars, meta in reader:
        # Generate chunk filename with zero-padded numbering
        chunk_filename = f"chunk_{chunk_num:04d}.parquet"
        chunk_path = output_path / chunk_filename

        # Write chunk to parquet
        df_polars.write_parquet(chunk_path, compression=compression)

        # Calculate elapsed time
        chunk_elapsed_time = time.time() - chunk_start_time

        # Update statistics
        chunk_rows = len(df_polars)
        total_rows += chunk_rows
        num_columns = len(meta.column_names)
        chunk_num += 1

        if verbose:
            click.echo(
                f"  Wrote chunk {chunk_num}: {chunk_rows:,} rows → {chunk_filename} (took {chunk_elapsed_time:.2f}s)"
            )
        else:
            click.echo(
                f"  Wrote chunk {chunk_num}: {chunk_rows:,} rows → {chunk_filename} (took {chunk_elapsed_time:.2f}s)"
            )
        chunk_start_time = time.time()

    # Calculate file sizes
    input_size = input_file.stat().st_size / (1024 * 1024)  # MB
    output_files = list(output_path.glob("*.parquet"))
    output_size = sum(f.stat().st_size for f in output_files) / (1024 * 1024)  # MB
    compression_ratio = input_size / output_size if output_size > 0 else 0

    # Display success message
    click.echo()
    click.secho("✓ Conversion completed successfully!", fg="green", bold=True)
    click.echo(f"Input file:      {input_size:.2f} MB ({input_file.name})")
    click.echo(f"Output files:    {output_size:.2f} MB ({len(output_files)} chunks)")
    click.echo(f"Compression:     {compression_ratio:.2f}x")
    click.echo(f"Total rows:      {total_rows:,}")
    click.echo(f"Columns:         {num_columns}")
    click.echo(f"Chunk size:      {chunk_size:,} rows/chunk")
    click.echo()
    click.echo("To read the data:")
    click.echo(f"  import polars as pl")
    click.echo(f"  df = pl.read_parquet('{output_path}/*.parquet')")


@click.command()
@click.argument("input_file", type=click.Path(exists=True, path_type=Path))
@click.argument("output_path", type=click.Path(path_type=Path))
@click.option(
    "--table-type",
    type=click.Choice(["diagnosis"], case_sensitive=False),
    default=None,
    help="Type of table to process (determines which columns to extract). If not specified, all columns are read.",
)
@click.option(
    "-c",
    "--chunk-size",
    type=int,
    default=100000,
    help="Number of rows to read per chunk (default: 100000)",
)
@click.option(
    "--compression",
    type=click.Choice(["zstd", "lz4", "snappy", "gzip"], case_sensitive=False),
    default="zstd",
    help="Parquet compression algorithm (default: zstd)",
)
@click.option(
    "--encoding",
    type=str,
    default=None,
    help="File encoding (default: auto-detect)",
)
@click.option(
    "--overwrite",
    is_flag=True,
    default=False,
    help="Overwrite existing output directory if it exists",
)
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose output")
def sas2parquet(
    input_file,
    output_path,
    table_type,
    chunk_size,
    compression,
    encoding,
    overwrite,
    verbose,
):
    """
    Convert a SAS file to Parquet format in chunks.

    INPUT_FILE: Path to the SAS file (.sas7bdat)

    OUTPUT_PATH: Path to output directory for Parquet files

    This command processes large SAS files in chunks to minimize memory usage.
    Each chunk is written to a separate Parquet file in the output directory.

    Example usage:

        specatwrap sas2parquet input.sas7bdat output_dir/ --table-type diagnosis

        specatwrap sas2parquet input.sas7bdat output_dir/ --chunk-size 50000 -v

        specatwrap sas2parquet input.sas7bdat output_dir/ --table-type diagnosis --compression lz4

    Reading the data later with Polars:

        import polars as pl

        df = pl.read_parquet("output_dir/*.parquet")
    """
    # Get columns for the specified table type (None means all columns)
    cols = TABLE_TYPE_COLUMNS.get(table_type.lower()) if table_type else None

    try:
        convert_sas_to_parquet(
            input_file=input_file,
            output_path=output_path,
            chunk_size=chunk_size,
            compression=compression,
            encoding=encoding,
            overwrite=overwrite,
            verbose=verbose,
            cols=cols,
        )
    except FileNotFoundError as e:
        click.secho(f"✗ Error: File not found - {e}", fg="red", err=True)
        sys.exit(1)
    except PermissionError as e:
        click.secho(f"✗ Error: Permission denied - {e}", fg="red", err=True)
        sys.exit(1)
    except ValueError as e:
        click.secho(f"✗ Error: Invalid input - {e}", fg="red", err=True)
        sys.exit(1)
    except MemoryError:
        click.secho(
            f"✗ Error: Out of memory. Try a smaller --chunk-size", fg="red", err=True
        )
        sys.exit(1)
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg="red", err=True)
        if verbose:
            import traceback

            traceback.print_exc()
        sys.exit(1)
