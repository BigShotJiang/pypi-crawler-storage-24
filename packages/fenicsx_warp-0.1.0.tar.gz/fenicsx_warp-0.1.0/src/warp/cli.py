def main():
    parser = argparse.ArgumentParser(
        description="Warp a template mesh to a target PCA shape from the UK Biobank atlas."
    )

    parser.add_argument(
        "--template", type=str, default="data-mean/ED.msh", help="Path to the template .msh file."
    )
    parser.add_argument(
        "--output", type=str, default="warped_mesh.xdmf", help="Path to save the output .xdmf file."
    )
    parser.add_argument("--mode", type=int, default=1, help="PCA mode to apply.")
    parser.add_argument(
        "--std", type=float, default=1.5, help="Standard deviation multiplier for the PCA mode."
    )
    parser.add_argument(
        "--interp", choices=["rbf", "kdtree"], default="rbf", help="Interpolation method."
    )
    parser.add_argument(
        "--solver",
        choices=["hyperelastic", "laplace"],
        default="hyperelastic",
        help="PDE solver method.",
    )
    parser.add_argument(
        "--cache-dir", type=str, default=str(Path.home() / ".ukb"), help="Directory for atlas data."
    )
    parser.add_argument("--all", action="store_true", help="Use the 'all subjects' PCA atlas.")

    args = parser.parse_args()

    # 1. Load the Atlas Coordinate Data
    print("Loading atlas data...")
    cache_dir = Path(args.cache_dir)
    filename = download_atlas(cache_dir, all=args.all)

    pts_mean = generate_points(filename, mode=-1).ED
    pts_target = generate_points(filename, mode=args.mode, std=args.std).ED

    # 2. Load the Template Mesh
    print(f"Loading template mesh from {args.template}...")
    try:
        my_domain, _, _ = io.gmshio.read_from_msh(args.template, MPI.COMM_WORLD, 0, gdim=3)
    except Exception as e:
        print(f"Error loading mesh: {e}")
        sys.exit(1)

    # 3. Warp the Mesh
    warped_domain = warp_mesh(
        domain=my_domain,
        points_mean=pts_mean,
        points_target=pts_target,
        interp_method=args.interp,
        solver_method=args.solver,
    )

    # 4. Save the Warped Mesh
    print(f"Saving warped mesh to {args.output}...")
    with io.XDMFFile(warped_domain.comm, args.output, "w") as xdmf:
        xdmf.write_mesh(warped_domain)

    print("Done!")


if __name__ == "__main__":
    main()
