# Changelog

## [0.9.0](https://github.com/noshita/ktch/compare/v0.8.1...v0.9.0) (2026-03-24)


### ⚠ BREAKING CHANGES

* **io:** ✨ return dataclass from read_chc and read_tps
* 

### Features

* ✨  add component_std parameter and improve API consistency ([a7c6ad5](https://github.com/noshita/ktch/commit/a7c6ad5fbc3a58199170883e612450bbd08b2101))
* ✨ add DiskHarmonicAnalysis class ([5847f60](https://github.com/noshita/ktch/commit/5847f60bed6b17badce7ef6c890b352f8b5797ad))
* ✨ add private OFF file parser for mesh datasets ([eb1aa5a](https://github.com/noshita/ktch/commit/eb1aa5aa7d66851e2c3aa6a32e671d42aa880699))
* ✨ add surface_leaf_bending dataset ([88b830e](https://github.com/noshita/ktch/commit/88b830e41e3143cef68c49d54125762241de36bc))
* ✨ area-based normalization of 2D EFA ([13e8f7f](https://github.com/noshita/ktch/commit/13e8f7f7f06ba4d11370e9b1115b56ebf7a90cec)), closes [#138](https://github.com/noshita/ktch/issues/138)
* ✨ confidence_ellipse_plot and convex_hull_plot ([722153f](https://github.com/noshita/ktch/commit/722153f191233cc4e071809153599ec470dbc392))
* **io:** ✨ add I/O for .nef file ([294bf3d](https://github.com/noshita/ktch/commit/294bf3d0cabba645e94854f5686e2da6802b5e7f))
* **io:** ✨ add MorphoData protocol and standardize data containers ([85f82d2](https://github.com/noshita/ktch/commit/85f82d21e440258e1d986e72391cd9822155c54d))
* **io:** ✨ return dataclass from read_chc and read_tps ([3d18190](https://github.com/noshita/ktch/commit/3d18190f874031bef59289466d0e0440c6a0e6ed))
* remove deprecated APIs and require NumPy&gt;=2.0, pandas&gt;=3.0 for v0.9 ([d6dc2c2](https://github.com/noshita/ktch/commit/d6dc2c2b36d59e19c36d54090cfb40be33c4aea6))


### Bug Fixes

* 🐛  TPS grid bounding box ([b9780c3](https://github.com/noshita/ktch/commit/b9780c3e65925ad139d66c694b11644dde1ff654))
* 🐛 add input validation and improve error messages ([df39891](https://github.com/noshita/ktch/commit/df39891aa9126ba5cf18d3e0b2f0f5863b23011e))
* 🐛 degeneration when area_per_pixel = 0 ([561179d](https://github.com/noshita/ktch/commit/561179d9fb96c33c975adc36d97bd47bc0ea1c98))
* 🐛 fix ChainCodeData monkey-patch and __all__ recursion bug ([d9f1e25](https://github.com/noshita/ktch/commit/d9f1e25bb2caddf7dbc9c64c2ea80624de837997))
* 🐛 fix float equality in pole detection and dataclass semantics ([4ed8441](https://github.com/noshita/ktch/commit/4ed844109d860f927755c965b8c8abcf6eaa3ba3))
* 🐛 I/O validation ([eb42f2f](https://github.com/noshita/ktch/commit/eb42f2f38f762c036560d52dd947dcd23dd6782a))
* 🐛 improve numerical robustness, input validation, and convergence safety ([5f7a0be](https://github.com/noshita/ktch/commit/5f7a0bed2361e56472b228000c7195cf5f7aa0de))
* **docs:** 🐛 add stable version fallback and update release procedure ([f6d1210](https://github.com/noshita/ktch/commit/f6d12103e76c71e797512dfb5c1af274e9724577))
* **docs:** 🐛 fix SEO issues preventing Google Search Console indexing ([275d625](https://github.com/noshita/ktch/commit/275d625dbd260b6c7c218b15cd9b8be648e89a9e))


### Documentation

* 📚  reorganize development documentation ([c9db6c3](https://github.com/noshita/ktch/commit/c9db6c352437a4382e6ce11c239284df45df68a8))
* 📚 add Disk Harmonic Analysis tutorial ([ac51a30](https://github.com/noshita/ktch/commit/ac51a305d85fd5c88fe983dc16d691ba773b87c0))
* 📚 exclude low-value pages from sitemap and add noindex ([8e1558c](https://github.com/noshita/ktch/commit/8e1558cc86d034303f22e605652b1d8b6a2fcd4d))
* 📚 improve how-to for visualization ([4445f9d](https://github.com/noshita/ktch/commit/4445f9d12b02f2325a03c2110e4a2c8dc3d76cf5))
* 📚 update CONTRIBUTING.md ([cb49c26](https://github.com/noshita/ktch/commit/cb49c26c3fe5021b657fa3d58489c9d3a81364a0))
* 📚 update versions.json for v0.8.1 ([579a7b4](https://github.com/noshita/ktch/commit/579a7b492f2ba40cf038261ccf225069fdb9f061))


### Miscellaneous Chores

* 🔧  improve CI ([6a84182](https://github.com/noshita/ktch/commit/6a841823337b3bd98304be934431bd6a6a69c9e1))
* 🔧 improve verbose output and migrate tests to default_rng ([bbb84b9](https://github.com/noshita/ktch/commit/bbb84b91158c733003073f45676288209ef8196d))
* 🔧 raise numpy lower bound from 1.23 to 1.26 ([3f0588f](https://github.com/noshita/ktch/commit/3f0588f6461330bc74421fcff890fdf886c06304))
* 🔧 releasing ([7368293](https://github.com/noshita/ktch/commit/7368293a8f5e3adb08fef7f83052c1e0a68b4cbc))
* 🔧 update requirements.txt ([c4103ff](https://github.com/noshita/ktch/commit/c4103ff764a0d4d44cd1765ff3e37f54c0a42ab2))
* **ci:** 🔧 add Disable notebook execution cache in documentation.yaml ([ffb64a9](https://github.com/noshita/ktch/commit/ffb64a9dcef2def8075a19ac7ba4379003cafa9e))
* **deps-dev:** bump sphinx-autobuild from 2024.10.3 to 2025.8.25 ([475d42a](https://github.com/noshita/ktch/commit/475d42a376eacbf5dd4021ab71e5c2f47cc89d6a))
* **deps-dev:** bump sphinx-autobuild from 2024.10.3 to 2025.8.25 ([5699637](https://github.com/noshita/ktch/commit/569963736e0ed7d06c1e0c938e5632ef0bf57219))
* **deps:** bump joblib from 1.5.2 to 1.5.3 ([4ccf1dc](https://github.com/noshita/ktch/commit/4ccf1dc45108d5ddc76888fc1347bfd285ebef49))
* **deps:** bump joblib from 1.5.2 to 1.5.3 ([91f2b82](https://github.com/noshita/ktch/commit/91f2b8272ae5b602acc292ed53f82b1a212e48fc))
* **deps:** bump tornado from 6.5.4 to 6.5.5 ([10544c2](https://github.com/noshita/ktch/commit/10544c264bd2655d3a7d7f568126b5e3fc90d37d))
* **deps:** bump tornado from 6.5.4 to 6.5.5 ([dbbe90c](https://github.com/noshita/ktch/commit/dbbe90c4ae68ced4b1413698d3edf5636205d856))
* **deps:** bump tzdata from 2025.2 to 2025.3 ([97865f4](https://github.com/noshita/ktch/commit/97865f44ba6a24447d83c2abf51138d7145ee929))
* **deps:** bump tzdata from 2025.2 to 2025.3 ([7040aa3](https://github.com/noshita/ktch/commit/7040aa38c1a8dc43327c1fab095267c839bc090a))


### Code Refactoring

* ♻️  remove redundant degenerate guard from 3D EFA ([e206357](https://github.com/noshita/ktch/commit/e2063571d0f090012ef22aeda01fd46cad1984dc))
* ♻️ remove dead code and extract named constants ([64f2acc](https://github.com/noshita/ktch/commit/64f2acc2861e146d6e1b3351481248f90102be40))
* **io:** ♻️ improve chain code I/O ([75336a9](https://github.com/noshita/ktch/commit/75336a9769fa5deb7ae0fb9bf93ed26fe46fde41))

## [0.8.1](https://github.com/noshita/ktch/compare/v0.8.0...v0.8.1) (2026-03-10)


### Features

* **datasets:** ✨ use 0-based specimen_id and return 3D arrays ([06c5ba6](https://github.com/noshita/ktch/commit/06c5ba66b1d1244da11d77f6f7fda70cf15dfcbe))


### Reverts

* restore versions.json to 0.8.0 before release ([2203c39](https://github.com/noshita/ktch/commit/2203c39aabfbd2b892c44cce150f8396d36f4326))


### Documentation

* update versions.json for v0.8.1 release ([0475f81](https://github.com/noshita/ktch/commit/0475f81d209516aa80fd62cc8d09312085f740b4))


### Miscellaneous Chores

* 🔧 update pyproject.toml metadata, sdist excludes, and lint config ([e04acc0](https://github.com/noshita/ktch/commit/e04acc0aab5fbd42bf46161929af3f98947e1909))


### Code Refactoring

* ♻️ remove unused imports detected by ruff F401 ([e29d452](https://github.com/noshita/ktch/commit/e29d4526efa2d0417efb9880dfc844e2650a2ae5))


### Continuous Integration

* harden and modernize GitHub Actions workflows ([a1611bf](https://github.com/noshita/ktch/commit/a1611bf07e856dc65b7a28f07226e3b24a4387f7))

## [0.8.0](https://github.com/noshita/ktch/compare/v0.7.2...v0.8.0) (2026-03-10)


### Features

* **plot:** ✨add shape_variation_plot and morphospace_plot ([9b37e1d](https://github.com/noshita/ktch/commit/9b37e1d5a8f93c62e137a072ead9d091c82a7fa2))


### Bug Fixes

* 🐛 remove plot_shapes_along_pcs from tests ([a9e389e](https://github.com/noshita/ktch/commit/a9e389e1122d624a1eaeccf2b274093d48057ebd))
* 🐛 rename to _elliptic_fourier_analysis.py ([7328832](https://github.com/noshita/ktch/commit/7328832253398c5b41148c8c804bf0ef8ada2722))
* 🐛 return_orientation_scale requires norm=True ([0a231d8](https://github.com/noshita/ktch/commit/0a231d800d1df8a1f2df93d0f591c47ba313a95e))
* **harmonic:** 🐛 fix inverse_transform return type and add set_output to SHA ([0f66d6a](https://github.com/noshita/ktch/commit/0f66d6adc9dcb9fa8bd7ac79a0940df29a2073fd))
* **io:** harden TPS write/read for semilandmarks ([c7c7678](https://github.com/noshita/ktch/commit/c7c76783783fe93dcfe788b5173ea9a40e93b550))
* **landmark:** 🐛 improve sklearn API compliance in GPA ([cf6bcdb](https://github.com/noshita/ktch/commit/cf6bcdb7f2dbed4244c252ffe895fe6fac5fdc2d)), closes [#104](https://github.com/noshita/ktch/issues/104)


### Documentation

* 📚  update tutorials to current API and use morphospace_plot ([2977783](https://github.com/noshita/ktch/commit/2977783bb40e82d0b3626a6456344ef23dadf891))
* **harmonic,io:** 📚 improve docstrings and extract tolerance constants ([a957540](https://github.com/noshita/ktch/commit/a957540d85f58b580fef84536a6f19f6af503636)), closes [#115](https://github.com/noshita/ktch/issues/115) [#118](https://github.com/noshita/ktch/issues/118)
* **plot:** 📚 add visualization API design docs and how-to guides ([45e6d48](https://github.com/noshita/ktch/commit/45e6d481e674e1e071a9516594de2a400e451462))
* update versions.json for v0.8.0 release ([372e561](https://github.com/noshita/ktch/commit/372e56173b22f27fae29defa847c219d36c81424))


### Miscellaneous Chores

* 🔧 clean up test directories ([f9897ea](https://github.com/noshita/ktch/commit/f9897ea15c15916590a5121043410e9707cabe89))
* 🔧 enable ruff pydocstyle (D) rules with incremental adoption ([8b0227e](https://github.com/noshita/ktch/commit/8b0227ee3e7e8dd49acc95336fe805337be1fc15))
* 🔧 remove bottle dataset ([839b595](https://github.com/noshita/ktch/commit/839b595538c67cfa005560008712bdd32246a0ea))
* 🔧 remove update_versions_json.py script ([1ef2f4c](https://github.com/noshita/ktch/commit/1ef2f4cb125a47ac3be8301852caef13f6f3a02e))
* **harmonic:** 🔧 add robustness tests and fix edge-case bugs in EFA/SHA ([1cdec79](https://github.com/noshita/ktch/commit/1cdec7990edeab3b03a9057177ce6e9aa14bd424)), closes [#117](https://github.com/noshita/ktch/issues/117)


### Code Refactoring

* ♻️  rename module files to PEP 8 snake_case ([f8a367e](https://github.com/noshita/ktch/commit/f8a367e1385a69d516fe9a566ee4243c3656408d)), closes [#116](https://github.com/noshita/ktch/issues/116)
* ♻️ move validations from __init__ into transform following scikit-learn convention ([bb2ed26](https://github.com/noshita/ktch/commit/bb2ed26d8ee04b3dafcebb7dc1d2c44ef7e23611))
* **harmonic:** ♻  align EFA/SHA API with scikit-learn transformer contract ([4080f00](https://github.com/noshita/ktch/commit/4080f001e87b4315a6c202a3776364136da14681))
* **harmonic:** ♻️ improve EFA/SHA sklearn compliance ([6942834](https://github.com/noshita/ktch/commit/6942834bb1d8dc5065b9d24cbba7fcd4fcd9ca8e))
* **harmonic:** ♻️ remove duplicate parts in 2D/3D transform in EFA ([b15f195](https://github.com/noshita/ktch/commit/b15f195fd45d674ccd926372d7b9956d814ebb2d)), closes [#114](https://github.com/noshita/ktch/issues/114)
* **landmark:** ♻️  align GPA with scikit-learn estimator contract ([72d8a8b](https://github.com/noshita/ktch/commit/72d8a8bcace92d424a7dd221bd0da549a60cd4be))
* **landmark:** ♻️ remove _slide_semilandmarks function ([3f387a2](https://github.com/noshita/ktch/commit/3f387a2e374add1e0b847d3fabe0d408d3373baa))

## [0.7.2](https://github.com/noshita/ktch/compare/v0.7.1...v0.7.2) (2026-02-20)


### Features

* ✨ update image_passiflora_leaves dataset ([9aae743](https://github.com/noshita/ktch/commit/9aae74366066b24b234202297376cad43d35a342))


### Bug Fixes

* 🐛 fix ReDoS vulnerability in TPS CURVES regex (code-scanning[#14](https://github.com/noshita/ktch/issues/14)) ([a913d89](https://github.com/noshita/ktch/commit/a913d89ff026a9cca5e8d4125dd6d88c4d14d654))


### Documentation

* 📚 dump version ([0aea7ec](https://github.com/noshita/ktch/commit/0aea7ec9b9f4fe0a7a56c42d68e982c3ee852184))
* 📚 update image_passiflora_leaves dataset ([71ce0d3](https://github.com/noshita/ktch/commit/71ce0d3de296d9baa7321131f249ae5a2af1caee))


### Miscellaneous Chores

* 🔧 remove obsolete Poetry-era and conda-related config ([8e72be4](https://github.com/noshita/ktch/commit/8e72be47ea7237819f49d2b0bfe523c939644c52))

## [0.7.1](https://github.com/noshita/ktch/compare/v0.7.0...v0.7.1) (2026-02-19)


### Features

* ✨ lazy import in plot module ([94de8cc](https://github.com/noshita/ktch/commit/94de8cc6c3b2f1c4704047ccc400d34accf9a851))


### Bug Fixes

* 🐛 .release-please-manifest.json ([ab0e443](https://github.com/noshita/ktch/commit/ab0e443e38358ce44c55603070baec7f51b7e9ee))
* 🐛 release-please workflow ([6c751a9](https://github.com/noshita/ktch/commit/6c751a96c3590dd8390b2aec38b1c7d800baf16f))
* 🐛 setup-uv ([31e1b51](https://github.com/noshita/ktch/commit/31e1b51e4e3c0f51e25a6591f53951c6c87f7b38))
* 🐛 sphinx multiversion switcher ([93e1ef3](https://github.com/noshita/ktch/commit/93e1ef369404db9035cb467c199c65698145134b))


### Performance Improvements

* ⚡️ doc build ([2281da7](https://github.com/noshita/ktch/commit/2281da7578d70fcfbe63419e876383897a199826))


### Documentation

* 📚 add guidelines for optional dependencies ([b7628f3](https://github.com/noshita/ktch/commit/b7628f3e62fde9ec394217884cfb250f3d765dda))


### Miscellaneous Chores

* 🔧 change trigger for documentation build ([57f0321](https://github.com/noshita/ktch/commit/57f0321ddde15ea77cd715deb0615f297c6ba692))
* 🔧 scipy &gt;= 1.15 ([0ef8844](https://github.com/noshita/ktch/commit/0ef8844e167059d9f8d4d8f1868c0dc3da888133))
* 🔧 script for doc versions ([641fc97](https://github.com/noshita/ktch/commit/641fc97dd2b02ec9daeba40ef227810dd4273732))
* 🔧 update doc versions ([8b18c47](https://github.com/noshita/ktch/commit/8b18c4797d67630cb000bc54477214794174e1c9))


### Code Refactoring

* ♻️ datasets module ([4b09555](https://github.com/noshita/ktch/commit/4b09555b448feb152f979e4b49b47476294f566f))

## [0.7.0](https://github.com/noshita/ktch/compare/v0.6.1...v0.7.0) (2026-02-12)


### Features

* ✨  add registry update script via R2 manifest.json ([b9d63bc](https://github.com/noshita/ktch/commit/b9d63bcf59121c109097f2e4b950aa3638bd16e1))
* ✨ add new dataset: outline_leaf_bending ([25d9d30](https://github.com/noshita/ktch/commit/25d9d308952ffbc7c0273c9b1b78428fab07ea8f))
* ✨ add normalization with semi-major axis for 3D EFA ([6b3440f](https://github.com/noshita/ktch/commit/6b3440f4a98175fc2b456e70d524d73d01bd92a4))
* ✨ add Passiflora leaf image dataset ([f75cb0c](https://github.com/noshita/ktch/commit/f75cb0c97b5425a84e765000cc04c662f8deb5c1))
* ✨ datasets trilobite cephala ([1ce07aa](https://github.com/noshita/ktch/commit/1ce07aa46134f64c914719c3034417e8be2f7899))
* ✨ n_jobs for GPA ([679dcd2](https://github.com/noshita/ktch/commit/679dcd2954929bbfa5baed55b10ee0bcc17ae3a0))
* ✨ Normalization for 3D EFA ([59ada8f](https://github.com/noshita/ktch/commit/59ada8fde44775e9b4722425b7027afae2d264e7))
* ✨ semilandmark analysis ([a5e6076](https://github.com/noshita/ktch/commit/a5e6076104e5b24529e52a356f8345946d16b973))
* ✨ tutorial for outline extraction ([3bfe708](https://github.com/noshita/ktch/commit/3bfe7084de0f083d2db09c30e8563d950a11a2d1))


### Bug Fixes

* 🐛 add jupytext for v0.6.1 build ([8e7cff2](https://github.com/noshita/ktch/commit/8e7cff25bd3ba5726a2d9949279a55f95fb28b7b))
* 🐛 add jupytext for v0.6.1 build ([932a9ab](https://github.com/noshita/ktch/commit/932a9ab7bc6c29472c900ae2d33660a8b75ad5d8))
* 🐛 add path traversal validation for zip extraction ([01010c4](https://github.com/noshita/ktch/commit/01010c435990252538c2f1ee5a273bf64caaf528))
* 🐛 add version_match logging ([8e7cff2](https://github.com/noshita/ktch/commit/8e7cff25bd3ba5726a2d9949279a55f95fb28b7b))
* 🐛 add version_match logging ([932a9ab](https://github.com/noshita/ktch/commit/932a9ab7bc6c29472c900ae2d33660a8b75ad5d8))
* 🐛 doc ([96ff2c8](https://github.com/noshita/ktch/commit/96ff2c80be52a3d0f58840b684dedb02511eb56d))
* 🐛 remove duplicate data and update metadata and tps data ([c979e80](https://github.com/noshita/ktch/commit/c979e80568de71a360912543929b39166423f22d))
* 🐛 replace exec() with ast-based parsing in update_registry ([abe1973](https://github.com/noshita/ktch/commit/abe1973bcb1b39c03a210634e1ca562e140b8648))
* 🐛 sphinx-multiversion and switcher ([932a9ab](https://github.com/noshita/ktch/commit/932a9ab7bc6c29472c900ae2d33660a8b75ad5d8))
* 🐛 test-codecov.yml ([1bafb2b](https://github.com/noshita/ktch/commit/1bafb2b8b2cc61e8bc92d70a6f5731517aedb237))
* 🐛 tip coordinates in outline_leaf_bending dataset ([f5a7996](https://github.com/noshita/ktch/commit/f5a7996a470bffbc94eaa90e8443794a44f83860))
* 🐛 typo ([1fb2811](https://github.com/noshita/ktch/commit/1fb281108d0a3249adf93db46f033abbfb376d3f))
* 🐛 use sphinx-multiversion on GitHub for env variable ([8e7cff2](https://github.com/noshita/ktch/commit/8e7cff25bd3ba5726a2d9949279a55f95fb28b7b))
* 🐛 use sphinx-multiversion on GitHub for env variable ([932a9ab](https://github.com/noshita/ktch/commit/932a9ab7bc6c29472c900ae2d33660a8b75ad5d8))
* 🐛 version switcher, redirect to stable ([8e7cff2](https://github.com/noshita/ktch/commit/8e7cff25bd3ba5726a2d9949279a55f95fb28b7b))
* 🐛 version switcher, redirect to stable ([932a9ab](https://github.com/noshita/ktch/commit/932a9ab7bc6c29472c900ae2d33660a8b75ad5d8))
* 🐛 version_match ([8e7cff2](https://github.com/noshita/ktch/commit/8e7cff25bd3ba5726a2d9949279a55f95fb28b7b))
* 🐛 version_match ([932a9ab](https://github.com/noshita/ktch/commit/932a9ab7bc6c29472c900ae2d33660a8b75ad5d8))


### Performance Improvements

* ⚡️ enable parallel read (and execute) ([8f1f1ff](https://github.com/noshita/ktch/commit/8f1f1ff176d0c9f30651e60e94fe8d5616de5f8e))


### Documentation

* 📚  move 2D outline registration guide from tutorials to how-to ([cdb1ad3](https://github.com/noshita/ktch/commit/cdb1ad3c4c353d6d5bfd8dc4fa62d16c89088aca))
* 📚 drop doc of v0.6.1 ([5cdb7aa](https://github.com/noshita/ktch/commit/5cdb7aafcae3dfa15af26e66091d8c76f77b6725))
* 📚 redesign documentation with Diátaxis framework and multi-version support ([#108](https://github.com/noshita/ktch/issues/108)) ([7bc8465](https://github.com/noshita/ktch/commit/7bc8465737cc2109a7a61a3607a701435d324ea4))
* 📚 refactor configuration_plot, use vtp files for spharm ([0db89a8](https://github.com/noshita/ktch/commit/0db89a86e0d2633ad6e666543aacb7116003d4d5))
* 📚 reorganize contributing guides and migrate liccheck to licensecheck ([d475742](https://github.com/noshita/ktch/commit/d47574262b451f5e3aeede32a5fd9aabf9116b2e))
* 📚 sitemap ([19a1932](https://github.com/noshita/ktch/commit/19a1932c4a0e482b6e552526dcc709691a249111))
* 📚 Update README.md ([d0d43eb](https://github.com/noshita/ktch/commit/d0d43eb446ad6dd92e1e104d4d82d3fbbce475bd))
* 📚 update tutorial for 3D EFA to cover morphospace reconstruction ([d63fcb3](https://github.com/noshita/ktch/commit/d63fcb3b0395169a92173e64d91c076e2c186602))


### Miscellaneous Chores

* release 0.7.0 ([e9c2476](https://github.com/noshita/ktch/commit/e9c2476ef3790c6afd687052fb39841644c74292))

## [0.6.1](https://github.com/noshita/ktch/compare/v0.6.0...v0.6.1) (2025-12-08)


### Bug Fixes

* 🐛 rename _tps to _kriging ([94089f8](https://github.com/noshita/ktch/commit/94089f83f70a0dc745ff9e8491c083d006d89b9d))


### Documentation

* 📚 update api, notebooks ([63ab4ac](https://github.com/noshita/ktch/commit/63ab4ac3b31ffcdc398406ed0686a520d19943bc))


### Miscellaneous Chores

* release 0.6.1 ([4cb985a](https://github.com/noshita/ktch/commit/4cb985a61221ff510a0af9b867f9823f79e733fe))

## [0.6.0](https://github.com/noshita/ktch/compare/v0.5.0...v0.6.0) (2025-12-04)


### Features

* ✨ add  option to  2D ([6032557](https://github.com/noshita/ktch/commit/6032557d1cce9fc9d06854a54111d6a27353f8ad))
* ✨ Add chain code file I/O functionality ([61905e0](https://github.com/noshita/ktch/commit/61905e00b554785ca1290739971c40ad3bed1dee))
* ✨ Add coordinate conversion functions to ChainCodeData class ([5384d02](https://github.com/noshita/ktch/commit/5384d02aa0170e7ba12f1f4955a963a08076532b))
* ✨ add n_jobs to EllipticFourierAnalysis class ([5db88e5](https://github.com/noshita/ktch/commit/5db88e58cd25f0721962c2991371fdc48bce55ab))
* ✨ add n_jobs to EllipticFourierAnalysis class ([321193a](https://github.com/noshita/ktch/commit/321193aad7770f8958b6261da1be475d8406f497))
* ✨ add plot module ([4f01f3e](https://github.com/noshita/ktch/commit/4f01f3ec439966cc8a8cc61d554093f378154ee0))
* ✨ SphericalHarmonicAnalysis class ([7103a16](https://github.com/noshita/ktch/commit/7103a16f341391f7bc8c389a3ec6473de69ec2ec))
* ✨ Update chain code format to use simplified sample name format ([38a4be4](https://github.com/noshita/ktch/commit/38a4be486ec5007c51baced185d084ef3b6d2cbe))
* ✨ Update chain code implementation to validate direction codes (0-7) ([2242ecc](https://github.com/noshita/ktch/commit/2242ecc6d7938fa5cd97e822bf7b45aee3bdc6e4))
* Add comprehensive input validation and error handling ([e5b7725](https://github.com/noshita/ktch/commit/e5b7725dd75c536ae4156076b81fa7f404e13ed4))
* Add type hints and improve documentation for SPHARM-PDM module ([fc47215](https://github.com/noshita/ktch/commit/fc472150ac0c896a9c2aa8cf72fadd9888ea380b))


### Bug Fixes

* _cvt_spharm_coef_SPHARMPDM_to_list ([5122e8b](https://github.com/noshita/ktch/commit/5122e8b83516cb8198c49ea514a7014cbb360b51))
* 🐛 Add n_samples definition in write_chc function ([7944293](https://github.com/noshita/ktch/commit/7944293f455a05ff4b8dafc623e7c916040c0b5c))
* 🐛 add seaborn for test-codecov ([5972268](https://github.com/noshita/ktch/commit/5972268df9966eeddecafa8a656e31a355639a50))
* 🐛 change outline to harmonic ([65bc786](https://github.com/noshita/ktch/commit/65bc786040631d533873c54802ea6322104f579b))
* 🐛 Fix chain_code property in ChainCodeData class ([7632cbf](https://github.com/noshita/ktch/commit/7632cbf3bf31c6792fbf624dfc84c7fdba5dfca6))
* 🐛 Fix handling of 1D arrays in write_chc function ([a51136e](https://github.com/noshita/ktch/commit/a51136e7fc815f5a3e02b5ed3489ad7656e0c370))
* 🐛 notebook for spharm ([36e17dd](https://github.com/noshita/ktch/commit/36e17ddcb31a561332357f5571b7eda32d6718fb))
* 🐛 notebook for spharm ([c4f26cd](https://github.com/noshita/ktch/commit/c4f26cd02a5eb95d7502ec8f194ad709bab73c06))
* 🐛 Optimize regex patterns and add test for CURVES functionality ([0537c4f](https://github.com/noshita/ktch/commit/0537c4f1c681f52a68e6c9bab4328ab6164402ba))
* 🐛 Optimize regex patterns to avoid catastrophic backtracking ([ee76958](https://github.com/noshita/ktch/commit/ee76958f8eabcd25f4c8e4d0a2734440760eb8ec))
* 🐛 Pass validate parameter to ChainCodeData constructor ([53f100e](https://github.com/noshita/ktch/commit/53f100ef71ba43c577e4f3d114b781ead779431a))
* 🐛 release-please config files ([a231c32](https://github.com/noshita/ktch/commit/a231c32fb686ac6f7ee91682d4147c2085ccbd6f))
* 🐛 remove unused Class ([f506f2a](https://github.com/noshita/ktch/commit/f506f2ac51533f378cd8cda336a38f3ae9916191))
* 🐛 remove unused import ([a2bbb6a](https://github.com/noshita/ktch/commit/a2bbb6a528a95cc5663614d0c8fc88fcdbee101a))
* 🐛 scale X before iterations ([82f4a16](https://github.com/noshita/ktch/commit/82f4a1622b7aeae1d36fca77ef48e0e70bf7360e))
* 🐛 tests for io of SPHARM-PDM ([543c1e9](https://github.com/noshita/ktch/commit/543c1e98464bbd541beb42e7b9965e66fa10251b))


### Performance Improvements

* Optimize coefficient parsing and conversion logic ([3ae8db3](https://github.com/noshita/ktch/commit/3ae8db3281e30defc2ce1a4d0389dbfc33716d64))


### Documentation

* 📚 add api, docstring, and notebook for spharm ([da7a9d9](https://github.com/noshita/ktch/commit/da7a9d910b7a3dcc30cb02de0fa185b5b0d5e064))
* 📚 fix 3D plots using Plotly, add myst-nb config ([c891b03](https://github.com/noshita/ktch/commit/c891b0360343b9ac49b741064a8a7d1cfe51cf76))
* 📚 update api for chc, spharmpdm ([719ef46](https://github.com/noshita/ktch/commit/719ef460fe5500276a50460909db33e776d1a6b0))
* 📚 update notebook for spharm ([a3c5738](https://github.com/noshita/ktch/commit/a3c57386c65d4092e47ba3e66ad5c136d06e1da4))

## [0.5.0](https://github.com/noshita/ktch/compare/v0.4.3...v0.5.0) (2025-02-07)


### Features

* ✨ add example notebook of 3D EFA ([8f8ead2](https://github.com/noshita/ktch/commit/8f8ead20d27fbe86e7c49ff7e1fe8ff1e2f72838))


### Bug Fixes

* 🐛 github actions test-codecov.yml ([30e31b1](https://github.com/noshita/ktch/commit/30e31b1498fc7b4a01e21938fd433e02b0c6ed6b))
* 🐛 paths filter ([3dbf322](https://github.com/noshita/ktch/commit/3dbf3229b5db6d4e425662622ebf4f0b17bfcbe2))


### Documentation

* 📚 reorganize documentations ([ff4ec55](https://github.com/noshita/ktch/commit/ff4ec5546582b11e0f48c396df2a9fc8df2c3b6c))

## [0.4.3](https://github.com/noshita/ktch/compare/v0.4.2...v0.4.3) (2025-02-06)


### Features

* ✨ add 3D EFA ([4d74c92](https://github.com/noshita/ktch/commit/4d74c92949e030703918c26c2c5de7c7f5074d6d))
* ✨ add auto-approve for owener ([a38fb05](https://github.com/noshita/ktch/commit/a38fb05db971cd2e62ba03f938ccd81ac0b19d69))


### Bug Fixes

* 🐛 actions/setup-python ([d06a63e](https://github.com/noshita/ktch/commit/d06a63e8fc558f66d3dcce14393bddbe32b7372e))
* 🐛 github actions filters ([43aa28c](https://github.com/noshita/ktch/commit/43aa28cb75cfeb2791a376b6ad43859167015ac7))
* 🐛 pull_request ([19ad8c7](https://github.com/noshita/ktch/commit/19ad8c757bfd67016ad0ca08fbf165ca79f0264d))


### Miscellaneous Chores

* 🔧  v0.4.3 ([7e07f19](https://github.com/noshita/ktch/commit/7e07f199dfad803844867e6e06def27efbd2a795))
* 🔧 update requirements.txt ([a43ec5f](https://github.com/noshita/ktch/commit/a43ec5f7ec020c338cb04bf87c8f22020c081f60))

## [0.4.2](https://github.com/noshita/ktch/compare/v0.4.1...v0.4.2) (2024-06-09)


### Bug Fixes

* 🐛  inefficient regular expression ([a2d04a2](https://github.com/noshita/ktch/commit/a2d04a2de7bbf204e289e2c2e4cdf75b0a59565f))
* 🐛 actions/setup-python ([d06a63e](https://github.com/noshita/ktch/commit/d06a63e8fc558f66d3dcce14393bddbe32b7372e))
* 🐛 install jupytext ([b938cb1](https://github.com/noshita/ktch/commit/b938cb1e52a77191069538942caeb71f46c07c1f))
* 🐛 invalid escape sequence ([394464d](https://github.com/noshita/ktch/commit/394464d84c1ec0da8fd50c12bd4a93c80afbe31c))


### Documentation

* 📚 introduce jupytext and remove .ipynb files ([d8b38b9](https://github.com/noshita/ktch/commit/d8b38b9a11408da1fd464a0f2c7b268688c23350))
* 📚 introduce jupytext and remove .ipynb files ([0d6dd70](https://github.com/noshita/ktch/commit/0d6dd705a53a52495e15e945612b4185ffd2b0a5))


### Miscellaneous Chores

* 🔧 update requirements.txt ([a43ec5f](https://github.com/noshita/ktch/commit/a43ec5f7ec020c338cb04bf87c8f22020c081f60))
* release 0.4.1 ([cc1c2a6](https://github.com/noshita/ktch/commit/cc1c2a62aeaebf444b14e05285378e6de8463860))

## [0.4.1](https://github.com/noshita/ktch/compare/v0.4.1...v0.4.1) (2024-03-12)


### Bug Fixes

* 🐛  inefficient regular expression ([a2d04a2](https://github.com/noshita/ktch/commit/a2d04a2de7bbf204e289e2c2e4cdf75b0a59565f))
* 🐛 install jupytext ([b938cb1](https://github.com/noshita/ktch/commit/b938cb1e52a77191069538942caeb71f46c07c1f))
* 🐛 invalid escape sequence ([394464d](https://github.com/noshita/ktch/commit/394464d84c1ec0da8fd50c12bd4a93c80afbe31c))


### Documentation

* 📚 introduce jupytext and remove .ipynb files ([d8b38b9](https://github.com/noshita/ktch/commit/d8b38b9a11408da1fd464a0f2c7b268688c23350))
* 📚 introduce jupytext and remove .ipynb files ([0d6dd70](https://github.com/noshita/ktch/commit/0d6dd705a53a52495e15e945612b4185ffd2b0a5))


### Miscellaneous Chores

* release 0.4.1 ([cc1c2a6](https://github.com/noshita/ktch/commit/cc1c2a62aeaebf444b14e05285378e6de8463860))

## [0.3.3](https://github.com/noshita/ktch/compare/v0.3.2...v0.3.3) (2024-03-10)


### Features

* ✨ add to doc ([25317da](https://github.com/noshita/ktch/commit/25317da0805b13316e767a563460c597da2066a9))
* ✨ add tps transformation grid ([ae87df5](https://github.com/noshita/ktch/commit/ae87df55d6f9590ac11f1be94ab493c647f71980))
* ✨ add tps transformation grid ([d295a4f](https://github.com/noshita/ktch/commit/d295a4fbc1629475b1fb4f85a569e4b178704f75))
* ✨ thin-plate spline ([09f8c4a](https://github.com/noshita/ktch/commit/09f8c4a4c7cd6061e8a55939b9cb1801386267ca))

## [0.3.1](https://github.com/noshita/ktch/compare/v0.3.0...v0.3.1) (2024-02-08)


### Bug Fixes

* 🐛 phase shift ([25450bc](https://github.com/noshita/ktch/commit/25450bc4f112f0f81e9ba34d4d832275302320be))
* 🐛 phaseshift ([25450bc](https://github.com/noshita/ktch/commit/25450bc4f112f0f81e9ba34d4d832275302320be))
* 🐛 phaseshift ([25450bc](https://github.com/noshita/ktch/commit/25450bc4f112f0f81e9ba34d4d832275302320be))
* 🐛 setter of SPHARMCoefficients class ([ee12ce2](https://github.com/noshita/ktch/commit/ee12ce2e62243c48ac657b322f62fb9fe0ee4231))


### Documentation

* 📚 add robots.txt ([ff2aeda](https://github.com/noshita/ktch/commit/ff2aedaf031ca032dac0b8daf40c170a40cb1b3a))
* 📚 add sitemap ([8ea64cf](https://github.com/noshita/ktch/commit/8ea64cffe07cac0f3a11734b7c94eaec511e60e1))
* 📚 doc ([ceb1ee3](https://github.com/noshita/ktch/commit/ceb1ee310ce9b00f13b836592ea73a39074b43a9))
* 📚 update autodoc ([ba2c2d6](https://github.com/noshita/ktch/commit/ba2c2d6cc66325fbbf6758a5ad260f1c723fb116))
* 📚 update doc config ([72f6df7](https://github.com/noshita/ktch/commit/72f6df73d8d7ce97644382a6b26e22eefbb00c39))
* 📚 update favicon ([54b6cec](https://github.com/noshita/ktch/commit/54b6cec17a9ac894ebcabfde7514722b4c046712))
* 📚 update favicon ([54b6cec](https://github.com/noshita/ktch/commit/54b6cec17a9ac894ebcabfde7514722b4c046712))
* 📚 update favicon ([54b6cec](https://github.com/noshita/ktch/commit/54b6cec17a9ac894ebcabfde7514722b4c046712))
