"""
BIAPAY SDK — Callback Server

L'utilisateur déclare son URL de callback complète une fois via set_callback_url().
Le SDK en extrait automatiquement le host, le port et le path pour lancer
le bon serveur sur la bonne route.
"""

import json
import logging
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Callable, Optional
from urllib.parse import urlparse, parse_qs

from .models import CallbackPayload
from .exceptions import BIAPaySignatureError, BIAPayValidationError

logger = logging.getLogger(__name__)


def _json_response(handler, status: int, body: dict) -> None:
    data = json.dumps(body).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


class _CallbackHandler(BaseHTTPRequestHandler):
    """Handler HTTP interne — une instance créée par requête."""

    callback_path: str = "/"
    verify_fn: Callable = None
    user_handler: Callable = None

    def log_message(self, format, *args):
        logger.debug("BiaPay CallbackServer: %s", format % args)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path.rstrip("/") != self.callback_path.rstrip("/"):
            _json_response(self, 404, {"error": "Not found"})
            return

        content_length = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(content_length) if content_length else b""

        try:
            params = json.loads(raw_body.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            logger.warning("BiaPay callback: JSON invalide — %s", e)
            _json_response(self, 400, {"success": False, "error": "JSON invalide"})
            return

        self._process(params)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path.rstrip("/") != self.callback_path.rstrip("/"):
            _json_response(self, 404, {"error": "Not found"})
            return

        raw_params = parse_qs(parsed.query)
        params = {k: v[0] for k, v in raw_params.items()}
        self._process(params)

    def _process(self, params: dict) -> None:
        ip = self.client_address[0]
        logger.info("BiaPay callback reçu depuis %s | params=%s", ip, params)

        # 1. Parse
        try:
            payload = CallbackPayload.from_query_params(params)
        except Exception as e:
            logger.error("Impossible de parser le payload BiaPay: %s", e)
            _json_response(self, 400, {"success": False, "error": f"Payload invalide : {e}"})
            return

        # 2. Vérification signature HMAC-SHA256
        try:
            is_valid = self.verify_fn(payload)
        except BIAPaySignatureError as e:
            logger.warning("Signature absente: %s", e)
            _json_response(self, 400, {"success": False, "error": str(e)})
            return
        except Exception as e:
            logger.error("Erreur vérification signature: %s", e)
            _json_response(self, 500, {"success": False, "error": "Erreur interne"})
            return

        # 3a. Signature invalide → 403, handler jamais appelé
        if not is_valid:
            logger.warning("Signature INVALIDE pour orderId=%s", payload.order_id)
            _json_response(self, 403, {
                "success": False,
                "error": "Signature invalide. La requête ne provient pas de BiaPay.",
                "orderId": payload.order_id,
            })
            return

        # 3b. Signature valide → dispatch vers le handler du développeur
        logger.info(
            "Signature valide ✓ | orderId=%s | status=%s | amount=%s %s",
            payload.order_id, payload.status, payload.amount, payload.currency,
        )

        try:
            self.user_handler(payload)
        except Exception as e:
            logger.exception("Erreur handler utilisateur orderId=%s: %s", payload.order_id, e)
            _json_response(self, 500, {"success": False, "error": "Erreur traitement paiement"})
            return

        _json_response(self, 200, {
            "success": True,
            "message": "Callback traité avec succès.",
            "orderId": payload.order_id,
            "status": payload.status,
        })


class CallbackServer:
    """
    Serveur HTTP intégré au SDK BiaPay.

    Prend l'URL complète déclarée par l'utilisateur et en extrait
    automatiquement le host, le port et le path.

    Args:
        callback_url: URL complète (ex: "http://localhost:8000/api/payments/callback/receive/")
        verify_fn:    Fonction HMAC du client BIAPay.
        user_handler: Handler @on_callback du développeur.
    """

    def __init__(self, callback_url: str, verify_fn: Callable, user_handler: Callable):
        self.callback_url = callback_url
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None

        # Extraction automatique des composantes de l'URL
        parsed = urlparse(callback_url)
        self.host = parsed.hostname or "0.0.0.0"
        self.port = parsed.port or (443 if parsed.scheme == "https" else 80)
        self.path = parsed.path or "/"

        # Injection dans la classe handler
        _CallbackHandler.callback_path = self.path
        _CallbackHandler.verify_fn = staticmethod(verify_fn)
        _CallbackHandler.user_handler = staticmethod(user_handler)

    def start(self, blocking: bool = True) -> None:
        self._server = HTTPServer((self.host, self.port), _CallbackHandler)

        logger.info("BiaPay CallbackServer démarré — URL: %s | path: %s", self.callback_url, self.path)
        print(f"\n{'='*60}")
        print(f"   BiaPay CallbackServer démarré")
        print(f"   URL déclarée  : {self.callback_url}")
        print(f"   Écoute sur   : {self.host}:{self.port}")
        print(f"   Path          : {self.path}")
        print(f"{'='*60}\n")

        if blocking:
            try:
                self._server.serve_forever()
            except KeyboardInterrupt:
                self.stop()
        else:
            self._thread = threading.Thread(
                target=self._server.serve_forever,
                daemon=True,
                name="biapay-callback-server",
            )
            self._thread.start()

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
            self._server.server_close()
            logger.info("BiaPay CallbackServer arrêté.")
            print("🛑 BiaPay CallbackServer arrêté.")

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()
