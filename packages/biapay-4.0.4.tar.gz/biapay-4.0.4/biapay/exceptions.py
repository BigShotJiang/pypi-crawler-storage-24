"""
BIAPAY SDK Exceptions
"""


class BIAPayError(Exception):
    """Base exception for all BIAPAY SDK errors."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response or {}

    def __repr__(self):
        return f"{self.__class__.__name__}(message={self.message!r}, status_code={self.status_code})"


class BIAPayAuthError(BIAPayError):
    """Raised when authentication fails (invalid clientId or clientSecret)."""
    pass


class BIAPayConnectionError(BIAPayError):
    """Raised when there is a network or connection issue."""
    pass


class BIAPaySignatureError(BIAPayError):
    """Raised when callback signature verification fails."""
    pass


class BIAPayValidationError(BIAPayError):
    """Raised when request parameters are invalid."""
    pass
