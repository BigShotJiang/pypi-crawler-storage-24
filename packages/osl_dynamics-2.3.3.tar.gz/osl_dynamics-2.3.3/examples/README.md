Example use of osl-dynamics
---------------------------

This directory contains:

- `decoding`: scripts for decoding (predicting quantities based on neuroimaging features).
- `fmri`: scripts for analysing fMRI data.
- `meg`: scripts for analysing MEG data.
- `plotting`: scripts for using the basic plotting functions provided in this package.
- `simulation`: scripts for training models for dynamics on simulated data. These scripts can be useful for testing your setup is working correctly and highlight the pros/cons of various models.
- 'spectra': scripts for calculating spectral properties.
- `static`:  scripts for static network analysis.
- `statistics`: scripts for performing statistical significance testing (using non-parameteric GLM permutations).
- `tinda`: scripts for using [TINDA](https://www.biorxiv.org/content/10.1101/2023.07.25.550338v3).
- `toolbox_paper`: scripts for reproducing the results in the [eLife paper](https://elifesciences.org/reviewed-preprints/91949).
