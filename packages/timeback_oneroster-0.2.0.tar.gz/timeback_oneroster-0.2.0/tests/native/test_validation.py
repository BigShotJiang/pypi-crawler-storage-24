"""
OneRoster client-side validation tests.

Tests that validation happens in the resource layer (before transport)
using a stub transport. Mirrors the TS SDK validation.unit.test.ts.
"""

from __future__ import annotations

import pytest

from timeback_common import InputValidationError, validate_sourced_id
from timeback_oneroster.client import OneRosterClient
from timeback_oneroster.lib.testing import create_recording_transport


def _client() -> tuple[OneRosterClient, list[dict[str, str]]]:
    transport = create_recording_transport()
    return OneRosterClient(transport=transport), transport.calls


class TestPaginatorValidation:
    @pytest.mark.asyncio
    async def test_invalid_limit_throws_before_paginated_request(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users.list(limit=0)
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_invalid_offset_throws_before_paginated_request(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users.list(limit=100, offset=-1)
        assert len(calls) == 0


class TestSourcedIdValidation:
    def test_rejects_empty_string(self) -> None:
        with pytest.raises(InputValidationError):
            validate_sourced_id("", "get user")

    def test_rejects_whitespace(self) -> None:
        with pytest.raises(InputValidationError):
            validate_sourced_id("  ", "get user")

    def test_accepts_non_empty_string(self) -> None:
        validate_sourced_id("abc-123", "get user")


class TestUsersValidation:
    @pytest.mark.asyncio
    async def test_create_validates_input(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users.create({})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_get_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users("").get()
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_update_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users("").update({})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_delete_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users("").delete()
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_upsert_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users.upsert("", {})
        assert len(calls) == 0

    def test_scoped_user_validates_user_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            client.users("")
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_add_agent_validates_sourced_id(self) -> None:
        client, calls = _client()
        scoped = client.users("valid-user-id")
        with pytest.raises(InputValidationError):
            await scoped.add_agent({"agentSourcedId": ""})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_register_credential_validates_application_name(self) -> None:
        client, calls = _client()
        scoped = client.users("valid-user-id")
        with pytest.raises(InputValidationError):
            await scoped.register_credential(
                {"applicationName": "", "credentials": {"username": "", "password": ""}}
            )
        assert len(calls) == 0


class TestCoursesValidation:
    @pytest.mark.asyncio
    async def test_create_validates_input(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.courses.create({"sourcedId": "test-id"})
        assert len(calls) == 0


class TestClassesValidation:
    @pytest.mark.asyncio
    async def test_create_validates_input(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.classes.create({"title": "Test Class"})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_enroll_validates_sourced_id(self) -> None:
        client, calls = _client()
        scoped = client.classes("valid-class-id")
        with pytest.raises(InputValidationError):
            await scoped.enroll({"sourcedId": "", "role": "student"})
        assert len(calls) == 0


class TestSchoolsValidation:
    @pytest.mark.asyncio
    async def test_create_validates_name(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.schools.create({})
        assert len(calls) == 0


class TestDemographicsValidation:
    @pytest.mark.asyncio
    async def test_create_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.demographics.create({})
        assert len(calls) == 0


class TestResourcesValidation:
    @pytest.mark.asyncio
    async def test_create_validates_title_and_vendor_resource_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.resources.create({"title": "Title only"})
        assert len(calls) == 0
