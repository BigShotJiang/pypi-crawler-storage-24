"""Fixture-driven tests for OneRoster base resource defaults."""

from __future__ import annotations

from typing import Any

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_oneroster.lib.testing import create_recording_transport
from timeback_oneroster.resources.base import CRUDResource

FIXTURES_DIR = fixtures_dir("oneroster", "base-defaults")


class _BaseDefaultsResource(CRUDResource[dict[str, Any]]):
    @property
    def _unwrap_key(self) -> str:
        return "items"

    @property
    def _wrap_key(self) -> str:
        return "item"

    @property
    def _model_class(self) -> type[dict[str, Any]]:
        return dict  # type: ignore[return-value]

    def _transform(self, entity: dict[str, Any] | dict) -> dict[str, Any]:
        return entity  # type: ignore[return-value]


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    resource = _BaseDefaultsResource(transport, "rostering", "/items")
    return {"resource": resource, "calls": transport.calls}


test_oneroster_base_defaults_fixtures = make_resource_fixture_test(
    name="oneroster > base-defaults",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
