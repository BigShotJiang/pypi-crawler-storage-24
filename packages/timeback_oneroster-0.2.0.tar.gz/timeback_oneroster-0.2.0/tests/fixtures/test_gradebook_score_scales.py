"""Fixture-driven tests for OneRoster gradebook-score-scales resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_oneroster.client import OneRosterClient
from timeback_oneroster.lib.testing import create_recording_transport

FIXTURES_DIR = fixtures_dir("oneroster", "gradebook-score-scales")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    client = OneRosterClient(transport=transport)
    return {"resource": client.score_scales, "calls": transport.calls}


test_oneroster_gradebook_score_scales_fixtures = make_resource_fixture_test(
    name="oneroster > gradebook-score-scales",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
