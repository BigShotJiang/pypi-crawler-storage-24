"""Recording transport for fixture-driven OneRoster tests."""

from __future__ import annotations

from typing import Any

from test_support.transport_base import BaseRecordingTransport
from test_support.transport_helpers import dump_model
from timeback_common import OneRosterPaths

from ..types import (
    AcademicSession,
    AssessmentLineItem,
    AssessmentResult,
    Category,
    Class,
    ComponentResource,
    Course,
    CourseComponent,
    Demographics,
    Enrollment,
    LineItem,
    Organization,
    Resource,
    Result,
    ScoreScale,
    User,
)
from .transport import PaginatedResponse


def create_recording_transport(
    fail_request: dict[str, Any] | None = None,
    transport_config: dict[str, Any] | None = None,
) -> OneRosterRecordingTransport:
    """Create a recording transport for OneRoster fixture tests."""
    return OneRosterRecordingTransport(
        fail_request=fail_request,
        transport_config=transport_config,
    )


class OneRosterRecordingTransport(BaseRecordingTransport):
    """OneRoster recording transport with resource-scoped payload fragments."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.paths = OneRosterPaths()
        self._apply_exclude_paths()

    async def request_paginated(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        unwrap_key: str | None = None,
    ) -> PaginatedResponse:
        self._record(path, method="GET", params=params)
        self._maybe_fail("GET")
        payload = self._resolve_payload(path)
        if unwrap_key is None:
            return PaginatedResponse(data=[], has_more=False, total=0)
        data = payload.get(unwrap_key, [])
        if not isinstance(data, list):
            data = []
        return PaginatedResponse(data=data, has_more=False, total=len(data))

    async def exists(self, path: str) -> bool:
        self._record(path, method="GET")
        self._maybe_fail("GET")
        return True

    async def request_raw(self, method: str, path: str, **kwargs: Any) -> Any:
        del kwargs
        normalized = method.upper()
        self._record(path, method=normalized)
        self._maybe_fail(normalized)
        return RawResponse(content=b"stub-export")

    def _default_get_stub(self, path: str) -> dict[str, Any]:
        return self._resolve_payload(path)

    def _default_post_stub(self, path: str) -> dict[str, Any]:
        return self._resolve_payload(path)

    def _default_put_stub(self, path: str) -> dict[str, Any]:
        return self._resolve_payload(path)

    def _default_patch_stub(self, path: str) -> dict[str, Any]:
        return self._resolve_payload(path)

    def _default_delete_stub(self, path: str) -> dict[str, Any]:
        return self._resolve_payload(path)

    def _resolve_payload(self, path: str) -> dict[str, Any]:
        fragments = [_credential_payload()]
        for resolver in (
            _resolve_resources_fragment,
            _resolve_assessment_fragment,
            _resolve_gradebook_fragment,
            _resolve_rostering_fragment,
        ):
            fragment = resolver(path)
            if fragment is not None:
                fragments.append(fragment)
                return _merge_fragments(fragments)
        return _merge_fragments(fragments)


class RawResponse:
    """Minimal raw response shape for export endpoints."""

    def __init__(self, *, content: bytes) -> None:
        self.content = content


def _resolve_rostering_fragment(path: str) -> dict[str, Any] | None:
    markers = (
        "/users",
        "/teachers",
        "/students",
        "/schools",
        "/orgs",
        "/classes",
        "/courses",
        "/enrollments",
        "/demographics",
        "/academicSessions",
        "/terms",
        "/gradingPeriods",
    )
    if any(marker in path for marker in markers):
        return _rostering_payload_fragment()
    return None


def _resolve_gradebook_fragment(path: str) -> dict[str, Any] | None:
    markers = ("/lineItems", "/results", "/categories", "/scoreScales")
    if any(marker in path for marker in markers):
        return _gradebook_payload_fragment()
    return None


def _resolve_assessment_fragment(path: str) -> dict[str, Any] | None:
    markers = ("/assessmentLineItems", "/assessmentResults")
    if any(marker in path for marker in markers):
        return _assessment_payload_fragment()
    return None


def _resolve_resources_fragment(path: str) -> dict[str, Any] | None:
    markers = (
        "/resources",
        "/courseComponents",
        "/componentResources",
        "/courses/components",
        "/courses/component-resources",
        "/export/",
    )
    if any(marker in path for marker in markers):
        return _resources_payload_fragment()
    return None


def _credential_payload() -> dict[str, Any]:
    return {
        "sourcedId": "credential-001",
        "sourcedIdPairs": [{"sourcedId": "stub-001"}],
        "message": "ok",
        "userProfileId": "profile-001",
        "credentialId": "credential-001",
        "password": "secret",
    }


def _merge_fragments(fragments: list[dict[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for fragment in fragments:
        result.update(fragment)
    return result


def _assessment_line_item_stub() -> AssessmentLineItem:
    return AssessmentLineItem.model_validate(
        {
            "sourcedId": "assessment-line-item-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Assessment",
        }
    )


def _assessment_result_stub() -> AssessmentResult:
    return AssessmentResult.model_validate(
        {
            "sourcedId": "assessment-result-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "assessmentLineItem": {"sourcedId": "assessment-line-item-001"},
            "student": {"sourcedId": "student-001"},
            "scoreDate": "2024-09-01",
            "scoreStatus": "submitted",
        }
    )


def _assessment_payload_fragment() -> dict[str, object]:
    assessment_line_item = dump_model(_assessment_line_item_stub(), exclude_none=True)
    assessment_result = dump_model(_assessment_result_stub(), exclude_none=True)
    return {
        "assessmentLineItem": assessment_line_item,
        "assessmentLineItems": [assessment_line_item],
        "assessmentResult": assessment_result,
        "assessmentResults": [assessment_result],
    }


def _line_item_stub() -> LineItem:
    return LineItem.model_validate(
        {
            "sourcedId": "line-item-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Line Item",
            "class": {"sourcedId": "class-001"},
        }
    )


def _result_stub() -> Result:
    return Result.model_validate(
        {
            "sourcedId": "result-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "lineItem": {"sourcedId": "line-item-001"},
            "student": {"sourcedId": "student-001"},
        }
    )


def _category_stub() -> Category:
    return Category.model_validate(
        {
            "sourcedId": "category-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Homework",
        }
    )


def _score_scale_stub() -> ScoreScale:
    return ScoreScale.model_validate(
        {
            "sourcedId": "score-scale-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Points",
        }
    )


def _gradebook_payload_fragment() -> dict[str, object]:
    line_item = dump_model(_line_item_stub(), exclude_none=True)
    result = dump_model(_result_stub(), exclude_none=True)
    category = dump_model(_category_stub(), exclude_none=True)
    score_scale = dump_model(_score_scale_stub(), exclude_none=True)
    return {
        "lineItem": line_item,
        "lineItems": [line_item],
        "result": result,
        "results": [result],
        "category": category,
        "categories": [category],
        "scoreScale": score_scale,
        "scoreScales": [score_scale],
    }


def _resource_stub() -> Resource:
    return Resource.model_validate(
        {
            "sourcedId": "resource-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Resource A",
            "vendorResourceId": "vendor-resource-001",
        }
    )


def _course_component_stub() -> CourseComponent:
    return CourseComponent.model_validate(
        {
            "sourcedId": "component-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Component A",
            "course": {"sourcedId": "course-001"},
        }
    )


def _component_resource_stub() -> ComponentResource:
    return ComponentResource.model_validate(
        {
            "sourcedId": "component-resource-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Component Resource A",
            "courseComponent": {"sourcedId": "component-001"},
            "resource": {"sourcedId": "resource-001"},
        }
    )


def _resources_payload_fragment() -> dict[str, object]:
    resource = dump_model(_resource_stub(), exclude_none=True)
    course_component = dump_model(_course_component_stub(), exclude_none=True)
    component_resource = dump_model(_component_resource_stub(), exclude_none=True)
    return {
        "resource": resource,
        "resources": [resource],
        "courseComponent": course_component,
        "courseComponents": [course_component],
        "componentResource": component_resource,
        "componentResources": [component_resource],
    }


def _user_stub() -> User:
    return User.model_validate(
        {
            "sourcedId": "user-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "givenName": "Test",
            "familyName": "User",
            "enabledUser": True,
        }
    )


def _org_stub() -> Organization:
    return Organization.model_validate(
        {
            "sourcedId": "org-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "name": "Test School",
            "type": "school",
        }
    )


def _class_stub() -> Class:
    return Class.model_validate(
        {
            "sourcedId": "class-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Class A",
            "classCode": "CLS-A",
        }
    )


def _enrollment_stub() -> Enrollment:
    return Enrollment.model_validate(
        {
            "sourcedId": "enrollment-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "user": {"sourcedId": "user-001"},
            "class": {"sourcedId": "class-001"},
            "role": "student",
        }
    )


def _course_stub() -> Course:
    return Course.model_validate(
        {
            "sourcedId": "course-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Course A",
        }
    )


def _academic_session_stub() -> AcademicSession:
    return AcademicSession.model_validate(
        {
            "sourcedId": "session-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Fall 2024",
            "type": "term",
            "startDate": "2024-08-15",
            "endDate": "2024-12-20",
        }
    )


def _term_stub() -> AcademicSession:
    return AcademicSession.model_validate(
        {
            "sourcedId": "term-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Term 1",
            "type": "term",
            "startDate": "2024-08-15",
            "endDate": "2024-12-20",
        }
    )


def _grading_period_stub() -> AcademicSession:
    return AcademicSession.model_validate(
        {
            "sourcedId": "grading-period-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
            "title": "Q1",
            "type": "gradingPeriod",
            "startDate": "2024-08-15",
            "endDate": "2024-10-20",
        }
    )


def _demographics_stub() -> Demographics:
    return Demographics.model_validate(
        {
            "sourcedId": "demographics-001",
            "status": "active",
            "dateLastModified": "2024-01-01T00:00:00Z",
        }
    )


def _rostering_payload_fragment() -> dict[str, object]:
    user = dump_model(_user_stub(), exclude_none=True)
    org = dump_model(_org_stub(), exclude_none=True)
    cls = dump_model(_class_stub(), exclude_none=True)
    course = dump_model(_course_stub(), exclude_none=True)
    enrollment = dump_model(_enrollment_stub(), exclude_none=True)
    academic_session = dump_model(_academic_session_stub(), exclude_none=True)
    term = dump_model(_term_stub(), exclude_none=True)
    grading_period = dump_model(_grading_period_stub(), exclude_none=True)
    demographics = dump_model(_demographics_stub(), exclude_none=True)
    return {
        "user": user,
        "users": [user],
        "org": org,
        "orgs": [org],
        "class": cls,
        "classes": [cls],
        "course": course,
        "courses": [course],
        "enrollment": enrollment,
        "enrollments": [enrollment],
        "academicSession": academic_session,
        "academicSessions": [academic_session],
        "term": term,
        "terms": [term],
        "gradingPeriod": grading_period,
        "gradingPeriods": [grading_period],
        "demographics": demographics,
    }


__all__ = ["OneRosterRecordingTransport", "create_recording_transport"]
