"""
Categories Resource

Access and manage grade categories.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from timeback_common import APIError, NotFoundError, validate_sourced_id

from ...types import CategoryCreateInput
from ...types.gradebook import Category
from ..base import CRUDResourceNoSearch

if TYPE_CHECKING:
    from pydantic import BaseModel

    from ...lib.transport import Transport


# ═══════════════════════════════════════════════════════════════════════════════
# SCOPED CATEGORY RESOURCE
# ═══════════════════════════════════════════════════════════════════════════════


class ScopedCategoryResource:
    """
    Scoped resource for operations on a specific category.

    Access via `client.categories(category_id)`.

    Example:
        ```python
        category = await client.categories(category_id).get()
        ```
    """

    def __init__(self, transport: Transport, category_id: str) -> None:
        self._transport = transport
        self._category_id = category_id
        self._base_path = f"{transport.paths.gradebook}/categories/{category_id}"

    async def get(self) -> Category:
        """Get the category details."""
        response = await self._transport.get(self._base_path)
        return Category(**response["category"])

    async def exists(self) -> bool:
        """Check whether this category exists."""
        return await self._transport.exists(self._base_path)

    async def delete(self) -> None:
        """Delete this category."""
        await self._transport.delete(self._base_path)


# ═══════════════════════════════════════════════════════════════════════════════
# CATEGORIES RESOURCE
# ═══════════════════════════════════════════════════════════════════════════════


class CategoriesResource(CRUDResourceNoSearch[Category]):
    """
    Resource for grade categories.

    Categories organize line items (e.g., "Homework", "Tests", "Quizzes").

    Example:
        ```python
        # List all categories
        categories = await client.categories.list()

        # Get specific category
        category = await client.categories.get("category-id")

        # Create a category
        await client.categories.create({
            "title": "Homework",
        })
        ```
    """

    def __init__(self, transport: Transport) -> None:
        super().__init__(transport, "gradebook", "/categories")

    @property
    def _unwrap_key(self) -> str:
        return "categories"

    @property
    def _wrap_key(self) -> str:
        return "category"

    @property
    def _model_class(self) -> type[Category]:
        return Category

    @property
    def _create_schema(self) -> type[BaseModel]:
        """Pydantic model for validating category create input."""
        return CategoryCreateInput

    @property
    def _update_schema(self) -> type[BaseModel]:
        """Pydantic model for validating category update input."""
        return CategoryCreateInput

    @property
    def _server_natively_upserts(self) -> bool:
        return True

    async def update(self, sourced_id: str, data: dict[str, Any]) -> Category:
        """Update a category and return the updated entity."""
        validate_sourced_id(sourced_id, "update categories")
        await self._ensure_exists_for_update(sourced_id)
        return await self._send_update_and_return(sourced_id, data)

    async def upsert(self, sourced_id: str, data: dict[str, Any]) -> Category:
        """Create or update a category, returning the entity."""
        validate_sourced_id(sourced_id, "upsert categories")
        full_data = {**data, "sourcedId": sourced_id}
        try:
            return await self._send_update_and_return(sourced_id, full_data)
        except NotFoundError:
            await self.create(full_data)
            return await self.get(sourced_id)
        except APIError as error:
            if error.status_code != 404:
                raise
            await self.create(full_data)
            return await self.get(sourced_id)

    def __call__(self, category_id: str) -> ScopedCategoryResource:
        """Get scoped resource for a specific category."""
        return ScopedCategoryResource(self._transport, category_id)
