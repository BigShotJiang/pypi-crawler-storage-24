"""
Assessment Results Resource

Access and manage standardized assessment results.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from timeback_common import APIError, NotFoundError, validate_sourced_id

from ...types.assessment import AssessmentResult
from ..base import CRUDResourceNoSearch

if TYPE_CHECKING:
    from ...lib.transport import Transport


# ═══════════════════════════════════════════════════════════════════════════════
# ASSESSMENT RESULTS RESOURCE
# ═══════════════════════════════════════════════════════════════════════════════


class AssessmentResultsResource(CRUDResourceNoSearch[AssessmentResult]):
    """
    Resource for assessment results.

    Assessment results record scores for formal assessments.

    Example:
        ```python
        # List all assessment results
        results = await client.assessment_results.list()

        # Get specific assessment result
        result = await client.assessment_results.get("result-id")

        # Create an assessment result
        await client.assessment_results.create({
            "assessmentLineItem": {"sourcedId": "line-item-id"},
            "student": {"sourcedId": "student-id"},
            "score": 85.5,
            "scoreStatus": "fully graded",
            "scoreDate": "2024-01-22",
        })

        # Filter by student
        student_results = await client.assessment_results.list(
            filter="student.sourcedId='student-id'"
        )

        # Patch a result
        await client.assessment_results.patch("result-id", {
            "score": 90.0,
        })
        ```
    """

    def __init__(self, transport: Transport) -> None:
        super().__init__(transport, "gradebook", "/assessmentResults")

    @property
    def _unwrap_key(self) -> str:
        return "assessmentResults"

    @property
    def _wrap_key(self) -> str:
        return "assessmentResult"

    @property
    def _model_class(self) -> type[AssessmentResult]:
        return AssessmentResult

    @property
    def _create_schema(self) -> type[BaseModel] | None:
        return _AssessmentResultMinimalInput

    @property
    def _update_schema(self) -> type[BaseModel] | None:
        return _AssessmentResultMinimalInput

    @property
    def _server_natively_upserts(self) -> bool:
        return True

    async def update(self, sourced_id: str, data: dict[str, Any]) -> AssessmentResult:
        """Update an assessment result and return the updated entity."""
        validate_sourced_id(sourced_id, "update assessmentResults")
        await self._ensure_exists_for_update(sourced_id)
        return await self._send_update_and_return(sourced_id, data)

    async def upsert(self, sourced_id: str, data: dict[str, Any]) -> AssessmentResult:
        """Create or update an assessment result, returning the entity."""
        validate_sourced_id(sourced_id, "upsert assessmentResults")
        full_data = {**data, "sourcedId": sourced_id}
        try:
            return await self._send_update_and_return(sourced_id, full_data)
        except NotFoundError:
            await self.create(full_data)
            return await self.get(sourced_id)
        except APIError as error:
            if error.status_code != 404:
                raise
            await self.create(full_data)
            return await self.get(sourced_id)

    async def patch(self, sourced_id: str, data: dict[str, Any]) -> None:
        """
        Partially update an assessment result.

        Only the fields provided will be updated. Other fields remain unchanged.

        Args:
            sourced_id: The assessment result sourcedId
            data: The fields to update
        """
        validate_sourced_id(sourced_id, "patch assessmentResult")
        body = {self._wrap_key: data}
        await self._transport.patch(f"{self._base_path}/{sourced_id}", body)


class _AssessmentResultMinimalInput(BaseModel):
    assessment_line_item: dict[str, Any] = Field(alias="assessmentLineItem")
    student: dict[str, Any]
    score_date: str = Field(alias="scoreDate", min_length=1)
    score_status: Literal[
        "exempt", "fully graded", "not submitted", "partially graded", "submitted"
    ] = Field(alias="scoreStatus")

    model_config = ConfigDict(extra="allow", populate_by_name=True)
