from inr_formatter import format_inr, format_inr_with_symbol, format_inr_full

def test_basic():
    assert format_inr(8194325) == "81,94,325"
    assert format_inr(1000) == "1,000"
    assert format_inr(100) == "100"
    assert format_inr(1000000) == "10,00,000"

def test_negative():
    assert format_inr(-8194325) == "-81,94,325"

def test_with_symbol():
    assert format_inr_with_symbol(8194325) == "₹81,94,325"

def test_with_decimals():
    assert format_inr_full(8194325.50) == "₹81,94,325.50"

print("✅ All tests passed!")
test_basic()
test_negative()
test_with_symbol()
test_with_decimals()
print("✅ All tests passed!")