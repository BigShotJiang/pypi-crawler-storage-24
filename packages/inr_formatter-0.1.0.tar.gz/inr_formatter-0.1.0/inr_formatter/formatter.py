def format_inr(amount):
    """
    Format a number in Indian numbering system.
    
    Example:
        >>> format_inr(8194325)
        '81,94,325'
        >>> format_inr(1000)
        '1,000'
    """
    amount = int(amount)
    if amount < 0:
        return "-" + format_inr(-amount)
    s = str(amount)
    if len(s) <= 3:
        return s
    last3 = s[-3:]
    rest = s[:-3]
    result = ""
    for i, digit in enumerate(reversed(rest)):
        if i > 0 and i % 2 == 0:
            result = "," + result
        result = digit + result
    return result + "," + last3


def format_inr_with_symbol(amount, symbol="₹"):
    """
    Format number in Indian style with currency symbol.
    
    Example:
        >>> format_inr_with_symbol(8194325)
        '₹81,94,325'
    """
    return f"{symbol}{format_inr(amount)}"


def format_inr_full(amount, symbol="₹", decimals=2):
    """
    Format number in Indian style with symbol and decimals.
    
    Example:
        >>> format_inr_full(8194325.50)
        '₹81,94,325.50'
    """
    decimal_part = round(amount % 1, decimals)
    decimal_str = f"{decimal_part:.{decimals}f}"[1:]
    return f"{symbol}{format_inr(int(amount))}{decimal_str}"