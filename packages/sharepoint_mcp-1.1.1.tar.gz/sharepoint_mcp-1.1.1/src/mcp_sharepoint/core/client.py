"""SharePoint client factory supporting Office365, Graph REST, and GraphQL APIs.

Provides a unified interface for SharePoint operations using:
- Office365 REST API (legacy/traditional)
- Microsoft Graph REST API (modern)
- Microsoft Graph GraphQL API (for organizations requiring GraphQL)
"""
from __future__ import annotations

import logging
from functools import lru_cache
from typing import Any, Protocol
from urllib.parse import urlparse

import msal
import requests
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.client_context import ClientContext

from ..config import get_settings
from ..exceptions import SharePointConnectionError

logger = logging.getLogger(__name__)


class SharePointClient(Protocol):
    """Protocol defining the interface for SharePoint clients."""
    
    api_type: str
    
    def __repr__(self) -> str:
        """String representation of the client."""
        ...


class Office365Client:
    """Wrapper for Office365 REST API ClientContext."""
    
    def __init__(self, ctx: ClientContext):
        """Initialize with Office365 ClientContext.
        
        Args:
            ctx: Authenticated ClientContext instance
        """
        self.ctx = ctx
        self.api_type = "office365"
    
    def __repr__(self) -> str:
        return f"Office365Client(site={self.ctx.base_url})"


class GraphClient:
    """Microsoft Graph API client for SharePoint operations."""

    def __init__(self, access_token: str, site_url: str):
        """Initialize Graph client with access token and site URL.
        
        Args:
            access_token: Microsoft Graph API access token
            site_url: SharePoint site URL
        """
        self.access_token = access_token
        self.site_url = site_url
        self.base_url = "https://graph.microsoft.com/v1.0"
        self.api_type = "graph"
        
        # Extract site components from URL
        parsed = urlparse(site_url)
        self.hostname = parsed.netloc
        # Extract site path (e.g., /sites/sitename)
        self.site_path = parsed.path.rstrip('/')
        
        self.headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        
        # Cache site ID
        self._site_id_cache: str | None = None
        
    def _get_site_id(self) -> str:
        """Get the SharePoint site ID from the site URL (cached)."""
        if self._site_id_cache:
            return self._site_id_cache
            
        # Format: /sites/{hostname}:{site_path}
        site_resource = f"{self.hostname}:{self.site_path}"
        url = f"{self.base_url}/sites/{site_resource}"
        
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            response.raise_for_status()
            self._site_id_cache = response.json().get("id", "")
            return self._site_id_cache
        except Exception as exc:
            logger.error(f"Failed to get site ID: {exc}")
            # Fallback: try root site
            try:
                url = f"{self.base_url}/sites/{self.hostname}:{self.site_path}"
                response = requests.get(url, headers=self.headers, timeout=30)
                response.raise_for_status()
                self._site_id_cache = response.json().get("id", "")
                return self._site_id_cache
            except Exception as e:
                logger.error(f"Fallback site ID lookup failed: {e}")
                raise SharePointConnectionError(f"Cannot determine site ID: {exc}") from exc
    
    def get(self, endpoint: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Make a GET request to Graph API.
        
        Args:
            endpoint: API endpoint (relative to base_url)
            params: Optional query parameters
            
        Returns:
            Response JSON data
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.get(url, headers=self.headers, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as exc:
            logger.error(f"GET {url} failed: {exc}")
            if hasattr(exc, 'response') and exc.response is not None:
                logger.error(f"Response: {exc.response.text}")
            raise SharePointConnectionError(f"Graph API GET failed: {exc}") from exc
    
    def post(self, endpoint: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
        """Make a POST request to Graph API.
        
        Args:
            endpoint: API endpoint (relative to base_url)
            data: Request body data
            
        Returns:
            Response JSON data
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.post(url, headers=self.headers, json=data, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as exc:
            logger.error(f"POST {url} failed: {exc}")
            if hasattr(exc, 'response') and exc.response is not None:
                logger.error(f"Response: {exc.response.text}")
            raise SharePointConnectionError(f"Graph API POST failed: {exc}") from exc
    
    def put(self, endpoint: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
        """Make a PUT request to Graph API.
        
        Args:
            endpoint: API endpoint (relative to base_url)
            data: Request body data
            
        Returns:
            Response JSON data
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.put(url, headers=self.headers, json=data, timeout=30)
            response.raise_for_status()
            return response.json() if response.content else {}
        except requests.exceptions.RequestException as exc:
            logger.error(f"PUT {url} failed: {exc}")
            if hasattr(exc, 'response') and exc.response is not None:
                logger.error(f"Response: {exc.response.text}")
            raise SharePointConnectionError(f"Graph API PUT failed: {exc}") from exc
    
    def delete(self, endpoint: str) -> bool:
        """Make a DELETE request to Graph API.
        
        Args:
            endpoint: API endpoint (relative to base_url)
            
        Returns:
            True if successful
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.delete(url, headers=self.headers, timeout=30)
            response.raise_for_status()
            return True
        except requests.exceptions.RequestException as exc:
            logger.error(f"DELETE {url} failed: {exc}")
            if hasattr(exc, 'response') and exc.response is not None:
                logger.error(f"Response: {exc.response.text}")
            raise SharePointConnectionError(f"Graph API DELETE failed: {exc}") from exc
    
    def download(self, endpoint: str) -> bytes:
        """Download binary content from Graph API.
        
        Args:
            endpoint: API endpoint (relative to base_url)
            
        Returns:
            Binary content
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.get(url, headers=self.headers, timeout=60)
            response.raise_for_status()
            return response.content
        except requests.exceptions.RequestException as exc:
            logger.error(f"Download from {url} failed: {exc}")
            raise SharePointConnectionError(f"Graph API download failed: {exc}") from exc
    
    def upload(self, endpoint: str, content: bytes) -> dict[str, Any]:
        """Upload binary content to Graph API.
        
        Args:
            endpoint: API endpoint (relative to base_url)
            content: Binary content to upload
            
        Returns:
            Response JSON data
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/octet-stream",
        }
        try:
            response = requests.put(url, headers=headers, data=content, timeout=60)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as exc:
            logger.error(f"Upload to {url} failed: {exc}")
            if hasattr(exc, 'response') and exc.response is not None:
                logger.error(f"Response: {exc.response.text}")
            raise SharePointConnectionError(f"Graph API upload failed: {exc}") from exc
    
    def __repr__(self) -> str:
        return f"GraphClient(site={self.site_url})"


@lru_cache(maxsize=1)
def get_sp_context() -> Office365Client | GraphClient:
    """Return a cached, authenticated SharePoint client.

    The client type is determined by the SHP_API_TYPE environment variable:
    - "office365" (default): Uses Office365 REST API
    - "graph": Uses Microsoft Graph REST API
    - "graphql": Uses Microsoft Graph GraphQL API

    Raises:
        SharePointConnectionError: if the client cannot be established.
    """
    settings = get_settings()
    
    if settings.shp_api_type == "graphql":
        logger.info("Using Microsoft Graph GraphQL API client")
        from .client_graphql import create_graphql_client
        return create_graphql_client(settings)
    elif settings.shp_api_type == "graph":
        logger.info("Using Microsoft Graph REST API client")
        return _create_graph_client(settings)
    else:
        logger.info("Using Office365 REST API client")
        return _create_office365_client(settings)


def _create_office365_client(settings) -> Office365Client:
    """Create an Office365 REST API client."""
    try:
        credentials = ClientCredential(settings.shp_id_app, settings.shp_id_app_secret)
        ctx = ClientContext(settings.shp_site_url).with_credentials(credentials)
        logger.info("Office365 client context initialized for %s", settings.shp_site_url)
        return Office365Client(ctx)
    except Exception as exc:
        msg = f"Failed to create Office365 client: {exc}"
        logger.error(msg)
        raise SharePointConnectionError(msg) from exc


def _create_graph_client(settings) -> GraphClient:
    """Create a Microsoft Graph API client."""
    try:
        # Create MSAL confidential client application
        app = msal.ConfidentialClientApplication(
            settings.shp_id_app,
            authority=f"https://login.microsoftonline.com/{settings.shp_tenant_id}",
            client_credential=settings.shp_id_app_secret,
        )
        
        # Acquire token for Microsoft Graph
        scopes = ["https://graph.microsoft.com/.default"]
        result = app.acquire_token_for_client(scopes=scopes)
        
        if "access_token" not in result:
            error_desc = result.get("error_description", "Unknown error")
            raise SharePointConnectionError(f"Failed to acquire access token: {error_desc}")
        
        access_token = result["access_token"]
        client = GraphClient(access_token, settings.shp_site_url)
        
        logger.info("Microsoft Graph API client initialized for %s", settings.shp_site_url)
        return client
        
    except Exception as exc:
        msg = f"Failed to create Graph API client: {exc}"
        logger.error(msg)
        raise SharePointConnectionError(msg) from exc
