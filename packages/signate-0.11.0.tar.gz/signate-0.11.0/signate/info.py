#!/usr/bin/python

NAME = 'SIGNATE CLI'
VERSION = '0.11.0'
