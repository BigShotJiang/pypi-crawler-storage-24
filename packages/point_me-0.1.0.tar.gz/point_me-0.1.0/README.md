# point-me

CLI and Python library for searching award flight availability on [point.me](https://point.me).

## Auth

Log in to point.me in your browser. The CLI automatically reads your session cookie from Firefox and exchanges it for an API token. No manual token copying needed.

Use `--browser chrome` (or `opera`, `edge`, `chromium`) if you don't use Firefox. You can also pass a token directly with `--token` or the `POINTME_TOKEN` env var.

## Usage

```bash
# One-way search
uvx point-me search JFK NRT 2026-04-01 business

# Roundtrip
uvx point-me search JFK NRT 2026-04-01 business --return-date 2026-04-15

# Filter and sort
uvx point-me search JFK NRT 2026-04-01 business --max-stops 1 --max-miles 100000 --sort miles

# Filter by program
uvx point-me search JFK NRT 2026-04-01 business --program united

# JSON output
uvx point-me search JFK NRT 2026-04-01 business --json
```

Cabin options: `economy`, `premium-economy`, `business`, `first`.

## Library

```python
import asyncio
from point_me import PointMeClient

async def main():
    client = PointMeClient(token="your-token")
    routes = await client.search("JFK", "NRT", "2026-04-01", "business")
    for route in routes:
        for fare in route.fares:
            print(f"{fare.program_name}: {fare.miles:,} miles")

asyncio.run(main())
```
