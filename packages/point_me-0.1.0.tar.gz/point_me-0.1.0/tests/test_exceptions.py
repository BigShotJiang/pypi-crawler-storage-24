from __future__ import annotations

import pytest

from point_me import AuthError, PointMeError, SearchError, StreamError
from tests.conftest import sse_bytes


def test_exception_hierarchy():
    assert issubclass(AuthError, PointMeError)
    assert issubclass(SearchError, PointMeError)
    assert issubclass(PointMeError, Exception)


def test_catch_base_exception():
    with pytest.raises(PointMeError):
        raise AuthError("test")
    with pytest.raises(PointMeError):
        raise SearchError("test")


def test_stream_error_hierarchy():
    assert issubclass(StreamError, SearchError)
    assert issubclass(StreamError, PointMeError)
    assert issubclass(StreamError, Exception)


def test_catch_search_error_catches_stream_error():
    with pytest.raises(SearchError):
        raise StreamError("timed out")


def test_sse_bytes_produces_valid_wire_format():
    result = sse_bytes(("SEARCH", '{"stops": 0}'), ("COMPLETE", ""))
    assert b"event: SEARCH\n" in result
    assert b'data: {"stops": 0}\n\n' in result
    assert b"event: COMPLETE\n" in result
    assert b"data: \n\n" in result
