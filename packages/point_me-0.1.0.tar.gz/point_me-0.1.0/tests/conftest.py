from __future__ import annotations

import json


def sse_bytes(*events: tuple[str, str]) -> bytes:
    """Build a valid SSE response body from (event_type, data) tuples."""
    lines: list[str] = []
    for event_type, data in events:
        lines.append(f"event: {event_type}\ndata: {data}\n\n")
    return "".join(lines).encode()


async def async_sse_stream(body: bytes):
    """Async generator that yields SSE body bytes."""
    yield body


def _wrap_routes(*routes: dict) -> str:
    """Wrap route dicts in the SSE SEARCH event envelope."""
    return json.dumps({
        "request_id": 12345,
        "routes": list(routes),
        "metrics": {"sites": []},
        "status": "",
        "user_ref": "test-ref",
    })


_ROUTE_1STOP = {
    "ulid": "route-1stop",
    "num_stops": 1,
    "times": {"flight": "8:00", "layover": "2:00"},
    "connections": [
        {
            "departure": {"when": "2026-05-01T10:00:00Z", "airport": "JFK"},
            "arrival": {"when": "2026-05-01T18:00:00Z", "airport": "LHR"},
            "airline": "BA",
            "flight": ["BA178"],
            "cabin": "business",
            "aircraft": {"model": "Boeing 777", "manufacturer": "Boeing"},
        }
    ],
    "fares": [
        {
            "miles": 60000,
            "program": "Avios",
            "program_key": "AVIOS",
            "payment": {"currency": "USD", "taxes": 200.0, "fees": 0},
            "transfer": [],
        }
    ],
}

_ROUTE_NONSTOP = {
    "ulid": "route-nonstop",
    "num_stops": 0,
    "times": {"flight": "5:00", "layover": "0:0"},
    "connections": [
        {
            "departure": {"when": "2026-05-01T09:00:00Z", "airport": "JFK"},
            "arrival": {"when": "2026-05-01T14:00:00Z", "airport": "LHR"},
            "airline": "BA",
            "flight": ["BA117"],
            "cabin": "business",
        }
    ],
    "fares": [
        {
            "miles": 40000,
            "program": "Air Canada Aeroplan",
            "program_key": "AEROPLAN",
            "payment": {"currency": "USD", "taxes": 100.0, "fees": 0},
            "transfer": [],
        },
        {
            "miles": 70000,
            "program": "Avios",
            "program_key": "AVIOS",
            "payment": {"currency": "USD", "taxes": 150.0, "fees": 0},
            "transfer": [],
        },
    ],
}

_ROUTE_NONE_DURATION = {
    "ulid": "route-none-dur",
    "num_stops": 2,
    "times": {"flight": "0:0", "layover": "0:0"},
    "connections": [
        {
            "departure": {"when": "2026-05-01T12:00:00Z", "airport": "SFO"},
            "arrival": {"when": "2026-05-02T06:00:00Z", "airport": "NRT"},
            "airline": "NH",
            "flight": ["NH7"],
            "cabin": "business",
        }
    ],
    "fares": [
        {
            "miles": 90000,
            "program": "ANA Mileage Club",
            "program_key": "ANA",
            "payment": {"currency": "USD", "taxes": 300.0, "fees": 0},
            "transfer": [],
        },
    ],
}

SAMPLE_ROUTE_JSON = _wrap_routes(_ROUTE_1STOP)
SAMPLE_ROUTE_NONSTOP = _wrap_routes(_ROUTE_NONSTOP)
SAMPLE_ROUTE_NONE_DURATION = _wrap_routes(_ROUTE_NONE_DURATION)

INITIATE_SEARCH_RESPONSE = json.dumps({
    "user_search_request_id": "test-user-req",
    "search_key": "test-search-key",
    "fsr_request_id": 12345,
})
