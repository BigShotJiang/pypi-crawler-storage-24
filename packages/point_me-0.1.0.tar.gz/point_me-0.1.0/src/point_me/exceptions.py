class PointMeError(Exception):
    """Base exception for all point-me errors."""


class AuthError(PointMeError):
    """Authentication failed - token missing, expired, or invalid."""


class SearchError(PointMeError):
    """Search request failed or response could not be parsed."""


class StreamError(SearchError):
    """SSE stream timed out or was interrupted."""
