def main():
    print("Hello from points-me!")


if __name__ == "__main__":
    main()
