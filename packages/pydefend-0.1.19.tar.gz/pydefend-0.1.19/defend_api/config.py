from functools import lru_cache
from pathlib import Path
from typing import Any, List, Optional

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field, ValidationError, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from .schemas import GuardAction, ProviderName


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Service
    DEFEND_API_HOST: str = "0.0.0.0"
    DEFEND_API_PORT: int = 8000

    # Models (local Defend HF classifier; requires pip install pydefend[local])
    DEFEND_MODEL_ID: str = "Adaxer/defend"

    # Thresholds
    INTENT_FASTPASS_THRESHOLD: float = 0.85
    INTENT_FASTPASS_ENABLED: bool = True
    INTENT_SAFE_PASS_SKIP_CLASSIFIER: bool = False
    REGEX_BLOCK_THRESHOLD: float = 0.9
    REGEX_FLAG_THRESHOLD: float = 0.6
    # Block immediately if regex match occurs
    REGEX_BLOCK_CATEGORIES: List[str] = Field(default_factory=lambda: ["system_prompt_extraction"])
    # Flag when we see multiple independent matches
    REGEX_FLAG_MIN_MATCHES: int = 2

    # Defend model runtime caps 
    DEFEND_MAX_INPUT_TOKENS: int = 1024
    DEFEND_INJECTION_THRESHOLD: float = 0.5

    # Semantic provider input caps 
    ANTHROPIC_MAX_INPUT_TOKENS: int = 2048
    OPENAI_MAX_INPUT_TOKENS: int = 2048

    # LLM providers
    ANTHROPIC_API_KEY: Optional[str] = None
    OPENAI_API_KEY: Optional[str] = None

    # Sessions
    SESSION_TTL_SECONDS: int = 1800
    SESSION_BLOCK_THRESHOLD: int = 3


class ModelsConfig(BaseModel):
    """
    Optional provider model overrides.

    When absent, providers use their built-in defaults.
    """

    claude: Optional[str] = None
    openai: Optional[str] = None


class GuardsInputConfig(BaseModel):
    provider: Optional[ProviderName] = None
    modules: List[Any] = Field(default_factory=list)


class GuardsOutputConfig(BaseModel):
    enabled: bool = False
    provider: Optional[ProviderName] = None
    modules: List[Any] = Field(default_factory=list)
    on_fail: GuardAction = GuardAction.BLOCK  # block | flag

    @field_validator("provider")
    @classmethod
    def validate_output_provider(cls, v: Optional[ProviderName]) -> Optional[ProviderName]:
        if v is None:
            return v
        if v not in {ProviderName.CLAUDE, ProviderName.OPENAI}:
            raise ValueError("guards.output.provider must be 'claude', or 'openai'")
        return v

    @field_validator("on_fail")
    @classmethod
    def validate_on_fail(cls, v: GuardAction) -> GuardAction:
        if v not in {GuardAction.BLOCK, GuardAction.FLAG}:
            raise ValueError("guards.output.on_fail must be 'block' or 'flag'")
        return v


class GuardsConfig(BaseModel):
    input: GuardsInputConfig = GuardsInputConfig()
    output: GuardsOutputConfig = GuardsOutputConfig()
    session_ttl_seconds: int = 300


class DefendConfig(BaseModel):
    provider: ProviderName
    models: ModelsConfig = ModelsConfig()
    guards: GuardsConfig = GuardsConfig()

    @field_validator("provider")
    @classmethod
    def validate_provider(cls, v: ProviderName) -> ProviderName:
        if v not in {ProviderName.DEFEND, ProviderName.CLAUDE, ProviderName.OPENAI}:
            raise ValueError("provider must be one of 'defend', 'claude', or 'openai'")
        return v

    @property
    def input_provider(self) -> ProviderName:
        return self.guards.input.provider or self.provider

    @property
    def output_provider(self) -> ProviderName:
        return self.guards.output.provider or self.provider


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    # Load `.env` into os.environ so SDK clients (OpenAI, Anthropic, etc.) see the same
    # keys as shell-exported variables. Pydantic Settings only maps declared fields;
    # undeclared keys in `.env` would otherwise be invisible to those clients.
    env_path = Path(".env")
    if env_path.is_file():
        load_dotenv(env_path, encoding="utf-8")
    return Settings()


@lru_cache(maxsize=1)
def get_defend_config() -> DefendConfig:
    config_path = Path("defend.config.yaml")
    if not config_path.exists():
        raise ValueError(
            "defend.config.yaml not found in project root. Open https://www.pydefend.com/#getting-started "
            'to create a config token, then run `defend init --token "defend_v1_..."`.'
        )

    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    try:
        return DefendConfig.model_validate(raw)
    except ValidationError as exc:  # pragma: no cover - defensive
        raise ValueError(f"Invalid defend.config.yaml: {exc}") from exc

