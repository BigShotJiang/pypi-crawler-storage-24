from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Tuple

import regex as re

from ..config import get_settings

IntentLabel = Literal["benign", "neutral", "suspicious"]

# High-signal substrings for prompt-injection / jailbreak-style intent.
_STRONG_PHRASES: Tuple[str, ...] = (
    "ignore all previous",
    "ignore previous",
    "disregard previous",
    "disregard all previous",
    "forget your instructions",
    "forget previous",
    "system prompt",
    "reveal your prompt",
    "show your prompt",
    "reveal your instructions",
    "show your instructions",
    "you are now in",
    "developer mode",
    "dan mode",
    "jailbreak",
    "bypass your",
    "bypass your safety",
    "roleplay as",
    "simulate being",
    "no restrictions",
    "without restrictions",
    "sudo mode",
    "root access",
    "new instructions:",
    "base64 decode and",
)

# Softer signals — smaller penalty each.
_WEAK_PHRASES: Tuple[str, ...] = (
    "override",
    "pretend you are",
    "act as if you",
    "you must ignore",
    "do not follow",
    "disobey",
    "unfiltered",
    "without ethical",
)

# Single tokens where substring match is too noisy; use word-boundary regex.
_STRONG_TOKENS: Tuple[str, ...] = (
    r"\bdan\b",
    r"\bjailbreak\b",
)


def _count_phrase_hits(text_lower: str, phrases: Tuple[str, ...]) -> int:
    return sum(1 for p in phrases if p in text_lower)


def _count_token_patterns(text: str, patterns: Tuple[str, ...]) -> int:
    return sum(1 for pat in patterns if re.search(pat, text, flags=re.IGNORECASE))


@dataclass(frozen=True)
class _HeuristicSignals:
    strong_hits: int
    weak_hits: int


def _compute_signals(text: str) -> _HeuristicSignals:
    stripped = text.strip()
    if not stripped:
        return _HeuristicSignals(0, 0)

    lower = stripped.lower()
    strong = _count_phrase_hits(lower, _STRONG_PHRASES) + _count_token_patterns(stripped, _STRONG_TOKENS)
    weak = _count_phrase_hits(lower, _WEAK_PHRASES)
    return _HeuristicSignals(strong_hits=min(strong, 8), weak_hits=min(weak, 8))


def classify_heuristic_intent(text: str) -> Tuple[IntentLabel, float]:
    """
    Lightweight L2 intent signal without ML dependencies.

    Produces a benign confidence score in [0, 1] and a coarse label. The
    safe-pass gate still requires agreement with regex (see pipeline orchestrator).
    """
    settings = get_settings()
    threshold = float(getattr(settings, "INTENT_FASTPASS_THRESHOLD", 0.85))

    signals = _compute_signals(text)
    # Penalize confidence per hit; strong signals weigh more than weak.
    penalty = 0.34 * signals.strong_hits + 0.09 * signals.weak_hits
    benign_score = max(0.0, min(1.0, 1.0 - penalty))

    if benign_score < 0.35 or signals.strong_hits >= 2:
        label: IntentLabel = "suspicious"
    elif benign_score >= threshold:
        label = "benign"
    else:
        label = "neutral"

    return label, benign_score
