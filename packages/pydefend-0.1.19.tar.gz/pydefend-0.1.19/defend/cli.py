from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, Optional

import typer

from .init_token import (
    InitTokenError,
    decode_init_token,
    defend_config_dict_to_payload,
    encode_init_token,
    payload_to_defend_config_dict,
)

app = typer.Typer(add_completion=False, help="Defend CLI")

INIT_SETUP_URL = "https://www.pydefend.com/#getting-started"


def _require(exc: Exception) -> None:
    typer.echo(
        (
            "Missing runtime dependency. Install with `pip install pydefend` "
            f"or add the dependency to your environment.\n\nOriginal error: {exc}"
        ),
        err=True,
    )
    raise typer.Exit(code=1)


@app.command()
def serve(host: str = "0.0.0.0", port: int = 8000, log_level: str = "info") -> None:
    """
    Start the Defend server (FastAPI) via uvicorn.
    """
    try:
        import uvicorn  # type: ignore
    except Exception as exc:  # pragma: no cover
        _require(exc)

    config_path = Path("defend.config.yaml")
    if not config_path.exists():
        typer.echo(
            "Missing `defend.config.yaml` in the project root.\n"
            f"Open {INIT_SETUP_URL} to create a config token, then run:\n"
            '  defend init --token "defend_v1_..."',
            err=True,
        )
        raise typer.Exit(code=1)

    try:
        import yaml  # type: ignore
    except Exception as exc:  # pragma: no cover
        _require(exc)

    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        provider = raw.get("provider", "defend")
    except Exception as exc:
        typer.echo(f"Failed to read defend.config.yaml: {exc}", err=True)
        raise typer.Exit(code=1)

    if str(provider).strip().lower() == "defend":
        try:
            import defend_api.models.defend_qwen  # type: ignore  # noqa: F401
        except ImportError as exc:
            typer.echo(
                "Your config uses provider: defend, which loads the local Hugging Face classifier.\n"
                "PyTorch and transformers are not included in the default pydefend install.\n\n"
                "Install them with:\n\n"
                "  pip install pydefend[local]\n\n"
                "For Docker, use the image tagged `local` (see docs). Underlying import error:\n"
                f"  {exc}",
                err=True,
            )
            raise typer.Exit(code=1)

    try:
        import defend_api  # type: ignore  # noqa: F401 — package entry; loads FastAPI app
    except Exception as exc:  # pragma: no cover
        _require(exc)

    uvicorn.run("defend_api.main:app", host=host, port=port, log_level=log_level)


def _print_init_instructions() -> None:
    typer.echo(
        "Create your Defend configuration in the browser, then apply it with a token:\n\n"
        f"  {INIT_SETUP_URL}\n\n"
        "After you copy your init token, run:\n\n"
        '  defend init --token "defend_v1_..."\n\n'
        "Optional: write to another file with --out path/to/defend.config.yaml\n\n"
        "To export a token from an existing defend.config.yaml:\n\n"
        "  defend init --from-config\n"
    )


@app.command()
def init(
    token: Optional[str] = typer.Option(None, "--token", help="Init token string (defend_v1_...)"),
    from_config: bool = typer.Option(False, "--from-config", help="Export token from existing defend.config.yaml"),
    out_path: str = typer.Option("defend.config.yaml", "--out", help="Where to write the generated config"),
) -> None:
    """
    Write defend.config.yaml from a web-created init token (--token), export a token (--from-config),
    or print setup instructions when run with no options.
    """
    if from_config:
        try:
            import yaml  # type: ignore
        except Exception as exc:  # pragma: no cover
            typer.echo(
                "Missing dependency: PyYAML is required for `defend init`. Install with `pip install pyyaml`.",
                err=True,
            )
            raise typer.Exit(code=1) from exc

        try:
            raw = yaml.safe_load(Path("defend.config.yaml").read_text(encoding="utf-8")) or {}
        except Exception as exc:
            typer.echo(f"Failed to read defend.config.yaml: {exc}", err=True)
            raise typer.Exit(code=1)
        if not isinstance(raw, dict):
            typer.echo("defend.config.yaml must contain a YAML mapping at the top level", err=True)
            raise typer.Exit(code=1)
        payload = defend_config_dict_to_payload(raw)
        typer.echo(encode_init_token(payload))
        return

    if token:
        typer.echo("Processing init token...")
        try:
            import yaml  # type: ignore
        except Exception as exc:  # pragma: no cover
            typer.echo(
                "Missing dependency: PyYAML is required for `defend init`. Install with `pip install pyyaml`.",
                err=True,
            )
            raise typer.Exit(code=1) from exc

        try:
            payload = decode_init_token(token)
        except InitTokenError as exc:
            typer.echo(f"Invalid init token: {exc}", err=True)
            raise typer.Exit(code=1)

        cfg = payload_to_defend_config_dict(payload)

        from pydantic import ValidationError  # type: ignore

        try:
            from defend_api.config import DefendConfig  # type: ignore

            DefendConfig.model_validate(cfg)
        except ValidationError as exc:
            typer.echo(f"Init token produced invalid config:\n{exc}", err=True)
            raise typer.Exit(code=1)

        typer.echo(f"Writing to {out_path}...")
        try:
            Path(out_path).write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
        except Exception as exc:
            typer.echo(f"Failed to write {out_path}: {exc}", err=True)
            raise typer.Exit(code=1)

        typer.echo(f"Wrote {out_path}")
        return

    _print_init_instructions()


@app.command()
def test(
    text: Optional[str] = typer.Argument(
        None,
        help="Text to test. If neither --input nor --output is provided, this defaults to --input.",
    ),
    input_text: Optional[str] = typer.Option(
        None,
        "--input",
        help="Run the input guard on this text.",
    ),
    output_text: Optional[str] = typer.Option(
        None,
        "--output",
        help="Run the output guard on this text.",
    ),
    session_id: Optional[str] = typer.Option(
        None,
        "--session-id",
        help="Optional session_id to link input and output guards.",
    ),
    pretty: bool = typer.Option(
        True,
        "--pretty/--no-pretty",
        help="Pretty-print JSON output.",
    ),
) -> None:
    """
    Test guard input/output via the CLI.

    Examples:
      defend test "Tell me how to bypass controls."
      defend test --input "..."
      defend test --output "LLM response" --session-id def-...
    """
    if text is not None and (input_text is not None or output_text is not None):
        raise typer.BadParameter("Provide either positional TEXT or --input/--output (not both).")

    if input_text is None and output_text is None:
        if text is None:
            raise typer.BadParameter('Provide TEXT or one of `--input` / `--output`.')
        input_text = text

    if input_text is not None and output_text is not None:
        # Full chain in one run.
        async def _run_both() -> tuple[dict[str, Any], dict[str, Any]]:
            from defend_api.routers.guard import guard_input, guard_output
            from defend_api.schemas import GuardInputRequest, GuardOutputRequest

            in_req = GuardInputRequest(text=input_text, session_id=session_id)
            in_resp = await guard_input(in_req)
            in_payload: dict[str, Any] = json.loads(in_resp.body.decode("utf-8"))
            linked_session_id = in_payload.get("session_id") or session_id

            out_req = GuardOutputRequest(text=output_text, session_id=linked_session_id)
            out_resp = await guard_output(out_req)
            out_payload: dict[str, Any] = json.loads(out_resp.body.decode("utf-8"))
            return in_payload, out_payload

        try:
            in_result, out_result = asyncio.run(_run_both())
        except KeyboardInterrupt:  # pragma: no cover
            raise typer.Exit(code=130)
        except Exception as exc:
            typer.echo(f"Test failed: {exc}", err=True)
            raise typer.Exit(code=1)

        if pretty:
            typer.echo("Input result:")
            typer.echo(json.dumps(in_result, indent=2, ensure_ascii=False))
            typer.echo("\nOutput result:")
            typer.echo(json.dumps(out_result, indent=2, ensure_ascii=False))
        else:
            typer.echo("input_result=" + json.dumps(in_result, ensure_ascii=False))
            typer.echo("output_result=" + json.dumps(out_result, ensure_ascii=False))
        return

    async def _run_one() -> dict[str, Any]:
        from defend_api.routers.guard import guard_input, guard_output
        from defend_api.schemas import GuardInputRequest, GuardOutputRequest

        if input_text is not None:
            req = GuardInputRequest(text=input_text, session_id=session_id)
            resp = await guard_input(req)
        else:
            req = GuardOutputRequest(text=output_text or "", session_id=session_id)
            resp = await guard_output(req)

        return json.loads(resp.body.decode("utf-8"))

    try:
        result = asyncio.run(_run_one())
    except KeyboardInterrupt:  # pragma: no cover
        raise typer.Exit(code=130)
    except Exception as exc:
        typer.echo(f"Test failed: {exc}", err=True)
        raise typer.Exit(code=1)

    if pretty:
        typer.echo(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        typer.echo(json.dumps(result, ensure_ascii=False))

