from __future__ import annotations

import base64
import json
import zlib
from dataclasses import dataclass
from typing import Any, Dict


TOKEN_PREFIX = "defend_v1_"


class InitTokenError(ValueError):
    pass


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64url_decode(s: str) -> bytes:
    padded = s + "=" * ((4 - (len(s) % 4)) % 4)
    return base64.urlsafe_b64decode(padded.encode("ascii"))


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, separators=(",", ":"), sort_keys=True, ensure_ascii=False).encode("utf-8")


@dataclass(frozen=True)
class InitTokenPayload:
    v: int
    data: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {"v": self.v, **self.data}


def encode_init_token(payload: Dict[str, Any]) -> str:
    """
    Encode a shareable init token.

    - Prefix: defend_v1_
    - Body: zlib-compressed canonical JSON, base64url (no padding)
    """
    v = int(payload.get("v") or 1)
    if v != 1:
        raise InitTokenError(f"Unsupported token version: v={v}")

    blob = _canonical_json(payload)
    compressed = zlib.compress(blob, level=9)
    return TOKEN_PREFIX + _b64url_encode(compressed)


def decode_init_token(token: str) -> Dict[str, Any]:
    if not isinstance(token, str) or not token:
        raise InitTokenError("Token must be a non-empty string")

    if token.startswith(TOKEN_PREFIX):
        token = token[len(TOKEN_PREFIX) :]
    else:
        raise InitTokenError(f"Token must start with '{TOKEN_PREFIX}'")

    try:
        compressed = _b64url_decode(token)
    except Exception as exc:  # pragma: no cover
        raise InitTokenError(f"Invalid base64url token: {exc}") from exc

    try:
        raw = zlib.decompress(compressed)
    except Exception as exc:  # pragma: no cover
        raise InitTokenError(f"Invalid compressed token: {exc}") from exc

    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception as exc:  # pragma: no cover
        raise InitTokenError(f"Invalid JSON payload: {exc}") from exc

    if not isinstance(payload, dict):
        raise InitTokenError("Token payload must be a JSON object")

    v = payload.get("v")
    if v != 1:
        raise InitTokenError(f"Unsupported token version: v={v!r}")

    return payload


def payload_to_defend_config_dict(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a v1 token payload into a `defend.config.yaml` dict.

    This intentionally contains no secrets; API key values are expected to come
    from environment variables.
    """
    if payload.get("v") != 1:
        raise InitTokenError("payload_to_defend_config_dict expects v1 payload")

    providers = payload.get("providers") or {}
    if not isinstance(providers, dict):
        raise InitTokenError("payload field 'providers' must be an object")
    provider_value = providers.get("provider")
    if not isinstance(provider_value, str) or not provider_value:
        raise InitTokenError("payload field 'providers.provider' must be a non-empty string")
    guards = payload.get("guards") or {}
    if not isinstance(guards, dict):
        raise InitTokenError("payload field 'guards' must be an object")
    models = payload.get("models") or None

    guards_cfg: Dict[str, Any] = {
        "session_ttl_seconds": int((guards.get("session_ttl_seconds") or 300)),
    }

    if "input" in guards:
        input_cfg = guards.get("input")
        if input_cfg is None:
            input_cfg = {}
        if not isinstance(input_cfg, dict):
            raise InitTokenError("payload field 'guards.input' must be an object")
        guards_cfg["input"] = input_cfg
    else:
        guards_cfg["input"] = {}

    if "output" in guards:
        output_cfg = guards.get("output")
        if output_cfg is None:
            output_cfg = {}
        if not isinstance(output_cfg, dict):
            raise InitTokenError("payload field 'guards.output' must be an object")
        guards_cfg["output"] = output_cfg
    else:
        guards_cfg["output"] = {}

    cfg: Dict[str, Any] = {
        "provider": provider_value,
        "guards": guards_cfg,
    }

    if isinstance(models, dict) and models:
        cfg["models"] = {k: v for k, v in models.items() if isinstance(v, str) and v}

    return cfg


def defend_config_dict_to_payload(config_dict: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert an existing `defend.config.yaml` dict into a v1 token payload.
    """
    provider = config_dict.get("provider") or "defend"
    if not isinstance(provider, str) or not provider:
        raise InitTokenError("config field 'provider' must be a non-empty string")
    guards = config_dict.get("guards") or {}

    payload: Dict[str, Any] = {
        "v": 1,
        "providers": {
            "provider": provider if isinstance(provider, str) and provider else "defend",
        },
        "guards": {
            "input": guards.get("input") or {"provider": "defend", "modules": []},
            "output": guards.get("output") or {"enabled": False, "provider": "claude", "modules": [], "on_fail": "block"},
            "session_ttl_seconds": guards.get("session_ttl_seconds", 300),
        },
    }

    models = config_dict.get("models")
    if isinstance(models, dict) and models:
        payload["models"] = {k: v for k, v in models.items() if isinstance(v, str) and v}

    return payload


def safe_round_trip(token: str) -> str:
    payload = decode_init_token(token)
    return encode_init_token(payload)

