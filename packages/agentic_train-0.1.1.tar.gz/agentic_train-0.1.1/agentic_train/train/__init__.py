from typing import Any, Generic

from agentic_train import Runner
from agentic_train.train.trainers import Trainer
from agentic_train.types import TCTrainRunner
from agentic_train.utils import load_class


class TrainRunner(Runner[TCTrainRunner], Generic[TCTrainRunner]):
    def __init__(self, config: TCTrainRunner):
        super().__init__(config)
        self.trainer: Trainer[Any] = load_class(self.config.trainer.module_path).from_config(self.config.trainer)

    def run(self) -> None:
        self.trainer.train()
