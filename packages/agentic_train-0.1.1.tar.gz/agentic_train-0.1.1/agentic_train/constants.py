RANDOM_SEED = 42
DATA_DIR, CONFIG_PATH = "/data", "/config/config.yaml"
