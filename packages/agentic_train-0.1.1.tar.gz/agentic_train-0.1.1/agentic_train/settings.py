from pathlib import Path
from typing import Any, Dict, Generic, List, Literal, Optional, Union

from agentic_base.connector.settings import MinioDatasetConnectorSettings
from agentic_base.types import TCDatasetConnector, TCProcessor
from agentic_train.constants import CONFIG_PATH, DATA_DIR
from agentic_train.types import (
    TCCollateFn,
    TCDistance,
    TCLoss,
    TCModel,
    TCTorchDataset,
    TCTrainer,
)
from pydantic import Field
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    YamlConfigSettingsSource,
)


class FromConfigMixinSettings(BaseSettings):
    module_path: str
    model_config = SettingsConfigDict(
        yaml_file=CONFIG_PATH,
        extra="ignore",
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            YamlConfigSettingsSource(settings_cls),
            env_settings,
            dotenv_settings,
            file_secret_settings,
        )


class TorchDatasetSettings(FromConfigMixinSettings, Generic[TCDatasetConnector]):
    dataset_connector: TCDatasetConnector


class TokenizerSettings(BaseSettings):
    name: str
    padding: Union[str, bool]
    truncation: bool
    max_length: int


class SamplerSettings(BaseSettings):
    module_path: str
    seed: Optional[int]


class DistanceSettings(FromConfigMixinSettings):
    pass


class StepRangeDistanceSettings(DistanceSettings):
    pass


class PositiveSamplerSettings(SamplerSettings, Generic[TCDistance]):
    max_step_distance: int
    distance: TCDistance
    k: int


class CollateFnSettings(BaseSettings, Generic[TCProcessor]):
    module_path: str
    tokenizer: TokenizerSettings
    processor: TCProcessor


class InBatchPositiveCollateFnSettings(CollateFnSettings[TCProcessor], Generic[TCProcessor]):
    pass


class MultiPositiveInBatchCollateFnSettings(CollateFnSettings[TCProcessor], Generic[TCProcessor]):
    n_pos: int


class ModelSettings(FromConfigMixinSettings):
    pass


class LossSettings(FromConfigMixinSettings):
    pass


class TrainerSettings(FromConfigMixinSettings):
    checkpoint_dir: Path = Path(DATA_DIR) / "checkpoints"


class PyTorchTrainerSettings(TrainerSettings, Generic[TCModel, TCLoss, TCTorchDataset, TCCollateFn]):
    model: TCModel
    torch_dataset: TCTorchDataset
    collate_fn: TCCollateFn
    train_frac: float
    num_epochs: int
    batch_size: int
    shuffle: bool
    lr: float
    device: str
    save_every: int
    drop_last: bool
    loss: TCLoss
    tensorboard_dir: Path = Path(DATA_DIR) / "tensorboard"
    resume_from: Optional[str] = None


class ContrastiveLossSettings(LossSettings):
    temperature: float


class QueryMultiPositiveDatasetSettings(TorchDatasetSettings[TCDatasetConnector]):
    pass


class InBatchNegativeContrastiveLossSettings(ContrastiveLossSettings):
    pass


class MultiPositiveContrastiveLossSettings(ContrastiveLossSettings):
    n_pos: int


class RunnerSettings(FromConfigMixinSettings):
    pass


class HFSettings(BaseSettings):
    repo: str
    revision: Optional[str]
    private: bool
    commit_message: Optional[str]


class PushToHFRunnerSettings(RunnerSettings, Generic[TCModel]):
    checkpoint_path: str = Field(init=False)
    device: str = Field(init=False)
    push: bool = Field(init=False)
    create_repo: bool = Field(init=False)
    hf: HFSettings = Field(init=False)
    model: TCModel = Field(init=False)


class TrainRunnerSettings(RunnerSettings, Generic[TCTrainer]):
    trainer: TCTrainer


class HardNegativesSettings(BaseSettings):
    enabled: bool
    range_min: int
    range_max: int
    max_score: float
    relative_margin: float
    num_negatives: int
    sampling_strategy: Literal["random", "top"]
    batch_size: int
    use_faiss: bool


class EvalutationSettings(BaseSettings):
    precision_recall_at_k: List[int]
    mrr_at_k: List[int]
    ndcg_at_k: List[int]
    batch_size: int


class SentenceTransformerLoss(LossSettings):
    kwargs: Dict[str, Any]


class SentenceTransformersTrainerSettings(TrainerSettings):
    model_name_or_path: str
    tokenizer: TokenizerSettings
    torch_dataset: QueryMultiPositiveDatasetSettings[MinioDatasetConnectorSettings]
    loss: SentenceTransformerLoss
    pooling: Literal["cls", "mean_tokens", "max_tokens"]
    batch_size: int
    num_epochs: int
    lr: float
    warmup_ratio: float
    eval_steps: int
    save_steps: int
    logging_steps: int
    fp16: bool
    train_frac: float
    hard_negatives: Optional[HardNegativesSettings]
    resume_from: Optional[str]
    evaluation: EvalutationSettings
