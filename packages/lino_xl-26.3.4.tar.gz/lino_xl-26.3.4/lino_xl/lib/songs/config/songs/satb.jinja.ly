\version "2.25.24"
\paper{
    indent=0\mm
    {% if fmt.line_width %}
    line-width={{fmt.line_width}}
    {% elif sng.scores_line_width %}
    line-width={{sng.scores_line_width}}
    {% endif %}
    oddFooterMarkup=##f
    oddHeaderMarkup=##f
    bookTitleMarkup = ##f
    scoreTitleMarkup = ##f
}

\layout{
   {# setting font-name here causes italic later to not work
   See https://jane.mylino.net/#/api/comments/Comments/18890
   #}
   \context { \Lyrics
     \override LyricText.font-name = #"{{sng.font_name}}"
   }
   \context { \Score
     \omit BarNumber
   }
}



{# The snippet below is taken from
https://wiki.lilypond.community/index.php?title=Scaling_vertical_spacing
#}
% This snippet shows how to increase or decrease the overall vertical spacing
% (of staves, systems, lyrics, chord names, etc.) by scaling all of the properties
% that affect the vertical spacing layout.  This helps preserve the basic
% proportions as compared with changing just one or two of these properties.

% VERTICAL SPACING SETTINGS: PAGE LAYOUT, OUTSIDE OF SYSTEMS

% see Notation Reference 4.1.4
% http://lilypond.org/doc/v2.18/Documentation/notation/flexible-vertical-spacing-paper-variables
% default values are from ly/engraver-init.ly in LilyPond source code

% pmult: page/paper variable multiplier, used in the paper block below to scale
% flexible vertical spacing paper variables. Change its value to change the
% vertical spacing outside of systems.

pmult = #{{"{:.1f}".format(sng.vertical_spacing_outside/100)}}

\paper {
  system-system-spacing =
  #`((basic-distance . ,(* 12 pmult))
     (minimum-distance . ,(* 8 pmult))
     (padding . ,pmult))
  score-system-spacing =
  #`((basic-distance . ,(* 14 pmult))
     (minimum-distance . ,(* 8 pmult))
     (padding . ,pmult))
  markup-system-spacing =
  #`((basic-distance . ,(* 5 pmult))
     (padding . ,(* 0.5 pmult)))
  score-markup-spacing =
  #`((basic-distance . ,(* 12 pmult))
     (padding . ,(* 0.5 pmult)))
  markup-markup-spacing =
  #`((basic-distance . ,pmult)
     (padding . ,(* 0.5 pmult)))
  top-system-spacing =
  % minimum-distance is 0
  #`((basic-distance . ,pmult)
     (padding . ,pmult))
  top-markup-spacing.padding = #pmult
  % basic-distance and minimum-distance are 0
  last-bottom-spacing =
  % minimum-distance is 0
  #`((basic-distance . ,pmult)
     (padding . ,pmult))
}


% VERTICAL SPACING SETTINGS: WITHIN SYSTEMS

% see Notation Reference 4.4.1
% http://lilypond.org/doc/v2.18/Documentation/notation/flexible-vertical-spacing-within-systems
% default values are from scm/define-grobs.scm in LilyPond source code

% gmult: grob property multiplier, used in the layout block below to scale
% flexible vertical spacing grob properties.  Change its value to change the
% vertical spacing within systems.

gmult = #{{"{:.1f}".format(sng.vertical_spacing_inside/100)}}

\layout {
  \context {
    \Score {
      \override StaffGrouper.staff-staff-spacing =
      #`((basic-distance . ,(* 9 gmult))
         (minimum-distance . ,(* 7 gmult))
         (padding . ,gmult))
      \override StaffGrouper.staffgroup-staff-spacing =
      #`((basic-distance . ,(* 10.5 gmult))
         (minimum-distance . ,(* 8 gmult))
         (padding . ,gmult))
    }
  }
  \context {
    \Staff {
      \override VerticalAxisGroup.default-staff-staff-spacing =
      #`((basic-distance . ,(* 9 gmult))
         (minimum-distance . ,(* 8 gmult))
         (padding . ,gmult))
    }
  }
  \context {
    \ChordNames {
      \override VerticalAxisGroup.nonstaff-relatedstaff-spacing.padding = #(* 0.5 gmult)
      \override VerticalAxisGroup.nonstaff-nonstaff-spacing.padding = #(* 0.5 gmult)
    }
  }
  \context {
    \Dynamics {
      \override VerticalAxisGroup.nonstaff-relatedstaff-spacing =
      #`((basic-distance . ,(* 5 gmult))
         (padding . ,(* 0.5 gmult)))
    }
  }
  \context {
    \FiguredBass {
      \override VerticalAxisGroup.nonstaff-relatedstaff-spacing.padding = #(* 0.5 gmult)
      \override VerticalAxisGroup.nonstaff-nonstaff-spacing.padding = #(* 0.5 gmult)
    }
  }
  % FretBoards do not set any grob-properties in VerticalAxisGroup
  % so there is nothing to scale, so they aren't includede here.
  \context {
    \Lyrics {
      \override VerticalAxisGroup.nonstaff-relatedstaff-spacing =
      #`((basic-distance . ,(* 5.5 gmult))
         (padding . ,(* 0.5 gmult)))
      \override VerticalAxisGroup.nonstaff-nonstaff-spacing =
      % basic-distance is 0
      #`((minimum-distance . ,(* 4.0 gmult))
         (padding . ,(* 0.2 gmult)))
      \override VerticalAxisGroup.nonstaff-unrelatedstaff-spacing.padding = #(* 1.5 gmult)
    }
  }
  \context {
    \NoteNames {
      \override VerticalAxisGroup.nonstaff-relatedstaff-spacing =
      #`((basic-distance . ,(* 5.5 gmult))
         (padding . ,(* 0.5 gmult)))
      \override VerticalAxisGroup.nonstaff-nonstaff-spacing =
      % basic-distance is 0
      #`((minimum-distance . ,(* 2.8 gmult))
         (padding . ,(* 0.2 gmult)))
      \override VerticalAxisGroup.nonstaff-unrelatedstaff-spacing.padding = #(* 1.5 gmult)
    }
  }
}

\score {

{% if sng.scores_chords %}
  <<
  \new ChordNames {
    \set chordChanges = ##f
    \set chordNameExceptions = #chExceptions
    \override ChordName #'font-size = #-1
    \chordmode {
  \set majorSevenSymbol = \markup { "Maj7" }
  \override ParenthesesItem #'font-size = #0
  {sng.scores_chords}
  } }
{% endif %}

\new GrandStaff <<

  \new Staff = "SA" \with {
    {% if not sng.time_signature %}\omit TimeSignature{% endif %}
    \consists Merge_rests_engraver
    printPartCombineTexts = ##f
  } <<
    {% if sng.combine_parts and sng.scores_soprano and sng.scores_alto %}
      \new NullVoice = "soprano" { {{sng.scores_soprano}} }
      \new NullVoice = "alto" { {{sng.scores_alto}} }
      \new Voice = "soprano_alto" {
          {% if sng.scores_tempo %} \tempo {{sng.scores_tempo}} {% endif %}
          {% if sng.time_signature %} \time {{sng.time_signature}} {% endif %}
          {{sng.scores_preamble}}
          \partCombine
          \relative g' { {{sng.scores_soprano}} }
          \relative g' { {{sng.scores_alto}} }
      }
    {% else %}
      \new Voice = "soprano" {
         {% if sng.scores_tempo %} \tempo {{sng.scores_tempo}} {% endif %}
         {% if sng.time_signature %} \time {{sng.time_signature}} {% endif %}
         {% if sng.scores_alto %} \voiceOne {% endif %}
         <<
            {{sng.scores_preamble}} \relative g' {
              {{sng.scores_soprano}}
            }
         >>
         {% if sng.scores_alto %}
      } \new Voice = "alto"  {
        \voiceTwo <<
             {{sng.scores_preamble}} \relative g' {
               {{sng.scores_alto}}
             }
           >>
         {% endif %}
      }
    {% endif %}
  >>

  {% for lln in sng.get_lyrics() %}
  \new Lyrics
    {% if lln.above %}
    \with { alignAboveContext = "{{lln.above}}" }
    {% endif %}
    \lyricsto "{{lln.voice}}" {
      {% if lln.font == 'alt' %}
      \override LyricText . font-shape = #'italic
      \override LyricText . font-name = #"{{sng.font_name}}"
      \override LyricText . font-size = #-1
      {% endif %}
      {{lln.text}}
  }
  {% endfor %}

  {% if sng.scores_tenor or sng.scores_bass %}
    \new Staff = "TB" \with {
      {% if not sng.time_signature %}\omit TimeSignature{% endif %}
      \consists Merge_rests_engraver
      printPartCombineTexts = ##f
    } <<
      \clef bass
      {% if sng.combine_parts and sng.scores_tenor and sng.scores_bass %}
        \new Voice = "tenor_bass" {
          {{sng.scores_preamble}}
          \partCombine
          \relative f { {{sng.scores_tenor}} }
          \relative f { {{sng.scores_bass}} }
        }
      {% else %}
        {% if sng.scores_tenor %}
          \new Voice = "tenor" {
            {% if sng.scores_bass %} \voiceOne {% endif %}
            << {{sng.scores_preamble}} \relative f {
              {{sng.scores_tenor}}
            } >>
          }
        {% endif %}
        {% if sng.scores_bass %}
          \new Voice = "bass" {
            \voiceTwo
            << {{sng.scores_preamble}} \relative f {
              {{sng.scores_bass}}
            } >>
          }
        {% endif %}
      {% endif %}
    >>
  {% endif %}

>>

{% if sng.scores_chords %}
>>
{% endif %}

}
