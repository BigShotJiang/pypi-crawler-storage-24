import httpx
import asyncio
from typing import Any, List, Dict, Optional, AsyncGenerator
from .base import PIServiceBase
from .config import WebAPISettings

class PIWebAPIError(Exception):
    """Custom exception for PI Web API failures."""
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code

class PIWebAPIService(PIServiceBase):
    """
    Implementation of PI Service using PI Web API (REST).
    """

    def __init__(self, settings: WebAPISettings):
        self.settings = settings
        self.base_url = settings.PI_WEB_API_URL
        if not self.base_url:
            raise ValueError("PI_WEB_API_URL must be set in configuration")
            
        self.client = httpx.AsyncClient(
            auth=(settings.PI_WEB_API_USERNAME, settings.PI_WEB_API_PASSWORD) if settings.PI_WEB_API_USERNAME else None,
            verify=settings.PI_WEB_API_VERIFY_SSL,
            timeout=30.0
        )

    async def _handle_request(self, method: str, url: str, **kwargs) -> httpx.Response:
        """Helper method to handle HTTP requests and catch common errors."""
        try:
            response = await self.client.request(method, url, **kwargs)
            response.raise_for_status()
            return response
        except httpx.HTTPStatusError as e:
            error_details = e.response.text
            try:
                # Try to extract the JSON error message from PI Web API
                error_json = e.response.json()
                if "Errors" in error_json:
                    error_details = str(error_json["Errors"])
            except:
                pass
            raise PIWebAPIError(f"HTTP Status Error: {e.response.status_code} - {error_details}", status_code=e.response.status_code)
        except httpx.RequestError as e:
            raise PIWebAPIError(f"HTTP Connection Error: {str(e)}")
        except Exception as e:
            raise PIWebAPIError(f"Unexpected API Error: {str(e)}")

    async def _get_data_server_web_id(self) -> str:
        """Helper to get the WebId of the PI Data Server."""
        url = f"{self.base_url}/dataservers"
        params = {"name": self.settings.PI_SERVER_NAME}
        
        response = await self._handle_request("GET", url, params=params)
        items = response.json().get("Items", [])
        
        if not items:
            # Try searching all servers if exact name match fails
            response = await self._handle_request("GET", url)
            items = response.json().get("Items", [])
            for item in items:
                if item["Name"].lower() == self.settings.PI_SERVER_NAME.lower():
                    return item["WebId"]
            raise PIWebAPIError(f"PI Data Server '{self.settings.PI_SERVER_NAME}' not found.")
            
        return items[0]["WebId"]

    async def _get_web_id(self, tag_name: str) -> str:
        """Helper to get WebID for a tag name with fallback."""
        # 1. First attempt: Get By Path
        path = f"\\\\{self.settings.PI_SERVER_NAME}\\{tag_name}"
        url = f"{self.base_url}/points"
        params = {"path": path}
        
        try:
            response = await self.client.get(url, params=params)
            if response.status_code == 200:
                return response.json().get("WebId")
        except httpx.RequestError as e:
            raise PIWebAPIError(f"Connection failed while resolving WebID for '{tag_name}': {str(e)}")

        # 2. Second attempt: Get via Query Search
        url_search = f"{self.base_url}/search/query"
        params_search = {"q": f"name:\"{tag_name}\""}
        
        try:
            response_search = await self.client.get(url_search, params=params_search)
            if response_search.status_code == 200:
                items = response_search.json().get("Items", [])
                if items:
                    return items[0]["WebId"]
        except httpx.RequestError as e:
            raise PIWebAPIError(f"Connection failed while searching WebID for '{tag_name}': {str(e)}")
            
        raise PIWebAPIError(f"Tag '{tag_name}' not found on the PI Server.")

    async def get_current_value(self, tag_name: str) -> Dict[str, Any]:
        """Fetch current value via PI Web API."""
        web_id = await self._get_web_id(tag_name)
        url = f"{self.base_url}/streams/{web_id}/value"
        
        response = await self._handle_request("GET", url)
        data = response.json()
        
        return {
            "tag": tag_name,
            "value": data.get("Value"),
            "timestamp": data.get("Timestamp"),
            "provider": "WebAPI"
        }

    async def get_real_time_data(self, tag_name: str) -> Dict[str, Any]:
        """Fetch real-time data via PI Web API."""
        return await self.get_current_value(tag_name)

    async def get_live_data_stream(self, tag_name: str, interval_seconds: int = 60) -> AsyncGenerator[Dict[str, Any], None]:
        """Yield real-time data every `interval_seconds` (default 60s / 1 min)."""
        while True:
            try:
                data = await self.get_current_value(tag_name)
                yield data
            except PIWebAPIError as e:
                # Yield error nicely formatted without crashing the generator loop
                yield {"tag": tag_name, "error": str(e), "provider": "WebAPI"}
            except Exception as e:
                yield {"tag": tag_name, "error": f"Unexpected stream error: {str(e)}", "provider": "WebAPI"}
                
            await asyncio.sleep(interval_seconds)

    async def get_recorded_values(self, tag_name: str, start_time: str, end_time: str) -> List[Dict[str, Any]]:
        """Fetch historical values via PI Web API."""
        web_id = await self._get_web_id(tag_name)
        url = f"{self.base_url}/streams/{web_id}/recorded"
        params = {"startTime": start_time, "endTime": end_time}
        
        response = await self._handle_request("GET", url, params=params)
        items = response.json().get("Items", [])
        
        return [
            {"timestamp": item.get("Timestamp"), "value": item.get("Value")}
            for item in items
        ]

    async def get_interpolated_values(self, tag_name: str, start_time: str, end_time: str, interval: str) -> List[Dict[str, Any]]:
        """Fetch interpolated values via PI Web API at regular intervals."""
        web_id = await self._get_web_id(tag_name)
        url = f"{self.base_url}/streams/{web_id}/interpolated"
        params = {"startTime": start_time, "endTime": end_time, "interval": interval}
        
        response = await self._handle_request("GET", url, params=params)
        items = response.json().get("Items", [])
        
        return [
            {"timestamp": item.get("Timestamp"), "value": item.get("Value")}
            for item in items
        ]

    async def get_multiple_current_values(self, tag_names: List[str]) -> Dict[str, Any]:
        """Fetch multiple current values efficiently using StreamSets."""
        if not tag_names:
            return {}
            
        web_ids = [await self._get_web_id(tag) for tag in tag_names]
        url = f"{self.base_url}/streamsets/value"
        query_string = "&".join([f"webId={wid}" for wid in web_ids])
        full_url = f"{url}?{query_string}"
        
        response = await self._handle_request("GET", full_url)
        items = response.json().get("Items", [])
        
        result = {}
        for idx, item in enumerate(items):
            val_obj = item.get("Value", {})
            result[tag_names[idx]] = {
                "value": val_obj.get("Value"),
                "timestamp": val_obj.get("Timestamp")
            }
        return result

    async def get_summary_data(self, tag_name: str, start_time: str, end_time: str, summary_type: str = "Average") -> Dict[str, Any]:
        """Fetch summary statistics (Average, Minimum, Maximum, etc.) via PI Web API."""
        web_id = await self._get_web_id(tag_name)
        url = f"{self.base_url}/streams/{web_id}/summary"
        params = {"startTime": start_time, "endTime": end_time, "summaryType": summary_type}
        
        response = await self._handle_request("GET", url, params=params)
        items = response.json().get("Items", [])
        
        if not items:
            return {}
            
        summary_val = items[0].get("Value", {})
        return {
            "type": items[0].get("Type"),
            "value": summary_val.get("Value"),
            "timestamp": summary_val.get("Timestamp")
        }

    async def get_tag_attributes(self, tag_name: str) -> Dict[str, Any]:
        """Fetch metadata (attributes) for a specific PI tag."""
        web_id = await self._get_web_id(tag_name)
        url = f"{self.base_url}/points/{web_id}"
        
        response = await self._handle_request("GET", url)
        data = response.json()
        
        return {
            "name": data.get("Name"),
            "descriptor": data.get("Descriptor"),
            "pointClass": data.get("PointClass"),
            "pointType": data.get("PointType"),
            "engineeringUnits": data.get("EngineeringUnits"),
            "step": data.get("Step")
        }

    async def delete_value(self, tag_name: str, timestamp: str) -> bool:
        """Delete a specific value from a PI tag at the exact timestamp."""
        try:
            web_id = await self._get_web_id(tag_name)
            url = f"{self.base_url}/streams/{web_id}/value"
            params = {"timestamp": timestamp}
            
            response = await self._handle_request("DELETE", url, params=params)
            return response.status_code in [200, 202, 204]
        except PIWebAPIError:
            return False

    async def write_value(self, tag_name: str, value: Any, timestamp: Any = None) -> bool:
        """Write value via PI Web API."""
        try:
            web_id = await self._get_web_id(tag_name)
            url = f"{self.base_url}/streams/{web_id}/value"
            data = {"Timestamp": timestamp or "*", "Value": value}
            
            response = await self._handle_request("POST", url, json=data)
            return response.status_code in [200, 202, 204]
        except PIWebAPIError:
            return False

    async def search_tags(self, query: str) -> List[str]:
        """Search tags via PI Web API using nameFilter."""
        try:
            server_web_id = await self._get_data_server_web_id()
            url = f"{self.base_url}/dataservers/{server_web_id}/points"
            params = {"nameFilter": query}
            
            response = await self._handle_request("GET", url, params=params)
            items = response.json().get("Items", [])
            return [item.get("Name") for item in items]
        except PIWebAPIError:
            return []

    async def _get_asset_server_web_id(self, server_name: str) -> str:
        """Helper to get the WebId of a PI AF Asset Server."""
        url = f"{self.base_url}/assetservers"
        params = {"name": server_name}
        
        response = await self._handle_request("GET", url, params=params)
        data = response.json()
        
        if "Items" in data:
            for item in data["Items"]:
                 if item["Name"].lower() == server_name.lower():
                     return item["WebId"]
        elif data.get("Name", "").lower() == server_name.lower():
            return data["WebId"]

        raise PIWebAPIError(f"PI AF Asset Server '{server_name}' not found.")

    async def get_asset_servers(self) -> List[str]:
        """Fetch PI AF Asset Server names via PI Web API."""
        url = f"{self.base_url}/assetservers"
        response = await self._handle_request("GET", url)
        items = response.json().get("Items", [])
        return [item.get("Name") for item in items]

    async def get_organizations(self, asset_server: str) -> List[str]:
        """Fetch AF Database names (Organizations) for a given Asset Server."""
        server_web_id = await self._get_asset_server_web_id(asset_server)
        url = f"{self.base_url}/assetservers/{server_web_id}/assetdatabases"
        
        response = await self._handle_request("GET", url)
        items = response.json().get("Items", [])
        return [item.get("Name") for item in items]

    async def test_connection(self) -> Dict[str, Any]:
        """Test PI Web API connection safely without throwing exceptions if it fails."""
        try:
            url = f"{self.base_url}/system/status"
            # Manually calling client rather than handle_request to catch everything securely
            response = await self.client.get(url)
            
            if response.status_code == 200:
                return {
                    "status": "connected", 
                    "type": "WebAPI", 
                    "url": self.base_url,
                    "server_time": response.json().get("ServerTime")
                }
            return {"status": "error", "code": response.status_code, "detail": response.text}
        except httpx.RequestError as e:
            return {"status": "failed", "error": f"Connection Refused: {str(e)}"}
        except Exception as e:
            return {"status": "failed", "error": f"Unexpected error: {str(e)}"}

    async def close(self):
        """Close the httpx client connections cleanly."""
        try:
            await self.client.aclose()
        except:
            pass
