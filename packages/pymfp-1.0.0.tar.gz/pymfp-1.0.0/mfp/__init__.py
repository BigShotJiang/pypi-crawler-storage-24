"""Mirror Frame Protocol — symmetric frame envelope for LLM agent communication.

Stable API Surface (semver commitment):
    Everything in __all__ is the public API and follows semantic versioning:
    - Breaking changes only in major versions (2.0, 3.0, ...)
    - Additions allowed in minor versions (1.1, 1.2, ...)
    - Bug fixes in patch versions (1.0.1, 1.0.2, ...)
    Everything not in __all__ is internal and may change without notice.

Usage:
    from mfp import Runtime, RuntimeConfig, bind, unbind
    from mfp import mfp_send, mfp_channels, mfp_status
    from mfp import AgentCallable, DeliveredMessage
"""

from mfp.agent.lifecycle import AgentHandle, bind, unbind
from mfp.agent.tools import (
    mfp_channels,
    mfp_channels_async,
    mfp_send,
    mfp_send_async,
    mfp_status,
    mfp_status_async,
)
from mfp.core.types import (
    AgentError,
    AgentErrorCode,
    AgentId,
    AgentStatus,
    ChannelId,
    ChannelInfo,
    DeliveredMessage,
    PROTOCOL_VERSION,
    Receipt,
)
from mfp.runtime.pipeline import AgentCallable, AsyncAgentCallable, RuntimeConfig
from mfp.runtime.runtime import Runtime

__version__ = "1.0.0"

__all__ = [
    # Core
    "Runtime",
    "RuntimeConfig",
    # Agent lifecycle
    "AgentHandle",
    "bind",
    "unbind",
    # Protocol tools (sync)
    "mfp_send",
    "mfp_channels",
    "mfp_status",
    # Protocol tools (async)
    "mfp_send_async",
    "mfp_channels_async",
    "mfp_status_async",
    # Types
    "AgentCallable",
    "AsyncAgentCallable",
    "AgentId",
    "AgentStatus",
    "AgentError",
    "AgentErrorCode",
    "ChannelId",
    "ChannelInfo",
    "DeliveredMessage",
    "PROTOCOL_VERSION",
    "Receipt",
    # Version
    "__version__",
]
