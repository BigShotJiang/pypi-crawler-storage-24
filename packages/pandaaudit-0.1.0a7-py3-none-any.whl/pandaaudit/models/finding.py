"""Finding model for scan results."""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any

from pandaaudit.models.severity import Severity, Category


@dataclass
class Finding:
    """A single security finding."""
    check_id: str           # e.g. "PA-NET01"
    title: str
    severity: Severity
    category: Category
    status: str             # "FAIL", "PASS", "SKIP", "ERROR"
    description: str = ""
    detail: str = ""        # additional context / evidence
    remediation: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_id": self.check_id,
            "title": self.title,
            "severity": self.severity.value,
            "category": self.category.value,
            "status": self.status,
            "description": self.description,
            "detail": self.detail,
            "remediation": self.remediation,
            "metadata": self.metadata,
        }
