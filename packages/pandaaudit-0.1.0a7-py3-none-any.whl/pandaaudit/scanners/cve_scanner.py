"""PA-CVE* — Known vulnerability scanner."""

from typing import List, Optional

from pandaaudit.scanners.base import BaseScanner
from pandaaudit.models.finding import Finding
from pandaaudit.models.severity import Severity, Category


class CveScanner(BaseScanner):
    category = Category.CVE
    mode = "both"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []

        version = self.discovery.version

        if self.target and not version:
            # Remote: try to fingerprint version
            version = self._remote_fingerprint()

        if not version:
            self.skip("PA-CVE00", "CVE version matching", Severity.HIGH,
                      "Cannot determine OpenClaw version")
            return self.findings

        from pandaaudit.cvedb.matcher import match_version

        matched = match_version(version)
        if not matched:
            self.add_finding("PA-CVE00", "CVE version matching", Severity.HIGH, "PASS",
                             detail=f"Version {version}: no known CVEs")
            return self.findings

        for cve in matched:
            sev_map = {
                "CRITICAL": Severity.CRITICAL,
                "HIGH": Severity.HIGH,
                "MEDIUM": Severity.MEDIUM,
            }
            severity = sev_map.get(cve.get("severity", "").upper(), Severity.HIGH)
            self.add_finding(
                check_id=cve["id"],
                title=cve.get("title", ""),
                severity=severity,
                status="FAIL",
                detail=f"Affected: {cve.get('affected', '')} | CVSS: {cve.get('cvss', '?')}",
                remediation=f"Upgrade OpenClaw to fix {cve['id']}",
                related_checks=cve.get("related_checks", []),
            )

        return self.findings

    def _remote_fingerprint(self) -> Optional[str]:
        """Try to detect version from remote HTTP response."""
        if not self.target:
            return None
        try:
            import urllib.request
            url = f"http://{self.target}:{self.port}"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=10) as resp:
                # Try X-Version header or body content
                version = resp.headers.get("X-Version") or resp.headers.get("Server", "")
                if version:
                    # Extract version number
                    import re
                    match = re.search(r"(\d+\.\d+\.\d+)", version)
                    if match:
                        return match.group(1)
                # Try parsing body for version info
                body = resp.read(4096).decode("utf-8", errors="ignore")
                match = re.search(r"version[\":\s]+(\d+\.\d+\.\d+)", body, re.IGNORECASE)
                if match:
                    return match.group(1)
        except Exception:
            pass
        return None
