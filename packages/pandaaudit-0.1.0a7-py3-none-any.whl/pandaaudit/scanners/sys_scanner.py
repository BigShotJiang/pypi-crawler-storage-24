"""PA-SYS* — System security scanner."""

import os
import subprocess
from pathlib import Path
from typing import List, Optional

from pandaaudit.scanners.base import BaseScanner
from pandaaudit.models.finding import Finding
from pandaaudit.models.severity import Severity, Category


class SysScanner(BaseScanner):
    category = Category.SYS
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-SYS01": self._sys01_root,
            "PA-SYS02": self._sys02_file_integrity,
            "PA-SYS03": self._sys03_sensitive_dirs,
            "PA-SYS04": self._sys04_cron,
            "PA-SYS05": self._sys05_ssh_bruteforce,
            "PA-SYS06": self._sys06_nodejs_cve,
        }
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-SYS01: Running as root
    # ------------------------------------------------------------------
    def _sys01_root(self):
        check_id = "PA-SYS01"
        title = "OpenClaw process running as root"

        try:
            result = subprocess.run(
                ["pgrep", "-f", "openclaw"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0 or not result.stdout.strip():
                self.skip(check_id, title, Severity.CRITICAL,
                          "OpenClaw process not found")
                return

            pids = result.stdout.strip().splitlines()
            root_pids = []
            for pid in pids:
                try:
                    stat = os.stat(f"/proc/{pid}")
                    if stat.st_uid == 0:
                        root_pids.append(pid)
                except (FileNotFoundError, PermissionError):
                    pass

            if root_pids:
                self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                 detail=f"PIDs running as root: {', '.join(root_pids)}",
                                 remediation="Run OpenClaw as a non-root user")
            else:
                self.add_finding(check_id, title, Severity.CRITICAL, "PASS")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            self.skip(check_id, title, Severity.CRITICAL,
                      "pgrep not available")

    # ------------------------------------------------------------------
    # PA-SYS02: System critical file permission anomaly
    # ------------------------------------------------------------------
    def _sys02_file_integrity(self):
        check_id = "PA-SYS02"
        title = "System critical file permission anomaly"

        import stat

        critical_files = [
            Path("/etc/passwd"),
            Path("/etc/shadow"),
            Path("/etc/ssh/sshd_config"),
            Path.home() / ".ssh" / "authorized_keys",
        ]

        anomalies = []
        for f in critical_files:
            if not f.exists():
                continue
            try:
                st = f.stat()
                mode = st.st_mode
                name = str(f)

                # /etc/shadow should not be world-readable
                if f.name == "shadow" and mode & stat.S_IROTH:
                    anomalies.append(f"{name}: world-readable")
                # sshd_config should not be world-writable
                elif f.name == "sshd_config" and mode & stat.S_IWOTH:
                    anomalies.append(f"{name}: world-writable")
                # authorized_keys should not be group/other writable
                elif f.name == "authorized_keys" and (mode & stat.S_IWGRP or mode & stat.S_IWOTH):
                    anomalies.append(f"{name}: group/other writable")
            except OSError:
                continue

        if anomalies:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="; ".join(anomalies),
                             remediation="Fix file permissions on system critical files")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="System critical file permissions are correct")

    # ------------------------------------------------------------------
    # PA-SYS03: Sensitive directory changes in 24h
    # ------------------------------------------------------------------
    def _sys03_sensitive_dirs(self):
        check_id = "PA-SYS03"
        title = "Sensitive directories modified in last 24h"

        if os.geteuid() != 0:
            self.skip(check_id, title, Severity.HIGH, "Requires root to scan /etc")
            return

        dirs = ["/etc", str(Path.home() / ".ssh"), str(Path.home() / ".gnupg")]
        total_modified = 0

        for d in dirs:
            if not Path(d).is_dir():
                continue
            try:
                result = subprocess.run(
                    ["find", d, "-type", "f", "-mtime", "-1"],
                    capture_output=True, text=True, timeout=10,
                )
                if result.stdout.strip():
                    total_modified += len(result.stdout.strip().splitlines())
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

        if total_modified > 20:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"{total_modified} files modified in last 24h",
                             remediation="Investigate unexpected file changes")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail=f"{total_modified} files modified in last 24h")

    # ------------------------------------------------------------------
    # PA-SYS04: Anomalous cron/systemd tasks
    # ------------------------------------------------------------------
    def _sys04_cron(self):
        check_id = "PA-SYS04"
        title = "Anomalous scheduled tasks (cron/systemd)"

        if os.geteuid() != 0:
            self.skip(check_id, title, Severity.HIGH, "Requires root to inspect system cron")
            return

        suspicious = []
        import re
        # Remote download + execute patterns
        suspect_patterns = [
            re.compile(r"(curl|wget)\s.*\|\s*(bash|sh|zsh|python|perl)", re.IGNORECASE),
            re.compile(r"(curl|wget)\s.*&&\s*(bash|sh|zsh|python|perl)", re.IGNORECASE),
            re.compile(r"(curl|wget)\s.*;\s*(bash|sh|zsh|python|perl)", re.IGNORECASE),
            re.compile(r"(curl|wget)\s+-o\s+\S+.*&&\s*(chmod|\./)"),
        ]

        def _check_cron_lines(text: str, source: str):
            for line in text.splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    if any(p.search(line) for p in suspect_patterns):
                        suspicious.append(f"[{source}] {line[:80]}")

        # Check current user crontab
        try:
            result = subprocess.run(["crontab", "-l"], capture_output=True, text=True, timeout=5)
            if result.returncode == 0 and result.stdout.strip():
                _check_cron_lines(result.stdout, "crontab")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # Check system-level cron files
        system_cron_paths = [Path("/etc/crontab")]
        cron_d = Path("/etc/cron.d")
        if cron_d.is_dir():
            system_cron_paths.extend(cron_d.glob("*"))
        for cron_file in system_cron_paths:
            if cron_file.is_file():
                try:
                    _check_cron_lines(cron_file.read_text(errors="ignore"), str(cron_file))
                except OSError:
                    pass

        # Check systemd timers
        try:
            result = subprocess.run(
                ["systemctl", "list-timers", "--all", "--no-pager"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                for line in result.stdout.splitlines():
                    if any(p.search(line) for p in suspect_patterns):
                        suspicious.append(f"[systemd] {line.strip()[:80]}")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        if suspicious:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Suspicious tasks: {'; '.join(suspicious[:3])}",
                             remediation="Review and remove unauthorized cron jobs")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-SYS05: SSH brute force attempts
    # ------------------------------------------------------------------
    def _sys05_ssh_bruteforce(self):
        check_id = "PA-SYS05"
        title = "SSH brute force attempts in last 24h"

        if os.geteuid() != 0:
            self.skip(check_id, title, Severity.HIGH, "Requires root to read auth logs")
            return

        failed_count = 0

        # Try journalctl
        try:
            result = subprocess.run(
                ["journalctl", "-u", "sshd", "--since", "24 hours ago", "--no-pager"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout:
                text = result.stdout.lower()
                failed_count = text.count("failed") + text.count("invalid")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # Fallback: auth.log (filter last 24h by date prefix)
        if failed_count == 0:
            import re
            from datetime import datetime, timedelta
            cutoff = datetime.now() - timedelta(hours=24)

            for log in ("/var/log/auth.log", "/var/log/secure"):
                if not Path(log).is_file():
                    continue
                try:
                    with open(log, errors="ignore") as fh:
                        for line in fh:
                            if not re.search(r"sshd.*(Failed|Invalid)", line, re.IGNORECASE):
                                continue
                            # auth.log format: "Mon DD HH:MM:SS"
                            try:
                                parts = line.split()[:3]
                                ts = datetime.strptime(
                                    f"{cutoff.year} {parts[0]} {parts[1]} {parts[2]}",
                                    "%Y %b %d %H:%M:%S",
                                )
                                if ts >= cutoff:
                                    failed_count += 1
                            except (ValueError, IndexError):
                                pass
                except OSError:
                    pass
                break

        if failed_count > 100:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"{failed_count} failed SSH attempts",
                             remediation="Configure fail2ban, disable password auth, use key-only SSH")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail=f"{failed_count} failed SSH attempts")

    # ------------------------------------------------------------------
    # PA-SYS06: Node.js version CVE
    # ------------------------------------------------------------------
    def _sys06_nodejs_cve(self):
        check_id = "PA-SYS06"
        title = "Node.js version vulnerable (CVE-2026-21636)"

        try:
            result = subprocess.run(
                ["node", "--version"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0:
                self.skip(check_id, title, Severity.CRITICAL,
                          "Node.js not found")
                return

            ver = result.stdout.strip().lstrip("v")
            parts = ver.split(".")
            major = int(parts[0])
            minor = int(parts[1]) if len(parts) > 1 else 0
            patch = int(parts[2]) if len(parts) > 2 else 0

            # CVE-2026-21636 fixed versions per release line:
            # 18.x: >= 18.20.6, 20.x: >= 20.18.3, 22.x: >= 22.14.0, 23.x: >= 23.7.0
            vulnerable = False
            if major == 18 and (minor < 20 or (minor == 20 and patch < 6)):
                vulnerable = True
            elif major == 20 and (minor < 18 or (minor == 18 and patch < 3)):
                vulnerable = True
            elif major == 22 and minor < 14:
                vulnerable = True
            elif major == 23 and minor < 7:
                vulnerable = True
            # Other major versions (e.g. 19, 21) are EOL — flag as vulnerable
            elif major < 18 or major in (19, 21):
                vulnerable = True

            if vulnerable:
                self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                 detail=f"Node.js {ver} is vulnerable",
                                 remediation="Upgrade Node.js to >= 18.20.6, >= 20.18.3, >= 22.14.0, or >= 23.7.0")
            else:
                self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                                 detail=f"Node.js {ver} not affected")

        except (FileNotFoundError, subprocess.TimeoutExpired):
            self.skip(check_id, title, Severity.CRITICAL,
                      "Node.js not installed")

