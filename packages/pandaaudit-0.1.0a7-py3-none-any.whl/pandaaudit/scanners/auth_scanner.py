"""PA-AUTH* — Authentication & authorization scanner."""

import re
from typing import List, Optional

from pandaaudit.scanners.base import BaseScanner
from pandaaudit.models.finding import Finding
from pandaaudit.models.severity import Severity, Category


class AuthScanner(BaseScanner):
    category = Category.AUTH
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-AUTH01": self._auth01_default_creds,
            "PA-AUTH02": self._auth03_ui_bypass,
        }
        if not self.discovery.config_files:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw config files found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-AUTH01: Default/weak credentials
    # ------------------------------------------------------------------
    def _auth01_default_creds(self):
        check_id = "PA-AUTH01"
        title = "Default/weak credentials"
        weak_patterns = [
            r'["\']?token["\']?\s*[:=]\s*["\']?(changeme|password|admin|default|test|12345|undefined)["\']?',
        ]

        for f in self.discovery.config_files:
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pat in weak_patterns:
                if re.search(pat, text, re.IGNORECASE):
                    self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                     detail=f"Weak credential found in {f.name}",
                                     remediation="Set a strong, unique token (>= 16 chars)")
                    return

        # Check credential length
        cred_pattern = re.compile(
            r'["\']?(token|secret|password|api[_-]?key|apiKey)["\']?\s*[:=]\s*["\']([^"\']{1,7})["\']',
            re.IGNORECASE,
        )
        for f in self.discovery.config_files:
            if f.name == ".env":
                continue
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            match = cred_pattern.search(text)
            if match:
                field, value = match.group(1), match.group(2)
                self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                 detail=f"{field} too short ({len(value)} chars) in {f.name}",
                                 remediation="Use a credential with at least 16 characters")
                return

        self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-AUTH02: Control UI auth bypass
    # ------------------------------------------------------------------
    def _auth03_ui_bypass(self):
        check_id = "PA-AUTH02"
        title = "Control UI auth bypass enabled"

        bypass_pattern = r'["\']?(dangerouslyDisableDeviceAuth|allowInsecureAuth)["\']?\s*[:=]\s*(true|yes|1)'
        if self.discovery.config_grep(bypass_pattern):
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             remediation="Set dangerouslyDisableDeviceAuth and allowInsecureAuth to false")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

