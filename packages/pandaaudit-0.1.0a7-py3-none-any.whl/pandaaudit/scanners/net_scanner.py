"""PA-NET* — Network exposure scanner."""

import re
import socket
import subprocess
from typing import List, Optional

from pandaaudit.scanners.base import BaseScanner
from pandaaudit.models.finding import Finding
from pandaaudit.models.severity import Severity, Category


class NetScanner(BaseScanner):
    category = Category.NET
    mode = "both"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-NET01": self._net01_gateway_18789,
            "PA-NET02": self._net02_tls,
            "PA-NET03": self._net03_anon_access,
            "PA-NET04": self._net04_ioc,
        }
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-NET01: Gateway 18789 binding 0.0.0.0
    # ------------------------------------------------------------------
    def _net01_gateway_18789(self):
        check_id = "PA-NET01"
        title = "Gateway port 18789 binding 0.0.0.0"

        if self.target:
            # Remote: try to connect
            if self._port_open(self.target, 18789):
                self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                 detail=f"{self.target}:18789 is reachable",
                                 remediation="Bind gateway to 127.0.0.1")
            else:
                self.add_finding(check_id, title, Severity.CRITICAL, "PASS")
            return

        # Local: check ss/netstat
        exposed = self._check_port_binding(18789)
        if exposed:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail="Port 18789 listening on 0.0.0.0 or [::]",
                             remediation="Bind gateway to 127.0.0.1")
        elif exposed is None:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="Port 18789 not listening (gateway not running)")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="Port 18789 bound to localhost only")

    # ------------------------------------------------------------------
    # PA-NET02: TLS/HTTPS missing
    # ------------------------------------------------------------------
    def _net02_tls(self):
        check_id = "PA-NET02"
        title = "TLS/HTTPS not detected"

        if not self.target:
            self.skip(check_id, title, Severity.WARNING, "Remote mode only")
            return

        try:
            import ssl
            ctx = ssl.create_default_context()
            with socket.create_connection((self.target, self.port), timeout=5) as sock:
                with ctx.wrap_socket(sock, server_hostname=self.target):
                    self.add_finding(check_id, title, Severity.WARNING, "PASS",
                                     detail="TLS connection succeeded")
                    return
        except Exception:
            self.add_finding(check_id, title, Severity.WARNING, "FAIL",
                             detail=f"No TLS on {self.target}:{self.port}",
                             remediation="Put a TLS-terminating reverse proxy (Nginx/Caddy) in front of Gateway")

    # ------------------------------------------------------------------
    # PA-NET03: Anonymous remote access
    # ------------------------------------------------------------------
    def _net03_anon_access(self):
        check_id = "PA-NET03"
        title = "Anonymous remote access (unauthenticated)"

        if not self.target:
            self.skip(check_id, title, Severity.CRITICAL, "Remote mode only")
            return

        try:
            import urllib.request
            url = f"http://{self.target}:{self.port}"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=10) as resp:
                if resp.status == 200:
                    self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                     detail=f"HTTP 200 from {url} without auth",
                                     remediation="Enable authentication for gateway")
                    return
        except Exception:
            pass

        self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                         detail="Not accessible or requires auth")

    # ------------------------------------------------------------------
    # PA-NET04: Network IOC detection
    # ------------------------------------------------------------------
    def _net04_ioc(self):
        check_id = "PA-NET04"
        title = "Network IOC detection (outbound C2 connections)"

        if self.target:
            self.skip(check_id, title, Severity.HIGH, "Local mode only")
            return

        # Load IOC list
        ioc_ips, ioc_domains = self._load_ioc_list()
        if not ioc_ips and not ioc_domains:
            self.skip(check_id, title, Severity.HIGH, "IOC database could not be loaded")
            return

        # Check established connections
        result = None
        try:
            result = subprocess.run(
                ["ss", "-tunp", "state", "established"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0:
                result = None
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        if result is None:
            try:
                result = subprocess.run(
                    ["netstat", "-an"],
                    capture_output=True, text=True, timeout=5,
                )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                self.skip(check_id, title, Severity.HIGH, "ss/netstat command not available")
                return

        hits = []
        for line in result.stdout.splitlines():
            for ip in ioc_ips:
                if ip in line:
                    hits.append(f"IOC IP {ip}")
            for domain in ioc_domains:
                if domain in line:
                    hits.append(f"IOC domain {domain}")

        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Matched: {'; '.join(hits[:5])}",
                             remediation="Investigate outbound connections to known malicious hosts")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail=f"No IOC matches ({len(ioc_ips)} IPs, {len(ioc_domains)} domains checked)")

    def _load_ioc_list(self):
        """Load IOC list from bundled YAML data."""
        from pathlib import Path
        ioc_path = Path(__file__).resolve().parent.parent / "data" / "ioc_list.yaml"
        if not ioc_path.is_file():
            return [], []
        try:
            import yaml
            data = yaml.safe_load(ioc_path.read_text())
            ips = data.get("ips", []) if data else []
            domains = data.get("domains", []) if data else []
            return ips, domains
        except Exception:
            return [], []

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _port_open(self, host: str, port: int, timeout: float = 3) -> bool:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except (OSError, socket.timeout):
            return False

    def _check_port_binding(self, port: int) -> Optional[bool]:
        """Check if port is bound to 0.0.0.0. Returns True/False/None (not listening)."""
        try:
            result = subprocess.run(
                ["ss", "-tunlp"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0:
                return None
        except (FileNotFoundError, subprocess.TimeoutExpired):
            # Fallback: try netstat
            try:
                result = subprocess.run(
                    ["netstat", "-tunlp"],
                    capture_output=True, text=True, timeout=5,
                )
                if result.returncode != 0:
                    return None
            except (FileNotFoundError, subprocess.TimeoutExpired):
                # Fallback: try lsof (macOS)
                try:
                    result = subprocess.run(
                        ["lsof", "-iTCP", "-sTCP:LISTEN", "-nP"],
                        capture_output=True, text=True, timeout=5,
                    )
                    if result.returncode != 0:
                        return None
                except (FileNotFoundError, subprocess.TimeoutExpired):
                    return None

        output = result.stdout
        found = False
        for line in output.splitlines():
            if f":{port}" not in line:
                continue
            found = True
            if f"0.0.0.0:{port}" in line or f"[::]:{port}" in line or f"*:{port}" in line:
                return True

        return None if not found else False
