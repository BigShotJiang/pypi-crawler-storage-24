"""CVE database updater — fetches from OSV.dev and GitHub Advisory APIs."""

from pathlib import Path
from typing import List, Dict, Any

import click
import requests
import yaml

from pandaaudit.cvedb.matcher import load_cvedb, CVE_DB_PATH

OSV_API = "https://api.osv.dev/v1/query"
GITHUB_API = "https://api.github.com/advisories"


def update_cvedb(source: str = "all"):
    """Update local CVE database from upstream sources."""
    click.echo(f"Updating CVE database (source: {source})...")

    existing = load_cvedb()
    existing_ids = {c["id"] for c in existing}
    new_cves: List[Dict[str, Any]] = []

    if source in ("all", "osv"):
        click.echo("Fetching from OSV.dev...")
        try:
            new_cves.extend(_fetch_osv())
        except Exception as e:
            click.echo(f"  OSV fetch failed: {e}", err=True)

    if source in ("all", "github"):
        click.echo("Fetching from GitHub Advisory...")
        try:
            new_cves.extend(_fetch_github())
        except Exception as e:
            click.echo(f"  GitHub fetch failed: {e}", err=True)

    added = 0
    for cve in new_cves:
        if cve["id"] not in existing_ids:
            existing.append(cve)
            existing_ids.add(cve["id"])
            added += 1

    _save_cvedb(existing)
    click.echo(f"Updated: {added} new CVEs added, {len(existing)} total")


def _fetch_osv() -> List[Dict[str, Any]]:
    """Fetch from OSV.dev REST API."""
    results = []
    body = {"package": {"name": "openclaw", "ecosystem": "npm"}}
    resp = requests.post(OSV_API, json=body, timeout=30)
    resp.raise_for_status()
    data = resp.json()

    for vuln in data.get("vulns", []):
        cve_id = vuln.get("id", "")
        title = vuln.get("summary", "")
        severity = _normalize_severity(
            vuln.get("database_specific", {}).get("severity", "MEDIUM")
        )

        # Parse affected version range
        affected = ""
        for aff in vuln.get("affected", []):
            for rng in aff.get("ranges", []):
                for event in rng.get("events", []):
                    if "fixed" in event:
                        affected = f"< {event['fixed']}"
                        break

        cvss = vuln.get("database_specific", {}).get("cvss", {}).get("score", None)
        entry: Dict[str, Any] = {
            "id": cve_id,
            "title": title,
            "severity": severity,
            "affected": affected,
        }
        if cvss is not None:
            entry["cvss"] = cvss
        results.append(entry)

    return results


def _fetch_github() -> List[Dict[str, Any]]:
    """Fetch from GitHub Advisory Database REST API."""
    results = []
    params = {"ecosystem": "npm", "affects": "openclaw", "per_page": 100}
    headers = {"Accept": "application/vnd.github+json"}

    # Use token if available
    import os
    token = os.environ.get("GITHUB_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"

    resp = requests.get(GITHUB_API, params=params, headers=headers, timeout=30)
    resp.raise_for_status()
    advisories = resp.json()

    for adv in advisories:
        cve_id = adv.get("cve_id") or adv.get("ghsa_id", "")
        title = adv.get("summary", "")
        severity = _normalize_severity(adv.get("severity", "MEDIUM"))
        cvss = adv.get("cvss", {}).get("score") if adv.get("cvss") else None

        affected = ""
        vulns = adv.get("vulnerabilities", [])
        if vulns:
            affected = vulns[0].get("vulnerable_version_range", "")

        entry: Dict[str, Any] = {
            "id": cve_id,
            "title": title,
            "severity": severity,
            "affected": affected,
        }
        if cvss is not None:
            entry["cvss"] = cvss
        results.append(entry)

    return results


def _normalize_severity(sev: str) -> str:
    return sev.strip().upper()


def _save_cvedb(cves: List[Dict[str, Any]]):
    """Write CVE database back to YAML."""
    CVE_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(CVE_DB_PATH, "w") as f:
        yaml.dump(cves, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
