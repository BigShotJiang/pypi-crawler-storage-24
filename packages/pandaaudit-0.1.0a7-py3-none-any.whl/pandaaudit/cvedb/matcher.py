"""CVE version matching engine."""

from pathlib import Path
from typing import List, Dict, Any, Optional

import yaml
from packaging.version import Version


CVE_DB_PATH = Path(__file__).resolve().parent.parent.parent / "cvedb" / "openclaw_cves.yaml"


def load_cvedb(path: Optional[Path] = None) -> List[Dict[str, Any]]:
    """Load CVE database from YAML."""
    db_path = path or CVE_DB_PATH
    if not db_path.is_file():
        return []
    with open(db_path, "r") as f:
        data = yaml.safe_load(f)
    return data or []


def match_version(version_str: str, cves: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """Return CVEs that affect the given version."""
    if cves is None:
        cves = load_cvedb()

    try:
        ver = Version(version_str)
    except Exception:
        return []

    matched = []
    for cve in cves:
        affected = cve.get("affected", "")
        if _version_in_range(ver, affected):
            matched.append(cve)

    return matched


def _version_in_range(ver: Version, affected: str) -> bool:
    """Check if version matches an affected range string.

    Supported formats:
        "< 4.2.1"
        "<= 4.2.1"
        ">= 4.0.0, < 4.2.1"
    """
    if not affected or not affected.strip():
        return False

    # Split on comma for range expressions
    parts = [p.strip() for p in affected.split(",")]

    for part in parts:
        if not _check_constraint(ver, part):
            return False
    return True


def _check_constraint(ver: Version, constraint: str) -> bool:
    """Check a single version constraint like '< 4.2.1' or '>= 4.0.0'."""
    constraint = constraint.strip()

    if constraint.startswith("<="):
        threshold_str = constraint[2:].strip()
        try:
            return ver <= Version(threshold_str)
        except Exception:
            return False
    elif constraint.startswith("<"):
        threshold_str = constraint[1:].strip()
        try:
            return ver < Version(threshold_str)
        except Exception:
            return False
    elif constraint.startswith(">="):
        threshold_str = constraint[2:].strip()
        try:
            return ver >= Version(threshold_str)
        except Exception:
            return False
    elif constraint.startswith(">"):
        threshold_str = constraint[1:].strip()
        try:
            return ver > Version(threshold_str)
        except Exception:
            return False
    elif constraint.startswith("="):
        threshold_str = constraint.lstrip("= ").strip()
        try:
            return ver == Version(threshold_str)
        except Exception:
            return False

    return False
