"""Base formatter."""

from abc import ABC, abstractmethod
from typing import List

from pandaaudit.models.finding import Finding


class BaseFormatter(ABC):
    @abstractmethod
    def format(self, findings: List[Finding]) -> str:
        ...
