"""Output formatters."""

from pandaaudit.formatters.base import BaseFormatter
from pandaaudit.formatters.terminal import TerminalFormatter
from pandaaudit.formatters.json_fmt import JsonFormatter
from pandaaudit.formatters.sarif import SarifFormatter
from pandaaudit.formatters.markdown import MarkdownFormatter


def get_formatter(name: str) -> BaseFormatter:
    formatters = {
        "terminal": TerminalFormatter,
        "json": JsonFormatter,
        "sarif": SarifFormatter,
        "markdown": MarkdownFormatter,
    }
    cls = formatters.get(name)
    if cls is None:
        raise ValueError(f"Unknown format: {name}")
    return cls()
