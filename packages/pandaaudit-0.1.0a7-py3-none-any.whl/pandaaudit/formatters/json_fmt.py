"""JSON formatter."""

import json
from typing import List

from pandaaudit.formatters.base import BaseFormatter
from pandaaudit.models.finding import Finding


class JsonFormatter(BaseFormatter):
    def format(self, findings: List[Finding]) -> str:
        data = {
            "version": "0.1.0",
            "total": len(findings),
            "summary": {
                "fail": sum(1 for f in findings if f.status == "FAIL"),
                "pass": sum(1 for f in findings if f.status == "PASS"),
                "skip": sum(1 for f in findings if f.status == "SKIP"),
            },
            "findings": [f.to_dict() for f in findings],
        }
        return json.dumps(data, indent=2, ensure_ascii=False)
