"""PandaAudit CLI entry point."""

import click

from pandaaudit import __version__


@click.group()
@click.version_option(__version__, prog_name="pandaaudit")
def cli():
    """PandaAudit - OpenClaw security audit tool."""
    pass


# Register sub-commands
from pandaaudit.cli.commands.scan import scan  # noqa: E402
from pandaaudit.cli.commands.cvedb import cvedb  # noqa: E402
from pandaaudit.cli.commands.baseline import baseline  # noqa: E402

cli.add_command(scan)
cli.add_command(cvedb)
cli.add_command(baseline)


if __name__ == "__main__":
    cli()
