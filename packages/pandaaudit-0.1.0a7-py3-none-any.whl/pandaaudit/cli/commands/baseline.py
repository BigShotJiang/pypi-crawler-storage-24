"""pandaaudit baseline command."""

import hashlib
import json
from pathlib import Path
from typing import Optional

import click

from pandaaudit.config.discovery import OpenClawDiscovery


@click.group()
def baseline():
    """Manage security baselines."""
    pass


@baseline.command()
@click.option("--path", default=None, help="OpenClaw install directory")
def init(path: Optional[str]):
    """Generate config + skill/MCP file SHA256 baseline."""
    discovery = OpenClawDiscovery(explicit_path=path)

    if not discovery.install_dir:
        click.echo("Error: No OpenClaw installation found.", err=True)
        raise SystemExit(1)

    install_dir = discovery.install_dir
    baseline_dir = install_dir / "security-baselines"
    baseline_dir.mkdir(parents=True, exist_ok=True)

    # Config file baseline
    config_lines = []
    for cf in discovery.config_files:
        sha = hashlib.sha256(cf.read_bytes()).hexdigest()
        config_lines.append(f"{sha}  {cf}")

    config_baseline = install_dir / ".config-baseline.sha256"
    config_baseline.write_text("\n".join(config_lines) + "\n")
    click.echo(f"Config baseline: {len(config_lines)} file(s) -> {config_baseline}")

    # Skill/MCP file baseline
    skill_mcp_lines = []
    for subdir_name in ("skills", "mcp"):
        subdir = install_dir / "workspace" / subdir_name
        if not subdir.is_dir():
            continue
        for f in sorted(subdir.rglob("*")):
            if f.is_file():
                sha = hashlib.sha256(f.read_bytes()).hexdigest()
                skill_mcp_lines.append(f"{sha}  {f}")

    skill_baseline = baseline_dir / "skill-mcp-baseline.sha256"
    skill_baseline.write_text("\n".join(skill_mcp_lines) + "\n")
    click.echo(f"Skill/MCP baseline: {len(skill_mcp_lines)} file(s) -> {skill_baseline}")


@baseline.command()
@click.option("--path", default=None, help="OpenClaw install directory")
def mcp(path: Optional[str]):
    """Snapshot current MCP server tool list for rug pull detection."""
    discovery = OpenClawDiscovery(explicit_path=path)

    if not discovery.install_dir:
        click.echo("Error: No OpenClaw installation found.", err=True)
        raise SystemExit(1)

    install_dir = discovery.install_dir
    baseline_dir = install_dir / "security-baselines"
    baseline_dir.mkdir(parents=True, exist_ok=True)

    tool_map: dict = {}
    for cf in discovery.config_files:
        if cf.suffix != ".json":
            continue
        try:
            data = json.loads(cf.read_text())
        except Exception:
            continue
        servers = data.get("mcpServers", {})
        if not isinstance(servers, dict):
            continue
        for server_name, server_cfg in servers.items():
            tools = server_cfg.get("tools", [])
            names = []
            if isinstance(tools, list):
                for tool in tools:
                    if isinstance(tool, dict):
                        names.append(tool.get("name", ""))
                    else:
                        names.append(str(tool))
            tool_map[server_name] = sorted(names)

    out_file = baseline_dir / "mcp-tools-baseline.json"
    out_file.write_text(json.dumps(tool_map, indent=2) + "\n")
    click.echo(f"MCP tool baseline: {len(tool_map)} server(s) -> {out_file}")


@baseline.command()
@click.option("--path", default=None, help="OpenClaw install directory")
def show(path: Optional[str]):
    """Show current baseline status."""
    discovery = OpenClawDiscovery(explicit_path=path)

    if not discovery.install_dir:
        click.echo("No OpenClaw installation found.")
        return

    install_dir = discovery.install_dir

    baselines = [
        ("Config baseline", install_dir / ".config-baseline.sha256"),
        ("Skill/MCP baseline", install_dir / "security-baselines" / "skill-mcp-baseline.sha256"),
        ("MCP tool baseline", install_dir / "security-baselines" / "mcp-tools-baseline.json"),
    ]

    for name, p in baselines:
        if p.is_file():
            import datetime
            mtime = p.stat().st_mtime
            ts = datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
            click.echo(f"  {name}: EXISTS (generated {ts})")
        else:
            click.echo(f"  {name}: NOT FOUND")
