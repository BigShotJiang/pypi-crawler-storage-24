"""pandaaudit scan command."""

import sys
from typing import List, Optional

import click

from pandaaudit.config.discovery import OpenClawDiscovery
from pandaaudit.models.finding import Finding
from pandaaudit.models.severity import Category


# Scanner registry: category -> scanner class
def _get_scanner_classes():
    from pandaaudit.scanners.net_scanner import NetScanner
    from pandaaudit.scanners.auth_scanner import AuthScanner
    from pandaaudit.scanners.conf_scanner import ConfScanner
    from pandaaudit.scanners.exec_scanner import ExecScanner
    from pandaaudit.scanners.sc_scanner import ScScanner
    from pandaaudit.scanners.data_scanner import DataScanner
    from pandaaudit.scanners.sys_scanner import SysScanner
    from pandaaudit.scanners.cve_scanner import CveScanner

    return {
        Category.NET: NetScanner,
        Category.AUTH: AuthScanner,
        Category.CONF: ConfScanner,
        Category.EXEC: ExecScanner,
        Category.SC: ScScanner,
        Category.DATA: DataScanner,
        Category.SYS: SysScanner,
        Category.CVE: CveScanner,
    }


def _parse_categories(value: Optional[str]) -> Optional[List[Category]]:
    if not value:
        return None
    result = []
    for name in value.split(","):
        name = name.strip().upper()
        try:
            result.append(Category(name))
        except ValueError:
            raise click.BadParameter(f"Unknown category: {name}")
    return result


def _parse_checks(value: Optional[str]) -> Optional[List[str]]:
    if not value:
        return None
    return [c.strip().upper() for c in value.split(",")]


@click.command()
@click.option("--mode", type=click.Choice(["local", "remote"]), default="local", help="Scan mode")
@click.option("--path", default=None, help="OpenClaw install directory (local mode)")
@click.option("--target", default=None, help="Target IP/domain (remote mode)")
@click.option("--port", default=18789, type=int, help="Target port (remote mode)")
@click.option("--category", default=None, help="Only scan specified categories (comma-separated)")
@click.option("--check", default=None, help="Only run specified check IDs (comma-separated)")
@click.option("--format", "fmt", type=click.Choice(["terminal", "json", "sarif", "markdown"]), default="terminal")
@click.option("-o", "--output", default=None, type=click.Path(), help="Output file")
def scan(mode, path, target, port, category, check, fmt, output):
    """Run security scan on OpenClaw instance."""
    if mode == "remote" and not target:
        raise click.UsageError("--target is required for remote mode")

    discovery = OpenClawDiscovery(explicit_path=path)

    if mode == "local":
        _print_discovery_info(discovery)

    categories = _parse_categories(category)
    checks = _parse_checks(check)

    all_findings: List[Finding] = []
    scanner_classes = _get_scanner_classes()

    for cat, cls in scanner_classes.items():
        # Filter by category
        if categories and cat not in categories:
            continue

        # Filter by mode compatibility
        scanner = cls(discovery, target=target or "", port=port)
        if mode == "remote" and scanner.mode == "local":
            continue
        if mode == "local" and scanner.mode == "remote":
            continue

        findings = scanner.run(checks=checks)
        all_findings.extend(findings)

    # Output
    _output_results(all_findings, fmt, output)

    # Exit code
    has_critical = any(f.status == "FAIL" and f.severity.value == "CRITICAL" for f in all_findings)
    has_fail = any(f.status == "FAIL" for f in all_findings)
    if has_critical:
        sys.exit(2)
    elif has_fail:
        sys.exit(1)


def _print_discovery_info(discovery: OpenClawDiscovery):
    from rich.console import Console
    console = Console(stderr=True)

    if discovery.config_files:
        console.print(f"[cyan]Found {len(discovery.config_files)} config file(s)[/cyan]")
        for f in discovery.config_files:
            console.print(f"  [dim]{f}[/dim]")
    else:
        console.print("[yellow]No OpenClaw config files found. Scanning system-level checks only.[/yellow]")

    if discovery.version:
        console.print(f"[cyan]OpenClaw version: {discovery.version}[/cyan]")
    console.print()


def _output_results(findings: List[Finding], fmt: str, output: Optional[str]):
    from pandaaudit.formatters import get_formatter

    formatter = get_formatter(fmt)
    text = formatter.format(findings)

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(text)
    else:
        if fmt == "terminal":
            # terminal formatter prints directly
            pass
        else:
            click.echo(text)
