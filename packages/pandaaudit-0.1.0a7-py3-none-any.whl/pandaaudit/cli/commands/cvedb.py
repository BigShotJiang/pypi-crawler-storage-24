"""pandaaudit cvedb command."""

import click


@click.group()
def cvedb():
    """Manage CVE database."""
    pass


@cvedb.command()
@click.option("--source", type=click.Choice(["github", "osv", "all"]), default="all")
def update(source):
    """Update local CVE database from upstream sources."""
    from pandaaudit.cvedb.fetcher import update_cvedb
    update_cvedb(source)


@cvedb.command(name="list")
@click.option("--severity", default=None, help="Filter by severity (e.g. critical, high)")
def list_cves(severity):
    """List CVEs in local database."""
    from pandaaudit.cvedb.matcher import load_cvedb

    cves = load_cvedb()
    if severity:
        cves = [c for c in cves if c.get("severity", "").upper() == severity.upper()]

    if not cves:
        click.echo("No CVEs found.")
        return

    for cve in cves:
        sev = cve.get("severity", "?")
        title = cve.get("title", "")
        affected = cve.get("affected", "")
        click.echo(f"  {cve['id']}  [{sev}]  {title}  (affected: {affected})")
