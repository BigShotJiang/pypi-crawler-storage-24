from pygame import*
from random import*
from .config import map, mario_lives

def run():

    global fire_time1, fire_time2, move, game, fire, no_fire, time_set, fireball_set, mari, mm, big, lives, score, run_coin_thing, run_goomba_squish, run_mario_death_fall, all_goombas_die, question_block_hit, question_hit_type, question_hit_chords

    def text(message,x,y,font_color,font_size, font_type='assets/font.otf'):
        font_type=font.Font(font_type,font_size)
        text=font_type.render(message,True,font_color)
        window.blit(text, (x,y))




    init()

    lives = mario_lives - 1

    coin_timer_event = USEREVENT + 1
    run_coin_thing = False

    goomba_timer_event = USEREVENT + 2
    run_goomba_squish = False

    mario_death_event = USEREVENT + 3
    run_mario_death_fall = False

    all_goombas_die = False

    fireball_set=0
    mari=0
    mm=0
    move=0
    fire=0
    no_fire=0
    mixer.music.load('assets/mario_theme.mp3')
    mixer.music.play(-1)
    mixer.music.set_volume(0.5)
    ouchs=mixer.Sound('assets/ouchs.mp3')
    bye=mixer.Sound('assets/goomba-destroy.wav')
    mx=43
    my=80
    big=0
    game=1
    time_set=0
    fire_time1=time.get_ticks()
    fire_time2=time.get_ticks()
    end=mixer.Sound('assets/game_over.mp3')
    die = mixer.Sound('assets/die.mp3')
    jump=mixer.Sound('assets/stomp.wav')
    sound=0
    jump_count=30
    score = 0
    goomba_direction=0
    csound=mixer.Sound('assets/coin-sound.wav')
    power=mixer.Sound('assets/power-up.wav')
    win=mixer.Sound('assets/mario-win.mp3')
    mixer.Sound.set_volume(win, 3)
    goomba_bye=0
    black = (0,0,0)
    red = (255,0,0)
    green = (0,255,0)
    white = (255,255,255)
    mario_blue = (116,147,246)
    question_cooldown=0
    width=1000
    height=495

    question_block_hit = False
    question_hit_type = 'none'
    question_hit_chords = [-1, -1]

    


    def clear_groups():
        tnt_group.empty()
        flower_group.empty()
        obstacle_group.empty()
        ground_group.empty()
        mushroom_group.empty()
        question_group.empty()
        coin_group.empty()
        goomba_group.empty()
        castle_group.empty()
        fireball_group.empty()
        stair_group.empty()
        mario_group.empty()
        firework_group.empty()
        fireball_group.update()


    def hit_question(x, y, type):
        global question_block_hit, question_hit_type, question_hit_chords

        question_block_hit = True
        question_hit_type = type
        question_hit_chords[0] = x
        question_hit_chords[1] = y
        # print(question_hit_chords)


    def restart_game():
        global game, move, lives, big, fire, all_goombas_die
        clear_groups()
        draw_map()
        mixer.music.play(-1)
        game = 1
        move = 0
        big = 0
        fire = 0
        lives -= 1
        all_goombas_die = False



    class  Ground (sprite.Sprite):
        def __init__(self, x,y,id):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/ground.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
            self.id = id
        def update(self):
            global move
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                move=0



    class  Castle (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/mario-castle.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
        def update(self):
            global move
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                move=0



    class  Stair (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/stair.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
        def update(self):
            global move
            # run()
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                # self.rect.x+=10
                move=0



    class  Fireball (sprite.Sprite):
        def __init__(self, x,y,dir):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/fireball.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
            self.direction=dir
            self.fall_speed = 2
            self.on_ground = False
        def upload(self):
            global no_fire
            if no_fire==1:
                self.kill()
            # print('test')
        def update(self):
            
            global no_fire
            # pass
            self.rect.y+=self.fall_speed
            self.fall_speed+=0.5
            bricks=sprite.spritecollide(self,ground_group,False)
            for w in bricks:
                    self.rect.bottom = w.rect.top
                    self.fall_speed=2
                    self.on_ground=True
            if self.on_ground==True:
                # self.jump()
                self.rect.y-=40
                self.on_ground=False
            if self.direction=='right':
                self.rect.x+=5
            else:
                self.rect.x-=5
            if no_fire==1:      
                self.kill
        

    class  Barrier (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/barrier.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]



    class  Fbarrier (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/barrier.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
        def update(self):
            global move
            # run()
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                # self.rect.x+=10
                move=0



    class  Flower (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/fire_flower.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
        def update(self):
            global move
            # run()
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                # self.rect.x+=10
                move=0
            if sprite.spritecollide(self, mario_group, False):
                global fire
                self.kill()
                fire=1

    class  Goomba (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/goomba.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
            self.direction=-3
            self.speed=5
            self.fall_speed = 2
            self.generate=randint(1,2)
            self.mario_approved = False
        def squish(self):
            self.image = image.load('assets/goomba-squish.png')
            time.set_timer(goomba_timer_event, 500, 1)
            self.direction = 0
            self.speed = 0

        def check_if_we_die_when_squished(self):
            global goomba_bye
            if run_goomba_squish and self.mario_approved:
                self.kill()
                mixer.Sound.play(bye)
                # goomba_bye+=1
        def check_if_we_die_when_mario_breakes_his_toes_while_dying_incorrectly(self):
            if all_goombas_die:
                self.kill()
        def update(self):
            global move
            self.check_if_we_die_when_squished()
            self.check_if_we_die_when_mario_breakes_his_toes_while_dying_incorrectly()
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                move=0
                # self.rect.x+=10
            global goomba_bye
            self.rect.y+=self.fall_speed
            self.fall_speed+=0.5
            bricks=sprite.spritecollide(self,ground_group,False)
            for w in bricks:
                    if w.id==0:
                        self.rect.bottom = w.rect.top
                        self.fall_speed = 0
            # if mario.rect.collidepoint(self.rect.centerx,self.rect.top) or sprite.spritecollide(self, fireball_group, True):
                
            #     global game, size
                
            # if mario.rect.collidepoint(self.rect.left,self.rect.centery) or mario.rect.collidepoint(self.rect.right,self.rect.centery):
            #     global sound, game
            #     if lives == 0:
            #         mario.image = image.load('assets/ouch.png')
            #         if sound == 0:
            #             game=0
            #             sound+=1
            #         game = 2
            #         mario.kill()
            #     elif lives > 0:
            #         lives -= 1


            if abs(self.rect.x-mario.rect.x)<20*30:
                if sprite.spritecollide(self,obstacle_group,False):
                    if self.direction==-3:
                        self.direction=3
                    else:
                        self.direction=-3
                self.rect.x+= self.direction
    class  Mushroom (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/mushroom.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
        def update(self):
            global move
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                move=0
                # self.rect.x+=10

    class  Fquestion (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/question.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
            self.state = True
            self.id = randint(1,2)
            self.was_hit = False
            # self.id2 = randint(1,2)
        def clear_vars(self):
            global question_block_hit, question_hit_type, question_hit_chords

            question_block_hit = False
            question_hit_type = 'none'
            question_hit_chords = [-1, -1]
            self.was_hit = True
        def check_hit(self):
            global flower
            if not self.was_hit:
                if big == 1:
                    if question_block_hit:
                        if question_hit_type == 'f':
                            if self.rect.collidepoint(question_hit_chords[0], question_hit_chords[1] - 30):
                                flower = Flower(self.rect.centerx,self.rect.top-13)
                                flower_group.add(flower)
                                self.image = image.load('assets/empty.png')
                                self.rect.y -= 1
                                self.state = False
                                obstacle_group.add(self)
                                self.clear_vars()
                            else:
                                if self.rect.collidepoint(question_hit_chords[0] + 20, question_hit_chords[1] - 30):
                                    flower = Flower(self.rect.centerx,self.rect.top-13)
                                    flower_group.add(flower)
                                    self.image = image.load('assets/empty.png')
                                    self.rect.y -= 1
                                    self.state = False
                                    obstacle_group.add(self)
                                    self.clear_vars()
                elif big == 0:
                    if question_block_hit:
                        if question_hit_type == 'f':
                            if self.rect.collidepoint(question_hit_chords[0], question_hit_chords[1] - 30):
                                mushroom = Mushroom(self.rect.centerx,self.rect.top-13)
                                mushroom_group.add(mushroom)
                                self.image = image.load('assets/empty.png')
                                self.rect.y -= 1
                                self.state = False
                                obstacle_group.add(self)
                                self.clear_vars()
                            else:
                                if self.rect.collidepoint(question_hit_chords[0] + 20, question_hit_chords[1] - 30):
                                    mushroom = Mushroom(self.rect.centerx,self.rect.top-13)
                                    mushroom_group.add(mushroom)
                                    self.image = image.load('assets/empty.png')
                                    self.rect.y -= 1
                                    self.state = False
                                    obstacle_group.add(self)
                                    self.clear_vars()
        def update(self):
            global move
            keys = key.get_pressed()
            if self.state==True:
                if keys[K_RIGHT] and move==1:
                    self.rect.x-=10
                if keys[K_LEFT] and move==1:
                    move=0
            if self.state==False:
                if keys[K_RIGHT] and move==1:
                    self.rect.x-=5
                # self.rect.x+=10
            # if self.rect.colliderect(mario.rect) and self.state == True:
                # if self.id == 1:
                # global flower
                # flower = Flower(self.rect.centerx,self.rect.top-13)
                # flower_group.add(flower)
                # else:
                #     mushroom = Mushroom(self.rect.centerx,self.rect.top-13)
                #     mushroom_group.add(mushroom)
                # self.image = image.load('assets/empty.png')
                # print('yay')
                # self.state = False
                # obstacle_group.add(self)

    class  Question (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/question.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
            self.state = True
            self.id = randint(1,2)
            self.was_hit = False
            # self.id2 = randint(1,2)
        def clear_vars(self):
            global question_block_hit, question_hit_type, question_hit_chords

            question_block_hit = False
            question_hit_type = 'none'
            question_hit_chords = [-1, -1]
        def check_hit(self):
            if not self.was_hit:
                if question_block_hit:
                    if question_hit_type == '?':
                        if self.rect.collidepoint(question_hit_chords[0], question_hit_chords[1] - 30):
                            coin = Coin(self.rect.centerx,self.rect.top-13)
                            coin_group.add(coin)
                            self.image = image.load('assets/empty.png')
                            self.rect.y -= 1
                            self.state = False
                            obstacle_group.add(self)
                            self.clear_vars()
                            self.was_hit = True
                        else:
                            if self.rect.collidepoint(question_hit_chords[0] + 20, question_hit_chords[1] - 30):
                                coin = Coin(self.rect.centerx,self.rect.top-13)
                                coin_group.add(coin)
                                self.image = image.load('assets/empty.png')
                                self.rect.y -= 1
                                self.state = False
                                obstacle_group.add(self)
                                self.clear_vars()
                                self.was_hit = True
        def update(self):
            global move
            # self.check_hit()
            keys = key.get_pressed()
            if self.state==True:
                if keys[K_RIGHT] and move==1:
                    self.rect.x-=10
                if keys[K_LEFT] and move==1:
                    move=0
            if self.state==False:
                if keys[K_RIGHT] and move==1:
                    self.rect.x-=5
            # if keys[K_t]:
                # print(f'x: {self.rect.x} y: {self.rect.y}')
                
    class  Mquestion (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/question.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
            self.state = True
            self.id = randint(1,2)
            self.was_hit = False
            # self.id2 = randint(1,2)
        def clear_vars(self):
            global question_block_hit, question_hit_type, question_hit_chords

            question_block_hit = False
            question_hit_type = 'none'
            question_hit_chords = [-1, -1]
            self.was_hit = True
        def check_hit(self):
            if not self.was_hit:
                if question_block_hit:
                    if question_hit_type == 'm':
                        if self.rect.collidepoint(question_hit_chords[0], question_hit_chords[1] - 30):
                            mushroom = Mushroom(self.rect.centerx,self.rect.top-13)
                            mushroom_group.add(mushroom)
                            self.image = image.load('assets/empty.png')
                            self.state = False
                            obstacle_group.add(self)
                            self.clear_vars()
                        else:
                            if self.rect.collidepoint(question_hit_chords[0] + 20, question_hit_chords[1] - 30):
                                mushroom = Mushroom(self.rect.centerx,self.rect.top-13)
                                mushroom_group.add(mushroom)
                                self.image = image.load('assets/empty.png')
                                self.state = False
                                obstacle_group.add(self)
                                self.clear_vars()
        def update(self):
            global move
            keys = key.get_pressed()
            if self.state==True:
                if keys[K_RIGHT] and move==1:
                    self.rect.x-=10
                if keys[K_LEFT] and move==1:
                    move=0
            if self.state==False:
                if keys[K_RIGHT] and move==1:
                    self.rect.x-=5

    class  Brick (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/mario-brick.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
            self.id = 0
        def update(self):
            global move
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                move=0
                # self.rect.x+=10

    class  Tnt (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/tnt.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
        def update(self):
            global move
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                move=0
            #     self.rect.x+=10

    class  Coin (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/coin2.png').convert_alpha()
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
            self.opacity = 225
            time.set_timer(coin_timer_event, 100, 10)
            self.runtime = 0
        def check_run_coin_thing(self):
            global run_coin_thing, score
            if run_coin_thing:
                self.rect.y -= 3
                self.opacity -= 25
                self.image.set_alpha(self.opacity)
                run_coin_thing = False
                self.runtime += 1
            if self.runtime == 10:
                self.kill()
                mixer.Sound.play(csound)
                score += 1
        def update(self):
            self.check_run_coin_thing()
            global move
            keys = key.get_pressed()
            if keys[K_RIGHT] and move==1:
                self.rect.x-=10
            if keys[K_LEFT] and move==1:
                move=0
            
            
            # if sprite.spritecollide(self, mario_group, False):
            #     self.kill()
            #     mixer.Sound.play(csound)
            #     score+=1
                # print(score)

    class  Mario (sprite.Sprite):
        def __init__(self, x,y):
            sprite.Sprite.__init__(self)
            self.image = image.load('assets/mario1.png')
            self.rect = self.image.get_rect()
            self.rect.center = [x,y]
            self.direction = 'down'
            self.make_jump = False
            self.fall_speed = 2
            self.on_ground = False
            self.mx=36
            self.my=48
            self.gravity = 1
            self.jump_gravity = 2
            self.is_jumping = False
            self.no_clip = False
            self.invincible = False
            self.hurt_time = 0

        def check_fall(self):
            global run_mario_death_fall, game
            if run_mario_death_fall:
                # self.no_clip = True
                game = 2
                run_mario_death_fall = False
        def update(self):
            keys = key.get_pressed()
            # self.check_fall()

            if self.invincible:
                if time.get_ticks() - self.hurt_time >= 1000:
                    self.invincible = False

            global move, mari, mm, fire, fireball_set, fire_time1, fire_time2, time_set, game, no_fire

            # print(game)

            if keys[K_RIGHT] and mario.rect.x >= width/2:
                move = 1

            # if game == 2:
            #     time.set_timer(mario_death_event, 2000, 1)
            
            # if self.invincible:
            #     goomba_thing = 0

            if not self.invincible and not self.no_clip:
                goomba_thing = sprite.spritecollide(self, goomba_group, False)

                for w in goomba_thing:
                    if self.fall_speed >= 0 and self.rect.bottom < w.rect.centery + 10: 
                        self.fall_speed = -20
                        mixer.Sound.play(jump)
                        self.on_ground = False
                        self.is_jumping = True
                        w.squish()
                        w.mario_approved = True
                    
                    else:
                        global sound, lives, all_goombas_die
                        
                        if not self.invincible:
                            
                            all_goombas_die = True
                            game = 2
                            # self.kill()
                            self.no_clip = True
                            # change sprite here
                            mixer.music.stop()
                            self.image = image.load('assets/mario_death.png')
                            time.delay(500)
                            mixer.Sound.play(die)
                            self.invincible = True 
                            self.fall_speed = -15
                            # lives -= 1

                                
                            # elif lives > 0:
                            #     lives -= 1
                            #     self.invincible = True
                            #     self.hurt_time = time.get_ticks()
                            #     print(f"Ouch! Lives remaining: {lives}")


            if sprite.spritecollide(self, testing_group, False):
                no_fire=1
                
                fireball_group.empty()
                game=3
            if self.rect.y >= height:
                if lives == 0:
                    game=0
                elif lives > 0:
                    if self.no_clip:
                        restart_game()
                    else:
                        mixer.music.stop()
                        mixer.Sound.play(die)
                        time.delay(3000)
                        restart_game()
                    return
                
            fire_time2=time.get_ticks()
            # print(fire_time2)
            if sprite.spritecollide(self, fquestion_group, False):
                no_fire=1
            if fire_time2-fire_time1>=500:
                time_set=1
                # fire_time2=fire_time1
                fire_time1=fire_time2
                # print(fire)
            if self.rect.centerx >= width/2:
                move=1
            if keys[K_LEFT] and move==1:
                move=0
            # global fire
            if fire==1:
                self.image = image.load('assets/fire_mario.png')
                fireball_set=fire
                # fire=3
                # pass
            self.rect.y+=self.fall_speed
            if not self.is_jumping:
                self.fall_speed += self.gravity
            elif self.is_jumping:
                self.fall_speed += self.jump_gravity
            # print(self.fall_speed)
            if sprite.spritecollide(self,mushroom_group,True):
                global big
                big=1
                self.mx=36
                self.my=60

                self.image = transform.scale(self.image,(self.mx,self.my))
                self.rect.update(self.rect.x,self.rect.y,self.mx,self.my)

                # self.rect = self.image.get_rect()
                # self.image = transform.scale(self.image,(43,150))
                # print('mushroom')
                mixer.Sound.play(power)
            if sprite.spritecollide(self,tnt_group,False):
                global goomba_bye
                self.image = image.load('assets/ouch.png')
                mixer.Sound.play(ouchs)
            # global keys, fireball
            keys=key.get_pressed()
            
            if fireball_set==1 and keys[K_LCTRL] | keys[K_LSHIFT] and time_set==1:
                fireball=Fireball(self.rect.centerx,self.rect.centery,self.direction)
                fireball_group.add(fireball)
                time_set=0
            
            if not self.no_clip:
                # check collision with question blocks
                bricks=sprite.spritecollide(self,question_group,False)     

                for w in bricks:
                        if self.fall_speed > 0: 
                            self.rect.bottom = w.rect.top
                            self.fall_speed=2
                            self.on_ground=True
                        elif self.fall_speed < 0: 
                            self.rect.top = w.rect.bottom
                            self.fall_speed = 0
                            # print('irregular test')
                            # if map[(self.rect.y - 2) // 30][self.rect.x//30] == '?':
                            # print('test')
                            hit_question(self.rect.x, self.rect.y, '?')
                            w.check_hit()
                            hit_question(self.rect.x, self.rect.y, 'm')
                            w.check_hit()
                            hit_question(self.rect.x, self.rect.y, 'f')
                            w.check_hit()
                
                # check collision with normal obstacles
                bricks=sprite.spritecollide(self,obstacle_group,False)     

                for w in bricks:
                        if self.fall_speed > 0: 
                            self.rect.bottom = w.rect.top
                            self.fall_speed=2
                            self.on_ground=True
                        elif self.fall_speed < 0: 
                            self.rect.top = w.rect.bottom
                            self.fall_speed = 0
                            # print('Ouch!')
            
            
            keys = key.get_pressed()
            if fire==0:
                mari=0
                mm=0
                # global mari, mm
                mari='assets/mario1.png'
                mm='assets/mario1-left.png'
            if fire==1:
                # global mari, mm
                mari='assets/fire_mario.png'
                mm='assets/fire_mario-left.png'
                fire=3
                transform.scale(self.image,(36,60))



            

            if not self.no_clip:

                if move == 0:
                    if keys[K_RIGHT]:
                            if self.direction != 'right':
                                self.image = image.load(mari)
                                self.direction='right'
                                self.image = transform.scale(self.image,(self.mx,self.my))
                                self.rect.update(self.rect.x,self.rect.y,self.mx,self.my)
                            else:
                                self.rect.x += 10
                    if keys[K_LEFT]:
                            if self.direction != 'left':
                                self.image = image.load(mm)
                                self.direction='left'
                                self.image = transform.scale(self.image,(self.mx,self.my))
                                self.rect.update(self.rect.x,self.rect.y,self.mx,self.my)
                            else:
                                self.rect.x -= 10
                if move==1:
                    if keys[K_RIGHT]:
                        if self.direction != 'right':
                                    self.image = image.load(mari)
                                    self.direction='right'
                                    self.image = transform.scale(self.image,(self.mx,self.my))
                    if keys[K_LEFT]:
                        if self.direction != 'left':
                                self.image = image.load(mm)
                                self.direction='left'
                                self.image = transform.scale(self.image,(self.mx,self.my))
                                self.rect.update(self.rect.x,self.rect.y,self.mx,self.my)


                bricks=sprite.spritecollide(self,obstacle_group,False)        
                for w in bricks:
                    if self.direction == 'left':
                        self.rect.left = w.rect.right
                    if self.direction == 'right':
                        self.rect.right = w.rect.left
                        move = 0

                if self.on_ground == True:
                    if keys[K_UP]:
                                # self.direction='up'
                                # self.rect.y-=80
                                self.fall_speed = -20
                                mixer.Sound.play(jump)
                                self.on_ground = False
                                self.is_jumping = True
                if self.fall_speed > 0:
                    self.is_jumping = False
                    # self.direction = 'down'

        def jump(self):
            global jump_count
            if jump_count>=-30:
                self.rect.y-=jump_count/2
                jump_count-=3
            else:
                jump_count=30
                self.make_jump=False

    firework_group = sprite.Group()
    stair_group = sprite.Group()
    castle_group = sprite.Group()
    fireball_group = sprite.Group()
    fquestion_group = sprite.Group()
    flower_group = sprite.Group()
    testing_group = sprite.Group()
    goomba_group = sprite.Group()
    mushroom_group = sprite.Group()
    obstacle_group = sprite.Group()
    ground_group = sprite.Group()
    question_group = sprite.Group()
    mario_group = sprite.Group()
    coin_group = sprite.Group()
    tnt_group = sprite.Group()
    # fireball_group.upload()
    # mario_group.


    def draw_map():

        global mario

        size=30
        x=0
        y=0

        for ro in map:
            for s in ro:
                if s == '-':
                    ground = Ground(x,y,0)
                    obstacle_group.add(ground)
                    ground_group.add(ground)

                if s == '=':
                    ground = Ground(x,y,1)
                    obstacle_group.add(ground)
                    ground_group.add(ground)
                if s == '?':
                    question = Question(x,y)
                    question_group.add(question)
                    # obstacle_group.add(question)
                
                if s == '.':
                    brick = Brick(x,y)
                    obstacle_group.add(brick)
                    ground_group.add(brick)
                if s == 'm':
                    mario = Mario(x,y-10)
                    mario_group.add(mario)
                if s == 't':
                    tnt = Tnt(x,y)
                    tnt_group.add(tnt)
                if s == 'g':
                    goomba = Goomba(x,y)
                    goomba_group.add(goomba)
                if s == 'u':
                    mquestion = Mquestion(x,y)
                    question_group.add(mquestion)
                    # obstacle_group.add(mquestion)
                if s == 'f':
                    fquestion = Fquestion(x,y)
                    question_group.add(fquestion)
                    # obstacle_group.add(fquestion)
                if s == 'b':
                    barrier = Barrier(x,y)
                    obstacle_group.add(barrier)
                if s == 'c':
                    castle = Castle(x,y)
                    castle_group.add(castle)
                if s == 's':
                    stair = Stair(x,y)
                    obstacle_group.add(stair)
                if s == '#':
                    fbarrier = Fbarrier(x,y)
                    testing_group.add(fbarrier)
                x+=size
            x=0
            y+=size

    draw_map()

    size_window = (width, height)
    window = display.set_mode(size_window)
    display.set_caption('Mario')
    run=True
    while run:
        for e in event.get():
            if e.type == QUIT:
                run = False
            if e.type == coin_timer_event:
                run_coin_thing = True
            if e.type == goomba_timer_event:
                run_goomba_squish = True
            if e.type == mario_death_event:
                run_mario_death_fall = True
        window.fill(mario_blue)
        # print(fire_time1)
        if game==1:
            testing_group.update()
            castle_group.update()
            stair_group.update()
            question_group.update()
            coin_group.update()
            obstacle_group.update()
            mushroom_group.update()
            tnt_group.update()
            goomba_group.update()
            flower_group.update()
            # coin_group.update()
            mario_group.update()
            # question_group.update()
        
        if game == 2:
            mario_group.update()

        if game==1 or game == 2 or game==3:
            
            tnt_group.draw(window)
            flower_group.draw(window)
            obstacle_group.draw(window)
            ground_group.draw(window)
            mushroom_group.draw(window)
            question_group.draw(window)
            coin_group.draw(window)
            goomba_group.draw(window)
            castle_group.draw(window)
            fireball_group.draw(window)
            stair_group.draw(window)
            mario_group.draw(window)
            firework_group.draw(window)
            fireball_group.update()

            text(f"Lives: {lives + 1}", 0, 0, white, 30)

            # Fireball.upload(fireball_group)
            

        if game==3:
            # print('test')
            # fireball_group.()
            # Fireball.kill
            # time.delay(1000)
            mixer.music.fadeout(1000)
            firework=image.load('assets/fireworks.png')
            window.blit(firework, (width//2-150, 30))
            mixer.Sound.play(win)
            text('YOU WIN!', width/2-250, height/2-100, 'green', 100)
            display.update()
            time.delay(16000)
            run=False
        
        if game==0:
            mixer.music.fadeout(1000)
            mixer.Sound.play(end)
            text('GAME OVER', width/2-250, height/2-100, 'red', 100)
            display.update()
            time.delay(5000)
            run=False
        
        display.update()
        time.delay(50)
        

    quit()