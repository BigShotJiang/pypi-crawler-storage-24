from __future__ import annotations

import importlib.util
import json
from datetime import date, datetime, timedelta
from pathlib import Path


def _load_impl_module():
    impl_path = Path(__file__).resolve().parent.parent / "main.py"
    spec = importlib.util.spec_from_file_location("jed_api._main_impl", impl_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Failed to load implementation module from {impl_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_impl = _load_impl_module()


def since_days_predicate(days, now=None):
    if days < 0:
        raise ValueError("days must be >= 0")
    now = now or datetime.now()
    threshold = now - timedelta(days=days)
    return lambda dt: dt is not None and dt >= threshold


def date_range_predicate(start_date, end_date=None):
    start = _coerce_date(start_date)
    end = _coerce_date(end_date) if end_date is not None else datetime.now().date()
    if start > end:
        raise ValueError("start_date must be <= end_date")
    return lambda dt: dt is not None and start <= dt.date() <= end


def _coerce_date(value):
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        return datetime.strptime(value, "%Y-%m-%d").date()
    raise TypeError("Expected date or YYYY-MM-DD string")


class JupiterEdClient:
    def __init__(self, credentials=None, config_path="config.json", headless=True):
        self.credentials = credentials
        self.config_path = config_path
        self.headless = headless
        self._started = False

    def start(self):
        if self._started and _impl.driver is not None:
            return self

        if self.credentials is not None:
            _impl.set_credentials(self.credentials)
        else:
            _impl.load_config(self.config_path)

        _impl._init_browser(headless=self.headless)
        self._started = True
        return self

    def close(self):
        try:
            if _impl.driver is not None:
                _impl.driver.quit()
        finally:
            _impl.driver = None
            _impl.wait = None
            self._started = False

    def __enter__(self):
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    @staticmethod
    def parse_message_datetime(label, now=None):
        return _impl._parse_message_datetime(label, now=now)

    def fetch_messages(self, limit=None, predicate=None, json_out=None):
        self.start()
        messages = _impl.fetch_messages(limit=limit, predicate=predicate)
        if json_out:
            with open(json_out, "w", encoding="utf-8") as f:
                json.dump(messages, f, ensure_ascii=False, indent=2)
        return messages

    def all(self, limit=None, json_out=None):
        return self.fetch_messages(limit=limit, predicate=lambda _dt: True, json_out=json_out)

    def newest(self, count, json_out=None):
        if count <= 0:
            raise ValueError("count must be > 0")
        return self.fetch_messages(limit=count, predicate=lambda _dt: True, json_out=json_out)

    def since(self, days, limit=None, json_out=None):
        predicate = since_days_predicate(days)
        return self.fetch_messages(limit=limit, predicate=predicate, json_out=json_out)

    def date_range(self, start_date, end_date=None, limit=None, json_out=None):
        predicate = date_range_predicate(start_date, end_date=end_date)
        return self.fetch_messages(limit=limit, predicate=predicate, json_out=json_out)

    def check_new_messages(
        self,
        state_file="message_state.json",
        update_state=True,
        fetch=False,
        json_out=None,
    ):
        self.start()
        new_messages, inbox_count, known_before = _impl.check_new_messages(
            state_file=state_file,
            update_state=update_state,
        )

        payload = new_messages
        if fetch and new_messages:
            payload = _impl.fetch_selected_messages(new_messages)

        result = {
            "new_messages": payload,
            "inbox_count": inbox_count,
            "known_before": known_before,
            "fetched": bool(fetch),
        }

        if json_out:
            with open(json_out, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)

        return result
