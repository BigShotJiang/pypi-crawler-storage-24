import argparse
import json
import os
import re
import time
from datetime import datetime, timedelta
from urllib.parse import urljoin, urlparse

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


BASE_URL = "https://login.jupitered.com/"
INBOX_URL = "https://login.jupitered.com/login/index.php"


driver = None
wait = None
data = {}

REQUIRED_CONFIG_KEYS = ("name", "password", "school", "city", "state")


def load_config(config_path="config.json"):
    with open(config_path, "r", encoding="utf-8") as file:
        loaded = json.load(file)
    set_credentials(loaded)
    return loaded


def set_credentials(credentials):
    if not isinstance(credentials, dict):
        raise TypeError("credentials must be a dict")
    missing = [key for key in REQUIRED_CONFIG_KEYS if not str(credentials.get(key, "")).strip()]
    if missing:
        raise ValueError(f"Missing credential field(s): {', '.join(missing)}")

    global data
    data = dict(credentials)


def _ensure_credentials():
    missing = [key for key in REQUIRED_CONFIG_KEYS if not str(data.get(key, "")).strip()]
    if missing:
        raise RuntimeError(
            "Credentials are not loaded. "
            "Call load_config(path) or set_credentials({...}) first. "
            f"Missing: {', '.join(missing)}"
        )


def _init_browser(headless=False):
    global driver, wait
    options = webdriver.ChromeOptions()
    if headless:
        options.add_argument("--headless=new")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1920,1080")

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 12)


def _normalize_href(href):
    href = (href or "").strip()
    if not href:
        return ""
    if href.lower().startswith("javascript:"):
        return ""
    return urljoin(BASE_URL, href)


def _clean_lines(text):
    return [line.strip() for line in (text or "").splitlines() if line.strip() and line.strip() not in {"…", "..."}]


def _parse_clock(clock_text):
    raw = (clock_text or "").strip().lower().replace(" ", "")
    if not raw:
        return datetime.min.time().replace(hour=0, minute=0, second=0, microsecond=0)
    for fmt in ("%I:%M%p", "%I%p"):
        try:
            return datetime.strptime(raw, fmt).time()
        except ValueError:
            continue
    return datetime.min.time().replace(hour=0, minute=0, second=0, microsecond=0)


def _parse_message_datetime(label, now=None):
    now = now or datetime.now()
    text = (label or "").strip()
    if not text:
        return None

    lower = text.lower()
    if lower.startswith("today"):
        clock = text[5:].strip()
        return datetime.combine(now.date(), _parse_clock(clock))

    if lower.startswith("yesterday"):
        clock = text[9:].strip()
        return datetime.combine((now - timedelta(days=1)).date(), _parse_clock(clock))

    weekday_map = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}
    wd_match = re.match(r"^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s*(.*)$", text, flags=re.IGNORECASE)
    if wd_match:
        target = weekday_map[wd_match.group(1).lower()[:3]]
        days_back = (now.weekday() - target) % 7
        date_val = (now - timedelta(days=days_back)).date()
        result = datetime.combine(date_val, _parse_clock(wd_match.group(2)))
        if result > now + timedelta(hours=1):
            result -= timedelta(days=7)
        return result

    md_match = re.match(r"^(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?(?:\s+(.*))?$", text)
    if md_match:
        month = int(md_match.group(1))
        day = int(md_match.group(2))
        year_part = md_match.group(3)
        clock = md_match.group(4) or ""
        if year_part:
            year = int(year_part)
            if year < 100:
                year += 2000
        else:
            year = now.year
        parsed_clock = _parse_clock(clock)
        try:
            result = datetime(year, month, day, parsed_clock.hour, parsed_clock.minute)
        except ValueError:
            return None
        if not year_part and result > now + timedelta(days=1):
            try:
                result = result.replace(year=result.year - 1)
            except ValueError:
                pass
        return result

    return None


def _is_attachment_url(url):
    if not url:
        return False
    lower = url.lower()

    if "forumattach.js" in lower:
        return False
    if "paperclip.png" in lower:
        return False
    if "/js/" in lower or lower.endswith(".js"):
        return False
    if "uphoto.jupitered.com" in lower or "logo.jupitered.com" in lower:
        return False

    exts = (
        ".pdf",
        ".doc",
        ".docx",
        ".xls",
        ".xlsx",
        ".ppt",
        ".pptx",
        ".zip",
        ".rar",
        ".txt",
        ".csv",
        ".png",
        ".jpg",
        ".jpeg",
    )
    words = ("attach", "attachment", "download", "adjunto", "archivo", "file=", "filename=", "openattach", "getfile")
    return any(ext in lower for ext in exts) or any(word in lower for word in words)


def _go_inbox_direct():
    try:
        ran = driver.execute_script(
            "if (typeof go === 'function') { go('inbox'); return true; } return false;"
        )
        if ran:
            time.sleep(0.8)
            return True
    except Exception:
        pass
    return False


def _open_messages_view():
    if len(driver.find_elements(By.CSS_SELECTOR, "div.post.accordion")) >= 2:
        return True

    try:
        driver.execute_script(
            """
            if (typeof clicknavsidebar === 'function') { try { clicknavsidebar(); } catch (e) {} }
            """
        )
    except Exception:
        pass
    time.sleep(0.4)

    # From your debug: rows are class "navrow", one is exactly "Messages".
    rows = driver.find_elements(By.CSS_SELECTOR, ".navrow, [class*='navrow']")
    for row in rows:
        try:
            if row.text.strip().lower() in {"messages", "mensajes"}:
                driver.execute_script("arguments[0].click();", row)
                time.sleep(0.8)
                return True
        except Exception:
            continue

    # Fallback generic label click.
    for el in driver.find_elements(By.XPATH, "//*[self::a or self::button or self::div or self::span]"):
        try:
            txt = el.text.strip().lower()
            if txt in {"messages", "mensajes"}:
                driver.execute_script("arguments[0].click();", el)
                time.sleep(0.8)
                return True
        except Exception:
            continue

    return len(driver.find_elements(By.CSS_SELECTOR, "div.post.accordion")) > 0


def _wait_for_inbox(min_cards=1, timeout=8):
    end = time.time() + timeout
    while time.time() < end:
        if len(driver.find_elements(By.CSS_SELECTOR, "div.post.accordion")) >= min_cards:
            return True
        _go_inbox_direct()
        _open_messages_view()
        time.sleep(0.2)
    return len(driver.find_elements(By.CSS_SELECTOR, "div.post.accordion")) >= min_cards


def _click_keep_open():
    try:
        clicked = driver.execute_script(
            """
            const btn = document.querySelector("div.btn[script*=\\"go('inbox')\\"]");
            if (btn) { try { btn.click(); return true; } catch (e) {} }
            if (typeof go === 'function') { try { go('inbox'); return true; } catch (e) {} }
            return false;
            """
        )
        if clicked:
            time.sleep(0.8)
            return True
    except Exception:
        pass
    return False


def _restore_inbox(min_cards=1):
    if _go_inbox_direct() and _wait_for_inbox(min_cards=min_cards, timeout=4):
        return True
    if _click_keep_open() and _wait_for_inbox(min_cards=min_cards, timeout=4):
        return True
    _open_messages_view()
    if _wait_for_inbox(min_cards=min_cards, timeout=4):
        return True

    # Hard fallback.
    driver.get(INBOX_URL)
    time.sleep(1.2)
    _open_messages_view()
    return _wait_for_inbox(min_cards=min_cards, timeout=4)


def _get_cards():
    return driver.find_elements(By.CSS_SELECTOR, "div.post.accordion")


def _find_card_by_id(card_id):
    if not card_id:
        return None
    for card in _get_cards():
        try:
            if card.get_attribute("id") == card_id:
                return card
        except Exception:
            continue
    return None


def _parse_inbox_preview(card):
    card_id = card.get_attribute("id") or ""

    date = ""
    sender = ""
    subject = ""
    sender_pfp = ""

    try:
        date = card.find_element(By.CSS_SELECTOR, ".date.small").text.strip()
    except Exception:
        pass

    try:
        sender = card.find_element(By.CSS_SELECTOR, ".previewtext b").text.strip()
    except Exception:
        pass

    try:
        img = card.find_element(By.CSS_SELECTOR, "img.photo")
        sender_pfp = _normalize_href(img.get_attribute("src") or "")
    except Exception:
        pass

    try:
        preview = card.find_element(By.CSS_SELECTOR, ".previewtext")
        lines = _clean_lines(preview.text)
        filtered = []
        for line in lines:
            lower = line.lower()
            if line == date or line == sender:
                continue
            if re.match(r"^\d+\s+attachments?$", lower):
                continue
            filtered.append(line)
        subject = filtered[0] if filtered else ""
    except Exception:
        pass

    return {
        "id": card_id,
        "time": date,
        "sender": sender or "Unknown",
        "subject": subject,
        "sender_pfp": sender_pfp,
    }


def _message_key(meta, index=None):
    card_id = (meta.get("id") or "").strip()
    if card_id:
        return card_id

    base = f"{meta.get('time', '')}|{meta.get('sender', '')}|{meta.get('subject', '')}"
    if index is None:
        return base
    return f"{base}|{index}"


def _open_message(card):
    try:
        clickspace = card.find_element(By.CSS_SELECTOR, "div.clickspace")
    except Exception:
        return False

    action = (clickspace.get_attribute("click") or "").strip()
    if action.startswith("clickblock("):
        try:
            driver.execute_script(f"{action};")
            return True
        except Exception:
            pass

    try:
        driver.execute_script("arguments[0].click();", clickspace)
        return True
    except Exception:
        return False


def _collect_target_link_attachments(scope=None):
    attachments = []
    seen = set()

    search_root = scope if scope is not None else driver
    anchors = search_root.find_elements(By.CSS_SELECTOR, "a[target='link'][href]")
    for a in anchors:
        href = _normalize_href(a.get_attribute("href") or "")
        if not href or not _is_attachment_url(href):
            continue
        if href in seen:
            continue
        seen.add(href)

        name = (a.text or "").strip()
        if not name:
            try:
                thumb = a.find_element(By.CSS_SELECTOR, "img.thumbnail, img")
                name = (thumb.get_attribute("alt") or "").strip()
            except Exception:
                pass
        if not name:
            name = urlparse(href).path.split("/")[-1] or "attachment"

        attachments.append({"name": name, "url": href})

    return attachments


def _extract_body_text(card, meta):
    lines = _clean_lines(card.text)
    if not lines:
        return ""

    junk = {
        meta.get("time", ""),
        meta.get("sender", ""),
        meta.get("subject", ""),
        "Keep Open",
        "Archive",
        "Reply",
        "Click Reply or erase your message.",
        "To Do",
        "Messages",
        "My Files",
        "Calendar",
        "Materials",
        "Attendance",
        "Behavior Log",
        "Settings",
        "Video Tour",
        "Logout",
    }
    body = []
    for line in lines:
        if line in junk:
            continue
        if re.match(r"^\d+\s+attachments?$", line.lower()):
            continue
        body.append(line)

    # Remove leading sender/subject leftovers if present.
    while body and body[0] in {meta.get("sender", ""), meta.get("subject", ""), meta.get("time", "")}:
        body.pop(0)

    return "\n".join(body).strip()


def _scrape_open_message(card, meta):
    subject = meta.get("subject", "")
    recipients = ""

    try:
        wraps = card.find_elements(By.CSS_SELECTOR, ".wrap")
        if wraps:
            wrap_lines = _clean_lines(wraps[0].text)
            if wrap_lines and not subject:
                subject = wrap_lines[0]
            if len(wrap_lines) > 1:
                recipients = wrap_lines[1]
    except Exception:
        pass

    attachments = _collect_target_link_attachments(scope=card)
    if not attachments:
        # Some attachments render outside the card wrapper.
        attachments = _collect_target_link_attachments(scope=None)

    body = _extract_body_text(card, meta)

    return {
        "subject": subject or meta.get("subject", ""),
        "recipients": recipients,
        "body": body,
        "attachments": attachments,
        "sender_pfp": meta.get("sender_pfp", ""),
    }


def _get_open_message_container(card_id=""):
    # Preferred opened-message layout from your debug dump.
    blocks = driver.find_elements(By.CSS_SELECTOR, "div.block.whitebox")
    for block in blocks:
        try:
            if block.is_displayed() and block.text.strip():
                return block
        except Exception:
            continue

    # Fallback: opened/expanded accordion card by id.
    if card_id:
        card = _find_card_by_id(card_id)
        if card is not None:
            return card

    return None


def login():
    _ensure_credentials()
    driver.get("https://login.jupitered.com/login/")

    name_field = wait.until(
        EC.element_to_be_clickable((By.XPATH, "/html/body/form/div[5]/div/div/div[3]/div[2]/div/div[2]"))
    )
    name_field.click()
    name_field.send_keys(data["name"])

    pass_field = wait.until(
        EC.element_to_be_clickable((By.XPATH, "/html/body/form/div[5]/div/div/div[3]/div[3]/div[2]/input"))
    )
    pass_field.click()
    pass_field.send_keys(data["password"])

    school_field = wait.until(
        EC.element_to_be_clickable((By.XPATH, "/html/body/form/div[5]/div/div/div[3]/div[8]/div[1]/div[2]"))
    )
    school_field.click()
    school_field.send_keys(data["school"])

    city_field = wait.until(
        EC.element_to_be_clickable((By.XPATH, "/html/body/form/div[5]/div/div/div[3]/div[8]/div[2]/div[1]/div[2]"))
    )
    city_field.click()
    city_field.send_keys(data["city"])

    driver.execute_script(
        "document.getElementsByName('region1')[0].value = arguments[0];",
        data["state"],
    )

    login_btn = wait.until(
        EC.element_to_be_clickable((By.XPATH, "/html/body/form/div[5]/div/div/div[4]/div[3]/div"))
    )
    login_btn.click()

    wait.until(lambda d: "page=" in d.current_url or "navlit" in d.page_source)
    _restore_inbox(min_cards=1)
    print("Logged in")


def _build_cli_parser():
    parser = argparse.ArgumentParser(
        description="JupiterEd message scraper CLI"
    )
    head_mode = parser.add_mutually_exclusive_group()
    head_mode.add_argument(
        "--headless",
        dest="headless",
        action="store_true",
        help="Run Chrome in headless mode (default).",
    )
    head_mode.add_argument(
        "--headed",
        dest="headless",
        action="store_false",
        help="Run Chrome with a visible browser window.",
    )
    parser.set_defaults(headless=True)
    parser.add_argument(
        "--config",
        default="config.json",
        help="Path to credentials config JSON (default: config.json).",
    )
    parser.add_argument(
        "--json-out",
        dest="json_out",
        help="Optional path to save results as JSON.",
    )

    subparsers = parser.add_subparsers(dest="command")

    p_newest = subparsers.add_parser("newest", help="Fetch newest N messages.")
    p_newest.add_argument("count", type=int, help="Number of newest messages to fetch.")

    p_since = subparsers.add_parser("since", help="Fetch messages from last N days.")
    p_since.add_argument("days", type=int, help="Days back from now (inclusive).")
    p_since.add_argument("--limit", type=int, default=None, help="Optional max messages to fetch.")

    p_range = subparsers.add_parser("range", help="Fetch messages in date range (inclusive).")
    p_range.add_argument("--from", dest="from_date", required=True, help="Start date YYYY-MM-DD.")
    p_range.add_argument("--to", dest="to_date", default=None, help="End date YYYY-MM-DD (default: today).")
    p_range.add_argument("--limit", type=int, default=None, help="Optional max messages to fetch.")

    p_all = subparsers.add_parser("all", help="Fetch all available messages.")
    p_all.add_argument("--limit", type=int, default=None, help="Optional max messages to fetch.")

    p_check_new = subparsers.add_parser(
        "check-new",
        help="Check inbox previews and report messages that are new since last check.",
    )
    p_check_new.add_argument(
        "--state-file",
        default="message_state.json",
        help="Path to JSON file that stores seen message IDs.",
    )
    p_check_new.add_argument(
        "--no-update",
        action="store_true",
        help="Do not update the state file after checking.",
    )
    p_check_new.add_argument(
        "--fetch",
        action="store_true",
        help="Open and scrape full content for only the newly detected messages.",
    )

    return parser


def _build_filter(args):
    now = datetime.now()

    # Default command when omitted.
    if not args.command:
        return (lambda _dt: True), None

    if args.command == "newest":
        if args.count <= 0:
            raise ValueError("count must be > 0")
        return (lambda _dt: True), args.count

    if args.command == "since":
        if args.days < 0:
            raise ValueError("days must be >= 0")
        threshold = now - timedelta(days=args.days)
        return (lambda dt: dt is not None and dt >= threshold), args.limit

    if args.command == "range":
        start = datetime.strptime(args.from_date, "%Y-%m-%d").date()
        end = datetime.strptime(args.to_date, "%Y-%m-%d").date() if args.to_date else now.date()
        if start > end:
            raise ValueError("--from must be <= --to")
        return (lambda dt: dt is not None and start <= dt.date() <= end), args.limit

    # all
    return (lambda _dt: True), getattr(args, "limit", None)


def _load_seen_keys(state_file):
    if not state_file or not os.path.exists(state_file):
        return set()

    try:
        with open(state_file, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return set()

    if isinstance(data, dict):
        values = data.get("seen_keys", [])
    elif isinstance(data, list):
        values = data
    else:
        values = []

    return {str(v) for v in values if str(v).strip()}


def _save_seen_keys(state_file, keys):
    payload = {
        "updated_at": datetime.now().isoformat(),
        "seen_keys": sorted(keys),
    }
    with open(state_file, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)


def _read_inbox_previews():
    _restore_inbox(min_cards=1)
    cards = _get_cards()
    previews = []

    for i, card in enumerate(cards):
        meta = _parse_inbox_preview(card)
        key = _message_key(meta)
        parsed_dt = _parse_message_datetime(meta.get("time", ""))
        previews.append(
            {
                "id": meta.get("id", ""),
                "key": key,
                "time": meta.get("time", ""),
                "parsed_time": parsed_dt.isoformat() if parsed_dt else None,
                "sender": meta.get("sender", "Unknown"),
                "subject": meta.get("subject", ""),
                "sender_pfp": meta.get("sender_pfp", ""),
                "index": i,
            }
        )

    return previews


def check_new_messages(state_file="message_state.json", update_state=True):
    login()

    previews = _read_inbox_previews()
    if not previews:
        print("Inbox not found; cannot check for new messages.")
        return [], 0, 0

    seen_before = _load_seen_keys(state_file)
    current_keys = {preview["key"] for preview in previews}

    new_messages = [msg for msg in previews if msg["key"] not in seen_before]

    if update_state:
        merged = seen_before | current_keys
        _save_seen_keys(state_file, merged)

    return new_messages, len(previews), len(seen_before)


def _find_card_for_preview(preview):
    card_id = (preview.get("id") or "").strip()
    if card_id:
        by_id = _find_card_by_id(card_id)
        if by_id is not None:
            return by_id

    cards = _get_cards()
    idx = preview.get("index")
    target_key = preview.get("key", "")

    if isinstance(idx, int) and 0 <= idx < len(cards):
        candidate = cards[idx]
        if _message_key(_parse_inbox_preview(candidate)) == target_key:
            return candidate

    for card in cards:
        if _message_key(_parse_inbox_preview(card)) == target_key:
            return card

    return None


def fetch_selected_messages(previews):
    messages = []
    total = len(previews)
    if total == 0:
        return messages

    for i, preview in enumerate(previews, start=1):
        _restore_inbox(min_cards=1)
        card = _find_card_for_preview(preview)
        if card is None:
            print(f"Opening {i}/{total}: {preview.get('subject', '')}")
            print("  Skipping, message card not found in inbox")
            continue

        print(f"Opening {i}/{total}: {preview.get('subject', '')}")
        if not _open_message(card):
            print("  Skipping, could not open message")
            continue

        time.sleep(1)
        container = _get_open_message_container(preview.get("id", ""))
        if container is None:
            time.sleep(0.8)
            container = _get_open_message_container(preview.get("id", ""))
        if container is None:
            print("  Skipping, could not locate opened message container")
            _restore_inbox(min_cards=1)
            continue

        details = _scrape_open_message(container, preview)
        print(f"  Body chars: {len(details['body'])}")
        print(f"  Attachments: {len(details['attachments'])}")

        messages.append(
            {
                "time": preview.get("time", ""),
                "parsed_time": preview.get("parsed_time"),
                "sender": preview.get("sender", "Unknown"),
                "sender_pfp": details.get("sender_pfp", preview.get("sender_pfp", "")),
                "subject": details.get("subject", "") or preview.get("subject", ""),
                "recipients": details.get("recipients", ""),
                "body": details.get("body", ""),
                "attachments": details.get("attachments", []),
                "url": driver.current_url,
            }
        )

        _restore_inbox(min_cards=1)

    return messages


def fetch_messages(limit=None, predicate=None):
    login()

    all_messages = []
    visited = set()
    initial_inbox_count = None
    predicate = predicate or (lambda _dt: True)

    while True:
        _restore_inbox(min_cards=1)
        cards = _get_cards()
        if not cards:
            print("Inbox not found; stopping scrape.")
            break

        if initial_inbox_count is None:
            initial_inbox_count = len(cards)

        next_index = None
        next_meta = None
        next_dt = None

        for i, card in enumerate(cards):
            meta = _parse_inbox_preview(card)
            key = _message_key(meta, index=i)
            if key in visited:
                continue

            parsed_dt = _parse_message_datetime(meta.get("time", ""))
            if not predicate(parsed_dt):
                visited.add(key)
                continue

            next_index = i
            next_meta = meta
            next_dt = parsed_dt
            break

        if next_index is None:
            print("All messages scraped")
            break

        key = _message_key(next_meta, index=next_index)
        print(f"Opening {len(all_messages)+1}/{initial_inbox_count or len(cards)}: {next_meta['subject']}")

        open_card = _find_card_by_id(next_meta["id"]) if next_meta["id"] else None
        if open_card is None:
            cards = _get_cards()
            if next_index < len(cards):
                open_card = cards[next_index]
            else:
                visited.add(key)
                continue

        if not _open_message(open_card):
            print("  Skipping, could not open message")
            visited.add(key)
            continue

        time.sleep(1)
        container = _get_open_message_container(next_meta["id"])
        if container is None:
            # One brief retry in case UI is still transitioning.
            time.sleep(0.8)
            container = _get_open_message_container(next_meta["id"])

        if container is None:
            print("  Skipping, could not locate opened message container")
            _restore_inbox(min_cards=1)
            visited.add(key)
            continue

        details = _scrape_open_message(container, next_meta)
        print(f"  Body chars: {len(details['body'])}")
        print(f"  Attachments: {len(details['attachments'])}")

        all_messages.append(
            {
                "time": next_meta["time"],
                "parsed_time": next_dt.isoformat() if next_dt else None,
                "sender": next_meta["sender"],
                "sender_pfp": details.get("sender_pfp", ""),
                "subject": details["subject"] or next_meta["subject"],
                "recipients": details["recipients"],
                "body": details["body"],
                "attachments": details["attachments"],
                "url": driver.current_url,
            }
        )

        visited.add(key)
        _restore_inbox(min_cards=1)

        if limit is not None and len(all_messages) >= limit:
            break

    return all_messages


def _print_messages(messages):
    print(f"\nScraped {len(messages)} message(s):\n")
    for msg in messages:
        print(f"Time: {msg['time']}")
        print(f"Sender: {msg['sender']}")
        print(f"Subject: {msg['subject']}")
        print(f"Recipients: {msg['recipients']}")
        print(f"Body: {msg['body']}")
        if msg["attachments"]:
            print("Attachments:")
            for att in msg["attachments"]:
                print(f"   - {att['name']}: {att['url']}")
        print("---")


def _print_check_new_result(new_messages, inbox_count, known_before, state_file, updated_state):
    print(f"\nChecked {inbox_count} inbox message(s).")
    print(f"Previously known: {known_before}")
    print(f"New messages: {len(new_messages)}")

    if new_messages:
        print("")
        for msg in new_messages:
            print(f"Time: {msg['time']}")
            print(f"Sender: {msg['sender']}")
            print(f"Subject: {msg['subject']}")
            print("---")

    if updated_state:
        print(f"State updated: {state_file}")
    else:
        print("State not updated (--no-update).")


def main():
    parser = _build_cli_parser()
    args = parser.parse_args()

    try:
        load_config(args.config)
    except (OSError, json.JSONDecodeError, ValueError, TypeError) as exc:
        parser.error(str(exc))
        return

    _init_browser(headless=args.headless)

    try:
        if args.command == "check-new":
            new_messages, inbox_count, known_before = check_new_messages(
                state_file=args.state_file,
                update_state=not args.no_update,
            )
            _print_check_new_result(
                new_messages,
                inbox_count,
                known_before,
                args.state_file,
                updated_state=not args.no_update,
            )

            output_payload = new_messages
            if args.fetch:
                if new_messages:
                    print("\nFetching full content for new messages...")
                    output_payload = fetch_selected_messages(new_messages)
                    _print_messages(output_payload)
                else:
                    print("No new messages to fetch.")

            if args.json_out:
                with open(args.json_out, "w", encoding="utf-8") as f:
                    json.dump(output_payload, f, ensure_ascii=False, indent=2)
                print(f"Saved JSON: {args.json_out}")
            return

        try:
            predicate, limit = _build_filter(args)
        except ValueError as exc:
            parser.error(str(exc))
            return

        messages = fetch_messages(limit=limit, predicate=predicate)
        _print_messages(messages)

        if args.json_out:
            with open(args.json_out, "w", encoding="utf-8") as f:
                json.dump(messages, f, ensure_ascii=False, indent=2)
            print(f"Saved JSON: {args.json_out}")
    finally:
        try:
            driver.quit()
        except Exception:
            pass


if __name__ == "__main__":
    main()
