"""
Tests for the optimisation of global image positions from correlation data.
"""

import os
import pytest
import numpy as np

from openflexure_stitching.loading import CorrelatedImageSet
from openflexure_stitching.optimisation import (
    pair_displacements,
    fully_connected,
    rms_error_position_discrepancy,
    fit_positions_lstsq,
    trial_fit_with_thresholds,
    optimise_peak_and_discrepancy_thresholds,
    resample_and_sort_list,
    fit_with_all_thresholds_until_turnaround,
)
from openflexure_stitching.settings import TilingSettings

THIS_DIR = os.path.dirname(os.path.realpath(__file__))


@pytest.fixture
def mock_image_set():
    """Create a minimal correlated image set for testing optimisation functions."""
    # This set will have 4 images and 6 overlapping pairs
    test_fpath = os.path.join(THIS_DIR, "images", "cropped")
    return CorrelatedImageSet(test_fpath)


def test_pair_displacements(mock_image_set):
    """Check pair_displacements returns correct shape and type."""
    pairs = mock_image_set.pairs
    positions = {k: np.array([0.0, 0.0]) for k in mock_image_set.keys()}
    # pair_displacements returns an array of x and y offset for
    # every pair in pairs
    disp = pair_displacements(pairs, positions)
    assert isinstance(disp, np.ndarray)
    # ensure all pairs have been included
    assert disp.shape[0] == len(pairs)
    # ensure two values, corresponding to x and y offsets
    assert disp.shape[1] == 2


def test_fully_connected(mock_image_set):
    """Check fully_connected detects connectivity correctly."""
    pairs = mock_image_set.pairs
    assert fully_connected(pairs, pairs) is True
    # Check that only accepting 2 pairs cannot connect all 4 images
    assert fully_connected(pairs[:2], pairs) is False


def test_rms_error_position_discrepancy(mock_image_set):
    """Check RMS error function does not return NaN and is non-negative."""
    pairs = mock_image_set.pairs
    positions = fit_positions_lstsq(mock_image_set, pairs)
    rms = rms_error_position_discrepancy(pairs, positions, pairs)
    assert isinstance(rms, float)
    assert rms >= 0


def test_fit_positions_lstsq_shape(mock_image_set):
    """Check that fitted positions cover all keys and are 2D vectors."""
    pairs = mock_image_set.pairs
    positions = fit_positions_lstsq(mock_image_set, pairs)
    for key, pos in positions.items():
        assert key in mock_image_set.keys()
        assert isinstance(pos, np.ndarray)
        assert pos.shape == (2,)


def test_trial_fit_with_thresholds_returns(mock_image_set):
    """Check the trial_fit returns a tuple of RMS error and number of pairs."""
    peak_thresh, stage_thresh = 0.5, 0.5
    rms, n_pairs = trial_fit_with_thresholds(mock_image_set, peak_thresh, stage_thresh, cache=None)
    assert isinstance(rms, float)
    assert isinstance(n_pairs, int)


def test_resample_and_sort_list_behaviour():
    """Check that resampling reduces list length for long lists and preserves order."""
    data = list(range(100))
    out = resample_and_sort_list(data)
    # Ensure resample_and_sort_list returns a list of increasing values
    assert all(out[i] <= out[i + 1] for i in range(len(out) - 1))
    # Default resampling should return 34 values from a list of 100
    assert len(out) == 34


def test_optimise_peak_and_discrepancy_thresholds(mock_image_set):
    """Check optimisation returns sensible thresholds within expected ranges."""

    # This tests for the exact values known from our mock image set
    peak, stage = optimise_peak_and_discrepancy_thresholds(mock_image_set)
    assert peak == 0.9999938001064127
    assert stage == 8.038873388460929e-14


def test_fit_with_all_thresholds_until_turnaround_runs(mock_image_set):
    """Check that fitting over thresholds returns iterable outputs."""
    peak_list = [0.1, 0.5, 0.9]
    stage_list = [0.1, 0.5, 1.0]
    result = fit_with_all_thresholds_until_turnaround(mock_image_set, peak_list, stage_list)
    peak_threshs, stage_threshs, rms_errors, n_pairs = result
    assert len(peak_threshs) == len(stage_threshs) == len(rms_errors) == len(n_pairs)


def test_user_thresholds_filter_all_pairs_raises(mock_image_set):
    """Ensure a ValueError is raised if the manually specified thresholds filter out all image pairs."""

    # Set thresholds outside the possible range
    tiling_settings = TilingSettings(
        min_peak_quality=2,  # max possible is 1
        max_stage_discrepancy=-1.0,  # min possible is 0
    )

    with pytest.raises(ValueError, match="User-specified thresholds filter out all image pairs"):
        optimise_peak_and_discrepancy_thresholds(mock_image_set, tiling_settings=tiling_settings)


def test_user_thresholds_filter_no_pairs_accepted(mock_image_set):
    """Ensure that very lenient user thresholds produce the same results as no thresholds."""

    # Lenient thresholds
    tiling_settings = TilingSettings(
        min_peak_quality=0.1,  # very low, accepts all peak qualities
        max_stage_discrepancy=1000,  # very high, accepts all discrepancies
    )

    # Optimise with lenient thresholds
    peak_thresh_user, stage_thresh_user = optimise_peak_and_discrepancy_thresholds(
        mock_image_set, tiling_settings=tiling_settings
    )

    # Optimise with thresholds explicitly None
    none_tiling_settings = TilingSettings(
        min_peak_quality=None,
        max_stage_discrepancy=None,
    )
    peak_thresh_none, stage_thresh_none = optimise_peak_and_discrepancy_thresholds(
        mock_image_set, tiling_settings=none_tiling_settings
    )

    # Optimise with default TilingSettings
    default_tiling_settings = TilingSettings()
    peak_thresh_default, stage_thresh_default = optimise_peak_and_discrepancy_thresholds(
        mock_image_set, tiling_settings=default_tiling_settings
    )

    # Assert that results are identical
    assert peak_thresh_user == peak_thresh_default == peak_thresh_none, (
        f"Peak quality thresholds differ: user {peak_thresh_user}, None {peak_thresh_none}, default {peak_thresh_default}"
    )
    assert stage_thresh_user == stage_thresh_default == stage_thresh_none, (
        f"Stage discrepancy thresholds differ: user {stage_thresh_user}, None {stage_thresh_none} default {stage_thresh_default}"
    )


def test_user_thresholds_filter_applied(mock_image_set):
    """Ensure that sensible user thresholds produce different results as no thresholds."""

    # Lenient thresholds
    tiling_settings = TilingSettings(
        min_peak_quality=0.999985,  # from examining thresholds manually
        max_stage_discrepancy=8.0388733884e-14,
    )

    # Optimise with lenient thresholds
    peak_thresh_user, stage_thresh_user = optimise_peak_and_discrepancy_thresholds(
        mock_image_set, tiling_settings=tiling_settings
    )

    # Optimise with thresholds explicitly None
    none_tiling_settings = TilingSettings(
        min_peak_quality=None,
        max_stage_discrepancy=None,
    )
    peak_thresh_none, stage_thresh_none = optimise_peak_and_discrepancy_thresholds(
        mock_image_set, tiling_settings=none_tiling_settings
    )

    # Assert that results differ
    assert peak_thresh_user != peak_thresh_none, (
        f"Peak quality thresholds are the same: user {peak_thresh_user}, None {peak_thresh_none}"
    )
    assert stage_thresh_user != stage_thresh_none, (
        f"Stage discrepancy thresholds are the same: user {stage_thresh_user}, None {stage_thresh_none}"
    )
