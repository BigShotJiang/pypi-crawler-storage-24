"""Handles external communication, printing to terminal."""


def notify(message):
    """Send an unbuffered message by printing with Flush=True."""

    # Allow printing on this line, as this is the current logging approach
    print(message, flush=True)  # noqa: T201
