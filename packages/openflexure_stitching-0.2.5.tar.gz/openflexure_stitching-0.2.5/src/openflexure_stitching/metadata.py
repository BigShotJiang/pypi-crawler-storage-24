"""
Module for handling exif metadata for JPEGs.

Currently mainly looking for OpenFlexure metadata, with some generic
or estimated.
"""

import json
from typing import Optional, Any
import time
import re

from PIL import Image
import numpy as np
import piexif

from openflexure_stitching.communicate import notify


class MetaDataError(RuntimeError):
    """The exception if Contradictory metadata found"""


def get_img_size(filepath: str, exif: Optional[dict] = None) -> tuple[int, int]:
    """Return the height and width of the image

    :param filepath: The filepath of the image
    :param exif: The image exif data as a dictionary if available

    :return: Tuple of (width, height)
    """

    if exif is not None:
        try:
            width = exif["Exif"][piexif.ExifIFD.PixelXDimension]
            height = exif["Exif"][piexif.ExifIFD.PixelYDimension]
            return width, height
        except KeyError:
            # If there is no exif data for the dimension a key error is
            # raised. Treat this the same as no exif data
            pass

    # Load from the file directly. PIL is significantly faster than cv2
    img = Image.open(filepath)
    width = img.size[0]
    height = img.size[1]
    return width, height


def get_capture_time(exif: Optional[dict]) -> Optional[float]:
    """
    Return the time the image was captured if recorded in the exif data.

    :param exif: The image exif data as a dictionary if available

    :return: The time as a C time float, or `None` if not known
    """
    encoded_time = nested_get(exif, ["0th", piexif.ImageIFD.DateTime])

    if encoded_time is None:
        return None

    decoded_time = encoded_time.decode()
    if isinstance(decoded_time, str):
        try:
            time_struct = time.strptime(decoded_time, "%Y:%m:%d %H:%M:%S")
            return time.mktime(time_struct)
        except ValueError:
            # EXIF always expects %Y:%m:%d %H:%M:%S, a value error is thrown otherwise
            notify(f"Could not read timestamp {decoded_time}")
    notify(f"Could not read timestamp of type {type(decoded_time)}")
    return None


def get_stage_position(
    imagename: str, usercomment: Optional[dict] = None
) -> Optional[tuple[int, int]]:
    """
    Return stage position from the image name or the usercomment in the EXIF data
    or None if neither are set

    :param imagename: The filename of the image with the extension removed
    :param usercomment: The usercomment JSON loaded as a dict from EXIF if available.

    :return: Tuple of (x-position, y-position)

    :raises: MetaDataError if both are set but have different values.
    """
    position_from_exif = nested_get(usercomment, ["stage", "position"])
    if position_from_exif is None:
        # If not found retry with legacy path syntax
        position_from_exif = nested_get(usercomment, ["/stage/", "position"])

    if position_from_exif is not None:
        # if key is found pull out "x", "y"
        try:
            position_from_exif = tuple(int(position_from_exif[dim]) for dim in ("x", "y"))
        except (KeyError, TypeError):
            notify("Stage position found in exif data, but it couldn't be read.")
            # Set to none and try file name
            position_from_exif = None

    position_from_filename = _read_stage_position_from_imagename(imagename)

    if position_from_exif is None:
        # This will return None if neither are set
        return position_from_filename
    if position_from_filename is None:
        return position_from_exif

    if position_from_filename != position_from_exif:
        raise MetaDataError("Position is set in both EXIF data and filename but do not match.")
    # Identical return either!
    return position_from_exif


def _read_stage_position_from_imagename(imagename: str) -> Optional[tuple[int, int]]:
    """Return the stage positions (x,y) from image name, or None if not found
    Expected coordinates in the file name with pattern `*x_y*` or `*x_y_z*`
    """

    matches = re.match(r"^.*?(-?\d+)_(-?\d+)(?:_(-?\d+))?$", imagename)
    if matches is None:
        return None
    # ignore z if found
    return (int(matches.group(1)), int(matches.group(2)))


def get_csm(usercomment: Optional[dict] = None) -> Optional[np.ndarray]:
    """Return the camera to sample matrix if stored in user comment.

    :param usercomment: The usercomment JSON loaded as a dict from EXIF if available.

    :return: numpy array of the camera to sample matrix or None if not set.
    """
    # These are they nested dictionary keys for where the CSM may be stored
    csm_nested_key_options = [
        ["camera_stage_mapping", "image_to_stage_displacement_matrix"],  # server v3
        ["/camera_stage_mapping/", "image_to_stage_displacement_matrix"],  # legacy v3
        [
            "instrument",
            "settings",
            "extensions",
            "org.openflexure.camera_stage_mapping",
            "image_to_stage_displacement",
        ],  # server v2
    ]

    for key_list in csm_nested_key_options:
        csm = nested_get(usercomment, key_list)
        if csm is not None:
            # If found return it, if not try more options
            return np.array(csm)
    # All options tried return None
    return None


def get_csm_width(usercomment: Optional[dict], from_openflexure: bool = False) -> Optional[int]:
    """Return the width the camera to sample matrix was calibrated at if stored in user comment.

    :param usercomment: The usercomment JSON loaded as a dict from EXIF if available.
    :param from_openflexure: Set True if the image is from an OpenFlexure Microscope
    This is needed for some old OpenFlexure Microscopes that used a csm_width of 832
    but didn't write it in the settings. (Default False)

    :return: the width of the calibration image in pixels or None if not set.
    """
    csm_width = nested_get(usercomment, ["camera_stage_mapping", "image_resolution", 1])
    if csm_width is None:
        # If not found retry with legacy path syntax
        csm_width = nested_get(usercomment, ["/camera_stage_mapping/", "image_resolution", 1])

    if csm_width is None:
        if from_openflexure:
            # Correct for old OpenFlexure Microscopes not setting csm width but
            # always using 832
            return 832
        return None
    # Coerce to int before returning if set.
    return int(csm_width)


def get_um_per_px(usercomment: Optional[dict]) -> Optional[float]:
    """Return the conversion from micrometers to pixels

    :param usercomment: The usercomment JSON loaded as a dict from EXIF if available.

    :return: the conversion factor or None if not set.
    """
    return nested_get(
        usercomment, ["instrument", "settings", "extensions", "usafcal", "um_per_px"]
    )


def get_exif_usercomment_json(exif: Optional[dict[str, Any]]) -> Optional[dict]:
    """Extract the OpenFlexure metadata from a usercomment dict if available

    :param exif: The image exif data as a dictionary if available

    :return: The usercomment JSON loaded as a dict from EXIF if available.
    """
    if exif is None or "Exif" not in exif:
        return None

    if piexif.ExifIFD.UserComment in exif["Exif"]:
        return json.loads(exif["Exif"][piexif.ExifIFD.UserComment].decode())

    return None


def nested_get(nested: Optional[dict | list], key_list: list[Any]) -> Any:
    """
    Return value from a nested dictionary or list or None if it is not found.

    :param nested: The nested dictionaries or lists. Can be None, None will
    always be returned
    :param key_list: The list of dictionary keys or list indexes

    :return: The value if exists or None if not found.
    """
    if nested is None:
        return None

    if not key_list:
        raise ValueError("key_list can't be empty")

    # Loop through keys updating the value
    value = nested
    for key in key_list:
        # Try to get next value from key in dict or index in list
        if isinstance(value, dict) and key in value:
            value = value[key]
        elif isinstance(value, list) and isinstance(key, int):
            try:
                value = value[key]
            except IndexError:
                # That index isn't in the list
                return None
        else:
            # Return None if it can't be found.
            return None
    # All keys found, return value
    return value


def build_exif_bytes(user_metadata: dict | None = None) -> bytes:
    """
    Build EXIF bytes for stitched images.

    User metadata is stored as JSON in the Exif UserComment field.
    """
    if user_metadata is None:
        user_metadata = {}

    exif_dict: dict = {"0th": {}, "Exif": {}, "GPS": {}, "1st": {}, "thumbnail": None}

    # Store JSON-encoded metadata in UserComment
    exif_dict["Exif"][piexif.ExifIFD.UserComment] = json.dumps(user_metadata).encode("utf-8")

    return piexif.dump(exif_dict)
