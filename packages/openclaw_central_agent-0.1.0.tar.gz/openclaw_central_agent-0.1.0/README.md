# OpenClaw Central Agent

Node agent for OpenClaw Central distributed monitoring platform.

## Install

```bash
pip install openclaw-central-agent
```

## Quick Start

```bash
ocagent register --server https://central.example.com --token <token> --name "my-server"
ocagent start -d
ocagent status
```

## Commands

| Command | Description |
|---------|-------------|
| `ocagent register` | Register node to Central Server |
| `ocagent start [-d]` | Start agent (foreground or daemon) |
| `ocagent stop` | Stop daemon |
| `ocagent restart` | Restart daemon |
| `ocagent status` | Show status |
| `ocagent doctor` | Environment check |
| `ocagent collect --once` | Debug: one-time data collection |
| `ocagent logs` | View agent logs |
