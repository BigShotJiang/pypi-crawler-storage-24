"""Shared test fixtures"""
import pytest
import json
import tempfile
from pathlib import Path


@pytest.fixture
def tmp_openclaw_home(tmp_path):
    """Create a minimal OpenClaw home directory for testing"""
    home = tmp_path / ".openclaw"
    home.mkdir()
    agents_dir = home / "agents" / "main" / "sessions"
    agents_dir.mkdir(parents=True)

    config = {
        "agents": {"defaults": {"model": "anthropic/claude-sonnet-4"}, "list": [{"id": "main"}]},
        "models": {"providers": {"anthropic": {"api": "anthropic-messages", "baseUrl": "https://api.anthropic.com", "models": [{"id": "claude-sonnet-4"}]}}},
        "gateway": {"port": 18789},
        "channels": {},
        "bindings": [],
    }
    (home / "openclaw.json").write_text(json.dumps(config))
    (agents_dir / "sessions.json").write_text("{}")
    return str(home)
