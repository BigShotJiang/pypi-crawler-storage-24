"""守护进程核心 — asyncio 事件循环"""
import asyncio
import signal
import logging
import os
from pathlib import Path
from datetime import datetime

from ocagent.connection import WSConnection
from ocagent.queue import OfflineQueue
from ocagent.collectors.config_collector import ConfigCollector
from ocagent.collectors.activity_collector import ActivityCollector
from ocagent.collectors.stats_collector import StatsCollector
from ocagent.collectors.session_collector import SessionCollector
from ocagent.collectors.health_collector import HealthCollector
from ocagent.executors.config_sync import ConfigSyncExecutor
from ocagent.executors.command_runner import CommandRunner
from ocagent.utils.paths import load_agent_config, find_openclaw_home

logger = logging.getLogger("ocagent")

CONFIG_DIR = Path.home() / ".openclaw" / ".central"
PID_PATH = CONFIG_DIR / "agent.pid"


def _setup_logging(config: dict):
    log_cfg = config.get("logging", {})
    level = getattr(logging, log_cfg.get("level", "INFO").upper(), logging.INFO)
    log_file = Path(log_cfg.get("file", str(CONFIG_DIR / "agent.log"))).expanduser()
    log_file.parent.mkdir(parents=True, exist_ok=True)

    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=int(log_cfg.get("max_size_mb", 50)) * 1024 * 1024,
        backupCount=int(log_cfg.get("max_files", 3)),
    )
    file_handler.setFormatter(formatter)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    root = logging.getLogger("ocagent")
    root.setLevel(level)
    root.addHandler(file_handler)
    root.addHandler(stream_handler)


import logging.handlers  # noqa: E402 (needed for RotatingFileHandler)


async def run_daemon():
    """主入口: 启动所有采集器和 WebSocket 连接"""
    config = load_agent_config()
    if not config:
        logger.error("无法加载配置文件，请先运行 ocagent register")
        return

    openclaw_home = find_openclaw_home(config.get("openclaw", {}).get("home"))
    if not openclaw_home:
        logger.error("找不到 OpenClaw 目录")
        return

    PID_PATH.parent.mkdir(parents=True, exist_ok=True)
    PID_PATH.write_text(str(os.getpid()))

    _setup_logging(config)

    node_id = config["node"]["id"]
    logger.info(f"OpenClaw Central Agent 启动 — Node: {node_id}")
    logger.info(f"OpenClaw Home: {openclaw_home}")

    # 离线队列
    queue = OfflineQueue(path=CONFIG_DIR / "offline-queue.jsonl")

    # WebSocket 连接
    ws = WSConnection(
        url=config["server"]["url"],
        auth_token=config["server"]["auth_token"],
        node_id=node_id,
        queue=queue,
    )

    # 远程执行器
    config_sync_opts = config.get("config_sync", {})
    config_sync = ConfigSyncExecutor(str(openclaw_home), config_sync_opts)
    cmd_runner = CommandRunner(str(openclaw_home))

    # Intervals config
    intervals = config.get("intervals", {})

    # Wrap config_push handler to re-report config after successful push
    config_collector = ConfigCollector(str(openclaw_home), interval=intervals.get("full_sync", 300))

    async def _handle_config_push(payload: dict) -> dict:
        result = await config_sync.handle_push(payload)
        if result.get("success"):
            # Re-report config immediately so snapshot is updated
            try:
                data = await config_collector.collect()
                if data:
                    await ws.send(data)
                    logger.info("Config re-reported after successful push")
            except Exception as e:
                logger.warning(f"Config re-report failed: {e}")
        return result

    ws.on_config_push = _handle_config_push
    ws.on_command = cmd_runner.handle_command
    ws.on_probe_request = cmd_runner.handle_probe

    # 采集器 (config_collector already created above for push re-report)
    collectors = [
        config_collector,
        ActivityCollector(str(openclaw_home), interval=intervals.get("activity_poll", 5)),
        StatsCollector(str(openclaw_home), interval=intervals.get("stats_flush", 60)),
        SessionCollector(str(openclaw_home), interval=intervals.get("session_sync", 300)),
        HealthCollector(str(openclaw_home), interval=intervals.get("heartbeat", 30),
                        probe_interval=intervals.get("model_probe", 600)),
    ]

    # 优雅退出
    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _signal_handler():
        logger.info("收到退出信号，正在关闭...")
        stop_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _signal_handler)
        except NotImplementedError:
            pass  # Windows

    # 启动协程
    tasks = [
        asyncio.create_task(ws.run_forever(stop_event), name="ws"),
        asyncio.create_task(_heartbeat_loop(ws, config, str(openclaw_home), stop_event), name="heartbeat"),
    ]
    for collector in collectors:
        tasks.append(asyncio.create_task(_collector_loop(collector, ws, stop_event), name=collector.name))

    await stop_event.wait()

    for task in tasks:
        task.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)

    await ws.close()
    PID_PATH.unlink(missing_ok=True)
    logger.info("Agent 已停止")


async def _heartbeat_loop(ws: WSConnection, config: dict, openclaw_home: str, stop: asyncio.Event):
    from ocagent.parsers.config_parser import compute_config_hash
    interval = config.get("intervals", {}).get("heartbeat", 30)
    start_time = datetime.now()

    while not stop.is_set():
        try:
            config_hash = compute_config_hash(openclaw_home)
            agent_count = _count_agents(openclaw_home)
            uptime = (datetime.now() - start_time).total_seconds()

            await ws.send({
                "type": "heartbeat",
                "payload": {
                    "uptime": int(uptime),
                    "agentCount": agent_count,
                    "configHash": config_hash,
                },
            })
        except Exception as e:
            logger.warning(f"心跳发送失败: {e}")

        try:
            await asyncio.wait_for(stop.wait(), timeout=interval)
            break
        except asyncio.TimeoutError:
            pass


async def _collector_loop(collector, ws: WSConnection, stop: asyncio.Event):
    # 启动时立即采集一次
    try:
        data = await collector.collect()
        if data:
            await ws.send(data)
    except Exception as e:
        logger.warning(f"{collector.name} 首次采集失败: {e}")

    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), timeout=collector.interval)
            break
        except asyncio.TimeoutError:
            pass

        try:
            data = await collector.collect()
            if data:
                await ws.send(data)
        except Exception as e:
            logger.warning(f"{collector.name} 采集失败: {e}")


def _count_agents(openclaw_home: str) -> int:
    agents_dir = Path(openclaw_home) / "agents"
    if not agents_dir.exists():
        return 0
    return sum(1 for d in agents_dir.iterdir() if d.is_dir() and not d.name.startswith("."))


async def collect_all_once() -> dict:
    """单次全量采集（供 CLI collect --once 使用）"""
    config = load_agent_config()
    openclaw_home = find_openclaw_home(config.get("openclaw", {}).get("home")) if config else None
    if not openclaw_home:
        return {"error": "OpenClaw home not found"}

    home = str(openclaw_home)
    results = {}

    collectors = {
        "config": ConfigCollector(home, interval=0),
        "activity": ActivityCollector(home, interval=0),
        "stats": StatsCollector(home, interval=0),
        "sessions": SessionCollector(home, interval=0),
        "health": HealthCollector(home, interval=0),
    }

    for name, collector in collectors.items():
        try:
            data = await collector.collect()
            results[name] = data
        except Exception as e:
            results[name] = {"error": str(e)}

    return results
