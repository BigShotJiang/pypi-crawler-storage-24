"""模型 API 探测 — 双路策略"""
import json
import time
import subprocess
from pathlib import Path
import httpx

TIMEOUT = 15.0
KIMI = {"kimi-coding", "moonshot"}


async def probe_all_models(openclaw_home: str, timeout: float = TIMEOUT) -> list[dict]:
    """探测所有已配置模型的可用性"""
    results = []
    try:
        data = json.loads((Path(openclaw_home) / "agents/main/agent/models.json").read_text())
        providers = data.get("providers", {})
        for pid, pcfg in providers.items():
            for mid in pcfg.get("models", []):
                model_id = mid if isinstance(mid, str) else mid.get("id", "")
                if model_id:
                    r = await probe_model(openclaw_home, pid, model_id, timeout)
                    results.append(r)
    except Exception as e:
        results.append({"ok": False, "error": str(e), "status": "error"})
    return results


async def probe_model(openclaw_home: str, provider_id: str, model_id: str, timeout: float = TIMEOUT) -> dict:
    direct = await _probe_direct(openclaw_home, provider_id, model_id, timeout)
    if direct is not None:
        return {**direct, "model": f"{provider_id}/{model_id}"}
    return await _probe_cli(provider_id, model_id, timeout)


async def _probe_direct(home: str, pid: str, mid: str, timeout: float):
    cfg = _load_provider(home, pid)
    if not cfg or not cfg.get("baseUrl") or not cfg.get("apiKey") or not cfg.get("api"):
        return None
    base = cfg["baseUrl"].rstrip("/")
    key = cfg["apiKey"]
    api = cfg["api"]
    temp = 1 if pid in KIMI else 0
    headers = {"Content-Type": "application/json", **cfg.get("headers", {}), **_auth_headers(cfg, key)}
    start = time.monotonic()
    try:
        async with httpx.AsyncClient(timeout=timeout) as c:
            if api == "anthropic-messages":
                headers.setdefault("anthropic-version", "2023-06-01")
                r = await c.post(f"{base}/v1/messages", json={"model": mid, "max_tokens": 8, "messages": [{"role": "user", "content": "Reply with OK."}], "temperature": temp}, headers=headers)
            elif api == "openai-completions":
                r = await c.post(f"{base}/chat/completions", json={"model": mid, "messages": [{"role": "user", "content": "Reply with OK."}], "max_tokens": 8, "temperature": temp}, headers=headers)
            else:
                return None
            ms = int((time.monotonic() - start) * 1000)
            if r.status_code == 200:
                return {"ok": True, "elapsed": ms, "status": "ok", "source": "direct"}
            return {"ok": False, "elapsed": ms, "status": _classify(r.status_code, r.text), "error": r.text[:200], "source": "direct"}
    except httpx.TimeoutException:
        return {"ok": False, "elapsed": int((time.monotonic() - start) * 1000), "status": "timeout", "source": "direct"}
    except Exception as e:
        return {"ok": False, "elapsed": int((time.monotonic() - start) * 1000), "status": "network", "error": str(e), "source": "direct"}


async def _probe_cli(pid: str, mid: str, timeout: float) -> dict:
    start = time.monotonic()
    try:
        r = subprocess.run(["openclaw", "models", "status", "--probe", "--json", "--probe-provider", pid],
                           capture_output=True, text=True, timeout=timeout + 5)
        ms = int((time.monotonic() - start) * 1000)
        return {"ok": "ok" in r.stdout.lower(), "elapsed": ms, "model": f"{pid}/{mid}", "status": "ok" if "ok" in r.stdout.lower() else "error", "source": "cli"}
    except Exception as e:
        return {"ok": False, "elapsed": int((time.monotonic() - start) * 1000), "model": f"{pid}/{mid}", "status": "error", "error": str(e), "source": "cli"}


def _load_provider(home: str, pid: str):
    """Load provider config, merging models.json with openclaw.json for real API keys."""
    cfg = None
    # 1. Try models.json first (has baseUrl, api type, etc.)
    try:
        data = json.loads((Path(home) / "agents/main/agent/models.json").read_text())
        cfg = data.get("providers", {}).get(pid)
    except Exception:
        pass

    # 2. Get real API key from openclaw.json (models.json may have placeholder)
    try:
        oc = json.loads((Path(home) / "openclaw.json").read_text())
        oc_prov = oc.get("models", {}).get("providers", {}).get(pid, {})
        if cfg is None:
            cfg = oc_prov
        elif oc_prov.get("apiKey"):
            # Override with real key from openclaw.json
            cfg = {**cfg, "apiKey": oc_prov["apiKey"]}
            # Also pick up authHeader from openclaw.json if models.json has wrong value
            if "authHeader" in oc_prov:
                cfg["authHeader"] = oc_prov["authHeader"]
            if not cfg.get("baseUrl") and oc_prov.get("baseUrl"):
                cfg["baseUrl"] = oc_prov["baseUrl"]
            if not cfg.get("api") and oc_prov.get("api"):
                cfg["api"] = oc_prov["api"]
    except Exception:
        pass

    return cfg


def _auth_headers(cfg: dict, key: str) -> dict:
    ah = cfg.get("authHeader")
    # authHeader can be a custom header name string, or True/None (ignored)
    if isinstance(ah, str) and ah.strip() and ah.strip().lower() not in ("true", "false"):
        return {ah.strip(): key}
    if cfg.get("api") == "anthropic-messages":
        return {"x-api-key": key, "Authorization": f"Bearer {key}"}
    return {"Authorization": f"Bearer {key}"}


def _classify(status: int, text: str) -> str:
    t = text.lower()
    if status in (401, 403) or "unauthorized" in t:
        return "auth"
    if status == 429 or "rate limit" in t:
        return "rate_limit"
    if "timeout" in t:
        return "timeout"
    return "error"
