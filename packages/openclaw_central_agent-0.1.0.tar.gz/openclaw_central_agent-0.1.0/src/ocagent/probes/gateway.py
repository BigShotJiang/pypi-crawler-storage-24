"""Gateway 健康探测 — 三级降级"""
import time
import subprocess
import httpx

DEGRADED_MS = 1500


async def probe_gateway(port: int, token: str, timeout: float = 5.0) -> dict:
    start = time.monotonic()
    # Level 1: /api/health
    try:
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        async with httpx.AsyncClient(timeout=timeout) as c:
            r = await c.get(f"http://localhost:{port}/api/health", headers=headers)
            ms = int((time.monotonic() - start) * 1000)
            if r.status_code == 200:
                return {"ok": True, "status": "degraded" if ms > DEGRADED_MS else "healthy", "responseMs": ms}
    except Exception:
        pass
    # Level 2: Web UI
    try:
        url = f"http://localhost:{port}/chat" + (f"?token={token}" if token else "")
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=False) as c:
            r = await c.get(url)
            ms = int((time.monotonic() - start) * 1000)
            if 200 <= r.status_code < 400:
                return {"ok": True, "status": "degraded", "responseMs": ms}
    except Exception:
        pass
    # Level 3: CLI
    try:
        args = ["openclaw", "gateway", "status", "--json", "--timeout", str(int(timeout * 1000))]
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout + 5)
        ms = int((time.monotonic() - start) * 1000)
        if '"ok": true' in result.stdout or '"ok":true' in result.stdout:
            return {"ok": True, "status": "healthy", "responseMs": ms}
    except Exception:
        pass
    return {"ok": False, "status": "down", "responseMs": int((time.monotonic() - start) * 1000)}
