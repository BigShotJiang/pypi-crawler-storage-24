"""JSONL 文件解析"""
import json
from pathlib import Path


def tail_jsonl_messages(filepath: Path, max_lines: int = 20) -> list:
    if not filepath.exists() or filepath.stat().st_size == 0:
        return []
    chunk_size = 8192
    lines = []
    with open(filepath, "rb") as f:
        pos = filepath.stat().st_size
        remainder = b""
        while pos > 0 and len(lines) < max_lines:
            read_size = min(chunk_size, pos)
            pos -= read_size
            f.seek(pos)
            chunk = f.read(read_size) + remainder
            parts = chunk.split(b"\n")
            remainder = parts[0]
            for part in reversed(parts[1:]):
                line = part.strip()
                if line:
                    try:
                        lines.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
                    if len(lines) >= max_lines:
                        break
        if remainder.strip() and len(lines) < max_lines:
            try:
                lines.append(json.loads(remainder))
            except json.JSONDecodeError:
                pass
    lines.reverse()
    return lines
