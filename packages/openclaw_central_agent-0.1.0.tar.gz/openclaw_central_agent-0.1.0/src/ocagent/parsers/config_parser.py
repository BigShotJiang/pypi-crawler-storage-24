"""openclaw.json 解析"""
import json
import hashlib
from pathlib import Path
from typing import Optional
from ocagent.utils.sanitizer import sanitize_config


def compute_config_hash(openclaw_home: str) -> str:
    p = Path(openclaw_home) / "openclaw.json"
    if p.exists():
        return hashlib.sha256(p.read_bytes()).hexdigest()
    return ""


def parse_openclaw_config(openclaw_home: str) -> Optional[dict]:
    p = Path(openclaw_home) / "openclaw.json"
    if not p.exists():
        return None
    try:
        config = json.loads(p.read_text())
    except Exception:
        return None

    # agents can be either:
    #   - an object: { defaults: {...}, list: [{id, model, ...}] }
    #   - an array:  [{id, model, name, ...}]
    agents_raw = config.get("agents", {})
    if isinstance(agents_raw, list):
        # Flat array format
        agent_list = agents_raw
        defaults = {}
    else:
        # Object format with defaults + list
        defaults = agents_raw.get("defaults", {})
        agent_list = agents_raw.get("list", [])

    model_raw = defaults.get("model", "unknown")
    default_model = model_raw if isinstance(model_raw, str) else (model_raw.get("primary") if isinstance(model_raw, dict) else "unknown")

    if not agent_list:
        agents_dir = Path(openclaw_home) / "agents"
        if agents_dir.exists():
            agent_list = [{"id": d.name} for d in sorted(agents_dir.iterdir()) if d.is_dir() and not d.name.startswith(".")]
        if not agent_list:
            agent_list = [{"id": "main"}]

    agents = []
    for a in agent_list:
        aid = a.get("id", "")
        name = read_identity_name_safe(aid, openclaw_home) or a.get("name") or aid
        emoji = a.get("identity", {}).get("emoji", "🤖")
        model = _normalize_model(a.get("model"), default_model)
        platforms = _resolve_platforms(aid, config)
        agents.append({"id": aid, "name": name, "emoji": emoji, "model": model, "platforms": platforms})

    providers = []
    for pid, prov in config.get("models", {}).get("providers", {}).items():
        models = [{"id": m.get("id"), "name": m.get("name", m.get("id")),
                    "contextWindow": m.get("contextWindow"), "maxTokens": m.get("maxTokens")}
                   for m in prov.get("models", [])]
        providers.append({"id": pid, "api": prov.get("api"), "accessMode": "api_key", "models": models})

    channels = {}
    for ch_name, ch_cfg in config.get("channels", {}).items():
        if isinstance(ch_cfg, dict):
            channels[ch_name] = {"enabled": ch_cfg.get("enabled", True)}

    gateway = config.get("gateway", {})
    result = {
        "agents": agents,
        "providers": providers,
        "defaults": {"model": default_model, "fallbacks": []},
        "gateway": {"port": gateway.get("port", 18789), "host": gateway.get("host", "")},
        "channels": channels,
    }
    return sanitize_config(result) if result else None


def read_identity_name_safe(agent_id: str, openclaw_home: str) -> Optional[str]:
    try:
        from ocagent.parsers.identity import read_identity_name
        return read_identity_name(agent_id, openclaw_home)
    except Exception:
        return None


def _normalize_model(value, fallback: str) -> str:
    if isinstance(value, str) and value.strip():
        return value.strip()
    if isinstance(value, dict):
        p = value.get("primary") or value.get("default")
        if isinstance(p, str) and p.strip():
            return p.strip()
    return fallback


def _resolve_platforms(agent_id: str, config: dict) -> list:
    platforms = []
    for b in config.get("bindings", []):
        if b.get("agentId") == agent_id:
            ch = b.get("match", {}).get("channel")
            if ch:
                platforms.append({"name": ch})
    return platforms
