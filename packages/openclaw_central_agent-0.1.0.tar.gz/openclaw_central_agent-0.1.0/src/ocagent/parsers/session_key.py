"""Session Key 类型识别"""
import re

PATTERNS = [
    (re.compile(r":feishu:direct:"), "feishu-dm"),
    (re.compile(r":feishu:group:"), "feishu-group"),
    (re.compile(r":discord:direct:"), "discord-dm"),
    (re.compile(r":discord:channel:"), "discord-channel"),
    (re.compile(r":telegram:direct:"), "telegram-dm"),
    (re.compile(r":telegram:group:"), "telegram-group"),
    (re.compile(r":whatsapp:direct:"), "whatsapp-dm"),
    (re.compile(r":whatsapp:group:"), "whatsapp-group"),
    (re.compile(r":cron:"), "cron"),
]


def parse_session_type(key: str) -> tuple:
    for pattern, session_type in PATTERNS:
        if pattern.search(key):
            parts = key.split(f":{session_type.split('-')[0]}:")
            target = parts[-1] if len(parts) > 1 else ""
            return session_type, target
    if key.endswith(":main"):
        return "main", ""
    return "unknown", ""
