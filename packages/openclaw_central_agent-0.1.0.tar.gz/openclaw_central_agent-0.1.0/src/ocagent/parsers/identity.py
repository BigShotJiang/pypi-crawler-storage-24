"""IDENTITY.md 名称提取"""
import re
from pathlib import Path
from typing import Optional


def read_identity_name(agent_id: str, openclaw_home: str) -> Optional[str]:
    candidates = [
        Path(openclaw_home) / f"agents/{agent_id}/agent/IDENTITY.md",
        Path(openclaw_home) / f"workspace-{agent_id}/IDENTITY.md",
    ]
    if agent_id == "main":
        candidates.append(Path(openclaw_home) / "workspace/IDENTITY.md")

    for p in candidates:
        if not p.exists():
            continue
        try:
            content = p.read_text()
            match = re.search(r"\*\*Name:\*\*\s*(.+)", content)
            if match:
                name = match.group(1).strip()
                if name and not name.startswith("_") and not name.startswith("("):
                    return name
        except Exception:
            continue
    return None
