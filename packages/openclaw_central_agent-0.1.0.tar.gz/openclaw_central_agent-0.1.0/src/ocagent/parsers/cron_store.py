"""Cron 任务状态解析"""
import json
from pathlib import Path


def load_cron_jobs(openclaw_home: str, agent_id: str) -> list:
    candidates = [
        Path(openclaw_home) / "cron" / "jobs.json",
        Path(openclaw_home) / f"agents/{agent_id}/cron-store.json",
    ]
    for store_path in candidates:
        if not store_path.exists():
            continue
        try:
            data = json.loads(store_path.read_text())
            jobs = data.get("jobs", []) if isinstance(data, dict) else data
            result = []
            for job in jobs:
                if not isinstance(job, dict):
                    continue
                owner = job.get("agentId", "main")
                if owner != agent_id:
                    continue
                state = job.get("state", {})
                result.append({
                    "jobId": job.get("id", ""),
                    "label": job.get("name", job.get("id", "")),
                    "isRunning": state.get("lastStatus") == "running",
                    "lastRunAt": state.get("lastRunAtMs", 0) / 1000 if state.get("lastRunAtMs") else 0,
                    "nextRunAt": state.get("nextRunAtMs", 0) / 1000 if state.get("nextRunAtMs") else None,
                    "lastStatus": state.get("lastStatus", "success"),
                    "consecutiveFailures": state.get("consecutiveErrors", 0),
                })
            return result
        except Exception:
            continue
    return []
