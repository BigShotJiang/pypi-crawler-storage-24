"""离线消息队列 — JSONL 文件持久化"""
import json
import logging
from pathlib import Path
from typing import List

logger = logging.getLogger("ocagent.queue")

MAX_QUEUE_SIZE = 5000
MAX_QUEUE_FILE_MB = 20


class OfflineQueue:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def push(self, message: dict):
        try:
            if self.path.exists() and self.path.stat().st_size > MAX_QUEUE_FILE_MB * 1024 * 1024:
                self._truncate_oldest()
            with open(self.path, "a") as f:
                f.write(json.dumps(message, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.error(f"写入离线队列失败: {e}")

    def drain(self) -> List[dict]:
        if not self.path.exists():
            return []
        try:
            lines = self.path.read_text().strip().split("\n")
            self.path.write_text("")
            messages = []
            for line in lines:
                if line.strip():
                    try:
                        messages.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
            return messages
        except Exception as e:
            logger.error(f"读取离线队列失败: {e}")
            return []

    @property
    def size(self) -> int:
        if not self.path.exists():
            return 0
        try:
            return sum(1 for _ in open(self.path))
        except Exception:
            return 0

    def _truncate_oldest(self):
        try:
            lines = self.path.read_text().strip().split("\n")
            half = len(lines) // 2
            self.path.write_text("\n".join(lines[half:]) + "\n")
        except Exception:
            self.path.write_text("")
