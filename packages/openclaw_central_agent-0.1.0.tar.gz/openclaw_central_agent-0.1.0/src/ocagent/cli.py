"""OpenClaw Central Agent CLI"""
import asyncio
import sys
import os
import signal
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console()

CONFIG_DIR = Path.home() / ".openclaw" / ".central"
CONFIG_PATH = CONFIG_DIR / "agent.toml"
PID_PATH = CONFIG_DIR / "agent.pid"


def load_toml(path: Path) -> dict:
    """Load TOML config (compatible with Python 3.9+)"""
    text = path.read_text(encoding="utf-8")
    try:
        import tomllib  # Python 3.11+
        return tomllib.loads(text)
    except ImportError:
        import tomli
        return tomli.loads(text)


@click.group()
@click.version_option(package_name="openclaw-central-agent")
def main():
    """OpenClaw Central Agent — 节点监控守护进程"""
    pass


@main.command()
@click.option("--server", required=True, help="Central Server URL (e.g. https://central.example.com)")
@click.option("--token", required=True, help="注册令牌")
@click.option("--name", required=True, help="节点名称")
@click.option("--tags", default="", help="标签 (逗号分隔)")
def register(server: str, token: str, name: str, tags: str):
    """注册节点到 Central Server"""
    from ocagent.connection import register_node

    tag_list = [t.strip() for t in tags.split(",") if t.strip()]
    result = asyncio.run(register_node(server.rstrip("/"), token, name, tag_list))

    if result.get("ok"):
        console.print("[bold green]✅ 注册成功！[/]")
        console.print(f"   Node ID:  {result['node_id']}")
        console.print(f"   配置文件: {result['config_path']}")
        console.print(f"\n运行 [bold]ocagent start[/] 启动 Agent")
    else:
        console.print(f"[bold red]❌ 注册失败: {result.get('error', 'Unknown error')}[/]")
        sys.exit(1)


@main.command()
@click.option("-d", "--daemon", is_flag=True, help="后台守护进程模式")
def start(daemon: bool):
    """启动 Agent"""
    if not CONFIG_PATH.exists():
        console.print("[red]配置文件不存在，请先运行 ocagent register[/]")
        sys.exit(1)

    if daemon and sys.platform != "win32":
        _daemonize()

    from ocagent.daemon import run_daemon
    asyncio.run(run_daemon())


@main.command()
def stop():
    """停止 Agent"""
    if not PID_PATH.exists():
        console.print("[yellow]Agent 未运行[/]")
        return

    pid = int(PID_PATH.read_text().strip())
    try:
        os.kill(pid, signal.SIGTERM)
        console.print(f"[green]已发送停止信号到 PID {pid}[/]")
    except ProcessLookupError:
        console.print("[yellow]进程已不存在，清理 PID 文件[/]")
        PID_PATH.unlink(missing_ok=True)


@main.command()
def restart():
    """重启 Agent"""
    from click.testing import CliRunner
    runner = CliRunner()
    runner.invoke(stop)
    import time
    time.sleep(1)
    runner.invoke(start)


@main.command()
def status():
    """查看 Agent 运行状态"""
    table = Table(title="OpenClaw Central Agent")
    table.add_column("项目", style="bold", width=16)
    table.add_column("状态")

    # 进程状态
    daemon_status = "stopped"
    pid = "-"
    if PID_PATH.exists():
        pid = PID_PATH.read_text().strip()
        try:
            os.kill(int(pid), 0)
            daemon_status = "running"
        except (OSError, ValueError):
            daemon_status = "stopped (stale pid)"

    color = "green" if daemon_status == "running" else "red"
    table.add_row("守护进程", f"[{color}]{daemon_status}[/]")
    table.add_row("PID", pid)

    # 配置信息
    if CONFIG_PATH.exists():
        try:
            config = load_toml(CONFIG_PATH)
            table.add_row("Node ID", config.get("node", {}).get("id", "-"))
            table.add_row("Server", config.get("server", {}).get("url", "-"))
        except Exception:
            table.add_row("配置", "[red]解析失败[/]")
    else:
        table.add_row("配置", "[red]未注册[/]")

    # OpenClaw
    from ocagent.utils.paths import find_openclaw_home
    home = find_openclaw_home()
    table.add_row("OpenClaw Home", str(home) if home else "[red]未找到[/]")

    # 离线队列
    queue_path = CONFIG_DIR / "offline-queue.jsonl"
    queue_size = 0
    if queue_path.exists():
        queue_size = sum(1 for _ in open(queue_path) if _.strip())
    table.add_row("离线队列", f"{queue_size} 条待发送")

    console.print(table)


@main.command()
def doctor():
    """环境诊断"""
    from ocagent.utils.paths import find_openclaw_home, find_openclaw_binary

    checks = []

    # 1. Python
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    checks.append(("Python ≥ 3.9", sys.version_info >= (3, 9), py_ver))

    # 2. OpenClaw Home
    home = find_openclaw_home()
    checks.append(("OpenClaw Home", home is not None, str(home) if home else "未找到"))

    # 3. openclaw.json
    config_exists = home and (Path(home) / "openclaw.json").exists()
    checks.append(("openclaw.json", config_exists, "存在" if config_exists else "不存在"))

    # 4. openclaw CLI
    binary = find_openclaw_binary()
    checks.append(("openclaw CLI", binary is not None, binary or "未安装"))

    # 5. Agent 配置
    checks.append(("Agent 配置", CONFIG_PATH.exists(), str(CONFIG_PATH) if CONFIG_PATH.exists() else "未注册"))

    # 6. Node ID
    node_id = "-"
    if CONFIG_PATH.exists():
        try:
            config = load_toml(CONFIG_PATH)
            node_id = config.get("node", {}).get("id", "-")
        except Exception:
            pass
    checks.append(("Node ID", node_id != "-", node_id))

    # 7. Central Server
    server_ok = False
    if CONFIG_PATH.exists():
        try:
            config = load_toml(CONFIG_PATH)
            server_ok = asyncio.run(_test_server(config))
        except Exception:
            pass
    checks.append(("Central Server", server_ok, "连通" if server_ok else "无法连接"))

    # 8. Gateway
    gateway_ok = False
    if home:
        try:
            from ocagent.probes.gateway import probe_gateway_sync
            result = probe_gateway_sync(home)
            gateway_ok = result.get("ok", False)
        except Exception:
            pass
    checks.append(("Gateway", gateway_ok, "healthy" if gateway_ok else "不可用"))

    # 9. 磁盘
    import psutil
    if home:
        disk = psutil.disk_usage(str(home))
        free_gb = round(disk.free / (1024 ** 3), 1)
        checks.append(("磁盘空间", free_gb >= 5, f"剩余 {free_gb} GB"))
    else:
        checks.append(("磁盘空间", False, "无法检测"))

    console.print("\n  [bold]OpenClaw Central Agent — 环境诊断[/]")
    console.print("  " + "─" * 40)
    passed = 0
    for name, ok, detail in checks:
        icon = "✅" if ok else "❌"
        if ok:
            passed += 1
        console.print(f"  {icon} {name:20s} {detail}")
    console.print("  " + "─" * 40)
    console.print(f"  总计: {passed}/{len(checks)} 通过\n")


@main.command("collect")
@click.option("--once", is_flag=True, help="执行一次全量采集并输出")
def collect_cmd(once: bool):
    """手动触发数据采集"""
    if once:
        from ocagent.daemon import collect_all_once
        import json
        data = asyncio.run(collect_all_once())
        console.print_json(json.dumps(data, ensure_ascii=False, default=str))


@main.command("install-service")
def install_service():
    """生成并安装 systemd service"""
    import shutil
    ocagent_path = shutil.which("ocagent") or "/usr/local/bin/ocagent"
    user = os.environ.get("USER", "root")
    home = Path.home()

    service = f"""[Unit]
Description=OpenClaw Central Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
ExecStart={ocagent_path} start
Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1
NoNewPrivileges=yes
ProtectSystem=strict
ReadWritePaths={home}/.openclaw

[Install]
WantedBy=multi-user.target
"""
    service_path = Path("/etc/systemd/system/ocagent.service")
    try:
        service_path.write_text(service)
        os.system("systemctl daemon-reload")
        console.print(f"[green]Service 已安装到 {service_path}[/]")
        console.print("运行 [bold]sudo systemctl enable --now ocagent[/] 启动")
    except PermissionError:
        console.print(f"[red]需要 root 权限。请运行: sudo ocagent install-service[/]")


async def _test_server(config: dict) -> bool:
    import httpx
    url = config.get("server", {}).get("url", "")
    http_url = url.replace("wss://", "https://").replace("ws://", "http://")
    if http_url.endswith("/ws"):
        http_url = http_url[:-3]
    http_url += "/api/health"
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(http_url)
            return resp.status_code < 500
    except Exception:
        return False


def _daemonize():
    """Unix double-fork daemonize"""
    if os.fork() > 0:
        sys.exit(0)
    os.setsid()
    if os.fork() > 0:
        sys.exit(0)
    sys.stdin = open(os.devnull, "r")
    sys.stdout = open(os.devnull, "w")
    sys.stderr = open(os.devnull, "w")


if __name__ == "__main__":
    main()
