"""配置脱敏"""
import copy
import re

SENSITIVE_PATTERNS = [
    r"models\.providers\.[^.]+\.apiKey",
    r"models\.providers\.[^.]+\.headers\.Authorization",
    r"channels\.[^.]+\.appSecret",
    r"channels\.[^.]+\.token",
    r"channels\.feishu\.accounts\.[^.]+\.appSecret",
    r"gateway\.auth\.token",
    r"auth\.profiles\.[^.]+\.clientSecret",
]
MASK = "***masked***"


def sanitize_config(config: dict) -> dict:
    sanitized = copy.deepcopy(config)
    _walk_and_mask(sanitized, "")
    return sanitized


def _walk_and_mask(obj, path: str):
    if isinstance(obj, dict):
        for key, value in obj.items():
            current = f"{path}.{key}" if path else key
            if _is_sensitive(current) and isinstance(value, str) and value:
                obj[key] = MASK
            elif isinstance(value, (dict, list)):
                _walk_and_mask(value, current)
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            if isinstance(item, (dict, list)):
                _walk_and_mask(item, f"{path}.{i}")


def _is_sensitive(path: str) -> bool:
    return any(re.fullmatch(p, path) for p in SENSITIVE_PATTERNS)
