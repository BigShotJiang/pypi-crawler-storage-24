"""文件变更监听"""
import asyncio
import logging
from pathlib import Path
from typing import Callable
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileModifiedEvent

logger = logging.getLogger("ocagent.watcher")


class ConfigFileHandler(FileSystemEventHandler):
    def __init__(self, callback: Callable, loop: asyncio.AbstractEventLoop):
        self.callback = callback
        self.loop = loop

    def on_modified(self, event):
        if isinstance(event, FileModifiedEvent) and event.src_path.endswith("openclaw.json"):
            logger.debug(f"Config file changed: {event.src_path}")
            self.loop.call_soon_threadsafe(asyncio.ensure_future, self.callback())


def start_file_watcher(openclaw_home: str, callback: Callable, loop: asyncio.AbstractEventLoop) -> Observer:
    observer = Observer()
    handler = ConfigFileHandler(callback, loop)
    observer.schedule(handler, openclaw_home, recursive=False)
    observer.daemon = True
    observer.start()
    return observer
