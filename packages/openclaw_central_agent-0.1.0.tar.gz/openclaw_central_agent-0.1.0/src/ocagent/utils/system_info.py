"""系统资源采集"""
import psutil
import platform
import socket
import time


def get_system_info(openclaw_home: str) -> dict:
    mem = psutil.virtual_memory()
    try:
        disk = psutil.disk_usage(openclaw_home)
        disk_info = {"total": round(disk.total / 1e9, 1), "used": round(disk.used / 1e9, 1), "free": round(disk.free / 1e9, 1)}
    except Exception:
        disk_info = {"total": 0, "used": 0, "free": 0}

    return {
        "platform": platform.system().lower(),
        "hostname": socket.gethostname(),
        "uptime": int(time.time() - psutil.boot_time()),
        "cpuUsage": psutil.cpu_percent(interval=0.5),
        "memoryUsage": {"total": round(mem.total / 1e6), "used": round(mem.used / 1e6), "free": round(mem.available / 1e6)},
        "diskUsage": disk_info,
    }
