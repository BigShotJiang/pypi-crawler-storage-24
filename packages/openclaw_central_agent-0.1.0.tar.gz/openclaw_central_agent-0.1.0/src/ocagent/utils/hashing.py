"""文件哈希"""
import hashlib
from pathlib import Path


def hash_file(path: str) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compute_config_hash(openclaw_home: str) -> str:
    config_path = Path(openclaw_home) / "openclaw.json"
    if config_path.exists():
        return hash_file(str(config_path))
    return ""
