"""OpenClaw 路径解析"""
import os
import sys
from pathlib import Path
from typing import Optional

try:
    import tomllib
except ImportError:
    import tomli as tomllib


def find_openclaw_home(override: Optional[str] = None) -> Optional[str]:
    if override:
        p = Path(override).expanduser()
        if p.exists():
            return str(p)
    env = os.environ.get("OPENCLAW_HOME")
    if env:
        p = Path(env)
        if p.exists():
            return str(p)
    default = Path.home() / ".openclaw"
    if default.exists():
        return str(default)
    return None


def find_openclaw_binary() -> Optional[str]:
    import shutil
    return shutil.which("openclaw")


def get_agent_config_path() -> Path:
    home = find_openclaw_home() or str(Path.home() / ".openclaw")
    return Path(home) / ".central" / "agent.toml"


def load_agent_config() -> Optional[dict]:
    path = get_agent_config_path()
    if not path.exists():
        return None
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except Exception:
        return None
