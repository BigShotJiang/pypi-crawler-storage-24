"""远程命令执行器"""
import subprocess
import logging
import json
import os
from pathlib import Path

logger = logging.getLogger("ocagent.command")

# 命令名 -> CLI 参数列表
# 基于 openclaw CLI 实际支持的子命令:
#   openclaw gateway restart/start/stop/status
#   openclaw config get/set/validate/file
#   openclaw channels list
ALLOWED_COMMANDS = {
    "restart_gateway": ["openclaw", "gateway", "restart"],
    "reload_config": ["openclaw", "gateway", "restart"],  # config reload = gateway restart
    "validate_config": ["openclaw", "config", "validate"],
    "gateway_status": ["openclaw", "gateway", "status"],
}


class CommandRunner:
    def __init__(self, openclaw_home: str):
        self.openclaw_home = openclaw_home

    async def handle_command(self, payload: dict) -> dict:
        rid = payload.get("requestId", "?")
        cmd = payload.get("command", "")
        args = payload.get("args", {})
        logger.info(f"执行远程命令 [{rid}]: {cmd}")

        if cmd in ALLOWED_COMMANDS:
            return self._run_cli(rid, ALLOWED_COMMANDS[cmd])
        elif cmd == "get_skill_list":
            return self._list_skills(rid)
        elif cmd == "probe_models":
            return await self._probe_models(rid)
        elif cmd == "test_platform":
            return self._test_platform(rid, args)
        else:
            return {"requestId": rid, "success": False, "error": f"Unknown command: {cmd}"}

    def _run_cli(self, rid: str, argv: list[str]) -> dict:
        """执行 openclaw CLI 命令"""
        try:
            result = subprocess.run(
                argv, capture_output=True, text=True, timeout=30,
            )
            return {
                "requestId": rid,
                "success": result.returncode == 0,
                "stdout": result.stdout[:4000],
                "stderr": result.stderr[:4000],
            }
        except subprocess.TimeoutExpired:
            return {"requestId": rid, "success": False, "error": "Command timeout (30s)"}
        except FileNotFoundError:
            return {"requestId": rid, "success": False, "error": "openclaw CLI not found in PATH"}

    def _list_skills(self, rid: str) -> dict:
        """扫描本地技能目录, 返回技能列表"""
        skills_dir = Path(self.openclaw_home) / "skills"
        skills = []
        if skills_dir.is_dir():
            for item in skills_dir.iterdir():
                if item.is_dir():
                    meta_file = item / "skill.json"
                    meta = {}
                    if meta_file.exists():
                        try:
                            meta = json.loads(meta_file.read_text())
                        except Exception:
                            pass
                    skills.append({
                        "id": item.name,
                        "name": meta.get("name", item.name),
                        "description": meta.get("description", ""),
                    })
        return {"requestId": rid, "success": True, "skills": skills}

    async def _probe_models(self, rid: str) -> dict:
        """触发模型探测"""
        try:
            from ocagent.probes.model import probe_all_models
            results = await probe_all_models(self.openclaw_home)
            return {"requestId": rid, "success": True, "results": results}
        except ImportError:
            # probe_all_models 可能不存在, 降级为 CLI 方式
            return self._run_cli(rid, ["openclaw", "gateway", "status"])
        except Exception as e:
            return {"requestId": rid, "success": False, "error": str(e)}

    def _test_platform(self, rid: str, args: dict) -> dict:
        """测试平台连通性"""
        platform = args.get("platform", "")
        if not platform:
            # 测试 gateway 连通性作为通用检测
            return self._run_cli(rid, ["openclaw", "gateway", "status"])
        # 特定平台暂不支持精确测试, 返回 gateway status
        return self._run_cli(rid, ["openclaw", "gateway", "status"])

    async def handle_probe(self, payload: dict) -> dict:
        rid = payload.get("requestId", "?")
        results = []
        for target in payload.get("targets", []):
            if target.get("type") == "model":
                from ocagent.probes.model import probe_model
                r = await probe_model(self.openclaw_home, target["provider"], target["modelId"])
                results.append(r)
        return {"requestId": rid, "success": True, "results": results}
