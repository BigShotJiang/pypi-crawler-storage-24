"""远程配置推送执行器"""
import json
import shutil
import hashlib
import logging
import subprocess
import copy
from pathlib import Path
from datetime import datetime

import jsonpatch as jp

logger = logging.getLogger("ocagent.config_sync")

PRESERVE_PATHS = [
    "models.providers.*.apiKey", "models.providers.*.headers.Authorization",
    "channels.feishu.appSecret", "channels.feishu.accounts.*.appSecret",
    "channels.discord.token", "channels.telegram.token", "channels.whatsapp.token",
    "channels.*.token", "channels.*.appSecret",
    "gateway.auth.token", "auth.profiles.*.clientSecret",
]


class ConfigSyncExecutor:
    def __init__(self, openclaw_home: str, options: dict):
        self.openclaw_home = Path(openclaw_home)
        self.config_path = self.openclaw_home / "openclaw.json"
        self.backup_dir = self.openclaw_home / ".central" / "backups"
        self.auto_apply = options.get("auto_apply", False)
        self.max_backups = options.get("max_backups", 20)

    async def handle_push(self, payload: dict) -> dict:
        rid = payload.get("requestId", "?")
        op = payload.get("operation")
        logger.info(f"收到配置推送 [{rid}]: {op}")
        try:
            backup = self._backup()
            if op == "full_replace":
                remote = payload.get("config", {})
                local = json.loads(self.config_path.read_text())
                merged = _merge_preserve(local, remote)
                self.config_path.write_text(json.dumps(merged, indent=2, ensure_ascii=False))
            elif op == "patch":
                config = json.loads(self.config_path.read_text())
                patch = jp.JsonPatch(payload.get("patches", []))
                patched = patch.apply(config)
                self.config_path.write_text(json.dumps(patched, indent=2, ensure_ascii=False))
            else:
                return {"requestId": rid, "success": False, "error": f"Unknown op: {op}"}

            if not self._validate():
                shutil.copy2(backup, self.config_path)
                return {"requestId": rid, "success": False, "error": "Validation failed, rolled back"}

            if self.auto_apply:
                try:
                    subprocess.run(["openclaw", "gateway", "restart"], timeout=10, capture_output=True)
                except Exception as e:
                    logger.warning(f"Reload failed: {e}")

            new_hash = hashlib.sha256(self.config_path.read_bytes()).hexdigest()
            return {"requestId": rid, "success": True, "configHash": new_hash}
        except Exception as e:
            logger.error(f"Config push failed: {e}")
            return {"requestId": rid, "success": False, "error": str(e)}

    def _backup(self) -> Path:
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        bp = self.backup_dir / f"openclaw.json.{ts}.bak"
        shutil.copy2(self.config_path, bp)
        backups = sorted(self.backup_dir.glob("*.bak"))
        while len(backups) > self.max_backups:
            backups[0].unlink()
            backups.pop(0)
        return bp

    def _validate(self) -> bool:
        try:
            c = json.loads(self.config_path.read_text())
            return isinstance(c, dict) and ("agents" in c or "gateway" in c)
        except Exception:
            return False


def _merge_preserve(local: dict, remote: dict) -> dict:
    merged = copy.deepcopy(remote)
    for pattern in PRESERVE_PATHS:
        _copy_paths(local, merged, pattern.split("."), 0)
    return merged


def _copy_paths(src, dst, parts, depth):
    if depth >= len(parts) or not isinstance(src, dict) or not isinstance(dst, dict):
        return
    part = parts[depth]
    if part == "*":
        for key in src:
            if key in dst:
                if depth == len(parts) - 1:
                    dst[key] = src[key]
                else:
                    _copy_paths(src[key], dst[key], parts, depth + 1)
    elif part in src:
        if part not in dst:
            dst[part] = src[part]
        elif depth == len(parts) - 1:
            dst[part] = src[part]
        else:
            _copy_paths(src[part], dst[part], parts, depth + 1)
