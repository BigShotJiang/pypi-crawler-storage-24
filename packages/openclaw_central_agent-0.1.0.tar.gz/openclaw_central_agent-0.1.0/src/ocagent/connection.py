"""WebSocket 连接管理 — 自动重连 + 消息确认 + 离线队列"""
import asyncio
import json
import logging
import uuid
import time
from typing import Optional, Callable, Awaitable

import websockets
from websockets.exceptions import ConnectionClosed

from ocagent.queue import OfflineQueue

logger = logging.getLogger("ocagent.ws")

RECONNECT_BASE_SEC = 1
RECONNECT_MAX_SEC = 60
RECONNECT_FACTOR = 2
ACK_TIMEOUT_SEC = 5
MAX_RETRIES = 3


def _ensure_ws_scheme(url: str) -> str:
    """确保 URL 使用 ws:// 或 wss:// 协议"""
    if url.startswith("https://"):
        return "wss://" + url[8:]
    if url.startswith("http://"):
        return "ws://" + url[7:]
    if url.startswith("ws://") or url.startswith("wss://"):
        return url
    return "ws://" + url


async def register_node(server: str, token: str, name: str, tags: list) -> dict:
    """注册节点到 Central Server"""
    import httpx
    import platform
    import sys
    from ocagent import __version__

    url = f"{server.rstrip('/')}/api/nodes/register"
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(url, json={
                "name": name,
                "tags": tags,
                "hostname": platform.node(),
                "platform": sys.platform,
                "pythonVersion": platform.python_version(),
                "agentVersion": __version__,
            }, headers={"Authorization": f"Bearer {token}"})

            if resp.status_code == 200:
                data = resp.json()
                from ocagent.utils.paths import get_agent_config_path
                config_path = get_agent_config_path()
                config_path.parent.mkdir(parents=True, exist_ok=True)

                # 确保 ws_url 使用 ws:// 协议
                raw_ws_url = data.get("ws_url") or (server.rstrip("/") + "/ws")
                ws_url = _ensure_ws_scheme(raw_ws_url)

                toml_content = f'''[node]
id = "{data["node_id"]}"
name = "{name}"
tags = {json.dumps(tags)}

[server]
url = "{ws_url}"
auth_token = "{data["auth_token"]}"

[intervals]
heartbeat = 30
activity_poll = 5
stats_flush = 60
session_sync = 300
full_sync = 300
model_probe = 600

[config_sync]
enabled = true
auto_apply = false
backup_before_apply = true
max_backups = 20

[logging]
level = "INFO"
'''
                config_path.write_text(toml_content)
                return {"ok": True, "node_id": data["node_id"], "config_path": str(config_path)}
            else:
                return {"ok": False, "error": resp.text}
    except Exception as e:
        return {"ok": False, "error": str(e)}


async def test_server_connection() -> bool:
    """测试 Central Server 连通性"""
    import httpx
    from ocagent.utils.paths import load_agent_config
    config = load_agent_config()
    if not config:
        return False
    ws_url = config.get("server", {}).get("url", "")
    # ws:// → http://, wss:// → https://
    http_url = ws_url.replace("wss://", "https://").replace("ws://", "http://")
    if http_url.endswith("/ws"):
        http_url = http_url[:-3]
    http_url += "/api/health"
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(http_url)
            return resp.status_code < 500
    except Exception:
        return False


class WSConnection:
    def __init__(self, url: str, auth_token: str, node_id: str, queue: OfflineQueue):
        self.url = _ensure_ws_scheme(url)  # 保险：确保协议正确
        self.auth_token = auth_token
        self.node_id = node_id
        self.queue = queue
        self._ws = None
        self._connected = False
        self._pending_acks: dict[str, asyncio.Future] = {}
        self.on_config_push: Optional[Callable] = None
        self.on_command: Optional[Callable] = None
        self.on_probe_request: Optional[Callable] = None

    @property
    def connected(self) -> bool:
        return self._connected

    async def run_forever(self, stop_event: asyncio.Event):
        backoff = RECONNECT_BASE_SEC
        while not stop_event.is_set():
            try:
                headers = {
                    "Authorization": f"Bearer {self.auth_token}",
                    "X-Node-Id": self.node_id,
                }
                async with websockets.connect(
                    self.url, extra_headers=headers,
                    ping_interval=20, ping_timeout=10, close_timeout=5,
                    max_size=10 * 1024 * 1024,
                ) as ws:
                    self._ws = ws
                    self._connected = True
                    backoff = RECONNECT_BASE_SEC
                    logger.info(f"WebSocket 已连接: {self.url}")
                    await self._flush_offline_queue()
                    async for raw in ws:
                        await self._handle_downstream(raw)
            except ConnectionClosed as e:
                logger.warning(f"WebSocket 断开: {e}")
            except Exception as e:
                logger.warning(f"WebSocket 连接失败: {e}")
            finally:
                self._connected = False
                self._ws = None

            if stop_event.is_set():
                break
            logger.info(f"将在 {backoff}s 后重连...")
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=backoff)
                break
            except asyncio.TimeoutError:
                pass
            backoff = min(backoff * RECONNECT_FACTOR, RECONNECT_MAX_SEC)

    async def send(self, message: dict) -> bool:
        msg_id = str(uuid.uuid4())
        envelope = {"id": msg_id, "nodeId": self.node_id, "timestamp": time.time(), **message}
        if not self._connected or not self._ws:
            self.queue.push(envelope)
            return False
        for attempt in range(MAX_RETRIES):
            try:
                ack_future = asyncio.get_running_loop().create_future()
                self._pending_acks[msg_id] = ack_future
                await self._ws.send(json.dumps(envelope))
                await asyncio.wait_for(ack_future, timeout=ACK_TIMEOUT_SEC)
                return True
            except asyncio.TimeoutError:
                logger.debug(f"ACK 超时 (attempt {attempt + 1}): {msg_id}")
            except Exception as e:
                logger.warning(f"发送失败: {e}")
                break
            finally:
                self._pending_acks.pop(msg_id, None)
        self.queue.push(envelope)
        return False

    async def _handle_downstream(self, raw: str):
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            return
        msg_type = msg.get("type")
        if msg_type == "ack":
            msg_id = msg.get("id")
            if msg_id in self._pending_acks:
                self._pending_acks[msg_id].set_result(True)
            return
        if self._ws and msg.get("id"):
            await self._ws.send(json.dumps({"type": "ack", "id": msg["id"], "nodeId": self.node_id, "timestamp": time.time()}))
        payload = msg.get("payload", {})
        if msg_type == "config_push" and self.on_config_push:
            result = await self.on_config_push(payload)
            await self.send({"type": "config_push_result", "payload": result})
        elif msg_type == "command" and self.on_command:
            result = await self.on_command(payload)
            await self.send({"type": "command_result", "payload": result})
        elif msg_type == "probe_request" and self.on_probe_request:
            result = await self.on_probe_request(payload)
            await self.send({"type": "probe_result", "payload": result})

    async def _flush_offline_queue(self):
        messages = self.queue.drain()
        if not messages:
            return
        logger.info(f"发送 {len(messages)} 条离线缓存消息")
        for msg in messages:
            if self._ws:
                try:
                    await self._ws.send(json.dumps(msg))
                except Exception:
                    self.queue.push(msg)
                    break

    async def close(self):
        if self._ws:
            await self._ws.close()
