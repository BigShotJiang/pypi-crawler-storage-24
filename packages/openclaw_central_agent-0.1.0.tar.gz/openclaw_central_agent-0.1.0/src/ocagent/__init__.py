"""OpenClaw Central Agent — 节点监控守护进程"""

__version__ = "0.1.0"
