"""消息协议定义"""
from dataclasses import dataclass, field, asdict
from typing import Optional, Any
import time
import uuid


@dataclass
class UpstreamMessage:
    type: str
    payload: dict
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    nodeId: str = ""
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class HeartbeatPayload:
    uptime: int
    agentCount: int
    configHash: str


@dataclass
class AgentActivity:
    agentId: str
    state: str  # "idle" | "working" | "waiting" | "offline"
    lastActive: float
    name: str = ""
    emoji: str = "🤖"
    currentTool: Optional[str] = None
    subagents: list = field(default_factory=list)
    cronJobs: list = field(default_factory=list)
