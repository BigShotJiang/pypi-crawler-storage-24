"""采集器基类"""
from abc import ABC, abstractmethod


class BaseCollector(ABC):
    def __init__(self, openclaw_home: str, interval: int):
        self.openclaw_home = openclaw_home
        self.interval = interval

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    async def collect(self) -> dict | None: ...
