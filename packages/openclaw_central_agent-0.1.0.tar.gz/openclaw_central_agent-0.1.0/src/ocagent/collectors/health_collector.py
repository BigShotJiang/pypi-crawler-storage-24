"""健康状态采集"""
import json
from pathlib import Path
from ocagent.collectors.base import BaseCollector
from ocagent.utils.system_info import get_system_info
from ocagent.probes.gateway import probe_gateway


class HealthCollector(BaseCollector):
    name = "HealthCollector"

    def __init__(self, openclaw_home: str, interval: int, probe_interval: int = 600):
        super().__init__(openclaw_home, interval)
        self.probe_interval = probe_interval
        self._probe_counter = 0

    async def collect(self) -> dict | None:
        system = get_system_info(self.openclaw_home)
        port, token = 18789, ""
        try:
            config = json.loads((Path(self.openclaw_home) / "openclaw.json").read_text())
            port = config.get("gateway", {}).get("port", 18789)
            token = config.get("gateway", {}).get("auth", {}).get("token", "")
        except Exception:
            pass
        gw = await probe_gateway(port, token)
        payload = {"system": system, "gateway": gw}
        return {"type": "health", "payload": payload}
