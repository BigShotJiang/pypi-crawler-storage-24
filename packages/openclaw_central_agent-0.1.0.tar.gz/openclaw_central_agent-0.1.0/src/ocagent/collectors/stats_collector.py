"""统计数据增量采集"""
import json
import logging
from pathlib import Path
from collections import defaultdict
from datetime import datetime

from ocagent.collectors.base import BaseCollector

logger = logging.getLogger("ocagent.collector.stats")
OFFSETS_FILE = ".central/stats-offsets.json"


class StatsCollector(BaseCollector):
    name = "StatsCollector"

    def __init__(self, openclaw_home: str, interval: int):
        super().__init__(openclaw_home, interval)
        self._offsets: dict[str, int] = {}
        self._load_offsets()

    async def collect(self) -> dict | None:
        agents_dir = Path(self.openclaw_home) / "agents"
        if not agents_dir.exists():
            return None
        all_stats = []
        for agent_dir in sorted(agents_dir.iterdir()):
            if not agent_dir.is_dir() or agent_dir.name.startswith("."):
                continue
            sessions_dir = agent_dir / "sessions"
            if not sessions_dir.exists():
                continue
            hourly = self._parse_incremental(sessions_dir)
            if hourly:
                all_stats.append({"agentId": agent_dir.name, "hourlyStats": hourly})
        self._save_offsets()
        return {"type": "stats", "payload": {"period": "hourly", "agents": all_stats}} if all_stats else None

    def _parse_incremental(self, sessions_dir: Path) -> list:
        hours = defaultdict(lambda: {"inputTokens": 0, "outputTokens": 0, "messageCount": 0, "responseTimes": []})
        try:
            files = [f for f in sessions_dir.iterdir() if f.suffix == ".jsonl" and ".deleted." not in f.name]
        except OSError:
            return []
        messages_for_rt = []
        for fp in files:
            fkey = str(fp)
            offset = self._offsets.get(fkey, 0)
            if fp.stat().st_size <= offset:
                continue
            try:
                with open(fp) as f:
                    f.seek(offset)
                    new_content = f.read()
                    self._offsets[fkey] = f.tell()
            except OSError:
                continue
            for line in new_content.strip().split("\n"):
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if entry.get("type") != "message":
                    continue
                msg = entry.get("message", {})
                ts_str = entry.get("timestamp")
                if not ts_str:
                    continue
                messages_for_rt.append((msg.get("role"), ts_str, msg.get("usage"), msg.get("stopReason")))
                if msg.get("role") == "assistant" and msg.get("usage"):
                    hk = ts_str[:13]
                    hours[hk]["inputTokens"] += msg["usage"].get("input", 0)
                    hours[hk]["outputTokens"] += msg["usage"].get("output", 0)
                    hours[hk]["messageCount"] += 1
        last_user = None
        for role, ts_str, usage, stop in messages_for_rt:
            if role == "user":
                last_user = ts_str
            elif role == "assistant" and stop == "stop" and last_user:
                try:
                    tu = datetime.fromisoformat(last_user.replace("Z", "+00:00")).timestamp()
                    ta = datetime.fromisoformat(ts_str.replace("Z", "+00:00")).timestamp()
                    diff = int((ta - tu) * 1000)
                    if 0 < diff < 600_000:
                        hours[last_user[:13]]["responseTimes"].append(diff)
                except Exception:
                    pass
                last_user = None
        result = []
        for hk, h in sorted(hours.items()):
            rt = h["responseTimes"]
            result.append({"hour": hk, "inputTokens": h["inputTokens"], "outputTokens": h["outputTokens"],
                           "messageCount": h["messageCount"], "avgResponseMs": int(sum(rt) / len(rt)) if rt else 0,
                           "responseSamples": len(rt)})
        return result

    def _load_offsets(self):
        p = Path(self.openclaw_home) / OFFSETS_FILE
        if p.exists():
            try:
                self._offsets = json.loads(p.read_text())
            except Exception:
                self._offsets = {}

    def _save_offsets(self):
        p = Path(self.openclaw_home) / OFFSETS_FILE
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(self._offsets))
