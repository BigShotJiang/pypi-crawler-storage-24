"""配置采集"""
import json
from pathlib import Path
from ocagent.collectors.base import BaseCollector
from ocagent.parsers.config_parser import parse_openclaw_config, compute_config_hash
from ocagent.utils.sanitizer import sanitize_config


class ConfigCollector(BaseCollector):
    name = "ConfigCollector"

    async def collect(self) -> dict | None:
        parsed = parse_openclaw_config(self.openclaw_home)
        if not parsed:
            return None

        # Read raw config for snapshot (used by config editor / push / restore)
        raw_config = None
        try:
            raw_path = Path(self.openclaw_home) / "openclaw.json"
            if raw_path.exists():
                raw = json.loads(raw_path.read_text())
                raw_config = sanitize_config(raw)
        except Exception:
            pass

        return {
            "type": "config",
            "payload": {
                "config": parsed,           # parsed flat format for agents/providers ingestion
                "rawConfig": raw_config,     # original format for snapshot (editor/push)
                "configHash": compute_config_hash(self.openclaw_home),
            },
        }
