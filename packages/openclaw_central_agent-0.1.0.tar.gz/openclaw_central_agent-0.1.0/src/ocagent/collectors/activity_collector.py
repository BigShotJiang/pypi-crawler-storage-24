"""Agent 活动状态采集"""
import json
import time
import logging
from pathlib import Path
from datetime import datetime

from ocagent.collectors.base import BaseCollector
from ocagent.parsers.jsonl_parser import tail_jsonl_messages
from ocagent.parsers.identity import read_identity_name
from ocagent.parsers.cron_store import load_cron_jobs

logger = logging.getLogger("ocagent.collector.activity")
WORKING_THRESHOLD = 3 * 60
IDLE_THRESHOLD = 24 * 60 * 60


class ActivityCollector(BaseCollector):
    name = "ActivityCollector"

    async def collect(self) -> dict | None:
        agents_dir = Path(self.openclaw_home) / "agents"
        if not agents_dir.exists():
            return None
        now = time.time()
        agents = []
        for agent_dir in sorted(agents_dir.iterdir()):
            if not agent_dir.is_dir() or agent_dir.name.startswith("."):
                continue
            agent_id = agent_dir.name
            sessions_dir = agent_dir / "sessions"
            state, last_active, tool = self._detect(sessions_dir, now)
            name = read_identity_name(agent_id, self.openclaw_home) or agent_id
            info = {"agentId": agent_id, "name": name, "emoji": self._emoji(agent_id), "state": state, "lastActive": last_active or 0}
            if tool:
                info["currentTool"] = tool
            cron = load_cron_jobs(self.openclaw_home, agent_id)
            if cron:
                info["cronJobs"] = cron
            agents.append(info)
        return {"type": "activity", "payload": {"agents": agents}}

    def _detect(self, sessions_dir: Path, now: float):
        if not sessions_dir.exists():
            return "offline", None, None
        last_active = last_asst = None
        tool = None
        try:
            sessions_json = sessions_dir / "sessions.json"
            if sessions_json.exists():
                for val in json.loads(sessions_json.read_text()).values():
                    ts = val.get("updatedAt", 0)
                    if ts and (last_active is None or ts > last_active):
                        last_active = ts
        except Exception:
            pass
        try:
            files = sorted([f for f in sessions_dir.iterdir() if f.suffix == ".jsonl" and ".deleted." not in f.name],
                           key=lambda f: f.stat().st_mtime, reverse=True)[:5]
        except OSError:
            files = []
        for f in files:
            if now - f.stat().st_mtime > 180:
                continue
            for entry in reversed(tail_jsonl_messages(f, 20)):
                ts_str = entry.get("timestamp")
                if not ts_str:
                    continue
                try:
                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00")).timestamp()
                except Exception:
                    continue
                if last_active is None or ts > last_active:
                    last_active = ts
                if entry.get("message", {}).get("role") == "assistant":
                    if last_asst is None or ts > last_asst:
                        last_asst = ts
        state = "offline"
        if last_active:
            if last_asst and now - last_asst < WORKING_THRESHOLD:
                state = "working"
            elif now - last_active < IDLE_THRESHOLD:
                state = "idle"
        return state, last_active, tool

    def _emoji(self, agent_id: str) -> str:
        try:
            config = json.loads((Path(self.openclaw_home) / "openclaw.json").read_text())
            for a in config.get("agents", {}).get("list", []):
                if a.get("id") == agent_id:
                    return a.get("identity", {}).get("emoji", "🤖")
        except Exception:
            pass
        return "🤖"
