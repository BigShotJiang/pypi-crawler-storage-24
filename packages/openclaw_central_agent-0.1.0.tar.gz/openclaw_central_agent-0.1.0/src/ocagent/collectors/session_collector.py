"""会话列表采集"""
import json
from pathlib import Path
from ocagent.collectors.base import BaseCollector
from ocagent.parsers.session_key import parse_session_type


class SessionCollector(BaseCollector):
    name = "SessionCollector"

    async def collect(self) -> dict | None:
        agents_dir = Path(self.openclaw_home) / "agents"
        if not agents_dir.exists():
            return None
        all_sessions = []
        for agent_dir in sorted(agents_dir.iterdir()):
            if not agent_dir.is_dir() or agent_dir.name.startswith("."):
                continue
            sp = agent_dir / "sessions" / "sessions.json"
            if not sp.exists():
                continue
            try:
                data = json.loads(sp.read_text())
            except Exception:
                continue
            sessions = []
            for key, val in data.items():
                stype, target = parse_session_type(key)
                sessions.append({"key": key, "type": stype, "target": target,
                                 "updatedAt": val.get("updatedAt", 0),
                                 "totalTokens": val.get("totalTokens", 0),
                                 "contextTokens": val.get("contextTokens", 0)})
            sessions.sort(key=lambda s: s["updatedAt"], reverse=True)
            all_sessions.append({"agentId": agent_dir.name, "sessions": sessions})
        return {"type": "sessions", "payload": {"agents": all_sessions}} if all_sessions else None
