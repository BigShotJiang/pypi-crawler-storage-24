"""python -m ocagent"""
from ocagent.cli import main
main()
