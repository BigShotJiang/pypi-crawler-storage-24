#!/bin/sh
if [ ! -f "$OC_OPENCLAW_HOME/.central/agent.toml" ] && [ -n "$OC_SERVER_URL" ]; then
    ocagent register \
        --server "$OC_SERVER_URL" \
        --token "$OC_AUTH_TOKEN" \
        --name "${OC_NODE_NAME:-$(hostname)}" \
        --tags "${OC_NODE_TAGS:-docker}"
fi
exec "$@"
