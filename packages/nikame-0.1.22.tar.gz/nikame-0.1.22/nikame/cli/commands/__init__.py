"""NIKAME CLI commands."""
