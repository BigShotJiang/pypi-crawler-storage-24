"""NIKAME utility modules."""
