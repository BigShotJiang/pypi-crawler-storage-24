"""NIKAME output composers."""
