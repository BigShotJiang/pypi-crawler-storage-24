"""NIKAME storage modules."""
