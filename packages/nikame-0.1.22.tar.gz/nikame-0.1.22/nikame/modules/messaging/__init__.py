"""NIKAME messaging modules."""
