## Typing stubs for waitress

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`waitress`](https://github.com/Pylons/waitress) package. It can be used by type checkers
to check code that uses `waitress`. This version of
`types-waitress` aims to provide accurate annotations for
`waitress~=3.0.1`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/waitress`](https://github.com/python/typeshed/tree/main/stubs/waitress)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`61524fab4e1804462cc31d2e6b43ff7279188f85`](https://github.com/python/typeshed/commit/61524fab4e1804462cc31d2e6b43ff7279188f85).