<p align="center">
  <img src="https://dev.dataqualitycompany.app/favicon/DQC-Logo-801x331.png" alt="Data Quality Company" width="200">
</p>

# dqc-db

A thread-safe SQLite wrapper for Python with a single-writer, multi-reader architecture. Built by [Data Quality Company](https://dataqualitycompany.app).

## Features

- **Single writer, many readers** — all writes go through a background writer thread via a queue; each reading thread gets its own connection for parallel reads
- **Two transaction modes** — batched (collects statements, commits at once) and pinned (immediate execution, blocks other writers)
- **Automatic retry** — write operations retry with exponential backoff + jitter on `SQLITE_BUSY` / `SQLITE_LOCKED`
- **Streaming** — fetch large result sets in chunks without loading everything into memory
- **Zero dependencies** — only Python 3.11+ standard library

## Installation

```bash
pip install dqc-db
```

## Quick start

```python
from dqc_db import DbClient

with DbClient("my.db") as db:
    db.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)")
    db.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("Alice", 30))

    users = db.query("SELECT * FROM users")
    print(users[0]["name"])  # "Alice"
```

## API

### Writes

```python
db.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("Alice", 30))
db.executemany("INSERT INTO users (name, age) VALUES (?, ?)", [("Bob", 25), ("Eve", 42)])
```

### Reads

```python
db.query("SELECT * FROM users")                          # list of rows
db.query_one("SELECT * FROM users WHERE id = ?", (1,))   # single row or None

for chunk in db.stream("SELECT * FROM big_table", chunk_size=5000):
    process(chunk)
```

### Transactions

```python
# Batched (default) — commits everything at once
with db.transaction():
    db.executemany("INSERT INTO users (name, age) VALUES (?, ?)", big_list)

# Pinned — each statement runs immediately, blocks other writers
with db.transaction(mode="pinned"):
    db.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("Alice", 30))
    db.execute("UPDATE users SET age = 31 WHERE name = ?", ("Alice",))
```

### Constructor options

```python
DbClient(
    db_path=":memory:",
    busy_timeout=5000,
    max_retries=10,
    pragmas={"cache_size": "-20000"},
)
```

### Default PRAGMAs

These are set on every connection automatically:

```
journal_mode = WAL
synchronous = NORMAL
foreign_keys = ON
busy_timeout = 5000
temp_store = MEMORY
wal_autocheckpoint = 1000
```

Override any default via the `pragmas` constructor parameter:

```python
db = DbClient("my.db", pragmas={"synchronous": "FULL", "cache_size": "-20000"})
```

## Advanced examples

### Bulk inserts with transactions

Wrap `executemany()` in a transaction for best performance — everything commits in a single operation:

```python
users = [("Alice", 30), ("Bob", 25), ("Eve", 42), ("Charlie", 35)]

with db.transaction():
    db.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)")
    db.executemany("INSERT INTO users (name, age) VALUES (?, ?)", users)
# all rows inserted in one commit
```

### Multi-step writes with pinned transactions

Use pinned mode when writes depend on each other and must execute immediately:

```python
with db.transaction(mode="pinned"):
    db.execute("INSERT INTO orders (user_id, total) VALUES (?, ?)", (1, 99.99))
    db.execute("UPDATE users SET order_count = order_count + 1 WHERE id = ?", (1,))
    db.execute("INSERT INTO audit_log (action, user_id) VALUES (?, ?)", ("new_order", 1))
# all three statements committed together, other writers blocked until done
```

### Concurrent reads from multiple threads

Each thread gets its own reader connection — reads never block each other:

```python
import threading

def read_users(db, thread_name):
    users = db.query("SELECT * FROM users WHERE age > ?", (25,))
    print(f"{thread_name}: found {len(users)} users")

with DbClient("my.db") as db:
    threads = [
        threading.Thread(target=read_users, args=(db, f"T{i}"))
        for i in range(5)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
```

### Streaming large result sets

Process millions of rows without loading them all into memory:

```python
total = 0
for chunk in db.stream("SELECT * FROM events", chunk_size=10000):
    for row in chunk:
        total += row["amount"]
print(f"Total: {total}")
```

### Multi-threaded writes

Writes from multiple threads are serialized through the writer queue automatically:

```python
import threading

def insert_batch(db, batch, thread_name):
    with db.transaction():
        db.executemany("INSERT INTO logs (source, message) VALUES (?, ?)", batch)
    print(f"{thread_name}: inserted {len(batch)} rows")

with DbClient("app.db") as db:
    db.execute("CREATE TABLE logs (id INTEGER PRIMARY KEY, source TEXT, message TEXT)")

    batches = [
        [(f"service_{i}", f"msg_{j}") for j in range(1000)]
        for i in range(4)
    ]
    threads = [
        threading.Thread(target=insert_batch, args=(db, batch, f"T{i}"))
        for i, batch in enumerate(batches)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    # 4000 rows inserted safely across 4 threads
```

### In-memory database

Useful for tests — all threads share the same data:

```python
with DbClient(":memory:") as db:
    db.execute("CREATE TABLE temp (id INTEGER PRIMARY KEY, value TEXT)")
    db.execute("INSERT INTO temp (value) VALUES (?)", ("hello",))
    print(db.query_one("SELECT * FROM temp")["value"])  # "hello"
```

## Architecture

```
Thread A ──► queue ──► Writer Thread ──► SQLite
Thread B ──►
Thread C ──►
```

- Writes are serialized through a single background writer thread
- Reads use thread-local connections for parallel access
- In-memory databases use shared-cache URIs so all connections see the same data

## License

Proprietary. Copyright Data Quality Company. All rights reserved.
