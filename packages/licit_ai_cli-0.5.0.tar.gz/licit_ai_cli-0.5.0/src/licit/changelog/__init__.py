"""Agent configuration changelog tracking."""
