"""Client for Quickbase's RESTful JSON API."""

from __future__ import annotations

import logging

from quickbase_api.session import create_session

logger = logging.getLogger(__name__)

BASE_URL = "https://api.quickbase.com/v1"


class RestMethod:
    """Low-level HTTP client for the Quickbase REST API.

    Handles URL construction, request execution, and response parsing
    for all REST API endpoints.
    """

    def __init__(self, realm: str, user_token: str):
        self.session = create_session(realm, user_token)

    def make_request(
        self,
        method: str,
        endpoint: str,
        params: dict = None,
        data: dict = None,
        body: str = None,
        extra_headers: dict = None,
    ) -> tuple[dict | str, int]:
        """Execute an HTTP request against the Quickbase REST API.

        Supports both JSON payloads (via data) and raw string payloads
        (via body) for endpoints like the Solutions API that use YAML.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            endpoint: API endpoint path (appended to base URL).
            params: Optional query string parameters.
            data: Optional JSON request body (dict).
            body: Optional raw string request body (e.g., YAML).
            extra_headers: Optional additional headers for this request.

        Returns:
            A tuple of (response_body, status_code). Body is a dict
            for JSON responses or a string for non-JSON/YAML responses.

        Raises:
            ValueError: If both data and body are specified.
        """
        if data is not None and body is not None:
            raise ValueError("Cannot specify both 'data' and 'body'")

        url = f"{BASE_URL}/{endpoint}"

        kwargs = {"method": method, "url": url, "params": params}

        if body is not None:
            kwargs["data"] = body
            # Override the session's default JSON content type for raw payloads
            kwargs["headers"] = {"Content-Type": "application/x-yaml"}
        elif data is not None:
            kwargs["json"] = data

        if extra_headers:
            kwargs.setdefault("headers", {}).update(extra_headers)

        response = self.session.request(**kwargs)

        content_type = response.headers.get("Content-Type", "")
        if "application/json" in content_type:
            try:
                result = response.json()
            except ValueError:
                result = {"raw_response": response.text}
        elif "yaml" in content_type:
            result = response.text
        else:
            result = response.text

        if response.status_code >= 400:
            logger.error(
                "REST API error %d on %s %s: %s",
                response.status_code,
                method,
                endpoint,
                result,
            )

        return result, response.status_code

    def get(self, endpoint: str, params: dict = None) -> tuple[dict, int]:
        """Send a GET request."""
        return self.make_request("GET", endpoint, params=params)

    def post(self, endpoint: str, params: dict = None, data: dict = None) -> tuple[dict, int]:
        """Send a POST request."""
        return self.make_request("POST", endpoint, params=params, data=data)

    def put(self, endpoint: str, params: dict = None, data: dict = None) -> tuple[dict, int]:
        """Send a PUT request."""
        return self.make_request("PUT", endpoint, params=params, data=data)

    def delete(self, endpoint: str, params: dict = None, data: dict = None) -> tuple[dict, int]:
        """Send a DELETE request."""
        return self.make_request("DELETE", endpoint, params=params, data=data)
