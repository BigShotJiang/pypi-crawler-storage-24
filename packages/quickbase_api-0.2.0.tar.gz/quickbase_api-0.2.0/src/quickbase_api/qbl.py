"""QBL parsing, modification, and serialization utilities for the Quickbase Solutions API."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from io import StringIO

from ruamel.yaml import YAML  # type: ignore[import-unresolved]

logger = logging.getLogger(__name__)

# Known-valid icon names (discovered empirically — Quickbase doesn't publish these).
# Expand this set as you confirm more values work.
KNOWN_ICONS = {
    "Application",
    "Briefcase",
    "Calendar",
    "Chart",
    "Clipboard",
    "Document",
    "Folder",
    "Gear",
    "Globe",
    "Heart",
    "Home",
    "Lightning",
    "List",
    "Lock",
    "People",
    "Star",
    "Tasks",
    "Wrench",
}

DEFAULT_ICON = "Application"


@dataclass
class QBLDiagnostics:
    """Collects issues found during QBL parsing and modification.

    Attributes:
        bad_refs: List of (path, value) tuples for every !BadRef found.
        warnings: General warnings encountered during modification.
        manager_removed: The manager value that was stripped, if any.
    """

    bad_refs: list[tuple[str, str]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    manager_removed: str | None = None

    @property
    def has_bad_refs(self) -> bool:
        return len(self.bad_refs) > 0

    def summary(self) -> str:
        """Return a human-readable summary of diagnostics."""
        lines = []
        if self.manager_removed:
            lines.append(f"Stripped Manager: {self.manager_removed}")
        if self.bad_refs:
            lines.append(f"Found {len(self.bad_refs)} !BadRef entries:")
            for path, value in self.bad_refs:
                lines.append(f"  {path}: {value}")
        if self.warnings:
            lines.append(f"Warnings ({len(self.warnings)}):")
            for w in self.warnings:
                lines.append(f"  {w}")
        return "\n".join(lines) if lines else "No issues found."


def _create_yaml_handler() -> YAML:
    """Create a ruamel.yaml handler configured for QBL round-tripping."""
    handler = YAML()
    handler.preserve_quotes = True
    # Allow arbitrary custom tags (!Ref, !BadRef, etc.) to pass through
    # without raising errors. ruamel.yaml round-trip mode does this by default.
    return handler


def parse_qbl(qbl: str) -> dict:
    """Parse a QBL YAML string into a round-trip-safe data structure.

    The returned object preserves tags, comments, and key ordering
    so it can be modified and re-serialized without losing !Ref entries.

    Args:
        qbl: The raw QBL YAML string.

    Returns:
        A ruamel.yaml CommentedMap (dict-like) preserving all tags.
    """
    handler = _create_yaml_handler()
    return handler.load(qbl)


def serialize_qbl(data) -> str:
    """Serialize a parsed QBL structure back to a YAML string.

    Preserves custom tags (!Ref, !BadRef) and key ordering.

    Args:
        data: The parsed QBL data (from parse_qbl).

    Returns:
        The QBL YAML string, ready to send to the Solutions API.
    """
    handler = _create_yaml_handler()
    stream = StringIO()
    handler.dump(data, stream)
    return stream.getvalue()


def collect_bad_refs(data, path: str = "") -> list[tuple[str, str]]:
    """Walk a parsed QBL structure and collect all !BadRef entries.

    Args:
        data: The parsed QBL data (or a subtree).
        path: The current dot-delimited path (used for recursion).

    Returns:
        A list of (path, value) tuples for each !BadRef found.
    """
    results = []

    # ruamel.yaml tagged scalars have a .tag attribute
    if hasattr(data, "tag") and data.tag is not None:
        tag_str = str(data.tag)
        if "BadRef" in tag_str:
            results.append((path or "(root)", str(data)))

    if isinstance(data, dict):
        for key, value in data.items():
            child_path = f"{path}.{key}" if path else str(key)
            results.extend(collect_bad_refs(value, child_path))
    elif isinstance(data, list):
        for i, item in enumerate(data):
            child_path = f"{path}[{i}]"
            results.extend(collect_bad_refs(item, child_path))

    return results


def modify_qbl(
    qbl: str,
    name: str = None,
    app_color: str = None,
    app_icon: str = None,
) -> tuple[str, QBLDiagnostics]:
    """Modify properties in a QBL definition for cloning.

    Handles:
    - Renaming the app (ParameterDefinitions + Resource logical ID)
    - Changing the app color and icon
    - Stripping the Manager field (the API assigns the caller)
    - Collecting all !BadRef entries for diagnostic review

    Args:
        qbl: The original QBL YAML string.
        name: New app name (e.g., 'MyApp-Dev').
        app_color: New app color hex (e.g., '#4a90d9').
        app_icon: New app icon name. Falls back to 'Application'
            if the value isn't in the known-valid set.

    Returns:
        A tuple of (modified_qbl_string, diagnostics).
    """
    diagnostics = QBLDiagnostics()
    data = parse_qbl(qbl)

    # ── Collect !BadRef entries ───────────────────────────────────────
    diagnostics.bad_refs = collect_bad_refs(data)
    if diagnostics.bad_refs:
        logger.warning(
            "QBL contains %d !BadRef entries. See diagnostics for details.",
            len(diagnostics.bad_refs),
        )

    # ── Validate and default the icon ─────────────────────────────────
    if app_icon is not None and app_icon not in KNOWN_ICONS:
        diagnostics.warnings.append(f"Icon '{app_icon}' not in known set; falling back to '{DEFAULT_ICON}'")
        app_icon = DEFAULT_ICON

    # ── Rename the app ────────────────────────────────────────────────
    original_name = None
    if name is not None:
        param_defs = data.get("ParameterDefinitions", {})
        for param_key, param_def in param_defs.items():
            if "App_Name" in str(param_key):
                original_name = param_def["Value"]
                param_def["Value"] = name
                break

        if original_name is None:
            diagnostics.warnings.append("Could not find App_Name parameter definition; name not changed.")

        # Update the logical ID under Resources
        if original_name is not None:
            resources = data.get("Resources", {})
            old_logical_id = f"$App_{original_name.replace(' ', '_')}"
            new_logical_id = f"$App_{name.replace(' ', '_')}"
            if old_logical_id in resources:
                resources.insert(
                    list(resources.keys()).index(old_logical_id),
                    new_logical_id,
                    resources.pop(old_logical_id),
                )
            else:
                diagnostics.warnings.append(f"Could not find resource '{old_logical_id}' to rename.")

    # ── Update app properties and strip Manager ───────────────────────
    for key, resource in data.get("Resources", {}).items():
        if not isinstance(resource, dict):
            continue
        if resource.get("Type") != "QB::Application":
            continue

        props = resource.get("Properties", {})

        if app_color is not None:
            props["AppColor"] = app_color
        if app_icon is not None:
            props["AppIcon"] = app_icon

        # Strip the Manager — the create API assigns the caller
        if "Manager" in props:
            diagnostics.manager_removed = props.pop("Manager")
            logger.info("Stripped Manager '%s' from QBL", diagnostics.manager_removed)

        break  # Only one application resource

    modified_qbl = serialize_qbl(data)
    return modified_qbl, diagnostics


def extract_app_properties(qbl: str) -> dict:
    """Extract the app name, color, and icon from a QBL definition.

    Used to read a solution's identity properties so another QBL
    can be modified to match before pushing changes.

    Args:
        qbl: The QBL YAML string.

    Returns:
        A dict with keys: name, app_color, app_icon.
    """
    data = parse_qbl(qbl)

    props = {}

    # Get the name from ParameterDefinitions
    param_defs = data.get("ParameterDefinitions", {})
    for param_key, param_def in param_defs.items():
        if "App_Name" in str(param_key):
            props["name"] = param_def["Value"]
            break

    # Get color and icon from the Application resource
    for key, resource in data.get("Resources", {}).items():
        if not isinstance(resource, dict):
            continue
        if resource.get("Type") != "QB::Application":
            continue
        resource_props = resource.get("Properties", {})
        props["app_color"] = resource_props.get("AppColor")
        props["app_icon"] = resource_props.get("AppIcon")
        break

    return props
