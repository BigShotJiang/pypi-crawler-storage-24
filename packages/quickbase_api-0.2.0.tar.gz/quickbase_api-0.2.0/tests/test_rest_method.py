"""Tests for RestMethod HTTP client."""

BASE_URL = "https://api.quickbase.com/v1"


class TestRestMethodGet:
    def test_get_success(self, mock_api, rest):
        mock_api.get(
            f"{BASE_URL}/apps/abc123",
            json={"id": "abc123", "name": "Test App"},
            status=200,
        )
        body, status = rest.get("apps/abc123")
        assert status == 200
        assert body["id"] == "abc123"

    def test_get_with_params(self, mock_api, rest):
        mock_api.get(
            f"{BASE_URL}/tables",
            json=[{"id": "tbl1", "name": "Table One"}],
            status=200,
        )
        body, status = rest.get("tables", params={"appId": "abc123"})
        assert status == 200
        assert mock_api.calls[0].request.params["appId"] == "abc123"

    def test_get_not_found(self, mock_api, rest):
        mock_api.get(
            f"{BASE_URL}/apps/invalid",
            json={"message": "Not found", "description": "App not found"},
            status=404,
        )
        body, status = rest.get("apps/invalid")
        assert status == 404
        assert "message" in body


class TestRestMethodPost:
    def test_post_with_data(self, mock_api, rest):
        mock_api.post(
            f"{BASE_URL}/apps",
            json={"id": "abc123", "name": "New App"},
            status=200,
        )
        body, status = rest.post("apps", data={"name": "New App"})
        assert status == 200
        assert body["name"] == "New App"

    def test_post_with_params_and_data(self, mock_api, rest):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 6, "label": "Name", "fieldType": "text"},
            status=200,
        )
        body, status = rest.post(
            "fields",
            params={"tableId": "tbl1"},
            data={"label": "Name", "fieldType": "text"},
        )
        assert status == 200
        assert mock_api.calls[0].request.params["tableId"] == "tbl1"


class TestRestMethodDelete:
    def test_delete_with_data(self, mock_api, rest):
        mock_api.delete(
            f"{BASE_URL}/records",
            json={"numberDeleted": 5},
            status=200,
        )
        body, status = rest.delete("records", data={"from": "tbl1", "where": "{6.EX.'test'}"})
        assert status == 200
        assert body["numberDeleted"] == 5

    def test_delete_with_params(self, mock_api, rest):
        mock_api.delete(
            f"{BASE_URL}/tables/tbl1",
            json={"deletedTableId": "tbl1"},
            status=200,
        )
        body, status = rest.delete("tables/tbl1", params={"appId": "abc123"})
        assert status == 200
        assert mock_api.calls[0].request.params["appId"] == "abc123"


class TestRestMethodHeaders:
    def test_session_has_auth_headers(self, rest):
        assert rest.session.headers["QB-Realm-Hostname"] == "testrealm.quickbase.com"
        assert rest.session.headers["Authorization"] == "QB-USER-TOKEN test-token-123"
        assert rest.session.headers["Content-Type"] == "application/json"


class TestRestMethodErrorHandling:
    def test_non_json_response(self, mock_api, rest):
        mock_api.get(
            "https://api.quickbase.com/v1/apps/abc123",
            body="<html>Bad Request</html>",
            status=400,
            content_type="text/html",
        )
        result, code = rest.get("apps/abc123")
        assert code == 400
        assert "<html>Bad Request</html>" in result

    def test_server_error(self, mock_api, rest):
        mock_api.get(
            f"{BASE_URL}/apps/abc123",
            json={"message": "Internal error"},
            status=500,
        )
        body, status = rest.get("apps/abc123")
        assert status == 500
