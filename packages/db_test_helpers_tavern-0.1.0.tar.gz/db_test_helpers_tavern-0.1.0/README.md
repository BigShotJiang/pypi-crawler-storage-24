# db-test-helpers-tavern

Tavern integration for [db-test-helpers](https://github.com/takaaa220/db-test-helpers). Provides DB seeding and state verification for YAML-based API tests.

## Installation

```bash
pip install db-test-helpers-tavern
```

## Documentation

See the [main repository](https://github.com/takaaa220/db-test-helpers) for usage and documentation.
