"""SQLite adapter configuration for Tavern E2E examples."""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from db_test_helpers.sqlite import SqliteAdapter
from db_test_helpers.tavern import configure, reset


@pytest.fixture(scope="session")
def sqlite_conn():
    conn = sqlite3.connect(":memory:")
    yield conn
    conn.close()



@pytest.fixture
def _db_configure(sqlite_conn):
    reset()
    configure(
        adapter=SqliteAdapter(sqlite_conn),
        base_path=Path(__file__).parent,
    )
    yield
    try:
        for (table,) in sqlite_conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall():
            sqlite_conn.execute(f"DROP TABLE IF EXISTS [{table}]")
    finally:
        reset()
