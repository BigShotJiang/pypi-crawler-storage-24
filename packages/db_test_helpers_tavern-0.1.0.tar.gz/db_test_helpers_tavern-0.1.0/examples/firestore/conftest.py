"""Firestore adapter configuration for Tavern E2E examples."""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from google.cloud import firestore

from db_test_helpers.firestore import FirestoreAdapter
from db_test_helpers.tavern import configure, reset


@pytest.fixture(scope="session")
def firestore_client():
    port = os.environ.get("FIRESTORE_PORT", "8080")
    os.environ.setdefault("FIRESTORE_EMULATOR_HOST", f"localhost:{port}")
    return firestore.Client(project="demo-project")


@pytest.fixture
def _db_configure(firestore_client):
    reset()
    configure(
        adapter=FirestoreAdapter(firestore_client),
        base_path=Path(__file__).parent,
    )
    yield
    try:
        for col in firestore_client.collections():
            firestore_client.recursive_delete(col)
    finally:
        reset()
