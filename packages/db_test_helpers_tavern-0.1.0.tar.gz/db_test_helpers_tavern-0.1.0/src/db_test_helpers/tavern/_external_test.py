"""Tests for _external module (verify_db, setup_db)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from db_test_helpers.tavern._config import _reset, configure
from db_test_helpers.tavern._external import setup_db, verify_db


def _make_adapter() -> MagicMock:
    return MagicMock()


@pytest.fixture(autouse=True)
def _cleanup():
    _reset()
    yield
    _reset()


class TestVerifyDb:
    def test_calls_verify_db_data(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)

        yaml_file = tmp_path / "expected.yaml"
        yaml_file.write_text("users:\n  - name: Alice\n")

        with patch("db_test_helpers.tavern._external.verify_db_data") as mock_verify:
            verify_db(response=MagicMock(), files=["expected.yaml"])
            mock_verify.assert_called_once()
            call_args = mock_verify.call_args
            assert call_args[0][0] is adapter
            assert call_args[0][1] == tmp_path / "expected.yaml"

    def test_response_is_ignored(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)
        (tmp_path / "f.yaml").write_text("x:\n  - a: 1\n")

        with patch("db_test_helpers.tavern._external.verify_db_data"):
            # Should not raise regardless of response value
            verify_db(response=None, files=["f.yaml"])
            verify_db(response="anything", files=["f.yaml"])

    def test_with_adapter_name(self, tmp_path: Path):
        a = _make_adapter()
        b = _make_adapter()
        configure(adapters={"a": a, "b": b}, base_path=tmp_path)
        (tmp_path / "f.yaml").write_text("x:\n  - a: 1\n")

        with patch("db_test_helpers.tavern._external.verify_db_data") as mock_verify:
            verify_db(response=MagicMock(), files=["f.yaml"], adapter="b")
            assert mock_verify.call_args[0][0] is b

    def test_with_variables(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)
        (tmp_path / "f.yaml").write_text("x:\n  - a: 1\n")

        with patch("db_test_helpers.tavern._external.verify_db_data") as mock_verify:
            verify_db(response=MagicMock(), files=["f.yaml"], variables='{"uid": "123"}')
            config = mock_verify.call_args[0][2]
            assert config.variables == {"uid": "123"}

    def test_not_configured_raises(self):
        with pytest.raises(RuntimeError, match="configure"):
            verify_db(response=MagicMock(), files=["f.yaml"])

    def test_invalid_variables_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(ValueError, match="Invalid JSON"):
            verify_db(response=MagicMock(), files=["f.yaml"], variables="bad")

    def test_multiple_files_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(ValueError, match="exactly 1 file"):
            verify_db(response=MagicMock(), files=["a.yaml", "b.yaml"])

    def test_empty_files_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(ValueError, match="exactly 1 file"):
            verify_db(response=MagicMock(), files=[])

    def test_files_not_list_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(TypeError, match="files must be a list"):
            verify_db(response=MagicMock(), files="single.yaml")  # type: ignore[arg-type]


class TestSetupDb:
    def test_calls_set_db_data(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)

        yaml_file = tmp_path / "seed.yaml"
        yaml_file.write_text("users:\n  - name: Alice\n")

        with patch("db_test_helpers.tavern._external.set_db_data") as mock_set:
            setup_db(response=MagicMock(), files=["seed.yaml"])
            mock_set.assert_called_once()
            call_args = mock_set.call_args
            assert call_args[0][0] is adapter
            assert call_args[0][1] == tmp_path / "seed.yaml"

    def test_response_is_ignored(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)
        (tmp_path / "f.yaml").write_text("x:\n  - a: 1\n")

        with patch("db_test_helpers.tavern._external.set_db_data"):
            setup_db(response=None, files=["f.yaml"])
            setup_db(response="anything", files=["f.yaml"])

    def test_with_adapter_name(self, tmp_path: Path):
        a = _make_adapter()
        b = _make_adapter()
        configure(adapters={"a": a, "b": b}, base_path=tmp_path)
        (tmp_path / "f.yaml").write_text("x:\n  - a: 1\n")

        with patch("db_test_helpers.tavern._external.set_db_data") as mock_set:
            setup_db(response=MagicMock(), files=["f.yaml"], adapter="a")
            assert mock_set.call_args[0][0] is a

    def test_with_variables(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)
        (tmp_path / "f.yaml").write_text("x:\n  - a: 1\n")

        with patch("db_test_helpers.tavern._external.set_db_data") as mock_set:
            setup_db(response=MagicMock(), files=["f.yaml"], variables='{"key": "val"}')
            config = mock_set.call_args[0][2]
            assert config.variables == {"key": "val"}

    def test_not_configured_raises(self):
        with pytest.raises(RuntimeError, match="configure"):
            setup_db(response=MagicMock(), files=["f.yaml"])

    def test_invalid_variables_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(ValueError, match="Invalid JSON"):
            setup_db(response=MagicMock(), files=["f.yaml"], variables="bad")

    def test_multiple_files_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(ValueError, match="exactly 1 file"):
            setup_db(response=MagicMock(), files=["a.yaml", "b.yaml"])

    def test_empty_files_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(ValueError, match="exactly 1 file"):
            setup_db(response=MagicMock(), files=[])

    def test_files_not_list_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(TypeError, match="files must be a list"):
            setup_db(response=MagicMock(), files="single.yaml")  # type: ignore[arg-type]
