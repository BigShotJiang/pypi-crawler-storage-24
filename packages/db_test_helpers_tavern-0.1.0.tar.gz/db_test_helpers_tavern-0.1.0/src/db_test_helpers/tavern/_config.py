"""Global configuration state for db-test-helpers-tavern."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from db_test_helpers.core import DatabaseAdapter


@dataclass
class _Registry:
    adapters: dict[str, DatabaseAdapter]
    base_path: Path


_registry: _Registry | None = None


def configure(
    *,
    adapter: DatabaseAdapter | None = None,
    adapters: dict[str, DatabaseAdapter] | None = None,
    base_path: str | Path | None = None,
) -> None:
    global _registry

    if _registry is not None:
        raise RuntimeError("configure() has already been called")

    if adapter is not None and adapters is not None:
        raise ValueError("Cannot specify both 'adapter' and 'adapters'")
    if adapter is None and adapters is None:
        raise ValueError("Must specify either 'adapter' or 'adapters'")

    if adapter is not None:
        resolved_adapters = {"__default__": adapter}
    else:
        assert adapters is not None
        resolved_adapters = adapters

    resolved_base_path = Path(base_path) if base_path is not None else Path.cwd()

    _registry = _Registry(adapters=resolved_adapters, base_path=resolved_base_path)


def _reset() -> None:
    global _registry
    _registry = None


def _resolve_adapter(name: str | None) -> DatabaseAdapter:
    if _registry is None:
        raise RuntimeError("configure() has not been called")

    if "__default__" in _registry.adapters:
        if name is not None:
            raise ValueError(
                f"single adapter mode does not accept adapter name: {name!r}"
            )
        return _registry.adapters["__default__"]

    if name is None:
        raise ValueError(
            "Multiple adapters registered; must specify adapter name"
        )
    if name not in _registry.adapters:
        raise ValueError(f"Unknown adapter: {name!r}")
    return _registry.adapters[name]


def _resolve_path(file: str) -> Path:
    if _registry is None:
        raise RuntimeError("configure() has not been called")

    path = Path(file)
    if path.is_absolute():
        raise ValueError(f"Path must be relative, got: {file!r}")

    resolved = (_registry.base_path / file).resolve()
    base_resolved = _registry.base_path.resolve()

    if not resolved.is_relative_to(base_resolved):
        raise ValueError(f"Path resolves outside base_path: {file!r}")

    return resolved


def _parse_variables(variables: dict[str, object] | str | None) -> dict[str, object]:
    if variables is None:
        return {}
    if isinstance(variables, dict):
        return _normalize_dict(variables)
    if not isinstance(variables, str):
        raise ValueError(f"variables must be a dict, str, or None, got {type(variables).__name__}")
    try:
        parsed = json.loads(variables)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in variables: {e}") from e
    if not isinstance(parsed, dict):
        raise ValueError(f"variables must be a JSON object, got {type(parsed).__name__}")
    return _normalize_dict(parsed)


def _normalize_value(value: object) -> object:
    """Convert subclass instances (e.g. Tavern's FormattedString) to plain Python types."""
    if isinstance(value, dict):
        return _normalize_dict(value)
    if isinstance(value, list):
        return [_normalize_value(v) for v in value]
    if type(value) is not str and isinstance(value, str):
        return str(value)
    return value


def _normalize_dict(d: dict[str, object]) -> dict[str, object]:
    return {str(k): _normalize_value(v) for k, v in d.items()}
