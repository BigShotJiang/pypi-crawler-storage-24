"""pytest plugin for db-test-helpers-tavern."""

from __future__ import annotations

import pytest

from db_test_helpers.core import Config, set_db_data

from db_test_helpers.tavern._config import _parse_variables, _resolve_adapter, _resolve_path


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line("markers", "db_seed: Seed database before test")
    _patch_tavern_marks_schema()


def _patch_tavern_marks_schema() -> None:
    """Extend Tavern's JSON schema to accept db_seed marks."""
    try:
        import os

        import tavern._core.schema as schema_mod
        from tavern._core.schema.files import load_schema_file

        schema_dir = os.path.dirname(os.path.abspath(schema_mod.__file__))
        schema_filename = os.path.join(schema_dir, "tests.jsonschema.yaml")
        schema = load_schema_file(schema_filename, with_plugins=False)

        marks_items = schema["properties"]["marks"]["items"]
        for option in marks_items["anyOf"]:
            if isinstance(option, dict) and option.get("type") == "object":
                option["properties"]["db_seed"] = {
                    "type": "array",
                    "items": {"type": "object"},
                }
                break
    except ImportError:
        pass
    except Exception as e:
        import warnings

        warnings.warn(f"Failed to patch Tavern marks schema for db_seed: {e}", stacklevel=2)


def _handle_db_seed(request: pytest.FixtureRequest) -> None:
    marker = request.node.get_closest_marker("db_seed")
    if marker is None:
        return

    if not marker.args:
        raise ValueError("db_seed marker requires a list of seed entries as argument")

    items = marker.args[0]
    if not isinstance(items, list):
        raise ValueError("db_seed marker argument must be a list")
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("Each db_seed entry must be a dict")
        adapter_name = item.get("adapter")
        files = item.get("files")
        variables_str = item.get("variables")

        if files is None:
            raise ValueError("Each db_seed entry must have a 'files' key")
        if not isinstance(files, list):
            raise TypeError("files must be a list")
        if len(files) != 1:
            raise ValueError("Currently only exactly 1 file per entry is supported")

        adapter = _resolve_adapter(adapter_name)
        parsed_vars = _parse_variables(variables_str)
        resolved_path = _resolve_path(files[0])
        set_db_data(adapter, resolved_path, Config(variables=parsed_vars))


@pytest.fixture
def _db_configure():
    """Override in conftest.py to configure the adapter before db_seed."""
    pass


@pytest.fixture(autouse=True)
def _db_seed_handler(request: pytest.FixtureRequest, _db_configure: None) -> None:
    _handle_db_seed(request)
