"""Tests for _config module."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from db_test_helpers.tavern._config import (
    _parse_variables,
    _reset,
    _resolve_adapter,
    _resolve_path,
    configure,
)


def _make_adapter() -> MagicMock:
    return MagicMock()


@pytest.fixture(autouse=True)
def _cleanup():
    _reset()
    yield
    _reset()


class TestConfigure:
    def test_single_adapter(self):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path="/tmp")
        assert _resolve_adapter(None) is adapter

    def test_multiple_adapters(self):
        a = _make_adapter()
        b = _make_adapter()
        configure(adapters={"a": a, "b": b}, base_path="/tmp")
        assert _resolve_adapter("a") is a
        assert _resolve_adapter("b") is b

    def test_both_adapter_and_adapters_raises(self):
        with pytest.raises(ValueError, match="Cannot specify both"):
            configure(adapter=_make_adapter(), adapters={"a": _make_adapter()})

    def test_neither_adapter_nor_adapters_raises(self):
        with pytest.raises(ValueError, match="Must specify either"):
            configure()

    def test_called_twice_raises(self):
        configure(adapter=_make_adapter())
        with pytest.raises(RuntimeError, match="already been called"):
            configure(adapter=_make_adapter())


class TestResolveAdapter:
    def test_single_name_omitted(self):
        adapter = _make_adapter()
        configure(adapter=adapter)
        assert _resolve_adapter(None) is adapter

    def test_single_name_given_raises(self):
        configure(adapter=_make_adapter())
        with pytest.raises(ValueError, match="single adapter.*does not accept"):
            _resolve_adapter("anything")

    def test_multiple_name_required(self):
        a = _make_adapter()
        b = _make_adapter()
        configure(adapters={"a": a, "b": b})
        assert _resolve_adapter("a") is a

    def test_multiple_name_omitted_raises(self):
        configure(adapters={"a": _make_adapter(), "b": _make_adapter()})
        with pytest.raises(ValueError, match="must specify adapter name"):
            _resolve_adapter(None)

    def test_unknown_name_raises(self):
        configure(adapters={"a": _make_adapter()})
        with pytest.raises(ValueError, match="Unknown adapter"):
            _resolve_adapter("unknown")

    def test_not_configured_raises(self):
        with pytest.raises(RuntimeError, match="configure"):
            _resolve_adapter(None)


class TestResolvePath:
    def test_normal(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        result = _resolve_path("seed/users.yaml")
        assert result == tmp_path / "seed" / "users.yaml"

    def test_absolute_path_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(ValueError, match="must be relative"):
            _resolve_path("/absolute/path.yaml")

    def test_traversal_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        with pytest.raises(ValueError, match="outside base_path"):
            _resolve_path("../../../etc/passwd")

    def test_symlink_traversal_raises(self, tmp_path: Path):
        # Create a symlink that points outside base_path
        inner = tmp_path / "inner"
        inner.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        target = outside / "secret.yaml"
        target.touch()

        link = inner / "link.yaml"
        link.symlink_to(target)

        configure(adapter=_make_adapter(), base_path=inner)
        with pytest.raises(ValueError, match="outside base_path"):
            _resolve_path("link.yaml")

    def test_default_base_path(self):
        configure(adapter=_make_adapter())
        result = _resolve_path("seed/users.yaml")
        assert result == Path.cwd() / "seed" / "users.yaml"


class TestParseVariables:
    def test_none_returns_empty(self):
        assert _parse_variables(None) == {}

    def test_valid_json(self):
        result = _parse_variables('{"uid": "test-123", "count": 42}')
        assert result == {"uid": "test-123", "count": 42}

    def test_invalid_json_raises(self):
        with pytest.raises(ValueError, match="Invalid JSON"):
            _parse_variables("not json")

    def test_non_dict_raises(self):
        with pytest.raises(ValueError, match="must be a JSON object"):
            _parse_variables("[1, 2, 3]")

    def test_dict_passthrough(self):
        d = {"uid": "test-123", "count": 42}
        assert _parse_variables(d) == d

    def test_non_str_non_dict_raises(self):
        with pytest.raises(ValueError, match="must be a dict, str, or None"):
            _parse_variables(123)
