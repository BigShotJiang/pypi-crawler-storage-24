"""Tavern external functions: verify_db, setup_db."""

from __future__ import annotations

from typing import Any

from db_test_helpers.core import Config, set_db_data, verify_db_data

from db_test_helpers.tavern._config import _parse_variables, _resolve_adapter, _resolve_path


def verify_db(
    response: Any,
    *,
    files: list[str],
    adapter: str | None = None,
    variables: dict[str, object] | str | None = None,
) -> None:
    if not isinstance(files, list):
        raise TypeError("files must be a list")
    if len(files) != 1:
        raise ValueError("Currently only exactly 1 file per entry is supported")

    resolved_adapter = _resolve_adapter(adapter)
    resolved_path = _resolve_path(files[0])
    parsed_vars = _parse_variables(variables)
    verify_db_data(resolved_adapter, resolved_path, Config(variables=parsed_vars))


def setup_db(
    response: Any,
    *,
    files: list[str],
    adapter: str | None = None,
    variables: dict[str, object] | str | None = None,
) -> None:
    if not isinstance(files, list):
        raise TypeError("files must be a list")
    if len(files) != 1:
        raise ValueError("Currently only exactly 1 file per entry is supported")

    resolved_adapter = _resolve_adapter(adapter)
    resolved_path = _resolve_path(files[0])
    parsed_vars = _parse_variables(variables)
    set_db_data(resolved_adapter, resolved_path, Config(variables=parsed_vars))
