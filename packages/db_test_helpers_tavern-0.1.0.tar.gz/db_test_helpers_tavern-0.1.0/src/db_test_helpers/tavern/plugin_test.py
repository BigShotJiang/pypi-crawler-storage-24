"""Tests for pytest plugin (db_seed marker)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from db_test_helpers.tavern._config import _reset, configure
from db_test_helpers.tavern.plugin import _handle_db_seed


def _make_adapter() -> MagicMock:
    return MagicMock()


def _make_request(marker_args=None):
    """Create a mock pytest request with optional db_seed marker."""
    request = MagicMock()
    if marker_args is None:
        request.node.get_closest_marker.return_value = None
    else:
        marker = MagicMock()
        marker.args = (marker_args,)
        request.node.get_closest_marker.return_value = marker
    return request


@pytest.fixture(autouse=True)
def _cleanup():
    _reset()
    yield
    _reset()


class TestDbSeedHandler:
    def test_no_marker_does_nothing(self):
        request = _make_request(marker_args=None)
        with patch("db_test_helpers.tavern.plugin.set_db_data") as mock_set:
            _handle_db_seed(request)
            mock_set.assert_not_called()

    def test_single_file(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)
        (tmp_path / "seed.yaml").write_text("x:\n  - a: 1\n")

        request = _make_request([{"files": ["seed.yaml"]}])

        with patch("db_test_helpers.tavern.plugin.set_db_data") as mock_set:
            _handle_db_seed(request)
            mock_set.assert_called_once()
            call_args = mock_set.call_args
            assert call_args[0][0] is adapter
            assert call_args[0][1] == tmp_path / "seed.yaml"

    def test_multiple_files_raises(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)

        request = _make_request([{"files": ["a.yaml", "b.yaml"]}])

        with pytest.raises(ValueError, match="only exactly 1 file"):
            _handle_db_seed(request)

    def test_with_adapter_name(self, tmp_path: Path):
        a = _make_adapter()
        b = _make_adapter()
        configure(adapters={"a": a, "b": b}, base_path=tmp_path)
        (tmp_path / "seed.yaml").write_text("x:\n  - a: 1\n")

        request = _make_request([{"adapter": "b", "files": ["seed.yaml"]}])

        with patch("db_test_helpers.tavern.plugin.set_db_data") as mock_set:
            _handle_db_seed(request)
            assert mock_set.call_args[0][0] is b

    def test_without_adapter_name_single(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)
        (tmp_path / "seed.yaml").write_text("x:\n  - a: 1\n")

        request = _make_request([{"files": ["seed.yaml"]}])

        with patch("db_test_helpers.tavern.plugin.set_db_data") as mock_set:
            _handle_db_seed(request)
            assert mock_set.call_args[0][0] is adapter

    def test_with_variables(self, tmp_path: Path):
        adapter = _make_adapter()
        configure(adapter=adapter, base_path=tmp_path)
        (tmp_path / "seed.yaml").write_text("x:\n  - a: 1\n")

        request = _make_request([{"files": ["seed.yaml"], "variables": '{"uid": "123"}'}])

        with patch("db_test_helpers.tavern.plugin.set_db_data") as mock_set:
            _handle_db_seed(request)
            config = mock_set.call_args[0][2]
            assert config.variables == {"uid": "123"}

    def test_multiple_entries(self, tmp_path: Path):
        a = _make_adapter()
        b = _make_adapter()
        configure(adapters={"a": a, "b": b}, base_path=tmp_path)
        (tmp_path / "s1.yaml").write_text("x:\n  - a: 1\n")
        (tmp_path / "s2.yaml").write_text("x:\n  - a: 1\n")

        request = _make_request([
            {"adapter": "a", "files": ["s1.yaml"]},
            {"adapter": "b", "files": ["s2.yaml"]},
        ])

        with patch("db_test_helpers.tavern.plugin.set_db_data") as mock_set:
            _handle_db_seed(request)
            assert mock_set.call_count == 2
            assert mock_set.call_args_list[0][0][0] is a
            assert mock_set.call_args_list[1][0][0] is b

    def test_not_configured_raises(self):
        request = _make_request([{"files": ["seed.yaml"]}])
        with pytest.raises(RuntimeError, match="configure"):
            _handle_db_seed(request)

    def test_empty_marker_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        request = MagicMock()
        marker = MagicMock()
        marker.args = ()
        request.node.get_closest_marker.return_value = marker
        with pytest.raises(ValueError, match="requires a list of seed entries"):
            _handle_db_seed(request)

    def test_missing_files_key_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        request = _make_request([{"adapter": "default"}])
        with pytest.raises(ValueError, match="must have a 'files' key"):
            _handle_db_seed(request)

    def test_empty_files_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        request = _make_request([{"files": []}])
        with pytest.raises(ValueError, match="only exactly 1 file"):
            _handle_db_seed(request)

    def test_files_not_list_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        request = _make_request([{"files": "single.yaml"}])
        with pytest.raises(TypeError, match="files must be a list"):
            _handle_db_seed(request)

    def test_non_list_items_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        request = _make_request("not a list")
        with pytest.raises(ValueError, match="must be a list"):
            _handle_db_seed(request)

    def test_non_dict_entry_raises(self, tmp_path: Path):
        configure(adapter=_make_adapter(), base_path=tmp_path)
        request = _make_request(["not a dict"])
        with pytest.raises(ValueError, match="must be a dict"):
            _handle_db_seed(request)
