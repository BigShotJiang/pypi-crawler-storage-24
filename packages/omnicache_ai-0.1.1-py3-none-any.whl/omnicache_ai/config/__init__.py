"""Configuration for omnicache-ai."""
