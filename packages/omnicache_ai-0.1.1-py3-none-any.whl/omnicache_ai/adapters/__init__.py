"""Framework-specific adapters."""
