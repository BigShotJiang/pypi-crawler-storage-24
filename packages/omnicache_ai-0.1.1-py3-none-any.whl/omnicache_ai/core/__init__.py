"""Core cache engine."""
