# reposeek

Quickly open local repositories in VS Code.

## Usage

### Search and open a repo

```bash
# Search by partial name and open in VS Code
reposeek search auth

# Shortcut (assumes search)
reposeek auth
```

### List all Git repos on Desktop

```bash
reposeek list
```

### Show help

```bash
reposeek help
```

