from pathlib import Path
import subprocess
import sys

SEARCH_ROOT = Path.home() / "Desktop"


def find_git_repos():
    """
    Recursively find all git repositories under SEARCH_ROOT.
    Returns a list of Path objects.
    """
    if not SEARCH_ROOT.exists():
        sys.exit(f"Search root does not exist: {SEARCH_ROOT}")

    repos = []

    for path in SEARCH_ROOT.rglob("*"):
        if path.is_dir() and (path / ".git").exists():
            repos.append(path)

    return sorted(repos)


def search_and_open(query: str):
    """
    Search for matching git repositories by name and open in VS Code.
    """
    repos = find_git_repos()

    # Filter by query (case-insensitive substring match)
    matches = [r for r in repos if query.lower() in r.name.lower()]

    if not matches:
        sys.exit(f"No git repositories found matching '{query}'")

    # One match → open immediately
    if len(matches) == 1:
        subprocess.run(["code", str(matches[0])])
        return

    # Multiple matches → prompt user
    print("\nMultiple matches found:\n")
    for i, repo in enumerate(matches, start=1):
        print(f"{i}. {repo.name}")  # Display only folder name

    choice = input("\nSelect a repo number: ").strip()
    try:
        index = int(choice) - 1
        selected = matches[index]
    except (ValueError, IndexError):
        sys.exit("Invalid selection.")

    subprocess.run(["code", str(selected)])


def list_git_repos():
    """
    List all git repositories recursively under SEARCH_ROOT.
    Only shows folder names.
    """
    repos = find_git_repos()

    if not repos:
        print(f"No git repositories found under {SEARCH_ROOT}")
        return

    print(f"Git repositories under {SEARCH_ROOT}:\n")
    for repo in repos:
        print(f"  {repo.name}")  # Display only folder name
