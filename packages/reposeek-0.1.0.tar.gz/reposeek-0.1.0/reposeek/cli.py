import sys
from .search import search_and_open, list_git_repos


def show_help():
    help_text = """
Usage: reposeek <command> [arguments]

Commands:
  help             Show this help message
  list             List all git repositories located within your Desktop folder
  search <query>   Search and open git repositories located within your Desktop folder

"""
    print(help_text)


def main():
    if len(sys.argv) < 2:
        show_help()
        sys.exit(0)

    cmd = sys.argv[1].lower()

    if cmd == "list":
        list_git_repos()

    elif cmd == "help":
        show_help()
    else:
        query = " ".join(sys.argv[1:])
        search_and_open(query)


if __name__ == "__main__":
    main()
