from . import api as api
from .const import CONFIG_FLOW_MINOR_VERSION as CONFIG_FLOW_MINOR_VERSION, CONFIG_FLOW_VERSION as CONFIG_FLOW_VERSION, DOMAIN as DOMAIN
from .coordinator import AladdinConnectConfigEntry as AladdinConnectConfigEntry, AladdinConnectCoordinator as AladdinConnectCoordinator
from homeassistant.const import Platform as Platform
from homeassistant.core import HomeAssistant as HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed as ConfigEntryAuthFailed, ConfigEntryNotReady as ConfigEntryNotReady
from homeassistant.helpers import aiohttp_client as aiohttp_client, config_entry_oauth2_flow as config_entry_oauth2_flow

PLATFORMS: list[Platform]

async def async_setup_entry(hass: HomeAssistant, entry: AladdinConnectConfigEntry) -> bool: ...
async def async_unload_entry(hass: HomeAssistant, entry: AladdinConnectConfigEntry) -> bool: ...
async def async_migrate_entry(hass: HomeAssistant, config_entry: AladdinConnectConfigEntry) -> bool: ...
def remove_stale_devices(hass: HomeAssistant, config_entry: AladdinConnectConfigEntry) -> None: ...
