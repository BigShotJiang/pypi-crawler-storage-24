# Lunar SDK - Evaluations Module Design

## Pesquisa de Referência

### SDKs Analisados

| SDK | Pattern Principal | Destaque |
|-----|------------------|----------|
| **Braintrust** | `Eval(data, task, scores)` | Scorers modulares, autoevals library |
| **Phoenix (Arize)** | `evaluate_dataframe()` + `log_span_annotations()` | Templates LLM-as-judge, batch processing |
| **Humanloop** | `evaluations.run(name, file, evaluators, dataset)` | Status tracking, callable evaluators |
| **LangSmith** | Evaluators retornam `{key, score, comment}` | Offline/online evaluations |
| **Galileo** | Luna EFMs + custom metrics | Output types (boolean, categorical, discrete, percentage), chain-of-thought |

### Padrões Identificados

1. **Evaluators como Callables**: Todos permitem funções Python como evaluators
2. **LLM-as-Judge**: Template-based prompts com classificação
3. **Batch Execution**: Processar múltiplos exemplos de uma vez
4. **Result Logging**: Persistência de resultados para análise posterior
5. **Status Tracking**: Acompanhamento de progresso em avaliações longas

---

## Requisitos do Usuário

### Métricas
- **Default metrics**: Métricas pré-definidas (exactMatch, contains, regex, etc.)
- **Custom Python scripts**: Funções Python com dependências customizadas
- **LLM-as-Judge**: Prompts configuráveis com modelos personalizados

### Execução
- **Batch evaluations**: Executar em lotes de datapoints
- **evaluation_id**: Identificador único para cada avaliação
- **Status tracking**: `pending` | `running` | `completed` | `failed`
- **Polling/Callbacks**: Mecanismos para acompanhar progresso

### Datasets
- **Log datasets**: Registrar datasets na plataforma
- **Log outputs**: Registrar saídas do modelo
- **Log results**: Registrar resultados das métricas
- **Console visibility**: Visualização automática no Console Lunar

### Autenticação
- **API Key** OU **JWT** (mutuamente exclusivos)
- Suporte a ambos métodos no mesmo SDK

---

## API Design

### Uso Básico

```python
from lunar import Lunar
from lunar.evals import Eval, exactMatch, llmJudge

client = Lunar(api_key="pk_live_xxx")

# Avaliação simples com métricas default
result = client.evals.run(
    name="QA Accuracy Test",
    dataset=[
        {"input": "What is 2+2?", "expected": "4"},
        {"input": "Capital of France?", "expected": "Paris"},
    ],
    task=lambda input: client.chat.completions.create(
        model="claude-3-5-haiku",
        messages=[{"role": "user", "content": input}]
    ).choices[0].message.content,
    scorers=[exactMatch],
)

print(f"Evaluation ID: {result.id}")
print(f"Status: {result.status}")
print(f"Score: {result.summary.mean_score}")
```

### LLM-as-Judge

```python
from lunar.evals import llmJudge

# LLM-as-Judge com prompt customizado
helpfulness_judge = llmJudge(
    name="helpfulness",
    prompt="""
    Rate the helpfulness of the response on a scale of 1-5.

    User Question: {input}
    Response: {output}

    Return ONLY a number from 1 to 5.
    """,
    model="claude-3-5-haiku",  # Modelo para avaliação
    output_type="discrete",    # 1-5
    range=(1, 5),
)

result = client.evals.run(
    name="Helpfulness Evaluation",
    dataset=my_dataset,
    task=my_task,
    scorers=[helpfulness_judge],
)
```

### Custom Python Scorer

```python
from lunar.evals import Scorer

# Scorer customizado
@Scorer
def json_valid(output: str, expected: str = None) -> float:
    """Check if output is valid JSON."""
    import json
    try:
        json.loads(output)
        return 1.0
    except:
        return 0.0

# Scorer com dependências externas
@Scorer(requirements=["rouge-score>=0.1.0"])
def rouge_l(output: str, expected: str) -> float:
    """Calculate ROUGE-L score."""
    from rouge_score import rouge_scorer
    scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
    scores = scorer.score(expected, output)
    return scores['rougeL'].fmeasure

result = client.evals.run(
    name="JSON and ROUGE Evaluation",
    dataset=my_dataset,
    task=my_task,
    scorers=[json_valid, rouge_l],
)
```

### Async Evaluation com Status Tracking

```python
from lunar import AsyncLunar

async with AsyncLunar() as client:
    # Iniciar avaliação assíncrona
    evaluation = await client.evals.create(
        name="Large Scale Evaluation",
        dataset_id="ds_abc123",  # Dataset previamente registrado
        task_config={
            "model": "claude-3-5-haiku",
            "system_prompt": "You are a helpful assistant.",
        },
        scorers=["exactMatch", "llm_judge:helpfulness"],
    )

    print(f"Started evaluation: {evaluation.id}")

    # Polling para status
    while evaluation.status in ["pending", "running"]:
        await asyncio.sleep(5)
        evaluation = await client.evals.get(evaluation.id)
        print(f"Progress: {evaluation.progress.completed}/{evaluation.progress.total}")

    # Ou usar callback
    result = await client.evals.wait(
        evaluation.id,
        on_progress=lambda p: print(f"Progress: {p.completed}/{p.total}")
    )
```

### Dataset Management

```python
# Criar dataset
dataset = client.datasets.create(
    name="QA Test Set v1",
    datapoints=[
        {"input": "...", "expected": "...", "metadata": {...}},
        {"input": "...", "expected": "..."},
    ],
)

# Listar datasets
datasets = client.datasets.list()

# Usar dataset em avaliação
result = client.evals.run(
    name="My Evaluation",
    dataset_id=dataset.id,  # Referência ao dataset
    task=my_task,
    scorers=[exactMatch],
)
```

### Autenticação Dual (API Key ou JWT)

```python
# Via API Key (padrão)
client = Lunar(api_key="pk_live_xxx")

# Via JWT (para integrações OAuth/Cognito)
client = Lunar(jwt="eyJhbGciOiJIUzI1NiIs...")

# A autenticação é mutuamente exclusiva
# Se ambos forem fornecidos, lança erro
```

---

## Estrutura de Arquivos

```
lunar/
├── evals/
│   ├── __init__.py           # Exports: Eval, Scorer, llmJudge, default scorers
│   ├── _base.py              # Classes base: BaseScorer, BaseEvaluator
│   ├── _runner.py            # EvaluationRunner: execução local/remota
│   ├── scorers/
│   │   ├── __init__.py       # Export all scorers
│   │   ├── default.py        # exactMatch, contains, regex, jsonValid, etc.
│   │   ├── llm_judge.py      # llmJudge factory function
│   │   └── custom.py         # @Scorer decorator para custom scorers
│   ├── types.py              # EvaluationResult, DataPoint, ScorerResult, etc.
│   └── _api.py               # API client para endpoints /v1/evaluations
├── resources/
│   ├── evaluations.py        # Evaluations resource (client.evals)
│   └── datasets.py           # Datasets resource (client.datasets)
└── types/
    └── evaluations.py        # Type definitions para evaluations
```

---

## Types

### DataPoint

```python
class DataPoint(BaseModel):
    """Single evaluation data point."""
    input: Union[str, Dict[str, Any]]      # Input para o task
    expected: Optional[str] = None          # Output esperado (para comparação)
    metadata: Optional[Dict[str, Any]] = None
```

### ScorerResult

```python
class ScorerResult(BaseModel):
    """Result from a single scorer."""
    name: str                               # Nome do scorer
    score: float                            # Score (0.0 - 1.0 normalizado)
    raw_value: Optional[Any] = None         # Valor original (se não normalizado)
    explanation: Optional[str] = None       # Explicação (LLM-as-Judge)
    latency_ms: Optional[float] = None      # Tempo de execução
```

### EvaluationRow

```python
class EvaluationRow(BaseModel):
    """Single row in evaluation results."""
    datapoint_id: str
    input: Union[str, Dict[str, Any]]
    output: str
    expected: Optional[str] = None
    scores: List[ScorerResult]
    error: Optional[str] = None             # Se o task falhou
```

### EvaluationProgress

```python
class EvaluationProgress(BaseModel):
    """Progress of an evaluation."""
    total: int
    completed: int
    failed: int
    percentage: float
```

### EvaluationSummary

```python
class EvaluationSummary(BaseModel):
    """Summary statistics for an evaluation."""
    total_rows: int
    successful_rows: int
    failed_rows: int
    scores: Dict[str, ScorerSummary]  # Por scorer

class ScorerSummary(BaseModel):
    """Summary for a single scorer."""
    name: str
    mean: float
    median: float
    min: float
    max: float
    std_dev: float
```

### EvaluationResult

```python
class EvaluationStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"

class EvaluationResult(BaseModel):
    """Complete evaluation result."""
    id: str                                 # evaluation_xxx
    name: str
    status: EvaluationStatus
    created_at: datetime
    completed_at: Optional[datetime] = None
    progress: EvaluationProgress
    summary: Optional[EvaluationSummary] = None
    rows: Optional[List[EvaluationRow]] = None
    error: Optional[str] = None             # Se failed

    # Metadata
    dataset_id: Optional[str] = None
    scorer_names: List[str]
    config: Dict[str, Any]
```

---

## Default Scorers

```python
# lunar/evals/scorers/default.py

def exactMatch(output: str, expected: str) -> float:
    """Exact string match (case-sensitive)."""
    return 1.0 if output.strip() == expected.strip() else 0.0

def exactMatchIgnoreCase(output: str, expected: str) -> float:
    """Exact string match (case-insensitive)."""
    return 1.0 if output.strip().lower() == expected.strip().lower() else 0.0

def contains(output: str, expected: str) -> float:
    """Check if expected is contained in output."""
    return 1.0 if expected.strip() in output else 0.0

def regex(pattern: str):
    """Factory for regex matcher."""
    import re
    compiled = re.compile(pattern)
    def _regex(output: str, expected: str = None) -> float:
        return 1.0 if compiled.search(output) else 0.0
    _regex.__name__ = f"regex:{pattern[:20]}"
    return _regex

def jsonValid(output: str, expected: str = None) -> float:
    """Check if output is valid JSON."""
    import json
    try:
        json.loads(output)
        return 1.0
    except:
        return 0.0

def lengthInRange(min_len: int, max_len: int):
    """Factory for length range checker."""
    def _length(output: str, expected: str = None) -> float:
        length = len(output)
        return 1.0 if min_len <= length <= max_len else 0.0
    _length.__name__ = f"lengthInRange:{min_len}-{max_len}"
    return _length
```

---

## LLM-as-Judge Implementation

```python
# lunar/evals/scorers/llm_judge.py

from typing import Literal, Tuple, Optional

OutputType = Literal["boolean", "categorical", "discrete", "percentage"]

def llmJudge(
    name: str,
    prompt: str,
    model: str = "claude-3-5-haiku",
    output_type: OutputType = "percentage",
    categories: Optional[List[str]] = None,  # Para categorical
    range: Optional[Tuple[int, int]] = None,  # Para discrete
    chain_of_thought: bool = False,           # Adiciona reasoning
) -> "LLMJudgeScorer":
    """
    Create an LLM-as-Judge scorer.

    Args:
        name: Scorer name
        prompt: Evaluation prompt template. Variables disponíveis:
            - {input}: Input do datapoint
            - {output}: Output do task
            - {expected}: Expected output (se disponível)
        model: Model to use for judging
        output_type: Type of output expected:
            - boolean: true/false
            - categorical: one of predefined categories
            - discrete: integer in range
            - percentage: 0.0 to 1.0
        categories: List of valid categories (for categorical)
        range: (min, max) tuple (for discrete)
        chain_of_thought: Enable step-by-step reasoning

    Example:
        >>> helpfulness = llmJudge(
        ...     name="helpfulness",
        ...     prompt="Rate helpfulness 1-5: {output}",
        ...     output_type="discrete",
        ...     range=(1, 5),
        ... )
    """
    return LLMJudgeScorer(
        name=name,
        prompt=prompt,
        model=model,
        output_type=output_type,
        categories=categories,
        range=range,
        chain_of_thought=chain_of_thought,
    )
```

### System Prompt para LLM Judge

```python
JUDGE_SYSTEM_PROMPTS = {
    "boolean": """You are an evaluation judge. Respond with ONLY "true" or "false".""",

    "categorical": """You are an evaluation judge. Respond with ONLY one of these categories: {categories}.""",

    "discrete": """You are an evaluation judge. Respond with ONLY a single integer from {min} to {max}.""",

    "percentage": """You are an evaluation judge. Respond with ONLY a decimal number from 0.0 to 1.0.""",
}

JUDGE_COT_SUFFIX = """
Think step by step before giving your final answer.
Format your response as:
<reasoning>Your reasoning here</reasoning>
<answer>Your final answer here</answer>
"""
```

---

## API Endpoints (Backend)

### Endpoints Necessários

```
POST   /v1/evaluations              # Criar/executar avaliação
GET    /v1/evaluations              # Listar avaliações
GET    /v1/evaluations/{id}         # Status/resultado de avaliação
DELETE /v1/evaluations/{id}         # Cancelar/deletar avaliação

POST   /v1/datasets                 # Criar dataset
GET    /v1/datasets                 # Listar datasets
GET    /v1/datasets/{id}            # Obter dataset
DELETE /v1/datasets/{id}            # Deletar dataset

POST   /v1/evaluations/{id}/logs    # Log de resultados (para execução local)
```

### Request: Criar Avaliação

```json
POST /v1/evaluations
{
    "name": "QA Accuracy Test",
    "dataset_id": "ds_abc123",           // OU inline dataset
    "dataset": [                          // Inline dataset
        {"input": "...", "expected": "..."}
    ],
    "task_config": {
        "model": "claude-3-5-haiku",
        "system_prompt": "You are helpful.",
        "temperature": 0.0
    },
    "scorers": [
        "exactMatch",
        {"type": "llm_judge", "name": "helpfulness", "prompt": "...", "model": "..."}
    ],
    "execution_mode": "remote"           // "remote" | "local"
}
```

### Response: Evaluation Result

```json
{
    "id": "eval_abc123",
    "name": "QA Accuracy Test",
    "status": "completed",
    "created_at": "2025-01-15T10:30:00Z",
    "completed_at": "2025-01-15T10:35:00Z",
    "progress": {
        "total": 100,
        "completed": 100,
        "failed": 2,
        "percentage": 100.0
    },
    "summary": {
        "total_rows": 100,
        "successful_rows": 98,
        "failed_rows": 2,
        "scores": {
            "exactMatch": {
                "mean": 0.85,
                "median": 1.0,
                "min": 0.0,
                "max": 1.0,
                "std_dev": 0.35
            },
            "helpfulness": {
                "mean": 4.2,
                "median": 4.0,
                "min": 2.0,
                "max": 5.0,
                "std_dev": 0.8
            }
        }
    },
    "rows": [...]  // Opcional, pode ser paginado
}
```

---

## Autenticação Dual

```python
# lunar/_config.py

class LunarConfig:
    def __init__(
        self,
        api_key: Optional[str] = None,
        jwt: Optional[str] = None,
        ...
    ):
        if api_key and jwt:
            raise ValueError("Cannot use both api_key and jwt. Choose one.")

        if not api_key and not jwt:
            # Tentar env vars
            api_key = os.environ.get("LUNAR_API_KEY")
            jwt = os.environ.get("LUNAR_JWT")

        if not api_key and not jwt:
            raise AuthenticationError(
                "Authentication required. Provide api_key, jwt, "
                "or set LUNAR_API_KEY/LUNAR_JWT environment variable."
            )

        self.api_key = api_key
        self.jwt = jwt

    @property
    def headers(self) -> Dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "lunar-python/0.1.0",
        }

        if self.api_key:
            headers["x-api-key"] = self.api_key
        elif self.jwt:
            headers["Authorization"] = f"Bearer {self.jwt}"

        return headers
```

---

## Execução Local vs Remota

### Execução Local (Default)
- Task é executado localmente pelo SDK
- Resultados são enviados para a API para logging
- Útil para desenvolvimento e debugging
- Suporta custom scorers com dependências arbitrárias

### Execução Remota
- Task é executado pelo backend Lunar
- Requer `task_config` ao invés de `task` callable
- Útil para avaliações em escala
- Limitado a scorers pré-registrados

```python
# Local execution (default)
result = client.evals.run(
    name="My Eval",
    dataset=my_dataset,
    task=my_task_function,  # Executa localmente
    scorers=[exactMatch, my_custom_scorer],
)

# Remote execution
result = client.evals.run(
    name="My Eval",
    dataset_id="ds_abc123",
    task_config={  # Backend executa
        "model": "claude-3-5-haiku",
        "system_prompt": "...",
    },
    scorers=["exactMatch", "helpfulness"],  # Scorers registrados
    execution_mode="remote",
)
```

---

## Ordem de Implementação

### Fase 1: Core Types e Scorers
1. `lunar/evals/types.py` - DataPoint, ScorerResult, EvaluationResult
2. `lunar/evals/scorers/default.py` - exactMatch, contains, jsonValid, etc.
3. `lunar/evals/_base.py` - BaseScorer, @Scorer decorator

### Fase 2: LLM-as-Judge
4. `lunar/evals/scorers/llm_judge.py` - llmJudge factory
5. Integração com client.chat para executar LLM judges

### Fase 3: Runner e Resources
6. `lunar/evals/_runner.py` - EvaluationRunner (execução local)
7. `lunar/resources/evaluations.py` - client.evals resource
8. `lunar/resources/datasets.py` - client.datasets resource

### Fase 4: API Integration
9. `lunar/evals/_api.py` - Chamadas para /v1/evaluations
10. Autenticação dual (API Key / JWT)

### Fase 5: Async e Status Tracking
11. AsyncEvaluations resource
12. Polling e callbacks para status

---

## Dependências Adicionais

```toml
[project.optional-dependencies]
evals = [
    "tqdm>=4.0",           # Progress bars
    "pandas>=2.0",         # DataFrame support
    "numpy>=1.24",         # Statistics
]
```

---

## Fontes da Pesquisa

- [Braintrust Evaluation Quickstart](https://www.braintrust.dev/docs/evaluation)
- [Braintrust Scorers](https://www.braintrust.dev/docs/guides/functions/scorers)
- [Phoenix Python Quickstart](https://arize.com/docs/phoenix/evaluation/python-quickstart)
- [Humanloop Run Evaluation](https://humanloop.com/docs/v5/sdk/run-evaluation)
- [LangSmith Evaluation Concepts](https://docs.langchain.com/langsmith/evaluation-concepts)
- [Galileo Custom LLM Metrics](https://v2docs.galileo.ai/concepts/metrics/custom-metrics/custom-metrics-ui-llm)
