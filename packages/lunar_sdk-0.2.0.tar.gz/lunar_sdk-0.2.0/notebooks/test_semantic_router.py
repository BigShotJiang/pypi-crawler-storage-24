"""
Test Semantic Router - Python

Tests the /v1/router endpoint for semantic model routing.
Run: LUNAR_API_KEY=pk_live_xxx python notebooks/test_semantic_router.py
"""

import os
import json
import requests

API_KEY = os.environ.get("LUNAR_API_KEY", "YOUR_API_KEY")
BASE_URL = "https://api.lunar-sys.com"

headers = {
    "Content-Type": "application/json",
    "x-api-key": API_KEY,
}


def test_router(name: str, payload: dict):
    """Send a request to /v1/router and print results."""
    print(f"\n{'='*60}")
    print(f"  TEST: {name}")
    print(f"{'='*60}")

    try:
        resp = requests.post(
            f"{BASE_URL}/v1/router",
            headers=headers,
            json=payload,
            timeout=60,
        )

        if resp.status_code != 200:
            print(f"  STATUS: {resp.status_code}")
            print(f"  ERROR: {resp.text}")
            return None

        data = resp.json()

        # Routing decision
        routing = data.get("routing", {})
        print(f"\n  Selected model:    {routing.get('selected_model')}")
        print(f"  Provider:          {routing.get('selected_provider')}")
        print(f"  Cluster ID:        {routing.get('cluster_id')}")
        print(f"  Expected error:    {routing.get('expected_error', 0):.4f}")
        print(f"  Cost-adj score:    {routing.get('cost_adjusted_score', 0):.4f}")

        # All scores
        all_scores = routing.get("all_scores", {})
        if all_scores:
            print(f"\n  Model scores:")
            for model, score in sorted(all_scores.items(), key=lambda x: x[1]):
                marker = " <-- selected" if model == routing.get("selected_model") else ""
                print(f"    {model:30s} {score:.4f}{marker}")

        # Reasoning
        if routing.get("reasoning"):
            print(f"\n  Reasoning: {routing['reasoning'][:200]}")

        # Execution result
        choices = data.get("choices", [])
        if choices:
            content = choices[0].get("message", {}).get("content", "")
            print(f"\n  Response ({len(content)} chars): {content[:150]}...")

        # Usage
        usage = data.get("usage", {})
        if usage:
            print(f"\n  Tokens: {usage.get('total_tokens', 0)} | Cost: ${usage.get('total_cost_usd', 0):.6f} | Latency: {usage.get('latency_ms', 0):.0f}ms")

        return data

    except Exception as e:
        print(f"  EXCEPTION: {e}")
        return None


def main():
    print("=" * 60)
    print("  Semantic Router Tests - Python")
    print("=" * 60)

    # Test 1: List available profiles
    print("\n--- Checking available profiles ---")
    try:
        resp = requests.get(f"{BASE_URL}/v1/router/profiles", headers=headers, timeout=10)
        if resp.status_code == 200:
            profiles = resp.json()
            print(f"  Available models: {profiles.get('count', 0)}")
            for p in profiles.get("profiles", []):
                print(f"    - {p}")
        else:
            print(f"  Status {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        print(f"  Error: {e}")

    # Test 2: Simple routing (execute=False, just see the decision)
    test_router("Route only (no execute) - Simple question", {
        "messages": [
            {"role": "user", "content": "What is 2+2?"}
        ],
        "execute": False,
    })

    # Test 3: Route + execute - Complex reasoning
    test_router("Route + Execute - Complex reasoning", {
        "messages": [
            {"role": "user", "content": "Explain the implications of Gödel's incompleteness theorems on the foundations of mathematics and its relationship to Turing's halting problem."}
        ],
        "execute": True,
        "max_tokens": 200,
    })

    # Test 4: Route + execute - Simple task
    test_router("Route + Execute - Simple task", {
        "messages": [
            {"role": "user", "content": "Say hello in French."}
        ],
        "execute": True,
        "max_tokens": 50,
    })

    # Test 5: Restricted models
    test_router("Restricted models (gpt-4o-mini, gpt-4o)", {
        "messages": [
            {"role": "user", "content": "Write a Python function to calculate fibonacci numbers."}
        ],
        "models": ["gpt-4o-mini", "gpt-4o"],
        "execute": True,
        "max_tokens": 150,
    })

    # Test 6: Cost-weighted routing
    test_router("Cost-weighted routing (prefer cheaper)", {
        "messages": [
            {"role": "user", "content": "What is the capital of France?"}
        ],
        "cost_weight": 1.0,
        "execute": False,
    })

    # Test 7: Cost-weighted vs unweighted comparison
    test_router("No cost weight - same prompt", {
        "messages": [
            {"role": "user", "content": "What is the capital of France?"}
        ],
        "cost_weight": 0.0,
        "execute": False,
    })

    print(f"\n{'='*60}")
    print("  All tests complete!")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
