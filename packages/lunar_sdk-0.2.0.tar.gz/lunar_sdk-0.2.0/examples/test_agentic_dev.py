#!/usr/bin/env python3
"""Test agentic trace features (tool use) against DEV environment.

Tests:
1. Basic chat completion (backward compat)
2. Chat completion with tools parameter
3. Tool calls response handling
4. Streaming with tool_calls
5. Multi-turn agentic flow (user -> tool_call -> tool result -> final response)

Usage:
    export LUNAR_DEV_API_KEY="your-dev-api-key"
    python examples/test_agentic_dev.py
"""

import json
import os
import sys

# Add parent dir to path so we can import local lunar
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from lunar import Lunar

API_KEY = os.environ.get("LUNAR_DEV_API_KEY", "")
if not API_KEY:
    print("Set LUNAR_DEV_API_KEY environment variable first.")
    sys.exit(1)

client = Lunar(api_key=API_KEY, environment="dev")
print(f"Connected to: {client._config.base_url}")
print()

# Weather tool definition (classic agentic example)
WEATHER_TOOL = {
    "type": "function",
    "function": {
        "name": "get_weather",
        "description": "Get the current weather for a location",
        "parameters": {
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "City name, e.g. 'San Francisco, CA'"
                },
                "unit": {
                    "type": "string",
                    "enum": ["celsius", "fahrenheit"],
                    "description": "Temperature unit"
                }
            },
            "required": ["location"]
        }
    }
}

CALCULATOR_TOOL = {
    "type": "function",
    "function": {
        "name": "calculator",
        "description": "Evaluate a math expression",
        "parameters": {
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": "Math expression to evaluate, e.g. '2 + 2'"
                }
            },
            "required": ["expression"]
        }
    }
}


def test_basic_completion():
    """Test 1: Basic chat completion (backward compat)."""
    print("=" * 60)
    print("Test 1: Basic chat completion (backward compat)")
    print("=" * 60)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Say 'hello' and nothing else."}],
        max_tokens=10,
    )

    msg = response.choices[0].message
    print(f"  Model: {response.model}")
    print(f"  Content: {msg.content}")
    print(f"  Finish reason: {response.choices[0].finish_reason}")
    print(f"  Tool calls: {msg.tool_calls}")
    if response.usage:
        print(f"  Tokens: {response.usage.prompt_tokens}in / {response.usage.completion_tokens}out")
        print(f"  Cost: ${response.usage.total_cost_usd}")
    print(f"  PASS")
    print()


def test_tools_no_trigger():
    """Test 2: Send tools but ask a question that shouldn't trigger them."""
    print("=" * 60)
    print("Test 2: Tools present, no trigger")
    print("=" * 60)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "What is 2+2? Answer directly."}],
        tools=[WEATHER_TOOL],
        max_tokens=50,
    )

    msg = response.choices[0].message
    print(f"  Content: {msg.content}")
    print(f"  Finish reason: {response.choices[0].finish_reason}")
    print(f"  Tool calls: {msg.tool_calls}")
    assert response.choices[0].finish_reason in ("stop", None), "Expected stop finish_reason"
    print(f"  PASS")
    print()


def test_tool_call_trigger():
    """Test 3: Send tools with a prompt that should trigger a tool call."""
    print("=" * 60)
    print("Test 3: Tool call trigger")
    print("=" * 60)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "What's the weather in Tokyo?"}],
        tools=[WEATHER_TOOL],
        tool_choice="auto",
    )

    msg = response.choices[0].message
    fr = response.choices[0].finish_reason
    print(f"  Content: {msg.content}")
    print(f"  Finish reason: {fr}")
    print(f"  Tool calls: {msg.tool_calls}")

    if msg.tool_calls:
        for tc in msg.tool_calls:
            print(f"    - id={tc.id}, fn={tc.function.name}, args={tc.function.arguments}")
        assert msg.tool_calls[0].function.name == "get_weather", "Expected get_weather tool call"
        print(f"  PASS - tool call triggered")
    else:
        print(f"  WARN - model didn't use tool (may happen with some models)")
    print()
    return response


def test_multi_turn_agentic():
    """Test 4: Full multi-turn agentic flow."""
    print("=" * 60)
    print("Test 4: Multi-turn agentic flow")
    print("=" * 60)

    # Step 1: User asks about weather
    print("  Step 1: User asks about weather...")
    messages = [
        {"role": "user", "content": "What's the weather like in Paris right now?"}
    ]

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages,
        tools=[WEATHER_TOOL],
        tool_choice="auto",
    )

    assistant_msg = response.choices[0].message
    print(f"    Assistant content: {assistant_msg.content}")
    print(f"    Finish reason: {response.choices[0].finish_reason}")

    if not assistant_msg.tool_calls:
        print(f"  SKIP - model didn't call tool, can't test multi-turn")
        print()
        return

    tc = assistant_msg.tool_calls[0]
    print(f"    Tool call: {tc.function.name}({tc.function.arguments})")

    # Step 2: Add assistant message with tool_calls + tool result
    print("  Step 2: Sending tool result...")

    # Build the assistant message dict with tool_calls
    assistant_dict = {"role": "assistant", "content": assistant_msg.content}
    assistant_dict["tool_calls"] = [t.model_dump() for t in assistant_msg.tool_calls]

    # Simulated tool result
    tool_result = {
        "role": "tool",
        "tool_call_id": tc.id,
        "content": json.dumps({
            "location": "Paris",
            "temperature": 18,
            "unit": "celsius",
            "condition": "Partly cloudy",
            "humidity": 65
        })
    }

    messages.append(assistant_dict)
    messages.append(tool_result)

    # Step 3: Get final response
    print("  Step 3: Getting final response...")
    response2 = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages,
        tools=[WEATHER_TOOL],
    )

    final_msg = response2.choices[0].message
    print(f"    Final content: {final_msg.content}")
    print(f"    Finish reason: {response2.choices[0].finish_reason}")
    print(f"    Tool calls: {final_msg.tool_calls}")

    assert final_msg.content, "Expected text response after tool result"
    assert response2.choices[0].finish_reason in ("stop", None), "Expected stop after tool result"
    print(f"  PASS - multi-turn agentic flow complete ({len(messages)+1} messages)")
    print()


def test_streaming_basic():
    """Test 5: Streaming without tools."""
    print("=" * 60)
    print("Test 5: Streaming (basic)")
    print("=" * 60)

    stream = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Count from 1 to 5."}],
        stream=True,
        max_tokens=50,
    )

    collected = ""
    chunk_count = 0
    print("  Chunks: ", end="")
    for chunk in stream:
        delta = chunk.choices[0].delta
        if delta.content:
            collected += delta.content
            chunk_count += 1
            print(".", end="", flush=True)

    print()
    print(f"  Total chunks: {chunk_count}")
    print(f"  Collected: {collected[:100]}...")
    assert collected, "Expected streamed content"
    print(f"  PASS")
    print()


def test_streaming_with_tools():
    """Test 6: Streaming with tool calls."""
    print("=" * 60)
    print("Test 6: Streaming with tools")
    print("=" * 60)

    stream = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "What's the weather in London?"}],
        tools=[WEATHER_TOOL],
        tool_choice="auto",
        stream=True,
    )

    collected_content = ""
    collected_tool_calls = {}
    chunk_count = 0

    for chunk in stream:
        chunk_count += 1
        delta = chunk.choices[0].delta

        if delta.content:
            collected_content += delta.content

        if delta.tool_calls:
            for tc_delta in delta.tool_calls:
                idx = tc_delta.index
                if idx not in collected_tool_calls:
                    collected_tool_calls[idx] = {
                        "id": tc_delta.id or "",
                        "type": "function",
                        "function": {"name": "", "arguments": ""}
                    }
                if tc_delta.id:
                    collected_tool_calls[idx]["id"] = tc_delta.id
                if tc_delta.function:
                    if tc_delta.function.get("name"):
                        collected_tool_calls[idx]["function"]["name"] = tc_delta.function["name"]
                    if tc_delta.function.get("arguments"):
                        collected_tool_calls[idx]["function"]["arguments"] += tc_delta.function["arguments"]

    print(f"  Total chunks: {chunk_count}")
    print(f"  Content: {collected_content or '(none)'}")
    print(f"  Tool calls assembled: {json.dumps(list(collected_tool_calls.values()), indent=2) if collected_tool_calls else '(none)'}")

    if collected_tool_calls:
        tc = list(collected_tool_calls.values())[0]
        print(f"    Function: {tc['function']['name']}")
        print(f"    Arguments: {tc['function']['arguments']}")
        print(f"  PASS - streaming tool calls captured")
    else:
        print(f"  WARN - model didn't use tool in streaming (may vary by model)")
    print()


def test_forced_tool_call():
    """Test 7: Force a specific tool call with tool_choice."""
    print("=" * 60)
    print("Test 7: Forced tool_choice")
    print("=" * 60)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Hello, how are you?"}],
        tools=[WEATHER_TOOL, CALCULATOR_TOOL],
        tool_choice={"type": "function", "function": {"name": "calculator"}},
    )

    msg = response.choices[0].message
    print(f"  Content: {msg.content}")
    print(f"  Finish reason: {response.choices[0].finish_reason}")

    if msg.tool_calls:
        for tc in msg.tool_calls:
            print(f"    Tool: {tc.function.name}({tc.function.arguments})")
        assert msg.tool_calls[0].function.name == "calculator", "Expected forced calculator call"
        print(f"  PASS - forced tool_choice worked")
    else:
        print(f"  WARN - tool_choice didn't force a call")
    print()


def test_generation_params():
    """Test 8: Generation parameters passthrough."""
    print("=" * 60)
    print("Test 8: Generation parameters")
    print("=" * 60)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Say 'test'."}],
        temperature=0.0,
        max_tokens=5,
        top_p=0.9,
        seed=42,
    )

    msg = response.choices[0].message
    print(f"  Content: {msg.content}")
    print(f"  Finish reason: {response.choices[0].finish_reason}")
    print(f"  PASS")
    print()


if __name__ == "__main__":
    tests = [
        test_basic_completion,
        test_tools_no_trigger,
        test_tool_call_trigger,
        test_multi_turn_agentic,
        test_streaming_basic,
        test_streaming_with_tools,
        test_forced_tool_call,
        test_generation_params,
    ]

    passed = 0
    failed = 0

    for test_fn in tests:
        try:
            test_fn()
            passed += 1
        except Exception as e:
            print(f"  FAIL: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
            print()

    print("=" * 60)
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)} tests")
    print("=" * 60)
