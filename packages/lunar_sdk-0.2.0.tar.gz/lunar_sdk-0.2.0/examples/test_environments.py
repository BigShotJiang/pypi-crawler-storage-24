#!/usr/bin/env python3
"""Test script to verify DEV and PROD environments work correctly."""

from lunar import Lunar, ENVIRONMENTS

# Show available environments
print("Available environments:")
for env, urls in ENVIRONMENTS.items():
    print(f"  {env}:")
    print(f"    base_url: {urls['base_url']}")
    print(f"    evals_api_url: {urls['evals_api_url']}")
print()

# Test DEV environment
print("=" * 60)
print("Testing DEV environment")
print("=" * 60)

# Replace with your DEV API key
DEV_API_KEY = "your-dev-api-key-here"

try:
    client_dev = Lunar(api_key=DEV_API_KEY, environment="dev")
    print(f"DEV client initialized")
    print(f"  Base URL: {client_dev._config.base_url}")

    # List models
    models = client_dev.models.list()
    print(f"  Models available: {len(models.data)}")
    for model in models.data[:5]:
        print(f"    - {model.id}")

    # Test chat completion
    response = client_dev.chat.completions.create(
        model="Llama-3.2-1B",  # Use a model available in DEV
        messages=[{"role": "user", "content": "Say hello in one word"}],
        max_tokens=10
    )
    print(f"  Chat response: {response.choices[0].message.content}")

except Exception as e:
    print(f"  Error: {e}")

print()

# Test PROD environment
print("=" * 60)
print("Testing PROD environment")
print("=" * 60)

# Replace with your PROD API key
PROD_API_KEY = "your-prod-api-key-here"

try:
    client_prod = Lunar(api_key=PROD_API_KEY, environment="prod")
    print(f"PROD client initialized")
    print(f"  Base URL: {client_prod._config.base_url}")

    # List models
    models = client_prod.models.list()
    print(f"  Models available: {len(models.data)}")
    for model in models.data[:5]:
        print(f"    - {model.id}")

    # Test chat completion
    response = client_prod.chat.completions.create(
        model="Llama-3.2-1B",  # Use a model available in PROD
        messages=[{"role": "user", "content": "Say hello in one word"}],
        max_tokens=10
    )
    print(f"  Chat response: {response.choices[0].message.content}")

except Exception as e:
    print(f"  Error: {e}")

print()
print("Done!")
