"""Full end-to-end evaluation pipeline test.

Runs a complete local evaluation pipeline without requiring a backend.
Tests: dataset creation -> task execution -> scoring -> results analysis.
"""

import pytest

from lunar import Lunar
from lunar.evals import (
    Scorer,
    exactMatch,
    exactMatchIgnoreCase,
    contains,
    containsIgnoreCase,
    jsonValid,
    notEmpty,
    isNumeric,
    EvaluationResult,
    EvaluationStatus,
)


@pytest.fixture
def client():
    return Lunar(api_key="test-key-not-used-for-local")


# --- Simple task functions (no LLM needed) ---

def capitalize_task(input_text):
    """Simple task: capitalize the input."""
    if isinstance(input_text, dict):
        input_text = input_text.get("text", str(input_text))
    return input_text.upper()


def echo_task(input_text):
    """Simple task: return input as-is."""
    if isinstance(input_text, dict):
        return str(input_text.get("text", input_text))
    return str(input_text)


def math_task(input_text):
    """Simple task: evaluate basic math."""
    if isinstance(input_text, dict):
        input_text = input_text.get("expression", str(input_text))
    try:
        return str(eval(input_text))  # noqa: S307
    except Exception:
        return "error"


def json_task(input_text):
    """Simple task: wrap input in JSON."""
    import json
    if isinstance(input_text, dict):
        input_text = input_text.get("text", str(input_text))
    return json.dumps({"answer": input_text})


# --- Custom scorers ---

@Scorer
def length_check(output: str, expected: str = None) -> float:
    """Score 1.0 if output length matches expected length."""
    if expected is None:
        return 1.0 if len(output) > 0 else 0.0
    return 1.0 if len(output) == len(expected) else 0.0


@Scorer
def has_uppercase(output: str, expected: str = None) -> float:
    """Score 1.0 if output has any uppercase letters."""
    return 1.0 if any(c.isupper() for c in output) else 0.0


class TestFullEvalPipeline:
    """End-to-end evaluation pipeline tests."""

    def test_exact_match_pipeline(self, client):
        """Test pipeline: echo task with exact match scorer."""
        dataset = [
            {"input": "Hello", "expected": "Hello"},
            {"input": "World", "expected": "World"},
            {"input": "Test", "expected": "Test"},
        ]

        result = client.evals.run(
            name="Exact Match Pipeline",
            dataset=dataset,
            task=echo_task,
            scorers=[exactMatch],
            log_to_api=False,
            show_progress=False,
        )

        assert isinstance(result, EvaluationResult)
        assert result.status == EvaluationStatus.COMPLETED
        assert result.progress.total == 3
        assert result.progress.completed == 3
        assert result.progress.failed == 0
        assert result.summary is not None
        assert result.summary.total_rows == 3
        assert result.summary.successful_rows == 3
        # Echo should match exactly
        assert result.summary.scores["exactMatch"].mean == 1.0
        assert len(result.rows) == 3
        client.close()

    def test_case_insensitive_pipeline(self, client):
        """Test pipeline: capitalize task with case-insensitive scorers."""
        dataset = [
            {"input": "hello", "expected": "hello"},
            {"input": "world", "expected": "world"},
        ]

        result = client.evals.run(
            name="Case Insensitive Pipeline",
            dataset=dataset,
            task=capitalize_task,
            scorers=[exactMatch, exactMatchIgnoreCase],
            log_to_api=False,
            show_progress=False,
        )

        assert result.status == EvaluationStatus.COMPLETED
        # exactMatch should fail (HELLO != hello)
        assert result.summary.scores["exactMatch"].mean == 0.0
        # exactMatchIgnoreCase should pass
        assert result.summary.scores["exactMatchIgnoreCase"].mean == 1.0
        client.close()

    def test_contains_scorer_pipeline(self, client):
        """Test pipeline with contains scorer."""
        dataset = [
            {"input": "Say hello", "expected": "hello"},
            {"input": "Say goodbye", "expected": "goodbye"},
        ]

        def task(input_text):
            return f"I say: {input_text.lower()}"

        result = client.evals.run(
            name="Contains Pipeline",
            dataset=dataset,
            task=task,
            scorers=[contains, containsIgnoreCase],
            log_to_api=False,
            show_progress=False,
        )

        assert result.status == EvaluationStatus.COMPLETED
        # "I say: say hello" contains "hello"
        assert result.summary.scores["contains"].mean == 1.0
        client.close()

    def test_math_evaluation_pipeline(self, client):
        """Test pipeline: math task with exact match."""
        dataset = [
            {"input": "2+2", "expected": "4"},
            {"input": "3*3", "expected": "9"},
            {"input": "10-7", "expected": "3"},
            {"input": "100/4", "expected": "25.0"},
        ]

        result = client.evals.run(
            name="Math Evaluation",
            dataset=dataset,
            task=math_task,
            scorers=[exactMatch],
            log_to_api=False,
            show_progress=False,
        )

        assert result.status == EvaluationStatus.COMPLETED
        assert result.summary.total_rows == 4
        assert result.summary.successful_rows == 4
        # All should match exactly
        assert result.summary.scores["exactMatch"].mean == 1.0
        client.close()

    def test_json_valid_pipeline(self, client):
        """Test pipeline with JSON validity scorer."""
        dataset = [
            {"input": "test1"},
            {"input": "test2"},
            {"input": "test3"},
        ]

        result = client.evals.run(
            name="JSON Validity Pipeline",
            dataset=dataset,
            task=json_task,
            scorers=[jsonValid, notEmpty],
            log_to_api=False,
            show_progress=False,
        )

        assert result.status == EvaluationStatus.COMPLETED
        assert result.summary.scores["jsonValid"].mean == 1.0
        assert result.summary.scores["notEmpty"].mean == 1.0
        client.close()

    def test_custom_scorer_pipeline(self, client):
        """Test pipeline with custom scorers."""
        dataset = [
            {"input": "hello", "expected": "HELLO"},
            {"input": "world", "expected": "WORLD"},
        ]

        result = client.evals.run(
            name="Custom Scorer Pipeline",
            dataset=dataset,
            task=capitalize_task,
            scorers=[has_uppercase, length_check],
            log_to_api=False,
            show_progress=False,
        )

        assert result.status == EvaluationStatus.COMPLETED
        # capitalize output is all uppercase
        assert result.summary.scores["has_uppercase"].mean == 1.0
        # length of "HELLO" == length of "HELLO"
        assert result.summary.scores["length_check"].mean == 1.0
        client.close()

    def test_multiple_scorers_pipeline(self, client):
        """Test pipeline with many scorers at once."""
        dataset = [
            {"input": "42", "expected": "42"},
            {"input": "100", "expected": "100"},
        ]

        result = client.evals.run(
            name="Multi-Scorer Pipeline",
            dataset=dataset,
            task=echo_task,
            scorers=[exactMatch, contains, notEmpty, isNumeric],
            log_to_api=False,
            show_progress=False,
        )

        assert result.status == EvaluationStatus.COMPLETED
        assert len(result.summary.scores) == 4
        assert result.summary.scores["exactMatch"].mean == 1.0
        assert result.summary.scores["contains"].mean == 1.0
        assert result.summary.scores["notEmpty"].mean == 1.0
        assert result.summary.scores["isNumeric"].mean == 1.0
        client.close()

    def test_partial_match_pipeline(self, client):
        """Test pipeline where some datapoints match and some don't."""
        dataset = [
            {"input": "hello", "expected": "hello"},    # match
            {"input": "world", "expected": "WORLD"},    # no match (case)
            {"input": "foo", "expected": "foo"},        # match
            {"input": "bar", "expected": "baz"},        # no match (different)
        ]

        result = client.evals.run(
            name="Partial Match Pipeline",
            dataset=dataset,
            task=echo_task,
            scorers=[exactMatch],
            log_to_api=False,
            show_progress=False,
        )

        assert result.status == EvaluationStatus.COMPLETED
        assert result.summary.scores["exactMatch"].mean == 0.5  # 2/4
        assert result.summary.scores["exactMatch"].min == 0.0
        assert result.summary.scores["exactMatch"].max == 1.0
        client.close()

    def test_dict_input_pipeline(self, client):
        """Test pipeline with dict-style inputs."""
        dataset = [
            {"input": {"text": "Hello"}, "expected": "Hello"},
            {"input": {"text": "World"}, "expected": "World"},
        ]

        result = client.evals.run(
            name="Dict Input Pipeline",
            dataset=dataset,
            task=echo_task,
            scorers=[exactMatch],
            log_to_api=False,
            show_progress=False,
        )

        assert result.status == EvaluationStatus.COMPLETED
        assert result.summary.scores["exactMatch"].mean == 1.0
        client.close()

    def test_large_dataset_pipeline(self, client):
        """Test pipeline with a larger dataset (100 items)."""
        dataset = [
            {"input": str(i), "expected": str(i)} for i in range(100)
        ]

        result = client.evals.run(
            name="Large Dataset Pipeline",
            dataset=dataset,
            task=echo_task,
            scorers=[exactMatch, notEmpty],
            log_to_api=False,
            show_progress=False,
        )

        assert result.status == EvaluationStatus.COMPLETED
        assert result.progress.total == 100
        assert result.progress.completed == 100
        assert result.summary.scores["exactMatch"].mean == 1.0
        assert result.summary.scores["notEmpty"].mean == 1.0
        client.close()

    def test_result_rows_have_scores(self, client):
        """Test that individual rows have complete scoring data."""
        dataset = [
            {"input": "hello", "expected": "hello"},
            {"input": "world", "expected": "earth"},
        ]

        result = client.evals.run(
            name="Row Detail Test",
            dataset=dataset,
            task=echo_task,
            scorers=[exactMatch, contains],
            log_to_api=False,
            show_progress=False,
        )

        assert len(result.rows) == 2

        # First row: "hello" == "hello"
        row0 = next(r for r in result.rows if r.output == "hello")
        assert row0.error is None
        assert row0.latency_ms is not None
        assert len(row0.scores) == 2
        em_score = next(s for s in row0.scores if s.name == "exactMatch")
        assert em_score.score == 1.0

        # Second row: "world" != "earth"
        row1 = next(r for r in result.rows if r.output == "world")
        em_score = next(s for s in row1.scores if s.name == "exactMatch")
        assert em_score.score == 0.0
        # "world" does not contain "earth"
        contains_score = next(s for s in row1.scores if s.name == "contains")
        assert contains_score.score == 0.0
        client.close()

    def test_summary_statistics(self, client):
        """Test that summary statistics are correctly calculated."""
        dataset = [
            {"input": "a", "expected": "a"},
            {"input": "b", "expected": "b"},
            {"input": "c", "expected": "x"},
        ]

        result = client.evals.run(
            name="Summary Stats Test",
            dataset=dataset,
            task=echo_task,
            scorers=[exactMatch],
            log_to_api=False,
            show_progress=False,
        )

        stats = result.summary.scores["exactMatch"]
        assert stats.count == 3
        assert round(stats.mean, 4) == round(2/3, 4)
        assert stats.min == 0.0
        assert stats.max == 1.0
        assert stats.median == 1.0  # [0, 1, 1] -> median is 1
        assert result.summary.success_rate == 1.0  # all tasks succeeded (scoring != task success)
        client.close()

    def test_task_failure_handling(self, client):
        """Test that task failures are properly tracked."""
        call_count = 0

        def failing_task(input_text):
            nonlocal call_count
            call_count += 1
            if call_count <= 1:
                return "ok"
            raise ValueError("Simulated failure")

        dataset = [
            {"input": "a", "expected": "ok"},
            {"input": "b", "expected": "ok"},
            {"input": "c", "expected": "ok"},
        ]

        result = client.evals.run(
            name="Failure Handling Test",
            dataset=dataset,
            task=failing_task,
            scorers=[exactMatch],
            log_to_api=False,
            show_progress=False,
            max_concurrent=1,  # Sequential to control order
        )

        assert result.status == EvaluationStatus.COMPLETED
        assert result.summary.failed_rows == 2
        assert result.summary.successful_rows == 1
        client.close()
