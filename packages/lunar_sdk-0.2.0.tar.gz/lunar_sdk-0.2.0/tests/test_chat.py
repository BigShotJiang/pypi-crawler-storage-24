"""Tests for chat completions."""

import pytest
import respx
from httpx import Response

from lunar import Lunar, AsyncLunar, ChatCompletion
from lunar._exceptions import BadRequestError, RateLimitError, ServerError


# Sample successful response
CHAT_RESPONSE = {
    "id": "chatcmpl_123",
    "object": "chat.completion",
    "created": 1234567890,
    "model": "gpt-4o-mini",
    "choices": [
        {
            "index": 0,
            "message": {"role": "assistant", "content": "Hello! How can I help you?"},
            "finish_reason": "stop",
        }
    ],
    "usage": {
        "prompt_tokens": 10,
        "completion_tokens": 8,
        "total_tokens": 18,
        "input_cost_usd": 0.00001,
        "output_cost_usd": 0.000016,
        "total_cost_usd": 0.000026,
    },
}


@pytest.fixture
def client():
    """Create a test client."""
    return Lunar(api_key="test-key", base_url="https://api.test.com")


@pytest.fixture
def async_client():
    """Create an async test client."""
    return AsyncLunar(api_key="test-key", base_url="https://api.test.com")


class TestChatCompletions:
    """Tests for chat completions."""

    @respx.mock
    def test_create_chat_completion(self, client):
        """Test creating a chat completion."""
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello!"}],
        )

        assert isinstance(response, ChatCompletion)
        assert response.id == "chatcmpl_123"
        assert response.choices[0].message.content == "Hello! How can I help you?"
        assert response.usage.total_cost_usd == 0.000026
        client.close()

    @respx.mock
    def test_create_with_dict_messages(self, client):
        """Test creating a completion with dict messages."""
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "Hello!"},
            ],
        )

        assert isinstance(response, ChatCompletion)
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_create_chat_completion(self, async_client):
        """Test creating an async chat completion."""
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )

        response = await async_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello!"}],
        )

        assert isinstance(response, ChatCompletion)
        assert response.id == "chatcmpl_123"
        await async_client.close()


class TestChatFallbacks:
    """Tests for fallback behavior."""

    @respx.mock
    def test_fallback_on_server_error(self, client):
        """Test that fallback is triggered on 5xx error."""
        # First request fails with 500
        respx.post("https://api.test.com/v1/chat/completions").mock(
            side_effect=[
                Response(500, json={"error": "Internal server error"}),
                Response(200, json=CHAT_RESPONSE),
            ]
        )

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello!"}],
            fallbacks=["claude-3-haiku"],
        )

        assert isinstance(response, ChatCompletion)
        client.close()

    @respx.mock
    def test_fallback_on_rate_limit(self, client):
        """Test that fallback is triggered on 429 error."""
        respx.post("https://api.test.com/v1/chat/completions").mock(
            side_effect=[
                Response(429, json={"error": "Rate limit exceeded"}),
                Response(200, json=CHAT_RESPONSE),
            ]
        )

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello!"}],
            fallbacks=["claude-3-haiku"],
        )

        assert isinstance(response, ChatCompletion)
        client.close()

    @respx.mock
    def test_no_fallback_on_bad_request(self, client):
        """Test that NO fallback is triggered on 400 error."""
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(400, json={"error": "Bad request"})
        )

        with pytest.raises(BadRequestError):
            client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "Hello!"}],
                fallbacks=["claude-3-haiku"],
            )
        client.close()

    @respx.mock
    def test_no_fallback_on_auth_error(self, client):
        """Test that NO fallback is triggered on 401 error."""
        from lunar._exceptions import AuthenticationError

        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(401, json={"error": "Unauthorized"})
        )

        with pytest.raises(AuthenticationError):
            client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "Hello!"}],
                fallbacks=["claude-3-haiku"],
            )
        client.close()

    @respx.mock
    def test_all_fallbacks_fail(self, client):
        """Test error when all fallbacks fail."""
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(500, json={"error": "Server error"})
        )

        with pytest.raises(ServerError):
            client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "Hello!"}],
                fallbacks=["claude-3-haiku", "llama-3.1-8b"],
            )
        client.close()

    @respx.mock
    def test_config_fallbacks(self):
        """Test fallbacks configured in client."""
        client = Lunar(
            api_key="test-key",
            base_url="https://api.test.com",
            fallbacks={"gpt-4o-mini": ["claude-3-haiku"]},
        )

        respx.post("https://api.test.com/v1/chat/completions").mock(
            side_effect=[
                Response(500, json={"error": "Server error"}),
                Response(200, json=CHAT_RESPONSE),
            ]
        )

        # Should use config fallbacks automatically
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello!"}],
        )

        assert isinstance(response, ChatCompletion)
        client.close()
