"""Tests for evals API routing and evals HTTP client."""

import pytest

from lunar import AsyncLunar, Lunar


class TestEvalsRouting:
    """Tests that evals resources use the correct base URL."""

    def test_dev_environment_uses_same_base(self):
        """In dev, evals should route to the same domain as base (unified via CloudFront)."""
        client = Lunar(api_key="test-key", environment="dev")
        assert client._http.config.base_url == "https://dev-api.lunar-sys.com"
        assert client._evals_http.config.base_url == "https://dev-api.lunar-sys.com"
        client.close()

    def test_prod_environment_same_base(self):
        """In prod, both should point to the same URL."""
        client = Lunar(api_key="test-key", environment="prod")
        assert client._http.config.base_url == "https://api.lunar-sys.com"
        assert client._evals_http.config.base_url == "https://api.lunar-sys.com"
        client.close()

    def test_evals_resource_uses_evals_http(self):
        """Evaluations resource should use _evals_http, not _http."""
        client = Lunar(api_key="test-key", environment="dev")
        assert client._evals._http is client._evals_http
        assert client._datasets._http is client._evals_http
        client.close()

    def test_new_resources_use_evals_http(self):
        """All new eval resources should use _evals_http."""
        client = Lunar(api_key="test-key", environment="dev")
        for attr in [
            "_experiments", "_metrics", "_traces", "_trace_issues",
            "_auto_eval", "_eval_agent", "_annotations", "_proposals",
            "_eval_models", "_eval_settings",
        ]:
            resource = getattr(client, attr)
            assert resource._http is client._evals_http, f"{attr} should use _evals_http"
        client.close()

    def test_close_closes_both_http_clients(self):
        """close() should close both HTTP clients."""
        client = Lunar(api_key="test-key")
        # Access clients to create them
        _ = client._http.client
        _ = client._evals_http.client
        client.close()
        assert client._http._client is None
        assert client._evals_http._client is None

    def test_evals_http_inherits_auth(self):
        """Evals HTTP client should have the same auth headers."""
        client = Lunar(api_key="my-secret-key", environment="dev")
        assert client._evals_http.config.api_key == "my-secret-key"
        assert "x-api-key" in client._evals_http.config.headers
        assert client._evals_http.config.headers["x-api-key"] == "my-secret-key"
        client.close()


class TestAsyncEvalsRouting:
    """Tests that async evals resources use the correct base URL."""

    def test_async_dev_environment_uses_same_base(self):
        """In dev, async evals should route to the same domain."""
        client = AsyncLunar(api_key="test-key", environment="dev")
        assert client._http.config.base_url == "https://dev-api.lunar-sys.com"
        assert client._evals_http.config.base_url == "https://dev-api.lunar-sys.com"

    def test_async_new_resources_use_evals_http(self):
        """All async eval resources should use _evals_http."""
        client = AsyncLunar(api_key="test-key", environment="dev")
        for attr in [
            "_experiments", "_metrics", "_traces", "_trace_issues",
            "_auto_eval", "_eval_agent", "_annotations", "_proposals",
            "_eval_models", "_eval_settings",
        ]:
            resource = getattr(client, attr)
            assert resource._http is client._evals_http, f"{attr} should use _evals_http"
