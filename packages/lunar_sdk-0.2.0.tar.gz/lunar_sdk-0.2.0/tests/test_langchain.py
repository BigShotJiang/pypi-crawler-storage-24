"""Tests for the LangChain integration."""

from unittest.mock import MagicMock, AsyncMock, patch

import pytest
import respx
from httpx import Response

from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)

from lunar.integrations.langchain import ChatLunar, _convert_messages, _convert_response
from lunar.types.chat import ChatCompletion


# -- Fixtures / sample data ------------------------------------------------

CHAT_RESPONSE = {
    "id": "chatcmpl_lc_001",
    "object": "chat.completion",
    "created": 1700000000,
    "model": "gpt-4o-mini",
    "choices": [
        {
            "index": 0,
            "message": {"role": "assistant", "content": "Hi there!"},
            "finish_reason": "stop",
        }
    ],
    "usage": {
        "prompt_tokens": 12,
        "completion_tokens": 4,
        "total_tokens": 16,
        "input_cost_usd": 0.00002,
        "output_cost_usd": 0.00001,
        "total_cost_usd": 0.00003,
        "latency_ms": 142.5,
        "ttft_ms": 45.2,
    },
}

CHAT_RESPONSE_NO_COST = {
    "id": "chatcmpl_lc_002",
    "object": "chat.completion",
    "created": 1700000000,
    "model": "gpt-4o-mini",
    "choices": [
        {
            "index": 0,
            "message": {"role": "assistant", "content": "Hello!"},
            "finish_reason": "stop",
        }
    ],
    "usage": {
        "prompt_tokens": 5,
        "completion_tokens": 2,
        "total_tokens": 7,
    },
}

STREAM_CHUNKS = [
    {
        "id": "chatcmpl_lc_s01",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "gpt-4o-mini",
        "choices": [
            {"index": 0, "delta": {"role": "assistant", "content": ""}, "finish_reason": None}
        ],
    },
    {
        "id": "chatcmpl_lc_s01",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "gpt-4o-mini",
        "choices": [
            {"index": 0, "delta": {"content": "Hello"}, "finish_reason": None}
        ],
    },
    {
        "id": "chatcmpl_lc_s01",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "gpt-4o-mini",
        "choices": [
            {"index": 0, "delta": {"content": " world"}, "finish_reason": None}
        ],
    },
    {
        "id": "chatcmpl_lc_s01",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "gpt-4o-mini",
        "choices": [
            {"index": 0, "delta": {"content": ""}, "finish_reason": "stop"}
        ],
    },
]


def _make_llm(**kwargs):
    """Helper to create a ChatLunar with test defaults."""
    defaults = {"model": "gpt-4o-mini", "api_key": "test-key", "base_url": "https://api.test.com"}
    defaults.update(kwargs)
    return ChatLunar(**defaults)


# -- Message conversion tests ---------------------------------------------


class TestConvertMessages:
    def test_system_message(self):
        msgs = _convert_messages([SystemMessage(content="You are helpful.")])
        assert msgs == [{"role": "system", "content": "You are helpful."}]

    def test_human_message(self):
        msgs = _convert_messages([HumanMessage(content="Hi")])
        assert msgs == [{"role": "user", "content": "Hi"}]

    def test_ai_message(self):
        msgs = _convert_messages([AIMessage(content="Hello!")])
        assert msgs == [{"role": "assistant", "content": "Hello!"}]

    def test_tool_message(self):
        msgs = _convert_messages([ToolMessage(content="42", tool_call_id="call_1")])
        assert msgs == [{"role": "tool", "content": "42", "tool_call_id": "call_1"}]

    def test_ai_message_with_tool_calls(self):
        ai = AIMessage(
            content="",
            tool_calls=[
                {"id": "call_1", "name": "get_weather", "args": {"city": "NYC"}},
            ],
        )
        msgs = _convert_messages([ai])
        assert len(msgs) == 1
        assert msgs[0]["role"] == "assistant"
        assert len(msgs[0]["tool_calls"]) == 1
        tc = msgs[0]["tool_calls"][0]
        assert tc["id"] == "call_1"
        assert tc["function"]["name"] == "get_weather"
        assert '"city"' in tc["function"]["arguments"]

    def test_all_message_types(self):
        msgs = _convert_messages([
            SystemMessage(content="Be concise."),
            HumanMessage(content="Hello"),
            AIMessage(content="Hi!"),
            HumanMessage(content="Thanks"),
        ])
        assert len(msgs) == 4
        assert [m["role"] for m in msgs] == ["system", "user", "assistant", "user"]


# -- Response conversion tests --------------------------------------------


class TestConvertResponse:
    def test_basic_response(self):
        completion = ChatCompletion.model_validate(CHAT_RESPONSE)
        result = _convert_response(completion)
        assert len(result.generations) == 1
        ai_msg = result.generations[0].message
        assert ai_msg.content == "Hi there!"

    def test_usage_metadata(self):
        completion = ChatCompletion.model_validate(CHAT_RESPONSE)
        result = _convert_response(completion)
        ai_msg = result.generations[0].message
        assert ai_msg.usage_metadata["input_tokens"] == 12
        assert ai_msg.usage_metadata["output_tokens"] == 4
        assert ai_msg.usage_metadata["total_tokens"] == 16

    def test_cost_metadata_in_response(self):
        completion = ChatCompletion.model_validate(CHAT_RESPONSE)
        result = _convert_response(completion)
        meta = result.generations[0].message.response_metadata
        assert meta["model"] == "gpt-4o-mini"
        assert meta["finish_reason"] == "stop"
        assert meta["input_cost_usd"] == 0.00002
        assert meta["output_cost_usd"] == 0.00001
        assert meta["total_cost_usd"] == 0.00003
        assert meta["latency_ms"] == 142.5
        assert meta["ttft_ms"] == 45.2

    def test_response_without_cost(self):
        completion = ChatCompletion.model_validate(CHAT_RESPONSE_NO_COST)
        result = _convert_response(completion)
        meta = result.generations[0].message.response_metadata
        assert "input_cost_usd" not in meta
        assert "latency_ms" not in meta


# -- Invoke / generate tests (using respx) --------------------------------


class TestInvoke:
    @respx.mock
    def test_invoke(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        result = llm.invoke("Hello!")
        assert result.content == "Hi there!"

    @respx.mock
    def test_generate(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        result = llm.generate([[HumanMessage(content="Hello!")]])
        assert result.generations[0][0].message.content == "Hi there!"

    @respx.mock
    def test_system_and_user_messages(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        result = llm.invoke([
            SystemMessage(content="Be concise."),
            HumanMessage(content="Hello"),
        ])
        assert result.content == "Hi there!"

    @respx.mock
    def test_usage_metadata_on_invoke(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        result = llm.invoke("Hello!")
        assert result.usage_metadata["input_tokens"] == 12
        assert result.usage_metadata["total_tokens"] == 16

    @respx.mock
    def test_cost_metadata_on_invoke(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        result = llm.invoke("Hello!")
        assert result.response_metadata["total_cost_usd"] == 0.00003
        assert result.response_metadata["latency_ms"] == 142.5


# -- Streaming tests (using mock SDK client) -------------------------------


class TestStream:
    def _mock_stream(self):
        """Create a mock Stream that yields ChatCompletionChunks."""
        from lunar.types.chat import ChatCompletionChunk

        chunks = [ChatCompletionChunk.model_validate(c) for c in STREAM_CHUNKS]

        class FakeStream:
            def __iter__(self):
                return iter(chunks)

            def __enter__(self):
                return self

            def __exit__(self, *a):
                pass

        return FakeStream()

    def test_stream_yields_chunks(self):
        llm = _make_llm()
        with patch.object(llm, "_get_client") as mock_get:
            mock_client = MagicMock()
            mock_client.chat.completions.create.return_value = self._mock_stream()
            mock_get.return_value = mock_client

            chunks = list(llm.stream("Hello!"))
            content = "".join(c.content for c in chunks)
            assert "Hello world" in content

    def test_stream_runs_callback(self):
        llm = _make_llm()
        with patch.object(llm, "_get_client") as mock_get:
            mock_client = MagicMock()
            mock_client.chat.completions.create.return_value = self._mock_stream()
            mock_get.return_value = mock_client

            tokens = []

            class FakeRunManager:
                def on_llm_new_token(self, token, **kwargs):
                    tokens.append(token)

            # Call _stream directly to pass run_manager
            gen_chunks = list(
                llm._stream([HumanMessage(content="Hello!")], run_manager=FakeRunManager())
            )
            assert len(gen_chunks) == len(STREAM_CHUNKS)
            assert "Hello" in tokens
            assert " world" in tokens


# -- Async tests -----------------------------------------------------------


class TestAsync:
    @respx.mock
    @pytest.mark.asyncio
    async def test_ainvoke(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        result = await llm.ainvoke("Hello!")
        assert result.content == "Hi there!"

    @pytest.mark.asyncio
    async def test_astream(self):
        from lunar.types.chat import ChatCompletionChunk

        chunks = [ChatCompletionChunk.model_validate(c) for c in STREAM_CHUNKS]

        class FakeAsyncStream:
            async def __aiter__(self):
                for c in chunks:
                    yield c

            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                pass

        llm = _make_llm()
        with patch.object(llm, "_get_async_client") as mock_get:
            mock_client = AsyncMock()
            mock_client.chat.completions.create.return_value = FakeAsyncStream()
            mock_get.return_value = mock_client

            content_parts = []
            async for chunk in llm.astream("Hello!"):
                content_parts.append(chunk.content)
            content = "".join(content_parts)
            assert "Hello world" in content


# -- Params / config tests -------------------------------------------------


class TestParams:
    @respx.mock
    def test_params_passed_through(self):
        route = respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm(temperature=0.5, max_tokens=100, top_p=0.9)
        llm.invoke("Hello!")

        request_body = route.calls[0].request
        import json

        body = json.loads(request_body.content)
        assert body["temperature"] == 0.5
        assert body["max_tokens"] == 100
        assert body["top_p"] == 0.9

    @respx.mock
    def test_per_call_kwargs_override(self):
        route = respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm(temperature=0.5)
        # Override temperature via invoke kwargs
        llm.invoke("Hello!", temperature=0.9)

        import json

        body = json.loads(route.calls[0].request.content)
        assert body["temperature"] == 0.9

    @respx.mock
    def test_stop_sequences(self):
        route = respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm(stop=["END"])
        llm.invoke("Hello!")

        import json

        body = json.loads(route.calls[0].request.content)
        assert body["stop"] == ["END"]

    def test_fallbacks_configured(self):
        llm = _make_llm(fallbacks=["claude-3-haiku", "llama-3.1-8b"])
        assert llm.fallbacks == ["claude-3-haiku", "llama-3.1-8b"]


# -- Identity tests --------------------------------------------------------


class TestIdentity:
    def test_llm_type(self):
        llm = _make_llm()
        assert llm._llm_type == "lunar"

    def test_identifying_params(self):
        llm = _make_llm(temperature=0.7, max_tokens=256)
        params = llm._identifying_params
        assert params["model"] == "gpt-4o-mini"
        assert params["temperature"] == 0.7
        assert params["max_tokens"] == 256
        assert params["base_url"] == "https://api.test.com"

    def test_identifying_params_minimal(self):
        llm = _make_llm()
        params = llm._identifying_params
        assert params == {"model": "gpt-4o-mini", "base_url": "https://api.test.com"}
