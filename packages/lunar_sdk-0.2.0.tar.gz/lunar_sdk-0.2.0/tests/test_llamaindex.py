"""Tests for the LlamaIndex integration."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import respx
from httpx import Response

from llama_index.core.llms import ChatMessage, MessageRole

from lunar.integrations.llamaindex import LunarLLM, _build_response_kwargs, _convert_messages
from lunar.types.chat import ChatCompletion


# -- Fixtures / sample data ------------------------------------------------

CHAT_RESPONSE = {
    "id": "chatcmpl_li_001",
    "object": "chat.completion",
    "created": 1700000000,
    "model": "gpt-4o-mini",
    "choices": [
        {
            "index": 0,
            "message": {"role": "assistant", "content": "Hi there!"},
            "finish_reason": "stop",
        }
    ],
    "usage": {
        "prompt_tokens": 12,
        "completion_tokens": 4,
        "total_tokens": 16,
        "input_cost_usd": 0.00002,
        "output_cost_usd": 0.00001,
        "total_cost_usd": 0.00003,
        "latency_ms": 142.5,
        "ttft_ms": 45.2,
    },
}

CHAT_RESPONSE_NO_COST = {
    "id": "chatcmpl_li_002",
    "object": "chat.completion",
    "created": 1700000000,
    "model": "gpt-4o-mini",
    "choices": [
        {
            "index": 0,
            "message": {"role": "assistant", "content": "Hello!"},
            "finish_reason": "stop",
        }
    ],
    "usage": {
        "prompt_tokens": 5,
        "completion_tokens": 2,
        "total_tokens": 7,
    },
}

STREAM_CHUNKS = [
    {
        "id": "chatcmpl_li_s01",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "gpt-4o-mini",
        "choices": [
            {"index": 0, "delta": {"role": "assistant", "content": ""}, "finish_reason": None}
        ],
    },
    {
        "id": "chatcmpl_li_s01",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "gpt-4o-mini",
        "choices": [
            {"index": 0, "delta": {"content": "Hello"}, "finish_reason": None}
        ],
    },
    {
        "id": "chatcmpl_li_s01",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "gpt-4o-mini",
        "choices": [
            {"index": 0, "delta": {"content": " world"}, "finish_reason": None}
        ],
    },
    {
        "id": "chatcmpl_li_s01",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "gpt-4o-mini",
        "choices": [
            {"index": 0, "delta": {"content": ""}, "finish_reason": "stop"}
        ],
    },
]


def _make_llm(**kwargs):
    """Helper to create a LunarLLM with test defaults."""
    defaults = {"model": "gpt-4o-mini", "api_key": "test-key", "base_url": "https://api.test.com"}
    defaults.update(kwargs)
    return LunarLLM(**defaults)


# -- Message conversion tests ---------------------------------------------


class TestConvertMessages:
    def test_user_message(self):
        msgs = _convert_messages([ChatMessage(role=MessageRole.USER, content="Hi")])
        assert msgs == [{"role": "user", "content": "Hi"}]

    def test_system_message(self):
        msgs = _convert_messages([ChatMessage(role=MessageRole.SYSTEM, content="Be helpful.")])
        assert msgs == [{"role": "system", "content": "Be helpful."}]

    def test_assistant_message(self):
        msgs = _convert_messages([ChatMessage(role=MessageRole.ASSISTANT, content="Hello!")])
        assert msgs == [{"role": "assistant", "content": "Hello!"}]

    def test_tool_message(self):
        msgs = _convert_messages([
            ChatMessage(
                role=MessageRole.TOOL,
                content="42",
                additional_kwargs={"tool_call_id": "call_1"},
            )
        ])
        assert msgs == [{"role": "tool", "content": "42", "tool_call_id": "call_1"}]

    def test_all_roles(self):
        msgs = _convert_messages([
            ChatMessage(role=MessageRole.SYSTEM, content="Be concise."),
            ChatMessage(role=MessageRole.USER, content="Hello"),
            ChatMessage(role=MessageRole.ASSISTANT, content="Hi!"),
            ChatMessage(role=MessageRole.USER, content="Thanks"),
        ])
        assert len(msgs) == 4
        assert [m["role"] for m in msgs] == ["system", "user", "assistant", "user"]

    def test_additional_kwargs_passthrough(self):
        msgs = _convert_messages([
            ChatMessage(
                role=MessageRole.ASSISTANT,
                content="",
                additional_kwargs={"tool_calls": [{"id": "c1", "type": "function"}]},
            )
        ])
        assert msgs[0]["tool_calls"] == [{"id": "c1", "type": "function"}]


# -- Response kwargs tests -------------------------------------------------


class TestBuildResponseKwargs:
    def test_with_full_usage(self):
        completion = ChatCompletion.model_validate(CHAT_RESPONSE)
        kwargs = _build_response_kwargs(completion)
        assert kwargs["usage"]["prompt_tokens"] == 12
        assert kwargs["usage"]["completion_tokens"] == 4
        assert kwargs["usage"]["total_tokens"] == 16
        assert kwargs["input_cost_usd"] == 0.00002
        assert kwargs["output_cost_usd"] == 0.00001
        assert kwargs["total_cost_usd"] == 0.00003
        assert kwargs["latency_ms"] == 142.5
        assert kwargs["ttft_ms"] == 45.2

    def test_without_cost(self):
        completion = ChatCompletion.model_validate(CHAT_RESPONSE_NO_COST)
        kwargs = _build_response_kwargs(completion)
        assert "usage" in kwargs
        assert "input_cost_usd" not in kwargs
        assert "latency_ms" not in kwargs


# -- Chat tests (using respx) ---------------------------------------------


class TestChat:
    @respx.mock
    def test_chat(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        resp = llm.chat([ChatMessage(role=MessageRole.USER, content="Hello!")])
        assert resp.message.content == "Hi there!"
        assert resp.message.role == MessageRole.ASSISTANT

    @respx.mock
    def test_chat_raw_response(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        resp = llm.chat([ChatMessage(role=MessageRole.USER, content="Hello!")])
        assert resp.raw is not None
        assert resp.raw.model == "gpt-4o-mini"

    @respx.mock
    def test_chat_additional_kwargs(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        resp = llm.chat([ChatMessage(role=MessageRole.USER, content="Hello!")])
        assert resp.additional_kwargs["total_cost_usd"] == 0.00003
        assert resp.additional_kwargs["latency_ms"] == 142.5
        assert resp.additional_kwargs["usage"]["total_tokens"] == 16


# -- Complete tests (delegates to chat) ------------------------------------


class TestComplete:
    @respx.mock
    def test_complete(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        resp = llm.complete("Hello!")
        assert resp.text == "Hi there!"


# -- Streaming tests (using mock SDK client) -------------------------------


class TestStreamChat:
    def _mock_stream(self):
        """Create a mock Stream that yields ChatCompletionChunks."""
        from lunar.types.chat import ChatCompletionChunk

        chunks = [ChatCompletionChunk.model_validate(c) for c in STREAM_CHUNKS]

        class FakeStream:
            def __iter__(self):
                return iter(chunks)

            def __enter__(self):
                return self

            def __exit__(self, *a):
                pass

        return FakeStream()

    def test_stream_chat_yields_responses(self):
        llm = _make_llm()
        with patch.object(llm, "_get_client") as mock_get:
            mock_client = MagicMock()
            mock_client.chat.completions.create.return_value = self._mock_stream()
            mock_get.return_value = mock_client

            responses = list(llm.stream_chat(
                [ChatMessage(role=MessageRole.USER, content="Hello!")]
            ))
            # Last response should have the accumulated content
            assert responses[-1].message.content == "Hello world"
            assert responses[-1].message.role == MessageRole.ASSISTANT

    def test_stream_chat_delta(self):
        llm = _make_llm()
        with patch.object(llm, "_get_client") as mock_get:
            mock_client = MagicMock()
            mock_client.chat.completions.create.return_value = self._mock_stream()
            mock_get.return_value = mock_client

            deltas = [
                r.delta
                for r in llm.stream_chat(
                    [ChatMessage(role=MessageRole.USER, content="Hello!")]
                )
            ]
            assert "Hello" in deltas
            assert " world" in deltas

    def test_stream_complete(self):
        llm = _make_llm()
        with patch.object(llm, "_get_client") as mock_get:
            mock_client = MagicMock()
            mock_client.chat.completions.create.return_value = self._mock_stream()
            mock_get.return_value = mock_client

            responses = list(llm.stream_complete("Hello!"))
            assert responses[-1].text == "Hello world"


# -- Async tests -----------------------------------------------------------


class TestAsync:
    @respx.mock
    @pytest.mark.asyncio
    async def test_achat(self):
        respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm()
        resp = await llm.achat([ChatMessage(role=MessageRole.USER, content="Hello!")])
        assert resp.message.content == "Hi there!"
        assert resp.additional_kwargs["total_cost_usd"] == 0.00003

    @pytest.mark.asyncio
    async def test_astream_chat(self):
        from lunar.types.chat import ChatCompletionChunk

        chunks = [ChatCompletionChunk.model_validate(c) for c in STREAM_CHUNKS]

        class FakeAsyncStream:
            async def __aiter__(self):
                for c in chunks:
                    yield c

            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                pass

        llm = _make_llm()
        with patch.object(llm, "_get_async_client") as mock_get:
            mock_client = AsyncMock()
            mock_client.chat.completions.create.return_value = FakeAsyncStream()
            mock_get.return_value = mock_client

            responses = []
            async for r in await llm.astream_chat(
                [ChatMessage(role=MessageRole.USER, content="Hello!")]
            ):
                responses.append(r)
            assert responses[-1].message.content == "Hello world"
            assert "Hello" in [r.delta for r in responses]


# -- Params / config tests -------------------------------------------------


class TestParams:
    @respx.mock
    def test_params_passed_through(self):
        import json

        route = respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm(temperature=0.5, max_tokens=100, top_p=0.9)
        llm.chat([ChatMessage(role=MessageRole.USER, content="Hello!")])

        body = json.loads(route.calls[0].request.content)
        assert body["temperature"] == 0.5
        assert body["max_tokens"] == 100
        assert body["top_p"] == 0.9

    @respx.mock
    def test_per_call_kwargs_override(self):
        import json

        route = respx.post("https://api.test.com/v1/chat/completions").mock(
            return_value=Response(200, json=CHAT_RESPONSE)
        )
        llm = _make_llm(temperature=0.5)
        llm.chat(
            [ChatMessage(role=MessageRole.USER, content="Hello!")],
            temperature=0.9,
        )

        body = json.loads(route.calls[0].request.content)
        assert body["temperature"] == 0.9

    def test_fallbacks_configured(self):
        llm = _make_llm(fallbacks=["claude-3-haiku", "llama-3.1-8b"])
        assert llm.fallbacks == ["claude-3-haiku", "llama-3.1-8b"]


# -- Identity tests --------------------------------------------------------


class TestIdentity:
    def test_metadata(self):
        llm = _make_llm(max_tokens=256)
        meta = llm.metadata
        assert meta.is_chat_model is True
        assert meta.model_name == "gpt-4o-mini"
        assert meta.num_output == 256

    def test_metadata_default_num_output(self):
        llm = _make_llm()
        assert llm.metadata.num_output == -1

    def test_class_name(self):
        assert LunarLLM.class_name() == "LunarLLM"
