"""Tests for all evaluation resource endpoints using respx HTTP mocking."""

import pytest
import respx
from httpx import Response

from lunar import AsyncLunar, Lunar
from lunar.evals.types import (
    AnnotationAnalytics,
    AnnotationItem,
    AnnotationQueue,
    AutoCollectConfig,
    AutoEvalConfig,
    AutoEvalRun,
    EvaluationResult,
    EvaluationStatusResponse,
    Experiment,
    Metric,
    Proposal,
    ScanResult,
    ScriptValidationResult,
    Trace,
    TraceIssue,
)

BASE = "https://evals.test.com"


@pytest.fixture
def client():
    """Create a test client with explicit evals URL."""
    c = Lunar(api_key="test-key", base_url="https://api.test.com")
    # Override evals HTTP base to a predictable URL for mocking
    c._evals_http.config.base_url = BASE
    c._evals_http._client = None  # Force client recreation with new URL
    return c


@pytest.fixture
def async_client():
    """Create an async test client with explicit evals URL."""
    c = AsyncLunar(api_key="test-key", base_url="https://api.test.com")
    c._evals_http.config.base_url = BASE
    c._evals_http._client = None
    return c


# =========================================================================
# Evaluations resource - new methods
# =========================================================================


class TestEvaluationsCreate:
    @respx.mock
    def test_create(self, client):
        respx.post(f"{BASE}/v1/evaluations").mock(
            return_value=Response(200, json={
                "id": "eval_1", "name": "Test", "status": "pending",
                "created_at": "2025-01-01T00:00:00", "progress": {"total": 10, "completed": 0},
            })
        )
        result = client.evals.create(
            name="Test", dataset_id="ds_1", models=["gpt-4o"], metrics=["accuracy"]
        )
        assert isinstance(result, EvaluationResult)
        assert result.id == "eval_1"
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_create(self, async_client):
        respx.post(f"{BASE}/v1/evaluations").mock(
            return_value=Response(200, json={
                "id": "eval_1", "name": "Test", "status": "pending",
                "created_at": "2025-01-01T00:00:00", "progress": {"total": 10, "completed": 0},
            })
        )
        result = await async_client.evals.create(
            name="Test", dataset_id="ds_1", models=["gpt-4o"], metrics=["accuracy"]
        )
        assert result.id == "eval_1"
        await async_client.close()


class TestEvaluationsStatus:
    @respx.mock
    def test_status(self, client):
        respx.get(f"{BASE}/v1/evaluations/eval_1/status").mock(
            return_value=Response(200, json={"id": "eval_1", "status": "running"})
        )
        result = client.evals.status("eval_1")
        assert isinstance(result, EvaluationStatusResponse)
        assert result.status == "running"
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_status(self, async_client):
        respx.get(f"{BASE}/v1/evaluations/eval_1/status").mock(
            return_value=Response(200, json={"id": "eval_1", "status": "running"})
        )
        result = await async_client.evals.status("eval_1")
        assert result.status == "running"
        await async_client.close()


class TestEvaluationsResults:
    @respx.mock
    def test_results(self, client):
        respx.get(f"{BASE}/v1/evaluations/eval_1/results").mock(
            return_value=Response(200, json={"rows": [], "summary": {}})
        )
        result = client.evals.results("eval_1")
        assert "rows" in result
        client.close()


class TestEvaluationsExport:
    @respx.mock
    def test_export(self, client):
        respx.get(f"{BASE}/v1/evaluations/eval_1/export").mock(
            return_value=Response(200, json={"data": "csv content"})
        )
        result = client.evals.export("eval_1", format="csv")
        assert "data" in result
        client.close()


class TestEvaluationsCancel:
    @respx.mock
    def test_cancel(self, client):
        respx.post(f"{BASE}/v1/evaluations/eval_1/cancel").mock(
            return_value=Response(200, json={
                "id": "eval_1", "name": "Test", "status": "cancelled",
                "created_at": "2025-01-01T00:00:00", "progress": {"total": 10, "completed": 5},
            })
        )
        result = client.evals.cancel("eval_1")
        assert result.status == "cancelled"
        client.close()


class TestEvaluationsRerun:
    @respx.mock
    def test_rerun(self, client):
        respx.post(f"{BASE}/v1/evaluations/eval_1/rerun").mock(
            return_value=Response(200, json={
                "id": "eval_2", "name": "Test", "status": "pending",
                "created_at": "2025-01-01T00:00:00", "progress": {"total": 10, "completed": 0},
            })
        )
        result = client.evals.rerun("eval_1")
        assert result.id == "eval_2"
        client.close()


class TestEvaluationsCleanup:
    @respx.mock
    def test_cleanup(self, client):
        respx.post(f"{BASE}/v1/evaluations/cleanup").mock(
            return_value=Response(200, json={"cleaned": 3})
        )
        result = client.evals.cleanup(stale_threshold_hours=48)
        assert result["cleaned"] == 3
        client.close()


class TestEvaluationsWaitSync:
    @respx.mock
    def test_wait_already_completed(self, client):
        respx.get(f"{BASE}/v1/evaluations/eval_1").mock(
            return_value=Response(200, json={
                "id": "eval_1", "name": "Test", "status": "completed",
                "created_at": "2025-01-01T00:00:00", "progress": {"total": 10, "completed": 10},
            })
        )
        result = client.evals.wait("eval_1")
        assert result.status == "completed"
        client.close()

    @respx.mock
    def test_wait_timeout(self, client):
        respx.get(f"{BASE}/v1/evaluations/eval_1").mock(
            return_value=Response(200, json={
                "id": "eval_1", "name": "Test", "status": "running",
                "created_at": "2025-01-01T00:00:00", "progress": {"total": 10, "completed": 3},
            })
        )
        with pytest.raises(TimeoutError):
            client.evals.wait("eval_1", poll_interval=0.01, timeout=0.05)
        client.close()


# =========================================================================
# Datasets resource - new methods
# =========================================================================


class TestDatasetsImport:
    @respx.mock
    def test_import_data(self, client):
        respx.post(f"{BASE}/v1/datasets/import").mock(
            return_value=Response(200, json={
                "id": "ds_1", "name": "Imported",
                "created_at": "2025-01-01T00:00:00", "datapoint_count": 50,
            })
        )
        ds = client.datasets.import_data(name="Imported", format="csv", data="col1,col2\na,b")
        assert ds.id == "ds_1"
        assert ds.datapoint_count == 50
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_import_data(self, async_client):
        respx.post(f"{BASE}/v1/datasets/import").mock(
            return_value=Response(200, json={
                "id": "ds_1", "name": "Imported",
                "created_at": "2025-01-01T00:00:00", "datapoint_count": 50,
            })
        )
        ds = await async_client.datasets.import_data(name="Imported", format="csv", data="a,b")
        assert ds.id == "ds_1"
        await async_client.close()


class TestDatasetsFromTraces:
    @respx.mock
    def test_from_traces(self, client):
        respx.post(f"{BASE}/v1/datasets/from-traces").mock(
            return_value=Response(200, json={
                "id": "ds_2", "name": "From Traces",
                "created_at": "2025-01-01T00:00:00", "datapoint_count": 20,
            })
        )
        ds = client.datasets.from_traces(name="From Traces", model_id="gpt-4o")
        assert ds.name == "From Traces"
        client.close()


class TestDatasetsFromInstruction:
    @respx.mock
    def test_from_instruction(self, client):
        respx.post(f"{BASE}/v1/datasets/from-instruction").mock(
            return_value=Response(200, json={
                "id": "ds_3", "name": "Synthetic",
                "created_at": "2025-01-01T00:00:00", "datapoint_count": 100,
            })
        )
        ds = client.datasets.from_instruction(
            name="Synthetic",
            instruction="Generate QA pairs about Python",
            count=100,
        )
        assert ds.datapoint_count == 100
        client.close()


class TestDatasetsDeleteSample:
    @respx.mock
    def test_delete_sample(self, client):
        respx.delete(f"{BASE}/v1/datasets/ds_1/samples/s_1").mock(
            return_value=Response(200, json={"deleted": True})
        )
        assert client.datasets.delete_sample("ds_1", "s_1") is True
        client.close()


class TestDatasetsAutoCollect:
    @respx.mock
    def test_set_auto_collect(self, client):
        respx.put(f"{BASE}/v1/datasets/ds_1/auto-collect").mock(
            return_value=Response(200, json={
                "dataset_id": "ds_1", "enabled": True, "sample_rate": 0.1,
            })
        )
        cfg = client.datasets.set_auto_collect("ds_1", enabled=True, sample_rate=0.1)
        assert isinstance(cfg, AutoCollectConfig)
        assert cfg.enabled is True
        client.close()

    @respx.mock
    def test_get_auto_collect(self, client):
        respx.get(f"{BASE}/v1/datasets/ds_1/auto-collect").mock(
            return_value=Response(200, json={
                "dataset_id": "ds_1", "enabled": False,
            })
        )
        cfg = client.datasets.get_auto_collect("ds_1")
        assert cfg.enabled is False
        client.close()

    @respx.mock
    def test_delete_auto_collect(self, client):
        respx.delete(f"{BASE}/v1/datasets/ds_1/auto-collect").mock(
            return_value=Response(200, json={"deleted": True})
        )
        assert client.datasets.delete_auto_collect("ds_1") is True
        client.close()

    @respx.mock
    def test_auto_collect_history(self, client):
        respx.get(f"{BASE}/v1/datasets/ds_1/auto-collect/history").mock(
            return_value=Response(200, json={"history": [{"run_id": "r1"}, {"run_id": "r2"}]})
        )
        history = client.datasets.auto_collect_history("ds_1")
        assert len(history) == 2
        client.close()

    @respx.mock
    def test_trigger_auto_collect(self, client):
        respx.post(f"{BASE}/v1/datasets/ds_1/auto-collect/run").mock(
            return_value=Response(200, json={"run_id": "r3", "status": "started"})
        )
        result = client.datasets.trigger_auto_collect("ds_1")
        assert result["status"] == "started"
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_set_auto_collect(self, async_client):
        respx.put(f"{BASE}/v1/datasets/ds_1/auto-collect").mock(
            return_value=Response(200, json={"dataset_id": "ds_1", "enabled": True})
        )
        cfg = await async_client.datasets.set_auto_collect("ds_1", enabled=True)
        assert cfg.enabled is True
        await async_client.close()


# =========================================================================
# Experiments resource
# =========================================================================


class TestExperiments:
    @respx.mock
    def test_list(self, client):
        respx.get(f"{BASE}/v1/experiments").mock(
            return_value=Response(200, json={"experiments": [
                {"id": "exp_1", "name": "Exp 1"},
                {"id": "exp_2", "name": "Exp 2"},
            ]})
        )
        exps = client.experiments.list()
        assert len(exps) == 2
        assert all(isinstance(e, Experiment) for e in exps)
        client.close()

    @respx.mock
    def test_create(self, client):
        respx.post(f"{BASE}/v1/experiments").mock(
            return_value=Response(200, json={
                "id": "exp_1", "name": "New Exp", "dataset_id": "ds_1",
                "evaluation_ids": ["eval_1", "eval_2"],
            })
        )
        exp = client.experiments.create(
            name="New Exp", dataset_id="ds_1", evaluation_ids=["eval_1", "eval_2"]
        )
        assert exp.id == "exp_1"
        assert len(exp.evaluation_ids) == 2
        client.close()

    @respx.mock
    def test_get(self, client):
        respx.get(f"{BASE}/v1/experiments/exp_1").mock(
            return_value=Response(200, json={"id": "exp_1", "name": "Exp 1"})
        )
        exp = client.experiments.get("exp_1")
        assert exp.name == "Exp 1"
        client.close()

    @respx.mock
    def test_delete(self, client):
        respx.delete(f"{BASE}/v1/experiments/exp_1").mock(
            return_value=Response(200, json={"deleted": True})
        )
        assert client.experiments.delete("exp_1") is True
        client.close()

    @respx.mock
    def test_comparison(self, client):
        respx.get(f"{BASE}/v1/experiments/exp_1/comparison").mock(
            return_value=Response(200, json={"models": {}, "metrics": {}})
        )
        result = client.experiments.comparison("exp_1")
        assert "models" in result
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_list(self, async_client):
        respx.get(f"{BASE}/v1/experiments").mock(
            return_value=Response(200, json={"experiments": [{"id": "exp_1", "name": "Exp"}]})
        )
        exps = await async_client.experiments.list()
        assert len(exps) == 1
        await async_client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_create(self, async_client):
        respx.post(f"{BASE}/v1/experiments").mock(
            return_value=Response(200, json={
                "id": "exp_1", "name": "Async Exp", "evaluation_ids": [],
            })
        )
        exp = await async_client.experiments.create(
            name="Async Exp", dataset_id="ds_1", evaluation_ids=[]
        )
        assert exp.id == "exp_1"
        await async_client.close()


# =========================================================================
# Metrics resource
# =========================================================================


class TestMetrics:
    @respx.mock
    def test_list(self, client):
        respx.get(f"{BASE}/v1/metrics").mock(
            return_value=Response(200, json={"metrics": [
                {"id": "m_1", "name": "Accuracy", "type": "builtin"},
            ]})
        )
        metrics = client.metrics.list()
        assert len(metrics) == 1
        assert isinstance(metrics[0], Metric)
        client.close()

    @respx.mock
    def test_create(self, client):
        respx.post(f"{BASE}/v1/metrics").mock(
            return_value=Response(200, json={
                "id": "m_2", "name": "Custom Score", "type": "custom",
            })
        )
        m = client.metrics.create(name="Custom Score", type="custom", python_script="...")
        assert m.id == "m_2"
        client.close()

    @respx.mock
    def test_get(self, client):
        respx.get(f"{BASE}/v1/metrics/m_1").mock(
            return_value=Response(200, json={"id": "m_1", "name": "Accuracy", "type": "builtin"})
        )
        m = client.metrics.get("m_1")
        assert m.name == "Accuracy"
        client.close()

    @respx.mock
    def test_update(self, client):
        respx.put(f"{BASE}/v1/metrics/m_1").mock(
            return_value=Response(200, json={"id": "m_1", "name": "Updated", "type": "builtin"})
        )
        m = client.metrics.update("m_1", name="Updated")
        assert m.name == "Updated"
        client.close()

    @respx.mock
    def test_delete(self, client):
        respx.delete(f"{BASE}/v1/metrics/m_1").mock(
            return_value=Response(200, json={"deleted": True})
        )
        assert client.metrics.delete("m_1") is True
        client.close()

    @respx.mock
    def test_validate_script(self, client):
        respx.post(f"{BASE}/v1/metrics/validate-script").mock(
            return_value=Response(200, json={"valid": True, "errors": [], "warnings": []})
        )
        result = client.metrics.validate_script("def score(output, expected): return 1.0")
        assert isinstance(result, ScriptValidationResult)
        assert result.valid is True
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_list(self, async_client):
        respx.get(f"{BASE}/v1/metrics").mock(
            return_value=Response(200, json={"metrics": [
                {"id": "m_1", "name": "Accuracy", "type": "builtin"},
            ]})
        )
        metrics = await async_client.metrics.list()
        assert len(metrics) == 1
        await async_client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_validate_script(self, async_client):
        respx.post(f"{BASE}/v1/metrics/validate-script").mock(
            return_value=Response(200, json={"valid": False, "errors": ["bad syntax"]})
        )
        result = await async_client.metrics.validate_script("not valid python")
        assert result.valid is False
        assert len(result.errors) == 1
        await async_client.close()


# =========================================================================
# Traces resource
# =========================================================================


class TestTraces:
    @respx.mock
    def test_list(self, client):
        respx.get(f"{BASE}/v1/traces").mock(
            return_value=Response(200, json={"traces": [
                {"id": "tr_1", "input": "Hi", "output": "Hello"},
            ]})
        )
        traces = client.traces.list()
        assert len(traces) == 1
        assert isinstance(traces[0], Trace)
        client.close()

    @respx.mock
    def test_list_with_filters(self, client):
        respx.get(f"{BASE}/v1/traces").mock(
            return_value=Response(200, json={"traces": []})
        )
        traces = client.traces.list(model_id="gpt-4o", source="sdk", limit=10)
        assert traces == []
        client.close()

    @respx.mock
    def test_create(self, client):
        respx.post(f"{BASE}/v1/traces").mock(
            return_value=Response(200, json={
                "id": "tr_2", "input": "Hello", "output": "Hi there", "model_id": "gpt-4o",
            })
        )
        t = client.traces.create(input="Hello", output="Hi there", model_id="gpt-4o")
        assert t.id == "tr_2"
        assert t.model_id == "gpt-4o"
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_list(self, async_client):
        respx.get(f"{BASE}/v1/traces").mock(
            return_value=Response(200, json={"traces": [{"id": "tr_1", "input": "Hi"}]})
        )
        traces = await async_client.traces.list()
        assert len(traces) == 1
        await async_client.close()


# =========================================================================
# Trace Issues resource
# =========================================================================


class TestTraceIssues:
    @respx.mock
    def test_list(self, client):
        respx.get(f"{BASE}/v1/trace-issues").mock(
            return_value=Response(200, json={"issues": [
                {"id": "ti_1", "type": "hallucination", "severity": "high"},
            ]})
        )
        issues = client.trace_issues.list()
        assert len(issues) == 1
        assert isinstance(issues[0], TraceIssue)
        client.close()

    @respx.mock
    def test_scan(self, client):
        respx.post(f"{BASE}/v1/trace-issues/scan").mock(
            return_value=Response(200, json={"scan_id": "scan_1", "status": "started", "issues_found": 0})
        )
        result = client.trace_issues.scan()
        assert isinstance(result, ScanResult)
        assert result.scan_id == "scan_1"
        client.close()

    @respx.mock
    def test_get_scan(self, client):
        respx.get(f"{BASE}/v1/trace-issues/scan/scan_1").mock(
            return_value=Response(200, json={"scan_id": "scan_1", "status": "completed", "issues_found": 5})
        )
        result = client.trace_issues.get_scan("scan_1")
        assert result.issues_found == 5
        client.close()

    @respx.mock
    def test_resolve(self, client):
        respx.put(f"{BASE}/v1/trace-issues/ti_1/resolve").mock(
            return_value=Response(200, json={"id": "ti_1", "resolved": True})
        )
        issue = client.trace_issues.resolve("ti_1")
        assert issue.resolved is True
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_scan(self, async_client):
        respx.post(f"{BASE}/v1/trace-issues/scan").mock(
            return_value=Response(200, json={"scan_id": "scan_2", "issues_found": 0})
        )
        result = await async_client.trace_issues.scan()
        assert result.scan_id == "scan_2"
        await async_client.close()


# =========================================================================
# Auto-Eval resource
# =========================================================================


class TestAutoEval:
    @respx.mock
    def test_list_configs(self, client):
        respx.get(f"{BASE}/v1/auto-eval/configs").mock(
            return_value=Response(200, json={"configs": [
                {"id": "ae_1", "name": "Nightly", "models": [], "metrics": []},
            ]})
        )
        configs = client.auto_eval.list_configs()
        assert len(configs) == 1
        assert isinstance(configs[0], AutoEvalConfig)
        client.close()

    @respx.mock
    def test_create_config(self, client):
        respx.post(f"{BASE}/v1/auto-eval/configs").mock(
            return_value=Response(200, json={
                "id": "ae_2", "name": "Weekly", "dataset_id": "ds_1",
                "models": ["gpt-4o"], "metrics": ["accuracy"],
            })
        )
        cfg = client.auto_eval.create_config(
            name="Weekly", dataset_id="ds_1", models=["gpt-4o"], metrics=["accuracy"]
        )
        assert cfg.id == "ae_2"
        client.close()

    @respx.mock
    def test_update_config(self, client):
        respx.put(f"{BASE}/v1/auto-eval/configs/ae_1").mock(
            return_value=Response(200, json={
                "id": "ae_1", "name": "Updated", "models": [], "metrics": [],
            })
        )
        cfg = client.auto_eval.update_config("ae_1", name="Updated")
        assert cfg.name == "Updated"
        client.close()

    @respx.mock
    def test_delete_config(self, client):
        respx.delete(f"{BASE}/v1/auto-eval/configs/ae_1").mock(
            return_value=Response(200, json={"deleted": True})
        )
        assert client.auto_eval.delete_config("ae_1") is True
        client.close()

    @respx.mock
    def test_suggest_metrics(self, client):
        respx.post(f"{BASE}/v1/auto-eval/suggest-metrics").mock(
            return_value=Response(200, json={"suggestions": ["accuracy", "f1"]})
        )
        result = client.auto_eval.suggest_metrics("ds_1")
        assert "suggestions" in result
        client.close()

    @respx.mock
    def test_trigger(self, client):
        respx.post(f"{BASE}/v1/auto-eval/configs/ae_1/trigger").mock(
            return_value=Response(200, json={"run_id": "r_1"})
        )
        result = client.auto_eval.trigger("ae_1")
        assert result["run_id"] == "r_1"
        client.close()

    @respx.mock
    def test_list_runs(self, client):
        respx.get(f"{BASE}/v1/auto-eval/configs/ae_1/runs").mock(
            return_value=Response(200, json={"runs": [
                {"id": "r_1", "config_id": "ae_1", "status": "completed"},
            ]})
        )
        runs = client.auto_eval.list_runs("ae_1")
        assert len(runs) == 1
        assert isinstance(runs[0], AutoEvalRun)
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_list_configs(self, async_client):
        respx.get(f"{BASE}/v1/auto-eval/configs").mock(
            return_value=Response(200, json={"configs": []})
        )
        configs = await async_client.auto_eval.list_configs()
        assert configs == []
        await async_client.close()


# =========================================================================
# Eval Agent resource
# =========================================================================


class TestEvalAgent:
    @respx.mock
    def test_analyze(self, client):
        respx.post(f"{BASE}/v1/eval-agent/analyze").mock(
            return_value=Response(200, json={"recommendations": ["add accuracy metric"]})
        )
        result = client.eval_agent.analyze("ds_1")
        assert "recommendations" in result
        client.close()

    @respx.mock
    def test_setup(self, client):
        respx.post(f"{BASE}/v1/eval-agent/setup").mock(
            return_value=Response(200, json={"config_id": "ae_1", "metrics_created": 3})
        )
        result = client.eval_agent.setup("ds_1", auto_trigger=True)
        assert result["config_id"] == "ae_1"
        client.close()

    @respx.mock
    def test_scan(self, client):
        respx.post(f"{BASE}/v1/eval-agent/scan").mock(
            return_value=Response(200, json={"findings": []})
        )
        result = client.eval_agent.scan()
        assert "findings" in result
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_analyze(self, async_client):
        respx.post(f"{BASE}/v1/eval-agent/analyze").mock(
            return_value=Response(200, json={"recommendations": []})
        )
        result = await async_client.eval_agent.analyze("ds_1")
        assert "recommendations" in result
        await async_client.close()


# =========================================================================
# Annotations resource
# =========================================================================


class TestAnnotations:
    @respx.mock
    def test_list_queues(self, client):
        respx.get(f"{BASE}/v1/annotations/queues").mock(
            return_value=Response(200, json={"queues": [
                {"id": "aq_1", "name": "Review Queue"},
            ]})
        )
        queues = client.annotations.list_queues()
        assert len(queues) == 1
        assert isinstance(queues[0], AnnotationQueue)
        client.close()

    @respx.mock
    def test_create_queue(self, client):
        respx.post(f"{BASE}/v1/annotations/queues").mock(
            return_value=Response(200, json={
                "id": "aq_2", "name": "New Queue", "dataset_id": "ds_1",
            })
        )
        q = client.annotations.create_queue(name="New Queue", dataset_id="ds_1")
        assert q.id == "aq_2"
        client.close()

    @respx.mock
    def test_delete_queue(self, client):
        respx.delete(f"{BASE}/v1/annotations/queues/aq_1").mock(
            return_value=Response(200, json={"deleted": True})
        )
        assert client.annotations.delete_queue("aq_1") is True
        client.close()

    @respx.mock
    def test_list_items(self, client):
        respx.get(f"{BASE}/v1/annotations/queues/aq_1/items").mock(
            return_value=Response(200, json={"items": [
                {"id": "ai_1", "status": "pending"},
            ]})
        )
        items = client.annotations.list_items("aq_1")
        assert len(items) == 1
        assert isinstance(items[0], AnnotationItem)
        client.close()

    @respx.mock
    def test_next_item(self, client):
        respx.get(f"{BASE}/v1/annotations/queues/aq_1/next").mock(
            return_value=Response(200, json={"id": "ai_2", "status": "pending"})
        )
        item = client.annotations.next_item("aq_1")
        assert item is not None
        assert item.id == "ai_2"
        client.close()

    @respx.mock
    def test_next_item_empty(self, client):
        respx.get(f"{BASE}/v1/annotations/queues/aq_1/next").mock(
            return_value=Response(200, json={})
        )
        item = client.annotations.next_item("aq_1")
        assert item is None
        client.close()

    @respx.mock
    def test_submit(self, client):
        respx.post(f"{BASE}/v1/annotations/queues/aq_1/items/ai_1/submit").mock(
            return_value=Response(200, json={
                "id": "ai_1", "status": "completed", "scores": {"quality": 4},
            })
        )
        item = client.annotations.submit("aq_1", "ai_1", scores={"quality": 4}, notes="Good")
        assert item.status == "completed"
        client.close()

    @respx.mock
    def test_skip(self, client):
        respx.post(f"{BASE}/v1/annotations/queues/aq_1/items/ai_1/skip").mock(
            return_value=Response(200, json={"id": "ai_1", "status": "skipped"})
        )
        item = client.annotations.skip("aq_1", "ai_1")
        assert item.status == "skipped"
        client.close()

    @respx.mock
    def test_stats(self, client):
        respx.get(f"{BASE}/v1/annotations/queues/aq_1/stats").mock(
            return_value=Response(200, json={"total": 100, "completed": 42})
        )
        result = client.annotations.stats("aq_1")
        assert result["completed"] == 42
        client.close()

    @respx.mock
    def test_export(self, client):
        respx.get(f"{BASE}/v1/annotations/queues/aq_1/export").mock(
            return_value=Response(200, json={"data": []})
        )
        result = client.annotations.export("aq_1")
        assert "data" in result
        client.close()

    @respx.mock
    def test_analytics(self, client):
        respx.get(f"{BASE}/v1/annotations/queues/aq_1/analytics").mock(
            return_value=Response(200, json={
                "queue_id": "aq_1", "total_items": 100, "completed_items": 50,
            })
        )
        analytics = client.annotations.analytics("aq_1")
        assert isinstance(analytics, AnnotationAnalytics)
        assert analytics.completed_items == 50
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_list_queues(self, async_client):
        respx.get(f"{BASE}/v1/annotations/queues").mock(
            return_value=Response(200, json={"queues": []})
        )
        queues = await async_client.annotations.list_queues()
        assert queues == []
        await async_client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_submit(self, async_client):
        respx.post(f"{BASE}/v1/annotations/queues/aq_1/items/ai_1/submit").mock(
            return_value=Response(200, json={"id": "ai_1", "status": "completed"})
        )
        item = await async_client.annotations.submit("aq_1", "ai_1", scores={"q": 5})
        assert item.status == "completed"
        await async_client.close()


# =========================================================================
# Proposals resource
# =========================================================================


class TestProposals:
    @respx.mock
    def test_list(self, client):
        respx.get(f"{BASE}/v1/proposals").mock(
            return_value=Response(200, json={"proposals": [
                {"id": "p_1", "type": "dataset_change", "status": "pending"},
            ]})
        )
        proposals = client.proposals.list()
        assert len(proposals) == 1
        assert isinstance(proposals[0], Proposal)
        client.close()

    @respx.mock
    def test_get(self, client):
        respx.get(f"{BASE}/v1/proposals/p_1").mock(
            return_value=Response(200, json={"id": "p_1", "status": "pending"})
        )
        p = client.proposals.get("p_1")
        assert p.id == "p_1"
        client.close()

    @respx.mock
    def test_approve(self, client):
        respx.post(f"{BASE}/v1/proposals/p_1/approve").mock(
            return_value=Response(200, json={"id": "p_1", "status": "approved"})
        )
        p = client.proposals.approve("p_1")
        assert p.status == "approved"
        client.close()

    @respx.mock
    def test_reject(self, client):
        respx.post(f"{BASE}/v1/proposals/p_1/reject").mock(
            return_value=Response(200, json={"id": "p_1", "status": "rejected", "reason": "Not needed"})
        )
        p = client.proposals.reject("p_1", reason="Not needed")
        assert p.status == "rejected"
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_approve(self, async_client):
        respx.post(f"{BASE}/v1/proposals/p_1/approve").mock(
            return_value=Response(200, json={"id": "p_1", "status": "approved"})
        )
        p = await async_client.proposals.approve("p_1")
        assert p.status == "approved"
        await async_client.close()


# =========================================================================
# Eval Models resource
# =========================================================================


class TestEvalModels:
    @respx.mock
    def test_available(self, client):
        respx.get(f"{BASE}/v1/models/available").mock(
            return_value=Response(200, json={"models": [
                {"id": "gpt-4o", "name": "GPT-4o"},
                {"id": "claude-3-5-sonnet", "name": "Claude 3.5 Sonnet"},
            ]})
        )
        models = client.eval_models.available()
        assert len(models) == 2
        assert models[0]["id"] == "gpt-4o"
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_available(self, async_client):
        respx.get(f"{BASE}/v1/models/available").mock(
            return_value=Response(200, json={"models": [{"id": "gpt-4o"}]})
        )
        models = await async_client.eval_models.available()
        assert len(models) == 1
        await async_client.close()


# =========================================================================
# Eval Settings resource
# =========================================================================


class TestEvalSettings:
    @respx.mock
    def test_get(self, client):
        respx.get(f"{BASE}/v1/evaluations/settings").mock(
            return_value=Response(200, json={
                "max_concurrent": 10, "default_timeout": 60,
            })
        )
        settings = client.eval_settings.get()
        assert settings["max_concurrent"] == 10
        client.close()

    @respx.mock
    def test_update(self, client):
        respx.put(f"{BASE}/v1/evaluations/settings").mock(
            return_value=Response(200, json={
                "max_concurrent": 20, "default_timeout": 60,
            })
        )
        settings = client.eval_settings.update(max_concurrent=20)
        assert settings["max_concurrent"] == 20
        client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_get(self, async_client):
        respx.get(f"{BASE}/v1/evaluations/settings").mock(
            return_value=Response(200, json={"max_concurrent": 10})
        )
        settings = await async_client.eval_settings.get()
        assert settings["max_concurrent"] == 10
        await async_client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_update(self, async_client):
        respx.put(f"{BASE}/v1/evaluations/settings").mock(
            return_value=Response(200, json={"max_concurrent": 50})
        )
        settings = await async_client.eval_settings.update(max_concurrent=50)
        assert settings["max_concurrent"] == 50
        await async_client.close()
