"""Tests for Lunar client."""

import os
import pytest

from lunar import Lunar, AsyncLunar, AuthenticationError


class TestClientInitialization:
    """Tests for client initialization."""

    def test_init_with_api_key(self):
        """Test client initialization with explicit API key."""
        client = Lunar(api_key="test-api-key")
        assert client._config.api_key == "test-api-key"
        client.close()

    def test_init_from_env_var(self, monkeypatch):
        """Test client initialization from environment variable."""
        monkeypatch.setenv("LUNAR_API_KEY", "env-api-key")
        client = Lunar()
        assert client._config.api_key == "env-api-key"
        client.close()

    def test_init_without_api_key_raises(self, monkeypatch):
        """Test that missing API key raises AuthenticationError."""
        monkeypatch.delenv("LUNAR_API_KEY", raising=False)
        with pytest.raises(AuthenticationError) as exc_info:
            Lunar()
        assert "API key not found" in str(exc_info.value)

    def test_init_with_custom_config(self):
        """Test client initialization with custom configuration."""
        client = Lunar(
            api_key="test-key",
            base_url="https://custom-api.example.com",
            timeout=30.0,
            num_retries=5,
            max_connections=50,
            fallbacks={"gpt-4o-mini": ["claude-3-haiku"]},
        )
        assert client._config.base_url == "https://custom-api.example.com"
        assert client._config.timeout == 30.0
        assert client._config.num_retries == 5
        assert client._config.max_connections == 50
        assert client._config.fallbacks == {"gpt-4o-mini": ["claude-3-haiku"]}
        client.close()

    def test_context_manager(self):
        """Test client as context manager."""
        with Lunar(api_key="test-key") as client:
            assert client._config.api_key == "test-key"
        # Client should be closed after exiting context

    def test_resources_available(self):
        """Test that all resources are available."""
        with Lunar(api_key="test-key") as client:
            assert hasattr(client, "chat")
            assert hasattr(client.chat, "completions")
            assert hasattr(client, "completions")
            assert hasattr(client, "models")
            assert hasattr(client, "providers")


class TestAsyncClientInitialization:
    """Tests for async client initialization."""

    def test_init_with_api_key(self):
        """Test async client initialization with explicit API key."""
        client = AsyncLunar(api_key="test-api-key")
        assert client._config.api_key == "test-api-key"

    def test_init_from_env_var(self, monkeypatch):
        """Test async client initialization from environment variable."""
        monkeypatch.setenv("LUNAR_API_KEY", "env-api-key")
        client = AsyncLunar()
        assert client._config.api_key == "env-api-key"

    def test_init_without_api_key_raises(self, monkeypatch):
        """Test that missing API key raises AuthenticationError."""
        monkeypatch.delenv("LUNAR_API_KEY", raising=False)
        with pytest.raises(AuthenticationError) as exc_info:
            AsyncLunar()
        assert "API key not found" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """Test async client as context manager."""
        async with AsyncLunar(api_key="test-key") as client:
            assert client._config.api_key == "test-key"
        # Client should be closed after exiting context

    def test_async_resources_available(self):
        """Test that all async resources are available."""
        client = AsyncLunar(api_key="test-key")
        assert hasattr(client, "chat")
        assert hasattr(client.chat, "completions")
        assert hasattr(client, "completions")
        assert hasattr(client, "models")
        assert hasattr(client, "providers")
