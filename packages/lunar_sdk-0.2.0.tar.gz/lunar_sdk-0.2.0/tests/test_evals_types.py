"""Tests for new evaluation types."""

import pytest
from datetime import datetime

from lunar.evals.types import (
    AnnotationAnalytics,
    AnnotationItem,
    AnnotationQueue,
    AutoCollectConfig,
    AutoEvalConfig,
    AutoEvalRun,
    EvaluationStatus,
    EvaluationStatusResponse,
    Experiment,
    Metric,
    MetricType,
    Proposal,
    ProposalStatus,
    ScanResult,
    ScriptValidationResult,
    Trace,
    TraceIssue,
)


class TestEvaluationStatusEnum:
    """Tests for updated EvaluationStatus enum."""

    def test_queued_status(self):
        assert EvaluationStatus.QUEUED == "queued"

    def test_starting_status(self):
        assert EvaluationStatus.STARTING == "starting"

    def test_all_statuses_present(self):
        expected = {"pending", "queued", "starting", "running", "completed", "failed", "cancelled"}
        actual = {s.value for s in EvaluationStatus}
        assert actual == expected


class TestEvaluationStatusResponse:
    def test_basic(self):
        resp = EvaluationStatusResponse(id="eval_1", status=EvaluationStatus.RUNNING)
        assert resp.id == "eval_1"
        assert resp.status == EvaluationStatus.RUNNING

    def test_extra_fields_allowed(self):
        resp = EvaluationStatusResponse(
            id="eval_1", status="running", extra_field="hello"
        )
        assert resp.extra_field == "hello"


class TestExperiment:
    def test_basic(self):
        exp = Experiment(id="exp_1", name="Test Experiment")
        assert exp.id == "exp_1"
        assert exp.name == "Test Experiment"
        assert exp.evaluation_ids == []

    def test_full(self):
        exp = Experiment(
            id="exp_1",
            name="Full",
            dataset_id="ds_1",
            evaluation_ids=["eval_1", "eval_2"],
            status="completed",
        )
        assert exp.dataset_id == "ds_1"
        assert len(exp.evaluation_ids) == 2

    def test_extra_fields(self):
        exp = Experiment(id="exp_1", name="Test", unknown_field=42)
        assert exp.unknown_field == 42


class TestMetric:
    def test_basic(self):
        m = Metric(id="m_1", name="Accuracy", type=MetricType.BUILTIN)
        assert m.id == "m_1"
        assert m.type == MetricType.BUILTIN

    def test_custom_type(self):
        m = Metric(id="m_2", name="Custom", type="custom", python_script="def score(): pass")
        assert m.type == MetricType.CUSTOM
        assert m.python_script is not None


class TestMetricType:
    def test_values(self):
        assert MetricType.BUILTIN == "builtin"
        assert MetricType.CUSTOM == "custom"
        assert MetricType.LLM_JUDGE == "llm_judge"


class TestScriptValidationResult:
    def test_valid(self):
        r = ScriptValidationResult(valid=True)
        assert r.valid is True
        assert r.errors == []

    def test_invalid(self):
        r = ScriptValidationResult(valid=False, errors=["syntax error"])
        assert r.valid is False
        assert len(r.errors) == 1


class TestTrace:
    def test_basic(self):
        t = Trace(id="tr_1", input="Hello", output="Hi")
        assert t.id == "tr_1"
        assert t.input == "Hello"

    def test_dict_input(self):
        t = Trace(id="tr_2", input={"messages": [{"role": "user", "content": "Hi"}]})
        assert isinstance(t.input, dict)


class TestTraceIssue:
    def test_basic(self):
        issue = TraceIssue(id="ti_1", type="hallucination", severity="high")
        assert issue.id == "ti_1"
        assert issue.resolved is False

    def test_resolved(self):
        issue = TraceIssue(id="ti_1", resolved=True)
        assert issue.resolved is True


class TestScanResult:
    def test_basic(self):
        sr = ScanResult(scan_id="scan_1", issues_found=3)
        assert sr.scan_id == "scan_1"
        assert sr.issues_found == 3
        assert sr.issues == []


class TestAutoEvalConfig:
    def test_basic(self):
        cfg = AutoEvalConfig(
            id="ae_1",
            name="Nightly Eval",
            models=["gpt-4o"],
            metrics=["accuracy"],
        )
        assert cfg.id == "ae_1"
        assert cfg.enabled is True


class TestAutoEvalRun:
    def test_basic(self):
        run = AutoEvalRun(id="aer_1", config_id="ae_1", status="completed")
        assert run.config_id == "ae_1"


class TestAnnotationQueue:
    def test_basic(self):
        q = AnnotationQueue(id="aq_1", name="Review Queue")
        assert q.total_items == 0


class TestAnnotationItem:
    def test_basic(self):
        item = AnnotationItem(id="ai_1", status="pending")
        assert item.id == "ai_1"


class TestAnnotationAnalytics:
    def test_basic(self):
        a = AnnotationAnalytics(queue_id="aq_1", total_items=100, completed_items=50)
        assert a.completed_items == 50


class TestProposal:
    def test_basic(self):
        p = Proposal(id="p_1", type="dataset_update")
        assert p.status == ProposalStatus.PENDING

    def test_approved(self):
        p = Proposal(id="p_1", status="approved")
        assert p.status == ProposalStatus.APPROVED


class TestProposalStatus:
    def test_values(self):
        assert ProposalStatus.PENDING == "pending"
        assert ProposalStatus.APPROVED == "approved"
        assert ProposalStatus.REJECTED == "rejected"


class TestAutoCollectConfig:
    def test_basic(self):
        cfg = AutoCollectConfig(dataset_id="ds_1", enabled=True, sample_rate=0.5)
        assert cfg.enabled is True
        assert cfg.sample_rate == 0.5
