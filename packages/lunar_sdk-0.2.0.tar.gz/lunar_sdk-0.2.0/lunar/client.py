"""Lunar SDK client."""

from __future__ import annotations

import os
from typing import Dict, List, Optional

from ._config import (
    DEFAULT_BASE_URL,
    DEFAULT_ENVIRONMENT,
    DEFAULT_EVALS_API_URL,
    DEFAULT_MAX_CONNECTIONS,
    DEFAULT_NUM_RETRIES,
    DEFAULT_RAG_API_URL,
    DEFAULT_TIMEOUT,
    ENV_VAR_API_KEY,
    ENV_VAR_ENVIRONMENT,
    ENV_VAR_JWT,
    ENV_VAR_RAG_API_URL,
    ENVIRONMENTS,
    LunarConfig,
    get_environment_urls,
)
from ._exceptions import AuthenticationError
from ._http import AsyncHTTPClient, HTTPClient
from .resources.annotations import Annotations, AsyncAnnotations
from .resources.auto_eval import AsyncAutoEval, AutoEval
from .resources.chat import AsyncChat, Chat
from .resources.completions import AsyncTextCompletions, TextCompletions
from .resources.datasets import AsyncDatasets, Datasets
from .resources.eval_agent import AsyncEvalAgent, EvalAgent
from .resources.eval_models import AsyncEvalModels, EvalModels
from .resources.eval_settings import AsyncEvalSettings, EvalSettings
from .resources.evaluations import AsyncEvaluations, Evaluations
from .resources.experiments import AsyncExperiments, Experiments
from .resources.metrics import AsyncMetrics, Metrics
from .resources.models import AsyncModels, AsyncProviders, Models, Providers
from .resources.proposals import AsyncProposals, Proposals
from .resources.rag import AsyncRAG, RAG
from .resources.trace_issues import AsyncTraceIssues, TraceIssues
from .resources.traces import AsyncTraces, Traces


class Lunar:
    """Synchronous Lunar client.

    Supports two authentication methods (mutually exclusive):
    - API Key: Use `api_key` parameter or LUNAR_API_KEY environment variable
    - JWT: Use `jwt` parameter or LUNAR_JWT environment variable

    Example:
        >>> from lunar import Lunar
        >>> client = Lunar()  # Uses LUNAR_API_KEY env var, defaults to 'prod'
        >>> response = client.chat.completions.create(
        ...     model="gpt-4o-mini",
        ...     messages=[{"role": "user", "content": "Hello!"}]
        ... )
        >>> print(response.choices[0].message.content)

        >>> # With development environment
        >>> client = Lunar(api_key="...", environment="dev")

        >>> # With JWT authentication
        >>> client = Lunar(jwt="eyJhbG...")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        jwt: Optional[str] = None,
        *,
        environment: Optional[str] = None,
        base_url: Optional[str] = None,
        rag_api_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        num_retries: int = DEFAULT_NUM_RETRIES,
        max_connections: int = DEFAULT_MAX_CONNECTIONS,
        fallbacks: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        """Initialize Lunar client.

        Args:
            api_key: API key for authentication. If not provided, reads from
                LUNAR_API_KEY environment variable. Mutually exclusive with jwt.
            jwt: JWT token for authentication. If not provided, reads from
                LUNAR_JWT environment variable. Mutually exclusive with api_key.
            environment: Environment to use ('dev' or 'prod'). If not provided,
                reads from LUNAR_ENV environment variable, defaults to 'prod'.
                Ignored if base_url is explicitly provided.
            base_url: Base URL for the API. Overrides environment setting.
            rag_api_url: Base URL for RAG API. If not provided, reads from
                LUNAR_RAG_API_URL environment variable or uses environment default.
            timeout: Request timeout in seconds
            num_retries: Number of retries for failed requests
            max_connections: Maximum number of concurrent connections
            fallbacks: Optional dict mapping model names to fallback model lists

        Raises:
            AuthenticationError: If no authentication is provided
            ValueError: If both api_key and jwt are provided
        """
        # Check for mutual exclusivity
        if api_key and jwt:
            raise ValueError(
                "Cannot use both api_key and jwt. Choose one authentication method."
            )

        # Get credentials from parameters or environment
        resolved_api_key = api_key or os.environ.get(ENV_VAR_API_KEY)
        resolved_jwt = jwt or os.environ.get(ENV_VAR_JWT)

        # Validate that we have at least one auth method
        if not resolved_api_key and not resolved_jwt:
            raise AuthenticationError(
                f"Authentication required. Either pass api_key/jwt parameter or set "
                f"{ENV_VAR_API_KEY} or {ENV_VAR_JWT} environment variable."
            )

        # If both env vars are set, prefer API key
        if resolved_api_key and resolved_jwt and not api_key and not jwt:
            resolved_jwt = None  # Use API key by default

        # Resolve environment and URLs
        if base_url:
            # Explicit base_url overrides environment — use it for all API URLs
            resolved_base_url = base_url
            resolved_evals_url = base_url
            resolved_rag_url = rag_api_url or os.environ.get(ENV_VAR_RAG_API_URL, base_url)
        else:
            # Use environment to determine URLs
            resolved_env = environment or os.environ.get(ENV_VAR_ENVIRONMENT, DEFAULT_ENVIRONMENT)
            env_urls = get_environment_urls(resolved_env)
            resolved_base_url = env_urls["base_url"]
            resolved_evals_url = env_urls["evals_api_url"]
            resolved_rag_url = rag_api_url or os.environ.get(ENV_VAR_RAG_API_URL, env_urls["rag_api_url"])

        self._config = LunarConfig(
            api_key=resolved_api_key if not resolved_jwt else None,
            jwt=resolved_jwt if not resolved_api_key else None,
            base_url=resolved_base_url,
            evals_api_url=resolved_evals_url,
            rag_api_url=resolved_rag_url,
            timeout=timeout,
            num_retries=num_retries,
            max_connections=max_connections,
            fallbacks=fallbacks or {},
        )

        self._http = HTTPClient(self._config)

        # Create a dedicated HTTP client for the evaluations API
        evals_config = LunarConfig(
            api_key=self._config.api_key,
            jwt=self._config.jwt,
            base_url=resolved_evals_url,
            evals_api_url=resolved_evals_url,
            rag_api_url=self._config.rag_api_url,
            timeout=self._config.timeout,
            num_retries=self._config.num_retries,
            max_connections=self._config.max_connections,
            fallbacks=self._config.fallbacks,
        )
        self._evals_http = HTTPClient(evals_config)

        # Initialize resources
        self._chat = Chat(self._http, self._config)
        self._completions = TextCompletions(self._http, self._config)
        self._models = Models(self._http, self._config)
        self._providers = Providers(self._http, self._config)
        self._evals = Evaluations(self._evals_http, self._config, self)
        self._datasets = Datasets(self._evals_http, self._config)
        self._rag = RAG(self._http, self._config, self)
        self._experiments = Experiments(self._evals_http, self._config)
        self._metrics = Metrics(self._evals_http, self._config)
        self._traces = Traces(self._evals_http, self._config)
        self._trace_issues = TraceIssues(self._evals_http, self._config)
        self._auto_eval = AutoEval(self._evals_http, self._config)
        self._eval_agent = EvalAgent(self._evals_http, self._config)
        self._annotations = Annotations(self._evals_http, self._config)
        self._proposals = Proposals(self._evals_http, self._config)
        self._eval_models = EvalModels(self._evals_http, self._config)
        self._eval_settings = EvalSettings(self._evals_http, self._config)

    @property
    def chat(self) -> Chat:
        """Get chat resource for chat completions."""
        return self._chat

    @property
    def completions(self) -> TextCompletions:
        """Get completions resource for text completions."""
        return self._completions

    @property
    def models(self) -> Models:
        """Get models resource for listing models."""
        return self._models

    @property
    def providers(self) -> Providers:
        """Get providers resource for listing providers."""
        return self._providers

    @property
    def evals(self) -> Evaluations:
        """Get evaluations resource for running evaluations."""
        return self._evals

    @property
    def datasets(self) -> Datasets:
        """Get datasets resource for managing evaluation datasets."""
        return self._datasets

    @property
    def rag(self) -> RAG:
        """Get RAG resource for document retrieval and ingestion."""
        return self._rag

    @property
    def experiments(self) -> Experiments:
        """Get experiments resource for comparing evaluations."""
        return self._experiments

    @property
    def metrics(self) -> Metrics:
        """Get metrics resource for managing evaluation metrics."""
        return self._metrics

    @property
    def traces(self) -> Traces:
        """Get traces resource for recording LLM interactions."""
        return self._traces

    @property
    def trace_issues(self) -> TraceIssues:
        """Get trace issues resource for quality analysis."""
        return self._trace_issues

    @property
    def auto_eval(self) -> AutoEval:
        """Get auto-eval resource for automatic evaluations."""
        return self._auto_eval

    @property
    def eval_agent(self) -> EvalAgent:
        """Get eval agent resource for AI-driven evaluation setup."""
        return self._eval_agent

    @property
    def annotations(self) -> Annotations:
        """Get annotations resource for human annotation."""
        return self._annotations

    @property
    def proposals(self) -> Proposals:
        """Get proposals resource for evaluation change proposals."""
        return self._proposals

    @property
    def eval_models(self) -> EvalModels:
        """Get eval models resource for available evaluation models."""
        return self._eval_models

    @property
    def eval_settings(self) -> EvalSettings:
        """Get eval settings resource for platform settings."""
        return self._eval_settings

    def close(self) -> None:
        """Close the client and release resources."""
        self._http.close()
        self._evals_http.close()

    def __enter__(self) -> Lunar:
        """Enter context manager."""
        return self

    def __exit__(self, *args) -> None:
        """Exit context manager."""
        self.close()


class AsyncLunar:
    """Asynchronous Lunar client.

    Supports two authentication methods (mutually exclusive):
    - API Key: Use `api_key` parameter or LUNAR_API_KEY environment variable
    - JWT: Use `jwt` parameter or LUNAR_JWT environment variable

    Example:
        >>> from lunar import AsyncLunar
        >>> async with AsyncLunar() as client:  # Uses 'prod' environment
        ...     response = await client.chat.completions.create(
        ...         model="gpt-4o-mini",
        ...         messages=[{"role": "user", "content": "Hello!"}]
        ...     )
        ...     print(response.choices[0].message.content)

        >>> # With development environment
        >>> async with AsyncLunar(api_key="...", environment="dev") as client:
        ...     ...

        >>> # With JWT authentication
        >>> async with AsyncLunar(jwt="eyJhbG...") as client:
        ...     ...
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        jwt: Optional[str] = None,
        *,
        environment: Optional[str] = None,
        base_url: Optional[str] = None,
        rag_api_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        num_retries: int = DEFAULT_NUM_RETRIES,
        max_connections: int = DEFAULT_MAX_CONNECTIONS,
        fallbacks: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        """Initialize async Lunar client.

        Args:
            api_key: API key for authentication. If not provided, reads from
                LUNAR_API_KEY environment variable. Mutually exclusive with jwt.
            jwt: JWT token for authentication. If not provided, reads from
                LUNAR_JWT environment variable. Mutually exclusive with api_key.
            environment: Environment to use ('dev' or 'prod'). If not provided,
                reads from LUNAR_ENV environment variable, defaults to 'prod'.
                Ignored if base_url is explicitly provided.
            base_url: Base URL for the API. Overrides environment setting.
            rag_api_url: Base URL for RAG API. If not provided, reads from
                LUNAR_RAG_API_URL environment variable or uses environment default.
            timeout: Request timeout in seconds
            num_retries: Number of retries for failed requests
            max_connections: Maximum number of concurrent connections
            fallbacks: Optional dict mapping model names to fallback model lists

        Raises:
            AuthenticationError: If no authentication is provided
            ValueError: If both api_key and jwt are provided
        """
        # Check for mutual exclusivity
        if api_key and jwt:
            raise ValueError(
                "Cannot use both api_key and jwt. Choose one authentication method."
            )

        # Get credentials from parameters or environment
        resolved_api_key = api_key or os.environ.get(ENV_VAR_API_KEY)
        resolved_jwt = jwt or os.environ.get(ENV_VAR_JWT)

        # Validate that we have at least one auth method
        if not resolved_api_key and not resolved_jwt:
            raise AuthenticationError(
                f"Authentication required. Either pass api_key/jwt parameter or set "
                f"{ENV_VAR_API_KEY} or {ENV_VAR_JWT} environment variable."
            )

        # If both env vars are set, prefer API key
        if resolved_api_key and resolved_jwt and not api_key and not jwt:
            resolved_jwt = None  # Use API key by default

        # Resolve environment and URLs
        if base_url:
            # Explicit base_url overrides environment — use it for all API URLs
            resolved_base_url = base_url
            resolved_evals_url = base_url
            resolved_rag_url = rag_api_url or os.environ.get(ENV_VAR_RAG_API_URL, base_url)
        else:
            # Use environment to determine URLs
            resolved_env = environment or os.environ.get(ENV_VAR_ENVIRONMENT, DEFAULT_ENVIRONMENT)
            env_urls = get_environment_urls(resolved_env)
            resolved_base_url = env_urls["base_url"]
            resolved_evals_url = env_urls["evals_api_url"]
            resolved_rag_url = rag_api_url or os.environ.get(ENV_VAR_RAG_API_URL, env_urls["rag_api_url"])

        self._config = LunarConfig(
            api_key=resolved_api_key if not resolved_jwt else None,
            jwt=resolved_jwt if not resolved_api_key else None,
            base_url=resolved_base_url,
            evals_api_url=resolved_evals_url,
            rag_api_url=resolved_rag_url,
            timeout=timeout,
            num_retries=num_retries,
            max_connections=max_connections,
            fallbacks=fallbacks or {},
        )

        self._http = AsyncHTTPClient(self._config)

        # Create a dedicated HTTP client for the evaluations API
        evals_config = LunarConfig(
            api_key=self._config.api_key,
            jwt=self._config.jwt,
            base_url=resolved_evals_url,
            evals_api_url=resolved_evals_url,
            rag_api_url=self._config.rag_api_url,
            timeout=self._config.timeout,
            num_retries=self._config.num_retries,
            max_connections=self._config.max_connections,
            fallbacks=self._config.fallbacks,
        )
        self._evals_http = AsyncHTTPClient(evals_config)

        # Initialize resources
        self._chat = AsyncChat(self._http, self._config)
        self._completions = AsyncTextCompletions(self._http, self._config)
        self._models = AsyncModels(self._http, self._config)
        self._providers = AsyncProviders(self._http, self._config)
        self._evals = AsyncEvaluations(self._evals_http, self._config, self)
        self._datasets = AsyncDatasets(self._evals_http, self._config)
        self._rag = AsyncRAG(self._http, self._config, self)
        self._experiments = AsyncExperiments(self._evals_http, self._config)
        self._metrics = AsyncMetrics(self._evals_http, self._config)
        self._traces = AsyncTraces(self._evals_http, self._config)
        self._trace_issues = AsyncTraceIssues(self._evals_http, self._config)
        self._auto_eval = AsyncAutoEval(self._evals_http, self._config)
        self._eval_agent = AsyncEvalAgent(self._evals_http, self._config)
        self._annotations = AsyncAnnotations(self._evals_http, self._config)
        self._proposals = AsyncProposals(self._evals_http, self._config)
        self._eval_models = AsyncEvalModels(self._evals_http, self._config)
        self._eval_settings = AsyncEvalSettings(self._evals_http, self._config)

    @property
    def chat(self) -> AsyncChat:
        """Get async chat resource for chat completions."""
        return self._chat

    @property
    def completions(self) -> AsyncTextCompletions:
        """Get async completions resource for text completions."""
        return self._completions

    @property
    def models(self) -> AsyncModels:
        """Get async models resource for listing models."""
        return self._models

    @property
    def providers(self) -> AsyncProviders:
        """Get async providers resource for listing providers."""
        return self._providers

    @property
    def evals(self) -> AsyncEvaluations:
        """Get async evaluations resource for running evaluations."""
        return self._evals

    @property
    def datasets(self) -> AsyncDatasets:
        """Get async datasets resource for managing evaluation datasets."""
        return self._datasets

    @property
    def rag(self) -> AsyncRAG:
        """Get async RAG resource for document retrieval and ingestion."""
        return self._rag

    @property
    def experiments(self) -> AsyncExperiments:
        """Get async experiments resource for comparing evaluations."""
        return self._experiments

    @property
    def metrics(self) -> AsyncMetrics:
        """Get async metrics resource for managing evaluation metrics."""
        return self._metrics

    @property
    def traces(self) -> AsyncTraces:
        """Get async traces resource for recording LLM interactions."""
        return self._traces

    @property
    def trace_issues(self) -> AsyncTraceIssues:
        """Get async trace issues resource for quality analysis."""
        return self._trace_issues

    @property
    def auto_eval(self) -> AsyncAutoEval:
        """Get async auto-eval resource for automatic evaluations."""
        return self._auto_eval

    @property
    def eval_agent(self) -> AsyncEvalAgent:
        """Get async eval agent resource for AI-driven evaluation setup."""
        return self._eval_agent

    @property
    def annotations(self) -> AsyncAnnotations:
        """Get async annotations resource for human annotation."""
        return self._annotations

    @property
    def proposals(self) -> AsyncProposals:
        """Get async proposals resource for evaluation change proposals."""
        return self._proposals

    @property
    def eval_models(self) -> AsyncEvalModels:
        """Get async eval models resource for available evaluation models."""
        return self._eval_models

    @property
    def eval_settings(self) -> AsyncEvalSettings:
        """Get async eval settings resource for platform settings."""
        return self._eval_settings

    async def close(self) -> None:
        """Close the client and release resources."""
        await self._http.close()
        await self._evals_http.close()

    async def __aenter__(self) -> AsyncLunar:
        """Enter async context manager."""
        return self

    async def __aexit__(self, *args) -> None:
        """Exit async context manager."""
        await self.close()
