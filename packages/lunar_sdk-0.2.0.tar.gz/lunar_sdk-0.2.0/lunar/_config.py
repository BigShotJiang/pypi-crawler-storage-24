"""Lunar SDK configuration."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional


# Environment variable names
ENV_VAR_API_KEY = "LUNAR_API_KEY"
ENV_VAR_JWT = "LUNAR_JWT"
ENV_VAR_ENVIRONMENT = "LUNAR_ENV"

# Environment variable for RAG API URL override
ENV_VAR_RAG_API_URL = "LUNAR_RAG_API_URL"

# Environment URLs
ENVIRONMENTS = {
    "dev": {
        "base_url": "https://dev-api.lunar-sys.com",
        "evals_api_url": "https://dev-api.lunar-sys.com",
        "rag_api_url": "https://dev-api.lunar-sys.com",
    },
    "prod": {
        "base_url": "https://api.lunar-sys.com",
        "evals_api_url": "https://api.lunar-sys.com",
        "rag_api_url": "https://api.lunar-sys.com",
    },
}

# Default configuration values
DEFAULT_ENVIRONMENT = "prod"
DEFAULT_BASE_URL = ENVIRONMENTS[DEFAULT_ENVIRONMENT]["base_url"]
DEFAULT_EVALS_API_URL = ENVIRONMENTS[DEFAULT_ENVIRONMENT]["evals_api_url"]
DEFAULT_RAG_API_URL = ENVIRONMENTS[DEFAULT_ENVIRONMENT]["rag_api_url"]
DEFAULT_TIMEOUT = 60.0
DEFAULT_NUM_RETRIES = 2
DEFAULT_MAX_CONNECTIONS = 100


def get_environment_urls(env: str = "dev") -> Dict[str, str]:
    """Get URLs for a specific environment.

    Args:
        env: Environment name ('dev' or 'prod')

    Returns:
        Dict with 'base_url', 'evals_api_url', and 'rag_api_url' keys

    Raises:
        ValueError: If environment is not recognized
    """
    env = env.lower()
    if env not in ENVIRONMENTS:
        raise ValueError(f"Unknown environment: {env}. Use 'dev' or 'prod'.")
    return ENVIRONMENTS[env]


@dataclass
class LunarConfig:
    """Configuration for Lunar client.

    Supports two authentication methods (mutually exclusive):
    - API Key: Use `api_key` parameter or LUNAR_API_KEY environment variable
    - JWT: Use `jwt` parameter or LUNAR_JWT environment variable

    Attributes:
        api_key: API key for authentication (mutually exclusive with jwt)
        jwt: JWT token for authentication (mutually exclusive with api_key)
        base_url: Base URL for the LLM inference API
        evals_api_url: Base URL for the evaluations API (for logging evaluation results)
        rag_api_url: Base URL for the RAG API (for document retrieval and ingestion)
        timeout: Request timeout in seconds
        num_retries: Number of retries for failed requests (only for fallback-able errors)
        max_connections: Maximum number of concurrent connections
        fallbacks: Optional dict mapping model names to fallback model lists
    """

    api_key: Optional[str] = None
    jwt: Optional[str] = None
    base_url: str = DEFAULT_BASE_URL
    evals_api_url: str = DEFAULT_EVALS_API_URL
    rag_api_url: str = DEFAULT_RAG_API_URL
    timeout: float = DEFAULT_TIMEOUT
    num_retries: int = DEFAULT_NUM_RETRIES
    max_connections: int = DEFAULT_MAX_CONNECTIONS
    fallbacks: Dict[str, List[str]] = field(default_factory=dict)

    def __post_init__(self):
        """Validate authentication configuration."""
        if self.api_key and self.jwt:
            raise ValueError(
                "Cannot use both api_key and jwt. Choose one authentication method."
            )
        if not self.api_key and not self.jwt:
            raise ValueError(
                "Authentication required. Provide api_key or jwt parameter, "
                f"or set {ENV_VAR_API_KEY} or {ENV_VAR_JWT} environment variable."
            )

    @property
    def auth_type(self) -> str:
        """Return the authentication type being used."""
        return "jwt" if self.jwt else "api_key"

    @property
    def headers(self) -> Dict[str, str]:
        """Return headers for API requests."""
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "lunar-python/0.2.0",
        }

        if self.api_key:
            headers["x-api-key"] = self.api_key
        elif self.jwt:
            headers["Authorization"] = f"Bearer {self.jwt}"

        return headers

    def get_fallbacks(self, model: str) -> List[str]:
        """Get fallback models for a given model.

        Args:
            model: The primary model name

        Returns:
            List of fallback model names, or empty list if none configured
        """
        return self.fallbacks.get(model, [])
