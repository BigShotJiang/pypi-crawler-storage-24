"""Chat completions resource."""

from __future__ import annotations

import logging
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncIterator,
    Dict,
    Iterator,
    List,
    Literal,
    Optional,
    Union,
    overload,
)

from ..types.chat import ChatCompletion, ChatCompletionChunk, ChatMessage, MessageInput
from .._exceptions import FALLBACK_ERRORS, NON_FALLBACK_ERRORS

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient
    from .._config import LunarConfig

logger = logging.getLogger(__name__)


class Stream:
    """Synchronous stream wrapper for chat completions."""

    def __init__(self, iterator: Iterator[Dict[str, Any]]) -> None:
        self._iterator = iterator

    def __iter__(self) -> Iterator[ChatCompletionChunk]:
        for chunk in self._iterator:
            yield ChatCompletionChunk.model_validate(chunk)

    def __enter__(self) -> "Stream":
        return self

    def __exit__(self, *args: Any) -> None:
        pass


class AsyncStream:
    """Asynchronous stream wrapper for chat completions."""

    def __init__(self, iterator: AsyncIterator[Dict[str, Any]]) -> None:
        self._iterator = iterator

    async def __aiter__(self) -> AsyncIterator[ChatCompletionChunk]:
        async for chunk in self._iterator:
            yield ChatCompletionChunk.model_validate(chunk)

    async def __aenter__(self) -> "AsyncStream":
        return self

    async def __aexit__(self, *args: Any) -> None:
        pass


def _normalize_messages(messages: List[MessageInput]) -> List[Dict[str, Any]]:
    """Convert messages to API format.

    Args:
        messages: List of ChatMessage objects or dicts

    Returns:
        List of message dicts for the API
    """
    result = []
    for msg in messages:
        if isinstance(msg, ChatMessage):
            d = msg.model_dump(exclude_none=True)
            result.append(d)
        elif isinstance(msg, dict):
            # Pass through all fields (role, content, tool_calls, tool_call_id, name, etc.)
            d = {k: v for k, v in msg.items() if v is not None}
            result.append(d)
        else:
            raise TypeError(f"Invalid message type: {type(msg)}")
    return result


class Completions:
    """Synchronous chat completions resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        """Initialize completions resource.

        Args:
            http: HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    @overload
    def create(
        self,
        *,
        model: str,
        messages: List[MessageInput],
        stream: Literal[True],
        fallbacks: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Stream: ...

    @overload
    def create(
        self,
        *,
        model: str,
        messages: List[MessageInput],
        stream: Literal[False] = False,
        fallbacks: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    @overload
    def create(
        self,
        *,
        model: str,
        messages: List[MessageInput],
        fallbacks: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    def create(
        self,
        *,
        model: str,
        messages: List[MessageInput],
        stream: bool = False,
        fallbacks: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Union[ChatCompletion, Stream]:
        """Create a chat completion.

        Args:
            model: Model to use for completion
            messages: List of messages in the conversation
            stream: Whether to stream the response
            fallbacks: Optional list of fallback models to try on failure
            **kwargs: Additional parameters to pass to the API

        Returns:
            ChatCompletion response or Stream for streaming

        Raises:
            APIError: If all models fail
        """
        # Combine config fallbacks with request-level fallbacks
        all_fallbacks = fallbacks or self._config.get_fallbacks(model)
        models_to_try = [model] + all_fallbacks

        normalized_messages = _normalize_messages(messages)
        last_error: Optional[Exception] = None

        for i, current_model in enumerate(models_to_try):
            try:
                return self._make_request(
                    current_model, normalized_messages, stream=stream, **kwargs
                )
            except NON_FALLBACK_ERRORS:
                # Client errors - don't try fallback
                raise
            except FALLBACK_ERRORS as e:
                # Server/infra errors - try fallback
                last_error = e
                is_last = i == len(models_to_try) - 1

                if is_last:
                    logger.error(f"All models failed. Last error: {e}")
                    raise
                else:
                    logger.warning(
                        f"Model {current_model} failed with {type(e).__name__}, "
                        f"trying fallback: {models_to_try[i + 1]}"
                    )
                    continue

        # Should not reach here, but just in case
        if last_error:
            raise last_error
        raise RuntimeError("Request failed with unknown error")

    def _make_request(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ChatCompletion, Stream]:
        """Make the actual API request.

        Args:
            model: Model to use
            messages: Normalized messages
            stream: Whether to stream the response
            **kwargs: Additional parameters

        Returns:
            ChatCompletion response or Stream
        """
        payload: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": stream,
            **kwargs,
        }

        if stream:
            iterator = self._http.post_stream("/v1/chat/completions", json_body=payload)
            return Stream(iterator)

        response = self._http.post("/v1/chat/completions", json=payload)
        return ChatCompletion.model_validate(response)


class AsyncCompletions:
    """Asynchronous chat completions resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        """Initialize async completions resource.

        Args:
            http: Async HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    @overload
    async def create(
        self,
        *,
        model: str,
        messages: List[MessageInput],
        stream: Literal[True],
        fallbacks: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> AsyncStream: ...

    @overload
    async def create(
        self,
        *,
        model: str,
        messages: List[MessageInput],
        stream: Literal[False] = False,
        fallbacks: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    @overload
    async def create(
        self,
        *,
        model: str,
        messages: List[MessageInput],
        fallbacks: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    async def create(
        self,
        *,
        model: str,
        messages: List[MessageInput],
        stream: bool = False,
        fallbacks: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Union[ChatCompletion, AsyncStream]:
        """Create a chat completion.

        Args:
            model: Model to use for completion
            messages: List of messages in the conversation
            stream: Whether to stream the response
            fallbacks: Optional list of fallback models to try on failure
            **kwargs: Additional parameters to pass to the API

        Returns:
            ChatCompletion response or AsyncStream for streaming

        Raises:
            APIError: If all models fail
        """
        # Combine config fallbacks with request-level fallbacks
        all_fallbacks = fallbacks or self._config.get_fallbacks(model)
        models_to_try = [model] + all_fallbacks

        normalized_messages = _normalize_messages(messages)
        last_error: Optional[Exception] = None

        for i, current_model in enumerate(models_to_try):
            try:
                return await self._make_request(
                    current_model, normalized_messages, stream=stream, **kwargs
                )
            except NON_FALLBACK_ERRORS:
                # Client errors - don't try fallback
                raise
            except FALLBACK_ERRORS as e:
                # Server/infra errors - try fallback
                last_error = e
                is_last = i == len(models_to_try) - 1

                if is_last:
                    logger.error(f"All models failed. Last error: {e}")
                    raise
                else:
                    logger.warning(
                        f"Model {current_model} failed with {type(e).__name__}, "
                        f"trying fallback: {models_to_try[i + 1]}"
                    )
                    continue

        # Should not reach here, but just in case
        if last_error:
            raise last_error
        raise RuntimeError("Request failed with unknown error")

    async def _make_request(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ChatCompletion, AsyncStream]:
        """Make the actual API request.

        Args:
            model: Model to use
            messages: Normalized messages
            stream: Whether to stream the response
            **kwargs: Additional parameters

        Returns:
            ChatCompletion response or AsyncStream
        """
        payload: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": stream,
            **kwargs,
        }

        if stream:
            iterator = self._http.post_stream("/v1/chat/completions", json_body=payload)
            return AsyncStream(iterator)

        response = await self._http.post("/v1/chat/completions", json=payload)
        return ChatCompletion.model_validate(response)


class Chat:
    """Synchronous chat resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        """Initialize chat resource.

        Args:
            http: HTTP client
            config: Lunar configuration
        """
        self._completions = Completions(http, config)

    @property
    def completions(self) -> Completions:
        """Get completions resource."""
        return self._completions


class AsyncChat:
    """Asynchronous chat resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        """Initialize async chat resource.

        Args:
            http: Async HTTP client
            config: Lunar configuration
        """
        self._completions = AsyncCompletions(http, config)

    @property
    def completions(self) -> AsyncCompletions:
        """Get async completions resource."""
        return self._completions
