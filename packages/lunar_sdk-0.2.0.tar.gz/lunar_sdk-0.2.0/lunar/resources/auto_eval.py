"""Auto-eval resource for managing automatic evaluation configurations."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..evals.types import AutoEvalConfig, AutoEvalRun


class AutoEval:
    """Synchronous auto-eval resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def list_configs(self) -> List[AutoEvalConfig]:
        """List auto-eval configurations.

        Returns:
            List of AutoEvalConfig
        """
        response = self._http.get("/v1/auto-eval/configs")
        return [AutoEvalConfig(**c) for c in response.get("configs", [])]

    def create_config(
        self,
        name: str,
        dataset_id: str,
        models: List[str],
        metrics: List[str],
        **kwargs: Any,
    ) -> AutoEvalConfig:
        """Create an auto-eval configuration.

        Args:
            name: Config name
            dataset_id: Dataset ID
            models: Model identifiers
            metrics: Metric identifiers
            **kwargs: Additional fields (schedule, enabled)

        Returns:
            Created AutoEvalConfig
        """
        body: Dict[str, Any] = {
            "name": name,
            "dataset_id": dataset_id,
            "models": models,
            "metrics": metrics,
            **kwargs,
        }
        response = self._http.post("/v1/auto-eval/configs", json=body)
        return AutoEvalConfig(**response)

    def update_config(self, config_id: str, **kwargs: Any) -> AutoEvalConfig:
        """Update an auto-eval configuration.

        Args:
            config_id: Config ID
            **kwargs: Fields to update

        Returns:
            Updated AutoEvalConfig
        """
        response = self._http.put(f"/v1/auto-eval/configs/{config_id}", json=kwargs)
        return AutoEvalConfig(**response)

    def delete_config(self, config_id: str) -> bool:
        """Delete an auto-eval configuration.

        Args:
            config_id: Config ID

        Returns:
            True if deleted
        """
        self._http.delete(f"/v1/auto-eval/configs/{config_id}")
        return True

    def suggest_metrics(self, dataset_id: str) -> Dict[str, Any]:
        """Get metric suggestions for a dataset.

        Args:
            dataset_id: Dataset ID

        Returns:
            Suggested metrics
        """
        return self._http.post(
            "/v1/auto-eval/suggest-metrics",
            json={"dataset_id": dataset_id},
        )

    def trigger(self, config_id: str) -> Dict[str, Any]:
        """Manually trigger an auto-eval run.

        Args:
            config_id: Config ID

        Returns:
            Trigger result
        """
        return self._http.post(f"/v1/auto-eval/configs/{config_id}/trigger")

    def list_runs(self, config_id: str) -> List[AutoEvalRun]:
        """List runs for an auto-eval configuration.

        Args:
            config_id: Config ID

        Returns:
            List of AutoEvalRun
        """
        response = self._http.get(f"/v1/auto-eval/configs/{config_id}/runs")
        return [AutoEvalRun(**r) for r in response.get("runs", [])]


class AsyncAutoEval:
    """Asynchronous auto-eval resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def list_configs(self) -> List[AutoEvalConfig]:
        """List auto-eval configurations."""
        response = await self._http.get("/v1/auto-eval/configs")
        return [AutoEvalConfig(**c) for c in response.get("configs", [])]

    async def create_config(
        self,
        name: str,
        dataset_id: str,
        models: List[str],
        metrics: List[str],
        **kwargs: Any,
    ) -> AutoEvalConfig:
        """Create an auto-eval configuration."""
        body: Dict[str, Any] = {
            "name": name,
            "dataset_id": dataset_id,
            "models": models,
            "metrics": metrics,
            **kwargs,
        }
        response = await self._http.post("/v1/auto-eval/configs", json=body)
        return AutoEvalConfig(**response)

    async def update_config(self, config_id: str, **kwargs: Any) -> AutoEvalConfig:
        """Update an auto-eval configuration."""
        response = await self._http.put(f"/v1/auto-eval/configs/{config_id}", json=kwargs)
        return AutoEvalConfig(**response)

    async def delete_config(self, config_id: str) -> bool:
        """Delete an auto-eval configuration."""
        await self._http.delete(f"/v1/auto-eval/configs/{config_id}")
        return True

    async def suggest_metrics(self, dataset_id: str) -> Dict[str, Any]:
        """Get metric suggestions for a dataset."""
        return await self._http.post(
            "/v1/auto-eval/suggest-metrics",
            json={"dataset_id": dataset_id},
        )

    async def trigger(self, config_id: str) -> Dict[str, Any]:
        """Manually trigger an auto-eval run."""
        return await self._http.post(f"/v1/auto-eval/configs/{config_id}/trigger")

    async def list_runs(self, config_id: str) -> List[AutoEvalRun]:
        """List runs for an auto-eval configuration."""
        response = await self._http.get(f"/v1/auto-eval/configs/{config_id}/runs")
        return [AutoEvalRun(**r) for r in response.get("runs", [])]
