"""Datasets resource for managing evaluation datasets."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..evals.types import AutoCollectConfig, DataPoint, Dataset, DatasetWithDatapoints


class Datasets:
    """Synchronous datasets resource.

    Example:
        >>> from lunar import Lunar
        >>>
        >>> client = Lunar()
        >>>
        >>> # Create a dataset
        >>> dataset = client.datasets.create(
        ...     name="QA Test Set",
        ...     datapoints=[
        ...         {"input": "What is 2+2?", "expected": "4"},
        ...         {"input": "Capital of France?", "expected": "Paris"},
        ...     ],
        ... )
        >>>
        >>> # Use in evaluation
        >>> result = client.evals.run(
        ...     name="My Eval",
        ...     dataset_id=dataset.id,
        ...     task=my_task,
        ...     scorers=[exactMatch],
        ... )
    """

    def __init__(
        self,
        http: HTTPClient,
        config: LunarConfig,
    ) -> None:
        """Initialize datasets resource.

        Args:
            http: HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    def create(
        self,
        name: str,
        datapoints: Optional[List[Union[Dict[str, Any], DataPoint]]] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dataset:
        """Create a new dataset.

        Args:
            name: Dataset name
            datapoints: Optional list of datapoints to add after creation
            description: Optional description
            metadata: Optional metadata

        Returns:
            Created Dataset
        """
        response = self._http.post(
            "/v1/datasets",
            json={
                "name": name,
                "description": description or "",
                "source": "manual",
            },
        )
        dataset = Dataset(**response)

        # Add datapoints in a second call if provided
        if datapoints:
            self.add_samples(dataset.id, datapoints)

        return dataset

    def list(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dataset]:
        """List all datasets.

        Args:
            limit: Maximum number of datasets to return
            offset: Number of datasets to skip

        Returns:
            List of datasets
        """
        response = self._http.get(
            "/v1/datasets",
            params={"limit": limit, "offset": offset},
        )
        return [Dataset(**ds) for ds in response.get("datasets", [])]

    def get(
        self,
        dataset_id: str,
        include_datapoints: bool = False,
    ) -> Union[Dataset, DatasetWithDatapoints]:
        """Get a specific dataset.

        Args:
            dataset_id: Dataset ID
            include_datapoints: Whether to include datapoints in response

        Returns:
            Dataset or DatasetWithDatapoints
        """
        response = self._http.get(
            f"/v1/datasets/{dataset_id}",
            params={"include_datapoints": include_datapoints},
        )
        if include_datapoints:
            return DatasetWithDatapoints(**response)
        return Dataset(**response)

    def update(
        self,
        dataset_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dataset:
        """Update a dataset.

        Args:
            dataset_id: Dataset ID
            name: New name (optional)
            description: New description (optional)
            metadata: New metadata (optional)

        Returns:
            Updated Dataset
        """
        update_data = {}
        if name is not None:
            update_data["name"] = name
        if description is not None:
            update_data["description"] = description
        if metadata is not None:
            update_data["metadata"] = metadata

        response = self._http.patch(
            f"/v1/datasets/{dataset_id}",
            json=update_data,
        )
        return Dataset(**response)

    def delete(self, dataset_id: str) -> bool:
        """Delete a dataset.

        Args:
            dataset_id: Dataset ID

        Returns:
            True if deleted successfully
        """
        self._http.delete(f"/v1/datasets/{dataset_id}")
        return True

    def add_samples(
        self,
        dataset_id: str,
        datapoints: List[Union[Dict[str, Any], DataPoint]],
    ) -> Dict[str, Any]:
        """Add samples to an existing dataset.

        Args:
            dataset_id: Dataset ID
            datapoints: Samples to add (each must have 'input' field)

        Returns:
            Response with count of added samples
        """
        normalized = []
        for dp in datapoints:
            if isinstance(dp, DataPoint):
                d = dp.model_dump()
                # Map 'expected' -> 'expected_output' for backend compatibility
                if "expected" in d and "expected_output" not in d:
                    d["expected_output"] = d.pop("expected")
                normalized.append(d)
            elif isinstance(dp, dict):
                d = dict(dp)
                if "expected" in d and "expected_output" not in d:
                    d["expected_output"] = d.pop("expected")
                normalized.append(d)
            else:
                raise ValueError(f"Invalid datapoint type: {type(dp)}")

        return self._http.post(
            f"/v1/datasets/{dataset_id}/samples",
            json={"samples": normalized},
        )

    # Backwards compatibility alias
    add_datapoints = add_samples

    def import_data(
        self,
        name: str,
        format: str,
        data: Any,
        **kwargs: Any,
    ) -> Dataset:
        """Import a dataset from an external format.

        Args:
            name: Dataset name
            format: Data format (e.g. 'csv', 'jsonl')
            data: Raw data content
            **kwargs: Additional parameters

        Returns:
            Created Dataset
        """
        body: Dict[str, Any] = {"name": name, "format": format, "data": data, **kwargs}
        response = self._http.post("/v1/datasets/import", json=body)
        return Dataset(**response)

    def from_traces(self, name: str, **kwargs: Any) -> Dataset:
        """Create a dataset from recorded traces.

        Args:
            name: Dataset name
            **kwargs: Filter parameters (model_id, source, limit, etc.)

        Returns:
            Created Dataset
        """
        body: Dict[str, Any] = {"name": name, **kwargs}
        response = self._http.post("/v1/datasets/from-traces", json=body)
        return Dataset(**response)

    def from_instruction(self, name: str, instruction: str, **kwargs: Any) -> Dataset:
        """Generate a synthetic dataset from an instruction.

        Args:
            name: Dataset name
            instruction: Natural-language instruction describing desired data
            **kwargs: Additional parameters (count, model, etc.)

        Returns:
            Created Dataset
        """
        body: Dict[str, Any] = {"name": name, "instruction": instruction, **kwargs}
        response = self._http.post("/v1/datasets/from-instruction", json=body)
        return Dataset(**response)

    def generate(
        self,
        name: str,
        instruction: str,
        count: int = 50,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generate a synthetic dataset using AI.

        Args:
            name: Dataset name
            instruction: Description of what data to generate
            count: Number of samples to generate (1-500, default 50)
            description: Optional dataset description

        Returns:
            Dict with dataset_id, name, source, samples_count, samples_requested
        """
        body: Dict[str, Any] = {
            "name": name,
            "instruction": instruction,
            "count": count,
        }
        if description:
            body["description"] = description

        return self._http.post("/v1/datasets/generate", json=body)

    def delete_sample(self, dataset_id: str, sample_id: str) -> bool:
        """Delete a single sample from a dataset.

        Args:
            dataset_id: Dataset ID
            sample_id: Sample ID to delete

        Returns:
            True if deleted
        """
        self._http.delete(f"/v1/datasets/{dataset_id}/samples/{sample_id}")
        return True

    def set_auto_collect(self, dataset_id: str, **kwargs: Any) -> AutoCollectConfig:
        """Set auto-collect configuration for a dataset.

        Args:
            dataset_id: Dataset ID
            **kwargs: Config fields (enabled, filters, sample_rate, max_samples)

        Returns:
            AutoCollectConfig
        """
        response = self._http.put(f"/v1/datasets/{dataset_id}/auto-collect", json=kwargs)
        return AutoCollectConfig(**response)

    def get_auto_collect(self, dataset_id: str) -> AutoCollectConfig:
        """Get auto-collect configuration for a dataset.

        Args:
            dataset_id: Dataset ID

        Returns:
            AutoCollectConfig
        """
        response = self._http.get(f"/v1/datasets/{dataset_id}/auto-collect")
        return AutoCollectConfig(**response)

    def delete_auto_collect(self, dataset_id: str) -> bool:
        """Delete auto-collect configuration for a dataset.

        Args:
            dataset_id: Dataset ID

        Returns:
            True if deleted
        """
        self._http.delete(f"/v1/datasets/{dataset_id}/auto-collect")
        return True

    def auto_collect_history(
        self, dataset_id: str, limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get auto-collect run history for a dataset.

        Args:
            dataset_id: Dataset ID
            limit: Maximum entries to return

        Returns:
            List of history entries
        """
        response = self._http.get(
            f"/v1/datasets/{dataset_id}/auto-collect/history",
            params={"limit": limit},
        )
        return response.get("history", [])

    def trigger_auto_collect(self, dataset_id: str) -> Dict[str, Any]:
        """Manually trigger an auto-collect run.

        Args:
            dataset_id: Dataset ID

        Returns:
            Run status
        """
        return self._http.post(f"/v1/datasets/{dataset_id}/auto-collect/run")


class AsyncDatasets:
    """Asynchronous datasets resource.

    Example:
        >>> from lunar import AsyncLunar
        >>>
        >>> async with AsyncLunar() as client:
        ...     dataset = await client.datasets.create(
        ...         name="QA Test Set",
        ...         datapoints=[{"input": "...", "expected": "..."}],
        ...     )
    """

    def __init__(
        self,
        http: AsyncHTTPClient,
        config: LunarConfig,
    ) -> None:
        """Initialize async datasets resource.

        Args:
            http: Async HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    async def create(
        self,
        name: str,
        datapoints: Optional[List[Union[Dict[str, Any], DataPoint]]] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dataset:
        """Create a new dataset.

        Args:
            name: Dataset name
            datapoints: Optional list of datapoints to add after creation
            description: Optional description
            metadata: Optional metadata

        Returns:
            Created Dataset
        """
        response = await self._http.post(
            "/v1/datasets",
            json={
                "name": name,
                "description": description or "",
                "source": "manual",
            },
        )
        dataset = Dataset(**response)

        if datapoints:
            await self.add_samples(dataset.id, datapoints)

        return dataset

    async def list(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dataset]:
        """List all datasets.

        Args:
            limit: Maximum number of datasets to return
            offset: Number of datasets to skip

        Returns:
            List of datasets
        """
        response = await self._http.get(
            "/v1/datasets",
            params={"limit": limit, "offset": offset},
        )
        return [Dataset(**ds) for ds in response.get("datasets", [])]

    async def get(
        self,
        dataset_id: str,
        include_datapoints: bool = False,
    ) -> Union[Dataset, DatasetWithDatapoints]:
        """Get a specific dataset.

        Args:
            dataset_id: Dataset ID
            include_datapoints: Whether to include datapoints

        Returns:
            Dataset or DatasetWithDatapoints
        """
        response = await self._http.get(
            f"/v1/datasets/{dataset_id}",
            params={"include_datapoints": include_datapoints},
        )
        if include_datapoints:
            return DatasetWithDatapoints(**response)
        return Dataset(**response)

    async def update(
        self,
        dataset_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dataset:
        """Update a dataset.

        Args:
            dataset_id: Dataset ID
            name: New name (optional)
            description: New description (optional)
            metadata: New metadata (optional)

        Returns:
            Updated Dataset
        """
        update_data = {}
        if name is not None:
            update_data["name"] = name
        if description is not None:
            update_data["description"] = description
        if metadata is not None:
            update_data["metadata"] = metadata

        response = await self._http.patch(
            f"/v1/datasets/{dataset_id}",
            json=update_data,
        )
        return Dataset(**response)

    async def delete(self, dataset_id: str) -> bool:
        """Delete a dataset.

        Args:
            dataset_id: Dataset ID

        Returns:
            True if deleted successfully
        """
        await self._http.delete(f"/v1/datasets/{dataset_id}")
        return True

    async def add_samples(
        self,
        dataset_id: str,
        datapoints: List[Union[Dict[str, Any], DataPoint]],
    ) -> Dict[str, Any]:
        """Add samples to an existing dataset.

        Args:
            dataset_id: Dataset ID
            datapoints: Samples to add (each must have 'input' field)

        Returns:
            Response with count of added samples
        """
        normalized = []
        for dp in datapoints:
            if isinstance(dp, DataPoint):
                d = dp.model_dump()
                if "expected" in d and "expected_output" not in d:
                    d["expected_output"] = d.pop("expected")
                normalized.append(d)
            elif isinstance(dp, dict):
                d = dict(dp)
                if "expected" in d and "expected_output" not in d:
                    d["expected_output"] = d.pop("expected")
                normalized.append(d)
            else:
                raise ValueError(f"Invalid datapoint type: {type(dp)}")

        return await self._http.post(
            f"/v1/datasets/{dataset_id}/samples",
            json={"samples": normalized},
        )

    # Backwards compatibility alias
    add_datapoints = add_samples

    async def import_data(
        self,
        name: str,
        format: str,
        data: Any,
        **kwargs: Any,
    ) -> Dataset:
        """Import a dataset from an external format.

        Args:
            name: Dataset name
            format: Data format (e.g. 'csv', 'jsonl')
            data: Raw data content
            **kwargs: Additional parameters

        Returns:
            Created Dataset
        """
        body: Dict[str, Any] = {"name": name, "format": format, "data": data, **kwargs}
        response = await self._http.post("/v1/datasets/import", json=body)
        return Dataset(**response)

    async def from_traces(self, name: str, **kwargs: Any) -> Dataset:
        """Create a dataset from recorded traces.

        Args:
            name: Dataset name
            **kwargs: Filter parameters (model_id, source, limit, etc.)

        Returns:
            Created Dataset
        """
        body: Dict[str, Any] = {"name": name, **kwargs}
        response = await self._http.post("/v1/datasets/from-traces", json=body)
        return Dataset(**response)

    async def from_instruction(self, name: str, instruction: str, **kwargs: Any) -> Dataset:
        """Generate a synthetic dataset from an instruction.

        Args:
            name: Dataset name
            instruction: Natural-language instruction describing desired data
            **kwargs: Additional parameters (count, model, etc.)

        Returns:
            Created Dataset
        """
        body: Dict[str, Any] = {"name": name, "instruction": instruction, **kwargs}
        response = await self._http.post("/v1/datasets/from-instruction", json=body)
        return Dataset(**response)

    async def generate(
        self,
        name: str,
        instruction: str,
        count: int = 50,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generate a synthetic dataset using AI.

        Args:
            name: Dataset name
            instruction: Description of what data to generate
            count: Number of samples to generate (1-500, default 50)
            description: Optional dataset description

        Returns:
            Dict with dataset_id, name, source, samples_count, samples_requested
        """
        body: Dict[str, Any] = {
            "name": name,
            "instruction": instruction,
            "count": count,
        }
        if description:
            body["description"] = description

        return await self._http.post("/v1/datasets/generate", json=body)

    async def delete_sample(self, dataset_id: str, sample_id: str) -> bool:
        """Delete a single sample from a dataset.

        Args:
            dataset_id: Dataset ID
            sample_id: Sample ID to delete

        Returns:
            True if deleted
        """
        await self._http.delete(f"/v1/datasets/{dataset_id}/samples/{sample_id}")
        return True

    async def set_auto_collect(self, dataset_id: str, **kwargs: Any) -> AutoCollectConfig:
        """Set auto-collect configuration for a dataset.

        Args:
            dataset_id: Dataset ID
            **kwargs: Config fields (enabled, filters, sample_rate, max_samples)

        Returns:
            AutoCollectConfig
        """
        response = await self._http.put(f"/v1/datasets/{dataset_id}/auto-collect", json=kwargs)
        return AutoCollectConfig(**response)

    async def get_auto_collect(self, dataset_id: str) -> AutoCollectConfig:
        """Get auto-collect configuration for a dataset.

        Args:
            dataset_id: Dataset ID

        Returns:
            AutoCollectConfig
        """
        response = await self._http.get(f"/v1/datasets/{dataset_id}/auto-collect")
        return AutoCollectConfig(**response)

    async def delete_auto_collect(self, dataset_id: str) -> bool:
        """Delete auto-collect configuration for a dataset.

        Args:
            dataset_id: Dataset ID

        Returns:
            True if deleted
        """
        await self._http.delete(f"/v1/datasets/{dataset_id}/auto-collect")
        return True

    async def auto_collect_history(
        self, dataset_id: str, limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get auto-collect run history for a dataset.

        Args:
            dataset_id: Dataset ID
            limit: Maximum entries to return

        Returns:
            List of history entries
        """
        response = await self._http.get(
            f"/v1/datasets/{dataset_id}/auto-collect/history",
            params={"limit": limit},
        )
        return response.get("history", [])

    async def trigger_auto_collect(self, dataset_id: str) -> Dict[str, Any]:
        """Manually trigger an auto-collect run.

        Args:
            dataset_id: Dataset ID

        Returns:
            Run status
        """
        return await self._http.post(f"/v1/datasets/{dataset_id}/auto-collect/run")
