"""Eval settings resource for managing evaluation platform settings."""

from __future__ import annotations

from typing import Any, Dict

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient


class EvalSettings:
    """Synchronous eval settings resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def get(self) -> Dict[str, Any]:
        """Get evaluation settings.

        Returns:
            Settings dict
        """
        return self._http.get("/v1/evaluations/settings")

    def update(self, **kwargs: Any) -> Dict[str, Any]:
        """Update evaluation settings.

        Args:
            **kwargs: Settings to update

        Returns:
            Updated settings dict
        """
        return self._http.put("/v1/evaluations/settings", json=kwargs)


class AsyncEvalSettings:
    """Asynchronous eval settings resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def get(self) -> Dict[str, Any]:
        """Get evaluation settings."""
        return await self._http.get("/v1/evaluations/settings")

    async def update(self, **kwargs: Any) -> Dict[str, Any]:
        """Update evaluation settings."""
        return await self._http.put("/v1/evaluations/settings", json=kwargs)
