"""Eval models resource for listing available evaluation models."""

from __future__ import annotations

from typing import Any, Dict, List

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient


class EvalModels:
    """Synchronous eval models resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def available(self) -> List[Dict[str, Any]]:
        """List available models for evaluations.

        Returns:
            List of model descriptors
        """
        response = self._http.get("/v1/models/available")
        return response.get("models", [])


class AsyncEvalModels:
    """Asynchronous eval models resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def available(self) -> List[Dict[str, Any]]:
        """List available models for evaluations."""
        response = await self._http.get("/v1/models/available")
        return response.get("models", [])
