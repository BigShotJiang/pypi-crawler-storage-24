"""Annotations resource for human annotation of evaluation samples."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..evals.types import AnnotationAnalytics, AnnotationItem, AnnotationQueue


class Annotations:
    """Synchronous annotations resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def list_queues(self) -> List[AnnotationQueue]:
        """List annotation queues.

        Returns:
            List of AnnotationQueue
        """
        response = self._http.get("/v1/annotations/queues")
        return [AnnotationQueue(**q) for q in response.get("queues", [])]

    def create_queue(
        self,
        name: str,
        dataset_id: str,
        rubric: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> AnnotationQueue:
        """Create an annotation queue.

        Args:
            name: Queue name
            dataset_id: Dataset ID
            rubric: Optional annotation rubric
            **kwargs: Additional parameters

        Returns:
            Created AnnotationQueue
        """
        body: Dict[str, Any] = {"name": name, "dataset_id": dataset_id, **kwargs}
        if rubric is not None:
            body["rubric"] = rubric
        response = self._http.post("/v1/annotations/queues", json=body)
        return AnnotationQueue(**response)

    def delete_queue(self, queue_id: str) -> bool:
        """Delete an annotation queue.

        Args:
            queue_id: Queue ID

        Returns:
            True if deleted
        """
        self._http.delete(f"/v1/annotations/queues/{queue_id}")
        return True

    def list_items(
        self, queue_id: str, status: Optional[str] = None
    ) -> List[AnnotationItem]:
        """List items in an annotation queue.

        Args:
            queue_id: Queue ID
            status: Optional status filter

        Returns:
            List of AnnotationItem
        """
        params: Dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        response = self._http.get(
            f"/v1/annotations/queues/{queue_id}/items",
            params=params or None,
        )
        return [AnnotationItem(**i) for i in response.get("items", [])]

    def next_item(self, queue_id: str) -> Optional[AnnotationItem]:
        """Get the next item to annotate.

        Args:
            queue_id: Queue ID

        Returns:
            Next AnnotationItem, or None if queue is empty
        """
        response = self._http.get(f"/v1/annotations/queues/{queue_id}/next")
        if not response or not response.get("id"):
            return None
        return AnnotationItem(**response)

    def submit(
        self,
        queue_id: str,
        item_id: str,
        scores: Dict[str, Any],
        notes: Optional[str] = None,
    ) -> AnnotationItem:
        """Submit an annotation.

        Args:
            queue_id: Queue ID
            item_id: Item ID
            scores: Annotation scores
            notes: Optional annotator notes

        Returns:
            Updated AnnotationItem
        """
        body: Dict[str, Any] = {"scores": scores}
        if notes is not None:
            body["notes"] = notes
        response = self._http.post(
            f"/v1/annotations/queues/{queue_id}/items/{item_id}/submit",
            json=body,
        )
        return AnnotationItem(**response)

    def skip(self, queue_id: str, item_id: str) -> AnnotationItem:
        """Skip an annotation item.

        Args:
            queue_id: Queue ID
            item_id: Item ID

        Returns:
            Updated AnnotationItem
        """
        response = self._http.post(
            f"/v1/annotations/queues/{queue_id}/items/{item_id}/skip"
        )
        return AnnotationItem(**response)

    def stats(self, queue_id: str) -> Dict[str, Any]:
        """Get annotation queue statistics.

        Args:
            queue_id: Queue ID

        Returns:
            Queue statistics
        """
        return self._http.get(f"/v1/annotations/queues/{queue_id}/stats")

    def export(self, queue_id: str, format: str = "json") -> Dict[str, Any]:
        """Export annotations.

        Args:
            queue_id: Queue ID
            format: Export format

        Returns:
            Export data
        """
        return self._http.get(
            f"/v1/annotations/queues/{queue_id}/export",
            params={"format": format},
        )

    def analytics(self, queue_id: str) -> AnnotationAnalytics:
        """Get annotation queue analytics.

        Args:
            queue_id: Queue ID

        Returns:
            AnnotationAnalytics
        """
        response = self._http.get(f"/v1/annotations/queues/{queue_id}/analytics")
        return AnnotationAnalytics(**response)


class AsyncAnnotations:
    """Asynchronous annotations resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def list_queues(self) -> List[AnnotationQueue]:
        """List annotation queues."""
        response = await self._http.get("/v1/annotations/queues")
        return [AnnotationQueue(**q) for q in response.get("queues", [])]

    async def create_queue(
        self,
        name: str,
        dataset_id: str,
        rubric: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> AnnotationQueue:
        """Create an annotation queue."""
        body: Dict[str, Any] = {"name": name, "dataset_id": dataset_id, **kwargs}
        if rubric is not None:
            body["rubric"] = rubric
        response = await self._http.post("/v1/annotations/queues", json=body)
        return AnnotationQueue(**response)

    async def delete_queue(self, queue_id: str) -> bool:
        """Delete an annotation queue."""
        await self._http.delete(f"/v1/annotations/queues/{queue_id}")
        return True

    async def list_items(
        self, queue_id: str, status: Optional[str] = None
    ) -> List[AnnotationItem]:
        """List items in an annotation queue."""
        params: Dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        response = await self._http.get(
            f"/v1/annotations/queues/{queue_id}/items",
            params=params or None,
        )
        return [AnnotationItem(**i) for i in response.get("items", [])]

    async def next_item(self, queue_id: str) -> Optional[AnnotationItem]:
        """Get the next item to annotate."""
        response = await self._http.get(f"/v1/annotations/queues/{queue_id}/next")
        if not response or not response.get("id"):
            return None
        return AnnotationItem(**response)

    async def submit(
        self,
        queue_id: str,
        item_id: str,
        scores: Dict[str, Any],
        notes: Optional[str] = None,
    ) -> AnnotationItem:
        """Submit an annotation."""
        body: Dict[str, Any] = {"scores": scores}
        if notes is not None:
            body["notes"] = notes
        response = await self._http.post(
            f"/v1/annotations/queues/{queue_id}/items/{item_id}/submit",
            json=body,
        )
        return AnnotationItem(**response)

    async def skip(self, queue_id: str, item_id: str) -> AnnotationItem:
        """Skip an annotation item."""
        response = await self._http.post(
            f"/v1/annotations/queues/{queue_id}/items/{item_id}/skip"
        )
        return AnnotationItem(**response)

    async def stats(self, queue_id: str) -> Dict[str, Any]:
        """Get annotation queue statistics."""
        return await self._http.get(f"/v1/annotations/queues/{queue_id}/stats")

    async def export(self, queue_id: str, format: str = "json") -> Dict[str, Any]:
        """Export annotations."""
        return await self._http.get(
            f"/v1/annotations/queues/{queue_id}/export",
            params={"format": format},
        )

    async def analytics(self, queue_id: str) -> AnnotationAnalytics:
        """Get annotation queue analytics."""
        response = await self._http.get(f"/v1/annotations/queues/{queue_id}/analytics")
        return AnnotationAnalytics(**response)
