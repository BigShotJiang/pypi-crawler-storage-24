"""Text completions resource."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..types.completion import Completion
from .._exceptions import FALLBACK_ERRORS, NON_FALLBACK_ERRORS

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient
    from .._config import LunarConfig

logger = logging.getLogger(__name__)


class TextCompletions:
    """Synchronous text completions resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        """Initialize text completions resource.

        Args:
            http: HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    def create(
        self,
        *,
        model: str,
        prompt: str,
        fallbacks: Optional[List[str]] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Completion:
        """Create a text completion.

        Args:
            model: Model to use for completion
            prompt: Text prompt to complete
            fallbacks: Optional list of fallback models to try on failure
            max_tokens: Maximum number of tokens to generate
            temperature: Sampling temperature (0-2)
            stop: List of stop sequences
            **kwargs: Additional parameters to pass to the API

        Returns:
            Completion response

        Raises:
            APIError: If all models fail
        """
        # Combine config fallbacks with request-level fallbacks
        all_fallbacks = fallbacks or self._config.get_fallbacks(model)
        models_to_try = [model] + all_fallbacks

        last_error: Optional[Exception] = None

        for i, current_model in enumerate(models_to_try):
            try:
                return self._make_request(
                    current_model,
                    prompt,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    stop=stop,
                    **kwargs,
                )
            except NON_FALLBACK_ERRORS:
                # Client errors - don't try fallback
                raise
            except FALLBACK_ERRORS as e:
                # Server/infra errors - try fallback
                last_error = e
                is_last = i == len(models_to_try) - 1

                if is_last:
                    logger.error(f"All models failed. Last error: {e}")
                    raise
                else:
                    logger.warning(
                        f"Model {current_model} failed with {type(e).__name__}, "
                        f"trying fallback: {models_to_try[i + 1]}"
                    )
                    continue

        # Should not reach here, but just in case
        if last_error:
            raise last_error
        raise RuntimeError("Request failed with unknown error")

    def _make_request(
        self,
        model: str,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Completion:
        """Make the actual API request.

        Args:
            model: Model to use
            prompt: Text prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            stop: Stop sequences
            **kwargs: Additional parameters

        Returns:
            Completion response
        """
        payload: Dict[str, Any] = {
            "model": model,
            "prompt": prompt,
        }

        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if temperature is not None:
            payload["temperature"] = temperature
        if stop is not None:
            payload["stop"] = stop

        payload.update(kwargs)

        response = self._http.post("/v1/completions", json=payload)
        return Completion.model_validate(response)


class AsyncTextCompletions:
    """Asynchronous text completions resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        """Initialize async text completions resource.

        Args:
            http: Async HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    async def create(
        self,
        *,
        model: str,
        prompt: str,
        fallbacks: Optional[List[str]] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Completion:
        """Create a text completion.

        Args:
            model: Model to use for completion
            prompt: Text prompt to complete
            fallbacks: Optional list of fallback models to try on failure
            max_tokens: Maximum number of tokens to generate
            temperature: Sampling temperature (0-2)
            stop: List of stop sequences
            **kwargs: Additional parameters to pass to the API

        Returns:
            Completion response

        Raises:
            APIError: If all models fail
        """
        # Combine config fallbacks with request-level fallbacks
        all_fallbacks = fallbacks or self._config.get_fallbacks(model)
        models_to_try = [model] + all_fallbacks

        last_error: Optional[Exception] = None

        for i, current_model in enumerate(models_to_try):
            try:
                return await self._make_request(
                    current_model,
                    prompt,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    stop=stop,
                    **kwargs,
                )
            except NON_FALLBACK_ERRORS:
                # Client errors - don't try fallback
                raise
            except FALLBACK_ERRORS as e:
                # Server/infra errors - try fallback
                last_error = e
                is_last = i == len(models_to_try) - 1

                if is_last:
                    logger.error(f"All models failed. Last error: {e}")
                    raise
                else:
                    logger.warning(
                        f"Model {current_model} failed with {type(e).__name__}, "
                        f"trying fallback: {models_to_try[i + 1]}"
                    )
                    continue

        # Should not reach here, but just in case
        if last_error:
            raise last_error
        raise RuntimeError("Request failed with unknown error")

    async def _make_request(
        self,
        model: str,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Completion:
        """Make the actual API request.

        Args:
            model: Model to use
            prompt: Text prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            stop: Stop sequences
            **kwargs: Additional parameters

        Returns:
            Completion response
        """
        payload: Dict[str, Any] = {
            "model": model,
            "prompt": prompt,
        }

        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if temperature is not None:
            payload["temperature"] = temperature
        if stop is not None:
            payload["stop"] = stop

        payload.update(kwargs)

        response = await self._http.post("/v1/completions", json=payload)
        return Completion.model_validate(response)
