"""RAG (Retrieval-Augmented Generation) resource for document retrieval."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..types.rag import (
    ChunkingStrategy,
    DeleteResponse,
    Document,
    IngestResponse,
    MetadataFilter,
    RAGConfig,
    RAGGenerateResponse,
    RAGStats,
    RetrievalResponse,
    SearchResult,
)

if TYPE_CHECKING:
    from ..client import AsyncLunar, Lunar

DEFAULT_SYSTEM_PROMPT = """You are a helpful assistant. Use the following context to answer the user's question.
If the context doesn't contain relevant information, say so and answer based on your general knowledge.

Context:
{context}"""


class RAG:
    """Synchronous RAG resource for document retrieval and ingestion.

    Example:
        >>> from lunar import Lunar
        >>>
        >>> client = Lunar()
        >>>
        >>> # Ingest a document
        >>> result = client.rag.ingest(
        ...     content="Machine learning is a subset of AI...",
        ...     metadata={"category": "technology"}
        ... )
        >>> print(f"Created {result.chunks_created} chunks")
        >>>
        >>> # Search for relevant content
        >>> results = client.rag.retrieve("What is machine learning?")
        >>> for r in results.results:
        ...     print(f"Score: {r.score:.3f} - {r.content[:100]}")
    """

    def __init__(self, http: HTTPClient, config: LunarConfig, client: "Lunar") -> None:
        """Initialize RAG resource.

        Args:
            http: HTTP client for API calls (used if rag_api_url == base_url)
            config: Lunar configuration
            client: Parent Lunar client for LLM calls
        """
        self._config = config
        self._client = client
        self._default_config = RAGConfig()

        # Use separate HTTP client if rag_api_url differs from base_url
        if config.rag_api_url != config.base_url:
            from dataclasses import replace
            rag_config = replace(config, base_url=config.rag_api_url)
            self._http = HTTPClient(rag_config)
            self._owns_http = True
        else:
            self._http = http
            self._owns_http = False

    def retrieve(
        self,
        query: str,
        *,
        top_k: int = 5,
        min_score: float = 0.0,
        metadata_filter: Optional[MetadataFilter] = None,
        rerank: bool = False,
        rerank_top_k: int = 3,
    ) -> RetrievalResponse:
        """Retrieve documents matching a query.

        Args:
            query: Search query text
            top_k: Maximum number of results to return
            min_score: Minimum similarity score threshold (0.0 to 1.0)
            metadata_filter: Optional metadata filters (key-value pairs)
            rerank: Whether to rerank results for better relevance
            rerank_top_k: Number of results after reranking

        Returns:
            RetrievalResponse with search results

        Example:
            >>> results = client.rag.retrieve(
            ...     "How does neural network training work?",
            ...     top_k=10,
            ...     metadata_filter={"category": "ml"},
            ...     rerank=True,
            ... )
            >>> for r in results.results:
            ...     print(f"{r.score:.3f}: {r.content[:50]}...")
        """
        payload: Dict[str, Any] = {
            "query": query,
            "top_k": top_k,
            "min_score": min_score,
            "rerank": rerank,
            "rerank_top_k": rerank_top_k,
        }

        if metadata_filter:
            payload["metadata_filter"] = metadata_filter

        response = self._http.post("/v1/rag/retrieve", json=payload)
        return RetrievalResponse(**response)

    def ingest(
        self,
        content: str,
        *,
        document_id: Optional[str] = None,
        filename: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        chunking_strategy: ChunkingStrategy = ChunkingStrategy.SENTENCE,
        chunk_size: int = 512,
        chunk_overlap: int = 50,
    ) -> IngestResponse:
        """Ingest text content into the RAG system.

        Args:
            content: Text content to ingest
            document_id: Optional document ID (generated if not provided)
            filename: Optional filename for the document
            metadata: Optional metadata to attach to the document
            chunking_strategy: Strategy for splitting content into chunks
            chunk_size: Target chunk size in characters
            chunk_overlap: Overlap between consecutive chunks

        Returns:
            IngestResponse with document ID and chunk count

        Example:
            >>> result = client.rag.ingest(
            ...     content="Your document content here...",
            ...     metadata={"author": "John", "category": "research"},
            ...     chunk_size=500,
            ... )
            >>> print(f"Document {result.document_id}: {result.chunks_created} chunks")
        """
        payload: Dict[str, Any] = {
            "content": content,
            "chunking_strategy": chunking_strategy.value,
            "chunk_size": chunk_size,
            "chunk_overlap": chunk_overlap,
        }

        if document_id:
            payload["document_id"] = document_id
        if filename:
            payload["filename"] = filename
        if metadata:
            payload["metadata"] = metadata

        response = self._http.post("/v1/rag/ingest", json=payload)
        return IngestResponse(**response)

    def ingest_file(
        self,
        file_url: Optional[str] = None,
        file_path: Optional[str] = None,
        *,
        document_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        chunking_strategy: ChunkingStrategy = ChunkingStrategy.SENTENCE,
    ) -> IngestResponse:
        """Ingest a file into the RAG system.

        Args:
            file_url: URL of file to ingest (S3, HTTP, etc.)
            file_path: Local file path to upload and ingest
            document_id: Optional document ID
            metadata: Optional metadata to attach
            chunking_strategy: Strategy for splitting content

        Returns:
            IngestResponse with document ID and chunk count

        Example:
            >>> # From URL
            >>> result = client.rag.ingest_file(
            ...     file_url="s3://bucket/docs/report.pdf",
            ...     metadata={"type": "report"}
            ... )
            >>>
            >>> # From local file
            >>> result = client.rag.ingest_file(
            ...     file_path="/path/to/document.pdf"
            ... )
        """
        if not file_url and not file_path:
            raise ValueError("Either file_url or file_path must be provided")

        payload: Dict[str, Any] = {
            "chunking_strategy": chunking_strategy.value,
        }

        if file_url:
            payload["file_url"] = file_url
        if document_id:
            payload["document_id"] = document_id
        if metadata:
            payload["metadata"] = metadata

        # If local file, upload it first
        if file_path:
            import json
            import os
            # Serialize complex values for multipart form
            form_data = {
                "chunking_strategy": chunking_strategy.value,
            }
            if document_id:
                form_data["document_id"] = document_id
            if metadata:
                form_data["metadata"] = json.dumps(metadata)

            with open(file_path, "rb") as f:
                files = {"file": (os.path.basename(file_path), f)}
                response = self._http.post(
                    "/v1/rag/ingest/file",
                    data=form_data,
                    files=files,
                )
        else:
            response = self._http.post("/v1/rag/ingest/file", json=payload)

        return IngestResponse(**response)

    def get_document(self, document_id: str) -> Document:
        """Get document metadata by ID.

        Args:
            document_id: Document identifier

        Returns:
            Document with metadata

        Example:
            >>> doc = client.rag.get_document("doc_123")
            >>> print(f"Document: {doc.filename}, Type: {doc.type}")
        """
        response = self._http.get(f"/v1/rag/documents/{document_id}")
        return Document(**response)

    def list_documents(
        self,
        *,
        limit: int = 100,
        offset: int = 0,
        metadata_filter: Optional[MetadataFilter] = None,
    ) -> List[Document]:
        """List documents in the RAG store.

        Args:
            limit: Maximum number of documents to return
            offset: Number of documents to skip
            metadata_filter: Optional metadata filters

        Returns:
            List of documents

        Example:
            >>> docs = client.rag.list_documents(limit=10)
            >>> for doc in docs:
            ...     print(f"{doc.id}: {doc.filename}")
        """
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if metadata_filter:
            params["metadata_filter"] = metadata_filter

        response = self._http.get("/v1/rag/documents", params=params)
        return [Document(**doc) for doc in response]

    def delete_document(self, document_id: str) -> DeleteResponse:
        """Delete a document and all its chunks.

        Args:
            document_id: Document identifier to delete

        Returns:
            DeleteResponse with deletion status

        Example:
            >>> result = client.rag.delete_document("doc_123")
            >>> print(f"Deleted {result.deleted_chunks} chunks")
        """
        response = self._http.delete(f"/v1/rag/documents/{document_id}")
        return DeleteResponse(**response)

    def stats(self) -> RAGStats:
        """Get RAG store statistics.

        Returns:
            RAGStats with document and chunk counts

        Example:
            >>> stats = client.rag.stats()
            >>> print(f"Documents: {stats.total_documents}, Chunks: {stats.total_chunks}")
        """
        response = self._http.get("/v1/rag/stats")
        return RAGStats(**response)

    def clear(self) -> DeleteResponse:
        """Clear all documents and chunks from the RAG store.

        Warning: This permanently deletes all data!

        Returns:
            DeleteResponse with deletion status

        Example:
            >>> result = client.rag.clear()
            >>> print(f"Cleared {result.deleted_chunks} chunks")
        """
        response = self._http.delete("/v1/rag/clear")
        return DeleteResponse(**response)

    def generate(
        self,
        query: str,
        *,
        model: str = "gpt-4o-mini",
        system_prompt: Optional[str] = None,
        top_k: int = 5,
        min_score: float = 0.0,
        rerank: bool = False,
        rerank_top_k: int = 3,
        metadata_filter: Optional[MetadataFilter] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        include_sources: bool = True,
    ) -> RAGGenerateResponse:
        """Generate a response using RAG (retrieve + generate).

        Retrieves relevant documents and uses them as context for LLM generation.

        Args:
            query: User query/question
            model: LLM model to use for generation
            system_prompt: Custom system prompt (use {context} placeholder)
            top_k: Number of documents to retrieve
            min_score: Minimum similarity score for retrieval
            rerank: Whether to rerank results
            rerank_top_k: Number of results after reranking
            metadata_filter: Optional metadata filters for retrieval
            temperature: LLM temperature (0.0 to 1.0)
            max_tokens: Maximum tokens for response
            include_sources: Whether to include source documents in response

        Returns:
            RAGGenerateResponse with generated content and sources

        Example:
            >>> response = client.rag.generate(
            ...     query="What is machine learning?",
            ...     model="gpt-4o-mini",
            ...     top_k=5,
            ... )
            >>> print(response.content)
            >>> print(f"Used {len(response.sources)} sources")
        """
        total_start = time.time()

        # Step 1: Retrieve relevant documents
        retrieval_start = time.time()
        retrieval_response = self.retrieve(
            query=query,
            top_k=top_k,
            min_score=min_score,
            metadata_filter=metadata_filter,
            rerank=rerank,
            rerank_top_k=rerank_top_k,
        )
        retrieval_latency = (time.time() - retrieval_start) * 1000

        # Step 2: Build context from retrieved chunks
        context_parts = []
        for i, result in enumerate(retrieval_response.results, 1):
            context_parts.append(f"[{i}] {result.content}")
        context = "\n\n".join(context_parts) if context_parts else "No relevant context found."

        # Step 3: Build system prompt with context
        prompt_template = system_prompt or DEFAULT_SYSTEM_PROMPT
        final_system_prompt = prompt_template.format(context=context)

        # Step 4: Call LLM via Lunar chat completions
        generation_start = time.time()

        chat_params: Dict[str, Any] = {
            "model": model,
            "messages": [
                {"role": "system", "content": final_system_prompt},
                {"role": "user", "content": query},
            ],
            "temperature": temperature,
        }
        if max_tokens:
            chat_params["max_tokens"] = max_tokens

        chat_response = self._client.chat.completions.create(**chat_params)
        generation_latency = (time.time() - generation_start) * 1000

        total_latency = (time.time() - total_start) * 1000

        # Build response
        return RAGGenerateResponse(
            content=chat_response.choices[0].message.content or "",
            model=chat_response.model,
            query=query,
            sources=retrieval_response.results if include_sources else [],
            usage={
                "prompt_tokens": chat_response.usage.prompt_tokens if chat_response.usage else 0,
                "completion_tokens": chat_response.usage.completion_tokens if chat_response.usage else 0,
                "total_tokens": chat_response.usage.total_tokens if chat_response.usage else 0,
            } if chat_response.usage else None,
            retrieval_latency_ms=retrieval_latency,
            generation_latency_ms=generation_latency,
            total_latency_ms=total_latency,
        )


class AsyncRAG:
    """Asynchronous RAG resource for document retrieval and ingestion.

    Example:
        >>> from lunar import AsyncLunar
        >>>
        >>> async with AsyncLunar() as client:
        ...     # Ingest documents
        ...     await client.rag.ingest(content="Your content...")
        ...
        ...     # Search
        ...     results = await client.rag.retrieve("query")
    """

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig, client: "AsyncLunar") -> None:
        """Initialize async RAG resource.

        Args:
            http: Async HTTP client for API calls (used if rag_api_url == base_url)
            config: Lunar configuration
            client: Parent AsyncLunar client for LLM calls
        """
        self._config = config
        self._client = client
        self._default_config = RAGConfig()

        # Use separate HTTP client if rag_api_url differs from base_url
        if config.rag_api_url != config.base_url:
            from dataclasses import replace
            rag_config = replace(config, base_url=config.rag_api_url)
            self._http = AsyncHTTPClient(rag_config)
            self._owns_http = True
        else:
            self._http = http
            self._owns_http = False

    async def retrieve(
        self,
        query: str,
        *,
        top_k: int = 5,
        min_score: float = 0.0,
        metadata_filter: Optional[MetadataFilter] = None,
        rerank: bool = False,
        rerank_top_k: int = 3,
    ) -> RetrievalResponse:
        """Retrieve documents matching a query.

        Args:
            query: Search query text
            top_k: Maximum number of results to return
            min_score: Minimum similarity score threshold (0.0 to 1.0)
            metadata_filter: Optional metadata filters
            rerank: Whether to rerank results
            rerank_top_k: Number of results after reranking

        Returns:
            RetrievalResponse with search results
        """
        payload: Dict[str, Any] = {
            "query": query,
            "top_k": top_k,
            "min_score": min_score,
            "rerank": rerank,
            "rerank_top_k": rerank_top_k,
        }

        if metadata_filter:
            payload["metadata_filter"] = metadata_filter

        response = await self._http.post("/v1/rag/retrieve", json=payload)
        return RetrievalResponse(**response)

    async def ingest(
        self,
        content: str,
        *,
        document_id: Optional[str] = None,
        filename: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        chunking_strategy: ChunkingStrategy = ChunkingStrategy.SENTENCE,
        chunk_size: int = 512,
        chunk_overlap: int = 50,
    ) -> IngestResponse:
        """Ingest text content into the RAG system.

        Args:
            content: Text content to ingest
            document_id: Optional document ID
            filename: Optional filename
            metadata: Optional metadata
            chunking_strategy: Chunking strategy
            chunk_size: Target chunk size
            chunk_overlap: Chunk overlap

        Returns:
            IngestResponse with document ID and chunk count
        """
        payload: Dict[str, Any] = {
            "content": content,
            "chunking_strategy": chunking_strategy.value,
            "chunk_size": chunk_size,
            "chunk_overlap": chunk_overlap,
        }

        if document_id:
            payload["document_id"] = document_id
        if filename:
            payload["filename"] = filename
        if metadata:
            payload["metadata"] = metadata

        response = await self._http.post("/v1/rag/ingest", json=payload)
        return IngestResponse(**response)

    async def ingest_file(
        self,
        file_url: Optional[str] = None,
        file_path: Optional[str] = None,
        *,
        document_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        chunking_strategy: ChunkingStrategy = ChunkingStrategy.SENTENCE,
    ) -> IngestResponse:
        """Ingest a file into the RAG system.

        Args:
            file_url: URL of file to ingest
            file_path: Local file path to upload
            document_id: Optional document ID
            metadata: Optional metadata
            chunking_strategy: Chunking strategy

        Returns:
            IngestResponse with document ID and chunk count
        """
        if not file_url and not file_path:
            raise ValueError("Either file_url or file_path must be provided")

        payload: Dict[str, Any] = {
            "chunking_strategy": chunking_strategy.value,
        }

        if file_url:
            payload["file_url"] = file_url
        if document_id:
            payload["document_id"] = document_id
        if metadata:
            payload["metadata"] = metadata

        if file_path:
            import json
            import os
            # Serialize complex values for multipart form
            form_data = {
                "chunking_strategy": chunking_strategy.value,
            }
            if document_id:
                form_data["document_id"] = document_id
            if metadata:
                form_data["metadata"] = json.dumps(metadata)

            with open(file_path, "rb") as f:
                files = {"file": (os.path.basename(file_path), f)}
                response = await self._http.post(
                    "/v1/rag/ingest/file",
                    data=form_data,
                    files=files,
                )
        else:
            response = await self._http.post("/v1/rag/ingest/file", json=payload)

        return IngestResponse(**response)

    async def get_document(self, document_id: str) -> Document:
        """Get document metadata by ID.

        Args:
            document_id: Document identifier

        Returns:
            Document with metadata
        """
        response = await self._http.get(f"/v1/rag/documents/{document_id}")
        return Document(**response)

    async def list_documents(
        self,
        *,
        limit: int = 100,
        offset: int = 0,
        metadata_filter: Optional[MetadataFilter] = None,
    ) -> List[Document]:
        """List documents in the RAG store.

        Args:
            limit: Maximum number of documents to return
            offset: Number of documents to skip
            metadata_filter: Optional metadata filters

        Returns:
            List of documents
        """
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if metadata_filter:
            params["metadata_filter"] = metadata_filter

        response = await self._http.get("/v1/rag/documents", params=params)
        return [Document(**doc) for doc in response]

    async def delete_document(self, document_id: str) -> DeleteResponse:
        """Delete a document and all its chunks.

        Args:
            document_id: Document identifier

        Returns:
            DeleteResponse with deletion status
        """
        response = await self._http.delete(f"/v1/rag/documents/{document_id}")
        return DeleteResponse(**response)

    async def stats(self) -> RAGStats:
        """Get RAG store statistics.

        Returns:
            RAGStats with document and chunk counts
        """
        response = await self._http.get("/v1/rag/stats")
        return RAGStats(**response)

    async def clear(self) -> DeleteResponse:
        """Clear all documents and chunks from the RAG store.

        Warning: This permanently deletes all data!

        Returns:
            DeleteResponse with deletion status
        """
        response = await self._http.delete("/v1/rag/clear")
        return DeleteResponse(**response)

    async def generate(
        self,
        query: str,
        *,
        model: str = "gpt-4o-mini",
        system_prompt: Optional[str] = None,
        top_k: int = 5,
        min_score: float = 0.0,
        rerank: bool = False,
        rerank_top_k: int = 3,
        metadata_filter: Optional[MetadataFilter] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        include_sources: bool = True,
    ) -> RAGGenerateResponse:
        """Generate a response using RAG (retrieve + generate).

        Retrieves relevant documents and uses them as context for LLM generation.

        Args:
            query: User query/question
            model: LLM model to use for generation
            system_prompt: Custom system prompt (use {context} placeholder)
            top_k: Number of documents to retrieve
            min_score: Minimum similarity score for retrieval
            rerank: Whether to rerank results
            rerank_top_k: Number of results after reranking
            metadata_filter: Optional metadata filters for retrieval
            temperature: LLM temperature (0.0 to 1.0)
            max_tokens: Maximum tokens for response
            include_sources: Whether to include source documents in response

        Returns:
            RAGGenerateResponse with generated content and sources

        Example:
            >>> async with AsyncLunar() as client:
            ...     response = await client.rag.generate(
            ...         query="What is machine learning?",
            ...         model="gpt-4o-mini",
            ...     )
            ...     print(response.content)
        """
        total_start = time.time()

        # Step 1: Retrieve relevant documents
        retrieval_start = time.time()
        retrieval_response = await self.retrieve(
            query=query,
            top_k=top_k,
            min_score=min_score,
            metadata_filter=metadata_filter,
            rerank=rerank,
            rerank_top_k=rerank_top_k,
        )
        retrieval_latency = (time.time() - retrieval_start) * 1000

        # Step 2: Build context from retrieved chunks
        context_parts = []
        for i, result in enumerate(retrieval_response.results, 1):
            context_parts.append(f"[{i}] {result.content}")
        context = "\n\n".join(context_parts) if context_parts else "No relevant context found."

        # Step 3: Build system prompt with context
        prompt_template = system_prompt or DEFAULT_SYSTEM_PROMPT
        final_system_prompt = prompt_template.format(context=context)

        # Step 4: Call LLM via Lunar chat completions
        generation_start = time.time()

        chat_params: Dict[str, Any] = {
            "model": model,
            "messages": [
                {"role": "system", "content": final_system_prompt},
                {"role": "user", "content": query},
            ],
            "temperature": temperature,
        }
        if max_tokens:
            chat_params["max_tokens"] = max_tokens

        chat_response = await self._client.chat.completions.create(**chat_params)
        generation_latency = (time.time() - generation_start) * 1000

        total_latency = (time.time() - total_start) * 1000

        # Build response
        return RAGGenerateResponse(
            content=chat_response.choices[0].message.content or "",
            model=chat_response.model,
            query=query,
            sources=retrieval_response.results if include_sources else [],
            usage={
                "prompt_tokens": chat_response.usage.prompt_tokens if chat_response.usage else 0,
                "completion_tokens": chat_response.usage.completion_tokens if chat_response.usage else 0,
                "total_tokens": chat_response.usage.total_tokens if chat_response.usage else 0,
            } if chat_response.usage else None,
            retrieval_latency_ms=retrieval_latency,
            generation_latency_ms=generation_latency,
            total_latency_ms=total_latency,
        )
