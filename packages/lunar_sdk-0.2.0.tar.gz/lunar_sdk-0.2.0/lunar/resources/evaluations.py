"""Evaluations resource for running and managing evaluations."""

from __future__ import annotations

import asyncio
from typing import (
    Any,
    Awaitable,
    Callable,
    Dict,
    List,
    Optional,
    Union,
)

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..evals._base import BaseScorer, ensure_scorer
from ..evals._runner import EvaluationRunner
from ..evals.types import (
    DataPoint,
    EvaluationProgress,
    EvaluationResult,
    EvaluationStatus,
    EvaluationStatusResponse,
)

# Type aliases
TaskFunction = Callable[[Union[str, Dict[str, Any]]], str]
AsyncTaskFunction = Callable[[Union[str, Dict[str, Any]]], Awaitable[str]]
ProgressCallback = Callable[[EvaluationProgress], None]


class Evaluations:
    """Synchronous evaluations resource.

    Example:
        >>> from lunar import Lunar
        >>> from lunar.evals import exactMatch, llmJudge
        >>>
        >>> client = Lunar()
        >>>
        >>> result = client.evals.run(
        ...     name="My Evaluation",
        ...     dataset=[{"input": "Hi", "expected": "Hello"}],
        ...     task=lambda x: client.chat.completions.create(
        ...         model="claude-3-5-haiku",
        ...         messages=[{"role": "user", "content": x}]
        ...     ).choices[0].message.content,
        ...     scorers=[exactMatch],
        ... )
        >>> print(f"Score: {result.summary.scores['exactMatch'].mean}")
    """

    def __init__(
        self,
        http: HTTPClient,
        config: LunarConfig,
        client: Any,
    ) -> None:
        """Initialize evaluations resource.

        Args:
            http: HTTP client
            config: Lunar configuration
            client: Parent Lunar client instance
        """
        self._http = http
        self._config = config
        self._client = client
        self._runner = EvaluationRunner(client)

    def run(
        self,
        name: str,
        dataset: Union[List[Dict[str, Any]], List[DataPoint]],
        task: TaskFunction,
        scorers: List[Union[BaseScorer, Callable[..., float]]],
        on_progress: Optional[ProgressCallback] = None,
        log_to_api: bool = True,
        max_concurrent: int = 10,
        models: Optional[List[str]] = None,
        show_progress: bool = True,
    ) -> EvaluationResult:
        """Run an evaluation locally.

        This executes the task function for each datapoint in the dataset,
        then runs all scorers on the outputs.

        Args:
            name: Name of the evaluation
            dataset: List of datapoints (dicts with 'input' and optionally 'expected')
            task: Function that takes input and returns output string
            scorers: List of scorers to apply to outputs
            on_progress: Optional callback for progress updates
            log_to_api: Whether to log results to Lunar API
            max_concurrent: Maximum concurrent task executions
            models: Optional list of model names being tested (for display in UI)
            show_progress: Whether to display progress bar (default: True)

        Returns:
            EvaluationResult with scores and summary

        Example:
            >>> result = client.evals.run(
            ...     name="QA Test",
            ...     dataset=[
            ...         {"input": "What is 2+2?", "expected": "4"},
            ...         {"input": "Capital of France?", "expected": "Paris"},
            ...     ],
            ...     task=lambda x: call_my_llm(x),
            ...     scorers=[exactMatch, contains],
            ... )
        """
        self._runner._max_concurrent = max_concurrent

        # Run async version in event loop
        # Handle Jupyter notebooks where event loop is already running
        try:
            loop = asyncio.get_running_loop()
            # Already in an async context (e.g., Jupyter)
            # Try to use nest_asyncio if available
            try:
                import nest_asyncio
                nest_asyncio.apply()
                return loop.run_until_complete(
                    self._runner.arun(
                        name=name,
                        dataset=dataset,
                        task=task,
                        scorers=scorers,
                        on_progress=on_progress,
                        log_to_api=log_to_api,
                        models=models,
                        show_progress=show_progress,
                    )
                )
            except ImportError:
                # Fall back to creating a task and running it
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    future = pool.submit(
                        asyncio.run,
                        self._runner.arun(
                            name=name,
                            dataset=dataset,
                            task=task,
                            scorers=scorers,
                            on_progress=on_progress,
                            log_to_api=log_to_api,
                            models=models,
                            show_progress=show_progress,
                        )
                    )
                    return future.result()
        except RuntimeError:
            # No running loop, safe to use asyncio.run
            return asyncio.run(
                self._runner.arun(
                    name=name,
                    dataset=dataset,
                    task=task,
                    scorers=scorers,
                    on_progress=on_progress,
                    log_to_api=log_to_api,
                    models=models,
                    show_progress=show_progress,
                )
            )

    def list(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> List[EvaluationResult]:
        """List evaluations.

        Args:
            limit: Maximum number of evaluations to return
            offset: Number of evaluations to skip

        Returns:
            List of evaluation results
        """
        response = self._http.get(
            "/v1/evaluations",
            params={"limit": limit, "offset": offset},
        )
        return [EvaluationResult(**eval_data) for eval_data in response.get("evaluations", [])]

    def get(self, evaluation_id: str) -> EvaluationResult:
        """Get a specific evaluation by ID.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            EvaluationResult
        """
        response = self._http.get(f"/v1/evaluations/{evaluation_id}")
        return EvaluationResult(**response)

    def delete(self, evaluation_id: str) -> bool:
        """Delete an evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            True if deleted successfully
        """
        self._http.delete(f"/v1/evaluations/{evaluation_id}")
        return True

    def create(
        self,
        name: str,
        dataset_id: str,
        models: List[str],
        metrics: List[str],
        **kwargs: Any,
    ) -> EvaluationResult:
        """Create and start an evaluation on the backend.

        Args:
            name: Evaluation name
            dataset_id: Dataset ID to evaluate against
            models: List of model identifiers
            metrics: List of metric identifiers
            **kwargs: Additional parameters passed to the API

        Returns:
            Created EvaluationResult
        """
        body: Dict[str, Any] = {
            "name": name,
            "dataset_id": dataset_id,
            "models": models,
            "metrics": metrics,
            **kwargs,
        }
        response = self._http.post("/v1/evaluations", json=body)
        return EvaluationResult(**response)

    def status(self, evaluation_id: str) -> EvaluationStatusResponse:
        """Get lightweight status for an evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            EvaluationStatusResponse
        """
        response = self._http.get(f"/v1/evaluations/{evaluation_id}/status")
        return EvaluationStatusResponse(**response)

    def results(self, evaluation_id: str) -> Dict[str, Any]:
        """Get detailed results for a completed evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            Results dict
        """
        return self._http.get(f"/v1/evaluations/{evaluation_id}/results")

    def export(self, evaluation_id: str, format: str = "json") -> Dict[str, Any]:
        """Export evaluation results.

        Args:
            evaluation_id: Evaluation ID
            format: Export format (e.g. 'json', 'csv')

        Returns:
            Export data
        """
        return self._http.get(
            f"/v1/evaluations/{evaluation_id}/export",
            params={"format": format},
        )

    def cancel(self, evaluation_id: str) -> EvaluationResult:
        """Cancel a running evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            Updated EvaluationResult
        """
        response = self._http.post(f"/v1/evaluations/{evaluation_id}/cancel")
        return EvaluationResult(**response)

    def rerun(self, evaluation_id: str) -> EvaluationResult:
        """Re-run a completed or failed evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            New EvaluationResult
        """
        response = self._http.post(f"/v1/evaluations/{evaluation_id}/rerun")
        return EvaluationResult(**response)

    def cleanup(self, stale_threshold_hours: int = 24) -> Dict[str, Any]:
        """Clean up stale evaluations.

        Args:
            stale_threshold_hours: Hours after which evaluations are considered stale

        Returns:
            Cleanup summary
        """
        return self._http.post(
            "/v1/evaluations/cleanup",
            json={"stale_threshold_hours": stale_threshold_hours},
        )

    def wait(
        self,
        evaluation_id: str,
        poll_interval: float = 2.0,
        timeout: Optional[float] = None,
        on_progress: Optional[ProgressCallback] = None,
    ) -> EvaluationResult:
        """Wait for an evaluation to complete.

        Args:
            evaluation_id: Evaluation ID
            poll_interval: Seconds between status checks
            timeout: Maximum seconds to wait (None for no timeout)
            on_progress: Optional callback for progress updates

        Returns:
            Completed EvaluationResult

        Raises:
            TimeoutError: If timeout is exceeded
        """
        import time

        start_time = time.time()

        while True:
            result = self.get(evaluation_id)

            if on_progress and result.progress:
                on_progress(result.progress)

            if result.status in (
                EvaluationStatus.COMPLETED,
                EvaluationStatus.FAILED,
                EvaluationStatus.CANCELLED,
            ):
                return result

            if timeout and (time.time() - start_time) > timeout:
                raise TimeoutError(
                    f"Evaluation {evaluation_id} did not complete within {timeout}s"
                )

            time.sleep(poll_interval)


class AsyncEvaluations:
    """Asynchronous evaluations resource.

    Example:
        >>> from lunar import AsyncLunar
        >>> from lunar.evals import exactMatch
        >>>
        >>> async with AsyncLunar() as client:
        ...     result = await client.evals.run(
        ...         name="My Evaluation",
        ...         dataset=[{"input": "Hi", "expected": "Hello"}],
        ...         task=my_async_task,
        ...         scorers=[exactMatch],
        ...     )
    """

    def __init__(
        self,
        http: AsyncHTTPClient,
        config: LunarConfig,
        client: Any,
    ) -> None:
        """Initialize async evaluations resource.

        Args:
            http: Async HTTP client
            config: Lunar configuration
            client: Parent AsyncLunar client instance
        """
        self._http = http
        self._config = config
        self._client = client
        self._runner = EvaluationRunner(client)

    async def run(
        self,
        name: str,
        dataset: Union[List[Dict[str, Any]], List[DataPoint]],
        task: Union[TaskFunction, AsyncTaskFunction],
        scorers: List[Union[BaseScorer, Callable[..., float]]],
        on_progress: Optional[ProgressCallback] = None,
        log_to_api: bool = True,
        max_concurrent: int = 10,
        models: Optional[List[str]] = None,
        show_progress: bool = True,
    ) -> EvaluationResult:
        """Run an evaluation asynchronously.

        This executes the task function for each datapoint in the dataset,
        then runs all scorers on the outputs.

        Args:
            name: Name of the evaluation
            dataset: List of datapoints
            task: Function that takes input and returns output (sync or async)
            scorers: List of scorers to apply to outputs
            on_progress: Optional callback for progress updates
            log_to_api: Whether to log results to Lunar API
            max_concurrent: Maximum concurrent task executions
            models: Optional list of model names being tested (for display in UI)
            show_progress: Whether to display progress bar (default: True)

        Returns:
            EvaluationResult with scores and summary
        """
        self._runner._max_concurrent = max_concurrent

        return await self._runner.arun(
            name=name,
            dataset=dataset,
            task=task,
            scorers=scorers,
            on_progress=on_progress,
            log_to_api=log_to_api,
            models=models,
            show_progress=show_progress,
        )

    async def list(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> List[EvaluationResult]:
        """List evaluations.

        Args:
            limit: Maximum number of evaluations to return
            offset: Number of evaluations to skip

        Returns:
            List of evaluation results
        """
        response = await self._http.get(
            "/v1/evaluations",
            params={"limit": limit, "offset": offset},
        )
        return [EvaluationResult(**eval_data) for eval_data in response.get("evaluations", [])]

    async def get(self, evaluation_id: str) -> EvaluationResult:
        """Get a specific evaluation by ID.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            EvaluationResult
        """
        response = await self._http.get(f"/v1/evaluations/{evaluation_id}")
        return EvaluationResult(**response)

    async def delete(self, evaluation_id: str) -> bool:
        """Delete an evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            True if deleted successfully
        """
        await self._http.delete(f"/v1/evaluations/{evaluation_id}")
        return True

    async def create(
        self,
        name: str,
        dataset_id: str,
        models: List[str],
        metrics: List[str],
        **kwargs: Any,
    ) -> EvaluationResult:
        """Create and start an evaluation on the backend.

        Args:
            name: Evaluation name
            dataset_id: Dataset ID to evaluate against
            models: List of model identifiers
            metrics: List of metric identifiers
            **kwargs: Additional parameters passed to the API

        Returns:
            Created EvaluationResult
        """
        body: Dict[str, Any] = {
            "name": name,
            "dataset_id": dataset_id,
            "models": models,
            "metrics": metrics,
            **kwargs,
        }
        response = await self._http.post("/v1/evaluations", json=body)
        return EvaluationResult(**response)

    async def status(self, evaluation_id: str) -> EvaluationStatusResponse:
        """Get lightweight status for an evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            EvaluationStatusResponse
        """
        response = await self._http.get(f"/v1/evaluations/{evaluation_id}/status")
        return EvaluationStatusResponse(**response)

    async def results(self, evaluation_id: str) -> Dict[str, Any]:
        """Get detailed results for a completed evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            Results dict
        """
        return await self._http.get(f"/v1/evaluations/{evaluation_id}/results")

    async def export(self, evaluation_id: str, format: str = "json") -> Dict[str, Any]:
        """Export evaluation results.

        Args:
            evaluation_id: Evaluation ID
            format: Export format (e.g. 'json', 'csv')

        Returns:
            Export data
        """
        return await self._http.get(
            f"/v1/evaluations/{evaluation_id}/export",
            params={"format": format},
        )

    async def cancel(self, evaluation_id: str) -> EvaluationResult:
        """Cancel a running evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            Updated EvaluationResult
        """
        response = await self._http.post(f"/v1/evaluations/{evaluation_id}/cancel")
        return EvaluationResult(**response)

    async def rerun(self, evaluation_id: str) -> EvaluationResult:
        """Re-run a completed or failed evaluation.

        Args:
            evaluation_id: Evaluation ID

        Returns:
            New EvaluationResult
        """
        response = await self._http.post(f"/v1/evaluations/{evaluation_id}/rerun")
        return EvaluationResult(**response)

    async def cleanup(self, stale_threshold_hours: int = 24) -> Dict[str, Any]:
        """Clean up stale evaluations.

        Args:
            stale_threshold_hours: Hours after which evaluations are considered stale

        Returns:
            Cleanup summary
        """
        return await self._http.post(
            "/v1/evaluations/cleanup",
            json={"stale_threshold_hours": stale_threshold_hours},
        )

    async def wait(
        self,
        evaluation_id: str,
        poll_interval: float = 2.0,
        timeout: Optional[float] = None,
        on_progress: Optional[ProgressCallback] = None,
    ) -> EvaluationResult:
        """Wait for an evaluation to complete.

        Args:
            evaluation_id: Evaluation ID
            poll_interval: Seconds between status checks
            timeout: Maximum seconds to wait (None for no timeout)
            on_progress: Optional callback for progress updates

        Returns:
            Completed EvaluationResult

        Raises:
            TimeoutError: If timeout is exceeded
        """
        import time

        start_time = time.time()

        while True:
            result = await self.get(evaluation_id)

            if on_progress and result.progress:
                on_progress(result.progress)

            if result.status in (
                EvaluationStatus.COMPLETED,
                EvaluationStatus.FAILED,
                EvaluationStatus.CANCELLED,
            ):
                return result

            if timeout and (time.time() - start_time) > timeout:
                raise TimeoutError(f"Evaluation {evaluation_id} did not complete within {timeout}s")

            await asyncio.sleep(poll_interval)
