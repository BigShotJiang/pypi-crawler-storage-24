"""Models and providers resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from ..types.models import Model, ModelsListResponse, Provider, ProvidersListResponse

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient
    from .._config import LunarConfig


class Models:
    """Synchronous models resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        """Initialize models resource.

        Args:
            http: HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    def list(self) -> List[Model]:
        """List available models.

        Returns:
            List of available models
        """
        response = self._http.get("/v1/pricing/models")
        # Response is a list directly from PricingTable
        if isinstance(response, list):
            return [Model.model_validate({"id": m["id"], "owned_by": m["owned_by"]}) for m in response]
        result = ModelsListResponse.model_validate(response)
        return result.data


class AsyncModels:
    """Asynchronous models resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        """Initialize async models resource.

        Args:
            http: Async HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    async def list(self) -> List[Model]:
        """List available models.

        Returns:
            List of available models
        """
        response = await self._http.get("/v1/pricing/models")
        # Response is a list directly from PricingTable
        if isinstance(response, list):
            return [Model.model_validate({"id": m["id"], "owned_by": m["owned_by"]}) for m in response]
        result = ModelsListResponse.model_validate(response)
        return result.data


class Providers:
    """Synchronous providers resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        """Initialize providers resource.

        Args:
            http: HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    def list(self, model: Optional[str] = None) -> List[Provider]:
        """List available providers.

        Args:
            model: Optional model name to filter providers

        Returns:
            List of providers
        """
        params = {}
        if model:
            params["model"] = model

        response = self._http.get("/v1/providers", params=params if params else None)

        # Handle both list response and object with providers key
        if isinstance(response, list):
            return [Provider.model_validate(p) for p in response]
        else:
            result = ProvidersListResponse.model_validate(response)
            return result.providers


class AsyncProviders:
    """Asynchronous providers resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        """Initialize async providers resource.

        Args:
            http: Async HTTP client
            config: Lunar configuration
        """
        self._http = http
        self._config = config

    async def list(self, model: Optional[str] = None) -> List[Provider]:
        """List available providers.

        Args:
            model: Optional model name to filter providers

        Returns:
            List of providers
        """
        params = {}
        if model:
            params["model"] = model

        response = await self._http.get("/v1/providers", params=params if params else None)

        # Handle both list response and object with providers key
        if isinstance(response, list):
            return [Provider.model_validate(p) for p in response]
        else:
            result = ProvidersListResponse.model_validate(response)
            return result.providers
