"""Trace issues resource for detecting and managing quality issues in traces."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..evals.types import ScanResult, TraceIssue


class TraceIssues:
    """Synchronous trace issues resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def list(
        self,
        severity: Optional[str] = None,
        type: Optional[str] = None,
        resolved: Optional[bool] = None,
    ) -> List[TraceIssue]:
        """List trace issues.

        Args:
            severity: Optional severity filter
            type: Optional type filter
            resolved: Optional resolved status filter

        Returns:
            List of TraceIssue
        """
        params: Dict[str, Any] = {}
        if severity is not None:
            params["severity"] = severity
        if type is not None:
            params["type"] = type
        if resolved is not None:
            params["resolved"] = resolved
        response = self._http.get("/v1/trace-issues", params=params or None)
        return [TraceIssue(**i) for i in response.get("issues", [])]

    def scan(self) -> ScanResult:
        """Start a trace issues scan.

        Returns:
            ScanResult
        """
        response = self._http.post("/v1/trace-issues/scan")
        return ScanResult(**response)

    def get_scan(self, scan_id: str) -> ScanResult:
        """Get scan results.

        Args:
            scan_id: Scan ID

        Returns:
            ScanResult
        """
        response = self._http.get(f"/v1/trace-issues/scan/{scan_id}")
        return ScanResult(**response)

    def resolve(self, issue_id: str) -> TraceIssue:
        """Resolve a trace issue.

        Args:
            issue_id: Issue ID

        Returns:
            Updated TraceIssue
        """
        response = self._http.put(f"/v1/trace-issues/{issue_id}/resolve")
        return TraceIssue(**response)


class AsyncTraceIssues:
    """Asynchronous trace issues resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def list(
        self,
        severity: Optional[str] = None,
        type: Optional[str] = None,
        resolved: Optional[bool] = None,
    ) -> List[TraceIssue]:
        """List trace issues."""
        params: Dict[str, Any] = {}
        if severity is not None:
            params["severity"] = severity
        if type is not None:
            params["type"] = type
        if resolved is not None:
            params["resolved"] = resolved
        response = await self._http.get("/v1/trace-issues", params=params or None)
        return [TraceIssue(**i) for i in response.get("issues", [])]

    async def scan(self) -> ScanResult:
        """Start a trace issues scan."""
        response = await self._http.post("/v1/trace-issues/scan")
        return ScanResult(**response)

    async def get_scan(self, scan_id: str) -> ScanResult:
        """Get scan results."""
        response = await self._http.get(f"/v1/trace-issues/scan/{scan_id}")
        return ScanResult(**response)

    async def resolve(self, issue_id: str) -> TraceIssue:
        """Resolve a trace issue."""
        response = await self._http.put(f"/v1/trace-issues/{issue_id}/resolve")
        return TraceIssue(**response)
