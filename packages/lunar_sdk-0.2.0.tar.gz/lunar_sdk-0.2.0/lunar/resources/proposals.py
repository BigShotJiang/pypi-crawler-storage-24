"""Proposals resource for managing evaluation change proposals."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..evals.types import Proposal


class Proposals:
    """Synchronous proposals resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def list(self, status: Optional[str] = None) -> List[Proposal]:
        """List proposals.

        Args:
            status: Optional status filter (pending, approved, rejected)

        Returns:
            List of Proposal
        """
        params: Dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        response = self._http.get("/v1/proposals", params=params or None)
        return [Proposal(**p) for p in response.get("proposals", [])]

    def get(self, proposal_id: str) -> Proposal:
        """Get a proposal by ID.

        Args:
            proposal_id: Proposal ID

        Returns:
            Proposal
        """
        response = self._http.get(f"/v1/proposals/{proposal_id}")
        return Proposal(**response)

    def approve(self, proposal_id: str) -> Proposal:
        """Approve a proposal.

        Args:
            proposal_id: Proposal ID

        Returns:
            Updated Proposal
        """
        response = self._http.post(f"/v1/proposals/{proposal_id}/approve")
        return Proposal(**response)

    def reject(self, proposal_id: str, reason: Optional[str] = None) -> Proposal:
        """Reject a proposal.

        Args:
            proposal_id: Proposal ID
            reason: Optional rejection reason

        Returns:
            Updated Proposal
        """
        body: Dict[str, Any] = {}
        if reason is not None:
            body["reason"] = reason
        response = self._http.post(
            f"/v1/proposals/{proposal_id}/reject",
            json=body or None,
        )
        return Proposal(**response)


class AsyncProposals:
    """Asynchronous proposals resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def list(self, status: Optional[str] = None) -> List[Proposal]:
        """List proposals."""
        params: Dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        response = await self._http.get("/v1/proposals", params=params or None)
        return [Proposal(**p) for p in response.get("proposals", [])]

    async def get(self, proposal_id: str) -> Proposal:
        """Get a proposal by ID."""
        response = await self._http.get(f"/v1/proposals/{proposal_id}")
        return Proposal(**response)

    async def approve(self, proposal_id: str) -> Proposal:
        """Approve a proposal."""
        response = await self._http.post(f"/v1/proposals/{proposal_id}/approve")
        return Proposal(**response)

    async def reject(self, proposal_id: str, reason: Optional[str] = None) -> Proposal:
        """Reject a proposal."""
        body: Dict[str, Any] = {}
        if reason is not None:
            body["reason"] = reason
        response = await self._http.post(
            f"/v1/proposals/{proposal_id}/reject",
            json=body or None,
        )
        return Proposal(**response)
