"""Eval agent resource for AI-driven evaluation setup and analysis."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient


class EvalAgent:
    """Synchronous eval agent resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def analyze(self, dataset_id: str) -> Dict[str, Any]:
        """Analyze a dataset and suggest evaluation setup.

        Args:
            dataset_id: Dataset ID

        Returns:
            Analysis results
        """
        return self._http.post(
            "/v1/eval-agent/analyze",
            json={"dataset_id": dataset_id},
        )

    def setup(self, dataset_id: str, auto_trigger: bool = False) -> Dict[str, Any]:
        """Auto-setup evaluations for a dataset.

        Args:
            dataset_id: Dataset ID
            auto_trigger: Whether to automatically trigger the first run

        Returns:
            Setup result
        """
        return self._http.post(
            "/v1/eval-agent/setup",
            json={"dataset_id": dataset_id, "auto_trigger": auto_trigger},
        )

    def scan(self) -> Dict[str, Any]:
        """Run a general evaluation scan.

        Returns:
            Scan results
        """
        return self._http.post("/v1/eval-agent/scan")


class AsyncEvalAgent:
    """Asynchronous eval agent resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def analyze(self, dataset_id: str) -> Dict[str, Any]:
        """Analyze a dataset and suggest evaluation setup."""
        return await self._http.post(
            "/v1/eval-agent/analyze",
            json={"dataset_id": dataset_id},
        )

    async def setup(self, dataset_id: str, auto_trigger: bool = False) -> Dict[str, Any]:
        """Auto-setup evaluations for a dataset."""
        return await self._http.post(
            "/v1/eval-agent/setup",
            json={"dataset_id": dataset_id, "auto_trigger": auto_trigger},
        )

    async def scan(self) -> Dict[str, Any]:
        """Run a general evaluation scan."""
        return await self._http.post("/v1/eval-agent/scan")
