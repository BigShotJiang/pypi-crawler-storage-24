"""Metrics resource for managing evaluation metrics."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..evals.types import Metric, ScriptValidationResult


class Metrics:
    """Synchronous metrics resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def list(self, type: Optional[str] = None) -> List[Metric]:
        """List metrics.

        Args:
            type: Optional type filter (builtin, custom, llm_judge)

        Returns:
            List of Metric
        """
        params: Dict[str, Any] = {}
        if type is not None:
            params["type"] = type
        response = self._http.get("/v1/metrics", params=params or None)
        return [Metric(**m) for m in response.get("metrics", [])]

    def create(self, name: str, type: str, **kwargs: Any) -> Metric:
        """Create a metric.

        Args:
            name: Metric name
            type: Metric type (exact_match, contains, semantic_sim, llm_judge, latency, cost, python)
            **kwargs: Additional fields (description, python_script/script, config)

        Returns:
            Created Metric
        """
        # Normalize 'script' -> 'python_script' for backend compatibility
        if "script" in kwargs and "python_script" not in kwargs:
            kwargs["python_script"] = kwargs.pop("script")
        body: Dict[str, Any] = {"name": name, "type": type, **kwargs}
        response = self._http.post("/v1/metrics", json=body)
        return Metric(**response)

    def get(self, metric_id: str) -> Metric:
        """Get a metric by ID.

        Args:
            metric_id: Metric ID

        Returns:
            Metric
        """
        response = self._http.get(f"/v1/metrics/{metric_id}")
        return Metric(**response)

    def update(self, metric_id: str, **kwargs: Any) -> Metric:
        """Update a metric.

        Args:
            metric_id: Metric ID
            **kwargs: Fields to update

        Returns:
            Updated Metric
        """
        response = self._http.put(f"/v1/metrics/{metric_id}", json=kwargs)
        return Metric(**response)

    def delete(self, metric_id: str) -> bool:
        """Delete a metric.

        Args:
            metric_id: Metric ID

        Returns:
            True if deleted
        """
        self._http.delete(f"/v1/metrics/{metric_id}")
        return True

    def validate_script(self, python_script: str, **kwargs: Any) -> ScriptValidationResult:
        """Validate a custom metric script.

        Args:
            python_script: Python source code
            **kwargs: Additional validation parameters

        Returns:
            ScriptValidationResult
        """
        body: Dict[str, Any] = {"python_script": python_script, **kwargs}
        response = self._http.post("/v1/metrics/validate-script", json=body)
        return ScriptValidationResult(**response)


class AsyncMetrics:
    """Asynchronous metrics resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def list(self, type: Optional[str] = None) -> List[Metric]:
        """List metrics."""
        params: Dict[str, Any] = {}
        if type is not None:
            params["type"] = type
        response = await self._http.get("/v1/metrics", params=params or None)
        return [Metric(**m) for m in response.get("metrics", [])]

    async def create(self, name: str, type: str, **kwargs: Any) -> Metric:
        """Create a metric."""
        # Normalize 'script' -> 'python_script' for backend compatibility
        if "script" in kwargs and "python_script" not in kwargs:
            kwargs["python_script"] = kwargs.pop("script")
        body: Dict[str, Any] = {"name": name, "type": type, **kwargs}
        response = await self._http.post("/v1/metrics", json=body)
        return Metric(**response)

    async def get(self, metric_id: str) -> Metric:
        """Get a metric by ID."""
        response = await self._http.get(f"/v1/metrics/{metric_id}")
        return Metric(**response)

    async def update(self, metric_id: str, **kwargs: Any) -> Metric:
        """Update a metric."""
        response = await self._http.put(f"/v1/metrics/{metric_id}", json=kwargs)
        return Metric(**response)

    async def delete(self, metric_id: str) -> bool:
        """Delete a metric."""
        await self._http.delete(f"/v1/metrics/{metric_id}")
        return True

    async def validate_script(self, python_script: str, **kwargs: Any) -> ScriptValidationResult:
        """Validate a custom metric script."""
        body: Dict[str, Any] = {"python_script": python_script, **kwargs}
        response = await self._http.post("/v1/metrics/validate-script", json=body)
        return ScriptValidationResult(**response)
