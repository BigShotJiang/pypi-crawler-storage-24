"""Traces resource for recording and listing LLM interaction traces."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..evals.types import Trace


class Traces:
    """Synchronous traces resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def list(
        self,
        limit: int = 100,
        model_id: Optional[str] = None,
        source: Optional[str] = None,
    ) -> List[Trace]:
        """List traces.

        Args:
            limit: Maximum number of traces to return
            model_id: Optional model filter
            source: Optional source filter

        Returns:
            List of Trace
        """
        params: Dict[str, Any] = {"limit": limit}
        if model_id is not None:
            params["model_id"] = model_id
        if source is not None:
            params["source"] = source
        response = self._http.get("/v1/traces", params=params)
        return [Trace(**t) for t in response.get("traces", [])]

    def create(
        self,
        input: Any,
        output: str,
        model_id: Optional[str] = None,
        **kwargs: Any,
    ) -> Trace:
        """Record a trace.

        Args:
            input: Input data
            output: Output text
            model_id: Model identifier
            **kwargs: Additional fields (source, latency_ms, token_count, metadata)

        Returns:
            Created Trace
        """
        body: Dict[str, Any] = {"input": input, "output": output, **kwargs}
        if model_id is not None:
            body["model_id"] = model_id
        response = self._http.post("/v1/traces", json=body)
        return Trace(**response)


class AsyncTraces:
    """Asynchronous traces resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def list(
        self,
        limit: int = 100,
        model_id: Optional[str] = None,
        source: Optional[str] = None,
    ) -> List[Trace]:
        """List traces."""
        params: Dict[str, Any] = {"limit": limit}
        if model_id is not None:
            params["model_id"] = model_id
        if source is not None:
            params["source"] = source
        response = await self._http.get("/v1/traces", params=params)
        return [Trace(**t) for t in response.get("traces", [])]

    async def create(
        self,
        input: Any,
        output: str,
        model_id: Optional[str] = None,
        **kwargs: Any,
    ) -> Trace:
        """Record a trace."""
        body: Dict[str, Any] = {"input": input, "output": output, **kwargs}
        if model_id is not None:
            body["model_id"] = model_id
        response = await self._http.post("/v1/traces", json=body)
        return Trace(**response)
