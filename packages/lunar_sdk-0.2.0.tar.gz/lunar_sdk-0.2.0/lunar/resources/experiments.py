"""Experiments resource for comparing evaluation runs."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._config import LunarConfig
from .._http import AsyncHTTPClient, HTTPClient
from ..evals.types import Experiment


class Experiments:
    """Synchronous experiments resource."""

    def __init__(self, http: HTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    def list(self, status: Optional[str] = None) -> List[Experiment]:
        """List experiments.

        Args:
            status: Optional status filter

        Returns:
            List of Experiment
        """
        params: Dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        response = self._http.get("/v1/experiments", params=params or None)
        return [Experiment(**e) for e in response.get("experiments", [])]

    def create(
        self,
        name: str,
        dataset_id: str,
        evaluation_ids: List[str],
        **kwargs: Any,
    ) -> Experiment:
        """Create an experiment.

        Args:
            name: Experiment name
            dataset_id: Dataset ID
            evaluation_ids: List of evaluation IDs to compare
            **kwargs: Additional parameters

        Returns:
            Created Experiment
        """
        body: Dict[str, Any] = {
            "name": name,
            "dataset_id": dataset_id,
            "evaluation_ids": evaluation_ids,
            **kwargs,
        }
        response = self._http.post("/v1/experiments", json=body)
        return Experiment(**response)

    def get(self, experiment_id: str) -> Experiment:
        """Get an experiment by ID.

        Args:
            experiment_id: Experiment ID

        Returns:
            Experiment
        """
        response = self._http.get(f"/v1/experiments/{experiment_id}")
        return Experiment(**response)

    def delete(self, experiment_id: str) -> bool:
        """Delete an experiment.

        Args:
            experiment_id: Experiment ID

        Returns:
            True if deleted
        """
        self._http.delete(f"/v1/experiments/{experiment_id}")
        return True

    def comparison(self, experiment_id: str, force: bool = False) -> Dict[str, Any]:
        """Get comparison data for an experiment.

        Args:
            experiment_id: Experiment ID
            force: Force recomputation

        Returns:
            Comparison data
        """
        params: Dict[str, Any] = {}
        if force:
            params["force"] = True
        return self._http.get(
            f"/v1/experiments/{experiment_id}/comparison",
            params=params or None,
        )


class AsyncExperiments:
    """Asynchronous experiments resource."""

    def __init__(self, http: AsyncHTTPClient, config: LunarConfig) -> None:
        self._http = http
        self._config = config

    async def list(self, status: Optional[str] = None) -> List[Experiment]:
        """List experiments."""
        params: Dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        response = await self._http.get("/v1/experiments", params=params or None)
        return [Experiment(**e) for e in response.get("experiments", [])]

    async def create(
        self,
        name: str,
        dataset_id: str,
        evaluation_ids: List[str],
        **kwargs: Any,
    ) -> Experiment:
        """Create an experiment."""
        body: Dict[str, Any] = {
            "name": name,
            "dataset_id": dataset_id,
            "evaluation_ids": evaluation_ids,
            **kwargs,
        }
        response = await self._http.post("/v1/experiments", json=body)
        return Experiment(**response)

    async def get(self, experiment_id: str) -> Experiment:
        """Get an experiment by ID."""
        response = await self._http.get(f"/v1/experiments/{experiment_id}")
        return Experiment(**response)

    async def delete(self, experiment_id: str) -> bool:
        """Delete an experiment."""
        await self._http.delete(f"/v1/experiments/{experiment_id}")
        return True

    async def comparison(self, experiment_id: str, force: bool = False) -> Dict[str, Any]:
        """Get comparison data for an experiment."""
        params: Dict[str, Any] = {}
        if force:
            params["force"] = True
        return await self._http.get(
            f"/v1/experiments/{experiment_id}/comparison",
            params=params or None,
        )
