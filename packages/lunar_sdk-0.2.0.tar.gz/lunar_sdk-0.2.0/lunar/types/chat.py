"""Chat completion type definitions."""

from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field

from .models import Usage


class FunctionCall(BaseModel):
    """A function call within a tool call."""

    name: str = Field(..., description="The name of the function to call")
    arguments: str = Field(..., description="JSON-encoded arguments for the function")


class ToolCall(BaseModel):
    """A tool call requested by the model."""

    id: str = Field(..., description="The ID of the tool call")
    type: str = Field(default="function", description="The type of the tool call")
    function: FunctionCall = Field(..., description="The function call details")


class ChatMessage(BaseModel):
    """A message in a chat conversation."""

    role: str = Field(
        ..., description="The role of the message author (system, user, assistant, tool)"
    )
    content: Optional[Union[str, List[Any]]] = Field(
        default=None, description="The content of the message"
    )
    name: Optional[str] = Field(
        default=None, description="Name of the tool (for tool role messages)"
    )
    tool_calls: Optional[List[ToolCall]] = Field(
        default=None, description="Tool calls requested by the assistant"
    )
    tool_call_id: Optional[str] = Field(
        default=None, description="ID of the tool call this message responds to (for tool role)"
    )


class ChatChoice(BaseModel):
    """A single choice in a chat completion response."""

    index: int = Field(..., description="The index of this choice")
    message: ChatMessage = Field(..., description="The generated message")
    finish_reason: Optional[str] = Field(
        default="stop", description="The reason the generation stopped"
    )


class ChatCompletion(BaseModel):
    """A chat completion response."""

    id: str = Field(..., description="Unique identifier for this completion")
    object: str = Field(default="chat.completion", description="Object type")
    created: Optional[int] = Field(default=None, description="Unix timestamp of creation")
    model: str = Field(..., description="The model used for completion")
    choices: List[ChatChoice] = Field(..., description="List of completion choices")
    usage: Optional[Usage] = Field(default=None, description="Token usage and cost information")


class DeltaToolCall(BaseModel):
    """A partial tool call in a streaming delta."""

    index: int = Field(..., description="Index of the tool call being streamed")
    id: Optional[str] = Field(default=None, description="The ID of the tool call (first chunk)")
    type: Optional[str] = Field(default=None, description="The type of the tool call")
    function: Optional[Dict[str, Any]] = Field(
        default=None, description="Partial function call (name and/or arguments fragment)"
    )


class ChatChoiceDelta(BaseModel):
    """Delta content for streaming responses."""

    role: Optional[str] = Field(default=None, description="The role (only in first chunk)")
    content: Optional[str] = Field(default=None, description="The content delta")
    tool_calls: Optional[List[DeltaToolCall]] = Field(
        default=None, description="Partial tool calls being streamed"
    )


class ChatStreamChoice(BaseModel):
    """A single choice in a streaming chat completion response."""

    index: int = Field(..., description="The index of this choice")
    delta: ChatChoiceDelta = Field(..., description="The delta content")
    finish_reason: Optional[str] = Field(
        default=None, description="The reason the generation stopped (in final chunk)"
    )


class ChatCompletionChunk(BaseModel):
    """A streaming chat completion chunk."""

    id: str = Field(..., description="Unique identifier for this completion")
    object: str = Field(default="chat.completion.chunk", description="Object type")
    created: Optional[int] = Field(default=None, description="Unix timestamp of creation")
    model: str = Field(..., description="The model used for completion")
    choices: List[ChatStreamChoice] = Field(..., description="List of streaming choices")


# Type alias for message input (can be dict or ChatMessage)
MessageInput = Union[ChatMessage, dict]
