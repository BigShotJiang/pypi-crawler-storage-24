"""RAG (Retrieval-Augmented Generation) type definitions."""

from typing import Any, Dict, List, Optional, Union
from enum import Enum

from pydantic import BaseModel, Field


class DocumentType(str, Enum):
    """Supported document types for ingestion."""
    PDF = "pdf"
    IMAGE = "image"
    DOCX = "docx"
    DOC = "doc"
    TEXT = "text"
    MARKDOWN = "markdown"
    HTML = "html"
    URL = "url"


class ChunkingStrategy(str, Enum):
    """Chunking strategies for document processing."""
    FIXED_SIZE = "fixed_size"
    SENTENCE = "sentence"
    PARAGRAPH = "paragraph"
    SEMANTIC = "semantic"


class Document(BaseModel):
    """A document in the RAG system."""

    id: str = Field(..., description="Unique document identifier")
    filename: Optional[str] = Field(default=None, description="Original filename")
    type: DocumentType = Field(default=DocumentType.TEXT, description="Document type")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Document metadata")
    created_at: Optional[str] = Field(default=None, description="Creation timestamp")


class Chunk(BaseModel):
    """A chunk of text from a document."""

    id: str = Field(..., description="Unique chunk identifier")
    document_id: str = Field(..., description="Parent document ID")
    content: str = Field(..., description="Text content of the chunk")
    position: int = Field(default=0, description="Position in the document")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Chunk metadata")


class SearchResult(BaseModel):
    """A single search result from RAG retrieval."""

    chunk_id: str = Field(..., description="Chunk identifier")
    document_id: str = Field(..., description="Document identifier")
    content: str = Field(..., description="Chunk content")
    score: float = Field(..., description="Similarity score (0.0 to 1.0)")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Result metadata")


class RetrievalResponse(BaseModel):
    """Response from a RAG retrieval query."""

    query: str = Field(..., description="Original query")
    results: List[SearchResult] = Field(default_factory=list, description="Search results")
    latency_ms: float = Field(default=0.0, description="Query latency in milliseconds")
    total_results: int = Field(default=0, description="Total number of results found")


class IngestRequest(BaseModel):
    """Request to ingest content into RAG."""

    content: str = Field(..., description="Text content to ingest")
    document_id: Optional[str] = Field(default=None, description="Optional document ID")
    filename: Optional[str] = Field(default=None, description="Optional filename")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Document metadata")
    chunking_strategy: ChunkingStrategy = Field(
        default=ChunkingStrategy.SENTENCE,
        description="Strategy for splitting content into chunks"
    )
    chunk_size: int = Field(default=512, description="Target chunk size in characters")
    chunk_overlap: int = Field(default=50, description="Overlap between chunks")


class IngestResponse(BaseModel):
    """Response from a RAG ingestion operation."""

    document_id: str = Field(..., description="Document identifier")
    chunks_created: int = Field(..., description="Number of chunks created")
    status: str = Field(default="success", description="Ingestion status")
    message: Optional[str] = Field(default=None, description="Status message")


class IngestFileRequest(BaseModel):
    """Request to ingest a file into RAG."""

    file_url: Optional[str] = Field(default=None, description="URL of file to ingest")
    file_path: Optional[str] = Field(default=None, description="Local path to file")
    document_id: Optional[str] = Field(default=None, description="Optional document ID")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Document metadata")
    chunking_strategy: ChunkingStrategy = Field(
        default=ChunkingStrategy.SENTENCE,
        description="Strategy for splitting content into chunks"
    )


class RAGConfig(BaseModel):
    """Configuration for RAG operations."""

    top_k: int = Field(default=5, description="Number of results to retrieve")
    min_score: float = Field(default=0.0, description="Minimum similarity score threshold")
    rerank: bool = Field(default=False, description="Whether to rerank results")
    rerank_top_k: int = Field(default=3, description="Number of results after reranking")
    include_metadata: bool = Field(default=True, description="Include metadata in results")


class DeleteResponse(BaseModel):
    """Response from a delete operation."""

    success: bool = Field(..., description="Whether deletion was successful")
    deleted_chunks: int = Field(default=0, description="Number of chunks deleted")
    message: Optional[str] = Field(default=None, description="Status message")


class RAGStats(BaseModel):
    """Statistics about the RAG store."""

    total_documents: int = Field(default=0, description="Total number of documents")
    total_chunks: int = Field(default=0, description="Total number of chunks")
    storage_bytes: Optional[int] = Field(default=None, description="Storage used in bytes")


class RAGGenerateRequest(BaseModel):
    """Request for RAG-augmented generation."""

    query: str = Field(..., description="User query")
    model: str = Field(default="gpt-4o-mini", description="LLM model to use")
    system_prompt: Optional[str] = Field(
        default=None,
        description="Custom system prompt. Use {context} placeholder for retrieved content."
    )
    top_k: int = Field(default=5, description="Number of documents to retrieve")
    min_score: float = Field(default=0.0, description="Minimum similarity score")
    rerank: bool = Field(default=False, description="Whether to rerank results")
    temperature: float = Field(default=0.7, description="LLM temperature")
    max_tokens: Optional[int] = Field(default=None, description="Max tokens for response")
    metadata_filter: Optional[Dict[str, Any]] = Field(default=None, description="Metadata filter for retrieval")


class RAGGenerateResponse(BaseModel):
    """Response from RAG-augmented generation."""

    content: str = Field(..., description="Generated response content")
    model: str = Field(..., description="Model used for generation")
    query: str = Field(..., description="Original query")
    sources: List[SearchResult] = Field(default_factory=list, description="Retrieved sources used")
    usage: Optional[Dict[str, Any]] = Field(default=None, description="Token usage information")
    retrieval_latency_ms: float = Field(default=0.0, description="Retrieval latency")
    generation_latency_ms: float = Field(default=0.0, description="Generation latency")
    total_latency_ms: float = Field(default=0.0, description="Total latency")


# Type aliases for convenience
MetadataFilter = Dict[str, Union[str, int, float, bool, List[str]]]
