"""Model and provider type definitions."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class Usage(BaseModel):
    """Token usage and cost information."""

    prompt_tokens: int = Field(..., description="Number of tokens in the prompt")
    completion_tokens: int = Field(..., description="Number of tokens in the completion")
    total_tokens: int = Field(..., description="Total tokens used")
    input_cost_usd: Optional[float] = Field(default=None, description="Cost for input tokens in USD")
    output_cost_usd: Optional[float] = Field(
        default=None, description="Cost for output tokens in USD"
    )
    cache_input_cost_usd: Optional[float] = Field(
        default=None, description="Cost for cached input tokens in USD"
    )
    total_cost_usd: Optional[float] = Field(default=None, description="Total cost in USD")
    latency_ms: Optional[float] = Field(
        default=None, description="Total request latency in milliseconds"
    )
    ttft_ms: Optional[float] = Field(
        default=None, description="Time to first token in milliseconds"
    )


class Model(BaseModel):
    """Model information."""

    id: str = Field(..., description="Model identifier")
    object: str = Field(default="model", description="Object type")
    created: Optional[int] = Field(default=None, description="Unix timestamp of creation")
    owned_by: str = Field(..., description="Model owner/provider")


class ModelsListResponse(BaseModel):
    """Response from listing models."""

    object: str = Field(default="list", description="Object type")
    data: List[Model] = Field(..., description="List of available models")


class Provider(BaseModel):
    """Provider information."""

    id: str = Field(..., description="Provider identifier")
    type: str = Field(..., description="Provider type")
    enabled: bool = Field(..., description="Whether the provider is enabled")
    params: Dict[str, Any] = Field(default_factory=dict, description="Provider parameters")


class ProvidersListResponse(BaseModel):
    """Response from listing providers."""

    providers: List[Provider] = Field(..., description="List of providers")
