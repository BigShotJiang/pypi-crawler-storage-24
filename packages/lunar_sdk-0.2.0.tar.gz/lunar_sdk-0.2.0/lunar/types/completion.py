"""Text completion type definitions."""

from typing import List, Optional

from pydantic import BaseModel, Field

from .models import Usage


class CompletionChoice(BaseModel):
    """A single choice in a text completion response."""

    index: int = Field(..., description="The index of this choice")
    text: str = Field(..., description="The generated text")
    finish_reason: Optional[str] = Field(
        default="stop", description="The reason the generation stopped"
    )


class Completion(BaseModel):
    """A text completion response."""

    id: str = Field(..., description="Unique identifier for this completion")
    object: str = Field(default="text_completion", description="Object type")
    created: Optional[int] = Field(default=None, description="Unix timestamp of creation")
    model: str = Field(..., description="The model used for completion")
    choices: List[CompletionChoice] = Field(..., description="List of completion choices")
    usage: Optional[Usage] = Field(default=None, description="Token usage and cost information")
