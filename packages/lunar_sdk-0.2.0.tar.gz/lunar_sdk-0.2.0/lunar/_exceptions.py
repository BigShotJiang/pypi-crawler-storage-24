"""Lunar SDK exceptions.

Exceptions are categorized into two groups:
1. Non-fallback errors (client errors): These indicate problems with the request
   itself that won't be fixed by trying a different model/provider.
2. Fallback-able errors (server/infra errors): These indicate temporary issues
   that might be resolved by trying a different model/provider.
"""

from typing import Any, Dict, Optional


class LunarError(Exception):
    """Base exception for all Lunar SDK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class APIError(LunarError):
    """Base exception for API-related errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message)

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


# =============================================================================
# NON-FALLBACK ERRORS (Client Errors)
# These errors indicate problems with the request that won't be fixed by
# trying a different model/provider. Fallback should NOT be attempted.
# =============================================================================


class BadRequestError(APIError):
    """400 Bad Request - Invalid request parameters.

    If the prompt is invalid for one provider, it will be invalid for others.
    Do NOT attempt fallback.
    """

    pass


class AuthenticationError(APIError):
    """401 Unauthorized - Invalid or missing API key.

    The same API key is used for all providers.
    Do NOT attempt fallback.
    """

    pass


class PermissionDeniedError(APIError):
    """403 Forbidden - Access denied.

    Permissions apply across all providers.
    Do NOT attempt fallback.
    """

    pass


class NotFoundError(APIError):
    """404 Not Found - Resource not found.

    If a model doesn't exist, trying another provider won't help.
    Do NOT attempt fallback.
    """

    pass


class UnprocessableEntityError(APIError):
    """422 Unprocessable Entity - Validation error.

    Request validation errors are consistent across providers.
    Do NOT attempt fallback.
    """

    pass


class ChatNotSupportedError(APIError):
    """Model does not support chat completions.

    The model was called with /v1/chat/completions but it doesn't have a chat
    template configured. Use /v1/completions instead or choose a chat-capable model.
    Do NOT attempt fallback.
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_body: Optional[Dict[str, Any]] = None,
        model: Optional[str] = None,
    ) -> None:
        super().__init__(message, status_code, response_body)
        self.model = model

    def __str__(self) -> str:
        if self.model:
            return f"Model '{self.model}' does not support chat completions. Use completions.create() instead."
        return self.message


# =============================================================================
# FALLBACK-ABLE ERRORS (Server/Infrastructure Errors)
# These errors indicate temporary infrastructure issues that might be resolved
# by trying a different model/provider. Fallback CAN be attempted.
# =============================================================================


class RateLimitError(APIError):
    """429 Too Many Requests - Rate limit exceeded.

    Another provider might have available capacity.
    Fallback CAN be attempted.
    """

    def __init__(
        self,
        message: str,
        status_code: int = 429,
        response_body: Optional[Dict[str, Any]] = None,
        retry_after: Optional[float] = None,
    ) -> None:
        super().__init__(message, status_code, response_body)
        self.retry_after = retry_after


class ServerError(APIError):
    """5xx Server Error - Internal server error.

    Server issues on one provider don't affect others.
    Fallback CAN be attempted.
    """

    pass


class ServiceUnavailableError(ServerError):
    """503 Service Unavailable - Service temporarily unavailable.

    Fallback CAN be attempted.
    """

    pass


class GatewayTimeoutError(ServerError):
    """504 Gateway Timeout - Request timed out.

    Fallback CAN be attempted.
    """

    pass


class ConnectionError(LunarError):
    """Network connection error.

    Fallback CAN be attempted.
    """

    pass


class TimeoutError(LunarError):
    """Request timeout error.

    Fallback CAN be attempted.
    """

    pass


# =============================================================================
# Evaluation Errors
# =============================================================================


class EvaluationError(LunarError):
    """Error during evaluation execution.

    Raised when an evaluation fails completely (all tasks failed).
    """

    def __init__(
        self,
        message: str,
        failed_count: int = 0,
        total_count: int = 0,
        last_error: str = None,
    ) -> None:
        self.failed_count = failed_count
        self.total_count = total_count
        self.last_error = last_error
        super().__init__(message)

    def __str__(self) -> str:
        msg = self.message
        if self.last_error:
            msg += f"\n\nLast error: {self.last_error}"
        return msg


# =============================================================================
# Error Classification Tuples
# =============================================================================

# Errors that should trigger fallback to next model
FALLBACK_ERRORS = (
    RateLimitError,
    ServerError,
    ServiceUnavailableError,
    GatewayTimeoutError,
    ConnectionError,
    TimeoutError,
)

# Errors that should NOT trigger fallback (re-raise immediately)
NON_FALLBACK_ERRORS = (
    BadRequestError,
    AuthenticationError,
    PermissionDeniedError,
    NotFoundError,
    UnprocessableEntityError,
    ChatNotSupportedError,
)


def raise_for_status(status_code: int, response_body: Optional[Dict[str, Any]] = None) -> None:
    """Raise appropriate exception based on HTTP status code.

    Args:
        status_code: HTTP status code
        response_body: Optional response body from the API

    Raises:
        Appropriate APIError subclass based on status code
    """
    if status_code < 400:
        return

    message = "API request failed"
    if response_body:
        if "error" in response_body:
            error = response_body["error"]
            if isinstance(error, dict):
                message = error.get("message", str(error))
            else:
                message = str(error)
        elif "detail" in response_body:
            message = str(response_body["detail"])
        elif "message" in response_body:
            message = str(response_body["message"])

    if status_code == 400:
        # Check if this is a "chat not supported" error
        message_lower = message.lower()
        if "does not support chat" in message_lower or "chat template" in message_lower:
            model = None
            if response_body and "error_details" in response_body:
                model = response_body["error_details"].get("model")
            raise ChatNotSupportedError(message, status_code, response_body, model)
        raise BadRequestError(message, status_code, response_body)
    elif status_code == 401:
        raise AuthenticationError(message, status_code, response_body)
    elif status_code == 403:
        raise PermissionDeniedError(message, status_code, response_body)
    elif status_code == 404:
        raise NotFoundError(message, status_code, response_body)
    elif status_code == 422:
        raise UnprocessableEntityError(message, status_code, response_body)
    elif status_code == 429:
        retry_after = None
        if response_body and "retry_after" in response_body:
            retry_after = float(response_body["retry_after"])
        raise RateLimitError(message, status_code, response_body, retry_after)
    elif status_code == 503:
        raise ServiceUnavailableError(message, status_code, response_body)
    elif status_code == 504:
        raise GatewayTimeoutError(message, status_code, response_body)
    elif status_code >= 500:
        raise ServerError(message, status_code, response_body)
    else:
        raise APIError(message, status_code, response_body)
