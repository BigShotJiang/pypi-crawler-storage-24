"""Type definitions for the Evaluations module."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union

from pydantic import BaseModel, Field


class DataPoint(BaseModel):
    """Single evaluation data point."""

    input: Union[str, Dict[str, Any]] = Field(
        ..., description="Input for the task"
    )
    expected: Optional[str] = Field(
        None, description="Expected output for comparison", alias="expected_output"
    )
    metadata: Optional[Dict[str, Any]] = Field(
        None, description="Additional metadata"
    )

    class Config:
        populate_by_name = True
        extra = "allow"


class ScorerResult(BaseModel):
    """Result from a single scorer execution."""

    name: str = Field(..., description="Name of the scorer")
    score: float = Field(
        ..., description="Normalized score (0.0 - 1.0)", ge=0.0, le=1.0
    )
    raw_value: Optional[Any] = Field(
        None, description="Original value before normalization"
    )
    explanation: Optional[str] = Field(
        None, description="Explanation (for LLM-as-Judge)"
    )
    latency_ms: Optional[float] = Field(
        None, description="Execution time in milliseconds"
    )
    error: Optional[str] = Field(
        None, description="Error message if scorer failed"
    )


class EvaluationRow(BaseModel):
    """Single row in evaluation results."""

    datapoint_id: str = Field(..., description="Unique identifier for the datapoint")
    input: Union[str, Dict[str, Any]] = Field(..., description="Input value")
    output: Optional[str] = Field(None, description="Task output")
    expected: Optional[str] = Field(None, description="Expected output")
    scores: List[ScorerResult] = Field(
        default_factory=list, description="Results from all scorers"
    )
    error: Optional[str] = Field(
        None, description="Error message if task execution failed"
    )
    latency_ms: Optional[float] = Field(
        None, description="Task execution time in milliseconds"
    )
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")


class EvaluationProgress(BaseModel):
    """Progress of an evaluation."""

    total: int = Field(..., description="Total number of datapoints")
    completed: int = Field(0, description="Number of completed datapoints")
    failed: int = Field(0, description="Number of failed datapoints")

    @property
    def percentage(self) -> float:
        """Calculate completion percentage."""
        if self.total == 0:
            return 100.0
        return (self.completed / self.total) * 100.0

    @property
    def pending(self) -> int:
        """Number of pending datapoints."""
        return self.total - self.completed


class ScorerSummary(BaseModel):
    """Summary statistics for a single scorer."""

    name: str = Field(..., description="Scorer name")
    mean: float = Field(..., description="Mean score")
    median: float = Field(..., description="Median score")
    min: float = Field(..., description="Minimum score")
    max: float = Field(..., description="Maximum score")
    std_dev: float = Field(..., description="Standard deviation")
    count: int = Field(..., description="Number of successful evaluations")


class EvaluationSummary(BaseModel):
    """Summary statistics for an evaluation."""

    total_rows: int = Field(..., description="Total number of rows")
    successful_rows: int = Field(..., description="Rows with successful task execution")
    failed_rows: int = Field(..., description="Rows with failed task execution")
    scores: Dict[str, ScorerSummary] = Field(
        default_factory=dict, description="Summary per scorer"
    )

    @property
    def success_rate(self) -> float:
        """Calculate success rate."""
        if self.total_rows == 0:
            return 0.0
        return self.successful_rows / self.total_rows


class EvaluationStatus(str, Enum):
    """Status of an evaluation."""

    PENDING = "pending"
    QUEUED = "queued"
    STARTING = "starting"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class EvaluationResult(BaseModel):
    """Complete evaluation result."""

    id: str = Field(..., description="Unique evaluation ID (eval_xxx)")
    name: str = Field(..., description="Evaluation name")
    status: EvaluationStatus = Field(..., description="Current status")
    created_at: datetime = Field(..., description="Creation timestamp")
    started_at: Optional[datetime] = Field(None, description="Start timestamp")
    completed_at: Optional[datetime] = Field(None, description="Completion timestamp")
    progress: EvaluationProgress = Field(..., description="Progress information")
    summary: Optional[EvaluationSummary] = Field(
        None, description="Summary statistics (available when completed)"
    )
    rows: Optional[List[EvaluationRow]] = Field(
        None, description="Individual row results"
    )
    error: Optional[str] = Field(
        None, description="Error message if evaluation failed"
    )

    # Metadata
    dataset_id: Optional[str] = Field(None, description="Associated dataset ID")
    scorer_names: List[str] = Field(
        default_factory=list, description="Names of scorers used"
    )
    config: Dict[str, Any] = Field(
        default_factory=dict, description="Evaluation configuration"
    )


class Dataset(BaseModel):
    """Dataset for evaluations."""

    id: str = Field(..., description="Unique dataset ID", alias="dataset_id")
    name: str = Field(..., description="Dataset name")
    description: Optional[str] = Field(None, description="Dataset description")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp")
    datapoint_count: int = Field(0, description="Number of datapoints", alias="samples_count")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")

    class Config:
        populate_by_name = True
        extra = "allow"


class DatasetWithDatapoints(Dataset):
    """Dataset with its datapoints included."""

    datapoints: List[DataPoint] = Field(
        default_factory=list, description="Dataset datapoints", alias="samples"
    )


# ---------------------------------------------------------------------------
# Evaluation status response (lightweight status check)
# ---------------------------------------------------------------------------


class EvaluationStatusResponse(BaseModel):
    """Lightweight evaluation status check."""

    id: str
    status: EvaluationStatus
    progress: Optional[EvaluationProgress] = None

    class Config:
        extra = "allow"


# ---------------------------------------------------------------------------
# Experiments
# ---------------------------------------------------------------------------


class Experiment(BaseModel):
    """An experiment comparing multiple evaluation runs."""

    id: str = Field(..., alias="experiment_id")
    name: str
    description: Optional[str] = None
    dataset_id: Optional[str] = None
    evaluation_ids: List[str] = Field(default_factory=list)
    status: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None

    class Config:
        populate_by_name = True
        extra = "allow"


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------


class MetricType(str, Enum):
    """Type of metric."""

    BUILTIN = "builtin"
    CUSTOM = "custom"
    LLM_JUDGE = "llm_judge"
    EXACT_MATCH = "exact_match"
    CONTAINS = "contains"
    SEMANTIC_SIM = "semantic_sim"
    LATENCY = "latency"
    COST = "cost"
    PYTHON = "python"


class Metric(BaseModel):
    """A metric definition."""

    id: str = Field(..., alias="metric_id")
    name: str
    type: str  # Free-form to accept all backend types
    description: Optional[str] = None
    python_script: Optional[str] = Field(None, alias="script")
    config: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True
        extra = "allow"


class ScriptValidationResult(BaseModel):
    """Result of validating a custom metric script."""

    valid: bool
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)

    class Config:
        extra = "allow"


# ---------------------------------------------------------------------------
# Traces
# ---------------------------------------------------------------------------


class Trace(BaseModel):
    """A recorded LLM interaction trace."""

    id: str
    input: Union[str, Dict[str, Any]]
    output: Optional[str] = None
    model_id: Optional[str] = None
    source: Optional[str] = None
    latency_ms: Optional[float] = None
    token_count: Optional[Dict[str, int]] = None
    metadata: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None

    class Config:
        extra = "allow"


# ---------------------------------------------------------------------------
# Trace Issues
# ---------------------------------------------------------------------------


class TraceIssue(BaseModel):
    """An issue detected in a trace."""

    id: str
    trace_id: Optional[str] = None
    type: Optional[str] = None
    severity: Optional[str] = None
    description: Optional[str] = None
    resolved: bool = False
    resolved_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

    class Config:
        extra = "allow"


class ScanResult(BaseModel):
    """Result of a trace issues scan."""

    scan_id: str
    status: Optional[str] = None
    issues_found: int = 0
    issues: List[TraceIssue] = Field(default_factory=list)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    class Config:
        extra = "allow"


# ---------------------------------------------------------------------------
# Auto-Eval
# ---------------------------------------------------------------------------


class AutoEvalConfig(BaseModel):
    """Configuration for automatic evaluations."""

    id: str
    name: str
    dataset_id: Optional[str] = None
    models: List[str] = Field(default_factory=list)
    metrics: List[str] = Field(default_factory=list)
    schedule: Optional[str] = None
    enabled: bool = True
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        extra = "allow"


class AutoEvalRun(BaseModel):
    """A run triggered by an auto-eval configuration."""

    id: str
    config_id: str
    evaluation_id: Optional[str] = None
    status: Optional[str] = None
    triggered_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    class Config:
        extra = "allow"


# ---------------------------------------------------------------------------
# Annotations
# ---------------------------------------------------------------------------


class AnnotationQueue(BaseModel):
    """A queue for human annotation of evaluation samples."""

    id: str
    name: str
    dataset_id: Optional[str] = None
    rubric: Optional[Dict[str, Any]] = None
    status: Optional[str] = None
    total_items: int = 0
    completed_items: int = 0
    created_at: Optional[datetime] = None

    class Config:
        extra = "allow"


class AnnotationItem(BaseModel):
    """An item in an annotation queue."""

    id: str
    queue_id: Optional[str] = None
    sample: Optional[Dict[str, Any]] = None
    status: Optional[str] = None
    scores: Optional[Dict[str, Any]] = None
    notes: Optional[str] = None
    annotator: Optional[str] = None
    annotated_at: Optional[datetime] = None

    class Config:
        extra = "allow"


class AnnotationAnalytics(BaseModel):
    """Analytics for an annotation queue."""

    queue_id: str
    total_items: int = 0
    completed_items: int = 0
    skipped_items: int = 0
    average_scores: Optional[Dict[str, float]] = None
    annotator_stats: Optional[Dict[str, Any]] = None

    class Config:
        extra = "allow"


# ---------------------------------------------------------------------------
# Proposals
# ---------------------------------------------------------------------------


class ProposalStatus(str, Enum):
    """Status of a proposal."""

    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class Proposal(BaseModel):
    """A proposal for dataset or evaluation changes."""

    id: str
    type: Optional[str] = None
    description: Optional[str] = None
    status: ProposalStatus = ProposalStatus.PENDING
    details: Optional[Dict[str, Any]] = None
    reason: Optional[str] = None
    created_at: Optional[datetime] = None
    resolved_at: Optional[datetime] = None

    class Config:
        extra = "allow"


# ---------------------------------------------------------------------------
# Auto-Collect
# ---------------------------------------------------------------------------


class AutoCollectConfig(BaseModel):
    """Configuration for automatic trace collection into a dataset."""

    dataset_id: str
    enabled: bool = False
    filters: Optional[Dict[str, Any]] = None
    sample_rate: Optional[float] = None
    max_samples: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        extra = "allow"


# ---------------------------------------------------------------------------
# Type aliases for task functions
# ---------------------------------------------------------------------------

TaskFunction = Callable[[Union[str, Dict[str, Any]]], str]
AsyncTaskFunction = Callable[[Union[str, Dict[str, Any]]], "Awaitable[str]"]

# Type for scorer functions
ScorerFunction = Callable[[str, Optional[str]], float]
