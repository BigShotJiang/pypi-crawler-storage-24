"""Evaluation runner for executing evaluations."""

from __future__ import annotations

import asyncio
import logging
import statistics
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import (
    Any,
    Awaitable,
    Callable,
    Dict,
    List,
    Optional,
    Union,
)

from .._exceptions import EvaluationError
from ._base import (
    AsyncBaseScorer,
    BaseScorer,
    ensure_scorer,
    is_async_scorer,
)
from .scorers.llm_judge import LLMJudgeScorer
from .types import (
    DataPoint,
    EvaluationProgress,
    EvaluationResult,
    EvaluationRow,
    EvaluationStatus,
    EvaluationSummary,
    ScorerResult,
    ScorerSummary,
)
from ._display import create_display

logger = logging.getLogger(__name__)

# Type aliases
TaskFunction = Callable[[Union[str, Dict[str, Any]]], str]
AsyncTaskFunction = Callable[[Union[str, Dict[str, Any]]], Awaitable[str]]
ProgressCallback = Callable[[EvaluationProgress], None]


class EvaluationRunner:
    """Runner for executing evaluations locally.

    This runner executes tasks and scorers locally, optionally logging
    results to the Lunar API. Supports both API Key and JWT authentication
    transparently through the provided client.
    """

    def __init__(
        self,
        client: Any,
        max_concurrent: int = 10,
    ):
        """Initialize runner.

        Args:
            client: Lunar client instance (sync or async) with authentication
                   configured (API Key or JWT)
            max_concurrent: Maximum concurrent task executions
        """
        self._client = client
        self._max_concurrent = max_concurrent
        self._is_async = hasattr(client, "__aenter__")

    def run(
        self,
        name: str,
        dataset: Union[List[Dict[str, Any]], List[DataPoint]],
        task: TaskFunction,
        scorers: List[Union[BaseScorer, Callable[..., float]]],
        on_progress: Optional[ProgressCallback] = None,
        log_to_api: bool = True,
        models: Optional[List[str]] = None,
        show_progress: bool = True,
    ) -> EvaluationResult:
        """Run evaluation synchronously.

        Args:
            name: Evaluation name
            dataset: List of datapoints
            task: Function to execute for each datapoint
            scorers: List of scorers to apply
            on_progress: Optional progress callback
            log_to_api: Whether to log results to API
            models: Optional list of model names being tested (for display in UI)
            show_progress: Whether to display progress bar (default: True)

        Returns:
            EvaluationResult with all scores
        """
        # Convert to async and run
        async def _run():
            return await self.arun(
                name=name,
                dataset=dataset,
                task=task,
                scorers=scorers,
                on_progress=on_progress,
                log_to_api=log_to_api,
                models=models,
                show_progress=show_progress,
            )

        return asyncio.get_event_loop().run_until_complete(_run())

    async def arun(
        self,
        name: str,
        dataset: Union[List[Dict[str, Any]], List[DataPoint]],
        task: Union[TaskFunction, AsyncTaskFunction],
        scorers: List[Union[BaseScorer, Callable[..., float]]],
        on_progress: Optional[ProgressCallback] = None,
        log_to_api: bool = True,
        models: Optional[List[str]] = None,
        show_progress: bool = True,
    ) -> EvaluationResult:
        """Run evaluation asynchronously.

        Args:
            name: Evaluation name
            dataset: List of datapoints
            task: Function to execute for each datapoint (sync or async)
            scorers: List of scorers to apply
            on_progress: Optional progress callback
            log_to_api: Whether to log results to API
            models: Optional list of model names being tested (for display in UI)
            show_progress: Whether to display progress bar (default: True)

        Returns:
            EvaluationResult with all scores
        """
        self._models = models or []
        # Generate evaluation ID
        eval_id = f"eval_{uuid.uuid4().hex[:12]}"
        started_at = datetime.utcnow()

        # Normalize dataset
        datapoints = self._normalize_dataset(dataset)

        # Normalize scorers
        normalized_scorers = [ensure_scorer(s) for s in scorers]

        # Set client on LLM judges
        for scorer in normalized_scorers:
            if isinstance(scorer, LLMJudgeScorer):
                scorer.set_client(self._client)

        # Initialize display
        display = create_display(show_progress=show_progress)
        display.start(name, len(datapoints), [s.name for s in normalized_scorers])

        # Initialize progress
        progress = EvaluationProgress(
            total=len(datapoints),
            completed=0,
            failed=0,
        )

        # Create initial result
        result = EvaluationResult(
            id=eval_id,
            name=name,
            status=EvaluationStatus.RUNNING,
            created_at=started_at,
            started_at=started_at,
            progress=progress,
            scorer_names=[s.name for s in normalized_scorers],
            config={
                "max_concurrent": self._max_concurrent,
                "log_to_api": log_to_api,
            },
        )

        # Execute evaluations
        rows: List[EvaluationRow] = []
        semaphore = asyncio.Semaphore(self._max_concurrent)

        async def process_datapoint(idx: int, dp: DataPoint) -> EvaluationRow:
            async with semaphore:
                return await self._process_single(
                    datapoint_id=f"{eval_id}_row_{idx}",
                    datapoint=dp,
                    task=task,
                    scorers=normalized_scorers,
                )

        # Process all datapoints concurrently
        tasks = [
            process_datapoint(idx, dp) for idx, dp in enumerate(datapoints)
        ]

        for coro in asyncio.as_completed(tasks):
            try:
                row = await coro
                rows.append(row)

                # Update progress
                progress.completed += 1
                if row.error:
                    progress.failed += 1

                # Update display
                display.update(progress.completed, progress.failed)

                if on_progress:
                    on_progress(progress)

            except Exception as e:
                logger.error(f"Error processing datapoint: {e}")
                progress.completed += 1
                progress.failed += 1
                display.update(progress.completed, progress.failed)

        # Check if all tasks failed
        failed_rows = [r for r in rows if r.error is not None]
        if len(failed_rows) == len(rows) and len(rows) > 0:
            # All tasks failed - this is likely a configuration issue
            # Get the most common error message
            error_messages = [r.error for r in failed_rows if r.error]
            last_error = error_messages[-1] if error_messages else "Unknown error"

            display.error(f"All {len(rows)} tasks failed: {last_error}")

            raise EvaluationError(
                message=f"Evaluation failed: all {len(rows)} tasks failed. "
                f"This usually indicates a configuration issue (e.g., missing API keys, invalid model, etc.).",
                failed_count=len(failed_rows),
                total_count=len(rows),
                last_error=last_error,
            )

        # Calculate summary
        summary = self._calculate_summary(rows, normalized_scorers)

        # Finalize result
        completed_at = datetime.utcnow()
        result = EvaluationResult(
            id=eval_id,
            name=name,
            status=EvaluationStatus.COMPLETED,
            created_at=started_at,
            started_at=started_at,
            completed_at=completed_at,
            progress=progress,
            summary=summary,
            rows=rows,
            scorer_names=[s.name for s in normalized_scorers],
            config={
                "max_concurrent": self._max_concurrent,
                "log_to_api": log_to_api,
            },
        )

        # Show final results
        display.finish(result)

        # Log to API if enabled
        if log_to_api:
            await self._log_to_api(result)

        return result

    def _normalize_dataset(
        self,
        dataset: Union[List[Dict[str, Any]], List[DataPoint]],
    ) -> List[DataPoint]:
        """Normalize dataset to list of DataPoint."""
        normalized = []
        for item in dataset:
            if isinstance(item, DataPoint):
                normalized.append(item)
            elif isinstance(item, dict):
                normalized.append(DataPoint(**item))
            else:
                raise ValueError(f"Invalid datapoint type: {type(item)}")
        return normalized

    async def _process_single(
        self,
        datapoint_id: str,
        datapoint: DataPoint,
        task: Union[TaskFunction, AsyncTaskFunction],
        scorers: List[BaseScorer],
    ) -> EvaluationRow:
        """Process a single datapoint.

        Args:
            datapoint_id: Unique ID for this row
            datapoint: The datapoint to process
            task: Task function to execute
            scorers: List of scorers

        Returns:
            EvaluationRow with results
        """
        output = None
        error = None
        task_latency_ms = None
        scores: List[ScorerResult] = []

        # Execute task
        start_time = time.perf_counter()
        try:
            if asyncio.iscoroutinefunction(task):
                output = await task(datapoint.input)
            else:
                # Run sync task in thread pool
                loop = asyncio.get_event_loop()
                with ThreadPoolExecutor() as executor:
                    output = await loop.run_in_executor(
                        executor, task, datapoint.input
                    )
            task_latency_ms = (time.perf_counter() - start_time) * 1000

        except Exception as e:
            error = str(e)
            task_latency_ms = (time.perf_counter() - start_time) * 1000
            logger.warning(f"Task failed for datapoint {datapoint_id}: {e}")

        # Run scorers if task succeeded
        if output is not None:
            scores = await self._run_scorers(
                scorers=scorers,
                output=output,
                expected=datapoint.expected,
                input=datapoint.input,
            )

        return EvaluationRow(
            datapoint_id=datapoint_id,
            input=datapoint.input,
            output=output,
            expected=datapoint.expected,
            scores=scores,
            error=error,
            latency_ms=task_latency_ms,
            metadata=datapoint.metadata,
        )

    async def _run_scorers(
        self,
        scorers: List[BaseScorer],
        output: str,
        expected: Optional[str],
        input: Optional[Union[str, Dict[str, Any]]],
    ) -> List[ScorerResult]:
        """Run all scorers on output.

        Args:
            scorers: List of scorers
            output: Task output
            expected: Expected output
            input: Original input

        Returns:
            List of scorer results
        """
        results = []

        for scorer in scorers:
            try:
                if is_async_scorer(scorer):
                    result = await scorer(output, expected, input)
                else:
                    # Run sync scorer
                    result = scorer(output, expected, input)

                results.append(result)

            except Exception as e:
                logger.warning(f"Scorer {scorer.name} failed: {e}")
                results.append(
                    ScorerResult(
                        name=scorer.name,
                        score=0.0,
                        error=str(e),
                    )
                )

        return results

    def _calculate_summary(
        self,
        rows: List[EvaluationRow],
        scorers: List[BaseScorer],
    ) -> EvaluationSummary:
        """Calculate summary statistics.

        Args:
            rows: List of evaluation rows
            scorers: List of scorers used

        Returns:
            EvaluationSummary with statistics
        """
        successful_rows = [r for r in rows if r.error is None]
        failed_rows = [r for r in rows if r.error is not None]

        # Calculate per-scorer statistics
        scorer_summaries: Dict[str, ScorerSummary] = {}

        for scorer in scorers:
            scores = []
            for row in successful_rows:
                for score_result in row.scores:
                    if score_result.name == scorer.name and score_result.error is None:
                        scores.append(score_result.score)

            if scores:
                scorer_summaries[scorer.name] = ScorerSummary(
                    name=scorer.name,
                    mean=statistics.mean(scores),
                    median=statistics.median(scores),
                    min=min(scores),
                    max=max(scores),
                    std_dev=statistics.stdev(scores) if len(scores) > 1 else 0.0,
                    count=len(scores),
                )
            else:
                scorer_summaries[scorer.name] = ScorerSummary(
                    name=scorer.name,
                    mean=0.0,
                    median=0.0,
                    min=0.0,
                    max=0.0,
                    std_dev=0.0,
                    count=0,
                )

        return EvaluationSummary(
            total_rows=len(rows),
            successful_rows=len(successful_rows),
            failed_rows=len(failed_rows),
            scores=scorer_summaries,
        )

    async def _log_to_api(self, result: EvaluationResult) -> None:
        """Log evaluation results to API in frontend-compatible format.

        Transforms the internal evaluation result structure to match the
        format expected by the Lunar frontend.

        Args:
            result: Evaluation result to log
        """
        import httpx

        try:
            # Get config from client
            config = getattr(self._client, "_config", None)
            if config is None:
                logger.debug("No config found on client, skipping API log")
                return

            # Determine model_id (use first model or default)
            model_id = self._models[0] if self._models else "sdk_model"

            # Transform rows to samples in frontend format
            samples = []
            total_latency = 0.0

            for row in (result.rows or []):
                latency_ms = row.latency_ms or 0
                latency_seconds = latency_ms / 1000.0  # Convert to seconds for frontend
                total_latency += latency_seconds

                # Transform scores array to nested dict: {metric: {model: score_data}}
                scores_dict: Dict[str, Dict[str, Any]] = {}
                for score in row.scores:
                    scores_dict[score.name] = {
                        model_id: {
                            "score": score.score,
                            "raw_value": score.raw_value,
                            "explanation": score.explanation,
                            "error": score.error,
                        }
                    }

                samples.append({
                    "sample_id": row.datapoint_id,
                    "input": row.input,
                    "expected": row.expected,
                    "outputs": {
                        model_id: {
                            "output": row.output,
                            "latency": latency_seconds,  # Send in seconds
                            "error": row.error,
                        }
                    },
                    "scores": scores_dict,
                })

            # Build summary in frontend format
            num_rows = len(result.rows) if result.rows else 0
            avg_latency = total_latency / num_rows if num_rows > 0 else 0

            # Extract avg_scores from original summary
            avg_scores: Dict[str, float] = {}
            metrics_summary: Dict[str, Dict[str, Any]] = {}

            if result.summary and result.summary.scores:
                for metric_name, stats in result.summary.scores.items():
                    avg_scores[metric_name] = stats.mean
                    metrics_summary[metric_name] = {
                        "avg_by_model": {
                            model_id: stats.mean
                        }
                    }

            transformed_summary = {
                "models": {
                    model_id: {
                        "total_latency": total_latency,
                        "avg_latency": avg_latency,
                        "total_cost": 0,
                        "avg_cost": 0,
                        "avg_scores": avg_scores,
                    }
                },
                "metrics": metrics_summary,
            }

            # Prepare payload in frontend-compatible format
            payload = {
                "id": result.id,
                "name": result.name,
                "status": result.status.value,
                "created_at": result.created_at.isoformat(),
                "completed_at": result.completed_at.isoformat() if result.completed_at else None,
                "models": self._models,
                "metrics": result.scorer_names,  # Frontend expects "metrics" not "scorer_names"
                "config": result.config,
                "progress": {
                    "total": result.progress.total,
                    "completed": result.progress.completed,
                    "failed": result.progress.failed,
                },
                "results": {  # Wrap in "results" as frontend expects
                    "summary": transformed_summary,
                    "samples": samples,
                },
            }

            # Use the evals API URL from config
            evals_api_url = getattr(config, "evals_api_url", None)
            if not evals_api_url:
                logger.debug("No evals_api_url configured, skipping API log")
                return

            # Make direct request to evaluations API
            try:
                async with httpx.AsyncClient(
                    base_url=evals_api_url,
                    headers=config.headers,
                    timeout=httpx.Timeout(config.timeout),
                ) as client:
                    response = await client.post("/v1/evaluations/log", json=payload)
                    response.raise_for_status()
                    logger.info(f"Evaluation logged to API: {result.id}")
            except Exception as api_error:
                logger.warning(f"Could not log to API: {api_error}")

            logger.info(
                f"Evaluation '{result.name}' completed: "
                f"{result.summary.successful_rows}/{result.summary.total_rows} successful"
            )

        except Exception as e:
            # Don't fail the evaluation if logging fails
            logger.warning(f"Failed to log evaluation to API: {e}")
