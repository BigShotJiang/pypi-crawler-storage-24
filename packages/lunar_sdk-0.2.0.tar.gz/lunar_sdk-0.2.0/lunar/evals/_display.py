"""Display utilities for evaluation progress and results."""

from __future__ import annotations

import sys
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .types import EvaluationResult, EvaluationProgress


def _is_notebook() -> bool:
    """Check if running in a Jupyter notebook."""
    try:
        from IPython import get_ipython
        shell = get_ipython()
        if shell is None:
            return False
        shell_name = shell.__class__.__name__
        if shell_name == 'ZMQInteractiveShell':
            return True  # Jupyter notebook or qtconsole
        elif shell_name == 'TerminalInteractiveShell':
            return False  # Terminal IPython
        else:
            return False
    except (ImportError, NameError):
        return False


# Try to import rich for beautiful output
try:
    from rich.console import Console
    from rich.progress import (
        Progress,
        SpinnerColumn,
        TextColumn,
        BarColumn,
        TaskProgressColumn,
        TimeElapsedColumn,
        TimeRemainingColumn,
    )
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.live import Live
    from rich.layout import Layout
    from rich import box
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False


class EvaluationDisplay:
    """Handles display of evaluation progress and results."""

    def __init__(self, show_progress: bool = True):
        self.show_progress = show_progress
        self._is_notebook = _is_notebook()
        # Force terminal mode for Jupyter to get proper output
        self._console = Console(force_terminal=True) if RICH_AVAILABLE else None
        self._progress = None
        self._task_id = None
        self._live = None
        self._total = 0

    def start(self, name: str, total: int, scorers: List[str]) -> None:
        """Start displaying progress."""
        if not self.show_progress:
            return

        self._total = total

        if self._is_notebook:
            self._start_notebook(name, total, scorers)
        elif RICH_AVAILABLE:
            self._start_rich(name, total, scorers)
        else:
            self._start_simple(name, total, scorers)

    def _start_notebook(self, name: str, total: int, scorers: List[str]) -> None:
        """Start progress display for Jupyter notebooks using ipywidgets or tqdm."""
        from IPython.display import display, HTML

        # Print header
        display(HTML(f"""
        <div style="padding: 10px; border: 2px solid #00bcd4; border-radius: 8px; margin: 10px 0; background: #f5f5f5;">
            <span style="font-size: 1.2em;">🔬 <strong style="color: #00838f;">{name}</strong></span>
            <span style="color: #666; margin-left: 10px;">{total} samples • {len(scorers)} scorers</span>
        </div>
        """))

        # Try to use tqdm for progress bar (works great in notebooks)
        try:
            from tqdm.notebook import tqdm
            self._tqdm_bar = tqdm(total=total, desc="Running evaluation",
                                  bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]')
            self._use_tqdm = True
        except ImportError:
            # Fallback: use simple text progress
            self._use_tqdm = False
            print(f"  Running evaluation: 0/{total}")

    def _start_rich(self, name: str, total: int, scorers: List[str]) -> None:
        """Start rich progress display."""
        # Create header
        header = Text()
        header.append("🔬 ", style="bold")
        header.append(name, style="bold cyan")
        header.append(f"  •  {total} samples  •  ", style="dim")
        header.append(f"{len(scorers)} scorers", style="dim")

        self._console.print()
        self._console.print(Panel(header, box=box.ROUNDED, border_style="cyan"))
        self._console.print()

        # Create progress bar
        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(bar_width=40, complete_style="cyan", finished_style="green"),
            TaskProgressColumn(),
            TextColumn("•"),
            TimeElapsedColumn(),
            TextColumn("•"),
            TimeRemainingColumn(),
            console=self._console,
            transient=False,
        )
        self._progress.start()
        self._task_id = self._progress.add_task("Running evaluation...", total=total)

    def _start_simple(self, name: str, total: int, scorers: List[str]) -> None:
        """Start simple text-based progress."""
        print(f"\n{'='*60}")
        print(f"🔬 {name}")
        print(f"   {total} samples • {len(scorers)} scorers")
        print(f"{'='*60}")
        print()

    def update(self, completed: int, failed: int) -> None:
        """Update progress display."""
        if not self.show_progress:
            return

        if self._is_notebook:
            self._update_notebook(completed, failed)
        elif RICH_AVAILABLE and self._progress and self._task_id is not None:
            self._progress.update(self._task_id, completed=completed)
            if failed > 0:
                self._progress.update(
                    self._task_id,
                    description=f"Running evaluation... [red]({failed} failed)[/red]"
                )
        else:
            # Simple progress
            sys.stdout.write(f"\r  Processing: {completed} completed, {failed} failed")
            sys.stdout.flush()

    def _update_notebook(self, completed: int, failed: int) -> None:
        """Update notebook progress bar."""
        if hasattr(self, '_use_tqdm') and self._use_tqdm and hasattr(self, '_tqdm_bar'):
            # Update tqdm bar
            self._tqdm_bar.n = completed
            if failed > 0:
                self._tqdm_bar.set_description(f"Running evaluation ({failed} failed)")
            self._tqdm_bar.refresh()
        else:
            # Simple fallback
            from IPython.display import clear_output, display
            clear_output(wait=True)
            pct = completed / self._total * 100
            bar_len = int(pct / 2)
            bar = "█" * bar_len + "░" * (50 - bar_len)
            failed_str = f" ({failed} failed)" if failed > 0 else ""
            print(f"  [{bar}] {completed}/{self._total} ({pct:.0f}%){failed_str}")

    def finish(self, result: "EvaluationResult") -> None:
        """Finish and display results."""
        # Close tqdm bar if using it
        if hasattr(self, '_tqdm_bar') and self._tqdm_bar:
            self._tqdm_bar.close()

        if RICH_AVAILABLE and self._progress:
            self._progress.stop()

        if not self.show_progress:
            return

        if self._is_notebook:
            self._finish_notebook(result)
        elif RICH_AVAILABLE:
            self._finish_rich(result)
        else:
            self._finish_simple(result)

    def _finish_notebook(self, result: "EvaluationResult") -> None:
        """Display results in Jupyter notebook with HTML."""
        from IPython.display import display, HTML

        # Status color
        if result.status.value == "completed":
            status_color = "#4caf50"
            status_icon = "✓"
        else:
            status_color = "#f44336"
            status_icon = "✗"

        # Build scores HTML
        scores_html = ""
        if result.summary and result.summary.scores:
            for name, stats in result.summary.scores.items():
                score_pct = stats.mean * 100
                if score_pct >= 80:
                    bar_color = "#4caf50"  # green
                elif score_pct >= 50:
                    bar_color = "#ff9800"  # orange
                else:
                    bar_color = "#f44336"  # red

                scores_html += f"""
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>{name}</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee; width: 200px;">
                        <div style="background: #eee; border-radius: 4px; overflow: hidden;">
                            <div style="width: {score_pct}%; background: {bar_color}; height: 20px; border-radius: 4px;"></div>
                        </div>
                    </td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold; color: {bar_color};">{score_pct:.1f}%</td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee; color: #666;">{stats.min*100:.1f}%</td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee; color: #666;">{stats.max*100:.1f}%</td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee; color: #666;">{stats.count}</td>
                </tr>
                """

        # Summary info
        summary_info = ""
        if result.summary:
            summary_info = f"{result.summary.successful_rows}/{result.summary.total_rows} successful"
            if result.summary.failed_rows > 0:
                summary_info += f" <span style='color: #f44336;'>({result.summary.failed_rows} failed)</span>"

        display(HTML(f"""
        <div style="margin: 20px 0;">
            <h3 style="margin-bottom: 10px;">📊 Results</h3>
            <table style="width: 100%; border-collapse: collapse; font-family: monospace;">
                <thead>
                    <tr style="background: #f5f5f5;">
                        <th style="padding: 8px; text-align: left;">Metric</th>
                        <th style="padding: 8px; text-align: left;">Score</th>
                        <th style="padding: 8px; text-align: left;">Value</th>
                        <th style="padding: 8px; text-align: left;">Min</th>
                        <th style="padding: 8px; text-align: left;">Max</th>
                        <th style="padding: 8px; text-align: left;">Samples</th>
                    </tr>
                </thead>
                <tbody>
                    {scores_html}
                </tbody>
            </table>

            <div style="margin-top: 15px; padding: 10px; background: #f5f5f5; border-radius: 8px; border-left: 4px solid {status_color};">
                <span style="font-weight: bold; color: {status_color};">{status_icon} {result.status.value.title()}</span>
                <span style="margin-left: 15px;">ID: <code>{result.id}</code></span>
                <span style="margin-left: 15px;">Samples: {summary_info}</span>
            </div>
        </div>
        """))

    def _finish_rich(self, result: "EvaluationResult") -> None:
        """Display rich results."""
        console = self._console
        console.print()

        # Status
        if result.status.value == "completed":
            status_text = Text("✓ Completed", style="bold green")
        else:
            status_text = Text(f"✗ {result.status.value}", style="bold red")

        # Results table
        table = Table(
            title="📊 Results",
            box=box.ROUNDED,
            border_style="dim",
            header_style="bold",
            show_header=True,
        )
        table.add_column("Metric", style="cyan", no_wrap=True)
        table.add_column("Score", justify="right", style="bold")
        table.add_column("Min", justify="right", style="dim")
        table.add_column("Max", justify="right", style="dim")
        table.add_column("Samples", justify="right", style="dim")

        if result.summary and result.summary.scores:
            for name, stats in result.summary.scores.items():
                # Color code the score
                score_pct = stats.mean * 100
                if score_pct >= 80:
                    score_style = "green"
                elif score_pct >= 50:
                    score_style = "yellow"
                else:
                    score_style = "red"

                table.add_row(
                    name,
                    Text(f"{score_pct:.1f}%", style=score_style),
                    f"{stats.min*100:.1f}%",
                    f"{stats.max*100:.1f}%",
                    str(stats.count),
                )

        console.print(table)
        console.print()

        # Summary panel
        summary_parts = []
        summary_parts.append(f"[bold]ID:[/bold] {result.id}")
        if result.summary:
            summary_parts.append(
                f"[bold]Samples:[/bold] {result.summary.successful_rows}/{result.summary.total_rows} successful"
            )
            if result.summary.failed_rows > 0:
                summary_parts.append(f"[red]({result.summary.failed_rows} failed)[/red]")

        summary_text = "  •  ".join(summary_parts)
        console.print(Panel(
            f"{status_text}  •  {summary_text}",
            box=box.ROUNDED,
            border_style="green" if result.status.value == "completed" else "red",
        ))
        console.print()

    def _finish_simple(self, result: "EvaluationResult") -> None:
        """Display simple text results."""
        print("\n")
        print(f"{'='*60}")

        if result.status.value == "completed":
            print("✓ Completed")
        else:
            print(f"✗ {result.status.value}")

        print(f"\nID: {result.id}")

        if result.summary:
            print(f"Samples: {result.summary.successful_rows}/{result.summary.total_rows} successful")
            if result.summary.failed_rows > 0:
                print(f"         ({result.summary.failed_rows} failed)")

        print(f"\n{'─'*40}")
        print("Results:")
        print(f"{'─'*40}")

        if result.summary and result.summary.scores:
            for name, stats in result.summary.scores.items():
                score_pct = stats.mean * 100
                bar_len = int(score_pct / 5)  # 20 chars max
                bar = "█" * bar_len + "░" * (20 - bar_len)
                print(f"  {name:20} [{bar}] {score_pct:5.1f}%")

        print(f"{'='*60}\n")

    def error(self, message: str) -> None:
        """Display error message."""
        if RICH_AVAILABLE and self._console:
            self._console.print(f"[bold red]✗ Error:[/bold red] {message}")
        else:
            print(f"✗ Error: {message}")


def create_display(show_progress: bool = True) -> EvaluationDisplay:
    """Create a display instance."""
    return EvaluationDisplay(show_progress=show_progress)
