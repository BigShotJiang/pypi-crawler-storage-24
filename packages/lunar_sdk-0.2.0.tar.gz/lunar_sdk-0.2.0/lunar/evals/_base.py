"""Base classes and decorators for scorers."""

from __future__ import annotations

import asyncio
import functools
import inspect
import time
from abc import ABC, abstractmethod
from typing import (
    Any,
    Awaitable,
    Callable,
    Dict,
    List,
    Optional,
    Union,
    TypeVar,
    overload,
)

from .types import ScorerResult

F = TypeVar("F", bound=Callable[..., Any])


class BaseScorer(ABC):
    """Base class for all scorers."""

    def __init__(
        self,
        name: Optional[str] = None,
        requirements: Optional[List[str]] = None,
    ):
        """Initialize scorer.

        Args:
            name: Scorer name (defaults to class/function name)
            requirements: List of pip requirements for this scorer
        """
        self._name = name or self.__class__.__name__
        self._requirements = requirements or []

    @property
    def name(self) -> str:
        """Get scorer name."""
        return self._name

    @property
    def requirements(self) -> List[str]:
        """Get pip requirements for this scorer."""
        return self._requirements

    @abstractmethod
    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        """Calculate score for the given output.

        Args:
            output: The output from the task
            expected: The expected output (if available)
            input: The original input (if needed for context)
            **kwargs: Additional arguments

        Returns:
            Score value (typically 0.0 to 1.0)
        """
        pass

    def __call__(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> ScorerResult:
        """Execute scorer and return result with metadata.

        Args:
            output: The output from the task
            expected: The expected output (if available)
            input: The original input (if needed for context)
            **kwargs: Additional arguments

        Returns:
            ScorerResult with score and metadata
        """
        start_time = time.perf_counter()
        error = None
        score = 0.0
        raw_value = None

        try:
            raw_value = self.score(output, expected, input, **kwargs)
            # Normalize to 0-1 range if needed
            score = self._normalize_score(raw_value)
        except Exception as e:
            error = str(e)

        latency_ms = (time.perf_counter() - start_time) * 1000

        return ScorerResult(
            name=self.name,
            score=score,
            raw_value=raw_value,
            latency_ms=latency_ms,
            error=error,
        )

    def _normalize_score(self, value: Any) -> float:
        """Normalize score to 0-1 range.

        Override this method for custom normalization.
        """
        if isinstance(value, bool):
            return 1.0 if value else 0.0
        if isinstance(value, (int, float)):
            return max(0.0, min(1.0, float(value)))
        return 0.0


class AsyncBaseScorer(BaseScorer):
    """Base class for async scorers."""

    @abstractmethod
    async def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        """Async score calculation."""
        pass

    async def __call__(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> ScorerResult:
        """Execute async scorer and return result with metadata."""
        start_time = time.perf_counter()
        error = None
        score = 0.0
        raw_value = None

        try:
            raw_value = await self.score(output, expected, input, **kwargs)
            score = self._normalize_score(raw_value)
        except Exception as e:
            error = str(e)

        latency_ms = (time.perf_counter() - start_time) * 1000

        return ScorerResult(
            name=self.name,
            score=score,
            raw_value=raw_value,
            latency_ms=latency_ms,
            error=error,
        )


class FunctionScorer(BaseScorer):
    """Scorer that wraps a simple function."""

    def __init__(
        self,
        func: Callable[..., float],
        name: Optional[str] = None,
        requirements: Optional[List[str]] = None,
    ):
        """Initialize function scorer.

        Args:
            func: The scoring function
            name: Scorer name (defaults to function name)
            requirements: Pip requirements
        """
        super().__init__(name=name or func.__name__, requirements=requirements)
        self._func = func
        self._sig = inspect.signature(func)

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        """Call the wrapped function."""
        # Build arguments based on function signature
        params = self._sig.parameters
        call_kwargs = {}

        if "output" in params:
            call_kwargs["output"] = output
        if "expected" in params:
            call_kwargs["expected"] = expected
        if "input" in params:
            call_kwargs["input"] = input

        # Add any additional kwargs that the function accepts
        for key, value in kwargs.items():
            if key in params:
                call_kwargs[key] = value

        # Check if function accepts **kwargs
        has_var_keyword = any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()
        )
        if has_var_keyword:
            call_kwargs.update(kwargs)

        return self._func(**call_kwargs)


class AsyncFunctionScorer(AsyncBaseScorer):
    """Scorer that wraps an async function."""

    def __init__(
        self,
        func: Callable[..., Awaitable[float]],
        name: Optional[str] = None,
        requirements: Optional[List[str]] = None,
    ):
        """Initialize async function scorer."""
        super().__init__(name=name or func.__name__, requirements=requirements)
        self._func = func
        self._sig = inspect.signature(func)

    async def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        """Call the wrapped async function."""
        params = self._sig.parameters
        call_kwargs = {}

        if "output" in params:
            call_kwargs["output"] = output
        if "expected" in params:
            call_kwargs["expected"] = expected
        if "input" in params:
            call_kwargs["input"] = input

        for key, value in kwargs.items():
            if key in params:
                call_kwargs[key] = value

        has_var_keyword = any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()
        )
        if has_var_keyword:
            call_kwargs.update(kwargs)

        return await self._func(**call_kwargs)


@overload
def Scorer(func: F) -> F:
    """Decorator without arguments."""
    ...


@overload
def Scorer(
    *,
    name: Optional[str] = None,
    requirements: Optional[List[str]] = None,
) -> Callable[[F], F]:
    """Decorator with arguments."""
    ...


def Scorer(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
    requirements: Optional[List[str]] = None,
) -> Union[F, Callable[[F], F]]:
    """Decorator to create a scorer from a function.

    Can be used with or without arguments:

    Example without arguments:
        >>> @Scorer
        ... def my_scorer(output: str, expected: str) -> float:
        ...     return 1.0 if output == expected else 0.0

    Example with arguments:
        >>> @Scorer(name="custom_name", requirements=["numpy>=1.0"])
        ... def my_scorer(output: str, expected: str) -> float:
        ...     import numpy as np
        ...     return np.mean([1.0 if output == expected else 0.0])

    Args:
        func: The function to wrap (when used without parentheses)
        name: Custom name for the scorer
        requirements: List of pip requirements

    Returns:
        A scorer instance that can be used in evaluations
    """

    def decorator(f: F) -> F:
        if asyncio.iscoroutinefunction(f):
            scorer = AsyncFunctionScorer(f, name=name, requirements=requirements)
        else:
            scorer = FunctionScorer(f, name=name, requirements=requirements)

        # Preserve function metadata
        functools.update_wrapper(scorer, f)

        return scorer  # type: ignore

    if func is not None:
        # Called without arguments: @Scorer
        return decorator(func)

    # Called with arguments: @Scorer(name="...")
    return decorator


def is_scorer(obj: Any) -> bool:
    """Check if an object is a scorer."""
    return isinstance(obj, (BaseScorer, AsyncBaseScorer))


def is_async_scorer(obj: Any) -> bool:
    """Check if an object is an async scorer."""
    return isinstance(obj, AsyncBaseScorer)


def ensure_scorer(
    obj: Union[BaseScorer, Callable[..., float]],
    name: Optional[str] = None,
) -> BaseScorer:
    """Ensure object is a scorer, wrapping functions if needed.

    Args:
        obj: Scorer instance or function
        name: Optional name override

    Returns:
        BaseScorer instance
    """
    if isinstance(obj, BaseScorer):
        return obj

    if callable(obj):
        if asyncio.iscoroutinefunction(obj):
            return AsyncFunctionScorer(obj, name=name)
        return FunctionScorer(obj, name=name)

    raise TypeError(f"Cannot convert {type(obj)} to scorer")
