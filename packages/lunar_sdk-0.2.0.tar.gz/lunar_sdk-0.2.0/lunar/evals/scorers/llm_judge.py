"""LLM-as-Judge scorer for AI-powered evaluations."""

from __future__ import annotations

import re
from typing import Any, Dict, List, Literal, Optional, Tuple, Union

from .._base import AsyncBaseScorer
from ..types import ScorerResult

OutputType = Literal["boolean", "categorical", "discrete", "percentage"]


# System prompts for different output types
JUDGE_SYSTEM_PROMPTS = {
    "boolean": (
        "You are an evaluation judge. After analyzing the content, "
        "respond with ONLY the word 'true' or 'false'. "
        "Do not include any other text, explanation, or punctuation."
    ),
    "categorical": (
        "You are an evaluation judge. After analyzing the content, "
        "respond with ONLY one of these exact categories: {categories}. "
        "Do not include any other text, explanation, or punctuation."
    ),
    "discrete": (
        "You are an evaluation judge. After analyzing the content, "
        "respond with ONLY a single integer from {min} to {max} (inclusive). "
        "Do not include any other text, explanation, or punctuation."
    ),
    "percentage": (
        "You are an evaluation judge. After analyzing the content, "
        "respond with ONLY a decimal number from 0.0 to 1.0. "
        "Do not include any other text, explanation, or punctuation."
    ),
}

COT_SUFFIX = """

Before giving your final answer, think step by step about your evaluation.

Format your response EXACTLY as follows:
<reasoning>
Your step-by-step reasoning here
</reasoning>
<answer>
Your final answer here (just the value, no explanation)
</answer>
"""


class LLMJudgeScorer(AsyncBaseScorer):
    """LLM-as-Judge scorer that uses an LLM to evaluate outputs.

    This scorer sends the output to an LLM with a custom prompt to get
    an evaluation score.

    Example:
        >>> from lunar.evals import llmJudge
        >>>
        >>> helpfulness = llmJudge(
        ...     name="helpfulness",
        ...     prompt="Rate how helpful this response is: {output}",
        ...     model="claude-3-5-haiku",
        ...     output_type="discrete",
        ...     range=(1, 5),
        ... )
    """

    def __init__(
        self,
        name: str,
        prompt: str,
        model: str = "claude-3-5-haiku",
        output_type: OutputType = "percentage",
        categories: Optional[List[str]] = None,
        range: Optional[Tuple[int, int]] = None,
        chain_of_thought: bool = False,
        temperature: float = 0.0,
        client: Optional[Any] = None,
    ):
        """Initialize LLM Judge scorer.

        Args:
            name: Name of the scorer
            prompt: Evaluation prompt template. Available variables:
                - {input}: The input to the task
                - {output}: The output from the task
                - {expected}: The expected output (if available)
            model: Model to use for judging (default: claude-3-5-haiku)
            output_type: Type of output expected:
                - "boolean": true/false
                - "categorical": one of predefined categories
                - "discrete": integer in range
                - "percentage": decimal 0.0-1.0
            categories: List of valid categories (required for "categorical")
            range: (min, max) tuple (required for "discrete")
            chain_of_thought: Enable step-by-step reasoning
            temperature: Model temperature (default: 0.0 for consistency)
            client: Optional Lunar client instance (will be set by runner)
        """
        super().__init__(name=name)

        self._prompt_template = prompt
        self._model = model
        self._output_type = output_type
        self._categories = categories
        self._range = range
        self._chain_of_thought = chain_of_thought
        self._temperature = temperature
        self._client = client

        # Validate configuration
        if output_type == "categorical" and not categories:
            raise ValueError("categories is required for categorical output type")
        if output_type == "discrete" and not range:
            raise ValueError("range is required for discrete output type")

    def set_client(self, client: Any) -> None:
        """Set the Lunar client for API calls.

        Args:
            client: Lunar or AsyncLunar client instance
        """
        self._client = client

    def _build_system_prompt(self) -> str:
        """Build the system prompt based on output type."""
        base_prompt = JUDGE_SYSTEM_PROMPTS[self._output_type]

        if self._output_type == "categorical":
            base_prompt = base_prompt.format(
                categories=", ".join(f"'{c}'" for c in self._categories)
            )
        elif self._output_type == "discrete":
            base_prompt = base_prompt.format(
                min=self._range[0], max=self._range[1]
            )

        if self._chain_of_thought:
            base_prompt += COT_SUFFIX

        return base_prompt

    def _build_user_prompt(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
    ) -> str:
        """Build the user prompt from template."""
        # Convert input to string if dict
        input_str = (
            str(input) if isinstance(input, dict) else (input or "")
        )

        return self._prompt_template.format(
            input=input_str,
            output=output,
            expected=expected or "",
        )

    def _parse_response(self, response: str) -> Tuple[float, Optional[str]]:
        """Parse the LLM response to extract score and explanation.

        Returns:
            Tuple of (normalized_score, explanation)
        """
        explanation = None
        answer = response.strip()

        # Extract answer from COT format if present
        if self._chain_of_thought:
            reasoning_match = re.search(
                r"<reasoning>(.*?)</reasoning>", response, re.DOTALL
            )
            answer_match = re.search(
                r"<answer>(.*?)</answer>", response, re.DOTALL
            )

            if reasoning_match:
                explanation = reasoning_match.group(1).strip()
            if answer_match:
                answer = answer_match.group(1).strip()

        # Parse based on output type
        if self._output_type == "boolean":
            return self._parse_boolean(answer), explanation
        elif self._output_type == "categorical":
            return self._parse_categorical(answer), explanation
        elif self._output_type == "discrete":
            return self._parse_discrete(answer), explanation
        else:  # percentage
            return self._parse_percentage(answer), explanation

    def _parse_boolean(self, answer: str) -> float:
        """Parse boolean answer."""
        answer_lower = answer.lower().strip()
        if answer_lower in ("true", "yes", "1"):
            return 1.0
        elif answer_lower in ("false", "no", "0"):
            return 0.0
        return 0.0

    def _parse_categorical(self, answer: str) -> float:
        """Parse categorical answer and return position-based score."""
        answer_lower = answer.lower().strip()

        for i, category in enumerate(self._categories):
            if answer_lower == category.lower():
                # Return score based on position (higher categories = higher score)
                return i / (len(self._categories) - 1) if len(self._categories) > 1 else 1.0

        return 0.0

    def _parse_discrete(self, answer: str) -> float:
        """Parse discrete answer and normalize to 0-1."""
        try:
            # Extract number from answer
            numbers = re.findall(r"-?\d+", answer)
            if not numbers:
                return 0.0

            value = int(numbers[0])
            min_val, max_val = self._range

            # Clamp to range
            value = max(min_val, min(max_val, value))

            # Normalize to 0-1
            if max_val == min_val:
                return 1.0
            return (value - min_val) / (max_val - min_val)

        except (ValueError, IndexError):
            return 0.0

    def _parse_percentage(self, answer: str) -> float:
        """Parse percentage/decimal answer."""
        try:
            # Extract decimal number
            numbers = re.findall(r"-?\d+\.?\d*", answer)
            if not numbers:
                return 0.0

            value = float(numbers[0])
            return max(0.0, min(1.0, value))

        except (ValueError, IndexError):
            return 0.0

    async def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        """Score using LLM as judge.

        Args:
            output: The output from the task
            expected: The expected output (if available)
            input: The original input
            **kwargs: Additional arguments

        Returns:
            Normalized score (0.0 - 1.0)

        Raises:
            ValueError: If no client is configured
        """
        if self._client is None:
            raise ValueError(
                "LLM Judge requires a Lunar client. "
                "Use set_client() or run through client.evals.run()"
            )

        system_prompt = self._build_system_prompt()
        user_prompt = self._build_user_prompt(output, expected, input)

        # Call the LLM
        response = await self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=self._temperature,
        )

        # Extract and parse response
        response_text = response.choices[0].message.content
        score, _ = self._parse_response(response_text)

        return score

    async def __call__(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> ScorerResult:
        """Execute scorer and return result with metadata."""
        import time

        start_time = time.perf_counter()
        error = None
        score = 0.0
        raw_value = None
        explanation = None

        try:
            if self._client is None:
                raise ValueError(
                    "LLM Judge requires a Lunar client. "
                    "Use set_client() or run through client.evals.run()"
                )

            system_prompt = self._build_system_prompt()
            user_prompt = self._build_user_prompt(output, expected, input)

            response = await self._client.chat.completions.create(
                model=self._model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=self._temperature,
            )

            response_text = response.choices[0].message.content
            raw_value = response_text
            score, explanation = self._parse_response(response_text)

        except Exception as e:
            error = str(e)

        latency_ms = (time.perf_counter() - start_time) * 1000

        return ScorerResult(
            name=self.name,
            score=score,
            raw_value=raw_value,
            explanation=explanation,
            latency_ms=latency_ms,
            error=error,
        )


def llmJudge(
    name: str,
    prompt: str,
    model: str = "claude-3-5-haiku",
    output_type: OutputType = "percentage",
    categories: Optional[List[str]] = None,
    range: Optional[Tuple[int, int]] = None,
    chain_of_thought: bool = False,
    temperature: float = 0.0,
) -> LLMJudgeScorer:
    """Create an LLM-as-Judge scorer.

    This creates a scorer that uses an LLM to evaluate outputs based on
    a custom prompt.

    Args:
        name: Name of the scorer (used in results)
        prompt: Evaluation prompt template. Available variables:
            - {input}: The input to the task
            - {output}: The output from the task
            - {expected}: The expected output (if available)
        model: Model to use for judging. Defaults to "claude-3-5-haiku"
        output_type: Type of output expected from the judge:
            - "boolean": Expects true/false answer
            - "categorical": Expects one of predefined categories
            - "discrete": Expects integer in a range
            - "percentage": Expects decimal 0.0-1.0
        categories: List of valid categories (required for "categorical")
        range: (min, max) tuple for valid values (required for "discrete")
        chain_of_thought: Enable step-by-step reasoning before answer
        temperature: Model temperature (default: 0.0 for consistency)

    Returns:
        LLMJudgeScorer instance

    Example:
        >>> # Boolean judge
        >>> is_polite = llmJudge(
        ...     name="is_polite",
        ...     prompt="Is this response polite? {output}",
        ...     output_type="boolean",
        ... )
        >>>
        >>> # Discrete scale judge
        >>> helpfulness = llmJudge(
        ...     name="helpfulness",
        ...     prompt="Rate the helpfulness of this response 1-5: {output}",
        ...     output_type="discrete",
        ...     range=(1, 5),
        ... )
        >>>
        >>> # Categorical judge
        >>> sentiment = llmJudge(
        ...     name="sentiment",
        ...     prompt="What is the sentiment? {output}",
        ...     output_type="categorical",
        ...     categories=["negative", "neutral", "positive"],
        ... )
        >>>
        >>> # With chain-of-thought
        >>> accuracy = llmJudge(
        ...     name="accuracy",
        ...     prompt="Is this factually accurate? Input: {input} Output: {output}",
        ...     output_type="boolean",
        ...     chain_of_thought=True,
        ... )
    """
    return LLMJudgeScorer(
        name=name,
        prompt=prompt,
        model=model,
        output_type=output_type,
        categories=categories,
        range=range,
        chain_of_thought=chain_of_thought,
        temperature=temperature,
    )
