"""Default scorers for common evaluation tasks."""

from __future__ import annotations

import json
import re
from typing import Any, Callable, Dict, List, Optional, Union

from .._base import BaseScorer, FunctionScorer


class ExactMatchScorer(BaseScorer):
    """Exact string match scorer."""

    def __init__(self, ignore_case: bool = False):
        name = "exactMatchIgnoreCase" if ignore_case else "exactMatch"
        super().__init__(name=name)
        self._ignore_case = ignore_case

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        if expected is None:
            return 0.0

        out = output.strip()
        exp = expected.strip()

        if self._ignore_case:
            out = out.lower()
            exp = exp.lower()

        return 1.0 if out == exp else 0.0


class ContainsScorer(BaseScorer):
    """Check if expected is contained in output."""

    def __init__(self, ignore_case: bool = False):
        name = "containsIgnoreCase" if ignore_case else "contains"
        super().__init__(name=name)
        self._ignore_case = ignore_case

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        if expected is None:
            return 0.0

        out = output
        exp = expected.strip()

        if self._ignore_case:
            out = out.lower()
            exp = exp.lower()

        return 1.0 if exp in out else 0.0


class StartsWithScorer(BaseScorer):
    """Check if output starts with expected."""

    def __init__(self):
        super().__init__(name="startsWith")

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        if expected is None:
            return 0.0
        return 1.0 if output.strip().startswith(expected.strip()) else 0.0


class EndsWithScorer(BaseScorer):
    """Check if output ends with expected."""

    def __init__(self):
        super().__init__(name="endsWith")

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        if expected is None:
            return 0.0
        return 1.0 if output.strip().endswith(expected.strip()) else 0.0


class RegexScorer(BaseScorer):
    """Regex pattern match scorer."""

    def __init__(self, pattern: str, flags: int = 0):
        # Truncate name for display
        display_pattern = pattern[:30] + "..." if len(pattern) > 30 else pattern
        super().__init__(name=f"regex:{display_pattern}")
        self._pattern = re.compile(pattern, flags)

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        return 1.0 if self._pattern.search(output) else 0.0


class JsonValidScorer(BaseScorer):
    """Check if output is valid JSON."""

    def __init__(self):
        super().__init__(name="jsonValid")

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        try:
            json.loads(output.strip())
            return 1.0
        except (json.JSONDecodeError, TypeError):
            return 0.0


class JsonSchemaScorer(BaseScorer):
    """Validate JSON output against a schema."""

    def __init__(self, schema: Dict[str, Any]):
        super().__init__(
            name="jsonSchema",
            requirements=["jsonschema>=4.0"],
        )
        self._schema = schema

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        try:
            from jsonschema import validate, ValidationError

            data = json.loads(output.strip())
            validate(instance=data, schema=self._schema)
            return 1.0
        except (json.JSONDecodeError, ValidationError, ImportError):
            return 0.0


class LengthInRangeScorer(BaseScorer):
    """Check if output length is within range."""

    def __init__(self, min_len: int = 0, max_len: int = float("inf")):
        super().__init__(name=f"lengthInRange:{min_len}-{max_len}")
        self._min_len = min_len
        self._max_len = max_len

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        length = len(output)
        return 1.0 if self._min_len <= length <= self._max_len else 0.0


class WordCountScorer(BaseScorer):
    """Check if word count is within range."""

    def __init__(self, min_words: int = 0, max_words: int = float("inf")):
        super().__init__(name=f"wordCount:{min_words}-{max_words}")
        self._min_words = min_words
        self._max_words = max_words

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        word_count = len(output.split())
        return 1.0 if self._min_words <= word_count <= self._max_words else 0.0


class NotEmptyScorer(BaseScorer):
    """Check if output is not empty."""

    def __init__(self):
        super().__init__(name="notEmpty")

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        return 1.0 if output.strip() else 0.0


class IsNumericScorer(BaseScorer):
    """Check if output is a valid number."""

    def __init__(self):
        super().__init__(name="isNumeric")

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        try:
            float(output.strip())
            return 1.0
        except ValueError:
            return 0.0


class NumericInRangeScorer(BaseScorer):
    """Check if numeric output is within range."""

    def __init__(self, min_val: float = float("-inf"), max_val: float = float("inf")):
        super().__init__(name=f"numericInRange:{min_val}-{max_val}")
        self._min_val = min_val
        self._max_val = max_val

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        try:
            value = float(output.strip())
            return 1.0 if self._min_val <= value <= self._max_val else 0.0
        except ValueError:
            return 0.0


class SemanticSimilarityScorer(BaseScorer):
    """Calculate semantic similarity using embeddings.

    Note: This is a placeholder that requires additional setup.
    For production use, consider integrating with an embeddings API.
    """

    def __init__(self, threshold: float = 0.8):
        super().__init__(
            name="semanticSimilarity",
            requirements=["sentence-transformers>=2.0"],
        )
        self._threshold = threshold
        self._model = None

    def _get_model(self):
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer

                self._model = SentenceTransformer("all-MiniLM-L6-v2")
            except ImportError:
                raise ImportError(
                    "sentence-transformers is required for semantic similarity. "
                    "Install with: pip install sentence-transformers"
                )
        return self._model

    def score(
        self,
        output: str,
        expected: Optional[str] = None,
        input: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> float:
        if expected is None:
            return 0.0

        try:
            from sentence_transformers import util

            model = self._get_model()
            embeddings = model.encode([output, expected], convert_to_tensor=True)
            similarity = util.cos_sim(embeddings[0], embeddings[1]).item()
            return max(0.0, min(1.0, similarity))
        except Exception:
            return 0.0


# Pre-instantiated scorers for common use
exactMatch = ExactMatchScorer(ignore_case=False)
exactMatchIgnoreCase = ExactMatchScorer(ignore_case=True)
contains = ContainsScorer(ignore_case=False)
containsIgnoreCase = ContainsScorer(ignore_case=True)
startsWith = StartsWithScorer()
endsWith = EndsWithScorer()
jsonValid = JsonValidScorer()
notEmpty = NotEmptyScorer()
isNumeric = IsNumericScorer()


# Factory functions for parameterized scorers
def regex(pattern: str, flags: int = 0) -> RegexScorer:
    """Create a regex pattern scorer.

    Args:
        pattern: Regular expression pattern
        flags: Regex flags (e.g., re.IGNORECASE)

    Returns:
        RegexScorer instance
    """
    return RegexScorer(pattern, flags)


def jsonSchema(schema: Dict[str, Any]) -> JsonSchemaScorer:
    """Create a JSON schema validator scorer.

    Args:
        schema: JSON schema dictionary

    Returns:
        JsonSchemaScorer instance
    """
    return JsonSchemaScorer(schema)


def lengthInRange(min_len: int = 0, max_len: int = float("inf")) -> LengthInRangeScorer:
    """Create a length range scorer.

    Args:
        min_len: Minimum length (inclusive)
        max_len: Maximum length (inclusive)

    Returns:
        LengthInRangeScorer instance
    """
    return LengthInRangeScorer(min_len, max_len)


def wordCount(
    min_words: int = 0, max_words: int = float("inf")
) -> WordCountScorer:
    """Create a word count scorer.

    Args:
        min_words: Minimum word count (inclusive)
        max_words: Maximum word count (inclusive)

    Returns:
        WordCountScorer instance
    """
    return WordCountScorer(min_words, max_words)


def numericInRange(
    min_val: float = float("-inf"), max_val: float = float("inf")
) -> NumericInRangeScorer:
    """Create a numeric range scorer.

    Args:
        min_val: Minimum value (inclusive)
        max_val: Maximum value (inclusive)

    Returns:
        NumericInRangeScorer instance
    """
    return NumericInRangeScorer(min_val, max_val)


def semanticSimilarity(threshold: float = 0.8) -> SemanticSimilarityScorer:
    """Create a semantic similarity scorer.

    Args:
        threshold: Similarity threshold (0-1)

    Returns:
        SemanticSimilarityScorer instance
    """
    return SemanticSimilarityScorer(threshold)
