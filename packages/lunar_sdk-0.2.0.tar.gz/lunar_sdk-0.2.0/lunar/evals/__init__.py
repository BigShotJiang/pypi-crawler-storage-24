"""Evaluations module for Lunar SDK.

This module provides tools for evaluating LLM outputs with various metrics,
including default scorers, custom Python scorers, and LLM-as-Judge evaluators.

Example:
    >>> from lunar import Lunar
    >>> from lunar.evals import exactMatch, llmJudge, Scorer
    >>>
    >>> client = Lunar()
    >>>
    >>> # Run evaluation with default scorers
    >>> result = client.evals.run(
    ...     name="QA Accuracy Test",
    ...     dataset=[
    ...         {"input": "What is 2+2?", "expected": "4"},
    ...         {"input": "Capital of France?", "expected": "Paris"},
    ...     ],
    ...     task=lambda x: client.chat.completions.create(
    ...         model="claude-3-5-haiku",
    ...         messages=[{"role": "user", "content": x}]
    ...     ).choices[0].message.content,
    ...     scorers=[exactMatch],
    ... )
    >>>
    >>> # With LLM-as-Judge
    >>> helpfulness = llmJudge(
    ...     name="helpfulness",
    ...     prompt="Rate 1-5 how helpful: {output}",
    ...     output_type="discrete",
    ...     range=(1, 5),
    ... )
    >>> result = client.evals.run(
    ...     name="Helpfulness Test",
    ...     dataset=my_dataset,
    ...     task=my_task,
    ...     scorers=[helpfulness],
    ... )
    >>>
    >>> # Custom scorer with decorator
    >>> @Scorer
    ... def has_greeting(output: str, expected: str = None) -> float:
    ...     greetings = ["hello", "hi", "hey"]
    ...     return 1.0 if any(g in output.lower() for g in greetings) else 0.0
"""

from ._base import (
    AsyncBaseScorer,
    BaseScorer,
    FunctionScorer,
    AsyncFunctionScorer,
    Scorer,
    ensure_scorer,
    is_scorer,
    is_async_scorer,
)
from .types import (
    AnnotationAnalytics,
    AnnotationItem,
    AnnotationQueue,
    AutoCollectConfig,
    AutoEvalConfig,
    AutoEvalRun,
    DataPoint,
    Dataset,
    DatasetWithDatapoints,
    EvaluationProgress,
    EvaluationResult,
    EvaluationRow,
    EvaluationStatus,
    EvaluationStatusResponse,
    EvaluationSummary,
    Experiment,
    Metric,
    MetricType,
    Proposal,
    ProposalStatus,
    ScanResult,
    ScorerResult,
    ScorerSummary,
    ScriptValidationResult,
    Trace,
    TraceIssue,
)
from .scorers import (
    # Default scorers (instances)
    exactMatch,
    exactMatchIgnoreCase,
    contains,
    containsIgnoreCase,
    startsWith,
    endsWith,
    jsonValid,
    notEmpty,
    isNumeric,
    # Default scorers (factories)
    regex,
    jsonSchema,
    lengthInRange,
    wordCount,
    numericInRange,
    semanticSimilarity,
    # LLM-as-Judge
    llmJudge,
    LLMJudgeScorer,
)

__all__ = [
    # Base classes
    "BaseScorer",
    "AsyncBaseScorer",
    "FunctionScorer",
    "AsyncFunctionScorer",
    "Scorer",
    "ensure_scorer",
    "is_scorer",
    "is_async_scorer",
    # Types
    "AnnotationAnalytics",
    "AnnotationItem",
    "AnnotationQueue",
    "AutoCollectConfig",
    "AutoEvalConfig",
    "AutoEvalRun",
    "DataPoint",
    "Dataset",
    "DatasetWithDatapoints",
    "EvaluationProgress",
    "EvaluationResult",
    "EvaluationRow",
    "EvaluationStatus",
    "EvaluationStatusResponse",
    "EvaluationSummary",
    "Experiment",
    "Metric",
    "MetricType",
    "Proposal",
    "ProposalStatus",
    "ScanResult",
    "ScorerResult",
    "ScorerSummary",
    "ScriptValidationResult",
    "Trace",
    "TraceIssue",
    # Default scorers (instances)
    "exactMatch",
    "exactMatchIgnoreCase",
    "contains",
    "containsIgnoreCase",
    "startsWith",
    "endsWith",
    "jsonValid",
    "notEmpty",
    "isNumeric",
    # Default scorers (factories)
    "regex",
    "jsonSchema",
    "lengthInRange",
    "wordCount",
    "numericInRange",
    "semanticSimilarity",
    # LLM-as-Judge
    "llmJudge",
    "LLMJudgeScorer",
]
