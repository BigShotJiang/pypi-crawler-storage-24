"""LangChain integration for the Lunar SDK."""

from __future__ import annotations

import json as json_mod
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional

from langchain_core.callbacks import (
    AsyncCallbackManagerForLLMRun,
    CallbackManagerForLLMRun,
)
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from pydantic import PrivateAttr

from lunar import AsyncLunar, Lunar
from lunar.types.chat import ChatCompletion


def _convert_messages(messages: List[BaseMessage]) -> List[Dict[str, Any]]:
    """Convert LangChain messages to Lunar API message dicts."""
    result: List[Dict[str, Any]] = []
    for msg in messages:
        if isinstance(msg, SystemMessage):
            result.append({"role": "system", "content": msg.content})
        elif isinstance(msg, HumanMessage):
            result.append({"role": "user", "content": msg.content})
        elif isinstance(msg, AIMessage):
            d: Dict[str, Any] = {"role": "assistant", "content": msg.content or ""}
            if msg.tool_calls:
                d["tool_calls"] = [
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["name"],
                            "arguments": (
                                tc["args"]
                                if isinstance(tc["args"], str)
                                else json_mod.dumps(tc["args"])
                            ),
                        },
                    }
                    for tc in msg.tool_calls
                ]
            result.append(d)
        elif isinstance(msg, ToolMessage):
            result.append({
                "role": "tool",
                "content": msg.content,
                "tool_call_id": msg.tool_call_id,
            })
        else:
            # Fallback: use the message type as role
            result.append({"role": msg.type, "content": msg.content})
    return result


def _convert_response(response: ChatCompletion) -> ChatResult:
    """Convert a Lunar ChatCompletion to a LangChain ChatResult."""
    message = response.choices[0].message
    finish_reason = response.choices[0].finish_reason

    response_metadata: Dict[str, Any] = {
        "model": response.model,
        "finish_reason": finish_reason,
    }

    usage_metadata: Optional[Dict[str, int]] = None
    if response.usage:
        usage_metadata = {
            "input_tokens": response.usage.prompt_tokens,
            "output_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens,
        }
        if response.usage.input_cost_usd is not None:
            response_metadata["input_cost_usd"] = response.usage.input_cost_usd
        if response.usage.output_cost_usd is not None:
            response_metadata["output_cost_usd"] = response.usage.output_cost_usd
        if response.usage.total_cost_usd is not None:
            response_metadata["total_cost_usd"] = response.usage.total_cost_usd
        if response.usage.latency_ms is not None:
            response_metadata["latency_ms"] = response.usage.latency_ms
        if response.usage.ttft_ms is not None:
            response_metadata["ttft_ms"] = response.usage.ttft_ms

    ai_message = AIMessage(
        content=message.content or "",
        response_metadata=response_metadata,
        usage_metadata=usage_metadata,
    )

    generation = ChatGeneration(message=ai_message)
    return ChatResult(generations=[generation])


class ChatLunar(BaseChatModel):
    """LangChain chat model backed by the Lunar SDK.

    Example:
        >>> from lunar.integrations.langchain import ChatLunar
        >>> llm = ChatLunar(model="gpt-4o-mini")
        >>> llm.invoke("Hello!")
    """

    model: str
    api_key: Optional[str] = None
    environment: Optional[str] = None
    base_url: Optional[str] = None
    fallbacks: Optional[List[str]] = None
    timeout: Optional[float] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    stop: Optional[List[str]] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None

    _client: Optional[Lunar] = PrivateAttr(default=None)
    _async_client: Optional[AsyncLunar] = PrivateAttr(default=None)

    @property
    def _llm_type(self) -> str:
        return "lunar"

    @property
    def _identifying_params(self) -> Dict[str, Any]:
        params: Dict[str, Any] = {"model": self.model}
        if self.temperature is not None:
            params["temperature"] = self.temperature
        if self.max_tokens is not None:
            params["max_tokens"] = self.max_tokens
        if self.base_url is not None:
            params["base_url"] = self.base_url
        return params

    def _get_client(self) -> Lunar:
        if self._client is None:
            kwargs: Dict[str, Any] = {}
            if self.api_key:
                kwargs["api_key"] = self.api_key
            if self.environment:
                kwargs["environment"] = self.environment
            if self.base_url:
                kwargs["base_url"] = self.base_url
            if self.timeout:
                kwargs["timeout"] = self.timeout
            self._client = Lunar(**kwargs)
        return self._client

    def _get_async_client(self) -> AsyncLunar:
        if self._async_client is None:
            kwargs: Dict[str, Any] = {}
            if self.api_key:
                kwargs["api_key"] = self.api_key
            if self.environment:
                kwargs["environment"] = self.environment
            if self.base_url:
                kwargs["base_url"] = self.base_url
            if self.timeout:
                kwargs["timeout"] = self.timeout
            self._async_client = AsyncLunar(**kwargs)
        return self._async_client

    def _build_params(
        self, stop: Optional[List[str]] = None, **kwargs: Any
    ) -> Dict[str, Any]:
        """Build parameters for the API call."""
        params: Dict[str, Any] = {}
        if self.temperature is not None:
            params["temperature"] = self.temperature
        if self.max_tokens is not None:
            params["max_tokens"] = self.max_tokens
        if self.top_p is not None:
            params["top_p"] = self.top_p
        if self.frequency_penalty is not None:
            params["frequency_penalty"] = self.frequency_penalty
        if self.presence_penalty is not None:
            params["presence_penalty"] = self.presence_penalty

        effective_stop = stop or self.stop
        if effective_stop:
            params["stop"] = effective_stop

        # Per-call kwargs override class-level params
        params.update(kwargs)
        return params

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        client = self._get_client()
        params = self._build_params(stop=stop, **kwargs)

        response = client.chat.completions.create(
            model=self.model,
            messages=_convert_messages(messages),
            fallbacks=self.fallbacks,
            **params,
        )

        return _convert_response(response)

    def _stream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> Iterator[ChatGenerationChunk]:
        client = self._get_client()
        params = self._build_params(stop=stop, **kwargs)

        stream = client.chat.completions.create(
            model=self.model,
            messages=_convert_messages(messages),
            stream=True,
            fallbacks=self.fallbacks,
            **params,
        )

        for chunk in stream:
            delta = chunk.choices[0].delta
            content = delta.content or ""
            gen_chunk = ChatGenerationChunk(
                message=AIMessageChunk(content=content),
            )
            if run_manager:
                run_manager.on_llm_new_token(content)
            yield gen_chunk

    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        client = self._get_async_client()
        params = self._build_params(stop=stop, **kwargs)

        response = await client.chat.completions.create(
            model=self.model,
            messages=_convert_messages(messages),
            fallbacks=self.fallbacks,
            **params,
        )

        return _convert_response(response)

    async def _astream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> AsyncIterator[ChatGenerationChunk]:
        client = self._get_async_client()
        params = self._build_params(stop=stop, **kwargs)

        stream = await client.chat.completions.create(
            model=self.model,
            messages=_convert_messages(messages),
            stream=True,
            fallbacks=self.fallbacks,
            **params,
        )

        async for chunk in stream:
            delta = chunk.choices[0].delta
            content = delta.content or ""
            gen_chunk = ChatGenerationChunk(
                message=AIMessageChunk(content=content),
            )
            if run_manager:
                await run_manager.on_llm_new_token(content)
            yield gen_chunk
