"""LlamaIndex integration for the Lunar SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

from llama_index.core.base.llms.generic_utils import (
    achat_to_completion_decorator,
    astream_chat_to_completion_decorator,
    chat_to_completion_decorator,
    stream_chat_to_completion_decorator,
)
from llama_index.core.llms import (
    ChatMessage,
    ChatResponse,
    ChatResponseAsyncGen,
    ChatResponseGen,
    CompletionResponse,
    CompletionResponseAsyncGen,
    CompletionResponseGen,
    LLM,
    LLMMetadata,
    MessageRole,
)
from llama_index.core.llms.callbacks import llm_chat_callback, llm_completion_callback
from pydantic import Field, PrivateAttr

from lunar import AsyncLunar, Lunar
from lunar.types.chat import ChatCompletion


def _convert_messages(messages: Sequence[ChatMessage]) -> List[Dict[str, Any]]:
    """Convert LlamaIndex ChatMessages to Lunar API message dicts."""
    result: List[Dict[str, Any]] = []
    for msg in messages:
        d: Dict[str, Any] = {"role": msg.role.value, "content": msg.content or ""}
        if msg.additional_kwargs:
            d.update(msg.additional_kwargs)
        result.append(d)
    return result


def _build_response_kwargs(response: ChatCompletion) -> Dict[str, Any]:
    """Extract usage/cost/latency from ChatCompletion into additional_kwargs."""
    kwargs: Dict[str, Any] = {}
    if response.usage:
        kwargs["usage"] = {
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens,
        }
        if response.usage.input_cost_usd is not None:
            kwargs["input_cost_usd"] = response.usage.input_cost_usd
        if response.usage.output_cost_usd is not None:
            kwargs["output_cost_usd"] = response.usage.output_cost_usd
        if response.usage.total_cost_usd is not None:
            kwargs["total_cost_usd"] = response.usage.total_cost_usd
        if response.usage.latency_ms is not None:
            kwargs["latency_ms"] = response.usage.latency_ms
        if response.usage.ttft_ms is not None:
            kwargs["ttft_ms"] = response.usage.ttft_ms
    return kwargs


class LunarLLM(LLM):
    """LlamaIndex LLM backed by the Lunar SDK.

    Example:
        >>> from lunar.integrations.llamaindex import LunarLLM
        >>> from llama_index.core.llms import ChatMessage
        >>> llm = LunarLLM(model="gpt-4o-mini")
        >>> resp = llm.chat([ChatMessage(role="user", content="Hello!")])
    """

    model: str
    api_key: Optional[str] = None
    environment: Optional[str] = None
    base_url: Optional[str] = None
    fallbacks: Optional[List[str]] = None
    timeout: Optional[float] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None

    _client: Optional[Lunar] = PrivateAttr(default=None)
    _async_client: Optional[AsyncLunar] = PrivateAttr(default=None)

    @classmethod
    def class_name(cls) -> str:
        return "LunarLLM"

    @property
    def metadata(self) -> LLMMetadata:
        return LLMMetadata(
            is_chat_model=True,
            model_name=self.model,
            num_output=self.max_tokens or -1,
        )

    def _get_client(self) -> Lunar:
        if self._client is None:
            kwargs: Dict[str, Any] = {}
            if self.api_key:
                kwargs["api_key"] = self.api_key
            if self.environment:
                kwargs["environment"] = self.environment
            if self.base_url:
                kwargs["base_url"] = self.base_url
            if self.timeout:
                kwargs["timeout"] = self.timeout
            self._client = Lunar(**kwargs)
        return self._client

    def _get_async_client(self) -> AsyncLunar:
        if self._async_client is None:
            kwargs: Dict[str, Any] = {}
            if self.api_key:
                kwargs["api_key"] = self.api_key
            if self.environment:
                kwargs["environment"] = self.environment
            if self.base_url:
                kwargs["base_url"] = self.base_url
            if self.timeout:
                kwargs["timeout"] = self.timeout
            self._async_client = AsyncLunar(**kwargs)
        return self._async_client

    def _build_params(self, **kwargs: Any) -> Dict[str, Any]:
        """Build parameters for the API call."""
        params: Dict[str, Any] = {}
        if self.temperature is not None:
            params["temperature"] = self.temperature
        if self.max_tokens is not None:
            params["max_tokens"] = self.max_tokens
        if self.top_p is not None:
            params["top_p"] = self.top_p
        if self.frequency_penalty is not None:
            params["frequency_penalty"] = self.frequency_penalty
        if self.presence_penalty is not None:
            params["presence_penalty"] = self.presence_penalty
        # Per-call kwargs override class-level params
        params.update(kwargs)
        return params

    # -- Chat ----------------------------------------------------------------

    @llm_chat_callback()
    def chat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponse:
        response = self._get_client().chat.completions.create(
            model=self.model,
            messages=_convert_messages(messages),
            fallbacks=self.fallbacks,
            **self._build_params(**kwargs),
        )
        content = response.choices[0].message.content or ""
        return ChatResponse(
            message=ChatMessage(role=MessageRole.ASSISTANT, content=content),
            raw=response,
            additional_kwargs=_build_response_kwargs(response),
        )

    @llm_chat_callback()
    def stream_chat(
        self, messages: Sequence[ChatMessage], **kwargs: Any
    ) -> ChatResponseGen:
        def gen():
            stream = self._get_client().chat.completions.create(
                model=self.model,
                messages=_convert_messages(messages),
                stream=True,
                fallbacks=self.fallbacks,
                **self._build_params(**kwargs),
            )
            accumulated = ""
            for chunk in stream:
                delta = chunk.choices[0].delta
                token = delta.content or ""
                accumulated += token
                yield ChatResponse(
                    message=ChatMessage(role=MessageRole.ASSISTANT, content=accumulated),
                    delta=token,
                )

        return gen()

    # -- Complete (delegates to chat) ----------------------------------------

    @llm_completion_callback()
    def complete(
        self, prompt: str, formatted: bool = False, **kwargs: Any
    ) -> CompletionResponse:
        return chat_to_completion_decorator(self.chat)(prompt, **kwargs)

    @llm_completion_callback()
    def stream_complete(
        self, prompt: str, formatted: bool = False, **kwargs: Any
    ) -> CompletionResponseGen:
        return stream_chat_to_completion_decorator(self.stream_chat)(prompt, **kwargs)

    # -- Async chat ----------------------------------------------------------

    async def achat(
        self, messages: Sequence[ChatMessage], **kwargs: Any
    ) -> ChatResponse:
        response = await self._get_async_client().chat.completions.create(
            model=self.model,
            messages=_convert_messages(messages),
            fallbacks=self.fallbacks,
            **self._build_params(**kwargs),
        )
        content = response.choices[0].message.content or ""
        return ChatResponse(
            message=ChatMessage(role=MessageRole.ASSISTANT, content=content),
            raw=response,
            additional_kwargs=_build_response_kwargs(response),
        )

    async def astream_chat(
        self, messages: Sequence[ChatMessage], **kwargs: Any
    ) -> ChatResponseAsyncGen:
        async def gen():
            stream = await self._get_async_client().chat.completions.create(
                model=self.model,
                messages=_convert_messages(messages),
                stream=True,
                fallbacks=self.fallbacks,
                **self._build_params(**kwargs),
            )
            accumulated = ""
            async for chunk in stream:
                delta = chunk.choices[0].delta
                token = delta.content or ""
                accumulated += token
                yield ChatResponse(
                    message=ChatMessage(role=MessageRole.ASSISTANT, content=accumulated),
                    delta=token,
                )

        return gen()

    # -- Async complete (delegates to async chat) ----------------------------

    async def acomplete(
        self, prompt: str, formatted: bool = False, **kwargs: Any
    ) -> CompletionResponse:
        return await achat_to_completion_decorator(self.achat)(prompt, **kwargs)

    async def astream_complete(
        self, prompt: str, formatted: bool = False, **kwargs: Any
    ) -> CompletionResponseAsyncGen:
        return await astream_chat_to_completion_decorator(self.astream_chat)(prompt, **kwargs)
