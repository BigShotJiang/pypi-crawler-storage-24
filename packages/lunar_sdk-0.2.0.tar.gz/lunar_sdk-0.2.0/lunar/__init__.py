"""Lunar SDK - Python client for Lunar LLM Inference API.

Lunar provides an OpenAI-compatible interface for accessing multiple LLM providers
through a single API, with built-in fallback support and cost tracking.

Example:
    >>> from lunar import Lunar
    >>>
    >>> # Initialize client (uses LUNAR_API_KEY env var, defaults to 'prod' environment)
    >>> client = Lunar()
    >>>
    >>> # Use development environment
    >>> client = Lunar(api_key="your-key", environment="dev")
    >>>
    >>> # Chat completion
    >>> response = client.chat.completions.create(
    ...     model="gpt-4o-mini",
    ...     messages=[{"role": "user", "content": "Hello!"}]
    ... )
    >>> print(response.choices[0].message.content)
    >>> print(f"Cost: ${response.usage.total_cost_usd}")
    >>>
    >>> # With fallbacks
    >>> response = client.chat.completions.create(
    ...     model="gpt-4o-mini",
    ...     messages=[{"role": "user", "content": "Hello!"}],
    ...     fallbacks=["claude-3-haiku", "llama-3.1-8b"]
    ... )
    >>>
    >>> # Streaming
    >>> stream = client.chat.completions.create(
    ...     model="gpt-4o-mini",
    ...     messages=[{"role": "user", "content": "Hello!"}],
    ...     stream=True
    ... )
    >>> for chunk in stream:
    ...     if chunk.choices[0].delta.content:
    ...         print(chunk.choices[0].delta.content, end="")

Async usage:
    >>> from lunar import AsyncLunar
    >>>
    >>> async with AsyncLunar() as client:  # defaults to 'prod'
    ...     response = await client.chat.completions.create(
    ...         model="gpt-4o-mini",
    ...         messages=[{"role": "user", "content": "Hello!"}]
    ...     )

Evaluations:
    >>> from lunar import Lunar
    >>> from lunar.evals import exactMatch, llmJudge
    >>>
    >>> client = Lunar()
    >>> result = client.evals.run(
    ...     name="QA Test",
    ...     dataset=[{"input": "What is 2+2?", "expected": "4"}],
    ...     task=lambda x: client.chat.completions.create(
    ...         model="claude-3-5-haiku",
    ...         messages=[{"role": "user", "content": x}]
    ...     ).choices[0].message.content,
    ...     scorers=[exactMatch],
    ... )
"""

from .client import AsyncLunar, Lunar
from ._config import ENVIRONMENTS, get_environment_urls
from .resources.chat import AsyncStream, Stream
from .types import (
    ChatChoice,
    ChatChoiceDelta,
    ChatCompletion,
    ChatCompletionChunk,
    ChatMessage,
    DeltaToolCall,
    FunctionCall,
    ToolCall,
    Completion,
    CompletionChoice,
    Model,
    ModelsListResponse,
    Provider,
    ProvidersListResponse,
    Usage,
    # RAG types
    Chunk,
    ChunkingStrategy,
    DeleteResponse,
    Document,
    DocumentType,
    IngestResponse,
    RAGConfig,
    RAGGenerateRequest,
    RAGGenerateResponse,
    RAGStats,
    RetrievalResponse,
    SearchResult,
)
from ._exceptions import (
    APIError,
    AuthenticationError,
    BadRequestError,
    ChatNotSupportedError,
    EvaluationError,
    LunarError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    ServerError,
    ServiceUnavailableError,
    TimeoutError,
    ConnectionError,
    UnprocessableEntityError,
    GatewayTimeoutError,
)

__version__ = "0.2.0"

__all__ = [
    # Clients
    "Lunar",
    "AsyncLunar",
    # Streaming
    "Stream",
    "AsyncStream",
    # Environment config
    "ENVIRONMENTS",
    "get_environment_urls",
    # Types - Chat
    "ChatMessage",
    "ChatChoice",
    "ChatChoiceDelta",
    "ChatCompletion",
    "ChatCompletionChunk",
    "DeltaToolCall",
    "FunctionCall",
    "ToolCall",
    # Types - Completion
    "Completion",
    "CompletionChoice",
    # Types - Models
    "Model",
    "ModelsListResponse",
    "Provider",
    "ProvidersListResponse",
    "Usage",
    # Types - RAG
    "Chunk",
    "ChunkingStrategy",
    "DeleteResponse",
    "Document",
    "DocumentType",
    "IngestResponse",
    "RAGConfig",
    "RAGGenerateRequest",
    "RAGGenerateResponse",
    "RAGStats",
    "RetrievalResponse",
    "SearchResult",
    # Exceptions
    "LunarError",
    "APIError",
    "BadRequestError",
    "ChatNotSupportedError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "UnprocessableEntityError",
    "RateLimitError",
    "ServerError",
    "ServiceUnavailableError",
    "GatewayTimeoutError",
    "ConnectionError",
    "TimeoutError",
    "EvaluationError",
]
