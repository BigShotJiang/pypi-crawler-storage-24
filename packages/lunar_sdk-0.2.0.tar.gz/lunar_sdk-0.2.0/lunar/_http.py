"""HTTP client wrapper with retry logic."""

import asyncio
import json
import logging
from typing import Any, AsyncIterator, Dict, Iterator, Optional, TypeVar

import httpx

from ._config import LunarConfig
from ._exceptions import (
    ConnectionError as LunarConnectionError,
    TimeoutError as LunarTimeoutError,
    raise_for_status,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")


class HTTPClient:
    """Synchronous HTTP client with retry logic."""

    def __init__(self, config: LunarConfig) -> None:
        """Initialize HTTP client.

        Args:
            config: Lunar configuration
        """
        self.config = config
        self._client: Optional[httpx.Client] = None

    @property
    def client(self) -> httpx.Client:
        """Get or create httpx client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.Client(
                base_url=self.config.base_url,
                headers=self.config.headers,
                timeout=httpx.Timeout(self.config.timeout),
                limits=httpx.Limits(max_connections=self.config.max_connections),
            )
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None and not self._client.is_closed:
            self._client.close()
            self._client = None

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make a GET request with retry logic.

        Args:
            path: API endpoint path
            params: Optional query parameters

        Returns:
            Response JSON as dict
        """
        return self._request_with_retry("GET", path, params=params)

    def post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make a POST request with retry logic.

        Args:
            path: API endpoint path
            json: Request body as JSON
            data: Form data (for multipart uploads)
            files: Files to upload (for multipart uploads)

        Returns:
            Response JSON as dict
        """
        return self._request_with_retry("POST", path, json=json, data=data, files=files)

    def post_stream(
        self, path: str, json_body: Optional[Dict[str, Any]] = None
    ) -> Iterator[Dict[str, Any]]:
        """Make a streaming POST request.

        Args:
            path: API endpoint path
            json_body: Request body

        Yields:
            Parsed JSON objects from SSE stream
        """
        try:
            with self.client.stream("POST", path, json=json_body) as response:
                raise_for_status(response.status_code, None)

                for line in response.iter_lines():
                    if not line:
                        continue
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            yield json.loads(data)
                        except json.JSONDecodeError:
                            continue
        except httpx.ConnectError as e:
            raise LunarConnectionError(f"Connection failed: {e}")
        except httpx.TimeoutException as e:
            raise LunarTimeoutError(f"Request timed out: {e}")

    def patch(self, path: str, json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make a PATCH request with retry logic.

        Args:
            path: API endpoint path
            json: Request body

        Returns:
            Response JSON as dict
        """
        return self._request_with_retry("PATCH", path, json=json)

    def put(self, path: str, json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make a PUT request with retry logic.

        Args:
            path: API endpoint path
            json: Request body

        Returns:
            Response JSON as dict
        """
        return self._request_with_retry("PUT", path, json=json)

    def delete(self, path: str) -> Dict[str, Any]:
        """Make a DELETE request with retry logic.

        Args:
            path: API endpoint path

        Returns:
            Response JSON as dict
        """
        return self._request_with_retry("DELETE", path)

    def _request_with_retry(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make a request with retry logic for transient errors.

        Args:
            method: HTTP method
            path: API endpoint path
            params: Optional query parameters
            json: Optional request body
            data: Optional form data (for multipart uploads)
            files: Optional files (for multipart uploads)

        Returns:
            Response JSON as dict

        Raises:
            Appropriate exception based on response status
        """
        import time

        last_error: Optional[Exception] = None

        for attempt in range(self.config.num_retries + 1):
            try:
                # For file uploads, use a direct request without the Content-Type header
                # to let httpx set it correctly for multipart/form-data
                if files is not None:
                    upload_headers = {k: v for k, v in self.config.headers.items() if k.lower() != "content-type"}
                    response = httpx.request(
                        method,
                        f"{self.config.base_url}{path}",
                        params=params,
                        data=data,
                        files=files,
                        headers=upload_headers,
                        timeout=httpx.Timeout(self.config.timeout),
                    )
                else:
                    response = self.client.request(
                        method, path, params=params, json=json, data=data, files=files
                    )

                # Parse response
                try:
                    response_body = response.json()
                except Exception:
                    response_body = None

                # Check for errors
                raise_for_status(response.status_code, response_body)

                return response_body or {}

            except httpx.ConnectError as e:
                last_error = LunarConnectionError(f"Connection failed: {e}")
            except httpx.TimeoutException as e:
                last_error = LunarTimeoutError(f"Request timed out: {e}")
            except Exception as e:
                # For non-retryable errors, raise immediately
                from ._exceptions import NON_FALLBACK_ERRORS

                if isinstance(e, NON_FALLBACK_ERRORS):
                    raise
                last_error = e

            # Calculate backoff (exponential with max 60s)
            if attempt < self.config.num_retries:
                wait = min(2**attempt, 60)
                logger.warning(
                    f"Request failed (attempt {attempt + 1}/{self.config.num_retries + 1}), "
                    f"retrying in {wait}s: {last_error}"
                )
                time.sleep(wait)

        # All retries exhausted
        if last_error:
            raise last_error
        raise RuntimeError("Request failed with unknown error")


class AsyncHTTPClient:
    """Asynchronous HTTP client with retry logic."""

    def __init__(self, config: LunarConfig) -> None:
        """Initialize async HTTP client.

        Args:
            config: Lunar configuration
        """
        self.config = config
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create async httpx client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.config.base_url,
                headers=self.config.headers,
                timeout=httpx.Timeout(self.config.timeout),
                limits=httpx.Limits(max_connections=self.config.max_connections),
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make a GET request with retry logic.

        Args:
            path: API endpoint path
            params: Optional query parameters

        Returns:
            Response JSON as dict
        """
        return await self._request_with_retry("GET", path, params=params)

    async def post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make a POST request with retry logic.

        Args:
            path: API endpoint path
            json: Request body as JSON
            data: Form data (for multipart uploads)
            files: Files to upload (for multipart uploads)

        Returns:
            Response JSON as dict
        """
        return await self._request_with_retry("POST", path, json=json, data=data, files=files)

    async def post_stream(
        self, path: str, json_body: Optional[Dict[str, Any]] = None
    ) -> AsyncIterator[Dict[str, Any]]:
        """Make a streaming POST request.

        Args:
            path: API endpoint path
            json_body: Request body

        Yields:
            Parsed JSON objects from SSE stream
        """
        try:
            async with self.client.stream("POST", path, json=json_body) as response:
                raise_for_status(response.status_code, None)

                async for line in response.aiter_lines():
                    if not line:
                        continue
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            yield json.loads(data)
                        except json.JSONDecodeError:
                            continue
        except httpx.ConnectError as e:
            raise LunarConnectionError(f"Connection failed: {e}")
        except httpx.TimeoutException as e:
            raise LunarTimeoutError(f"Request timed out: {e}")

    async def patch(self, path: str, json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make a PATCH request with retry logic.

        Args:
            path: API endpoint path
            json: Request body

        Returns:
            Response JSON as dict
        """
        return await self._request_with_retry("PATCH", path, json=json)

    async def put(self, path: str, json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make a PUT request with retry logic.

        Args:
            path: API endpoint path
            json: Request body

        Returns:
            Response JSON as dict
        """
        return await self._request_with_retry("PUT", path, json=json)

    async def delete(self, path: str) -> Dict[str, Any]:
        """Make a DELETE request with retry logic.

        Args:
            path: API endpoint path

        Returns:
            Response JSON as dict
        """
        return await self._request_with_retry("DELETE", path)

    async def _request_with_retry(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make a request with retry logic for transient errors.

        Args:
            method: HTTP method
            path: API endpoint path
            params: Optional query parameters
            json: Optional request body
            data: Optional form data (for multipart uploads)
            files: Optional files (for multipart uploads)

        Returns:
            Response JSON as dict

        Raises:
            Appropriate exception based on response status
        """
        last_error: Optional[Exception] = None

        for attempt in range(self.config.num_retries + 1):
            try:
                # For file uploads, use a direct request without the Content-Type header
                # to let httpx set it correctly for multipart/form-data
                if files is not None:
                    upload_headers = {k: v for k, v in self.config.headers.items() if k.lower() != "content-type"}
                    async with httpx.AsyncClient(timeout=httpx.Timeout(self.config.timeout)) as upload_client:
                        response = await upload_client.request(
                            method,
                            f"{self.config.base_url}{path}",
                            params=params,
                            data=data,
                            files=files,
                            headers=upload_headers,
                        )
                else:
                    response = await self.client.request(
                        method, path, params=params, json=json, data=data, files=files
                    )

                # Parse response
                try:
                    response_body = response.json()
                except Exception:
                    response_body = None

                # Check for errors
                raise_for_status(response.status_code, response_body)

                return response_body or {}

            except httpx.ConnectError as e:
                last_error = LunarConnectionError(f"Connection failed: {e}")
            except httpx.TimeoutException as e:
                last_error = LunarTimeoutError(f"Request timed out: {e}")
            except Exception as e:
                # For non-retryable errors, raise immediately
                from ._exceptions import NON_FALLBACK_ERRORS

                if isinstance(e, NON_FALLBACK_ERRORS):
                    raise
                last_error = e

            # Calculate backoff (exponential with max 60s)
            if attempt < self.config.num_retries:
                wait = min(2**attempt, 60)
                logger.warning(
                    f"Request failed (attempt {attempt + 1}/{self.config.num_retries + 1}), "
                    f"retrying in {wait}s: {last_error}"
                )
                await asyncio.sleep(wait)

        # All retries exhausted
        if last_error:
            raise last_error
        raise RuntimeError("Request failed with unknown error")
