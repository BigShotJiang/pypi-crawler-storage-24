from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def set_awspipe_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AWSPIPE_HOME", str(tmp_path / "awspipe-home"))
