from datetime import datetime, timezone

from awspipe.backend import BackendAdapter
from awspipe.providers.base import Column, TableProvider


DUMMY_PROVIDER = TableProvider(
    name="aws_dummy",
    description="Dummy table for backend tests.",
    columns=(
        Column("profile_name", "VARCHAR", "Profile name."),
        Column("account_id", "VARCHAR", "Account id."),
        Column("region", "VARCHAR", "Region."),
        Column("arn", "VARCHAR", "Arn."),
        Column("title", "VARCHAR", "Title."),
        Column("resource_id", "VARCHAR", "Resource id."),
        Column("created_at", "TIMESTAMP", "Created timestamp."),
    ),
    scope="regional",
    fetcher=lambda context: [],
)


def test_backend_replaces_rows_and_executes_queries(tmp_path) -> None:
    backend = BackendAdapter(tmp_path / "cache.duckdb")
    backend.replace_rows(
        DUMMY_PROVIDER,
        profile="dev",
        source_region="eu-west-1",
        rows=[
            {
                "profile_name": "dev",
                "account_id": "123456789012",
                "region": "eu-west-1",
                "arn": "arn:aws:test:::one",
                "title": "one",
                "resource_id": "r-1",
                "created_at": datetime(2026, 3, 9, tzinfo=timezone.utc),
            }
        ],
    )

    result = backend.execute("select resource_id, title from aws_dummy")

    assert result.columns == ["resource_id", "title"]
    assert result.rows == [("r-1", "one")]
    assert backend.is_fresh(DUMMY_PROVIDER, profile="dev", source_region="eu-west-1", ttl_seconds=60)
