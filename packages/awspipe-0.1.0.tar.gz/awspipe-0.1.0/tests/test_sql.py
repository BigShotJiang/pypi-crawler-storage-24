from awspipe.sql import extract_table_names


def test_extract_table_names_ignores_ctes() -> None:
    sql = """
    with scoped as (
        select account_id from aws_account
    )
    select scoped.account_id, vpc_id
    from scoped
    join aws_vpc on aws_vpc.account_id = scoped.account_id
    """
    assert extract_table_names(sql) == {"aws_account", "aws_vpc"}
