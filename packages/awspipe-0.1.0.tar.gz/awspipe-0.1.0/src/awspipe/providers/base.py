from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from awspipe.aws import AwsSessionContext


@dataclass(frozen=True)
class Column:
    name: str
    duckdb_type: str
    description: str


@dataclass(frozen=True)
class TableProvider:
    name: str
    description: str
    columns: tuple[Column, ...]
    scope: str
    fetcher: Any

    def fetch(self, context: AwsSessionContext) -> list[dict[str, Any]]:
        return self.fetcher(context)


class ProviderRegistry(Protocol):
    def get(self, table_name: str) -> TableProvider | None: ...

    def all(self) -> list[TableProvider]: ...
