from awspipe.providers.aws_tables import PROVIDERS, StaticProviderRegistry

__all__ = ["PROVIDERS", "StaticProviderRegistry"]
