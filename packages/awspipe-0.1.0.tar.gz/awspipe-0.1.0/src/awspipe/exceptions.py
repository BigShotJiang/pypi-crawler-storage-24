class AwspipeError(Exception):
    """Base exception for user-facing awspipe failures."""


class QueryPreparationError(AwspipeError):
    """Raised when awspipe cannot prepare or execute a query."""


class ProviderError(AwspipeError):
    """Raised when a provider cannot fetch data."""
