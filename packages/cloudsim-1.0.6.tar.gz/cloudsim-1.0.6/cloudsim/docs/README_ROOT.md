# Nimbus Cloud Simulator Monorepo

This workspace is split into two projects:
- `frontend/`: React UI (no cloud simulation logic)
- `backend/`: Flask API with all VM/LB/traffic simulation logic and autoscaling

Latest additions:
- VM `python_script` runtime mode with process-per-VM port behavior (including autoscaled clones).
- Online PostgreSQL SQL console support via backend APIs.
- Online MongoDB rental console support via backend APIs.

## Project layout

- Frontend app: `frontend/`
- Backend service: `backend/`
- Usage guide: `docs/SIMULATION_GUIDE.md`
- Backend reference: `docs/README_BACKEND.md`
- Frontend reference: `docs/README_FRONTEND.md`

## Run locally

1. Start backend

```bash
cd backend
python -m pip install -r requirements.txt
python app.py
```

2. Start frontend (new terminal)

```bash
cd frontend
npm install
npm run dev
```

Frontend runs on Vite (`http://localhost:5173`) and proxies `/api` to Flask (`http://127.0.0.1:5000`).

## Build frontend

```bash
cd frontend
npm run build
npm run preview
```

## CLI alias

From repo root you can use:

```bash
cloudsim health
cloudsim state --summary
```

If `cloudsim` is not in PATH, run:

```bash
.\cloudsim health
```

## DNS/Public URL concept

- Public URL is domain-only, no visible VM port:
  - `http://<vm-name>-<vm-id>.<region>.cloudsim.local`
- Internal port (`reservedPort`) is stored per VM and used only by gateway routing.
- DNS mapping is stored as domain records (`dns_records`), not full URL strings.
