# Frontend (React UI)

This project contains only the UI layer.

- Source: `frontend/src/`
- Dev server: Vite
- API target: `/api` proxied to Flask backend at `http://127.0.0.1:5000`
- UI includes:
  - VM runtime mode + python script path
  - LB/traffic simulation controls
  - online PostgreSQL SQL console (backend-driven)
  - online MongoDB rental console (backend-driven)

## Documentation

- Detailed frontend guide: `frontend/docs/FRONTEND_DETAILED_DOCS.md`
- Backend docs: `docs/README_BACKEND.md`

## Run

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```
