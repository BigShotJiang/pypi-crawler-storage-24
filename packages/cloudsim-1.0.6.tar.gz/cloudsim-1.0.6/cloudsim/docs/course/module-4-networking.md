# 🌐 Module 4: The Global Network

<p align="center">
  <img src="https://img.shields.io/badge/Module-4-7986CB?style=for-the-badge" alt="Module 4">
  <img src="https://img.shields.io/badge/Concept-Networking_&_DNS-9C27B0?style=for-the-badge" alt="Topic">
</p>

## 🗺️ System Design Concept: Public vs. Private Networking

In a real cloud VPC (Virtual Private Cloud), your VMs should **not** be open to the internet by default. This is for security.

### 1. The Private Subnet
When you create a VM in CloudSim, it is "Private". You can't reach it via a web browser easily because its port is hidden.

### 2. The Gateway (Expose)
To make a VM public, you need a **Reverse Proxy** or **Gateway**. 
- CloudSim simulates this by "Exposing" a internal port to a public-facing domain name.

---

## 🛠️ Design in Action: Service Discovery & DNS
How does `service-a` find `service-b`?
- **DNS (Domain Name System)**: Instead of remembering IP addresses like `127.0.0.1:7001`, humans (and apps) use names like `web-server.cloudsim.local`.
- **DNS Sync**: This command mimics the process of updating a Global DNS registry so everyone knows the new "Map" of the cloud.

---

## 🛠️ Lab Activity

### 1. Expose your Endpoint
```bash
cloudsim expose <vm-id>
```
*Observation: CloudSim will give you a "Public URL". Keep it!*

### 2. The Public Call
Test the networking path from the "Internet" to your "Private VM":
```bash
cloudsim call <vm-id> /health
```

### 3. DNS Synchronization
```bash
cloudsim dns-sync
```
*Observation: This mimics how `hosts` files or CoreDNS entries are updated in a real Kubernetes cluster.*

---

<p align="center">
  <b>Final Graduation!</b><br>
  You have mastered the lifecycle of Cloud Infrastructure.<br>
  🎉🎉🎉
</p>
