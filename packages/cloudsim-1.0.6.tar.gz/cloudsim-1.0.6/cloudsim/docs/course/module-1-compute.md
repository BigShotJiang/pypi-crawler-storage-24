# 💻 Module 1: The Compute Engine

<p align="center">
  <img src="https://img.shields.io/badge/Module-1-7986CB?style=for-the-badge" alt="Module 1">
  <img src="https://img.shields.io/badge/Concept-Isolation_&_Scaling-9C27B0?style=for-the-badge" alt="Topic">
</p>

## ☁️ System Design Concept: Resource Isolation

When you rent a "Server" in the cloud, you are rarely getting a whole physical machine. You are getting an **Isolated Environment**. 

CloudSim covers this through:
- **Process Isolation**: Every VM starts its own Python process. 
- **Filesystem Isolation**: Every VM has its own directory. One VM cannot "peek" into another VM's files.
- **Dependency Isolation**: Using `venv` (Virtual Environments), one VM can use Python 3.10 while another uses 3.12 without crashing each other.

---

## 🛠️ Design in Action: Ephemeral vs Persistent State
Most web servers should be **Stateless**. 
- If you save a file inside a `cloudsim ssh` session, and then `cloudsim vm delete`, that file is gone forever.
- This teaches you the System Design rule: **"Store data in a Database, not on the App Server."**

---

## 🛠️ Lab Activity

### 1. The Provisioning Ritual
Provisioning is the act of allocating resources.
```bash
cloudsim vm create --name web-node --region us-west1 --machine-type e2-micro --image "Ubuntu" --backend-profile-id python-fastapi
```

### 2. Verify the Isolation
Enter the VM and try to find where your host files are:
```bash
cloudsim ssh <vm-id>
pwd
ls -la
```
*Observation: You are trapped in a subfolder. You can't see the rest of your computer. This is "Jailing" or "Sandboxing", a core security concept.*

---
<p align="right">
  <a href="module-2-database.md"><b>Next: Module 2 - Multi-Tenancy ➡️</b></a>
</p>
