# 🚦 Module 3: The Traffic Orchestrator

<p align="center">
  <img src="https://img.shields.io/badge/Module-3-7986CB?style=for-the-badge" alt="Module 3">
  <img src="https://img.shields.io/badge/Concept-High_Availability-9C27B0?style=for-the-badge" alt="Topic">
</p>

## ⚖️ System Design Concept: High Availability (HA)

**High Availability** ensures that a system remains operational even if some of its components fail. 

CloudSim implements this through:
- **Redundancy**: Having multiple VMs (instances) of your application.
- **Health Checks**: (Simulated) The Load Balancer only sends traffic to VMs that are "Running".
- **Horizontal Scaling**: Adding more machines to share the load.

---

## 🛠️ Design in Action: Distribution Algorithms
How does the LB choose which VM gets the next request?
- **Round Robin**: Cycle through 1, 2, 3... simple but doesn't care if VM 1 is busy.
- **Least Connections**: Send the request to the VM that is currently doing the least amount of work. This is smarter and more common in production.

---

## 🛠️ Lab Activity

### 1. The LB Setup
```bash
cloudsim lb create --name prod-lb --type HTTP --backend-vm-id <vm1> --backend-vm-id <vm2>
```

### 2. The Traffic Simulation
Observe how the traffic is "split" between your two VMs. 
```bash
cloudsim simulate --lb-id <lb-id> --requests 200
```
*Observation: Check the `cloudsim-server` logs to see the distribution algorithm in action.*

### 3. The Autoscaling Trigger
Watch the **Horizontal Pod Autoscaler (HPA)** concept in action.
```bash
cloudsim autoscale-test --requests 1000 --max-instances 5
```
*Design Note: The system detects "Congestion" and triggers a "Scale Out" event to protect the system from crashing.*

---
<p align="right">
  <a href="module-4-networking.md"><b>Next: Module 4 - The Global Network ➡️</b></a>
</p>
