# 🗄️ Module 2: The Data Store

<p align="center">
  <img src="https://img.shields.io/badge/Module-2-7986CB?style=for-the-badge" alt="Module 2">
  <img src="https://img.shields.io/badge/Concept-Multi--Tenancy-9C27B0?style=for-the-badge" alt="Topic">
</p>

## 🔐 System Design Concept: Multi-Tenancy

**Multi-tenancy** is an architecture where a single instance of software serves multiple customers (tenants). 

CloudSim demonstrates this with:
- **Shared Cluster with Logical Separation**: When using Real PostgreSQL, many VMs might share the same Postgres instance, but CloudSim creates unique **Roles (Users)** and **Databases** for each one.
- **Data Privacy**: Tenant A cannot run `SELECT` on Tenant B's tables because they lack the credentials.

---

## 🛠️ Design in Action: Credential Mapping
In cloud architecture, the app server never knows the "Master Password" to the database. It is given a "Service Account".

### CloudSim handles this by:
1. Generating a random secure password for the VM.
2. Injecting that password into the VM's environment.
3. Granting permissions only to that VM's specific "Space".

---

## 🛠️ Lab Activity

1. **The Provisioning Command:**
   ```bash
   # This creates the logical isolation boundary
   cloudsim sql real-provision --space prod_team --username admin --database project_db
   ```

2. **The "Space" Challenge:**
   - Create a table in `space_1`.
   - Try to read it from a VM in `space_2`.
   - You will see that even though the physical hardware is the same, the **System Design** keeps them completely apart.

---
<p align="right">
  <a href="module-3-loadbalancer.md"><b>Next: Module 3 - High Availability ➡️</b></a>
</p>
