# 🧪 Module 0: The Cloud Laboratory

<p align="center">
  <img src="https://img.shields.io/badge/Module-0-7986CB?style=for-the-badge" alt="Module 0">
  <img src="https://img.shields.io/badge/Concept-Control_Plane-9C27B0?style=for-the-badge" alt="Topic">
</p>

## 🏛️ System Design Concept: Control Plane vs. Data Plane

In a distributed cloud system, we always separate **Intent** from **Execution**.

### 1. The Control Plane (CloudSim Server)
This is the "Brain". It manages the lifecycle of resources. When you run `cloudsim vm create`, you are sending a request to the Control Plane. It doesn't run your application code; it simply orchestrates the infrastructure.

### 2. The Data Plane (VM Workspaces)
This is where the "real work" happens. The Data Plane consists of the actual processes running your code, the ports serving traffic, and the database records.

---

## 🛠️ Design in Action: The Workspace
CloudSim uses a **Workspace Architecture**. This simulates how a Cloud Provider keeps customer data physically (or logically) separated on a disk.

- **Isolation**: Every VM you create gets a unique directory.
- **Persistence**: Global state is stored in `.cloudsim/`, while local state (VM files) is stored in `vms/`.

---

## 🛠️ Lab Activity
1. **Fire up the Control Plane:**
   ```bash
   cloudsim-server
   ```
   *Observation: Notice the initialization logs. This is the server setting up the Control API.*

2. **Check the Heartbeat:**
   ```bash
   cloudsim health
   ```
   *Observation: This is the simplest API call from a user terminal to the Cloud Controller.*

---
<p align="right">
  <a href="module-1-compute.md"><b>Next: Module 1 - Compute & Isolation ➡️</b></a>
</p>
