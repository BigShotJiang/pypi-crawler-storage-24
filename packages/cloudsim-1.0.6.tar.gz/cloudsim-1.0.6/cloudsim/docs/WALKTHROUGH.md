# 🎓 Cloud Architect Academy: The CloudSim Course

<p align="center">
  <img src="https://img.shields.io/badge/Course-System_Design_Fundamentals-8A2BE2?style=for-the-badge&logo=googlescholar" alt="Course Header">
  <img src="https://img.shields.io/badge/Difficulty-Junior_to_Senior-success?style=for-the-badge" alt="Difficulty">
</p>

Welcome to the **CloudSim Walkthrough**. This course is designed to teach you **System Design** by doing. You won't just learn commands; you'll learn the *why* behind modern cloud architecture.

---

## 🏛️ Core System Design Pillars covered:
- **Separation of Concerns**: Control Plane vs. Data Plane.
- **Scalability**: Vertical vs. Horizontal scaling.
- **High Availability**: Load Balancing & Fault Tolerance.
- **Security & Isolation**: Multi-Tenancy & Networking.
- **State Management**: Ephemeral storage vs. Persistent volumes.

---

## 🗺️ Course Map

| Module | System Design Concept | Focus |
| :--- | :--- | :--- |
| **0** | [The Lab Architecture](#module-0-the-laboratory) | Control Plane & Workspaces |
| **1** | [Compute & Isolation](#module-1-the-compute-engine) | Resource Provisioning & SSH |
| **2** | [Multi-Tenancy](#module-2-the-data-store) | DB Isolation & Space Mapping |
| **3** | [High Availability](#module-3-the-traffic-controller) | LB Algorithms & Autoscaling |
| **4** | [Global Networking](#module-4-the-global-network) | Public API Gateways & DNS |

---

## 🔬 Module 0: The Laboratory
**System Design Spotlight:** *The Control Plane vs. Data Plane*

In production clouds (AWS/GCP), there are two worlds:
1. **Control Plane**: The API you talk to (CloudSim Server). It doesn't run your app; it manages the things that do.
2. **Data Plane**: The actual servers (VM Workspace) where your code lives and runs.

### 🛠️ Lab Activity
1. **Start the Control Plane:** `cloudsim-server`
2. **Heartbeat Check:** `cloudsim health`

---

## 💻 Module 1: The Compute Engine
**System Design Spotlight:** *Resource Isolation & Ephemeral State*

How does a cloud provider keep your code from touching someone else's? 
- **Isolation**: CloudSim gives every VM its own folder and Python environment.
- **Ephemeral Storage**: In this lab, if you delete a VM, its workspace is wiped. This teaches you to never store permanent data on a web server!

### 🛠️ Lab Activity
1. **Provision a Node:** `cloudsim vm create --name web-1 ...`
2. **Inspect the Isolation:** `cloudsim ssh <vm-id>`

---

## 🗄️ Module 2: The Data Store
**System Design Spotlight:** *Multi-Tenancy & Data Security*

How do 1,000 customers use one database cluster?
- **Space Mapping**: CloudSim maps a "Space ID" to a specific database schema or SQLite file.
- **Access Control**: Users are restricted to their own Space, mimicking "Managed DB" permissions.

### 🛠️ Lab Activity
1. **Provision a Tenant DB:** `cloudsim sql provision`
2. **Simulate a Query:** `cloudsim sql execute`

---

## 🚦 Module 3: The Traffic Controller
**System Design Spotlight:** *LB Algorithms & Fault Tolerance*

What happens when the load is too high?
- **Round Robin**: Equal distribution of traffic.
- **Least Connections**: Routing to the "quietest" server.
- **Autoscaling**: Horizontal scaling based on real-time traffic spikes.

### 🛠️ Lab Activity
1. **Create an HA Cluster:** `cloudsim lb create ...`
2. **Stress Test & Scale:** `cloudsim autoscale-test`

---

## 🌐 Module 4: The Global Network
**System Design Spotlight:** *API Gateways & Reverse Proxies*

Your VMs are in a "Private Network". To reach the world, you need a Gateway.
- **Expose**: Mimics an API Gateway mapping a public domain to a private port.
- **DNS Sync**: Simulates how `hosts` files and DNS servers track moving targets.

### 🛠️ Lab Activity
1. **Public Exposure:** `cloudsim expose <vm-id>`
2. **API Call:** `cloudsim call <vm-id> /health`

---

<p align="center">
  <b>Way to go, Architect!</b><br>
  You've just built a fully functional cloud environment on your local machine.<br>
</p>

<p align="center">
  ☁️👷‍♂️⚙️
</p>
