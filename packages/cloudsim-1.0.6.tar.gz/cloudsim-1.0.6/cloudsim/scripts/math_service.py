from __future__ import annotations

import argparse
import json
import os
import math
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    import cloud_sdk
except ImportError:
    cloud_sdk = None


def _port_from_env(default_port: int) -> int:
    value = os.environ.get("PORT")
    if not value:
        return default_port
    try:
        return int(value)
    except ValueError:
        return default_port


def _compute_factorial(n: int) -> int:
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    if n > 200:
         # Limit to prevent DoS in simulation
        raise ValueError("Factorial limit is 200")
    if n == 0 or n == 1:
        return 1
    return math.factorial(n)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            self._send_json({"ok": True, "service": "math-service"})
            return
        
        if self.path == "/details":
            if cloud_sdk:
                try:
                    # Demonstrate getting details from backend via SDK (which queries SQL DB)
                    details = cloud_sdk.get_my_details()
                    self._send_json({"ok": True, "vm": details})
                except Exception as e:
                    self._send_json({"error": str(e)}, status=500)
            else:
                 self._send_json({"ok": False, "error": "SDK not available"}, status=503)
            return

        # Example: /api/factorial?n=5
        if self.path.startswith("/api/factorial"):
            try:
                # Basic query parsing
                query = self.path.split("?")[-1] if "?" in self.path else ""
                params = {}
                for qc in query.split("&"):
                    if "=" in qc:
                        k, v = qc.split("=", 1)
                        params[k] = v
                
                n_str = params.get("n")
                if n_str is None:
                     self._send_json({"error": "Missing parameter 'n'"}, status=400)
                     return

                n = int(n_str)
                result = _compute_factorial(n)
                self._send_json({"n": n, "factorial": str(result)})
            except ValueError as e:
                self._send_json({"error": str(e)}, status=400)
            except Exception as e:
                self._send_json({"error": "Invalid request"}, status=400)
            return

        self._send_text("math-service running. endpoints: /health, /api/factorial?n=10")

    def _send_json(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_text(self, text: str, status: int = 200) -> None:
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: object) -> None:
        print(fmt % args)


def main() -> None:
    parser = argparse.ArgumentParser(description="Math VM python script service")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()
    port = _port_from_env(args.port)
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"math-service listening on port {port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
