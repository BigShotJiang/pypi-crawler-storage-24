from __future__ import annotations

import argparse
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def _port_from_env(default_port: int) -> int:
    value = os.environ.get("PORT")
    if not value:
        return default_port
    try:
        return int(value)
    except ValueError:
        return default_port


class Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            payload = {"ok": True, "service": "sample-vm-script"}
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        body = b"sample-vm-script running\n"
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: object) -> None:
        print(fmt % args)


def main() -> None:
    parser = argparse.ArgumentParser(description="Sample VM python script service")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()
    port = _port_from_env(args.port)
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"sample-vm-script listening on port {port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
