from __future__ import annotations

import argparse
import urllib.error
import urllib.request
from pathlib import Path

from ..common import CliError, _request, get_repo_root
from ...services.dns_resolution_service import resolve_vm_dns_target

def _handle_expose(args: argparse.Namespace) -> None:
    # 1. Toggle exposure state in backend
    try:
        _request(args.base_url, "PUT", f"/api/vms/{args.id}/expose", {"exposed": True})
    except Exception as e:
        print(f"Warning: Could not sync exposure state with backend: {e}")

    repo_root = get_repo_root()
    target = resolve_vm_dns_target(args.id, repo_root, _request, args.base_url)

    print(f"[ok] VM {args.id} is now EXPOSED to public domain mapping.")
    print("Exposure Details:")
    print(f"  Public URL:   {target['publicUrl']}")
    print(f"  Local Target: {target['localBaseUrl']}")
    print("  Status:       UNBLOCKED")

def _handle_block(args: argparse.Namespace) -> None:
    try:
        _request(args.base_url, "PUT", f"/api/vms/{args.id}/expose", {"exposed": False})
        print(f"[OK] VM {args.id} access has been BLOCKED.")
        print(f"    Public domain mapping will now return 403 Forbidden.")
    except Exception as e:
        raise CliError(f"Failed to block VM: {e}")

def _handle_call(args: argparse.Namespace) -> None:
    repo_root = get_repo_root()
    try:
        target = resolve_vm_dns_target(args.id, repo_root, _request, args.base_url)
    except Exception:
        raise CliError(f"Could not resolve port for VM {args.id}")

    public_host = target["publicHost"]
    path = args.path if args.path.startswith("/") else f"/{args.path}"

    # We call localhost but set the Host header to simulation endpoint
    url = f"{target['localBaseUrl']}{path}"
    headers = {"Host": public_host}

    print(f"Calling {public_host}{path} ...")

    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as response:
            print(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        print(f"Error {e.code}: {e.read().decode('utf-8')}")
    except Exception as e:
        print(f"Failed to connect: {e}")

def _handle_dns_sync(args: argparse.Namespace) -> None:
    try:
        res = _request(args.base_url, "GET", "/api/dns/records")
        records = res.get("records", [])
        dns_lines = [f"127.0.0.1 {rec['domain']}" for rec in records]

        # Mock-admin mode: simulate successful sync without OS admin.
        if getattr(args, "admin_pass", ""):
            if args.admin_pass != "123":
                raise CliError("Invalid admin password for mock dns-sync.")

            mock_hosts_path = Path(args.mock_hosts_file).resolve()
            mock_hosts_path.parent.mkdir(parents=True, exist_ok=True)
            mock_content = [
                "# START CLOUDSIM DNS (MOCK)",
                *dns_lines,
                "# END CLOUDSIM DNS (MOCK)",
                "",
            ]
            mock_hosts_path.write_text("\n".join(mock_content), encoding="utf-8")
            print("[MOCK-ADMIN] DNS sync simulated successfully.")
            print(f"[MOCK-ADMIN] Entries written to: {mock_hosts_path}")
            for line in dns_lines:
                print(line)
            return
        
        # Windows hosts file path
        hosts_path = Path(r"C:\Windows\System32\drivers\etc\hosts")
        if not hosts_path.exists():
             raise CliError("Hosts file not found at expected location.")

        content = ""
        try:
             content = hosts_path.read_text()
        except Exception as e:
             raise CliError(f"Failed to read hosts file: {e}")

        lines = content.splitlines()
        new_lines = []
        in_block = False
        
        for line in lines:
            if "# START CLOUDSIM DNS" in line:
                in_block = True
                continue
            if "# END CLOUDSIM DNS" in line:
                in_block = False
                continue
            if not in_block:
                new_lines.append(line)
        
        new_lines.append("# START CLOUDSIM DNS")
        for line in dns_lines:
            new_lines.append(line)
        new_lines.append("# END CLOUDSIM DNS")
        
        new_content = "\n".join(new_lines) + "\n"
        
        try:
            hosts_path.write_text(new_content)
            print("Successfully synced DNS records to hosts file.")
        except PermissionError:
            print("[ERROR] Permission Denied: You must run this command as Administrator (Elevated) to update the hosts file.")
            print("Tip: use mock mode if you want simulation only:")
            print("  cloudsim dns-sync --admin-pass 123")
            print("\nSuggested manual entries for your hosts file:")
            for line in dns_lines:
                print(line)
    except Exception as e:
        raise CliError(f"DNS sync failed: {e}")

