from __future__ import annotations

import argparse

from ..common import _print, _request

def _handle_health(args: argparse.Namespace) -> None:
    response = _request(args.base_url, "GET", "/api/health")
    summary = {
        "ok": response.get("ok"),
        "service": response.get("service")
    }
    _print(summary)

def _handle_state(args: argparse.Namespace) -> None:
    response = _request(args.base_url, "GET", "/api/state")
    state = response.get("state", {})
    
    # Always show summary by default unless we add a flag later
    # User said "I dont want whole state to be printed anywhere"
    summary = {
        "ok": response.get("ok", True),
        "vmCount": len(state.get("vms", [])),
        "lbCount": len(state.get("lbs", [])),
        "runningVmCount": sum(1 for vm in state.get("vms", []) if vm.get("status") == "running"),
        "activeLbCount": sum(1 for lb in state.get("lbs", []) if lb.get("status") == "active"),
    }
    _print(summary)

