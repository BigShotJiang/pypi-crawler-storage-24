from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from ..common import CliError, _print, _request, get_repo_root

def _handle_vm_create(args: argparse.Namespace) -> None:
    payload: dict[str, Any] = {
        "name": args.name,
        "region": args.region,
        "machineType": args.machine_type,
        "image": args.image,
        "backendProfileId": args.backend_profile_id,
        "runtimeMode": args.runtime_mode,
        "scriptPath": args.script_path if args.runtime_mode == "python_script" else "",
    }
    
    print("Initializing VM creation...", end="", flush=True)
    time.sleep(0.6)
    print("\r[OK] Validated configuration parameters          ")

    print(f"Provisioning resources in {args.region}...", end="", flush=True)
    time.sleep(0.8)
    print(f"\r[OK] Allocated {args.machine_type} instance in {args.region}")

    print("Setting up workspace...", end="", flush=True)
    # Perform the actual API call
    response = _request(args.base_url, "POST", "/api/vms", payload)
    time.sleep(0.8) # Simulate file copy time
    
    # Check if successful before continuing success messages
    if "state" in response and "vms" in response["state"] and response["state"]["vms"]:
        print("\r[OK] Created isolated workspace and injected SDK")
        
        print("Finalizing global state registration...", end="", flush=True)
        time.sleep(0.6)
        print("\r[OK] State recorded in global DB               ")
        print("\nVM provisioning complete.")
        
        vm = response["state"]["vms"][0]
        summary = {
            "id": vm.get("id"),
            "name": vm.get("name"),
            "status": vm.get("status"),
            "reservedPort": vm.get("reservedPort"),
            "scriptStatus": vm.get("scriptStatus"),
            "workspacePath": vm.get("_vmDir", "rel/backend/vms/..."),
        }
        _print(summary)
    else:
        # If API failed (returned error inside JSON structure or unexpected), print raw response
        print("\r[ERR] Provisioning failed                    ")
        _print(response)

def _handle_vm_list(args: argparse.Namespace) -> None:
    response = _request(args.base_url, "GET", "/api/state")
    vms = response.get("state", {}).get("vms", [])
    result = [
        {"id": vm.get("id"), "name": vm.get("name"), "status": vm.get("status")} for vm in vms
    ]
    _print(result)

def _handle_vm_delete(args: argparse.Namespace) -> None:
    _request(args.base_url, "DELETE", f"/api/vms/{args.id}")
    _print({"ok": True, "deletedVmId": args.id})

def _handle_vm_update(args: argparse.Namespace) -> None:
    _request(args.base_url, "PUT", f"/api/vms/{args.id}/script", {"scriptPath": args.script_path})
    _print({"ok": True, "updatedVmId": args.id, "scriptPath": args.script_path})

def _handle_vm_details(args: argparse.Namespace) -> None:
    repo_root = get_repo_root()
    db_path = repo_root / "vms" / args.id / "vm_state.db"
    
    if not db_path.exists():
        print(f"Local DB not found at {db_path}. Using API...")
        try:
            _print(_request(args.base_url, "GET", f"/api/vms/{args.id}"))
        except:
            print("VM not found.")
        return

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM info").fetchall()
        
        data = {}
        for row in rows:
            key = row["key"]
            val = row["value"]
            try:
                parsed = json.loads(val)
                data[key] = parsed
            except:
                data[key] = val
        conn.close()
        _print(data)
    except Exception as e:
        raise CliError(f"Failed to read local VM state: {e}")

def _handle_cp(args: argparse.Namespace) -> None:
    repo_root = get_repo_root()
    vm_dir = repo_root / "vms" / args.vm_id
    if not vm_dir.exists():
        raise CliError(f"VM workspace not found for ID: {args.vm_id}")
    
    src_path = Path(args.src).resolve()
    if not src_path.exists():
        raise CliError(f"Source file not found: {args.src}")
        
    dest_path = vm_dir / args.dest
    
    try:
        if src_path.is_dir():
            if dest_path.exists():
                shutil.rmtree(dest_path)
            shutil.copytree(src_path, dest_path)
            print(f"Copied directory {src_path.name} to VM {args.vm_id}:{args.dest}")
        else:
            if dest_path.is_dir():
                 dest_path = dest_path / src_path.name
            
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_path, dest_path)
            print(f"Copied file {src_path.name} to VM {args.vm_id}:{args.dest}")
    except Exception as e:
        raise CliError(f"Copy failed: {e}")

def _handle_ssh(args: argparse.Namespace) -> None:
    repo_root = get_repo_root()
    vm_dir = repo_root / "vms" / args.id
    if not vm_dir.exists():
        raise CliError(f"VM workspace not found for ID: {args.id}")
        
    venv_dir = vm_dir / "venv"
    if not venv_dir.exists():
        print("Initializing isolated environment (venv)...")
        subprocess.check_call([sys.executable, "-m", "venv", str(venv_dir)])
    
    print(f"Opening shell in VM {args.id} workspace...")
    
    if os.name == "nt":
        # Build environment for the child shell
        env = os.environ.copy()
        
        # 1. Manual Venv Activation
        venv_dir_path = str(venv_dir)
        scripts_dir = str(venv_dir / "Scripts")
        env["VIRTUAL_ENV"] = venv_dir_path
        env["PATH"] = f"{scripts_dir};{env.get('PATH', '')}"
        env.pop("PYTHONHOME", None)
        
        # 2. Add CloudSim paths
        repo_path_str = str(repo_root)
        codex_path_str = str(repo_root.parent)
        env["PATH"] = f"{repo_path_str};{codex_path_str};{env['PATH']}"

        # 3. VM shell context (used for policy checks like SQL access binding).
        env["CLOUDSIM_IN_VM_SHELL"] = "1"
        env["CLOUDSIM_VM_ID"] = str(args.id)
        env["CLOUDSIM_VM_SPACE"] = f"vm_{args.id}"
        
        # Add visual hint to prompt
        env["PROMPT"] = f"(vm-{args.id}) $P$G"
        
        # Run shell in current console
        subprocess.run(["cmd", "/k", "echo *** CloudSim VM Shell Connected ***"], env=env, cwd=vm_dir)
    else:
        print("SSH emulation started (type 'exit' to quit)")
        # For Unix, we also prepend the PATH
        env = os.environ.copy()
        env["PATH"] = f"{repo_root}:{env.get('PATH', '')}"
        subprocess.run(["bash"], cwd=vm_dir, env=env)

