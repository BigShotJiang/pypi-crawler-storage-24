﻿from __future__ import annotations

import argparse
import itertools
import time
from typing import Any, Callable

from ..common import CliError, _request


def _prompt_yes_no(question: str, default_yes: bool = True) -> bool:
    suffix = " [Y/n]: " if default_yes else " [y/N]: "
    raw = input(question + suffix).strip().lower()
    if not raw:
        return default_yes
    return raw in {"y", "yes"}


def _find_running_vm_count_for_lb(state: dict[str, Any], lb_id: str) -> int:
    lb = next((item for item in state.get("lbs", []) if item.get("id") == lb_id), None)
    if not lb:
        return 0
    vm_ids = set(lb.get("backendVmIds", []))
    return sum(1 for vm in state.get("vms", []) if vm.get("id") in vm_ids and vm.get("status") == "running")


def _find_running_autoscaled_count_for_lb(state: dict[str, Any], lb_id: str) -> int:
    lb = next((item for item in state.get("lbs", []) if item.get("id") == lb_id), None)
    if not lb:
        return 0
    vm_ids = set(lb.get("backendVmIds", []))
    return sum(
        1
        for vm in state.get("vms", [])
        if vm.get("id") in vm_ids
        and vm.get("status") == "running"
        and vm.get("autoScaled")
        and vm.get("autoScaledForLbId") == lb_id
    )


def _wait_for_state(
    args: argparse.Namespace,
    condition: Callable[[dict[str, Any]], bool],
    label: str,
    timeout_seconds: float = 20.0,
    poll_seconds: float = 0.5,
) -> dict[str, Any]:
    spinner = itertools.cycle(["|", "/", "-", "\\"])
    deadline = time.time() + timeout_seconds
    last_state: dict[str, Any] = {}
    while time.time() < deadline:
        response = _request(args.base_url, "GET", "/api/state")
        state = response.get("state", {})
        last_state = state
        if condition(state):
            print(f"\r{label} ... done                ")
            return state
        print(f"\r{label} ... {next(spinner)}", end="", flush=True)
        time.sleep(poll_seconds)
    print("")
    raise CliError(f"Timeout while waiting: {label}")


def _animate_autoscale_spinup(
    args: argparse.Namespace,
    lb_id: str,
    autoscaled_now: int,
    target_total: int,
    step_delay_seconds: float,
) -> dict[str, Any]:
    spinner = itertools.cycle(["|", "/", "-", "\\"])
    deadline = time.time() + max(30.0, autoscaled_now * (step_delay_seconds + 3.0))
    next_stage_at = time.time() + 0.1
    required_autoscaled = 0
    last_state: dict[str, Any] = {}
    announced_vms: set[str] = set()

    print("\n[*] COMPUTE ENGINE: Signal received. Initializing lifecycle events...")

    while time.time() < deadline:
        response = _request(args.base_url, "GET", "/api/state")
        state = response.get("state", {})
        last_state = state

        lb = next((item for item in state.get("lbs", []) if item.get("id") == lb_id), None)
        lb_vm_ids = set(lb.get("backendVmIds", [])) if lb else set()

        running_total = _find_running_vm_count_for_lb(state, lb_id)
        running_autoscaled = _find_running_autoscaled_count_for_lb(state, lb_id)

        # Notify when an instance becomes ready
        for vm in state.get("vms", []):
            v_id = vm.get("id")
            if not v_id:
                continue
            if v_id in lb_vm_ids and vm.get("status") == "running" and v_id not in announced_vms:
                announced_vms.add(v_id)
                prefix = "[AUTO]" if vm.get("autoScaled") else "[BASE]"
                print(f"\r  {prefix} Instance {v_id} is healthy. (port {vm.get('reservedPort')})        ")

        now = time.time()
        if autoscaled_now > 0 and now >= next_stage_at and required_autoscaled < autoscaled_now:
            required_autoscaled += 1
            next_stage_at = now + step_delay_seconds

        stage_met = running_autoscaled >= required_autoscaled
        total_met = running_total >= target_total

        progress = (running_total / target_total) if target_total > 0 else 0
        bar_len = 20
        filled = int(progress * bar_len)
        bar = "#" * filled + "." * (bar_len - filled)

        status_text = (
            f"\r{next(spinner)} [{bar}] Scaling compute footprint... "
            f"({running_total}/{target_total} active) "
        )
        print(status_text, end="", flush=True)

        if stage_met and total_met and required_autoscaled >= autoscaled_now:
            print(f"\r[OK] [{bar}] Fleet stabilization complete. ({target_total}/{target_total} active)          \n")
            return state
        time.sleep(0.15)

    print("")
    raise CliError("Fleet took too long to stabilize.")


def _handle_autoscale_test(args: argparse.Namespace) -> None:
    print("\n" + "=" * 60)
    print("CLOUDSIM AUTOSCALE LABORATORY".center(60))
    print("=" * 60)
    print("This scenario simulates a high-traffic event to trigger autoscaling.")

    if not _prompt_yes_no("Launch infrastructure simulation?", default_yes=True):
        print("Cancelled.")
        return

    state = _request(args.base_url, "GET", "/api/state").get("state", {})
    constants = state.get("constants", {})
    backend_profiles = state.get("backendProfiles", [])
    if not backend_profiles:
        raise CliError("No backend profiles available from server state.")

    region = constants.get("vmRegions", ["us-central1"])[0]
    machine = constants.get("vmMachineTypes", ["e2-standard-2"])[0]
    image = constants.get("vmImages", ["Ubuntu 22.04 LTS"])[0]
    backend_profile_id = backend_profiles[0].get("id", "python-fastapi")
    endpoint_key = "GET /health"

    print(f"\n[*] Provisioning static resources in {region}...")
    vm_name = f"as-base-{int(time.time())}"
    vm_payload = {
        "name": vm_name,
        "region": region,
        "machineType": machine,
        "image": image,
        "backendProfileId": backend_profile_id,
        "runtimeMode": "profile",
        "scriptPath": "",
    }
    vm_resp = _request(args.base_url, "POST", "/api/vms", vm_payload)
    base_vm_id = vm_resp["state"]["vms"][0]["id"]

    _wait_for_state(
        args,
        lambda s: any(vm.get("id") == base_vm_id and vm.get("status") == "running" for vm in s.get("vms", [])),
        "Wait: Base VM boot",
    )

    lb_name = f"as-lb-{int(time.time())}"
    lb_payload = {
        "name": lb_name,
        "type": "HTTP(S)",
        "region": constants.get("lbRegions", ["global"])[0],
        "distributionAlgorithmId": "round_robin",
        "backendVmIds": [base_vm_id],
        "autoScaleProfileId": "aggressive",
        "queueServiceTier": "disabled",
        "cloudArmorPolicyId": "relaxed",
    }
    lb_resp = _request(args.base_url, "POST", "/api/load-balancers", lb_payload)
    lb_id = lb_resp["state"]["lbs"][0]["id"]

    _wait_for_state(
        args,
        lambda s: any(lb.get("id") == lb_id and lb.get("status") == "active" for lb in s.get("lbs", [])),
        "Wait: LB Propagation",
    )

    print(f"\n[!] READY: Load Balancer {lb_id} is live with 1 backend.")
    if not _prompt_yes_no("Initiate traffic spike?", default_yes=True):
        print("Test aborted.")
        return

    print(f"\n[*] BURST: Sending {args.requests} requests to {lb_id}...")
    simulate_payload = {
        "lbId": lb_id,
        "endpointKey": endpoint_key,
        "requests": args.requests,
        "clientId": "autoscale-lab-client",
    }
    sim_resp = _request(args.base_url, "POST", "/api/simulate", simulate_payload)
    traffic = sim_resp.get("state", {}).get("lastTrafficResult", {}) or {}
    autoscaled_now = int(traffic.get("autoscaledCount", 0))
    target_total = min(args.max_instances, 1 + max(0, autoscaled_now))

    print(f"[*] RESPONSE: Autoscaler detected overload. Triggering +{autoscaled_now} instances.")

    state = _animate_autoscale_spinup(
        args=args,
        lb_id=lb_id,
        autoscaled_now=autoscaled_now,
        target_total=target_total,
        step_delay_seconds=args.spinup_delay,
    )

    print("=" * 60)
    print("TRAFFIC DISTRIBUTION ANALYSIS".center(60))
    print("-" * 60)
    vm_usage = traffic.get("vmUsage", {})
    total_served = int(traffic.get("served", 0) or 0)
    print(f"  Total Requests Processed: {total_served}")
    print(f"  Average Latency:          {traffic.get('avgLatencyMs')}ms")
    print(f"  Distribution Algorithm:   {traffic.get('distributionAlgorithmId')}")
    print("\n  INSTANCE RELAY MAP:")

    lb = next((item for item in state.get("lbs", []) if item.get("id") == lb_id), None)
    vm_ids = lb.get("backendVmIds", []) if lb else []

    for v_id in vm_ids:
        vm = next((v for v in state.get("vms", []) if v.get("id") == v_id), None)
        if not vm:
            continue
        count = int(vm_usage.get(v_id, 0) or 0)
        share = (count / total_served * 100) if total_served > 0 else 0
        tag = "[AUTO]" if vm.get("autoScaled") else "[BASE]"
        status_mark = "*" if vm.get("status") == "running" else "!"
        bar = "#" * int(share / 5)
        print(f"    {status_mark} {v_id} {tag:<6} | {count:4} reqs ({share:4.1f}%) {bar}")
    print("=" * 60 + "\n")

    if _prompt_yes_no("Destroy ephemeral resources?", default_yes=True):
        current_state = _request(args.base_url, "GET", "/api/state").get("state", {})
        lb_current = next((item for item in current_state.get("lbs", []) if item.get("id") == lb_id), None)
        lb_vm_ids = set(lb_current.get("backendVmIds", [])) if lb_current else set()
        autoscaled = [
            vm
            for vm in current_state.get("vms", [])
            if vm.get("id") in lb_vm_ids
            and vm.get("autoScaled")
            and vm.get("autoScaledForLbId") == lb_id
        ]
        autoscaled_ids = [vm.get("id") for vm in autoscaled if vm.get("id")]
        for vm_id in autoscaled_ids:
            _request(args.base_url, "DELETE", f"/api/vms/{vm_id}")

        time.sleep(0.4)
        verify_state = _request(args.base_url, "GET", "/api/state").get("state", {})
        remaining_ids = {
            vm.get("id")
            for vm in verify_state.get("vms", [])
            if vm.get("autoScaled") and vm.get("autoScaledForLbId") == lb_id
        }
        retry_ids = [vm_id for vm_id in autoscaled_ids if vm_id in remaining_ids]
        for vm_id in retry_ids:
            _request(args.base_url, "DELETE", f"/api/vms/{vm_id}")

        final_state = _request(args.base_url, "GET", "/api/state").get("state", {})
        final_remaining = [
            vm.get("id")
            for vm in final_state.get("vms", [])
            if vm.get("autoScaled") and vm.get("autoScaledForLbId") == lb_id
        ]
        destroyed_count = len(autoscaled_ids) - len(final_remaining)
        print(f"Destroyed {destroyed_count} auto-scaled VM(s).")
        if final_remaining:
            print(f"Warning: still present auto-scaled VM(s): {', '.join(final_remaining)}")
    else:
        print("Kept auto-scaled VM(s) running.")

    if _prompt_yes_no("Destroy temporary LB and base VM too?", default_yes=False):
        _request(args.base_url, "DELETE", f"/api/load-balancers/{lb_id}")
        _request(args.base_url, "DELETE", f"/api/vms/{base_vm_id}")
        print("Destroyed temporary LB and base VM.")
