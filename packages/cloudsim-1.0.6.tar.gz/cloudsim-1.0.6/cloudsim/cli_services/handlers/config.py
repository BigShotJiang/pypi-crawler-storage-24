from __future__ import annotations

import argparse
import os
from pathlib import Path

import cloudsim
from cloudsim.paths import (
    autoscale_vms_dir,
    ensure_state_dir,
    read_global_config,
    vms_dir,
    workspace_root,
    write_global_config,
)
from cloudsim.web.env_loader import load_env_file

from ..common import CliError, _print


def _package_env_example_path() -> Path:
    return Path(cloudsim.__file__).resolve().parent / ".env.example"


def _render_env_from_example(example_text: str, workspace: Path) -> str:
    lines = example_text.splitlines()

    def is_ws_line(line: str) -> bool:
        return line.strip().startswith("CLOUDSIM_WORKSPACE=")

    out: list[str] = []
    replaced = False
    for line in lines:
        if is_ws_line(line):
            out.append(f"CLOUDSIM_WORKSPACE={workspace}")
            replaced = True
        else:
            out.append(line)

    if not replaced:
        out.append(f"CLOUDSIM_WORKSPACE={workspace}")

    return "\n".join(out).rstrip() + "\n"


def _handle_config_init(args: argparse.Namespace) -> None:
    ws = (args.workspace or "").strip()
    if ws:
        workspace = Path(ws).expanduser().resolve()
    else:
        workspace = workspace_root()

    # Ensure this process uses the chosen workspace immediately (even if user didn't export env yet).
    os.environ["CLOUDSIM_WORKSPACE"] = str(workspace)

    workspace.mkdir(parents=True, exist_ok=True)

    # Create expected top-level dirs.
    ensure_state_dir()
    vms_dir().mkdir(parents=True, exist_ok=True)
    autoscale_vms_dir().mkdir(parents=True, exist_ok=True)

    env_path = workspace / ".env"
    if env_path.exists() and not args.force:
        raise CliError(f"{env_path} already exists. Use --force to overwrite.")

    example_path = _package_env_example_path()
    if not example_path.exists():
        raise CliError(f"Missing packaged env example at {example_path}")

    rendered = _render_env_from_example(example_path.read_text(encoding="utf-8"), workspace)
    env_path.write_text(rendered, encoding="utf-8")

    # Load it for this process so immediate follow-up commands work.
    load_env_file(env_path)

    default_cfg_path = ""
    if not getattr(args, "no_default", False):
        cfg = read_global_config()
        if not isinstance(cfg, dict):
            cfg = {}
        cfg["workspace"] = str(workspace)
        default_cfg_path = str(write_global_config(cfg))

    _print(
        {
            "ok": True,
            "workspace": str(workspace),
            "envFile": str(env_path),
            "defaultConfig": default_cfg_path,
            "next": {
                "windowsPowerShellSession": f"$env:CLOUDSIM_WORKSPACE = '{workspace}'",
                "windowsPermanentUser": f'setx CLOUDSIM_WORKSPACE "{workspace}"',
                "macLinuxSession": f'export CLOUDSIM_WORKSPACE="{workspace}"',
            },
        }
    )


def _mask(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 4:
        return "****"
    return value[:2] + "****" + value[-2:]


def _handle_config_show(args: argparse.Namespace) -> None:
    # Show how workspace was resolved.
    ws_env = (os.environ.get("CLOUDSIM_WORKSPACE") or "").strip()
    cfg = read_global_config()
    ws_cfg = (cfg.get("workspace") or "").strip() if isinstance(cfg, dict) else ""

    # Prefer reporting the *stable* source a new user relies on.
    # If both env and default config exist but disagree, treat env as an override.
    if ws_env and ws_cfg and Path(ws_env).expanduser().resolve() != Path(ws_cfg).expanduser().resolve():
        source = "env_override"
    elif ws_cfg:
        source = "default_config"
    elif ws_env:
        source = "env"
    else:
        source = "cwd"

    ws = workspace_root()
    env_path = ws / ".env"

    # Parse .env without mutating env (for display).
    env_keys: list[str] = []
    if env_path.exists():
        for raw_line in env_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            k = line.split("=", 1)[0].strip()
            if k:
                env_keys.append(k)

    # Load it for this process too (safe: env_loader won't override explicit env vars).
    load_env_file(env_path)

    def getenv(k: str) -> str:
        return (os.environ.get(k) or "").strip()

    pg = {
        "host": getenv("CLOUDSIM_PG_HOST"),
        "port": getenv("CLOUDSIM_PG_PORT"),
        "adminUser": getenv("CLOUDSIM_PG_ADMIN_USER"),
        "adminPassword": _mask(getenv("CLOUDSIM_PG_ADMIN_PASSWORD")),
        "adminDb": getenv("CLOUDSIM_PG_ADMIN_DB"),
    }

    _print(
        {
            "ok": True,
            "workspaceSource": source,
            "workspace": str(ws),
            "envFile": str(env_path),
            "envFileExists": env_path.exists(),
            "envFileKeys": sorted(list(set(env_keys))),
            "postgresConfigured": all(
                [
                    pg["host"],
                    pg["port"],
                    pg["adminUser"],
                    getenv("CLOUDSIM_PG_ADMIN_PASSWORD"),
                    pg["adminDb"],
                ]
            ),
            "postgres": pg,
        }
    )
