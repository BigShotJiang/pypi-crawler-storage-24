﻿from __future__ import annotations

import argparse
import json
import os
import subprocess
import sqlite3
from pathlib import Path
from typing import Any

from ..common import _parse_json, _print, _request, get_repo_root
from cloudsim import paths

_PROFILE_PATH = paths.cloudsql_profiles_path()

def _vm_dir_for(vm_id: str) -> Path:
    repo_root = get_repo_root()
    candidates = [
        repo_root / "vms" / vm_id,
        repo_root / "autoscale-vms" / vm_id,
    ]
    for c in candidates:
        if c.exists():
            return c
    # Default to vms/<id> even if missing, to allow provision to create it.
    return repo_root / "vms" / vm_id


def _local_sqlite_path(vm_dir: Path) -> Path:
    return vm_dir / "vm_sqlite.db"


def _ensure_local_sqlite(vm_dir: Path) -> Path:
    vm_dir.mkdir(parents=True, exist_ok=True)
    db_path = _local_sqlite_path(vm_dir)
    conn = sqlite3.connect(db_path)
    try:
        conn.execute("CREATE TABLE IF NOT EXISTS _meta(key TEXT PRIMARY KEY, value TEXT)")
        conn.commit()
    finally:
        conn.close()
    return db_path


def _local_sql_execute(vm_dir: Path, query: str, params: Any | None) -> dict[str, Any]:
    db_path = _ensure_local_sqlite(vm_dir)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    try:
        if params is None:
            cur.execute(query)
        else:
            cur.execute(query, params)
        if query.strip().lower().startswith("select"):
            rows = cur.fetchall()
            cols = [d[0] for d in (cur.description or [])]
            return {"columns": cols, "rows": rows, "rowCount": len(rows), "dbPath": str(db_path)}
        conn.commit()
        return {"rowCount": cur.rowcount, "dbPath": str(db_path)}
    finally:
        conn.close()


def _local_sql_run_script(vm_dir: Path, script: str) -> dict[str, Any]:
    db_path = _ensure_local_sqlite(vm_dir)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    executed = 0
    try:
        statements = [s.strip() for s in script.split(";") if s.strip()]
        for stmt in statements:
            cur.execute(stmt)
            executed += 1
        conn.commit()
        return {"executed": executed, "dbPath": str(db_path)}
    finally:
        conn.close()


def _resolve_vm_id(args: argparse.Namespace) -> str | None:
    if getattr(args, "vm_id", None):
        return str(args.vm_id).strip()
    if os.environ.get("CLOUDSIM_IN_VM_SHELL") == "1":
        vm_id = os.environ.get("CLOUDSIM_VM_ID", "").strip()
        if vm_id:
            return vm_id
    return None


def _sql_mode(args: argparse.Namespace) -> str:
    mode = getattr(args, "mode", "auto") or "auto"
    if mode not in {"auto", "local", "api"}:
        return "auto"
    return mode


def _load_profiles() -> dict[str, Any]:
    if not _PROFILE_PATH.exists():
        return {}
    try:
        return json.loads(_PROFILE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_profiles(data: dict[str, Any]) -> None:
    _PROFILE_PATH.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def _resolve_space(args: argparse.Namespace) -> str:
    # Precedence:
    # 1) explicit --space
    # 2) explicit --vm-id (maps to vm_<id>)
    # 3) VM shell context (maps to vm_<CLOUDSIM_VM_ID>)
    if getattr(args, "space", None):
        return str(args.space).strip()
    if getattr(args, "vm_id", None):
        return f"vm_{str(args.vm_id).strip()}"
    if os.environ.get("CLOUDSIM_IN_VM_SHELL") == "1":
        vm_id = os.environ.get("CLOUDSIM_VM_ID", "").strip()
        if vm_id:
            return f"vm_{vm_id}"
    raise ValueError("space not provided. Use --vm-id <id> or --space <space> (or run inside cloudsim ssh).")


def _handle_sql_status(args: argparse.Namespace) -> None:
    _print(_request(args.base_url, "GET", "/api/sql/status"))


def _handle_sql_execute(args: argparse.Namespace) -> None:
    vm_id = _resolve_vm_id(args)
    mode = _sql_mode(args)
    params = _parse_json(args.params_json, "sql params JSON") if args.params_json.strip() else None

    if mode in {"local", "auto"} and vm_id:
        vm_dir = _vm_dir_for(vm_id)
        result = _local_sql_execute(vm_dir, args.query, params)
        _print({"ok": True, "mode": "local-sqlite", "vmId": vm_id, "result": result})
        return

    payload: dict[str, Any] = {
        "query": args.query,
        "params": params,
        "username": args.username,
        "password": args.password,
        "space": args.space,
    }
    _print(_request(args.base_url, "POST", "/api/sql/execute", payload))


def _handle_sql_create_account(args: argparse.Namespace) -> None:
    payload = {
        "username": args.username,
        "password": args.password,
        "space": args.space,
        "role": args.role,
    }
    _print(_request(args.base_url, "POST", "/api/sql/accounts", payload))


def _handle_sql_run_script(args: argparse.Namespace) -> None:
    script = Path(args.file).read_text(encoding="utf-8")
    vm_id = _resolve_vm_id(args)
    mode = _sql_mode(args)

    if mode in {"local", "auto"} and vm_id:
        vm_dir = _vm_dir_for(vm_id)
        result = _local_sql_run_script(vm_dir, script)
        _print({"ok": True, "mode": "local-sqlite", "vmId": vm_id, "result": result})
        return

    payload = {
        "script": script,
        "username": args.username,
        "password": args.password,
        "space": args.space,
    }
    _print(_request(args.base_url, "POST", "/api/sql/script", payload))


def _handle_sql_provision(args: argparse.Namespace) -> None:
    vm_id = _resolve_vm_id(args)
    if not vm_id:
        raise ValueError("sql provision requires VM context. Use --vm-id <id> or run inside cloudsim ssh.")
    vm_dir = _vm_dir_for(vm_id)
    db_path = _ensure_local_sqlite(vm_dir)
    _print({"ok": True, "mode": "local-sqlite", "vmId": vm_id, "dbPath": str(db_path)})


def _handle_sql_change_password(args: argparse.Namespace) -> None:
    payload = {
        "username": args.username,
        "space": args.space,
        "oldPassword": args.old_password,
        "newPassword": args.new_password,
    }
    _print(_request(args.base_url, "POST", "/api/sql/change-password", payload))


def _handle_sql_set_role(args: argparse.Namespace) -> None:
    payload = {
        "username": args.username,
        "space": args.space,
        "role": args.role,
        "adminUsername": args.admin_username,
        "adminPassword": args.admin_password,
    }
    _print(_request(args.base_url, "POST", "/api/sql/set-role", payload))


def _handle_sql_real_status(args: argparse.Namespace) -> None:
    _print(_request(args.base_url, "GET", "/api/sql/real/status"))


def _handle_sql_real_provision(args: argparse.Namespace) -> None:
    space = _resolve_space(args)
    if os.environ.get("CLOUDSIM_IN_VM_SHELL") == "1" and not getattr(args, "force", False):
        expected = os.environ.get("CLOUDSIM_VM_SPACE", "")
        if expected and str(space).strip().lower() != expected.strip().lower():
            raise ValueError(
                f'This VM shell is bound to space "{expected}". Refusing to provision space "{space}". '
                f"Use --force to override."
            )
    payload = {
        "space": space,
        "username": args.username,
        "password": args.password,
        "database": args.database,
    }
    response = _request(args.base_url, "POST", "/api/sql/real/provision", payload)
    result = response.get("result", {})
    space_key = str(result.get("space") or args.space).strip().lower()
    if space_key:
        profiles = _load_profiles()
        profiles[space_key] = {
            "host": result.get("host"),
            "port": result.get("port"),
            "username": result.get("username"),
            "password": result.get("password"),
            "database": result.get("database"),
        }
        _save_profiles(profiles)
    _print(response)


def _handle_sql_real_change_password(args: argparse.Namespace) -> None:
    payload = {
        "username": args.username,
        "oldPassword": args.old_password,
        "newPassword": args.new_password,
        "database": args.database,
    }
    _print(_request(args.base_url, "POST", "/api/sql/real/change-password", payload))


def _handle_sql_real_connect(args: argparse.Namespace) -> None:
    space = _resolve_space(args)
    if os.environ.get("CLOUDSIM_IN_VM_SHELL") == "1" and not getattr(args, "force", False):
        expected = os.environ.get("CLOUDSIM_VM_SPACE", "")
        if expected and str(space).strip().lower() != expected.strip().lower():
            raise ValueError(
                f'This VM shell is bound to space "{expected}". Refusing to connect to space "{space}". '
                f"Use --force to override."
            )
    profiles = _load_profiles()
    key = str(space).strip().lower()
    profile = profiles.get(key)
    if not profile:
        raise ValueError(
            f'No saved profile for space "{space}". Run: cloudsim sql real-provision --space {space}'
        )

    cmd = [
        "psql",
        "-h",
        str(profile.get("host", "127.0.0.1")),
        "-p",
        str(profile.get("port", 5432)),
        "-U",
        str(profile.get("username")),
        "-d",
        str(profile.get("database")),
    ]
    env = dict(**os.environ)
    env["PGPASSWORD"] = str(profile.get("password", ""))
    print("Launching:", " ".join(cmd))
    subprocess.run(cmd, env=env, check=False)


def _handle_mongo_status(args: argparse.Namespace) -> None:
    _print(_request(args.base_url, "GET", "/api/mongo/status"))


def _handle_mongo_execute(args: argparse.Namespace) -> None:
    payload: dict[str, Any] = {
        "operation": args.operation,
        "collection": args.collection,
    }
    if args.operation in {"find", "find_one", "update_one", "delete_one", "count_documents"}:
        payload["filter"] = _parse_json(args.filter_json, "mongo filter JSON")
    if args.operation == "find":
        payload["sort"] = _parse_json(args.sort_json, "mongo sort JSON")
        payload["limit"] = args.limit
    if args.operation == "insert_one":
        payload["document"] = _parse_json(args.document_json, "mongo document JSON")
    if args.operation == "update_one":
        payload["update"] = _parse_json(args.update_json, "mongo update JSON")
    _print(_request(args.base_url, "POST", "/api/mongo/execute", payload))
