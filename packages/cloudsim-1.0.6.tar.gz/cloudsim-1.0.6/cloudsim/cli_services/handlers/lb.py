from __future__ import annotations

import argparse
from typing import Any

from ..common import _print, _request

def _handle_lb_delete(args: argparse.Namespace) -> None:
    _request(args.base_url, "DELETE", f"/api/load-balancers/{args.id}")
    _print({"ok": True, "deletedLbId": args.id})

def _handle_lb_list(args: argparse.Namespace) -> None:
    response = _request(args.base_url, "GET", "/api/state")
    lbs = response.get("state", {}).get("lbs", [])
    result = [
        {"id": lb.get("id"), "name": lb.get("name"), "status": lb.get("status")} for lb in lbs
    ]
    _print(result)

def _handle_lb_create(args: argparse.Namespace) -> None:
    payload: dict[str, Any] = {
        "name": args.name,
        "type": args.type,
        "region": args.region,
        "distributionAlgorithmId": args.distribution_algorithm_id,
        "backendVmIds": args.backend_vm_id,
        "autoScaleProfileId": args.auto_scale_profile_id,
        "queueServiceTier": args.queue_service_tier,
        "cloudArmorPolicyId": args.cloud_armor_policy_id,
    }
    response = _request(args.base_url, "POST", "/api/load-balancers", payload)
    if "state" in response and "lbs" in response["state"] and response["state"]["lbs"]:
        lb = response["state"]["lbs"][0]
        summary = {
            "id": lb.get("id"),
            "name": lb.get("name"),
            "status": lb.get("status"),
            "frontendPort": lb.get("frontendPort"),
        }
        _print(summary)
    else:
        _print(response)

def _handle_simulate(args: argparse.Namespace) -> None:
    payload = {
        "lbId": args.lb_id,
        "endpointKey": args.endpoint_key,
        "requests": args.requests,
        "clientId": args.client_id,
    }
    response = _request(args.base_url, "POST", "/api/simulate", payload)
    if "state" in response and "lastTrafficResult" in response["state"]:
        tr = response["state"]["lastTrafficResult"]
        summary = {
            "requested": tr.get("requested"),
            "served": tr.get("served"),
            "rejected": tr.get("rejected"),
            "autoscaledCount": tr.get("autoscaledCount"),
            "compatibleBackends": tr.get("compatibleBackends"),
            "avgLatencyMs": tr.get("avgLatencyMs"),
        }
        _print(summary)
    else:
        # Fallback if structure is unexpected
        _print(response, key="lastTrafficResult")

