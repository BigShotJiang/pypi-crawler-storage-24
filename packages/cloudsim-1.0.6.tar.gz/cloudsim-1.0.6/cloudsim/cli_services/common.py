from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from cloudsim import paths

DEFAULT_API_URL = os.environ.get("CLOUDSIM_API_URL", "http://127.0.0.1:5000").rstrip("/")


def get_repo_root() -> Path:
    # Keep legacy name used across CLI handlers; this is the workspace root.
    return paths.workspace_root()


class CliError(Exception):
    def __init__(self, message: str, status_code: int = 1) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def _parse_json(value: str, label: str) -> Any:
    try:
        return json.loads(value)
    except json.JSONDecodeError as error:
        raise CliError(f"Invalid JSON for {label}: {error.msg}") from error


def _request(base_url: str, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    url = f"{base_url}{path}"
    headers = {"Content-Type": "application/json"}
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url=url, method=method, data=body, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read().decode("utf-8")
            data = json.loads(raw) if raw else {}
    except urllib.error.HTTPError as error:
        raw = error.read().decode("utf-8")
        message = f"HTTP {error.code}"
        if raw:
            try:
                data = json.loads(raw)
                message = data.get("error") or data.get("message") or message
            except json.JSONDecodeError:
                message = f"{message}: {raw}"
        raise CliError(message, status_code=error.code)
    except urllib.error.URLError as error:
        raise CliError(f"Unable to reach backend at {base_url}: {error}") from error
    except json.JSONDecodeError as error:
        raise CliError(f"Invalid JSON response from backend: {error}") from error

    if isinstance(data, dict) and data.get("ok") is False:
        raise CliError(str(data.get("error") or "Request failed"))
    return data


def _print(data: Any, key: str | None = None) -> None:
    if key and isinstance(data, dict):
        if "state" in data:
            data = data["state"]
        if key in data:
            target = data[key]
            if isinstance(target, list) and target:
                print(json.dumps(target[0], indent=2, sort_keys=True))
            else:
                print(json.dumps(target, indent=2, sort_keys=True))
            return
    print(json.dumps(data, indent=2, sort_keys=True))
