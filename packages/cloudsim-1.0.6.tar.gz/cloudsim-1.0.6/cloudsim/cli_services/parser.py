from __future__ import annotations

import argparse

from .common import DEFAULT_API_URL
from .handlers.data import (
    _handle_mongo_execute,
    _handle_mongo_status,
    _handle_sql_change_password,
    _handle_sql_create_account,
    _handle_sql_execute,
    _handle_sql_provision,
    _handle_sql_real_change_password,
    _handle_sql_real_connect,
    _handle_sql_real_provision,
    _handle_sql_real_status,
    _handle_sql_set_role,
    _handle_sql_run_script,
    _handle_sql_status,
)
from .handlers.general import _handle_health, _handle_state
from .handlers.config import _handle_config_init, _handle_config_show
from .handlers.lb import _handle_lb_create, _handle_lb_delete, _handle_lb_list, _handle_simulate
from .handlers.network import _handle_block, _handle_call, _handle_dns_sync, _handle_expose
from .handlers.vm import _handle_cp, _handle_ssh, _handle_vm_create, _handle_vm_delete, _handle_vm_details, _handle_vm_list, _handle_vm_update


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cloudsim", description="CLI client for Nimbus Cloud Simulator Flask API")
    parser.add_argument("--base-url", default=DEFAULT_API_URL, help=f"Cloud simulator API base URL (default: {DEFAULT_API_URL})")
    subparsers = parser.add_subparsers(dest="command", required=True)

    health_parser = subparsers.add_parser("health", help="Check API health")
    health_parser.set_defaults(handler=_handle_health)

    state_parser = subparsers.add_parser("state", help="Fetch simulator state")
    state_parser.add_argument("--summary", action="store_true", help="Show compact counts instead of full state")
    state_parser.set_defaults(handler=_handle_state)

    config_parser = subparsers.add_parser("config", help="Configuration (workspace/.env)")
    config_sub = config_parser.add_subparsers(dest="config_command", required=True)
    config_init = config_sub.add_parser("init", help="Create <workspace>/.env and basic folders")
    config_init.add_argument("--workspace", default="", help="Workspace directory to initialize (default: current resolution)")
    config_init.add_argument("--force", action="store_true", help="Overwrite existing <workspace>/.env")
    config_init.add_argument("--no-default", action="store_true", help="Do not write ~/.cloudsim/config.json default workspace")
    config_init.set_defaults(handler=_handle_config_init)
    config_show = config_sub.add_parser("show", help="Show active config (workspace/.env/postgres)")
    config_show.set_defaults(handler=_handle_config_show)

    vm_parser = subparsers.add_parser("vm", help="VM operations")
    vm_sub = vm_parser.add_subparsers(dest="vm_command", required=True)
    vm_create = vm_sub.add_parser("create", help="Create a VM")
    vm_create.add_argument("--name", required=True)
    vm_create.add_argument("--region", required=True)
    vm_create.add_argument("--machine-type", required=True)
    vm_create.add_argument("--image", required=True)
    vm_create.add_argument("--backend-profile-id", required=True)
    vm_create.add_argument("--runtime-mode", choices=["profile", "python_script"], default="profile")
    vm_create.add_argument("--script-path", default="scripts/sample_app.py")
    vm_create.set_defaults(handler=_handle_vm_create)
    vm_list = vm_sub.add_parser("list", help="List all VMs")
    vm_list.set_defaults(handler=_handle_vm_list)
    vm_details = vm_sub.add_parser("details", help="Show VM details")
    vm_details.add_argument("id", help="VM ID")
    vm_details.set_defaults(handler=_handle_vm_details)
    vm_update = vm_sub.add_parser("update", help="Update a VM (e.g. change script)")
    vm_update.add_argument("--id", required=True)
    vm_update.add_argument("--script-path", required=True)
    vm_update.set_defaults(handler=_handle_vm_update)
    vm_delete = vm_sub.add_parser("delete", help="Delete a VM")
    vm_delete.add_argument("--id", required=True)
    vm_delete.set_defaults(handler=_handle_vm_delete)

    lb_parser = subparsers.add_parser("lb", help="Load balancer operations")
    lb_sub = lb_parser.add_subparsers(dest="lb_command", required=True)
    lb_list = lb_sub.add_parser("list", help="List all load balancers")
    lb_list.set_defaults(handler=_handle_lb_list)
    lb_create = lb_sub.add_parser("create", help="Create a load balancer")
    lb_create.add_argument("--name", required=True)
    lb_create.add_argument("--type", required=True)
    lb_create.add_argument("--region", required=True)
    lb_create.add_argument("--distribution-algorithm-id", default="round_robin")
    lb_create.add_argument("--backend-vm-id", action="append", required=True, help="Backend VM ID. Repeat this flag to add multiple backends.")
    lb_create.add_argument("--auto-scale-profile-id", default="balanced")
    lb_create.add_argument("--queue-service-tier", default="disabled")
    lb_create.add_argument("--cloud-armor-policy-id", default="standard")
    lb_create.set_defaults(handler=_handle_lb_create)
    lb_delete = lb_sub.add_parser("delete", help="Delete a load balancer")
    lb_delete.add_argument("--id", required=True)
    lb_delete.set_defaults(handler=_handle_lb_delete)

    sim_parser = subparsers.add_parser("simulate", help="Run traffic simulation")
    sim_parser.add_argument("--lb-id", required=True)
    sim_parser.add_argument("--endpoint-key", required=True, help='Example: "GET /health"')
    sim_parser.add_argument("--requests", type=int, required=True)
    sim_parser.add_argument("--client-id", default="demo-client")
    sim_parser.set_defaults(handler=_handle_simulate)


    sql_parser = subparsers.add_parser("sql", help="PostgreSQL service operations")
    sql_sub = sql_parser.add_subparsers(dest="sql_command", required=True)
    sql_status = sql_sub.add_parser("status", help="Show SQL service status")
    sql_status.set_defaults(handler=_handle_sql_status)
    sql_exec = sql_sub.add_parser("execute", help="Run SQL query")
    sql_exec.add_argument("--query", required=True)
    sql_exec.add_argument("--params-json", default="", help='JSON params for query, example: "[1, \"alice\"]"')
    sql_exec.add_argument("--vm-id", default=None, help="Target VM id for per-VM SQLite (auto when in cloudsim ssh)")
    sql_exec.add_argument("--mode", default="auto", choices=["auto", "local", "api"], help="auto=local if VM context else api")
    sql_exec.add_argument("--username", default=None)
    sql_exec.add_argument("--password", default=None)
    sql_exec.add_argument("--space", default=None)
    sql_exec.set_defaults(handler=_handle_sql_execute)
    sql_provision = sql_sub.add_parser("provision", help="Provision per-VM SQLite Cloud SQL (fallback when real Postgres not configured)")
    sql_provision.add_argument("--vm-id", default=None, help="Target VM id for per-VM SQLite (auto when in cloudsim ssh)")
    sql_provision.set_defaults(handler=_handle_sql_provision)
    sql_account = sql_sub.add_parser("create-account", help="Create cloud sql account in a space")
    sql_account.add_argument("--username", required=True)
    sql_account.add_argument("--password", required=True)
    sql_account.add_argument("--space", required=True)
    sql_account.add_argument("--role", default="admin", choices=["admin", "user"])
    sql_account.set_defaults(handler=_handle_sql_create_account)
    sql_script = sql_sub.add_parser("run-script", help="Run SQL script file in an authenticated space")
    sql_script.add_argument("--file", required=True, help="Path to .sql script file")
    sql_script.add_argument("--vm-id", default=None, help="Target VM id for per-VM SQLite (auto when in cloudsim ssh)")
    sql_script.add_argument("--mode", default="auto", choices=["auto", "local", "api"], help="auto=local if VM context else api")
    sql_script.add_argument("--username", required=True)
    sql_script.add_argument("--password", required=True)
    sql_script.add_argument("--space", required=True)
    sql_script.set_defaults(handler=_handle_sql_run_script)
    sql_change_password = sql_sub.add_parser("change-password", help="Change your cloud sql password")
    sql_change_password.add_argument("--username", required=True)
    sql_change_password.add_argument("--space", required=True)
    sql_change_password.add_argument("--old-password", required=True)
    sql_change_password.add_argument("--new-password", required=True)
    sql_change_password.set_defaults(handler=_handle_sql_change_password)
    sql_set_role = sql_sub.add_parser("set-role", help="Set role for a user in same space (admin only)")
    sql_set_role.add_argument("--admin-username", required=True)
    sql_set_role.add_argument("--admin-password", required=True)
    sql_set_role.add_argument("--username", required=True)
    sql_set_role.add_argument("--space", required=True)
    sql_set_role.add_argument("--role", required=True, choices=["admin", "user"])
    sql_set_role.set_defaults(handler=_handle_sql_set_role)
    sql_real_status = sql_sub.add_parser("real-status", help="Check real PostgreSQL connectivity")
    sql_real_status.set_defaults(handler=_handle_sql_real_status)
    sql_real_provision = sql_sub.add_parser("real-provision", help="Provision real PostgreSQL db/user for a space")
    sql_real_provision.add_argument("--space", default=None, help="Optional. If omitted, uses --vm-id or VM shell binding.")
    sql_real_provision.add_argument("--vm-id", default=None, help="Provision for a VM id (maps to space vm_<id>).")
    sql_real_provision.add_argument("--username", default=None)
    sql_real_provision.add_argument("--password", default=None)
    sql_real_provision.add_argument("--database", default=None)
    sql_real_provision.add_argument("--force", action="store_true", help="Override VM shell space binding checks")
    sql_real_provision.set_defaults(handler=_handle_sql_real_provision)
    sql_real_change_password = sql_sub.add_parser("real-change-password", help="Change password for real PostgreSQL user")
    sql_real_change_password.add_argument("--username", required=True)
    sql_real_change_password.add_argument("--old-password", required=True)
    sql_real_change_password.add_argument("--new-password", required=True)
    sql_real_change_password.add_argument("--database", required=True)
    sql_real_change_password.set_defaults(handler=_handle_sql_real_change_password)
    sql_real_connect = sql_sub.add_parser("real-connect", help="Open psql using saved profile for a space")
    sql_real_connect.add_argument("--space", default=None, help="Optional. If omitted, uses --vm-id or VM shell binding.")
    sql_real_connect.add_argument("--vm-id", default=None, help="Connect for a VM id (maps to space vm_<id>).")
    sql_real_connect.add_argument("--force", action="store_true", help="Override VM shell space binding checks")
    sql_real_connect.set_defaults(handler=_handle_sql_real_connect)

    mongo_parser = subparsers.add_parser("mongo", help="MongoDB service operations")
    mongo_sub = mongo_parser.add_subparsers(dest="mongo_command", required=True)
    mongo_status = mongo_sub.add_parser("status", help="Show Mongo service status")
    mongo_status.set_defaults(handler=_handle_mongo_status)
    mongo_exec = mongo_sub.add_parser("execute", help="Run Mongo operation")
    mongo_exec.add_argument("--operation", required=True, choices=["find", "find_one", "insert_one", "update_one", "delete_one", "count_documents"])
    mongo_exec.add_argument("--collection", required=True)
    mongo_exec.add_argument("--filter-json", default="{}", help='JSON object, example: "{\"name\": \"demo\"}"')
    mongo_exec.add_argument("--sort-json", default='{"_id": -1}', help='JSON object, used by "find"')
    mongo_exec.add_argument("--limit", type=int, default=20, help='Used by "find" (max 200)')
    mongo_exec.add_argument("--document-json", default="{}", help='JSON object, used by "insert_one"')
    mongo_exec.add_argument("--update-json", default='{"$set": {}}', help='JSON object, used by "update_one"')
    mongo_exec.set_defaults(handler=_handle_mongo_execute)

    ssh_parser = subparsers.add_parser("ssh", help="Open shell in VM environment")
    ssh_parser.add_argument("id", help="VM ID")
    ssh_parser.set_defaults(handler=_handle_ssh)
    cp_parser = subparsers.add_parser("cp", help="Copy file to VM workspace")
    cp_parser.add_argument("src", help="Source file/directory")
    cp_parser.add_argument("vm_id", help="Target VM ID")
    cp_parser.add_argument("dest", nargs="?", default=".", help="Destination path in VM (default: root)")
    cp_parser.set_defaults(handler=_handle_cp)

    expose_parser = subparsers.add_parser("expose", help="Get public URL mapping for VM")
    expose_parser.add_argument("id", help="VM ID")
    expose_parser.set_defaults(handler=_handle_expose)
    call_parser = subparsers.add_parser("call", help="Perform HTTP request to VM public mapping")
    call_parser.add_argument("id", help="VM ID")
    call_parser.add_argument("path", nargs="?", default="/", help="The endpoint path (default: /)")
    call_parser.set_defaults(handler=_handle_call)
    dns_sync = subparsers.add_parser("dns-sync", help="Sync internal DNS records to OS hosts file")
    dns_sync.add_argument("--admin-pass", default="", help="Mock admin password for simulated sync mode (use 123).")
    dns_sync.add_argument("--mock-hosts-file", default="cloudsim-hosts.mock", help="Output file used in mock-admin mode.")
    dns_sync.set_defaults(handler=_handle_dns_sync)
    block_parser = subparsers.add_parser("block", help="Revoke public domain expansion for a VM")
    block_parser.add_argument("id", help="VM ID")
    block_parser.set_defaults(handler=_handle_block)

    return parser
