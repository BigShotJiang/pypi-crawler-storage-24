from __future__ import annotations

import sys

from .common import CliError
from .parser import build_parser
from cloudsim.paths import workspace_root
from cloudsim.web.env_loader import load_env_file

WELCOME_BANNER = r"""
\033[96m   ________                _______ _
  / ____/ /___  __  ______/ ____/(_)___ ___
 / /   / / __ \/ / / / __  /\__ \/ / __ `__ \
/ /___/ / /_/ / /_/ / /_/ /___/ / / / / / / /
\____/_/\____/\__,_/\__,_/____/_/_/ /_/ /_/

Compute. Scale. Simulate.\033[0m
"""


def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    # Load <workspace>/.env for CLI runs too (Postgres config, etc.).
    load_env_file(workspace_root() / ".env")

    if not argv:
        print(WELCOME_BANNER)
        print("\033[93mWelcome to CloudSim!\033[0m Your personal cloud laboratory.")
        print("\n\033[95mCore Commands:\033[0m")
        print("  \033[92mcloudsim vm\033[0m <create|list|details>    Manage your Virtual Machines")
        print("  \033[92mcloudsim lb\033[0m <create|list|delete>    Provision Load Balancers")
        print("  \033[92mcloudsim sql\033[0m real-provision         Set up isolated databases")
        print("\n\033[95mInteraction:\033[0m")
        print("  \033[92mcloudsim ssh\033[0m <vm_id>                 SSH into a simulated VM")
        print("  \033[92mcloudsim call\033[0m <vm_id> /math          Test your public endpoints")
        print("\nRun \033[94m'cloudsim --help'\033[0m for all commands or check the README.")
        return 0

    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        args.handler(args)
        return 0
    except CliError as error:
        print(error.message, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
