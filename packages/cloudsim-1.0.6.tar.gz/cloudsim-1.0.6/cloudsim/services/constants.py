﻿from __future__ import annotations

VM_REGIONS = ["us-central1", "us-east1", "europe-west1"]
VM_MACHINE_TYPES = ["e2-micro", "e2-standard-2", "c3-standard-4"]
VM_IMAGES = ["Ubuntu 22.04 LTS", "Debian 12"]
LB_TYPES = ["HTTP(S)"]
LB_REGIONS = ["global", "us-central1"]

VM_REQUEST_LIMIT = 100
LB_REQUEST_LIMITS = [100, 500, 1000, 5000]
MAX_SIMULATED_REQUESTS = 100000
MAX_LOGS = 500
VM_PORT_START = 6001
LB_PORT_START = 7001

BACKEND_PROFILES = [
    {
        "id": "python-fastapi",
        "name": "Python API",
        "runtime": "python",
        "description": "Basic API profile",
        "apis": [
            {"method": "GET", "path": "/health", "latencyMs": 35},
            {"method": "GET", "path": "/", "latencyMs": 20},
        ],
        "sampleCode": "print('ok')",
    }
]

VM_RUNTIME_MODES = [
    {"id": "profile", "label": "Backend profile"},
    {"id": "python_script", "label": "Python script"},
]

LB_DISTRIBUTION_ALGORITHMS = [
    {"id": "round_robin", "label": "Round robin"},
    {"id": "least_connections", "label": "Least connections"},
]

AUTO_SCALE_PROFILES = [
    {"id": "conservative", "label": "Conservative", "maxVmCount": 2},
    {"id": "balanced", "label": "Balanced", "maxVmCount": 3},
    {"id": "aggressive", "label": "Aggressive", "maxVmCount": 5},
]
AUTO_SCALE_PROFILE_BY_ID = {p["id"]: p for p in AUTO_SCALE_PROFILES}

QUEUE_SERVICE_TIERS = [
    {"id": "disabled", "label": "Disabled", "capacity": 0},
    {"id": "paid", "label": "Paid", "capacity": 5000},
]

CLOUD_ARMOR_POLICIES = [
    {"id": "relaxed", "label": "Relaxed", "rateLimitPerWindow": 200000, "windowSeconds": 60},
    {"id": "standard", "label": "Standard", "rateLimitPerWindow": 10000, "windowSeconds": 60},
    {"id": "strict", "label": "Strict", "rateLimitPerWindow": 2000, "windowSeconds": 60},
]
