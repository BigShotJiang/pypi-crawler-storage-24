﻿from __future__ import annotations

from .constants import BACKEND_PROFILES, VM_REQUEST_LIMIT


def _profile_by_id(profile_id: str):
    for p in BACKEND_PROFILES:
        if p["id"] == profile_id:
            return p
    return BACKEND_PROFILES[0]


def create_vm(payload, reserve_port, new_id, now_stamp):
    profile = _profile_by_id(str(payload.get("backendProfileId", "python-fastapi")))
    return {
        "id": new_id(),
        "name": str(payload.get("name") or "vm"),
        "region": str(payload.get("region") or "us-central1"),
        "machineType": str(payload.get("machineType") or "e2-standard-2"),
        "image": str(payload.get("image") or "Ubuntu 22.04 LTS"),
        "status": "running",
        "createdAt": now_stamp(),
        "reservedPort": reserve_port(),
        "backendProfileId": profile["id"],
        "backendProfileName": profile["name"],
        "backendRuntime": profile["runtime"],
        "backendDescription": profile["description"],
        "apis": profile["apis"],
        "sampleCode": profile.get("sampleCode", ""),
        "runtimeMode": str(payload.get("runtimeMode") or "profile"),
        "scriptPath": str(payload.get("scriptPath") or ""),
        "scriptStatus": "pending",
        "_vmDir": None,
        "autoScaled": False,
        "autoScaledFromVmId": None,
        "autoScaledForLbId": None,
        "autoScaledForLb": None,
        "requestLimit": VM_REQUEST_LIMIT,
        "isExposed": False,
        "_createdTs": 0.0,
        "_readyAt": 0.0,
    }


def create_autoscaled_vm(template, lb_id, lb_name, reserve_port, new_id, now_stamp):
    vm = dict(template)
    vm["id"] = new_id()
    vm["name"] = f"{template.get('name', 'vm')}-as-{vm['id'][:4]}"
    vm["reservedPort"] = reserve_port()
    vm["createdAt"] = now_stamp()
    vm["status"] = "running"
    vm["autoScaled"] = True
    vm["autoScaledFromVmId"] = template.get("id")
    vm["autoScaledForLbId"] = lb_id
    vm["autoScaledForLb"] = lb_name
    vm["isExposed"] = False
    return vm


def sync_vm_statuses(vms, now_ts, push_log, on_vm_running):
    return None
