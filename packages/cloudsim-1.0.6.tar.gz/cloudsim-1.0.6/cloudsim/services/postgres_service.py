﻿from __future__ import annotations

import hashlib
import re
import sqlite3
import time
from pathlib import Path

from .. import paths
from .sqlite_utils import connect_sqlite

class PostgresService:
    def __init__(self) -> None:
        self.db_path = paths.sql_service_db_path()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        conn = connect_sqlite(self.db_path)
        conn.execute("CREATE TABLE IF NOT EXISTS demo (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS cloudsql_accounts (
                username TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                space TEXT NOT NULL,
                role TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (username, space)
            )
            """
        )
        conn.commit()
        conn.close()

    def status(self):
        return {"provider": "simulated-postgres", "available": True, "dbPath": str(self.db_path)}

    def _hash_password(self, password: str) -> str:
        return hashlib.sha256(password.encode("utf-8")).hexdigest()

    def create_account(self, username: str, password: str, space: str, role: str = "admin"):
        if not username.strip():
            raise ValueError("username is required")
        if not password.strip():
            raise ValueError("password is required")
        if not space.strip():
            raise ValueError("space is required")
        if role not in {"admin", "user"}:
            raise ValueError("role must be admin or user")

        conn = connect_sqlite(self.db_path)
        try:
            conn.execute(
                """
                INSERT OR REPLACE INTO cloudsql_accounts(username, password_hash, space, role)
                VALUES (?, ?, ?, ?)
                """,
                (username.strip(), self._hash_password(password), space.strip(), role),
            )
            conn.commit()
            return {"username": username.strip(), "space": space.strip(), "role": role}
        finally:
            conn.close()

    def change_password(self, username: str, space: str, old_password: str, new_password: str):
        if not new_password.strip():
            raise ValueError("new password is required")
        identity = self._verify_account(username.strip(), old_password, space.strip())
        conn = connect_sqlite(self.db_path)
        try:
            conn.execute(
                "UPDATE cloudsql_accounts SET password_hash = ? WHERE username = ? AND space = ?",
                (self._hash_password(new_password), identity["username"], identity["space"]),
            )
            conn.commit()
            return {"username": identity["username"], "space": identity["space"], "passwordChanged": True}
        finally:
            conn.close()

    def set_role(
        self,
        target_username: str,
        space: str,
        role: str,
        admin_username: str,
        admin_password: str,
    ):
        if role not in {"admin", "user"}:
            raise ValueError("role must be admin or user")
        admin_identity = self._verify_account(admin_username.strip(), admin_password, space.strip())
        if admin_identity["role"] != "admin":
            raise PermissionError("only admin can change roles")

        conn = connect_sqlite(self.db_path)
        try:
            cur = conn.execute(
                "UPDATE cloudsql_accounts SET role = ? WHERE username = ? AND space = ?",
                (role, target_username.strip(), space.strip()),
            )
            if cur.rowcount == 0:
                raise ValueError("target account not found in this space")
            conn.commit()
            return {"username": target_username.strip(), "space": space.strip(), "role": role}
        finally:
            conn.close()

    def _verify_account(self, username: str, password: str, space: str):
        conn = connect_sqlite(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                "SELECT username, space, role, password_hash FROM cloudsql_accounts WHERE username = ? AND space = ?",
                (username, space),
            ).fetchone()
            if not row:
                raise PermissionError("account not found for this space")
            if row["password_hash"] != self._hash_password(password):
                raise PermissionError("invalid password")
            return {"username": row["username"], "space": row["space"], "role": row["role"]}
        finally:
            conn.close()

    def _extract_table_names(self, query: str) -> list[str]:
        patterns = [
            r"\bfrom\s+([a-zA-Z_][a-zA-Z0-9_]*)",
            r"\bjoin\s+([a-zA-Z_][a-zA-Z0-9_]*)",
            r"\binto\s+([a-zA-Z_][a-zA-Z0-9_]*)",
            r"\bupdate\s+([a-zA-Z_][a-zA-Z0-9_]*)",
            r"\btable\s+(?:if\s+not\s+exists\s+)?([a-zA-Z_][a-zA-Z0-9_]*)",
        ]
        found: list[str] = []
        q = query.lower()
        for pattern in patterns:
            found.extend(re.findall(pattern, q))
        return list(dict.fromkeys(found))

    def _qualify_query_tables(self, query: str, space: str) -> str:
        """
        Rewrite user table names to tenant-qualified names.
        Example for space vm_a: `orders` -> `vm_a__orders`.
        """
        prefix = f"{space.lower()}__"
        rewritten = query

        def _qualify(name: str) -> str:
            if name.startswith("cloudsql_"):
                raise PermissionError("access to internal cloudsql tables is denied")
            if name.startswith(prefix):
                return name
            if "__" in name and not name.startswith(prefix):
                raise PermissionError(
                    f'access denied for table "{name}". This table belongs to another space.'
                )
            return f"{prefix}{name}"

        patterns = [
            r"(\bfrom\s+)([a-zA-Z_][a-zA-Z0-9_]*)",
            r"(\bjoin\s+)([a-zA-Z_][a-zA-Z0-9_]*)",
            r"(\binto\s+)([a-zA-Z_][a-zA-Z0-9_]*)",
            r"(\bupdate\s+)([a-zA-Z_][a-zA-Z0-9_]*)",
            r"(\btable\s+(?:if\s+not\s+exists\s+)?)([a-zA-Z_][a-zA-Z0-9_]*)",
        ]

        for pattern in patterns:
            rewritten = re.sub(
                pattern,
                lambda m: f"{m.group(1)}{_qualify(m.group(2).lower())}",
                rewritten,
                flags=re.IGNORECASE,
            )
        return rewritten

    def execute(self, query, params=None, username: str | None = None, password: str | None = None, space: str | None = None):
        identity = None
        effective_query = query
        if username is not None or password is not None or space is not None:
            if not username or not password or not space:
                raise PermissionError("username, password, and space are required together")
            identity = self._verify_account(username.strip(), password, space.strip())
            effective_query = self._qualify_query_tables(str(query), identity["space"])

        # Retry a few times on lock under heavy concurrency.
        backoff = 0.02
        last_exc: Exception | None = None
        for _ in range(6):
            conn = connect_sqlite(self.db_path)
            cur = conn.cursor()
            try:
                if params is None:
                    cur.execute(effective_query)
                else:
                    cur.execute(effective_query, params)
                if str(query).strip().lower().startswith("select"):
                    rows = cur.fetchall()
                    cols = [d[0] for d in (cur.description or [])]
                    return {
                        "columns": cols,
                        "rows": rows,
                        "rowCount": len(rows),
                        "space": identity["space"] if identity else None,
                        "username": identity["username"] if identity else None,
                    }
                conn.commit()
                return {
                    "rowCount": cur.rowcount,
                    "space": identity["space"] if identity else None,
                    "username": identity["username"] if identity else None,
                }
            except sqlite3.OperationalError as exc:
                last_exc = exc
                if "locked" not in str(exc).lower():
                    raise
                time.sleep(backoff)
                backoff = min(backoff * 2, 0.5)
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
        raise sqlite3.OperationalError(f"database is locked (after retries): {last_exc}")

    def run_script(self, script: str, username: str, password: str, space: str):
        identity = self._verify_account(username.strip(), password, space.strip())
        statements = [s.strip() for s in script.split(";") if s.strip()]
        if not statements:
            return {"executed": 0, "space": identity["space"], "username": identity["username"]}

        conn = connect_sqlite(self.db_path)
        cur = conn.cursor()
        executed = 0
        try:
            for stmt in statements:
                effective_stmt = self._qualify_query_tables(stmt, identity["space"])
                cur.execute(effective_stmt)
                executed += 1
            conn.commit()
            return {"executed": executed, "space": identity["space"], "username": identity["username"]}
        finally:
            conn.close()
