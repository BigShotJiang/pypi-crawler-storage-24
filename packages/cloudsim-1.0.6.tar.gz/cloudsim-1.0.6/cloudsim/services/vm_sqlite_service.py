﻿from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from .sqlite_utils import connect_sqlite


def ensure_vm_sqlite_db(vm_dir: Path) -> Path:
    vm_dir.mkdir(parents=True, exist_ok=True)
    db_path = vm_dir / "vm_sqlite.db"
    conn = connect_sqlite(db_path)
    try:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS _meta(key TEXT PRIMARY KEY, value TEXT)"
        )
        conn.commit()
    finally:
        conn.close()
    return db_path


def execute_vm_sqlite(vm_dir: Path, query: str, params: Any | None = None) -> dict[str, Any]:
    db_path = ensure_vm_sqlite_db(vm_dir)
    conn = connect_sqlite(db_path)
    cur = conn.cursor()
    try:
        if params is None:
            cur.execute(query)
        else:
            cur.execute(query, params)

        if query.strip().lower().startswith("select"):
            rows = cur.fetchall()
            cols = [d[0] for d in (cur.description or [])]
            return {"columns": cols, "rows": rows, "rowCount": len(rows), "dbPath": str(db_path)}

        conn.commit()
        return {"rowCount": cur.rowcount, "dbPath": str(db_path)}
    finally:
        conn.close()


def run_script_vm_sqlite(vm_dir: Path, script: str) -> dict[str, Any]:
    db_path = ensure_vm_sqlite_db(vm_dir)
    conn = connect_sqlite(db_path)
    cur = conn.cursor()
    executed = 0
    try:
        statements = [s.strip() for s in script.split(";") if s.strip()]
        for stmt in statements:
            cur.execute(stmt)
            executed += 1
        conn.commit()
        return {"executed": executed, "dbPath": str(db_path)}
    finally:
        conn.close()
