﻿from __future__ import annotations

from collections import defaultdict

from .constants import CLOUD_ARMOR_POLICIES


class CloudArmorService:
    def __init__(self) -> None:
        self._buckets = defaultdict(lambda: {"window_start": 0.0, "count": 0})

    def evaluate(self, lb, client_id, requested, now_ts):
        policy_id = lb.get("cloudArmorPolicyId", "standard")
        policy = next((p for p in CLOUD_ARMOR_POLICIES if p["id"] == policy_id), CLOUD_ARMOR_POLICIES[1])
        key = (lb.get("id"), client_id, policy_id)
        bucket = self._buckets[key]
        window = int(policy.get("windowSeconds", 60))
        limit = int(policy.get("rateLimitPerWindow", 10000))

        if now_ts - float(bucket["window_start"]) >= window:
            bucket["window_start"] = now_ts
            bucket["count"] = 0

        remaining = max(0, limit - int(bucket["count"]))
        allowed = min(int(requested), remaining)
        blocked = max(0, int(requested) - allowed)
        bucket["count"] = int(bucket["count"]) + allowed

        return {
            "policyId": policy_id,
            "policyLabel": policy.get("label", policy_id),
            "clientId": client_id,
            "allowed": allowed,
            "blocked": blocked,
            "remainingInWindow": max(0, limit - int(bucket["count"])),
            "reason": "rate limit applied" if blocked else "allowed",
        }
