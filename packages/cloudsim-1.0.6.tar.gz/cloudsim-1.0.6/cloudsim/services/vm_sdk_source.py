﻿# CloudSim VM SDK placeholder

def hello():
    return "cloudsim-sdk"
