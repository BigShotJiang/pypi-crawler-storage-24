﻿from __future__ import annotations

from .constants import AUTO_SCALE_PROFILE_BY_ID, LB_REQUEST_LIMITS


def create_load_balancer(payload, vms, reserve_port, new_id, now_stamp):
    backend_ids = list(payload.get("backendVmIds") or [])
    if not backend_ids:
        raise ValueError("backendVmIds is required")
    request_limit = max(LB_REQUEST_LIMITS)
    return {
        "id": new_id(),
        "name": str(payload.get("name") or "lb"),
        "type": str(payload.get("type") or "HTTP(S)"),
        "region": str(payload.get("region") or "global"),
        "status": "active",
        "frontendPort": reserve_port(),
        "requestLimit": request_limit,
        "distributionAlgorithmId": str(payload.get("distributionAlgorithmId") or "round_robin"),
        "autoScaleProfileId": str(payload.get("autoScaleProfileId") or "balanced"),
        "queueServiceTier": str(payload.get("queueServiceTier") or "disabled"),
        "cloudArmorPolicyId": str(payload.get("cloudArmorPolicyId") or "standard"),
        "backendVmIds": backend_ids,
        "createdAt": now_stamp(),
        # Never scale below the initially provisioned backend count.
        "minVmCount": len(backend_ids),
        "_rrIndex": 0,
        "_queueDepth": 0,
        "_idleCycles": 0,
        "_leastConnections": {},
    }


def distribute_requests(lb, compatible_backends, served):
    algo = lb.get("distributionAlgorithmId", "round_robin")
    usage = {vm["id"]: 0 for vm in compatible_backends}
    if not compatible_backends or served <= 0:
        return usage, {"algorithmId": algo, "startIndex": int(lb.get("_rrIndex", 0)), "endIndex": int(lb.get("_rrIndex", 0))}

    if algo == "least_connections":
        least = lb.setdefault("_leastConnections", {})
        for _ in range(served):
            vm = min(compatible_backends, key=lambda v: least.get(v["id"], 0))
            usage[vm["id"]] += 1
            least[vm["id"]] = least.get(vm["id"], 0) + 1
        return usage, {"algorithmId": algo, "startIndex": 0, "endIndex": 0}

    start = int(lb.get("_rrIndex", 0)) % len(compatible_backends)
    idx = start
    for _ in range(served):
        vm = compatible_backends[idx]
        usage[vm["id"]] += 1
        idx = (idx + 1) % len(compatible_backends)
    lb["_rrIndex"] = idx
    return usage, {"algorithmId": "round_robin", "startIndex": start, "endIndex": idx}


def sync_load_balancer_statuses(lbs, now_ts, push_log):
    return None
