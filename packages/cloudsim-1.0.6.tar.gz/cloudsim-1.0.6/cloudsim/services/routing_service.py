﻿from __future__ import annotations


def average_latency_ms(backends, endpoint_latency):
    return int(endpoint_latency)


def distribution_text(backends, usage):
    parts = []
    for vm in backends:
        vid = vm.get("id", "?")
        parts.append(f"{vid}:{usage.get(vid, 0)}")
    return ", ".join(parts)
