from __future__ import annotations

import sqlite3
from pathlib import Path


def connect_sqlite(path: Path, *, timeout_seconds: float = 10.0) -> sqlite3.Connection:
    """
    Centralized SQLite connection settings for CloudSim.

    Stress testing will otherwise hit transient "database is locked" errors under
    concurrent writes. These settings improve concurrency and add a busy timeout.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=timeout_seconds)
    try:
        # WAL gives better writer/reader concurrency for our workload.
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        conn.execute("PRAGMA busy_timeout=5000;")  # ms
    except Exception:
        # PRAGMAs should not hard-fail app startup.
        pass
    return conn

