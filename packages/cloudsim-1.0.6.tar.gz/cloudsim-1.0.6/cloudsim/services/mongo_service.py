﻿from __future__ import annotations

from collections import defaultdict


class MongoService:
    def __init__(self) -> None:
        self._db = defaultdict(list)

    def status(self):
        return {"provider": "simulated-mongo", "available": True}

    def execute(self, payload):
        op = payload.get("operation")
        coll = payload.get("collection")
        if not coll:
            return {"error": "collection is required"}
        docs = self._db[coll]

        if op == "insert_one":
            doc = dict(payload.get("document") or {})
            docs.append(doc)
            return {"insertedCount": 1}

        filt = payload.get("filter") or {}
        matches = [d for d in docs if all(d.get(k) == v for k, v in filt.items())]

        if op == "find_one":
            return {"document": matches[0] if matches else None}
        if op == "find":
            limit = max(0, min(200, int(payload.get("limit", 20))))
            return {"documents": matches[:limit], "count": len(matches[:limit])}
        if op == "count_documents":
            return {"count": len(matches)}
        if op == "delete_one":
            if matches:
                docs.remove(matches[0])
                return {"deletedCount": 1}
            return {"deletedCount": 0}
        if op == "update_one":
            upd = payload.get("update") or {}
            set_vals = upd.get("$set", {})
            if matches:
                matches[0].update(set_vals)
                return {"matchedCount": 1, "modifiedCount": 1}
            return {"matchedCount": 0, "modifiedCount": 0}
        return {"error": f"unsupported operation: {op}"}
