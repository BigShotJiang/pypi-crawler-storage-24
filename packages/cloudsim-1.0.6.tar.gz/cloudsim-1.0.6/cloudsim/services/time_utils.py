﻿from __future__ import annotations

from datetime import datetime, timezone


def now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
