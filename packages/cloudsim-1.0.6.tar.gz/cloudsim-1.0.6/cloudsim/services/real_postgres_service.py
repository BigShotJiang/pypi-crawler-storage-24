﻿from __future__ import annotations

import os
import re
import secrets
from dataclasses import dataclass

try:
    import psycopg
    from psycopg import sql
except Exception:  # pragma: no cover
    psycopg = None
    sql = None


_IDENTIFIER_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,62}$")


def _sanitize_identifier(name: str, label: str) -> str:
    candidate = (name or "").strip().lower()
    if not _IDENTIFIER_RE.match(candidate):
        raise ValueError(f"invalid {label}: use letters/numbers/underscore, start with letter/underscore")
    return candidate


@dataclass
class PgAdminConfig:
    host: str
    port: int
    user: str
    password: str
    dbname: str


class RealPostgresService:
    def __init__(self) -> None:
        self.cfg = PgAdminConfig(
            host=os.environ.get("CLOUDSIM_PG_HOST", os.environ.get("PGHOST", "127.0.0.1")),
            port=int(os.environ.get("CLOUDSIM_PG_PORT", os.environ.get("PGPORT", "5432"))),
            user=os.environ.get("CLOUDSIM_PG_ADMIN_USER", os.environ.get("PGUSER", "postgres")),
            password=os.environ.get("CLOUDSIM_PG_ADMIN_PASSWORD", os.environ.get("PGPASSWORD", "")),
            dbname=os.environ.get("CLOUDSIM_PG_ADMIN_DB", "postgres"),
        )

    def _ensure_driver(self):
        if psycopg is None:
            raise RuntimeError("psycopg is not installed. Run: pip install psycopg[binary]")

    def _admin_conn(self, dbname: str | None = None):
        self._ensure_driver()
        return psycopg.connect(
            host=self.cfg.host,
            port=self.cfg.port,
            user=self.cfg.user,
            password=self.cfg.password,
            dbname=dbname or self.cfg.dbname,
            autocommit=True,
        )

    def status(self) -> dict:
        self._ensure_driver()
        try:
            with self._admin_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT version(), current_database(), current_user")
                    row = cur.fetchone()
            return {
                "available": True,
                "host": self.cfg.host,
                "port": self.cfg.port,
                "adminUser": self.cfg.user,
                "adminDb": self.cfg.dbname,
                "serverVersion": row[0],
                "connectedDatabase": row[1],
                "connectedUser": row[2],
            }
        except Exception as exc:
            return {
                "available": False,
                "host": self.cfg.host,
                "port": self.cfg.port,
                "adminUser": self.cfg.user,
                "adminDb": self.cfg.dbname,
                "error": str(exc),
            }

    def provision_space(self, space: str, username: str | None = None, password: str | None = None, database: str | None = None) -> dict:
        norm_space = _sanitize_identifier(space, "space")
        db_name = _sanitize_identifier(database or f"cs_{norm_space}", "database")
        user_name = _sanitize_identifier(username or f"cs_{norm_space}", "username")
        user_password = password or secrets.token_urlsafe(12)

        with self._admin_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (user_name,))
                user_exists = cur.fetchone() is not None
                if not user_exists:
                    cur.execute(
                        sql.SQL("CREATE ROLE {} LOGIN PASSWORD {}").format(
                            sql.Identifier(user_name), sql.Literal(user_password)
                        )
                    )
                else:
                    cur.execute(
                        sql.SQL("ALTER ROLE {} WITH LOGIN PASSWORD {}").format(
                            sql.Identifier(user_name), sql.Literal(user_password)
                        )
                    )

                cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (db_name,))
                db_exists = cur.fetchone() is not None
                if not db_exists:
                    cur.execute(
                        sql.SQL("CREATE DATABASE {} OWNER {}")
                        .format(sql.Identifier(db_name), sql.Identifier(user_name))
                    )
                else:
                    cur.execute(
                        sql.SQL("ALTER DATABASE {} OWNER TO {}")
                        .format(sql.Identifier(db_name), sql.Identifier(user_name))
                    )

        with self._admin_conn(dbname=db_name) as conn:
            with conn.cursor() as cur:
                cur.execute("CREATE SCHEMA IF NOT EXISTS app")
                cur.execute(
                    sql.SQL("ALTER SCHEMA app OWNER TO {}").format(sql.Identifier(user_name))
                )
                cur.execute(
                    sql.SQL("GRANT ALL PRIVILEGES ON DATABASE {} TO {}")
                    .format(sql.Identifier(db_name), sql.Identifier(user_name))
                )
                cur.execute(sql.SQL("GRANT USAGE, CREATE ON SCHEMA app TO {}").format(sql.Identifier(user_name)))

        # Validate login with new credentials.
        with psycopg.connect(
            host=self.cfg.host,
            port=self.cfg.port,
            user=user_name,
            password=user_password,
            dbname=db_name,
            autocommit=True,
        ) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT current_user, current_database()")
                row = cur.fetchone()

        return {
            "space": norm_space,
            "host": self.cfg.host,
            "port": self.cfg.port,
            "username": user_name,
            "password": user_password,
            "database": db_name,
            "schema": "app",
            "verifiedLogin": {"user": row[0], "database": row[1]},
            "psqlCommand": f'PGPASSWORD="{user_password}" psql -h {self.cfg.host} -p {self.cfg.port} -U {user_name} -d {db_name}',
        }

    def change_password_self(self, username: str, old_password: str, new_password: str, database: str) -> dict:
        user_name = _sanitize_identifier(username, "username")
        db_name = _sanitize_identifier(database, "database")
        if not new_password.strip():
            raise ValueError("new password is required")

        self._ensure_driver()
        with psycopg.connect(
            host=self.cfg.host,
            port=self.cfg.port,
            user=user_name,
            password=old_password,
            dbname=db_name,
            autocommit=True,
        ) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    sql.SQL("ALTER ROLE {} WITH PASSWORD {}").format(
                        sql.Identifier(user_name), sql.Literal(new_password)
                    )
                )

        return {"username": user_name, "database": db_name, "passwordChanged": True}
