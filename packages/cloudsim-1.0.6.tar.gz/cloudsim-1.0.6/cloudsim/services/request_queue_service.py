﻿from __future__ import annotations

from .constants import QUEUE_SERVICE_TIERS


def apply_queue(lb, overflow, autoscaled_total_for_lb, autoscaling_enabled):
    tier = lb.get("queueServiceTier", "disabled")
    capacity = 0
    for t in QUEUE_SERVICE_TIERS:
        if t["id"] == tier:
            capacity = int(t["capacity"])
            break

    existing = int(lb.get("_queueDepth", 0))
    demand = existing + max(0, int(overflow))
    queued = min(capacity, demand)
    dropped = max(0, demand - queued)
    lb["_queueDepth"] = queued
    return {
        "tier": tier,
        "capacity": capacity,
        "queued": queued,
        "dropped": dropped,
        "isFull": queued >= capacity if capacity > 0 else demand > 0,
    }
