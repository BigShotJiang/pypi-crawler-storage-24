﻿from __future__ import annotations

from .constants import AUTO_SCALE_PROFILE_BY_ID


def autoscale_up(lb, compatible_backends, vm_rejected_before_autoscale, create_autoscaled_vm):
    if vm_rejected_before_autoscale <= 0 or not compatible_backends:
        return [], False

    profile = AUTO_SCALE_PROFILE_BY_ID.get(lb.get("autoScaleProfileId"), {"maxVmCount": 3})
    max_count = int(profile.get("maxVmCount", 3))
    current_auto = sum(1 for vm in compatible_backends if vm.get("autoScaled") and vm.get("autoScaledForLbId") == lb.get("id"))
    room = max(0, max_count - current_auto)
    if room <= 0:
        return [], True

    needed = (vm_rejected_before_autoscale + 99) // 100
    create_n = min(room, needed)
    template = compatible_backends[0]
    created = [create_autoscaled_vm(template, lb.get("id"), lb.get("name")) for _ in range(create_n)]
    return created, create_n < needed


def autoscale_down(lb, backend_vms, utilization, queue_depth, remove_vm, *, min_vm_count: int = 1):
    removed = []
    if queue_depth > 0:
        lb["_idleCycles"] = 0
        return removed
    if utilization < 0.3:
        lb["_idleCycles"] = int(lb.get("_idleCycles", 0)) + 1
    else:
        lb["_idleCycles"] = 0
        return removed

    if int(lb.get("_idleCycles", 0)) < 2:
        return removed

    autoscaled = [vm for vm in backend_vms if vm.get("autoScaled") and vm.get("autoScaledForLbId") == lb.get("id")]
    if not autoscaled:
        return removed

    # Never scale the LB below its minimum footprint (base instances).
    if len(backend_vms) <= max(1, int(min_vm_count)):
        lb["_idleCycles"] = 0
        return removed

    victim = autoscaled[-1]
    remove_vm(victim["id"])
    removed.append(victim)
    lb["_idleCycles"] = 0
    return removed
