﻿from __future__ import annotations


class ScriptRuntimeService:
    def __init__(self, backend_root, push_log, repo_root=None) -> None:
        self.backend_root = backend_root
        self.push_log = push_log
        self.repo_root = repo_root

    def start_for_vm(self, vm):
        if vm.get("runtimeMode") == "python_script":
            vm["scriptStatus"] = "running"

    def stop_for_vm(self, vm):
        if vm.get("runtimeMode") == "python_script":
            vm["scriptStatus"] = "stopped"

    def refresh_vm_runtime_status(self, vm):
        return None
