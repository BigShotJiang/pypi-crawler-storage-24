﻿from __future__ import annotations

import json
from pathlib import Path


def resolve_vm_dns_target(resource_id, repo_root: Path, request_fn, base_url):
    state_resp = request_fn(base_url, "GET", "/api/state")
    state = state_resp.get("state", {})
    
    # Try finding VM by id or name
    target = next((v for v in state.get("vms", []) if v.get("id") == resource_id or v.get("name") == resource_id), None)
    port = None
    
    if target:
        port = target.get("reservedPort") or target.get("reserved_port")
        public_host = f"{target.get('name', 'vm')}-{target['id']}.cloudsim.local"
    else:
        # Try finding LB by id or name
        target = next((l for l in state.get("lbs", []) if l.get("id") == resource_id or l.get("name") == resource_id), None)
        if target:
            port = target.get("frontendPort") or target.get("frontend_port")
            public_host = f"{target.get('name', 'lb')}-{target['id']}.cloudsim.local"
            
    if not target:
        raise ValueError(f"Resource not found: {resource_id}")

    if not port:
        raise ValueError(f"No configured port for resource: {resource_id}")

    return {
        "publicHost": public_host,
        "publicUrl": f"http://{public_host}",
        "localBaseUrl": "http://127.0.0.1:5000",
        "resolvedPort": int(port),
    }
