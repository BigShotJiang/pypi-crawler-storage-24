﻿from __future__ import annotations

from cloudsim.web.app_factory import create_app

app = create_app()


def main(argv: list[str] | None = None) -> int:
    # argv kept for console_script compatibility; Flask dev server ignores it.
    app.run(host="127.0.0.1", port=5000, debug=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

