﻿from __future__ import annotations

from flask import Blueprint, jsonify, request

from .deps import mongo_service, postgres_service, real_postgres_service, simulator

try:
    import database
except ImportError:
    from .. import database

api_bp = Blueprint("api", __name__, url_prefix="/api")


@api_bp.get("/health")
def health():
    real_pg = real_postgres_service.status()
    return jsonify(
        {
            "ok": True,
            "service": "cloud-simulator-backend",
            "realPostgresAvailable": bool(real_pg.get("available")),
            "realPostgresHost": real_pg.get("host"),
            "realPostgresPort": real_pg.get("port"),
        }
    )


@api_bp.get("/state")
def state():
    return jsonify({"ok": True, "state": simulator.get_state()})


@api_bp.post("/vms")
def create_vm():
    payload = request.get_json(silent=True) or {}
    return jsonify({"ok": True, "state": simulator.create_vm(payload)})


@api_bp.delete("/vms/<vm_id>")
def delete_vm(vm_id: str):
    return jsonify({"ok": True, "state": simulator.delete_vm(vm_id)})


@api_bp.put("/vms/<vm_id>/script")
def update_vm_script(vm_id: str):
    payload = request.get_json(silent=True) or {}
    return jsonify({"ok": True, "state": simulator.update_vm_script(vm_id, payload.get("scriptPath", ""))})


@api_bp.put("/vms/<vm_id>/expose")
def expose_vm(vm_id: str):
    payload = request.get_json(silent=True) or {}
    return jsonify({"ok": True, "state": simulator.expose_vm(vm_id, payload.get("exposed", True))})


@api_bp.post("/load-balancers")
def create_load_balancer():
    payload = request.get_json(silent=True) or {}
    return jsonify({"ok": True, "state": simulator.create_load_balancer(payload)})


@api_bp.delete("/load-balancers/<lb_id>")
def delete_load_balancer(lb_id: str):
    return jsonify({"ok": True, "state": simulator.delete_load_balancer(lb_id)})


@api_bp.post("/simulate")
def simulate():
    payload = request.get_json(silent=True) or {}
    return jsonify({"ok": True, "state": simulator.simulate(payload)})


@api_bp.get("/sql/status")
def sql_status():
    return jsonify({"ok": True, "sql": postgres_service.status()})


@api_bp.post("/sql/execute")
def sql_execute():
    payload = request.get_json(silent=True) or {}
    return jsonify(
        {
            "ok": True,
            "result": postgres_service.execute(
                payload.get("query", ""),
                payload.get("params"),
                username=payload.get("username"),
                password=payload.get("password"),
                space=payload.get("space"),
            ),
        }
    )


@api_bp.post("/sql/accounts")
def sql_create_account():
    payload = request.get_json(silent=True) or {}
    result = postgres_service.create_account(
        username=str(payload.get("username", "")),
        password=str(payload.get("password", "")),
        space=str(payload.get("space", "")),
        role=str(payload.get("role", "admin")),
    )
    return jsonify({"ok": True, "result": result})


@api_bp.post("/sql/script")
def sql_run_script():
    payload = request.get_json(silent=True) or {}
    result = postgres_service.run_script(
        script=str(payload.get("script", "")),
        username=str(payload.get("username", "")),
        password=str(payload.get("password", "")),
        space=str(payload.get("space", "")),
    )
    return jsonify({"ok": True, "result": result})


@api_bp.post("/sql/change-password")
def sql_change_password():
    payload = request.get_json(silent=True) or {}
    result = postgres_service.change_password(
        username=str(payload.get("username", "")),
        space=str(payload.get("space", "")),
        old_password=str(payload.get("oldPassword", "")),
        new_password=str(payload.get("newPassword", "")),
    )
    return jsonify({"ok": True, "result": result})


@api_bp.post("/sql/set-role")
def sql_set_role():
    payload = request.get_json(silent=True) or {}
    result = postgres_service.set_role(
        target_username=str(payload.get("username", "")),
        space=str(payload.get("space", "")),
        role=str(payload.get("role", "")),
        admin_username=str(payload.get("adminUsername", "")),
        admin_password=str(payload.get("adminPassword", "")),
    )
    return jsonify({"ok": True, "result": result})


@api_bp.get("/sql/real/status")
def sql_real_status():
    return jsonify({"ok": True, "result": real_postgres_service.status()})


@api_bp.post("/sql/real/provision")
def sql_real_provision():
    payload = request.get_json(silent=True) or {}
    result = real_postgres_service.provision_space(
        space=str(payload.get("space", "")),
        username=payload.get("username"),
        password=payload.get("password"),
        database=payload.get("database"),
    )
    return jsonify({"ok": True, "result": result})


@api_bp.post("/sql/real/change-password")
def sql_real_change_password():
    payload = request.get_json(silent=True) or {}
    result = real_postgres_service.change_password_self(
        username=str(payload.get("username", "")),
        old_password=str(payload.get("oldPassword", "")),
        new_password=str(payload.get("newPassword", "")),
        database=str(payload.get("database", "")),
    )
    return jsonify({"ok": True, "result": result})


@api_bp.get("/mongo/status")
def mongo_status():
    return jsonify({"ok": True, "mongo": mongo_service.status()})


@api_bp.post("/mongo/execute")
def mongo_execute():
    payload = request.get_json(silent=True) or {}
    return jsonify({"ok": True, "result": mongo_service.execute(payload)})


@api_bp.get("/dns/records")
def dns_records():
    return jsonify({"ok": True, "records": database.get_all_dns_records()})


@api_bp.route("/<path:_ignored>", methods=["OPTIONS"])
def api_options(_ignored: str):
    return ("", 204)
