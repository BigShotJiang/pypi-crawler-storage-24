﻿from __future__ import annotations

import json
import urllib.error
import urllib.request
from pathlib import Path
import sys

from flask import Response, jsonify, request

_BACKEND_ROOT = Path(__file__).resolve().parents[1]
if str(_BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(_BACKEND_ROOT))

try:
    import database
except ImportError:
    from .. import database


def _extract_vm_id_from_localhost_path(path: str) -> str | None:
    internal_prefixes = [
        "/api/vms",
        "/api/load-balancers",
        "/api/state",
        "/api/simulate",
        "/api/sql",
        "/api/mongo",
        "/api/dns",
    ]
    host = request.host.split(":")[0]
    if host not in {"localhost", "127.0.0.1"}:
        return None
    if any(path.startswith(p) for p in internal_prefixes):
        return None

    vms = database.get_all_vms()
    for vm in vms:
        if not vm.get("isExposed"):
            continue
        apis = vm.get("apis", [])
        if isinstance(apis, str):
            try:
                apis = json.loads(apis)
            except Exception:
                apis = []
        for api in apis:
            if api.get("path") == path:
                return vm["id"]

    exposed = [vm for vm in vms if vm.get("isExposed")]
    if len(exposed) == 1:
        return exposed[0]["id"]
    return None


def _extract_vm_id() -> str | None:
    host = request.host.split(":")[0]
    if host.endswith(".cloudsim.local") and host != "localhost":
        subdomain = host.split(".")[0]
        return subdomain.split("-")[-1]
    return _extract_vm_id_from_localhost_path(request.path)


def internal_dns_proxy():
    vm_id = _extract_vm_id()
    if not vm_id:
        return None

    vm = database.get_vm(vm_id)
    if not vm:
        return jsonify({"ok": False, "error": f"Domain {request.host} not found."}), 404
    if not vm.get("isExposed"):
        return (
            jsonify(
                {
                    "ok": False,
                    "error": f"ACCESS BLOCKED: The VM {vm_id} has not been exposed.",
                    "remedy": f"Run 'cloudsim expose {vm_id}' to allow public traffic.",
                }
            ),
            403,
        )

    port = vm.get("reservedPort") or vm.get("reserved_port")
    if not port:
        return jsonify({"ok": False, "error": f"VM {vm_id} exists but has no reserved port assigned."}), 500

    path = request.full_path if request.query_string else request.path

    runtime_mode = vm.get("runtimeMode") or vm.get("runtime_mode")
    if runtime_mode == "profile":
        return jsonify({
            "ok": True, 
            "message": f"Hello from simulated backend profile '{vm.get('backendProfileId') or vm.get('backend_profile_id', 'unknown')}'!",
            "vmId": vm_id,
            "path": path,
            "mode": "profile"
        })

    target_url = f"http://127.0.0.1:{port}{path}"

    try:
        proxy_req = urllib.request.Request(
            target_url,
            data=request.get_data() if request.method in ["POST", "PUT"] else None,
            method=request.method,
        )
        for key, value in request.headers.items():
            if key.lower() not in ["host", "content-length"]:
                proxy_req.add_header(key, value)

        with urllib.request.urlopen(proxy_req, timeout=5) as upstream:
            proxy_resp = Response(upstream.read(), status=upstream.status)
            for key, value in upstream.headers.items():
                if key.lower() not in ["content-encoding", "transfer-encoding", "connection", "content-length"]:
                    proxy_resp.headers[key] = value
            return proxy_resp
    except urllib.error.HTTPError as error:
        return Response(error.read(), status=error.code)
    except Exception as error:
        return jsonify({"ok": False, "error": f"Gateway Error: Could not reach internal VM at port {port}. {error}"}), 502


def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response
