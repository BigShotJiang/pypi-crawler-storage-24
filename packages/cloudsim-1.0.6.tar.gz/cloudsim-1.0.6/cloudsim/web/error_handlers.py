﻿from __future__ import annotations

import traceback
from flask import jsonify


def register_error_handlers(app, simulation_error_cls):
    @app.errorhandler(PermissionError)
    def handle_permission_error(error: PermissionError):
        return jsonify({"ok": False, "error": str(error)}), 403

    @app.errorhandler(ValueError)
    def handle_value_error(error: ValueError):
        return jsonify({"ok": False, "error": str(error)}), 400

    @app.errorhandler(simulation_error_cls)
    def handle_simulation_error(error):
        return jsonify({"ok": False, "error": error.message}), error.status_code

    @app.errorhandler(Exception)
    def handle_unexpected_error(error: Exception):
        traceback.print_exc()
        return jsonify({"ok": False, "error": f"{type(error).__name__}: {str(error)}"}), 500
