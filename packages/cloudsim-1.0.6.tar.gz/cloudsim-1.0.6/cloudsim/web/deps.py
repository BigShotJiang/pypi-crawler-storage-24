﻿from __future__ import annotations

from pathlib import Path
import sys

_BACKEND_ROOT = Path(__file__).resolve().parents[1]
if str(_BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(_BACKEND_ROOT))

try:
    from simulator import CloudSimulator
    from services.mongo_service import MongoService
    from services.postgres_service import PostgresService
    from services.real_postgres_service import RealPostgresService
except ImportError:
    from ..simulator import CloudSimulator
    from ..services.mongo_service import MongoService
    from ..services.postgres_service import PostgresService
    from ..services.real_postgres_service import RealPostgresService

simulator = CloudSimulator()
postgres_service = PostgresService()
real_postgres_service = RealPostgresService()
mongo_service = MongoService()
