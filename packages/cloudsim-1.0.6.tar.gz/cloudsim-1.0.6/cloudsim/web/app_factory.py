﻿from __future__ import annotations

from flask import Flask

from cloudsim.simulator import SimulationError
from cloudsim.paths import workspace_root
from cloudsim.web.env_loader import load_env_file
from cloudsim.web.error_handlers import register_error_handlers
from cloudsim.web.middleware import add_cors_headers, internal_dns_proxy
from cloudsim.web.routes_api import api_bp

# Load <workspace>/.env before services read os.environ.
# This keeps configuration editable for users (no need to modify site-packages).
load_env_file(workspace_root() / ".env")


def create_app() -> Flask:
    app = Flask(__name__)
    app.register_blueprint(api_bp)
    app.before_request(internal_dns_proxy)
    app.after_request(add_cors_headers)
    register_error_handlers(app, SimulationError)

    # Startup diagnostic: real PostgreSQL connectivity.
    try:
        from cloudsim.web.deps import real_postgres_service

        status = real_postgres_service.status()
        if status.get("available"):
            print(
                "Real PostgreSQL check: CONNECTED "
                f"host={status.get('host')} port={status.get('port')} adminUser={status.get('adminUser')} adminDb={status.get('adminDb')}"
            )
        else:
            print(
                "Real PostgreSQL check: NOT CONNECTED "
                f"host={status.get('host')} port={status.get('port')} adminUser={status.get('adminUser')} adminDb={status.get('adminDb')} error={status.get('error')}"
            )
    except Exception as exc:
        print(f"Real PostgreSQL check failed: {exc}")

    return app

