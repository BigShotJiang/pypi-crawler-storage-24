﻿from __future__ import annotations

import os
from pathlib import Path


def load_env_file(env_path: Path) -> dict[str, str]:
    """Minimal .env loader: KEY=VALUE lines, ignores comments and blanks."""
    loaded: dict[str, str] = {}
    if not env_path.exists():
        return loaded

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if not key:
            continue
        # Do not override explicit environment.
        if key not in os.environ:
            os.environ[key] = value
            loaded[key] = value
    return loaded
