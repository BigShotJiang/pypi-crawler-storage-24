import sqlite3
import json
import time
from pathlib import Path
from typing import Any, List, Optional

from . import paths
from .services.sqlite_utils import connect_sqlite

def get_connection():
    db_path = paths.simulation_db_path()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = connect_sqlite(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    c = conn.cursor()
    
    # VMs table
    c.execute('''
        CREATE TABLE IF NOT EXISTS vms (
            id TEXT PRIMARY KEY,
            name TEXT,
            region TEXT,
            machine_type TEXT,
            image TEXT,
            status TEXT,
            created_at TEXT,
            reserved_port INTEGER,
            backend_profile_id TEXT,
            backend_profile_name TEXT,
            backend_runtime TEXT,
            backend_description TEXT,
            apis JSON,
            sample_code TEXT,
            runtime_mode TEXT,
            script_path TEXT,
            script_status TEXT,
            vm_dir TEXT,
            auto_scaled BOOLEAN,
            auto_scaled_from_vm_id TEXT,
            auto_scaled_for_lb_id TEXT,
            auto_scaled_for_lb TEXT,
            request_limit INTEGER,
            isExposed BOOLEAN DEFAULT 0,
            meta_created_ts REAL,
            meta_ready_at REAL
        )
    ''')
    
    # Load Balancers table
    c.execute('''
        CREATE TABLE IF NOT EXISTS load_balancers (
            id TEXT PRIMARY KEY,
            name TEXT,
            type TEXT,
            region TEXT,
            status TEXT,
            frontend_port INTEGER,
            request_limit INTEGER,
            distribution_algorithm_id TEXT,
            auto_scale_profile_id TEXT,
            queue_service_tier TEXT,
            cloud_armor_policy_id TEXT,
            backend_vm_ids JSON,
            created_at TEXT,
            min_vm_count INTEGER,
            meta_rr_index INTEGER,
            meta_queue_depth INTEGER,
            meta_idle_cycles INTEGER,
            meta_least_connections JSON
        )
    ''')
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS dns_records (
            domain TEXT PRIMARY KEY,
            targetType TEXT,
            targetId TEXT,
            createdAt REAL
        )
    ''')
    
    conn.commit()
    conn.close()

def save_dns_record(domain: str, target_type: str, target_id: str):
    conn = get_connection()
    c = conn.cursor()
    c.execute('INSERT OR REPLACE INTO dns_records VALUES (?, ?, ?, ?)', 
              (domain, target_type, target_id, time.time()))
    conn.commit()
    conn.close()

def delete_dns_record(domain: str):
    conn = get_connection()
    c = conn.cursor()
    c.execute('DELETE FROM dns_records WHERE domain = ?', (domain,))
    conn.commit()
    conn.close()

def get_all_dns_records():
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM dns_records')
    records = []
    for row in c.fetchall():
        records.append({
            "domain": row[0],
            "targetType": row[1],
            "targetId": row[2],
            "createdAt": row[3]
        })
    conn.close()
    return records

def save_vm(vm: dict[str, Any]):
    conn = get_connection()
    c = conn.cursor()
    c.execute('''
        INSERT OR REPLACE INTO vms VALUES (
            :id, :name, :region, :machineType, :image, :status, :createdAt, :reservedPort,
            :backendProfileId, :backendProfileName, :backendRuntime, :backendDescription,
            :apis, :sampleCode, :runtimeMode, :scriptPath, :scriptStatus, :_vmDir,
            :autoScaled, :autoScaledFromVmId, :autoScaledForLbId, :autoScaledForLb,
            :requestLimit, :isExposed, :_createdTs, :_readyAt
        )
    ''', {
        **vm,
        "apis": json.dumps(vm.get("apis", [])),
        "autoScaled": 1 if vm.get("autoScaled") else 0,
        "isExposed": 1 if vm.get("isExposed") else 0,
        "_vmDir": vm.get("_vmDir"),
        # Ensure optional fields have defaults if missing
        "autoScaledFromVmId": vm.get("autoScaledFromVmId"),
        "autoScaledForLbId": vm.get("autoScaledForLbId"),
        "autoScaledForLb": vm.get("autoScaledForLb"),
        "scriptPath": vm.get("scriptPath"),
        "scriptStatus": vm.get("scriptStatus"),
    })
    conn.commit()
    conn.close()

def delete_vm(vm_id: str):
    conn = get_connection()
    conn.execute("DELETE FROM vms WHERE id = ?", (vm_id,))
    conn.commit()
    conn.close()

def set_vm_exposure(vm_id: str, exposed: bool):
    conn = get_connection()
    c = conn.cursor()
    c.execute('UPDATE vms SET isExposed = ? WHERE id = ?', (1 if exposed else 0, vm_id))
    conn.commit()
    conn.close()

def get_vm(vm_id: str) -> Optional[dict[str, Any]]:
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM vms WHERE id = ?', (vm_id,))
    row = c.fetchone()
    conn.close()
    if row:
        return dict(row)
    return None

def get_all_vms() -> List[dict[str, Any]]:
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM vms")
    rows = c.fetchall()
    vms = []
    for row in rows:
        d = dict(row)
        d["apis"] = json.loads(d["apis"] or "[]")
        d["autoScaled"] = bool(d.get("auto_scaled"))
        d["isExposed"] = bool(d.get("isExposed"))
        # Map snake_case back to camelCase for app compatibility
        vm = {
            "id": d["id"],
            "name": d["name"],
            "region": d["region"],
            "machineType": d["machine_type"],
            "image": d["image"],
            "status": d["status"],
            "createdAt": d["created_at"],
            "reservedPort": d["reserved_port"],
            "backendProfileId": d["backend_profile_id"],
            "backendProfileName": d["backend_profile_name"],
            "backendRuntime": d["backend_runtime"],
            "backendDescription": d["backend_description"],
            "apis": d["apis"],
            "sampleCode": d["sample_code"],
            "runtimeMode": d["runtime_mode"],
            "scriptPath": d["script_path"],
            "scriptStatus": d["script_status"],
            "_vmDir": d["vm_dir"],
            "autoScaled": d["autoScaled"],
            "autoScaledFromVmId": d["auto_scaled_from_vm_id"],
            "autoScaledForLbId": d["auto_scaled_for_lb_id"],
            "autoScaledForLb": d["auto_scaled_for_lb"],
            "requestLimit": d["request_limit"],
            "isExposed": d["isExposed"],
            "_createdTs": d["meta_created_ts"],
            "_readyAt": d["meta_ready_at"],
        }
        vms.append(vm)
    conn.close()
    return vms

def save_lb(lb: dict[str, Any]):
    conn = get_connection()
    c = conn.cursor()
    c.execute('''
        INSERT OR REPLACE INTO load_balancers VALUES (
            :id, :name, :type, :region, :status, :frontendPort, :requestLimit,
            :distributionAlgorithmId, :autoScaleProfileId, :queueServiceTier, :cloudArmorPolicyId,
            :backendVmIds, :createdAt, :minVmCount, :_rrIndex, :_queueDepth, :_idleCycles, :_leastConnections
        )
    ''', {
        **lb,
        "backendVmIds": json.dumps(lb.get("backendVmIds", [])),
        "_leastConnections": json.dumps(lb.get("_leastConnections", {}))
    })
    conn.commit()
    conn.close()

def delete_lb(lb_id: str):
    conn = get_connection()
    conn.execute("DELETE FROM load_balancers WHERE id = ?", (lb_id,))
    conn.commit()
    conn.close()

def get_all_lbs() -> List[dict[str, Any]]:
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM load_balancers")
    rows = c.fetchall()
    lbs = []
    for row in rows:
        d = dict(row)
        lb = {
            "id": d["id"],
            "name": d["name"],
            "type": d["type"],
            "region": d["region"],
            "status": d["status"],
            "frontendPort": d["frontend_port"],
            "requestLimit": d["request_limit"],
            "distributionAlgorithmId": d["distribution_algorithm_id"],
            "autoScaleProfileId": d["auto_scale_profile_id"],
            "queueServiceTier": d["queue_service_tier"],
            "cloudArmorPolicyId": d["cloud_armor_policy_id"],
            "backendVmIds": json.loads(d["backend_vm_ids"] or "[]"),
            "createdAt": d["created_at"],
            "minVmCount": d["min_vm_count"],
            "_rrIndex": d["meta_rr_index"],
            "_queueDepth": d["meta_queue_depth"],
            "_idleCycles": d["meta_idle_cycles"],
            "_leastConnections": json.loads(d["meta_least_connections"] or "{}")
        }
        lbs.append(lb)
    conn.close()
    return lbs

def create_local_vm_db(vm_dir: Path, vm_data: dict[str, Any]):
    db_path = vm_dir / "vm_state.db"
    try:
        conn = connect_sqlite(db_path)
        c = conn.cursor()
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS info (
                key TEXT PRIMARY KEY,
                value TEXT
            )
            """
        )

        params: list[tuple[str, str]] = []
        for k, v in (vm_data or {}).items():
            if str(k).startswith("_"):
                continue  # Skip internal fields
            val_str = json.dumps(v) if isinstance(v, (dict, list)) else str(v)
            params.append((str(k), val_str))

        if params:
            c.executemany("INSERT OR REPLACE INTO info VALUES (?, ?)", params)
        conn.commit()
        conn.close()
    except Exception as e:
        # Keep the simulator running, but make sure the file exists so tooling can rely on it.
        try:
            fallback = sqlite3.connect(db_path)
            fallback.execute("CREATE TABLE IF NOT EXISTS info (key TEXT PRIMARY KEY, value TEXT)")
            fallback.commit()
            fallback.close()
        except Exception:
            pass
        print(f"Failed to create local VM DB: {e}")
