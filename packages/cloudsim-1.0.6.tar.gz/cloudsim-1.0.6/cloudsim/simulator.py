from __future__ import annotations

import atexit
import copy
import secrets
import shutil
import time
from pathlib import Path
from threading import RLock
from typing import Any


try:
    from . import database
    from .services.autoscaler_service import autoscale_down, autoscale_up
    from .services.cloud_armor_service import CloudArmorService
    from .services.constants import (
        AUTO_SCALE_PROFILE_BY_ID,
        AUTO_SCALE_PROFILES,
        BACKEND_PROFILES,
        CLOUD_ARMOR_POLICIES,
        LB_DISTRIBUTION_ALGORITHMS,
        LB_PORT_START,
        LB_REGIONS,
        LB_REQUEST_LIMITS,
        LB_TYPES,
        MAX_LOGS,
        MAX_SIMULATED_REQUESTS,
        QUEUE_SERVICE_TIERS,
        VM_IMAGES,
        VM_MACHINE_TYPES,
        VM_PORT_START,
        VM_REGIONS,
        VM_REQUEST_LIMIT,
        VM_RUNTIME_MODES,
    )
    from .services.errors import SimulationError
    from .services.load_balancer_service import (
        create_load_balancer,
        distribute_requests,
        sync_load_balancer_statuses,
    )
    from .services.request_queue_service import apply_queue
    from .services.routing_service import average_latency_ms, distribution_text
    from .services.script_runtime_service import ScriptRuntimeService
    from .services.time_utils import now_stamp
    from .services.vm_sqlite_service import ensure_vm_sqlite_db
    from .services.vm_service import create_autoscaled_vm, create_vm, sync_vm_statuses
    from . import paths
except ImportError:
    import database
    from services.autoscaler_service import autoscale_down, autoscale_up
    from services.cloud_armor_service import CloudArmorService
    from services.constants import (
        AUTO_SCALE_PROFILE_BY_ID,
        AUTO_SCALE_PROFILES,
        BACKEND_PROFILES,
        CLOUD_ARMOR_POLICIES,
        LB_DISTRIBUTION_ALGORITHMS,
        LB_PORT_START,
        LB_REGIONS,
        LB_REQUEST_LIMITS,
        LB_TYPES,
        MAX_LOGS,
        MAX_SIMULATED_REQUESTS,
        QUEUE_SERVICE_TIERS,
        VM_IMAGES,
        VM_MACHINE_TYPES,
        VM_PORT_START,
        VM_REGIONS,
        VM_REQUEST_LIMIT,
        VM_RUNTIME_MODES,
    )
    from services.errors import SimulationError
    from services.load_balancer_service import (
        create_load_balancer,
        distribute_requests,
        sync_load_balancer_statuses,
    )
    from services.request_queue_service import apply_queue
    from services.routing_service import average_latency_ms, distribution_text
    from services.script_runtime_service import ScriptRuntimeService
    from services.time_utils import now_stamp
    from services.vm_sqlite_service import ensure_vm_sqlite_db
    from services.vm_service import create_autoscaled_vm, create_vm, sync_vm_statuses
    import paths


class CloudSimulator:
    def __init__(self) -> None:
        self._lock = RLock()
        database.init_db()
        self._vms: list[dict[str, Any]] = database.get_all_vms()
        self._lbs: list[dict[str, Any]] = database.get_all_lbs()
        
        # Calculate next ports based on max used
        max_vm_port = max((vm.get("reservedPort", 0) for vm in self._vms), default=VM_PORT_START - 1)
        self._next_vm_port = max(VM_PORT_START, max_vm_port + 1)
        
        max_lb_port = max((lb.get("frontendPort", 0) for lb in self._lbs), default=LB_PORT_START - 1)
        self._next_lb_port = max(LB_PORT_START, max_lb_port + 1)

        self._logs: list[str] = []
        self._last_traffic_result: dict[str, Any] | None = None
        self._cloud_armor = CloudArmorService()
        self._autoscaling_enabled = True
        self._backend_root = Path(__file__).resolve().parent
        self._repo_root = paths.workspace_root()
        self._script_runtime = ScriptRuntimeService(self._backend_root, self._push_log, repo_root=self._repo_root)
        # Scale-down runs opportunistically when callers poll state.
        self._scale_down_cooldown_seconds = 8.0
        atexit.register(self.shutdown)
        self._push_log(
            "Welcome. Step 1: create VM + backend API profile. Step 2: create load balancer. Step 3: simulate API traffic."
        )
        
        # Restore running scripts
        for vm in self._vms:
            if vm.get("status") == "running":
                # Ensure script status is reset if process is gone
                vm["scriptStatus"] = "pending"
                vm["_scriptStarted"] = False
                self._on_vm_running(vm)

    def shutdown(self) -> None:
        with self._lock:
            for vm in self._vms:
                self._script_runtime.stop_for_vm(vm)

    def get_state(self) -> dict[str, Any]:
        with self._lock:
            self._sync_statuses()
            return self._serialize_state()

    def create_vm(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            self._sync_statuses()
            vm = create_vm(payload, self._reserve_vm_port, self._new_id, now_stamp)
            
            # Create VM directory in repo root
            vm_dir = paths.vms_dir() / vm["id"]
            vm_dir.mkdir(parents=True, exist_ok=True)
            try:
                vm["_vmDir"] = str(vm_dir.relative_to(self._repo_root))
            except ValueError:
                vm["_vmDir"] = str(vm_dir)
            # Always create local state DB and per-VM SQLite instance.
            database.create_local_vm_db(vm_dir, vm)
            ensure_vm_sqlite_db(vm_dir)
            
            # Setup script if applicable
            if vm.get("runtimeMode") == "python_script" and vm.get("scriptPath"):
                original_script = Path(vm["scriptPath"])
                if not original_script.is_absolute():
                    candidates = [
                        self._repo_root / original_script,
                        self._backend_root / original_script
                    ]
                    found = None
                    for c in candidates:
                        if c.exists():
                            found = c
                            break
                    if found:
                        original_script = found
                
                if original_script.exists():
                    target_script = vm_dir / original_script.name
                    shutil.copy2(original_script, target_script)
                    try:
                        vm["scriptPath"] = str(target_script.relative_to(self._repo_root))
                        vm["_vmDir"] = str(vm_dir.relative_to(self._repo_root))
                    except ValueError:
                        vm["scriptPath"] = str(target_script)
                        vm["_vmDir"] = str(vm_dir)

                    # Copy SDK
                    sdk_source = self._backend_root / "services" / "vm_sdk_source.py"
                    if sdk_source.exists():
                        target_sdk = vm_dir / "cloud_sdk.py"
                        shutil.copy2(sdk_source, target_sdk)
                        
                    self._push_log(f'VM "{vm["name"]}" workspace created at {vm_dir.name}')
                else:
                    self._push_log(f'Warning: VM script not found at {original_script}')

            self._vms.insert(0, vm)
            database.save_vm(vm)
            mode_note = (
                f', script "{vm["scriptPath"]}"' if vm.get("runtimeMode") == "python_script" else ""
            )
            self._push_log(
                f'VM "{vm["name"]}" provisioning in {vm["region"]} ({vm["machineType"]}, port {vm["reservedPort"]}, {vm["backendProfileName"]}, mode {vm.get("runtimeMode")}{mode_note})'
            )

            # Register internal DNS
            domain = f"{vm['name']}-{vm['id']}.{vm['region']}.cloudsim.local"
            try:
                database.save_dns_record(domain, "vm", vm["id"])
            except Exception as e:
                print(f"Failed to save DNS record: {e}")

            return self._serialize_state()

    def create_load_balancer(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            self._sync_statuses()
            lb = create_load_balancer(payload, self._vms, self._reserve_lb_port, self._new_id, now_stamp)
            self._lbs.insert(0, lb)
            database.save_lb(lb)
            profile = AUTO_SCALE_PROFILE_BY_ID[lb["autoScaleProfileId"]]
            self._push_log(
                f'Load balancer "{lb["name"]}" provisioning on port {lb["frontendPort"]} with {len(lb["backendVmIds"])} backend(s), algo {lb["distributionAlgorithmId"]}, scale profile {profile["label"]}, queue {lb["queueServiceTier"]}, cloud armor {lb["cloudArmorPolicyId"]}'
            )

            # Register internal DNS
            domain = f"{lb['name'].lower().replace(' ', '-')}.{lb['region']}.cloudsim.local"
            try:
                database.save_dns_record(domain, "lb", lb["id"])
            except Exception as e:
                print(f"Failed to save DNS record: {e}")

            return self._serialize_state()

    def delete_load_balancer(self, lb_id: str) -> dict[str, Any]:
        with self._lock:
            self._sync_statuses()
            lb = next((l for l in self._lbs if l["id"] == lb_id or l["name"] == lb_id), None)
            if lb:
                # Cleanup DNS
                domain = f"{lb['name'].lower().replace(' ', '-')}.{lb['region']}.cloudsim.local"
                try:
                    database.delete_dns_record(domain)
                except:
                    pass
                
                # Cleanup autoscaled VMs for this LB
                autoscaled_vms = [
                    vm for vm in self._vms 
                    if vm.get("autoScaled") and vm.get("autoScaledForLbId") == lb_id
                ]
                for vm in autoscaled_vms:
                    self._remove_vm(vm["id"])
                
                self._lbs = [l for l in self._lbs if l["id"] != lb_id]
                database.delete_lb(lb_id)
                self._push_log(f'Load balancer "{lb["name"]}" (id {lb_id}) deleted')
            return self._serialize_state()

    def delete_vm(self, vm_id: str) -> dict[str, Any]:
        with self._lock:
            self._sync_statuses()
            vm = self._find_vm(vm_id)
            if vm:
                self._remove_vm(vm_id)
                self._push_log(f'VM "{vm["name"]}" deleted.')
            return self._serialize_state()

    def update_vm_script(self, vm_id: str, script_path: str) -> dict[str, Any]:
        with self._lock:
            self._sync_statuses()
            vm = self._find_vm(vm_id)
            if vm:
                # Stop existing process
                self._script_runtime.stop_for_vm(vm)
                
                # Update script path
                vm["scriptPath"] = script_path
                # We need to reset the resolved path so it resolves again (if logic allows? 
                # looking at script_runtime_service.py might reveal if it caches or uses helper.
                # Assuming start_for_vm re-evaluates or uses vm["scriptPath"]. 
                # Let's hope start_for_vm handles path resolution or assumes relative.
                # Actually, `ScriptRuntimeService.start_for_vm` likely uses `vm["scriptPath"]`.
                
                # If VM is supposed to be running, restart it
                if vm["status"] == "running":
                    self._on_vm_running(vm)
                    
                self._push_log(f'VM "{vm["name"]}" script updated to "{script_path}"')
            return self._serialize_state()

    def expose_vm(self, vm_id: str, exposed: bool) -> dict[str, Any]:
        with self._lock:
            self._sync_statuses()
            vm = self._find_vm(vm_id)
            if vm:
                vm["isExposed"] = exposed
                database.set_vm_exposure(vm["id"], exposed)
                status = "exposed" if exposed else "blocked"
                self._push_log(f'VM "{vm["name"]}" public access is now {status}')
            return self._serialize_state()

    def simulate(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            self._sync_statuses()
            lb_id = str(payload.get("lbId", ""))
            endpoint_key = str(payload.get("endpointKey", ""))
            client_id = str(payload.get("clientId", "demo-client")).strip() or "demo-client"
            requests = payload.get("requests")

            try:
                requested = int(requests)
            except (TypeError, ValueError):
                raise SimulationError("Traffic simulation blocked: enter a valid request count")

            if requested < 1:
                raise SimulationError("Traffic simulation blocked: enter a valid request count")
            if requested > MAX_SIMULATED_REQUESTS:
                raise SimulationError(
                    f"Traffic simulation blocked: max {MAX_SIMULATED_REQUESTS:,} requests per run"
                )

            lb = next((item for item in self._lbs if (item["id"] == lb_id or item["name"] == lb_id) and item["status"] == "active"), None)
            if not lb:
                raise SimulationError("Traffic simulation blocked: choose an active load balancer")

            backend_vms = self._running_backends(lb)
            if not backend_vms:
                raise SimulationError(f'Traffic simulation blocked: LB "{lb["name"]}" has no running backends')

            endpoint_options = self._endpoint_options_for_backends(backend_vms)
            endpoint = endpoint_options.get(endpoint_key)
            if not endpoint:
                raise SimulationError(f'Traffic simulation blocked: LB "{lb["name"]}" has no selectable API endpoints')

            armor_result = self._cloud_armor.evaluate(lb, client_id, requested, time.time())
            allowed_incoming = armor_result["allowed"]
            blocked_by_armor = armor_result["blocked"]
            if blocked_by_armor > 0:
                self._push_log(
                    f'Cloud Armor: blocked {blocked_by_armor:,} request(s) for client "{armor_result["clientId"]}" on policy {armor_result["policyLabel"]}. {armor_result["reason"]}'
                )

            previous_queue_depth = int(lb.get("_queueDepth", 0))
            demand = previous_queue_depth + allowed_incoming
            lb_accepted = min(demand, lb["requestLimit"])
            lb_overflow = demand - lb_accepted

            compatible_backends = self._compatible_backends(backend_vms, endpoint)
            vm_capacity_before_autoscale = len(compatible_backends) * VM_REQUEST_LIMIT
            vm_rejected_before_autoscale = max(lb_accepted - vm_capacity_before_autoscale, 0)

            autoscaled_vms: list[dict[str, Any]] = []
            autoscale_hit_cap = False
            if self._autoscaling_enabled:
                autoscaled_vms, autoscale_hit_cap = autoscale_up(
                    lb=lb,
                    compatible_backends=compatible_backends,
                    vm_rejected_before_autoscale=vm_rejected_before_autoscale,
                    create_autoscaled_vm=lambda template, lb_i, lb_name: create_autoscaled_vm(
                        template,
                        lb_i,
                        lb_name,
                        self._reserve_vm_port,
                        self._new_id,
                        now_stamp,
                    ),
                )

            if autoscaled_vms:
                for vm in autoscaled_vms:
                    self._prepare_autoscaled_vm_workspace(vm)
                self._vms[0:0] = autoscaled_vms
                lb["backendVmIds"].extend(vm["id"] for vm in autoscaled_vms)
                for vm in autoscaled_vms:
                    self._on_vm_running(vm)
                ports = ", ".join(str(vm["reservedPort"]) for vm in autoscaled_vms)
                profile = AUTO_SCALE_PROFILE_BY_ID[lb["autoScaleProfileId"]]
                self._push_log(
                    f'Auto scaling: LB "{lb["name"]}" added {len(autoscaled_vms)} VM(s) on ports {ports}. maxVmCount={profile["maxVmCount"]}'
                )

            if autoscale_hit_cap:
                profile = AUTO_SCALE_PROFILE_BY_ID[lb["autoScaleProfileId"]]
                self._push_log(
                    f'Auto scaling max VM count reached ({profile["maxVmCount"]}). Remaining overflow may still be rejected.'
                )

            backend_vms = self._running_backends(lb)
            compatible_backends = self._compatible_backends(backend_vms, endpoint)
            vm_capacity_after_autoscale = len(compatible_backends) * VM_REQUEST_LIMIT
            served = min(lb_accepted, vm_capacity_after_autoscale)
            vm_overflow = lb_accepted - served

            distribution_usage, distribution_meta = distribute_requests(lb, compatible_backends, served)
            rr_start = int(distribution_meta.get("startIndex", 0))
            rr_end = int(distribution_meta.get("endIndex", 0))
            algorithm_id = distribution_meta.get(
                "algorithmId", lb.get("distributionAlgorithmId", "round_robin")
            )

            vm_usage = {vm["id"]: 0 for vm in backend_vms}
            vm_usage.update(distribution_usage)

            avg_latency = average_latency_ms(compatible_backends, endpoint["latencyMs"])
            autoscaled_total_for_lb = self._autoscaled_total_for_lb(backend_vms, lb["id"])

            queue_input = lb_overflow + vm_overflow
            queue_result = apply_queue(lb, queue_input, autoscaled_total_for_lb, self._autoscaling_enabled)
            if queue_result["queued"] > 0:
                self._push_log(
                    f'Request queue: queued {queue_result["queued"]:,} request(s) for LB "{lb["name"]}" (tier={queue_result["tier"]}, capacity={queue_result["capacity"]:,}).'
                )
            if queue_result["dropped"] > 0:
                if queue_result["tier"] == "paid":
                    self._push_log(
                        f'Request queue full: dropped {queue_result["dropped"]:,} request(s) for LB "{lb["name"]}". Increase queue tier/capacity or scale resources.'
                    )
                else:
                    self._push_log(
                        f'Request queue full: queue service disabled, dropped {queue_result["dropped"]:,} request(s) for LB "{lb["name"]}".'
                    )

            utilization = served / vm_capacity_after_autoscale if vm_capacity_after_autoscale > 0 else 0.0
            # Store last-traffic metadata for idle scale-down.
            lb["_lastTrafficAt"] = time.time()
            lb["_lastUtilization"] = utilization
            removed_vms = autoscale_down(
                lb=lb,
                backend_vms=backend_vms,
                utilization=utilization,
                queue_depth=queue_result["queued"],
                remove_vm=self._remove_vm,
                min_vm_count=int(lb.get("minVmCount", 1) or 1),
            )
            if removed_vms:
                removed_ports = ", ".join(str(vm["reservedPort"]) for vm in removed_vms)
                self._push_log(
                    f'Scale down: LB "{lb["name"]}" removed {len(removed_vms)} auto-scaled VM(s) on ports {removed_ports}.'
                )

            backend_vms_after_scale_down = self._running_backends(lb)
            autoscaled_total_for_lb = self._autoscaled_total_for_lb(backend_vms_after_scale_down, lb["id"])

            rejected = blocked_by_armor + queue_result["dropped"]
            rr_text = distribution_text(compatible_backends, distribution_usage)

            result = {
                "lbId": lb["id"],
                "endpointKey": endpoint["key"],
                "endpointMethod": endpoint["method"],
                "endpointPath": endpoint["path"],
                "clientId": armor_result["clientId"],
                "requested": requested,
                "allowedByCloudArmor": allowed_incoming,
                "blockedByCloudArmor": blocked_by_armor,
                "served": served,
                "rejected": rejected,
                "lbOverflow": lb_overflow,
                "vmOverflow": vm_overflow,
                "vmRejectedBeforeAutoscale": vm_rejected_before_autoscale,
                "vmUsage": vm_usage,
                "compatibleBackends": len(compatible_backends),
                "totalBackends": len(backend_vms_after_scale_down),
                "avgLatencyMs": avg_latency,
                "autoscalingEnabled": self._autoscaling_enabled,
                "autoscaleProfileId": lb["autoScaleProfileId"],
                "autoscaledCount": len(autoscaled_vms),
                "autoscaledVmIds": [vm["id"] for vm in autoscaled_vms],
                "autoscaledPorts": [vm["reservedPort"] for vm in autoscaled_vms],
                "autoscaledTotalForLb": autoscaled_total_for_lb,
                "scaledDownCount": len(removed_vms),
                "scaledDownVmIds": [vm["id"] for vm in removed_vms],
                "scaleDownIdleCycles": int(lb.get("_idleCycles", 0)),
                "queueTier": queue_result["tier"],
                "queueCapacity": queue_result["capacity"],
                "queueDepth": queue_result["queued"],
                "queueDropped": queue_result["dropped"],
                "queueWasFull": queue_result["isFull"],
                "queueCarriedFromPrevious": previous_queue_depth,
                "cloudArmorPolicyId": armor_result["policyId"],
                "cloudArmorPolicyLabel": armor_result["policyLabel"],
                "cloudArmorRemainingInWindow": armor_result["remainingInWindow"],
                "distributionAlgorithmId": algorithm_id,
                "roundRobinStartIndex": rr_start,
                "roundRobinEndIndex": rr_end,
                "timestamp": now_stamp(),
            }
            self._last_traffic_result = result

            self._push_log(
                f'Monitoring: LB "{lb["name"]}" routed {endpoint["method"]} {endpoint["path"]} with {len(compatible_backends)}/{len(backend_vms_after_scale_down)} compatible backend(s)'
            )
            self._push_log(
                f'Distribution monitor: LB "{lb["name"]}" algo={algorithm_id} start={rr_start} end={rr_end} autoscaledNow={len(autoscaled_vms)} autoscaledTotal={autoscaled_total_for_lb} scaledDownNow={len(removed_vms)} queueDepth={queue_result["queued"]} distribution [{rr_text}]'
            )

            if rejected == 0 and queue_result["queued"] == 0:
                self._push_log(
                    f'LB "{lb["name"]}" served all {served:,} request(s) for {endpoint["method"]} {endpoint["path"]} (avg latency {avg_latency}ms)'
                )

            return self._serialize_state()

    def _serialize_state(self) -> dict[str, Any]:
        endpoint_options_by_lb: dict[str, list[dict[str, Any]]] = {}
        for lb in self._lbs:
            backends = self._running_backends(lb)
            endpoint_options_by_lb[lb["id"]] = sorted(
                self._endpoint_options_for_backends(backends).values(),
                key=lambda item: item["key"],
            )

        return {
            "constants": {
                "vmRegions": VM_REGIONS,
                "vmMachineTypes": VM_MACHINE_TYPES,
                "vmImages": VM_IMAGES,
                "vmRuntimeModes": copy.deepcopy(VM_RUNTIME_MODES),
                "lbTypes": LB_TYPES,
                "lbRegions": LB_REGIONS,
                "lbDistributionAlgorithms": copy.deepcopy(LB_DISTRIBUTION_ALGORITHMS),
                "vmRequestLimit": VM_REQUEST_LIMIT,
                "lbRequestLimits": LB_REQUEST_LIMITS,
                "maxSimulatedRequests": MAX_SIMULATED_REQUESTS,
                "autoScalingEnabled": self._autoscaling_enabled,
                "autoScaleProfiles": copy.deepcopy(AUTO_SCALE_PROFILES),
                "queueServiceTiers": copy.deepcopy(QUEUE_SERVICE_TIERS),
                "cloudArmorPolicies": copy.deepcopy(CLOUD_ARMOR_POLICIES),
            },
            "backendProfiles": copy.deepcopy(BACKEND_PROFILES),
            "vms": [self._serialize_resource(vm) for vm in self._vms],
            "lbs": [self._serialize_resource(lb) for lb in self._lbs],
            "logs": copy.deepcopy(self._logs),
            "lastTrafficResult": copy.deepcopy(self._last_traffic_result),
            "endpointOptionsByLb": endpoint_options_by_lb,
        }

    def _serialize_resource(self, resource: dict[str, Any]) -> dict[str, Any]:
        return {key: copy.deepcopy(value) for key, value in resource.items() if not key.startswith("_")}

    def _endpoint_options_for_backends(self, backends: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        endpoint_map: dict[str, dict[str, Any]] = {}
        for vm in backends:
            for api in vm["apis"]:
                key = f'{api["method"]} {api["path"]}'
                if key not in endpoint_map:
                    endpoint_map[key] = {
                        "key": key,
                        "method": api["method"],
                        "path": api["path"],
                        "latencyMs": api["latencyMs"],
                    }
        return endpoint_map

    def _compatible_backends(self, backends: list[dict[str, Any]], endpoint: dict[str, Any]) -> list[dict[str, Any]]:
        return [
            vm
            for vm in backends
            if any(
                api["method"] == endpoint["method"] and api["path"] == endpoint["path"]
                for api in vm["apis"]
            )
        ]

    def _running_backends(self, lb: dict[str, Any]) -> list[dict[str, Any]]:
        return [
            vm
            for vm in (self._find_vm(vm_id) for vm_id in lb.get("backendVmIds", []))
            if vm and vm.get("status") == "running"
        ]

    def _autoscaled_total_for_lb(self, backends: list[dict[str, Any]], lb_id: str) -> int:
        return sum(
            1
            for vm in backends
            if vm.get("autoScaled") and vm.get("autoScaledForLbId") == lb_id
        )

    def _sync_statuses(self) -> None:
        now_ts = time.time()
        sync_vm_statuses(self._vms, now_ts, self._push_log, self._on_vm_running)
        for vm in self._vms:
            self._script_runtime.refresh_vm_runtime_status(vm)
        sync_load_balancer_statuses(self._lbs, now_ts, self._push_log)
        self._tick_scale_down(now_ts)

    def _tick_scale_down(self, now_ts: float) -> None:
        """
        Scale down auto-scaled backends after traffic cools off.

        This is intentionally simple: it runs when callers poll `/api/state` or perform
        other operations that call `_sync_statuses()`. That keeps the simulator single-process
        and avoids background threads.
        """
        for lb in self._lbs:
            if lb.get("status") != "active":
                continue
            backend_vms = self._running_backends(lb)
            autoscaled = [
                vm
                for vm in backend_vms
                if vm.get("autoScaled") and vm.get("autoScaledForLbId") == lb.get("id")
            ]
            if not autoscaled:
                continue

            last_at = float(lb.get("_lastTrafficAt", 0.0) or 0.0)
            queue_depth = int(lb.get("_queueDepth", 0) or 0)

            # Only start counting idleness after a cooldown window.
            if last_at <= 0 or (now_ts - last_at) < self._scale_down_cooldown_seconds:
                continue

            removed = autoscale_down(
                lb=lb,
                backend_vms=backend_vms,
                utilization=0.0,
                queue_depth=queue_depth,
                remove_vm=self._remove_vm,
                min_vm_count=int(lb.get("minVmCount", 1) or 1),
            )
            if removed:
                removed_ids = ", ".join(vm.get("id", "?") for vm in removed)
                self._push_log(
                    f'Autoscale scale-down: removed {len(removed)} VM(s) from LB "{lb.get("name")}" ({lb.get("id")}): {removed_ids}'
                )
                try:
                    database.save_lb(lb)
                except Exception:
                    pass

    def _on_vm_running(self, vm: dict[str, Any]) -> None:
        self._script_runtime.start_for_vm(vm)

    def _find_vm(self, vm_id: str) -> dict[str, Any] | None:
        return next((vm for vm in self._vms if vm["id"] == vm_id or vm["name"] == vm_id), None)

    def _prepare_autoscaled_vm_workspace(self, vm: dict[str, Any]) -> None:
        # Persist autoscaled VMs into a dedicated folder tree so users can inspect them.
        autoscale_root = paths.autoscale_vms_dir()
        vm_dir = autoscale_root / vm["id"]
        vm_dir.mkdir(parents=True, exist_ok=True)
        try:
            vm["_vmDir"] = str(vm_dir.relative_to(self._repo_root))
        except ValueError:
            vm["_vmDir"] = str(vm_dir)
        database.create_local_vm_db(vm_dir, vm)
        ensure_vm_sqlite_db(vm_dir)

    def _remove_vm(self, vm_id: str) -> None:
        vm = self._find_vm(vm_id)
        if vm:
            self._script_runtime.stop_for_vm(vm)

            # Cleanup DNS
            domain = f"{vm['name']}-{vm['id']}.{vm['region']}.cloudsim.local"
            try:
                database.delete_dns_record(domain)
            except:
                pass
            
            self._vms = [v for v in self._vms if v["id"] != vm_id]
            database.delete_vm(vm_id)

            # Cleanup VM directory
            vm_dir_path = vm.get("_vmDir")
            if vm_dir_path:
                try:
                    p = Path(vm_dir_path)
                    if not p.is_absolute():
                        # Resolve path (could be relative to repo root or backend root)
                        p_repo = self._repo_root / p
                        if p_repo.exists():
                             p = p_repo
                        else:
                             p = self._backend_root / p
                    
                    if p.exists():
                        import shutil
                        shutil.rmtree(p)
                except Exception as e:
                    print(f"Failed to cleanup VM dir {vm_dir_path}: {e}")

        self._vms = [item for item in self._vms if item["id"] != vm_id]
        for lb in self._lbs:
            if vm_id in lb.get("backendVmIds", []):
                lb["backendVmIds"] = [current for current in lb["backendVmIds"] if current != vm_id]
                least_map = lb.get("_leastConnections", {})
                if vm_id in least_map:
                    del least_map[vm_id]
                running = self._running_backends(lb)
                if running:
                    lb["_rrIndex"] = int(lb.get("_rrIndex", 0)) % len(running)
                else:
                    lb["_rrIndex"] = 0

    def _reserve_vm_port(self) -> int:
        port = self._next_vm_port
        self._next_vm_port += 1
        return port

    def _reserve_lb_port(self) -> int:
        port = self._next_lb_port
        self._next_lb_port += 1
        return port

    def _new_id(self) -> str:
        return secrets.token_hex(4)

    def _push_log(self, message: str) -> None:
        self._logs.insert(0, f"[{now_stamp()}] {message}")
        if len(self._logs) > MAX_LOGS:
            del self._logs[MAX_LOGS:]


__all__ = ["CloudSimulator", "SimulationError"]
