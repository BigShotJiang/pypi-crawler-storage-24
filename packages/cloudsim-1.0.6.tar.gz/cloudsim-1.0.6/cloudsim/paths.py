from __future__ import annotations

import json
import os
from pathlib import Path


def user_config_dir() -> Path:
    """
    Global per-user CloudSim config directory.

    This is intentionally *not* the same as CLOUDSIM_WORKSPACE. The workspace is where
    VMs/state live. The config dir stores small settings like the default workspace path.
    """
    return Path.home() / ".cloudsim"


def global_config_path() -> Path:
    return user_config_dir() / "config.json"


def read_global_config() -> dict:
    p = global_config_path()
    try:
        if not p.exists():
            return {}
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        # Never fail the app because a user config file is missing or invalid.
        return {}


def write_global_config(cfg: dict) -> Path:
    p = global_config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, indent=2, sort_keys=True), encoding="utf-8")
    return p


def workspace_root() -> Path:
    """
    CloudSim persists state and VM folders in a *workspace* directory (not in site-packages).

    Resolution order:
    1) CLOUDSIM_WORKSPACE (absolute or relative)
    2) ~/.cloudsim/config.json ("workspace")
    3) current working directory (Path.cwd())
    """
    val = (os.environ.get("CLOUDSIM_WORKSPACE") or "").strip()
    if val:
        return Path(val).expanduser().resolve()
    cfg = read_global_config()
    ws = (cfg.get("workspace") or "").strip() if isinstance(cfg, dict) else ""
    if ws:
        return Path(ws).expanduser().resolve()
    return Path.cwd().resolve()


def state_dir() -> Path:
    return workspace_root() / ".cloudsim"


def ensure_state_dir() -> Path:
    p = state_dir()
    p.mkdir(parents=True, exist_ok=True)
    return p


def simulation_db_path() -> Path:
    return ensure_state_dir() / "simulation.db"


def sql_service_db_path() -> Path:
    return ensure_state_dir() / "sql_service.db"


def cloudsql_profiles_path() -> Path:
    return ensure_state_dir() / ".cloudsql_real_profiles.json"


def vms_dir() -> Path:
    return workspace_root() / "vms"


def autoscale_vms_dir() -> Path:
    return workspace_root() / "autoscale-vms"
