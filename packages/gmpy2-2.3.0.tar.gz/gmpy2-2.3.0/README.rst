gmpy2 is an optimized, C-coded Python extension module that supports fast
multiple-precision arithmetic.  gmpy2 is based on the original gmpy module.
gmpy2 adds support for correctly rounded multiple-precision real arithmetic
(using the MPFR library) and complex arithmetic (using the MPC library).

Releases are available in the Python Package Index (PyPI) at
https://pypi.python.org/pypi/gmpy2/.  Documentation is available at
https://gmpy2.readthedocs.io/.
