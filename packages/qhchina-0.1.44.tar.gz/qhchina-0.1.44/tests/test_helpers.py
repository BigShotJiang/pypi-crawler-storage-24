"""
Tests for qhchina.helpers module (texts, fonts, stopwords).
"""
import pytest
from pathlib import Path


# =============================================================================
# Load Text Tests
# =============================================================================

class TestLoadText:
    """Tests for load_text and load_texts functions."""
    
    def test_load_text_basic(self, texts_dir):
        """Test loading a single text file."""
        from qhchina.helpers import load_text
        
        text_file = texts_dir / "民国_鲁迅_呐喊_1923.txt"
        text = load_text(str(text_file))
        
        assert isinstance(text, str)
        assert len(text) > 0
        assert "我" in text  # Basic Chinese character check
    
    def test_load_texts_multiple(self, texts_dir):
        """Test loading multiple text files."""
        from qhchina.helpers import load_texts
        
        files = [
            str(texts_dir / "民国_鲁迅_呐喊_1923.txt"),
            str(texts_dir / "民国_鲁迅_彷徨_1926.txt"),
        ]
        texts = load_texts(files)
        
        assert isinstance(texts, list)
        assert len(texts) == 2
        assert all(isinstance(t, str) for t in texts)
    
    def test_load_text_invalid_path(self):
        """Test that loading non-existent file raises error."""
        from qhchina.helpers import load_text
        
        with pytest.raises(FileNotFoundError):
            load_text("/nonexistent/path/file.txt")
    
    def test_load_text_invalid_filename_type(self):
        """Test that non-string filename raises ValueError."""
        from qhchina.helpers import load_text
        
        with pytest.raises(ValueError, match="filename must be a string"):
            load_text(123)
    
    def test_load_text_auto_encoding(self, texts_dir):
        """Test loading text with automatic encoding detection."""
        from qhchina.helpers import load_text
        
        text_file = texts_dir / "民国_鲁迅_呐喊_1923.txt"
        text = load_text(str(text_file), encoding="auto")
        
        assert isinstance(text, str)
        assert len(text) > 0
    
    def test_load_texts_single_string_input(self, texts_dir):
        """Test that load_texts accepts a single string path."""
        from qhchina.helpers import load_texts
        
        text_file = str(texts_dir / "民国_鲁迅_呐喊_1923.txt")
        texts = load_texts(text_file)
        
        assert isinstance(texts, list)
        assert len(texts) == 1


class TestLoadStopwords:
    """Tests for stopword loading functions."""
    
    def test_load_stopwords_simplified(self):
        """Test loading simplified Chinese stopwords."""
        from qhchina.helpers import load_stopwords
        
        stopwords = load_stopwords("zh_sim")
        
        assert isinstance(stopwords, set)
        assert len(stopwords) > 0
        assert "的" in stopwords  # Common stopword
    
    def test_load_stopwords_traditional(self):
        """Test loading traditional Chinese stopwords."""
        from qhchina.helpers import load_stopwords
        
        stopwords = load_stopwords("zh_tr")
        
        assert isinstance(stopwords, set)
        assert len(stopwords) > 0
    
    def test_load_stopwords_classical(self):
        """Test loading classical Chinese stopwords."""
        from qhchina.helpers import load_stopwords
        
        stopwords = load_stopwords("zh_cl_sim")
        
        assert isinstance(stopwords, set)
        assert len(stopwords) > 0
    
    def test_load_stopwords_invalid_language(self):
        """Test that invalid language raises ValueError."""
        from qhchina.helpers import load_stopwords
        
        with pytest.raises(ValueError, match="No stopwords files found"):
            load_stopwords("invalid_language_xyz")
    
    def test_load_stopwords_all_available(self):
        """Test loading all available stopword languages."""
        from qhchina.helpers import load_stopwords, get_stopword_languages
        
        languages = get_stopword_languages()
        
        for lang in languages:
            stopwords = load_stopwords(lang)
            assert isinstance(stopwords, set)
            assert len(stopwords) > 0
    
    def test_get_stopword_languages(self):
        """Test listing available stopword languages."""
        from qhchina.helpers import get_stopword_languages
        
        languages = get_stopword_languages()
        
        assert isinstance(languages, list)
        assert "zh_sim" in languages
        assert "zh_tr" in languages
    
    def test_load_stopwords_prefix_zh(self):
        """Test loading all Chinese stopwords with prefix 'zh'."""
        from qhchina.helpers import load_stopwords
        
        # Load all zh* stopwords
        all_zh_stopwords = load_stopwords("zh")
        
        # Load individual files
        zh_sim = load_stopwords("zh_sim")
        zh_tr = load_stopwords("zh_tr")
        zh_cl_sim = load_stopwords("zh_cl_sim")
        zh_cl_tr = load_stopwords("zh_cl_tr")
        
        # The combined set should be the union of all individual sets
        expected = zh_sim | zh_tr | zh_cl_sim | zh_cl_tr
        assert all_zh_stopwords == expected
        assert len(all_zh_stopwords) >= len(zh_sim)
    
    def test_load_stopwords_prefix_zh_cl(self):
        """Test loading classical Chinese stopwords with prefix 'zh_cl'."""
        from qhchina.helpers import load_stopwords
        
        # Load all zh_cl* stopwords
        all_cl_stopwords = load_stopwords("zh_cl")
        
        # Load individual classical files
        zh_cl_sim = load_stopwords("zh_cl_sim")
        zh_cl_tr = load_stopwords("zh_cl_tr")
        
        # The combined set should be the union of classical files only
        expected = zh_cl_sim | zh_cl_tr
        assert all_cl_stopwords == expected
        
        # Should NOT include non-classical stopwords
        zh_sim = load_stopwords("zh_sim")
        # Classical files should have some stopwords not in modern simplified
        assert isinstance(all_cl_stopwords, set)


class TestSplitIntoChunks:
    """Tests for text chunking function."""
    
    def test_split_into_chunks_basic(self, sample_chinese_text):
        """Test basic text chunking."""
        from qhchina.helpers import split_into_chunks
        
        chunks = split_into_chunks(sample_chinese_text, chunk_size=10)
        
        assert isinstance(chunks, list)
        assert len(chunks) > 0
        assert all(isinstance(c, str) for c in chunks)
    
    def test_split_into_chunks_overlap(self, sample_chinese_text):
        """Test chunking with overlap (float between 0-1)."""
        from qhchina.helpers import split_into_chunks
        
        # overlap=0.3 means 30% overlap
        chunks = split_into_chunks(sample_chinese_text, chunk_size=10, overlap=0.3)
        
        assert isinstance(chunks, list)
        assert len(chunks) > 0
    
    def test_split_into_chunks_list_input(self, sample_tokenized):
        """Test chunking with list input (tokens)."""
        from qhchina.helpers import split_into_chunks
        
        chunks = split_into_chunks(sample_tokenized, chunk_size=5)
        
        assert isinstance(chunks, list)
        assert all(isinstance(c, list) for c in chunks)
    
    def test_split_into_chunks_empty_input(self):
        """Test chunking with empty input returns empty list."""
        from qhchina.helpers import split_into_chunks
        
        assert split_into_chunks("", chunk_size=5) == []
        assert split_into_chunks([], chunk_size=5) == []
    
    def test_split_into_chunks_invalid_chunk_size_zero(self):
        """Test that chunk_size=0 raises ValueError."""
        from qhchina.helpers import split_into_chunks
        
        with pytest.raises(ValueError, match="chunk_size must be greater than 0"):
            split_into_chunks("test", chunk_size=0)
    
    def test_split_into_chunks_invalid_chunk_size_negative(self):
        """Test that negative chunk_size raises ValueError."""
        from qhchina.helpers import split_into_chunks
        
        with pytest.raises(ValueError, match="chunk_size must be greater than 0"):
            split_into_chunks("test", chunk_size=-1)
    
    def test_split_into_chunks_invalid_overlap_one(self):
        """Test that overlap=1.0 raises ValueError."""
        from qhchina.helpers import split_into_chunks
        
        with pytest.raises(ValueError, match="Overlap must be between 0 and 1"):
            split_into_chunks("test text", chunk_size=2, overlap=1.0)
    
    def test_split_into_chunks_invalid_overlap_negative(self):
        """Test that negative overlap raises ValueError."""
        from qhchina.helpers import split_into_chunks
        
        with pytest.raises(ValueError, match="Overlap must be between 0 and 1"):
            split_into_chunks("test text", chunk_size=2, overlap=-0.1)
    
    def test_split_into_chunks_sequence_shorter_than_chunk(self):
        """Test when sequence is shorter than chunk_size."""
        from qhchina.helpers import split_into_chunks
        
        text = "short"
        chunks = split_into_chunks(text, chunk_size=100)
        
        assert len(chunks) == 1
        assert chunks[0] == text
    
    def test_split_into_chunks_exact_division(self):
        """Test when sequence divides exactly into chunks."""
        from qhchina.helpers import split_into_chunks
        
        text = "abcdefghij"  # 10 chars
        chunks = split_into_chunks(text, chunk_size=5, overlap=0.0)
        
        assert len(chunks) == 2
        assert chunks[0] == "abcde"
        assert chunks[1] == "fghij"
    
    def test_split_into_chunks_with_high_overlap(self, sample_chinese_text):
        """Test chunking with high overlap (0.9)."""
        from qhchina.helpers import split_into_chunks
        
        chunks = split_into_chunks(sample_chinese_text, chunk_size=10, overlap=0.9)
        
        # With 90% overlap, should have many overlapping chunks
        assert isinstance(chunks, list)
        assert len(chunks) > 1


class TestDetectEncoding:
    """Tests for encoding detection function."""
    
    def test_detect_encoding_utf8(self, texts_dir):
        """Test detecting UTF-8 encoding."""
        from qhchina.helpers import detect_encoding
        
        # The test files should be UTF-8 encoded
        text_file = texts_dir / "民国_鲁迅_呐喊_1923.txt"
        encoding = detect_encoding(str(text_file))
        
        # Should detect as UTF-8 or a compatible encoding
        assert encoding.lower() in ['utf-8', 'utf8', 'ascii']
    
    def test_detect_encoding_with_num_bytes(self, texts_dir):
        """Test encoding detection with custom num_bytes."""
        from qhchina.helpers import detect_encoding
        
        text_file = texts_dir / "红楼梦.txt"
        encoding = detect_encoding(str(text_file), num_bytes=5000)
        
        assert isinstance(encoding, str)
        assert len(encoding) > 0
    
    def test_detect_encoding_returns_string(self, texts_dir):
        """Test that detect_encoding always returns a string."""
        from qhchina.helpers import detect_encoding
        
        text_file = texts_dir / "宋史.txt"
        encoding = detect_encoding(str(text_file))
        
        assert isinstance(encoding, str)


class TestFonts:
    """Tests for font management functions."""
    
    def test_list_remote_fonts(self):
        """Test listing remote fonts from GitHub."""
        from qhchina.helpers import list_remote_fonts
        
        fonts = list_remote_fonts()
        
        assert isinstance(fonts, list)
        assert len(fonts) > 0
        assert 'file' in fonts[0]
        assert 'size' in fonts[0]
        assert 'size_mb' in fonts[0]
    
    def test_list_cached_fonts(self):
        """Test listing cached fonts."""
        from qhchina.helpers import list_cached_fonts, load_fonts
        
        # Ensure at least one font is cached
        load_fonts()
        
        cached = list_cached_fonts()
        assert isinstance(cached, list)
        assert len(cached) > 0
        assert 'file' in cached[0]
        assert 'font_name' in cached[0]
        assert 'path' in cached[0]
    
    def test_get_current_font_path(self):
        """Test getting current font path after loading."""
        from qhchina.helpers import load_font, get_current_font_path
        
        # Load a font first
        load_font()
        
        # Should return a path for the loaded font
        path = get_current_font_path()
        
        assert path is not None
        assert Path(path).exists()
    
    def test_get_current_font_path_after_different_loads(self):
        """Test that get_current_font_path returns correct path after loading different fonts."""
        from qhchina.helpers import load_font, get_current_font_path
        
        # Load default font
        load_font()
        path1 = get_current_font_path()
        assert 'NotoSans' in path1
        
        # Load a different font
        load_font(remote='NotoSerifTC-Regular.otf')
        path2 = get_current_font_path()
        assert 'NotoSerif' in path2
    
    def test_load_fonts(self):
        """Test loading fonts for matplotlib."""
        from qhchina.helpers import load_fonts
        
        # Should return font name
        font_name = load_fonts()
        assert isinstance(font_name, str)
        assert font_name == 'Noto Sans CJK TC'
    
    def test_download_fonts_single(self):
        """Test downloading a single font."""
        from qhchina.helpers import download_fonts
        
        result = download_fonts(['NotoSerifTC-Regular.otf'])
        
        assert isinstance(result, dict)
        assert 'NotoSerifTC-Regular.otf' in result
        assert result['NotoSerifTC-Regular.otf'] == 'Noto Serif TC'
    
    def test_download_fonts_requires_list(self):
        """Test that download_fonts requires a list, not a string."""
        from qhchina.helpers import download_fonts
        
        with pytest.raises(TypeError, match="must be a list"):
            download_fonts('NotoSerifTC-Regular.otf')
    
    def test_get_current_font_name(self):
        """Test getting current font name."""
        from qhchina.helpers import get_current_font_name, load_fonts
        
        load_fonts()
        font = get_current_font_name()
        
        assert font is not None
        assert font == 'Noto Sans CJK TC'
    
    def test_load_font_with_remote(self):
        """Test loading font with remote filename."""
        from qhchina.helpers.fonts import load_font, get_current_font_name
        
        # Load with remote filename (downloads if needed)
        font_name = load_font(remote='NotoSerifTC-Regular.otf')
        
        assert font_name == 'Noto Serif TC'
        assert get_current_font_name() == 'Noto Serif TC'
    
    def test_load_font_default(self):
        """Test loading default font."""
        from qhchina.helpers.fonts import load_font, get_current_font_name
        
        # Load default font
        font_name = load_font()
        
        assert font_name == 'Noto Sans CJK TC'
        assert get_current_font_name() == 'Noto Sans CJK TC'
    
    def test_load_font_invalid_extension(self):
        """Test that invalid font extension raises ValueError."""
        from qhchina.helpers.fonts import load_font
        
        with pytest.raises(ValueError, match="Invalid font file"):
            load_font(remote='InvalidFont')
    
    def test_load_font_both_remote_and_path_raises(self):
        """Test that specifying both remote and path raises ValueError."""
        from qhchina.helpers.fonts import load_font
        
        with pytest.raises(ValueError, match="Cannot specify both"):
            load_font(remote='NotoSerifTC-Regular.otf', path='/some/path.otf')
    
    def test_get_cache_dir(self):
        """Test getting cache directory."""
        from qhchina.helpers import get_cache_dir
        
        cache_dir = get_cache_dir()
        assert cache_dir is not None
        assert 'qhchina' in str(cache_dir)
        assert 'fonts' in str(cache_dir)


class TestGithubErrorSemantics:
    """Tests that distinguish not-found from transport/API failures."""

    def test_query_github_api_404_maps_to_valueerror(self, monkeypatch):
        """404 responses should map to ValueError with not-found semantics."""
        from qhchina.helpers import github

        class FakeResponse:
            status_code = 404

            def raise_for_status(self):
                raise AssertionError("raise_for_status should not be called for 404 mapping test")

        class FakeRequests:
            def get(self, *args, **kwargs):
                return FakeResponse()

        monkeypatch.setattr(github, "_get_requests", lambda: FakeRequests())

        with pytest.raises(ValueError, match="Repository path not found"):
            github.query_github_api("corpora/not_real")

    def test_download_file_404_maps_to_valueerror(self, monkeypatch, tmp_path):
        """404 download responses should map to ValueError."""
        from qhchina.helpers import github

        class FakeResponse:
            status_code = 404

            def raise_for_status(self):
                raise AssertionError("raise_for_status should not be called for 404 mapping test")

            def iter_content(self, chunk_size=65536):
                return iter(())

        class FakeRequests:
            def get(self, *args, **kwargs):
                return FakeResponse()

        monkeypatch.setattr(github, "_get_requests", lambda: FakeRequests())

        with pytest.raises(ValueError, match="Resource not found at URL"):
            github.download_file("https://example.invalid/missing.txt", tmp_path / "out.txt")

    def test_query_github_api_network_error_bubbles_up(self, monkeypatch):
        """Transport/network failures should propagate as requests exceptions."""
        import requests
        from qhchina.helpers import github

        class FakeRequests:
            def get(self, *args, **kwargs):
                raise requests.ConnectionError("network down")

        monkeypatch.setattr(github, "_get_requests", lambda: FakeRequests())

        with pytest.raises(requests.RequestException):
            github.query_github_api("corpora")


# =============================================================================
# Top-level Import Tests
# =============================================================================

class TestTopLevelImports:
    """Verify key functions are accessible from the top-level package."""

    def test_import_kwic(self):
        from qhchina import kwic
        assert callable(kwic)

    def test_import_compare_collocates(self):
        from qhchina import compare_collocates
        assert callable(compare_collocates)

    def test_import_find_shared_sequences(self):
        from qhchina import find_shared_sequences
        assert callable(find_shared_sequences)

    def test_import_from_analytics(self):
        from qhchina.analytics import kwic, compare_collocates, find_shared_sequences
        assert callable(kwic)
        assert callable(compare_collocates)
        assert callable(find_shared_sequences)