# Changelog

All notable changes to RenderDeck are documented here.

## 0.9.1

- Fix: `list_voices` no longer opens browser tabs during test runs — `webbrowser.open()` is now opt-in via `open_browser` parameter (EXE-1107)

## 0.9.0

- Add `file_path` parameter to `validate_prompt_file` — validate prompt files by path instead of passing full content inline
- Eliminates context window duplication (3,000–5,000 tokens) when the presenter skill writes the file before validating
- Both `slide_prompt_content` and `file_path` are supported (mutually exclusive); existing callers are fully backward-compatible
- Add `scripts/build_skill.py` to package the renderdeck-presenter skill as a distributable zip

## 0.8.0

- Add prompt file caching with `prompt_id` workflow — `validate_prompt_file` now returns a `prompt_id` (SHA-256 content hash)
- All downstream tools (`generate_deck`, `assemble_deck`, `generate_video`, `regenerate_slide`) accept `prompt_id` instead of full content
- In-memory cache scoped per MCP server session with LRU eviction (max 64 entries)

## 0.7.0

- Add Vietnamese voice support for video narration: 2 new voices for vi-VN locale
- New voices: hoaimy (female), namminh (male) — Vietnam
- `list_voices` now returns 71 voices (60 English + 9 French + 2 Vietnamese) with Vietnamese locale label
- Use any Vietnamese voice alias in `generate_video(voice="hoaimy")` for Vietnamese-narrated presentations

## 0.6.0

- Add French voice support for video narration: 9 new voices across 3 locales (fr-FR, fr-BE, fr-CA)
- New voices: denise, henri, eloise (France), charline, gerard (Belgium), sylvie, antoine, jean, thierry (Canada)
- `list_voices` now returns 69 voices (60 English + 9 French) with French locale labels
- Use any French voice alias in `generate_video(voice="denise")` for French-narrated presentations

## 0.5.2

- Fix FFmpeg hanging indefinitely when edge-tts produces a 0-byte audio file during video generation
- Add subprocess timeouts to all FFmpeg/ffprobe calls (30s/120s/180s) to prevent pipeline hangs
- Invalidate bad TTS cache entries (< 100 bytes) so failed audio is regenerated on retry
- Skip slides with corrupt audio instead of passing them to FFmpeg

## 0.5.1

- Fix API key not found when stored via `setup_gemini_key` or installer — tools now check encrypted config store, not just env var
- Fix server version reporting MCP SDK version instead of RenderDeck version
- Installer creates `/usr/local/bin` symlinks for `uv`/`uvx` so Claude Desktop can find them

## 0.5.0

- Add reference image support for slide generation: pass URLs or base64-encoded images to `generate_slide` and `generate_deck` for style transfer, screenshots, logos, and brand consistency
- New `REFERENCES:` block in prompt file format for per-slide reference images
- Gemini multimodal API integration: reference images sent as `inline_data` content blocks with role-based prompt annotations
- Graceful fallback to text-only generation when image fetch fails
- URL scheme validation (http/https only) and 20 MB response size limit for fetched reference images
- Cache hash includes reference images for proper invalidation
- Fix lint: use `datetime.UTC` alias, break long lines in voices HTML template

## 0.4.2

- Fix garbled/interrupted audio in `generate_video`

## 0.4.1

- Fix `datetime.UTC` crash on Python < 3.11

## 0.3.6

- Fix gender color from red to purple in voice samples page
- Exclude voices without audio samples from the HTML page — only playable voices shown
- Remove `sample_url` from `list_voices` JSON output (audio is handled by the browser page)

## 0.3.5

- `list_voices` now auto-opens a local HTML page in the browser with inline audio play buttons — no downloads, no extra clicks in Claude Desktop

## 0.3.4

- Replace MP3 download links with inline `<audio>` players in `list_voices` so voice samples play directly in Claude Desktop without downloading
- Update `voice_samples.html` resource with embedded audio controls for all voices with samples

## 0.3.3

- Add clickable MP3 sample links to `list_voices` output for 20 voices via yaph/tts-samples

## 0.3.2

- Exclude `video_output/` and `e2e_output/` from sdist to reduce package size

## 0.3.1

- Fix `get_help` to return raw text instead of dict, preventing LLM summarization
- Update PyPI description with video generation tools, voice samples resource, and example prompts

## 0.3.0

- Add `generate_video` tool: convert cached slide images + TTS narration into MP4 video via edge-tts and FFmpeg
- Add `list_voices` tool: list all 30 supported TTS voices with aliases, locale, and gender
- Add `renderdeck://voice-samples` MCP resource with interactive HTML voice preview page
- Add `edge-tts` dependency for free neural TTS (no API key required)

## 0.2.15

- Fix packaging: move `resources/` (help.md, renderdeck_reference.md) into the Python package so they are included in the wheel distribution

## 0.2.14

- Extract `get_help` content into editable `resources/help.md` file loaded at runtime

## 0.2.13

- Add PyPI project link to `get_help` tool output

## 0.2.12

- Add quick-start usage hint to the top of the PyPI README directing users to ask their LLM "How do I use RenderDeck?"

## 0.2.10

- Add Security & Privacy section to PyPI README explaining local-only execution and Gemini API communication
- Add Tech Stack table to PyPI README

## 0.2.9

- Add copy-pasteable example prompts to each step in the "Getting the Best Results" workflow (both `get_help` tool and PyPI README)
- Restructure `tips.recommended_steps` from flat strings to objects with `step`, `description`, and `prompt` fields

## 0.2.8

- Add example prompts and LLM context advice to `get_help` tool and PyPI README
- Show users how to phrase requests for different presentation scenarios

## 0.2.7

- Add `get_help` tool with workflows, tools, prompts, and resources documentation
- Users can discover all RenderDeck capabilities from within the MCP conversation

## 0.2.6

- Add `notes_mode` parameter for narration-only speaker notes
- Support `**Say:**` prefix format for notes intended for video narration tools like Pictory

## 0.2.5

- Improve speaker notes formatting for presenter readability

## 0.2.4

- Support inline `### Speaker Notes` within slide blocks

## 0.2.3

- Clarify speaker notes format to prevent `---` separators between entries

## 0.2.2

- Fix speaker notes lost due to `---` separator splitting

## 0.2.1

- Add `get_version` tool
- Fix stale `__version__` value

## 0.2.0

- Add per-slide `generate_slide` and `assemble_deck` tools to avoid MCP client timeouts
- Add `regenerate_slide` for iterating on individual slides
- Retry on HTTP 500/502 Bad Gateway from Gemini API
- Use `ctx.info()` log notifications to keep MCP connection alive

## 0.1.0

- Initial release: MCP server with `generate_deck`, `validate_prompt_file`, `setup_gemini_key`, `get_setup_status`, and `update_settings` tools
- Gemini image generation (Flash and Pro models)
- `.pptx` assembly with background images and speaker notes
- Content-hash image caching
- Fernet-encrypted API key storage
- Bundled LLM reference document served as MCP resource
- `create_deck` and `check_and_fix` MCP prompts
