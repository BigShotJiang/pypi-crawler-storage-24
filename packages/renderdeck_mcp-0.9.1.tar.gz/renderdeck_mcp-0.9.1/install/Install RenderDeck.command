#!/bin/bash
# ─────────────────────────────────────────────────────────
# RenderDeck MCP — One-Click Installer for macOS
# Double-click this file to install RenderDeck for Claude Desktop.
# ─────────────────────────────────────────────────────────
set -euo pipefail

clear
cat <<'BANNER'

╔══════════════════════════════════════════════════════════╗
║              RenderDeck MCP — Installer                  ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  RenderDeck lets you create presentations and videos     ║
║  directly from Claude Desktop using AI.                  ║
║                                                          ║
║  This installer will set up:                             ║
║    • Homebrew (macOS package manager, if not installed)   ║
║    • ffmpeg (for video generation)                       ║
║    • uv (Python package runner)                          ║
║    • RenderDeck MCP server for Claude Desktop            ║
║                                                          ║
║  You will need a Google Gemini API key.                  ║
║  Either:                                                 ║
║    1. Ask your admin to share it via 1Password           ║
║    2. Create one at: https://aistudio.google.com/apikey  ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝

BANNER

read -rp "Press Enter to continue or Ctrl+C to cancel... "
echo

# ── Homebrew ──────────────────────────────────────────────
if ! command -v brew &>/dev/null; then
    echo "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    # Add Homebrew to PATH for Apple Silicon Macs
    if [[ -f /opt/homebrew/bin/brew ]]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
else
    echo "✓ Homebrew already installed"
fi

# ── ffmpeg ────────────────────────────────────────────────
if ! command -v ffmpeg &>/dev/null; then
    echo "Installing ffmpeg..."
    brew install ffmpeg
else
    echo "✓ ffmpeg already installed"
fi

# ── uv ────────────────────────────────────────────────────
if ! command -v uv &>/dev/null; then
    echo "Installing uv..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    # Source the env to get uv on PATH
    if [[ -f "$HOME/.local/bin/env" ]]; then
        source "$HOME/.local/bin/env"
    elif [[ -f "$HOME/.cargo/env" ]]; then
        source "$HOME/.cargo/env"
    fi
    export PATH="$HOME/.local/bin:$PATH"
else
    echo "✓ uv already installed"
fi

# ── Symlink uv/uvx into /usr/local/bin ─────────────────────
# Claude Desktop's PATH doesn't include ~/.local/bin, so uv/uvx
# must be reachable from /usr/local/bin (or /opt/homebrew/bin).
for bin in uv uvx; do
    target="$HOME/.local/bin/$bin"
    link="/usr/local/bin/$bin"
    if [[ -x "$target" ]] && [[ ! -e "$link" ]]; then
        echo "Creating symlink: $link → $target"
        sudo ln -s "$target" "$link"
    fi
done

# ── RenderDeck setup ─────────────────────────────────────
echo
echo "Running RenderDeck setup..."
uvx renderdeck-mcp install

echo
read -rp "Press Enter to close this window... "
