"""End-to-end tests for the generate_deck pipeline.

Test A (mocked Gemini): Uses a real deck from decks/, runs the full pipeline
with only Gemini mocked, validates real .pptx output and cache behavior.

Test B (live Gemini): Uses a real API key, calls real Gemini, produces a real
.pptx. Skips automatically when no API key is set.

Run with:
    pytest tests/test_e2e.py -m e2e -v          # mocked (safe, fast)
    pytest tests/test_e2e.py -m e2e_live -v      # live (needs API key, ~$0.004)
"""

from __future__ import annotations

import io
import json
import os
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from PIL import Image

from renderdeck_mcp.cache import prompt_cache
from renderdeck_mcp.generation.gemini import ImageResult


@pytest.fixture(autouse=True)
def _clear_cache_after_each_test() -> object:
    """Clear the prompt_cache singleton after every test in this module."""
    yield
    prompt_cache.clear()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

DECK_FILE = Path(__file__).resolve().parent.parent / "decks" / "SDD_Hackathon_Kickoff.md"

_PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
_JPEG_MAGIC = b"\xff\xd8\xff"

LIVE_3_SLIDE_PROMPT = """\
# E2E Test Deck

## General

A minimal end-to-end test deck for validating the RenderDeck pipeline.

## Global Rules

FORMAT: Wide-format 16:9.
COLORS: Dark background #1a1a2e, accent blue #0066ff, white text #ffffff.

---

## Slide 01 — Blue Circle

Create a wide-format presentation slide (16:9) with a dark navy background (#1a1a2e). \
In the center, draw a large solid blue circle (#0066ff). Nothing else.

---

## Slide 02 — Green Square

Create a wide-format presentation slide (16:9) with a dark navy background (#1a1a2e). \
In the center, draw a large solid green square (#00cc66). Nothing else.

---

## Slide 03 — Red Triangle

Create a wide-format presentation slide (16:9) with a dark navy background (#1a1a2e). \
In the center, draw a large solid red triangle (#ff3333). Nothing else.

---

## Speaker Notes

### Slide 01 — Blue Circle

**Say:** This is a blue circle slide for testing.

### Slide 02 — Green Square

**Say:** This is a green square slide for testing.

### Slide 03 — Red Triangle

**Say:** This is a red triangle slide for testing.
"""

# Same deck but with inline ### Speaker Notes inside each slide block
# (the format Claude Desktop naturally generates).
INLINE_NOTES_3_SLIDE_PROMPT = """\
# E2E Inline Notes Test Deck

## General

A minimal end-to-end test deck validating inline speaker notes.

## Global Rules

FORMAT: Wide-format 16:9.
COLORS: Dark background #1a1a2e, accent blue #0066ff, white text #ffffff.

---

## Slide 01 — Blue Circle

Create a wide-format presentation slide (16:9) with a dark navy background (#1a1a2e). \
In the center, draw a large solid blue circle (#0066ff). Nothing else.

### Speaker Notes

**Say:** This is a blue circle slide for testing inline notes.

**Time:** ~10 seconds.

---

## Slide 02 — Green Square

Create a wide-format presentation slide (16:9) with a dark navy background (#1a1a2e). \
In the center, draw a large solid green square (#00cc66). Nothing else.

### Speaker Notes

**Say:** This is a green square slide for testing inline notes.

**Time:** ~10 seconds.

---

## Slide 03 — Red Triangle

Create a wide-format presentation slide (16:9) with a dark navy background (#1a1a2e). \
In the center, draw a large solid red triangle (#ff3333). Nothing else.

### Speaker Notes

**Say:** This is a red triangle slide for testing inline notes.

**Time:** ~10 seconds.
"""


def _make_fake_png() -> bytes:
    """Create a valid 1920x1080 PNG image via Pillow."""
    img = Image.new("RGB", (1920, 1080), color=(56, 54, 137))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


async def _mock_generate_images(
    requests: list[object],
    config: object,
    progress_cb: object = None,
) -> list[ImageResult]:
    """Return an ImageResult with real PNG bytes for each request."""
    fake_png = _make_fake_png()
    return [
        ImageResult(
            slide_index=getattr(req, "slide_index", i),
            image_bytes=fake_png,
            fallback=False,
        )
        for i, req in enumerate(requests)
    ]


@pytest.fixture()
def isolated_cache(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect both cache base dir locations to tmp_path."""
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    monkeypatch.setattr("renderdeck_mcp.generation.cache.CACHE_BASE_DIR", cache_dir)
    monkeypatch.setattr("renderdeck_mcp.tools.generate_deck._CACHE_BASE_DIR", cache_dir)
    return cache_dir


# ---------------------------------------------------------------------------
# Test A: Mocked Gemini E2E
# ---------------------------------------------------------------------------


@pytest.mark.e2e
@pytest.mark.asyncio
async def test_e2e_mocked_gemini(
    tmp_path: Path,
    isolated_cache: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Full pipeline with real deck file, only Gemini mocked."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key-for-e2e")

    deck_content = DECK_FILE.read_text(encoding="utf-8")
    output_pptx = tmp_path / "output" / "hackathon.pptx"

    mock_gen = AsyncMock(side_effect=_mock_generate_images)

    # ---- Cold-cache run ----
    with patch(
        "renderdeck_mcp.tools.generate_deck.generate_images_concurrent",
        mock_gen,
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(deck_content).prompt_id,
            output_path=str(output_pptx),
            project_name="e2e-hackathon-test",
        )

    assert result["status"] == "ok", f"Pipeline failed: {result}"
    assert result["slide_count"] == 14
    assert result["slides_generated"] == 14
    assert result["slides_cached"] == 0

    # .pptx file exists and is non-empty
    assert output_pptx.exists()
    assert output_pptx.stat().st_size > 0

    # Validate with python-pptx
    from pptx import Presentation

    prs = Presentation(str(output_pptx))
    assert len(prs.slides) == 14
    for slide in prs.slides:
        notes = slide.notes_slide.notes_text_frame.text
        assert len(notes) > 0, "Each slide should have speaker notes"
        # Check for picture shape (MSO_SHAPE_TYPE.PICTURE == 13)
        has_picture = any(shape.shape_type == 13 for shape in slide.shapes)
        assert has_picture, "Each slide should have a picture shape"

    # Cache manifest exists and is valid
    manifest_path = isolated_cache / "e2e-hackathon-test" / "cache_manifest.json"
    assert manifest_path.exists()
    manifest_data = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest_data["version"] == 1
    assert len(manifest_data["slides"]) == 14

    # 14 cached PNG files exist
    cache_project_dir = isolated_cache / "e2e-hackathon-test"
    for i in range(1, 15):
        png_path = cache_project_dir / f"slide_{i:02d}.png"
        assert png_path.exists(), f"Missing cached PNG: {png_path.name}"

    # ---- Warm-cache run ----
    mock_gen_warm = AsyncMock(side_effect=_mock_generate_images)
    output_pptx_warm = tmp_path / "output" / "hackathon_warm.pptx"

    with patch(
        "renderdeck_mcp.tools.generate_deck.generate_images_concurrent",
        mock_gen_warm,
    ):
        result_warm = await run_generate_deck(
            prompt_id=prompt_cache.store(deck_content).prompt_id,
            output_path=str(output_pptx_warm),
            project_name="e2e-hackathon-test",
        )

    assert result_warm["status"] == "ok"
    assert result_warm["slides_generated"] == 0
    assert result_warm["slides_cached"] == 14
    mock_gen_warm.assert_not_called()

    # Second .pptx is valid
    prs_warm = Presentation(str(output_pptx_warm))
    assert len(prs_warm.slides) == 14


# ---------------------------------------------------------------------------
# Test A2: Mocked Gemini E2E — inline ### Speaker Notes format
# ---------------------------------------------------------------------------


@pytest.mark.e2e
@pytest.mark.asyncio
async def test_e2e_inline_speaker_notes(
    tmp_path: Path,
    isolated_cache: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Full pipeline with inline ### Speaker Notes inside each slide block.

    This validates the format Claude Desktop naturally generates, where
    speaker notes appear as ### Speaker Notes sub-headings within each
    slide block rather than in a consolidated ## Speaker Notes section.
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key-for-e2e")

    output_pptx = tmp_path / "output" / "inline_notes.pptx"

    mock_gen = AsyncMock(side_effect=_mock_generate_images)

    with patch(
        "renderdeck_mcp.tools.generate_deck.generate_images_concurrent",
        mock_gen,
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(INLINE_NOTES_3_SLIDE_PROMPT).prompt_id,
            output_path=str(output_pptx),
            project_name="e2e-inline-notes",
        )

    assert result["status"] == "ok", f"Pipeline failed: {result}"
    assert result["slide_count"] == 3
    assert result["slides_generated"] == 3

    # .pptx file exists and is non-empty
    assert output_pptx.exists()
    assert output_pptx.stat().st_size > 0

    # Validate with python-pptx
    from pptx import Presentation

    prs = Presentation(str(output_pptx))
    assert len(prs.slides) == 3

    from pptx.util import Pt

    expected_notes = [
        "blue circle slide for testing inline notes",
        "green square slide for testing inline notes",
        "red triangle slide for testing inline notes",
    ]
    for idx, slide in enumerate(prs.slides):
        tf = slide.notes_slide.notes_text_frame
        notes_text = tf.text
        assert len(notes_text) > 0, f"Slide {idx + 1} has no speaker notes"
        assert expected_notes[idx] in notes_text, (
            f"Slide {idx + 1} speaker notes missing expected content.\n"
            f"Expected substring: {expected_notes[idx]!r}\n"
            f"Got: {notes_text!r}"
        )
        # No --- separator artifacts in notes
        assert "---" not in notes_text, (
            f"Slide {idx + 1}: separator '---' leaked into speaker notes"
        )
        # Formatting: bold label runs get 12pt, body runs get 10pt
        has_12pt_label = False
        has_10pt_body = False
        for para in tf.paragraphs:
            for run in para.runs:
                if run.font.bold and run.font.size == Pt(12):
                    has_12pt_label = True
                if not run.font.bold and run.font.size == Pt(10) and run.text.strip():
                    has_10pt_body = True
        assert has_12pt_label, f"Slide {idx + 1}: no 12pt bold label found in speaker notes"
        assert has_10pt_body, f"Slide {idx + 1}: no 10pt body text found in speaker notes"
        # Speaker notes must NOT leak into image prompt
        for shape in slide.shapes:
            if shape.has_text_frame:
                shape_text = shape.text_frame.text.lower()
                assert "speaker notes" not in shape_text, (
                    f"Slide {idx + 1}: '### Speaker Notes' leaked into slide shape text"
                )
        # Check for picture shape
        has_picture = any(shape.shape_type == 13 for shape in slide.shapes)
        assert has_picture, f"Slide {idx + 1} has no picture shape"


# ---------------------------------------------------------------------------
# Test B: Live Gemini E2E
# ---------------------------------------------------------------------------


@pytest.mark.e2e_live
@pytest.mark.asyncio
async def test_e2e_live_gemini(
    tmp_path: Path,
    isolated_cache: Path,
    e2e_output_dir: Path | None,
) -> None:
    """Full pipeline with real Gemini API calls. Skips if no API key."""
    api_key = os.environ.get("GOOGLE_GEMINI_API_KEY")
    if not api_key:
        pytest.skip("GOOGLE_GEMINI_API_KEY not set — skipping live E2E test")

    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    output_pptx = tmp_path / "output" / "live_test.pptx"

    # ---- Cold-cache run ----
    result = await run_generate_deck(
        prompt_id=prompt_cache.store(LIVE_3_SLIDE_PROMPT).prompt_id,
        output_path=str(output_pptx),
        project_name="e2e-live-test",
    )

    assert result["status"] == "ok", f"Pipeline failed: {result}"
    assert result["slide_count"] == 3
    assert result["slides_generated"] == 3

    if e2e_output_dir is not None:
        import shutil

        shutil.copy2(output_pptx, e2e_output_dir / "e2e_live_cold.pptx")

    # .pptx file size is reasonable
    pptx_size = output_pptx.stat().st_size
    assert pptx_size > 10_000, f".pptx too small: {pptx_size} bytes"
    assert pptx_size < 50_000_000, f".pptx too large: {pptx_size} bytes"

    # Validate with python-pptx
    from pptx import Presentation

    prs = Presentation(str(output_pptx))
    assert len(prs.slides) == 3

    for slide in prs.slides:
        notes = slide.notes_slide.notes_text_frame.text
        assert len(notes) > 0, "Each slide should have speaker notes"
        # Check for picture shape — skip if Gemini failed (API flakiness)
        has_picture = any(shape.shape_type == 13 for shape in slide.shapes)
        if not has_picture:
            pytest.skip("Gemini did not return an image — API flakiness, skipping validation")

    # Validate cached PNGs
    cache_project_dir = isolated_cache / "e2e-live-test"
    for i in range(1, 4):
        png_path = cache_project_dir / f"slide_{i:02d}.png"
        assert png_path.exists(), f"Missing cached PNG: {png_path.name}"
        png_bytes = png_path.read_bytes()
        assert len(png_bytes) > 100, f"PNG too small: {len(png_bytes)} bytes"
        assert png_bytes[:8] == _PNG_MAGIC or png_bytes[:3] == _JPEG_MAGIC, (
            f"Invalid image magic bytes: {png_path.name}"
        )
        img = Image.open(png_path)
        assert img.width > 100 and img.height > 100, f"Image too small: {img.size}"

    # Cache manifest validation
    manifest_path = cache_project_dir / "cache_manifest.json"
    assert manifest_path.exists()
    manifest_data = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest_data["version"] == 1
    assert len(manifest_data["slides"]) == 3
    assert len(manifest_data["options_hash"]) > 0
    for _slide_num, hash_val in manifest_data["slides"].items():
        assert len(hash_val) == 16, f"Expected 16-char hash, got {len(hash_val)}"

    # ---- Warm-cache run — zero API calls ----
    output_pptx_warm = tmp_path / "output" / "live_warm.pptx"

    with patch(
        "renderdeck_mcp.tools.generate_deck.generate_images_concurrent",
        side_effect=AssertionError("should not call Gemini on warm cache"),
    ):
        result_warm = await run_generate_deck(
            prompt_id=prompt_cache.store(LIVE_3_SLIDE_PROMPT).prompt_id,
            output_path=str(output_pptx_warm),
            project_name="e2e-live-test",
        )

    assert result_warm["status"] == "ok"
    assert result_warm["slides_generated"] == 0
    assert result_warm["slides_cached"] == 3

    # ---- Incremental regeneration — 1 changed slide ----
    modified_prompt = LIVE_3_SLIDE_PROMPT.replace(
        "draw a large solid blue circle (#0066ff)",
        "draw a large solid yellow star (#ffcc00)",
    )
    output_pptx_incr = tmp_path / "output" / "live_incremental.pptx"

    result_incr = await run_generate_deck(
        prompt_id=prompt_cache.store(modified_prompt).prompt_id,
        output_path=str(output_pptx_incr),
        project_name="e2e-live-test",
    )

    assert result_incr["status"] == "ok"
    assert result_incr["slides_generated"] == 1, (
        f"Expected 1 regenerated slide, got {result_incr['slides_generated']}"
    )
    assert result_incr["slides_cached"] == 2, (
        f"Expected 2 cached slides, got {result_incr['slides_cached']}"
    )

    if e2e_output_dir is not None:
        import shutil

        shutil.copy2(output_pptx_incr, e2e_output_dir / "e2e_live_incremental.pptx")


# ---------------------------------------------------------------------------
# Test C: Live Gemini E2E — Hackathon Kickoff deck (14 slides)
# ---------------------------------------------------------------------------


@pytest.mark.e2e_live
@pytest.mark.asyncio
async def test_e2e_live_hackathon_deck(
    tmp_path: Path,
    isolated_cache: Path,
    e2e_output_dir: Path | None,
) -> None:
    """Full pipeline with SDD_Hackathon_Kickoff.md and real Gemini. Skips if no API key."""
    api_key = os.environ.get("GOOGLE_GEMINI_API_KEY")
    if not api_key:
        pytest.skip("GOOGLE_GEMINI_API_KEY not set — skipping live E2E test")

    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    deck_content = DECK_FILE.read_text(encoding="utf-8")
    output_pptx = tmp_path / "output" / "hackathon_live.pptx"

    result = await run_generate_deck(
        slide_prompt_content=deck_content,
        output_path=str(output_pptx),
        project_name="e2e-hackathon-live",
    )

    assert result["status"] == "ok", f"Pipeline failed: {result}"
    assert result["slide_count"] == 14
    assert result["slides_generated"] == 14
    assert result["slides_cached"] == 0

    # .pptx exists and has reasonable size
    pptx_size = output_pptx.stat().st_size
    assert pptx_size > 50_000, f".pptx too small: {pptx_size} bytes"
    assert pptx_size < 100_000_000, f".pptx too large: {pptx_size} bytes"

    # Validate with python-pptx
    from pptx import Presentation

    prs = Presentation(str(output_pptx))
    assert len(prs.slides) == 14

    slides_with_images = 0
    for idx, slide in enumerate(prs.slides):
        # Every slide must have speaker notes
        notes = slide.notes_slide.notes_text_frame.text
        assert len(notes) > 0, f"Slide {idx + 1} has no speaker notes"

        # Count slides with picture shapes (Gemini may fail on some)
        has_picture = any(shape.shape_type == 13 for shape in slide.shapes)
        if has_picture:
            slides_with_images += 1

    # At least 10 of 14 slides should have images (tolerate some API flakiness)
    assert slides_with_images >= 10, (
        f"Only {slides_with_images}/14 slides have images — too many Gemini failures"
    )

    # Validate cached PNGs
    cache_project_dir = isolated_cache / "e2e-hackathon-live"
    cached_pngs = list(cache_project_dir.glob("slide_*.png"))
    assert len(cached_pngs) >= 10, f"Only {len(cached_pngs)} cached PNGs — expected at least 10"
    for png_path in cached_pngs:
        png_bytes = png_path.read_bytes()
        assert png_bytes[:8] == _PNG_MAGIC or png_bytes[:3] == _JPEG_MAGIC, (
            f"Bad image magic: {png_path.name}"
        )
        img = Image.open(png_path)
        assert img.width > 100 and img.height > 100, f"Image too small: {png_path.name}"

    # Cache manifest
    manifest_path = cache_project_dir / "cache_manifest.json"
    assert manifest_path.exists()
    manifest_data = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest_data["version"] == 1
    assert len(manifest_data["slides"]) == 14

    # Copy to output dir for inspection
    if e2e_output_dir is not None:
        import shutil

        shutil.copy2(output_pptx, e2e_output_dir / "e2e_hackathon_kickoff.pptx")
