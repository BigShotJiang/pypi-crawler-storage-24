"""Unit tests for renderdeck_mcp.tools.generate_deck (task 2.5).

All external dependencies are mocked — no real filesystem, no Gemini API calls,
no cache reads/writes.

Run with:
    pytest tests/test_generate_deck_tool.py -v
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest

from renderdeck_mcp.cache import prompt_cache
from renderdeck_mcp.generation.cache import CacheManifest
from renderdeck_mcp.generation.gemini import ImageResult

# ---------------------------------------------------------------------------
# Shared prompt fixtures
# ---------------------------------------------------------------------------

MINIMAL_1_SLIDE = """\
# Test Deck

## General
Test context.

---

## Slide 01 — Test Slide
A test image prompt.\
"""

MINIMAL_2_SLIDES = """\
# My Test Deck

## General
General context.

## Global Rules
Visual rules.

---

## Slide 01 — First Slide
Prompt for slide one.

---

## Slide 02 — Second Slide
Prompt for slide two.\
"""

MINIMAL_3_SLIDES = """\
# My Great Deck

## General
General context.

## Global Rules
Visual rules.

---

## Slide 01 — First Slide
Prompt for slide one.

---

## Slide 02 — Second Slide
Prompt for slide two.

---

## Slide 03 — Third Slide
Prompt for slide three.\
"""

FAKE_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100


@pytest.fixture(autouse=True)
def _clear_cache_after_each_test() -> object:
    """Clear the prompt_cache singleton after every test in this module."""
    yield
    prompt_cache.clear()


# ---------------------------------------------------------------------------
# Helper — build a fake content hash for a slide index
# ---------------------------------------------------------------------------


def _fake_hash(idx: int) -> str:
    return f"hash{idx:012d}abcd"


def _fake_manifest(slide_count: int, opts_hash: str) -> CacheManifest:
    """Build a CacheManifest that looks like all slides are up-to-date."""
    return CacheManifest(
        version=1,
        options_hash=opts_hash,
        slides={i + 1: _fake_hash(0) for i in range(slide_count)},
    )


# ---------------------------------------------------------------------------
# Patch targets
# ---------------------------------------------------------------------------

_TARGET_GENERATE = "renderdeck_mcp.tools.generate_deck.generate_images_concurrent"
_TARGET_LOAD_CACHE = "renderdeck_mcp.tools.generate_deck.load_cache_manifest"
_TARGET_SAVE_CACHE = "renderdeck_mcp.tools.generate_deck.save_cache_manifest"
_TARGET_BUILD_PPTX = "renderdeck_mcp.tools.generate_deck.build_pptx"
_TARGET_CONTENT_HASH = "renderdeck_mcp.tools.generate_deck.content_hash_for_slide"
_TARGET_OPTIONS_HASH = "renderdeck_mcp.tools.generate_deck.options_hash"
_TARGET_READ_CACHED = "renderdeck_mcp.tools.generate_deck._read_cached_image"


def _make_image_results(
    count: int, *, fallback_indices: set[int] | None = None
) -> list[ImageResult]:
    """Create ImageResult list with fake PNG bytes."""
    fallback_indices = fallback_indices or set()
    results = []
    for i in range(count):
        is_fallback = i in fallback_indices
        results.append(
            ImageResult(
                slide_index=i,
                image_bytes=None if is_fallback else FAKE_PNG,
                fallback=is_fallback,
            )
        )
    return results


# ---------------------------------------------------------------------------
# TC-01: Full pipeline with mocked Gemini — returns valid result dict
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc01_full_pipeline_returns_valid_result() -> None:
    """TC-01: 3-slide prompt, no cache, all Gemini calls succeed."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    fake_output = Path("/tmp/test_output.pptx")
    image_results = _make_image_results(3)

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=None),
        patch(_TARGET_SAVE_CACHE) as mock_save,
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=image_results),
        patch(_TARGET_BUILD_PPTX, return_value=fake_output),
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
        patch(_TARGET_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(MINIMAL_3_SLIDES).prompt_id,
            output_path="/tmp/test_output.pptx",
        )

    assert result["status"] == "ok", f"Expected status='ok', got: {result}"
    assert result["slide_count"] == 3
    assert result["slides_generated"] == 3
    assert result["slides_cached"] == 0
    assert str(result["output_path"]).endswith(".pptx")
    assert isinstance(result["cost_estimate"], str)
    mock_save.assert_called_once()


# ---------------------------------------------------------------------------
# TC-02: All slides cached — 0 Gemini calls
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc02_all_slides_cached_zero_gemini_calls() -> None:
    """TC-02: All slides in cache with matching hashes — Gemini not called."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    opts = "optshash1234abcd"
    manifest = _fake_manifest(3, opts)
    fake_output = Path("/tmp/cached.pptx")

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=manifest),
        patch(_TARGET_SAVE_CACHE),
        patch(_TARGET_GENERATE, new_callable=AsyncMock) as mock_generate,
        patch(_TARGET_BUILD_PPTX, return_value=fake_output),
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value=opts),
        patch(_TARGET_READ_CACHED, return_value=FAKE_PNG),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(MINIMAL_3_SLIDES).prompt_id,
            output_path="/tmp/cached.pptx",
        )

    mock_generate.assert_not_called()
    assert result["status"] == "ok"
    assert result["slides_generated"] == 0
    assert result["slides_cached"] == 3


# ---------------------------------------------------------------------------
# TC-03: Some slides cached, some new
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc03_partial_cache_only_uncached_sent_to_gemini() -> None:
    """TC-03: Slide 1 cached, slides 2 and 3 need generation."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    opts = "optshash1234abcd"
    # Slide 1 has matching hash; slides 2 and 3 have wrong hashes
    manifest = CacheManifest(
        version=1,
        options_hash=opts,
        slides={1: _fake_hash(0), 2: "wronghash0000000", 3: "wronghash0000001"},
    )
    # Gemini returns 2 results for the 2 uncached slides
    image_results = _make_image_results(2)
    fake_output = Path("/tmp/partial.pptx")

    call_count = 0

    def _content_hash_side_effect(*args: str, **kwargs: str) -> str:
        nonlocal call_count
        h = _fake_hash(0)  # All slides get the same hash (only slide 1 is in cache)
        call_count += 1
        return h

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=manifest),
        patch(_TARGET_SAVE_CACHE),
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=image_results) as mock_gen,
        patch(_TARGET_BUILD_PPTX, return_value=fake_output),
        patch(_TARGET_CONTENT_HASH, side_effect=_content_hash_side_effect),
        patch(_TARGET_OPTIONS_HASH, return_value=opts),
        patch(_TARGET_READ_CACHED, return_value=FAKE_PNG),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(MINIMAL_3_SLIDES).prompt_id,
            output_path="/tmp/partial.pptx",
        )

    assert result["status"] == "ok"
    assert result["slides_cached"] == 1
    assert result["slides_generated"] == 2
    mock_gen.assert_called_once()
    # The requests list passed to Gemini should have 2 entries
    requests_arg = mock_gen.call_args[0][0]
    assert len(requests_arg) == 2


# ---------------------------------------------------------------------------
# TC-04: Image failure on one slide → fallback, .pptx still produced
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc04_image_failure_fallback_pptx_produced() -> None:
    """TC-04: One slide fails image generation; fallback used; .pptx still assembled."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    # Slide index 1 (second slide) has fallback=True, no image bytes
    image_results = _make_image_results(2, fallback_indices={1})
    fake_output = Path("/tmp/fallback.pptx")

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=None),
        patch(_TARGET_SAVE_CACHE),
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=image_results),
        patch(_TARGET_BUILD_PPTX, return_value=fake_output) as mock_build,
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
        patch(_TARGET_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(MINIMAL_2_SLIDES).prompt_id,
            output_path="/tmp/fallback.pptx",
        )

    assert result["status"] == "ok", f"Expected ok despite fallback, got: {result}"
    mock_build.assert_called_once()
    assert result["slide_count"] == 2


# ---------------------------------------------------------------------------
# TC-05: Empty prompt → error result, no .pptx
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc05_empty_prompt_returns_error() -> None:
    """TC-05: Empty prompt content produces error result; build_pptx never called."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_BUILD_PPTX) as mock_build,
    ):
        result = await run_generate_deck(prompt_id=prompt_cache.store("").prompt_id)

    assert result["status"] == "error"
    assert "message" in result
    mock_build.assert_not_called()


# ---------------------------------------------------------------------------
# TC-06: No API key → error result with setup instructions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc06_no_api_key_error_with_instructions() -> None:
    """TC-06: Missing GOOGLE_GEMINI_API_KEY returns clear error with setup hint."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    with (
        patch("renderdeck_mcp.config.get_api_key", return_value=None),
        patch(_TARGET_GENERATE, new_callable=AsyncMock) as mock_gen,
    ):
        result = await run_generate_deck(prompt_id=prompt_cache.store(MINIMAL_1_SLIDE).prompt_id)

    assert result["status"] == "error"
    assert "message" in result
    msg: str = str(result["message"])
    assert "GOOGLE_GEMINI_API_KEY" in msg or "setup" in msg.lower()
    mock_gen.assert_not_called()


# ---------------------------------------------------------------------------
# TC-07: Default output path includes title slug and .pptx extension
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc07_default_output_path_includes_title() -> None:
    """TC-07: Default output_path contains slugified title and ends in .pptx."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    fake_output = Path("/tmp/default_path.pptx")

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=None),
        patch(_TARGET_SAVE_CACHE),
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=_make_image_results(1)),
        patch(_TARGET_BUILD_PPTX, return_value=fake_output) as mock_build,
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
        patch(_TARGET_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(MINIMAL_1_SLIDE).prompt_id,
            output_path=None,
        )

    assert result["status"] == "ok"
    # The output path passed to build_pptx should contain the slug and .pptx
    called_output_path = str(mock_build.call_args[0][1])
    assert "test-deck" in called_output_path.lower() or "test_deck" in called_output_path.lower()
    assert called_output_path.endswith(".pptx")


# ---------------------------------------------------------------------------
# TC-08: Custom output_path used when provided
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc08_custom_output_path_used() -> None:
    """TC-08: Explicit output_path is forwarded to build_pptx unchanged."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    custom_path = "/tmp/custom_test_output.pptx"
    fake_output = Path(custom_path)

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=None),
        patch(_TARGET_SAVE_CACHE),
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=_make_image_results(1)),
        patch(_TARGET_BUILD_PPTX, return_value=fake_output) as mock_build,
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
        patch(_TARGET_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(MINIMAL_1_SLIDE).prompt_id,
            output_path=custom_path,
        )

    assert result["status"] == "ok"
    called_output_path = str(mock_build.call_args[0][1])
    assert called_output_path == custom_path


# ---------------------------------------------------------------------------
# TC-09: project_name defaults to slugified title
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc09_project_name_defaults_to_slug() -> None:
    """TC-09: When project_name=None, load/save cache use slugified title."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    fake_output = Path("/tmp/slug_test.pptx")

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=None) as mock_load,
        patch(_TARGET_SAVE_CACHE) as mock_save,
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=_make_image_results(1)),
        patch(_TARGET_BUILD_PPTX, return_value=fake_output),
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
        patch(_TARGET_READ_CACHED, return_value=None),
    ):
        await run_generate_deck(
            prompt_id=prompt_cache.store(MINIMAL_1_SLIDE).prompt_id,
            project_name=None,
            output_path="/tmp/slug_test.pptx",
        )

    # load_cache_manifest called with slugified title "test-deck"
    load_project_name = mock_load.call_args[0][0]
    assert load_project_name == "test-deck", (
        f"Expected project_name='test-deck', got {load_project_name!r}"
    )
    save_project_name = mock_save.call_args[0][0]
    assert save_project_name == "test-deck", (
        f"Expected save project_name='test-deck', got {save_project_name!r}"
    )


# ---------------------------------------------------------------------------
# TC-10: Result dict has all required fields
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc10_result_dict_has_all_required_fields() -> None:
    """TC-10: Successful result contains all required keys."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    required_keys = {
        "status",
        "output_path",
        "slide_count",
        "slides_generated",
        "slides_cached",
        "cost_estimate",
    }
    fake_output = Path("/tmp/fields_test.pptx")

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=None),
        patch(_TARGET_SAVE_CACHE),
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=_make_image_results(1)),
        patch(_TARGET_BUILD_PPTX, return_value=fake_output),
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
        patch(_TARGET_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(MINIMAL_1_SLIDE).prompt_id,
            output_path="/tmp/fields_test.pptx",
        )

    assert result["status"] == "ok"
    missing = required_keys - set(result.keys())
    assert missing == set(), f"Result missing required keys: {missing}. Got: {set(result.keys())}"


# ---------------------------------------------------------------------------
# TC-11: Cache manifest saved after successful generation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc11_cache_manifest_saved_after_success() -> None:
    """TC-11: save_cache_manifest called exactly once with a CacheManifest instance."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    fake_output = Path("/tmp/cache_save_test.pptx")

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=None),
        patch(_TARGET_SAVE_CACHE) as mock_save,
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=_make_image_results(2)),
        patch(_TARGET_BUILD_PPTX, return_value=fake_output),
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
        patch(_TARGET_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(MINIMAL_2_SLIDES).prompt_id,
            output_path="/tmp/cache_save_test.pptx",
        )

    assert result["status"] == "ok"
    mock_save.assert_called_once()
    _, manifest_arg = mock_save.call_args[0]
    assert isinstance(manifest_arg, CacheManifest), (
        f"Expected CacheManifest, got {type(manifest_arg)!r}"
    )


# ---------------------------------------------------------------------------
# TC-12: image_quality parameter affects model selection
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc12_image_quality_model_selection() -> None:
    """TC-12: draft uses flash model, final uses pro model."""
    from renderdeck_mcp.generation.gemini import GeminiConfig
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    fake_output = Path("/tmp/quality_test.pptx")

    expected_models = {
        "draft": "gemini-3.1-flash-image-preview",
        "final": "gemini-3-pro-image-preview",
    }

    configs_captured: list[GeminiConfig] = []

    async def _capture_config(requests: Any, config: GeminiConfig, **_kw: Any) -> list[ImageResult]:
        configs_captured.append(config)
        return _make_image_results(len(requests))

    for quality, expected_model in expected_models.items():
        configs_captured.clear()
        with (
            patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
            patch(_TARGET_LOAD_CACHE, return_value=None),
            patch(_TARGET_SAVE_CACHE),
            patch(_TARGET_GENERATE, side_effect=_capture_config),
            patch(_TARGET_BUILD_PPTX, return_value=fake_output),
            patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
            patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
            patch(_TARGET_READ_CACHED, return_value=None),
        ):
            await run_generate_deck(
                prompt_id=prompt_cache.store(MINIMAL_1_SLIDE).prompt_id,
                output_path="/tmp/quality_test.pptx",
                image_quality=quality,
            )

        assert len(configs_captured) == 1
        assert configs_captured[0].model == expected_model, (
            f"quality={quality!r} should use {expected_model}, got {configs_captured[0].model!r}"
        )


# ---------------------------------------------------------------------------
# TC-13: server.py wrapper calls run_generate_deck and returns its result
# ---------------------------------------------------------------------------


async def test_tc13_server_wrapper_calls_implementation() -> None:
    """TC-13: server.generate_deck awaits run_generate_deck."""
    expected_result: dict[str, object] = {
        "status": "ok",
        "output_path": "/tmp/wrapper_test.pptx",
        "slide_count": 1,
        "slides_generated": 1,
        "slides_cached": 0,
        "cost_estimate": "~1 image(s) generated (est. $0.001 USD)",
    }

    async def _fake_impl(*args: Any, **kwargs: Any) -> dict[str, object]:
        return expected_result

    with patch(
        "renderdeck_mcp.tools.generate_deck.run_generate_deck",
        side_effect=_fake_impl,
    ):
        from renderdeck_mcp import server

        result = await server.generate_deck(
            prompt_id=prompt_cache.store("# Test\n\n---\n\n## Slide 01 — T\nP").prompt_id
        )

    assert result == expected_result


# ---------------------------------------------------------------------------
# TC-14: Error result from empty prompt has no output_path field (or empty)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc14_error_result_has_no_output_path() -> None:
    """TC-14: Error results do not include output_path (or it is absent/None)."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    with patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}):
        result = await run_generate_deck(prompt_id=prompt_cache.store("").prompt_id)

    assert result["status"] == "error"
    # output_path should not be present or should be None/empty on error
    assert "output_path" not in result or result.get("output_path") is None


# ---------------------------------------------------------------------------
# TC-15: Slides with no image prompts — skip Gemini, produce text-only deck
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc15_slides_without_image_prompts_produce_text_only_deck() -> None:
    """TC-15: Slides with has_prompt=False skip Gemini; produce pptx."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    no_prompt_content = """\
# No Prompt Deck

---

## Slide 01 — Title Only
"""
    fake_output = Path("/tmp/no_prompt.pptx")

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=None),
        patch(_TARGET_SAVE_CACHE),
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=[]) as mock_gen,
        patch(_TARGET_BUILD_PPTX, return_value=fake_output),
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
        patch(_TARGET_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_cache.store(no_prompt_content).prompt_id,
            output_path="/tmp/no_prompt.pptx",
        )

    assert result["status"] == "ok"
    assert result["slide_count"] == 1
    # Gemini should not be called for slides with no prompt
    mock_gen.assert_not_called()


# ===========================================================================
# EXE-1104: prompt_id workflow integration tests
# ===========================================================================


# ---------------------------------------------------------------------------
# TC-P01: validate → generate_deck using prompt_id (happy path)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_generate_deck_with_prompt_id(clear_prompt_cache: object) -> None:
    """TC-P01: validate returns prompt_id; run_generate_deck accepts it and succeeds."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck
    from renderdeck_mcp.tools.validate import run_validate

    # Step 1 — Validate and capture prompt_id
    validate_result = run_validate(MINIMAL_3_SLIDES)
    assert validate_result["valid"] is True, "Fixture content must be valid"
    prompt_id: str = validate_result["prompt_id"]  # type: ignore[assignment]
    assert isinstance(prompt_id, str) and len(prompt_id) == 64

    # Step 2 — Generate deck using the returned prompt_id (Gemini mocked)
    fake_output = Path("/tmp/prompt_id_test.pptx")
    image_results = _make_image_results(3)

    with (
        patch.dict("os.environ", {"GOOGLE_GEMINI_API_KEY": "test-key"}),
        patch(_TARGET_LOAD_CACHE, return_value=None),
        patch(_TARGET_SAVE_CACHE),
        patch(_TARGET_GENERATE, new_callable=AsyncMock, return_value=image_results),
        patch(_TARGET_BUILD_PPTX, return_value=fake_output),
        patch(_TARGET_CONTENT_HASH, return_value=_fake_hash(0)),
        patch(_TARGET_OPTIONS_HASH, return_value="optshash1234abcd"),
        patch(_TARGET_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            prompt_id=prompt_id,
            output_path="/tmp/prompt_id_test.pptx",
        )

    assert result["status"] == "ok", f"Expected status='ok', got: {result}"
    assert result["slide_count"] == 3


# ---------------------------------------------------------------------------
# TC-P02: generate_deck with unknown prompt_id returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_generate_deck_unknown_prompt_id(clear_prompt_cache: object) -> None:
    """TC-P02: run_generate_deck with an unknown prompt_id returns a clear error."""
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    result = await run_generate_deck(prompt_id="a" * 64)

    assert result["status"] == "error"
    assert "message" in result
    msg: str = str(result["message"])
    assert "prompt_id" in msg.lower() or "unknown" in msg.lower()


# ---------------------------------------------------------------------------
# TC-P03: run_generate_deck signature no longer accepts slide_prompt_content
# ---------------------------------------------------------------------------


def test_generate_deck_no_slide_prompt_content_param() -> None:
    """TC-P03: run_generate_deck parameter list does not include slide_prompt_content."""
    import inspect

    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    params = inspect.signature(run_generate_deck).parameters
    assert "slide_prompt_content" not in params, (
        "run_generate_deck must not have a slide_prompt_content parameter after EXE-1104"
    )
    assert "prompt_id" in params, "run_generate_deck must have a prompt_id parameter after EXE-1104"
