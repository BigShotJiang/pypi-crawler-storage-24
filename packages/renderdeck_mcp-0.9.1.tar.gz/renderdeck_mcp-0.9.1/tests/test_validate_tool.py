"""Tests for the validate_prompt_file MCP tool."""

from __future__ import annotations

import re
import sys
from pathlib import Path

import pytest

from renderdeck_mcp.tools.validate import run_validate

VALID_PROMPT = """\
# My Presentation

## General

A test deck for validation.

## Global Rules

FORMAT: 16:9

---

## Slide 01 — Introduction

A wide-format opening slide.

---

## Slide 02 — Main Content

Content with data visualisation.

---

## Slide 03 — Closing

Final statement slide.

## Speaker Notes

### Slide 01 — Introduction

**Say:** Welcome everyone.
**Time:** 30 seconds

### Slide 02 — Main Content

**Say:** Here is the data.
**Time:** 2 minutes

### Slide 03 — Closing

**Say:** Thank you.
**Time:** 15 seconds
"""

INVALID_PROMPT_NO_H1 = """\
## Slide 01 — First Slide

Content here.
"""

INVALID_PROMPT_MULTI_ERROR = """\
# Title

## Slide 1 — Bad Number

Not zero-padded.

---

## Slide 01 — First

Content.

---

## Slide 01 — Duplicate

Same number again.
"""


class TestRunValidate:
    """Tests for run_validate."""

    def test_valid_file_returns_valid_true(self) -> None:
        result = run_validate(VALID_PROMPT)
        assert result["valid"] is True
        assert result["slide_count"] == 3
        assert len(result["errors"]) == 0

    def test_valid_file_slides_populated(self) -> None:
        result = run_validate(VALID_PROMPT)
        slides = result["slides"]
        assert len(slides) == 3
        assert slides[0] == {"number": 1, "title": "Introduction", "line_number": 13}
        assert slides[1]["number"] == 2
        assert slides[2]["number"] == 3

    def test_valid_file_slide_dict_keys(self) -> None:
        result = run_validate(VALID_PROMPT)
        slide = result["slides"][0]
        assert set(slide.keys()) == {"number", "title", "line_number"}

    def test_invalid_no_h1_returns_error(self) -> None:
        result = run_validate(INVALID_PROMPT_NO_H1)
        assert result["valid"] is False
        assert len(result["errors"]) >= 1
        assert any("H1" in e["message"] for e in result["errors"])

    def test_error_dict_keys(self) -> None:
        result = run_validate(INVALID_PROMPT_NO_H1)
        error = result["errors"][0]
        assert set(error.keys()) == {"line_number", "message", "slide_number"}

    def test_multiple_errors_all_reported(self) -> None:
        result = run_validate(INVALID_PROMPT_MULTI_ERROR)
        assert result["valid"] is False
        # Should have at least: non-zero-padded slide 1, duplicate slide 01
        assert len(result["errors"]) >= 2

    def test_empty_input_returns_error_not_crash(self) -> None:
        result = run_validate("")
        assert result["valid"] is False
        assert len(result["errors"]) >= 1

    def test_warnings_included(self) -> None:
        result = run_validate(VALID_PROMPT)
        assert isinstance(result["warnings"], list)

    def test_return_type_is_dict(self) -> None:
        result = run_validate(VALID_PROMPT)
        assert isinstance(result, dict)
        assert set(result.keys()) == {
            "valid",
            "slide_count",
            "slides",
            "errors",
            "warnings",
            "prompt_id",
        }


# ---------------------------------------------------------------------------
# Prompt-cache integration: prompt_id in validate response (EXE-1104)
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clear_prompt_cache_validate() -> object:
    """Clear the module-level prompt_cache singleton after every test in this module."""
    yield
    try:
        from renderdeck_mcp.cache import prompt_cache

        prompt_cache.clear()
    except ImportError:
        pass  # cache module not yet implemented; tests that need it will fail explicitly


class TestValidatePromptId:
    """Tests that run_validate returns a prompt_id field (EXE-1104)."""

    def test_validate_returns_prompt_id_key(self) -> None:
        """The validate response dict must include a 'prompt_id' key."""
        result = run_validate(VALID_PROMPT)
        assert "prompt_id" in result

    def test_validate_prompt_id_is_string(self) -> None:
        """The prompt_id value must be a str."""
        result = run_validate(VALID_PROMPT)
        assert isinstance(result["prompt_id"], str)

    def test_validate_prompt_id_is_64_hex_chars(self) -> None:
        """The prompt_id must be exactly 64 lowercase hexadecimal characters."""
        result = run_validate(VALID_PROMPT)
        prompt_id = result["prompt_id"]
        assert len(prompt_id) == 64
        assert re.fullmatch(r"[0-9a-f]{64}", prompt_id)

    def test_validate_invalid_still_returns_prompt_id(self) -> None:
        """Even when validation fails, the response dict must include prompt_id."""
        result = run_validate(INVALID_PROMPT_NO_H1)
        assert result["valid"] is False
        assert "prompt_id" in result
        assert isinstance(result["prompt_id"], str)
        assert len(result["prompt_id"]) == 64

    def test_validate_same_content_same_id(self) -> None:
        """Calling run_validate twice with identical content returns the same prompt_id."""
        result_a = run_validate(VALID_PROMPT)
        result_b = run_validate(VALID_PROMPT)
        assert result_a["prompt_id"] == result_b["prompt_id"]


# ---------------------------------------------------------------------------
# file_path parameter (validate-file-path-param)
# ---------------------------------------------------------------------------


class TestRunValidateFilePath:
    """Tests for the optional file_path parameter on run_validate."""

    # ------------------------------------------------------------------
    # Helper fixture
    # ------------------------------------------------------------------

    @pytest.fixture()
    def valid_prompt_file(self, tmp_path: Path) -> Path:
        p = tmp_path / "valid_prompt.txt"
        p.write_text(VALID_PROMPT, encoding="utf-8")
        return p

    # ------------------------------------------------------------------
    # Mutual-exclusion guard tests
    # ------------------------------------------------------------------

    def test_neither_param_returns_error(self) -> None:
        """Calling run_validate() with no arguments returns a structured error dict."""
        result = run_validate()
        assert result["valid"] is False
        assert len(result["errors"]) >= 1
        msg = result["errors"][0]["message"]
        assert "slide_prompt_content" in msg
        assert "file_path" in msg

    def test_neither_param_prompt_id_is_empty_string(self) -> None:
        """When neither param is supplied, prompt_id must be an empty string."""
        result = run_validate()
        assert result["prompt_id"] == ""

    def test_both_params_returns_error(self) -> None:
        """Passing both slide_prompt_content and file_path returns a mutual-exclusion error."""
        result = run_validate(slide_prompt_content=VALID_PROMPT, file_path="/some/path.txt")
        assert result["valid"] is False
        assert len(result["errors"]) >= 1
        msg = result["errors"][0]["message"]
        assert "not both" in msg or "slide_prompt_content" in msg or "file_path" in msg

    def test_both_params_no_disk_access(self) -> None:
        """When both params are given the error is mutual-exclusion, not file-not-found.

        The path does not exist on disk; this confirms no I/O is attempted when
        both params are present.
        """
        result = run_validate(
            slide_prompt_content=VALID_PROMPT,
            file_path="/nonexistent/path.txt",
        )
        assert result["valid"] is False
        msg = result["errors"][0]["message"]
        # Must NOT be a file-not-found error — it must be the mutual-exclusion error.
        assert "not found" not in msg.lower()
        assert "not both" in msg or "slide_prompt_content" in msg or "file_path" in msg

    # ------------------------------------------------------------------
    # file_path happy-path tests
    # ------------------------------------------------------------------

    def test_file_path_valid_content_returns_valid_true(self, valid_prompt_file: Path) -> None:
        """Reading VALID_PROMPT from a file returns valid=True and slide_count=3."""
        result = run_validate(file_path=str(valid_prompt_file))
        assert result["valid"] is True
        assert result["slide_count"] == 3

    def test_file_path_same_prompt_id_as_inline(self, valid_prompt_file: Path) -> None:
        """prompt_id is content-addressed: file and inline calls with the same content agree."""
        result_inline = run_validate(slide_prompt_content=VALID_PROMPT)
        result_file = run_validate(file_path=str(valid_prompt_file))
        assert result_inline["prompt_id"] == result_file["prompt_id"]

    def test_file_path_invalid_content_returns_valid_false(self, tmp_path: Path) -> None:
        """A file containing invalid prompt content returns valid=False with non-empty errors."""
        p = tmp_path / "invalid_prompt.txt"
        p.write_text(INVALID_PROMPT_NO_H1, encoding="utf-8")
        result = run_validate(file_path=str(p))
        assert result["valid"] is False
        assert len(result["errors"]) >= 1

    def test_file_path_returns_full_result_shape(self, valid_prompt_file: Path) -> None:
        """The result dict has exactly the standard six keys when file_path is used."""
        result = run_validate(file_path=str(valid_prompt_file))
        assert set(result.keys()) == {
            "valid",
            "slide_count",
            "slides",
            "errors",
            "warnings",
            "prompt_id",
        }

    def test_file_path_prompt_id_is_64_hex(self, valid_prompt_file: Path) -> None:
        """prompt_id returned for a file read must be exactly 64 lowercase hex chars."""
        result = run_validate(file_path=str(valid_prompt_file))
        assert re.fullmatch(r"[0-9a-f]{64}", result["prompt_id"])

    # ------------------------------------------------------------------
    # file_path error-path tests
    # ------------------------------------------------------------------

    def test_nonexistent_file_returns_error(self) -> None:
        """A path to a non-existent file returns valid=False with an empty prompt_id."""
        result = run_validate(file_path="/nonexistent/no/such/file.txt")
        assert result["valid"] is False
        assert result["prompt_id"] == ""
        msg = result["errors"][0]["message"]
        assert "not found" in msg.lower() or "File not found" in msg

    def test_nonexistent_file_error_shape(self) -> None:
        """The error dict for a missing file has the standard shape with slide_count=0."""
        result = run_validate(file_path="/nonexistent/no/such/file.txt")
        assert set(result.keys()) == {
            "valid",
            "slide_count",
            "slides",
            "errors",
            "warnings",
            "prompt_id",
        }
        assert result["slide_count"] == 0
        assert result["slides"] == []

    def test_directory_path_returns_error(self, tmp_path: Path) -> None:
        """Passing a path to an existing directory returns a structured error dict."""
        result = run_validate(file_path=str(tmp_path))
        assert result["valid"] is False
        assert len(result["errors"]) >= 1
        msg = result["errors"][0]["message"]
        assert str(tmp_path) in msg or "not found" in msg.lower() or "directory" in msg.lower()

    def test_empty_file_returns_invalid(self, tmp_path: Path) -> None:
        """An empty file produces valid=False (mirrors existing empty-string behaviour)."""
        p = tmp_path / "empty.txt"
        p.write_text("", encoding="utf-8")
        result = run_validate(file_path=str(p))
        assert result["valid"] is False
        assert len(result["errors"]) >= 1

    @pytest.mark.skipif(sys.platform == "win32", reason="chmod not supported on Windows")
    def test_unreadable_file_returns_error(self, tmp_path: Path) -> None:
        """A file with no read permissions returns valid=False with a 'Cannot read' message."""
        p = tmp_path / "locked.txt"
        p.write_text(VALID_PROMPT, encoding="utf-8")
        p.chmod(0o000)
        try:
            result = run_validate(file_path=str(p))
            assert result["valid"] is False
            assert "Cannot read" in result["errors"][0]["message"]
        finally:
            p.chmod(0o644)

    def test_non_utf8_file_returns_error(self, tmp_path: Path) -> None:
        """A file with non-UTF-8 bytes returns valid=False with a 'Cannot read' message."""
        p = tmp_path / "binary.txt"
        p.write_bytes(b"\xff\xfe invalid")
        result = run_validate(file_path=str(p))
        assert result["valid"] is False
        assert "Cannot read" in result["errors"][0]["message"]

    # ------------------------------------------------------------------
    # Backward-compatibility tests
    # ------------------------------------------------------------------

    def test_inline_content_still_works_with_new_signature(self) -> None:
        """Keyword-style call run_validate(slide_prompt_content=...) continues to work."""
        result = run_validate(slide_prompt_content=VALID_PROMPT)
        assert result["valid"] is True

    def test_positional_content_still_works(self) -> None:
        """Positional call run_validate(VALID_PROMPT) continues to work."""
        result = run_validate(VALID_PROMPT)
        assert result["valid"] is True
