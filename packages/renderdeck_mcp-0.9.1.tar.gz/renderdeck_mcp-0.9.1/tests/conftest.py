"""pytest configuration and shared fixtures.

Fixtures will be added here as individual epic tasks are implemented.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest


def pytest_addoption(parser: Any) -> None:
    """Add --e2e-output-dir option for persisting E2E test artifacts."""
    parser.addoption(
        "--e2e-output-dir",
        action="store",
        default=None,
        help="Directory to copy E2E test .pptx output files for inspection.",
    )


@pytest.fixture()
def e2e_output_dir(request: pytest.FixtureRequest) -> Path | None:
    """Return the --e2e-output-dir path (created if needed), or None."""
    raw = request.config.getoption("--e2e-output-dir")
    if raw is None:
        return None
    out = Path(raw)
    out.mkdir(parents=True, exist_ok=True)
    return out


# Saved modules cleared before import-isolation tests, restored after.
_saved_modules: dict[str, Any] = {}


def pytest_collection_modifyitems(items: list[Any]) -> None:
    """Ensure import-isolation tests run before tests that load google-genai SDK."""
    early: list[Any] = []
    rest: list[Any] = []
    for item in items:
        if "no_google_import" in item.nodeid or "no_import_of_google" in item.nodeid:
            early.append(item)
        else:
            rest.append(item)
    items[:] = early + rest


def pytest_runtest_setup(item: object) -> None:
    """Clear polluting modules before import-isolation tests."""
    nodeid = getattr(item, "nodeid", "")
    if "no_google_import" not in nodeid and "no_import_of_google" not in nodeid:
        return

    _saved_modules.clear()
    for key in list(sys.modules):
        if key.startswith(("google", "dotenv", "renderdeck_mcp")):
            _saved_modules[key] = sys.modules.pop(key)


def pytest_runtest_teardown(item: object) -> None:
    """Restore cleared modules after import-isolation tests."""
    nodeid = getattr(item, "nodeid", "")
    if "no_google_import" not in nodeid and "no_import_of_google" not in nodeid:
        return

    if _saved_modules:
        sys.modules.update(_saved_modules)
        _saved_modules.clear()


# ---------------------------------------------------------------------------
# Prompt cache cleanup (EXE-1104)
# ---------------------------------------------------------------------------


@pytest.fixture()
def clear_prompt_cache() -> object:
    """Fixture that clears the module-level prompt_cache singleton after the test.

    Opt-in version — use this fixture explicitly in tests that manipulate
    the singleton directly and need guaranteed isolation.  Tests in
    test_prompt_cache.py use their own autouse variant instead.
    """
    yield
    try:
        from renderdeck_mcp.cache import prompt_cache  # noqa: PLC0415

        prompt_cache.clear()
    except ImportError:
        pass  # cache module not yet implemented; safe to ignore in other test modules
