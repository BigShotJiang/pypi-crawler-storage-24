"""Unit tests for reference image resolution and generate_image integration.

Tests cover:
- TC-R01 through TC-R10: _fetch_url_as_base64 and _resolve_reference_image
- TC-V01 through TC-V03: generate_image validation (>14 refs limit, 0 refs text path)
- TC-I01 through TC-I03: generate_image integration with reference image resolution

All tests mock external I/O. No real network requests are made.

Design doc: docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/design.md
Test handoff: docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/test-handoff.md
"""

from __future__ import annotations

import base64
import logging
import urllib.error
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from renderdeck_mcp.generation.gemini import (
    AspectRatio,
    GeminiConfig,
    SlideImageRequest,
    generate_image,
)
from renderdeck_mcp.generation.types import ReferenceImageDict, ResolvedReferenceImage

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MINIMAL_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 20


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def png_base64() -> str:
    return base64.b64encode(MINIMAL_PNG).decode("ascii")


@pytest.fixture
def config() -> GeminiConfig:
    return GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=3,
        max_concurrent_images=3,
        retry_delays=(0.0, 0.0, 0.0),
    )


@pytest.fixture
def url_ref() -> ReferenceImageDict:
    return ReferenceImageDict(
        url="https://example.com/img.png",
        role="brand logo",
        placement="top-right corner",
    )


@pytest.fixture
def base64_ref(png_base64: str) -> ReferenceImageDict:
    return ReferenceImageDict(
        base64=png_base64,
        media_type="image/png",
        role="product screenshot",
        placement="center",
    )


@pytest.fixture
def resolved_ref(png_base64: str) -> ResolvedReferenceImage:
    return ResolvedReferenceImage(
        base64_data=png_base64,
        media_type="image/png",
        role="brand logo",
        placement="top-right corner",
    )


@pytest.fixture
def mock_genai_response() -> MagicMock:
    """A mock Gemini response with one image part containing minimal PNG bytes."""
    part = MagicMock()
    part.inline_data.data = MINIMAL_PNG
    response = MagicMock()
    response.parts = [part]
    return response


@pytest.fixture
def mock_client(mock_genai_response: MagicMock) -> MagicMock:
    client = MagicMock()
    client.models.generate_content.return_value = mock_genai_response
    return client


def _make_url_mock_response(status: int = 200, data: bytes = MINIMAL_PNG) -> MagicMock:
    """Create a mock urllib response context manager."""
    mock_response = MagicMock()
    mock_response.status = status
    mock_response.read.return_value = data
    mock_ctx = MagicMock()
    mock_ctx.__enter__ = MagicMock(return_value=mock_response)
    mock_ctx.__exit__ = MagicMock(return_value=False)
    return mock_ctx


# ---------------------------------------------------------------------------
# Helpers — import lazy so tests fail clearly when implementation is absent
# ---------------------------------------------------------------------------


def _fetch_url_as_base64(url: str):  # type: ignore[return]
    from renderdeck_mcp.generation.gemini import _fetch_url_as_base64 as _fn

    return _fn(url)


def _resolve_reference_image(ref: ReferenceImageDict):  # type: ignore[return]
    from renderdeck_mcp.generation.gemini import _resolve_reference_image as _fn

    return _fn(ref)


# ---------------------------------------------------------------------------
# Category R — Reference resolution
# ---------------------------------------------------------------------------


async def test_tc_r01_fetch_url_as_base64_success(png_base64: str) -> None:
    """TC-R01: Successful HTTP fetch returns base64-encoded bytes."""
    mock_ctx = _make_url_mock_response(status=200, data=MINIMAL_PNG)

    with patch("urllib.request.urlopen", return_value=mock_ctx):
        result = await _fetch_url_as_base64("https://example.com/img.png")

    assert result == png_base64


async def test_tc_r02_fetch_url_as_base64_network_error_returns_none(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """TC-R02: URLError results in None return and a warning log."""
    with (
        patch(
            "urllib.request.urlopen",
            side_effect=urllib.error.URLError("Connection refused"),
        ),
        caplog.at_level(logging.WARNING, logger="renderdeck_mcp.generation.gemini"),
    ):
        result = await _fetch_url_as_base64("https://broken.example.com/img.png")

    assert result is None
    assert any(r.levelno == logging.WARNING for r in caplog.records)


async def test_tc_r03_fetch_url_as_base64_non_200_status_returns_none(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """TC-R03: A 404 response returns None and logs a warning."""
    mock_ctx = _make_url_mock_response(status=404)

    with (
        patch("urllib.request.urlopen", return_value=mock_ctx),
        caplog.at_level(logging.WARNING, logger="renderdeck_mcp.generation.gemini"),
    ):
        result = await _fetch_url_as_base64("https://example.com/missing.png")

    assert result is None
    assert any(r.levelno == logging.WARNING for r in caplog.records)


async def test_tc_r04_resolve_reference_image_url_field_success(png_base64: str) -> None:
    """TC-R04: ReferenceImageDict with url resolves to ResolvedReferenceImage."""
    ref: ReferenceImageDict = {
        "url": "https://example.com/img.png",
        "role": "logo",
        "placement": "top-right",
    }

    with patch(
        "renderdeck_mcp.generation.gemini._fetch_url_as_base64",
        new_callable=AsyncMock,
        return_value=png_base64,
    ):
        result = await _resolve_reference_image(ref)

    assert result is not None
    assert isinstance(result, ResolvedReferenceImage)
    assert result.base64_data == png_base64
    assert result.media_type == "image/png"
    assert result.role == "logo"
    assert result.placement == "top-right"


async def test_tc_r05_resolve_reference_image_url_fetch_failure_returns_none() -> None:
    """TC-R05: When _fetch_url_as_base64 returns None, _resolve_reference_image returns None."""
    ref: ReferenceImageDict = {"url": "https://broken.example.com/img.png"}

    with patch(
        "renderdeck_mcp.generation.gemini._fetch_url_as_base64",
        new_callable=AsyncMock,
        return_value=None,
    ):
        result = await _resolve_reference_image(ref)

    assert result is None


async def test_tc_r06_resolve_reference_image_base64_field_valid(png_base64: str) -> None:
    """TC-R06: ReferenceImageDict with base64 field resolves directly."""
    ref: ReferenceImageDict = {
        "base64": png_base64,
        "media_type": "image/jpeg",
        "role": "hero",
    }

    result = await _resolve_reference_image(ref)

    assert result is not None
    assert result.base64_data == png_base64
    assert result.media_type == "image/jpeg"
    assert result.role == "hero"
    assert result.placement == ""


async def test_tc_r07_resolve_reference_image_invalid_base64_returns_none(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """TC-R07: Invalid base64 data returns None and logs a warning."""
    ref: ReferenceImageDict = {"base64": "!!!not-valid-base64!!!"}

    with caplog.at_level(logging.WARNING, logger="renderdeck_mcp.generation.gemini"):
        result = await _resolve_reference_image(ref)

    assert result is None
    warning_messages = " ".join(
        r.getMessage() for r in caplog.records if r.levelno == logging.WARNING
    )
    assert "base64" in warning_messages.lower() or "invalid" in warning_messages.lower()


async def test_tc_r08_resolve_reference_image_empty_base64_returns_none() -> None:
    """TC-R08: Empty string in base64 field is treated as invalid, returns None."""
    ref: ReferenceImageDict = {"base64": ""}

    result = await _resolve_reference_image(ref)

    assert result is None


async def test_tc_r09_resolve_reference_image_neither_url_nor_base64_returns_none(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """TC-R09: Dict with only role and no image source returns None."""
    ref: ReferenceImageDict = {"role": "orphaned"}

    with caplog.at_level(logging.WARNING, logger="renderdeck_mcp.generation.gemini"):
        result = await _resolve_reference_image(ref)

    assert result is None


async def test_tc_r10_resolve_reference_image_default_media_type_is_png(png_base64: str) -> None:
    """TC-R10: Default media_type is image/png when absent."""
    ref: ReferenceImageDict = {"base64": png_base64}

    result = await _resolve_reference_image(ref)

    assert result is not None
    assert result.media_type == "image/png"


# ---------------------------------------------------------------------------
# Category V — Validation
# ---------------------------------------------------------------------------


async def test_tc_v01_generate_image_raises_for_more_than_14_references(
    mock_client: MagicMock,
    config: GeminiConfig,
    png_base64: str,
) -> None:
    """TC-V01: 15 reference images raises ValueError before any API call."""
    refs = tuple({"base64": png_base64} for _ in range(15))
    request = SlideImageRequest(
        slide_index=0,
        prompt="A slide",
        aspect_ratio=AspectRatio.WIDE,
        reference_images=refs,
    )

    with pytest.raises(ValueError, match="14"):
        await generate_image(mock_client, request, config)

    mock_client.models.generate_content.assert_not_called()


async def test_tc_v02_generate_image_accepts_exactly_14_references(
    mock_client: MagicMock,
    config: GeminiConfig,
    png_base64: str,
) -> None:
    """TC-V02: 14 reference images is within the limit; no ValueError raised."""
    refs = tuple({"base64": png_base64} for _ in range(14))
    request = SlideImageRequest(
        slide_index=0,
        prompt="A slide",
        aspect_ratio=AspectRatio.WIDE,
        reference_images=refs,
    )

    with patch("asyncio.sleep", new_callable=AsyncMock):
        try:
            await generate_image(mock_client, request, config)
        except ValueError:
            pytest.fail("ValueError raised for exactly 14 references — should be allowed")

    mock_client.models.generate_content.assert_called()


async def test_tc_v03_generate_image_zero_references_uses_text_only_path(
    mock_client: MagicMock,
    config: GeminiConfig,
) -> None:
    """TC-V03: Empty reference_images tuple passes str (not list) as contents."""
    request = SlideImageRequest(
        slide_index=0,
        prompt="A plain slide",
        aspect_ratio=AspectRatio.WIDE,
    )

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, request, config)

    assert result == MINIMAL_PNG
    call_kwargs = mock_client.models.generate_content.call_args
    _, kwargs = call_kwargs
    contents_arg = kwargs.get("contents")
    assert isinstance(contents_arg, str), (
        f"Expected str contents for text-only path, got {type(contents_arg).__name__}"
    )


# ---------------------------------------------------------------------------
# Category I — Integration within generate_image
# ---------------------------------------------------------------------------


async def test_tc_i01_generate_image_with_references_passes_list_to_sdk(
    mock_client: MagicMock,
    config: GeminiConfig,
    png_base64: str,
) -> None:
    """TC-I01: Resolved references cause generate_content to receive a list for contents."""
    ref: ReferenceImageDict = {"base64": png_base64, "role": "logo"}
    request = SlideImageRequest(
        slide_index=0,
        prompt="A product overview slide",
        aspect_ratio=AspectRatio.WIDE,
        reference_images=(ref,),
    )

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, request, config)

    assert result == MINIMAL_PNG
    call_kwargs = mock_client.models.generate_content.call_args
    _, kwargs = call_kwargs
    contents_arg = kwargs.get("contents")
    assert isinstance(contents_arg, list), (
        f"Expected list contents for multimodal path, got {type(contents_arg).__name__}"
    )


async def test_tc_i02_generate_image_all_references_fail_falls_back_to_text(
    mock_client: MagicMock,
    config: GeminiConfig,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """TC-I02: All references failing to resolve falls back to text-only contents."""
    refs: tuple[ReferenceImageDict, ...] = (
        {"url": "https://broken1.example.com/img.png"},
        {"url": "https://broken2.example.com/img.png"},
    )
    request = SlideImageRequest(
        slide_index=0,
        prompt="A product slide",
        aspect_ratio=AspectRatio.WIDE,
        reference_images=refs,
    )

    with (
        patch(
            "renderdeck_mcp.generation.gemini._fetch_url_as_base64",
            new_callable=AsyncMock,
            return_value=None,
        ),
        patch("asyncio.sleep", new_callable=AsyncMock),
        caplog.at_level(logging.WARNING, logger="renderdeck_mcp.generation.gemini"),
    ):
        result = await generate_image(mock_client, request, config)

    assert result == MINIMAL_PNG
    call_kwargs = mock_client.models.generate_content.call_args
    _, kwargs = call_kwargs
    contents_arg = kwargs.get("contents")
    assert isinstance(contents_arg, str), (
        "Expected text-only fallback (str) when all references fail"
    )
    # The text-only fallback (asserted above as isinstance str) is the key behavior.
    # _fetch_url_as_base64 is mocked to return None, so no warnings from the real fetcher.


async def test_tc_i03_generate_image_partial_resolution(
    mock_client: MagicMock,
    config: GeminiConfig,
    png_base64: str,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """TC-I03: One valid and one invalid base64 ref — only the valid one appears in contents."""
    valid_ref: ReferenceImageDict = {"base64": png_base64, "role": "valid"}
    invalid_ref: ReferenceImageDict = {"base64": "!!!bad-base64!!!", "role": "invalid"}
    request = SlideImageRequest(
        slide_index=0,
        prompt="A mixed slide",
        aspect_ratio=AspectRatio.WIDE,
        reference_images=(valid_ref, invalid_ref),
    )

    with (
        patch("asyncio.sleep", new_callable=AsyncMock),
        caplog.at_level(logging.WARNING, logger="renderdeck_mcp.generation.gemini"),
    ):
        result = await generate_image(mock_client, request, config)

    assert result == MINIMAL_PNG

    call_kwargs = mock_client.models.generate_content.call_args
    _, kwargs = call_kwargs
    contents_arg = kwargs.get("contents")

    # One resolved image + one text part = 2-element list
    assert isinstance(contents_arg, list)
    assert len(contents_arg) == 2

    # At least one warning for the invalid reference
    warning_messages = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warning_messages) >= 1


async def test_tc_i01_generate_image_multimodal_text_part_is_last(
    mock_client: MagicMock,
    config: GeminiConfig,
    png_base64: str,
) -> None:
    """TC-I01 (additional): The text part is the last element in multimodal contents."""
    ref: ReferenceImageDict = {"base64": png_base64, "role": "logo"}
    request = SlideImageRequest(
        slide_index=0,
        prompt="Slide prompt text",
        aspect_ratio=AspectRatio.WIDE,
        reference_images=(ref,),
    )

    with patch("asyncio.sleep", new_callable=AsyncMock):
        await generate_image(mock_client, request, config)

    call_kwargs = mock_client.models.generate_content.call_args
    _, kwargs = call_kwargs
    contents_arg = kwargs.get("contents")

    assert isinstance(contents_arg, list)
    # Last element should be a text Part
    last_part = contents_arg[-1]
    # The text part should have a text attribute
    assert hasattr(last_part, "text") or (
        hasattr(last_part, "__class__") and "Part" in type(last_part).__name__
    )
