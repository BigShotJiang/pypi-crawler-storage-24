"""Unit tests for REFERENCES: block parsing in parser/prompt_file.py.

Tests cover TC-P01 through TC-P09 from the reference-image-input test handoff.

Modules under test:
- src/renderdeck_mcp/parser/prompt_file.py  (extended with _parse_references_block and
  REFERENCES: extraction from ParsedSlide.reference_images)

All tests are pure unit tests — no I/O, no network, no mocking needed.
The functions are pure parsers operating on strings.
"""

from __future__ import annotations

from renderdeck_mcp.generation.types import ReferenceImageDict
from renderdeck_mcp.parser.prompt_file import parse_prompt_file

# ---------------------------------------------------------------------------
# Helpers for _parse_references_block (imported lazily to survive
# pre-implementation runs via importerror at function scope)
# ---------------------------------------------------------------------------


def _parse_references_block(block_text: str) -> list[ReferenceImageDict]:
    """Thin import shim so tests import from the expected module location."""
    from renderdeck_mcp.parser.prompt_file import _parse_references_block as _fn

    return _fn(block_text)


# ---------------------------------------------------------------------------
# Category A — _parse_references_block (TC-P01 to TC-P05)
# ---------------------------------------------------------------------------


def test_tc_p01_parse_references_block_url_role_placement() -> None:
    """TC-P01: Well-formed block with one URL entry parsed correctly."""
    block = "- url: https://example.com/img.png\n  role: brand logo\n  placement: top-right corner"

    result = _parse_references_block(block)

    assert len(result) == 1
    assert result[0]["url"] == "https://example.com/img.png"
    assert result[0]["role"] == "brand logo"
    assert result[0]["placement"] == "top-right corner"


def test_tc_p02_parse_references_block_base64_entry() -> None:
    """TC-P02: Entry with base64 field instead of url is parsed correctly."""
    block = "- base64: aGVsbG8=\n  media_type: image/jpeg\n  role: hero image"

    result = _parse_references_block(block)

    assert len(result) == 1
    assert result[0]["base64"] == "aGVsbG8="
    assert result[0]["media_type"] == "image/jpeg"
    assert result[0]["role"] == "hero image"


def test_tc_p03_parse_references_block_multiple_entries() -> None:
    """TC-P03: Two entries separated by a blank line produce two dicts."""
    block = (
        "- url: https://a.com/1.png\n  role: logo\n\n- url: https://b.com/2.png\n  role: background"
    )

    result = _parse_references_block(block)

    assert len(result) == 2
    assert result[0]["url"] == "https://a.com/1.png"
    assert result[0]["role"] == "logo"
    assert result[1]["url"] == "https://b.com/2.png"
    assert result[1]["role"] == "background"


def test_tc_p04_parse_references_block_skips_entries_without_url_or_base64() -> None:
    """TC-P04: An entry with only role and no image source is silently dropped."""
    block = "- role: orphaned\n  placement: center"

    result = _parse_references_block(block)

    assert result == []


def test_tc_p05_parse_references_block_empty_input() -> None:
    """TC-P05: Empty string input returns empty list."""
    result = _parse_references_block("")

    assert result == []


# ---------------------------------------------------------------------------
# Category A — parse_prompt_file with REFERENCES: blocks (TC-P06 to TC-P09)
# ---------------------------------------------------------------------------

_SLIDE_WITH_REFERENCES = """\
# My Deck

---

## Slide 01 — Intro

Show a bold title card.

REFERENCES:
- url: https://example.com/logo.png
  role: brand logo
  placement: top-right corner
"""

_SLIDE_WITHOUT_REFERENCES = """\
# My Deck

---

## Slide 01 — Intro

Show a bold title card.
"""

_SLIDE_REFERENCES_BEFORE_NOTES = """\
# My Deck

---

## Slide 01 — Intro

Image prompt text.

REFERENCES:
- url: https://example.com/img.png
  role: hero

### Speaker Notes
Notes here.
"""


def test_tc_p06_parse_prompt_file_references_extracted_from_slide_body() -> None:
    """TC-P06: REFERENCES: block extracted into reference_images, removed from image_prompt."""
    deck = parse_prompt_file(_SLIDE_WITH_REFERENCES)

    slide = deck.slides[0]
    assert slide.image_prompt == "Show a bold title card."
    assert len(slide.reference_images) == 1
    assert slide.reference_images[0]["url"] == "https://example.com/logo.png"
    assert slide.reference_images[0]["role"] == "brand logo"
    assert slide.reference_images[0]["placement"] == "top-right corner"


def test_tc_p06_parse_prompt_file_has_prompt_true_with_references() -> None:
    """TC-P06: has_prompt is True when text exists before REFERENCES: block."""
    deck = parse_prompt_file(_SLIDE_WITH_REFERENCES)

    assert deck.slides[0].has_prompt is True


def test_tc_p06_parse_prompt_file_references_block_removed_from_prompt() -> None:
    """TC-P06: The REFERENCES: keyword does not appear in image_prompt."""
    deck = parse_prompt_file(_SLIDE_WITH_REFERENCES)

    assert "REFERENCES:" not in deck.slides[0].image_prompt
    assert "https://example.com/logo.png" not in deck.slides[0].image_prompt


def test_tc_p07_parse_prompt_file_no_references_block_yields_empty_list() -> None:
    """TC-P07: Missing REFERENCES: block produces reference_images=[] (backward compatible)."""
    deck = parse_prompt_file(_SLIDE_WITHOUT_REFERENCES)

    assert deck.slides[0].reference_images == []


def test_tc_p07_parse_prompt_file_no_references_prompt_unchanged() -> None:
    """TC-P07: Slide without REFERENCES: keeps its full image_prompt."""
    deck = parse_prompt_file(_SLIDE_WITHOUT_REFERENCES)

    assert deck.slides[0].image_prompt == "Show a bold title card."


def test_tc_p08_parse_prompt_file_has_prompt_true_when_text_before_references() -> None:
    """TC-P08: has_prompt is True when image prompt text exists before REFERENCES: block."""
    content = """\
# Deck

---

## Slide 01 — Test

My prompt text.

REFERENCES:
- url: https://example.com/img.png
  role: logo
"""
    deck = parse_prompt_file(content)

    slide = deck.slides[0]
    assert slide.has_prompt is True
    assert slide.image_prompt == "My prompt text."


def test_tc_p08_parse_prompt_file_image_prompt_is_text_before_references() -> None:
    """TC-P08: image_prompt is the text before REFERENCES:, stripped."""
    content = """\
# Deck

---

## Slide 01 — Test

Prompt before refs.

REFERENCES:
- url: https://example.com/img.png
  role: logo
"""
    deck = parse_prompt_file(content)

    assert deck.slides[0].image_prompt == "Prompt before refs."


def test_tc_p09_parse_prompt_file_references_and_speaker_notes() -> None:
    """TC-P09: REFERENCES: block stripped before speaker notes parsing."""
    deck = parse_prompt_file(_SLIDE_REFERENCES_BEFORE_NOTES)

    slide = deck.slides[0]
    assert slide.image_prompt == "Image prompt text."
    assert len(slide.reference_images) == 1
    assert slide.reference_images[0]["url"] == "https://example.com/img.png"
    assert slide.reference_images[0]["role"] == "hero"
    assert slide.speaker_notes == "Notes here."


def test_tc_p09_references_and_notes_both_present_has_notes_true() -> None:
    """TC-P09: has_notes is True when speaker notes follow REFERENCES: block."""
    deck = parse_prompt_file(_SLIDE_REFERENCES_BEFORE_NOTES)

    assert deck.slides[0].has_notes is True


def test_parse_prompt_file_reference_images_field_default_is_list() -> None:
    """ParsedSlide.reference_images defaults to [] (not None) for backward compatibility."""
    deck = parse_prompt_file(_SLIDE_WITHOUT_REFERENCES)

    assert isinstance(deck.slides[0].reference_images, list)


def test_parse_prompt_file_multiple_slides_independent_references() -> None:
    """Each slide carries its own reference_images independently."""
    content = """\
# Deck

---

## Slide 01 — First

First prompt.

REFERENCES:
- url: https://example.com/a.png
  role: logo a

---

## Slide 02 — Second

Second prompt.

REFERENCES:
- url: https://example.com/b.png
  role: logo b
"""
    deck = parse_prompt_file(content)

    assert len(deck.slides) == 2
    assert deck.slides[0].reference_images[0]["url"] == "https://example.com/a.png"
    assert deck.slides[1].reference_images[0]["url"] == "https://example.com/b.png"


def test_parse_prompt_file_slide_with_only_references_has_no_prompt() -> None:
    """Slide with no text before REFERENCES: has has_prompt=False and empty image_prompt."""
    content = """\
# Deck

---

## Slide 01 — Empty Prompt

REFERENCES:
- url: https://example.com/img.png
  role: background
"""
    deck = parse_prompt_file(content)

    slide = deck.slides[0]
    assert slide.image_prompt == ""
    assert slide.has_prompt is False
    assert len(slide.reference_images) == 1
