"""Unit tests for the prompt-file cache (EXE-1104).

Tests cover PromptCache.store, PromptCache.get, PromptCache.remove,
eviction, PromptCache.clear, __len__, get_validated_entry, hash
computation, and edge cases.

The implementation module (renderdeck_mcp.cache) does not exist yet.
These tests define the expected behaviour and will pass once the
implementation is in place.
"""

from __future__ import annotations

import hashlib
import re

import pytest

from renderdeck_mcp.cache import prompt_cache
from renderdeck_mcp.cache.prompt_cache import (
    PromptCache,
    PromptCacheEntry,
    get_validated_entry,
)

# ---------------------------------------------------------------------------
# Shared prompt fixtures
# ---------------------------------------------------------------------------

VALID_PROMPT = """\
# Test Presentation

## General

A test deck for caching.

## Global Rules

FORMAT: 16:9

---

## Slide 01 — Introduction

A wide-format opening slide.

---

## Slide 02 — Main Content

Content with data visualisation.

---

## Slide 03 — Closing

Final statement slide.

## Speaker Notes

### Slide 01 — Introduction

**Say:** Welcome everyone.
**Time:** 30 seconds

### Slide 02 — Main Content

**Say:** Here is the data.
**Time:** 2 minutes

### Slide 03 — Closing

**Say:** Thank you.
**Time:** 15 seconds
"""

VALID_PROMPT_2 = """\
# Another Presentation

## General

A second deck for cache isolation testing.

---

## Slide 01 — Opening

Opening content.

---

## Slide 02 — Closing

Closing content.
"""

INVALID_PROMPT_NO_H1 = """\
## Slide 01 — First Slide

Content here.
"""


# ---------------------------------------------------------------------------
# Fixture: clear the module-level singleton between every test
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clear_singleton_cache() -> object:
    """Clear the module-level prompt_cache singleton after every test."""
    yield
    prompt_cache.clear()


# ---------------------------------------------------------------------------
# PromptCache.store
# ---------------------------------------------------------------------------


class TestPromptCacheStore:
    """Tests for PromptCache.store."""

    def test_store_returns_entry_with_prompt_id(self) -> None:
        """Storing valid content returns a PromptCacheEntry with a 64-char hex prompt_id."""
        cache = PromptCache()
        entry = cache.store(VALID_PROMPT)
        assert isinstance(entry, PromptCacheEntry)
        assert isinstance(entry.prompt_id, str)
        assert len(entry.prompt_id) == 64
        assert re.fullmatch(r"[0-9a-f]{64}", entry.prompt_id)

    def test_store_prompt_id_is_sha256_of_content(self) -> None:
        """The prompt_id must equal the SHA-256 hex digest of the UTF-8 encoded content."""
        cache = PromptCache()
        entry = cache.store(VALID_PROMPT)
        expected = hashlib.sha256(VALID_PROMPT.encode("utf-8")).hexdigest()
        assert entry.prompt_id == expected

    def test_store_parses_deck(self) -> None:
        """The stored entry contains a ParsedDeck with the correct title and slide count."""
        cache = PromptCache()
        entry = cache.store(VALID_PROMPT)
        assert entry.parsed_deck is not None
        assert entry.parsed_deck.title == "Test Presentation"
        assert len(entry.parsed_deck.slides) == 3

    def test_store_runs_validation(self) -> None:
        """Storing valid content sets validation_result.valid to True."""
        cache = PromptCache()
        entry = cache.store(VALID_PROMPT)
        assert entry.validation_result is not None
        assert entry.validation_result.valid is True

    def test_store_invalid_content_still_cached(self) -> None:
        """Content that fails validation is still stored; valid is False but prompt_id is set."""
        cache = PromptCache()
        entry = cache.store(INVALID_PROMPT_NO_H1)
        assert isinstance(entry, PromptCacheEntry)
        assert isinstance(entry.prompt_id, str)
        assert len(entry.prompt_id) == 64
        assert entry.validation_result.valid is False
        # Confirm it is actually in the cache
        retrieved = cache.get(entry.prompt_id)
        assert retrieved is not None
        assert retrieved.prompt_id == entry.prompt_id

    def test_store_same_content_returns_same_id(self) -> None:
        """Storing identical content twice returns the same prompt_id both times."""
        cache = PromptCache()
        entry_a = cache.store(VALID_PROMPT)
        entry_b = cache.store(VALID_PROMPT)
        assert entry_a.prompt_id == entry_b.prompt_id

    def test_store_different_content_returns_different_id(self) -> None:
        """Storing two distinct content strings produces two distinct prompt_ids."""
        cache = PromptCache()
        entry_a = cache.store(VALID_PROMPT)
        entry_b = cache.store(VALID_PROMPT_2)
        assert entry_a.prompt_id != entry_b.prompt_id

    def test_store_preserves_raw_content(self) -> None:
        """The entry retains the original raw content string unchanged."""
        cache = PromptCache()
        entry = cache.store(VALID_PROMPT)
        assert entry.raw_content == VALID_PROMPT


# ---------------------------------------------------------------------------
# PromptCache.get
# ---------------------------------------------------------------------------


class TestPromptCacheGet:
    """Tests for PromptCache.get."""

    def test_get_existing_entry(self) -> None:
        """After storing content, get() by prompt_id returns the matching entry."""
        cache = PromptCache()
        entry = cache.store(VALID_PROMPT)
        retrieved = cache.get(entry.prompt_id)
        assert retrieved is not None
        assert retrieved.prompt_id == entry.prompt_id
        assert retrieved.raw_content == VALID_PROMPT

    def test_get_unknown_id_returns_none(self) -> None:
        """get() with an ID that was never stored returns None."""
        cache = PromptCache()
        result = cache.get("nonexistent_id_that_was_never_stored")
        assert result is None

    def test_get_after_clear_returns_none(self) -> None:
        """After clear(), get() for a previously stored ID returns None."""
        cache = PromptCache()
        entry = cache.store(VALID_PROMPT)
        cache.clear()
        result = cache.get(entry.prompt_id)
        assert result is None


# ---------------------------------------------------------------------------
# PromptCache.remove
# ---------------------------------------------------------------------------


class TestPromptCacheRemove:
    """Tests for PromptCache.remove."""

    def test_remove_existing_returns_true(self) -> None:
        """Removing a stored entry returns True and makes it unretrievable."""
        cache = PromptCache()
        entry = cache.store(VALID_PROMPT)
        result = cache.remove(entry.prompt_id)
        assert result is True
        assert cache.get(entry.prompt_id) is None

    def test_remove_unknown_returns_false(self) -> None:
        """Removing an ID that was never stored returns False."""
        cache = PromptCache()
        result = cache.remove("nonexistent_id")
        assert result is False


# ---------------------------------------------------------------------------
# PromptCache eviction
# ---------------------------------------------------------------------------


class TestPromptCacheEviction:
    """Tests for LRU-by-insertion-time eviction when max_entries is reached."""

    def test_eviction_at_max_entries(self) -> None:
        """When storing beyond max_entries, the oldest entry is evicted."""
        cache = PromptCache(max_entries=3)
        contents = [f"# Deck {i}\n\n---\n\n## Slide 01 — Slide\n\nBody.\n" for i in range(4)]
        entries = [cache.store(c) for c in contents]

        # Cache should hold at most 3 entries
        assert len(cache) == 3

        # The first (oldest) entry should have been evicted
        first_id = entries[0].prompt_id
        assert cache.get(first_id) is None

    def test_eviction_preserves_newest(self) -> None:
        """After eviction, the most recently stored entries are all still retrievable."""
        cache = PromptCache(max_entries=3)
        contents = [f"# Deck {i}\n\n---\n\n## Slide 01 — Slide\n\nBody.\n" for i in range(4)]
        entries = [cache.store(c) for c in contents]

        # Entries 1, 2, 3 (the three newest) must all be present
        for entry in entries[1:]:
            assert cache.get(entry.prompt_id) is not None


# ---------------------------------------------------------------------------
# PromptCache.clear
# ---------------------------------------------------------------------------


class TestPromptCacheClear:
    """Tests for PromptCache.clear."""

    def test_clear_empties_cache(self) -> None:
        """After storing 3 entries and calling clear(), the cache is empty."""
        cache = PromptCache()
        cache.store(VALID_PROMPT)
        cache.store(VALID_PROMPT_2)
        cache.store(INVALID_PROMPT_NO_H1)
        cache.clear()
        assert len(cache) == 0


# ---------------------------------------------------------------------------
# PromptCache.__len__
# ---------------------------------------------------------------------------


class TestPromptCacheLen:
    """Tests for PromptCache.__len__."""

    def test_len_empty(self) -> None:
        """A freshly created cache reports length 0."""
        cache = PromptCache()
        assert len(cache) == 0

    def test_len_after_stores(self) -> None:
        """Storing 3 distinct contents increments the length to 3."""
        cache = PromptCache()
        cache.store(VALID_PROMPT)
        cache.store(VALID_PROMPT_2)
        cache.store(INVALID_PROMPT_NO_H1)
        assert len(cache) == 3

    def test_len_after_duplicate_store(self) -> None:
        """Storing the same content twice leaves the length at 1."""
        cache = PromptCache()
        cache.store(VALID_PROMPT)
        cache.store(VALID_PROMPT)
        assert len(cache) == 1


# ---------------------------------------------------------------------------
# get_validated_entry helper
# ---------------------------------------------------------------------------


class TestGetValidatedEntry:
    """Tests for the get_validated_entry module-level helper."""

    def test_get_validated_entry_success(self) -> None:
        """A stored valid prompt returns the PromptCacheEntry, not a dict."""
        entry = prompt_cache.store(VALID_PROMPT)
        result = get_validated_entry(entry.prompt_id)
        assert isinstance(result, PromptCacheEntry)
        assert result.prompt_id == entry.prompt_id

    def test_get_validated_entry_unknown_id(self) -> None:
        """An unknown prompt_id returns an error dict mentioning 'Unknown prompt_id'."""
        result = get_validated_entry("bad_id_that_does_not_exist")
        assert isinstance(result, dict)
        assert result.get("status") == "error"
        assert "Unknown prompt_id" in result.get("message", "")

    def test_get_validated_entry_invalid_prompt(self) -> None:
        """An invalid (cached but not valid) prompt returns an error dict about validation."""
        entry = prompt_cache.store(INVALID_PROMPT_NO_H1)
        result = get_validated_entry(entry.prompt_id)
        assert isinstance(result, dict)
        assert result.get("status") == "error"
        assert "validation errors" in result.get("message", "")


# ---------------------------------------------------------------------------
# Hash computation
# ---------------------------------------------------------------------------


class TestHashComputation:
    """Tests for the SHA-256 hash used as prompt_id."""

    def test_hash_deterministic(self) -> None:
        """Computing the hash of the same string 100 times produces identical results."""
        results = {hashlib.sha256(VALID_PROMPT.encode("utf-8")).hexdigest() for _ in range(100)}
        assert len(results) == 1

    def test_hash_empty_string(self) -> None:
        """The hash of the empty string equals hashlib.sha256(b'').hexdigest()."""
        cache = PromptCache()
        entry = cache.store("")
        expected = hashlib.sha256(b"").hexdigest()
        assert entry.prompt_id == expected

    def test_hash_unicode_content(self) -> None:
        """Unicode content produces a valid 64-char lowercase hex hash."""
        unicode_content = "# Présentation\n\n---\n\n## Slide 01 — Ouverture\n\nContenu ici.\n"
        cache = PromptCache()
        entry = cache.store(unicode_content)
        assert re.fullmatch(r"[0-9a-f]{64}", entry.prompt_id)


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    """Edge case tests for the prompt cache."""

    def test_empty_content_cached(self) -> None:
        """Storing an empty string caches the entry with an empty parsed deck."""
        cache = PromptCache()
        entry = cache.store("")
        expected_id = hashlib.sha256(b"").hexdigest()
        assert entry.prompt_id == expected_id
        assert entry.parsed_deck.slides == []
        assert cache.get(entry.prompt_id) is not None

    def test_whitespace_only_content(self) -> None:
        """Whitespace-only content produces a hash distinct from the empty-string hash."""
        whitespace = "   \n\n  "
        cache = PromptCache()
        entry = cache.store(whitespace)
        empty_hash = hashlib.sha256(b"").hexdigest()
        whitespace_hash = hashlib.sha256(whitespace.encode("utf-8")).hexdigest()
        assert entry.prompt_id == whitespace_hash
        assert entry.prompt_id != empty_hash

    def test_prompt_id_format(self) -> None:
        """The prompt_id is exactly 64 lowercase hexadecimal characters."""
        cache = PromptCache()
        entry = cache.store(VALID_PROMPT)
        assert re.fullmatch(r"^[0-9a-f]{64}$", entry.prompt_id)

    def test_cache_isolation_across_instances(self) -> None:
        """Two separate PromptCache instances share no mutable state."""
        cache_a = PromptCache()
        cache_b = PromptCache()
        entry = cache_a.store(VALID_PROMPT)
        # cache_b should know nothing about entries stored in cache_a
        assert cache_b.get(entry.prompt_id) is None

    def test_very_large_content(self) -> None:
        """A prompt with 100 slides (~50 KB) is cached and retrievable without error."""
        # Build a large prompt with a valid H1 and 100 well-formed slides
        parts = ["# Large Deck\n\n## General\n\nThis is a large deck.\n"]
        for i in range(1, 101):
            parts.append(f"\n---\n\n## Slide {i:02d} — Slide Title {i}\n\nImage prompt body.\n")
        large_content = "".join(parts)

        cache = PromptCache()
        entry = cache.store(large_content)
        assert entry is not None
        assert len(entry.prompt_id) == 64
        retrieved = cache.get(entry.prompt_id)
        assert retrieved is not None
        assert retrieved.raw_content == large_content
