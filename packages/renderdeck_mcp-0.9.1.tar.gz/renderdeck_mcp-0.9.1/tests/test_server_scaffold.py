"""Tests for the mcp-server-scaffold task.

Covers:
- __main__.main() argument dispatch (serve subcommand, missing, unknown)
- FastMCP tool registration (schema shape, tool names, required vs optional params)
- Import isolation (no Google modules loaded on import renderdeck_mcp.server)
- Clean exit on stdin EOF (subprocess integration test)
- Placeholder tool return values (not_implemented response, no raised exceptions)

Run with:
    pytest tests/test_server_scaffold.py -v
"""

from __future__ import annotations

import asyncio
import subprocess
import sys

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

EXPECTED_TOOLS = {
    "generate_deck",
    "validate_prompt_file",
    "regenerate_slide",
    "setup_gemini_key",
    "get_setup_status",
    "update_settings",
}


def _get_tools_sync() -> dict[str, object]:
    """Return a name -> Tool mapping by running list_tools() in an event loop."""
    from renderdeck_mcp.server import mcp

    async def _inner() -> dict[str, object]:
        tools = await mcp.list_tools()
        return {t.name: t for t in tools}

    return asyncio.run(_inner())


# ---------------------------------------------------------------------------
# TC-01: serve subcommand — clean exit on EOF
# ---------------------------------------------------------------------------


def test_serve_exits_cleanly_on_eof() -> None:
    """TC-01: python -m renderdeck_mcp serve exits with code 0 on stdin EOF.

    Covers acceptance criteria: design.md §5 (clean EOF handling), TC-01.
    """
    result = subprocess.run(
        [sys.executable, "-m", "renderdeck_mcp", "serve"],
        input=b"",
        capture_output=True,
        timeout=10,
    )
    assert result.returncode == 0, (
        f"Expected exit code 0 on EOF, got {result.returncode}.\nstderr: {result.stderr.decode()}"
    )


# ---------------------------------------------------------------------------
# TC-02: Missing serve argument exits with code 1
# ---------------------------------------------------------------------------


def test_no_subcommand_exits_0() -> None:
    """TC-02: python -m renderdeck_mcp (no subcommand) runs server and exits 0.

    After MCP server implementation, invoking without args starts the server
    on stdio which exits cleanly when stdin is closed.
    """
    result = subprocess.run(
        [sys.executable, "-m", "renderdeck_mcp"],
        capture_output=True,
        timeout=5,
    )
    assert result.returncode == 0, f"Expected exit code 0, got {result.returncode}"


# ---------------------------------------------------------------------------
# TC-03: Unknown subcommand exits with code 1
# ---------------------------------------------------------------------------


def test_unknown_subcommand_exits_1() -> None:
    """TC-03: python -m renderdeck_mcp foo exits 1.

    Covers acceptance criteria: design.md §8 (edge cases), TC-03.
    """
    result = subprocess.run(
        [sys.executable, "-m", "renderdeck_mcp", "foo"],
        capture_output=True,
        timeout=5,
    )
    assert result.returncode == 1, (
        f"Expected exit code 1 for unknown subcommand, got {result.returncode}"
    )


# ---------------------------------------------------------------------------
# TC-04: No Google imports on server module import
# ---------------------------------------------------------------------------


def test_no_google_imports_at_startup() -> None:
    """TC-04: Importing renderdeck_mcp.server must not load any google.* modules.

    Covers acceptance criteria: design.md §7 (import isolation), TC-04.
    """
    # Remove any previously cached renderdeck_mcp modules to get a fresh import
    for key in list(sys.modules.keys()):
        if "renderdeck_mcp" in key:
            del sys.modules[key]

    import renderdeck_mcp.server  # noqa: F401

    google_modules = [k for k in sys.modules if k.startswith("google")]
    assert google_modules == [], (
        f"Unexpected Google modules loaded after importing renderdeck_mcp.server: {google_modules}"
    )


# ---------------------------------------------------------------------------
# TC-05: FastMCP instance type and name
# ---------------------------------------------------------------------------


def test_mcp_instance_type_and_name() -> None:
    """TC-05: renderdeck_mcp.server.mcp is a FastMCP instance named 'renderdeck-mcp'.

    Covers acceptance criteria: design.md §4.1 (module interface), TC-05.
    """
    from mcp.server.fastmcp import FastMCP

    from renderdeck_mcp.server import mcp

    assert isinstance(mcp, FastMCP), f"Expected FastMCP instance, got {type(mcp)!r}"
    assert mcp.name == "renderdeck-mcp", f"Expected mcp.name == 'renderdeck-mcp', got {mcp.name!r}"


# ---------------------------------------------------------------------------
# TC-06: All six tools are registered
# ---------------------------------------------------------------------------


def test_all_tools_registered() -> None:
    """TC-06: FastMCP instance exposes exactly the six required tool names.

    Covers acceptance criteria: design.md §6 (tool registration), TC-06.
    """
    tools = _get_tools_sync()
    registered_names = set(tools.keys())
    assert EXPECTED_TOOLS.issubset(registered_names), (
        f"Missing tools: {EXPECTED_TOOLS - registered_names}. Registered: {registered_names}"
    )


# ---------------------------------------------------------------------------
# TC-07: generate_deck schema — required vs optional params
# ---------------------------------------------------------------------------


def test_generate_deck_schema() -> None:
    """TC-07: generate_deck exposes prompt_id as required; others optional.

    Covers acceptance criteria: design.md §3.1 (generate_deck parameters), TC-07.
    Updated for EXE-1104: slide_prompt_content replaced by prompt_id.
    """
    tools = _get_tools_sync()
    assert "generate_deck" in tools, "generate_deck tool not registered"

    tool = tools["generate_deck"]
    schema = tool.inputSchema  # type: ignore[attr-defined]

    required = set(schema.get("required", []))
    props = schema.get("properties", {})

    assert "prompt_id" in required, f"prompt_id must be required. Required fields: {required}"
    assert "output_path" not in required, (
        f"output_path must be optional. Required fields: {required}"
    )
    assert "image_quality" not in required, (
        f"image_quality must be optional. Required fields: {required}"
    )
    assert "project_name" not in required, (
        f"project_name must be optional. Required fields: {required}"
    )

    assert "prompt_id" in props, "prompt_id missing from properties"
    assert "output_path" in props, "output_path missing from properties"
    assert "image_quality" in props, "image_quality missing from properties"
    assert "project_name" in props, "project_name missing from properties"


# ---------------------------------------------------------------------------
# TC-08: image_quality is an enum or string type
# ---------------------------------------------------------------------------


def test_generate_deck_image_quality_enum() -> None:
    """TC-08: image_quality in generate_deck schema is an enum ['draft', 'final'].

    Covers acceptance criteria: design.md §3.1, TC-08.
    """
    tools = _get_tools_sync()
    schema = tools["generate_deck"].inputSchema  # type: ignore[attr-defined]
    quality_prop = schema["properties"]["image_quality"]

    # FastMCP represents Literal["draft", "final"] as {"enum": [...]}
    # Accept either enum or plain string type
    assert "enum" in quality_prop or quality_prop.get("type") == "string", (
        f"Expected enum or string type for image_quality. Got: {quality_prop}"
    )
    if "enum" in quality_prop:
        assert set(quality_prop["enum"]) == {"draft", "final"}, (
            f"Expected enum values {{'draft', 'final'}}, got {quality_prop['enum']}"
        )


# ---------------------------------------------------------------------------
# TC-09: regenerate_slide — slide_numbers is array of integer
# ---------------------------------------------------------------------------


def test_regenerate_slide_schema() -> None:
    """TC-09: regenerate_slide has slide_numbers as required array[integer].

    Covers acceptance criteria: design.md §3.1 (regenerate_slide parameters), TC-09.
    """
    tools = _get_tools_sync()
    assert "regenerate_slide" in tools, "regenerate_slide tool not registered"

    schema = tools["regenerate_slide"].inputSchema  # type: ignore[attr-defined]
    required = set(schema.get("required", []))
    props = schema.get("properties", {})

    assert "project_name" in required, (
        f"project_name must be required in regenerate_slide. Required: {required}"
    )
    assert "slide_numbers" in required, (
        f"slide_numbers must be required in regenerate_slide. Required: {required}"
    )
    assert "slide_numbers" in props, "slide_numbers missing from properties"
    assert props["slide_numbers"].get("type") == "array", (
        f"slide_numbers must be type array. Got: {props['slide_numbers']}"
    )
    assert props["slide_numbers"].get("items", {}).get("type") == "integer", (
        f"slide_numbers items must be type integer. Got: {props['slide_numbers'].get('items')}"
    )


# ---------------------------------------------------------------------------
# TC-10: generate_deck stub returns not_implemented without raising
# ---------------------------------------------------------------------------


async def test_generate_deck_returns_dict() -> None:
    """TC-10: Calling generate_deck directly returns a dict with a 'status' key.

    After wiring (task 2.5), generate_deck calls the real implementation.
    We only verify the return shape here; full pipeline tests are in
    test_generate_deck_tool.py.
    """
    from unittest.mock import patch

    from renderdeck_mcp import server

    expected: dict[str, object] = {
        "status": "error",
        "message": "Prompt file contains no slides. Add at least one ## Slide NN — Title block.",
    }

    async def _fake(*args: object, **kwargs: object) -> dict[str, object]:
        return expected

    with patch("renderdeck_mcp.tools.generate_deck.run_generate_deck", side_effect=_fake):
        from renderdeck_mcp.cache import prompt_cache as _pc

        result = await server.generate_deck(prompt_id=_pc.store("# Test\n").prompt_id)

    assert isinstance(result, dict), (
        f"Expected dict result from generate_deck, got {type(result)!r}"
    )
    assert "status" in result, f"Expected 'status' key in result, got {result!r}"


# ---------------------------------------------------------------------------
# TC-11: get_setup_status has no required parameters
# ---------------------------------------------------------------------------


def test_get_setup_status_no_params() -> None:
    """TC-11: get_setup_status schema has no required parameters.

    Covers acceptance criteria: design.md §3.1 (get_setup_status parameters), TC-11.
    """
    tools = _get_tools_sync()
    assert "get_setup_status" in tools, "get_setup_status tool not registered"

    schema = tools["get_setup_status"].inputSchema  # type: ignore[attr-defined]
    required = schema.get("required", [])
    props = schema.get("properties", {})

    assert required == [], f"get_setup_status must have no required parameters. Got: {required}"
    assert props == {} or all(v is None for v in props.values()), (
        f"get_setup_status must have empty or null properties. Got: {props}"
    )


# ---------------------------------------------------------------------------
# TC-12: server module is importable without error
# ---------------------------------------------------------------------------


def test_server_module_importable() -> None:
    """TC-12: renderdeck_mcp.server imports without raising any exception.

    Covers acceptance criteria: design.md §11 (acceptance criteria), TC base.
    """
    import importlib

    try:
        importlib.import_module("renderdeck_mcp.server")
    except Exception as exc:
        pytest.fail(f"Failed to import renderdeck_mcp.server: {exc}")


# ---------------------------------------------------------------------------
# TC-13: server exposes a run() callable
# ---------------------------------------------------------------------------


def test_server_exposes_run_callable() -> None:
    """TC-13: renderdeck_mcp.server.run is a callable.

    Covers acceptance criteria: design.md §4.1 (module interface).
    """
    from renderdeck_mcp import server

    assert callable(getattr(server, "run", None)), "renderdeck_mcp.server.run is not callable"
