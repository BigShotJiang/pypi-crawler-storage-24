"""Unit tests for reference_images parameter threading in tools/generate_slide.py.

Tests cover TC-T01 through TC-T03 from the reference-image-input test handoff.

run_generate_slide gains a new optional reference_images parameter that is
converted to a tuple and passed to SlideImageRequest, and also incorporated
into the content hash for cache invalidation.

All tests mock external dependencies (generate_image, Gemini client, filesystem).

Design doc: docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/design.md
Test handoff: docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/test-handoff.md
"""

from __future__ import annotations

import base64
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from renderdeck_mcp.tools.generate_slide import run_generate_slide

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MINIMAL_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 20


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def png_base64() -> str:
    return base64.b64encode(MINIMAL_PNG).decode("ascii")


# ---------------------------------------------------------------------------
# TC-T01: reference_images threaded to SlideImageRequest
# ---------------------------------------------------------------------------


async def test_tc_t01_reference_images_threaded_to_slide_image_request(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    png_base64: str,
) -> None:
    """TC-T01: reference_images list is converted to tuple in SlideImageRequest."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    ref = {"base64": png_base64, "role": "logo"}

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            new_callable=AsyncMock,
            return_value=MINIMAL_PNG,
        ) as mock_gen,
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        result = await run_generate_slide(
            project_name="test",
            slide_number=1,
            image_prompt="A test slide",
            reference_images=[ref],
        )

    assert result["status"] == "ok"

    call_args = mock_gen.call_args
    # second positional arg is the SlideImageRequest
    request_arg = call_args[0][1]
    assert request_arg.reference_images == (ref,)


async def test_tc_t01_reference_images_is_tuple_in_request(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    png_base64: str,
) -> None:
    """TC-T01: reference_images on SlideImageRequest is always a tuple."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    refs = [
        {"base64": png_base64, "role": "logo"},
        {"url": "https://example.com/img.png", "role": "background"},
    ]

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            new_callable=AsyncMock,
            return_value=MINIMAL_PNG,
        ) as mock_gen,
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        await run_generate_slide(
            project_name="test",
            slide_number=1,
            image_prompt="A test slide",
            reference_images=refs,
        )

    request_arg = mock_gen.call_args[0][1]
    assert isinstance(request_arg.reference_images, tuple)
    assert len(request_arg.reference_images) == 2


# ---------------------------------------------------------------------------
# TC-T02: reference_images=None → empty tuple in SlideImageRequest
# ---------------------------------------------------------------------------


async def test_tc_t02_reference_images_none_yields_empty_tuple(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """TC-T02: Omitting reference_images produces SlideImageRequest with empty tuple."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            new_callable=AsyncMock,
            return_value=MINIMAL_PNG,
        ) as mock_gen,
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        result = await run_generate_slide(
            project_name="test",
            slide_number=1,
            image_prompt="A plain slide",
        )

    assert result["status"] == "ok"

    request_arg = mock_gen.call_args[0][1]
    assert request_arg.reference_images == ()


async def test_tc_t02_reference_images_explicitly_none_yields_empty_tuple(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """TC-T02: Passing reference_images=None explicitly produces empty tuple."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            new_callable=AsyncMock,
            return_value=MINIMAL_PNG,
        ) as mock_gen,
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        await run_generate_slide(
            project_name="test",
            slide_number=1,
            image_prompt="A plain slide",
            reference_images=None,
        )

    request_arg = mock_gen.call_args[0][1]
    assert request_arg.reference_images == ()


# ---------------------------------------------------------------------------
# TC-T03: Cache is invalidated when reference_images changes
# ---------------------------------------------------------------------------


async def test_tc_t03_cache_invalidated_when_references_change(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """TC-T03: Different reference_images produces a different content hash → cache miss."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    call_count = {"n": 0}

    async def _counting_generate(client, request, config):  # type: ignore[no-untyped-def]
        call_count["n"] += 1
        return MINIMAL_PNG

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            side_effect=_counting_generate,
        ),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        # First call — no references
        result1 = await run_generate_slide(
            project_name="test-cache",
            slide_number=1,
            image_prompt="A slide",
            reference_images=[],
        )
        # Second call — with a reference image → different hash → cache miss
        result2 = await run_generate_slide(
            project_name="test-cache",
            slide_number=1,
            image_prompt="A slide",
            reference_images=[{"url": "https://example.com/img.png"}],
        )

    assert result1["status"] == "ok"
    assert result2["status"] == "ok"
    # generate_image must have been called twice — second call is a cache miss
    assert call_count["n"] == 2


async def test_tc_t03_same_references_hits_cache(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    png_base64: str,
) -> None:
    """TC-T03 (inverse): Same references on second call hits the cache."""
    import io

    from PIL import Image

    # Create a real-looking PNG for the cache
    buf = io.BytesIO()
    Image.new("RGB", (4, 4), "blue").save(buf, format="PNG")
    real_png = buf.getvalue()

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    refs = [{"url": "https://example.com/img.png", "role": "logo"}]

    call_count = {"n": 0}

    async def _counting_generate(client, request, config):  # type: ignore[no-untyped-def]
        call_count["n"] += 1
        return real_png

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            side_effect=_counting_generate,
        ),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        # First call — writes to cache
        result1 = await run_generate_slide(
            project_name="test-same",
            slide_number=1,
            image_prompt="A slide",
            reference_images=refs,
        )
        # Second call — same parameters → should hit cache
        result2 = await run_generate_slide(
            project_name="test-same",
            slide_number=1,
            image_prompt="A slide",
            reference_images=refs,
        )

    assert result1["status"] == "ok"
    assert result1["cached"] is False
    assert result2["status"] == "ok"
    assert result2["cached"] is True
    # generate_image called only once (second was a cache hit)
    assert call_count["n"] == 1


async def test_tc_t01_run_generate_slide_returns_ok_with_references(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    png_base64: str,
) -> None:
    """TC-T01: run_generate_slide with reference_images returns status=ok."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            new_callable=AsyncMock,
            return_value=MINIMAL_PNG,
        ),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        result = await run_generate_slide(
            project_name="test",
            slide_number=1,
            image_prompt="A test slide",
            reference_images=[{"base64": png_base64, "role": "logo"}],
        )

    assert result["status"] == "ok"
    assert result["slide_number"] == 1
    assert result["cached"] is False
