"""Unit tests for _build_contents in generation/gemini.py.

Tests cover TC-C01 through TC-C05 from the reference-image-input test handoff.

_build_contents(request, resolved) returns:
- A plain str when resolved is empty (text-only, backward-compatible path)
- A list of content parts when resolved is non-empty (multimodal path)

All tests are pure unit tests with no external I/O.

Design doc: docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/design.md
Test handoff: docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/test-handoff.md
"""

from __future__ import annotations

import base64

import pytest

from renderdeck_mcp.generation.gemini import AspectRatio, SlideImageRequest, _build_prompt
from renderdeck_mcp.generation.types import ResolvedReferenceImage

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MINIMAL_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 20


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def png_base64() -> str:
    return base64.b64encode(MINIMAL_PNG).decode("ascii")


@pytest.fixture
def request_no_refs() -> SlideImageRequest:
    return SlideImageRequest(
        slide_index=0,
        prompt="A plain text slide",
        aspect_ratio=AspectRatio.WIDE,
    )


@pytest.fixture
def request_with_refs(png_base64: str) -> SlideImageRequest:
    return SlideImageRequest(
        slide_index=0,
        prompt="A product overview slide",
        aspect_ratio=AspectRatio.WIDE,
        general_context="Tech startup",
        visual_rules="Bold colors",
        reference_images=(
            {
                "base64": png_base64,
                "media_type": "image/png",
                "role": "product screenshot",
                "placement": "center",
            },
        ),
    )


@pytest.fixture
def resolved_ref(png_base64: str) -> ResolvedReferenceImage:
    return ResolvedReferenceImage(
        base64_data=png_base64,
        media_type="image/png",
        role="brand logo",
        placement="top-right corner",
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_contents(request: SlideImageRequest, resolved: list[ResolvedReferenceImage]):
    """Import shim to keep tests forward-compatible with pre-implementation runs."""
    from renderdeck_mcp.generation.gemini import _build_contents as _fn

    return _fn(request, resolved)


# ---------------------------------------------------------------------------
# TC-C01 through TC-C05 — Content Building
# ---------------------------------------------------------------------------


def test_tc_c01_build_contents_empty_resolved_returns_str(
    request_no_refs: SlideImageRequest,
) -> None:
    """TC-C01: Empty resolved list returns a plain str (text-only path)."""
    result = _build_contents(request_no_refs, [])

    assert isinstance(result, str)


def test_tc_c01_build_contents_empty_resolved_equals_build_prompt(
    request_no_refs: SlideImageRequest,
) -> None:
    """TC-C01: Text-only contents equals _build_prompt output (backward-compatible)."""
    result = _build_contents(request_no_refs, [])
    expected = _build_prompt(request_no_refs)

    assert result == expected


def test_tc_c02_build_contents_with_resolved_images_returns_list(
    request_with_refs: SlideImageRequest,
    resolved_ref: ResolvedReferenceImage,
) -> None:
    """TC-C02: Non-empty resolved list returns a list of content parts."""
    result = _build_contents(request_with_refs, [resolved_ref])

    assert isinstance(result, list)


def test_tc_c02_build_contents_list_has_two_elements(
    request_with_refs: SlideImageRequest,
    resolved_ref: ResolvedReferenceImage,
) -> None:
    """TC-C02: One resolved image → list with 2 elements (1 image part + 1 text part)."""
    result = _build_contents(request_with_refs, [resolved_ref])

    assert len(result) == 2


def test_tc_c02_build_contents_image_part_precedes_text_part(
    request_with_refs: SlideImageRequest,
    resolved_ref: ResolvedReferenceImage,
) -> None:
    """TC-C02: The image part comes first, the text part last."""
    result = _build_contents(request_with_refs, [resolved_ref])

    # The text part is the last element
    last = result[-1]
    # A text Part should have a text attribute with actual content
    assert hasattr(last, "text")
    assert isinstance(last.text, str)
    assert len(last.text) > 0


def test_tc_c02_build_contents_first_element_is_image_part(
    request_with_refs: SlideImageRequest,
    resolved_ref: ResolvedReferenceImage,
) -> None:
    """TC-C02: The first element is an image Part with inline_data."""
    result = _build_contents(request_with_refs, [resolved_ref])

    first = result[0]
    assert hasattr(first, "inline_data")
    assert first.inline_data is not None


def test_tc_c03_build_contents_includes_role_annotation_in_text(
    request_with_refs: SlideImageRequest,
    png_base64: str,
) -> None:
    """TC-C03: Role and placement annotations appear in the text part."""
    resolved = ResolvedReferenceImage(
        base64_data=png_base64,
        media_type="image/png",
        role="brand logo",
        placement="top-right corner",
    )

    result = _build_contents(request_with_refs, [resolved])

    text_part = result[-1]
    text_content = text_part.text
    assert "REFERENCE IMAGES:" in text_content
    assert "brand logo" in text_content
    assert "top-right corner" in text_content


def test_tc_c04_build_contents_no_role_no_annotation(
    request_with_refs: SlideImageRequest,
    png_base64: str,
) -> None:
    """TC-C04: Empty role strings → no REFERENCE IMAGES: annotation in text part."""
    resolved = ResolvedReferenceImage(
        base64_data=png_base64,
        media_type="image/png",
        role="",
        placement="",
    )

    result = _build_contents(request_with_refs, [resolved])

    text_part = result[-1]
    assert "REFERENCE IMAGES:" not in text_part.text


def test_tc_c05_build_contents_multiple_images_all_appear_in_parts(
    request_with_refs: SlideImageRequest,
    png_base64: str,
) -> None:
    """TC-C05: Three resolved images produce 4 parts (3 image + 1 text)."""
    resolved = [
        ResolvedReferenceImage(
            base64_data=png_base64,
            media_type="image/png",
            role=f"image-{i}",
            placement="center",
        )
        for i in range(3)
    ]

    result = _build_contents(request_with_refs, resolved)

    assert isinstance(result, list)
    assert len(result) == 4


def test_tc_c05_build_contents_last_element_is_text_with_multiple_images(
    request_with_refs: SlideImageRequest,
    png_base64: str,
) -> None:
    """TC-C05: With multiple resolved images, last element is still the text part."""
    resolved = [
        ResolvedReferenceImage(
            base64_data=png_base64,
            media_type="image/png",
            role=f"image-{i}",
            placement="",
        )
        for i in range(3)
    ]

    result = _build_contents(request_with_refs, resolved)

    last = result[-1]
    assert hasattr(last, "text")
    assert isinstance(last.text, str)


def test_build_contents_inline_data_contains_correct_mime_type(
    request_with_refs: SlideImageRequest,
    png_base64: str,
) -> None:
    """Image part inline_data has the mime_type from the resolved image."""
    resolved = ResolvedReferenceImage(
        base64_data=png_base64,
        media_type="image/jpeg",
        role="hero",
        placement="",
    )

    result = _build_contents(request_with_refs, [resolved])

    image_part = result[0]
    assert image_part.inline_data.mime_type == "image/jpeg"


def test_build_contents_text_part_includes_prompt_text(
    request_with_refs: SlideImageRequest,
    resolved_ref: ResolvedReferenceImage,
) -> None:
    """The text part contains the original slide prompt text."""
    result = _build_contents(request_with_refs, [resolved_ref])

    text_part = result[-1]
    assert "A product overview slide" in text_part.text
