"""Unit tests for content_hash_for_slide with reference_images parameter.

Tests cover TC-H01 through TC-H04 from the reference-image-input test handoff.

content_hash_for_slide is extended with an optional reference_images parameter.
Existing callers (no reference_images argument) must produce the same hash as before.

All tests are pure unit tests — no I/O, no mocking, no external dependencies.

Design doc: docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/design.md
Test handoff: docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/test-handoff.md
"""

from __future__ import annotations

from renderdeck_mcp.generation.cache import content_hash_for_slide
from renderdeck_mcp.generation.types import ReferenceImageDict

# ---------------------------------------------------------------------------
# TC-H01: Hash stability — no references (backward compatible)
# ---------------------------------------------------------------------------


def test_tc_h01_hash_stable_without_reference_images() -> None:
    """TC-H01: Calling without reference_images matches calling with None and with []."""
    h1 = content_hash_for_slide("general", "rules", "prompt")
    h2 = content_hash_for_slide("general", "rules", "prompt", reference_images=None)
    h3 = content_hash_for_slide("general", "rules", "prompt", reference_images=[])

    assert h1 == h2
    assert h1 == h3


def test_tc_h01_positional_call_unchanged() -> None:
    """TC-H01: Positional-only call (existing callers) remains unchanged."""
    original = content_hash_for_slide("g", "r", "p")
    with_none = content_hash_for_slide("g", "r", "p", reference_images=None)

    assert original == with_none


def test_tc_h01_empty_list_same_as_no_arg() -> None:
    """TC-H01: Empty list is treated identically to None."""
    h_none: str = content_hash_for_slide("g", "r", "p", reference_images=None)
    h_empty: str = content_hash_for_slide("g", "r", "p", reference_images=[])

    assert h_none == h_empty


# ---------------------------------------------------------------------------
# TC-H02: Hash changes when references are added
# ---------------------------------------------------------------------------


def test_tc_h02_hash_changes_when_references_added() -> None:
    """TC-H02: Adding a reference image changes the content hash."""
    h_no_ref = content_hash_for_slide("g", "r", "p")
    h_with_ref = content_hash_for_slide(
        "g",
        "r",
        "p",
        reference_images=[{"url": "https://x.com/img.png"}],
    )

    assert h_no_ref != h_with_ref


def test_tc_h02_hash_differs_one_vs_two_references() -> None:
    """TC-H02: One reference image produces a different hash than two."""
    h_one = content_hash_for_slide(
        "g",
        "r",
        "p",
        reference_images=[{"url": "https://x.com/img.png"}],
    )
    h_two = content_hash_for_slide(
        "g",
        "r",
        "p",
        reference_images=[
            {"url": "https://x.com/img.png"},
            {"url": "https://y.com/img.png"},
        ],
    )

    assert h_one != h_two


# ---------------------------------------------------------------------------
# TC-H03: Hash changes when reference URL changes
# ---------------------------------------------------------------------------


def test_tc_h03_hash_changes_when_reference_url_changes() -> None:
    """TC-H03: Changing the URL in a reference dict changes the hash."""
    h1 = content_hash_for_slide("g", "r", "p", [{"url": "https://a.com/img.png"}])
    h2 = content_hash_for_slide("g", "r", "p", [{"url": "https://b.com/img.png"}])

    assert h1 != h2


def test_tc_h03_hash_changes_when_role_changes() -> None:
    """TC-H03 (variant): Changing the role in a reference dict changes the hash."""
    h1 = content_hash_for_slide("g", "r", "p", [{"url": "https://x.com/img.png", "role": "logo"}])
    h2 = content_hash_for_slide(
        "g", "r", "p", [{"url": "https://x.com/img.png", "role": "background"}]
    )

    assert h1 != h2


def test_tc_h03_hash_changes_when_placement_changes() -> None:
    """TC-H03 (variant): Changing the placement hint in a reference dict changes the hash."""
    h1 = content_hash_for_slide(
        "g", "r", "p", [{"url": "https://x.com/img.png", "placement": "center"}]
    )
    h2 = content_hash_for_slide(
        "g", "r", "p", [{"url": "https://x.com/img.png", "placement": "top-right"}]
    )

    assert h1 != h2


# ---------------------------------------------------------------------------
# TC-H04: Hash stability — deterministic for same inputs
# ---------------------------------------------------------------------------


def test_tc_h04_hash_stable_for_same_inputs() -> None:
    """TC-H04: Same inputs always produce the same hash."""
    refs: list[ReferenceImageDict] = [{"url": "https://x.com/img.png", "role": "logo"}]

    h1 = content_hash_for_slide("gen", "rules", "prompt", reference_images=refs)
    h2 = content_hash_for_slide("gen", "rules", "prompt", reference_images=refs)

    assert h1 == h2


def test_tc_h04_hash_stable_called_twice_without_refs() -> None:
    """TC-H04: Same inputs without refs are deterministic across calls."""
    h1 = content_hash_for_slide("general context", "bold rules", "slide prompt")
    h2 = content_hash_for_slide("general context", "bold rules", "slide prompt")

    assert h1 == h2


def test_tc_h04_hash_stable_with_base64_reference() -> None:
    """TC-H04: Hash with base64 reference is deterministic."""
    import base64

    png_b64 = base64.b64encode(b"\x89PNG\r\n\x1a\n" + b"\x00" * 20).decode("ascii")
    refs: list[ReferenceImageDict] = [{"base64": png_b64, "media_type": "image/png"}]

    h1 = content_hash_for_slide("g", "r", "p", reference_images=refs)
    h2 = content_hash_for_slide("g", "r", "p", reference_images=refs)

    assert h1 == h2


def test_hash_result_is_16_char_hex() -> None:
    """content_hash_for_slide with reference_images returns 16-character hex string."""
    result = content_hash_for_slide(
        "gen",
        "rules",
        "prompt",
        reference_images=[{"url": "https://x.com/img.png"}],
    )

    assert len(result) == 16
    assert all(c in "0123456789abcdef" for c in result)


def test_hash_dict_order_independent() -> None:
    """Reference dict key order does not affect the hash (sort_keys=True used internally)."""
    refs_a: list[ReferenceImageDict] = [{"role": "logo", "url": "https://x.com/img.png"}]
    refs_b: list[ReferenceImageDict] = [{"url": "https://x.com/img.png", "role": "logo"}]

    h_a = content_hash_for_slide("g", "r", "p", reference_images=refs_a)
    h_b = content_hash_for_slide("g", "r", "p", reference_images=refs_b)

    assert h_a == h_b
