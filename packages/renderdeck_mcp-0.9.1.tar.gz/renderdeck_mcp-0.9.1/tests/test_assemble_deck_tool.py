"""Tests for the assemble_deck MCP tool."""

from __future__ import annotations

import io
from pathlib import Path

import pytest
from PIL import Image

from renderdeck_mcp.cache import prompt_cache
from renderdeck_mcp.tools.assemble_deck import _slugify, run_assemble_deck


@pytest.fixture(autouse=True)
def _clear_cache_after_each_test() -> object:
    """Clear the prompt_cache singleton after every test in this module."""
    yield
    prompt_cache.clear()


def _make_png() -> bytes:
    """Create a minimal valid PNG image."""
    buf = io.BytesIO()
    Image.new("RGB", (100, 100), "blue").save(buf, format="PNG")
    return buf.getvalue()


SAMPLE_PROMPT = """\
# Test Deck

## General

Test context.

## Global Rules

FORMAT: 16:9

---

## Slide 01 — First

A wide-format opening slide with blue gradient.

---

## Slide 02 — Second

Content slide with data cards.
"""

EMPTY_PROMPT = """\
# Empty Deck

## General

No slides here.
"""


# ---------------------------------------------------------------------------
# _slugify
# ---------------------------------------------------------------------------


class TestSlugify:
    def test_basic(self) -> None:
        assert _slugify("My Great Deck") == "my-great-deck"

    def test_special_chars(self) -> None:
        assert _slugify("Hello, World! (2026)") == "hello-world-2026"

    def test_empty(self) -> None:
        assert _slugify("") == "untitled"

    def test_only_special_chars(self) -> None:
        assert _slugify("!!!") == "untitled"

    def test_multiple_spaces(self) -> None:
        assert _slugify("a   b") == "a-b"


# ---------------------------------------------------------------------------
# run_assemble_deck — no slides
# ---------------------------------------------------------------------------


def test_assemble_no_slides(tmp_path: Path) -> None:
    """Returns error when prompt has no slides."""
    result = run_assemble_deck(
        project_name="test-proj",
        prompt_id=prompt_cache.store(EMPTY_PROMPT).prompt_id,
        output_path=str(tmp_path / "out.pptx"),
    )
    assert result["status"] == "error"
    assert "no slides" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# run_assemble_deck — with cached images
# ---------------------------------------------------------------------------


def test_assemble_with_cached_images(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Assembles .pptx using cached images from disk."""
    cache_dir = tmp_path / "cache" / "test-proj"
    cache_dir.mkdir(parents=True)

    # Write a cached image for slide 1
    png_bytes = _make_png()
    (cache_dir / "slide_01.png").write_bytes(png_bytes)

    monkeypatch.setattr(
        "renderdeck_mcp.tools.assemble_deck._CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    output = tmp_path / "out.pptx"
    result = run_assemble_deck(
        project_name="test-proj",
        prompt_id=prompt_cache.store(SAMPLE_PROMPT).prompt_id,
        output_path=str(output),
    )

    assert result["status"] == "ok"
    assert result["slide_count"] == 2
    assert result["slides_with_images"] == 1
    assert result["slides_text_only"] == 1
    assert output.is_file()


# ---------------------------------------------------------------------------
# run_assemble_deck — no cached images (text-only)
# ---------------------------------------------------------------------------


def test_assemble_no_cached_images(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Assembles .pptx with all text-only slides when no cache exists."""
    monkeypatch.setattr(
        "renderdeck_mcp.tools.assemble_deck._CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    output = tmp_path / "out.pptx"
    result = run_assemble_deck(
        project_name="test-proj",
        prompt_id=prompt_cache.store(SAMPLE_PROMPT).prompt_id,
        output_path=str(output),
    )

    assert result["status"] == "ok"
    assert result["slides_with_images"] == 0
    assert result["slides_text_only"] == 2
    assert output.is_file()


# ---------------------------------------------------------------------------
# run_assemble_deck — default output path
# ---------------------------------------------------------------------------


def test_assemble_default_output_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Uses default output path when none specified."""
    monkeypatch.setattr(
        "renderdeck_mcp.tools.assemble_deck._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.tools.assemble_deck._DEFAULT_OUTPUT_BASE",
        tmp_path / "output",
    )

    result = run_assemble_deck(
        project_name="test-proj",
        prompt_id=prompt_cache.store(SAMPLE_PROMPT).prompt_id,
    )

    assert result["status"] == "ok"
    assert "test-deck" in str(result["output_path"])
    assert str(result["output_path"]).endswith(".pptx")


# ---------------------------------------------------------------------------
# run_assemble_deck — unreadable cached image
# ---------------------------------------------------------------------------


def test_assemble_unreadable_cached_image(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Gracefully handles unreadable cache files."""
    cache_dir = tmp_path / "cache" / "test-proj"
    cache_dir.mkdir(parents=True)

    # Write a file but make it a directory to trigger OSError on read_bytes
    slide_dir = cache_dir / "slide_01.png"
    slide_dir.mkdir()

    monkeypatch.setattr(
        "renderdeck_mcp.tools.assemble_deck._CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    output = tmp_path / "out.pptx"
    result = run_assemble_deck(
        project_name="test-proj",
        prompt_id=prompt_cache.store(SAMPLE_PROMPT).prompt_id,
        output_path=str(output),
    )

    assert result["status"] == "ok"
    assert result["slides_with_images"] == 0


# ===========================================================================
# EXE-1104: prompt_id workflow integration tests
# ===========================================================================


def test_assemble_deck_with_prompt_id(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, clear_prompt_cache: object
) -> None:
    """TC-P01: validate returns prompt_id; run_assemble_deck accepts it and succeeds."""
    from renderdeck_mcp.tools.validate import run_validate

    # Step 1 — Validate and capture prompt_id
    validate_result = run_validate(SAMPLE_PROMPT)
    assert validate_result["valid"] is True, "SAMPLE_PROMPT must be valid"
    prompt_id: str = validate_result["prompt_id"]  # type: ignore[assignment]
    assert isinstance(prompt_id, str) and len(prompt_id) == 64

    # Step 2 — Set up a cache dir with a cached image for slide 1
    cache_dir = tmp_path / "cache" / "test-proj"
    cache_dir.mkdir(parents=True)
    (cache_dir / "slide_01.png").write_bytes(_make_png())

    monkeypatch.setattr(
        "renderdeck_mcp.tools.assemble_deck._CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    output = tmp_path / "out.pptx"
    result = run_assemble_deck(
        project_name="test-proj",
        prompt_id=prompt_id,
        output_path=str(output),
    )

    assert result["status"] == "ok", f"Expected status='ok', got: {result}"
    assert result["slide_count"] == 2
    assert result["slides_with_images"] == 1


def test_assemble_deck_unknown_prompt_id(tmp_path: Path, clear_prompt_cache: object) -> None:
    """TC-P02: run_assemble_deck with unknown prompt_id returns a clear error."""
    result = run_assemble_deck(
        project_name="test-proj",
        prompt_id="c" * 64,
        output_path=str(tmp_path / "out.pptx"),
    )

    assert result["status"] == "error"
    assert "message" in result
    msg: str = str(result["message"])
    assert "prompt_id" in msg.lower() or "unknown" in msg.lower()
