# PRD: RenderDeck Presentation Skill (v2)

## 1. Problem Statement

There is no reusable, portable skill that manages the full lifecycle of an Exalate presentation — from distilling conversation context into a narrative, through slide generation and video production, to translation and iterative refinement. The knowledge lives in scattered project files, accumulated convention, and one person's head. Every new conversation starts from scratch. The result is inconsistent output quality, missed brand rules, wasted iteration cycles, and no path for non-experts to produce decks independently.

## 2. Goal

Ship a single Claude skill (`renderdeck-presenter`) that manages the **full presentation lifecycle**:

1. **Distill** — Accepts any body of context and produces a narrative presentation for a stated audience.
2. **Generate prompt file** — Outputs a syntactically valid RenderDeck slide prompt file conforming to a codified format spec, enforcing Exalate brand guidelines.
3. **Generate PPTX** — Calls RenderDeck MCP tools to produce the `.pptx`.
4. **Generate video** — Produces a narrated MP4 from the deck using RenderDeck's TTS pipeline.
5. **Publish to YouTube** — Uploads the video with metadata.
6. **Translate** — Produces localized versions of the prompt file in other languages.
7. **Modify slides** — Helps the user refine specific slides, across all language variants or a single one.
8. **Guide the user** — Reports where it is in the process at every step, and helps the user learn to use the skill.

The skill is Exalate-branded in v1. Non-Exalate brand support is a v2 concern.

## 3. Scope

### In scope

- Skill SKILL.md authoring with frontmatter, instructions, and bundled references.
- Codified **format specification** (`references/format-spec.md`).
- Codified **brand guidelines** (`references/brand-guidelines.md`).
- Codified **structure instructions** (`references/structure-instructions.md`).
- Full annotated **example prompt file** (`references/example-prompt-file.md`) based on `ai_presentation_workflow.md`.
- **Seven capabilities** (§5): prompt file generation, PPTX generation, video generation, YouTube publishing, translation, slide modification, and user guidance.
- **Progress reporting** — the skill tells the user what phase it's in before and after each major step.
- **Visual style choice** — at prompt file generation time, the user chooses between standard Deep Purple and the Gartner atmospheric style.
- Test cases and evals.

### Out of scope

- Non-Exalate brand guidelines (v2).
- Google Slides / Nano Banana prompt format (distinct output target).
- Custom font installation or Gemini API key management (user's environment setup).
- Automatic generation without user confirmation at each phase gate.

## 4. User Personas

| Persona | Context | Entry point |
|---|---|---|
| **Power user** | Has built context in a multi-turn conversation. Knows the workflow. Wants speed. | "Create a slide prompt file from this context" |
| **First-timer** | Received a briefing document. Needs a deck for a meeting tomorrow. Doesn't know the format or any tools. | "Turn this into a presentation" / "Help me make a deck" |
| **Content creator** | Has a blog post or article. Wants a companion slide deck, possibly with video. | "Create a presentation based on this article for [audience]" |
| **Localizer** | Has an existing prompt file. Needs it translated for a non-English audience. | "Translate this deck to French" |

## 5. Capabilities

The skill provides seven distinct capabilities. Each can be triggered independently, but they follow a natural lifecycle order. The skill tracks which artifacts exist (prompt file, PPTX, video, translations) and offers the next logical step without forcing it.

### Capability 1: Generate Prompt File

**Input:** Conversation context, documents, Confluence/Jira content, or uploaded files + audience + objective.
**Output:** A validated RenderDeck slide prompt file (`.md`).
**Gate:** No auto-generation of PPTX. The prompt file is delivered for review. The user explicitly triggers the next step.

**Style choice.** Before generating, the skill asks the user to choose a visual style:
- **Standard Exalate** — Deep Purple (#383689) backgrounds, brand palette as documented in brand guidelines.
- **Atmospheric / Gartner** — Dark navy-to-deep-blue backgrounds with teal and purple gradient accents, atmospheric glow treatment. When this style is chosen, all gradient values are specified as explicit hex stops and angles in the Global Rules — no vague descriptions.

**Sub-steps:**
1. Gather context.
2. Distill narrative: identify audience, objective, tone, key messages.
3. Structure slide sequence (one idea per slide, clear transitions).
4. Present outline to user for approval. (For power users who signal "just do it," skip outline review.)
5. Ask style choice (Standard Exalate vs. Atmospheric).
6. Read format spec, brand guidelines, structure instructions from `references/`.
7. Generate the complete prompt file.
8. Run structural validation checks.
9. Call `renderdeck:validate_prompt_file`.
10. Fix errors, re-validate until clean.
11. Deliver file to user. Report: slide count, estimated speaking time, any manual post-processing actions.

### Capability 2: Generate PPTX

**Input:** A validated prompt file (from Capability 1 or user-supplied).
**Output:** A `.pptx` file.
**Prerequisite:** A prompt file must exist and have passed validation.

**Sub-steps:**
1. Confirm with user: "Ready to generate the deck?"
2. For decks ≤10 slides: call `renderdeck:generate_deck` with full prompt content.
3. For decks >10 slides: use slide-by-slide pipeline (`renderdeck:generate_slide` per slide, then `renderdeck:assemble_deck`).
4. Report progress: "Generating slide X of Y..."
5. Deliver `.pptx` to user.

### Capability 3: Generate Video

**Input:** A generated PPTX (i.e., cached slide images from a prior generation) + the prompt file.
**Output:** A narrated `.mp4` file.
**Prerequisite:** The PPTX must have been generated (slide images must be cached).

**Sub-steps:**
1. Ask the user for voice preference. Offer to list available voices (`renderdeck:list_voices`).
2. Confirm voice selection.
3. Call `renderdeck:generate_video` with project name, prompt content, and selected voice.
4. Report progress.
5. Deliver `.mp4` to user.

### Capability 4: Publish to YouTube

**Input:** A generated video file + metadata (title, description, tags, visibility).
**Output:** Published YouTube video.
**Prerequisite:** Video file must exist.

**Implementation note:** RenderDeck does not have a native YouTube upload tool. This capability requires either:
- A YouTube MCP integration (if connected), or
- Manual instructions to the user for uploading, with pre-formatted metadata (title, description, tags, thumbnail instructions).

**Sub-steps:**
1. Draft YouTube metadata: title, description, tags, category, visibility setting.
2. Present metadata to user for review.
3. If YouTube MCP is available: upload via MCP tool.
4. If YouTube MCP is NOT available: present the metadata as a ready-to-paste package and instruct the user to upload manually.

### Capability 5: Translate

**Input:** An existing prompt file + target language(s).
**Output:** One prompt file per target language, structurally identical to the source, with all text content translated.

**Translation rules:**
- Translate: `## General` section, slide titles, image prompt text content (labels, card text, descriptions), Speaker Notes (`**Say:**` lines, `**Timing:**`, `**Transition:**`, `**Defensive note:**`).
- Do NOT translate: structural markers (`## Slide NN —`, `## Speaker Notes`, `---`), hex color codes, font names, slide furniture format (slide numbers stay zero-padded Arabic numerals).
- Do NOT translate brand terms: "Exalate", product names, technical terms that are universally used in English in the target market (e.g., "API", "MCP", "iPaaS"). If in doubt, keep the English term with a parenthetical translation on first use.
- The `## Global Rules` section stays in English — it's machine-readable visual instructions, not audience-facing content.
- Slide numbering stays identical across all language variants.
- File naming: `[project-name]_slide_prompts_[lang-code].md` (e.g., `_fr.md`, `_de.md`, `_nl.md`).

**Sub-steps:**
1. Confirm target language(s).
2. Read the source prompt file.
3. For each target language: produce a translated copy.
4. Validate each translated file (same structural checks + `renderdeck:validate_prompt_file`).
5. Deliver all translated files.

### Capability 6: Modify Slides

**Input:** An existing prompt file + user instructions for which slides to change and how.
**Output:** Updated prompt file(s).

**Scope options (ask the user):**
- **Single language** — modify the specified slides in one specific language variant only.
- **All languages** — apply the modification to the source file and propagate to all existing translations.

**Sub-steps:**
1. Identify which slides to modify (by number or by description).
2. Clarify the desired change.
3. Ask: apply to single language or all languages?
4. Make the edit in the source prompt file.
5. If "all languages": re-translate only the modified slides in each existing language variant. Do not re-translate unchanged slides.
6. Re-validate all modified files.
7. If a PPTX was previously generated, offer to regenerate only the modified slides using `renderdeck:regenerate_slide`.
8. Deliver updated file(s).

### Capability 7: User Guidance

**Input:** User asks for help, seems lost, or triggers the skill for the first time.
**Output:** Contextual explanation of what the skill can do and where the user is in the process.

**This is not a separate workflow — it's a behavior woven into every capability.** The skill:

1. **On first contact:** Briefly explains what it does and offers to walk the user through the process or jump to a specific capability.
2. **At each phase gate:** Reports what just completed, what the next step is, and what options are available. Example: "The prompt file is ready and validated — 12 slides, estimated 8 minutes of speaking time. You can now: review and modify slides, generate the PPTX, or translate to other languages."
3. **On confusion:** If the user asks "what can you do" / "help" / "where are we" at any point, the skill provides a status report showing: which artifacts exist (prompt file, PPTX, video, translations), what the next logical steps are, and what commands trigger each capability.
4. **On errors:** If a step fails (validation error, generation timeout, missing prerequisite), the skill explains what went wrong, what the user's options are, and how to recover.

## 6. Skill Architecture

```
renderdeck-presenter/
├── SKILL.md                          # Main skill — orchestrator + all 7 capabilities (~450 lines)
└── references/
    ├── format-spec.md                # Slide prompt file format specification (~200 lines)
    ├── brand-guidelines.md           # Exalate brand rules for slide generation (~80 lines)
    ├── structure-instructions.md     # Structural conventions and edge cases (~50 lines)
    └── example-prompt-file.md        # Full annotated example from ai_presentation_workflow.md (~300 lines)
```

### 6.1 SKILL.md — Responsibilities

The SKILL.md is the orchestrator. It contains:

- **Capability router** — determines which capability the user is requesting based on trigger phrase, available artifacts, and conversation state.
- **Phase tracking** — maintains awareness of which artifacts exist (prompt file, PPTX, video, translations) so it can offer logical next steps.
- **Progress reporting** — reports what it's doing before and after each major step.
- **Reference loading** — reads the appropriate `references/` files before any generation step.
- **Validation** — runs structural checks and `renderdeck:validate_prompt_file` before any delivery.
- **Tool call patterns** — documents the correct RenderDeck MCP tool calls for each capability.
- **User guidance** — embedded throughout, not a separate section.

### 6.2 Progressive Disclosure

| File | When to load | Size estimate |
|---|---|---|
| `format-spec.md` | Before generating or modifying any prompt file | ~200 lines |
| `brand-guidelines.md` | Before generating any prompt file; also when modifying visual elements | ~80 lines |
| `structure-instructions.md` | Before generating or modifying any prompt file | ~50 lines |
| `example-prompt-file.md` | On first use, when user asks for format help, or when skill needs a structural reference | ~300 lines |

## 7. Format Specification (to be codified in `references/format-spec.md`)

Extracted from existing examples (`ai_presentation_workflow.md`, `gartner_slide_prompts_v2.md`) and accumulated convention.

### 7.1 File Structure

```
# [Presentation Title]

## General
[Audience description, tone, objectives, constraints — free-form prose]

## Global Rules
[Visual rules that apply to every slide — see §7.3]

---

## Slide 01 — [Title]

[Image generation prompt — detailed, self-contained description of the slide visual]

---

## Slide 02 — [Title]

[Image generation prompt]

---

[... repeat for all slides ...]

---

## Speaker Notes

### Slide 01 — [Title]

**Say:** [Scripted narration text — what the presenter actually says]

**Timing:** [Duration estimate and pacing notes]
**Transition:** [Cue to advance to next slide]

[Optional: **Defensive note:** anticipated objections and prepared responses]
[Optional: *Italic instruction for manual post-processing, e.g., adding a screenshot*]

### Slide 02 — [Title]

[... repeat for all slides ...]
```

### 7.2 Structural Rules

1. **H1 title** — exactly one, first line.
2. **`## General`** — required. Must contain at minimum: audience description, tone directive, presentation purpose.
3. **`## Global Rules`** — required. Must include: format, colors (full palette with hex codes and semantic meanings), typography, patterns, slide furniture, punctuation conventions.
4. **Slide separator** — `---` on its own line between every slide block and between the last slide and the Speaker Notes section.
5. **Slide headings** — `## Slide NN — Title` where NN is zero-padded (`01`, `02`, ..., `10`, `11`, ...).
6. **Slide body** — the image generation prompt. Self-contained. Must describe the complete visual without referencing other slides. Each prompt starts with "Create a wide-format presentation slide (16:9)..." or equivalent framing.
7. **Speaker Notes heading** — `## Speaker Notes`.
8. **Individual note headings** — `### Slide NN — Title` — must match the corresponding slide heading exactly.
9. **Say lines** — `**Say:**` prefix. Narration script. First person, present tense, conversational register.
10. **Timing** — `**Timing:**` prefix. Duration estimate and pacing guidance.
11. **Transition** — `**Transition:**` prefix. Cue to advance.
12. **Defensive notes** — `**Defensive note:**` prefix. Optional. Anticipated objections and prepared responses.
13. **Manual instructions** — italic text. Optional. Post-generation actions (adding screenshots, logos, etc.).

### 7.3 Global Rules Template

Every prompt file must include these in `## Global Rules`:

```
FORMAT: Wide-format 16:9
COLORS: [full palette with hex codes and semantic meanings]
TYPOGRAPHY: [headline and body fonts with substitutes]
PATTERNS: [approved decorative patterns only]
SLIDE FURNITURE: [slide number, footer, logo placeholder]
PUNCTUATION: [no trailing periods, em dash convention]
COLOR MEANING: [semantic color assignments specific to this deck]
```

### 7.4 Validation Checks

Before outputting any prompt file, the skill must verify:

| Check | Method | Pass condition |
|---|---|---|
| Slide count | `grep -c "^## Slide"` | Count matches expected |
| Speaker note count | `grep -c "^### Slide"` | Equals slide count |
| Say-line count | `grep -c "^\*\*Say:\*\*"` | Equals slide count |
| Separators present | `grep -c "^---$"` | ≥ slide count |
| Zero-padded numbering | Pattern check | All slide numbers zero-padded |
| No orphan slides | Cross-reference | Every `## Slide NN` has matching `### Slide NN` |
| Global Rules present | `grep "^## Global Rules"` | Exactly one |
| General section present | `grep "^## General"` | Exactly one |
| Brand colors present | Content check | All primary palette hex codes in Global Rules |
| Slide furniture specified | Content check | Slide number, footer, logo placeholder rules present |

After structural validation, call `renderdeck:validate_prompt_file` for parser validation.

## 8. Brand Guidelines (to be codified in `references/brand-guidelines.md`)

### 8.1 Existing Rules (carry forward verbatim from `/mnt/project/Brand_Guidelines`)

Format, colors, typography, logo, patterns, headshots, slide furniture, punctuation, layout consistency.

### 8.2 Additions from Accumulated Practice

1. **Color meaning is per-deck.** Each prompt file's Global Rules must assign semantic meaning to colors for that specific presentation. Not a fixed mapping.

2. **Two visual styles.**
   - **Standard Exalate:** Deep Purple (#383689) backgrounds. Default.
   - **Atmospheric / Gartner:** Dark navy-to-deep-blue with gradient accents. Used for analyst briefings and external high-stakes presentations. When selected, gradient hex stops, angles, and opacity values must be specified explicitly in Global Rules. No vague gradient descriptions.

3. **Card treatment consistency.** If any slide uses rounded-corner cards with border glow, all card slides in the deck must use the same treatment.

4. **Gradient naming banned.** The brand book names gradients (Aida, mesh, etc.) without hex stops. Prompts must not reference gradient names — only explicit color values.

5. **Placeholder handling.** When a slide requires a manually-added image (screenshot, logo, headshot), the prompt describes the layout with the placeholder area empty. The Speaker Notes include an italic instruction for the manual step.

## 9. Structure Instructions (to be codified in `references/structure-instructions.md`)

1. **Transparent-background placeholders.** Placeholder areas for images with transparent backgrounds must not contain visible placeholder graphics. Instruction goes in Speaker Notes in italic.

2. **Narrative over documentation.** Decks are narrative arguments with rhetorical tension — not instructional documentation. Titles pose questions or make claims. Content builds tension and resolves it. Transitions create momentum.

3. **One idea per slide.** If a slide prompt describes more than one distinct concept, split it.

4. **Image prompts are self-contained.** No cross-references to other slides. No "same as slide X." Each prompt stands alone.

5. **File management.** `create_file` does not overwrite. Delete existing output with `bash_tool` before recreating at the same path.

## 10. Progress Reporting Protocol

The skill reports its status at every phase gate. This is a hard requirement, not optional polish.

### Status report format

When reporting status, the skill uses this structure:

```
**Status: [Phase Name]**
[What just completed]
[What comes next]
[Available actions — what the user can do now]
```

### Phase gate reports

| After... | Report includes |
|---|---|
| Context gathering | "Context gathered. [N] source documents, audience: [X], objective: [Y]. Next: narrative distillation." |
| Outline approval | "Outline approved: [N] slides. Next: prompt file generation. Style choice needed." |
| Prompt file delivery | "Prompt file ready — [N] slides, ~[M] minutes speaking time, [K] manual actions flagged. You can now: review/modify slides, generate PPTX, or translate." |
| PPTX generation | "PPTX generated — [N] slides. You can now: generate video, modify slides, or translate." |
| Video generation | "Video generated — [duration]. Voice: [voice name]. You can now: publish to YouTube or re-generate with a different voice." |
| Translation | "Translated to [languages]. [N] files delivered. You can now: generate PPTX for translated versions, or modify slides across languages." |
| Slide modification | "Slides [NN, NN] updated in [scope]. Validation passed. You can now: regenerate affected slides in PPTX, or review changes." |

### Artifact tracker

The skill maintains mental awareness of which artifacts exist for the current project:

| Artifact | State | Example |
|---|---|---|
| Prompt file (source) | exists / not yet | `project_slide_prompts.md` |
| Prompt file (fr) | exists / not yet | `project_slide_prompts_fr.md` |
| Prompt file (de) | exists / not yet | `project_slide_prompts_de.md` |
| PPTX (source) | exists / not yet | generated via RenderDeck |
| PPTX (fr) | exists / not yet | — |
| Video (source) | exists / not yet | — |
| YouTube metadata | drafted / published / not yet | — |

When the user asks "where are we" or "what's next," the skill consults this tracker and responds accordingly.

## 11. Triggering

### Primary triggers (must always activate)

- "Create a slide prompt file from this context"
- "Create a presentation from this"
- "Turn this into a deck"
- "Make me a slide deck"
- "Generate a RenderDeck prompt file"
- "Distill this into a presentation for [audience]"

### Capability-specific triggers

| Trigger phrase | Capability |
|---|---|
| "Generate the deck" / "Build the PPTX" / "Render it" | Capability 2: Generate PPTX |
| "Make a video" / "Generate video" / "Create a narrated video" | Capability 3: Generate Video |
| "Publish to YouTube" / "Upload to YouTube" | Capability 4: Publish to YouTube |
| "Translate this to [language]" / "Make a [language] version" | Capability 5: Translate |
| "Change slide [N]" / "Fix slide [N]" / "Update the [topic] slide" | Capability 6: Modify Slides |
| "Help" / "What can you do" / "Where are we" / "How does this work" | Capability 7: User Guidance |

### Secondary triggers (activate when combined with presentation context)

- "Build a deck about [topic]"
- "I need slides for [event/meeting]"
- "Help me present [topic] to [audience]"
- "Prepare a presentation"
- Any reference to "RenderDeck" in the context of creating content

### Non-triggers (skill should NOT activate)

- Requests to explain RenderDeck (use `renderdeck:get_help` directly)
- General questions about presentation design theory
- RenderDeck configuration (API keys, settings)

## 12. Skill Description (for frontmatter)

Draft — to be refined through trigger optimization:

```
Full lifecycle Exalate presentation creation using RenderDeck. This skill distills conversation context, documents, or source material into a structured RenderDeck slide prompt file with image generation prompts and scripted speaker notes, then optionally generates the PPTX, produces a narrated video, publishes to YouTube, translates to other languages, and helps modify specific slides across all language variants. Use this skill whenever the user wants to: create a presentation or slide deck, generate a prompt file, build a PPTX, make a video from slides, translate a deck, modify slides in an existing deck, or asks for help with any of these steps. Triggers on: "create a slide prompt file", "make me a deck", "turn this into a presentation", "generate the deck", "make a video", "translate to [language]", "change slide [N]", "publish to YouTube", "help me with the presentation", or any mention of RenderDeck in the context of creating or editing content. The skill tracks which artifacts exist and guides the user through the lifecycle. Do NOT use for general RenderDeck help or configuration — those are handled by RenderDeck tools directly.
```

## 13. Risks and Mitigations

| Risk | Impact | Mitigation |
|---|---|---|
| **Format spec drift.** RenderDeck parser changes. | Validation failures. | `renderdeck:validate_prompt_file` as hard gate. Format spec is a single-file update. |
| **Brand guideline violations.** Vague gradient descriptions. | Visual inconsistency. | Ban gradient names. Require explicit hex stops. |
| **Prompt bloat.** Dense slides exceed Gemini's instruction window. | Garbled images. | One idea per slide. Flag prompts >500 words. |
| **Card style inconsistency.** | Visual grammar breaks. | Track first card treatment, enforce on all subsequent cards. |
| **Speaker note mismatch.** Slides added/removed but notes not updated. | Orphan/missing notes. | Validation cross-references headings. |
| **Timeout on large decks.** | Partial generation. | Slide-by-slide pipeline for >10 slides. |
| **Translation quality.** LLM translation may miss domain nuance. | Awkward or incorrect text on slides. | Skill flags brand terms and technical jargon kept in English. User reviews translations before generation. |
| **Partial modification propagation.** Slide edit applied to source but not all translations. | Cross-language drift. | Skill tracks which languages exist and prompts user to propagate. Only re-translates modified slides. |
| **YouTube publish without review.** | Premature publication. | Metadata presented for review before any upload. Explicit confirmation required. |
| **Scope creep per conversation.** User asks for a presentation, then video, then translations — skill loses track. | Confusion, wasted work. | Artifact tracker + progress reports at every gate. |

## 14. Decisions (resolved)

| # | Question | Decision | Rationale |
|---|---|---|---|
| 1 | Non-Exalate brands? | v2. | Skill is Exalate-specific. Generalization requires parameterized brand references. |
| 2 | Auto-generate PPTX after prompt file? | No. | Prompt file is a review artifact. No Gemini API calls until user confirms. |
| 3 | Gartner atmospheric vs. Deep Purple? | User chooses at generation time. | Ask when Capability 1 reaches the style decision point. Both options fully specified. |
| 4 | Example prompt file: template or full? | Full annotated real example. | `ai_presentation_workflow.md` — 14 slides, complete, demonstrates all structural elements. Annotated with inline comments. |
| 5 | Interactive outline review or autonomous? | Interactive by default. | Present outline for approval. Power users who signal "just do it" skip the review. |

## 15. Success Criteria

1. A user with no prior knowledge of the format can say "turn this into a presentation for [audience]" and receive a valid, brand-compliant prompt file with clear next-step guidance.
2. The prompt file passes `renderdeck:validate_prompt_file` on first attempt in >90% of cases.
3. Every slide is visually consistent with Exalate brand guidelines (human review).
4. Speaker notes contain scripted narration for every slide with timing estimates that sum to a reasonable total.
5. The skill does not require the user to know anything about the format, brand guidelines, or RenderDeck internals.
6. At every phase gate, the user knows: what just happened, what comes next, and what their options are.
7. A translated prompt file is structurally identical to the source and passes the same validation.
8. Slide modifications propagate correctly to specified language variants without affecting unchanged slides.

## 16. Implementation Plan

| Step | Deliverable | Dependency |
|---|---|---|
| 1 | Write `references/format-spec.md` | This PRD §7 |
| 2 | Write `references/brand-guidelines.md` | This PRD §8 + existing Brand_Guidelines |
| 3 | Write `references/structure-instructions.md` | This PRD §9 |
| 4 | Create `references/example-prompt-file.md` — full annotated version of `ai_presentation_workflow.md` | Steps 1–3 |
| 5 | Write `SKILL.md` — capability router, phase tracking, progress reporting, all 7 capabilities | Steps 1–4 |
| 6 | Write test cases (`evals/evals.json`) — minimum 1 per capability | Step 5 |
| 7 | Run test cases, review outputs | Step 6 |
| 8 | Iterate on SKILL.md based on test results | Step 7 |
| 9 | Optimize skill description for triggering | Step 8 |
| 10 | Package as `.skill` file | Step 9 |

### Test case coverage targets

| Capability | Test scenario |
|---|---|
| 1 — Prompt file | "Turn this blog post into a 10-slide presentation for Atlassian Solution Architects" |
| 1 — Prompt file | "Create a slide prompt file from this context" (with rich conversation history) |
| 2 — PPTX | "Generate the deck" (with existing prompt file) |
| 3 — Video | "Make a narrated video with a British male voice" |
| 4 — YouTube | "Publish to YouTube" (test metadata generation; actual upload depends on MCP availability) |
| 5 — Translate | "Translate this deck to French and German" |
| 6 — Modify | "Change slide 04 — replace the three-column layout with a timeline" + "apply to all languages" |
| 7 — Guidance | "Help" / "Where are we" / "What can you do" (at various stages) |
