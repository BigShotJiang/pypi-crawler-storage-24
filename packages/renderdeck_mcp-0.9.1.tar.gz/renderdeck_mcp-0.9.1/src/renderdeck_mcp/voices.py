"""Shared voice constants and resolution for TTS narration.

Used by both the ``generate_video`` and ``list_voices`` tools.
Voice aliases map friendly short names to full edge-tts neural voice identifiers.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Voice catalogue — alias → full edge-tts name
# ---------------------------------------------------------------------------

_SAMPLE_BASE = "https://github.com/yaph/tts-samples/raw/main/mp3/English"
_SAMPLE_BASE_FR = "https://github.com/yaph/tts-samples/raw/main/mp3/French"
_SAMPLE_BASE_VI = "https://github.com/yaph/tts-samples/raw/main/mp3/Vietnamese"

DEFAULT_VOICES: dict[str, dict[str, str]] = {
    # Australian English
    "natasha": {
        "full_name": "en-AU-NatashaNeural",
        "locale": "en-AU",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-AU-NatashaNeural.mp3",
    },
    "william": {
        "full_name": "en-AU-WilliamMultilingualNeural",
        "locale": "en-AU",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-AU-WilliamNeural.mp3",
    },
    # Canadian English
    "clara": {
        "full_name": "en-CA-ClaraNeural",
        "locale": "en-CA",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-CA-ClaraNeural.mp3",
    },
    "liam": {
        "full_name": "en-CA-LiamNeural",
        "locale": "en-CA",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-CA-LiamNeural.mp3",
    },
    # British English
    "sonia": {
        "full_name": "en-GB-SoniaNeural",
        "locale": "en-GB",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-SoniaNeural.mp3",
    },
    "ryan": {
        "full_name": "en-GB-RyanNeural",
        "locale": "en-GB",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-RyanNeural.mp3",
    },
    "libby": {
        "full_name": "en-GB-LibbyNeural",
        "locale": "en-GB",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-LibbyNeural.mp3",
    },
    "maisie": {
        "full_name": "en-GB-MaisieNeural",
        "locale": "en-GB",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-MaisieNeural.mp3",
    },
    "thomas": {
        "full_name": "en-GB-ThomasNeural",
        "locale": "en-GB",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-ThomasNeural.mp3",
    },
    # Hong Kong English
    "sam": {
        "full_name": "en-HK-SamNeural",
        "locale": "en-HK",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-HK-SamNeural.mp3",
    },
    "yan": {
        "full_name": "en-HK-YanNeural",
        "locale": "en-HK",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-HK-YanNeural.mp3",
    },
    # Irish English
    "connor": {
        "full_name": "en-IE-ConnorNeural",
        "locale": "en-IE",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-IE-ConnorNeural.mp3",
    },
    "emily": {
        "full_name": "en-IE-EmilyNeural",
        "locale": "en-IE",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-IE-EmilyNeural.mp3",
    },
    # Indian English
    "neerja-expressive": {
        "full_name": "en-IN-NeerjaExpressiveNeural",
        "locale": "en-IN",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-IN-NeerjaExpressiveNeural.mp3",
    },
    "neerja": {
        "full_name": "en-IN-NeerjaNeural",
        "locale": "en-IN",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-IN-NeerjaNeural.mp3",
    },
    "prabhat": {
        "full_name": "en-IN-PrabhatNeural",
        "locale": "en-IN",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-IN-PrabhatNeural.mp3",
    },
    # Kenyan English
    "asilia": {
        "full_name": "en-KE-AsiliaNeural",
        "locale": "en-KE",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-KE-AsiliaNeural.mp3",
    },
    "chilemba": {
        "full_name": "en-KE-ChilembaNeural",
        "locale": "en-KE",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-KE-ChilembaNeural.mp3",
    },
    # Nigerian English
    "abeo": {
        "full_name": "en-NG-AbeoNeural",
        "locale": "en-NG",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-NG-AbeoNeural.mp3",
    },
    "ezinne": {
        "full_name": "en-NG-EzinneNeural",
        "locale": "en-NG",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-NG-EzinneNeural.mp3",
    },
    # New Zealand English
    "mitchell": {
        "full_name": "en-NZ-MitchellNeural",
        "locale": "en-NZ",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-NZ-MitchellNeural.mp3",
    },
    "molly": {
        "full_name": "en-NZ-MollyNeural",
        "locale": "en-NZ",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-NZ-MollyNeural.mp3",
    },
    # Philippine English
    "james": {
        "full_name": "en-PH-JamesNeural",
        "locale": "en-PH",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-PH-JamesNeural.mp3",
    },
    "rosa": {
        "full_name": "en-PH-RosaNeural",
        "locale": "en-PH",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-PH-RosaNeural.mp3",
    },
    # Singaporean English
    "luna": {
        "full_name": "en-SG-LunaNeural",
        "locale": "en-SG",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-SG-LunaNeural.mp3",
    },
    "wayne": {
        "full_name": "en-SG-WayneNeural",
        "locale": "en-SG",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-SG-WayneNeural.mp3",
    },
    # Tanzanian English
    "elimu": {
        "full_name": "en-TZ-ElimuNeural",
        "locale": "en-TZ",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-TZ-ElimuNeural.mp3",
    },
    "imani": {
        "full_name": "en-TZ-ImaniNeural",
        "locale": "en-TZ",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-TZ-ImaniNeural.mp3",
    },
    # US English
    "aria": {
        "full_name": "en-US-AriaNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-AriaNeural.mp3",
    },
    "guy": {
        "full_name": "en-US-GuyNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-GuyNeural.mp3",
    },
    "jenny": {
        "full_name": "en-US-JennyNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-JennyNeural.mp3",
    },
    "davis": {"full_name": "en-US-DavisNeural", "locale": "en-US", "gender": "Male"},
    "amber": {"full_name": "en-US-AmberNeural", "locale": "en-US", "gender": "Female"},
    "ana": {
        "full_name": "en-US-AnaNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-AnaNeural.mp3",
    },
    "andrew": {
        "full_name": "en-US-AndrewNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-AndrewNeural.mp3",
    },
    "andrew-ml": {
        "full_name": "en-US-AndrewMultilingualNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-AndrewMultilingualNeural.mp3",
    },
    "ashley": {"full_name": "en-US-AshleyNeural", "locale": "en-US", "gender": "Female"},
    "ava": {
        "full_name": "en-US-AvaNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-AvaNeural.mp3",
    },
    "ava-ml": {
        "full_name": "en-US-AvaMultilingualNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-AvaMultilingualNeural.mp3",
    },
    "brandon": {"full_name": "en-US-BrandonNeural", "locale": "en-US", "gender": "Male"},
    "brian": {
        "full_name": "en-US-BrianNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-BrianNeural.mp3",
    },
    "brian-ml": {
        "full_name": "en-US-BrianMultilingualNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-BrianMultilingualNeural.mp3",
    },
    "christopher": {
        "full_name": "en-US-ChristopherNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-ChristopherNeural.mp3",
    },
    "cora": {"full_name": "en-US-CoraNeural", "locale": "en-US", "gender": "Female"},
    "elizabeth": {"full_name": "en-US-ElizabethNeural", "locale": "en-US", "gender": "Female"},
    "emma": {
        "full_name": "en-US-EmmaNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-EmmaNeural.mp3",
    },
    "emma-ml": {
        "full_name": "en-US-EmmaMultilingualNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-EmmaMultilingualNeural.mp3",
    },
    "eric": {
        "full_name": "en-US-EricNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-EricNeural.mp3",
    },
    "jacob": {"full_name": "en-US-JacobNeural", "locale": "en-US", "gender": "Male"},
    "jane": {"full_name": "en-US-JaneNeural", "locale": "en-US", "gender": "Female"},
    "jason": {"full_name": "en-US-JasonNeural", "locale": "en-US", "gender": "Male"},
    "michelle": {
        "full_name": "en-US-MichelleNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-MichelleNeural.mp3",
    },
    "monica": {"full_name": "en-US-MonicaNeural", "locale": "en-US", "gender": "Female"},
    "nancy": {"full_name": "en-US-NancyNeural", "locale": "en-US", "gender": "Female"},
    "roger": {
        "full_name": "en-US-RogerNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-RogerNeural.mp3",
    },
    "sara": {"full_name": "en-US-SaraNeural", "locale": "en-US", "gender": "Female"},
    "steffan": {
        "full_name": "en-US-SteffanNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-SteffanNeural.mp3",
    },
    "tony": {"full_name": "en-US-TonyNeural", "locale": "en-US", "gender": "Male"},
    # South African English
    "leah": {
        "full_name": "en-ZA-LeahNeural",
        "locale": "en-ZA",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-ZA-LeahNeural.mp3",
    },
    "luke": {
        "full_name": "en-ZA-LukeNeural",
        "locale": "en-ZA",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-ZA-LukeNeural.mp3",
    },
    # French — France
    "denise": {
        "full_name": "fr-FR-DeniseNeural",
        "locale": "fr-FR",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE_FR}/fr-FR-DeniseNeural.mp3",
    },
    "henri": {
        "full_name": "fr-FR-HenriNeural",
        "locale": "fr-FR",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE_FR}/fr-FR-HenriNeural.mp3",
    },
    "eloise": {
        "full_name": "fr-FR-EloiseNeural",
        "locale": "fr-FR",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE_FR}/fr-FR-EloiseNeural.mp3",
    },
    # French — Belgium
    "charline": {
        "full_name": "fr-BE-CharlineNeural",
        "locale": "fr-BE",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE_FR}/fr-BE-CharlineNeural.mp3",
    },
    "gerard": {
        "full_name": "fr-BE-GerardNeural",
        "locale": "fr-BE",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE_FR}/fr-BE-GerardNeural.mp3",
    },
    # French — Canada
    "sylvie": {
        "full_name": "fr-CA-SylvieNeural",
        "locale": "fr-CA",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE_FR}/fr-CA-SylvieNeural.mp3",
    },
    "antoine": {
        "full_name": "fr-CA-AntoineNeural",
        "locale": "fr-CA",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE_FR}/fr-CA-AntoineNeural.mp3",
    },
    "jean": {
        "full_name": "fr-CA-JeanNeural",
        "locale": "fr-CA",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE_FR}/fr-CA-JeanNeural.mp3",
    },
    "thierry": {
        "full_name": "fr-CA-ThierryNeural",
        "locale": "fr-CA",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE_FR}/fr-CA-ThierryNeural.mp3",
    },
    # Vietnamese — Vietnam
    "hoaimy": {
        "full_name": "vi-VN-HoaiMyNeural",
        "locale": "vi-VN",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE_VI}/vi-VN-HoaiMyNeural.mp3",
    },
    "namminh": {
        "full_name": "vi-VN-NamMinhNeural",
        "locale": "vi-VN",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE_VI}/vi-VN-NamMinhNeural.mp3",
    },
}

DEFAULT_VOICE = "en-US-AriaNeural"


def resolve_voice(voice: str) -> str:
    """Resolve a short alias to a full edge-tts voice name, or pass through as-is.

    Args:
        voice: Short alias (e.g. "aria") or full name (e.g. "en-US-AriaNeural").

    Returns:
        Full edge-tts voice identifier.
    """
    lower = voice.lower()
    if lower in DEFAULT_VOICES:
        return DEFAULT_VOICES[lower]["full_name"]
    return voice
