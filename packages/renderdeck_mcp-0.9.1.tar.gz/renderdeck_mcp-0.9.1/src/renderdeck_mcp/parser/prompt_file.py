"""Slide prompt file parser.

Parses the RenderDeck prompt file format into structured slide data.
Pure function implementation — no file I/O, no sys.exit(), no env vars.

Design doc: docs/sdd/epic-parser-validation/prompt-file-parser/design.md
Behavioral spec: renderdeck.py lines 200-308.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from renderdeck_mcp.generation.types import ReferenceImageDict

# ---------------------------------------------------------------------------
# Compiled regex patterns (module level for performance)
# ---------------------------------------------------------------------------

_SEP_RE = re.compile(r"(?m)^-{3,}\s*$")
_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)
_H2_SUBTITLE_RE = re.compile(r"^##\s+(.+)$", re.MULTILINE)
_SLIDE_HEADING_RE = re.compile(r"^##\s+Slide\s+(\d{2})\s+[—\-]\s*(.*)$", re.MULTILINE)
_SPEAKER_NOTES_H3_RE = re.compile(r"^###\s+Slide\s+(\d{2})\s+[—\-].*$", re.MULTILINE)
_INLINE_SPEAKER_NOTES_RE = re.compile(r"(?m)^###\s+Speaker\s+Notes\s*$")
_REFERENCES_BLOCK_RE = re.compile(r"(?m)^REFERENCES:\s*$")

# ---------------------------------------------------------------------------
# Section header name constants
# ---------------------------------------------------------------------------

_SECTION_GENERAL = "General"
_SECTION_GLOBAL_RULES = "Global Rules"
_SECTION_SPEAKER_NOTES = "Speaker Notes"

# ---------------------------------------------------------------------------
# Field name constants
# ---------------------------------------------------------------------------

FIELD_SLIDE_NUMBER = "slide_number"
FIELD_SLIDE_TITLE = "slide_title"
FIELD_IMAGE_PROMPT = "image_prompt"
FIELD_HAS_PROMPT = "has_prompt"
FIELD_SPEAKER_NOTES = "speaker_notes"
FIELD_HAS_NOTES = "has_notes"


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class ParsedSlide:
    """Structured representation of a single slide block."""

    number: str
    """Two-digit zero-padded slide number string (e.g. '03').
    Source: capture group 1 of _SLIDE_HEADING_RE.
    """

    title: str
    """Slide title text after the dash in the H2 heading, stripped.
    Source: capture group 2 of _SLIDE_HEADING_RE, stripped.
    """

    image_prompt: str
    """Full body text of the slide block, excluding the H2 heading line.
    Empty string ('') when the block has no body.
    """

    has_prompt: bool
    """True when image_prompt is non-empty after stripping whitespace."""

    speaker_notes: str
    """Body text of the matching ### Slide NN sub-section in Speaker Notes.
    Empty string ('') when no matching sub-section exists.
    """

    has_notes: bool
    """True when speaker_notes is non-empty."""

    line_number: int
    """1-based line number of the ## Slide heading in the original content."""

    reference_images: list[ReferenceImageDict] = field(default_factory=list)
    """Parsed reference images from the REFERENCES: block. Empty list when absent."""


@dataclass
class ParsedDeck:
    """Structured representation of a parsed slide deck prompt file."""

    title: str
    """Presentation title from the H1 heading. Empty string when H1 is absent."""

    title_line_number: int
    """1-based line number of the H1 heading. 0 when H1 is absent."""

    subtitle: str
    """Optional subtitle from the first non-reserved H2 in front matter."""

    general: str
    """Content of the ## General block. Empty string when absent."""

    global_rules: str
    """Content of the ## Global Rules block. Empty string when absent."""

    slides: list[ParsedSlide]
    """Ordered list of parsed slides."""

    speaker_notes: dict[int, str]
    """Speaker notes keyed by slide number as int. Populated during parse."""

    warnings: list[str] = field(default_factory=list)
    """Non-fatal diagnostic messages collected during parsing."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _block_after_header(text: str, header_name: str) -> str:
    """Extract block content after ## Header Name until next ## or end.

    Direct extraction of the same-named inner function from renderdeck.py
    lines 226-234. Lifted to module scope as a private helper.

    Args:
        text: Text to search within (typically: content after H1 in first segment).
        header_name: Exact header name to match (e.g. 'General', 'Global Rules').
                     Matched case-insensitively.

    Returns:
        Stripped block text, or '' if header not found.
    """
    pattern = rf"^##\s+{re.escape(header_name)}\s*$"
    m = re.search(pattern, text, re.MULTILINE | re.IGNORECASE)
    if not m:
        return ""
    rest = text[m.end() :]
    next_sec = re.search(r"\n##\s+", rest)
    return (rest[: next_sec.start()] if next_sec else rest).strip()


def _line_number_of(content: str, pos: int) -> int:
    """Return the 1-based line number of character position pos in content."""
    return content.count("\n", 0, pos) + 1


def _parse_references_block(block_text: str) -> list[ReferenceImageDict]:
    """Parse a REFERENCES: block from a slide body into a list of ReferenceImageDict.

    Each reference entry is delimited by a blank line or a list bullet (`-`).
    Recognised field names: url, base64, media_type, role, placement.
    Lines that do not match key: value are silently skipped.

    Args:
        block_text: The text that follows the REFERENCES: line, up to the next
                    section heading or end of block.

    Returns:
        List of ReferenceImageDict. May be empty if no valid entries found.
    """
    if not block_text.strip():
        return []

    _KNOWN_FIELDS = {"url", "base64", "media_type", "role", "placement"}
    _KEY_VALUE_RE = re.compile(r"^\s*(\w+)\s*:\s*(.+)$")

    # Split into raw entry chunks by blank lines or leading '-' bullets.
    # We re-join lines that belong to the same entry (indented continuation lines).
    # Strategy: split on lines that start a new entry (blank line or '- ').
    entries: list[dict[str, str]] = []
    current: dict[str, str] = {}

    for line in block_text.splitlines():
        stripped = line.strip()
        # Blank line → flush current entry, start new
        if not stripped:
            if current:
                entries.append(current)
                current = {}
            continue

        # A new bullet marker '- key: value' starts a new entry
        # Strip leading '-' and treat remaining as key: value
        if stripped.startswith("- "):
            # Flush previous entry if non-empty
            if current:
                entries.append(current)
                current = {}
            stripped = stripped[2:].strip()

        m = _KEY_VALUE_RE.match(stripped)
        if m:
            key = m.group(1).lower()
            value = m.group(2).strip()
            if key in _KNOWN_FIELDS:
                current[key] = value

    # Flush final entry
    if current:
        entries.append(current)

    # Filter: only keep entries with at least 'url' or 'base64'
    result: list[ReferenceImageDict] = []
    for entry in entries:
        if "url" in entry or "base64" in entry:
            ref: ReferenceImageDict = {}
            if "url" in entry:
                ref["url"] = entry["url"]
            if "base64" in entry:
                ref["base64"] = entry["base64"]
            if "media_type" in entry:
                ref["media_type"] = entry["media_type"]
            if "role" in entry:
                ref["role"] = entry["role"]
            if "placement" in entry:
                ref["placement"] = entry["placement"]
            result.append(ref)

    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_prompt_file(content: str) -> ParsedDeck:
    """Parse slide prompt file markdown text into a structured ParsedDeck.

    This is a pure function. It performs no file I/O, makes no network calls,
    reads no environment variables, and never raises an exception or calls
    sys.exit(). All error and warning conditions are returned in the result.

    The parsing behavior matches renderdeck.py lines 200-308 exactly. Given
    the same input string, this function produces the same structural data
    as renderdeck.py's parse_markdown() function (minus file I/O).

    Args:
        content: Full text of the slide prompt file, UTF-8 decoded.
                 The caller is responsible for file I/O and encoding handling.

    Returns:
        ParsedDeck dataclass. Always returns a result — never raises.
        Check ParsedDeck.warnings for non-fatal issues.
        Check ParsedDeck.title == '' to detect missing H1 (fatal in renderdeck.py,
        returned here for the validator to handle with line numbers).

    Examples:
        >>> from pathlib import Path
        >>> content = Path("deck.md").read_text(encoding="utf-8")
        >>> deck = parse_prompt_file(content)
        >>> print(deck.title)
        'My Presentation'
        >>> print(len(deck.slides))
        15
    """
    warnings: list[str] = []

    # ------------------------------------------------------------------
    # Step 1 — Split on separators (renderdeck.py lines 207-212)
    # ------------------------------------------------------------------
    segments = _SEP_RE.split(content)
    segments = [s.strip() for s in segments if s.strip()]

    if not segments:
        warnings.append("No content found")
        return ParsedDeck(
            title="",
            title_line_number=0,
            subtitle="",
            general="",
            global_rules="",
            slides=[],
            speaker_notes={},
            warnings=warnings,
        )

    # ------------------------------------------------------------------
    # Step 2 — Parse front matter (renderdeck.py lines 214-245)
    # ------------------------------------------------------------------
    first = segments[0]

    h1_match = _H1_RE.search(first)
    if not h1_match:
        title = ""
        title_line_number = 0
        warnings.append("No H1 title found")
        after_h1 = first.lstrip()
    else:
        title = h1_match.group(1).strip()
        title_line_number = _line_number_of(content, content.find(first) + h1_match.start())
        after_h1 = first[h1_match.end() :].lstrip()

    # General block (renderdeck.py line 236)
    general = _block_after_header(after_h1, _SECTION_GENERAL)

    # Global Rules block (renderdeck.py line 237)
    global_rules = _block_after_header(after_h1, _SECTION_GLOBAL_RULES)

    # Subtitle — first H2 that is not a reserved section name (lines 239-245)
    subtitle = ""
    before_first_section = re.split(r"\n##\s+", after_h1, maxsplit=1)[0].strip()
    h2_subtitle_match = re.search(r"^##\s+(.+)$", before_first_section, re.MULTILINE)
    if h2_subtitle_match:
        sub_candidate = h2_subtitle_match.group(1).strip()
        if sub_candidate.lower() not in (
            _SECTION_GENERAL.lower(),
            _SECTION_GLOBAL_RULES.lower(),
            _SECTION_SPEAKER_NOTES.lower(),
            "slide",
        ):
            subtitle = sub_candidate

    # ------------------------------------------------------------------
    # Step 3 — Identify slide blocks vs. speaker notes (lines 250-254)
    # ------------------------------------------------------------------
    # Find the segment that starts the Speaker Notes section.
    speaker_notes_idx: int | None = None
    for idx, seg in enumerate(segments):
        if seg.strip().lower().startswith(f"## {_SECTION_SPEAKER_NOTES.lower()}"):
            speaker_notes_idx = idx
            break

    if speaker_notes_idx is not None:
        has_speaker_notes_block = True
        # Rejoin speaker notes segment + everything after it (they were split on ---)
        last_segment = "\n---\n".join(segments[speaker_notes_idx:])
        slide_blocks = segments[1:speaker_notes_idx]
    else:
        has_speaker_notes_block = False
        last_segment = ""
        slide_blocks = segments[1:]

    # ------------------------------------------------------------------
    # Step 4 — Parse slide blocks (lines 256-274)
    # ------------------------------------------------------------------
    slides: list[ParsedSlide] = []

    for block in slide_blocks:
        block = block.strip()
        if not block:
            continue
        m = _SLIDE_HEADING_RE.match(block)
        if not m:
            warnings.append("Slide heading does not match ## Slide NN — ...; skipping block.")
            continue

        slide_number = m.group(1)  # raw two-char string e.g. "03"
        slide_title = m.group(2).strip()
        body = block[m.end() :].strip()

        # Check for inline ### Speaker Notes within the slide block
        inline_notes_match = _INLINE_SPEAKER_NOTES_RE.search(body)
        if inline_notes_match:
            image_prompt = body[: inline_notes_match.start()].strip()
            inline_notes = body[inline_notes_match.end() :].strip()
        else:
            image_prompt = body
            inline_notes = ""

        # Extract REFERENCES: block from image_prompt (before has_prompt is set)
        reference_images: list[ReferenceImageDict] = []
        refs_match = _REFERENCES_BLOCK_RE.search(image_prompt)
        if refs_match:
            refs_block_text = image_prompt[refs_match.end() :]
            reference_images = _parse_references_block(refs_block_text)
            image_prompt = image_prompt[: refs_match.start()].strip()

        has_prompt = bool(image_prompt)

        # Compute line number in original content by finding the block's
        # start position then locating the heading within it.
        block_pos = content.find(block)
        if block_pos == -1:
            # Fallback: search for the heading directly in content.
            heading_match = _SLIDE_HEADING_RE.search(content)
            line_num = _line_number_of(content, heading_match.start()) if heading_match else 1
        else:
            line_num = _line_number_of(content, block_pos + m.start())

        slides.append(
            ParsedSlide(
                number=slide_number,
                title=slide_title,
                image_prompt=image_prompt,
                has_prompt=has_prompt,
                speaker_notes=inline_notes,
                has_notes=bool(inline_notes),
                line_number=line_num,
                reference_images=reference_images,
            )
        )

    # ------------------------------------------------------------------
    # Step 5 — Slide count warning (lines 276-277)
    # ------------------------------------------------------------------
    if len(slides) > 30:
        warnings.append(
            f"{len(slides)} slides found"
            " — Google Slides API performance may degrade above 30 slides."
        )

    # ------------------------------------------------------------------
    # Step 6 — Parse speaker notes (lines 280-300)
    # ------------------------------------------------------------------
    speaker_notes_dict: dict[int, str] = {}

    if has_speaker_notes_block:
        notes_content = last_segment.split("\n", 1)[-1].strip() if "\n" in last_segment else ""
        parts = _SPEAKER_NOTES_H3_RE.split(notes_content)

        if len(parts) >= 2:
            for i in range(1, len(parts) - 1, 2):
                notes_slide_num = parts[i].strip()
                notes_body = parts[i + 1].strip()

                # Strip any trailing content after a subsequent ### line
                next_h3 = re.search(r"\n###\s+", notes_body)
                if next_h3:
                    notes_body = notes_body[: next_h3.start()].strip()

                # Strip trailing --- separator artifacts from rejoined segments
                notes_body = re.sub(r"\n?-{3,}\s*$", "", notes_body).strip()

                # Find matching slides by number string
                matching = [s for s in slides if s.number == notes_slide_num]
                if not matching:
                    warnings.append(
                        f"Speaker notes for slide {notes_slide_num}"
                        " have no matching slide; skipping."
                    )
                    continue

                for s in matching:
                    s.speaker_notes = notes_body
                    s.has_notes = True
                    speaker_notes_dict[int(notes_slide_num)] = notes_body

    # ------------------------------------------------------------------
    # Step 6b — Populate speaker_notes_dict from inline notes
    # Consolidated ## Speaker Notes (Step 6) takes precedence over inline.
    # ------------------------------------------------------------------
    for s in slides:
        if s.has_notes and int(s.number) not in speaker_notes_dict:
            speaker_notes_dict[int(s.number)] = s.speaker_notes

    # ------------------------------------------------------------------
    # Step 7 — Return
    # ------------------------------------------------------------------
    return ParsedDeck(
        title=title,
        title_line_number=title_line_number,
        subtitle=subtitle,
        general=general,
        global_rules=global_rules,
        slides=slides,
        speaker_notes=speaker_notes_dict,
        warnings=warnings,
    )
