"""Content-hash-based image generation cache.

Avoids duplicate Gemini API calls by caching generated images keyed on
content hash (General + Global Rules + prompt + options).

Hash algorithm mirrors renderdeck.py exactly (lines 367-389) so that
the MCP server can read and write cache manifests produced by the CLI
and vice versa.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path

from renderdeck_mcp.generation.types import ReferenceImageDict

# Matches renderdeck.py HASH_HEX_LEN constant
HASH_HEX_LEN: int = 16


def normalize_for_hash(text: str) -> str:
    """Normalize text for stable hashing.

    Strips leading/trailing whitespace, normalizes line endings to LF,
    and removes trailing newlines.  Mirrors renderdeck.py
    ``_normalize_for_hash`` (lines 367-372).

    Args:
        text: Raw text to normalize.

    Returns:
        Normalized string suitable for inclusion in a hash payload.
    """
    if not text:
        return ""
    s = (text or "").strip().replace("\r\n", "\n").replace("\r", "\n")
    return s.rstrip("\n")


def content_hash_for_slide(
    general: str,
    global_rules: str,
    image_prompt: str,
    reference_images: list[ReferenceImageDict] | None = None,
) -> str:
    """Compute a 16-character content hash for one slide.

    Combines General context, Global Rules, and the slide image prompt
    with double-newline separators, then returns the first 16 hex
    characters of the SHA-256 digest.  Mirrors renderdeck.py
    ``_content_hash_for_slide`` (lines 375-381).

    When reference_images is provided (non-None, non-empty), a stable JSON
    serialisation is appended to the combined string so the hash changes
    when references change. Callers that omit reference_images produce the
    same hash as before (backward compatible).

    Args:
        general: General context block text.
        global_rules: Global Rules block text.
        image_prompt: Slide image prompt text.
        reference_images: Optional list of reference image dicts. None or []
            produce the same hash as callers that omit this argument.

    Returns:
        16-character lowercase hex string.
    """
    g = normalize_for_hash(general)
    r = normalize_for_hash(global_rules)
    p = normalize_for_hash(image_prompt)
    if reference_images:
        refs_str = json.dumps(
            [dict(sorted(ref.items())) for ref in reference_images],
            sort_keys=True,
        )
        combined = f"{g}\n\n{r}\n\n{p}\n\n{refs_str}"
    else:
        combined = f"{g}\n\n{r}\n\n{p}"
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()[:HASH_HEX_LEN]


def options_hash(aspect_ratio: str, model: str) -> str:
    """Compute a 16-character options hash for image generation settings.

    Combines aspect ratio (uppercased, defaulting to ``"WIDE"``) and
    model name with a single-newline separator, then returns the first
    16 hex characters of the SHA-256 digest.  Mirrors renderdeck.py
    ``_options_hash`` (lines 384-389).

    Args:
        aspect_ratio: Slide aspect ratio (e.g. ``"WIDE"``, ``"TALL"``,
            ``"SQUARE"``).  Empty/None falls back to ``"WIDE"``.
        model: Gemini model identifier.  Empty/None falls back to
            ``"gemini-2.5-flash-image"``.

    Returns:
        16-character lowercase hex string.
    """
    aspect = (aspect_ratio or "WIDE").upper()
    mod = model or "gemini-3-pro-image-preview"
    combined = f"{aspect}\n{mod}"
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()[:HASH_HEX_LEN]


# ---------------------------------------------------------------------------
# Cache manifest — per-project content-hash-based image caching
# ---------------------------------------------------------------------------

CACHE_MANIFEST_FILE: str = "cache_manifest.json"
MANIFEST_VERSION: int = 1
CACHE_BASE_DIR: Path = Path.home() / ".renderdeck" / "cache"


@dataclass
class CacheManifest:
    """In-memory representation of a per-project cache manifest.

    Attributes:
        version: Schema version. Always ``MANIFEST_VERSION`` (1) for new
            manifests.
        options_hash: 16-char hex hash of the image generation options
            (aspect_ratio + model).  All slides share the same options;
            if this changes every slide is regenerated.
        slides: Mapping of slide number (1-based int) to its 16-char content
            hash.  A slide is regenerated if its hash is absent or changed.
    """

    version: int
    options_hash: str
    slides: dict[int, str]


def _cache_dir(project_name: str) -> Path:
    """Return the cache directory path for a project (does not create it).

    Args:
        project_name: Project identifier used as the directory name.

    Returns:
        Path to ``~/.renderdeck/cache/{project_name}/``.
    """
    return CACHE_BASE_DIR / project_name


def load_cache_manifest(project_name: str) -> CacheManifest | None:
    """Load the cache manifest for a project from disk.

    Returns ``None`` (rather than raising) for any of: missing directory,
    missing file, unreadable file, invalid JSON, or wrong schema version.

    Args:
        project_name: Project identifier — used to locate the cache dir.

    Returns:
        Populated :class:`CacheManifest` on success, ``None`` otherwise.
    """
    path = _cache_dir(project_name) / CACHE_MANIFEST_FILE
    if not path.exists() or not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict) or data.get("version") != MANIFEST_VERSION:
        return None
    opts = data.get("options_hash", "")
    raw_slides = data.get("slides", {})
    if not isinstance(raw_slides, dict):
        return None
    slides: dict[int, str] = {int(k): v for k, v in raw_slides.items()}
    return CacheManifest(version=MANIFEST_VERSION, options_hash=opts, slides=slides)


def save_cache_manifest(project_name: str, manifest: CacheManifest) -> None:
    """Write a cache manifest to disk atomically.

    Uses a write-to-temp-then-rename strategy so the manifest is never
    partially written from the reader's perspective.

    Args:
        project_name: Project identifier — determines the cache directory.
        manifest: Manifest instance to persist.

    Raises:
        OSError: If the directory cannot be created or the file cannot be
            written.  The ``.tmp`` file is cleaned up before re-raising.
    """
    cache_dir = _cache_dir(project_name)
    cache_dir.mkdir(parents=True, exist_ok=True)
    path = cache_dir / CACHE_MANIFEST_FILE
    tmp_path = cache_dir / (CACHE_MANIFEST_FILE + ".tmp")
    data = {
        "version": manifest.version,
        "options_hash": manifest.options_hash,
        "slides": {str(k): v for k, v in manifest.slides.items()},
    }
    try:
        tmp_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.replace(tmp_path, path)
    except Exception:
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise


def should_regenerate(
    slide_number: int,
    content_hash: str,
    manifest: CacheManifest | None,
    current_options_hash: str,
) -> bool:
    """Decide whether a slide's image must be regenerated.

    Returns ``True`` (regenerate) when any condition holds:

    - *manifest* is ``None`` — no valid cache on disk.
    - Options hash changed — generation settings differ from last run.
    - Slide is absent from the manifest — new slide added.
    - Content hash changed — slide text or shared context changed.

    Returns ``False`` only when all four match (slide is up-to-date).

    Args:
        slide_number: 1-based slide index.
        content_hash: Current 16-char content hash for this slide.
        manifest: Loaded manifest (may be ``None``).
        current_options_hash: 16-char hash of current generation options.

    Returns:
        ``True`` if the image should be regenerated, ``False`` to reuse cache.
    """
    if manifest is None:
        return True
    if manifest.options_hash != current_options_hash:
        return True
    cached = manifest.slides.get(slide_number)
    if cached is None:
        return True
    return cached != content_hash
