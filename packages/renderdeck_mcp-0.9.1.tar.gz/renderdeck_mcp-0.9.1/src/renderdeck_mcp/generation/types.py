"""Shared types for the generation subpackage.

Defines ReferenceImageDict and ResolvedReferenceImage in a separate module
to avoid circular imports between parser/prompt_file.py and generation/gemini.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TypedDict


class ReferenceImageDict(TypedDict, total=False):
    """Raw input dict accepted from MCP callers and parsed prompt files.

    At least one of url or base64 must be present.
    """

    url: str  # HTTP/HTTPS URL — fetched and converted to base64 at call time
    base64: str  # Already-encoded base64 image data
    media_type: str  # MIME type, e.g. "image/png" (default: "image/png")
    role: str  # Free-text label, e.g. "brand logo", "background reference"
    placement: str  # Hint for Gemini, e.g. "background", "top-right corner"


@dataclass(frozen=True)
class ResolvedReferenceImage:
    """A reference image with base64 data confirmed present and media_type resolved.

    Produced by _resolve_reference_image(); never constructed directly by callers.
    """

    base64_data: str  # Base64-encoded image bytes (no data-URI prefix)
    media_type: str  # Resolved MIME type (default: "image/png")
    role: str  # Role label (empty string if not specified)
    placement: str  # Placement hint (empty string if not specified)
