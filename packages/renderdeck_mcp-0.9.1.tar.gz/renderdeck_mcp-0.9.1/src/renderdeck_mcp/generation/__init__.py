"""generation subpackage — Gemini image generation and content-hash caching."""

from __future__ import annotations

from renderdeck_mcp.generation.cache import (
    CACHE_BASE_DIR,
    CACHE_MANIFEST_FILE,
    HASH_HEX_LEN,
    MANIFEST_VERSION,
    CacheManifest,
    content_hash_for_slide,
    load_cache_manifest,
    normalize_for_hash,
    options_hash,
    save_cache_manifest,
    should_regenerate,
)
from renderdeck_mcp.generation.types import (
    ReferenceImageDict,
    ResolvedReferenceImage,
)

__all__ = [
    "ReferenceImageDict",
    "ResolvedReferenceImage",
    "CACHE_BASE_DIR",
    "CACHE_MANIFEST_FILE",
    "CacheManifest",
    "HASH_HEX_LEN",
    "MANIFEST_VERSION",
    "content_hash_for_slide",
    "load_cache_manifest",
    "normalize_for_hash",
    "options_hash",
    "save_cache_manifest",
    "should_regenerate",
]
