"""MCP tool: validate_prompt_file.

Wraps the parser validator as an MCP tool, returning a structured dict
suitable for JSON serialisation by FastMCP.
"""

from __future__ import annotations

from pathlib import Path

from renderdeck_mcp.cache import prompt_cache


def _error_result(message: str) -> dict[str, object]:
    """Build a consistent early-exit error dict."""
    return {
        "valid": False,
        "slide_count": 0,
        "slides": [],
        "errors": [{"line_number": None, "message": message, "slide_number": None}],
        "warnings": [],
        "prompt_id": "",
    }


def run_validate(
    slide_prompt_content: str | None = None,
    file_path: str | None = None,
) -> dict[str, object]:
    """Validate a slide prompt file and return a structured result.

    Exactly one of slide_prompt_content or file_path must be provided.
    When file_path is given the content is read from disk (UTF-8).

    Returns a dict with keys: valid, slide_count, slides, errors, warnings,
    prompt_id.
    """
    # Mutual-exclusion guard.
    if slide_prompt_content is None and file_path is None:
        return _error_result("Provide either slide_prompt_content or file_path.")
    if slide_prompt_content is not None and file_path is not None:
        return _error_result("Provide slide_prompt_content or file_path, not both.")

    # Resolve content from file when file_path is given.
    if file_path is not None:
        path = Path(file_path)
        if not path.is_file():
            return _error_result(f"File not found: {file_path}")
        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as e:
            return _error_result(f"Cannot read file: {e}")
        slide_prompt_content = content

    entry = prompt_cache.store(slide_prompt_content)  # type: ignore[arg-type]
    result = entry.validation_result

    return {
        "valid": result.valid,
        "slide_count": result.slide_count,
        "slides": [
            {"number": s.number, "title": s.title, "line_number": s.line_number}
            for s in result.slides
        ],
        "errors": [
            {
                "line_number": e.line_number,
                "message": e.message,
                "slide_number": e.slide_number,
            }
            for e in result.errors
        ],
        "warnings": result.warnings,
        "prompt_id": entry.prompt_id,
    }
