"""Entry point for `python -m renderdeck_mcp` and the `renderdeck-mcp` console script.

Usage:
    python -m renderdeck_mcp serve
    python -m renderdeck_mcp install
    renderdeck-mcp serve
    renderdeck-mcp install

The `serve` subcommand starts the MCP server on stdio using FastMCP.
The `install` subcommand configures API key and Claude Desktop integration.
The server import is deferred to inside main() to avoid loading google libs at startup.
"""

from __future__ import annotations

import sys

SUBCOMMANDS = ("serve", "install")


def main() -> None:
    """Entry point for `python -m renderdeck_mcp` and `uvx renderdeck-mcp serve`."""
    subcommand = sys.argv[1] if len(sys.argv) >= 2 else "serve"

    if subcommand not in SUBCOMMANDS:
        print(f"Usage: renderdeck-mcp [{' | '.join(SUBCOMMANDS)}]", file=sys.stderr)
        sys.exit(1)

    if subcommand == "install":
        from renderdeck_mcp.tools.installer import run_install

        run_install()
    else:
        from renderdeck_mcp.server import run

        run()


if __name__ == "__main__":
    main()
