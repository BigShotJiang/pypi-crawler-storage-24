"""In-memory prompt file cache for the RenderDeck MCP server.

Caches parsed prompt files keyed by SHA-256 content hash so that downstream
tools can reference validated prompts by ID rather than re-sending the full
content on every tool call.

Design doc: docs/sdd/epic-mcp-server-generation-assembly/prompt-file-cache/design.md
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass

from renderdeck_mcp.parser.prompt_file import ParsedDeck, parse_prompt_file
from renderdeck_mcp.parser.validator import ValidationResult, validate_prompt_file


@dataclass
class PromptCacheEntry:
    """A single cached prompt file parse result."""

    prompt_id: str
    raw_content: str
    parsed_deck: ParsedDeck
    validation_result: ValidationResult
    created_at: float  # time.monotonic() timestamp


class PromptCache:
    """In-memory prompt file cache, scoped to a single MCP server session.

    Entries are keyed by SHA-256 hex digest of the raw prompt content.
    When max_entries is reached, the oldest entry (by created_at) is evicted.
    """

    def __init__(self, max_entries: int = 64) -> None:
        self._entries: dict[str, PromptCacheEntry] = {}
        self._max_entries: int = max_entries

    def store(self, content: str) -> PromptCacheEntry:
        """Parse, validate, and cache the given prompt content.

        Computes the SHA-256 hex digest of the content, parses and validates
        the prompt file, stores the result, and returns the entry.
        If an entry with the same prompt_id already exists, it is overwritten
        (resetting created_at).

        Evicts the oldest entry if max_entries would be exceeded.

        Args:
            content: Raw prompt file text.

        Returns:
            PromptCacheEntry with prompt_id, parsed_deck, validation_result, etc.
        """
        prompt_id = hashlib.sha256(content.encode("utf-8")).hexdigest()

        # If not already present and at capacity, evict oldest entry.
        if prompt_id not in self._entries and len(self._entries) >= self._max_entries:
            oldest_id = min(self._entries, key=lambda k: self._entries[k].created_at)
            del self._entries[oldest_id]

        parsed_deck = parse_prompt_file(content)
        validation_result = validate_prompt_file(content)

        entry = PromptCacheEntry(
            prompt_id=prompt_id,
            raw_content=content,
            parsed_deck=parsed_deck,
            validation_result=validation_result,
            created_at=time.monotonic(),
        )
        self._entries[prompt_id] = entry
        return entry

    def get(self, prompt_id: str) -> PromptCacheEntry | None:
        """Return the cached entry for prompt_id, or None if not found.

        Args:
            prompt_id: SHA-256 hex digest of the prompt content.

        Returns:
            PromptCacheEntry if found, None otherwise.
        """
        return self._entries.get(prompt_id)

    def remove(self, prompt_id: str) -> bool:
        """Remove the entry for prompt_id from the cache.

        Args:
            prompt_id: SHA-256 hex digest of the prompt content.

        Returns:
            True if the entry was found and removed, False otherwise.
        """
        if prompt_id in self._entries:
            del self._entries[prompt_id]
            return True
        return False

    def clear(self) -> None:
        """Remove all entries from the cache."""
        self._entries.clear()

    def __len__(self) -> int:
        """Return the number of entries currently in the cache."""
        return len(self._entries)


def get_validated_entry(prompt_id: str) -> PromptCacheEntry | dict[str, object]:
    """Look up a prompt_id and return the entry, or an error dict.

    Uses the module-level singleton from renderdeck_mcp.cache.

    Returns:
        PromptCacheEntry on success.
        A dict with status="error" if the prompt_id is unknown or the prompt
        is invalid.
    """
    # Import the singleton from __init__ to avoid circular dependency and to
    # always use the single shared instance.
    from renderdeck_mcp.cache import prompt_cache  # noqa: PLC0415

    entry = prompt_cache.get(prompt_id)
    if entry is None:
        return {
            "status": "error",
            "message": (
                f"Unknown prompt_id '{prompt_id}'. "
                "Call validate_prompt_file first to validate and cache the prompt."
            ),
        }
    if not entry.validation_result.valid:
        return {
            "status": "error",
            "message": (
                "Prompt file has validation errors. Fix the errors and call "
                "validate_prompt_file again to obtain a new prompt_id."
            ),
        }
    return entry
