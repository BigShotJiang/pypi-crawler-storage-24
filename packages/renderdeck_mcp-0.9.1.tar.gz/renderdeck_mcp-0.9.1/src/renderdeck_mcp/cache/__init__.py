"""Prompt file cache package for renderdeck_mcp.

Exports the module-level singleton `prompt_cache` and associated types.
"""

from __future__ import annotations

from renderdeck_mcp.cache.prompt_cache import PromptCache, PromptCacheEntry, get_validated_entry

prompt_cache = PromptCache()

__all__ = ["prompt_cache", "PromptCache", "PromptCacheEntry", "get_validated_entry"]
