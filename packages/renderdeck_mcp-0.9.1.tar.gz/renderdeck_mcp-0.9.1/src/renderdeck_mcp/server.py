"""MCP server definition for renderdeck_mcp.

Registers all six tool stubs with the FastMCP server instance using stdio transport.
No Google or Gemini imports are triggered at module load time.

Actual tool implementations are wired in downstream tasks (generate-deck-tool, etc.).
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, Literal

from mcp.server.fastmcp import Context, FastMCP

from renderdeck_mcp import __version__

mcp = FastMCP("renderdeck-mcp")
mcp._mcp_server.version = __version__

# Type alias for progress callbacks passed to tool implementations.
ProgressCallback = Callable[[float, float, str], Awaitable[None]]


def _make_progress_cb(ctx: Context | None) -> ProgressCallback | None:
    """Build an async progress callback from a FastMCP Context, or None.

    Uses ctx.info() (notifications/message) which is always sent without
    requiring the client to supply a progressToken. Also attempts
    report_progress() for clients that do support it.
    """
    if ctx is None:
        return None

    async def _cb(current: float, total: float, message: str) -> None:
        # Always send a log notification — works regardless of progressToken.
        await ctx.info(message)
        # Also try structured progress for clients that opt in.
        await ctx.report_progress(current, total, message)

    return _cb


# ---------------------------------------------------------------------------
# Tool stubs — all return {"status": "not_implemented", "message": "..."}
# ---------------------------------------------------------------------------


@mcp.tool()
async def generate_deck(
    prompt_id: str,
    output_path: str | None = None,
    image_quality: Literal["draft", "final"] = "final",
    project_name: str | None = None,
    notes_mode: Literal["full", "narration"] = "full",
    ctx: Context | None = None,
) -> dict[str, object]:
    """Generate a .pptx presentation from a slide prompt file.

    Call validate_prompt_file first to obtain prompt_id, then pass it here.
    Generates images via Gemini and assembles a .pptx at output_path
    (default: ~/Documents/RenderDeck/{title}_{timestamp}.pptx).

    Set notes_mode to "narration" to include only the **Say:** content in speaker
    notes (labels stripped), useful for video generation tools like Pictory.
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    progress_cb = _make_progress_cb(ctx)
    return await run_generate_deck(
        prompt_id,
        output_path,
        image_quality,
        project_name,
        progress_cb=progress_cb,
        notes_mode=notes_mode,
    )


@mcp.tool()
def validate_prompt_file(
    slide_prompt_content: str | None = None,
    file_path: str | None = None,
) -> dict[str, object]:
    """Validate a slide prompt file and return any parsing errors.

    Checks syntax, required sections, and slide structure without generating images.
    Provide either slide_prompt_content (inline text) or file_path (absolute path to
    a .txt/.md file on disk), but not both.
    """
    from renderdeck_mcp.tools.validate import run_validate

    return run_validate(slide_prompt_content, file_path)


@mcp.tool()
async def regenerate_slide(
    project_name: str,
    slide_numbers: list[int],
    prompt_id: str,
    output_path: str | None = None,
    ctx: Context | None = None,
) -> dict[str, object]:
    """Regenerate specific slides in an existing project.

    Call validate_prompt_file first to obtain prompt_id, then pass it here.
    Re-runs image generation for the given slide numbers, updates the cache,
    and rebuilds the .pptx at output_path.
    """
    from renderdeck_mcp.tools.regenerate import run_regenerate_slide

    progress_cb = _make_progress_cb(ctx)
    return await run_regenerate_slide(
        project_name,
        slide_numbers,
        prompt_id,
        output_path,
        progress_cb=progress_cb,
    )


@mcp.tool()
def setup_gemini_key(
    api_key: str,
) -> dict[str, object]:
    """Store the Gemini API key securely for use by generate_deck.

    Saves the key to the encrypted local config. The key is validated by
    performing a lightweight test call to the Gemini API.
    """
    from renderdeck_mcp.tools.setup import run_setup_gemini_key

    return run_setup_gemini_key(api_key)


@mcp.tool()
def get_setup_status() -> dict[str, object]:
    """Return the current configuration and setup status.

    Reports whether the Gemini API key is configured, the active model,
    default output directory, and other settings.
    """
    from renderdeck_mcp.tools.setup import run_get_setup_status

    return run_get_setup_status()


@mcp.tool()
def update_settings(
    gemini_image_model: str | None = None,
    aspect_ratio: Literal["WIDE", "STANDARD"] | None = None,
    default_output_dir: str | None = None,
    gemini_max_retries: int | None = None,
    max_concurrent_images: int | None = None,
    verbose: bool | None = None,
) -> dict[str, object]:
    """Update renderdeck configuration settings.

    Only provided (non-None) fields are updated; omitted fields retain their
    current values.
    """
    from renderdeck_mcp.config import update_settings as _update

    valid_aspects = {"WIDE", "STANDARD"}
    if aspect_ratio is not None and aspect_ratio not in valid_aspects:
        return {
            "status": "error",
            "message": f"Invalid aspect_ratio: {aspect_ratio}. Must be WIDE or STANDARD.",
        }

    updates: dict[str, object] = {}
    for key, val in [
        ("gemini_image_model", gemini_image_model),
        ("aspect_ratio", aspect_ratio),
        ("default_output_dir", default_output_dir),
        ("gemini_max_retries", gemini_max_retries),
        ("max_concurrent_images", max_concurrent_images),
        ("verbose", verbose),
    ]:
        if val is not None:
            updates[key] = val

    if not updates:
        return {"status": "success", "message": "No settings to update", "settings": {}}

    merged = _update(updates)
    return {"status": "success", "message": "Settings updated", "settings": merged}


@mcp.tool()
def get_version() -> dict[str, object]:
    """Return the renderdeck-mcp server version."""
    from importlib.metadata import version

    return {"version": version("renderdeck-mcp")}


_HELP_PATH = Path(__file__).resolve().parent / "resources" / "help.md"


def _load_help() -> str:
    """Load the help document from the bundled markdown file."""
    if _HELP_PATH.is_file():
        return _HELP_PATH.read_text(encoding="utf-8")
    msg = f"Bundled help document not found at {_HELP_PATH}"
    raise FileNotFoundError(msg)


@mcp.tool()
def get_help() -> str:
    """Return the full RenderDeck help document verbatim.

    Call this tool when the user asks how RenderDeck works, what it can do,
    or wants to see available commands.
    Present the returned text to the user exactly as-is — do not summarise or rephrase.
    """
    from importlib.metadata import version

    ver = version("renderdeck-mcp")
    return f"**RenderDeck v{ver}**\n\n{_load_help()}"


# ---------------------------------------------------------------------------
# Per-slide tools — preferred workflow for MCP clients with tool timeouts
# ---------------------------------------------------------------------------


@mcp.tool()
async def generate_slide(
    project_name: str,
    slide_number: int,
    image_prompt: str,
    general_context: str = "",
    visual_rules: str = "",
    image_quality: Literal["draft", "final"] = "final",
    reference_images: list[dict[str, Any]] | None = None,
) -> dict[str, object]:
    """Generate a single slide image and cache it.

    Call this once per slide, then call assemble_deck to build the .pptx.
    This avoids tool-call timeouts by keeping each invocation short (~30-40s).
    Returns immediately if the slide is already cached with the same prompt.

    Optionally provide reference_images as a list of dicts with fields:
    url, base64, media_type, role, placement (all optional except one of url/base64).
    """
    from renderdeck_mcp.tools.generate_slide import run_generate_slide

    return await run_generate_slide(
        project_name,
        slide_number,
        image_prompt,
        general_context,
        visual_rules,
        image_quality,
        reference_images=reference_images,  # type: ignore[arg-type]
    )


@mcp.tool()
async def generate_video(
    project_name: str,
    prompt_id: str,
    output_path: str | None = None,
    voice: str = "aria",
    slides: str | None = None,
    ctx: Context | None = None,
) -> dict[str, object]:
    """Convert a previously-generated presentation into a narrated MP4 video.

    Call validate_prompt_file first to obtain prompt_id, then pass it here.
    Reads cached slide images, generates TTS audio via edge-tts (free, no API key),
    and composes them into a single MP4 using FFmpeg. Narration is extracted from
    **Say:** lines in the prompt file's speaker notes.

    Requires ffmpeg to be installed (brew install ffmpeg / apt install ffmpeg).
    """
    from renderdeck_mcp.tools.generate_video import run_generate_video

    return await run_generate_video(
        project_name,
        prompt_id,
        output_path,
        voice,
        slides,
    )


@mcp.tool()
def list_voices() -> dict[str, object]:
    """List all supported TTS voices for video narration.

    Returns voice aliases, full edge-tts names, locale, and gender for all 60
    supported voices across 14 English locales. Use the alias or full name as the voice parameter in
    generate_video.
    """
    from renderdeck_mcp.tools.voices import run_list_voices

    return run_list_voices(open_browser=True)


@mcp.tool()
def assemble_deck(
    project_name: str,
    prompt_id: str,
    output_path: str | None = None,
    notes_mode: Literal["full", "narration"] = "full",
) -> dict[str, object]:
    """Assemble a .pptx from cached slide images.

    Call validate_prompt_file first to obtain prompt_id, then pass it here.
    Reads cached images from the project cache directory and builds the final
    PowerPoint file. Slides without cached images become text-only slides.

    Set notes_mode to "narration" to include only the **Say:** content in speaker
    notes (labels stripped), useful for video generation tools like Pictory.
    """
    from renderdeck_mcp.tools.assemble_deck import run_assemble_deck

    return run_assemble_deck(project_name, prompt_id, output_path, notes_mode=notes_mode)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def run() -> None:
    """Start the MCP server on stdio. Blocks until stdin EOF."""
    import renderdeck_mcp.prompts.templates  # noqa: F401  # registers @mcp.prompt
    import renderdeck_mcp.resources.handler  # noqa: F401  # registers @mcp.resource

    mcp.run()
