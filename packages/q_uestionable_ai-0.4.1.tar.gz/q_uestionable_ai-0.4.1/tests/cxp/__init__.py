"""CXP module tests."""
