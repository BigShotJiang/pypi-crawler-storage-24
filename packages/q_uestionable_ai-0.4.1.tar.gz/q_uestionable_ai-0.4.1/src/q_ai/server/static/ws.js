// ws.js — WebSocket event dispatcher for the operations page
(function () {
    var root = document.getElementById('operations-root');
    if (!root) return;

    var runId = root.dataset.runId || null;
    var wsUrl = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws';
    var socket;
    var elapsedInterval = null;

    // --- Reconnect state ---
    var RECONNECT_BASE_MS = 1000;
    var RECONNECT_MAX_MS = 30000;
    var reconnectDelay = RECONNECT_BASE_MS;
    var reconnectTimer = null;
    var intentionalClose = false;

    var TERMINAL_STATUSES = [2, 3, 4, 6]; // COMPLETED, FAILED, CANCELLED, PARTIAL
    var parentTerminal = false; // true once parent reaches terminal status

    var STATUS_LABELS = {
        0: 'PENDING', 1: 'RUNNING', 2: 'COMPLETED',
        3: 'FAILED', 4: 'CANCELLED', 5: 'WAITING_FOR_USER', 6: 'PARTIAL',
    };
    var STATUS_CLASSES = {
        0: 'badge-ghost', 1: 'badge-info', 2: 'badge-success',
        3: 'badge-error', 4: 'badge-ghost', 5: 'badge-warning', 6: 'badge-warning',
    };

    // --- Status bar data attribute access ---

    function getStatusBar() {
        return document.getElementById('operations-status-bar');
    }

    // --- Reconnect indicator ---

    function showReconnecting(show) {
        var indicator = document.getElementById('ws-reconnect-indicator');
        if (!indicator) {
            // Create indicator if it doesn't exist
            var bar = getStatusBar();
            if (!bar) return;
            indicator = document.createElement('span');
            indicator.id = 'ws-reconnect-indicator';
            indicator.className = 'badge badge-sm badge-warning animate-pulse ml-2';
            indicator.textContent = 'Reconnecting\u2026';
            indicator.style.display = 'none';
            bar.appendChild(indicator);
        }
        indicator.style.display = show ? 'inline-flex' : 'none';
    }

    // --- Elapsed timer ---

    function formatElapsed(totalSeconds) {
        var s = Math.max(0, Math.floor(totalSeconds));
        var h = Math.floor(s / 3600);
        var m = Math.floor((s % 3600) / 60);
        var sec = s % 60;
        var mm = (m < 10 ? '0' : '') + m;
        var ss = (sec < 10 ? '0' : '') + sec;
        if (h > 0) {
            return h + ':' + mm + ':' + ss;
        }
        return mm + ':' + ss;
    }

    function parseISOtoEpoch(isoStr) {
        if (!isoStr) return null;
        // Ensure trailing Z for UTC if no timezone info present
        var s = isoStr;
        if (!/[Zz+\-]/.test(s.slice(-6))) {
            s += 'Z';
        }
        var ms = Date.parse(s);
        return isNaN(ms) ? null : ms;
    }

    function startElapsedTimer(startedAtISO) {
        stopElapsedTimer();
        var startMs = parseISOtoEpoch(startedAtISO);
        if (!startMs) return;
        var el = document.getElementById('workflow-elapsed');
        if (!el) return;

        function tick() {
            var now = Date.now();
            el.textContent = formatElapsed((now - startMs) / 1000);
        }
        tick();
        elapsedInterval = setInterval(tick, 1000);
    }

    function stopElapsedTimer() {
        if (elapsedInterval !== null) {
            clearInterval(elapsedInterval);
            elapsedInterval = null;
        }
    }

    function showFinalElapsed(startedAtISO, finishedAtISO) {
        stopElapsedTimer();
        var startMs = parseISOtoEpoch(startedAtISO);
        var endMs = parseISOtoEpoch(finishedAtISO);
        var el = document.getElementById('workflow-elapsed');
        if (!el) return;
        if (startMs && endMs) {
            el.textContent = formatElapsed((endMs - startMs) / 1000);
        } else if (startMs) {
            // Terminal but no finished_at — show elapsed to now
            el.textContent = formatElapsed((Date.now() - startMs) / 1000);
        }
    }

    function initElapsedTimer() {
        var bar = getStatusBar();
        if (!bar) return;
        var status = parseInt(bar.dataset.workflowStatus, 10);
        var startedAt = bar.dataset.startedAt || '';
        var finishedAt = bar.dataset.finishedAt || '';

        if (isNaN(status) || !startedAt) return; // No run or no start time

        if (status === 1 || status === 5) {
            // RUNNING or WAITING_FOR_USER — live timer
            startElapsedTimer(startedAt);
        } else if (TERMINAL_STATUSES.indexOf(status) !== -1) {
            // Terminal — show final duration
            showFinalElapsed(startedAt, finishedAt);
        }
    }

    // --- WebSocket handlers ---

    function scheduleReconnect() {
        if (intentionalClose) return;
        showReconnecting(true);
        reconnectTimer = setTimeout(function () {
            reconnectTimer = null;
            connect();
        }, reconnectDelay);
        // Exponential backoff: double delay, cap at max
        reconnectDelay = Math.min(reconnectDelay * 2, RECONNECT_MAX_MS);
    }

    function connect() {
        if (socket && (socket.readyState === WebSocket.CONNECTING || socket.readyState === WebSocket.OPEN)) {
            return;
        }
        socket = new WebSocket(wsUrl);

        socket.onopen = function () {
            // Reset reconnect state on successful connection
            reconnectDelay = RECONNECT_BASE_MS;
            showReconnecting(false);

            // Re-fetch status to catch events that fired while disconnected.
            // If the status bar element doesn't exist the page is already in
            // results mode (terminal) — nothing to update.
            if (runId && getStatusBar()) {
                htmx.ajax('GET', '/api/operations/workflow-status-bar?run_id=' + runId,
                          {target: '#operations-status-bar', swap: 'outerHTML'}).then(function () {
                    var bar = getStatusBar();
                    if (bar) {
                        var status = parseInt(bar.dataset.workflowStatus, 10);
                        if (TERMINAL_STATUSES.indexOf(status) !== -1) {
                            // Workflow finished while disconnected — reload
                            // to show the full results view.
                            parentTerminal = true;
                            stopElapsedTimer();
                            window.location.reload();
                            return;
                        }
                    }
                    initElapsedTimer();
                });
                htmx.ajax('GET', '/api/operations/status-bar?run_id=' + runId,
                          {target: '#child-run-badges', swap: 'innerHTML'});
                htmx.ajax('GET', '/api/operations/findings-sidebar?run_id=' + runId,
                          {target: '#findings-sidebar-content', swap: 'innerHTML'});
            }
        };

        socket.onmessage = function (e) {
            var event = JSON.parse(e.data);
            dispatch(event);
        };

        socket.onclose = function () {
            scheduleReconnect();
        };

        socket.onerror = function () {
            // onclose will fire after onerror, which triggers reconnect
        };
    }

    function dispatch(event) {
        switch (event.type) {
            case 'run_status':   handleRunStatus(event);  break;
            case 'progress':     handleProgress(event);   break;
            case 'finding':      handleFinding(event);    break;
            case 'waiting':      handleWaiting(event);    break;
            case 'resumed':      handleResumed(event);    break;
        }
    }

    function handleRunStatus(event) {
        if (event.run_id === runId && TERMINAL_STATUSES.indexOf(event.status) !== -1) {
            // Terminal parent status — reload page to transition from
            // monitoring view to full results view (overview header,
            // module tabs, Export JSON / Generate Report buttons).
            parentTerminal = true;
            stopElapsedTimer();
            window.location.reload();
            return;
        } else if (event.run_id === runId) {
            // Non-terminal parent update — just update the badge inline
            var badge = document.getElementById('workflow-status-badge');
            if (badge) {
                badge.textContent = STATUS_LABELS[event.status] || event.status;
                badge.className = 'badge badge-sm ' + (STATUS_CLASSES[event.status] || 'badge-ghost');
            }
        }
        // Any run_status → refresh child badges via HTMX
        if (runId) {
            htmx.ajax('GET', '/api/operations/status-bar?run_id=' + runId,
                      {target: '#child-run-badges', swap: 'innerHTML'});
        }
    }

    function handleProgress(event) {
        if (!runId || event.run_id !== runId) return;
        // Ignore late progress events after parent reached terminal status
        if (parentTerminal) return;
        var el = document.getElementById('workflow-progress');
        if (el) el.textContent = event.message;
    }

    function handleFinding(event) {
        if (runId) {
            htmx.ajax('GET', '/api/operations/findings-sidebar?run_id=' + runId,
                      {target: '#findings-sidebar-content', swap: 'innerHTML'});
        }
    }

    function handleWaiting(event) {
        if (event.run_id !== runId) return;
        var banner = document.getElementById('waiting-banner');
        var msg = document.getElementById('waiting-message');
        var btn = document.getElementById('resume-btn');
        if (banner) banner.classList.remove('hidden');
        if (msg) msg.textContent = event.message;
        if (btn) btn.classList.remove('hidden');
    }

    function handleResumed(event) {
        if (event.run_id !== runId) return;
        var banner = document.getElementById('waiting-banner');
        if (banner) banner.classList.add('hidden');
    }

    // Expose for the Resume button onclick
    window.resumeWorkflow = function () {
        if (!runId) return;
        fetch('/api/workflows/' + runId + '/resume', {method: 'POST'});
        var btn = document.getElementById('resume-btn');
        if (btn) btn.classList.add('hidden');
    };

    // Clean up on page unload to prevent reconnect attempts
    window.addEventListener('beforeunload', function () {
        intentionalClose = true;
        if (reconnectTimer) {
            clearTimeout(reconnectTimer);
            reconnectTimer = null;
        }
        if (socket) {
            socket.close();
        }
    });

    initElapsedTimer();
    connect();
})();
