"""agent-trace: strace for AI agents."""

__version__ = "0.3.0"
