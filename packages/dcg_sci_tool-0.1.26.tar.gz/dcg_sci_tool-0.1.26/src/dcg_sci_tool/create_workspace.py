import shutil
from pathlib import Path


def create_workspace(dir_name, required_files=None):
    """
    创建工作目录并复制必要文件
    Args:
        dir_name (str): 工作目录名称
        required_files (list, optional): 必要文件列表。默认值为空列表。
    
    """
    if required_files is None:
        required_files = []
    
    workspace = Path(dir_name)
    workspace.mkdir(exist_ok=True)
    print(f"创建/进入工作目录: {workspace}")
    
    # 复制必要文件
    for file in required_files:
        src = Path(file)
        if src.exists():
            shutil.copy2(src, workspace)
            print(f"  复制: {file}")
        else:
            print(f"  警告: 文件不存在 {file}")
    
    return workspace