def find_elements_exclusively_frames(filename:str,allowed_elements={'Pd', 'O', 'C'}):
    """
    找出.xyz轨迹中只含指定元素的帧

    Args:
        filename (str): XYZ文件路径
        allowed_elements (set): 允许的元素集合，默认为{'Pd', 'O', 'C'}
    Returns:
        target_frames (list): 只含指定元素的帧索引列表
    """
    target_frames = []
    
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    i = 0
    frame_idx = 0
    
    while i < len(lines):
        # 读取原子数
        if not lines[i].strip():
            i += 1
            continue
            
        try:
            natoms = int(lines[i].strip())
        except:
            i += 1
            continue
        
        # 检查该帧元素
        elements = set()
        for j in range(2, 2 + natoms):  # 跳过原子数和注释行
            if i + j < len(lines):
                parts = lines[i + j].strip().split()
                if parts:
                    elements.add(parts[0])
        
        # 判断是否只含指定元素
        if elements == set(allowed_elements):
            target_frames.append(frame_idx)
        
        i += 2 + natoms
        frame_idx += 1
    
    return target_frames
