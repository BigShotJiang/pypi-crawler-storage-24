from ase.io import read
from ase.io.lammpsdata import write_lammps_data

def traj2iniData(traj_file: str, specorder=['C','O','Pd','Au'], start_frame=0, end_frame=None):
    """
    将轨迹文件转换为LAMMPS ini data文件：0.data, 1.data, 2.data, ...
    
    Args:
        traj_file (str): 轨迹文件路径
        specorder (list): 元素顺序列表，元素会按在表格中的顺序分别编号为1，2，3...
        start_frame (int): 起始帧索引 (默认0)
        end_frame (int): 结束帧索引 (默认None表示最后一帧)，-N表示倒数第N帧
    """
    # 读取所有结构
    structs = read(traj_file, ':')
    
    # 获取总帧数
    total_frames = len(structs)
    
    # 设置合适的end_frame默认值
    if end_frame is None:
        end_frame = total_frames  # 最后一帧的索引+1
    elif end_frame < 0:
        # 支持负数索引，如-1表示最后一帧
        end_frame = total_frames + end_frame + 1
    
    # 确保索引在有效范围内
    start_frame = max(0, min(start_frame, total_frames-1))
    end_frame = max(start_frame+1, min(end_frame, total_frames))
    
    print(f"处理帧: {start_frame} 到 {end_frame-1} (共{total_frames}帧)")
    
    # 处理每一帧
    for i in range(start_frame, end_frame):
        write_lammps_data(f'{i}.data', structs[i], specorder=specorder)