import numpy as np
import os

def read_lammps_data(file_path):
    """读取LAMMPS data文件，提取原子坐标、元素信息、质量信息和晶胞参数"""
    # 使用字典列表存储每个原子的完整信息
    atoms_data = []
    
    # 晶胞参数
    xlo, xhi = 0.0, 0.0
    ylo, yhi = 0.0, 0.0
    zlo, zhi = 0.0, 0.0
    
    # 质量到元素的映射
    mass_to_element = {
        1.008: 'H', 4.0026: 'He', 6.94: 'Li', 9.0122: 'Be', 10.81: 'B',
        12.01: 'C', 14.007: 'N', 16: 'O', 18.998: 'F', 20.18: 'Ne',
        22.99: 'Na', 24.305: 'Mg', 26.982: 'Al', 28.085: 'Si', 30.974: 'P',
        32.06: 'S', 35.45: 'Cl', 39.95: 'Ar', 39.098: 'K', 40.078: 'Ca',
        47.867: 'Ti', 50.942: 'V', 51.996: 'Cr', 54.938: 'Mn', 55.845: 'Fe',
        58.933: 'Co', 58.693: 'Ni', 63.546: 'Cu', 65.38: 'Zn', 69.723: 'Ga',
        72.63: 'Ge', 74.922: 'As', 78.971: 'Se', 79.904: 'Br', 83.798: 'Kr',
        85.468: 'Rb', 87.62: 'Sr', 88.906: 'Y', 91.224: 'Zr', 92.906: 'Nb',
        95.95: 'Mo', 98.0: 'Tc', 101.07: 'Ru', 102.91: 'Rh', 106.42: 'Pd',
        107.87: 'Ag', 112.41: 'Cd', 114.82: 'In', 118.71: 'Sn', 121.76: 'Sb',
        127.6: 'Te', 126.9: 'I', 131.29: 'Xe', 132.91: 'Cs', 137.33: 'Ba',
        138.91: 'La', 140.12: 'Ce', 140.91: 'Pr', 144.24: 'Nd', 145.0: 'Pm',
        150.36: 'Sm', 151.96: 'Eu', 157.25: 'Gd', 158.93: 'Tb', 162.5: 'Dy',
        164.93: 'Ho', 167.26: 'Er', 168.93: 'Tm', 173.05: 'Yb', 174.97: 'Lu',
        178.49: 'Hf', 180.95: 'Ta', 183.84: 'W', 186.21: 'Re', 190.23: 'Os',
        192.22: 'Ir', 195.08: 'Pt', 196.97: 'Au', 200.59: 'Hg', 204.38: 'Tl',
        207.2: 'Pb', 208.98: 'Bi', 209.0: 'Po', 210.0: 'At', 222.0: 'Rn'
    }
    
    # 读取文件
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    # 读取晶胞参数
    for line in lines:
        if 'xlo xhi' in line:
            parts = line.split()
            if len(parts) >= 4:
                xlo = float(parts[0])
                xhi = float(parts[1])
        elif 'ylo yhi' in line:
            parts = line.split()
            if len(parts) >= 4:
                ylo = float(parts[0])
                yhi = float(parts[1])
        elif 'zlo zhi' in line:
            parts = line.split()
            if len(parts) >= 4:
                zlo = float(parts[0])
                zhi = float(parts[1])
    
    # 读取质量信息
    mass_section = False
    type_to_mass = {}
    
    for i, line in enumerate(lines):
        if "Masses" in line:
            mass_section = True
            continue
        if mass_section and line.strip() and not line.startswith("#"):
            if line.strip().startswith("Atoms"):
                break
            try:
                data = line.split()
                if len(data) >= 2:
                    atom_type = int(data[0])
                    mass = float(data[1])
                    type_to_mass[atom_type] = mass
            except ValueError:
                continue
    
    # 读取原子信息
    atoms_section = False
    for line in lines:
        if "Atoms" in line:
            atoms_section = True
            continue
        if atoms_section and line.strip() and not line.startswith("#"):
            if len(line.split()) >= 8:  # 确保有足够的数据列
                data = line.split()
                try:
                    atom_id = int(data[0])
                    element_type = int(data[1])
                    x = float(data[2])
                    y = float(data[3])
                    z = float(data[4])
                    # 忽略后面的速度数据
                    
                    # 获取质量并确定元素
                    mass = type_to_mass.get(element_type, 0)
                    # 找到最接近的质量对应的元素
                    element_symbol = None
                    min_diff = float('inf')
                    
                    for mass_val, elem in mass_to_element.items():
                        diff = abs(mass - mass_val)
                        if diff < min_diff:
                            min_diff = diff
                            element_symbol = elem
                    
                    if element_symbol is None:
                        element_symbol = f"E{element_type}"
                    
                    # 存储每个原子的完整信息到一个字典中
                    atom_info = {
                        'atom_id': atom_id,
                        'element_symbol': element_symbol,
                        'mass': mass,
                        'atom_type': element_type,
                        'x': x,
                        'y': y,
                        'z': z
                    }
                    
                    atoms_data.append(atom_info)
                except ValueError:
                    continue
    
    # 按照 atom_id 从小到大排序
    atoms_data.sort(key=lambda atom: atom['atom_id'])
    
    # 提取排序后的各个信息列表，用于向后兼容
    atoms = [atom['atom_id'] for atom in atoms_data]
    elements = [atom['element_symbol'] for atom in atoms_data]
    masses = [atom['mass'] for atom in atoms_data]
    atom_types = [atom['atom_type'] for atom in atoms_data]
    x_coords = [atom['x'] for atom in atoms_data]
    y_coords = [atom['y'] for atom in atoms_data]
    z_coords = [atom['z'] for atom in atoms_data]
    
    return atoms, elements, masses, atom_types, x_coords, y_coords, z_coords, xlo, xhi, ylo, yhi, zlo, zhi

def create_extxyz(atoms, elements, masses, atom_types, x_coords, y_coords, z_coords, 
                  xlo, xhi, ylo, yhi, zlo, zhi, output_file="structure.extxyz"):
    """创建.extxyz格式文件"""
    
    num_atoms = len(atoms)
    
    with open(output_file, 'w') as f:
        # 第一行：原子总数
        f.write(f"{num_atoms}\n")
        
        # 第二行：元数据和晶胞信息 (使用key=value格式)
        # 计算晶胞向量
        a = xhi - xlo
        b = yhi - ylo
        c = zhi - zlo
        
        # 写入晶胞信息和属性
        f.write(f'Lattice="{a:.6f} 0.0 0.0 0.0 {b:.6f} 0.0 0.0 0.0 {c:.6f}" ')
        f.write(f'Properties=species:S:1:pos:R:3:mass:R:1:type:I:1 ')
        f.write(f'pbc="T T T"\n')
        
        # 写入每个原子的信息（此时atoms列表已按atom_id排序）
        for i in range(num_atoms):
            # 格式: 元素符号 x y z 质量 原子类型
            f.write(f"{elements[i]:<4} ")
            f.write(f"{x_coords[i]:12.6f} {y_coords[i]:12.6f} {z_coords[i]:12.6f} ")
            f.write(f"{masses[i]:8.4f} {atom_types[i]:3d}\n")

def resultData2extxyz(input_file: str, output_file = "structure.xyz"):
    """
    
    将lammps的.data格式的文件转化为.extxyz格式的文件，同时保持原子排列顺序不变

    注意：
    
    只能处理含有元素信息的result.data文件， 无法处理不含元素信息的ini.data。

    元素原子量无须严格和代码内置的 原子量-元素符号 列表中对应原子量匹配，脚本会寻找最接近原子量的元素

    Args:

        input_file (str): 要处理的lammps的data文件的地址

        output_file (str): 转化后的.xyz文件名称（默认：structure.xyz）

    """
    
    # 读取数据
    atoms, elements, masses, atom_types, x_coords, y_coords, z_coords, xlo, xhi, ylo, yhi, zlo, zhi = read_lammps_data(input_file)
    
    print(f"读取到 {len(atoms)} 个原子")
    print(f"元素类型: {sorted(set(elements))}")
    if masses:
        print(f"质量范围: {min(masses):.3f} - {max(masses):.3f}")
    print(f"晶胞参数: x={xhi-xlo:.3f} Å, y={yhi-ylo:.3f} Å, z={zhi-zlo:.3f} Å")
    
    # 验证原子是否已按ID排序
    if atoms:
        is_sorted = all(atoms[i] < atoms[i+1] for i in range(len(atoms)-1))
        if is_sorted:
            print("原子已按ID排序（从小到大）")
        else:
            print("警告：原子ID顺序异常")
    
    # 创建.extxyz文件
    create_extxyz(atoms, elements, masses, atom_types, x_coords, y_coords, z_coords, 
                  xlo, xhi, ylo, yhi, zlo, zhi, output_file)
    print(f".extxyz文件已生成: {output_file}")