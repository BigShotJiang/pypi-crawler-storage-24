
import os
import subprocess
import time
from pathlib import Path


def get_optimal_np():
    """获取最优的MPI进程数"""
    # 优先级1: 环境变量NP
    if 'NP' in os.environ:
        return int(os.environ['NP'])
    
    # 优先级2: LSF分配的核心数
    if 'LSB_DJOB_NUMPROC' in os.environ:
        return int(os.environ['LSB_DJOB_NUMPROC'])
    # 默认值
    return 40


def get_lmps_exec_path():
    """获取LAMMPS可执行文件路径"""
    # 优先级1: 环境变量EXEC
    if 'LAMMPS_EXEC' in os.environ:
        return os.environ['LAMMPS_EXEC']
    else:
        print('环境变量中无LAMMPS_EXEC')
        return None


def mpirun_lammps(np=None, exec_path=None, input_file="in.lammps_neb", partition=None):
    """
    通过python调用mpi命令，并行执行lammps

    注意：
    
    需要事先在LSF环境中通过export命令设置环境变量NP（并行核数）和LAMMPS_EXEC（Lammps可执行文件地址）
    
    在LSF中运行: python -u run_lmps.py > out.log 2>&1，保证python执行结果能够实时输出

    Args:
        np (int): 并行调用的CPU数量（默认环境变量中NP的值）

        exec_path (str): lammps可执行文件的路径（默认环境变量中LAMMPS_EXEC的值）

        input_file (str): lammps的in文件名

        partition (str): lammps的-partition选项的参数
        
    
    
    """
    
    # 确定MPI进程数
    if np is None:
        np = get_optimal_np()
    
    # 确定可执行文件路径
    if exec_path is None:
        exec_path = get_lmps_exec_path()
    
    
    print(f"LSF作业ID: {os.environ.get('LSB_JOBID', 'N/A')}")
    print(f"使用的MPI进程数: {np}")
    print(f"LAMMPS可执行文件: {exec_path}")
    print(f"输入文件: {input_file}")
    
    # 检查文件是否存在
    if not Path(input_file).exists():
        print(f"错误: 输入文件 '{input_file}' 不存在")
        return False
    
    if not Path(exec_path).exists():
        print(f"错误: 可执行文件 '{exec_path}' 不存在")
        return False
    
    if not os.access(exec_path, os.X_OK):
        print(f"错误: 可执行文件 '{exec_path}' 没有执行权限")
        return False
    
    # 构建命令
    # 主要修改点：仅当partition参数不为None时，才在命令中包含-partition选项
    cmd = ["mpirun", "-np", str(np), exec_path]
    if partition is not None:
        cmd.extend(["-partition", partition])
    cmd.extend(["-i", input_file])
    
    # 设置输出文件
    log_file = f"{os.environ.get('LSB_JOBID', 'output')}.log"
    
    print(f"执行命令: {' '.join(cmd)}")
    print(f"输出日志: {log_file}")
    print(f"开始时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("-" * 50)
    
    # 记录开始时间
    start_time = time.time()
    
    print("开始执行lammps...")
    try:
        with open(log_file, 'w') as f:
            # 运行命令
            result = subprocess.run(
                cmd,
                stdout=f,
                stderr=subprocess.STDOUT,
                text=True,
                check=True
            )
        
        # 计算运行时间
        elapsed_time = time.time() - start_time
        
        print(f"\n{'='*50}")
        print(f"执行结束!")
        print(f"总运行时间: {elapsed_time:.2f} 秒 ({elapsed_time/60:.2f} 分钟)")
        print(f"结束时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"日志文件: {log_file}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"\n错误: 命令执行失败，返回码: {e.returncode}")
        print(f"请查看日志文件: {log_file}")
        return False
    
    except FileNotFoundError as e:
        print(f"\n错误: 命令未找到 - {e}")
        return False
    
    except Exception as e:
        print(f"\n未知错误: {e}")
        return False