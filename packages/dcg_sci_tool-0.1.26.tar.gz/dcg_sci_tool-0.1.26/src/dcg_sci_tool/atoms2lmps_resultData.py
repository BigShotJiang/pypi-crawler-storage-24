from ase import Atoms

def atoms2lmps_resultData(atoms: Atoms, output_file: str = "FS.data"):
    """
    将ASE Atoms对象转化为lammps跑neb时的FS.data格式的文件
    
    格式：
    第一行：原子数
    后续行：原子序号(从1开始) X Y Z坐标

    Args:

        atoms (Atoms): 要处理的Atoms对象

        output_file (str): 输出的.data文件名，默认值为FS.data

    """
    print(f"开始将输入atoms对象转化为lammps跑neb时的FS.data文件...")
    with open(output_file, 'w') as f:
        # 第一行：原子数
        f.write(f"{len(atoms)}\n")
        
        # 原子信息
        for i, (x, y, z) in enumerate(atoms.positions, 1):
            f.write(f"{i} {x:.6f} {y:.6f} {z:.6f}\n")
    print("转化结束")
