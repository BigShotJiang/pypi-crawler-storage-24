
from dcg_sci_tool import *
from ovito.data import *
from ovito.io import import_file

def pre_del_gases(input_file: str, old_indexes_to_transfer: list):
    """
    将轨迹文件第一帧结构中，PdAu团簇上游离的气态分子删去，输出新的Atoms对象以及新的原子索引

    Args:
        input_file (str): 要处理的轨迹文件地址
        old_indexes_to_transfer (list): 要获得新索引列表的旧索引的列表

    Returns:
        tuple: 处理后的结果

            filtered_atoms (Atoms): 处理后的Atoms对象
        
            tranfered_indexes (list): 转化后的原子索引列表

    """

    
    pipeline = import_file(input_file)
    type_names_order = extract_atom_types(input_file)
    frame = 0
    data = pipeline.compute(frame)

    # 获取要删除的原子的索引列表
    list_for_deletion = detect_gas_molecules_for_deletion(data, type_names_order)

    # 获取要保留的原子的索引列表
    keep_indexes=[]
    for i in range(data.particles.count):
        if i not in list_for_deletion:
            keep_indexes.append(i)


    # 处理并输出新结构
    filtered_atoms, tranfered_indexes = create_filtered_structure(data, type_names_order, keep_indexes, old_indexes_to_transfer)

    return filtered_atoms, tranfered_indexes