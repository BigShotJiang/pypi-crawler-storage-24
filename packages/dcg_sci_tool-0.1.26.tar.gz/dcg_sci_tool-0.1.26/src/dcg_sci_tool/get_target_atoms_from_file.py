import json
import re

def get_target_atoms_from_file(filename="python.log"):
    """
    通过读取python.log日志文件中获得目标原子列表
    
    Args:
        filename (str): 日志文件名，默认 "python.log"
        
    Returns:
        atom_list (list): 包含所有提取到的原子列表的列表
    """
    atom_list = []
    
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            for line in file:
                # 匹配格式: 目标原子列表: [52, 100] 或类似格式
                match = re.search(r'目标原子列表:\s*(\[[^\]]+\])', line)
                if match:
                    list_str = match.group(1)
                    
                    # 使用json（如果格式严格是JSON格式）
                    try:
                        # 将字符串形式的数组"[a,b,...]"转化为真的数组
                        atom_list = json.loads(list_str) 

                    except json.JSONDecodeError:
                        pass
    except FileNotFoundError:
        print(f"错误: 文件 '{filename}' 不存在")
    except Exception as e:
        print(f"读取文件时发生错误: {e}")
    
    return atom_list