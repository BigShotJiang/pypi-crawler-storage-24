import os
from pathlib import Path
from dcg_sci_tool.reaction.neb_post_process import *

def run_initial_state_minimization():
    """
    在自动截取MD轨迹的算能垒的自动化流程中，运行初态结构优化
    包括创建1.IS_min目录，复制文件到该目录，运行LAMMPS最小化，转换结果为可读格式。
    返回优化后的结构文件路径
    Returns:
        Path: 优化后的结构文件路径
    """
    print("\n" + "=" * 60)
    print("步骤 1: 初态结构优化")
    print("=" * 60)
    
    # 准备工作目录
    is_dir = create_workspace("1.IS_min", ["nep.txt", "in.lammps_min", "preprocessed.xyz"])
    
    # 保存当前目录
    original_dir = Path.cwd()
    
    try:
        os.chdir(is_dir)
        
        # 转换轨迹为初始数据
        traj2iniData(
            traj_file="preprocessed.xyz",
            specorder=['C', 'O', 'Pd', 'Au'],
            start_frame=0,
            end_frame=0
        )
        
        # 重命名数据文件
        data_file = Path("0.data")
        if data_file.exists():
            data_file.rename("ini.data")
            print("已将 0.data 重命名为 ini.data")
        
        # 运行 LAMMPS 最小化
        print("运行 LAMMPS 结构优化...")
        mpirun_lammps(input_file="in.lammps_min")
        
        # 转换结果为可读格式
        resultData2extxyz(input_file="result.data", output_file="minimized_IS.xyz")
        print("优化完成，结果保存为: minimized_IS.xyz")
        
    finally:
        os.chdir(original_dir)
    
    return original_dir / is_dir / "minimized_IS.xyz"