from dcg_sci_tool.reaction.neb_post_process import *
from ase.io import write

def construct_final_state(minimized_is_path, target_atom_list):
    """
    在自动截取MD轨迹的算能垒的自动化流程中，构建末态结构
    Args:
        minimized_is_path (Path): 最小化后的结构文件路径
        target_atom_list (list): 目标原子列表
    Returns:
        tuple: 包含末态结构对象和文件路径的元组
        atoms_fs (ASE atoms object): 末态结构对象
        fs_path (Path): 末态结构文件路径
    """
    print("\n" + "=" * 60)
    print("步骤 2: 构建末态结构")
    print("=" * 60)
    
    atoms_fs = construct_CO2_formation_FS(str(minimized_is_path), target_atom_list)
    fs_path = minimized_is_path.parent / "constructed_FS.xyz"
    write(str(fs_path), format="extxyz", images=atoms_fs)
    
    print(f"末态结构已保存到: {fs_path}")
    return atoms_fs, fs_path