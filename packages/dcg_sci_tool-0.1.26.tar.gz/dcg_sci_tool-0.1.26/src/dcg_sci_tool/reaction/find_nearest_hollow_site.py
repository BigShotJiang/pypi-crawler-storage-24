import numpy as np
from ovito.data import DataCollection
from itertools import combinations
from dcg_sci_tool import *
from pyparsing import Dict

def find_nearest_hollow_site(data: DataCollection, type_names_order: list, c_index: int, o_index: int) -> Dict:
    """
    找到距离C-O中点最近的hollow位点

    Args:
        data (DataCollection): 结构的ovito数据集合
        
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号

        c_index (int): 目标C原子索引

        o_index (int): 目标O原子索引

    Returns:

        nearest_hollow_indexes (list): 最近的Hollow位点对应的金属原子序号列表（长度为3）

        nearby_hollow_sites_count (int): C-O中点附近合理的Hollow位点数量

    """
    max_triangle_side = 4.0  # 定义三角形边长的最大值，单位为Å

    particles = data.particles
    
    if particles is None:
        return {'error': '无法读取粒子数据'}
    
    # 获取原子信息
    positions = particles.positions[...]
    types = particles.particle_types[...]

    symbols = np.array([type_names_order[t-1] for t in types])
    num_atoms = particles.count
    
    # 验证输入原子序号
    if c_index >= num_atoms:
        return {'error': f'C原子序号 {c_index} 超出范围 (总原子数: {num_atoms})'}
    if o_index >= num_atoms:
        return {'error': f'O原子序号 {o_index} 超出范围 (总原子数: {num_atoms})'}
    if symbols[c_index] != 'C':
        return {'error': f'原子 {c_index} 不是C原子 (实际类型: {symbols[c_index]})'}
    if symbols[o_index] != 'O':
        return {'error': f'原子 {o_index} 不是O原子 (实际类型: {symbols[o_index]})'}
    
    # 计算C-O连线中点坐标
    c_pos = positions[c_index]
    o_pos = positions[o_index]
    midpoint = (c_pos + o_pos) / 2.0
    co_distance = np.linalg.norm(c_pos - o_pos)
    
    print(f"C-O距离: {co_distance:.3f} Å")
    print(f"C-O中点坐标: ({midpoint[0]:.3f}, {midpoint[1]:.3f}, {midpoint[2]:.3f})")
    
    # 获取与C/O成键的金属原子
    bonded_metal_atoms = get_OC_bonded_metal_atoms(data, type_names_order, c_index, o_index)
    print(f"与C/O成键的金属原子数量: {len(bonded_metal_atoms)}")
    
  
    if len(bonded_metal_atoms) < 3:
        return {'error': '与C/O成键的表面金属原子数量不足，无法形成Hollow位点'}
    
    # 寻找最近的Hollow位点
    nearest_hollow_indexes = []
    min_distance = float('inf')
    nearby_hollow_sites_count = 0
    
    # 生成候选三角形组合
    geometric_triangles = list(combinations(bonded_metal_atoms, 3))
    
    for triangle in geometric_triangles:
        idx_a, idx_b, idx_c = triangle
        
        # 计算三角形边长
        pos_a, pos_b, pos_c = positions[idx_a], positions[idx_b], positions[idx_c]
        side_ab = np.linalg.norm(pos_a - pos_b)
        side_bc = np.linalg.norm(pos_b - pos_c)
        side_ca = np.linalg.norm(pos_c - pos_a)
        
        # 检查三角形边长是否合理
        if side_ab > max_triangle_side or side_bc > max_triangle_side or side_ca > max_triangle_side:
            continue
        
        # 计算三角形中心（Hollow位点）
        center = (pos_a + pos_b + pos_c) / 3.0
        

        nearby_hollow_sites_count += 1
        
        # 计算到C-O中点的距离
        distance_to_midpoint = np.linalg.norm(center - midpoint)
        
        # 更新最近Hollow位点
        if distance_to_midpoint < min_distance:
            min_distance = distance_to_midpoint
            nearest_hollow_indexes = [idx_a, idx_b, idx_c]
    
    if nearest_hollow_indexes is None:
        return {'error': '未找到有效的Hollow位点'}

    
    return nearest_hollow_indexes, nearby_hollow_sites_count