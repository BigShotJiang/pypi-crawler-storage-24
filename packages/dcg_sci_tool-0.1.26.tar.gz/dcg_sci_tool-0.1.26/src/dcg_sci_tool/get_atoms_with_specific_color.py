from dcg_sci_tool import get_xyz_prop_columns


def get_atoms_with_specific_color(xyz_file: str, target_color=[0.0, 1.0, 1.0]):
    """
    从.xyz文件中找到color属性为特定值的原子序号
    
    Args:

        xyz_file (str): 输入的.xyz文件路径

        target_color (list): 目标颜色值，默认[0.0, 1.0, 1.0]
    
    Returns:

        list: 颜色为target_color的原子序号列表
        
    """

    # 1. 获取color属性所在的列序号
    color_columns = get_xyz_prop_columns(xyz_file, "color")
    
    if not color_columns:
        raise ValueError(f"在文件 {xyz_file} 中未找到color属性")
    
    print(f"color属性在原子行中的列序号: {color_columns}")
    
    # 检查color属性是否是3维向量（RGB颜色）
    if len(color_columns) != 3:
        raise ValueError(f"color属性的维度不是3，实际维度: {len(color_columns)}")
    
    # 2. 读取文件并查找匹配颜色的原子
    matching_atoms = []
    
    with open(xyz_file, 'r', encoding='utf-8') as f:
        # 读取第一行：原子数
        first_line = f.readline().strip()
        if not first_line:
            return matching_atoms
        
        n_atoms = int(first_line)
        
        # 跳过注释行
        f.readline()
        
        # 读取每个原子行
        for atom_idx in range(n_atoms):
            line = f.readline()
            if not line:
                break
            
            parts = line.strip().split()
            if len(parts) <= max(color_columns):
                continue
            
            # 提取color属性的三个分量
            try:
                r = float(parts[color_columns[0]])
                g = float(parts[color_columns[1]])
                b = float(parts[color_columns[2]])
                
                # 检查是否匹配目标颜色
                if (abs(r - target_color[0]) < 1e-6 and
                    abs(g - target_color[1]) < 1e-6 and
                    abs(b - target_color[2]) < 1e-6):
                    matching_atoms.append(atom_idx)
                    
            except (ValueError, IndexError) as e:
                print(f"警告: 解析原子 {atom_idx} 的color属性时出错: {e}")
                continue
    
    print(f"找到 {len(matching_atoms)} 个颜色为 {target_color} 的原子")
    return matching_atoms