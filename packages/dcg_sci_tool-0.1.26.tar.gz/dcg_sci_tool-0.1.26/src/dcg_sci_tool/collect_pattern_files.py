import os
import re
import shutil


def collect_pattern_files(pattern: str, target_dir: str):
    """
    将当下目录及子目录下所有满足特定正则表达式的文件复制到创建的新文件夹中

    Args:
        pattern (str): 正则表达式字符串

        target_dir (str): 目标新文件夹
    
    """
    # 创建正则表达式模式
    pattern = re.compile(pattern)
    # 创建目标文件夹
    os.makedirs(target_dir, exist_ok=True)
    # 遍历当前目录及所有子目录
    copied_count = 0
    for root, dirs, files in os.walk("."):
        # 关键修改：从dirs列表中移除目标文件夹，使其不会被遍历
        if target_dir in dirs:
            dirs.remove(target_dir)

        for file in files:
            if pattern.match(file):
                source_path = os.path.join(root, file)
                target_path = os.path.join(target_dir, file)

                # 处理同名文件
                counter = 1
                original_target = target_path
                while os.path.exists(target_path):
                    name, ext = os.path.splitext(file)
                    target_path = os.path.join(target_dir, f"{name}_{counter}{ext}")
                    counter += 1

                try:
                    shutil.copy2(source_path, target_path)
                    print(f"已复制: {source_path} -> {target_path}")
                    copied_count += 1
                except Exception as e:
                    print(f"复制失败 {source_path}: {e}")

    print(f"\n完成！共复制了 {copied_count} 个文件到 '{target_dir}' 文件夹")