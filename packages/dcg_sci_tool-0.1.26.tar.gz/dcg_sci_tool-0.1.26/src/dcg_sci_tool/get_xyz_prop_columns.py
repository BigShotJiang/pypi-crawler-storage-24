import re


def get_xyz_prop_columns(input_file:str,property:str):
    """
    获取.extxyz格式文件中某一个属性对应于原子数据的列号

    Args:
        input_file (str): 输入的.xyz文件
        propertyc(str): 要查找的属性名称

    Returns:
        target_column_indexes (list): 目标属性对应的原子数据列号所在的列表

    """


    with open(input_file, 'r', encoding='utf-8') as f:
        # 跳过第一行
        n_atoms = int(f.readline().strip())

        second_string = f.readline().strip() 
        properties_pattern = r'Properties=[^"]+'
        match = re.search(properties_pattern, second_string)
        if match:
            properties_str = match.group(0)
        else:
            print("无注释行！")
            return None
        
        prop_parts = properties_str[11:].split(':')


        # 解析properties字段
        current_atomistic_data_column = 0
        current_prop_part = 0

        target_column_indexes = []

        while current_prop_part < len(prop_parts):
            if current_prop_part + 3 <= len(prop_parts):
                prop_name = prop_parts[current_prop_part]  # 属性名
                prop_type = prop_parts[current_prop_part+1]  # 属性类型
                try:
                    prop_size = int(prop_parts[current_prop_part+2])  # 属性维度
                except ValueError:
                    break
                
                # 如果是目标属性，返回当前列号
                if prop_name == f"{property}":
                    for i in range(prop_size):
                        target_column_indexes.append(current_atomistic_data_column + i)
                    break
                # 移动到下一个属性
                current_prop_part += 3
                current_atomistic_data_column += prop_size
            else:
                print("注释行不完整")
                break
    return target_column_indexes