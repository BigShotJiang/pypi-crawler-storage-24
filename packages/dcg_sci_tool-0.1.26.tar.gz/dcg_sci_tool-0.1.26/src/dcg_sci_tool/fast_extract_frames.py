def fast_extract_frames(input_file, output_file, start_frame=0, end_frame=None):
    """
    提取.xyz轨迹文件中指定帧区间的轨迹到新文件

    Args:
        input_file (str): 输入轨迹文件路径
        output_file (str): 输出轨迹文件路径
        start_frame (int): 起始帧索引（从0开始）
        end_frame (int): 结束帧索引（包含），None表示到文件末尾
    """
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        frame_count = 0
        while True:
            # 读取帧头（原子数）
            line = infile.readline()
            if not line:  # 文件结束
                break
                
            natoms = int(line.strip())
            comment = infile.readline()  # 读取注释行
            atoms = [infile.readline() for _ in range(natoms)]  # 读取原子数据
            
            # 检查是否在指定帧范围内
            if (end_frame is None or frame_count <= end_frame) and frame_count >= start_frame:
                outfile.write(f"{natoms}\n")
                outfile.write(comment)
                outfile.writelines(atoms)
            
            frame_count += 1
            if end_frame is not None and frame_count > end_frame:
                break  # 提前终止读取
