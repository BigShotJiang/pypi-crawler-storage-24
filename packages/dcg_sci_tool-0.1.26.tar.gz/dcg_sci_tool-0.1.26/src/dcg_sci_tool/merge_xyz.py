def merge_xyz(file_list, output_file="merged.xyz"):
    """合并多个xyz轨迹文件"""
    
    with open(output_file, 'w') as out_f:
        for i, filename in enumerate(file_list):
            with open(filename, 'r') as in_f:
                content = in_f.read().rstrip()  # 移除末尾空白
                
                if i > 0:  # 不是第一个文件，添加换行符
                    out_f.write('\n')
                
                out_f.write(content)
    
    print(f"成功合并 {len(file_list)} 个文件到 {output_file}")

