def add_config_to_xyz(input_file, output_file, Config_type=""):
    """
    在.extxyz格式文件的header中添加Config_type，可用于NepTrainKit中的结构点部分选中。
    输出的.xyz文件中，新Config_type属性的键值对已添加
    
    Args:

        input_file (str): 输入的.xyz轨迹文件

        output_file (str): 输出的.xyz轨迹文件

        Config_type (str): 要添加的Config_type值

    """
    
    with open(input_file) as f:
        lines = [line.rstrip() for line in f]
    
    out = []
    i = 0
    frames = 0
    
    while i < len(lines):
        if not lines[i]:
            i += 1
            continue
            
        # 原子数
        try:
            n_atoms = int(lines[i])
        except:
            break
        
        out.append(str(n_atoms))
        
        # header行 - 添加Config_type属性
        if i + 1 < len(lines):
            header = lines[i + 1]
            if header:
                out.append(f"{header} Config_type=\"{Config_type}\"")
            else:
                out.append(f"Config_type=\"{Config_type}\"")
        
        # 原子行 - 原样输出，不添加额外内容
        start = i + 2
        end = min(start + n_atoms, len(lines))
        
        for j in range(start, end):
            out.append(lines[j])  # 保持原子行不变
        
        frames += 1
        i = end
        
        # 保持原文件格式
        if i < len(lines) and not lines[i]:
            out.append("")
            i += 1
    
    with open(output_file, 'w') as f:
        f.write('\n'.join(out))