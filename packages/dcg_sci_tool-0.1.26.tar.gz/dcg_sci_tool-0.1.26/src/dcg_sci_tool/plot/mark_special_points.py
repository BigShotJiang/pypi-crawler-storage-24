import matplotlib.pyplot as plt

def mark_special_points(point_list=None):
    """
    在散点图上添加特定点并标注

    Args:
        point_list (list): 包含点坐标和标签的字典列表，格式为 [{'coords': (x, y), 'label': '点标签'}, ...]
    """
    # 获取当前坐标轴范围
    x_lim = plt.xlim()  # 保存当前x轴范围
    y_lim = plt.ylim()  # 保存当前y轴范围


    for point_dict in point_list:
        x_val, y_val = point_dict['coords']
        plt.scatter(x_val, y_val, c='red', s=30, marker='o', 
                   edgecolor='k', linewidth=0.0)
        # 在点旁边添加文字标注
        plt.text(x_val, y_val, point_dict['label'], fontsize=9, 
                 ha='left', va='bottom')  # 文字在点的左下方

    # 恢复坐标轴范围
    plt.xlim(x_lim)
    plt.ylim(y_lim)