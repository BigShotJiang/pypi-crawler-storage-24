import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import numpy as np
from typing import List, Union, Optional, Dict, Any
import logging

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 定义常量
DEFAULT_COLORS = ['blue', 'red', 'green', 'orange', 'purple', 'brown', 'pink', 'gray', 'olive', 'cyan']
# DEFAULT_COLORS = [
#     '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
#     '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
# ]

DEFAULT_CONFIG = {
    'figure_size': (10, 6),
    'axis_label_fontsize': 18,
    'tick_label_fontsize': 18,
    'line_width': 2,
    'marker_style': 'o',
    'marker_size': 5,
    'scatter_size': 20,
    'grid_visible': True,
    'grid_alpha_light': 0.3,
    'grid_alpha_medium': 0.5,
    'tight_layout': True
}


def plot_basic_graph(
    src_file: str = 'neb_mep.dat',
    x_col: int = 0,
    y_cols: Union[int, List[int]] = 3,
    legend_loc = 'upper right',
    mode: str = 'line',
    x_label: str = 'Indexes',
    y_label: str = 'Potential Energy (eV)',
    output_file: Optional[str] = None,
    colors: Optional[List[str]] = None,
    labels: Optional[List[str]] = None,
    title: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None
) -> plt.Figure:
    """
    绘制基础折线图或散点图
    
    注意：
    - 目前不支持图中的中文字符，请统一使用国际标准的英文
    - 该函数只做前期基础配置，不输出图片，需要额外调用 plt.savefig() 输出图片
    - 此设计方便在此基础上调用 plt 命令进行再加工
    
    Parameters
    ----------
    src_file : str, optional
        源数据文件路径，文件内容为多列数据，默认 'neb_mep.dat'
    x_col : int, optional
        X轴数据列索引，默认 0
    y_cols : Union[int, List[int]], optional
        Y轴数据列索引（单个整数或整数列表），默认 3
    legend_loc : str, optional
        图例的位置，'upper right' 右上角，'upper left' 左上角，

        'lower right' 右下角，'lower left' 左下角。

        默认 'upper right'，
    mode : str, optional
        绘图模式，'line' 为折线图，'scatter' 为散点图，默认 'line'
    x_label : str, optional
        X轴标签，默认 'Indexes'
    y_label : str, optional
        Y轴标签，默认 'Potential Energy (eV)'
    output_file : Optional[str], optional
        输出文件路径，如果为None则不自动保存
    colors : Optional[List[str]], optional
        颜色列表，如果为None则使用默认颜色
    labels : Optional[List[str]], optional
        图例标签列表，如果为None则自动生成
    title : Optional[str], optional
        图表标题
    config : Optional[Dict[str, Any]], optional
        自定义配置字典，覆盖默认配置
        
    Returns
    -------
    plt.Figure
        创建的matplotlib图形对象
        
    Raises
    ------
    FileNotFoundError
        当指定的源文件不存在时
    ValueError
        当参数值不合法时
    IndexError
        当指定的列索引超出数据范围时
        
    Examples
    --------
    >>> # 绘制单条折线
    >>> fig = plot_basic_line_chart('data.dat', x_col=0, y_cols=1)
    >>> plt.savefig('output.png', dpi=300, bbox_inches='tight')
    >>> plt.show()
    
    >>> # 绘制多条散点图
    >>> fig = plot_basic_line_chart('data.dat', 
    ...                             x_col=0, 
    ...                             y_cols=[1, 2, 3],
    ...                             mode='scatter',
    ...                             labels=['Series A', 'Series B', 'Series C'])
    >>> plt.savefig('scatter_plot.png', dpi=300)
    >>> plt.close(fig)
    """
    
    # 合并配置
    plot_config = DEFAULT_CONFIG.copy()
    if config:
        plot_config.update(config)
    
    # 参数验证
    if mode not in ['line', 'scatter']:
        raise ValueError(f"不支持的绘图模式: {mode}，可选值为 'line' 或 'scatter'")
    
    # 确保y_cols是列表
    if isinstance(y_cols, int):
        y_cols = [y_cols]
    
    # 使用默认颜色或传入的颜色
    if colors is None:
        colors = DEFAULT_COLORS
    else:
        # 验证颜色格式
        for i, color in enumerate(colors):
            if not (isinstance(color, str) and (color.startswith('#') or color in plt.colors.cnames)):
                logger.warning(f"颜色 {color} 可能不是有效的matplotlib颜色")
    
    # 确保有足够的颜色
    if len(colors) < len(y_cols):
        colors = colors * (len(y_cols) // len(colors) + 1)
        logger.info(f"颜色列表已扩展以适应 {len(y_cols)} 条曲线")
    
    try:
        # 读取数据文件
        logger.info(f"正在读取数据文件: {src_file}")
        data = pd.read_csv(src_file, header=None, sep=r'\s+|,', engine='python',comment = '#')
        
        if data.empty:
            raise ValueError(f"数据文件 {src_file} 为空")
        
        logger.info(f"数据形状: {data.shape}, 列数: {data.shape[1]}")
        
        # 检查列索引是否有效
        all_cols = [x_col] + y_cols
        max_col = data.shape[1] - 1
        for col in all_cols:
            if col > max_col:
                error_msg = f"列索引 {col} 超出数据范围（最大列索引：{max_col}）"
                logger.error(error_msg)
                raise IndexError(error_msg)
        
        # 提取x轴数据
        x_data = data.iloc[:, x_col]
        
        # 创建图形
        fig, ax = plt.subplots(figsize=plot_config['figure_size'])
        
        # 绘制多条曲线
        line_handles = []
        for i, y_col in enumerate(y_cols):
            y_data = data.iloc[:, y_col]
            
            # 设置标签
            if labels and i < len(labels):
                label = labels[i]
            else:
                label = f'Column {y_col}'
            
            # 根据模式绘图
            if mode == 'line':
                line, = ax.plot(x_data, y_data,
                               marker=plot_config['marker_style'],
                               linestyle='-',
                               linewidth=plot_config['line_width'],
                               color=colors[i % len(colors)],
                               markersize=plot_config['marker_size'],
                               label=label)
            elif mode == 'scatter':
                line = ax.scatter(x_data, y_data,
                                 marker=plot_config['marker_style'],
                                 color=colors[i % len(colors)],
                                 s=plot_config['scatter_size'],
                                 label=label)
            
            line_handles.append(line)
            logger.debug(f"已绘制曲线 {i+1}/{len(y_cols)}: 列 {y_col}, 标签: {label}")
        
        # 设置坐标轴标签
        ax.set_xlabel(x_label, fontsize=plot_config['axis_label_fontsize'])
        ax.set_ylabel(y_label, fontsize=plot_config['axis_label_fontsize'])
        
        # 设置标题
        if title:
            ax.set_title(title, fontsize=plot_config['axis_label_fontsize'] + 2, pad=20)
        
        # 设置刻度字体大小
        ax.tick_params(axis='both', labelsize=plot_config['tick_label_fontsize'])
        
        # 添加图例（如果有多条线）
        if len(y_cols) > 1:
            ax.legend(handles=line_handles, 
                     fontsize=plot_config['axis_label_fontsize'] - 2,
                     loc=legend_loc,
                     framealpha=0.8)
        
        # 设置x轴刻度标记（每隔5个单位显示一个）
        ax.xaxis.set_major_locator(MultipleLocator(5))
        
        # 是否显示网格
        if plot_config['grid_visible']:
            # 在每个数据点位置显示垂直网格线
            for x in x_data:
                ax.axvline(x=x, 
                          color='gray', 
                          linestyle=':', 
                          alpha=plot_config['grid_alpha_light'])
            
            # 在每隔5个单位的位置显示更明显的垂直网格线
            x_min = int(np.floor(x_data.min()))
            x_max = int(np.ceil(x_data.max()))
            for x in range(x_min, x_max + 1, 5):
                ax.axvline(x=x, 
                          color='gray', 
                          linestyle='--', 
                          alpha=plot_config['grid_alpha_medium'])
            
            # 显示水平网格线
            ax.yaxis.grid(True, 
                         which='both', 
                         linestyle='--', 
                         alpha=plot_config['grid_alpha_medium'])
        
        # 自动调整布局
        if plot_config['tight_layout']:
            plt.tight_layout()
        
        # 保存图片（如果指定了输出文件）
        if output_file:
            try:
                plt.savefig(output_file, dpi=300, bbox_inches='tight')
                logger.info(f"图表已保存为: {output_file}")
            except Exception as save_error:
                logger.error(f"保存图片时出错: {str(save_error)}")
                raise
        
        logger.info(f"图表创建成功: 模式={mode}, 曲线数={len(y_cols)}")
        return fig
        
    except FileNotFoundError:
        error_msg = f"错误：找不到文件 '{src_file}'"
        logger.error(error_msg)
        raise FileNotFoundError(error_msg)
    except pd.errors.EmptyDataError:
        error_msg = f"错误：文件 '{src_file}' 为空或格式不正确"
        logger.error(error_msg)
        raise
    except Exception as e:
        error_msg = f"发生错误: {str(e)}"
        logger.error(error_msg)
        raise