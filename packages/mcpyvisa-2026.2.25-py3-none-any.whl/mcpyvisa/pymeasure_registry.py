"""IDN-to-pymeasure driver mapping.

Maps instrument identities (from *IDN? responses) to pymeasure instrument
classes. Uses lazy imports so pymeasure is only loaded when a driver is
actually needed.

The catalog IDs match gpib-catalog's naming convention.
"""

import importlib
import logging
import re

logger = logging.getLogger(__name__)

# Maps catalog ID -> (module_path, class_name)
# These are the 8 instruments in our catalog that have pymeasure drivers.
PYMEASURE_DRIVERS: dict[str, tuple[str, str]] = {
    "hp-33120a": ("pymeasure.instruments.hp", "HP33120A"),
    "hp-34401a": ("pymeasure.instruments.hp", "HP34401A"),
    "hp-3478a": ("pymeasure.instruments.hp", "HP3478A"),
    "hp-8657b": ("pymeasure.instruments.hp", "HP8657B"),
    "agilent-4284a": ("pymeasure.instruments.agilent", "Agilent4284A"),
    "keithley-2000": ("pymeasure.instruments.keithley", "Keithley2000"),
    "keithley-2400": ("pymeasure.instruments.keithley", "Keithley2400"),
    "keithley-6517b": ("pymeasure.instruments.keithley", "Keithley6517B"),
}

# Maps IDN patterns to catalog IDs.
# Each entry: (manufacturer_pattern, model_pattern) -> catalog_id
# Patterns are case-insensitive regexes matched against IDN manufacturer/model.
_IDN_PATTERNS: list[tuple[str, str, str]] = [
    (r"hewlett.packard|hp|agilent", r"33120a", "hp-33120a"),
    (r"hewlett.packard|hp|agilent", r"34401a", "hp-34401a"),
    (r"hewlett.packard|hp", r"3478a", "hp-3478a"),
    (r"hewlett.packard|hp", r"8657b", "hp-8657b"),
    (r"agilent|hp|hewlett.packard", r"4284a", "agilent-4284a"),
    (r"keithley", r"2000\b", "keithley-2000"),
    (r"keithley", r"2400\b", "keithley-2400"),
    (r"keithley", r"6517b?", "keithley-6517b"),
]


def match_idn(raw_idn: str) -> str | None:
    """Match a raw *IDN? response to a catalog ID.

    Parses the comma-separated IDN string and matches manufacturer/model
    patterns. Returns the catalog ID or None if no driver is available.
    """
    parts = [p.strip() for p in raw_idn.split(",")]
    if len(parts) < 2:
        return None

    manufacturer = parts[0]
    model = parts[1]

    for mfr_pattern, model_pattern, catalog_id in _IDN_PATTERNS:
        if re.search(mfr_pattern, manufacturer, re.IGNORECASE) and re.search(
            model_pattern, model, re.IGNORECASE
        ):
            return catalog_id

    return None


def get_driver_class(catalog_id: str):
    """Lazily import and return the pymeasure instrument class.

    Returns the class object, or None if the driver isn't available
    (e.g. pymeasure not installed, or the specific driver module missing).
    """
    entry = PYMEASURE_DRIVERS.get(catalog_id)
    if entry is None:
        return None

    module_path, class_name = entry
    try:
        module = importlib.import_module(module_path)
        return getattr(module, class_name)
    except (ImportError, AttributeError) as e:
        logger.warning(
            "Failed to load pymeasure driver %s.%s: %s",
            module_path,
            class_name,
            e,
        )
        return None


def list_supported() -> dict[str, str]:
    """Return a dict of catalog_id -> pymeasure class name for all supported instruments."""
    return {
        catalog_id: f"{module}.{cls}"
        for catalog_id, (module, cls) in PYMEASURE_DRIVERS.items()
    }
