"""Configuration loading for mcpyvisa.

Config is TOML-based, searched in order:
  1. $MCPYVISA_CONFIG environment variable
  2. ./mcpyvisa.toml (current directory)
  3. ~/.config/mcpyvisa/config.toml

Backends are declared as [[backend]] tables. Each defines a pyvisa backend
type (ar488, pyvisa-py, system) and transport-specific options.

Instrument aliases are declared under [instruments.<alias>] and map friendly
names to VISA resource strings + backend names.
"""

import os
import tomllib
from pathlib import Path

from pydantic import BaseModel, Field, field_validator

from mcpyvisa.models import BackendType


class BackendConfig(BaseModel):
    """Configuration for a single pyvisa backend."""

    name: str = Field(description="Unique backend identifier")
    type: BackendType = Field(description="Backend type: ar488, pyvisa-py, system")

    # AR488 serial transport options
    transport: str | None = Field(
        default=None, description="Transport type for AR488: 'serial' or 'tcp'"
    )
    port: str | None = Field(default=None, description="Serial port path, e.g. /dev/ttyUSB0")
    baudrate: int = Field(default=115200, description="Serial baud rate")

    # AR488 TCP transport options
    host: str | None = Field(default=None, description="TCP host for WiFi AR488 bridge")
    tcp_port: int = Field(default=23, description="TCP port for WiFi AR488 bridge")

    # Behavior
    auto_discover: bool = Field(default=True, description="List resources on connect")
    auto_identify: bool = Field(default=True, description="Send *IDN? to discovered instruments")
    read_timeout_ms: int = Field(default=3000, ge=1, le=32000, description="Read timeout")
    inter_command_delay_ms: int = Field(
        default=10, ge=0, le=1000,
        description="Delay between commands (prevents ESP32 brownout for AR488)",
    )

    # Sim backend
    sim_file: str | None = Field(
        default=None,
        description="Path to pyvisa-sim YAML definition file (sim backend only)",
    )

    @field_validator("name")
    @classmethod
    def name_must_be_slug(cls, v: str) -> str:
        if not v.replace("-", "").replace("_", "").isalnum():
            msg = f"Backend name must be alphanumeric with hyphens/underscores: {v!r}"
            raise ValueError(msg)
        return v


class InstrumentAlias(BaseModel):
    """Maps a friendly name to a VISA resource string and backend."""

    resource: str = Field(description="VISA resource string, e.g. GPIB0::22::INSTR")
    backend: str = Field(description="Name of the backend this instrument is on")


class ServerConfig(BaseModel):
    """Top-level server configuration."""

    log_level: str = Field(default="INFO", description="Logging level")
    auto_discover: bool = Field(default=True, description="Auto-discover instruments on connect")
    auto_identify: bool = Field(default=True, description="Auto-identify discovered instruments")


class AppConfig(BaseModel):
    """Root configuration object."""

    server: ServerConfig = Field(default_factory=ServerConfig)
    backend: list[BackendConfig] = Field(default_factory=list)
    instruments: dict[str, InstrumentAlias] = Field(default_factory=dict)


def _find_config_file() -> Path | None:
    """Search for config file in standard locations."""
    # 1. Environment variable
    env_path = os.environ.get("MCPYVISA_CONFIG")
    if env_path:
        p = Path(env_path)
        if p.is_file():
            return p

    # 2. Current directory
    cwd = Path.cwd() / "mcpyvisa.toml"
    if cwd.is_file():
        return cwd

    # 3. XDG config
    xdg = Path.home() / ".config" / "mcpyvisa" / "config.toml"
    if xdg.is_file():
        return xdg

    return None


def load_config(path: Path | None = None) -> AppConfig:
    """Load configuration from TOML file.

    Args:
        path: Explicit path to config file. If None, searches standard locations.

    Returns:
        Parsed and validated AppConfig.
    """
    config_path = path or _find_config_file()

    if config_path is None:
        return AppConfig()

    with open(config_path, "rb") as f:
        raw = tomllib.load(f)

    return AppConfig.model_validate(raw)
