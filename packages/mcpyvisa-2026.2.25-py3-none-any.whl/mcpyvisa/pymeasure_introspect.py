"""Introspect pymeasure instrument classes to extract properties and methods.

When an LLM needs to know what operations are available on an instrument,
we inspect the pymeasure driver class and categorize everything into:
- measurement properties (read-only: triggers a real measurement)
- control properties (read/write: get/set with validation)
- setting properties (write-only: configure without readback)
- public methods (high-level operations like apply_voltage)

The pymeasure property factories (Instrument.measurement, .control, .setting)
store metadata in the property's fget/fset closures that we can extract.
"""

import inspect
import logging
from typing import Any

logger = logging.getLogger(__name__)


def introspect_instrument(instrument_class) -> dict[str, Any]:
    """Extract a structured description of a pymeasure instrument class.

    Returns a dict with keys:
        class_name: str
        description: str (from class docstring)
        measurements: list of measurement property descriptors
        controls: list of control property descriptors
        settings: list of setting property descriptors
        methods: list of public method descriptors
    """
    result = {
        "class_name": instrument_class.__name__,
        "description": _clean_docstring(instrument_class.__doc__),
        "measurements": [],
        "controls": [],
        "settings": [],
        "methods": [],
    }

    # Walk the MRO to find all properties and methods
    seen_names: set[str] = set()

    for cls in instrument_class.__mro__:
        if cls.__name__ in ("object", "CommonBase"):
            break

        for name, obj in vars(cls).items():
            if name.startswith("_") or name in seen_names:
                continue
            seen_names.add(name)

            if isinstance(obj, property):
                prop_info = _analyze_property(name, obj)
                if prop_info:
                    category = prop_info.pop("category")
                    if category == "measurement":
                        result["measurements"].append(prop_info)
                    elif category == "control":
                        result["controls"].append(prop_info)
                    elif category == "setting":
                        result["settings"].append(prop_info)
                    else:
                        result["controls"].append(prop_info)

            elif callable(obj) and not isinstance(obj, type):
                method_info = _analyze_method(name, obj)
                if method_info:
                    result["methods"].append(method_info)

    # Sort each category alphabetically
    for key in ("measurements", "controls", "settings", "methods"):
        result[key].sort(key=lambda x: x["name"])

    return result


def _analyze_property(name: str, prop: property) -> dict[str, Any] | None:
    """Extract metadata from a pymeasure property descriptor."""
    info: dict[str, Any] = {"name": name}

    has_getter = prop.fget is not None
    has_setter = prop.fset is not None

    # Try to extract the docstring (pymeasure stores it in the property)
    doc = _clean_docstring(prop.__doc__ or getattr(prop.fget, "__doc__", None))
    info["description"] = doc

    # Determine category from getter/setter presence
    if has_getter and not has_setter:
        info["category"] = "measurement"
        info["readable"] = True
        info["writable"] = False
    elif has_getter and has_setter:
        info["category"] = "control"
        info["readable"] = True
        info["writable"] = True
    elif has_setter and not has_getter:
        info["category"] = "setting"
        info["readable"] = False
        info["writable"] = True
    else:
        return None

    # Try to extract pymeasure-specific metadata from the closure
    _extract_pymeasure_metadata(prop, info)

    return info


def _extract_pymeasure_metadata(prop: property, info: dict) -> None:
    """Dig into pymeasure property closures to find SCPI commands and validators.

    pymeasure's Instrument.control/measurement/setting store the get_command,
    set_command, values, and validator in the closure of fget/fset.
    """
    # Try fget closure first
    for fn in (prop.fget, prop.fset):
        if fn is None:
            continue
        closure_vars = _get_closure_vars(fn)
        if not closure_vars:
            continue

        if "get_command" in closure_vars and closure_vars["get_command"]:
            info["get_command"] = str(closure_vars["get_command"])
        if "set_command" in closure_vars and closure_vars["set_command"]:
            info["set_command"] = str(closure_vars["set_command"])
        if "values" in closure_vars:
            vals = closure_vars["values"]
            if vals:
                info["valid_values"] = _format_values(vals)
        if "validator" in closure_vars:
            validator = closure_vars["validator"]
            if hasattr(validator, "__name__"):
                info["validator"] = validator.__name__


def _get_closure_vars(fn) -> dict[str, Any]:
    """Extract variables from a function's closure."""
    if fn is None:
        return {}

    try:
        cv = inspect.getclosurevars(fn)
        result = {}
        result.update(cv.nonlocals)
        if hasattr(fn, "__wrapped__"):
            inner = inspect.getclosurevars(fn.__wrapped__)
            result.update(inner.nonlocals)
        return result
    except TypeError:
        return {}


def _format_values(values: Any) -> str:
    """Format valid values for display."""
    if isinstance(values, dict):
        return str(list(values.keys()))
    if isinstance(values, (list, tuple)):
        if len(values) == 2 and all(isinstance(v, (int, float)) for v in values):
            return f"[{values[0]}, {values[1]}]"
        return str(list(values))
    return str(values)


def _analyze_method(name: str, method) -> dict[str, Any] | None:
    """Extract metadata from a public method."""
    if name in (
        "write", "read", "ask", "values", "binary_values",
        "check_errors", "check_get_errors", "check_set_errors",
        "wait_for", "adapter", "isShutdown",
    ):
        return None

    if not callable(method):
        return None

    try:
        sig = inspect.signature(method)
    except (ValueError, TypeError):
        return None

    params = []
    for pname, param in sig.parameters.items():
        if pname == "self":
            continue
        p: dict[str, Any] = {"name": pname}
        if param.default is not inspect.Parameter.empty:
            p["default"] = repr(param.default)
        if param.annotation is not inspect.Parameter.empty:
            p["type"] = _format_annotation(param.annotation)
        params.append(p)

    doc = _clean_docstring(getattr(method, "__doc__", None))

    return {
        "name": name,
        "description": doc,
        "parameters": params,
    }


def _format_annotation(annotation: Any) -> str:
    """Format a type annotation for display."""
    if hasattr(annotation, "__name__"):
        return annotation.__name__
    return str(annotation)


def _clean_docstring(doc: str | None) -> str:
    """Clean up a docstring for display."""
    if not doc:
        return ""
    lines = doc.strip().split("\n")
    result = []
    for line in lines:
        stripped = line.strip()
        if not stripped and result:
            break
        result.append(stripped)
    return " ".join(result)


def format_for_llm(introspection: dict[str, Any]) -> str:
    """Format introspection results as a readable string for the LLM.

    Produces a structured text description that helps the LLM understand
    what properties and methods are available on the instrument.
    """
    lines = [
        f"# {introspection['class_name']}",
        "",
    ]

    if introspection["description"]:
        lines.append(introspection["description"])
        lines.append("")

    if introspection["measurements"]:
        lines.append("## Measurements (read-only -- triggers a measurement)")
        for m in introspection["measurements"]:
            desc = m.get("description", "")
            cmd = m.get("get_command", "")
            line = f"  - `{m['name']}`"
            if cmd:
                line += f"  (SCPI: {cmd})"
            if desc:
                line += f" -- {desc}"
            lines.append(line)
        lines.append("")

    if introspection["controls"]:
        lines.append("## Controls (read + write -- get/set with validation)")
        for c in introspection["controls"]:
            desc = c.get("description", "")
            get_cmd = c.get("get_command", "")
            set_cmd = c.get("set_command", "")
            valid = c.get("valid_values", "")
            validator = c.get("validator", "")

            line = f"  - `{c['name']}`"
            if get_cmd or set_cmd:
                cmds = f" (SCPI: {get_cmd}" if get_cmd else " ("
                if set_cmd:
                    cmds += f" / {set_cmd}" if get_cmd else f"SCPI: {set_cmd}"
                cmds += ")"
                line += cmds
            if desc:
                line += f" -- {desc}"
            lines.append(line)

            if valid:
                lines.append(f"    Valid: {valid}")
            if validator:
                lines.append(f"    Validator: {validator}")
        lines.append("")

    if introspection["settings"]:
        lines.append("## Settings (write-only -- configure without readback)")
        for s in introspection["settings"]:
            desc = s.get("description", "")
            cmd = s.get("set_command", "")
            valid = s.get("valid_values", "")

            line = f"  - `{s['name']}`"
            if cmd:
                line += f"  (SCPI: {cmd})"
            if desc:
                line += f" -- {desc}"
            lines.append(line)

            if valid:
                lines.append(f"    Valid: {valid}")
        lines.append("")

    if introspection["methods"]:
        lines.append("## Methods (high-level operations)")
        for m in introspection["methods"]:
            desc = m.get("description", "")
            params = m.get("parameters", [])

            param_str = ""
            if params:
                parts = []
                for p in params:
                    s = p["name"]
                    if "type" in p:
                        s += f": {p['type']}"
                    if "default" in p:
                        s += f"={p['default']}"
                    parts.append(s)
                param_str = ", ".join(parts)

            line = f"  - `{m['name']}({param_str})`"
            if desc:
                line += f" -- {desc}"
            lines.append(line)
        lines.append("")

    return "\n".join(lines)
