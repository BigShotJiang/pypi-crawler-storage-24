"""Exception hierarchy for mcpyvisa.

All exceptions inherit from McpyVisaError so callers can catch broadly
or narrowly. The hierarchy reflects the pyvisa-centric architecture:

    McpyVisaError
    +-- ConfigError              -- bad TOML, missing fields
    +-- BackendError             -- backend-level problems
    |   +-- BackendNotFoundError -- name doesn't match any configured backend
    +-- InstrumentNotFoundError  -- alias/resource doesn't resolve
    +-- InstrumentError          -- instrument didn't respond or returned error
    +-- TransportError           -- serial/TCP/USB connect/read/write failures
    |   +-- TimeoutError         -- read deadline exceeded
    +-- CapabilityError          -- operation not supported by this transport
    +-- PyMeasureError           -- pymeasure driver layer errors
"""


class McpyVisaError(Exception):
    """Base exception for all mcpyvisa errors."""


# --- Config ---

class ConfigError(McpyVisaError):
    """Invalid or missing configuration."""


# --- Backend ---

class BackendError(McpyVisaError):
    """Backend-level problem (connect, init, protocol)."""


class BackendNotFoundError(BackendError):
    """No configured backend matches the given name."""


# --- Instrument ---

class InstrumentNotFoundError(McpyVisaError):
    """Alias or resource string doesn't resolve to a known instrument."""


class InstrumentError(McpyVisaError):
    """Instrument did not respond or returned an error."""


# --- Transport ---

class TransportError(McpyVisaError):
    """Transport layer failure (serial, TCP, USB)."""


class TimeoutError(TransportError):  # noqa: A001
    """Read operation exceeded deadline."""


# --- Capability ---

class CapabilityError(McpyVisaError):
    """Operation not supported by this backend/transport type.

    Raised when e.g. a GPIB-specific operation is attempted on a
    TCPIP backend, or an AR488-specific command on a NI-VISA backend.
    """


# --- pymeasure ---

class PyMeasureError(McpyVisaError):
    """Error from pymeasure driver layer (validation, driver load, etc.)."""
