"""pymeasure instrument lifecycle manager.

Creates and caches pymeasure instrument objects, backed by pyvisa
ResourceManager instances from the InstrumentManager.

Simplified from mcgpib's version: no bridge mode wrapping needed.
The InstrumentManager already holds pyvisa ResourceManagers, so we
just get the RM for the right backend and open resources through it.
"""

import contextlib
import logging
from typing import Any

from mcpyvisa.instrument_manager import InstrumentManager
from mcpyvisa.pymeasure_registry import get_driver_class, match_idn

logger = logging.getLogger(__name__)


class PyMeasureManager:
    """Manages pymeasure instrument instances backed by pyvisa."""

    def __init__(self, instrument_manager: InstrumentManager):
        self._im = instrument_manager

        # Cache: (resource, backend_name) -> pymeasure instrument instance
        self._instruments: dict[tuple[str, str], Any] = {}

        # Cache: (resource, backend_name) -> catalog_id
        self._catalog_ids: dict[tuple[str, str], str] = {}

    def get_catalog_id(self, resource: str, backend_name: str) -> str | None:
        """Look up the pymeasure catalog ID for an instrument.

        Uses cached identity from the InstrumentManager. Returns None
        if the instrument isn't recognized or has no pymeasure driver.
        """
        key = (resource, backend_name)
        if key in self._catalog_ids:
            return self._catalog_ids[key]

        # Find identity in the backend's discovered instruments
        instruments = self._im.list_instruments(backend_name=backend_name)
        for inst in instruments:
            if inst.resource == resource and inst.identity:
                catalog_id = match_idn(inst.identity.raw)
                if catalog_id:
                    self._catalog_ids[key] = catalog_id
                return catalog_id

        # Try the identity cache
        identity = self._im.get_identity(resource)
        if identity:
            catalog_id = match_idn(identity.raw)
            if catalog_id:
                self._catalog_ids[key] = catalog_id
            return catalog_id

        return None

    def get_driver_class_for(self, resource: str, backend_name: str):
        """Get the pymeasure driver class for an instrument, or None."""
        catalog_id = self.get_catalog_id(resource, backend_name)
        if catalog_id is None:
            return None
        return get_driver_class(catalog_id)

    def get_or_create(self, resource: str, backend_name: str):
        """Get a cached pymeasure instrument instance, or create one.

        Returns None if no pymeasure driver is available for this instrument.
        Must be called from a thread (not the event loop) since pymeasure
        constructors do synchronous I/O through pyvisa.
        """
        key = (resource, backend_name)
        if key in self._instruments:
            return self._instruments[key]

        driver_class = self.get_driver_class_for(resource, backend_name)
        if driver_class is None:
            return None

        # Get the pyvisa ResourceManager for this backend
        state = self._im._get_backend(backend_name)
        if state.rm is None:
            logger.warning("Backend %s not connected for pymeasure", backend_name)
            return None

        try:
            visa_resource = state.rm.open_resource(resource)
            instrument = driver_class(visa_resource)
            self._instruments[key] = instrument
            logger.info(
                "Created pymeasure %s for %s on %s",
                driver_class.__name__,
                resource,
                backend_name,
            )
            return instrument
        except Exception:
            logger.warning(
                "Failed to create pymeasure instrument for %s on %s",
                resource,
                backend_name,
                exc_info=True,
            )
            return None

    def get_cached(self, resource: str, backend_name: str):
        """Get a cached instrument instance without creating a new one."""
        return self._instruments.get((resource, backend_name))

    def invalidate(self, backend_name: str, resource: str | None = None) -> None:
        """Remove cached instruments for a backend (or specific resource).

        Called when a backend disconnects to clean up stale objects.
        """
        if resource is not None:
            key = (resource, backend_name)
            self._instruments.pop(key, None)
            self._catalog_ids.pop(key, None)
        else:
            keys_to_remove = [
                k for k in self._instruments if k[1] == backend_name
            ]
            for k in keys_to_remove:
                inst = self._instruments.pop(k, None)
                if inst is not None:
                    with contextlib.suppress(Exception):
                        if hasattr(inst, "adapter") and hasattr(inst.adapter, "close"):
                            inst.adapter.close()
                self._catalog_ids.pop(k, None)

    def cleanup(self) -> None:
        """Clean up all cached instruments."""
        for inst in self._instruments.values():
            with contextlib.suppress(Exception):
                if hasattr(inst, "adapter") and hasattr(inst.adapter, "close"):
                    inst.adapter.close()
        self._instruments.clear()
        self._catalog_ids.clear()
