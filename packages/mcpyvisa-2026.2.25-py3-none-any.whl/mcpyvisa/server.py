"""FastMCP server for test equipment via pyvisa.

This wires everything together: config loading, InstrumentManager lifecycle,
and tool/resource/prompt registration. The lifespan context manager
initializes the InstrumentManager and makes it available to all tools.

Any pyvisa backend works: AR488/Prologix, pyvisa-py (USB-TMC, LAN),
NI-VISA, or simulation. The backend type is configured in mcpyvisa.toml.

If pymeasure is installed, additional tools are registered for validated
instrument interaction through pymeasure drivers.
"""

import logging
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastmcp import FastMCP

from mcpyvisa import __version__
from mcpyvisa.config import load_config
from mcpyvisa.instrument_manager import InstrumentManager

# Prompts
from mcpyvisa.prompts import (
    bus_health_check,
    initialize_bench,
    measurement_sequence,
    pymeasure_measurement,
    scpi_command_help,
    troubleshoot_instrument,
)

# Tool modules
from mcpyvisa.tools import ar488_tools, gpib_tools, instrument_tools

logger = logging.getLogger("mcpyvisa")

# Detect pymeasure availability at import time
_PYMEASURE_AVAILABLE = False
try:
    from mcpyvisa.pymeasure_manager import PyMeasureManager
    from mcpyvisa.tools import pymeasure_tools

    _PYMEASURE_AVAILABLE = True
except ImportError:
    logger.debug("pymeasure not available -- pymeasure tools will be disabled")


@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[dict]:
    """Initialize InstrumentManager on startup, disconnect all on shutdown."""
    config = load_config()

    log_level = getattr(logging, config.server.log_level.upper(), logging.INFO)
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s %(name)s %(levelname)s: %(message)s",
        stream=sys.stderr,
    )

    im = InstrumentManager(config)
    context: dict = {"instrument_manager": im}

    # Set up pymeasure manager if available
    pm_manager = None
    if _PYMEASURE_AVAILABLE:
        pm_manager = PyMeasureManager(im)
        context["pymeasure_manager"] = pm_manager
        logger.info("pymeasure integration enabled")

    logger.info(
        "mcpyvisa v%s starting -- %d backend(s) configured",
        __version__,
        len(config.backend),
    )

    try:
        yield context
    finally:
        if pm_manager:
            pm_manager.cleanup()
        await im.disconnect_all()
        logger.info("mcpyvisa shutdown complete")


mcp = FastMCP(
    "mcpyvisa",
    instructions=(
        "Test equipment controller via pyvisa. "
        "Supports GPIB (AR488/Prologix, NI-VISA), USB-TMC, LAN/VXI-11, "
        "and serial instruments. Instruments addressed by VISA resource "
        "strings or friendly aliases."
    ),
    lifespan=lifespan,
)

# --- Register tools ---

# Universal instrument tools (any backend)
mcp.tool(instrument_tools.server_status)
mcp.tool(instrument_tools.connect_backend)
mcp.tool(instrument_tools.disconnect_backend)
mcp.tool(instrument_tools.discover_instruments)
mcp.tool(instrument_tools.instrument_query)
mcp.tool(instrument_tools.instrument_write)
mcp.tool(instrument_tools.instrument_identify)
mcp.tool(instrument_tools.instrument_reset)

# GPIB-specific tools (helpful error on non-GPIB backends)
mcp.tool(gpib_tools.instrument_clear)
mcp.tool(gpib_tools.serial_poll)
mcp.tool(gpib_tools.check_srq)
mcp.tool(gpib_tools.bus_trigger)
mcp.tool(gpib_tools.interface_clear)
mcp.tool(gpib_tools.instrument_local)
mcp.tool(gpib_tools.instrument_remote)

# AR488-specific tools (helpful error on non-AR488 backends)
mcp.tool(ar488_tools.ar488_command)
mcp.tool(ar488_tools.ar488_diagnostic)
mcp.tool(ar488_tools.configure_ar488)

# pymeasure-backed tools (only if pymeasure is installed)
if _PYMEASURE_AVAILABLE:
    mcp.tool(pymeasure_tools.instrument_inspect)
    mcp.tool(pymeasure_tools.instrument_get)
    mcp.tool(pymeasure_tools.instrument_set)
    mcp.tool(pymeasure_tools.instrument_call)

# --- Register prompts ---

mcp.prompt(initialize_bench)
mcp.prompt(troubleshoot_instrument)
mcp.prompt(measurement_sequence)
mcp.prompt(bus_health_check)
mcp.prompt(scpi_command_help)

if _PYMEASURE_AVAILABLE:
    mcp.prompt(pymeasure_measurement)


# --- Register resources ---

@mcp.resource("visa://protocol/scpi")
def protocol_commands() -> str:
    """SCPI and AR488/Prologix command reference -- all supported commands."""
    from mcpyvisa.resources import SCPI_REFERENCE
    return SCPI_REFERENCE


if _PYMEASURE_AVAILABLE:
    @mcp.resource("visa://pymeasure/supported")
    def pymeasure_supported() -> str:
        """List instruments with pymeasure driver support."""
        import json

        from mcpyvisa.pymeasure_registry import list_supported
        return json.dumps(list_supported(), indent=2)


def main():
    mcp.run()
