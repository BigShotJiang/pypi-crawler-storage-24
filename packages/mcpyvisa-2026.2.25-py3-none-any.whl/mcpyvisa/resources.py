"""MCP resources -- read-only reference data for VISA/SCPI/AR488.

Resources provide structured data that LLMs can read to understand
protocols, commands, and instrument capabilities without executing commands.
"""

import json

# AR488/Prologix command reference for the protocol resource
COMMAND_REFERENCE = {
    "prologix_commands": {
        "++addr [N]": "Show or set current GPIB address (1-30)",
        "++auto [0|1|2|3]": "Auto-read mode: 0=off, 1=prologix, 2=on-query, 3=continuous",
        "++clr": "Send Selected Device Clear (SDC) to addressed device",
        "++eoi [0|1]": "Enable/disable EOI assertion on last byte",
        "++eor [0-7]": (
            "Set EOR char: 0=CRLF 1=CR 2=LF 3=None 4=LFCR 5=ETX 6=CRLF+ETX 7=SPACE"
        ),
        "++eos [0-3]": "Set end-of-send character (0=CRLF, 1=CR, 2=LF, 3=None)",
        "++eot_enable [0|1]": "Enable/disable appending EOT character on EOI detection",
        "++eot_char [N]": "Set EOT character (ASCII 0-255)",
        "++ifc": "Assert Interface Clear for 150us -- become Controller-In-Charge",
        "++llo [all]": "Local Lockout -- disable front panel on instrument(s)",
        "++loc [all]": "Go To Local -- re-enable front panel on instrument(s)",
        "++mode [0|1]": "Set interface mode: 0=device, 1=controller",
        "++read [eoi|N]": "Read from bus until EOI, char N, or timeout",
        "++read_tmo_ms [N]": "Set read timeout in milliseconds (1-32000)",
        "++rst": "Reset the controller",
        "++savecfg": "Save configuration to NVS flash",
        "++spoll [N]": "Serial poll address N (or current address)",
        "++srq": "Return SRQ line state (0=unasserted, 1=asserted)",
        "++status [N]": "Set/get status byte for device mode",
        "++trg [N ...]": "Send Group Execute Trigger to address(es)",
        "++ver [real]": "Show firmware version string",
        "++verbose [0|1]": "Enable/disable human-readable output",
    },
    "extended_commands": {
        "++allspoll [N ...]": "Serial poll multiple addresses, returns addr:status pairs",
        "++findlstn": "Find all listeners on the bus (returns space-separated addresses)",
        "++findrqs [N ...]": "Find device requesting service (returns SRQ:addr,status)",
        "++dcl": "Send Universal Device Clear to all devices",
        "++default": "Reset to factory default configuration",
        "++id name [S]": "Show/set interface name (max 15 chars)",
        "++id serial [N]": "Show/set interface serial number (max 9 digits)",
        "++id verstr [S]": "Show/set custom version string (max 47 chars)",
        "++idn [0|1|2]": "Enable *IDN? response: 0=off, 1=name, 2=name+serial",
        "++macro [N] [set|del]": "List/run/edit/delete macros (0-9, 128 bytes each)",
        "++ppoll": "Conduct parallel poll (returns response byte)",
        "++prompt [0|1]": "Show/hide command prompt",
        "++ren [0|1]": "Assert/deassert Remote Enable",
        "++repeat N ms cmd": "Repeat a command N times with ms delay",
        "++setvstr [S]": "Set custom version string (alias for ++id verstr)",
        "++srqauto [0|1]": "Auto serial poll on SRQ assertion",
        "++tmbus [N]": "Bus settling delay in microseconds (0-30000)",
        "++ton [0|1]": "Talk-only mode",
        "++xdiag mode byte": "Bus diagnostics: mode 0=data, 1=control",
    },
    "notes": {
        "gpib_addresses": "Valid range 0-30. Address 0 is typically the controller.",
        "scpi_queries": "Commands ending with '?' expect a response -- use instrument_query.",
        "scpi_commands": "Commands without '?' set parameters -- use instrument_write.",
        "visa_resource_strings": [
            "GPIB0::22::INSTR -- GPIB instrument at address 22",
            "TCPIP::192.168.1.5::INSTR -- LAN instrument via VXI-11",
            "TCPIP::192.168.1.5::5025::SOCKET -- Raw TCP socket",
            "USB0::0x1234::0x5678::SN12345::INSTR -- USB-TMC instrument",
            "ASRL/dev/ttyUSB0::INSTR -- Serial instrument",
        ],
        "common_scpi": [
            "*IDN? -- Identify instrument",
            "*RST -- Reset to power-on defaults",
            "*CLS -- Clear status registers",
            "*ESE N -- Set event status enable register",
            "*ESR? -- Read event status register",
            "*OPC -- Operation complete",
            "*OPC? -- Operation complete query",
            "*SRE N -- Set service request enable register",
            "*STB? -- Read status byte",
            "*TST? -- Self-test",
            "*WAI -- Wait for pending operations",
        ],
    },
}


SCPI_REFERENCE = json.dumps(COMMAND_REFERENCE, indent=2)
