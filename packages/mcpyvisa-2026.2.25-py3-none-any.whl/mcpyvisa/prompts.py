"""MCP prompts -- guided workflows for common instrument tasks.

Prompts provide structured starting points for LLM interactions
with test equipment. They encode domain knowledge about instrument
initialization, troubleshooting patterns, and measurement sequences.

Updated from mcgpib: uses pyvisa vocabulary (backend, instrument alias/resource)
instead of bridge-specific terminology.
"""


def initialize_bench(backend: str) -> str:
    """Connect to a backend, discover instruments, and identify them.

    Use this prompt to set up a test bench for the first time or after
    power cycling instruments.

    Args:
        backend: Name of the backend to initialize.
    """
    return f"""Initialize the test bench on backend "{backend}":

1. Call connect_backend("{backend}") to establish communication
2. Call discover_instruments("{backend}") to find instruments
3. For each discovered instrument, note its resource string and identity
4. Summarize the bench setup:
   - Backend type and firmware version (if AR488)
   - Number and type of instruments found
   - Any resources that responded but couldn't be identified
   - Instrument aliases available from config

If the backend connection fails, check:
- Is the USB cable connected? (AR488 serial transport)
- Is the ESP32 powered and WiFi connected? (AR488 TCP transport)
- Is another client already connected? (ESP32 allows only ONE TCP client)
- Is the VISA backend installed? (pyvisa-py, NI-VISA)

If no instruments are found:
- Check GPIB cable connections / network connectivity
- Verify instruments are powered on
- Try interface_clear() to reset the bus state (GPIB only)
"""


def troubleshoot_instrument(instrument: str) -> str:
    """Systematic diagnostic sequence for a non-responsive instrument.

    Args:
        instrument: Instrument alias or VISA resource string.
    """
    return f"""Troubleshoot instrument "{instrument}":

Step 1 -- Verify connectivity:
  - Call discover_instruments() to check if the instrument appears
  - If not present: check physical connections or network path

Step 2 -- Check instrument identity:
  - Call instrument_identify("{instrument}")
  - If *IDN? times out: instrument may not support IEEE 488.2

Step 3 -- Check instrument status:
  - Call serial_poll(instrument="{instrument}")
  - Examine the status byte:
    - Bit 6 (0x40): device requesting service (SRQ)
    - Bit 5 (0x20): event status bit (check *ESR?)
    - Bit 4 (0x10): message available (MAV)
    - Other bits: instrument-specific

Step 4 -- Clear error state:
  - Call instrument_write("{instrument}", "*CLS")
  - Call instrument_query("{instrument}", "SYST:ERR?")
  - Repeat SYST:ERR? until "0,No error" is returned

Step 5 -- Reset if needed:
  - Call instrument_reset("{instrument}")
  - Wait a few seconds for the instrument to reconfigure
  - Re-identify with instrument_identify()

Step 6 -- Bus-level recovery (GPIB only):
  - Call interface_clear() to reassert bus control
  - Call instrument_clear("{instrument}") for selective device clear
"""


def measurement_sequence(instrument: str, measurement_type: str) -> str:
    """Guide setup and capture of a measurement.

    Args:
        instrument: Instrument alias or VISA resource string.
        measurement_type: Type of measurement (e.g. "dc_voltage", "frequency", "resistance").
    """
    return f"""Set up {measurement_type} measurement on instrument "{instrument}":

1. Identify the instrument:
   - Call instrument_identify("{instrument}")
   - Determine the instrument type and available SCPI commands

2. Configure the measurement:
   - Based on the instrument model, send appropriate configuration commands
   - Common patterns:
     - DC Voltage: CONF:VOLT:DC [range],[resolution]
     - AC Voltage: CONF:VOLT:AC [range],[resolution]
     - Frequency: CONF:FREQ [range],[resolution]
     - Resistance: CONF:RES [range],[resolution]
     - 4-Wire Resistance: CONF:FRES [range],[resolution]
     - Current DC: CONF:CURR:DC [range],[resolution]
   - Use instrument_write() for each configuration command

3. Trigger and read:
   - Call instrument_query("{instrument}", "READ?")
   - Or for triggered measurements:
     a. instrument_write("{instrument}", "TRIG:SOUR IMM")
     b. instrument_write("{instrument}", "INIT")
     c. instrument_query("{instrument}", "FETCH?")

4. Validate the reading:
   - Check the returned value is within expected range
   - Check instrument status: instrument_query("{instrument}", "*STB?")

Note: SCPI commands vary by manufacturer. Always check *IDN? first and adapt
commands to the specific instrument model.
"""


def bus_health_check() -> str:
    """Full infrastructure health audit across all backends."""
    return """Perform a complete instrument infrastructure health check:

1. Check server status:
   - Call server_status()
   - Note which backends are connected vs disconnected

2. For each connected backend:
   a. Run discover_instruments() with identification
   b. Check SRQ line: check_srq() (GPIB backends only)
   c. Serial poll all instruments: serial_poll(backend=name)

3. For each disconnected backend:
   - Attempt connect_backend()
   - Log success or failure

4. Generate health report:
   - Total backends: configured, connected, failed
   - Total instruments: discovered, identified, responding
   - Any SRQ assertions (devices requesting service)
   - Any instruments with error status bytes
   - Recommendations for any issues found
"""


def pymeasure_measurement(instrument: str) -> str:
    """Guided workflow: inspect, configure, and measure using pymeasure drivers.

    This prompt steers toward validated pymeasure tools when available,
    falling back to raw SCPI only when necessary.

    Args:
        instrument: Instrument alias or VISA resource string.
    """
    return f"""\
Take a validated measurement from instrument "{instrument}":

Step 1 -- Discover capabilities:
  - Call instrument_inspect("{instrument}")
  - This returns the pymeasure driver's properties and methods
  - If no pymeasure driver is available, fall back to raw SCPI (skip to Step 5)

Step 2 -- Check current instrument state:
  - Use instrument_get() to read key control properties
  - For a source-measure unit: source_mode, source_enabled, compliance settings
  - For a multimeter: measurement function, range, resolution
  - This tells you what the instrument is currently configured to do

Step 3 -- Configure the measurement:
  - Use instrument_set() for individual properties -- values are validated
    before reaching the instrument (out-of-range values are rejected)
  - Or use instrument_call() for high-level methods that combine multiple steps:
    - apply_voltage(voltage=5.0, compliance_current=0.1)
    - apply_current(current_range=0.01, compliance_voltage=10)
  - The driver handles the correct SCPI command sequence internally

Step 4 -- Read the measurement:
  - Use instrument_get() on measurement properties (e.g., "voltage", "current")
  - pymeasure parses the response, handles unit conversion, and returns typed values
  - For repeated measurements, call instrument_get() in a loop

Step 5 -- Raw SCPI fallback (if no pymeasure driver):
  - Use instrument_query("{instrument}", "MEAS:VOLT:DC?")
  - Use instrument_write() for configuration commands
  - Parse numeric responses manually

Step 6 -- Cleanup:
  - If you enabled an output (source-measure units), disable it when done:
    instrument_call("{instrument}", "shutdown")
  - Return instrument to local control:
    instrument_local("{instrument}")

Key principle: Always prefer instrument_get/set/call over raw SCPI when a pymeasure
driver is available -- the driver validates parameters and protects the instrument.
"""


def scpi_command_help(instrument_model: str) -> str:
    """SCPI command reference for a specific instrument model.

    Args:
        instrument_model: Model identifier (e.g. "HP3478A", "Keithley 2000").
    """
    return f"""Provide SCPI/GPIB command reference for the {instrument_model}:

Look up the {instrument_model} programming manual and provide:

1. Common measurement commands:
   - Configuration commands (CONF:*, SENS:*)
   - Trigger commands (TRIG:*, INIT, *TRG)
   - Read commands (READ?, FETCH?, MEAS:*)
   - Range and resolution settings

2. Status and error handling:
   - Status byte bit assignments
   - Error query (SYST:ERR?)
   - Event status register bits (*ESE, *ESR?)

3. Important notes:
   - Is the instrument IEEE 488.2 compliant? (supports *IDN?, *RST, etc.)
   - Any non-standard GPIB behavior
   - Typical read timeout requirements
   - Any initialization sequence needed after power-on

Note: Older instruments (HP 3478A, Fluke 8842A, etc.) may use HP-GL or
proprietary command sets rather than standard SCPI. Adapt commands accordingly.
"""
