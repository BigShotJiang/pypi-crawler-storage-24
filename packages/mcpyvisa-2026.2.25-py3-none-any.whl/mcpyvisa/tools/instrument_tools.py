"""Universal instrument tools -- work with any pyvisa backend.

These are the primary LLM interface tools: query, write, identify, discover,
reset, and backend management. All instrument parameters accept either a
VISA resource string ("GPIB0::22::INSTR") or a configured alias ("dmm").
"""

from fastmcp import Context

from mcpyvisa.instrument_manager import InstrumentManager


def _im(ctx: Context) -> InstrumentManager:
    return ctx.request_context.lifespan_context["instrument_manager"]


async def server_status(ctx: Context) -> str:
    """Show server status: configured backends, connections, and instrument counts.

    Returns an overview of all backends and their connection states,
    plus total discovered instruments. Use this to understand the current
    state of the test bench.
    """
    im = _im(ctx)
    status = im.get_server_status()

    lines = [
        f"mcpyvisa v{status.version}",
        f"Backends: {status.backends_connected}/{status.backends_configured} connected",
        f"Instruments: {status.total_instruments} discovered",
    ]

    if status.backend_summaries:
        lines.append("")
        for b in status.backend_summaries:
            state = b.connection_state.value
            detail = f" ({b.transport_detail})" if b.transport_detail else ""
            fw = f" -- {b.firmware_version}" if b.firmware_version else ""
            lines.append(f"  {b.name}: {b.type.value}{detail} [{state}]{fw}")
            if b.resource_count:
                lines.append(f"    {b.resource_count} instrument(s)")
            if b.error_message:
                lines.append(f"    Error: {b.error_message}")
    else:
        lines.append("\nNo backends configured. Add [[backend]] sections to mcpyvisa.toml.")

    return "\n".join(lines)


async def connect_backend(ctx: Context, backend: str) -> str:
    """Connect to a backend and initialize it for instrument communication.

    Establishes the pyvisa ResourceManager for the specified backend.
    For AR488 backends, this opens the serial/TCP connection and runs
    the initialization sequence. Auto-discovers instruments if configured.

    Args:
        backend: Name of the backend to connect (from config).
    """
    im = _im(ctx)
    info = await im.connect_backend(backend)
    instruments = im.list_instruments(backend_name=backend)

    result = f"Connected to {backend}: {info.type.value}"
    if info.firmware_version:
        result += f" ({info.firmware_version})"
    if info.transport_detail:
        result += f"\nTransport: {info.transport_detail}"

    if instruments:
        result += f"\nDiscovered {len(instruments)} instrument(s):"
        for inst in instruments:
            label = inst.alias or inst.resource
            if inst.identity:
                result += (
                    f"\n  {label}: {inst.identity.manufacturer} "
                    f"{inst.identity.model}"
                )
            else:
                result += f"\n  {label}: (no *IDN? response)"

    return result


async def disconnect_backend(ctx: Context, backend: str) -> str:
    """Disconnect from a backend.

    Closes the underlying connection (serial, TCP, VISA session).
    Instruments on the bus will return to local control.

    Args:
        backend: Name of the backend to disconnect.
    """
    im = _im(ctx)
    await im.disconnect_backend(backend)
    return f"Disconnected from {backend}"


async def discover_instruments(
    ctx: Context,
    backend: str | None = None,
) -> str:
    """Discover instruments on one or all backends.

    Queries each connected backend for available resources and optionally
    identifies each with *IDN?. Replaces the previous bus_scan + list_instruments.

    Args:
        backend: Backend name to scan. If omitted, scans all connected backends.
    """
    im = _im(ctx)
    instruments = await im.discover(backend_name=backend)

    if not instruments:
        scope = f"on {backend}" if backend else "on any backend"
        return f"No instruments found {scope}."

    # Check pymeasure availability for driver annotations
    try:
        from mcpyvisa.pymeasure_registry import match_idn
        has_pymeasure = True
    except ImportError:
        has_pymeasure = False

    lines = [f"Discovered {len(instruments)} instrument(s):"]
    for inst in instruments:
        label = inst.alias or inst.resource
        idn = inst.identity

        if idn:
            desc = f"{idn.manufacturer} {idn.model}".strip()
            if not desc:
                desc = idn.raw or "(identified but empty *IDN?)"
            if idn.serial_number:
                desc += f" (S/N: {idn.serial_number})"
            if has_pymeasure and idn.raw:
                catalog_id = match_idn(idn.raw)
                if catalog_id:
                    desc += f"  [pymeasure: {catalog_id}]"
        else:
            desc = "(not identified)"

        lines.append(f"  [{inst.backend_name}] {label}: {desc}")

    return "\n".join(lines)


async def instrument_query(
    ctx: Context,
    instrument: str,
    command: str,
) -> str:
    """Send a SCPI query to an instrument and return the response.

    This is the most common operation -- send a query command (usually
    ending with '?') and read back the instrument's response.

    Examples:
        instrument_query("dmm", "MEAS:VOLT:DC?")
        instrument_query("GPIB0::22::INSTR", "*IDN?")
        instrument_query("scope", "MEAS:FREQ?")

    Args:
        instrument: Instrument alias or VISA resource string.
        command: SCPI command to send (typically ends with '?').
    """
    im = _im(ctx)
    return await im.query(instrument, command)


async def instrument_write(
    ctx: Context,
    instrument: str,
    command: str,
) -> str:
    """Send a SCPI command to an instrument with no response expected.

    Use this for configuration commands that don't return data.

    Examples:
        instrument_write("dmm", "CONF:VOLT:DC 10,0.001")
        instrument_write("smu", "OUTP ON")
        instrument_write("GPIB0::1::INSTR", "TRIG:SOUR IMM")

    Args:
        instrument: Instrument alias or VISA resource string.
        command: SCPI command to send.
    """
    im = _im(ctx)
    await im.write(instrument, command)
    resource, _ = im.resolve(instrument)
    return f"Sent to {resource}: {command}"


async def instrument_identify(ctx: Context, instrument: str) -> str:
    """Identify an instrument by sending the IEEE 488.2 *IDN? query.

    Returns parsed manufacturer, model, serial number, and firmware version.

    Args:
        instrument: Instrument alias or VISA resource string.
    """
    im = _im(ctx)
    idn = await im.identify(instrument)
    resource, backend_name = im.resolve(instrument)
    return (
        f"{resource} ({backend_name}):\n"
        f"  Manufacturer: {idn.manufacturer}\n"
        f"  Model: {idn.model}\n"
        f"  Serial: {idn.serial_number}\n"
        f"  Firmware: {idn.firmware_version}\n"
        f"  Raw: {idn.raw}"
    )


async def instrument_reset(ctx: Context, instrument: str) -> str:
    """Send *RST to reset an instrument to its power-on defaults.

    Args:
        instrument: Instrument alias or VISA resource string.
    """
    im = _im(ctx)
    await im.write(instrument, "*RST")
    resource, _ = im.resolve(instrument)
    return f"Reset instrument {resource}"
