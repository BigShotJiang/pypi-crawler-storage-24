"""AR488-specific tools -- raw ++ commands, diagnostics, configuration.

These tools always register but return helpful error messages when used
on non-AR488 backends. They provide direct access to AR488/Prologix
features not covered by the standard VISA interface.
"""

from fastmcp import Context

from mcpyvisa.instrument_manager import InstrumentManager


def _im(ctx: Context) -> InstrumentManager:
    return ctx.request_context.lifespan_context["instrument_manager"]


async def ar488_command(
    ctx: Context,
    backend: str,
    command: str,
) -> str:
    """Send a raw ++ command directly to an AR488 bridge.

    Passes the command through without interpretation. Use for AR488
    commands not covered by other tools, or for debugging.

    Common commands:
        ++ver          -- firmware version
        ++addr         -- show current address
        ++mode         -- show controller/device mode
        ++savecfg      -- save configuration to NVS
        ++default      -- reset to factory defaults
        ++id name      -- show bridge name
        ++macro        -- list macros
        ++ppoll        -- parallel poll

    This tool only works with AR488 backends. On other backend types,
    returns a helpful error message.

    Args:
        backend: Name of the AR488 backend.
        command: The full ++ command string (e.g. "++ver", "++addr 5").
    """
    im = _im(ctx)
    response = await im.ar488_command(backend, command)
    if response is not None:
        return response
    return "(no response)"


async def ar488_diagnostic(
    ctx: Context,
    backend: str,
    mode: int,
    value: int,
) -> str:
    """Run bus diagnostics via ++xdiag.

    Writes a byte directly to the data or control bus lines for 10 seconds.
    Use for hardware debugging and signal integrity testing.

    WARNING: This holds the bus for 10 seconds and may disrupt communication.

    This tool only works with AR488 backends.

    Args:
        backend: Name of the AR488 backend.
        mode: 0 = data bus (DIO1-DIO8), 1 = control bus (IFC, ATN, etc.).
        value: Byte value to write (0-255).
    """
    im = _im(ctx)
    await im.ar488_xdiag(backend, mode, value)
    bus_type = "data" if mode == 0 else "control"
    return (
        f"Diagnostic: writing 0x{value:02X} to {bus_type} bus on {backend} "
        f"for 10 seconds"
    )


async def configure_ar488(
    ctx: Context,
    backend: str,
    read_timeout_ms: int | None = None,
    auto_mode: int | None = None,
    eos: int | None = None,
    eoi: bool | None = None,
) -> str:
    """Change AR488 bridge configuration at runtime.

    This tool only works with AR488 backends.

    Args:
        backend: Name of the AR488 backend.
        read_timeout_ms: GPIB read timeout in milliseconds (1-32000).
        auto_mode: Auto-read mode (0=off, 1=prologix, 2=on-query, 3=continuous).
        eos: End-of-send character (0=CRLF, 1=CR, 2=LF, 3=None).
        eoi: Whether to assert EOI on last byte sent.
    """
    im = _im(ctx)
    changes = []

    if read_timeout_ms is not None:
        await im.ar488_command(backend, f"++read_tmo_ms {read_timeout_ms}")
        changes.append(f"read_timeout_ms={read_timeout_ms}")
    if auto_mode is not None:
        await im.ar488_command(backend, f"++auto {auto_mode}")
        changes.append(f"auto_mode={auto_mode}")
    if eos is not None:
        await im.ar488_command(backend, f"++eos {eos}")
        changes.append(f"eos={eos}")
    if eoi is not None:
        await im.ar488_command(backend, f"++eoi {'1' if eoi else '0'}")
        changes.append(f"eoi={eoi}")

    if not changes:
        return f"No configuration changes specified for {backend}"

    return f"Configured {backend}: {', '.join(changes)}"
