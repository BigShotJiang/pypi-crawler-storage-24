"""pymeasure-backed instrument tools -- validated, high-level access.

These tools provide validated, high-level access to instruments that have
pymeasure drivers. Properties are range-checked before commands reach the
instrument, methods encode multi-step SCPI sequences, and all operations
use pymeasure's tested driver implementations.

The raw instrument_query/instrument_write tools remain as fallback for
instruments without pymeasure drivers.

All instrument parameters accept either a VISA resource string or alias.
"""

import asyncio
import json
import logging
from typing import Any

from fastmcp import Context

from mcpyvisa.errors import PyMeasureError
from mcpyvisa.pymeasure_introspect import format_for_llm, introspect_instrument
from mcpyvisa.pymeasure_manager import PyMeasureManager
from mcpyvisa.pymeasure_registry import get_driver_class, list_supported, match_idn

logger = logging.getLogger(__name__)


def _pm(ctx: Context) -> PyMeasureManager:
    return ctx.request_context.lifespan_context["pymeasure_manager"]


def _im(ctx: Context):
    return ctx.request_context.lifespan_context["instrument_manager"]


async def instrument_inspect(ctx: Context, instrument: str) -> str:
    """Inspect an instrument's pymeasure driver -- discover available properties and methods.

    This is the starting point for validated instrument interaction. Returns
    categorized lists of measurements (read-only), controls (read/write with
    validation), settings (write-only), and high-level methods.

    If no pymeasure driver is available for this instrument, suggests using
    the raw instrument_query/instrument_write tools instead.

    Args:
        instrument: Instrument alias or VISA resource string.
    """
    pm = _pm(ctx)
    im = _im(ctx)
    resource, backend_name = im.resolve(instrument)

    catalog_id = pm.get_catalog_id(resource, backend_name)

    if catalog_id is None:
        # Try to identify the instrument first
        try:
            idn = await im.identify(instrument)
            catalog_id = match_idn(idn.raw)
        except Exception:
            pass

    if catalog_id is None:
        return (
            f"No pymeasure driver available for {resource} "
            f"on {backend_name}.\n\n"
            f"Use instrument_query() and instrument_write() for raw SCPI access.\n\n"
            f"Supported instruments with pymeasure drivers:\n"
            + "\n".join(f"  - {k}: {v}" for k, v in list_supported().items())
        )

    driver_class = get_driver_class(catalog_id)
    if driver_class is None:
        return f"pymeasure driver for {catalog_id} could not be loaded."

    introspection = introspect_instrument(driver_class)
    result = format_for_llm(introspection)

    label = instrument if instrument != resource else resource
    return (
        f"pymeasure driver: {catalog_id} ({driver_class.__name__})\n"
        f"Instrument: {label} ({resource} on {backend_name})\n\n"
        f"Use instrument_get/instrument_set/instrument_call for validated access.\n\n"
        + result
    )


async def instrument_get(
    ctx: Context,
    instrument: str,
    property_name: str,
) -> str:
    """Read a property from an instrument using its pymeasure driver.

    For measurement properties, this triggers a real measurement on the
    instrument. For control properties, this queries the current value.
    pymeasure handles response parsing, unit conversion, and error checking.

    Run instrument_inspect first to see available properties.

    Args:
        instrument: Instrument alias or VISA resource string.
        property_name: Name of the property to read (e.g. "voltage", "source_mode").
    """
    pm = _pm(ctx)
    im = _im(ctx)
    resource, backend_name = im.resolve(instrument)

    def _get():
        inst_obj = pm.get_or_create(resource, backend_name)
        if inst_obj is None:
            raise PyMeasureError(
                f"No pymeasure driver for {resource} on {backend_name}"
            )

        if not hasattr(inst_obj, property_name):
            raise PyMeasureError(
                f"Property '{property_name}' not found on {type(inst_obj).__name__}"
            )

        prop = getattr(type(inst_obj), property_name, None)
        if not isinstance(prop, property):
            raise PyMeasureError(
                f"'{property_name}' is not a property -- use instrument_call for methods"
            )

        if prop.fget is None:
            raise PyMeasureError(
                f"Property '{property_name}' is write-only (setting)"
            )

        return getattr(inst_obj, property_name)

    try:
        value = await asyncio.to_thread(_get)
    except PyMeasureError:
        raise
    except Exception as e:
        raise PyMeasureError(f"Error reading '{property_name}': {e}") from e

    return f"{property_name} = {value!r}"


async def instrument_set(
    ctx: Context,
    instrument: str,
    property_name: str,
    value: str,
) -> str:
    """Set a property on an instrument using its pymeasure driver with validation.

    The value is validated by pymeasure's driver before the command reaches
    the instrument. If the value is out of range or invalid, a clear error
    is returned without sending anything to the instrument -- protecting
    expensive equipment from bad parameters.

    Run instrument_inspect first to see available properties and valid ranges.

    Args:
        instrument: Instrument alias or VISA resource string.
        property_name: Name of the property to set (e.g. "source_current", "voltage_range").
        value: Value to set. Will be parsed as appropriate type (number, string, bool).
    """
    pm = _pm(ctx)
    im = _im(ctx)
    resource, backend_name = im.resolve(instrument)

    def _set():
        inst_obj = pm.get_or_create(resource, backend_name)
        if inst_obj is None:
            raise PyMeasureError(
                f"No pymeasure driver for {resource} on {backend_name}"
            )

        if not hasattr(inst_obj, property_name):
            raise PyMeasureError(
                f"Property '{property_name}' not found on {type(inst_obj).__name__}"
            )

        prop = getattr(type(inst_obj), property_name, None)
        if not isinstance(prop, property):
            raise PyMeasureError(
                f"'{property_name}' is not a property -- use instrument_call for methods"
            )

        if prop.fset is None:
            raise PyMeasureError(
                f"Property '{property_name}' is read-only (measurement)"
            )

        parsed_value = _parse_value(value)
        setattr(inst_obj, property_name, parsed_value)
        return parsed_value

    try:
        parsed = await asyncio.to_thread(_set)
    except PyMeasureError:
        raise
    except ValueError as e:
        raise PyMeasureError(
            f"Validation error for '{property_name}' = {value!r}: {e}"
        ) from e
    except Exception as e:
        raise PyMeasureError(f"Error setting '{property_name}': {e}") from e

    return f"Set {property_name} = {parsed!r}"


async def instrument_call(
    ctx: Context,
    instrument: str,
    method_name: str,
    kwargs_json: str = "{}",
) -> str:
    """Call a high-level method on an instrument using its pymeasure driver.

    Methods encode multi-step SCPI sequences that would otherwise require
    manual construction. For example, apply_voltage() on a Keithley 2400
    configures source mode, range, compliance, and enables output in one call.

    Run instrument_inspect first to see available methods and their parameters.

    Args:
        instrument: Instrument alias or VISA resource string.
        method_name: Name of the method to call (e.g. "apply_voltage", "shutdown").
        kwargs_json: JSON object of keyword arguments (e.g. '{"voltage": 5.0}').
    """
    pm = _pm(ctx)
    im = _im(ctx)
    resource, backend_name = im.resolve(instrument)

    try:
        kwargs = json.loads(kwargs_json)
    except json.JSONDecodeError as e:
        raise PyMeasureError(f"Invalid JSON for kwargs: {e}") from e

    if not isinstance(kwargs, dict):
        raise PyMeasureError("kwargs_json must be a JSON object (dict)")

    def _call():
        inst_obj = pm.get_or_create(resource, backend_name)
        if inst_obj is None:
            raise PyMeasureError(
                f"No pymeasure driver for {resource} on {backend_name}"
            )

        method = getattr(inst_obj, method_name, None)
        if method is None:
            raise PyMeasureError(
                f"Method '{method_name}' not found on {type(inst_obj).__name__}"
            )

        if not callable(method):
            raise PyMeasureError(
                f"'{method_name}' is not callable -- use instrument_get/instrument_set "
                f"for properties"
            )

        return method(**kwargs)

    try:
        result = await asyncio.to_thread(_call)
    except PyMeasureError:
        raise
    except TypeError as e:
        raise PyMeasureError(f"Invalid arguments for {method_name}: {e}") from e
    except Exception as e:
        raise PyMeasureError(f"Error calling {method_name}: {e}") from e

    if result is None:
        return f"Called {method_name}({_format_kwargs(kwargs)})"
    return f"{method_name}({_format_kwargs(kwargs)}) returned: {result!r}"


def _parse_value(value_str: str) -> Any:
    """Parse a string value into the appropriate Python type."""
    if value_str.lower() in ("true", "on", "yes"):
        return True
    if value_str.lower() in ("false", "off", "no"):
        return False

    try:
        if "." not in value_str and "e" not in value_str.lower():
            return int(value_str)
        return float(value_str)
    except ValueError:
        pass

    return value_str


def _format_kwargs(kwargs: dict) -> str:
    """Format kwargs dict as a readable string."""
    if not kwargs:
        return ""
    return ", ".join(f"{k}={v!r}" for k, v in kwargs.items())
