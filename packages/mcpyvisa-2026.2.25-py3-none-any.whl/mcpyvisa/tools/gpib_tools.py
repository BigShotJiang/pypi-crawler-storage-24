"""GPIB-specific tools -- serial poll, SRQ, IFC, trigger, local/remote.

These tools always register but return helpful error messages when used
on non-GPIB backends. All instrument parameters accept either a VISA
resource string or a configured alias.
"""

from fastmcp import Context

from mcpyvisa.instrument_manager import InstrumentManager


def _im(ctx: Context) -> InstrumentManager:
    return ctx.request_context.lifespan_context["instrument_manager"]


async def instrument_clear(ctx: Context, instrument: str) -> str:
    """Send Selected Device Clear (SDC) to an instrument.

    Clears the instrument's input/output buffers and resets its parser.
    This does NOT reset the instrument to defaults (use instrument_reset for that).

    Args:
        instrument: Instrument alias or VISA resource string.
    """
    im = _im(ctx)
    await im.clear(instrument)
    resource, _ = im.resolve(instrument)
    return f"Sent Device Clear to {resource}"


async def serial_poll(
    ctx: Context,
    instrument: str | None = None,
    backend: str | None = None,
) -> str:
    """Serial poll one or all instruments.

    Returns the status byte for each polled instrument. Bit 6 (0x40)
    indicates the device is requesting service (RQS/SRQ).

    Args:
        instrument: Instrument alias or VISA resource to poll.
                    If omitted, polls all instruments on the specified backend.
        backend: Backend name (required when instrument is omitted).
    """
    im = _im(ctx)
    results = await im.serial_poll(instrument=instrument, backend_name=backend)

    if not results:
        return "No instruments to poll."

    lines = ["Serial poll results:"]
    for r in results:
        srq = " [SRQ]" if r.is_requesting_service else ""
        lines.append(
            f"  {r.resource}: status=0x{r.status_byte:02X} "
            f"({r.status_byte}){srq}"
        )
    return "\n".join(lines)


async def check_srq(ctx: Context, backend: str) -> str:
    """Check if the SRQ (Service Request) line is asserted on a GPIB bus.

    If SRQ is asserted, a device is requesting service. Use serial_poll
    to identify which device.

    This operation is GPIB-specific. On non-GPIB backends, returns a
    helpful error message.

    Args:
        backend: Name of the backend to check.
    """
    im = _im(ctx)
    asserted = await im.check_srq(backend)

    if asserted:
        return (
            f"SRQ ASSERTED on {backend} -- "
            f"a device is requesting service. Use serial_poll to identify which one."
        )
    return f"SRQ not asserted on {backend}"


async def bus_trigger(
    ctx: Context,
    instruments: list[str] | None = None,
) -> str:
    """Send Group Execute Trigger (GET) to instruments.

    Args:
        instruments: List of instrument aliases or VISA resource strings.
    """
    im = _im(ctx)
    await im.trigger(instruments=instruments)
    return f"Triggered {len(instruments or [])} instrument(s)"


async def interface_clear(ctx: Context, backend: str) -> str:
    """Assert Interface Clear (IFC) -- become Controller-In-Charge.

    This resets all bus interfaces to their idle state. Use when taking
    control of the bus or recovering from a hung state.

    WARNING: If another controller is on the bus, this overrides it.

    This operation is GPIB/AR488-specific. On non-AR488 backends,
    returns a helpful error message.

    Args:
        backend: Name of the backend.
    """
    im = _im(ctx)
    await im.send_ifc(backend)
    return f"IFC asserted on {backend} -- this backend is now Controller-In-Charge"


async def instrument_local(ctx: Context, instrument: str) -> str:
    """Return an instrument to local (front panel) control.

    Sends Go To Local (GTL) so the operator can use the front panel again.

    Args:
        instrument: Instrument alias or VISA resource string.
    """
    im = _im(ctx)
    await im.go_to_local(instrument)
    resource, _ = im.resolve(instrument)
    return f"{resource} returned to local control"


async def instrument_remote(
    ctx: Context,
    instrument: str,
    lockout: bool = False,
) -> str:
    """Put an instrument in remote mode.

    Asserts Remote Enable (REN). With lockout=True, also sends Local
    Lockout (LLO) to prevent front panel operation.

    Args:
        instrument: Instrument alias or VISA resource string.
        lockout: If True, lock out the front panel.
    """
    im = _im(ctx)
    await im.set_remote(instrument, lockout=lockout)
    resource, _ = im.resolve(instrument)
    mode = "remote + lockout" if lockout else "remote"
    return f"{resource} set to {mode}"
