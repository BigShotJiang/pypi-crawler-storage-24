"""Data models for mcpyvisa.

Pure Pydantic models -- no I/O, no side effects. They represent the state
of backends, instruments, and bus topology as seen by MCP clients.

Key change from mcgpib: instruments are identified by VISA resource strings
(e.g. "GPIB0::22::INSTR") rather than (bridge_name, address) tuples.
"""

from enum import StrEnum

from pydantic import BaseModel, Field


class BackendType(StrEnum):
    ar488 = "ar488"
    pyvisa_py = "pyvisa-py"
    system = "system"
    sim = "sim"


class ConnectionState(StrEnum):
    disconnected = "disconnected"
    connecting = "connecting"
    connected = "connected"
    error = "error"


class BackendInfo(BaseModel):
    """Summary of a configured backend and its connection state."""

    name: str = Field(description="User-assigned backend name from config")
    type: BackendType
    connection_state: ConnectionState = ConnectionState.disconnected
    resource_count: int = Field(default=0, description="Number of discovered resources")
    firmware_version: str | None = Field(
        default=None, description="AR488 firmware version (AR488 backends only)"
    )
    transport_detail: str = Field(
        default="", description="Transport info, e.g. '/dev/ttyUSB0 @ 115200'"
    )
    error_message: str | None = Field(
        default=None, description="Last error if connection_state is 'error'"
    )


class InstrumentIdentity(BaseModel):
    """Parsed *IDN? response per IEEE 488.2 section 10.14."""

    manufacturer: str = ""
    model: str = ""
    serial_number: str = ""
    firmware_version: str = ""
    raw: str = Field(description="Original unparsed *IDN? response")

    @classmethod
    def from_idn_string(cls, raw: str) -> "InstrumentIdentity":
        """Parse a comma-separated *IDN? response.

        Expected format: Manufacturer,Model,Serial,FirmwareVersion
        Some instruments omit fields or use different separators.
        """
        parts = [p.strip() for p in raw.split(",")]
        return cls(
            manufacturer=parts[0] if len(parts) > 0 else "",
            model=parts[1] if len(parts) > 1 else "",
            serial_number=parts[2] if len(parts) > 2 else "",
            firmware_version=parts[3] if len(parts) > 3 else "",
            raw=raw,
        )


class InstrumentInfo(BaseModel):
    """An instrument discovered on any backend."""

    resource: str = Field(description="VISA resource string (universal identifier)")
    alias: str | None = Field(default=None, description="Friendly name from config")
    backend_name: str = Field(description="Which backend this instrument is on")
    identity: InstrumentIdentity | None = Field(
        default=None, description="Parsed *IDN? response, if available"
    )
    interface_type: str = Field(
        default="", description="Interface type: GPIB, TCPIP, USB, ASRL"
    )
    pymeasure_driver: str | None = Field(
        default=None,
        description="pymeasure driver class name if available (e.g. 'Keithley2400')",
    )


class SerialPollResult(BaseModel):
    """Result of a serial poll operation."""

    resource: str = Field(description="VISA resource string of polled instrument")
    status_byte: int
    is_requesting_service: bool = Field(
        description="True if bit 6 (RQS) is set in the status byte"
    )

    @classmethod
    def from_status(cls, resource: str, status_byte: int) -> "SerialPollResult":
        return cls(
            resource=resource,
            status_byte=status_byte,
            is_requesting_service=bool(status_byte & 0x40),
        )


class ServerStatus(BaseModel):
    """Overall server health."""

    version: str
    backends_configured: int
    backends_connected: int
    total_instruments: int
    backend_summaries: list[BackendInfo] = Field(default_factory=list)
