"""Central orchestrator -- routes all instrument I/O through pyvisa.

InstrumentManager replaces mcgpib's BridgeManager. Instead of holding
BridgeConnection objects (AR488-specific), it holds pyvisa ResourceManager
instances (universal). Any pyvisa backend works: AR488, pyvisa-py, NI-VISA.

All pyvisa calls are synchronous and wrapped in asyncio.to_thread() for
non-blocking async operation. This is simpler than the old bridge-mode
run_coroutine_threadsafe() dance.
"""

import asyncio
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

import pyvisa

from mcpyvisa import __version__
from mcpyvisa.config import AppConfig, BackendConfig
from mcpyvisa.errors import (
    BackendError,
    BackendNotFoundError,
    CapabilityError,
    InstrumentError,
    InstrumentNotFoundError,
    TimeoutError,  # noqa: A004
)
from mcpyvisa.models import (
    BackendInfo,
    BackendType,
    ConnectionState,
    InstrumentIdentity,
    InstrumentInfo,
    SerialPollResult,
    ServerStatus,
)

logger = logging.getLogger(__name__)

# Regex for VISA resource strings: contains :: separator
_VISA_RESOURCE_RE = re.compile(r"::")


@dataclass
class BackendState:
    """Runtime state for a configured backend."""

    config: BackendConfig
    rm: pyvisa.ResourceManager | None = None
    connection_state: ConnectionState = ConnectionState.disconnected
    firmware_version: str | None = None
    error_message: str | None = None
    discovered_resources: list[str] = field(default_factory=list)
    instruments: list[InstrumentInfo] = field(default_factory=list)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class InstrumentManager:
    """Central orchestrator -- routes instrument I/O through pyvisa."""

    def __init__(self, config: AppConfig):
        self._config = config
        self._backends: dict[str, BackendState] = {}
        self._aliases: dict[str, tuple[str, str]] = {}  # alias -> (resource, backend_name)
        self._identities: dict[str, InstrumentIdentity] = {}  # resource@backend -> identity

        # Initialize backend states from config
        for bc in config.backend:
            self._backends[bc.name] = BackendState(config=bc)

        # Load instrument aliases
        for alias, inst_alias in config.instruments.items():
            self._aliases[alias] = (inst_alias.resource, inst_alias.backend)

    # --- Resolution ---

    def resolve(self, instrument: str) -> tuple[str, str]:
        """Resolve an instrument identifier to (visa_resource, backend_name).

        Resolution order:
        1. VISA resource string (contains ::) -> search backends for it
        2. Configured alias -> resolve to mapped resource + backend
        3. Error with helpful message listing known instruments

        Returns:
            Tuple of (visa_resource_string, backend_name)
        """
        # 1. Full VISA resource string
        if _VISA_RESOURCE_RE.search(instrument):
            backend_name = self._find_backend_for_resource(instrument)
            if backend_name:
                return (instrument, backend_name)
            # If only one backend is configured, use it
            if len(self._backends) == 1:
                return (instrument, next(iter(self._backends)))
            raise InstrumentNotFoundError(
                f"Resource {instrument!r} not found on any connected backend. "
                f"Available backends: {', '.join(self._backends.keys())}"
            )

        # 2. Alias lookup
        if instrument in self._aliases:
            return self._aliases[instrument]

        # 3. Error
        known = []
        for alias, (res, be) in self._aliases.items():
            known.append(f"  {alias} -> {res} ({be})")
        for name, state in self._backends.items():
            for inst in state.instruments:
                if inst.alias:
                    continue  # Already listed
                known.append(f"  {inst.resource} ({name})")

        hint = "\n".join(known) if known else "  (none -- run discover_instruments first)"
        raise InstrumentNotFoundError(
            f"Unknown instrument {instrument!r}. Known instruments:\n{hint}"
        )

    def _find_backend_for_resource(self, resource: str) -> str | None:
        """Find which backend owns a resource (from discovered instruments)."""
        for name, state in self._backends.items():
            if resource in state.discovered_resources:
                return name
            for inst in state.instruments:
                if inst.resource == resource:
                    return name
        return None

    # --- Backend lifecycle ---

    def _get_backend(self, name: str) -> BackendState:
        state = self._backends.get(name)
        if state is None:
            available = ", ".join(self._backends.keys()) or "(none)"
            raise BackendNotFoundError(
                f"No backend named {name!r}. Available: {available}"
            )
        return state

    async def connect_backend(self, name: str) -> BackendInfo:
        """Connect to a backend and initialize its pyvisa ResourceManager."""
        state = self._get_backend(name)

        async with state._lock:
            state.connection_state = ConnectionState.connecting
            state.error_message = None

            try:
                rm = await asyncio.to_thread(self._create_rm, state.config)
                state.rm = rm
                state.connection_state = ConnectionState.connected

                # For AR488: extract firmware version
                if state.config.type == BackendType.ar488:
                    state.firmware_version = await self._ar488_get_version(state)

                logger.info(
                    "Connected backend %s (%s)",
                    name,
                    state.config.type.value,
                )

            except Exception as e:
                state.connection_state = ConnectionState.error
                state.error_message = str(e)
                raise BackendError(f"Failed to connect backend {name!r}: {e}") from e

        # Auto-discover if configured
        if state.config.auto_discover:
            try:
                await self.discover(backend_name=name)
            except Exception as e:
                logger.warning("Auto-discover failed on %s: %s", name, e)

        return self._backend_info(state)

    async def disconnect_backend(self, name: str) -> None:
        """Disconnect a backend and clean up."""
        state = self._get_backend(name)

        async with state._lock:
            if state.rm is not None:
                try:
                    await asyncio.to_thread(state.rm.close)
                except Exception as e:
                    logger.warning("Error closing ResourceManager for %s: %s", name, e)
                state.rm = None

            state.connection_state = ConnectionState.disconnected
            state.firmware_version = None
            state.discovered_resources.clear()
            state.instruments.clear()

            # Clear cached identities for this backend
            keys_to_remove = [
                k for k in self._identities if k.endswith(f"@{name}")
            ]
            for k in keys_to_remove:
                del self._identities[k]

        logger.info("Disconnected backend %s", name)

    async def disconnect_all(self) -> None:
        """Disconnect all backends. Called during server shutdown."""
        for name in list(self._backends.keys()):
            try:
                await self.disconnect_backend(name)
            except Exception as e:
                logger.warning("Error disconnecting backend %s: %s", name, e)

    # --- ResourceManager creation ---

    def _create_rm(self, config: BackendConfig) -> pyvisa.ResourceManager:
        """Create a pyvisa ResourceManager for the given backend config.

        Called from a thread via asyncio.to_thread().
        """
        if config.type == BackendType.ar488:
            return self._create_ar488_rm(config)
        elif config.type == BackendType.pyvisa_py:
            return pyvisa.ResourceManager("@py")
        elif config.type == BackendType.system:
            return pyvisa.ResourceManager()
        elif config.type == BackendType.sim:
            return self._create_sim_rm(config)
        else:
            raise BackendError(f"Unknown backend type: {config.type}")

    def _create_ar488_rm(self, config: BackendConfig) -> pyvisa.ResourceManager:
        """Create a pyvisa ResourceManager with pyvisa-ar488 backend."""
        from pyvisa_ar488 import AR488VisaLibrary

        transport = config.transport or "serial"

        if transport == "serial":
            if not config.port:
                raise BackendError(
                    f"AR488 backend {config.name!r} with serial transport "
                    f"requires 'port' setting"
                )
            lib = AR488VisaLibrary.from_serial(
                port=config.port,
                baudrate=config.baudrate,
                read_timeout_ms=config.read_timeout_ms,
            )
        elif transport == "tcp":
            if not config.host:
                raise BackendError(
                    f"AR488 backend {config.name!r} with tcp transport "
                    f"requires 'host' setting"
                )
            lib = AR488VisaLibrary.from_tcp(
                host=config.host,
                port=config.tcp_port,
                read_timeout_ms=config.read_timeout_ms,
            )
        else:
            raise BackendError(
                f"AR488 backend {config.name!r}: unknown transport {transport!r}"
            )

        return pyvisa.ResourceManager(lib)

    def _create_sim_rm(self, config: BackendConfig) -> pyvisa.ResourceManager:
        """Create a pyvisa ResourceManager with pyvisa-sim backend."""
        if config.sim_file is None:
            raise BackendError(
                f"Sim backend {config.name!r} requires 'sim_file' pointing to a YAML definition"
            )
        sim_path = Path(config.sim_file).expanduser().resolve()
        if not sim_path.is_file():
            raise BackendError(f"Sim definition file not found: {sim_path}")
        try:
            return pyvisa.ResourceManager(f"{sim_path}@sim")
        except Exception as e:
            if "sim" in str(e).lower():
                raise BackendError(
                    "pyvisa-sim not installed. Install with: uv add mcpyvisa[sim]"
                ) from e
            raise BackendError(f"Failed to create sim backend: {e}") from e

    # --- Discovery ---

    async def discover(self, backend_name: str | None = None) -> list[InstrumentInfo]:
        """Discover instruments on one or all backends.

        Returns a flat list of InstrumentInfo across all queried backends.
        """
        all_instruments: list[InstrumentInfo] = []

        backends_to_scan = (
            [self._get_backend(backend_name)]
            if backend_name
            else list(self._backends.values())
        )

        for state in backends_to_scan:
            if state.connection_state != ConnectionState.connected:
                continue

            async with state._lock:
                try:
                    resources = await asyncio.to_thread(
                        state.rm.list_resources
                    )
                    state.discovered_resources = list(resources)
                except Exception as e:
                    logger.warning(
                        "list_resources failed on %s: %s",
                        state.config.name, e,
                    )
                    state.discovered_resources = []
                    continue

                instruments: list[InstrumentInfo] = []
                for resource in state.discovered_resources:
                    iface = _interface_type(resource)
                    alias = self._find_alias(resource, state.config.name)

                    info = InstrumentInfo(
                        resource=resource,
                        alias=alias,
                        backend_name=state.config.name,
                        interface_type=iface,
                    )

                    # Auto-identify if configured
                    if state.config.auto_identify:
                        try:
                            identity = await self._identify_resource(state, resource)
                            info.identity = identity
                        except Exception as e:
                            logger.debug(
                                "IDN failed for %s on %s: %s",
                                resource, state.config.name, e,
                            )

                    instruments.append(info)

                state.instruments = instruments
                all_instruments.extend(instruments)

        return all_instruments

    # --- Instrument I/O ---

    async def query(self, instrument: str, command: str) -> str:
        """Send a query and return the response."""
        resource, backend_name = self.resolve(instrument)
        state = self._get_backend(backend_name)
        self._ensure_connected(state)

        async with state._lock:
            try:
                return await asyncio.to_thread(
                    self._visa_query, state.rm, resource, command
                )
            except pyvisa.errors.VisaIOError as e:
                if "timeout" in str(e).lower():
                    raise TimeoutError(
                        f"Timeout querying {resource}: {command}"
                    ) from e
                raise InstrumentError(
                    f"Error querying {resource}: {e}"
                ) from e

    async def write(self, instrument: str, command: str) -> None:
        """Send a command with no response expected."""
        resource, backend_name = self.resolve(instrument)
        state = self._get_backend(backend_name)
        self._ensure_connected(state)

        async with state._lock:
            try:
                await asyncio.to_thread(
                    self._visa_write, state.rm, resource, command
                )
            except pyvisa.errors.VisaIOError as e:
                raise InstrumentError(
                    f"Error writing to {resource}: {e}"
                ) from e

    async def identify(self, instrument: str) -> InstrumentIdentity:
        """Send *IDN? and return parsed identity."""
        resource, backend_name = self.resolve(instrument)
        state = self._get_backend(backend_name)
        self._ensure_connected(state)

        async with state._lock:
            identity = await self._identify_resource(state, resource)

        # Cache the identity
        cache_key = f"{resource}@{backend_name}"
        self._identities[cache_key] = identity

        # Update the instrument info if discovered
        for inst in state.instruments:
            if inst.resource == resource:
                inst.identity = identity
                break

        return identity

    async def read_stb(self, instrument: str) -> int:
        """Read the status byte via serial poll."""
        resource, backend_name = self.resolve(instrument)
        state = self._get_backend(backend_name)
        self._ensure_connected(state)

        async with state._lock:
            try:
                return await asyncio.to_thread(
                    self._visa_read_stb, state.rm, resource
                )
            except pyvisa.errors.VisaIOError as e:
                raise InstrumentError(
                    f"Serial poll failed for {resource}: {e}"
                ) from e

    async def clear(self, instrument: str) -> None:
        """Send Selected Device Clear to an instrument."""
        resource, backend_name = self.resolve(instrument)
        state = self._get_backend(backend_name)
        self._ensure_connected(state)

        async with state._lock:
            try:
                await asyncio.to_thread(
                    self._visa_clear, state.rm, resource
                )
            except pyvisa.errors.VisaIOError as e:
                raise InstrumentError(
                    f"Clear failed for {resource}: {e}"
                ) from e

    async def trigger(self, instruments: list[str] | None = None) -> None:
        """Send Group Execute Trigger to instrument(s)."""
        if not instruments:
            raise InstrumentError("No instruments specified for trigger")

        for instrument in instruments:
            resource, backend_name = self.resolve(instrument)
            state = self._get_backend(backend_name)
            self._ensure_connected(state)

            async with state._lock:
                try:
                    await asyncio.to_thread(
                        self._visa_trigger, state.rm, resource
                    )
                except pyvisa.errors.VisaIOError as e:
                    raise InstrumentError(
                        f"Trigger failed for {resource}: {e}"
                    ) from e

    # --- GPIB-specific operations ---

    async def serial_poll(
        self,
        instrument: str | None = None,
        backend_name: str | None = None,
    ) -> list[SerialPollResult]:
        """Serial poll one or all instruments on a backend."""
        if instrument:
            resource, be_name = self.resolve(instrument)
            stb = await self.read_stb(instrument)
            return [SerialPollResult.from_status(resource, stb)]

        if not backend_name:
            raise BackendError("Specify either instrument or backend_name for serial_poll")

        state = self._get_backend(backend_name)
        self._ensure_connected(state)

        results: list[SerialPollResult] = []
        for inst in state.instruments:
            try:
                async with state._lock:
                    stb = await asyncio.to_thread(
                        self._visa_read_stb, state.rm, inst.resource
                    )
                results.append(SerialPollResult.from_status(inst.resource, stb))
            except Exception as e:
                logger.debug("Serial poll failed for %s: %s", inst.resource, e)
        return results

    async def check_srq(self, backend_name: str) -> bool:
        """Check if SRQ line is asserted (AR488/GPIB only)."""
        state = self._get_backend(backend_name)
        self._ensure_connected(state)
        self._require_ar488(state, "check_srq")

        async with state._lock:
            return await asyncio.to_thread(self._ar488_check_srq, state)

    async def send_ifc(self, backend_name: str) -> None:
        """Assert Interface Clear (GPIB bus reset)."""
        state = self._get_backend(backend_name)
        self._ensure_connected(state)
        self._require_ar488(state, "send_ifc")

        async with state._lock:
            await asyncio.to_thread(self._ar488_send_ifc, state)

    async def go_to_local(self, instrument: str) -> None:
        """Return an instrument to local (front panel) control."""
        resource, backend_name = self.resolve(instrument)
        state = self._get_backend(backend_name)
        self._ensure_connected(state)

        async with state._lock:
            try:
                await asyncio.to_thread(
                    self._visa_go_to_local, state.rm, resource
                )
            except pyvisa.errors.VisaIOError as e:
                raise InstrumentError(
                    f"Go to local failed for {resource}: {e}"
                ) from e

    async def set_remote(self, instrument: str, lockout: bool = False) -> None:
        """Put an instrument in remote mode."""
        resource, backend_name = self.resolve(instrument)
        state = self._get_backend(backend_name)
        self._ensure_connected(state)

        async with state._lock:
            try:
                await asyncio.to_thread(
                    self._visa_set_remote, state.rm, resource, lockout
                )
            except pyvisa.errors.VisaIOError as e:
                raise InstrumentError(
                    f"Set remote failed for {resource}: {e}"
                ) from e

    # --- AR488-specific operations ---

    async def ar488_command(self, backend_name: str, command: str) -> str | None:
        """Send a raw ++ command to an AR488 backend."""
        state = self._get_backend(backend_name)
        self._ensure_connected(state)
        self._require_ar488(state, "ar488_command")

        async with state._lock:
            return await asyncio.to_thread(
                self._ar488_raw_command, state, command
            )

    async def ar488_xdiag(self, backend_name: str, mode: int, value: int) -> None:
        """Run AR488 bus diagnostics via ++xdiag."""
        state = self._get_backend(backend_name)
        self._ensure_connected(state)
        self._require_ar488(state, "ar488_xdiag")

        async with state._lock:
            await asyncio.to_thread(
                self._ar488_raw_command, state, f"++xdiag {mode} {value}"
            )

    # --- Status ---

    def get_server_status(self) -> ServerStatus:
        summaries = [self._backend_info(s) for s in self._backends.values()]
        return ServerStatus(
            version=__version__,
            backends_configured=len(self._backends),
            backends_connected=sum(
                1 for s in self._backends.values()
                if s.connection_state == ConnectionState.connected
            ),
            total_instruments=sum(
                len(s.instruments) for s in self._backends.values()
            ),
            backend_summaries=summaries,
        )

    def list_instruments(self, backend_name: str | None = None) -> list[InstrumentInfo]:
        """List all discovered instruments, optionally filtered by backend."""
        instruments: list[InstrumentInfo] = []
        for name, state in self._backends.items():
            if backend_name and name != backend_name:
                continue
            instruments.extend(state.instruments)
        return instruments

    def get_identity(self, instrument: str) -> InstrumentIdentity | None:
        """Get cached identity for an instrument."""
        try:
            resource, backend_name = self.resolve(instrument)
        except InstrumentNotFoundError:
            return None
        return self._identities.get(f"{resource}@{backend_name}")

    # --- Internal helpers ---

    def _ensure_connected(self, state: BackendState) -> None:
        if state.connection_state != ConnectionState.connected or state.rm is None:
            raise BackendError(
                f"Backend {state.config.name!r} is not connected. "
                f"Call connect_backend({state.config.name!r}) first."
            )

    def _require_ar488(self, state: BackendState, operation: str) -> None:
        if state.config.type != BackendType.ar488:
            raise CapabilityError(
                f"Operation '{operation}' requires an AR488 backend, "
                f"but {state.config.name!r} is type {state.config.type.value!r}. "
                f"AR488-specific operations only work with AR488/Prologix adapters."
            )

    def _backend_info(self, state: BackendState) -> BackendInfo:
        detail = ""
        if state.config.type == BackendType.ar488:
            transport = state.config.transport or "serial"
            if transport == "serial" and state.config.port:
                detail = f"{state.config.port} @ {state.config.baudrate}"
            elif transport == "tcp" and state.config.host:
                detail = f"{state.config.host}:{state.config.tcp_port}"
        elif state.config.type == BackendType.pyvisa_py:
            detail = "pyvisa-py (USB-TMC, LAN, serial)"
        elif state.config.type == BackendType.system:
            detail = "system VISA (NI-VISA, Keysight IO)"
        elif state.config.type == BackendType.sim:
            detail = f"simulated ({state.config.sim_file})"

        return BackendInfo(
            name=state.config.name,
            type=state.config.type,
            connection_state=state.connection_state,
            resource_count=len(state.instruments),
            firmware_version=state.firmware_version,
            transport_detail=detail,
            error_message=state.error_message,
        )

    def _find_alias(self, resource: str, backend_name: str) -> str | None:
        """Find a configured alias for a resource on a backend."""
        for alias, (res, be) in self._aliases.items():
            if res == resource and be == backend_name:
                return alias
        return None

    # --- Synchronous pyvisa operations (called via to_thread) ---

    @staticmethod
    def _visa_query(rm: pyvisa.ResourceManager, resource: str, command: str) -> str:
        inst = rm.open_resource(resource)
        try:
            return inst.query(command).strip()
        finally:
            inst.close()

    @staticmethod
    def _visa_write(rm: pyvisa.ResourceManager, resource: str, command: str) -> None:
        inst = rm.open_resource(resource)
        try:
            inst.write(command)
        finally:
            inst.close()

    @staticmethod
    def _visa_read_stb(rm: pyvisa.ResourceManager, resource: str) -> int:
        inst = rm.open_resource(resource)
        try:
            return inst.read_stb()
        finally:
            inst.close()

    @staticmethod
    def _visa_clear(rm: pyvisa.ResourceManager, resource: str) -> None:
        inst = rm.open_resource(resource)
        try:
            inst.clear()
        finally:
            inst.close()

    @staticmethod
    def _visa_trigger(rm: pyvisa.ResourceManager, resource: str) -> None:
        inst = rm.open_resource(resource)
        try:
            inst.assert_trigger()
        finally:
            inst.close()

    @staticmethod
    def _visa_go_to_local(rm: pyvisa.ResourceManager, resource: str) -> None:
        inst = rm.open_resource(resource)
        try:
            inst.control_ren(
                pyvisa.constants.RENLineOperation.deassert_gtl
            )
        finally:
            inst.close()

    @staticmethod
    def _visa_set_remote(
        rm: pyvisa.ResourceManager, resource: str, lockout: bool
    ) -> None:
        inst = rm.open_resource(resource)
        try:
            if lockout:
                inst.control_ren(
                    pyvisa.constants.RENLineOperation.assert_address_llockout
                )
            else:
                inst.control_ren(
                    pyvisa.constants.RENLineOperation.assert_address
                )
        finally:
            inst.close()

    async def _identify_resource(
        self, state: BackendState, resource: str
    ) -> InstrumentIdentity:
        """Send *IDN? to a resource and return parsed identity."""
        try:
            raw = await asyncio.to_thread(
                self._visa_query, state.rm, resource, "*IDN?"
            )
            return InstrumentIdentity.from_idn_string(raw)
        except Exception as e:
            raise InstrumentError(
                f"Identification failed for {resource}: {e}"
            ) from e

    async def _ar488_get_version(self, state: BackendState) -> str | None:
        """Get AR488 firmware version."""
        try:
            return await asyncio.to_thread(
                self._ar488_raw_command, state, "++ver"
            )
        except Exception as e:
            logger.debug("Could not get AR488 version: %s", e)
            return None

    @staticmethod
    def _ar488_raw_command(state: BackendState, command: str) -> str | None:
        """Send a raw ++ command via the AR488 pyvisa-ar488 backend.

        Accesses the underlying AR488VisaLibrary through the ResourceManager.
        """
        lib = state.rm.visalib
        # pyvisa-ar488's AR488VisaLibrary exposes raw_command
        if hasattr(lib, "raw_command"):
            return lib.raw_command(command)
        return None

    @staticmethod
    def _ar488_check_srq(state: BackendState) -> bool:
        """Check SRQ via AR488 backend."""
        lib = state.rm.visalib
        if hasattr(lib, "raw_command"):
            result = lib.raw_command("++srq")
            return result == "1" if result else False
        return False

    @staticmethod
    def _ar488_send_ifc(state: BackendState) -> None:
        """Send IFC via AR488 backend."""
        lib = state.rm.visalib
        if hasattr(lib, "raw_command"):
            lib.raw_command("++ifc")


def _interface_type(resource: str) -> str:
    """Extract the interface type from a VISA resource string."""
    upper = resource.upper()
    if upper.startswith("GPIB"):
        return "GPIB"
    elif upper.startswith("TCPIP"):
        return "TCPIP"
    elif upper.startswith("USB"):
        return "USB"
    elif upper.startswith("ASRL"):
        return "ASRL"
    return ""
