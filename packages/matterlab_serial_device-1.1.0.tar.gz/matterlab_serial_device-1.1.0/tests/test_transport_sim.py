from matterlab_serial_device import ScriptedSerialTransport, SerialDevice


def scripted_transport_factory(config):
    return ScriptedSerialTransport(
        config,
        response_map={
            b"PING\r\n": b"PONG",
            b"STATUS\r\n": b"READY",
        },
    )


def test_scripted_transport_query_returns_scripted_response():
    device = SerialDevice(com_port="SIM::loopback", transport_factory=scripted_transport_factory)

    response = device.query("PING\r\n", read_delay=0)

    assert response == "PONG"


def test_scripted_transport_tracks_write_history():
    device = SerialDevice(com_port="SIM::loopback", transport_factory=scripted_transport_factory)

    device.query("STATUS\r\n", read_delay=0)

    assert device.transport.write_history == [b"STATUS\r\n"]
