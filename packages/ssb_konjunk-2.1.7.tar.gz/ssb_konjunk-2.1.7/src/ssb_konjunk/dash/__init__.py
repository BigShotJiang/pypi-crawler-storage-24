"""422 dash framework."""
