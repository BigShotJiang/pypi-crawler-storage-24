from __future__ import annotations

import ast
import inspect
from enum import Enum
from typing import Annotated, Any, Dict, List, Literal, Optional, Union, get_args, TYPE_CHECKING, TypedDict
from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from veri_agents_aiware.content_intelligence.plan import Plan

ConstraintRelation = Literal["BEFORE", "AFTER", "OVERLAPS", "WITHIN"]

# ---------------------------
# Time window helper types
# ---------------------------


class MediaTime(BaseModel):
    """Relative to the media's own timeline (seconds)."""

    from_s: Optional[float] = None
    to_s: Optional[float] = None


class AbsTime(BaseModel):
    """Wall-clock constraints for selecting WHICH media (ISO strings or epoch seconds)."""

    from_iso: Optional[str] = None
    to_iso: Optional[str] = None
    from_epoch_s: Optional[float] = None
    to_epoch_s: Optional[float] = None


# -----------------------------
# Find Ops (base NOT exported)
# -----------------------------


class _FindOpBase(BaseModel):
    """Common fields for all FIND_* ops. Not exposed to the LLM union."""

    output: str
    media_time: Optional[MediaTime] = None
    abs_time: Optional[AbsTime] = None


# ---------------------------
# Concrete FIND ops
# ---------------------------

class SearchMode(str, Enum):
    SEMANTIC = "semantic"
    KEYWORD_WINDOW = "keyword_window"
    KEYWORD_HIT = "keyword_hit"


class FindTranscriptOp(_FindOpBase):
    """
    Search through transcripts using conceptual understanding or exact string matching.
    """
    op: Literal["find_transcript"] = "find_transcript"

    query: str = Field(
        ...,
        description=(
            "The search string. For semantic search, use natural language describing the topic. "
            "For keyword search, use boolean logic (AND, OR, NOT), double quotes for exact phrases, and parentheses for grouping. "
            "IMPORTANT: Boolean operators MUST be uppercase. "
            "CRITICAL WARNING FOR TRANSCRIPTS: Spoken language is messy and unpredictable. "
            "When using keyword search for conceptual topics, DO NOT over-constrain with strict 'AND' clauses (e.g., avoid '(started OR began) AND (career OR job)'). "
            "Instead, cast a wide net using broad 'OR' clauses of actual words the speaker might say (e.g., 'started OR began OR \"first job\" OR originally'). "
            "Only use 'AND' when intersecting highly specific entities like proper names or companies."
        ),
        examples=[
            "discussions about economic policy",
            'started OR began OR "first job" OR originally',  # <-- Shows a broad conceptual OR search
            '"John Smith" AND (politics OR election)',        # <-- Shows AND is for entities
            'CNN OR MSNBC OR "Fox News"',
        ]
    )

    search_mode: SearchMode = Field(
        default=SearchMode.SEMANTIC,
        description=(
            "The retrieval engine and result shape:\n"
            "1. 'semantic' (Default): Uses AI embeddings. Returns paragraphs of context. "
            "Best for 'What did they say about X?' or 'Summarize the discussion'.\n"
            "2. 'keyword_window': Uses exact string matching. Returns the paragraph/context surrounding the match. "
            "Best for 'Read me the context where they mentioned John'.\n"
            "3. 'keyword_hit': Uses exact string matching. Returns ONLY the sub-second timestamp of the specific word. "
            "MUST USE for counting: 'How many times did they say Y?' or 'At what exact second did Z happen?'\n"
            "(Note: Keyword modes support uppercase AND, OR, NOT logic and exact \"phrases\")."
        )
    )
    # speaker: Optional[str] = None


# Also see https://veritone.atlassian.net/browse/VE-18978
# The keyword search for documents in aiWARE doesn't provide suitable output for our purposes,
# so for now we will only support semantic search for documents.
# We will add keyword search back when the platform supports it in a way that meets our needs.
# So in this class, things are commented out now and the search_mode is fixed to semantic.
class FindTextOp(_FindOpBase):
    """
    Search through textual content from ingested documents using
    conceptual understanding (embedding-based semantic search).
    """
    op: Literal["find_text"] = "find_text"

    query: str = Field(
        ...,
        description=(
            "The search string. For semantic search, use natural language describing the topic. "
            # "For keyword search, use boolean logic (AND, OR, NOT), double quotes for exact phrases, and parentheses for grouping. "
            # "IMPORTANT: Boolean operators MUST be uppercase. "
            # "WARNING FOR DOCUMENTS: Authors use varied vocabulary. When using keyword search for concepts, "
            # "avoid over-constraining with strict 'AND' clauses which often yield zero results. "
            # "Favor broad 'OR' clauses to capture synonyms (e.g., 'revenue OR income OR profit'). "
            # "Reserve strict 'AND' clauses primarily for intersecting specific entities with a topic."
        ),
        # examples=[
        #     "sections discussing risk factors",
        #     '"revenue growth" OR profitability OR "increased sales"', # <-- Shows capturing synonyms
        #     '"Apple Inc." AND (lawsuit OR litigation OR court)',      # <-- Entity intersection
        #     'GDPR OR "data protection" OR CCPA',
        # ]
    )

    search_mode: Literal[SearchMode.SEMANTIC] = SearchMode.SEMANTIC
    # search_mode: SearchMode = Field(
    #     default=SearchMode.SEMANTIC,
    #     description=(
    #         "Determines the retrieval engine: "
    #         "1. 'semantic': Use for broad topics, concepts, or 'aboutness' (e.g., 'sections about compliance'). "
    #         "2. 'keyword': Use for precise mentions, proper nouns, acronyms, or counting occurrences. "
    #         "Supports boolean logic (AND, OR, NOT - must be uppercase), exact phrases in quotes, "
    #         "and grouping with parentheses."
    #     )
    # )

    granularity: Literal["token", "window"] = Field(
        default="window",
        description=(
            "Granularity of search results: "
            "'window' (returns larger text blocks, e.g., paragraphs), "
            "'token' (returns smaller fixed token chunks). "
        )
    )


class FindFaceOp(_FindOpBase):
    # TODO: do we want to be able to provide multiple entityIds?
    """Find specific faces/persons. Use this if given an entity ID or name."""

    op: Literal["find_face"] = "find_face"
    where: Dict[str, Any] = Field(
        default_factory=dict,
        description='Search criteria for finding faces. Can be by {"entityId":"..."} or {"name":"..."}.',
    )
    #min_score: float = 0.0


class FindLogoOp(_FindOpBase):
    """Find specific logos/brands. Use this if given an entity ID or name."""

    op: Literal["find_logo"] = "find_logo"
    where: Dict[str, Any] = Field(
        default_factory=dict,
        description='Search criteria for finding logos. Can be by {"entityId":"..."} or {"name":"..."}.',
    )


# (Optional future)
# class FindObjectOp(_FindOpBase): ...
# class FindOcrOp(_FindOpBase): ...


# ---------------------------
# GET_* ops
# ---------------------------


class GetFacesOp(BaseModel):
    """Get all occurrences of faces/persons in the target media, producing segments. 
       If you need unique occurrences, use the aggregate operation after this.
       Use this if you don't have a specific name or entity ID.
       
       Use tdo_ids to scope to specific media files. Can be a list of IDs or a table alias
       containing a 'tdo_id' column (e.g., output from a FilterOp on _tdo_metadata).
    """

    op: Literal["get_faces"] = "get_faces"
    output: str
    tdo_ids: Optional[Union[List[str], str]] = Field(
        default=None,
        description=(
            "Optional: Scope operation to specific TDO IDs. Can be a list of ID strings "
            "or a table alias (string) containing a 'tdo_id' column. If not provided, "
            "uses the runtime target."
        )
    )


class GetLogosOp(BaseModel):
    """Get all logo occurrences in the target media, producing segments.
       If you need unique occurrences, use the aggregate operation after this.
       Use this if you don't have a specific name or entity ID.
       
       Use tdo_ids to scope to specific media files. Can be a list of IDs or a table alias
       containing a 'tdo_id' column (e.g., output from a FilterOp on _tdo_metadata).
    """

    op: Literal["get_logos"] = "get_logos"
    output: str
    tdo_ids: Optional[Union[List[str], str]] = Field(
        default=None,
        description=(
            "Optional: Scope operation to specific TDO IDs. Can be a list of ID strings "
            "or a table alias (string) containing a 'tdo_id' column. If not provided, "
            "uses the runtime target."
        )
    )


class GetOcrsOp(BaseModel):
    """Get all OCR text occurrences in the target media, producing segments.
    
       Use tdo_ids to scope to specific media files. Can be a list of IDs or a table alias
       containing a 'tdo_id' column (e.g., output from a FilterOp on _tdo_metadata).
    """

    op: Literal["get_ocrs"] = "get_ocrs"
    output: str
    tdo_ids: Optional[Union[List[str], str]] = Field(
        default=None,
        description=(
            "Optional: Scope operation to specific TDO IDs. Can be a list of ID strings "
            "or a table alias (string) containing a 'tdo_id' column. If not provided, "
            "uses the runtime target."
        )
    )


class GetTranscriptsOp(BaseModel):
    """Get the speech transcripts for the target media, producing segments.
    
       Use tdo_ids to scope to specific media files. Can be a list of IDs or a table alias
       containing a 'tdo_id' column (e.g., output from a FilterOp on _tdo_metadata).
    """

    op: Literal["get_transcripts"] = "get_transcripts"
    output: str
    # probably add "sentence" or "words" if needed (unlikely?)
    granularity: Literal["utterance", "full"] = Field(
        default="utterance",
        description="Granularity of the returned transcript, e.g. 'utterance' for speaker segments (if we have speaker information, otherwise inter-pausal units), 'full' for the entire transcript as one segment.",
    )
    tdo_ids: Optional[Union[List[str], str]] = Field(
        default=None,
        description=(
            "Optional: Scope operation to specific TDO IDs. Can be a list of ID strings "
            "or a table alias (string) containing a 'tdo_id' column. If not provided, "
            "uses the runtime target."
        )
    )
    # speaker: Optional[str] = None


class GetTextOp(BaseModel):
    """Get the textual content from ingested documents, producing segments.
    
       Use tdo_ids to scope to specific documents. Can be a list of IDs or a table alias
       containing a 'tdo_id' column (e.g., output from a FilterOp on _tdo_metadata).
    """

    op: Literal["get_text"] = "get_text"
    output: str
    granularity: Literal["chunk", "full"] = Field(
        default="chunk",
        description="Granularity of the returned text, e.g. 'chunk' for document chunks/paragraphs, 'full' for the entire document text as one segment.",
    )
    tdo_ids: Optional[Union[List[str], str]] = Field(
        default=None,
        description=(
            "Optional: Scope operation to specific TDO IDs. Can be a list of ID strings "
            "or a table alias (string) containing a 'tdo_id' column. If not provided, "
            "uses the runtime target."
        )
    )


# ---------------------------
# Table/Timeline ops
# ---------------------------
    
class ProjectOp(BaseModel):
    """Projects a table to a new records table with custom fields."""

    op: Literal["project"] = "project"
    input: str = Field(
        ..., description="Alias to read from. Can be a segments table, records table, or metadata table (e.g., '_tdo_metadata', '_mention_metadata')."
    )
    output: str = Field(
        ..., description="Alias to write the projected records table to."
    )
    select: dict[str, str] = Field(
        ..., description="Dictionary mapping input fields to output fields. Example: {'old_col': 'new_col'}"
    )


# Supported filter operators
FilterOperator = Literal[
    "==", "!=", ">", "<", ">=", "<=",
    "contains", "starts_with", "in",
    "is_null", "not_null", "fuzzy_match"
]


class FilterCondition(BaseModel):
    """A single filter condition for FilterOp.
    
    Operators:
    - '==', '!=', '>', '<', '>=', '<=': Standard comparisons
    - 'contains': Case-insensitive substring match (for strings)
    - 'starts_with': Case-insensitive prefix match (for strings)
    - 'in': Value is in provided list
    - 'is_null': Column value is null (no value needed)
    - 'not_null': Column value is not null (no value needed)
    - 'fuzzy_match': Fuzzy string matching using rapidfuzz (returns matches with score > 65, sorted by score)
    """
    column: str = Field(..., description="The column name to filter on.")
    operator: FilterOperator = Field(
        ...,
        description=(
            "The comparison operator. Use 'fuzzy_match' for approximate string matching "
            "(e.g., when user says 'Stretch budget' but file is '2025_Q3_Stretch_Budget_Final.mp4')."
        )
    )
    value: Any = Field(
        default=None,
        description=(
            "The value to compare against. Not required for 'is_null' and 'not_null' operators. "
            "For 'in' operator, provide a list. For 'fuzzy_match', provide the search string."
        )
    )


class FilterOp(BaseModel):
    """Filter rows in a table by one or more conditions.
    
    All conditions are combined with logical AND. Supports standard comparisons,
    string operations, null checks, and fuzzy string matching for approximate lookups.
    
    Use fuzzy_match when users provide approximate names (e.g., 'budget report' to find 
    'Q3_Budget_Report_Final.pdf'). Results are sorted by match quality.
    """

    op: Literal["filter"] = "filter"
    input: str = Field(
        ...,
        description="Alias of the table to read from (segments, records, or metadata table)."
    )
    output: str = Field(
        ...,
        description="Alias to write the filtered table to."
    )
    conditions: List[FilterCondition] = Field(
        ...,
        description="List of filter conditions to apply. All conditions are combined with AND."
    )
    limit: Optional[int] = Field(
        default=None,
        ge=1,
        description="Optional maximum number of rows to return after filtering."
    )


class JoinTemporalOp(BaseModel):
    """
    Temporal join between two segment tables to find co-occurrences (e.g., a face and a logo on screen together).
    The join is scoped by tdo_id.
    
    CRITICAL: Right-side columns get a '_right' suffix. 
    If you join 'faces' (left) with 'logos' (right), use 'content' for the face name and 'content_right' for the logo name in subsequent operations.
    """
    op: Literal["join_temporal"] = "join_temporal"
    left: str = Field(..., description="Alias of the left-side segments table.")
    right: str = Field(..., description="Alias of the right-side segments table.")
    output: str = Field(..., description="Alias to write the joined segments table to.")
    relation: ConstraintRelation = Field(
        ...,
        description=(
            "The temporal rule: "
            "'OVERLAPS' (any shared time), 'WITHIN' (left is entirely inside right), "
            "'BEFORE' (left ends before right starts), 'AFTER' (left starts after right ends)."
        )
    )
    within_s: Optional[float] = Field(None, description="Max seconds between segments for BEFORE/AFTER relations.")
    tolerance_s: float = Field(0.0, description="Fuzziness in seconds for boundary matches.")


class MergeOp(BaseModel):
    """Merge adjacent segments (e.g. a segment from second 2 to 3 and another one from 3 to 5 would be merged into one segment 2 to 5)"""

    op: Literal["merge"] = "merge"
    inputs: List[str]
    output: str
    tolerance_s: float = 0.0
    coalesce: bool = Field(
        default=True,
        description="If true, coalesce non-time fields (e.g. content), otherwise just deduplicate.",
    )


# Strongly-typed metric specification for AggregateOp
AggregationFn = Literal["count", "count_distinct", "sum", "avg", "min", "max"]


class MetricSpec(TypedDict, total=False):
    """Specification for an aggregation metric.
    
    - fn: The aggregation function to apply (required)
    - field: Column name to aggregate (optional, not needed for count)
    - expr: Expression like "duration()" (optional, alternative to field)
    """
    fn: AggregationFn
    field: str
    expr: str


class AggregateOp(BaseModel):
    """
    Aggregate rows from a table into a summary table.
    
    Use group_by to partition data, then compute metrics on each group.
    If group_by is empty, computes metrics over the entire table.
    """

    op: Literal["aggregate"] = "aggregate"
    input: str = Field(
        ...,
        description="Alias to read from. Can be a segments table, records table, or metadata table.",
    )
    output: str = Field(
        ..., description="Alias to write the aggregated table to."
    )
    group_by: list[str] = Field(
        default_factory=list,
        description="Columns to group by (e.g., ['content'] for per-entity stats, ['tdo_id'] for per-media stats)."
    )
    metrics: dict[str, MetricSpec] = Field(
        default_factory=dict,
        description=(
            "Map of output column names to metric specs. Each spec has: "
            "'fn' (count|count_distinct|sum|avg|min|max), "
            "'field' (column to aggregate), or 'expr' ('duration()' for end_s - start_s)."
        ),
        examples=[
            {
                "rows": {"fn": "count"},
                "screen_time_s": {"fn": "sum", "expr": "duration()"},
                "avg_conf": {"fn": "avg", "field": "score"},
                "distinct_tdos": {"fn": "count_distinct", "field": "tdo_id"},
            }
        ],
    )


class OutputTable(BaseModel):
    """Specifies a table to include in the answer."""
    alias: str = Field(..., description="The table alias to return.")
    sort_by: Optional[str] = Field(None, description="Column name to sort by, or None for no sorting.")
    ascending: bool = Field(True, description="Sort order: True for ascending, False for descending.")


class AnswerWithOp(BaseModel):
    """Return specified tables to the LLM for summarization."""
    op: Literal["answer_with"] = "answer_with"
    inputs: list[OutputTable] = Field(
        description="List of tables to return, each with optional sorting.",
    )
    limit: int = Field(
        default=5000,
        ge=1,
        description="Maximum number of rows to return per table.",
    )


# ---------------------------------------------
# Unions (exported to the planner / LLM)
# ---------------------------------------------

# Everything the LLM is allowed to emit:
Op = Union[
    # FIND
    FindTranscriptOp,
    FindTextOp,
    FindFaceOp,
    FindLogoOp,
    # GET
    GetTranscriptsOp,
    GetTextOp,
    GetFacesOp,
    GetLogosOp,
    GetOcrsOp,
    # tables/timeline
    ProjectOp,
    FilterOp,
    JoinTemporalOp,
    MergeOp,
    AggregateOp,
    AnswerWithOp,
]

DiscriminatedOp = Annotated[Op, Field(discriminator="op")]


def _get_op_class_map() -> dict[str, type[BaseModel]]:
    """Creates a fast lookup dictionary: {'find_face': FindFaceOp, ...}"""
    return {
        cls.model_fields["op"].default: cls
        for cls in get_args(Op)
    }


