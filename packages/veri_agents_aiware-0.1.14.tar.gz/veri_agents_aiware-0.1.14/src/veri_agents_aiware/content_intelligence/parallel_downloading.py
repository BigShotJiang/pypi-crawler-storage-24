import logging

import asyncio
from asyncio import Semaphore
import aiohttp

logger = logging.getLogger(__name__)

# Global semaphore to limit total concurrent downloads across all adownload_all calls.
# This prevents file descriptor exhaustion when multiple calls run in parallel
# (e.g., when from_tdo_ids processes many TDOs concurrently).
_GLOBAL_MAX_CONCURRENT = 100
_global_semaphore: Semaphore | None = None


def _get_global_semaphore() -> Semaphore:
    """Get or create the global download semaphore."""
    global _global_semaphore
    if _global_semaphore is None:
        _global_semaphore = Semaphore(_GLOBAL_MAX_CONCURRENT)
    return _global_semaphore


def in_ipython() -> bool:
    try:
        from IPython.core.getipython import get_ipython

        return get_ipython() is not None
    except ImportError:
        return False


if in_ipython():
    # Patch event loop so run_until_complete works in Jupyter
    import nest_asyncio

    nest_asyncio.apply()


async def adownload_all(
    urls: list[str],
    max_concurrent: int = 50,
    timeout: int = 60,
) -> list[dict | None]:
    # Use global semaphore to limit total concurrent connections across all calls
    global_semaphore = _get_global_semaphore()

    async def fetch(session: aiohttp.ClientSession, url: str) -> dict | None:
        async with global_semaphore:
            try:
                async with session.get(
                    url, timeout=aiohttp.ClientTimeout(total=timeout)
                ) as response:
                    response.raise_for_status()
                    # maybe a bad idea to assume JSON here:
                    content = await response.json()
                    # logger.info("Downloaded %s", url)
                    return content
            except Exception as e:
                logger.error("Error fetching %s: %s", url, str(e))
                return None

    # Configure connector with explicit limits to prevent fd exhaustion
    connector = aiohttp.TCPConnector(
        limit=max_concurrent,  # Max simultaneous connections per session
        limit_per_host=20,  # Max connections to same host (S3)
        enable_cleanup_closed=True,  # Clean up closed connections
    )
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [fetch(session, url) for url in urls]
        return await asyncio.gather(*tasks)


def download_all(
    urls: list[str],
    max_concurrent: int = 50,
    timeout: int = 120,
) -> list[dict | None]:
    loop = asyncio.get_running_loop()  # Python 3.7+
    try:
        result = loop.run_until_complete(adownload_all(urls, max_concurrent, timeout))
    except RuntimeError:  # no loop running
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(adownload_all(urls, max_concurrent, timeout))
    return result
