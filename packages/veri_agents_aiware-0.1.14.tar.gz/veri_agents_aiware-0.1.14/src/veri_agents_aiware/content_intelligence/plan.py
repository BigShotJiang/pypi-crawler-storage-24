from __future__ import annotations
import ast
import enum
import inspect
import hashlib
import logging
from typing import Any, Literal, Union, get_args, get_origin

from pydantic import BaseModel, ConfigDict, Field

from veri_agents_aiware.content_intelligence.ops import DiscriminatedOp, _get_op_class_map, Op

log = logging.getLogger(__name__)

class InvalidPlanError(Exception):
    pass

class Plan(BaseModel):
    model_config = ConfigDict(extra="forbid")
    plan_version: str = "2.0"
    steps: list[DiscriminatedOp]
    reasoning: str = Field(
        description="Brief explanation of why this plan was chosen."
    )
    resolved_query: str = Field(
        description="The standalone, fully contextualized question being answered. All pronouns and implicit references resolved from chat history."
    )

    def signature(self) -> str:
        body = self.model_dump_json(by_alias=True)
        return hashlib.sha256(body.encode()).hexdigest()[:16]

    def prettify(self) -> str:
        s = ""
        for step in self.steps:
            s += f"- {step.op}({', '.join(f'{k}={v}' for k, v in step.model_dump().items() if v)})\n"
        return s


# ---------------------------
# DSL Support
# ---------------------------


class DslPlanOutput(BaseModel):
    """The schema for the LLM to output its reasoning and DSL script."""

    reasoning: str = Field(
        description="Brief explanation of why this plan was chosen."
    )
    resolved_query: str = Field(
        description=(
            "The standalone, fully contextualized question you are trying to answer. "
            "Resolve ALL pronouns and implicit references using the chat history. "
            "Example: If history is 'How many faces?' and current query is 'And transcripts?', "
            "the resolved_query MUST be 'How many people were mentioned in the transcripts?'"
        )
    )
    dsl_script: str = Field(
        description="The multi-line Python-like script executing the plan."
    )


def _get_type_schema_str(annotation: Any) -> str:
    """Recursively resolves type hints and nested Pydantic models into a compact string for the LLM."""
    origin = get_origin(annotation)
    args = get_args(annotation)
    
    # Handle Literal types - show all allowed values
    if origin is Literal:
        values = [repr(a) for a in args]
        return f"Literal[{', '.join(values)}]"
    
    # Handle Optional (Union[X, None]) and Union types
    if origin is Union:
        non_none_args = [a for a in args if a is not type(None)]
        if len(non_none_args) == 1 and type(None) in args:
            # This is Optional[X] - show as "X | None"
            return f"{_get_type_schema_str(non_none_args[0])} | None"
        else:
            # General Union
            return " | ".join(_get_type_schema_str(a) for a in args)
    
    # Handle lists (e.g., list[Projection])
    if origin is list and args:
        return f"list[{_get_type_schema_str(args[0])}]"
    
    # Handle dicts
    if origin is dict and len(args) == 2:
        return f"dict[{_get_type_schema_str(args[0])}, {_get_type_schema_str(args[1])}]"
    
    # Handle Enum types - show all possible values
    if isinstance(annotation, type) and issubclass(annotation, enum.Enum):
        values = [repr(e.value) for e in annotation]
        return f"{annotation.__name__}[{', '.join(values)}]"
    
    # Handle nested Pydantic Models (e.g., Projection)
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        props = []
        for fname, finfo in annotation.model_fields.items():
            req = "" if finfo.is_required() else "?"
            props.append(f"'{fname}'{req}: {_get_type_schema_str(finfo.annotation)}")
        return f"{{{', '.join(props)}}}"
    
    # Handle basic types (str, int, float)
    if hasattr(annotation, "__name__"):
        return annotation.__name__
    
    # Handle NoneType
    if annotation is type(None):
        return "None"
    
    # Fallback
    return str(annotation).replace("typing.", "")


def generate_dsl_cheat_sheet() -> str:
    """
    Dynamically generates a token-efficient Markdown DSL manual
    from the Pydantic Op union.
    """
    op_classes = get_args(Op)

    docs = [
        "=== MEDIA ANALYSIS DSL ===",
        "Write a sequential Python-like script using the following operations.",
        "Variables hold references to table aliases (e.g., `faces_table = find_face(...)`).",
        "Pass arguments as kwargs. Omit OPTIONAL arguments if not needed.",
        "",
    ]

    for op_cls in op_classes:
        # Get the literal op name (e.g., 'find_face')
        op_name = op_cls.model_fields["op"].default

        # Clean up the docstring
        description = inspect.cleandoc(op_cls.__doc__ or "No description.")

        docs.append(f"## {op_name}")
        docs.append(f"{description}")
        docs.append("Args:")

        for field_name, field_info in op_cls.model_fields.items():
            # output fields are now the target of assignment
            if field_name in ("op", "output"):
                continue 
                
            is_required = field_info.is_required()
            req_str = "REQUIRED" if is_required else "OPTIONAL"
            desc = field_info.description or ""
            
            default_str = ""
            if not is_required and field_info.default is not None and field_info.default != Ellipsis:
                default_val = field_info.default
                
                # Unpack Enums to their raw primitive values
                if isinstance(default_val, enum.Enum):
                    default_val = default_val.value
                
                # Add quotes around strings so the LLM writes valid literals
                if isinstance(default_val, str):
                    default_val = f"'{default_val}'"
                    
                default_str = f" (Default: {default_val})"
            
            # Extract the structural schema of the type for nested objects
            type_str = _get_type_schema_str(field_info.annotation)
                
            docs.append(f"  - `{field_name}` ({req_str}) [Type: {type_str}]{default_str}: {desc}")

            # Show examples if they exist
            examples = getattr(field_info, "examples", None)
            if examples:
                docs.append(f"    Examples: {examples}")

        docs.append("")  # Spacing

    return "\n".join(docs)


def parse_dsl_to_plan(dsl: DslPlanOutput) -> Plan:
    """
    Safely parses a Python-like DSL script into strict Pydantic Plan models.
    Raises ValueError on syntax errors or invalid function calls.
    """
    dsl_script = dsl.dsl_script
    reasoning = dsl.reasoning
    op_map = _get_op_class_map()
    steps: list[DiscriminatedOp] = []

    try:
        # Parse string into an Abstract Syntax Tree
        tree = ast.parse(dsl_script)
    except SyntaxError as e:
        raise ValueError(
            f"DSL Syntax Error: {e.msg} on line {e.lineno}. Script must be valid Python syntax."
        )

    # Walk through each line of the script
    for node in tree.body:
        # The line must be a function call, either standalone or assigned to a variable
        call_node = None
        assigned_var_name = None
        if isinstance(node, ast.Assign):
            # Extract the variable name
            if isinstance(node.targets[0], ast.Name):
                assigned_var_name = node.targets[0].id
            # e.g., faces = find_face(...)
            if isinstance(node.value, ast.Call):
                call_node = node.value
        elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
            # e.g., find_face(...)
            call_node = node.value

        if not call_node:
            continue  # Ignore random statements like print() or comments

        # Extract the function name
        if not isinstance(call_node.func, ast.Name):
            raise ValueError(
                "DSL parsing failed: Operation must be a simple function call."
            )

        op_name = call_node.func.id

        if op_name not in op_map:
            raise ValueError(
                f"Invalid operation: '{op_name}' is not a valid DSL command."
            )

        # Extract kwargs safely using literal_eval
        kwargs = {}
        for keyword in call_node.keywords:
            if keyword.arg is None:
                continue # Skip **kwargs unpacking syntax
            
            # If the LLM wrote SearchMode.SEMANTIC (ast.Attribute)
            if isinstance(keyword.value, ast.Attribute):
                # We extract the 'SEMANTIC' part, lowercase it, and save it as a string
                # Pydantic will automatically cast this string back to your Enum!
                kwargs[keyword.arg] = keyword.value.attr.lower()
                continue
            
            # If the LLM just wrote SEMANTIC without the class (ast.Name)
            elif isinstance(keyword.value, ast.Name):
                # We extract 'SEMANTIC' and lowercase it
                # Handle booleans gracefully just in case AST didn't catch them as constants
                if keyword.value.id in ('True', 'False', 'None'):
                    pass # Let literal_eval handle it below
                else:
                    kwargs[keyword.arg] = keyword.value.id.lower()
                    continue

            try:
                # Safely convert standard AST nodes (strings, numbers, dicts, lists)
                value = ast.literal_eval(keyword.value)
                kwargs[keyword.arg] = value
            except ValueError:
                raise ValueError(
                    f"Could not parse argument '{keyword.arg}' in {op_name}. "
                    f"Ensure it is a basic Python literal (string, number, list, dict)."
                )

        # Instantiate Pydantic Model (Validation happens here!)
        pydantic_class = op_map[op_name]

        # If the LLM assigned a variable, map it to the Pydantic 'output' field!
        if assigned_var_name:
            kwargs["output"] = assigned_var_name
        elif "output" in pydantic_class.model_fields and pydantic_class.model_fields["output"].is_required() and "output" not in kwargs:
            # If it's a FIND or GET op but the LLM didn't assign it or provide it directly, we have a problem.
            raise ValueError(f"DSL Error: You must assign the result of {op_name} to a variable.")

        # Inject the operation name explicitly just in case
        kwargs["op"] = op_name

        try:
            step_instance = pydantic_class(**kwargs)
            steps.append(step_instance)  # type: ignore[arg-type]
        except Exception as e:
            # If Pydantic validation fails (e.g., missing 'where' dict), it bubbles up
            raise ValueError(f"Validation failed for {op_name}: {str(e)}")

    return Plan(steps=steps, reasoning=reasoning, resolved_query=dsl.resolved_query)
