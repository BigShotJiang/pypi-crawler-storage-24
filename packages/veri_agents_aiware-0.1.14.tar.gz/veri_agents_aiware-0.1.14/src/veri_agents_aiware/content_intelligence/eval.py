"""
Evaluation script for the Content Intelligence Agent using Langfuse and OpenEvals.
This script sets up the necessary clients, defines the evaluation prompt,
and runs the evaluation on a specified dataset.

Usage:
    python eval.py              # Run evaluation and write results to Langfuse
    python eval.py --local      # Run evaluation locally, output to console only
    python eval.py --local -v   # Verbose mode (INFO level logging)
    python eval.py --local -d   # Debug mode (DEBUG level logging)
"""

import argparse
import json
import logging
import os
import sys
from typing import cast
import asyncio
from langchain_aws import ChatBedrockConverse
from langfuse import Langfuse, get_client, Evaluation
from openevals import create_async_llm_as_judge
from openevals.types import EvaluatorResult
from pydantic import TypeAdapter

from aiware.common.auth import TokenAuth, AiwareApiKey
from veri_agents_aiware.aiware_client.async_client import AsyncAgentsAiware
from veri_agents_aiware.content_intelligence import create_content_intelligence_agent
from veri_agents_aiware.content_intelligence import TargetSelector

# Evaluates how well the LLM answered given the context it had available.
# This scores high if the LLM correctly interpreted and used the information it was given,
# even if that information was incomplete.
CONTEXT_FAITHFULNESS_PROMPT = """You are an expert data labeler evaluating how well an LLM answered a question given the context it had available.

Your task is to evaluate whether the model's response is faithful to and appropriate for the context it was provided.

<Rubric>
  A faithful answer:
  - Correctly uses information present in the context
  - Does not hallucinate facts not present in the context
  - Appropriately acknowledges when information is missing from the context
  - Avoids speculation beyond what the context supports
  - Is logically consistent with the provided context

  When scoring, you should penalize:
  - Hallucinated facts not supported by the context
  - Ignoring relevant information that was in the context
  - Claiming certainty when context is ambiguous
  - Failing to acknowledge missing information
  - Misinterpreting or distorting context information

Scores should be in the range of 0.0 to 1.0, with the following guidelines:
- 1.0: Perfectly faithful to context, correctly handles available/missing info
- 0.8: Mostly faithful with minor issues
- 0.5: Partially faithful but with some hallucination or misuse of context
- 0.2: Largely unfaithful to context
- 0.0: Completely ignores context or heavily hallucinates
</Rubric>

<Instructions>
  - Focus ONLY on whether the response is faithful to the provided context
  - Score high if the LLM correctly says "I don't know" when context lacks the answer
  - Score low if the LLM makes up information not in the context
  - Do NOT penalize for missing information if the context didn't contain it
</Instructions>

<Reminder>
  This score evaluates the LLM's behavior given its context, NOT whether the pipeline retrieved the right context.
</Reminder>

<question>
{inputs}
</question>

<output>
{outputs}
</output>
"""

# Evaluates whether the full pipeline produced the correct final answer.
# This is the end-to-end score that grades retrieval + reasoning together.
ANSWER_CORRECTNESS_PROMPT = """You are an expert data labeler evaluating whether a system produced the correct answer.

Your task is to compare the system's output against the ground truth reference answer.

<Rubric>
  A correct answer:
  - Contains the same factual information as the reference
  - Accurately answers the question asked
  - Does not contradict the reference answer
  - Captures the key information from the reference

  When scoring, you should penalize:
  - Missing key facts present in the reference
  - Incorrect or contradictory information
  - Claiming no answer exists when reference has one
  - Providing a different answer than the reference

Scores should be in the range of 0.0 to 1.0, with the following guidelines:
- 1.0: Exact or semantically equivalent to reference answer
- 0.8: Mostly correct, captures main facts with minor omissions
- 0.5: Partially correct, missing significant information
- 0.2: Largely incorrect but with some overlap
- 0.0: Completely wrong or missing the answer entirely
</Rubric>

<Instructions>
  - Compare the output directly against the reference answer
  - Focus on factual accuracy and completeness
  - If reference says "Bell Labs in 1988" and output says "no information available", score should be low
  - Style differences are acceptable if facts match
</Instructions>

<Reminder>
  This score evaluates the full pipeline's ability to retrieve and synthesize the correct answer.
</Reminder>

<question>
{inputs}
</question>

<output>
{outputs}
</output>

<reference_answer>
{reference_outputs}
</reference_answer>
"""


async def main(local_mode: bool = False, limit: int | None = None):
    """Main function to set up clients and run the evaluation.
    
    Args:
        local_mode: If True, run evaluation locally and output to console.
                   If False, write results back to Langfuse.
        limit: Maximum number of dataset items to process. None means all items.
    """
    aiware_token = os.getenv("LABS_AIWARE_API_KEY")
    aiware_url = os.getenv("LABS_AIWARE_BASE_URL")
    langfuse_public = os.getenv("LANGFUSE_PUBLIC_KEY")
    langfuse_secret = os.getenv("LANGFUSE_SECRET_KEY")
    langfuse_url = os.getenv("LANGFUSE_URL", "https://langfuse.varp.tech")

    if not (langfuse_public and langfuse_secret):
        raise ValueError(
            "LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY environment variables must be set."
        )
    if not (aiware_token and aiware_url):
        raise ValueError(
            "VERITONE_AIWARE_API_KEY and VERITONE_AIWARE_BASE_URL environment variables must be set."
        )

    Langfuse(
        public_key=langfuse_public,
        secret_key=langfuse_secret,
        host=langfuse_url,
    )

    aiware_client = AsyncAgentsAiware(
        base_url=aiware_url,
        auth=TokenAuth(token=AiwareApiKey(aiware_token)),
    )

    bulk_llm = ChatBedrockConverse(
        model="arn:aws:bedrock:us-east-1:075494626733:application-inference-profile/nhxrhd3b0en8",
        base_model="us.amazon.nova-2-lite-v1:0",
        provider="amazon",
        region_name="us-east-1",
    )
    summary_llm = ChatBedrockConverse(
        max_tokens=2000,
        model="arn:aws:bedrock:us-east-1:075494626733:application-inference-profile/nqd9c00141tr",
        base_model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        provider="amazon",
        region_name="us-east-1",
    )
    llm = ChatBedrockConverse(
        model="arn:aws:bedrock:us-east-1:075494626733:application-inference-profile/nqd9c00141tr",
        base_model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        provider="anthropic",
        region_name="us-east-1",
    )
    eval_llm = ChatBedrockConverse(
        max_tokens=2000,
        model="arn:aws:bedrock:us-east-1:075494626733:application-inference-profile/nhxrhd3b0en8",
        base_model="us.amazon.nova-2-lite-v1:0",
        provider="amazon",
        region_name="us-east-1",
    )

    async def eval_task(*, input, output, expected_output, metadata, **kwargs):
        # Evaluator 1: Context Faithfulness - how well did the LLM use available context
        faithfulness_evaluator = create_async_llm_as_judge(
            prompt=CONTEXT_FAITHFULNESS_PROMPT,
            judge=eval_llm,
            continuous=True,
        )
        
        # Evaluator 2: Answer Correctness - did the pipeline produce the correct answer
        correctness_evaluator = create_async_llm_as_judge(
            prompt=ANSWER_CORRECTNESS_PROMPT,
            judge=eval_llm,
            continuous=True,
        )
        
        # Run both evaluators concurrently
        faithfulness_result, correctness_result = await asyncio.gather(
            faithfulness_evaluator(
                inputs=str(input["messages"]),
                outputs=str(output["messages"]),
            ),
            correctness_evaluator(
                inputs=str(input["messages"]),
                outputs=str(output["messages"]),
                reference_outputs=str(expected_output["messages"]),
            ),
        )
        
        faithfulness_result = cast(EvaluatorResult, faithfulness_result)
        correctness_result = cast(EvaluatorResult, correctness_result)
        
        return [
            Evaluation(
                name="Context Faithfulness",
                value=faithfulness_result["score"],
                comment=faithfulness_result["comment"],
            ),
            Evaluation(
                name="Answer Correctness",
                value=correctness_result["score"],
                comment=correctness_result["comment"],
            ),
        ]

    async def run_task(*, item, **kwargs):
        print(item.input)
        messages = item.input.get("messages")
        target_json = item.input.get("context", {}).get("target")
        print(target_json)
        adapter = TypeAdapter(TargetSelector)
        target = adapter.validate_python(target_json)

        content_agent = create_content_intelligence_agent(
            model=llm,
            summary_model=summary_llm,
            bulk_model=bulk_llm,
            aiware_client=aiware_client,
            target=target,
        )

        result = await content_agent.ainvoke(input={"messages": messages})  # type: ignore
        return {"messages": result["messages"][-1].text}

    # Run on dataset we retrieve from langfuse
    langfuse = get_client()
    dataset = langfuse.get_dataset("content_intelligence/veritoneinc_basic")
    
    # Apply limit to dataset items
    items = dataset.items[:limit] if limit else dataset.items
    total_items = len(items)
    
    if local_mode:
        # Local mode: run agent and output to console only (no evaluators)
        print("\n" + "=" * 80)
        print("RUNNING IN LOCAL MODE - Agent outputs will be printed to console")
        if limit:
            print(f"Limited to {limit} items (out of {len(dataset.items)} total)")
        print("=" * 80 + "\n")
        
        successful = 0
        failed = 0
        for i, item in enumerate(items):
            print(f"\n{'─' * 80}")
            print(f"ITEM {i + 1}/{total_items}: {item.id}")
            print(f"{'─' * 80}")
            
            # Print input
            print("\n📥 INPUT:")
            print(json.dumps(item.input, indent=2, default=str))
            
            print("\n🎯 EXPECTED OUTPUT:")
            print(json.dumps(item.expected_output, indent=2, default=str))
            
            try:
                print("\n⚙️  Running agent...")
                output = await run_task(item=item)
                
                print("\n📤 ACTUAL OUTPUT:")
                print(json.dumps(output, indent=2, default=str))
                successful += 1
                
            except Exception as e:
                import traceback
                print(f"\n❌ ERROR: {e}")
                print("\n📋 TRACEBACK:")
                traceback.print_exc()
                failed += 1
        
        # Print summary
        print("\n" + "=" * 80)
        print("SUMMARY")
        print("=" * 80)
        print(f"Total items: {successful + failed}")
        print(f"Successful: {successful}")
        print(f"Failed: {failed}")
            
    else:
        # Normal mode: write results to Langfuse
        dataset.run_experiment(
            name="Content Intelligence Evaluation",
            description="Regular evaluation of the content intelligence agent",
            task=run_task,
            evaluators=[eval_task],
            max_concurrency=5,
        )


def setup_logging(verbose: bool = False, debug: bool = False) -> None:
    """Configure logging based on verbosity flags.
    
    Args:
        verbose: Enable INFO level logging
        debug: Enable DEBUG level logging (overrides verbose)
    """
    if debug:
        level = logging.DEBUG
    elif verbose:
        level = logging.INFO
    else:
        level = logging.WARNING
    
    # Configure root logger
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        stream=sys.stdout,
        force=True,
    )
    
    # Set level for key loggers
    loggers_to_configure = [
        "veri_agents_aiware",
        "aiware",
        "langchain",
    ]
    
    for logger_name in loggers_to_configure:
        logging.getLogger(logger_name).setLevel(level)
    
    # Always suppress noisy AWS/HTTP loggers (even in debug mode)
    noisy_loggers = [
        "httpx",
        "httpcore",
        "botocore",
        "botocore.hooks",
        "botocore.endpoints",
        "botocore.auth",
        "botocore.httpsession",
        "botocore.parsers",
        "botocore.retryhandler",
        "botocore.loaders",
        "botocore.regions",
        "botocore.credentials",
        "boto3",
        "urllib3",
        "s3transfer",
        "langchain_aws",
        "langchain_aws.chat_models",
        "langchain_aws.chat_models.bedrock_converse",
        "asyncio",
    ]
    for logger_name in noisy_loggers:
        logging.getLogger(logger_name).setLevel(logging.WARNING)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Run Content Intelligence Agent evaluation"
    )
    parser.add_argument(
        "--local",
        action="store_true",
        help="Run evaluation locally, output to console only (no Langfuse write-back)",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output (INFO level logging)",
    )
    parser.add_argument(
        "-d", "--debug",
        action="store_true",
        help="Enable debug output (DEBUG level logging)",
    )
    parser.add_argument(
        "-n", "--limit",
        type=int,
        default=None,
        help="Maximum number of dataset items to process (default: all)",
    )
    args = parser.parse_args()
    
    setup_logging(verbose=args.verbose, debug=args.debug)
    
    asyncio.run(main(local_mode=args.local, limit=args.limit))
