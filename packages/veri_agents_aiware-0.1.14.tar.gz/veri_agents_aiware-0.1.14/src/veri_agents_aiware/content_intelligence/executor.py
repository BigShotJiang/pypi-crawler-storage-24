from __future__ import annotations

import asyncio
import logging
import time
from functools import singledispatchmethod
from typing import Any

import polars as pl
from pydantic import BaseModel, Field
from veri_agents_aiware.content_intelligence.client import ContentIntelligenceClient
from veri_agents_aiware.content_intelligence.data import (
    MentionsTable,
    RecordsTable,
    SegmentsTable,
    Table,
    TargetByIds,
    TargetByMention,
    TargetByWatchlist,
    TargetSelector,
    TdoTable,
    WatchlistsTable,
    coalesce_segments,
    dedupe_segments,
    format_table_delimited,
    new_mentions_table,
    new_tdo_table,
    new_watchlists_table,
)
from rapidfuzz import fuzz
from veri_agents_aiware.content_intelligence.ops import (
    FindTranscriptOp,
    FindTextOp,
    FindFaceOp,
    FindLogoOp,
    GetOcrsOp,
    GetTranscriptsOp,
    GetTextOp,
    GetFacesOp,
    GetLogosOp,
    ProjectOp,
    FilterOp,
    FilterCondition,
    JoinTemporalOp,
    MergeOp,
    AggregateOp,
    AnswerWithOp,
    OutputTable,
    MetricSpec,
)
from veri_agents_aiware.content_intelligence.plan import InvalidPlanError, Plan
from veri_agents_aiware.content_intelligence.temporal import join_temporal

log = logging.getLogger(__name__)


class ErrorInfo(BaseModel):
    stage: str
    message: str


class State(BaseModel):
    """Models the state of execution for a content intelligence plan.
    
    Initially expects a query, a target and a plan.
    As execution proceeds, tables and results are populated. 
    """
    model_config = {"arbitrary_types_allowed": True}

    query: str
    target: TargetSelector
    plan: Plan | None = None
    tdo_table: TdoTable | None = None
    mentions_table: MentionsTable | None = None
    watchlists_table: WatchlistsTable | None = None
    segments_tables: dict[str, SegmentsTable] = {}
    records_tables: dict[str, RecordsTable] = {}
    answer: Any = None
    errors: list[ErrorInfo] = []
    started_at: float = Field(default_factory=time.time)


# ----------------------- EXECUTOR -----------------------


class Executor:
    """Deterministic executor for Plan steps with singledispatch-based handlers."""

    def __init__(self, client: ContentIntelligenceClient):
        self.client = client

    # ---------------------- public ----------------------

    async def run(self, state: State) -> State:
        """Execute the plan in the given state.
        
        Args:
            state: The current execution state containing the plan and data.
        
        Returns:
            The updated state after executing the plan.
        """
        if not state.plan:
            state.errors.append(ErrorInfo(stage="executor", message="missing plan"))
            return state
        try:
            # data gathering steps can run in parallel
            parallel_steps = []
            sequential_steps = []
            for step in state.plan.steps:
                if step.op.startswith("find_") or step.op.startswith("get_"):
                    if hasattr(step, "tdo_ids") and step.tdo_ids is not None:
                        # Steps with tdo_ids need to resolve targets first, so run sequentially
                        # this can be done smarter in future by resolving targets first and then running finds/gets in parallel, but for now just run these sequentially to be safe
                        sequential_steps.append(step)
                    else:
                        parallel_steps.append(step)
                else:
                    sequential_steps.append(step)
            
            # Execute parallel steps
            await asyncio.gather(*(self._handle(step, state) for step in parallel_steps))
            
            # Now the sequential ones
            for step in sequential_steps:
                log.info("[Executor] Executing sequential step: %s", step)
                await self._handle(step, state)  # dispatch on step type
        except Exception as e:
            log.exception("Executor error")
            state.errors.append(ErrorInfo(stage="execute", message=str(e)))
        return state

    # ---------------------- dispatch root ----------------------

    @singledispatchmethod
    async def _handle(self, step: BaseModel, state: State) -> None:
        raise NotImplementedError(f"No handler for {type(step).__name__}")

    # ---------------------- helper methods ----------------------

    async def _resolve_tdo_ids_target(
        self, 
        tdo_ids: list[str] | str | None, 
        state: State,
        op_name: str
    ) -> TargetSelector | None:
        """Resolve tdo_ids parameter to a TargetByIds, or return None to use default target.
        
        Args:
            tdo_ids: Either a list of TDO ID strings, a table alias (string) containing
                     a 'tdo_id' column, or None to use the default target.
            state: The current execution state for table lookups.
            op_name: Name of the operation (for error messages).
            
        Returns:
            TargetByIds if tdo_ids was provided and resolved, None otherwise.
            
        Raises:
            InvalidPlanError: If table alias not found or doesn't contain 'tdo_id' column.
        """
        if tdo_ids is None:
            return None
            
        if isinstance(tdo_ids, list):
            # Direct list of IDs
            if not tdo_ids:
                raise InvalidPlanError(
                    f"{op_name}: tdo_ids list is empty. Cannot execute with no target IDs."
                )
            return TargetByIds(kind="tdo_ids", tdo_ids=tdo_ids)
            
        # It's a string - resolve table alias
        alias = tdo_ids
        try:
            table = await self._get_table_from_state(state, alias)
        except InvalidPlanError:
            raise InvalidPlanError(
                f"{op_name}: table alias '{alias}' not found in state. "
                "Ensure a previous operation created this table."
            )
        
        if "tdo_id" not in table.columns:
            raise InvalidPlanError(
                f"{op_name}: table '{alias}' does not contain 'tdo_id' column. "
                f"Available columns: {list(table.columns)}"
            )
        
        # Extract unique tdo_ids from the table
        ids = table.select(pl.col("tdo_id")).unique().to_series().to_list()
        
        if not ids:
            raise InvalidPlanError(
                f"{op_name}: table '{alias}' has 0 rows. Cannot execute extraction "
                "with no target IDs. Consider adjusting filter criteria."
            )
        
        log.info("[Executor] Resolved %d TDO IDs from table alias '%s'", len(ids), alias)
        return TargetByIds(kind="tdo_ids", tdo_ids=ids)

    # ---------------------- FIND handlers ----------------------

    @_handle.register
    async def _handle_find_transcript(
        self, step: FindTranscriptOp, state: State
    ) -> None:
        log.info("[Executor] Executing find_transcript: %s", step)
        segs = await self.client.find_transcript(step, state.target)
        log.info("[Executor] Completed find_transcript")
        state.segments_tables[step.output] = segs

    @_handle.register
    async def _handle_find_text(
        self, step: FindTextOp, state: State
    ) -> None:
        log.info("[Executor] Executing find_text: %s", step)
        segs = await self.client.find_text(step, state.target)
        log.info("[Executor] Completed find_text")
        state.segments_tables[step.output] = segs

    @_handle.register
    async def _handle_find_face(self, step: FindFaceOp, state: State) -> None:
        log.info("[Executor] Executing find_face: %s", step)
        segs = await self.client.find_face(step, state.target)
        log.info("[Executor] Completed find_face")
        state.segments_tables[step.output] = segs

    @_handle.register
    async def _handle_find_logo(self, step: FindLogoOp, state: State) -> None:
        log.info("[Executor] Executing find_logo: %s", step)
        segs = await self.client.find_logo(step, state.target)
        log.info("[Executor] Completed find_logo")
        state.segments_tables[step.output] = segs

    # ---------------------- GET_* handlers ----------------------

    @_handle.register
    async def _handle_get_transcripts(
        self, step: GetTranscriptsOp, state: State
    ) -> None:
        log.info("[Executor] Executing get_transcripts: %s", step)
        
        # Resolve tdo_ids to target if provided
        resolved_target = await self._resolve_tdo_ids_target(
            step.tdo_ids, state, "GET_TRANSCRIPTS"
        )
        effective_target = resolved_target if resolved_target else state.target
        
        match effective_target:
            case TargetByMention() | TargetByWatchlist():
                segs, metadata = await self.client.get_mention_transcript(step, effective_target)
                if state.mentions_table is None:
                    state.mentions_table = metadata
            case _:
                segs = await self.client.get_tdo_transcript(step, effective_target)
        state.segments_tables[step.output] = segs
        log.info("[Executor] Completed get_transcripts")

    @_handle.register
    async def _handle_get_text(self, step: GetTextOp, state: State) -> None:
        log.info("[Executor] Executing get_text: %s", step)
        
        # Resolve tdo_ids to target if provided
        resolved_target = await self._resolve_tdo_ids_target(
            step.tdo_ids, state, "GET_TEXT"
        )
        effective_target = resolved_target if resolved_target else state.target
        
        segs = await self.client.get_tdo_text(step, effective_target)
        state.segments_tables[step.output] = segs
        log.info("[Executor] Completed get_text")

    @_handle.register
    async def _handle_get_faces(self, step: GetFacesOp, state: State) -> None:
        log.info("[Executor] Executing get_faces: %s", step)
        
        # Resolve tdo_ids to target if provided
        resolved_target = await self._resolve_tdo_ids_target(
            step.tdo_ids, state, "GET_FACES"
        )
        effective_target = resolved_target if resolved_target else state.target
        
        match effective_target:
            case TargetByMention() | TargetByWatchlist():
                segs, metadata = await self.client.get_mention_faces(step, effective_target)
                if state.mentions_table is None:
                    state.mentions_table = metadata
            case _:
                segs = await self.client.get_tdo_faces(step, effective_target)
        state.segments_tables[step.output] = segs
        log.info("[Executor] Completed get_faces")

    @_handle.register
    async def _handle_get_logos(self, step: GetLogosOp, state: State) -> None:
        log.info("[Executor] Executing get_logos: %s", step)
        
        # Resolve tdo_ids to target if provided
        resolved_target = await self._resolve_tdo_ids_target(
            step.tdo_ids, state, "GET_LOGOS"
        )
        effective_target = resolved_target if resolved_target else state.target
        
        match effective_target:
            case TargetByMention() | TargetByWatchlist():
                segs, metadata = await self.client.get_mention_logos(step, effective_target)
                if state.mentions_table is None:
                    state.mentions_table = metadata
            case _:
                segs = await self.client.get_tdo_logos(step, effective_target)
        state.segments_tables[step.output] = segs
        log.info("[Executor] Completed get_logos")

    @_handle.register
    async def _handle_get_ocrs(self, step: GetOcrsOp, state: State) -> None:
        log.info("[Executor] Executing get_ocrs: %s", step)
        
        # Resolve tdo_ids to target if provided
        resolved_target = await self._resolve_tdo_ids_target(
            step.tdo_ids, state, "GET_OCRS"
        )
        effective_target = resolved_target if resolved_target else state.target
        
        match effective_target:
            case TargetByMention() | TargetByWatchlist():
                segs, metadata = await self.client.get_mention_ocrs(step, effective_target)
                if state.mentions_table is None:
                    state.mentions_table = metadata
            case _:
                segs = await self.client.get_tdo_ocrs(step, effective_target)
        state.segments_tables[step.output] = segs
        log.info("[Executor] Completed get_ocrs")

    # ---------------------- timeline/table ops ----------------------

    @_handle.register
    async def _handle_project(self, step: ProjectOp, state: State) -> None:
        """Project selected fields from any table (segments, records, or metadata)."""
        table = await self._get_table_from_state(state, step.input)
        
        # Build selection expressions with fallback for "_right" suffixed columns
        select_exprs = []
        for input_field, output_field in step.select.items():
            # Check if the field exists
            if input_field in table.columns:
                # Check if the column is all nulls and there's a "_right" version
                if (table.height > 0 and 
                    table[input_field].null_count() == table.height and 
                    f"{input_field}_right" in table.columns):
                    log.debug(f"Column '{input_field}' is all nulls, using '{input_field}_right' instead")
                    select_exprs.append(pl.col(f"{input_field}_right").alias(output_field))
                else:
                    select_exprs.append(pl.col(input_field).alias(output_field))
            elif f"{input_field}_right" in table.columns:
                # Field doesn't exist but "_right" version does
                log.debug(f"Column '{input_field}' not found, using '{input_field}_right' instead")
                select_exprs.append(pl.col(f"{input_field}_right").alias(output_field))
            else:
                # Neither exists, let Polars handle the error
                select_exprs.append(pl.col(input_field).alias(output_field))
        
        proj = table.select(select_exprs)
        state.records_tables[step.output] = proj

    @_handle.register
    async def _handle_filter(self, step: FilterOp, state: State) -> None:
        """Filter rows in a table by conditions, with support for fuzzy matching.
        
        Handles standard comparisons, string operations, null checks, and fuzzy
        string matching using rapidfuzz. All conditions are combined with AND.
        """
        log.info("[Executor] Executing filter: %s", step)
        df = await self._get_table_from_state(state, step.input)
        
        if df.is_empty():
            log.info("[Executor] Filter input table is empty, returning empty table")
            state.segments_tables[step.output] = df
            return
        
        filter_exprs: list[pl.Expr] = []
        fuzzy_sort_needed = False
        
        for cond in step.conditions:
            col_name = cond.column
            op = cond.operator
            val = cond.value
            
            # Validate column exists
            if col_name not in df.columns:
                raise InvalidPlanError(
                    f"FILTER: column '{col_name}' not found in table. "
                    f"Available columns: {list(df.columns)}"
                )
            
            col_expr = pl.col(col_name)
            
            if op == "fuzzy_match":
                # Fuzzy string matching using rapidfuzz
                if val is None:
                    raise InvalidPlanError(
                        f"FILTER: 'fuzzy_match' operator requires a value for column '{col_name}'"
                    )
                search_term = str(val).lower()
                
                # Calculate fuzzy score for each row
                score_expr = col_expr.map_elements(
                    lambda x: fuzz.partial_ratio(search_term, str(x).lower()) if x is not None else 0.0,
                    return_dtype=pl.Float64
                )
                df = df.with_columns(score_expr.alias("_fuzzy_score"))
                filter_exprs.append(pl.col("_fuzzy_score") > 65)
                fuzzy_sort_needed = True
                
            elif op == "==":
                filter_exprs.append(col_expr == val)
                
            elif op == "!=":
                filter_exprs.append(col_expr != val)
                
            elif op == ">":
                filter_exprs.append(col_expr > val)
                
            elif op == "<":
                filter_exprs.append(col_expr < val)
                
            elif op == ">=":
                filter_exprs.append(col_expr >= val)
                
            elif op == "<=":
                filter_exprs.append(col_expr <= val)
                
            elif op == "contains":
                if val is None:
                    raise InvalidPlanError(
                        f"FILTER: 'contains' operator requires a value for column '{col_name}'"
                    )
                # Case-insensitive substring match
                filter_exprs.append(
                    col_expr.cast(pl.Utf8).str.to_lowercase().str.contains(
                        str(val).lower(), literal=True
                    )
                )
                
            elif op == "starts_with":
                if val is None:
                    raise InvalidPlanError(
                        f"FILTER: 'starts_with' operator requires a value for column '{col_name}'"
                    )
                # Case-insensitive prefix match
                filter_exprs.append(
                    col_expr.cast(pl.Utf8).str.to_lowercase().str.starts_with(
                        str(val).lower()
                    )
                )
                
            elif op == "in":
                if val is None:
                    raise InvalidPlanError(
                        f"FILTER: 'in' operator requires a list value for column '{col_name}'"
                    )
                if not isinstance(val, (list, tuple, set)):
                    raise InvalidPlanError(
                        f"FILTER: 'in' operator requires a list, got {type(val).__name__}"
                    )
                filter_exprs.append(col_expr.is_in(list(val)))
                
            elif op == "is_null":
                filter_exprs.append(col_expr.is_null())
                
            elif op == "not_null":
                filter_exprs.append(col_expr.is_not_null())
                
            else:
                raise InvalidPlanError(f"FILTER: unsupported operator '{op}'")
        
        # Apply all filter conditions (combined with AND)
        if filter_exprs:
            df = df.filter(pl.all_horizontal(filter_exprs))
        
        # Sort by fuzzy score if fuzzy matching was used
        if fuzzy_sort_needed:
            df = df.sort("_fuzzy_score", descending=True)
        
        # Apply row limit if specified
        if step.limit is not None and step.limit > 0:
            df = df.head(step.limit)
        
        # Zero-match short-circuit: halt execution if filter returns no rows
        if df.is_empty():
            conditions_desc = ", ".join(
                f"{c.column} {c.operator} {c.value!r}" for c in step.conditions
            )
            raise InvalidPlanError(
                f"FILTER returned 0 results for conditions: [{conditions_desc}]. "
                "Please clarify the search terms or try broader criteria."
            )
        
        # Store result in appropriate table type based on input
        if step.input in state.segments_tables:
            state.segments_tables[step.output] = df
        else:
            state.records_tables[step.output] = df
        
        log.info("[Executor] Completed filter, output rows: %d", df.height)

    @_handle.register
    async def _handle_join_temporal(self, step: JoinTemporalOp, state: State) -> None:
        REQUIRED_COLS = {"tdo_id", "start_s", "end_s"}

        def _ensure_cols(df: pl.DataFrame, alias: str) -> None:
            missing = REQUIRED_COLS - set(df.columns)
            if missing:
                raise InvalidPlanError(
                    f"JOIN_TEMPORAL: alias '{alias}' is missing required columns {sorted(missing)}"
                )

        left_df = state.segments_tables.get(step.left)
        if left_df is None:
            raise InvalidPlanError(
                f"JOIN_TEMPORAL left alias '{step.left}' not found in segments_tables"
            )
        right_df = state.segments_tables.get(step.right)
        if right_df is None:
            raise InvalidPlanError(
                f"JOIN_TEMPORAL right alias '{step.right}' not found in segments_tables"
            )

        _ensure_cols(left_df, step.left)
        _ensure_cols(right_df, step.right)

        # Temporal semi-join: keep only left rows that satisfy the relation with at least one right row
        matched_left = join_temporal(
            left=left_df,
            right=right_df,
            relation=step.relation,  # "BEFORE" | "AFTER" | "OVERLAPS" | "WITHIN"
            within_s=step.within_s,  # may be None
            tol=float(step.tolerance_s),  # default 0.0
            how="pairs",
        )

        # dedup exact duplicates on the core identity+time
        subset = [
            c
            for c in ("tdo_id", "start_s", "end_s", "signal", "channel", "content")
            if c in matched_left.columns
        ]
        if subset:
            matched_left = matched_left.unique(subset=subset)
        state.segments_tables[step.output] = matched_left

    @_handle.register
    async def _handle_merge(self, step: MergeOp, state: State) -> None:
        """Merge multiple segment tables, then dedupe or coalesce them."""
        dfs: list[SegmentsTable] = []
        for alias in step.inputs:
            try:
                dfs.append(state.segments_tables[alias])
            except KeyError:
                raise InvalidPlanError(
                    f"MERGE input alias '{alias}' not found in segments_tables"
                )
        if not dfs:
            raise InvalidPlanError("MERGE did not have any input data")

        merged: SegmentsTable = pl.concat(dfs, how="diagonal", rechunk=True)

        tol = step.tolerance_s if step.tolerance_s and step.tolerance_s > 0.0 else 0.0
        if step.coalesce:
            result: SegmentsTable = coalesce_segments(merged, tolerance_s=tol)
        else:
            # dedupe_segments handles its own key creation
            result: SegmentsTable = dedupe_segments(merged, tol=tol)

        state.segments_tables[step.output] = result

    async def _get_table_from_state(self, state: State, alias: str) -> Table:
        """Get a table (segments or records) from state by alias, including special tables.

        Args:
            state: The current execution state.
            alias: The alias of the table to retrieve.

        Returns:
            The requested table if found.

        Raises:
            InvalidPlanError: If the alias is not found.
        """
        # Try segments first, then records. Adjust to your State layout.
        if alias in state.segments_tables:
            return state.segments_tables[alias]
        if alias in state.records_tables:
            return state.records_tables[alias]
        # tdo metadata table?
        if alias == "_tdo_metadata":
            if state.tdo_table is None:
                tdos = await self.client.get_tdos(state.target, include_segments=False)
                state.tdo_table = new_tdo_table([tdo.to_dict() for tdo in tdos])
            return state.tdo_table
        # mention metadata table?
        if alias == "_mention_metadata":
            if state.mentions_table is None:
                # Explicitly fetch metadata since no segment operations have run yet
                match state.target:
                    case TargetByMention(mention_id=mid):
                        state.mentions_table = await self.client.get_mention_by_id(mid)
                    case TargetByWatchlist(watchlist_id=wid):
                        log.info("Fetching mentions metadata for watchlist %s", wid)
                        state.mentions_table = await self.client.get_mentions_by_watchlist(wid)
                        log.info("Fetched %d mentions for watchlist %s", len(state.mentions_table), wid)
                    case _:
                        state.mentions_table = new_mentions_table([])
            return state.mentions_table if state.mentions_table is not None else new_mentions_table([])
        if alias == "_watchlist_metadata":
            if state.watchlists_table is None:
                match state.target:
                    case TargetByWatchlist(watchlist_id=wid):
                        log.info("Fetching watchlist metadata for %s", wid)
                        state.watchlists_table = await self.client.get_watchlist_by_id(
                            wid
                        )
                        log.info("Fetched watchlist metadata for %s", wid)
                    case _:
                        state.watchlists_table = new_watchlists_table([])
            return state.watchlists_table
        raise InvalidPlanError(f"Unknown input alias '{alias}'")

    def _duration_expr(self) -> pl.Expr:
        """Duration expression helper."""
        return (pl.col("end_s") - pl.col("start_s")).cast(pl.Float64)

    def _compile_metric_expr(
        self, field: str | None, expr: str | None
    ) -> pl.Expr | None:
        """Compile a safe metric base expression.

        Supported:
        - field="score" → pl.col("score")
        - expr="duration()"  → end_s - start_s
        - expr="end_s - start_s" (alias)
        """
        if field:
            return pl.col(field)

        if expr:
            e = expr.strip().lower()
            if e == "duration()" or e == "end_s - start_s":
                return self._duration_expr()
            # (Optionally extend here with whitelisted cols / arithmetic.)
            raise ValueError(f"Unsupported expr: {expr!r}")

        # no field and no expr → allowed only for count()
        return None  # caller must handle this

    def _compile_metric_agg(self, name: str, spec: MetricSpec) -> pl.Expr:
        """Turn a single metric spec into a Polars aggregation expression with alias `name`."""
        fn = spec.get("fn")
        if fn is None:
            raise InvalidPlanError(f"Metric '{name}' is missing required 'fn' field")
        
        field = spec.get("field")
        expr = spec.get("expr")

        base = self._compile_metric_expr(field, expr)
        if fn == "count":
            return pl.count().alias(name)
        elif fn == "count_distinct":
            if base is None:
                raise InvalidPlanError(f"count_distinct for '{name}' needs field/expr")
            return base.n_unique().alias(name)
        elif fn == "sum":
            if base is None:
                raise InvalidPlanError(f"sum for '{name}' needs field/expr")
            return base.sum().alias(name)
        elif fn == "avg":
            if base is None:
                raise InvalidPlanError(f"avg for '{name}' needs field/expr")
            return base.mean().alias(name)
        elif fn == "min":
            if base is None:
                raise InvalidPlanError(f"min for '{name}' needs field/expr")
            return base.min().alias(name)
        elif fn == "max":
            if base is None:
                raise InvalidPlanError(f"max for '{name}' needs field/expr")
            return base.max().alias(name)

        raise InvalidPlanError(f"Unsupported fn '{fn}' for metric '{name}'")

    @_handle.register
    async def handle_aggregate(self, step: AggregateOp, state) -> None:
        df = await self._get_table_from_state(state, step.input)

        # Build aggregation expressions
        aggs = []
        for name, spec in step.metrics.items():
            aggs.append(self._compile_metric_agg(name, spec))

        if step.group_by:
            out = df.group_by(step.group_by).agg(aggs)
        else:
            out = df.select(aggs)
        state.segments_tables[step.output] = out

    async def _get_structured_table_data(
        self,
        step: AnswerWithOp,
        state: State,
        alias: str,
        sort_by: str | None = None,
        ascending: bool = True,
        table: Table | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Get structured table data for output, with optional sorting and limiting.

        Args:
           step: The AnswerWithOp step.
           state: The current State.
           alias: The alias of the table to get data for.
           sort_by: Column name to sort by, or None for no sorting.
           ascending: Sort order (True for ascending, False for descending).
           table: Optional Table to use directly instead of looking up alias.
           limit: Optional limit on the number of rows to include, overrides step.limit.

        Returns:
           A dictionary containing structured table data.
        """
        # Check if table exists and not empty
        if table is None:
            try:
                table = await self._get_table_from_state(state, alias)
            except InvalidPlanError:
                return {
                    "alias": alias,
                    "status": "missing",
                    "data": None,
                    "shape": (0, 0),
                    "columns": [],
                }

        if table.is_empty():
            return {
                "alias": alias,
                "status": "empty",
                "data": None,
                "shape": (0, table.width),
                "columns": list(table.columns),
            }

        # Sort and limit the table
        limit = limit if limit is not None else step.limit
        processed_table = table
        original_height = table.height
        
        if sort_by and sort_by in table.columns:
            processed_table = processed_table.sort(
                sort_by, descending=not ascending
            )

        # Apply row limit if specified and track truncation
        was_truncated = False
        if limit and limit > 0 and processed_table.height > limit:
            was_truncated = True
            processed_table = processed_table.head(limit)

        # Remove columns that are all null
        non_null_cols = [
            c
            for c in processed_table.columns
            if processed_table[c].null_count() < processed_table.height
        ]
        if non_null_cols:
            processed_table = processed_table.select(non_null_cols)

        return {
            "alias": alias,
            "status": "ok",
            "data": processed_table,
            "shape": (processed_table.height, processed_table.width),
            "columns": list(processed_table.columns),
            "original_height": original_height,
            "was_truncated": was_truncated,
            "truncation_info": f"Showing {processed_table.height} of {original_height} rows" if was_truncated else None,
        }

    async def _format_table(
        self,
        step: AnswerWithOp,
        state: State,
        alias: str,
        sort_by: str | None = None,
        ascending: bool = True,
        table: Table | None = None,
        limit: int | None = None,
    ) -> str:
        """Format a table for output, with optional sorting and limiting.
        If table is provided, use it directly; otherwise look up alias in state.

        Args:
           step: The AnswerWithOp step.
           state: The current State.
           alias: The alias of the table to format.
           sort_by: Column name to sort by, or None for no sorting.
           ascending: Sort order (True for ascending, False for descending).
           table: Optional Table to use directly instead of looking up alias.
           limit: Optional limit on the number of rows to include, overrides step.limit.

        Returns:
           A string representation of the table.
        """
        # Get structured data and format it
        structured_data = await self._get_structured_table_data(
            step, state, alias, sort_by, ascending, table
        )

        alias = structured_data["alias"]
        status = structured_data["status"]
        shape = structured_data["shape"]
        was_truncated = structured_data.get("was_truncated", False)
        truncation_info = structured_data.get("truncation_info")

        ret = f"{alias} ({shape[0]}, {shape[1]}) = \n"
        
        # Add truncation warning if data was limited
        if was_truncated and truncation_info:
            ret += f"⚠️  {truncation_info}\n"

        if status == "missing":
            return ret + "<missing>\n"
        elif status == "empty":
            return ret + "(empty)\n"

        table_data = structured_data["data"]
        body = format_table_delimited(
            table_data,
            delimiter="\t",
            text_preview=None,
            round_digits=4,
            add_footer=True,
            limit_rows=limit if limit is not None else step.limit,
        )
        return ret + body

    @_handle.register
    async def _handle_answer_with(self, step: AnswerWithOp, state: State) -> None:
        log.debug("SEGMENTS TABLES:")
        for table in state.segments_tables.keys():
            log.debug("\n%s", await self._format_table(step, state, table, limit=3))
        log.debug("RECORDS TABLES:")
        for table in state.records_tables.keys():
            log.debug("\n%s", await self._format_table(step, state, table, limit=3))

        # Return structured data instead of formatted strings
        structured_summary = []
        any_truncated = False
        for output_table in step.inputs:
            table_data = await self._get_structured_table_data(
                step, state, output_table.alias,
                sort_by=output_table.sort_by,
                ascending=output_table.ascending
            )
            log.debug("Structured data for alias '%s': %s", output_table.alias, table_data)
            structured_summary.append(table_data)
            if table_data.get("was_truncated", False):
                any_truncated = True

        state.answer = {
            "summary": structured_summary,
            "has_truncated_data": any_truncated,
        }
