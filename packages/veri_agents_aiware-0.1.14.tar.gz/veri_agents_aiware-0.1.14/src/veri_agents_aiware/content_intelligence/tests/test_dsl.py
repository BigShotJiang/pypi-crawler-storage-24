"""Tests for DSL conversion functions in plan.py and ops.py."""

import pytest

from veri_agents_aiware.content_intelligence.ops import (
    _get_op_class_map,
)
from veri_agents_aiware.content_intelligence.plan import DslPlanOutput, generate_dsl_cheat_sheet, parse_dsl_to_plan


class TestGenerateDslCheatSheet:
    """Tests for generate_dsl_cheat_sheet function."""

    def test_generates_markdown_header(self):
        cheat_sheet = generate_dsl_cheat_sheet()
        assert "=== MEDIA ANALYSIS DSL ===" in cheat_sheet

    def test_contains_all_operations(self):
        cheat_sheet = generate_dsl_cheat_sheet()
        op_map = _get_op_class_map()
        for op_name in op_map.keys():
            assert f"## {op_name}" in cheat_sheet

    def test_documents_required_and_optional_args(self):
        cheat_sheet = generate_dsl_cheat_sheet()
        assert "(REQUIRED)" in cheat_sheet
        assert "(OPTIONAL)" in cheat_sheet

    def test_includes_examples_when_present(self):
        cheat_sheet = generate_dsl_cheat_sheet()
        # FindTranscriptOp has examples on the query field
        assert "Examples:" in cheat_sheet


class TestGetOpClassMap:
    """Tests for _get_op_class_map helper function."""

    def test_returns_dict_with_all_ops(self):
        op_map = _get_op_class_map()
        expected_ops = [
            "find_transcript",
            "find_text",
            "find_face",
            "find_logo",
            "get_transcripts",
            "get_text",
            "get_faces",
            "get_logos",
            "get_ocrs",
            "project",
            "filter",
            "join_temporal",
            "merge",
            "aggregate",
            "answer_with",
        ]
        assert set(op_map.keys()) == set(expected_ops)

    def test_values_are_pydantic_classes(self):
        op_map = _get_op_class_map()
        for cls in op_map.values():
            assert hasattr(cls, "model_fields")


class TestParseDslToPlan:
    """Tests for parse_dsl_to_plan function."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        """Helper to wrap a DSL script string in a DslPlanOutput."""
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_parses_single_operation(self):
        dsl_script = 'faces = find_face(where={"name": "Kobe Bryant"}, output="faces")'
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 1
        assert plan.steps[0].op == "find_face"
        assert plan.steps[0].output == "faces"

    def test_parses_multi_line_script(self):
        dsl_script = """
faces = find_face(where={"name": "Kobe Bryant"}, output="faces")
speech = find_transcript(query="basketball", search_mode="keyword", output="speech")
joined = join_temporal(left="faces", right="speech", relation="OVERLAPS", output="joined")
final = answer_with(inputs=[("joined", None)])
"""
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 4
        assert plan.steps[0].op == "find_face"
        assert plan.steps[1].op == "find_transcript"
        assert plan.steps[2].op == "join_temporal"
        assert plan.steps[3].op == "answer_with"

    def test_parses_without_assignment(self):
        dsl_script = 'find_face(where={"name": "Test"}, output="test")'
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 1
        assert plan.steps[0].op == "find_face"

    def test_search_mode_enum_conversion(self):
        dsl_script = 'find_transcript(query="test", search_mode="keyword", output="speech")'
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].search_mode.value == "keyword"

    def test_raises_on_invalid_syntax(self):
        dsl_script = "find_face(where={"  # Invalid Python syntax
        with pytest.raises(ValueError, match="DSL Syntax Error"):
            parse_dsl_to_plan(self._make_dsl(dsl_script))

    def test_raises_on_invalid_operation(self):
        dsl_script = 'invalid_op(output="test")'
        with pytest.raises(ValueError, match="Invalid operation"):
            parse_dsl_to_plan(self._make_dsl(dsl_script))

    def test_raises_on_validation_failure(self):
        # find_transcript requires 'query' argument
        dsl_script = 'find_transcript(output="test")'
        with pytest.raises(ValueError, match="Validation failed"):
            parse_dsl_to_plan(self._make_dsl(dsl_script))

    def test_ignores_comments_and_empty_lines(self):
        dsl_script = """
# This is a comment
faces = find_face(where={"name": "Test"}, output="faces")

# Another comment
"""
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 1

    def test_parses_complex_nested_structures(self):
        dsl_script = """
agg = aggregate(
    input="faces",
    output="face_counts",
    group_by=["content"],
    metrics={"count": {"fn": "count"}, "total_time": {"fn": "sum", "expr": "duration()"}}
)
"""
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 1
        assert plan.steps[0].op == "aggregate"
        assert plan.steps[0].group_by == ["content"]
        assert "count" in plan.steps[0].metrics


class TestDslPlanOutput:
    """Tests for DslPlanOutput schema."""

    def test_creates_valid_instance(self):
        output = DslPlanOutput(
            reasoning="Test reasoning",
            dsl_script='find_face(output="test")',
        )
        assert output.reasoning == "Test reasoning"
        assert output.dsl_script == 'find_face(output="test")'

    def test_requires_both_fields(self):
        with pytest.raises(Exception):
            DslPlanOutput(reasoning="Only reasoning")

    def test_serializes_to_json(self):
        output = DslPlanOutput(
            reasoning="Test",
            dsl_script="answer_with(inputs=[])",
        )
        json_str = output.model_dump_json()
        assert "reasoning" in json_str
        assert "dsl_script" in json_str


class TestFilterOpDsl:
    """Tests for FilterOp DSL parsing."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        """Helper to wrap a DSL script string in a DslPlanOutput."""
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_parses_filter_with_equality_condition(self):
        dsl_script = '''
filtered_tdos = filter(
    input="_tdo_metadata",
    output="filtered_tdos",
    conditions=[{"column": "status", "operator": "==", "value": "completed"}]
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 1
        assert plan.steps[0].op == "filter"
        assert plan.steps[0].input == "_tdo_metadata"
        assert plan.steps[0].output == "filtered_tdos"
        assert len(plan.steps[0].conditions) == 1
        assert plan.steps[0].conditions[0].column == "status"
        assert plan.steps[0].conditions[0].operator == "=="
        assert plan.steps[0].conditions[0].value == "completed"

    def test_parses_filter_with_fuzzy_match(self):
        dsl_script = '''
filtered = filter(
    input="_tdo_metadata",
    output="matched_files",
    conditions=[{"column": "name", "operator": "fuzzy_match", "value": "Stretch budget"}]
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 1
        assert plan.steps[0].op == "filter"
        assert plan.steps[0].conditions[0].operator == "fuzzy_match"
        assert plan.steps[0].conditions[0].value == "Stretch budget"

    def test_parses_filter_with_multiple_conditions(self):
        dsl_script = '''
filtered = filter(
    input="_tdo_metadata",
    output="filtered",
    conditions=[
        {"column": "name", "operator": "fuzzy_match", "value": "budget report"},
        {"column": "score", "operator": ">", "value": 0.5},
        {"column": "status", "operator": "!=", "value": "deleted"}
    ]
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps[0].conditions) == 3
        assert plan.steps[0].conditions[0].operator == "fuzzy_match"
        assert plan.steps[0].conditions[1].operator == ">"
        assert plan.steps[0].conditions[2].operator == "!="

    def test_parses_filter_with_limit(self):
        dsl_script = '''
filtered = filter(
    input="_tdo_metadata",
    output="top_matches",
    conditions=[{"column": "name", "operator": "contains", "value": "report"}],
    limit=10
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].limit == 10

    def test_parses_filter_with_contains_operator(self):
        dsl_script = '''
filtered = filter(
    input="files",
    output="matching",
    conditions=[{"column": "filename", "operator": "contains", "value": "budget"}]
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].conditions[0].operator == "contains"

    def test_parses_filter_with_in_operator(self):
        dsl_script = '''
filtered = filter(
    input="files",
    output="matching",
    conditions=[{"column": "type", "operator": "in", "value": ["video", "audio"]}]
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].conditions[0].operator == "in"
        assert plan.steps[0].conditions[0].value == ["video", "audio"]

    def test_parses_filter_with_null_checks(self):
        dsl_script = '''
filtered = filter(
    input="files",
    output="with_transcript",
    conditions=[{"column": "transcript_id", "operator": "not_null"}]
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].conditions[0].operator == "not_null"

    def test_parses_filter_in_pipeline_with_get_transcripts(self):
        """Test that filter output can be passed to get_transcripts via tdo_ids."""
        dsl_script = '''
filtered = filter(
    input="_tdo_metadata",
    output="target_files",
    conditions=[{"column": "name", "operator": "fuzzy_match", "value": "stretch budget"}],
    limit=5
)
transcripts = get_transcripts(output="speech", tdo_ids="target_files")
final = answer_with(inputs=[{"alias": "speech", "sort_by": None, "ascending": True}])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 3
        assert plan.steps[0].op == "filter"
        assert plan.steps[1].op == "get_transcripts"
        assert plan.steps[1].tdo_ids == "target_files"
        assert plan.steps[2].op == "answer_with"

    def test_raises_on_invalid_filter_operator(self):
        dsl_script = '''
filtered = filter(
    input="_tdo_metadata",
    output="filtered",
    conditions=[{"column": "name", "operator": "invalid_op", "value": "test"}]
)
'''
        with pytest.raises(ValueError, match="Validation failed"):
            parse_dsl_to_plan(self._make_dsl(dsl_script))

    def test_raises_on_missing_conditions(self):
        dsl_script = '''
filtered = filter(
    input="_tdo_metadata",
    output="filtered"
)
'''
        with pytest.raises(ValueError, match="Validation failed"):
            parse_dsl_to_plan(self._make_dsl(dsl_script))


class TestGetOpsDsl:
    """Tests for GET_* operations with tdo_ids parameter."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_get_transcripts_with_tdo_ids_list(self):
        dsl_script = '''
transcripts = get_transcripts(output="speech", tdo_ids=["id1", "id2", "id3"])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "get_transcripts"
        assert plan.steps[0].tdo_ids == ["id1", "id2", "id3"]

    def test_get_transcripts_with_table_alias(self):
        dsl_script = '''
transcripts = get_transcripts(output="speech", tdo_ids="filtered_files")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].tdo_ids == "filtered_files"

    def test_get_transcripts_without_tdo_ids(self):
        dsl_script = '''
transcripts = get_transcripts(output="speech")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].tdo_ids is None

    def test_get_transcripts_with_granularity(self):
        dsl_script = '''
transcripts = get_transcripts(output="speech", granularity="full")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].granularity == "full"

    def test_get_faces_with_tdo_ids(self):
        dsl_script = '''
faces = get_faces(output="detected_faces", tdo_ids="target_media")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "get_faces"
        assert plan.steps[0].tdo_ids == "target_media"

    def test_get_logos_with_tdo_ids(self):
        dsl_script = '''
logos = get_logos(output="detected_logos", tdo_ids=["media1", "media2"])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "get_logos"
        assert plan.steps[0].tdo_ids == ["media1", "media2"]

    def test_get_ocrs_with_tdo_ids(self):
        dsl_script = '''
ocrs = get_ocrs(output="ocr_results", tdo_ids="filtered_docs")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "get_ocrs"
        assert plan.steps[0].tdo_ids == "filtered_docs"

    def test_get_text_with_tdo_ids_and_granularity(self):
        dsl_script = '''
text = get_text(output="doc_text", tdo_ids="target_docs", granularity="full")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "get_text"
        assert plan.steps[0].tdo_ids == "target_docs"
        assert plan.steps[0].granularity == "full"


class TestProjectOpDsl:
    """Tests for ProjectOp DSL parsing."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_parses_project_with_select(self):
        dsl_script = '''
slim_data = project(
    input="_tdo_metadata",
    output="slim_data",
    select={"tdo_id": "id", "name": "filename", "created_at": "date"}
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "project"
        assert plan.steps[0].input == "_tdo_metadata"
        assert plan.steps[0].output == "slim_data"
        assert plan.steps[0].select == {"tdo_id": "id", "name": "filename", "created_at": "date"}

    def test_parses_project_single_field(self):
        dsl_script = '''
ids_only = project(input="faces", output="face_ids", select={"entity_id": "id"})
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].select == {"entity_id": "id"}


class TestJoinTemporalOpDsl:
    """Tests for JoinTemporalOp DSL parsing."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_parses_join_temporal_overlaps(self):
        dsl_script = '''
face_logo_pairs = join_temporal(
    left="faces",
    right="logos",
    relation="OVERLAPS",
    output="face_logo_pairs"
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "join_temporal"
        assert plan.steps[0].left == "faces"
        assert plan.steps[0].right == "logos"
        assert plan.steps[0].relation == "OVERLAPS"
        assert plan.steps[0].output == "face_logo_pairs"

    def test_parses_join_temporal_before_with_within(self):
        dsl_script = '''
joined = join_temporal(
    left="speech",
    right="faces",
    relation="BEFORE",
    within_s=5.0,
    output="speech_before_face"
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].relation == "BEFORE"
        assert plan.steps[0].within_s == 5.0

    def test_parses_join_temporal_with_tolerance(self):
        dsl_script = '''
joined = join_temporal(
    left="faces",
    right="speech",
    relation="WITHIN",
    tolerance_s=0.5,
    output="faces_within_speech"
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].relation == "WITHIN"
        assert plan.steps[0].tolerance_s == 0.5

    def test_parses_join_temporal_after(self):
        dsl_script = '''
joined = join_temporal(left="a", right="b", relation="AFTER", output="result")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].relation == "AFTER"


class TestMergeOpDsl:
    """Tests for MergeOp DSL parsing."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_parses_merge_multiple_inputs(self):
        dsl_script = '''
all_segments = merge(inputs=["faces", "logos", "speech"], output="all_segments")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "merge"
        assert plan.steps[0].inputs == ["faces", "logos", "speech"]
        assert plan.steps[0].output == "all_segments"

    def test_parses_merge_with_tolerance(self):
        dsl_script = '''
merged = merge(inputs=["seg1", "seg2"], output="merged", tolerance_s=1.0)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].tolerance_s == 1.0

    def test_parses_merge_without_coalesce(self):
        dsl_script = '''
merged = merge(inputs=["a", "b"], output="merged", coalesce=False)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].coalesce is False

    def test_parses_merge_default_coalesce(self):
        dsl_script = '''
merged = merge(inputs=["a", "b"], output="merged")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].coalesce is True


class TestAggregateOpDsl:
    """Tests for AggregateOp DSL parsing."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_parses_aggregate_with_group_by(self):
        dsl_script = '''
stats = aggregate(
    input="faces",
    output="face_stats",
    group_by=["content"],
    metrics={"count": {"fn": "count"}}
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "aggregate"
        assert plan.steps[0].group_by == ["content"]
        assert plan.steps[0].metrics["count"]["fn"] == "count"

    def test_parses_aggregate_with_duration(self):
        dsl_script = '''
screen_time = aggregate(
    input="faces",
    output="screen_time",
    group_by=["content"],
    metrics={"total_time": {"fn": "sum", "expr": "duration()"}}
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].metrics["total_time"]["fn"] == "sum"
        assert plan.steps[0].metrics["total_time"]["expr"] == "duration()"

    def test_parses_aggregate_with_multiple_metrics(self):
        dsl_script = '''
stats = aggregate(
    input="faces",
    output="face_summary",
    group_by=["content", "tdo_id"],
    metrics={
        "appearances": {"fn": "count"},
        "screen_time": {"fn": "sum", "expr": "duration()"},
        "avg_confidence": {"fn": "avg", "field": "score"},
        "max_confidence": {"fn": "max", "field": "score"}
    }
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps[0].metrics) == 4
        assert plan.steps[0].metrics["appearances"]["fn"] == "count"
        assert plan.steps[0].metrics["avg_confidence"]["field"] == "score"

    def test_parses_aggregate_without_group_by(self):
        dsl_script = '''
total = aggregate(
    input="faces",
    output="total_count",
    metrics={"total": {"fn": "count"}}
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].group_by == []

    def test_parses_aggregate_count_distinct(self):
        dsl_script = '''
unique = aggregate(
    input="faces",
    output="unique_people",
    metrics={"unique_faces": {"fn": "count_distinct", "field": "content"}}
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].metrics["unique_faces"]["fn"] == "count_distinct"


class TestAnswerWithOpDsl:
    """Tests for AnswerWithOp DSL parsing."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_parses_answer_with_single_table(self):
        dsl_script = '''
answer_with(inputs=[{"alias": "results", "sort_by": None, "ascending": True}])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "answer_with"
        assert len(plan.steps[0].inputs) == 1
        assert plan.steps[0].inputs[0].alias == "results"

    def test_parses_answer_with_sorting(self):
        dsl_script = '''
answer_with(inputs=[{"alias": "ranked", "sort_by": "score", "ascending": False}])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].inputs[0].sort_by == "score"
        assert plan.steps[0].inputs[0].ascending is False

    def test_parses_answer_with_multiple_tables(self):
        dsl_script = '''
answer_with(inputs=[
    {"alias": "faces", "sort_by": "screen_time", "ascending": False},
    {"alias": "logos", "sort_by": None, "ascending": True}
])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps[0].inputs) == 2
        assert plan.steps[0].inputs[0].alias == "faces"
        assert plan.steps[0].inputs[1].alias == "logos"

    def test_parses_answer_with_limit(self):
        dsl_script = '''
answer_with(inputs=[{"alias": "data", "sort_by": None, "ascending": True}], limit=100)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].limit == 100

    def test_parses_answer_with_default_limit(self):
        dsl_script = '''
answer_with(inputs=[{"alias": "data", "sort_by": None, "ascending": True}])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].limit == 5000  # default value


class TestFindOpsDsl:
    """Tests for FIND_* operations."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_parses_find_transcript_semantic(self):
        dsl_script = '''
speech = find_transcript(query="discussions about climate change", output="climate_speech")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "find_transcript"
        assert plan.steps[0].query == "discussions about climate change"
        assert plan.steps[0].search_mode.value == "semantic"

    def test_parses_find_transcript_keyword_window(self):
        dsl_script = '''
speech = find_transcript(
    query="Apple OR Google OR Microsoft",
    search_mode="keyword_window",
    output="tech_mentions"
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].search_mode.value == "keyword_window"

    def test_parses_find_transcript_keyword_hit(self):
        dsl_script = '''
hits = find_transcript(
    query='"inflation" OR "interest rates"',
    search_mode="keyword_hit",
    output="econ_hits"
)
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].search_mode.value == "keyword_hit"

    def test_parses_find_text(self):
        dsl_script = '''
docs = find_text(query="risk factors and compliance", output="risk_docs")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "find_text"
        assert plan.steps[0].query == "risk factors and compliance"

    def test_parses_find_text_with_granularity(self):
        dsl_script = '''
docs = find_text(query="revenue growth", output="revenue", granularity="token")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].granularity == "token"

    def test_parses_find_face_by_name(self):
        dsl_script = '''
faces = find_face(where={"name": "Elon Musk"}, output="elon_appearances")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "find_face"
        assert plan.steps[0].where == {"name": "Elon Musk"}

    def test_parses_find_face_by_entity_id(self):
        dsl_script = '''
faces = find_face(where={"entityId": "entity-123"}, output="person_appearances")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].where == {"entityId": "entity-123"}

    def test_parses_find_logo(self):
        dsl_script = '''
logos = find_logo(where={"name": "Nike"}, output="nike_appearances")
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert plan.steps[0].op == "find_logo"
        assert plan.steps[0].where == {"name": "Nike"}


class TestComplexPipelineDsl:
    """Tests for complex multi-step pipelines."""

    def _make_dsl(self, script: str) -> DslPlanOutput:
        return DslPlanOutput(reasoning="Test reasoning", dsl_script=script)

    def test_filter_then_extract_pipeline(self):
        """Filter files, then extract faces from the filtered set."""
        dsl_script = '''
target_files = filter(
    input="_tdo_metadata",
    output="target_files",
    conditions=[{"column": "name", "operator": "fuzzy_match", "value": "quarterly earnings"}],
    limit=10
)
faces = get_faces(output="faces", tdo_ids="target_files")
summary = aggregate(
    input="faces",
    output="face_summary",
    group_by=["content"],
    metrics={"screen_time": {"fn": "sum", "expr": "duration()"}}
)
answer_with(inputs=[{"alias": "face_summary", "sort_by": "screen_time", "ascending": False}])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 4
        assert plan.steps[0].op == "filter"
        assert plan.steps[1].op == "get_faces"
        assert plan.steps[1].tdo_ids == "target_files"
        assert plan.steps[2].op == "aggregate"
        assert plan.steps[3].op == "answer_with"

    def test_temporal_join_pipeline(self):
        """Find co-occurrences of faces and logos."""
        dsl_script = '''
faces = find_face(where={"name": "John"}, output="john_appearances")
logos = get_logos(output="all_logos")
together = join_temporal(left="john_appearances", right="all_logos", relation="OVERLAPS", output="john_with_logos")
stats = aggregate(
    input="together",
    output="logo_stats",
    group_by=["content_right"],
    metrics={"coappearances": {"fn": "count"}}
)
answer_with(inputs=[{"alias": "logo_stats", "sort_by": "coappearances", "ascending": False}])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 5
        assert plan.steps[2].op == "join_temporal"
        assert plan.steps[2].left == "john_appearances"
        assert plan.steps[2].right == "all_logos"

    def test_merge_and_aggregate_pipeline(self):
        """Merge multiple segment sources and aggregate."""
        dsl_script = '''
faces = get_faces(output="faces")
logos = get_logos(output="logos")
all_visual = merge(inputs=["faces", "logos"], output="visual_elements", tolerance_s=0.5)
stats = aggregate(
    input="visual_elements",
    output="visual_summary",
    metrics={"total_detections": {"fn": "count"}, "total_time": {"fn": "sum", "expr": "duration()"}}
)
answer_with(inputs=[{"alias": "visual_summary", "sort_by": None, "ascending": True}])
'''
        plan = parse_dsl_to_plan(self._make_dsl(dsl_script))
        assert len(plan.steps) == 5
        assert plan.steps[2].op == "merge"
        assert plan.steps[2].inputs == ["faces", "logos"]
