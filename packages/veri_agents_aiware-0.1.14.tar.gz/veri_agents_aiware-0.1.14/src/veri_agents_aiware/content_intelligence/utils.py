import logging
from typing import Sequence

from langchain_core.messages import AnyMessage
from langchain_core.messages.utils import count_tokens_approximately
from veri_agents_aiware.content_intelligence.data import format_table_delimited

log = logging.getLogger(__name__)


def format_sterilized_chat_history(
    messages: Sequence[AnyMessage], 
    max_history_turns: int = 5,
    max_tokens: int | None = None,
) -> str:
    """
    Extracts a clean, plain-text chat history from the UI message ledger.
    Filters out tool calls, keeps only string content, and truncates old history.
    
    Args:
        messages: The list of messages to format (usually messages[:-1] to exclude current query).
        max_history_turns: The maximum number of conversational messages to retain.
        max_tokens: Optional maximum tokens for the history. If exceeded, oldest messages 
                    are removed first (keeping most recent).
    """
    valid_history = []
    
    for msg in messages:
        # Strict filtering: Only humans and AI, only raw strings, no tool messages etc.
        if msg.type in ["human", "ai"] and isinstance(msg.content, str) and msg.content.strip():
            role = "User" if msg.type == "human" else "Agent"
            valid_history.append(f"{role}: {msg.content}")

    original_count = len(valid_history)

    # Turn-based truncation: keep most recent N
    if len(valid_history) > max_history_turns:
        valid_history = valid_history[-max_history_turns:]

    # Token-based truncation: remove oldest until we fit
    if max_tokens is not None and valid_history:
        truncation_marker = "[... earlier conversational history truncated ...]"
        marker_tokens = count_tokens_approximately([truncation_marker + "\n"])
        target_tokens = max(0, max_tokens - marker_tokens)  # Reserve space for marker
        
        while len(valid_history) > 1:  # Keep at least the most recent message
            current_text = "\n".join(valid_history)
            if count_tokens_approximately([current_text]) <= target_tokens:
                break
            # Remove the oldest message (first in list)
            valid_history.pop(0)

    # Add truncation marker if any messages were removed
    was_truncated = len(valid_history) < original_count
    if was_truncated and valid_history:
        valid_history.insert(0, "[... earlier conversational history truncated ...]")

    return "\n".join(valid_history) if valid_history else ""


def truncate_previous_data(
    data_str: str,
    max_tokens: int = 20000,
) -> str:
    """
    Truncate previous execution data to fit within a token budget.
    
    Preserves as much data as possible while ensuring we don't overflow
    the context window. Truncates from the end (keeping earlier/header content)
    and adds a truncation marker.
    
    Args:
        data_str: The previous execution data string to potentially truncate.
        max_tokens: Maximum tokens to allow for this data.
    
    Returns:
        The (potentially truncated) data string with truncation marker if needed.
    """
    if not data_str:
        return ""
    
    current_tokens = count_tokens_approximately([data_str])
    if current_tokens <= max_tokens:
        return data_str
    
    # Split into lines and truncate from the end
    lines = data_str.splitlines()
    truncated_lines = []
    accumulated_tokens = 0
    truncation_marker = "\n[... execution data truncated due to size ...]"
    marker_tokens = count_tokens_approximately([truncation_marker])
    target_tokens = max_tokens - marker_tokens
    
    for line in lines:
        line_with_newline = line + "\n"
        line_tokens = count_tokens_approximately([line_with_newline])
        
        if accumulated_tokens + line_tokens > target_tokens:
            # Stop here and add truncation marker
            break
        
        truncated_lines.append(line)
        accumulated_tokens += line_tokens
    
    result = "\n".join(truncated_lines) + truncation_marker
    log.info(
        f"Truncated previous data from {current_tokens} to ~{count_tokens_approximately([result])} tokens"
    )
    return result


def format_structured_table_for_context(table_data: dict) -> str:
    """Format structured table data for LLM context."""
    alias = table_data.get("alias", "unknown")
    status = table_data.get("status", "unknown")
    shape = table_data.get("shape", (0, 0))
    was_truncated = table_data.get("was_truncated", False)
    truncation_info = table_data.get("truncation_info")

    if status == "missing":
        return f"{alias}: Table not found"
    elif status == "empty":
        return f"{alias}: Table is empty"
    elif status != "ok":
        return f"{alias}: Table status: {status}"

    # Get the actual polars DataFrame
    df = table_data.get("data")
    if df is None:
        return f"{alias}: No data available"

    formatted_table = format_table_delimited(
        df,
        delimiter="\t",
        text_preview=None,
        round_digits=4,
        add_footer=True,
        limit_rows=10000,  # Large limit for now, we'll handle chunking separately
    )

    # Build the result with truncation warning if applicable
    header = f"{alias} ({shape[0]} rows, {shape[1]} cols)"
    if was_truncated and truncation_info:
        header += f" - ⚠️ DATA TRUNCATED: {truncation_info}"

    return f"{header}:\n{formatted_table}"


def chunk_text_tables(
    formatted_tables: list[str], max_tokens_per_chunk: int = 50000
) -> list[str]:
    """
    Split pre-formatted table strings into manageable chunks for bulk processing.

    Args:
        formatted_tables: List of already formatted table strings
        max_tokens_per_chunk: Maximum tokens per chunk

    Returns:
        List of text chunks, each containing one or more tables
    """
    # Filter out empty/missing table notifications - they add no value
    meaningful_tables = [
        t for t in formatted_tables 
        if not (t.endswith(": Table is empty") or t.endswith(": Table not found") or ": Table status:" in t or ": No data available" in t)
    ]
    
    chunks = []
    current_chunk = ""
    current_tokens = 0
    fitting_tables = []

    # first we have to split tables that are by itself too long already
    for i, table_text in enumerate(meaningful_tables):
        table_tokens = count_tokens_approximately([table_text])
        if table_tokens > max_tokens_per_chunk:
            log.warning(
                f"[Executor] Single table {i} exceeds max tokens per chunk ({table_tokens} > {max_tokens_per_chunk}), splitting it individually."
            )
            # Split this table into smaller parts by lines
            lines = table_text.splitlines()
            header = lines[0] if lines else ""
            part = header + "\n"
            part_tokens = count_tokens_approximately([part])
            for line in lines[1:]:
                line_tokens = count_tokens_approximately([line + "\n"])
                if part_tokens + line_tokens > max_tokens_per_chunk and part:
                    chunks.append(part.strip())
                    part = header + "\n"  # start new part with header
                    part += line + "\n"
                    part_tokens = count_tokens_approximately([part])
                else:
                    part += line + "\n"
                    part_tokens += line_tokens
            if part:
                chunks.append(part.strip())
        else:
            # Keep the table as is for normal processing
            fitting_tables.append(table_text)

    # process the remaining tables that fit, perhaps we can squeeze two or more into one chunk
    for table_text in fitting_tables:
        table_tokens = count_tokens_approximately([table_text])

        # If adding this table would exceed the limit, save current chunk and start new one
        if current_tokens + table_tokens > max_tokens_per_chunk and current_chunk:
            chunks.append(current_chunk.strip())
            current_chunk = table_text
            current_tokens = table_tokens
        else:
            # Add table to current chunk
            if current_chunk:
                current_chunk += "\n\n" + table_text
            else:
                current_chunk = table_text
            current_tokens += table_tokens

    # Add the last chunk if it has content
    if current_chunk:
        chunks.append(current_chunk.strip())

    return chunks
