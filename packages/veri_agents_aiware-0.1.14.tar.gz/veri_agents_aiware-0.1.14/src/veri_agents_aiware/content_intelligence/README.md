# Content Intelligence Toolkit

The Content Intelligence Toolkit is a sophisticated LangGraph-based agent system that uses Large Language Models (LLMs) to create and execute plans for analyzing media content using the aiWARE platform. It provides a declarative approach to media analysis through structured execution plans.

## Overview

The system follows a **Triage → Plan → Execute → Summarize** pattern:

1. **Triage**: The agent first checks if it can answer from cached data (optimistic answering), otherwise routes to planning
2. **Plan Creation**: An LLM generates a structured execution plan using available operations via forced structured output
3. **Plan Execution**: The executor deterministically runs each operation in the plan, processing media data
4. **Result Summarization**: The LLM receives the execution results and provides a natural language response

## Usage

The Content Intelligence Agent requires an aiWARE client and LLMs for planning, bulk processing, and summarization.
LLMs can be passed in as LangChain BaseChatModels, which includes the LLMGateway model from this package.

Example API use:
```
    from aiware.common.auth import TokenAuth, AiwareApiKey
    from veri_agents_aiware.aiware_client.async_client import AsyncAgentsAiware
    from veri_agents_aiware.content_intelligence import create_content_intelligence_agent, TargetSelector

    from langchain_aws import ChatBedrockConverse

    # Setup aiWARE client using an aiWARE API key
    aiware_client = AsyncAgentsAiware(
        base_url=aiware_url,
        auth=TokenAuth(token=AiwareApiKey(aiware_token)),
    )

    # LLM used for planning and making decisions
    llm = ChatBedrockConverse(
        model="arn:aws:bedrock:us-east-1:075494626733:application-inference-profile/nqd9c00141tr",
        base_model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        provider="anthropic",
        region_name="us-east-1",
    )
    # Bulk LLM used for large scale operations (e.g. summarization of transcripts)
    bulk_llm = ChatBedrockConverse(
        model="arn:aws:bedrock:us-east-1:075494626733:application-inference-profile/kl8qab6pdp97",
        base_model="us.amazon.nova-micro-v1:0",
        provider="amazon",
        region_name="us-east-1",
    )
    # LLM used to generate the final answer
    summary_llm = ChatBedrockConverse(
        max_tokens=2000,
        model="arn:aws:bedrock:us-east-1:075494626733:application-inference-profile/nhxrhd3b0en8",
        base_model="us.amazon.nova-2-lite-v1:0",
        provider="amazon",
        region_name="us-east-1",
    )

   # Default target
   target = TargetByIds(kind="tdo_ids", tdo_ids=tdo_ids)

   # Create the agent, can be done per query or once and reused
   content_agent = create_content_intelligence_agent(
      model=llm,
      model_summary=summary_llm,
      model_bulk=bulk_llm,
      aiware_client=aiware_client,
      target=target,
   )

   # Execute a query, can override target in context if desired
   result = await content_agent.ainvoke(
      {"messages": ["What's the screen time for John Doe?"]},
      context={
          "target": {"kind": "tdo_ids", "tdo_ids": ["tdo1", "tdo2"]}  # Override default target
      }
   )
```

## Evaluation

eval.py provides an evaluation framework for the Content Intelligence Agent using Langfuse and OpenEvals.

Requires the dev dependencies for veri_agents_aiware:
    `uv sync --all-groups`

Then run
    `uv run python -m veri_agents_aiware.content_intelligence.eval` 

For a quick local test run without writing to LangFuse:
    `uv run python -m veri_agents_aiware.content_intelligence.eval --local --debug -n 1`

Requires the following environment variables to be set:
   LABS_AIWARE_API_KEY - aiWARE API key
   LABS_AIWARE_BASE_URL - aiWARE base URL
   LANGFUSE_PUBLIC_KEY - Langfuse public key
   LANGFUSE_SECRET_KEY - Langfuse secret key
   LANGFUSE_URL - (optional) Langfuse base URL, defaults to https://langfuse.varp.tech

Also the IAM profile used must have access to Bedrock LLMs.

This usually happens automatically if you're running inside the dev container.


## Core Components

### 1. Plan (`plan.py`)

The planning system uses a lightweight Python-like DSL to generate execution plans. Instead of outputting the full Pydantic JSON schema (which can consume ~7,000 tokens), the LLM outputs a simple DSL script that is then safely parsed back into Pydantic models using AST.

**Key Features:**
- `Plan` model: Contains a list of operations with version tracking and signatures
- `DslPlanOutput` schema: Lightweight Pydantic model containing `reasoning` and `dsl_script` fields
- `generate_dsl_cheat_sheet()`: Auto-generates a token-efficient Markdown DSL manual from Pydantic Op definitions
- `parse_dsl_to_plan()`: Safely parses Python-like DSL scripts into strict Pydantic Plan models using AST (no eval)
- DSL validation through AST parsing + Pydantic schema enforcement

### 2. Operations (`ops.py`)

Operations define the atomic actions that can be performed on media content. They fall into several categories:

#### Data Retrieval Operations
- **find_transcript**: Search for specific text within transcripts using keyword or semantic search
- **find_text**: Search through textual content from ingested documents
- **find_face**: Find specific faces/persons by entity ID or name
- **find_logo**: Find specific logos/brands by entity ID or name
- **get_transcripts**: Retrieve all speech transcripts for target media
- **get_text**: Get textual content from ingested documents
- **get_faces**: Get all face occurrences in target media
- **get_logos**: Get all logo occurrences in target media
- **get_ocrs**: Get all OCR text occurrences in target media

> **Note**: All `get_*` operations accept an optional `tdo_ids` parameter that can be either a list of TDO ID strings or a table alias (string) containing a `tdo_id` column. This enables "predicate pushdown" where you filter metadata first, then extract data only from matching files.

#### Data Processing Operations
- **filter**: Filter rows in a table by conditions with support for fuzzy string matching
  - Operators: `==`, `!=`, `>`, `<`, `>=`, `<=`, `contains`, `starts_with`, `in`, `is_null`, `not_null`, `fuzzy_match`
  - `fuzzy_match` uses rapidfuzz for approximate string matching (e.g., "Stretch budget" matches "2025_Q3_Stretch_Budget_Final.mp4")
  - Results are sorted by match quality; rows with score ≤ 65 are filtered out
  - Zero-match short-circuit: raises error to trigger replan if no rows match
- **project**: Select and transform specific fields from segments into records
- **aggregate**: Perform grouping, counting, summing operations (e.g., screen time calculations)
- **merge**: Coalesce adjacent or overlapping segments (crucial for screen time analysis)
- **join_temporal**: Join segments from different signals based on temporal relationships
- **answer_with**: Define which table aliases are returned to the LLM for final processing (with optional sort specs)

#### Time Constraints
Operations support both relative (`MediaTime`) and absolute (`AbsTime`) time filtering:
- `MediaTime`: Relative to media timeline (e.g., seconds 10-30 of a video)
- `AbsTime`: Wall-clock time constraints for selecting which media to analyze

### 3. Data Schemas (`data.py`)

The system operates on strongly-typed Polars DataFrames with predefined schemas:

#### Core Data Types
- **SegmentsTable**: Time-bounded annotations within media (e.g., face detection from 10-15 seconds)
- **RecordsTable**: Aggregated data derived from segments (e.g., total screen time per person)
- **TdoTable**: Metadata about Temporal Data Objects (media files)
- **MentionsTable**: Metadata about Mentions (parts of TDOs)
- **WatchlistsTable**: Metadata about watchlists (saved searched producing mentions)

#### Segment Schema
```python
SEGMENT_SCHEMA = {
    "tdo_id": pl.Utf8,           # Media file identifier
    "start_s": pl.Float64,       # Start time in seconds
    "end_s": pl.Float64,         # End time in seconds
    "channel": pl.Utf8,          # audio/video/image/text
    "signal": pl.Utf8,           # transcript/face/logo/object/etc.
    "content": pl.Utf8,          # The actual content (transcript text, face names, logo names, etc.)
    "score": pl.Float64,         # Confidence score (0.0-1.0)
    "engine_id": pl.Utf8,        # Processing engine used
    "engine_name": pl.Utf8,      # Engine display name
    "abs_start_epoch_s": pl.Float64,  # Wall-clock start time
    "abs_end_epoch_s": pl.Float64,    # Wall-clock end time
    "bbox_json": pl.Utf8,        # Bounding box coordinates (JSON)
    "poly_json": pl.Utf8,        # Polygon coordinates (JSON)
    "meta_json": pl.Utf8,        # Additional metadata (JSON)
}
```

#### Target Selectors
Define what media content to analyze:
- `TargetByOrg`: All media in an organization
- `TargetByIds`: Specific media files by ID
- `TargetByFolder`: All media in a folder
- `TargetByWatchlist`: Media associated with a watchlist
- `TargetByMention`: Media associated with a specific mention

### 4. Executor (`executor.py`)

The executor provides deterministic execution of plans using single-dispatch pattern:

**Key Features:**
- `State` model: Tracks execution state including query, target, tables, and results
- Single-dispatch handlers for each operation type
- Error collection and reporting

**Execution Flow:**
1. Initialize state with query and target
2. Iterate through plan steps
3. Dispatch each step to appropriate handler
4. Accumulate results in state tables
5. Return final state with all results

### 5. Client (`client.py`)

The client handles all interactions with the aiWARE platform:

**Key Responsibilities:**
- **Data Retrieval**: Fetch media content and analysis results from aiWARE
- **Search Operations**: Execute complex queries against media indexes
- **Result Conversion**: Transform aiWARE responses into standardized segment format
- **Caching**: Optimize performance with intelligent caching strategies

**Key Features:**
- Async operations for performance
- Support for both search-based and direct TDO access
- Conversion utilities for different aiWARE result formats
- Handling of cognitive engine results from mentions

### 6. LangGraph Agent (`agent.py`)

The LangGraph agent orchestrates the entire content intelligence workflow using a state machine approach with the Command pattern for routing. It coordinates between all the other components to provide a seamless experience from query to answer.

#### Agent Architecture

The agent is built using LangGraph's `StateGraph` and follows a multi-node workflow pattern with built-in retry mechanisms and Command-based routing:

```
START → triage_input ─┬─→ prepare_plan ─┬─→ execute_plan ─┬─→ summarize ─┬─→ END
                      │                 │                 │              │
                      └→ END            │              rerun ←──┘        ├→ bulk_summarize → END
                      (optimistic)   replan ←──────────────┘             │    (parallel)
                                        │                                │
                                       END ←── (max 3 attempts) ←────────┘
                                              plan_feedback (evaluator loop)
```

#### Key Components

**AgentState**: Tracks the complete workflow state including:
- `messages`: Conversation history with the LLM
- `query`: User's original question
- `plan`: Generated execution plan
- `executor_result`: Results from plan execution
- `plan_generation_attempts`: Counter for retry mechanism
- `plan_execution_attempts`: Counter for execution retries
- `plan_validation_errors`: List of validation errors
- `plan_execution_errors`: List of execution errors
- `context_chunks`: For handling large result sets
- `chunk_summaries`: Intermediate summaries for bulk processing
- `signal_stats`: Cached signal availability for planning context
- `plan_feedback`: Evaluator feedback for guiding replanning when data is insufficient

**ContentIntelligenceInput**: Runtime context containing:
- `target`: Target selector defining what media to analyze

#### Workflow Nodes

All nodes use the **Command pattern** for explicit routing, making the control flow clear and localized:

1. **triage_input** (Command pattern):
   - Extracts query from user message
   - Cleans state for follow-up queries
   - Attempts optimistic answering from cached data (L1 cache)
   - Routes to `prepare_plan` if new data is needed, or directly to `END` if answerable from cache
   - Uses `get_triage_system_prompt` for context

2. **prepare_plan** (Command pattern, DSL Generation):
   - **Early exit**: If max attempts (3) reached, routes to `END` with error message
   - Fetches signal stats to inform the LLM about available data types
   - Uses `model.with_structured_output(DslPlanOutput)` to output a lightweight DSL script
   - Embeds DSL cheat sheet via `generate_dsl_cheat_sheet()` in system message
   - Incorporates `plan_feedback` from previous failed attempts to guide replanning
   - Parses DSL script into Pydantic Plan using `parse_dsl_to_plan()` (AST-based, no eval)
   - Fabricates `AIMessage` + `ToolMessage` for frontend compatibility
   - **On success**: Routes to `execute_plan`
   - **On parse/validation error**: Routes back to `prepare_plan` (retry)

3. **execute_plan** (Command pattern):
   - Creates `ExecutorState` with query, target, and plan
   - Instantiates `ContentIntelligenceClient` and `Executor`
   - Runs plan execution and collects results
   - Converts DataFrames to serializable format for LLM processing
   - **On success**: Routes to `summarize`
   - **On execution error (attempts < 2)**: Routes to `execute_plan` (retry same plan)
   - **On execution error (attempts >= 2)**: Routes to `prepare_plan` (new strategy)
   - **On invalid plan error**: Routes to `prepare_plan` (new strategy)

4. **summarize** (Command pattern, also acts as **Evaluator**):
   - Formats execution results for LLM context
   - **Evaluates data sufficiency**: If results are empty or insufficient, can trigger replan with feedback
   - For small contexts: generates answer and routes to `END`
   - For large contexts: chunks data and routes to `bulk_summarize`
   - For insufficient data: routes back to `prepare_plan` with `plan_feedback`
   - Uses `get_triage_system_prompt` for summarization context

5. **bulk_summarize** (Command pattern, parallel processing):
   - Processes all chunks **in parallel** using `asyncio.gather`
   - Aggregates chunk summaries into final answer
   - Routes to `END` with aggregated response

#### Advanced Features

**Pure Command Pattern Architecture**: All nodes use LangGraph's `Command` to explicitly route to next nodes, eliminating the need for separate routing functions or conditional edges:
- `triage_input`: Routes to `prepare_plan` or `END`
- `prepare_plan`: Routes to `execute_plan` (success), `prepare_plan` (retry), or `END` (max attempts)
- `execute_plan`: Routes to `summarize` (success), `execute_plan` (retry), or `prepare_plan` (replan)
- `summarize`: Routes to `prepare_plan` (evaluator replan), `bulk_summarize`, or `END`
- `bulk_summarize`: Routes to `END`

This architecture makes routing **explicit and localized**—when an error occurs, the node directly says where to go next instead of updating state and letting a separate function decide.

**DSL-Based Planning**: Instead of heavy Pydantic JSON schemas:
- Uses `model.with_structured_output(DslPlanOutput)` for lightweight DSL output
- LLM outputs Python-like DSL script (e.g., `faces = find_face(where={"name": "John"})`)
- DSL is parsed into Pydantic models using safe AST parsing (no eval)
- Reduces token usage from ~7,000 tokens (full schema) to ~1,500 tokens (DSL cheat sheet)
- Fabricates tool call messages for frontend UI compatibility

**Evaluator Feedback Loop**: Transforms the pipeline into a cognitive agent:
- The `summarize` node acts as both summarizer and **evaluator**
- If execution results are empty or insufficient to answer the query, the evaluator doesn't fabricate an answer
- Instead, it calls the `RequestReplan` tool with instructions for the planner (using tool-calling prevents escape-hatch strings from streaming to the UI)
- The planner receives this feedback and adjusts its search strategy (e.g., broader keywords, switch search modes)
- Maximum 3 total plan attempts to prevent infinite loops
- Enables aggressive first attempts (specific keyword searches) with a safety net for fallback

**Retry Mechanism**: Robust error handling with intelligent retry logic:
- **Execution Retries**: Up to 2 attempts to execute the same plan if execution fails
- **Plan Re-generation**: Up to 3 total plan generation attempts if validation fails
- **Graceful Termination**: Ends workflow after maximum attempts to prevent infinite loops
- **Error Differentiation**: Separate handling for validation vs. execution errors

**Parallel Bulk Processing**: For large result sets that exceed token limits:
- **Chunking**: Splits large results into manageable chunks
- **Parallel Execution**: Uses `asyncio.gather` to process all chunks concurrently
- **Aggregation**: Combines chunk summaries into final answer

**Optimistic Answering (L1 Cache)**:
- For follow-up questions, attempts to answer from cached execution results
- Configurable via `l1_cache_size` parameter
- Falls back to replanning if cached data is insufficient

**Error Handling & Recovery**:
- Plan validation failures trigger re-planning (with attempt tracking)
- Execution errors are captured and can trigger re-execution or re-planning
- Graceful fallbacks for missing data or API failures
- Clear error reporting when maximum attempts are reached

**Context Management**:
- Token-aware chunking prevents context overflow
- Intelligent table formatting with truncation warnings
- Separate models for planning vs. bulk processing

#### Routing Logic

All routing logic is embedded directly within each node using the Command pattern:

- **triage_input**: Routes based on cache availability and ability to answer from cached data
- **prepare_plan**: Routes based on plan validation success and attempt count (max 3)
- **execute_plan**: Routes based on execution success and attempt count (max 2 per plan)—differentiates between validation errors (always replan) and execution errors (retry then replan)
- **summarize**: Routes based on data sufficiency (evaluator role) and context size (bulk processing)

#### Usage Example

```python
# Create the agent
agent = create_content_intelligence_agent(
    model=your_llm_model,
    aiware_client=aiware_client,
    target=your_target_selector,  # Default target for all queries
    model_summary=optional_summary_model,  # For final answers
    model_bulk=optional_bulk_model,  # For chunk processing
    max_tokens_per_request=80000,  # Context size management
    l1_cache_size=10000,  # Optimistic answering threshold
)

# Execute a query
result = await agent.ainvoke(
    {"messages": [HumanMessage("What's the screen time for John Doe?")]},
    context={
        "target": {"kind": "tdo_ids", "tdo_ids": ["tdo1", "tdo2"]}  # Override default target
    }
)
```

The agent automatically:
1. Checks if it can answer from cached data (triage)
2. Generates an execution plan using DSL: `find_face → merge → aggregate → answer_with`
3. Executes the plan against the specified TDOs (with retry on failure)
4. Handles large result sets through parallel bulk processing if needed
5. Returns a natural language answer: "John Doe appears for 2 minutes and 15 seconds total"

#### Retry Behavior Example

```python
# If plan generation fails:
# Attempt 1: LLM generates invalid plan → replan
# Attempt 2: LLM generates valid plan → execute
# If execution fails:
# Attempt 1: Execution error → rerun same plan
# Attempt 2: Execution error again → replan (generate new plan)
# Attempt 3: New plan generated → execute
# If still failing: → end (graceful termination)
```

#### Evaluator Feedback Loop Example

```python
# User asks: "What did John say about Q3 revenue?"
#
# Attempt 1:
#   Planner: find_transcript(query='"John" AND "Q3 revenue"', search_mode="keyword")
#   Executor: Returns empty table (John never said "Q3 revenue" verbatim)
#   Evaluator: Calls RequestReplan(reason="'Q3 revenue' was too specific. Try semantic
#              search for financial topics, or search for just 'revenue' or 'earnings.")
#
# Attempt 2:
#   Planner (with feedback): find_transcript(query="revenue earnings financial results",
#                                            search_mode="semantic")
#   Executor: Returns 15 relevant transcript segments
#   Evaluator: Generates final answer from data
#
# Result: "John discussed revenue growth in three segments..."
```

#### Integration with Other Components

The agent serves as the orchestration layer that:
- Uses **prompts.py** for system context with separate prompts for triage/summarization vs. planning
- Uses **plan.py** `DslPlanOutput` schema + `parse_dsl_to_plan()` for DSL-based plan generation
- Delegates to **executor.py** for deterministic plan execution
- Leverages **client.py** for aiWARE data access
- Operates on **data.py** schemas for type safety
- Executes **ops.py** operations in sequence

This design separates concerns while providing a unified interface for complex media analysis tasks.

### 7. Background Context (`prompts.py`)

Provides domain knowledge and context to the LLM about aiWARE concepts. The module contains separate system prompts for different agent stages:

#### System Prompts

**Triage/Summary System Prompt** (`get_triage_system_prompt`):
- Used in `triage_input` for optimistic answering from cached data
- Used in `summarize` and `bulk_summarize` for generating final answers
- Focuses on answering questions based on retrieved data
- Emphasizes not making up information

**Planner System Prompt** (`get_planner_system_prompt`):
- Used in `prepare_plan` for generating execution plans
- Contains planning-specific guidelines (operations, aggregations, answer_with usage)
- Combined with dynamic DSL cheat sheet for target-specific context

**DSL Cheat Sheet** (`generate_dsl_cheat_sheet`):
- Auto-generated Markdown documentation from Pydantic Op definitions
- Lists all available operations with their required/optional arguments
- Includes field descriptions, defaults, and examples
- Token-efficient format (~1,500 tokens vs ~7,000 for full JSON schema)

**Plan Prompt** (`get_plan_prompt`):
- Dynamically generated based on target type and signal availability
- Includes metadata table aliases and target-specific context
- Informs the LLM about which signals are available in the target TDOs

#### Key Concepts Explained:

**Temporal Data Objects (TDOs)**
- Containers for media assets and their analysis results
- Include metadata like duration, creation time, asset type
- Users may refer to them as "videos", "files", or "media"

**Watchlists**
- Saved searches that continuously monitor for specific content
- Automatically generate mentions when matching content is found
- Support complex query logic with boolean operators

**Mentions**
- Results produced by watchlists when matching content is detected
- Point to specific TDOs and time ranges within them
- Include audience metrics and hit counts
- Link advertiser/brand information for commercial monitoring

**Segments vs Records**
- **Segments**: Raw time-bounded detections (e.g., face at 10-15 seconds)
- **Records**: Processed/aggregated data (e.g., total screen time = 45 seconds)

## Common Usage Patterns

### Screen Time Analysis
```
find_face(where={"name": "..."}) → merge → aggregate(group_by=["content"], metrics={"screen_time": {"fn": "sum", "expr": "duration()"}}) → answer_with
```

### Content Discovery
```
find_transcript(query="keyword") → project(select=[...]) → answer_with
```

### Temporal Relationships
```
find_face → find_transcript → join_temporal(relation="OVERLAPS") → answer_with
```

### Entity Counting
```
get_faces → aggregate(group_by=["content"], metrics={"count": {"fn": "count_distinct", "field": "content"}}) → answer_with
```

### Content Summarization
```
get_transcripts(granularity="full") → project(select=[...]) → answer_with
```

## Error Handling

The system includes comprehensive error handling:
- Plan validation before execution
- Operation-level error collection
- Graceful degradation for missing data
- Clear error messages for debugging

## Performance Considerations

- Uses Polars for efficient dataframe operations
- Async I/O for aiWARE communication
- **Parallel chunk processing** with `asyncio.gather` for bulk summarization
- Intelligent result chunking for large datasets
- LRU caching for repeated queries
- Token-aware truncation for LLM context limits
- Optimistic answering (L1 cache) to avoid unnecessary replanning
- DSL-based planning reduces token usage by ~80% compared to full Pydantic schemas

This toolkit enables sophisticated media analysis through natural language queries while maintaining the precision and performance required for production workloads.