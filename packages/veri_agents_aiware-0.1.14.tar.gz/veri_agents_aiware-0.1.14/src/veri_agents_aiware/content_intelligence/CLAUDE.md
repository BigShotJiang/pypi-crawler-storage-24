# Content Intelligence Toolkit - Claude Instructions

## Overview
You are working with a LangGraph-based agent system that analyzes media content via aiWARE. 
The system follows: **Plan → Execute → Summarize**

## Key Files
- `agent.py` - LangGraph workflow orchestration
- `ops.py` - Operation definitions (FIND_*, GET_*, AGGREGATE, etc.)
- `executor.py` - Deterministic plan execution
- `client.py` - aiWARE API interactions
- `data.py` - Polars DataFrame schemas (SegmentsTable, RecordsTable)
- `tdo.py` - MediaTDO wrapper for TDO data with segments
- `plan.py` - Plan generation via LLM tool calls
- `prompts.py` - System prompts and domain context

## Operations Available
**Data Retrieval:**
- FIND_TRANSCRIPT, FIND_TEXT, FIND_FACE, FIND_LOGO
- GET_TRANSCRIPTS, GET_TEXT, GET_FACES, GET_LOGOS, GET_OCRS
  - All GET_* ops accept optional `tdo_ids` parameter (list of IDs or table alias)
  - Enables "predicate pushdown": filter metadata first, then extract from filtered results

**Data Processing:**
- PROJECT, FILTER, AGGREGATE, MERGE, JOIN_TEMPORAL, OUTPUT

**FILTER operation** (with rapidfuzz fuzzy matching):
- Supports operators: ==, !=, >, <, >=, <=, contains, starts_with, in, is_null, not_null, fuzzy_match
- `fuzzy_match` uses rapidfuzz.fuzz.partial_ratio, returns rows with score > 65, sorted by match quality
- Zero-match short-circuit: raises InvalidPlanError if filter returns 0 rows to trigger replan

## Data Flow
1. `TargetSelector` defines scope (TDO IDs, folder, watchlist, mention)
2. Operations produce `SegmentsTable` (time-bounded annotations)
3. AGGREGATE transforms segments into `RecordsTable` (summary data)
4. OUTPUT sends results to LLM for natural language response

## MediaTDO Class (tdo.py)
- `from_tdo_ids()` - Batch fetch using `get_tdos_by_id_with_assets` (100 per batch)
- `from_tdo_id()` - Single TDO fetch with caching
- `include_segments=False` for cheap metadata-only queries
- Segments stored by signal type: transcript, face, logo, ocr, document
- All segment content (text, names, etc.) stored in unified 'content' field

## Client Patterns (client.py)
- All methods are async
- Uses `@async_lru.alru_cache` for caching
- Pagination pattern: loop while `cnt >= limit`, increment offset
- Vector search for semantic queries, Elasticsearch for keywords

## Agent Workflow
START → prepare_plan → tools → process_plan → execute_plan → summarize → END
- Retry up to 3 plan generations, 2 execution attempts per plan
- Bulk processing for large results: route_chunks → aggregate_summaries


## Coding Style

- Follow PEP8, use type hints whenever possible, prefer | None over Optional and avoid Union where possible.