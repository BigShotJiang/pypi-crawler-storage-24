# palobabu

A logic-helper library built on SymPy to quickly find contrapositives, conjunctions, and disjunctions.

## Installation
```bash
pip install palobabu