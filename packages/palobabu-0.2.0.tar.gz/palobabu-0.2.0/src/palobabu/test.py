from palobabu import (
    get_contrapositive, 
    get_conjunction, 
    get_disjunction, 
    get_formatted_truth_table
)
from sympy.abc import P, Q

print("--- 1. CONJUNCTION (P & Q) ---")
print(get_formatted_truth_table(get_conjunction(P, Q)))

print("\n--- 2. DISJUNCTION (P | Q) ---")
print(get_formatted_truth_table(get_disjunction(P, Q)))

print("\n--- 3. CONTRAPOSITIVE (~Q >> ~P) ---")
# Getting the contrapositive of P implies Q
contra = get_contrapositive(P >> Q)
print(f"Expression: {contra}")
print(get_formatted_truth_table(contra))