from .logic import (
    get_contrapositive, 
    get_conjunction, 
    get_disjunction, 
    get_formatted_truth_table
)