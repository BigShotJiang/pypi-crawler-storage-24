"""Helpers for deriving pipeline identifiers from JSON-LD."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Iterable, Union
import json


def _iter_nodes(doc: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
    graph = doc.get("@graph")
    if isinstance(graph, list):
        for node in graph:
            if isinstance(node, dict):
                yield node
    elif isinstance(doc, dict):
        yield doc


def _has_type(node: Dict[str, Any], candidates: set[str]) -> bool:
    raw = node.get("@type")
    types: list[str] = []
    if isinstance(raw, str):
        types.append(raw)
    elif isinstance(raw, list):
        for entry in raw:
            if isinstance(entry, str):
                types.append(entry)
            elif isinstance(entry, dict):
                entry_id = entry.get("@id")
                if isinstance(entry_id, str):
                    types.append(entry_id)
    elif isinstance(raw, dict):
        entry_id = raw.get("@id")
        if isinstance(entry_id, str):
            types.append(entry_id)
    return any(t in candidates for t in types)


def _local_id(value: str) -> str:
    if "#" in value:
        return value.split("#", 1)[1]
    if "/" in value:
        return value.rsplit("/", 1)[-1]
    if ":" in value:
        return value.split(":", 1)[1]
    return value


def _load_jsonld(value: Union[Dict[str, Any], str, Path]) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, Path):
        return json.loads(value.read_text(encoding="utf-8"))
    if isinstance(value, str):
        candidate = Path(value)
        if candidate.is_file():
            return json.loads(candidate.read_text(encoding="utf-8"))
        return json.loads(value)
    raise TypeError(f"Unsupported jsonld type: {type(value)!r}")


def derive_pipeline_id_from_jsonld(value: Union[Dict[str, Any], str, Path]) -> str:
    """Derive a stable pipeline id from a JSON-LD document (ProcessingPipeline @id)."""
    doc = _load_jsonld(value)
    pipeline_nodes = [
        node for node in _iter_nodes(doc) if _has_type(node, {"cf:ProcessingPipeline"})
    ]
    if not pipeline_nodes:
        raise ValueError("No cf:ProcessingPipeline node found in JSON-LD")
    if len(pipeline_nodes) > 1:
        raise ValueError("Multiple cf:ProcessingPipeline nodes found; pipeline id is ambiguous")
    node_id = pipeline_nodes[0].get("@id")
    if not isinstance(node_id, str) or not node_id.strip():
        raise ValueError("ProcessingPipeline node is missing a string @id")
    return _local_id(node_id)
