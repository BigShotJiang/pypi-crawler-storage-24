from __future__ import annotations

import math

import numpy as np
import pytest

from batcamp import Octree
from batcamp import OctreeInterpolator
from fake_dataset import FakeDataset as _FakeDataset
from fake_dataset import build_spherical_hex_mesh as _build_spherical_hex_mesh


def _build_uniform_spherical_hex_dataset(
    *,
    nr: int = 2,
    ntheta: int = 4,
    nphi: int = 8,
) -> tuple[_FakeDataset, np.ndarray, tuple[float, float, float, float]]:
    """Private test helper: build a synthetic full-sphere hexahedral dataset."""
    points, corners = _build_spherical_hex_mesh(
        nr=nr,
        ntheta=ntheta,
        nphi=nphi,
        r_min=1.0,
        r_max=3.0,
    )
    x = points[:, 0]
    y = points[:, 1]
    z = points[:, 2]
    r_nodes = np.sqrt(x * x + y * y + z * z)
    theta_nodes = np.arccos(np.clip(z / np.maximum(r_nodes, np.finfo(float).tiny), -1.0, 1.0))
    phi_nodes = np.mod(np.arctan2(y, x), 2.0 * math.pi)

    a, b, c, d = (1.7, -0.45, 0.3, 2.1)
    linear_field = a * r_nodes + b * theta_nodes + c * phi_nodes + d
    linear_field2 = 2.0 * linear_field + 1.0
    linear_const = np.full_like(linear_field, 5.0)

    ds = _FakeDataset(
        points=points,
        corners=corners,
        variables={
            Octree.X_VAR: x,
            Octree.Y_VAR: y,
            Octree.Z_VAR: z,
            "LinField": linear_field,
            "LinField2": linear_field2,
            "LinFieldConst": linear_const,
        },
    )
    return ds, linear_field, (a, b, c, d)


@pytest.fixture(scope="module")
def synthetic_context() -> tuple[_FakeDataset, Octree, np.ndarray, tuple[float, float, float, float]]:
    """Return synthetic dataset, built tree, linear nodal field and coefficients."""
    ds, linear_field, coeffs = _build_uniform_spherical_hex_dataset()
    tree = Octree.from_dataset(ds, tree_coord="rpa")
    return ds, tree, linear_field, coeffs


def _sample_inside_cells(tree: Octree, cids: np.ndarray, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    """Private test helper: sample one interior xyz/rpa point per selected cell."""
    xyz_list: list[np.ndarray] = []
    rpa_list: list[np.ndarray] = []
    for cid in cids.tolist():
        lo, hi = tree.cell_bounds(int(cid), coord="rpa")
        r0 = float(lo[0])
        r1 = float(hi[0])
        t0 = float(lo[1])
        t1 = float(hi[1])
        p0 = float(lo[2])
        pw = float((hi[2] - lo[2]) % (2.0 * math.pi))
        if np.isclose(pw, 0.0, atol=1e-12):
            pw = 2.0 * math.pi

        u = float(rng.uniform(0.15, 0.85))
        v = float(rng.uniform(0.15, 0.85))
        w = float(rng.uniform(0.15, 0.85))
        r = r0 + u * (r1 - r0)
        theta = t0 + v * (t1 - t0)
        phi = (p0 + w * pw) % (2.0 * math.pi)

        st = math.sin(theta)
        xyz = np.array([r * st * math.cos(phi), r * st * math.sin(phi), r * math.cos(theta)])
        xyz_list.append(xyz)
        rpa_list.append(np.array([r, theta, phi]))
    return np.array(xyz_list), np.array(rpa_list)


def _interpolation_valid_cells(
    tree: Octree,
    *,
    interp: OctreeInterpolator | None = None,
) -> np.ndarray:
    """Private test helper: return cells suitable for stable interpolation checks."""
    n_cells = int(tree.cell_count)
    lo = np.empty((n_cells, 3), dtype=float)
    hi = np.empty((n_cells, 3), dtype=float)
    for cid in range(n_cells):
        lo[cid], hi[cid] = tree.cell_bounds(cid, coord="rpa")
    phi_end = hi[:, 2]
    ids = np.flatnonzero(
        (lo[:, 1] > 1e-6)
        & (hi[:, 1] < (math.pi - 1e-6))
        & (phi_end < (2.0 * math.pi - 1e-8))
    )
    if interp is None:
        return ids
    good = [int(cid) for cid in ids.tolist() if interp.cell_has_full_trilinear_corner_map(int(cid))]
    return np.array(good, dtype=np.int64)


def test_lookup_hits_cell_centers(synthetic_context) -> None:
    """Lookup of each synthetic cell center should return the corresponding cell id."""
    _ds, tree, _field, _coeffs = synthetic_context
    centers = np.array(tree.cell_centers, dtype=float)
    for cid in range(centers.shape[0]):
        q = centers[cid]
        hit = tree.lookup_point(q, coord="xyz")
        assert hit is not None
        assert int(hit.cell_id) == int(cid)


def test_lookup_xyz_rpa_match_random_points(synthetic_context) -> None:
    """xyz and rpa lookups should agree on synthetic interior random points."""
    _ds, tree, _field, _coeffs = synthetic_context
    rng = np.random.default_rng(11)
    valid = _interpolation_valid_cells(tree)
    choose = rng.choice(valid, size=min(120, valid.size), replace=False)
    xyz, rpa = _sample_inside_cells(tree, choose, rng)

    for i in range(xyz.shape[0]):
        hit_xyz = tree.lookup_point(xyz[i], coord="xyz")
        hit_rpa = tree.lookup_point(rpa[i], coord="rpa")
        assert hit_xyz is not None
        assert hit_rpa is not None
        assert int(hit_xyz.cell_id) == int(hit_rpa.cell_id)


def test_interp_matches_linear_field_xyz(synthetic_context) -> None:
    """xyz interpolation should reconstruct an exactly linear spherical field."""
    ds, tree, _field, coeffs = synthetic_context
    a, b, c, d = coeffs
    interp = OctreeInterpolator(ds, ["LinField"], tree=tree)
    rng = np.random.default_rng(22)
    valid = _interpolation_valid_cells(tree, interp=interp)
    assert valid.size > 0
    choose = rng.choice(valid, size=min(200, valid.size), replace=False)
    xyz, rpa = _sample_inside_cells(tree, choose, rng)
    vals, cell_ids = interp(xyz, return_cell_ids=True)
    expected = a * rpa[:, 0] + b * rpa[:, 1] + c * rpa[:, 2] + d

    assert np.array_equal(cell_ids, choose)
    assert np.allclose(vals, expected, atol=1e-9, rtol=0.0)


def test_interp_matches_linear_field_rpa_wrap(synthetic_context) -> None:
    """rpa interpolation should normalize wrapped azimuth and match linear field."""
    ds, tree, _field, coeffs = synthetic_context
    a, b, c, d = coeffs
    interp = OctreeInterpolator(ds, ["LinField"], tree=tree)
    rng = np.random.default_rng(33)
    valid = _interpolation_valid_cells(tree, interp=interp)
    assert valid.size > 0
    choose = rng.choice(valid, size=min(200, valid.size), replace=False)
    _xyz, rpa = _sample_inside_cells(tree, choose, rng)
    wrapped = np.array(rpa, copy=True)
    wrapped[:, 2] += 2.0 * math.pi
    vals, cell_ids = interp(wrapped, query_coord="rpa", return_cell_ids=True)
    expected = a * rpa[:, 0] + b * rpa[:, 1] + c * rpa[:, 2] + d

    assert np.array_equal(cell_ids, choose)
    assert np.allclose(vals, expected, atol=1e-9, rtol=0.0)


def test_vector_interp_shape_and_values(synthetic_context) -> None:
    """Vector-valued interpolation should preserve trailing dims and nodal exactness."""
    ds, tree, _linear_field, coeffs = synthetic_context
    a, b, c, d = coeffs
    interp = OctreeInterpolator(ds, ["LinField", "LinField2", "LinFieldConst"], tree=tree)

    rng = np.random.default_rng(44)
    valid = _interpolation_valid_cells(tree, interp=interp)
    assert valid.size > 0
    choose = rng.choice(valid, size=min(120, valid.size), replace=False)
    xyz, rpa = _sample_inside_cells(tree, choose, rng)
    vals = interp(xyz)

    scalar = a * rpa[:, 0] + b * rpa[:, 1] + c * rpa[:, 2] + d
    expected = np.column_stack((scalar, 2.0 * scalar + 1.0, np.full_like(scalar, 5.0)))

    assert vals.shape == expected.shape
    assert np.allclose(vals, expected, atol=1e-9, rtol=0.0)


def test_outside_points_use_fill_and_negative_cell_id(synthetic_context) -> None:
    """Outside-domain synthetic points should return fill value and cell_id=-1."""
    ds, tree, _field, _coeffs = synthetic_context
    fill = -999.0
    interp = OctreeInterpolator(ds, ["LinField"], tree=tree, fill_value=fill)

    inside = np.array(tree.cell_centers[0]).reshape(1, 3)
    outside = np.array([[100.0, 0.0, 0.0], [-100.0, 0.0, 0.0]])
    q = np.vstack((inside, outside))

    vals, cell_ids = interp(q, return_cell_ids=True)
    assert int(cell_ids[0]) >= 0
    assert int(cell_ids[1]) == -1
    assert int(cell_ids[2]) == -1
    assert np.isclose(float(vals[1]), fill)
    assert np.isclose(float(vals[2]), fill)
