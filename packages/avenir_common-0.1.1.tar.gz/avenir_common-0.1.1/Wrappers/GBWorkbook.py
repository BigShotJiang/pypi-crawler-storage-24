import openpyxl
import pandas as pd
import os

class GBWorkbook:

    def __init__(self, FQName='', dataOnly=False):
        if (FQName == ''):
            self.xlsx = openpyxl.Workbook()
        else:
            extension = os.path.splitext(FQName)[1].lower()
            self.xlsx = openpyxl.load_workbook(FQName, data_only=dataOnly)

        self.sheet = self.xlsx.active
        
    def __call__(self, row=None, col=None, value=None):
        if row is None:
            return self

        #getter
        if value is None:    
            return self.sheet.cell(row = row, column = col).value

        #setter
        self.sheet.cell(row = row, column = col).value = value

    def save_to_xlsx(self, FQName='', sheet_name=''):
        self.sheet.title = sheet_name
        self.xlsx.save(FQName)
        return None

    def save_to_csv(self, FQName=''):
        dataFrame = pandas.DataFrame(self.sheet.values)
        dataFrame.to_csv(FQName, header=False, index=False)

    #careful, loading a new sheet will delete current data in sheet
    def load_from_xlsx(self, FQName, sheet_name=0):
        return None

    def load_from_csv(self, FQName, sheet_name=0):
        return None

    def clear_sheet(self, row_count, col_count, init=''):
        return None

    def isEmpty(self):
        return None
    
    def getRowCount(self):
        return self.sheet.max_row

    def getColCount(self):
        return None
    
    def getRows(self):
        #return self.sheet.rows
        all_rows = []

        for row in self.sheet:
            current_row = []
            for cell in row:
                current_row.append(cell.value)
            all_rows.append(current_row)
        

    def insterRow(self, row):
        self.sheet.insert_rows(row)

    def deleteRows(self, row, numRows):
        self.sheet.delete_rows(row, numRows)

    def getStyle(self, row, col):
        return self.sheet.cell(row = row, column = col)._style

    def setStyle(self, row, col, style):
        self.sheet.cell(row = row, column = col)._style = style
