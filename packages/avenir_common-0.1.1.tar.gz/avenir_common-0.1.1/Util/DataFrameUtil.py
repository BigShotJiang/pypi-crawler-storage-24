
def findTagRow(sheet, tag : str="", column : int= 0):
    if type(sheet)==list:
        for row in range(len(sheet)):
            if len(sheet[row]) <= column:
                continue
            if sheet[row][column] == tag:
                return row
        return None
    else:
        import numpy as np
        whereArr = np.where(sheet.values[:, column] == tag)
        row = int(whereArr[0][0]) if (len(whereArr[0]) > 0) else -1
        # if row < 0:
        #     raise Exception('Tag ' + tag + ' not found')
        return row

def findTagCol(sheet, tag = str, row = 0):
    import numpy as np
    whereArr = np.where(sheet.values[row, :] == tag)
    row = int(whereArr[0][0]) if (len(whereArr[0]) > 0) else -1
    if row < 0:
        raise Exception('Tag ' + tag + ' not found')
    return row