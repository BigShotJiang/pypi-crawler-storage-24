"""CLI integration tests for the version detection logic.

Verifies that malac-hd correctly detects the FHIR version from file content
when a generic file extension (.json, .xml, .map) is used, by invoking the
tool via the command line (python -m malac.hd).

Uses the existing AT preNUDGE R4 StructureMap and practitioner_patient FML
test data.
"""

import json
import os
import subprocess
import sys
import tempfile
import pytest

_TESTS_DIR = os.path.dirname(__file__)

PRENUDGE_DIR = os.path.join(_TESTS_DIR, "structuremap", "r4", "aut_prenudge")
INPUT_FILE = os.path.join(PRENUDGE_DIR, "QuestionnaireResponse-AlcoholResponseNever.json")
MAP_JSON = os.path.join(PRENUDGE_DIR, "StructureMap-AlcoholQuestionnaireResponseToObservation.json")
MAP_XML = os.path.join(PRENUDGE_DIR, "StructureMap-AlcoholQuestionnaireResponseToObservation.xml")
EXPECTED_OUTPUT = os.path.join(PRENUDGE_DIR, "out", "observation-json.json")

FML_MAP = os.path.join(_TESTS_DIR, "fml", "r4", "aut_prenudge", "AlcoholQuestionnaireResponseToObservation.map")


def _run_malac_hd(map_file, output_file, input_file=None):
    """Invoke malac-hd via the command line and return the CompletedProcess."""
    cmd = [
        sys.executable, "-m", "malac.hd",
        "-m", map_file,
        "-co", output_file,
        "-s",
    ]
    if input_file is not None:
        cmd += ["-ti", input_file, "-to", output_file]
    return subprocess.run(cmd, capture_output=True, text=True)


def _load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


class TestVersionDetectionCLI:
    """End-to-end CLI tests for generic-extension version detection."""

    def test_json_map_detected_as_r4_via_cli(self):
        """A .json StructureMap with an R4 URL must be detected as R4 and
        produce the expected Observation output when invoked via CLI."""
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
            tmp_output = tmp.name
        try:
            result = _run_malac_hd(MAP_JSON, tmp_output, input_file=INPUT_FILE)
            assert result.returncode == 0, (
                f"malac-hd exited with code {result.returncode}.\n"
                f"stderr: {result.stderr}"
            )
            assert os.path.isfile(tmp_output), "No output file was created."
            assert _load_json(tmp_output) == _load_json(EXPECTED_OUTPUT)
        finally:
            if os.path.isfile(tmp_output):
                os.remove(tmp_output)

    def test_xml_map_detected_as_r4_via_cli(self):
        """A .xml StructureMap with an R4 URL must be detected as R4 and
        produce the expected Observation output when invoked via CLI."""
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
            tmp_output = tmp.name
        try:
            result = _run_malac_hd(MAP_XML, tmp_output, input_file=INPUT_FILE)
            assert result.returncode == 0, (
                f"malac-hd exited with code {result.returncode}.\n"
                f"stderr: {result.stderr}"
            )
            assert os.path.isfile(tmp_output), "No output file was created."
            assert _load_json(tmp_output) == _load_json(EXPECTED_OUTPUT)
        finally:
            if os.path.isfile(tmp_output):
                os.remove(tmp_output)

    def test_fml_map_detected_as_r4_via_cli(self):
        """A .map FML file with an R4 URL must be detected as R4 and
        successfully converted to Python code when invoked via CLI."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            convert_output = os.path.join(tmp_dir, "AlcoholQuestionnaireResponseToObservation.py")

            result = _run_malac_hd(FML_MAP, convert_output)
            assert result.returncode == 0, (
                f"malac-hd exited with code {result.returncode}.\n"
                f"stderr: {result.stderr}"
            )
            assert os.path.isfile(convert_output), "No converted Python file was created."
            with open(convert_output, "r", encoding="utf-8") as f:
                content = f.read()
            assert "def AlcoholQuestionnaireResponseToObservation(" in content
