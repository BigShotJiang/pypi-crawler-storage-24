
import json
from functools import partial

from malac.hd import ConvertMaster, list_i_o_modules
from malac.models.fhir import utils as utils, r4 as supermod
from malac.transformer.fhir.r4 import structuremap as transformer
from malac.hd.core.fhir.base.generator.resource import parse_factory

from ...r5.generator.structuremap import PythonGenerator as PythonGeneratorR5

# Build an R4 version of list_i_o_modules where the versionless base URL
# points to the R4 module instead of the default (R5).
_BASE_URL = 'http://hl7.org/fhir/StructureDefinition'
_r4_list_i_o_modules = dict(list_i_o_modules)
if _BASE_URL in _r4_list_i_o_modules:
    _r4_list_i_o_modules[_BASE_URL] = supermod


class PythonGenerator(supermod.StructureMap, ConvertMaster):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.skipped_groups = None
        self.transform_default_needed = None
        self.translate_dict_py_code = None
        self.get_group = None
        self.default_types_maps = None
        self.default_types_maps_plus = None
        self.default_types_maps_subtypes = None

    def version_match(self):
        if self.url is None or self.url.value is None:
            return 101
        for part in ["r4", "r4b", "4", "4.0", "4.3"]:
            if "/%s/" % part in self.url.value.lower():
                return 1001
        return 1

    def convert(self, *args, **kwargs):
        tgt = PythonGeneratorR5()
        transformer.StructureMap(self, tgt)
        kwargs["parse_wrapper"] = parse
        kwargs["parse_wrapper_json"] = partial(utils.parse_json, supermod)
        tgt.i_module = getattr(self, "i_module", None)
        tgt.o_module = getattr(self, "o_module", None)
        tgt.default_types_maps = self.default_types_maps or tgt.default_types_maps
        tgt.default_types_maps_plus = self.default_types_maps_plus or tgt.default_types_maps_plus
        tgt.default_types_maps_subtypes = self.default_types_maps_subtypes or tgt.default_types_maps_subtypes
        # Override module lookup so versionless URLs resolve to R4
        tgt.list_i_o_modules_override = _r4_list_i_o_modules
        result = tgt.convert(*args, **kwargs)
        self.skipped_groups = tgt.skipped_groups
        self.transform_default_needed = tgt.transform_default_needed
        self.translate_dict_py_code = tgt.translate_dict_py_code
        self.get_group = tgt.get_group
        self.default_types_maps = tgt.default_types_maps
        self.default_types_maps_plus = tgt.default_types_maps_plus
        self.default_types_maps_subtypes = tgt.default_types_maps_subtypes
        return result


parse, parseEtree, parseString, parseLiteral = parse_factory(supermod)
