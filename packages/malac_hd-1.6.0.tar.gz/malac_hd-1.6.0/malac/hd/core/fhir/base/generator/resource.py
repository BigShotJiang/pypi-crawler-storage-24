import os
import sys
from lxml import etree as etree_

# generateDS globals
ExternalEncoding = ''
SaveElementTreeNode = True

def parse_factory(supermod):

    def parsexml_(infile, parser=None, **kwargs):
        if parser is None:
            # Use the lxml ElementTree compatible parser so that, e.g.,
            #   we ignore comments.
            parser = etree_.ETCompatXMLParser()
        try:
            if isinstance(infile, os.PathLike):
                infile = os.path.join(infile)
        except AttributeError:
            pass
        doc = etree_.parse(infile, parser=parser, **kwargs)
        return doc

    def parsexmlstring_(instring, parser=None, **kwargs):
        if parser is None:
            # Use the lxml ElementTree compatible parser so that, e.g.,
            #   we ignore comments.
            try:
                parser = etree_.ETCompatXMLParser()
            except AttributeError:
                # fallback to xml.etree
                parser = etree_.XMLParser()
        element = etree_.fromstring(instring, parser=parser, **kwargs)
        return element

    def get_root_tag(node):
        tag = supermod.Tag_pattern_.match(node.tag).groups()[-1]
        rootClass = None
        rootClass = supermod.GDSClassesMapping.get(tag)
        if rootClass is None and hasattr(supermod, tag):
            rootClass = getattr(supermod, tag)
        return tag, rootClass

    def parse(inFilename, silence=False):
        parser = None
        doc = parsexml_(inFilename, parser)
        rootNode = doc.getroot()
        rootTag, rootClass = get_root_tag(rootNode)
        if rootClass is None:
            rootTag = 'AdministrativeGender'
            rootClass = supermod.AdministrativeGender
        rootObj = rootClass.factory()
        rootObj.build(rootNode)
        # Enable Python to collect the space used by the DOM.
        if not SaveElementTreeNode:
            doc = None
            rootNode = None
        if not silence:
            sys.stdout.write('<?xml version="1.0" ?>\n')
            rootObj.export(
                sys.stdout, 0, name_=rootTag,
                namespacedef_='',
                pretty_print=True)
        return rootObj

    def parseEtree(inFilename, silence=False):
        parser = None
        doc = parsexml_(inFilename, parser)
        rootNode = doc.getroot()
        rootTag, rootClass = get_root_tag(rootNode)
        if rootClass is None:
            rootTag = 'AdministrativeGender'
            rootClass = supermod.AdministrativeGender
        rootObj = rootClass.factory()
        rootObj.build(rootNode)
        mapping = {}
        rootElement = rootObj.to_etree(None, name_=rootTag, mapping_=mapping)
        reverse_mapping = rootObj.gds_reverse_node_mapping(mapping)
        # Enable Python to collect the space used by the DOM.
        if not SaveElementTreeNode:
            doc = None
            rootNode = None
        if not silence:
            content = etree_.tostring(
                rootElement, pretty_print=True,
                xml_declaration=True, encoding="utf-8")
            sys.stdout.write(content)
            sys.stdout.write('\n')
        return rootObj, rootElement, mapping, reverse_mapping


    def parseString(inString, silence=False, source_path=None):
        if sys.version_info.major == 2:
            from StringIO import StringIO
        else:
            from io import BytesIO as StringIO
        parser = None
        rootNode= parsexmlstring_(inString, parser)
        rootTag, rootClass = get_root_tag(rootNode)
        if rootClass is None:
            rootTag = 'AdministrativeGender'
            rootClass = supermod.AdministrativeGender
        rootObj = rootClass.factory()
        rootObj.build(rootNode)
        # Enable Python to collect the space used by the DOM.
        if not SaveElementTreeNode:
            rootNode = None
        if not silence:
            sys.stdout.write('<?xml version="1.0" ?>\n')
            rootObj.export(
                sys.stdout, 0, name_=rootTag,
                namespacedef_='')
        return rootObj

    def parseLiteral(inFilename, silence=False):
        parser = None
        doc = parsexml_(inFilename, parser)
        rootNode = doc.getroot()
        rootTag, rootClass = get_root_tag(rootNode)
        if rootClass is None:
            rootTag = 'AdministrativeGender'
            rootClass = supermod.AdministrativeGender
        rootObj = rootClass.factory()
        rootObj.build(rootNode)
        # Enable Python to collect the space used by the DOM.
        if not SaveElementTreeNode:
            doc = None
            rootNode = None
        if not silence:
            sys.stdout.write('#from ??? import *\n\n')
            sys.stdout.write('import ??? as model_\n\n')
            sys.stdout.write('rootObj = model_.rootClass(\n')
            rootObj.exportLiteral(sys.stdout, 0, name_=rootTag)
            sys.stdout.write(')\n')
        return rootObj

    return parse, parseEtree, parseString, parseLiteral
