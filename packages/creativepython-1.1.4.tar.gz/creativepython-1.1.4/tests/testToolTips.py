from gui import *

d = Display()
d.setToolTipText("display")

r = Rectangle(25, 25, 125, 125)
r.setToolTipText("rectangle")
d.add(r)

def toggleCoordinateTooltip(*args):
   if d._showCoordinates:
      d.hideMouseCoordinates()
   else:
      d.showMouseCoordinates()

d.onMouseClick(toggleCoordinateTooltip)