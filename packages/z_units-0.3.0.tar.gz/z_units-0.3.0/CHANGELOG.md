## Release v0.3.0 (2026.0311)

### Features & Improvements

- `atm_pressure` parameter in `Quantity` initialization (source environment) and `.to()` method (target environment).

### Breaking Changes

- **Drop support for Python 3.7 and 3.8.**

## Release v0.2.1 (2026.0310)

- update CI workflow

## Release v0.2.0 (2026.0309)

### Features & Improvements

- Support `atm_pressure` parameter in `Quantity` initialization and `.to()` method for flexible gauge pressure calculation without changing global configuration.

## Release v0.1.9 (2025.0320)

- Fix package name bug (z_unit -> z_units)

## Release v0.1.8 (2025.0312)

### Features & Improvements

- `environment` module for global configuration management

### Breaking Changes

- Removed `config` module in favor of new `environment` module
- Changed configuration interface: use `get_env()` instead of direct config functions

### Migration Guide

Old configuration:

```python
from z_units import config

config.set_local_atmospheric_pressure(100e3)
config.set_standard_temperature(15)
```

New configuration:

```python
from z_units.environment import get_env

env = get_env()
env.atmospheric_pressure = 100e3  # in Pa
env.standard_temperature = 273.15 + 15  # in K
```

## Release v0.1.7 (2024.0616)

### Features & Improvements

- `convert()` method for shortcut.
- `Quantity` can parse str value with unit, ie: `Length("1m")`.
