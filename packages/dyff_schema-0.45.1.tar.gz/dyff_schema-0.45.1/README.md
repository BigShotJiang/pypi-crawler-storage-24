# dyff-schema

<!-- BADGIE TIME -->

[![pipeline status](https://gitlab.com/dyff/packages/dyff-schema/badges/main/pipeline.svg)](https://gitlab.com/dyff/packages/dyff-schema/-/commits/main)
[![coverage report](https://gitlab.com/dyff/packages/dyff-schema/badges/main/coverage.svg)](https://gitlab.com/dyff/packages/dyff-schema/-/commits/main)
[![latest release](https://gitlab.com/dyff/packages/dyff-schema/-/badges/release.svg)](https://gitlab.com/dyff/packages/dyff-schema/-/releases)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](https://github.com/pre-commit/pre-commit)
[![code style: prettier](https://img.shields.io/badge/code_style-prettier-ff69b4.svg)](https://github.com/prettier/prettier)
[![cici enabled](https://img.shields.io/badge/%E2%9A%A1_cici-enabled-c0ff33)](https://gitlab.com/saferatday0/cici)

<!-- END BADGIE TIME -->

Data models for the Dyff AI auditing platform.

> Do not use this software unless you are an active collaborator on the
> associated research project.
>
> This project is an output of an ongoing, active research project. It is
> published without warranty, is subject to change at any time, and has not been
> certified, tested, assessed, or otherwise assured of safety by any person or
> organization. Use at your own risk.

## Installation

Python 3.9+ is required. Install `dyff-schema` via `pip`:

```bash
python3 -m pip install dyff-schema
```

## License

Copyright 2024 UL Research Institutes.

Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at

<http://www.apache.org/licenses/LICENSE-2.0>

Unless required by applicable law or agreed to in writing, software distributed
under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
