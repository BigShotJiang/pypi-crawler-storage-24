# Urdu Learning Aid

> A personal quiz app for practising Urdu, built around lessons with my Preply tutor Nashmia.

---

## About

Every sentence, vocabulary item, and grammar pattern in this app comes directly from lessons.
The quiz is organised by the same categories Nashmia teaches — tenses, postpositions, and vocabulary —
so practice stays aligned with what is actually being learned.

Built with Flask and SQLAlchemy as a learning project in both Urdu and Python web development.

---

## How it works

1. **Pick categories** — select one or more tense groups, postpositions, or vocabulary sets
2. **Choose a direction** — English to Urdu, or Urdu to English
3. **Answer 10 questions** — type and press Enter to submit, Enter again to advance
4. **Review** — an end-of-session table shows every question alongside your answer and the correct answer

---

## Quiz content

| Type | Categories |
|---|---|
| Past tense | Simple, continuous, ko constructions, possessive |
| Present tense | Simple, continuous, ko constructions, possessive |
| Future tense | Simple, continuous |
| Postpositions | se &bull; ke pas &bull; ke baray may &bull; se door / ke qareeb |
| Vocabulary | Imperatives and common words |
| Mixed | Sentences that combine multiple tenses in one |

---

## Stack

| | |
|---|---|
| Language | Python 3.12+ |
| Web framework | Flask |
| Database | SQLite via SQLAlchemy |
| Auth | Flask-Login + Flask-Bcrypt |
| Forms | Flask-WTF |
| Package manager | uv |

---

## Running locally

```bash
# Install dependencies
uv sync

# Seed the database (first run only)
uv run python -m quiz_genie.seed

# Start the app
uv run quiz-gui
```

Open **http://127.0.0.1:5010**, register an account, and start a quiz.

---

## Data

Quiz content lives in `data/` as CSV files organised by category.

```
data/
  past/
  present/
  future/
  postposition_*.csv
  vocab/
  mixed_tense.csv
```

All files use a standard format after normalisation:

```
"english","urdu","notes","predicted_error"
```

To re-normalise after editing the CSVs and reload the database:

```bash
uv run python tools/normalize_csvs.py
uv run python -m quiz_genie.seed --force
```

---

## Development

```bash
uv sync --extra dev
pre-commit install
```

Commits follow [Conventional Commits](https://www.conventionalcommits.org/).
The pre-commit hook updates `CHANGELOG.md` automatically.

Releases are handled automatically by GitHub Actions on every push to `master`:
- `feat:` commits trigger a minor version bump
- `fix:` commits trigger a patch version bump
- The new version is published to PyPI automatically

Requires two repository secrets set in GitHub → Settings → Secrets → Actions:
- `GH_TOKEN` — classic PAT with `repo` + `workflow` scopes
- `PYPI_TOKEN` — PyPI API token
