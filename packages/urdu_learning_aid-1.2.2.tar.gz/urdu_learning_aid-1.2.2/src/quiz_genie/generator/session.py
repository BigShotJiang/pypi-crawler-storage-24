"""
Quiz session logic.

These functions handle everything that happens during a quiz run:
  - start_session()   — pick questions, create a session and its attempts
  - next_attempt()    — return the next unanswered question
  - submit_answer()   — record the user's answer and mark correct/incorrect
  - finish_session()  — close the session and return a summary dict
"""

import random
from datetime import datetime
from quiz_genie.models import db, QuizItem, QuizSession, QuizAttempt

# How many questions per session
SESSION_SIZE = 10


def start_session(user_id: int, categories: list[str], mode: str) -> QuizSession:
    """
    Create a QuizSession and pre-populate it with QuizAttempts.

    Parameters
    ----------
    user_id    : the logged-in user's id
    categories : list of category names the user selected, e.g. ["past_simple"]
    mode       : "en_to_ur" (shown English, type Urdu)
                 "ur_to_en" (shown Urdu, type English)
    """
    # Pull all matching items and sample up to SESSION_SIZE
    items = QuizItem.query.filter(QuizItem.category.in_(categories)).all()
    sample = random.sample(items, min(SESSION_SIZE, len(items)))

    session = QuizSession(
        user_id=user_id,
        categories=",".join(categories),
        mode=mode,
    )
    db.session.add(session)
    db.session.flush()  # gives us session.id before committing

    for item in sample:
        if mode == "en_to_ur":
            question = item.english
            correct_answer = item.urdu
        else:
            question = item.urdu
            correct_answer = item.english

        attempt = QuizAttempt(
            session_id=session.id,
            quiz_item_id=item.id,
            question=question,
            correct_answer=correct_answer,
        )
        db.session.add(attempt)

    db.session.commit()
    return session


def next_attempt(session_id: int) -> QuizAttempt | None:
    """
    Return the next unanswered attempt for this session, or None if all are done.
    Attempts are served in the order they were created (by id).
    """
    return (
        QuizAttempt.query
        .filter_by(session_id=session_id, user_answer=None)
        .order_by(QuizAttempt.id)
        .first()
    )


def submit_answer(attempt_id: int, user_answer: str) -> dict:
    """
    Record the user's answer and return the result.

    Answer matching: case-insensitive, leading/trailing whitespace stripped.
    The correct answer is always returned so the user can self-assess.

    Returns
    -------
    {
        "is_correct": bool,
        "correct_answer": str,
        "user_answer": str,
        "notes": str | None,
    }
    """
    attempt = QuizAttempt.query.get(attempt_id)
    if not attempt:
        raise ValueError(f"Attempt {attempt_id} not found")

    attempt.user_answer = user_answer.strip()
    attempt.is_correct = attempt.user_answer.lower() == attempt.correct_answer.lower()
    attempt.attempted_at = datetime.utcnow()
    db.session.commit()

    return {
        "is_correct": attempt.is_correct,
        "correct_answer": attempt.correct_answer,
        "user_answer": attempt.user_answer,
        "notes": attempt.item.notes,
    }


def finish_session(session_id: int) -> dict:
    """
    Mark the session as finished and return a summary.

    Returns
    -------
    {
        "session_id": int,
        "correct": int,
        "total": int,
        "score_pct": int,
        "attempts": list[QuizAttempt],
    }
    """
    session = QuizSession.query.get(session_id)
    session.finished_at = datetime.utcnow()
    db.session.commit()

    attempts = QuizAttempt.query.filter_by(session_id=session_id).all()
    correct = sum(1 for a in attempts if a.is_correct)
    total = len(attempts)

    return {
        "session_id": session_id,
        "correct": correct,
        "total": total,
        "score_pct": round(100 * correct / total) if total else 0,
        "attempts": attempts,
    }
