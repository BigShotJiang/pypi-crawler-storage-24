import pandas as pd
import random
from dataclasses import dataclass


@dataclass
class Urdu_dc:
    df: pd.DataFrame

    def __post_init__(self):
        # Validate input DataFrame
        required_cols = {"A", "B"}
        if not required_cols.issubset(self.df.columns):
            missing = required_cols - set(self.df.columns)
            raise ValueError(f"Missing required columns: {missing}")
        if self.df.empty:
            raise ValueError("DataFrame is empty.")

    def get_random_row(self) -> dict:
        """Return a random row as a dict with keys 'A' and 'B'."""
        idx = random.choice(self.df.index.tolist())
        row = self.df.loc[idx, ["A", "B"]]
        return {"A": row["A"], "B": row["B"]}
