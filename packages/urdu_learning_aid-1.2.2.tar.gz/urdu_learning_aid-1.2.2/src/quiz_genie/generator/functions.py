import os
import sys
import pandas as pd

### _____________________________________________________________TEST


def say_hello(name):
    return f"Hello, {name}!"


### _____________________________________________________________ARGS


def parse_args():
    pass


### ________________________________________________________FUNCTIONS


# Flask entrypoint
def test_quiz_question():
    import random
    qa_pairs = [
        ("Kitaab", "Book"),
        ("Dog", "Kutta"),
        ("Goat", "Bakri"),
        ("to go", "jana"),
        ("to wash", "dhona"),
        ("to study", "parhna"),
        ("to wear", "pehenna"),
        ("to write", "likhna"),
        ("to drink", "peena"),
        ("to jump", "ochalna"),
        ("to pray", "ibaadat karna"),
        ("to cook", "pakana"),
        ("to eat", "khana"),
        ("to dance", "nachna"),
        ("to walk", "chalna"),
        ("to sleep", "sona"),
        ("to talk", "baat karna"),
        ("to argue", "behas karna"),
        ("to watch", "dekhna"),
        ("to swim", "tairna"),
        ("to give", "dena"),
        ("to take", "lona"),
        ("to travel", "ghoomnay"),
        ("to say", "kehna"),
        ("to ask", "poochna"),
        ("to do", "karna"),
        ("to keep", "rakhna"),
        ("to clean", "saaf karna"),
        ("to work", "kaam karna"),
        ("to open", "kholna"),
        ("to buy", "khareedna"),
        ("to sell", "bechna"),
        ("to sing", "gana"),
        ("to repair", "theek karna"),
        ("to dry", "sokhana"),
        ("to help", "madad karna"),
        ("to feel", "mehsos karna"),
        ("to want", "chahna"),
        ("to think", "sochna"),
        ("to analyse", "analyse karna"),
        ("to inspect", "inspect karna"),
        ("to hold", "pakarna"),
    ]
    english, urdu = random.choice(qa_pairs)
    question = f"What is {english}?"
    answer = urdu
    return question, answer


def get_sentence_qa(
    tense,
    post_positions,
    difficulty,
):
    pass


def get_vocab_qa(set: int = 1):
    pass



def check_data_frame(df: pd.DataFrame):
    pass


def merge_data_frames(df: pd.DataFrame):
    pass


def instantiate_data_class(df: pd.DataFrame):
    pass


def finish():
    """
    Generate a random fact about Urdu before saying goodbye
    """
    pass
