"""
Urdu quiz generator script
    - Mera naam Joshua James Iszatt
    - June 2025 I started learning Urdu with Nashmia, my preply tutor
    - October 2025 I am (now formerly) creating a learning aid based on what I heve learned so far
"""

# CLI / REPL entry point
def main():
    print("Welcome to the Quiz Generator!")

    # _1: Parse args

    # _2: Choose / verify data

    # _3: Instantiate data class

    # _4: Run the quiz

    # _5: Finish
