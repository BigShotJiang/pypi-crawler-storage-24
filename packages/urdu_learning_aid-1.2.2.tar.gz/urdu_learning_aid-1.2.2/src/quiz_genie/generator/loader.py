"""
CSV loader — reads quiz content from data/ and returns normalised dicts.

Each entry in CSV_SOURCES describes one CSV file:
    (path relative to data/, category name, item_type, display label)

load_all() is called by seed.py to populate the database.
CATEGORIES is imported by app.py to build the dashboard category picker.
"""

import pandas as pd
from pathlib import Path

# data/ sits at the repo root, four levels up from this file
# src/quiz_genie/generator/loader.py  →  parents[3] = repo root
DATA_DIR = Path(__file__).resolve().parents[3] / "data"

# (csv_path, category_name, item_type, display_label)
CSV_SOURCES = [
    # ── Tenses ────────────────────────────────────────────────────────────
    ("past/past_simple.csv",                    "past_simple",                "tense",       "Past Simple"),
    ("past/past_simple_KO.csv",                 "past_simple_ko",             "tense",       "Past Simple — ko"),
    ("past/past_simple_POSSESSIVE.csv",         "past_simple_possessive",     "tense",       "Past Simple — Possessive"),
    ("past/past_continuous.csv",                "past_continuous",            "tense",       "Past Continuous"),
    ("present/present_simple.csv",              "present_simple",             "tense",       "Present Simple"),
    ("present/present_simple_KO.csv",           "present_simple_ko",          "tense",       "Present Simple — ko"),
    ("present/present_simple_POSSESSIVE.csv",   "present_simple_possessive",  "tense",       "Present Simple — Possessive"),
    ("present/present_continuous.csv",          "present_continuous",         "tense",       "Present Continuous"),
    ("future/future_simple.csv",                "future_simple",              "tense",       "Future Simple"),
    ("future/future_continuous.csv",            "future_continuous",          "tense",       "Future Continuous"),
    # ── Postpositions ─────────────────────────────────────────────────────
    ("postposition_se.csv",                     "postposition_se",            "postposition","Postposition — se"),
    ("postposition_kepas.csv",                  "postposition_kepas",         "postposition","Postposition — ke pas"),
    ("postposition_kebaraymay.csv",             "postposition_kebaraymay",    "postposition","Postposition — ke baray may"),
    ("postposition_sedoor_keqareeb.csv",        "postposition_sedoor",        "postposition","Postposition — se door / ke qareeb"),
    # ── Vocabulary ────────────────────────────────────────────────────────
    ("vocab/vocab.csv",                         "vocab",                      "vocab",       "Vocabulary"),
    # ── Mixed ─────────────────────────────────────────────────────────────
    ("mixed_tense.csv",                         "mixed_tense",                "mixed",       "Mixed Tense"),
]

# Flat list of (category_name, item_type, display_label) — used by the dashboard
CATEGORIES = [(cat, itype, label) for _, cat, itype, label in CSV_SOURCES]


def load_csv(path: Path, category: str, item_type: str) -> list[dict]:
    """
    Read one CSV file and return a list of normalised row dicts.
    All CSV files are expected to be in the standard format:
        "english","urdu","notes","predicted_error"
    (produced by tools/normalize_csvs.py)
    """
    df = pd.read_csv(path)

    rows = []
    for _, row in df.iterrows():
        english = str(row.get("english", "")).strip()
        urdu = str(row.get("urdu", "")).strip()

        # skip blank or NaN rows
        if not english or not urdu or english == "nan" or urdu == "nan":
            continue

        notes = str(row.get("notes", "")).strip() or None
        if notes == "nan":
            notes = None

        predicted_error = str(row.get("predicted_error", "")).strip() or None
        if predicted_error == "nan":
            predicted_error = None

        rows.append({
            "english": english,
            "urdu": urdu,
            "notes": notes,
            "predicted_error": predicted_error,
            "category": category,
            "item_type": item_type,
        })
    return rows


def load_all() -> list[dict]:
    """Return all quiz items from every CSV source."""
    all_items = []
    for relative_path, category, item_type, label in CSV_SOURCES:
        path = DATA_DIR / relative_path
        if not path.exists():
            print(f"  [skip] {relative_path} — file not found")
            continue
        items = load_csv(path, category, item_type)
        print(f"  [ok]   {relative_path} → {len(items)} items")
        all_items.extend(items)
    return all_items
