import os
from pathlib import Path
from flask import Flask, render_template, jsonify, url_for, redirect, flash, request
from flask_login import (
    login_user,
    LoginManager,
    login_required,
    logout_user,
    current_user,
)
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Length, ValidationError
from flask_bcrypt import Bcrypt
from flask_wtf.csrf import CSRFProtect

# Package imports
from quiz_genie.models import db, User
from quiz_genie.generator import (
    CATEGORIES,
    start_session,
    next_attempt,
    submit_answer,
    finish_session,
)

# Set database location within application space
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "database.db"

# Initialise application
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DB_PATH}"
app.config["SECRET_KEY"] = "ABC123"

# Initialise database, bcrypt, and CSRF protection
db.init_app(app)
bcrypt = Bcrypt(app)
csrf = CSRFProtect(app)  # makes csrf_token() available in all templates

# Flask login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"  # type: ignore


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


### AUTH FORMS ###


class RegisterForm(FlaskForm):
    username = StringField(
        "Username",
        validators=[DataRequired(), Length(min=3, max=100)],
        render_kw={"placeholder": "Username"},
    )
    email = StringField(
        "Email",
        validators=[DataRequired(), Length(min=5, max=100)],
        render_kw={"placeholder": "Email"},
    )
    password = PasswordField(
        "Password",
        validators=[DataRequired(), Length(min=6, max=128)],
        render_kw={"placeholder": "Password"},
    )
    submit = SubmitField("Register")

    def validate_username(self, username):
        existing_username = User.query.filter_by(username=username.data).first()
        if existing_username:
            raise ValidationError("This username already exists")


class LoginForm(FlaskForm):
    username = StringField(
        "Username",
        validators=[DataRequired(), Length(min=3, max=100)],
        render_kw={"placeholder": "Username"},
    )
    password = PasswordField(
        "Password",
        validators=[DataRequired(), Length(min=6, max=100)],
        render_kw={"placeholder": "Password"},
    )
    submit = SubmitField("Log In")


### SETUP ###


def initialise_database():
    """Create the database tables if they don't already exist."""
    if not DB_PATH.exists():
        with app.app_context():
            db.create_all()
            print(f"Database created at {DB_PATH}")
    else:
        with app.app_context():
            db.create_all()  # adds any new tables without touching existing ones
        print(f"Database already exists at {DB_PATH}")


### AUTH ROUTES ###


@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode(
            "utf-8"
        )
        new_user: User = User(
            username=form.username.data,
            email=form.email.data,
            password=hashed_password,  # type: ignore
        )
        db.session.add(new_user)
        db.session.commit()
        login_user(new_user)
        flash("Registered successfully!", "success")
        return redirect(url_for("dashboard"))
    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user)
            flash("Logged in successfully!", "success")
            return redirect(url_for("dashboard"))
        return render_template("error.html")
    return render_template("login.html", form=form)


@app.route("/logout", methods=["GET", "POST"])
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))


### AUTHENTICATED ROUTES ###


@app.route("/")
@login_required
def dashboard():
    # Group categories by item_type for display in the template
    grouped = {}
    for cat_name, item_type, label in CATEGORIES:
        grouped.setdefault(item_type, []).append((cat_name, label))
    return render_template("dashboard.html", grouped_categories=grouped)


@app.route("/about")
@login_required
def about():
    return render_template("about.html")


@app.route("/contact")
@login_required
def contact():
    return render_template("contact.html")


### QUIZ ROUTES ###


@app.route("/quiz/start", methods=["POST"])
@login_required
def quiz_start():
    """
    Create a new QuizSession from the dashboard form.
    Expects form fields:
      - categories  (one or more values, e.g. "past_simple")
      - mode        ("en_to_ur" or "ur_to_en")
    """
    categories = request.form.getlist("categories")
    mode = request.form.get("mode", "en_to_ur")

    if not categories:
        flash("Please select at least one category.", "warning")
        return redirect(url_for("dashboard"))

    session = start_session(
        user_id=current_user.id,
        categories=categories,
        mode=mode,
    )
    return redirect(url_for("quiz_page", session_id=session.id))


@app.route("/quiz/<int:session_id>")
@login_required
def quiz_page(session_id):
    """Render the quiz page. The JS on this page drives the question loop."""
    return render_template("quiz.html", session_id=session_id)


@app.route("/quiz/<int:session_id>/question")
@login_required
def quiz_question(session_id):
    """
    JSON endpoint — return the next unanswered attempt.
    Returns 200 with attempt data, or {"done": true} when all questions are answered.
    """
    attempt = next_attempt(session_id)
    if attempt is None:
        return jsonify({"done": True})

    # Count how many attempts this session has total (for "Q n of N" display)
    from quiz_genie.models import QuizAttempt
    total = QuizAttempt.query.filter_by(session_id=session_id).count()
    answered = QuizAttempt.query.filter(
        QuizAttempt.session_id == session_id,
        QuizAttempt.user_answer != None,  # noqa: E711
    ).count()

    return jsonify({
        "done": False,
        "attempt_id": attempt.id,
        "question": attempt.question,
        "question_number": answered + 1,
        "total": total,
    })


@app.route("/quiz/<int:session_id>/answer", methods=["POST"])
@login_required
@csrf.exempt
def quiz_answer(session_id):
    """
    JSON endpoint — record the user's answer.
    Expects JSON body: {"attempt_id": int, "user_answer": str}
    Returns the result and the correct answer.
    """
    data = request.get_json()
    attempt_id = data.get("attempt_id")
    user_answer = data.get("user_answer", "")

    result = submit_answer(attempt_id, user_answer)
    return jsonify(result)


@app.route("/quiz/<int:session_id>/summary")
@login_required
def quiz_summary(session_id):
    """Finish the session and show the results page."""
    summary = finish_session(session_id)
    return render_template("summary.html", summary=summary)


### ENTRY POINT ###


def main():
    initialise_database()
    app.run(port=5010, debug=True)
