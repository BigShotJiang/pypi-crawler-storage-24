from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

# Initialise — this instance is shared across the app
db = SQLAlchemy()


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)

    def __repr__(self):
        return f"<User: {self.email}>"


class QuizItem(db.Model):
    """
    A single sentence pair loaded from a CSV file.
    These rows are the raw quiz content — seeded once from data/*.csv.
    """
    __tablename__ = "quiz_items"

    id = db.Column(db.Integer, primary_key=True)
    english = db.Column(db.Text, nullable=False)
    urdu = db.Column(db.Text, nullable=False)
    notes = db.Column(db.Text, nullable=True)
    predicted_error = db.Column(db.Text, nullable=True)
    # category maps to the CSV source, e.g. "past_simple", "postposition_se"
    category = db.Column(db.String(50), nullable=False)
    # item_type is the broader group: "tense", "postposition", "vocab", "mixed"
    item_type = db.Column(db.String(20), nullable=False)

    def __repr__(self):
        return f"<QuizItem [{self.category}]: {self.english[:40]}>"


class QuizSession(db.Model):
    """
    One quiz run. Created when the user hits Start on the dashboard.
    Holds the selected categories and mode for that run.
    """
    __tablename__ = "quiz_sessions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    started_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    finished_at = db.Column(db.DateTime, nullable=True)
    # comma-separated list of selected category names, e.g. "past_simple,past_continuous"
    categories = db.Column(db.Text, nullable=False)
    # "en_to_ur" = shown English, type Urdu
    # "ur_to_en" = shown Urdu, type English
    mode = db.Column(db.String(10), nullable=False)

    attempts = db.relationship("QuizAttempt", backref="session", lazy=True)

    def __repr__(self):
        return f"<QuizSession {self.id} user={self.user_id}>"


class QuizAttempt(db.Model):
    """
    One question within a session.
    Created upfront when the session starts; user_answer and is_correct
    are filled in as the user works through the quiz.
    """
    __tablename__ = "quiz_attempts"

    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("quiz_sessions.id"), nullable=False)
    quiz_item_id = db.Column(db.Integer, db.ForeignKey("quiz_items.id"), nullable=False)
    question = db.Column(db.Text, nullable=False)       # what was shown to the user
    correct_answer = db.Column(db.Text, nullable=False) # the expected answer
    user_answer = db.Column(db.Text, nullable=True)     # what the user typed
    is_correct = db.Column(db.Boolean, nullable=True)   # None = not yet answered
    attempted_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    item = db.relationship("QuizItem")

    def __repr__(self):
        return f"<QuizAttempt session={self.session_id} correct={self.is_correct}>"
