"""
Seed the database with quiz items from CSV files.

Run with:
    uv run python -m quiz_genie.seed
    uv run python -m quiz_genie.seed --force   # wipe existing items and reload

The script is safe to re-run without --force: it checks for an existing
(english, urdu, category) triple before inserting, so no duplicates are created.
"""

import sys
from quiz_genie.app import app
from quiz_genie.models import db, QuizItem
from quiz_genie.generator.loader import load_all


def seed(force: bool = False) -> None:
    with app.app_context():
        # Ensure tables exist (harmless if they already do)
        db.create_all()

        if force:
            print("--force: deleting all existing quiz items...")
            QuizItem.query.delete()
            db.session.commit()

        print("Loading CSV files...")
        items = load_all()

        inserted = 0
        skipped = 0
        for item in items:
            # Skip if this exact (english, urdu, category) triple already exists
            exists = QuizItem.query.filter_by(
                english=item["english"],
                urdu=item["urdu"],
                category=item["category"],
            ).first()

            if exists:
                skipped += 1
                continue

            db.session.add(QuizItem(**item))
            inserted += 1

        db.session.commit()
        print(f"\nDone. Inserted {inserted} new items, skipped {skipped} duplicates.")


if __name__ == "__main__":
    force = "--force" in sys.argv
    seed(force=force)
