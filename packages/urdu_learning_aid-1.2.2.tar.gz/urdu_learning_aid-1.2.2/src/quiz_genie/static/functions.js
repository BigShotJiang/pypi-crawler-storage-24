// ── Quiz loop ────────────────────────────────────────────────────────────────
//
// The quiz page (quiz.html) renders once. This file drives the loop:
//   1. fetchNextQuestion()  — GET /quiz/<id>/question  → display question
//   2. submitAnswer()       — POST /quiz/<id>/answer   → show result
//   3. fetchNextQuestion()  — repeat until done, then redirect to summary

// Read the session id from the data attribute set by quiz.html
function getSessionId() {
    return document.getElementById("session-data").dataset.sessionId;
}

// Fetch the next unanswered question and update the UI
async function fetchNextQuestion() {
    const sessionId = getSessionId();

    const response = await fetch(`/quiz/${sessionId}/question`);
    const data = await response.json();

    if (data.done) {
        // All questions answered — go to the summary page
        window.location.href = `/quiz/${sessionId}/summary`;
        return;
    }

    // Store the current attempt id on the submit button so submitAnswer() can read it
    document.getElementById("submit-btn").dataset.attemptId = data.attempt_id;

    // Update the UI
    document.getElementById("progress").textContent =
        `Question ${data.question_number} of ${data.total}`;
    document.getElementById("question-text").textContent = data.question;
    const input = document.getElementById("answer-input");
    input.value = "";
    input.focus();

    // Show answer section, hide result section
    document.getElementById("answer-section").style.display = "block";
    document.getElementById("result-section").style.display = "none";
}

// Submit the typed answer and reveal the result
async function submitAnswer() {
    const sessionId = getSessionId();
    const attemptId = parseInt(document.getElementById("submit-btn").dataset.attemptId);
    const userAnswer = document.getElementById("answer-input").value;

    const response = await fetch(`/quiz/${sessionId}/answer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ attempt_id: attemptId, user_answer: userAnswer }),
    });
    const result = await response.json();

    document.getElementById("user-answer").textContent = result.user_answer || "—";
    document.getElementById("correct-answer").textContent = result.correct_answer;

    const notesEl = document.getElementById("notes-text");
    notesEl.textContent = result.notes ? `Note: ${result.notes}` : "";

    // Swap sections and move focus to the page so Enter still works
    document.getElementById("answer-section").style.display = "none";
    document.getElementById("result-section").style.display = "block";
    document.getElementById("next-btn").focus();
}

// Allow pressing Enter to submit the answer, or advance to the next question
document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById("answer-input");
    if (input) {
        document.addEventListener("keydown", (e) => {
            if (e.key !== "Enter") return;
            const resultVisible = document.getElementById("result-section").style.display !== "none";
            if (resultVisible) {
                fetchNextQuestion();
            } else {
                submitAnswer();
            }
        });
        // Load the first question automatically
        fetchNextQuestion();
    }
});
