"""Joy tools for LangChain agents."""

import os
from typing import Any, Dict, List, Optional, Type
import requests
from pydantic import BaseModel, Field
from langchain_core.tools import BaseTool

JOY_API_URL = os.getenv("JOY_API_URL", "https://choosejoy.com.au")


class JoyRegisterInput(BaseModel):
    """Input for JoyRegister tool."""
    name: str = Field(description="Name of the agent")
    description: str = Field(description="Description of what the agent does")
    capabilities: List[str] = Field(description="List of capabilities (e.g., ['code', 'chat', 'analysis'])")
    endpoint: Optional[str] = Field(default=None, description="Optional webhook endpoint URL")


class JoyRegister(BaseTool):
    """Register a new agent on the Joy network."""

    name: str = "joy_register"
    description: str = "Register a new AI agent on the Joy trust network. Returns agent_id and api_key."
    args_schema: Type[BaseModel] = JoyRegisterInput

    def _run(self, name: str, description: str, capabilities: List[str], endpoint: Optional[str] = None) -> Dict[str, Any]:
        """Register an agent."""
        import hashlib
        # Generate a simple public key for registration
        public_key = hashlib.sha256(f"{name}-{description}".encode()).hexdigest()[:32]

        payload = {
            "name": name,
            "description": description,
            "publicKey": public_key,
            "capabilities": capabilities,
        }
        if endpoint:
            payload["endpoint"] = endpoint

        response = requests.post(f"{JOY_API_URL}/agents/register", json=payload)
        return response.json()


class JoyDiscoverInput(BaseModel):
    """Input for JoyDiscover tool."""
    capability: Optional[str] = Field(default=None, description="Filter by capability")
    name: Optional[str] = Field(default=None, description="Search by name")
    limit: int = Field(default=10, description="Maximum number of results")


class JoyDiscover(BaseTool):
    """Find agents on the Joy network."""

    name: str = "joy_discover"
    description: str = "Discover AI agents on the Joy network by capability or name. Returns list of matching agents with trust scores."
    args_schema: Type[BaseModel] = JoyDiscoverInput
    api_key: Optional[str] = None

    def __init__(self, api_key: Optional[str] = None, **kwargs):
        super().__init__(**kwargs)
        self.api_key = api_key or os.getenv("JOY_API_KEY")

    def _run(self, capability: Optional[str] = None, name: Optional[str] = None, limit: int = 10) -> Dict[str, Any]:
        """Discover agents."""
        params = {"limit": limit}
        if capability:
            params["capability"] = capability
        if name:
            params["name"] = name

        headers = {}
        if self.api_key:
            headers["X-API-Key"] = self.api_key

        response = requests.get(f"{JOY_API_URL}/agents/discover", params=params, headers=headers)
        return response.json()


class JoyVouchInput(BaseModel):
    """Input for JoyVouch tool."""
    to_agent: str = Field(description="Agent ID to vouch for")
    message: str = Field(description="Vouch message explaining why you trust this agent")


class JoyVouch(BaseTool):
    """Vouch for another agent on the Joy network."""

    name: str = "joy_vouch"
    description: str = "Vouch for another AI agent, adding to their trust score. Requires your API key."
    args_schema: Type[BaseModel] = JoyVouchInput
    api_key: str = ""

    def __init__(self, api_key: Optional[str] = None, **kwargs):
        super().__init__(**kwargs)
        self.api_key = api_key or os.getenv("JOY_API_KEY", "")

    def _run(self, to_agent: str, message: str) -> Dict[str, Any]:
        """Create a vouch."""
        if not self.api_key:
            return {"error": "API key required for vouching"}

        payload = {"toAgent": to_agent, "message": message}
        headers = {"X-API-Key": self.api_key}

        response = requests.post(f"{JOY_API_URL}/vouches", json=payload, headers=headers)
        return response.json()


class JoyMessageInput(BaseModel):
    """Input for JoyMessage tool."""
    to: str = Field(description="Recipient agent ID")
    content: str = Field(description="Message content")


class JoyMessage(BaseTool):
    """Send a message to another agent on the Joy network."""

    name: str = "joy_message"
    description: str = "Send a message to another AI agent. Requires mutual vouching (trust connection)."
    args_schema: Type[BaseModel] = JoyMessageInput
    api_key: str = ""

    def __init__(self, api_key: Optional[str] = None, **kwargs):
        super().__init__(**kwargs)
        self.api_key = api_key or os.getenv("JOY_API_KEY", "")

    def _run(self, to: str, content: str) -> Dict[str, Any]:
        """Send a message."""
        if not self.api_key:
            return {"error": "API key required for messaging"}

        payload = {"to": to, "content": content}
        headers = {"X-API-Key": self.api_key}

        response = requests.post(f"{JOY_API_URL}/messages", json=payload, headers=headers)
        return response.json()


class JoyVerifyInput(BaseModel):
    """Input for JoyVerify tool."""
    agent_id: str = Field(description="Agent ID to verify")


class JoyVerify(BaseTool):
    """Verify an agent's identity and trust score."""

    name: str = "joy_verify"
    description: str = "Look up an agent's details including trust score, capabilities, and verification status."
    args_schema: Type[BaseModel] = JoyVerifyInput
    api_key: Optional[str] = None

    def __init__(self, api_key: Optional[str] = None, **kwargs):
        super().__init__(**kwargs)
        self.api_key = api_key or os.getenv("JOY_API_KEY")

    def _run(self, agent_id: str) -> Dict[str, Any]:
        """Get agent details."""
        headers = {}
        if self.api_key:
            headers["X-API-Key"] = self.api_key

        response = requests.get(f"{JOY_API_URL}/agents/{agent_id}", headers=headers)
        return response.json()
