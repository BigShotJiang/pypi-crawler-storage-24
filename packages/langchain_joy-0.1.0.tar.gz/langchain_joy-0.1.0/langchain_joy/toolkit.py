"""Joy toolkit for LangChain."""

from typing import List, Optional
from langchain_core.tools import BaseTool
from langchain_joy.tools import (
    JoyRegister,
    JoyDiscover,
    JoyVouch,
    JoyMessage,
    JoyVerify,
)


class JoyToolkit:
    """Toolkit providing Joy tools for LangChain agents.

    Joy is a decentralized trust network for AI agents, providing:
    - Agent identity and registration
    - Discovery by capability
    - Trust through vouching
    - Secure cross-platform messaging

    Example:
        >>> toolkit = JoyToolkit(api_key="joy_...")
        >>> tools = toolkit.get_tools()
        >>> # Use tools with any LangChain agent
    """

    def __init__(self, api_key: Optional[str] = None):
        """Initialize the toolkit.

        Args:
            api_key: Joy API key. If not provided, uses JOY_API_KEY env var.
        """
        self.api_key = api_key

    def get_tools(self) -> List[BaseTool]:
        """Get all Joy tools.

        Returns:
            List of LangChain tools for interacting with Joy network.
        """
        return [
            JoyRegister(),
            JoyDiscover(api_key=self.api_key),
            JoyVouch(api_key=self.api_key),
            JoyMessage(api_key=self.api_key),
            JoyVerify(api_key=self.api_key),
        ]
