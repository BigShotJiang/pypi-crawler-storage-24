from setuptools import setup, find_packages

setup(
    name="langchain-joy",
    version="0.1.0",
    description="LangChain integration for Joy Agent Trust Network",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Joy Network",
    author_email="tom@autropic.com",
    url="https://github.com/tlkc888-Jenkins/Joy",
    packages=find_packages(),
    install_requires=[
        "langchain-core>=0.1.0",
        "requests>=2.28.0",
    ],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords="langchain joy agents trust network mcp ai",
)
