"""
FastTRL - Hızlı ve Güvenilir Transformer RL Kütüphanesi
setup.py
"""

from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="fasttrl",
    version="1.0.0",
    description="Yüksek performanslı, güvenilir Transformer Reinforcement Learning kütüphanesi",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="FastTRL",
    python_requires=">=3.9",
    packages=find_packages(),
    install_requires=[
        "torch>=2.0.0",
        "transformers>=4.38.0",
        "datasets>=2.14.0",
        "numpy>=1.24.0",
        "tqdm>=4.65.0",
        "accelerate>=0.27.0",
    ],
    extras_require={
        "peft": ["peft>=0.9.0"],
        "bitsandbytes": ["bitsandbytes>=0.42.0"],
        "flash_attn": ["flash-attn>=2.5.0"],
        "dev": [
            "pytest>=7.0",
            "black",
            "isort",
            "mypy",
        ],
        "all": [
            "peft>=0.9.0",
            "bitsandbytes>=0.42.0",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords=[
        "reinforcement learning",
        "transformers",
        "rlhf",
        "ppo",
        "dpo",
        "sft",
        "grpo",
        "llm",
        "fine-tuning",
    ],
)
