"""
Chroma client and collection operations. One module = one responsibility: connect and add documents.
Requires: pip install hecvec[chroma] (chromadb).
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000


def get_client(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    persist_path: str | None = None,
):
    """
    Return a Chroma client and mode.

    - If persist_path is set: use PersistentClient(path). Data is stored on disk.
      Returns (client, "persistent"). host/port are ignored.
    - Else: try HttpClient(host, port). If that fails, use EphemeralClient().
      Returns (client, "server") or (client, "ephemeral").
    """
    import chromadb
    if persist_path is not None:
        client = chromadb.PersistentClient(path=persist_path)
        return client, "persistent"
    try:
        client = chromadb.HttpClient(host=host, port=port)
        return client, "server"
    except Exception:
        return chromadb.EphemeralClient(), "ephemeral"


def get_or_create_collection(
    client: "chromadb.HttpClient",
    name: str,
    metadata: dict | None = None,
):
    """Get or create a collection (cosine similarity by default)."""
    if metadata is None:
        metadata = {"hnsw:space": "cosine"}
    return client.get_or_create_collection(name=name, metadata=metadata)


def add_documents(
    client: "chromadb.HttpClient",
    collection_name: str,
    ids: list[str],
    embeddings: list[list[float]],
    documents: list[str],
) -> dict:
    """
    Add documents to a collection. If dimension mismatch, deletes and recreates the collection.
    Returns {"collection_existed": bool} so the caller can log whether the collection was pre-existing.
    """
    import chromadb
    existing_names = [c.name for c in client.list_collections()]
    collection_existed = collection_name in existing_names
    coll = get_or_create_collection(client, collection_name)
    try:
        coll.add(ids=ids, embeddings=embeddings, documents=documents)
    except chromadb.errors.InvalidArgumentError as e:
        if "dimension" not in str(e).lower():
            raise
        client.delete_collection(name=collection_name)
        coll = client.create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        coll.add(ids=ids, embeddings=embeddings, documents=documents)
        collection_existed = False  # we recreated it
    return {"collection_existed": collection_existed}
