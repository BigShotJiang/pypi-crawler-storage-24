"""Tests for kryten-userstats."""
