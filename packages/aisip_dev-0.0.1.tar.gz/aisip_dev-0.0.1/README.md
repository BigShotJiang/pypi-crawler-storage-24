# aisip-dev

AISIP Dev — AI Structured Instruction Protocol development tools

- Protocol: https://aisip.dev
- License: MIT
