"""
ASIFlow MCP Server SDK -- Build MCP-compatible servers easily.

Quick start::

    from asiflow_mcp_sdk import MCPServer, create_mcp_app

    server = MCPServer(name="my-server", version="1.0.0")

    @server.tool("greet", description="Greet someone")
    async def greet(name: str) -> str:
        return f"Hello, {name}!"

    app = create_mcp_app(server)
    # Run: uvicorn my_server:app --port 3001
"""

from .models import (
    MCPPromptArgument,
    MCPPromptDef,
    MCPResourceDef,
    MCPToolAnnotations,
    MCPToolDef,
)
from .server import MCPServer, create_mcp_app

__all__ = [
    "MCPServer",
    "MCPToolDef",
    "MCPToolAnnotations",
    "MCPResourceDef",
    "MCPPromptDef",
    "MCPPromptArgument",
    "create_mcp_app",
]

__version__ = "1.0.0"
