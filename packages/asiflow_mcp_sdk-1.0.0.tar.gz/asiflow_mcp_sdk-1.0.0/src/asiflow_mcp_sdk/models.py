"""
Pydantic models for MCP protocol types.

Defines the core data structures used by the MCP Server SDK:
tool definitions, resource definitions, prompt definitions,
and their associated annotation/argument types.
"""

from __future__ import annotations

from typing import Any, Callable, Coroutine

from pydantic import BaseModel, Field


class MCPToolAnnotations(BaseModel):
    """MCP 2025-11-25 tool behavior annotations.

    These hints inform the client about the tool's behavior so it can
    make better decisions about confirmation prompts, caching, etc.
    """

    title: str = ""
    readOnlyHint: bool = False
    destructiveHint: bool = False
    idempotentHint: bool = False
    openWorldHint: bool = False


class MCPToolDef(BaseModel):
    """Internal representation of a registered MCP tool."""

    name: str
    description: str = ""
    inputSchema: dict[str, Any] = Field(default_factory=lambda: {
        "type": "object",
        "properties": {},
    })
    annotations: MCPToolAnnotations | None = None
    handler: Any = Field(default=None, exclude=True)

    model_config = {"arbitrary_types_allowed": True}

    def to_protocol(self) -> dict[str, Any]:
        """Serialize to the MCP protocol wire format for tools/list."""
        result: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.inputSchema,
        }
        if self.annotations is not None:
            result["annotations"] = self.annotations.model_dump(exclude_none=True)
        return result


class MCPResourceDef(BaseModel):
    """Internal representation of a registered MCP resource."""

    uri: str
    name: str
    description: str = ""
    mimeType: str = "application/json"
    handler: Any = Field(default=None, exclude=True)

    model_config = {"arbitrary_types_allowed": True}

    def to_protocol(self) -> dict[str, Any]:
        """Serialize to the MCP protocol wire format for resources/list."""
        return {
            "uri": self.uri,
            "name": self.name,
            "description": self.description,
            "mimeType": self.mimeType,
        }


class MCPPromptArgument(BaseModel):
    """A single argument for an MCP prompt."""

    name: str
    description: str = ""
    required: bool = False


class MCPPromptDef(BaseModel):
    """Internal representation of a registered MCP prompt."""

    name: str
    description: str = ""
    arguments: list[MCPPromptArgument] = Field(default_factory=list)
    handler: Any = Field(default=None, exclude=True)

    model_config = {"arbitrary_types_allowed": True}

    def to_protocol(self) -> dict[str, Any]:
        """Serialize to the MCP protocol wire format for prompts/list."""
        result: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
        }
        if self.arguments:
            result["arguments"] = [
                arg.model_dump(exclude_none=True) for arg in self.arguments
            ]
        return result


# Type aliases for handler signatures.
ToolHandler = Callable[..., Coroutine[Any, Any, Any]]
ResourceHandler = Callable[..., Coroutine[Any, Any, Any]]
PromptHandler = Callable[..., Coroutine[Any, Any, Any]]
