"""
Minimal MCP server example.

Demonstrates the core SDK API: registering tools, a resource, and
running the server with uvicorn.

Run:
    cd examples
    pip install -e ..
    uvicorn hello_world_server:app --port 3001 --reload

Connect from Claude Code:
    claude mcp add --transport http http://localhost:3001/mcp
"""

from asiflow_mcp_sdk import MCPServer, create_mcp_app

server = MCPServer(name="hello-world", version="1.0.0")


@server.tool("greet", description="Greet someone by name")
async def greet(name: str = "World") -> str:
    """Say hello to someone."""
    return f"Hello, {name}!"


@server.tool("add", description="Add two numbers")
async def add(a: int, b: int) -> int:
    """Return the sum of a and b."""
    return a + b


@server.resource("hello://info", name="Server Info", description="About this server")
async def server_info() -> dict:
    """Return basic information about this MCP server."""
    return {
        "name": "Hello World MCP Server",
        "version": "1.0.0",
        "tools": ["greet", "add"],
        "description": "A minimal example MCP server built with asiflow-mcp-sdk.",
    }


app = create_mcp_app(server)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=3001)
