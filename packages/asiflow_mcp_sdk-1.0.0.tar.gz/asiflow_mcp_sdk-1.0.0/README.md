# ASIFlow MCP Server SDK

Build MCP-compatible servers in Python with a decorator-based API. Ships tools, resources, and prompts over the **MCP 2025-11-25 Streamable HTTP** transport via FastAPI.

## Quickstart

### Install

```bash
pip install asiflow-mcp-sdk
```

Or install from source:

```bash
cd backend/mcp-server-sdk
pip install -e .
```

### Create a server

```python
# my_server.py
from asiflow_mcp_sdk import MCPServer, create_mcp_app

server = MCPServer(name="my-server", version="1.0.0")

@server.tool("greet", description="Greet someone by name")
async def greet(name: str = "World") -> str:
    return f"Hello, {name}!"

@server.tool("add", description="Add two numbers")
async def add(a: int, b: int) -> int:
    return a + b

@server.resource("myapp://status", name="Status", description="Server status")
async def status() -> dict:
    return {"ok": True, "tools": 2}

app = create_mcp_app(server)
```

### Run

```bash
uvicorn my_server:app --port 3001
```

The server is now live at `http://localhost:3001/mcp`.

### Connect from Claude Code

```bash
claude mcp add my-server --transport http http://localhost:3001/mcp
```

### Connect from Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "my-server": {
      "url": "http://localhost:3001/mcp"
    }
  }
}
```

## API Reference

### `MCPServer(name, version)`

The core server class. Register tools, resources, and prompts using decorators.

```python
server = MCPServer(name="my-server", version="1.0.0")
```

### `@server.tool(name, *, description, annotations)`

Register an async function as an MCP tool. Input schema is auto-generated from type hints.

```python
@server.tool("calculate", description="Evaluate a math expression")
async def calculate(expression: str) -> str:
    return str(eval(expression))
```

**Parameters:**
- `name` -- Unique tool name exposed to clients.
- `description` -- Human-readable description.
- `annotations` -- Optional `MCPToolAnnotations` or dict with behavior hints:
  - `title` -- Display name.
  - `readOnlyHint` -- Tool does not modify state.
  - `destructiveHint` -- Tool may delete data.
  - `idempotentHint` -- Safe to call multiple times.
  - `openWorldHint` -- Tool accesses external systems.

**Supported type hints:** `str`, `int`, `float`, `bool`, `list`, `dict`, `list[T]`, `Optional[T]`.

Parameters with defaults become optional in the schema. Parameters without defaults are required.

### `@server.resource(uri, *, name, description, mime_type)`

Register an async function as an MCP resource.

```python
@server.resource("myapp://config", name="Config", description="App configuration")
async def config() -> dict:
    return {"debug": False, "version": "1.0.0"}
```

**Parameters:**
- `uri` -- The resource URI (e.g. `"myapp://config"`).
- `name` -- Display name.
- `description` -- Human-readable description.
- `mime_type` -- Content type (default `"application/json"`).

### `@server.prompt(name, *, description, arguments)`

Register an async function as an MCP prompt template.

```python
@server.prompt("summarize", description="Summarize a document")
async def summarize(text: str, max_length: int = 100) -> list[dict]:
    return [
        {
            "role": "user",
            "content": {
                "type": "text",
                "text": f"Summarize in {max_length} words:\n\n{text}",
            },
        }
    ]
```

If `arguments` is omitted, they are inferred from the function signature.

**Parameters:**
- `name` -- Unique prompt name.
- `description` -- Human-readable description.
- `arguments` -- List of `MCPPromptArgument` or dicts with `name`, `description`, `required`.

### `create_mcp_app(server, *, prefix, cors_origins)`

Create a FastAPI application serving the MCP protocol.

```python
app = create_mcp_app(server, prefix="/mcp", cors_origins=["*"])
```

**Endpoints created:**
| Method | Path | Description |
|--------|------|-------------|
| POST | `/mcp` | JSON-RPC 2.0 MCP endpoint |
| GET | `/mcp` | SSE stream (server-initiated messages) |
| GET | `/mcp/tools` | List tools (convenience) |
| GET | `/mcp/resources` | List resources (convenience) |
| GET | `/mcp/prompts` | List prompts (convenience) |
| GET | `/health` | Health check |

### Types

```python
from asiflow_mcp_sdk import (
    MCPToolDef,          # Tool definition model
    MCPToolAnnotations,  # Tool behavior hints
    MCPResourceDef,      # Resource definition model
    MCPPromptDef,        # Prompt definition model
    MCPPromptArgument,   # Prompt argument model
)
```

## Protocol

The SDK implements **MCP 2025-11-25** over Streamable HTTP:

- **POST** `/mcp` -- Accepts JSON-RPC 2.0 requests (single or batch). Returns JSON.
- **GET** `/mcp` -- Opens an SSE stream for server-initiated notifications (requires `Mcp-Session-Id` header).
- **Session management** -- `initialize` creates a session; the `Mcp-Session-Id` header is returned and must be sent on subsequent requests.

### Supported JSON-RPC methods

| Method | Description |
|--------|-------------|
| `initialize` | Start a session, negotiate capabilities |
| `ping` | Keepalive |
| `tools/list` | List available tools |
| `tools/call` | Execute a tool |
| `resources/list` | List available resources |
| `resources/read` | Read a resource's content |
| `resources/subscribe` | Subscribe to resource updates |
| `resources/unsubscribe` | Unsubscribe from resource updates |
| `prompts/list` | List available prompts |
| `prompts/get` | Render a prompt with arguments |

## ASIFlow Integration

To connect this SDK-built server to ASIFlow's agent-core as an external MCP server, register it in the ASIFlow MCP server configuration:

```json
{
  "mcpServers": {
    "my-custom-server": {
      "transport": "streamable-http",
      "url": "http://my-server:3001/mcp"
    }
  }
}
```

ASIFlow agents can then use tools from your server alongside built-in tools.

## Examples

- [`examples/hello_world_server.py`](examples/hello_world_server.py) -- Minimal server with two tools and one resource.
- [`examples/weather_server.py`](examples/weather_server.py) -- Full server with four tools, three resources, two prompts, and tool annotations.

## License

MIT
