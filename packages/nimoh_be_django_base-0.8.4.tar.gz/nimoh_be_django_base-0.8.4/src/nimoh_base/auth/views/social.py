"""
nimoh_base.auth.views.social
=============================
Ready-to-use done-view for the PSA OAuth dance.

Mount it in your project URLs::

    from nimoh_base.auth.views.social import social_login_done_view

    urlpatterns = [
        path("api/v1/auth/social/done/", social_login_done_view, name="social-auth-done"),
        path("api/v1/auth/social/", include("social_django.urls", namespace="social")),
    ]

And point PSA at it::

    SOCIAL_AUTH_LOGIN_REDIRECT_URL = "/api/v1/auth/social/done/"
    SOCIAL_AUTH_NEW_USER_REDIRECT_URL = "/api/v1/auth/social/done/"
"""
import logging

from django.conf import settings as django_settings
from django.http import HttpResponseRedirect
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny

from nimoh_base.conf.social import SOCIAL_EXCHANGE_TOKEN_SESSION_KEY

logger = logging.getLogger(__name__)


@api_view(["GET"])
@permission_classes([AllowAny])
def social_login_done_view(request):
    """
    GET handler for SOCIAL_AUTH_LOGIN_REDIRECT_URL.

    The exchange token was stored in PSA's session by the
    ``social_generate_exchange_token`` pipeline step.  This view pops it and
    redirects the browser to ``{FRONTEND_URL}/auth/verified?exchange_token=``
    so the frontend can exchange it for JWT cookies via the standard
    exchange-token endpoint.

    Intentionally does NOT rely on ``request.user`` — see social_generate_exchange_token in nimoh_base.conf.social for why.
    """
    frontend_url = getattr(django_settings, "FRONTEND_URL", "http://localhost:3000")

    # PSA stores session data on the underlying Django request via
    # DjangoStrategy.session_set() → request.session[key].
    django_request = getattr(request, "_request", request)
    exchange_token = django_request.session.pop(SOCIAL_EXCHANGE_TOKEN_SESSION_KEY, None)
    if exchange_token:
        django_request.session.save()

    if not exchange_token:
        logger.warning("social_login_done_view: no exchange token in session — pipeline step missing?")
        return HttpResponseRedirect(f"{frontend_url}/auth/verify-error?reason=social_auth_failed")

    logger.info("Social auth done — redirecting to /auth/verified")
    return HttpResponseRedirect(f"{frontend_url}/auth/verified?exchange_token={exchange_token}")
