import os, json, threading, webbrowser, importlib.util, datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

CONF = Path.home() / ".config" / "daps"
CONF_FILE = CONF / "config.json"
PLUGIN_DIR = CONF / "plugins"
LOG_FILE = CONF / "shell.log"
HISTORY_FILE = Path.home() / ".daps.history"
HTML = Path(__file__).parent / "ui.html"

def read_config():
        if not CONF_FILE.exists(): return {"aliases":{}, "cleargreet":"no"}
        with open(CONF_FILE) as f: return json.load(f)

def write_config(data):
        with open(CONF_FILE,"w") as f: json.dump(data, f, indent=2)

def get_plugins():
        plugins = []
        if not PLUGIN_DIR.exists(): return plugins
        for f in PLUGIN_DIR.iterdir():
                if f.suffix != ".py": continue
                desc = "no description"
                try:
                        spec = importlib.util.spec_from_file_location(f.stem, f)
                        mod = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(mod)
                        doc = getattr(mod, "__doc__", None) or (mod.run.__doc__ if hasattr(mod, "run") else None)
                        if doc: desc = doc.strip()
                except Exception: pass
                plugins.append({"name": f.stem, "desc": desc, "file": str(f)})
        return plugins

def install_plugin(url):
        import urllib.request
        name = url.split("/")[-1]
        if not name.endswith(".py"): name += ".py"
        dest = PLUGIN_DIR / name
        try: urllib.request.urlretrieve(url, dest); return True, None
        except Exception as e: return False, str(e)

def remove_plugin(name):
        f = PLUGIN_DIR / f"{name}.py"
        if f.exists(): f.unlink(); return True
        return False

def read_history():
        if not HISTORY_FILE.exists(): return []
        try:
                lines = HISTORY_FILE.read_text().splitlines()
                return [l for l in lines if l.strip() and not l.startswith("+")]
        except Exception: return []

def clear_history():
        if HISTORY_FILE.exists(): HISTORY_FILE.write_text("")
        return True

def read_log():
        if not LOG_FILE.exists(): return []
        try:
                entries = []
                for line in LOG_FILE.read_text().splitlines():
                        try: entries.append(json.loads(line))
                        except Exception: pass
                return entries
        except Exception: return []

def clear_log():
        if LOG_FILE.exists(): LOG_FILE.write_text("")
        return True

class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_): pass

        def send_json(self, data, code=200):
                body = json.dumps(data).encode()
                self.send_response(code)
                self.send_header("Content-Type","application/json")
                self.send_header("Content-Length",len(body))
                self.send_header("Access-Control-Allow-Origin","*")
                self.end_headers()
                self.wfile.write(body)

        def send_html(self):
                body = HTML.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type","text/html")
                self.send_header("Content-Length",len(body))
                self.end_headers()
                self.wfile.write(body)

        def do_GET(self):
                if self.path in ("/","/index.html"): self.send_html()
                elif self.path == "/api/config":
                        cfg = read_config(); cfg["_plugins"] = get_plugins(); self.send_json(cfg)
                elif self.path == "/api/history": self.send_json({"lines": read_history()})
                elif self.path == "/api/log": self.send_json({"entries": read_log()})
                else: self.send_json({"error":"not found"},404)

        def do_POST(self):
                length = int(self.headers.get("Content-Length",0))
                body = json.loads(self.rfile.read(length)) if length else {}
                if self.path == "/api/config":
                        body.pop("_plugins",None); write_config(body); self.send_json({"ok":True})
                elif self.path == "/api/plugin/install":
                        ok, err = install_plugin(body.get("url","")); self.send_json({"ok":ok,"error":err})
                elif self.path == "/api/plugin/remove":
                        self.send_json({"ok": remove_plugin(body.get("name",""))})
                elif self.path == "/api/history/clear":
                        self.send_json({"ok": clear_history()})
                elif self.path == "/api/log/clear":
                        self.send_json({"ok": clear_log()})
                else: self.send_json({"error":"not found"},404)

        def do_OPTIONS(self):
                self.send_response(200)
                self.send_header("Access-Control-Allow-Origin","*")
                self.send_header("Access-Control-Allow-Methods","GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers","Content-Type")
                self.end_headers()

def launch(port=6473):
        server = HTTPServer(("127.0.0.1", port), Handler)
        url = f"http://127.0.0.1:{port}"
        print(f"\033[96mdaps\033[0m  config ui → {url}")
        print(f"\033[96mdaps\033[0m  ctrl+c to stop")
        threading.Timer(0.3, lambda: webbrowser.open(url)).start()
        try: server.serve_forever()
        except KeyboardInterrupt: print("\n\033[96mdaps\033[0m  stopped")
