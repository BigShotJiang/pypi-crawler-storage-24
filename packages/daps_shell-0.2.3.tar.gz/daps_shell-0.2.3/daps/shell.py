#!/usr/bin/env python3
import os, sys, signal, json, importlib.util, subprocess, glob, shutil, difflib, threading, time, socket, urllib.request, re
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.lexers import Lexer
from prompt_toolkit.styles import Style
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.history import FileHistory
from prompt_toolkit.keys import Keys
from prompt_toolkit.key_binding import KeyBindings

plugins = {}
_start_time = time.monotonic()

THEMES = {
    "default":   {"username":"#00d787 bold","at":"#ffffff","hostname":"#5fafff bold","paren":"#00d787","ident":"#00d787 bold","dash":"#ffffff","path":"#00d7af bold","arrow":"#00d787 bold","errcode":"#ff5f5f bold","branch":"#d7af5f","builtin":"#00d787 bold","alias":"#5fafff bold","plugin":"#d7af5f bold","cmd":"#ffffff","cmd-real":"#ffffff underline","args":"#aaaaaa","arg-real":"#aaaaaa underline","time":"#888888"},
    "fire":      {"username":"#ff5f00 bold","at":"#ffffff","hostname":"#ff8700 bold","paren":"#ff5f00","ident":"#ff5f00 bold","dash":"#ffffff","path":"#ffaf00 bold","arrow":"#ff5f00 bold","errcode":"#ff0000 bold","branch":"#ffaf5f","builtin":"#ff5f00 bold","alias":"#ffaf00 bold","plugin":"#ff8700 bold","cmd":"#ffffff","cmd-real":"#ffffff underline","args":"#aaaaaa","arg-real":"#aaaaaa underline","time":"#888888"},
    "ocean":     {"username":"#0087ff bold","at":"#ffffff","hostname":"#00afff bold","paren":"#0087ff","ident":"#0087ff bold","dash":"#ffffff","path":"#00d7ff bold","arrow":"#0087ff bold","errcode":"#ff5f5f bold","branch":"#5fafff","builtin":"#0087ff bold","alias":"#00afff bold","plugin":"#5fafff bold","cmd":"#ffffff","cmd-real":"#ffffff underline","args":"#aaaaaa","arg-real":"#aaaaaa underline","time":"#888888"},
    "candy":     {"username":"#ff5faf bold","at":"#ffffff","hostname":"#af5fff bold","paren":"#ff5faf","ident":"#ff5faf bold","dash":"#ffffff","path":"#ff87d7 bold","arrow":"#ff5faf bold","errcode":"#ff0000 bold","branch":"#ffaf5f","builtin":"#ff5faf bold","alias":"#af5fff bold","plugin":"#ff87d7 bold","cmd":"#ffffff","cmd-real":"#ffffff underline","args":"#aaaaaa","arg-real":"#aaaaaa underline","time":"#888888"},
    "mono":      {"username":"#ffffff bold","at":"#aaaaaa","hostname":"#ffffff bold","paren":"#aaaaaa","ident":"#ffffff bold","dash":"#aaaaaa","path":"#ffffff bold","arrow":"#ffffff bold","errcode":"#ff5f5f bold","branch":"#aaaaaa","builtin":"#ffffff bold","alias":"#aaaaaa bold","plugin":"#aaaaaa bold","cmd":"#ffffff","cmd-real":"#ffffff underline","args":"#666666","arg-real":"#666666 underline","time":"#555555"},
    "cyberpunk": {"username":"#ffff00 bold","at":"#ff00ff","hostname":"#ff00ff bold","paren":"#ffff00","ident":"#ffff00 bold","dash":"#ff00ff","path":"#00ffff bold","arrow":"#ffff00 bold","errcode":"#ff0000 bold","branch":"#ff00ff","builtin":"#ffff00 bold","alias":"#ff00ff bold","plugin":"#00ffff bold","cmd":"#ffffff","cmd-real":"#ffffff underline","args":"#aaaaaa","arg-real":"#aaaaaa underline","time":"#888888"},
    "nord":      {"username":"#88c0d0 bold","at":"#e5e9f0","hostname":"#81a1c1 bold","paren":"#88c0d0","ident":"#88c0d0 bold","dash":"#e5e9f0","path":"#8fbcbb bold","arrow":"#88c0d0 bold","errcode":"#bf616a bold","branch":"#ebcb8b","builtin":"#88c0d0 bold","alias":"#81a1c1 bold","plugin":"#b48ead bold","cmd":"#eceff4","cmd-real":"#eceff4 underline","args":"#7b88a1","arg-real":"#7b88a1 underline","time":"#616e88"},
    "dracula":   {"username":"#ff79c6 bold","at":"#f8f8f2","hostname":"#bd93f9 bold","paren":"#ff79c6","ident":"#ff79c6 bold","dash":"#f8f8f2","path":"#50fa7b bold","arrow":"#ff79c6 bold","errcode":"#ff5555 bold","branch":"#f1fa8c","builtin":"#ff79c6 bold","alias":"#bd93f9 bold","plugin":"#8be9fd bold","cmd":"#f8f8f2","cmd-real":"#f8f8f2 underline","args":"#6272a4","arg-real":"#6272a4 underline","time":"#44475a"},
    "solarized": {"username":"#859900 bold","at":"#839496","hostname":"#268bd2 bold","paren":"#859900","ident":"#859900 bold","dash":"#839496","path":"#2aa198 bold","arrow":"#859900 bold","errcode":"#dc322f bold","branch":"#b58900","builtin":"#859900 bold","alias":"#268bd2 bold","plugin":"#6c71c4 bold","cmd":"#839496","cmd-real":"#839496 underline","args":"#586e75","arg-real":"#586e75 underline","time":"#657b83"},
    "blood":     {"username":"#ff0000 bold","at":"#cc0000","hostname":"#aa0000 bold","paren":"#ff0000","ident":"#ff0000 bold","dash":"#cc0000","path":"#ff3333 bold","arrow":"#ff0000 bold","errcode":"#ffffff bold","branch":"#ff6666","builtin":"#ff0000 bold","alias":"#cc0000 bold","plugin":"#ff3333 bold","cmd":"#ffcccc","cmd-real":"#ffcccc underline","args":"#993333","arg-real":"#993333 underline","time":"#661111"},
    "ice":       {"username":"#ffffff bold","at":"#aaffff","hostname":"#00ffff bold","paren":"#ffffff","ident":"#ffffff bold","dash":"#aaffff","path":"#aaffff bold","arrow":"#ffffff bold","errcode":"#ff5f5f bold","branch":"#00ffff","builtin":"#ffffff bold","alias":"#00ffff bold","plugin":"#aaffff bold","cmd":"#ffffff","cmd-real":"#ffffff underline","args":"#88cccc","arg-real":"#88cccc underline","time":"#557777"},
}

PROMPT_FORMATS = {
    "default": "{errcode}{time}{user}@{host} ({ident}) - {cwd}{branch}\n> ",
    "minimal":  "{errcode}{user} {cwd}{branch} > ",
    "compact":  "{errcode}{ident} {cwd}{branch} > ",
    "powerline":"{errcode} {user} | {cwd} | {branch} \n> ",
    "classic":  "[{user}@{host} {cwd}]{branch}{ident} ",
}

def loadconf():
        conf_dir = os.path.expanduser("~/.config/daps")
        whereis = os.path.join(conf_dir, "config.json")
        plugin_dir = os.path.join(conf_dir, "plugins")
        os.makedirs(plugin_dir, exist_ok=True)
        if not os.path.exists(whereis):
                with open(whereis, "w") as f:
                        json.dump({"aliases": {}, "cleargreet": "no"}, f, indent=2)
        for filename in os.listdir(plugin_dir):
                if filename.endswith(".py"):
                        name = filename[:-3]
                        try:
                                spec = importlib.util.spec_from_file_location(name, os.path.join(plugin_dir, filename))
                                module = importlib.util.module_from_spec(spec)
                                spec.loader.exec_module(module)
                                plugins[name] = module
                        except Exception as e:
                                print(f"\033[91merror\033[0m loading plugin '{name}': {e}", file=sys.stderr)
        try:
                with open(whereis) as f:
                        return json.load(f)
        except json.JSONDecodeError as e:
                print(f"\033[91merror\033[0m invalid JSON in config: {e}", file=sys.stderr)
                sys.exit(1)

def reload_plugins(base_config):
        plugins.clear()
        plugin_dir = os.path.join(os.path.expanduser("~/.config/daps"), "plugins")
        for filename in os.listdir(plugin_dir):
                if filename.endswith(".py"):
                        name = filename[:-3]
                        try:
                                spec = importlib.util.spec_from_file_location(name, os.path.join(plugin_dir, filename))
                                module = importlib.util.module_from_spec(spec)
                                spec.loader.exec_module(module)
                                plugins[name] = module
                        except Exception as e:
                                print(f"\033[91merror\033[0m loading plugin '{name}': {e}", file=sys.stderr)

def load_local_conf(base):
        local = os.path.join(os.getcwd(), ".daps")
        if not os.path.exists(local): return base
        try:
                with open(local) as f: overrides = json.load(f)
                merged = dict(base)
                merged["aliases"] = {**base.get("aliases", {}), **overrides.get("aliases", {})}
                for k, v in overrides.items():
                        if k != "aliases": merged[k] = v
                return merged
        except Exception: return base

def save_conf(config):
        whereis = os.path.join(os.path.expanduser("~/.config/daps"), "config.json")
        with open(whereis, "w") as f: json.dump(config, f, indent=2)

def get_bookmarks():
        f = os.path.expanduser("~/.config/daps/bookmarks.json")
        if not os.path.exists(f): return {}
        try:
                with open(f) as fp: return json.load(fp)
        except Exception: return {}

def save_bookmarks(bm):
        f = os.path.expanduser("~/.config/daps/bookmarks.json")
        with open(f, "w") as fp: json.dump(bm, fp, indent=2)

def git_branch():
        try:
                r = subprocess.run(["git", "branch", "--show-current"], capture_output=True, text=True, timeout=1)
                b = r.stdout.strip()
                if not b: return None
                dirty = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True, timeout=1).stdout.strip()
                return f"{b}{'*' if dirty else ''}"
        except Exception: return None

def expand_env(s): return os.path.expandvars(os.path.expanduser(s))
def is_executable(cmd): return shutil.which(cmd) is not None
def is_existing_path(token): return os.path.exists(os.path.expanduser(expand_env(token)))
def is_ssh(): return "SSH_CLIENT" in os.environ or "SSH_TTY" in os.environ

def fmt_time(secs):
        if secs is None: return None
        if secs < 1: return f"{int(secs*1000)}ms"
        if secs < 60: return f"{secs:.1f}s"
        return f"{int(secs//60)}m{int(secs%60)}s"

BUILTINS = ["cd", "exit", "clear", "plugins", "daps", "which", "help", "bookmark", "bm"]

class DapsCompleter(Completer):
        def __init__(self, aliases):
                self.aliases = aliases
        def _commands(self):
                bm = list(get_bookmarks().keys())
                return list(self.aliases.keys()) + list(plugins.keys()) + BUILTINS + bm
        def get_completions(self, document, complete_event):
                text = document.text_before_cursor
                parts = text.split()
                word = document.get_word_before_cursor(WORD=True)
                if not parts or (len(parts) == 1 and not text.endswith(" ")):
                        for cmd in self._commands():
                                if cmd.startswith(word): yield Completion(cmd, start_position=-len(word))
                        return
                expanded = os.path.expanduser(expand_env(word))
                for m in glob.glob(expanded + "*"):
                        display = m.replace(os.path.expanduser("~"), "~", 1) if word.startswith("~") else m
                        if os.path.isdir(m): display += "/"
                        yield Completion(display, start_position=-len(word))

class DapsLexer(Lexer):
        def __init__(self, aliases):
                self.aliases = aliases
        def lex_document(self, document):
                def inner(line_no):
                        line = document.lines[line_no]
                        if not line.strip(): return FormattedText([("class:args", line)])
                        parts = line.split()
                        cmd = parts[0]
                        tokens = []
                        if cmd in BUILTINS: tokens.append(("class:builtin", cmd))
                        elif cmd in self.aliases: tokens.append(("class:alias", cmd))
                        elif cmd in plugins: tokens.append(("class:plugin", cmd))
                        elif is_executable(cmd): tokens.append(("class:cmd-real", cmd))
                        else: tokens.append(("class:cmd", cmd))
                        pos = len(cmd)
                        while pos < len(line):
                                if line[pos] == " ":
                                        start = pos
                                        while pos < len(line) and line[pos] == " ": pos += 1
                                        tokens.append(("class:args", line[start:pos]))
                                else:
                                        start = pos
                                        while pos < len(line) and line[pos] != " ": pos += 1
                                        chunk = line[start:pos]
                                        tokens.append(("class:arg-real" if is_existing_path(chunk) else "class:args", chunk))
                        return FormattedText(tokens)
                return inner

def make_style(theme_name):
        return Style.from_dict(THEMES.get(theme_name, THEMES["default"]))

def build_prompt(user, host, errcode, elapsed, theme_name, fmt_name="default"):
        home = os.path.expanduser("~")
        cwd = os.getcwd()
        display_cwd = cwd.replace(home, "~", 1) if cwd.startswith(home) else cwd
        ident = "#" if user == "root" else ("@" if is_ssh() else "$")
        branch = git_branch()
        t = fmt_time(elapsed)
        tokens = []
        if fmt_name == "minimal":
                if errcode and errcode != "0": tokens += [("class:errcode", f"[{errcode}] ")]
                tokens += [("class:username", user), ("class:dash", " "), ("class:path", display_cwd)]
                if branch: tokens += [("class:dash", " "), ("class:branch", f"[{branch}]")]
                tokens += [("", "\n"), ("class:arrow", "> ")]
        elif fmt_name == "compact":
                if errcode and errcode != "0": tokens += [("class:errcode", f"[{errcode}] ")]
                tokens += [("class:ident", ident), ("class:dash", " "), ("class:path", display_cwd)]
                if branch: tokens += [("class:dash", " "), ("class:branch", f"[{branch}]")]
                tokens += [("", "\n"), ("class:arrow", "> ")]
        elif fmt_name == "classic":
                tokens += [("class:paren", "["), ("class:username", user), ("class:at", "@"), ("class:hostname", host), ("class:dash", " "), ("class:path", display_cwd), ("class:paren", "]")]
                if branch: tokens += [("class:branch", f"({branch})")]
                tokens += [("class:ident", ident), ("", " ")]
        else:
                if errcode and errcode != "0": tokens += [("class:errcode", f"[{errcode}]"), ("class:dash", " - ")]
                if t: tokens += [("class:time", f"[{t}]"), ("class:dash", " - ")]
                tokens += [("class:username", user), ("class:at", "@"), ("class:hostname", host), ("class:dash", " "), ("class:paren", "("), ("class:ident", ident), ("class:paren", ")"), ("class:dash", " - "), ("class:path", display_cwd)]
                if branch: tokens += [("class:dash", " "), ("class:branch", f"[{branch}]")]
                tokens += [("", "\n"), ("class:arrow", "> ")]
        return tokens

def fmt_error(msg): print(f"\033[91mdaps error\033[0m  {msg}", file=sys.stderr)
def fmt_info(msg): print(f"\033[96mdaps\033[0m  {msg}")

def runfc(config, key):
        cmd = config.get(key)
        if cmd: os.system(cmd)

def do_clear(config):
        os.system("clear")
        if config.get("cleargreet") == "yes": runfc(config, "greeter")

def suggest(cmd, alias):
        path_cmds = []
        for p in os.environ.get("PATH", "").split(":"):
                if os.path.isdir(p):
                        try: path_cmds += os.listdir(p)
                        except Exception: pass
        all_cmds = list(alias.keys()) + list(plugins.keys()) + BUILTINS + path_cmds
        matches = difflib.get_close_matches(cmd, [c for c in all_cmds if isinstance(c, str)], n=3, cutoff=0.6)
        print(f"\033[93mdaps\033[0m  command not found: \033[91m{cmd}\033[0m")
        if matches: print(f"       did you mean: {', '.join(f'\033[96m{m}\033[0m' for m in matches)}?")

def do_help(alias):
        print(f"\033[96m{'─'*50}\033[0m")
        print(f"\033[96mdaps\033[0m  built-in commands:")
        helps = {
                "cd [path]": "change directory (- for prev, fuzzy match on miss)",
                "clear": "clear screen (re-runs greeter if cleargreet=yes)",
                "exit": "exit daps",
                "help": "show this help",
                "which <cmd>": "show what a command resolves to",
                "plugins": "list loaded plugins",
                "bookmark <name> [path]": "save/jump to a directory bookmark",
                "bm": "alias for bookmark",
                "daps config set/get": "manage config",
                "daps config ui": "open web config editor",
                "daps alias list": "list aliases",
                "daps theme <n>": "switch theme",
                "daps prompt <fmt>": "switch prompt format",
                "daps reload": "reload config and plugins",
                "daps update": "upgrade daps-shell",
                "daps env set/get/del/list": "manage env vars",
                "!! / sudo !!": "repeat last command",
                "cmd &": "run in background",
                "cmd \\": "multiline input",
        }
        for k, v in helps.items(): print(f"  \033[92m{k:<30}\033[0m {v}")
        if alias:
                print(f"\n\033[96mdaps\033[0m  aliases ({len(alias)}):")
                for k, v in alias.items(): print(f"  \033[96m{k:<20}\033[0m → {v}")
        if plugins:
                print(f"\n\033[96mdaps\033[0m  plugins ({len(plugins)}):")
                for name, mod in plugins.items():
                        doc = getattr(mod, "__doc__", None) or (mod.run.__doc__ if hasattr(mod, "run") else None) or "no description"
                        print(f"  \033[93m{name:<20}\033[0m {doc.strip()}")
        print(f"\033[96m{'─'*50}\033[0m")

def do_plugins():
        if not plugins: fmt_info("no plugins loaded"); return
        fmt_info(f"{len(plugins)} plugin(s) loaded:")
        for name, mod in plugins.items():
                doc = getattr(mod, "__doc__", None) or (mod.run.__doc__ if hasattr(mod, "run") else None) or "no description"
                print(f"  \033[96m{name}\033[0m  {doc.strip()}")

def do_which(args, alias):
        if not args: fmt_error("which: no command given"); return "1"
        cmd = args[0]
        if cmd in BUILTINS: print(f"{cmd}: daps built-in"); return "0"
        if cmd in alias: print(f"{cmd}: alias → {alias[cmd]}"); return "0"
        if cmd in plugins:
                mod = plugins[cmd]
                path = getattr(mod, "__file__", "unknown")
                print(f"{cmd}: daps plugin ({path})"); return "0"
        found = shutil.which(cmd)
        if found: print(f"{cmd}: {found}"); return "0"
        fmt_error(f"which: {cmd}: not found"); return "1"

def do_bookmark(args):
        bm = get_bookmarks()
        if not args:
                if not bm: fmt_info("no bookmarks"); return "0"
                fmt_info(f"{len(bm)} bookmark(s):")
                for k, v in bm.items(): print(f"  \033[96m{k:<20}\033[0m {v}")
                return "0"
        name = args[0]
        if len(args) >= 2:
                path = os.path.expanduser(" ".join(args[1:]))
                bm[name] = path; save_bookmarks(bm)
                fmt_info(f"bookmark '{name}' → {path}"); return "0"
        if name in bm:
                try: os.chdir(bm[name]); return "0"
                except Exception as e: fmt_error(str(e)); return "1"
        if name == "del" and len(args) >= 2:
                bm.pop(args[1], None); save_bookmarks(bm)
                fmt_info(f"bookmark '{args[1]}' removed"); return "0"
        bm[name] = os.getcwd(); save_bookmarks(bm)
        fmt_info(f"bookmark '{name}' → {os.getcwd()}"); return "0"

def do_cd_fuzzy(target):
        try: os.chdir(target); return True
        except FileNotFoundError:
                parent = os.path.dirname(target) or "."
                name = os.path.basename(target)
                try:
                        entries = os.listdir(parent)
                        matches = difflib.get_close_matches(name, [e for e in entries if os.path.isdir(os.path.join(parent, e))], n=1, cutoff=0.6)
                        if matches:
                                suggested = os.path.join(parent, matches[0])
                                print(f"\033[93mdaps\033[0m  '{target}' not found, trying '{suggested}'")
                                os.chdir(suggested); return True
                except Exception: pass
        return False

def do_env(args, base_config):
        envs = base_config.get("env", {})
        if not args or args[0] == "list":
                if not envs: fmt_info("no env vars set"); return "0"
                fmt_info(f"{len(envs)} env var(s):")
                for k, v in envs.items(): print(f"  \033[96m{k}\033[0m={v}")
                return "0"
        if args[0] == "set" and len(args) >= 3:
                key, val = args[1], " ".join(args[2:])
                envs[key] = val; base_config["env"] = envs
                os.environ[key] = val; save_conf(base_config)
                fmt_info(f"set {key}={val}"); return "0"
        if args[0] == "get" and len(args) >= 2:
                v = envs.get(args[1]) or os.environ.get(args[1])
                if v: print(f"  {args[1]}={v}"); return "0"
                fmt_error(f"env: {args[1]} not set"); return "1"
        if args[0] == "del" and len(args) >= 2:
                envs.pop(args[1], None); base_config["env"] = envs
                os.environ.pop(args[1], None); save_conf(base_config)
                fmt_info(f"unset {args[1]}"); return "0"
        fmt_error(f"usage: daps env set/get/del/list"); return "1"

def install_plugin(url):
        name = url.split("/")[-1]
        if not name.endswith(".py"): name += ".py"
        dest = os.path.join(os.path.expanduser("~/.config/daps/plugins"), name)
        try: urllib.request.urlretrieve(url, dest); return True, None
        except Exception as e: return False, str(e)

def do_daps_cmd(args, base_config):
        if not args:
                fmt_info("usage: daps config|plugins|plugin|reload|update|theme|prompt|alias|env|config ui")
                return "0"
        sub = args[0]
        if sub == "plugins": do_plugins(); return "0"
        if sub == "reload": return None
        if sub == "update":
                fmt_info("updating daps-shell...")
                r = subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "daps-shell"])
                return str(r.returncode)
        if sub == "theme":
                if len(args) < 2: fmt_info(f"available themes: {', '.join(THEMES.keys())}"); return "0"
                if args[1] not in THEMES: fmt_error(f"unknown theme: {args[1]}"); return "1"
                base_config["theme"] = args[1]; save_conf(base_config)
                fmt_info(f"theme set to {args[1]}"); return "0"
        if sub == "prompt":
                if len(args) < 2: fmt_info(f"available formats: {', '.join(PROMPT_FORMATS.keys())}"); return "0"
                if args[1] not in PROMPT_FORMATS: fmt_error(f"unknown format: {args[1]}"); return "1"
                base_config["prompt_format"] = args[1]; save_conf(base_config)
                fmt_info(f"prompt format set to {args[1]}"); return "0"
        if sub == "plugin" and len(args) >= 3 and args[1] == "install":
                ok, err = install_plugin(args[2])
                if ok: fmt_info("plugin installed"); return "0"
                fmt_error(f"install failed: {err}"); return "1"
        if sub == "alias" and len(args) >= 2 and args[1] == "list":
                aliases = base_config.get("aliases", {})
                if not aliases: fmt_info("no aliases set"); return "0"
                fmt_info(f"{len(aliases)} alias(es):")
                for k, v in aliases.items(): print(f"  \033[96m{k}\033[0m → {v}")
                return "0"
        if sub == "env":
                return do_env(args[1:], base_config)
        if sub == "config":
                if len(args) >= 2 and args[1] == "ui":
                        from daps.ui import launch; launch(); return "0"
                if len(args) < 2: fmt_info("usage: daps config set/get/set-alias/del-alias/ui"); return "0"
                if args[1] == "get" and len(args) >= 3:
                        print(f"  {args[2]} = {json.dumps(base_config.get(args[2], None))}"); return "0"
                if args[1] == "set" and len(args) >= 4:
                        key, val = args[2], " ".join(args[3:])
                        if val.lower() in ("true", "false"): val = val.lower() == "true"
                        base_config[key] = val; save_conf(base_config)
                        fmt_info(f"set {key} = {json.dumps(val)}"); return "0"
                if args[1] == "set-alias" and len(args) >= 4:
                        base_config.setdefault("aliases", {})[args[2]] = " ".join(args[3:])
                        save_conf(base_config); fmt_info(f"alias {args[2]} set"); return "0"
                if args[1] == "del-alias" and len(args) >= 3:
                        base_config.get("aliases", {}).pop(args[2], None)
                        save_conf(base_config); fmt_info(f"alias {args[2]} removed"); return "0"
        fmt_error(f"unknown daps command: {' '.join(args)}"); return "1"

def run_bg(cmd_parts):
        def target(): subprocess.run(" ".join(cmd_parts), shell=True)
        t = threading.Thread(target=target, daemon=True)
        t.start()
        print(f"\033[96m[bg]\033[0m  {' '.join(cmd_parts)}")

def apply_saved_env(config):
        for k, v in config.get("env", {}).items(): os.environ[k] = v

def main():
        signal.signal(signal.SIGINT, lambda *_: sys.exit(255))
        base_config = loadconf()
        apply_saved_env(base_config)
        history_path = os.path.expanduser("~/.daps.history")
        user = subprocess.run(["whoami"], capture_output=True, text=True).stdout.strip()
        try:
                with open("/etc/hostname") as f: host = f.read().strip()
        except Exception: host = "daps-station"

        startup_elapsed = time.monotonic() - _start_time
        if startup_elapsed > 0.3:
                print(f"\033[90mstarted in {startup_elapsed*1000:.0f}ms\033[0m")

        prev_dir = os.getcwd()
        errcode = None
        elapsed = None
        history = []
        bm = get_bookmarks()

        def make_session(alias, theme):
                kb = KeyBindings()
                return PromptSession(
                        history=FileHistory(history_path),
                        completer=DapsCompleter(alias), lexer=DapsLexer(alias),
                        style=make_style(theme), complete_while_typing=False,
                        key_bindings=kb, enable_history_search=True,
                )

        config = load_local_conf(base_config)
        session = make_session(config.get("aliases", {}), config.get("theme", "default"))
        do_clear(config)
        runfc(config, "greeter")

        while True:
                try:
                        cur_dir = os.getcwd()
                        if cur_dir != prev_dir:
                                config = load_local_conf(base_config)
                                session = make_session(config.get("aliases", {}), config.get("theme", "default"))
                                prev_dir = cur_dir
                        alias = config.get("aliases", {})
                        fmt = config.get("prompt_format", "default")
                        try:
                                raw = session.prompt(FormattedText(build_prompt(user, host, errcode, elapsed, config.get("theme", "default"), fmt))).strip()
                        except EOFError: runfc(config, "farewell"); sys.exit(0)
                        except KeyboardInterrupt: print(); continue
                        if not raw: continue

                        if raw == "!!":
                                if not history: fmt_error("no previous command"); continue
                                raw = history[-1]; print(f"\033[90m{raw}\033[0m")
                        raw = re.sub(r'\bsudo !!\b', lambda _: f"sudo {history[-1]}" if history else "sudo", raw)
                        history.append(raw)
                        if len(history) > 1 and history[-1] == history[-2]: history.pop()

                        bg = raw.endswith("&")
                        if bg: raw = raw[:-1].strip()
                        while raw.endswith("\\"):
                                raw = raw[:-1]
                                try: extra = input("... ").strip()
                                except (EOFError, KeyboardInterrupt): break
                                raw += " " + extra

                        parts = [expand_env(p) for p in raw.split()]
                        cmd_base = parts[0]
                        args = parts[1:]
                        bm = get_bookmarks()
                        if cmd_base in bm:
                                try: os.chdir(bm[cmd_base]); errcode = "0"
                                except Exception as e: fmt_error(str(e)); errcode = "1"
                                continue

                        if cmd_base in alias:
                                translated = alias[cmd_base]
                                for i, arg in enumerate(args): translated = translated.replace(f"${i + 1}", arg)
                                translated = translated.replace("$*", " ".join(args))
                                cmd_parts = [expand_env(p) for p in translated.split()]
                        else: cmd_parts = parts

                        ccmd = cmd_parts[0]
                        ccmar = cmd_parts[1:]
                        t0 = time.monotonic()

                        if ccmd == "cd":
                                if ccmar and ccmar[0] == "-": target = prev_dir
                                else: target = os.path.expanduser(ccmar[0] if ccmar else "~")
                                if not do_cd_fuzzy(target): fmt_error(f"cd: no such directory: {target}"); errcode = "1"
                                else: errcode = "0"
                        elif ccmd == "exit": runfc(config, "farewell"); sys.exit(0)
                        elif ccmd == "clear": do_clear(config); errcode = "0"
                        elif ccmd == "plugins": do_plugins(); errcode = "0"
                        elif ccmd == "help": do_help(alias); errcode = "0"
                        elif ccmd == "which": errcode = do_which(ccmar, alias)
                        elif ccmd in ("bookmark", "bm"): errcode = do_bookmark(ccmar)
                        elif ccmd == "daps":
                                result = do_daps_cmd(ccmar, base_config)
                                if result is None:
                                        reload_plugins(base_config); base_config = loadconf()
                                        config = load_local_conf(base_config)
                                        session = make_session(config.get("aliases", {}), config.get("theme", "default"))
                                        fmt_info("reloaded"); errcode = "0"
                                else:
                                        errcode = result
                                        config = load_local_conf(base_config)
                                        session = make_session(config.get("aliases", {}), config.get("theme", "default"))
                        elif ccmd in plugins:
                                try: errcode = str(plugins[ccmd].run(ccmar))
                                except Exception as e: fmt_error(f"plugin '{ccmd}' raised: {type(e).__name__}: {e}"); errcode = "1"
                        else:
                                if bg: run_bg(cmd_parts); errcode = "0"
                                else:
                                        try:
                                                result = subprocess.run(" ".join(cmd_parts), shell=True)
                                                errcode = str(result.returncode)
                                                if result.returncode == 127: suggest(ccmd, alias)
                                        except Exception as e: fmt_error(f"could not run command: {e}"); errcode = "1"

                        elapsed = time.monotonic() - t0
                        if elapsed < 0.1: elapsed = None
                except Exception as e: fmt_error(f"unexpected shell error: {type(e).__name__}: {e}")
