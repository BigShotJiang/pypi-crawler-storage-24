# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re

import requests

from .package import PackageBase

# Go Proxy API endpoints
GO_PKG_LATEST_VERSION_API_URL = "https://proxy.golang.org/{package_path}/@latest"

REQUEST_TIMEOUT = 10


class GoPackage(PackageBase):
    """Represents a Go module."""

    @classmethod
    def from_specification(package, spec: str) -> "GoPackage" | None:
        """Parse a Go module specification string into a Package object.

        Handles formats like:
        - 'mvdan.cc/sh' (Module path only)
        - 'mvdan.cc/sh@v1.3.0' (Module path with specific version)
        - 'mvdan.cc/sh/v3' (Module path with major version suffix)
        - 'mvdan.cc/sh/v3@v3.10.0' (Major suffix with version)
        - 'mvdan.cc/sh/v3/cmd/shfmt' (Submodule)
        - 'mvdan.cc/sh/v3/cmd/shfmt@v3.10.0' (Submodule with version)

        Args:
            package: The package specification string.

        Returns:
            A Package instance if parsing succeeds, otherwise None.
        """
        clean_spec = spec.strip().strip('"').strip("'")

        match = re.match(r"^([a-zA-Z0-9._/-]+)(@.+)?$", clean_spec)

        if not match:
            logging.warning(
                "Could not parse the Go package specification: %s", clean_spec
            )
            return None

        name = match.group(1)
        raw_spec = match.group(2)

        module_path = package._resolve_module_path(name)
        latest_version = package._fetch_latest_version(module_path)

        return package(
            name=name,
            raw_spec=raw_spec,
            latest_version=latest_version,
        )

    @staticmethod
    def _resolve_module_path(package_path: str) -> str:
        """
        Resolve a submodule path to a module path.

        If the path contains a major version suffix (e.g., /v2, /v3) followed by
        additional path segments, it trims the path at the suffix.

        Args:
            package_path: The full submodule path.

        Returns:
            The resolved module path.
        """

        match = re.search(r"/v([2-9]|[1-9][0-9]+)(?=/)", package_path)

        if match:
            return package_path[: match.end()]

        return package_path

    @staticmethod
    def _fetch_latest_version(package_path: str) -> str | None:
        """Fetch the latest version of a Go module from proxy.golang.org.

        Args:
            package_path: The module path (e.g., mvdan.cc/sh/v3).

        Returns:
            The latest version string (e.g., v3.10.0) if found, otherwise None.
        """
        logging.debug("Fetching latest version for %s", package_path)
        try:
            url = GO_PKG_LATEST_VERSION_API_URL.format(package_path=package_path)

            response = requests.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()

            data = response.json()
            version = data.get("Version")

            if isinstance(version, str):
                return version

            return None
        except requests.exceptions.RequestException as exc:
            logging.warning(
                "Could not fetch latest version for %s: %s", package_path, exc
            )
            return None
        except (KeyError, ValueError) as exc:
            logging.warning("Could not parse response for %s: %s", package_path, exc)
            return None

    def latest_version_specification(self) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            The latest version specification string if found, otherwise None.
        """
        if not self.latest_version:
            return None

        return f"{self.name}@{self.latest_version}"
