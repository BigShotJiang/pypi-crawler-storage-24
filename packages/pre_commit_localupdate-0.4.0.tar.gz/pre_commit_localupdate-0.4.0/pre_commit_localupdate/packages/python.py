# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re
from typing import cast

import requests

from .package import PackageBase

PYPI_API_URL = "https://pypi.org/pypi/{package_name}/json"
REQUEST_TIMEOUT = 10


class PyPackage(PackageBase):
    """Represents a Python package."""

    @classmethod
    def from_specification(package, spec: str) -> "PyPackage" | None:
        """Parse a package specification string into a Package object.

        Handles formats like 'ansible==13.3.0', 'ansible>=1.0', or just 'ansible'.

        Args:
            spec: The package specification string.

        Returns:
            A Package instance if parsing succeeds, otherwise None.

        """
        clean_spec = spec.strip().strip('"').strip("'")
        match = re.match(r"^([a-zA-Z0-9._-]+)([=<>!~]+.*)?$", clean_spec)
        if not match:
            logging.warning("Could not parse the package specification: %s", clean_spec)
            return None

        name = match.group(1)
        raw_spec = match.group(2)
        latest_version = package._get_latest_version(name)

        return package(
            name=name,
            raw_spec=raw_spec,
            latest_version=latest_version,
        )

    @staticmethod
    def _get_latest_version(package_name: str) -> str | None:
        """Fetch the latest version of a package from PyPI.

        Returns:
            The latest version string if found, otherwise None.

        """
        logging.debug("Fetching latest version for %s", package_name)
        try:
            url = PYPI_API_URL.format(package_name=package_name)
            response = requests.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json()
            version = data.get("info", {}).get("version")
            if version and isinstance(version, str):
                return cast("str", version)

            return None
        except requests.exceptions.RequestException as exc:
            logging.warning(
                "Could not fetch latest version for %s: %s", package_name, exc
            )
            return None
        except (KeyError, ValueError) as exc:
            logging.warning("Could not parse response for %s: %s", package_name, exc)
            return None

    def latest_version_specification(package) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            The latest version specification string if found, otherwise None.

        """
        if not package.latest_version:
            return None

        return f"{package.name}=={package.latest_version}"
