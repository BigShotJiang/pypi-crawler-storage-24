# LlamaIndex Tools: DocAPI

LlamaIndex tool spec for [DocAPI](https://docapi.com) — generate PDFs, screenshots, and invoices from your LlamaIndex agents.

## Installation

```bash
pip install llama-index-tools-docapi
```

## Usage

```python
from llama_index.tools.docapi import DocAPIToolSpec
from llama_index.core.agent import ReActAgent
from llama_index.llms.openai import OpenAI

tools = DocAPIToolSpec(api_key="your-docapi-key").to_tool_list()
agent = ReActAgent.from_tools(tools, llm=OpenAI(model="gpt-4o"))

agent.chat("Generate a PDF from this HTML: <h1>Hello World</h1>")
agent.chat(
    "Create an invoice from Acme Corp to Globex Inc for 10 widgets at $5 each"
)
```

## Tools

| Tool | Description |
|------|-------------|
| `generate_pdf` | Render HTML to PDF with full CSS support |
| `capture_screenshot` | Screenshot a URL or HTML as PNG |
| `generate_invoice` | Generate an invoice PDF from structured data |

## Documentation

- [DocAPI docs](https://docapi.com/docs)
- [DocAPI Python SDK](https://pypi.org/project/docapi/)
