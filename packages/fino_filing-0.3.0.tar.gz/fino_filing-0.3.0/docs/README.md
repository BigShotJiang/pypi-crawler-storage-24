# fino-filing Documentation (Docusaurus)

This site is built with [Docusaurus](https://docusaurus.io/).

## Structure

- **`docs/spec/`** — Specification (users): overview, quick start, API contract, scenarios
- **`docs/dev/`** — Development (contributors): design, testing, archive

Spec and dev are separate; both are available on the site. Add new docs under `spec/` or `dev/` depending on the audience.

## Installation

```bash
yarn
```

## Local Development

```bash
yarn start
```

This command starts a local development server and opens up a browser window. Most changes are reflected live without having to restart the server.

## Build

```bash
yarn build
```

This command generates static content into the `build` directory and can be served using any static contents hosting service.

## Deployment

Using SSH:

```bash
USE_SSH=true yarn deploy
```

Not using SSH:

```bash
GIT_USER=<Your GitHub username> yarn deploy
```

If you are using GitHub pages for hosting, this command is a convenient way to build the website and push to the `gh-pages` branch.
