from setuptools import setup, find_packages

setup(
    name="antarraksha-langchain",
    version="0.1.0",
    description="Antarraksha AI Agent Enforcement SDK for LangChain",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Akash Kumar Dey",
    author_email="akash@antarraksha.ai",
    url="https://github.com/antarraksha/antarraksha-langchain",
    packages=find_packages(),
    install_requires=[
        "langchain>=0.1.0",
        "requests>=2.28.0",
    ],
    python_requires=">=3.9",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Topic :: Security",
        "Topic :: Software Development :: Libraries",
    ],
    keywords="ai agent safety security enforcement langchain antarraksha",
)
