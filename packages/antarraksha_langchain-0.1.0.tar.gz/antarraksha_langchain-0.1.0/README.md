# antarraksha-langchain

Antarraksha AI Agent Enforcement SDK for LangChain.

## Installation

```bash
pip install antarraksha-langchain
```

## Quick Start

```python
from antarraksha_langchain import AntarakshaCallbackHandler

handler = AntarakshaCallbackHandler(
    base_url="https://antarraksha.ai",
    agent_id="my-agent",
    passport_id="ANTK-PASS-xxx",
)

# Every LLM and tool call is now enforced
from langchain_openai import ChatOpenAI
llm = ChatOpenAI(model="gpt-4o", callbacks=[handler])
```

## Tool Wrapping

```python
from langchain_community.tools import ShellTool
from antarraksha_langchain import AntarakshaSafeTool, AntarakshaClient

client = AntarakshaClient(agent_id="my-agent", passport_id="ANTK-PASS-xxx")
client.register()

safe_shell = AntarakshaSafeTool(wrapped_tool=ShellTool(), antarraksha_client=client)
# safe_shell.run("ls") — enforced by Antarraksha before execution
```
