"""OpenClaw vanilla installer - installs OpenClaw and starts the gateway."""

import os
import sys
import subprocess
import shutil
from pathlib import Path
from typing import Optional
from rich.console import Console

console = Console()

NODE_VERSION = "22.16.0"


def get_platform():
    """Get platform identifier."""
    if sys.platform == "win32":
        return "win"
    elif sys.platform == "darwin":
        return "darwin"
    else:
        return "linux"


def get_node_download_url(version: str) -> str:
    """Get download URL for Node.js."""
    platform = get_platform()
    if platform == "win":
        return f"https://nodejs.org/dist/v{version}/node-v{version}-win-x64.zip"
    elif platform == "darwin":
        return f"https://nodejs.org/dist/v{version}/node-v{version}-darwin-x64.tar.gz"
    else:
        return f"https://nodejs.org/dist/v{version}/node-v{version}-linux-x64.tar.xz"


def get_install_base() -> Path:
    """Get base installation directory (fully isolated)."""
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        return base / "openclaw-installer"
    else:
        xdg_data = os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")
        return Path(xdg_data) / "openclaw-installer"


def get_bin_dir() -> Path:
    """Get binary directory for wrapper scripts."""
    return get_install_base() / "bin"


class OpenClawInstaller:
    """Vanilla OpenClaw installer - installs and starts gateway."""

    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run
        self.node_bins = {}
        self.bin_dir = get_bin_dir()

    def install(self) -> bool:
        """Run vanilla installation."""
        console.print("")
        console.print("[bold blue]OpenClaw Vanilla Installer[/]")
        console.print("[dim]Installs OpenClaw and starts the gateway[/]")
        console.print("")

        if self.dry_run:
            console.print("[yellow]DRY RUN MODE - No changes will be made[/]")
            console.print("")

        steps = [
            ("Setting up Node.js", self._setup_node),
            ("Installing OpenClaw", self._install_openclaw),
            ("Creating wrapper", self._create_wrapper),
            ("Starting gateway", self._start_gateway),
        ]

        for name, step_func in steps:
            if not step_func():
                console.print(f"[red]Installation failed at: {name}[/]")
                return False

        self._print_success()
        return True

    def _setup_node(self) -> bool:
        """Ensure Node.js v22+ is available."""
        console.print("[dim]Setting up Node.js...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        install_base = get_install_base()
        node_dir = install_base / "node"

        # Check for already-downloaded Node.js
        if sys.platform == "win32":
            node_exe = node_dir / "node.exe"
            npm_exe = node_dir / "npm.cmd"
        else:
            node_exe = node_dir / "bin" / "node"
            npm_exe = node_dir / "bin" / "npm"

        if node_exe.exists():
            console.print(f" [green]OK[/] Using Node.js v{NODE_VERSION}")
            self.node_bins = {"node": node_exe, "npm": npm_exe, "system": False}
            return True

        # Download Node.js
        console.print(f" [dim]downloading v{NODE_VERSION}...[/]", end="")
        try:
            import urllib.request
            import tempfile

            url = get_node_download_url(NODE_VERSION)
            ext = ".zip" if sys.platform == "win32" else ".tar.gz" if sys.platform == "darwin" else ".tar.xz"

            with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
                urllib.request.urlretrieve(url, tmp.name)
                tmp_path = Path(tmp.name)

            # Extract
            node_dir.mkdir(parents=True, exist_ok=True)
            if sys.platform == "win32":
                import zipfile
                with zipfile.ZipFile(tmp_path, 'r') as z:
                    z.extractall(node_dir.parent)
                extracted = node_dir.parent / f"node-v{NODE_VERSION}-win-x64"
                if extracted.exists():
                    extracted.rename(node_dir)
            else:
                import tarfile
                with tarfile.open(tmp_path, 'r:*') as t:
                    t.extractall(node_dir.parent)
                extracted = node_dir.parent / f"node-v{NODE_VERSION}-{get_platform()}-x64"
                if extracted.exists():
                    extracted.rename(node_dir)

            tmp_path.unlink()

            if node_exe.exists():
                console.print(" [green]OK[/]")
                self.node_bins = {"node": node_exe, "npm": npm_exe, "system": False}
                return True
            else:
                console.print(" [red]FAIL (extraction failed)[/]")
                return False

        except Exception as e:
            console.print(f" [red]FAIL {e}[/]")
            return False

    def _install_openclaw(self) -> bool:
        """Install OpenClaw npm package."""
        console.print("[dim]Installing OpenClaw...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        install_base = get_install_base()
        npm_prefix = install_base / "openclaw"
        npm_prefix.mkdir(parents=True, exist_ok=True)

        node = str(self.node_bins["node"])
        npm = str(self.node_bins["npm"])
        node_dir = Path(node).parent

        # Find npm-cli.js for more reliable execution
        if sys.platform == "win32":
            npm_cli = node_dir.parent / "node_modules" / "npm" / "bin" / "npm-cli.js"
        else:
            npm_cli = node_dir.parent / "lib" / "node_modules" / "npm" / "bin" / "npm-cli.js"
        
        # Use npm-cli.js if available, otherwise fall back to npm command
        if npm_cli.exists():
            cmd = [node, str(npm_cli), "install", "--prefix", str(npm_prefix), "openclaw@latest"]
        else:
            cmd = [npm, "install", "--prefix", str(npm_prefix), "openclaw@latest"]

        try:
            # Set up environment with Node.js in PATH
            env = os.environ.copy()
            env["PATH"] = str(node_dir) + os.pathsep + env.get("PATH", "")
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
                env=env,
            )

            if result.returncode != 0:
                console.print(f" [red]FAIL[/]")
                if result.stderr:
                    console.print(f"[dim]{result.stderr[:500]}[/]")
                return False

            console.print(" [green]OK[/]")
            return True

        except Exception as e:
            console.print(f" [red]FAIL {e}[/]")
            return False

    def _create_wrapper(self) -> bool:
        """Create wrapper script for openclaw command."""
        console.print("[dim]Creating wrapper...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        self.bin_dir.mkdir(parents=True, exist_ok=True)

        install_base = get_install_base()
        node_path = install_base / "node" / ("node.exe" if sys.platform == "win32" else "bin/node")
        index_path = install_base / "openclaw" / "node_modules" / "openclaw" / "dist" / "index.js"

        if sys.platform == "win32":
            wrapper_path = self.bin_dir / "openclaw.cmd"
            wrapper_content = f'''@echo off
"{node_path}" "{index_path}" %*
'''
        else:
            wrapper_path = self.bin_dir / "openclaw"
            wrapper_content = f'''#!/bin/sh
exec "{node_path}" "{index_path}" "$@"
'''

        try:
            wrapper_path.write_text(wrapper_content)
            if sys.platform != "win32":
                wrapper_path.chmod(0o755)
            console.print(" [green]OK[/]")
            return True
        except Exception as e:
            console.print(f" [red]FAIL {e}[/]")
            return False

    def _start_gateway(self) -> bool:
        """Start the OpenClaw gateway."""
        console.print("[dim]Starting gateway...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        install_base = get_install_base()
        node_path = install_base / "node" / ("node.exe" if sys.platform == "win32" else "bin/node")
        index_path = install_base / "openclaw" / "node_modules" / "openclaw" / "dist" / "index.js"

        try:
            # Start gateway in background
            if sys.platform == "win32":
                subprocess.Popen(
                    [str(node_path), str(index_path), "gateway", "--port", "18789"],
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            else:
                subprocess.Popen(
                    [str(node_path), str(index_path), "gateway", "--port", "18789"],
                    start_new_session=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )

            # Wait a moment for it to start
            import time
            time.sleep(3)

            console.print(" [green]OK[/]")
            return True

        except Exception as e:
            console.print(f" [red]FAIL {e}[/]")
            return False

    def _print_success(self) -> None:
        """Print success message."""
        console.print("")
        console.print("[bold green]Installation Complete![/]")
        console.print("")
        console.print("OpenClaw is installed and the gateway is running.")
        console.print("")
        console.print("Next steps:")
        console.print("  1. Open dashboard: [bold]openclaw dashboard[/]")
        console.print("  2. Configure AI providers in the dashboard")
        console.print("")

        if sys.platform != "win32":
            console.print(f"Add to PATH: export PATH=\"{self.bin_dir}:$PATH\"")

    def uninstall(self) -> bool:
        """Uninstall OpenClaw."""
        console.print("")
        console.print("[bold blue]OpenClaw Uninstaller[/]")
        console.print("")

        if self.dry_run:
            console.print("[yellow]DRY RUN MODE - No changes will be made[/]")
            console.print("")

        steps = [
            ("Removing OpenClaw", self._uninstall_openclaw),
            ("Cleaning up Node.js", self._cleanup_node),
        ]

        for name, step_func in steps:
            if not step_func():
                console.print(f"[red]Uninstall failed at: {name}[/]")
                return False

        console.print("")
        console.print("[bold green]Uninstall Complete![/]")
        console.print("")
        return True

    def _uninstall_openclaw(self) -> bool:
        """Uninstall OpenClaw npm package."""
        console.print("[dim]Removing OpenClaw...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        try:
            install_base = get_install_base()
            openclaw_dir = install_base / "openclaw"
            if openclaw_dir.exists():
                shutil.rmtree(openclaw_dir)

            # Remove wrapper
            if sys.platform == "win32":
                wrapper = self.bin_dir / "openclaw.cmd"
            else:
                wrapper = self.bin_dir / "openclaw"

            if wrapper.exists():
                wrapper.unlink()

            console.print(" [green]OK[/]")
            return True
        except Exception as e:
            console.print(f" [red]FAIL {e}[/]")
            return False

    def _cleanup_node(self) -> bool:
        """Clean up Node.js installation."""
        console.print("[dim]Cleaning up Node.js...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        try:
            install_base = get_install_base()
            node_dir = install_base / "node"
            if node_dir.exists():
                shutil.rmtree(node_dir)

            console.print(" [green]OK[/]")
            return True
        except Exception as e:
            console.print(f" [red]FAIL {e}[/]")
            return False
