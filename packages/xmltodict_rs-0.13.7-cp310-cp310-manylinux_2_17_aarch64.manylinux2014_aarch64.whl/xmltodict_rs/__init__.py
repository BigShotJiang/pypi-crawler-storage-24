from .xmltodict_rs import *

__doc__ = xmltodict_rs.__doc__
if hasattr(xmltodict_rs, "__all__"):
    __all__ = xmltodict_rs.__all__