import setuptools

setuptools.setup(
    name="QAnglesKit",
    version="0.0.4.78",
    author="saipranay",
    author_email="info@cloudangles.com",
    description="QAngles Quantum Solution SDK",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),
    include_package_data=True,  # Include non-Python files
    package_data={
        "QAnglesKit": ["config.json"],  # Ensure config.json is included
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
    install_requires=[
        "requests",
        "pillow",
        "IPython"

    ],
    entry_points={
        "console_scripts": [
            "mypackage-cli=QAnglesKit.db_handler:main",  # Optional CLI command
        ],
    },
)
