from pysll import Constellation
from pysll.models import Object

if __name__ == "__main__":
    client = Constellation.from_env()
    cf = Object("id:XnlV5jO9OLW3")
    # cf = Object("id:bq9LA0aWLqbe")

    data = client.download_cloud_file(cf)
    breakpoint()
