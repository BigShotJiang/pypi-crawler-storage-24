"""Pure Python implementations for agents commands - no typer dependencies."""

from typing import cast
from pathlib import Path
from time import perf_counter
from machineconfig.scripts.python.helpers.helpers_agents.fire_agents_helper_types import AGENTS, HOST, PROVIDER
from machineconfig.scripts.python.helpers.helpers_agents.reasoning_capabilities import ReasoningEffort


def _split_and_chunk_prompts(raw_material: str, separator: str, tasks_per_prompt: int) -> list[str]:
    prompts = [piece for piece in raw_material.split(separator) if piece.strip() != ""]
    if not prompts:
        return []
    if tasks_per_prompt <= 0:
        raise ValueError("--agent-load must be a positive integer")
    if tasks_per_prompt >= len(prompts):
        print("No need to chunk prompts, as tasks_per_prompt >= total prompts.", f"({tasks_per_prompt} >= {len(prompts)})")
        return prompts
    print(f"Chunking {len(prompts)} prompts into groups of {tasks_per_prompt} rows/tasks each.")
    grouped: list[str] = []
    for idx in range(0, len(prompts), tasks_per_prompt):
        grouped.append(separator.join(prompts[idx : idx + tasks_per_prompt]))
    return grouped


def resolve_agents_output_dir(*, repo_root: Path, agents_dir: str | None, job_name: str | None) -> tuple[Path, str]:
    if agents_dir is None:
        from machineconfig.utils.accessories import randstr
        if job_name is None:
            job_name_resolved = randstr(6)
        else:
            job_name_resolved = job_name.strip()
        return Path(repo_root) / ".ai" / "agents" / job_name_resolved, job_name_resolved

    agents_dir_obj = Path(agents_dir).expanduser().resolve().absolute()
    if job_name is None:
        job_name_resolved = agents_dir_obj.name
    else:
        job_name_resolved = job_name.strip()
    return agents_dir_obj, job_name_resolved


def agents_create(
    agent: AGENTS,
    host: HOST,
    model: str | None,
    reasoning_effort: ReasoningEffort | None,
    provider: PROVIDER | None,
    context: str | None,
    context_path: str | None,
    separator: str,
    agent_load: int,
    prompt: str | None,
    prompt_path: str | None,
    job_name: str | None,
    join_prompt_and_context: bool,
    output_path: str | None,
    agents_dir: str | None,
) -> None:
    """Create agents layout file, ready to run."""
    from machineconfig.scripts.python.helpers.helpers_agents.fire_agents_help_launch import prep_agent_launch, get_agents_launch_layout
    from machineconfig.scripts.python.helpers.helpers_agents.fire_agents_load_balancer import chunk_prompts
    from machineconfig.utils.accessories import get_repo_root
    import json

    if agent != "codex" and reasoning_effort is not None:
        raise ValueError("--reasoning-effort is only supported for --agent codex")

    repo_root = get_repo_root(Path.cwd())
    if repo_root is None:
        raise RuntimeError("💥 Could not determine the repository root. Please run this script from within a git repository.")

    if agent == "codex":
        if provider is None:
            provider = "openai"
        elif provider != "openai":
            raise ValueError("Codex agent only works with openai provider.")

    print(f"Operating @ {repo_root}")

    agents_dir_obj, job_name_resolved = resolve_agents_output_dir(
        repo_root=repo_root,
        agents_dir=agents_dir,
        job_name=job_name,
    )
    if agents_dir is not None:
        if agents_dir_obj.exists():
            import shutil
            shutil.rmtree(agents_dir_obj)
    del job_name
    del agents_dir


    prompt_options = [prompt, prompt_path]
    provided_prompt = [opt for opt in prompt_options if opt is not None]
    if len(provided_prompt) != 1:
        raise ValueError("Exactly one of --prompt or --prompt-path must be provided")

    context_options = [context, context_path]
    provided_context = [opt for opt in context_options if opt is not None]
    if len(provided_context) > 1:
        raise ValueError("Provide at most one of --context or --context-path")


    if context is not None:
        prompt_material_re_splitted = _split_and_chunk_prompts(raw_material=context, separator=separator, tasks_per_prompt=agent_load)
        if not prompt_material_re_splitted:
            raise ValueError("Provided --context does not contain any non-empty task after splitting")
    else:
        if context_path is None:
            context_path_resolved = agents_dir_obj / "context.md"
        else:
            context_path_resolved = Path(context_path).expanduser().resolve()
        if not context_path_resolved.exists():
            raise ValueError(f"Path does not exist: {context_path_resolved}")

        if context_path_resolved.is_file():
            prompt_material_re_splitted = chunk_prompts(context_path_resolved, tasks_per_prompt=agent_load, joiner=separator)
        elif context_path_resolved.is_dir():
            files = sorted(
                (f for f in context_path_resolved.rglob("*") if f.is_file()),
                key=lambda path: str(path.relative_to(context_path_resolved)),
            )
            if not files:
                raise ValueError(f"No files found in directory: {context_path_resolved}")
            file_materials = [f.read_text(encoding="utf-8") for f in files]
            non_empty_materials = [material for material in file_materials if material.strip() != ""]
            if not non_empty_materials:
                raise ValueError(f"All files in directory are empty: {context_path_resolved}")
            if agent_load <= 0:
                raise ValueError("--agent-load must be a positive integer")
            if agent_load >= len(non_empty_materials):
                print("No need to chunk prompts, as tasks_per_prompt >= total prompts.", f"({agent_load} >= {len(non_empty_materials)})")
                prompt_material_re_splitted = non_empty_materials
            else:
                print(f"Chunking {len(non_empty_materials)} directory files into groups of {agent_load} rows/tasks each.")
                prompt_material_re_splitted = [
                    separator.join(non_empty_materials[idx : idx + agent_load])
                    for idx in range(0, len(non_empty_materials), agent_load)
                ]
        else:
            raise ValueError(f"Path is neither file nor directory: {context_path_resolved}")

    if prompt_path is not None:
        prompt_prefix = Path(prompt_path).read_text(encoding="utf-8")
    else:
        prompt_prefix = cast(str, prompt)

    agent_selected = agent
    prep_agent_launch(
        repo_root=repo_root,
        agents_dir=agents_dir_obj,
        prompts_material=prompt_material_re_splitted,
        join_prompt_and_context=join_prompt_and_context,
        prompt_prefix=prompt_prefix,
        machine=host,
        agent=agent_selected,
        model=model,
        reasoning_effort=reasoning_effort,
        provider=provider,
        job_name=job_name_resolved,
    )
    layoutfile = get_agents_launch_layout(session_root=agents_dir_obj)

    layout_output_path = Path(output_path) if output_path is not None else agents_dir_obj / "layout.json"
    layout_output_path.parent.mkdir(parents=True, exist_ok=True)
    layout_output_path.write_text(data=json.dumps(layoutfile, indent=4), encoding="utf-8")
    print(f"Created agents in {agents_dir_obj}")
    print(f"Created layout in {layout_output_path}")


def collect(agent_dir: str, output_path: str, separator: str, pattern: str | None) -> None:
    """Collect all material files from an agent directory and concatenate them."""
    if not Path(agent_dir).exists() or not Path(agent_dir).is_dir():
        raise ValueError(f"Agent directory does not exist or is not a directory: {agent_dir}")

    prompts_dir = Path(agent_dir) / "prompts"
    if not prompts_dir.exists():
        raise ValueError(f"Prompts directory not found: {prompts_dir}")

    material_files: list[Path] = []
    for agent_subdir in prompts_dir.iterdir():
        if pattern is None:
            if agent_subdir.is_dir() and agent_subdir.name.startswith("agent_"):
                material_file = agent_subdir / f"{agent_subdir.name}_material.txt"
                if material_file.exists():
                    material_files.append(material_file)
        else:
            if agent_subdir.is_dir():
                for material_file in agent_subdir.glob(pattern):
                    if material_file.is_file():
                        material_files.append(material_file)

    if not material_files:
        print("No material files found in the agent directory.")
        return
    print(f"Found {len(material_files)} material files. Concatenating...")
    for idx, a_file in enumerate(material_files):
        print(f"{idx+1}. {a_file}")
    material_files.sort(key=lambda x: int(x.parent.name.split("_")[-1]))
    concatenated_content: list[str] = []
    for material_file in material_files:
        content = material_file.read_text(encoding="utf-8")
        concatenated_content.append(content)
    result = separator.join(concatenated_content)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(result, encoding="utf-8")
    print(f"Concatenated material written to {output_path}")


def make_agents_command_template() -> None:
    """Create a template for fire agents."""
    from platform import system
    import machineconfig.scripts.python.helpers.helpers_agents as module

    if system() == "Linux" or system() == "Darwin":
        template_path = Path(module.__file__).parent / "templates/template.sh"
    elif system() == "Windows":
        template_path = Path(module.__file__).parent / "templates/template.ps1"
    else:
        raise ValueError(f"Unsupported OS: {system()}")

    from machineconfig.utils.accessories import get_repo_root
    repo_root = get_repo_root(Path.cwd())
    if repo_root is None:
        raise RuntimeError("💥 Could not determine the repository root. Please run this script from within a git repository.")

    save_path_root = repo_root / ".ai" / "agents"

    save_path_root.mkdir(parents=True, exist_ok=True)
    save_path_root.joinpath("template_fire_agents.sh").write_text(template_path.read_text(encoding="utf-8"), encoding="utf-8")
    print(f"Template bash script written to {save_path_root}")

    from machineconfig.scripts.python.ai.utils.generate_files import make_todo_files
    make_todo_files(
        pattern=".py", repo=str(repo_root), strategy="name", output_path=str(save_path_root / "files.md"), split_every=None, split_to=None
    )

    prompt_path = Path(module.__file__).parent / "templates/prompt.txt"
    save_path_root.joinpath("prompt.txt").write_text(prompt_path.read_text(encoding="utf-8"), encoding="utf-8")
    print(f"Prompt template written to {save_path_root}")


def init_config(
    root: str | None,
    frameworks: tuple[AGENTS, ...],
    include_common: bool,
    add_all_configs_to_gitignore: bool,
    add_lint_task: bool,
    add_config: bool,
    add_instructions: bool,
) -> None:
    """Initialize AI configurations in the current repository."""
    from machineconfig.scripts.python.ai.initai import add_ai_configs
    started_at = perf_counter()
    print("[init-config] Starting configuration")
    if root is None:
        repo_root = Path.cwd()
    else:
        repo_root = Path(root).expanduser().resolve()
    print(f"[init-config] Repository root input: {repo_root}")
    from typing import get_args
    if len(frameworks) > 0:
        selected_frameworks_list: list[AGENTS] = []
        for framework in frameworks:

            if framework not in get_args(AGENTS):
                raise ValueError(f"Unsupported framework: {framework}. The supported frameworks are: {', '.join(get_args(AGENTS))}")
            selected_frameworks_list.append(framework)
        selected_frameworks: tuple[AGENTS, ...] = tuple(dict.fromkeys(selected_frameworks_list))
        print(f"[init-config] Selected frameworks: {', '.join(selected_frameworks)}")
    else:
        raise ValueError("Provide at least one --framework option, or pass --all-frameworks")

    before_add_configs = perf_counter()
    print("[init-config] Running add_ai_configs")
    add_ai_configs(
        repo_root=repo_root,
        frameworks=selected_frameworks,
        include_common_scaffold=include_common,
        add_all_touched_configs_to_gitignore=add_all_configs_to_gitignore,
        add_vscode_task=add_lint_task,
        add_private_config=add_config,
        add_instructions=add_instructions,
    )
    add_configs_elapsed = perf_counter() - before_add_configs
    total_elapsed = perf_counter() - started_at
    print(f"[init-config] add_ai_configs finished in {add_configs_elapsed:.3f}s")
    print(f"[init-config] Completed in {total_elapsed:.3f}s")


# def main() -> None:
#     a = 2
#     del a
#     print(a)
