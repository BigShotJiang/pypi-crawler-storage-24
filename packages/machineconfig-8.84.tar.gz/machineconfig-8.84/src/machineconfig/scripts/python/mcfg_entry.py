"""Fast-loading CLI entry point using lazy imports.

Submodules are only imported when their commands are actually invoked, not at startup.
This makes `mcfg --help` much faster by avoiding loading heavy dependencies.
"""
from typing import Annotated
import typer
from machineconfig.scripts.python.enums import BACKENDS_LOOSE, BACKENDS_MAP


def fire(
    ctx: typer.Context,
    path: Annotated[str, typer.Argument(help="Path to the Python file to run")] = ".",
    function: Annotated[str | None, typer.Argument(help="Function to run")] = None,
    ve: Annotated[str, typer.Option("--ve", "-v", help="Virtual environment name")] = "",
    cmd: Annotated[bool, typer.Option("--cmd", "-B", help="Create a cmd fire command to launch the job asynchronously")] = False,
    debug: Annotated[bool, typer.Option("--debug", "-d", help="Enable debug mode")] = False,
    choose_function: Annotated[bool, typer.Option("--choose-function", "-c", help="Choose function interactively")] = False,
    loop: Annotated[bool, typer.Option("--loop", "-l", help="Infinite recursion (runs again after completion/interruption)")] = False,

    interactive: Annotated[bool, typer.Option("--interactive", "-i", help="Whether to run the job interactively using IPython")] = False,
    jupyter: Annotated[bool, typer.Option("--jupyter", "-j", help="Open in a jupyter notebook")] = False,
    marimo: Annotated[bool, typer.Option("--marimo", "-M", help="Open in a marimo notebook")] = False,
    streamlit: Annotated[bool, typer.Option("--streamlit", "-S", help="Run as streamlit app")] = False,

    module: Annotated[bool, typer.Option("--module", "-m", help="Launch the main file")] = False,
    script: Annotated[bool, typer.Option("--script", "-s", help="Launch as a script without fire")] = False,
    optimized: Annotated[bool, typer.Option("--optimized", "-O", help="Run the optimized version of the function")] = False,
    zellij_tab: Annotated[str | None, typer.Option("--zellij-tab", "-z", help="Open in a new zellij tab")] = None,
    submit_to_cloud: Annotated[bool, typer.Option("--submit-to-cloud", "-C", help="Submit to cloud compute")] = False,
    root_repo: Annotated[bool, typer.Option("--root-repo", "-r", help="Resolve and search from the repository root")] = False,
    remote: Annotated[bool, typer.Option("--remote", "-R", help="Launch on a remote machine")] = False,
    environment: Annotated[str, typer.Option("--environment", "-E", help="Choose ip, localhost, hostname or arbitrary url")] = "",
    holdDirectory: Annotated[bool, typer.Option("--holdDirectory", "-D", help="Hold current directory and avoid cd'ing to the script directory")] = False,
    PathExport: Annotated[bool, typer.Option("--PathExport", "-P", help="Augment the PYTHONPATH with repo root")] = False,
    git_pull: Annotated[bool, typer.Option("--git-pull", "-g", help="Start by pulling the git repo")] = False,
    watch: Annotated[bool, typer.Option("--watch", "-w", help="Watch the file for changes")] = False,
) -> None:
    """Fire and manage jobs."""
    from machineconfig.scripts.python.fire_jobs import fire as fire_impl
    fire_impl(ctx=ctx, path=path, function=function, ve=ve, cmd=cmd, interactive=interactive, debug=debug,
              choose_function=choose_function, loop=loop, jupyter=jupyter, marimo=marimo, module=module,
              script=script, optimized=optimized, zellij_tab=zellij_tab, submit_to_cloud=submit_to_cloud, root_repo=root_repo,
              remote=remote, streamlit=streamlit, environment=environment, holdDirectory=holdDirectory,
              PathExport=PathExport, git_pull=git_pull, watch=watch)


def croshell(
    path: Annotated[str | None, typer.Argument(help="path of file to read.")] = None,
    project_path: Annotated[str | None, typer.Option("--project", "-p", help="specify uv project to use")] = None,
    uv_with: Annotated[str | None, typer.Option("--uv-with", "-w", help="specify uv with packages to use")] = None,
    backend: Annotated[BACKENDS_LOOSE, typer.Option("--backend", "-b", help="specify the backend to use")] = "ipython",
    profile: Annotated[str | None, typer.Option("--profile", "-r", help="ipython profile to use, defaults to default profile.")] = None,
) -> None:
    """Cross-shell command execution."""
    from machineconfig.scripts.python.croshell import croshell as croshell_impl
    croshell_impl(path=path, project_path=project_path, uv_with=uv_with, backend=BACKENDS_MAP[backend], profile=profile)


def devops(ctx: typer.Context) -> None:
    """<d> DevOps related commands."""
    from machineconfig.scripts.python.devops import get_app as get_app_devops
    get_app_devops()(ctx.args, standalone_mode=not ctx.args)


def cloud(ctx: typer.Context) -> None:
    """<c> Cloud management commands."""
    from machineconfig.scripts.python.cloud import get_app as get_app_cloud
    get_app_cloud()(ctx.args, standalone_mode=not ctx.args)


def sessions(ctx: typer.Context) -> None:
    """<s> Session and layout management."""
    from machineconfig.scripts.python.sessions import get_app as get_app_sessions
    get_app_sessions()(ctx.args, standalone_mode=not ctx.args)


def agents(ctx: typer.Context) -> None:
    """<a> 🤖 AI Agents management commands."""
    from machineconfig.scripts.python.agents import get_app as get_app_agents
    get_app_agents()(ctx.args, standalone_mode=not ctx.args)


def utils(ctx: typer.Context) -> None:
    """<u> Utility commands."""
    from machineconfig.scripts.python.utils import get_app as get_app_utils
    get_app_utils()(ctx.args, standalone_mode=not ctx.args)



def get_app() -> typer.Typer:
    app = typer.Typer(help="MachineConfig CLI - Manage your machine configurations and workflows", no_args_is_help=True, add_help_option=True, add_completion=False)

    ctx_settings: dict[str, object] = {"allow_extra_args": True, "allow_interspersed_args": True, "ignore_unknown_options": True, "help_option_names": []}

    app.command(name="devops", help="<d> DevOps related commands", context_settings=ctx_settings)(devops)
    app.command(name="d", hidden=True, context_settings=ctx_settings)(devops)
    app.command(name="cloud", help="<c> Cloud management commands", context_settings=ctx_settings)(cloud)
    app.command(name="c", hidden=True, context_settings=ctx_settings)(cloud)
    app.command(name="sessions", help="<s> Session and layout management", context_settings=ctx_settings)(sessions)
    app.command(name="s", hidden=True, context_settings=ctx_settings)(sessions)
    app.command(name="agents", help="<a> 🤖 AI Agents management commands", context_settings=ctx_settings)(agents)
    app.command(name="a", hidden=True, context_settings=ctx_settings)(agents)
    app.command(name="utils", help="<u> Utility commands", context_settings=ctx_settings)(utils)
    app.command(name="u", hidden=True, context_settings=ctx_settings)(utils)

    app.command(name="fire", help="<f> Fire and manage jobs", no_args_is_help=False, context_settings={"allow_extra_args": True, "allow_interspersed_args": False})(fire)
    app.command(name="f", hidden=True, no_args_is_help=False, context_settings={"allow_extra_args": True, "allow_interspersed_args": False})(fire)
    app.command("croshell", no_args_is_help=False, help="<r> Cross-shell command execution")(croshell)
    app.command("r", no_args_is_help=False, hidden=True)(croshell)

    return app


def main() -> None:
    app = get_app()
    app()


if __name__ == "__main__":
    main()
