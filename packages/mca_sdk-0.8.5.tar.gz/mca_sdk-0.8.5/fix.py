lines = open('mca-prototype/sdk-examples/internal-agentic/agent_instrumented.py').readlines()
new_lines = []
for i, line in enumerate(lines):
    if i in [197, 198, 203, 204]:
        continue
    new_lines.append(line)
with open('mca-prototype/sdk-examples/internal-agentic/agent_instrumented.py', 'w') as f:
    f.writelines(new_lines)
