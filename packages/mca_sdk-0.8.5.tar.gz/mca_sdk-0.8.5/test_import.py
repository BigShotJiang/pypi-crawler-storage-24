import sys
sys.path.insert(0, "./mca-prototype")
from mca_sdk.autolog import autolog
print("Success")
