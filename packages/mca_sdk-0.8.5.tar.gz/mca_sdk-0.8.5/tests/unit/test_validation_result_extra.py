import pytest
from mca_sdk.validation.result import ValidationResult


def test_validation_result_valid():
    result = ValidationResult(is_valid=True)
    assert result.is_valid
    assert not result.missing_fields
    assert not result.errors
    assert str(result) == "Validation passed"


def test_validation_result_invalid():
    result = ValidationResult(is_valid=False, missing_fields=["foo"], errors=["foo is missing"])
    assert not result.is_valid
    assert result.missing_fields == ["foo"]
    assert result.errors == ["foo is missing"]
    assert str(result) == "Validation failed: foo is missing"


def test_validation_result_contradictory_state_raises():
    with pytest.raises(
        ValueError, match="ValidationResult with is_valid=True cannot have missing_fields or errors"
    ):
        ValidationResult(is_valid=True, missing_fields=["foo"])

    with pytest.raises(
        ValueError, match="ValidationResult with is_valid=True cannot have missing_fields or errors"
    ):
        ValidationResult(is_valid=True, errors=["some error"])
