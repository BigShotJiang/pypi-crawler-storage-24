# Test-only utilities for mca_sdk.security. Never import in production code.
import mca_sdk.security.secret_manager as _sm_module


def reset_secret_manager_for_testing() -> None:
    """Reset the SecretManagerClient singleton for test isolation.

    Clears the module-level singleton so each test starts fresh.
    Never import or use this function in production code.
    """
    _sm_module._singleton_client = None
