#!/usr/bin/env python3
"""
vssh-quic: QUIC-based high-speed file transfer
- UDP transport (no TCP overhead)
- Built-in multiplexing
- 0-RTT reconnection
- Same protocol as vssh but over QUIC
"""

import asyncio
import hashlib
import os
import sys
import time
import hmac as hmac_lib
from pathlib import Path
from typing import Optional

from aioquic.asyncio import connect, serve
from aioquic.asyncio.protocol import QuicConnectionProtocol
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.events import StreamDataReceived, HandshakeCompleted

# Configuration
SECRET = os.environ.get('VSSH_SECRET', '')
PORT = 48292  # Different from TCP vssh (48291)
CHUNK_SIZE = 1024 * 1024  # 1MB chunks

# ========== Authentication ==========
def compute_hmac(secret: str, timestamp: int) -> str:
    return hmac_lib.new(secret.encode(), str(timestamp).encode(), hashlib.sha256).hexdigest()[:32]

def generate_token() -> str:
    ts = int(time.time())
    h = compute_hmac(SECRET, ts)
    return f"hmac_{ts}_{h}"

def verify_token(token: str, secret: str) -> bool:
    if not token.startswith("hmac_"):
        return token == secret  # Plaintext fallback
    parts = token.split("_")
    if len(parts) != 3:
        return False
    try:
        ts = int(parts[1])
        if abs(time.time() - ts) > 60:
            return False
        expected = compute_hmac(secret, ts)
        return parts[2] == expected
    except Exception:
        return False

def file_hash(path: Path) -> str:
    md5 = hashlib.md5()
    with open(path, 'rb') as f:
        while chunk := f.read(8192):
            md5.update(chunk)
    return md5.hexdigest()

# ========== QUIC Client ==========
class VsshQuicClient(QuicConnectionProtocol):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._responses = {}
        self._events = {}

    def quic_event_received(self, event):
        if isinstance(event, StreamDataReceived):
            stream_id = event.stream_id
            if stream_id not in self._responses:
                self._responses[stream_id] = b''
            self._responses[stream_id] += event.data
            if event.end_stream:
                if stream_id in self._events:
                    self._events[stream_id].set()

    async def send_request(self, data: bytes) -> bytes:
        stream_id = self._quic.get_next_available_stream_id()
        self._events[stream_id] = asyncio.Event()
        self._responses[stream_id] = b''

        self._quic.send_stream_data(stream_id, data, end_stream=True)
        self.transmit()

        await self._events[stream_id].wait()
        return self._responses.pop(stream_id)

async def quic_put(host: str, local: str, remote: str) -> bool:
    """Upload file via QUIC with streaming"""
    path = Path(local)
    if not path.exists():
        print(f"Error: {local} not found")
        return False

    size = path.stat().st_size
    md5 = file_hash(path)

    config = QuicConfiguration(is_client=True)
    config.verify_mode = False

    try:
        async with connect(host, PORT, configuration=config, create_protocol=VsshQuicClient) as client:
            stream_id = client._quic.get_next_available_stream_id()
            client._events[stream_id] = asyncio.Event()
            client._responses[stream_id] = b''

            # Send header first
            header = f"PUT:{generate_token()}:{remote}:{size}:{md5}\n".encode()
            client._quic.send_stream_data(stream_id, header, end_stream=False)
            client.transmit()

            print(f'{path.name} ({size/1024/1024:.1f}MB) via QUIC')
            start = time.time()
            sent = 0

            # Stream file in chunks
            with open(path, 'rb') as f:
                while True:
                    chunk = f.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    is_last = (sent + len(chunk) >= size)
                    client._quic.send_stream_data(stream_id, chunk, end_stream=is_last)
                    client.transmit()
                    sent += len(chunk)

                    # Progress
                    pct = sent * 100 // size
                    speed = sent / (time.time() - start + 0.001) / 1024 / 1024
                    print(f'\r  ↑ {pct}% {speed:.1f}MB/s', end='', flush=True)

            # Wait for response
            await client._events[stream_id].wait()
            response = client._responses.pop(stream_id)

            elapsed = time.time() - start
            resp = response.decode().strip()

            print()
            if resp == 'OK' or resp == 'SKIP':
                speed = size / elapsed / 1024 / 1024 if elapsed > 0 else 0
                print(f'  Done {elapsed:.1f}s ({speed:.1f}MB/s)')
                return True
            else:
                print(f'  Error: {resp}')
                return False
    except Exception as e:
        print(f'Error: {e}')
        return False

async def quic_get(host: str, remote: str, local: str) -> bool:
    """Download file via QUIC"""
    config = QuicConfiguration(is_client=True)
    config.verify_mode = False

    try:
        async with connect(host, PORT, configuration=config, create_protocol=VsshQuicClient) as client:
            request = f"GET:{generate_token()}:{remote}\n".encode()

            print(f'Downloading {remote} via QUIC...')
            start = time.time()

            response = await client.send_request(request)

            # Parse response: OK:size:md5\ndata or ERROR
            if not response.startswith(b'OK:'):
                print(f'Error: {response.decode()}')
                return False

            newline = response.index(b'\n')
            header = response[:newline].decode()
            data = response[newline+1:]

            _, size, md5_exp = header.split(':')
            size = int(size)

            Path(local).parent.mkdir(parents=True, exist_ok=True)
            with open(local, 'wb') as f:
                f.write(data)

            elapsed = time.time() - start

            if file_hash(Path(local)) == md5_exp:
                speed = size / elapsed / 1024 / 1024 if elapsed > 0 else 0
                print(f'  Done {elapsed:.1f}s ({speed:.1f}MB/s)')
                return True
            else:
                print('  Hash mismatch!')
                return False
    except Exception as e:
        print(f'Error: {e}')
        return False

async def quic_ssh(host: str, cmd: str) -> tuple:
    """Execute command via QUIC"""
    config = QuicConfiguration(is_client=True)
    config.verify_mode = False

    try:
        async with connect(host, PORT, configuration=config, create_protocol=VsshQuicClient) as client:
            request = f"SSH:{generate_token()}:{cmd}\n".encode()
            response = await client.send_request(request)

            if response.startswith(b'OK:'):
                # OK:exit_code:output_len\noutput
                newline = response.index(b'\n')
                header = response[:newline].decode()
                output = response[newline+1:]
                _, code, _ = header.split(':')
                return int(code), output.decode()
            else:
                return 1, response.decode()
    except Exception as e:
        return 1, str(e)

# ========== QUIC Server ==========
class VsshQuicServer(QuicConnectionProtocol):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._buffer = {}
        self._header_parsed = {}
        self._files = {}  # stream_id -> file handle

    def quic_event_received(self, event):
        if isinstance(event, StreamDataReceived):
            stream_id = event.stream_id
            if stream_id not in self._buffer:
                self._buffer[stream_id] = b''
            self._buffer[stream_id] += event.data

            # Try to parse header and stream to file
            if stream_id not in self._header_parsed:
                if b'\n' in self._buffer[stream_id]:
                    asyncio.create_task(self.handle_stream_start(stream_id))

            if event.end_stream:
                asyncio.create_task(self.handle_stream_end(stream_id))

    async def handle_stream_start(self, stream_id: int):
        """Parse header and prepare file for streaming PUT"""
        data = self._buffer[stream_id]
        newline = data.index(b'\n')
        header = data[:newline].decode()
        body = data[newline+1:]

        parts = header.split(':')
        cmd = parts[0]
        token = parts[1]

        if not verify_token(token, SECRET):
            self._quic.send_stream_data(stream_id, b'AUTH\n', end_stream=True)
            self.transmit()
            return

        self._header_parsed[stream_id] = parts

        if cmd == 'PUT':
            rpath = ':'.join(parts[2:-2])
            p = Path(rpath)
            p.parent.mkdir(parents=True, exist_ok=True)
            self._files[stream_id] = open(p, 'wb')
            if body:
                self._files[stream_id].write(body)
            self._buffer[stream_id] = b''  # Clear buffer

    async def handle_stream_end(self, stream_id: int):
        """Finalize stream and send response"""
        if stream_id in self._files:
            # Write remaining buffer
            if self._buffer.get(stream_id):
                self._files[stream_id].write(self._buffer[stream_id])
            self._files[stream_id].close()
            del self._files[stream_id]

            parts = self._header_parsed.get(stream_id, [])
            if len(parts) >= 4:
                rpath = ':'.join(parts[2:-2])
                md5_exp = parts[-1]
                p = Path(rpath)

                if p.exists() and file_hash(p) == md5_exp:
                    print(f'[PUT] {rpath} ({p.stat().st_size} bytes)')
                    self._quic.send_stream_data(stream_id, b'OK\n', end_stream=True)
                else:
                    self._quic.send_stream_data(stream_id, b'HASH\n', end_stream=True)
                self.transmit()
        else:
            # Non-PUT commands
            data = self._buffer.pop(stream_id, b'')
            response = await self.process_request(data)
            self._quic.send_stream_data(stream_id, response, end_stream=True)
            self.transmit()

        self._buffer.pop(stream_id, None)
        self._header_parsed.pop(stream_id, None)

    async def process_request(self, data: bytes) -> bytes:
        try:
            # Find header end
            newline = data.index(b'\n')
            header = data[:newline].decode()
            body = data[newline+1:]

            parts = header.split(':')
            cmd = parts[0]
            token = parts[1]

            if not verify_token(token, SECRET):
                return b'AUTH\n'

            if cmd == 'PUT':
                # PUT:token:path:size:md5
                rpath = ':'.join(parts[2:-2])
                size = int(parts[-2])
                md5_exp = parts[-1]

                p = Path(rpath)

                # Check if exists with same hash
                if p.exists() and file_hash(p) == md5_exp:
                    return b'SKIP\n'

                # Write file
                p.parent.mkdir(parents=True, exist_ok=True)
                with open(p, 'wb') as f:
                    f.write(body)

                if file_hash(p) == md5_exp:
                    print(f'[PUT] {rpath} ({size} bytes)')
                    return b'OK\n'
                else:
                    return b'HASH\n'

            elif cmd == 'GET':
                rpath = ':'.join(parts[2:])
                p = Path(rpath)

                if not p.exists():
                    return b'NOTFOUND\n'

                size = p.stat().st_size
                md5 = file_hash(p)

                with open(p, 'rb') as f:
                    content = f.read()

                header = f'OK:{size}:{md5}\n'.encode()
                print(f'[GET] {rpath} ({size} bytes)')
                return header + content

            elif cmd == 'SSH':
                import subprocess
                cmdline = ':'.join(parts[2:])
                print(f'[SSH] {cmdline}')

                result = subprocess.run(cmdline, shell=True, capture_output=True, timeout=300)
                output = result.stdout + result.stderr
                header = f'OK:{result.returncode}:{len(output)}\n'.encode()
                return header + output

            else:
                return b'UNKNOWN\n'

        except Exception as e:
            return f'ERROR:{e}\n'.encode()

async def run_server():
    """Run QUIC server"""
    # Generate self-signed cert if not exists
    cert_file = Path.home() / '.vssh' / 'quic.crt'
    key_file = Path.home() / '.vssh' / 'quic.key'

    if not cert_file.exists():
        print("Generating self-signed certificate...")
        cert_file.parent.mkdir(exist_ok=True)
        os.system(f'openssl req -x509 -newkey rsa:2048 -keyout {key_file} -out {cert_file} -days 365 -nodes -subj "/CN=vssh-quic" 2>/dev/null')

    config = QuicConfiguration(is_client=False)
    config.load_cert_chain(str(cert_file), str(key_file))

    print(f"""
╔═══════════════════════════════════════╗
║  vssh-quic server                      ║
║  Port: {PORT} (UDP)                     ║
║  Protocol: QUIC                        ║
╚═══════════════════════════════════════╝
""")

    await serve('0.0.0.0', PORT, configuration=config, create_protocol=VsshQuicServer)
    await asyncio.Future()  # Run forever

# ========== CLI ==========
def main():
    if len(sys.argv) < 2:
        print("""vssh-quic: QUIC-based file transfer

Usage:
  vssh-quic put <local> <host>:<remote>   Upload file
  vssh-quic get <host>:<remote> <local>   Download file
  vssh-quic ssh <host> <command>          Run command
  vssh-quic server                        Start server

Environment:
  VSSH_SECRET   Authentication token
""")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == 'put':
        local, remote = sys.argv[2], sys.argv[3]
        host, rpath = remote.split(':', 1)
        success = asyncio.run(quic_put(host, local, rpath))
        sys.exit(0 if success else 1)

    elif cmd == 'get':
        remote, local = sys.argv[2], sys.argv[3]
        host, rpath = remote.split(':', 1)
        success = asyncio.run(quic_get(host, rpath, local))
        sys.exit(0 if success else 1)

    elif cmd == 'ssh':
        host, cmdline = sys.argv[2], ' '.join(sys.argv[3:])
        code, output = asyncio.run(quic_ssh(host, cmdline))
        print(output, end='')
        sys.exit(code)

    elif cmd == 'server':
        asyncio.run(run_server())

    else:
        print(f'Unknown command: {cmd}')
        sys.exit(1)

if __name__ == '__main__':
    main()
