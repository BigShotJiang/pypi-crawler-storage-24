#!/usr/bin/env python3
"""
vssh P2P: NAT hole-punching for direct peer-to-peer file transfer

Flow:
1. Both peers get external IP:port via STUN
2. Exchange addresses via VPN signaling
3. Simultaneous UDP hole-punch to establish direct path
4. Transfer file over established P2P connection
5. Connection closes, return to normal

Bypasses VPN relay for faster transfers between NAT peers.
"""

import socket
import subprocess
import threading
import time
import json
import hashlib
import hmac
import os
import ssl
import sys
import tempfile
from pathlib import Path

# ========== Configuration ==========
SECRET = os.environ.get('VSSH_SECRET', '')
VSSH_PORT = 48291
FORWARD_PORT_RANGE = (48300, 48350)

# ========== Port Forwarding via wire ==========
def get_relay_ip() -> str:
    """Get relay server IP from config"""
    config_path = Path.home() / '.mpop' / 'config.json'
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
            relays = config.get('relays', [])
            if relays:
                servers = config.get('servers', {})
                relay_name = relays[0]
                if relay_name in servers:
                    return servers[relay_name].get('ip', '')
    return os.environ.get('VSSH_RELAY', '127.0.0.1')  # Default v1

def request_port_forward(relay_ip: str, target_vpn_ip: str, target_port: int) -> tuple:
    """Request port forward on relay
    
    Returns: (forward_port, success) - the port on relay that forwards to target
    """
    # Use RPC to request port forward
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect((relay_ip, VSSH_PORT))
        
        auth = hashlib.sha256((SECRET + str(int(time.time()))).encode()).hexdigest()[:32]
        request = {
            'target_ip': target_vpn_ip,
            'target_port': target_port,
            'duration': 3600  # 1 hour max
        }
        payload = json.dumps(request).encode()
        
        sock.sendall(f"PORT_FORWARD:{auth}:{len(payload)}\n".encode())
        sock.sendall(payload)
        
        resp = sock.recv(256).decode().strip()
        sock.close()
        
        if resp.startswith('OK:'):
            forward_port = int(resp.split(':')[1])
            return (forward_port, True)
        else:
            print(f"Port forward failed: {resp}")
            return (0, False)
            
    except Exception as e:
        print(f"Port forward error: {e}")
        return (0, False)

def release_port_forward(relay_ip: str, forward_port: int) -> bool:
    """Release port forward on relay"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect((relay_ip, VSSH_PORT))
        
        auth = hashlib.sha256((SECRET + str(int(time.time()))).encode()).hexdigest()[:32]
        sock.sendall(f"PORT_FORWARD_RELEASE:{auth}:{forward_port}\n".encode())
        
        resp = sock.recv(64).decode().strip()
        sock.close()
        return resp == 'OK'
        
    except Exception as e:
        print(f"Release error: {e}")
        return False

# ========== STUN for external address ==========
STUN_SERVERS = [
    ('stun.l.google.com', 19302),
    ('stun1.l.google.com', 19302),
]

STUN_MAGIC_COOKIE = 0x2112A442

def stun_get_external(local_port: int = 0) -> tuple:
    """Get external IP:port using STUN"""
    import struct
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(3)
    
    if local_port:
        sock.bind(('0.0.0.0', local_port))
    
    transaction_id = os.urandom(12)
    msg = struct.pack('>HHI', 0x0001, 0, STUN_MAGIC_COOKIE) + transaction_id
    
    for stun_host, stun_port in STUN_SERVERS:
        try:
            sock.sendto(msg, (stun_host, stun_port))
            data, addr = sock.recvfrom(1024)
            
            if len(data) < 20:
                continue
                
            msg_type, msg_len, magic = struct.unpack('>HHI', data[:8])
            if msg_type != 0x0101 or magic != STUN_MAGIC_COOKIE:
                continue
            
            # Parse XOR-MAPPED-ADDRESS
            pos = 20
            while pos < len(data):
                if pos + 4 > len(data):
                    break
                attr_type, attr_len = struct.unpack('>HH', data[pos:pos+4])
                pos += 4
                
                if attr_type == 0x0020 and attr_len >= 8:  # XOR-MAPPED-ADDRESS
                    port = struct.unpack('>H', data[pos+2:pos+4])[0] ^ (STUN_MAGIC_COOKIE >> 16)
                    ip_bytes = bytes(b ^ c for b, c in zip(data[pos+4:pos+8], struct.pack('>I', STUN_MAGIC_COOKIE)))
                    ip = '.'.join(str(b) for b in ip_bytes)
                    local_port = sock.getsockname()[1]
                    sock.close()
                    return (ip, port, local_port)
                    
                pos += attr_len + (4 - attr_len % 4) % 4
                
        except Exception as e:
            continue
    
    sock.close()
    return (None, None, None)

# ========== Direct P2P Transfer ==========
class DirectTransfer:
    """Direct file transfer bypassing relay"""
    
    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port
        self.sock = None
        
    def connect(self) -> bool:
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(30)
            self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 16 * 1024 * 1024)
            self.sock.connect((self.host, self.port))
            return True
        except Exception as e:
            print(f"Connect failed: {e}")
            return False
    
    def send_file(self, path: Path, remote_path: str) -> bool:
        """Send file directly"""
        if not self.sock:
            return False
            
        size = path.stat().st_size
        md5 = hashlib.md5(open(path, 'rb').read()).hexdigest()
        
        # Send header
        auth = hashlib.sha256((SECRET + str(int(time.time()))).encode()).hexdigest()[:32]
        header = f"DIRECT_PUT:{auth}:{remote_path}:{size}:{md5}\n"
        self.sock.sendall(header.encode())
        
        resp = self.sock.recv(64).decode().strip()
        if resp != 'OK':
            print(f"Server rejected: {resp}")
            return False
        
        # Send file
        print(f"Sending {path.name} ({size/1024/1024:.1f}MB)...")
        start = time.time()
        sent = 0
        
        with open(path, 'rb') as f:
            while sent < size:
                chunk = f.read(1024 * 1024)  # 1MB chunks
                if not chunk:
                    break
                self.sock.sendall(chunk)
                sent += len(chunk)
                pct = sent * 100 // size
                speed = sent / (time.time() - start + 0.001) / 1024 / 1024
                print(f'\r  ↑ {pct}% {speed:.1f}MB/s', end='', flush=True)
        
        print()
        
        # Wait for confirmation
        resp = self.sock.recv(64).decode().strip()
        elapsed = time.time() - start
        
        if resp == 'OK':
            print(f"  Done {elapsed:.1f}s ({size/elapsed/1024/1024:.1f}MB/s)")
            return True
        else:
            print(f"  Failed: {resp}")
            return False
    
    def close(self):
        if self.sock:
            self.sock.close()
            self.sock = None

# ========== P2P Transfer with Port Forward ==========
def transfer_with_port_forward(local_path: str, target_vpn_ip: str, remote_path: str) -> bool:
    """Transfer file using port forward for direct connection
    
    1. Request port forward on relay
    2. Connect directly through forward
    3. Transfer file
    4. Release port forward
    """
    relay_ip = get_relay_ip()
    path = Path(local_path)
    
    if not path.is_file():
        print(f"Not a file: {local_path}")
        return False
    
    print(f"=== P2P Transfer: {path.name} -> {target_vpn_ip} ===")
    print(f"Relay: {relay_ip}")
    
    # Step 1: Request port forward
    print("1. Requesting port forward...")
    forward_port, success = request_port_forward(relay_ip, target_vpn_ip, VSSH_PORT)
    
    if not success:
        print("   Port forward not available, using direct VPN")
        # Fallback to regular vssh
        return False
    
    print(f"   Forward port: {forward_port}")
    
    try:
        # Step 2: Connect through forward
        print("2. Connecting through forward...")
        transfer = DirectTransfer(relay_ip, forward_port)
        
        if not transfer.connect():
            print("   Direct connect failed")
            return False
        
        # Step 3: Transfer
        print("3. Transferring...")
        success = transfer.send_file(path, remote_path)
        transfer.close()
        
        return success
        
    finally:
        # Step 4: Release port forward
        print("4. Releasing port forward...")
        release_port_forward(relay_ip, forward_port)
        print("   Done")

# ========== NAT Hole Punching ==========
def hole_punch_udp(peer_ip: str, peer_port: int, local_port: int, duration: int = 30) -> bool:
    """Perform UDP hole punching to open NAT

    Returns True if hole punch succeeded, False otherwise.
    The UDP socket is closed after punching - we use TCP for actual transfer.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    except OSError as e:
        pass  # Not available on all platforms
    sock.bind(('', local_port))
    sock.setblocking(False)

    peer = (peer_ip, peer_port)
    msg = b'PUNCH_VSSH'

    start = time.time()
    sent = recv = 0

    while time.time() - start < duration:
        try:
            sock.sendto(msg, peer)
            sent += 1
        except Exception:  pass  # TODO: log error

        try:
            data, addr = sock.recvfrom(1024)
            if data.startswith(b'PUNCH'):
                recv += 1
                if recv >= 3:
                    print(f"  Hole punch SUCCESS! {recv} packets from {addr}")
                    sock.close()
                    return True
        except BlockingIOError: pass
        except Exception:  pass  # TODO: log error

        time.sleep(0.05)

    print(f"  Hole punch FAILED: sent={sent}, recv={recv}")
    sock.close()
    return False


def tcp_simultaneous_open(peer_ip: str, peer_port: int, local_port: int, timeout: int = 30) -> socket.socket:
    """TCP simultaneous open - both sides connect at the same time

    After UDP hole punch, the NAT mapping is established.
    Both sides try TCP connect() simultaneously using the same ports.
    Returns connected TCP socket on success, None on failure.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    except OSError as e:
        pass  # TODO: log error
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    sock.bind(('', local_port))
    sock.settimeout(1)

    start = time.time()
    attempts = 0

    while time.time() - start < timeout:
        try:
            sock.connect((peer_ip, peer_port))
            # Connection established!
            sock.settimeout(60)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 16 * 1024 * 1024)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 16 * 1024 * 1024)
            print(f"  TCP connected after {attempts} attempts")
            return sock
        except socket.error as e:
            # EINPROGRESS, EALREADY, EISCONN are expected during simultaneous open
            attempts += 1
            if attempts % 10 == 0:
                print(f"  TCP connecting... ({attempts})")
            time.sleep(0.1)

    print(f"  TCP connect FAILED after {attempts} attempts")
    sock.close()
    return None



# ========== TLS Encryption for P2P ==========
_tls_cert_cache = {}

def _generate_ephemeral_cert():
    """Generate self-signed cert+key for TLS. Cached per process."""
    if 'cert' in _tls_cert_cache:
        return _tls_cert_cache['cert'], _tls_cert_cache['key']

    cert_file = tempfile.NamedTemporaryFile(suffix='.pem', delete=False)
    key_file = tempfile.NamedTemporaryFile(suffix='.key', delete=False)
    cert_file.close()
    key_file.close()

    subprocess.run([
        'openssl', 'req', '-x509', '-newkey', 'rsa:2048',
        '-keyout', key_file.name, '-out', cert_file.name,
        '-days', '1', '-nodes', '-subj', '/CN=vssh-p2p',
        '-batch'
    ], capture_output=True, timeout=10)

    _tls_cert_cache['cert'] = cert_file.name
    _tls_cert_cache['key'] = key_file.name
    return cert_file.name, key_file.name


def wrap_p2p_tls(sock: socket.socket, is_server: bool) -> ssl.SSLSocket:
    """Wrap a connected TCP socket with TLS encryption.

    After TCP simultaneous open, both sides need to agree who is TLS server/client.
    Convention: the side with the LOWER local port becomes TLS server.

    TLS provides:
    - Confidentiality: ChaCha20-Poly1305 or AES-256-GCM (negotiated)
    - Integrity: HMAC built into TLS record layer
    - Forward secrecy: Ephemeral ECDHE key exchange

    After TLS handshake, both sides verify shared secret via HMAC exchange.
    """
    if is_server:
        cert_file, key_file = _generate_ephemeral_cert()
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cert_file, key_file)
        # Prefer ChaCha20 for speed on non-AES-NI hardware
        try:
            ctx.set_ciphers('ECDHE+CHACHA20:ECDHE+AESGCM:@STRENGTH')
        except Exception as e:
            pass  # TODO: log error
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        tls_sock = ctx.wrap_socket(sock, server_side=True)
    else:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE  # Self-signed, verified by HMAC below
        try:
            ctx.set_ciphers('ECDHE+CHACHA20:ECDHE+AESGCM:@STRENGTH')
        except OSError as e:
            pass  # TODO: log error
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        tls_sock = ctx.wrap_socket(sock, server_hostname='vssh-p2p')

    return tls_sock


def verify_p2p_peer(tls_sock: ssl.SSLSocket, secret: str) -> bool:
    """Verify both sides share the same secret over TLS channel.

    Protocol:
    1. Both sides generate random nonce (16 bytes)
    2. Send HMAC(secret, nonce) + nonce
    3. Receive peer's HMAC + nonce
    4. Verify peer's HMAC matches

    This prevents MITM even with self-signed certs.
    """
    nonce = os.urandom(16)
    mac = hmac.new(secret.encode(), nonce, hashlib.sha256).digest()

    # Send our proof: 32 bytes HMAC + 16 bytes nonce = 48 bytes
    tls_sock.sendall(mac + nonce)

    # Receive peer's proof
    peer_data = b''
    while len(peer_data) < 48:
        chunk = tls_sock.recv(48 - len(peer_data))
        if not chunk:
            return False
        peer_data += chunk

    peer_mac = peer_data[:32]
    peer_nonce = peer_data[32:48]

    # Verify
    expected = hmac.new(secret.encode(), peer_nonce, hashlib.sha256).digest()
    return hmac.compare_digest(peer_mac, expected)


def p2p_tcp_connect(peer_ip: str, peer_port: int, local_port: int,
                    punch_duration: int = 600, encrypt: bool = True) -> socket.socket:
    """Full P2P TCP connection: UDP hole-punch then TCP simultaneous open + TLS

    Returns connected (and optionally TLS-encrypted) socket on success, None on failure.
    """
    # Step 1: UDP hole punch
    print(f"  Punching {peer_ip}:{peer_port} from local:{local_port}...")
    if not hole_punch_udp(peer_ip, peer_port, local_port, punch_duration):
        return None

    # Small delay for NAT state to stabilize
    time.sleep(0.1)

    # Step 2: TCP simultaneous open
    print(f"  TCP connecting...")
    sock = tcp_simultaneous_open(peer_ip, peer_port, local_port, timeout=30)
    if not sock:
        return None

    if not encrypt:
        return sock

    # Step 3: TLS encryption
    print(f"  Encrypting (TLS)...")
    try:
        # Determine TLS role: lower local port = server
        my_port = sock.getsockname()[1]
        peer_actual_port = sock.getpeername()[1]
        is_server = (my_port < peer_actual_port)

        tls_sock = wrap_p2p_tls(sock, is_server=is_server)

        # Show cipher info
        cipher = tls_sock.cipher()
        if cipher:
            print(f"  TLS: {cipher[1]} {cipher[0]}")

        # Step 4: Verify shared secret
        print(f"  Verifying peer...")
        if not verify_p2p_peer(tls_sock, SECRET):
            print(f"  PEER VERIFICATION FAILED — possible MITM attack!")
            tls_sock.close()
            return None

        print(f"  Encrypted + verified ✓")
        return tls_sock

    except Exception as e:
        print(f"  TLS handshake failed: {e}")
        sock.close()
        return None

def signal_exchange(peer_vpn_ip: str, my_external: tuple, relay_ip: str = None, timeout: int = 30) -> tuple:
    """Exchange external addresses via relay server (v1)

    Both peers register with v1, then query for each other.
    Returns peer's (external_ip, external_port, local_port) or (None, None, None)
    """
    import subprocess

    if not relay_ip:
        relay_ip = get_relay_ip()

    my_ip, my_port, my_local = my_external

    # Register our info with relay and request peer's info
    payload = json.dumps({
        'external_ip': my_ip,
        'external_port': my_port,
        'local_port': my_local,
        'peer_vpn_ip': peer_vpn_ip
    })

    # Try multiple times (peer may register after us)
    for attempt in range(timeout // 2):
        try:
            result = subprocess.run(
                ['python3', 'vssh.py', 'rpc', relay_ip, 'p2p_signal', payload],
                capture_output=True, text=True, timeout=5,
                env={**os.environ, 'VSSH_SECRET': SECRET}
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                if data.get('status') == 'peer_found':
                    return (data.get('external_ip'), data.get('external_port'), data.get('local_port'))
                # Peer not ready yet, wait and retry
                print(f"   Waiting for peer... ({attempt+1})")
                time.sleep(2)
        except Exception as e:
            print(f"   Signal error: {e}")
            time.sleep(2)

    return (None, None, None)

def p2p_transfer_tcp(local_path: str, peer_vpn_ip: str, remote_path: str,
                      peer_external: tuple = None, my_local_port: int = None) -> bool:
    """Transfer file via P2P TCP after hole punching

    Args:
        local_path: Local file path
        peer_vpn_ip: Peer's VPN IP for signaling (or ignored if peer_external given)
        remote_path: Remote destination path
        peer_external: (ip, port) if already known (skip signaling)
        my_local_port: Local port to use (if known from STUN)

    1. Get own external address (STUN)
    2. Exchange addresses with peer via VPN relay
    3. UDP hole punch to establish NAT mapping
    4. TCP simultaneous open for reliable transfer
    5. Transfer file over TCP
    """
    path = Path(local_path)
    if not path.is_file():
        print(f"Not a file: {local_path}")
        return False

    size = path.stat().st_size
    print(f"=== P2P TCP Transfer: {path.name} ({size/1024/1024:.1f}MB) -> {peer_vpn_ip} ===")

    # For large files (>10GB), skip pre-calc MD5 - verify after transfer
    if size > 10 * 1024 * 1024 * 1024:  # > 10GB
        print("  Large file - MD5 will be calculated during transfer")
        md5 = "STREAM"  # Signal to calculate during transfer
    elif size > 100 * 1024 * 1024:  # > 100MB
        print("  Calculating MD5 (streaming)...")
        md5_hash = hashlib.md5()
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(8 * 1024 * 1024), b''):
                md5_hash.update(chunk)
        md5 = md5_hash.hexdigest()
        print(f"  MD5: {md5[:16]}...")
    else:
        md5 = hashlib.md5(open(path, 'rb').read()).hexdigest()

    # Step 1: Get external address
    if not my_local_port:
        print("1. Getting external address (STUN)...")
        ext_ip, ext_port, my_local_port = stun_get_external()
        if not ext_ip:
            print("   STUN failed")
            return False
        print(f"   External: {ext_ip}:{ext_port} (local:{my_local_port})")
    else:
        ext_ip, ext_port, _ = stun_get_external(my_local_port)
        print(f"1. External: {ext_ip}:{ext_port} (local:{my_local_port})")

    # Step 2: Exchange with peer (or use provided)
    if peer_external:
        peer_ip, peer_port = peer_external
        print(f"2. Using provided peer: {peer_ip}:{peer_port}")
    else:
        print("2. Exchanging addresses with peer...")
        peer_ip, peer_port, peer_local = signal_exchange(
            peer_vpn_ip, (ext_ip, ext_port, my_local_port)
        )
        if not peer_ip:
            print("   Signaling failed")
            return False
        print(f"   Peer: {peer_ip}:{peer_port}")

    # Step 3: P2P TCP connect (UDP punch + TCP simultaneous open)
    print("3. Establishing P2P TCP connection...")
    sock = p2p_tcp_connect(peer_ip, peer_port, my_local_port)
    if not sock:
        print("   P2P connection failed")
        return False

    # Step 4: Transfer over TCP
    print("4. Transferring over TCP...")
    try:
        # Send file header
        header = f"P2P_PUT:{remote_path}:{size}:{md5}\n"
        sock.sendall(header.encode())

        # Wait for OK
        resp = sock.recv(64).decode().strip()
        if resp != 'OK':
            print(f"   Peer rejected: {resp}")
            sock.close()
            return False

        # Send file data (calculate MD5 during transfer for large files)
        start = time.time()
        sent = 0
        chunk_size = 1024 * 1024  # 1MB chunks for TCP
        md5_hash = hashlib.md5() if md5 == "STREAM" else None

        with open(path, 'rb') as f:
            while sent < size:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                sock.sendall(chunk)
                if md5_hash:
                    md5_hash.update(chunk)
                sent += len(chunk)

                pct = sent * 100 // size
                speed = sent / (time.time() - start + 0.001) / 1024 / 1024
                print(f'\r  ↑ {pct}% {speed:.1f}MB/s', end='', flush=True)

        print()

        # Send calculated MD5 for large files
        if md5_hash:
            calculated_md5 = md5_hash.hexdigest()
            sock.sendall(f"MD5:{calculated_md5}\n".encode())

        # Wait for checksum confirmation
        resp = sock.recv(64).decode().strip()
        elapsed = time.time() - start

        if resp == 'OK':
            print(f"  Done {elapsed:.1f}s ({size/elapsed/1024/1024:.1f}MB/s) ✓ checksum verified")
            sock.close()
            return True
        else:
            print(f"  FAILED: {resp}")
            sock.close()
            return False

    except Exception as e:
        print(f"  Transfer error: {e}")
        sock.close()
        return False


def p2p_receive_file(sock: socket.socket) -> bool:
    """Receive file from P2P TCP connection (server side)

    Called after P2P TCP connection is established.
    """
    try:
        # Read header line
        header = b''
        while not header.endswith(b'\n'):
            b = sock.recv(1)
            if not b:
                return False
            header += b

        header = header.decode().strip()
        if not header.startswith('P2P_PUT:'):
            sock.sendall(b'ERROR:INVALID_HEADER\n')
            return False

        parts = header.split(':')
        remote_path = parts[1]
        size = int(parts[2])
        expected_md5 = parts[3]
        stream_md5 = (expected_md5 == "STREAM")

        # Send OK
        sock.sendall(b'OK\n')

        # Receive file
        print(f"  Receiving {remote_path} ({size/1024/1024:.1f}MB)...")
        start = time.time()
        received = 0
        md5_hash = hashlib.md5()
        last_print = 0

        # Create temp file
        temp_path = Path(remote_path).with_suffix('.tmp')
        temp_path.parent.mkdir(parents=True, exist_ok=True)

        # Use larger buffer for faster receive
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 16 * 1024 * 1024)

        with open(temp_path, 'wb') as f:
            while received < size:
                # Larger recv buffer
                to_recv = min(4 * 1024 * 1024, size - received)
                chunk = sock.recv(to_recv)
                if not chunk:
                    break
                f.write(chunk)
                md5_hash.update(chunk)
                received += len(chunk)

                # Print every 5% or 500ms
                now = time.time()
                pct = received * 100 // size
                if pct >= last_print + 5 or now - start > 0.5:
                    speed = received / (now - start + 0.001) / 1024 / 1024
                    print(f'\r  ↓ {pct}% {speed:.1f}MB/s', end='', flush=True)
                    last_print = pct

        print()
        elapsed = time.time() - start

        # For stream MD5, receive the calculated hash from sender
        if stream_md5:
            md5_line = b''
            while not md5_line.endswith(b'\n'):
                b = sock.recv(1)
                if not b:
                    break
                md5_line += b
            expected_md5 = md5_line.decode().strip().split(':')[1]

        # Verify checksum
        actual_md5 = md5_hash.hexdigest()
        if actual_md5 != expected_md5:
            print(f"  Checksum MISMATCH: {actual_md5} vs {expected_md5}")
            sock.sendall(b'ERROR:CHECKSUM\n')
            temp_path.unlink()
            return False

        # Move to final path
        final_path = Path(remote_path)
        temp_path.rename(final_path)

        print(f"  Saved {final_path} ({size/elapsed/1024/1024:.1f}MB/s)")
        sock.sendall(b'OK\n')
        return True

    except Exception as e:
        print(f"  Receive error: {e}")
        sock.sendall(f'ERROR:{e}\n'.encode())
        return False

# ========== CLI ==========
def main():
    if len(sys.argv) < 2:
        print(__doc__)
        print("\nUsage:")
        print("  vssh_p2p.py stun                    Test STUN")
        print("  vssh_p2p.py punch <peer_ip> <peer_port> <local_port>  Manual hole punch")
        print("  vssh_p2p.py transfer <local> <host>:<remote>  P2P transfer")
        print("  vssh_p2p.py test                    Test P2P capability")
        return

    cmd = sys.argv[1]

    if cmd == 'stun':
        print("Testing STUN...")
        ext_ip, ext_port, local_port = stun_get_external()
        if ext_ip:
            print(f"External: {ext_ip}:{ext_port}")
            print(f"Local port: {local_port}")
            print("NAT type: Likely cone NAT (P2P possible)")
        else:
            print("STUN failed - symmetric NAT or blocked")

    elif cmd == 'punch':
        if len(sys.argv) < 5:
            print("Usage: vssh_p2p.py punch <peer_ip> <peer_port> <local_port>")
            return
        peer_ip = sys.argv[2]
        peer_port = int(sys.argv[3])
        local_port = int(sys.argv[4])
        print(f"Hole punching to {peer_ip}:{peer_port} from local:{local_port}")
        sock = hole_punch(peer_ip, peer_port, local_port)
        if sock:
            print("Connection established!")
            sock.close()
            sys.exit(0)
        else:
            sys.exit(1)

    elif cmd == 'p2p':
        # P2P TCP transfer with hole punching
        if len(sys.argv) < 4:
            print("Usage: vssh_p2p.py p2p <local_file> <vpn_ip>:<remote_path>")
            return
        local = sys.argv[2]
        remote = sys.argv[3]
        host, rpath = remote.split(':', 1)
        success = p2p_transfer_tcp(local, host, rpath)
        sys.exit(0 if success else 1)

    elif cmd == 'receive':
        # P2P receive mode - wait for incoming P2P connection
        if len(sys.argv) < 3:
            print("Usage: vssh_p2p.py receive <peer_external_ip>:<peer_port> [local_port]")
            return
        peer = sys.argv[2]
        peer_ip, peer_port = peer.split(':')
        peer_port = int(peer_port)
        local_port = int(sys.argv[3]) if len(sys.argv) > 3 else 0

        # Get STUN address
        print("Getting STUN address...")
        if local_port == 0:
            ext_ip, ext_port, local_port = stun_get_external()
        else:
            ext_ip, ext_port, _ = stun_get_external(local_port)

        if ext_ip:
            print(f"My external: {ext_ip}:{ext_port} (local:{local_port})")

        # P2P connect
        print(f"Connecting to {peer_ip}:{peer_port}...")
        sock = p2p_tcp_connect(peer_ip, peer_port, local_port)
        if sock:
            print("Connected! Waiting for file...")
            p2p_receive_file(sock)
            sock.close()
        else:
            print("Failed to connect")
            sys.exit(1)

    elif cmd == 'transfer':
        # Legacy port forward transfer
        if len(sys.argv) < 4:
            print("Usage: vssh_p2p.py transfer <local_file> <host>:<remote_path>")
            return
        local = sys.argv[2]
        remote = sys.argv[3]
        host, rpath = remote.split(':', 1)
        success = transfer_with_port_forward(local, host, rpath)
        sys.exit(0 if success else 1)

    elif cmd == 'direct':
        # Direct P2P transfer (skip signaling, use known peer address)
        # Usage: vssh_p2p.py direct <local_file> <peer_ext_ip>:<peer_ext_port> <local_port> <remote_path>
        if len(sys.argv) < 6:
            print("Usage: vssh_p2p.py direct <local_file> <peer_ext_ip>:<peer_ext_port> <local_port> <remote_path>")
            print("Example: vssh_p2p.py direct test.bin <router2-public-ip>:32777 57407 /tmp/test.bin")
            return
        local_file = sys.argv[2]
        peer_addr = sys.argv[3]
        peer_ip, peer_port = peer_addr.split(':')
        peer_port = int(peer_port)
        local_port = int(sys.argv[4])
        remote_path = sys.argv[5]

        success = p2p_transfer_tcp(local_file, peer_ip, remote_path,
                                   peer_external=(peer_ip, peer_port),
                                   my_local_port=local_port)
        sys.exit(0 if success else 1)

    elif cmd == 'test':
        print("Testing P2P capability...")
        print("\n1. STUN test:")
        ext_ip, ext_port, local_port = stun_get_external()
        if ext_ip:
            print(f"   OK: {ext_ip}:{ext_port} (local:{local_port})")
        else:
            print("   FAILED: Cannot determine external address")
            return

        print("\n2. Relay connectivity:")
        relay_ip = get_relay_ip()
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((relay_ip, VSSH_PORT))
            sock.close()
            print(f"   OK: {relay_ip}:{VSSH_PORT}")
        except OSError as e:
            print(f"   FAILED: Cannot connect to relay")
            return

        print("\nP2P ready!")
        print(f"\nTo send to peer:")
        print(f"  1. On peer: python3 vssh_p2p.py receive <your_ext_ip>:{ext_port} [their_local_port]")
        print(f"  2. On this machine: python3 vssh_p2p.py direct <file> <peer_ext_ip>:<peer_port> {local_port} <remote_path>")
    
    else:
        print(f"Unknown command: {cmd}")

if __name__ == '__main__':
    main()
