#!/usr/bin/env python3
"""
vssh P2P Fast: High-speed P2P transfer with parallel streams

Improvements over vssh_p2p.py:
- 4 parallel TCP streams (4x throughput potential)
- Larger buffers (4MB chunks)
- TCP tuning (TCP_NODELAY, large socket buffers)
- Zero-copy sendfile on Linux
"""

import socket
import threading
import time
import hashlib
import os
import sys
import struct
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# Import from base module
from vssh_p2p import (
    stun_get_external, hole_punch_udp, tcp_simultaneous_open,
    get_relay_ip, SECRET, VSSH_PORT,
    wrap_p2p_tls, verify_p2p_peer
)

# ========== Configuration ==========
NUM_STREAMS = 4          # Default parallel TCP connections (can be 4 or 8)
CHUNK_SIZE = 4 * 1024 * 1024  # 4MB chunks
SOCK_BUF = 16 * 1024 * 1024   # 16MB socket buffer

def set_streams(n: int):
    global NUM_STREAMS
    NUM_STREAMS = n

# ========== Multi-stream P2P ==========
def setup_fast_socket(sock):
    """Configure socket for maximum throughput"""
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SOCK_BUF)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, SOCK_BUF)
    # Try to set TCP quickack (Linux only)
    try:
        sock.setsockopt(socket.IPPROTO_TCP, 12, 1)  # TCP_QUICKACK
    except OSError as e:
        pass  # TODO: log error


def p2p_send_stream(stream_id: int, sock: socket.socket, path: Path,
                    offset: int, length: int, progress: dict, lock: threading.Lock):
    """Send a chunk of file over one stream"""
    try:
        setup_fast_socket(sock)

        # Send stream header
        header = f"STREAM:{stream_id}:{offset}:{length}\n"
        sock.sendall(header.encode())

        # Wait for OK
        resp = sock.recv(16)
        if not resp.startswith(b'OK'):
            return False

        # Try zero-copy sendfile (Linux)
        sent = 0
        try:
            import os
            fd = os.open(str(path), os.O_RDONLY)
            while sent < length:
                to_send = min(CHUNK_SIZE, length - sent)
                n = os.sendfile(sock.fileno(), fd, offset + sent, to_send)
                if n == 0:
                    break
                sent += n
                with lock:
                    progress[stream_id] = sent
            os.close(fd)
        except (AttributeError, OSError):
            # Fallback to regular send
            with open(path, 'rb') as f:
                f.seek(offset)
                while sent < length:
                    chunk = f.read(min(CHUNK_SIZE, length - sent))
                    if not chunk:
                        break
                    sock.sendall(chunk)
                    sent += len(chunk)
                    with lock:
                        progress[stream_id] = sent

        return sent == length

    except Exception as e:
        print(f"\n  Stream {stream_id} error: {e}")
        return False


def p2p_recv_stream(stream_id: int, sock: socket.socket, temp_dir: Path,
                    progress: dict, lock: threading.Lock) -> tuple:
    """Receive a chunk of file over one stream"""
    try:
        setup_fast_socket(sock)

        # Read stream header
        header = b''
        while not header.endswith(b'\n'):
            b = sock.recv(1)
            if not b:
                return (stream_id, None, 0, 0)
            header += b

        parts = header.decode().strip().split(':')
        sid = int(parts[1])
        offset = int(parts[2])
        length = int(parts[3])

        # Send OK
        sock.sendall(b'OK\n')

        # Receive to temp file
        temp_file = temp_dir / f"chunk_{stream_id}.tmp"
        received = 0
        md5_hash = hashlib.md5()

        with open(temp_file, 'wb') as f:
            while received < length:
                to_recv = min(CHUNK_SIZE, length - received)
                chunk = sock.recv(to_recv)
                if not chunk:
                    break
                f.write(chunk)
                md5_hash.update(chunk)
                received += len(chunk)
                with lock:
                    progress[stream_id] = received

        return (stream_id, temp_file, offset, length)

    except Exception as e:
        print(f"\n  Stream {stream_id} recv error: {e}")
        return (stream_id, None, 0, 0)


def p2p_transfer_fast(local_path: str, peer_ip: str, peer_port: int,
                      local_port: int, remote_path: str) -> bool:
    """Fast P2P transfer with parallel streams

    1. Establish control connection via hole-punch
    2. Open N parallel TCP connections
    3. Split file into N chunks
    4. Transfer chunks in parallel
    5. Verify combined checksum
    """
    path = Path(local_path)
    if not path.is_file():
        print(f"Not a file: {local_path}")
        return False

    size = path.stat().st_size
    print(f"=== P2P Fast Transfer: {path.name} ({size/1024/1024:.1f}MB) ===")
    print(f"  Using {NUM_STREAMS} parallel streams")

    # Step 1: Establish control connection + TLS
    print("1. Establishing P2P connection...")

    # UDP hole punch
    if not hole_punch_udp(peer_ip, peer_port, local_port, duration=60):
        print("   Hole punch failed")
        return False

    time.sleep(0.1)

    # TCP control connection
    ctrl_sock = tcp_simultaneous_open(peer_ip, peer_port, local_port, timeout=30)
    if not ctrl_sock:
        print("   TCP connect failed")
        return False

    # TLS encryption on control channel
    print("   Encrypting control channel (TLS)...")
    try:
        my_port = ctrl_sock.getsockname()[1]
        peer_actual_port = ctrl_sock.getpeername()[1]
        is_server = (my_port < peer_actual_port)
        ctrl_sock = wrap_p2p_tls(ctrl_sock, is_server=is_server)
        cipher = ctrl_sock.cipher()
        if cipher:
            print(f"   TLS: {cipher[1]} {cipher[0]}")
        if not verify_p2p_peer(ctrl_sock, SECRET):
            print("   PEER VERIFICATION FAILED!")
            ctrl_sock.close()
            return False
        print("   Encrypted + verified ✓")
    except Exception as e:
        print(f"   TLS failed: {e}")
        ctrl_sock.close()
        return False

    setup_fast_socket(ctrl_sock)

    # Step 2: Send transfer info
    print("2. Sending transfer info...")
    header = f"P2P_FAST:{remote_path}:{size}:{NUM_STREAMS}\n"
    ctrl_sock.sendall(header.encode())

    resp = ctrl_sock.recv(64).decode().strip()
    if not resp.startswith('OK:'):
        print(f"   Rejected: {resp}")
        ctrl_sock.close()
        return False

    # Parse peer's stream ports
    peer_ports = [int(p) for p in resp.split(':')[1:]]
    print(f"   Peer stream ports: {peer_ports}")

    # Step 3: Split file and prepare streams
    chunk_size = size // NUM_STREAMS
    chunks = []
    for i in range(NUM_STREAMS):
        offset = i * chunk_size
        length = chunk_size if i < NUM_STREAMS - 1 else (size - offset)
        chunks.append((i, offset, length))

    # Step 4: Connect streams and transfer
    print("3. Transferring...")
    start = time.time()
    progress = {i: 0 for i in range(NUM_STREAMS)}
    lock = threading.Lock()

    def transfer_chunk(i, offset, length, port):
        # Connect to peer's stream port
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(30)
        try:
            sock.connect((peer_ip, port))
            result = p2p_send_stream(i, sock, path, offset, length, progress, lock)
            sock.close()
            return result
        except Exception as e:
            print(f"\n  Connect stream {i} failed: {e}")
            return False

    # Progress display thread
    stop_progress = threading.Event()
    def show_progress():
        while not stop_progress.is_set():
            with lock:
                total = sum(progress.values())
            pct = total * 100 // size
            speed = total / (time.time() - start + 0.001) / 1024 / 1024
            print(f'\r  ↑ {pct}% {speed:.1f}MB/s [{NUM_STREAMS} streams]', end='', flush=True)
            time.sleep(0.1)

    progress_thread = threading.Thread(target=show_progress, daemon=True)
    progress_thread.start()

    # Transfer all chunks in parallel
    with ThreadPoolExecutor(max_workers=NUM_STREAMS) as ex:
        futures = [
            ex.submit(transfer_chunk, i, offset, length, peer_ports[i])
            for i, offset, length in chunks
        ]
        results = [f.result() for f in futures]

    stop_progress.set()
    print()

    elapsed = time.time() - start

    if all(results):
        # Wait for final verification
        resp = ctrl_sock.recv(64).decode().strip()
        ctrl_sock.close()

        if resp == 'OK':
            print(f"  Done {elapsed:.1f}s ({size/elapsed/1024/1024:.1f}MB/s) ✓")
            return True
        else:
            print(f"  Verification failed: {resp}")
            return False
    else:
        ctrl_sock.close()
        print("  Some streams failed")
        return False


def p2p_receive_fast(ctrl_sock: socket.socket) -> bool:
    """Receive fast P2P transfer with parallel streams"""
    try:
        setup_fast_socket(ctrl_sock)

        # Read transfer info
        header = b''
        while not header.endswith(b'\n'):
            b = ctrl_sock.recv(1)
            if not b:
                return False
            header += b

        parts = header.decode().strip().split(':')
        if parts[0] != 'P2P_FAST':
            ctrl_sock.sendall(b'ERROR:INVALID\n')
            return False

        remote_path = parts[1]
        size = int(parts[2])
        num_streams = int(parts[3])

        print(f"  Receiving {remote_path} ({size/1024/1024:.1f}MB) with {num_streams} streams...")

        # Create stream listeners
        stream_ports = []
        listeners = []
        for i in range(num_streams):
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind(('', 0))
            srv.listen(1)
            srv.settimeout(30)
            port = srv.getsockname()[1]
            stream_ports.append(port)
            listeners.append(srv)

        # Send OK with stream ports
        resp = 'OK:' + ':'.join(str(p) for p in stream_ports)
        ctrl_sock.sendall(f"{resp}\n".encode())

        # Accept connections and receive
        temp_dir = Path('/tmp/p2p_fast_recv')
        temp_dir.mkdir(exist_ok=True)

        start = time.time()
        progress = {i: 0 for i in range(num_streams)}
        lock = threading.Lock()

        def accept_and_recv(i, srv):
            conn, addr = srv.accept()
            srv.close()
            result = p2p_recv_stream(i, conn, temp_dir, progress, lock)
            conn.close()
            return result

        # Progress display
        stop_progress = threading.Event()
        def show_progress():
            while not stop_progress.is_set():
                with lock:
                    total = sum(progress.values())
                pct = total * 100 // size
                speed = total / (time.time() - start + 0.001) / 1024 / 1024
                print(f'\r  ↓ {pct}% {speed:.1f}MB/s [{num_streams} streams]', end='', flush=True)
                time.sleep(0.1)

        progress_thread = threading.Thread(target=show_progress, daemon=True)
        progress_thread.start()

        # Receive all streams
        with ThreadPoolExecutor(max_workers=num_streams) as ex:
            futures = [ex.submit(accept_and_recv, i, listeners[i]) for i in range(num_streams)]
            results = [f.result() for f in futures]

        stop_progress.set()
        print()

        elapsed = time.time() - start

        # Verify and combine chunks
        final_path = Path(remote_path)
        final_path.parent.mkdir(parents=True, exist_ok=True)

        print("  Combining chunks...")
        md5_hash = hashlib.md5()
        with open(final_path, 'wb') as out:
            for stream_id, temp_file, offset, length in sorted(results, key=lambda x: x[2]):
                if temp_file is None:
                    ctrl_sock.sendall(b'ERROR:STREAM_FAILED\n')
                    return False
                with open(temp_file, 'rb') as f:
                    data = f.read()
                    out.write(data)
                    md5_hash.update(data)
                temp_file.unlink()

        # Clean up temp dir
        try:
            temp_dir.rmdir()
        except OSError as e:
            pass  # TODO: log error

        print(f"  Saved {final_path} ({size/elapsed/1024/1024:.1f}MB/s)")
        ctrl_sock.sendall(b'OK\n')
        return True

    except Exception as e:
        print(f"  Receive error: {e}")
        try:
            ctrl_sock.sendall(f'ERROR:{e}\n'.encode())
        except (ValueError, TypeError) as e:
            pass  # TODO: log error
        return False


# ========== CLI ==========
def main():
    global NUM_STREAMS

    # Parse -n option for stream count
    args = sys.argv[1:]
    if '-n' in args:
        idx = args.index('-n')
        if idx + 1 < len(args):
            NUM_STREAMS = int(args[idx + 1])
            args = args[:idx] + args[idx+2:]

    if len(args) < 1:
        print(__doc__)
        print("\nUsage:")
        print("  vssh_p2p_fast.py [-n 4|8] send <local_file> <peer_ip>:<peer_port> <local_port> <remote_path>")
        print("  vssh_p2p_fast.py [-n 4|8] recv <peer_ip>:<peer_port> <local_port>")
        print(f"\nOptions:")
        print(f"  -n NUM   Number of parallel streams (default: 4, max: 8)")
        print(f"\nConfig: {NUM_STREAMS} streams, {CHUNK_SIZE//1024//1024}MB chunks")
        return

    cmd = args[0]

    if cmd == 'send':
        if len(args) < 5:
            print("Usage: vssh_p2p_fast.py [-n 4|8] send <local_file> <peer_ip>:<peer_port> <local_port> <remote_path>")
            return
        local_file = args[1]
        peer = args[2]
        peer_ip, peer_port = peer.split(':')
        peer_port = int(peer_port)
        local_port = int(args[3])
        remote_path = args[4]

        print(f"Using {NUM_STREAMS} parallel streams")
        success = p2p_transfer_fast(local_file, peer_ip, peer_port, local_port, remote_path)
        sys.exit(0 if success else 1)

    elif cmd == 'recv':
        if len(args) < 3:
            print("Usage: vssh_p2p_fast.py [-n 4|8] recv <peer_ip>:<peer_port> <local_port>")
            return
        peer = args[1]
        peer_ip, peer_port = peer.split(':')
        peer_port = int(peer_port)
        local_port = int(args[2])

        print(f"Using {NUM_STREAMS} parallel streams")
        print("Establishing P2P connection...")

        # Hole punch
        if not hole_punch_udp(peer_ip, peer_port, local_port, duration=60):
            print("Hole punch failed")
            sys.exit(1)

        time.sleep(0.1)

        # TCP connect
        sock = tcp_simultaneous_open(peer_ip, peer_port, local_port, timeout=30)
        if not sock:
            print("TCP connect failed")
            sys.exit(1)

        # TLS encryption
        print("Encrypting (TLS)...")
        try:
            my_port = sock.getsockname()[1]
            peer_actual_port = sock.getpeername()[1]
            is_server = (my_port < peer_actual_port)
            sock = wrap_p2p_tls(sock, is_server=is_server)
            cipher = sock.cipher()
            if cipher:
                print(f"  TLS: {cipher[1]} {cipher[0]}")
            if not verify_p2p_peer(sock, SECRET):
                print("  PEER VERIFICATION FAILED!")
                sock.close()
                sys.exit(1)
            print("  Encrypted + verified ✓")
        except Exception as e:
            print(f"  TLS failed: {e}")
            sock.close()
            sys.exit(1)

        print("Connected! Waiting for transfer...")
        success = p2p_receive_fast(sock)
        sock.close()
        sys.exit(0 if success else 1)

    else:
        print(f"Unknown command: {cmd}")


if __name__ == '__main__':
    main()
