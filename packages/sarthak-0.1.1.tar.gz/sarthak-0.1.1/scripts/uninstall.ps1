$ErrorActionPreference = "Stop"

$InstallDir = Join-Path $HOME ".sarthak_ai"
$BinDir = Join-Path $InstallDir "bin"
$Wrapper = Join-Path $BinDir "sarthak.ps1"
$TaskName = "SarthakOrchestrator"

schtasks /Delete /TN $TaskName /F | Out-Null

if (Test-Path $Wrapper) {
    Remove-Item $Wrapper -Force
}
if (Test-Path $InstallDir) {
    Remove-Item $InstallDir -Recurse -Force
}

Write-Host "Sarthak uninstalled."
