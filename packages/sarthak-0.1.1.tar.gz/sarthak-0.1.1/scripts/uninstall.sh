#!/usr/bin/env bash
# Sarthak AI — Uninstall (Linux/macOS)

set -euo pipefail

INSTALL_DIR="$HOME/.sarthak_ai"
WRAPPER="$HOME/.local/bin/sarthak"
ORCHESTRATOR_SERVICE_NAME="sarthak-orchestrator"
SYSTEMD_USER_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
PLIST_AW="$HOME/Library/LaunchAgents/com.sarthak.activitywatch.plist"
PLIST_ORCH="$HOME/Library/LaunchAgents/com.sarthak.orchestrator.plist"

if [[ "$(uname -s)" == "Linux" ]]; then
    for svc in "$ORCHESTRATOR_SERVICE_NAME"; do
        systemctl --user stop "$svc" 2>/dev/null || true
        systemctl --user disable "$svc" 2>/dev/null || true
        rm -f "$SYSTEMD_USER_DIR/$svc.service"
    done
    systemctl --user daemon-reload 2>/dev/null || true
fi

if [[ "$(uname -s)" == "Darwin" ]]; then
    launchctl unload "$PLIST_AW"   >/dev/null 2>&1 || true
    launchctl unload "$PLIST_ORCH" >/dev/null 2>&1 || true
    rm -f "$PLIST_AW" "$PLIST_ORCH"
fi

rm -f "$WRAPPER"
rm -rf "$INSTALL_DIR"

echo "Sarthak uninstalled."
