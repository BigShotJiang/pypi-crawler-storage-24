# Sarthak AI — Windows installer
#
# Latest release:
#   irm https://raw.githubusercontent.com/1bharath-yadav/sarthak/main/scripts/install.ps1 | iex
#
# Specific version:
#   $env:RELEASE_TAG="v0.2.0"
#   irm https://raw.githubusercontent.com/1bharath-yadav/sarthak/main/scripts/install.ps1 | iex
#
# This file is a thin redirect to scripts/install.ps1.

$script = (Invoke-RestMethod "https://raw.githubusercontent.com/1bharath-yadav/sarthak/main/scripts/install.ps1")
Invoke-Expression $script
