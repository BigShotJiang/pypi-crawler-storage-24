#!/usr/bin/env bash
# Build optimized standalone binary with Nuitka

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="$PROJECT_ROOT/dist"

python -m nuitka \
  --onefile \
  --assume-yes-for-downloads \
  --follow-imports \
  --include-package=sarthak \
  --output-dir="$DIST_DIR" \
  -m sarthak.cli \
  --output-filename=sarthak

echo "Binary written to $DIST_DIR"
