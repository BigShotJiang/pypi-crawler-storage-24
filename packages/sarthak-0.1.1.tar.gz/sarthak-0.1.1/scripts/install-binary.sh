#!/usr/bin/env bash
# Sarthak AI — curl installer (Linux/macOS)
#
# Latest release:
#   curl -fsSL https://raw.githubusercontent.com/1bharath-yadav/sarthak/main/scripts/install.sh | bash
#
# Specific version:
#   RELEASE_TAG=v0.2.0 curl -fsSL https://raw.githubusercontent.com/1bharath-yadav/sarthak/main/scripts/install.sh | bash
#
# This file is a thin redirect. The real installer is scripts/install.sh.
# It auto-detects RELEASE_TAG and falls back to the main branch tarball.

exec bash <(curl -fsSL https://raw.githubusercontent.com/1bharath-yadav/sarthak/main/scripts/install.sh) "$@"
