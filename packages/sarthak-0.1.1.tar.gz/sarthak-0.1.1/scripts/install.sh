#!/usr/bin/env bash
# Sarthak AI — Installer (Linux/macOS)
# Installs to ~/.sarthak_ai.
#
# Modes (mutually exclusive, checked in order):
#   LOCAL_INSTALL=1   — use the repo you're already sitting in (dev)
#   RELEASE_TAG=vX.Y  — install that version from PyPI
#   (default)         — pull HEAD of REPO_BRANCH from GitHub

set -euo pipefail

REPO_URL="https://github.com/1bharath-yadav/sarthak"
REPO_BRANCH="${REPO_BRANCH:-main}"
RELEASE_TAG="${RELEASE_TAG:-}"
INSTALL_DIR="$HOME/.sarthak_ai"
CONFIG_FILE="$INSTALL_DIR/config.toml"
SECRETS_FILE="$INSTALL_DIR/secrets.toml"
MASTER_KEY_FILE="$INSTALL_DIR/master.key"
export MASTER_KEY_FILE
DATA_DIR="$INSTALL_DIR/data"
ORCHESTRATOR_SERVICE_NAME="sarthak-orchestrator"
SYSTEMD_USER_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"

OR='\033[38;5;214m'; CY='\033[38;5;87m'; GR='\033[38;5;82m'
YL='\033[38;5;227m'; RD='\033[38;5;196m'; BD='\033[1m'; RS='\033[0m'

hdr()  { echo -e "\n${OR}${BD}:: ${1}${RS}"; }
ok()   { echo -e "  ${GR}+${RS} $*"; }
info() { echo -e "  ${CY}>${RS} $*"; }
warn() { echo -e "  ${YL}!${RS} $*"; }
fail() { echo -e "  ${RD}x${RS} $*"; exit 1; }
step() { echo -e "\n${CY}${BD}[${1}/${TOTAL_STEPS}]${RS} ${BD}${2}${RS}"; }

require_cmd() { command -v "$1" &>/dev/null || fail "Missing dependency: $1"; }

OS_NAME="$(uname -s)"
[[ "$OS_NAME" == "Linux" || "$OS_NAME" == "Darwin" ]] \
    || fail "Unsupported OS ($OS_NAME). Use scripts/install.ps1 on Windows."

TOTAL_STEPS=7

clear
hdr "Sarthak AI Installer"

require_cmd curl

if ! command -v uv &>/dev/null; then
    info "uv not found — installing"
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
    command -v uv &>/dev/null || fail "uv install failed"
    ok "uv installed"
fi

[[ "$OS_NAME" == "Linux" ]] && require_cmd systemctl

# ── Step 1: Install / upgrade sarthak ────────────────────────────────────────
step 1 "Installing sarthak"
mkdir -p "$INSTALL_DIR" "$DATA_DIR"

if [[ "${LOCAL_INSTALL:-}" == "1" ]]; then
    # Dev mode — sync from the repo you're running this script from.
    # Run as: LOCAL_INSTALL=1 bash scripts/install.sh
    SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.."; pwd)"
    info "Local install from $SRC_DIR"
    require_cmd rsync
    [[ -f "$CONFIG_FILE" ]] && cp "$CONFIG_FILE" "$CONFIG_FILE.bak"
    rsync -a --exclude '.git' --exclude '.venv' --exclude '__pycache__' \
          --exclude 'node_modules' --exclude '*.egg-info' \
          "$SRC_DIR/" "$INSTALL_DIR/"
    [[ -f "$CONFIG_FILE.bak" ]] && mv "$CONFIG_FILE.bak" "$CONFIG_FILE"
    cd "$INSTALL_DIR"
    VIRTUAL_ENV="$INSTALL_DIR/.venv" uv sync --all-extras
    ok "Installed from local source ($SRC_DIR)"

elif [[ -n "$RELEASE_TAG" ]]; then
    # Tagged release → install from PyPI
    info "Installing sarthak==${RELEASE_TAG#v} from PyPI"
    uv venv "$INSTALL_DIR/.venv" --python 3.11
    uv pip install --python "$INSTALL_DIR/.venv/bin/python" \
        "sarthak==${RELEASE_TAG#v}" --extra cloud
    ok "Installed from PyPI"

else
    # Default — pull HEAD of branch from GitHub
    require_cmd rsync
    TMP_DIR="$(mktemp -d)"
    TARBALL_URL="https://codeload.github.com/1bharath-yadav/sarthak/tar.gz/refs/heads/$REPO_BRANCH"
    SRC_DIR="$TMP_DIR/sarthak-$REPO_BRANCH"
    info "Fetching $TARBALL_URL"
    curl -fsSL "$TARBALL_URL" | tar -xz -C "$TMP_DIR"
    [[ -d "$SRC_DIR" ]] || fail "Download failed — expected $SRC_DIR"
    [[ -f "$CONFIG_FILE" ]] && cp "$CONFIG_FILE" "$CONFIG_FILE.bak"
    rsync -a --exclude '.git' --exclude '.venv' --exclude '__pycache__' \
          --exclude 'node_modules' "$SRC_DIR/" "$INSTALL_DIR/"
    [[ -f "$CONFIG_FILE.bak" ]] && mv "$CONFIG_FILE.bak" "$CONFIG_FILE"
    cd "$INSTALL_DIR"
    VIRTUAL_ENV="$INSTALL_DIR/.venv" uv sync --all-extras
    ok "Installed from GitHub ($REPO_BRANCH)"
fi

# ── Step 2: Master key & secrets ─────────────────────────────────────────────
step 2 "Configuring master key and secrets"
if [[ ! -f "$MASTER_KEY_FILE" ]]; then
    "$INSTALL_DIR/.venv/bin/python" - <<'PY'
import base64, os
from pathlib import Path
kp = Path(os.environ["MASTER_KEY_FILE"])
kp.parent.mkdir(parents=True, exist_ok=True)
kp.write_text(base64.b64encode(os.urandom(32)).decode() + "\n")
os.chmod(kp, 0o600)
PY
    ok "Master key generated"
fi
if [[ ! -f "$SECRETS_FILE" ]]; then
    touch "$SECRETS_FILE" && chmod 600 "$SECRETS_FILE"
    ok "Secrets file created"
fi

# ── Step 3: Interactive wizard ────────────────────────────────────────────────
step 3 "Interactive configuration"
if [[ "${SKIP_WIZARD:-}" == "true" ]]; then
    warn "Wizard skipped (SKIP_WIZARD=true) — run 'sarthak configure' later"
else
    info "Launching wizard (Ctrl-C to skip)"
    "$INSTALL_DIR/.venv/bin/python" -m sarthak.cli configure --mode full </dev/tty
fi

# ── Step 4: Patch config.toml ─────────────────────────────────────────────────
step 4 "Finalizing config.toml"
CONFIG_FILE="$CONFIG_FILE" DATA_DIR="$DATA_DIR" "$INSTALL_DIR/.venv/bin/python" - <<'PY'
import os
from pathlib import Path
import tomlkit

config_file = Path(os.environ["CONFIG_FILE"])
data_dir = os.environ["DATA_DIR"]

cfg = tomlkit.parse(config_file.read_text()) if config_file.exists() else tomlkit.document()

def _tbl(cfg, key):
    if key not in cfg or not isinstance(cfg[key], dict):
        cfg[key] = tomlkit.table()
    return cfg[key]

g = _tbl(cfg, "general")
g["data_dir"] = data_dir

ai = _tbl(cfg, "ai")
ai.setdefault("default_provider", "github-models")
ai.setdefault("default_model", "gpt-4o")

def _ai_sub(key, defaults):
    t = ai.get(key, tomlkit.table())
    ai[key] = t
    for k, v in defaults.items():
        if k not in t:
            t[k] = v

_ai_sub("github-models", {"base_url": "https://models.inference.ai.azure.com", "text_model": "gpt-4o", "vision_model": "gpt-4o", "timeout": 30})
_ai_sub("ollama",         {"base_url": "http://localhost:11434/v1", "text_model": "gemma3:4b", "vision_model": "qwen3-vl", "timeout": 60})
_ai_sub("openai",         {"model": "gpt-4o-mini", "base_url": "", "timeout": 30})
_ai_sub("gemini",         {"model": "gemini-2.0-flash", "timeout": 30})
_ai_sub("anthropic",      {"model": "claude-3-5-haiku-20241022", "timeout": 30})
_ai_sub("openrouter",     {"model": "anthropic/claude-3.5-sonnet", "timeout": 30, "app_url": "https://github.com/1bharath-yadav/sarthak", "app_title": "Sarthak AI"})
_ai_sub("grok",           {"model": "grok-2", "timeout": 30, "base_url": "https://api.x.ai/v1"})
_ai_sub("huggingface",    {"model": "Qwen/Qwen2.5-Coder-32B-Instruct", "timeout": 30})
_ai_sub("custom",         {"compat": "openai", "base_url": "", "model": "gpt-4o-mini", "timeout": 30})
_ai_sub("fallback",       {"fallback1_provider": "github-models", "fallback1_model": "gpt-4o-mini", "fallback2_provider": "ollama", "fallback2_model": "gemma3:4b"})
_ai_sub("classify",       {"provider": "github-models", "model": "gpt-4o", "categories": ["coding", "browsing", "reading", "communication", "design", "debugging", "research", "admin", "idle", "unknown"]})
_ai_sub("cache",          {"enabled": True, "ttl_seconds": 3600, "cache_dir": f"{data_dir}/cache"})

w = _tbl(cfg, "web")
w.setdefault("enabled", True); w.setdefault("host", "127.0.0.1"); w.setdefault("port", 4848)

e = _tbl(cfg, "encryption")
e.setdefault("enabled", True); e.setdefault("algorithm", "AES-GCM")

t = _tbl(cfg, "tui")
t.setdefault("refresh_interval", 5); t.setdefault("theme", "tokyo")
t.setdefault("max_event_rows", 200); t.setdefault("font", "JetBrainsMono Nerd Font")

m = _tbl(cfg, "mcp")
m.setdefault("enabled", True); m.setdefault("transport", "stdio")

n = _tbl(cfg, "notifications")
n.setdefault("provider", "dunst"); n.setdefault("enabled", True)
n.setdefault("idle_coding_alert_minutes", 120)
n.setdefault("work_hours_start", "09:00"); n.setdefault("work_hours_end", "22:00")

tg = _tbl(cfg, "telegram")
tg.setdefault("enabled", False); tg.setdefault("timeout_seconds", 60)

config_file.write_text(tomlkit.dumps(cfg))
PY
ok "config.toml patched"

# ── Step 5: CLI wrapper ───────────────────────────────────────────────────────
step 5 "Installing CLI wrapper"
mkdir -p "$HOME/.local/bin"
WRAPPER="$HOME/.local/bin/sarthak"
cat > "$WRAPPER" <<WRAPPER
#!/usr/bin/env bash
export SARTHAK_DIR="$INSTALL_DIR"
export SARTHAK_CONFIG="$CONFIG_FILE"
exec "$INSTALL_DIR/.venv/bin/python" -m sarthak.cli "\$@"
WRAPPER
chmod +x "$WRAPPER"
ok "CLI wrapper: $WRAPPER"

# ── Step 6: Systemd / launchd service ─────────────────────────────────────────
step 6 "Installing orchestrator service"

if [[ "$OS_NAME" == "Linux" ]]; then
    mkdir -p "$SYSTEMD_USER_DIR"
    cat > "$SYSTEMD_USER_DIR/$ORCHESTRATOR_SERVICE_NAME.service" <<UNIT
[Unit]
Description=Sarthak AI — Orchestrator
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=90
StartLimitBurst=5

[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/.venv/bin/python -m sarthak.cli orchestrator
Environment=SARTHAK_ORCHESTRATOR_SKIP_CAPTURE=1
PassEnvironment=HYPRLAND_INSTANCE_SIGNATURE XDG_RUNTIME_DIR WAYLAND_DISPLAY DISPLAY HOME USER PATH
Restart=on-failure
RestartSec=15

[Install]
WantedBy=default.target
UNIT

    timeout 5s systemctl --user enable systemd-networkd-wait-online.service 2>/dev/null \
        || warn "systemd-networkd-wait-online not available (non-fatal)"
    systemctl --user daemon-reload
    systemctl --user enable "$ORCHESTRATOR_SERVICE_NAME"
    systemctl --user restart "$ORCHESTRATOR_SERVICE_NAME"
    ok "systemd service enabled and started"
fi

if [[ "$OS_NAME" == "Darwin" ]]; then
    LAUNCH_AGENTS_DIR="$HOME/Library/LaunchAgents"
    mkdir -p "$LAUNCH_AGENTS_DIR" "$INSTALL_DIR/logs"
    PLIST="$LAUNCH_AGENTS_DIR/com.sarthak.orchestrator.plist"
    cat > "$PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.sarthak.orchestrator</string>
  <key>ProgramArguments</key>
  <array>
    <string>$INSTALL_DIR/.venv/bin/python</string>
    <string>-m</string><string>sarthak.cli</string><string>orchestrator</string>
  </array>
  <key>EnvironmentVariables</key>
  <dict>
    <key>SARTHAK_ORCHESTRATOR_SKIP_CAPTURE</key><string>1</string>
  </dict>
  <key>WorkingDirectory</key><string>$INSTALL_DIR</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$INSTALL_DIR/logs/orchestrator.log</string>
  <key>StandardErrorPath</key><string>$INSTALL_DIR/logs/orchestrator.err</string>
</dict>
</plist>
PLIST
    launchctl unload "$PLIST" 2>/dev/null || true
    launchctl load "$PLIST"
    ok "launchd agent installed"
fi

# ── Step 7: PATH reminder ─────────────────────────────────────────────────────
step 7 "Checking PATH"
if ! echo "$PATH" | grep -q "$HOME/.local/bin"; then
    warn "Add ~/.local/bin to PATH — append to ~/.bashrc or ~/.zshrc:"
    warn "  export PATH=\"\$HOME/.local/bin:\$PATH\""
else
    ok "~/.local/bin already in PATH"
fi

hdr "Installation complete"
info "Config & data : $INSTALL_DIR"
info "CLI           : $WRAPPER"
[[ "$OS_NAME" == "Linux" ]] && info "Service       : systemctl --user status $ORCHESTRATOR_SERVICE_NAME"
info "Next          : sarthak configure"
