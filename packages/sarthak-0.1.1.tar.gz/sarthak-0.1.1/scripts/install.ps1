$ErrorActionPreference = "Stop"

$RepoUrl    = "https://github.com/1bharath-yadav/sarthak"
$Branch     = if ($env:REPO_BRANCH) { $env:REPO_BRANCH } else { "main" }
$ReleaseTag = $env:RELEASE_TAG
$InstallDir = Join-Path $HOME ".sarthak_ai"
$ConfigFile = Join-Path $InstallDir "config.toml"
$SecretsFile = Join-Path $InstallDir "secrets.toml"
$MasterKeyFile = Join-Path $InstallDir "master.key"
$DataDir    = Join-Path $InstallDir "data"
$BinDir     = Join-Path $InstallDir "bin"
$Wrapper    = Join-Path $BinDir "sarthak.ps1"

function Require-Cmd([string]$Name) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Missing dependency: $Name. Please install it and re-run."
    }
}

Require-Cmd uv

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
New-Item -ItemType Directory -Force -Path $DataDir    | Out-Null

# ── Step 1: Install / upgrade sarthak ────────────────────────────────────────
Write-Host "[1/6] Installing sarthak"
if ($ReleaseTag) {
    $Ver = $ReleaseTag.TrimStart("v")
    Write-Host "  > Installing sarthak==$Ver from PyPI"
    uv venv (Join-Path $InstallDir ".venv") --python 3.11
    $PythonExe = Join-Path $InstallDir ".venv\Scripts\python.exe"
    uv pip install --python $PythonExe "sarthak==$Ver"
    Write-Host "  + Installed from PyPI"
} else {
    Write-Host "  > Fetching source from GitHub ($Branch)"
    $TempDir = Join-Path $env:TEMP ("sarthak_" + [Guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $TempDir | Out-Null
    $ZipUrl  = "$RepoUrl/archive/refs/heads/$Branch.zip"
    $ZipPath = Join-Path $TempDir "sarthak.zip"
    $SrcDir  = Join-Path $TempDir "sarthak-$Branch"
    curl -fsSL $ZipUrl -o $ZipPath
    Expand-Archive -Path $ZipPath -DestinationPath $TempDir -Force
    if (-not (Test-Path $SrcDir)) { throw "Download failed — expected $SrcDir" }

    if (Test-Path $ConfigFile) { Copy-Item $ConfigFile "$ConfigFile.bak" -Force }
    Copy-Item -Path (Join-Path $SrcDir "*") -Destination $InstallDir -Recurse -Force
    if (Test-Path "$ConfigFile.bak") { Move-Item "$ConfigFile.bak" $ConfigFile -Force }

    uv sync --project $InstallDir --all-extras
    Write-Host "  + Installed from source"
}

$PythonExe = Join-Path $InstallDir ".venv\Scripts\python.exe"

# ── Step 2: Master key & secrets ─────────────────────────────────────────────
Write-Host "[2/6] Configuring master key and secrets"
if (-not (Test-Path $MasterKeyFile)) {
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $bytes = New-Object byte[] 32
    $rng.GetBytes($bytes)
    New-Item -ItemType Directory -Force -Path (Split-Path $MasterKeyFile) | Out-Null
    Set-Content -Path $MasterKeyFile -Value ([Convert]::ToBase64String($bytes))
    Write-Host "  + Master key generated"
}
if (-not (Test-Path $SecretsFile)) {
    New-Item -ItemType File -Force -Path $SecretsFile | Out-Null
    Write-Host "  + Secrets file created"
}

# ── Step 3: Interactive wizard ────────────────────────────────────────────────
Write-Host "[3/6] Interactive configuration"
if ($env:SKIP_WIZARD -eq "true") {
    Write-Host "  ! Wizard skipped (SKIP_WIZARD=true) — run 'sarthak configure' later"
} else {
    Write-Host "  > Launching wizard..."
    & $PythonExe -m sarthak.cli configure --mode full
}

# ── Step 4: Patch config.toml ─────────────────────────────────────────────────
Write-Host "[4/6] Finalizing config.toml"
$env:CONFIG_FILE = $ConfigFile
$env:DATA_DIR    = $DataDir
$PyPatch = Join-Path $env:TEMP "sarthak_cfg_patch.py"
@'
import os
from pathlib import Path
import tomlkit

config_file = Path(os.environ["CONFIG_FILE"])
data_dir = os.environ["DATA_DIR"]

cfg = tomlkit.parse(config_file.read_text()) if config_file.exists() else tomlkit.document()

def _tbl(cfg, key):
    if key not in cfg or not isinstance(cfg[key], dict):
        cfg[key] = tomlkit.table()
    return cfg[key]

g = _tbl(cfg, "general")
g["data_dir"] = data_dir

ai = _tbl(cfg, "ai")
ai.setdefault("default_provider", "github-models")
ai.setdefault("default_model", "gpt-4o")

def _ai_sub(key, defaults):
    t = ai.get(key, tomlkit.table())
    ai[key] = t
    for k, v in defaults.items():
        if k not in t:
            t[k] = v

_ai_sub("github-models", {"base_url": "https://models.inference.ai.azure.com", "text_model": "gpt-4o", "vision_model": "gpt-4o", "timeout": 30})
_ai_sub("ollama",         {"base_url": "http://localhost:11434/v1", "text_model": "gemma3:4b", "vision_model": "qwen3-vl", "timeout": 60})
_ai_sub("openai",         {"model": "gpt-4o-mini", "base_url": "", "timeout": 30})
_ai_sub("gemini",         {"model": "gemini-2.0-flash", "timeout": 30})
_ai_sub("anthropic",      {"model": "claude-3-5-haiku-20241022", "timeout": 30})
_ai_sub("openrouter",     {"model": "anthropic/claude-3.5-sonnet", "timeout": 30, "app_url": "https://github.com/1bharath-yadav/sarthak", "app_title": "Sarthak AI"})
_ai_sub("grok",           {"model": "grok-2", "timeout": 30, "base_url": "https://api.x.ai/v1"})
_ai_sub("huggingface",    {"model": "Qwen/Qwen2.5-Coder-32B-Instruct", "timeout": 30})
_ai_sub("custom",         {"compat": "openai", "base_url": "", "model": "gpt-4o-mini", "timeout": 30})
_ai_sub("fallback",       {"fallback1_provider": "github-models", "fallback1_model": "gpt-4o-mini", "fallback2_provider": "ollama", "fallback2_model": "gemma3:4b"})
_ai_sub("classify",       {"provider": "github-models", "model": "gpt-4o", "categories": ["coding", "browsing", "reading", "communication", "design", "debugging", "research", "admin", "idle", "unknown"]})
_ai_sub("cache",          {"enabled": True, "ttl_seconds": 3600, "cache_dir": f"{data_dir}/cache"})

w = _tbl(cfg, "web")
w.setdefault("enabled", True); w.setdefault("host", "127.0.0.1"); w.setdefault("port", 4848)

e = _tbl(cfg, "encryption")
e.setdefault("enabled", True); e.setdefault("algorithm", "AES-GCM")

t = _tbl(cfg, "tui")
t.setdefault("refresh_interval", 5); t.setdefault("theme", "tokyo")
t.setdefault("max_event_rows", 200); t.setdefault("font", "JetBrainsMono Nerd Font")

m = _tbl(cfg, "mcp")
m.setdefault("enabled", True); m.setdefault("transport", "stdio")

n = _tbl(cfg, "notifications")
n.setdefault("provider", "dunst"); n.setdefault("enabled", True)
n.setdefault("idle_coding_alert_minutes", 120)
n.setdefault("work_hours_start", "09:00"); n.setdefault("work_hours_end", "22:00")

tg = _tbl(cfg, "telegram")
tg.setdefault("enabled", False); tg.setdefault("timeout_seconds", 60)

config_file.write_text(tomlkit.dumps(cfg))
'@ | Set-Content -Path $PyPatch -Encoding UTF8
& $PythonExe $PyPatch
Write-Host "  + config.toml patched"

# ── Step 5: CLI wrapper ───────────────────────────────────────────────────────
Write-Host "[5/6] Installing CLI wrapper"
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
@"
`$env:SARTHAK_DIR    = "$InstallDir"
`$env:SARTHAK_CONFIG = "$ConfigFile"
& "$PythonExe" -m sarthak.cli `$args
"@ | Set-Content -Path $Wrapper -Encoding UTF8
Write-Host "  + CLI wrapper: $Wrapper"

$currentPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($currentPath -notlike "*$BinDir*") {
    [Environment]::SetEnvironmentVariable("Path", "$currentPath;$BinDir", "User")
    Write-Host "  + Added $BinDir to user PATH (restart terminal to take effect)"
}

# ── Step 6: Windows Task Scheduler service ────────────────────────────────────
Write-Host "[6/6] Installing orchestrator (Task Scheduler)"
$TaskName = "SarthakOrchestrator"
$TaskAction = New-ScheduledTaskAction `
    -Execute $PythonExe `
    -Argument "-m sarthak.cli orchestrator" `
    -WorkingDirectory $InstallDir
$TaskTrigger  = New-ScheduledTaskTrigger -AtLogOn
$TaskSettings = New-ScheduledTaskSettingsSet -RestartCount 5 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
$env:SARTHAK_ORCHESTRATOR_SKIP_CAPTURE = "1"
Register-ScheduledTask -TaskName $TaskName -Action $TaskAction -Trigger $TaskTrigger `
    -Settings $TaskSettings -RunLevel Limited -Force | Out-Null
Start-ScheduledTask -TaskName $TaskName
Write-Host "  + Scheduled task '$TaskName' registered and started"

Write-Host ""
Write-Host "Installation complete."
Write-Host "  Config & data : $InstallDir"
Write-Host "  CLI wrapper   : $Wrapper"
Write-Host "  Next          : sarthak configure"
