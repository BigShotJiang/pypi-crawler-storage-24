$ErrorActionPreference = "Stop"

$Sarthak = Get-Command sarthak -ErrorAction SilentlyContinue
if ($Sarthak) {
    & $Sarthak.Path status
    exit
}

$Wrapper = Join-Path $HOME ".sarthak_ai\\bin\\sarthak.ps1"
if (Test-Path $Wrapper) {
    & $Wrapper status
    exit
}

Write-Host "sarthak not found in PATH."
