$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ProjectRoot
$DistDir = Join-Path $ProjectRoot "dist"

python -m nuitka `
  --onefile `
  --assume-yes-for-downloads `
  --follow-imports `
  --include-package=sarthak `
  --output-dir="$DistDir" `
  -m sarthak.cli `
  --output-filename=sarthak.exe

Write-Host "Binary written to $DistDir"
