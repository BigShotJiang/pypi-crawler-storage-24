"""
Sarthak AI — CLI entrypoint.
Sub-commands:
  spaces    → cli/spaces_cli.py
  agents    → cli/agents_cli.py
  analytics → cli/analytics_cli.py
"""
from __future__ import annotations

import click

from sarthak.cli.spaces_cli import spaces
from sarthak.cli.agents_cli import agents
from sarthak.cli import analytics_cli


@click.group()
def main():
    """Sarthak AI — Privacy-first self-analytics intelligence platform."""


# ── Sub-groups ────────────────────────────────────────────────────────────────
main.add_command(spaces)
main.add_command(agents)

main.add_command(analytics_cli.resume)


# ── Core commands ─────────────────────────────────────────────────────────────

@main.command()
@click.argument("text")
def encrypt(text: str):
    """Encrypt a string (output prefixed with ENC:)."""
    from sarthak.storage.encrypt import encrypt_string
    click.echo(encrypt_string(text))


@main.command()
@click.argument("text")
def decrypt(text: str):
    """Decrypt an ENC:... string."""
    from sarthak.storage.encrypt import decrypt_string
    try:
        click.echo(decrypt_string(text))
    except Exception as e:
        click.echo(f"Decryption failed: {e}", err=True)


@main.command()
def tui():
    """Open the Sarthak TUI dashboard."""
    from sarthak.features.tui.app import main as run_tui
    run_tui()


@main.command()
def mcp():
    """Start the Sarthak MCP server (Standard I/O)."""
    from sarthak.features.mcp.server import main as run_mcp
    run_mcp()


@main.command()
@click.option("--host", help="Override host from config.toml")
@click.option("--port", type=int, help="Override port from config.toml")
def web(host: str | None, port: int | None):
    """Start the Sarthak Web UI."""
    from sarthak.core.config import load_config
    from sarthak.web.app import launch_web

    cfg = load_config()
    web_cfg = cfg["web"]
    if not web_cfg["enabled"]:
        raise click.ClickException("Web UI is disabled in config.toml")

    launch_web(
        host=host or web_cfg["host"],
        port=int(port or web_cfg["port"]),
    )


@main.command()
@click.option("--date", help="Date to summarize (YYYY-MM-DD), defaults to today")
def summarize(date: str | None):
    """Generate an AI summary for a specific day using Spaces data."""
    import asyncio
    from datetime import datetime, date as dt
    from pathlib import Path

    from sarthak.core.config import load_config
    from sarthak.storage.helpers import get_daily_summary, write_daily_summary
    from sarthak.features.ai.agent import AgentDeps, generate_daily_summary

    target_date = date or str(dt.today())

    async def run():
        cfg  = load_config()
        parsed_date = datetime.strptime(target_date, "%Y-%m-%d").date()

        existing     = await get_daily_summary(parsed_date)
        prev_summary = existing.get("summary") if existing else None

        space_context = _collect_space_sessions_today(parsed_date)
        context = space_context

        if not context:
            click.secho(f"No activity found for {target_date}.", fg="yellow")
            return

        deps   = AgentDeps(pool=None, cwd=str(Path.home()), allow_web=False, allow_shell=False)
        result = await generate_daily_summary(
            context, target_date, deps, previous_summary=prev_summary
        )

        if result.summary.startswith("Summary unavailable"):
            click.echo(result.summary, err=True)
            return

        print()
        print(result.summary)
        if result.recommendation:
            print()
            print("── Recommendation ──────────────────────────────────────")
            print(result.recommendation)
        print()

        provider = cfg.get("ai", {}).get("default_provider", "ollama")
        await write_daily_summary(
            date=parsed_date, summary=result.summary,
            top_apps=[], productive_mins=0, idle_mins=0,
            model_used=provider,
        )

    asyncio.run(run())


def _collect_space_sessions_today(target_date) -> str:
    """Read today's SpaceSession records from all known spaces."""
    from pathlib import Path
    from sarthak.spaces.store import list_spaces
    from sarthak.spaces.session_tracker import load_sessions

    lines: list[str] = []
    try:
        for space in list_spaces():
            d = Path(space.get("directory", ""))
            if not d.exists():
                continue
            sessions = load_sessions(d, limit=20)
            today_sessions = [
                s for s in sessions
                if s.started_at and s.started_at.date() == target_date
            ]
            if today_sessions:
                total_active = sum(s.signals.active_seconds for s in today_sessions)
                lines.append(
                    f"- Space **{space.get('name', d.name)}**: "
                    f"{len(today_sessions)} session(s), "
                    f"{total_active // 60} active minutes, "
                    f"concepts: {', '.join(s.concept for s in today_sessions)}"
                )
    except Exception:
        pass
    if not lines:
        return ""
    return "## Space Learning Today\n" + "\n".join(lines)


@main.command()
@click.option(
    "--mode",
    type=click.Choice(["full", "quick"], case_sensitive=False),
    default="full",
    show_default=True,
)
def configure(mode: str):
    """Interactive configuration wizard for Sarthak AI."""
    from sarthak.core.configure import run_quick_wizard, run_wizard
    handlers = {"full": run_wizard, "quick": run_quick_wizard}
    handlers[mode]()


@main.command()
def status():
    """Check the status of Sarthak services and configuration."""
    import asyncio
    import socket
    import subprocess
    import sys
    from pathlib import Path

    from sarthak.core.config import load_config
    from sarthak.storage.db import _db_path

    def _ok(label: str, detail: str = "") -> None:
        click.secho(f"{label} OK{' — ' + detail if detail else ''}", fg="green")

    def _bad(label: str, detail: str) -> None:
        click.secho(f"{label} FAIL — {detail}", fg="red")

    def _check_file(label: str, path: Path) -> None:
        if path.exists():
            _ok(label, str(path))
        else:
            _bad(label, f"missing {path}")

    def _check_web(cfg: dict) -> None:
        web_cfg = cfg["web"]
        if not web_cfg["enabled"]:
            click.secho("Web WARN — disabled", fg="yellow")
            return
        host, port = web_cfg["host"], int(web_cfg["port"])
        sock = socket.socket()
        sock.settimeout(1.0)
        try:
            sock.connect((host, port))
            _ok("Web", f"{host}:{port}")
        except Exception as exc:
            click.secho(f"Web WARN — {host}:{port} not reachable ({exc})", fg="yellow")
        finally:
            sock.close()

    def _check_db() -> None:
        _ok("SQLite", str(_db_path()))

    click.echo("Sarthak status")
    _check_file("Config",     Path.home() / ".sarthak_ai" / "config.toml")
    _check_file("Secrets",    Path.home() / ".sarthak_ai" / "secrets.toml")
    _check_file("Master key", Path.home() / ".sarthak_ai" / "master.key")

    try:
        _check_db()
    except Exception as exc:
        _bad("SQLite", str(exc))

    try:
        cfg = load_config()
        _check_web(cfg)
    except Exception as exc:
        _bad("Web", str(exc))


@main.command()
@click.option("--force", is_flag=True, help="Skip confirmation prompt")
def reset(force: bool):
    """Wipe all production data and configuration."""
    import shutil
    import subprocess
    import sys
    from pathlib import Path

    prod_dir   = Path.home() / ".sarthak_ai"
    bin_file   = Path.home() / ".local/bin/sarthak"
    plist_file = Path.home() / "Library/LaunchAgents/com.sarthak.orchestrator.plist"

    if not force:
        click.confirm(
            f"This will DESTROY all data in {prod_dir}. Continue?",
            abort=True,
        )

    if sys.platform.startswith("linux"):
        for svc in ("sarthak-orchestrator",):
            subprocess.run(["systemctl", "--user", "stop",    svc], stderr=subprocess.DEVNULL)
            subprocess.run(["systemctl", "--user", "disable", svc], stderr=subprocess.DEVNULL)

    if sys.platform == "darwin":
        subprocess.run(["launchctl", "unload", str(plist_file)], stderr=subprocess.DEVNULL)
        if plist_file.exists():
            plist_file.unlink()

    if sys.platform == "win32":
        subprocess.run(["schtasks", "/Delete", "/TN", "SarthakOrchestrator", "/F"],
                       stderr=subprocess.DEVNULL, shell=True)

    if prod_dir.exists():
        shutil.rmtree(prod_dir)
    if bin_file.exists():
        bin_file.unlink()

    click.echo("Sarthak AI reset. Run the install script to reinstall.")


@main.command()
def orchestrator():
    """Start all Sarthak services in the foreground."""
    from sarthak.orchestrator.service import main as run_orchestrator
    run_orchestrator()


if __name__ == "__main__":
    main()
