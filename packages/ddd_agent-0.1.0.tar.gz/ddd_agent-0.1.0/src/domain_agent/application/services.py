"""Application services for orchestrating agent workflows."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, cast

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command, Interrupt

from domain_agent.application.dto import ReviewPacket
from domain_agent.application.ports import RequestRepository, WorkflowDependencies
from domain_agent.domain import PlanReviewResult
from domain_agent.workflow.graph import build_workflow
from domain_agent.workflow.state import WorkflowState, initial_workflow_state


class RequestNotFoundError(LookupError):
    """Raised when a request cannot be found in the repository."""


class ReviewHandlerRequiredError(RuntimeError):
    """Raised when workflow execution pauses for review without a handler."""


ReviewHandler = Callable[[ReviewPacket], PlanReviewResult]


@dataclass(frozen=True)
class AgentWorkflowService:
    """Orchestrate workflow execution through application ports."""

    request_repository: RequestRepository
    workflow_dependencies: WorkflowDependencies

    def run(
        self,
        request_id: str,
        *,
        review_handler: ReviewHandler | None = None,
    ) -> WorkflowState:
        """Load a request, execute the workflow, and persist the result."""
        request = self.request_repository.get(request_id)
        if request is None:
            raise RequestNotFoundError(f"Request '{request_id}' was not found.")

        workflow = build_workflow(
            self.workflow_dependencies,
            checkpointer=InMemorySaver(),
        )
        config = {"configurable": {"thread_id": request.request_id}}
        next_input: object = initial_workflow_state(request)

        while True:
            result = cast(dict[str, Any], workflow.invoke(next_input, config=config))
            interrupts = cast(tuple[Interrupt, ...], tuple(result.get("__interrupt__", ())))
            if not interrupts:
                final_result = cast(WorkflowState, result)
                self.request_repository.save(final_result["request"])
                return final_result

            if review_handler is None:
                raise ReviewHandlerRequiredError(
                    "Workflow paused for review, but no review_handler was provided."
                )

            interrupt_value = interrupts[0].value
            if not isinstance(interrupt_value, ReviewPacket):
                raise TypeError("Workflow interrupt value must be a ReviewPacket.")

            next_input = Command(
                resume=review_handler(interrupt_value),
                update={"request": result.get("request")},
            )
