"""Application-layer data structures."""

from __future__ import annotations

from dataclasses import dataclass

from domain_agent.domain import (
    ActionReviewDecision,
    AgentPlan,
    PlannedAction,
    Proposal,
    Request,
    RiskLevel,
)


@dataclass(frozen=True)
class AnalysisResult:
    """Structured analysis output used to build a proposal."""

    summary: str
    rationale: str
    execution_steps: tuple[str, ...]
    risk_level: RiskLevel


@dataclass(frozen=True)
class AgentWorkResult:
    """Structured output returned by an agent engine."""

    analysis: AnalysisResult
    proposal: Proposal
    agent_plan: AgentPlan | None = None


@dataclass(frozen=True)
class ReviewPacket:
    """Structured payload presented to a human reviewer."""

    request_id: str
    requester_id: str
    request_summary: str
    proposal_summary: str
    rationale: str
    risk_level: RiskLevel
    execution_steps: tuple[str, ...]
    planned_actions: tuple[PlannedAction, ...]
    action_decisions: tuple[ActionReviewDecision, ...] = ()


def build_review_packet(request: Request, proposal: Proposal) -> ReviewPacket:
    """Create a structured review packet from the request and proposal."""
    planned_actions: tuple[PlannedAction, ...]
    if proposal.agent_plan is not None:
        planned_actions = proposal.agent_plan.actions
    else:
        planned_actions = (
            PlannedAction(
                action_id="plan-review",
                tool_name="plan_review",
                description="Review the overall proposal as a single action.",
            ),
        )

    return ReviewPacket(
        request_id=request.request_id,
        requester_id=request.requester_id,
        request_summary=request.summary,
        proposal_summary=proposal.summary,
        rationale=proposal.rationale,
        risk_level=proposal.risk_level,
        execution_steps=proposal.execution_steps,
        planned_actions=planned_actions,
    )
