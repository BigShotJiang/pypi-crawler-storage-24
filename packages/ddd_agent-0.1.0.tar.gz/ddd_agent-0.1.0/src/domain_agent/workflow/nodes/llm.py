"""LLM-oriented workflow nodes."""

from __future__ import annotations

from domain_agent.application.ports import WorkflowDependencies
from domain_agent.workflow.state import WorkflowState

from .deterministic import _append_step


class LLMNodes:
    """Nodes designed to be backed by LLM integrations."""

    def __init__(self, dependencies: WorkflowDependencies) -> None:
        self._dependencies = dependencies

    def prepare_agent_work(self, state: WorkflowState) -> WorkflowState:
        request = state["request"]
        context = state["context"]
        work_result = self._dependencies.agent_engine.prepare(request, context)
        request.attach_proposal(work_result.proposal)

        return {
            "analysis": work_result.analysis,
            "agent_plan": work_result.agent_plan,
            "request": request,
            "proposal": work_result.proposal,
            "completed_steps": _append_step(state, "prepare_agent_work"),
        }
