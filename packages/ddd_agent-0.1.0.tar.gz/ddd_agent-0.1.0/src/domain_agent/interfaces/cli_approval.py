"""CLI helpers for collecting human review input."""

from __future__ import annotations

import datetime as dt
from collections.abc import Callable

from domain_agent.application.dto import ReviewPacket
from domain_agent.domain import (
    ActionReviewDecision,
    PlanReviewResult,
    ReviewDecision,
)


class CLIReviewCollector:
    """Collect action-level review decisions interactively from the terminal."""

    def __init__(
        self,
        *,
        decided_by: str = "cli-reviewer",
        input_func: Callable[[str], str] = input,
        output_func: Callable[[str], None] = print,
    ) -> None:
        self._decided_by = decided_by
        self._input = input_func
        self._output = output_func

    def __call__(self, review_packet: ReviewPacket) -> PlanReviewResult:
        self._render_review_packet(review_packet)

        action_decisions = self._prompt_for_action_decisions(review_packet)
        approved_action_decisions = tuple(
            action_decision for action_decision in action_decisions if action_decision.approved
        )
        overall_approved = bool(approved_action_decisions)
        overall_comment = ""
        if not overall_approved:
            overall_comment = "; ".join(
                action_decision.comment
                for action_decision in action_decisions
                if action_decision.comment
            )

        return PlanReviewResult(
            decision=ReviewDecision(
                approved=overall_approved,
                decided_by=self._decided_by,
                decided_at=dt.datetime.now(tz=dt.UTC),
                comment=overall_comment,
            ),
            action_decisions=action_decisions,
        )

    def _render_review_packet(self, review_packet: ReviewPacket) -> None:
        self._output("")
        self._output("=== Human Review ===")
        self._output(f"Request ID: {review_packet.request_id}")
        self._output(f"Requester: {review_packet.requester_id}")
        self._output(f"Summary: {review_packet.request_summary}")
        self._output(f"Risk: {review_packet.risk_level.value}")
        self._output(f"Proposal Summary: {review_packet.proposal_summary}")
        self._output(f"Rationale: {review_packet.rationale}")
        self._output("Execution Steps:")
        for index, step in enumerate(review_packet.execution_steps, start=1):
            self._output(f"  {index}. {step}")

        self._output("Planned Actions:")
        for index, action in enumerate(review_packet.planned_actions, start=1):
            self._output(f"  {index}. {action.tool_name}: {action.description}")
            if action.arguments:
                self._output(f"     arguments={action.arguments}")

    def _prompt_for_action_decisions(
        self,
        review_packet: ReviewPacket,
    ) -> tuple[ActionReviewDecision, ...]:
        action_decisions: list[ActionReviewDecision] = []
        for index, planned_action in enumerate(review_packet.planned_actions, start=1):
            approved = self._prompt_for_action_decision(
                f"Review action {index} ({planned_action.tool_name})? [a/r]: "
            )
            comment = ""
            if not approved:
                comment = self._prompt_for_rejection_comment()
            action_decisions.append(
                ActionReviewDecision(
                    action_id=planned_action.action_id,
                    approved=approved,
                    comment=comment,
                )
            )

        return tuple(action_decisions)

    def _prompt_for_action_decision(self, prompt: str) -> bool:
        while True:
            response = self._input(prompt).strip().lower()
            if response in {"a", "approve", "approved", "y", "yes"}:
                return True
            if response in {"r", "reject", "rejected", "n", "no"}:
                return False
            self._output("Please enter 'a' to approve or 'r' to reject.")

    def _prompt_for_rejection_comment(self) -> str:
        while True:
            comment = self._input("Rejection comment for this action: ").strip()
            if comment:
                return comment
            self._output("A rejection comment is required.")
