"""Interface layer for delivery mechanisms such as CLI or API."""

from domain_agent.interfaces.cli_approval import CLIReviewCollector
from domain_agent.interfaces.cli_demo import main as run_cli_demo

__all__ = ["CLIReviewCollector", "run_cli_demo"]
