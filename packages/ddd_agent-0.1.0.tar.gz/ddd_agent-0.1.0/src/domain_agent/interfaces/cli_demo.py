"""Interactive CLI demo for the generic agent template."""

from __future__ import annotations

import argparse
from collections.abc import Callable, Mapping
from dataclasses import dataclass

from domain_agent.application.dto import AgentWorkResult, AnalysisResult
from domain_agent.application.ports import WorkflowDependencies
from domain_agent.application.services import AgentWorkflowService
from domain_agent.domain import (
    AgentPlan,
    PlannedAction,
    Proposal,
    Request,
    RequestStatus,
    RiskLevel,
)
from domain_agent.infrastructure.adapters import (
    InMemoryRequestRepository,
    InMemoryTool,
    InMemoryToolRegistry,
    StaticContextProvider,
    ToolDispatchingActionExecutor,
)
from domain_agent.interfaces.cli_approval import CLIReviewCollector


@dataclass(frozen=True)
class DemoAgentEngine:
    """Build predictable agent output so the CLI can demonstrate partial review."""

    prepared_by: str = "workflow-agent"

    def prepare(
        self,
        request: Request,
        context: Mapping[str, object],
    ) -> AgentWorkResult:
        del context
        analysis = AnalysisResult(
            summary=f"Analyze request {request.request_id}",
            rationale=f"Plan a safe workflow for {request.summary}",
            execution_steps=("collect inputs", "perform approved action"),
            risk_level=request.risk_level,
        )
        agent_plan = AgentPlan(
            summary=f"Plan for {request.request_id}",
            rationale=analysis.rationale,
            actions=(
                PlannedAction(
                    action_id=f"{request.request_id}-action-1",
                    tool_name="approved_action",
                    description="Validate the current request context",
                    arguments={"request_id": request.request_id, "step": 1},
                ),
                PlannedAction(
                    action_id=f"{request.request_id}-action-2",
                    tool_name="approved_action",
                    description="Apply the approved simulated action",
                    arguments={"request_id": request.request_id, "step": 2},
                ),
            ),
            expected_outcome=f"Approved actions for {request.request_id} are completed.",
            risk_level=analysis.risk_level,
        )
        proposal = Proposal(
            summary=analysis.summary,
            rationale=analysis.rationale,
            execution_steps=analysis.execution_steps,
            risk_level=analysis.risk_level,
            prepared_by=self.prepared_by,
            agent_plan=agent_plan,
        )
        return AgentWorkResult(
            analysis=analysis,
            proposal=proposal,
            agent_plan=agent_plan,
        )


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI parser for the interactive review demo."""
    parser = argparse.ArgumentParser(
        description="Run an interactive agent workflow demo.",
    )
    parser.add_argument("--request-id", default="demo-request-001")
    parser.add_argument("--requester-id", default="demo-user")
    parser.add_argument("--summary", default="Rotate service credentials")
    parser.add_argument(
        "--details",
        default=(
            "system: demo-service\n"
            "environment: staging\n"
            "change_type: credential rotation\n"
            "expected_impact: brief reconnect"
        ),
    )
    parser.add_argument(
        "--risk-level",
        choices=tuple(level.value for level in RiskLevel),
        default=RiskLevel.MEDIUM.value,
    )
    parser.add_argument("--reviewer", default="cli-reviewer")
    return parser


def build_demo_dependencies() -> WorkflowDependencies:
    """Create package-contained demo dependencies."""
    tool_registry = InMemoryToolRegistry()
    tool_registry.register(InMemoryTool(name="approved_action", result_prefix="Simulated"))
    return WorkflowDependencies(
        context_provider=StaticContextProvider(
            {
                "policy": "human review required",
                "source": "interactive-cli-demo",
            }
        ),
        agent_engine=DemoAgentEngine(),
        action_executor=ToolDispatchingActionExecutor(tool_registry=tool_registry),
    )


def build_demo_request(args: argparse.Namespace) -> Request:
    """Create a generic request from CLI arguments."""
    return Request(
        request_id=args.request_id,
        requester_id=args.requester_id,
        summary=args.summary,
        details=args.details,
        risk_level=RiskLevel(args.risk_level),
    )


def run_demo(
    args: argparse.Namespace,
    *,
    input_func: Callable[[str], str] = input,
    output_func: Callable[[str], None] = print,
) -> int:
    """Run the interactive agent workflow demo."""
    repository = InMemoryRequestRepository()
    request = build_demo_request(args)
    repository.save(request)

    service = AgentWorkflowService(
        request_repository=repository,
        workflow_dependencies=build_demo_dependencies(),
    )
    review_collector = CLIReviewCollector(
        decided_by=args.reviewer,
        input_func=input_func,
        output_func=output_func,
    )

    output_func("=== Agent Workflow Demo ===")
    output_func(f"Request: {request.summary}")
    output_func(f"Risk Level: {request.risk_level.value}")

    result = service.run(
        request.request_id,
        review_handler=review_collector,
    )
    final_request = result["request"]

    output_func("")
    output_func("=== Final Result ===")
    output_func(f"Status: {final_request.status.value}")
    if "execution_result" in result:
        output_func(f"Execution Result: {result['execution_result']}")
    else:
        output_func("Execution Result: not executed")
    output_func(f"Completed Steps: {', '.join(result['completed_steps'])}")

    if final_request.status is RequestStatus.REJECTED:
        return 1
    return 0


def main() -> int:
    """Run the interactive CLI demo."""
    parser = build_parser()
    args = parser.parse_args()
    return run_demo(args)


if __name__ == "__main__":
    raise SystemExit(main())
