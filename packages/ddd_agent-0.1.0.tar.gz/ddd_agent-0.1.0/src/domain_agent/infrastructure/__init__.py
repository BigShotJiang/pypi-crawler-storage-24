"""Infrastructure layer for external system adapters."""
