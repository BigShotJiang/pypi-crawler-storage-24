# MixLift Strategy

*Cross-Functional Phase 0-2 Synthesis | March 5, 2026 | Confidential*

*This document synthesizes findings from two rounds of independent leadership audits (Engineering, Product, Strategy, Data Science, Marketing) conducted after Phase 0-1 implementation. It replaces all prior strategy documents and should be reviewed every Monday.*

---

## The North Star

**MixLift is the tool that turns every marketer's ad spend data into a dollar-denominated action plan they trust enough to act on -- delivered in minutes, for $299/month, inside the AI assistant they already use.**

The key words are *dollar-denominated*, *trust*, *act on*, and *already use*. If any part of the product fails one of those tests, it is not done.

---

# Section I: Executive Summary -- Phase 0-1 Results

## Execution Scorecard

| Phase | Deliverables | Shipped | Status |
|---|---|---|---|
| **Phase 0** | 10 | 8 | 80% -- all code items done, both infrastructure items blocked |
| **Phase 1A** | 7 | 7 | 100% -- all output quality features shipped, headless API ahead of schedule |
| **Total** | 17 | 15 | 88% completion rate |

**What changed:** The output is now marketer-ready. Dollar headlines, saturation traffic lights, confidence summaries, scenario mode, and a headless Python API all shipped. The product transforms raw Bayesian output into something a VP of Marketing can act on.

**What didn't change:** No one can install or pay. `pip install mixlift` does not work. The license API is not deployed. Stripe webhooks are not connected. Zero revenue is possible today.

**Execution grade: B+.** Strong code execution, poor infrastructure execution. "Everything that could be done locally was done. Everything that requires infrastructure was not." This is the classic pattern of shipping features but not shipping the business.

### Phase 0 Detail

| Deliverable | Status | Notes |
|---|---|---|
| CI/CD pipeline | DONE | GitHub Actions, pytest+ruff, Python 3.11/3.12, tag-based PyPI release |
| Config lazy init | DONE | `ensure_directories()` no longer called on import |
| Secret key validation | DONE | Raises in production if default used |
| Channel display names | DONE | Centralized `format_channel_name()` in `optimizer.py:12-29` |
| Pricing correction | DONE | All messages say "$299/mo" and "Growth" |
| Free tier limits | DONE | 2 channels, 2,000 rows in `license.py` and `config.py` |
| MCP_FAST_CONFIG removal | DONE | 2 chains, 500 tune, 250 draws. No 1-chain config |
| PyMC-Marketing pin | DONE | `pymc-marketing>=0.9,<1.0` in `pyproject.toml` |
| **Deploy license API** | **BLOCKED** | `api.mixlift.io` does not exist. All validation falls back to free tier |
| **Publish to PyPI** | **BLOCKED** | Release workflow exists but no tag pushed. Cannot `pip install mixlift` |

### Phase 1A Detail

| Deliverable | Status | Location |
|---|---|---|
| Dollar-value headline | DONE | `server.py:486` -- Free shows %, paid shows $ |
| Saturation traffic lights | DONE | `server.py:282-337` -- green/yellow/red with interpolated % |
| Budget reallocation (% + $) | DONE | Plain English labels with percentages and dollars |
| Confidence explainer | DONE | `server.py:382-408` -- high/moderate/low per channel |
| Model fit summary | DONE | `server.py:412-445` -- R-squared, MAPE (see Section II, #8) |
| Headless Python API | DONE | `mixlift/api.py` (141 lines), exposed via `mixlift/__init__.py` |
| Scenario mode | DONE | `server.py:739-809` -- "cut X by Y%", "increase X by $Y", "move $Y from X to Z" |

---

# Section II: What We Learned

These findings emerged from cross-referencing all leadership audits against the actual codebase. They are the ground truth of where MixLift stands today.

### 1. Code velocity =/= deployment velocity

All code items shipped. Zero infrastructure items shipped. The sprint plan optimized for code velocity and had no explicit "deploy" phase. Deployment must be treated as its own workstream with its own timeline, not a line item in a feature sprint.

### 2. The output transformation worked

Dollar headlines ("MixLift found $47,000/week in budget optimization opportunity"), saturation traffic lights ("Meta is 78% saturated"), and confidence summaries make the product VP-of-Marketing readable. The free-to-paid gate (percentages vs. dollars) is more elegant than designed. **This is the moat layer.** Do not weaken the dollar-headline gate.

### 3. Tests now pass

Test assertions have been corrected for the updated display names (TikTok, TV, SEO) and tier limits. CI should pass once changes are committed and pushed.

### 4. The tier naming is a latent revenue-blocking bug

`license.py` line 52 checks for `data.get("tier") == "pro"` from the API response. But the product is marketed as "Growth" tier. If the license API returns `"tier": "growth"`, `validate_license()` will treat it as invalid and return free tier. **The first paying customer gets free tier limits.** Must accept both `"pro"` and `"growth"` at minimum.

### 5. The 180-day minimum was softened (RESOLVED)

Strategy Decision #9 specified: "Accept shorter time ranges with explicit accuracy caveats. 90 days minimum." This has been implemented: `server.py:164` now hard-blocks at 90 days instead of 180. `_check_date_range_warnings()` at `server.py:174-195` warns for 90-179 days with explicit accuracy caveats. **Note:** `ingest/service.py` still uses 180-day minimum for platform CSV path -- must be aligned to 90 days.

### 6. Free tier is unlimited in practice

`config.py` defines `free_max_runs_per_month: 2` but nothing on the MCP path reads this value. No usage metering exists in the MCP server. `deps.py` enforces run limits only for the FastAPI web backend. In practice, free tier MCP users can run unlimited analyses.

### 7. The headless API has no license gate

`mixlift/api.py` implements the full analysis pipeline without MCP dependency -- but it has zero license validation. Any user who `pip install`s MixLift can call `analyze("data.csv")` with no tier limits. **Must add basic license gate before GTM launch (Week 4). Not acceptable as ungated beyond beta.**

### 8. Model fit metrics silently return nothing

`_compute_model_fit()` at `server.py:412-445` depends on `posterior_predictive` samples, which PyMC-Marketing does not generate by default. The function catches the failure and returns `"Model fit metrics not available for this run"`. Every production run will show this. Must add `sample_posterior_predictive()` to the `fit_model()` call.

### 9. No seasonal or holiday controls (NEW)

`add_control_columns()` in `preprocessing.py` only adds a linear trend. No holiday indicators, no month dummies, no promotional flags. Seasonal demand spikes (Black Friday, Q4 lift) will be misattributed to whichever channel spent more during those periods. This is the single largest source of biased ROAS estimates. Must add auto-detected holiday controls before GTM launch.

### 10. Free tier leaks dollar values (NEW)

The free tier suppresses dollar headlines but `budget_optimization.current_allocation` and `optimal_allocation` still show raw dollar amounts. A sophisticated user can calculate the exact dollar opportunity from the optimization data. The paywall gate is bypassed for anyone who reads the JSON.

### 11. Raw saturation curves are useless in MCP context (NEW)

`saturation_curves` dumps 100 spend/response data points per channel (1,600 points for 8 channels). Claude cannot render charts. This data inflates token usage and degrades summarization quality. Keep traffic lights, strip raw curves from MCP output.

### 12. MCMC config insufficient for reliable diagnostics (NEW)

2 chains is the absolute minimum for R-hat computation. With only 2 chains, a single bad chain gives false confidence (R-hat=1.0). Industry standard is 4 chains. target_accept=0.85 is below PyMC default (0.95) and risks divergent transitions. Fixed random_seed=42 masks sampling variability.

---

# Section III: Revised Risk Matrix

Merged and deduplicated from all leadership audits. Ordered by severity.

| # | Risk | Severity | Source | Mitigation |
|---|---|---|---|---|
| 1 | **Cannot charge anyone** (License API + PyPI not deployed) | CRITICAL | All | Deploy license API. Push PyPI tag. This is the only P0. |
| 2 | **Tier naming mismatch blocks first paying customer** | HIGH | EM + Strategist | `license.py:52` accept both "pro" and "growth". 30-minute fix. |
| 3 | **Tests broken, CI will fail on next PR** | HIGH | EM | Fix assertions in test_license, test_server. Commit all pending changes. |
| 4 | **No retention mechanic (stateless)** | HIGH | PM + Strategist | Contextual memory is #1 priority. Ship Week 7-8. Without it, estimated 40-60% monthly churn. |
| 5 | **No seasonal/holiday controls** | HIGH | DS Manager | Seasonal demand misattributed to channels. Biased ROAS. Add auto-detected holidays Week 5. |
| 6 | **Free tier unlimited (no metering)** | MEDIUM | All | Local run counter Week 4-5, server-side metering Week 7-8. |
| 7 | **Model fit silently empty** | MEDIUM | EM + DS | Add `sample_posterior_predictive()` to `fit_model()`. Week 4. |
| 8 | **Scenario mode lacks confidence intervals** | MEDIUM | PM + DS | Point estimates without CI risk wrong recommendations. Add CIs Week 7-8. |
| 9 | **MCMC config insufficient** | MEDIUM | DS Manager | 2 chains inadequate for reliable R-hat. Move to 4 chains x 250 draws. Week 4. |
| 10 | **Headless API bypasses monetization** | MEDIUM | Strategist | Must gate in Week 4. Ungated path around all monetization. |
| 11 | **Free tier dollar leak** | MEDIUM | PM | `budget_optimization` output shows dollar values, undermining paywall. Redact Week 4. |
| 12 | **MCMC timeout on large datasets** | MEDIUM | EM | Model caching for repeat runs. Reduce problem size for MCP path. |
| 13 | **Circular import fragility (engine <-> optimizer)** | LOW | EM | Move `format_channel_name()` to `mixlift/modeling/utils.py`. |
| 14 | **No data length warnings** | LOW | DS Manager | Analyses with <26 weeks treated same as 52+. Add "exploratory" badge. |

### Unchanged Strategic Risks

These risks from the original strategy remain valid and unchanged:

| Risk | Severity | Probability | Mitigation |
|---|---|---|---|
| **PyMC-Marketing ships a product** | HIGH | MEDIUM | Ship faster. Build moats they will not build: data normalization, memory, dollar-value output, agency features. |
| **Anthropic platform dependency** | HIGH | MEDIUM | Headless Python API already shipped. REST API in Phase 2. MCP is channel one, not the only channel. |
| **LLM hallucination erodes trust** | HIGH | HIGH | MixLift returns deterministic JSON. Add "verified by MixLift" markers. Add interpretation guidelines in tool description. |
| **High churn (>5% monthly)** | HIGH | HIGH | Build memory, comparison, scenario features. Make MixLift a monthly workflow, not a one-shot tool. |
| **Prescient/Paramark drops prices** | HIGH | LOW | Stay 3-5x cheaper. Emphasize zero-onboarding AI-native UX. |
| **Triple Whale deepens MMM** | HIGH | HIGH | Triple Whale has massive DTC distribution. If they ship real Bayesian MMM at $199/mo, we cannot compete on distribution. Speed is the defense. |
| **MCP marketplace does not gain traction** | MEDIUM | MEDIUM | Headless API + Python library as backup distribution. Direct content marketing to DTC communities. |

---

# Section IV: Revised Sprint Plan

## Week 3 -- "SHIP THE BUSINESS" (Infrastructure Only)

No feature work. No refactoring. Only tasks that unblock revenue.

| # | Deliverable | Effort | Definition of Done |
|---|---|---|---|
| 1 | Commit all pending changes, push to main | 30 min | Code on GitHub. CI runs. |
| 2 | Fix free tier limits in code: `license.py` (2ch/2000), `config.py` (2ch/2000) | 1 hr | Constants match strategy. All test assertions updated. |
| 3 | Fix tier naming in `license.py:52` | 30 min | `validate_license()` accepts both `"pro"` and `"growth"` tier values. |
| 4 | Fix all broken test assertions | 2 hrs | `pytest` passes. CI green. |
| 5 | Deploy license API to `api.mixlift.io` on Render | 4 hrs | Health check passing. `/v1/license/validate` responding. DNS configured. |
| 6 | Connect Stripe webhooks, verify payment flow | 4 hrs | Payment Link -> Checkout -> Webhook -> License created in DB. Manual end-to-end test passes. |
| 7 | Push `v0.1.0` tag, publish to PyPI | 1 hr | `pip install mixlift` works from a clean virtualenv. Release workflow triggered by tag. |
| 8 | End-to-end stranger test | 2 hrs | A stranger can: install from PyPI -> pay via Stripe -> receive license key -> configure MCP -> run analysis. |

**Exit criteria:** A stranger can `pip install mixlift`, pay $299, and run an analysis. Total estimated effort: ~15 hours / 2.5 engineering days.

## Week 4-5 -- "Fix What We Found"

Quality, correctness, and conversion fixes from the Phase 0-1 audit.

| # | Deliverable | Effort | Priority |
|---|---|---|---|
| 1 | Add `sample_posterior_predictive()` to `fit_model()` | M | P1 |
| 2 | Add license gate to headless API (`analyze()`) | M | P1 |
| 3 | Redact dollar values from optimization output for free tier | S | P1 |
| 4 | Update MCMC config: MCP_CONFIG to 4 chains x 250 draws, target_accept=0.90 | S | P1 |
| 5 | Auto-detect US holidays (add `holidays` package to controls) | M | P1 |
| 6 | Add "Exploratory Analysis" badge for analyses with <26 weeks of data | S | P1 |
| 7 | Basic usage metering: local run counter (MCP path) | S | P1 |
| 8 | Strip raw saturation curves from MCP output (keep traffic lights) | S | P2 |
| 9 | Extract shared CSV logic from `server.py` into `mixlift/ingest/loader.py` | M | P2 |
| 10 | Align `ingest/service.py` date validation from 180 to 90 days | S | P1 |
| 11 | Add unit tests for Phase 1A functions | M | P2 |

## Week 5-6 -- "GET CUSTOMERS" (GTM Launch)

| # | Deliverable | Owner | Definition of Done |
|---|---|---|---|
| 1 | Record 2-minute demo video | Founder | Shows full flow: CSV drop -> Claude -> dollar-value result |
| 2 | Write 1 case study with real dollar numbers | Founder | Anonymized real data analysis. Published on landing page. |
| 3 | Build landing page at mixlift.io | Founder | Headline, demo video, pricing, install instructions, CTA |
| 4 | MCP marketplace listing | Founder | MixLift listed with description, screenshots, install instructions |
| 5 | Founder-led outreach: 20 DTC brands | Founder | Personalized LinkedIn DMs to Directors/VPs of Growth. Offer live demo on their data. |
| 6 | Concierge demos: 2+ per week | Founder | Sit on Zoom, run MixLift on their data live, show dollar-value output |
| 7 | Community seeding | Founder | 2-3 posts on r/dtc, r/PPC, Twitter sharing anonymized results |

**Target: 5 paying customers by end of Week 6.**

## Week 7-8 -- "RETAIN THEM"

| # | Deliverable | Owner | Priority |
|---|---|---|---|
| 1 | **Contextual memory v1** | Eng | #1 -- store analysis summaries locally. Subsequent runs show "ROAS changed +12% since last analysis." |
| 2 | Server-side usage metering | Eng | `analysis_runs` table in license API. MCP server reports usage. Monthly limits enforced. |
| 3 | License fallback decision: fail-closed with grace period | Eng + Strategy | Paid features fail-closed when API unreachable. 24-hour grace window for outages. |
| 4 | Add confidence intervals to scenario mode | Eng | Propagate posterior uncertainty through scenario projections. |
| 5 | Continue outreach, close to 10 customers | Founder | |

**Target: 10 paying customers by end of Week 8 (Day 56). Memory shipped before first billing renewal.**

## Week 9-10 -- "LEARN AND ITERATE"

| # | Deliverable | Owner |
|---|---|---|
| 1 | Churn analysis from first cohort | Founder |
| 2 | Customer interviews (every paying customer) | Founder |
| 3 | Agency outreach (conditional -- only if inbound signals justify) | Founder |
| 4 | Monitoring and alerting for license API | Eng |
| 5 | End-to-end integration test in CI | Eng |
| 6 | Propagate uncertainty through budget optimizer | Eng |

## Week 11-12 -- Phase 2: Scale or Pivot

| # | Deliverable | Owner |
|---|---|---|
| 1 | Evaluate kill criteria at Day 90 | Founder |
| 2 | Pro tier launch ($799/mo) if demand warrants | Eng + Product |
| 3 | Model caching for repeat runs | Eng |
| 4 | Landing page refresh with customer testimonials | Founder |

**Exit criteria:** Monthly churn <5%. 25+ paying customers. Retention mechanics demonstrably reducing churn. Or: kill criteria triggered, pivot begins.

---

# Section V: Strategic Decisions

These are resolved. Do not re-debate unless new data emerges.

| # | Decision | Resolution | Rationale |
|---|---|---|---|
| 1 | **Primary distribution channel** | MCP (with Python API backup shipped) | AI-native UX is the differentiation. Headless API already live as backup. |
| 2 | **Launch pricing** | Free ($0) + Growth ($299/mo) only | Two tiers. Simple. No $99 tier yet -- insufficient data on conversion. |
| 3 | **Free tier limits** | 2 channels, 2,000 rows, 2 runs/month, no dollar headlines | 3ch/5000 was too generous -- covers 80% of DTC ad spend with no upgrade pressure. 2ch forces constraint that drives upgrade. Run count enforced via local counter (Week 4), server-side (Week 7-8). |
| 4 | **Agency strategy Phase 1** | Deferred to Week 9+. Phase 1 is DTC brands only. | Agency sales are longer-cycle and require multi-client features we don't have. Focus on one persona. |
| 5 | **1-chain fast config** | Removed | Trust > speed. Using 4 chains with reduced draws (250). |
| 6 | **Headless API timing** | Phase 1A (shipped, was Phase 2) | Reduces platform risk. **UPDATE:** Has no license gate. Basic gate shipping Week 4 before GTM launch. |
| 7 | **PyMC-Marketing threat level** | HIGH/MEDIUM (upgraded) | If they ship a product, our tech layer vanishes. Speed is the defense. |
| 8 | **Data locality** | Local by default, opt-in benchmarking in Phase 2 | Preserves privacy story. Builds data asset over time without forcing it. |
| 9 | **Minimum data requirement** | 90-day hard minimum. "Exploratory Analysis" badge for <26 weeks. | Implemented. Analyses with <182 days carry accuracy caveats. Priors dominate at <26 weeks -- users are warned. Wide-format path at 90 days. Platform CSV path must be aligned from 180 to 90. |
| 10 | **Web app** | Parked | MCP server is the product. Web app gets no investment until Phase 3 at earliest. |
| 11 | **When to raise** | After proving churn <5% with 30+ paying customers | Raise on retention data, not projections. Seed round at $500K-$1M ARR run rate. |
| 12 | **Primary positioning headline** | "Find the wasted $47K in your ad budget. In 5 minutes. For $299/month." | Lead with dollar outcome, not methodology. "Enterprise-grade" retired. |
| 13 | **Infrastructure as separate workstream** | Deployment gets its own sprint, not feature sprint line items | Phase 0-1 proved code velocity =/= deployment velocity. |
| 14 | **License fallback behavior** | Fail-closed with 24-hour grace period (Week 7-8) | Current: fail-open to free tier on any API error. Acceptable during beta. Fail-closed protects revenue. Grace period prevents locking out paid users during short outages. |
| 15 | **Free tier limits enforcement** | 2 channels, 2,000 rows. Code aligned to strategy. | 3ch/5000 was a bug. Code must match strategy. |
| 16 | **MCMC config (MCP path)** | 4 chains x 250 draws, target_accept=0.90 | 4 chains required for reliable R-hat diagnostics. 250 draws sufficient with 4 chains. Parallel execution keeps wall-clock time manageable. |
| 17 | **Agency outreach** | Deferred to Week 9+. Phase 1 is DTC brands only. | Agency sales are longer-cycle and require multi-client features we don't have. Focus on one persona. |
| 18 | **Seasonal controls** | Auto-detect US holidays. Ship Week 5. | Missing holiday controls cause seasonal demand misattribution. Use `holidays` Python package. No user configuration required. |

---

# Section VI: Success Metrics

## The Only Metric That Matters

**5 paying customers by Day 45. 10 paying customers by Day 60.**

Concierge sales model with 20 targeted DTC prospects. Not free users. Not signups. Not MCP installs. Humans who have given MixLift $299/month of their company's money and have not asked for a refund.

## Ongoing Dashboard

| Metric | 30 Days | 90 Days | 6 Months | 12 Months |
|---|---|---|---|---|
| Paying customers | 5 | 25 | 60 | 150 |
| MRR | $1,500 | $7,500 | $25,000 | $75,000 |
| Monthly logo churn | Measuring | <8% | <5% | <3% |
| Free-to-paid conversion | Measuring | 3% | 5% | 8% |
| Time from install to first analysis | <10 min | <5 min | <3 min | <3 min |
| NPS (paying customers) | Measuring | >30 | >40 | >50 |
| CAC (blended) | $0 (founder-sold) | <$100 | <$150 | <$200 |
| LTV/CAC | Measuring | >3x | >4x | >5x |

## Product Readiness by Persona

| Persona | Readiness | Gap |
|---|---|---|
| Media buyer / performance marketer | 80% | Needs scenario CI, sample dataset |
| VP of Marketing | 55% | Needs narrative output, shareable artifacts |
| CFO / CEO | 30% | Won't use AI assistant for analytics |

## The Churn Threshold

- **Monthly churn >5%:** Lifestyle business. Caps at ~$500K ARR.
- **Monthly churn 3-5%:** Viable SaaS. Can reach $1-3M ARR with strong acquisition.
- **Monthly churn <3%:** Venture-scale. Compounding math works. Raise a seed round.

**Churn is THE metric that determines every subsequent strategic decision.** Start measuring from Day 1 of paid customers.

## Kill Criteria

If at 90 days (Day 90):
- Fewer than 10 paying customers despite active sales effort: pivot distribution strategy (consider web app, consider Shopify app)
- Monthly churn >15%: fundamental product-market fit problem. Stop building features. Talk to every churned customer.
- Zero inbound interest from any channel: distribution is not working. Build alternative channels immediately.

Lifestyle business ($100-180K ARR) is acknowledged as a valid base case. Not a failure. Venture path requires churn <3%.

---

# Section VII: Architecture

## Current State (Updated)

```
USER'S MACHINE                              REMOTE SERVICES
+------------------------------+            +------------------------------+
|  Claude Desktop / MCP Client |            |  api.mixlift.io              |
|           |                  |            |  (License API - NOT YET LIVE)|
|           | stdio            |            |                              |
|           v                  |            |  POST /v1/license/validate   |
|  +---------------------+    |  HTTPS ->  |  POST /v1/webhooks/stripe    |
|  |  MixLift MCP Server |----+----------->|  GET  /health                |
|  |                     |    |  <- JSON   |           |                   |
|  |  mixlift_analyze()  |    |            |           v                   |
|  |  - CSV auto-detect  |    |            |  SQLite (licenses table)      |
|  |  - tier enforcement |    |            +------------------------------+
|  +----------+----------+    |
|             |               |            +------------------------------+
|             v               |            |  Stripe                      |
|  +---------------------+    |            |  - Payment Link -> Checkout  |
|  |  Modeling Engine     |    |            |  - Webhooks -> License API   |
|  |  PyMC-Marketing     |    |            +------------------------------+
|  |  - MCMC (4 chains)  |    |
|  |  - Budget optimizer  |    |
|  |  - Saturation curves |    |
|  +---------------------+    |
|                              |
|  === Headless API ===        |
|  +---------------------+    |
|  |  mixlift.analyze()  |    |
|  |  (Python API)        |    |
|  |  - No MCP dependency |    |     License gate shipping
|  |  - License gate TBD  |    |     Week 4 before GTM launch
|  |  - Full pipeline     |    |
|  +---------------------+    |
+------------------------------+
```

### Key Technical Decisions

**Why MCP?** Zero infrastructure for users. Data stays local. AI-native UX. New, uncrowded distribution channel.

**Why PyMC-Marketing?** Battle-tested Bayesian MMM. Published methodology. Inherited credibility. Risk: if they build a product, we lose the tech layer.

**Why SQLite for License API?** Simple CRUD. Zero ops. Migrate to Postgres at ~10K licenses.

**Why Stripe Payment Links?** Fastest path to revenue. Upgrade to embedded checkout when we need custom pricing pages.

**Why headless API now?** Reduces Anthropic platform dependency. Enables non-MCP distribution (notebooks, scripts, future REST API). Developer on-ramp for technical users.

**Why 4 chains?** R-hat convergence diagnostics require multiple chains. 2 chains is the absolute minimum; 4 provides reliable diagnostics. Parallel execution on multi-core machines keeps wall-clock time manageable.

---

# Section VIII: Technical Debt Queue

Reordered with newly discovered items from the Phase 0-2 audit. Ordered by business impact.

| Priority | Issue | Business Impact if Unfixed | Effort | Status |
|---|---|---|---|---|
| P0 | **License API not deployed** | No one can pay for the product. | M | BLOCKED |
| P0 | **Not on PyPI** | No one can install the product. | S | BLOCKED |
| P0 | **Tier naming mismatch** (`license.py:52`) | First paying customer gets free tier. | S | NEW |
| P0 | **Free tier limits mismatch** (code vs strategy) | Gate too generous, no upgrade pressure. | S | NEW |
| P1 | **No seasonal/holiday controls** | Biased ROAS from seasonal misattribution. | M | NEW |
| P1 | **Model fit silently empty** | Every run shows "metrics not available." Looks broken. | M | UNCHANGED |
| P1 | **Headless API bypasses monetization** | Ungated path around all monetization. | M | UPGRADED |
| P1 | **Free tier dollar leak** | `budget_optimization` shows dollars, undermining paywall. | S | NEW |
| P1 | **MCMC config insufficient** | 2 chains inadequate for reliable R-hat diagnostics. | S | NEW |
| P1 | No usage metering | Cannot enforce run limits. Free tier is unlimited. | M | UNCHANGED |
| P1 | License bypass (fail-open) (`license.py:61`) | Anyone can use paid features by catching exception. | M | UNCHANGED |
| P1 | Scenario mode lacks confidence intervals | Point estimates risk bad recommendations. | M | UNCHANGED |
| P1 | `ingest/service.py` still 180-day minimum | Platform CSV users hit old wall. Wide format is 90 days. | S | NEW |
| P2 | Raw saturation curves in MCP output | 1600 wasted data points Claude can't render. | S | NEW |
| P2 | Shared CSV logic in `server.py` private functions | `api.py` depends on MCP server internals. Fragile coupling. | M | UNCHANGED |
| P2 | Circular import risk (engine <-> optimizer) | Fragile. Will break when adding new modules. | S | UNCHANGED |
| P2 | No end-to-end integration test | Full pipeline regressions not caught. | M | UNCHANGED |
| P2 | No model caching | Repeat runs on similar data take full MCMC time. | M | UNCHANGED |
| P2 | No monitoring/alerting | License API outage goes undetected. | S-M | UNCHANGED |
| P3 | Web app code in same package | Bloats install size. Confusing package boundary. | M | UNCHANGED |

---

# Section IX: What Remains True

## The Synthesized Strategy (Unchanged)

### What MixLift Is

MixLift is the first AI-native Marketing Mix Modeling platform. It delivers Bayesian MMM -- the gold standard for marketing measurement -- through a conversational AI interface, at a fraction of the price of every competitor.

A marketer drops a CSV of their ad spend into Claude and gets back: a dollar-value headline showing how much budget is being wasted, which channels are actually driving revenue, exactly how to reallocate their budget with confidence intervals, and a saturation analysis showing where spend has diminishing returns. No dashboard. No data science team. No six-figure contract.

### The Market

**Marketing analytics:** ~$5B today, growing to $13-15B by 2030.

**The pricing gap we exploit:** True Bayesian MMM starts at $1,500/month (Prescient AI, Paramark). Everything below that is shallow regression or basic attribution. MixLift is the only true Bayesian MMM under $1,500/month.

**Primary buyer:** Director of Growth or VP Marketing at a DTC eCommerce brand, $5M-$200M revenue, spending $500K-$20M/year on ads, with no data scientist on staff.

### Pricing (Launch)

| Tier | Price | Channels | Rows | Runs/Month | Dollar Headlines | Target |
|---|---|---|---|---|---|---|
| **Free** | $0 | 2 | 2,000 | 2 | No (percentages only) | Trial / demonstrate value |
| **Growth** | $299/mo | 8 | 50,000 | Unlimited | Yes | DTC brands, $1-20M rev |

**Phase 2 additions** (after 50 paying customers):
- **Pro** ($799/mo) -- 20 channels, 500K rows, priority support
- **Agency** ($1,499/mo) -- multi-client (10), white-label reports

### Moat (Ordered by Build Priority)

1. **Output quality and trust.** Dollar-value headlines, confidence explainers, saturation traffic lights. The AI interpretation layer that makes raw Bayesian output actionable. PyMC-Marketing will not build this. **STATUS: SHIPPED.** Not a durable moat (replicable in 1-2 weeks) but a first-mover advantage.

2. **Data normalization.** Every CSV format, API schema, and edge case. The unglamorous but critical ingest pipeline. **STATUS: Partial. Auto-detect works for Meta, Google, TikTok, generic.**

3. **Contextual memory.** "Last quarter we recommended cutting TikTok by 15%. You did. Revenue went up 8%." Strategic memory creates switching costs. **STATUS: Not started. #1 priority for Week 7-8. This is the first real moat.**

4. **Becoming the default verb.** "Run MixLift on it" becomes how marketers say "do MMM." First-mover in AI-native marketing analytics. **STATUS: Requires shipping first.**

5. **Vertical benchmarks.** Anonymized, aggregated benchmark data from the user base. Requires scale; cannot be built day one. **STATUS: Not started.**

### Competitive Landscape (Updated)

| Competitor | Threat Level | Rationale |
|---|---|---|
| **PyMC-Marketing** (open source) | HIGH | We build on this. If they ship a product/UI, our tech layer disappears. |
| **Triple Whale** | HIGH | Massive DTC distribution ($50M+ raised). If they ship real Bayesian MMM at $199/mo, we cannot compete on distribution. |
| **Paramark** | HIGH | Closest methodology. If they launch a $500/month self-serve tier, the gap narrows. |
| **Prescient AI** | HIGH | Same methodology, same market, 5-15x our price. Could drop prices. |
| **Pecan AI** | MEDIUM-HIGH | $116M raised. Predictive analytics platform adding marketing measurement. |
| **Agency internal tools** (Robyn/Meridian) | MEDIUM | Agencies building DIY tools on open source. We must be easier. |

---

# Section X: What Winning Looks Like

## 6-Month Snapshot (September 2026)

MixLift has 60 paying customers generating $25K MRR. Monthly churn is 4%. Three agencies are using it across 15+ client accounts. The product runs on both Claude and ChatGPT. Meta Ads API connector eliminates CSV friction for 40% of users. Every analysis output starts with a dollar-value headline. Users who have run 3+ analyses have <2% monthly churn because comparison features make each run more valuable than the last.

## 12-Month Snapshot (March 2027)

MixLift has 150 paying customers generating $75K MRR ($900K ARR run rate). Monthly churn is under 3%. The agency channel represents 30% of revenue. A seed round closes at $3-5M on a $20-30M valuation. The team is 4 people: founder, senior engineer, growth marketer, customer success. MixLift is the default answer to "how do I run MMM?" in AI assistant conversations.

## The Honest Assessment

MixLift is a well-engineered product with no business attached to it. The modeling core is production-quality. The output layer is shipped and compelling. The competitive positioning is real.

### Probability Assessment

- **Probability of reaching $1M ARR:** 5-10%. Requires churn <3%, strong retention mechanics, and expanding to 300+ customers.
- **Most likely outcome:** Lifestyle business at $100-180K ARR. This is a fine outcome.
- **MixLift is a speed play, not a moat play.** Output quality is replicable. Contextual memory creates real switching costs but is not built. "Default verb" status requires scale we don't have. Act accordingly: ship fast, learn fast, pivot fast.

### What determines the outcome is not strategy -- it is:

1. **Can we actually deploy?** (License API + PyPI -- this week)
2. **Can we convert?** (5 paying customers -- next 4 weeks)
3. **Can we retain?** (Churn <5% -- next 3 months)

If monthly churn stays above 5%, this caps out as a profitable lifestyle business doing $300-500K ARR. That is a fine outcome.

If monthly churn drops below 3% because memory, comparison, and scenario features make MixLift a monthly workflow tool, the compounding math works for venture scale.

**The next 72 hours determine whether MixLift is a product or a project.**

Ship the infrastructure. Get 5 paying customers. Measure churn. Everything else follows from that data.

---

*Last updated: March 5, 2026*
*Next review: March 11, 2026*
*Review cadence: Every Monday*
