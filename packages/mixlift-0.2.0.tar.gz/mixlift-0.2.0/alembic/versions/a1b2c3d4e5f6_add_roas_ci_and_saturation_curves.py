"""add roas_ci and saturation_curves columns

Revision ID: a1b2c3d4e5f6
Revises: 53723658268c
Create Date: 2026-02-28

"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

# revision identifiers, used by Alembic.
revision = "a1b2c3d4e5f6"
down_revision = "53723658268c"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("model_runs", sa.Column("roas_ci", JSONB, nullable=True))
    op.add_column("model_runs", sa.Column("saturation_curves", JSONB, nullable=True))


def downgrade() -> None:
    op.drop_column("model_runs", "saturation_curves")
    op.drop_column("model_runs", "roas_ci")
