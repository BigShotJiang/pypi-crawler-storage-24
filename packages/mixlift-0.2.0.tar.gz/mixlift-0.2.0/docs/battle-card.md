# Battle Card: MixLift vs. The Field

**Subject:** Bayesian Marketing Mix Modeling (MMM)
**Use Case:** Competitive displacement & Objection handling

---

## 1. Elevator Pitch & Positioning

**The "Why MixLift" Narrative:**
"MixLift is the first self-serve, Bayesian MMM tool built for the modern Growth Director. We take the exact same open-source probabilistic programming used by enterprise giants (PyMC-Marketing), wrap it in an AI-native interface, and deliver it at 20% of the cost. We don't charge you for dashboards or account managers -- we charge for the math."

**Value Proposition:**
Enterprise-grade methodology without the enterprise overhead.

**Target Persona:**
- **Title:** Director/VP of Growth, Head of Performance.
- **Profile:** DTC eCommerce, $5M - $200M Revenue.
- **Pain:** "My last-click attribution is lying to me," "I can't afford a data scientist," and "Enterprise MMM tools cost $20k/year."

---

## 2. The Kill Zone: Competitor Comparison

| Feature | **MixLift** | **Prescient AI / Paramark** | **Triple Whale** | **Robyn / Meridian** |
| :--- | :--- | :--- | :--- | :--- |
| **Methodology** | **True Bayesian (PyMC)** | True Bayesian | MTA / Heuristic (Not True MMM) | True Bayesian |
| **Pricing** | **$299/mo** | $1,500 - $2,500+/mo | $500+/mo (Bundled) | Free (Labor cost is high) |
| **Setup Time** | **Minutes (Self-serve)** | Weeks (Custom onboarding) | Days (Pixel install) | Months (Dev/DS required) |
| **Data Privacy** | **100% Local (User's machine)** | Cloud-hosted | Cloud/Pixel-based | Local (Code) |
| **Interface** | **AI-Native (MCP/Claude)** | Custom Dashboards | Dashboard / "Summary" | Code / Notebook output |
| **Requirement** | **No Data Scientist needed** | No Data Scientist needed | No Data Scientist needed | **Requires Data Scientist** |

---

## 3. Competitive Displacement Playbook

### vs. Prescient AI / Paramark (The High-End Bayesian)

**The Attack:** "You are paying a premium for human labor (Account Managers) and custom visualization layers, not better math."

- **Weakness:** High OPEX cost ($18k+ annually) and slow iteration cycles due to "managed" service layers.
- **Kill Shot:** "Prescient uses PyMC, and so do we. If you don't need a consultant to hold your hand, why are you paying consultant prices? With MixLift, you get the model tomorrow, not in 3 weeks."

### vs. Triple Whale (The DTC Incumbent)

**The Attack:** "Triple Whale is an attribution dashboard (MTA), not a statistical model. It's great for tracking, not for budget prediction."

- **Weakness:** Reliance on pixel data (subject to iOS tracking limits) and lack of true Bayesian causal inference (e.g., diminishing returns).
- **Kill Shot:** "Triple Whale tells you what *happened* (with limited data). MixLift tells you what to *do next* using full probabilistic simulation. Don't navigate with a rear-view mirror."

### vs. Robyn (Meta) / Meridian (Google)

**The Attack:** "The software is free, but the talent to run it costs $150k/year."

- **Weakness:** High technical barrier. Requires knowledge of R/Python, Bayesian statistics, and significant dev time.
- **Kill Shot:** "We've wrapped the power of Robyn/Meridian into a SaaS layer. You don't need to hire a Data Scientist to run the model; you just need MixLift."

---

## 4. Objection Handling

### "Why should I trust a $299 tool over Prescient at $1,500?"

- **The Reality:** You aren't paying for better math at $1,500; you are paying for overhead.
- **The Handle:** "That is exactly why we built this. The enterprise players use the same open-source methodology we do (PyMC-Marketing). The price difference isn't the accuracy of the model -- it's that we don't have Account Managers flying out to visit you or building custom dashboards you might not need. We pass those savings directly to you."
- **Proof Point:** "We are $299 because we are AI-native and automated. Same math, zero bloat."

### "We don't have a data scientist. Is this too technical for us?"

- **The Handle:** "Most tools require you to interpret complex posterior distributions. MixLift is AI-native. We integrate directly with tools like Claude (via MCP) to let you ask plain English questions about your data. You don't need to know Python; you just need to know your business goals."

### "Is my data safe?"

- **The Handle:** "Safer than anywhere else. MixLift processes data locally on your machine. We don't store your row-level data on our cloud servers like Prescient or Triple Whale. Your sensitive revenue numbers never leave your laptop."

### "Does 'Free' actually work for real businesses?"

- **The Handle:** "The Free tier is for validation. Upload your data, run the model, and see the curve fitting. When you want to see the actual dollar-value ROI and scale to your full history, you upgrade. It's proof before purchase."

---

## 5. Qualifying Questions (BANT)

- **Budget:** "Are you currently spending over $500k/year on ads? (If yes, our tool pays for itself in <1 day of optimized spend)."
- **Authority:** "Do you control the budget allocation decisions, or do you have to ask a Finance/Data team?" (Target: You control the budget).
- **Need:** "Are you making budget decisions based on Facebook/Google Ads Manager numbers, or are you looking for an independent view?"
- **Timing:** "How quickly can you get 2 years of historical ad data into a CSV?" (If they can do it now, close now).

---

## 6. Proof Points & Differentiators

- **Methodology:** Built on **PyMC-Marketing**, the industry standard for probabilistic programming (same tech stack powering Google Meridian).
- **Innovation:** The only platform offering **MCP (Model Context Protocol)** integration -- allowing you to chat with your model inside Claude AI.
- **Privacy:** **Zero-Cloud-Retention** architecture. Data is processed in-memory, locally.
- **Economics:** **5x cheaper** than the nearest "True Bayesian" competitor.
- **Freedom:** No contracts. No onboarding fees. Month-to-month SaaS.

---

## 7. Closing Statement

"Stop guessing with last-click attribution and stop overpaying for enterprise 'managed services.' Get the same Bayesian rigor as the Fortune 500, run it on your own machine, and save $15,000 a year."
