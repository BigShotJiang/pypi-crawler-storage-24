# MixLift Ideal Customer Profile (ICP)

**Target:** First 20 Design Partners
**Product:** MixLift (Bayesian MMM)
**Price:** $299/mo

---

## 1. ICP Definition: "The Measurement-Constrained Scaler"

The ideal target for MixLift's first 20 accounts is a DTC brand that has graduated from "growth hacking" and is now in the "optimization phase." They are spending significant capital on paid media ($1M+ year) but lack the internal technical resources (Data Scientists) to understand the true marginal ROI of that spend.

**The Core Conflict:** They are sophisticated enough to know that platform attribution (last-click) is lying to them, but they are too lean to hire a $200k/year data analyst to build a custom MMM solution. They are currently flying blind on cross-channel budget allocation.

---

## 2. Firmographic Criteria (Must-Haves)

*These are the non-negotiable data points used to build initial prospect lists.*

- **Industry:** B2C eCommerce (Direct-to-Consumer).
- **Annual Revenue:** $10M - $80M.
  - *Why?* Under $10M usually lacks data volume for statistical significance. Over $80M likely has an internal BI team or enterprise contracts with consultancies like Measured/Recast.
- **Media Spend:** $100k - $400k/month ($1.2M - $5M annually).
- **Tech Stack:**
  - Shopify Plus (primary indicator of scale).
  - Triple Whale/Northbeam (indicates they care about attribution but may be frustrated by "black box" pixel data).
- **Team Structure:**
  - **No** dedicated "Data Scientist" or "Marketing Scientist" on LinkedIn headcount.
  - Has a "Director of Growth," "VP of Marketing," or "Head of DTC."

---

## 3. Behavioral Signals (Intent Data)

*Actions that indicate a prospect is "in-market" for a measurement solution.*

- **The "Attribution Rant":** The decision-maker has posted on LinkedIn or Twitter about iOS14, cookie deprecation, or the death of last-click attribution.
- **Channel Expansion:** Recently launched on a new channel (e.g., Started TikTok Ads, Started a Podcast, or OOH/TV) and is struggling to measure the halo effect on Meta/Google.
- **Hiring Signal:** Job posting for a "Performance Marketing Manager" or "Marketing Analyst" that mentions "incrementality," "attribution," or "mixed methods."
- **Tech Swap:** Recently installed or uninstalled an attribution tool (via BuiltWith or PipeCandy data).
- **Agency Dependence:** Heavy reliance on a performance agency, but the internal team wants to verify the agency's recommendations with independent data.

---

## 4. Vertical Sweet Spots

*These verticals have the ideal mix of high repeat purchase rates and complex customer journeys.*

### A. Beauty & Skincare
- **Why:** High competition on Meta/TikTok necessitates precise budget allocation.
- **Trigger:** Blended ROAS is dropping, but they can't tell if it's creative fatigue or channel saturation.

### B. Supplements & Wellness
- **Why:** Subscription models mean LTV is more important than first-order profitability. MixLift helps model the long tail.
- **Trigger:** Running aggressive "Challenge" campaigns or Podcast ads that don't convert immediately.

### C. Apparel (Fashion/Athleisure)
- **Why:** Seasonality is massive. They need to know how much brand spend drives Q4 sales.
- **Trigger:** Scaling past the founder-led growth phase where "vibe" marketing isn't working anymore.

### D. Home Goods & Decor
- **Why:** High AOV leads to longer consideration windows.
- **Trigger:** Investing in Google Shopping + Meta and unsure which channel initiates the journey.

### E. Pet Brands
- **Why:** Passionate founders who are hands-on but often lack technical marketing backgrounds.
- **Trigger:** Expansion into big box retail (Target/Whole Foods) and needing to understand how retail impacts DTC sales.

---

## 5. Disqualification Criteria (Anti-ICP)

*Do not target these accounts to save time.*

- **Pure Marketplace Sellers:** Brands doing >50% of revenue on Amazon (cannot track attribution effectively).
- **Low Ad Spend:** Under $80k/month (MMM models will be too noisy/unstable).
- **Enterprise/Bloat:** Brands with >200 employees (sales cycle is too long for the first 20 accounts).
- **Single Channel:** Brands running 100% on Meta or 100% on Google. MixLift needs channel variance to work.
- **B2B SaaS:** Sales cycles are too long for transactional DTC MMM modeling.

---

## 6. Where to Find Them

**LinkedIn (Primary):**
- **Search Queries:** "Head of Growth" AND "Shopify" AND "DTC"; "VP Marketing" AND "Skincare"; "Director of DTC" AND "Apparel".
- **Activity:** Look for commenters on posts by influencers like Nik Sharma, Moiz Ali, or Eric Seufert.

**Twitter / X:**
- **Communities:** "DTC Twitter," "EcomCircle."
- **Keywords:** Search for "attribution is broken," "ROAS is vanity," or "MMM."

**Podcasts (Listener Targeting):**
- *My First Million*, *Acquired*, *Ecommerce Fuel*, *DTC Newsletter Podcast*. Look for guests who fit the profile or sponsors of these shows.

**Agency Partnerships:**
- Cold outreach to boutique media buying agencies (5-20 employees) that manage $1M+ spend. Offer them a "Powered by MixLift" value prop to intro the tool to their clients.

---

## 7. Account Scoring Rubric

*Use this to prioritize the top 20 accounts from a list of 100 prospects.*

| Criteria | Weight | Score (1-5) | Description |
| :--- | :--- | :--- | :--- |
| **Ad Spend Volume** | **30%** | 5 = $5M+/yr, 1 = $1M/yr | Must have enough data points for Bayesian model. |
| **Channel Mix** | **25%** | 5 = 4+ channels, 1 = 2 channels | The more channels, the harder the attribution problem. |
| **Tech Sophistication** | **15%** | 5 = Uses Triple Whale/Northbeam, 1 = GA4 only | Indicates budget for tools and a culture of measurement. |
| **Persona Presence** | **15%** | 5 = Active on LI/Twitter, 1 = No social footprint | Active buyers are easier to cold outreach via DM/InMail. |
| **Vertical Fit** | **15%** | 5 = Beauty/Supps, 1 = Electronics | Prioritize "Sweet Spots" for case study relevance. |

**Total Score Calculation:** (Score x Weight) = Final Score.
**Target:** Only outreach to accounts scoring **> 4.2 / 5.0**.
