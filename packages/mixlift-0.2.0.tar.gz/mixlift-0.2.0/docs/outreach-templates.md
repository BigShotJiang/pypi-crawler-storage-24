# LinkedIn Outreach Templates

5 templates for founder-led sales. Each uses a different angle.
CTA is always a 15-minute live demo on their data.

---

## 1. The "Price Anchor"

**Hook:** MMM for $299/mo (vs $1,500+)

**When to use:** Prospects who are cost-conscious or currently in a trial with a high-end competitor.

**Message:**

> Hi [Name],
>
> I know tools like Prescient AI or Paramark are the standard for Marketing Mix Modeling, but the $1,500+/mo price tag is a tough pill to swallow for most DTC brands.
>
> I built MixLift to solve that. We use the exact same Bayesian methodology, but because we deliver it through a Claude AI interface (and skip the flashy dashboards), we can offer it for $299/mo.
>
> Your data stays local, and you get the same strategic output for 1/5th of the cost.
>
> I'm running 15-minute live demos where I analyze a prospect's actual data. Want to see if we can spot some wasted spend in your accounts?

---

## 2. The "Pain Point"

**Hook:** Your ROAS is lying to you

**When to use:** VPs of Growth who are actively complaining about attribution or "black box" ad performance.

**Message:**

> Hi [Name],
>
> Post-iOS 14.5, relying on platform attribution is a gamble. You're likely over-investing in channels that look good on paper but are actually burning cash.
>
> You need Bayesian MMM to see the true incrementality of your spend, but usually, that requires a data science team or an enterprise SaaS contract.
>
> MixLift fixes this. We give you enterprise-grade modeling for $299/mo. It takes 5 minutes to set up.
>
> I'm offering a "concierge demo" -- I'll run the model live on your data for 15 minutes so you can see the blind spots immediately.
>
> Open to taking a look?

---

## 3. The "Social Proof / Results"

**Hook:** Found $47k in wasted spend in 5 minutes

**When to use:** Numbers-driven prospects who need to see ROI before committing to a conversation.

**Message:**

> Hi [Name],
>
> I recently ran a MixLift analysis for a DTC brand in the $15M revenue range. Using our Bayesian modeling, we identified $47,000/month being wasted on under-performing channels -- money they immediately reallocated to profitable growth.
>
> The best part? It took 5 minutes to find it.
>
> I'm looking to replicate this for a few other brands in the $5M-$200M range.
>
> I'd love to run a free, 15-minute analysis on your actual data over Zoom. No pitch decks, just the numbers.
>
> Worth a quarter of an hour to find the waste?

---

## 4. The "Curiosity / Pattern Interrupt"

**Hook:** a weird question about your ad budget

**When to use:** Prospects with "SaaS fatigue" who are tired of complex sales cycles and expensive contracts.

**Message:**

> Hi [Name],
>
> Most VPs of Growth I talk to are paying $20k+/year for MMM tools that they barely log into.
>
> I'm trying to prove that you can get the same Bayesian insights without the enterprise overhead.
>
> I built MixLift as an AI-native tool (powered by Claude). It runs locally on your machine, costs $299/mo, and delivers the analysis instantly.
>
> I'm not trying to be a standard SaaS vendor; I'm doing concierge onboarding personally.
>
> Up for a 15-minute experiment? I'll run MixLift on your CSV exports right now.

---

## 5. The "Warm Referral"

**Hook:** [Mutual Connection] suggested I reach out

**When to use:** Only when you have a legitimate mutual connection who gave permission to name-drop or suggested the intro.

**Message:**

> Hi [Name],
>
> [Mutual Connection] mentioned you're scaling [Company Name] pretty aggressively right now and might be hitting some attribution walls.
>
> They thought you'd be interested in what we're doing at MixLift. We provide Bayesian Marketing Mix Modeling for $299/mo -- about 5x cheaper than the incumbents like Paramark, but with the same statistical rigor.
>
> Since [Mutual Connection] spoke so highly of your growth strategy, I'd love to offer you a private demo.
>
> I'll run the analysis on your actual data live on Zoom (15 mins max). Let me know if you're game?
