# MixLift

**Find the wasted dollars in your ad budget. In 5 minutes. For $299/month.**

MixLift is a marketing mix model that runs inside Claude. Give it a CSV of your weekly ad spend and revenue, and it tells you exactly which channels are overspent, which are underspent, and how to reallocate for more revenue. No dashboards to learn, no analysts to hire — just ask Claude a question and get an answer.

---

## Quick Start

Three steps. Five minutes. No data science degree required.

### Step 1: Install MixLift

Open your terminal (on Mac: search for "Terminal" in Spotlight) and paste this command:

```bash
pip install mixlift
```

Not sure if you have Python? Run this first:

```bash
python3 --version
```

You need Python 3.11 or higher. If you see something like `Python 3.11.5` or `Python 3.12.0`, you're good. If you get an error or see a version below 3.11, install Python from [python.org/downloads](https://www.python.org/downloads/).

### Step 2: Connect MixLift to Claude Desktop

MixLift works as a tool inside Claude Desktop. You need to tell Claude where to find it.

**On macOS**, open Terminal and paste:

```bash
open ~/Library/Application\ Support/Claude/claude_desktop_config.json
```

**On Windows**, open File Explorer and go to:

```
%APPDATA%\Claude\claude_desktop_config.json
```

Add or replace the contents with:

```json
{
  "mcpServers": {
    "mixlift": {
      "command": "mixlift-mcp"
    }
  }
}
```

If the file already has other servers, just add the `"mixlift"` block inside `"mcpServers"`.

Save the file and **restart Claude Desktop** (quit and reopen it).

### Step 3: Try It

Open Claude Desktop and type:

> **Run mixlift_analyze with no arguments**

Claude will run MixLift on a built-in demo dataset and show you channel performance, ROAS, and budget recommendations. If you see results, everything is working.

---

## What You Get

- **"Move $3,200 from Google to Meta for +12% revenue"** — Ranked budget reallocation recommendations you can act on today
- **Return on ad spend per channel** — See which channels earn the most per dollar, with confidence ranges (not just point estimates)
- **Diminishing returns analysis** — Know exactly where each channel starts wasting money (marginal ROAS)
- **Optimal budget split** — The mathematically best allocation across all your channels, with expected revenue lift
- **Saturation curves** — Visual proof of where you're overspending and where there's headroom
- **Model quality checks** — Convergence diagnostics so you can trust the numbers

---

## Your Data

### CSV Format

The simplest format is a spreadsheet with one row per week:

| date | google_ads_spend | meta_spend | tiktok_spend | revenue |
|------|-----------------|------------|-------------|---------|
| 2025-09-01 | 5243.77 | 5658.76 | 1991.60 | 61475.19 |
| 2025-09-08 | 4237.89 | 7190.88 | 1825.93 | 59907.05 |

Rules:
- A `date` column (weekly dates work best — at least 26 weeks of data)
- One or more columns ending in `_spend` for your ad channels
- A `revenue`, `sales`, or `target` column

Export your data from your ad platform, drop it into a spreadsheet, and save as CSV. That's it.

A sample CSV is included at `tests/fixtures/sample_marketing_data.csv` if you want to see the exact format.

### Supported Exports

- Meta Ads Manager
- Google Ads
- TikTok Ads

### Need Help Formatting?

Ask Claude: *"Help me prepare my marketing data CSV for MixLift."* Claude can walk you through exporting from your ad platform and combining the data into a single file.

---

## Pricing

| Plan | Channels | Data Rows | Runs | Price |
|------|----------|-----------|------|-------|
| **Free** | 2 | 2,000 | 2/month | $0 |
| **Growth** | 8 | 50,000 | Unlimited | $299/month |

Start free. Upgrade when you need more channels or runs: [mixlift.io/pricing](https://mixlift.io/pricing)

---

## How It Works

1. You give Claude a CSV of your weekly ad spend and revenue
2. MixLift fits a Bayesian model to your data using MCMC sampling (~30-60 seconds)
3. The model learns how each channel drives revenue, including diminishing returns
4. An optimizer finds the best way to reallocate your budget
5. Claude returns the results in plain English with specific dollar recommendations

Under the hood, MixLift uses [PyMC-Marketing](https://github.com/pymc-labs/pymc-marketing), the same Bayesian framework used by data science teams at large brands. You get the same methodology without needing a data scientist.

---

## Headless Python API

If you want to use MixLift from your own Python code (no Claude required):

```python
from mixlift import analyze

results = analyze("data.csv")
```

The `results` dictionary contains channel ROAS, marginal ROAS, optimal budget allocation, and recommendations.

---

## Scenario Mode

Ask Claude "what if" questions about your budget:

> "What happens if I cut Meta spend by 20%?"

> "Move $5,000 from Google to TikTok and show me the impact."

> "What's the optimal budget if I increase total spend by $10,000/month?"

MixLift runs the scenario through the model and shows you the projected revenue change.

---

## Support

Questions or issues? Open a ticket: [GitHub Issues](https://github.com/mixlift/mixlift/issues)

---

## License

MIT
