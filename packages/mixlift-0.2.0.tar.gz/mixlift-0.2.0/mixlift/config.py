"""Application configuration via environment variables."""

from pathlib import Path

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # App
    app_name: str = "MixLift"
    environment: str = "development"
    debug: bool = False

    # Auth
    secret_key: str = "dev-only-not-for-production"

    @property
    def validated_secret_key(self) -> str:
        """Return secret key, raising in production if still using default."""
        if self.environment == "production" and self.secret_key == "dev-only-not-for-production":
            raise ValueError("SECRET_KEY must be set in production. Set the SECRET_KEY env var.")
        return self.secret_key
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 60
    refresh_token_expire_days: int = 30

    # Database
    database_url: str = "postgresql+asyncpg://mixlift:mixlift_dev@localhost:5432/mixlift"

    # Storage
    data_dir: Path = Path("data")
    upload_dir: Path = Path("data/uploads")
    model_dir: Path = Path("data/models")

    # Frontend
    frontend_url: str = "http://localhost:8501"

    # Stripe (paid tier)
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    stripe_pro_price_id: str = ""

    # Modeling defaults
    mcmc_chains: int = 4
    mcmc_tune: int = 1000
    mcmc_draws: int = 500
    adstock_l_max: int = 8
    yearly_seasonality: int = 6

    # Tier limits
    free_max_rows: int = 2000
    free_max_channels: int = 2
    free_max_runs_per_month: int = 2
    free_max_projects: int = 3

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()


def ensure_directories() -> None:
    """Create data directories on first use (not on import)."""
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    settings.model_dir.mkdir(parents=True, exist_ok=True)
