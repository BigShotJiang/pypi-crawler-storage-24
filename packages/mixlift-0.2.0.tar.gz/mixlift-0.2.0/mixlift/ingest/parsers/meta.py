"""Parser for Meta (Facebook/Instagram) Ads CSV exports."""

import pandas as pd

from mixlift.ingest.templates import PLATFORM_SIGNATURES


def parse_meta_csv(df: pd.DataFrame) -> pd.DataFrame:
    """Parse a Meta Ads CSV into canonical format.

    Returns DataFrame with columns: date, channel, spend, impressions, clicks, conversions
    """
    col_map = _find_columns(df)

    result = pd.DataFrame()
    result["date"] = pd.to_datetime(df[col_map["date"]])

    # Use campaign name as channel, fallback to "Meta"
    if col_map.get("campaign"):
        result["channel"] = df[col_map["campaign"]].str.strip()
    else:
        result["channel"] = "Meta"

    result["spend"] = pd.to_numeric(df[col_map["spend"]], errors="coerce").fillna(0)
    result["impressions"] = (
        pd.to_numeric(df[col_map["impressions"]], errors="coerce").fillna(0).astype(int)
    )
    result["clicks"] = (
        pd.to_numeric(df[col_map["clicks"]], errors="coerce").fillna(0).astype(int)
    )

    if col_map.get("conversions"):
        result["conversions"] = (
            pd.to_numeric(df[col_map["conversions"]], errors="coerce").fillna(0).astype(int)
        )
    else:
        result["conversions"] = 0

    return result


def _find_columns(df: pd.DataFrame) -> dict[str, str]:
    """Match DataFrame columns to expected Meta column names."""
    lower_cols = {c.lower().strip(): c for c in df.columns}
    meta_cols = PLATFORM_SIGNATURES["meta"]["columns"]

    col_map = {}
    for field, aliases in meta_cols.items():
        for alias in aliases:
            if alias.lower() in lower_cols:
                col_map[field] = lower_cols[alias.lower()]
                break

    required = ["date", "spend", "impressions", "clicks"]
    missing = [f for f in required if f not in col_map]
    if missing:
        raise ValueError(f"Meta CSV missing required columns: {missing}")

    return col_map
