"""Result response schemas."""

from pydantic import BaseModel


class RecommendationItem(BaseModel):
    rank: int
    action: str
    channel: str
    change_amount: float
    current_spend: float
    optimal_spend: float
    roas: float
    reason: str


class RecommendationsResponse(BaseModel):
    run_id: str
    status: str
    expected_lift_pct: float | None
    summary: str | None
    recommendations: list[RecommendationItem]
    current_allocation: dict[str, float] | None
    optimal_allocation: dict[str, float] | None
