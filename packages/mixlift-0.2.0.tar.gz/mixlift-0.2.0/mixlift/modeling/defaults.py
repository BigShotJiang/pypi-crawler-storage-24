"""Opinionated default configuration for the MMM model."""

# random_seed is intentionally omitted from all configs below.
# Fixed seeds mask sampling variability and prevent convergence diagnostics
# (e.g. R-hat) from being truly diagnostic. Each run should explore
# independent regions of the posterior.

# MCMC sampler settings (balance speed vs quality)
DEFAULT_MCMC_CONFIG = {
    "chains": 4,
    "tune": 1000,
    "draws": 500,
    "target_accept": 0.9,
}

# Adstock settings
DEFAULT_ADSTOCK_CONFIG = {
    "type": "geometric",  # simplest, 1 parameter. Weibull in v2.
    "l_max": 8,  # max lag in weeks
}

# Saturation settings
DEFAULT_SATURATION_CONFIG = {
    "type": "logistic",
}

# Seasonality
DEFAULT_SEASONALITY = {
    "yearly_seasonality": 6,  # number of Fourier terms (captures monthly-scale patterns for DTC retail)
}

# Model fitting
FAST_CONFIG = {
    "chains": 4,
    "tune": 500,
    "draws": 250,
    "target_accept": 0.90,
}

# MCP config: 4 chains x 250 draws for reliable R-hat diagnostics.
# 4 chains required for reliable R-hat. target_accept=0.90 reduces divergences.
MCP_CONFIG = {
    "chains": 4,
    "tune": 500,
    "draws": 250,
    "target_accept": 0.90,
}
