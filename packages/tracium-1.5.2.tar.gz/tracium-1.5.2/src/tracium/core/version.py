"""
Version information for Tracium SDK.
"""

__version__ = "1.5.2"
