from .service import PIWebAPIService
from .config import get_settings, WebAPISettings
from typing import Optional

def get_service(
    env_path: Optional[str] = None,
    url: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    verify_ssl: Optional[bool] = None,
    server_name: Optional[str] = None
) -> PIWebAPIService:
    """
    Factory function to get the PI Web API service.
    Can be configured via .env file or by passing parameters directly.
    """
    settings = get_settings(
        env_path=env_path,
        url=url,
        username=username,
        password=password,
        verify_ssl=verify_ssl,
        server_name=server_name
    )
    return PIWebAPIService(settings)

__all__ = ["PIWebAPIService", "get_service", "WebAPISettings"]
