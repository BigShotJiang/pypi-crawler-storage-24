from abc import ABC, abstractmethod
from typing import Any, List, Dict, AsyncGenerator

class PIServiceBase(ABC):
    """
    Abstract Base Class for PI Data Services.
    """

    @abstractmethod
    async def get_current_value(self, tag_name: str) -> Dict[str, Any]:
        """Fetch the current value for a given PI tag."""
        pass

    @abstractmethod
    async def get_real_time_data(self, tag_name: str) -> Dict[str, Any]:
        """Fetch real-time data for a PI tag."""
        pass

    @abstractmethod
    async def get_live_data_stream(self, tag_name: str, interval_seconds: int = 300) -> AsyncGenerator[Dict[str, Any], None]:
        """Yield real-time data periodically."""
        pass

    @abstractmethod
    async def get_recorded_values(self, tag_name: str, start_time: str, end_time: str) -> List[Dict[str, Any]]:
        """Fetch historical recorded values for a PI tag."""
        pass

    @abstractmethod
    async def write_value(self, tag_name: str, value: Any, timestamp: Any = None) -> bool:
        """Write a value to a PI tag."""
        pass

    @abstractmethod
    async def search_tags(self, query: str) -> List[str]:
        """Search for PI tags based on a query string."""
        pass

    @abstractmethod
    async def get_asset_servers(self) -> List[str]:
        """Fetch the names of the AF Asset Servers (PISystems)."""
        pass

    @abstractmethod
    async def get_organizations(self, asset_server: str) -> List[str]:
        """Fetch the names of the Databases (Organizations) for a given Asset Server."""
        pass

    @abstractmethod
    async def test_connection(self) -> Dict[str, Any]:
        """Test if the connection to PI is active and working."""
        pass
