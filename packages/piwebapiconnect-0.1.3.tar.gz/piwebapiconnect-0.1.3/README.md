# piwebapiconnect

A professional Python library for PI Web API integration.

## Installation

```bash
pip install piwebapiconnect
```

## Usage

### Using .env file

Create a `.env` file in your project root with the following variables:

```env
PI_WEB_API_URL=https://your-pi-server/piwebapi
PI_WEB_API_USERNAME=domain\user
PI_WEB_API_PASSWORD=your-password
PI_SERVER_NAME=PISERVER01
PI_WEB_API_VERIFY_SSL=True  # Optional, defaults to True
```

```python
from piwebapiconnect import get_service
service = get_service()
```

## Functions Provided

All service functions are **asynchronous**.

- `get_current_value(tag_name: str)`: Fetch the current value for a given PI tag.
- `get_recorded_values(tag_name: str, start_time: str, end_time: str)`: Fetch historical (recorded) values for a time range.
- `write_value(tag_name: str, value: Any, timestamp: Any = None)`: Write a value for a PI tag.
- `search_tags(query: str)`: Search for PI tags based on a query pattern.
- `get_asset_servers()`: List available PI AF System (Asset Server) names.
- `get_organizations(asset_server: str)`: List AF Databases (Organizations) on a specific Asset Server.
- `test_connection()`: Verify the connection status to the PI Web API.
- `close()`: Close the underlying HTTP client.

### Passing credentials directly

```python
from piwebapiconnect import get_service
import asyncio
service = get_service(
    url="https://your-pi-server/piwebapi",
    username="domain\\user",
    password="your-password",
    server_name="PISERVER01",
    verify_ssl=False  # Optional
)

async def main():
    val = await service.get_current_value("YourTagName")
    print(val)

if __name__ == "__main__":
    asyncio.run(main())
```
