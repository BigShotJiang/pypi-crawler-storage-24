"""Tests for orc/conflict.py — ConflictResolver."""

from __future__ import annotations

from unittest.mock import patch

import pytest
import typer

import orc.config as _cfg
import orc.context as _ctx
import orc.git as _git
from orc.conflict import ConflictResolver

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_resolver():
    """Return a ConflictResolver with a minimal stub SquadConfig."""

    class FakeSquad:
        def model(self, role: str) -> str:
            return "test-model"

    return ConflictResolver(squad_cfg=FakeSquad(), messages=[])


# ---------------------------------------------------------------------------
# resolve_merge_conflict
# ---------------------------------------------------------------------------


class TestResolveMergeConflict:
    def test_success(self, tmp_path, monkeypatch):
        """Coder resolves conflict, merge completes, no exception raised."""
        monkeypatch.setattr(_cfg, "WORK_DEV_BRANCH", "dev")
        resolver = _make_resolver()

        with (
            patch.object(_ctx, "build_agent_context", return_value=("model", "ctx")),
            patch.object(_ctx, "invoke_agent", return_value=0),
            patch.object(_git, "_merge_in_progress", return_value=False),
        ):
            # Should NOT raise
            resolver.resolve_merge_conflict("feat/task", tmp_path, "M src/foo.py")

    def test_coder_nonzero_raises_exit(self, tmp_path, monkeypatch):
        """Coder exits non-zero → typer.Exit raised."""
        monkeypatch.setattr(_cfg, "WORK_DEV_BRANCH", "dev")
        resolver = _make_resolver()

        with (
            patch.object(_ctx, "build_agent_context", return_value=("model", "ctx")),
            patch.object(_ctx, "invoke_agent", return_value=1),
        ):
            with pytest.raises(typer.Exit):
                resolver.resolve_merge_conflict("feat/task", tmp_path, "M src/foo.py")

    def test_merge_still_in_progress_raises_exit(self, tmp_path, monkeypatch):
        """Coder succeeds but merge still in progress → typer.Exit raised."""
        monkeypatch.setattr(_cfg, "WORK_DEV_BRANCH", "dev")
        resolver = _make_resolver()

        with (
            patch.object(_ctx, "build_agent_context", return_value=("model", "ctx")),
            patch.object(_ctx, "invoke_agent", return_value=0),
            patch.object(_git, "_merge_in_progress", return_value=True),
        ):
            with pytest.raises(typer.Exit):
                resolver.resolve_merge_conflict("feat/task", tmp_path, "M src/foo.py")


# ---------------------------------------------------------------------------
# resolve_rebase_conflict
# ---------------------------------------------------------------------------


class TestResolveRebaseConflict:
    def test_success(self, tmp_path, monkeypatch):
        """Coder resolves rebase conflict, no exception raised."""
        monkeypatch.setattr(_cfg, "WORK_DEV_BRANCH", "dev")
        resolver = _make_resolver()

        with (
            patch.object(_ctx, "build_agent_context", return_value=("model", "ctx")),
            patch.object(_ctx, "invoke_agent", return_value=0),
            patch.object(_git, "_rebase_in_progress", return_value=False),
        ):
            resolver.resolve_rebase_conflict(tmp_path, "M src/foo.py")

    def test_coder_nonzero_raises_exit(self, tmp_path, monkeypatch):
        monkeypatch.setattr(_cfg, "WORK_DEV_BRANCH", "dev")
        resolver = _make_resolver()

        with (
            patch.object(_ctx, "build_agent_context", return_value=("model", "ctx")),
            patch.object(_ctx, "invoke_agent", return_value=2),
        ):
            with pytest.raises(typer.Exit):
                resolver.resolve_rebase_conflict(tmp_path, "UU src/bar.py")

    def test_rebase_still_in_progress_raises_exit(self, tmp_path, monkeypatch):
        monkeypatch.setattr(_cfg, "WORK_DEV_BRANCH", "dev")
        resolver = _make_resolver()

        with (
            patch.object(_ctx, "build_agent_context", return_value=("model", "ctx")),
            patch.object(_ctx, "invoke_agent", return_value=0),
            patch.object(_git, "_rebase_in_progress", return_value=True),
        ):
            with pytest.raises(typer.Exit):
                resolver.resolve_rebase_conflict(tmp_path, "UU src/bar.py")
