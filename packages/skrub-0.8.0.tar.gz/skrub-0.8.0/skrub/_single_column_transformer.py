"""Base class for single-column transformers."""

import functools
import re
import textwrap

from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline
from sklearn.utils.validation import check_is_fitted

from . import _dataframe as sbd
from . import _utils

__all__ = ["SingleColumnTransformer", "RejectColumn"]

_SINGLE_COL_LINE = (
    "``{class_name}`` is a type of single-column transformer. Unlike most scikit-learn"
    " estimators, its ``fit``, ``transform`` and ``fit_transform`` methods expect a"
    " single column (a pandas or polars Series) rather than a full dataframe. To apply"
    " this transformer to one or more columns in a dataframe, use it as a parameter in"
    " a ``skrub.ApplyToCols`` or a ``skrub.TableVectorizer``.\n\n"
    "To apply to all columns::\n\n"
    "   ApplyToCols({class_name}())\n\n"
    "To apply to selected columns::\n\n"
    "   ApplyToCols({class_name}(), cols=['col_name_1', 'col_name_2'])"
)
_SINGLE_COL_PARAGRAPH = textwrap.indent(_SINGLE_COL_LINE, prefix=" " * 4)
_SINGLE_COL_NOTE = f".. note::\n\n{_SINGLE_COL_PARAGRAPH}\n"


@_utils.set_module("skrub.core")
class RejectColumn(ValueError):
    """Used by single-column transformers to indicate they do not apply to a column.

    Examples
    ----------
    A :class:`SingleColumnTransformer` can raise ``RejectColumn`` exceptions
    to indicate it cannot handle a given column.

    >>> from skrub import ToDatetime
    >>> import pandas as pd
    >>> df = pd.DataFrame(dict(birthday=["29/01/2024"], city=["London"]))
    >>> df
         birthday    city
    0  29/01/2024  London
    >>> df.dtypes
    birthday    ...
    city        ...
    dtype: object
    >>> ToDatetime().fit_transform(df["birthday"])
    0   2024-01-29
    Name: birthday, dtype: datetime64[...]
    >>> ToDatetime().fit_transform(df["city"])
    Traceback (most recent call last):
        ...
    skrub.core.RejectColumn: Could not find a datetime format...

    ``RejectColumn`` exceptions can be used to indicate that a column cannot be
    handled by the current transformer: this may mean that the data is invalid,
    or that the transformer is simply not designed to handle that type of data.
    For example, a ``ToDatetime`` transformer might raise ``RejectColumn`` when it is
    passed a column that does not contain strings, or that contains strings but none
    of them look like dates.

    :class:`ApplyToCols` relies on these exceptions to decide whether a column should be
    transformed or passed through unchanged.

    How these rejections are handled depends on the ``allow_reject`` parameter.
    By default, no special handling is performed and rejections are considered
    to be errors:

    >>> from skrub import ApplyToCols
    >>> to_datetime = ApplyToCols(ToDatetime())
    >>> to_datetime.fit_transform(df)
    Traceback (most recent call last):
        ...
    ValueError: Transformer ToDatetime.fit_transform failed on column 'city'...

    However, setting ``allow_reject=True`` gives the transformer itself some
    control over which columns it should be applied to. For example, whether a
    string column contains dates is only known once we try to parse them.
    Therefore it might be sensible to try to parse all string columns but allow
    the transformer to reject those that, upon inspection, do not contain dates.

    >>> to_datetime = ApplyToCols(ToDatetime(), allow_reject=True)
    >>> transformed = to_datetime.fit_transform(df)
    >>> transformed
        birthday    city
    0 2024-01-29  London

    Now the column 'city' was rejected but this was not treated as an error;
    'city' was passed through unchanged and only 'birthday' was converted to a
    datetime column.

    >>> transformed.dtypes
    birthday    datetime64[...]
    city                ...
    dtype: object
    >>> to_datetime.transformers_
    {'birthday': ToDatetime()}

    >>> from skrub import ToDatetime
    >>> df = pd.DataFrame(dict(a=['2020-02-02'], b=[12.5]))
    >>> ToDatetime().fit_transform(df['a'])
    0   2020-02-02
    Name: a, dtype: datetime64[...]
    >>> ToDatetime().fit_transform(df['b'])
    Traceback (most recent call last):
        ...
    skrub.core.RejectColumn: Column 'b' does not contain strings.
    """

    pass


class SingleColumnTransformer(BaseEstimator):
    """Base class for single-column transformers.

    Such transformers are applied independently to each column by
    ``ApplyToCols``; see the docstring of ``ApplyToCols`` for more
    information.

    Single-column transformers are not required to inherit from this class in
    order to work with ``ApplyToCols``, however doing so avoids some
    boilerplate:

    - The required ``__single_column_transformer__`` attribute is set.
    - ``fit`` is defined (calls ``fit_transform`` and discards the result).
    - ``fit``, ``transform`` and ``fit_transform`` are wrapped to check
        that the input is a single column and raise a ``ValueError`` with a
        helpful message when it is not.
    - A note about single-column transformers (vs dataframe transformers)
        is added after the summary line of the docstring.

    Subclasses must define ``fit_transform`` and ``transform`` (or inherit them
    from another superclass).
    """

    __single_column_transformer__ = True

    def set_output(self, *, transform=None):
        """
        Default no-op implementation for set_output.

        Skrub transformers already output dataframes of the correct type by
        default so there is usually no need for set_output to do anything.

        Subclasses are of course free to redefine set_output (e.g. by
        inheriting from TransformerMixin before SingleColumnTransformer).

        Parameters
        ----------
        transform : str or None, default=None
            Ignored.

        Returns
        -------
        SingleColumnTransformer
            Returns self.
        """
        return self

    def fit(self, column, y=None, **kwargs):
        """Fit the transformer.

        This default implementation simply calls ``fit_transform()`` and
        returns ``self``.

        Subclasses should implement ``fit_transform`` and ``transform``.

        Parameters
        ----------
        column : a pandas or polars Series
            Unlike most scikit-learn transformers, single-column transformers
            transform a single column, not a whole dataframe.

        y : column or dataframe
            Prediction targets.

        **kwargs
            Extra named arguments are passed to ``self.fit_transform()``.

        Returns
        -------
        self
            The fitted transformer.
        """
        self.fit_transform(column, y=y, **kwargs)
        return self

    def _check_single_column(self, column, function_name):
        class_name = self.__class__.__name__
        if sbd.is_dataframe(column):
            if sbd.shape(column)[1] == 1:
                # Dataframes containing just 1 column are accepted and silently
                # converted to a column.
                return sbd.col_by_idx(column, 0)
            raise ValueError(
                f"``{class_name}.{function_name}`` should be passed a single column,"
                " not a dataframe. " + _SINGLE_COL_LINE.format(class_name=class_name)
            )
        if not sbd.is_column(column):
            raise ValueError(
                f"``{class_name}.{function_name}`` expects the first argument X "
                "to be a column (a pandas or polars Series). "
                f"Got X with type: {column.__class__.__name__}."
            )
        return column

    def __init_subclass__(subclass, **kwargs):
        super().__init_subclass__(**kwargs)
        if subclass.__doc__ is not None:
            subclass.__doc__ = _insert_after_first_paragraph(
                subclass.__doc__,
                _SINGLE_COL_NOTE.format(class_name=subclass.__name__),
            )
        for method in "fit", "fit_transform", "transform", "partial_fit":
            if method in subclass.__dict__:
                wrapped = _wrap_add_check_single_column(getattr(subclass, method))
                setattr(subclass, method, wrapped)

    def get_feature_names_out(self, input_features=None):
        """Get the output feature names.

        Parameters
        -----------
        input_features : array-like of str, default=None
            Input feature names. Ignored.

        Returns
        --------
        list of str
            The names of the output features.
        """
        check_is_fitted(self, "all_outputs_")
        return self.all_outputs_


def _wrap_add_check_single_column(f):
    # as we have only a few predefined functions to handle, using their exact
    # name and signature in the wrapper definition gives better tracebacks and
    # autocompletion than just functools.wraps / setting __name__ and
    # __signature__
    if f.__name__ == "fit":

        @functools.wraps(f)
        def fit(self, X, y=None, **kwargs):
            X = self._check_single_column(X, f.__name__)
            return f(self, X, y=y, **kwargs)

        return fit
    elif f.__name__ == "partial_fit":

        @functools.wraps(f)
        def partial_fit(self, X, y=None, **kwargs):
            X = self._check_single_column(X, f.__name__)
            return f(self, X, y=y, **kwargs)

        return partial_fit

    elif f.__name__ == "fit_transform":

        @functools.wraps(f)
        def fit_transform(self, X, y=None, **kwargs):
            X = self._check_single_column(X, f.__name__)
            return f(self, X, y=y, **kwargs)

        return fit_transform
    else:
        assert f.__name__ == "transform", f.__name__

        @functools.wraps(f)
        def transform(self, X, **kwargs):
            X = self._check_single_column(X, f.__name__)
            return f(self, X, **kwargs)

        return transform


def _insert_after_first_paragraph(document, text_to_insert):
    split_doc = document.splitlines(True)
    indent = min(
        (
            len(m.group(1))
            for line in split_doc[1:]
            if (m := re.match(r"^( *)\S", line)) is not None
        ),
        default=0,
    )
    doc_lines = iter(split_doc)
    output_lines = []
    for line in doc_lines:
        output_lines.append(line)
        if line.strip():
            break
    for line in doc_lines:
        output_lines.append(line)
        if not line.strip():
            break
    else:
        output_lines.append("\n")
    for line in text_to_insert.splitlines(True):
        output_lines.append(line if not line.strip() else " " * indent + line)
    output_lines.append("\n")
    output_lines.extend(doc_lines)
    return "".join(output_lines)


def is_single_column_transformer(transformer):
    """
    Check if the provided transformer is a single-column transformer.

    This is done by checking the special attribute
    __single_column_transformer__ (thus inheriting from the
    SingleColumnTransformer class is not mandatory). We treat scikit-learn
    pipelines as a special case and inspect their first step.

    Parameters
    ----------
    transformer : BaseEstimator
        The transformer to check.

    Returns
    -------
    bool
        Whether the transformer is a single-column transformer, meaning that it
        should be passed columns rather than dataframes.
    """
    if hasattr(transformer, "__single_column_transformer__"):
        return True
    if isinstance(transformer, Pipeline):
        # When the transformer is a Pipeline, the first step is what determines
        # if it accepts single columns or dataframes so we inspect the first
        # step (recursively, to handle pipelines that contain pipelines).
        try:
            # Pipeline steps are ('step name', StepEstimator) pairs.
            return is_single_column_transformer(transformer.steps[0][1])
        except Exception:
            # If we are given an invalid Pipeline (eg with no steps) we do not
            # want to raise while attempting to inspect it (it would obfuscate
            # the better error that will be raised when calling fit)
            return False
    return False
