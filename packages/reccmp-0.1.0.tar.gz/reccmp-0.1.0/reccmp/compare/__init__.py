from .core import Compare
