"""Tests for lootqdm.themes."""

from __future__ import annotations

from lootqdm.themes import Theme, get_theme, list_themes, THEMES


class TestThemeRegistry:
    def test_list_themes(self):
        names = list_themes()
        assert "cozy_pastel" in names
        assert "dark_dungeon" in names
        assert "neon_cyber" in names
        assert "retro_crt" in names
        assert len(names) == 4

    def test_get_theme_by_name(self):
        theme = get_theme("dark_dungeon")
        assert isinstance(theme, Theme)
        assert theme.name == "dark_dungeon"

    def test_get_theme_invalid(self):
        import pytest
        with pytest.raises(KeyError):
            get_theme("nonexistent")

    def test_get_theme_default(self):
        theme = get_theme()
        assert theme.name == "dark_dungeon"


class TestThemeStructure:
    def test_all_themes_have_required_fields(self):
        for name in list_themes():
            theme = get_theme(name)
            assert theme.name == name
            assert "title" in theme.palette
            assert "accent" in theme.palette
            assert "soft" in theme.palette
            assert "dim" in theme.palette
            assert len(theme.bar_chars) == 2
            assert "xp" in theme.icons
            assert "level" in theme.icons
            assert "quest" in theme.icons
            assert "achievement" in theme.icons
            for rarity in ("common", "uncommon", "rare", "epic", "legendary"):
                assert rarity in theme.rarity_styles
                assert rarity in theme.icons["loot"]
            assert "crit" in theme.icons["events"]
            assert "lucky" in theme.icons["events"]
            assert "warning" in theme.icons["events"]

    def test_cozy_pastel_icons(self):
        theme = get_theme("cozy_pastel")
        assert theme.icons["xp"] == "\U0001f331"  # 🌱

    def test_retro_crt_ascii_only_icons(self):
        theme = get_theme("retro_crt")
        assert theme.icons["xp"] == "+XP"
        assert theme.icons["level"] == "LV"

    def test_theme_is_immutable(self):
        theme = get_theme("dark_dungeon")
        import pytest
        with pytest.raises(AttributeError):
            theme.name = "hacked"


class TestThemeLootNames:
    def test_all_themes_have_loot_names(self):
        for name in list_themes():
            theme = get_theme(name)
            assert hasattr(theme, "loot_names")
            for rarity in ("common", "uncommon", "rare", "epic", "legendary"):
                assert rarity in theme.loot_names
                assert len(theme.loot_names[rarity]) >= 3
