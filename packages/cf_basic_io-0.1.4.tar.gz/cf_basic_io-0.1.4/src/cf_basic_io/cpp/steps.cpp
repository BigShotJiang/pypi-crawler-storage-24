#include <cstdlib>
#include <cstdint>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

#if defined(CF_BASIC_IO_HAS_OPCUA)
  #if CF_BASIC_IO_HAS_OPCUA
    #include <open62541/client_config_default.h>
    #include <open62541/client_highlevel.h>
  #endif
#else
  #if __has_include(<open62541/client_config_default.h>)
    #include <open62541/client_config_default.h>
    #include <open62541/client_highlevel.h>
    #define CF_BASIC_IO_HAS_OPCUA 1
  #else
    #define CF_BASIC_IO_HAS_OPCUA 0
  #endif
#endif

#include "cf_step_abi.h"
#include "cf_step_utils.h"
#include "cf_plugin_table.h"
#include "cf_basic_io_signature_hashes.h"

// Magic indices removed; cf_sig indices come from canonical semantics via siggen.
namespace {
#if CF_BASIC_IO_HAS_OPCUA
UA_Client* g_opcua_client = nullptr;
std::string g_opcua_client_endpoint;
std::mutex g_opcua_client_mutex;
#endif

static CfStatusCode call_handle_sink(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::HandleSinkStep;
  if (n_params < S::kParamCount || n_inputs < S::kInputCount || n_outputs < S::kOutputCount) {
    return CF_STATUS_INVALID;
  }
  if (cf_handle_is_empty(&params[S::P_handleUri])) return CF_STATUS_INVALID;
  if (inputs[S::I_data].storage_type != CF_STORAGE_DATACUBE || !inputs[S::I_data].data) {
    return CF_STATUS_INVALID;
  }

  std::string handle_uri = cf_handle_to_string(&params[S::P_handleUri]);
  std::string status = "handled via " + handle_uri;
  return cf_out_string(ctx, &outputs[S::O_status_port], status.c_str());
}

static CfStatusCode call_opcua_reader(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle*,
  size_t,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::OpcuaReaderStep;
  if (n_params < S::kParamCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&params[S::P_endpoint]) || cf_handle_is_empty(&params[S::P_nodes])) {
    return CF_STATUS_INVALID;
  }

  std::string endpoint = cf_handle_to_string(&params[S::P_endpoint]);
  std::string nodes_json(reinterpret_cast<const char*>(params[S::P_nodes].data), params[S::P_nodes].size);
  auto nodes = cf_parse_nodes_json(nodes_json);
  if (nodes.empty()) return CF_STATUS_INVALID;

  std::string payload = "{";
#if CF_BASIC_IO_HAS_OPCUA
  auto read_value_json = [](UA_Client* client, const std::string& node_id_str, std::string& out_json) -> bool {
    UA_String node_id_string = UA_STRING_ALLOC(node_id_str.c_str());
    UA_NodeId node_id = UA_NODEID_NULL;
    if (UA_NodeId_parse(&node_id, node_id_string) != UA_STATUSCODE_GOOD) {
      UA_String_clear(&node_id_string);
      return false;
    }
    UA_String_clear(&node_id_string);

    UA_Variant value;
    UA_Variant_init(&value);
    const auto status = UA_Client_readValueAttribute(client, node_id, &value);
    UA_NodeId_clear(&node_id);
    if (status != UA_STATUSCODE_GOOD) {
      return false;
    }

    if (UA_Variant_hasScalarType(&value, &UA_TYPES[UA_TYPES_DOUBLE])) {
      out_json = std::to_string(*static_cast<UA_Double*>(value.data));
      return true;
    }
    if (UA_Variant_hasScalarType(&value, &UA_TYPES[UA_TYPES_FLOAT])) {
      out_json = std::to_string(static_cast<double>(*static_cast<UA_Float*>(value.data)));
      return true;
    }
    if (UA_Variant_hasScalarType(&value, &UA_TYPES[UA_TYPES_STRING])) {
      UA_String* s = static_cast<UA_String*>(value.data);
      std::string str(reinterpret_cast<const char*>(s->data), s->length);
      out_json = "\"" + str + "\"";
      return true;
    }
    return false;
  };

  std::lock_guard<std::mutex> opcua_lock(g_opcua_client_mutex);
  if (!g_opcua_client) {
    g_opcua_client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(g_opcua_client));
    UA_Client_getConfig(g_opcua_client)->timeout = 1000;
  }
  if (g_opcua_client_endpoint != endpoint) {
    if (!g_opcua_client_endpoint.empty()) {
      UA_Client_disconnect(g_opcua_client);
    }
    g_opcua_client_endpoint.clear();
    if (UA_Client_connect(g_opcua_client, endpoint.c_str()) == UA_STATUSCODE_GOOD) {
      g_opcua_client_endpoint = endpoint;
    }
  }
#endif
  for (size_t i = 0; i < nodes.size(); ++i) {
    if (i > 0) payload += ",";
    payload += "\"" + nodes[i].first + "\":";
#if CF_BASIC_IO_HAS_OPCUA
    std::string value_json = "null";
    if (!g_opcua_client_endpoint.empty()) {
      if (!read_value_json(g_opcua_client, nodes[i].second, value_json)) {
        UA_Client_disconnect(g_opcua_client);
        g_opcua_client_endpoint.clear();
      }
    }
    payload += value_json;
#else
    payload += "null";
#endif
  }
  payload += "}";

  return cf_out_bytes(ctx, &outputs[S::O_data], CF_STORAGE_JSON, payload.data(), payload.size());
}

static CfStatusCode call_json_field_select(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::JsonFieldSelectStep;
  if (n_params < S::kParamCount || n_inputs < S::kInputCount || n_outputs < S::kOutputCount) {
    return CF_STATUS_INVALID;
  }
  if (cf_handle_is_empty(&params[S::P_field]) || cf_handle_is_empty(&inputs[S::I_data])) {
    return CF_STATUS_INVALID;
  }

  std::string field = cf_handle_to_string(&params[S::P_field]);
  std::string payload = cf_handle_to_string(&inputs[S::I_data]);
  std::string value;
  if (!cf_extract_json_field(payload, field, value)) return CF_STATUS_INVALID;

  return cf_out_bytes(ctx, &outputs[S::O_value_port], CF_STORAGE_JSON, value.data(), value.size());
}

static CfStatusCode call_json_scalar_to_double(
  CfCallContext* ctx,
  const CfValueHandle*,
  size_t,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::JsonScalarToDoubleStep;
  if (n_inputs < S::kInputCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&inputs[S::I_value_port])) return CF_STATUS_INVALID;

  double value = 0.0;
  if (!cf_try_read_numeric_scalar(&inputs[S::I_value_port], value)) {
    return CF_STATUS_INVALID;
  }
  return cf_out_f64(ctx, &outputs[S::O_value_port], value);
}

static CfStatusCode call_timestamp_to_epoch(
  CfCallContext* ctx,
  const CfValueHandle*,
  size_t,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::TimestampToEpochStep;
  if (n_inputs < S::kInputCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&inputs[S::I_data])) return CF_STATUS_INVALID;

  std::string payload = cf_handle_to_string(&inputs[S::I_data]);
  double epoch = 0.0;
  if (!cf_parse_iso8601_to_epoch(payload, epoch)) {
    epoch = static_cast<double>(std::time(nullptr));
  }
  return cf_out_f64(ctx, &outputs[S::O_value_port], epoch);
}

static CfStatusCode call_epoch_to_timestamp(
  CfCallContext* ctx,
  const CfValueHandle*,
  size_t,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::EpochToTimestampStep;
  if (n_inputs < S::kInputCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&inputs[S::I_value_port])) return CF_STATUS_INVALID;

  double epoch = 0.0;
  if (inputs[S::I_value_port].storage_type == CF_STORAGE_F64 &&
      inputs[S::I_value_port].size >= sizeof(double)) {
    epoch = *reinterpret_cast<const double*>(inputs[S::I_value_port].data);
  } else {
    std::string raw = cf_handle_to_string(&inputs[S::I_value_port]);
    if (!raw.empty() && raw.front() == '"' && raw.back() == '"') {
      raw = raw.substr(1, raw.size() - 2);
    }
    char* end = nullptr;
    epoch = std::strtod(raw.c_str(), &end);
    if (!end || end == raw.c_str()) return CF_STATUS_INVALID;
  }

  std::string ts = cf_format_iso8601(epoch);
  if (ts.empty()) return CF_STATUS_INVALID;
  return cf_out_string(ctx, &outputs[S::O_timestamp], ts.c_str());
}

static CfStatusCode call_report_chart(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle*,
  size_t,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::ReportChartStep;
  if (n_params < S::kParamCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&params[S::P_chartSpec])) return CF_STATUS_INVALID;
  std::string title = cf_handle_to_string(&params[S::P_title]);
  std::string status = "report chart updated";
  if (!title.empty()) {
    status += ": " + title;
  }
  return cf_out_string(ctx, &outputs[S::O_status_port], status.c_str());
}

static CfStatusCode call_report_table(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle*,
  size_t,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::ReportTableStep;
  if (n_params < S::kParamCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  int64_t max_rows = 0;
  if (!cf_read_i64(&params[S::P_maxRows], max_rows) || max_rows < 1) return CF_STATUS_INVALID;
  std::string title = cf_handle_to_string(&params[S::P_title]);
  std::string status = "report table updated";
  if (!title.empty()) {
    status += ": " + title;
  }
  status += " (maxRows=" + std::to_string(max_rows) + ")";
  return cf_out_string(ctx, &outputs[S::O_status_port], status.c_str());
}

static CfStatusCode call_stats_row(
  CfCallContext* ctx,
  const CfValueHandle*,
  size_t n_params,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::StatsRowStep;
  if (n_params < S::kParamCount || n_inputs < S::kInputCount || n_outputs < S::kOutputCount) {
    return CF_STATUS_INVALID;
  }
  if (!inputs[S::I_data].data || inputs[S::I_data].size == 0) return CF_STATUS_INVALID;
  if (inputs[S::I_data].storage_type == CF_STORAGE_DATACUBE) return CF_STATUS_INVALID;
  return cf_out_bytes(ctx, &outputs[S::O_data], inputs[S::I_data].storage_type,
                      inputs[S::I_data].data, inputs[S::I_data].size);
}

#define CF_BASIC_IO_STEPS(X) \
  X(cf_generated::kHandleSinkStepIri, cf_generated::kHandleSinkStepSigHash, call_handle_sink, nullptr) \
  X(cf_generated::kOpcuaReaderStepIri, cf_generated::kOpcuaReaderStepSigHash, call_opcua_reader, nullptr) \
  X(cf_generated::kJsonFieldSelectStepIri, cf_generated::kJsonFieldSelectStepSigHash, call_json_field_select, nullptr) \
  X(cf_generated::kJsonScalarToDoubleStepIri, cf_generated::kJsonScalarToDoubleStepSigHash, call_json_scalar_to_double, nullptr) \
  X(cf_generated::kTimestampToEpochStepIri, cf_generated::kTimestampToEpochStepSigHash, call_timestamp_to_epoch, nullptr) \
  X(cf_generated::kEpochToTimestampStepIri, cf_generated::kEpochToTimestampStepSigHash, call_epoch_to_timestamp, nullptr) \
  X(cf_generated::kReportChartStepIri, cf_generated::kReportChartStepSigHash, call_report_chart, nullptr) \
  X(cf_generated::kReportTableStepIri, cf_generated::kReportTableStepSigHash, call_report_table, nullptr) \
  X(cf_generated::kStatsRowStepIri, cf_generated::kStatsRowStepSigHash, call_stats_row, nullptr)

}  // namespace

CF_DEFINE_STEP_TABLE(CF_BASIC_IO_STEPS)
