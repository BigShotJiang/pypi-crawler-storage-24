"""Anthropic-compatible API proxy server.

Exposes a ``/v1/messages`` endpoint that speaks the Anthropic Messages API
protocol.  Claude Code (or any Anthropic-compatible client) connects to
this server thinking it's talking to Anthropic, while Prism routes each
request to the cheapest/best model across all configured providers.

Usage::

    prism serve                        # start on localhost:8080
    prism serve --port 9090            # custom port
    prism serve --host 0.0.0.0        # listen on all interfaces

Then point Claude Code at it::

    export ANTHROPIC_BASE_URL=http://localhost:8080
    export ANTHROPIC_API_KEY=prism
    claude --model auto

Performance optimisations (v2):
    1. Multi-agent cascade disabled by default (gate flag)
    2. Single classification per request (no double-classify)
    3. In-memory LRU cache in front of SQLite
    4. Pre-computed fallback chains (rebuilt on provider health change)
    5. Classification cache (OrderedDict LRU, 512 entries)
    6. Latency-aware routing (rolling P50 per model)
    7. Speculative model racing for streaming (race top 2 candidates)
    8. Request deduplication (in-flight futures)
    9. SSE write batching (buffer up to 5 events / 50ms)
   10. Latency recording after streaming completes
"""

from __future__ import annotations

import asyncio
import hashlib as _hashlib
import json
import time
import uuid
from collections import OrderedDict
from threading import Lock as _Lock
from typing import Any

import structlog
from aiohttp import web

from prism.proxy.translator import (
    anthropic_to_openai_messages,
    build_anthropic_response,
    build_anthropic_stream_events,
    openai_tool_calls_to_anthropic,
)

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Globals set at server startup
# ---------------------------------------------------------------------------

_completion_engine: Any = None
_cost_tracker: Any = None
_provider_registry: Any = None
_auth_manager: Any = None
_settings: Any = None
_router_classifier: Any = None
_router_selector: Any = None
_response_cache: Any = None
_adaptive_learner: Any = None
_health_checker: Any = None
_response_validator: Any = None

# ---------------------------------------------------------------------------
# Performance: In-memory LRU cache, request dedup, classification cache,
# pre-computed fallback chains, latency tracker, SSE batching
# ---------------------------------------------------------------------------

# --- [FIX 1] Multi-agent gate — disabled by default for speed ---
_multi_agent_enabled: bool = False

# --- [FIX 3] In-memory LRU cache (avoids SQLite hot-path lookups) ---
_LRU_MAX = 256
_lru_cache: OrderedDict[str, Any] = OrderedDict()
_lru_lock = _Lock()


def _lru_get(key: str) -> Any:
    """Get from in-memory LRU. Returns None on miss."""
    with _lru_lock:
        val = _lru_cache.get(key)
        if val is not None:
            _lru_cache.move_to_end(key)
        return val


def _lru_put(key: str, value: Any) -> None:
    """Put into in-memory LRU, evicting oldest if full."""
    with _lru_lock:
        _lru_cache[key] = value
        _lru_cache.move_to_end(key)
        while len(_lru_cache) > _LRU_MAX:
            _lru_cache.popitem(last=False)


# --- [FIX 5] Classification cache — avoid re-classifying the same prompt ---
_classification_cache: OrderedDict[str, Any] = OrderedDict()
_classification_lock = _Lock()
_CLASSIFICATION_CACHE_MAX = 512


def _cached_classify(user_text: str) -> Any:
    """Classify with memoization. Returns cached result or computes fresh."""
    if not _router_classifier or not user_text:
        return None
    # Use first 200 chars as cache key (most prompts differ early)
    key = user_text[:200]
    with _classification_lock:
        cached = _classification_cache.get(key)
        if cached is not None:
            _classification_cache.move_to_end(key)
            return cached
    try:
        result = _router_classifier.classify(user_text)
        with _classification_lock:
            _classification_cache[key] = result
            _classification_cache.move_to_end(key)
            while len(_classification_cache) > _CLASSIFICATION_CACHE_MAX:
                _classification_cache.popitem(last=False)
        return result
    except Exception:
        return None


# --- [FIX 4] Pre-computed fallback chains per tier ---
_fallback_chains: dict[str, list[str]] = {}
_fallback_chains_built = False


def _get_or_build_fallback_chain(
    primary_model: str,
    tools_required: bool = False,
) -> list[str]:
    """Get a fallback chain, using pre-computed chains when possible."""
    global _fallback_chains_built
    if not _fallback_chains_built and _provider_registry:
        _precompute_fallback_chains()
        _fallback_chains_built = True
    # Check if we have a pre-computed chain for this model
    cached_chain = _fallback_chains.get(primary_model)
    if cached_chain:
        if tools_required:
            return [m for m in cached_chain
                    if _is_reliable_for_tools(m) or m == primary_model]
        return cached_chain
    # Fall back to dynamic computation
    return _build_fallback_chain_dynamic(primary_model, tools_required=tools_required)


def _precompute_fallback_chains() -> None:
    """Pre-compute fallback chains for all available models."""
    if not _provider_registry:
        return
    try:
        from prism.router.fallback import FallbackChain
        chain_builder = FallbackChain(_provider_registry)
        for model in _provider_registry.get_available_models():
            chain = chain_builder.build_chain(model.tier, model.id)
            if _health_checker:
                chain = [m for m in chain if _is_provider_healthy(m)]
                if model.id not in chain:
                    chain.insert(0, model.id)
            _fallback_chains[model.id] = chain
    except Exception:
        pass


def _invalidate_fallback_chains() -> None:
    """Invalidate pre-computed fallback chains (call when health changes)."""
    global _fallback_chains_built
    _fallback_chains.clear()
    _fallback_chains_built = False


# --- [FIX 8] Request deduplication — if same prompt is in-flight, wait ---
_inflight: dict[str, asyncio.Future[Any]] = {}
_inflight_lock = _Lock()


# --- [FIX 6] Latency tracker — tracks P50/P99 per model ---
_latency_samples: dict[str, list[float]] = {}
_LATENCY_MAX_SAMPLES = 100


def _record_latency(model: str, latency_ms: float) -> None:
    """Record a latency sample for a model."""
    samples = _latency_samples.setdefault(model, [])
    samples.append(latency_ms)
    if len(samples) > _LATENCY_MAX_SAMPLES:
        samples.pop(0)


def _get_p50_latency(model: str) -> float:
    """Get P50 latency for a model. Returns 999999 if no data."""
    samples = _latency_samples.get(model)
    if not samples:
        return 999999.0
    s = sorted(samples)
    return s[len(s) // 2]


def _get_p99_latency(model: str) -> float:
    """Get P99 latency for a model. Returns 999999 if no data."""
    samples = _latency_samples.get(model)
    if not samples:
        return 999999.0
    s = sorted(samples)
    idx = min(int(len(s) * 0.99), len(s) - 1)
    return s[idx]


# --- [FIX 9] SSE write batching ---
_SSE_BATCH_MAX_EVENTS = 5
_SSE_BATCH_MAX_WAIT_MS = 50


# ---------------------------------------------------------------------------
# Anthropic Messages API endpoint
# ---------------------------------------------------------------------------


async def handle_messages(request: web.Request) -> web.StreamResponse:
    """Handle POST /v1/messages -- the core Anthropic Messages API endpoint.

    Accepts an Anthropic-format request, translates it to OpenAI format,
    routes through Prism's completion engine, and returns an Anthropic-
    format response.  Supports both streaming and non-streaming.
    """
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return web.json_response(
            {"error": {"type": "invalid_request_error", "message": "Invalid JSON"}},
            status=400,
        )

    # Extract Anthropic-format fields
    model_requested = body.get("model", "auto")
    max_tokens = body.get("max_tokens", 4096)
    temperature = body.get("temperature", 0.7)
    stream = body.get("stream", False)
    messages_anthropic = body.get("messages", [])
    system_content = body.get("system", "")
    tools_anthropic = body.get("tools", [])
    tool_choice = body.get("tool_choice")

    # Translate messages: Anthropic format -> OpenAI format
    messages_openai = anthropic_to_openai_messages(messages_anthropic, system_content)

    # Translate tools: Anthropic format -> OpenAI format
    tools_openai = _translate_tools(tools_anthropic) if tools_anthropic else None

    # Budget enforcement -- block if over budget
    if _cost_tracker:
        from prism.cost.tracker import BudgetAction
        action = _cost_tracker.check_budget(0.01)  # estimate
        if action == BudgetAction.BLOCK:
            remaining = _cost_tracker.get_budget_remaining()
            return web.json_response(
                {
                    "type": "error",
                    "error": {
                        "type": "rate_limit_error",
                        "message": (
                            f"Prism budget exceeded. Remaining: ${remaining:.4f}. "
                            "Increase budget with `prism config set budget.daily <amount>`"
                        ),
                    },
                },
                status=429,
            )

    # --- [FIX 2] Classify ONCE at the top, reuse everywhere ---
    tools_present = bool(tools_anthropic)
    user_text = _get_user_text(messages_openai)
    classification = _cached_classify(user_text) if user_text else None
    complexity = "simple"
    if classification:
        try:
            complexity = classification.tier.value
        except Exception:
            complexity = "medium"

    # Route: pick the best model (with fallback chain), passing classification
    chosen_model = _route_model(
        model_requested,
        messages_openai,
        tools_present=tools_present,
        classification=classification,
    )
    # [FIX 4] Use pre-computed fallback chains instead of rebuilding
    fallback_chain = _get_or_build_fallback_chain(chosen_model, tools_required=tools_present)

    logger.info(
        "proxy_request",
        requested=model_requested,
        routed_to=chosen_model,
        complexity=complexity,
        stream=stream,
        messages=len(messages_openai),
        tools=len(tools_anthropic),
        fallback_chain=fallback_chain[:3],
    )

    # --- [FIX 3] Cache lookup: memory LRU first, then SQLite ---
    cache_key: str | None = None
    if _response_cache and not tools_anthropic:
        cache_key = _make_cache_key(model_requested, system_content, messages_anthropic)

        # Check in-memory LRU first
        mem_cached = _lru_get(cache_key)
        if mem_cached is not None:
            logger.info("proxy_cache_hit", model=mem_cached.get("model", ""), source="memory")
            if stream:
                return await _stream_cached_response_from_dict(request, mem_cached)
            return web.json_response(mem_cached["response"])

        # Fall back to SQLite cache
        cached = _response_cache.get(cache_key)
        if cached:
            logger.info("proxy_cache_hit", model=cached.model, source="sqlite", key=cache_key[:16])
            # Promote to in-memory LRU
            resp = build_anthropic_response(
                content=cached.content,
                model=cached.model,
                input_tokens=cached.input_tokens,
                output_tokens=cached.output_tokens,
                finish_reason=cached.finish_reason,
            )
            _lru_put(cache_key, {
                "model": cached.model,
                "content": cached.content,
                "input_tokens": cached.input_tokens,
                "output_tokens": cached.output_tokens,
                "finish_reason": cached.finish_reason,
                "response": resp,
            })
            if stream:
                return await _stream_cached_response(request, cached)
            return web.json_response(resp)

    # --- [FIX 1] Check query param for multi-agent override ---
    multi_agent_requested = request.query.get("multi_agent", "").lower() == "true"

    if stream:
        return await _handle_streaming(
            request, messages_openai, chosen_model,
            max_tokens, temperature, tools_openai, tool_choice,
            cache_key=cache_key,
            fallback_chain=fallback_chain,
        )
    else:
        return await _handle_non_streaming(
            messages_openai, chosen_model,
            max_tokens, temperature, tools_openai, tool_choice,
            cache_key=cache_key,
            multi_agent_override=multi_agent_requested,
            complexity=complexity,
        )


async def _handle_non_streaming(
    messages: list[dict[str, Any]],
    model: str,
    max_tokens: int,
    temperature: float,
    tools: list[dict] | None,
    tool_choice: Any | None,
    cache_key: str | None = None,
    multi_agent_override: bool = False,
    complexity: str = "simple",
) -> web.Response:
    """Handle a non-streaming completion request.

    Multi-agent is ONLY used when explicitly enabled via the global flag
    or the per-request query param override.  Default path is single-model.
    """
    # --- [FIX 1] Multi-agent only when explicitly enabled ---
    if not tools and (_multi_agent_enabled or multi_agent_override):
        if complexity == "complex":
            multi_result = await _try_multi_agent(messages, model, max_tokens, temperature)
            if multi_result is not None:
                return multi_result

    # --- [FIX 8] Request deduplication ---
    dedup_key: str | None = None
    if cache_key and not tools:
        dedup_key = cache_key
        with _inflight_lock:
            existing_future = _inflight.get(dedup_key)
        if existing_future is not None:
            try:
                logger.info("proxy_dedup_wait", key=dedup_key[:16])
                result_response = await existing_future
                return web.json_response(result_response)
            except Exception:
                pass  # Original request failed, proceed normally

        # Register this request as in-flight
        loop = asyncio.get_running_loop()
        future: asyncio.Future[Any] = loop.create_future()
        with _inflight_lock:
            _inflight[dedup_key] = future

    start_time = time.perf_counter()

    try:
        result = await _completion_engine.complete(
            messages=messages,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            tools=tools,
            stream=False,
        )

        # --- [FIX 10] Record latency ---
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        _record_latency(model, elapsed_ms)

        # --- Response validation ---
        if _response_validator:
            try:
                result = _response_validator.validate(result)
            except Exception as exc:
                logger.debug("response_validation_error", error=str(exc))

        # Convert tool calls from OpenAI to Anthropic format
        tool_calls_anthropic = []
        if result.tool_calls:
            tool_calls_anthropic = openai_tool_calls_to_anthropic(result.tool_calls)

        response = build_anthropic_response(
            content=result.content or "",
            model=model,
            input_tokens=result.input_tokens,
            output_tokens=result.output_tokens,
            tool_calls=tool_calls_anthropic,
            finish_reason=result.finish_reason,
        )

        # --- [FIX 3] Cache to both in-memory LRU and SQLite ---
        if cache_key and not tools:
            _lru_put(cache_key, {
                "model": model,
                "content": result.content or "",
                "input_tokens": result.input_tokens,
                "output_tokens": result.output_tokens,
                "finish_reason": result.finish_reason or "stop",
                "response": response,
            })

        if _response_cache and cache_key and not tools:
            try:
                _response_cache.put(
                    cache_key=cache_key,
                    model=model,
                    provider=getattr(result, "provider", "unknown"),
                    content=result.content or "",
                    input_tokens=result.input_tokens or 0,
                    output_tokens=result.output_tokens or 0,
                    cost_usd=getattr(result, "cost", 0.0) or 0.0,
                    finish_reason=result.finish_reason or "stop",
                )
            except Exception as exc:
                logger.debug("cache_put_error", error=str(exc))

        # --- Record outcome for adaptive learning ---
        _record_learning_outcome(model, "accepted", result)

        # --- [FIX 8] Resolve dedup future ---
        if dedup_key is not None:
            with _inflight_lock:
                fut = _inflight.pop(dedup_key, None)
            if fut is not None and not fut.done():
                fut.set_result(response)

        return web.json_response(response)

    except Exception as exc:
        logger.error("proxy_completion_error", error=str(exc))
        # Record failure for adaptive learning
        _record_learning_outcome(model, "rejected", None)

        # --- [FIX 8] Resolve dedup future with error ---
        if dedup_key is not None:
            with _inflight_lock:
                fut = _inflight.pop(dedup_key, None)
            if fut is not None and not fut.done():
                fut.set_exception(exc)

        return web.json_response(
            {
                "type": "error",
                "error": {
                    "type": "api_error",
                    "message": f"Prism routing error: {exc}",
                },
            },
            status=500,
        )


async def _handle_streaming(
    request: web.Request,
    messages: list[dict[str, Any]],
    model: str,
    max_tokens: int,
    temperature: float,
    tools: list[dict] | None,
    tool_choice: Any | None,
    cache_key: str | None = None,
    fallback_chain: list[str] | None = None,
) -> web.StreamResponse:
    """Handle a streaming completion request with SSE.

    [FIX 7] Uses speculative model racing: when 2+ candidates are available,
    launches the top 2 concurrently. Whichever produces the first successful
    chunk wins; the other is cancelled.  Falls back to sequential on error.
    """
    # Build the candidate list
    models_to_try = [model]
    if fallback_chain:
        for fb in fallback_chain:
            if fb != model and fb not in models_to_try:
                models_to_try.append(fb)

    active_stream = None
    actual_model = model
    first_chunk = None
    last_error: Exception | None = None
    stream_start_time = time.perf_counter()

    backend = _completion_engine._get_backend()

    # --- [FIX 7] Speculative model racing for top 2 candidates ---
    if len(models_to_try) >= 2:
        race_result = await _race_stream_candidates(
            backend, messages, models_to_try[:2],
            temperature, max_tokens, tools,
        )
        if race_result is not None:
            active_stream, actual_model, first_chunk = race_result
            if actual_model != model:
                logger.info(
                    "stream_race_winner",
                    primary=model,
                    winner=actual_model,
                )
            # Remove the candidates we already tried from sequential fallback
            remaining = [m for m in models_to_try[2:]]
        else:
            remaining = models_to_try[2:]  # Both racers failed

        # If race failed, fall back to sequential for remaining candidates
        if active_stream is None:
            for candidate in remaining:
                try:
                    kwargs = _completion_engine._build_litellm_kwargs(
                        model=candidate,
                        messages=messages,
                        temperature=temperature,
                        max_tokens=max_tokens,
                        stream=True,
                        tools=tools,
                    )
                    candidate_stream = await backend.acompletion(**kwargs)
                    first_chunk = await candidate_stream.__anext__()
                    active_stream = candidate_stream
                    actual_model = candidate
                    logger.info(
                        "stream_fallback_success",
                        primary=model,
                        fallback=candidate,
                    )
                    break
                except (StopAsyncIteration, StopIteration):
                    last_error = RuntimeError(f"{candidate}: empty stream")
                    logger.warning("stream_model_empty", model=candidate)
                    _record_learning_outcome(candidate, "rejected", None)
                    continue
                except Exception as exc:
                    last_error = exc
                    logger.warning(
                        "stream_model_failed",
                        model=candidate,
                        error=str(exc)[:200],
                    )
                    _record_learning_outcome(candidate, "rejected", None)
                    continue
    else:
        # Only one candidate, no racing possible
        candidate = models_to_try[0]
        try:
            kwargs = _completion_engine._build_litellm_kwargs(
                model=candidate,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
                tools=tools,
            )
            candidate_stream = await backend.acompletion(**kwargs)
            first_chunk = await candidate_stream.__anext__()
            active_stream = candidate_stream
            actual_model = candidate
        except (StopAsyncIteration, StopIteration):
            last_error = RuntimeError(f"{candidate}: empty stream")
            logger.warning("stream_model_empty", model=candidate)
            _record_learning_outcome(candidate, "rejected", None)
        except Exception as exc:
            last_error = exc
            logger.warning(
                "stream_model_failed",
                model=candidate,
                error=str(exc)[:200],
            )
            _record_learning_outcome(candidate, "rejected", None)

    # All models failed -- return a clean JSON error (not raw dump)
    if active_stream is None:
        error_msg = "All models failed."
        if last_error:
            err_str = str(last_error)
            if "RateLimitError" in err_str or "429" in err_str:
                error_msg = "All available models are rate-limited. Please wait and retry."
            elif "AuthenticationError" in err_str:
                error_msg = "No valid API keys for available models."
            elif "Insufficient Balance" in err_str:
                error_msg = "All available models have insufficient balance."
            else:
                error_msg = err_str[:300]
        return web.json_response(
            {
                "type": "error",
                "error": {
                    "type": "api_error",
                    "message": f"Prism: {error_msg}",
                },
            },
            status=500,
        )

    # --- Now start SSE with the working stream ---
    response = web.StreamResponse(
        status=200,
        reason="OK",
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Prism-Model": actual_model,
        },
    )
    await response.prepare(request)

    msg_id = f"msg_{uuid.uuid4().hex[:24]}"

    # Send message_start
    start_event = {
        "type": "message_start",
        "message": {
            "id": msg_id,
            "type": "message",
            "role": "assistant",
            "content": [],
            "model": actual_model,
            "stop_reason": None,
            "stop_sequence": None,
            "usage": {"input_tokens": 0, "output_tokens": 0},
        },
    }
    await _send_sse(response, "message_start", start_event)

    # Send content_block_start
    await _send_sse(response, "content_block_start", {
        "type": "content_block_start",
        "index": 0,
        "content_block": {"type": "text", "text": ""},
    })

    # Stream tokens with batched writes
    collected_content = ""
    collected_tool_calls: list[dict] = []
    input_tokens = 0
    output_tokens = 0

    # --- [FIX 9] SSE write batching state ---
    sse_batch: list[str] = []
    batch_start_time = time.perf_counter()

    async def _flush_sse_batch() -> None:
        """Flush accumulated SSE events to the response."""
        nonlocal sse_batch, batch_start_time
        if sse_batch:
            combined = "".join(sse_batch)
            await response.write(combined.encode("utf-8"))
            sse_batch = []
            batch_start_time = time.perf_counter()

    def _queue_sse_event(event: str, data: dict[str, Any]) -> None:
        """Add an SSE event to the batch buffer."""
        payload = f"event: {event}\ndata: {json.dumps(data)}\n\n"
        sse_batch.append(payload)

    try:
        async def _chain_stream(first: Any, rest: Any):
            """Yield the first chunk then the rest of the stream."""
            if first is not None:
                yield first
            async for item in rest:
                yield item

        async for chunk in _chain_stream(first_chunk, active_stream):
            # Handle both dict and object responses
            if hasattr(chunk, "choices"):
                choices = chunk.choices
            elif isinstance(chunk, dict):
                choices = chunk.get("choices", [])
            else:
                continue

            if not choices:
                continue

            choice = choices[0] if isinstance(choices, list) else choices
            delta = getattr(choice, "delta", None)
            if delta is None and isinstance(choice, dict):
                delta = choice.get("delta", {})

            # Text content
            content_delta = getattr(delta, "content", None)
            if content_delta is None and isinstance(delta, dict):
                content_delta = delta.get("content")

            if content_delta:
                collected_content += content_delta
                _queue_sse_event("content_block_delta", {
                    "type": "content_block_delta",
                    "index": 0,
                    "delta": {"type": "text_delta", "text": content_delta},
                })

                # [FIX 9] Flush when batch is full or time exceeded
                elapsed_batch_ms = (time.perf_counter() - batch_start_time) * 1000
                if (len(sse_batch) >= _SSE_BATCH_MAX_EVENTS
                        or elapsed_batch_ms >= _SSE_BATCH_MAX_WAIT_MS):
                    await _flush_sse_batch()

            # Tool calls
            tc_delta = getattr(delta, "tool_calls", None)
            if tc_delta is None and isinstance(delta, dict):
                tc_delta = delta.get("tool_calls")
            if tc_delta:
                for tc in tc_delta:
                    _merge_tool_call_delta(collected_tool_calls, tc)

            # Usage info
            usage = getattr(chunk, "usage", None)
            if usage is None and isinstance(chunk, dict):
                usage = chunk.get("usage")
            if usage:
                input_tokens = getattr(usage, "prompt_tokens", 0) or (
                    usage.get("prompt_tokens", 0) if isinstance(usage, dict) else 0
                )
                output_tokens = getattr(usage, "completion_tokens", 0) or (
                    usage.get("completion_tokens", 0) if isinstance(usage, dict) else 0
                )

    except Exception as exc:
        logger.error("proxy_stream_error", error=str(exc))
        _queue_sse_event("content_block_delta", {
            "type": "content_block_delta",
            "index": 0,
            "delta": {"type": "text_delta", "text": "\n\n[Prism: stream interrupted]"},
        })

    # Flush any remaining batched events
    await _flush_sse_batch()

    # Send content_block_stop
    await _send_sse(response, "content_block_stop", {
        "type": "content_block_stop",
        "index": 0,
    })

    # If there were tool calls, send them as additional content blocks
    if collected_tool_calls:
        anthropic_tcs = openai_tool_calls_to_anthropic(collected_tool_calls)
        for idx, tc in enumerate(anthropic_tcs, start=1):
            await _send_sse(response, "content_block_start", {
                "type": "content_block_start",
                "index": idx,
                "content_block": tc,
            })
            await _send_sse(response, "content_block_stop", {
                "type": "content_block_stop",
                "index": idx,
            })

    # Determine stop reason
    stop_reason = "end_turn"
    if collected_tool_calls:
        stop_reason = "tool_use"

    # Send message_delta (final usage + stop reason)
    await _send_sse(response, "message_delta", {
        "type": "message_delta",
        "delta": {"stop_reason": stop_reason, "stop_sequence": None},
        "usage": {"output_tokens": output_tokens},
    })

    # Send message_stop
    await _send_sse(response, "message_stop", {"type": "message_stop"})

    elapsed = time.perf_counter() - stream_start_time
    elapsed_ms = int(elapsed * 1000)

    # --- [FIX 10] Record latency after streaming completes ---
    _record_latency(actual_model, float(elapsed_ms))

    logger.info(
        "proxy_stream_complete",
        model=actual_model,
        tokens_in=input_tokens,
        tokens_out=output_tokens,
        elapsed_ms=elapsed_ms,
    )

    # --- [FIX 3] Cache streamed result to both LRU and SQLite ---
    if cache_key and not collected_tool_calls:
        resp_data = build_anthropic_response(
            content=collected_content,
            model=actual_model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            finish_reason="stop",
        )
        _lru_put(cache_key, {
            "model": actual_model,
            "content": collected_content,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "finish_reason": "stop",
            "response": resp_data,
        })

    if _response_cache and cache_key and not collected_tool_calls:
        try:
            _response_cache.put(
                cache_key=cache_key,
                model=actual_model,
                provider="stream",
                content=collected_content,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=0.0,
                finish_reason="stop",
            )
        except Exception as exc:
            logger.debug("cache_put_stream_error", error=str(exc))

    # --- Record outcome for adaptive learning ---
    _record_learning_outcome(actual_model, "accepted", None)

    return response


# ---------------------------------------------------------------------------
# [FIX 7] Speculative model racing
# ---------------------------------------------------------------------------


async def _race_stream_candidates(
    backend: Any,
    messages: list[dict[str, Any]],
    candidates: list[str],
    temperature: float,
    max_tokens: int,
    tools: list[dict] | None,
) -> tuple[Any, str, Any] | None:
    """Race two model candidates and return the winner.

    Launches both candidates concurrently. Whichever produces the first
    successful chunk wins; the other task is cancelled.

    Returns:
        (stream, model_id, first_chunk) on success, None if both fail.
    """
    if len(candidates) < 2:
        return None

    async def _try_candidate(candidate: str) -> tuple[Any, str, Any]:
        """Try to open a stream and read the first chunk."""
        kwargs = _completion_engine._build_litellm_kwargs(
            model=candidate,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
            tools=tools,
        )
        candidate_stream = await backend.acompletion(**kwargs)
        chunk = await candidate_stream.__anext__()
        return (candidate_stream, candidate, chunk)

    task_a = asyncio.create_task(_try_candidate(candidates[0]))
    task_b = asyncio.create_task(_try_candidate(candidates[1]))

    done, pending = await asyncio.wait(
        {task_a, task_b},
        return_when=asyncio.FIRST_COMPLETED,
    )

    winner_result = None
    for task in done:
        try:
            winner_result = task.result()
            break
        except Exception as exc:
            logger.debug("race_candidate_failed", error=str(exc)[:200])
            continue

    # Cancel pending tasks
    for task in pending:
        task.cancel()
        try:
            await task
        except (asyncio.CancelledError, Exception):
            pass

    if winner_result is not None:
        return winner_result

    # Both tasks might have completed (both in done), check the other
    for task in done:
        if task.done() and not task.cancelled():
            try:
                result = task.result()
                if result is not None:
                    return result
            except Exception:
                continue

    # If the first winner failed but a pending task completed successfully
    # (unlikely since we cancelled, but handle gracefully)
    return None


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


async def _send_sse(
    response: web.StreamResponse,
    event: str,
    data: dict[str, Any],
) -> None:
    """Send a Server-Sent Event (unbatched, for control events)."""
    payload = f"event: {event}\ndata: {json.dumps(data)}\n\n"
    await response.write(payload.encode("utf-8"))


async def _stream_cached_response_from_dict(
    request: web.Request,
    cached_dict: dict[str, Any],
) -> web.StreamResponse:
    """Replay a cached response from in-memory dict as SSE events."""
    events = build_anthropic_stream_events(
        content=cached_dict["content"],
        model=cached_dict["model"],
        input_tokens=cached_dict.get("input_tokens", 0),
        output_tokens=cached_dict.get("output_tokens", 0),
    )

    response = web.StreamResponse(
        status=200,
        reason="OK",
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Prism-Model": cached_dict["model"],
            "X-Prism-Cache": "hit-memory",
        },
    )
    await response.prepare(request)

    for event_type, event_data in events:
        await _send_sse(response, event_type, event_data)

    return response


def _merge_tool_call_delta(
    collected: list[dict],
    delta: Any,
) -> None:
    """Merge a streaming tool call delta into the collected list."""
    idx = getattr(delta, "index", None)
    if idx is None and isinstance(delta, dict):
        idx = delta.get("index", 0)

    # Ensure list is big enough
    while len(collected) <= (idx or 0):
        collected.append({"id": "", "type": "function", "function": {"name": "", "arguments": ""}})

    tc = collected[idx or 0]

    # Merge ID
    tc_id = getattr(delta, "id", None) or (delta.get("id") if isinstance(delta, dict) else None)
    if tc_id:
        tc["id"] = tc_id

    # Merge function name and arguments
    fn = getattr(delta, "function", None)
    if fn is None and isinstance(delta, dict):
        fn = delta.get("function", {})

    if fn:
        name = getattr(fn, "name", None) or (fn.get("name") if isinstance(fn, dict) else None)
        args = getattr(fn, "arguments", None) or (
            fn.get("arguments") if isinstance(fn, dict) else None
        )
        if name:
            tc["function"]["name"] = name
        if args:
            tc["function"]["arguments"] += args


def _translate_tools(tools_anthropic: list[dict]) -> list[dict]:
    """Translate Anthropic tool format to OpenAI tool format.

    Anthropic: ``{"name": "X", "description": "Y", "input_schema": {...}}``
    OpenAI:    ``{"type": "function", "function": {"name": "X", ...}}``
    """
    result: list[dict] = []
    for tool in tools_anthropic:
        result.append({
            "type": "function",
            "function": {
                "name": tool.get("name", ""),
                "description": tool.get("description", ""),
                "parameters": tool.get("input_schema", {}),
            },
        })
    return result


def _route_model(
    requested: str,
    messages: list[dict],
    tools_present: bool = False,
    classification: Any = None,
) -> str:
    """Pick the best model for this request using Prism's router.

    [FIX 2] Accepts pre-computed classification to avoid double-classify.
    [FIX 6] When multiple same-tier models exist at similar cost, prefer
    the one with lower P50 latency.

    If the user requested a specific model (not 'auto'), use it.
    Otherwise, classify the task and route intelligently.  Consults
    the adaptive learner for recommendations and filters out
    unhealthy providers.  When tools are present, only picks models
    that support tool use.
    """
    # If user specified a concrete model, use it — unless the provider
    # isn't available (e.g. Claude Code requests claude-sonnet-4-6 but
    # no Anthropic API key is configured).  In that case, fall through
    # to the intelligent router so it picks the best available model.
    if requested and requested not in ("auto", "default", "prism"):
        model = _ensure_litellm_model(requested)
        # Check if the provider for this model is actually available
        provider_available = True
        if _auth_manager:
            anthropic_prefixes = ("claude-", "claude_")
            openai_prefixes = ("gpt-", "o1-", "o3-")
            if any(model.startswith(p) for p in anthropic_prefixes):
                provider_available = _auth_manager.get_key("anthropic") is not None
            elif any(model.startswith(p) for p in openai_prefixes):
                provider_available = _auth_manager.get_key("openai") is not None
        if provider_available:
            if _health_checker and not _is_provider_healthy(model):
                logger.warning("proxy_unhealthy_model_requested", model=model)
            return model
        else:
            logger.info(
                "proxy_provider_unavailable_rerouting",
                requested=requested,
                reason="no API key for provider",
            )

    # Use Prism's routing engine
    if _router_classifier and _router_selector:
        try:
            user_text = ""
            for msg in reversed(messages):
                if msg.get("role") == "user":
                    content = msg.get("content", "")
                    if isinstance(content, str):
                        user_text = content
                    break

            # [FIX 2] Use pre-computed classification instead of re-classifying
            if classification is None and user_text:
                classification = _cached_classify(user_text)

            if classification:
                # --- Adaptive learner recommendation ---
                if _adaptive_learner and _adaptive_learner.is_active:
                    recommended = _adaptive_learner.get_model_recommendation(
                        classification.tier,
                    )
                    if recommended and _is_provider_healthy(recommended):
                        logger.info(
                            "proxy_learner_recommendation",
                            tier=classification.tier.value,
                            model=recommended,
                        )
                        return recommended

                from prism.cost.pricing import estimate_input_tokens
                ctx_tokens = sum(
                    estimate_input_tokens(str(m.get("content", "")))
                    for m in messages
                )
                selection = _router_selector.select(
                    tier=classification.tier,
                    prompt=user_text,
                    context_tokens=ctx_tokens,
                    tools_enabled=True,
                )

                # Skip unhealthy models, use fallback
                selected = selection.model_id
                if _health_checker and not _is_provider_healthy(selected):
                    for fb in selection.fallback_chain:
                        if _is_provider_healthy(fb):
                            logger.info(
                                "proxy_health_fallback",
                                unhealthy=selected,
                                fallback=fb,
                            )
                            selected = fb
                            break

                # --- [FIX 6] Latency-aware tie-breaking ---
                # If there are fallback models in the same tier at similar
                # cost, prefer the one with the lowest P50 latency.
                selected = _latency_tiebreak(selected, selection.fallback_chain)

                logger.info(
                    "proxy_routed",
                    tier=classification.tier.value,
                    model=selected,
                    fallback=selection.fallback_chain[:2],
                    p50_ms=int(_get_p50_latency(selected)),
                )
                return selected
        except Exception as exc:
            logger.debug("proxy_routing_fallback", error=str(exc))

    # Fallback: try to find any available healthy model
    if _provider_registry:
        try:
            models = _provider_registry.get_available_models()
            # First pass: healthy + reliable for tools
            for m in models:
                if tools_present and (not m.supports_tools or not _is_reliable_for_tools(m.id)):
                    continue
                if _is_provider_healthy(m.id):
                    return m.id
            # Second pass: healthy, accept unreliable tool providers
            for m in models:
                if tools_present and not m.supports_tools:
                    continue
                if _is_provider_healthy(m.id):
                    return m.id
            # Third pass: any compatible
            for m in models:
                if not tools_present or m.supports_tools:
                    return m.id
            if models:
                return models[0].id
        except Exception:
            pass

    # Last resort
    return "gpt-4o-mini"


def _latency_tiebreak(selected: str, fallback_chain: list[str]) -> str:
    """[FIX 6] Among healthy models, prefer the one with lowest P50 latency.

    Only switches if an alternative has significantly lower latency (>20%
    improvement) to avoid constant flip-flopping.
    """
    if not fallback_chain:
        return selected

    selected_p50 = _get_p50_latency(selected)

    # If we have no latency data for the selected model, keep it
    if selected_p50 >= 999999.0:
        return selected

    best_model = selected
    best_p50 = selected_p50

    for alt in fallback_chain:
        if alt == selected:
            continue
        if not _is_provider_healthy(alt):
            continue
        alt_p50 = _get_p50_latency(alt)
        # Only switch if alternative is >20% faster (avoids flip-flopping)
        if alt_p50 < best_p50 * 0.8:
            best_model = alt
            best_p50 = alt_p50

    if best_model != selected:
        logger.info(
            "latency_tiebreak",
            original=selected,
            switched_to=best_model,
            original_p50=int(selected_p50),
            switched_p50=int(best_p50),
        )

    return best_model


def _ensure_litellm_model(model: str) -> str:
    """Ensure the model ID is LiteLLM-compatible.

    Claude Code may send Anthropic model names. If the model looks
    like an Anthropic model, keep it. Otherwise, ensure proper prefix.
    """
    # Already has a provider prefix
    if "/" in model:
        return model

    # Known Anthropic models -- pass through (LiteLLM handles them)
    anthropic_prefixes = ("claude-", "claude_")
    if any(model.startswith(p) for p in anthropic_prefixes):
        return model

    # Known OpenAI models
    openai_prefixes = ("gpt-", "o1-", "o3-")
    if any(model.startswith(p) for p in openai_prefixes):
        return model

    # Looks like an Ollama model (no known prefix)
    return f"ollama/{model}"


def _build_fallback_chain_dynamic(
    primary_model: str,
    tools_required: bool = False,
) -> list[str]:
    """Build a fallback chain dynamically (used when pre-computed cache misses).

    If the primary model fails, we try these in order.
    Filters out providers known to be unhealthy and, when tools
    are required, excludes models that don't support tool use.
    """
    if not _provider_registry:
        return [primary_model]

    try:
        from prism.router.fallback import FallbackChain

        chain_builder = FallbackChain(_provider_registry)
        model_info = _provider_registry.get_model_info(primary_model)
        if model_info:
            chain = chain_builder.build_chain(model_info.tier, primary_model)
            # Filter out unhealthy providers
            if _health_checker:
                chain = [m for m in chain if _is_provider_healthy(m)]
                if primary_model not in chain:
                    chain.insert(0, primary_model)
            # Cache it for next time
            _fallback_chains[primary_model] = chain
            return chain
    except Exception:
        pass

    # Simple fallback: reliable models first, then unreliable ones
    try:
        available = _provider_registry.get_available_models()
        chain = [primary_model]
        # First: reliable, healthy models
        for m in available:
            if m.id == primary_model:
                continue
            if tools_required and (not m.supports_tools or not _is_reliable_for_tools(m.id)):
                continue
            if _is_provider_healthy(m.id):
                chain.append(m.id)
        # Then: unreliable but tool-capable (as last resort)
        for m in available:
            if m.id in chain:
                continue
            if tools_required and not m.supports_tools:
                continue
            if _is_provider_healthy(m.id):
                chain.append(m.id)
        return chain[:7]
    except Exception:
        return [primary_model]


# ---------------------------------------------------------------------------
# Multi-agent enhancement (transparent to Claude Code)
# Only active when _multi_agent_enabled is True or ?multi_agent=true
# ---------------------------------------------------------------------------

# Complexity thresholds for multi-agent strategies
_MULTI_AGENT_MIN_PROMPT_LEN = 50


def _get_user_text(messages: list[dict[str, Any]]) -> str:
    """Extract the latest user message text."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
    return ""


async def _try_multi_agent(
    messages: list[dict[str, Any]],
    primary_model: str,
    max_tokens: int,
    temperature: float,
) -> web.Response | None:
    """Attempt multi-agent processing for complex requests.

    Uses Prism's full orchestration stack in priority order:

    1. **Confidence Cascade** (FrugalGPT) -- try cheap first, escalate
       if confidence is low. Best for most complex tasks.
    2. **Mixture of Agents** -- parallel generation + fusion. Used when
       multiple perspectives improve quality (design, architecture).
    3. **Debate** -- multi-round model debate. Used for controversial
       or ambiguous questions.
    4. **Parallel consensus** -- fallback: run 2 models, pick best.

    All of this is invisible to Claude Code -- it just gets a better
    answer back.

    Returns:
        A web.Response if multi-agent produced a result, None to fall
        back to single-model.
    """
    if not _provider_registry:
        return None

    user_text = _get_user_text(messages)

    # Too short for multi-agent
    if not user_text or len(user_text) < _MULTI_AGENT_MIN_PROMPT_LEN:
        return None

    # Try strategies in order of reliability
    for strategy_fn in (
        _try_confidence_cascade,
        _try_mixture_of_agents,
        _try_debate,
        _try_swarm,
        _try_parallel_consensus,
    ):
        try:
            result = await strategy_fn(
                messages, user_text, primary_model, max_tokens, temperature,
            )
            if result is not None:
                return result
        except Exception as exc:
            logger.debug(
                "multi_agent_strategy_failed",
                strategy=strategy_fn.__name__,
                error=str(exc),
            )
            continue

    return None


async def _try_confidence_cascade(
    messages: list[dict[str, Any]],
    user_text: str,
    primary_model: str,
    max_tokens: int,
    temperature: float,
) -> web.Response | None:
    """Try the Confidence Cascade (FrugalGPT pattern).

    Start cheap, escalate only when the model isn't confident.
    """
    try:
        from prism.orchestrator.cascade import CascadeConfig, ConfidenceCascade
    except ImportError:
        return None

    if not _provider_registry:
        return None

    try:
        from prism.orchestrator.swarm import ModelPool

        available = _provider_registry.get_available_models()
        if len(available) < 2:
            return None

        pool = ModelPool(
            cheap=[m.id for m in available if m.tier.value == "simple"][:2],
            mid=[m.id for m in available if m.tier.value == "medium"][:2],
            premium=[m.id for m in available if m.tier.value == "complex"][:2],
        )

        cascade = ConfidenceCascade(
            engine=_completion_engine,
            model_pool=pool,
            config=CascadeConfig(confidence_threshold=0.7),
        )

        result = await cascade.execute(prompt=user_text)

        if result and result.accepted_output:
            logger.info(
                "cascade_complete",
                model=result.accepted_model,
                confidence=result.confidence,
                attempts=result.total_attempts,
                cost=result.total_cost,
            )
            return web.json_response(build_anthropic_response(
                content=result.accepted_output,
                model=result.accepted_model or primary_model,
                output_tokens=len(result.accepted_output.split()) * 2,
            ))
    except Exception as exc:
        logger.debug("cascade_error", error=str(exc))

    return None


async def _try_mixture_of_agents(
    messages: list[dict[str, Any]],
    user_text: str,
    primary_model: str,
    max_tokens: int,
    temperature: float,
) -> web.Response | None:
    """Try Mixture of Agents -- parallel generation + fusion."""
    try:
        from prism.orchestrator.moa import MixtureOfAgents, MoAConfig
    except ImportError:
        return None

    if not _provider_registry:
        return None

    try:
        from prism.orchestrator.swarm import ModelPool

        available = _provider_registry.get_available_models()
        if len(available) < 3:
            return None  # MoA needs at least 3 models

        pool = ModelPool(
            cheap=[m.id for m in available if m.tier.value == "simple"][:2],
            mid=[m.id for m in available if m.tier.value == "medium"][:2],
            premium=[m.id for m in available if m.tier.value == "complex"][:1],
        )

        moa = MixtureOfAgents(
            engine=_completion_engine,
            model_pool=pool,
            config=MoAConfig(num_agents=min(3, len(available))),
        )

        result = await moa.generate(prompt=user_text)

        if result and result.final_output:
            logger.info(
                "moa_complete",
                layers=result.total_layers,
                cost=result.total_cost,
            )
            return web.json_response(build_anthropic_response(
                content=result.final_output,
                model=primary_model,
                output_tokens=len(result.final_output.split()) * 2,
            ))
    except Exception as exc:
        logger.debug("moa_error", error=str(exc))

    return None


async def _try_debate(
    messages: list[dict[str, Any]],
    user_text: str,
    primary_model: str,
    max_tokens: int,
    temperature: float,
) -> web.Response | None:
    """Try multi-model debate for controversial/ambiguous questions."""
    try:
        from prism.orchestrator.debate import DebateConfig, DebateEngine
    except ImportError:
        return None

    if not _provider_registry:
        return None

    try:
        from prism.orchestrator.swarm import ModelPool

        available = _provider_registry.get_available_models()
        if len(available) < 2:
            return None

        pool = ModelPool(
            cheap=[m.id for m in available if m.tier.value == "simple"][:2],
            mid=[m.id for m in available if m.tier.value == "medium"][:2],
            premium=[m.id for m in available if m.tier.value == "complex"][:1],
        )

        debate = DebateEngine(
            engine=_completion_engine,
            model_pool=pool,
            config=DebateConfig(max_rounds=2),
        )

        result = await debate.debate(topic=user_text)

        if result and result.synthesis:
            logger.info(
                "debate_complete",
                rounds=result.total_rounds,
                consensus=result.consensus_score,
                cost=result.total_cost,
            )
            return web.json_response(build_anthropic_response(
                content=result.synthesis,
                model=primary_model,
                output_tokens=len(result.synthesis.split()) * 2,
            ))
    except Exception as exc:
        logger.debug("debate_error", error=str(exc))

    return None


async def _try_parallel_consensus(
    messages: list[dict[str, Any]],
    user_text: str,
    primary_model: str,
    max_tokens: int,
    temperature: float,
) -> web.Response | None:
    """Fallback: run 2 models in parallel, pick the better answer."""
    if not _provider_registry:
        return None

    try:
        available = _provider_registry.get_available_models()
        if len(available) < 2:
            return None

        models_to_try = [primary_model]
        for m in available:
            if m.id != primary_model and m.id not in models_to_try:
                models_to_try.append(m.id)
                if len(models_to_try) >= 2:
                    break

        if len(models_to_try) < 2:
            return None

        results = await _completion_engine.complete_parallel(
            messages=messages,
            models=models_to_try[:2],
            temperature=temperature,
            max_tokens=max_tokens,
        )

        if not results:
            return None

        if len(results) == 1:
            best = results[0]
        else:
            best = max(results, key=lambda r: len(r.content or ""))
            logger.info(
                "parallel_consensus",
                model_a=results[0].model,
                model_b=results[1].model,
                picked=best.model,
            )

        return web.json_response(build_anthropic_response(
            content=best.content or "",
            model=best.model,
            input_tokens=best.input_tokens,
            output_tokens=best.output_tokens,
            finish_reason=best.finish_reason,
        ))

    except Exception as exc:
        logger.debug("parallel_consensus_error", error=str(exc))
        return None


async def _try_swarm(
    messages: list[dict[str, Any]],
    user_text: str,
    primary_model: str,
    max_tokens: int,
    temperature: float,
) -> web.Response | None:
    """Try SwarmOrchestrator for ultra-complex multi-step tasks.

    The swarm decomposes the task into subtasks, researches, plans,
    executes with cross-review, and integrates.  Best for tasks that
    need multiple phases of work (large refactors, multi-file features).
    """
    try:
        from prism.orchestrator.swarm import SwarmConfig, SwarmOrchestrator
    except ImportError:
        return None

    if not _provider_registry or not _completion_engine:
        return None

    # Swarm needs a reasonably long prompt to decompose
    if len(user_text) < 100:
        return None

    try:
        config = SwarmConfig(
            use_debate=True,
            use_moa=True,
            use_cascade=True,
            use_tools=False,  # Proxy doesn't expose tool execution
            total_budget=0.50,
            max_retries=1,
        )

        swarm = SwarmOrchestrator(
            engine=_completion_engine,
            registry=_provider_registry,
            config=config,
        )

        plan = await swarm.orchestrate(goal=user_text)

        if plan and not plan.budget_exhausted:
            # Collect all task results into a coherent response
            parts: list[str] = []
            if plan.plan_text:
                parts.append(plan.plan_text)
            for task in plan.tasks:
                if task.result:
                    parts.append(task.result)

            if parts:
                combined = "\n\n".join(parts)
                logger.info(
                    "swarm_complete",
                    tasks=len(plan.tasks),
                    cost=plan.total_cost,
                    phases=list(plan.phase_costs.keys()),
                )
                return web.json_response(build_anthropic_response(
                    content=combined,
                    model=primary_model,
                    output_tokens=len(combined.split()) * 2,
                ))
    except Exception as exc:
        logger.debug("swarm_error", error=str(exc))

    return None


# ---------------------------------------------------------------------------
# Cache, validation, learning, and health helpers
# ---------------------------------------------------------------------------


def _make_cache_key(
    model: str,
    system: str | list,
    messages: list[dict],
) -> str:
    """Build a cache key from request parameters."""
    try:
        from prism.cache.response_cache import ResponseCache

        system_str = system if isinstance(system, str) else json.dumps(system)
        user_text = ""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                content = msg.get("content", "")
                user_text = content if isinstance(content, str) else json.dumps(content)
                break
        return ResponseCache.make_cache_key(model, system_str, user_text)
    except Exception:
        # Fallback: simple hash
        raw = f"{model}:{system}:{json.dumps(messages[-1:])}"
        return _hashlib.sha256(raw.encode()).hexdigest()


async def _stream_cached_response(
    request: web.Request,
    cached: Any,
) -> web.StreamResponse:
    """Replay a cached response as SSE events."""
    events = build_anthropic_stream_events(
        content=cached.content,
        model=cached.model,
        input_tokens=cached.input_tokens,
        output_tokens=cached.output_tokens,
    )

    response = web.StreamResponse(
        status=200,
        reason="OK",
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Prism-Model": cached.model,
            "X-Prism-Cache": "hit",
        },
    )
    await response.prepare(request)

    for event_type, event_data in events:
        await _send_sse(response, event_type, event_data)

    return response


def _record_learning_outcome(
    model: str,
    outcome: str,
    result: Any,
) -> None:
    """Record an outcome for adaptive learning."""
    if not _adaptive_learner:
        return
    try:
        # Determine complexity tier
        tier = None
        if _router_classifier:
            try:
                from prism.router.classifier import ComplexityTier
                tier = ComplexityTier.MEDIUM  # Default
            except ImportError:
                return

        cost = 0.0
        if result and hasattr(result, "cost"):
            cost = result.cost or 0.0

        if tier:
            _adaptive_learner.record_outcome(
                model=model,
                tier=tier,
                outcome=outcome,
                cost=cost,
            )
    except Exception as exc:
        logger.debug("learning_record_error", error=str(exc))


def _is_provider_healthy(model: str) -> bool:
    """Check if a model's provider is currently healthy."""
    if not _health_checker:
        return True  # No checker = assume healthy
    try:
        # Extract provider name from model ID
        provider = model.split("/")[0] if "/" in model else _infer_provider(model)
        unavailable = _health_checker.get_unavailable_providers()
        return provider not in unavailable
    except Exception:
        return True  # On error, assume healthy


def _is_reliable_for_tools(model: str) -> bool:
    """Check if a model is known to reliably support tool use.

    OpenRouter free-tier models are marked as supporting tools in the
    registry but OpenRouter's routing often can't find free endpoints
    that actually handle tool_calls.  Deprioritise them when tools
    are needed.
    """
    # OpenRouter free models are unreliable for tool use
    if "openrouter/" in model and ":free" in model:
        return False
    return True


def _infer_provider(model: str) -> str:
    """Infer provider name from model ID."""
    if model.startswith(("claude-", "claude_")):
        return "anthropic"
    if model.startswith(("gpt-", "o1-", "o3-")):
        return "openai"
    if model.startswith("gemini"):
        return "google"
    if model.startswith("deepseek"):
        return "deepseek"
    if model.startswith(("llama", "mixtral", "qwen")):
        return "groq"
    return "unknown"


# ---------------------------------------------------------------------------
# Health, info, and performance endpoints
# ---------------------------------------------------------------------------


async def handle_health(request: web.Request) -> web.Response:
    """GET /health -- simple health check."""
    return web.json_response({"status": "ok", "service": "prism-proxy"})


async def handle_models(request: web.Request) -> web.Response:
    """GET /v1/models -- list available models (Anthropic-compatible)."""
    models = []
    if _provider_registry:
        try:
            for m in _provider_registry.get_available_models():
                models.append({
                    "id": m.id,
                    "object": "model",
                    "created": 0,
                    "owned_by": m.provider,
                })
        except Exception:
            pass

    return web.json_response({"object": "list", "data": models})


async def handle_cost(request: web.Request) -> web.Response:
    """GET /prism/cost -- show cost tracking dashboard."""
    data: dict[str, Any] = {"service": "prism-proxy", "tracking": False}

    if _cost_tracker:
        data["tracking"] = True
        try:
            data["today"] = _cost_tracker.get_today_cost()
            data["budget_remaining"] = _cost_tracker.get_budget_remaining()
            data["total"] = _cost_tracker.get_total_cost()
        except Exception:
            pass

    if _provider_registry:
        try:
            available = _provider_registry.get_available_models()
            data["available_models"] = len(available)
            data["providers"] = list(set(m.provider for m in available))
        except Exception:
            pass

    return web.json_response(data)


async def handle_provider_health(request: web.Request) -> web.Response:
    """GET /prism/health -- detailed provider health status."""
    data: dict[str, Any] = {"service": "prism-proxy"}

    if _health_checker:
        try:
            results = _health_checker.get_results()
            data["providers"] = {}
            for provider, result in results.items():
                data["providers"][provider] = {
                    "available": result.available,
                    "latency_ms": result.latency_ms,
                    "error": result.error,
                    "checked_at": str(result.checked_at) if hasattr(result, "checked_at") else None,
                }
            data["healthy"] = _health_checker.get_available_providers()
            data["unhealthy"] = _health_checker.get_unavailable_providers()
        except Exception as exc:
            data["error"] = str(exc)
    else:
        data["message"] = "Health checker not configured"

    # Cache stats
    if _response_cache:
        try:
            stats = _response_cache.get_stats()
            data["cache"] = {
                "entries": stats.total_entries,
                "hit_rate": stats.hit_rate,
                "tokens_saved": stats.tokens_saved,
                "cost_saved": stats.cost_saved,
            }
        except Exception:
            pass

    # In-memory LRU stats
    with _lru_lock:
        data["memory_cache"] = {
            "entries": len(_lru_cache),
            "max_entries": _LRU_MAX,
        }

    # Learning stats
    if _adaptive_learner:
        try:
            data["adaptive_learning"] = {
                "active": _adaptive_learner.is_active,
                "total_interactions": _adaptive_learner.total_interactions,
            }
        except Exception:
            pass

    return web.json_response(data)


async def handle_perf(request: web.Request) -> web.Response:
    """GET /prism/perf -- show latency stats, cache stats, and performance data.

    [NEW ENDPOINT] Returns per-model latency P50/P99, in-memory cache stats,
    classification cache stats, inflight request count, and fallback chain
    cache stats.
    """
    data: dict[str, Any] = {
        "service": "prism-proxy",
        "multi_agent_enabled": _multi_agent_enabled,
    }

    # Per-model latency stats
    model_latency: dict[str, dict[str, Any]] = {}
    for model_id, samples in _latency_samples.items():
        if not samples:
            continue
        s = sorted(samples)
        model_latency[model_id] = {
            "sample_count": len(s),
            "p50_ms": int(s[len(s) // 2]),
            "p99_ms": int(s[min(int(len(s) * 0.99), len(s) - 1)]),
            "min_ms": int(s[0]),
            "max_ms": int(s[-1]),
            "avg_ms": int(sum(s) / len(s)),
        }
    data["latency"] = model_latency

    # In-memory LRU cache
    with _lru_lock:
        data["memory_cache"] = {
            "entries": len(_lru_cache),
            "max_entries": _LRU_MAX,
        }

    # Classification cache
    with _classification_lock:
        data["classification_cache"] = {
            "entries": len(_classification_cache),
            "max_entries": _CLASSIFICATION_CACHE_MAX,
        }

    # In-flight requests
    with _inflight_lock:
        data["inflight_requests"] = len(_inflight)

    # Pre-computed fallback chains
    data["fallback_chains_cached"] = len(_fallback_chains)
    data["fallback_chains_built"] = _fallback_chains_built

    # SSE batching config
    data["sse_batching"] = {
        "max_events": _SSE_BATCH_MAX_EVENTS,
        "max_wait_ms": _SSE_BATCH_MAX_WAIT_MS,
    }

    return web.json_response(data)


async def handle_status(request: web.Request) -> web.Response:
    """GET /prism/status -- show full Prism status including all features."""
    features = {
        "routing": _router_classifier is not None,
        "model_selection": _router_selector is not None,
        "cost_tracking": _cost_tracker is not None,
        "budget_enforcement": _cost_tracker is not None,
        "provider_registry": _provider_registry is not None,
        "auth_manager": _auth_manager is not None,
        "response_cache": _response_cache is not None,
        "adaptive_learning": _adaptive_learner is not None,
        "health_checker": _health_checker is not None,
        "response_validation": _response_validator is not None,
        "multi_agent_enabled": _multi_agent_enabled,
    }

    # Check orchestration features
    try:
        from prism.orchestrator.cascade import ConfidenceCascade  # noqa: F401
        features["confidence_cascade"] = True
    except ImportError:
        features["confidence_cascade"] = False

    try:
        from prism.orchestrator.moa import MixtureOfAgents  # noqa: F401
        features["mixture_of_agents"] = True
    except ImportError:
        features["mixture_of_agents"] = False

    try:
        from prism.orchestrator.debate import DebateEngine  # noqa: F401
        features["debate"] = True
    except ImportError:
        features["debate"] = False

    try:
        from prism.orchestrator.swarm import SwarmOrchestrator  # noqa: F401
        features["swarm"] = True
    except ImportError:
        features["swarm"] = False

    models = []
    if _provider_registry:
        try:
            for m in _provider_registry.get_available_models():
                models.append({
                    "id": m.id,
                    "provider": m.provider,
                    "tier": m.tier.value,
                    "supports_tools": m.supports_tools,
                })
        except Exception:
            pass

    return web.json_response({
        "service": "prism-proxy",
        "features": features,
        "models": models,
        "multi_agent_strategies": [
            k for k, v in features.items()
            if v and k in (
                "confidence_cascade", "mixture_of_agents", "debate", "swarm",
            )
        ],
    })


# ---------------------------------------------------------------------------
# Server factory
# ---------------------------------------------------------------------------


def create_app(
    completion_engine: Any,
    cost_tracker: Any | None = None,
    provider_registry: Any | None = None,
    auth_manager: Any | None = None,
    settings: Any | None = None,
    router_classifier: Any | None = None,
    router_selector: Any | None = None,
    response_cache: Any | None = None,
    adaptive_learner: Any | None = None,
    health_checker: Any | None = None,
    response_validator: Any | None = None,
    multi_agent_enabled: bool = False,
) -> web.Application:
    """Create the aiohttp application with all routes.

    Args:
        completion_engine: Prism's CompletionEngine instance.
        cost_tracker: Optional CostTracker for budget enforcement.
        provider_registry: Optional ProviderRegistry for model lookup.
        auth_manager: Optional AuthManager for API keys.
        settings: Optional Settings.
        router_classifier: Optional TaskClassifier for intelligent routing.
        router_selector: Optional ModelSelector for model selection.
        response_cache: Optional ResponseCache for request deduplication.
        adaptive_learner: Optional AdaptiveLearner for routing improvement.
        health_checker: Optional HealthChecker for provider monitoring.
        response_validator: Optional ResponseValidator for output sanitisation.
        multi_agent_enabled: Whether multi-agent strategies are enabled
            (default False for speed).

    Returns:
        An aiohttp Application ready to run.
    """
    global _completion_engine, _cost_tracker, _provider_registry
    global _auth_manager, _settings, _router_classifier, _router_selector
    global _response_cache, _adaptive_learner, _health_checker, _response_validator
    global _multi_agent_enabled

    _completion_engine = completion_engine
    _cost_tracker = cost_tracker
    _provider_registry = provider_registry
    _auth_manager = auth_manager
    _settings = settings
    _router_classifier = router_classifier
    _router_selector = router_selector
    _response_cache = response_cache
    _adaptive_learner = adaptive_learner
    _health_checker = health_checker
    _response_validator = response_validator
    _multi_agent_enabled = multi_agent_enabled

    # Pre-compute fallback chains at startup
    if _provider_registry:
        _precompute_fallback_chains()
        global _fallback_chains_built
        _fallback_chains_built = True

    app = web.Application()
    app.router.add_post("/v1/messages", handle_messages)
    app.router.add_get("/v1/models", handle_models)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/prism/cost", handle_cost)
    app.router.add_get("/prism/health", handle_provider_health)
    app.router.add_get("/prism/status", handle_status)
    app.router.add_get("/prism/perf", handle_perf)

    # Also handle the root for basic info
    app.router.add_get("/", handle_health)

    # Start background health checks
    if _health_checker:
        try:
            _health_checker.start_background_checks(interval_seconds=300)
            logger.info("health_checks_started")
        except Exception as exc:
            logger.debug("health_checks_start_error", error=str(exc))

    # Register cleanup on shutdown
    app.on_cleanup.append(_cleanup_on_shutdown)

    return app


async def _cleanup_on_shutdown(app: web.Application) -> None:
    """Clean up resources on server shutdown."""
    if _health_checker:
        try:
            _health_checker.stop_background_checks()
        except Exception:
            pass

    if _response_cache:
        try:
            _response_cache.close()
        except Exception:
            pass

    # Clean up in-flight futures
    with _inflight_lock:
        for key, fut in _inflight.items():
            if not fut.done():
                fut.cancel()
        _inflight.clear()


async def run_server(
    host: str = "127.0.0.1",
    port: int = 8080,
    completion_engine: Any = None,
    cost_tracker: Any | None = None,
    provider_registry: Any | None = None,
    auth_manager: Any | None = None,
    settings: Any | None = None,
    router_classifier: Any | None = None,
    router_selector: Any | None = None,
    response_cache: Any | None = None,
    adaptive_learner: Any | None = None,
    health_checker: Any | None = None,
    response_validator: Any | None = None,
    multi_agent_enabled: bool = False,
) -> None:
    """Start the proxy server.

    Args:
        host: Bind address.
        port: Bind port.
        completion_engine: Prism's CompletionEngine.
        cost_tracker: Optional CostTracker.
        provider_registry: Optional ProviderRegistry.
        auth_manager: Optional AuthManager.
        settings: Optional Settings.
        router_classifier: Optional TaskClassifier.
        router_selector: Optional ModelSelector.
        response_cache: Optional ResponseCache.
        adaptive_learner: Optional AdaptiveLearner.
        health_checker: Optional HealthChecker.
        response_validator: Optional ResponseValidator.
        multi_agent_enabled: Whether to enable multi-agent strategies
            (default False for speed).
    """
    app = create_app(
        completion_engine=completion_engine,
        cost_tracker=cost_tracker,
        provider_registry=provider_registry,
        auth_manager=auth_manager,
        settings=settings,
        router_classifier=router_classifier,
        router_selector=router_selector,
        response_cache=response_cache,
        adaptive_learner=adaptive_learner,
        health_checker=health_checker,
        response_validator=response_validator,
        multi_agent_enabled=multi_agent_enabled,
    )

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)
    await site.start()

    logger.info("proxy_started", host=host, port=port, multi_agent=multi_agent_enabled)
    print(f"\n  Prism proxy running at http://{host}:{port}")
    print(f"  Multi-agent: {'enabled' if multi_agent_enabled else 'disabled (fast mode)'}")
    print(f"\n  Point Claude Code at it:")
    print(f"    export ANTHROPIC_BASE_URL=http://{host}:{port}")
    print(f"    export ANTHROPIC_API_KEY=prism")
    print(f"    claude\n")

    # Run forever
    try:
        await asyncio.Event().wait()
    finally:
        await runner.cleanup()
