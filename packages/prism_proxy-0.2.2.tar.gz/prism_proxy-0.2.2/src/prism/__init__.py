"""Prism — Multi-API Intelligent Router CLI."""

__version__ = "0.2.2"
__app_name__ = "prism"
