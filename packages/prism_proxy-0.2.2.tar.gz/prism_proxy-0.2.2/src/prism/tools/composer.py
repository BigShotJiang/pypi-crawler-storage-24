"""Tool composition primitives — sequence, parallel, branch, retry.

Provides declarative combinators for orchestrating multi-tool workflows
without writing procedural code.  Think of it as shell pipes (|) and
logical operators (&&, ||) for AI tool chains.

Usage::

    chain = (
        Sequence("deploy")
        .then(Step("run_tests", tool="terminal", args={"command": "pytest"}))
        .then(
            Branch("check_results")
            .on_success(Step("deploy", tool="terminal", args={"command": "deploy.sh"}))
            .on_failure(Step("notify", tool="terminal", args={"command": "echo FAIL"}))
        )
    )
    result = await chain.execute(context)

Combinators:
    - **Sequence**: Execute steps one after another (A → B → C)
    - **Parallel**: Execute steps concurrently (A | B | C)
    - **Branch**: Conditional execution based on previous result
    - **Retry**: Retry a step on failure with backoff
    - **Loop**: Repeat a step until a condition is met
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


class StepStatus(Enum):
    """Execution status of a step."""

    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    TIMEOUT = "timeout"


@dataclass
class StepResult:
    """Result of executing a single step.

    Attributes:
        step_name: Name of the step.
        status: Execution status.
        output: Output data from the step.
        error: Error message if failed.
        duration_ms: Execution time in milliseconds.
        metadata: Additional metadata.
    """

    step_name: str
    status: StepStatus
    output: Any = None
    error: str = ""
    duration_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def succeeded(self) -> bool:
        """Whether the step completed successfully."""
        return self.status == StepStatus.SUCCESS


@dataclass
class ChainResult:
    """Result of executing a full chain.

    Attributes:
        chain_name: Name of the chain.
        steps: Results from each step.
        total_duration_ms: Total execution time.
        success: Whether the chain completed successfully.
    """

    chain_name: str
    steps: list[StepResult]
    total_duration_ms: float
    success: bool

    @property
    def last_output(self) -> Any:
        """Output from the last successful step."""
        for step in reversed(self.steps):
            if step.succeeded and step.output is not None:
                return step.output
        return None

    @property
    def all_outputs(self) -> dict[str, Any]:
        """All step outputs keyed by step name."""
        return {s.step_name: s.output for s in self.steps if s.output is not None}


# ---------------------------------------------------------------------------
# Context object passed through the chain
# ---------------------------------------------------------------------------


@dataclass
class ChainContext:
    """Execution context passed through a chain.

    Stores outputs from previous steps and shared state.

    Attributes:
        variables: Shared variables accessible to all steps.
        step_outputs: Outputs from completed steps (keyed by step name).
        executor: Async callable that executes a tool.  Signature:
            ``async def executor(tool: str, args: dict) -> Any``
    """

    variables: dict[str, Any] = field(default_factory=dict)
    step_outputs: dict[str, Any] = field(default_factory=dict)
    executor: Any = None  # Callable[[str, dict], Awaitable[Any]]

    def get(self, key: str, default: Any = None) -> Any:
        """Get a variable or step output."""
        if key in self.variables:
            return self.variables[key]
        if key in self.step_outputs:
            return self.step_outputs[key]
        return default

    def set(self, key: str, value: Any) -> None:
        """Set a variable."""
        self.variables[key] = value


# ---------------------------------------------------------------------------
# Base composable node
# ---------------------------------------------------------------------------


class ComposableNode:
    """Base class for all composition nodes."""

    def __init__(self, name: str) -> None:
        self.name = name

    async def execute(self, context: ChainContext) -> StepResult:
        """Execute this node.

        Args:
            context: Execution context.

        Returns:
            StepResult from execution.
        """
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Step — a single tool invocation
# ---------------------------------------------------------------------------


class Step(ComposableNode):
    """A single tool invocation step.

    Args:
        name: Step name for identification.
        tool: Tool name to invoke.
        args: Arguments to pass to the tool.
        transform: Optional function to transform the result.
        timeout_ms: Maximum execution time in milliseconds.
    """

    def __init__(
        self,
        name: str,
        tool: str = "",
        args: dict[str, Any] | None = None,
        transform: Any = None,
        timeout_ms: float = 30000,
    ) -> None:
        super().__init__(name)
        self.tool = tool
        self.args = args or {}
        self.transform = transform
        self.timeout_ms = timeout_ms

    async def execute(self, context: ChainContext) -> StepResult:
        """Execute the tool step."""
        start = time.perf_counter()

        try:
            if context.executor is None:
                return StepResult(
                    step_name=self.name,
                    status=StepStatus.FAILED,
                    error="No executor configured in context",
                )

            # Resolve variable references in args
            resolved_args = self._resolve_args(context)

            result = await asyncio.wait_for(
                context.executor(self.tool, resolved_args),
                timeout=self.timeout_ms / 1000,
            )

            if self.transform:
                result = self.transform(result)

            elapsed = (time.perf_counter() - start) * 1000
            context.step_outputs[self.name] = result

            return StepResult(
                step_name=self.name,
                status=StepStatus.SUCCESS,
                output=result,
                duration_ms=elapsed,
            )

        except TimeoutError:
            elapsed = (time.perf_counter() - start) * 1000
            return StepResult(
                step_name=self.name,
                status=StepStatus.TIMEOUT,
                error=f"Step timed out after {self.timeout_ms}ms",
                duration_ms=elapsed,
            )
        except Exception as exc:
            elapsed = (time.perf_counter() - start) * 1000
            return StepResult(
                step_name=self.name,
                status=StepStatus.FAILED,
                error=str(exc),
                duration_ms=elapsed,
            )

    def _resolve_args(self, context: ChainContext) -> dict[str, Any]:
        """Resolve variable references like ${step_name} in args."""
        resolved: dict[str, Any] = {}
        for key, value in self.args.items():
            if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                ref = value[2:-1]
                resolved[key] = context.get(ref, value)
            else:
                resolved[key] = value
        return resolved


# ---------------------------------------------------------------------------
# Sequence — execute steps in order
# ---------------------------------------------------------------------------


class Sequence(ComposableNode):
    """Execute steps sequentially, stopping on first failure.

    Args:
        name: Chain name.
        stop_on_failure: If True, stop on first failure.  Default True.
    """

    def __init__(self, name: str, stop_on_failure: bool = True) -> None:
        super().__init__(name)
        self._steps: list[ComposableNode] = []
        self._stop_on_failure = stop_on_failure

    def then(self, step: ComposableNode) -> Sequence:
        """Add a step to the sequence.

        Args:
            step: Step to append.

        Returns:
            Self for chaining.
        """
        self._steps.append(step)
        return self

    async def execute(self, context: ChainContext) -> StepResult:
        """Execute all steps in sequence."""
        start = time.perf_counter()
        results: list[StepResult] = []

        for step in self._steps:
            result = await step.execute(context)
            results.append(result)

            if not result.succeeded and self._stop_on_failure:
                logger.info(
                    "sequence_stopped",
                    chain=self.name,
                    failed_step=step.name,
                    error=result.error,
                )
                break

        elapsed = (time.perf_counter() - start) * 1000
        all_succeeded = all(r.succeeded for r in results)

        return StepResult(
            step_name=self.name,
            status=StepStatus.SUCCESS if all_succeeded else StepStatus.FAILED,
            output=results,
            duration_ms=elapsed,
            metadata={"step_count": len(results)},
        )

    @property
    def steps(self) -> list[ComposableNode]:
        """Get the list of steps."""
        return list(self._steps)


# ---------------------------------------------------------------------------
# Parallel — execute steps concurrently
# ---------------------------------------------------------------------------


class Parallel(ComposableNode):
    """Execute steps concurrently, collecting all results.

    Args:
        name: Group name.
        require_all: If True, fail if any step fails.  Default False.
    """

    def __init__(self, name: str, require_all: bool = False) -> None:
        super().__init__(name)
        self._steps: list[ComposableNode] = []
        self._require_all = require_all

    def add(self, step: ComposableNode) -> Parallel:
        """Add a step to run in parallel.

        Args:
            step: Step to add.

        Returns:
            Self for chaining.
        """
        self._steps.append(step)
        return self

    async def execute(self, context: ChainContext) -> StepResult:
        """Execute all steps concurrently."""
        start = time.perf_counter()

        tasks = [step.execute(context) for step in self._steps]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        step_results: list[StepResult] = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                step_results.append(StepResult(
                    step_name=self._steps[i].name,
                    status=StepStatus.FAILED,
                    error=str(result),
                ))
            else:
                step_results.append(result)

        elapsed = (time.perf_counter() - start) * 1000

        if self._require_all:
            success = all(r.succeeded for r in step_results)
        else:
            success = any(r.succeeded for r in step_results)

        return StepResult(
            step_name=self.name,
            status=StepStatus.SUCCESS if success else StepStatus.FAILED,
            output=step_results,
            duration_ms=elapsed,
            metadata={"parallel_count": len(step_results)},
        )


# ---------------------------------------------------------------------------
# Branch — conditional execution
# ---------------------------------------------------------------------------


class Branch(ComposableNode):
    """Conditional execution based on a predicate or previous result.

    Args:
        name: Branch name.
        condition: Callable that takes ChainContext and returns bool.
            If None, branches based on the last step's success.
    """

    def __init__(
        self,
        name: str,
        condition: Any = None,
    ) -> None:
        super().__init__(name)
        self._condition = condition
        self._on_true: ComposableNode | None = None
        self._on_false: ComposableNode | None = None

    def on_success(self, step: ComposableNode) -> Branch:
        """Step to execute when condition is true (or last step succeeded).

        Args:
            step: Step for the success path.

        Returns:
            Self for chaining.
        """
        self._on_true = step
        return self

    def on_failure(self, step: ComposableNode) -> Branch:
        """Step to execute when condition is false (or last step failed).

        Args:
            step: Step for the failure path.

        Returns:
            Self for chaining.
        """
        self._on_false = step
        return self

    async def execute(self, context: ChainContext) -> StepResult:
        """Execute the appropriate branch."""
        start = time.perf_counter()

        # Evaluate condition
        if self._condition is not None:
            try:
                condition_result = self._condition(context)
            except Exception:
                condition_result = False
        else:
            # Default: check if last step output is truthy
            last_outputs = list(context.step_outputs.values())
            condition_result = bool(last_outputs[-1]) if last_outputs else False

        # Execute appropriate branch
        branch_step = self._on_true if condition_result else self._on_false
        if branch_step is None:
            elapsed = (time.perf_counter() - start) * 1000
            return StepResult(
                step_name=self.name,
                status=StepStatus.SKIPPED,
                duration_ms=elapsed,
                metadata={"condition": condition_result, "branch": "none"},
            )

        result = await branch_step.execute(context)
        elapsed = (time.perf_counter() - start) * 1000

        return StepResult(
            step_name=self.name,
            status=result.status,
            output=result.output,
            error=result.error,
            duration_ms=elapsed,
            metadata={
                "condition": condition_result,
                "branch": "success" if condition_result else "failure",
                "executed_step": branch_step.name,
            },
        )


# ---------------------------------------------------------------------------
# Retry — retry on failure with backoff
# ---------------------------------------------------------------------------


class Retry(ComposableNode):
    """Retry a step on failure with configurable backoff.

    Args:
        name: Retry wrapper name.
        step: The step to retry.
        max_retries: Maximum number of retry attempts.
        backoff_ms: Initial backoff in milliseconds.
        backoff_multiplier: Multiplier for exponential backoff.
    """

    def __init__(
        self,
        name: str,
        step: ComposableNode,
        max_retries: int = 3,
        backoff_ms: float = 1000,
        backoff_multiplier: float = 2.0,
    ) -> None:
        super().__init__(name)
        self._step = step
        self._max_retries = max_retries
        self._backoff_ms = backoff_ms
        self._multiplier = backoff_multiplier

    async def execute(self, context: ChainContext) -> StepResult:
        """Execute with retries."""
        start = time.perf_counter()
        last_result: StepResult | None = None
        backoff = self._backoff_ms

        for attempt in range(self._max_retries + 1):
            result = await self._step.execute(context)

            if result.succeeded:
                elapsed = (time.perf_counter() - start) * 1000
                result.metadata["attempts"] = attempt + 1
                result.duration_ms = elapsed
                return result

            last_result = result

            if attempt < self._max_retries:
                logger.info(
                    "retry_attempt",
                    step=self._step.name,
                    attempt=attempt + 1,
                    max_retries=self._max_retries,
                    backoff_ms=backoff,
                )
                await asyncio.sleep(backoff / 1000)
                backoff *= self._multiplier

        elapsed = (time.perf_counter() - start) * 1000
        final = last_result or StepResult(
            step_name=self.name,
            status=StepStatus.FAILED,
            error="Max retries exceeded",
        )
        final.duration_ms = elapsed
        final.metadata["attempts"] = self._max_retries + 1
        return final


# ---------------------------------------------------------------------------
# Loop — repeat until condition
# ---------------------------------------------------------------------------


class Loop(ComposableNode):
    """Repeat a step until a condition is met or max iterations reached.

    Args:
        name: Loop name.
        step: The step to repeat.
        condition: Callable(ChainContext) → bool.  Stops when True.
        max_iterations: Safety limit on iterations.
    """

    def __init__(
        self,
        name: str,
        step: ComposableNode,
        condition: Any,
        max_iterations: int = 10,
    ) -> None:
        super().__init__(name)
        self._step = step
        self._condition = condition
        self._max_iterations = max_iterations

    async def execute(self, context: ChainContext) -> StepResult:
        """Execute the loop."""
        start = time.perf_counter()
        results: list[StepResult] = []

        for iteration in range(self._max_iterations):
            result = await self._step.execute(context)
            results.append(result)

            if not result.succeeded:
                break

            try:
                if self._condition(context):
                    break
            except Exception:
                break

        elapsed = (time.perf_counter() - start) * 1000
        all_ok = all(r.succeeded for r in results)

        return StepResult(
            step_name=self.name,
            status=StepStatus.SUCCESS if all_ok else StepStatus.FAILED,
            output=results,
            duration_ms=elapsed,
            metadata={"iterations": len(results)},
        )
