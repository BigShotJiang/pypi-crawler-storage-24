"""Streaming token display handler for the REPL.

Uses Rich's Live display to progressively render Markdown as tokens arrive.
Shows a spinner while waiting for the first token, then switches to
streaming Markdown with batched refresh for smooth display.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from rich.console import Console

logger = structlog.get_logger(__name__)

# Bullet prefix for AI responses (like Claude CLI)
_BULLET = "\u25cf"  # ● solid circle

# Refresh interval in seconds (batch tokens, render every N ms)
_REFRESH_INTERVAL = 0.04  # 40ms = 25fps — smooth without being CPU-bound


class StreamHandler:
    """Handles streaming token display with Rich Markdown rendering.

    Shows a "Thinking..." spinner until the first token arrives, then
    progressively renders Markdown in a Rich Live display with batched
    token refresh for smooth, efficient rendering.

    Includes repetition detection: if the model starts generating the
    same block of text repeatedly, display is stopped and the content
    is trimmed to the first clean occurrence.

    Args:
        console: The Rich console for rendering.
    """

    # Repetition detection settings
    _REPEAT_CHECK_INTERVAL = 200
    _MIN_CONTENT_FOR_CHECK = 600

    def __init__(self, console: Console) -> None:
        self.console = console
        self.buffer: str = ""
        self._token_count: int = 0
        self._thinking: bool = False
        self._streaming: bool = False
        self._live: object | None = None
        self._chars_since_check: int = 0
        self.repetition_detected: bool = False
        self._last_render_time: float = 0.0
        self._dirty: bool = False

    def show_thinking(self) -> None:
        """Show a spinner while waiting for the first token."""
        from rich.live import Live
        from rich.spinner import Spinner

        self._live = Live(
            Spinner("dots", text="[dim] Thinking...[/dim]"),
            console=self.console,
            refresh_per_second=10,
            transient=True,
        )
        self._live.start()
        self._thinking = True

    def _check_repetition(self) -> bool:
        """Check if the buffer contains repetitive content.

        Uses sliding window detection: if a recent block of text (100-300
        chars) already appeared earlier in the buffer, the model is looping.
        """
        if len(self.buffer) < self._MIN_CONTENT_FOR_CHECK:
            return False

        for window_size in (300, 200, 100):
            if len(self.buffer) < window_size * 2:
                continue
            tail = self.buffer[-window_size:]
            earlier = self.buffer[: len(self.buffer) - window_size]
            if tail in earlier:
                return True

        # Line-based check: if last 5 non-empty lines all appear earlier
        lines = [ln for ln in self.buffer.split("\n") if ln.strip()]
        if len(lines) >= 10:
            recent = lines[-5:]
            earlier_text = "\n".join(lines[:-5])
            if sum(1 for ln in recent if ln in earlier_text) >= 4:
                return True

        return False

    def _render(self) -> None:
        """Render the current buffer to the live display."""
        if self._live is not None:
            from rich.markdown import Markdown

            self._live.update(Markdown(self.buffer))
            self._live.refresh()
        self._last_render_time = time.monotonic()
        self._dirty = False

    def on_token(self, token: str) -> None:
        """Called for each streaming token delta.

        On first token: replaces spinner with Live Markdown display.
        On subsequent tokens: batches updates and renders at a fixed
        interval (every ~40ms) for smooth display without CPU thrashing.

        If repetition is detected, stops accepting tokens and trims
        the buffer to clean content.
        """
        if not token:
            return

        # Stop accepting tokens once repetition detected
        if self.repetition_detected:
            return

        # First token — switch from spinner to markdown streaming
        if not self._streaming:
            if self._live is not None:
                self._live.stop()
                self._live = None

            from rich.live import Live
            from rich.markdown import Markdown

            self._live = Live(
                Markdown(""),
                console=self.console,
                refresh_per_second=30,
                vertical_overflow="visible",
            )
            self._live.start()
            self._streaming = True
            self._thinking = False
            self._last_render_time = time.monotonic()

        self.buffer += token
        self._token_count += 1
        self._chars_since_check += len(token)
        self._dirty = True

        # Periodic repetition check
        if self._chars_since_check >= self._REPEAT_CHECK_INTERVAL:
            self._chars_since_check = 0
            if self._check_repetition():
                self.repetition_detected = True
                # Trim: find where the repeated block starts and cut there
                for ws in (300, 200, 100):
                    if len(self.buffer) < ws * 2:
                        continue
                    tail = self.buffer[-ws:]
                    earlier = self.buffer[: len(self.buffer) - ws]
                    pos = earlier.find(tail)
                    if pos >= 0:
                        self.buffer = self.buffer[: pos + ws]
                        break
                logger.warning(
                    "stream_repetition_detected",
                    token_count=self._token_count,
                    trimmed_len=len(self.buffer),
                )
                self._render()
                return

        # Batched rendering: only re-render if enough time has passed
        now = time.monotonic()
        if now - self._last_render_time >= _REFRESH_INTERVAL:
            self._render()

    def finalize(self) -> str:
        """Stop the Live display and return the full content."""
        if self._live is not None:
            if self._streaming and self._dirty:
                from rich.markdown import Markdown

                self._live.update(Markdown(self.buffer))
            self._live.stop()
            self._live = None

        return self.buffer

    @property
    def token_count(self) -> int:
        """Number of tokens received so far."""
        return self._token_count

    @property
    def has_content(self) -> bool:
        """Whether any content has been received."""
        return len(self.buffer) > 0

    def reset(self) -> None:
        """Reset the handler for reuse."""
        if self._live is not None:
            self._live.stop()
            self._live = None
        self.buffer = ""
        self._token_count = 0
        self._thinking = False
        self._streaming = False
        self._dirty = False
        self._last_render_time = 0.0
        self._chars_since_check = 0
        self.repetition_detected = False
