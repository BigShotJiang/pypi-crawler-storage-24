"""Autonomous context engine for Prism.

Before the model sees a user prompt, this module gathers everything the
model would need to solve the task: referenced files, their imports, test
files, git state, recent errors, and project structure.  The goal is to
make even a small model behave like an expert — because by the time it
sees the prompt, all the relevant context is already there.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from pathlib import Path

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Keyword lists used for strategy detection
# ---------------------------------------------------------------------------

_DEBUG_WORDS: tuple[str, ...] = (
    "error", "bug", "fix", "crash", "traceback", "exception",
    "fail", "broken", "debug", "issue", "wrong", "doesn't work",
    "not working", "problem",
)

_CREATE_WORDS: tuple[str, ...] = (
    "create", "make", "build", "generate", "scaffold", "new file",
    "new project", "init", "add a new", "implement",
)

_EDIT_WORDS: tuple[str, ...] = (
    "edit", "modify", "change", "update", "refactor", "rename",
    "add to", "remove from", "move", "replace", "rewrite",
)

_EXPLAIN_WORDS: tuple[str, ...] = (
    "explain", "what does", "how does", "why", "understand",
    "describe", "tell me about", "walk me through",
)

_RESEARCH_WORDS: tuple[str, ...] = (
    "search", "find", "look up", "google", "what is", "how to",
    "best practice", "compare", "difference between", "latest",
)

# File-path regex: matches common source file extensions.
_FILE_REF_PATTERN = re.compile(
    r"[\w./\\-]+\.(?:py|js|ts|jsx|tsx|rs|go|java|cpp|c|h|yaml|yml|"
    r"json|toml|md|txt|html|css|sh|sql|env|cfg|ini)"
)

# Import pattern: from X import Y or import X
_IMPORT_PATTERN = re.compile(
    r"^(?:from\s+([\w.]+)\s+import|import\s+([\w.]+))", re.MULTILINE
)

# Max chars per file to include in context.
_MAX_FILE_CHARS = 4000
_MAX_TOTAL_CONTEXT_CHARS = 20000

# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------


@dataclass
class EnhancedPrompt:
    """Result of prompt enhancement.

    Attributes:
        original: The raw user prompt.
        enhanced_prompt: The enriched prompt with injected context.
        context_added: Human-readable descriptions of what was injected.
        strategy: Detected task type.
    """

    original: str
    enhanced_prompt: str
    context_added: list[str] = field(default_factory=list)
    strategy: str = "question"


# ---------------------------------------------------------------------------
# Enhancer
# ---------------------------------------------------------------------------


class PromptEnhancer:
    """Autonomous context engine that pre-loads everything the model needs.

    Instead of making the model figure out what files to read, we read them
    proactively and inject them.  This compensates for small models' inability
    to autonomously navigate a codebase.

    Context gathering:
        - **File references**: Any file paths mentioned in the prompt.
        - **Import chain**: Local imports from referenced files (1 level deep).
        - **Test files**: Corresponding test files for referenced modules.
        - **Git state**: Uncommitted changes, recent commits.
        - **Project structure**: Top-level directory layout.
        - **Error context**: Recent test failures or tracebacks.

    Args:
        project_root: Path to the root of the current project.
        active_files: Optional list of file paths the user is working with.
    """

    def __init__(
        self,
        project_root: Path,
        active_files: list[str] | None = None,
    ) -> None:
        self._root = project_root
        self._active_files = active_files or []

    # ----- public API -------------------------------------------------------

    def enhance(self, prompt: str) -> EnhancedPrompt:
        """Enhance a user prompt with autonomous context gathering.

        Args:
            prompt: The raw user prompt.

        Returns:
            An :class:`EnhancedPrompt` containing the enriched text and
            metadata about what context was added.
        """
        strategy = self._detect_strategy(prompt)
        context_parts: list[str] = []
        sections: list[str] = [prompt]
        char_budget = _MAX_TOTAL_CONTEXT_CHARS

        # 1. Referenced files + their imports + their tests
        referenced = self._extract_file_refs(prompt)
        all_files = list(referenced)

        # Add active files
        for af in self._active_files[:5]:
            if af not in all_files:
                all_files.append(af)

        if all_files and strategy in ("code_edit", "debug", "create", "explain"):
            file_context, chars_used = self._gather_file_context(
                all_files, char_budget, context_parts
            )
            if file_context:
                sections.append(file_context)
                char_budget -= chars_used

        # 2. Git state for code tasks
        if strategy in ("code_edit", "debug", "create") and char_budget > 2000:
            git_context = self._gather_git_context(context_parts)
            if git_context:
                sections.append(git_context)
                char_budget -= len(git_context)

        # 3. Project structure for create tasks
        if strategy == "create" and char_budget > 1000:
            struct_context = self._gather_structure_context(context_parts)
            if struct_context:
                sections.append(struct_context)
                char_budget -= len(struct_context)

        # 4. Task-type-specific guidance
        guidance = self._get_strategy_guidance(strategy)
        if guidance:
            sections.append(guidance)
            context_parts.append(f"Strategy: {strategy}")

        # 5. Active files summary (for non-code strategies where files
        # weren't already included as full content above)
        if self._active_files and strategy in ("question", "research"):
            file_list = ", ".join(self._active_files[:5])
            sections.append(f"\n[Active files: {file_list}]")
            context_parts.append(f"Active files: {file_list}")

        return EnhancedPrompt(
            original=prompt,
            enhanced_prompt="\n".join(sections),
            context_added=context_parts,
            strategy=strategy,
        )

    # ----- strategy detection -----------------------------------------------

    def _detect_strategy(self, prompt: str) -> str:
        """Classify the user prompt into a task type.

        Order of precedence: debug > create > code_edit > explain >
        research > question.
        """
        lower = prompt.lower()

        for word in _DEBUG_WORDS:
            if word in lower:
                return "debug"
        for word in _CREATE_WORDS:
            if word in lower:
                return "create"
        for word in _EDIT_WORDS:
            if word in lower:
                return "code_edit"
        for word in _EXPLAIN_WORDS:
            if word in lower:
                return "explain"
        for word in _RESEARCH_WORDS:
            if word in lower:
                return "research"

        return "question"

    # ----- context gatherers ------------------------------------------------

    def _gather_file_context(
        self,
        files: list[str],
        char_budget: int,
        context_log: list[str],
    ) -> tuple[str, int]:
        """Gather file contents, their local imports, and their test files.

        Returns:
            Tuple of (context string, characters used).
        """
        parts: list[str] = []
        chars_used = 0
        seen: set[str] = set()

        for fpath in files[:5]:  # cap at 5 referenced files
            if fpath in seen:
                continue
            seen.add(fpath)

            full = self._root / fpath
            if not full.exists() or not full.is_file():
                continue

            # Read the file itself
            try:
                content = full.read_text(encoding="utf-8")
                truncated = content[:_MAX_FILE_CHARS]
                header = f"\n--- {fpath} ---\n"
                chunk = header + truncated
                if chars_used + len(chunk) > char_budget:
                    break
                parts.append(chunk)
                chars_used += len(chunk)
                context_log.append(f"Included {fpath}")
            except Exception:
                logger.debug("context_file_read_failed", path=str(fpath))
                continue

            # Find and include local imports (1 level deep)
            if fpath.endswith(".py"):
                imports = self._extract_local_imports(content, fpath)
                for imp_path in imports[:3]:
                    if imp_path in seen:
                        continue
                    seen.add(imp_path)
                    imp_full = self._root / imp_path
                    if not imp_full.exists():
                        continue
                    try:
                        imp_content = imp_full.read_text(encoding="utf-8")
                        imp_truncated = imp_content[:2000]
                        imp_chunk = f"\n--- {imp_path} (imported) ---\n{imp_truncated}"
                        if chars_used + len(imp_chunk) > char_budget:
                            break
                        parts.append(imp_chunk)
                        chars_used += len(imp_chunk)
                        context_log.append(f"Included import {imp_path}")
                    except Exception:
                        continue

            # Find and include the corresponding test file
            test_path = self._find_test_file(fpath)
            if test_path and test_path not in seen:
                seen.add(test_path)
                test_full = self._root / test_path
                if test_full.exists():
                    try:
                        test_content = test_full.read_text(encoding="utf-8")
                        test_truncated = test_content[:2000]
                        test_chunk = (
                            f"\n--- {test_path} (test file) ---\n{test_truncated}"
                        )
                        if chars_used + len(test_chunk) > char_budget:
                            break
                        parts.append(test_chunk)
                        chars_used += len(test_chunk)
                        context_log.append(f"Included test {test_path}")
                    except Exception:
                        continue

        return "\n".join(parts), chars_used

    def _gather_git_context(self, context_log: list[str]) -> str:
        """Gather git status and recent changes."""
        parts: list[str] = []

        # git status (short)
        try:
            result = subprocess.run(
                ["git", "status", "--short"],
                cwd=str(self._root),
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                status = result.stdout.strip()[:1000]
                parts.append(f"\n--- Git Status ---\n{status}")
                context_log.append("Included git status")
        except Exception:
            logger.debug("git_status_failed")

        # git diff --stat (what changed)
        try:
            result = subprocess.run(
                ["git", "diff", "--stat", "HEAD"],
                cwd=str(self._root),
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                diff_stat = result.stdout.strip()[:1000]
                parts.append(f"\n--- Recent Changes ---\n{diff_stat}")
                context_log.append("Included git diff stats")
        except Exception:
            logger.debug("git_diff_failed")

        return "\n".join(parts)

    def _gather_structure_context(self, context_log: list[str]) -> str:
        """Gather project top-level structure."""
        try:
            entries = sorted(self._root.iterdir())
            dirs = [
                e.name for e in entries
                if e.is_dir() and not e.name.startswith(".")
            ][:15]
            files = [
                e.name for e in entries
                if e.is_file() and not e.name.startswith(".")
            ][:15]

            if dirs or files:
                struct = "\n--- Project Structure ---\n"
                for d in dirs:
                    struct += f"  {d}/\n"
                for f in files:
                    struct += f"  {f}\n"
                context_log.append("Included project structure")
                return struct
        except Exception:
            logger.debug("structure_gather_failed")

        return ""

    def _get_strategy_guidance(self, strategy: str) -> str:
        """Return task-type-specific guidance for the model."""
        guidance: dict[str, str] = {
            "debug": (
                "\n[Task: DEBUGGING. Steps: 1) Read the error/traceback "
                "carefully. 2) Find the exact file and line. 3) Read "
                "surrounding code and tests. 4) Fix the root cause. "
                "5) Run tests to verify the fix. 6) Check for similar "
                "bugs nearby.]"
            ),
            "code_edit": (
                "\n[Task: CODE EDIT. Steps: 1) Read the file(s) being "
                "changed. 2) Read files that import from them (ripple "
                "effects). 3) Read the test file. 4) Make the change. "
                "5) Run tests. 6) Fix any failures.]"
            ),
            "create": (
                "\n[Task: CREATE NEW CODE. Steps: 1) Check project "
                "structure and conventions. 2) Look at similar existing "
                "files for patterns. 3) Write the new code following "
                "project conventions. 4) Write tests. 5) Run tests. "
                "6) Update any imports/registrations needed.]"
            ),
            "explain": (
                "\n[Task: EXPLAIN CODE. Read the referenced files "
                "thoroughly. Trace the call chain. Give concrete "
                "examples, not abstract descriptions.]"
            ),
            "research": (
                "\n[Task: RESEARCH. Call search_web immediately with "
                "a well-formed query. Synthesise multiple sources. "
                "Give concrete answers with examples.]"
            ),
        }
        return guidance.get(strategy, "")

    # ----- utilities --------------------------------------------------------

    def _extract_file_refs(self, prompt: str) -> list[str]:
        """Extract file-path references from a prompt string.

        Only returns paths that actually exist on disk relative to
        *project_root*.

        Returns:
            A deduplicated list of relative path strings.
        """
        files: list[str] = []
        for match in _FILE_REF_PATTERN.finditer(prompt):
            candidate = match.group(0)
            if (self._root / candidate).exists():
                files.append(candidate)

        # Also check for bare module names like "auth" or "router"
        words = prompt.lower().split()
        src_dir = self._root / "src"
        if src_dir.exists():
            for word in words:
                # Check src/prism/<word>/ or src/prism/<word>.py
                clean = word.strip(".,;:!?\"'()")
                if not clean or len(clean) < 3:
                    continue
                candidates = [
                    f"src/prism/{clean}.py",
                    f"src/prism/{clean}/__init__.py",
                ]
                for c in candidates:
                    if (self._root / c).exists() and c not in files:
                        files.append(c)
                        break

        return list(dict.fromkeys(files))

    def _extract_local_imports(
        self, content: str, source_path: str,
    ) -> list[str]:
        """Extract local (prism.*) import paths from Python source.

        Args:
            content: Python source code.
            source_path: Path of the source file (for relative resolution).

        Returns:
            List of relative file paths for local imports.
        """
        paths: list[str] = []
        for match in _IMPORT_PATTERN.finditer(content):
            module = match.group(1) or match.group(2)
            if not module or not module.startswith("prism"):
                continue
            # Convert prism.foo.bar → src/prism/foo/bar.py
            parts = module.split(".")
            rel = "src/" + "/".join(parts) + ".py"
            if (self._root / rel).exists():
                paths.append(rel)
            else:
                # Try as package __init__.py
                rel_init = "src/" + "/".join(parts) + "/__init__.py"
                if (self._root / rel_init).exists():
                    paths.append(rel_init)

        return list(dict.fromkeys(paths))

    def _find_test_file(self, source_path: str) -> str | None:
        """Find the corresponding test file for a source file.

        Args:
            source_path: e.g. ``src/prism/cli/repl.py``

        Returns:
            Relative path to test file, or ``None``.
        """
        # src/prism/cli/repl.py → tests/test_cli/test_repl.py
        if not source_path.startswith("src/prism/"):
            return None

        relative = source_path.removeprefix("src/prism/")
        parts = relative.split("/")

        if len(parts) == 1:
            # src/prism/foo.py → tests/test_foo.py
            test_path = f"tests/test_{parts[0]}"
        elif len(parts) == 2:
            # src/prism/cli/repl.py → tests/test_cli/test_repl.py
            test_path = f"tests/test_{parts[0]}/test_{parts[1]}"
        else:
            # Deeper nesting — best effort
            test_path = (
                f"tests/test_{parts[0]}/test_{'_'.join(parts[1:])}"
            )

        if (self._root / test_path).exists():
            return test_path

        return None
