"""Tests for the autonomous context engine (prompt enhancer)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from prism.cli.prompt_enhancer import EnhancedPrompt, PromptEnhancer

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def project_root(tmp_path: Path) -> Path:
    """Create a minimal project tree for testing."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "prism").mkdir(parents=True)
    (tmp_path / "tests").mkdir()
    (tmp_path / "src" / "main.py").write_text(
        'def main():\n    print("hello")\n', encoding="utf-8"
    )
    (tmp_path / "src" / "utils.py").write_text(
        'def add(a, b):\n    return a + b\n', encoding="utf-8"
    )
    (tmp_path / "README.md").write_text("# Test Project\n", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "test"\n', encoding="utf-8"
    )
    return tmp_path


@pytest.fixture
def enhancer(project_root: Path) -> PromptEnhancer:
    """Create a PromptEnhancer against the temp project."""
    return PromptEnhancer(project_root)


@pytest.fixture
def enhancer_with_files(project_root: Path) -> PromptEnhancer:
    """Create a PromptEnhancer with active files set."""
    return PromptEnhancer(project_root, active_files=["src/main.py", "src/utils.py"])


# ---------------------------------------------------------------------------
# EnhancedPrompt dataclass
# ---------------------------------------------------------------------------


class TestEnhancedPrompt:
    """Tests for the EnhancedPrompt dataclass."""

    def test_defaults(self) -> None:
        ep = EnhancedPrompt(original="hi", enhanced_prompt="hi")
        assert ep.original == "hi"
        assert ep.enhanced_prompt == "hi"
        assert ep.context_added == []
        assert ep.strategy == "question"

    def test_custom_values(self) -> None:
        ep = EnhancedPrompt(
            original="fix bug",
            enhanced_prompt="fix bug\n[context]",
            context_added=["Added debugging instructions"],
            strategy="debug",
        )
        assert ep.strategy == "debug"
        assert len(ep.context_added) == 1


# ---------------------------------------------------------------------------
# Strategy detection
# ---------------------------------------------------------------------------


class TestDetectStrategy:
    """Tests for PromptEnhancer._detect_strategy."""

    @pytest.mark.parametrize(
        "prompt,expected",
        [
            ("fix the error in main.py", "debug"),
            ("There is a bug in the router", "debug"),
            ("My app crashes on startup", "debug"),
            ("I see a traceback when I run tests", "debug"),
            ("The build is broken", "debug"),
            ("debug the login flow", "debug"),
            ("This exception keeps happening", "debug"),
            ("it's not working anymore", "debug"),
            ("there is a problem with auth", "debug"),
        ],
    )
    def test_debug_strategy(
        self, enhancer: PromptEnhancer, prompt: str, expected: str
    ) -> None:
        assert enhancer._detect_strategy(prompt) == expected

    @pytest.mark.parametrize(
        "prompt,expected",
        [
            ("create a new API endpoint", "create"),
            ("make a test file for utils", "create"),
            ("build a REST server", "create"),
            ("generate a migration script", "create"),
            ("scaffold a React component", "create"),
            ("I need a new file for auth", "create"),
            ("init the project", "create"),
            ("implement a caching layer", "create"),
        ],
    )
    def test_create_strategy(
        self, enhancer: PromptEnhancer, prompt: str, expected: str
    ) -> None:
        assert enhancer._detect_strategy(prompt) == expected

    @pytest.mark.parametrize(
        "prompt,expected",
        [
            ("edit the config file", "code_edit"),
            ("modify the database schema", "code_edit"),
            ("change the color theme", "code_edit"),
            ("update the version number", "code_edit"),
            ("refactor the router module", "code_edit"),
            ("rename the class to Foo", "code_edit"),
            ("add to the test suite", "code_edit"),
            ("move the function to utils", "code_edit"),
            ("replace the old API call", "code_edit"),
        ],
    )
    def test_edit_strategy(
        self, enhancer: PromptEnhancer, prompt: str, expected: str
    ) -> None:
        assert enhancer._detect_strategy(prompt) == expected

    @pytest.mark.parametrize(
        "prompt,expected",
        [
            ("explain how the router works", "explain"),
            ("what does this function do", "explain"),
            ("how does the auth module work", "explain"),
            ("why is this variable needed", "explain"),
            ("describe the architecture", "explain"),
            ("tell me about the cost tracker", "explain"),
            ("walk me through the code", "explain"),
        ],
    )
    def test_explain_strategy(
        self, enhancer: PromptEnhancer, prompt: str, expected: str
    ) -> None:
        assert enhancer._detect_strategy(prompt) == expected

    @pytest.mark.parametrize(
        "prompt,expected",
        [
            ("search for auth libraries", "research"),
            ("find the best Python web framework", "research"),
            ("look up how to use asyncio", "research"),
            ("best practice for database migrations", "research"),
            ("compare FastAPI and Flask", "research"),
            ("difference between async and sync", "research"),
        ],
    )
    def test_research_strategy(
        self, enhancer: PromptEnhancer, prompt: str, expected: str
    ) -> None:
        assert enhancer._detect_strategy(prompt) == expected

    def test_question_fallback(self, enhancer: PromptEnhancer) -> None:
        assert enhancer._detect_strategy("list all providers") == "question"

    def test_debug_takes_priority(self, enhancer: PromptEnhancer) -> None:
        """Debug keywords should win even if other keywords are present."""
        assert enhancer._detect_strategy("create a fix for the error") == "debug"


# ---------------------------------------------------------------------------
# File reference extraction
# ---------------------------------------------------------------------------


class TestExtractFileRefs:
    """Tests for PromptEnhancer._extract_file_refs."""

    def test_extracts_existing_file(self, enhancer: PromptEnhancer) -> None:
        refs = enhancer._extract_file_refs("look at src/main.py please")
        assert "src/main.py" in refs

    def test_ignores_nonexistent_file(self, enhancer: PromptEnhancer) -> None:
        refs = enhancer._extract_file_refs("check foo/bar.py")
        assert "foo/bar.py" not in refs

    def test_deduplicates(self, enhancer: PromptEnhancer) -> None:
        refs = enhancer._extract_file_refs(
            "compare src/main.py with src/main.py"
        )
        assert refs.count("src/main.py") == 1

    def test_multiple_files(self, enhancer: PromptEnhancer) -> None:
        refs = enhancer._extract_file_refs(
            "compare src/main.py and src/utils.py"
        )
        assert len(refs) == 2

    def test_no_file_refs(self, enhancer: PromptEnhancer) -> None:
        refs = enhancer._extract_file_refs("just a plain question")
        assert refs == []


# ---------------------------------------------------------------------------
# enhance() integration
# ---------------------------------------------------------------------------


class TestEnhance:
    """Tests for the main enhance() method."""

    def test_returns_enhanced_prompt(self, enhancer: PromptEnhancer) -> None:
        result = enhancer.enhance("list all files")
        assert isinstance(result, EnhancedPrompt)
        assert result.original == "list all files"
        assert result.strategy == "question"

    def test_active_files_shown_for_question(
        self, enhancer_with_files: PromptEnhancer
    ) -> None:
        """Active files are shown when there are no code file refs."""
        result = enhancer_with_files.enhance("list all providers")
        assert "Active files:" in result.enhanced_prompt
        assert "src/main.py" in result.enhanced_prompt

    def test_no_active_files(self, enhancer: PromptEnhancer) -> None:
        result = enhancer.enhance("hello")
        assert "Active files:" not in result.enhanced_prompt

    def test_code_edit_includes_file_content(
        self, enhancer: PromptEnhancer
    ) -> None:
        result = enhancer.enhance("edit src/main.py to add logging")
        assert result.strategy == "code_edit"
        assert "--- src/main.py ---" in result.enhanced_prompt
        assert "def main()" in result.enhanced_prompt
        assert any("Included src/main.py" in c for c in result.context_added)

    def test_code_edit_missing_file(self, enhancer: PromptEnhancer) -> None:
        result = enhancer.enhance("edit nonexistent/file.py")
        assert result.strategy == "code_edit"
        assert "--- nonexistent/file.py ---" not in result.enhanced_prompt

    def test_debug_adds_instructions(self, enhancer: PromptEnhancer) -> None:
        result = enhancer.enhance("there is an error in my code")
        assert result.strategy == "debug"
        assert "DEBUGGING" in result.enhanced_prompt
        assert any("Strategy" in c for c in result.context_added)

    def test_create_adds_project_structure(
        self, enhancer: PromptEnhancer
    ) -> None:
        result = enhancer.enhance("create a new module for caching")
        assert result.strategy == "create"
        assert "Project Structure" in result.enhanced_prompt
        assert "src/" in result.enhanced_prompt
        assert any("project structure" in c.lower() for c in result.context_added)

    def test_explain_includes_file_content(
        self, enhancer: PromptEnhancer
    ) -> None:
        result = enhancer.enhance("explain src/main.py")
        assert result.strategy == "explain"
        assert "--- src/main.py ---" in result.enhanced_prompt
        assert any("Included src/main.py" in c for c in result.context_added)

    def test_explain_missing_file(self, enhancer: PromptEnhancer) -> None:
        result = enhancer.enhance("explain ghost/module.py")
        assert result.strategy == "explain"
        assert "--- ghost/module.py ---" not in result.enhanced_prompt

    def test_question_returns_prompt_unchanged(
        self, enhancer: PromptEnhancer
    ) -> None:
        prompt = "list all providers"
        result = enhancer.enhance(prompt)
        assert result.strategy == "question"
        assert result.enhanced_prompt == prompt
        assert result.context_added == []

    def test_research_adds_guidance(self, enhancer: PromptEnhancer) -> None:
        result = enhancer.enhance("search for the latest Python features")
        assert result.strategy == "research"
        assert "RESEARCH" in result.enhanced_prompt
        assert "search_web" in result.enhanced_prompt


# ---------------------------------------------------------------------------
# Local import extraction
# ---------------------------------------------------------------------------


class TestLocalImports:
    """Tests for _extract_local_imports."""

    def test_extracts_prism_imports(self, project_root: Path) -> None:
        """Should extract local prism.* imports."""
        (project_root / "src" / "prism" / "foo.py").write_text(
            "x = 1\n", encoding="utf-8"
        )
        e = PromptEnhancer(project_root)
        source = "from prism.foo import x\nimport os\n"
        result = e._extract_local_imports(source, "src/prism/bar.py")
        assert "src/prism/foo.py" in result

    def test_ignores_third_party(self, project_root: Path) -> None:
        """Should ignore non-prism imports."""
        e = PromptEnhancer(project_root)
        source = "import requests\nfrom pathlib import Path\n"
        result = e._extract_local_imports(source, "src/prism/bar.py")
        assert result == []


# ---------------------------------------------------------------------------
# Test file discovery
# ---------------------------------------------------------------------------


class TestFindTestFile:
    """Tests for _find_test_file."""

    def test_finds_test_for_module(self, project_root: Path) -> None:
        """Should find tests/test_cli/test_repl.py for src/prism/cli/repl.py."""
        test_dir = project_root / "tests" / "test_cli"
        test_dir.mkdir(parents=True)
        (test_dir / "test_repl.py").write_text("# tests\n", encoding="utf-8")
        e = PromptEnhancer(project_root)
        result = e._find_test_file("src/prism/cli/repl.py")
        assert result == "tests/test_cli/test_repl.py"

    def test_returns_none_for_missing_test(
        self, project_root: Path
    ) -> None:
        e = PromptEnhancer(project_root)
        result = e._find_test_file("src/prism/cli/repl.py")
        assert result is None

    def test_returns_none_for_non_prism_path(
        self, project_root: Path
    ) -> None:
        e = PromptEnhancer(project_root)
        result = e._find_test_file("vendor/lib.py")
        assert result is None


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    """Edge case and boundary tests."""

    def test_empty_prompt(self, enhancer: PromptEnhancer) -> None:
        result = enhancer.enhance("")
        assert result.original == ""
        assert result.strategy == "question"

    def test_empty_project_root(self, tmp_path: Path) -> None:
        """Enhancer works even with a completely empty project directory."""
        empty = tmp_path / "empty"
        empty.mkdir()
        e = PromptEnhancer(empty)
        result = e.enhance("create something")
        assert result.strategy == "create"

    def test_file_content_capped(self, project_root: Path) -> None:
        """Files included in context should be capped at 5 max."""
        for i in range(7):
            (project_root / f"f{i}.py").write_text(
                f"# file {i}\n", encoding="utf-8"
            )
        prompt = "edit f0.py f1.py f2.py f3.py f4.py f5.py f6.py"
        e = PromptEnhancer(project_root)
        result = e.enhance(prompt)
        # At most 5 files should be included
        count = result.enhanced_prompt.count("--- f")
        assert count <= 5

    def test_explain_includes_referenced_files(
        self, project_root: Path,
    ) -> None:
        for i in range(4):
            (project_root / f"e{i}.py").write_text(
                f"# e{i}\n", encoding="utf-8"
            )
        prompt = "explain e0.py e1.py e2.py e3.py"
        e = PromptEnhancer(project_root)
        result = e.enhance(prompt)
        # Should include some files
        assert "--- e" in result.enhanced_prompt

    def test_active_files_capped_at_five(self, project_root: Path) -> None:
        many_files = [f"file{i}.py" for i in range(10)]
        e = PromptEnhancer(project_root, active_files=many_files)
        result = e.enhance("list all providers")
        # Only first 5 should appear
        assert "file4.py" in result.enhanced_prompt
        assert "file5.py" not in result.enhanced_prompt


# ---------------------------------------------------------------------------
# Git context (best-effort, no assertions on availability)
# ---------------------------------------------------------------------------


class TestGitContext:
    """Tests for git context gathering."""

    def test_git_context_on_non_git_dir(self, tmp_path: Path) -> None:
        """Should not crash when git is not available."""
        e = PromptEnhancer(tmp_path)
        result = e.enhance("fix the error in my code")
        # Should still work, just without git context
        assert result.strategy == "debug"
        assert result.original == "fix the error in my code"
