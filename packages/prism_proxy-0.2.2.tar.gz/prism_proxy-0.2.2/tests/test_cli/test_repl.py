"""Tests for prism.cli.repl — interactive REPL loop and slash commands."""

from __future__ import annotations

import io
from typing import TYPE_CHECKING, Any
from unittest.mock import patch

from rich.console import Console

from prism.cli.repl import (
    COMMAND_CATEGORIES,
    _ask_permission,
    _build_system_prompt,
    _dispatch_command,
    _execute_tool_with_permission,
    _format_tool_error,
    _load_project_instructions,
    _looks_like_swarm_task,
    _maybe_escalate_model,
    _SessionState,
    _should_auto_approve,
    run_repl,
)
from prism.config.schema import PrismConfig
from prism.config.settings import Settings

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_settings(tmp_path: Path) -> Settings:
    """Create a minimal Settings instance for testing."""
    config = PrismConfig(prism_home=tmp_path / ".prism")
    settings = Settings(config=config, project_root=tmp_path)
    settings.ensure_directories()
    return settings


def _make_console(width: int = 300) -> Console:
    """Create a console that writes to an in-memory buffer."""
    buf = io.StringIO()
    return Console(
        file=buf, force_terminal=False, no_color=True, width=width,
    )


def _get_output(console: Console) -> str:
    """Extract text from an in-memory console."""
    assert isinstance(console.file, io.StringIO)
    return console.file.getvalue()


def _make_state(
    pinned_model: str | None = None,
    active_files: list[str] | None = None,
) -> _SessionState:
    """Create a SessionState with optional overrides."""
    state = _SessionState(pinned_model=pinned_model)
    if active_files is not None:
        state.active_files = active_files
    state.session_id = "test-session"
    return state


def _cmd(
    command: str,
    tmp_path: Path,
    active_files: list[str] | None = None,
    pinned_model: str | None = None,
    console: Console | None = None,
    settings: Settings | None = None,
    state: _SessionState | None = None,
    dry_run: bool = False,
    offline: bool = False,
) -> tuple[str, str, Console, Settings, _SessionState]:
    """Run a slash command and return (action, output, console, settings, state).

    This is a convenience wrapper to reduce boilerplate in individual tests.
    """
    con = console or _make_console()
    stg = settings or _make_settings(tmp_path)
    st = state or _make_state(
        pinned_model=pinned_model,
        active_files=active_files if active_files is not None else [],
    )
    # If active_files was passed but state was not, ensure they match
    if active_files is not None and state is None:
        st.active_files = active_files
    action = _dispatch_command(
        command,
        console=con,
        settings=stg,
        state=st,
        dry_run=dry_run,
        offline=offline,
    )
    return action, _get_output(con), con, stg, st


# ===========================================================================
# COMMAND_CATEGORIES registry
# ===========================================================================


class TestCommandCategories:
    """Tests for the COMMAND_CATEGORIES constant."""

    def test_command_categories_is_dict(self) -> None:
        assert isinstance(COMMAND_CATEGORIES, dict)

    def test_has_general_category(self) -> None:
        assert "General" in COMMAND_CATEGORIES

    def test_has_model_routing_category(self) -> None:
        assert "Model & Routing" in COMMAND_CATEGORIES

    def test_has_context_files_category(self) -> None:
        assert "Context & Files" in COMMAND_CATEGORIES

    def test_has_cost_budget_category(self) -> None:
        assert "Cost & Budget" in COMMAND_CATEGORIES

    def test_has_tools_execution_category(self) -> None:
        assert "Tools & Execution" in COMMAND_CATEGORIES

    def test_has_code_intelligence_category(self) -> None:
        assert "Code Intelligence" in COMMAND_CATEGORIES

    def test_has_infrastructure_category(self) -> None:
        assert "Infrastructure" in COMMAND_CATEGORIES

    def test_all_values_are_lists_of_tuples(self) -> None:
        for cat, commands in COMMAND_CATEGORIES.items():
            assert isinstance(commands, list), f"{cat} is not a list"
            for item in commands:
                assert isinstance(item, tuple), (
                    f"Item in {cat} is not a tuple"
                )
                assert len(item) == 2, f"Tuple in {cat} has {len(item)} items"

    def test_minimum_categories(self) -> None:
        assert len(COMMAND_CATEGORIES) >= 6

    def test_minimum_total_commands(self) -> None:
        total = sum(len(v) for v in COMMAND_CATEGORIES.values())
        assert total >= 25


# ===========================================================================
# _SessionState
# ===========================================================================


class TestSessionState:
    """Tests for the _SessionState class."""

    def test_default_state(self) -> None:
        state = _SessionState(pinned_model=None)
        assert state.active_files == []
        assert state.conversation == []
        assert state.pinned_model is None
        assert state.web_enabled is True
        assert state.session_id == ""

    def test_pinned_model_set(self) -> None:
        state = _SessionState(pinned_model="gpt-4o")
        assert state.pinned_model == "gpt-4o"

    def test_active_files_mutable(self) -> None:
        state = _SessionState(pinned_model=None)
        state.active_files.append("foo.py")
        assert state.active_files == ["foo.py"]

    def test_conversation_mutable(self) -> None:
        state = _SessionState(pinned_model=None)
        state.conversation.append({"role": "user", "content": "hi"})
        assert len(state.conversation) == 1


# ===========================================================================
# 1. /help
# ===========================================================================


class TestHelpCommand:
    """Tests for the /help slash command."""

    def test_help_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/help", tmp_path)
        assert action == "continue"

    def test_help_shows_category_names(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/help", tmp_path)
        for category in COMMAND_CATEGORIES:
            assert category in output, (
                f"Category {category!r} not in /help output"
            )

    def test_help_case_insensitive(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/HELP", tmp_path)
        assert action == "continue"
        # Should still display categories
        assert "General" in output

    def test_help_with_trailing_space(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/help   ", tmp_path)
        assert action == "continue"

    def test_help_ignores_extra_args(self, tmp_path: Path) -> None:
        """Extra arguments after /help are silently ignored."""
        action, output, _, _, _ = _cmd("/help some extra args", tmp_path)
        assert action == "continue"
        assert "General" in output


# ===========================================================================
# 2. /cost
# ===========================================================================


class TestCostCommand:
    """Tests for the /cost slash command."""

    def test_cost_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/cost", tmp_path)
        assert action == "continue"

    def test_cost_shows_cost_content(self, tmp_path: Path) -> None:
        """Shows either a dashboard or a fallback message."""
        _, output, _, _, _ = _cmd("/cost", tmp_path)
        lower = output.lower()
        assert (
            "cost" in lower or "dashboard" in lower or "api call" in lower
        )

    def test_cost_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/COST", tmp_path)
        assert action == "continue"


# ===========================================================================
# 3. /model
# ===========================================================================


class TestModelCommand:
    """Tests for the /model slash command."""

    def test_model_no_args_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/model", tmp_path)
        assert action == "continue"

    def test_model_no_args_shows_current(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd(
            "/model", tmp_path, pinned_model="gpt-4o",
        )
        assert "gpt-4o" in output

    def test_model_no_args_shows_auto(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/model", tmp_path)
        assert "auto" in output.lower()

    def test_model_set_new_model(self, tmp_path: Path) -> None:
        action, output, _, _, st = _cmd("/model gpt-4o", tmp_path)
        assert action == "continue"
        assert st.pinned_model == "gpt-4o"
        assert "gpt-4o" in output

    def test_model_set_auto(self, tmp_path: Path) -> None:
        state = _make_state(pinned_model="gpt-4o")
        action, _, _, _, st = _cmd(
            "/model auto", tmp_path, state=state,
        )
        assert action == "continue"
        assert st.pinned_model is None

    def test_model_with_complex_name(self, tmp_path: Path) -> None:
        action, _, _, _, st = _cmd(
            "/model deepseek/deepseek-chat", tmp_path,
        )
        assert action == "continue"
        assert st.pinned_model == "deepseek/deepseek-chat"

    def test_model_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/MODEL gpt-4o", tmp_path)
        assert action == "continue"


# ===========================================================================
# 4. /add — file context addition
# ===========================================================================


class TestAddCommand:
    """Tests for the /add slash command."""

    def test_add_no_args_shows_usage(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/add", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_add_single_file(self, tmp_path: Path) -> None:
        action, output, _, _, st = _cmd(
            "/add src/main.py", tmp_path,
        )
        assert action == "continue"
        assert "src/main.py" in st.active_files
        assert "+" in output

    def test_add_multiple_files_at_once(self, tmp_path: Path) -> None:
        _, _, _, _, st = _cmd("/add a.py b.py c.py", tmp_path)
        assert st.active_files == ["a.py", "b.py", "c.py"]

    def test_add_duplicate_file_not_added_twice(
        self, tmp_path: Path,
    ) -> None:
        state = _make_state(active_files=["src/main.py"])
        _, output, _, _, st = _cmd(
            "/add src/main.py", tmp_path, state=state,
        )
        assert st.active_files.count("src/main.py") == 1
        assert "Already added" in output

    def test_add_mix_of_new_and_duplicate(self, tmp_path: Path) -> None:
        state = _make_state(active_files=["existing.py"])
        _, output, _, _, st = _cmd(
            "/add existing.py new.py", tmp_path, state=state,
        )
        assert st.active_files == ["existing.py", "new.py"]
        assert "Already added" in output
        assert "+" in output

    def test_add_preserves_order(self, tmp_path: Path) -> None:
        _, _, _, _, st = _cmd("/add z.py a.py m.py", tmp_path)
        assert st.active_files == ["z.py", "a.py", "m.py"]

    def test_add_file_with_spaces_in_path(self, tmp_path: Path) -> None:
        """Spaces split into separate file args (current behavior)."""
        _, _, _, _, st = _cmd("/add my file.py", tmp_path)
        assert "my" in st.active_files
        assert "file.py" in st.active_files

    def test_add_case_insensitive_command(self, tmp_path: Path) -> None:
        action, _, _, _, st = _cmd("/ADD foo.py", tmp_path)
        assert action == "continue"
        assert "foo.py" in st.active_files


# ===========================================================================
# 5. /drop — file context removal
# ===========================================================================


class TestDropCommand:
    """Tests for the /drop slash command."""

    def test_drop_no_args_shows_active_files(self, tmp_path: Path) -> None:
        state = _make_state(active_files=["src/main.py", "src/utils.py"])
        action, output, _, _, _ = _cmd("/drop", tmp_path, state=state)
        assert action == "continue"
        assert "src/main.py" in output
        assert "src/utils.py" in output

    def test_drop_no_args_empty_list(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/drop", tmp_path)
        assert "No active files" in output

    def test_drop_removes_file(self, tmp_path: Path) -> None:
        state = _make_state(active_files=["src/main.py", "src/utils.py"])
        _, output, _, _, st = _cmd(
            "/drop src/main.py", tmp_path, state=state,
        )
        assert "src/main.py" not in st.active_files
        assert "src/utils.py" in st.active_files
        assert "-" in output

    def test_drop_nonexistent_file(self, tmp_path: Path) -> None:
        state = _make_state(active_files=["src/main.py"])
        _, output, _, _, st = _cmd(
            "/drop nonexistent.py", tmp_path, state=state,
        )
        assert "Not in context" in output
        assert "src/main.py" in st.active_files

    def test_drop_multiple_files(self, tmp_path: Path) -> None:
        state = _make_state(active_files=["a.py", "b.py", "c.py"])
        _, _, _, _, st = _cmd(
            "/drop a.py c.py", tmp_path, state=state,
        )
        assert st.active_files == ["b.py"]

    def test_drop_mix_of_present_and_absent(self, tmp_path: Path) -> None:
        state = _make_state(active_files=["real.py"])
        _, output, _, _, st = _cmd(
            "/drop real.py fake.py", tmp_path, state=state,
        )
        assert st.active_files == []
        assert "Not in context" in output

    def test_drop_all_files(self, tmp_path: Path) -> None:
        state = _make_state(active_files=["a.py", "b.py"])
        _, _, _, _, st = _cmd(
            "/drop a.py b.py", tmp_path, state=state,
        )
        assert st.active_files == []

    def test_drop_case_insensitive_command(self, tmp_path: Path) -> None:
        state = _make_state(active_files=["foo.py"])
        action, _, _, _, st = _cmd(
            "/DROP foo.py", tmp_path, state=state,
        )
        assert action == "continue"
        assert st.active_files == []


# ===========================================================================
# 6. /compact
# ===========================================================================


class TestCompactCommand:
    """Tests for the /compact slash command."""

    def test_compact_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/compact", tmp_path)
        assert action == "continue"

    def test_compact_short_conversation_shows_message(
        self, tmp_path: Path,
    ) -> None:
        """With less than 4 messages, shows 'too short' message."""
        state = _make_state()
        state.conversation = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        _, output, _, _, _ = _cmd("/compact", tmp_path, state=state)
        assert "too short" in output.lower()

    def test_compact_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/COMPACT", tmp_path)
        assert action == "continue"


# ===========================================================================
# 7. /undo
# ===========================================================================


class TestUndoCommand:
    """Tests for the /undo slash command."""

    def test_undo_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/undo", tmp_path)
        assert action == "continue"

    def test_undo_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/UNDO", tmp_path)
        assert action == "continue"

    def test_undo_outputs_something(self, tmp_path: Path) -> None:
        """Even on error, should print a message."""
        _, output, _, _, _ = _cmd("/undo", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 8. /web
# ===========================================================================


class TestWebCommand:
    """Tests for the /web slash command."""

    def test_web_on(self, tmp_path: Path) -> None:
        action, output, _, _, st = _cmd("/web on", tmp_path)
        assert action == "continue"
        assert "enabled" in output.lower()
        assert st.web_enabled is True

    def test_web_off(self, tmp_path: Path) -> None:
        state = _make_state()
        state.web_enabled = True
        action, output, _, _, st = _cmd(
            "/web off", tmp_path, state=state,
        )
        assert action == "continue"
        assert "disabled" in output.lower()
        assert st.web_enabled is False

    def test_web_no_args_shows_status(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/web", tmp_path)
        lower = output.lower()
        assert "usage" in lower or "disabled" in lower or "enabled" in lower

    def test_web_invalid_arg_shows_status(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/web maybe", tmp_path)
        lower = output.lower()
        assert "usage" in lower or "disabled" in lower or "enabled" in lower

    def test_web_on_case_insensitive_arg(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/web ON", tmp_path)
        assert "enabled" in output.lower()

    def test_web_off_case_insensitive_arg(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/web OFF", tmp_path)
        assert "disabled" in output.lower()

    def test_web_case_insensitive_command(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/WEB on", tmp_path)
        assert action == "continue"
        assert "enabled" in output.lower()


# ===========================================================================
# 9. /status
# ===========================================================================


class TestStatusCommand:
    """Tests for the /status slash command."""

    def test_status_returns_continue(self, tmp_path: Path) -> None:
        with patch("prism.cli.repl.logger"):
            action, _, _, _, _ = _cmd("/status", tmp_path)
        assert action == "continue"

    def test_status_case_insensitive(self, tmp_path: Path) -> None:
        with patch("prism.cli.repl.logger"):
            action, _, _, _, _ = _cmd("/STATUS", tmp_path)
        assert action == "continue"


# ===========================================================================
# 10. /clear
# ===========================================================================


class TestClearCommand:
    """Tests for the /clear slash command."""

    def test_clear_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/clear", tmp_path)
        assert action == "continue"

    def test_clear_shows_cleared_message(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/clear", tmp_path)
        assert "cleared" in output.lower()

    def test_clear_empties_conversation(self, tmp_path: Path) -> None:
        state = _make_state()
        state.conversation = [
            {"role": "user", "content": "test"},
            {"role": "assistant", "content": "reply"},
        ]
        _, _, _, _, st = _cmd("/clear", tmp_path, state=state)
        assert st.conversation == []

    def test_clear_shows_message_count(self, tmp_path: Path) -> None:
        state = _make_state()
        state.conversation = [
            {"role": "user", "content": "a"},
            {"role": "assistant", "content": "b"},
            {"role": "user", "content": "c"},
        ]
        _, output, _, _, _ = _cmd("/clear", tmp_path, state=state)
        assert "3" in output

    def test_clear_case_insensitive(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/CLEAR", tmp_path)
        assert action == "continue"
        assert "cleared" in output.lower()


# ===========================================================================
# 11. /cache
# ===========================================================================


class TestCacheCommand:
    """Tests for the /cache slash command."""

    def test_cache_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/cache", tmp_path)
        assert action == "continue"

    def test_cache_outputs_something(self, tmp_path: Path) -> None:
        """Should output cache stats or an error message."""
        _, output, _, _, _ = _cmd("/cache", tmp_path)
        assert len(output.strip()) > 0

    def test_cache_clear_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/cache clear", tmp_path)
        assert action == "continue"


# ===========================================================================
# 12. /compare
# ===========================================================================


class TestCompareCommand:
    """Tests for the /compare slash command."""

    def test_compare_no_args_shows_usage(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/compare", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_compare_returns_continue(self, tmp_path: Path) -> None:
        """Even with args, should return continue (may fail internally)."""
        action, _, _, _, _ = _cmd(
            "/compare test prompt", tmp_path,
        )
        assert action == "continue"


# ===========================================================================
# 13. /branch
# ===========================================================================


class TestBranchCommand:
    """Tests for the /branch slash command."""

    def test_branch_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/branch", tmp_path)
        assert action == "continue"

    def test_branch_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/BRANCH", tmp_path)
        assert action == "continue"

    def test_branch_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/branch", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 14. /rollback
# ===========================================================================


class TestRollbackCommand:
    """Tests for the /rollback slash command."""

    def test_rollback_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/rollback", tmp_path)
        assert action == "continue"

    def test_rollback_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/ROLLBACK", tmp_path)
        assert action == "continue"

    def test_rollback_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/rollback", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 15. /sandbox
# ===========================================================================


class TestSandboxCommand:
    """Tests for the /sandbox slash command."""

    def test_sandbox_no_args_shows_usage(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/sandbox", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_sandbox_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd(
            "/sandbox print('hello')", tmp_path,
        )
        assert action == "continue"


# ===========================================================================
# 16. /tasks
# ===========================================================================


class TestTasksCommand:
    """Tests for the /tasks slash command."""

    def test_tasks_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/tasks", tmp_path)
        assert action == "continue"

    def test_tasks_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/TASKS", tmp_path)
        assert action == "continue"

    def test_tasks_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/tasks", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 17. /privacy
# ===========================================================================


class TestPrivacyCommand:
    """Tests for the /privacy slash command."""

    def test_privacy_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/privacy", tmp_path)
        assert action == "continue"

    def test_privacy_on_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/privacy on", tmp_path)
        assert action == "continue"

    def test_privacy_off_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/privacy off", tmp_path)
        assert action == "continue"


# ===========================================================================
# 18. /plugins
# ===========================================================================


class TestPluginsCommand:
    """Tests for the /plugins slash command."""

    def test_plugins_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/plugins", tmp_path)
        assert action == "continue"

    def test_plugins_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/PLUGINS", tmp_path)
        assert action == "continue"

    def test_plugins_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/plugins", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 19. /forecast
# ===========================================================================


class TestForecastCommand:
    """Tests for the /forecast slash command."""

    def test_forecast_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/forecast", tmp_path)
        assert action == "continue"

    def test_forecast_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/FORECAST", tmp_path)
        assert action == "continue"

    def test_forecast_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/forecast", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 20. /workspace
# ===========================================================================


class TestWorkspaceCommand:
    """Tests for the /workspace slash command."""

    def test_workspace_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/workspace", tmp_path)
        assert action == "continue"

    def test_workspace_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/WORKSPACE", tmp_path)
        assert action == "continue"

    def test_workspace_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/workspace", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 21. /offline
# ===========================================================================


class TestOfflineCommand:
    """Tests for the /offline slash command."""

    def test_offline_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/offline", tmp_path)
        assert action == "continue"

    def test_offline_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/OFFLINE", tmp_path)
        assert action == "continue"

    def test_offline_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/offline", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 22. /debate
# ===========================================================================


class TestDebateCommand:
    """Tests for the /debate slash command."""

    def test_debate_no_args_shows_usage(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/debate", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_debate_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd(
            "/debate is python better than rust", tmp_path,
        )
        assert action == "continue"


# ===========================================================================
# 23. /blast
# ===========================================================================


class TestBlastCommand:
    """Tests for the /blast slash command."""

    def test_blast_no_args_shows_usage(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/blast", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_blast_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/blast src/main.py", tmp_path)
        assert action == "continue"


# ===========================================================================
# 24. /gaps
# ===========================================================================


class TestGapsCommand:
    """Tests for the /gaps slash command."""

    def test_gaps_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/gaps", tmp_path)
        assert action == "continue"

    def test_gaps_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/GAPS", tmp_path)
        assert action == "continue"

    def test_gaps_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/gaps", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 25. /deps
# ===========================================================================


class TestDepsCommand:
    """Tests for the /deps slash command."""

    def test_deps_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/deps", tmp_path)
        assert action == "continue"

    def test_deps_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/DEPS", tmp_path)
        assert action == "continue"

    def test_deps_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/deps", tmp_path)
        assert len(output.strip()) > 0


# ===========================================================================
# 26. /arch
# ===========================================================================


class TestArchCommand:
    """Tests for the /arch slash command."""

    def test_arch_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/arch", tmp_path)
        assert action == "continue"

    def test_arch_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/ARCH", tmp_path)
        assert action == "continue"

    def test_arch_drift_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/arch drift", tmp_path)
        assert action == "continue"


# ===========================================================================
# 27. /debug-memory
# ===========================================================================


class TestDebugMemoryCommand:
    """Tests for the /debug-memory slash command."""

    def test_debug_memory_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/debug-memory", tmp_path)
        assert action == "continue"

    def test_debug_memory_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/debug-memory", tmp_path)
        assert len(output.strip()) > 0

    def test_debug_memory_search_returns_continue(
        self, tmp_path: Path,
    ) -> None:
        action, _, _, _, _ = _cmd(
            "/debug-memory search import error", tmp_path,
        )
        assert action == "continue"


# ===========================================================================
# 28. /history
# ===========================================================================


class TestHistoryCommand:
    """Tests for the /history slash command."""

    def test_history_no_args_shows_usage(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/history", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_history_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/history src/main.py", tmp_path)
        assert action == "continue"


# ===========================================================================
# 29. /budget
# ===========================================================================


class TestBudgetCommand:
    """Tests for the /budget slash command."""

    def test_budget_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/budget", tmp_path)
        assert action == "continue"

    def test_budget_outputs_something(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/budget", tmp_path)
        assert len(output.strip()) > 0

    def test_budget_set_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/budget set 50000", tmp_path)
        assert action == "continue"


# ===========================================================================
# 30. /quit, /exit, /q
# ===========================================================================


class TestQuitCommand:
    """Tests for the /quit, /exit, and /q slash commands."""

    def test_quit_returns_quit(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/quit", tmp_path)
        assert action == "quit"
        assert "Goodbye" in output

    def test_exit_returns_quit(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/exit", tmp_path)
        assert action == "quit"
        assert "Goodbye" in output

    def test_q_returns_quit(self, tmp_path: Path) -> None:
        action, output, _, _, _ = _cmd("/q", tmp_path)
        assert action == "quit"
        assert "Goodbye" in output

    def test_quit_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/QUIT", tmp_path)
        assert action == "quit"

    def test_exit_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/EXIT", tmp_path)
        assert action == "quit"

    def test_q_case_insensitive(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/Q", tmp_path)
        assert action == "quit"

    def test_quit_ignores_extra_args(self, tmp_path: Path) -> None:
        """Extra arguments after /quit are ignored — still exits."""
        action, _, _, _, _ = _cmd("/quit now", tmp_path)
        assert action == "quit"


# ===========================================================================
# Unknown command
# ===========================================================================


class TestUnknownCommand:
    """Tests for unrecognized slash commands."""

    def test_unknown_command_returns_continue(
        self, tmp_path: Path,
    ) -> None:
        action, _, _, _, _ = _cmd("/foobar", tmp_path)
        assert action == "continue"

    def test_unknown_command_shows_error(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/foobar", tmp_path)
        assert "Unknown command" in output
        assert "/foobar" in output

    def test_unknown_suggests_help(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/nonexistent", tmp_path)
        assert "/help" in output

    def test_unknown_with_random_string(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/xyz123", tmp_path)
        assert "Unknown command" in output

    def test_unknown_single_char(self, tmp_path: Path) -> None:
        """Single character that is not /q."""
        _, output, _, _, _ = _cmd("/z", tmp_path)
        assert "Unknown command" in output

    def test_unknown_with_args(self, tmp_path: Path) -> None:
        _, output, _, _, _ = _cmd("/banana split", tmp_path)
        assert "Unknown command" in output
        assert "/banana" in output


# ===========================================================================
# Edge cases and cross-cutting behavior
# ===========================================================================


class TestSlashCommandEdgeCases:
    """Edge cases that cut across multiple commands."""

    def test_command_with_leading_whitespace_in_args(
        self, tmp_path: Path,
    ) -> None:
        """Args are stripped properly."""
        _, _, _, _, st = _cmd(
            "/add    spaced.py", tmp_path,
        )
        assert "spaced.py" in st.active_files

    def test_all_implemented_commands_return_valid_action(
        self, tmp_path: Path,
    ) -> None:
        """Every command returns one of the valid actions."""
        valid_actions = {"continue", "quit"}
        commands_to_test = [
            "/help", "/cost", "/model", "/compact", "/undo",
            "/web on", "/clear", "/cache", "/compare", "/branch",
            "/rollback", "/sandbox", "/tasks", "/privacy",
            "/plugins", "/forecast", "/workspace", "/offline",
            "/debate", "/blast", "/gaps", "/deps", "/arch",
            "/debug-memory", "/history", "/budget",
        ]
        for cmd_str in commands_to_test:
            action, _, _, _, _ = _cmd(cmd_str, tmp_path)
            assert action in valid_actions, (
                f"Command {cmd_str!r} returned invalid action "
                f"{action!r}"
            )

    def test_add_then_drop_roundtrip(self, tmp_path: Path) -> None:
        """Adding and then dropping a file returns to empty state."""
        state = _make_state()
        stg = _make_settings(tmp_path)

        con1 = _make_console()
        _dispatch_command(
            "/add roundtrip.py",
            console=con1,
            settings=stg,
            state=state,
            dry_run=False,
            offline=False,
        )
        assert state.active_files == ["roundtrip.py"]

        con2 = _make_console()
        _dispatch_command(
            "/drop roundtrip.py",
            console=con2,
            settings=stg,
            state=state,
            dry_run=False,
            offline=False,
        )
        assert state.active_files == []

    def test_multiple_add_commands_accumulate(
        self, tmp_path: Path,
    ) -> None:
        state = _make_state()
        stg = _make_settings(tmp_path)

        for filename in ["a.py", "b.py", "c.py"]:
            console = _make_console()
            _dispatch_command(
                f"/add {filename}",
                console=console,
                settings=stg,
                state=state,
                dry_run=False,
                offline=False,
            )

        assert state.active_files == ["a.py", "b.py", "c.py"]

    def test_model_set_persists_across_calls(
        self, tmp_path: Path,
    ) -> None:
        state = _make_state()
        stg = _make_settings(tmp_path)

        con1 = _make_console()
        _dispatch_command(
            "/model gpt-4o",
            console=con1,
            settings=stg,
            state=state,
            dry_run=False,
            offline=False,
        )
        assert state.pinned_model == "gpt-4o"

        # Check subsequent call shows it
        con2 = _make_console()
        _dispatch_command(
            "/model",
            console=con2,
            settings=stg,
            state=state,
            dry_run=False,
            offline=False,
        )
        output = _get_output(con2)
        assert "gpt-4o" in output

    def test_clear_resets_conversation(self, tmp_path: Path) -> None:
        state = _make_state()
        state.conversation = [
            {"role": "user", "content": "first"},
            {"role": "assistant", "content": "second"},
        ]
        stg = _make_settings(tmp_path)

        _dispatch_command(
            "/clear",
            console=_make_console(),
            settings=stg,
            state=state,
            dry_run=False,
            offline=False,
        )
        assert state.conversation == []

    def test_web_toggle_roundtrip(self, tmp_path: Path) -> None:
        state = _make_state()
        stg = _make_settings(tmp_path)

        _dispatch_command(
            "/web on",
            console=_make_console(),
            settings=stg,
            state=state,
            dry_run=False,
            offline=False,
        )
        assert state.web_enabled is True

        _dispatch_command(
            "/web off",
            console=_make_console(),
            settings=stg,
            state=state,
            dry_run=False,
            offline=False,
        )
        assert state.web_enabled is False

    def test_dispatch_table_has_all_known_commands(
        self, tmp_path: Path,
    ) -> None:
        """All commands listed in COMMAND_CATEGORIES are
        recognized by the dispatcher (not 'Unknown command')."""
        stg = _make_settings(tmp_path)

        for category, commands in COMMAND_CATEGORIES.items():
            for cmd_label, _desc in commands:
                # Extract the command name (e.g. "/add" from "/add <files>")
                cmd_name = cmd_label.split()[0]
                state = _make_state()
                con = _make_console()
                _dispatch_command(
                    cmd_name,
                    console=con,
                    settings=stg,
                    state=state,
                    dry_run=False,
                    offline=False,
                )
                output = _get_output(con)
                assert "Unknown command" not in output, (
                    f"{cmd_name} from category {category!r} "
                    f"was not recognized"
                )


# ===========================================================================
# _process_prompt tests
# ===========================================================================


class TestProcessPrompt:
    """Tests for _process_prompt — prompt classification and completion."""

    def _import_process_prompt(self):
        """Import _process_prompt lazily."""
        from prism.cli.repl import _process_prompt
        return _process_prompt

    def _mock_classify_result(
        self,
        tier: str = "simple",
        score: float = 0.3,
        features: str = "short prompt",
        reasoning: str = "Low complexity",
    ) -> object:
        """Create a mock classification result."""
        from enum import Enum
        from unittest.mock import MagicMock

        class MockTier(Enum):
            simple = "simple"
            medium = "medium"
            complex = "complex"

        result = MagicMock()
        result.tier = MockTier[tier]
        result.score = score
        result.features = features
        result.reasoning = reasoning
        return result

    def test_classification_displayed(self, tmp_path: Path) -> None:
        """_process_prompt displays classification tier and score."""
        proc = self._import_process_prompt()
        stg = _make_settings(tmp_path)
        con = _make_console()
        state = _make_state()
        mock_result = self._mock_classify_result(
            tier="simple", score=0.25,
        )

        with patch(
            "prism.router.classifier.TaskClassifier",
        ) as mock_cls, patch(
            "prism.router.classifier.TaskContext",
        ):
            mock_cls.return_value.classify.return_value = mock_result
            proc(
                prompt="hello",
                console=con,
                settings=stg,
                state=state,
                dry_run=True,
                offline=False,
            )

        output = _get_output(con)
        assert "SIMPLE" in output
        assert "0.25" in output

    def test_dry_run_shows_features_and_reasoning(
        self, tmp_path: Path,
    ) -> None:
        """In dry-run mode, features and reasoning are displayed."""
        proc = self._import_process_prompt()
        stg = _make_settings(tmp_path)
        con = _make_console()
        state = _make_state()
        mock_result = self._mock_classify_result(
            features="code_edit, multi_file",
            reasoning="Edits across files",
        )

        with patch(
            "prism.router.classifier.TaskClassifier",
        ) as mock_cls, patch(
            "prism.router.classifier.TaskContext",
        ):
            mock_cls.return_value.classify.return_value = mock_result
            proc(
                prompt="refactor module",
                console=con,
                settings=stg,
                state=state,
                dry_run=True,
                offline=False,
            )

        output = _get_output(con)
        assert "code_edit" in output
        assert "Edits across files" in output
        assert "Dry-run" in output

    def test_dry_run_no_conversation_update(
        self, tmp_path: Path,
    ) -> None:
        """In dry-run mode, conversation is not updated."""
        proc = self._import_process_prompt()
        stg = _make_settings(tmp_path)
        con = _make_console()
        state = _make_state()
        mock_result = self._mock_classify_result()

        with patch(
            "prism.router.classifier.TaskClassifier",
        ) as mock_cls, patch(
            "prism.router.classifier.TaskContext",
        ):
            mock_cls.return_value.classify.return_value = mock_result
            proc(
                prompt="test",
                console=con,
                settings=stg,
                state=state,
                dry_run=True,
                offline=False,
            )

        assert len(state.conversation) == 0

    def test_complex_tier_displayed(self, tmp_path: Path) -> None:
        """Complex tier is displayed with correct label."""
        proc = self._import_process_prompt()
        stg = _make_settings(tmp_path)
        con = _make_console()
        state = _make_state()
        mock_result = self._mock_classify_result(
            tier="complex", score=0.92,
        )

        with patch(
            "prism.router.classifier.TaskClassifier",
        ) as mock_cls, patch(
            "prism.router.classifier.TaskContext",
        ):
            mock_cls.return_value.classify.return_value = mock_result
            proc(
                prompt="refactor entire codebase",
                console=con,
                settings=stg,
                state=state,
                dry_run=True,
                offline=False,
            )

        output = _get_output(con)
        assert "COMPLEX" in output
        assert "0.92" in output

    def test_active_files_passed_to_context(
        self, tmp_path: Path,
    ) -> None:
        """Active files from state are passed to TaskContext."""
        proc = self._import_process_prompt()
        stg = _make_settings(tmp_path)
        con = _make_console()
        state = _make_state(active_files=["a.py", "b.py"])
        mock_result = self._mock_classify_result()

        with patch(
            "prism.router.classifier.TaskClassifier",
        ) as mock_cls, patch(
            "prism.router.classifier.TaskContext",
        ) as mock_ctx:
            mock_cls.return_value.classify.return_value = mock_result
            proc(
                prompt="hello",
                console=con,
                settings=stg,
                state=state,
                dry_run=True,
                offline=False,
            )
            mock_ctx.assert_called_once_with(
                active_files=["a.py", "b.py"],
            )

    def test_completion_error_displays_message(
        self, tmp_path: Path,
    ) -> None:
        """When completion engine raises, an error is printed."""
        proc = self._import_process_prompt()
        stg = _make_settings(tmp_path)
        con = _make_console()
        state = _make_state()
        mock_result = self._mock_classify_result()

        with patch(
            "prism.router.classifier.TaskClassifier",
        ) as mock_cls, patch(
            "prism.router.classifier.TaskContext",
        ), patch(
            "prism.llm.completion.CompletionEngine",
            side_effect=RuntimeError("no key"),
        ), patch(
            "litellm.acompletion",
            side_effect=RuntimeError("no key"),
        ):
            mock_cls.return_value.classify.return_value = mock_result
            proc(
                prompt="hello",
                console=con,
                settings=stg,
                state=state,
                dry_run=False,
                offline=False,
            )

        output = _get_output(con)
        assert "error" in output.lower()

    def test_medium_tier_displayed(self, tmp_path: Path) -> None:
        """Medium tier is displayed correctly."""
        proc = self._import_process_prompt()
        stg = _make_settings(tmp_path)
        con = _make_console()
        state = _make_state()
        mock_result = self._mock_classify_result(
            tier="medium", score=0.55,
        )

        with patch(
            "prism.router.classifier.TaskClassifier",
        ) as mock_cls, patch(
            "prism.router.classifier.TaskContext",
        ):
            mock_cls.return_value.classify.return_value = mock_result
            proc(
                prompt="explain this function",
                console=con,
                settings=stg,
                state=state,
                dry_run=True,
                offline=False,
            )

        output = _get_output(con)
        assert "MEDIUM" in output
        assert "0.55" in output


# ===========================================================================
# run_repl comprehensive tests
# ===========================================================================


class TestRunRepl:
    """Comprehensive tests for the run_repl function."""

    def test_run_repl_exists(self) -> None:
        """run_repl is importable."""
        assert callable(run_repl)

    def test_run_repl_accepts_expected_args(self) -> None:
        """run_repl has the expected signature parameters."""
        import inspect
        sig = inspect.signature(run_repl)
        param_names = list(sig.parameters.keys())
        assert "settings" in param_names
        assert "console" in param_names
        assert "dry_run" in param_names
        assert "offline" in param_names

    def test_eof_exits_with_goodbye(self, tmp_path: Path) -> None:
        """EOFError from prompt exits the loop with goodbye."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = EOFError
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "Goodbye" in output

    def test_quit_command_exits(self, tmp_path: Path) -> None:
        """/quit exits the REPL loop."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/quit", EOFError,
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "Goodbye" in output or "Ready" in output

    def test_exit_command_exits(self, tmp_path: Path) -> None:
        """/exit is an alias for /quit."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/exit", EOFError,
            ]
            run_repl(settings=stg, console=con)

        # Should exit cleanly without hitting EOFError
        output = _get_output(con)
        assert "Goodbye" in output or "Providers" in output or output.strip()

    def test_q_command_exits(self, tmp_path: Path) -> None:
        """/q is an alias for /quit."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/q", EOFError,
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "Goodbye" in output or "Providers" in output or output.strip()

    def test_empty_input_continues(self, tmp_path: Path) -> None:
        """Empty input is silently skipped."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "", "  ", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        # No error messages for empty input
        assert "error" not in output.lower()

    def test_keyboard_interrupt_continues(
        self, tmp_path: Path,
    ) -> None:
        """KeyboardInterrupt from prompt continues the loop."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                KeyboardInterrupt, "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "Goodbye" in output or "Providers" in output or output.strip()

    def test_multiple_keyboard_interrupts(
        self, tmp_path: Path,
    ) -> None:
        """Multiple KeyboardInterrupts don't crash the loop."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                KeyboardInterrupt,
                KeyboardInterrupt,
                KeyboardInterrupt,
                "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "Goodbye" in output or "Providers" in output or output.strip()

    def test_help_then_quit(self, tmp_path: Path) -> None:
        """Running /help followed by /quit works correctly."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/help", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        # /help output should appear
        assert "help" in output.lower() or "command" in output.lower()

    def test_regular_prompt_calls_process(
        self, tmp_path: Path,
    ) -> None:
        """Non-slash input is routed to _process_prompt."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._process_prompt",
        ) as mock_proc:
            mock_ps.return_value.prompt.side_effect = [
                "hello world", "/quit",
            ]
            run_repl(settings=stg, console=con)

        mock_proc.assert_called_once()
        call_kwargs = mock_proc.call_args
        assert call_kwargs[1]["prompt"] == "hello world" or (
            call_kwargs[0][0] == "hello world"
        )

    def test_multiple_prompts_processed(
        self, tmp_path: Path,
    ) -> None:
        """Multiple regular prompts each call _process_prompt."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._process_prompt",
        ) as mock_proc:
            mock_ps.return_value.prompt.side_effect = [
                "first", "second", "third", "/quit",
            ]
            run_repl(settings=stg, console=con)

        assert mock_proc.call_count == 3

    def test_model_change_via_loop(self, tmp_path: Path) -> None:
        """/model command in the loop changes pinned model."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/model gpt-4", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "gpt-4" in output

    def test_model_no_arg_shows_current(
        self, tmp_path: Path,
    ) -> None:
        """/model with no argument shows the current model."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/model", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "auto" in output.lower() or "model" in output.lower()

    def test_exception_in_loop_continues(
        self, tmp_path: Path,
    ) -> None:
        """An exception in the loop body prints error, continues."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._process_prompt",
            side_effect=[RuntimeError("boom"), None],
        ):
            mock_ps.return_value.prompt.side_effect = [
                "bad prompt", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "unexpected error" in output.lower() or (
            "error" in output.lower()
        )

    def test_exception_does_not_exit(
        self, tmp_path: Path,
    ) -> None:
        """Exception in processing does not terminate the loop."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        call_count = 0

        def side_effect(*_args: object, **_kwargs: object) -> None:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise ValueError("test error")

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._process_prompt",
            side_effect=side_effect,
        ):
            mock_ps.return_value.prompt.side_effect = [
                "prompt1", "prompt2", "/quit",
            ]
            run_repl(settings=stg, console=con)

        # Second prompt should still be processed
        assert call_count == 2

    def test_dry_run_passed_to_dispatch(
        self, tmp_path: Path,
    ) -> None:
        """dry_run flag is passed through to command dispatch."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._dispatch_command",
            return_value="quit",
        ) as mock_disp:
            mock_ps.return_value.prompt.side_effect = ["/help"]
            run_repl(
                settings=stg, console=con,
                dry_run=True, offline=False,
            )

        mock_disp.assert_called_once()
        _, kwargs = mock_disp.call_args
        assert kwargs.get("dry_run") is True

    def test_offline_passed_to_dispatch(
        self, tmp_path: Path,
    ) -> None:
        """offline flag is passed through to command dispatch."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._dispatch_command",
            return_value="quit",
        ) as mock_disp:
            mock_ps.return_value.prompt.side_effect = ["/status"]
            run_repl(
                settings=stg, console=con,
                dry_run=False, offline=True,
            )

        mock_disp.assert_called_once()
        _, kwargs = mock_disp.call_args
        assert kwargs.get("offline") is True

    def test_dry_run_and_offline_defaults(
        self, tmp_path: Path,
    ) -> None:
        """Default values for dry_run and offline are False."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._process_prompt",
        ) as mock_proc:
            mock_ps.return_value.prompt.side_effect = [
                "hello", "/quit",
            ]
            run_repl(settings=stg, console=con)

        _, kwargs = mock_proc.call_args
        assert kwargs.get("dry_run") is False
        assert kwargs.get("offline") is False

    def test_creates_history_dir(self, tmp_path: Path) -> None:
        """run_repl creates the sessions directory for history."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = EOFError
            run_repl(settings=stg, console=con)

        assert stg.sessions_dir.exists()

    def test_ready_message_displayed(
        self, tmp_path: Path,
    ) -> None:
        """The 'Ready' message is printed on startup."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = EOFError
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "Goodbye" in output or "Providers" in output or output.strip()

    def test_slash_commands_dont_call_process_prompt(
        self, tmp_path: Path,
    ) -> None:
        """Slash commands are dispatched, not sent to
        _process_prompt."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._process_prompt",
        ) as mock_proc:
            mock_ps.return_value.prompt.side_effect = [
                "/help", "/cost", "/status", "/quit",
            ]
            run_repl(settings=stg, console=con)

        mock_proc.assert_not_called()

    def test_pinned_model_from_settings(
        self, tmp_path: Path,
    ) -> None:
        """State picks up pinned_model from settings.config."""
        config = PrismConfig(
            prism_home=tmp_path / ".prism",
            pinned_model="claude-3-opus",
        )
        stg = Settings(config=config, project_root=tmp_path)
        stg.ensure_directories()
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/model", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "claude-3-opus" in output

    def test_add_drop_via_loop(self, tmp_path: Path) -> None:
        """Adding and dropping files through the loop works."""
        stg = _make_settings(tmp_path)
        con = _make_console()
        # Create a real file for /add
        test_file = tmp_path / "hello.py"
        test_file.write_text("x = 1\n")

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                f"/add {test_file}",
                "/drop",
                "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        # /add should show the file was added
        assert "hello.py" in output or "Added" in output

    def test_web_toggle_via_loop(self, tmp_path: Path) -> None:
        """Toggling web mode through the loop works."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/web on", "/web off", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "enabled" in output.lower() or (
            "on" in output.lower()
        )

    def test_unknown_command_via_loop(
        self, tmp_path: Path,
    ) -> None:
        """Unknown slash command shows error, does not exit."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/nonexistent", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "Unknown command" in output

    def test_mixed_commands_and_prompts(
        self, tmp_path: Path,
    ) -> None:
        """Mix of commands and prompts all handled correctly."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._process_prompt",
        ) as mock_proc:
            mock_ps.return_value.prompt.side_effect = [
                "/help",
                "hello",
                "/cost",
                "world",
                "/quit",
            ]
            run_repl(settings=stg, console=con)

        assert mock_proc.call_count == 2

    def test_conversation_maintained_across_prompts(
        self, tmp_path: Path,
    ) -> None:
        """The same state object is passed to each call."""
        stg = _make_settings(tmp_path)
        con = _make_console()
        states_seen: list[object] = []

        def capture_state(
            *_args: object, **kwargs: object,
        ) -> None:
            states_seen.append(id(kwargs.get("state")))

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._process_prompt",
            side_effect=capture_state,
        ):
            mock_ps.return_value.prompt.side_effect = [
                "first", "second", "/quit",
            ]
            run_repl(settings=stg, console=con)

        assert len(states_seen) == 2
        assert states_seen[0] == states_seen[1]

    def test_session_uuid_generated(
        self, tmp_path: Path,
    ) -> None:
        """run_repl generates a session UUID on the state."""
        stg = _make_settings(tmp_path)
        con = _make_console()
        captured_state: list[_SessionState] = []

        def capture(
            *_args: object, **kwargs: object,
        ) -> None:
            s = kwargs.get("state")
            if s is not None:
                captured_state.append(s)

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl._process_prompt",
            side_effect=capture,
        ):
            mock_ps.return_value.prompt.side_effect = [
                "hello", "/quit",
            ]
            run_repl(settings=stg, console=con)

        assert len(captured_state) == 1
        assert len(captured_state[0].session_id) == 12

    def test_prompt_session_uses_file_history(
        self, tmp_path: Path,
    ) -> None:
        """PromptSession is created with FileHistory."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps, patch(
            "prism.cli.repl.FileHistory",
        ) as mock_fh:
            mock_ps.return_value.prompt.side_effect = EOFError
            run_repl(settings=stg, console=con)

        mock_fh.assert_called_once()
        mock_ps.assert_called_once()
        call_kwargs = mock_ps.call_args[1]
        assert "history" in call_kwargs
        assert call_kwargs.get("multiline") is False
        assert call_kwargs.get("enable_history_search") is True

    def test_clear_in_loop(self, tmp_path: Path) -> None:
        """/clear in the REPL loop shows confirmation."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/clear", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        assert "clear" in output.lower() or (
            "Cleared" in output
        )

    def test_status_in_loop(self, tmp_path: Path) -> None:
        """/status in the REPL loop shows provider status."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = [
                "/status", "/quit",
            ]
            run_repl(settings=stg, console=con)

        output = _get_output(con)
        # Status command should produce some output
        assert len(output) > 0


# ===========================================================================
# Enhanced /cache command tests
# ===========================================================================


class TestCacheCommandEnhanced:
    """Tests for the enhanced /cache command (on/off/clear --older-than)."""

    def test_cache_on_returns_continue(self, tmp_path: Path) -> None:
        action, output, _, _, st = _cmd("/cache on", tmp_path)
        assert action == "continue"
        assert st.cache_enabled is True
        assert "re-enabled" in output.lower() or "enabled" in output.lower()

    def test_cache_off_returns_continue(self, tmp_path: Path) -> None:
        action, output, _, _, st = _cmd("/cache off", tmp_path)
        assert action == "continue"
        assert st.cache_enabled is False
        assert "disabled" in output.lower()

    def test_cache_off_then_on_toggles(self, tmp_path: Path) -> None:
        """Off then on should toggle the flag correctly."""
        st = _make_state()
        assert st.cache_enabled is True

        _cmd("/cache off", tmp_path, state=st)
        assert st.cache_enabled is False

        _cmd("/cache on", tmp_path, state=st)
        assert st.cache_enabled is True

    def test_cache_stats_shows_session_status(
        self, tmp_path: Path,
    ) -> None:
        """Stats should include session enabled/disabled status."""
        _, output, _, _, _ = _cmd("/cache stats", tmp_path)
        assert "Session" in output or "enabled" in output.lower() or len(output) > 0

    def test_cache_clear_older_than_returns_continue(
        self, tmp_path: Path,
    ) -> None:
        action, _, _, _, _ = _cmd(
            "/cache clear --older-than 24h", tmp_path,
        )
        assert action == "continue"

    def test_cache_clear_older_than_invalid_duration(
        self, tmp_path: Path,
    ) -> None:
        """Invalid duration should show an error message."""
        _, output, _, _, _ = _cmd(
            "/cache clear --older-than xyz", tmp_path,
        )
        assert "Invalid" in output or "duration" in output.lower() or len(output) > 0

    def test_cache_clear_older_than_2d(
        self, tmp_path: Path,
    ) -> None:
        action, _output, _, _, _ = _cmd(
            "/cache clear --older-than 2d", tmp_path,
        )
        assert action == "continue"

    def test_cache_stats_default(self, tmp_path: Path) -> None:
        """Default /cache command should show stats."""
        action, output, _, _, _ = _cmd("/cache", tmp_path)
        assert action == "continue"
        assert len(output.strip()) > 0


# ===========================================================================
# _parse_duration_to_hours tests
# ===========================================================================


class TestParseDurationToHours:
    """Tests for the _parse_duration_to_hours helper."""

    def test_hours(self) -> None:
        from prism.cli.repl import _parse_duration_to_hours

        assert _parse_duration_to_hours("24h") == 24.0

    def test_days(self) -> None:
        from prism.cli.repl import _parse_duration_to_hours

        assert _parse_duration_to_hours("2d") == 48.0

    def test_minutes(self) -> None:
        from prism.cli.repl import _parse_duration_to_hours

        result = _parse_duration_to_hours("30m")
        assert result is not None
        assert abs(result - 0.5) < 0.01

    def test_weeks(self) -> None:
        from prism.cli.repl import _parse_duration_to_hours

        assert _parse_duration_to_hours("1w") == 168.0

    def test_invalid_returns_none(self) -> None:
        from prism.cli.repl import _parse_duration_to_hours

        assert _parse_duration_to_hours("invalid") is None
        assert _parse_duration_to_hours("") is None
        assert _parse_duration_to_hours("24x") is None

    def test_float_values(self) -> None:
        from prism.cli.repl import _parse_duration_to_hours

        result = _parse_duration_to_hours("1.5h")
        assert result is not None
        assert abs(result - 1.5) < 0.01

    def test_whitespace_handling(self) -> None:
        from prism.cli.repl import _parse_duration_to_hours

        result = _parse_duration_to_hours("  24h  ")
        assert result == 24.0


# ===========================================================================
# /image command tests
# ===========================================================================


class TestImageCommand:
    """Tests for the /image slash command."""

    def test_image_no_args_shows_usage(
        self, tmp_path: Path,
    ) -> None:
        action, output, _, _, _ = _cmd("/image", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_image_returns_continue(self, tmp_path: Path) -> None:
        """Even with invalid args, should return continue."""
        action, _, _, _, _ = _cmd(
            "/image nonexistent.png", tmp_path,
        )
        assert action == "continue"

    def test_image_nonexistent_file_shows_error(
        self, tmp_path: Path,
    ) -> None:
        """Missing file should show error."""
        _, output, _, _, _ = _cmd(
            "/image /tmp/nonexistent_image_12345.png", tmp_path,
        )
        assert (
            "not found" in output.lower()
            or "No valid" in output
            or "error" in output.lower()
            or len(output.strip()) > 0
        )

    def test_image_command_in_dispatch(
        self, tmp_path: Path,
    ) -> None:
        """Ensure /image is recognized (not unknown)."""
        _, output, _, _, _ = _cmd("/image test.png", tmp_path)
        assert "Unknown command" not in output

    def test_image_in_command_categories(self) -> None:
        """Ensure /image appears in COMMAND_CATEGORIES."""
        all_commands = []
        for cmds in COMMAND_CATEGORIES.values():
            for cmd_name, _ in cmds:
                all_commands.append(cmd_name)
        assert any("/image" in c for c in all_commands)


# ===========================================================================
# Enhanced /compare command tests
# ===========================================================================


class TestCompareCommandEnhanced:
    """Tests for the enhanced /compare command."""

    def test_compare_config_returns_continue(
        self, tmp_path: Path,
    ) -> None:
        action, _, _, _, _ = _cmd("/compare config", tmp_path)
        assert action == "continue"

    def test_compare_history_returns_continue(
        self, tmp_path: Path,
    ) -> None:
        action, _, _, _, _ = _cmd("/compare history", tmp_path)
        assert action == "continue"

    def test_compare_history_empty(self, tmp_path: Path) -> None:
        """History should indicate no sessions when empty."""
        _, output, _, _, _ = _cmd(
            "/compare history", tmp_path,
        )
        assert (
            "No comparison" in output
            or "history" in output.lower()
            or len(output.strip()) > 0
        )

    def test_compare_no_args_shows_usage(
        self, tmp_path: Path,
    ) -> None:
        action, output, _, _, _ = _cmd("/compare", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_compare_prompt_returns_continue(
        self, tmp_path: Path,
    ) -> None:
        """Even with a prompt, should return continue."""
        action, _, _, _, _ = _cmd(
            "/compare what is 2+2", tmp_path,
        )
        assert action == "continue"


# ===========================================================================
# SessionState cache_enabled tests
# ===========================================================================


class TestSessionStateCacheEnabled:
    """Tests for the cache_enabled attribute on _SessionState."""

    def test_default_cache_enabled(self) -> None:
        state = _SessionState(pinned_model=None)
        assert state.cache_enabled is True

    def test_cache_enabled_false(self) -> None:
        state = _SessionState(
            pinned_model=None, cache_enabled=False,
        )
        assert state.cache_enabled is False

    def test_cache_enabled_true_explicit(self) -> None:
        state = _SessionState(
            pinned_model=None, cache_enabled=True,
        )
        assert state.cache_enabled is True

    def test_toggle_cache(self) -> None:
        state = _SessionState(pinned_model=None)
        state.cache_enabled = False
        assert state.cache_enabled is False
        state.cache_enabled = True
        assert state.cache_enabled is True


# ===========================================================================
# run_repl no_cache parameter tests
# ===========================================================================


class TestRunReplNoCache:
    """Tests for the no_cache parameter on run_repl."""

    def test_run_repl_no_cache_true(self, tmp_path: Path) -> None:
        """When no_cache=True, session cache should be disabled."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = ["/quit"]
            run_repl(
                settings=stg,
                console=con,
                no_cache=True,
            )

        output = _get_output(con)
        assert len(output) > 0

    def test_run_repl_no_cache_false(self, tmp_path: Path) -> None:
        """When no_cache=False (default), cache should be on."""
        stg = _make_settings(tmp_path)
        con = _make_console()

        with patch(
            "prism.cli.repl.PromptSession",
        ) as mock_ps:
            mock_ps.return_value.prompt.side_effect = ["/quit"]
            run_repl(
                settings=stg,
                console=con,
                no_cache=False,
            )

        output = _get_output(con)
        assert len(output) > 0


# ===========================================================================
# /ignore command tests
# ===========================================================================


class TestIgnoreCommand:
    """Tests for the /ignore slash command."""

    def test_ignore_list_default(self, tmp_path: Path) -> None:
        """'/ignore' with no args lists patterns (defaults loaded)."""
        action, output, _, _, _ = _cmd("/ignore", tmp_path)
        assert action == "continue"
        # Default patterns include .env
        assert ".env" in output

    def test_ignore_list_explicit(self, tmp_path: Path) -> None:
        """'/ignore list' explicitly lists patterns."""
        action, output, _, _, _ = _cmd("/ignore list", tmp_path)
        assert action == "continue"
        assert ".prismignore patterns" in output

    def test_ignore_add_no_args_shows_usage(
        self, tmp_path: Path,
    ) -> None:
        action, output, _, _, _ = _cmd("/ignore add", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_ignore_add_pattern(self, tmp_path: Path) -> None:
        """Adding a new pattern reports success."""
        action, output, _, _, _ = _cmd(
            "/ignore add *.secret", tmp_path,
        )
        assert action == "continue"
        assert "Added pattern" in output
        assert "*.secret" in output

    def test_ignore_add_duplicate_pattern(
        self, tmp_path: Path,
    ) -> None:
        """Adding an existing default pattern reports duplicate."""
        action, output, _, _, _ = _cmd(
            "/ignore add .env", tmp_path,
        )
        assert action == "continue"
        assert "already exists" in output

    def test_ignore_check_no_args_shows_usage(
        self, tmp_path: Path,
    ) -> None:
        action, output, _, _, _ = _cmd(
            "/ignore check", tmp_path,
        )
        assert action == "continue"
        assert "Usage" in output

    def test_ignore_check_ignored_file(
        self, tmp_path: Path,
    ) -> None:
        """.env should be ignored by default patterns."""
        action, output, _, _, _ = _cmd(
            "/ignore check .env", tmp_path,
        )
        assert action == "continue"
        assert "IGNORED" in output

    def test_ignore_check_not_ignored_file(
        self, tmp_path: Path,
    ) -> None:
        """A normal Python file should not be ignored."""
        action, output, _, _, _ = _cmd(
            "/ignore check main.py", tmp_path,
        )
        assert action == "continue"
        assert "NOT IGNORED" in output

    def test_ignore_check_shows_matching_pattern(
        self, tmp_path: Path,
    ) -> None:
        """Check should show which pattern matched."""
        action, output, _, _, _ = _cmd(
            "/ignore check server.key", tmp_path,
        )
        assert action == "continue"
        assert "IGNORED" in output
        assert "*.key" in output

    def test_ignore_create_when_exists(
        self, tmp_path: Path,
    ) -> None:
        """Create should warn if .prismignore already exists."""
        # Create the file first
        (tmp_path / ".prismignore").write_text("*.log\n")
        action, output, _, _, _ = _cmd(
            "/ignore create", tmp_path,
        )
        assert action == "continue"
        assert "already exists" in output

    def test_ignore_create_new(self, tmp_path: Path) -> None:
        """Create should succeed when no .prismignore exists.

        PrismIgnore falls back to defaults in memory even without
        a file, so we need a subdirectory with no .prismignore.
        """
        sub = tmp_path / "subproject"
        sub.mkdir()
        stg = _make_settings(sub)
        action, _output, _, _, _ = _cmd(
            "/ignore create", sub, settings=stg,
        )
        assert action == "continue"
        # File should have been created on disk
        assert (sub / ".prismignore").is_file()

    def test_ignore_unknown_subcommand(
        self, tmp_path: Path,
    ) -> None:
        action, output, _, _, _ = _cmd(
            "/ignore bogus", tmp_path,
        )
        assert action == "continue"
        assert "Usage" in output


# ===========================================================================
# /add prismignore warning tests
# ===========================================================================


class TestAddPrismignoreWarning:
    """Tests that /add warns about .prismignore-matched files."""

    def test_add_ignored_file_shows_warning(
        self, tmp_path: Path,
    ) -> None:
        """Adding .env should produce an ignore warning."""
        action, output, _, _, st = _cmd(
            "/add .env", tmp_path,
        )
        assert action == "continue"
        assert "Warning" in output
        assert ".prismignore" in output
        # File should still be added
        assert ".env" in st.active_files

    def test_add_normal_file_no_warning(
        self, tmp_path: Path,
    ) -> None:
        """Adding a normal file should not produce a warning."""
        action, output, _, _, st = _cmd(
            "/add main.py", tmp_path,
        )
        assert action == "continue"
        assert "Warning" not in output
        assert "main.py" in st.active_files

    def test_add_key_file_shows_warning(
        self, tmp_path: Path,
    ) -> None:
        """Adding *.key files should warn (crypto key pattern)."""
        action, output, _, _, st = _cmd(
            "/add server.key", tmp_path,
        )
        assert action == "continue"
        assert "Warning" in output
        assert "secrets" in output.lower() or "prismignore" in output
        assert "server.key" in st.active_files

    def test_add_mixed_warns_only_for_ignored(
        self, tmp_path: Path,
    ) -> None:
        """Mixed add: warns for .env but not for safe.py."""
        action, output, _, _, st = _cmd(
            "/add .env safe.py", tmp_path,
        )
        assert action == "continue"
        # Should have warning for .env
        assert "Warning" in output
        # Both files added
        assert ".env" in st.active_files
        assert "safe.py" in st.active_files


# ======================================================================
# Task 1: Self-Correction — _format_tool_error tests
# ======================================================================


class TestFormatToolError:
    """Tests for _format_tool_error: structured errors with hints."""

    def test_basic_error_format(self) -> None:
        """Error should include tool name, message, and retry prompt."""
        result = _format_tool_error("read_file", "Something went wrong")
        assert "ERROR in read_file" in result
        assert "Something went wrong" in result
        assert "try a different approach" in result

    def test_edit_file_not_found_hint(self) -> None:
        """edit_file with 'not found' should suggest read_file first."""
        result = _format_tool_error(
            "edit_file", "Search string not found in file",
        )
        assert "read_file" in result
        assert "actual content" in result

    def test_edit_file_no_match_hint(self) -> None:
        """edit_file with 'no match' should suggest read_file first."""
        result = _format_tool_error(
            "edit_file", "No match for the given pattern",
        )
        assert "read_file first" in result

    def test_read_file_not_found_hint(self) -> None:
        """read_file with 'no such file' should suggest list_directory."""
        result = _format_tool_error(
            "read_file", "No such file or directory: /foo/bar.py",
        )
        assert "list_directory" in result

    def test_read_file_file_not_found_hint(self) -> None:
        """read_file with 'not found' should suggest list_directory."""
        result = _format_tool_error(
            "read_file", "File not found: /foo/bar.py",
        )
        assert "list_directory" in result

    def test_execute_command_permission_denied_hint(self) -> None:
        """execute_command with 'permission denied' should hint."""
        result = _format_tool_error(
            "execute_command", "Permission denied: /usr/bin/foo",
        )
        assert "Permission denied" in result
        assert "permission" in result.lower()

    def test_execute_command_not_found_hint(self) -> None:
        """execute_command with 'not found' should suggest checking."""
        result = _format_tool_error(
            "execute_command", "command not found: foobar",
        )
        assert "not installed" in result or "Install" in result
        assert "installed" in result.lower()

    def test_timeout_hint(self) -> None:
        """Any tool with 'timeout' should suggest simpler approach."""
        result = _format_tool_error(
            "execute_command", "Operation timeout after 30s",
        )
        assert "timed out" in result
        assert "smaller" in result or "timeout" in result.lower()

    def test_generic_error_no_hint(self) -> None:
        """Unrecognized errors get no hint, just the standard format."""
        result = _format_tool_error(
            "search_codebase", "Internal regex error",
        )
        assert "ERROR in search_codebase" in result
        assert "Internal regex error" in result
        assert "try a different approach" in result
        # Should not contain any specific hint
        assert "Hint:" not in result

    def test_case_insensitive_matching(self) -> None:
        """Error matching should be case-insensitive."""
        result = _format_tool_error(
            "edit_file", "SEARCH STRING NOT FOUND",
        )
        assert "read_file first" in result


class TestExecuteToolWithPermission:
    """Tests for _execute_tool_with_permission self-correction format."""

    def test_unknown_tool_returns_formatted_error(self) -> None:
        """Unknown tools should use _format_tool_error format."""
        from unittest.mock import MagicMock

        registry = MagicMock()
        registry.get_tool.side_effect = KeyError("no such tool")
        console = _make_console()

        result = _execute_tool_with_permission(
            "nonexistent_tool", {}, registry, console,
        )
        assert "ERROR in nonexistent_tool" in result
        assert "Unknown tool" in result
        assert "try a different approach" in result

    def test_tool_failure_returns_formatted_error(self) -> None:
        """Failed tool execution should use _format_tool_error."""
        from dataclasses import dataclass
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        @dataclass
        class FakeResult:
            success: bool
            output: str
            error: str | None

        tool = MagicMock()
        tool.permission_level = PermissionLevel.AUTO
        tool.execute.return_value = FakeResult(
            success=False, output="", error="File not found: /x.py",
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        result = _execute_tool_with_permission(
            "read_file", {"path": "/x.py"}, registry, console,
        )
        assert "ERROR in read_file" in result
        assert "File not found" in result
        assert "try a different approach" in result

    def test_tool_exception_returns_formatted_error(self) -> None:
        """Exceptions during tool execution should use _format_tool_error."""
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        tool = MagicMock()
        tool.permission_level = PermissionLevel.AUTO
        tool.execute.side_effect = RuntimeError("disk full")

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        result = _execute_tool_with_permission(
            "write_file", {"path": "/x.py", "content": "hi"},
            registry, console,
        )
        assert "ERROR in write_file" in result
        assert "disk full" in result

    def test_successful_tool_returns_output(self) -> None:
        """Successful tools should return output, not error format."""
        from dataclasses import dataclass
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        @dataclass
        class FakeResult:
            success: bool
            output: str
            error: str | None

        tool = MagicMock()
        tool.permission_level = PermissionLevel.AUTO
        tool.execute.return_value = FakeResult(
            success=True, output="file contents here", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        result = _execute_tool_with_permission(
            "read_file", {"path": "/x.py"}, registry, console,
        )
        assert result == "file contents here"
        assert "ERROR" not in result


# ======================================================================
# Task 2: Project Memory — _load_project_instructions / system prompt
# ======================================================================


class TestLoadProjectInstructions:
    """Tests for _load_project_instructions and system prompt integration."""

    def test_no_instruction_files(self, tmp_path: Path) -> None:
        """Returns empty string when no instruction files exist."""
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _load_project_instructions()
        assert result == ""

    def test_prism_md_loaded(self, tmp_path: Path) -> None:
        """.prism.md should be loaded when present."""
        prism_md = tmp_path / ".prism.md"
        prism_md.write_text("Use pytest for testing.\nPrefer async.")
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _load_project_instructions()
        assert "Use pytest for testing" in result
        assert "Prefer async" in result

    def test_claude_md_loaded(self, tmp_path: Path) -> None:
        """CLAUDE.md should be loaded when .prism.md doesn't exist."""
        claude_md = tmp_path / "CLAUDE.md"
        claude_md.write_text("# Claude Instructions\nBe concise.")
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _load_project_instructions()
        assert "Claude Instructions" in result
        assert "Be concise" in result

    def test_dot_claude_md_loaded(self, tmp_path: Path) -> None:
        """.claude.md should be loaded as last fallback."""
        dot_claude = tmp_path / ".claude.md"
        dot_claude.write_text("Hidden claude config.")
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _load_project_instructions()
        assert "Hidden claude config" in result

    def test_prism_md_takes_priority(self, tmp_path: Path) -> None:
        """.prism.md should take priority over CLAUDE.md."""
        (tmp_path / ".prism.md").write_text("PRISM RULES")
        (tmp_path / "CLAUDE.md").write_text("CLAUDE RULES")
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _load_project_instructions()
        assert "PRISM RULES" in result
        assert "CLAUDE RULES" not in result

    def test_content_capped_at_4000_chars(self, tmp_path: Path) -> None:
        """Content should be truncated to 4000 characters."""
        prism_md = tmp_path / ".prism.md"
        prism_md.write_text("X" * 5000)
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _load_project_instructions()
        assert len(result) == 4000

    def test_unreadable_file_skipped(self, tmp_path: Path) -> None:
        """If .prism.md can't be read, fall through to next file."""
        prism_md = tmp_path / ".prism.md"
        prism_md.write_text("content")
        claude_md = tmp_path / "CLAUDE.md"
        claude_md.write_text("CLAUDE fallback")
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            # Make .prism.md unreadable by patching read_text
            original_read = _RealPath.read_text

            def patched_read(self: _RealPath, **kw: str) -> str:
                if self.name == ".prism.md":
                    raise OSError("Permission denied")
                return original_read(self, **kw)

            with patch.object(
                _RealPath, "read_text", patched_read,
            ):
                result = _load_project_instructions()
        assert "CLAUDE fallback" in result


class TestBuildSystemPromptIntegration:
    """Tests for _build_system_prompt with self-correction and project memory."""

    def test_self_correction_rules_present(self, tmp_path: Path) -> None:
        """System prompt should contain tool usage and retry guidance."""
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _build_system_prompt()
        content = result["content"]
        # System prompt should have tool guidance and retry instructions
        assert "tool" in content.lower()
        assert "retry" in content.lower() or "retries" in content.lower()
        assert "read" in content.lower()
        assert "edit" in content.lower()

    def test_project_instructions_included(self, tmp_path: Path) -> None:
        """System prompt should include .prism.md content when present."""
        (tmp_path / ".prism.md").write_text("Always use type hints.")
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _build_system_prompt()
        content = result["content"]
        assert "Project Instructions" in content
        assert "Always use type hints" in content

    def test_no_project_instructions_section_when_missing(
        self, tmp_path: Path,
    ) -> None:
        """No 'Project Instructions' header when no files exist."""
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _build_system_prompt()
        content = result["content"]
        assert "Project Instructions" not in content

    def test_system_prompt_structure(self, tmp_path: Path) -> None:
        """System prompt should have role=system and contain basics."""
        from pathlib import Path as _RealPath
        with patch.object(_RealPath, "cwd", return_value=tmp_path):
            result = _build_system_prompt()
        assert result["role"] == "system"
        assert "Prism" in result["content"]
        # System prompt should describe behavior and tools
        assert "tool" in result["content"].lower()
        assert "autonomous" in result["content"].lower() or "concise" in result["content"].lower()


# ===========================================================================
# /test (/autotest) — _cmd_autotest
# ===========================================================================


class TestAutotestCommand:
    """Tests for the /test and /autotest slash commands."""

    def test_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/test", tmp_path)
        assert action == "continue"

    def test_no_tool_registry_shows_warning(self, tmp_path: Path) -> None:
        """When tool_registry is None, a yellow warning is shown."""
        state = _make_state()
        state.tool_registry = None
        action, output, _, _, _ = _cmd("/test", tmp_path, state=state)
        assert action == "continue"
        assert "Tool registry not initialized" in output

    def test_no_changed_files_shows_hint(self, tmp_path: Path) -> None:
        """When git returns no changes and no args given, show hint."""
        from unittest.mock import MagicMock
        state = _make_state()
        mock_registry = MagicMock()
        state.tool_registry = mock_registry

        # Mock subprocess.run to return empty stdout (no changes)
        mock_result = MagicMock()
        mock_result.stdout = ""
        with patch("subprocess.run", return_value=mock_result):
            action, output, _, _, _ = _cmd("/test", tmp_path, state=state)
        assert action == "continue"
        assert "No changed files" in output

    def test_explicit_files_passed(self, tmp_path: Path) -> None:
        """When files are passed explicitly, they are forwarded to tool."""
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=True, output="All 5 tests passed.",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd(
            "/test foo.py bar.py", tmp_path, state=state,
        )
        assert action == "continue"
        mock_registry.get_tool.assert_called_once_with("auto_test")
        mock_tool.execute.assert_called_once_with(
            {"changed_files": ["foo.py", "bar.py"]},
        )
        assert "Test Results" in output
        assert "All 5 tests passed" in output

    def test_tool_execute_failure(self, tmp_path: Path) -> None:
        """When tool returns success=False, the panel uses red border."""
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=False, output="", error="2 tests failed",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd(
            "/test src/main.py", tmp_path, state=state,
        )
        assert action == "continue"
        assert "2 tests failed" in output

    def test_git_auto_detect_head(self, tmp_path: Path) -> None:
        """When no args, auto-detects changed files from git diff HEAD."""
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=True, output="Tests passed.",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        mock_result = MagicMock()
        mock_result.stdout = "src/foo.py\nsrc/bar.py\n"
        with patch("subprocess.run", return_value=mock_result):
            action, _output, _, _, _ = _cmd("/test", tmp_path, state=state)
        assert action == "continue"
        mock_tool.execute.assert_called_once_with(
            {"changed_files": ["src/foo.py", "src/bar.py"]},
        )

    def test_git_fallback_to_cached(self, tmp_path: Path) -> None:
        """When git diff HEAD is empty, falls back to --cached."""
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=True, output="OK",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        empty_result = MagicMock()
        empty_result.stdout = ""
        cached_result = MagicMock()
        cached_result.stdout = "staged.py\n"

        with patch("subprocess.run", side_effect=[empty_result, cached_result]):
            action, _output, _, _, _ = _cmd("/test", tmp_path, state=state)
        assert action == "continue"
        mock_tool.execute.assert_called_once_with(
            {"changed_files": ["staged.py"]},
        )

    def test_exception_handled(self, tmp_path: Path) -> None:
        """Exceptions inside _cmd_autotest are caught and displayed."""
        from unittest.mock import MagicMock

        state = _make_state()
        mock_registry = MagicMock()
        mock_registry.get_tool.side_effect = RuntimeError("boom")
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd(
            "/test foo.py", tmp_path, state=state,
        )
        assert action == "continue"
        assert "Error" in output
        assert "boom" in output

    def test_alias_autotest(self, tmp_path: Path) -> None:
        """The /autotest alias routes to the same handler."""
        state = _make_state()
        state.tool_registry = None
        action, output, _, _, _ = _cmd("/autotest", tmp_path, state=state)
        assert action == "continue"
        assert "Tool registry not initialized" in output


# ===========================================================================
# /quality (/lint) — _cmd_quality
# ===========================================================================


class TestQualityCommand:
    """Tests for the /quality and /lint slash commands."""

    def test_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/quality", tmp_path)
        assert action == "continue"

    def test_no_tool_registry_shows_warning(self, tmp_path: Path) -> None:
        state = _make_state()
        state.tool_registry = None
        action, output, _, _, _ = _cmd("/quality", tmp_path, state=state)
        assert action == "continue"
        assert "Tool registry not initialized" in output

    def test_no_changed_files_shows_hint(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock

        state = _make_state()
        mock_registry = MagicMock()
        state.tool_registry = mock_registry

        mock_result = MagicMock()
        mock_result.stdout = ""
        with patch("subprocess.run", return_value=mock_result):
            action, output, _, _, _ = _cmd("/quality", tmp_path, state=state)
        assert action == "continue"
        assert "No changed files" in output

    def test_explicit_files_success(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=True, output="All checks passed!",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd(
            "/quality module.py", tmp_path, state=state,
        )
        assert action == "continue"
        mock_registry.get_tool.assert_called_once_with("quality_gate")
        mock_tool.execute.assert_called_once_with(
            {"changed_files": ["module.py"], "action": "check"},
        )
        assert "Quality Gate" in output
        assert "All checks passed" in output

    def test_tool_execute_failure(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=False, output="", error="ruff found 3 issues",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd(
            "/quality foo.py", tmp_path, state=state,
        )
        assert action == "continue"
        assert "ruff found 3 issues" in output

    def test_git_auto_detect(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=True, output="Clean!",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        mock_result = MagicMock()
        mock_result.stdout = "a.py\nb.py\n"
        with patch("subprocess.run", return_value=mock_result):
            action, _, _, _, _ = _cmd("/quality", tmp_path, state=state)
        assert action == "continue"
        mock_tool.execute.assert_called_once_with(
            {"changed_files": ["a.py", "b.py"], "action": "check"},
        )

    def test_exception_handled(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock

        state = _make_state()
        mock_registry = MagicMock()
        mock_registry.get_tool.side_effect = ValueError("no such tool")
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd(
            "/quality foo.py", tmp_path, state=state,
        )
        assert action == "continue"
        assert "Error" in output
        assert "no such tool" in output

    def test_alias_lint(self, tmp_path: Path) -> None:
        state = _make_state()
        state.tool_registry = None
        action, output, _, _, _ = _cmd("/lint", tmp_path, state=state)
        assert action == "continue"
        assert "Tool registry not initialized" in output


# ===========================================================================
# /optimize — _cmd_optimize
# ===========================================================================


class TestOptimizeCommand:
    """Tests for the /optimize slash command."""

    def test_returns_continue(self, tmp_path: Path) -> None:
        action, _, _, _, _ = _cmd("/optimize", tmp_path)
        assert action == "continue"

    def test_no_tool_registry_shows_warning(self, tmp_path: Path) -> None:
        state = _make_state()
        state.tool_registry = None
        action, output, _, _, _ = _cmd("/optimize", tmp_path, state=state)
        assert action == "continue"
        assert "Tool registry not initialized" in output

    def test_tool_not_found_shows_hint(self, tmp_path: Path) -> None:
        """When get_tool raises, shows a friendly message about usage history."""
        from unittest.mock import MagicMock

        state = _make_state()
        mock_registry = MagicMock()
        mock_registry.get_tool.side_effect = KeyError("cost_optimizer")
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd("/optimize", tmp_path, state=state)
        assert action == "continue"
        assert "usage history" in output

    def test_default_action_recommend(self, tmp_path: Path) -> None:
        """When no args, default action is 'recommend'."""
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=True, output="Switch to GPT-4o-mini for simple tasks.",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd("/optimize", tmp_path, state=state)
        assert action == "continue"
        mock_tool.execute.assert_called_once_with({"action": "recommend"})
        assert "Cost Optimization" in output
        assert "GPT-4o-mini" in output

    def test_custom_action_arg(self, tmp_path: Path) -> None:
        """Custom action passed via args is forwarded to the tool."""
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=True, output="Report generated.",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        action, _output, _, _, _ = _cmd(
            "/optimize report", tmp_path, state=state,
        )
        assert action == "continue"
        mock_tool.execute.assert_called_once_with({"action": "report"})

    def test_tool_execute_failure(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock

        from prism.tools.base import ToolResult

        state = _make_state()
        mock_tool = MagicMock()
        mock_tool.execute.return_value = ToolResult(
            success=False, output="", error="Not enough data",
        )
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = mock_tool
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd("/optimize", tmp_path, state=state)
        assert action == "continue"
        assert "Not enough data" in output

    def test_exception_handled(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock

        state = _make_state()
        mock_registry = MagicMock()
        mock_registry.get_tool.return_value = MagicMock(
            execute=MagicMock(side_effect=RuntimeError("db crash")),
        )
        state.tool_registry = mock_registry

        action, output, _, _, _ = _cmd("/optimize", tmp_path, state=state)
        assert action == "continue"
        assert "Error" in output
        assert "db crash" in output


# ===========================================================================
# /memory — _cmd_memory
# ===========================================================================


class TestMemoryCommand:
    """Tests for the /memory slash command."""

    def test_returns_continue(self, tmp_path: Path) -> None:
        with patch("prism.context.memory.ProjectMemory") as mock_cls:
            mock_mem = mock_cls.return_value
            mock_mem.get_facts.return_value = {}
            action, _, _, _, _ = _cmd("/memory", tmp_path)
        assert action == "continue"

    def test_show_empty(self, tmp_path: Path) -> None:
        """When no facts exist, show a hint message."""
        with patch("prism.context.memory.ProjectMemory") as mock_cls:
            mock_mem = mock_cls.return_value
            mock_mem.get_facts.return_value = {}
            action, output, _, _, _ = _cmd("/memory show", tmp_path)
        assert action == "continue"
        assert "No project memory facts" in output

    def test_show_default_subcommand(self, tmp_path: Path) -> None:
        """No sub-command defaults to 'show'."""
        with patch("prism.context.memory.ProjectMemory") as mock_cls:
            mock_mem = mock_cls.return_value
            mock_mem.get_facts.return_value = {}
            _, output, _, _, _ = _cmd("/memory", tmp_path)
        assert "No project memory facts" in output

    def test_show_with_facts(self, tmp_path: Path) -> None:
        """When facts exist, display them in a table."""
        with patch("prism.context.memory.ProjectMemory") as mock_cls:
            mock_mem = mock_cls.return_value
            mock_mem.get_facts.return_value = {
                "stack": "Python 3.12",
                "framework": "FastAPI",
            }
            _, output, _, _, _ = _cmd("/memory show", tmp_path)
        assert "Project Memory" in output
        assert "stack" in output
        assert "Python 3.12" in output
        assert "framework" in output
        assert "FastAPI" in output

    def test_add_success(self, tmp_path: Path) -> None:
        with patch("prism.context.memory.ProjectMemory") as mock_cls:
            mock_mem = mock_cls.return_value
            _, output, _, _, _ = _cmd(
                "/memory add stack Python 3.12", tmp_path,
            )
        mock_mem.add_fact.assert_called_once_with("stack", "Python 3.12")
        assert "Saved" in output
        assert "stack" in output
        assert "Python 3.12" in output

    def test_add_missing_value(self, tmp_path: Path) -> None:
        """Usage error when value is omitted."""
        with patch("prism.context.memory.ProjectMemory"):
            _, output, _, _, _ = _cmd("/memory add mykey", tmp_path)
        assert "Usage" in output

    def test_add_missing_key_and_value(self, tmp_path: Path) -> None:
        with patch("prism.context.memory.ProjectMemory"):
            _, output, _, _, _ = _cmd("/memory add", tmp_path)
        assert "Usage" in output

    def test_remove_success(self, tmp_path: Path) -> None:
        with patch("prism.context.memory.ProjectMemory") as mock_cls:
            mock_mem = mock_cls.return_value
            mock_mem.remove_fact.return_value = True
            _, output, _, _, _ = _cmd("/memory remove stack", tmp_path)
        mock_mem.remove_fact.assert_called_once_with("stack")
        assert "Removed" in output
        assert "stack" in output

    def test_remove_key_not_found(self, tmp_path: Path) -> None:
        with patch("prism.context.memory.ProjectMemory") as mock_cls:
            mock_mem = mock_cls.return_value
            mock_mem.remove_fact.return_value = False
            _, output, _, _, _ = _cmd("/memory remove nope", tmp_path)
        assert "Key not found" in output
        assert "nope" in output

    def test_remove_missing_key(self, tmp_path: Path) -> None:
        with patch("prism.context.memory.ProjectMemory"):
            _, output, _, _, _ = _cmd("/memory remove", tmp_path)
        assert "Usage" in output

    def test_clear(self, tmp_path: Path) -> None:
        with patch("prism.context.memory.ProjectMemory") as mock_cls:
            mock_mem = mock_cls.return_value
            _, output, _, _, _ = _cmd("/memory clear", tmp_path)
        mock_mem.clear.assert_called_once()
        assert "cleared" in output.lower()

    def test_unknown_subcommand(self, tmp_path: Path) -> None:
        with patch("prism.context.memory.ProjectMemory"):
            _, output, _, _, _ = _cmd("/memory frobnicate", tmp_path)
        assert "Usage" in output

    def test_exception_handled(self, tmp_path: Path) -> None:
        """Import/runtime errors are caught gracefully."""
        with patch(
            "prism.context.memory.ProjectMemory",
            side_effect=OSError("disk full"),
        ):
            action, output, _, _, _ = _cmd("/memory show", tmp_path)
        assert action == "continue"
        assert "Error" in output
        assert "disk full" in output


# ======================================================================
# Permission Memory — _ask_permission, _should_auto_approve,
# _execute_tool_with_permission permission logic
# ======================================================================


class TestAskPermission:
    """Tests for _ask_permission returning 'deny', 'once', or 'always'."""

    def test_deny_on_no_input(self) -> None:
        """User pressing Enter (empty) should deny."""
        console = _make_console()
        with patch("builtins.input", return_value=""):
            result = _ask_permission("write_file", {}, "confirm", console)
        assert result == "deny"

    def test_once_on_yes_confirm(self) -> None:
        """'y' for a CONFIRM tool returns 'once'."""
        console = _make_console()
        with patch("builtins.input", return_value="y"):
            result = _ask_permission("write_file", {}, "confirm", console)
        assert result == "once"

    def test_always_on_a_confirm(self) -> None:
        """'a' for a CONFIRM tool returns 'always'."""
        console = _make_console()
        with patch("builtins.input", return_value="a"):
            result = _ask_permission("edit_file", {}, "confirm", console)
        assert result == "always"

    def test_always_on_always_word(self) -> None:
        """'always' word for a CONFIRM tool returns 'always'."""
        console = _make_console()
        with patch("builtins.input", return_value="always"):
            result = _ask_permission("edit_file", {}, "confirm", console)
        assert result == "always"

    def test_dangerous_no_always_option(self) -> None:
        """'a' for a DANGEROUS tool should deny (no always option)."""
        console = _make_console()
        with patch("builtins.input", return_value="a"):
            result = _ask_permission(
                "execute_command", {}, "DANGEROUS", console,
            )
        assert result == "deny"

    def test_dangerous_yes_returns_once(self) -> None:
        """'y' for a DANGEROUS tool returns 'once' (not 'always')."""
        console = _make_console()
        with patch("builtins.input", return_value="y"):
            result = _ask_permission(
                "execute_command", {}, "DANGEROUS", console,
            )
        assert result == "once"

    def test_deny_on_eof(self) -> None:
        """EOFError should be treated as deny."""
        console = _make_console()
        with patch("builtins.input", side_effect=EOFError):
            result = _ask_permission("write_file", {}, "confirm", console)
        assert result == "deny"

    def test_deny_on_keyboard_interrupt(self) -> None:
        """KeyboardInterrupt should be treated as deny."""
        console = _make_console()
        with patch("builtins.input", side_effect=KeyboardInterrupt):
            result = _ask_permission("write_file", {}, "confirm", console)
        assert result == "deny"

    def test_write_file_shows_details(self) -> None:
        """write_file permission prompt shows path and size."""
        console = _make_console()
        args = {"path": "/tmp/test.py", "content": "hello world"}
        with patch("builtins.input", return_value="n"):
            _ask_permission("write_file", args, "confirm", console)
        output = _get_output(console)
        assert "/tmp/test.py" in output
        assert "11" in output  # len("hello world")

    def test_edit_file_shows_path(self) -> None:
        """edit_file permission prompt shows path."""
        console = _make_console()
        args = {"path": "/tmp/main.py"}
        with patch("builtins.input", return_value="n"):
            _ask_permission("edit_file", args, "confirm", console)
        output = _get_output(console)
        assert "/tmp/main.py" in output

    def test_execute_command_shows_command(self) -> None:
        """execute_command permission prompt shows the command."""
        console = _make_console()
        args = {"command": "rm -rf /"}
        with patch("builtins.input", return_value="n"):
            _ask_permission("execute_command", args, "DANGEROUS", console)
        output = _get_output(console)
        assert "rm -rf /" in output

    def test_dangerous_label_shown(self) -> None:
        """DANGEROUS tools show a DANGEROUS label."""
        console = _make_console()
        with patch("builtins.input", return_value="n"):
            _ask_permission("execute_command", {}, "DANGEROUS", console)
        output = _get_output(console)
        assert "DANGEROUS" in output

    def test_confirm_label_shown(self) -> None:
        """CONFIRM tools show a Confirm label."""
        console = _make_console()
        with patch("builtins.input", return_value="n"):
            _ask_permission("write_file", {}, "confirm", console)
        output = _get_output(console)
        assert "Confirm" in output


class TestShouldAutoApprove:
    """Tests for the _should_auto_approve helper."""

    def test_tool_in_permission_cache(self) -> None:
        """Tools in the permission cache should be auto-approved."""
        state = _make_state()
        state.permission_cache.add("write_file")
        assert _should_auto_approve("write_file", state) is True

    def test_tool_not_in_cache(self) -> None:
        """Tools not in cache and no auto_approve should not be approved."""
        state = _make_state()
        assert _should_auto_approve("write_file", state) is False

    def test_settings_auto_approve_on(self, tmp_path: Path) -> None:
        """When settings.config.tools.auto_approve is True, approve."""
        state = _make_state()
        settings = _make_settings(tmp_path)
        settings._config.tools.auto_approve = True
        state.settings = settings
        assert _should_auto_approve("write_file", state) is True

    def test_settings_auto_approve_off(self, tmp_path: Path) -> None:
        """When settings.config.tools.auto_approve is False, deny."""
        state = _make_state()
        settings = _make_settings(tmp_path)
        settings._config.tools.auto_approve = False
        state.settings = settings
        assert _should_auto_approve("write_file", state) is False

    def test_no_settings_no_cache(self) -> None:
        """No settings and no cache should not auto-approve."""
        state = _make_state()
        state.settings = None
        assert _should_auto_approve("edit_file", state) is False

    def test_cache_takes_priority_over_settings(
        self, tmp_path: Path,
    ) -> None:
        """Permission cache should approve even if settings says no."""
        state = _make_state()
        settings = _make_settings(tmp_path)
        settings._config.tools.auto_approve = False
        state.settings = settings
        state.permission_cache.add("edit_file")
        assert _should_auto_approve("edit_file", state) is True


class TestPermissionMemoryIntegration:
    """Integration tests for permission memory in _execute_tool_with_permission."""

    def test_skip_all_permissions_bypasses_confirm(self) -> None:
        """--dangerously-skip-permissions bypasses CONFIRM tools."""
        from dataclasses import dataclass
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        @dataclass
        class FakeResult:
            success: bool
            output: str
            error: str | None

        tool = MagicMock()
        tool.permission_level = PermissionLevel.CONFIRM
        tool.execute.return_value = FakeResult(
            success=True, output="written ok", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        state = _make_state()
        state.skip_all_permissions = True

        result = _execute_tool_with_permission(
            "write_file",
            {"path": "/tmp/test.py", "content": "hi"},
            registry,
            console,
            state=state,
        )
        assert result == "written ok"
        # Should NOT have called input()
        assert "Permission denied" not in result

    def test_skip_all_permissions_bypasses_dangerous(self) -> None:
        """--dangerously-skip-permissions bypasses DANGEROUS tools too."""
        from dataclasses import dataclass
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        @dataclass
        class FakeResult:
            success: bool
            output: str
            error: str | None

        tool = MagicMock()
        tool.permission_level = PermissionLevel.DANGEROUS
        tool.execute.return_value = FakeResult(
            success=True, output="command ran", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        state = _make_state()
        state.skip_all_permissions = True

        result = _execute_tool_with_permission(
            "execute_command",
            {"command": "ls"},
            registry,
            console,
            state=state,
        )
        assert result == "command ran"

    def test_permission_cache_auto_approves_confirm(self) -> None:
        """A tool in the permission_cache skips the prompt for CONFIRM."""
        from dataclasses import dataclass
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        @dataclass
        class FakeResult:
            success: bool
            output: str
            error: str | None

        tool = MagicMock()
        tool.permission_level = PermissionLevel.CONFIRM
        tool.execute.return_value = FakeResult(
            success=True, output="edit done", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        state = _make_state()
        state.permission_cache.add("edit_file")

        result = _execute_tool_with_permission(
            "edit_file",
            {"path": "/tmp/test.py"},
            registry,
            console,
            state=state,
        )
        assert result == "edit done"
        # Auto-approve is silent — verify no permission prompt shown
        output = _get_output(console)
        assert "Confirm" not in output

    def test_permission_cache_does_not_auto_approve_dangerous(self) -> None:
        """DANGEROUS tools are never auto-approved even if in cache."""
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        tool = MagicMock()
        tool.permission_level = PermissionLevel.DANGEROUS
        tool.execute.return_value = MagicMock(
            success=True, output="ran", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        state = _make_state()
        state.permission_cache.add("execute_command")

        # Should still prompt because DANGEROUS
        with patch("builtins.input", return_value="n"):
            result = _execute_tool_with_permission(
                "execute_command",
                {"command": "rm -rf /"},
                registry,
                console,
                state=state,
            )
        assert "Permission denied" in result

    def test_always_response_adds_to_cache(self) -> None:
        """When user answers 'always', tool is added to permission_cache."""
        from dataclasses import dataclass
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        @dataclass
        class FakeResult:
            success: bool
            output: str
            error: str | None

        tool = MagicMock()
        tool.permission_level = PermissionLevel.CONFIRM
        tool.execute.return_value = FakeResult(
            success=True, output="written", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        state = _make_state()
        assert "write_file" not in state.permission_cache

        with patch("builtins.input", return_value="a"):
            result = _execute_tool_with_permission(
                "write_file",
                {"path": "/tmp/test.py", "content": "hi"},
                registry,
                console,
                state=state,
            )
        assert result == "written"
        assert "write_file" in state.permission_cache

    def test_once_response_does_not_add_to_cache(self) -> None:
        """When user answers 'y' (once), tool is NOT added to cache."""
        from dataclasses import dataclass
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        @dataclass
        class FakeResult:
            success: bool
            output: str
            error: str | None

        tool = MagicMock()
        tool.permission_level = PermissionLevel.CONFIRM
        tool.execute.return_value = FakeResult(
            success=True, output="written", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        state = _make_state()

        with patch("builtins.input", return_value="y"):
            result = _execute_tool_with_permission(
                "write_file",
                {"path": "/tmp/test.py", "content": "hi"},
                registry,
                console,
                state=state,
            )
        assert result == "written"
        assert "write_file" not in state.permission_cache

    def test_auto_approve_setting_skips_confirm(
        self, tmp_path: Path,
    ) -> None:
        """settings.config.tools.auto_approve skips CONFIRM tools."""
        from dataclasses import dataclass
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        @dataclass
        class FakeResult:
            success: bool
            output: str
            error: str | None

        tool = MagicMock()
        tool.permission_level = PermissionLevel.CONFIRM
        tool.execute.return_value = FakeResult(
            success=True, output="ok", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        state = _make_state()
        settings = _make_settings(tmp_path)
        settings._config.tools.auto_approve = True
        state.settings = settings

        result = _execute_tool_with_permission(
            "write_file",
            {"path": "/tmp/test.py", "content": "hi"},
            registry,
            console,
            state=state,
        )
        assert result == "ok"
        # Auto-approve is silent — verify no permission prompt shown
        output = _get_output(console)
        assert "Confirm" not in output

    def test_auto_approve_setting_does_not_skip_dangerous(
        self, tmp_path: Path,
    ) -> None:
        """settings.config.tools.auto_approve does NOT skip DANGEROUS."""
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        tool = MagicMock()
        tool.permission_level = PermissionLevel.DANGEROUS
        tool.execute.return_value = MagicMock(
            success=True, output="ran", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        state = _make_state()
        settings = _make_settings(tmp_path)
        settings._config.tools.auto_approve = True
        state.settings = settings

        # Should still prompt because DANGEROUS
        with patch("builtins.input", return_value="n"):
            result = _execute_tool_with_permission(
                "execute_command",
                {"command": "rm -rf /"},
                registry,
                console,
                state=state,
            )
        assert "Permission denied" in result

    def test_session_state_has_permission_fields(self) -> None:
        """_SessionState should have permission_cache and skip fields."""
        state = _SessionState(pinned_model=None)
        assert isinstance(state.permission_cache, set)
        assert len(state.permission_cache) == 0
        assert state.skip_all_permissions is False
        assert state.settings is None

    def test_deny_response_returns_permission_denied(self) -> None:
        """When user answers 'n', tool is not executed."""
        from unittest.mock import MagicMock

        from prism.tools.base import PermissionLevel

        tool = MagicMock()
        tool.permission_level = PermissionLevel.CONFIRM
        tool.execute.return_value = MagicMock(
            success=True, output="ok", error=None,
        )

        registry = MagicMock()
        registry.get_tool.return_value = tool
        console = _make_console()

        state = _make_state()

        with patch("builtins.input", return_value="n"):
            result = _execute_tool_with_permission(
                "write_file",
                {"path": "/tmp/test.py", "content": "hi"},
                registry,
                console,
                state=state,
            )
        assert "Permission denied" in result
        tool.execute.assert_not_called()


# ===========================================================================
# Gap 4: _maybe_escalate_model — smart model escalation for tool-use
# ===========================================================================


class TestMaybeEscalateModel:
    """Tests for the _maybe_escalate_model helper."""

    def _make_escalation_state(
        self,
        tmp_path: Path,
        *,
        escalate_on_tool_use: bool = True,
        model_info: object | None = None,
        available_models: list[object] | None = None,
    ) -> _SessionState:
        """Create a state wired for escalation tests."""
        from unittest.mock import MagicMock

        from prism.config.schema import PrismConfig, RoutingConfig

        routing = RoutingConfig(escalate_on_tool_use=escalate_on_tool_use)
        config = PrismConfig(prism_home=tmp_path / ".prism", routing=routing)
        settings = Settings(config=config, project_root=tmp_path)

        registry = MagicMock()
        registry.get_model_info.return_value = model_info
        registry.get_available_models.return_value = available_models or []

        state = _make_state()
        state.settings = settings
        state.registry = registry
        return state

    def test_returns_none_when_settings_missing(self) -> None:
        state = _make_state()
        state.settings = None
        state.registry = None
        result = _maybe_escalate_model("groq/mixtral-8x7b-32768", state)
        assert result is None

    def test_returns_none_when_registry_missing(self, tmp_path: Path) -> None:
        from prism.config.schema import PrismConfig
        state = _make_state()
        config = PrismConfig(prism_home=tmp_path / ".prism")
        state.settings = Settings(config=config, project_root=tmp_path)
        state.registry = None
        result = _maybe_escalate_model("groq/mixtral-8x7b-32768", state)
        assert result is None

    def test_returns_none_when_escalation_disabled(self, tmp_path: Path) -> None:
        state = self._make_escalation_state(
            tmp_path, escalate_on_tool_use=False,
        )
        result = _maybe_escalate_model("groq/mixtral-8x7b-32768", state)
        assert result is None

    def test_returns_none_for_medium_tier_model(self, tmp_path: Path) -> None:
        from prism.providers.base import ComplexityTier, ModelInfo
        model_info = ModelInfo(
            id="gpt-4o-mini",
            display_name="GPT-4o Mini",
            provider="openai",
            tier=ComplexityTier.MEDIUM,
            input_cost_per_1m=0.15,
            output_cost_per_1m=0.60,
            context_window=128_000,
            supports_tools=True,
        )
        state = self._make_escalation_state(
            tmp_path, model_info=model_info,
        )
        result = _maybe_escalate_model("gpt-4o-mini", state)
        assert result is None

    def test_returns_none_for_complex_tier_model(self, tmp_path: Path) -> None:
        from prism.providers.base import ComplexityTier, ModelInfo
        model_info = ModelInfo(
            id="gpt-4o",
            display_name="GPT-4o",
            provider="openai",
            tier=ComplexityTier.COMPLEX,
            input_cost_per_1m=2.50,
            output_cost_per_1m=10.00,
            context_window=128_000,
            supports_tools=True,
        )
        state = self._make_escalation_state(
            tmp_path, model_info=model_info,
        )
        result = _maybe_escalate_model("gpt-4o", state)
        assert result is None

    def test_escalates_simple_to_cheapest_medium(self, tmp_path: Path) -> None:
        from prism.providers.base import ComplexityTier, ModelInfo
        simple_model = ModelInfo(
            id="groq/mixtral-8x7b-32768",
            display_name="Mixtral 8x7B",
            provider="groq",
            tier=ComplexityTier.SIMPLE,
            input_cost_per_1m=0.24,
            output_cost_per_1m=0.24,
            context_window=32_768,
            supports_tools=True,
        )
        medium_model = ModelInfo(
            id="gpt-4o-mini",
            display_name="GPT-4o Mini",
            provider="openai",
            tier=ComplexityTier.MEDIUM,
            input_cost_per_1m=0.15,
            output_cost_per_1m=0.60,
            context_window=128_000,
            supports_tools=True,
        )
        expensive_model = ModelInfo(
            id="gpt-4o",
            display_name="GPT-4o",
            provider="openai",
            tier=ComplexityTier.COMPLEX,
            input_cost_per_1m=2.50,
            output_cost_per_1m=10.00,
            context_window=128_000,
            supports_tools=True,
        )
        state = self._make_escalation_state(
            tmp_path,
            model_info=simple_model,
            available_models=[medium_model, expensive_model],
        )
        result = _maybe_escalate_model("groq/mixtral-8x7b-32768", state)
        assert result == "gpt-4o-mini"

    def test_returns_none_when_no_tool_capable_medium(
        self, tmp_path: Path,
    ) -> None:
        from prism.providers.base import ComplexityTier, ModelInfo
        simple_model = ModelInfo(
            id="groq/mixtral-8x7b-32768",
            display_name="Mixtral 8x7B",
            provider="groq",
            tier=ComplexityTier.SIMPLE,
            input_cost_per_1m=0.24,
            output_cost_per_1m=0.24,
            context_window=32_768,
            supports_tools=True,
        )
        # Only simple-tier models available
        another_simple = ModelInfo(
            id="ollama/llama3.2:3b",
            display_name="Llama 3.2 3B",
            provider="ollama",
            tier=ComplexityTier.SIMPLE,
            input_cost_per_1m=0.00,
            output_cost_per_1m=0.00,
            context_window=32_768,
            supports_tools=False,
        )
        state = self._make_escalation_state(
            tmp_path,
            model_info=simple_model,
            available_models=[another_simple],
        )
        result = _maybe_escalate_model("groq/mixtral-8x7b-32768", state)
        assert result is None

    def test_returns_none_for_unknown_model(self, tmp_path: Path) -> None:
        """Unknown model (not in registry) should still try to escalate."""
        from prism.providers.base import ComplexityTier, ModelInfo
        medium_model = ModelInfo(
            id="gpt-4o-mini",
            display_name="GPT-4o Mini",
            provider="openai",
            tier=ComplexityTier.MEDIUM,
            input_cost_per_1m=0.15,
            output_cost_per_1m=0.60,
            context_window=128_000,
            supports_tools=True,
        )
        state = self._make_escalation_state(
            tmp_path,
            model_info=None,  # Unknown model
            available_models=[medium_model],
        )
        result = _maybe_escalate_model("some/unknown-model", state)
        # Should escalate because model is unknown (not confirmed medium/complex)
        assert result == "gpt-4o-mini"

    def test_skips_candidate_with_same_id(self, tmp_path: Path) -> None:
        from prism.providers.base import ComplexityTier, ModelInfo
        simple_model = ModelInfo(
            id="groq/mixtral-8x7b-32768",
            display_name="Mixtral 8x7B",
            provider="groq",
            tier=ComplexityTier.SIMPLE,
            input_cost_per_1m=0.24,
            output_cost_per_1m=0.24,
            context_window=32_768,
            supports_tools=True,
        )
        # The only medium model has the same id (edge case)
        same_id = ModelInfo(
            id="groq/mixtral-8x7b-32768",
            display_name="Mixtral Medium variant",
            provider="groq",
            tier=ComplexityTier.MEDIUM,
            input_cost_per_1m=0.50,
            output_cost_per_1m=0.50,
            context_window=32_768,
            supports_tools=True,
        )
        state = self._make_escalation_state(
            tmp_path,
            model_info=simple_model,
            available_models=[same_id],
        )
        result = _maybe_escalate_model("groq/mixtral-8x7b-32768", state)
        assert result is None


# ===========================================================================
# /swarm command tests
# ===========================================================================


class TestSwarmCommand:
    """Tests for the /swarm slash command."""

    def test_swarm_no_args_shows_usage(self, tmp_path: Path) -> None:
        action, output, *_ = _cmd("/swarm", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_swarm_status_shows_no_swarm(self, tmp_path: Path) -> None:
        action, output, *_ = _cmd("/swarm status", tmp_path)
        assert action == "continue"
        assert "No swarm execution in progress" in output

    def test_swarm_plan_no_goal_shows_usage(self, tmp_path: Path) -> None:
        action, output, *_ = _cmd("/swarm plan", tmp_path)
        assert action == "continue"
        assert "Usage" in output

    def test_swarm_plan_no_engine_shows_error(self, tmp_path: Path) -> None:
        state = _make_state()
        state.completion_engine = None
        state.registry = None
        action, output, *_ = _cmd(
            "/swarm plan build a REST API",
            tmp_path,
            state=state,
        )
        assert action == "continue"
        assert "requires initialized providers" in output

    def test_swarm_full_no_engine_shows_error(self, tmp_path: Path) -> None:
        state = _make_state()
        state.completion_engine = None
        state.registry = None
        action, output, *_ = _cmd(
            "/swarm build a full REST API with tests",
            tmp_path,
            state=state,
        )
        assert action == "continue"
        assert "requires initialized providers" in output

    def test_swarm_plan_invokes_orchestrator(self, tmp_path: Path) -> None:
        """Verify /swarm plan lazy-imports and calls decompose phases."""
        from unittest.mock import AsyncMock, MagicMock

        from prism.orchestrator.swarm import SwarmPlan, SwarmTask, TaskStatus

        mock_engine = MagicMock()
        mock_registry = MagicMock()

        state = _make_state()
        state.completion_engine = mock_engine
        state.registry = mock_registry

        # Build a mock plan to be returned by each phase
        mock_plan = SwarmPlan(goal="test goal")
        mock_plan.tasks = [
            SwarmTask(
                description="Step 1",
                complexity="simple",
                status=TaskStatus.PENDING,
            ),
        ]
        mock_plan.plan_text = "Plan text here"
        mock_plan.review_notes = "Looks good"
        mock_plan.phase_costs = {"decompose": 0.005, "plan": 0.010}
        mock_plan.total_cost = 0.015

        with patch(
            "prism.orchestrator.swarm.SwarmOrchestrator",
            autospec=False,
        ) as mock_orch_cls:
            mock_orch = MagicMock()
            mock_orch._phase_decompose = AsyncMock(return_value=mock_plan)
            mock_orch._phase_research = AsyncMock(return_value=mock_plan)
            mock_orch._phase_plan = AsyncMock(return_value=mock_plan)
            mock_orch._phase_review = AsyncMock(return_value=mock_plan)
            mock_orch_cls.return_value = mock_orch

            action, _output, *_ = _cmd(
                "/swarm plan build a REST API",
                tmp_path,
                state=state,
            )

        assert action == "continue"
        # Verify the orchestrator was instantiated with engine, registry, config, tool_registry
        mock_orch_cls.assert_called_once()
        call_kwargs = mock_orch_cls.call_args[1]
        assert call_kwargs["engine"] is mock_engine
        assert call_kwargs["registry"] is mock_registry
        assert call_kwargs["config"] is not None
        assert "tool_registry" in call_kwargs

    def test_swarm_full_invokes_orchestrate(self, tmp_path: Path) -> None:
        """Verify /swarm <goal> runs the full orchestration pipeline."""
        from unittest.mock import AsyncMock, MagicMock

        from prism.orchestrator.swarm import SwarmPlan, SwarmTask, TaskStatus

        mock_engine = MagicMock()
        mock_registry = MagicMock()

        state = _make_state()
        state.completion_engine = mock_engine
        state.registry = mock_registry

        mock_plan = SwarmPlan(goal="build it")
        mock_plan.tasks = [
            SwarmTask(
                description="Create module",
                complexity="medium",
                assigned_model="gpt-4o",
                status=TaskStatus.COMPLETED,
                result="Done",
            ),
        ]
        mock_plan.phase_costs = {"execute": 0.003}
        mock_plan.total_cost = 0.020

        with patch(
            "prism.orchestrator.swarm.SwarmOrchestrator",
            autospec=False,
        ) as mock_orch_cls:
            mock_orch = MagicMock()
            mock_orch.orchestrate = AsyncMock(return_value=mock_plan)
            mock_orch_cls.return_value = mock_orch

            action, output, *_ = _cmd(
                "/swarm build a REST API system",
                tmp_path,
                state=state,
            )

        assert action == "continue"
        mock_orch.orchestrate.assert_called_once_with("build a REST API system")
        assert "Swarm complete" in output

    def test_swarm_returns_continue(self, tmp_path: Path) -> None:
        action, _output, *_ = _cmd("/swarm", tmp_path)
        assert action == "continue"


# ===========================================================================
# _looks_like_swarm_task heuristic tests
# ===========================================================================


class TestLooksLikeSwarmTask:
    """Tests for the _looks_like_swarm_task heuristic."""

    def test_positive_build_and_components(self) -> None:
        assert _looks_like_swarm_task(
            "Build a REST API and database components"
        ) is True

    def test_positive_create_multiple_files(self) -> None:
        assert _looks_like_swarm_task(
            "Create multiple test files for the router module"
        ) is True

    def test_positive_implement_system(self) -> None:
        assert _looks_like_swarm_task(
            "Implement an auth system with login and logout"
        ) is True

    def test_positive_refactor_modules(self) -> None:
        assert _looks_like_swarm_task(
            "Refactor the modules to use dependency injection"
        ) is True

    def test_positive_develop_and_then(self) -> None:
        assert _looks_like_swarm_task(
            "Develop a CLI tool and then add tests"
        ) is True

    def test_positive_design_components(self) -> None:
        assert _looks_like_swarm_task(
            "Design the components for the new dashboard"
        ) is True

    def test_negative_simple_question(self) -> None:
        assert _looks_like_swarm_task(
            "What is the capital of France?"
        ) is False

    def test_negative_single_action(self) -> None:
        assert _looks_like_swarm_task(
            "Fix the bug in line 42"
        ) is False

    def test_negative_no_keywords(self) -> None:
        assert _looks_like_swarm_task(
            "Tell me about the weather and temperature"
        ) is False

    def test_negative_keyword_no_multi(self) -> None:
        assert _looks_like_swarm_task(
            "Build it"
        ) is False

    def test_negative_multi_no_keyword(self) -> None:
        assert _looks_like_swarm_task(
            "Show me the files and modules"
        ) is False

    def test_negative_empty_string(self) -> None:
        assert _looks_like_swarm_task("") is False


# ===========================================================================
# COMMAND_CATEGORIES: Multi-Agent category
# ===========================================================================


class TestMultiAgentCategory:
    """Tests for the Multi-Agent command category."""

    def test_has_multi_agent_category(self) -> None:
        assert "Multi-Agent" in COMMAND_CATEGORIES

    def test_multi_agent_has_swarm_commands(self) -> None:
        commands = COMMAND_CATEGORIES["Multi-Agent"]
        names = [c[0] for c in commands]
        assert "/swarm <goal>" in names
        assert "/swarm status" in names
        assert "/swarm plan <goal>" in names


# ===========================================================================
# _detect_fake_tool_use — auto-tool invocation detection
# ===========================================================================


class TestDetectFakeToolUse:
    """Tests for _detect_fake_tool_use auto-detection."""

    def setup_method(self) -> None:
        from prism.cli.repl import _detect_fake_tool_use
        self.detect = _detect_fake_tool_use

    def test_detects_ill_search_for(self) -> None:
        result = self.detect("I'll search for self evolving AI agents.")
        assert result is not None
        assert result[0] == "search_web"
        assert "self evolving" in result[1]["query"].lower()

    def test_detects_let_me_search(self) -> None:
        result = self.detect("Let me search for quantum computing breakthroughs.")
        assert result is not None
        assert result[0] == "search_web"

    def test_detects_search_web_function_call_text(self) -> None:
        result = self.detect("search_web(query='python async patterns')")
        assert result is not None
        assert result[0] == "search_web"
        assert "python async" in result[1]["query"]

    def test_detects_using_search_web(self) -> None:
        result = self.detect("I'll be using search_web to search for latest AI news.")
        assert result is not None
        assert result[0] == "search_web"

    def test_detects_browse_web_url(self) -> None:
        result = self.detect("I'll browse https://example.com/page to get info.")
        assert result is not None
        assert result[0] == "browse_web"
        assert result[1]["url"] == "https://example.com/page"

    def test_no_false_positive_normal_text(self) -> None:
        result = self.detect("The search feature works by indexing documents.")
        assert result is None

    def test_no_false_positive_code(self) -> None:
        result = self.detect("Here is a function that processes data:\ndef main():\n    pass")
        assert result is None

    def test_detects_quoted_search_topic(self) -> None:
        result = self.detect('Let me search for "machine learning optimizers" on the web.')
        assert result is not None
        assert result[0] == "search_web"
        assert "machine learning" in result[1]["query"]

    def test_detects_going_to_search(self) -> None:
        result = self.detect("I'm going to search the internet for LLM benchmarks.")
        assert result is not None
        assert result[0] == "search_web"

    def test_no_false_positive_short_query(self) -> None:
        """Queries shorter than 3 chars are ignored."""
        result = self.detect("I'll search for it.")
        assert result is None


# ===========================================================================
# _is_research_query — research intent detection
# ===========================================================================


class TestIsResearchQuery:
    """Tests for _is_research_query detection."""

    def setup_method(self) -> None:
        from prism.cli.repl import _is_research_query
        self.detect = _is_research_query

    def test_detects_research_keyword(self) -> None:
        assert self.detect("research self evolving AI agents") is True

    def test_detects_web_search(self) -> None:
        assert self.detect("do a web search on quantum computing") is True

    def test_detects_investigate(self) -> None:
        assert self.detect("investigate the latest LLM benchmarks") is True

    def test_detects_search_for(self) -> None:
        assert self.detect("search for recent papers on attention mechanisms") is True

    def test_no_false_positive_code(self) -> None:
        assert self.detect("fix the bug in main.py") is False

    def test_no_false_positive_greeting(self) -> None:
        assert self.detect("hello how are you") is False

    def test_detects_find_out(self) -> None:
        assert self.detect("find out what the best practices are for REST APIs") is True

    def test_detects_compare(self) -> None:
        assert self.detect("compare React vs Vue frameworks") is True


# ===========================================================================
# Rate-limit cooldown memory
# ===========================================================================


class TestRateLimitCooldown:
    """Tests for provider rate-limit memory."""

    def setup_method(self) -> None:
        from prism.cli import repl
        self.repl = repl
        # Clear cooldown state between tests
        repl._RATE_LIMIT_COOLDOWN.clear()

    def test_fresh_model_is_cooled_down(self) -> None:
        assert self.repl._is_cooled_down("groq/llama") is True

    def test_marked_model_not_cooled_down(self) -> None:
        self.repl._mark_rate_limited("groq/llama")
        assert self.repl._is_cooled_down("groq/llama") is False

    def test_cooldown_expires(self) -> None:
        import time
        self.repl._mark_rate_limited("groq/llama")
        # Simulate time passing by backdating the entry
        self.repl._RATE_LIMIT_COOLDOWN["groq/llama"] = (
            time.monotonic() - 120.0
        )
        assert self.repl._is_cooled_down("groq/llama") is True

    def test_pick_model_skips_rate_limited(self, monkeypatch: Any) -> None:
        """_pick_repl_model should skip rate-limited models."""
        # Clear all provider keys to isolate the test
        for key in (
            "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GOOGLE_API_KEY",
            "GEMINI_API_KEY", "VERTEXAI_PROJECT", "DEEPSEEK_API_KEY",
            "OPENROUTER_API_KEY",
        ):
            monkeypatch.delenv(key, raising=False)
        monkeypatch.setenv("GROQ_API_KEY", "test")
        monkeypatch.setenv("MISTRAL_API_KEY", "test")
        self.repl._RATE_LIMIT_COOLDOWN.clear()

        # Without rate limit, groq comes first (only groq+mistral set)
        models = self.repl._get_available_models()
        assert models[0] == "groq/llama-3.3-70b-versatile"

        # After marking groq rate-limited, mistral comes first
        self.repl._mark_rate_limited("groq/llama-3.3-70b-versatile")
        models = self.repl._get_available_models()
        assert models[0] == "mistral/mistral-small-latest"
        # Groq should still be in the list, just at the end
        assert "groq/llama-3.3-70b-versatile" in models
