"""Tests for tool composition primitives — sequence, parallel, branch, retry, loop."""

from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import AsyncMock

import pytest

from prism.tools.composer import (
    Branch,
    ChainContext,
    ChainResult,
    ComposableNode,
    Loop,
    Parallel,
    Retry,
    Sequence,
    Step,
    StepResult,
    StepStatus,
)

# =====================================================================
# Helpers — mock executors
# =====================================================================


def make_executor(return_value: Any = "ok") -> AsyncMock:
    """Create a mock executor that returns a fixed value."""
    return AsyncMock(return_value=return_value)


def make_failing_executor(error: str = "boom") -> AsyncMock:
    """Create a mock executor that raises an exception."""
    return AsyncMock(side_effect=RuntimeError(error))


def make_slow_executor(delay: float, return_value: Any = "slow_ok") -> AsyncMock:
    """Create a mock executor that sleeps before returning."""
    async def _slow(_tool: str, _args: dict) -> Any:
        await asyncio.sleep(delay)
        return return_value
    return AsyncMock(side_effect=_slow)


def make_counting_executor() -> tuple[AsyncMock, dict[str, int]]:
    """Create a mock executor that counts invocations and returns the count."""
    state: dict[str, int] = {"calls": 0}

    async def _counting(_tool: str, _args: dict) -> int:
        state["calls"] += 1
        return state["calls"]

    return AsyncMock(side_effect=_counting), state


def make_flaky_executor(
    fail_count: int, return_value: Any = "recovered"
) -> AsyncMock:
    """Create a mock executor that fails N times then succeeds."""
    state = {"attempts": 0}

    async def _flaky(_tool: str, _args: dict) -> Any:
        state["attempts"] += 1
        if state["attempts"] <= fail_count:
            raise RuntimeError(f"attempt {state['attempts']} failed")
        return return_value

    return AsyncMock(side_effect=_flaky)


def make_context(
    executor: Any = None,
    variables: dict[str, Any] | None = None,
    step_outputs: dict[str, Any] | None = None,
) -> ChainContext:
    """Create a ChainContext with the given executor and optional state."""
    return ChainContext(
        executor=executor,
        variables=variables or {},
        step_outputs=step_outputs or {},
    )


# =====================================================================
# StepStatus
# =====================================================================


class TestStepStatus:
    """Tests for the StepStatus enum."""

    def test_values(self) -> None:
        assert StepStatus.PENDING.value == "pending"
        assert StepStatus.RUNNING.value == "running"
        assert StepStatus.SUCCESS.value == "success"
        assert StepStatus.FAILED.value == "failed"
        assert StepStatus.SKIPPED.value == "skipped"
        assert StepStatus.TIMEOUT.value == "timeout"

    def test_all_members(self) -> None:
        assert set(StepStatus.__members__) == {
            "PENDING",
            "RUNNING",
            "SUCCESS",
            "FAILED",
            "SKIPPED",
            "TIMEOUT",
        }


# =====================================================================
# StepResult
# =====================================================================


class TestStepResult:
    """Tests for the StepResult dataclass."""

    def test_succeeded_true(self) -> None:
        result = StepResult(step_name="s", status=StepStatus.SUCCESS, output="ok")
        assert result.succeeded is True

    def test_succeeded_false_for_failed(self) -> None:
        result = StepResult(step_name="s", status=StepStatus.FAILED, error="err")
        assert result.succeeded is False

    def test_succeeded_false_for_timeout(self) -> None:
        result = StepResult(step_name="s", status=StepStatus.TIMEOUT)
        assert result.succeeded is False

    def test_succeeded_false_for_skipped(self) -> None:
        result = StepResult(step_name="s", status=StepStatus.SKIPPED)
        assert result.succeeded is False

    def test_succeeded_false_for_pending(self) -> None:
        result = StepResult(step_name="s", status=StepStatus.PENDING)
        assert result.succeeded is False

    def test_defaults(self) -> None:
        result = StepResult(step_name="x", status=StepStatus.SUCCESS)
        assert result.output is None
        assert result.error == ""
        assert result.duration_ms == 0.0
        assert result.metadata == {}

    def test_metadata_not_shared_across_instances(self) -> None:
        r1 = StepResult(step_name="a", status=StepStatus.SUCCESS)
        r2 = StepResult(step_name="b", status=StepStatus.SUCCESS)
        r1.metadata["key"] = "val"
        assert "key" not in r2.metadata


# =====================================================================
# ChainResult
# =====================================================================


class TestChainResult:
    """Tests for the ChainResult dataclass."""

    def test_last_output_from_successful_step(self) -> None:
        steps = [
            StepResult(step_name="a", status=StepStatus.SUCCESS, output="first"),
            StepResult(step_name="b", status=StepStatus.SUCCESS, output="second"),
        ]
        cr = ChainResult(chain_name="c", steps=steps, total_duration_ms=10, success=True)
        assert cr.last_output == "second"

    def test_last_output_skips_failed(self) -> None:
        steps = [
            StepResult(step_name="a", status=StepStatus.SUCCESS, output="first"),
            StepResult(step_name="b", status=StepStatus.FAILED, output=None),
        ]
        cr = ChainResult(chain_name="c", steps=steps, total_duration_ms=10, success=False)
        assert cr.last_output == "first"

    def test_last_output_skips_none_output(self) -> None:
        steps = [
            StepResult(step_name="a", status=StepStatus.SUCCESS, output="first"),
            StepResult(step_name="b", status=StepStatus.SUCCESS, output=None),
        ]
        cr = ChainResult(chain_name="c", steps=steps, total_duration_ms=10, success=True)
        assert cr.last_output == "first"

    def test_last_output_none_when_no_successes(self) -> None:
        steps = [
            StepResult(step_name="a", status=StepStatus.FAILED, output=None),
        ]
        cr = ChainResult(chain_name="c", steps=steps, total_duration_ms=10, success=False)
        assert cr.last_output is None

    def test_last_output_none_when_empty(self) -> None:
        cr = ChainResult(chain_name="c", steps=[], total_duration_ms=0, success=True)
        assert cr.last_output is None

    def test_all_outputs(self) -> None:
        steps = [
            StepResult(step_name="a", status=StepStatus.SUCCESS, output="A"),
            StepResult(step_name="b", status=StepStatus.FAILED, output=None),
            StepResult(step_name="c", status=StepStatus.SUCCESS, output="C"),
        ]
        cr = ChainResult(chain_name="chain", steps=steps, total_duration_ms=10, success=False)
        assert cr.all_outputs == {"a": "A", "c": "C"}

    def test_all_outputs_empty(self) -> None:
        cr = ChainResult(chain_name="chain", steps=[], total_duration_ms=0, success=True)
        assert cr.all_outputs == {}


# =====================================================================
# ChainContext
# =====================================================================


class TestChainContext:
    """Tests for ChainContext get/set and step_outputs."""

    def test_get_from_variables(self) -> None:
        ctx = ChainContext(variables={"key": "val"})
        assert ctx.get("key") == "val"

    def test_get_from_step_outputs(self) -> None:
        ctx = ChainContext(step_outputs={"step1": "output1"})
        assert ctx.get("step1") == "output1"

    def test_get_prefers_variables_over_step_outputs(self) -> None:
        ctx = ChainContext(variables={"k": "from_var"}, step_outputs={"k": "from_step"})
        assert ctx.get("k") == "from_var"

    def test_get_default(self) -> None:
        ctx = ChainContext()
        assert ctx.get("missing", "fallback") == "fallback"

    def test_get_default_none(self) -> None:
        ctx = ChainContext()
        assert ctx.get("missing") is None

    def test_set(self) -> None:
        ctx = ChainContext()
        ctx.set("x", 42)
        assert ctx.variables["x"] == 42
        assert ctx.get("x") == 42

    def test_set_overwrites(self) -> None:
        ctx = ChainContext(variables={"x": 1})
        ctx.set("x", 2)
        assert ctx.get("x") == 2

    def test_step_outputs_dict(self) -> None:
        ctx = ChainContext()
        ctx.step_outputs["s1"] = "out1"
        ctx.step_outputs["s2"] = "out2"
        assert ctx.step_outputs == {"s1": "out1", "s2": "out2"}

    def test_default_executor_is_none(self) -> None:
        ctx = ChainContext()
        assert ctx.executor is None


# =====================================================================
# ComposableNode base
# =====================================================================


class TestComposableNode:
    """Tests for the ComposableNode base class."""

    async def test_execute_raises_not_implemented(self) -> None:
        node = ComposableNode("base")
        with pytest.raises(NotImplementedError):
            await node.execute(ChainContext())

    def test_name(self) -> None:
        node = ComposableNode("test_name")
        assert node.name == "test_name"


# =====================================================================
# Step execution
# =====================================================================


class TestStep:
    """Tests for single Step execution."""

    async def test_success(self) -> None:
        executor = make_executor("result_data")
        ctx = make_context(executor=executor)
        step = Step("s1", tool="mytool", args={"a": 1})

        result = await step.execute(ctx)

        assert result.succeeded
        assert result.status == StepStatus.SUCCESS
        assert result.output == "result_data"
        assert result.step_name == "s1"
        assert result.duration_ms > 0
        assert result.error == ""
        executor.assert_awaited_once_with("mytool", {"a": 1})

    async def test_success_stores_in_context(self) -> None:
        executor = make_executor("stored")
        ctx = make_context(executor=executor)
        step = Step("s1", tool="t")

        await step.execute(ctx)

        assert ctx.step_outputs["s1"] == "stored"

    async def test_no_executor(self) -> None:
        ctx = make_context(executor=None)
        step = Step("s1", tool="t")

        result = await step.execute(ctx)

        assert not result.succeeded
        assert result.status == StepStatus.FAILED
        assert "No executor configured" in result.error

    async def test_executor_raises(self) -> None:
        executor = make_failing_executor("something broke")
        ctx = make_context(executor=executor)
        step = Step("s1", tool="t")

        result = await step.execute(ctx)

        assert not result.succeeded
        assert result.status == StepStatus.FAILED
        assert "something broke" in result.error
        assert result.duration_ms >= 0

    async def test_timeout(self) -> None:
        executor = make_slow_executor(delay=5.0)
        ctx = make_context(executor=executor)
        step = Step("s1", tool="t", timeout_ms=50)

        result = await step.execute(ctx)

        assert not result.succeeded
        assert result.status == StepStatus.TIMEOUT
        assert "timed out" in result.error

    async def test_variable_resolution(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor, variables={"myvar": "resolved_val"})
        step = Step("s1", tool="t", args={"param": "${myvar}", "literal": "keep"})

        await step.execute(ctx)

        call_args = executor.call_args[0]
        assert call_args[1]["param"] == "resolved_val"
        assert call_args[1]["literal"] == "keep"

    async def test_variable_resolution_from_step_outputs(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor, step_outputs={"prev": "prev_output"})
        step = Step("s1", tool="t", args={"data": "${prev}"})

        await step.execute(ctx)

        call_args = executor.call_args[0]
        assert call_args[1]["data"] == "prev_output"

    async def test_variable_resolution_unresolved_kept(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)
        step = Step("s1", tool="t", args={"data": "${missing}"})

        await step.execute(ctx)

        call_args = executor.call_args[0]
        assert call_args[1]["data"] == "${missing}"

    async def test_transform(self) -> None:
        executor = make_executor(10)
        ctx = make_context(executor=executor)
        step = Step("s1", tool="t", transform=lambda x: x * 2)

        result = await step.execute(ctx)

        assert result.succeeded
        assert result.output == 20
        assert ctx.step_outputs["s1"] == 20

    async def test_default_args_empty(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)
        step = Step("s1", tool="t")

        await step.execute(ctx)

        call_args = executor.call_args[0]
        assert call_args[1] == {}

    async def test_non_string_args_not_resolved(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor, variables={"x": 99})
        step = Step("s1", tool="t", args={"num": 42, "flag": True})

        await step.execute(ctx)

        call_args = executor.call_args[0]
        assert call_args[1] == {"num": 42, "flag": True}


# =====================================================================
# Sequence execution
# =====================================================================


class TestSequence:
    """Tests for Sequence (sequential execution of steps)."""

    async def test_all_steps_succeed(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)

        seq = (
            Sequence("seq")
            .then(Step("a", tool="t1"))
            .then(Step("b", tool="t2"))
            .then(Step("c", tool="t3"))
        )

        result = await seq.execute(ctx)

        assert result.succeeded
        assert result.status == StepStatus.SUCCESS
        assert result.metadata["step_count"] == 3
        assert len(result.output) == 3
        assert all(r.succeeded for r in result.output)

    async def test_stop_on_failure_default(self) -> None:
        call_count = {"n": 0}

        async def _executor(tool: str, args: dict) -> Any:
            call_count["n"] += 1
            if tool == "fail_tool":
                raise RuntimeError("fail")
            return "ok"

        ctx = make_context(executor=AsyncMock(side_effect=_executor))

        seq = (
            Sequence("seq")
            .then(Step("a", tool="ok_tool"))
            .then(Step("b", tool="fail_tool"))
            .then(Step("c", tool="ok_tool"))
        )

        result = await seq.execute(ctx)

        assert not result.succeeded
        assert result.status == StepStatus.FAILED
        # Step c should not have run
        assert result.metadata["step_count"] == 2
        assert len(result.output) == 2

    async def test_stop_on_failure_false(self) -> None:
        async def _executor(tool: str, args: dict) -> Any:
            if tool == "fail_tool":
                raise RuntimeError("fail")
            return "ok"

        ctx = make_context(executor=AsyncMock(side_effect=_executor))

        seq = (
            Sequence("seq", stop_on_failure=False)
            .then(Step("a", tool="ok_tool"))
            .then(Step("b", tool="fail_tool"))
            .then(Step("c", tool="ok_tool"))
        )

        result = await seq.execute(ctx)

        assert not result.succeeded  # not all succeeded
        assert result.metadata["step_count"] == 3
        assert len(result.output) == 3
        assert result.output[0].succeeded
        assert not result.output[1].succeeded
        assert result.output[2].succeeded

    async def test_empty_sequence(self) -> None:
        ctx = make_context(executor=make_executor("ok"))
        seq = Sequence("empty")

        result = await seq.execute(ctx)

        assert result.succeeded  # all() of empty is True
        assert result.output == []
        assert result.metadata["step_count"] == 0

    async def test_then_returns_self(self) -> None:
        seq = Sequence("s")
        returned = seq.then(Step("a", tool="t"))
        assert returned is seq

    async def test_steps_property(self) -> None:
        step1 = Step("a", tool="t")
        step2 = Step("b", tool="t")
        seq = Sequence("s").then(step1).then(step2)
        assert len(seq.steps) == 2
        assert seq.steps[0] is step1
        assert seq.steps[1] is step2

    async def test_steps_property_returns_copy(self) -> None:
        seq = Sequence("s").then(Step("a", tool="t"))
        steps = seq.steps
        steps.append(Step("b", tool="t"))
        assert len(seq.steps) == 1  # original unchanged

    async def test_duration_is_positive(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)
        seq = Sequence("s").then(Step("a", tool="t"))

        result = await seq.execute(ctx)

        assert result.duration_ms > 0

    async def test_context_flows_between_steps(self) -> None:
        """Earlier step outputs are available to later steps via variable resolution."""
        call_log: list[dict] = []

        async def _executor(tool: str, args: dict) -> Any:
            call_log.append({"tool": tool, "args": args})
            return f"output_of_{tool}"

        ctx = make_context(executor=AsyncMock(side_effect=_executor))

        seq = (
            Sequence("seq")
            .then(Step("first", tool="tool1"))
            .then(Step("second", tool="tool2", args={"prev": "${first}"}))
        )

        await seq.execute(ctx)

        assert call_log[1]["args"]["prev"] == "output_of_tool1"


# =====================================================================
# Parallel execution
# =====================================================================


class TestParallel:
    """Tests for Parallel (concurrent execution of steps)."""

    async def test_all_succeed(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)

        par = (
            Parallel("par")
            .add(Step("a", tool="t"))
            .add(Step("b", tool="t"))
            .add(Step("c", tool="t"))
        )

        result = await par.execute(ctx)

        assert result.succeeded
        assert result.status == StepStatus.SUCCESS
        assert result.metadata["parallel_count"] == 3
        assert len(result.output) == 3

    async def test_partial_failure_default_require_all_false(self) -> None:
        async def _executor(tool: str, args: dict) -> Any:
            if tool == "bad":
                raise RuntimeError("fail")
            return "ok"

        ctx = make_context(executor=AsyncMock(side_effect=_executor))

        par = (
            Parallel("par")
            .add(Step("a", tool="good"))
            .add(Step("b", tool="bad"))
        )

        result = await par.execute(ctx)

        # Default require_all=False: succeeds if any succeed
        assert result.succeeded
        assert result.status == StepStatus.SUCCESS

    async def test_partial_failure_require_all_true(self) -> None:
        async def _executor(tool: str, args: dict) -> Any:
            if tool == "bad":
                raise RuntimeError("fail")
            return "ok"

        ctx = make_context(executor=AsyncMock(side_effect=_executor))

        par = (
            Parallel("par", require_all=True)
            .add(Step("a", tool="good"))
            .add(Step("b", tool="bad"))
        )

        result = await par.execute(ctx)

        assert not result.succeeded
        assert result.status == StepStatus.FAILED

    async def test_all_fail_require_all_false(self) -> None:
        executor = make_failing_executor("fail")
        ctx = make_context(executor=executor)

        par = (
            Parallel("par", require_all=False)
            .add(Step("a", tool="t"))
            .add(Step("b", tool="t"))
        )

        result = await par.execute(ctx)

        # No successes, so even with require_all=False this fails
        assert not result.succeeded
        assert result.status == StepStatus.FAILED

    async def test_add_returns_self(self) -> None:
        par = Parallel("p")
        returned = par.add(Step("a", tool="t"))
        assert returned is par

    async def test_empty_parallel(self) -> None:
        ctx = make_context(executor=make_executor("ok"))
        par = Parallel("empty")

        result = await par.execute(ctx)

        # No steps: any() of empty is False
        assert not result.succeeded
        assert result.metadata["parallel_count"] == 0

    async def test_empty_parallel_require_all(self) -> None:
        ctx = make_context(executor=make_executor("ok"))
        par = Parallel("empty", require_all=True)

        result = await par.execute(ctx)

        # all() of empty is True
        assert result.succeeded

    async def test_exception_in_step_becomes_failed_result(self) -> None:
        """If a step raises an exception caught by gather, it becomes a FAILED StepResult."""
        # We need a step whose execute() itself raises (not caught internally).
        # Step.execute() catches all exceptions, so we make a custom node.

        class ExplodingNode(ComposableNode):
            async def execute(self, context: ChainContext) -> StepResult:
                raise RuntimeError("exploded")

        ctx = make_context(executor=make_executor("ok"))
        par = Parallel("par").add(ExplodingNode("boom"))

        result = await par.execute(ctx)

        assert result.output[0].status == StepStatus.FAILED
        assert "exploded" in result.output[0].error

    async def test_concurrent_execution(self) -> None:
        """Verify steps actually run concurrently, not sequentially."""
        start_times: list[float] = []

        async def _executor(tool: str, args: dict) -> str:
            import time as _time
            start_times.append(_time.monotonic())
            await asyncio.sleep(0.05)
            return "done"

        ctx = make_context(executor=AsyncMock(side_effect=_executor))

        par = (
            Parallel("par")
            .add(Step("a", tool="t"))
            .add(Step("b", tool="t"))
            .add(Step("c", tool="t"))
        )

        await par.execute(ctx)

        # All three should have started within ~10ms of each other if concurrent
        assert len(start_times) == 3
        spread = max(start_times) - min(start_times)
        assert spread < 0.04  # well under the 50ms each task sleeps


# =====================================================================
# Branch execution
# =====================================================================


class TestBranch:
    """Tests for Branch (conditional execution)."""

    async def test_condition_true_runs_on_success(self) -> None:
        executor = make_executor("success_path")
        ctx = make_context(executor=executor)

        branch = (
            Branch("br", condition=lambda _ctx: True)
            .on_success(Step("yes", tool="t"))
            .on_failure(Step("no", tool="t"))
        )

        result = await branch.execute(ctx)

        assert result.succeeded
        assert result.output == "success_path"
        assert result.metadata["condition"] is True
        assert result.metadata["branch"] == "success"
        assert result.metadata["executed_step"] == "yes"

    async def test_condition_false_runs_on_failure(self) -> None:
        executor = make_executor("failure_path")
        ctx = make_context(executor=executor)

        branch = (
            Branch("br", condition=lambda _ctx: False)
            .on_success(Step("yes", tool="t"))
            .on_failure(Step("no", tool="t"))
        )

        result = await branch.execute(ctx)

        assert result.succeeded
        assert result.output == "failure_path"
        assert result.metadata["condition"] is False
        assert result.metadata["branch"] == "failure"
        assert result.metadata["executed_step"] == "no"

    async def test_no_condition_truthy_last_output(self) -> None:
        """Without a condition, branches based on last step output truthiness."""
        executor = make_executor("yes_result")
        ctx = make_context(executor=executor, step_outputs={"prev": "truthy_value"})

        branch = (
            Branch("br")
            .on_success(Step("yes", tool="t"))
            .on_failure(Step("no", tool="t"))
        )

        result = await branch.execute(ctx)

        assert result.metadata["condition"] is True
        assert result.metadata["branch"] == "success"

    async def test_no_condition_falsy_last_output(self) -> None:
        executor = make_executor("no_result")
        ctx = make_context(executor=executor, step_outputs={"prev": ""})

        branch = (
            Branch("br")
            .on_success(Step("yes", tool="t"))
            .on_failure(Step("no", tool="t"))
        )

        result = await branch.execute(ctx)

        assert result.metadata["condition"] is False
        assert result.metadata["branch"] == "failure"

    async def test_no_condition_no_previous_output(self) -> None:
        executor = make_executor("no_result")
        ctx = make_context(executor=executor)

        branch = (
            Branch("br")
            .on_success(Step("yes", tool="t"))
            .on_failure(Step("no", tool="t"))
        )

        result = await branch.execute(ctx)

        # Empty step_outputs -> condition is False
        assert result.metadata["condition"] is False
        assert result.metadata["branch"] == "failure"

    async def test_no_branch_configured_skipped(self) -> None:
        ctx = make_context(executor=make_executor("ok"))

        # condition=True but no on_success configured
        branch = Branch("br", condition=lambda _ctx: True)

        result = await branch.execute(ctx)

        assert result.status == StepStatus.SKIPPED
        assert result.metadata["branch"] == "none"

    async def test_only_on_success_configured_condition_false(self) -> None:
        ctx = make_context(executor=make_executor("ok"))

        branch = Branch("br", condition=lambda _ctx: False).on_success(
            Step("yes", tool="t")
        )

        result = await branch.execute(ctx)

        assert result.status == StepStatus.SKIPPED
        assert result.metadata["condition"] is False
        assert result.metadata["branch"] == "none"

    async def test_only_on_failure_configured_condition_true(self) -> None:
        ctx = make_context(executor=make_executor("ok"))

        branch = Branch("br", condition=lambda _ctx: True).on_failure(
            Step("no", tool="t")
        )

        result = await branch.execute(ctx)

        assert result.status == StepStatus.SKIPPED
        assert result.metadata["condition"] is True
        assert result.metadata["branch"] == "none"

    async def test_condition_exception_treated_as_false(self) -> None:
        executor = make_executor("failure_path")
        ctx = make_context(executor=executor)

        def _bad_condition(_ctx: ChainContext) -> bool:
            raise ValueError("condition error")

        branch = (
            Branch("br", condition=_bad_condition)
            .on_success(Step("yes", tool="t"))
            .on_failure(Step("no", tool="t"))
        )

        result = await branch.execute(ctx)

        assert result.metadata["condition"] is False
        assert result.metadata["branch"] == "failure"

    async def test_on_success_returns_self(self) -> None:
        branch = Branch("br")
        returned = branch.on_success(Step("s", tool="t"))
        assert returned is branch

    async def test_on_failure_returns_self(self) -> None:
        branch = Branch("br")
        returned = branch.on_failure(Step("s", tool="t"))
        assert returned is branch

    async def test_branch_propagates_step_error(self) -> None:
        executor = make_failing_executor("inner_error")
        ctx = make_context(executor=executor)

        branch = Branch("br", condition=lambda _ctx: True).on_success(
            Step("yes", tool="t")
        )

        result = await branch.execute(ctx)

        assert result.status == StepStatus.FAILED
        assert "inner_error" in result.error

    async def test_condition_uses_context(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor, variables={"flag": True})

        branch = (
            Branch("br", condition=lambda c: c.get("flag"))
            .on_success(Step("yes", tool="t"))
            .on_failure(Step("no", tool="t"))
        )

        result = await branch.execute(ctx)

        assert result.metadata["condition"] is True
        assert result.metadata["branch"] == "success"


# =====================================================================
# Retry execution
# =====================================================================


class TestRetry:
    """Tests for Retry (retry on failure with backoff)."""

    async def test_succeed_first_try(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")
        retry = Retry("r", step=step, max_retries=3, backoff_ms=1)

        result = await retry.execute(ctx)

        assert result.succeeded
        assert result.metadata["attempts"] == 1
        assert result.output == "ok"

    async def test_succeed_after_retries(self) -> None:
        executor = make_flaky_executor(fail_count=2, return_value="recovered")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")
        retry = Retry("r", step=step, max_retries=3, backoff_ms=1, backoff_multiplier=1)

        result = await retry.execute(ctx)

        assert result.succeeded
        assert result.metadata["attempts"] == 3  # 2 fails + 1 success

    async def test_max_retries_exceeded(self) -> None:
        executor = make_failing_executor("always_fail")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")
        retry = Retry("r", step=step, max_retries=2, backoff_ms=1, backoff_multiplier=1)

        result = await retry.execute(ctx)

        assert not result.succeeded
        assert result.status == StepStatus.FAILED
        assert result.metadata["attempts"] == 3  # initial + 2 retries

    async def test_zero_retries(self) -> None:
        executor = make_failing_executor("fail")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")
        retry = Retry("r", step=step, max_retries=0, backoff_ms=1)

        result = await retry.execute(ctx)

        assert not result.succeeded
        assert result.metadata["attempts"] == 1

    async def test_backoff_multiplier(self) -> None:
        """Verify backoff increases exponentially."""
        sleep_durations: list[float] = []
        original_sleep = asyncio.sleep

        async def _mock_sleep(duration: float) -> None:
            sleep_durations.append(duration)
            # Don't actually sleep for the full duration
            await original_sleep(0)

        executor = make_failing_executor("always_fail")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")
        retry = Retry(
            "r", step=step, max_retries=3, backoff_ms=100, backoff_multiplier=2.0
        )

        import unittest.mock
        with unittest.mock.patch("prism.tools.composer.asyncio.sleep", side_effect=_mock_sleep):
            await retry.execute(ctx)

        # 3 retries -> 3 sleeps
        assert len(sleep_durations) == 3
        assert sleep_durations[0] == pytest.approx(0.1, abs=0.01)   # 100ms
        assert sleep_durations[1] == pytest.approx(0.2, abs=0.01)   # 200ms
        assert sleep_durations[2] == pytest.approx(0.4, abs=0.01)   # 400ms

    async def test_duration_accounts_for_all_attempts(self) -> None:
        executor = make_flaky_executor(fail_count=1, return_value="ok")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")
        retry = Retry("r", step=step, max_retries=2, backoff_ms=1, backoff_multiplier=1)

        result = await retry.execute(ctx)

        assert result.duration_ms > 0


# =====================================================================
# Loop execution
# =====================================================================


class TestLoop:
    """Tests for Loop (repeat until condition)."""

    async def test_condition_met_stops_loop(self) -> None:
        executor, _state = make_counting_executor()
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")

        loop = Loop(
            "loop",
            step=step,
            condition=lambda c: c.get("s") == 3,  # stop when count reaches 3
            max_iterations=10,
        )

        result = await loop.execute(ctx)

        assert result.succeeded
        assert result.metadata["iterations"] == 3
        assert len(result.output) == 3

    async def test_max_iterations_limit(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")

        loop = Loop(
            "loop",
            step=step,
            condition=lambda _ctx: False,  # never true -> hits max
            max_iterations=5,
        )

        result = await loop.execute(ctx)

        assert result.succeeded  # all iterations succeeded
        assert result.metadata["iterations"] == 5

    async def test_failure_stops_loop(self) -> None:
        call_count = {"n": 0}

        async def _executor(tool: str, args: dict) -> Any:
            call_count["n"] += 1
            if call_count["n"] == 3:
                raise RuntimeError("fail on third")
            return "ok"

        ctx = make_context(executor=AsyncMock(side_effect=_executor))
        step = Step("s", tool="t")

        loop = Loop(
            "loop",
            step=step,
            condition=lambda _ctx: False,
            max_iterations=10,
        )

        result = await loop.execute(ctx)

        assert not result.succeeded
        assert result.status == StepStatus.FAILED
        assert result.metadata["iterations"] == 3
        # First two succeeded, third failed
        assert result.output[0].succeeded
        assert result.output[1].succeeded
        assert not result.output[2].succeeded

    async def test_condition_exception_stops_loop(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")

        call_count = {"n": 0}

        def _bad_condition(_ctx: ChainContext) -> bool:
            call_count["n"] += 1
            if call_count["n"] >= 2:
                raise ValueError("condition error")
            return False

        loop = Loop("loop", step=step, condition=_bad_condition, max_iterations=10)

        result = await loop.execute(ctx)

        # Should stop after 2 iterations (condition raises on 2nd eval)
        assert result.metadata["iterations"] == 2

    async def test_single_iteration_condition_immediately_true(self) -> None:
        executor = make_executor("done")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")

        loop = Loop(
            "loop",
            step=step,
            condition=lambda _ctx: True,  # immediately true
            max_iterations=10,
        )

        result = await loop.execute(ctx)

        assert result.succeeded
        assert result.metadata["iterations"] == 1

    async def test_zero_max_iterations(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")

        loop = Loop(
            "loop",
            step=step,
            condition=lambda _ctx: False,
            max_iterations=0,
        )

        result = await loop.execute(ctx)

        assert result.succeeded  # all() of empty is True
        assert result.metadata["iterations"] == 0
        assert result.output == []

    async def test_loop_accumulates_results(self) -> None:
        executor, _ = make_counting_executor()
        ctx = make_context(executor=executor)
        step = Step("s", tool="t")

        loop = Loop(
            "loop",
            step=step,
            condition=lambda _ctx: False,
            max_iterations=3,
        )

        result = await loop.execute(ctx)

        assert len(result.output) == 3
        outputs = [r.output for r in result.output]
        assert outputs == [1, 2, 3]


# =====================================================================
# Integration: composing combinators together
# =====================================================================


class TestComposedChains:
    """Tests for combining multiple composition primitives."""

    async def test_sequence_with_branch(self) -> None:
        """Sequence that branches based on first step's output."""
        async def _executor(tool: str, args: dict) -> Any:
            if tool == "check":
                return True
            return f"ran_{tool}"

        ctx = make_context(executor=AsyncMock(side_effect=_executor))

        chain = (
            Sequence("deploy_chain")
            .then(Step("check", tool="check"))
            .then(
                Branch("decide", condition=lambda c: c.get("check"))
                .on_success(Step("deploy", tool="deploy"))
                .on_failure(Step("abort", tool="abort"))
            )
        )

        result = await chain.execute(ctx)

        assert result.succeeded
        branch_result = result.output[1]
        assert branch_result.metadata["branch"] == "success"
        assert branch_result.metadata["executed_step"] == "deploy"

    async def test_retry_wrapping_step_in_sequence(self) -> None:
        executor = make_flaky_executor(fail_count=1, return_value="ok")
        ctx = make_context(executor=executor)

        chain = (
            Sequence("seq")
            .then(Retry("retry_s", step=Step("s", tool="t"), max_retries=3, backoff_ms=1))
        )

        result = await chain.execute(ctx)

        assert result.succeeded

    async def test_parallel_inside_sequence(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)

        chain = (
            Sequence("pipeline")
            .then(Step("setup", tool="t"))
            .then(
                Parallel("parallel_tests")
                .add(Step("test_a", tool="t"))
                .add(Step("test_b", tool="t"))
            )
            .then(Step("teardown", tool="t"))
        )

        result = await chain.execute(ctx)

        assert result.succeeded
        assert result.metadata["step_count"] == 3
        parallel_result = result.output[1]
        assert parallel_result.metadata["parallel_count"] == 2

    async def test_nested_sequences(self) -> None:
        executor = make_executor("ok")
        ctx = make_context(executor=executor)

        inner = Sequence("inner").then(Step("a", tool="t")).then(Step("b", tool="t"))
        outer = Sequence("outer").then(inner).then(Step("c", tool="t"))

        result = await outer.execute(ctx)

        assert result.succeeded
        assert result.metadata["step_count"] == 2
        inner_result = result.output[0]
        assert inner_result.metadata["step_count"] == 2
