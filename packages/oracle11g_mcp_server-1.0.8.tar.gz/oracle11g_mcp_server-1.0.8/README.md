# Oracle11g MCP Server

[![PyPI version](https://badge.fury.io/py/oracle11g-mcp-server.svg)](https://badge.fury.io/py/oracle11g-mcp-server)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)

Model Context Protocol (MCP) server for Oracle databases, supporting Oracle 11g and above. This server enables AI models to interact with Oracle databases through a standardized protocol.

## Features

- **Database Operations**: List tables, describe table structures, execute SQL queries
- **DDL Support**: Execute Data Definition Language statements (CREATE, ALTER, DROP, etc.)
- **Security**: Built-in protections against dangerous operations
- **Connection Pooling**: Efficient database connection management
- **Async Support**: Full asynchronous operation support

## Installation

### Using uvx (Recommended)

```bash
uvx oracle11g-mcp-server
```

### Using pip

```bash
pip install oracle11g-mcp-server
```

## Prerequisites

- Python 3.12 or higher
- Oracle Instant Client
- Oracle database (11g or higher)

## Configuration

### Environment Variables

Create a `.env` file or set the following environment variables:

- `ORACLE_CONNECTION_STRING`: Your Oracle database connection string
  - Format: `username/password@hostname:port/service_name`
- `LIB_DIR`: Path to your Oracle Instant Client directory
- `DQL_LIMITS_ROWS`: Maximum rows returned by SELECT queries (default: 10)
- `DDL_ENABLE`: Enable DDL operations (Y/N, default: N)

### MCP Configuration

Add this to your MCP client configuration (e.g., Cursor's `mcp.json`):

```json
{
  "mcpServers": {
    "oracle11g-mcp-server": {
      "command": "uvx",
      "args": ["oracle11g-mcp-server"],
      "env": {
        "ORACLE_CONNECTION_STRING": "username/password@hostname:port/service_name",
        "LIB_DIR": "/path/to/instantclient",
        "DQL_LIMITS_ROWS": "1000",
        "DDL_ENABLE": "Y"
      }
    }
  }
}
```

## Available Tools

- **list_tables**: Get a list of all tables in the database
- **describe_table**: Get detailed information about a table's structure
- **execute_DQL**: Execute SELECT queries to read data
- **execute_DDL**: Execute DDL statements (CREATE, ALTER, DROP, etc.) - requires DDL_ENABLE=Y

## Security Features

- **DDL Protection**: DDL operations are disabled by default. Set `DDL_ENABLE=Y` to enable them.
- **Dangerous Operation Prevention**: Blocks potentially harmful operations like `DROP DATABASE`, `DROP TABLESPACE`, `DROP USER`.
- **Query Validation**: Validates SQL syntax and prevents non-DDL queries from being executed via DDL endpoint.
- **Connection Pooling**: Uses secure connection pooling to manage database connections efficiently.

## Development

### Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/oracle11g-mcp-server.git
cd oracle11g-mcp-server

# Install dependencies
uv pip install -e .

# Install Node.js dependencies for inspector
pnpm install
```

### Running

```bash
# Development mode with hot reload
uv run dev

# Production mode
uv run main
```

### Testing

```bash
# Run MCP inspector
pnpm run inspector
```

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

