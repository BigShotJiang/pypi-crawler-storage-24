# PyPI 发布检查清单

在上传到 PyPI 之前，请确保完成以下步骤：

## 📋 发布前检查

### 1. 项目信息
- [ ] 更新 `pyproject.toml` 中的版本号
- [ ] 确认项目描述准确
- [ ] 更新作者信息和邮箱
- [ ] 确认 GitHub 仓库 URL（如果有的话）

### 2. 文档
- [ ] README.md 内容完整且准确
- [ ] 安装说明清晰
- [ ] 使用示例正确
- [ ] 许可证文件存在

### 3. 代码质量
- [ ] 所有功能都经过测试
- [ ] 没有语法错误
- [ ] 导入路径正确
- [ ] 依赖项版本合适

### 4. PyPI 准备
- [ ] 在 PyPI 上注册账户
- [ ] 生成 API token（推荐）或准备用户名/密码
- [ ] 确认包名在 PyPI 上唯一

## 🚀 发布步骤

### 方法 1: 使用自动化脚本（推荐）

```bash
python upload_to_pypi.py
```

### 方法 2: 手动步骤

1. **安装构建工具**
   ```bash
   uv pip install build twine
   ```

2. **清理旧构建**
   ```bash
   rm -rf dist/ build/ *.egg-info/
   ```

3. **构建包**
   ```bash
   uv run python -m build
   ```

4. **检查包**
   ```bash
   uv run twine check dist/*
   ```

5. **上传到 TestPyPI（可选，用于测试）**
   ```bash
   uv run twine upload --repository testpypi dist/*
   ```

6. **上传到 PyPI**
   ```bash
   uv run twine upload dist/*
   ```

## 🔧 配置 API Token

### 创建 PyPI API Token
1. 登录 PyPI (https://pypi.org)
2. 进入 Account Settings
3. 创建新的 API token
4. 选择作用域（推荐选择特定项目）

### 配置 Token
创建 `~/.pypirc` 文件：

```ini
[distutils]
index-servers = pypi

[pypi]
username = __token__
password = pypi-your-api-token-here
```

## 📦 发布后验证

- [ ] 在 PyPI 上查看项目页面
- [ ] 测试安装: `pip install oracle11g-mcp-server`
- [ ] 测试 uvx 安装: `uvx oracle11g-mcp-server`
- [ ] 验证功能正常工作

## 🔄 版本管理

### 语义化版本控制
- **主版本号**: 不兼容的 API 更改
- **次版本号**: 向后兼容的功能添加
- **修订号**: 向后兼容的错误修复

### 版本更新示例
- `1.0.6` → `1.0.7` (错误修复)
- `1.0.6` → `1.1.0` (新功能)
- `1.0.6` → `2.0.0` (重大更改)

## ⚠️ 常见问题

### 包名已存在
- 更改包名或版本号
- 检查是否有拼写错误

### 认证失败
- 验证 API token 正确
- 检查 `~/.pypirc` 配置

### 构建失败
- 检查 `pyproject.toml` 语法
- 确认所有依赖项可用

### 上传失败
- 检查网络连接
- 确认文件权限正确