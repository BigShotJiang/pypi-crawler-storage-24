#!/usr/bin/env python3
"""
上传包到 PyPI 的脚本
"""
import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    """运行命令并处理错误"""
    print(f"\n🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} 成功完成")
        if result.stdout:
            print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} 失败:")
        print(f"错误代码: {e.returncode}")
        if e.stdout:
            print(f"标准输出: {e.stdout}")
        if e.stderr:
            print(f"错误输出: {e.stderr}")
        return False

def main():
    """主函数"""
    print("🚀 开始上传 Oracle11g MCP Server 到 PyPI")
    
    # 检查是否在正确的目录
    if not Path("pyproject.toml").exists():
        print("❌ 错误: 未找到 pyproject.toml 文件")
        print("请确保您在项目根目录中运行此脚本")
        sys.exit(1)
    
    # 清理之前的构建
    print("\n🧹 清理之前的构建文件...")
    for path in ["dist", "build", "*.egg-info"]:
        if os.path.exists(path):
            if os.path.isdir(path):
                import shutil
                shutil.rmtree(path)
                print(f"删除目录: {path}")
            else:
                os.remove(path)
                print(f"删除文件: {path}")
    
    # 安装构建依赖
    if not run_command("uv pip install build twine", "安装构建工具"):
        sys.exit(1)
    
    # 构建包
    if not run_command("uv run python -m build", "构建包"):
        sys.exit(1)
    
    # 检查构建的包
    if not run_command("uv run twine check dist/*", "检查包"):
        sys.exit(1)
    
    # 询问用户是否要上传到 PyPI
    print("\n📦 包构建完成！")
    print("构建的文件:")
    for file in Path("dist").glob("*"):
        print(f"  - {file}")
    
    choice = input("\n是否要上传到 PyPI？(y/N): ").lower().strip()
    
    if choice == 'y' or choice == 'yes':
        # 上传到 PyPI
        print("\n⚠️  注意: 请确保您已经:")
        print("1. 在 PyPI 上注册了账户")
        print("2. 配置了 API token 或准备输入用户名/密码")
        print("3. 项目名称在 PyPI 上是唯一的")
        
        confirm = input("\n继续上传？(y/N): ").lower().strip()
        if confirm == 'y' or confirm == 'yes':
            if not run_command("uv run twine upload dist/*", "上传到 PyPI"):
                print("\n❌ 上传失败。常见问题:")
                print("1. 包名已存在 - 需要更改版本号或包名")
                print("2. 认证失败 - 检查 API token 或用户名/密码")
                print("3. 网络问题 - 检查网络连接")
                sys.exit(1)
            else:
                print("\n🎉 成功上传到 PyPI!")
                print("您的包现在可以通过以下方式安装:")
                print("  pip install oracle11g-mcp-server")
                print("  uvx oracle11g-mcp-server")
        else:
            print("取消上传")
    else:
        print("跳过上传到 PyPI")
        print("如果您想稍后上传，可以运行:")
        print("  uv run twine upload dist/*")

if __name__ == "__main__":
    main()