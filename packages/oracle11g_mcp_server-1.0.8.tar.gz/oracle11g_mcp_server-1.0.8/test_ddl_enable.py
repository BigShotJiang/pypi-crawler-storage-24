#!/usr/bin/env python3
"""
测试 DDL_ENABLE 参数控制的脚本
"""
import asyncio
import os
from src.oracle_mcp_server.oracle_tools import execute_DDL

# 模拟不同的 DDL_ENABLE 设置
async def test_ddl_enable():
    """测试 DDL 启用/禁用功能"""
    
    print("测试 DDL_ENABLE 参数控制...")
    
    # 测试用的 CREATE TABLE 语句
    test_query = """
    CREATE TABLE test_ddl_enable (
        id NUMBER PRIMARY KEY,
        name VARCHAR2(100)
    )
    """
    
    # 测试1: DDL_ENABLE = N (默认，禁用)
    print("\n1. 测试 DDL_ENABLE = N (禁用状态):")
    # 模拟设置环境变量
    from src.oracle_mcp_server import oracle_tools
    oracle_tools.ddl_enable = "N"
    
    result = await execute_DDL(test_query)
    print(f"结果: {result}")
    
    # 测试2: DDL_ENABLE = n (小写n，应该被禁用)
    print("\n2. 测试 DDL_ENABLE = n (小写n，应该被禁用):")
    oracle_tools.ddl_enable = "n"
    
    result = await execute_DDL(test_query)
    print(f"结果: {result}")
    
    # 测试3: DDL_ENABLE = Y (启用)
    print("\n3. 测试 DDL_ENABLE = Y (启用状态):")
    oracle_tools.ddl_enable = "Y"
    
    result = await execute_DDL(test_query)
    print(f"结果: {result}")
    print("注意: 如果没有数据库连接，会显示连接错误，这是正常的")
    
    # 测试4: DDL_ENABLE = y (小写y，应该被启用)
    print("\n4. 测试 DDL_ENABLE = y (小写y，应该被启用):")
    oracle_tools.ddl_enable = "y"
    
    result = await execute_DDL(test_query)
    print(f"结果: {result}")
    print("注意: 如果没有数据库连接，会显示连接错误，这是正常的")
    
    # 测试5: DDL_ENABLE = 其他值 (应该被禁用)
    print("\n5. 测试 DDL_ENABLE = 'YES' (其他值，应该被禁用):")
    oracle_tools.ddl_enable = "YES"
    
    result = await execute_DDL(test_query)
    print(f"结果: {result}")
    
    # 测试6: DDL_ENABLE = 空字符串 (应该被禁用)
    print("\n6. 测试 DDL_ENABLE = '' (空字符串，应该被禁用):")
    oracle_tools.ddl_enable = ""
    
    result = await execute_DDL(test_query)
    print(f"结果: {result}")

def test_environment_variable():
    """测试环境变量的读取"""
    print("\n=== 测试环境变量设置 ===")
    
    # 显示当前环境变量
    ddl_enable_env = os.getenv("DDL_ENABLE", "未设置")
    print(f"当前 DDL_ENABLE 环境变量: {ddl_enable_env}")
    
    # 模拟不同的环境变量设置
    test_values = ["Y", "N", "y", "n", "YES", "NO", "1", "0", ""]
    
    for value in test_values:
        os.environ["DDL_ENABLE"] = value
        result = os.getenv("DDL_ENABLE", "N")
        is_enabled = result.upper() == 'Y'
        print(f"DDL_ENABLE='{value}' -> 读取为: '{result}' -> 启用: {is_enabled}")
    
    # 清理环境变量
    if "DDL_ENABLE" in os.environ:
        del os.environ["DDL_ENABLE"]

if __name__ == "__main__":
    print("🔧 DDL_ENABLE 功能测试")
    
    # 测试环境变量
    test_environment_variable()
    
    # 测试异步功能
    asyncio.run(test_ddl_enable())
    
    print("\n✅ 测试完成!")
    print("\n📝 使用说明:")
    print("- 设置 DDL_ENABLE=Y 来启用 DDL 操作")
    print("- 设置 DDL_ENABLE=N 或不设置来禁用 DDL 操作")
    print("- 只有 'Y' 或 'y' 会启用 DDL，其他所有值都会禁用")