#!/usr/bin/env python3
"""
测试 execute_DDL 方法的简单脚本
"""
import asyncio
from src.oracle_mcp_server.oracle_tools import execute_DDL

async def test_ddl():
    """测试 DDL 方法的各种情况"""
    
    print("测试 DDL 方法...")
    
    # 测试1: 有效的 CREATE TABLE 语句
    print("\n1. 测试有效的 CREATE TABLE 语句:")
    create_query = """
    CREATE TABLE test_table (
        id NUMBER PRIMARY KEY,
        name VARCHAR2(100),
        created_date DATE DEFAULT SYSDATE
    )
    """
    result = await execute_DDL(create_query)
    print(f"结果: {result}")
    
    # 测试2: 无效的查询（SELECT 语句）
    print("\n2. 测试无效的查询（SELECT 语句）:")
    select_query = "SELECT * FROM test_table"
    result = await execute_DDL(select_query)
    print(f"结果: {result}")
    
    # 测试3: 危险操作（DROP DATABASE）
    print("\n3. 测试危险操作（DROP DATABASE）:")
    dangerous_query = "DROP DATABASE test_db"
    result = await execute_DDL(dangerous_query)
    print(f"结果: {result}")
    
    # 测试4: ALTER TABLE 语句
    print("\n4. 测试 ALTER TABLE 语句:")
    alter_query = "ALTER TABLE test_table ADD (email VARCHAR2(200))"
    result = await execute_DDL(alter_query)
    print(f"结果: {result}")
    
    # 测试5: 带注释的 DDL 语句
    print("\n5. 测试带注释的 DDL 语句:")
    comment_query = """
    -- 这是一个注释
    CREATE TABLE test_table2 (
        /* 多行注释
           测试 */
        id NUMBER
    )
    """
    result = await execute_DDL(comment_query)
    print(f"结果: {result}")

if __name__ == "__main__":
    asyncio.run(test_ddl())