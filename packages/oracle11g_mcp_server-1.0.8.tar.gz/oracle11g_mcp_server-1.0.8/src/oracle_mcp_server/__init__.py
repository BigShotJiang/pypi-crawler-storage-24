import os
import sys
import signal
from typing import Any
from mcp.server.fastmcp import FastMCP
from . import oracle_tools
from dotenv import load_dotenv
import asyncio


# Load the environment variables
load_dotenv()

# Initialize the FastMCP server
mcp = FastMCP("oracle11g-mcp-server")

oracle_tools.connection_string = os.getenv("ORACLE_CONNECTION_STRING")
oracle_tools.lib_dir = os.getenv("LIB_DIR")
oracle_tools.dql_limits_rows = int(os.getenv("DQL_LIMITS_ROWS", "10"))
oracle_tools.ddl_enable = os.getenv("DDL_ENABLE", "N")

# 初始化连接池
async def initialize_server():
    await oracle_tools.init_pool()

@mcp.tool()
async def list_tables() -> str:
    """Get a list of all tables in the oracle database

    Args:
        None
    """
    return await oracle_tools.list_tables()


@mcp.tool()
async def describe_table(table_name: str) -> str:
    """Get a description of a table in the oracle database"

    Args:
        table_name (string): The name of the table to describe
    """
    return await oracle_tools.describe_table(table_name)


@mcp.tool()
async def execute_DQL(query: str) -> str:
    """Execute SELECT queries to read data from the oracle database

    Args:
        query (string): The SELECT query to execute
    """
    return await oracle_tools.execute_DQL(query)


@mcp.tool()
async def execute_DDL(query: str) -> str:
    """Execute DDL (Data Definition Language) statements like CREATE, ALTER, DROP, TRUNCATE, etc.
    
    Note: DDL operations are disabled by default for security. Set DDL_ENABLE=Y to enable.

    Args:
        query (string): The DDL statement to execute
    """
    return await oracle_tools.execute_DDL(query)


def main() -> None:
    # 在启动服务器前初始化连接池
    asyncio.run(initialize_server())
    mcp.run(transport='stdio')


def dev() -> None:
    """
    Development function that handles Ctrl+C gracefully.
    This function calls main() but catches KeyboardInterrupt to allow 
    clean exit when user presses Ctrl+C.
    """
    print("mcp server starting", file=sys.stderr)

    # Define signal handler for cleaner exit
    def signal_handler(sig, frame):
        print("\nShutting down mcp server...", file=sys.stderr)
        sys.exit(0)

    # Register the signal handler for SIGINT (Ctrl+C)
    signal.signal(signal.SIGINT, signal_handler)

    try:
        # Run the server with proper exception handling
        main()
    except KeyboardInterrupt:
        print("\nShutting down mcp server...", file=sys.stderr)
        sys.exit(0)
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)
