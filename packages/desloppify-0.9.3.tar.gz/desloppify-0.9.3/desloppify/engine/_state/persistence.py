"""State persistence and migration routines."""

from __future__ import annotations

import json
import logging
import shutil
import sys
from pathlib import Path
from typing import cast

__all__ = [
    "load_state",
    "save_state",
]

from desloppify.base.discovery.file_paths import safe_write_text
from desloppify.base.text_utils import is_numeric
from desloppify.engine._state.schema import (
    CURRENT_VERSION,
    StateModel,
    empty_state,
    ensure_state_defaults,
    get_state_file,
    json_default,
    validate_state_invariants,
)

logger = logging.getLogger(__name__)

_STATE_FILE_SENTINEL = object()
STATE_FILE = _STATE_FILE_SENTINEL


from desloppify.engine._state import _recompute_stats


def _default_state_file() -> Path:
    """Resolve the default state path, honoring runtime context overrides.

    If tests monkeypatch ``STATE_FILE`` in this module, use that override.
    """
    if STATE_FILE is not _STATE_FILE_SENTINEL:
        return Path(STATE_FILE)
    return get_state_file()


def _load_json(path: Path) -> dict[str, object]:
    data = json.loads(path.read_text())
    if not isinstance(data, dict):
        raise ValueError("state file root must be a JSON object")
    return data


def _normalize_loaded_state(data: object) -> dict[str, object]:
    if not isinstance(data, dict):
        raise ValueError("state file root must be a JSON object")
    ensure_state_defaults(data)
    normalized = cast(StateModel, data)
    validate_state_invariants(normalized)
    return normalized


def load_state(path: Path | None = None) -> StateModel:
    """Load state from disk, or return empty state on missing/corruption."""
    state_path = path or _default_state_file()
    if not state_path.exists():
        return empty_state()

    try:
        data = _load_json(state_path)
    except (json.JSONDecodeError, UnicodeDecodeError, OSError, ValueError) as ex:
        backup = state_path.with_suffix(".json.bak")
        if backup.exists():
            logger.warning(
                "Primary state load failed for %s; attempting backup %s: %s",
                state_path,
                backup,
                ex,
            )
            try:
                backup_data = _load_json(backup)
                logger.warning(
                    "Recovered state from backup %s after primary load failure at %s",
                    backup,
                    state_path,
                )
                print(
                    f"  ⚠ State file corrupted ({ex}), loaded from backup.",
                    file=sys.stderr,
                )
                return _normalize_loaded_state(backup_data)
            except (
                json.JSONDecodeError,
                UnicodeDecodeError,
                OSError,
                ValueError,
                TypeError,
                AttributeError,
            ) as backup_ex:
                logger.warning(
                    "Backup state load failed from %s after corruption in %s: %s",
                    backup,
                    state_path,
                    backup_ex,
                )
                logger.debug("Backup state load failed from %s: %s", backup, backup_ex)

        logger.warning(
            "State file load failed for %s and backup recovery was unavailable. "
            "Falling back to empty state: %s",
            state_path,
            ex,
        )
        print(f"  ⚠ State file corrupted ({ex}). Starting fresh.", file=sys.stderr)
        rename_failed = False
        try:
            state_path.rename(state_path.with_suffix(".json.corrupted"))
        except OSError as rename_ex:
            rename_failed = True
            logger.debug(
                "Failed to rename corrupted state file %s: %s", state_path, rename_ex
            )
        if rename_failed:
            logger.debug(
                "Corrupted state file retained at original path: %s", state_path
            )
        return empty_state()

    version = data.get("version", 1)
    if version > CURRENT_VERSION:
        print(
            "  ⚠ State file version "
            f"{version} is newer than supported ({CURRENT_VERSION}). "
            "Some features may not work correctly.",
            file=sys.stderr,
        )

    try:
        return _normalize_loaded_state(data)
    except (ValueError, TypeError, AttributeError) as normalize_ex:
        logger.warning(
            "State invariants invalid for %s; falling back to empty state: %s",
            state_path,
            normalize_ex,
        )
        print(
            f"  ⚠ State invariants invalid ({normalize_ex}). Starting fresh.",
            file=sys.stderr,
        )
        return empty_state()


def _coerce_integrity_target(value: object) -> float | None:
    if not is_numeric(value):
        return None
    return max(0.0, min(100.0, float(value)))


def _resolve_integrity_target(
    state: StateModel,
    explicit_target: float | None,
) -> float | None:
    target = _coerce_integrity_target(explicit_target)
    if target is not None:
        return target

    integrity = state.get("subjective_integrity")
    if not isinstance(integrity, dict):
        return None
    return _coerce_integrity_target(integrity.get("target_score"))


def save_state(
    state: StateModel,
    path: Path | None = None,
    *,
    subjective_integrity_target: float | None = None,
) -> None:
    """Recompute stats/score and save to disk atomically."""
    ensure_state_defaults(state)
    _recompute_stats(
        state,
        scan_path=state.get("scan_path"),
        subjective_integrity_target=_resolve_integrity_target(
            state,
            subjective_integrity_target,
        ),
    )
    validate_state_invariants(state)

    state_path = path or _default_state_file()
    state_path.parent.mkdir(parents=True, exist_ok=True)

    content = json.dumps(state, indent=2, default=json_default) + "\n"

    if state_path.exists():
        backup = state_path.with_suffix(".json.bak")
        try:
            shutil.copy2(str(state_path), str(backup))
        except OSError as backup_ex:
            logger.debug(
                "Failed to create state backup %s: %s",
                state_path.with_suffix(".json.bak"),
                backup_ex,
            )

    try:
        safe_write_text(state_path, content)
    except OSError as ex:
        print(f"  Warning: Could not save state: {ex}", file=sys.stderr)
        raise
