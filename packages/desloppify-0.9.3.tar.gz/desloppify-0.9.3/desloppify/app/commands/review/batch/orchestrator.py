"""Batch runner helpers and orchestration for review command."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import cast

from desloppify.app.commands.helpers.query import write_query_best_effort
from desloppify.base.coercions import coerce_positive_int
from desloppify.base.discovery.file_paths import safe_write_text
from desloppify.base.exception_sets import CommandError, PacketValidationError
from desloppify.base.output.terminal import colorize, log
from desloppify.base.search.query_paths import query_file_path
import desloppify.intelligence.narrative.core as narrative_mod
from desloppify.intelligence import review as review_mod
from desloppify.intelligence.review.feedback_contract import (
    max_batch_issues_for_dimension_count,
)

from ..helpers import parse_dimensions
from ..importing.cmd import do_import as _do_import
from ..importing.flags import ReviewImportConfig
from ..packet.policy import coerce_review_batch_file_limit, redacted_review_config
from ..prompt_sections import explode_to_single_dimension
from ..runner_failures import print_failures, print_failures_and_raise
from ..runner_packets import (
    build_batch_import_provenance,
    build_blind_packet,
    prepare_run_artifacts,
    run_stamp,
    selected_batch_indexes,
    write_packet_snapshot,
)
from ..runner_parallel import BatchExecutionOptions, collect_batch_results, execute_batches
from ..runner_process import (
    CodexBatchRunnerDeps,
    FollowupScanDeps,
    run_codex_batch,
    run_followup_scan,
)
from ..runtime.setup import setup_lang_concrete as _setup_lang
from ..runtime_paths import (
    blind_packet_path as _blind_packet_path,
)
from ..runtime_paths import (
    review_packet_dir as _review_packet_dir,
)
from ..runtime_paths import (
    runtime_project_root as _runtime_project_root,
)
from ..runtime_paths import (
    subagent_runs_dir as _subagent_runs_dir,
)
from .core_merge_support import assessment_weight  # noqa: F401 — re-exported
from .core_models import BatchResultPayload
from .scope import (
    collect_reviewed_files_from_batches,
    normalize_dimension_list,
    scored_dimensions_for_lang,
)
from .core_normalize import normalize_batch_result
from .core_parse import extract_json_payload, parse_batch_selection
from . import execution_phases as review_batch_phases_mod
from .merge import merge_batch_results
from .prompt_template import render_batch_prompt
from . import execution as review_batches_mod

FOLLOWUP_SCAN_TIMEOUT_SECONDS = 45 * 60
ABSTRACTION_SUB_AXES = (
    "abstraction_leverage",
    "indirection_cost",
    "interface_honesty",
    "delegation_density",
    "definition_directness",
    "type_discipline",
)
ABSTRACTION_COMPONENT_NAMES = {
    "abstraction_leverage": "Abstraction Leverage",
    "indirection_cost": "Indirection Cost",
    "interface_honesty": "Interface Honesty",
    "delegation_density": "Delegation Density",
    "definition_directness": "Definition Directness",
    "type_discipline": "Type Discipline",
}



def _try_load_prepared_packet() -> dict | None:
    """Load a prepared holistic packet from query.json if it looks valid.

    Returns the packet dict when query.json exists, parses as JSON, and
    contains the ``investigation_batches`` key written by ``--prepare``.
    Returns ``None`` otherwise (missing file, parse error, wrong shape).
    """
    try:
        qf = query_file_path()
        if not qf.exists():
            return None
        data = json.loads(qf.read_text())
    except (OSError, json.JSONDecodeError, RuntimeError):
        return None
    if not isinstance(data, dict):
        return None
    if "investigation_batches" not in data:
        return None
    batches = data["investigation_batches"]
    if not isinstance(batches, list) or not batches:
        return None
    return data


def _merge_batch_results(batch_results: list[object]) -> dict[str, object]:
    """Deterministically merge assessments/issues across batch outputs."""
    normalized_results: list[BatchResultPayload] = []
    for result in batch_results:
        if hasattr(result, "to_dict") and callable(result.to_dict):
            payload = result.to_dict()
            if isinstance(payload, dict):
                normalized_results.append(cast(BatchResultPayload, payload))
                continue
        if isinstance(result, dict):
            normalized_results.append(cast(BatchResultPayload, result))
    return merge_batch_results(
        normalized_results,
        abstraction_sub_axes=ABSTRACTION_SUB_AXES,
        abstraction_component_names=ABSTRACTION_COMPONENT_NAMES,
    )


def _load_or_prepare_packet(
    args,
    *,
    state: dict,
    lang,
    config: dict,
    stamp: str,
) -> tuple[dict, Path, Path]:
    """Load packet override or prepare a fresh packet snapshot."""
    packet_override = getattr(args, "packet", None)
    if packet_override:
        packet_path = Path(packet_override)
        if not packet_path.exists():
            raise PacketValidationError(f"packet not found: {packet_override}", exit_code=1)
        try:
            packet = json.loads(packet_path.read_text())
        except (OSError, json.JSONDecodeError) as exc:
            raise PacketValidationError(f"reading packet: {exc}", exit_code=1) from exc
        blind_path = _blind_packet_path()
        blind_packet = build_blind_packet(packet)
        safe_write_text(blind_path, json.dumps(blind_packet, indent=2) + "\n")
        print(colorize(f"  Immutable packet: {packet_path}", "dim"))
        print(colorize(f"  Blind packet: {blind_path}", "dim"))
        return packet, packet_path, blind_path

    # When no explicit --packet and no explicit --dimensions were given,
    # check whether a prior ``review --prepare`` left a valid query.json
    # packet we can reuse instead of rebuilding from scratch.
    dims = parse_dimensions(args)
    if not dims:
        prepared = _try_load_prepared_packet()
        if prepared is not None:
            print(colorize("  Reusing prepared packet from query.json", "dim"))
            blind_path = _blind_packet_path()
            blind_packet = build_blind_packet(prepared)
            safe_write_text(blind_path, json.dumps(blind_packet, indent=2) + "\n")
            packet_path, blind_saved = write_packet_snapshot(
                prepared,
                stamp=stamp,
                review_packet_dir=_review_packet_dir(),
                blind_path=blind_path,
                safe_write_text_fn=safe_write_text,
            )
            print(colorize(f"  Immutable packet: {packet_path}", "dim"))
            print(colorize(f"  Blind packet: {blind_saved}", "dim"))
            return prepared, packet_path, blind_saved

    path = Path(args.path)
    dimensions = list(dims) if dims else None
    retrospective = bool(getattr(args, "retrospective", False))
    retrospective_max_issues = coerce_positive_int(
        getattr(args, "retrospective_max_issues", None),
        default=30,
        minimum=1,
    )
    retrospective_max_batch_items = coerce_positive_int(
        getattr(args, "retrospective_max_batch_items", None),
        default=20,
        minimum=1,
    )
    lang_run, found_files = _setup_lang(lang, path, config)
    lang_name = lang_run.name
    narrative = narrative_mod.compute_narrative(
        state,
        context=narrative_mod.NarrativeContext(lang=lang_name, command="review"),
    )

    blind_path = _blind_packet_path()
    packet = review_mod.prepare_holistic_review(
        path,
        lang_run,
        state,
        options=review_mod.HolisticReviewPrepareOptions(
            dimensions=dimensions,
            files=found_files or None,
            max_files_per_batch=coerce_review_batch_file_limit(config),
            include_issue_history=retrospective,
            issue_history_max_issues=retrospective_max_issues,
            issue_history_max_batch_items=retrospective_max_batch_items,
        ),
    )
    packet["config"] = redacted_review_config(config)
    packet["narrative"] = narrative
    next_command = "desloppify review --prepare"
    if retrospective:
        next_command += (
            " --retrospective"
            f" --retrospective-max-issues {retrospective_max_issues}"
            f" --retrospective-max-batch-items {retrospective_max_batch_items}"
        )
    packet["next_command"] = next_command
    write_query_best_effort(
        packet,
        context="review packet query update",
    )
    packet_path, blind_saved = write_packet_snapshot(
        packet,
        stamp=stamp,
        review_packet_dir=_review_packet_dir(),
        blind_path=blind_path,
        safe_write_text_fn=safe_write_text,
    )
    print(colorize(f"  Immutable packet: {packet_path}", "dim"))
    print(colorize(f"  Blind packet: {blind_saved}", "dim"))
    return packet, packet_path, blind_saved


def do_run_batches(args, state, lang, state_file, config: dict | None = None) -> None:
    """Run holistic investigation batches with a local subagent runner."""
    from ..runtime.policy import resolve_batch_run_policy

    runtime_project_root = _runtime_project_root()
    subagent_runs_dir = _subagent_runs_dir()
    policy = resolve_batch_run_policy(args)
    batch_timeout_seconds = policy.batch_timeout_seconds
    batch_max_retries = policy.batch_max_retries
    batch_retry_backoff_seconds = policy.batch_retry_backoff_seconds
    batch_heartbeat_seconds = policy.heartbeat_seconds
    batch_live_log_interval_seconds = (
        max(1.0, min(batch_heartbeat_seconds, 10.0))
        if batch_heartbeat_seconds > 0
        else 5.0
    )
    batch_stall_kill_seconds = policy.stall_kill_seconds

    from desloppify.engine.plan import load_policy, render_policy_block
    _policy_block = render_policy_block(load_policy())

    def _prompt_fn_with_policy(**kwargs):
        return render_batch_prompt(**kwargs, policy_block=_policy_block)

    def _adapted_selected_batch_indexes(_args, *, batch_count):
        return selected_batch_indexes(
            raw_selection=getattr(args, "only_batches", None),
            batch_count=batch_count,
            parse_fn=parse_batch_selection,
            colorize_fn=colorize,
        )

    def _adapted_prepare_run_artifacts(
        *, stamp, selected_indexes, batches, packet_path, run_root, repo_root
    ):
        return prepare_run_artifacts(
            stamp=stamp,
            selected_indexes=selected_indexes,
            batches=batches,
            packet_path=packet_path,
            run_root=run_root,
            repo_root=repo_root,
            build_prompt_fn=_prompt_fn_with_policy,
            safe_write_text_fn=safe_write_text,
            colorize_fn=colorize,
        )

    def _adapted_run_codex_batch(*, prompt, repo_root, output_file, log_file):
        return run_codex_batch(
            prompt=prompt,
            repo_root=repo_root,
            output_file=output_file,
            log_file=log_file,
            deps=CodexBatchRunnerDeps(
                timeout_seconds=batch_timeout_seconds,
                subprocess_run=subprocess.run,
                timeout_error=subprocess.TimeoutExpired,
                safe_write_text_fn=safe_write_text,
                use_popen_runner=(
                    getattr(subprocess.run, "__module__", "") == "subprocess"
                ),
                subprocess_popen=subprocess.Popen,
                live_log_interval_seconds=batch_live_log_interval_seconds,
                stall_after_output_seconds=batch_stall_kill_seconds,
                max_retries=batch_max_retries,
                retry_backoff_seconds=batch_retry_backoff_seconds,
            ),
        )

    def _adapted_execute_batches(**kwargs):
        return execute_batches(
            tasks=kwargs["tasks"],
            options=BatchExecutionOptions(
                run_parallel=kwargs["options"].run_parallel,
                max_parallel_workers=kwargs["options"].max_parallel_workers,
                heartbeat_seconds=kwargs["options"].heartbeat_seconds,
            ),
            progress_fn=kwargs.get("progress_fn"),
            error_log_fn=kwargs.get("error_log_fn"),
        )

    def _adapted_collect_batch_results(
        *, selected_indexes, failures, output_files, allowed_dims
    ):
        return collect_batch_results(
            selected_indexes=selected_indexes,
            failures=failures,
            output_files=output_files,
            allowed_dims=allowed_dims,
            extract_payload_fn=lambda raw: extract_json_payload(raw, log_fn=log),
            normalize_result_fn=lambda payload, dims: normalize_batch_result(
                payload,
                dims,
                max_batch_issues=max_batch_issues_for_dimension_count(len(dims)),
                abstraction_sub_axes=ABSTRACTION_SUB_AXES,
            ),
        )

    def _adapted_run_followup_scan(*, lang_name, scan_path):
        return run_followup_scan(
            lang_name=lang_name,
            scan_path=scan_path,
            deps=FollowupScanDeps(
                project_root=runtime_project_root,
                timeout_seconds=FOLLOWUP_SCAN_TIMEOUT_SECONDS,
                python_executable=sys.executable,
                subprocess_run=subprocess.run,
                timeout_error=subprocess.TimeoutExpired,
                colorize_fn=colorize,
            ),
        )

    batch_deps = review_batches_mod.BatchRunDeps(
        run_stamp_fn=run_stamp,
        load_or_prepare_packet_fn=_load_or_prepare_packet,
        selected_batch_indexes_fn=_adapted_selected_batch_indexes,
        prepare_run_artifacts_fn=_adapted_prepare_run_artifacts,
        run_codex_batch_fn=_adapted_run_codex_batch,
        execute_batches_fn=_adapted_execute_batches,
        collect_batch_results_fn=_adapted_collect_batch_results,
        print_failures_fn=print_failures,
        print_failures_and_raise_fn=print_failures_and_raise,
        merge_batch_results_fn=_merge_batch_results,
        build_import_provenance_fn=build_batch_import_provenance,
        do_import_fn=_do_import,
        run_followup_scan_fn=_adapted_run_followup_scan,
        safe_write_text_fn=safe_write_text,
        colorize_fn=colorize,
    )
    prepared = review_batch_phases_mod.prepare_batch_run(
        args=args,
        state=state,
        lang=lang,
        config=config or {},
        deps=batch_deps,
        project_root=runtime_project_root,
        subagent_runs_dir=subagent_runs_dir,
    )
    if prepared is None:
        return

    executed = review_batch_phases_mod.execute_batch_run(
        prepared=prepared,
        deps=batch_deps,
    )
    review_batch_phases_mod.merge_and_import_batch_run(
        prepared=prepared,
        executed=executed,
        state_file=state_file,
        deps=batch_deps,
    )

def _validate_run_dir(run_dir: Path) -> tuple[dict, Path, str]:
    """Validate run directory, load summary, and return (summary, blind_packet_path, immutable_packet_path).

    Raises CommandError on any validation failure.
    """
    if not run_dir.is_dir():
        raise CommandError(f"run directory not found: {run_dir}", exit_code=1)

    summary_path = run_dir / "run_summary.json"
    if not summary_path.exists():
        raise CommandError(f"no run_summary.json in {run_dir}", exit_code=1)
    try:
        summary = json.loads(summary_path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise CommandError(f"Error reading run summary: {exc}", exit_code=1) from exc

    successful = summary.get("successful_batches", [])
    blind_packet_path = Path(str(summary.get("blind_packet", "")))
    immutable_packet_path = str(summary.get("immutable_packet", ""))

    if not successful:
        raise CommandError("no successful batches in run summary.", exit_code=1)
    if not blind_packet_path.exists():
        raise PacketValidationError(f"blind packet not found: {blind_packet_path}", exit_code=1)

    try:
        packet = json.loads(Path(immutable_packet_path).read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise PacketValidationError(f"Error reading immutable packet: {exc}", exit_code=1) from exc

    summary["_packet"] = packet
    return summary, blind_packet_path, immutable_packet_path


def do_import_run(
    run_dir_path: str,
    state: dict,
    lang,
    state_file: str,
    *,
    config: dict | None = None,
    allow_partial: bool = False,
    scan_after_import: bool = False,
    scan_path: str = ".",
    dry_run: bool = False,
) -> None:
    """Re-import results from a completed run directory.

    Replays the merge+provenance+import step that normally runs at the end of
    ``--run-batches``.  Useful when the original pipeline was interrupted (e.g.
    broken pipe from background execution) but all batch results completed.
    """
    run_dir = Path(run_dir_path)
    summary, blind_packet_path, _immutable_path = _validate_run_dir(run_dir)

    runner = str(summary.get("runner", "codex"))
    stamp = str(summary.get("run_stamp", ""))
    successful = summary.get("successful_batches", [])
    packet = summary.pop("_packet", {})
    allowed_dims = {str(d) for d in packet.get("dimensions", []) if isinstance(d, str)}

    # -- locate and parse raw batch results --
    results_dir = run_dir / "results"
    selected_indexes = [idx - 1 for idx in successful]  # convert 1-based to 0-based
    output_files = {
        idx: results_dir / f"batch-{idx + 1}.raw.txt"
        for idx in selected_indexes
    }

    missing = [idx + 1 for idx in selected_indexes if not output_files[idx].exists()]
    if missing:
        raise CommandError(f"missing result files for batches: {missing}", exit_code=1)

    batch_results, failures = collect_batch_results(
        selected_indexes=selected_indexes,
        failures=[],
        output_files=output_files,
        allowed_dims=allowed_dims,
        extract_payload_fn=lambda raw: extract_json_payload(raw, log_fn=log),
        normalize_result_fn=lambda payload, dims: normalize_batch_result(
            payload,
            dims,
            max_batch_issues=max_batch_issues_for_dimension_count(len(dims)),
            abstraction_sub_axes=ABSTRACTION_SUB_AXES,
        ),
    )

    if not batch_results:
        raise CommandError("no valid batch results could be parsed.", exit_code=1)

    print(colorize(f"  Parsed {len(batch_results)} batch results from {run_dir}", "bold"))
    if failures:
        print(colorize(f"  Warning: {len(failures)} batches failed to parse: {[f + 1 for f in failures]}", "yellow"))

    # -- merge --
    merged = _merge_batch_results(batch_results)

    # -- build provenance --
    successful_indexes = [idx for idx in selected_indexes if idx not in set(failures)]
    merged["provenance"] = build_batch_import_provenance(
        runner=runner,
        blind_packet_path=blind_packet_path,
        run_stamp=stamp,
        batch_indexes=successful_indexes,
    )

    # -- enrich with review_scope / reviewed_files / assessment_coverage --
    # Mirror the metadata that merge_and_write_results adds in the normal flow
    # so that downstream import does not blindly auto-resolve all dimensions.
    raw_batches = packet.get("investigation_batches", [])
    raw_dim_prompts = packet.get("dimension_prompts")
    batches = explode_to_single_dimension(
        raw_batches if isinstance(raw_batches, list) else [],
        dimension_prompts=raw_dim_prompts if isinstance(raw_dim_prompts, dict) else None,
    )
    reviewed_files = collect_reviewed_files_from_batches(
        batches=batches,
        selected_indexes=successful_indexes,
    )
    full_sweep_included = any(
        str(batch.get("name", "")).strip().lower() == "full codebase sweep"
        for idx in successful_indexes
        if 0 <= idx < len(batches)
        for batch in [batches[idx]]
        if isinstance(batch, dict)
    )
    review_scope: dict[str, object] = {
        "reviewed_files_count": len(reviewed_files),
        "successful_batch_count": len(successful_indexes),
        "full_sweep_included": full_sweep_included,
    }
    total_files = packet.get("total_files")
    if isinstance(total_files, int) and not isinstance(total_files, bool) and total_files > 0:
        review_scope["total_files"] = total_files
    merged["review_scope"] = review_scope
    if reviewed_files:
        merged["reviewed_files"] = reviewed_files

    packet_dimensions = normalize_dimension_list(packet.get("dimensions", []))
    lang_name = getattr(lang, "name", None) or str(getattr(lang, "lang", ""))
    scored_dimensions = scored_dimensions_for_lang(lang_name) if lang_name else []
    _assessments = merged.get("assessments")
    _assessments_dict = _assessments if isinstance(_assessments, dict) else {}
    merged_assessment_dims = normalize_dimension_list(
        list(_assessments_dict.keys())
    )
    _issues = merged.get("issues")
    _issues_list = _issues if isinstance(_issues, list) else []
    merged_issue_dims = normalize_dimension_list(
        [
            issue.get("dimension")
            for issue in _issues_list
            if isinstance(issue, dict)
        ]
    )
    merged_imported_dims = normalize_dimension_list(
        merged_assessment_dims + merged_issue_dims
    )
    review_scope["imported_dimensions"] = merged_imported_dims
    merged["assessment_coverage"] = {
        "scored_dimensions": scored_dimensions,
        "selected_dimensions": packet_dimensions,
        "imported_dimensions": merged_assessment_dims,
        "missing_dimensions": [
            dim for dim in scored_dimensions if dim not in set(merged_assessment_dims)
        ],
    }

    # -- write merged output (always — this is inside the run dir, not state) --
    merged_path = run_dir / "holistic_issues_merged.json"
    safe_write_text(merged_path, json.dumps(merged, indent=2) + "\n")
    print(colorize(f"  Merged output: {merged_path}", "bold"))

    # -- import with trusted source --
    _do_import(
        str(merged_path),
        state,
        lang,
        state_file,
        import_config=ReviewImportConfig(
            config=config,
            allow_partial=allow_partial,
            trusted_assessment_source=True,
            trusted_assessment_label=f"trusted import-run replay from {run_dir.name}",
        ),
        dry_run=dry_run,
    )

    # -- optional follow-up scan --
    if scan_after_import and not dry_run:
        lang_name = getattr(lang, "name", None) or str(getattr(lang, "lang", ""))
        if lang_name:
            run_followup_scan(
                lang_name=lang_name,
                scan_path=scan_path,
                deps=FollowupScanDeps(
                    project_root=_runtime_project_root(),
                    timeout_seconds=FOLLOWUP_SCAN_TIMEOUT_SECONDS,
                    python_executable=sys.executable,
                    subprocess_run=subprocess.run,
                    timeout_error=subprocess.TimeoutExpired,
                    colorize_fn=colorize,
                ),
            )
