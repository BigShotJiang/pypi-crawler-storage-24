from dataclasses import dataclass
from typing import List

from workers_control.core.interactors import show_a_account_details
from workers_control.web.translator import Translator
from workers_control.web.url_index import UrlIndex
from workers_control.web.www.navbar import NavbarItem
from workers_control.web.www.presenters.transfers import TransferInfo, TransferPresenter


@dataclass
class ShowAAccountDetailsPresenter:
    @dataclass
    class ViewModel:
        transfers: List[TransferInfo]
        account_balance: str
        plot_url: str
        navbar_items: list[NavbarItem]

    translator: Translator
    url_index: UrlIndex
    transfer_presenter: TransferPresenter

    def present(
        self, interactor_response: show_a_account_details.Response
    ) -> ViewModel:
        transfers = self.transfer_presenter.present_transfers(
            interactor_response.transfers
        )
        return self.ViewModel(
            transfers=transfers,
            account_balance=str(round(interactor_response.account_balance, 2)),
            plot_url=self.url_index.get_line_plot_of_company_a_account(
                interactor_response.company_id
            ),
            navbar_items=[
                NavbarItem(
                    text=self.translator.gettext("Accounts"),
                    url=self.url_index.get_company_accounts_url(
                        company_id=interactor_response.company_id
                    ),
                ),
                NavbarItem(text=self.translator.gettext("Account a"), url=None),
            ],
        )
