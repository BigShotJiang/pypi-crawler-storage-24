from dataclasses import dataclass

from workers_control.core.email_notifications import AccountantInvitation, EmailSender
from workers_control.core.repositories import DatabaseGateway


@dataclass
class SendAccountantRegistrationTokenInteractor:
    @dataclass
    class Response:
        has_been_sent: bool

    @dataclass
    class Request:
        email: str

    email_sender: EmailSender
    database: DatabaseGateway

    def send_accountant_registration_token(self, request: Request) -> Response:
        if not self._is_user_existing(request.email):
            self.email_sender.send_email(
                AccountantInvitation(email_address=request.email)
            )
            return self.Response(has_been_sent=True)
        return self.Response(has_been_sent=False)

    def _is_user_existing(self, email: str) -> bool:
        return bool(self.database.get_accountants().with_email_address(email))
