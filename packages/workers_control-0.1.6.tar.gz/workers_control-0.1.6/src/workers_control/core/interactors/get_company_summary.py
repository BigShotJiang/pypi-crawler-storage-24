from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime
from decimal import Decimal
from typing import Dict, Generator, Iterable, List, Optional, Tuple
from uuid import UUID

from workers_control.core.datetime_service import DatetimeService
from workers_control.core.decimal import decimal_sum
from workers_control.core.records import Company, Plan, SocialAccounting, Transfer
from workers_control.core.repositories import DatabaseGateway
from workers_control.core.transfers import TransferType


@dataclass
class PlanDetails:
    id: UUID
    name: str
    is_active: bool
    sales_volume: Decimal
    sales_balance: Decimal
    deviation_relative: Decimal


@dataclass
class AccountBalances:
    means: Decimal
    raw_material: Decimal
    work: Decimal
    product: Decimal


@dataclass
class Expectations:
    means: Decimal
    raw_material: Decimal
    work: Decimal
    product: Decimal


@dataclass
class Supplier:
    company_id: UUID
    company_name: str
    volume_of_sales: Decimal


@dataclass
class GetCompanySummarySuccess:
    id: UUID
    name: str
    email: str
    registered_on: datetime
    expectations: Expectations
    account_balances: AccountBalances
    deviations_relative: List[Decimal]
    plan_details: List[PlanDetails]
    suppliers_ordered_by_volume: List[Supplier]


GetCompanySummaryResponse = Optional[GetCompanySummarySuccess]


@dataclass
class GetCompanySummaryInteractor:
    social_accounting: SocialAccounting
    database_gateway: DatabaseGateway
    datetime_service: DatetimeService

    def execute(self, company_id: UUID) -> GetCompanySummaryResponse:
        record = (
            self.database_gateway.get_companies()
            .with_id(company_id)
            .joined_with_email_address()
            .first()
        )
        if not record:
            return None
        company, email = record
        plans = (
            self.database_gateway.get_plans()
            .planned_by(company.id)
            .ordered_by_creation_date(ascending=False)
        )
        supply = self._get_suppliers_and_supply_volume(
            (transfer, company)
            for _, transfer, company in self.database_gateway.get_productive_consumptions()
            .where_consumer_is_company(company=company_id)
            .joined_with_transfer_and_provider()
        )
        expectations = self._get_expectations(company)
        account_balances = self._get_account_balances(company)
        return GetCompanySummarySuccess(
            id=company.id,
            name=company.name,
            email=email.address,
            registered_on=company.registered_on,
            expectations=expectations,
            account_balances=account_balances,
            deviations_relative=[
                self._calculate_deviation(
                    asdict(account_balances)[account_name],
                    asdict(expectations)[account_name],
                )
                for account_name in ["means", "raw_material", "work", "product"]
            ],
            plan_details=[
                self._get_plan_details(plan=plan, provided_amount=provided_amount)
                for plan, provided_amount in plans.joined_with_provided_product_amount()
            ],
            suppliers_ordered_by_volume=list(
                sorted(supply, key=lambda supplier: -supplier.volume_of_sales)
            ),
        )

    def _get_plan_details(self, plan: Plan, provided_amount: int) -> PlanDetails:
        expected_sales_volume = plan.expected_sales_value
        certificates_from_sales = (
            plan.expected_sales_value
            * Decimal(provided_amount)
            / Decimal(plan.prd_amount)
        )
        sales_balance_of_plan = certificates_from_sales - expected_sales_volume
        now = self.datetime_service.now()
        return PlanDetails(
            id=plan.id,
            name=plan.prd_name,
            is_active=plan.is_active_as_of(now),
            sales_volume=expected_sales_volume,
            sales_balance=sales_balance_of_plan,
            deviation_relative=self._calculate_deviation(
                sales_balance_of_plan, expected_sales_volume
            ),
        )

    def _get_expectations(self, company: Company) -> Expectations:
        """
        Companies are expected to spend as much for p, r and a as they plan.
        They are expected to sell as much product as they plan productively.
        """
        credits = [
            decimal_sum(
                map(
                    lambda t: t.value,
                    self.database_gateway.get_transfers().where_account_is_creditor(
                        account
                    ),
                )
            )
            for account in company.accounts()[:3]
        ]
        expected_sales = decimal_sum(
            map(
                lambda t: (
                    t.value
                    if t.type
                    in [
                        TransferType.credit_p,
                        TransferType.credit_r,
                        TransferType.credit_a,
                    ]
                    else Decimal(0)
                ),
                self.database_gateway.get_transfers().where_account_is_debtor(
                    company.product_account
                ),
            )
        )
        return Expectations(
            means=credits[0],
            raw_material=credits[1],
            work=credits[2],
            product=-expected_sales,
        )

    def _get_account_balances(self, company: Company) -> AccountBalances:
        company_accounts = self.database_gateway.get_accounts().with_id(
            *company.accounts()
        )
        balances = dict(
            (account.id, balance)
            for account, balance in company_accounts.joined_with_balance()
        )
        return AccountBalances(
            balances[company.means_account],
            balances[company.raw_material_account],
            balances[company.work_account],
            balances[company.product_account],
        )

    def _calculate_deviation(
        self,
        account_balance: Decimal,
        expectation: Decimal,
    ) -> Decimal:
        if expectation == 0:
            if account_balance == 0:
                return Decimal(0)
            else:
                return Decimal("Infinity")
        else:
            return abs(account_balance / expectation) * 100

    def _get_suppliers_and_supply_volume(
        self, supply: Iterable[Tuple[Transfer, Company]]
    ) -> Generator[Supplier, None, None]:
        volume_by_company_id: Dict[UUID, Decimal] = defaultdict(lambda: Decimal(0))
        suppliers_by_id: Dict[UUID, Company] = dict()
        for transfer, company in supply:
            suppliers_by_id[company.id] = company
            volume_by_company_id[company.id] += transfer.value
        for company_id, volume in volume_by_company_id.items():
            yield Supplier(
                company_id=company_id,
                company_name=suppliers_by_id[company_id].name,
                volume_of_sales=volume,
            )
