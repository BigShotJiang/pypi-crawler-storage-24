from typing import Any
from uuid import UUID

from flask import Flask, session
from flask_talisman import Talisman
from jinja2 import StrictUndefined

from workers_control.db.db import Database
from workers_control.flask.babel import initialize_babel
from workers_control.flask.config.checks import ConfigValidator
from workers_control.flask.config.loader import load_configuration
from workers_control.flask.config.options import CONFIG_OPTIONS
from workers_control.flask.database import run_db_migrations
from workers_control.flask.extensions import csrf_protect, login_manager
from workers_control.flask.filters import icon_filter
from workers_control.flask.flask_session import FlaskLoginUser
from workers_control.flask.profiling import initialize_flask_profiler  # type: ignore


def create_app(
    dev_or_test_config: Any = None,
    template_folder: Any = None,
) -> Flask:
    if template_folder is None:
        template_folder = "templates"

    app = Flask(
        __name__, instance_relative_config=False, template_folder=template_folder
    )

    load_configuration(app=app, dev_or_test_config=dev_or_test_config)

    config_validator = ConfigValidator(app.config, CONFIG_OPTIONS)
    config_validator.validate_options()
    config_validator.validate_option_types()

    db = Database()
    db.configure(uri=app.config["SQLALCHEMY_DATABASE_URI"])
    run_db_migrations(app.config, db)

    # Where to redirect the user when he attempts to access a login_required
    # view without being logged in.
    login_manager.login_view = "auth.start"

    if app.config["DEBUG"]:
        app.jinja_env.undefined = StrictUndefined
    else:
        # Init Flask-Talisman
        csp = {"default-src": ["'self'", "'unsafe-inline'"]}
        Talisman(
            app, content_security_policy=csp, force_https=app.config["FORCE_HTTPS"]
        )

    # init flask extensions
    csrf_protect.init_app(app)
    login_manager.init_app(app)
    initialize_babel(app)

    @app.teardown_appcontext
    def shutdown_session(exception: BaseException | None = None) -> None:
        db.session.remove()

    app.template_filter("icon")(icon_filter)

    with app.app_context():
        from workers_control.flask.commands import invite_accountant, run_alembic

        app.cli.command("invite-accountant")(invite_accountant)
        app.cli.command(
            "db",
            context_settings=dict(
                ignore_unknown_options=True,
                allow_extra_args=True,
                allow_interspersed_args=False,
            ),
            add_help_option=False,
        )(run_alembic)

        from workers_control.db.models import Accountant, Company, Member

        @login_manager.user_loader
        def load_user(
            user_id: str,
        ) -> FlaskLoginUser | None:
            """
            This callback is used to reload the user object from the user ID
            stored in the session.
            """
            if "user_type" in session:
                uuid = UUID(user_id)
                user_type = session["user_type"]
                if user_type == "member":
                    member_orm = db.session.query(Member).get(uuid)
                    return FlaskLoginUser(member_orm) if member_orm else None
                elif user_type == "company":
                    company_orm = db.session.query(Company).get(uuid)
                    return FlaskLoginUser(company_orm) if company_orm else None
                elif user_type == "accountant":
                    accountant_orm = db.session.query(Accountant).get(uuid)
                    return FlaskLoginUser(accountant_orm) if accountant_orm else None
            return None

        # register blueprints
        from .context_processors import add_template_variables
        from .routes import accountant as accountant_routes
        from .routes import company as company_routes
        from .routes import healthcheck as healthcheck_routes
        from .routes import member as member_routes
        from .routes import user as user_routes
        from .routes.auth import routes as auth_routes
        from .routes.plots import routes as plots_routes

        app.register_blueprint(auth_routes.auth)
        app.register_blueprint(plots_routes.plots)
        app.register_blueprint(
            company_routes.blueprint.main_company, url_prefix="/company"
        )
        app.register_blueprint(
            member_routes.blueprint.main_member, url_prefix="/member"
        )
        app.register_blueprint(accountant_routes.blueprint.main_accountant)
        app.register_blueprint(user_routes.blueprint, url_prefix="/user")
        app.register_blueprint(healthcheck_routes.blueprint.healthcheck_blueprint)
        app.context_processor(add_template_variables)

        # The profiler needs to be initialized last because all the
        # routes to monitor need to present in the app at that point
        initialize_flask_profiler(app)

        return app
