from dataclasses import dataclass

from flask import render_template

from workers_control.web.email import MailService
from workers_control.web.email.accountant_invitation_presenter import ViewModel


@dataclass
class AccountantInvitationEmailViewImpl:
    mail_service: MailService

    def render_accountant_invitation_email(self, view_model: ViewModel) -> None:
        html = render_template(
            "auth/accountant_invitation.html",
            view_model=view_model,
        )
        self.mail_service.send_message(
            subject=view_model.subject,
            recipients=view_model.recipients,
            html=html,
            sender=view_model.sender,
        )
