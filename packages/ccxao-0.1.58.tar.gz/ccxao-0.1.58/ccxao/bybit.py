# pylint: disable=too-many-lines
"""
Ccxao - cryptoCurrency Exchange algoritmic order
Bybit auxiliary functions

Author: Ricardo Marcelo Alvarez
Date: 2024-06-20
"""

import os
import sys
import json
import time
import datetime # pylint: disable=unused-import
import copy
import threading
import builtins
import pickle
import logging
import logging.handlers
import queue
from typing import List, Optional # pylint: disable=unused-import
import hmac
import pprint # pylint: disable=unused-import
import websocket
import ccxt
import ccxao.ccxao_common_functions as ccf
from ccxao.bybit_manage_orders import CcxaoBybitManageOrders

class BybitCcxaoAuxClass():
    """
    BybitCcxaoAuxClass
    ==================
    This class provides helper functions specifically designed for the Ccxao class
    related to Bybit exchange operations. 

    It includes methods for retrieving market data, managing orders, and other 
    utility functions that facilitate trading operations on Bybit.
    """

    # pylint: disable=unused-argument
    def __init__(self,\
                 api_key: str=None,\
                 api_secret: str=None,\
                 api_uid: str=None,\
                 api_password: str=None,\
                 sandbox: bool=False,\
                 trading_type: str='SPOT',\
                 debug: bool=False,\
                 var_dir: str=None,\
                 log_handler: logging.Logger = None,\
                 err_handler: logging.Logger = None):
        """
        BybitCcxaoAuxClass constructor
        ==============================
        Initializes a new instance of the BybitCcxaoAuxClass.

        :param api_key: str
            API key for authenticating with the exchange.
        :param api_secret: str
            API secret for authenticating with the exchange.
        :param api_uid: str
            API uid, only required for some exchanges.
        :param api_password: str
            API password, only required for some exchanges.
        :param sandbox: bool
            Indicates whether to use the sandbox environment (default is False).
        :param trading_type: str
            Type of trading, valid only as 'SPOT' (default is 'SPOT').
        :param debug: bool
            If True, enables verbose output for debugging (default is False).
        :param var_dir: str
            Directory for variable storage, default is '/var/lib/ccxao'.
        :param log_handler: logging.Logger
            Logger for handling logs.
        :param err_handler: logging.Logger
            Logger for handling errors.

        Returns:
        --------
        Ccxao
            A new instance of the BybitCcxaoAuxClass class.
        """

        self.__api_key = api_key
        self.__api_secret = api_secret
        self.__exchange = 'bybit'
        self.__trading_type = trading_type
        self.__ws = None
        self.__ws_thread = None
        self.__ws_ping_thread = None
        self.__ws_url = None
        self.__base_ws_url = 'wss://stream.bybit.com/v5/private'
        if sandbox:
            self.__base_ws_url = 'wss://stream-testnet.bybit.com/v5/private'

        self.__ws_url = self.__base_ws_url

        self.__custom_rate_limit = 500

        self.__log_logger = log_handler
        self.__err_logger = err_handler

        self.__var_dir = var_dir

        if self.__var_dir is None:
            self.__var_dir = '/var/lib/ccxao/bybit'

        self.__var_dir = os.path.join(self.__var_dir, 'aux_vars')

        if not os.path.exists(self.__var_dir):
            os.makedirs(self.__var_dir)

        self.__main_thread = None
        self.__main_thread_running = False
        self.__main_thread_sleep = 1

        self.__exchange_info = None
        self.__exchange_info_time = 0
        self.__exchange_info_time_limit = 7200
        self.__exchange_trading_fees = None
        self.__exchange_symbols_prices = None
        self.__exchange_balances = None
        self.__exchange_usdt_balances = None

        self.__exchange_symbols_info = None

        self.__exchange_check_orders_time = 0
        self.__exchange_check_orders_time_limit = 7200

        self.__events_queue = None
        self.__events_queue_file = f'{self.__var_dir}/events_queue.pkl'

        self.__lock_main_thread = threading.Lock()
        self.__lock_orders = threading.Lock()
        self.__lock_events_queue = threading.Lock()

        self.__load_queue()

        self.__orders = {}
        self.__orders_file = f'{self.__var_dir}/orders.pkl'

        if not self.__load_orders():
            self.__orders = {}

        self.__debug = debug
        self.__bmo = None

        self.__api_client = None
        self.__api_client_orders = None
        self.__conn_id = None
        self.__lock_conn_id = threading.Lock()
        self.__conn_id_limit_time = 95
        self.__ws_private_channels = ['order', 'wallet']

        try:
            # self.__api_client = Spot(api_key=api_key,\
            #                          api_secret=api_secret,\
            #                          base_url=self.__api_url)
            __api_conn_data = {
                'apiKey': self.__api_key,
                'secret': self.__api_secret,
                'enableRateLimit': True,
                'verbose': self.__debug,
                'options': {
                    'defaultType': self.__trading_type.lower()
                }
            }

            __api_conn_data_orders = {
                'apiKey': self.__api_key,
                'secret': self.__api_secret,
                'rateLimit': self.__custom_rate_limit,
                'enableRateLimit': True,
                'verbose': self.__debug,
                'options': {
                    'defaultType': self.__trading_type.lower()
                }
            }

            self.__api_client = ccxt.bybit(__api_conn_data)
            self.__api_client_orders = ccxt.bybit(__api_conn_data_orders)

            if sandbox:
                self.__api_client.set_sandbox_mode(True)
                self.__api_client_orders.set_sandbox_mode(True)

            self.__bmo = CcxaoBybitManageOrders(api_key=self.__api_key,
                                                api_secret=self.__api_secret,
                                                var_dir=self.__var_dir,
                                                sandbox=sandbox,
                                                ccxt_bybit_inst=self.__api_client_orders,
                                                debug=self.__debug,
                                                log_handler=self.__log_logger,
                                                err_handler=self.__err_logger)

        except Exception as e: # pylint: disable=broad-except
            print(f'Error: exception {e}')

        if not self.__check_exchange_connection():
            raise ValueError(f'The exchange connection {str(self.__exchange)} failed.')

        self.__api_client.load_markets()

    def __check_exchange_connection(self):
        """
        __check_exchange_connection
        ===========================

        This is an internal function that checks if the connection to the exchange
        can be established successfully.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            True if the connection is possible, or False otherwise.
        """
        result = False
        __data = None

        if self.__api_client is not None:
            try:
                __data = self.__api_client.account()
                result = True
            except Exception as e: # pylint: disable=broad-except
                result = False
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, error: {e}'
                if self.__err_logger is not None:
                    self.__err_logger.error(err_msg)
                else:
                    print(err_msg)

        return result

    def __del__(self):
        """
        __del__
        =======

        Destructor for the BybitCcxaoAuxClass instance. This method is called when 
        the instance is about to be destroyed. It is responsible for saving any 
        pending orders and the current state of the queue to ensure no data is lost.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.
        """

        self.__save_orders()
        self.__save_queue()

    def __save_orders(self):
        """
        __save_orders
        =============
        This internal function saves the current state of orders to a file using 
        pickle serialization. If the operation is successful, it returns True; 
        otherwise, it returns False.

        This method handles any exceptions that occur during the file operation 
        and logs the error if an error logger is provided.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            True if orders were successfully saved, False otherwise.
        """

        result = False

        try:
            with builtins.open(self.__orders_file, 'wb') as orders_file:
                pickle.dump(self.__orders, orders_file)
            result = True
        except Exception as e: # pylint: disable=broad-except
            result = False
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, error: {e}'
            if self.__err_logger is not None:
                self.__err_logger.error(err_msg)

        return result

    def __load_orders(self):
        """
        __load_orders
        =============
        This internal function loads orders from a file using pickle deserialization.
        It checks if the file exists and whether it contains data. If successful,
        the orders are loaded into the instance; otherwise, an empty dictionary
        is assigned to the orders.

        If any exceptions occur during the file operation, they are logged
        if an error logger is provided.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            True if orders were successfully loaded or if the orders file did not exist, 
            False if there was an error during loading or if the file was empty.
        """
        result = False

        if os.path.exists(self.__orders_file):
            try:
                if os.path.getsize(self.__orders_file) > 0:
                    with builtins.open(self.__orders_file, 'rb') as orders_file:
                        self.__orders = pickle.load(orders_file)
                    result = True
                else:
                    self.__orders = {}
                    result = False
            except Exception as e: # pylint: disable=broad-except
                if self.__err_logger is not None:
                    __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                    err_msg = f'Found error in {__l_function}, error: {e}'
                    self.__err_logger.error(err_msg)

                self.__orders = {}
                result = False
        else:
            self.__orders = {}
            result = True

        if self.__orders is None or not isinstance(self.__orders, dict):
            self.__orders = {}
            result = True

        return result

    def __save_queue(self):
        """
        __save_queue
        ============

        This internal function saves the current state of the events queue 
        to a file using pickle serialization. It converts the queue into a 
        list and writes it to the specified file. 

        If an error occurs during the file operation, it is logged 
        if an error logger is provided.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            True if the queue was successfully saved, 
            False if there was an error during the saving process.
        """
        result = False
        try:
            __data = list(self.__events_queue.queue)
            with builtins.open(self.__events_queue_file, 'wb') as queue_file:
                pickle.dump(__data, queue_file)
            result = True

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, error: {e}'
                self.__err_logger.error(err_msg)
            result = False

        return result

    def __load_queue(self):
        """
        __load_queue
        ============

        This internal function loads the state of the events queue 
        from a file using pickle deserialization. It initializes 
        the events queue from the contents of the file if it exists 
        and is not empty. If an error occurs during the file operation, 
        the queue is reset to a new instance, and the error is logged 
        if an error logger is provided.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            True if the queue was successfully loaded, 
            False if there was an error during the loading process 
            or if the file was empty.
        """

        result = False

        with self.__lock_events_queue:
            if os.path.exists(self.__events_queue_file):
                try:
                    if os.path.getsize(self.__events_queue_file) > 0:
                        with builtins.open(self.__events_queue_file, 'rb') as queue_file:
                            data = pickle.load(queue_file)
                        self.__events_queue = queue.Queue()
                        for item in data:
                            self.__events_queue.put(item)
                        result = True
                    else:
                        self.__events_queue = queue.Queue()
                        result = False

                except Exception as e: # pylint: disable=broad-except
                    self.__events_queue = queue.Queue()
                    if self.__err_logger is not None:
                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        err_msg = f'Found error in {__l_function}, error: {e}'
                        self.__err_logger.error(err_msg)

                    result = False
            else:
                self.__events_queue = queue.Queue()

            if self.__events_queue is None or not isinstance(self.__events_queue, queue.Queue):
                self.__events_queue = queue.Queue()

        return result

    def __ws_auth_request(self):
        """
        __ws_auth_request
        =================

        Sends an authentication request over the WebSocket connection.

        Notes:
        ------
        This method constructs an authentication message with the current 
        timestamp and a signature generated using HMAC with the API secret. 
        The message is then sent over the WebSocket connection to authenticate 
        the user.

        Parameters:
        -----------
        None

        Returns:
        --------
        None
            This method does not return a value. It sends the authentication 
            request to the WebSocket server.        
        """
        expires = int((time.time() + self.__conn_id_limit_time) * 1000)
        signature = str(hmac.new(\
            bytes(self.__api_secret, "utf-8"),\
            bytes(f"GET/realtime{expires}",\
            "utf-8"),\
            digestmod="sha256").hexdigest())
        __req_auth = {
                        "op": "auth",
                        "args": [
                        self.__api_key,
                        expires,
                        signature
                        ]
                    }

        __req_auth = json.dumps(__req_auth, sort_keys=False)

        self.__ws.send(__req_auth)

    def __ws_open_handler(self, ws):
        """
        __ws_open_handler
        =================
        """
        self.__ws_auth_request()

    def __ws_on_close_handler(self, ws, close_status_code, close_msg):

        if self.__err_logger is not None\
            and (close_status_code is not None or close_msg is not None):
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, close_status_code: {close_status_code}'
            err_msg += f', close_msg: {close_msg}'
            self.__err_logger.error(err_msg)

    def __ws_on_reconnect_handler(self, ws):
        self.__ws_auth_request()

    def __ws_subscribe_channels_request(self):
        """
        __ws_subscribe_channels_request
        ===============================

        Sends a request to subscribe to specified WebSocket channels.

        Notes:
        ------
        This method constructs a subscription message using the private 
        channels defined in the instance variable `__ws_private_channels` 
        and sends it over the WebSocket connection to subscribe to those channels.

        Parameters:
        -----------
        None

        Returns:
        --------
        None
            This method does not return a value. It sends the subscription 
            request to the WebSocket server.        
        """
        __req_subs = {
            'op': 'subscribe',
            'args': self.__ws_private_channels
            }

        __req_subs = json.dumps(__req_subs, sort_keys=False)
        self.__ws.send(__req_subs)

    def __ws_unsubscribe_chanels_request(self):
        """
        __ws_unsubscribe_chanels_request
        ================================

        Sends a request to unsubscribe from specified WebSocket channels.

        Notes:
        ------
        This method constructs an unsubscription message using the private 
        channels defined in the instance variable `__ws_private_channels` 
        and sends it over the WebSocket connection to unsubscribe from those channels.

        Parameters:
        -----------
        None

        Returns:
        --------
        None
            This method does not return a value. It sends the unsubscription 
            request to the WebSocket server.        
        """

        __req_subs = {
            'op': 'unsubscribe',
            'args': self.__ws_private_channels
            }

        __req_subs = json.dumps(__req_subs, sort_keys=False)
        self.__ws.send(__req_subs)

    def start_listen_socket(self):
        """
        start_listen_socket
        ===================

        This method initializes and starts the WebSocket connection 
        to the exchange for real-time data streaming. It sets the 
        listen key required for the WebSocket connection and starts 
        two threads: one for handling the WebSocket communication and 
        another for the main processing thread.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True indicating that the process of starting the 
            socket listener has commenced successfully.
        """
        result = True

        with self.__lock_main_thread:
            self.__main_thread_running = True

        self.__ws_thread = (
            threading.Thread(target=self.__launch_ccxao_websocket_thread,\
                             name=f'ccxao_{self.__exchange}__launch_websocket_thread')
        )

        self.__ws_thread.start()

        time.sleep(5)

        self.__ws_ping_thread = threading.Thread(target=self.__launch_ping_thread,\
                                                 name=\
                                                    f'ccxao_{self.__exchange}__launch_ping_thread')


        self.__ws_ping_thread.start()

        self.__main_thread = threading.Thread(target=self.__launch_ccxao_main_thread,\
                                              name=f'ccxao_{self.__exchange}__launch_main_thread')

        self.__main_thread.start()

        self.__bmo.start()

        return result

    def __check_orders(self):
        """
        __check_orders
        ==============

        This internal function checks the status of existing orders 
        in the exchange. It determines if any orders have been open 
        for longer than the specified time limit. If so, it requests 
        the latest status for those orders.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True if the order check was executed successfully, 
            regardless of whether any orders were updated or not.
        """

        result = True

        __exchange_check_orders_time_diff = (
            abs(int(round(time.time())) - self.__exchange_check_orders_time)
        )

        if __exchange_check_orders_time_diff > self.__exchange_check_orders_time_limit:
            __check_orders = {}
            __req_keys = {
                'status': (str),
                'symbol': (str),
                'timestamp': (int, str)
            }
            with self.__lock_orders:
                for __order_id, __order_data in self.__orders.items():
                    if __order_data is not None\
                        and isinstance(__order_data, dict):

                        if all((key in __order_data\
                                and __order_data[key] is not None\
                                and isinstance(__order_data[key], types))\
                                    for key, types in __req_keys.items()):
                            __status = __order_data['status']
                            __symbol = __order_data['symbol']
                            __timestamp = __order_data['timestamp']

                            __order_tstamp_diff = (
                                abs(round((int(__timestamp)/1000)\
                                          - self.__exchange_check_orders_time))
                            )

                            if __status == 'open'\
                                and __order_tstamp_diff > self.__exchange_check_orders_time_limit:
                                __check_orders[__order_id] = __symbol

            self.__exchange_check_orders_time = int(round(time.time()))

            for __order_id, __symbol in __check_orders.items():
                __order = self.__get_order(__order_id, __symbol)

        return result

    def __launch_ccxao_main_thread(self):
        """
        __launch_ccxao_main_thread
        ==========================

        This internal function runs the main loop for managing the 
        connection to the exchange. It handles the renewal of the 
        listen key, checks the status of existing orders, updates 
        exchange information, and processes events from the event queue.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True if the main thread is executed successfully.
        """
        result = True

        __to_run = True

        self.__check_orders()

        while __to_run:

            self.__check_orders()

            __exchange_info_time_diff = abs(int(round(time.time())) - self.__exchange_info_time)
            if __exchange_info_time_diff > self.__exchange_info_time_limit:
                with self.__lock_main_thread:
                    self.__exchange_info = self.__api_client.fetch_markets()
                    self.__exchange_symbols_info = self.__get_exchange_symbols_info()
                    self.__exchange_trading_fees = self.__get_trading_fees()
                    self.__exchange_symbols_prices = self.__get_all_symbols_prices()
                    self.__exchange_balances = self.__get_balances()
                    self.__exchange_usdt_balances = self.__get_usdt_balances()
                    self.__exchange_info_time = abs(int(round(time.time())))

            with self.__lock_events_queue:
                if self.__events_queue.qsize() > 0:
                    __event = self.__events_queue.get()
                    self.__save_queue()
                    self.__proc_event(__event)

            if self.__events_queue.qsize() == 0:
                with self.__lock_main_thread:
                    __to_run = self.__main_thread_running

            time.sleep(self.__main_thread_sleep)

        return result

    def force_reload_exchange_info(self):
        """
        force_reload_exchange_info
        ==========================
        
        Forces a reload of the exchange information by resetting the 
        timestamp that tracks the last time exchange information was 
        fetched. This allows the system to retrieve fresh data from 
        the exchange the next time it checks for updates.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True, indicating that the reload operation was 
            triggered successfully.
        """
        result = True
        with self.__lock_main_thread:
            self.__exchange_info_time = 0

        return result

    def __launch_ccxao_websocket_thread(self):
        """
        __launch_ccxao_websocket_thread
        ===============================

        This internal method initializes and starts the WebSocket client 
        for real-time communication with the exchange. It enables 
        debugging if specified and sets the message handler for incoming 
        WebSocket messages.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        None
        """
        with self.__lock_conn_id:
            websocket.enableTrace(self.__debug)
            self.__ws = websocket.WebSocketApp(self.__ws_url,\
                                               on_message=self.__ws_message_handler,\
                                               on_open=self.__ws_open_handler,\
                                               on_close=self.__ws_on_close_handler,\
                                               on_reconnect=self.__ws_on_reconnect_handler)

        self.__ws.run_forever(reconnect=90, ping_interval=30, ping_timeout=9)

    def __launch_ping_thread(self):
        """
        __launch_ping_thread
        ====================

        Launches a thread that periodically sends a ping request to the WebSocket server 
        to maintain the connection.

        The ping request is sent every 23 seconds to ensure that the connection remains 
        alive. The thread checks if the main thread is still running before sending 
        the ping. If the main thread is no longer running, the ping thread will stop.

        Parameters:
        -----------
        None

        Returns:
        --------
        None
            This method does not return a value. It runs in a separate thread to 
            continuously send ping requests.
        """

        __req_ping = {
            'op': 'ping'
        }

        __req_ping = json.dumps(__req_ping, sort_keys=False)

        __to_run = True
        while __to_run:
            with self.__lock_conn_id:
                self.__ws.send(__req_ping)
            with self.__lock_main_thread:
                __to_run = self.__main_thread_running

            time.sleep(23)

    def stop_listen_socket(self):
        """
        stop_listen_socket
        ==================

        This method stops the WebSocket client from listening to incoming messages
        and terminates the associated threads. It gracefully shuts down the WebSocket
        connection and ensures that the main thread is no longer running.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True to indicate that the WebSocket client has been stopped successfully.
        """
        result = True

        self.__bmo.stop()

        with self.__lock_main_thread:
            self.__main_thread_running = False

        if self.__ws_ping_thread is not None:
            self.__ws_ping_thread.join(400)

        if self.__main_thread is not None:
            self.__main_thread.join(400)

        self.__ws.close()
        if self.__ws_thread is not None:
            self.__ws_thread.join(400)

        self.__ws = None
        return result

    def __ws_message_handler(self, _, message):
        """
        __ws_message_handler
        ====================

        This internal function handles incoming WebSocket messages. It checks if the
        received message is a valid JSON string, parses it, and adds it to the events queue
        if it contains a specific event type.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.
        _ : Any
            Unused parameter typically representing the WebSocket instance.
        message : str
            The incoming WebSocket message as a JSON string.

        Returns:
        --------
        None
            This method does not return a value.
        """
        result = None

        if ccf.is_json(message):
            __message = json.loads(message)

            if __message is not None\
                and isinstance(__message, dict)\
                and ('op' in __message or 'topic' in __message):
                with self.__lock_events_queue:
                    self.__events_queue.put(__message)
                    self.__save_queue()

        # print(f'message:\n{json.dumps(__message, indent=4)}\n')
        # print(f'message type: {type(message)}')
        # print('================================================================')

        return result

    def __proc_event(self, event):
        """
        __proc_event
        ============

        Processes incoming events from the WebSocket. Based on the event type,
        it delegates the handling to the corresponding processing method.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.
        event : dict
            The event data received from the WebSocket, containing at least an 
            event type key 'e' that determines the processing logic.

        Returns:
        --------
        Any
            The result of the event processing, which can vary depending on 
            the specific event type handled. Returns None if the event type 
            does not match any known handlers.
        """
        result = None

        __op_events = ['pong', 'auth', 'subscribe', 'unsubscribe']
        __op_topics = ['order', 'wallet']

        # pprint.pprint(event, sort_dicts=False)
        if 'op' in event and isinstance(event['op'], str) and event['op'] in __op_events:
            if event['op'] == 'auth':
                self.__proc_auth(event)
            elif event['op'] == 'pong':
                self.__proc_pong(event)
            elif event['op'] == 'subscribe':
                pass
            elif event['op'] == 'unsubscribe':
                pass

        elif 'topic' in event\
            and isinstance(event['topic'], str)\
            and event['topic'] in __op_topics\
            and 'data' in event:

            if event['topic'] == 'order'\
                and event['data'] is not None\
                and isinstance(event['data'], list)\
                and len(event['data']) > 0:

                self.__proc_order(event['data'])
            elif event['topic'] == 'wallet'\
                and event['data'] is not None\
                and isinstance(event['data'], list)\
                and len(event['data']) > 0:

                self.__proc_wallet(event['data'])

        return result

    def __proc_wallet(self, data):
        """
        __proc_wallet
        =============

        Processes wallet data received from the exchange and updates the balances 
        for each asset in both the exchange balances and USDT balances.

        :param data: (list) A list of events containing wallet data. Each event should 
                    include information about the assets in the wallet.

        The method performs the following actions:
        - Iterates through each event in the provided data.
        - Validates that the event contains the necessary information, including:
        - A list of coins.
        - Equity values for each coin.
        - Updates the balances for each coin in the exchange's balances.
        - Calculates the USDT equivalent for each asset and updates the USDT balances.
        - Computes the total USDT balance and stores it with the key '__total__'.

        :return: None
            This method does not return a value. It modifies the instance's 
            __exchange_balances and __exchange_usdt_balances attributes directly.
        """

        for event in data:
            if all([
                event is not None,
                isinstance(event, dict),
                'coin' in event,
                isinstance(event['coin'], list),
                event['coin']
                ]):

                for coin_data in event['coin']:
                    if coin_data is not None and isinstance(coin_data, dict):
                        if 'coin' in coin_data\
                            and 'equity' in coin_data\
                            and isinstance(coin_data['coin'], str)\
                            and len(coin_data['coin']) > 0\
                            and isinstance(coin_data['equity'], (str, float, int)):

                            with self.__lock_main_thread:
                                self.__exchange_balances[coin_data['coin']] = (
                                    float(coin_data['equity'])
                                )

                                __symbol = coin_data['coin'] + '/USDT'

                                if coin_data['coin'] == 'USDT':
                                    self.__exchange_usdt_balances[coin_data['coin']] = (
                                        round(self.__exchange_balances[coin_data['coin']], 2)
                                    )

                                elif self.__exchange_symbols_prices is not None\
                                    and isinstance(self.__exchange_symbols_prices, dict)\
                                    and __symbol in self.__exchange_symbols_prices\
                                    and self.__exchange_symbols_prices[__symbol] is not None:

                                    self.__exchange_usdt_balances[coin_data['coin']] = (
                                        round(self.__exchange_balances[coin_data['coin']]\
                                                * self.__exchange_symbols_prices[__symbol], 2)
                                    )

                                __total = 0
                                for __asset, __balance in self.__exchange_usdt_balances.items():
                                    if __asset != '__total__':
                                        __total += __balance

                                self.__exchange_usdt_balances['__total__'] = round(__total, 2)

    def __proc_order(self, data):
        """
        __proc_order
        ============
        
        Processes order data received from the exchange and updates the order 
        information based on the current status of each order.

        :param data: (list) A list of events containing order data. Each event should 
                    include information about the order, including its symbol, status, 
                    and identifier.

        The method performs the following actions:
        - Defines a dictionary `req_types` that maps the expected keys to their 
        corresponding data types.
        - Iterates through each event in the provided data.
        - Validates that each event contains the necessary information by checking
        the presence and type of required keys.
        - Retrieves the order symbol, status, and identifier from the event.
        - Validates the order ID and status against a predefined list of valid 
        order statuses.
        - If valid, fetches additional order data using the `__get_order` method.

        :return: (None) 
            This method does not return a value. It may update internal state 
            based on the order data processed.
        """
        result = None

        self.__bmo.proc_order(data)

        for event in data:
            __order_symbol = event.get('symbol', None)
            __order_id = event.get('orderId', None)

            if __order_symbol is not None and __order_id is not None:
                __order_data = self.__get_order(__order_id, __order_symbol)

        return result

    def __proc_pong(self, event):
        """
        __proc_pong
        ===========
        
        Processes the 'pong' response received from the WebSocket server. This 
        method checks the connection identifier in the event and handles 
        reconnection if necessary.

        :param event: (dict) A dictionary containing the 'pong' event data, 
                    which includes the connection identifier ('conn_id').

        The method performs the following actions:
        - Checks if the 'conn_id' key is present in the event and verifies that 
        its value is a non-empty string.
        - If the connection identifier from the event does not match the current 
        connection identifier, it:
            - Calls the `__ws_unsubscribe_chanels_request` method to unsubscribe 
            from the current channels.
            - Calls the `__ws_auth_request` method to re-authenticate with the 
            WebSocket server.

        :return: (None) 
            This method does not return a value. It updates the WebSocket 
            subscription status based on the connection identifier check.        
        """

        if 'conn_id' in event\
            and isinstance(event['conn_id'], str)\
            and len(event['conn_id']) > 0:
            with self.__lock_conn_id:
                if self.__conn_id != event['conn_id']:
                    self.__ws_unsubscribe_chanels_request()
                    self.__ws_auth_request()

    def __proc_auth(self, event):
        """
        __proc_auth
        ===========
        
        Processes the authentication response received from the WebSocket server. 
        This method checks if the authentication was successful and updates the 
        connection identifier accordingly.

        :param event: (dict) A dictionary containing the authentication event data, 
                    which includes a success flag and the connection identifier 
                    ('conn_id').

        The method performs the following actions:
        - Checks if the 'success' key is present in the event and verifies that 
        its value is True.
        - Ensures that the 'conn_id' key is present and its value is a non-empty 
        string.
        - If both conditions are met, it updates the current connection identifier 
        within a thread-safe context.
        - Finally, it calls the `__ws_subscribe_chanels_request` method to 
        subscribe to the private channels.

        :return: (None)
            This method does not return a value. It updates the connection identifier 
            and subscribes to channels upon successful authentication.        
        """

        if 'success' in event\
            and event['success']\
            and 'conn_id' in event\
            and isinstance(event['conn_id'], str)\
            and len(event['conn_id']) > 0:
            with self.__lock_conn_id:
                self.__conn_id = event['conn_id']
            self.__ws_subscribe_channels_request()

    def ping(self):
        """
        ping
        ====
        Sends a ping message to the WebSocket server to keep the connection alive.
        """
        return self.__bmo.ping()

    def __get_order(self, order_id, symbol):
        """
        __get_order
        ===========
        
        Retrieves the order details from the exchange for a given order ID and symbol.
        The order data is then saved to the internal orders dictionary. If successful,
        it returns the order data, otherwise, it handles any exceptions and returns None.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.
        order_id : int or str
            The unique identifier of the order to retrieve.
        symbol : str
            The trading pair symbol associated with the order.

        Returns:
        --------
        dict or None
            Returns the order data as a dictionary if successful; otherwise, returns None.
        """

        result = None

        try:
            num_tries = 0
            max_tries = 5

            __order_data = None

            while __order_data is None and num_tries <= max_tries:
                __order_data = self.__bmo.get_order(order_id, symbol)

                if __order_data is None:
                    time.sleep(0.10)
                num_tries += 1

            #pylint: disable=unsupported-membership-test
            if __order_data is not None\
                and isinstance(__order_data, dict)\
                and 'id' in __order_data\
                and 'timestamp' in __order_data\
                and 'status' in __order_data:

                __order_data.pop('info', None)

                with self.__lock_orders:
                    self.__orders[str(order_id)] = __order_data
                    self.__save_orders()
                result = __order_data

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, order_id: {order_id}'
                err_msg += f', symbol: {symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def get_orders(self, symbol: str=None, order_status: str=None, from_api: bool=False):
        """
        get_orders
        ==========
        
        Retrieves the current orders stored in the internal orders dictionary.
        This method is thread-safe and ensures that the order data is accessed
        without interference from other threads.

        Parameters:
        -----------
        self : BybitCcxaoAuxClass
            The instance of the BybitCcxaoAuxClass.

        Returns:
        --------
        dict
            A dictionary containing the current orders, where the keys are order IDs
            and the values are the corresponding order data.
        """
        result = None

        if from_api:
            try:
                __data = None

                if order_status is not None\
                    and isinstance(order_status, str):
                    if order_status.lower() == 'open':
                        __data = self.__api_client.fetch_open_orders(symbol=symbol)
                    elif order_status.lower() == 'closed':
                        __data = self.__api_client.fetch_closed_orders(symbol=symbol)

                else:
                    __data = self.__api_client.fetch_orders(symbol=symbol)
                    if __data is None or not isinstance(__data, list):
                        __data = []

                        __data_open = self.__api_client.fetch_open_orders(symbol=symbol)
                        __data_closed = self.__api_client.fetch_closed_orders(symbol=symbol)
                        if __data_open is not None and isinstance(__data_open, list):
                            __data.extend(__data_open)
                        if __data_closed is not None and isinstance(__data_closed, list):
                            __data.extend(__data_closed)

                if order_status is None:
                    __data = self.__api_client.fetch_orders(symbol=symbol)
                elif isinstance(order_status, str):
                    if order_status.lower() == 'open':
                        __data = self.__api_client.fetch_open_orders(symbol=symbol)
                    elif order_status.lower() == 'closed':
                        __data = self.__api_client.fetch_closed_orders(symbol=symbol)

                if __data is not None and isinstance(__data, list):
                    result = {}
                    for __order in __data:
                        if __order is not None and isinstance(__order, dict):
                            __order_id = __order['id']
                            result[__order_id] = __order

                if __data is not None and isinstance(__data, list):
                    result = {}
                    for __order in __data:
                        if __order is not None and isinstance(__order, dict):
                            __order_id = __order['id']
                            result[__order_id] = __order
                            result[__order_id].pop('info', None)

            except Exception as e: # pylint: disable=broad-except
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
                err_msg += f', error: {e}'
                self.__err_logger.error(err_msg)
                result = None

        else:
            with self.__lock_orders:
                result = self.__orders

        return result

    def del_order(self, order_id):
        """
        del_order
        =========

        Deletes the specified order from the internal orders dictionary.

        Parameters:
        -----------
        order_id : str, int
            The ID of the order to be deleted. This can be provided as a string or an integer.

        Returns:
        --------
        bool
            True if the order was successfully deleted, False if the order was not found
            or an error occurred during deletion.
        """
        result = self.__del_order(order_id)

        return result

    def __del_order(self, order_id):
        """
        __del_order
        ===========

        Deletes an order from the internal orders dictionary if it is not in 'open' status.

        Parameters:
        -----------
        order_id : str, int
            The ID of the order to be deleted. This can be provided as a string or an integer.

        Returns:
        --------
        bool
            True if the order was successfully deleted or was not found (already deleted).
            False if the order exists and is still in 'open' status, or if an error occurred
            during deletion.
        
        Notes:
        ------
        This method only allows the deletion of orders that are not currently 'open'. 
        If the order is in 'open' status, it will not be deleted, and the method will return False.
        Additionally, if the order is not found, it will return True to indicate that no action was
        necessary.
        """

        result = False

        try:
            with self.__lock_orders:
                # pprint.pprint(self.__orders, sort_dicts=False)
                # print(f'ENTRE: {order_id} -> {str(order_id) in self.__orders}')
                # -> {"status" in self.__orders[order_id]}
                # -> {self.__orders[order_id]["status"] != "open"}')

                if str(order_id) in self.__orders\
                    and 'status' in self.__orders[order_id]\
                    and self.__orders[str(order_id)]['status'] != 'open':

                    del self.__orders[str(order_id)]
                    self.__save_orders()
                    result = True
                elif order_id not in self.__orders:
                    result = True
                else:
                    result = False

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, order_id: {order_id}'
                err_msg += f', error: {e}'
                self.__err_logger.error(err_msg)
            # print(f'DEL EXC: {e}')
            result = False

        return result

    def get_exchange_info(self):
        """
        get_exchange_info
        =================

        Retrieves the current exchange information stored in the instance.

        Returns:
        --------
        dict or None
            Returns a dictionary containing the exchange information if available; 
            otherwise, returns None.

        Notes:
        ------
        This method is thread-safe and uses a lock to ensure that the exchange 
        information is accessed safely in a multi-threaded environment. It provides 
        a snapshot of the exchange's data as stored in the instance variable 
        `__exchange_info`.
        """
        result = None

        with self.__lock_main_thread:
            result = self.__exchange_info

        return result

    def __get_trading_fees(self):
        """
        __get_trading_fees
        ==================

        Fetches the current trading fees for each trading pair from the API client.

        Returns:
        --------
        dict or None
            A dictionary where each key is a trading symbol and its value is another 
            dictionary containing the 'maker' and 'taker' fees as floats. Returns None 
            if the trading fees could not be retrieved or if the API client does not 
            support fetching trading fees.

        Notes:
        ------
        This method checks if the API client has the `request` method 
        before attempting to call it. If the response data is valid, it processes 
        the data to return the trading fees for each trading pair.         
        """
        result = None

        if hasattr(self.__api_client, 'request'):

            endpoint = '/v5/account/fee-rate'

            params = {
                'category': 'spot',
            }

            # Ejecutar el request al endpoint
            __data_fees = self.__api_client.request(
                path=endpoint,
                api='private',
                method='GET',
                params=params
            )

            __data_fees_cmp = {}
            if __data_fees is not None\
                and isinstance(__data_fees, dict)\
                and 'retCode' in __data_fees\
                and 'result' in __data_fees\
                and int(__data_fees['retCode']) == 0:

                for __data_fee in __data_fees['result']['list']:
                    __data_fees_cmp[__data_fee['symbol']] = __data_fee

            if self.__exchange_info is not None\
                and isinstance(self.__exchange_info, list):

                result = {}

                for symbol_data in self.__exchange_info:
                    __symbol = symbol_data['symbol']
                    __base = symbol_data['base']
                    __quote = symbol_data['quote']
                    __symbol_api = f'{__base}{__quote}'

                    if __symbol_api in __data_fees_cmp:
                        result[__symbol] = None
                        result[__symbol] = {}
                        result[__symbol]['maker'] = (
                            float(__data_fees_cmp[__symbol_api]['makerFeeRate'])
                        )
                        result[__symbol]['taker'] = (
                            float(__data_fees_cmp[__symbol_api]['takerFeeRate'])
                        )

        return result

    def get_trading_fees(self):
        """
        get_trading_fees
        =================

        Retrieves the current trading fees stored in the instance.

        Returns:
        --------
        dict or None
            A dictionary containing the trading fees for each trading pair, where 
            each key is a trading symbol and its value is another dictionary 
            with 'maker' and 'taker' fees. Returns None if no trading fees are available.

        Notes:
        ------
        This method is thread-safe and uses a lock to ensure that the trading fees 
        are accessed safely across multiple threads. It provides a way to access the 
        current trading fees without directly exposing the internal data structure.
        """
        result = None

        with self.__lock_main_thread:
            result = self.__exchange_trading_fees

        return result

    def __get_exchange_symbols_info(self):
        """
        __get_exchange_symbols_info
        ===========================

        Extracts and returns information about exchange symbols from the 
        stored exchange information.

        Returns:
        --------
        dict or None
            A dictionary where each key is a trading symbol and its value 
            is a dictionary containing information about that symbol, excluding 
            the 'info' key. Returns None if no exchange information is available 
            or if the data structure is not in the expected format.

        Notes:
        ------
        This method is intended for internal use and provides a way to access 
        symbol-specific information without exposing the full data structure.
        It assumes that the exchange information has been previously loaded 
        and is stored in the instance.
        """
        result = None

        __data = None
        __data = self.__exchange_info

        if __data is not None\
            and isinstance(__data, list):

            result = {}
            for symbol_data in __data:
                __symbol = symbol_data['symbol']
                __not_info = copy.deepcopy(symbol_data)
                if 'info' in __not_info:

                    del __not_info['info']
                result[__symbol] = __not_info

        return result

    def get_exchange_symbols_info(self):
        """
        get_exchange_symbols_info
        =========================

        Retrieves information about the exchange trading symbols.

        Returns:
        --------
        dict or None
            A dictionary containing information about each trading symbol, 
            with the symbol name as the key and its associated data as the value. 
            Returns None if the symbol information is not available or has not 
            been initialized yet.

        Notes:
        ------
        This method is thread-safe and utilizes a lock to ensure consistent access 
        to the exchange symbols information. It should be used to access the most 
        recent state of the symbol information stored in the instance.
        """
        result = None

        with self.__lock_main_thread:
            result = self.__exchange_symbols_info

        return result

    def get_symbol_price(self, symbol='BTC/USDT', from_cache=True):
        """
        get_symbol_price
        ================
        Retrieves the current price of a specified trading symbol.

        Parameters:
        -----------
        symbol : str, optional
            The trading pair symbol to fetch the price for. Defaults to 'BTC/USDT'.
        from_cache : bool, optional
            Indicates whether to retrieve the price from the cached values. 
            If True, it checks the cache first before making an API call. Defaults to True.

        Returns:
        --------
        float or None
            The last price of the specified symbol if available, otherwise None.

        Notes:
        ------
        This function attempts to fetch the price of the symbol from the cache if 
        `from_cache` is set to True. If the price is not found in the cache, it 
        retrieves the price from the API client.
        """
        result = None

        if from_cache:
            with self.__lock_main_thread:
                __prices = self.__exchange_symbols_prices

            if __prices is not None and isinstance(__prices, dict) and symbol in __prices:
                result = __prices[symbol]

        if result is None:
            __ticker = self.__api_client.fetch_ticker(symbol)

            if __ticker is not None and isinstance(__ticker, dict) and 'last' in __ticker:
                result = __ticker['last']

        return result

    def __get_balances(self):
        """
        __get_balances
        ==============
        Fetches the current balances of free assets available in the account.

        Returns:
        --------
        dict or None
            A dictionary containing the asset symbols as keys and their corresponding 
            free balances as values. If no free balances are found, returns None.

        Notes:
        ------
        This function retrieves the account's free balances using the API client. 
        It processes the balance data and returns only the assets with a balance greater than zero.
        """
        result = None

        __balance_data = self.__api_client.fetch_balance()

        if __balance_data is not None\
            and isinstance(__balance_data, dict)\
            and 'free' in __balance_data\
            and __balance_data['free'] is not None\
            and isinstance(__balance_data['free'], dict):

            result = {}

            for asset, balance in __balance_data['free'].items():
                if balance > 0:
                    result[asset] = balance

        return result

    def get_balances(self):
        """
        get_balances
        ============
        Retrieves the current balances of free assets from the exchange.

        Returns:
        --------
        dict
            A dictionary containing the asset symbols as keys and their corresponding 
            balances as values. If there are no balances, an empty dictionary is returned.

        Notes:
        ------
        This method uses the API client to fetch the account's free balances. The result 
        is processed to return all available asset balances, even if they are zero.
        """
        result = None

        with self.__lock_main_thread:
            result = self.__exchange_balances

        return result

    def __get_usdt_balances(self):
        """
        __get_usdt_balances
        ====================
        
        Calculates the USDT equivalent of the current asset balances based on their prices.

        Returns:
        --------
        dict or None
            A dictionary containing asset symbols as keys and their corresponding USDT 
            balances as values. The total USDT balance is also included with the key 
            '__total__'. If no balances are available, returns None.

        Notes:
        ------
        This method calculates the value of each asset in terms of USDT by fetching the 
        current asset prices and multiplying them by the asset balances. If no balances 
        or prices are available, the method will return None.
        """
        result = None

        __total = 0

        if self.__exchange_balances is not None\
            and isinstance(self.__exchange_balances, dict)\
            and self.__exchange_symbols_prices is not None\
            and isinstance(self.__exchange_symbols_prices, dict):
            result = {}
            for __asset, __balance in self.__exchange_balances.items():
                if __asset is not None and __balance is not None:
                    __symbol = __asset + '/USDT'

                    if __asset == 'USDT':
                        result[__asset] = round(__balance, 2)
                        __total += result[__asset]

                    elif self.__exchange_symbols_prices is not None\
                        and isinstance(self.__exchange_symbols_prices, dict)\
                        and __symbol in self.__exchange_symbols_prices\
                        and self.__exchange_symbols_prices[__symbol] is not None:

                        result[__asset] = (
                            round(__balance * self.__exchange_symbols_prices[__symbol], 2)
                        )
                        __total += result[__asset]

            result['__total__'] = round(__total,2)

        return result

    def get_usdt_balances(self):
        """
        get_usdt_balances
        =================

        Retrieves the current USDT balances for all assets in the exchange.

        Returns:
        --------
        dict or None
            A dictionary containing asset symbols as keys and their corresponding USDT 
            balances as values. If no USDT balances are available, returns None.

        Notes:
        ------
        This method fetches the current USDT balances for all assets held in the account. 
        It processes the available balances and converts them into their equivalent USDT values 
        based on the current market price of each asset.
        """
        result = None
        with self.__lock_main_thread:
            result = self.__exchange_usdt_balances

        return result

    def get_exchange_tickers(self):
        """
        get_exchange_tickers
        ====================

        Retrieves the current ticker information for all trading pairs available on the exchange.

        Returns:
        --------
        dict or None
            A dictionary containing ticker information for all trading pairs. If no tickers 
            are available, returns None.

        Notes:
        ------
        This method fetches the latest ticker data from the API client, which includes 
        various market statistics such as last price, bid/ask prices, volume, etc., for 
        each trading pair on the exchange.
        """
        result = None

        __tickers = self.__api_client.fetch_tickers()

        if __tickers is not None and isinstance(__tickers, dict):
            result = {}
            for __symbol, __ticker in __tickers.items():

                if __ticker is not None and isinstance(__ticker, dict):
                    __ticker.pop('info', None)
                    result[__symbol] = __ticker

        return result

    def __get_all_symbols_prices(self):
        """
        __get_all_symbols_prices
        ========================

        Fetches the current prices for all trading pairs available on the exchange.

        Returns:
        --------
        dict or None
            A dictionary containing trading pair symbols as keys and their last traded prices 
            as values. If no prices are available, returns None.

        Notes:
        ------
        This method retrieves the latest prices for all available trading pairs on the exchange 
        by fetching ticker information from the API client. The returned data is processed 
        to extract the last traded price for each trading pair.
        """
        result = None

        __tickers = self.__api_client.fetch_tickers()

        if __tickers is not None and isinstance(__tickers, dict):
            result = {}
            for __symbol, __ticker in __tickers.items():

                if __ticker is not None and isinstance(__ticker, dict) and 'last' in __ticker:
                    result[__symbol] = __ticker['last']

        return result

    def get_order(self, order_id, order_symbol):
        """
        get_order
        =========

        Retrieves the order data for a specific order.

        Parameters:
        -----------
        order_id : str or int
            The unique identifier for the order.
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').

        Returns:
        --------
        dict or None
            A dictionary containing the order data if found, or None if an error 
            occurred while fetching the order.

        Notes:
        ------
        This method calls the internal `__get_order` function to retrieve the 
        order information for the specified order ID and symbol.
        """

        result = self.__get_order(order_id, order_symbol)

        return result

    def cancel_order(self, order_id, order_symbol):
        """
        cancel_order
        ============

        Cancels an existing order on the exchange.

        Parameters:
        -----------
        order_id : str or int
            The unique identifier of the order to be canceled.
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').
        order_params : dict, optional
            Additional parameters for canceling the order. Default is None.

        Returns:
        --------
        bool
            True if the order was successfully canceled, or False if an error occurred 
            or the order was not found.

        Notes:
        ------
        This method cancels an order by calling the `cancel_order` function of the API client. 
        It also logs the operation and saves the updated order data if the cancellation is
        successful.
        """

        result = False

        try:
            result = self.__bmo.cancel_order(order_id=order_id, order_symbol=order_symbol)
            __order_data = self.__bmo.get_order(order_id=order_id, order_symbol=order_symbol)

            if __order_data is not None\
                and isinstance(__order_data, dict)\
                and 'id' in __order_data\
                and 'timestamp' in __order_data\
                and 'status' in __order_data:

                __order_data.pop('info', None)

                with self.__lock_orders:
                    self.__orders[str(__order_data['id'])] = __order_data
                    self.__save_orders()

                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                log_msg = f'{__l_function}, exchange: {self.__exchange}'
                log_msg += f', symbol: {order_symbol}, result: {result}'
                self.__log_logger.info(log_msg)

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, order_id: {order_id}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = False

        return result

    def create_order(self,\
                     order_symbol: str='BTC/USDT',\
                     order_side: str='buy',\
                     order_amount: float=0,\
                     order_price: float=0,\
                     order_type: str='limit_maker',\
                     order_params: dict=None):
        """
        create_order
        ============
        
        Creates a new order on the exchange.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').
        order_side : str
            The side of the order, either 'buy' or 'sell'.
        order_amount : float
            The amount to buy or sell. Must be greater than 0.
        order_price : float
            The price at which to buy or sell. Must be greater than 0.
        order_type : str
            The type of order; only 'limit' or 'limit_maker' are allowed.
        order_params : dict, optional
            Additional parameters for the order. Default is None.

        Returns:
        --------
        dict or None
            Returns a dictionary with the order data if the order was created successfully, 
            or None if an error occurred.

        Notes:
        ------
        This method sends a new order request to the exchange using the `create_order` function of 
        the API client. It also saves the order data and logs the operation. If `order_type` is 
        'limit_maker', the `timeInForce` parameter is removed from `order_params` if present.
        """

        result = None
        if order_params is None:
            order_params = {}

        order_tif = order_params.get('timeInForce', 'GTC')


        try:
            __order_data = self.__bmo.create_order(order_symbol=order_symbol,
                                                   order_side=order_side,
                                                   order_amount=order_amount,
                                                   order_price=order_price,
                                                   order_type=order_type,
                                                   time_in_force=order_tif)

            if __order_data is not None\
                and isinstance(__order_data, dict)\
                and 'id' in __order_data\
                and 'timestamp' in __order_data\
                and 'status' in __order_data:

                __order_id = __order_data['id']
                __order_data = self.get_order(__order_id, order_symbol)

                if isinstance(__order_data, dict):
                    __order_data.pop('info', None)

                with self.__lock_orders:
                    self.__orders[str(__order_id)] = __order_data
                    self.__save_orders()

                result = __order_data

                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                log_msg = f'{__l_function}, exchange: {self.__exchange}'
                log_msg += f', symbol: {order_symbol}, order_side: {order_side}'
                log_msg += f', order_amount: {order_amount}, order_price: {order_price}'
                log_msg += f', order_type: {order_type}'
                self.__log_logger.info(log_msg)

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
                err_msg += f', symbol: {order_symbol}, order_side: {order_side}'
                err_msg += f', order_amount: {order_amount}, order_price: {order_price}'
                err_msg += f', order_type: {order_type}, ERROR: {e}'
                self.__err_logger.error(err_msg)
            # print(f'CREATE ORDER ERROR: {e}')
            result = None

        return result

    def amount_to_precision(self, order_symbol, order_amount):
        """
        amount_to_precision
        ===================

        Rounds the order amount to the appropriate precision for the specified symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').
        order_amount : float
            The amount to round. Must be greater than 0.

        Returns:
        --------
        float or None
            Returns the rounded amount to the precision required for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method first loads the markets from the API client and then calls 
        the `amount_to_precision` method of the API client to round the order amount. 
        If an error occurs during this process, it logs the error and returns None.
        """
        result = None

        try:
            self.__api_client.load_markets()
            result = self.__api_client.amount_to_precision(order_symbol, order_amount)

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)

            result = None

        return result

    def price_to_precision(self, order_symbol, order_price):
        """
        price_to_precision
        ==================

        Rounds the order price to the appropriate precision for the specified symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').
        order_price : float
            The price to round. Must be greater than 0.

        Returns:
        --------
        float or None
            Returns the rounded price to the precision required for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method first loads the markets from the API client and then calls 
        the `price_to_precision` method of the API client to round the order price. 
        If an error occurs during this process, it logs the error and returns None.
        """
        result = None

        try:
            self.__api_client.load_markets()
            result = self.__api_client.price_to_precision(order_symbol, order_price)

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def cost_to_precision(self, order_symbol, order_cost):
        """
        cost_to_precision
        =================
        """

        result = None

        try:
            self.__api_client.load_markets()
            result = self.__api_client.cost_to_precision(order_symbol, order_cost)

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def symbol_min_amount(self, order_symbol):
        """
        symbol_min_amount
        =================

        Retrieves the minimum amount required to buy or sell a specific trading symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for which to retrieve the minimum amount (e.g., 'BTC/USDT').

        Returns:
        --------
        float or None
            Returns the minimum amount to buy or sell for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method loads the markets from the API client and accesses the minimum amount 
        limit for the specified symbol. If an error occurs during this process, it logs 
        the error and returns None.
        """
        result = None

        try:
            __markets = self.__api_client.load_markets()
            result = float(__markets[order_symbol]['limits']['amount']['min'])

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def symbol_tick_size(self, order_symbol):
        """
        symbol_tick_size
        ================

        Retrieves the tick size for a specific trading symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for which to retrieve the tick size (e.g., 'BTC/USDT').

        Returns:
        --------
        float or None
            Returns the tick size for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method loads the markets from the API client and accesses the precision 
        for the price of the specified symbol. If an error occurs during this process, 
        it logs the error and returns None.
        """
        result = None

        try:
            __markets = self.__api_client.load_markets()
            result = float(__markets[order_symbol]['precision']['price'])

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def symbol_min_cost(self, order_symbol):
        """
        symbol_min_cost
        ===============

        Retrieves the minimum cost required to buy or sell a specific trading symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for which to retrieve the minimum cost (e.g., 'BTC/USDT').

        Returns:
        --------
        float or None
            Returns the minimum cost for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method loads the markets from the API client and accesses the limits 
        for the cost of the specified symbol. If an error occurs during this process, 
        it logs the error and returns None.
        """
        result = None

        try:
            __markets = self.__api_client.load_markets()
            result = float(__markets[order_symbol]['limits']['cost']['min'])
            result = float(self.cost_to_precision(order_symbol, result))

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def get_markets(self):
        """
        get_markets
        ===========

        Retrieves market information for all available trading pairs.

        Returns:
        --------
        dict or None
            Returns a dictionary containing market information for all symbols, 
            or None if an error occurred.

        Notes:
        ------
        This method calls the API client to load the markets. If an error occurs 
        during this process, it logs the error and returns None.
        """
        result = None

        try:
            result = self.__api_client.load_markets()

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def get_ratelimit(self):
        """
        get_ratelimit
        =============

        Retrieves the rate limits for API requests.

        Returns:
        --------
        dict or None
            Returns a dictionary containing the raw rate limits and 
            order request rate limits, or None if an error occurred.

        Notes:
        ------
        This method fetches the rate limits from both the main API client 
        and the orders API client. If an error occurs during this process, 
        it logs the error and returns None.
        """
        result = None

        try:
            result = {}
            result['RAW_REQUEST'] = self.__api_client.rateLimit
            result['ORDER_REQUEST'] = self.__api_client_orders.rateLimit

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def get_ccxt_inst(self):
        """
        get_ccxt_inst
        =============

        Retrieves the CCXT API client instance.

        Returns:
        --------
        ccxt.Exchange or None
            Returns the CCXT exchange instance used for API communication,
            or None if the instance has not been initialized.

        Notes:
        ------
        This method provides access to the underlying CCXT library instance,
        allowing direct interaction with exchange-specific methods and properties
        not exposed through the wrapper interface.
        """
        result = None

        result = self.__api_client

        return result

    def dual_investment_get_products(self,
                                     params: dict=None) -> List[dict]:
        """
        Retrieve available Dual Investment products from Bybit.

        This method fetches Dual Investment products from Bybit's API with optional filtering
        by option type, asset pair, duration, and APR. It handles pagination automatically and
        returns a sorted list of products by APR in descending order.

        Args:
            params (dict, optional): Dictionary containing filter parameters. Defaults to None.
                Available keys:
                - option (str, optional): The option type - 'buy' for PUT options (low buy products)
                                          or 'sell' for CALL options (high sell products).
                                          Defaults to None.
                - asset (str, optional): The asset coin symbol (e.g., 'BNB', 'ETH').
                                         Defaults to None.
                - quote (str, optional): The quote coin symbol (e.g., 'USDT', 'BUSD').
                                         Defaults to None.
                - max_duration_days (int, optional): Maximum duration in days for
                                                     the investment products.
                                                     Only products with duration <= this value will
                                                     be returned. Defaults to 1.
                - min_apr (float, optional): Minimum Annual Percentage Rate (APR) filter.
                                             Only products with APR >= this value will be returned.
                                             Defaults to None (no minimum filter).
                - max_page_index (int, optional): Maximum number of pages to fetch from the API.
                                                  Each page contains up to 100 products.
                                                  Defaults to 10.

        Returns:
            List[dict]: A list of dictionaries containing Dual Investment product details.
                       Each dictionary includes:
                       - id: Product ID
                       - investCoin: Coin to invest
                       - exercisedCoin: Coin to be exercised
                       - strikePrice: Strike price of the option
                       - duration: Duration in days
                       - settleDate: Settlement date timestamp
                       - settleDateTime: Settlement date in human-readable format
                       - purchaseDecimal: Decimal precision for purchase amounts
                       - purchaseEndTime: Purchase end time timestamp
                       - purchaseEndDateTime: Purchase end time in human-readable format
                       - canPurchase: Boolean indicating if the product can be purchased
                       - apr: Annual Percentage Rate
                       - orderId: Order ID
                       - minAmount: Minimum investment amount
                       - maxAmount: Maximum investment amount
                       - createTimestamp: Creation timestamp
                       - createDateTime: Creation date in human-readable format
                       - optionType: Type of option (CALL or PUT)
                       
                       Returns None if an error occurs or no products are found.

        Raises:
            ValueError: If the option parameter is not 'buy' or 'sell'.

        Note:
            - CALL options are "high sell" products: optionType:CALL, exercisedCoin:USDT,
              investCoin:BNB
            - PUT options are "low buy" products: optionType:PUT, exercisedCoin:BNB, investCoin:USDT
            - The method includes a 0.25 second delay between page requests to avoid rate limits
            - Results are sorted by APR in descending order (highest APR first)
        """

        result = None

        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
        err_msg = f'Function {__l_function} not implemented in {self.__exchange} exchange API.'

        if self.__err_logger is not None:
            self.__err_logger.error(err_msg)

        return result

    def dual_investment_get_positions(self, params: dict=None) -> List[dict]:
        """
        Retrieve Dual Investment positions from Bybit.

        This method fetches all Dual Investment positions from Bybit's API with optional
        filtering by status. It handles pagination automatically to retrieve all available
        positions across multiple pages.

        Args:
            params (dict, optional): Dictionary containing filter parameters. Defaults to None.
                Available keys:
                - status (str, optional): Filter positions by status. Common values include:
                                         - 'PENDING': Positions waiting to be settled
                                         - 'EXERCISED': Positions that have been exercised
                                         - 'SETTLED': Positions that have been settled
                                         If None, returns all positions regardless of status.
                                         Defaults to None.
                - order_id (str | int, optional): The order ID to filter positions. 
                                                  Defaults to None (no order ID filter).

        Returns:
            List[dict]: A list of dictionaries containing Dual Investment position details.
                       Each dictionary includes information about an active or historical
                       Dual Investment position such as:
                        - id: Position ID
                        - investCoin: Coin invested
                        - exercisedCoin: Coin to be exercised
                        - subscriptionAmount: Amount invested
                        - strikePrice: Strike price of the option
                        - duration: Duration in days
                        - settleDate: Settlement date timestamp
                        - settleDateTime: Settlement date in human-readable format
                        - purchaseStatus: Current status of the position
                        - apr: Annual Percentage Rate
                        - orderId: Order ID
                        - purchaseEndTime: Purchase end time timestamp
                        - purchaseEndDateTime: Purchase end time in human-readable format
                        - optionType: Type of option (CALL or PUT)
                        - autoCompoundPlan: Auto-compound plan details
                       
                       Returns an empty list if no positions are found or if an error occurs.

        Note:
            - The method includes automatic pagination with 100 positions per page
            - A 0.25 second delay is added between page requests to avoid rate limits
            - Maximum of 5 consecutive errors are tolerated before stopping the fetch
            - A 5 second delay is applied after each error before retrying
            - All positions are aggregated and returned in a single list
        """

        result = None

        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
        err_msg = f'Function {__l_function} not implemented in {self.__exchange} exchange API.'

        if self.__err_logger is not None:
            self.__err_logger.error(err_msg)

        return result

    def dual_investment_subscribe_product(self,
                                          params: dict=None) -> Optional[dict]:
        """
        Subscribe to a Dual Investment product on Bybit.

        This method allows you to subscribe to a Dual Investment product by providing
        the product ID, order ID, and deposit amount. Optionally, you can specify
        an auto-compound plan for automatic reinvestment of returns.

        Args:
            params (dict, optional): Dictionary containing subscription parameters.
                                     Defaults to None.
                Available keys:
                - product_id (str): The unique identifier of the Dual Investment product
                                   to subscribe to. Must be a non-empty string.
                                   Defaults to None.
                - order_id (str): The order ID associated with the subscription.
                                 Must be a non-empty string. Defaults to None.
                - deposit_amount (float): The amount to invest in the product.
                                         Must be a positive number (int or float).
                                         Defaults to None.
                - invest_coin (str): The coin to invest in the product.
                - auto_compound_plan (str, optional): The auto-compound plan type for reinvesting
                                                     returns. Valid values are:
                                                     - 'NONE': No auto-compound (default)
                                                     - 'STANDARD': Standard auto-compound plan
                                                     - 'ADVANCED': Advanced auto-compound plan
                                                     Defaults to 'NONE'.

        Returns:
            Optional[dict]: A dictionary containing the subscription response from Bybit's API
                          if the subscription is successful. The dictionary includes:
                          - positionId: Position ID of the subscription
                          - investCoin: Coin invested
                          - exercisedCoin: Coin to be exercised
                          - subscriptionAmount: Amount subscribed
                          - duration: Duration in days
                          - autoCompoundPlan: Auto-compound plan used
                          - strikePrice: Strike price of the option
                          - settleDate: Settlement date timestamp
                          - settleDateTime: Settlement date in human-readable format
                          - purchaseStatus: Current status of the purchase
                          - apr: Annual Percentage Rate
                          - orderId: Order ID
                          - purchaseTime: Purchase time timestamp
                          - purchaseDateTime: Purchase time in human-readable format
                          - optionType: Type of option (CALL or PUT)
                          
                          Returns None if:
                          - Any parameter validation fails
                          - An API error occurs during subscription
                          - Network or connection issues prevent the request

        Raises:
            None: This method catches all exceptions and logs them via the error handler.
                 It returns None instead of raising exceptions.

        Note:
            - All parameters are validated before making the API request
            - Invalid parameters are logged to the error handler if available
            - A timestamp is automatically added to the API request
            - Any API errors are caught, logged, and result in a None return value
        """

        result = None

        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
        err_msg = f'Function {__l_function} not implemented in {self.__exchange} exchange API.'

        if self.__err_logger is not None:
            self.__err_logger.error(err_msg)

        return result
