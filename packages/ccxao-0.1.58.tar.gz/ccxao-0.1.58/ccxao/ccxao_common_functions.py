"""
CCXW - CryptoCurrency eXchange Websocket Library
Common functions used by the package

Author: Ricardo Marcelo Alvarez
Date: 2023-10-31
"""

import sys
import os
import threading
import string
import builtins
import random
import time
import datetime
import pwd
import grp
import hashlib
import io
import urllib.parse
import urllib.request
import json
import socket
import zipfile
from typing import Dict, Any

import pprint # pylint: disable=unused-import
import yaml
from schema import Schema, Or, Optional

def is_json(myjson):
    """
    is_json
    =======
    Check whether the provided value is a valid JSON string/bytes.

    Parameters:
    -----------
    myjson : str | bytes
        Candidate JSON payload.

    Returns:
    --------
    bool
        True if parsing succeeds, otherwise False.
    """

    result = False

    if myjson is not None and isinstance(myjson,(str,bytes)):
        try:
            json.loads(myjson)
            result = True
        except Exception: # pylint: disable=broad-except
            result = False

    return result

def is_integer_string(s):
    """
    is_integer_string
    =================
    Determine if a string represents a valid integer (base 10).

    Parameters:
    -----------
    s : str
        Input string to test.

    Returns:
    --------
    bool
        True if the string can be converted to int without error, else False.
    """

    result = False
    try:
        int(s)
        result = True
    except ValueError:
        result = False

    return result

def is_convertible_to_json(myvar):
    """
    is_convertible_to_json
    ======================
    Check whether an object can be serialized to JSON.

    Parameters:
    -----------
    myvar : Any
        Object to test for JSON-serializability.

    Returns:
    --------
    bool
        True if json.dumps(myvar) succeeds, otherwise False.
    """

    result = False
    try:
        json.dumps(myvar)
        result = True
    except Exception: # pylint: disable=broad-except
        result = False

    return result

def time_to_str(t: float=None, fmt: str="%Y-%m-%d %H:%M:%S.%f") -> str:
    """
    time_to_str
    ===========
    Convert a timestamp to a formatted string.

    Parameters:
    -----------
    t : float | int, optional
        Timestamp in seconds since epoch. If None, uses current time. Defaults to None.
    fmt : str, optional
        Format string for strftime. Defaults to "%Y-%m-%d %H:%M:%S".

    Returns:
    --------
    str
        Formatted time string.
    """

    if t is None:
        t = time.time()

    return datetime.datetime.fromtimestamp(t).strftime(fmt)

def file_get_contents(filename, mode_in="", encoding='utf-8'):
    """
    file_get_contents
    =================
    Read the content of a file and return it as text.

    Parameters:
    -----------
    filename : str
        Path to the file.
    mode_in : str, optional
        Extra mode flags (e.g., 'b' for binary). Defaults to "" (text mode).
    encoding : str, optional
        Text encoding used when reading. Defaults to 'utf-8'.

    Returns:
    --------
    str | bool | None
        File content as string on success, False on error, or None if unreadable.
    """
    result = None
    mode = "r" + mode_in

    try:
        f = builtins.open(filename, mode, encoding=encoding)
        result = f.read()
    except Exception: # pylint: disable=broad-except
        result = False

    return result

def file_put_contents(filename, data, mode_in=""):
    """
    file_put_contents
    =================
    Write the given data to the specified file.

    Parameters:
    -----------
    filename : str
        Destination file path.
    data : str
        Content to write.
    mode_in : str, optional
        Mode string (e.g., 'wb' for binary). Defaults to "" which implies 'w'.

    Returns:
    --------
    int | bool
        Number of characters written on success, or False on error.
    """
    result = False
    mode = "w"

    if len(mode_in) > 0:
        mode = mode_in
    try:
        f = builtins.open(filename, mode, encoding='utf-8')
        result = f.write(data)
        f.close()
    except Exception: # pylint: disable=broad-except
        result = False

    return result

def file_get_contents_url(url,mode="b",post_data=None,headers=None,timeout=9):
    """
    file_get_contents_url
    =====================
    Fetch content from a URL, optionally performing a POST request.

    Parameters:
    -----------
    url : str
        Target URL.
    mode : str, optional
        "b" to keep binary response; any other value decodes to text. Defaults to "b".
    post_data : dict, optional
        Form data to send via POST (application/x-www-form-urlencoded).
    headers : dict, optional
        Additional HTTP headers.
    timeout : int, optional
        Request timeout in seconds. Defaults to 9.

    Returns:
    --------
    str | None
        Response content as text (unless mode == 'b', then bytes decoded to str if possible),
        or None on failure.
    """

    result = None

    if headers is None:
        headers = {}

    try:
        req = None
        if post_data is not None and isinstance(post_data,dict):
            req = urllib.request.Request(url, urllib.parse.urlencode(post_data).encode(),headers)
        else:
            req = urllib.request.Request(url, None,headers)

        if req is not None:
            try:
                with urllib.request.urlopen(req, None, timeout=timeout) as response:
                    result = response.read()

            except Exception: # pylint: disable=broad-except
                result = None

        if result is not None and isinstance(result,bytes):
            result = result.decode()

    except Exception: # pylint: disable=broad-except
        result = None

    if mode != "b" and result is not None and result is not False and isinstance(result,bytes):
        result = result.decode()

    return result

def read_config_yaml(filename):
    """
    read_config_yaml
    ================
    Read a YAML configuration file and return its content as a dictionary.

    Parameters:
    -----------
    filename : str
        File path to the YAML configuration file.

    Returns:
    --------
    dict
        The contents of the YAML file as a dictionary.
    """
    file_raw = file_get_contents(filename)
    res = yaml.safe_load(file_raw)
    return res

def merge_common_keys(orig: dict, dest: dict) -> dict:
    """
    Merge keys from the original dictionary into the destination dictionary.
    Only keys that exist in both dictionaries are merged. If the value is a dictionary,
    the merge is performed recursively.
    Args:
        orig (dict): The original dictionary with new values.
        dest (dict): The destination dictionary to be updated.
    Returns:
        dict: The updated destination dictionary with merged values.
    Raises:
        None
    Notes:
        This function modifies the destination dictionary in place.
    """
    for k, v in orig.items():
        if k in dest:
            if isinstance(v, dict) and isinstance(dest[k], dict):
                merge_common_keys(v, dest[k])
            else:
                dest[k] = v
    return dest

def group_exists(name: str) -> bool:
    """
    Check if a group exists in the system.
    ======================================
    Args:
        name (str): Group name to check.
    Returns:
        bool: True if the group exists, False otherwise.
    Raises:
        None
    Notes:
        None
    """
    try:
        grp.getgrnam(name)
        return True
    except Exception: # pylint: disable=broad-except
        return False

def get_uid(username: str) -> int | None:
    """
    Get the user ID (UID) of a given username.
    ======================================
    Args:
        username (str): The username to look up.
    Returns:
        int | None: The UID of the user if found, None otherwise.
    Raises:
        None
    Notes:
        None
    """
    try:
        user_info = pwd.getpwnam(username)
        return user_info.pw_uid
    except Exception: # pylint: disable=broad-except
        return 0

def get_gid(groupname: str) -> int | None:
    """
    Get the group ID (GID) of a given group name.
    ======================================
    Args:
        username (str): The username to look up.
    Returns:
        int | None: The UID of the user if found, None otherwise.
    Raises:
        None
    Notes:
        None
    """
    try:
        __group_info = grp.getgrnam(groupname)
        return int(__group_info.gr_gid)

    except Exception: # pylint: disable=broad-except
        return 0

def is_port_free(port, host='localhost'):
    """
    is_port_free
    ============
    Check whether a TCP port is available on the specified host.

    Parameters:
    -----------
    port : int
        The port number to check.
    host : str, optional
        The host address. Defaults to 'localhost'.

    Returns:
    --------
    bool
        True if the port is free, False if it is in use or an error occurs.
    """
    result = False

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((host, port))
        s.close()
        result = True
    except Exception: # pylint: disable=broad-except
        result = False

    return result

def random_string(n=14):
    """
    random_string
    =============
    Generate a random alphanumeric string of the specified length.

    Parameters:
    -----------
    n : int, optional
        Length of the resulting string. Defaults to 14.

    Returns:
    --------
    str
        Randomly generated string of length n.
    """
    letters = string.ascii_letters + '0123456789'
    return ''.join(random.choice(letters) for _ in range(n))

def sha256(str_in):
    """
    sha256
    ======
    Compute the SHA-256 hex digest of a UTF-8 string.

    Parameters:
    -----------
    str_in : str
        Input string to hash.

    Returns:
    --------
    str
        Hexadecimal SHA-256 digest of the input.
    """

    __sha = hashlib.sha256()
    __sha.update(str_in.encode('utf-8'))
    return __sha.hexdigest()

def decompress_zip_data(data):
    """
    decompress_zip_data
    ===================
    Decompress a ZIP file given as bytes and return the first entry's content as text.

    Parameters:
    -----------
    data : bytes
        Raw ZIP archive in memory.

    Returns:
    --------
    str | None
        UTF-8 decoded content of the first file inside the archive, or None on error.
    """

    result = None

    try:
        # z = zipfile.ZipFile(io.BytesIO(data))
        # result = z.read(z.infolist()[0]).decode()

        with zipfile.ZipFile(io.BytesIO(data)) as z:
            result = z.read(z.infolist()[0]).decode()

    except Exception: # pylint: disable=broad-except
        result = None

    return result

def __check_config_structure(config_data):
    """
    __check_config_structure
    ========================

    Validate the minimal structure of the loaded configuration.

    Parameters:
    -----------
    config_data : dict
        Mapping parsed from YAML to validate.

    Returns:
    --------
    bool
        True if the configuration satisfies the required schema, otherwise False.
    """

    result = False

    schema = Schema({'global': dict,
                     'exchanges': list
                    }
    )

    schema_global = Schema({
                            Optional('var_dir'): str,
                            Optional('log_dir'): str,
                            Optional('run_dir'): str,
                            Optional('socket_name'): str,
                            Optional('socket_timeout'): int,
                            Optional('socket_max_bytes'): int,
                            Optional('ccxao_group'): str,
                            'ccxao_key': str,
                            Optional('sandbox'): bool,
                            Optional('debug'): bool,
                            Optional('time_to_purge_algo_orders'): Or(str, int),
                            Optional('restart_time_limit'): Or(str, int),
                            Optional('daemon_sleep_time'): Or(float, int)
                    }
    )

    if config_data is not None and schema.is_valid(config_data)\
        and config_data['global'] is not None\
        and schema_global.is_valid(config_data['global']):
        result = True

    return result

def create_dir_without_exception(dir_in):
    """
    create_dir_without_exception
    ============================
    Create a directory path if it does not already exist, ignoring exceptions.

    Parameters:
    -----------
    dir_in : str
        Directory path to create.

    Returns:
    --------
    bool | None
        True if the directory exists/was created, False on error, None if not attempted.
    """
    result = None
    try:
        if not os.path.exists(dir_in):
            os.makedirs(dir_in)
        result = True
    except Exception: # pylint: disable=broad-except
        result = False

    return result

def get_config_data(config_file):
    """
    get_config_data
    ===============
    Load and normalize daemon configuration from a YAML file, falling back to defaults.

    Parameters:
    -----------
    config_file : str
        Explicit path to the YAML configuration file. If missing, tries system defaults.

    Returns:
    --------
    dict | None
        Configuration mapping with validated writable directories for var/log/run,
        or None if validation/permissions fail.
    """
    result = None
    default_log_dir = '/var/log/ccxao-daemon'
    default_var_dir = '/var/ccxao-daemon'
    default_run_dir = '/run/ccxao-daemon'

    home_dir = os.getenv('HOME')

    if home_dir is None:
        home_dir = '/tmp/.ccxao'

    default_home_log_dir = os.path.join(home_dir, '.ccxao-daemon/var/log')
    default_home_var_dir = os.path.join(home_dir, '.ccxao-daemon/var/var')
    default_home_run_dir = os.path.join(home_dir, '.ccxao-daemon/var/run')


    config_data = None
    default_config_file = '/etc/ccxao-daemon/ccxao-daemon.yaml'

    if config_file is not None and isinstance(config_file, str) and os.path.exists(config_file):
        config_data = read_config_yaml(config_file)
    elif os.path.exists(default_config_file):
        config_data = read_config_yaml(default_config_file)

    if __check_config_structure(config_data):
        result = config_data

        if result['global']['var_dir'] is None or not isinstance(result['global']['var_dir'], str):
            result['global']['var_dir'] = default_var_dir

        if not (create_dir_without_exception(result['global']['var_dir'])\
            and os.access(result['global']['var_dir'], os.W_OK)):
            result['global']['var_dir'] = default_var_dir
            if not (create_dir_without_exception(result['global']['var_dir'])\
                and os.access(result['global']['var_dir'], os.W_OK)):
                result['global']['var_dir'] = default_home_var_dir
                if not (create_dir_without_exception(result['global']['var_dir'])\
                    and os.access(result['global']['var_dir'], os.W_OK)):
                    return None

        if result['global']['log_dir'] is None or not isinstance(result['global']['log_dir'], str):
            result['global']['log_dir'] = default_log_dir

        if not (create_dir_without_exception(result['global']['log_dir'])\
            and os.access(result['global']['log_dir'], os.W_OK)):
            result['global']['log_dir'] = default_log_dir
            if not (create_dir_without_exception(result['global']['log_dir'])\
                and os.access(result['global']['log_dir'], os.W_OK)):
                result['global']['log_dir'] = default_home_log_dir
                if not (create_dir_without_exception(result['global']['log_dir'])\
                    and os.access(result['global']['log_dir'], os.W_OK)):
                    return None

        if result['global']['run_dir'] is None or not isinstance(result['global']['run_dir'], str):
            result['global']['run_dir'] = default_run_dir

        if not (create_dir_without_exception(result['global']['run_dir'])\
            and os.access(result['global']['run_dir'], os.W_OK)):
            result['global']['run_dir'] = default_run_dir
            if not (create_dir_without_exception(result['global']['run_dir'])\
                and os.access(result['global']['run_dir'], os.W_OK)):
                result['global']['run_dir'] = default_home_run_dir
                if not (create_dir_without_exception(result['global']['run_dir'])\
                    and os.access(result['global']['run_dir'], os.W_OK)):
                    return None

    return result

def is_pid_running(pid):
    """
    is_pid_running
    ==============
    Check if a process with the given PID is currently running.

    Parameters:
    -----------
    pid : int
        Process ID to probe.

    Returns:
    --------
    bool
        True if the process appears to be alive, otherwise False.
    """
    result = False

    try:
        os.kill(pid, 0)
        result = True
    except OSError:
        result = False
    else:
        result = True

    return result

def load_config(config_path: str) -> Dict[str, Any]:
    """
    load_config
    ===========
    Load configuration from a YAML file.

    Parameters:
    -----------
    config_path : str
        Path to the configuration file.

    Returns:
    --------
    dict
        Mapping containing configuration data.

    Raises:
    -------
    FileNotFoundError
        If the config file does not exist.
    yaml.YAMLError
        If the config file contains invalid YAML.
    """
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    return config

class ReturnValueThread(threading.Thread):
    """
    ReturnValueThread
    =================
    A Thread subclass that captures and exposes the return value of the target function.

    Credits:
    https://alexandra-zaharia.github.io/posts/how-to-return-a-result-from-a-python-thread/

    Notes:
    ------
    Pass target, args and kwargs as usual to threading.Thread. The return value can be
    retrieved via join().
    """
    def __init__(self, *args, **kwargs):
        """
        __init__
        ========
        Initialize the ReturnValueThread.

        Parameters:
        -----------
        args : tuple
            Positional arguments for the Thread constructor.
        kwargs : dict
            Keyword arguments for the Thread constructor.
        """

        super().__init__(*args, **kwargs)
        self.result = None

    def run(self):
        """
        run
        ===

        Executes the target function and captures its return value.
        If an exception occurs during the execution, it is printed to stderr.
        """

        if self._target is None:
            return  # could alternatively raise an exception, depends on the use case
        try:
            self.result = self._target(*self._args, **self._kwargs)
        except Exception as exc: # pylint: disable=broad-except
            print(f'{type(exc).__name__}: {exc}', file=sys.stderr)  # properly handle the exception

    def join(self, *args, **kwargs):
        """
        join
        ====
        Wait for thread completion and return the target function's result.

        Parameters:
        -----------
        args : tuple
            Positional arguments forwarded to threading.Thread.join.
        kwargs : dict
            Keyword arguments forwarded to threading.Thread.join.

        Returns:
        --------
        Any
            The result of the target function, if any.
        """


        super().join(*args, **kwargs)
        return self.result

def chg_owner_and_perms(dir_in: str = None,
                        uid: str = None,
                        gid: str = None,
                        perms_dir: int = 0o770,
                        perms_file: int = 0o660) -> bool:
    """
    chg_owner_and_perms
    ===================
    
    Recursively changes the ownership and permissions of all directories and files 
    under the specified directory.

    Args:
        dir_in (str): The base directory to start applying ownership and permissions.
        uid (int): The user ID to set as owner.
        gid (int): The group ID to set as group owner.
        perms_dir (int): Permissions to set on directories (e.g., 0o500).
        perms_file (int): Permissions to set on files (e.g., 0o400).

    Returns:
        bool: True if processing was started successfully (root privileges and valid input),
              False otherwise.
    
    Notes:
        - This function must be executed as root to change ownership.
        - If any path inside the directory fails, it prints an error but continues with others.
    """
    result = False

    if not (isinstance(uid, int) and isinstance(gid, int) and isinstance(dir_in, str)):
        return result

    if not os.path.isdir(dir_in):
        return result

    if os.geteuid() != 0:
        gid = os.getgid()


    for root, dirs, files in os.walk(dir_in):
        for d in dirs:
            path = os.path.join(root, d)
            try:
                os.chown(path, uid, gid)
                os.chmod(path, perms_dir)
                result = True
            except Exception:  # pylint: disable=broad-except
                result = False

        for f in files:
            path = os.path.join(root, f)
            try:
                os.chown(path, uid, gid)
                os.chmod(path, perms_file)
                result = True
            except Exception:  # pylint: disable=broad-except
                result = False

    return result
