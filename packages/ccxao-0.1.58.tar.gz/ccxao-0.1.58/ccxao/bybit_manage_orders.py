# pylint: disable=too-many-lines, too-many-statements
"""
Ccxao - cryptoCurrency Exchange algoritmic order
Bybit Manage Orders

Author: Ricardo Marcelo Alvarez
Date: 2024-06-20
"""

# pylint: disable=unused-import

import sys
import os
import time
import datetime
import base64
import json
import urllib
import copy
import logging
import logging.handlers
import threading
import pickle
import builtins
import hmac
import hashlib
from typing import Callable, Any
import pprint
import websocket
import pytz
import ccxt

import ccxao.ccxao_common_functions as ccf # pylint: disable=unused-import

class CcxaoBybitManageOrders():
    """
    CcxaoBybitManageOrders
    ======================
    """
    # pylint: disable=arguments-renamed, no-member, unused-variable, unused-private-member
    def __init__(self,
                 api_key: str=None,
                 api_secret: str=None,
                 var_dir: str=None,
                 trading_type: str='SPOT',
                 sandbox: bool=False,
                 time_to_purge_orders: int=7200,
                 ccxt_bybit_inst: ccxt.bybit=None,
                 debug: bool=False,
                 log_handler: logging.Logger=None,
                 err_handler: logging.Logger=None):

        self.__log_logger = None
        self.__err_logger = None
        self.__debug = debug
        self.__exchange = 'bybit'
        self.__ord_status = None
        self.__ord_status_inv = None
        self.__ord_types = None
        self.__ord_types_inv = None
        self.__ord_sides = None
        self.__ord_sides_inv = None
        self.__time_in_force = None
        self.__time_in_force_inv = None
        self.__ord_reject_reason = None
        self.__ord_statuses = None
        self.__execution_report_struct = None

        self.__log_handler = log_handler
        self.__err_handler = err_handler
        self.__ccxt_bybit_inst = ccxt_bybit_inst

        self.__trading_type = trading_type

        if self.__trading_type is None:
            self.__trading_type = 'SPOT'

        self.__var_dir = var_dir

        if self.__var_dir is None:
            self.__var_dir = '/var/lib/ccxao/bybit'

        if not os.path.exists(self.__var_dir):
            os.makedirs(self.__var_dir)

        self.__orders_file = f'{self.__var_dir}/orders_bmo.pkl'

        self.__time_sleep = 0.05
        self.__ws = None
        self.__ws_thread = None
        self.__client_conn_uuid = None
        self.__run_daemon = False
        self.__run_daemon_lock = threading.Lock()
        self.__main_th = None
        self.__main_th_lock = threading.Lock()

        self.__requests = {}
        self.__requests_lock = threading.Lock()
        self.__time_to_purge_requests = 900

        self.__orders = {}
        self.__orders_lock = threading.Lock()

        if not self.__load_orders():
            self.__orders = {}

        self.__ws_lock = threading.Lock()
        self.__ws_response_data = {}
        self.__ws_is_connected = False
        self.__ws_reload = False

        self.__api_key = api_key
        self.__api_secret = api_secret
        self.__time_to_purge_orders = time_to_purge_orders
        self.__response_mode = 1

        self.__ws_url = 'wss://stream.bybit.com/v5/trade'

        if sandbox:
            self.__ws_url = 'wss://stream-testnet.bybit.com/v5/trade'

        self.__ord_statuses = {
            'New': 'open',
            'PartiallyFilled': 'open',
            'Untriggered': 'open',
            'Filled': 'closed',
            'PartiallyFilledCanceled': 'canceled',
            'Cancelled': 'canceled',
            'Rejected': 'rejected',
            'Deactivated': 'expired',
            'Triggered': 'closed'
        }

        self.__status_ended = ['closed', 'canceled', 'rejected', 'expired']

    def __save_orders(self):
        result = False

        try:
            with builtins.open(self.__orders_file, 'wb') as orders_file:
                pickle.dump(self.__orders, orders_file)
            result = True
        except Exception as e: # pylint: disable=broad-except
            result = False
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, error: {e}'
            if self.__err_logger is not None:
                self.__err_logger.error(err_msg)

        return result

    def __load_orders(self):
        result = False

        if os.path.exists(self.__orders_file):
            try:
                if os.path.getsize(self.__orders_file) > 0:
                    with builtins.open(self.__orders_file, 'rb') as orders_file:
                        self.__orders = pickle.load(orders_file)
                    result = True
                else:
                    self.__orders = {}
                    result = False
            except Exception as e: # pylint: disable=broad-except
                if self.__err_logger is not None:
                    __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                    err_msg = f'Found error in {__l_function}, error: {e}'
                    self.__err_logger.error(err_msg)

                self.__orders = {}
                result = False
        else:
            self.__orders = {}
            result = True

        if self.__orders is None or not isinstance(self.__orders, dict):
            self.__orders = {}
            result = True

        return result

    def start(self):
        """
        start
        =====
        """
        with self.__run_daemon_lock:
            self.__run_daemon = True

        __ws_name = f'ccxao_{self.__exchange}__launch_websocket__bybit_manage_orders_thread'
        self.__ws_thread = (
            threading.Thread(target=self.__launch_ccxao_websocket_thread,
                             name=__ws_name)
        )

        self.__ws_thread.start()
        time.sleep(5)

        __th_name = f'ccxao_{self.__exchange}__launch_main__bybit_manage_orders_thread'
        self.__main_th = threading.Thread(target=self.__main_thread,
                                          name = __th_name)

        self.__main_th.start()

        __time_out = 300
        __time_ini = time.time()
        __time_diff = 0

        while not self.is_connected() and __time_diff <= __time_out:
            time.sleep(0.5)
            __time_diff = time.time() - __time_ini

    def stop(self):
        """
        stop
        ====
        """
        with self.__run_daemon_lock:
            self.__run_daemon = False

        if self.__main_th is not None:
            self.__main_th.join(400)

        if self.__ws_thread is not None:
            self.__ws_thread.join(400)


    def __launch_ccxao_websocket_thread(self):
        """
        __launch_ccxao_websocket_thread
        ===============================

        This internal method initializes and starts the WebSocket client 
        for real-time communication with the exchange. It enables 
        debugging if specified and sets the message handler for incoming 
        WebSocket messages.

        Parameters:
        -----------
        self : CcxaoBybitManageOrders
            The instance of the CcxaoBybitManageOrders.

        Returns:
        --------
        None
        """
        websocket.enableTrace(self.__debug)
        self.__ws = websocket.WebSocketApp(self.__ws_url,
                                           on_open=self.__ws_on_open_handler,
                                           on_close=self.__ws_on_close_handler,
                                           on_reconnect=self.__ws_on_reconnect_handler,
                                           on_message=self.__ws_message_handler)

        self.__ws.run_forever(reconnect=320)

    def __ws_on_open_handler(self, _):
        with self.__requests_lock:
            self.__client_conn_uuid = None

        __log_msg = f'Connected to websocket {self.__ws}'
        if self.__log_logger is not None:
            self.__log_logger.info(__log_msg)

    def __ws_on_close_handler(self, _, close_status_code, close_msg):
        with self.__requests_lock:
            self.__client_conn_uuid = None

        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
        err_msg = f'Found error in {__l_function},'
        err_msg += f' error code: {close_status_code}, close msg: {close_msg}'
        if self.__err_logger is not None:
            self.__err_logger.error(err_msg)

    def __ws_on_reconnect_handler(self, _):
        with self.__requests_lock:
            self.__client_conn_uuid = None

        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
        __log_msg = f'Function: {__l_function} Reconnected to websocket {self.__ws}'
        if self.__log_logger is not None:
            self.__log_logger.info(__log_msg)

    def __ws_message_handler(self, _, message):

        __data = None

        if ccf.is_json(message):
            __data = json.loads(message)

        __l_request = {}
        __request_out = None
        __req_index = None

        with self.__requests_lock:
            __l_request = self.__requests

        if isinstance(__data, dict):
            __req_id = __data.get('reqId', None)
            __pong = __data.get('op', '')

            if isinstance(__req_id, str) and __req_id in __l_request:
                __req_index = __req_id
            elif isinstance(__pong, str) and __pong == 'pong' and __pong in __l_request:
                __req_index = __pong

            if isinstance(__req_index, str) and len(__req_index) > 0:
                __request_out = __l_request[__req_index]

            if isinstance(__request_out, dict):
                __current_tstp = time.time()
                dt_utc = datetime.datetime.fromtimestamp(__current_tstp, tz=datetime.timezone.utc)
                __current_timedate = dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")
                __request_out = {
                    'request_data': __request_out.get('request_data', None),
                    'request_result': __data,
                    'input_symbol': __request_out.get('input_symbol', None),
                    'init_unixtime': __request_out.get('init_unixtime', None),
                    'init_datetime': __request_out.get('init_datetime', None),
                    'last_update_unixtime': __current_tstp,
                    'last_update_datetime': __current_timedate,
                    'exec_time': round((__current_tstp - __request_out.get('init_unixtime', 0)), 4)
                }

                with self.__requests_lock:
                    self.__requests[__req_index] = __request_out

    def __auth_ws(self):

        __time_out = 23
        __time_ini = time.time()

        __op = "auth"
        __current_tstp = time.time()
        dt_utc = datetime.datetime.fromtimestamp(__current_tstp,
                                                 tz=datetime.timezone.utc)

        __current_timedate = dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")

        __req_id = f'{dt_utc.strftime("%Y%m%d_%H%M%S_%f")}_{__op}_{ccf.random_string(9)}'

        # __req_id = 'auth'
        expires = (int(time.time()) + 30) * 1000 # Expires in 30 seconds

        signature = hmac.new(self.__api_secret.encode(),
                             f'GET/realtime{expires}'.encode(),
                             hashlib.sha256)

        signature = signature.hexdigest()

        __auth_msg = {
            "reqId": __req_id,
            "op": __op,
            "args": [self.__api_key, expires, signature]
        }

        __req = json.dumps(__auth_msg)

        with self.__requests_lock:

            __request_out = {
                'request_data': __auth_msg,
                'request_result': None,
                'input_symbol': None,
                'init_unixtime': __current_tstp,
                'init_datetime': __current_timedate,
                'last_update_unixtime': __current_tstp,
                'last_update_datetime': __current_timedate,
                'exec_time': 0
            }

            self.__requests[__req_id] = __request_out
            self.__client_conn_uuid = None

        try:
            self.__ws.send(__req)

            __connected = False

            while not __connected:
                time.sleep(0.1)
                __data = None
                __data_out = None
                with self.__requests_lock:
                    __data_out = self.__requests.get(__req_id, None)

                if isinstance(__data_out, dict):
                    __data = __data_out.get('request_result', None)

                if isinstance(__data, dict):
                    __req_id_res = __data.get('reqId', '')
                    __conn_id = __data.get('connId', '')
                    __ret_code = int(__data.get('retCode', 99999))
                    __op_res = __data.get('op', '____NONE____')
                    __ret_msg = __data.get('retMsg', '')

                    if isinstance(__conn_id, str)\
                        and __op == __op_res\
                        and __req_id == __req_id_res\
                        and __ret_code == 0\
                        and len(__conn_id) > 0:

                        __connected = True
                        with self.__requests_lock:
                            self.__client_conn_uuid = __conn_id
                            self.__requests.pop(__req_id, None)

                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        __log_msg = f'Function: {__l_function} websocket'
                        __log_msg += f' auth: req_id: {__req_id}, op: {__op}'
                        if self.__log_logger is not None:
                            self.__log_logger.info(__log_msg)

                    else:
                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        __err_msg = f'Function: {__l_function} websocket'
                        __err_msg += f' auth: req_id: {__req_id}, op: {__op}'
                        if self.__err_logger is not None:
                            self.__err_logger.error(__err_msg)

                __time_diff = time.time() - __time_ini
                if __time_diff > __time_out:
                    __connected = True

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            __err_msg = f'Function: {__l_function} websocket'
            __err_msg += f' auth: req_id: {__req_id}, op: {__op}, ERROR: {e}'
            if self.__err_logger is not None:
                self.__err_logger.error(__err_msg)

            with self.__requests_lock:
                self.__client_conn_uuid = None

    def __ping_ws(self):

        result = False

        __time_out = 23
        __time_ini = time.time()

        __conn_id = None

        with self.__requests_lock:
            __conn_id = self.__client_conn_uuid

        # if __conn_id is None:
        #     return result

        __op = 'ping'
        __req_id = 'pong'

        __ping_msg = {
            "reqId": __req_id,
            "op": __op
        }

        __req = json.dumps(__ping_msg)

        __current_tstp = time.time()
        dt_utc = datetime.datetime.fromtimestamp(__current_tstp,
                                                 tz=datetime.timezone.utc)
        __current_timedate = dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")

        __request_out = {
            'request_data': __ping_msg,
            'request_result': None,
            'input_symbol': None,
            'init_unixtime': __current_tstp,
            'init_datetime': __current_timedate,
            'last_update_unixtime': __current_tstp,
            'last_update_datetime': __current_timedate,
            'exec_time': 0
        }

        with self.__requests_lock:
            self.__requests[__req_id] = __request_out

        try:
            self.__ws.send(__req)

            __pong_msg = False

            while not __pong_msg:
                time.sleep(0.1)
                __data = None
                __data_out = None
                with self.__requests_lock:
                    __data_out = self.__requests.get(__req_id, None)

                if isinstance(__data_out, dict):
                    __data = __data_out.get('request_result', None)

                if isinstance(__data, dict):
                    __req_id_res = __data.get('reqId', '')
                    __conn_id_res = __data.get('connId', '')
                    __ret_code = int(__data.get('retCode', 99999))
                    __op_res = __data.get('op', '____NONE____')
                    __ret_msg = __data.get('retMsg', '')

                    if isinstance(__conn_id_res, str)\
                        and 'pong' == __op_res\
                        and __ret_code == 0\
                        and len(__conn_id_res) > 0\
                        and isinstance(__conn_id, str):

                        with self.__requests_lock:
                            self.__requests.pop(__req_id, None)
                        __pong_msg = True

                        result = __conn_id == __conn_id_res

                    else:
                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        __err_msg = f'Function: {__l_function} websocket'
                        __err_msg += f' auth: req_id: {__req_id}, op: {__op}'
                        if self.__err_logger is not None:
                            self.__err_logger.error(__err_msg)

                __time_diff = time.time() - __time_ini
                if __time_diff > __time_out:
                    __pong_msg = True

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            __err_msg = f'Function: {__l_function} websocket'
            __err_msg += f' auth: req_id: {__req_id}, op: {__op}, ERROR: {e}'
            if self.__err_logger is not None:
                self.__err_logger.error(__err_msg)

            with self.__requests_lock:
                self.__client_conn_uuid = None

        return result

    def ping(self):
        """
        ping
        ====

        Sends a ping message to the WebSocket server to keep the connection alive.
        """
        return self.__ping_ws()

    def __main_thread(self):

        __run_daemon = True

        __time_sleep = 23

        while __run_daemon:
            __time_ini = time.time()
            if not self.__ping_ws():
                self.__auth_ws()

            self.__get_orders()
            self.__purge_ended_orders()
            self.__purge_old_requests()

            time.sleep(15)
            with self.__run_daemon_lock:
                __run_daemon = self.__run_daemon
            __time_diff = __time_sleep - (time.time() - __time_ini)
            __time_diff = round(__time_diff, 2)

            if __time_diff > 0:
                time.sleep(__time_diff)

        self.__ws.close()

    def is_connected(self):
        """
        is_connected
        ============

        """
        result = False

        with self.__requests_lock:
            result = self.__client_conn_uuid is not None

        return result

    def __get_orders(self):
        result = False

        __orders_l = {}

        with self.__orders_lock:
            __orders_l = self.__orders

        for __order_id, __order_data in __orders_l.items():
            __symbol = __order_data.get('symbol', None)
            __ended = __order_data.get('ended', False)

            if isinstance(__symbol, str) and not __ended:
                __order_data_get = None

                max_tries = 5
                num_tries = 0

                try:
                    while __order_data_get is None and num_tries <= max_tries:
                        __order_data_get = self.__ccxt_bybit_inst.fetch_open_order(__order_id,
                                                                                   __symbol)
                        if __order_data_get is None:
                            __order_data_get = self.__ccxt_bybit_inst.fetch_closed_order(__order_id,
                                                                                        __symbol)
                        if __order_data_get is None:
                            time.sleep(0.5)
                        else:
                            __order_data_get.pop('info', None)
                            __order_data_out = __order_data

                            __order_status = __order_data_get.get('status', '____NONE____')

                            __ended_out = __order_status in self.__status_ended
                            __order_data_out['order'] = __order_data_get
                            __order_data_out['postonly'] = __order_data_get.get('postOnly', False)
                            __order_data_out['ended'] = __ended_out
                            __order_data_out['timestamp'] = time.time()
                            with self.__orders_lock:
                                self.__orders[__order_id] = __order_data_out
                                self.__save_orders()

                            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                            __log_msg = f'Function: {__l_function}'
                            __log_msg += f' order_id: {__order_id}, order_symbol: {__symbol}'
                            if self.__log_logger is not None:
                                self.__log_logger.info(__log_msg)

                            time.sleep(0.25)

                except Exception as e: # pylint: disable=broad-except
                    __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                    __err_msg = f'Function: {__l_function}'
                    __err_msg += f' order_id: {__order_id}, order_symbol: {__symbol}, ERROR: {e}'
                    if self.__err_logger is not None:
                        self.__err_logger.error(__err_msg)

        return result

    def __purge_ended_orders(self):
        result = False
        __orders_l = {}

        with self.__orders_lock:
            __orders_l = self.__orders

        for __order_id, __order_data in __orders_l.items():
            __current_time = time.time()
            __symbol = __order_data.get('symbol', None)
            __ended = __order_data.get('ended', False)
            __timestamp = __order_data.get('timestamp', __current_time)
            __diff_timestamp = __current_time - __timestamp
            if __ended and __diff_timestamp > self.__time_to_purge_orders:
                with self.__orders_lock:
                    self.__orders.pop(__order_id, None)
                    self.__save_orders()

        return result

    def __purge_old_requests(self):
        result = False
        with self.__requests_lock:
            __requests_l = self.__requests

        if isinstance(__requests_l, dict):
            for __req_id, __request_data in __requests_l.items():
                if isinstance(__request_data, dict):
                    __current_time = time.time()
                    __init_time = __request_data.get('init_unixtime', __current_time)
                    __diff_time = __current_time - __init_time

                    if __diff_time > self.__time_to_purge_requests:
                        with self.__requests_lock:
                            self.__requests.pop(__req_id, None)

        return result

    def create_order(self,
                     order_symbol: str=None,
                     order_side: str=None,
                     order_amount: str=None,
                     order_price: str=None,
                     order_type: str='limit_maker',
                     time_in_force: str='GTC',
                     time_out: int=30):
        """
        create_order
        ============
        """
        result = None

        __conn_id = None

        with self.__requests_lock:
            __conn_id = self.__client_conn_uuid

        if __conn_id is None:
            return result

        __time_out = time_out
        __time_ini = time.time()

        __op = "order.create"
        __time_in_force = time_in_force
        __order_type = order_type

        __current_tstp = time.time()
        dt_utc = datetime.datetime.fromtimestamp(__current_tstp,
                                                 tz=datetime.timezone.utc)

        __current_timedate = dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")

        __req_id = f'{dt_utc.strftime("%Y%m%d_%H%M%S_%f")}_ocr_{ccf.random_string(9)}'

        if __order_type == 'limit_maker':
            __order_type = 'limit'
            __time_in_force = 'PostOnly'

        __request_data = {
            "reqId": __req_id,
            "header": {
                "X-BAPI-TIMESTAMP": int((time.time() * 1000)),
                "X-BAPI-RECV-WINDOW": int(__time_out * 1000),
                "Referer": 'ccxao'
            },
            "op": __op,
            "args": [
                {
                    "category": self.__trading_type.lower(),
                    "symbol": order_symbol.replace('/', '').upper(),
                    "side": order_side.capitalize(),
                    "orderType": __order_type.capitalize(),
                    "price": str(order_price),
                    "qty": str(order_amount),
                    "timeInForce": __time_in_force
                }
            ]
        }

        __req = json.dumps(__request_data, sort_keys=False)

        __request_out = {
            'request_data': __request_data,
            'request_result': None,
            'input_symbol': order_symbol,
            'init_unixtime': __current_tstp,
            'init_datetime': __current_timedate,
            'last_update_unixtime': __current_tstp,
            'last_update_datetime': __current_timedate,
            'exec_time': 0
        }

        with self.__requests_lock:
            self.__requests[__req_id] = __request_out

        try:
            self.__ws.send(__req)

            __order_is_exec = False

            while not __order_is_exec:
                time.sleep(0.005)
                __data = None
                __data_out = None
                with self.__requests_lock:
                    __data_out = self.__requests.get(__req_id, None)

                if isinstance(__data_out, dict):
                    __data = __data_out.get('request_result', None)

                if isinstance(__data, dict):
                    __req_id_res = __data.get('reqId', '')
                    __conn_id_res = __data.get('connId', '')
                    __ret_code = int(__data.get('retCode', 99999))
                    __op_res = __data.get('op', '____NONE____')
                    __ret_msg = __data.get('retMsg', '')
                    __order_data = __data.get('data', {})
                    __order_header = __data.get('header', {})

                    __order_id = __order_data.get('orderId', None)
                    __order_timestamp = __order_header.get('Timenow', 0)

                    if isinstance(__conn_id_res, str)\
                        and __op == __op_res\
                        and __ret_code == 0\
                        and len(__conn_id_res) > 0\
                        and __conn_id == __conn_id_res\
                        and isinstance(__order_id, str)\
                        and len(__order_id) > 0:

                        with self.__requests_lock:
                            self.__requests.pop(__req_id, None)

                        __order = None

                        __order_data = {
                            'order': __order,
                            'symbol': order_symbol,
                            'postonly': __time_in_force == 'PostOnly',
                            'ended': False,
                            'timestamp': time.time()
                        }

                        with self.__orders_lock:
                            self.__orders[__order_id] = __order_data
                            self.__save_orders()

                        __order_data_out = None
                        __step_get_time_ini = time.time()
                        __step_get_time_limit = 32
                        __step_get_time_diff = 0
                        while __order is None and __step_get_time_diff < __step_get_time_limit:
                            with self.__orders_lock:
                                __order_data_out = self.__orders.get(__order_id, {})

                            __order = __order_data_out.get('order', None)
                            if __order is None:
                                time.sleep(0.05)
                                __step_get_time_diff = time.time() - __step_get_time_ini

                        if __order is None:
                            __order = self.get_order_skel()
                            __order['id'] = __order_id
                            __order['symbol'] = order_symbol
                            __order['status'] = 'open'

                        result = __order

                        __order_is_exec = True

                    else:
                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        __err_msg = f'Function: {__l_function} websocket'
                        __err_msg += f' req_id: {__req_id}, op: {__op}'
                        __err_msg += f' order_symbol: {order_symbol}, order_side: {order_side}'
                        __err_msg += f' order_amount: {order_amount}, order_price: {order_price}'
                        __err_msg += f' order_type: {order_type}, time_in_force: {time_in_force}'
                        __err_msg += f' time_out: {time_out}'

                        if self.__err_logger is not None:
                            self.__err_logger.error(__err_msg)

                __time_diff = time.time() - __time_ini
                if __time_diff > __time_out:
                    __order_is_exec = True

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            __err_msg = f'Function: {__l_function} websocket'
            __err_msg += f' req_id: {__req_id}, op: {__op}'
            __err_msg += f' order_symbol: {order_symbol}, order_side: {order_side}'
            __err_msg += f' order_amount: {order_amount}, order_price: {order_price}'
            __err_msg += f' order_type: {order_type}, time_in_force: {time_in_force}'
            __err_msg += f' time_out: {time_out}, ERROR: {e}'

            if self.__err_logger is not None:
                self.__err_logger.error(__err_msg)

        return result

    def proc_order(self, data):
        """
        proc_order
        ==========

        """
        result = False

        if isinstance(data, list):
            for order_data in data:

                if isinstance(order_data, dict)\
                    and 'orderId' in order_data\
                    and isinstance(order_data['orderId'], str)\
                    and len(order_data['orderId']) > 0:

                    __order_id = order_data.get('orderId', '____NONE____')
                    __order_time = round((float(order_data.get('createdTime', 0))/1000), 3)
                    __order_date = datetime.datetime.fromtimestamp(__order_time)\
                        .replace(tzinfo=pytz.utc).isoformat(timespec='milliseconds')\
                            .replace('+00:00', 'Z')

                    __order_data_in = None

                    __order_wait_time_limit = 32
                    __order_wait_time_ini = time.time()
                    __order_wait_time_diff = 0

                    while __order_data_in is None\
                        and __order_wait_time_diff < __order_wait_time_limit:
                        with self.__orders_lock:
                            __order_data_in = self.__orders.get(__order_id, None)

                        __order_wait_time_diff = time.time() - __order_wait_time_ini
                        time.sleep(0.05)

                    if isinstance(__order_data_in, dict):
                        __order_symbol = __order_data_in.get('symbol', None)
                        __post_only = __order_data_in.get('postonly', False)
                        __order_symbol_get = order_data.get('symbol', '____XXXX____')

                        if __order_symbol is not None\
                            and __order_symbol.replace('/', '').upper() == __order_symbol_get:

                            __remaining = (
                                float(order_data.get('qty', 0.0))\
                                    - float(order_data.get('cumExecQty', 0.0))
                            )

                            __remaining = round(__remaining, 8)
                            __status = self.__ord_statuses.get(
                                order_data.get('orderStatus', '____'),
                                None)

                            __ended = __status in self.__status_ended

                            __avg_price = str(order_data.get('avgPrice', '0.0'))
                            if not __avg_price.isnumeric():
                                __avg_price = 0.0
                            else:
                                __avg_price = float(__avg_price)

                            __order_out = {
                                "id": __order_id,
                                "clientOrderId": str(order_data.get('orderLinkId', '')),
                                "timestamp": int(order_data.get('createdTime', 0)),
                                "datetime": __order_date,
                                "lastTradeTimestamp": int(order_data.get('updatedTime', 0)),
                                "lastUpdateTimestamp": int(order_data.get('updatedTime', 0)),
                                "symbol": __order_symbol,
                                "type": str(order_data.get('orderType', '').lower()),
                                "timeInForce": str(order_data.get('timeInForce', '')),
                                "postOnly": bool(__post_only),
                                "reduceOnly": bool(order_data.get('reduceOnly', False)),
                                "side": str(order_data.get('side', '').lower()),
                                "price": float(order_data.get('price', 0.0)),
                                "triggerPrice": float(order_data.get('triggerPrice', 0.0)),
                                "amount": float(order_data.get('qty', 0.0)),
                                "cost": float(order_data.get('cumExecValue', 0.0)),
                                "average": __avg_price,
                                "filled": float(order_data.get('cumExecQty', 0.0)),
                                "remaining": __remaining,
                                "status": str(__status),
                                "fee": None,
                                "trades": [],
                                "fees": [],
                                "stopPrice": None,
                                "takeProfitPrice": None,
                                "stopLossPrice": None
                            }

                            __order_data_out = __order_data_in
                            __order_data_out['order'] = __order_out
                            __order_data_out['ended'] = __ended
                            __order_data_out['timestamp'] = time.time()

                            with self.__orders_lock:
                                self.__orders[__order_id] = __order_data_out
                                self.__save_orders()

        return result

    def cancel_order(self,
                     order_id: str=None,
                     order_symbol: str=None,
                     time_out: int=30):
        """
        cancel_order
        ============
        """
        result = False

        __conn_id = None

        with self.__requests_lock:
            __conn_id = self.__client_conn_uuid

        if __conn_id is None:
            return result

        __time_out = time_out
        __time_ini = time.time()

        __op = "order.cancel"

        __current_tstp = time.time()
        dt_utc = datetime.datetime.fromtimestamp(__current_tstp,
                                                 tz=datetime.timezone.utc)

        __current_timedate = dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")

        __req_id = f'{dt_utc.strftime("%Y%m%d_%H%M%S_%f")}_ocn_{ccf.random_string(9)}'

        __request_data = {
            "reqId": __req_id,
            "header": {
                "X-BAPI-TIMESTAMP": int((time.time() * 1000)),
                "X-BAPI-RECV-WINDOW": int(__time_out * 1000),
                "Referer": 'ccxao'
            },
            "op": __op,
            "args": [
                {
                    "category": self.__trading_type.lower(),
                    "symbol": order_symbol.replace('/', '').upper(),
                    "orderId": str(order_id)
                }
            ]
        }

        __req = json.dumps(__request_data, sort_keys=False)

        __request_out = {
            'request_data': __request_data,
            'request_result': None,
            'input_symbol': order_symbol,
            'init_unixtime': __current_tstp,
            'init_datetime': __current_timedate,
            'last_update_unixtime': __current_tstp,
            'last_update_datetime': __current_timedate,
            'exec_time': 0
        }

        with self.__requests_lock:
            self.__requests[__req_id] = __request_out

        try:
            self.__ws.send(__req)

            __order_is_exec = False

            while not __order_is_exec:
                time.sleep(0.1)
                __data = None
                __data_out = None
                with self.__requests_lock:
                    __data_out = self.__requests.get(__req_id, None)

                if isinstance(__data_out, dict):
                    __data = __data_out.get('request_result', None)

                if isinstance(__data, dict):
                    __req_id_res = __data.get('reqId', '')
                    __conn_id_res = __data.get('connId', '')
                    __ret_code = int(__data.get('retCode', 99999))
                    __op_res = __data.get('op', '____NONE____')
                    __ret_msg = __data.get('retMsg', '')
                    __order_data = __data.get('data', {})
                    __order_header = __data.get('header', {})

                    __order_id = __order_data.get('orderId', None)
                    __order_timestamp = __order_header.get('Timenow', 0)

                    if isinstance(__conn_id_res, str)\
                        and __op == __op_res\
                        and __ret_code == 0\
                        and len(__conn_id_res) > 0\
                        and __conn_id == __conn_id_res\
                        and isinstance(__order_id, str)\
                        and len(__order_id) > 0:

                        result = __order_id == __order_id

                        with self.__requests_lock:
                            self.__requests.pop(__req_id, None)
                        __order_is_exec = True

                    else:
                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        __err_msg = f'Function: {__l_function} websocket'
                        __err_msg += f' req_id: {__req_id}, op: {__op}, order_id: {order_id}'
                        __err_msg += f' order_symbol: {order_symbol}'
                        __err_msg += f' time_out: {time_out}'

                        if self.__err_logger is not None:
                            self.__err_logger.error(__err_msg)

                __time_diff = time.time() - __time_ini
                if __time_diff > __time_out:
                    __order_is_exec = True

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            __err_msg = f'Function: {__l_function} websocket'
            __err_msg += f' req_id: {__req_id}, op: {__op}, order_id: {order_id}'
            __err_msg += f' order_symbol: {order_symbol}'
            __err_msg += f' time_out: {time_out}, ERROR: {e}'

            if self.__err_logger is not None:
                self.__err_logger.error(__err_msg)

        return result

    def get_order(self, order_id, order_symbol=None):
        """
        get_order
        =========

        """
        result = None

        with self.__orders_lock:
            __order_data = self.__orders.get(order_id, None)

        if isinstance(__order_data, dict):
            __order = __order_data.get('order', None)
            if order_symbol is not None:
                if order_symbol == __order_data.get('symbol', '____NONE____'):
                    result = __order
            else:
                result = __order

        return result

    @classmethod
    def get_order_skel(cls):
        """
        get_order_skel
        ==============
        """
        result = {
            "id": None,
            "clientOrderId": None,
            "timestamp": int(time.time()),
            "datetime": None,
            "lastTradeTimestamp": None,
            "lastUpdateTimestamp": None,
            "symbol": None,
            "type": None,
            "timeInForce": None,
            "postOnly": True,
            "reduceOnly": None,
            "side": None,
            "price": None,
            "triggerPrice": None,
            "amount": None,
            "cost": None,
            "average": None,
            "filled": None,
            "remaining": None,
            "status": None,
            "fee": None,
            "trades": [],
            "fees": [],
            "stopPrice": None,
            "takeProfitPrice": None,
            "stopLossPrice": None
        }

        return result
