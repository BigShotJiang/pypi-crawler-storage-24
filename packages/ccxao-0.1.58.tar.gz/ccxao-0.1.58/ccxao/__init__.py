"""
Ccxao - cryptoCurrency Exchange Algorithmic Order.

This package provides a comprehensive framework for creating and managing
algorithmic trading orders across various cryptocurrency exchanges.

Author: Ricardo Marcelo Alvarez
Date: 2024-06-20
"""

from os.path import dirname, basename, isfile, join
import glob
import sys
import importlib.metadata
from .ccxao import Ccxao
# from .ccxao_client import CcxaoClient
# # from .safe_thread_vars import DictSafeThread
# from .binance import BinanceCcxaoAuxClass
# from .bybit import BybitCcxaoAuxClass
# from .okx import OkxCcxaoAuxClass
# from .kucoin import KucoinCcxaoAuxClass
# from .bingx import BingxCcxaoAuxClass

ccxao_metadata = importlib.metadata.metadata('ccxao')

__title__ = ccxao_metadata['Name']
__summary__ = ccxao_metadata['Summary']
__uri__ = ccxao_metadata['Home-page']
__version__ = ccxao_metadata['Version']
__author__ = ccxao_metadata['Author']
__email__ = ccxao_metadata['Author-email']
__license__ = ccxao_metadata['License']
__copyright__ = 'Copyright © 2024 Ricardo Marcelo Alvarez'

modules = glob.glob(join(dirname(__file__), "*.py"))
__all__ = []

if isinstance(sys.path,list):
    sys.path.append(dirname(__file__))

for f in modules:
    if isfile(f) and not f.endswith('__init__.py'):
        __all__.append(basename(f)[:-3])
