# pylint: disable=too-many-lines
"""
Ccxao - cryptoCurrency Exchange algoritmic order
Main Class Ccxao

Author: Ricardo Marcelo Alvarez
Date: 2024-06-20
"""

import os
import sys
import glob
import threading
import base64
import time
import random
import queue
import decimal
import sqlite3
import copy
import json
import logging
import logging.handlers
import math
from typing import List, Optional # pylint: disable=unused-import
from contextlib import nullcontext
import pprint # pylint: disable=unused-import
import statistics
from ccxw import Ccxw

import ccxao.ccxao_common_functions as ccf

from .binance import BinanceCcxaoAuxClass
from .bybit import BybitCcxaoAuxClass
from .okx import OkxCcxaoAuxClass
from .kucoin import KucoinCcxaoAuxClass
from .bingx import BingxCcxaoAuxClass

class CcxaoExchangeConfig:
    """
    CcxaoExchangeConfig
    ====================
    A configuration class for managing exchange classes.

    Attributes:
        exchange_classes (dict): A dictionary mapping exchange names to their corresponding classes.

    Example:
        To obtain the class for the 'binance' exchange, use:
        ExchangeConfig.exchange_classes['binance']
    """

    exchange_classes = {
        'binance': BinanceCcxaoAuxClass,
        'bybit': BybitCcxaoAuxClass,
        'okx': OkxCcxaoAuxClass,
        'kucoin': KucoinCcxaoAuxClass,
        'bingx': BingxCcxaoAuxClass
    }

class Ccxao():
    """
    Ccxao - cryptoCurrency Exchange Algorithmic Order
    =================================================
    This class executes algorithmic orders and only uses limit or limit_maker order types.
    It was created for two main reasons: firstly, when using limit orders in some exchanges, 
    fees are lower, or in some cases, even zero for specific symbols; and secondly, to try 
    to avoid market manipulation.
    
    How it works:
    -------------
    This class continuously monitors the order book via a websocket connection and places 
    the corresponding order when the take profit or stop loss price is reached. It handles 
    both long and short positions. However, a limitation is that if you place an order for 
    the symbol BTC/USDT, for example, you must have sufficient funds in both assets: USDT 
    and BTC.

    When initializing the class, you also need to specify a list of symbols that will be 
    available for trading. This is necessary because a websocket connection is required 
    to get the order book for each symbol.

    Orders are executed in the background, so you need to periodically check the status of 
    the orders.

    For Binance:
    ------------
    
    Example:

    ```python
    import time

    import pprint
    from ccxao import Ccxao

    exchange = 'binance'
    api_key = '__BINANCE_API_KEY__'
    api_secret = '__BINANCE_SECRET_KEY__'
    sandbox = False
    debug = False
    var_dir = '.var'
    log_dir = '.log'
    symbols_to_trade = ['BTC/FDUSD', 'LTC/FDUSD']
    time_to_purge_algo_orders = 24

    __ccxao = Ccxao(\
        exchange=exchange,\
        api_key=api_key,\
        api_secret=api_secret,\
        symbols_to_trade=symbols_to_trade,\
        sandbox=sandbox,\
        debug=debug,\
        var_dir=var_dir,\
        log_dir=log_dir,\
        time_to_purge_algo_orders=time_to_purge_algo_orders)

    
    __ccxao.start()

    quote = 'FDUSD'
    asset = 'BTC'
    order_symbol = f'{asset}/{quote}'

    __order_amount_quote = 20.0
        
    __symbol_price = __ccxao.get_symbol_price_from_order_book(order_symbol)

    order_amount = __order_amount_quote / __symbol_price
    order_amount = __ccxao.amount_to_precision(order_symbol=order_symbol,\
                                               order_amount=order_amount)

    order_price_dir = 'bull' # 'bull' or 'bear'
    order_price_in = 'current' # 'current' or float with price to trigger de order
    order_price_tp = '1%' # a str with a valid float concatenat with % symbol 
    order_price_sl = '1%' # a str with a valid float concatenat with % symbol 
    order_trailing_porc = 0.5 # float
    order_trailing_max_steps = 5 # int

    order_finished = False
    __order_algo_id = None

    __order_algo_id = (
        __ccxao.queue_algo_order(order_symbol=order_symbol,\
                                 order_amount=order_amount,\
                                 order_price_dir=order_price_dir,\
                                 order_price_in=order_price_in,\
                                 order_price_tp=order_price_tp,\
                                 order_price_sl=order_price_sl,\
                                 order_trailing_porc=order_trailing_porc,\
                                 order_trailing_max_steps=order_trailing_max_steps)
    )

    print(f'__order_algo_id: {__order_algo_id}')

    if __order_algo_id is not None:
        while not order_finished:
            if __ccxao.algo_order_finished(__order_algo_id):
                __algo_order_data = __ccxao.get_algo_order(__order_algo_id)
                order_finished = True
                pprint.pprint(__algo_order_data, sort_dicts=False)
                print('=' * 140)
                time.sleep(5)

            time.sleep(14)

    __ccxao.stop()

    ```

    """

    def __init__(self,
                 exchange: str='binance',
                 market_type: str='SPOT',
                 api_key: str=None,
                 api_secret: str=None,
                 api_uid: str=None,
                 api_password: str=None,
                 symbols_to_trade: list=None,
                 sandbox: bool=False,
                 debug: bool=False,
                 var_dir: str=None,
                 log_dir: str=None,
                 time_to_purge_algo_orders: int=None):
        """
        Ccxao Constructor
        =================
        
        Initializes a new instance of the Ccxao class.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        exchange : str
            The name of the exchange (e.g., 'binance').
        market_type : str
            Market type; currently only 'SPOT' is allowed.
        api_key : str, optional
            API key for authentication.
        api_secret : str, optional
            API secret for authentication.
        api_uid : str, optional
            API UID, required only for some exchanges.
        api_password : str, optional
            API password, required only for some exchanges.
        symbols_to_trade : list, optional
            List of symbols available for trading, as defined by the exchange.
        sandbox : bool, optional
            Whether to use the sandbox environment for testing. Defaults to False.
        debug : bool, optional
            Whether to enable debug mode. Defaults to False.
        var_dir : str, optional
            Directory for storing variable data. Defaults to '/var/lib/ccxao'.
        log_dir : str, optional
            Directory for storing log files. Defaults to '/var/log/ccxao'.
        time_to_purge_algo_orders : int, optional
            Time in hours to purge algorithmic orders. Defaults to None.

        Returns:
        --------
        Ccxao
            A new instance of the Ccxao class.

        """

        self.__exchange = None
        self.__market_type = market_type
        self.__exchange_aux_class = None
        self.__var_dir = var_dir
        self.__log_dir = log_dir
        self.__db_name = None
        self.__table_name_orders = None
        self.__table_name_algo = None
        self.__db_conn = None
        self.__db_cursor = None
        self.__db_conn_lock = None
        self.__main_thread = None
        self.__thread_running = False
        self.__thread_running_lock = threading.Lock()
        self.__ccxw_streams = []
        self.__ccxw_inst = None
        self.__ccxw_inst_lock = threading.Lock()
        self.__sandbox = sandbox
        self.__debug = debug
        self.__order_time_limit = 90

        self.log_enabled = False
        self.__log_logger = None
        self.__err_logger = None
        self.__log_logger_file = None
        self.__err_logger_file = None

        self.__self_stopped = True

        self.__max_queue_prices_len = 90
        self.__queue_prices = queue.Queue(maxsize=self.__max_queue_prices_len)

        self.__time_to_purge_algo_orders = time_to_purge_algo_orders

        if self.__time_to_purge_algo_orders is None:
            self.__time_to_purge_algo_orders = 5

        if self.__time_to_purge_algo_orders is not None\
            and isinstance(self.__time_to_purge_algo_orders, int):
            self.__time_to_purge_algo_orders = self.__time_to_purge_algo_orders * 3600

        logging.getLogger().addHandler(logging.NullHandler())

        if exchange is not None and exchange in Ccxao.get_supported_exchanges():
            self.__exchange = exchange
        else:
            raise ValueError(f'Exchange {str(self.__exchange)} is not supported')

        if self.__market_type is None\
            or not isinstance(self.__market_type, str)\
            or self.__market_type != 'SPOT':

            __msg_out = f'Market type {str(self.__market_type)} '
            __msg_out += f'is not supported in exchange {str(self.__exchange)}'
            raise ValueError(__msg_out)

        if self.__var_dir is None:
            self.__var_dir = os.path.join('/var/lib/ccxao', 'exchanges', self.__exchange)
        else:
            self.__var_dir = os.path.join(self.__var_dir, 'exchanges', self.__exchange)

        if not os.path.exists(self.__var_dir):
            os.makedirs(self.__var_dir)

        if exchange in Ccxao.get_supported_exchanges():
            self.__exchange = exchange

            if self.__log_dir is None:
                self.__log_dir = os.path.join('/var/log/ccxao', 'exchanges', self.__exchange)
            else:
                self.__log_dir = os.path.join(self.__log_dir, 'exchanges', self.__exchange)

            self.log_enabled = self.__init_loggin_out(log_dir=self.__log_dir)

            __exchange_error = False
            e = ''
            try:

                self.__exchange_aux_class = (
                    CcxaoExchangeConfig.exchange_classes[self.__exchange](
                        api_key=api_key,
                        api_secret=api_secret,
                        api_uid=api_uid,
                        api_password=api_password,
                        sandbox=sandbox,
                        trading_type=self.__market_type,
                        debug=self.__debug,
                        var_dir=self.__var_dir,
                        log_handler=self.__log_logger,
                        err_handler=self.__err_logger)
                )

            except Exception as __e: # pylint: disable=broad-except
                e = __e
                __exchange_error = True
                # print(f'Exchange {str(self.__exchange)} exception {e}')

            if __exchange_error:
                raise ValueError(f'Exchange {str(self.__exchange)} exception {e}')

        else:
            raise ValueError(f'The exchange {str(self.__exchange)} is not supported.')

        if not self.__set_database():
            raise ValueError('Creating database problem')


        self.__symbols_to_trade = []

        if symbols_to_trade is not None\
            and isinstance(symbols_to_trade, list)\
            and len(symbols_to_trade) > 0:
            for symbol in symbols_to_trade:
                if isinstance(symbol, str)\
                    and len(symbol) > 0:
                    self.__symbols_to_trade.append(symbol)

        if len(self.__symbols_to_trade) == 0:
            raise ValueError('Not valid symbol in symbols_to_trade or none symbol is active.')

    def __del__(self):
        """
        __del__
        ========
        Destructor for the Ccxao class.
        """

        if not self.__self_stopped:
            self.stop()

        if self.__db_conn is not None:
            self.__db_conn.commit()
            self.__db_conn.close()
            self.__db_conn = None

    def get_allowed_symbols_to_trade(self):
        """
        get_allowed_symbols_to_trade
        ============================
        
        Returns the list of symbols that are allowed for trading.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        Returns:
        --------
        list
            A list of symbols that are allowed for trading.
        """

        result = []
        if isinstance(self.__symbols_to_trade, list):
            for symbol in self.__symbols_to_trade:
                if isinstance(symbol, str) and len(symbol) > 0 and self.is_symbol_active(symbol):
                    result.append(symbol)

        return result

    def __init_ccxw(self):
        """
        __init_ccxw
        ===========
        
        Initializes the Ccxw instance to receive data from websocket streams.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        """

        __symbol_data_tmp = None
        __counter_tmp = 0
        __counter_tmp_limit = 50
        while __symbol_data_tmp is None:
            time.sleep(1)
            __symbol_data_tmp = self.__exchange_aux_class.get_exchange_symbols_info()
            if __counter_tmp > __counter_tmp_limit and __symbol_data_tmp is None:
                __symbol_data_tmp = 'ERROR'
            __counter_tmp += 1

        if __symbol_data_tmp is None:
            raise ValueError('Problem when created Ccxao instance.')
        elif isinstance(__symbol_data_tmp, str) and __symbol_data_tmp == 'ERROR':
            raise ValueError('Problem when created Ccxao instance.')

        if self.__symbols_to_trade is not None\
            and isinstance(self.__symbols_to_trade, list)\
            and len(self.__symbols_to_trade) > 0:

            for __symbol in self.__symbols_to_trade:
                if self.is_symbol_active(__symbol):

                    __stream = \
                        {\
                            'endpoint': 'order_book',\
                            'symbol': __symbol
                        }

                    self.__ccxw_streams.append(__stream)
                else:
                    __out_msg = f'Symbol {__symbol} is not active in exchange {self.__exchange}.'
                    raise ValueError(__out_msg)

            try:
                self.__ccxw_inst = None
                self.__ccxw_inst = Ccxw(self.__exchange,\
                                        self.__ccxw_streams,\
                                        result_max_len=2500,\
                                        testmode=self.__sandbox,\
                                        debug=self.__debug)

                self.__ccxw_inst.start()

            except Exception as e: # pylint: disable=broad-except
                __exchange_error = True
                print(f'Error when created Ccxw instance: {e}')

        else:
            raise ValueError('symbols_to_trade can be a list of symbols')

    def __check_and_restart_ccxw(self):
        """
        __check_and_restart_ccxw
        ========================
        Restarts the CCXW instance.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        """

        with self.__ccxw_inst_lock:

            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            log_msg = f'restarting Ccxw inst in Class Ccxao in {__l_function}'
            log_msg += f', for exchange {self.__exchange}'
            log_msg_ini = f'BEGIN {log_msg}'
            log_msg_end = f'END {log_msg}'

            if self.__ccxw_inst is not None and isinstance(self.__ccxw_inst, Ccxw):
                if not self.__ccxw_ping():
                    self.__log_logger.info(log_msg_ini)
                    if self.__ccxw_inst.is_running():
                        self.__ccxw_inst.stop()

                    self.__ccxw_inst = None
                    self.__ccxw_inst = Ccxw(self.__exchange,\
                                            self.__ccxw_streams,\
                                            result_max_len=2500,\
                                            testmode=self.__sandbox,\
                                            debug=self.__debug)

                    self.__ccxw_inst.start()
                    self.__log_logger.info(log_msg_end)
            else:
                self.__log_logger.info(log_msg_ini)

                self.__ccxw_inst = None
                self.__ccxw_inst = Ccxw(self.__exchange,\
                                        self.__ccxw_streams,\
                                        result_max_len=2500,\
                                        testmode=self.__sandbox,\
                                        debug=self.__debug)

                self.__ccxw_inst.start()
                self.__log_logger.info(log_msg_end)

    def start(self):
        """
        start
        =====
        Starts the main thread of the class.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        """

        with self.__thread_running_lock:
            self.__thread_running = True

        if self.__exchange_aux_class is not None:
            self.__exchange_aux_class.start_listen_socket()
        else:
            raise ValueError('Error when creted Ccxao instance')

        self.__init_ccxw()

        self.__main_thread = threading.Thread(target=self.__launch_ccxao_thread,\
                                              name=f'ccxao_{self.__exchange}__0000')

        self.__main_thread.start()

        self.__self_stopped = False

    def stop(self):
        """
        stop
        ====
        Stops the main thread of the class.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        """
        with self.__thread_running_lock:
            self.__thread_running = False

        if self.__main_thread is not None:
            self.__main_thread.join(400)

        if self.__exchange_aux_class is not None:
            self.__exchange_aux_class.stop_listen_socket()

        if self.__ccxw_inst is not None and isinstance(self.__ccxw_inst, Ccxw):
            self.__ccxw_inst.stop()

        self.__self_stopped = True

    def ping(self):
        """
        ping
        ====
        Pings the Ccxao instance to check if it's alive.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        bool
            True if the instance is alive, False otherwise.
        """

        result = False

        if self.__exchange_aux_class is not None\
            and isinstance(self.__exchange_aux_class,
                           CcxaoExchangeConfig.exchange_classes[self.__exchange]):
            result = self.__exchange_aux_class.ping()
        else:
            result = False

        return result

    def __ccxw_ping(self):
        """
        __ccxw_ping
        ===========
        Pings the CCXW instance to check if it's alive.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        bool
            True if the CCXW instance is alive, False otherwise.
        """
        result = False

        if self.__ccxw_inst is not None and isinstance(self.__ccxw_inst, Ccxw):
            result = self.__ccxw_inst.is_connections_ok()

        __symbol = None

        if result:
            __res_type = 'mid'
            __symbol = random.choice(self.__symbols_to_trade)

            __mid_price = self.get_symbol_price_from_order_book(__symbol, __res_type, False)

            if __mid_price is None or not isinstance(__mid_price, (int, float)):
                time.sleep(9)
                __symbol = random.choice(self.__symbols_to_trade)
                __mid_price = self.get_symbol_price_from_order_book(__symbol, __res_type, False)

            result = (
                result and __mid_price is not None and isinstance(__mid_price, (int, float))
            )
        else:
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in Class Ccxao in function {__l_function}'
            err_msg += f', exchange: {self.__exchange}, symbol: {__symbol}, result: {result}'
            self.__err_logger.error(err_msg)


        return result

    def get_order_book_for_symbol(self, symbol, num_results=5, lock_ccxw=True):
        """
        get_order_book_for_symbol
        =========================
        
        Retrieves the order book for a given symbol.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT').
        num_results : int, optional
            The number of results to return, must be greater than 0 and less
            than or equal to 2500. Defaults to 5.
        lock_ccxw : bool, optional
            If True, the CCXW instance will be locked during the operation
            to prevent concurrent access.

        Returns:
        --------
        dict
            A dictionary with the structure:
            {
                'bids': ['10.0', '11.0', '12.0', '13.0', '14.0'],
                'asks': ['9.0', '8.0', '7.0', '6.0', '5.0'],
            }
        """
        result = None

        if num_results > 2500:
            num_results = 2500
        elif num_results <= 0:
            num_results = 5

        __lock = self.__ccxw_inst_lock if lock_ccxw else nullcontext()

        with __lock:
            if self.__ccxw_inst is not None and isinstance(self.__ccxw_inst, Ccxw):
                __data = self.__ccxw_inst.get_current_data('order_book', symbol)

                if __data is not None and isinstance(__data, dict):
                    try:
                        __bids = __data['data']['bids'][0:num_results]
                        __asks = __data['data']['asks'][0:num_results]
                        result = {}
                        result['bids'] = __bids
                        result['asks'] = __asks

                    except Exception as e: # pylint: disable=broad-except
                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
                        err_msg += f', symbol: {symbol}, error: {e}'
                        self.__err_logger.error(err_msg)

                        result = None

        return result

    def get_symbol_price_from_order_book(self, symbol, res_type='mid', lock_ccxw=True):
        """
        get_symbol_price_from_order_book
        ================================

        Retrieves the price from the order book for a given symbol.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT').
        res_type : str, optional
            Defines the type of price to retrieve.
            Acceptable values are ['mid', 'bids', 'asks', 'both'].
            If the provided value is not in the list, it defaults to 'mid'.
            - 'mid': Returns the mid price, calculated as (best bid + best ask) / 2.
            - 'bids': Returns the best bid price.
            - 'asks': Returns the best ask price.
            - 'both': Returns a dictionary with the best bid and ask prices along with
               their volumes.
        lock_ccxw : bool, optional
            If True, the CCXW instance will be locked during the operation
            to prevent concurrent access.


        Returns:
        --------
        float or dict
            - If `res_type` is 'mid', 'bids', or 'asks',
                it returns a float representing the current price from the order book.
            - If `res_type` is 'both', it returns a dictionary with the following structure:

            {
                'bids': 10.0,
                'bids_vol': 925.0,
                'asks': 11.0,
                'asks_vol': 975.0,
            }
        """
        result = None
        order_book = self.get_order_book_for_symbol(symbol, 5, lock_ccxw)

        if order_book is not None\
            and isinstance(order_book, dict)\
            and (res_type in order_book or res_type == 'both' or res_type == 'mid'):

            try:
                if res_type == 'both':
                    result = {}
                    result['bids'] = float(order_book['bids'][0][0])
                    result['bids_vol'] = float(order_book['bids'][0][1])
                    result['asks'] = float(order_book['asks'][0][0])
                    result['asks_vol'] = float(order_book['asks'][0][1])
                elif res_type == 'mid':
                    result = (float(order_book['bids'][0][0]) + float(order_book['asks'][0][0])) / 2
                elif res_type in order_book:
                    result = float(order_book[res_type][0][0])
                else:
                    result = (float(order_book['bids'][0][0]) + float(order_book['asks'][0][0])) / 2

            except Exception as e: # pylint: disable=broad-except
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
                err_msg += f', symbol: {symbol}, error: {e}'
                self.__err_logger.error(err_msg)

                result = None

        return result

    def __queue_lasts_prices(self):
        """
        __queue_lasts_prices
        ====================

        This function stores the latest price values in a queue. It is used to calculate 
        the sample standard deviation, in an attempt to detect price spikes that may indicate 
        market manipulation.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        """
        result = False

        try:
            __prices = {}
            __to_add = True
            for symbol in self.__symbols_to_trade:
                __price = self.get_symbol_price_from_order_book(symbol, 'mid')
                if __price is not None and isinstance(__price,(int, float)):
                    __prices[symbol] = __price
                else:
                    __to_add = False

            if __to_add:
                if self.__queue_prices.full():
                    self.__queue_prices.get()

                self.__queue_prices.put(__prices)
                result = True

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result

    def calculate_std_dev_prices(self, symbol, n=None):
        """
        calculate_std_dev_prices
        ========================

        Calculates the sample standard deviation of prices for a given symbol.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT') for which the sample standard deviation
            will be calculated.
        n : int, optional
            The number of price values to use for the calculation. 
            If None, it will calculate the standard deviation using all prices in the queue. 
            If an integer is provided, it will calculate based on the last 'n' prices.

        Returns:
        --------
        float
            The calculated sample standard deviation.
        """
        result = None

        n_min = 5

        try:
            __prices_data = None
            __prices = []
            with self.__queue_prices.mutex:
                __prices_data = list(self.__queue_prices.queue)

            if __prices_data is not None and isinstance(__prices_data, list):
                for __price_data in  __prices_data:
                    if symbol in __price_data:
                        __prices.append(__price_data[symbol])

            __std_dev_max_data = round(self.__max_queue_prices_len / 10) + n_min
            __std_dev_max_data = max(__std_dev_max_data, n_min)

            if len(__prices) > __std_dev_max_data:
                if n is not None and isinstance(n, int):
                    n = max(n, n_min)
                    __prices = __prices[:n]

                result = round(statistics.stdev(__prices), 4)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', symbol: {symbol}, error: {e}'
            self.__err_logger.error(err_msg)
            result = None

        return result

    def check_std_diff_prices(self, symbol):
        """
        check_std_diff_prices
        =====================

        Checks for anomalies in the sample standard deviation by comparing the full queue's 
        sample standard deviation with that of the last 'n' values, where 'n' is calculated 
        as len(queue) / 10.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT') for which the sample standard deviation
            will be analyzed.

        Returns:
        --------
        bool
            - True if no price anomaly is detected.
            - False if a price anomaly is detected.
        """

        result = False
        __porc_limit_l = 75
        __porc_limit_u = 125

        try:
            __std_dev_max_data = round(self.__max_queue_prices_len / 10)

            if __std_dev_max_data <= 1:
                __std_dev_max_data = 2

            __prices_std_t = self.calculate_std_dev_prices(symbol)
            __prices_std_p = self.calculate_std_dev_prices(symbol, __std_dev_max_data)

            if __prices_std_t is not None and __prices_std_p is not None:
                if __prices_std_t > 0:
                    __porc = (__prices_std_p / __prices_std_t) * 100
                    if __porc <= __porc_limit_l or __porc >= __porc_limit_u:
                        result = True

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', symbol: {symbol}, error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result

    def __launch_ccxao_thread(self):
        """
        __launch_ccxao_thread
        =====================

        This function launches the main thread of the class.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        """

        result = True

        time.sleep(5)

        __last_time_purge = None
        __time_loop = 1.0

        __ping_time_limit = 140
        __ping_time_next = time.time() + __ping_time_limit

        __to_run = True

        while __to_run:
            __time_ini = time.time()
            self.update_orders_in_db()

            __algo_orders = self.get_algo_orders()
            if __algo_orders is not None and isinstance(__algo_orders, dict):
                for __order_algo_id in __algo_orders:
                    self.__exec_algo_order(__order_algo_id)

            self.__queue_lasts_prices()

            if __last_time_purge is None\
                or abs(int(round(time.time())) - __last_time_purge)\
                    > self.__time_to_purge_algo_orders:
                self.__purge_finished_algo_orders()
                __last_time_purge = int(round(time.time()))

            if time.time() >= __ping_time_next:
                with self.__thread_running_lock:
                    if self.__thread_running:
                        self.__check_and_restart_ccxw()

                __ping_time_next = time.time() + __ping_time_limit

            __time_diff = abs(time.time() - __time_ini)
            if __time_diff < __time_loop:
                __time_diff = __time_loop - __time_diff
                __time_diff = round(__time_diff, 2)
                if __time_diff > 0:
                    time.sleep(__time_diff)

            with self.__thread_running_lock:
                __to_run = self.__thread_running

        return result

    def get_exchange_info(self):
        """
        get_exchange_info
        =================

        This function returns a list of dictionaries with
        the structure provided by `ccxt.fetch_markets()`.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        list[dict]
            A list of dictionaries with the structure returned by `ccxt.fetch_markets()`.
        """

        result = self.__exchange_aux_class.get_exchange_info()
        return result

    def get_exchange_tickers(self, symbol: str=None):
        """
        get_exchange_tickers
        ====================

        This function returns a dictionary containing all the trading
        symbols available on the exchange, along with their current prices.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        dict
            A dictionary structured as follows:
            {
                'BTC/USDT': 45000.0,
                'LTC/USDT': 150.0,
                ...
                'ZRX/ETH': 0.005,
                'ZRX/USDT': 1.5
            }
            where the keys are the trading symbols and the values are their respective prices.
        """

        result = self.__exchange_aux_class.get_exchange_tickers()

        if symbol is not None\
            and isinstance(symbol, str)\
            and symbol in result:

            result = {symbol: result[symbol]}
        elif symbol is not None\
            and isinstance(symbol, str)\
            and symbol not in result:

            result = None

        return result

    def get_trading_fees(self):
        """
        get_trading_fees
        ================

        This function returns a dictionary containing all the trading
        symbols available on the exchange, along with the associated
        maker and taker fees.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        dict
            A dictionary structured as follows:
            {
                'BTC/USDT': {'maker': 0.001, 'taker': 0.001},
                'LTC/USDT': {'maker': 0.001, 'taker': 0.001},
                ...
                'ZRX/ETH': {'maker': 0.001, 'taker': 0.001},
                'ZRX/USDT': {'maker': 0.001, 'taker': 0.001}
            }
        """

        result = self.__exchange_aux_class.get_trading_fees()

        return result

    def get_symbol_price(self, symbol='BTC/USDT', from_cache=True):
        """
        get_symbol_price
        ================

        Retrieves the price from `ccxt.fetch_ticker(symbol)`.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str, optional
            The trading symbol (e.g., 'BTC/USDT'). Defaults to 'BTC/USDT'.
        from_cache : bool, optional
            If True, returns the price from the cache;
            if False, queries again using `ccxt.fetch_ticker(symbol)`.

        Returns:
        --------
        float
            The price of the specified symbol.
        """
        result = None

        result = self.__exchange_aux_class.get_symbol_price(symbol, from_cache)

        return result

    def get_exchange_symbols_info(self, symbol: str=None):
        """
        get_exchange_symbols_info
        =========================

        Returns the data provided by `ccxt.fetch_markets()`, 
        but with a slightly modified structure.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str, optional
            The trading symbol (e.g., 'BTC/USDT'). If provided,
            returns info for that specific symbol.

        Returns:
        --------
        dict
            Returns a dictionary constructed from the list returned by `ccxt.fetch_markets()`. 
            Instead of returning a list, it returns a dictionary where the key is the symbol from 
            the list node and the value is the corresponding node (with the 'info' key removed). 
            If `symbol` is provided, returns a dictionary with that symbol as the only key.
        """
        result = None
        __data = self.__exchange_aux_class.get_exchange_symbols_info()

        if symbol is None:
            result = __data
        elif isinstance(symbol, str) and symbol in __data:
            result = {}
            result[symbol] = __data[symbol]

        return result

    def is_symbol_active(self, symbol):
        """
        is_symbol_active
        ================

        Checks if a symbol is active on the exchange.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        bool
            True if the symbol is active on the exchange, False if it is inactive.
        """
        result = False

        __symbol_data = self.get_exchange_symbols_info(symbol)

        if __symbol_data is not None\
            and isinstance(__symbol_data, dict)\
            and symbol in __symbol_data\
            and __symbol_data[symbol] is not None\
            and isinstance(__symbol_data[symbol], dict)\
            and 'active' in __symbol_data[symbol]:

            result = __symbol_data[symbol]['active']

        return result

    def get_balances(self):
        """
        get_balances
        ============

        Retrieves the balances of all symbols with a balance greater than 0.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        dict
            A dictionary structured as follows:
            {
                'BTC': 0.001,
                'LTC': 0.5,
                ...
                'ETH': 0.01
            }
            where the keys are the symbols and the values are their respective balances.
        """
        result = None
        __data = self.__exchange_aux_class.get_balances()
        result = copy.deepcopy(__data)

        return result

    def get_usdt_balances(self):
        """
        get_usdt_balances
        =================

        Retrieves the balances of all symbols with a balance greater than 0, expressed in USDT.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        dict
            A dictionary structured as follows:
            {
                'BTC': 150.0,
                'LTC': 50.0,
                ...
                'ETH': 250.01
            }

            where the keys are the symbols and the values represent
            their respective balances in USDT.
        """
        result = None
        __data = self.__exchange_aux_class.get_usdt_balances()
        result = copy.deepcopy(__data)

        return result

    def force_reload_exchange_info(self):
        """
        force_reload_exchange_info
        ==========================

        Forces an update of the exchange information data in the cache.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        """
        result = self.__exchange_aux_class.force_reload_exchange_info()

        return result

    def get_symbols_with_less_than_fee_maker(self,\
                                             limit: float=0.001,\
                                             quote_asset: str=None,\
                                             base_asset: str=None):
        """
        get_symbols_with_less_than_fee_maker
        ====================================

        Returns a dictionary of symbols with a maker fee less than to the specified limit.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        limit : float
            The maximum maker fee allowed.

        quote_asset : str, optional
            If provided, returns only symbols that have this quote asset.

        base_asset : str, optional
            If provided, returns only symbols that have this base asset.

        Returns:
        --------
        dict
            A dictionary structured as follows:
            {
                'BTC/AEUR': {'maker': 0.0, 'taker': 0.0},
                'BTC/USDP': {'maker': 0.0, 'taker': 0.0},
                ...
                'BTC/ZAR': {'maker': 0.0, 'taker': 0.001}
            }
        """
        result = None
        __data = self.get_trading_fees()

        result = {}

        __fee_type = 'maker'

        if __data is not None and isinstance(__data, dict):
            for symbol, data_symbol in __data.items():
                if data_symbol is not None\
                    and isinstance(data_symbol, dict)\
                    and __fee_type in data_symbol:

                    if '/' in symbol:
                        __base, __quote = symbol.split('/')

                        if quote_asset is None and base_asset is None:
                            if limit == 0:
                                if float(data_symbol[__fee_type]) <= limit:
                                    result[symbol] = data_symbol
                            else:
                                if float(data_symbol[__fee_type]) < limit:
                                    result[symbol] = data_symbol
                        elif quote_asset is None and base_asset == __base:
                            if limit == 0:
                                if float(data_symbol[__fee_type]) <= limit:
                                    result[symbol] = data_symbol
                            else:
                                if float(data_symbol[__fee_type]) < limit:
                                    result[symbol] = data_symbol

                        elif quote_asset == __quote and base_asset is None:
                            if limit == 0:
                                if float(data_symbol[__fee_type]) <= limit:
                                    result[symbol] = data_symbol
                            else:
                                if float(data_symbol[__fee_type]) < limit:
                                    result[symbol] = data_symbol

                        elif quote_asset == __quote and base_asset == __base:
                            if limit == 0:
                                if float(data_symbol[__fee_type]) <= limit:
                                    result[symbol] = data_symbol
                            else:
                                if float(data_symbol[__fee_type]) < limit:
                                    result[symbol] = data_symbol

        return result

    def get_symbols_with_less_than_fee_taker(self,\
                                             limit: float=0.001,\
                                             quote_asset: str=None,\
                                             base_asset: str=None):
        """
        get_symbols_with_less_than_fee_taker
        ====================================

        Returns a dictionary of symbols with a taker fee less than to the specified limit.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        limit : float
            The maximum taker fee allowed.

        quote_asset : str, optional
            If provided, returns only symbols that have this quote asset.

        base_asset : str, optional
            If provided, returns only symbols that have this base asset.

        Returns:
        --------
        dict
            A dictionary structured as follows:
            {
                'BTC/AEUR': {'maker': 0.0, 'taker': 0.0},
                'BTC/USDP': {'maker': 0.0, 'taker': 0.0},
                ...
                'BTC/ZAR': {'maker': 0.0, 'taker': 0.001}
            }

        """
        result = None
        __data = self.get_trading_fees()

        result = {}

        __fee_type = 'taker'

        for symbol, data_symbol in __data.items():
            if data_symbol is not None\
                and isinstance(data_symbol, dict)\
                and __fee_type in data_symbol:

                if '/' in symbol:
                    __base, __quote = symbol.split('/')

                    if quote_asset is None and base_asset is None:
                        if limit == 0:
                            if float(data_symbol[__fee_type]) <= limit:
                                result[symbol] = data_symbol
                        else:
                            if float(data_symbol[__fee_type]) < limit:
                                result[symbol] = data_symbol
                    elif quote_asset is None and base_asset == __base:
                        if limit == 0:
                            if float(data_symbol[__fee_type]) <= limit:
                                result[symbol] = data_symbol
                        else:
                            if float(data_symbol[__fee_type]) < limit:
                                result[symbol] = data_symbol

                    elif quote_asset == __quote and base_asset is None:
                        if limit == 0:
                            if float(data_symbol[__fee_type]) <= limit:
                                result[symbol] = data_symbol
                        else:
                            if float(data_symbol[__fee_type]) < limit:
                                result[symbol] = data_symbol

                    elif quote_asset == __quote and base_asset == __base:
                        if limit == 0:
                            if float(data_symbol[__fee_type]) <= limit:
                                result[symbol] = data_symbol
                        else:
                            if float(data_symbol[__fee_type]) < limit:
                                result[symbol] = data_symbol

        return result

    def __set_database(self):
        """
        __set_database
        ==============

        This is an internal function that initializes the SQLite database
        (if it has not been initialized).

        It creates two tables with the following structures:

        self.__table_name_orders
        (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exchange VARCHAR(32) NOT NULL,
            symbol VARCHAR(14) NOT NULL,
            order_id VARCHAR(32) NOT NULL,
            order_data TEXT NOT NULL,
            created_time INT NOT NULL,
            end_time INT NULL,
            status VARCHAR(14) NOT NULL,
            error_code INT NULL,
            error_msg TEXT NULL,
            data TEXT NULL,
            UNIQUE (exchange, symbol, order_id)
        )

        self.__table_name_algo
        (
            order_algo_id VARCHAR(192) PRIMARY KEY,
            exchange VARCHAR(32) NOT NULL,
            symbol VARCHAR(14) NOT NULL,
            order_algo_time_ini INT NOT NULL,
            order_algo_time_date_ini VARCHAR(23) NOT NULL,
            order_algo_time_end INT NULL,
            order_algo_time_date_end VARCHAR(23) NULL,
            order_algo_status VARCHAR(14) NULL,
            order_algo_data TEXT NULL,
            UNIQUE (order_algo_id, exchange, symbol)
        )

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        bool
            True if everything was successful, or False if there was an error.
        """

        result = False

        self.__db_name = 'ccxao'
        self.__table_name_orders = 'orders_data'
        self.__table_name_algo = 'orders_algo'

        __db_dir = os.path.join(self.__var_dir, 'dbs/sqlite')
        __db_file = f'{__db_dir}/{self.__db_name}.db'

        if not os.path.exists(__db_dir):
            os.makedirs(__db_dir)

        # self.__conn_db = sqlite3.connect(self.__database_name, check_same_thread=False)
        self.__db_conn = sqlite3.connect(database=__db_file, check_same_thread=False)
        self.__db_conn.row_factory = sqlite3.Row
        self.__db_cursor = self.__db_conn.cursor()
        # self.__conn_db = sqlite3.connect(':memory:', check_same_thread=False)
        self.__db_conn_lock = threading.Lock()

        if self.__db_conn is not None:

            __sql_create_table_db = f'''
                                        CREATE TABLE IF NOT EXISTS {self.__table_name_orders} (
                                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                                        exchange VARCHAR(32) NOT NULL,
                                        symbol VARCHAR(14) NOT NULL,
                                        order_id VARCHAR(32) NOT NULL,
                                        order_data TEXT NOT NULL,
                                        created_time INT NOT NULL,
                                        end_time INT NULL,
                                        status VARCHAR(14) NOT NULL,
                                        error_code INT NULL,
                                        error_msg TEXT NULL,
                                        data TEXT NULL,
                                        UNIQUE (exchange, symbol, order_id)
                                        ) ;

                                        CREATE TABLE IF NOT EXISTS {self.__table_name_algo} (
                                        order_algo_id VARCHAR(192) PRIMARY KEY,
                                        exchange VARCHAR(32) NOT NULL,
                                        symbol VARCHAR(14) NOT NULL,
                                        order_algo_time_ini INT NOT NULL,
                                        order_algo_time_date_ini VARCHAR(23) NOT NULL,
                                        order_algo_time_end INT NULL,
                                        order_algo_time_date_end VARCHAR(23) NULL,
                                        order_algo_status VARCHAR(14) NULL,
                                        order_algo_data TEXT NULL,
                                        UNIQUE (order_algo_id, exchange, symbol)
                                        ) ;
                                    '''

            with self.__db_conn_lock:
                self.__db_cursor.executescript(__sql_create_table_db)
                self.__db_conn.commit()

            result = True

        return result

    def symbol_min_amount(self, symbol):
        """
        symbol_min_amount
        =================

        This function returns the minimum amount allowed for an order for the given symbol.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        float
            The minimum amount required to buy or sell for the specified symbol.

        """
        result = None

        try:
            result = self.__exchange_aux_class.symbol_min_amount(symbol)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', symbol: {symbol}, error: {e}'
            self.__err_logger.error(err_msg)

            result = None

        return result

    def symbol_min_cost(self, symbol):
        """
        symbol_min_cost
        ===============

        This function returns the minimum cost of an order for the given symbol.
        (The minimum cost is expressed in the quote asset.)

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        float
            The minimum cost required to buy or sell for the specified symbol.
        """
        result = None

        try:
            result = self.__exchange_aux_class.symbol_min_cost(symbol)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', symbol: {symbol}, error: {e}'
            self.__err_logger.error(err_msg)

            result = None

        return result

    def amount_to_precision(self, symbol, order_amount):
        """
        amount_to_precision
        ===================

        This function rounds the order_amount for the given symbol,
        conforming to the precision accepted by the exchange.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT').
        order_amount : float
            The amount of the order.

        Returns:
        --------
        float
            The amount rounded to the precision accepted by the exchange.
        """
        result = decimal.Decimal(order_amount).normalize()
        result = float(self.__exchange_aux_class.amount_to_precision(symbol, result))
        return result

    def price_to_precision(self, symbol, order_price):
        """
        price_to_precision
        ==================

        This function rounds the order_price for the given symbol,
        conforming to the precision accepted by the exchange.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT').
        order_price : float
            The price of the order.

        Returns:
        --------
        float
            The price rounded to the precision accepted by the exchange.
        """
        result = decimal.Decimal(order_price).normalize()
        result = float(self.__exchange_aux_class.price_to_precision(symbol, result))
        return result

    def cost_to_precision(self, symbol, order_cost):
        """
        cost_to_precision
        =================

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT').
        order_cost : float
            The cost of the order.

        Returns:
        --------
        float
            The cost rounded to the precision accepted by the exchange.

        """
        result = decimal.Decimal(order_cost).normalize()
        result = float(self.__exchange_aux_class.cost_to_precision(symbol, result))
        return result


    def symbol_tick_size(self, symbol):
        """
        symbol_tick_size
        =================

        This function returns the minimum tick size for the given symbol.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The trading symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        float
            The minimum tick size for the symbol.
        """
        result = float(self.__exchange_aux_class.symbol_tick_size(symbol))
        return result

    def create_order(self,\
                     order_symbol: str='BTC/USDT',\
                     order_side: str='buy',\
                     order_amount: float=0,\
                     order_price: float=0,\
                     order_type: str='limit_maker',\
                     order_time_in_force: str='GTC',\
                     order_params: dict=None):
        """
        create_order
        ============
        
        This function creates an order, but only if the order is of type 'limit' or 'limit_maker'.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_symbol : str, optional
            The trading symbol for the order (e.g., 'BTC/USDT'). Default is 'BTC/USDT'.
        order_side : str, optional
            The side of the order, either 'buy' or 'sell'. Only these values are accepted.
            Default is 'buy'.
        order_amount : float, optional
            The amount of the order. Must be greater than 0. Default is 0.
        order_price : float, optional
            The price of the order. Must be greater than 0. Default is 0.
        order_type : str, optional
            The type of the order. Only 'limit' or 'limit_maker' is allowed.
            Default is 'limit_maker'.
        order_time_in_force : str, optional
            Time-in-force for the order. Allowed values are 'GTC', 'IOC', or 'FOK'.
            Default is 'GTC'.
        order_params : dict, optional
            Additional parameters for the order. Default is None.

        Returns:
        --------
        dict or None
            Returns a dictionary with the order data (as returned by ccxt.create_order())
            without the 'info' key.
            If an error occurs, None is returned.
        """
        result = None
        if order_params is None:
            order_params = {'timeInForce': order_time_in_force}
        elif isinstance(order_params, dict):
            order_params['timeInForce'] = order_time_in_force
        else:
            order_params = {'timeInForce': order_time_in_force}

        try:
            order_amount = self.amount_to_precision(order_symbol, order_amount)
            order_price = self.price_to_precision(order_symbol, order_price)

            __order_data = self.__exchange_aux_class.create_order(order_symbol=order_symbol,
                                                                  order_side=order_side,
                                                                  order_amount=order_amount,
                                                                  order_price=order_price,
                                                                  order_type=order_type,
                                                                  order_params=order_params)

            __order_data = copy.deepcopy(__order_data)
            if __order_data is not None and isinstance(__order_data, dict):

                if self.__upsert_order_in_db(__order_data['symbol'],\
                                             __order_data['id'],\
                                             __order_data,\
                                             __order_data['timestamp'],\
                                             __order_data['status']):
                    result = copy.deepcopy(__order_data)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', symbol: {order_symbol}, error: {e}'
            self.__err_logger.error(err_msg)

            result = None

        return result

    def get_order(self, order_id, order_symbol):
        """
        get_order
        =========

        This function retrieves an order by its ID and symbol.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_id : str or int
            The ID of the order to be retrieved.
        order_symbol : str
            The trading symbol of the order (e.g., 'BTC/USDT').

        Returns:
        --------
        dict
            Returns a dictionary with the order data as returned by
            ccxt.fetch_order(order_id, order_symbol), but with the 'info' key removed.

        """

        result = None

        try:
            __order_data = self.__exchange_aux_class.get_order(order_id, order_symbol)

            if __order_data is not None and isinstance(__order_data, dict):
                if self.__upsert_order_in_db(__order_data['symbol'],\
                                             __order_data['id'],\
                                             __order_data,\
                                             __order_data['timestamp'],\
                                             __order_data['status']):

                    result = __order_data

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_id: {order_id}, symbol: {order_symbol}, error: {e}'
            self.__err_logger.error(err_msg)

            result = None

        return result

    def check_order_open(self, order_id, order_symbol):
        """
        check_order_open
        ================

        Checks if the specified order is still open.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_id : str or int
            The ID of the order to check.
        order_symbol : str
            The trading symbol of the order (e.g., 'BTC/USDT').

        Returns:
        --------
        bool
            Returns True if the order is open, otherwise False.
        """
        result = False

        __order_data = self.get_order(order_id, order_symbol)

        if __order_data is not None\
            and isinstance(__order_data, dict)\
            and 'status' in __order_data\
            and isinstance(__order_data['status'], str)\
            and __order_data['status'] == 'open':

            result = True

        return result

    def get_order_status(self, order_id, order_symbol):
        """
        get_order_status
        ================
        
        Retrieves the status of a given order.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_id : str or int
            The ID of the order whose status is to be retrieved.
        order_symbol : str
            The trading symbol of the order (e.g., 'BTC/USDT').

        Returns:
        --------
        str
            The status of the order as a string if found. Possible statuses
            could include 'open', 'closed', 'canceled', etc.
            Returns 'none' if the order does not exist or an error occurs.
        """
        result = 'none'

        __order_data = self.get_order(order_id, order_symbol)

        if __order_data is not None\
            and isinstance(__order_data, dict)\
            and 'status' in __order_data\
            and isinstance(__order_data['status'], str):
            result = __order_data['status']

        return result

    def cancel_order(self, order_id, order_symbol):
        """
        cancel_order
        ============

        This function cancels an order.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_id : str or int
            The ID of the order to be canceled.
        order_symbol : str
            The trading symbol of the order (e.g., 'BTC/USDT').

        Returns:
        --------
        bool
            Returns True if the order was successfully canceled,
            or False if it could not be canceled.
        """
        result = False

        try:
            result = self.__exchange_aux_class.cancel_order(order_id, order_symbol)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_id: {order_id}, symbol: {order_symbol}, error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result

    def create_orders(self, orders):
        """
        create_orders
        =============

        This function creates multiple orders almost simultaneously.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        orders : list
            List of dictionaries, where each dictionary has the following structure:
            {
                order_symbol: str
                    The symbol for the order (e.g., 'BTC/USDT').
                order_side: str
                    The side of the order, only 'buy' or 'sell' is accepted.
                order_amount: float
                    The amount for the order, must be greater than 0.
                order_price: float
                    The price for the order, must be greater than 0.
                order_type: str
                    Only 'limit' or 'limit_maker' types are allowed.
                order_params: dict, optional
                    Additional parameters for the order, default is None.
            }

        Returns:
        --------
        list of dict
            Returns a list of dictionaries, with each dictionary having the structure 
            returned by ccxt.create_order() but with the 'info' key removed.
        """
        result = None

        __order_threads = []

        if orders is not None and isinstance(orders, list):
            for order_parms in orders:
                if order_parms is not None\
                    and isinstance(order_parms, dict)\
                    and len(order_parms) >= 4:
                    if 'order_type' not in order_parms:
                        order_parms['order_type'] = 'limit_maker'
                    if 'order_params' not in order_parms:
                        order_parms['order_params'] = None

                    order_parms_out=(order_parms['order_symbol'],\
                                     order_parms['order_side'],\
                                     order_parms['order_amount'],\
                                     order_parms['order_price'],\
                                     order_parms['order_type'],\
                                     order_parms['order_params'])

                    __order_thread = (
                        ccf.ReturnValueThread(target=self.create_order, args=order_parms_out)
                    )
                    __order_thread.start()
                    __order_threads.append(__order_thread)

            result = []
            for __order_thread in __order_threads:
                __order_result = __order_thread.join(timeout=50)
                result.append(__order_result)

        return result

    def __upsert_order_in_db(self,\
                             order_symbol,\
                             order_id,\
                             order_data,\
                             order_timestamp,\
                             order_status):

        """
        __upsert_order_in_db
        ====================

        This is an internal function responsible for inserting or updating order data 
        into the SQLite database.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_symbol : str
            The symbol of the order (e.g., 'BTC/USDT').
        order_id : (str, int)
            The ID of the order.
        order_data : dict
            A dictionary with the order data. The structure is the same as the one returned 
            by ccxt.fetch_order(order_id, order_symbol) but with the 'info' key removed.
        order_timestamp : int
            The timestamp when the order was created.
        order_status : str
            The status of the order.

        Returns:
        --------
        bool
            True if the data was successfully inserted or updated, False if an error occurred.
        """

        result = False

        try:
            if order_timestamp is None or not isinstance(order_timestamp, int):
                order_timestamp = int(round(time.time()))

            if order_status is None or not isinstance(order_timestamp, str):
                order_status = 'none'

            __order_data = json.dumps(order_data, sort_keys=False, indent=4)
            __order_data = base64.b64encode(__order_data.encode('utf-8')).decode('utf-8')
            with self.__db_conn_lock:
                __query = f'''INSERT INTO {self.__table_name_orders}\
                    (exchange, symbol, order_id, order_data, created_time, status)
                    VALUES(?, ?, ?, ?, ?, ?) ON CONFLICT(exchange, symbol, order_id)
                    DO UPDATE SET
                        order_data = excluded.order_data,
                        status = excluded.status ;
                    '''

                self.__db_cursor.execute(__query, (self.__exchange,\
                                                   order_symbol,\
                                                   order_id,\
                                                   __order_data,\
                                                   order_timestamp,\
                                                   order_status))
                self.__db_conn.commit()
                result = True
        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_id: {order_id}, symbol: {order_symbol}'
            err_msg += f', order_timestamp: {order_timestamp}, order_status: {order_status}'
            err_msg += f', error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result

    def __delete_order_in_db(self,\
                             order_id,\
                             order_symbol=None):
        """
        __delete_order_in_db
        ====================
        
        This is an internal function that deletes an order from the SQLite database.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_id : (str, int)
            The ID of the order.
        order_symbol : str, optional
            The symbol of the order (e.g., 'BTC/USDT'). Optional.

        Returns:
        --------
        bool
            True if the order was successfully deleted, False if an error occurred.
        """

        result = False

        try:
            with self.__db_conn_lock:
                __query = f"DELETE FROM {self.__table_name_orders} WHERE status != 'open'"
                __query += " AND exchange = ? AND order_id = ?"
                if order_symbol is not None:
                    __query += " AND symbol = ? ;"
                    self.__db_cursor.execute(__query,(self.__exchange, order_id, order_symbol))
                else:
                    __query += " ;"
                    self.__db_cursor.execute(__query,(self.__exchange, order_id))

                __rows_eliminated = self.__db_cursor.rowcount

                self.__db_conn.commit()
                if __rows_eliminated > 0:
                    result = True
                else:
                    result = False

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_id: {order_id}, symbol: {order_symbol}, error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result

    def update_orders_in_db(self):
        """
        update_orders_in_db
        ===================
        
        This function iterates over each order stored in the SQLite database and queries
        the exchange to check if the status of the order has changed. If the status has changed,
        it updates the order in the SQLite database.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        bool
            True if all orders were successfully updated, False if an error occurred.
        """
        result = False
        __current_orders = self.__get_orders_in_db()

        if __current_orders is not None\
            and isinstance(__current_orders, dict)\
            and len(__current_orders) > 0:
            __current_orders_tmp = self.__exchange_aux_class.get_orders()
            __current_orders_aux = copy.deepcopy(__current_orders_tmp)

            result = True
            for order_id, order_data in __current_orders_aux.items():
                if order_id in __current_orders\
                    and order_data['symbol'] == __current_orders[order_id]['symbol']\
                    and order_data['status'] != __current_orders[order_id]['status']:

                    result = self.__upsert_order_in_db(order_data['symbol'],\
                                                       order_id,\
                                                       order_data,\
                                                       order_data['timestamp'],\
                                                       order_data['status']) and result

        return result

    def __get_orders_in_db(self, order_status=None):
        """
        __get_orders_in_db
        ==================
        
        This internal function retrieves orders from the SQLite database.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_status : str, optional
            The status of the order in the SQLite database.
            If None, it returns all orders stored in the database.

        Returns:
        --------
        dict
            Returns a dictionary where each key is the order_id, and the corresponding
            value is a dictionary with order_data.
        """

        result = None

        try:
            with self.__db_conn_lock:
                __query = f'SELECT * FROM {self.__table_name_orders} WHERE exchange = ?'
                if order_status is not None:
                    __query += ' AND status = ? ;'
                    self.__db_cursor.execute(__query,(self.__exchange, order_status))
                else:
                    __query += ' ;'
                    self.__db_cursor.execute(__query,(self.__exchange,))

                __orders = [dict(fila) for fila in self.__db_cursor.fetchall()]

                self.__db_conn.commit()

                if __orders is not None and isinstance(__orders, list):
                    result = {}
                    for __order in __orders:
                        if __order is not None and isinstance(__order, dict):
                            __order_id = __order['order_id']
                            __order_data = base64.b64decode(__order['order_data']).decode('utf-8')
                            __order_data = json.loads(__order_data)
                            result[__order_id] = __order_data

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', error: {e}'
            self.__err_logger.error(err_msg)

            result = None

        return result

    def get_orders(self, symbol='BTC/USDT', order_status=None, from_api=False):
        """
        get_orders
        ==========

        This function retrieves orders from the auxiliary class.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_status : str, optional
            The status of the order in the auxiliary class.
            If None, it returns all orders stored in the auxiliary class.
        from_api : bool, optional
            If True, it fetches the orders directly from the exchange API.
            Default is False.

        Returns:
        --------
        dict
            Returns a dictionary where each key is the order_id, and the corresponding
            value is a dictionary with order_data.
        """
        result = None
        if not isinstance(from_api, bool):
            from_api = False

        if from_api:
            result = self.__exchange_aux_class.get_orders(symbol=symbol,
                                                          order_status=order_status,
                                                          from_api=from_api)

        else:
            result = self.__get_orders_in_db(order_status)

        return result

    def delete_order(self, order_id, order_symbol):
        """
        delete_order
        ============

        This function removes the order from the auxiliary class and the database.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_id : (str, int)
            The order id.
        order_symbol : str
            The trading symbol of the order.

        Returns:
        --------
        bool
            Returns True if the order was successfully deleted, or False if it could not be deleted.
        """
        result = False

        result = self.__exchange_aux_class.del_order(order_id)\
            and self.__delete_order_in_db(order_id, order_symbol)

        return result

    def __purge_finished_orders(self, not_orphan_orders):
        """
        __purge_finished_orders
        =======================

        This is an internal function that removes from the auxiliary class and the database
        the orders that are not in the 'open' status, that have been created more than 
        self.__time_to_purge_algo_orders ago, and that are not in the list not_orphan_orders.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        not_orphan_orders : list
            List of order IDs that should not be considered for deletion.

        Returns:
        --------
        bool
            Returns True if the purge was successful, or False if an error occurred.
        """
        result = False

        try:
            __orders = self.__get_orders_in_db()

            if __orders is not None and isinstance(__orders, dict):
                result = True
                for __order_id, __order_data in __orders.items():
                    __symbol = __order_data['symbol']
                    __status = __order_data['status']
                    __order_time = int(round(int(__order_data['timestamp']) / 1000))
                    __order_diff = abs(int(round(time.time())) - __order_time)

                    if __status != 'open'\
                        and __order_diff > self.__time_to_purge_algo_orders\
                        and __order_id not in not_orphan_orders:
                        result = self.__exchange_aux_class.del_order(__order_id)\
                            and self.__delete_order_in_db(__order_id, __symbol)\
                            and result

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result

    def __upsert_algo_order_in_db(self,\
                                  order_algo_id,\
                                  order_symbol,\
                                  order_algo_time_ini=None,\
                                  order_algo_time_end=None,\
                                  order_algo_status=None,\
                                  order_algo_data=None):
        """
        __upsert_algo_order_in_db
        =========================

        This is an internal function that saves an algorithmic order in the SQLite database.
        An algorithmic order consists of two orders and, in some cases, more than two if 
        there were any canceled orders.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_algo_id : str
            The algorithmic order ID (this is the ID used in the class for this type of order, 
            do not confuse it with the order ID).
        order_symbol : str
            The symbol for the algorithmic order.
        order_algo_time_ini : int, optional
            The starting timestamp for the algorithmic order. If None,
            the current timestamp will be used.
        order_algo_time_end : int, optional
            The ending timestamp for the algorithmic order.
        order_algo_status : str, optional
            The status of the algorithmic order.
        order_algo_data : dict, optional
            A dictionary containing the structure of an algorithmic order, which includes:

            {
                'order_amount': 0.5,
                'order_price_dir': 'bull',
                'order_price_in': 'current',
                'order_price_tp': '1%',
                'order_price_sl': '1%',
                'order_trailing_porc': 0.25,
                'order_trailing_max_steps': 5,
                'order_trailing_step': 0,
                'order_algo_result': None,
                'order_algo_result_porc': 0,
                'current_price': 0,
                'current_asset_volume' = 0
                'current_quote_volume' = 0
                'min_price': None,
                'max_price': None,
                'min_price_porc': None,
                'max_price_porc': None,
                'order_algo_0_id': None,
                'order_algo_0_status': None,
                'order_algo_0_result': None,
                'order_algo_0_error_code': None,
                'order_algo_0_error_msg': None,
                'order_algo_1_id': None,
                'order_algo_1_status': None,
                'order_algo_1_result': None,
                'order_algo_1_error_code': None,
                'order_algo_1_error_msg': None,
                'order_algo_orders_list_0_len': 0,
                'order_algo_orders_list_1_len': 0,
                'order_algo_orders_list_0': [],
                'order_algo_orders_list_1': [],
                'order_algo_data': None
            }

        Returns:
        --------
        bool
            Returns True if the upsert operation was successful, otherwise returns False.
        """

        result = False
        __query = None

        try:

            if order_algo_time_ini is None:
                order_algo_time_ini = int(round(time.time()))
            else:
                order_algo_time_ini = int(order_algo_time_ini)

            order_algo_time_date_ini = (
                time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(order_algo_time_ini))
            )

            order_algo_time_date_end = None

            if order_algo_time_end is not None:
                order_algo_time_end = int(order_algo_time_end)
                order_algo_time_date_end = (
                    time.strftime("%Y-%m-%d_%H:%M:%S", time.gmtime(order_algo_time_end))
                )

            __order_algo_data = json.dumps(order_algo_data, sort_keys=False, indent=4)
            __order_algo_data = base64.b64encode(__order_algo_data.encode('utf-8')).decode('utf-8')

            with self.__db_conn_lock:
                __query = f'''INSERT INTO {self.__table_name_algo}\
                    (order_algo_id, exchange, symbol, order_algo_time_ini, order_algo_time_date_ini, order_algo_time_end, order_algo_time_date_end, order_algo_status, order_algo_data)
                    VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(order_algo_id, exchange, symbol)
                    DO UPDATE SET
                        order_algo_time_ini = excluded.order_algo_time_ini,
                        order_algo_time_date_ini = excluded.order_algo_time_date_ini,
                        order_algo_time_end = excluded.order_algo_time_end,
                        order_algo_time_date_end = excluded.order_algo_time_date_end,
                        order_algo_status = excluded.order_algo_status,
                        order_algo_data = excluded.order_algo_data ;
                    '''

                self.__db_cursor.execute(__query, (order_algo_id,\
                                                   self.__exchange,\
                                                   order_symbol,\
                                                   order_algo_time_ini,\
                                                   order_algo_time_date_ini,\
                                                   order_algo_time_end,\
                                                   order_algo_time_date_end,\
                                                   order_algo_status,\
                                                   __order_algo_data))
                self.__db_conn.commit()
                result = True
        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_id: {order_algo_id}, symbol: {order_symbol}'
            err_msg += f', query: {__query}, error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result

    def exec_algo_order(self, order_algo_id: str=None):
        """
        exec_algo_order
        ===============

        This function simply calls the internal function self.__exec_algo_order().

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_algo_id : str, optional
            The algorithmic order ID.

        Returns:
        --------
        None

        """

        result = None

        result = self.__exec_algo_order(order_algo_id=order_algo_id)

        return result

    def __exec_order_algo_queue_0(self, order_symbol, order_side, order_amount, order_price):
        result = None
        try:
            __order_vol_prop = 1.4

            __order_amount_0 = float(order_amount)
            __order_price_0 = order_price

            order_time_in_force = 'GTC'

            res_type = 'both'
            __current_price = 0
            __current_price_vol = 0

            __tick_size = self.symbol_tick_size(order_symbol)

            __current_price_data = None
            if self.check_std_diff_prices(order_symbol):
                __current_price_data = self.get_symbol_price_from_order_book(order_symbol, res_type)

            if __current_price_data is not None and isinstance(__current_price_data, dict):

                __current_price = (
                    (float(__current_price_data['asks']) + float(__current_price_data['bids'])) / 2
                )

                if order_side == 'buy':
                    if __current_price == float(__current_price_data['asks']):
                        __current_price -= __tick_size
                    __current_price_vol = float(__current_price_data['asks_vol'])
                elif order_side == 'sell':
                    if __current_price == float(__current_price_data['bids']):
                        __current_price += __tick_size
                    __current_price_vol = float(__current_price_data['bids_vol'])

                if __order_price_0 == 'current':
                    __order_price_0 = __current_price
                    order_time_in_force = 'GTC'
                else:
                    __order_price_0 = float(__order_price_0)

                __exec_order = False
                if (__order_amount_0 * __order_vol_prop) < __current_price_vol:
                    if __current_price == __order_price_0:
                        __exec_order = True
                    elif __current_price > __order_price_0 and order_side == 'sell':
                        __order_price_0 = __current_price
                        __exec_order = True
                    elif __current_price < __order_price_0 and order_side == 'buy':
                        __order_price_0 = __current_price
                        __exec_order = True

                if order_side == 'buy' and __order_price_0 > __current_price:
                    __order_price_0 = __current_price

                if order_side == 'sell' and __order_price_0 < __current_price:
                    __order_price_0 = __current_price

                if __exec_order:
                    result = self.create_order(order_symbol=order_symbol,\
                                               order_side=order_side,\
                                               order_amount=__order_amount_0,\
                                               order_price=__order_price_0,\
                                               order_time_in_force=order_time_in_force)
                    time.sleep(0.5)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_symbol: {order_symbol}, order_side: {order_side}'
            err_msg += f', order_amount: {order_amount}, order_price: {order_price}'
            err_msg += f', error: {e}'
            self.__err_logger.error(err_msg)
            result = None

        return result

    def __check_order_algo_queue_0(self, order_algo_data):
        result = False
        __max_price_diff_porc = 0.2

        res_type = 'both'

        if order_algo_data is not None and isinstance(order_algo_data, dict):
            __order_data = order_algo_data['order_algo_data']['order_algo_0_result']
            __time_diff = abs(int(round(time.time())) - int(round(__order_data['timestamp']/1000)))
            __order_id = __order_data['id']
            __order_side = __order_data['side']
            __order_symbol = __order_data['symbol']
            __order_price = float(__order_data['price'])

            if __time_diff > self.__order_time_limit:
                __current_price_data = (
                    self.get_symbol_price_from_order_book(__order_symbol, res_type)
                )

                __current_price = 0
                if __order_side == 'buy':
                    __current_price = float(__current_price_data['asks'])
                elif __order_side == 'sell':
                    __current_price = float(__current_price_data['bids'])

                __price_diff_porc = (abs(__current_price - __order_price) / __order_price) * 100

                if __price_diff_porc > __max_price_diff_porc:
                    result = self.cancel_order(__order_id, __order_symbol)
                    time.sleep(0.5)

                    if result is None:
                        result = False

        return result

    def __exec_order_algo_queue_1(self,\
                                  order_symbol,\
                                  order_side,\
                                  order_amount,\
                                  current_algo_price,\
                                  order_tp,\
                                  order_sl,\
                                  order_trailing_porc,\
                                  order_trailing_max_steps,\
                                  order_trailing_step):
        result = None
        try:
            res_type = 'both'
            # order_time_in_force = 'FOK'
            order_time_in_force = 'GTC'
            amount_prop = 1.4

            order_tp = str(order_tp)
            order_sl = str(order_sl)

            order_tp_1 = 0
            order_sl_1 = 0
            order_trailing_porc_1 = None
            order_trailing_max_steps_1 = 0
            order_trailing_step_1 = 0
            __current_price = 0
            __current_volume = 0

            if order_trailing_porc is not None and isinstance(order_trailing_porc, (float, int)):
                order_trailing_porc_1 = order_trailing_porc
            else:
                order_trailing_porc_1 = 0

            if order_trailing_max_steps is not None and isinstance(order_trailing_max_steps, int):
                order_trailing_max_steps_1 = order_trailing_max_steps

            if order_trailing_step is not None and isinstance(order_trailing_step, int):
                order_trailing_step_1 = order_trailing_step

            if '%' in order_tp:
                order_tp_1 = order_tp.replace('%', '')
                order_tp_1 = float(order_tp_1.strip())
                order_tp_1 = (order_tp_1 * current_algo_price) / 100

                if order_side == 'buy':
                    order_tp_1 = current_algo_price + order_tp_1
                elif order_side == 'sell':
                    order_tp_1 = current_algo_price - order_tp_1

            else:
                order_tp_1 = float(order_tp.strip())

            if '%' in order_sl:
                order_sl_1 = order_sl.replace('%', '')
                order_sl_1 = float(order_sl_1.strip())
                order_sl_1 = (order_sl_1 * current_algo_price) / 100

                if order_side == 'buy':
                    order_sl_1 = current_algo_price - order_sl_1
                elif order_side == 'sell':
                    order_sl_1 = current_algo_price + order_sl_1

            else:
                order_sl_1 = float(order_sl.strip())

            __tick_size = self.symbol_tick_size(order_symbol)

            __current_price_data = None
            if self.check_std_diff_prices(order_symbol):
                __current_price_data = self.get_symbol_price_from_order_book(order_symbol, res_type)

            __exec_order = False

            if __current_price_data is not None\
                and isinstance(__current_price_data, dict)\
                and order_tp_1 is not None\
                and order_sl_1 is not None:
                __current_vol_buy = __current_price_data['asks_vol']
                __current_vol_sell = __current_price_data['bids_vol']
                __current_volume = (__current_vol_buy + __current_vol_sell) / 2

                __current_price = (
                    (float(__current_price_data['asks']) + float(__current_price_data['bids'])) / 2
                )

                __data_prt = f'{__current_price_data["asks"]}, {__current_price_data["bids"]}'

                __order_price_1 = None
                __order_side_1 = None

                order_tp_1_delta_tp = (order_trailing_porc_1 * current_algo_price) / 100
                order_tp_1_delta_sl = order_tp_1_delta_tp / 2

                if order_side == 'buy':
                    __current_volume = __current_vol_buy
                    if __current_price == float(__current_price_data['asks']):
                        __current_price -= __tick_size

                    if order_trailing_step_1 > 0:
                        order_tp_1 = order_tp_1 + (order_trailing_step_1 * order_tp_1_delta_tp)
                        order_sl_1 = order_tp_1 - order_tp_1_delta_tp - order_tp_1_delta_sl

                    if __current_price >= order_tp_1:
                        __order_price_1 = __current_price
                        __order_side_1 = 'sell'
                        if (order_amount * amount_prop) < __current_vol_sell:
                            if order_trailing_step_1 >= order_trailing_max_steps_1:
                                __exec_order = True
                            else:
                                result = {}
                                result['is_temp'] = True
                                result['order_trailing_step'] = order_trailing_step_1 + 1
                                result['current_price'] = round(__current_price, 8)
                                result['current_asset_volume'] = round(__current_volume, 8)
                                __current_quote_volume = (
                                    result['current_asset_volume'] * result['current_price']
                                )

                                __current_quote_volume = round(__current_quote_volume, 8)
                                result['current_quote_volume'] = __current_quote_volume
                                result['target_price_sl'] = order_sl_1
                                result['target_price_tp'] = order_tp_1

                                result['result'] = None

                    elif __current_price <= order_sl_1:
                        __order_price_1 = __current_price
                        __order_side_1 = 'sell'
                        if (order_amount * amount_prop) < __current_vol_sell:
                            __exec_order = True


                elif order_side == 'sell':
                    __current_volume = __current_vol_sell
                    if __current_price == float(__current_price_data['bids']):
                        __current_price += __tick_size

                    if order_trailing_step_1 > 0:
                        order_tp_1 = order_tp_1 - (order_trailing_step_1 * order_tp_1_delta_tp)
                        order_sl_1 = order_tp_1 + order_tp_1_delta_tp + order_tp_1_delta_sl

                    if __current_price <= order_tp_1:
                        __order_price_1 = __current_price
                        __order_side_1 = 'buy'
                        if (order_amount * amount_prop) < __current_vol_buy:
                            if order_trailing_step_1 >= order_trailing_max_steps_1:
                                __exec_order = True
                            else:
                                result = {}
                                result['is_temp'] = True
                                result['order_trailing_step'] = order_trailing_step_1 + 1
                                result['current_price'] = round(__current_price, 8)
                                result['current_asset_volume'] = round(__current_volume, 8)
                                __current_quote_volume = (
                                    result['current_asset_volume'] * result['current_price']
                                )

                                __current_quote_volume = round(__current_quote_volume, 8)
                                result['current_quote_volume'] = __current_quote_volume

                                result['target_price_sl'] = order_sl_1
                                result['target_price_tp'] = order_tp_1
                                result['result'] = None

                    elif __current_price >= order_sl_1:
                        __order_price_1 = __current_price
                        __order_side_1 = 'buy'
                        if (order_amount * amount_prop) < __current_vol_buy:
                            __exec_order = True

                if result is None:
                    result = {}
                    result['is_temp'] = True
                    result['order_trailing_step'] = order_trailing_step_1
                    result['current_price'] = round(__current_price, 8)
                    result['current_asset_volume'] = round(__current_volume, 8)
                    __current_quote_volume = (
                        result['current_asset_volume'] * result['current_price']
                    )

                    __current_quote_volume = round(__current_quote_volume, 8)
                    result['current_quote_volume'] = __current_quote_volume

                    result['target_price_sl'] = order_sl_1
                    result['target_price_tp'] = order_tp_1
                    result['result'] = None

                if __exec_order:
                    time.sleep(0.25)
                    result['is_temp'] = False
                    result['order_trailing_step'] = order_trailing_step_1
                    result['current_price'] = round(__current_price, 8)
                    result['current_asset_volume'] = round(__current_volume, 8)
                    __current_quote_volume = (
                        result['current_asset_volume'] * result['current_price']
                    )

                    __current_quote_volume = round(__current_quote_volume, 8)
                    result['current_quote_volume'] = __current_quote_volume

                    result['target_price_sl'] = round(result['target_price_sl'], 8)
                    result['target_price_tp'] = round(result['target_price_tp'], 8)
                    result['result'] = self.create_order(order_symbol=order_symbol,\
                                                         order_side=__order_side_1,\
                                                         order_amount=order_amount,\
                                                         order_price=__order_price_1,\
                                                         order_time_in_force=order_time_in_force)

                    # __tmp_file = '/tmp/tester_exec.txt'
                    # __data_prt += f', {__current_price}, {__order_price_1} -> {__order_side_1}\n'
                    # ccf.file_put_contents(__tmp_file, __data_prt)
                    time.sleep(0.5)
                    # __data_prt = f'CREATE: order_id: {result["result"]["id"]}'
                    # __data_prt += f', order_price: {__order_price_1}'
                    # __data_prt += f', current_price: {__current_price}'
                    # data_prt = f', order_amount: {round((order_amount * amount_prop), 8)}'
                    # data_prt += f', current_asset_volume: {round(__current_volume, 8)}'
                    # print(__data_prt)

                    # pprint.pprint(result, sort_dicts=False)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_symbol: {order_symbol}, order_side: {order_side}'
            err_msg += f', order_amount: {order_amount}, current_algo_price: {current_algo_price}'
            err_msg += f', order_tp: {order_tp}, order_sl: {order_sl}'
            err_msg += f', order_trailing_porc: {order_trailing_porc}'
            err_msg += f', order_trailing_max_steps: {order_trailing_max_steps}'
            err_msg += f', order_trailing_step: {order_trailing_step}'
            err_msg += f', error: {e}'
            self.__err_logger.error(err_msg)
            result = None

        return result

    def __check_order_algo_queue_1(self, order_algo_data):
        result = False
        __max_price_diff_porc = 0.2

        res_type = 'both'

        if order_algo_data is not None and isinstance(order_algo_data, dict):
            __order_algo_id = order_algo_data['order_algo_id']
            __order_data = order_algo_data['order_algo_data']['order_algo_1_result']
            __time_diff = abs(int(round(time.time())) - int(round(__order_data['timestamp']/1000)))
            __order_id = __order_data['id']
            __order_side = __order_data['side']
            __order_symbol = __order_data['symbol']
            __order_price = float(__order_data['price'])

            if __time_diff > self.__order_time_limit:
                __current_price_data = (
                    self.get_symbol_price_from_order_book(__order_symbol, res_type)
                )

                __current_price = 0
                if __order_side == 'buy':
                    __current_price = float(__current_price_data['asks'])
                elif __order_side == 'sell':
                    __current_price = float(__current_price_data['bids'])

                __price_diff_porc = (abs(__current_price - __order_price) / __order_price) * 100

                # __tmp_file = '/tmp/tester_check.txt'
                # __data_prt = f'{__current_price_data["asks"]}, {__current_price_data["bids"]}'
                # __data_prt += f', {__current_price}, {__order_price}'
                # __data_prt += f' -> {__price_diff_porc} -> {__order_side}\n'
                # ccf.file_put_contents(__tmp_file, __data_prt, 'a+')

                if __price_diff_porc > __max_price_diff_porc:

                    result = self.cancel_order(__order_id, __order_symbol)
                    time.sleep(0.5)

                    if result is None:
                        result = False

        return result

    def __exec_algo_order(self, order_algo_id: str=None):
        """
        __exec_algo_order
        =================

        This is an internal function responsible for executing an algorithmic order. 
        This function is called multiple times during the lifecycle of the algorithmic 
        order, retrieving the state of the algorithmic order from the database and 
        checking the prices via a WebSocket connection. It decides whether to execute 
        a buy or sell order based on the parameters with which the algorithmic order was 
        created. When the price reaches the take profit or stop loss, it executes another 
        order in the opposite direction. This function is automatically called by the class.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_algo_id : str, optional
            The algorithmic order ID.

        Returns:
        --------
        None
        """

        result = None

        __print_debug = False
        __order_algo_status_out = ''

        if order_algo_id is not None and isinstance(order_algo_id, str) and len(order_algo_id) > 0:

            __order_algo_data = self.get_algo_order(order_algo_id)

            if __order_algo_data is not None and isinstance(__order_algo_data, dict):
                if __order_algo_data['order_algo_status'] == 'order_step_0_queue':
                    __order_algo_status_out = __order_algo_data['order_algo_status']

                    __order_algo_status = 'order_step_0_running'

                    __order_side = 'buy'
                    if __order_algo_data['order_algo_data']['order_price_dir'] == 'bull':
                        __order_side = 'buy'
                    elif __order_algo_data['order_algo_data']['order_price_dir'] == 'bear':
                        __order_side = 'sell'

                    __order_data_0 = (
                        self.__exec_order_algo_queue_0(__order_algo_data['symbol'],\
                            __order_side,\
                            __order_algo_data['order_algo_data']['order_amount'],\
                            __order_algo_data['order_algo_data']['order_price_in'])
                    )

                    if __order_data_0 is not None and isinstance(__order_data_0, dict):

                        __order_algo_data['order_algo_data']['order_algo_0_id'] = (
                            __order_data_0['id']
                        )
                        __order_algo_data['order_algo_data']['order_algo_0_status'] = (
                            __order_data_0['status']
                        )
                        __order_algo_data['order_algo_data']['order_algo_0_result'] = (
                            __order_data_0
                        )
                        __order_algo_data['order_algo_data']['order_algo_0_error_code'] = None
                        __order_algo_data['order_algo_data']['order_algo_0_error_msg'] = None
                        __order_algo_data['order_algo_data']['order_algo_orders_list_0']\
                            .append(__order_data_0)

                        __order_algo_data['order_algo_data']['order_algo_orders_list_0_len'] = (
                            len(__order_algo_data['order_algo_data']['order_algo_orders_list_0'])
                        )

                        __order_algo_time_end = int(round(time.time()))

                        if self.__upsert_algo_order_in_db(
                            order_algo_id,\
                            __order_algo_data['symbol'],\
                            int(__order_algo_data['order_algo_time_ini']),\
                            __order_algo_time_end,\
                            __order_algo_status,\
                            __order_algo_data['order_algo_data']):
                            __print_debug = True

                elif __order_algo_data['order_algo_status'] == 'order_step_0_running':
                    __order_algo_status_out = __order_algo_data['order_algo_status']
                    __update_db = False

                    __order_data_0 = (
                        self.get_order(__order_algo_data['order_algo_data']['order_algo_0_id'],\
                                       __order_algo_data['symbol'])
                    )

                    __order_algo_status = 'order_step_0_running'
                    if __order_data_0 is not None and isinstance(__order_data_0, dict):
                        if __order_data_0['status'] == 'closed':
                            __order_algo_data['order_algo_data']['order_amount'] = (
                                __order_data_0['amount']
                            )
                            __order_algo_data['order_algo_data']['order_price_in'] = (
                                __order_data_0['price']
                            )

                            __order_algo_data['order_algo_data']['order_algo_0_status'] = (
                                __order_data_0['status']
                            )
                            __order_algo_data['order_algo_data']['order_algo_0_result'] = (
                                __order_data_0
                            )

                            __order_algo_status = 'order_step_1_queue'
                            __update_db = True
                        elif __order_data_0['status'] != 'open':
                            __update_db = True
                            __order_side = 'buy'
                            if __order_algo_data['order_algo_data']['order_price_dir'] == 'bull':
                                __order_side = 'buy'
                            elif __order_algo_data['order_algo_data']['order_price_dir'] == 'bear':
                                __order_side = 'sell'

                            __order_data_0 = (
                                self.__exec_order_algo_queue_0(\
                                    __order_algo_data['symbol'],\
                                    __order_side,\
                                    __order_algo_data['order_algo_data']['order_amount'],\
                                    __order_algo_data['order_algo_data']['order_price_in']))

                            if __order_data_0 is not None and isinstance(__order_data_0, dict):
                                __order_algo_status = 'order_step_0_running'

                                __order_algo_data['order_algo_data']['order_algo_0_id'] = (
                                    __order_data_0['id']
                                )
                                __order_algo_data['order_algo_data']['order_algo_0_status'] = (
                                    __order_data_0['status']
                                )
                                __order_algo_data['order_algo_data']['order_algo_0_result'] = (
                                    __order_data_0
                                )
                                __order_algo_data['order_algo_data']['order_algo_0_error_code'] = (
                                    None
                                )
                                __order_algo_data['order_algo_data']['order_algo_0_error_msg'] = (
                                    None
                                )
                                __order_algo_data['order_algo_data']['order_algo_orders_list_0']\
                                    .append(__order_data_0)
                                __order_algo_data['order_algo_data']\
                                    ['order_algo_orders_list_0_len'] = (
                                    len(__order_algo_data['order_algo_data']\
                                        ['order_algo_orders_list_0'])
                                )

                        else:

                            __order_data_0_tmp = self.__check_order_algo_queue_0(__order_algo_data)

                            if __order_data_0_tmp and isinstance(__order_data_0_tmp, dict):
                                __order_algo_data['order_algo_data']['order_amount'] = (
                                    __order_data_0_tmp['amount']
                                )
                                __order_algo_data['order_algo_data']['order_price_in'] = (
                                    __order_data_0_tmp['price']
                                )

                                __order_algo_data['order_algo_data']['order_algo_0_status'] = (
                                    __order_data_0_tmp['status']
                                )
                                __order_algo_data['order_algo_data']['order_algo_0_result'] = (
                                    __order_data_0_tmp
                                )
                                __update_db = True
                            else:
                                __update_db = False

                            __order_algo_status = 'order_step_0_running'

                        if __update_db:
                            __order_algo_time_end = int(round(time.time()))
                            if self.__upsert_algo_order_in_db(
                                    order_algo_id,\
                                    __order_algo_data['symbol'],\
                                    int(__order_algo_data['order_algo_time_ini']),\
                                    __order_algo_time_end,\
                                    __order_algo_status,\
                                    __order_algo_data['order_algo_data']):
                                __print_debug = True

                elif __order_algo_data['order_algo_status'] == 'order_step_1_queue':
                    __order_algo_status_out = __order_algo_data['order_algo_status']

                    if __order_algo_data['order_algo_data']['order_price_in'] is not None\
                        and isinstance(__order_algo_data['order_algo_data']['order_price_in'],\
                                       (float, int)):

                        __order_amount_1 = __order_algo_data['order_algo_data']['order_amount']
                        __order_price_1 = __order_algo_data['order_algo_data']['order_price_in']

                        __order_price_tp = __order_algo_data['order_algo_data']['order_price_tp']
                        __order_price_sl = __order_algo_data['order_algo_data']['order_price_sl']

                        __order_trailing_porc = (
                            __order_algo_data['order_algo_data']['order_trailing_porc']
                        )

                        __order_trailing_max_steps = (
                            __order_algo_data['order_algo_data']['order_trailing_max_steps']
                        )

                        __order_trailing_step = (
                            __order_algo_data['order_algo_data']['order_trailing_step']
                        )

                        __order_side = 'buy'
                        if __order_algo_data['order_algo_data']['order_price_dir'] == 'bull':
                            __order_side = 'buy'
                        elif __order_algo_data['order_algo_data']['order_price_dir'] == 'bear':
                            __order_side = 'sell'

                        __order_data_1 = (
                            self.__exec_order_algo_queue_1(__order_algo_data['symbol'],\
                                                           __order_side,\
                                                           __order_amount_1,\
                                                           __order_price_1,\
                                                           __order_price_tp,\
                                                           __order_price_sl,\
                                                           __order_trailing_porc,\
                                                           __order_trailing_max_steps,\
                                                           __order_trailing_step)
                        )

                        if __order_data_1 is not None:
                            if isinstance(__order_data_1, dict):
                                try:
                                    if 'is_temp' in __order_data_1:

                                        __order_algo_data['order_algo_data']\
                                            ['order_trailing_step'] =\
                                                __order_data_1['order_trailing_step']

                                        __order_algo_data['order_algo_data']['current_price'] = (
                                            __order_data_1['current_price']
                                        )

                                        __order_algo_data['order_algo_data']\
                                            ['current_asset_volume'] = (
                                            __order_data_1['current_asset_volume']
                                        )

                                        __order_algo_data['order_algo_data']\
                                            ['current_quote_volume'] = (
                                            __order_data_1['current_quote_volume']
                                        )

                                        if __order_algo_data['order_algo_data']['max_price']\
                                            is None\
                                            or __order_data_1['current_price'] \
                                                > __order_algo_data['order_algo_data']['max_price']:
                                            __order_algo_data['order_algo_data']['max_price'] = (
                                                __order_data_1['current_price']
                                            )

                                        if __order_algo_data['order_algo_data']['min_price']\
                                            is None\
                                            or __order_data_1['current_price'] \
                                                < __order_algo_data['order_algo_data']['min_price']:
                                            __order_algo_data['order_algo_data']['min_price'] = (
                                                __order_data_1['current_price']
                                            )

                                        __order_algo_data['order_algo_data']['min_price_porc'] =\
                                            __order_algo_data['order_algo_data']['order_price_in']\
                                                - __order_algo_data['order_algo_data']['min_price']

                                        __order_algo_data['order_algo_data']['min_price_porc'] =\
                                            __order_algo_data['order_algo_data']['min_price_porc']\
                                                / __order_algo_data['order_algo_data']\
                                                    ['order_price_in']

                                        __order_algo_data['order_algo_data']['min_price_porc'] = (
                                            abs(round(__order_algo_data['order_algo_data']\
                                                    ['min_price_porc'] * 100, 4))
                                        )

                                        __order_algo_data['order_algo_data']['max_price_porc'] =\
                                            __order_algo_data['order_algo_data']['order_price_in']\
                                                - __order_algo_data['order_algo_data']['max_price']

                                        __order_algo_data['order_algo_data']['max_price_porc'] =\
                                            __order_algo_data['order_algo_data']['max_price_porc']\
                                                / __order_algo_data['order_algo_data']\
                                                    ['order_price_in']

                                        __order_algo_data['order_algo_data']['max_price_porc'] = (
                                            abs(round(__order_algo_data['order_algo_data']\
                                                    ['max_price_porc'] * 100, 4))
                                        )

                                        # __update_db = True

                                        if not __order_data_1['is_temp']\
                                            and 'result' in __order_data_1\
                                            and isinstance(__order_data_1['result'], dict):

                                            __order_algo_status_out = 'order_step_1_running'

                                            __order_algo_data['order_algo_data']\
                                                ['order_algo_1_id'] =\
                                                    __order_data_1['result']['id']

                                            __order_algo_data['order_algo_data']\
                                                ['order_algo_1_status'] =\
                                                    __order_data_1['result']['status']

                                            __order_algo_data['order_algo_data']\
                                                ['order_algo_1_result'] = __order_data_1['result']

                                            __order_algo_data['order_algo_data']\
                                                ['order_algo_1_error_code'] = None

                                            __order_algo_data['order_algo_data']\
                                                ['order_algo_1_error_msg'] = None

                                            __order_algo_data['order_algo_data']\
                                                ['order_algo_orders_list_1']\
                                                    .append(__order_data_1['result'])

                                            __order_algo_data['order_algo_data']\
                                                ['order_algo_orders_list_1_len'] = (
                                                len(__order_algo_data['order_algo_data']\
                                                    ['order_algo_orders_list_1'])
                                            )

                                    __order_algo_data['order_algo_data']['target_price_sl'] = (
                                        __order_data_1['target_price_sl']
                                    )
                                    __order_algo_data['order_algo_data']['target_price_tp'] = (
                                        __order_data_1['target_price_tp']
                                    )

                                    __order_algo_time_end = int(round(time.time()))

                                    if self.__upsert_algo_order_in_db(
                                        order_algo_id,\
                                        __order_algo_data['symbol'],\
                                        int(__order_algo_data['order_algo_time_ini']),\
                                        __order_algo_time_end,\
                                        __order_algo_status_out,\
                                        __order_algo_data['order_algo_data']):
                                        __print_debug = True

                                except Exception as e: # pylint: disable=broad-except
                                    __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                                    err_msg = f'Found error in {__l_function}'
                                    err_msg += f', exchange: {self.__exchange}'
                                    err_msg += f', error: {e}'
                                    self.__err_logger.error(err_msg)

                elif __order_algo_data['order_algo_status'] == 'order_step_1_running':
                    __update_db = False
                    __order_algo_status_out = __order_algo_data['order_algo_status']

                    __order_data_1 = (
                        self.get_order(__order_algo_data['order_algo_data']['order_algo_1_id'],\
                                       __order_algo_data['symbol'])
                    )

                    __order_algo_status = 'order_step_1_running'
                    if __order_data_1 is not None and isinstance(__order_data_1, dict):
                        if __order_data_1['status'] == 'closed':
                            __update_db = True

                            __order_algo_data['order_algo_data']['order_algo_1_status'] = (
                                __order_data_1['status']
                            )
                            __order_algo_data['order_algo_data']['order_algo_1_result'] = (
                                __order_data_1
                            )

                            __order_algo_result = None
                            __o_a_r_p = 0

                            __order_data_0 = (
                                __order_algo_data['order_algo_data']['order_algo_0_result']
                            )

                            __o_a_r_p = (
                                (float(__order_data_1['price']) - float(__order_data_0['price']))\
                                    / float(__order_data_0['price'])
                            )

                            __o_a_r_p = round(abs(__o_a_r_p * 100), 4)

                            if __order_algo_data['order_algo_data']['order_price_dir'] == 'bull':
                                if float(__order_data_1['price']) > float(__order_data_0['price']):
                                    __order_algo_result = 'win'
                                else:
                                    __order_algo_result = 'lost'
                                    __o_a_r_p = - __o_a_r_p
                            if __order_algo_data['order_algo_data']['order_price_dir'] == 'bear':
                                if float(__order_data_1['price']) < float(__order_data_0['price']):
                                    __order_algo_result = 'win'
                                else:
                                    __order_algo_result = 'lost'
                                    __o_a_r_p = - __o_a_r_p

                            __order_algo_data['order_algo_data']['order_algo_result'] = (
                                __order_algo_result
                            )

                            __order_algo_data['order_algo_data']['order_algo_result_porc'] = (
                                __o_a_r_p
                            )

                            __order_algo_status = 'order_algo_finished'
                        elif __order_data_1['status'] != 'open':
                            __order_amount_1 = __order_algo_data['order_algo_data']['order_amount']
                            __order_price_1 = __order_algo_data['order_algo_data']['order_price_in']

                            __order_price_tp = (
                                __order_algo_data['order_algo_data']['order_price_tp']
                            )
                            __order_price_sl = (
                                __order_algo_data['order_algo_data']['order_price_sl']
                            )

                            __order_trailing_porc = (
                                __order_algo_data['order_algo_data']['order_trailing_porc']
                            )

                            __order_trailing_max_steps = (
                                __order_algo_data['order_algo_data']['order_trailing_max_steps']
                            )

                            __order_trailing_step = (
                                __order_algo_data['order_algo_data']['order_trailing_step']
                            )

                            __order_side = 'buy'
                            if __order_algo_data['order_algo_data']['order_price_dir'] == 'bull':
                                __order_side = 'buy'
                            elif __order_algo_data['order_algo_data']['order_price_dir'] == 'bear':
                                __order_side = 'sell'

                            __order_data_1 = (
                                self.__exec_order_algo_queue_1(__order_algo_data['symbol'],\
                                                               __order_side,\
                                                               __order_amount_1,\
                                                               __order_price_1,\
                                                               __order_price_tp,\
                                                               __order_price_sl,\
                                                               __order_trailing_porc,\
                                                               __order_trailing_max_steps,\
                                                               __order_trailing_step)
                            )

                            ##################################################################

                            if __order_data_1 is not None:
                                if isinstance(__order_data_1, dict):
                                    try:
                                        if 'is_temp' in __order_data_1:

                                            __order_algo_data['order_algo_data']\
                                                ['order_trailing_step'] =\
                                                    __order_data_1['order_trailing_step']

                                            __order_algo_data['order_algo_data']\
                                                ['current_price'] = __order_data_1['current_price']

                                            __order_algo_data['order_algo_data']\
                                                ['current_asset_volume'] = (
                                                __order_data_1['current_asset_volume']
                                            )

                                            __order_algo_data['order_algo_data']\
                                                ['current_quote_volume'] = (
                                                __order_data_1['current_quote_volume']
                                            )

                                            if __order_algo_data['order_algo_data']['max_price']\
                                                is None\
                                                or __order_data_1['current_price'] >\
                                                    __order_algo_data['order_algo_data']\
                                                        ['max_price']:
                                                __order_algo_data['order_algo_data']\
                                                    ['max_price'] = __order_data_1['current_price']

                                            if __order_algo_data['order_algo_data']['min_price']\
                                                is None\
                                                or __order_data_1['current_price'] \
                                                    < __order_algo_data['order_algo_data']\
                                                        ['min_price']:
                                                __order_algo_data['order_algo_data']['min_price'] =\
                                                    __order_data_1['current_price']

                                            __order_algo_data['order_algo_data']\
                                                ['min_price_porc'] =\
                                                __order_algo_data['order_algo_data']\
                                                    ['order_price_in'] -\
                                                        __order_algo_data['order_algo_data']\
                                                            ['min_price']

                                            __order_algo_data['order_algo_data']\
                                                ['min_price_porc'] =\
                                                __order_algo_data['order_algo_data']\
                                                    ['min_price_porc'] /\
                                                        __order_algo_data['order_algo_data']\
                                                            ['order_price_in']

                                            __order_algo_data['order_algo_data']\
                                                ['min_price_porc'] =\
                                                abs(round(__order_algo_data['order_algo_data']\
                                                          ['min_price_porc'] * 100, 4))

                                            __order_algo_data['order_algo_data']\
                                                ['max_price_porc'] =\
                                                __order_algo_data['order_algo_data']\
                                                    ['order_price_in']\
                                                    - __order_algo_data['order_algo_data']\
                                                        ['max_price']

                                            __order_algo_data['order_algo_data']\
                                                ['max_price_porc'] =\
                                                __order_algo_data['order_algo_data']\
                                                    ['max_price_porc']\
                                                    / __order_algo_data['order_algo_data']\
                                                        ['order_price_in']

                                            __order_algo_data['order_algo_data']\
                                                ['max_price_porc'] =\
                                                    abs(round(__order_algo_data['order_algo_data']\
                                                              ['max_price_porc'] * 100, 4))

                                            # __update_db = True

                                            if not __order_data_1['is_temp']\
                                                and 'result' in __order_data_1\
                                                and isinstance(__order_data_1['result'], dict):

                                                __order_algo_status_out = 'order_step_1_running'

                                                __order_algo_data['order_algo_data']\
                                                    ['order_algo_1_id'] =\
                                                        __order_data_1['result']['id']

                                                __order_algo_data['order_algo_data']\
                                                    ['order_algo_1_status']\
                                                        = __order_data_1['result']['status']

                                                __order_algo_data['order_algo_data']\
                                                    ['order_algo_1_result'] =\
                                                        __order_data_1['result']

                                                __order_algo_data['order_algo_data']\
                                                    ['order_algo_1_error_code'] = None

                                                __order_algo_data['order_algo_data']\
                                                    ['order_algo_1_error_msg'] = None

                                                __order_algo_data['order_algo_data']\
                                                    ['order_algo_orders_list_1']\
                                                        .append(__order_data_1['result'])

                                                __order_algo_data['order_algo_data']\
                                                    ['order_algo_orders_list_1_len'] = (
                                                    len(__order_algo_data['order_algo_data']\
                                                        ['order_algo_orders_list_1'])
                                                )

                                        __order_algo_data['order_algo_data']['target_price_sl'] = (
                                            __order_data_1['target_price_sl']
                                        )
                                        __order_algo_data['order_algo_data']['target_price_tp'] = (
                                            __order_data_1['target_price_tp']
                                        )

                                        __order_algo_time_end = int(round(time.time()))

                                        if self.__upsert_algo_order_in_db(
                                            order_algo_id,\
                                            __order_algo_data['symbol'],\
                                            int(__order_algo_data['order_algo_time_ini']),\
                                            __order_algo_time_end,\
                                            __order_algo_status_out,\
                                            __order_algo_data['order_algo_data']):
                                            __print_debug = True

                                    except Exception as e: # pylint: disable=broad-except
                                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                                        err_msg = f'Found error in {__l_function}'
                                        err_msg += f', exchange: {self.__exchange}'
                                        err_msg += f', error: {e}'
                                        self.__err_logger.error(err_msg)

                        else:
                            __order_data_1_tmp = self.__check_order_algo_queue_1(__order_algo_data)

                            if __order_data_1_tmp and isinstance(__order_data_1_tmp, dict):

                                __order_algo_data['order_algo_data']['order_algo_1_status'] = (
                                    __order_data_1_tmp['status']
                                )
                                __order_algo_data['order_algo_data']['order_algo_1_result'] = (
                                    __order_data_1_tmp
                                )
                                __update_db = True
                            else:
                                __update_db = False

                            __order_algo_status = 'order_step_1_running'

                        __order_algo_time_end = int(round(time.time()))

                        if __update_db:
                            if self.__upsert_algo_order_in_db(
                                    order_algo_id,\
                                    __order_algo_data['symbol'],\
                                    int(__order_algo_data['order_algo_time_ini']),\
                                    __order_algo_time_end,\
                                    __order_algo_status,\
                                    __order_algo_data['order_algo_data']):
                                __print_debug = True


            __print_debug = False

            if __print_debug:
                print('='*140)
                __order_algo_data = self.get_algo_order(order_algo_id)
                pprint.pprint(__order_algo_data, sort_dicts=False)
                print('='*140)

        return result

    def queue_algo_order(self,\
                         order_symbol: str=None,\
                         order_amount: str='',\
                         order_price_dir: str='bull',\
                         order_price_in: str='current',\
                         order_price_tp: str='',\
                         order_price_sl: str='',\
                         order_trailing_porc: float=None,\
                         order_trailing_max_steps: int=0):
        """
        queue_algo_order
        ================

        This function queues an algorithmic order for execution. If the order is successfully
        queued, it returns the algorithmic order ID; otherwise, it returns None.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_symbol : str
            The trading symbol for the order.
        order_amount : str
            The order amount, must be a valid representation of a float number.
        order_price_dir : str
            The order price direction, allowed values are 'bull' or 'bear'.
        order_price_in : str
            The order price, allowed values are 'current' or a valid representation
            of a float number.
        order_price_tp : str
            The take profit price, allowed values are a valid representation of a float number
            or a valid representation of a float number followed by the '%' symbol.
        order_price_sl : str
            The stop loss price, allowed values are a valid representation of a float number
            or a valid representation of a float number followed by the '%' symbol.
        order_trailing_porc : float, optional
            The percentage of trailing to move the take profit. If None, no trailing will occur.
        order_trailing_max_steps : int, default=0
            The maximum steps for trailing. A value of 0 means unlimited steps.

        Returns:
        --------
        str or None
            Returns the algorithmic order ID as a string if successful, otherwise None.
        """
        result = None

        if order_symbol not in self.__symbols_to_trade:
            return result

        try:
            order_price_in = str(order_price_in)
            order_price_tp = str(order_price_tp)
            order_price_sl = str(order_price_sl)

            if order_price_in != 'current' and float(order_price_in) > 0:
                if '%' not in order_price_tp and float(order_price_tp) > 0:
                    if order_price_dir == 'bull' and float(order_price_tp) < float(order_price_in):
                        return result
                    if order_price_dir == 'bear' and float(order_price_tp) > float(order_price_in):
                        return result

                if '%' not in order_price_sl and float(order_price_sl) > 0:
                    if order_price_dir == 'bull' and float(order_price_sl) > float(order_price_in):
                        return result
                    if order_price_dir == 'bear' and float(order_price_sl) < float(order_price_in):
                        return result

                __res_type = 'mid'

                __current_price = self.get_symbol_price_from_order_book(order_symbol, __res_type)

                # if order_price_dir == 'bull' and float(order_price_in) > __current_price:
                #     return result
                # if order_price_dir == 'bear' and float(order_price_in) < __current_price:
                #     return result

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_symbol: {order_symbol}, order_price_dir: {order_price_dir}'
            err_msg += f', order_price_in: {order_price_in}, order_price_tp: {order_price_tp}'
            err_msg += f', order_price_sl: {order_price_sl}'
            err_msg += f', error: {e}'
            self.__err_logger.error(err_msg)

            result = None
            return result

        __order_algo_time_ini = time.time()
        __order_algo_time_end = None
        __time_int = int(math.floor(__order_algo_time_ini))
        __time = abs(__order_algo_time_ini - __time_int)
        __time = str(__time)[2:].ljust(23, '0')
        __time_str = f'{time.strftime("%Y-%m-%d_%H:%M:%S", time.gmtime(__time_int))}.{__time}'
        __base_id = f'{self.__exchange}_{order_symbol}_{order_price_dir}_{__time_str}_'
        __base_id += f'{ccf.random_string(14)}'
        __base_id = ccf.sha256(__base_id)
        __order_algo_time_ini = int(round(__order_algo_time_ini))

        __order_algo_id = f'{__time_str}__{self.__exchange}__{order_symbol.replace("/","_")}__'
        __order_algo_id += f'{__base_id}'

        __order_algo_status = 'order_step_0_queue'
        __order_algo_data = {}
        __order_algo_data['order_amount'] = order_amount
        __order_algo_data['order_price_dir'] = order_price_dir
        __order_algo_data['order_price_in'] = order_price_in
        __order_algo_data['order_price_tp'] = order_price_tp
        __order_algo_data['order_price_sl'] = order_price_sl
        __order_algo_data['order_trailing_porc'] = order_trailing_porc
        __order_algo_data['order_trailing_max_steps'] = order_trailing_max_steps
        __order_algo_data['order_trailing_step'] = 0
        __order_algo_data['order_algo_result'] = None
        __order_algo_data['order_algo_result_porc'] = 0
        __order_algo_data['current_price'] = 0
        __order_algo_data['current_asset_volume'] = 0
        __order_algo_data['current_quote_volume'] = 0
        __order_algo_data['target_price_sl'] = 0
        __order_algo_data['target_price_tp'] = 0
        __order_algo_data['min_price'] = None
        __order_algo_data['max_price'] = None
        __order_algo_data['min_price_porc'] = None
        __order_algo_data['max_price_porc'] = None
        __order_algo_data['order_algo_0_id'] = None
        __order_algo_data['order_algo_0_status'] = None
        __order_algo_data['order_algo_0_result'] = None
        __order_algo_data['order_algo_0_error_code'] = None
        __order_algo_data['order_algo_0_error_msg'] = None
        __order_algo_data['order_algo_1_id'] = None
        __order_algo_data['order_algo_1_status'] = None
        __order_algo_data['order_algo_1_result'] = None
        __order_algo_data['order_algo_1_error_code'] = None
        __order_algo_data['order_algo_1_error_msg'] = None
        __order_algo_data['order_algo_orders_list_0_len'] = 0
        __order_algo_data['order_algo_orders_list_1_len'] = 0
        __order_algo_data['order_algo_orders_list_0'] = []
        __order_algo_data['order_algo_orders_list_1'] = []
        __order_algo_data['order_algo_data'] = None

        if self.__upsert_algo_order_in_db(__order_algo_id,\
                                          order_symbol,\
                                          __order_algo_time_ini,\
                                          __order_algo_time_end,\
                                          __order_algo_status,\
                                          __order_algo_data):
            result = __order_algo_id

        return result

    def get_algo_orders(self, skip_finished=True):
        """
        get_algo_orders
        ===============

        This function is used to call the internal function __get_algo_orders_in_db().

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        skip_finished : bool, default=True
            If True, finished orders will be skipped in the result.

        Returns:
        --------
        dict
            Returns a dictionary containing the algorithmic orders.
            The keys are the algo order IDs, and the values are
            dictionaries with the algo order data.
        """
        result = self.__get_algo_orders_in_db(skip_finished)
        return result

    def __get_algo_orders_in_db(self, skip_finished=True):
        """
        __get_algo_orders_in_db
        =======================

        This function retrieves a dictionary containing the data of the algorithmic orders stored
        in the database.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        skip_finished : bool, default=True
            If True, finished orders will be skipped in the result.

        Returns:
        --------
        dict
            Returns a dictionary where each key is the ID of the algorithmic order,
            and the value is a dictionary containing the algorithmic order data.
        """

        result = None
        __query = None

        try:
            with self.__db_conn_lock:
                if skip_finished:
                    __query = f'SELECT * FROM {self.__table_name_algo} '
                    __query += 'WHERE order_algo_status != "order_algo_finished" AND exchange = ? '
                    __query += 'ORDER BY order_algo_time_ini ;'
                else:
                    __query = f'SELECT * FROM {self.__table_name_algo} WHERE exchange = ? '
                    __query += 'ORDER BY order_algo_time_ini ;'

                self.__db_cursor.execute(__query,(self.__exchange, ))

                __orders = [dict(fila) for fila in self.__db_cursor.fetchall()]

                self.__db_conn.commit()

                if __orders is not None and isinstance(__orders, list):
                    result = {}
                    for __algo_order in __orders:
                        if __algo_order is not None and isinstance(__algo_order, dict):
                            __order_algo_id = __algo_order['order_algo_id']
                            __order_algo_data = (
                                base64.b64decode(__algo_order['order_algo_data']).decode('utf-8')
                            )
                            __order_algo_data = json.loads(__order_algo_data)

                            __order_algo_out = {}
                            __order_algo_out['order_algo_id'] = __order_algo_id
                            __order_algo_out['exchange'] = __algo_order['exchange']
                            __order_algo_out['symbol'] = __algo_order['symbol']
                            __order_algo_out['order_algo_time_ini'] = (
                                __algo_order['order_algo_time_ini']
                            )
                            __order_algo_out['order_algo_time_date_ini'] = (
                                __algo_order['order_algo_time_date_ini']
                            )
                            __order_algo_out['order_algo_time_end'] = (
                                __algo_order['order_algo_time_end']
                            )
                            __order_algo_out['order_algo_time_date_end'] = (
                                __algo_order['order_algo_time_date_end']
                            )
                            __order_algo_out['order_algo_status'] = (
                                __algo_order['order_algo_status']
                            )
                            __order_algo_out['order_algo_data'] = __order_algo_data

                            result[__order_algo_id] = __order_algo_out

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', error: {e}'
            self.__err_logger.error(err_msg)

            result = None

        return result

    def algo_order_finished(self, order_algo_id):
        """
        algo_order_finished
        ===================

        Checks if the algorithmic order has finished.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_algo_id : str
            The ID of the algorithmic order to check.

        Returns:
        --------
        bool
            Returns True if the order has finished, or False otherwise.
        """
        result = False

        try:
            __algo_order_data = self.get_algo_order(order_algo_id)

            if __algo_order_data is not None\
                and isinstance(__algo_order_data, dict)\
                and __algo_order_data['order_algo_status'] == 'order_algo_finished':
                result = True

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f',order_algo_id: {order_algo_id}, error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result

    def get_algo_order(self, order_algo_id):
        """
        get_algo_order
        ==============

        Retrieves the data of an algorithmic order.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_algo_id : str
            The ID of the algorithmic order to retrieve.

        Returns:
        --------
        dict
            This dictionary contains the structure of an algorithmic order
            or None if it does not exist or if there was an error.
        """
        result = None

        __result_tmp = self.__get_algo_order_in_db(order_algo_id)

        if __result_tmp is None:
            __result_tmp = self.__get_algo_order_from_file(order_algo_id)

        if __result_tmp is not None and isinstance(__result_tmp, list) and len(__result_tmp) > 0:
            result = __result_tmp[0]

        return result

    def __get_algo_order_from_file(self, order_algo_id):
        result = None

        try:
            year, month = 1970, 1

            if order_algo_id is not None\
                and isinstance(order_algo_id, str)\
                and len(order_algo_id) > 8:
                __ym = order_algo_id.split('-', 2)

                if __ym is not None and isinstance(__ym, list) and len(__ym) >= 2:
                    year, month = __ym[0], __ym[1]
                    __algo_orders_hist_dir = os.path.join(self.__var_dir, 'historic', year, month)
                    __algo_order_path = f'{__algo_orders_hist_dir}/{order_algo_id}*.json'

                    matching_files = glob.glob(__algo_order_path)

                    if matching_files is not None\
                        and isinstance(matching_files, list)\
                        and len(matching_files) > 0:
                        result = []

                        for __algo_order_file in matching_files:

                            if os.path.exists(__algo_order_file):
                                __data_json = ccf.file_get_contents(__algo_order_file)

                                if ccf.is_json(__data_json):
                                    __data = json.loads(__data_json)
                                    result.append(__data)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_algo_id: {order_algo_id}, error: {e}'
            self.__err_logger.error(err_msg)
            result = None

        return result

    def __get_algo_order_in_db(self, order_algo_id):
        result = None
        __query = None

        try:
            with self.__db_conn_lock:
                __query = f'SELECT * FROM {self.__table_name_algo} '
                __query += 'WHERE order_algo_id LIKE ? AND exchange = ? ;'

                self.__db_cursor.execute(__query,(f"{order_algo_id}%", self.__exchange))

                __orders = [dict(fila) for fila in self.__db_cursor.fetchall()]

                self.__db_conn.commit()

                if __orders is not None and isinstance(__orders, list) and len(__orders) > 0:
                    result = []

                    for __algo_order in __orders:

                        if __algo_order is not None and isinstance(__algo_order, dict):
                            __order_algo_id = __algo_order['order_algo_id']
                            __order_algo_data = (
                                base64.b64decode(__algo_order['order_algo_data']).decode('utf-8')
                            )
                            __order_algo_data = json.loads(__order_algo_data)

                            result_row = {}
                            result_row['order_algo_id'] = __order_algo_id
                            result_row['exchange'] = __algo_order['exchange']
                            result_row['symbol'] = __algo_order['symbol']
                            result_row['order_algo_time_ini'] = (
                                __algo_order['order_algo_time_ini']
                            )
                            result_row['order_algo_time_date_ini'] = (
                                __algo_order['order_algo_time_date_ini']
                            )
                            result_row['order_algo_time_end'] = (
                                __algo_order['order_algo_time_end']
                            )
                            result_row['order_algo_time_date_end'] = (
                                __algo_order['order_algo_time_date_end']
                            )
                            result_row['order_algo_status'] = (
                                __algo_order['order_algo_status']
                            )
                            result_row['order_algo_data'] = __order_algo_data

                            result.append(result_row)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_algo_id: {order_algo_id}, error: {e}'
            self.__err_logger.error(err_msg)

            result = None

        return result

    def __delete_algo_order_in_db(self, order_algo_id):
        """
        __delete_algo_order_in_db
        =========================

        Deletes an algorithmic order from the database.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        order_algo_id : str
            The ID of the algorithmic order to delete.

        Returns:
        --------
        bool
            Returns True if the order was successfully deleted, False otherwise.
        """
        result = False

        try:
            with self.__db_conn_lock:
                __query = f"DELETE FROM {self.__table_name_algo}"
                __query += " WHERE order_algo_status == 'order_algo_finished'"
                __query += " AND exchange = ? AND order_algo_id = ? ;"
                self.__db_cursor.execute(__query,(self.__exchange, order_algo_id))

                __rows_eliminated = self.__db_cursor.rowcount

                self.__db_conn.commit()
                if __rows_eliminated > 0:
                    result = True
                else:
                    result = False

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', order_algo_id: {order_algo_id}, error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result

    def __purge_finished_algo_orders(self):
        """
        __purge_finished_algo_orders
        ============================
        
        This function removes finished algorithmic orders from the database that
        were created more than self.__time_to_purge_algo_orders ago. These orders
        are deleted from the database but saved to a .json file.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        bool
            Returns True if the purge was successful, False otherwise.
        """

        result = False

        try:
            __not_orphan_orders = []
            if self.__time_to_purge_algo_orders is not None\
                and isinstance(self.__time_to_purge_algo_orders, int):
                __algo_orders = self.get_algo_orders(False)
                for __algo_order_id in __algo_orders:

                    __algo_order = self.get_algo_order(__algo_order_id)

                    if __algo_order is not None\
                        and isinstance(__algo_order, dict):

                        order_algo_time_ini = int(__algo_order['order_algo_time_ini'])

                        order_algo_time_diff = abs(int(round(time.time())) - order_algo_time_ini)

                        __orders_0 = __algo_order['order_algo_data']['order_algo_orders_list_0']
                        __orders_1 = __algo_order['order_algo_data']['order_algo_orders_list_1']
                        __orders = []
                        if isinstance(__orders_0, list):
                            __orders += __orders_0
                        if isinstance(__orders_1, list):
                            __orders += __orders_1

                        if __orders is not None and isinstance(__orders, list):
                            for __order in __orders:
                                __not_orphan_orders.append(__order['id'])

                        if order_algo_time_diff > self.__time_to_purge_algo_orders\
                            and __algo_order['order_algo_status'] == 'order_algo_finished':
                            __o_t_ini = time.gmtime(order_algo_time_ini)

                            __algo_orders_hist_dir = (
                                os.path.join(self.__var_dir,\
                                             'historic',\
                                             time.strftime("%Y", __o_t_ini),\
                                             time.strftime("%m", __o_t_ini))
                            )
                            if not os.path.exists(__algo_orders_hist_dir):
                                os.makedirs(__algo_orders_hist_dir)

                            __algo_orders_hist_file = f'{__algo_orders_hist_dir}'
                            __algo_orders_hist_file += f'/{__algo_order_id}.json'
                            __algo_orders_data = json.dumps(__algo_order, sort_keys=False, indent=4)

                            if __orders is not None and isinstance(__orders, list):
                                for __order in __orders:
                                    result = self.delete_order(__order['id'], __order['symbol'])

                            result = self.__delete_algo_order_in_db(__algo_order_id)
                            ccf.file_put_contents(__algo_orders_hist_file, __algo_orders_data)

            self.__purge_finished_orders(__not_orphan_orders)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange},'
            err_msg += f' error: {e}'
            self.__err_logger.error(err_msg)
            result = False

        return result


    def get_markets(self):
        """
        get_markets
        ===========

        This function returns a dictionary similar to the one returned by 
        ccxt.load_markets(), but it removes the 'info' key from each symbol.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        dict
            A dictionary containing market information without the 'info' key.
        """
        result = None
        __data = self.__exchange_aux_class.get_markets()
        __data = copy.deepcopy(__data)

        if __data is not None and isinstance(__data, dict):
            result = {}
            for symbol, symbol_data in __data.items():
                if symbol_data is not None and isinstance(symbol_data, dict):
                    result[symbol] = symbol_data

                    if 'info' in symbol_data:
                        del result[symbol]['info']

        return result

    def get_ratelimit(self):
        """
        get_ratelimit
        =============

        This function returns a dictionary containing the data returned by 
        the auxiliary function get_ratelimit().

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        dict
            A dictionary with the following structure:
            {
                'RAW_REQUEST': rateLimit,
                'ORDER_REQUEST': orderRequestLimit     
            }
        """
        result = None
        result = self.__exchange_aux_class.get_ratelimit()
        return result

    def get_ccxt_inst(self):
        """
        get_ccxt_inst
        =============

        This function returns the CCXT exchange instance used by the auxiliary class
        for direct API communication.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.

        Returns:
        --------
        ccxt.Exchange or None
            Returns the CCXT exchange instance, or None if the instance has not been
            initialized or if the exchange auxiliary class does not support this operation.

        Notes:
        ------
        This method provides access to the underlying CCXT library instance, allowing
        direct interaction with exchange-specific methods and properties not exposed
        through the wrapper interface.
        """
        result = None
        if self.__exchange_aux_class is not None:
            result = self.__exchange_aux_class.get_ccxt_inst()
        return result

    def __init_loggin_out(self, log_dir: str=None):
        result = False
        max_backup_log_files = 9
        __max_log_file_size = 8 * 1024 * 1024  # 8 MB

        if self.__set_default_log_file(log_dir=log_dir):
            try:
                if not self.__debug:
                    for handler in logging.root.handlers[:]:
                        logging.root.removeHandler(handler)

                __log_formatter = (
                    logging.Formatter('%(asctime)s %(message)s', datefmt='%Y-%m-%d %H:%M:%S -')
                )

                __err_formatter = (
                    logging.Formatter('%(asctime)s %(message)s', datefmt='%Y-%m-%d %H:%M:%S -')
                )

                log_handler = logging.handlers.RotatingFileHandler(filename=self.__log_logger_file,
                                                                   maxBytes=__max_log_file_size,
                                                                   backupCount=max_backup_log_files,
                                                                   encoding='utf-8',
                                                                   delay=True)

                log_handler.setFormatter(__log_formatter)
                __log_desc = f'{self.__exchange}_{self.__market_type}_CCXAO_LOG'
                self.__log_logger = logging.getLogger(__log_desc)
                self.__log_logger.setLevel(logging.INFO)

                for handler in self.__log_logger.handlers[:]:
                    self.__log_logger.removeHandler(handler)

                self.__log_logger.addHandler(log_handler)

                err_handler = logging.handlers.RotatingFileHandler(filename=self.__err_logger_file,
                                                                   maxBytes=__max_log_file_size,
                                                                   backupCount=max_backup_log_files,
                                                                   encoding='utf-8',
                                                                   delay=True)

                err_handler.setFormatter(__err_formatter)
                __err_desc = f'{self.__exchange}_{self.__market_type}_CCXAO_ERR'
                self.__err_logger = logging.getLogger(__err_desc)
                self.__err_logger.setLevel(logging.ERROR)

                for handler in self.__err_logger.handlers[:]:
                    self.__err_logger.removeHandler(handler)

                self.__err_logger.addHandler(err_handler)
                result = True

            except Exception: # pylint: disable=broad-except
                result = False

        return result

    def __set_default_log_file(self, log_dir: str=None):
        """
        Ccxao __set_default_log_file function.
        ======================================
            This method .
                :param self: Ccxao instance.
                :param log_dir: str.

                :return: str log_file
        """
        __result = False
        __log_file_path = None
        __log_file_base = f'ccxao_{self.__exchange}_{self.__market_type}'
        __log_file_log = None
        __log_file_err = None

        if log_dir is not None and self.is_valid_dir(log_dir):
            __log_file_log = os.path.join(log_dir, f'{__log_file_base}.log')
            __log_file_err = os.path.join(log_dir, f'{__log_file_base}.err')
            if self.is_valid_file(__log_file_log) and self.is_valid_file(__log_file_err):
                __result = True

        if not __result:
            current_directory = os.getcwd()
            is_poetry_active = os.path.exists(os.path.join(current_directory, 'poetry.lock'))

            if is_poetry_active:
                __log_file_path = os.path.join(current_directory, '.log/ccxao', self.__exchange)
            else:
                __home_directory = os.path.expanduser("~")
                __log_file_path = os.path.join(__home_directory, '.var/log/ccxao', self.__exchange)

            if __log_file_path is not None and self.is_valid_dir(__log_file_path):
                __log_file_log = os.path.join(__log_file_path, __log_file_base + '.log')
                __log_file_err = os.path.join(__log_file_path, __log_file_base + '.err')
                if self.is_valid_file(__log_file_log) and self.is_valid_file(__log_file_err):
                    __result = True

        if __result:
            self.__log_logger_file = __log_file_log
            self.__err_logger_file = __log_file_err

        return __result

    def pass_all_assets_to_asset(self, dest_asset, exclude_assets=None):
        """
        pass_all_assets_to_asset
        ========================
        This function sells all assets to convert them into the specified destination asset,
        excluding any assets specified in the exclude_assets list.
        Parameters:
        -----------
        dest_asset : str
            The asset to convert all other assets into.
        exclude_assets : list, optional
            A list of assets to exclude from the conversion process.
        Returns:
        --------
        bool
            Returns True if the operation was successful, False otherwise.
        """
        result = False
        excludes = None

        if exclude_assets is not None and isinstance(exclude_assets, list):
            excludes = exclude_assets
        else:
            excludes = []

        excludes.append(dest_asset)

        balances = self.get_balances()

        if balances is not None and isinstance(balances, dict):
            result = True
            for asset in balances:
                if asset not in excludes:
                    symbol = f'{asset}/{dest_asset}'
                    if symbol in self.get_allowed_symbols_to_trade():
                        result = self.sell_total_asset(symbol) and result

        return result

    def sell_total_asset(self, symbol):
        """
        sell_total_asset
        ================

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The symbol to balance.

        Returns:
        --------
        bool
            Returns True if the selling total asset was successful, False otherwise.
        """
        result = False

        if symbol not in self.get_allowed_symbols_to_trade():
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', symbol: {symbol}, error: Symbol not allowed to trade'
            self.__err_logger.error(err_msg)
            return False

        symbol_data = self.get_exchange_symbols_info(symbol=symbol)

        res_type = 'both'

        if symbol_data is not None\
            and isinstance(symbol_data, dict)\
            and symbol in symbol_data:

            try:
                __base = symbol_data[symbol]['base']
                __quote = symbol_data[symbol]['quote']

                min_amount = self.symbol_min_amount(symbol)
                min_cost = self.symbol_min_cost(symbol)
                tick_size = self.symbol_tick_size(symbol)
                balances = self.get_balances()

                if balances is not None and isinstance(balances, dict):
                    balance_base = 0

                    if __base in balances:
                        balance_base = balances[__base]

                    if balance_base >= min_amount:
                        order_amount = balance_base
                        order_side = 'sell'
                        order_type = 'limit_maker'

                        limit_attemps = 23
                        num_attemps = 0

                        while num_attemps < limit_attemps:

                            price_data = (
                                self.get_symbol_price_from_order_book(symbol, res_type)
                            )

                            if price_data is not None and isinstance(price_data, dict):
                                order_price = 0
                                order_vol = 0

                                order_price = (float(price_data['asks'])\
                                                + float(price_data['bids'])) / 2

                                order_price += tick_size
                                order_vol = float(price_data['asks_vol'])
                                order_cost = order_price * order_amount

                                if (order_amount * 1.4) <= order_vol and order_cost >= min_cost:

                                    order_data = (
                                        self.create_order(order_symbol=symbol,\
                                                        order_side=order_side,\
                                                        order_amount=order_amount,\
                                                        order_price=order_price,\
                                                        order_type=order_type)
                                    )

                                    if order_data is not None\
                                        and isinstance(order_data, dict):
                                        order_id = order_data['id']

                                        order_finish = False
                                        order_time = (
                                            int(round(float(order_data['timestamp'])/1000))
                                        )
                                        order_time_limit = 270

                                        while not order_finish:

                                            __order_status = (
                                                self.get_order_status(order_id, symbol)
                                            )

                                            if __order_status == 'open':
                                                order_finish = False
                                                __time_diff = (
                                                    abs(int(round(time.time()))\
                                                        - order_time)
                                                )
                                                if __time_diff > order_time_limit:
                                                    order_finish = True
                                                    _ = self.cancel_order(order_id,\
                                                                            symbol)

                                                    time.sleep(5)

                                            elif __order_status == 'closed':
                                                order_finish = True
                                                num_attemps = limit_attemps
                                                result = True
                                            elif __order_status == 'none':
                                                order_finish = False
                                                result = False
                                            else:
                                                order_finish = True
                                                result = False

                                            time.sleep(5)
                                else:
                                    result = False

                            time.sleep(10)
                            num_attemps += 1

                    else:
                        result = False

            except Exception as e: # pylint: disable=broad-except
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
                err_msg += f', symbol: {symbol}, error: {e}'
                self.__err_logger.error(err_msg)
                result = False

        return result

    def balance_symbol(self, symbol, proportion: float=0.5):
        """
        balance_symbol
        ==============

        This function balances the amounts of the asset and quote of the symbol
        to ensure they have an equivalent value in both.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        symbol : str
            The symbol to balance.
        proportion : float, default=0.5
            The target proportion for balancing (default is 0.5 for equal balance).

        Returns:
        --------
        bool
            Returns True if the balancing was successful, False otherwise.
        """
        result = False

        if symbol not in self.get_allowed_symbols_to_trade():
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', symbol: {symbol}, error: Symbol not allowed to trade'
            self.__err_logger.error(err_msg)
            return False

        prop_cost = 1.4

        symbol_data = self.get_exchange_symbols_info(symbol=symbol)

        res_type = 'both'
        price_data = self.get_symbol_price_from_order_book(symbol, res_type)

        price = price_data['asks']

        order_id = None

        if symbol_data is not None\
            and isinstance(symbol_data, dict)\
            and symbol in symbol_data\
            and price is not None\
            and isinstance(price, float):

            try:
                __base = symbol_data[symbol]['base']
                __quote = symbol_data[symbol]['quote']

                min_amount = self.symbol_min_amount(symbol)
                min_cost = self.symbol_min_cost(symbol)
                balances = self.get_balances()

                if balances is not None and isinstance(balances, dict):
                    balance_base = 0
                    balance_quote = 0

                    if __base in balances:
                        balance_base = balances[__base]

                    if __quote in balances:
                        balance_quote = balances[__quote]

                    if balance_base > 0 or balance_quote > 0:
                        balance_base_in_quote = balance_base * price
                        total_balance_in_quote = balance_base_in_quote + balance_quote
                        balance_target_in_quote = total_balance_in_quote * proportion
                        diff = abs(balance_base_in_quote - balance_target_in_quote)

                        order_amount = diff / price

                        if diff > (min_cost * prop_cost) and order_amount > min_amount:
                            order_side = None

                            if balance_base_in_quote > balance_target_in_quote:
                                order_side = 'sell'
                            elif balance_base_in_quote < balance_target_in_quote:
                                order_side = 'buy'

                            if order_side is not None:
                                limit_attemps = 23
                                num_attemps = 0
                                order_type = 'limit_maker'

                                while num_attemps < limit_attemps:
                                    tick_size = self.symbol_tick_size(symbol)
                                    price_data = (
                                        self.get_symbol_price_from_order_book(symbol, res_type)
                                    )

                                    if price_data is not None and isinstance(price_data, dict):
                                        order_price = 0
                                        order_vol = 0

                                        order_price = (float(price_data['asks'])\
                                                       + float(price_data['bids'])) / 2

                                        if order_side == 'buy':
                                            if order_price == float(price_data['asks']):
                                                order_price -= tick_size
                                            order_vol = float(price_data['asks_vol'])
                                        else:
                                            if order_price == float(price_data['bids']):
                                                order_price += tick_size
                                            order_vol = float(price_data['bids_vol'])

                                        if (order_amount * prop_cost) <= order_vol:

                                            order_data = (
                                                self.create_order(order_symbol=symbol,\
                                                                  order_side=order_side,\
                                                                  order_amount=order_amount,\
                                                                  order_price=order_price,\
                                                                  order_type=order_type)
                                            )

                                            order_data = copy.deepcopy(order_data)
                                            num_attemps += 1

                                            if order_data is not None\
                                                and isinstance(order_data, dict):
                                                order_id = order_data['id']

                                                order_finish = False
                                                order_time = (
                                                    int(round(float(order_data['timestamp'])/1000))
                                                )
                                                order_time_limit = 320

                                                while not order_finish:

                                                    __order_status = (
                                                        self.get_order_status(order_id, symbol)
                                                    )

                                                    if __order_status == 'open':
                                                        order_finish = False
                                                        __time_diff = (
                                                            abs(int(round(time.time()))\
                                                                - order_time)
                                                        )
                                                        if __time_diff > order_time_limit:
                                                            order_finish = True
                                                            _ = self.cancel_order(order_id,\
                                                                                  symbol)

                                                            time.sleep(5)

                                                    elif __order_status == 'closed':
                                                        order_finish = True
                                                        num_attemps = limit_attemps
                                                        result = True
                                                    elif __order_status == 'none':
                                                        order_finish = False
                                                        result = False
                                                    else:
                                                        order_finish = True
                                                        result = False

                                                    time.sleep(5)

                                    time.sleep(10)
                        else:
                            result = True

            except Exception as e: # pylint: disable=broad-except
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
                err_msg += f', symbol: {symbol}, error: {e}'
                self.__err_logger.error(err_msg)
                result = False

        return result

    def dual_investment_get_products(self,
                                     params: str=None) -> List[dict]:
        """
        dual_investment_get_products
        ============================

        Retrieve available Dual Investment products from the exchange.

        This method fetches Dual Investment products from the exchange's API with optional filtering
        by option type, asset pair, duration, and APR. It handles pagination automatically and
        returns a sorted list of products by APR in descending order.

        Parameters:
        -----------
        params : str
            A base64-encoded JSON string containing the parameters dictionary.
            After decoding, the dictionary can contain the following keys:
            - option (str, optional): 'buy' for PUT options (low buy),
                                      'sell' for CALL options (high sell)
            - asset (str, optional): The asset coin symbol (e.g., 'BNB', 'ETH')
            - quote (str, optional): The quote coin symbol (e.g., 'USDT', 'BUSD')
            - max_duration_days (int, optional): Maximum duration in days for
                                                 the investment products
            - min_apr (float, optional): Minimum Annual Percentage Rate (APR) filter
            - max_page_index (int, optional): Maximum number of pages to fetch from the API
            
            If no parameters are provided, all available products are returned.

        Returns:
        --------
        List[dict]
            A list of dictionaries containing Dual Investment product details.
            Each dictionary includes:
            - id: Product ID
            - investCoin: Coin to invest
            - exercisedCoin: Coin to be exercised
            - strikePrice: Strike price of the option
            - duration: Duration in days
            - settleDate: Settlement date timestamp
            - settleDateTime: Settlement date in human-readable format
            - purchaseDecimal: Decimal precision for purchase amounts
            - purchaseEndTime: Purchase end time timestamp
            - purchaseEndDateTime: Purchase end time in human-readable format
            - canPurchase: Boolean indicating if the product can be purchased
            - apr: Annual Percentage Rate
            - orderId: Order ID
            - minAmount: Minimum investment amount
            - maxAmount: Maximum investment amount
            - createTimestamp: Creation timestamp
            - createDateTime: Creation date in human-readable format
            - optionType: Type of option (CALL or PUT)
            
            Returns None if an error occurs or no products are found.

        Raises:
        -------
        ValueError
            If the option parameter is not 'buy' or 'sell'.
        """
        __params = None
        try:
            __params = bytes.fromhex(params)
            __params = json.loads(__params)

        except Exception: # pylint: disable=broad-except
            __params = None

        result = (
            self.__exchange_aux_class.dual_investment_get_products(params=__params)
        )

        return result

    def dual_investment_get_positions(self,
                                      params: str=None) -> List[dict]:
        """
        dual_investment_get_positions
        =============================

        Retrieve Dual Investment positions from the exchange.

        This method fetches Dual Investment positions from the exchange's API with optional
        filtering by status. It returns a list of positions sorted by creation timestamp in
        descending order.

        Parameters:
        -----------
        params : str
            A base64-encoded JSON string containing the parameters dictionary.
            After decoding, the dictionary can contain the following keys:
            - status (str, optional): Filter positions by status. Common values include:
                                     'PENDING', 'EXERCISED', 'SETTLED', 'SUBSCRIBED', 'REDEEMED',
                                     'EXPIRED', 'CANCELLED'. Defaults to None (no status filter).
            - order_id (str | int, optional): The order ID to filter positions.
                                              Defaults to None (no order ID filter).
        Returns:
        --------
        List[dict]
            A list of dictionaries containing Dual Investment position details.
            Each dictionary includes:
            - id: Position ID
            - investCoin: Coin invested
            - exercisedCoin: Coin to be exercised
            - strikePrice: Strike price of the option
            - subscriptionAmount: Amount invested
            - duration: Duration in days
            - createTimestamp: Creation timestamp
            - createDateTime: Creation date in human-readable format
            - settleDate: Settlement date timestamp
            - settleDateTime: Settlement date in human-readable format
            - status: Current status of the position
            - exercisePrice: Price at which the option was exercised
            - exerciseDateTime: Exercise date in human-readable format
            - optionType: Type of option (CALL or PUT)
            - autoCompoundPlan: Auto-compound plan details
            Returns None if an error occurs or no positions are found.
        Raises:
        -------
        ValueError
            If the status parameter is not one of the allowed values.
        """

        __params = None
        try:
            __params = bytes.fromhex(params)
            __params = json.loads(__params)
        except Exception: # pylint: disable=broad-except
            __params = None

        result = (
            self.__exchange_aux_class.dual_investment_get_positions(params=__params)
        )

        return result

    def dual_investment_subscribe_product(self,
                                          params: str=None) -> Optional[dict]:
        """
        dual_investment_subscribe_product
        =================================
        Subscribe to a Dual Investment product on the exchange.
        This method allows you to subscribe to a specific Dual Investment product by providing
        the product ID, order ID, deposit amount, and auto-compound plan. It returns the details
        of the subscription if successful.
        Parameters:
        -----------
        params : str
            A base64-encoded JSON string containing the parameters dictionary.
            After decoding, the dictionary can contain the following keys:
            - product_id (str): The unique identifier of the Dual Investment
                                product to subscribe to.
            - order_id (str): The order ID associated with the subscription.
            - deposit_amount (float): The amount to invest in the product.
            - invest_coin (str): The coin to invest in the product.
            - auto_compound_plan (str, optional): The auto-compound plan type for reinvesting
                                                  returns.
                                                  Possible values are
                                                    'NONE', 'STANDARD', 'ADVANCED'.
                                                  Defaults to 'NONE'.
        Returns:
        --------
        Optional[dict]
            A dictionary containing the subscription details if successful,
            or None if an error occurs.

            The dictionary includes:

            - positionId: Position ID
            - investCoin: Coin invested
            - exercisedCoin: Coin to be exercised
            - subscriptionAmount: Amount invested
            - duration: Duration in days
            - autoCompoundPlan: Auto-compound plan details
            - strikePrice: Strike price of the option
            - settleDate: Settlement date timestamp
            - settleDateTime: Settlement date in human-readable format
            - purchaseStatus: Current status of the subscription
            - apr: Annual Percentage Rate
            - orderId: Order ID
            - purchaseTime: Purchase timestamp
            - purchaseDateTime: Purchase date in human-readable format
            - optionType: Type of option (CALL or PUT)

        Raises:
        -------
        ValueError
            If any of the required parameters are missing or invalid.
        """
        __params = None

        try:
            __params = bytes.fromhex(params)
            __params = json.loads(__params)

        except Exception: # pylint: disable=broad-except
            __params = None

        result = (
            self.__exchange_aux_class.dual_investment_subscribe_product(params=__params)
        )

        return result

    def is_valid_dir(self, dir_in): # pylint: disable=unused-argument
        """
        is_valid_dir
        ============

        This function takes a string and checks if it is a valid directory with write access.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        dir_in : str
            The directory path to check.

        Returns:
        --------
        bool
            Returns True if the directory is valid and writable, False otherwise.
        """

        result = False

        try:
            if not os.path.exists(dir_in):
                os.makedirs(dir_in)
                result = True
            elif not os.path.isdir(dir_in):
                result = False
            else:
                result = True

            result = result and os.access(dir_in, os.W_OK)

        except Exception: # pylint: disable=broad-except
            result = False

        return result

    def is_valid_file(self, file_in): # pylint: disable=unused-argument
        """
        is_valid_file
        =============

        This function takes a string and checks if it is a valid file with write access.

        Parameters:
        -----------
        self : Ccxao
            The instance of the Ccxao class.
        file_in : str
            The file path to check.

        Returns:
        --------
        bool
            Returns True if the file is valid and writable, False otherwise.
        """

        result = False

        try:
            if not os.path.exists(file_in):
                with open(file_in, 'a', encoding="utf-8") as f:
                    f.write("")
                result = True
            elif not os.path.isfile(file_in):
                result = False
            else:
                result = True

            result = result and os.access(file_in, os.W_OK)

        except Exception: # pylint: disable=broad-except
            result = False

        return result



    @classmethod
    def get_supported_exchanges(cls):
        """
        get_supported_exchanges
        =======================

        This method returns a list of supported exchanges.

        Parameters:
        -----------
        cls : Ccxao
            The Ccxao class.

        Returns:
        --------
        list[str]
            A list of strings representing the supported exchanges.
        """
        __suported_exchanges = ['binance', 'bybit', 'okx', 'kucoin', 'bingx']

        return __suported_exchanges
