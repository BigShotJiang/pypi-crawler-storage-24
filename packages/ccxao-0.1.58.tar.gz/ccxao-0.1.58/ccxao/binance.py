# pylint: disable=too-many-lines
"""
Ccxao - cryptoCurrency Exchange algoritmic order
Binance auxiliary functions

Author: Ricardo Marcelo Alvarez
Date: 2024-06-20
"""

import os
import sys
import json
import time
import datetime
import copy
import threading
import builtins
import pickle
import logging
import logging.handlers
import queue
from typing import List, Optional
import pprint # pylint: disable=unused-import
import ccxt
import ccxao.ccxao_common_functions as ccf
from ccxao.binance_manage_orders import CcxaoBinanceManageOrders

class BinanceCcxaoAuxClass():
    """
    BinanceCcxaoAuxClass
    ====================
    This class provides helper functions specifically designed for the Ccxao class
    related to Binance exchange operations. 

    It includes methods for retrieving market data, managing orders, and other 
    utility functions that facilitate trading operations on Binance.
    """

    # pylint: disable=unused-argument
    def __init__(self,\
                 api_key: str=None,\
                 api_secret: str=None,\
                 api_uid: str=None,\
                 api_password: str=None,\
                 sandbox: bool=False,\
                 trading_type: str='SPOT',\
                 debug: bool=False,\
                 var_dir: str=None,\
                 log_handler: logging.Logger = None,\
                 err_handler: logging.Logger = None):
        """
        BinanceCcxaoAuxClass constructor
        ================================
        Initializes a new instance of the BinanceCcxaoAuxClass.

        :param api_key: str
            API key for authenticating with the exchange.
        :param api_secret: str
            API secret for authenticating with the exchange.
        :param api_uid: str
            API uid, only required for some exchanges.
        :param api_password: str
            API password, only required for some exchanges.
        :param sandbox: bool
            Indicates whether to use the sandbox environment (default is False).
        :param trading_type: str
            Type of trading, valid only as 'SPOT' (default is 'SPOT').
        :param debug: bool
            If True, enables verbose output for debugging (default is False).
        :param var_dir: str
            Directory for variable storage, default is '/var/lib/ccxao'.
        :param log_handler: logging.Logger
            Logger for handling logs.
        :param err_handler: logging.Logger
            Logger for handling errors.

        Returns:
        --------
        Ccxao
            A new instance of the BinanceCcxaoAuxClass class.
        """

        self.__exchange = 'binance'
        self.__trading_type = trading_type

        self.__log_logger = log_handler
        self.__err_logger = err_handler

        self.__var_dir = var_dir

        if self.__var_dir is None:
            self.__var_dir = '/var/lib/ccxao/binance'

        self.__var_dir = os.path.join(self.__var_dir, 'aux_vars')

        if not os.path.exists(self.__var_dir):
            os.makedirs(self.__var_dir)

        self.__main_thread = None
        self.__main_thread_running = False
        self.__main_thread_sleep = 1

        self.__ping_thread = None

        self.__exchange_info = None
        self.__exchange_info_time = 0
        self.__exchange_info_time_limit = 540
        self.__exchange_trading_fees = None
        self.__exchange_symbols_prices = None
        self.__exchange_balances = None
        self.__exchange_usdt_balances = None

        self.__exchange_symbols_info = None

        self.__exchange_check_orders_time = 0
        self.__exchange_check_orders_time_limit = 7200

        self.__events_queue = None
        self.__events_queue_file = f'{self.__var_dir}/events_queue.pkl'

        self.__lock = threading.Lock()
        self.__lock_orders = threading.Lock()
        self.__lock_events_queue = threading.Lock()

        self.__load_queue()

        self.__orders = {}
        self.__orders_file = f'{self.__var_dir}/orders.pkl'

        if not self.__load_orders():
            self.__orders = {}

        self.__debug = debug

        self.__api_client = None
        self.__bmo = None

        try:
            # self.__api_client = Spot(api_key=api_key,\
            #                          api_secret=api_secret,\
            #                          base_url=self.__api_url)
            __api_conn_data = {
                'apiKey': api_key,
                'secret': api_secret,
                'enableRateLimit': True,
                'verbose': self.__debug,
                'options': {
                    'defaultType': self.__trading_type.lower()
                }
            }

            self.__bmo = CcxaoBinanceManageOrders(api_key=api_key,
                                                  api_secret=api_secret,
                                                  sandbox=sandbox,
                                                  debug=self.__debug,
                                                  log_handler=self.__log_logger,
                                                  err_handler=self.__err_logger,
                                                  on_message=self.__ws_message_handler)

            self.__api_client = ccxt.binance(__api_conn_data)
            if sandbox:
                self.__api_client.set_sandbox_mode(True)

        except Exception as e: # pylint: disable=broad-except
            print(f'Error: exception {e}')

        if not self.__check_exchange_connection():
            raise ValueError(f'The exchange connection {str(self.__exchange)} failed.')

        self.__api_client.load_markets()

    def __check_exchange_connection(self):
        """
        __check_exchange_connection
        ===========================

        This is an internal function that checks if the connection to the exchange
        can be established successfully.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            True if the connection is possible, or False otherwise.
        """
        result = False
        __data = None

        if self.__api_client is not None:
            try:
                __data = self.__api_client.account()
                result = True
            except Exception as e: # pylint: disable=broad-except
                result = False
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, error: {e}'
                if self.__err_logger is not None:
                    self.__err_logger.error(err_msg)
                else:
                    print(err_msg)

        return result

    def __del__(self):
        """
        __del__
        =======

        Destructor for the BinanceCcxaoAuxClass instance. This method is called when 
        the instance is about to be destroyed. It is responsible for saving any 
        pending orders and the current state of the queue to ensure no data is lost.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.
        """

        self.__save_orders()
        self.__save_queue()

    def __save_orders(self):
        """
        __save_orders
        =============
        This internal function saves the current state of orders to a file using 
        pickle serialization. If the operation is successful, it returns True; 
        otherwise, it returns False.

        This method handles any exceptions that occur during the file operation 
        and logs the error if an error logger is provided.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            True if orders were successfully saved, False otherwise.
        """

        result = False

        try:
            with builtins.open(self.__orders_file, 'wb') as orders_file:
                pickle.dump(self.__orders, orders_file)
            result = True
        except Exception as e: # pylint: disable=broad-except
            result = False
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, error: {e}'
            if self.__err_logger is not None:
                self.__err_logger.error(err_msg)

        return result

    def __load_orders(self):
        """
        __load_orders
        =============
        This internal function loads orders from a file using pickle deserialization.
        It checks if the file exists and whether it contains data. If successful,
        the orders are loaded into the instance; otherwise, an empty dictionary
        is assigned to the orders.

        If any exceptions occur during the file operation, they are logged
        if an error logger is provided.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            True if orders were successfully loaded or if the orders file did not exist, 
            False if there was an error during loading or if the file was empty.
        """
        result = False

        if os.path.exists(self.__orders_file):
            try:
                if os.path.getsize(self.__orders_file) > 0:
                    with builtins.open(self.__orders_file, 'rb') as orders_file:
                        self.__orders = pickle.load(orders_file)
                    result = True
                else:
                    self.__orders = {}
                    result = False
            except Exception as e: # pylint: disable=broad-except
                if self.__err_logger is not None:
                    __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                    err_msg = f'Found error in {__l_function}, error: {e}'
                    self.__err_logger.error(err_msg)

                self.__orders = {}
                result = False
        else:
            self.__orders = {}
            result = True

        if self.__orders is None or not isinstance(self.__orders, dict):
            self.__orders = {}
            result = True

        return result

    def __save_queue(self):
        """
        __save_queue
        ============

        This internal function saves the current state of the events queue 
        to a file using pickle serialization. It converts the queue into a 
        list and writes it to the specified file. 

        If an error occurs during the file operation, it is logged 
        if an error logger is provided.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            True if the queue was successfully saved, 
            False if there was an error during the saving process.
        """
        result = False
        try:
            __data = list(self.__events_queue.queue)
            with builtins.open(self.__events_queue_file, 'wb') as queue_file:
                pickle.dump(__data, queue_file)
            result = True

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, error: {e}'
                self.__err_logger.error(err_msg)
            result = False

        return result

    def __load_queue(self):
        """
        __load_queue
        ============

        This internal function loads the state of the events queue 
        from a file using pickle deserialization. It initializes 
        the events queue from the contents of the file if it exists 
        and is not empty. If an error occurs during the file operation, 
        the queue is reset to a new instance, and the error is logged 
        if an error logger is provided.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            True if the queue was successfully loaded, 
            False if there was an error during the loading process 
            or if the file was empty.
        """

        result = False

        with self.__lock_events_queue:
            if os.path.exists(self.__events_queue_file):
                try:
                    if os.path.getsize(self.__events_queue_file) > 0:
                        with builtins.open(self.__events_queue_file, 'rb') as queue_file:
                            data = pickle.load(queue_file)
                        self.__events_queue = queue.Queue()
                        for item in data:
                            self.__events_queue.put(item)
                        result = True
                    else:
                        self.__events_queue = queue.Queue()
                        result = False

                except Exception as e: # pylint: disable=broad-except
                    self.__events_queue = queue.Queue()
                    if self.__err_logger is not None:
                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        err_msg = f'Found error in {__l_function}, error: {e}'
                        self.__err_logger.error(err_msg)

                    result = False
            else:
                self.__events_queue = queue.Queue()

            if self.__events_queue is None or not isinstance(self.__events_queue, queue.Queue):
                self.__events_queue = queue.Queue()

        return result

    def start_listen_socket(self):
        """
        start_listen_socket
        ===================

        This method initializes and starts the WebSocket connection 
        to the exchange for real-time data streaming. It sets the 
        listen key required for the WebSocket connection and starts 
        two threads: one for handling the WebSocket communication and 
        another for the main processing thread.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True indicating that the process of starting the 
            socket listener has commenced successfully.
        """
        result = True

        self.__bmo.start()

        self.__main_thread = threading.Thread(target=self.__launch_ccxao_main_thread,\
                                              name=f'ccxao_{self.__exchange}__launch_main_thread')

        self.__main_thread.start()

        self.__ping_thread = threading.Thread(target=self.__launch_ping_thread,
                                              name=f'ccxao_{self.__exchange}__launch_ping_thread')

        self.__ping_thread.start()

        return result

    def __check_orders(self):
        """
        __check_orders
        ==============

        This internal function checks the status of existing orders 
        in the exchange. It determines if any orders have been open 
        for longer than the specified time limit. If so, it requests 
        the latest status for those orders.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True if the order check was executed successfully, 
            regardless of whether any orders were updated or not.
        """

        result = True

        __exchange_check_orders_time_diff = (
            abs(int(round(time.time())) - self.__exchange_check_orders_time)
        )

        if __exchange_check_orders_time_diff > self.__exchange_check_orders_time_limit:
            __check_orders = {}
            __req_keys = {
                'status': (str),
                'symbol': (str),
                'timestamp': (int, str)
            }
            with self.__lock_orders:
                for __order_id, __order_data in self.__orders.items():
                    if __order_data is not None\
                        and isinstance(__order_data, dict):

                        if all((key in __order_data\
                                and __order_data[key] is not None\
                                and isinstance(__order_data[key], types))\
                                    for key, types in __req_keys.items()):
                            __status = __order_data['status']
                            __symbol = __order_data['symbol']
                            __timestamp = __order_data['timestamp']

                            __order_tstamp_diff = (
                                abs(round((int(__timestamp)/1000)\
                                          - self.__exchange_check_orders_time))
                            )

                            if __status == 'open'\
                                and __order_tstamp_diff > self.__exchange_check_orders_time_limit:
                                __check_orders[__order_id] = __symbol

            self.__exchange_check_orders_time = int(round(time.time()))

            for __order_id, __symbol in __check_orders.items():
                __order = self.__get_order(__order_id, __symbol)

        return result

    def __launch_ccxao_main_thread(self):
        """
        __launch_ccxao_main_thread
        ==========================

        This internal function runs the main loop for managing the 
        connection to the exchange. It handles the renewal of the 
        listen key, checks the status of existing orders, updates 
        exchange information, and processes events from the event queue.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True if the main thread is executed successfully.
        """
        result = True

        __to_run = True

        with self.__lock:
            self.__main_thread_running = True

        self.__check_orders()

        while __to_run:
            self.__check_orders()

            __exchange_info_time_diff = abs(int(round(time.time())) - self.__exchange_info_time)
            if __exchange_info_time_diff > self.__exchange_info_time_limit:
                with self.__lock:
                    self.__exchange_info = self.__api_client.fetch_markets()
                    self.__exchange_symbols_info = self.__get_exchange_symbols_info()
                    self.__exchange_trading_fees = self.__get_trading_fees()
                    self.__exchange_symbols_prices = self.__get_all_symbols_prices()
                    self.__exchange_balances = self.__get_balances()
                    self.__exchange_usdt_balances = self.__get_usdt_balances()
                    self.__exchange_info_time = abs(int(round(time.time())))

            with self.__lock_events_queue:
                if self.__events_queue.qsize() > 0:
                    __event = self.__events_queue.get()
                    self.__save_queue()

                    self.__proc_event(__event)

            if self.__events_queue.qsize() == 0:
                with self.__lock:
                    __to_run = self.__main_thread_running

            time.sleep(self.__main_thread_sleep)

        return result

    def __launch_ping_thread(self):
        """
        __launch_ping_thread
        ====================

        Launches a thread that periodically sends a ping request to the WebSocket server 
        to maintain the connection.

        The ping request is sent every 23 seconds to ensure that the connection remains 
        alive. The thread checks if the main thread is still running before sending 
        the ping. If the main thread is no longer running, the ping thread will stop.

        Parameters:
        -----------
        None

        Returns:
        --------
        None
            This method does not return a value. It runs in a separate thread to 
            continuously send ping requests.
        """

        __ping_time = 23

        __to_run = True
        while __to_run:

            self.__bmo.ping()
            with self.__lock:
                __to_run = self.__main_thread_running

            time.sleep(__ping_time)

    def force_reload_exchange_info(self):
        """
        force_reload_exchange_info
        ==========================
        
        Forces a reload of the exchange information by resetting the 
        timestamp that tracks the last time exchange information was 
        fetched. This allows the system to retrieve fresh data from 
        the exchange the next time it checks for updates.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True, indicating that the reload operation was 
            triggered successfully.
        """
        result = True
        with self.__lock:
            self.__exchange_info_time = 0

        return result

    def stop_listen_socket(self):
        """
        stop_listen_socket
        ==================

        This method stops the WebSocket client from listening to incoming messages
        and terminates the associated threads. It gracefully shuts down the WebSocket
        connection and ensures that the main thread is no longer running.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        bool
            Returns True to indicate that the WebSocket client has been stopped successfully.
        """
        result = True

        with self.__lock:
            self.__main_thread_running = False

        if self.__main_thread is not None and isinstance(self.__main_thread, threading.Thread):
            self.__main_thread.join(400)

        if self.__ping_thread is not None and isinstance(self.__ping_thread, threading.Thread):
            self.__ping_thread.join(400)

        self.__bmo.stop()

        return result

    def __ws_message_handler(self, message):
        """
        __ws_message_handler
        ====================

        This internal function handles incoming WebSocket messages. It checks if the
        received message is a valid JSON string, parses it, and adds it to the events queue
        if it contains a specific event type.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.
        _ : Any
            Unused parameter typically representing the WebSocket instance.
        message : str
            The incoming WebSocket message as a JSON string.

        Returns:
        --------
        None
            This method does not return a value.
        """
        result = None

        if ccf.is_json(message):
            __message_e = json.loads(message)

            if __message_e is not None and isinstance(__message_e, dict):
                if 'e' in __message_e\
                    and __message_e['e'] is not None\
                    and isinstance(__message_e['e'], str):
                    with self.__lock_events_queue:
                        self.__events_queue.put(__message_e)
                        self.__save_queue()

        # print(f'message:\n{json.dumps(__message, indent=4)}\n')
        # print(f'message type: {type(message)}')
        # print('================================================================')

        return result

    def __proc_event(self, event):
        """
        __proc_event
        ============

        Processes incoming events from the WebSocket. Based on the event type,
        it delegates the handling to the corresponding processing method.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.
        event : dict
            The event data received from the WebSocket, containing at least an 
            event type key 'e' that determines the processing logic.

        Returns:
        --------
        Any
            The result of the event processing, which can vary depending on 
            the specific event type handled. Returns None if the event type 
            does not match any known handlers.
        """
        result = None

        # pprint.pprint(event, sort_dicts=False)
        if event['e'] == 'outboundAccountPosition':
            result = self.__proc_outbound_account_position(event)
        elif event['e'] == 'balanceUpdate':
            result = self.__proc_balance_update(event)
        elif event['e'] == 'executionReport':
            result = self.__proc_execution_report(event)

        return result

    def __proc_execution_report(self, event):
        """
        __proc_execution_report
        =======================
        
        Processes the execution report event from the WebSocket, which contains
        information about the status of an order. Validates the required fields
        in the event and retrieves the corresponding order data.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.
        event : dict
            The event data received from the WebSocket, which must include
            the keys 's' (symbol), 'X' (status), and 'i' (order ID).

        Returns:
        --------
        Any
            Returns None. The processing may result in side effects, such as
            updating order status in the internal order storage, but does not
            return a specific value.
        """
        result = None

        req_types = {
            's': str,
            'X': str,
            'i': (int, str)
        }

        if all((key in event and isinstance(event[key], types))\
               for key, types in req_types.items()):
            __symbol = event['s']
            __status = event['X']
            __order_id = event['i']

            __order_statuses = ['FILLED', 'CANCELED', 'REJECTED', 'EXPIRED', 'EXPIRED_IN_MATCH']

            if __order_id is not None\
                and isinstance(__order_id, (int, str))\
                and len(str(__order_id)) > 0\
                and __status is not None\
                and isinstance(__status, str)\
                and __status in __order_statuses:

                __order_data = self.__get_order(__order_id, __symbol)

        return result

    def __get_order(self, order_id, symbol):
        """
        __get_order
        ===========
        
        Retrieves the order details from the exchange for a given order ID and symbol.
        The order data is then saved to the internal orders dictionary. If successful,
        it returns the order data, otherwise, it handles any exceptions and returns None.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.
        order_id : int or str
            The unique identifier of the order to retrieve.
        symbol : str
            The trading pair symbol associated with the order.

        Returns:
        --------
        dict or None
            Returns the order data as a dictionary if successful; otherwise, returns None.
        """

        result = None

        try:
            __order_data = self.__bmo.get_order(order_id, symbol)

            if __order_data is not None\
                and isinstance(__order_data, dict)\
                and 'id' in __order_data\
                and 'timestamp' in __order_data\
                and 'status' in __order_data:

                if 'info' in __order_data:
                    del __order_data['info']

                with self.__lock_orders:
                    self.__orders[str(__order_data['id'])] = __order_data
                    self.__save_orders()
                result = __order_data

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, order_id: {order_id}'
                err_msg += f', symbol: {symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def ping(self):
        """
        ping
        ====
        Sends a ping message to the WebSocket server to keep the connection alive.
        This method is typically called periodically to prevent the connection from
        timing out due to inactivity.

        Returns:
        --------
        bool
            Returns True if the ping message was sent successfully, False otherwise.
        """

        return self.__bmo.ping()

    def get_orders(self, symbol: str=None, order_status: str=None, from_api: bool=False):
        """
        get_orders
        ==========
        
        Retrieves the current orders stored in the internal orders dictionary.
        This method is thread-safe and ensures that the order data is accessed
        without interference from other threads.

        Parameters:
        -----------
        self : BinanceCcxaoAuxClass
            The instance of the BinanceCcxaoAuxClass.

        Returns:
        --------
        dict
            A dictionary containing the current orders, where the keys are order IDs
            and the values are the corresponding order data.
        """
        result = None

        if from_api:
            try:
                __data = None

                if order_status is not None\
                    and isinstance(order_status, str):
                    if order_status.lower() == 'open':
                        __data = self.__api_client.fetch_open_orders(symbol=symbol)
                    elif order_status.lower() == 'closed':
                        __data = self.__api_client.fetch_closed_orders(symbol=symbol)

                else:
                    __data = self.__api_client.fetch_orders(symbol=symbol)
                    if __data is None or not isinstance(__data, list):
                        __data = []

                        __data_open = self.__api_client.fetch_open_orders(symbol=symbol)
                        __data_closed = self.__api_client.fetch_closed_orders(symbol=symbol)
                        if __data_open is not None and isinstance(__data_open, list):
                            __data.extend(__data_open)
                        if __data_closed is not None and isinstance(__data_closed, list):
                            __data.extend(__data_closed)

                if order_status is None:
                    __data = self.__api_client.fetch_orders(symbol=symbol)
                elif isinstance(order_status, str):
                    if order_status.lower() == 'open':
                        __data = self.__api_client.fetch_open_orders(symbol=symbol)
                    elif order_status.lower() == 'closed':
                        __data = self.__api_client.fetch_closed_orders(symbol=symbol)

                if __data is not None and isinstance(__data, list):
                    result = {}
                    for __order in __data:
                        if __order is not None and isinstance(__order, dict):
                            __order_id = __order['id']
                            result[__order_id] = __order

                if __data is not None and isinstance(__data, list):
                    result = {}
                    for __order in __data:
                        if __order is not None and isinstance(__order, dict):
                            __order_id = __order['id']
                            result[__order_id] = __order
                            result[__order_id].pop('info', None)

            except Exception as e: # pylint: disable=broad-except
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
                err_msg += f', error: {e}'
                self.__err_logger.error(err_msg)
                result = None

        else:
            with self.__lock_orders:
                result = self.__orders

        return result

    def del_order(self, order_id):
        """
        del_order
        =========

        Deletes the specified order from the internal orders dictionary.

        Parameters:
        -----------
        order_id : str, int
            The ID of the order to be deleted. This can be provided as a string or an integer.

        Returns:
        --------
        bool
            True if the order was successfully deleted, False if the order was not found
            or an error occurred during deletion.
        """
        result = self.__del_order(order_id)

        return result

    def __del_order(self, order_id):
        """
        __del_order
        ===========

        Deletes an order from the internal orders dictionary if it is not in 'open' status.

        Parameters:
        -----------
        order_id : str, int
            The ID of the order to be deleted. This can be provided as a string or an integer.

        Returns:
        --------
        bool
            True if the order was successfully deleted or was not found (already deleted).
            False if the order exists and is still in 'open' status, or if an error occurred
            during deletion.
        
        Notes:
        ------
        This method only allows the deletion of orders that are not currently 'open'. 
        If the order is in 'open' status, it will not be deleted, and the method will return False.
        Additionally, if the order is not found, it will return True to indicate that no action was
        necessary.
        """

        result = False

        try:
            with self.__lock_orders:
                # pprint.pprint(self.__orders, sort_dicts=False)
                # print(f'ENTRE: {order_id} -> {str(order_id) in self.__orders}')
                # -> {"status" in self.__orders[order_id]}
                # -> {self.__orders[order_id]["status"] != "open"}')

                if str(order_id) in self.__orders\
                    and 'status' in self.__orders[order_id]\
                    and self.__orders[str(order_id)]['status'] != 'open':

                    del self.__orders[str(order_id)]
                    self.__save_orders()
                    result = True
                elif order_id not in self.__orders:
                    result = True
                else:
                    result = False

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, order_id: {order_id}'
                err_msg += f', error: {e}'
                self.__err_logger.error(err_msg)
            # print(f'DEL EXC: {e}')
            result = False

        return result

    def __proc_outbound_account_position(self, event):
        """
        __proc_outbound_account_position
        ================================

        Processes the outbound account position event, updating the exchange balances
        and calculating the USDT equivalent balances for each asset.

        Parameters:
        -----------
        event : dict
            The event data containing the account balances. The 'B' key should contain a 
            list of balances, where each balance is represented as a dictionary with 'a'
            (asset) and 'f' (free balance) keys.

        Returns:
        --------
        bool
            Returns True if the balances were successfully processed and updated; 
            otherwise, returns None.

        Notes:
        ------
        This method performs the following actions:
        1. Checks if the 'B' key exists in the event and is a non-empty list.
        2. Iterates through the balances, extracting the asset and free balance.
        3. Updates the local exchange balances dictionary with the free balance for each asset.
        4. Calculates the USDT equivalent balance for each asset using current market prices,
           if available, and stores it in a separate dictionary.
        5. Computes the total USDT balance across all assets and updates it in the dictionary.        
        """
        result = None

        if 'B' in event\
            and event['B'] is not None\
            and isinstance(event['B'], list):

            for b in event['B']:
                if b is not None\
                    and isinstance(b, dict)\
                    and 'a' in b and 'f' in b\
                    and isinstance(b['a'], str)\
                    and isinstance(b['f'], str):

                    with self.__lock:
                        self.__exchange_balances[b['a']] = float(b['f'])

                        __symbol = b['a'] + '/USDT'
                        if self.__exchange_symbols_prices is not None\
                            and isinstance(self.__exchange_symbols_prices, dict)\
                            and __symbol in self.__exchange_symbols_prices\
                            and self.__exchange_symbols_prices[__symbol] is not None:

                            self.__exchange_usdt_balances[b['a']] = (
                                round(self.__exchange_balances[b['a']]\
                                        * self.__exchange_symbols_prices[__symbol], 2)
                            )

                            __total = 0
                            for __asset, __balance in self.__exchange_usdt_balances.items():
                                if __asset != '__total__':
                                    __total += __balance

                            self.__exchange_usdt_balances['__total__'] = round(__total, 2)
                            result = True

        return result

    def __proc_balance_update(self, event):
        """
        __proc_balance_update
        ======================

        Processes a balance update event, updating the exchange balances
        and recalculating the USDT equivalent balance for the updated asset.

        Parameters:
        -----------
        event : dict
            The event data containing the balance update information. The 'a' key 
            should contain the asset symbol, and the 'd' key should contain the 
            amount change (positive or negative) as a string.

        Returns:
        --------
        bool
            Returns True if the balance was successfully processed and updated; 
            otherwise, returns None.

        Notes:
        ------
        This method performs the following actions:
        1. Checks if the 'a' (asset) and 'd' (amount change) keys exist in the event 
           and are of the correct type.
        2. Updates the local exchange balances dictionary with the new balance for 
           the specified asset, adding the change to the existing balance.
        3. If the asset price in USDT is available, calculates the new USDT 
           equivalent balance for the asset and updates it in the respective dictionary.
        4. Recalculates the total USDT balance across all assets and updates it in 
           the dictionary.        
        """
        result = None

        if 'a' in event\
            and event['a'] is not None\
            and isinstance(event['a'], str)\
            and 'd' in event\
            and event['d'] is not None\
            and isinstance(event['d'], str):

            with self.__lock:
                if event['a'] in self.__exchange_balances:
                    self.__exchange_balances[event['a']] = (
                        self.__exchange_balances[event['a']] + float(event['d'])
                    )
                else:
                    self.__exchange_balances[event['a']] = float(event['d'])

                __symbol = event['a'] + '/USDT'

                if event['a'] == 'USDT':
                    self.__exchange_usdt_balances[event['a']] = (
                        round(self.__exchange_balances[event['a']], 2)
                    )

                elif self.__exchange_symbols_prices is not None\
                    and isinstance(self.__exchange_symbols_prices, dict)\
                    and __symbol in self.__exchange_symbols_prices\
                    and self.__exchange_symbols_prices[__symbol] is not None:

                    self.__exchange_usdt_balances[event['a']] = (
                        round(self.__exchange_balances[event['a']]\
                                * self.__exchange_symbols_prices[__symbol], 2)
                    )

                __total = 0
                for __asset, __balance in self.__exchange_usdt_balances.items():
                    if __asset != '__total__':
                        __total += __balance

                self.__exchange_usdt_balances['__total__'] = round(__total, 2)
                result = True


        return result

    def get_exchange_info(self):
        """
        get_exchange_info
        =================

        Retrieves the current exchange information stored in the instance.

        Returns:
        --------
        dict or None
            Returns a dictionary containing the exchange information if available; 
            otherwise, returns None.

        Notes:
        ------
        This method is thread-safe and uses a lock to ensure that the exchange 
        information is accessed safely in a multi-threaded environment. It provides 
        a snapshot of the exchange's data as stored in the instance variable 
        `__exchange_info`.
        """
        result = None

        with self.__lock:
            result = self.__exchange_info

        return result

    def __get_trading_fees(self):
        """
        __get_trading_fees
        ==================

        Fetches the current trading fees for each trading pair from the API client.

        Returns:
        --------
        dict or None
            A dictionary where each key is a trading symbol and its value is another 
            dictionary containing the 'maker' and 'taker' fees as floats. Returns None 
            if the trading fees could not be retrieved or if the API client does not 
            support fetching trading fees.

        Notes:
        ------
        This method checks if the API client has the `fetch_trading_fees` method 
        before attempting to call it. If the response data is valid, it processes 
        the data to return the trading fees for each trading pair.         
        """
        result = None

        if hasattr(self.__api_client, 'fetch_trading_fees'):
            __data = self.__api_client.fetch_trading_fees()

            if __data is not None and isinstance(__data, dict):
                result = {}

                for symbol, data in __data.items():
                    result[symbol] = None
                    result[symbol] = {}
                    result[symbol]['maker'] = float(data['maker'])
                    result[symbol]['taker'] = float(data['taker'])

        return result

    def get_trading_fees(self):
        """
        get_trading_fees
        =================

        Retrieves the current trading fees stored in the instance.

        Returns:
        --------
        dict or None
            A dictionary containing the trading fees for each trading pair, where 
            each key is a trading symbol and its value is another dictionary 
            with 'maker' and 'taker' fees. Returns None if no trading fees are available.

        Notes:
        ------
        This method is thread-safe and uses a lock to ensure that the trading fees 
        are accessed safely across multiple threads. It provides a way to access the 
        current trading fees without directly exposing the internal data structure.
        """
        result = None

        with self.__lock:
            result = self.__exchange_trading_fees

        return result

    def __get_exchange_symbols_info(self):
        """
        __get_exchange_symbols_info
        ===========================

        Extracts and returns information about exchange symbols from the 
        stored exchange information.

        Returns:
        --------
        dict or None
            A dictionary where each key is a trading symbol and its value 
            is a dictionary containing information about that symbol, excluding 
            the 'info' key. Returns None if no exchange information is available 
            or if the data structure is not in the expected format.

        Notes:
        ------
        This method is intended for internal use and provides a way to access 
        symbol-specific information without exposing the full data structure.
        It assumes that the exchange information has been previously loaded 
        and is stored in the instance.
        """
        result = None

        __data = None
        __data = self.__exchange_info

        if __data is not None\
            and isinstance(__data, list):

            result = {}
            for symbol_data in __data:
                __symbol = symbol_data['symbol']
                __not_info = copy.deepcopy(symbol_data)
                if 'info' in __not_info:

                    del __not_info['info']
                result[__symbol] = __not_info

        return result

    def get_exchange_symbols_info(self):
        """
        get_exchange_symbols_info
        =========================

        Retrieves information about the exchange trading symbols.

        Returns:
        --------
        dict or None
            A dictionary containing information about each trading symbol, 
            with the symbol name as the key and its associated data as the value. 
            Returns None if the symbol information is not available or has not 
            been initialized yet.

        Notes:
        ------
        This method is thread-safe and utilizes a lock to ensure consistent access 
        to the exchange symbols information. It should be used to access the most 
        recent state of the symbol information stored in the instance.
        """
        result = None

        with self.__lock:
            result = self.__exchange_symbols_info

        return result

    def get_symbol_price(self, symbol='BTC/USDT', from_cache=True):
        """
        get_symbol_price
        ================
        Retrieves the current price of a specified trading symbol.

        Parameters:
        -----------
        symbol : str, optional
            The trading pair symbol to fetch the price for. Defaults to 'BTC/USDT'.
        from_cache : bool, optional
            Indicates whether to retrieve the price from the cached values. 
            If True, it checks the cache first before making an API call. Defaults to True.

        Returns:
        --------
        float or None
            The last price of the specified symbol if available, otherwise None.

        Notes:
        ------
        This function attempts to fetch the price of the symbol from the cache if 
        `from_cache` is set to True. If the price is not found in the cache, it 
        retrieves the price from the API client.
        """
        result = None

        if from_cache:
            with self.__lock:
                __prices = self.__exchange_symbols_prices

            if __prices is not None and isinstance(__prices, dict) and symbol in __prices:
                result = __prices[symbol]

        if result is None:
            __ticker = self.__api_client.fetch_ticker(symbol)

            if __ticker is not None and isinstance(__ticker, dict) and 'last' in __ticker:
                result = __ticker['last']

        return result

    def __get_balances(self):
        """
        __get_balances
        ==============
        Fetches the current balances of free assets available in the account.

        Returns:
        --------
        dict or None
            A dictionary containing the asset symbols as keys and their corresponding 
            free balances as values. If no free balances are found, returns None.

        Notes:
        ------
        This function retrieves the account's free balances using the API client. 
        It processes the balance data and returns only the assets with a balance greater than zero.
        """
        result = None

        __balance_data = self.__api_client.fetch_balance()

        if __balance_data is not None\
            and isinstance(__balance_data, dict)\
            and 'free' in __balance_data\
            and __balance_data['free'] is not None\
            and isinstance(__balance_data['free'], dict):

            result = {}

            for asset, balance in __balance_data['free'].items():
                if balance > 0:
                    result[asset] = balance

        return result

    def get_balances(self):
        """
        get_balances
        ============
        Retrieves the current balances of free assets from the exchange.

        Returns:
        --------
        dict
            A dictionary containing the asset symbols as keys and their corresponding 
            balances as values. If there are no balances, an empty dictionary is returned.

        Notes:
        ------
        This method uses the API client to fetch the account's free balances. The result 
        is processed to return all available asset balances, even if they are zero.
        """
        result = None

        with self.__lock:
            result = self.__exchange_balances

        return result

    def __get_usdt_balances(self):
        """
        __get_usdt_balances
        ====================
        
        Calculates the USDT equivalent of the current asset balances based on their prices.

        Returns:
        --------
        dict or None
            A dictionary containing asset symbols as keys and their corresponding USDT 
            balances as values. The total USDT balance is also included with the key 
            '__total__'. If no balances are available, returns None.

        Notes:
        ------
        This method calculates the value of each asset in terms of USDT by fetching the 
        current asset prices and multiplying them by the asset balances. If no balances 
        or prices are available, the method will return None.
        """
        result = None

        __total = 0

        if self.__exchange_balances is not None\
            and isinstance(self.__exchange_balances, dict)\
            and self.__exchange_symbols_prices is not None\
            and isinstance(self.__exchange_symbols_prices, dict):
            result = {}
            for __asset, __balance in self.__exchange_balances.items():
                if __asset is not None and __balance is not None:
                    __symbol = __asset + '/USDT'

                    if __asset == 'USDT':
                        result[__asset] = round(__balance, 2)
                        __total += result[__asset]

                    elif self.__exchange_symbols_prices is not None\
                        and isinstance(self.__exchange_symbols_prices, dict)\
                        and __symbol in self.__exchange_symbols_prices\
                        and self.__exchange_symbols_prices[__symbol] is not None:

                        result[__asset] = (
                            round(__balance * self.__exchange_symbols_prices[__symbol], 2)
                        )
                        __total += result[__asset]

            result['__total__'] = round(__total,2)

        return result

    def get_usdt_balances(self):
        """
        get_usdt_balances
        =================

        Retrieves the current USDT balances for all assets in the exchange.

        Returns:
        --------
        dict or None
            A dictionary containing asset symbols as keys and their corresponding USDT 
            balances as values. If no USDT balances are available, returns None.

        Notes:
        ------
        This method fetches the current USDT balances for all assets held in the account. 
        It processes the available balances and converts them into their equivalent USDT values 
        based on the current market price of each asset.
        """
        result = None
        with self.__lock:
            result = self.__exchange_usdt_balances

        return result

    def get_exchange_tickers(self):
        """
        get_exchange_tickers
        ====================

        Retrieves the current ticker information for all trading pairs available on the exchange.

        Returns:
        --------
        dict or None
            A dictionary containing ticker information for all trading pairs. If no tickers 
            are available, returns None.

        Notes:
        ------
        This method fetches the latest ticker data from the API client, which includes 
        various market statistics such as last price, bid/ask prices, volume, etc., for 
        each trading pair on the exchange.
        """
        result = None

        __tickers = self.__api_client.fetch_tickers()

        if __tickers is not None and isinstance(__tickers, dict):
            result = {}
            for __symbol, __ticker in __tickers.items():

                if __ticker is not None and isinstance(__ticker, dict):
                    __ticker.pop('info', None)
                    result[__symbol] = __ticker

        return result


    def __get_all_symbols_prices(self):
        """
        __get_all_symbols_prices
        ========================

        Fetches the current prices for all trading pairs available on the exchange.

        Returns:
        --------
        dict or None
            A dictionary containing trading pair symbols as keys and their last traded prices 
            as values. If no prices are available, returns None.

        Notes:
        ------
        This method retrieves the latest prices for all available trading pairs on the exchange 
        by fetching ticker information from the API client. The returned data is processed 
        to extract the last traded price for each trading pair.
        """
        result = None

        __tickers = self.__api_client.fetch_tickers()

        if __tickers is not None and isinstance(__tickers, dict):
            result = {}
            for __symbol, __ticker in __tickers.items():

                if __ticker is not None and isinstance(__ticker, dict) and 'last' in __ticker:
                    result[__symbol] = __ticker['last']

        return result

    def get_order(self, order_id, order_symbol):
        """
        get_order
        =========

        Retrieves the order data for a specific order.

        Parameters:
        -----------
        order_id : str or int
            The unique identifier for the order.
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').

        Returns:
        --------
        dict or None
            A dictionary containing the order data if found, or None if an error 
            occurred while fetching the order.

        Notes:
        ------
        This method calls the internal `__get_order` function to retrieve the 
        order information for the specified order ID and symbol.
        """

        result = self.__get_order(order_id, order_symbol)

        return result

    def cancel_order(self, order_id, order_symbol, order_params=None):
        """
        cancel_order
        ============

        Cancels an existing order on the exchange.

        Parameters:
        -----------
        order_id : str or int
            The unique identifier of the order to be canceled.
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').
        order_params : dict, optional
            Additional parameters for canceling the order. Default is None.

        Returns:
        --------
        bool
            True if the order was successfully canceled, or False if an error occurred 
            or the order was not found.

        Notes:
        ------
        This method cancels an order by calling the `cancel_order` function of the API client. 
        It also logs the operation and saves the updated order data if the cancellation is
        successful.
        """

        result = False
        if order_params is None:
            order_params = {}

        try:
            __order_data = self.__bmo.cancel_order(order_id, order_symbol)

            if __order_data is not None\
                and isinstance(__order_data, dict)\
                and 'id' in __order_data\
                and 'timestamp' in __order_data\
                and 'status' in __order_data:

                if 'info' in __order_data:
                    del __order_data['info']

                with self.__lock_orders:
                    self.__orders[str(__order_data['id'])] = __order_data
                    self.__save_orders()

                if __order_data['status'] is not None\
                    and isinstance(__order_data['status'], str)\
                    and __order_data['status'] == 'canceled':
                    result = True

                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                log_msg = f'{__l_function}, exchange: {self.__exchange}'
                log_msg += f', symbol: {order_symbol}, result: {result}'
                self.__log_logger.info(log_msg)

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}, order_id: {order_id}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = False

        return result

    def create_order(self,\
                     order_symbol: str='BTC/USDT',\
                     order_side: str='buy',\
                     order_amount: float=0,\
                     order_price: float=0,\
                     order_type: str='limit',\
                     order_params: dict=None):
        """
        create_order
        ============
        
        Creates a new order on the exchange.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').
        order_side : str
            The side of the order, either 'buy' or 'sell'.
        order_amount : float
            The amount to buy or sell. Must be greater than 0.
        order_price : float
            The price at which to buy or sell. Must be greater than 0.
        order_type : str
            The type of order; only 'limit' or 'limit_maker' are allowed.
        order_params : dict, optional
            Additional parameters for the order. Default is None.

        Returns:
        --------
        dict or None
            Returns a dictionary with the order data if the order was created successfully, 
            or None if an error occurred.

        Notes:
        ------
        This method sends a new order request to the exchange using the `create_order` function of 
        the API client. It also saves the order data and logs the operation. If `order_type` is 
        'limit_maker', the `timeInForce` parameter is removed from `order_params` if present.
        """

        result = None
        if order_params is None:
            order_params = {}

        time_in_force = order_params.pop('timeInForce', 'GTC')

        if order_type == 'limit_maker':
            order_type = 'limit'

        try:
            __order_data = self.__bmo.create_order(order_symbol=order_symbol,
                                                   order_type=order_type,
                                                   order_side=order_side,
                                                   order_amount=order_amount,
                                                   order_price=order_price,
                                                   time_in_force=time_in_force)

            time.sleep(0.25)
            __order_data = copy.deepcopy(__order_data)

            if __order_data is not None\
                and isinstance(__order_data, dict)\
                and 'id' in __order_data\
                and 'timestamp' in __order_data\
                and 'status' in __order_data:
                if __order_data['id'] is not None:

                    __order_data = copy.deepcopy(__order_data)

                    __order_data.pop('info', None)

                    with self.__lock_orders:
                        self.__orders[str(__order_data['id'])] = copy.deepcopy(__order_data)
                        self.__save_orders()

                    result = copy.deepcopy(__order_data)

                    if self.__log_logger is not None:
                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        log_msg = f'{__l_function}, exchange: {self.__exchange}'
                        log_msg += f', symbol: {order_symbol}, order_side: {order_side}'
                        log_msg += f', order_amount: {order_amount}, order_price: {order_price}'
                        log_msg += f', order_type: {order_type}'
                        self.__log_logger.info(log_msg)
                else:
                    if self.__err_logger is not None:
                        __error_code = __order_data.get('error_code', 0)
                        __error_msg = __order_data.get('error_msg', '')
                        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                        err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
                        err_msg += f', symbol: {order_symbol}, order_side: {order_side}'
                        err_msg += f', order_amount: {order_amount}, order_price: {order_price}'
                        err_msg += f', order_type: {order_type}, error_code: {__error_code}'
                        err_msg += f', error_msg: {__error_msg}'
                        self.__err_logger.error(err_msg)

        except Exception as e: # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, exchange: {self.__exchange}'
            err_msg += f', symbol: {order_symbol}, order_side: {order_side}'
            err_msg += f', order_amount: {order_amount}, order_price: {order_price}'
            err_msg += f', order_type: {order_type}, ERROR: {e}'
            if self.__err_logger is not None:
                self.__err_logger.error(err_msg)

        return result

    def amount_to_precision(self, order_symbol, order_amount):
        """
        amount_to_precision
        ===================

        Rounds the order amount to the appropriate precision for the specified symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').
        order_amount : float
            The amount to round. Must be greater than 0.

        Returns:
        --------
        float or None
            Returns the rounded amount to the precision required for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method first loads the markets from the API client and then calls 
        the `amount_to_precision` method of the API client to round the order amount. 
        If an error occurs during this process, it logs the error and returns None.
        """
        result = None

        try:
            self.__api_client.load_markets()
            result = self.__api_client.amount_to_precision(order_symbol, order_amount)

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)

            result = None

        return result

    def price_to_precision(self, order_symbol, order_price):
        """
        price_to_precision
        ==================

        Rounds the order price to the appropriate precision for the specified symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for the order (e.g., 'BTC/USDT').
        order_price : float
            The price to round. Must be greater than 0.

        Returns:
        --------
        float or None
            Returns the rounded price to the precision required for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method first loads the markets from the API client and then calls 
        the `price_to_precision` method of the API client to round the order price. 
        If an error occurs during this process, it logs the error and returns None.
        """
        result = None

        try:
            self.__api_client.load_markets()
            result = self.__api_client.price_to_precision(order_symbol, order_price)

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def cost_to_precision(self, order_symbol, order_cost):
        """
        cost_to_precision
        =================
        """

        result = None

        try:
            self.__api_client.load_markets()
            result = self.__api_client.cost_to_precision(order_symbol, order_cost)

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def symbol_min_amount(self, order_symbol):
        """
        symbol_min_amount
        =================

        Retrieves the minimum amount required to buy or sell a specific trading symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for which to retrieve the minimum amount (e.g., 'BTC/USDT').

        Returns:
        --------
        float or None
            Returns the minimum amount to buy or sell for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method loads the markets from the API client and accesses the minimum amount 
        limit for the specified symbol. If an error occurs during this process, it logs 
        the error and returns None.
        """
        result = None

        try:
            __markets = self.__api_client.load_markets()
            result = float(__markets[order_symbol]['limits']['amount']['min'])

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def symbol_tick_size(self, order_symbol):
        """
        symbol_tick_size
        ================

        Retrieves the tick size for a specific trading symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for which to retrieve the tick size (e.g., 'BTC/USDT').

        Returns:
        --------
        float or None
            Returns the tick size for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method loads the markets from the API client and accesses the precision 
        for the price of the specified symbol. If an error occurs during this process, 
        it logs the error and returns None.
        """
        result = None

        try:
            __markets = self.__api_client.load_markets()
            result = float(__markets[order_symbol]['precision']['price'])

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def symbol_min_cost(self, order_symbol):
        """
        symbol_min_cost
        ===============

        Retrieves the minimum cost required to buy or sell a specific trading symbol.

        Parameters:
        -----------
        order_symbol : str
            The trading symbol for which to retrieve the minimum cost (e.g., 'BTC/USDT').

        Returns:
        --------
        float or None
            Returns the minimum cost for the symbol, 
            or None if an error occurred.

        Notes:
        ------
        This method loads the markets from the API client and accesses the limits 
        for the cost of the specified symbol. If an error occurs during this process, 
        it logs the error and returns None.
        """
        result = None

        try:
            __markets = self.__api_client.load_markets()
            result = float(__markets[order_symbol]['limits']['cost']['min'])
            result = float(self.cost_to_precision(order_symbol, result))

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', symbol: {order_symbol}, error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def get_markets(self):
        """
        get_markets
        ===========

        Retrieves market information for all available trading pairs.

        Returns:
        --------
        dict or None
            Returns a dictionary containing market information for all symbols, 
            or None if an error occurred.

        Notes:
        ------
        This method calls the API client to load the markets. If an error occurs 
        during this process, it logs the error and returns None.
        """
        result = None

        try:
            result = self.__api_client.load_markets()

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def get_ratelimit(self):
        """
        get_ratelimit
        =============

        Retrieves the rate limits for API requests.

        Returns:
        --------
        dict or None
            Returns a dictionary containing the raw rate limits and 
            order request rate limits, or None if an error occurred.

        Notes:
        ------
        This method fetches the rate limits from both the main API client 
        and the orders API client. If an error occurs during this process, 
        it logs the error and returns None.
        """
        result = None

        try:
            result = {}
            result['RAW_REQUEST'] = self.__api_client.rateLimit
            result['ORDER_REQUEST'] = result['RAW_REQUEST']

        except Exception as e: # pylint: disable=broad-except
            if self.__err_logger is not None:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in {__l_function}'
                err_msg += f', error: {e}'
                self.__err_logger.error(err_msg)
            result = None

        return result

    def get_ccxt_inst(self):
        """
        get_ccxt_inst
        =============

        Retrieves the CCXT API client instance.

        Returns:
        --------
        ccxt.Exchange or None
            Returns the CCXT exchange instance used for API communication,
            or None if the instance has not been initialized.

        Notes:
        ------
        This method provides access to the underlying CCXT library instance,
        allowing direct interaction with exchange-specific methods and properties
        not exposed through the wrapper interface.
        """
        result = None

        result = self.__api_client

        return result

    def dual_investment_get_products(self,
                                     params: dict=None) -> List[dict]:
        """
        Retrieve available Dual Investment products from Binance.

        This method fetches Dual Investment products from Binance's API with optional filtering
        by option type, asset pair, duration, and APR. It handles pagination automatically and
        returns a sorted list of products by APR in descending order.

        Args:
            params (dict, optional): Dictionary containing filter parameters. Defaults to None.
                Available keys:
                - option (str, optional): The option type - 'buy' for PUT options (low buy products)
                                          or 'sell' for CALL options (high sell products).
                                          Defaults to None.
                - asset (str, optional): The asset coin symbol (e.g., 'BNB', 'ETH').
                                         Defaults to None.
                - quote (str, optional): The quote coin symbol (e.g., 'USDT', 'BUSD').
                                         Defaults to None.
                - max_duration_days (int, optional): Maximum duration in days for
                                                     the investment products.
                                                     Only products with duration <= this value will
                                                     be returned. Defaults to 1.
                - min_apr (float, optional): Minimum Annual Percentage Rate (APR) filter.
                                             Only products with APR >= this value will be returned.
                                             Defaults to None (no minimum filter).
                - max_page_index (int, optional): Maximum number of pages to fetch from the API.
                                                  Each page contains up to 100 products.
                                                  Defaults to 10.

        Returns:
            List[dict]: A list of dictionaries containing Dual Investment product details.
                       Each dictionary includes:
                        - id: Product ID
                        - investCoin: Coin to invest
                        - exercisedCoin: Coin to be exercised
                        - strikePrice: Strike price of the option
                        - duration: Duration in days
                        - settleDate: Settlement date timestamp
                        - settleDateTime: Settlement date in human-readable format
                        - purchaseDecimal: Decimal precision for purchase amounts
                        - purchaseEndTime: Purchase end time timestamp
                        - purchaseEndDateTime: Purchase end time in human-readable format
                        - canPurchase: Boolean indicating if the product can be purchased
                        - apr: Annual Percentage Rate
                        - orderId: Order ID
                        - minAmount: Minimum investment amount
                        - maxAmount: Maximum investment amount
                        - createTimestamp: Creation timestamp
                        - createDateTime: Creation date in human-readable format
                        - optionType: Type of option (CALL or PUT)
                       
                       Returns None if an error occurs or no products are found.

        Raises:
            ValueError: If the option parameter is not 'buy' or 'sell'.

        Note:
            - CALL options are "high sell" products: optionType:CALL, exercisedCoin:USDT,
              investCoin:BNB
            - PUT options are "low buy" products: optionType:PUT, exercisedCoin:BNB, investCoin:USDT
            - The method includes a 0.25 second delay between page requests to avoid rate limits
            - Results are sorted by APR in descending order (highest APR first)
        """

        result = None
        option = params.get('option', None) if isinstance(params, dict) else None
        asset = params.get('asset', None) if isinstance(params, dict) else None
        quote = params.get('quote', None) if isinstance(params, dict) else None

        max_duration_days = (
            params.get('max_duration_days', None) if isinstance(params, dict) else None
        )

        min_apr = params.get('min_apr', None) if isinstance(params, dict) else None

        max_page_index = (
            params.get('max_page_index', None) if isinstance(params, dict) else None
        )

        __option_type = None # 'CALL' or 'PUT'
        if option == 'buy':
            __option_type = 'PUT'
        elif option == 'sell':
            __option_type = 'CALL'

        if max_page_index is None:
            max_page_index = 10

        if max_duration_days is None:
            max_duration_days = 1

        # __option_type = 'PUT'  # 'CALL' or 'PUT'
        # CALL: high sell product -> optionType:CALL,exercisedCoin:USDT,investCoin:BNB
        # PUT: low buy product -> optionType:PUT,exercisedCoin:BNB,investCoin:USDT

        if __option_type is None:
            __out_msg = "Invalid option type. Must be 'buy' or 'sell'."
            raise ValueError(__out_msg)

        __asset = asset
        __quote = quote

        __page_size = 100

        __page_index = 1
        __batch_products_fetched = 1000

        __total_data = []

        __max_errors = 5
        __count_errors = 0

        while __page_index <= max_page_index\
            and __batch_products_fetched > 0\
            and __count_errors <= __max_errors:

            __query_params = {
                'optionType': str(__option_type),
                'exercisedCoin': str(__quote) if __option_type == 'CALL' else str(__asset),
                'investCoin': str(__asset) if __option_type == 'CALL' else str(__quote),
                'pageSize': int(__page_size),
                'pageIndex': int(__page_index),
                'timestamp': int(time.time() * 1000)
            }

            try:
                __products_data = self.__api_client.sapi_get_dci_product_list(__query_params)

                __products_len = __products_data.get('total', 0)
                __products_list_fetched = __products_data.get('list', [])
                __batch_products_fetched = len(__products_list_fetched)
                __total_data += __products_list_fetched
                __page_index += 1

            except Exception as exc: # pylint: disable=broad-except
                __query_json = json.dumps(__query_params, sort_keys=False)
                __error_msg = 'Error fetching Dual Investment products on exchange'
                __error_msg += f' {self.__exchange}. query_params {__query_json}: {exc}'
                __count_errors += 1

                if self.__err_logger is not None:
                    self.__err_logger.error(__error_msg)
                time.sleep(5)

            time.sleep(0.25)  # To avoid rate limits

        if isinstance(__total_data, list):
            result = []

            for __product in __total_data:

                __apr = float(__product.get('apr', 0.0))
                __can_purchase = bool(__product.get('canPurchase', False))
                __duration = int(__product.get('duration', 0))
                __settle_date = int(__product.get('settleDate', 0)) / 1000
                __settle_date_time = (
                    datetime.datetime.fromtimestamp(__settle_date).strftime('%Y-%m-%d %H:%M:%S.%f')
                )

                __purchase_end_time = int(__product.get('purchaseEndTime', 0)) / 1000
                __purchase_end_date_time = (
                    datetime.datetime.fromtimestamp(__purchase_end_time)\
                        .strftime('%Y-%m-%d %H:%M:%S.%f')
                )

                __create_timestamp = int(__product.get('createTimestamp', 0)) / 1000
                __create_date_time = (
                    datetime.datetime.fromtimestamp(__create_timestamp)\
                        .strftime('%Y-%m-%d %H:%M:%S.%f')
                )

                __apr_estimated = (__apr / 365) * __duration
                __apr_estimated = round(__apr_estimated, 4)

                if __can_purchase\
                    and isinstance(__duration, int)\
                    and __duration <= max_duration_days:

                    if min_apr is None or (__apr >= min_apr):
                        __data_product = {
                            'id': __product.get('id', ''),
                            'investCoin': __product.get('investCoin', ''),
                            'exercisedCoin': __product.get('exercisedCoin', ''),
                            'strikePrice': __product.get('strikePrice', ''),
                            'duration': __product.get('duration', ''),
                            'settleDate': __product.get('settleDate', ''),
                            'settleDateTime': __settle_date_time,
                            'purchaseDecimal': __product.get('purchaseDecimal', ''),
                            'purchaseEndTime': __product.get('purchaseEndTime', ''),
                            'purchaseEndDateTime': __purchase_end_date_time,
                            'canPurchase': __product.get('canPurchase', ''),
                            'apr': __product.get('apr', 0.0),
                            'aprEstimated': __apr_estimated,
                            'orderId': __product.get('orderId', ''),
                            'minAmount': __product.get('minAmount', ''),
                            'maxAmount': __product.get('maxAmount', ''),
                            'createTimestamp': __product.get('createTimestamp', ''),
                            'createDateTime': __create_date_time,
                            'optionType': __product.get('optionType', ''),
                        }

                        result.append(__data_product)

            result = sorted(
                result,
                key=lambda x: float(x['apr']),
                reverse=True
            )

        return result

    def dual_investment_get_positions(self,
                                      params: dict=None) -> List[dict]:
        """
        Retrieve Dual Investment positions from Binance.

        This method fetches all Dual Investment positions from Binance's API with optional
        filtering by status. It handles pagination automatically to retrieve all available
        positions across multiple pages.

        Args:
            params (dict, optional): Dictionary containing filter parameters. Defaults to None.
                Available keys:
                - status (str, optional): Filter positions by status. Common values include:
                                         - 'PENDING': Positions waiting to be settled
                                         - 'EXERCISED': Positions that have been exercised
                                         - 'SETTLED': Positions that have been settled
                                         If None, returns all positions regardless of status.
                                         Defaults to None.
                - order_id (str | int, optional): The order ID to filter positions. 
                                                  Defaults to None (no order ID filter).

        Returns:
            List[dict]: A list of dictionaries containing Dual Investment position details.
                        Each dictionary includes information about an active or historical
                        Dual Investment position such as:
                         - id: Position ID
                         - investCoin: Coin invested
                         - exercisedCoin: Coin to be exercised
                         - subscriptionAmount: Amount invested
                         - strikePrice: Strike price of the option
                         - duration: Duration in days
                         - settleDate: Settlement date timestamp
                         - settleDateTime: Settlement date in human-readable format
                         - purchaseStatus: Current status of the position
                         - apr: Annual Percentage Rate
                         - orderId: Order ID
                         - purchaseEndTime: Purchase end time timestamp
                         - purchaseEndDateTime: Purchase end time in human-readable format
                         - optionType: Type of option (CALL or PUT)
                         - autoCompoundPlan: Auto-compound plan details
                       
                        Returns an empty list if no positions are found or if an error occurs.

        Note:
            - The method includes automatic pagination with 100 positions per page
            - A 0.25 second delay is added between page requests to avoid rate limits
            - Maximum of 5 consecutive errors are tolerated before stopping the fetch
            - A 5 second delay is applied after each error before retrying
            - All positions are aggregated and returned in a single list
        """

        result = []
        status = params.get('status', None) if isinstance(params, dict) else None
        product_id = params.get('product_id', None) if isinstance(params, dict) else None
        order_id = params.get('order_id', None) if isinstance(params, dict) else None

        __page_size = 100
        __page_index = 1

        __query_params = {}

        __batch_positions_fetched = None

        __max_errors = 5
        __count_errors = 0

        __total_data = []

        while (__batch_positions_fetched is None or __batch_positions_fetched > 0)\
            and __count_errors <= __max_errors:

            if status is not None and isinstance(status, str) and len(status) > 0:
                __query_params = {
                    'status': str(status),
                    'pageSize': int(__page_size),
                    'pageIndex': int(__page_index),
                    'timestamp': int(time.time() * 1000)
                }
            else:
                __query_params = {
                    'pageSize': int(__page_size),
                    'pageIndex': int(__page_index),
                    'timestamp': int(time.time() * 1000)
                }

            try:
                __positions_data = self.__api_client.sapi_get_dci_product_positions(__query_params)
                time.sleep(0.25)  # To avoid rate limits

                __positions_list_fetched = __positions_data.get('list', [])
                __batch_positions_fetched = len(__positions_list_fetched)
                __total_data += __positions_list_fetched
                __page_index += 1

            except Exception as exc: # pylint: disable=broad-except
                __query_json = json.dumps(__query_params, sort_keys=False)
                __error_msg = 'Error fetching Dual Investment positions on exchange'
                __error_msg += f' {self.__exchange}. query_params {__query_json}: {exc}'
                __count_errors += 1

                if self.__err_logger is not None:
                    self.__err_logger.error(__error_msg)
                time.sleep(5)

        if isinstance(__total_data, list) and len(__total_data) > 0:
            for __position in __total_data:
                __settle_date = int(__position.get('settleDate', 0)) / 1000
                __settle_date_time = (
                    datetime.datetime.fromtimestamp(__settle_date).strftime('%Y-%m-%d %H:%M:%S.%f')
                )

                __purchase_end_time = int(__position.get('purchaseEndTime', 0)) / 1000
                __purchase_end_date_time = (
                    datetime.datetime.fromtimestamp(__purchase_end_time)\
                        .strftime('%Y-%m-%d %H:%M:%S.%f')
                )

                __product_id = __position.get('id', None)
                __order_id = __position.get('orderId', None)

                if order_id is not None\
                    and __order_id is not None\
                    and str(__order_id) != str(order_id):
                    continue

                if product_id is not None\
                    and __product_id is not None\
                    and str(__product_id) != str(product_id):
                    continue

                # __data_out = f'Exchange: {self.__exchange}\n'
                # __data_out += f'Position Data: {json.dumps(__position,
                #                                            indent=4,
                #                                            sort_keys=False)}\n\n'
                # __data_out += '=' * 80
                # __data_out += '\n\n'
                # ccf.file_put_contents('/tmp/ccxao_daemon_debug.log', __data_out, mode_in='a')

                __data_position = {
                    'id': __position.get('id', ''),
                    'investCoin': __position.get('investCoin', ''),
                    'exercisedCoin': __position.get('exercisedCoin', ''),
                    'subscriptionAmount': __position.get('subscriptionAmount', ''),
                    'strikePrice': __position.get('strikePrice', ''),
                    'duration': __position.get('duration', ''),
                    'isExercised': __position.get('isExercised', False),
                    'settleDate': __position.get('settleDate', ''),
                    'settleDateTime': __settle_date_time,
                    'purchaseStatus': __position.get('purchaseStatus', ''),
                    'settleAmount': __position.get('settleAmount', ''),
                    'settleAsset': __position.get('settleAsset', ''),
                    'settlePrice': __position.get('settlePrice', ''),
                    'apr': __position.get('apr', 0.0),
                    'orderId': __position.get('orderId', ''),
                    'purchaseEndTime': __position.get('purchaseEndTime', ''),
                    'purchaseEndDateTime': __purchase_end_date_time,
                    'optionType': __position.get('optionType', ''),
                    'autoCompoundPlan': __position.get('autoCompoundPlan', {}),
                }

                result.append(__data_position)

        return result

    def dual_investment_subscribe_product(self,
                                          params: dict=None) -> Optional[dict]:
        """
        Subscribe to a Dual Investment product on Binance.

        This method allows you to subscribe to a Dual Investment product by providing
        the product ID, order ID, and deposit amount. Optionally, you can specify
        an auto-compound plan for automatic reinvestment of returns.

        Args:
            params (dict, optional): Dictionary containing subscription parameters.
                                     Defaults to None.
                Available keys:
                - product_id (str): The unique identifier of the Dual Investment product
                                    to subscribe to. Must be a non-empty string.
                                    Defaults to None.
                - order_id (str): The order ID associated with the subscription.
                                  Must be a non-empty string. Defaults to None.
                - deposit_amount (float): The amount to invest in the product.
                                          Must be a positive number (int or float).
                                          Defaults to None.
                - invest_coin (str): The coin to invest in the product.
                - auto_compound_plan (str, optional): The auto-compound plan type for reinvesting
                                                      returns. Valid values are:
                                                      - 'NONE': No auto-compound (default)
                                                      - 'STANDARD': Standard auto-compound plan
                                                      - 'ADVANCED': Advanced auto-compound plan
                                                      Defaults to 'NONE'.

        Returns:
            Optional[dict]: A dictionary containing the subscription response from Binance's API
                          if the subscription is successful. The dictionary includes:
                           - positionId: Position ID of the subscription
                           - investCoin: Coin invested
                           - exercisedCoin: Coin to be exercised
                           - subscriptionAmount: Amount subscribed
                           - duration: Duration in days
                           - autoCompoundPlan: Auto-compound plan used
                           - strikePrice: Strike price of the option
                           - settleDate: Settlement date timestamp
                           - settleDateTime: Settlement date in human-readable format
                           - purchaseStatus: Current status of the purchase
                           - apr: Annual Percentage Rate
                           - orderId: Order ID
                           - purchaseTime: Purchase time timestamp
                           - purchaseDateTime: Purchase time in human-readable format
                           - optionType: Type of option (CALL or PUT)
                          
                          Returns None if:
                          - Any parameter validation fails
                          - An API error occurs during subscription
                          - Network or connection issues prevent the request

        Raises:
            None: This method catches all exceptions and logs them via the error handler.
                 It returns None instead of raising exceptions.

        Note:
            - All parameters are validated before making the API request
            - Invalid parameters are logged to the error handler if available
            - A timestamp is automatically added to the API request
            - Any API errors are caught, logged, and result in a None return value
        """

        result = None
        product_id = params.get('product_id', None) if isinstance(params, dict) else None
        order_id = params.get('order_id', None) if isinstance(params, dict) else None

        deposit_amount = (
            params.get('deposit_amount', None) if isinstance(params, dict) else None
        )

        auto_compound_plan = (
            params.get('auto_compound_plan', None) if isinstance(params, dict) else None
        )

        __auto_compound_plan_valid_values = ['NONE', 'STANDARD', 'ADVANCED']

        if not product_id or not isinstance(product_id, (str, int)):
            if self.__err_logger:
                __error_msg = 'Invalid product id provided for Dual Investment subscription.'
                self.__err_logger.error(__error_msg)
            return result

        if not order_id or not isinstance(order_id, (str, int)):
            if self.__err_logger:
                __error_msg = 'Invalid order_id provided for Dual Investment subscription.'
                self.__err_logger.error(__error_msg)
            return result

        if not isinstance(deposit_amount, (int, float)) or deposit_amount <= 0:
            if self.__err_logger:
                __error_msg = 'Invalid deposit_amount provided for Dual Investment subscription.'
                self.__err_logger.error(__error_msg)
            return result

        if auto_compound_plan is None:
            auto_compound_plan = 'NONE'

        if not auto_compound_plan\
            or not isinstance(auto_compound_plan, str)\
            or auto_compound_plan not in __auto_compound_plan_valid_values:

            if self.__err_logger:
                __error_msg = (
                    'Invalid auto_compound_plan provided for Dual Investment subscription.'
                )
                __error_msg += (
                    f' Valid values are: {", ".join(__auto_compound_plan_valid_values)}.'
                )
                self.__err_logger.error(__error_msg)
            return result

        __query_params = {
            'id': str(product_id),
            'orderId': str(order_id),
            'depositAmount': float(deposit_amount),
            'autoCompoundPlan': str(auto_compound_plan),
            'timestamp': int(time.time() * 1000)
        }

        try:
            __subscription_response = (
                self.__api_client.sapi_post_dci_product_subscribe(__query_params)
            )

            if __subscription_response is not None and isinstance(__subscription_response, dict):

                __settle_date = int(__subscription_response.get('settleDate', 0)) / 1000
                __settle_date_time = (
                    datetime.datetime.fromtimestamp(__settle_date)\
                        .strftime('%Y-%m-%d %H:%M:%S.%f')
                )

                __purchase_time = int(__subscription_response.get('purchaseTime', 0)) / 1000
                __purchase_date_time = (
                    datetime.datetime.fromtimestamp(__purchase_time)\
                        .strftime('%Y-%m-%d %H:%M:%S.%f')
                )


                result = {
                    "positionId": __subscription_response.get('positionId', ''),
                    "investCoin": __subscription_response.get('investCoin', ''),
                    "exercisedCoin": __subscription_response.get('exercisedCoin', ''),
                    "subscriptionAmount": __subscription_response.get('subscriptionAmount', ''),
                    "duration": __subscription_response.get('duration', ''),
                    "autoCompoundPlan": __subscription_response.get('autoCompoundPlan', ''),
                    "strikePrice": __subscription_response.get('strikePrice', ''),
                    "settleDate": __subscription_response.get('settleDate', ''),
                    "settleDateTime": __settle_date_time,
                    "purchaseStatus": __subscription_response.get('purchaseStatus', ''),
                    "apr": __subscription_response.get('apr', ''),
                    "orderId": __subscription_response.get('orderId', ''),
                    "purchaseTime": __subscription_response.get('purchaseTime', ''),
                    "purchaseDateTime": __purchase_date_time,
                    "optionType": __subscription_response.get('optionType', '')
                }

        except Exception as exc: # pylint: disable=broad-except
            __query_json = json.dumps(__query_params, sort_keys=False)
            __error_msg = 'Error subscribing to Dual Investment product on exchange'
            __error_msg += f' {self.__exchange}. query_params {__query_json}: {exc}'

            if self.__err_logger is not None:
                self.__err_logger.error(__error_msg)
            result = None

        return result

