# pylint: disable=too-many-lines
"""
Ccxao - cryptocurrency exchange algorithmic order
Client class: CcxaoClient

Author: Ricardo Marcelo Alvarez
Date: 2024-06-20
"""

import os
import json
import time
import base64
import struct
import errno
import select
import socket
import pprint # pylint: disable=unused-import
from typing import Any, Dict, List
import schema
from ccxao.ccxao_manage_orders import CcxaoManageOrders
import ccxao.ccxao_common_functions as ccf

class CcxaoClient:
    """
    CcxaoClient - cryptoCurrency Exchange Algorithmic Order Client
    ==============================================================
    
    Client interface to communicate with the ccxao daemon over a Unix domain socket.
    Requests are serialized to JSON, base64-encoded, signed, and verified for integrity.
    """

    def __init__(self, config_path: str = None):
        """
        CcxaoClient constructor
        =======================
        
        Initialize the client with configuration from a YAML file.

        Parameters:
        -----------
        config_path : str, optional
            Path to the configuration file. If None, uses default search paths.

        Returns:
        --------
        None
            This constructor does not return a value.

        Raises:
        -------
        ValueError
            If the configuration does not contain a valid 'ccxao_key'.
        """
        self.config_path = config_path or self.__get_default_config_path()
        self.config = self.__load_config()

        # Database configuration
        self.__socket_name = self.config.get('global', {}).get('socket_name', 'ccxao_daemon')
        self.__var_dir = self.config.get('global', {}).get('var_dir', '/var/ccxao-daemon')
        self.__ccxao_key = self.config.get('global', {}).get('ccxao_key')

        self.__sock_dir = os.path.join(self.__var_dir, 'socket')
        self.__socket_path = f'{self.__sock_dir}/{self.__socket_name}'

        if not self.__ccxao_key:
            raise ValueError("ccxao_key not found in configuration")

    def __get_default_config_path(self) -> str:
        """
        Get the default configuration file path.

        Returns:
        --------
        str
            Absolute path to the first existing configuration file among the defaults.

        Raises:
        -------
        FileNotFoundError
            If none of the default configuration paths exist.
        """
        default_paths = [
            '/etc/ccxao-daemon/ccxao-daemon.yaml',
            os.path.expanduser('~/.ccxao-daemon/ccxao-daemon.yaml'),
            'ccxao/.etc/ccxao-daemon.yaml'
        ]

        for path in default_paths:
            if os.path.exists(path):
                return path

        raise FileNotFoundError("No configuration file found in default locations")

    def __load_config(self) -> Dict[str, Any]:
        """
        Load configuration from YAML file.

        Returns:
        --------
        Dict[str, Any]
            Parsed configuration mapping loaded via ccxao_common_functions.load_config.

        Raises:
        -------
        ValueError
            If the configuration cannot be loaded or parsed.
        """
        try:
            return ccf.load_config(self.config_path)
        except Exception as e:
            raise ValueError(f"Failed to load configuration: {e}") from e

    def execute_command(self,
                        exchange: str=None,
                        command_name: str=None,
                        timeout: int = 320,
                        command_data: Any = None,
                        frame_bytes: int = 8192) -> dict | None:
        """Execute a command on the CCXAO server.

        This method sends a command to the CCXAO server and waits for a response.

        Parameters:
        -----------
        exchange : str
            The name of the exchange to target.
        command_name : str
            The name of the command to execute.
        timeout : int
            The maximum time to wait for a response (in seconds).
        command_data : Any
            Optional data to include with the command.
        frame_bytes : int
            The maximum number of bytes to send in a single frame.

        Returns:
        --------
        dict | None
            The response from the server, or None if an error occurred.
        """
        result = None

        if command_name not in CcxaoManageOrders.get_commands_func():
            return None

        __order_data = {
            'exchange': exchange,
            'command_name': command_name,
            'command_id': CcxaoManageOrders.generate_command_id(),
            'command_time': time.time_ns(),
            'command_data': command_data,
            'command_result': None,
            'status': 'NONE',
            'error_code': 0,
            'error_msg': '',
            'data': None
        }

        __raw = json.dumps(__order_data, separators=(',', ':'), ensure_ascii=False)
        __b64_raw = base64.b64encode(__raw.encode('utf-8')).decode('utf-8')
        __signature = CcxaoManageOrders.sign_command(self.__ccxao_key, __b64_raw.encode('utf-8'))
        __msg = (__b64_raw + CcxaoManageOrders.get_separator() + __signature).encode('utf-8')


        msg_len = struct.pack('>I', len(__msg))  # big-endian 4 bytes

        __msg_out = msg_len + __msg

        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            sock.connect(self.__socket_path)

            mv = memoryview(__msg_out)

            total = len(__msg_out)
            sent = 0
            while sent < total:
                end = sent + frame_bytes

                try:
                    n = sock.send(mv[sent:end])
                    if n == 0:
                        raise RuntimeError("Socket broken during send")
                    sent += n
                except (BlockingIOError, OSError) as e:
                    if getattr(e, "errno", None) in (errno.EAGAIN, errno.EWOULDBLOCK):
                        select.select([], [sock], [], timeout)
                        continue
                    raise

            raw_len = b''

            while len(raw_len) < 4:
                chunk = sock.recv(4 - len(raw_len))

                if not chunk:
                    return None
                raw_len += chunk

            msg_size = struct.unpack('>I', raw_len)[0]

            raw_data = b''
            while len(raw_data) < msg_size:
                chunk = sock.recv(min(4096, msg_size - len(raw_data)))

                if not chunk:
                    return None
                raw_data += chunk

            raw_data = raw_data.decode('utf-8')
            parts = raw_data.split(CcxaoManageOrders.get_separator())

            if len(parts) >= 2\
                and CcxaoManageOrders.verify_command_signature(self.__ccxao_key,
                                                               parts[0].encode('utf-8'),
                                                               parts[1]):

                result = json.loads(base64.b64decode(parts[0]).decode('utf-8'))

        return result

    def get_allowed_symbols_to_trade(self, exchange: str) -> List[str]:
        """
        Get the list of allowed symbols to trade for a specific exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').

        Returns:
        --------
        List[str]
            A list of allowed trading symbols.
        """

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_allowed_symbols_to_trade',
                                          command_data={})

        result = __res_data.get('command_result', []) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else []

        return result

    def get_balances(self, exchange: str) -> Dict[str, Any]:
        """
        Get account balances from the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').

        Returns:
        --------
        Dict[str, Any] or None
            The decoded JSON response containing balances if successful; otherwise None.
        """

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_balances',
                                          command_data={})
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0
        return result

    def get_usdt_balances(self, exchange: str) -> Dict[str, Any]:
        """
        Get account balances converted to USDT from the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').

        Returns:
        --------
        Dict[str, Any] or None
            The decoded JSON response containing USDT balances if successful; otherwise None.
        """

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_usdt_balances',
                                          command_data={})
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0
        return result

    def get_symbol_price_from_order_book(self,
                                         exchange: str,
                                         symbol: str,
                                         res_type: str='mid') -> float:
        """
        Get the current price for a symbol from the order book.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').
        res_type : str, optional
            Type of price to return: 'mid', 'bids', 'asks', or 'both'. Defaults to 'mid'.

        Returns:
        --------
        float
            The requested price type if successful; otherwise 0.0.
        """

        __command_params = {
            'symbol': symbol,
            'res_type': res_type
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_symbol_price_from_order_book',
                                          command_data=__command_params)
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0

        return result

    def get_order_book_for_symbol(self,
                                  exchange: str,
                                  symbol: str,
                                  num_results: int=5) -> Dict[str, Any]:
        """
        Get the order book for a specific symbol.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').
        num_results : int, optional
            Number of order book entries to return. Defaults to 5.

        Returns:
        --------
        Dict[str, Any] or None
            The decoded JSON response containing the order book if successful; otherwise None.
        """

        __command_params = {
            'symbol': symbol,
            'num_results': num_results
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_order_book_for_symbol',
                                          command_data=__command_params)
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0

        return result

    def is_symbol_active(self,
                         exchange: str,
                         symbol: str) -> bool:
        """
        Check if a trading symbol is active on the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        bool
            True if the symbol is active; otherwise False.
        """

        __command_params = {
            'symbol': symbol
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='is_symbol_active',
                                          command_data=__command_params)
        result = __res_data.get('command_result', False) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else False

        return result

    def amount_to_precision(self,
                            exchange: str,
                            symbol: str,
                            amount: float) -> float:
        """
        Convert an amount to the precision required by the exchange for a specific symbol.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').
        amount : float
            The amount to convert.

        Returns:
        --------
        float
            The amount rounded to the appropriate precision.
        """

        __command_params = {
            'symbol': symbol,
            'order_amount': amount
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='amount_to_precision',
                                          command_data=__command_params)
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0

        return result

    def price_to_precision(self,
                           exchange: str,
                           symbol: str,
                           price: float) -> float:
        """
        Convert a price to the precision required by the exchange for a specific symbol.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').
        price : float
            The price to convert.

        Returns:
        --------
        float
            The price rounded to the appropriate precision.
        """

        __command_params = {
            'symbol': symbol,
            'order_price': price
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='price_to_precision',
                                          command_data=__command_params)
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0

        return result

    def symbol_min_amount(self,
                          exchange: str,
                          symbol: str) -> float:
        """
        Get the minimum order amount for a specific trading pair on the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        float
            The minimum order amount for the symbol.
        """

        __command_params = {
            'symbol': symbol
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='symbol_min_amount',
                                          command_data=__command_params)
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0

        return result

    def symbol_min_cost(self,
                        exchange: str,
                        symbol: str) -> float:
        """
        Get the minimum order cost for a specific trading pair on the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        float
            The minimum order cost for the symbol.
        """

        __command_params = {
            'symbol': symbol
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='symbol_min_cost',
                                          command_data=__command_params)
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0

        return result

    def symbol_tick_size(self,
                         exchange: str,
                         symbol: str) -> float:
        """
        Get the tick size for a specific trading pair on the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        float
            The tick size for the symbol.
        """

        __command_params = {
            'symbol': symbol
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='symbol_tick_size',
                                          command_data=__command_params)
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0

        return result

    def queue_algo_order(self,
                         exchange: str,
                         order_symbol: str,
                         order_amount: float,
                         order_price_dir: str,
                         order_price_in: Any,
                         order_price_tp: Any,
                         order_price_sl: Any,
                         order_trailing_porc: float=None,
                         order_trailing_max_steps: int=None) -> Dict[str, Any]:
        """
        Queue an algorithmic order on the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        order_symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').
        order_amount : float
            Amount to trade.
        order_price_dir : str
            Price direction ('bull' or 'bear').
        order_price_in : Any
            Entry price ('current' or a specific float value).
        order_price_tp : Any
            Take profit price ('1%' or a specific float value).
        order_price_sl : Any
            Stop loss price ('1%' or a specific float value).
        order_trailing_porc : float, optional
            Trailing percentage for stop loss. Defaults to None.
        order_trailing_max_steps : int, optional
            Maximum steps for trailing stop. Defaults to None.

        Returns:
        --------
        Dict[str, Any] or None
            The decoded JSON response containing the queued algorithmic
            order details if successful; otherwise None.
        """

        __command_params = {
            'order_symbol': order_symbol,
            'order_amount': order_amount,
            'order_price_dir': order_price_dir,
            'order_price_in': order_price_in,
            'order_price_tp': order_price_tp,
            'order_price_sl': order_price_sl,
            'order_trailing_porc': order_trailing_porc,
            'order_trailing_max_steps': order_trailing_max_steps
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='queue_algo_order',
                                          command_data=__command_params)
        result = __res_data.get('command_result', None) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else None

        return result

    def get_algo_orders(self,
                        exchange: str,
                        skip_finished: bool=False) -> Dict[str, Any]:
        """
        Get the list of algorithmic orders for the specified exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        skip_finished : bool, optional
            Whether to skip finished orders. Defaults to False.

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the list of algorithmic
            orders if successful; otherwise an empty dictionary.
        """

        __command_params = {
            'skip_finished': skip_finished
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_algo_orders',
                                          command_data=__command_params)
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def get_algo_order(self,
                       exchange: str,
                       order_algo_id: str) -> Dict[str, Any]:
        """
        Get the details of a specific algorithmic order.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        order_algo_id : str
            The ID of the algorithmic order.

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the algorithmic order
            details if successful; otherwise an empty dictionary.
        """

        __command_params = {
            'order_algo_id': order_algo_id
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_algo_order',
                                          command_data=__command_params)
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def algo_order_finished(self,
                            exchange: str,
                            order_algo_id: str) -> bool:
        """
        Mark an algorithmic order as finished.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        order_algo_id : str
            The ID of the algorithmic order.

        Returns:
        --------
        bool
            True if the operation was successful; otherwise False.
        """

        __command_params = {
            'order_algo_id': order_algo_id
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='algo_order_finished',
                                          command_data=__command_params)
        result = __res_data.get('command_result', False) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else False

        return result


    def get_symbols_with_less_than_fee_maker(self,
                                             exchange: str,
                                             limit: float,
                                             quote_asset: str=None,
                                             base_asset: str=None) -> Dict[str, Any]:
        """
        Get symbols with maker fees less than the specified limit.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        limit : float
            The maximum maker fee percentage.
        quote_asset : str, optional
            Filter by quote asset. Defaults to None.
        base_asset : str, optional
            Filter by base asset. Defaults to None.

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the list of symbols
            with maker fees less than the limit if successful; otherwise an empty dictionary.
        """

        __command_params = {
            'limit': limit,
            'quote_asset': quote_asset,
            'base_asset': base_asset
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_symbols_with_less_than_fee_maker',
                                          command_data=__command_params)
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def get_symbols_with_less_than_fee_taker(self,
                                             exchange: str,
                                             limit: float,
                                             quote_asset: str=None,
                                             base_asset: str=None) -> Dict[str, Any]:
        """
        Get symbols with taker fees less than the specified limit.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        limit : float
            The maximum taker fee percentage.
        quote_asset : str, optional
            Filter by quote asset. Defaults to None.
        base_asset : str, optional
            Filter by base asset. Defaults to None.

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the list of symbols
            with taker fees less than the limit if successful; otherwise an empty dictionary.
        """

        __command_params = {
            'limit': limit,
            'quote_asset': quote_asset,
            'base_asset': base_asset
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_symbols_with_less_than_fee_taker',
                                          command_data=__command_params)
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def pass_all_assets_to_asset(self,
                                 exchange: str,
                                 dest_asset: str,
                                 exclude_assets: list[str]=None) -> bool:
        """
        Convert all assets to a specified destination asset.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        dest_asset : str
            The destination asset to convert all other assets into (e.g., 'USDT').
        exclude_assets : list[str], optional
            List of assets to exclude from conversion. Defaults to None.

        Returns:
        --------
        bool
            True if the operation was successful; otherwise False.
        """

        __command_params = {
            'dest_asset': dest_asset,
            'exclude_assets': exclude_assets
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='pass_all_assets_to_asset',
                                          command_data=__command_params)
        result = __res_data.get('command_result', False) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else False

        return result

    def balance_symbol(self,
                       exchange: str,
                       symbol: str,
                       proportion: float=0.5) -> Dict[str, Any]:
        """
        Get the balance information for a specific symbol.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            The trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the balance information
            for the specified symbol if successful; otherwise an empty dictionary.
        """

        __command_params = {
            'symbol': symbol,
            'proportion': proportion
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='balance_symbol',
                                          command_data=__command_params)

        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def get_trading_fees(self,
                         exchange: str) -> Dict[str, Any]:
        """
        Get the trading fees for the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the trading fees
            if successful; otherwise an empty dictionary.
        """

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_trading_fees',
                                          command_data={})
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def get_exchange_info(self, exchange: str) -> Dict[str, Any]:
        """
        Get the exchange information.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the exchange information
            if successful; otherwise an empty dictionary.
        """

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_exchange_info',
                                          command_data={})
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def get_exchange_tickers(self, exchange: str, symbol: str=None) -> Dict[str, Any]:
        """
        Get the list of exchange tickers available on the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str, optional
            Specific trading pair symbol to filter by (e.g., 'BTC/USDT'). Defaults to None.

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the exchange tickers
            if successful; otherwise an empty dictionary.
        """

        if symbol is not None and isinstance(symbol, str):
            __command_params = {
                'symbol': symbol
            }
        else:
            __command_params = {}

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_exchange_tickers',
                                          command_data=__command_params)

        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def get_markets(self,
                    exchange: str) -> Dict[str, Any]:
        """
        Get the list of markets available on the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the list of markets
            if successful; otherwise an empty dictionary.
        """

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_markets',
                                          command_data={})
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def get_symbol_price(self,
                         exchange: str,
                         symbol: str,
                         from_cache: bool=False) -> float:
        """
        Get the current price for a symbol.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').
        from_cache : bool, optional
            Whether to retrieve the price from cache. Defaults to False.

        Returns:
        --------
        float
            The current price of the symbol if successful; otherwise 0.0.
        """

        __command_params = {
            'symbol': symbol,
            'from_cache': from_cache
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_symbol_price',
                                          command_data=__command_params)
        result = __res_data.get('command_result', 0.0) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else 0.0

        return result

    def create_order(self,
                     exchange: str,
                     order_symbol: str,
                     order_side: str,
                     order_amount: float,
                     order_price: float,
                     order_type: str,
                     order_time_in_force: str=None,
                     order_params: Dict[str, Any]=None) -> Dict[str, Any]:
        """
        Create a new order on the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        order_symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').
        order_side : str
            Order side ('buy' or 'sell').
        order_amount : float
            Amount to trade.
        order_price : float
            Price at which to place the order.
        order_type : str
            Order type ('limit' or 'limit_maker').
        order_time_in_force : str, optional
            Time in force policy ('GTC', 'IOC', or 'FOK'). Defaults to None.
        order_params : Dict[str, Any], optional
            Additional parameters for the order. Defaults to None.

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the created order details
            if successful; otherwise an empty dictionary.
        """

        __command_params = {
            'order_symbol': order_symbol,
            'order_side': order_side,
            'order_amount': order_amount,
            'order_price': order_price,
            'order_type': order_type,
            'order_time_in_force': order_time_in_force,
            'order_params': order_params
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='create_order',
                                          command_data=__command_params)
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def create_orders(self,
                      exchange: str,
                      orders: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Create multiple orders on the exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        orders : List[Dict[str, Any]]
            A list of order dictionaries, each containing:
            - order_symbol (str): Trading pair symbol (e.g., 'BTC/USDT').
            - order_side (str): Order side ('buy' or 'sell').
            - order_amount (float): Amount to trade.
            - order_price (float): Price at which to place the order.
            - order_type (str): Order type ('limit' or 'limit_maker').
            - order_time_in_force (str, optional): Time in force policy ('GTC', 'IOC', or 'FOK').
            - order_params (Dict[str, Any], optional): Additional parameters for the order.

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the created orders details
            if successful; otherwise an empty dictionary.
        """

        __command_params = {
            'orders': orders
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='create_orders',
                                          command_data=__command_params)
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def get_order(self,
                  exchange: str,
                  order_id: Any,
                  order_symbol: str) -> Dict[str, Any]:
        """
        Get the details of a specific order.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        order_id : Any
            The ID of the order (str or int).
        order_symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the order details
            if successful; otherwise an empty dictionary.
        """

        __command_params = {
            'order_id': order_id,
            'order_symbol': order_symbol
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_order',
                                          command_data=__command_params)
        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def cancel_order(self,
                     exchange: str,
                     order_id: Any,
                     order_symbol: str) -> bool:
        """
        Cancel a specific order.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        order_id : Any
            The ID of the order (str or int).
        order_symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        bool
            True if the order was successfully canceled; otherwise False.
        """

        __command_params = {
            'order_id': order_id,
            'order_symbol': order_symbol
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='cancel_order',
                                          command_data=__command_params)
        result = __res_data.get('command_result', False) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else False

        return result

    def check_order_open(self,
                         exchange: str,
                         order_id: Any,
                         order_symbol: str) -> bool:
        """
        Check if a specific order is open.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        order_id : Any
            The ID of the order (str or int).
        order_symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        bool
            True if the order is open; otherwise False.
        """

        __command_params = {
            'order_id': order_id,
            'order_symbol': order_symbol
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='check_order_open',
                                          command_data=__command_params)
        result = __res_data.get('command_result', False) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else False

        return result

    def get_order_status(self,
                         exchange: str,
                         order_id: Any,
                         order_symbol: str) -> str:
        """
        Get the status of a specific order.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        order_id : Any
            The ID of the order (str or int).
        order_symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        str
            The status of the order (e.g., 'open', 'closed', 'canceled').
        """

        __command_params = {
            'order_id': order_id,
            'order_symbol': order_symbol
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_order_status',
                                          command_data=__command_params)
        result = __res_data.get('command_result', '') if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else ''

        return result

    def get_orders(self,
                   exchange: str,
                   symbol: str=None,
                   order_status: Any=None,
                   from_api: bool=False) -> Dict[str, Any]:
        """
        Get a list of orders for a specific exchange.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        order_status : Any
            The status of the orders to retrieve (e.g., 'open', 'closed').
        from_api : bool
            Whether to retrieve the orders from the API or use cached data.

        Returns:
        --------
        Dict[str, Any]
            A dictionary containing the list of orders and their details.
        """

        __command_params = {
            'symbol': symbol,
            'order_status': order_status,
            'from_api': from_api
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='get_orders',
                                          command_data=__command_params)

        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else {}

        return result

    def sell_total_asset(self,
                         exchange: str,
                         symbol: str) -> bool:
        """
        Sell the total amount of a specific asset.

        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        symbol : str
            Trading pair symbol (e.g., 'BTC/USDT').

        Returns:
        --------
        bool
            True if the operation was successful; otherwise False.
        """

        __command_params = {
            'symbol': symbol
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='sell_total_asset',
                                          command_data=__command_params)
        result = __res_data.get('command_result', False) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else False

        return result

    def dual_investment_get_products(self,
                                     exchange: str,
                                     option: str=None,
                                     asset: str=None,
                                     quote: str=None,
                                     max_duration_days: int=None,
                                     min_apr: float=None,
                                     max_page_index: int=None) -> List[dict]:
        """
        Get dual investment products based on specified filters.
        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        option : str, optional
            The investment option filter. Defaults to None.
        asset : str, optional
            The asset filter. Defaults to None.
        quote : str, optional
            The quote currency filter. Defaults to None.
        max_duration_days : int, optional
            The maximum duration in days filter. Defaults to None.
        min_apr : float, optional
            The minimum annual percentage rate filter. Defaults to None.
        max_page_index : int, optional
            The maximum page index filter. Defaults to None.
        Returns:
        --------
        List[dict]
            A list of dual investment products matching the filters.
        """
        __command_params = {
            'option': option,
            'asset': asset,
            'quote': quote,
            'max_duration_days': max_duration_days,
            'min_apr': min_apr,
            'max_page_index': max_page_index
        }


        __raw = json.dumps(__command_params, separators=(',', ':'), ensure_ascii=False)
        __raw = __raw.encode('utf-8')
        __hex_raw = __raw.hex()

        __command_params = {
            'params': __hex_raw
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='dual_investment_get_products',
                                          command_data=__command_params)
        result = __res_data.get('command_result', []) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else False

        return result

    def dual_investment_get_positions(self,
                                      exchange: str,
                                      status: str=None,
                                      product_id: str | int | None=None,
                                      order_id: str | int | None=None) -> List[dict]:
        """
        Get dual investment positions based on specified status.
        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        status : str, optional
            The position status filter. Defaults to None.
        product_id : str | int, optional
            The product ID to filter positions. Defaults to None.
        order_id : str | int, optional
            The order ID to filter positions. Defaults to None.
        Returns:
        --------
        List[dict]
            A list of dual investment positions matching the status.
        """
        __command_params = {
            'status': status,
            'product_id': product_id,
            'order_id': order_id
        }

        __raw = json.dumps(__command_params, separators=(',', ':'), ensure_ascii=False)
        __raw = __raw.encode('utf-8')
        __hex_raw = __raw.hex()

        __command_params = {
            'params': __hex_raw
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='dual_investment_get_positions',
                                          command_data=__command_params)
        result = __res_data.get('command_result', []) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else False

        return result

    def dual_investment_subscribe_product(self,
                                          exchange: str,
                                          product_id: str=None,
                                          order_id: str=None,
                                          deposit_amount: float=0.0,
                                          invest_coin: str=None,
                                          auto_compound_plan: str='NONE') -> Dict[str, Any]:
        """
        Subscribe to a dual investment product.
        Parameters:
        -----------
        exchange : str
            The name of the exchange (e.g., 'binance').
        product_id : str
            The ID of the dual investment product.
        order_id : str
            The order ID for the subscription.
        deposit_amount : float
            The amount to deposit for the subscription.
        invest_coin : str, optional
            The coin to invest. Defaults to None.
        auto_compound_plan : str, optional
            The auto-compound plan. Defaults to 'NONE'.
        Returns:
        --------
        Dict[str, Any]
            The decoded JSON response containing the subscription details
            if successful; otherwise an empty dictionary.
        """
        result = None

        __command_params = {
            'product_id': product_id,
            'order_id': order_id,
            'deposit_amount': deposit_amount,
            'invest_coin': invest_coin,
            'auto_compound_plan': auto_compound_plan
        }

        __raw = json.dumps(__command_params, separators=(',', ':'), ensure_ascii=False)
        __raw = __raw.encode('utf-8')
        __hex_raw = __raw.hex()

        __command_params = {
            'params': __hex_raw
        }

        __res_data = self.execute_command(exchange=exchange,
                                          command_name='dual_investment_subscribe_product',
                                          command_data=__command_params)

        result = __res_data.get('command_result', {}) if isinstance(__res_data, dict)\
            and 'command_result' in __res_data else False
        return result

    @classmethod
    def get_commands_schemas(cls):
        """
        Get the schemas for all supported commands.

        Returns:
            dict: Mapping of command names to their parameter schemas.
        """
        schemas = {}

        # Comandos sin parámetros
        __no_params_cmd = [
            'get_balances',
            'get_usdt_balances',
            'get_trading_fees',
            'get_exchange_info',
            'get_markets',
            'get_allowed_symbols_to_trade',
            'stop'
        ]

        for cmd in __no_params_cmd:
            schemas[cmd] = {}

        schemas['get_exchange_tickers'] = {
            schema.Optional('symbol'): str
        }

        # Precios
        schemas['get_symbol_price'] = {
            'symbol': str,
            schema.Optional('from_cache'): bool
        }

        schemas['get_symbol_price_from_order_book'] = {
            'symbol': schema.Or(str),
            schema.Optional('res_type'): str  # p.e. 'mid', 'bids', 'asks', 'both'
        }

        schemas['get_order_book_for_symbol'] = {
            'symbol': str,
            schema.Optional('num_results'): int
        }

        # Órdenes spot
        schemas['create_order'] = {
            'order_symbol': str,
            'order_side': str,  # 'buy' | 'sell'
            'order_amount': schema.Or(float, int),
            'order_price': schema.Or(float, int),
            'order_type': str,     # 'limit' | 'limit_maker'
            schema.Optional('order_time_in_force'): str,  # 'GTC' | 'IOC' | 'FOK'
            schema.Optional('order_params'): dict
        }

        schemas['create_orders'] = {
            schema.Optional('orders'): list
        }

        schemas['get_order'] = {
            'order_id': schema.Or(str, int),
            'order_symbol': str
        }

        schemas['cancel_order'] = {
            'order_id': schema.Or(str, int),
            'order_symbol': str
        }

        schemas['check_order_open'] = {
            'order_id': schema.Or(str, int),
            'order_symbol': str
        }

        schemas['get_order_status'] = {
            'order_id': schema.Or(str, int),
            'order_symbol': str
        }

        schemas['get_orders'] = {
            'symbol': str,
            schema.Optional('order_status'): schema.Or(str, int),
            schema.Optional('from_api'): bool
        }

        schemas['sell_total_asset'] = {
            'symbol': str
        }

        # Órdenes algorítmicas
        schemas['queue_algo_order'] = {
            'order_symbol': str,
            'order_amount': schema.Or(float, int),
            'order_price_dir': str,             # 'bull' | 'bear'
            'order_price_in': schema.Or(str, float, int),  # 'current' | float
            'order_price_tp': schema.Or(str, float, int),  # '1%' | float
            'order_price_sl': schema.Or(str, float, int),  # '1%' | float
            schema.Optional('order_trailing_porc'): schema.Or(float, int),
            schema.Optional('order_trailing_max_steps'): int
        }

        schemas['get_algo_order'] = {
            'order_algo_id': str
        }

        schemas['get_algo_orders'] = {
            schema.Optional('skip_finished'): bool
        }

        schemas['algo_order_finished'] = {
            'order_algo_id': str
        }

        # Utilidades / validaciones varias
        schemas['get_symbols_with_less_than_fee_maker'] = {
            'limit': schema.Or(float, int),
            schema.Optional('quote_asset'): str,
            schema.Optional('base_asset'): str
        }

        schemas['get_symbols_with_less_than_fee_taker'] = {
            'limit': schema.Or(float, int),
            schema.Optional('quote_asset'): str,
            schema.Optional('base_asset'): str
        }

        schemas['pass_all_assets_to_asset'] = {
            'dest_asset': str,
            schema.Optional('exclude_assets'): list[str]

        }

        schemas['balance_symbol'] = {
            'symbol': str,
            'proportion': schema.Or(float, None)
        }

        schemas['is_symbol_active'] = {
            'symbol': str
        }

        schemas['amount_to_precision'] = {
            'symbol': str,
            'order_amount': schema.Or(float, int)
        }

        schemas['price_to_precision'] = {
            'symbol': str,
            'order_price': schema.Or(float, int)
        }

        schemas['symbol_min_amount'] = {
            'symbol': str
        }

        schemas['symbol_min_cost'] = {
            'symbol': str
        }

        schemas['symbol_tick_size'] = {
            'symbol': str
        }

        schemas['dual_investment_get_products'] = {
            schema.Optional('option'): str,
            'asset': str,
            'quote': str,
            schema.Optional('max_duration_days'): int,
            schema.Optional('min_apr'): schema.Or(float, int),
            schema.Optional('max_page_index'): int
        }

        schemas['dual_investment_get_positions'] = {
            schema.Optional('product_id'): schema.Or(str, int),
            schema.Optional('status'): str,
            schema.Optional('order_id'): schema.Or(str, int)
        }

        schemas['dual_investment_subscribe_product'] = {
            schema.Optional('product_id'): schema.Or(str, int),
            schema.Optional('order_id'): schema.Or(str, int),
            'deposit_amount': schema.Or(float, int),
            schema.Optional('invest_coin'): schema.Or(str, None),
            schema.Optional('auto_compound_plan'): schema.Or(str, None)
        }

        return schemas

    @classmethod
    def check_params_structure(cls, command, params):
        """
        check_params_structure
        ======================
        Validates the structure of 'params' for each supported command.
        - For some commands, no parameters are expected (params must be None).
        - For others, a minimal subset of keys and types is validated, following
        the same logic used here (basic types with Or(..., None) when applicable).
        Parameters:
        -----------
        command : str
            The command name to validate parameters for.
        params : dict or None
            The parameters to validate.
        Returns:
        --------
        bool
            True if the parameters structure is valid for the command; otherwise False.
        """

        schemas = cls.get_commands_schemas()

        if command not in schemas:
            return False

        schema_st = schema.Schema(schemas[command])

        if command == 'create_orders':
            if schema_st.is_valid(params):
                __orders = params.get('orders', [])
                __order_schema = {
                    'order_symbol': str,
                    'order_side': str,
                    'order_amount': float,
                    'order_price': float,
                    'order_type': str,
                    schema.Optional('order_params'): schema.Or(str, None)
                }

                __order_schema = schema.Schema(__order_schema)

                if isinstance(__orders, list):
                    result = True
                    for __order in __orders:
                        result = result and __order_schema.is_valid(__order)
                    return result

        elif command == 'stop':
            return True

        else:
            return schema_st.is_valid(params)

        return False
