# pylint: disable=too-many-lines, too-many-statements
"""
Ccxao - Cryptocurrency Exchange Algorithmic Order
=================================================
Binance Order Management
------------------------

This module handles order management for the Binance exchange using the FIX protocol.
It provides functionalities to create, cancel, and query orders.

Author: Ricardo Marcelo Alvarez
Date: 2024-06-20
"""
# pylint: disable=unused-import

import sys
import time
import datetime
import base64
import json
import urllib
from copy import deepcopy
import logging
import logging.handlers
import threading
from typing import Callable, Any
import pprint
import websocket
import pytz

import cryptography.hazmat.primitives.serialization as chps # pylint: disable=unused-import
import binance_fix_connector.fix_connector as fix_connector
# import create_order_entry_session

import ccxao.ccxao_common_functions as ccf # pylint: disable=unused-import

class CcxaoBinanceManageOrders():
    """
    Manages order operations for Binance via FIX and WebSocket APIs.

    This class provides a high-level interface to interact with Binance,
    handling session management, order creation, cancellation, and status
    tracking. It uses the FIX protocol for order entry and WebSocket for
    real-time updates.

    Attributes:
        api_key (str): The API key for Binance.
        api_secret (str): The API secret for Binance.
        sandbox (bool): Whether to use the sandbox environment.
        on_message (Callable): Callback function for WebSocket messages.
        time_to_purge_orders (int): Time in seconds to keep closed orders.
        debug (bool): Enables debug logging.
        log_handler (logging.Logger): Custom logger for info messages.
        err_handler (logging.Logger): Custom logger for error messages.
    """
    # pylint: disable=arguments-renamed, no-member, unused-variable, unused-private-member
    def __init__(self,
                 api_key: str=None,
                 api_secret: str=None,
                 sandbox: bool=False,
                 on_message: Callable[[Any, str], None]=None,
                 time_to_purge_orders: int=1800,
                 debug: bool=False,
                 log_handler: logging.Logger=None,
                 err_handler: logging.Logger=None):

        self.__debug = False
        self.__log_logger = None
        self.__err_logger = None
        self.__debug = debug
        self.__exchange = 'binance'
        self.__ord_status = None
        self.__ord_status_inv = None
        self.__ord_types = None
        self.__ord_types_inv = None
        self.__ord_sides = None
        self.__ord_sides_inv = None
        self.__time_in_force = None
        self.__time_in_force_inv = None
        self.__ord_reject_reason = None
        self.__ord_statuses = None
        self.__execution_report_struct = None

        self.__log_handler = log_handler
        self.__err_handler = err_handler

        self.__time_sleep = 0.05
        self.__client_oe = None
        self.__client_dc = None
        self.__ws = None
        self.__fix_thread = None
        self.__ws_th_thread = None
        self.__ws_thread = None
        self.__client_conn_uuid = None
        self.__run_daemon = False
        self.__run_daemon_lock = threading.Lock()

        self.__last_ping_checked = time.time()
        self.__limit_ping_time = 32

        self.__orders = {}
        self.__orders_lock = threading.Lock()

        self.__ws_lock = threading.Lock()
        self.__ws_response_data = {}
        self.__ws_is_connected = False
        self.__ws_reload = False
        self.__ws_on_message = on_message

        self.__api_key = api_key
        self.__api_secret = api_secret
        self.__time_to_purge_orders = time_to_purge_orders
        self.__sender_comp_id_dc = f'_{ccf.random_string(4)}'
        self.__sender_comp_id_oe = f'_{ccf.random_string(4)}'
        self.__target_comp_id = 'SPOT'
        self.__response_mode = 1

        self.__fix_oe_url = 'tcp+tls://fix-oe.binance.com:9000'
        self.__ws_url = 'wss://ws-api.binance.com:9443/ws-api/v3'
        # self.__ws_url = 'wss://stream.binance.com:9443'

        if sandbox:
            self.__fix_oe_url = 'tcp+tls://fix-oe.testnet.binance.vision:9000'
            self.__ws_url = 'wss://ws-api.testnet.binance.vision/ws-api/v3'

        self.__init_consts()

        self.__private_key = chps.load_pem_private_key(self.__api_secret.encode('ASCII'),
                                                       password=None)

    def __init_consts(self):
        # Response types
        self.__ord_status = {
            'NEW': '0',
            'PARTIALLY_FILLED': '1',
            'FILLED': '2',
            'CANCELED': '4',
            'PENDING_CANCEL': '6',
            'REJECTED': '8',
            'PENDING_NEW': 'A',
            'EXPIRED': 'C'
        }

        self.__ord_status_inv = {v: k for k, v in self.__ord_status.items()}

        self.__ord_statuses = {
            '0': 'open',
            '1': 'open',
            '2': 'closed',
            '4': 'canceled',
            '6': 'open',
            '8': 'rejected',
            'A': 'open',
            'C': 'expired'
        }

        # ord_types = {"1": "MARKET", "2": "LIMIT", "3": "STOP", "4": "STOP_LIMIT"}
        self.__ord_types = {
            '1': 'market',
            '2': 'limit',
            '3': 'stop',
            '4': 'stop_limit'
        }

        self.__ord_types_inv = {v: k for k, v in self.__ord_types.items()}

        # sides = {"1": "BUY", "2": "SELL"}
        self.__ord_sides = {
            '1': 'buy',
            '2': 'sell'
        }

        self.__ord_sides_inv = {v: k for k, v in self.__ord_sides.items()}

        self.__time_in_force = {
            '1': 'GTC',
            '2': 'IOC',
            '3': 'FOK'
        }

        self.__time_in_force_inv = {v: k for k, v in self.__time_in_force.items()}

        self.__ord_reject_reason = {
            '99': 'OTHER'
        }

        self.__ord_reject_reason_inv = {v: k for k, v in self.__ord_reject_reason.items()}

        self.__execution_report_struct = {
            '37': 'id',
            '11': 'clientOrderId',
            '151': 'remaining',
            '25018': 'timestamp',
            # '60': 'lastTradeTimestamp',
            '1057': 'postOnly',
            '39': 'status',
            '55': 'symbol',
            '40': 'type',
            '59': 'timeInForce',
            '54': 'side',
            '44': 'price',
            '25017': 'cost',
            # '': 'average',
            '38': 'amount',
            '14': 'filled',
            # '': 'trades',
            # '': 'fee',
            '17': 'execid',
            '41': 'OrigClOrdID',
            '18': 'ExecInst'
        }

        self.__execution_report_error = {
            '25016': 'error_code',
            '58': 'error_msg'
        }

    def __create_fix_session(self):
        if not self.__debug:
            self.__redirect_logs_to_null()

        self.__client_oe = (
            fix_connector.create_order_entry_session(api_key=self.__api_key,
                                                     private_key=self.__private_key,
                                                     sender_comp_id=self.__sender_comp_id_oe,
                                                     target_comp_id=self.__target_comp_id,
                                                     endpoint=self.__fix_oe_url,
                                                     response_mode=self.__response_mode)
        )


        if self.__log_handler is not None\
            and isinstance(self.__log_handler, logging.Logger)\
            and self.__err_handler is not None\
            and isinstance(self.__err_handler, logging.Logger):


            self.__redirect_logs()
        else:
            if not self.__debug:
                self.__redirect_logs_to_null()

    def start(self):
        """
        Initializes and starts the FIX and WebSocket connections.

        This method establishes the FIX session and logs in. Once connected,
        it starts background threads to handle incoming FIX messages and
        maintain the WebSocket connection for real-time data streams.
        """

        self.__create_fix_session()
        __is_logged = False

        while not __is_logged:
            time.sleep(9)
            __msgs = self.__client_oe.get_all_new_messages_received()
            if isinstance(__msgs, list) and len(__msgs) > 0:
                for __msg_i in __msgs:
                    __msg_type = 35
                    __msg = None if not __msg_i.get(__msg_type)\
                        else str(__msg_i.get(__msg_type).decode("utf-8"))

                    if __msg is not None:
                        if __msg == 'A':
                            __msg_type = 25037
                            __msg = None if not __msg_i.get(__msg_type)\
                                else str(__msg_i.get(__msg_type).decode("utf-8"))

                            self.__client_conn_uuid = __msg
                            __is_logged = True

                        elif __msg == '3':
                            __msg_type = 25016
                            __msg = None if not __msg_i.get(__msg_type)\
                                else str(__msg_i.get(__msg_type).decode("utf-8"))
                            __error_code = __msg

                            __msg_type = 58
                            __msg = None if not __msg_i.get(__msg_type)\
                                else str(__msg_i.get(__msg_type).decode("utf-8"))
                            __error_msg = __msg

                            __error_out = f'The exchange {self.__exchange} fix api '
                            __error_out += f'connection failed code: {__error_code} '
                            __error_out += f'msg: {__error_msg}'
                            raise Exception(__error_out) # pylint: disable=broad-exception-raised

                        # if __msg_i:
                        #     data = self.fix_msg_to_dict(__msg_i)
                        #     pprint.pprint(data, sort_dicts=False)


            __msgs = self.__client_oe.get_all_new_messages_received()
            if isinstance(__msgs, list) and len(__msgs) > 0:
                for __msg_i in __msgs:
                    __msg_type = 35
                    __msg = None if not __msg_i.get(__msg_type)\
                        else str(__msg_i.get(__msg_type).decode("utf-8"))

                    if __msg is not None:
                        if __msg == 'A':
                            __msg_type = 25037
                            __msg = None if not __msg_i.get(__msg_type)\
                                else str(__msg_i.get(__msg_type).decode("utf-8"))

                            self.__client_conn_uuid = __msg
                            __is_logged = True

                        elif __msg == '3':
                            __msg_type = 25016
                            __msg = None if not __msg_i.get(__msg_type)\
                                else str(__msg_i.get(__msg_type).decode("utf-8"))
                            __error_code = __msg

                            __msg_type = 58
                            __msg = None if not __msg_i.get(__msg_type)\
                                else str(__msg_i.get(__msg_type).decode("utf-8"))
                            __error_msg = __msg

                            __error_out = f'The exchange {self.__exchange} fix api '
                            __error_out += f'connection failed code: {__error_code} '
                            __error_out += f'msg: {__error_msg}'
                            raise Exception(__error_out) # pylint: disable=broad-exception-raised

                        # if __msg_i:
                        #     data = self.fix_msg_to_dict(__msg_i)
                        #     pprint.pprint(data, sort_dicts=False)

        if __is_logged:
            with self.__run_daemon_lock:
                self.__run_daemon = True

            self.__fix_thread = threading.Thread(target=self.__messages_reader_th,
                                                 name=f'ccxao_bmo_{self.__exchange}__thread')

            self.__fix_thread.start()

        __ws_name = f'ccxao_{self.__exchange}__launch_websocket__binance_manage_orders__thread'
        self.__ws_thread = (
            threading.Thread(target=self.__launch_ccxao_websocket_thread,
                             name=__ws_name)
        )

        self.__ws_thread.start()
        time.sleep(9)

        self.__ws_th_thread = (
            threading.Thread(target=self.__ws_th,
                             name=f'ccxao_bmo_{self.__exchange}__ws_th__thread')
        )

        self.__ws_th_thread.start()

        __time_out = 400
        __time_ini = time.time()
        __time_diff = 0

        __conn_status = False
        while not __conn_status and __time_diff < __time_out:
            __conn_status = self.__ws_check_conn_status()
            __time_diff = time.time() - __time_ini

        time.sleep(1)

    def stop(self):
        """
        Stops the connections and cleans up resources.

        Logs out from the FIX session, stops all running background threads,
        and disconnects the FIX and WebSocket clients.
        """
        self.__client_oe.logout()
        # self.__client_dc.logout()
        time.sleep(9)
        with self.__run_daemon_lock:
            self.__run_daemon = False

        if self.__fix_thread is not None:
            self.__fix_thread.join(400)

        time.sleep(1)
        self.__client_oe.disconnect()
        # self.__client_dc.disconnect()

        if self.__ws_th_thread is not None:
            self.__ws_th_thread.join(400)

        self.__ws.close()

        if self.__ws_thread is not None:
            self.__ws_thread.join(400)

    def __launch_ccxao_websocket_thread(self):
        """
        Initializes and starts the WebSocket client thread.

        This method sets up the WebSocket connection for real-time communication
        with the exchange. It configures handlers for open, close, and message
        events and runs the client in a perpetual loop with reconnection logic.
        """
        websocket.enableTrace(self.__debug)
        self.__ws = websocket.WebSocketApp(self.__ws_url,
                                           on_open=self.__ws_on_open_handler,
                                           on_close=self.__ws_on_close_handler,
                                           on_reconnect=self.__ws_on_reconnect_handler,
                                           on_message=self.__ws_message_handler)

        self.__ws.run_forever(reconnect=320)

    def __purge_old_orders(self):

        __total_orders = {}
        with self.__orders_lock:
            __total_orders = deepcopy(self.__orders)

        __to_drop = []
        __current_time = time.time()
        for cl_order_id, order_data in __total_orders.items():
            __time_diff = __current_time - order_data.get('last_update_unixtime', time.time())
            if __time_diff > self.__time_to_purge_orders:
                __to_drop.append(cl_order_id)

        with self.__orders_lock:
            for cl_order_id in __to_drop:
                self.__orders.pop(cl_order_id, None)

    def __messages_reader_th(self):
        result = False

        __to_run = True
        __time_purge_freq = 300
        __time_purge_last = 0

        while __to_run:
            # print(f'self.__client_conn_uuid: {self.__client_conn_uuid}')
            # print(f'__to_run: {__to_run}')

            with self.__run_daemon_lock:
                __to_run = self.__run_daemon

            __total_orders = {}

            if __to_run:

                if time.time() - __time_purge_last > __time_purge_freq:
                    self.__purge_old_orders()
                    __time_purge_last = time.time()

                with self.__orders_lock:
                    __total_orders = deepcopy(self.__orders)

                __total_new_messages = self.__client_oe.get_all_new_messages_received()

                if isinstance(__total_new_messages, list) and len(__total_new_messages) > 0:

                    for __msg_i in __total_new_messages:
                        # self.print_fix_msg(__msg_i)
                        __msg_type = 35
                        __msg = None if not __msg_i.get(__msg_type)\
                            else str(__msg_i.get(__msg_type).decode("utf-8"))

                        if __msg is not None:
                            if str(__msg) == '0' or str(__msg) == '1':
                                self.__last_ping_checked = time.time()
                                # self.print_fix_msg(__msg_i)
                            elif __msg == '8': # ExecutionReport
                                __msg_type = 150
                                __msg = None if not __msg_i.get(__msg_type)\
                                    else str(__msg_i.get(__msg_type).decode("utf-8"))

                                if __msg in ['0', '4', '5', '8', 'C', 'F']: # NEW
                                    __cl_order_id = None if not __msg_i.get(11)\
                                        else str(__msg_i.get(11).decode("utf-8"))

                                    if __cl_order_id is not None\
                                        and __cl_order_id in __total_orders:

                                        __order = self.get_order_skel()

                                        __str_values = ['id',
                                                        'symbol',
                                                        'clientOrderId',
                                                        'error_msg']

                                        __float_values = ['price',
                                                          'amount',
                                                          'cost',
                                                          'average',
                                                          'filled',
                                                          'remaining']

                                        __int_values = ['lastTradeTimestamp',
                                                        'error_code']

                                        __dict_values = ['type',
                                                         'timeInForce',
                                                         'side',
                                                         'status']

                                        __other_values = []

                                        __datetime_values = ['timestamp']
                                        __bool_values = ['postOnly']

                                        for __m_type, __k_value\
                                            in self.__execution_report_struct.items():
                                            __msg_value = None if not __msg_i.get(__m_type)\
                                                else __msg_i.get(__m_type).decode("utf-8")
                                            if __msg_value is not None:
                                                if __k_value in __str_values:

                                                    __order[__k_value] = (
                                                        str(__msg_value)
                                                    )

                                                elif __k_value in __float_values:
                                                    __order[__k_value] = float(__msg_value)
                                                elif __k_value in __int_values:
                                                    __order[__k_value] = int(__msg_value)
                                                elif __k_value in __datetime_values:
                                                    __v_out = datetime.datetime\
                                                        .strptime(str(__msg_value),
                                                                '%Y%m%d-%H:%M:%S.%f')
                                                    __v_out = int(__v_out.timestamp() * 1000)
                                                    __order[__k_value] = __v_out

                                                    __order['lastUpdateTimestamp'] = __v_out
                                                    __order['lastTradeTimestamp'] = __v_out

                                                    __order_time = round((float(__v_out)/1000), 3)
                                                    __order['datetime'] = (
                                                        datetime.datetime\
                                                            .fromtimestamp(__order_time)\
                                                                .replace(tzinfo=pytz.utc)\
                                                                    .isoformat(
                                                                        timespec='milliseconds')
                                                    ).replace('+00:00', 'Z')

                                                elif __k_value in __bool_values:
                                                    if __k_value == 'postOnly':
                                                        __order[__k_value] = False

                                                elif __k_value in __dict_values:
                                                    if __k_value == 'type':
                                                        __order[__k_value] = (
                                                            self.__ord_types.get(str(__msg_value),
                                                                                None)
                                                        )
                                                    elif __k_value == 'timeInForce':
                                                        __order[__k_value] = (
                                                            self.__time_in_force\
                                                                .get(str(__msg_value), None)
                                                        )
                                                    elif __k_value == 'side':
                                                        __order[__k_value] = (
                                                            self.__ord_sides.get(str(__msg_value),
                                                                                None)
                                                        )
                                                    elif __k_value == 'status':
                                                        __order[__k_value] = (
                                                            self.__ord_statuses\
                                                                .get(str(__msg_value), None)
                                                        )

                                        for __m_type, __k_value\
                                            in self.__execution_report_error.items():
                                            __msg_value = None if not __msg_i.get(__m_type)\
                                                else __msg_i.get(__m_type).decode("utf-8")

                                            if __msg_value is not None:
                                                if __k_value in __str_values:
                                                    __order[__k_value] = str(__msg_value)
                                                elif __k_value in __float_values:
                                                    __order[__k_value] = float(__msg_value)
                                                elif __k_value in __int_values:
                                                    __order[__k_value] = int(__msg_value)

                                        if __cl_order_id is not None:
                                            with self.__orders_lock:
                                                __current_time = round(time.time(), 3)
                                                __current_datetime = (
                                                    datetime.datetime\
                                                        .fromtimestamp(__current_time)\
                                                            .isoformat(timespec='milliseconds')
                                                )

                                                __order_out = None
                                                __init_unixtime = 0
                                                __init_datetime = (
                                                    datetime.datetime\
                                                        .fromtimestamp(__init_unixtime)\
                                                            .isoformat(timespec='milliseconds')
                                                )

                                                if self.__orders[__cl_order_id] is None:
                                                    __init_unixtime = __current_time
                                                    __init_datetime = __current_datetime
                                                else:
                                                    __init_unixtime = (
                                                        self.__orders[__cl_order_id]\
                                                            .get('init_unixtime', __init_unixtime)
                                                    )
                                                    __init_datetime = (
                                                        self.__orders[__cl_order_id]\
                                                            .get('init_datetime', __init_datetime)
                                                    )

                                                __order_out = {
                                                    'order': __order,
                                                    'fix_request': __total_orders[__cl_order_id]\
                                                        .get('fix_request', None),
                                                    'input_symbol': __total_orders[__cl_order_id]\
                                                        .get('input_symbol', None),
                                                    'init_unixtime': __init_unixtime,
                                                    'init_datetime': __init_datetime,
                                                    'last_update_unixtime': __current_time,
                                                    'last_update_datetime': __current_datetime,
                                                }

                                                self.__orders[__cl_order_id] = __order_out

                                    # raise Exception(__error_out) # pylint: disable=broad-exception-raised

            time.sleep(self.__time_sleep)

        return result

    def __ws_th(self):
        result = False

        __max_time_to_check = 300
        __last_time_check = 0

        __to_run = True

        if not self.__ws_check_conn_status():
            self.__ws_start()

        ws_reload = False

        while __to_run:
            if not self.__ws_ping():
                __last_time_check = 0
            time.sleep(5)
            with self.__ws_lock:
                ws_reload = self.__ws_reload
                self.__ws_reload = False

            if ws_reload:
                __last_time_check = 0
                ws_reload = False

            __time_diff = time.time() - __last_time_check
            if __time_diff > __max_time_to_check:
                if not self.__ws_check_conn_status():
                    self.__ws_stop()
                    time.sleep(1)
                    self.__ws_start()
                __last_time_check = time.time()

            with self.__run_daemon_lock:
                __to_run = self.__run_daemon
            time.sleep(23)

        if self.__ws_check_conn_status():
            self.__ws_stop()

        return result

    def __ws_on_open_handler(self, _):
        result = True

        return result

    def __ws_on_close_handler(self, _, close_status_code, close_msg):

        if close_status_code is not None or close_msg is not None:
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in {__l_function}, close_status_code: {close_status_code}'
            err_msg += f', close_msg: {close_msg}'

            if self.__err_logger is not None:
                self.__err_logger.error(err_msg)

    def __ws_on_reconnect_handler(self, _):
        result = True

        return result

    def __ws_message_handler(self, _, message):
        """
        Handles incoming WebSocket messages.

        This method processes messages from the WebSocket stream. It parses
        JSON messages, identifies them by their ID, and routes them to the
        appropriate handler or callback. It also manages responses to
        synchronous requests and handles events like listen key expiration.

        Args:
            _ (Any): Unused WebSocket instance parameter.
            message (str): The raw message received from the WebSocket.
        """
        result = None

        __data = None

        if ccf.is_json(message):
            __data = json.loads(message)

        __id = None
        __event = None
        if __data is not None and isinstance(__data, dict):
            __id = __data.get('id', None)
            __event = __data.get('event', None)

        if __id is not None:
            with self.__ws_lock:
                if __id in self.__ws_response_data:
                    __current_time = time.time()
                    __current_datetime = datetime.datetime.fromtimestamp(__current_time,
                                                                         tz=datetime.timezone.utc)
                    __current_datetime = f'{__current_datetime.strftime("%Y-%m-%d %H:%M:%S.%f")}'
                    self.__ws_response_data[__id]['time_end'] = round(__current_time, 8)
                    self.__ws_response_data[__id]['datetime_end'] = __current_datetime
                    self.__ws_response_data[__id]['diff_time'] = (
                        round((__current_time - self.__ws_response_data[__id].get('time_ini', 0)),
                              8)
                    )
                    self.__ws_response_data[__id]['req_result'] = __data

                    # print('H' * 80)
                    # pprint.pprint(self.__ws_response_data[__id], sort_dicts=False)
                    # print('H' * 80)
                else:
                    # print('(' * 80)
                    # print('(' * 80)
                    # pprint.pprint(__data, sort_dicts=False)
                    # print(')' * 80)
                    # print(')' * 80)
                    # print('')

                    # __out_msg = f'ACA: 1, self.__ws_on_message: {self.__ws_on_message}'
                    # __out_msg += f' -> {type(self.__ws_on_message)}'
                    # __out_msg += f' -> {isinstance(self.__ws_on_message, Callable)}'
                    # print('-' * 80)
                    # print(__out_msg)
                    # print('-' * 80)
                    # print('')

                    if self.__ws_on_message is not None\
                        and isinstance(self.__ws_on_message, Callable):
                        self.__ws_on_message(message)

        else:
            # print('(' * 80)
            # print('(' * 80)
            # pprint.pprint(__data, sort_dicts=False)
            # print(')' * 80)
            # print(')' * 80)
            # print('')

            # __out_msg = f'ACA: 1, self.__ws_on_message: {self.__ws_on_message}'
            # __out_msg += f' -> {type(self.__ws_on_message)}'
            # __out_msg += f' -> {isinstance(self.__ws_on_message, Callable)}'
            # print('-' * 80)
            # print(__out_msg)
            # print('-' * 80)
            # print('')

            if __event is not None\
                and isinstance(__event, dict)\
                and __event.get('e', '__NONE__') == 'listenKeyExpired':
                with self.__ws_lock:
                    self.__ws_reload = True

            else:
                if self.__ws_on_message is not None\
                    and isinstance(self.__ws_on_message, Callable):

                    __message_out = json.dumps(__event, sort_keys=False)
                    self.__ws_on_message(__message_out)

        return result

    def __create_logon_request(self):
        result = None

        __current_tstp = time.time()

        dt_utc = datetime.datetime.fromtimestamp(__current_tstp, tz=datetime.timezone.utc)
        __req_id = f'{dt_utc.strftime("%Y%m%d_%H-%M-%S_%f")}_{ccf.random_string(9)}'

        __params = {
            "apiKey": self.__api_key,
            "timestamp": int(__current_tstp * 1000)
        }

        __params = self.__add_signature(__params)

        __request_method = "session.logon"

        result = {
            "id": __req_id,
            "method": __request_method,
            "params": __params
        }

        return result

    def __create_logout_request(self):
        result = None

        __current_tstp = time.time()

        dt_utc = datetime.datetime.fromtimestamp(__current_tstp, tz=datetime.timezone.utc)
        __req_id = f'{dt_utc.strftime("%Y%m%d_%H-%M-%S_%f")}_{ccf.random_string(9)}'

        __request_method = "session.logout"

        result = {
            "id": __req_id,
            "method": __request_method
        }

        return result

    def __create_ping_request(self):
        result = None

        __current_tstp = time.time()

        dt_utc = datetime.datetime.fromtimestamp(__current_tstp, tz=datetime.timezone.utc)
        __req_id = f'{dt_utc.strftime("%Y%m%d_%H-%M-%S_%f")}_{ccf.random_string(9)}'

        __request_method = "ping"

        result = {
            "id": __req_id,
            "method": __request_method
        }

        return result

    def __create_status_request(self):
        result = None

        __current_tstp = time.time()

        dt_utc = datetime.datetime.fromtimestamp(__current_tstp, tz=datetime.timezone.utc)
        __req_id = f'{dt_utc.strftime("%Y%m%d_%H-%M-%S_%f")}_{ccf.random_string(9)}'

        __request_method = "session.status"

        result = {
            "id": __req_id,
            "method": __request_method
        }

        return result

    def __create_subscribe_request(self):
        result = None

        __current_tstp = time.time()

        dt_utc = datetime.datetime.fromtimestamp(__current_tstp, tz=datetime.timezone.utc)
        __req_id = f'{dt_utc.strftime("%Y%m%d_%H-%M-%S_%f")}_{ccf.random_string(9)}'

        # __params = self.__add_signature(__params)

        __request_method = "userDataStream.subscribe"

        result = {
            "id": __req_id,
            "method": __request_method
        }

        return result

    def __create_unsubscribe_request(self):
        result = None

        __current_tstp = time.time()

        dt_utc = datetime.datetime.fromtimestamp(__current_tstp, tz=datetime.timezone.utc)
        __req_id = f'{dt_utc.strftime("%Y%m%d_%H-%M-%S_%f")}_{ccf.random_string(9)}'


        __request_method = "userDataStream.unsubscribe"

        result = {
            "id": __req_id,
            "method": __request_method
        }

        return result

    def __add_signature(self, params: dict = None):
        """
        Adds a cryptographic signature to the request parameters.

        This method signs the given parameters using the provided API secret
        and attaches the signature to the parameter dictionary, as required
        by the Binance API for authenticated endpoints.

        Args:
            params (dict): A dictionary of request parameters.

        Returns:
            dict: The parameter dictionary with the 'signature' key added.
        """
        result = None

        if params is not None and isinstance(params, dict):
            query_string = urllib.parse.urlencode(sorted(params.items()))

            signature = None

            signature = base64.b64encode(self.__private_key.sign(query_string.encode('ASCII')))
            signature = signature.decode('ASCII')

            if signature is not None:
                params['signature'] = signature

            result = params

        return result

    def __ws_check_conn_status(self):
        result = False
        __req_time_out = 9
        __max_tries = 3
        __num_try = 0

        __req_response_data = None
        __is_logged = False
        __req_result = None

        while (__req_result is None or not __req_result) and __num_try < __max_tries:
            # print(f'__num_try: {__num_try}')

            __req = self.__create_status_request()
            __req_json = json.dumps(__req, sort_keys=True)
            __req_id = __req.get('id', None)
            __req_response_data = None

            if __req_id is not None:
                __req_response_data = {}

                __req_response_data['time_ini'] = time.time()
                dt_utc = datetime.datetime.fromtimestamp(__req_response_data['time_ini'],
                                                        tz=datetime.timezone.utc)
                __req_response_data['datetime_ini'] = f'{dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")}'
                __req_response_data['time_end'] = None
                __req_response_data['datetime_end'] = None
                __req_response_data['diff_time'] = 0
                __req_response_data['id'] = __req_id
                __req_response_data['req_data'] = __req
                __req_response_data['req_result'] = None

                with self.__ws_lock:
                    self.__ws_response_data[__req_id] = __req_response_data

                try:
                    self.__ws.send(__req_json)
                except Exception as e: # pylint: disable=broad-except
                    pass

                __time_diff = 0
                __req_time_ini = time.time()

                while not __is_logged and __time_diff <= __req_time_out:
                    __req_response_data = None

                    with self.__ws_lock:
                        __req_response_data = self.__ws_response_data.get(__req_id, None)

                    if isinstance(__req_response_data, dict):
                        __req_result = __req_response_data.get('req_result', {})
                        if __req_result is None:
                            __req_result = {}
                        __current_status = __req_result.get('status', 0)
                        __current_status = int(__current_status)

                        __req_res = __req_result.get('result', {})
                        if __req_res is None:
                            __req_res = {}
                        __current_result = __req_res.get('apiKey', '')
                        __current_user_data_stream = __req_res.get('userDataStream', False)

                        if __current_status == 200\
                            and __current_result is not None\
                            and __current_result == self.__api_key\
                            and __current_user_data_stream:
                            __is_logged = True

                    time.sleep(0.05)
                    __time_diff = int(time.time() - __req_time_ini)

            if __req_result is None or not __req_result:
                __num_try += 1
                time.sleep(0.25)

        result = __is_logged

        with self.__ws_lock:
            self.__ws_is_connected = result

        return result

    def __ws_subscribe_request(self):
        result = False
        __req_time_out = 9
        __max_tries = 3
        __num_try = 0

        __req_response_data = None
        __is_logged = False
        __req_result = None

        while (__req_result is None or not __req_result) and __num_try < __max_tries:

            __req = self.__create_subscribe_request()
            __req_json = json.dumps(__req, sort_keys=True)
            __req_id = __req.get('id', None)
            __req_response_data = None

            if __req_id is not None:
                __req_response_data = {}

                __req_response_data['time_ini'] = time.time()
                dt_utc = datetime.datetime.fromtimestamp(__req_response_data['time_ini'],
                                                         tz=datetime.timezone.utc)
                __req_response_data['datetime_ini'] = f'{dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")}'
                __req_response_data['time_end'] = None
                __req_response_data['datetime_end'] = None
                __req_response_data['diff_time'] = 0
                __req_response_data['id'] = __req_id
                __req_response_data['req_data'] = __req
                __req_response_data['req_result'] = None

                with self.__ws_lock:
                    self.__ws_response_data[__req_id] = __req_response_data

                try:
                    self.__ws.send(__req_json)
                except Exception as e: # pylint: disable=broad-except
                    pass

                __time_diff = 0
                __req_time_ini = time.time()

                while not __is_logged and __time_diff <= __req_time_out:
                    __req_response_data = None

                    with self.__ws_lock:
                        __req_response_data = self.__ws_response_data.get(__req_id, None)

                    if isinstance(__req_response_data, dict):
                        __req_result = __req_response_data.get('req_result', {})
                        if __req_result is None:
                            __req_result = {}
                        __current_status = __req_result.get('status', 0)
                        __current_status = int(__current_status)

                        if __current_status == 200:
                            __is_logged = True

                    time.sleep(0.05)
                    __time_diff = int(time.time() - __req_time_ini)

            if __req_result is None or not __req_result:
                __num_try += 1
                time.sleep(0.25)

        result = __is_logged

        with self.__ws_lock:
            self.__ws_is_connected = result

        return result

    def __ws_unsubscribe_request(self):
        result = False
        __req_time_out = 9
        __max_tries = 3
        __num_try = 0

        __req_response_data = None
        __is_logged = False
        __req_result = None

        while (__req_result is None or not __req_result) and __num_try < __max_tries:

            __req = self.__create_unsubscribe_request()
            __req_json = json.dumps(__req, sort_keys=True)
            __req_id = __req.get('id', None)
            __req_response_data = None

            if __req_id is not None:
                __req_response_data = {}

                __req_response_data['time_ini'] = time.time()
                dt_utc = datetime.datetime.fromtimestamp(__req_response_data['time_ini'],
                                                        tz=datetime.timezone.utc)
                __req_response_data['datetime_ini'] = f'{dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")}'
                __req_response_data['time_end'] = None
                __req_response_data['datetime_end'] = None
                __req_response_data['diff_time'] = 0
                __req_response_data['id'] = __req_id
                __req_response_data['req_data'] = __req
                __req_response_data['req_result'] = None

                with self.__ws_lock:
                    self.__ws_response_data[__req_id] = __req_response_data

                try:
                    self.__ws.send(__req_json)
                except Exception as e: # pylint: disable=broad-except
                    pass

                __time_diff = 0
                __req_time_ini = time.time()

                while not __is_logged and __time_diff <= __req_time_out:
                    __req_response_data = None

                    with self.__ws_lock:
                        __req_response_data = self.__ws_response_data.get(__req_id, None)

                    if isinstance(__req_response_data, dict):
                        __req_result = __req_response_data.get('req_result', {})
                        if __req_result is None:
                            __req_result = {}
                        __current_status = __req_result.get('status', 0)
                        __current_status = int(__current_status)

                        if __current_status == 200:
                            __is_logged = True

                    time.sleep(0.05)
                    __time_diff = int(time.time() - __req_time_ini)

            if __req_result is None or not __req_result:
                __num_try += 1
                time.sleep(0.25)

        result = __is_logged

        with self.__ws_lock:
            self.__ws_is_connected = result

        return result

    def __ws_session_logon(self):
        result = False
        __req_time_out = 9
        __max_tries = 3
        __num_try = 0

        __req_result = None

        __req_response_data = None
        __is_logged = False

        while not __is_logged and __num_try < __max_tries:

            __req = self.__create_logon_request()
            __req_json = json.dumps(__req, sort_keys=True)
            __req_id = __req.get('id', None)
            __req_response_data = None

            if __req_id is not None:
                __req_response_data = {}

                __req_response_data['time_ini'] = time.time()
                dt_utc = datetime.datetime.fromtimestamp(__req_response_data['time_ini'],
                                                        tz=datetime.timezone.utc)
                __req_response_data['datetime_ini'] = f'{dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")}'
                __req_response_data['time_end'] = None
                __req_response_data['datetime_end'] = None
                __req_response_data['diff_time'] = 0
                __req_response_data['id'] = __req_id
                __req_response_data['req_data'] = __req
                __req_response_data['req_result'] = None

                with self.__ws_lock:
                    self.__ws_response_data[__req_id] = __req_response_data

                try:
                    self.__ws.send(__req_json)
                except Exception as e: # pylint: disable=broad-except
                    pass

                __time_diff = 0
                __req_time_ini = time.time()

                while not __is_logged and __time_diff <= __req_time_out:
                    __req_response_data = None

                    with self.__ws_lock:
                        __req_response_data = self.__ws_response_data.get(__req_id, None)

                    if isinstance(__req_response_data, dict):
                        __req_result = __req_response_data.get('req_result', {})
                        if __req_result is None:
                            __req_result = {}
                        __current_status = __req_result.get('status', 0)
                        __current_status = int(__current_status)

                        __current_result = __req_result.get('result', {})
                        if __current_result is None:
                            __current_result = {}
                        __current_result = __current_result.get('apiKey', '')

                        if __current_status == 200\
                            and __current_result is not None\
                            and __current_result == self.__api_key:
                            __is_logged = True

                    time.sleep(0.05)
                    __time_diff = int(time.time() - __req_time_ini)

            if not __is_logged:
                __num_try += 1
                time.sleep(5)

        result = __is_logged

        with self.__ws_lock:
            self.__ws_is_connected = result

        return result

    def __ws_session_logout(self):
        result = False
        __req_time_out = 9
        __max_tries = 3
        __num_try = 0

        __req_response_data = None
        __is_exec = False
        __req_result = None

        while (__req_result is None or not __req_result) and __num_try < __max_tries:

            __req = self.__create_logout_request()
            __req_json = json.dumps(__req, sort_keys=True)
            __req_id = __req.get('id', None)
            __req_response_data = None

            if __req_id is not None:
                __req_response_data = {}

                __req_response_data['time_ini'] = time.time()
                dt_utc = datetime.datetime.fromtimestamp(__req_response_data['time_ini'],
                                                        tz=datetime.timezone.utc)
                __req_response_data['datetime_ini'] = f'{dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")}'
                __req_response_data['time_end'] = None
                __req_response_data['datetime_end'] = None
                __req_response_data['diff_time'] = 0
                __req_response_data['id'] = __req_id
                __req_response_data['req_data'] = __req
                __req_response_data['req_result'] = None

                with self.__ws_lock:
                    self.__ws_response_data[__req_id] = __req_response_data

                try:
                    self.__ws.send(__req_json)
                except Exception as e: # pylint: disable=broad-except
                    pass

                __time_diff = 0
                __req_time_ini = time.time()

                while not __is_exec and __time_diff <= __req_time_out:
                    __req_response_data = None

                    with self.__ws_lock:
                        __req_response_data = self.__ws_response_data.get(__req_id, None)

                    if isinstance(__req_response_data, dict):
                        __req_result = __req_response_data.get('req_result', {})
                        if __req_result is None:
                            __req_result = {}
                        __current_status = __req_result.get('status', 0)
                        __current_status = int(__current_status)

                        if __current_status == 200:
                            __is_exec = True

                    time.sleep(0.05)
                    __time_diff = int(time.time() - __req_time_ini)

            if __req_result is None or not __req_result:
                __num_try += 1
                time.sleep(0.25)

        result = __is_exec

        with self.__ws_lock:
            self.__ws_is_connected = result

        return result

    def __ws_ping(self):
        result = False
        __req_time_out = 32
        __max_tries = 3
        __num_try = 0

        __req_response_data = None
        __is_exec = False
        __req_result = None

        while (__req_result is None or not __req_result) and __num_try < __max_tries:

            __req = self.__create_ping_request()
            __req_json = json.dumps(__req, sort_keys=True)
            __req_id = __req.get('id', None)
            __req_response_data = None

            if __req_id is not None:
                __req_response_data = {}

                __req_response_data['time_ini'] = time.time()
                dt_utc = datetime.datetime.fromtimestamp(__req_response_data['time_ini'],
                                                        tz=datetime.timezone.utc)
                __req_response_data['datetime_ini'] = f'{dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")}'
                __req_response_data['time_end'] = None
                __req_response_data['datetime_end'] = None
                __req_response_data['diff_time'] = 0
                __req_response_data['id'] = __req_id
                __req_response_data['req_data'] = __req
                __req_response_data['req_result'] = None

                with self.__ws_lock:
                    self.__ws_response_data[__req_id] = __req_response_data

                try:
                    self.__ws.send(__req_json)
                except Exception as e: # pylint: disable=broad-except
                    pass

                __time_diff = 0
                __req_time_ini = time.time()

                while not __is_exec and __time_diff <= __req_time_out:
                    __req_response_data = None

                    with self.__ws_lock:
                        __req_response_data = self.__ws_response_data.get(__req_id, None)

                    if isinstance(__req_response_data, dict):
                        __req_result = __req_response_data.get('req_result', {})
                        if __req_result is None:
                            __req_result = {}
                        __current_status = __req_result.get('status', 0)
                        __current_status = int(__current_status)

                        if __current_status == 200:
                            __is_exec = True

                    time.sleep(0.05)
                    __time_diff = int(time.time() - __req_time_ini)

            if __req_result is None or not __req_result:
                __num_try += 1
                time.sleep(0.25)

        result = __is_exec

        with self.__ws_lock:
            self.__ws_is_connected = result

        return result

    def __ws_start(self):
        result = False

        self.__ws_session_logon()
        time.sleep(32)
        self.__ws_subscribe_request()

        __time_out = 95

        __time_ini = time.time()
        __time_diff = 0
        while not result and __time_diff < __time_out:
            result = self.__ws_check_conn_status()
            time.sleep(5)
            __time_diff = time.time() - __time_ini

        return result

    def __ws_stop(self):
        result = False
        try:
            self.__ws_unsubscribe_request()
            time.sleep(5)
            self.__ws_session_logout()
            time.sleep(4)
        except Exception: # pylint: disable=broad-except
            pass

        result = self.__ws_check_conn_status()
        result = not result

        return result

    # ------------------------
    # Funciones de operación
    # ------------------------

    def __create_order_status_request(self, order_id, symbol):
        result = None

        __current_tstp = time.time()

        dt_utc = datetime.datetime.fromtimestamp(__current_tstp, tz=datetime.timezone.utc)
        __req_id = f'{dt_utc.strftime("%Y%m%d_%H-%M-%S_%f")}_{ccf.random_string(9)}'

        __request_method = "order.status"
        __timestamp = int(time.time() * 1000)

        __params = {
            "apiKey": self.__api_key,
            "orderId": order_id,
            "symbol": symbol,
            "timestamp": __timestamp
        }

        __params = self.__add_signature(__params)

        result = {
            "id": __req_id,
            "method": __request_method,
            "params": __params
        }

        return result

    def ping(self):
        """
        ping
        ====
        Sends a ping message to the WebSocket server to keep the connection alive.
        This method is typically called periodically to prevent the connection from
        timing out due to inactivity.

        Returns:
        --------
        bool
            Returns True if the ping message was sent successfully, False otherwise.
        """

        result = (time.time() - self.__last_ping_checked) < self.__limit_ping_time

        return result and self.__ws_ping()

    def get_order(self, order_id, order_symbol=None):
        """
        Retrieves the details of a specific order by its ID.

        This method queries the status and details of a single order using
        a WebSocket request.

        Args:
            order_id (str): The exchange-assigned order ID.
            order_symbol (str, optional): The symbol of the order (e.g., 'BTC/USDT').
                Required for the query.

        Returns:
            dict: A dictionary containing the order details, or None if not found.
        """
        # Implementar mensaje FIX de tipo OrderStatusRequest
        result = None

        __req_time_out = 32
        __max_tries = 5
        __num_try = 0

        __req_response_data = None
        __is_exec = False
        __req_result = None

        order_symbol_req = None
        if order_symbol is not None and isinstance(order_symbol, str) and len(order_symbol) > 0:
            order_symbol_req = order_symbol.replace('/', '')
        else:
            return result

        while (__req_result is None or not __req_result) and __num_try < __max_tries:

            __req = self.__create_order_status_request(order_id, order_symbol_req)
            __req_json = json.dumps(__req, sort_keys=True)
            __req_id = __req.get('id', None)
            __req_response_data = None

            if __req_id is not None:
                __req_response_data = {}

                __req_response_data['time_ini'] = time.time()
                dt_utc = datetime.datetime.fromtimestamp(__req_response_data['time_ini'],
                                                        tz=datetime.timezone.utc)
                __req_response_data['datetime_ini'] = f'{dt_utc.strftime("%Y-%m-%d %H:%M:%S.%f")}'
                __req_response_data['time_end'] = None
                __req_response_data['datetime_end'] = None
                __req_response_data['diff_time'] = 0
                __req_response_data['id'] = __req_id
                __req_response_data['req_data'] = __req
                __req_response_data['req_result'] = None

                with self.__ws_lock:
                    self.__ws_response_data[__req_id] = __req_response_data

                try:
                    self.__ws.send(__req_json)
                except Exception as e: # pylint: disable=broad-except
                    pass

                __time_diff = 0
                __req_time_ini = time.time()

                while not __is_exec and __time_diff <= __req_time_out:
                    __req_response_data = None

                    with self.__ws_lock:
                        __req_response_data = self.__ws_response_data.get(__req_id, None)

                    if isinstance(__req_response_data, dict):
                        __req_result = __req_response_data.get('req_result', {})
                        if __req_result is None:
                            __req_result = {}
                        __current_status = __req_result.get('status', 0)
                        __current_status = int(__current_status)

                        if __current_status == 200:
                            __is_exec = True

                    time.sleep(0.05)
                    __time_diff = int(time.time() - __req_time_ini)

            if __req_result is None or not __req_result:
                __num_try += 1
                time.sleep(0.25)

        if __req_response_data is not None\
            and isinstance(__req_response_data, dict)\
            and 'req_result' in __req_response_data\
            and __req_response_data['req_result'] is not None\
            and isinstance(__req_response_data['req_result'], dict):

            if int(__req_response_data['req_result'].get('status', 0)) != 200:
                return result

            __res_data = __req_response_data['req_result'].get('result', None)
            if __res_data is None or not isinstance(__res_data, dict):
                return result

            result = self.get_order_skel()
            result['id'] = str(__res_data.get('orderId', order_id))
            result['clientOrderId'] = str(__res_data.get('clientOrderId', ''))
            result['timestamp'] = int(__res_data.get('time', 0))
            __order_time = round((float(result['timestamp'])/1000), 3)
            result['datetime'] = datetime.datetime.fromtimestamp(__order_time)\
                .replace(tzinfo=pytz.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
            result['lastTradeTimestamp'] = __res_data.get('updateTime', 0)
            result['lastUpdateTimestamp'] = __res_data.get('updateTime', 0)
            result['symbol'] = order_symbol
            result['type'] = str(__res_data.get('type', '')).lower()
            result['timeInForce'] = str(__res_data.get('timeInForce', ''))
            result['postOnly'] = False
            result['reduceOnly'] = __res_data.get('', False)
            result['side'] = str(__res_data.get('side', '')).lower()
            result['price'] = float(__res_data.get('price', 0.0))
            result['amount'] = float(__res_data.get('origQty', 0.0))
            result['cost'] = float(__res_data.get('cummulativeQuoteQty', 0.0))
            result['average'] = result['price']
            result['filled'] = float(__res_data.get('executedQty', 0.0))
            result['remaining'] = result['amount'] - result['filled']
            __status_key = str(__res_data.get('status', 'Z'))
            __status_key = self.__ord_status.get(__status_key, 'Z')
            result['status'] = self.__ord_statuses.get(__status_key, None)

        # print('=' * 80)
        # pprint.pprint(__req_response_data, sort_dicts=False)
        # print('=' * 80)
        # print('')

        return result

    def cancel_order(self,
                     order_id,
                     order_symbol,
                     time_out: int = 9):
        """
        Cancels an active order.

        This method sends an OrderCancelRequest via the FIX protocol to cancel
        an existing order.

        Args:
            order_id (str): The ID of the order to be canceled.
            order_symbol (str): The symbol of the order (e.g., 'BTC/USDT').
            time_out (int, optional): Timeout in seconds to wait for confirmation.
                Defaults to 9.

        Returns:
            dict: The final state of the canceled order, or None on timeout.
        """
        # Implementar mensaje FIX de tipo OrderCancelRequest
        result = None

        __time_ini = time.time()
        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access

        __order_symbol = order_symbol.replace('/', '').upper()

        __cl_order_id = f'{time.time_ns():0>23}_{ccf.random_string(7)}'

        with self.__orders_lock:

            __current_time = round(time.time(), 3)
            __current_datetime = (
                datetime.datetime.fromtimestamp(__current_time).isoformat(timespec='milliseconds')
            )

            __order_out = {
                'order': None,
                'fix_request': 'OrderCancelRequest',
                'input_symbol': order_symbol,
                'init_unixtime': __current_time,
                'init_datetime': __current_datetime,
                'last_update_unixtime': __current_time,
                'last_update_datetime': __current_datetime,
            }

            self.__orders[__cl_order_id] = __order_out

        __msg = self.__client_oe.create_fix_message_with_basic_header("F")
        __msg.append_pair(11, __cl_order_id)  # CL ORD ID
        __msg.append_pair(37, order_id)  # ORD ID
        __msg.append_pair(55, __order_symbol)  # SYMBOL

        self.__client_oe.send_message(__msg)
        time.sleep(self.__time_sleep)

        __order = None
        __is_order_executed = False
        __time_diff = 0
        while not __is_order_executed and __time_diff <= time_out:
            if __time_diff != 0:
                time.sleep(self.__time_sleep)
            with self.__orders_lock:
                __order = deepcopy(self.__orders).get(__cl_order_id, {}).get('order', None)
                __time_diff = time.time() - __time_ini

            if isinstance(__order, dict):
                __is_order_executed = True
                __order['symbol'] = order_symbol
                __order['total_execution_time'] = round(__time_diff, 8)

        result = __order

        return result

    def create_order(self,
                     order_symbol: str = None,
                     order_side: str = None,
                     order_amount: str = None,
                     order_price: str = None,
                     order_type: str = 'limit',
                     time_in_force: str = 'GTC',
                     time_out: int = 95):
        """
        Creates a new order on the exchange.

        This method sends a NewOrderSingle message via the FIX protocol to
        place a new order with the specified parameters.

        Args:
            order_symbol (str): The trading symbol (e.g., 'BTC/USDT').
            order_side (str): The side of the order ('buy' or 'sell').
            order_amount (str): The quantity of the asset to trade.
            order_price (str): The price at which to place the order.
            order_type (str, optional): The type of order ('limit', 'market', etc.).
                Defaults to 'limit'.
            time_in_force (str, optional): The time-in-force policy ('GTC', 'IOC', 'FOK').
                Defaults to 'GTC'.
            time_out (int, optional): Timeout in seconds to wait for confirmation.
                Defaults to 9.

        Returns:
            dict: The initial state of the created order, or None on timeout.
        """
        result = None

        __time_ini = time.time()
        __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access

        __order_symbol = order_symbol.replace('/', '').upper()

        __order_price = str(order_price)
        __order_amount = str(order_amount)

        __order_type = None if not self.__ord_types_inv.get(order_type, False)\
            else str(self.__ord_types_inv.get(order_type, '2'))

        if __order_type is None:
            __error_out = f'{__l_function} ERROR: order type {order_type} not allowed'
            raise Exception(__error_out) # pylint: disable=broad-exception-raised

        __order_side = None if not self.__ord_sides_inv.get(order_side, False)\
            else str(self.__ord_sides_inv.get(order_side))

        if __order_side is None:
            __error_out = f'{__l_function} ERROR: order side {order_side} not allowed'
            raise Exception(__error_out) # pylint: disable=broad-exception-raised

        __time_in_force = '1' if not self.__time_in_force_inv.get(time_in_force, False)\
            else str(self.__time_in_force_inv.get(time_in_force))

        __cl_order_id = f'{time.time_ns():0>23}_{ccf.random_string(7)}'

        with self.__orders_lock:

            __current_time = round(time.time(), 3)
            __current_datetime = (
                datetime.datetime.fromtimestamp(__current_time).isoformat(timespec='milliseconds')
            )

            __order_out = {
                'order': None,
                'fix_request': 'NewOrderSingle',
                'input_symbol': order_symbol,
                'init_unixtime': __current_time,
                'init_datetime': __current_datetime,
                'last_update_unixtime': __current_time,
                'last_update_datetime': __current_datetime,
            }

            self.__orders[__cl_order_id] = __order_out

        __msg = self.__client_oe.create_fix_message_with_basic_header("D")
        __msg.append_pair(38, __order_amount)  # ORD QTY
        __msg.append_pair(40, __order_type)  # ORD TYPE
        __msg.append_pair(11, __cl_order_id)  # CL ORD ID
        __msg.append_pair(44, __order_price)  # PRICE
        __msg.append_pair(54, __order_side)  # SIDE
        __msg.append_pair(55, __order_symbol)  # SYMBOL
        __msg.append_pair(59, __time_in_force)  # TIME IN FORCE

        self.__client_oe.send_message(__msg)
        time.sleep(self.__time_sleep)

        if time_out < 95:
            time_out = 95

        __order = None
        __time_diff = 0
        # pylint: disable=unsupported-membership-test
        while (__order is None or not isinstance(__order, dict) or 'id' not in __order)\
            and __time_diff <= time_out:
            __order = None
            if __time_diff != 0:
                time.sleep(self.__time_sleep)
            with self.__orders_lock:
                __temp_order = deepcopy(self.__orders).get(__cl_order_id, {}).get('order', None)
                if __temp_order is not None\
                    and isinstance(__temp_order, dict)\
                    and 'id' in __temp_order\
                    and __temp_order['id'] is not None\
                    and isinstance(__temp_order['id'], (str, int))\
                    and len(str(__temp_order['id'])) > 0:
                    __order = deepcopy(__temp_order)
                    __order['symbol'] = order_symbol
                    __order['total_execution_time'] = round(__time_diff, 8)

                else:
                    __order = None

            __time_diff = time.time() - __time_ini

        result = deepcopy(__order)

        return result

    def ws_check_conn_status(self):
        """
        Checks the status of the WebSocket connection.

        Returns:
            bool: True if the connection is active and authenticated, False otherwise.
        """

        return self.__ws_check_conn_status()

    def __redirect_logs(self):
        # Obtener logger externo
        __external_logger = logging.getLogger("BinanceFixConnector")
        __external_logger.setLevel(logging.DEBUG)  # se necesita el nivel más bajo posible

        # Eliminar handlers previos si los hubiera
        __external_logger.handlers.clear()

        # Filtros personalizados
        class InfoOnlyFilter(logging.Filter):
            """
            InfoOnlyFilter
            ==============
            """
            def filter(self, record):
                return record.levelno == logging.INFO

        class ErrorOnlyFilter(logging.Filter):
            """
            ErrorOnlyFilter
            ==============
            """
            def filter(self, record):
                return record.levelno >= logging.ERROR

        class DebugOnlyFilter(logging.Filter):
            """
            DebugOnlyFilter
            ==============
            """
            def filter(self, record):
                return record.levelno == logging.DEBUG

        # Redirigir INFO (solo) a log_handler
        for h in self.__log_handler.handlers:
            info_handler = self.__copy_handler(h)
            info_handler.addFilter(InfoOnlyFilter())
            __external_logger.addHandler(info_handler)

        # Redirigir ERROR y EXCEPTION a err_handler
        for h in self.__err_handler.handlers:
            err_handler = self.__copy_handler(h)
            err_handler.addFilter(ErrorOnlyFilter())
            __external_logger.addHandler(err_handler)

        # Redirigir DEBUG si debug_enabled es True
        if self.__debug:
            for h in self.__log_handler.handlers:
                debug_handler = self.__copy_handler(h)
                debug_handler.addFilter(DebugOnlyFilter())
                __external_logger.addHandler(debug_handler)

        # Evitar propagación al logger raíz
        __external_logger.propagate = False

    def __redirect_logs_to_null(self):

        class DiscardFilter(logging.Filter):
            """
            DiscardFilter
            =============
            """
            def filter(self, record):
                # Devuelve False si el nivel está en los que quieres descartar
                return record.levelno not in (logging.DEBUG, logging.INFO, logging.ERROR)

        null_handler = logging.NullHandler()
        null_handler.addFilter(DiscardFilter())

        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(message)s",
            handlers=[null_handler],
        )

        __external_logger = logging.getLogger("BinanceFixConnector")
        __external_logger.handlers.clear()
        __external_logger.addHandler(null_handler)
        __external_logger.setLevel(logging.DEBUG)  # se necesita el nivel más bajo posible
        __external_logger.propagate = False

    def __copy_handler(self, handler: logging.Handler) -> logging.Handler:
        # Clona el handler para evitar conflictos compartidos
        new_handler = (
            type(handler)(handler.baseFilename if isinstance(handler,
                                                             logging.FileHandler) else None)
        )
        new_handler.setFormatter(handler.formatter)
        new_handler.setLevel(handler.level)
        return new_handler

    @classmethod
    def fix_msg_to_dict(cls, message):
        """
        Converts a FIX message object to a dictionary.

        Args:
            message: The FIX message object from the connector.

        Returns:
            dict: A dictionary representation of the FIX message, with indexed keys.
        """
        result = {}
        index = 1

        for pair in message.pairs:
            __name = pair[0].decode()
            __value = pair[1].decode()

            index_d = f'FIX_{index:0>5}'
            result[index_d] = {
                'name': __name,
                'value': __value
            }
            index += 1

        return result

    @classmethod
    def print_fix_msg(cls, message):
        """
        Prints the contents of a FIX message to the console.

        Args:
            message: The FIX message object.

        Returns:
            bool: Always returns True.
        """
        result = True

        data = message.to_string()
        print(f'DATA: {data}')
        print('=' * 80)
        for pair in message.pairs:
            print(f'{pair[0].decode()}: {pair[1].decode()}')
        print('=' * 80)

        return result

    @classmethod
    def get_order_skel(cls):
        """
        Returns a skeleton dictionary for a standardized order structure.

        This provides a consistent format for order data across the application.

        Returns:
            dict: A dictionary with predefined keys for order details.
        """
        result = {
            "id": None,
            "clientOrderId": None,
            "timestamp": None,
            "datetime": None,
            "lastTradeTimestamp": None,
            "lastUpdateTimestamp": None,
            "symbol": None,
            "type": None,
            "timeInForce": None,
            "postOnly": True,
            "reduceOnly": None,
            "side": None,
            "price": None,
            "triggerPrice": None,
            "amount": None,
            "cost": None,
            "average": None,
            "filled": None,
            "remaining": None,
            "status": None,
            "fee": None,
            "trades": [],
            "fees": [],
            "stopPrice": None,
            "takeProfitPrice": None,
            "stopLossPrice": None
        }

        return result
