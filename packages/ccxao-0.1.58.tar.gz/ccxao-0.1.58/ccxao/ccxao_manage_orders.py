"""
Ccxao - Cryptocurrency Exchange Algorithmic Order
Class: CcxaoManageOrders

Author: Ricardo Marcelo Alvarez
Date: 2024-06-20
"""

import sys
import os
import time
import uuid
import hashlib
import hmac
import logging
import logging.handlers
import struct
import pprint # pylint: disable=unused-import
import json
import socket
import grp
import select
import base64
import errno
import ccxao.ccxao_common_functions as ccf # pylint: disable=unused-import
from ccxao import Ccxao # pylint: disable=unused-import

class CcxaoManageOrders():
    """
    CcxaoManageOrders
    =================
    Manages server-side command transport for Ccxao using a Unix Domain Socket (UDS).
    Provides helpers to accept a client, read/write base64-encoded JSON messages,
    and basic request/response framing. Also keeps optional compatibility helpers
    for legacy command-queue methods.
    """

    def __init__(self,
                 ccxao_key: str=None,
                 socket_group: str='ccxao',
                 socket_name: str='ccxao',
                 socket_timeout: int=45,
                 socket_max_bytes: int=67108864,
                 var_dir: str='/var/lib/ccxao',
                 sock_backlog: int = 64,
                 log_handler: logging.Logger = None,
                 err_handler: logging.Logger = None):

        """
        Constructor
        ===========
        Initializes server-side transport and internal paths.

        Parameters:
        -----------
        ccxao_key : str | None
            Secret key used for command signing/verification.
        socket_group : str
            Group ownership for the UDS socket file.
        socket_name : str
            Socket filename (created under var_dir/socket).
        socket_timeout : int
            Maximum time in seconds to wait for socket I/O operations.
        socket_max_bytes : int
            Upper bound on message size accepted from clients (in bytes).
        var_dir : str
            Base directory for runtime artifacts (e.g., socket path).
        sock_backlog : int
            Backlog size passed to listen() for the UDS server socket.
        log_handler : logging.Logger | None
            Logger for informational messages.
        err_handler : logging.Logger | None
            Logger for error messages.
        """

        self.__separator = self.get_separator()
        self.__socket_name = socket_name
        self.__socket_timeout = socket_timeout # pylint: disable=unused-private-member
        self.__socket_max_bytes = socket_max_bytes # pylint: disable=unused-private-member
        self.__var_dir = var_dir
        self.__ccxao_key = ccxao_key
        self.__socket_group = socket_group

        self.__socket_uid = os.getuid()
        self.__socket_gid = os.getgid()

        try:
            __group_info = grp.getgrnam(self.__socket_group)
            self.__socket_gid = __group_info.gr_gid
        except Exception: # pylint: disable=broad-except
            pass

        self.__log_logger = log_handler # pylint: disable=unused-private-member
        self.__err_logger = err_handler # pylint: disable=unused-private-member

        self.__sock_dir = os.path.join(self.__var_dir, 'socket')
        self.__socket_path = f'{self.__sock_dir}/{self.__socket_name}'
        self.__server_socket = None
        self.__socket_backlog = sock_backlog

        if not self.__create_socket_server(self.__socket_backlog):
            raise ValueError('Error on create socket')

    def __del__(self):
        """
        __del__
        =======
        Destructor that closes the server socket and removes the socket file if present.

        Notes:
        ------
        - Closes self.__server_socket if open, ignoring any exceptions.
        - Removes self.__socket_path from the filesystem if it exists.
        - Errors are logged to the provided error logger when available.
        """

        # Cerrar el socket del servidor si está creado
        try:
            if self.__server_socket:
                try:
                    self.__server_socket.close()
                except Exception:  # pylint: disable=broad-except
                    pass
        except Exception:  # pylint: disable=broad-except
            pass

        # Eliminar el archivo del socket en filesystem
        try:
            if os.path.exists(self.__socket_path):
                os.remove(self.__socket_path)
        except Exception as e:  # pylint: disable=broad-except
            if self.__err_logger:
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in class CcxaoManageOrders on function {__l_function}'
                err_msg += f', error: {e}'
                self.__err_logger.error(err_msg)

    def __create_socket_server(self, backlog: int = 64) -> bool:
        """
        Create the Unix Domain Socket server.
        ====================================
        Creates the UDS at self.__socket_path:
        - Ensures self.__sock_dir exists
        - Removes a stale socket file if present
        - Binds and listens with the given backlog
        - Stores the server socket in self.__server_socket

        Returns:
        --------
        bool
            True if the server was created successfully, False otherwise.
        """
        result = False
        try:
            if not os.path.exists(self.__sock_dir):
                os.makedirs(self.__sock_dir, exist_ok=True, mode=0o770)
                os.chown(self.__sock_dir, self.__socket_uid, self.__socket_gid)

            if os.path.exists(self.__socket_path):
                try:
                    os.remove(self.__socket_path)
                except Exception as e: # pylint: disable=broad-except
                    __err_msg = f'Cannot remove existing socket {self.__socket_path}: {e}'
                    if self.__err_logger:
                        self.__err_logger.error(__err_msg)

            self.__server_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.__server_socket.bind(self.__socket_path)

            try:
                os.chmod(self.__socket_path, 0o660)  # rw-rw----
                os.chown(self.__socket_path, self.__socket_uid, self.__socket_gid)
            except Exception:  # pylint: disable=broad-except
                __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
                err_msg = f'Found error in class CcxaoManageOrders on function {__l_function}'
                err_msg += f', socket path: {self.__socket_path}, error: {e}'

                if self.__err_logger:
                    self.__err_logger.error(err_msg)
                else:
                    print(err_msg)

            self.__server_socket.listen(backlog)
            self.__server_socket.setblocking(True)
            result = True
        except Exception as e:  # pylint: disable=broad-except
            __l_function = sys._getframe().f_code.co_name # pylint: disable=protected-access
            err_msg = f'Found error in class CcxaoManageOrders on function {__l_function}'
            err_msg += f', socket path: {self.__socket_path}, error: {e}'

            if self.__err_logger:
                self.__err_logger.error(err_msg)
            else:
                print(err_msg)

            result = False

        return result

    def recv_b64json_line(self):
        """
        Receive a base64-encoded JSON line from a client connection.
        """

        raw_len = b''

        client_conn, _ = self.__server_socket.accept()

        while len(raw_len) < 4:
            chunk = client_conn.recv(4 - len(raw_len))
            if not chunk:
                return None, None
            raw_len += chunk
        msg_size = struct.unpack('>I', raw_len)[0]

        raw_data = b''
        while len(raw_data) < msg_size:
            chunk = client_conn.recv(min(4096, msg_size - len(raw_data)))
            if not chunk:
                return None, None
            raw_data += chunk

        raw_data = raw_data.decode('utf-8')
        parts = raw_data.split(self.__separator)
        if len(parts) >= 2 and self.verify_command_signature(
            self.__ccxao_key, parts[0].encode('utf-8'), parts[1]
        ):
            return json.loads(base64.b64decode(parts[0])), client_conn
        return None, None

    def send_b64json_line(self, obj, __client_conn, frame_bytes: int = 8192) -> bool:
        """
        Envía un objeto JSON codificado en base64 con prefijo de longitud (4 bytes).
        Se encarga de firmar el mensaje y enviarlo en chunks para evitar problemas
        de buffer. Devuelve True si se envió todo correctamente, False en caso contrario.
        """
        try:
            # --- Serializar a JSON ---
            raw_json = json.dumps(obj, separators=(',', ':'), ensure_ascii=False)

            # --- Codificar base64 ---
            obj_b64 = base64.b64encode(raw_json.encode("utf-8")).decode("utf-8")

            # --- Generar firma ---
            signature = self.sign_command(self.__ccxao_key, obj_b64.encode("utf-8"))

            # --- Mensaje completo: b64|firma ---
            msg = (obj_b64 + self.__separator + signature).encode("utf-8")

            # --- Prefijo de longitud (4 bytes big-endian) ---
            msg_len = struct.pack(">I", len(msg))
            msg_out = msg_len + msg

            # --- Enviar en chunks ---
            mv = memoryview(msg_out)
            total = len(msg_out)
            sent = 0
            while sent < total:
                end = sent + frame_bytes
                try:
                    n = __client_conn.send(mv[sent:end])
                    if n == 0:
                        raise RuntimeError("Socket closed during send")
                    sent += n
                except (BlockingIOError, OSError) as e:
                    if getattr(e, "errno", None) in (errno.EAGAIN, errno.EWOULDBLOCK):
                        # Esperar a que el socket esté listo para escribir
                        select.select([], [__client_conn], [], 5.0)
                        continue
                    raise

            return True

        except Exception as e: # pylint: disable=broad-except
            # Acá podés loguear con tu logger interno
            print(f"[send_b64json_line] Error: {e}")
            return False

    @classmethod
    def generate_command_id(cls) -> str:
        """
        Generate a unique command ID.

        Returns:
        --------
        str
            Unique command identifier string composed of a UUID and a high-resolution timestamp.
        """
        return str(uuid.uuid4()) + '-' + str(time.time_ns())

    @classmethod
    def sign_command(cls,
                     ccxao_key: str='',
                     command_data: bytes=None) -> str:
        """
        Sign command data using HMAC-SHA256.

        Parameters:
        -----------
        ccxao_key : str
            Shared secret used to compute the HMAC.
        command_data : bytes
            Raw message bytes to sign.

        Returns:
        --------
        str
            Hexadecimal HMAC-SHA256 signature.
        """

        return hmac.new(ccxao_key.encode('utf-8'),
                        command_data,
                        hashlib.sha256).hexdigest()

    @classmethod
    def verify_command_signature(cls,
                                 ccxao_key: str='',
                                 command_data: bytes='',
                                 signature: str='') -> bool:
        """
        Verify command signature.

        Parameters:
        -----------
        ccxao_key : str
            Shared secret used to compute the expected HMAC.
        command_data : bytes
            Raw message bytes whose signature is being verified.
        signature : str
            Hexadecimal HMAC-SHA256 signature to compare against.

        Returns:
        --------
        bool
            True if the signature matches the expected value, False otherwise.
        """
        expected_signature = cls.sign_command(ccxao_key=ccxao_key,
                                              command_data=command_data)

        return expected_signature == signature

    @classmethod
    def get_commands_func(cls):
        """
        get_commands_func
        =================
        Enumerate supported command names.

        Returns:
        --------
        dict
            Mapping of command name (str) to a truthy placeholder (bool) indicating availability.
        """

        return {
            'get_balances': True,
            'get_usdt_balances': True,
            'get_trading_fees': True,
            'get_exchange_info': True,
            'get_exchange_tickers': True,
            'get_symbol_price': True,
            'get_symbol_price_from_order_book': True,
            'get_order_book_for_symbol': True,
            'create_order': True,
            'get_order': True,
            'cancel_order': True,
            'queue_algo_order': True,
            'get_algo_order': True,
            'get_algo_orders': True,
            'algo_order_finished': True,
            'get_symbols_with_less_than_fee_maker': True,
            'get_symbols_with_less_than_fee_taker': True,
            'pass_all_assets_to_asset': True,
            'balance_symbol': True,
            'is_symbol_active': True,
            'amount_to_precision': True,
            'price_to_precision': True,
            'symbol_min_amount': True,
            'symbol_min_cost': True,
            'symbol_tick_size': True,
            'check_order_open': True,
            'get_order_status': True,
            'get_orders': True,
            'get_markets': True,
            'sell_total_asset': True,
            'create_orders': True,
            'get_allowed_symbols_to_trade': True,
            'dual_investment_get_products': True,
            'dual_investment_get_positions': True,
            'dual_investment_subscribe_product': True,
            'stop': True
        }

    @classmethod
    def get_separator(cls):
        """
        get_separator
        =============
        Return the field separator used to delimit base64(JSON) payload and signature.

        Returns:
        --------
        str
            Separator string inserted between encoded payload and signature.
        """
        return '____|____'
