"""Nomad Backup (NBKP) - An rsync-based backup tool."""

__version__ = "0.2.1"
