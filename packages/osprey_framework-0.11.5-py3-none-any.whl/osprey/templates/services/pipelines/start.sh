#!/bin/bash
# Pipelines startup wrapper - installs framework before starting server
set -e

echo "=============================================="
echo "Starting Pipelines Container"
echo "=============================================="

# Install uv for fast package management
curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"

# Install project dependencies (including framework)
if [ -f "/pipelines/repo_src/requirements.txt" ]; then
    echo "Installing project dependencies from requirements.txt..."
    uv pip install --system --no-cache -r /pipelines/repo_src/requirements.txt
    echo "✓ Project dependencies installed successfully"
else
    echo "WARNING: /pipelines/repo_src/requirements.txt not found"
    echo "Installing framework as fallback (includes Claude Code SDK)..."
    uv pip install --system "osprey-framework>=0.9.6"
fi

# Development mode override - install local osprey AFTER everything else
if [ "$DEV_MODE" = "true" ]; then
    # Find and install osprey wheel if it exists
    OSPREY_WHEEL=$(find /pipelines -maxdepth 1 -name "osprey_framework-*.whl" | head -1)

    if [ -n "$OSPREY_WHEEL" ]; then
        echo "🔧 Development mode: Installing local osprey wheel..."
        uv pip install --system --no-cache --force-reinstall --no-deps "$OSPREY_WHEEL"
        echo "✓ Osprey overridden with local development version from wheel"
    else
        echo "⚠️  Dev mode enabled but no osprey wheel found, using PyPI version"
    fi
else
    echo "📦 Using PyPI osprey version"
fi

# Verify pipeline interface files exist
if [ -n "$PIPELINES_DIR" ] && [ -f "$PIPELINES_DIR/main.py" ]; then
    echo "✓ Pipeline interface found at $PIPELINES_DIR/main.py"
    ls -la "$PIPELINES_DIR"
else
    echo "WARNING: Pipeline interface not found at $PIPELINES_DIR"
    echo "Make sure main.py was copied during project initialization"
fi

# Call the original pipelines start script
echo "Starting pipelines server..."
cd /app
exec bash start.sh
