#!/usr/bin/env python3

"""This script contains a function that allow to regroup variables from a CMIP6 dictionary into a single xarray Dataset.
The dictionary is provided for a given experiment_id, source_id and member_id, dubbed as an "entry".

To give a simple example : we load the clt and tas variables for GFDL-CM4.r1i1p1f1, a source_id.member_id couple, and for two experiments : piClim-aer and piClim-control.
Intake-esgf generates a single dictionary with four xarray Datasets. This condensing_dictionary script, will generate two xarray Datasets, one per experiment_id, into a dictionary. 

Optionally, the climatology of each variable can be computed according to the user-defined parameters and options.

Functions :

condense_all_variables_from_entry_into_one_dataset : Regroups the variables of a CMIP6 dictionary, that are stored as xarray Datasets for a given experiment_id, source_id and member_id, into an unique xarray Dataset.

Author : GIBONI Lucas

Feel free to copy, adapt and modify it under the provided license.
"""

##################################
### IMPORTATION OF THE MODULES ###
##################################

### DATA OBJECTS AND ASSOCIATED COMPUTATION ###

import xarray as xr  # This is imported to handle xarray objects.

### PROJECT MODULES ###

## Xarray datasets ##

from import_cmip6_data_utils.tools.dataset import (
    generate_climatology,  # This is to generate the climatology when condensing the dictionary.
    add_one_variable_to_dataset,  # It is to modify a dataset in-place by adding new variables.
)

###################################
### DEFINITION OF THE FUNCTIONS ###
###################################

######################################################
### CONDENSE_SAME_ENTRY_VARIABLES_INTO_ONE_DATASET ###
######################################################

def condense_all_variables_from_entry_into_one_dataset(
    downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids: dict[
        str, xr.Dataset
    ],
    wanted_description_facets: list[str],
    do_climatology: bool,
    frequency_for_climatology: str = None,
) -> xr.Dataset:
    """Regroups the variables of a CMIP6 dictionary, that are stored as xarray Datasets for a given experiment_id, source_id and member_id, into an unique xarray Dataset.

    Parameters
    ----------

    downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids : dict[str, xr.DataArray]

        Dictionary of the different xarray Datasets for each variable downloaded for a given experiment_id, source_id and member_id.

    wanted_description_facets : list[str]

        List of the description facets we kept from the full facets description of intake-esgf

    do_climatology : bool

        Bool describing if the climatology of the variable needs to be done before adding it.

    frequency_for_climatology : str, optional

        Frequency of the wanted climatology to provide if do_climatology is set to True, by default None. It can be "day", "month" or "season".

    Returns
    -------
    condensed_dataset : xr.Dataset

        Dataset where the different variables present in the input CMIP6 dictionary were regrouped.
    """

    ### INITIALISE ###

    ## Extract the list of keys for this given source and member id couple ##

    list_of_keys = list(
        downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids.keys()
    )

    ## Find the list of the variable from the dictionary keys ##

    # We find the index of the variable_id in a splitted_key #

    index_of_variable_id = wanted_description_facets.index("variable_id")

    # We split the keys of the list of keys #

    list_of_splitted_keys = [key.split(".") for key in list_of_keys]

    # We finally extract the list of variables for this experiment_id, member_id and source_id #

    list_of_variables = [
        splitted_key[index_of_variable_id] for splitted_key in list_of_splitted_keys
    ]

    ## Initialise the xarray Dataset ##

    # Get the first key for the dictionary we want to condense and first variable associated to it #

    key = list_of_keys[0]

    variable_name = list_of_variables[0]

    # Define that the dataset does not exist yet #

    modify_data = False

    ## Initialise the dataset ##

    variable_dataset = (
        downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids[
            key
        ]
    )

    if do_climatology:
        # True : the climatology of the variable is computed #

        variable_dataset = generate_climatology(
            dataset=variable_dataset,
            variable_to_compute_climatology=variable_name,
            frequency=frequency_for_climatology,
        )

    ## Creation of the dataset ##

    condensed_dataset = add_one_variable_to_dataset(
        variable_name=variable_name,
        variable_dataset=variable_dataset,
        modify_data=modify_data,
    )

    ## Set that now the dataset already exists ##

    modify_data = True

    for key, variable_name in zip(list_of_keys, list_of_variables):
        variable_dataset = downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids[
            key
        ]

        ## Checking if the climatology needs to be done on the variable ##

        if do_climatology:
            # True : the climatology of the variable is computed #

            variable_dataset = generate_climatology(
                dataset=variable_dataset,
                variable_to_compute_climatology=variable_name,
                frequency=frequency_for_climatology,
            )

        ## Update the dataset ##

        condensed_dataset = add_one_variable_to_dataset(
            variable_name=variable_name,
            variable_dataset=variable_dataset,
            dataset=condensed_dataset,
            modify_data=modify_data,
        )

    return condensed_dataset

######################
### USED FOR TESTS ###
######################

if __name__ == "__main__":
    pass
