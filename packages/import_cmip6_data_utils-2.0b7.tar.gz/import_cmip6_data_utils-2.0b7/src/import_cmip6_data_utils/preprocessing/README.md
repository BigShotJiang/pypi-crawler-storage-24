# ./import_cmip6_data_utils/preprocessing

## Description of the full subpackage

This subpackage is dedicated to condensing raw intake-esgf catalog outputs into more compact and readable dictionaries. It is used by the **load** subpackage.

- **condense_dictionary**, is dedicated to regrouping variables from the same entry (which is an experiment_id, source_id and member_id tuple) within a CMIP6 dictionary into the same xarray dataset. 

- **reduce_couple_dictionary_keys**, is used to reduce the dictionary description keys to what the user wants. Its main function is **only_keep_wanted_facets_in_couple_dictionary** while the other functions are utilitary functions used to achieve the goal of the script.

## condense_dictionary

### Description of the script

This script contains functions that allow to regroup variables from the same model entry into the same xarray dataset. What we mean by entry is a given **source_id, member_id and experiment_id** tuple.

To give a simple example : if the **clt** and **tas** variables were loaded for GFDL-CM4.r1i1p1f1, a **source_id.member_id couple**, and for two experiments : **piClim-aer** and **piClim-control**, then intake-esgf generates a single dictionary with **four xarray Datasets**. This **condensing_dictionary** script, will generate **two xarray Datasets**, one per experiment_id, into a dictionary.

Optionally, the climatology of each variable can be computed according to the user-defined parameters and options.

### Functions

**condense_all_variables_from_entry_into_one_dataset** : Regroups the variables of a CMIP6 dictionary, that are stored as xarray Datasets for a given experiment_id, source_id and member_id, into an unique xarray Dataset.

### Inputs

The inputs of this script are CMIP6 data **dictionaries**. They are composed of **xarray Datasets** of variables associated to different catalog entries.-

### Outputs

The outputs are **xarray Datasets**. All the variables associated to the same entries have been regrouped into a single dataset.

## reduce_couple_dictionary_keys

### Description of the script

This script contains functions to edit the dictionary keys of a CMIP6 dictionary associated to a model.variant couple.

We only keep, for a given source and member id couple, the facets in the provided **wanted_description_facets**.

### Functions

**define_facets_to_ignore_for_couple** : Defines the facets that will be ignored for a given model_variant couple dictionary keys.

**find_index_of_kept_facets** : Finds the index of the facets to be kept in the splitted full catalog facets.

**only_keep_wanted_facets_in_key** : Modifies a key to keep only the wanted facets within it.

**only_keep_wanted_facets_in_couple_dictionary** : Modifies the keys of a model.variant couple dictionary according to the wanted description facets.

### Inputs

These functions deal with **str** CMIP6 keys that are organised in terms of facets. One full key is organised like this :

```'mip_era.activity_drs.institution_id.source_id.experiment_id.member_id.table_id.variable_id.grid_label'```

They can be splitted under the form of a list :

```['mip_era','activity_drs','institution_id','source_id','experiment_id','member_id','table_id''variable_id','grid_label']```

For more details on the facets see : <http://goo.gl/v1drZl> (last visited 01/09/2025).

### Outputs

The outputs are **dictionaries of xarray Datasets** whose keys have been reduce only to the **wanted_description_facets**.