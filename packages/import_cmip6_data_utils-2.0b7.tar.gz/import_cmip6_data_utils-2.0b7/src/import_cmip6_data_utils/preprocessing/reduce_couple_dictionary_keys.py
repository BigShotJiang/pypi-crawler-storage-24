#!/usr/bin/env python3

"""This script contains functions to edit the dictionary keys of a CMIP6 dictionary associated to a model.variant couple.

Its main function is only_keep_wanted_facets_in_couple_dictionary whose goal is to reduce the facets contained in the given CMIP6 dictionary keys.

We only keep, for a given source and member id couple, the facets in the provided wanted_description_facets.

A given choice of wanted_description_facets may sometimes lead to bugs as not all the possible outcomes have been explored for a given csv criteria file.

Functions :
-----------

define_facets_to_ignore_for_couple : Defines the facets that will be ignored for a given model_variant couple dictionary keys.

find_index_of_kept_facets : Finds the index of the facets to be kept in the splitted full catalog facets.

only_keep_wanted_facets_in_key : Modifies a key to keep only the wanted facets within it.

only_keep_wanted_facets_in_couple_dictionary : Reduces the keys of a model.variant couple dictionary to the wanted description facets only.

Author : GIBONI Lucas

Feel free to copy, adapt and modify it under the provided license.
"""

##################################
### IMPORTATION OF THE MODULES ###
##################################

### DOWNLADING THE ENTRIES ###

import intake_esgf  # This gives us access to the ESGF catalog to make queries.

### DATA OBJECTS AND ASSOCIATED COMPUTATION ###

import numpy as np  # It is imported to work on the pandas arrays.

import xarray as xr  # This package is used to handle xarrays.

### TYPE HINTS ###

from numpy.typing import NDArray

###############################################
#### ONLY_FACETS_TO_IGNORE_FOR_COUPLE_ENTRY ###
###############################################


def define_facets_to_ignore_for_couple(
    filled_catalog_for_given_couple: intake_esgf.ESGFCatalog,
    wanted_description_facets: list[str],
) ->  list[str]:
    """Defines the facets that will be ignored for a given model.variant couple dictionary keys.

    Parameters
    ----------

    filled_catalog_for_given_couple : intake_esgf.ESGFCatalog

        Intake-esgf catalog filled with the provided search criteria and the source_id and member_id of the couple.

    wanted_description_facets : list[str]

        List of the wanted description facets for the couple dictionary keys.

    Returns
    -------
    facets_to_ignore : list[str]

        List of the facets to be ignored for the coupel dictionary keys.

    Raises
    ------
    TypeError
        If wanted_description_facets is not defined.
    """

    ### DEFINING THE ORIGINAL FULL LIST OF FACETS ###

    full_used_facets = filled_catalog_for_given_couple.project.master_id_facets()

    ### GENERATE THE FACETS TO IGNORE BASED ON THE WANTED DESCRIPTION KEYS ###

    ## Remove the wanted description facets from the full list of used facets ##

    facets_to_ignore = np.setdiff1d(full_used_facets, wanted_description_facets)

    ## Transform the facets to ignore from an array of np.str to a list[str] ##

    facets_to_ignore = [str(facet_to_ignore) for facet_to_ignore in facets_to_ignore]

    return facets_to_ignore


##################################
#### FIND_INDEX_OF_KEPT_FACETS ###
##################################


def find_index_of_kept_facets(
    facets_to_ignore: list[str],
    full_catalog_facets: list[str],
) -> list[int]:
    """Finds the index of the facets to be kept in the list of the full catalog facets.

    Parameters
    ----------
    facets_to_ignore : list[str]

        List of the facets to be ignored within the full catalog facets.

    full_catalog_facets : list[str]

        Ordered list of the full catalog facets used to describe an entry key the CMIP6 dictionary.

    Returns
    -------
    index_of_kept_facets : list[int]

        List of the index of the facets that will be kept.
    """

    ### GENERATES THE LIST OF THE INDEX OF KEPT FACETS ###

    index_of_kept_facets = [
        ii
        for ii, facet in enumerate(full_catalog_facets)
        if facet not in facets_to_ignore
    ]

    return index_of_kept_facets


#######################################
#### ONLY_KEEP_WANTED_FACETS_IN_KEY ###
#######################################


def only_keep_wanted_facets_in_key(
    full_key: str,
    index_of_kept_facets: list[int],
) -> str:
    """Modifies a key to keep only the wanted facets within it.

    Parameters
    ----------
    full_key : str

        Full key to be reduced.

    index_of_kept_facets : list[int]

        List of the index of the facets to keep in the splitted key.

    Returns
    -------
    key_with_wanted_facets : str

        Key reduced to the wanted facets.

    """
    full_key_splitted = full_key.split(".")

    new_key_splitted = [full_key_splitted[index] for index in index_of_kept_facets]

    key_with_wanted_facets = ".".join(new_key_splitted)

    return key_with_wanted_facets


#####################################################
#### ONLY_KEEP_WANTED_FACETS_IN_COUPLE_DICTIONARY ###
#####################################################


def only_keep_wanted_facets_in_couple_dictionary(
    catalog: intake_esgf.ESGFCatalog,
    cmip6_dictionary: dict[str, xr.Dataset],
    wanted_description_facets: list[str],
    verbose: bool = False,
) -> dict[str, xr.Dataset]:
    """Modifies the keys of a model.variant couple dictionary according to the wanted description facets.

    Originally we download dictionaries for a given couple with the full description keys :

    'mip_era.activity_drs.institution_id.source_id.experiment_id.member_id.table_id.variable_id.grid_label'

    We preserve, for a given source and member id couple, the facets written in wanted_description_facets.

    Parameters
    ----------

    catalog: intake_esgf.ESGFCatalog,

        Catalog that was filled by the search for the given model.variant couple.

    cmip6_dictionary : dict[str, xr.Dataset]

        CMIP6 dictionary holding the different entries.

    wanted_description_facets : list[str]

        List of the wanted description facets for the couple dictionary keys.

    verbose : bool, optional

        Bool defining if the function needs to print information, by default False.

    Returns
    -------
    updated_dictionary : dict[str, xr.Dataset]

        Model.variant couple dictionary with the keys reduced according to the wanted facets.
    """

    ### INITIALISATION ###

    ## Extract the full catalog facets description list ##

    full_catalog_facets = catalog.project.master_id_facets()

    ## Find the facets to ignore for the given couple ##

    facets_to_ignore = define_facets_to_ignore_for_couple(
        filled_catalog_for_given_couple=catalog,
        wanted_description_facets=wanted_description_facets,
    )

    ## Find the index of the facets to keep ##

    index_of_kept_facets = find_index_of_kept_facets(
        facets_to_ignore=facets_to_ignore,
        full_catalog_facets=full_catalog_facets,
    )

    ## Initialise the updated dictionary ##

    updated_dictionary = {}

    ### LOOP THROUGH THE KEYS ###

    # If wanted the first edited key is printed

    if verbose:
        show_first_key = True

    else:
        show_first_key = False

    for key in cmip6_dictionary.keys():
        ## Editing the key by keeping the wanted facets only ##

        key_with_wanted_facets = only_keep_wanted_facets_in_key(
            full_key=key,
            index_of_kept_facets=index_of_kept_facets,
        )

        # If wanted the first edited key is printed

        if show_first_key:
            print(
                "\nUpdating the key {} into {}.\n".format(key, key_with_wanted_facets)
            )

            show_first_key = False

        ## Setting this key to the updated dictionary ##

        updated_dictionary[key_with_wanted_facets] = cmip6_dictionary[key]

    return updated_dictionary
