# ./import_cmip6_data_utils/download

## Description of the full subpackage

This subpackage is dedicated to the downloading of the CMIP6 data through the **full_catalog** script. It is constructed linearly following this order :

- **prepare** is dedicated to preparing the download by setting the folder in which the data is saved, with **set_folder_to_save_raw_data**.

- **download_full_catalog** is the main function of the whole **import_cmip6_data_module**. It uses functions from the **preprocessing** and **tools** subpackages.

## prepare

### Description of the script

This script contains a function to prepare the download of the CMIP6 data.

### Functions

**set_folder_to_save_raw_data** : This function sets the path of the folder in which the data will be saved.

### Inputs

This script receives the **str** path of the folder in which the data will be saved.

### Outputs

It creates the folder in which the downloaded data will be saved.

## full_catalog

### Description of the script

This script contains a function to download and save the full catalog by **entries**. That is to say by splitting it by **experiment_id, source_id and member_id**.

### Functions

**download_full_catalog** : Downloads, as netcdf files, the full catalog by splitting it by experiment_id, source_id and member_id.

The result is a dictionary of dictionaries of xarray Datasets, whose keys are the different experiment_ids searched by the user. For a given experiment_id, the variables of a given model.variant couple are regrouped into the same xarray Dataset. The datasets produced for the entries of a given couple can be associated to simpler description keys than the ones of the full catalog. The climatology of each variable is optionally computed.

This function uses intake-esgf **to download** the data at the **save_path/CMIP6** path. We handle one **experiment_id, source_id and member_id** at a time, to ease the memory load.

To give a simple example : you wish to download the **clt** variable for GFDL-CM4.r1i1p1f1 and IPSL-CM6A-LR.r1i1p1f1, representing two **source_id.member_id couples**, for two experiments : **piClim-aer** and **piClim-control**. Then we will realise a for loop in order to download the **clt** variable for every experiment_id and for every **source_id and member_id couples**. A first entry downloaded could be piClim-control.GFDL-CM4.r1i1p1f1.clt.

### Inputs

It receives all the user criteria and options defined in the *import_cmip6_data* notebook by the user.
The script also takes as an input the intake-esgf catalog filled for by the full search.

### Outputs

It downloads the full catalog and saves several netcdf files for each model.variant couple. Each file is associated to a **xarray.Dataset** defined for a given entry from the catalog. The climatology of the variables of the dataset can be computed if the user asks so.
