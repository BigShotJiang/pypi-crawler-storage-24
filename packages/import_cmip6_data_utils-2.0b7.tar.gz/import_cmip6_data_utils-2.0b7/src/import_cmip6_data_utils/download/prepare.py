#!/usr/bin/env python3

"""This script contains a function to prepare the download of the CMIP6 data.

Functions :
-----------

set_folder_to_save_raw_data : This function sets the path of the folder in which the data will be saved.

Author : GIBONI Lucas

Feel free to copy, adapt and modify it under the provided license.
"""


##################################
### IMPORTATION OF THE MODULES ###
##################################

# ================ IMPORTATIONS ================ #

### LOAD AND NAVIGATE THROUGH THE DATA ###

import intake_esgf  # This package gives us access to the ESGF catalog to make queries.

### DATA OBJECTS AND ASSOCIATED COMPUTATION ###

import pandas as pd  # It is imported to manage the product of the search.

### HANDLING PATHS ###

from os.path import join  # This is used to join two paths together.

### PROJECT MODULES ###

## Create directories and clean them ##

from import_cmip6_data_utils.tools.folders import (
    create_dir,  # It is used to create a cleaned directory in which the downloaded data will be stored.
)

###############################
#### SET_DOWNLOADING_FOLDER ###
###############################

def set_folder_to_save_raw_data(
    parent_path: str,
    download_folder_name: str,
    clear: bool = True,
    verbose: bool = False,
):
    """This function sets the path of the folder in which the data will be saved.

    Parameters
    ----------

    parent_path : str

        Parent path of the folder in which the data will be saved.

    download_folder_name : str

        Name of the folder in which the data will be saved.

    clear : bool, optional

        Bool defining we clear the tree or not, by default True.

    verbose : bool, optional

        Bool defining if the function needs to print information, by default False.
    """
    ### CREATE THE DIRECTORY ###

    download_path = create_dir(
        parent_path=parent_path,
        name=download_folder_name,
        clear=clear,
    )

    ### SET THE DOWNLOAD FOLDER PATH ###

    intake_esgf.conf.set(local_cache=download_path)

    ### SET THE PATH VARIABLES ###

    ## Write the full path of the raw data ##

    full_path_raw_data = join(download_path, "CMIP6")

    ## Write the full path of the preprocessed data ##

    full_path_preprocessed = join(download_path, "preprocessed")

    # If wanted prints the setting.

    if verbose:
        print(
            "\nThe folder in which the raw data will be downloaded is under the path {}.\n".format(
                full_path_raw_data
            )
        )

        print(
            "\nThe folder in which the preprocessed data will be saved is under the path {}.\n".format(
                full_path_preprocessed
            )
        )

    return download_path

######################
### USED FOR TESTS ###
######################

if __name__ == "__main__":
    pass
