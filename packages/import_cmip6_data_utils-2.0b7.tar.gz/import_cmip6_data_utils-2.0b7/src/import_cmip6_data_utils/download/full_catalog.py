#!/usr/bin/env python3

"""This script contains a function to download and save the full catalog by entries. That is to say by splitting it by experiment_id, source_id and member_id.


Functions :
-----------

download_full_catalog : Downloads and saves the full catalog by splitting it into its different experiment_ids by downloading one model.variant couple at a time.

Functions :

Author : GIBONI Lucas

Feel free to copy, adapt and modify it under the provided license.
"""

##################################
### IMPORTATION OF THE MODULES ###
##################################

### DOWNLADING THE ENTRIES ###

from os.path import join  # It is used to joined two paths together.

### HANDLING FILES FROM PYTHON ###
from shutil import rmtree  # This is imported to remove the raw data if asked.

import intake_esgf  # This gives us access to the ESGF catalog to make queries.

### EXCEPTIONS OF INTAKE-ESGF ###
import intake_esgf.exceptions as intake_exception  # This is imported to raise intake-esgf specific exceptions

### DATA OBJECTS AND ASSOCIATED COMPUTATION ###
import pandas as pd  # This is to manage the product of the search
import xarray as xr  # This is to handle xarray objects.

### HANDLE THE OUTPUTS OF JUPYTER CELLS ###
from IPython.display import (
    clear_output,
)  # It is to clear the output of a Jupyter cell from intake-esgf information.

## Condensing the couple dictionary entries by regrouping the same entry variables into one dataset ##
from import_cmip6_data_utils.preprocessing.condense_dictionary import (
    condense_all_variables_from_entry_into_one_dataset,  # This is used to regroup the variables of the same model.variant couple in the same xarray Dataset within an experiment_id dictionary.
)

### PROJECT MODULES ###
## Reducing the keys of the CMIP6 dictionaries ##
from import_cmip6_data_utils.preprocessing.reduce_couple_dictionary_keys import (
    only_keep_wanted_facets_in_couple_dictionary,  # It is imported to reduce the information within the keys of a model.variant dictionary.
)

## Saving the couple dictionary entries as netcdf files ##
from import_cmip6_data_utils.tools.save_and_load_netcdf import (
    save_dictionary_entries_to_nectdf,  # This is imported to save each entry of a CMIP6 dictionary to a netcdf file and returns its path.
)

##############################
#### DOWNLOAD_FULL_CATALOG ###
##############################


def download_full_catalog(
    filled_catalog: intake_esgf.ESGFCatalog,
    wanted_description_facets: list[str],
    add_measures: bool,
    do_climatology: bool,
    frequency_for_climatology: str,
    save_path: str,
    clear: bool,
    remove_raw_data: bool,
    verbose: bool = False,
) -> dict[str, dict[str, xr.Dataset]]:
    """Downloads, as netcdf files, the full catalog by splitting it by experiment_id.

    The result is a dictionary of dictionaries of xarray Datasets, whose keys are the different experiment_ids searched by the user.
    For a given experiment_id, the variables of a given model.variant couple are regrouped into the same xarray Dataset.

    The datasets produced for the entries of a given couple can be associated to simpler description keys than the ones of the full catalog.
    The climatology of each variable is optionally computed.

    Parameters
    ----------
    filled_catalog: intake_esgf.ESGFCatalog,

        Catalog filled by the full search.

    wanted_description_facets : list[str]

        List of the wanted description facets for the couple dictionary keys.

    add_measures : bool

        Bool defining if the measure variables need to be loaded for every variable.

    do_climatology : bool

        Bool defining if the climatologies are computed.

    frequency_for_climatology : str

        Frequency of the climatology : can be "day", "month" and "seasons", for more details see https://xcdat.readthedocs.io/en/latest/generated/xarray.Dataset.temporal.climatology.html.

    save_path : str

        Path leading to the folder in which the entries are stored.
        The preprocessed entries will be saved under a "/preprocessed" folder while the raw data under a "/CMIP6" folder.

    clear : bool, optional

        Bool defining whether we clear save_path or not.

    remove_raw_data : bool

        Bool defining if the raw data needs to be erased from disk or not.

    verbose : bool, optional

        Bool defining if the function needs to print information, by default False.

    Returns
    -------
    cmip6_dictionary : dict[str, dict[str, xr.Dataset]]

        Dictionary linking experiment_ids to their dicitonary of CMIP6 entries.

    """
    ### INITIALISATION ###

    ## Initialise the CMIP6 dictionary ##

    cmip6_dictionary = {}

    ## Extracting the full catalog information ##

    # Test wether wanted_description_facets is defined #

    if wanted_description_facets is None:
        # Then the user wants ALL descriptions facets #

        wanted_description_facets = filled_catalog.project.master_id_facets()

    # Retrieving the filled catalog under a pandas DataFrame #

    catalog_df = filled_catalog.df

    # Storing it in a variable #

    full_catalog_df = catalog_df

    ## Initialise a new intake-esgf catalog ##

    catalog = intake_esgf.ESGFCatalog()

    ## Listing the experiment ids present in the catalog ##

    list_of_experiment_ids = list(catalog_df.experiment_id.drop_duplicates().values)

    ### GOING THROUGH EACH EXPERIMENT_ID ###

    for experiment_id in list_of_experiment_ids:
        ## Initialising the dictionary for the given experiment_id ##

        dict_for_given_experiment_id = {}

        ## Extracting the catalog dataframe for this experiment_id ##

        # Extract the full catalog dataframe #

        catalog_df_for_specific_experiment_id = full_catalog_df[
            full_catalog_df["experiment_id"] == experiment_id
        ]

        # Extract the catalog dataframe reduced to source_id and member_id #

        catalog_df_for_specific_experiment_id_reduced_to_source_and_member_ids = (
            catalog_df_for_specific_experiment_id[
                ["source_id", "member_id"]
            ].drop_duplicates()
        )

        # If asked we say that look at this given experiment_id

        if verbose:
            print("\nCreating the CMIP6 dictionary for {}.\n".format(experiment_id))

        ### GOING THROUGH EACH SOURCE_ID AND MEMBER_ID COUPLE FOR THIS GIVEN EXPERIMENT ###

        for (
            source_id,
            member_id,
        ) in zip(
            catalog_df_for_specific_experiment_id_reduced_to_source_and_member_ids[
                "source_id"
            ],
            catalog_df_for_specific_experiment_id_reduced_to_source_and_member_ids[
                "member_id"
            ],
        ):
            ## Generate the couple key for the experiment dictionary ##

            couple_key = source_id + "." + member_id

            ## Reduce the catalog of the experiment id information to this couple ##

            catalog_df_for_specific_experiment_id_at_given_source_and_member_ids = (
                catalog_df_for_specific_experiment_id[
                    (
                        (
                            catalog_df_for_specific_experiment_id["source_id"]
                            == source_id
                        )
                        & (
                            catalog_df_for_specific_experiment_id["member_id"]
                            == member_id
                        )
                    )
                ]
            )

            ### SET THE INTAKE ESGF CATALOG INFORMATION FOR THE DOWNLOAD ###

            catalog.df = (
                catalog_df_for_specific_experiment_id_at_given_source_and_member_ids
            )

            ### DOWNLOAD THE DICTIONARY ###

            try:
                ## Display information to the user if asked ##

                if verbose:
                    print("\n==============================\n")

                    print(
                        "\nDownloaded the CMIP6 dictionary for {} for {} experiment.\n".format(
                            couple_key, experiment_id
                        )
                    )

                ## Download the dictionary ##

                downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids = catalog.to_dataset_dict(
                    minimal_keys=False,
                    add_measures=add_measures,
                )

            except intake_exception.IntakeESGFException as breaking_exception:
                raise breaking_exception

            ### SIMPLIFY THE KEYS ACCORDING TO WHAT WAS ASKED BY THE USER ###

            downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids = only_keep_wanted_facets_in_couple_dictionary(
                catalog=catalog,
                cmip6_dictionary=downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids,
                wanted_description_facets=wanted_description_facets,
                verbose=verbose,
            )

            ### CONDENSE THE DICTIONARY INTO ONE DATASET ###

            # If wanted we say that we condense the current dictionary

            if verbose:
                print(
                    "\nCondensing the variables of {} into a single dataset for {} experiment.\n".format(
                        couple_key, experiment_id
                    )
                )

            condensed_dataset = condense_all_variables_from_entry_into_one_dataset(
                downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids=downloaded_dictionary_for_specific_experiment_id_at_given_source_and_member_ids,
                wanted_description_facets=wanted_description_facets,
                do_climatology=do_climatology,
                frequency_for_climatology=frequency_for_climatology,
            )

            ### ADD TO THE EXPERIMENT_ID DICTIONARY  ###

            dict_for_given_experiment_id[couple_key] = condensed_dataset

            # If wanted it closes the verbose display for this couple.

            if verbose:
                print("\n==============================\n")

        ### SAVE THE FULL DICTIONARY FOR THE EXPERIMENT_ID ###

        # We display the saving process #

        if verbose:
            print(
                "\nSaving the dictionary for {} experiment.\n".format(
                    experiment_id,
                )
            )

        ## Remove what was printed for this experiment_id ##

        clear_output(wait=False)

        ### ADD TO THE CMIP6 FULL DICTIONARY ###

        cmip6_dictionary[experiment_id] = (
            dict_for_given_experiment_id  ## Remove the raw data ##
        )

    ### REMOVING THE RAW DATA IF ASKED ###

    if remove_raw_data:
        ## Generate the path of the raw data ##

        full_path_raw_data = join(save_path, "CMIP6")

        # If wanted the user is informed of the removing.

        print("Removing the raw data located at {}".format(full_path_raw_data))

        rmtree(full_path_raw_data)

    return cmip6_dictionary
