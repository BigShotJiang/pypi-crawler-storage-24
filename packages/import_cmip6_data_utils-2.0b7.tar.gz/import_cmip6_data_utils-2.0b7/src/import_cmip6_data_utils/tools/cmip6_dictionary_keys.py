#!/usr/bin/env python3

"""This script contains functions used to handle the keys of a CMIP6 dictionary.

These functions deal with str CMIP6 keys that are organised in terms of facets. One full key is organised like this :

'mip_era.activity_drs.institution_id.source_id.experiment_id.member_id.table_id.variable_id.grid_label'

They can be splitted under the form of a list :

['mip_era','activity_drs','institution_id','source_id','experiment_id','member_id','table_id','variable_id','grid_label']

For more details on the facets see : <http://goo.gl/v1drZl> (last visited 01/09/2025).

Functions :

find_facet_index : Finds the index associated to a specific facet in a provided dictionary key.

remove_facet_name_at_facet_index : Removes the facet name of the provided CMIP6 dictionary key at the given index.

Author : GIBONI Lucas

Feel free to copy, adapt and modify it under the provided license.
"""

##################################
### IMPORTATION OF THE MODULES ###
##################################

### DATA OBJECTS AND ASSOCIATED COMPUTATION ###

import numpy as np  # It is to handle numpy arrays and the associated tools.

import xarray as xr  # This is imported to handle xarray objects.

### TYPE HINTS FOR FUNCTIONS ###

from numpy.typing import NDArray  # It is used for type hinting for the numpy library.

###################################
### DEFINITION OF THE FUNCTIONS ###
###################################

########################
### FIND_FACET_INDEX ###
########################


def find_facet_index(
    key_cmip6_dictionary: str,
    search_facets_dictionary: dict[str, list[str]],
    facet_name: str,
) -> np.int64:
    """Finds the index associated to a specific facet in a provided splitted dictionary key.

    It uses the provided search facets and looks for a given facet, for example variable_id, in a splitted key of a dowloaded cmip6 dictionary.
    As a result, the function provides the index associated to the variable_id facet in all the keys of the dictionary.

    Parameters
    ----------
    key_cmip6_dictionary : str

        A key from a dictionary of CMIP6 datasets.

    search_facets_dictionary : dict[str, list[str]]

        Search facets provided by the user, used to find the index of facet_name in the dictionary key.

    facet_name : str

        Facet_name whose associated index is searched by the function.

    Returns
    -------
    index_of_facet : np.int64

        Index associated to facet_name in the CMIP6 dictionary.
    """

    ### RETRIEVE THE LIST OF FACETS PROVIDED FOR FACET_NAME ###

    provided_list_for_facet_name = search_facets_dictionary[
        facet_name
    ]  # For example if facet_name is "variable_id", the list could hold "clt".

    ### FINDING THE INDEX ASSOCIATED TO FACET_NAME ###

    ## Using the list to find the corresponding index in the provided key ##

    index_of_facet = np.where(
        np.isin(key_cmip6_dictionary.split("."), provided_list_for_facet_name)
    )[0][0]

    return index_of_facet


########################################
### REMOVE_FACET_NAME_AT_FACET_INDEX ###
########################################


def remove_facet_name_at_facet_index(
    key: str,
    index_facet: int,
) -> str:
    """Removes the facet name of the provided CMIP6 dictionary key at the given index.
    
    Parameters
    ----------
    key : str

        CMIP6 description key that is organised in the following way :

        'mip_era.activity_drs.institution_id.source_id.experiment_id.member_id.table_id.variable_id.grid_label'

        Note that the provided key can be missing facets.

    index_facet : int

        Index at which the facet needs to be removed from the key.

    Returns
    -------
    key_without_facet_at_index : str

        Key without facet at the given index.
    """

    ### SPLIT THE KEY ###
    key_splitted = key.split(".")

    ### REMOVE THE FACET AT THE PROVIDED INDEX ###

    key_splitted.pop(index_facet)

    ### REFORM THE KEY ###

    key_without_facet_at_index = ".".join(key_splitted)

    return key_without_facet_at_index

######################
### USED FOR TESTS ###
######################

if __name__ == "__main__":
    pass
