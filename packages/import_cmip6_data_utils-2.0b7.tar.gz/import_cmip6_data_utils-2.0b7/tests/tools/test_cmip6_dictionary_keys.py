#!/usr/bin/env python3

"""This is a test script for the cmip6_dictionary_keys utilitary functions of the tools subpackage.

Tested Functions :
-----------

find_facet_index : Finds the index associated to a specific facet in a provided dictionary key.

remove_facet_name_at_facet_index : Removes the facet name of the provided CMIP6 dictionary key at the given index.

Author : GIBONI Lucas

Feel free to copy, adapt and modify it under the provided license.
"""

##################################
### IMPORTATION OF THE MODULES ###
##################################

### TESTS ###

import pytest # This is used to test functions. 

### DATA OBJECTS AND ASSOCIATED COMPUTATION ###

import pandas as pd  # This is to read csv files.

### HANDLING PATHS ###
from os.path import (
    dirname, # Used to give us the absolute path of the parent directory of this script.
    realpath,  # To get the absolute path of this script.
    join, # To join two paths together without handling "/"
)

### PROJECT MODULES ###

## Handle dictionary keys ##

from import_cmip6_data_utils.tools.cmip6_dictionary_keys import (
    find_facet_index, # This is to find the index of a given facet.
    remove_facet_name_at_facet_index, # It removes the facet name of the provided CMIP6 dictionary key at the given index.
)

## Extract search criteria ##

from import_cmip6_data_utils.tools.csv_criteria import (
    extract_search_facets,  # It is to read a provided csv file holding the search criteria and generate a dictionary of the search facets.
)
########################
### GLOBAL VARIABLES ###
########################

### PATHS ###

## Absolute path of this script ##

abs_path_of_this_script = dirname(realpath(__file__))

## Path of the test criteria files ##

path_to_csv_criteria_files = join(abs_path_of_this_script, "../criteria")

### GENERATE A MOCK SEARCH_FACETS_DICTIONARY ###

test_search_facets_dictionary = extract_search_facets(
    path_to_csv_criteria_files, "search-criteria-test.csv"
)

#########################
### FIND_FACETS_INDEX ###
#########################

### TEST OUTPUT AS EXPECTED ###

def test_output_find_facets_index() -> bool :
    assert find_facet_index(
    key_cmip6_dictionary = "piClim-control.GFDL-CM4.r1i1p1f1.tas",
    search_facets_dictionary = test_search_facets_dictionary,
    facet_name = "variable_id",
) == 3


########################################
### REMOVE_FACET_NAME_AT_FACET_INDEX ###
########################################

### TEST OUTPUT AS EXPECTED ###

def test_output_remove_facet_name_at_facet_index() -> bool:
    assert remove_facet_name_at_facet_index(
    key = "piClim-control.GFDL-CM4.r1i1p1f1.tas",
    index_facet = 3
) == "piClim-control.GFDL-CM4.r1i1p1f1"