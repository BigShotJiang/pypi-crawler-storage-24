#!/usr/bin/env python3

"""This is a test script for the csv_criteria utilitary functions of the tools subpackage.

Tested Functions :
-----------

csv_to_dataframe : Reads the provided csv file and generates a panda dataframe from it.

extract_search_facets : Reads the provided csv file holding the search criteria and generates a dictionary of the search facets.

Author : GIBONI Lucas

Feel free to copy, adapt and modify it under the provided license.
"""

##################################
### IMPORTATION OF THE MODULES ###
##################################

### TESTS ###

import pytest # This is used to test functions. 

### DATA OBJECTS AND ASSOCIATED COMPUTATION ###

import pandas as pd  # This is to read csv files.

### HANDLING PATHS ###
from os.path import (
    dirname, # Used to give us the absolute path of the parent directory of this script.
    realpath,  # To get the absolute path of this script.
    join, # To join two paths together without handling "/"
)

### PROJECT MODULES ###

## Extract search criteria ##

from import_cmip6_data_utils.tools.csv_criteria import (
    csv_to_dataframe,  # This is to read a provided csv file and generate a panda dataframe from it.
    extract_search_facets,  # It is to read a provided csv file holding the search criteria and generate a dictionary of the search facets.
)

########################
### GLOBAL VARIABLES ###
########################

### PATHS ###

## Absolute path of this script ##

abs_path_of_this_script = dirname(realpath(__file__))

## Path of the test criteria files ##

path_to_csv_criteria_files = join(abs_path_of_this_script, "../criteria")

########################
### CSV_TO_DATAFRAME ###
########################

### DEFINE PYTEST.FICTURES ###

@pytest.fixture
def example_csv_df()-> pd.DataFrame:
    dict = {"experiment_id" : ["piClim-control"], "variable_id" : ["tas"]}
    wanted_output = pd.DataFrame(dict)
    return wanted_output

### TEST UNDEFINED CSV_FILENAME ###

def test_undefined_csv_filename() -> bool:
    with pytest.raises(FileNotFoundError):
        csv_to_dataframe(path_to_criteria_folder = None, csv_filename = None)

### TEST FILE NOT FOUND ###

def test_file_not_found() -> bool :
    with pytest.raises(FileNotFoundError):
        csv_to_dataframe(path_to_criteria_folder = "~/absurde/path/to/test", csv_filename = "search-criteria-test")

### TEST OUTPUT AS EXPECTED ###

def test_output_csv_to_dataframe(example_csv_df) -> bool :
    assert (csv_to_dataframe(path_to_criteria_folder = path_to_csv_criteria_files, csv_filename = "search-criteria-test") == example_csv_df).all


#############################
### EXTRACT_SEARCH_FACETS ###
#############################

@pytest.fixture
def example_csv_dict()-> dict[str,list[str]]:
    return {"experiment_id" : ["piClim-control"], "variable_id" : ["tas"]}

def test_output_extract_search_facets(example_csv_dict) -> bool:
    assert (extract_search_facets(path_to_criteria_folder = path_to_csv_criteria_files, csv_filename = "search-criteria-test") == example_csv_dict)