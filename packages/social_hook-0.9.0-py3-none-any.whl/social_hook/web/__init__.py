"""Web dashboard API server."""
