"""Summary generation module."""
