"""
Bedrock Agent client for AiCippy.

Invokes the odin Bedrock Agent via invoke_agent API with streaming support.
All AI responses flow through the Bedrock Agent (not raw invoke_model).
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Final

import boto3
from botocore.config import Config

from aicippy.config import get_settings
from aicippy.utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

logger = get_logger(__name__)

# Bedrock Agent IDs — odin supervisor agent
ODIN_AGENT_ID: Final[str] = "CACLS9AC1J"
ODIN_AGENT_ALIAS_ID: Final[str] = "Y32URLZGJE"  # prod alias

# Timeouts
# No timeout limits — let the agent complete fully
AGENT_READ_TIMEOUT: Final[int] = 900
AGENT_CONNECT_TIMEOUT: Final[int] = 30


class BedrockAgentClient:
    """Client for invoking odin Bedrock Agent with streaming."""

    def __init__(
        self,
        agent_id: str | None = None,
        agent_alias_id: str | None = None,
        session_id: str | None = None,
    ) -> None:
        settings = get_settings()
        self._agent_id = agent_id or settings.bedrock_agent_id
        self._agent_alias_id = agent_alias_id or settings.bedrock_agent_alias_id
        self._session_id = session_id or self._generate_session_id()
        self._client: Any = None

    @staticmethod
    def _generate_session_id() -> str:
        import uuid
        return str(uuid.uuid4())[:12]

    def _get_client(self) -> Any:
        if self._client is None:
            settings = get_settings()
            config = Config(
                read_timeout=AGENT_READ_TIMEOUT,
                connect_timeout=AGENT_CONNECT_TIMEOUT,
                retries={"max_attempts": 2, "mode": "adaptive"},
            )
            session_kwargs: dict[str, Any] = {
                "region_name": settings.aws_region,
            }
            if settings.aws_profile:
                session_kwargs["profile_name"] = settings.aws_profile

            session = boto3.Session(**session_kwargs)
            self._client = session.client("bedrock-agent-runtime", config=config)
        return self._client

    async def invoke(
        self,
        input_text: str,
        on_token: Callable[[str], None] | None = None,
    ) -> str:
        """Invoke the odin agent and stream response tokens.

        Args:
            input_text: User message to send to the agent.
            on_token: Callback for each streamed text chunk.

        Returns:
            Complete response text.
        """
        import asyncio

        client = self._get_client()

        def _invoke_sync() -> str:
            response = client.invoke_agent(
                agentId=self._agent_id,
                agentAliasId=self._agent_alias_id,
                sessionId=self._session_id,
                inputText=input_text,
            )

            full_response = ""
            for event in response.get("completion", []):
                if "chunk" in event:
                    chunk_bytes = event["chunk"].get("bytes", b"")
                    if chunk_bytes:
                        text = chunk_bytes.decode("utf-8")
                        full_response += text
                        if on_token:
                            on_token(text)

            return full_response

        # Run blocking boto3 call in thread pool
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _invoke_sync)

    def close(self) -> None:
        """Close the client."""
        self._client = None

    @property
    def session_id(self) -> str:
        return self._session_id
