"""layer-scan: Automated LLM layer duplication configuration scanner."""

__version__ = "0.1.0"
