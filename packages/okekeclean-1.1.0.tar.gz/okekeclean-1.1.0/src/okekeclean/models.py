import json
from pathlib import Path
from typing import cast

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from huggingface_hub import hf_hub_download
from torch.utils.data import DataLoader
from torchvision import models
from tqdm import tqdm

from .types import (
    ArtifactModel,
    CheckpointConfig,
    CNNConfig,
    EnsembleConfig,
    Modality,
    ModelsFileDict,
    Progress,
    ReturnType,
)

CONFIG_PATH = Path(__file__).parent / "config" / "models.json"
HF_REPO_MAP = {
    "ABP": "moberg-analytics/okekeclean-abp",
    "ECG": "moberg-analytics/okekeclean-ecg",
}


def _load_models_config() -> ModelsFileDict:
    with CONFIG_PATH.open() as file:
        return cast(ModelsFileDict, json.load(file))


def _download_checkpoint(modality: Modality, filename: str) -> Path:
    return Path(
        hf_hub_download(
            repo_id=HF_REPO_MAP[modality],
            filename=filename,
        )
    )


def list_models() -> list[str]:
    return list(_load_models_config()["models"].keys())


def get_model_config(model_name: str) -> EnsembleConfig | CNNConfig:
    models_config = _load_models_config()

    if model_name not in models_config["models"]:
        available = list_models()
        raise ValueError(
            f"Model '{model_name}' not found. Available models: {available}"
        )

    model_info = models_config["models"][model_name]

    if model_info["type"] == "ensemble":
        return EnsembleConfig(
            type=model_info["type"],
            description=model_info["description"],
            modality=model_info["config"]["modality"],
            image_size=model_info["config"]["image_size"],
            threshold=model_info["config"]["threshold"],
            weights=model_info["config"]["weights"],
            ckpts=[
                CheckpointConfig(**checkpoint)
                for checkpoint in model_info["config"]["ckpts"]
            ],
        )

    if model_info["type"] == "cnn":
        return CNNConfig(
            type=model_info["type"],
            description=model_info["description"],
            modality=model_info["config"]["modality"],
            image_size=model_info["config"]["image_size"],
            threshold=model_info["config"]["threshold"],
            ckpt=CheckpointConfig(**model_info["config"]["ckpt"]),
        )

    raise ValueError(f"Invalid model type: {model_info['type']}")


def build_model(
    cfg: CheckpointConfig,
    image_size: int,
    threshold: float,
    modality: Modality = "ABP",
) -> nn.Module:
    if cfg.name == "resnet18":
        return ResNet18(image_size=image_size, threshold=threshold)
    if cfg.name == "efficientnet_b0":
        return EfficientNetB0(
            image_size=image_size,
            threshold=threshold,
            modality=modality,
        )
    raise ValueError(f"Invalid model checkpoint: {cfg.name}")


def load_model(
    model_name: str,
    device: torch.device,
    threshold: float | None = None,
    modality: Modality = "ABP",
) -> ArtifactModel:
    cfg = get_model_config(model_name)
    if threshold is not None:
        cfg.threshold = threshold

    if isinstance(cfg, EnsembleConfig):
        model = Ensemble(cfg)
        for submodel, ckpt_cfg in zip(model.models, model.ckpt_cfgs):
            submodel.load_state_dict(
                torch.load(
                    _download_checkpoint(cfg.modality, ckpt_cfg.checkpoint),
                    map_location=device,
                    weights_only=True,
                )
            )
            submodel.to(device)
            submodel.eval()
        return cast(ArtifactModel, model)

    if isinstance(cfg, CNNConfig):
        model = build_model(
            cfg.ckpt,
            cfg.image_size,
            cfg.threshold,
            modality=cfg.modality,
        )
        model.load_state_dict(
            torch.load(
                _download_checkpoint(cfg.modality, cfg.ckpt.checkpoint),
                map_location=device,
                weights_only=True,
            )
        )
        model.to(device)
        model.eval()
        return cast(ArtifactModel, model)

    raise ValueError(f"Invalid model type: {model_name}")


def _advance(progress: Progress, done: int, total: int) -> None:
    try:
        if hasattr(progress, "update"):
            progress.update(1)
        elif hasattr(progress, "progress"):
            progress.progress(int(done / total * 100))
    except Exception:
        pass


def run_inference(
    model: ArtifactModel,
    loader: DataLoader,
    device: torch.device,
    progress: Progress | None = None,
    return_type: ReturnType = "binary",
) -> np.ndarray:
    assert hasattr(model, "threshold"), "Model must have a threshold attribute"
    if return_type not in ["binary", "probability"]:
        raise ValueError(f"Invalid return_type: {return_type}")

    probs, preds = [], []
    total = len(loader)

    if progress is None:
        iterator = tqdm(
            loader,
            total=total,
            leave=False,
            bar_format="Running Inference for CNN | {desc} {bar:50} {percentage:3.0f}% {n_fmt}/{total_fmt}",
        )
    else:
        iterator = loader

    with torch.no_grad():
        for i, item in enumerate(iterator, start=1):
            data = item.to(device) if torch.is_tensor(item) else item[0].to(device)
            output = model(data)

            probs_tensor = (
                output if isinstance(model, Ensemble) else F.softmax(output, dim=1)
            )

            prob_1 = probs_tensor[:, 1]
            pred = (prob_1 >= model.threshold).int()

            probs.append(prob_1.cpu().numpy())
            preds.append(pred.cpu().numpy())

            if progress is not None:
                _advance(progress, i, total)

    return np.concatenate(preds if return_type == "binary" else probs)


class Ensemble(nn.Module):
    def __init__(self, config: EnsembleConfig):
        super().__init__()
        self.threshold: float = config.threshold
        self.image_size: int = config.image_size
        self.weights: list[float] = config.weights
        self.models: list[nn.Module] = [
            build_model(
                ckpt,
                config.image_size,
                config.threshold,
                modality=config.modality,
            )
            for ckpt in config.ckpts
        ]
        self.ckpt_cfgs: list[CheckpointConfig] = config.ckpts

        assert len(self.models) == len(self.weights)
        assert len(self.models) == len(self.ckpt_cfgs)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        outputs = [F.softmax(model(x), dim=1) for model in self.models]
        return sum(weight * probs for weight, probs in zip(self.weights, outputs))


class ResNet18(nn.Module):
    def __init__(self, image_size: int, threshold: float):
        super().__init__()
        self.image_size: int = image_size
        self.threshold: float = threshold
        self.resnet = models.resnet18()

        num_ftrs = self.resnet.fc.in_features
        self.resnet.fc = nn.Sequential(
            nn.Linear(num_ftrs, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 2),
        )
        self.resnet.conv1 = nn.Conv2d(
            1, 64, kernel_size=7, stride=2, padding=3, bias=False
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.resnet(x)


class EfficientNetB0(nn.Module):
    def __init__(self, image_size: int, threshold: float, modality: Modality = "ABP"):
        super().__init__()
        self.image_size: int = image_size
        self.threshold: float = threshold
        self.efficientnet = models.efficientnet_b0()

        num_ftrs = self.efficientnet.classifier[1].in_features
        self.efficientnet.classifier = nn.Sequential(
            nn.Linear(num_ftrs, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 2),
        )

        if modality == "ABP":
            self.efficientnet.features[0][0] = nn.Conv2d(
                1, 32, kernel_size=3, stride=2, padding=1, bias=False
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.efficientnet(x)
