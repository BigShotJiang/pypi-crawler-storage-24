from dataclasses import dataclass
from typing import (
    Any,
    Literal,
    Protocol,
    TypedDict,
    runtime_checkable,
)

from torch import Tensor as _Tensor

Modality = Literal["ABP", "ECG"]
ReturnType = Literal["binary", "probability"]


@dataclass
class ABPParams:
    sampling_rate: int = 125
    sigma: float = 2.0
    distance: int = 58
    chunk_size: int | None = None


@dataclass
class ECGParams:
    sampling_rate: int = 500
    chunk_duration: float = 10.0
    overlap: float = 0.0
    n_fft: int = 256
    hop_length: int = 64


WaveformParams = ABPParams | ECGParams


class CheckpointConfigDict(TypedDict):
    name: str
    checkpoint: str


class BaseModelFileConfigDict(TypedDict):
    modality: Modality
    image_size: int
    threshold: float


class CNNModelFileConfigDict(BaseModelFileConfigDict):
    ckpt: CheckpointConfigDict


class EnsembleModelFileConfigDict(BaseModelFileConfigDict):
    weights: list[float]
    ckpts: list[CheckpointConfigDict]


class BaseModelEntryDict(TypedDict):
    description: str
    version: str


class CNNModelEntryDict(BaseModelEntryDict):
    type: Literal["cnn"]
    config: CNNModelFileConfigDict


class EnsembleModelEntryDict(BaseModelEntryDict):
    type: Literal["ensemble"]
    config: EnsembleModelFileConfigDict


ModelEntryDict = CNNModelEntryDict | EnsembleModelEntryDict


class ModelsFileDict(TypedDict):
    models: dict[str, ModelEntryDict]


@dataclass
class CheckpointConfig:
    """Configuration for model checkpoint metadata."""

    name: str
    checkpoint: str


@dataclass
class ModelConfig:
    """Configuration for model metadata."""

    type: str
    description: str
    modality: Modality
    image_size: int
    threshold: float


@dataclass
class EnsembleConfig(ModelConfig):
    """Configuration for ensemble model with multiple checkpoints."""

    weights: list[float]
    ckpts: list[CheckpointConfig]


@dataclass
class CNNConfig(ModelConfig):
    """Configuration for single CNN model."""

    ckpt: CheckpointConfig


@runtime_checkable
class ArtifactModel(Protocol):
    threshold: float
    image_size: int

    def __call__(self, x: _Tensor) -> Any: ...


@runtime_checkable
class Progress(Protocol):
    """Minimal progress-bar contract."""

    def update(self, advance: int = 1) -> Any: ...

    def progress(self, value: int | float) -> Any: ...
