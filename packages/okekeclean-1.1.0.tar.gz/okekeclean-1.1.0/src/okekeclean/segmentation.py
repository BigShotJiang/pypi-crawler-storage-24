import numpy as np
import pandas as pd
import torch
from scipy.interpolate import CubicSpline
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, resample
from torchaudio import transforms as atrans
from torchvision import transforms as vtrans

from .types import ABPParams, ECGParams


def segment_abp(waveform: pd.Series, params: ABPParams = ABPParams()) -> pd.DataFrame:
    """Segment continuous ABP waveform into individual pulses using trough detection."""

    abp = waveform.values
    n = len(abp)

    if not params.chunk_size:
        windows = [(0, n)]
    else:
        overlap = params.distance + 2
        starts = np.arange(0, n, params.chunk_size - overlap)
        windows = [(s, min(s + params.chunk_size, n)) for s in starts]

    pulse_rows = []

    for w_start, w_end in windows:
        seg = abp[w_start:w_end]
        smooth = gaussian_filter1d(seg, sigma=params.sigma)
        local_troughs, _ = find_peaks(-smooth, distance=params.distance)
        troughs = local_troughs + w_start

        if len(troughs) < 2:
            continue

        starts = troughs[:-1]
        ends = troughs[1:]
        for s, e in zip(starts, ends):
            pulse_rows.append(
                {
                    "start_idx": s,
                    "end_idx": e,
                    "start_time": waveform.index[s],
                    "end_time": waveform.index[e],
                    "signal": abp[s:e],
                }
            )

    return pd.DataFrame(pulse_rows).reset_index(drop=True)


def resample_segments(segments_df: pd.DataFrame, target_fs: int = 500) -> pd.DataFrame:
    """Resample all segments to target frequency."""

    def resample_signal(signal: np.ndarray, original_duration: float) -> np.ndarray:
        original_length = len(signal)
        target_length = int(target_fs * original_duration)
        return (
            resample(signal, target_length)
            if original_length != target_length
            else signal
        )

    durations = (segments_df["end_time"] - segments_df["start_time"]).dt.total_seconds()
    segments_df = segments_df.copy()
    segments_df["signal"] = [
        resample_signal(sig, dur) for sig, dur in zip(segments_df["signal"], durations)
    ]
    return segments_df


def segment_ecg(waveform: pd.Series, params: ECGParams = ECGParams()) -> pd.DataFrame:
    """Segment an ECG signal into chunks."""

    chunk_duration_ns = int(params.chunk_duration * 1e9)
    overlap_ns = int(params.overlap * 1e9)
    step_ns = chunk_duration_ns - overlap_ns

    start_ns = waveform.index[0].value
    end_ns = waveform.index[-1].value

    chunk_starts_ns = np.arange(start_ns, end_ns - chunk_duration_ns + 1, step_ns)
    chunk_ends_ns = chunk_starts_ns + chunk_duration_ns

    chunk_starts = pd.to_datetime(chunk_starts_ns)
    chunk_ends = pd.to_datetime(chunk_ends_ns)

    start_indices = waveform.index.get_indexer(chunk_starts, method="nearest")
    end_indices = waveform.index.get_indexer(chunk_ends, method="nearest")

    segments_df = pd.DataFrame(
        {
            "start_idx": start_indices,
            "end_idx": end_indices,
            "start_time": chunk_starts,
            "end_time": chunk_ends,
            "signal": [
                waveform.values[s:e] for s, e in zip(start_indices, end_indices)
            ],
        }
    )
    return resample_segments(
        segments_df.loc[segments_df.signal.apply(len) > 10],
        target_fs=params.sampling_rate,
    )


class ABPDataset:
    def __init__(self, segments: pd.DataFrame, image_size: int):
        self.segments: np.ndarray = segments.signal.values
        self.image_size: int = image_size
        self.transform: vtrans.Compose = vtrans.Compose(
            [
                vtrans.ToPILImage(),
                vtrans.Resize((image_size, image_size)),
                vtrans.ToTensor(),
            ]
        )

    def __len__(self) -> int:
        return len(self.segments)

    def __getitem__(self, idx) -> torch.Tensor:
        if not isinstance(idx, int):
            raise TypeError(f"Expected int index, got {type(idx).__name__}")
        assert idx < len(self.segments), f"Index {idx} out of range"
        signal = self._convert_signal_to_image(
            self._interpolate_and_normalize(self.segments[idx])
        )
        return self.transform(signal)

    def _interpolate_and_normalize(self, signal: np.ndarray) -> np.ndarray:
        x_original = np.arange(len(signal))
        x_new = np.linspace(0, len(signal) - 1, self.image_size)
        cs = CubicSpline(x_original, signal)
        interpolated_array = cs(x_new)

        if interpolated_array.min() == interpolated_array.max():
            return np.zeros_like(interpolated_array)

        normalized_array = (interpolated_array - interpolated_array.min()) / (
            interpolated_array.max() - interpolated_array.min()
        )
        normalized_array[np.isnan(normalized_array)] = 0
        return normalized_array

    def _convert_signal_to_image(self, signal: np.ndarray) -> np.ndarray:
        image = np.zeros((self.image_size, self.image_size))
        for x, y in enumerate(signal):
            image[x][int(y * (self.image_size - 1))] = 1
        return np.rot90(image, k=1)


class ECGDataset:
    def __init__(
        self,
        segments: pd.DataFrame,
        image_size: int,
        n_fft: int = 256,
        hop_length: int = 64,
    ):
        self.segments: np.ndarray = segments.signal.values
        self.image_size: int = image_size
        self.spec_trans = atrans.Spectrogram(
            n_fft=n_fft, hop_length=hop_length, power=2.0
        )
        self.db_trans = atrans.AmplitudeToDB(stype="power")
        self.transform: vtrans.Compose = vtrans.Compose(
            [
                vtrans.ToPILImage(),
                vtrans.Resize((image_size, image_size)),
                vtrans.ToTensor(),
            ]
        )
        self.global_min: float = -100.0
        self.global_max: float = 87.12892150878906

    def __len__(self) -> int:
        return len(self.segments)

    def __getitem__(self, idx) -> torch.Tensor:
        if not isinstance(idx, int):
            raise TypeError(f"Expected int index, got {type(idx).__name__}")
        assert idx < len(self.segments), f"Index {idx} out of range"
        signal = self.segments[idx].copy()
        signal = torch.from_numpy(signal).float()
        spec = self.db_trans(self.spec_trans(signal))
        spec = (spec - self.global_min) / (self.global_max - self.global_min)
        spec = torch.clamp(spec, 0.0, 1.0)
        spec = spec.unsqueeze(0)
        return self.transform(spec).repeat(3, 1, 1)
