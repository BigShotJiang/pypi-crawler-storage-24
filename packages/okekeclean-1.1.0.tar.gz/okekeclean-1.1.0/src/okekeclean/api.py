from typing import cast

import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset

from .models import run_inference
from .segmentation import ABPDataset, ECGDataset, segment_abp, segment_ecg
from .types import (
    ABPParams,
    ArtifactModel,
    ECGParams,
    Modality,
    ReturnType,
    WaveformParams,
)


def detect_artifacts(
    waveform: pd.Series,
    modality: Modality,
    model: ArtifactModel,
    params: WaveformParams,
    device: torch.device,
    return_type: ReturnType = "probability",
    batch_size: int = 128,
    num_workers: int = 0,
) -> pd.Series:
    if modality == "ABP":
        assert isinstance(params, ABPParams), "For ABP, pass ABPParams"
        segments = segment_abp(waveform, params)
        ds = ABPDataset(segments, model.image_size)
    elif modality == "ECG":
        assert isinstance(params, ECGParams), "For ECG, pass ECGParams"
        segments = segment_ecg(waveform, params)
        ds = ECGDataset(segments, model.image_size, params.n_fft, params.hop_length)
    else:
        raise ValueError(f"Invalid modality: {modality}")

    dl = DataLoader(
        cast(Dataset[torch.Tensor], ds),
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
    )
    segments["score"] = run_inference(model, dl, device, return_type=return_type)

    out = pd.Series(
        0.0 if return_type == "probability" else False,
        index=waveform.index,
    )
    for _, segment in segments.iterrows():
        out.loc[segment["start_time"] : segment["end_time"]] = segment["score"]

    if return_type == "binary":
        out = out.astype(bool)

    return out
