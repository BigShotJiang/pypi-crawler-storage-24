"""
Multi-screen capture test script.
Uses local SDK to test channels, displays, and export against dev server.

Usage: python test_multi_screen.py
"""

import os
import asyncio
from dotenv import load_dotenv
import videodb
from videodb.capture import CaptureClient

load_dotenv()

VIDEO_DB_API_KEY = os.getenv("VIDEO_DB_API_KEY")
VIDEO_DB_API = os.getenv("VIDEO_DB_API")
if not VIDEO_DB_API_KEY:
    raise ValueError("VIDEO_DB_API_KEY environment variable not set")


async def main():
    print("=" * 60)
    print("Multi-Screen Capture Test")
    print("=" * 60)

    # Step 1: Connect
    print("\n[1] Connecting to VideoDB...")
    conn = videodb.connect(api_key=VIDEO_DB_API_KEY, base_url=VIDEO_DB_API)
    print("Connected.")

    # Step 2: Create session
    print("\n[2] Creating capture session...")
    session = conn.create_capture_session(
        end_user_id="test-user",
        collection_id="default",
        metadata={"app": "multi-screen-test"},
    )
    print(f"  Session ID: {session.id}")
    print(f"  Status: {session.status}")

    # Step 3: Generate token and init capture client
    print("\n[3] Generating client token...")
    token = conn.generate_client_token()
    client = CaptureClient(client_token=token)

    # Step 4: Request permissions and discover channels
    print("\n[4] Requesting permissions...")
    await client.request_permission("microphone")
    await client.request_permission("screen_capture")

    print("\n[5] Discovering channels...")
    channels = await client.list_channels()

    print(f"\n  Mics ({len(channels.mics)}):")
    for ch in channels.mics:
        print(f"    - {ch.id}: {ch.name}")

    print(f"\n  Displays ({len(channels.displays)}):")
    for ch in channels.displays:
        print(f"    - {ch.id}: {ch.name}")

    print(f"\n  System Audio ({len(channels.system_audio)}):")
    for ch in channels.system_audio:
        print(f"    - {ch.id}: {ch.name}")

    # Step 6: Select all channels, store=True, mark display:1 as primary
    print("\n[6] Selecting all channels for recording...")
    mic = channels.mics.default
    display_primary = channels.displays[0]
    display_secondary = channels.displays[1] if len(channels.displays) > 1 else None
    system_audio = channels.system_audio.default

    selected = []
    for ch in [mic, display_primary, display_secondary, system_audio]:
        if ch:
            ch.store = True
            selected.append(ch)

    display_primary.is_primary = True
    print(f"  Recording {len(selected)} channels, primary={display_primary.id}")

    # Step 7: Start recording
    print("\n[7] Starting recording...")
    await client.start_session(
        capture_session_id=session.id,
        channels=selected,
    )
    print("  Recording started.")

    # Step 8: Wait for user to stop
    print("\n  Press Enter to stop recording...")
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, input)

    print("\n[8] Stopping recording...")
    await client.stop_session()
    await client.shutdown()
    print("  Stopped.")

    # Step 9: Fetch session and verify channels from server
    print("\n[9] Fetching session from server...")
    session = conn.get_capture_session(session.id)
    print(f"  Status: {session.status}")

    print(f"\n  Channels ({len(session.channels)}):")
    for ch in session.channels:
        primary = " (primary)" if ch.is_primary else ""
        print(f"    - {ch.id}  type={ch.type}  name={ch.name}{primary}")

    print(f"\n  Displays ({len(session.displays)}):")
    for d in session.displays:
        primary = " (primary)" if d.is_primary else ""
        print(f"    - {d.id}  name={d.name}{primary}")

    print(f"\n  primary_video_channel_id: {session.primary_video_channel_id}")
    print(f"  export_status: {session.export_status}")
    print(f"  exported_video_id: {session.exported_video_id}")

    print("\n" + "=" * 60)
    print(f"Done. Session ID: {session.id}")
    print("=" * 60)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nAborted.")
