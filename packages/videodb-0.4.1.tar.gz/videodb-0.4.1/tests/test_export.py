"""
Test export on an existing capture session.

Usage: python tests/test_export.py <session_id>
"""

import os
import sys
from dotenv import load_dotenv
import videodb

load_dotenv()

VIDEO_DB_API_KEY = os.getenv("VIDEO_DB_API_KEY")
VIDEO_DB_API = os.getenv("VIDEO_DB_API")
if not VIDEO_DB_API_KEY:
    raise ValueError("VIDEO_DB_API_KEY environment variable not set")


def main():
    if len(sys.argv) < 2:
        print("Usage: python test_export.py <session_id>")
        sys.exit(1)

    session_id = sys.argv[1]

    print("=" * 60)
    print("Export Test")
    print("=" * 60)

    conn = videodb.connect(api_key=VIDEO_DB_API_KEY, base_url=VIDEO_DB_API)
    print("Connected.\n")

    # Step 1: Fetch session and show current state
    print(f"[1] Fetching session: {session_id}")
    session = conn.get_capture_session(session_id)

    print(session)

    print(f"  Status: {session.status}")
    print(f"  primary_video_channel_id: {session.primary_video_channel_id}")
    print(f"  export_status: {session.export_status}")
    print(f"  exported_video_id: {session.exported_video_id}")


    # Step 2: Show displays
    print(f"\n[2] Displays ({len(session.displays)}):")
    for i, d in enumerate(session.displays):
        primary = " (primary)" if d.is_primary else ""
        print(f"    [{i}] {d.id}  name={d.name}{primary}")

    # Step 3: Export default (primary)
    print(f"\n[3] Exporting primary display...")
    result = session.export(session.displays[1].id)
    print(f"  Response: {result}")
    
    # Step 4: Poll if export is async
    # if not result.get("data", {}).get("video_id"):
    #     print("\n[4] Export started, polling for completion...")
    #     for i in range(60):
    #         import time
    #         time.sleep(5)
    #         session = conn.get_capture_session(session_id)
    #         print(f"  [{(i+1)*5}s] export_status={session.export_status}  exported_videos={session.exported_videos}")
    #         if session.export_status in ("exported", "failed"):
    #             break

    # # Step 5: Final state
    # session = conn.get_capture_session(session_id)
    # print(f"\n[5] Final state:")
    # print(f"  export_status: {session.export_status}")
    # print(f"  exported_video_id: {session.exported_video_id}")
    # print(f"  exported_videos: {session.exported_videos}")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
