"""
Comando status.

Exibe o estado atual do monitor de risco.

O comando verifica:

1. Existência do arquivo PID
2. Presença do heartbeat
3. Tempo desde o último heartbeat

Isso permite detectar se o monitor:

- está rodando
- travou
- ou foi encerrado.
"""

import os
import time
import click

from mtcli.logger import setup_logger
from mtcli.conf import PID_FILE, HEARTBEAT_FILE

log = setup_logger("risco")


@click.command()
def status_cmd() -> None:
    """
    Exibe o status atual do monitor de risco.
    """

    if not os.path.exists(PID_FILE):
        click.echo("Monitor não está rodando.")
        log.info("[STATUS] Monitor inativo")
        return

    with open(PID_FILE) as f:
        pid = f.read().strip()

    if os.path.exists(HEARTBEAT_FILE):

        with open(HEARTBEAT_FILE) as f:
            ts = float(f.read())

        age = int(time.time() - ts)

        click.echo(f"Monitor ativo (PID {pid})")
        click.echo(f"Último heartbeat: {age}s")

        log.debug("[STATUS] Monitor ativo | pid=%s heartbeat_age=%ss", pid, age)

    else:
        click.echo(f"Monitor rodando (PID {pid})")
        log.warning("[STATUS] PID encontrado sem heartbeat | pid=%s", pid)
