"""
Comando start.

Responsável por iniciar o monitor de risco em background.

Este comando cria um novo processo Python que executa o módulo
`mtcli_risco.services.run_monitor`, responsável por iniciar o
loop de monitoramento contínuo do risco diário.

Fluxo
-----

mt risco start
    ->
subprocess.Popen()
    ->
run_monitor.py
    ->
monitor_loop()

O comando também verifica se já existe um processo ativo
através do arquivo PID.
"""

import os
import click
import subprocess
import sys

from mtcli.logger import setup_logger
from mtcli.conf import PID_FILE
from ..conf import LOSS_LIMIT, INTERVALO

log = setup_logger("risco")


@click.command()
@click.option("--limite", default=LOSS_LIMIT, show_default=True)
@click.option("--intervalo", default=INTERVALO, show_default=True)
@click.option("--dry-run", is_flag=True, help="Simula execução sem enviar ordens.")
def start_cmd(limite: float, intervalo: int, dry_run: bool) -> None:
    """
    Inicia o monitor de risco em background.

    Parameters
    ----------
    limite : float
        Limite máximo de prejuízo diário permitido.
    intervalo : int
        Intervalo (segundos) entre verificações de risco.
    dry_run : bool
        Executa em modo simulação (sem enviar ordens ao MT5).
    """

    if os.path.exists(PID_FILE):
        click.echo("Monitor já está rodando.")
        log.warning("[START] Monitor já ativo | pid_file=%s", PID_FILE)
        return

    cmd = [
        sys.executable,
        "-m",
        "mtcli_risco.services.run_monitor",
        str(limite),
        str(intervalo),
        str(int(dry_run)),
    ]

    log.info(
        "[START] Iniciando monitor | limite=%.2f intervalo=%ss dry_run=%s",
        limite,
        intervalo,
        dry_run,
    )

    subprocess.Popen(cmd)

    click.echo("Monitor iniciado em background.")
