"""
Comando stop.

Solicita a parada do monitor de risco.

O comando cria um arquivo de sinal (`STOP_FILE`) que será
detectado pelo loop de monitoramento, permitindo uma
finalização controlada do processo.
"""

import click
from mtcli.logger import setup_logger
from mtcli.conf import STOP_FILE

log = setup_logger("risco")


@click.command()
def stop_cmd() -> None:
    """
    Envia sinal de parada para o monitor de risco.
    """

    with open(STOP_FILE, "w") as f:
        f.write("stop")

    log.info("[STOP] Sinal de parada enviado")

    click.echo("Sinal de parada enviado.")
