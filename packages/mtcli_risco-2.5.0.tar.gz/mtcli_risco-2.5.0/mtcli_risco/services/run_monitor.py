"""
Runner do monitor de risco.

Este módulo é responsável por:

1. Receber parâmetros do processo pai (`start`)
2. Criar o arquivo PID
3. Executar o loop de monitoramento
4. Garantir limpeza do PID ao finalizar

Ele é executado como módulo Python:

    python -m mtcli_risco.services.run_monitor
"""

import sys
import os

from mtcli.logger import setup_logger
from mtcli.conf import PID_FILE
from .monitor_service import monitor_loop

log = setup_logger("risco")


def main() -> None:
    """
    Inicializa o processo de monitoramento.
    """

    limite = float(sys.argv[1])
    intervalo = int(sys.argv[2])
    dry_run = bool(int(sys.argv[3]))

    pid = os.getpid()

    with open(PID_FILE, "w") as f:
        f.write(str(pid))

    log.info(
        "[RUNNER] Processo iniciado | pid=%s limite=%.2f intervalo=%ss dry_run=%s",
        pid,
        limite,
        intervalo,
        dry_run,
    )

    try:
        monitor_loop(limite, intervalo, dry_run)

    finally:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)

        log.info("[RUNNER] Processo finalizado | pid=%s", pid)


if __name__ == "__main__":
    main()
