"""
Serviço de monitoramento de risco.

Este módulo contém o loop principal responsável por:

- Monitorar continuamente o resultado financeiro diário
- Disparar PANIC CLOSE quando o limite de perda é atingido
- Atualizar heartbeat para verificação de saúde do processo
- Encerrar de forma controlada quando solicitado

Fluxo
-----

monitor_loop()
    ->
verifica STOP_FILE
    ->
atualiza heartbeat
    ->
verifica risco
    ->
executa panic_close_all()
"""

import time
import os
from datetime import date

from mtcli.logger import setup_logger
from mtcli.conf import STOP_FILE, HEARTBEAT_FILE
from ..conf import STATUS_FILE
from ..models.checar_model import (
    carregar_estado,
    salvar_estado,
    risco_excedido,
)
from ..models.panic_model import panic_close_all

log = setup_logger("risco")


def write_heartbeat() -> None:
    """
    Atualiza timestamp de heartbeat do monitor.

    O heartbeat é utilizado pelo comando `status`
    para detectar se o monitor está ativo.
    """
    with open(HEARTBEAT_FILE, "w") as f:
        f.write(str(time.time()))


def monitor_loop(limite: float, intervalo: int, dry_run: bool) -> None:
    """
    Loop principal do monitor de risco.

    Parameters
    ----------
    limite : float
        Limite máximo de prejuízo diário permitido.
    intervalo : int
        Intervalo entre verificações (segundos).
    dry_run : bool
        Executa em modo simulação.
    """

    log.info(
        "[MONITOR] Iniciado | limite=%.2f intervalo=%ss dry_run=%s",
        limite,
        intervalo,
        dry_run,
    )

    while True:

        if os.path.exists(STOP_FILE):
            log.info("[MONITOR] Sinal de parada recebido")
            os.remove(STOP_FILE)
            break

        write_heartbeat()

        hoje = date.today()
        estado = carregar_estado(STATUS_FILE)

        if estado["data"] != hoje.isoformat():
            log.info("[MONITOR] Novo dia detectado | resetando estado")
            salvar_estado(STATUS_FILE, hoje, False)
            estado["bloqueado"] = False

        if not estado["bloqueado"] and risco_excedido(limite):

            log.critical("[MONITOR] Limite de risco excedido")

            resultado = panic_close_all(
                retry_on_market_open=True,
                dry_run=dry_run,
            )

            salvar_estado(STATUS_FILE, hoje, True)

            log.critical("[MONITOR] PANIC CLOSE executado | resultado=%s", resultado)

        time.sleep(intervalo)

    log.info("[MONITOR] Finalizado")
