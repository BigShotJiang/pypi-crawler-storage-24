"""
Comando principal e registro dos subcomandos
"""

import click
from .commands.checar import checar_cmd
from .commands.monitorar import monitorar_cmd
from .commands.trades import trades_cmd
from .commands.panic import panic_cmd
from .commands.start import start_cmd
from .commands.stop import stop_cmd
from .commands.status import status_cmd


@click.group()
@click.version_option(package_name="mtcli-risco")
def cli():
    """
    Plugin mtcli-risco.

    Conjunto de comandos para gerenciamento e controle de risco diário
    baseado em lucro/prejuízo no MetaTrader 5.
    """
    pass


cli.add_command(checar_cmd, name="checar")
cli.add_command(monitorar_cmd, name="monitorar")
cli.add_command(trades_cmd, name="trades")
cli.add_command(panic_cmd, name="panic")
cli.add_command(start_cmd, name="start")
cli.add_command(stop_cmd, name="stop")
cli.add_command(status_cmd, name="status")
