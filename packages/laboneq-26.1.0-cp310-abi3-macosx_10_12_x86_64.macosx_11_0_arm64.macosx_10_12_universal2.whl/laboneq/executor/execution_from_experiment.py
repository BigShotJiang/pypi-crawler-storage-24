# Copyright 2023 Zurich Instruments AG
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import numpy as np

from laboneq.core.utilities.prng import PRNG
from laboneq.data.experiment_description import (
    Acquire,
    AcquireLoopRt,
    Call,
    Case,
    Delay,
    Experiment,
    Match,
    Operation,
    PlayPulse,
    PrngLoop,
    Reserve,
    Section,
    SetNode,
    Sweep,
)
from laboneq.data.parameter import LinearSweepParameter, Parameter, SweepParameter
from laboneq.data.prng import PRNGSample
from laboneq.executor import executor


class ExecutionFactoryFromExperiment(executor.ExecutionFactory):
    def __init__(self):
        super().__init__()
        # A mapping from driver parameter UIDs to the parameters they drive
        # Not all parameters are mapped to their respective sweeps, therefore we
        # use this mapping to find driven parameters when handling sweeps and placing them into
        # correct nt execution statements.
        self._driver_parameter_map: dict[str, list[Parameter]] = {}

    def make(
        self,
        experiment: Experiment,
        driver_parameter_map: dict[str, list[Parameter]] | None = None,
    ) -> executor.Statement:
        self._driver_parameter_map = driver_parameter_map or {}
        self._handle_children(experiment.sections)
        return self._root_sequence

    def _handle_children(self, children: list[Operation | Section]):
        for child in children:
            if isinstance(child, Operation):
                self._append_statement(self._statement_from_operation(child))
            elif isinstance(child, AcquireLoopRt):
                loop_body = self._sub_scope(self._handle_children, child.children)
                loop = executor.ExecRT(
                    count=child.count,
                    body=loop_body,
                    uid=child.uid,
                    averaging_mode=child.averaging_mode,
                    acquisition_type=child.acquisition_type,
                )
                self._append_statement(loop)
            elif isinstance(child, Sweep):
                parameter = child.parameters[0]
                if isinstance(parameter, LinearSweepParameter):
                    count = parameter.count
                else:
                    assert isinstance(parameter, SweepParameter)
                    count = len(parameter.values)
                loop_body = self._sub_scope(self._handle_sweep, child)
                flag = (
                    executor.LoopFlags.CHUNKED
                    if child.chunk_count > 1 or child.auto_chunking
                    else executor.LoopFlags.NONE
                )
                self._append_statement(
                    executor.ForLoop(count=count, body=loop_body, loop_flags=flag)
                )
            elif isinstance(child, Match):
                sweep_parameter = child.sweep_parameter
                cases = self._sub_scope(self._handle_children, child.children)
                self._append_statement(
                    executor.MatchSection(
                        sweep_parameter=sweep_parameter.uid
                        if sweep_parameter is not None
                        else None,
                        cases=cases,
                    )
                )
            elif isinstance(child, Case):
                state = child.state
                body = self._sub_scope(self._handle_children, child.children)
                self._append_statement(executor.CaseSection(state=state, body=body))
            elif isinstance(child, PrngLoop):
                prng_sample = child.prng_sample
                count = prng_sample.count
                loop_body = self._sub_scope(self._handle_prng_loop, child)
                self._append_statement(executor.ForLoop(count=count, body=loop_body))
            else:
                sub_sequence = self._sub_scope(self._handle_children, child.children)
                self._append_statement(sub_sequence)

    def _handle_sweep(self, sweep: Sweep):
        seen_params = set()
        for parameter in sweep.parameters:
            seen_params.add(parameter.uid)
            self._append_statement(self._statement_from_param(parameter))

            for driven_param in self._driver_parameter_map.get(parameter.uid, []):
                if driven_param.uid in seen_params:
                    continue
                seen_params.add(driven_param.uid)
                self._append_statement(self._statement_from_param(driven_param))
        self._handle_children(sweep.children)

    def _handle_prng_loop(self, loop: PrngLoop):
        self._append_statement(self._statement_from_param(loop.prng_sample))
        self._handle_children(loop.children)

    def _statement_from_param(
        self, parameter: SweepParameter | LinearSweepParameter | PRNGSample
    ):
        if isinstance(parameter, SweepParameter):
            values = parameter.values
            axis_name = parameter.axis_name
        elif isinstance(parameter, LinearSweepParameter):
            values = np.linspace(parameter.start, parameter.stop, parameter.count)
            axis_name = parameter.axis_name
        elif isinstance(parameter, PRNGSample):
            prng = parameter.prng
            prng_sim = PRNG(seed=prng.seed, upper=prng.range - 1)
            values = np.array([next(prng_sim) for _ in range(parameter.count)])
            axis_name = parameter.uid
        else:
            raise TypeError(f"Unrecognized parameter type: {type(parameter)}")
        return executor.SetSoftwareParam(
            name=parameter.uid, values=values, axis_name=axis_name
        )

    def _statement_from_operation(self, operation):
        if isinstance(operation, Call):
            return executor.ExecNeartimeCall(operation.func_name, operation.args)
        if isinstance(operation, SetNode):
            return executor.ExecSet(operation.path, operation.value)
        if isinstance(operation, PlayPulse):
            return executor.Nop()
        if isinstance(operation, Delay):
            return executor.Nop()
        if isinstance(operation, Reserve):
            return executor.Nop()
        if isinstance(operation, Acquire):
            assert operation.signal is not None
            return executor.ExecAcquire(operation.handle, operation.signal)
        return executor.Nop()
