# Copyright 2022 Zurich Instruments AG
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import ItemsView, Iterator
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import (
    TYPE_CHECKING,
    Any,
    KeysView,
    Literal,
    TypeVar,
    cast,
    overload,
)

import numpy as np
import zhinst.utils  # type: ignore[import-untyped]
from packaging.version import InvalidVersion, Version

from laboneq.controller.attribute_value_tracker import (
    AttributeName,
    AttributeValueTracker,
    DeviceAttribute,
)
from laboneq.controller.utilities.exception import LabOneQControllerException
from laboneq.core.types.enums.acquisition_type import AcquisitionType
from laboneq.core.types.enums.averaging_mode import AveragingMode
from laboneq.core.types.enums.awg_signal_type import AWGSignalType
from laboneq.core.types.enums.wave_type import WaveType
from laboneq.data.awg_info import AwgKey as AwgKeyFromData
from laboneq.data.calibration import PortMode as RecipePortMode
from laboneq.data.recipe import IO, Initialization, Recipe
from laboneq.data.scheduled_experiment import (
    ArtifactsCodegen,
    CodegenWaveform,
    ScheduledExperiment,
    WeightInfo,
)
from laboneq.executor.executor import (
    Statement,
)

if TYPE_CHECKING:
    from laboneq.controller.devices.device_collection import DeviceCollection
    from laboneq.controller.devices.device_setup_dao import DeviceUID
    from laboneq.core.types.numpy_support import NumPyArray


_logger = logging.getLogger(__name__)


MIN_LABONEQ_VERSION_FOR_COMPILED_EXPERIMENT = Version("2.52.0")

VIRTUAL_SHFSG_UID_SUFFIX = "_sg"


@dataclass(frozen=True)
class AwgKey:
    device_uid: DeviceUID
    awg_index: int


class AwgType(Enum):
    QA = auto()
    SG = auto()


class AwgSignalType(Enum):
    IQ = auto()
    SINGLE = auto()


@dataclass
class AwgConfig:
    awg_type: AwgType
    signal_type: AwgSignalType
    signals: set[str]
    # QA
    raw_acquire_length: int | None = None
    result_length: int | None = None
    acquire_signals: set[str] = field(default_factory=set)
    # SG
    command_table_match_offset: int | None = None
    source_feedback_register: int | Literal["local"] | None = None
    fb_reg_source_index: int | None = None
    fb_reg_target_index: int | None = None
    register_selector_bitmask: int | None = 0b11
    register_selector_shift: int | None = None


class AwgConfigs:
    def __init__(self):
        self._configs: dict[AwgKey, AwgConfig] = {}
        # Used to estimate timeouts due to possible slowdowns on
        # the network when fetching large results.
        self._max_result_length: int = 0

    @property
    def max_result_length(self) -> int:
        return self._max_result_length

    def update_max_result_length(self, result_length: int):
        if result_length > self._max_result_length:
            self._max_result_length = result_length

    def __getitem__(self, key: AwgKey) -> AwgConfig:
        return self._configs[key]

    def items(self) -> ItemsView[AwgKey, AwgConfig]:
        return self._configs.items()

    def keys(self) -> KeysView[AwgKey]:
        return self._configs.keys()

    def add(self, key: AwgKey, config: AwgConfig):
        assert key not in self._configs
        self._configs[key] = config

    def by_signal(self, signal_id: str) -> tuple[AwgKey, AwgConfig]:
        return next(
            (key, config)
            for key, config in self._configs.items()
            if signal_id in config.signals
        )


class HWModulation(Enum):
    NONE = auto()
    OFF = auto()
    SINE = auto()
    IQ = auto()


class TrigOutSource(Enum):
    NONE = auto()
    AWG_TRIGGER = auto()
    MARKER_1 = auto()


@dataclass
class HDAWGOutputRecipeData:
    enable: bool | None = None
    range: float | None = None
    hw_modulation: HWModulation = HWModulation.NONE
    # To keep behavior identical to before, empty dict indicates no precompensation provided,
    # while None means precompensation explicitly disabled.
    precompensation: dict[str, dict] | None = field(default_factory=dict)
    trig_out_source: TrigOutSource = TrigOutSource.NONE


@dataclass
class HDAWGRecipeData:
    outputs: tuple[HDAWGOutputRecipeData, HDAWGOutputRecipeData] = field(
        default_factory=lambda: (HDAWGOutputRecipeData(), HDAWGOutputRecipeData())
    )
    iq_settings: tuple[int, int] | None = None


@dataclass
class UHFQAOutputRecipeData:
    enable: bool = False
    offset: float | None = None
    hw_modulation: HWModulation = HWModulation.NONE
    range: float | None = None


@dataclass
class UHFQARecipeData:
    outputs: tuple[UHFQAOutputRecipeData, UHFQAOutputRecipeData] = field(
        default_factory=lambda: (UHFQAOutputRecipeData(), UHFQAOutputRecipeData())
    )


@dataclass
class QAChannelRecipeData:
    output_enable: bool | None = None  # None means no output config provided
    output_range: float | None = None
    output_mute_enable: bool = False
    input_enable: bool | None = None  # None means no input config provided
    input_range: float | None = None
    input_rf_path: bool = True


@dataclass
class OutputRouteConfig:
    source: int
    fixed_amplitude: float | None = None  # None means parameterized amplitude
    fixed_phase: float | None = None  # None means parameterized phase
    param_amplitude: str | None = None  # None means fixed amplitude
    param_phase: str | None = None  # None means fixed phase


@dataclass
class SGChannelRecipeData:
    output_enable: bool | None = None  # None means no output config provided
    output_range: float | None = None
    output_mute_enable: bool = False
    modulation: bool | None = None
    marker_source_trigger: bool = True
    output_rf_path: bool = True
    router_config: list[OutputRouteConfig] | None = None

    def ensure_router_config(self):
        if self.router_config is None:
            self.router_config = []
        return self.router_config


@dataclass
class PPChannelRecipeData:
    settings: dict[str, Any] = field(default_factory=dict)


@dataclass
class AllocatedOscillator:
    channels: set[int]
    awg_type: AwgType
    index: int
    id_index: int
    frequency: float | None
    param: str | None


@dataclass
class DeviceRecipeData:
    is_present: bool = True
    start_trigger_repetitions: int = 1
    iq_settings: dict[int, tuple[int, int]] = field(default_factory=dict)
    allocated_oscs: list[AllocatedOscillator] = field(default_factory=list)
    uhfqacore: UHFQARecipeData = field(default_factory=UHFQARecipeData)
    hdawgcores: dict[int, HDAWGRecipeData] = field(default_factory=dict)
    qachannels: dict[int, QAChannelRecipeData] = field(default_factory=dict)
    sgchannels: dict[int, SGChannelRecipeData] = field(default_factory=dict)
    ppchannels: dict[int, PPChannelRecipeData] = field(default_factory=dict)
    awg_configs: dict[int, AwgConfig] = field(default_factory=dict)
    has_feedback: bool = False

    def allocated_awgs(self, default_awg: int | None = None) -> set[int]:
        awgs = set(self.awg_configs.keys())
        if len(awgs) == 0 and default_awg is not None:
            awgs.add(default_awg)
        return awgs


@dataclass
class RtExecutionInfo:
    uid: str
    averages: int
    averaging_mode: AveragingMode
    acquisition_type: AcquisitionType
    chunk_count: int | None

    @property
    def is_chunked(self) -> bool:
        return self.chunk_count is not None

    @property
    def chunk_count_or_1(self) -> int:
        return self.chunk_count or 1

    @property
    def is_raw_acquisition(self) -> bool:
        return self.acquisition_type == AcquisitionType.RAW

    @property
    def effective_averages(self) -> int:
        return 1 if self.averaging_mode == AveragingMode.SINGLE_SHOT else self.averages

    @property
    def effective_averaging_mode(self) -> AveragingMode:
        # TODO(2K): handle sequential
        return (
            AveragingMode.CYCLIC
            if self.averaging_mode == AveragingMode.SINGLE_SHOT
            else self.averaging_mode
        )


T = TypeVar("T")


def get_artifacts(artifacts: Any, artifacts_class: type[T]) -> T:
    if isinstance(artifacts, artifacts_class):
        return artifacts
    if isinstance(artifacts, dict):
        for artifacts_data in artifacts.values():
            if isinstance(artifacts_data, artifacts_class):
                return artifacts_data
    raise LabOneQControllerException(
        "Internal error: Unexpected artifacts structure in compiled experiment."
    )


def get_initialization_by_device_uid(
    recipe: Recipe | None, device_uid: str
) -> Initialization | None:
    if recipe is None:
        return None
    for initialization in recipe.initializations:
        if initialization.device_uid == device_uid:
            return initialization
    return None


def get_elf(artifacts: ArtifactsCodegen, seqc_ref: str | None) -> bytes | None:
    if seqc_ref is None:
        return None

    if artifacts.src is None:
        seqc = None
    else:
        seqc = next((s for s in artifacts.src if s["filename"] == seqc_ref), None)
    if seqc is None or "elf" not in seqc or not isinstance(seqc["elf"], bytes):
        raise LabOneQControllerException(
            "Experiment cannot be executed - compilation artifacts are incomplete. "
            "Possible cause: the experiment was compiled with the IGNORE_RESOURCE_LIMITATION_ERRORS setting."
        )

    return seqc["elf"]


@dataclass
class RecipeData:
    scheduled_experiment: ScheduledExperiment
    recipe: Recipe
    execution: Statement
    rt_execution_info: RtExecutionInfo
    device_settings: dict[DeviceUID, DeviceRecipeData]
    awg_configs: AwgConfigs
    attribute_value_tracker: AttributeValueTracker
    max_step_execution_time: float

    def get_initialization(self, device_uid: DeviceUID) -> Initialization:
        for initialization in self.recipe.initializations:
            if initialization.device_uid == device_uid:
                return initialization
        return Initialization(device_uid=device_uid)

    def get_artifacts(self, artifacts_class: type[T]) -> T:
        return get_artifacts(self.scheduled_experiment.artifacts, artifacts_class)

    def awgs_producing_results(self) -> Iterator[tuple[AwgKey, AwgConfig]]:
        for awg_key, awg_config in self.awg_configs.items():
            if awg_config.result_length is not None:
                yield awg_key, awg_config

    def awg_by_seqc_name(self, seqc_name: str) -> AwgKey | None:
        for rt_exec_step in self.recipe.realtime_execution_init:
            if rt_exec_step.program_ref == seqc_name:
                return AwgKey(rt_exec_step.device_id, rt_exec_step.awg_index)
        return None

    def allocated_awgs(
        self, device_uid: str, default_awg: int | None = None
    ) -> set[int]:
        awgs = {
            awg_key.awg_index
            for awg_key in self.awg_configs.keys()
            if awg_key.device_uid == device_uid
        }
        if len(awgs) == 0 and default_awg is not None:
            awgs.add(default_awg)
        return awgs


def _validate_scheduled_experiment(
    scheduled_experiment: ScheduledExperiment, devices: DeviceCollection
):
    recipe = scheduled_experiment.recipe
    assert recipe is not None  # Recipe is present

    # Recipe version is correct
    try:
        if (
            Version(Version(recipe.versions.laboneq).base_version)
            < MIN_LABONEQ_VERSION_FOR_COMPILED_EXPERIMENT
        ):
            raise LabOneQControllerException(
                f"The experiment was compiled with LabOne Q version {recipe.versions.laboneq}, which is not compatible. "
                "Please recompile using the current LabOne Q version."
            )
    except InvalidVersion:
        _logger.warning(
            "The experiment was compiled with an invalid LabOne Q version '%s'. "
            "Passing, as this is only expected to happen in tests. Consider ensuring that the valid version is set.",
            recipe.versions.laboneq,
        )

    if (
        scheduled_experiment.device_setup_fingerprint
        != devices.device_setup_fingerprint
    ):
        raise LabOneQControllerException(
            "The device setup of the compiled experiment is not compatible with the current device setup. "
            "Please recompile using the current device setup."
        )

    assert scheduled_experiment.execution is not None


def _pre_process_iq_settings_hdawg(
    initialization: Initialization | None,
) -> dict[int, tuple[int, int]]:
    if initialization is None or initialization.device_type != "HDAWG":
        return {}

    # TODO(2K): Every pair of outputs with adjacent even+odd channel numbers (starting from 0)
    # is treated as an I/Q pair. I/Q pairs should be specified explicitly instead.

    # Base gains matrix (assuming ideal mixer, i.e. without calibration).
    # It ensures correct phases of I/Q components (correct sideband of
    # the resulting signal), along with the correct settings for:
    #   * playWave channel assignment: playWave(1, 2, I_wave, 1, 2, Q_wave)
    #   * oscillator phase: ch0 -> 0 deg / ch1 -> 90 deg
    #   * modulation mode: ch0 -> 3 (Sine12) / ch1 -> 4 (Sine21)

    outputs = initialization.outputs
    awgs = initialization.awgs
    iq_settings = {}

    for output in outputs or []:
        awg_idx = output.channel // 2

        # The channel already considered? Skip to the next.
        if awg_idx in iq_settings:
            continue

        # Do the outputs form an I/Q pair?
        awg = next((a for a in awgs if a.awg == awg_idx), None)
        if awg is None or awg.signal_type != AWGSignalType.IQ:
            continue

        # Determine I and Q output elements for the IQ pair with index awg_idxs.
        if output.channel % 2 == 0:
            i_out = output
            q_out = next((o for o in outputs if o.channel == output.channel + 1), IO(0))
        else:
            i_out = next((o for o in outputs if o.channel == output.channel - 1), IO(0))
            q_out = output

        if i_out.gains is None or q_out.gains is None:
            continue  # No pair with valid gains found? This is not an IQ signal.
        iq_settings[awg_idx] = (i_out.channel, q_out.channel)

    return iq_settings


def _pre_process_oscillator_allocations_per_type(
    *, recipe: Recipe, oscillator_ids: list[str], device_id: str, awg_type: AwgType
):
    allocated_oscs: list[AllocatedOscillator] = []
    for osc_param in recipe.oscillator_params:
        if osc_param.device_id != device_id:
            continue
        osc_id_index = oscillator_ids.index(osc_param.id)
        same_id_osc = next(
            (osc for osc in allocated_oscs if osc.id_index == osc_id_index), None
        )
        if same_id_osc is None:
            allocated_oscs.append(
                AllocatedOscillator(
                    channels={osc_param.channel},
                    awg_type=awg_type,
                    index=osc_param.allocated_index,
                    id_index=osc_id_index,
                    frequency=osc_param.frequency,
                    param=osc_param.param,
                )
            )
        else:
            if same_id_osc.frequency != osc_param.frequency:
                raise LabOneQControllerException(
                    f"Ambiguous frequency in recipe for oscillator "
                    f"'{osc_param.id}': {same_id_osc.frequency} != {osc_param.frequency}"
                )
            if same_id_osc.index != osc_param.allocated_index:
                raise LabOneQControllerException(
                    f"Ambiguous index in recipe for oscillator "
                    f"'{osc_param.id}': {same_id_osc.index} != {osc_param.allocated_index}"
                )
            same_id_osc.channels.add(osc_param.channel)
    return allocated_oscs


def _pre_process_oscillator_allocations(
    *, recipe: Recipe, oscillator_ids: list[str], device_id: str
):
    allocated_oscs = _pre_process_oscillator_allocations_per_type(
        recipe=recipe,
        oscillator_ids=oscillator_ids,
        device_id=device_id,
        awg_type=AwgType.QA,
    )
    return allocated_oscs


def _pre_process_uhfqa(
    initialization: Initialization | None,
) -> UHFQARecipeData:
    uhfqa_core = UHFQARecipeData()
    if initialization is None or initialization.device_type != "UHFQA":
        return uhfqa_core

    outputs = initialization.outputs or []
    for output in outputs:
        qa_output = uhfqa_core.outputs[output.channel]
        qa_output.enable = output.enable is True
        if isinstance(output.offset, float):
            qa_output.offset = output.offset
        else:
            _logger.warning(
                f"Parameter 'offset' specified for the device {initialization.device_uid}, channel {output.channel} must be of type 'float'."
            )
        qa_output.hw_modulation = (
            HWModulation.SINE if output.modulation is True else HWModulation.OFF
        )
        qa_output.range = output.range

    return uhfqa_core


def _pre_process_hd_awgs(
    initialization: Initialization | None,
) -> dict[int, HDAWGRecipeData]:
    if initialization is None or initialization.device_type != "HDAWG":
        return {}

    awgs: dict[int, HDAWGRecipeData] = {}

    def _get_awg_data(awg_index: int) -> HDAWGRecipeData:
        awg_data = awgs.get(awg_index)
        if awg_data is None:
            awg_data = HDAWGRecipeData()
            awgs[awg_index] = awg_data
        return awg_data

    iq_settings = _pre_process_iq_settings_hdawg(initialization)

    outputs = initialization.outputs or []
    for output in outputs:
        awg_index = output.channel // 2
        rel_output = output.channel % 2

        awg_data = _get_awg_data(awg_index)
        output_data = awg_data.outputs[rel_output]
        output_data.enable = output.enable

        if awg_index in iq_settings:
            awg_data.iq_settings = iq_settings[awg_index]
            hw_modulation = HWModulation.IQ
        else:
            hw_modulation = HWModulation.SINE
        output_data.hw_modulation = (
            hw_modulation if output.modulation is True else HWModulation.OFF
        )

        if output.range is not None:
            if output.range_unit not in (None, "volt"):
                raise LabOneQControllerException(
                    f"The output range of device {initialization.device_uid} is specified in "
                    f"units of {output.range_unit}. Units must be 'volt'."
                )
            if output.range not in (0.2, 0.4, 0.6, 0.8, 1.0, 2.0, 3.0, 4.0, 5.0):
                _logger.warning(
                    "The specified output range %s for device %s is not in the list of "
                    "supported values. It will be rounded to the next higher allowed value.",
                    output.range,
                    initialization.device_uid,
                )
            output_data.range = output.range

        output_data.precompensation = output.precompensation

        if output.marker_mode == "TRIGGER":
            output_data.trig_out_source = TrigOutSource.AWG_TRIGGER
        elif output.marker_mode == "MARKER":
            output_data.trig_out_source = TrigOutSource.MARKER_1
        elif output.marker_mode is not None:
            raise ValueError(
                f"Maker mode must be either 'MARKER' or 'TRIGGER', but got {output.marker_mode} for output {output.channel} on HDAWG {initialization.device_uid}"
            )

    return awgs


def _pre_process_qa_channels(
    initialization: Initialization | None,
) -> dict[int, QAChannelRecipeData]:
    if initialization is None or initialization.device_type != "SHFQA":
        return {}

    channels: dict[int, QAChannelRecipeData] = {}

    def _get_channel_data(channel: int) -> QAChannelRecipeData:
        channel_data = channels.get(channel)
        if channel_data is None:
            channel_data = QAChannelRecipeData()
            channels[channel] = channel_data
        return channel_data

    outputs = initialization.outputs or []
    for output in outputs:
        channel_data = _get_channel_data(output.channel)
        channel_data.output_enable = True
        channel_data.output_range = output.range
        channel_data.output_mute_enable = output.enable_output_mute

    for input in initialization.inputs or []:
        channel_data = _get_channel_data(input.channel)
        channel_data.input_enable = True
        channel_data.input_range = input.range
        channel_data.input_rf_path = (
            input.port_mode is None or input.port_mode == RecipePortMode.RF.value
        )

    return channels


def _pre_process_sg_channels(
    initialization: Initialization | None,
) -> dict[int, SGChannelRecipeData]:
    if initialization is None or initialization.device_type != "SHFSG":
        return {}

    channels: dict[int, SGChannelRecipeData] = {}

    def _get_channel_data(channel: int) -> SGChannelRecipeData:
        channel_data = channels.get(channel)
        if channel_data is None:
            channel_data = SGChannelRecipeData()
            channels[channel] = channel_data
        return channel_data

    outputs = initialization.outputs or []
    for output in outputs:
        channel_data = _get_channel_data(output.channel)
        channel_data.output_enable = True
        channel_data.output_range = output.range
        channel_data.output_mute_enable = output.enable_output_mute
        channel_data.modulation = output.modulation
        channel_data.marker_source_trigger = output.marker_mode != "MARKER"
        channel_data.output_rf_path = (
            output.port_mode is None or output.port_mode == "rf"
        )
        for route in output.routed_outputs:
            fixed_amplitude, param_amplitude = (
                (None, route.amplitude)
                if isinstance(route.amplitude, str)
                else (route.amplitude, None)
            )
            fixed_phase, param_phase = (
                (None, route.phase)
                if isinstance(route.phase, str)
                else (route.phase, None)
            )
            channel_data.ensure_router_config().append(
                OutputRouteConfig(
                    source=route.from_channel,
                    fixed_amplitude=fixed_amplitude,
                    fixed_phase=fixed_phase,
                    param_amplitude=param_amplitude,
                    param_phase=param_phase,
                )
            )
            # Also enable the router for the source channel, even if no other sources are routing to it,
            # to ensure latency matches between source and destination channels.
            _get_channel_data(route.from_channel).ensure_router_config()

    return channels


def _pre_process_pp_channels(
    initialization: Initialization | None,
) -> dict[int, PPChannelRecipeData]:
    if initialization is None or initialization.device_type != "SHFPPC":
        return {}

    channels = {
        # TODO(2K): convert ppchannel to proper structure
        ppchannel["channel"]: PPChannelRecipeData(settings=ppchannel)
        for ppchannel in initialization.ppchannels or []
    }

    return channels


def _calculate_awg_configs(
    rt_execution_info: RtExecutionInfo,
    scheduled_experiment: ScheduledExperiment,
    devices: DeviceCollection,
) -> AwgConfigs:
    awg_configs = AwgConfigs()

    for _, device in devices.all:
        # Newer interface that assumes all information is in the device-class-specific artifacts.
        # Not yet implemented for all device classes.
        device.fetch_awg_configs(awg_configs, scheduled_experiment.artifacts)

    # TODO(2K): Move recipe data into artifacts.
    recipe = scheduled_experiment.recipe
    for initialization in recipe.initializations:
        awg_type = (
            AwgType.QA
            if initialization.device_type is not None
            and initialization.device_type.startswith("SHFQA")
            else AwgType.SG
        )
        for awg in initialization.awgs or []:
            awg_config = AwgConfig(
                awg_type=awg_type,
                signal_type=(
                    AwgSignalType.IQ
                    if awg.signal_type == AWGSignalType.IQ
                    else AwgSignalType.SINGLE
                ),
                signals=set(awg.signals.keys()),
                source_feedback_register=awg.source_feedback_register,
                register_selector_shift=awg.codeword_bitshift,
                register_selector_bitmask=awg.codeword_bitmask,
                command_table_match_offset=awg.command_table_match_offset,
            )
            if awg_config.source_feedback_register not in (None, "local"):
                if devices.has_qhub:
                    raise LabOneQControllerException(
                        "Global feedback over QHub is not implemented."
                    )
                awg_config.fb_reg_source_index = awg.feedback_register_index_select
                awg_config.fb_reg_target_index = awg.awg
            awg_configs.add(
                AwgKey(device_uid=initialization.device_uid, awg_index=awg.awg),
                awg_config,
            )

    for integrator_allocation in recipe.integrator_allocations:
        awg_key = AwgKey(
            device_uid=integrator_allocation.device_id,
            awg_index=integrator_allocation.awg,
        )
        awg_configs[awg_key].acquire_signals.add(integrator_allocation.signal_id)

    for awg_key, awg_config in awg_configs.items():
        result_length = scheduled_experiment.result_shape_info.result_lengths.get(
            AwgKeyFromData(awg_key.device_uid, awg_key.awg_index)
        )
        if result_length is not None:
            awg_config.result_length = result_length
            awg_configs.update_max_result_length(result_length)

    # Determine the raw acquisition lengths across various acquire events.
    # Will use the maximum length, as scope / monitor can only be configured for one.
    # device_uid + awg_index -> raw acquisition lengths
    raw_acquire_lengths: dict[str, dict[str, int]] = defaultdict(dict)
    raw_acquire_channels: dict[str, set[int]] = defaultdict(set)
    if rt_execution_info.is_raw_acquisition:
        for al in recipe.acquire_lengths:
            ac_awg_key, _ = awg_configs.by_signal(al.signal_id)
            raw_acquire_lengths[ac_awg_key.device_uid][al.signal_id] = al.acquire_length
            raw_acquire_channels[ac_awg_key.device_uid].add(ac_awg_key.awg_index)

    for awg_key, awg_config in awg_configs.items():
        dev_raw_acquire_lengths = raw_acquire_lengths.get(awg_key.device_uid, {})
        # Use dummy raw_acquire_length 4096 if there's no acquire statements in experiment
        raw_acquire_length = max(dev_raw_acquire_lengths.values(), default=4096)
        awg_config.raw_acquire_length = raw_acquire_length

    return awg_configs


def _pre_process_attributes(
    *, recipe: Recipe, devices: DeviceCollection, oscillator_ids: list[str]
) -> AttributeValueTracker:
    attribute_value_tracker = AttributeValueTracker()
    oscillators_check: dict[str, str | float] = {}

    for oscillator_param in recipe.oscillator_params:
        value_or_param = oscillator_param.param or oscillator_param.frequency
        assert value_or_param is not None, "undefined oscillator frequency"
        if oscillator_param.id in oscillators_check:
            if oscillators_check[oscillator_param.id] != value_or_param:
                raise LabOneQControllerException(
                    f"Conflicting specifications for the same oscillator id '{oscillator_param.id}' "
                    f"in the recipe: '{oscillators_check[oscillator_param.id]}' != '{value_or_param}'"
                )
        else:
            oscillators_check[oscillator_param.id] = value_or_param
        attribute_value_tracker.add_attribute(
            device_uid=oscillator_param.device_id,
            attribute=DeviceAttribute(
                name=AttributeName.OSCILLATOR_FREQ,
                index=oscillator_ids.index(oscillator_param.id),
                value_or_param=value_or_param,
            ),
        )

    for initialization in recipe.initializations:
        device = devices.find_by_uid(initialization.device_uid)
        for attribute in device.pre_process_attributes(initialization):
            attribute_value_tracker.add_attribute(
                device_uid=initialization.device_uid,
                attribute=attribute,
            )

    return attribute_value_tracker


def pre_process_compiled(
    scheduled_experiment: ScheduledExperiment,
    devices: DeviceCollection,
) -> RecipeData:
    _validate_scheduled_experiment(scheduled_experiment, devices)

    rt_loop_properties = scheduled_experiment.rt_loop_properties
    rt_execution_info = RtExecutionInfo(
        uid=rt_loop_properties.uid,
        averages=rt_loop_properties.shots,
        averaging_mode=rt_loop_properties.averaging_mode,
        acquisition_type=rt_loop_properties.acquisition_type,
        chunk_count=rt_loop_properties.chunk_count,
    )

    for _, device in devices.all:
        device.validate_scheduled_experiment(scheduled_experiment, rt_execution_info)

    recipe = scheduled_experiment.recipe
    # Mapping of the unique oscillator ids to integer indices for use with the AttributeValueTracker
    oscillator_ids = list(set(o.id for o in recipe.oscillator_params))

    awg_configs = _calculate_awg_configs(
        rt_execution_info, scheduled_experiment, devices
    )

    device_settings: dict[DeviceUID, DeviceRecipeData] = {}
    for device_uid, _ in devices.all:
        init = get_initialization_by_device_uid(recipe, device_uid)
        device_settings[device_uid] = DeviceRecipeData(
            is_present=init is not None,
            start_trigger_repetitions=1 if init is None else init.config.repetitions,
            iq_settings=_pre_process_iq_settings_hdawg(init),
            allocated_oscs=_pre_process_oscillator_allocations(
                recipe=recipe, oscillator_ids=oscillator_ids, device_id=device_uid
            ),
            uhfqacore=_pre_process_uhfqa(init),
            hdawgcores=_pre_process_hd_awgs(init),
            qachannels=_pre_process_qa_channels(init),
            sgchannels=_pre_process_sg_channels(init),
            ppchannels=_pre_process_pp_channels(init),
            awg_configs={
                awg_key.awg_index: awg_config
                for awg_key, awg_config in awg_configs.items()
                if awg_key.device_uid == device_uid
            },
            has_feedback=any(
                awg_config.source_feedback_register is not None
                for awg_key, awg_config in awg_configs.items()
                if awg_key.device_uid == device_uid
            ),
        )

    recipe_data = RecipeData(
        scheduled_experiment=scheduled_experiment,
        recipe=recipe,
        execution=scheduled_experiment.execution,
        rt_execution_info=rt_execution_info,
        device_settings=device_settings,
        awg_configs=awg_configs,
        attribute_value_tracker=_pre_process_attributes(
            recipe=recipe, devices=devices, oscillator_ids=oscillator_ids
        ),
        max_step_execution_time=recipe.max_step_execution_time,
    )

    for _, device in devices.all:
        device.validate_recipe_data(recipe_data)

    return recipe_data


def calc_result_transfer_base_time(recipe_data: RecipeData) -> float:
    # The maximum result block size is figured out by taking the maximum result length
    # and multiplying it by 16 bytes per sample (complex128). We assume a default transfer
    # speed of 1MB/s (conservative). The final timeout is then scaled based on the timeout the user
    # sets during connect, compared to the default 10-second connect timeout.
    return recipe_data.awg_configs.max_result_length * 16 / (2**20)


def get_execution_time(recipe_data: RecipeData) -> tuple[float, float]:
    rt_execution_info = recipe_data.rt_execution_info
    min_wait_time = recipe_data.max_step_execution_time
    if rt_execution_info.is_chunked:
        pipeliner_reload_worst_case = 1500e-6
        min_wait_time = (
            min_wait_time + pipeliner_reload_worst_case
        ) * rt_execution_info.chunk_count_or_1

    # Add extra guard time for potential state node update delayed by the
    # large result transfer from a previous measurement. Assume up to two result blocks
    # of maximum size may need to be delivered before the state update.
    extra_guard_for_results = calc_result_transfer_base_time(recipe_data) * 2

    # +10% and fixed 1sec guard time rounded up to next full second
    guarded_wait_time = round((min_wait_time + extra_guard_for_results) * 1.1 + 1.5)

    return min_wait_time, guarded_wait_time


def get_readout_time(recipe_data: RecipeData) -> tuple[float, float]:
    # In the async execution model, result waiting starts as soon as execution begins,
    # so the execution time must be included when calculating the result retrieval timeout.
    _, guarded_wait_time = get_execution_time(recipe_data)
    max_result_wait_time = calc_result_transfer_base_time(recipe_data)
    return guarded_wait_time, max_result_wait_time


def get_weights_info(
    artifacts: ArtifactsCodegen, kernel_ref: str | None
) -> dict[str, list[WeightInfo]]:
    if kernel_ref is None:
        return {}
    return artifacts.integration_weights.get(kernel_ref, {})


@overload
def get_wave(wave_name: str, waves: dict[str, CodegenWaveform]) -> CodegenWaveform: ...


@overload
def get_wave(
    wave_name: str, waves: dict[str, CodegenWaveform], optional: bool = True
) -> CodegenWaveform | None: ...


def get_wave(
    wave_name: str, waves: dict[str, CodegenWaveform], optional: bool = False
) -> CodegenWaveform | None:
    wave = waves.get(wave_name)
    if wave is None:
        if optional:
            return None
        raise LabOneQControllerException(
            f"Wave '{wave_name}' is not found in the compiled waves collection."
        )
    return wave


def get_marker_samples(
    wave_name: str, waves: dict[str, CodegenWaveform]
) -> NumPyArray | None:
    marker_wave = get_wave(wave_name, waves, optional=True)
    if marker_wave is None:
        return None
    samples = marker_wave.samples
    if samples is not None and np.any(samples * (1 - samples)):
        raise LabOneQControllerException(
            "Marker samples must only contain ones and zeros"
        )
    return np.array(samples, order="C")


def get_iq_marker_samples(
    sig: str, waves: dict[str, CodegenWaveform]
) -> NumPyArray | None:
    marker_samples = get_marker_samples(f"{sig}_marker1.wave", waves)
    marker2_samples = get_marker_samples(f"{sig}_marker2.wave", waves)
    if marker2_samples is not None:
        marker2_len = len(marker2_samples)
        if marker_samples is None:
            marker_samples = np.zeros(marker2_len, dtype=np.int32)
        elif len(marker_samples) != marker2_len:
            raise LabOneQControllerException(
                "Samples for marker1 and marker2 must have the same length"
            )
        # we want marker 2 to be played on output 2, marker 1
        # bits 0/1 = marker 1/2 of output 1, bit 2/4 = marker 1/2 output 2
        # bit 2 is factor 4
        factor = 4
        marker_samples += factor * marker2_samples
    return marker_samples


@dataclass
class WaveformItem:
    index: int
    name: str
    samples: NumPyArray
    hold_start: int | None = None
    hold_length: int | None = None


Waveforms = list[WaveformItem]


def _prepare_wave_iq(
    waves: dict[str, CodegenWaveform], sig: str, index: int
) -> WaveformItem:
    wave_i = get_wave(f"{sig}_i.wave", waves)
    wave_q = get_wave(f"{sig}_q.wave", waves)
    marker_samples = get_iq_marker_samples(sig, waves)
    return WaveformItem(
        index=index,
        name=sig,
        samples=zhinst.utils.convert_awg_waveform(
            np.clip(np.ascontiguousarray(wave_i.samples), -1, 1),
            np.clip(np.ascontiguousarray(wave_q.samples), -1, 1),
            markers=marker_samples,
        ),
    )


def _prepare_wave_single(
    waves: dict[str, CodegenWaveform], sig: str, index: int
) -> WaveformItem:
    wave = get_wave(f"{sig}.wave", waves)
    marker_samples = get_marker_samples(f"{sig}_marker1.wave", waves)
    return WaveformItem(
        index=index,
        name=sig,
        samples=zhinst.utils.convert_awg_waveform(
            np.clip(np.ascontiguousarray(wave.samples), -1, 1),
            markers=marker_samples,
        ),
    )


def _prepare_wave_complex(
    waves: dict[str, CodegenWaveform], sig: str, index: int
) -> WaveformItem:
    wave = get_wave(f"{sig}.wave", waves)
    return WaveformItem(
        index=index,
        name=sig,
        samples=np.ascontiguousarray(wave.samples, dtype=np.complex128),
        hold_start=wave.hold_start,
        hold_length=wave.hold_length,
    )


def prepare_waves(
    artifacts: ArtifactsCodegen,
    wave_indices_ref: str | None,
) -> Waveforms | None:
    if wave_indices_ref is None:
        return None
    if artifacts.wave_indices is None:
        return None
    wave_indices: dict[str, tuple[int, WaveType]] = cast(
        dict[str, tuple[int, WaveType]],
        next(
            (i for i in artifacts.wave_indices if i["filename"] == wave_indices_ref),
            {},
        )["value"],
    )

    waves: Waveforms = []
    for sig, (index, sig_type) in [
        i for i in wave_indices.items() if i[0] != "filename"
    ]:
        if sig.startswith("precomp_reset"):
            continue  # precomp reset waveform is bundled with ELF
        if sig_type in (WaveType.IQ, WaveType.DOUBLE):
            wave = _prepare_wave_iq(artifacts.waves, sig, index)
        elif sig_type == WaveType.SINGLE:
            wave = _prepare_wave_single(artifacts.waves, sig, index)
        elif sig_type == WaveType.COMPLEX:
            wave = _prepare_wave_complex(artifacts.waves, sig, index)
        else:
            raise LabOneQControllerException(
                f"Unexpected signal type for binary wave for '{sig}' in '{wave_indices_ref}' - "
                f"'{sig_type}', should be one of [iq, double, single, complex]"
            )
        waves.append(wave)

    return waves


def prepare_command_table(
    artifacts: ArtifactsCodegen, ct_ref: str | None
) -> dict | None:
    if ct_ref is None:
        return None
    return next(
        (ct["ct"] for ct in artifacts.command_tables if ct["seqc"] == ct_ref),
        None,
    )
