# Project Version

## Overview

Planar can expose your project's version alongside the Planar SDK version via the system info API. This helps teams verify which version of their application is deployed.

## Configuration

Pass `project_version` when creating your `PlanarApp`:

```python
from planar import PlanarApp, get_package_version

app = PlanarApp(
    title="My App",
    description="My application",
    project_version=get_package_version("my-app"),
)
```

The `project_version` parameter accepts any string, so you can use whichever strategy fits your deployment:

### Package Version

`get_package_version(name)` reads the version from installed Python package metadata (i.e. the `version` field in `pyproject.toml`):

```python
from planar import PlanarApp, get_package_version

app = PlanarApp(
    project_version=get_package_version("rw-orders"),  # e.g. "0.1.0"
)
```

Returns `None` if the package is not installed.

### Git Commit Hash

`get_git_commit_hash()` returns the short git commit SHA. It checks the `COMMIT_SHA` environment variable first, then falls back to running `git rev-parse --short HEAD`:

```python
from planar import PlanarApp, get_git_commit_hash

app = PlanarApp(
    project_version=get_git_commit_hash(),  # e.g. "d6b0266"
)
```

Returns `None` if neither the env var is set nor git is available.

### Combining Both

You can fall back from one strategy to the other:

```python
from planar import PlanarApp, get_git_commit_hash, get_package_version

app = PlanarApp(
    project_version=get_package_version("my-app") or get_git_commit_hash(),
)
```

## CI/CD Setup

### Setting `COMMIT_SHA` in Docker

Most CI platforms expose the git SHA. Pass it as a build arg:

```dockerfile
ARG COMMIT_SHA
ENV COMMIT_SHA=$COMMIT_SHA
```

```yaml
# GitHub Actions
- run: docker build --build-arg COMMIT_SHA=${{ github.sha }} .
```

With `COMMIT_SHA` set, `get_git_commit_hash()` returns it directly without needing git installed in the container.

### Package Version in CI

If you use `get_package_version()`, ensure CI sets the version in `pyproject.toml` before building:

```bash
uv version $VERSION
uv build --wheel
```

## API

The project version is returned in the `/planar/v1/system-info` endpoint as `project_version`:

```json
{
  "title": "My App",
  "version": "1.2.0",
  "project_version": "0.1.0",
  "environment": "prod",
  ...
}
```

The field is `null` when no project version is configured.
