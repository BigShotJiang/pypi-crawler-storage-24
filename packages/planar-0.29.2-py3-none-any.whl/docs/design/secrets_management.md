# Pluggable Secrets Management and Configuration Resolution Strategy

## 1. Context & Motivation

Currently, the Planar configuration system (`PlanarConfig`) and its corresponding `planar.yaml` relies exclusively on environment variable substitution (`os.path.expandvars`) during the loading process. While simple, this approach has significant limitations:

*   **Security Risk**: Sensitive secrets must be exposed as environment variables, which can leak into logs, or debugging output.
*   **Operational Complexity**: Managing secrets across different environments and clouds requires external orchestration to inject them as env vars before the application starts. This leads to e.g. custom code such as
 `config.py` in apps' business logic repos (and differs per cloud provider).
*   **Lack of Flexibility**: There is no native framework-level support for fetching secrets directly from dedicated secrets management services (AWS Secrets Manager, Azure Key Vault) within the configuration file itself and no framework abstractions to do so - thus making developers of business app to think about specific implementation per cloud.

## 2. Objective

To design and implement a robust, pluggable secrets management system integrated into the application's configuration loading lifecycle. This system will allow secrets to be referenced in `planar.yaml` using a custom syntax, resolved at runtime from configured providers, and injected before final Pydantic validation. Adds ability to obtain custom api secrets using Planar framework abstractions. Crucially, it must support **custom user-defined providers** similar to the AI provider registry. 

### 2.1 Non-Objective
We do not touch secrets rotation or secrets configuration via CoPlane UI in this proposal.

## 3. Architecture

The solution introduces a `SecretRegistry` and a set of `SecretProvider` implementations that are initialized during the configuration bootstrap phase.

### 3.1. Secret Provider Protocol

We will define a protocol that all secret providers must implement. This ensures a consistent interface for retrieving secrets regardless of the backend.

```python
from typing import Protocol, Any

class SecretProvider(Protocol):
    def __init__(self, config: dict[str, Any]):
        """
        Initialize the provider with configuration from planar.yaml.
        """
        ...

    def get_secret(self, secret_id: str) -> str | None:
        """
        Retrieve a secret by its ID.
        Returns None if the secret is not found.
        """
        ...
```

### 3.2. Concrete Providers

We will implement three initial providers in `planar/secrets/providers.py`:

1.  **`EnvVarSecretProvider`**:
    *   **Description**: Wraps `os.environ`. Serves as the default fallback.
    *   **Resolution**: `get_secret("MY_VAR")` -> `os.environ.get("MY_VAR")`.

2.  **`AwsSecretsManagerProvider`**:
    *   **Description**: Fetches secrets from AWS Secrets Manager using `boto3`.
    *   **Resolution**: `get_secret("prod/db/password")` calls `get_secret_value`.

3.  **`AzureKeyVaultProvider`**:
    *   **Description**: Fetches secrets from Azure Key Vault using `azure-keyvault-secrets`.
    *   **Resolution**: `get_secret("db-password")` calls `get_secret`.

### 3.3. Secret Registry

The `SecretRegistry` will manage the lifecycle of providers and handle the resolution logic. It supports:

1.  **Built-in providers**: `env`, `aws_secrets_manager`, `azure_key_vault`.
2.  **Registered custom providers**: Providers registered via `SecretRegistry.register_provider_type`.

```python
class SecretRegistry:
    _provider_types: dict[str, Type[SecretProvider]] = { ... }

    @classmethod
    def register_provider_type(cls, name: str, provider_cls: Type[SecretProvider]) -> None:
        """Register a custom provider class with a label."""
        ...

    def __init__(self):
        self._providers: dict[str, SecretProvider] = {}

    def register(self, name: str, provider: SecretProvider) -> None:
        self._providers[name] = provider

    def get_provider(self, name: str) -> SecretProvider:
        # Returns provider or raises error
        ...

    def resolve_secret(self, provider_name: str, secret_id: str, json_key: str | None = None) -> str:
        # 1. Get provider
        # 2. Call provider.get_secret(secret_id)
        # 3. If json_key is present, parse JSON and extract key
        # 4. Return value
        ...
```

## 4. Configuration Schema Updates

We will update `PlanarConfig` in `planar/config.py` to support configuring these providers.

### 4.1. Provider Configuration Models

We will use a discriminated union or a generic model to allow flexibility, especially for custom providers.

```python
from typing import Literal

class ProviderConfig(BaseModel):
    # Built-in provides: "env", "aws_secrets_manager", "azure_key_vault"
    # OR a registered custom provider label
    provider: str

    # Arbitrary configuration passed to the provider's __init__
    options: dict[str, Any] = Field(default_factory=dict)

class SecretsSection(BaseModel):
    providers: dict[str, ProviderConfig] = Field(default_factory=dict)
    custom_secrets: dict[str, SecretStr] = Field(default_factory=dict)
```

### 4.2. Updated `PlanarConfig`

```python
class PlanarConfig(BaseModel):
    # ... existing fields ...
    secrets: SecretsSection | None = None
```

## 5. Resolution Syntax & Logic

We will support a custom interpolation syntax within the YAML configuration:

```
${secret:<provider_name>:<secret_id>[:<json_key>]}
```

*   `provider_name`: Matches a key in `secrets.providers`.
*   `secret_id`: The identifier used by the provider.
*   `json_key` (Optional): If the secret value is a JSON string, extract this field.

## 6. Implementation Strategy: Two-Pass Loading

To support custom providers and provider configuration via env vars, we use a two-pass strategy in `load_environment_aware_config`.

### Phase 1: Bootstrap

1.  **Load Raw YAML**: Read `planar.yaml` into a raw Python dictionary.
2.  **Standard Env Expansion (Scoped)**: Perform `os.path.expandvars` on the `secrets` section *only*.
3.  **Initialize Registry**:
    *   Iterate through `secrets.providers`.
    *   Check if `provider` matches a registered type (built-in or custom registered via `register_provider_type`).
    *   If found, instantiate the registered class.
    *   Register the instance in `SecretRegistry`.

### Phase 2: Resolution

1.  **Full Traversal**: Traverse the *entire* raw configuration dictionary.
2.  **Detect & Resolve**: For every string matching `${secret:...}`:
    *   Parse the string.
    *   Call `registry.resolve_secret(...)`.
    *   Replace the placeholder with the resolved value.
3.  **Standard Env Expansion (Global)**: Perform a final pass of `os.path.expandvars` on the rest of the config.

### Phase 3: Validation

1.  **Model Validation**: Pass the fully resolved dictionary to `PlanarConfig.model_validate()`.

## 7. Example Usage

### Built-in Provider
```yaml
secrets:
  providers:
    aws_prod:
      provider: aws_secrets_manager
      options:
        region: us-west-2

app:
  db_connection: app
db_connections:
  app:
    driver: postgresql
    password: ${secret:aws_prod:prod/db/credentials:password}
```

### Custom Provider (Registered via Code)

You can register a custom provider with a label in your application code before the config is loaded. This is the preferred method for custom providers. This must be done before PlanarApp() is created.

```python
# main.py
from planar.secrets.protocol import SecretProvider
from planar.secrets.registry import SecretRegistry

class MyCustomProvider(SecretProvider):
    def __init__(self, options: dict[str, Any]):
        self.options = options
    
    def get_secret(self, secret_id: str) -> str:
        # ... implementation ...
        pass

# Register with a label, must be done before PlanarApp() is created
SecretRegistry.register_provider_type("my_custom", MyCustomProvider)

app = PlanarApp()
```

```yaml
# planar.yaml
secrets:
  providers:
    my_vault:
      provider: my_custom  # Use the registered label
      options:
        url: https://vault.myorg.internal
  custom_secrets:
    stripe: ${secret:my_vault:stripe_live_key}
```

## Proposed API to reference secrets in code
The proposed API to reference secrets in code is to access them via the loaded `PlanarConfig` object.
Since secrets are resolved during the configuration loading phase, they are available as standard values in the configuration object.
For arbitrary application secrets, you should use the `secrets.custom_secrets` dictionary:

```python
from planar.config import load_environment_aware_config

config = load_environment_aware_config()

# Accessing a custom secret
stripe_key = config.secrets.custom_secrets["stripe"]
```

## 9. Deliverables

1.  `planar/secrets/protocol.py`: `SecretProvider` protocol.
2.  `planar/secrets/providers.py`: Built-in implementations.
3.  `planar/secrets/registry.py`: `SecretRegistry`.
4.  `planar/config.py`: Updated `PlanarConfig` and `load_environment_aware_config` logic.
5.  Tests for registry, providers, and config loading.
6.  `docs/design/secrets_management.md`.
