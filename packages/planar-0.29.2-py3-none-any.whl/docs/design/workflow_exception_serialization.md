# Workflow Exception Serialization

This document describes the current behavior of exception persistence and replay in workflows.

## Overview

Workflow and step failures are persisted as a versioned JSON envelope and restored on replay.

Core implementation lives in:

- `planar/workflows/exceptions.py`
- `planar/workflows/step_core.py`
- `planar/workflows/execution.py`
- `planar/human/exceptions.py`

## Envelope Format (V1)

Persisted errors use this shape:

```json
{
  "schema_version": 1,
  "code": "workflow.foreign_exception@1",
  "message": "error message",
  "data": {},
  "traceback": "....",
  "type": "ValueError",
  "cancelled": false
}
```

Fields:

- `code`: stable restore key (registry lookup).
- `message`: exception message.
- `data`: structured payload for `WorkflowException` subclasses.
- `traceback`: debug field (not used for type restoration).
- `type`: compatibility/debug field.
- `cancelled`: compatibility/debug field.

## Exception Model

`WorkflowException[TData]` is the base class for framework and user-defined replayable exceptions.

Behavior:

- Subclasses auto-register in an internal registry via `__init_subclass__`.
- `code` defaults to `<snake_case_class_name>@1` unless explicitly set.
- `data_type` is explicit and optional (`type[BaseModel] | None`).

Example:

```python
class PaymentDeclinedData(BaseModel):
    reason: str

class PaymentDeclined(WorkflowException[PaymentDeclinedData]):
    code = "billing.payment_declined@1"
    data_type = PaymentDeclinedData
```

## Serialization Rules

`serialize_exception(exc)`:

- If `exc` is a `WorkflowException`:
  - `code = exc.code`
  - `data = exc.data.model_dump(mode="json")` (or `{}` if no data)
- Otherwise:
  - `code = "workflow.foreign_exception@1"`
  - `data = {}`
- Always includes `message`, `traceback`, and compatibility fields (`type`, `cancelled`).

Step and workflow execution paths persist errors through this function.

## Deserialization Rules

`deserialize_exception(raw)`:

1. Normalize input to V1 envelope:
   - parse V1 directly, or
   - parse legacy `{type, message, traceback?, cancelled?}` and map to V1.
2. If `code` exists in `WorkflowException` registry:
   - if `data_type` is set, validate `data` using `model_validate`;
   - on validation failure, fall back to generic `WorkflowException(message)`;
   - otherwise instantiate the registered class.
3. If `code == workflow.foreign_exception@1`:
   - try restoring to a built-in exception using `type` (for example `ValueError`);
   - otherwise return generic `WorkflowException(message)`.
4. Unknown/unregistered codes restore as generic `WorkflowException(message)`.

`try_restore_exception(...)` wraps this and falls back to `StepError` on malformed payloads.

## Cancellation Exceptions

Framework cancellation codes:

- `workflow.cancelled@1` (`WorkflowCancelledException`)

Current orchestration behavior:

- Workflow notification suppression for "failed" events is based on
  `isinstance(e, WorkflowCancelledException)` in execution flow.

## Practical Limits

- Full fidelity reconstruction of arbitrary custom exceptions is not supported.
- For non-`WorkflowException` custom exceptions, replay restores either:
  - a built-in exception (if `type` maps to builtins), or
  - generic `WorkflowException(message)`.
- Traceback is preserved in persisted error payload for diagnostics only.
