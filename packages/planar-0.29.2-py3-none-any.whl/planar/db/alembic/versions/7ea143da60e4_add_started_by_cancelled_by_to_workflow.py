"""add started_by cancelled_by to workflow

Revision ID: 7ea143da60e4
Revises: 28c48a017ceb
Create Date: 2026-02-18 12:00:00.000000

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "7ea143da60e4"
down_revision: Union[str, None] = "28c48a017ceb"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("workflow", schema="planar") as batch_op:
        batch_op.add_column(sa.Column("started_by", sa.String(), nullable=True))
        batch_op.add_column(sa.Column("cancelled_by", sa.String(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("workflow", schema="planar") as batch_op:
        batch_op.drop_column("cancelled_by")
        batch_op.drop_column("started_by")
