from typing import Literal, Self

from pydantic import BaseModel, Field

from planar.ai.utils import StepWithWorkflow
from planar.routers.models import WorkflowStepInfo
from planar.routers.step_metadata import (
    AgentMetadata,
    ComputeMetadata,
    HumanTaskMetadata,
    MessageMetadata,
    RuleMetadata,
    StepMetadata,
    ToolCallMetadata,
)
from planar.workflows.models import StepType


def _build_base_step(sw: StepWithWorkflow) -> WorkflowStepInfo:
    return WorkflowStepInfo.from_step(sw.step, metadata={})


class AgentStep(BaseModel):
    step_type: Literal[StepType.AGENT] = Field(default=StepType.AGENT, init=False)
    workflow_name: str
    base: WorkflowStepInfo
    meta: AgentMetadata | None = None

    @classmethod
    def from_step(cls, sw: StepWithWorkflow, metadata: dict[int, StepMetadata]) -> Self:
        meta = metadata.get(sw.step.step_id)
        if meta is not None and not isinstance(meta, AgentMetadata):
            raise TypeError(
                f"metadata type mismatch for step {sw.step.step_id}: "
                f"expected AgentMetadata, got {type(meta).__name__}"
            )
        return cls(
            workflow_name=sw.workflow_name,
            base=_build_base_step(sw),
            meta=meta,
        )


class RuleStep(BaseModel):
    step_type: Literal[StepType.RULE] = Field(default=StepType.RULE, init=False)
    workflow_name: str
    base: WorkflowStepInfo
    meta: RuleMetadata | None = None

    @classmethod
    def from_step(cls, sw: StepWithWorkflow, metadata: dict[int, StepMetadata]) -> Self:
        meta = metadata.get(sw.step.step_id)
        if meta is not None and not isinstance(meta, RuleMetadata):
            raise TypeError(
                f"metadata type mismatch for step {sw.step.step_id}: "
                f"expected RuleMetadata, got {type(meta).__name__}"
            )
        return cls(
            workflow_name=sw.workflow_name,
            base=_build_base_step(sw),
            meta=meta,
        )


class ToolCallStep(BaseModel):
    step_type: Literal[StepType.TOOL_CALL] = Field(
        default=StepType.TOOL_CALL, init=False
    )
    workflow_name: str
    base: WorkflowStepInfo
    meta: ToolCallMetadata | None = None

    @classmethod
    def from_step(cls, sw: StepWithWorkflow, metadata: dict[int, StepMetadata]) -> Self:
        meta = metadata.get(sw.step.step_id)
        if meta is not None and not isinstance(meta, ToolCallMetadata):
            raise TypeError(
                f"metadata type mismatch for step {sw.step.step_id}: "
                f"expected ToolCallMetadata, got {type(meta).__name__}"
            )
        return cls(
            workflow_name=sw.workflow_name,
            base=_build_base_step(sw),
            meta=meta,
        )


class HumanStep(BaseModel):
    step_type: Literal[StepType.HUMAN_IN_THE_LOOP] = Field(
        default=StepType.HUMAN_IN_THE_LOOP, init=False
    )
    workflow_name: str
    base: WorkflowStepInfo
    meta: HumanTaskMetadata | None = None

    @classmethod
    def from_step(cls, sw: StepWithWorkflow, metadata: dict[int, StepMetadata]) -> Self:
        meta = metadata.get(sw.step.step_id)
        if meta is not None and not isinstance(meta, HumanTaskMetadata):
            raise TypeError(
                f"metadata type mismatch for step {sw.step.step_id}: "
                f"expected HumanTaskMetadata, got {type(meta).__name__}"
            )
        return cls(
            workflow_name=sw.workflow_name,
            base=_build_base_step(sw),
            meta=meta,
        )


class MessageStep(BaseModel):
    step_type: Literal[StepType.MESSAGE] = Field(default=StepType.MESSAGE, init=False)
    workflow_name: str
    base: WorkflowStepInfo
    meta: MessageMetadata | None = None

    @classmethod
    def from_step(cls, sw: StepWithWorkflow, metadata: dict[int, StepMetadata]) -> Self:
        meta = metadata.get(sw.step.step_id)
        if meta is not None and not isinstance(meta, MessageMetadata):
            raise TypeError(
                f"metadata type mismatch for step {sw.step.step_id}: "
                f"expected MessageMetadata, got {type(meta).__name__}"
            )
        return cls(
            workflow_name=sw.workflow_name,
            base=_build_base_step(sw),
            meta=meta,
        )


class ComputeStep(BaseModel):
    step_type: Literal[StepType.COMPUTE] = Field(default=StepType.COMPUTE, init=False)
    workflow_name: str
    base: WorkflowStepInfo
    meta: ComputeMetadata | None = None

    @classmethod
    def from_step(cls, sw: StepWithWorkflow, metadata: dict[int, StepMetadata]) -> Self:
        meta = metadata.get(sw.step.step_id)
        if meta is not None and not isinstance(meta, ComputeMetadata):
            raise TypeError(
                f"metadata type mismatch for step {sw.step.step_id}: "
                f"expected ComputeMetadata, got {type(meta).__name__}"
            )
        return cls(
            workflow_name=sw.workflow_name,
            base=_build_base_step(sw),
            meta=meta,
        )


class AgentStepList(BaseModel):
    items: list[AgentStep]
    total: int
    offset: int
    limit: int
