from datetime import date, datetime
from enum import Enum
from types import NoneType, UnionType
from typing import Any, Never, Union, get_args, get_origin
from uuid import UUID

from fastapi import APIRouter, HTTPException
from sqlalchemy import ColumnElement, String, cast, func
from sqlmodel import select

from planar.logging import get_logger
from planar.modeling.orm.query_filter_builder import build_paginated_query
from planar.object_registry import ObjectRegistry
from planar.routers.models import (
    DateEntityFilter,
    EntityInstance,
    EntityInstanceList,
    EntityInstancesQuery,
    EntityMetadata,
    EntityQueryFilter,
    EnumEntityFilter,
    NumberEntityFilter,
    SortDirection,
    TextEntityFilter,
)
from planar.session import get_session
from planar.utils import one_or_raise

logger = get_logger(__name__)


def _escape_like(value: str) -> str:
    """Escape SQL LIKE/ILIKE wildcard characters in user input."""
    return value.replace("\\", "\\\\").replace("%", r"\%").replace("_", r"\_")


def _unwrap_optional(annotation: Any) -> Any:
    if get_origin(annotation) not in (UnionType, Union):
        return annotation

    args = get_args(annotation)
    assert len(args) == 2 and NoneType in args, (
        f"Expected optional annotation in the form X | None, got {annotation!r}"
    )
    return next(arg for arg in args if arg is not NoneType)


def _coerce_enum_filter_value(raw_value: Any, annotation: type[Enum]) -> Enum:
    string_value = str(raw_value)

    try:
        if issubclass(annotation, int):
            # IntEnum
            return annotation(int(string_value))
        return annotation(string_value)
    except (ValueError, KeyError):
        pass

    normalized = string_value.casefold()
    for member in annotation:
        if str(member.value).casefold() == normalized:
            return member

    raise ValueError(f"'{raw_value}' is not a valid {annotation.__name__}")


def _coerce_filter_value(raw_value: Any, annotation: Any, field_name: str) -> Any:
    annotation = _unwrap_optional(annotation)

    try:
        if raw_value is None:
            return None
        if annotation is Any:
            return raw_value
        if isinstance(annotation, type) and issubclass(annotation, Enum):
            return _coerce_enum_filter_value(raw_value, annotation)
        if annotation is bool:
            if isinstance(raw_value, bool):
                return raw_value
            lower_value = str(raw_value).lower()
            if lower_value in {"true", "1", "yes"}:
                return True
            if lower_value in {"false", "0", "no"}:
                return False
            raise ValueError("invalid boolean")
        if annotation is float:
            return float(raw_value)
        if annotation is UUID:
            if isinstance(raw_value, UUID):
                return raw_value
            return UUID(str(raw_value))
        if annotation is datetime:
            if isinstance(raw_value, datetime):
                return raw_value
            return datetime.fromisoformat(str(raw_value).replace("Z", "+00:00"))
        if annotation is date:
            if isinstance(raw_value, datetime):
                return raw_value.date()
            if isinstance(raw_value, date):
                return raw_value
            return date.fromisoformat(str(raw_value))
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid filter value '{raw_value}' for field '{field_name}'",
        ) from exc

    return raw_value


def _build_like_filter(
    *,
    column: Any,
    annotation: Any,
    field_name: str,
    operator: str,
    raw_value: str,
) -> ColumnElement[bool]:
    annotation = _unwrap_optional(annotation)
    escaped_value = _escape_like(raw_value)
    pattern = f"%{escaped_value}%" if operator == "contains" else f"{escaped_value}%"

    if annotation is str:
        return column.ilike(pattern, escape="\\")
    if annotation is UUID:
        # Normalize UUIDs so searches work across dashed/non-dashed storage formats.
        normalized = raw_value.replace("-", "").lower()
        escaped_normalized = _escape_like(normalized)
        normalized_pattern = (
            f"%{escaped_normalized}%"
            if operator == "contains"
            else f"{escaped_normalized}%"
        )
        return func.lower(func.replace(cast(column, String), "-", "")).like(
            normalized_pattern, escape="\\"
        )

    raise HTTPException(
        status_code=400,
        detail=(
            f"Filter operator '{operator}' requires a text or UUID field; "
            f"field '{field_name}' is not compatible"
        ),
    )


def _raise_unsupported_filter_operator(operator: Never) -> Never:
    raise HTTPException(
        status_code=400,
        detail=f"Unsupported filter operator '{operator}'",
    )


def _raise_unsupported_filter_type(filter_item: Never) -> Never:
    raise HTTPException(
        status_code=400,
        detail=f"Unsupported filter type '{type(filter_item).__name__}'",
    )


def _build_enum_filters(
    *,
    column: Any,
    annotation: Any,
    field_name: str,
    filter_item: EnumEntityFilter,
) -> list[ColumnElement[bool]]:
    if not filter_item.value:
        raise HTTPException(
            status_code=400,
            detail=f"Filter field '{field_name}' requires a non-empty list value",
        )

    coerced_values = [
        _coerce_filter_value(item, annotation, field_name) for item in filter_item.value
    ]

    match filter_item.operator:
        case "is":
            return [column.in_(coerced_values)]
        case "is_not":
            return [column.not_in(coerced_values)]
        case unsupported_operator:
            _raise_unsupported_filter_operator(unsupported_operator)


def _build_text_filters(
    *,
    column: Any,
    annotation: Any,
    field_name: str,
    filter_item: TextEntityFilter,
) -> list[ColumnElement[bool]]:
    match filter_item.operator:
        case "contains" | "starts_with":
            return [
                _build_like_filter(
                    column=column,
                    annotation=annotation,
                    field_name=field_name,
                    operator=filter_item.operator,
                    raw_value=filter_item.value,
                )
            ]
        case "is":
            coerced_value = _coerce_filter_value(
                filter_item.value, annotation, field_name
            )
            return [column == coerced_value]
        case "is_not":
            coerced_value = _coerce_filter_value(
                filter_item.value, annotation, field_name
            )
            return [column != coerced_value]
        case unsupported_operator:
            _raise_unsupported_filter_operator(unsupported_operator)


def _build_number_filters(
    *,
    column: Any,
    annotation: Any,
    field_name: str,
    filter_item: NumberEntityFilter,
) -> list[ColumnElement[bool]]:
    coerced_value = _coerce_filter_value(filter_item.value, annotation, field_name)

    match filter_item.operator:
        case "==":
            return [column == coerced_value]
        case "!=":
            return [column != coerced_value]
        case ">":
            return [column > coerced_value]
        case ">=":
            return [column >= coerced_value]
        case "<":
            return [column < coerced_value]
        case "<=":
            return [column <= coerced_value]
        case unsupported_operator:
            _raise_unsupported_filter_operator(unsupported_operator)


def _build_date_filters(
    *,
    column: Any,
    annotation: Any,
    field_name: str,
    filter_item: DateEntityFilter,
) -> list[ColumnElement[bool]]:
    match filter_item.operator:
        case "between":
            if filter_item.value_end is None:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Filter field '{field_name}' with 'between' requires "
                        "filter_value_end"
                    ),
                )
            start_value = _coerce_filter_value(
                filter_item.value, annotation, field_name
            )
            end_value = _coerce_filter_value(
                filter_item.value_end,
                annotation,
                field_name,
            )
            return [column >= start_value, column <= end_value]
        case "before":
            coerced_value = _coerce_filter_value(
                filter_item.value, annotation, field_name
            )
            return [column < coerced_value]
        case "after":
            coerced_value = _coerce_filter_value(
                filter_item.value, annotation, field_name
            )
            return [column > coerced_value]
        case unsupported_operator:
            _raise_unsupported_filter_operator(unsupported_operator)


def _build_filters(
    *,
    entity_class: type,
    filters: list[EntityQueryFilter] | None,
) -> list[ColumnElement[bool]]:
    if not filters:
        return []

    built_filters: list[ColumnElement[bool]] = []
    table_columns = entity_class.__table__.columns

    for filter_item in filters:
        field_name = filter_item.field
        if field_name not in table_columns:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid filter field '{field_name}'",
            )

        column = getattr(entity_class, field_name)
        model_field = entity_class.model_fields.get(field_name)
        annotation = model_field.annotation if model_field else str

        match filter_item:
            case EnumEntityFilter():
                built_filters.extend(
                    _build_enum_filters(
                        column=column,
                        annotation=annotation,
                        field_name=field_name,
                        filter_item=filter_item,
                    )
                )
            case TextEntityFilter():
                built_filters.extend(
                    _build_text_filters(
                        column=column,
                        annotation=annotation,
                        field_name=field_name,
                        filter_item=filter_item,
                    )
                )
            case NumberEntityFilter():
                built_filters.extend(
                    _build_number_filters(
                        column=column,
                        annotation=annotation,
                        field_name=field_name,
                        filter_item=filter_item,
                    )
                )
            case DateEntityFilter():
                built_filters.extend(
                    _build_date_filters(
                        column=column,
                        annotation=annotation,
                        field_name=field_name,
                        filter_item=filter_item,
                    )
                )
            case unsupported_filter:
                _raise_unsupported_filter_type(unsupported_filter)

    return built_filters


def _resolve_sorting(
    *,
    entity_class: type,
    sort_field: str | None,
    sort_direction: SortDirection | None,
) -> tuple[Any | None, SortDirection | None]:
    if not sort_field:
        return None, None

    table_columns = entity_class.__table__.columns
    if sort_field not in table_columns:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid sort field '{sort_field}'",
        )

    return getattr(entity_class, sort_field), sort_direction or SortDirection.ASC


def get_entity_class(
    *,
    object_registry: ObjectRegistry,
    entity_name: str,
) -> type:
    entities = object_registry.get_entities()
    try:
        entity_class = one_or_raise([e for e in entities if e.__name__ == entity_name])
    except ValueError:
        logger.warning("entity not found", entity_name=entity_name)
        raise HTTPException(status_code=404, detail=f"Entity {entity_name} not found")

    if not hasattr(entity_class, "__tablename__"):
        logger.warning("entity is not a database table", entity_name=entity_name)
        raise HTTPException(
            status_code=400,
            detail=f"Entity {entity_name} is not stored in database",
        )

    return entity_class


async def _query_entity_instances(
    *,
    entity_class: type,
    entity_name: str,
    skip: int,
    limit: int,
    filters: list[EntityQueryFilter] | None = None,
    sort_field: str | None = None,
    sort_direction: SortDirection | None = None,
) -> EntityInstanceList:
    session = get_session()
    base_query = select(entity_class)
    parsed_filters = _build_filters(
        entity_class=entity_class,
        filters=filters,
    )
    order_by, order_direction = _resolve_sorting(
        entity_class=entity_class,
        sort_field=sort_field,
        sort_direction=sort_direction,
    )

    paginated_query, count_query = build_paginated_query(
        base_query,
        filters=parsed_filters,
        offset=skip,
        limit=limit,
        order_by=order_by,
        order_direction=order_direction,
    )

    total_count = await session.scalar(count_query) or 0
    results = (await session.exec(paginated_query)).all()
    instances = [
        EntityInstance(
            id=str(result.id), entity_name=entity_name, data=result.model_dump()
        )
        for result in results
    ]
    return EntityInstanceList(
        items=instances, total=total_count, offset=skip, limit=limit
    )


def create_entities_router(object_registry: ObjectRegistry) -> APIRouter:
    router = APIRouter(tags=["Entities"])

    @router.get("/", response_model=list[EntityMetadata])
    async def get_entities():
        entities = object_registry.get_entities()
        session = get_session()

        result = []
        for entity in entities:
            count_query = select(func.count()).select_from(entity)
            instance_count = await session.scalar(count_query) or 0

            result.append(
                EntityMetadata(
                    name=entity.__name__,
                    description=entity.__doc__,
                    json_schema=entity.model_json_schema(),
                    instance_count=instance_count,
                )
            )
        return result

    @router.get("/{entity_name}/instances", response_model=EntityInstanceList)
    async def get_entity_instances(
        entity_name: str,
        skip: int = 0,
        limit: int = 100,
    ):
        """
        Get instances of a domain model entity from the database.
        Only works for entities that have a database table.
        """
        entity_class = get_entity_class(
            object_registry=object_registry,
            entity_name=entity_name,
        )
        return await _query_entity_instances(
            entity_class=entity_class,
            entity_name=entity_name,
            skip=skip,
            limit=limit,
        )

    @router.post("/{entity_name}/instances/query", response_model=EntityInstanceList)
    async def query_entity_instances(
        entity_name: str,
        query: EntityInstancesQuery,
    ):
        """
        Query entity instances using advanced filters and sorting.
        All filters are combined with AND semantics.
        """
        entity_class = get_entity_class(
            object_registry=object_registry,
            entity_name=entity_name,
        )
        return await _query_entity_instances(
            entity_class=entity_class,
            entity_name=entity_name,
            skip=query.skip,
            limit=query.limit,
            filters=query.filters,
            sort_field=query.sort_field,
            sort_direction=query.sort_direction,
        )

    @router.get("/{entity_name}/instances/{instance_id}", response_model=EntityInstance)
    async def get_entity_instance_by_id(entity_name: str, instance_id: UUID):
        """
        Get a specific entity instance by its ID.
        Only works for entities that have a database table.
        """
        entity_class = get_entity_class(
            object_registry=object_registry,
            entity_name=entity_name,
        )

        session = get_session()
        result = await session.get(entity_class, instance_id)

        if not result:
            logger.warning(
                "instance with id not found for entity",
                instance_id=instance_id,
                entity_name=entity_name,
            )
            raise HTTPException(
                status_code=404,
                detail=f"Instance with ID {instance_id} not found for entity {entity_name}",
            )

        instance_data = result.model_dump()
        return EntityInstance(
            id=str(result.id), entity_name=entity_name, data=instance_data
        )

    return router
