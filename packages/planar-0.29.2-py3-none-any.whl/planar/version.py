"""Utilities for working with Planar package version information."""

import os
import subprocess
from functools import lru_cache
from importlib import metadata
from typing import Final

from planar.logging import get_logger

logger = get_logger(__name__)

PACKAGE_NAME: Final[str] = "planar"
FALLBACK_VERSION: Final[str] = "0.0.0.dev0"
DEFAULT_COMMIT_SHA_ENV_VAR: Final[str] = "COMMIT_SHA"


@lru_cache(maxsize=1)
def get_version(
    fallback: str = FALLBACK_VERSION,
) -> str:
    """Return the installed Planar version or a fallback value.

    Args:
        fallback: Value returned if the package metadata is unavailable.

    Returns:
        The package version string if available, otherwise the fallback value.
    """

    try:
        return metadata.version(PACKAGE_NAME)
    except metadata.PackageNotFoundError:
        return fallback


def get_package_version(package_name: str) -> str | None:
    """Return the installed version of a Python package.

    Args:
        package_name: The distribution name of the package (as declared in ``pyproject.toml``).

    Returns:
        The version string if the package is installed, otherwise ``None``.
    """
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        return None


@lru_cache(maxsize=1)
def get_git_commit_hash(env_var: str = DEFAULT_COMMIT_SHA_ENV_VAR) -> str | None:
    """Return the current git commit short hash.

    Checks the given environment variable first, then falls back to running
    ``git rev-parse --short HEAD``.

    Args:
        env_var: Environment variable name to check for a pre-set commit SHA.

    Returns:
        The short commit hash string, or ``None`` if it cannot be determined.
    """
    sha = os.environ.get(env_var)
    if sha:
        return sha

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        logger.debug("unable to determine git commit hash")

    return None
