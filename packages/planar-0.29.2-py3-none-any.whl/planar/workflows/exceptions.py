import builtins
import re
import traceback
from collections.abc import Mapping
from typing import Any, ClassVar, Literal

from pydantic import BaseModel, Field, ValidationError

_WORKFLOW_FOREIGN_EXCEPTION_CODE = "workflow.foreign_exception@1"
_WORKFLOW_CANCELLED_CODE = "workflow.cancelled@1"


def _to_snake_case(value: str) -> str:
    # Convert "HTTPError" -> "http_error" and "HumanTaskCancelled" -> "human_task_cancelled".
    normalized = re.sub(r"(?<!^)(?=[A-Z])", "_", value).lower()
    return normalized


def _format_exception_traceback(exc: BaseException) -> str | None:
    if exc.__traceback__ is None:
        return None
    return "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))


def _legacy_type_to_code(exc_type: str) -> str:
    for cls in WorkflowException._registry.values():
        if cls.__name__ == exc_type:
            return cls.code
    return _WORKFLOW_FOREIGN_EXCEPTION_CODE


def _restore_builtin_exception(type_name: str | None, message: str) -> Exception | None:
    if not type_name:
        return None
    exc_class = getattr(builtins, type_name, None)
    if isinstance(exc_class, type) and issubclass(exc_class, Exception):
        return exc_class(message)
    return None


class WorkflowErrorEnvelopeV1(BaseModel):
    schema_version: Literal[1] = 1
    code: str
    message: str
    data: dict[str, Any] = Field(default_factory=dict)
    traceback: str | None = None
    # Compatibility with existing error payload readers (router models/tests).
    type: str | None = None
    cancelled: bool | None = None


class LegacyErrorV0(BaseModel):
    type: str
    message: str
    traceback: str | None = None
    cancelled: bool | None = None


class StepError(Exception):
    def __init__(self, type: str, message: str):
        self.type = type
        self.original_message = message
        super().__init__(f"{type}: {message}")


class WorkflowError(StepError):
    pass


class WorkflowException[TData: BaseModel](Exception):
    code: ClassVar[str] = "workflow.exception@1"
    data_type: ClassVar[type[BaseModel] | None] = None
    _registry: ClassVar[dict[str, type["WorkflowException[Any]"]]] = {}
    data: TData | None

    def __init__(self, message: str, *, data: TData | None = None):
        super().__init__(message)
        self.data = data

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if cls is WorkflowException:
            return

        if "code" not in cls.__dict__:
            cls.code = f"{_to_snake_case(cls.__name__)}@1"

        existing = WorkflowException._registry.get(cls.code)
        if existing is not None and existing is not cls:
            raise TypeError(f"duplicate WorkflowException code: {cls.code!r}")

        WorkflowException._registry[cls.code] = cls


class LockResourceFailed(Exception):
    pass


class NonDeterministicStepCallError(WorkflowException[BaseModel]):
    """Raised when a step call is not deterministic compared to previous executions."""

    code = "workflow.non_deterministic_step_call@1"


class WorkflowCancelledException(WorkflowException[BaseModel]):
    """Raised when a workflow has been cancelled during execution."""

    code = _WORKFLOW_CANCELLED_CODE


def _parse_and_normalize_exception(
    exception: Mapping[str, Any],
) -> WorkflowErrorEnvelopeV1:
    if "schema_version" in exception:
        try:
            return WorkflowErrorEnvelopeV1.model_validate(exception)
        except ValidationError:
            # Keep the legacy fallback path for malformed/partial envelopes.
            pass

    legacy = LegacyErrorV0.model_validate(exception)
    code = _legacy_type_to_code(legacy.type)
    return WorkflowErrorEnvelopeV1(
        code=code,
        message=legacy.message,
        data={},
        traceback=legacy.traceback,
        type=legacy.type,
        cancelled=bool(legacy.cancelled) or code == _WORKFLOW_CANCELLED_CODE,
    )


def serialize_exception(exc: BaseException) -> dict[str, Any]:
    if isinstance(exc, WorkflowException):
        data = exc.data.model_dump(mode="json") if exc.data else {}
        envelope = WorkflowErrorEnvelopeV1(
            code=exc.code,
            message=str(exc),
            data=data,
            traceback=_format_exception_traceback(exc),
            type=type(exc).__name__,
            cancelled=exc.code == _WORKFLOW_CANCELLED_CODE,
        )
        return envelope.model_dump(mode="json")

    envelope = WorkflowErrorEnvelopeV1(
        code=_WORKFLOW_FOREIGN_EXCEPTION_CODE,
        message=str(exc),
        data={},
        traceback=_format_exception_traceback(exc),
        type=type(exc).__name__,
    )
    return envelope.model_dump(mode="json")


def deserialize_exception(exception: Mapping[str, Any]) -> Exception:
    envelope = _parse_and_normalize_exception(exception)

    exc_class = WorkflowException._registry.get(envelope.code)
    if exc_class is not None:
        data = None
        if exc_class.data_type:
            try:
                data = exc_class.data_type.model_validate(envelope.data)
            except ValidationError:
                return WorkflowException(envelope.message)

        try:
            return exc_class(envelope.message, data=data)
        except TypeError:
            return WorkflowException(envelope.message)

    if envelope.code == _WORKFLOW_FOREIGN_EXCEPTION_CODE:
        builtin_exc = _restore_builtin_exception(envelope.type, envelope.message)
        if builtin_exc is not None:
            return builtin_exc

    return WorkflowException(envelope.message)


def try_restore_exception(exception: dict[str, Any]) -> Exception:
    try:
        return deserialize_exception(exception)
    except Exception:
        exc_type = str(exception.get("type", "UnknownException"))
        exc_message = str(exception.get("message", "Unknown workflow exception"))
        return StepError(exc_type, exc_message)
