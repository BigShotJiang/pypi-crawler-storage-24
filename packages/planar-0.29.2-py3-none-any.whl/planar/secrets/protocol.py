from typing import Protocol


class SecretNotFoundError(Exception):
    """Raised when a secret cannot be found in the provider."""

    pass


class SecretAccessError(Exception):
    """Raised when there is an error accessing the secret (e.g. permission denied, network error)."""

    pass


class SecretProvider(Protocol):
    def get_secret(self, secret_id: str) -> str:
        """
        Retrieve a secret by its ID.
        Raises:
            SecretNotFoundError: if the secret is not found.
            SecretAccessError: if there is an error accessing the secret.
        """
        ...
