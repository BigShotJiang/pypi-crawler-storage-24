import json
from typing import Any, Callable, Type, cast

from pydantic import SecretStr

from planar.logging import get_logger
from planar.secrets.protocol import SecretProvider
from planar.secrets.providers import (
    AwsSecretsManagerProvider,
    AzureKeyVaultProvider,
    EnvVarSecretProvider,
)

logger = get_logger(__name__)


class SecretRegistry:
    _provider_types: dict[str, Type[SecretProvider]] = {
        "env": EnvVarSecretProvider,
        "aws_secrets_manager": AwsSecretsManagerProvider,
        "azure_key_vault": AzureKeyVaultProvider,
    }

    def __init__(self):
        self._providers: dict[str, SecretProvider] = {}

    @classmethod
    def register_provider_type(
        cls, name: str, provider_cls: Type[SecretProvider]
    ) -> None:
        """
        Register a custom secret provider class with a label.
        This must be called before configuration is loaded.
        """
        if name in cls._provider_types:
            logger.warning("overriding secret provider type", name=name)
        cls._provider_types[name] = provider_cls

    def register(self, name: str, provider: SecretProvider) -> None:
        self._providers[name] = provider

    def get_provider(self, name: str) -> SecretProvider:
        if name not in self._providers:
            logger.error("secret provider not found", provider_name=name)
            raise ValueError(f"Secret provider '{name}' not found in registry.")
        return self._providers[name]

    def resolve_secret(
        self, provider_name: str, secret_id: str, json_key: str | None = None
    ) -> SecretStr:
        provider = self.get_provider(provider_name)
        # Provider will raise SecretNotFoundError if not found
        secret_value = provider.get_secret(secret_id)

        if json_key:
            try:
                secret_json = json.loads(secret_value)
                if not isinstance(secret_json, dict):
                    logger.error("secret is not a json object", secret_id=secret_id)
                    raise ValueError(
                        f"Secret '{secret_id}' is not a valid JSON object, cannot extract key '{json_key}'"
                    )
                if json_key not in secret_json:
                    logger.error(
                        "json key not found in secret",
                        secret_id=secret_id,
                        json_key=json_key,
                    )
                    raise ValueError(
                        f"Key '{json_key}' not found in secret '{secret_id}'"
                    )
                return SecretStr(str(secret_json[json_key]))
            except json.JSONDecodeError as e:
                logger.error(
                    "secret is not valid json", secret_id=secret_id, error=str(e)
                )
                raise ValueError(
                    f"Secret '{secret_id}' is not valid JSON, cannot extract key '{json_key}'"
                ) from e

        return SecretStr(secret_value)

    @classmethod
    def from_config(cls, providers_config: dict[str, Any]) -> "SecretRegistry":
        registry = cls()
        for name, config_entry in providers_config.items():
            provider_type = config_entry.get("provider")
            provider_config = config_entry.get("options", {})

            if not provider_type:
                logger.error("provider type missing", provider_name=name)
                raise ValueError(f"Provider type missing for secret provider '{name}'")

            provider_instance: SecretProvider

            if provider_type in cls._provider_types:
                provider_class = cls._provider_types[provider_type]
                try:
                    provider_factory = cast(
                        Callable[[dict[str, Any]], SecretProvider], provider_class
                    )
                    provider_instance = provider_factory(provider_config)
                except Exception as e:
                    raise ValueError(
                        f"Failed to initialize secret provider '{name}' ({provider_type}): {e}"
                    ) from e
            else:
                logger.error("unknown provider type", provider_type=provider_type)
                raise ValueError(f"Unknown secret provider type: '{provider_type}'")

            registry.register(name, provider_instance)

        return registry
