# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

class ConfigurationError(Exception):
    pass

class ModelError(Exception):
    pass

class BatchJobError(Exception):
    pass

class IndexError(Exception):
    pass

class GraphQueryError(Exception):
    pass
