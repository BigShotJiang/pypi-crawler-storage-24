import os
import logging
from supabase import create_client, Client
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class ForgeDatabase:
    """
    A reusable Supabase client for the Aegis Forge pipeline.
    
    Expects SUPABASE_URL and SUPABASE_KEY to be set in the environment or a .env file.
    Provides methods to:
      - Fetch pending tasks from a table
      - Update task status
      - Insert completed trajectories
      - Export all successful trajectories (with pagination)
    """

    def __init__(self):
        """Initialize the Supabase client using environment variables."""
        load_dotenv()  # Load variables from .env if present

        url: str = os.getenv("SUPABASE_URL")
        key: str = os.getenv("SUPABASE_KEY")

        if not url or not key:
            raise ValueError("❌ SUPABASE_URL and SUPABASE_KEY must be set in .env")

        try:
            self.client: Client = create_client(url, key)
            logger.info("✅ Successfully connected to Forge Database (Supabase).")
        except Exception as e:
            logger.error(f"❌ Database connection failed: {e}")
            raise

    def fetch_pending_tasks(self, table_name: str, limit: int = 10) -> list:
        """
        Retrieve a batch of unprocessed tasks from a given table.
        
        The table must have a 'status' column with values like 'pending', 'processing', etc.
        
        Args:
            table_name: Name of the table containing tasks.
            limit: Maximum number of tasks to fetch.
        
        Returns:
            List of task records (dictionaries).
        """
        try:
            response = self.client.table(table_name)\
                .select("*")\
                .eq("status", "pending")\
                .limit(limit)\
                .execute()
            return response.data
        except Exception as e:
            logger.error(f"Error fetching pending tasks from {table_name}: {e}")
            return []

    def update_task_status(self, table_name: str, record_id: str,
                           status: str, error_log: str = None):
        """
        Update the status of a specific task (e.g., from 'pending' to 'processing').
        
        Args:
            table_name: Table containing the task.
            record_id: Unique identifier of the task (usually the 'id' column).
            status: New status (e.g., 'processing', 'success', 'failed').
            error_log: Optional error message to store when status is 'failed'.
        """
        try:
            data = {"status": status}
            if error_log:
                data["error_log"] = error_log

            self.client.table(table_name)\
                .update(data)\
                .eq("id", record_id)\
                .execute()
            logger.debug(f"Updated record {record_id} in {table_name} to {status}.")
        except Exception as e:
            logger.error(f"Error updating status for {record_id} in {table_name}: {e}")

    def insert_trajectory(self, table_name: str, payload: dict):
        """
        Insert a completed trajectory (success or failure) into a table.
        
        The payload should contain at least:
          - trajectory: the conversation formatted by the formatter
          - status: 'success' or 'failed'
          - prompt_id: ID linking back to the original task
          - error_log: (optional) error message for failed attempts
        
        Args:
            table_name: Target table (e.g., 'trajectories').
            payload: Dictionary matching the table's columns.
        """
        try:
            self.client.table(table_name).insert(payload).execute()
            logger.debug(f"Successfully inserted trajectory into {table_name}.")
        except Exception as e:
            logger.error(f"Error inserting trajectory into {table_name}: {e}")

    def export_gold_dataset(self, table_name: str, batch_size: int = 1000) -> list:
        """
        Retrieve all successful trajectories from a table, using pagination to handle large datasets.
        
        Args:
            table_name: Table containing trajectories (must have a 'status' column).
            batch_size: Number of records to fetch per request.
        
        Returns:
            List of all records with status == 'success'.
        """
        all_records = []
        start = 0

        try:
            while True:
                end = start + batch_size - 1
                response = self.client.table(table_name)\
                    .select("*")\
                    .eq("status", "success")\
                    .range(start, end)\
                    .execute()

                records = response.data
                if not records:
                    break

                all_records.extend(records)
                logger.info(f"📥 Fetched {len(records)} records from {table_name} "
                            f"(Total so far: {len(all_records)})...")

                if len(records) < batch_size:
                    break

                start += batch_size

            logger.info(f"✅ Successfully exported all {len(all_records)} gold trajectories.")
            return all_records

        except Exception as e:
            logger.error(f"Error exporting dataset from {table_name}: {e}")
            return all_records