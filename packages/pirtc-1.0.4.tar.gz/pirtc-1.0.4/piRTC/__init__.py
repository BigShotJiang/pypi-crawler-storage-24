"""
piRTC - Raspberry Pi RTC & WatchDog Package
Complete solution for DS3231 RTC and WatchDog management
"""

__version__ = "1.0.4"
__author__ = "piRTC Team"

from .rtc import RTCManager
from .watchdog import WatchDogManager
from .shell import RTCShell

__all__ = [
    "RTCManager",
    "WatchDogManager", 
    "RTCShell",
    "__version__"
]
