"""
piRTC - Raspberry Pi RTC & WatchDog Package
Setup configuration
"""

from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))

with open(os.path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="piRTC",
    version="1.0.3",
    description="Raspberry Pi RTC & WatchDog Management Package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="piRTC Team",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "fastapi>=0.68.0",
        "uvicorn>=0.15.0",
        "websockets>=10.0",
        "jinja2>=3.0.0",
        "smbus2>=0.4.0",
        "RPi.GPIO>=0.7.0",
        "pydantic>=1.8.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black>=21.0",
            "flake8>=3.9",
        ],
    },
    entry_points={
        "console_scripts": [
            "pirtc=piRTC.main:main",
            "pirtc-shell=piRTC.shell:main",
            "pirtc-server=piRTC.api:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Operating System :: POSIX :: Linux",
        "Topic :: System :: Hardware",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    include_package_data=True,
    package_data={
        "piRTC": ["web/*", "templates/*"],
    },
)
