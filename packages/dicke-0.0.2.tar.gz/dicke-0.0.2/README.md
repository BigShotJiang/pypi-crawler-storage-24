# Dicke

Variational methods for searching the ground state of a many-body Hamiltonian.
