"""
preprocessor.py — Stage 0: Adaptive, domain-specific image preprocessing.

Returns per-engine optimised image variants.  Each downstream OCR engine
receives the version of the image it performs best on rather than a single
generic preprocessing path.

Key design decisions (from expert review):
- Hough-line median deskew instead of minAreaRect — robust on sparse
  engineering diagrams where minAreaRect returns unreliable angles.
- Super-resolution is optional (EDSR_x2.pb, ~143 MB) and gated by config.
- Color image fed to PaddleOCR; binarized variants to Tesseract / EasyOCR.
"""

from __future__ import annotations

import os

import cv2
import numpy as np

from . import config


# ── Public API ──────────────────────────────────────────────────────────────


def adaptive_preprocess(image_path: str) -> dict[str, np.ndarray]:
    """
    Load *image_path*, apply domain-specific preprocessing, and return a dict
    with one optimised variant per OCR engine:

    ``for_tesseract``  — Otsu-binarized, high-contrast grayscale
    ``for_paddleocr``  — denoised colour (PaddleOCR performs better on colour)
    ``for_easyocr``    — adaptive-threshold grayscale
    ``original``       — untouched BGR image (for visualisation / fallback)
    """
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {image_path}")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Optional 2× super-resolution before everything else
    if config.USE_SUPER_RESOLVE:
        img = _super_resolve(img)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Deskew (Hough-line median — robust on sparse diagrams)
    gray = _deskew_hough(gray)

    # CLAHE contrast enhancement (critical for faded engineering scan prints)
    clahe = cv2.createCLAHE(
        clipLimit=config.CLAHE_CLIP_LIMIT,
        tileGridSize=tuple(config.CLAHE_TILE_GRID),
    )
    enhanced = clahe.apply(gray)

    # ── Engine-specific variants ─────────────────────────────────────────────
    # Tesseract: Otsu binarization on CLAHE-enhanced grayscale
    _, for_tesseract = cv2.threshold(
        enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    # EasyOCR: adaptive threshold (handles uneven lighting)
    for_easyocr = cv2.adaptiveThreshold(
        enhanced,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        config.ADAPTIVE_BLOCK_SIZE,
        config.ADAPTIVE_C,
    )

    # PaddleOCR: denoised colour image (colour preserves layout cues for DBNet)
    # Deskew the colour image to match the gray-based deskew angle
    deskewed_color = _deskew_hough_color(img)
    for_paddleocr = cv2.fastNlMeansDenoisingColored(
        deskewed_color, h=10, hColor=10, templateWindowSize=7, searchWindowSize=21
    )

    return {
        "for_tesseract": for_tesseract,
        "for_paddleocr": for_paddleocr,
        "for_easyocr": for_easyocr,
        "original": img,
    }


# ── Two-stage: per-region crop helper ────────────────────────────────────────


def crop_region(
    original: np.ndarray,
    quad: np.ndarray,
    padding_frac: float = 0.15,
    min_height_px: int = 48,
) -> tuple[np.ndarray, list[float]]:
    """
    Extract, deskew, and preprocess a single text region detected by DBNet.

    This is the core of the Google Vision-style two-stage approach: instead
    of running recognition on the whole image, we crop out each detected
    region individually, correct *its own* rotation angle, upscale if it's
    too small, suppress crossing line-work, and binarize — all independently.

    Why this matters for engineering diagrams: a "DN50" label rotated 90°
    and sitting next to a pipe line is a disaster for whole-image recognition.
    Cropped, deskewed, and line-suppressed, it becomes a clean, upright crop
    that all three engines can read accurately.

    Parameters
    ----------
    original      : full-resolution BGR or grayscale image
    quad          : (4, 2) array of corner points from the DBNet detector
    padding_frac  : border to add around the tight crop (helps Tesseract's
                    language model anchor to surrounding white space)
    min_height_px : minimum height after upscaling; below ~32 px all engines
                    lose accuracy sharply

    Returns
    -------
    crop     : preprocessed grayscale crop, ready for recognition
    bbox_orig: [x1, y1, x2, y2] of the region in the *original* image — used
               to populate the bbox field in the result dict so the voter can
               still do IoU grouping in original image coordinates
    """
    if len(original.shape) == 3:
        gray_full = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
    else:
        gray_full = original.copy()

    quad = quad.astype(np.float32)

    # Record the original-image bbox now, before any cropping transforms
    xs, ys = quad[:, 0], quad[:, 1]
    bbox_orig = [float(xs.min()), float(ys.min()), float(xs.max()), float(ys.max())]

    # ── Compute the upright bounding rectangle for this specific quad ────────
    rect = cv2.minAreaRect(quad)          # (center, (w, h), angle)
    _center, (w, h), angle = rect
    if w < h:                             # ensure width > height (text reads left→right)
        w, h = h, w
        angle += 90.0

    # Add padding so the crop includes a little surrounding context
    pad_w = w * padding_frac
    pad_h = h * padding_frac
    w_out = int(w + 2 * pad_w)
    h_out = int(h + 2 * pad_h)

    # ── Perspective warp: extract and straighten this region ─────────────────
    # Sort corners into TL, TR, BR, BL order, expanded outward by the padding
    src = _sorted_corners(quad, pad_w, pad_h)
    dst = np.array([[0, 0], [w_out, 0], [w_out, h_out], [0, h_out]], dtype=np.float32)
    M = cv2.getPerspectiveTransform(src, dst)
    crop = cv2.warpPerspective(
        gray_full, M, (w_out, h_out),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )

    # ── Upscale if the crop is too small for reliable recognition ─────────────
    if crop.shape[0] < min_height_px:
        scale = min_height_px / crop.shape[0]
        crop = cv2.resize(crop, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)

    # ── Remove crossing structural line-work ──────────────────────────────────
    # Engineering diagrams have single-pixel wall lines, pipe lines, and hatch
    # patterns that physically cross through text characters. We detect and
    # erase these thin lines before running recognition — they look like noise
    # to OCR but are meaningful structural elements we should not corrupt.
    crop = _suppress_thin_lines(crop)

    # ── Strong CLAHE + adaptive threshold tuned for recognition (not detection)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    crop = clahe.apply(crop)
    crop = cv2.adaptiveThreshold(
        crop, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,
        blockSize=15, C=8,
    )

    return crop, bbox_orig


def _sorted_corners(quad: np.ndarray, pad_w: float, pad_h: float) -> np.ndarray:
    """
    Reorder four quad corners into TL, TR, BR, BL, then push each corner
    outward by (pad_w, pad_h) so the perspective warp includes padding.
    """
    s = quad.sum(axis=1)
    d = np.diff(quad, axis=1).ravel()
    tl = quad[np.argmin(s)]
    br = quad[np.argmax(s)]
    tr = quad[np.argmin(d)]
    bl = quad[np.argmax(d)]
    return np.array([
        [tl[0] - pad_w, tl[1] - pad_h],
        [tr[0] + pad_w, tr[1] - pad_h],
        [br[0] + pad_w, br[1] + pad_h],
        [bl[0] - pad_w, bl[1] + pad_h],
    ], dtype=np.float32)


def _suppress_thin_lines(gray: np.ndarray) -> np.ndarray:
    """
    Detect and erase horizontal/vertical lines thinner than ~3 px.

    Engineering structural lines (walls, pipes, leader lines) are almost
    always 1–2 px wide at OCR resolution. Text strokes are 3–8 px wide.
    Morphological opening with a long narrow element finds only the thin
    lines; painting those pixels white removes them without touching text.
    """
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    h, w = binary.shape

    # Horizontal lines: kernel spans 1/10 of image width, 1 px tall
    h_kern = cv2.getStructuringElement(cv2.MORPH_RECT, (max(40, w // 10), 1))
    h_lines = cv2.morphologyEx(binary, cv2.MORPH_OPEN, h_kern)

    # Vertical lines: kernel spans 1/10 of image height, 1 px wide
    v_kern = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(40, h // 10)))
    v_lines = cv2.morphologyEx(binary, cv2.MORPH_OPEN, v_kern)

    # Slightly dilate the combined mask to cover anti-aliased line edges
    mask = cv2.add(h_lines, v_lines)
    mask = cv2.dilate(mask, cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2)))

    result = gray.copy()
    result[mask > 0] = 255   # paint detected lines white (background)
    return result


# ── Internal helpers ─────────────────────────────────────────────────────────


def _deskew_hough(gray: np.ndarray) -> np.ndarray:
    """
    Deskew a grayscale image using the median angle of detected Hough lines.

    This is more robust than ``cv2.minAreaRect`` for sparse engineering
    diagrams where the foreground pixel count is low and minAreaRect's
    bounding box angle becomes unreliable.
    """
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(
        edges,
        rho=1,
        theta=np.pi / 180,
        threshold=config.HOUGH_THRESHOLD,
        minLineLength=config.HOUGH_MIN_LINE_LENGTH,
        maxLineGap=config.HOUGH_MAX_LINE_GAP,
    )

    if lines is None:
        return gray  # no lines detected — return unchanged

    angles: list[float] = []
    for x1, y1, x2, y2 in lines[:, 0]:
        angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
        if abs(angle) < config.HOUGH_MAX_ANGLE:
            angles.append(angle)

    if not angles:
        return gray

    median_angle = float(np.median(angles))
    h, w = gray.shape
    M = cv2.getRotationMatrix2D((w // 2, h // 2), median_angle, 1.0)
    return cv2.warpAffine(gray, M, (w, h), borderMode=cv2.BORDER_REPLICATE)


def _deskew_hough_color(img: np.ndarray) -> np.ndarray:
    """Apply the same Hough deskew to a colour image."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(
        edges,
        rho=1,
        theta=np.pi / 180,
        threshold=config.HOUGH_THRESHOLD,
        minLineLength=config.HOUGH_MIN_LINE_LENGTH,
        maxLineGap=config.HOUGH_MAX_LINE_GAP,
    )

    if lines is None:
        return img

    angles: list[float] = []
    for x1, y1, x2, y2 in lines[:, 0]:
        angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
        if abs(angle) < config.HOUGH_MAX_ANGLE:
            angles.append(angle)

    if not angles:
        return img

    median_angle = float(np.median(angles))
    h, w = img.shape[:2]
    M = cv2.getRotationMatrix2D((w // 2, h // 2), median_angle, 1.0)
    return cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REPLICATE)


def _super_resolve(img: np.ndarray) -> np.ndarray:
    """
    2× upscale via EDSR super-resolution model.

    Critical for small text on engineering diagram scans.
    Requires ``models/EDSR_x2.pb`` — run ``download_models.py`` first.
    Falls back to bicubic resize if the model file is missing.
    """
    if not os.path.exists(config.EDSR_MODEL_PATH):
        print(
            f"[WARN] EDSR model not found at {config.EDSR_MODEL_PATH}. "
            "Run download_models.py. Falling back to bicubic 2× resize."
        )
        h, w = img.shape[:2]
        return cv2.resize(img, (w * 2, h * 2), interpolation=cv2.INTER_CUBIC)

    sr = cv2.dnn_superres.DnnSuperResImpl_create()
    sr.readModel(config.EDSR_MODEL_PATH)
    sr.setModel("edsr", 2)
    return sr.upsample(img)
