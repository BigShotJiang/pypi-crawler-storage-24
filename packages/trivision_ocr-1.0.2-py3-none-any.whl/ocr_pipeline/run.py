"""
run.py — CLI entry point for the OCR pipeline.

Usage
-----
After installing (`pip install -e .`) the `ocr-pipeline` command is available:

    ocr-pipeline path/to/image.jpg
    ocr-pipeline path/to/image.jpg --output result.json
    ocr-pipeline path/to/image.jpg --no-super-resolve --pretty
    ocr-pipeline path/to/image.jpg --text-only

Or run directly without installing:

    python -m ocr_pipeline.run path/to/image.jpg
"""

from __future__ import annotations

import argparse
import json
import os
import sys


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ocr-pipeline",
        description="Multi-engine OCR pipeline (Vision API-compatible output)",
    )
    parser.add_argument("image", help="Path to the input image file")
    parser.add_argument(
        "-o", "--output",
        default=None,
        metavar="FILE",
        help="Write JSON output to FILE instead of stdout",
    )
    parser.add_argument(
        "--no-super-resolve",
        action="store_true",
        help="Disable EDSR super-resolution (faster, no model download required)",
    )
    parser.add_argument(
        "--pretty",
        action="store_true",
        help="Pretty-print JSON output (indent=2)",
    )
    parser.add_argument(
        "--text-only",
        action="store_true",
        help="Print only the extracted text string, not the full JSON",
    )
    return parser


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    # Resolve image path
    image_path = os.path.abspath(args.image)
    if not os.path.isfile(image_path):
        print(f"[ERROR] Image not found: {image_path}", file=sys.stderr)
        sys.exit(1)

    # Apply CLI flags to config BEFORE importing pipeline
    # (config reads env vars at import time, override here for CLI flags)
    if args.no_super_resolve:
        os.environ["USE_SUPER_RESOLVE"] = "false"

    # Late import — config env vars must be set before this
    from .pipeline import beat_vision_api  # noqa: PLC0415

    print(f"[INFO] Processing: {image_path}", file=sys.stderr)
    result = beat_vision_api(image_path)

    if args.text_only:
        text = result["responses"][0]["fullTextAnnotation"]["text"]
        output_str = text
    else:
        indent = 2 if args.pretty else None
        output_str = json.dumps(result, indent=indent, ensure_ascii=False)

    if args.output:
        out_path = os.path.abspath(args.output)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(output_str)
        print(f"[INFO] Output written to: {out_path}", file=sys.stderr)
    else:
        print(output_str)


if __name__ == "__main__":
    main()
