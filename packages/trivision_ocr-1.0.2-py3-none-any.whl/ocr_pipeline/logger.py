"""
logger.py — Centralised logging setup.

Every module gets a consistent, timestamped logger via:
    from ocr_pipeline.logger import get_logger
    log = get_logger(__name__)
"""

from __future__ import annotations

import logging
import sys


def get_logger(name: str) -> logging.Logger:
    """
    Return a logger with a stream handler attached (idempotent — safe to call
    multiple times; handlers are only added once).
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            logging.Formatter(
                "[%(asctime)s] %(levelname)-8s %(name)s — %(message)s",
                datefmt="%H:%M:%S",
            )
        )
        logger.addHandler(handler)
        try:
            from . import config
            level = getattr(logging, config.LOG_LEVEL, logging.INFO)
        except Exception:
            level = logging.INFO
        logger.setLevel(level)
    return logger
