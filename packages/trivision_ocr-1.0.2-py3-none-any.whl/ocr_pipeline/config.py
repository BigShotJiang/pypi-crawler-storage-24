"""
config.py — Central configuration for the OCR pipeline.

Loads .env file automatically (via python-dotenv) so that TESSERACT_CMD and
other settings work reliably on a fresh machine without needing system env vars.
Import this module first in any other module — it also sets the Tesseract
binary path so pytesseract works on Windows without extra setup.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytesseract
from dotenv import load_dotenv

# Load .env from the project root (two levels up from this file)
_PROJECT_ROOT = Path(__file__).parent.parent
load_dotenv(_PROJECT_ROOT / ".env", override=False)

# ─── Tesseract binary (Windows) ──────────────────────────────────────────────
# Set TESSERACT_CMD in .env or as a system env var to override.
TESSERACT_CMD: str = os.environ.get(
    "TESSERACT_CMD",
    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
)
pytesseract.pytesseract.tesseract_cmd = TESSERACT_CMD  # applied at import time

# ─── Runtime flags ───────────────────────────────────────────────────────────
USE_GPU: bool = os.environ.get("USE_GPU", "false").lower() == "true"
USE_SUPER_RESOLVE: bool = os.environ.get("USE_SUPER_RESOLVE", "false").lower() == "true"

# ─── Paths (pathlib — no hardcoded strings) ──────────────────────────────────
MODELS_DIR: Path = Path(os.environ.get("MODELS_DIR", str(_PROJECT_ROOT / "models")))
EDSR_MODEL_PATH: str = str(MODELS_DIR / "EDSR_x2.pb")
SYMSPELL_DICT_PATH: str = str(MODELS_DIR / "frequency_dictionary_en_82_765.txt")

# ─── Engine weights ──────────────────────────────────────────────────────────
ENGINE_WEIGHTS: dict[str, float] = {
    "paddleocr": 0.45,
    "easyocr":   0.35,
    "tesseract": 0.20,
}

# ─── Voter parameters ────────────────────────────────────────────────────────
MIN_CONFIDENCE: float = 0.05
IOU_THRESHOLD: float = 0.20
TEXT_SIMILARITY_THRESHOLD: float = 0.80
AGREEMENT_BONUS: float = 0.15
MIN_TESSERACT_CONF: int = 0

# ─── Preprocessing parameters ────────────────────────────────────────────────
CLAHE_CLIP_LIMIT: float = 3.0
CLAHE_TILE_GRID: tuple[int, int] = (8, 8)
ADAPTIVE_BLOCK_SIZE: int = 31
ADAPTIVE_C: int = 10

HOUGH_THRESHOLD: int = 80
HOUGH_MIN_LINE_LENGTH: int = 50
HOUGH_MAX_LINE_GAP: int = 10
HOUGH_MAX_ANGLE: float = 45.0

# ─── Domain vocabulary ───────────────────────────────────────────────────────
DOMAIN_TERMS: set[str] = {
    "PRV", "FCV", "GV", "BFP", "MH", "DMH", "SV", "WM",
    "HDPE", "DI", "MDIA", "NRV", "ARV", "PSV", "RFV",
    "DN", "PN", "ID", "OD", "PVC", "GRP", "PE",
    "GATE", "VALVE", "SLUICE", "BUTTERFLY", "CHECK", "BALL", "GLOBE",
    "MANHOLE", "CHAMBER", "JUNCTION", "TEE", "BEND", "REDUCER",
}

# ─── SymSpell parameters ─────────────────────────────────────────────────────
SYMSPELL_MAX_EDIT_DISTANCE: int = 2
SYMSPELL_MIN_FREQUENCY: int = 50000

# ─── OCR confusion aliases ───────────────────────────────────────────────────
DOMAIN_MISREADS: dict[str, str] = {
    "HOPE":  "HDPE",
    "HDFE":  "HDPE",
    "PNI6":  "PN16",
    "PNI":   "PN1",
    "BFP-S": "BFP-3",
    "MHS":   "MH-5",
    "MH5":   "MH-5",
    "DN3OO": "DN300",
}

# ─── API auth ────────────────────────────────────────────────────────────────
API_KEYS: set[str] = set(
    k.strip()
    for k in os.environ.get("API_KEYS", "").split(",")
    if k.strip()
)

# ─── Benchmark / logging ─────────────────────────────────────────────────────
LOG_LEVEL: str = os.environ.get("LOG_LEVEL", "INFO").upper()
