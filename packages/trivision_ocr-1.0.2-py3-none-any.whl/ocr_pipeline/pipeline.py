"""
pipeline.py — Full orchestration: Stage 0 → 1 → 2 → 3 → JSON.

Exposes ``beat_vision_api(image_path)`` which returns a dict matching the
Google Cloud Vision API ``images.annotate`` response schema, plus bonus
``engine_count`` and ``confidence`` fields that Vision API never exposes.
"""

from __future__ import annotations

from .corrector import post_correct
from .engines import run_two_stage
from .preprocessor import adaptive_preprocess
from .voter import vote


def beat_vision_api(image_path: str) -> dict:
    """
    Run the full 4-stage OCR pipeline on *image_path*.

    Parameters
    ----------
    image_path:
        Absolute or relative path to the input image (JPEG, PNG, TIFF, BMP …).

    Returns
    -------
    A dict compatible with the Google Vision API ``annotateImage`` response:

    .. code-block:: json

        {
          "responses": [{
            "textAnnotations": [
              {"description": "<full text>", "boundingPoly": null},
              {"description": "TOKEN", "confidence": 0.87,
               "engine_count": 3,
               "boundingPoly": {"vertices": [...]}}
            ],
            "fullTextAnnotation": {"text": "<full text>"}
          }]
        }
    """
    # ── Stage 0: Domain-specific preprocessing ────────────────────────────────
    variants = adaptive_preprocess(image_path)

    # ── Stage 1: Two-stage OCR (detect regions → recognise each crop) ─────────
    # run_two_stage() first asks PaddleOCR's DBNet detector where text regions
    # are, then crops + deskews + line-suppresses each region and runs all three
    # engines on the isolated crop. This is the Google Vision API approach.
    # If detection yields nothing it falls back to whole-image mode automatically.
    all_raw = run_two_stage(variants["original"], variants)

    # ── Stage 2: Confidence-weighted spatial voting ───────────────────────────
    voted = vote(all_raw)

    # ── Stage 3: Domain-aware post-correction ─────────────────────────────────
    corrected = post_correct(voted)

    # ── Assemble Vision API-compatible response ────────────────────────────────
    full_text = " ".join(r["text"] for r in corrected)

    text_annotations = [
        # First annotation = full concatenated text (Vision API convention)
        {"description": full_text, "boundingPoly": None},
    ] + [
        {
            "description": r["text"],
            "confidence": r["confidence"],
            "engine_count": r["engine_count"],   # bonus: Vision API never exposes this
            "boundingPoly": {
                "vertices": [
                    {"x": int(r["bbox"][0]), "y": int(r["bbox"][1])},
                    {"x": int(r["bbox"][2]), "y": int(r["bbox"][1])},
                    {"x": int(r["bbox"][2]), "y": int(r["bbox"][3])},
                    {"x": int(r["bbox"][0]), "y": int(r["bbox"][3])},
                ]
            },
        }
        for r in corrected
    ]

    return {
        "responses": [
            {
                "textAnnotations": text_annotations,
                "fullTextAnnotation": {"text": full_text},
            }
        ]
    }
