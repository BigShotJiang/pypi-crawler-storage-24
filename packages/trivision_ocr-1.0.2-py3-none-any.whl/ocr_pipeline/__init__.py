"""
ocr_pipeline — Multi-engine OCR pipeline.

Top-level public API:
    from ocr_pipeline import beat_vision_api
    result = beat_vision_api("path/to/image.jpg")

The pipeline import is lazy so that lightweight submodules (voter, config)
can be imported in test environments without requiring all heavy ML deps.
"""

__version__ = "1.0.0"
__all__ = ["beat_vision_api"]


def __getattr__(name: str):
    if name == "beat_vision_api":
        from .pipeline import beat_vision_api  # noqa: PLC0415
        return beat_vision_api
    raise AttributeError(f"module 'ocr_pipeline' has no attribute {name!r}")
