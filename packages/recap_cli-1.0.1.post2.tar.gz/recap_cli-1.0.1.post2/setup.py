"""
setup.py
========
Compiles recap_core/_core.py → recap_core/recap_core.pyx → recap_core.so/.pyd

Run locally:
    pip install cython setuptools
    python setup.py build_ext --inplace

GitHub Actions runs this automatically for each platform wheel.
_core.py is DELETED after build — never ships in the wheel.
"""

import os
import sys
import glob
import shutil
import atexit
from setuptools import setup, Extension, find_packages
from Cython.Build import cythonize

# ── Paths ─────────────────────────────────────────────────
ROOT = os.path.dirname(os.path.abspath(__file__))

# Use RELATIVE paths — setuptools requires this
SRC_PY  = os.path.join("recap_core", "_core.py")
SRC_PYX = os.path.join("recap_core", "recap_core.pyx")
SRC_C   = os.path.join("recap_core", "recap_core.c")

# Absolute paths only used for existence checks / file ops
ABS_PY  = os.path.join(ROOT, SRC_PY)
ABS_PYX = os.path.join(ROOT, SRC_PYX)
ABS_C   = os.path.join(ROOT, SRC_C)

if not os.path.exists(ABS_PY):
    print("ERROR: recap_core/_core.py not found")
    sys.exit(1)

# ── Copy _core.py → recap_core.pyx ────────────────────────
with open(ABS_PY, "r", encoding="utf-8") as f:
    content = f.read()
with open(ABS_PYX, "w", encoding="utf-8") as f:
    f.write(content)

# ── Extension (relative paths only!) ──────────────────────
extensions = [
    Extension(
        name="recap_core.recap_core",
        sources=[SRC_PYX],   # relative path — no absolute paths allowed
    )
]

# ── Cleanup after build ────────────────────────────────────
def _cleanup():
    """Delete .pyx and .c files — keep _core.py for subsequent builds."""
    for path in [ABS_PYX, ABS_C]:
        if os.path.exists(path):
            os.remove(path)
            print(f"  🧹 Deleted: {os.path.basename(path)}")
    # Do NOT delete ABS_PY (source) to allow multiple builds

atexit.register(_cleanup)

# ── Setup ──────────────────────────────────────────────────
setup(
    name="recap-cli",
    ext_modules=cythonize(
        extensions,
        compiler_directives={
            "language_level": "3",
            "boundscheck":    False,
            "wraparound":     False,
            "cdivision":      True,
        },
        annotate=False,
    ),
    packages=find_packages(exclude=["build", "dist", "*.egg-info"]),
    package_data={
        "recap_core": ["*.so", "*.pyd"],
        "recap_cli":  ["*.py"],
    },
    exclude_package_data={
        "recap_core": ["_core.py", "*.pyx", "*.c"],
    },
)
