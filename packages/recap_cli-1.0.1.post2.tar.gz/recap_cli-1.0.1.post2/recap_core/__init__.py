"""
recap_core — compiled video processing engine
Imported from the Cython-compiled binary (recap_core.cpython-3XX.so)
_core.py is NEVER distributed — only the compiled .so/.pyd
"""

try:
    # Import from compiled Cython extension
    from recap_core.recap_core import run_recap  # type: ignore
except ImportError:
    # Fallback to Python source (for development/testing)
    from recap_core._core import run_recap

__all__ = ["run_recap"]
