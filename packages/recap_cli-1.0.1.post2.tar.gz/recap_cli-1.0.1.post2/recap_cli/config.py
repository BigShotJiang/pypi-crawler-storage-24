"""CLI Configuration — PHP Backend"""
import os
from pathlib import Path

# Set this to your PythonAnywhere URL after deploying the PHP backend
API_BASE_URL = os.getenv("RECAP_API_URL", "https://www.recap-saas.x10.mx/")

CONFIG_DIR = Path.home() / ".recap_cli"
TOKEN_FILE = CONFIG_DIR / "auth.json"
CONFIG_DIR.mkdir(exist_ok=True)

APP_NAME               = "RecapSaaS"
APP_VERSION            = "1.0.1"
CREDITS_PER_GENERATION = 3
