"""
UI utilities for RecapSaaS CLI
Common UI components and helper functions
"""

import sys
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

from recap_cli.config import APP_NAME, APP_VERSION, CREDITS_PER_GENERATION
from recap_cli.auth import is_logged_in

console = Console()


def banner():
    """Display the application banner."""
    console.print(Panel(
        f"[bold red]🎬 {APP_NAME}[/bold red]  [dim]v{APP_VERSION}[/dim]\n"
        "[dim]Credit-Based AI Video Recap Generator[/dim]",
        border_style="red",
    ))


def require_login():
    """Check if user is logged in, exit if not."""
    if not is_logged_in():
        console.print("[red]❌ Not logged in. Run: [bold]recap login[/bold][/red]")
        sys.exit(1)


def show_credits_bar(credits: int):
    """Display credits information with color coding."""
    gens = credits // CREDITS_PER_GENERATION
    color = "green" if credits >= 9 else "yellow" if credits >= 3 else "red"
    console.print(
        f"  💳 Credits: [{color}]{credits}[/{color}]  "
        f"[dim]({gens} generation{'s' if gens != 1 else ''} available)[/dim]"
    )


def success(message: str):
    """Display a success message."""
    console.print(f"[green]✅ {message}[/green]")


def error(message: str):
    """Display an error message."""
    console.print(f"[red]❌ {message}[/red]")


def warning(message: str):
    """Display a warning message."""
    console.print(f"[yellow]⚠️  {message}[/yellow]")


def info(message: str):
    """Display an info message."""
    console.print(f"[blue]ℹ️  {message}[/blue]")