"""
Enhanced API Client for RecapSaaS CLI
Improved error handling, retry logic, and response validation
"""

import sys
import time
import requests
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

from recap_cli.config import API_BASE_URL
from recap_cli.auth import (get_access_token, get_refresh_token,
                             save_tokens, clear_tokens, load_tokens)


@dataclass
class APIResponse:
    """Structured API response with validation"""
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    error_code: Optional[str] = None
    status_code: int = 0


class APIError(Exception):
    """Enhanced API error with more context"""
    def __init__(self, message: str, status_code: int = 0, error_code: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


class APIClient:
    """Enhanced API client with retry logic and better error handling"""
    
    def __init__(self, base_url: str = None, timeout: int = 120, max_retries: int = 3):
        self.base_url = base_url or API_BASE_URL
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = requests.Session()
        
        # Set default headers
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': f'recap-cli/1.0.0'
        })
    
    def _get_auth_headers(self, token: str = None) -> Dict[str, str]:
        """Get headers with authentication token"""
        headers = self.session.headers.copy()
        if token:
            headers['Authorization'] = f'Bearer {token}'
        return headers
    
    def _parse_response(self, response: requests.Response) -> APIResponse:
        """Parse and validate API response"""
        try:
            data = response.json()
        except requests.exceptions.JSONDecodeError:
            data = {"detail": response.text}
        
        if response.status_code >= 400:
            error_msg = data.get("error", data.get("detail", "Unknown error"))
            error_code = data.get("error_code", None)
            return APIResponse(
                success=False,
                error=error_msg,
                status_code=response.status_code,
                error_code=error_code
            )
        
        return APIResponse(
            success=True,
            data=data,
            status_code=response.status_code
        )
    
    def _refresh_token(self) -> Optional[str]:
        """Attempt to refresh the access token"""
        refresh_token = get_refresh_token()
        if not refresh_token:
            return None
        
        try:
            response = self.session.post(
                f"{self.base_url}/auth/refresh",
                json={"refresh_token": refresh_token},
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                info = load_tokens() or {}
                save_tokens(
                    data["access_token"],
                    data["refresh_token"],
                    data["user_id"],
                    data["username"],
                    data["credits"]
                )
                return data["access_token"]
        except Exception:
            pass
        
        return None
    
    def _make_request(self, method: str, endpoint: str, 
                      authenticated: bool = False, **kwargs) -> APIResponse:
        """Make HTTP request with retry logic and authentication"""
        url = f"{self.base_url}{endpoint}"
        token = get_access_token() if authenticated else None
        
        for attempt in range(self.max_retries + 1):
            try:
                response = self.session.request(
                    method,
                    url,
                    headers=self._get_auth_headers(token),
                    timeout=self.timeout,
                    **kwargs
                )
                
                # Handle token refresh
                if authenticated and response.status_code == 401 and attempt == 0:
                    new_token = self._refresh_token()
                    if new_token:
                        token = new_token
                        continue
                    else:
                        clear_tokens()
                        return APIResponse(
                            success=False,
                            error="Session expired. Run: recap login",
                            status_code=401
                        )
                
                return self._parse_response(response)
                
            except requests.exceptions.Timeout:
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)  # Exponential backoff
                    continue
                return APIResponse(
                    success=False,
                    error="Request timed out",
                    status_code=408
                )
            
            except requests.exceptions.ConnectionError:
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    continue
                return APIResponse(
                    success=False,
                    error="Connection error",
                    status_code=503
                )
            
            except requests.exceptions.RequestException as e:
                return APIResponse(
                    success=False,
                    error=f"Request failed: {str(e)}",
                    status_code=500
                )
        
        return APIResponse(
            success=False,
            error="Max retries exceeded",
            status_code=503
        )
    
    def post(self, endpoint: str, data: Dict[str, Any], 
             authenticated: bool = False) -> APIResponse:
        """Make POST request"""
        return self._make_request("POST", endpoint, 
                                 authenticated=authenticated, json=data)
    
    def get(self, endpoint: str, authenticated: bool = False) -> APIResponse:
        """Make GET request"""
        return self._make_request("GET", endpoint, authenticated=authenticated)
    
    def put(self, endpoint: str, data: Dict[str, Any], 
            authenticated: bool = False) -> APIResponse:
        """Make PUT request"""
        return self._make_request("PUT", endpoint, 
                                 authenticated=authenticated, json=data)
    
    def delete(self, endpoint: str, authenticated: bool = False) -> APIResponse:
        """Make DELETE request"""
        return self._make_request("DELETE", endpoint, authenticated=authenticated)


# Global API client instance
api_client = APIClient()


# Authentication endpoints
def api_signup(email: str, username: str, password: str) -> Dict[str, Any]:
    """Register a new user"""
    response = api_client.post("/auth/signup", {
        "email": email,
        "username": username,
        "password": password
    })
    
    if not response.success:
        raise APIError(response.error, response.status_code)
    
    return response.data


def api_login(email: str, password: str) -> Dict[str, Any]:
    """Authenticate user"""
    response = api_client.post("/auth/login", {
        "email": email,
        "password": password
    })
    
    if not response.success:
        raise APIError(response.error, response.status_code)
    
    return response.data


def api_logout() -> Dict[str, Any]:
    """Logout user"""
    refresh_token = get_refresh_token()
    if not refresh_token:
        return {}
    
    response = api_client.post("/auth/logout", {
        "refresh_token": refresh_token
    })
    
    if not response.success:
        raise APIError(response.error, response.status_code)
    
    return response.data


def api_me() -> Dict[str, Any]:
    """Get current user info"""
    response = api_client.get("/auth/me", authenticated=True)
    
    if not response.success:
        raise APIError(response.error, response.status_code)
    
    return response.data


# Recap endpoints
def api_generate(youtube_url: str, language: str, speed: str,
                 segments: List[Dict[str, str]]) -> Dict[str, Any]:
    """Generate recap segments (client provides segments)"""
    response = api_client.post("/recap/generate", {
        "youtube_url": youtube_url,
        "language": language,
        "speed": speed,
        "segments": segments
    }, authenticated=True)
    
    if not response.success:
        raise APIError(response.error, response.status_code, response.error_code)
    
    return response.data


def api_credits() -> Dict[str, Any]:
    """Get credit balance and transactions"""
    response = api_client.get("/recap/credits", authenticated=True)
    
    if not response.success:
        raise APIError(response.error, response.status_code)
    
    return response.data


def api_buy_credits() -> Dict[str, Any]:
    """Get credit purchase information"""
    response = api_client.get("/recap/buy", authenticated=True)
    
    if not response.success:
        raise APIError(response.error, response.status_code)
    
    return response.data


def api_history(limit: int = 20) -> List[Dict[str, Any]]:
    """Get generation history"""
    response = api_client.get(f"/recap/history?limit={limit}", authenticated=True)
    
    if not response.success:
        raise APIError(response.error, response.status_code)
    
    return response.data
