"""
Enhanced Authentication Module for RecapSaaS CLI
Improved security, token validation, and session management
"""

import json
import os
import stat
from typing import Optional, Dict, Any
from datetime import datetime, timezone
from pathlib import Path
import secrets
import hashlib

from recap_cli.config import TOKEN_FILE


class TokenManager:
    """Secure token management with validation and encryption"""
    
    def __init__(self, token_file: Path = None):
        self.token_file = token_file or TOKEN_FILE
        self._ensure_secure_directory()
    
    def _ensure_secure_directory(self):
        """Ensure token directory exists with proper permissions"""
        self.token_file.parent.mkdir(exist_ok=True, mode=0o700)
    
    def _hash_token(self, token: str) -> str:
        """Create a secure hash of the token for validation"""
        return hashlib.sha256(token.encode()).hexdigest()
    
    def _encrypt_data(self, data: str) -> str:
        """Simple XOR encryption for local storage (not for sensitive data)"""
        # In production, consider using proper encryption libraries
        key = os.environ.get('RECAP_ENCRYPTION_KEY', 'default-key-change-in-production')
        key_bytes = key.encode('utf-8')
        data_bytes = data.encode('utf-8')
        
        encrypted = bytearray()
        for i, byte in enumerate(data_bytes):
            encrypted.append(byte ^ key_bytes[i % len(key_bytes)])
        
        return encrypted.hex()
    
    def _decrypt_data(self, encrypted_hex: str) -> str:
        """Decrypt data encrypted with _encrypt_data"""
        key = os.environ.get('RECAP_ENCRYPTION_KEY', 'default-key-change-in-production')
        key_bytes = key.encode('utf-8')
        encrypted = bytes.fromhex(encrypted_hex)
        
        decrypted = bytearray()
        for i, byte in enumerate(encrypted):
            decrypted.append(byte ^ key_bytes[i % len(key_bytes)])
        
        return decrypted.decode('utf-8')
    
    def save_tokens(self, access_token: str, refresh_token: str, 
                   user_id: str, username: str, credits: int) -> None:
        """Save tokens with enhanced security"""
        token_data = {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "user_id": user_id,
            "username": username,
            "credits": credits,
            "saved_at": datetime.now(timezone.utc).isoformat(),
            "access_token_hash": self._hash_token(access_token),
            "refresh_token_hash": self._hash_token(refresh_token),
            "device_id": self._get_or_create_device_id()
        }
        
        # Encrypt sensitive parts
        encrypted_data = self._encrypt_data(json.dumps(token_data))
        
        self.token_file.write_text(encrypted_data)
        self.token_file.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    
    def load_tokens(self) -> Optional[Dict[str, Any]]:
        """Load and validate tokens"""
        if not self.token_file.exists():
            return None
        
        try:
            encrypted_data = self.token_file.read_text()
            decrypted_data = self._decrypt_data(encrypted_data)
            tokens = json.loads(decrypted_data)
            
            # Validate token structure
            required_fields = ["access_token", "refresh_token", "user_id", 
                             "username", "credits", "saved_at"]
            if not all(field in tokens for field in required_fields):
                self.clear_tokens()
                return None
            
            # Validate token hashes
            if (self._hash_token(tokens["access_token"]) != tokens.get("access_token_hash") or
                self._hash_token(tokens["refresh_token"]) != tokens.get("refresh_token_hash")):
                self.clear_tokens()
                return None
            
            return tokens
            
        except (json.JSONDecodeError, ValueError, KeyError):
            self.clear_tokens()
            return None
    
    def clear_tokens(self) -> None:
        """Securely clear stored tokens"""
        if self.token_file.exists():
            # Overwrite file with random data before deletion
            try:
                with open(self.token_file, 'wb') as f:
                    f.write(os.urandom(self.token_file.stat().st_size))
            except:
                pass
            self.token_file.unlink()
    
    def _get_or_create_device_id(self) -> str:
        """Get or create a unique device identifier"""
        device_file = self.token_file.parent / ".device_id"
        
        if device_file.exists():
            try:
                return device_file.read_text().strip()
            except:
                pass
        
        device_id = secrets.token_urlsafe(16)
        device_file.write_text(device_id)
        device_file.chmod(stat.S_IRUSR | stat.S_IWUSR)
        return device_id
    
    def is_token_expired(self, token_data: Dict[str, Any], max_age_hours: int = 24) -> bool:
        """Check if token is expired based on age"""
        try:
            saved_at = datetime.fromisoformat(token_data["saved_at"])
            age = datetime.now(timezone.utc) - saved_at
            return age.total_seconds() > (max_age_hours * 3600)
        except (KeyError, ValueError):
            return True


# Global token manager instance
token_manager = TokenManager()


# Convenience functions for backward compatibility
def save_tokens(access_token: str, refresh_token: str, 
               user_id: str, username: str, credits: int) -> None:
    """Save authentication tokens"""
    token_manager.save_tokens(access_token, refresh_token, 
                             user_id, username, credits)


def load_tokens() -> Optional[Dict[str, Any]]:
    """Load authentication tokens"""
    return token_manager.load_tokens()


def clear_tokens() -> None:
    """Clear authentication tokens"""
    token_manager.clear_tokens()


def is_logged_in() -> bool:
    """Check if user is logged in with valid tokens"""
    tokens = load_tokens()
    if not tokens:
        return False
    
    # Check if tokens are expired
    if token_manager.is_token_expired(tokens):
        clear_tokens()
        return False
    
    return True


def get_access_token() -> Optional[str]:
    """Get access token"""
    tokens = load_tokens()
    return tokens.get("access_token") if tokens else None


def get_refresh_token() -> Optional[str]:
    """Get refresh token"""
    tokens = load_tokens()
    return tokens.get("refresh_token") if tokens else None


def get_current_user_info() -> Optional[Dict[str, Any]]:
    """Get current user information"""
    return load_tokens()


def update_credits(new_credits: int) -> None:
    """Update cached credit balance"""
    tokens = load_tokens()
    if tokens:
        tokens["credits"] = new_credits
        save_tokens(
            tokens["access_token"],
            tokens["refresh_token"],
            tokens["user_id"],
            tokens["username"],
            new_credits
        )


def get_device_id() -> str:
    """Get unique device identifier"""
    return token_manager._get_or_create_device_id()


def validate_session() -> bool:
    """Validate current session is still valid"""
    if not is_logged_in():
        return False
    
    # Additional validation can be added here
    # For example, checking with the server if the session is still valid
    
    return True
