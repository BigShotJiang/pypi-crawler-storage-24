"""RecapSaaS CLI — Credit-Based AI Video Recap Generator"""
__version__ = "1.0.0"
