#!/usr/bin/env python3
"""
RecapSaaS  — Movie Recap Generator
Commands: signup login generate credits buy history logout whoami
"""

import click
from recap_cli.config import APP_NAME

# Import command modules
from recap_cli.commands.auth_commands import signup, login, logout, whoami
from recap_cli.commands.recap_commands import generate, credits, buy, history


@click.group()
def cli():
    """🎬 RecapSaaS — AI Video Recap Generator"""
    pass


# Register all commands
cli.add_command(signup)
cli.add_command(login)
cli.add_command(logout)
cli.add_command(whoami)
cli.add_command(generate)
cli.add_command(credits)
cli.add_command(buy)
cli.add_command(history)


if __name__ == "__main__":
    cli()
