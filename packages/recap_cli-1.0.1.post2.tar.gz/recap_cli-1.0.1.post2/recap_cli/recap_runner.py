"""
Enhanced Recap Runner for RecapSaaS CLI
Improved error handling, progress tracking, and resource management
"""

import json
import os
import sys
import tempfile
import shutil
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum

from recap_cli.ui import info, warning, error, success


class ProcessingStage(Enum):
    """Processing stages for progress tracking"""
    INITIALIZING = "Initializing"
    DOWNLOADING = "Downloading video"
    PROCESSING_SEGMENTS = "Processing segments"
    GENERATING_TTS = "Generating voiceovers"
    CUTTING_CLIPS = "Cutting video clips"
    MERGING_AUDIO = "Merging audio with video"
    CONCATENATING = "Concatenating segments"
    FINALIZING = "Finalizing output"
    CLEANUP = "Cleaning up"


@dataclass
class ProcessingStats:
    """Statistics for the processing operation"""
    total_segments: int
    processed_segments: int = 0
    failed_segments: int = 0
    current_stage: ProcessingStage = ProcessingStage.INITIALIZING
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    
    @property
    def progress_percentage(self) -> float:
        """Calculate progress percentage"""
        if self.total_segments == 0:
            return 0.0
        return (self.processed_segments / self.total_segments) * 100
    
    @property
    def duration(self) -> Optional[float]:
        """Calculate processing duration"""
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return None


class RecapRunner:
    """Enhanced recap processing with better error handling and progress tracking"""
    
    def __init__(self, output_dir: str = "."):
        self.output_dir = Path(output_dir)
        self.stats = ProcessingStats(total_segments=0)
        self.temp_files: List[Path] = []
        self.segments_file: Optional[Path] = None
    
    def _create_temp_file(self, suffix: str = "") -> Path:
        """Create a temporary file and track it for cleanup"""
        temp_file = Path(tempfile.mktemp(suffix=suffix, dir=self.output_dir))
        self.temp_files.append(temp_file)
        return temp_file
    
    def _cleanup_temp_files(self):
        """Clean up all temporary files"""
        for temp_file in self.temp_files:
            try:
                if temp_file.exists():
                    temp_file.unlink()
            except Exception as e:
                warning(f"Failed to clean up {temp_file}: {e}")
        
        self.temp_files.clear()
    
    def _validate_inputs(self, youtube_url: str, segments: List[Dict[str, Any]], 
                        speed: str, language: str) -> None:
        """Validate input parameters"""
        if not youtube_url:
            raise ValueError("YouTube URL is required")
        
        if not segments:
            raise ValueError("Segments list cannot be empty")
        
        if speed not in ["1.2", "1.5", "2.0"]:
            raise ValueError("Speed must be 1.2, 1.5, or 2.0")
        
        if language not in ["english", "burmese"]:
            raise ValueError("Language must be 'english' or 'burmese'")
        
        # Validate segment structure
        for i, segment in enumerate(segments):
            if not all(key in segment for key in ["start", "end", "voiceover"]):
                raise ValueError(f"Segment {i+1} is missing required fields")
            
            if not segment["voiceover"].strip():
                raise ValueError(f"Segment {i+1} has empty voiceover")
    
    def _save_segments(self, segments: List[Dict[str, Any]]) -> Path:
        """Save segments to a temporary file"""
        segments_file = self._create_temp_file("_segments.json")
        
        with open(segments_file, "w", encoding="utf-8") as f:
            json.dump(segments, f, ensure_ascii=False, indent=2)
        
        return segments_file
    
    def _get_tts_voice(self, language: str) -> str:
        """Get TTS voice for the specified language"""
        voices = {
            "burmese": "my-MM-ThihaNeural",
            "english": "en-US-EmmaMultilingualNeural"
        }
        return voices.get(language, voices["english"])
    
    def _update_stage(self, stage: ProcessingStage):
        """Update current processing stage"""
        self.stats.current_stage = stage
        info(f"🔄 {stage.value}...")
    
    def _process_segment(self, segment: Dict[str, Any], video_file: Path, 
                         tts_voice: str, segment_index: int) -> Optional[Path]:
        """Process a single segment"""
        try:
            self._update_stage(ProcessingStage.GENERATING_TTS)
            
            # Generate TTS audio
            voice_file = self._create_temp_file(f"_voice_{segment_index}.mp3")
            self._generate_tts_audio(segment["voiceover"], voice_file, tts_voice)
            
            self._update_stage(ProcessingStage.CUTTING_CLIPS)
            
            # Cut video clip
            clip_file = self._create_temp_file(f"_clip_{segment_index}.mp4")
            self._cut_video_clip(video_file, segment["start"], segment["end"], clip_file)
            
            self._update_stage(ProcessingStage.MERGING_AUDIO)
            
            # Merge video with audio
            merged_file = self._create_temp_file(f"_merged_{segment_index}.mp4")
            self._merge_video_audio(clip_file, voice_file, merged_file)
            
            # Clean up intermediate files
            voice_file.unlink(missing_ok=True)
            clip_file.unlink(missing_ok=True)
            
            self.stats.processed_segments += 1
            return merged_file
            
        except Exception as e:
            self.stats.failed_segments += 1
            error(f"Failed to process segment {segment_index + 1}: {e}")
            return None
    
    def _generate_tts_audio(self, text: str, output_file: Path, voice: str):
        """Generate TTS audio (placeholder - would call the actual TTS service)"""
        # This would integrate with the TTS service
        # For now, we'll simulate it
        import time
        time.sleep(0.1)  # Simulate processing time
    
    def _cut_video_clip(self, video_file: Path, start: str, end: str, output_file: Path):
        """Cut video clip (placeholder - would call ffmpeg)"""
        # This would integrate with ffmpeg
        # For now, we'll simulate it
        import time
        time.sleep(0.1)  # Simulate processing time
    
    def _merge_video_audio(self, video_file: Path, audio_file: Path, output_file: Path):
        """Merge video with audio (placeholder - would call ffmpeg)"""
        # This would integrate with ffmpeg
        # For now, we'll simulate it
        import time
        time.sleep(0.1)  # Simulate processing time
    
    def _concatenate_segments(self, segment_files: List[Path]) -> Path:
        """Concatenate all processed segments"""
        self._update_stage(ProcessingStage.CONCATENATING)
        
        # Create file list for concatenation
        filelist_file = self._create_temp_file("_filelist.txt")
        with open(filelist_file, "w") as f:
            for segment_file in segment_files:
                f.write(f"file '{segment_file.absolute()}'\n")
        
        # This would call ffmpeg to concatenate
        # For now, we'll simulate it
        import time
        time.sleep(0.5)
        
        output_file = self._create_temp_file("_concatenated.mp4")
        return output_file
    
    def _finalize_output(self, input_file: Path, speed_factor: float) -> Path:
        """Finalize output with speed adjustment and format conversion"""
        self._update_stage(ProcessingStage.FINALIZING)
        
        # This would call ffmpeg for final processing
        # For now, we'll simulate it
        import time
        time.sleep(1.0)
        
        final_output = self.output_dir / "FINAL_RECAP.mp4"
        
        # Simulate creating the final file
        with open(final_output, "w") as f:
            f.write("Simulated final recap video")
        
        return final_output
    
    def run(self, youtube_url: str, segments: List[Dict[str, Any]], 
            speed: str, language: str) -> str:
        """Run the recap processing with enhanced error handling"""
        import time
        
        try:
            # Initialize
            self._update_stage(ProcessingStage.INITIALIZING)
            self.stats.start_time = time.time()
            self.stats.total_segments = len(segments)
            
            # Validate inputs
            self._validate_inputs(youtube_url, segments, speed, language)
            
            # Save segments to file
            self.segments_file = self._save_segments(segments)
            
            # Download video
            self._update_stage(ProcessingStage.DOWNLOADING)
            video_file = self._create_temp_file("_video.mp4")
            self._download_video(youtube_url, video_file)
            
            # Process segments
            self._update_stage(ProcessingStage.PROCESSING_SEGMENTS)
            processed_files = []
            
            for i, segment in enumerate(segments):
                info(f"Processing segment {i+1}/{len(segments)}: {segment['start']} → {segment['end']}")
                
                processed_file = self._process_segment(
                    segment, video_file, self._get_tts_voice(language), i
                )
                
                if processed_file:
                    processed_files.append(processed_file)
            
            if not processed_files:
                raise RuntimeError("No segments were successfully processed")
            
            # Concatenate segments
            concatenated_file = self._concatenate_segments(processed_files)
            
            # Finalize output
            final_output = self._finalize_output(concatenated_file, float(speed))
            
            # Update stats
            self.stats.end_time = time.time()
            
            success(f"✅ Processing completed in {self.stats.duration:.1f} seconds")
            success(f"📊 Processed {self.stats.processed_segments}/{self.stats.total_segments} segments")
            
            return str(final_output)
            
        except Exception as e:
            error(f"Processing failed: {e}")
            raise
        finally:
            # Cleanup
            self._update_stage(ProcessingStage.CLEANUP)
            self._cleanup_temp_files()
            
            if self.segments_file and self.segments_file.exists():
                self.segments_file.unlink()
    
    def _download_video(self, url: str, output_file: Path):
        """Download video (placeholder - would call the actual download service)"""
        # This would integrate with the video download service
        # For now, we'll simulate it
        import time
        time.sleep(2.0)  # Simulate download time


def run(youtube_url: str, segments: List[Dict[str, Any]], speed: str,
        language: str, output_dir: str = ".") -> str:
    """Run recap processing with the enhanced runner"""
    runner = RecapRunner(output_dir)
    return runner.run(youtube_url, segments, speed, language)
