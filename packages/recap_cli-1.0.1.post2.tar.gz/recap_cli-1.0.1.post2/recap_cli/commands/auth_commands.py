"""
Authentication commands for RecapSaaS CLI
Handles signup, login, logout, and user account management
"""

import sys
import getpass
import click
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm

from recap_cli.config import APP_NAME, APP_VERSION, CREDITS_PER_GENERATION
from recap_cli.auth import (save_tokens, clear_tokens, is_logged_in,
                             get_current_user_info, update_credits)
from recap_cli.api_client import (
    api_signup, api_login, api_logout, api_me, APIError,
)
from recap_cli.ui import banner, show_credits_bar, require_login

console = Console()


@click.command()
def signup():
    """Create a new account (includes 3 free trial credits)."""
    banner()
    console.print("\n[bold]📝 Create Account[/bold]\n")

    email = Prompt.ask("Email")
    username = Prompt.ask("Username (3-30 alphanumeric)")
    password = getpass.getpass("Password (min 8 chars): ")
    confirm = getpass.getpass("Confirm password: ")

    if password != confirm:
        console.print("[red]❌ Passwords do not match[/red]")
        sys.exit(1)

    try:
        r = api_signup(email, username, password)
        console.print(f"\n[green]✅ {r['message']}[/green]")
        console.print(f"[yellow]🎁 You'll get {r.get('trial_credits', 3)} free trial credits after verifying![/yellow]")
    except APIError as e:
        console.print(f"\n[red]❌ {e}[/red]")
        sys.exit(1)


@click.command()
def login():
    """Log in to your account."""
    banner()
    if is_logged_in():
        info = get_current_user_info()
        console.print(f"[yellow]Already logged in as [bold]{info['username']}[/bold][/yellow]")
        if not Confirm.ask("Switch account?"):
            return

    console.print("\n[bold]🔐 Login[/bold]\n")
    email = Prompt.ask("Email")
    password = getpass.getpass("Password: ")

    try:
        r = api_login(email, password)
        save_tokens(r["access_token"], r["refresh_token"],
                    r["user_id"], r["username"], r["credits"])
        console.print(f"\n[green]✅ Welcome back, [bold]{r['username']}[/bold]![/green]")
        show_credits_bar(r["credits"])
        if r["credits"] < CREDITS_PER_GENERATION:
            console.print("[yellow]⚠️  Low credits — run [bold]recap buy[/bold] to top up[/yellow]")
    except APIError as e:
        console.print(f"\n[red]❌ {e}[/red]")
        sys.exit(1)


@click.command()
def logout():
    """Log out."""
    require_login()
    info = get_current_user_info()
    try:
        api_logout()
    except:
        pass
    clear_tokens()
    console.print(f"[green]✅ Logged out ({info['username']})[/green]")


@click.command()
def whoami():
    """Show current account info."""
    require_login()
    try:
        u = api_me()
    except APIError as e:
        console.print(f"[red]❌ {e}[/red]")
        sys.exit(1)

    c = u["credits"]
    color = "green" if c >= 9 else "yellow" if c >= 3 else "red"
    console.print(Panel(
        f"[bold]Username:[/bold]  {u['username']}\n"
        f"[bold]Email:[/bold]     {u['email']}\n"
        f"[bold]Credits:[/bold]   [{color}]{c}[/{color}]  "
        f"[dim]({c // CREDITS_PER_GENERATION} generation(s) available)[/dim]\n"
        f"[bold]User ID:[/bold]   {u['id']}\n"
        f"[bold]Status:[/bold]    {u['status']}\n"
        f"[bold]Joined:[/bold]    {u['created_at'][:10]}",
        title="👤 Account",
        border_style="blue",
    ))