"""
Commands module for RecapSaaS CLI
Contains all command handlers organized by functionality
"""