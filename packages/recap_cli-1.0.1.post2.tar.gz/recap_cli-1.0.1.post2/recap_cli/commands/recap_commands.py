"""
Recap generation commands for RecapSaaS CLI
Handles video generation, credits, and history
"""

import sys
import json
import os
import tempfile
import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt
from rich.progress import Progress, SpinnerColumn, TextColumn

from recap_cli.config import CREDITS_PER_GENERATION
from recap_cli.auth import get_current_user_info, update_credits
from recap_cli.api_client import (
    api_generate, api_credits, api_buy_credits, api_history, APIError,
)
from recap_cli.ui import banner, show_credits_bar, require_login

console = Console()

TTS_VOICES = {
    "burmese": "my-MM-ThihaNeural",
    "english": "en-US-EmmaMultilingualNeural",
}


@click.command()
@click.option("--url", default=None)
@click.option("--speed", default=None)
@click.option("--lang", default=None)
@click.option("--segments-file", default=None, help="Path to JSON file containing segments")
@click.option("--output", default=".", help="Output directory")
def generate(url, speed, lang, segments_file, output):
    """Generate a recap (costs 3 credits). Client must provide segments."""
    banner()
    require_login()

    info = get_current_user_info()
    credits = info.get("credits", 0)

    console.print(f"\n[bold]🎬 Generate Recap[/bold]")
    show_credits_bar(credits)

    if credits < CREDITS_PER_GENERATION:
        console.print(f"\n[red]❌ Not enough credits.[/red]")
        console.print(f"   You have [bold]{credits}[/bold] credit(s) but need [bold]{CREDITS_PER_GENERATION}[/bold].")
        console.print("   Run [bold]recap buy[/bold] to get more credits.")
        sys.exit(1)

    console.print()

    if not url:
        url = Prompt.ask("YouTube URL").strip()
    if not speed:
        speed = Prompt.ask("Speed", choices=["1.2", "1.5", "2.0"], default="1.5")
    if not lang:
        lang = Prompt.ask("Language", choices=["english", "burmese"], default="english")
    if not segments_file:
        segments_file = Prompt.ask("Segments JSON file path").strip()

    if "youtube.com/watch" not in url and "youtu.be/" not in url:
        console.print("[red]❌ Invalid YouTube URL[/red]")
        sys.exit(1)

    # Load segments from file
    try:
        with open(segments_file, 'r', encoding='utf-8') as f:
            segments = json.load(f)
    except FileNotFoundError:
        console.print(f"[red]❌ File not found: {segments_file}[/red]")
        sys.exit(1)
    except json.JSONDecodeError as e:
        console.print(f"[red]❌ Invalid JSON: {e}[/red]")
        sys.exit(1)

    if not isinstance(segments, list) or len(segments) == 0:
        console.print("[red]❌ Segments must be a non-empty list[/red]")
        sys.exit(1)

    # Validate each segment structure
    for i, seg in enumerate(segments):
        if not all(k in seg for k in ("start", "end", "voiceover")):
            console.print(f"[red]❌ Segment {i} missing required fields (start, end, voiceover)[/red]")
            sys.exit(1)
        if not isinstance(seg['start'], str) or not isinstance(seg['end'], str) or not isinstance(seg['voiceover'], str):
            console.print(f"[red]❌ Segment {i} fields must be strings[/red]")
            sys.exit(1)

    # Step 1 — Send segments to server
    console.print(f"\n[bold cyan]Step 1/2[/bold cyan] Sending segments to server...")
    console.print(f"[dim]  This will cost [bold]{CREDITS_PER_GENERATION} credits[/bold] ({credits} → {credits - CREDITS_PER_GENERATION} remaining)[/dim]")

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                  console=console) as progress:
        task = progress.add_task("Uploading segments...", total=None)
        try:
            result = api_generate(url, lang, speed, segments)
        except APIError as e:
            progress.stop()
            if e.status_code == 402:
                console.print(f"\n[red]❌ {e}[/red]")
                console.print("[dim]Run [bold]recap buy[/bold] to top up.[/dim]")
            else:
                console.print(f"\n[red]❌ {e}[/red]")
            sys.exit(1)

    remaining = result.get("credits_remaining", credits - CREDITS_PER_GENERATION)
    update_credits(remaining)

    console.print(f"[green]✅ {len(segments)} segments accepted![/green]")
    console.print(f"[dim]  Credits remaining: [bold]{remaining}[/bold][/dim]")

    if remaining < CREDITS_PER_GENERATION:
        console.print(f"[yellow]⚠️  Low credits! Run [bold]recap buy[/bold] to continue generating.[/yellow]")

    # Step 2 — Local processing using the real compiled engine
    console.print(f"\n[bold cyan]Step 2/2[/bold cyan] Processing video locally...")

    # Write segments to a temp file for run_recap
    tmp_segments = tempfile.NamedTemporaryFile(
        suffix="_segments.json", delete=False, mode="w", encoding="utf-8"
    )
    try:
        json.dump(segments, tmp_segments, ensure_ascii=False)
        tmp_segments.close()

        tts_voice = TTS_VOICES.get(lang, TTS_VOICES["english"])

        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                      console=console) as progress:
            progress.add_task("Downloading, cutting, TTS, encoding...", total=None)
            try:
                from recap_core import run_recap
                out_path = run_recap(
                    youtube_url=url,
                    segments_file=tmp_segments.name,
                    speed_factor=float(speed),
                    tts_voice=tts_voice,
                    output_dir=output,
                )
            except SystemExit:
                raise
            except Exception as e:
                console.print(f"\n[red]❌ Local processing failed: {e}[/red]")
                sys.exit(1)
    finally:
        if os.path.exists(tmp_segments.name):
            os.unlink(tmp_segments.name)

    console.print(f"\n[bold green]🎉 Done![/bold green] Output: [bold]{out_path}[/bold]")


@click.command()
def credits():
    """View your credit balance and transaction history."""
    require_login()
    try:
        data = api_credits()
    except APIError as e:
        console.print(f"[red]❌ {e}[/red]")
        sys.exit(1)

    c = data["credits"]
    color = "green" if c >= 9 else "yellow" if c >= 3 else "red"

    console.print(Panel(
        f"💳 Balance: [{color}][bold]{c} credits[/bold][/{color}]\n"
        f"Each recap costs [bold]{data['cost_per_generation']} credits[/bold]\n"
        f"You can run [bold]{c // data['cost_per_generation']} more generation(s)[/bold]\n\n"
        + ("[green]✅ Ready to generate![/green]" if data["can_generate"]
           else "[red]❌ Need more credits — run [bold]recap buy[/bold][/red]"),
        title="💳 Credits",
        border_style=color,
    ))

    txns = data.get("transactions", [])
    if txns:
        table = Table(title="Recent Transactions", border_style="dim")
        table.add_column("Type")
        table.add_column("Amount")
        table.add_column("Balance")
        table.add_column("Description")
        table.add_column("Date")
        for t in txns[:10]:
            amt = t["amount"]
            color = "green" if amt > 0 else "red"
            table.add_row(
                t["type"],
                f"[{color}]{'+' if amt > 0 else ''}{amt}[/{color}]",
                str(t["balance_after"]),
                (t.get("description") or "")[:40],
                t["date"][:10],
            )
        console.print(table)


@click.command()
def buy():
    """Purchase more credits."""
    require_login()
    try:
        data = api_buy_credits()
    except APIError as e:
        console.print(f"[red]❌ {e}[/red]")
        sys.exit(1)

    console.print(Panel(
        f"[bold yellow]💳 Buy Credits[/bold yellow]\n\n"
        f"Contact us to purchase credits:\n"
        f"  📱 Telegram: [bold cyan]{data['telegram']}[/bold cyan]\n\n"
        f"[bold]Your User ID:[/bold] [yellow]{data['your_user_id']}[/yellow]\n"
        f"[bold]Username:[/bold]     {data['your_username']}\n"
        f"[bold]Current balance:[/bold] {data['current_credits']} credits\n\n"
        f"[dim]Send your User ID when contacting us — we'll top up instantly.[/dim]\n\n"
        f"Each generation costs {data['cost_per_generation']} credits.",
        border_style="yellow",
        title="💳 Buy Credits",
    ))


@click.command()
def history():
    """View generation history."""
    require_login()
    try:
        logs = api_history()
    except APIError as e:
        console.print(f"[red]❌ {e}[/red]")
        sys.exit(1)

    if not logs:
        console.print("[dim]No history yet. Run [bold]recap generate[/bold].[/dim]")
        return

    table = Table(title="📋 Generation History", border_style="dim")
    table.add_column("#")
    table.add_column("URL", max_width=35)
    table.add_column("Lang")
    table.add_column("Speed")
    table.add_column("Credits")
    table.add_column("Status")
    table.add_column("Date")

    for l in logs:
        sc = "green" if l["status"] == "success" else "red"
        table.add_row(
            str(l["id"]),
            l["youtube_url"][:35],
            l["language"],
            l["speed"] + "x",
            str(l["credits_charged"]),
            f"[{sc}]{l['status']}[/{sc}]",
            l["created_at"][:10],
        )
    console.print(table)
