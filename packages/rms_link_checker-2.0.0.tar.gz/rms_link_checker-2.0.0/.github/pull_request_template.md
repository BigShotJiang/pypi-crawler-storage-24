## Purpose

<!-- Why is this change needed? What problem does it solve? -->

Closes #<!-- issue number -->

## Changes

<!-- What changed and how? Note any non-obvious design decisions. Bullet list is fine. -->

-

## Type of Change

- [ ] Bug fix (non-breaking)
- [ ] New feature (non-breaking)
- [ ] Breaking change (fix or feature that alters existing behavior or public API)
- [ ] Refactor (no functional or API changes)
- [ ] Documentation
- [ ] Tests only (no production code change)
- [ ] CI / Build / Dependencies

## Testing

- [ ] Existing tests pass (`pytest`)
- [ ] New or updated tests for changed code
- [ ] Tested manually (describe below if applicable)

<!-- Manual verification steps, if any. -->

## Potential Impacts

<!-- Effects on the public API, backward compatibility, performance, or downstream
     packages. Write "None" if straightforward. -->

## Checklist

- [ ] Code follows project style (`ruff check`, `ruff format`)
- [ ] Type annotations present and `mypy` passes
- [ ] Docstrings and Sphinx docs updated (if applicable)
- [ ] CHANGES.md updated (if user-facing change)
- [ ] No temporary or debug code left in
- [ ] Breaking changes flagged in Type of Change above

## Notes

<!-- Anything reviewers should know: tricky areas, unresolved questions, follow-up
     work. Delete this section if not needed. -->
