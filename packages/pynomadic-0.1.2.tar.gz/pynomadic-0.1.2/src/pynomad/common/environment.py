"""
环境信息管理模块

提供程序运行时环境信息的获取功能，包括项目根目录检测等。
"""

from functools import cache, cached_property
import inspect
from pathlib import Path
import platform
import sys
import os
import hashlib
import uuid
import base64
from collections import Counter
import tempfile
from types import FrameType, ModuleType
import warnings
from pynomad.common.decorator import singleton


class PathDetector:
    """路径检测辅助类

    负责从不同来源检测和提取项目根目录的候选路径。
    """

    # 需要跳过的路径关键词
    SKIP_KEYWORDS = frozenset([".vscode", ".zip", "DLLs", "Lib", ".venv"])

    # 需要跳过的模块名（测试框架等）
    SKIP_MODULES = frozenset(["__main__", "pytest", "unittest"])

    @staticmethod
    def is_python_install_dir(path_str: str) -> bool:
        """判断是否为 Python 安装目录"""
        return (
            "python" in path_str.lower() and (Path(path_str) / "DLLs").exists()
        )

    @staticmethod
    def should_skip_path(path_str: str) -> bool:
        """判断是否应该跳过该路径"""
        # 检查 Python 安装目录
        if PathDetector.is_python_install_dir(path_str):
            return True
        # 检查跳过关键词
        if any(keyword in path_str for keyword in PathDetector.SKIP_KEYWORDS):
            return True
        return False

    @staticmethod
    def extract_from_tests(path_str: str) -> Path | None:
        """从 tests 目录提取项目根目录"""
        if "tests" in path_str:
            return Path(path_str.split("tests", maxsplit=1)[0])
        return None

    @staticmethod
    def extract_from_src(path: Path) -> list[Path]:
        """从 src 目录提取项目根目录"""
        if path.name == "src":
            return [path.parent, path]
        return []

    @staticmethod
    def should_skip_module(file: str, name: str) -> bool:
        """判断是否应该跳过该模块"""
        if name in PathDetector.SKIP_MODULES:
            return True
        if "test" in file:
            return True
        return False


@singleton
class Environment:
    """环境信息管理类

    提供获取项目根目录、项目名称等环境信息的功能。
    通过多种方式（sys.path、命令行参数、调用栈）综合判断项目根目录。

    该类使用 @singleton 装饰器确保全局只有一个实例。

    Attributes:
        project_dir: 项目根目录的缓存属性（Path）
        project_name: 项目名称的属性（str）

    Examples:
        >>> env = Environment()
        >>> project_root = env.get_project_dir()
        >>> # 或者使用便捷函数
        >>> from pynomad.common.environment import get_project_dir, get_project_name
        >>> root = get_project_dir()
        >>> name = get_project_name()
    """

    def __init__(self) -> None:
        """初始化环境实例"""
        self._detector = PathDetector()

    @cached_property
    def project_dir(self) -> Path:
        """获取项目根目录（缓存属性）

        使用 @cached_property 装饰器缓存结果，避免重复计算。
        首次访问时调用 get_project_dir() 方法，后续访问直接返回缓存值。

        Returns:
            Path: 项目根目录的绝对路径

        Examples:
            >>> env = Environment()
            >>> root = env.project_dir
        """
        return self.get_project_dir()

    @property
    def project_name(self) -> str:
        """获取项目名称

        返回项目根目录的名称部分。

        Returns:
            str: 项目名称

        Examples:
            >>> env = Environment()
            >>> name = env.project_name
            >>> # 如果项目根目录是 /path/to/myproject，返回 "myproject"
        """
        return self.project_dir.name

    def get_project_dir(self) -> Path:
        """获取项目根目录

        通过多种方式综合判断项目根目录：
        1. 从 sys.path 中解析
        2. 从命令行参数中解析（如 pytest 的 --rootdir）
        3. 从调用栈中解析

        最终通过投票机制选择出现次数最多的路径作为项目根目录。
        如果所有方法都失败，则返回当前工作目录作为后备方案。

        Returns:
            Path: 项目根目录的绝对路径

        Note:
            该方法结合了多种检测策略，以提高在不同运行环境下
            （开发环境、测试环境、打包环境）的鲁棒性。
        """
        possible_dirs: list[Path] = []

        # 从 sys.path 中解析项目根目录
        sys_paths = self._parse_sys_path()
        possible_dirs.extend(sys_paths)

        # 从命令行中解析项目根路径，像 pytest 一般会传递一个 --rootdir 参数
        arg_paths = self._parse_sys_argv()
        possible_dirs.extend(arg_paths)

        # 从堆栈中解析项目根路径
        stack_paths = self._parse_call_stack()
        possible_dirs.extend(stack_paths)

        return self._select_best_path(possible_dirs)

    def _select_best_path(self, candidates: list[Path]) -> Path:
        """从候选路径中选择最佳路径

        使用投票机制，返回出现次数最多的路径。

        Args:
            candidates: 候选路径列表

        Returns:
            Path: 出现次数最多的路径，如果列表为空则返回当前工作目录

        Examples:
            >>> from pathlib import Path
            >>> paths = [Path("/a"), Path("/b"), Path("/a")]
            >>> env = Environment()
            >>> result = env._select_best_path(paths)
            >>> assert result == Path("/a")

        Note:
            如果 candidates 为空，返回 Path.cwd() 作为后备方案。
            PyInstaller 打包后使用原始路径，避免路径解析错误。
        """
        if not candidates:
            warnings.warn("无法从任何来源确定项目根目录，使用当前工作目录")
            return Path.cwd()

        counter = Counter(candidates)
        best_path = counter.most_common(1)[0][0]

        # PyInstaller 打包后的特殊处理
        # 打包后使用原始路径，不进行 resolve，避免路径解析错误
        if getattr(sys, "frozen", False):
            return best_path

        # 开发环境：确保返回绝对路径，这样 .name 才能正确获取目录名
        return best_path if best_path.is_absolute() else best_path.resolve()

    def _parse_sys_path(self) -> list[Path]:
        """从 sys.path 中解析项目根目录

        分析 sys.path 中的路径，识别并提取项目根目录：
        - sys.path[0] 通常是项目的根路径（开发环境）
        - 过滤 Python 安装目录和虚拟环境目录
        - 识别包含 "tests" 或 "src" 的路径，提取其父目录

        Returns:
            list[Path]: 候选项目根目录列表
        """
        if not sys.path:
            return []

        possible_dirs: list[Path] = []

        # 处理 sys.path[0]（通常是最重要的路径）
        self._process_single_path(sys.path[0], possible_dirs)

        # 处理 sys.path[1:]
        for path_str in sys.path[1:]:
            if self._detector.should_skip_path(path_str):
                continue
            self._process_single_path(path_str, possible_dirs)

        return possible_dirs

    def _process_single_path(
        self, path_str: str, candidates: list[Path]
    ) -> None:
        """处理单个路径，添加到候选列表

        Args:
            path_str: 要处理的路径字符串
            candidates: 候选路径列表
        """
        # 尝试从 tests 目录提取
        test_root = self._detector.extract_from_tests(path_str)
        if test_root:
            candidates.append(test_root)
            return

        # 尝试从 src 目录提取
        path = Path(path_str)
        src_roots = self._detector.extract_from_src(path)
        if src_roots:
            candidates.extend(src_roots)
            return

        # 普通路径直接添加
        candidates.append(path)

    def _parse_sys_argv(self) -> list[Path]:
        """从命令行参数中解析项目根目录

        解析命令行参数，提取 --rootdir 参数指定的路径。
        这主要用于 pytest 等测试框架的场景。

        Returns:
            list[Path]: 候选项目根目录列表

        Examples:
            >>> # pytest --rootdir=/path/to/project
            >>> env = Environment()
            >>> paths = env._parse_sys_argv()
            >>> # 返回 [Path("/path/to/project")]
        """
        possible_dirs: list[Path] = []

        for arg in sys.argv:
            if arg.startswith("--rootdir="):
                root_dir = Path(arg[len("--rootdir=") :])
                possible_dirs.append(root_dir)

        return possible_dirs

    def _parse_call_stack(self) -> list[Path]:
        """从调用栈中解析项目根目录

        通过分析调用栈中的模块信息，反推项目根目录。
        根据模块的文件路径和模块名的关系，提取项目根目录。

        策略：
        1. 过滤掉测试框架和测试相关的帧
        2. 分析模块文件路径和模块名的对应关系
        3. 提取项目根目录（src/tests 的父目录）

        Returns:
            list[Path]: 候选项目根目录列表
        """
        possible_dirs: list[Path] = []
        frames: list[inspect.FrameInfo] | None = None
        current_frame: FrameType | None = None
        try:
            current_frame = inspect.currentframe()
            frames = inspect.getouterframes(current_frame)

            for frame in frames:
                module: ModuleType | None = inspect.getmodule(frame.frame)
                if module is None:
                    continue

                name = module.__name__
                file = module.__file__

                if not (file and name):
                    continue

                if self._detector.should_skip_module(file, name):
                    break

                path = self._extract_project_root_from_module(file, name)
                if path:
                    possible_dirs.append(path)
                    # 打包后的路径通常不包含 src，找到第一个就跳出
                    break
        finally:
            # 显式删除帧引用，避免内存泄漏
            del frames
            del current_frame

        return possible_dirs

    def _extract_project_root_from_module(
        self, file: str, name: str
    ) -> Path | None:
        """从模块文件路径和名称提取项目根目录

        Args:
            file: 模块文件路径
            name: 模块名称

        Returns:
            Path | None: 项目根目录，如果无法确定则返回 None
        """
        path_str = Path(file).absolute().as_posix()
        module_path = "/".join(name.split("."))
        paths = path_str.split(module_path)

        if len(paths) == 1:
            # 无法匹配模块路径，使用文件父目录
            return Path(file).parent

        if len(paths) > 1:
            # 提取项目根目录
            root = Path(paths[0])
            if root.name in ("src", "tests"):
                root = root.parent
            return root

        return None

    def get_project_name(self) -> str:
        """获取项目名称

        返回项目根目录的名称部分。

        Returns:
            str: 项目名称

        Examples:
            >>> env = Environment()
            >>> name = env.get_project_name()
            >>> # 如果项目根目录是 /path/to/myproject，返回 "myproject"
        """
        return get_project_dir().name

    def is_windows(self) -> bool:
        """判断系统是否为windows"""
        return platform.system() == "Windows"

    def is_darwin(self) -> bool:
        """判断操作系统是否是macos"""
        return platform.system() == "Darwin"

    def is_linux(self) -> bool:
        """是否是linux系统"""
        return platform.system() == "Linux"

    def is_windows10(self) -> bool:
        """判断系统是否大于windows10"""
        if not platform.system() == "Windows":
            return False
        try:
            # 检查Windows版本，Windows 10 build 10586以上支持ANSI
            release = platform.release()
            if release.isdigit() and int(release) >= 10:
                return True
            # 也处理类似 "10.0.19041" 这样的版本号
            if "." in release:
                major_version = int(release.split(".")[0])
                return major_version >= 10
        except (ValueError, AttributeError, IndexError):
            return False
        return False

    @cached_property
    def localdata(self) -> Path:
        """获取系统本地数据目录

        根据不同操作系统返回应用数据目录的默认位置：
        - Windows: %LOCALAPPDATA% (C:\\Users\\用户名\\AppData\\Local)
        - macOS: ~/Library/Application Support
        - Linux: ~/.local/share

        Returns:
            Path: 系统应用数据目录的绝对路径

        Examples:
            >>> env = Environment()
            >>> data_dir = env.localappdata
            >>> print(data_dir)
            >>> # Windows 输出: C:\\Users\\username\\AppData\\Local
            >>> # macOS 输出: /Users/username/Library/Application Support
            >>> # Linux 输出: /home/username/.local/share

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
            Windows 环境使用 os.getenv('LOCALAPPDATA') 获取本地应用数据目录。
        """
        if self.is_windows():
            # Windows: %LOCALAPPDATA%
            appdata_path = Path(
                os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local")
            )
            return appdata_path
        if self.is_darwin():
            # macOS: ~/Library/Application Support
            appdata_path = Path.home() / "Library" / "Application Support"
            return appdata_path
        # Linux 和其他 Unix-like: XDG Base Directory 规范
        # 优先使用 XDG_DATA_HOME，默认为 ~/.local/share
        xdg_data = os.getenv("XDG_DATA_HOME")
        if xdg_data:
            appdata_path = Path(xdg_data)
        else:
            appdata_path = Path.home() / ".local" / "share"
        return appdata_path

    @cached_property
    def roamingappdata(self) -> Path:
        """获取系统漫游数据目录（仅 Windows）

        Returns:
            Path: Windows 漫游应用数据目录的绝对路径，非 Windows 系统返回空目录

        Examples:
            >>> env = Environment()
            >>> if env.is_windows():
            ...     roaming = env.roamingappdata
            ...     print(roaming)
            ...     # 输出: C:\\Users\\username\\AppData\\Roaming

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
            仅 Windows 系统有漫游数据目录概念，macOS 和 Linux 返回 Path.cwd()。
        """
        if self.is_windows():
            # Windows: %APPDATA%
            return Path(
                os.getenv("APPDATA", Path.home() / "AppData" / "Roaming")
            )
        # 非 Windows 系统返回当前目录
        return Path.cwd()

    @cached_property
    def config_home(self) -> Path:
        """获取系统配置目录

        根据不同操作系统返回配置目录的默认位置：
        - Windows: %LOCALAPPDATA% (C:\\Users\\用户名\\AppData\\Local)
        - macOS: ~/Library/Application Support
        - Linux: ~/.config

        Returns:
            Path: 系统配置目录的绝对路径

        Examples:
            >>> env = Environment()
            >>> config_dir = env.config_home
            >>> print(config_dir)
            >>> # Windows 输出: C:\\Users\\username\\AppData\\Local
            >>> # macOS 输出: /Users/username/Library/Application Support
            >>> # Linux 输出: /home/username/.config

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
            Linux 遵循 XDG Base Directory 规范，使用 XDG_CONFIG_HOME 环境变量。
        """
        if self.is_windows():
            # Windows: 配置通常放在 LOCALAPPDATA
            return Path(
                os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local")
            )

        if self.is_darwin():
            # macOS: 配置也放在 Application Support
            return Path.home() / "Library" / "Application Support"

        # Linux: XDG Base Directory 规范
        # 优先使用 XDG_CONFIG_HOME，默认为 ~/.config
        xdg_config = os.getenv("XDG_CONFIG_HOME")
        if xdg_config:
            return Path(xdg_config)
        return Path.home() / ".config"

    @cached_property
    def cache_home(self) -> Path:
        """获取系统缓存目录

        根据不同操作系统返回缓存目录的默认位置：
        - Windows: %LOCALAPPDATA%\\Cache 或 %TEMP%
        - macOS: ~/Library/Caches
        - Linux: ~/.cache

        Returns:
            Path: 系统缓存目录的绝对路径

        Examples:
            >>> env = Environment()
            >>> cache_dir = env.cache_home
            >>> print(cache_dir)
            >>> # Windows 输出: C:\\Users\\username\\AppData\\Local\\Cache
            >>> # macOS 输出: /Users/username/Library/Caches
            >>> # Linux 输出: /home/username/.cache

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
            Linux 遵循 XDG Base Directory 规范，使用 XDG_CACHE_HOME 环境变量。
        """
        if self.is_windows():
            # Windows: 优先使用 LOCALAPPDATA\\Cache，备选 TEMP
            local_cache = Path(
                os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local")
            )
            cache_path = local_cache / "Cache"
            if cache_path.exists():
                return cache_path
            temp_path = Path(os.getenv("TEMP", ""))
            if temp_path.exists():
                return temp_path
            return cache_path

        if self.is_darwin():
            # macOS: ~/Library/Caches
            return Path.home() / "Library" / "Caches"

        # Linux: XDG Base Directory 规范
        # 优先使用 XDG_CACHE_HOME，默认为 ~/.cache
        xdg_cache = os.getenv("XDG_CACHE_HOME")
        if xdg_cache:
            return Path(xdg_cache)
        return Path.home() / ".cache"

    @cached_property
    def state_home(self) -> Path:
        """获取系统状态目录

        根据不同操作系统返回状态目录的默认位置：
        - Windows: %LOCALAPPDATA%
        - macOS: ~/Library/Application Support
        - Linux: ~/.local/state

        Returns:
            Path: 系统状态目录的绝对路径

        Examples:
            >>> env = Environment()
            >>> state_dir = env.state_home
            >>> print(state_dir)
            >>> # Windows 输出: C:\\Users\\username\\AppData\\Local
            >>> # macOS 输出: /Users/username/Library/Application Support
            >>> # Linux 输出: /home/username/.local/state

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
            Linux 遵循 XDG Base Directory 规范，使用 XDG_STATE_HOME 环境变量。
            状态目录用于存储应用运行时状态（如日志、锁文件等）。
        """
        if self.is_windows():
            # Windows: 状态放在 LOCALAPPDATA
            return Path(
                os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local")
            )

        if self.is_darwin():
            # macOS: 状态放在 Application Support
            return Path.home() / "Library" / "Application Support"

        # Linux: XDG Base Directory 规范
        # 优先使用 XDG_STATE_HOME，默认为 ~/.local/state
        xdg_state = os.getenv("XDG_STATE_HOME")
        if xdg_state:
            return Path(xdg_state)
        return Path.home() / ".local" / "state"

    @cached_property
    def tmp_dir(self) -> Path:
        """获取系统临时目录

        使用 tempfile 模块获取跨平台的临时目录。

        Returns:
            Path: 系统临时目录的绝对路径

        Examples:
            >>> env = Environment()
            >>> tmp = env.tmp_dir
            >>> print(tmp)
            >>> # Windows 输出: C:\\Users\\username\\AppData\\Local\\Temp
            >>> # macOS/Linux 输出: /tmp

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
            使用 tempfile.gettempdir() 获取系统临时目录。
        """
        return Path(tempfile.gettempdir())

    @cached_property
    def home(self) -> Path:
        """获取用户主目录

        Returns:
            Path: 用户主目录的绝对路径

        Examples:
            >>> env = Environment()
            >>> home_dir = env.home
            >>> print(home_dir)
            >>> # Windows 输出: C:\\Users\\username
            >>> # macOS/Linux 输出: /home/username

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
            等同于 Path.home()。
        """
        return Path.home()

    @cached_property
    def application(self) -> Path:
        """获取系统应用安装目录

        根据不同操作系统返回应用安装目录：
        - Windows: %ProgramFiles% (C:\\Program Files)
        - macOS: /Applications
        - Linux: /usr/local

        Returns:
            Path: 系统应用安装目录的绝对路径

        Examples:
            >>> env = Environment()
            >>> app_dir = env.application
            >>> print(app_dir)
            >>> # Windows 输出: C:\\Program Files
            >>> # macOS 输出: /Applications
            >>> # Linux 输出: /usr/local

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
        """
        if self.is_windows():
            # Windows: %ProgramFiles%
            return Path(os.getenv("ProgramFiles", "C:\\Program Files"))

        if self.is_darwin():
            # macOS: /Applications
            return Path("/Applications")

        # Linux: /usr/local (本地安装的应用)
        return Path("/usr/local")

    @cached_property
    def machine_code(self) -> str:
        """获取机器码

        基于多个机器特征生成唯一的机器标识符，包括：
        - 主机名
        - 登录用户名
        - MAC 地址

        Returns:
            str: 机器码的十六进制字符串表示

        Examples:
            >>> env = Environment()
            >>> machine_code = env.machine_code
            >>> print(machine_code)
            >>> # 输出类似: a1b2c3d4e5f6...

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
            机器码基于 SHA-256 哈希算法生成，具有足够的唯一性。
        """
        machine_id = platform.node()
        user = os.getlogin()
        machine_uuid = str(uuid.getnode())

        combined = f"{machine_id}:{user}:{machine_uuid}"
        hash_obj = hashlib.sha256(combined.encode())
        return hash_obj.hexdigest()

    @cached_property
    def machine_code_base64(self) -> str:
        """获取机器码的 Base64 编码

        将机器码转换为 Base64 编码格式，便于在需要 ASCII 字符的场景使用。

        Returns:
            str: 机器码的 Base64 编码字符串

        Examples:
            >>> env = Environment()
            >>> machine_code_b64 = env.machine_code_base64
            >>> print(machine_code_b64)
            >>> # 输出类似: YWIxYzJkM2U0ZjY...

        Note:
            该方法使用 @cached_property 装饰器，结果会被缓存。
            Base64 编码使用 URL 安全字符集（urlsafe_b64encode）。
            直接复用 machine_code 的哈希结果进行编码，避免重复计算。
        """
        hex_str = self.machine_code
        hash_bytes = bytes.fromhex(hex_str)
        return base64.urlsafe_b64encode(hash_bytes).decode()

    def get_machine_key(self, salt: str = "pynomad_cache_v1") -> bytes:
        """获取机器派生密钥

        基于机器特征和可选盐值生成加密密钥，用于防止缓存数据被复制到其他机器使用。
        复用 machine_code 的哈希结果，将 salt 拼接后再次哈希。

        Args:
            salt: 可选的盐值，用于隔离不同项目的密钥。默认为 "pynomad_cache_v1"

        Returns:
            bytes: 适用于 Fernet 加密的 32 字节密钥

        Examples:
            >>> env = Environment()
            >>> key = env.get_machine_key()
            >>> print(len(key))
            >>> # 输出: 32
            >>> # 不同项目使用不同盐值
            >>> key_custom = env.get_machine_key(salt="my_project_v1")

        Note:
            复用 machine_code 的哈希结果，避免重复计算。
            相同的 salt 参数会返回相同的密钥。
            密钥长度为 32 字节，符合 Fernet 加密算法的要求。

        Warning:
            机器码包含用户名等敏感信息，密钥应妥善保管。
            更改机器特征（如更换用户、重装系统）会导致密钥失效，
            从而无法解密之前加密的数据。
        """
        combined = f"{self.machine_code}:{salt}"
        key = hashlib.sha256(combined.encode()).digest()

        return base64.urlsafe_b64encode(key)

    def get_machine_base64(self, salt: str = "pynomad_cache_v1") -> str:
        """获取机器码与盐值组合的 Base64 编码

        将机器码和盐值组合后进行 Base64 编码，用于需要字符串密钥的场景。

        Args:
            salt: 可选的盐值，用于隔离不同项目的密钥。默认为 "pynomad_cache_v1"

        Returns:
            str: Base64 编码的机器码字符串

        Examples:
            >>> env = Environment()
            >>> machine_b64 = env.get_machine_base64()
            >>> print(machine_b64)
            >>> # 输出: YWIxYzJkM2U0ZjY...
            >>> # 不同项目使用不同盐值
            >>> machine_b64_custom = env.get_machine_base64(salt="my_project_v1")

        Note:
            复用 get_machine_key 的结果，转换为字符串格式。
            相同的 salt 参数会返回相同的结果。
        """
        key = self.get_machine_key(salt=salt)
        return key.decode()

    @property
    def cache(self) -> Path:
        """获取系统缓存目录（属性别名）

        Returns:
            Path: 系统缓存目录的绝对路径

        Note:
            该属性是 cache_home 的别名，提供更简洁的访问方式。
        """
        return self.cache_home


# 全局单例实例
# 使用 @singleton 装饰器确保整个程序只有一个 Environment 实例
environ = Environment()


@cache
def get_project_dir() -> Path:
    """获取项目根目录（缓存版本）

    使用 @cache 装饰器缓存结果，避免重复计算。
    这是一个便捷函数，内部调用 Environment 单例的 get_project_dir() 方法。

    Returns:
        Path: 项目根目录的绝对路径

    Raises:
        RuntimeError: 当无法确定项目根目录时抛出

    Examples:
        >>> from pynomad.common.environment import get_project_dir
        >>> root = get_project_dir()
        >>> print(root)
        >>> # 输出类似：/path/to/your/project

    Note:
        该函数使用 @cache 装饰器，第一次调用后结果会被缓存。
        在无法确定项目根目录时，会返回当前工作目录（Path.cwd()）。
    """
    return environ.get_project_dir()


@cache
def get_project_name() -> str:
    """获取项目名称（缓存版本）

    使用 @cache 装饰器缓存结果，避免重复计算。
    这是一个便捷函数，内部调用 Environment 单例的 get_project_name() 方法。

    Returns:
        str: 项目名称

    Examples:
        >>> from pynomad.common.environment import get_project_name
        >>> name = get_project_name()
        >>> print(name)
        >>> # 如果项目根目录是 /path/to/myproject，输出 "myproject"

    Note:
        该函数使用 @cache 装饰器，第一次调用后结果会被缓存。
    """
    return environ.get_project_name()
