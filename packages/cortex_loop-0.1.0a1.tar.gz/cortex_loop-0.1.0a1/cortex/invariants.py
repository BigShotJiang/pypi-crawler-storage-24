from __future__ import annotations

import importlib.util
import os
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from .genome import HooksConfig, InvariantsConfig
from .store import SQLiteStore


@dataclass(slots=True)
class InvariantCaseResult:
    test_path: str
    status: str
    duration_ms: int
    stdout: str
    stderr: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "test_path": self.test_path,
            "status": self.status,
            "duration_ms": self.duration_ms,
            "stdout": self.stdout,
            "stderr": self.stderr,
        }


@dataclass(slots=True)
class InvariantReport:
    configured_paths: list[str]
    results: list[InvariantCaseResult] = field(default_factory=list)
    diagnostics: list[dict[str, Any]] = field(default_factory=list)
    ok: bool = True
    had_errors: bool = False
    recommend_revert: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "configured_paths": self.configured_paths,
            "results": [r.to_dict() for r in self.results],
            "diagnostics": self.diagnostics,
            "ok": self.ok,
            "had_errors": self.had_errors,
            "recommend_revert": self.recommend_revert,
        }


class InvariantRunner:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        config: InvariantsConfig,
        hooks_config: HooksConfig,
        *,
        trust_profile: str = "trusted",
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.store = store
        self.config = config
        self.hooks_config = hooks_config
        self.trust_profile = trust_profile if trust_profile in {"trusted", "untrusted"} else "untrusted"

    def run(self, session_id: str, extra_pytest_args: Iterable[str] | None = None) -> InvariantReport:
        report = InvariantReport(configured_paths=list(self.config.suite_paths))
        args = list(extra_pytest_args or [])
        if self.trust_profile == "untrusted" and self.config.execution_mode == "host":
            result = InvariantCaseResult(
                test_path="__policy__",
                status="error",
                duration_ms=0,
                stdout="",
                stderr=(
                    "Host invariant execution is blocked for trust_profile='untrusted'. "
                    "Set [invariants].execution_mode='container' or [project].trust_profile='trusted'."
                ),
            )
            report.results.append(result)
            report.diagnostics.append(_invariant_diagnostic(result))
            report.ok = False
            report.had_errors = True
            self.store.record_invariant_result(
                session_id=session_id,
                test_path=result.test_path,
                status=result.status,
                duration_ms=result.duration_ms,
                stdout=result.stdout,
                stderr=result.stderr,
            )
            report.recommend_revert = self.hooks_config.recommend_revert_on_invariant_failure
            return report

        for suite_path in self.config.suite_paths:
            result = self._run_one(session_id=session_id, suite_path=suite_path, extra_args=args)
            report.results.append(result)
            if result.status in {"fail", "error", "missing"}:
                report.diagnostics.append(_invariant_diagnostic(result))
            self.store.record_invariant_result(
                session_id=session_id,
                test_path=result.test_path,
                status=result.status,
                duration_ms=result.duration_ms,
                stdout=result.stdout,
                stderr=result.stderr,
            )
            if result.status in {"fail", "error", "missing"}:
                report.ok = False
            if result.status == "error":
                report.had_errors = True

        if not report.ok:
            report.recommend_revert = self.hooks_config.recommend_revert_on_invariant_failure
        return report

    def promote_session_test(self, session_id: str, source_path: str | Path) -> Path:
        source = (self.repo_root / source_path).resolve() if not Path(source_path).is_absolute() else Path(source_path)
        target_dir = self.repo_root / self.config.graduation.target_dir
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / source.name
        shutil.copy2(source, target)
        self.store.record_invariant_result(
            session_id=session_id,
            test_path=str(target.relative_to(self.repo_root)),
            status="graduated",
            duration_ms=0,
            stdout="",
            stderr="",
            graduated_from=str(source),
        )
        return target

    def _run_one(self, *, session_id: str, suite_path: str, extra_args: list[str]) -> InvariantCaseResult:
        path = self.repo_root / suite_path
        if not path.exists():
            return InvariantCaseResult(
                test_path=suite_path,
                status="missing",
                duration_ms=0,
                stdout="",
                stderr=f"Invariant path not found: {suite_path}",
            )

        started = time.perf_counter()
        try:
            cmd = self._pytest_command(path=path, suite_path=suite_path, extra_args=extra_args, session_id=session_id)
        except ValueError as exc:
            return InvariantCaseResult(
                test_path=suite_path,
                status="error",
                duration_ms=int((time.perf_counter() - started) * 1000),
                stdout="",
                stderr=str(exc),
            )
        env = None
        if self.config.execution_mode != "container":
            env = os.environ.copy()
            env["CORTEX_SESSION_ID"] = str(session_id)
            env["CORTEX_PROJECT_ROOT"] = str(self.repo_root)
        try:
            proc = subprocess.run(
                cmd,
                cwd=self.repo_root,
                env=env,
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError as exc:
            return InvariantCaseResult(
                test_path=suite_path,
                status="error",
                duration_ms=int((time.perf_counter() - started) * 1000),
                stdout="",
                stderr=str(exc),
            )

        duration_ms = int((time.perf_counter() - started) * 1000)
        status = "pass" if proc.returncode == 0 else "fail"
        return InvariantCaseResult(
            test_path=suite_path,
            status=status,
            duration_ms=duration_ms,
            stdout=proc.stdout.strip(),
            stderr=proc.stderr.strip(),
        )

    def _pytest_command(
        self,
        *,
        path: Path,
        suite_path: str,
        extra_args: list[str],
        session_id: str,
    ) -> list[str]:
        if self.config.execution_mode != "container":
            return self._host_pytest_command(path=path, extra_args=extra_args)
        target = self._container_suite_path(path, suite_path)
        return [
            self.config.container_engine,
            "run",
            "--rm",
            "-e",
            f"CORTEX_SESSION_ID={session_id}",
            "-e",
            f"CORTEX_PROJECT_ROOT={self.config.container_workdir}",
            "-v",
            f"{self.repo_root}:{self.config.container_workdir}",
            "-w",
            self.config.container_workdir,
            self.config.container_image,
            "python",
            "-m",
            "pytest",
            target,
            *extra_args,
        ]

    def _host_pytest_command(self, *, path: Path, extra_args: list[str]) -> list[str]:
        configured = str(self.config.pytest_bin).strip() or "pytest"
        configured_path = Path(configured).expanduser()
        if configured_path.is_absolute() and configured_path.exists():
            return [str(configured_path), str(path), *extra_args]
        if any(sep in configured for sep in ("/", "\\")):
            repo_relative = (self.repo_root / configured_path).resolve()
            if repo_relative.exists():
                return [str(repo_relative), str(path), *extra_args]
            if configured_path.exists():
                return [str(configured_path.resolve()), str(path), *extra_args]
        elif shutil.which(configured):
            return [configured, str(path), *extra_args]
        if importlib.util.find_spec("pytest") is not None:
            return [sys.executable, "-m", "pytest", str(path), *extra_args]
        raise ValueError(
            f"Configured pytest_bin '{configured}' is unavailable and fallback 'python -m pytest' is not installed."
        )

    def _container_suite_path(self, path: Path, suite_path: str) -> str:
        try:
            return str(path.resolve().relative_to(self.repo_root))
        except ValueError as exc:
            raise ValueError(
                f"Container invariant path is outside repo root: {path.resolve()} (root: {self.repo_root})"
            ) from exc


def _invariant_diagnostic(result: InvariantCaseResult) -> dict[str, Any]:
    if result.status == "missing":
        return {"evidence_found": [result.test_path], "evidence_expected": ["configured invariant test path to exist"], "gap_description": f"Invariant path '{result.test_path}' was missing.", "gap_characterization": "comprehension_gap", "distance_signal": "far"}
    if result.status == "error":
        return {"evidence_found": [result.stderr[:200]] if result.stderr else [result.test_path], "evidence_expected": [f"invariant '{result.test_path}' to run successfully"], "gap_description": f"Invariant '{result.test_path}' could not execute cleanly.", "gap_characterization": "execution_gap", "distance_signal": "moderate"}
    return {"evidence_found": [result.test_path], "evidence_expected": [f"invariant '{result.test_path}' to pass"], "gap_description": f"Invariant '{result.test_path}' failed.", "gap_characterization": "execution_gap", "distance_signal": "close"}
