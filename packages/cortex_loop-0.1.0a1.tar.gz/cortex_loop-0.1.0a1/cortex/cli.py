import sys
from importlib import import_module
from types import ModuleType

_IMPL = import_module("cortex_ops_cli.main")
sys.modules[__name__].__class__ = type("_ShimModule", (ModuleType,), {"__getattr__": lambda self, name: getattr(_IMPL, name), "__setattr__": lambda self, name, value: (setattr(_IMPL, name, value), ModuleType.__setattr__(self, name, value))[1]})
if __name__ == "__main__": raise SystemExit(_IMPL.main())  # noqa: E701
