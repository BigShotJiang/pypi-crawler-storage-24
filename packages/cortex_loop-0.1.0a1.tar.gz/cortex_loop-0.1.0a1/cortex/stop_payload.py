from __future__ import annotations

import json
import re
from collections.abc import Mapping
from typing import Any

STOP_FIELD_KEYS = (
    "challenge_coverage",
    "requirement_audit",
    "truth_claims",
    "required_requirement_ids",
    "failed_approach",
    "stuck_declaration",
)


def extract_stop_fields(
    payload: Mapping[str, Any], *, allow_message_fallback: bool = True
) -> tuple[dict[str, Any] | None, str | None, list[str], int]:
    warnings: list[str] = []

    raw = payload.get("stop_fields")
    if isinstance(raw, Mapping):
        normalized, normalization_count = _canonicalize_map_keys(raw)
        return normalized, "payload.stop_fields", warnings, normalization_count
    if raw is not None:
        warnings.append("Ignoring invalid stop_fields field; expected an object.")

    if not allow_message_fallback:
        return None, None, warnings, 0
    if any(payload.get(key) is not None for key in STOP_FIELD_KEYS):
        return None, None, warnings, 0

    last_message = payload.get("last_assistant_message")
    if isinstance(last_message, str):
        parsed, marker_found, error = parse_stop_fields_json(last_message)
        if parsed is not None:
            normalized, normalization_count = _canonicalize_map_keys(parsed)
            return normalized, "last_assistant_message", warnings, normalization_count
        if marker_found and error:
            warnings.append(f"Ignoring invalid STOP_FIELDS_JSON trailer: {error}")

    return None, None, warnings, 0


def resolve_stop_value(
    *,
    key: str,
    payload: Mapping[str, Any],
    stop_fields: dict[str, Any] | None,
    stop_fields_source: str | None,
    warnings: list[str],
    value_label: str,
) -> Any:
    value = payload.get(key)
    if value is not None or not (stop_fields and key in stop_fields):
        return value
    value = stop_fields[key]
    if stop_fields_source == "last_assistant_message":
        warnings.append(f"Using {value_label} parsed from last assistant message (STOP_FIELDS_JSON).")
    elif stop_fields_source == "payload.stop_fields":
        warnings.append(f"Using {value_label} from payload.stop_fields.")
    return value


def parse_stop_fields_json(text: str) -> tuple[dict[str, Any] | None, bool, str | None]:
    for pattern in (
        r"```(?:stop-fields|stop_fields)\s*(\{.*?\})\s*```",
        r"```json\s*(\{.*?\"challenge_coverage\".*?\})\s*```",
    ):
        match = re.search(pattern, text, flags=re.DOTALL)
        if not match:
            continue
        try:
            parsed = json.loads(match.group(1))
        except json.JSONDecodeError as exc:
            return None, True, str(exc)
        if not isinstance(parsed, dict):
            return None, True, "expected a JSON object"
        return parsed, True, None

    marker = "STOP_FIELDS_JSON:"
    idx = text.rfind(marker)
    if idx == -1:
        return None, False, None
    decoder = json.JSONDecoder()
    try:
        parsed, _ = decoder.raw_decode(text[idx + len(marker) :].lstrip())
    except json.JSONDecodeError as exc:
        return None, True, str(exc)
    if not isinstance(parsed, dict):
        return None, True, "expected a JSON object"
    return parsed, True, None


def _canonicalize_map_keys(value: Mapping[str, Any]) -> tuple[dict[str, Any], int]:
    normalized: dict[str, Any] = {}
    normalization_count = 0
    for raw_key, raw_value in value.items():
        key = str(raw_key)
        canonical_key = key.strip()
        if canonical_key != key:
            normalization_count += 1
        canonical_value, nested_count = _canonicalize_value(raw_value)
        normalization_count += nested_count
        normalized[canonical_key] = canonical_value
    return normalized, normalization_count


def _canonicalize_value(value: Any) -> tuple[Any, int]:
    if isinstance(value, Mapping):
        return _canonicalize_map_keys(value)
    if isinstance(value, list):
        items: list[Any] = []
        normalization_count = 0
        for item in value:
            canonical_item, nested_count = _canonicalize_value(item)
            items.append(canonical_item)
            normalization_count += nested_count
        return items, normalization_count
    return value, 0
