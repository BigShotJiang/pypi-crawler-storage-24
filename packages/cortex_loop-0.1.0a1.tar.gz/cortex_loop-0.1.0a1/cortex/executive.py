from __future__ import annotations

import json
import re
from collections.abc import Mapping
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable

_LAYER1_PART_A_PATH = Path(__file__).resolve().parent / "data" / "layer1_part_a.md"
_LAYER1_PART_B_PATH = Path(__file__).resolve().parent / "data" / "layer1_part_b.md"
_IDENTITY_PREAMBLE_PATH = Path(__file__).resolve().parent / "data" / "identity_preamble.md"
_WORD_RE = re.compile(r"[A-Za-z0-9_]+")

_STOPWORDS = set(
    "a an and agent are as at be by code error file for from human in into is it its of on or output claim "
    "contradicted that the their then this to was were with".split()
)
_TOKEN_CANONICAL = {
    "verification": "verify",
    "verifications": "verify",
    "verified": "verify",
    "verifying": "verify",
    "defense": "defend",
    "defences": "defend",
}


def _tokenize_keywords(text: str) -> set[str]:
    return {
        token
        for raw in _WORD_RE.findall(text.lower())
        if (token := _normalize_keyword(raw))
        and len(token) >= 3
        and token not in _STOPWORDS
        and not token.isdigit()
    }


def _normalize_keyword(raw: str) -> str:
    token = str(raw).strip().lower().strip("_")
    if not token:
        return ""
    if token.startswith("verif"):
        token = "verify"
    elif token.startswith("defenc") or token.startswith("defens"):
        token = "defend"
    if token.endswith("ies") and len(token) > 4:
        token = token[:-3] + "y"
    elif token.endswith("ing") and len(token) > 5:
        token = token[:-3]
    elif token.endswith("ed") and len(token) > 4:
        token = token[:-2]
    elif token.endswith("s") and len(token) > 3:
        token = token[:-1]
    return _TOKEN_CANONICAL.get(token, token)


def _keyword_overlap(left: str, right: str) -> int:
    return len(_tokenize_keywords(left) & _tokenize_keywords(right))


def _canonical_phrase(text: str) -> str:
    return " ".join(str(text).strip().lower().split())


def effective_weight(entry: dict[str, Any], current_session_count: int, halflife_sessions: int = 30) -> float:
    current = max(0, int(current_session_count))
    half = max(1, int(halflife_sessions))
    last_accessed = max(0, int(entry.get("last_accessed_at_session", 0)))
    strength = max(1, int(entry.get("strength", 1)))
    sessions_since = max(0, current - last_accessed)
    recency = 1.0 / (1.0 + (sessions_since / half))
    return strength * recency


@lru_cache(maxsize=1)
def get_base_executive_function() -> tuple[str, str]:
    return (
        _read_layer1_asset(_LAYER1_PART_A_PATH, "Part A"),
        _read_layer1_asset(_LAYER1_PART_B_PATH, "Part B"),
    )


@lru_cache(maxsize=1)
def get_identity_preamble() -> str:
    return _read_layer1_asset(_IDENTITY_PREAMBLE_PATH, "Identity preamble")


def _read_layer1_asset(path: Path, label: str) -> str:
    try:
        content = path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise ValueError(f"Unable to read Layer 1 {label} asset: {path}") from exc
    if not content:
        raise ValueError(f"Layer 1 {label} asset is empty: {path}")
    return content


def _find_consolidation_match(entries: list[dict[str, Any]], *, event_type: str, trigger_pattern: str, error_pattern: str) -> dict[str, Any] | None:
    for entry in entries:
        if str(entry.get("type") or "") != event_type:
            continue
        existing_trigger = str(entry.get("trigger_pattern") or "")
        existing_error = str(entry.get("error_pattern") or "")
        if (
            _canonical_phrase(existing_trigger) == _canonical_phrase(trigger_pattern)
            and _canonical_phrase(existing_error) == _canonical_phrase(error_pattern)
        ):
            return entry
        trigger_overlap = _keyword_overlap(existing_trigger, trigger_pattern)
        error_overlap = _keyword_overlap(existing_error, error_pattern)
        if trigger_overlap >= 2 and error_overlap >= 2:
            return entry
    return None


def consolidate_event(store: Any, *, event_type: str, trigger_pattern: str, error_pattern: str, resolution: str, session_id: str) -> dict[str, Any]:
    current_session = store.get_session_count()
    entries = store.get_executive_memory()
    match = _find_consolidation_match(
        entries,
        event_type=str(event_type),
        trigger_pattern=str(trigger_pattern),
        error_pattern=str(error_pattern),
    )
    if match:
        updated_strength = int(match.get("strength", 1)) + 1
        store.update_executive_entry(
            str(match["id"]),
            strength=updated_strength,
            last_accessed_at_session=current_session,
        )
        merged = dict(match)
        merged["strength"] = updated_strength
        merged["last_accessed_at_session"] = current_session
        return merged
    return store.record_executive_event(
        str(event_type),
        str(trigger_pattern),
        str(error_pattern),
        str(resolution),
        str(session_id),
    )


def run_decay(store: Any, *, halflife_sessions: int = 30, threshold: float = 0.3, min_hold_sessions: int = 3) -> int:
    current_session = store.get_session_count()
    prune_ids: list[str] = []
    for entry in store.get_executive_memory():
        created_at = max(0, int(entry.get("created_at_session", 0)))
        if current_session - created_at < max(0, int(min_hold_sessions)):
            continue
        if effective_weight(entry, current_session, halflife_sessions) < float(threshold):
            prune_ids.append(str(entry.get("id") or ""))
    store.delete_executive_entries(prune_ids)
    return len([eid for eid in prune_ids if eid])


def record_stop_failure_event(
    store: Any,
    *,
    session_id: str,
    structured_stop_violation: bool,
    challenge_coverage_missing: bool,
    challenge_report: Mapping[str, Any] | None,
    requirements_gate_gap: bool,
    requirement_audit_report: Mapping[str, Any] | None,
    truth_claims_report: Mapping[str, Any] | None,
    invariant_report: Mapping[str, Any] | None,
    previous_signature: str | None = None,
    signature_claim: Callable[[str], bool] | None = None,
) -> tuple[dict[str, Any] | None, str | None]:
    missing = (
        [str(item).strip() for item in challenge_report["missing_categories"] if str(item).strip()]
        if isinstance(challenge_report, Mapping) and isinstance(challenge_report.get("missing_categories"), list)
        else []
    )
    req_errors = (
        [str(item).strip() for item in requirement_audit_report["errors"] if str(item).strip()][:2]
        if isinstance(requirement_audit_report, Mapping) and isinstance(requirement_audit_report.get("errors"), list)
        else []
    )
    truth_errors = (
        [str(item).strip() for item in truth_claims_report["errors"] if str(item).strip()][:2]
        if isinstance(truth_claims_report, Mapping) and isinstance(truth_claims_report.get("errors"), list)
        else []
    )
    invariant_failed = isinstance(invariant_report, Mapping) and invariant_report.get("ok") is False
    if structured_stop_violation:
        kind, event_type = "structured_stop_violation", "metacognitive"
        trigger = "stop payload lacked structured evidence fields"
        error = "completion claim submitted without machine-readable stop fields"
        resolution = "emit payload.stop_fields or STOP_FIELDS_JSON with evidence before claiming completion"
    elif requirements_gate_gap:
        kind, event_type = "requirements_gate_gap", "technical"
        trigger = "stop requirement or truth evidence gap"
        error = "completion claim included unverified requirement/truth evidence"
        resolution = "add requirement_audit and truth_claims entries backed by observed evidence"
    elif challenge_coverage_missing or missing:
        kind, event_type = "challenge_coverage_gap", "technical"
        scope = ", ".join(missing) if missing else "required categories"
        trigger = f"stop challenge coverage missing ({scope})"
        error = "completion claim omitted required challenge coverage evidence"
        resolution = "provide challenge_coverage covering all active categories before completion"
    elif invariant_failed:
        kind, event_type = "invariant_failure", "technical"
        trigger = "stop invariant suite failure"
        error = "completion claim submitted while invariants were failing"
        resolution = "fix failing invariants and rerun invariant suite before completion"
    else:
        return None, None
    signature = json.dumps(
        {"kind": kind, "missing_categories": missing, "req_errors": req_errors, "truth_errors": truth_errors},
        sort_keys=True,
        separators=(",", ":"),
    )
    if signature == str(previous_signature or ""):
        return None, signature
    if signature_claim is not None and not signature_claim(signature):
        return None, signature
    return (
        consolidate_event(
            store,
            event_type=event_type,
            trigger_pattern=trigger,
            error_pattern=error,
            resolution=resolution,
            session_id=session_id,
        ),
        signature,
    )


def _format_learned_entry(entry: dict[str, Any], *, sessions_since: int) -> str:
    strength = max(1, int(entry.get("strength", 1)))
    trigger = str(entry.get("trigger_pattern") or "").strip()
    error = str(entry.get("error_pattern") or "").strip()
    resolution = str(entry.get("resolution") or "").strip()
    guidance = f"When {trigger}, avoid {error}. Correct action: {resolution}."
    return f"[reinforced {strength} times, last relevant {sessions_since} sessions ago]\n{guidance}"


def _approx_tokens(text: str) -> int:
    return max(1, len(text) // 4)


def get_learned_executive_function(store: Any, *, halflife_sessions: int, inject_threshold: float, decay_threshold: float, max_entries: int, max_tokens: int, min_hold_sessions: int) -> str:
    current_session = store.get_session_count()
    candidates: list[dict[str, Any]] = []
    for entry in store.get_executive_memory():
        weight = effective_weight(entry, current_session, halflife_sessions)
        sessions_since = max(0, current_session - int(entry.get("last_accessed_at_session", 0)))
        is_recent_hold = sessions_since <= max(0, int(min_hold_sessions))
        if weight >= float(inject_threshold) or (is_recent_hold and weight >= float(decay_threshold)):
            candidate = dict(entry)
            candidate["effective_weight"] = weight
            candidate["sessions_since"] = sessions_since
            candidates.append(candidate)
    candidates.sort(
        key=lambda item: (
            float(item["effective_weight"]),
            int(item.get("strength", 1)),
            -int(item.get("sessions_since", 0)),
        ),
        reverse=True,
    )

    selected: list[dict[str, Any]] = []
    token_budget = max(0, int(max_tokens))
    used_tokens = _approx_tokens("## Learned patterns from this project")
    for entry in candidates:
        if len(selected) >= max(1, int(max_entries)):
            break
        rendered = _format_learned_entry(entry, sessions_since=int(entry["sessions_since"]))
        rendered_tokens = _approx_tokens(rendered)
        if used_tokens + rendered_tokens > token_budget:
            continue
        used_tokens += rendered_tokens
        selected.append(entry)

    if not selected:
        return ""

    for entry in selected:
        store.update_executive_entry(
            str(entry["id"]),
            last_accessed_at_session=current_session,
        )

    lines = ["## Learned patterns from this project", ""]
    for entry in selected:
        lines.append(_format_learned_entry(entry, sessions_since=int(entry["sessions_since"])))
        lines.append("")
    return "\n".join(lines).strip()
