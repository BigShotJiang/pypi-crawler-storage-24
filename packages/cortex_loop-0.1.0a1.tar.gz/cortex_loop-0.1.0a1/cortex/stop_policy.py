from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class StopVerdict:
    session_status: str
    recommend_revert: bool
    proceed: bool
    feedback_mode: str


def compute_stop_outcome(
    *,
    mode: str,
    fail_on_missing_challenge_coverage: bool,
    fail_on_requirement_audit_gap: bool,
    require_requirement_audit: bool,
    challenge_ok: bool | None,
    invariant_ok: bool | None,
    invariant_recommend_revert: bool,
    missing_challenge_coverage: bool,
    requirements_gate_gap: bool,
    requirement_audit_missing: bool,
    structured_stop_violation: bool,
    loop_detected: bool = False,
    stuck_declared: bool = False,
) -> StopVerdict:
    strict_mode = mode == "strict"
    strict_challenge_gate = strict_mode and fail_on_missing_challenge_coverage
    challenge_gate_violation = _challenge_gate_violation(
        strict_challenge_gate=strict_challenge_gate,
        missing_challenge_coverage=missing_challenge_coverage,
        challenge_ok=challenge_ok,
    )
    requirement_audit_violation = _requirement_audit_violation(
        strict_mode=strict_mode,
        fail_on_requirement_audit_gap=fail_on_requirement_audit_gap,
        requirements_gate_gap=requirements_gate_gap,
        requirement_audit_missing=requirement_audit_missing,
        require_requirement_audit=require_requirement_audit,
    )

    base_status = "completed"
    if invariant_ok is False:
        base_status = "failed_invariants"
    elif structured_stop_violation:
        base_status = "failed_stop_contract"
    elif requirement_audit_violation:
        base_status = "failed_requirements"
    elif challenge_ok is False:
        base_status = "failed_challenges"
    elif missing_challenge_coverage and strict_challenge_gate:
        base_status = "missing_challenge_coverage"

    if base_status != "completed" and stuck_declared:
        return StopVerdict(
            session_status="stuck",
            recommend_revert=False,
            proceed=False,
            feedback_mode="stuck",
        )

    recommend_revert = bool(
        invariant_recommend_revert
        or challenge_gate_violation
        or requirement_audit_violation
        or (strict_mode and structured_stop_violation)
    )
    return StopVerdict(
        session_status=base_status,
        recommend_revert=recommend_revert,
        proceed=not recommend_revert,
        feedback_mode="reconsider_approach" if base_status != "completed" and loop_detected else "normal",
    )


def _challenge_gate_violation(
    *,
    strict_challenge_gate: bool,
    missing_challenge_coverage: bool,
    challenge_ok: bool | None,
) -> bool:
    return strict_challenge_gate and (missing_challenge_coverage or challenge_ok is False)


def _requirement_audit_violation(
    *,
    strict_mode: bool,
    fail_on_requirement_audit_gap: bool,
    requirements_gate_gap: bool,
    requirement_audit_missing: bool,
    require_requirement_audit: bool,
) -> bool:
    return bool(
        strict_mode
        and fail_on_requirement_audit_gap
        and (requirements_gate_gap or (requirement_audit_missing and require_requirement_audit))
    )
