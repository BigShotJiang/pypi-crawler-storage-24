from __future__ import annotations

import re
from pathlib import Path
from typing import Any


def _as_bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "yes", "on", "1"}:
            return True
        if lowered in {"false", "no", "off", "0"}:
            return False
    return default


def _as_string_list(value: Any) -> list[str]:
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if isinstance(value, (list, tuple)):
        return [text for v in value if v is not None for text in [str(v).strip()] if text]
    return []


def _unique_list(values: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def _normalize_repo_relative_path(value: str, *, root: Path) -> str | None:
    raw = str(value).strip().strip("'\"")
    if not raw or raw.startswith(("http://", "https://")):
        return None
    raw = raw.split("#", 1)[0].strip()
    raw = re.sub(r":\d+(?::\d+|-\d+)?$", "", raw).strip().rstrip(".,;:")
    if not raw:
        return None
    raw = raw.replace("\\", "/")
    if raw.startswith("./"):
        raw = raw[2:]
    candidate = Path(raw).expanduser()
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    try:
        return resolved.relative_to(root).as_posix()
    except ValueError:
        return None
