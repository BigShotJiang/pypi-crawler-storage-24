from __future__ import annotations

import importlib
import json
import logging
import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Protocol

from .stop_payload import parse_stop_fields_json

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class NormalizedEvent:
    name: str
    payload: dict[str, Any]


class EventAdapter(Protocol):
    def normalize(self, event_name: str, payload: Mapping[str, Any] | None = None) -> NormalizedEvent: ...


CANONICAL_EVENT_ALIASES = {
    "session_start": "session_start",
    "sessionstart": "session_start",
    "session_marker": "session_marker",
    "sessionmarker": "session_marker",
    "pre_tool_use": "pre_tool_use",
    "pretooluse": "pre_tool_use",
    "post_tool_use": "post_tool_use",
    "posttooluse": "post_tool_use",
    "stop": "stop",
}


class GenericAdapter:
    EVENT_ALIASES = CANONICAL_EVENT_ALIASES

    def normalize(self, event_name: str, payload: Mapping[str, Any] | None = None) -> NormalizedEvent:
        name = _normalize_event_name(event_name, self.EVENT_ALIASES)
        data = dict(payload) if isinstance(payload, Mapping) else {}
        return NormalizedEvent(name=name, payload=data)


class ClaudeAdapter:
    EVENT_ALIASES = CANONICAL_EVENT_ALIASES

    def normalize(self, event_name: str, payload: Mapping[str, Any] | None = None) -> NormalizedEvent:
        name = _normalize_event_name(event_name, self.EVENT_ALIASES)
        data = dict(payload) if isinstance(payload, Mapping) else {}
        data = _normalize_claude_payload(data)
        message = data.get("last_assistant_message")
        if isinstance(message, str):
            rewritten = _rewrite_legacy_trailer_markers(message)
            if name == "stop":
                stop_fields, passthrough = _normalize_claude_stop_fields(rewritten)
                if isinstance(stop_fields, dict):
                    data["stop_fields"] = stop_fields
                data["last_assistant_message"] = passthrough
            else:
                data["last_assistant_message"] = rewritten
        return NormalizedEvent(name=name, payload=data)


GEMINI_EVENT_ALIASES = {
    **CANONICAL_EVENT_ALIASES,
    "SessionStart": "session_start",
    "BeforeTool": "pre_tool_use",
    "AfterTool": "post_tool_use",
    "AfterAgent": "stop",
    "SessionEnd": "session_end",
    "BeforeAgent": "before_agent",
    "BeforeModel": "before_model",
    "AfterModel": "after_model",
    "BeforeToolSelection": "before_tool_selection",
    "Notification": "notification",
    "PreCompress": "pre_compress",
    "sessionstart": "session_start",
    "beforetool": "pre_tool_use",
    "aftertool": "post_tool_use",
    "afteragent": "stop",
}


class GeminiAdapter:
    EVENT_ALIASES = GEMINI_EVENT_ALIASES

    def normalize(self, event_name: str, payload: Mapping[str, Any] | None = None) -> NormalizedEvent:
        name = _normalize_event_name(event_name, self.EVENT_ALIASES)
        data = dict(payload) if isinstance(payload, Mapping) else {}
        _normalize_session_id(data)
        if name in {"pre_tool_use", "post_tool_use"}:
            _normalize_tool_name(data, candidate_keys=("tool_name",))
        if name == "post_tool_use":
            _normalize_gemini_status(data)
        if name == "stop":
            prompt_response = data.get("prompt_response")
            if not isinstance(prompt_response, str):
                if "prompt_response" not in data:
                    logger.warning("Gemini AfterAgent payload missing prompt_response; using empty string fallback.")
                else:
                    logger.warning(
                        "Gemini AfterAgent prompt_response is not a string (%s); using empty string fallback.",
                        type(prompt_response).__name__,
                    )
                prompt_response = ""
            stop_fields, passthrough = _normalize_gemini_stop_fields(prompt_response)
            data["stop_fields"] = stop_fields
            data["last_assistant_message"] = passthrough
        return NormalizedEvent(name=name, payload=data)


OPENAI_EVENT_ALIASES = {
    **CANONICAL_EVENT_ALIASES,
    "item/commandexecution/requestapproval": "pre_tool_use",
    "item/commandExecution/requestApproval": "pre_tool_use",
    "command_execution_request_approval": "pre_tool_use",
    "item/commandexecution/completed": "post_tool_use",
    "item/commandExecution/completed": "post_tool_use",
    "command_execution_completed": "post_tool_use",
    "turn/completed": "stop",
    "turn_completed": "stop",
}


class OpenAIAdapter:
    EVENT_ALIASES = OPENAI_EVENT_ALIASES

    def normalize(self, event_name: str, payload: Mapping[str, Any] | None = None) -> NormalizedEvent:
        name = _normalize_event_name(event_name, self.EVENT_ALIASES)
        data = dict(payload) if isinstance(payload, Mapping) else {}
        _normalize_session_id(data)
        if name in {"pre_tool_use", "post_tool_use"}:
            _normalize_tool_name(data, candidate_keys=("tool_name", "command", "tool", "action"))
        if name == "stop":
            final_text = data.get("final_text")
            if isinstance(final_text, str) and "last_assistant_message" not in data:
                data["last_assistant_message"] = final_text
            if "stop_fields" in data and isinstance(data.get("stop_fields"), Mapping):
                data["stop_fields"] = dict(data["stop_fields"])
        return NormalizedEvent(name=name, payload=data)


def load_adapter(adapter_path: str) -> EventAdapter:
    module_name, class_name = _split_adapter_path(adapter_path)
    try:
        module = importlib.import_module(module_name)
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"Failed to import adapter module '{module_name}': {exc}") from exc
    adapter_cls = getattr(module, class_name, None)
    if adapter_cls is None:
        raise ValueError(f"Adapter class '{class_name}' not found in module '{module_name}'.")
    try:
        adapter = adapter_cls()
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"Failed to instantiate adapter '{module_name}:{class_name}': {exc}") from exc
    if not callable(getattr(adapter, "normalize", None)):
        raise TypeError(
            f"Adapter '{module_name}:{class_name}' must define callable normalize(event_name, payload)."
        )
    return adapter


def _split_adapter_path(adapter_path: str) -> tuple[str, str]:
    token = str(adapter_path or "").strip()
    if not token:
        raise ValueError(
            "runtime.adapter is required. Set [runtime].adapter = \"module.path:ClassName\" in cortex.toml."
        )
    if ":" not in token:
        raise ValueError(
            f"Invalid runtime.adapter '{token}'. Expected format 'module.path:ClassName'."
        )
    module_name, class_name = token.split(":", 1)
    module_name = module_name.strip()
    class_name = class_name.strip()
    module_name = _ADAPTER_PATH_ALIASES.get(module_name, module_name)
    if not module_name or not class_name:
        raise ValueError(
            f"Invalid runtime.adapter '{token}'. Expected format 'module.path:ClassName'."
        )
    return module_name, class_name


def _normalize_event_name(event_name: str, aliases: dict[str, str]) -> str:
    raw = str(event_name or "").strip()
    if raw in aliases:
        return aliases[raw]
    token = raw.lower().replace("-", "_")
    return aliases.get(token) or aliases.get(token.replace("_", "")) or token


def _normalize_claude_payload(payload: dict[str, Any]) -> dict[str, Any]:
    _normalize_tool_name(payload, candidate_keys=("tool_name", "tool", "toolName", "action"))
    _normalize_session_id(payload)
    if "stop_fields" not in payload and "cortex_stop" in payload:
        payload["stop_fields"] = payload.get("cortex_stop")
    return payload


def _normalize_claude_stop_fields(message: str) -> tuple[dict[str, Any] | None, str]:
    parsed, _, _ = parse_stop_fields_json(message)
    passthrough = _strip_gemini_stop_markers(message)
    if isinstance(parsed, dict):
        stop_fields = {str(k): v for k, v in parsed.items()}
        if passthrough and not stop_fields.get("summary"):
            stop_fields["summary"] = passthrough
        return stop_fields, passthrough
    return None, passthrough or message.strip()


_ADAPTER_PATH_ALIASES = {
    "cortex.adapters.claude": "cortex.adapters",
    "cortex.adapters.generic": "cortex.adapters",
    "cortex.adapters.gemini": "cortex.adapters",
    "cortex.adapters.openai": "cortex.adapters",
}


def _normalize_session_id(payload: dict[str, Any]) -> None:
    raw_session_id = payload.get("session_id")
    if isinstance(raw_session_id, str):
        session_id = raw_session_id.strip()
        if session_id:
            payload["session_id"] = session_id
            return
    payload.pop("session_id", None)


def _normalize_tool_name(payload: dict[str, Any], *, candidate_keys: tuple[str, ...]) -> None:
    primary = payload.get("tool_name")
    if isinstance(primary, str) and primary.strip():
        payload["tool_name"] = primary.strip()
        return
    payload.pop("tool_name", None)
    for key in candidate_keys:
        val = payload.get(key)
        if isinstance(val, str) and val.strip():
            payload["tool_name"] = val.strip()
            return


def _normalize_gemini_status(payload: dict[str, Any]) -> None:
    status = payload.get("status")
    if isinstance(status, str) and status.strip():
        payload["status"] = status.strip().lower()
        return
    tool_response = payload.get("tool_response")
    if isinstance(tool_response, Mapping) and tool_response.get("error"):
        payload["status"] = "error"
        return
    payload["status"] = "ok"


def _normalize_gemini_stop_fields(prompt_response: str) -> tuple[dict[str, Any], str]:
    parsed, marker_found, error = parse_stop_fields_json(prompt_response)
    passthrough = _strip_gemini_stop_markers(prompt_response)

    if isinstance(parsed, dict):
        stop_fields = {str(k): v for k, v in parsed.items()}
        if passthrough and not stop_fields.get("summary"):
            stop_fields["summary"] = passthrough
        return stop_fields, passthrough

    stop_fields = _recover_partial_stop_fields(prompt_response)
    if marker_found and error:
        stop_fields["marker_parse_error"] = error
    if passthrough:
        stop_fields.setdefault("summary", passthrough)
    elif prompt_response.strip():
        stop_fields.setdefault("summary", prompt_response.strip())
    return stop_fields, passthrough


def _strip_gemini_stop_markers(text: str) -> str:
    cleaned = text
    fenced_patterns = (
        r"```(?:stop-fields|stop_fields)\s*\{.*?\}\s*```",
        r"```json\s*\{.*?\"challenge_coverage\".*?\}\s*```",
    )
    for pattern in fenced_patterns:
        cleaned = re.sub(pattern, "", cleaned, flags=re.DOTALL | re.IGNORECASE)
    marker = "STOP_FIELDS_JSON:"
    marker_idx = cleaned.rfind(marker)
    if marker_idx != -1:
        cleaned = cleaned[:marker_idx]
    return cleaned.strip()


def _recover_partial_stop_fields(text: str) -> dict[str, Any]:
    recovered: dict[str, Any] = {}

    coverage: dict[str, bool] = {}
    for key in ("null_inputs", "boundary_values", "error_handling", "graveyard_regression"):
        match = re.search(rf'"{key}"\s*:\s*(true|false)', text, flags=re.IGNORECASE)
        if match:
            coverage[key] = match.group(1).lower() == "true"
    if coverage:
        recovered["challenge_coverage"] = coverage

    truth_claims: dict[str, list[str]] = {}
    for key in ("modified_files", "tests_ran"):
        values = _recover_string_list(text, key)
        if values:
            truth_claims[key] = values
    if truth_claims:
        recovered["truth_claims"] = truth_claims

    return recovered


def _recover_string_list(text: str, key: str) -> list[str]:
    match = re.search(rf'"{key}"\s*:\s*\[(.*?)\]', text, flags=re.DOTALL | re.IGNORECASE)
    if not match:
        return []
    values: list[str] = []
    seen: set[str] = set()
    for token in re.findall(r'"((?:\\.|[^"\\])*)"', match.group(1)):
        try:
            value = str(json.loads(f'"{token}"'))
        except json.JSONDecodeError:
            value = token
        cleaned = value.strip()
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        values.append(cleaned)
    return values


def _rewrite_legacy_trailer_markers(message: str) -> str:
    return (
        message.replace("CORTEX_STOP_JSON:", "STOP_FIELDS_JSON:")
        .replace("```cortex-stop", "```stop-fields")
        .replace("```cortex_stop", "```stop_fields")
    )
