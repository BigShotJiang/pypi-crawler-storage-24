from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

RETRYABLE_STATUSES: frozenset[str] = frozenset({"error", "failed", "fail"})
NON_RETRYABLE_REASONS: frozenset[str] = frozenset({"invariant_violation", "stop_gate_failure", "policy_violation", "challenge_failure", "permission_denied", "authentication_failure"})
CORRECTIVE_RETRYABLE: str = "corrective_retryable"
TERMINAL_HARD_GATE: str = "terminal_hard_gate"
_CORRECTIVE_CANONICAL: frozenset[str] = frozenset({"tool_error", "timeout", "shape_mismatch", "range_error", "format_error"})
_REASON_RETRY_LIMITS: Mapping[str, int] = {
    "timeout": 3,
    "tool_error": 3,
    "shape_mismatch": 2,
    "format_error": 2,
    "range_error": 1,
}
_DELTA_OBJECTIVE_KEYS: tuple[str, ...] = ("changed_files", "updated_files")
_DELTA_SENSITIVE_REASONS: frozenset[str] = frozenset({"shape_mismatch", "range_error", "format_error"})


@dataclass(slots=True)
class FailureVerdict:
    retryable: bool
    reason: str
    hard_stop: bool = False


@dataclass(slots=True)
class RetryVerdict:
    should_retry: bool
    hard_stop: bool
    failure_class: str
    reason: str
    budget_remaining: int
    budget_exhausted: bool
    decision_code: str
    failure_signature: str


def compute_retry_verdict(
    *,
    store: Any,
    session_id: str,
    payload: Mapping[str, Any],
    max_retries: int,
) -> RetryVerdict | None:
    failure = classify_failure(payload)
    if failure is None:
        return None
    reason = failure.reason
    reason_limit = reason_retry_limit(reason, default_limit=max_retries)
    attempts_state = store.get_retry_attempts(session_id, reason=reason)
    budget_state = _retry_budget_state(
        attempts=int(attempts_state["attempts"]),
        reason_attempts=int(attempts_state["reason_attempts"]),
        max_retries=max_retries,
        reason_limit=reason_limit,
    )
    signature = failure_signature(payload, reason=reason)
    delta_hash = objective_delta_hash(payload)
    delta_sensitive = reason in _DELTA_SENSITIVE_REASONS
    previous_delta_hash = (
        store.get_retry_delta_hash(session_id, reason, signature)
        if delta_sensitive
        else None
    )
    remaining_session = int(budget_state["remaining"])
    remaining_reason = int(budget_state["reason_remaining"])
    remaining = int(budget_state["budget_remaining"])
    terminal_code = (
        "hard_stop"
        if failure.hard_stop
        else "reason_budget_exhausted"
        if remaining_reason <= 0
        else "session_budget_exhausted"
        if remaining_session <= 0
        else ""
    )
    if terminal_code:
        return RetryVerdict(
            should_retry=False,
            hard_stop=terminal_code == "hard_stop",
            failure_class=TERMINAL_HARD_GATE if terminal_code == "hard_stop" else CORRECTIVE_RETRYABLE,
            reason=reason,
            budget_remaining=remaining,
            budget_exhausted=remaining == 0 or terminal_code != "hard_stop",
            decision_code=terminal_code,
            failure_signature=signature,
        )

    if delta_sensitive and previous_delta_hash is not None and not previous_delta_hash and not delta_hash:
        store.upsert_retry_delta_hash(
            session_id,
            reason=reason,
            failure_signature=signature,
            delta_hash=delta_hash,
        )
        return RetryVerdict(
            should_retry=False,
            hard_stop=False,
            failure_class=CORRECTIVE_RETRYABLE,
            reason=reason,
            budget_remaining=remaining,
            budget_exhausted=remaining == 0,
            decision_code="no_delta",
            failure_signature=signature,
        )

    outcome = _consume_retry_with_budget(
        store=store,
        session_id=session_id,
        reason=reason,
        max_retries=max_retries,
        reason_limit=reason_limit,
    )
    if delta_sensitive:
        store.upsert_retry_delta_hash(
            session_id,
            reason=reason,
            failure_signature=signature,
            delta_hash=delta_hash,
        )
    return RetryVerdict(
        should_retry=bool(outcome["consumed"]),
        hard_stop=False,
        failure_class=CORRECTIVE_RETRYABLE,
        reason=reason,
        budget_remaining=int(outcome["budget_remaining"]),
        budget_exhausted=bool(outcome["budget_exhausted"]),
        decision_code=str(outcome["decision_code"]),
        failure_signature=signature,
    )


def reason_retry_limit(reason: str, *, default_limit: int) -> int:
    return max(0, min(default_limit, int(_REASON_RETRY_LIMITS.get(reason, default_limit))))


def _retry_budget_state(
    *,
    attempts: int,
    reason_attempts: int,
    max_retries: int,
    reason_limit: int,
) -> dict[str, int | str]:
    session_limit = max(0, int(max_retries))
    reason_cap = max(0, int(reason_limit))
    session_attempts = max(0, int(attempts))
    reason_attempts = max(0, int(reason_attempts))
    remaining = max(0, session_limit - session_attempts)
    reason_remaining = max(0, reason_cap - reason_attempts)
    decision_code = "retry_allowed"
    if remaining <= 0:
        decision_code = "session_budget_exhausted"
    elif reason_remaining <= 0:
        decision_code = "reason_budget_exhausted"
    return {
        "attempts": session_attempts,
        "reason_attempts": reason_attempts,
        "remaining": remaining,
        "reason_remaining": reason_remaining,
        "budget_remaining": min(remaining, reason_remaining),
        "decision_code": decision_code,
    }


def _consume_retry_with_budget(
    *,
    store: Any,
    session_id: str,
    reason: str,
    max_retries: int,
    reason_limit: int,
) -> dict[str, int | bool | str]:
    for _ in range(16):
        attempts_state = store.get_retry_attempts(session_id, reason=reason)
        state = _retry_budget_state(
            attempts=int(attempts_state["attempts"]),
            reason_attempts=int(attempts_state["reason_attempts"]),
            max_retries=max_retries,
            reason_limit=reason_limit,
        )
        if state["decision_code"] != "retry_allowed":
            return {
                "consumed": False,
                "attempts": int(state["attempts"]),
                "reason_attempts": int(state["reason_attempts"]),
                "budget_remaining": int(state["budget_remaining"]),
                "decision_code": str(state["decision_code"]),
                "budget_exhausted": True,
            }

        write_outcome = store.try_increment_retry_attempts(
            session_id,
            reason=reason,
            expected_attempts=int(state["attempts"]),
            expected_reason_attempts=int(state["reason_attempts"]),
        )
        if bool(write_outcome["consumed"]):
            post = _retry_budget_state(
                attempts=int(write_outcome["attempts"]),
                reason_attempts=int(write_outcome["reason_attempts"]),
                max_retries=max_retries,
                reason_limit=reason_limit,
            )
            return {
                "consumed": True,
                "attempts": int(post["attempts"]),
                "reason_attempts": int(post["reason_attempts"]),
                "budget_remaining": int(post["budget_remaining"]),
                "decision_code": "retry_allowed",
                "budget_exhausted": int(post["budget_remaining"]) == 0,
            }

    final_attempts = store.get_retry_attempts(session_id, reason=reason)
    final_state = _retry_budget_state(
        attempts=int(final_attempts["attempts"]),
        reason_attempts=int(final_attempts["reason_attempts"]),
        max_retries=max_retries,
        reason_limit=reason_limit,
    )
    return {
        "consumed": False,
        "attempts": int(final_state["attempts"]),
        "reason_attempts": int(final_state["reason_attempts"]),
        "budget_remaining": int(final_state["budget_remaining"]),
        "decision_code": (
            str(final_state["decision_code"])
            if final_state["decision_code"] != "retry_allowed"
            else "retry_contention"
        ),
        "budget_exhausted": final_state["decision_code"] != "retry_allowed",
    }


def objective_delta_hash(payload: Mapping[str, Any]) -> str:
    files = _collect_objective_delta_files(payload)
    if not files:
        return ""
    return hashlib.sha256(
        json.dumps(files, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    ).hexdigest()


def failure_signature(payload: Mapping[str, Any], *, reason: str) -> str:
    canonical = {
        "reason": reason,
        "tool_name": _normalize_token(payload.get("tool_name")),
        "status": _normalize_token(payload.get("status")),
        "message": _normalize_token(payload.get("error") or payload.get("message") or payload.get("stderr"))[:240],
        "target_files": _normalize_files(payload.get("target_files")),
        "planned_files": _normalize_files(payload.get("planned_files")),
    }
    return hashlib.sha256(
        json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _canonical_reason(raw_reason: Any) -> str:
    token = re.sub(r"[^a-z0-9_]+", "_", re.sub(r"[\s\-]+", "_", str(raw_reason or "").lower().strip())).strip("_")
    if not token or token in _CORRECTIVE_CANONICAL:
        return token
    parts = set(token.split("_"))
    if {"shape", "mismatch"} <= parts:
        return "shape_mismatch"
    if {"range", "error"} <= parts:
        return "range_error"
    if {"format", "error"} <= parts:
        return "format_error"
    return "timeout" if "timeout" in parts else token


def classify_failure(payload: Mapping[str, Any]) -> FailureVerdict | None:
    if str(payload.get("status", "")).lower().strip() not in RETRYABLE_STATUSES:
        return None
    reason = _canonical_reason(payload.get("failure_reason") or payload.get("reason"))
    if reason in NON_RETRYABLE_REASONS:
        return FailureVerdict(retryable=False, reason=reason, hard_stop=True)
    if not reason:
        inferred = _canonical_reason(payload.get("error") or payload.get("message") or payload.get("stderr"))
        if inferred in _CORRECTIVE_CANONICAL:
            return FailureVerdict(retryable=True, reason=inferred)
        return FailureVerdict(retryable=True, reason="tool_error")
    if reason in _CORRECTIVE_CANONICAL:
        return FailureVerdict(retryable=True, reason=reason)
    return FailureVerdict(retryable=False, reason=reason, hard_stop=True)


def _normalize_token(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _normalize_files(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    tokens = [str(item).strip() for item in value]
    return sorted({token for token in tokens if token})


def _collect_objective_delta_files(payload: Mapping[str, Any]) -> list[str]:
    files: list[str] = []
    for key in _DELTA_OBJECTIVE_KEYS:
        value = payload.get(key)
        if not isinstance(value, list):
            continue
        files.extend(str(item).strip() for item in value)
    return sorted({token for token in files if token})
