from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .utils import _as_string_list


def build_stop_attempt_signature(
    *,
    challenge_coverage: Mapping[str, Any] | None,
    witness: Mapping[str, list[str]] | None,
    truth_claims_payload: Mapping[str, Any] | None,
    failed_approach: Mapping[str, Any] | None,
    observed_modified_files: list[str] | None,
) -> dict[str, Any]:
    challenge_shape: list[str] = []
    if isinstance(challenge_coverage, Mapping):
        for category in sorted(str(key).strip() for key in challenge_coverage.keys()):
            raw = challenge_coverage.get(category)
            if isinstance(raw, Mapping):
                challenge_shape.append(f"{category}:covered={bool(raw.get('covered', False))}")
            else:
                challenge_shape.append(f"{category}:covered={bool(raw)}")

    witnessed_commands = sorted(
        {
            normalize_stop_command_signal(command)
            for command in _as_string_list((witness or {}).get("commands"))
            if normalize_stop_command_signal(command)
        }
    )
    file_signal = sorted(
        {
            path
            for path in (
                _as_string_list((truth_claims_payload or {}).get("modified_files"))
                + _as_string_list((failed_approach or {}).get("files"))
                + _as_string_list(observed_modified_files)
            )
            if path
        }
    )
    return {
        "challenge_shape": challenge_shape,
        "witnessed_commands": witnessed_commands,
        "file_signal": file_signal,
    }


def stop_attempt_similarity(previous: Mapping[str, Any] | None, current: Mapping[str, Any]) -> float | None:
    if not isinstance(previous, Mapping):
        return None
    scores = [
        _signal_jaccard(previous.get("challenge_shape"), current.get("challenge_shape")),
        _signal_jaccard(previous.get("witnessed_commands"), current.get("witnessed_commands")),
        _signal_jaccard(previous.get("file_signal"), current.get("file_signal")),
    ]
    present_scores = [score for score in scores if score is not None]
    return round(sum(present_scores) / len(present_scores), 3) if present_scores else None


def normalize_stop_command_signal(command: str) -> str:
    return " ".join(str(command).strip().lower().split())


def _signal_jaccard(left: Any, right: Any) -> float | None:
    left_set = set(_as_string_list(left))
    right_set = set(_as_string_list(right))
    if not left_set and not right_set:
        return None
    union = left_set | right_set
    if not union:
        return None
    return len(left_set & right_set) / len(union)
