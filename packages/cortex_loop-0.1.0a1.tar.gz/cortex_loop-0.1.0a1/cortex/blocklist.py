from __future__ import annotations

from dataclasses import dataclass

DEFAULT_BLOCKED_TOOLS: frozenset[str] = frozenset({
    "vim",
    "nvim",
    "nano",
    "emacs",
    "vi",
    "python_repl",
    "ipython",
    "node_repl",
    "irb",
    "gdb",
    "lldb",
    "pdb",
    "less",
    "more",
    "man",
    "ssh",
    "docker_exec_interactive",
    "kubectl_exec",
})


@dataclass(slots=True)
class BlockVerdict:
    blocked: bool
    reason: str


def evaluate_blocklist(
    tool_name: object | None,
    *,
    enabled: bool = True,
    blocked_tools: frozenset[str] = DEFAULT_BLOCKED_TOOLS,
    allowed_tools: frozenset[str] = frozenset(),
    fail_closed: bool = False,
) -> BlockVerdict:
    if not enabled:
        return BlockVerdict(False, "blocklist_disabled")
    normalized = "" if tool_name is None else str(tool_name).strip().lower()
    normalized = normalized or "unknown"
    if normalized in allowed_tools:
        return BlockVerdict(False, "explicitly_allowed")
    if normalized in blocked_tools:
        return BlockVerdict(True, "tool_denied")
    if fail_closed and normalized not in allowed_tools:
        return BlockVerdict(True, "fail_closed")
    return BlockVerdict(False, "not_in_denylist")
