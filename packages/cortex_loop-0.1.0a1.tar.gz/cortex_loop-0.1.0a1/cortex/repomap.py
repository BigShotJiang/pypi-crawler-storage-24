import sys
from importlib import import_module
from types import ModuleType

_IMPL = import_module("cortex_repomap.engine")
sys.modules[__name__].__class__ = type("_ShimModule", (ModuleType,), {"__getattr__": lambda self, name: getattr(_IMPL, name), "__setattr__": lambda self, name, value: (setattr(_IMPL, name, value), ModuleType.__setattr__(self, name, value))[1]})
