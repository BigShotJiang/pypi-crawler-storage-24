from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .genome import ChallengesConfig
from .requirements import evaluate_evidence_reference
from .store import SQLiteStore
from .templates import BUILTIN_CHALLENGE_TEMPLATES
from .utils import _as_string_list


@dataclass(slots=True)
class ChallengeCoverage:
    category: str
    covered: bool
    evidence: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"category": self.category, "covered": self.covered, "evidence": self.evidence}


@dataclass(slots=True)
class ChallengeReport:
    active_categories: list[str]
    custom_paths: list[str]
    results: list[ChallengeCoverage]
    missing_categories: list[str]
    unverified_categories: list[str]
    uncheckable_categories: list[str]
    diagnostics: list[dict[str, Any]]
    config_warnings: list[str]
    ok: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            "active_categories": self.active_categories,
            "custom_paths": self.custom_paths,
            "results": [r.to_dict() for r in self.results],
            "missing_categories": self.missing_categories,
            "unverified_categories": self.unverified_categories,
            "uncheckable_categories": self.uncheckable_categories,
            "diagnostics": self.diagnostics,
            "config_warnings": self.config_warnings,
            "ok": self.ok,
        }


class ChallengeEnforcer:
    def __init__(self, store: SQLiteStore, config: ChallengesConfig) -> None:
        self.store = store
        self.config = config

    def evaluate(
        self,
        session_id: str,
        coverage_payload: Mapping[str, Any] | None = None,
        *,
        require_verifiable_coverage: bool = False,
        root: Path | None = None,
        witness: Mapping[str, list[str]] | None = None,
    ) -> ChallengeReport:
        coverage_payload = coverage_payload or {}
        results: list[ChallengeCoverage] = []
        missing: list[str] = []
        unverified: list[str] = []
        uncheckable: list[str] = []
        diagnostics: list[dict[str, Any]] = []
        config_warnings: list[str] = []
        resolved_root = root.resolve() if root is not None else None

        missing_builtin = [
            name for name in BUILTIN_CHALLENGE_TEMPLATES if name not in self.config.active_categories
        ]
        if missing_builtin:
            config_warnings.append(
                "Built-in challenge categories missing from active set: " + ", ".join(missing_builtin)
            )

        for category in self.config.active_categories:
            raw = coverage_payload.get(category)
            covered, evidence = self._coerce_coverage(raw)
            if require_verifiable_coverage and covered:
                verification = self._verify_covered_category(
                    evidence=evidence,
                    root=resolved_root,
                    witness=witness,
                )
                evidence["verification"] = verification
                verification_status = str(verification.get("status") or "")
                if verification_status != "verified":
                    covered = False
                    reason = str(verification.get("reason") or "missing verifiable evidence")
                    if verification_status == "uncheckable":
                        uncheckable.append(category)
                    else:
                        unverified.append(category)
                    config_warnings.append(
                        f"Challenge coverage '{category}' marked covered but evidence is {verification_status}: {reason}"
                    )
            if not covered:
                missing.append(category)
                diagnostics.append(
                    self._coverage_diagnostic(
                        category=category,
                        raw=raw,
                        evidence=evidence,
                        require_verifiable_coverage=require_verifiable_coverage,
                    )
                )
            result = ChallengeCoverage(category=category, covered=covered, evidence=evidence)
            results.append(result)
            self.store.record_challenge_result(session_id, category, covered, evidence)

        ok = not missing if self.config.require_coverage else True
        return ChallengeReport(
            active_categories=list(self.config.active_categories),
            custom_paths=list(self.config.custom_paths),
            results=results,
            missing_categories=missing,
            unverified_categories=sorted(set(unverified)),
            uncheckable_categories=sorted(set(uncheckable)),
            diagnostics=diagnostics,
            config_warnings=config_warnings,
            ok=ok,
        )

    def missing_coverage_diagnostics(self) -> list[dict[str, Any]]:
        return [
            {"evidence_found": [], "evidence_expected": [f"challenge_coverage for: {', '.join(self.config.active_categories)}"], "gap_description": "No challenge_coverage was provided for the stop attempt.", "gap_characterization": "comprehension_gap", "distance_signal": "far"}
        ]

    def invalid_coverage_diagnostics(self, raw: Any) -> list[dict[str, Any]]:
        return [
            {"evidence_found": [f"challenge_coverage={type(raw).__name__}"], "evidence_expected": ["challenge_coverage object keyed by active challenge categories"], "gap_description": "Challenge coverage used an invalid payload shape.", "gap_characterization": "comprehension_gap", "distance_signal": "far"}
        ]

    @staticmethod
    def _coerce_coverage(raw: Any) -> tuple[bool, dict[str, Any]]:
        if isinstance(raw, bool):
            return raw, {}
        if isinstance(raw, Mapping):
            covered = bool(raw.get("covered", False))
            evidence = {str(k): v for k, v in raw.items() if str(k) != "covered"}
            return covered, evidence
        if raw is None:
            return False, {}
        return bool(raw), {"raw": raw}

    @staticmethod
    def _verify_covered_category(
        *,
        evidence: Mapping[str, Any],
        root: Path | None,
        witness: Mapping[str, list[str]] | None,
    ) -> dict[str, Any]:
        if root is None:
            return {
                "status": "uncheckable",
                "reason": "verification root unavailable",
                "checked_references": [],
            }

        references = _as_string_list(evidence.get("evidence"))
        if not references:
            return {
                "status": "unverified",
                "reason": "covered=true requires non-empty evidence list",
                "checked_references": [],
            }

        checks = [evaluate_evidence_reference(ref, root=root, witness=witness) for ref in references]
        if any(check.get("status") == "verified" for check in checks):
            return {
                "status": "verified",
                "reason": "",
                "checked_references": checks,
            }
        if any(check.get("status") == "uncheckable" for check in checks):
            return {
                "status": "uncheckable",
                "reason": "no verifiable evidence reference was checkable",
                "checked_references": checks,
            }
        return {
            "status": "unverified",
            "reason": "no evidence reference was verified",
            "checked_references": checks,
        }

    @staticmethod
    def _coverage_diagnostic(
        *,
        category: str,
        raw: Any,
        evidence: Mapping[str, Any],
        require_verifiable_coverage: bool,
    ) -> dict[str, Any]:
        verification = evidence.get("verification") if isinstance(evidence, Mapping) else None
        if raw is None:
            return {"evidence_found": [], "evidence_expected": [f"challenge_coverage.{category}=true"], "gap_description": f"Challenge category '{category}' was not addressed in stop coverage.", "gap_characterization": "comprehension_gap", "distance_signal": "far"}

        evidence_refs = _as_string_list(evidence.get("evidence")) if isinstance(evidence, Mapping) else []
        if require_verifiable_coverage and isinstance(verification, Mapping):
            status = str(verification.get("status") or "unverified")
            return {"evidence_found": evidence_refs or [f"verification_status={status}"], "evidence_expected": [f"verifiable evidence for challenge '{category}'"], "gap_description": f"Challenge category '{category}' was claimed but not verifiably supported.", "gap_characterization": "execution_gap", "distance_signal": "moderate" if evidence_refs else "far"}

        return {"evidence_found": ["covered=false"], "evidence_expected": [f"challenge_coverage.{category}=true"], "gap_description": f"Challenge category '{category}' remains uncovered.", "gap_characterization": "comprehension_gap", "distance_signal": "moderate"}
