from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

PACK_SCHEMA_VERSION = "cortex_pack_v1"


@dataclass(slots=True)
class PackOverlay:
    challenge_categories: list[str] = field(default_factory=list)
    invariant_paths: list[str] = field(default_factory=list)
    blocked_tools: list[str] = field(default_factory=list)
    allowed_tools: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def load_pack_overlay(*, root: Path, pack_paths: list[str]) -> PackOverlay:
    overlay = PackOverlay()
    for raw_path in pack_paths:
        declared_path = str(raw_path).strip()
        if not declared_path:
            continue
        manifest_path = (
            Path(declared_path).expanduser()
            if Path(declared_path).is_absolute()
            else (root / declared_path).expanduser()
        ).resolve()
        if not manifest_path.exists():
            overlay.warnings.append(f"Pack manifest not found: {declared_path}")
            continue
        try:
            with manifest_path.open("rb") as fh:
                payload = tomllib.load(fh)
        except Exception as exc:  # noqa: BLE001
            overlay.warnings.append(f"Pack manifest parse error in {manifest_path}: {exc}")
            continue
        if not isinstance(payload, dict):
            overlay.warnings.append(f"Pack manifest must be a TOML table: {manifest_path}")
            continue

        schema = str(payload.get("schema") or "").strip()
        if schema != PACK_SCHEMA_VERSION:
            overlay.warnings.append(
                f"Unsupported pack schema in {manifest_path}: {schema or 'missing'} "
                f"(expected {PACK_SCHEMA_VERSION})"
            )
            continue

        pack_id = str(payload.get("pack_id") or manifest_path.stem).strip() or manifest_path.stem
        categories = _as_str_list(payload.get("challenge_categories"))
        invariants = _as_str_list(payload.get("invariant_paths"))
        blocked_tools = _as_str_list(payload.get("blocked_tools"))
        allowed_tools = _as_str_list(payload.get("allowed_tools"))
        if not (categories or invariants or blocked_tools or allowed_tools):
            overlay.warnings.append(f"Pack '{pack_id}' declares no challenges/invariants/blocklist entries.")
            continue

        overlay.challenge_categories.extend(categories)
        overlay.invariant_paths.extend(
            _resolve_invariant_paths(
                repo_root=root,
                manifest_dir=manifest_path.parent,
                invariant_paths=invariants,
            )
        )
        overlay.blocked_tools.extend(blocked_tools)
        overlay.allowed_tools.extend(allowed_tools)

    overlay.challenge_categories = _unique_nonempty(overlay.challenge_categories)
    overlay.invariant_paths = _unique_nonempty(overlay.invariant_paths)
    overlay.blocked_tools = _unique_nonempty(overlay.blocked_tools)
    overlay.allowed_tools = _unique_nonempty(overlay.allowed_tools)
    overlay.warnings = _unique_nonempty(overlay.warnings)
    return overlay


def _resolve_invariant_paths(
    *,
    repo_root: Path,
    manifest_dir: Path,
    invariant_paths: list[str],
) -> list[str]:
    resolved: list[str] = []
    for value in invariant_paths:
        path = Path(value)
        if path.is_absolute():
            candidate = path.resolve()
        else:
            # Prefer repo-root-relative paths so pack manifests can be dropped into a project
            # without requiring path rewrites for test suites that already use repo-relative layout.
            root_candidate = (repo_root / path).resolve()
            manifest_candidate = (manifest_dir / path).resolve()
            candidate = root_candidate if (root_candidate.exists() or not manifest_candidate.exists()) else manifest_candidate
        try:
            candidate = candidate.relative_to(repo_root)
        except ValueError:
            pass
        resolved.append(candidate.as_posix() if isinstance(candidate, Path) else str(candidate))
    return resolved


def _as_str_list(value: Any) -> list[str]:
    return [str(v).strip() for v in value] if isinstance(value, list) else []


def _unique_nonempty(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in values:
        token = str(item).strip()
        if not token or token in seen:
            continue
        seen.add(token)
        result.append(token)
    return result
