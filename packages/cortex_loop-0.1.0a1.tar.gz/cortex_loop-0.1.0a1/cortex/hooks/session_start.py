from __future__ import annotations

import sys

from ._shared import run_hook


def main(argv: list[str] | None = None) -> int:
    return run_hook(hook_name="SessionStart", event_name="session_start", argv=argv)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
