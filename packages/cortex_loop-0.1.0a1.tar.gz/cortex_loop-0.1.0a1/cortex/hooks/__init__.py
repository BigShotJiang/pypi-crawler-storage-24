"""Runtime hook entrypoints for Cortex."""

from __future__ import annotations

from pathlib import Path

from cortex.core import CortexKernel


def marker(
    label: str,
    *,
    session_id: str,
    root: str | Path = ".",
    config_path: str | Path | None = None,
) -> dict[str, object]:
    token = str(label).strip()
    if not token:
        raise ValueError("marker() requires a non-empty label.")
    session_token = str(session_id or "").strip()
    if not session_token:
        raise ValueError("marker() requires session_id. Use marker(label, session_id='sess-...').")
    payload: dict[str, object] = {"label": token, "session_id": session_token}
    return CortexKernel(root=root, config_path=config_path).dispatch("session_marker", payload)


__all__ = ["marker"]
