from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from cortex.core import CortexKernel

HOOK_SCHEMA_NATIVE = "native_hook_v1"
HOOK_SCHEMA_LEGACY = "legacy_json_v0"
_NATIVE_ALIAS = "".join(["cl", "aude_native_v1"])
_STOP_PRIORITY_PREFIXES = (
    "Structured stop payload is required",
    "Strict mode rejects Stop message-fallback payloads",
    "Truth claims reported gaps:",
    "Requirement audit reported gaps:",
    "Missing challenge coverage for categories:",
    "Challenge coverage '",
    "Stop attempt is highly similar to the previous failed Stop;",
)
_STOP_IGNORED_PREFIXES = ("Using ", "Truth claims note:", "Requirement audit note:")


def run_hook(
    *,
    hook_name: str,
    event_name: str,
    argv: list[str] | None = None,
) -> int:
    args = _parse_args(argv)
    try:
        if args.adapter is not None:
            raise ValueError(
                "--adapter is no longer supported. Configure [runtime].adapter in cortex.toml."
            )
        payload = _read_stdin_json()
        kernel = CortexKernel(root=args.root, config_path=args.config)
        result = kernel.dispatch(event_name, payload)
        print(json.dumps(_format_hook_output(hook_name=hook_name, result=result, schema_version=args.schema_version)))
        return 0
    except Exception as exc:  # noqa: BLE001
        print(json.dumps(_format_hook_error(hook_name=hook_name, error=str(exc), schema_version=args.schema_version)))
        return 1


def _read_stdin_json() -> dict[str, object]:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("Hook payload must be a JSON object")
    return data


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--root", default=".")
    parser.add_argument("--config")
    parser.add_argument("--adapter")
    parser.add_argument("--schema-version", default=HOOK_SCHEMA_LEGACY)
    args = parser.parse_args([] if argv is None else argv)
    args.schema_version = _normalize_schema_version(str(args.schema_version))
    return args


def _normalize_schema_version(raw: str) -> str:
    schema_version = str(raw or "").strip()
    if schema_version in {HOOK_SCHEMA_NATIVE, _NATIVE_ALIAS}:
        return HOOK_SCHEMA_NATIVE
    if schema_version == HOOK_SCHEMA_LEGACY:
        return HOOK_SCHEMA_LEGACY
    raise ValueError(
        "Unsupported --schema-version. Use one of: "
        f"{HOOK_SCHEMA_NATIVE}, {_NATIVE_ALIAS}, {HOOK_SCHEMA_LEGACY}"
    )


def _format_hook_output(*, hook_name: str, result: dict[str, Any], schema_version: str) -> dict[str, Any]:
    if schema_version == HOOK_SCHEMA_LEGACY:
        return result
    if hook_name == "PreToolUse":
        proceed = bool(result.get("proceed", True))
        decision = "allow" if proceed else "deny"
        output: dict[str, Any] = {
            "permissionDecision": decision,
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": decision,
            },
        }
        if not proceed:
            output["hookSpecificOutput"]["permissionDecisionReason"] = _primary_reason(hook_name, result)
        return output
    if hook_name in {"PostToolUse", "Stop"}:
        if hook_name == "Stop" and _is_stuck_result(result):
            return {"continue": False, "stopReason": _primary_reason(hook_name, result)}
        if bool(result.get("proceed", True)):
            return {}
        return {"decision": "block", "reason": _primary_reason(hook_name, result)}
    return result


def _format_hook_error(*, hook_name: str, error: str, schema_version: str) -> dict[str, Any]:
    if schema_version == HOOK_SCHEMA_LEGACY:
        return {"ok": False, "hook": hook_name, "error": error}
    if hook_name == "PreToolUse":
        return {
            "permissionDecision": "deny",
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": error,
            }
        }
    if hook_name in {"PostToolUse", "Stop"}:
        return {"decision": "block", "reason": error}
    return {"decision": "block", "reason": error}


def _primary_reason(hook_name: str, result: dict[str, Any]) -> str:
    if _is_stuck_result(result):
        return _stuck_reason(result)
    if hook_name == "Stop":
        stop_reason = _stop_reason(result)
        if stop_reason:
            return stop_reason
    warning = next((item for item in _warning_strings(result) if item), "")
    if warning:
        return warning
    if hook_name == "Stop":
        return "Cortex stop path blocked completion."
    if hook_name == "PostToolUse":
        return "Cortex post-tool gate blocked continuation."
    return "Cortex denied tool execution."


def _stop_reason(result: dict[str, Any]) -> str | None:
    warnings = _warning_strings(result)
    warning = next((item for item in warnings if item.startswith(_STOP_PRIORITY_PREFIXES)), None)
    if warning:
        return warning
    return next((item for item in warnings if not item.startswith(_STOP_IGNORED_PREFIXES)), None)


def _is_stuck_result(result: dict[str, Any]) -> bool:
    return bool(result.get("stuck_declared")) or str(result.get("feedback_mode") or "") == "stuck"


def _warning_strings(result: dict[str, Any]) -> list[str]:
    warnings = result.get("warnings")
    if not isinstance(warnings, list):
        return []
    return [str(raw_warning or "").strip() for raw_warning in warnings if str(raw_warning or "").strip()]


def _stuck_reason(result: dict[str, Any]) -> str:
    stuck = result.get("stuck_declaration")
    if isinstance(stuck, dict):
        check = str(stuck.get("check") or "").strip()
        obstacle = str(stuck.get("obstacle") or "").strip()
        if check and obstacle:
            return f"Cortex reported stuck on {check}: {obstacle}"
        if obstacle:
            return f"Cortex reported stuck: {obstacle}"
    return "Cortex reported stuck and could not complete the requested evidence boundary."
