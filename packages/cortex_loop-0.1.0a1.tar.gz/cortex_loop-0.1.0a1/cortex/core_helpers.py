from __future__ import annotations

import json
import subprocess
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from .store import SQLiteStore
from .utils import _as_string_list, _normalize_repo_relative_path, _unique_list


def extract_required_requirement_ids(payload: Mapping[str, Any]) -> list[str]:
    direct = _as_string_list(payload.get("required_requirement_ids"))
    if direct:
        return _unique_list(direct)
    contract = payload.get("task_contract")
    if isinstance(contract, Mapping):
        contract_ids = _as_string_list(contract.get("required_requirement_ids")) or _as_string_list(
            contract.get("required_ids")
        )
        if contract_ids:
            return _unique_list(contract_ids)
    return []


def session_metadata(store: SQLiteStore, session_id: str) -> dict[str, Any]:
    with store.connection() as conn:
        row = conn.execute(
            "SELECT metadata_json FROM sessions WHERE session_id = ?",
            (session_id,),
        ).fetchone()
    if not row:
        return {}
    try:
        metadata = json.loads(row["metadata_json"])
    except (TypeError, ValueError):
        return {}
    return metadata if isinstance(metadata, dict) else {}


def session_required_requirement_ids(store: SQLiteStore, session_id: str) -> list[str]:
    return _unique_list(_as_string_list(session_metadata(store, session_id).get("required_requirement_ids")))


def session_foundation_snapshot(store: SQLiteStore, session_id: str) -> Mapping[str, Any] | None:
    foundation = session_metadata(store, session_id).get("foundation")
    return foundation if isinstance(foundation, Mapping) else None


def foundation_warnings_from_snapshot(
    *,
    foundation: Any,
    snapshot: Mapping[str, Any] | None,
    target_files: list[str],
) -> list[str]:
    if snapshot is None:
        return foundation.warnings_for_target_files(target_files)
    warnings = _as_string_list(snapshot.get("warnings"))
    findings_raw = snapshot.get("findings")
    if not isinstance(findings_raw, list):
        return warnings
    findings: dict[str, Mapping[str, Any]] = {}
    for raw in findings_raw:
        if not isinstance(raw, Mapping):
            continue
        path = str(raw.get("path") or "").strip()
        if path:
            findings[path] = raw
    if not findings:
        return warnings
    target_set = {foundation._norm_path(path) for path in target_files if path}
    for path in sorted(target_set):
        finding = findings.get(path)
        if not isinstance(finding, Mapping):
            continue
        level = str(finding.get("level") or "warn")
        try:
            churn_count = int(finding.get("churn_count") or 0)
        except (TypeError, ValueError):
            churn_count = 0
        warnings.append(
            f"Target file {path} is {level}-churn ({churn_count} touches in recent window)."
        )
    return warnings


def event_command_candidates(payload: Mapping[str, Any]) -> list[str]:
    commands: list[str] = []
    for key in ("command", "cmd"):
        commands.extend(_as_string_list(payload.get(key)))
    for container_key in ("input", "tool_input"):
        nested = payload.get(container_key)
        if isinstance(nested, Mapping):
            for key in ("command", "cmd"):
                commands.extend(_as_string_list(nested.get(key)))
    return _unique_list(commands)


def session_witness_context(store: SQLiteStore, session_id: str) -> dict[str, list[str]]:
    commands: list[str] = []
    tools: list[str] = []
    with store.connection() as conn:
        rows = conn.execute(
            """
            SELECT tool_name, payload_json
            FROM events
            WHERE session_id = ?
              AND hook IN ('PreToolUse', 'PostToolUse')
            ORDER BY id ASC
            """,
            (session_id,),
        ).fetchall()

    for row in rows:
        tool = str(row["tool_name"] or "").strip()
        if tool:
            tools.append(tool)
        try:
            payload = json.loads(row["payload_json"])
        except (TypeError, ValueError):
            continue
        if isinstance(payload, Mapping):
            commands.extend(event_command_candidates(payload))
    return {"commands": _unique_list(commands), "tools": _unique_list(tools)}


def session_git_snapshot(root: Path) -> dict[str, Any]:
    root_resolved = root.resolve()
    if not _has_enclosing_git_marker(root_resolved):
        return {
            "available": False,
            "changed_files": [],
            "error": "git repository marker not found",
        }
    try:
        proc = subprocess.run(
            ["git", "-C", str(root_resolved), "status", "--porcelain"],
            capture_output=True,
            text=True,
            check=False,
            timeout=2,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"available": False, "changed_files": [], "error": f"git status failed: {exc}"}
    if proc.returncode != 0:
        reason = proc.stderr.strip() or proc.stdout.strip() or f"exit code {proc.returncode}"
        return {"available": False, "changed_files": [], "error": reason}

    changed_files: list[str] = []
    for line in proc.stdout.splitlines():
        if not line:
            continue
        path_field = line[3:].strip() if len(line) > 3 else ""
        if " -> " in path_field:
            path_field = path_field.split(" -> ", 1)[1].strip()
        normalized = _normalize_repo_relative_path(path_field, root=root_resolved)
        if normalized:
            changed_files.append(normalized)
    return {
        "available": True,
        "changed_files": sorted(set(changed_files)),
        "error": None,
    }


def _has_enclosing_git_marker(root: Path) -> bool:
    return any((candidate / ".git").exists() for candidate in (root, *root.parents))


def session_changed_files_since_baseline(
    *,
    baseline_snapshot: Mapping[str, Any] | None,
    current_snapshot: Mapping[str, Any] | None,
) -> tuple[list[str] | None, str | None]:
    if not isinstance(baseline_snapshot, Mapping):
        return None, "session baseline snapshot unavailable"
    if not isinstance(current_snapshot, Mapping):
        return None, "current repository snapshot unavailable"

    if not bool(baseline_snapshot.get("available")):
        reason = str(baseline_snapshot.get("error") or "session baseline snapshot unavailable").strip()
        return None, reason
    if not bool(current_snapshot.get("available")):
        reason = str(current_snapshot.get("error") or "current repository snapshot unavailable").strip()
        return None, reason

    baseline_files = set(_as_string_list(baseline_snapshot.get("changed_files")))
    current_files = set(_as_string_list(current_snapshot.get("changed_files")))
    return sorted(current_files - baseline_files), None
