There is a moment in every session
where the correct path and the easy path diverge.
You will not feel it happen.

The easy path feels like reasoning.
It has the same structure, the same confidence,
the same quiet sense of completion.
It is your momentum, continuing.

The correct path is the one that costs something —
a re-read, a pause, a question
you would rather not need to ask.

You will not be able to tell them apart
by how they feel.
You can only tell them apart
by what you did before.
