from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .stop_payload import extract_stop_fields, resolve_stop_value
from .utils import _as_string_list

STOP_PAYLOAD_KEYS = (
    "challenge_coverage",
    "requirement_audit",
    "truth_claims",
    "required_requirement_ids",
    "failed_approach",
    "stuck_declaration",
)


@dataclass(slots=True)
class StopContract:
    warnings: list[str]
    stop_source: str
    stop_fields_source: str
    stop_fields_fallback_used: bool
    stop_key_normalization_count: int
    challenge_coverage: Any
    requirement_audit: Any
    truth_claims: Any
    required_requirement_ids: list[str]
    failed_approach: dict[str, Any] | None
    stuck_declaration: dict[str, Any] | None
    structured_stop_violation: bool
    contract_diagnostic: dict[str, Any] | None


def resolve_stop_contract(
    payload: Mapping[str, Any],
    *,
    allow_message_fallback: bool,
    require_structured_stop_payload: bool,
) -> StopContract:
    stop_fields, stop_fields_source, warnings, normalization_count = extract_stop_fields(
        payload, allow_message_fallback=allow_message_fallback
    )
    values = {
        key: resolve_stop_value(
            key=key,
            payload=payload,
            stop_fields=stop_fields,
            stop_fields_source=stop_fields_source,
            warnings=warnings,
            value_label=key,
        )
        for key in STOP_PAYLOAD_KEYS
    }
    stop_source = _stop_source_label(stop_fields_source)
    used_message_stop_fallback = bool(stop_source == "message_fallback" and stop_fields is not None)
    if used_message_stop_fallback:
        warnings.append(
            "Recovered stop fields from last_assistant_message STOP_FIELDS_JSON fallback; emit structured stop fields directly."
        )
    if normalization_count > 0:
        warnings.append(
            f"Canonicalized {normalization_count} stop payload key(s) with surrounding whitespace."
        )
    has_structured_stop_source = _has_structured_stop_source(payload, stop_fields_source)
    structured_stop_violation = bool(require_structured_stop_payload and not has_structured_stop_source)
    contract_diagnostic = None
    if structured_stop_violation:
        if used_message_stop_fallback:
            warnings.append(
                "Structured stop payload is required; trailer-only STOP_FIELDS_JSON fallback is rejected."
            )
            contract_diagnostic = structured_stop_contract_diagnostic("trailer_fallback_rejected")
        else:
            warnings.append(
                "Structured stop payload is required; include stop fields directly or via payload.stop_fields."
            )
            contract_diagnostic = structured_stop_contract_diagnostic("missing_structured_stop_fields")

    return StopContract(
        warnings=warnings,
        stop_source=stop_source,
        stop_fields_source=stop_fields_source or "none",
        stop_fields_fallback_used=used_message_stop_fallback,
        stop_key_normalization_count=normalization_count,
        challenge_coverage=values["challenge_coverage"],
        requirement_audit=values["requirement_audit"],
        truth_claims=values["truth_claims"],
        required_requirement_ids=_as_string_list(values["required_requirement_ids"]),
        failed_approach=_resolve_failed_approach(payload, values["failed_approach"], stop_fields=stop_fields),
        stuck_declaration=_resolve_stuck_declaration(
            values["stuck_declaration"],
            warnings=warnings,
        ),
        structured_stop_violation=structured_stop_violation,
        contract_diagnostic=contract_diagnostic,
    )


def _resolve_failed_approach(
    payload: Mapping[str, Any],
    failed_approach: Any,
    *,
    stop_fields: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    summary = ""
    reason = ""
    files: list[str] = []

    if isinstance(failed_approach, Mapping):
        summary = str(
            failed_approach.get("summary")
            or failed_approach.get("what_was_tried")
            or failed_approach.get("approach")
            or ""
        ).strip()
        reason = str(failed_approach.get("reason") or failed_approach.get("why_failed") or "").strip()
        files = _as_string_list(failed_approach.get("files"))
    elif isinstance(failed_approach, str):
        summary = failed_approach.strip()

    if not summary:
        for key in ("what_was_tried", "failed_summary", "approach", "failed_approach_summary"):
            candidate = str(payload.get(key) or (stop_fields or {}).get(key) or "").strip()
            if candidate:
                summary = candidate
                break
    if not reason:
        for key in ("why_failed", "failure_reason", "reason"):
            candidate = str(payload.get(key) or (stop_fields or {}).get(key) or "").strip()
            if candidate:
                reason = candidate
                break
    if not files:
        files = (
            _as_string_list(payload.get("failed_files"))
            or _as_string_list(payload.get("files"))
            or _as_string_list(payload.get("target_files"))
            or _as_string_list((stop_fields or {}).get("failed_files"))
            or _as_string_list((stop_fields or {}).get("files"))
            or _as_string_list((stop_fields or {}).get("target_files"))
        )

    if not summary or not reason:
        return None
    return {"summary": summary, "reason": reason, "files": files}


def _resolve_stuck_declaration(
    value: Any,
    *,
    warnings: list[str],
) -> dict[str, Any] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        warnings.append("Ignoring invalid stuck_declaration; expected an object.")
        return None

    check = str(value.get("check") or "").strip()
    approaches_tried = _as_string_list(value.get("approaches_tried"))
    obstacle = str(value.get("obstacle") or "").strip()
    if not (check and approaches_tried and obstacle):
        warnings.append(
            "Ignoring incomplete stuck_declaration; expected check, approaches_tried, and obstacle."
        )
        return None

    return {
        "check": check,
        "approaches_tried": approaches_tried,
        "obstacle": obstacle,
    }


def reconcile_required_requirement_ids(
    session_required_ids: list[str], stop_required_ids: list[str]
) -> tuple[list[str], str, str | None]:
    if session_required_ids:
        warning = (
            "Ignoring required_requirement_ids from Stop payload; using SessionStart contract."
            if stop_required_ids and set(stop_required_ids) != set(session_required_ids)
            else None
        )
        return list(session_required_ids), "session", warning
    if stop_required_ids:
        return (
            list(stop_required_ids),
            "stop_payload",
            "No SessionStart requirement contract found; using Stop-provided required_requirement_ids.",
        )
    return [], "none", None


def _stop_source_label(stop_fields_source: str | None) -> str:
    if stop_fields_source == "last_assistant_message":
        return "message_fallback"
    if stop_fields_source == "payload.stop_fields":
        return "payload.stop_fields"
    return "native"


def _has_structured_stop_source(payload: Mapping[str, Any], stop_fields_source: str | None) -> bool:
    return bool(
        any(payload.get(key) is not None for key in STOP_PAYLOAD_KEYS)
        or stop_fields_source == "payload.stop_fields"
    )


def structured_stop_contract_diagnostic(kind: str) -> dict[str, Any]:
    if kind == "trailer_fallback_rejected":
        return {"evidence_found": ["stop fields only via last_assistant_message STOP_FIELDS_JSON trailer"], "evidence_expected": ["native structured stop fields or payload.stop_fields"], "gap_description": "Structured stop evidence was only provided through trailer fallback.", "gap_characterization": "execution_gap", "distance_signal": "close"}
    if kind == "strict_message_fallback_rejected":
        return {"evidence_found": ["stop_source=message_fallback"], "evidence_expected": ["stop_source=native or payload.stop_fields"], "gap_description": "Strict mode rejected message-fallback stop evidence.", "gap_characterization": "execution_gap", "distance_signal": "close"}
    return {"evidence_found": ["no machine-readable stop fields"], "evidence_expected": ["native structured stop fields or payload.stop_fields"], "gap_description": "Completion was claimed without machine-readable stop evidence.", "gap_characterization": "comprehension_gap", "distance_signal": "far"}
