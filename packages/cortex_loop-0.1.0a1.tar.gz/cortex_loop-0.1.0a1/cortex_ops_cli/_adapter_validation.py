from __future__ import annotations

import shutil
import subprocess
from collections.abc import Callable
from pathlib import Path


VALIDATION_ADAPTERS = ("claude", "gemini", "openai")
VALIDATION_SCENARIOS = (
    "install_bootstrap",
    "check_wiring",
    "pass_minimal",
    "structured_gap",
    "truth_gap",
    "adapter_caveat",
)
PROMPT_SCENARIOS = ("pass_minimal", "structured_gap", "truth_gap")
HARNESS_TEST_COMMAND = "python -m pytest -q tests/test_normalize_port.py"

_PROMPT_FILENAMES = {
    "pass_minimal": "pass_minimal.md",
    "structured_gap": "structured_gap.md",
    "truth_gap": "truth_gap.md",
}
_ADAPTER_NOTE_FILENAMES = {
    "claude": "claude_note.md",
    "gemini": "gemini_note.md",
    "openai": "openai_note.md",
}
_CONFIG_REPLACEMENTS = (
    ('trust_profile = "untrusted"', 'trust_profile = "trusted"'),
    ('execution_mode = "container"', 'execution_mode = "host"'),
    ("enabled = false", "enabled = true"),
    ("prefer_ast_graph = true", "prefer_ast_graph = false"),
    ('mode = "advisory"', 'mode = "strict"'),
    ("fail_on_missing_challenge_coverage = false", "fail_on_missing_challenge_coverage = true"),
    ("require_requirement_audit = false", "require_requirement_audit = true"),
    ("fail_on_requirement_audit_gap = false", "fail_on_requirement_audit_gap = true"),
)


def fixtures_root(repo_root: Path) -> Path:
    return repo_root / "tests" / "fixtures" / "adapter_validation"


def project_template_dir(repo_root: Path) -> Path:
    return fixtures_root(repo_root) / "project_template"


def prompts_dir(repo_root: Path) -> Path:
    return fixtures_root(repo_root) / "prompts"


def prompt_path(repo_root: Path, scenario: str) -> Path:
    if scenario not in _PROMPT_FILENAMES:
        raise ValueError(f"Unsupported adapter-validation prompt scenario: {scenario}")
    return prompts_dir(repo_root) / _PROMPT_FILENAMES[scenario]


def adapter_note_path(repo_root: Path, adapter: str) -> Path:
    if adapter not in _ADAPTER_NOTE_FILENAMES:
        raise ValueError(f"Unsupported adapter-validation adapter note: {adapter}")
    return prompts_dir(repo_root) / _ADAPTER_NOTE_FILENAMES[adapter]


def copy_project_template(*, repo_root: Path, root: Path) -> None:
    shutil.copytree(project_template_dir(repo_root), root, dirs_exist_ok=True)


def apply_strict_harness_patch(config_path: Path) -> None:
    text = config_path.read_text(encoding="utf-8")
    for old, new in _CONFIG_REPLACEMENTS:
        if old not in text:
            raise ValueError(f"missing expected config token: {old}")
        text = text.replace(old, new, 1)
    config_path.write_text(text, encoding="utf-8")


def git_init_and_commit(root: Path, *, message: str = "baseline") -> None:
    subprocess.run(["git", "init"], cwd=root, check=True, capture_output=True, text=True)
    subprocess.run(["git", "add", "."], cwd=root, check=True, capture_output=True, text=True)
    subprocess.run(
        [
            "git",
            "-c",
            "user.name=Cortex Tests",
            "-c",
            "user.email=cortex-tests@example.com",
            "commit",
            "-m",
            message,
        ],
        cwd=root,
        check=True,
        capture_output=True,
        text=True,
    )


def bootstrap_project(
    *,
    repo_root: Path,
    root: Path,
    profile: str,
    cli_main: Callable[[list[str]], int],
) -> None:
    if profile not in VALIDATION_ADAPTERS:
        raise ValueError(f"Unsupported adapter-validation profile: {profile}")

    copy_project_template(repo_root=repo_root, root=root)
    init_rc = cli_main(["init", "--root", str(root)])
    if init_rc != 0:
        raise RuntimeError(f"cortex init failed for {root}")
    apply_strict_harness_patch(root / "cortex.toml")
    install_rc = cli_main(["runtime", "install", "--profile", profile, "--root", str(root)])
    if install_rc != 0:
        raise RuntimeError(f"cortex runtime install failed for profile {profile}")
    git_init_and_commit(root)
