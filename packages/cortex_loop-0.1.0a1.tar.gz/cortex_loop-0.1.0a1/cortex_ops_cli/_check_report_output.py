from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any

STOP_PATH_MODULE_FILES = (
    "core.py",
    "stop_contract.py",
    "stop_runtime.py",
    "stop_signals.py",
    "challenges.py",
    "requirements.py",
    "invariants.py",
    "graveyard.py",
    "stop_policy.py",
    "store.py",
)


def build_kernel_metrics_payload(
    *,
    include: bool,
    root: Path,
    baseline_path: str | None,
    write_baseline_path: str | None,
    warnings: list[str],
) -> dict[str, Any] | None:
    if not include:
        return None
    current_metrics = _collect_kernel_metrics()
    payload: dict[str, Any] = {"gating": "non_blocking", "current": current_metrics}
    payload.update(
        {
            key: current_metrics[key]
            for key in ("scope", "kernel_dir", "modules", "totals", "trend_target")
            if key in current_metrics
        }
    )

    if write_baseline_path:
        baseline_write_path = Path(write_baseline_path).resolve()
        try:
            payload["baseline_written"] = _write_kernel_metrics_baseline(
                baseline_write_path,
                current_metrics,
                root=root,
            )
        except OSError as exc:
            warnings.append(
                f"Kernel metrics baseline write failed for {baseline_write_path}: {exc}"
            )
    if baseline_path:
        baseline_metrics_path = Path(baseline_path).resolve()
        baseline_metrics, baseline_error = _read_kernel_metrics_baseline(baseline_metrics_path)
        if baseline_error:
            warnings.append(
                f"Kernel metrics baseline read failed for {baseline_metrics_path}: {baseline_error}"
            )
        elif baseline_metrics is not None:
            payload["baseline"] = baseline_metrics
            payload["diff"] = _diff_kernel_metrics(
                current=current_metrics,
                baseline=baseline_metrics,
            )
    return payload


def print_check_report(report: dict[str, Any]) -> None:
    print(f"Cortex Check: {report['root']}")
    _print_check_section("OK", report["ok"])
    _print_check_section("Needs Attention", report["warnings"])
    _print_check_section("Missing / Errors", report["errors"])
    kernel_metrics = report.get("kernel_metrics")
    if isinstance(kernel_metrics, dict):
        current = (
            kernel_metrics.get("current")
            if isinstance(kernel_metrics.get("current"), dict)
            else kernel_metrics
        )
        totals = current.get("totals") if isinstance(current.get("totals"), dict) else {}
        items = [
            "non-blocking informational output",
            f"stop_path_loc_total={int(totals.get('loc_total', 0))}",
            f"stop_path_loc_code={int(totals.get('loc_code', 0))}",
            f"stop_path_function_total={int(totals.get('functions', 0))}",
            f"stop_path_decision_points={int(totals.get('decision_points', 0))}",
        ]
        diff = kernel_metrics.get("diff") if isinstance(kernel_metrics.get("diff"), dict) else None
        diff_totals = (
            diff.get("totals")
            if isinstance(diff, dict) and isinstance(diff.get("totals"), dict)
            else None
        )
        if diff_totals is not None:
            items.extend(
                [
                    f"delta_loc_total={int(diff_totals.get('loc_total', 0))}",
                    f"delta_loc_code={int(diff_totals.get('loc_code', 0))}",
                    f"delta_function_total={int(diff_totals.get('functions', 0))}",
                    f"delta_decision_points={int(diff_totals.get('decision_points', 0))}",
                ]
            )
        _print_check_section("Kernel Metrics", items)
    summary = report["summary"]
    print(
        f"Summary: {summary['ok']} ok, {summary['warnings']} warnings, {summary['errors']} errors"
    )


def print_fleet_report(payload: dict[str, Any]) -> None:
    print("Cortex Fleet Status")
    for report in payload["projects"]:
        summary = report["summary"]
        status = "OK" if summary["errors"] == 0 else "ERROR"
        print(
            f"- {report['root']} [{status}] "
            f"ok={summary['ok']} warnings={summary['warnings']} errors={summary['errors']}"
        )
    summary = payload["summary"]
    print(
        "Fleet Summary: "
        f"projects={summary['projects']} ok_projects={summary['ok_projects']} "
        f"warning_projects={summary['warning_projects']} error_projects={summary['error_projects']}"
    )


def write_status_artifact(root: Path, report: dict[str, Any]) -> str:
    status_path = root / ".cortex" / "status.json"
    status_path.parent.mkdir(parents=True, exist_ok=True)
    status_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return str(status_path)


def _collect_kernel_metrics() -> dict[str, Any]:
    kernel_dir = Path(__file__).resolve().parents[1] / "cortex"
    modules: dict[str, Any] = {}
    totals = {"loc_total": 0, "loc_code": 0, "functions": 0, "decision_points": 0}
    for module_name in STOP_PATH_MODULE_FILES:
        metrics = _python_module_metrics(kernel_dir / module_name)
        modules[module_name[:-3]] = metrics
        if metrics.get("exists"):
            totals["loc_total"] += int(metrics["loc_total"])
            totals["loc_code"] += int(metrics["loc_code"])
            totals["functions"] += int(metrics["functions"])
            totals["decision_points"] += int(metrics["decision_points"])
    return {
        "gating": "non_blocking",
        "scope": "stop_path",
        "kernel_dir": str(kernel_dir),
        "modules": modules,
        "totals": totals,
        "trend_target": "down_or_equal_without_reliability_loss",
    }


def _write_kernel_metrics_baseline(
    path: Path,
    metrics: dict[str, Any],
    *,
    root: Path | None = None,
) -> str:
    if root is not None and not path.is_relative_to(root):
        raise OSError(f"path must stay under --root ({root})")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return str(path)


def _read_kernel_metrics_baseline(path: Path) -> tuple[dict[str, Any] | None, str | None]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        return None, str(exc)
    except json.JSONDecodeError as exc:
        return None, f"invalid JSON: {exc}"
    if not isinstance(payload, dict):
        return None, "baseline payload must be a JSON object"
    baseline = payload.get("current") if isinstance(payload.get("current"), dict) else payload
    if not isinstance(baseline, dict):
        return None, "baseline payload does not include a metrics object"
    return baseline, None


def _diff_kernel_metrics(*, current: dict[str, Any], baseline: dict[str, Any]) -> dict[str, Any]:
    keys = ("loc_total", "loc_code", "functions", "decision_points")
    current_totals = current.get("totals") if isinstance(current.get("totals"), dict) else {}
    baseline_totals = baseline.get("totals") if isinstance(baseline.get("totals"), dict) else {}
    totals_diff = {
        key: int(current_totals.get(key, 0)) - int(baseline_totals.get(key, 0))
        for key in keys
    }

    current_modules = current.get("modules") if isinstance(current.get("modules"), dict) else {}
    baseline_modules = baseline.get("modules") if isinstance(baseline.get("modules"), dict) else {}
    modules_diff: dict[str, dict[str, int]] = {}
    for module_name in sorted(set(current_modules) | set(baseline_modules)):
        current_metrics = (
            current_modules.get(module_name)
            if isinstance(current_modules.get(module_name), dict)
            else {}
        )
        baseline_metrics = (
            baseline_modules.get(module_name)
            if isinstance(baseline_modules.get(module_name), dict)
            else {}
        )
        modules_diff[module_name] = {
            key: int(current_metrics.get(key, 0)) - int(baseline_metrics.get(key, 0))
            for key in keys
        }
    return {"totals": totals_diff, "modules": modules_diff}


def _python_module_metrics(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {
            "exists": False,
            "path": str(path),
            "loc_total": 0,
            "loc_code": 0,
            "functions": 0,
            "decision_points": 0,
            "parse_error": "module file not found",
        }

    source = path.read_text(encoding="utf-8")
    lines = source.splitlines()
    loc_total = len(lines)
    loc_code = sum(1 for line in lines if line.strip() and not line.strip().startswith("#"))
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        return {
            "exists": True,
            "path": str(path),
            "loc_total": loc_total,
            "loc_code": loc_code,
            "functions": 0,
            "decision_points": 0,
            "parse_error": str(exc),
        }
    function_count = sum(
        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) for node in ast.walk(tree)
    )
    decision_count = sum(
        isinstance(
            node,
            (ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try, ast.BoolOp, ast.IfExp, ast.Match),
        )
        for node in ast.walk(tree)
    )
    return {
        "exists": True,
        "path": str(path),
        "loc_total": loc_total,
        "loc_code": loc_code,
        "functions": function_count,
        "decision_points": decision_count,
    }


def _print_check_section(title: str, items: list[str]) -> None:
    print(f"{title}:")
    if not items:
        print("  (none)")
        return
    for item in items:
        print(f"  - {item}")
