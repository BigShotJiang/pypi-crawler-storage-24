from __future__ import annotations

import argparse
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from cortex.core import CortexKernel
from cortex.stop_payload import parse_stop_fields_json

from ._openai_bridge_probe import probe_approval_blocking as _probe_approval_blocking_impl
from ._openai_bridge_probe import probe_model as _probe_model_impl
from ._openai_bridge_protocol import (
    AppServerClient,
    BridgeError,
    COMMAND_APPROVAL_METHOD,
    DEFAULT_APPROVAL_POLICY_CANDIDATES,
    FILE_CHANGE_APPROVAL_METHOD,
    execute_turn as _protocol_execute_turn,
    initialize_app_server as _initialize_app_server,
    start_thread_with_policy_fallback,
)

SCHEMA_VERSION = "openai_app_server_v1"
_start_thread_with_policy_fallback = start_thread_with_policy_fallback


_STOP_RESULT_FORWARD_KEYS = (
    "session_status",
    "proceed",
    "recommend_revert",
    "feedback_mode",
    "stuck_declared",
    "stuck_declaration",
    "structured_stop_violation",
    "challenge_coverage_missing",
    "requirement_audit_gap",
    "truth_claims_gap",
    "requirements_gate_gap",
    "contract_diagnostic",
)


def _extract_stop_fields_from_final_text(final_text: str) -> tuple[dict[str, Any] | None, str, str]:
    parsed, marker_found, parse_error = parse_stop_fields_json(final_text)
    if parsed is not None:
        return dict(parsed), "payload.stop_fields", ""
    if marker_found:
        return None, "none", str(parse_error or "invalid_stop_fields_json")
    return None, "none", ""


def _bridge_stop_summary(stop_result: dict[str, Any]) -> dict[str, Any]:
    summary = {"enforcement_pass": bool(stop_result.get("enforcement_pass"))}
    warnings = stop_result.get("warnings")
    if isinstance(warnings, list):
        normalized_warnings = [str(item) for item in warnings if str(item).strip()]
        if normalized_warnings:
            summary["warnings"] = normalized_warnings
    for key in _STOP_RESULT_FORWARD_KEYS:
        if key in stop_result:
            summary[key] = stop_result[key]
    return summary


def _kernel_pretool_decision(
    *,
    kernel: CortexKernel,
    session_id: str,
    method: str,
    params: dict[str, Any],
) -> tuple[bool, dict[str, Any]]:
    if method == COMMAND_APPROVAL_METHOD:
        command = str(params.get("command") or "")
        tool_name = "command_execution"
    elif method == FILE_CHANGE_APPROVAL_METHOD:
        command = "file_change"
        tool_name = "file_change"
    else:
        return True, {"warnings": [f"unhandled_approval_method:{method}"]}

    kernel_response = kernel.dispatch(
        "pre_tool_use",
        {
            "session_id": session_id,
            "tool_name": tool_name,
            "command": command,
            "approval_method": method,
        },
    )
    return bool(kernel_response.get("proceed", True)), kernel_response


def _handle_post_tool(
    *,
    kernel: CortexKernel,
    session_id: str,
    item: dict[str, Any],
) -> None:
    if str(item.get("type") or "") != "commandExecution":
        return
    status = str(item.get("status") or "").strip().lower()
    mapped_status = "ok"
    if status in {"failed"}:
        mapped_status = "error"
    elif status in {"declined"}:
        mapped_status = "declined"
    kernel.dispatch(
        "post_tool_use",
        {
            "session_id": session_id,
            "tool_name": "command_execution",
            "status": mapped_status,
            "tool_response": {
                "stdout": str(item.get("aggregatedOutput") or ""),
                "stderr": "",
                "exit_code": item.get("exitCode"),
            },
            "command": str(item.get("command") or ""),
            "cwd": str(item.get("cwd") or ""),
            "raw_status": status,
        },
    )


def _normalize_command_for_witness(command: str) -> str:
    raw = str(command or "").strip()
    if not raw:
        return ""
    try:
        tokens = shlex.split(raw)
    except ValueError:
        return raw
    if len(tokens) >= 3 and Path(tokens[0]).name.lower() in {"bash", "sh", "zsh"} and tokens[1] == "-lc":
        inner = str(tokens[2]).strip()
        return inner or raw
    return raw


def _execute_turn(
    *,
    codex_bin: str,
    cwd: Path,
    prompt: str,
    model: str | None,
    timeout_seconds: float,
    approval_policy_candidates: tuple[str, ...] = DEFAULT_APPROVAL_POLICY_CANDIDATES,
    approval_handler: Any,
) -> dict[str, Any]:
    return _protocol_execute_turn(
        codex_bin=codex_bin,
        cwd=cwd,
        prompt=prompt,
        model=model,
        timeout_seconds=timeout_seconds,
        approval_policy_candidates=approval_policy_candidates,
        approval_handler=approval_handler,
        client_cls=AppServerClient,
    )


def _run_mode(args: argparse.Namespace) -> int:
    cwd = Path(args.cwd).resolve()
    kernel = CortexKernel(root=args.root, config_path=args.config_path, db_path=args.db_path)
    coverage_gaps: list[str] = []
    session_id_holder: dict[str, str] = {"value": ""}

    def _approval_handler(method: str, params: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        thread_id = str(params.get("threadId") or "").strip()
        if thread_id:
            session_id_holder["value"] = thread_id
        session_id = session_id_holder["value"] or thread_id or f"openai-session-{int(time.time())}"
        proceed, kernel_response = _kernel_pretool_decision(
            kernel=kernel,
            session_id=session_id,
            method=method,
            params=params,
        )
        decision = "accept" if proceed else "decline"
        if method not in {COMMAND_APPROVAL_METHOD, FILE_CHANGE_APPROVAL_METHOD}:
            coverage_gaps.append(f"pre_tool_use_coverage_gap:{method}")
        return decision, kernel_response

    result = _execute_turn(
        codex_bin=args.codex_bin,
        cwd=cwd,
        prompt=args.prompt,
        model=args.model,
        timeout_seconds=float(args.timeout_seconds),
        approval_policy_candidates=_approval_policy_candidates_from_args(args),
        approval_handler=_approval_handler,
    )

    command_surface = result.get("command_surface") if isinstance(result.get("command_surface"), dict) else {}
    command_items_without_approval = [
        str(item)
        for item in command_surface.get("command_items_without_approval", [])
        if str(item).strip()
    ]
    nonblocking_declines = [str(item) for item in command_surface.get("nonblocking_declines", []) if str(item).strip()]
    if command_items_without_approval:
        coverage_gaps.append("pre_tool_use_partial_surface_trusted_commands")
    if nonblocking_declines:
        coverage_gaps.append("pre_tool_use_nonblocking_approval")

    session_id = session_id_holder["value"] or str(result.get("thread_id") or "")
    approval_command_by_item_id: dict[str, dict[str, str]] = {}
    for request in result.get("approval_requests") or []:
        if not isinstance(request, dict):
            continue
        item_id = str(request.get("item_id") or "").strip()
        if not item_id:
            continue
        approval_command_by_item_id[item_id] = {
            "command": str(request.get("command") or "").strip(),
            "cwd": str(request.get("cwd") or "").strip(),
        }

    for item in result.get("command_completion_items") or []:
        if isinstance(item, dict):
            item_id = str(item.get("item_id") or "").strip()
            completion_command = str(item.get("command") or "").strip()
            completion_cwd = str(item.get("cwd") or "").strip()
            fallback_command = approval_command_by_item_id.get(item_id, {}).get("command", "")
            fallback_cwd = approval_command_by_item_id.get(item_id, {}).get("cwd", "")
            resolved_command = completion_command or fallback_command
            resolved_cwd = completion_cwd or fallback_cwd or str(cwd)
            normalized_command = _normalize_command_for_witness(resolved_command)
            _handle_post_tool(
                kernel=kernel,
                session_id=session_id,
                item={
                    "type": "commandExecution",
                    "status": item.get("status"),
                    "exitCode": item.get("exit_code"),
                    "aggregatedOutput": item.get("aggregated_output"),
                    "command": normalized_command,
                    "cwd": resolved_cwd,
                },
            )

    final_text = str(result.get("text") or "")
    stop_fields, stop_fields_source, stop_fields_parse_error = _extract_stop_fields_from_final_text(final_text)
    stop_payload: dict[str, Any] = {
        "session_id": session_id,
        "last_assistant_message": final_text,
        "final_text": final_text,
    }
    if stop_fields is not None:
        stop_payload["stop_fields"] = stop_fields
    stop_result = kernel.dispatch(
        "stop",
        stop_payload,
    )

    response = {
        "ok": True,
        "text": final_text,
        "session_id": session_id,
        "thread_id": result.get("thread_id"),
        "turn_id": result.get("turn_id"),
        "approval_policy_used": result.get("approval_policy_used"),
        "coverage_gaps": sorted(set([*coverage_gaps, *[str(v) for v in result.get("coverage_gaps") or []]])),
        "command_items_with_approval_count": len(command_surface.get("command_items_with_approval", [])),
        "command_items_without_approval_count": len(command_items_without_approval),
        "nonblocking_decline_count": len(nonblocking_declines),
        "duplicate_turn_completed_count": int(result.get("duplicate_turn_completed_count") or 0),
        "approval_request_count": len(result.get("approval_requests") or []),
        "command_completion_count": len(result.get("command_completion_items") or []),
        "stop_fields_present": bool(stop_fields is not None),
        "stop_fields_parse_error": stop_fields_parse_error,
        "stop_fields_source": stop_fields_source,
        "elapsed_seconds": result.get("elapsed_seconds"),
    }
    response.update(_bridge_stop_summary(stop_result))
    print(json.dumps(response, sort_keys=True))
    return 0


def _probe_approval_blocking(args: argparse.Namespace) -> int:
    return _probe_approval_blocking_impl(
        args=args,
        command_approval_method=COMMAND_APPROVAL_METHOD,
        execute_turn=_execute_turn,
        approval_policy_candidates_from_args=_approval_policy_candidates_from_args,
    )


def _probe_model(args: argparse.Namespace) -> int:
    return _probe_model_impl(
        args=args,
        app_server_client_cls=AppServerClient,
        initialize_app_server=_initialize_app_server,
        bridge_error_cls=BridgeError,
        run_exec=subprocess.run,
    )


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run")
    run.add_argument("--schema-version", choices=[SCHEMA_VERSION], default=SCHEMA_VERSION)
    run.add_argument("--codex-bin", default="codex")
    run.add_argument("--cwd", default=".")
    run.add_argument("--root", default=".")
    run.add_argument("--config-path")
    run.add_argument("--db-path")
    run.add_argument("--model")
    run.add_argument("--prompt", required=True)
    run.add_argument("--timeout-seconds", type=float, default=180.0)
    run.add_argument(
        "--approval-policy-candidates",
        default=",".join(DEFAULT_APPROVAL_POLICY_CANDIDATES),
        help="Comma-delimited thread/start approvalPolicy fallback order.",
    )

    probe = sub.add_parser("probe-approval-blocking")
    probe.add_argument("--schema-version", choices=[SCHEMA_VERSION], default=SCHEMA_VERSION)
    probe.add_argument("--codex-bin", default="codex")
    probe.add_argument("--cwd", default=".")
    probe.add_argument("--model")
    probe.add_argument("--timeout-seconds", type=float, default=180.0)
    probe.add_argument("--prompt", default="")
    probe.add_argument(
        "--approval-policy-candidates",
        default=",".join(DEFAULT_APPROVAL_POLICY_CANDIDATES),
        help="Comma-delimited thread/start approvalPolicy fallback order.",
    )

    probe_model = sub.add_parser("probe-model")
    probe_model.add_argument("--schema-version", choices=[SCHEMA_VERSION], default=SCHEMA_VERSION)
    probe_model.add_argument("--codex-bin", default="codex")
    probe_model.add_argument("--cwd", default=".")
    probe_model.add_argument("--model", required=True)
    probe_model.add_argument("--timeout-seconds", type=float, default=180.0)

    return parser.parse_args(argv)


def _approval_policy_candidates_from_args(args: argparse.Namespace) -> tuple[str, ...]:
    raw = getattr(args, "approval_policy_candidates", None)
    if raw is None:
        return DEFAULT_APPROVAL_POLICY_CANDIDATES
    if isinstance(raw, str):
        parsed = tuple(token.strip() for token in raw.split(",") if token.strip())
        return parsed or DEFAULT_APPROVAL_POLICY_CANDIDATES
    if isinstance(raw, (list, tuple)):
        parsed = tuple(str(token).strip() for token in raw if str(token).strip())
        return parsed or DEFAULT_APPROVAL_POLICY_CANDIDATES
    return DEFAULT_APPROVAL_POLICY_CANDIDATES


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        if args.command == "run":
            return _run_mode(args)
        if args.command == "probe-approval-blocking":
            return _probe_approval_blocking(args)
        if args.command == "probe-model":
            return _probe_model(args)
        raise BridgeError(f"Unsupported command: {args.command}")
    except BridgeError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
