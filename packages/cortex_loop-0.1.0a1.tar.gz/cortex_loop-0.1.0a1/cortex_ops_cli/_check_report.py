from __future__ import annotations

import importlib.util
import shutil
import sqlite3
import subprocess
import tomllib
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cortex import __version__
from cortex.adapters import load_adapter
from cortex.genome import GENOME_SCHEMA_VERSION, load_genome
from cortex.store import DB_SCHEMA_VERSION
from cortex_ops_cli._runtime_profiles import (
    CLAUDE_ADAPTER_ALIASES,
    CLAUDE_DIRNAME,
    GEMINI_ADAPTER_ALIASES,
    OPENAI_ADAPTER_ALIASES,
    resolve_claude_settings_path,
    resolve_gemini_settings_path,
    resolve_openai_bridge_profile_path,
    validate_claude_settings,
    validate_gemini_settings,
    validate_openai_bridge_profile,
)

REQUIRED_DB_TABLES = {"sessions", "graveyard", "invariants", "challenge_results", "events"}
DEFAULT_REPOMAP_SESSION_START_TIMEOUT_MS = 2500


def collect_check_report(
    root: Path,
    *,
    repomap_dependency_status: Callable[[], list[str]] | None = None,
    repomap_parser_dependency_status: Callable[[], list[str]] | None = None,
    which: Callable[[str], str | None] = shutil.which,
    find_spec: Callable[[str], object | None] = importlib.util.find_spec,
    run_exec: Callable[..., Any] = subprocess.run,
) -> dict[str, Any]:
    ok: list[str] = []
    warn: list[str] = []
    err: list[str] = []
    config_path = root / "cortex.toml"
    db_path = root / ".cortex" / "cortex.db"
    check_data: dict[str, Any] = {
        "root": str(root),
        "generated_at": _now_iso(),
        "cortex_version": __version__,
        "config_schema_version": GENOME_SCHEMA_VERSION,
        "config": {"path": str(config_path), "exists": config_path.exists(), "parse_error": None},
        "db": {
            "path": str(db_path),
            "exists": db_path.exists(),
            "tables": [],
            "missing_tables": [],
            "schema_version": 0,
            "expected_schema_version": DB_SCHEMA_VERSION,
        },
        "hooks": {"settings_path": None, "legacy_settings_path": None, "valid": False},
        "runtime": {
            "adapter_path": None,
            "adapter_valid": False,
            "profile": None,
        },
        "invariants": {"paths": [], "missing_paths": []},
        "repomap": {
            "enabled": None,
            "prefer_ast_graph": None,
            "parity_profile": None,
            "deps_missing": [],
            "parser_deps_missing": [],
        },
        "packs": {"temporal_protocol": {"phase_gate_patterns": []}},
        "ok": ok,
        "warnings": warn,
        "errors": err,
    }

    repomap_dependency_status = repomap_dependency_status or _repomap_dependency_status
    repomap_parser_dependency_status = (
        repomap_parser_dependency_status or _repomap_parser_dependency_status
    )

    genome = None
    if not config_path.exists():
        err.append(f"Missing config file: {config_path}")
    else:
        genome = load_genome(config_path)
        check_data["config"]["parse_error"] = genome.parse_error
        if genome.parse_error:
            err.append(f"Config parse error in {config_path}: {genome.parse_error}")
        else:
            ok.append(f"Config parsed: {config_path}")
            adapter_path = str(genome.runtime.adapter).strip()
            check_data["runtime"]["adapter_path"] = adapter_path or None
            check_data["packs"]["temporal_protocol"] = pack_temporal_protocol_summary(
                root=root,
                pack_paths=list(genome.packs.paths),
            )
            if not adapter_path:
                err.append(
                    "Missing runtime adapter config: set [runtime].adapter = "
                    '"module.path:ClassName" (for example cortex.adapters.claude:ClaudeAdapter '
                    "or cortex.adapters.gemini:GeminiAdapter)."
                )
            else:
                try:
                    load_adapter(adapter_path)
                except Exception as exc:  # noqa: BLE001
                    err.append(f"Runtime adapter load failed ({adapter_path}): {exc}")
                else:
                    ok.append(f"Runtime adapter loaded: {adapter_path}")
                    check_data["runtime"]["adapter_valid"] = True

    if not db_path.exists():
        err.append(f"Missing database file: {db_path}")
    else:
        db_tables, db_schema_version, db_error = _inspect_db(db_path)
        check_data["db"]["tables"] = sorted(db_tables)
        check_data["db"]["schema_version"] = db_schema_version
        if db_error:
            err.append(f"Database check failed: {db_error}")
        else:
            missing_tables = sorted(REQUIRED_DB_TABLES - db_tables)
            check_data["db"]["missing_tables"] = missing_tables
            if missing_tables:
                err.append("Database missing required tables: " + ", ".join(missing_tables))
            else:
                ok.append(f"Database ready: {db_path} (required tables present)")
                if db_schema_version != DB_SCHEMA_VERSION:
                    warn.append(
                        "Database schema version mismatch: "
                        f"found {db_schema_version}, expected {DB_SCHEMA_VERSION} "
                        "(run `cortex init-db --root <project>` to refresh metadata)"
                    )

    if genome and not genome.parse_error:
        check_data["invariants"]["paths"] = list(genome.invariants.suite_paths)
        check_data["repomap"]["enabled"] = genome.repomap.enabled
        check_data["repomap"]["prefer_ast_graph"] = genome.repomap.prefer_ast_graph
        check_data["repomap"]["parity_profile"] = genome.repomap.parity_profile
        _append_check_policy_warnings(genome=genome, warn=warn)

        if genome.invariants.suite_paths:
            for suite_path in genome.invariants.suite_paths:
                full_path = root / suite_path
                if not full_path.exists():
                    check_data["invariants"]["missing_paths"].append(suite_path)
                    warn.append(f"Invariant path missing (warning only): {suite_path}")
            if not check_data["invariants"]["missing_paths"]:
                ok.append(f"Invariant paths present: {len(genome.invariants.suite_paths)} configured")
        else:
            warn.append("No invariant suite paths configured in cortex.toml")
        _check_invariant_execution_mode(
            genome=genome,
            root=root,
            ok=ok,
            warn=warn,
            err=err,
            which=which,
            find_spec=find_spec,
        )

        if genome.repomap.enabled:
            missing = repomap_dependency_status() if genome.repomap.prefer_ast_graph else []
            parser_missing = (
                repomap_parser_dependency_status() if genome.repomap.prefer_ast_graph else []
            )
            check_data["repomap"]["deps_missing"] = list(missing)
            check_data["repomap"]["parser_deps_missing"] = list(parser_missing)
            if genome.repomap.prefer_ast_graph and missing:
                warn.append(
                    "Repo-map enabled; optional ranking dependencies missing "
                    "(AST graph + lightweight fallback remain available): "
                    + ", ".join(missing)
                    + " (install with: pip install -e '.[repomap]')"
                )
            elif genome.repomap.prefer_ast_graph:
                ok.append("Repo-map AST parser/ranking dependencies available")
            else:
                ok.append("Repo-map configured for heuristic-only mode (prefer_ast_graph=false)")
            if genome.repomap.prefer_ast_graph and parser_missing:
                warn.append(
                    "Repo-map tree-sitter parser dependencies missing: "
                    + ", ".join(parser_missing)
                    + " (install with: pip install -e '.[repomap]')"
                )
            elif genome.repomap.prefer_ast_graph:
                ok.append("Repo-map tree-sitter parser dependencies available")
            if genome.repomap.parity_profile and parser_missing:
                warn.append(
                    "Repo-map parity profile is enabled but parser dependencies are missing; "
                    "parity runs will fail until dependencies are installed"
                )
            repomap_artifact = root / genome.repomap.artifact_path
            check_data["repomap"]["artifact_path"] = str(repomap_artifact)
            check_data["repomap"]["artifact_exists"] = repomap_artifact.exists()
            if repomap_artifact.exists():
                ok.append(f"Repo-map artifact present: {repomap_artifact}")
            else:
                warn.append(
                    "Repo-map artifact missing (warning only): "
                    f"{genome.repomap.artifact_path} (run `cortex repomap --root {root}`)"
                )
        else:
            warn.append(
                "Repo-map is disabled in cortex.toml (set [repomap].enabled = true to test it)"
            )

    adapter_path = str(check_data["runtime"]["adapter_path"] or "")
    if adapter_path in CLAUDE_ADAPTER_ALIASES and bool(check_data["runtime"]["adapter_valid"]):
        check_data["runtime"]["profile"] = "claude"
        settings_path, legacy_settings_path = resolve_claude_settings_path(root)
        check_data["hooks"]["settings_path"] = str(settings_path) if settings_path else None
        check_data["hooks"]["legacy_settings_path"] = (
            str(legacy_settings_path) if legacy_settings_path and legacy_settings_path.exists() else None
        )
        if settings_path is None:
            warn.append(
                f"Claude runtime profile settings not found at {root / CLAUDE_DIRNAME / 'settings.json'}; "
                f"run `cortex runtime install --profile claude --root {root}` for hook wiring"
            )
        else:
            settings_errors, settings_warnings = validate_claude_settings(settings_path)
            err.extend(settings_errors)
            warn.extend(settings_warnings)
            if not settings_errors:
                check_data["hooks"]["valid"] = True
                ok.append(f"Runtime profile wiring found in {settings_path}")
                if legacy_settings_path and legacy_settings_path.exists():
                    warn.append(
                        "Legacy runtime settings also present at "
                        f"{legacy_settings_path}; prefer {root / CLAUDE_DIRNAME / 'settings.json'}"
                    )
    elif adapter_path in GEMINI_ADAPTER_ALIASES and bool(check_data["runtime"]["adapter_valid"]):
        check_data["runtime"]["profile"] = "gemini"
        settings_path = resolve_gemini_settings_path(root)
        check_data["hooks"]["settings_path"] = str(settings_path) if settings_path else None
        check_data["hooks"]["legacy_settings_path"] = None
        if settings_path is None:
            err.append(
                "No Gemini settings file found. Run cortex runtime install --profile gemini to create one."
            )
        else:
            settings_errors, settings_warnings = validate_gemini_settings(settings_path)
            err.extend(settings_errors)
            warn.extend(settings_warnings)
            if not settings_errors:
                check_data["hooks"]["valid"] = True
                ok.append(f"Runtime profile wiring found in {settings_path}")
    elif adapter_path in OPENAI_ADAPTER_ALIASES and bool(check_data["runtime"]["adapter_valid"]):
        check_data["runtime"]["profile"] = "openai"
        settings_path = resolve_openai_bridge_profile_path(root)
        check_data["hooks"]["settings_path"] = str(settings_path) if settings_path else None
        check_data["hooks"]["legacy_settings_path"] = None
        if settings_path is None:
            err.append(
                "No OpenAI bridge profile found. Run cortex runtime install --profile openai to create one."
            )
        else:
            settings_errors, settings_warnings = validate_openai_bridge_profile(
                settings_path,
                which=which,
                run_exec=run_exec,
            )
            err.extend(settings_errors)
            warn.extend(settings_warnings)
            if not settings_errors:
                check_data["hooks"]["valid"] = True
                ok.append(f"Runtime profile wiring found in {settings_path}")
    elif adapter_path:
        warn.append(
            f"No runtime profile validator implemented for adapter '{adapter_path}' "
            "(kernel checks still active)."
        )

    check_data["summary"] = {"ok": len(ok), "warnings": len(warn), "errors": len(err)}
    check_data["status"] = "ok" if not err else "error"
    return check_data
def pack_temporal_protocol_summary(*, root: Path, pack_paths: list[str]) -> dict[str, list[str]]:
    patterns: list[str] = []
    for raw_path in pack_paths:
        path_token = str(raw_path).strip()
        if not path_token:
            continue
        manifest = (
            Path(path_token) if Path(path_token).is_absolute() else (root / path_token)
        ).expanduser().resolve()
        if not manifest.exists():
            continue
        try:
            with manifest.open("rb") as fh:
                payload = tomllib.load(fh)
        except Exception:  # noqa: BLE001
            continue
        if not isinstance(payload, dict):
            continue
        temporal = payload.get("temporal_protocol")
        if not isinstance(temporal, dict):
            continue
        pattern = str(temporal.get("phase_gate_pattern") or "").strip()
        if pattern:
            patterns.append(pattern)
    seen: set[str] = set()
    deduped: list[str] = []
    for pattern in patterns:
        if pattern in seen:
            continue
        seen.add(pattern)
        deduped.append(pattern)
    return {"phase_gate_patterns": deduped}


def _append_check_policy_warnings(*, genome: Any, warn: list[str]) -> None:
    warning_rules = (
        (
            bool(genome.repomap.run_on_session_start),
            "repomap.run_on_session_start=true is deprecated/no-op under magic-kernel policy; "
            "use `cortex repomap` for explicit artifact generation",
        ),
        (
            genome.repomap.session_start_timeout_ms != DEFAULT_REPOMAP_SESSION_START_TIMEOUT_MS,
            "repomap.session_start_timeout_ms is ignored because SessionStart repo-map execution "
            "is deprecated/no-op; use `cortex repomap --timeout-ms ...` when needed",
        ),
        (
            genome.hooks.mode != "strict"
            and genome.hooks.fail_on_missing_challenge_coverage
            and genome.challenges.require_coverage,
            "hooks.fail_on_missing_challenge_coverage=true has no blocking effect while "
            "hooks.mode='advisory'; set [hooks].mode='strict' to enforce missing challenge "
            "coverage as a real gate",
        ),
        (
            genome.hooks.require_structured_stop_payload
            and genome.hooks.allow_message_stop_fallback,
            "hooks.require_structured_stop_payload=true while "
            "hooks.allow_message_stop_fallback=true; set allow_message_stop_fallback=false "
            "for fully deterministic structured stop gating",
        ),
    )
    for enabled, message in warning_rules:
        if enabled:
            warn.append(message)


def _inspect_db(db_path: Path) -> tuple[set[str], int, str | None]:
    try:
        conn = sqlite3.connect(db_path)
        try:
            rows = conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'").fetchall()
            user_version_row = conn.execute("PRAGMA user_version").fetchone()
        finally:
            conn.close()
    except sqlite3.Error as exc:
        return set(), 0, str(exc)
    user_version = int(user_version_row[0]) if user_version_row else 0
    return {str(row[0]) for row in rows}, user_version, None


def _check_invariant_execution_mode(
    *,
    genome: Any,
    root: Path,
    ok: list[str],
    warn: list[str],
    err: list[str],
    which: Callable[[str], str | None],
    find_spec: Callable[[str], object | None],
) -> None:
    trust_profile = str(
        getattr(getattr(genome, "project", object()), "trust_profile", "trusted")
    ).strip().lower()
    if trust_profile not in {"trusted", "untrusted"}:
        err.append(
            "project.trust_profile must be 'trusted' or 'untrusted'; "
            f"got {trust_profile or '<empty>'!r}"
        )
        trust_profile = "untrusted"
    if genome.invariants.execution_mode == "host":
        if trust_profile == "untrusted":
            err.append(
                "invariants.execution_mode='host' is blocked when "
                "project.trust_profile='untrusted'; set execution_mode='container' "
                "or explicitly set trust_profile='trusted'"
            )
            return
        pytest_bin = str(genome.invariants.pytest_bin).strip() or "pytest"
        pytest_path = Path(pytest_bin).expanduser()
        has_configured_bin = False
        if pytest_path.is_absolute():
            has_configured_bin = pytest_path.exists()
        elif any(sep in pytest_bin for sep in ("/", "\\")):
            has_configured_bin = (root / pytest_path).exists() or pytest_path.exists()
        else:
            has_configured_bin = which(pytest_bin) is not None

        if has_configured_bin:
            ok.append(f"Invariant host pytest runner available: {pytest_bin}")
        elif find_spec("pytest") is not None:
            warn.append(
                f"invariants.pytest_bin='{pytest_bin}' is unavailable; host mode will fallback "
                "to 'python -m pytest' when invariants run"
            )
        else:
            err.append(
                f"invariants.execution_mode='host' but pytest is unavailable "
                f"(configured pytest_bin='{pytest_bin}' not found and python -m pytest not installed)"
            )
        warn.append(
            "invariants.execution_mode='host' runs tests on the host machine; use only for "
            "trusted repositories (switch to execution_mode='container' for stronger isolation)"
        )
        return
    engine = genome.invariants.container_engine.strip()
    if not engine:
        message = (
            "invariants.execution_mode='container' but container_engine is empty; "
            "set [invariants].container_engine (for example 'docker') or switch "
            "to execution_mode='host'"
        )
        if trust_profile == "untrusted":
            err.append(message)
        else:
            warn.append(message)
        return
    if which(engine):  # pragma: no branch
        ok.append(f"Invariant container engine available: {engine}")
        return
    message = (
        f"invariants.execution_mode='container' but container engine '{engine}' is not on PATH; "
        f"install '{engine}' or switch to execution_mode='host'"
    )
    if trust_profile == "untrusted":
        err.append(message)
    else:
        warn.append(message)


def _repomap_dependency_status() -> list[str]:
    from cortex.repomap import repomap_missing_dependencies

    return repomap_missing_dependencies()


def _repomap_parser_dependency_status() -> list[str]:
    from cortex.repomap import repomap_missing_parser_dependencies

    return repomap_missing_parser_dependencies()
def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
