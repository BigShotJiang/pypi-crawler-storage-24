from __future__ import annotations

import json
import re
import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable

from ._runtime_profile_templates import (
    render_claude_md,
    render_claude_settings_json,
    render_gemini_md,
    render_gemini_settings_json,
    render_openai_bridge_profile_json,
    render_openai_md,
)

CLAUDE_REQUIRED_HOOK_COMMANDS = {
    "PreToolUse": "cortex.hooks.pre_tool_use",
    "PostToolUse": "cortex.hooks.post_tool_use",
    "Stop": "cortex.hooks.stop",
}
CLAUDE_HOOK_SCHEMA_NATIVE = "claude_native_v1"
CLAUDE_HOOK_SCHEMA_LEGACY = "legacy_json_v0"
CLAUDE_SUPPORTED_HOOK_SCHEMAS = {CLAUDE_HOOK_SCHEMA_NATIVE, CLAUDE_HOOK_SCHEMA_LEGACY}
CLAUDE_PINNED_HOOK_SCHEMA = CLAUDE_HOOK_SCHEMA_NATIVE
GEMINI_REQUIRED_HOOK_COMMANDS = {
    "SessionStart": "cortex_ops_cli.gemini_hooks SessionStart",
    "BeforeTool": "cortex_ops_cli.gemini_hooks BeforeTool",
    "AfterTool": "cortex_ops_cli.gemini_hooks AfterTool",
    "AfterAgent": "cortex_ops_cli.gemini_hooks AfterAgent",
}
GEMINI_OPTIONAL_HOOK_COMMANDS = {
    "BeforeAgent": "cortex_ops_cli.gemini_hooks BeforeAgent",
}
GEMINI_AFTER_AGENT_BRIDGE_PATTERN = "cortex_ops_cli.gemini_hooks AfterAgent"
CLAUDE_DIRNAME, LEGACY_CLAUDE_DIRNAME = ".claude", "claude"
GEMINI_DIRNAME = ".gemini"
OPENAI_DIRNAME = ".codex"
OPENAI_BRIDGE_PROFILE_FILENAME = "cortex_openai_bridge.json"
OPENAI_BRIDGE_SCHEMA_VERSION = "openai_app_server_v1"
OPENAI_BRIDGE_COMMAND_PATTERN = "cortex_ops_cli.openai_app_server_bridge run"
OPENAI_CODEX_MIN_VERSION = (0, 111, 0)
OPENAI_CODEX_MIN_VERSION_LABEL = "0.111.0"
CLAUDE_ADAPTER_PATH = "cortex.adapters.claude:ClaudeAdapter"
CLAUDE_ADAPTER_ALIASES = {CLAUDE_ADAPTER_PATH, "cortex.adapters:ClaudeAdapter"}
GEMINI_ADAPTER_PATH = "cortex.adapters.gemini:GeminiAdapter"
GEMINI_ADAPTER_ALIASES = {GEMINI_ADAPTER_PATH, "cortex.adapters:GeminiAdapter"}
OPENAI_ADAPTER_PATH = "cortex.adapters.openai:OpenAIAdapter"
OPENAI_ADAPTER_ALIASES = {OPENAI_ADAPTER_PATH, "cortex.adapters:OpenAIAdapter"}


def runtime_profile_install_spec(
    *,
    root: Path,
    profile: str,
    python_executable: str | None,
) -> tuple[Path, dict[Path, str], str]:
    normalized = str(profile).strip().lower()
    if normalized == "claude":
        runtime_dir = root / CLAUDE_DIRNAME
        return (
            runtime_dir,
            {
                runtime_dir / "settings.json": render_claude_settings_json(
                    python_executable=python_executable,
                    schema_version=CLAUDE_PINNED_HOOK_SCHEMA,
                ),
                runtime_dir / "CLAUDE.md": render_claude_md(),
            },
            CLAUDE_ADAPTER_PATH,
        )
    if normalized == "gemini":
        runtime_dir = root / GEMINI_DIRNAME
        return (
            runtime_dir,
            {
                runtime_dir / "settings.json": render_gemini_settings_json(
                    python_executable=python_executable
                ),
                runtime_dir / "GEMINI.md": render_gemini_md(),
            },
            GEMINI_ADAPTER_PATH,
        )
    if normalized == "openai":
        runtime_dir = root / OPENAI_DIRNAME
        return (
            runtime_dir,
            {
                runtime_dir / OPENAI_BRIDGE_PROFILE_FILENAME: render_openai_bridge_profile_json(
                    python_executable=python_executable,
                    schema_version=OPENAI_BRIDGE_SCHEMA_VERSION,
                ),
                runtime_dir / "OPENAI.md": render_openai_md(),
            },
            OPENAI_ADAPTER_PATH,
        )
    raise ValueError(f"Unsupported runtime profile: {profile}")


def set_runtime_adapter(config_path: Path, adapter_path: str) -> str:
    if not config_path.exists():
        raise OSError(f"Missing config file: {config_path}")
    lines = config_path.read_text(encoding="utf-8").splitlines()
    out: list[str] = []
    in_runtime = False
    runtime_seen = False
    adapter_written = False
    for line in lines:
        stripped = line.strip()
        section = stripped.startswith("[") and stripped.endswith("]")
        if section:
            if in_runtime and not adapter_written:
                out.append(f'adapter = "{adapter_path}"')
                adapter_written = True
            in_runtime = stripped == "[runtime]"
            runtime_seen = runtime_seen or in_runtime
            out.append(line)
            continue
        if in_runtime and stripped.startswith("adapter"):
            if not adapter_written:
                out.append(f'adapter = "{adapter_path}"')
                adapter_written = True
            continue
        out.append(line)
    if in_runtime and not adapter_written:
        out.append(f'adapter = "{adapter_path}"')
        adapter_written = True
    if not runtime_seen:
        if out and out[-1].strip():
            out.append("")
        out.extend(["[runtime]", f'adapter = "{adapter_path}"'])
    rendered = "\n".join(out).rstrip() + "\n"
    before = config_path.read_text(encoding="utf-8")
    if rendered == before:
        return "unchanged"
    config_path.write_text(rendered, encoding="utf-8")
    return "updated"


def resolve_claude_settings_path(root: Path) -> tuple[Path | None, Path | None]:
    preferred = root / CLAUDE_DIRNAME / "settings.json"
    legacy = root / LEGACY_CLAUDE_DIRNAME / "settings.json"
    if preferred.exists():
        return preferred, legacy
    if legacy.exists():
        return legacy, None
    return None, legacy


def validate_claude_settings(settings_path: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        data = json.loads(settings_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return [f"Failed to read {settings_path}: {exc}"], []

    hooks = data.get("hooks")
    if not isinstance(hooks, dict):
        return [f"Invalid {settings_path}: missing top-level hooks object"], []

    for event_name, command_fragment in CLAUDE_REQUIRED_HOOK_COMMANDS.items():
        event_entries = hooks.get(event_name)
        if not isinstance(event_entries, list):
            errors.append(f"Invalid {settings_path}: missing hooks.{event_name} list")
            continue
        commands = _event_hook_commands(event_entries)
        if not any(command_fragment in command for command in commands):
            errors.append(
                f"Invalid {settings_path}: hooks.{event_name} does not contain "
                f"command fragment '{command_fragment}'"
            )
            continue
        matched = [command for command in commands if command_fragment in command]
        schema_versions = {_command_schema_version(command) for command in matched}
        schema_versions.discard(None)
        if not schema_versions:
            errors.append(
                f"Invalid {settings_path}: hooks.{event_name} command must pin --schema-version "
                f"{CLAUDE_PINNED_HOOK_SCHEMA}"
            )
            continue
        if len(schema_versions) != 1:
            errors.append(
                f"Invalid {settings_path}: hooks.{event_name} has mixed schema versions: "
                + ", ".join(sorted(str(item) for item in schema_versions))
            )
            continue
        schema_version = next(iter(schema_versions))
        if schema_version not in CLAUDE_SUPPORTED_HOOK_SCHEMAS:
            errors.append(
                f"Invalid {settings_path}: hooks.{event_name} schema version '{schema_version}' "
                f"is unsupported (supported: {', '.join(sorted(CLAUDE_SUPPORTED_HOOK_SCHEMAS))})"
            )
            continue
        if schema_version != CLAUDE_PINNED_HOOK_SCHEMA:
            errors.append(
                f"Invalid {settings_path}: hooks.{event_name} schema version '{schema_version}' "
                f"does not match pinned runtime schema '{CLAUDE_PINNED_HOOK_SCHEMA}'"
            )
    return errors, warnings


def resolve_gemini_settings_path(root: Path) -> Path | None:
    path = root / GEMINI_DIRNAME / "settings.json"
    return path if path.exists() else None


def validate_gemini_settings(settings_path: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        data = json.loads(settings_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return [f"Failed to read {settings_path}: {exc}"], []

    hooks_config = data.get("hooksConfig")
    if isinstance(hooks_config, dict) and hooks_config.get("enabled") is False:
        errors.append(
            "Gemini hooks are globally disabled. "
            "Cortex cannot enforce without hooks. Set hooksConfig.enabled to true or remove the field (defaults to true).",
        )

    hooks = data.get("hooks")
    if not isinstance(hooks, dict):
        errors.append(f"Invalid {settings_path}: missing top-level hooks object")
        return errors, warnings

    after_agent_entries = hooks.get("AfterAgent")
    if not isinstance(after_agent_entries, list) or not after_agent_entries:
        errors.append("No AfterAgent hook configured. Cortex stop path cannot fire without this hook.")
    after_agent_configs = _flatten_hook_configs(
        after_agent_entries if isinstance(after_agent_entries, list) else []
    )
    if isinstance(after_agent_entries, list) and after_agent_entries and not after_agent_configs:
        errors.append("No AfterAgent hook configured. Cortex stop path cannot fire without this hook.")
    if after_agent_configs and not all(_is_command_hook(config) for config in after_agent_configs):
        errors.append(
            "AfterAgent hook configuration is invalid. Each hook config requires type: 'command' and a command string."
        )
    after_agent_commands = [
        str(config.get("command") or "").strip()
        for config in after_agent_configs
        if str(config.get("command") or "").strip()
    ]
    if after_agent_commands and not any(
        GEMINI_AFTER_AGENT_BRIDGE_PATTERN in command for command in after_agent_commands
    ):
        warnings.append(
            "AfterAgent hook command does not appear to be a Cortex hook bridge. "
            "Stop path enforcement may not work. Expected command containing "
            f"'{GEMINI_AFTER_AGENT_BRIDGE_PATTERN}'."
        )

    before_tool_entries = hooks.get("BeforeTool")
    if not isinstance(before_tool_entries, list) or not before_tool_entries:
        warnings.append("No BeforeTool hook. Tool blocklist enforcement will not run.")
    elif not _flatten_hook_configs(before_tool_entries):
        warnings.append("No BeforeTool hook. Tool blocklist enforcement will not run.")

    after_tool_entries = hooks.get("AfterTool")
    if not isinstance(after_tool_entries, list) or not after_tool_entries:
        warnings.append("No AfterTool hook. Post-tool failure detection will not run.")
    elif not _flatten_hook_configs(after_tool_entries):
        warnings.append("No AfterTool hook. Post-tool failure detection will not run.")

    before_agent_entries = hooks.get("BeforeAgent")
    if not isinstance(before_agent_entries, list) or not before_agent_entries:
        warnings.append("No BeforeAgent hook. Per-turn persistent executive anchor injection will not run.")
    elif not _flatten_hook_configs(before_agent_entries):
        warnings.append("No BeforeAgent hook. Per-turn persistent executive anchor injection will not run.")

    project_root = settings_path.parent.parent
    for command in _hook_commands(hooks):
        if _command_references_missing_path(command, project_root):
            warnings.append(
                f"Hook command may reference a missing path: {command}. Hooks may fail at runtime."
            )
    return errors, warnings


def resolve_openai_bridge_profile_path(root: Path) -> Path | None:
    path = root / OPENAI_DIRNAME / OPENAI_BRIDGE_PROFILE_FILENAME
    return path if path.exists() else None


def validate_openai_bridge_profile(
    profile_path: Path,
    *,
    which: Callable[[str], str | None] = shutil.which,
    run_exec: Callable[..., Any] = subprocess.run,
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        data = json.loads(profile_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return [f"Failed to read {profile_path}: {exc}"], []

    if not isinstance(data, dict):
        return [f"Invalid {profile_path}: expected JSON object"], []

    schema_version = str(data.get("schema_version") or "").strip()
    if schema_version != OPENAI_BRIDGE_SCHEMA_VERSION:
        errors.append(
            f"Invalid {profile_path}: schema_version must be '{OPENAI_BRIDGE_SCHEMA_VERSION}'."
        )

    bridge = data.get("bridge")
    if not isinstance(bridge, dict):
        errors.append(f"Invalid {profile_path}: missing bridge object.")
        return errors, warnings

    command = str(bridge.get("command") or "").strip()
    if not command:
        errors.append(f"Invalid {profile_path}: bridge.command is required.")
        return errors, warnings
    if OPENAI_BRIDGE_COMMAND_PATTERN not in command:
        errors.append(
            f"Invalid {profile_path}: bridge.command must contain '{OPENAI_BRIDGE_COMMAND_PATTERN}'."
        )
    command_schema = _command_schema_version(command)
    if command_schema != OPENAI_BRIDGE_SCHEMA_VERSION:
        errors.append(
            f"Invalid {profile_path}: bridge.command must pin --schema-version {OPENAI_BRIDGE_SCHEMA_VERSION}."
        )

    codex_bin = str(bridge.get("codex_bin") or "").strip()
    if not codex_bin:
        warnings.append(
            f"{profile_path}: bridge.codex_bin is empty; runtime will fallback to 'codex' on PATH."
        )
        return errors, warnings

    resolved = which(codex_bin)
    if resolved is None:
        errors.append(f"{profile_path}: bridge.codex_bin '{codex_bin}' is not on PATH.")
        return errors, warnings

    try:
        version_run = run_exec(
            [codex_bin, "--version"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception as exc:  # noqa: BLE001
        warnings.append(f"{profile_path}: failed to run '{codex_bin} --version': {exc}")
        return errors, warnings

    version_text = f"{version_run.stdout}\n{version_run.stderr}"
    version_tuple = _parse_semver_tuple(version_text)
    if version_tuple is None:
        warnings.append(
            f"{profile_path}: unable to parse Codex version from '{codex_bin} --version' output."
        )
        return errors, warnings
    if version_tuple < OPENAI_CODEX_MIN_VERSION:
        warnings.append(
            f"{profile_path}: Codex version {version_tuple[0]}.{version_tuple[1]}.{version_tuple[2]} is below tested baseline {OPENAI_CODEX_MIN_VERSION_LABEL}."
        )
    return errors, warnings


def _parse_semver_tuple(text: str) -> tuple[int, int, int] | None:
    match = re.search(r"(\d+)\.(\d+)\.(\d+)", str(text))
    if not match:
        return None
    return (int(match.group(1)), int(match.group(2)), int(match.group(3)))


def _flatten_hook_configs(event_entries: list[Any]) -> list[dict[str, Any]]:
    configs: list[dict[str, Any]] = []
    for entry in event_entries:
        if not isinstance(entry, dict):
            continue
        hook_items = entry.get("hooks")
        if not isinstance(hook_items, list):
            continue
        for config in hook_items:
            if isinstance(config, dict):
                configs.append(config)
    return configs


def _is_command_hook(config: dict[str, Any]) -> bool:
    return (
        str(config.get("type") or "").strip() == "command"
        and bool(str(config.get("command") or "").strip())
    )


def _hook_commands(hooks: dict[str, Any]) -> list[str]:
    commands: list[str] = []
    for event_name in [*GEMINI_REQUIRED_HOOK_COMMANDS, *GEMINI_OPTIONAL_HOOK_COMMANDS]:
        event_entries = hooks.get(event_name)
        if not isinstance(event_entries, list):
            continue
        for config in _flatten_hook_configs(event_entries):
            command = str(config.get("command") or "").strip()
            if command:
                commands.append(command)
    return commands


def _command_references_missing_path(command: str, root: Path) -> bool:
    tokens = str(command).split()
    for token in tokens:
        candidate = token.strip().strip("'\"")
        if not candidate or "/" not in candidate:
            continue
        if candidate.startswith("-"):
            continue
        path = Path(candidate)
        if path.is_absolute():
            if path.exists():
                continue
            return True
        if (root / path).exists() or path.exists():
            continue
        return True
    return False


def _event_hook_commands(event_entries: list[Any]) -> list[str]:
    commands: list[str] = []
    for config in _flatten_hook_configs(event_entries):
        command = str(config.get("command") or "").strip()
        if command:
            commands.append(command)
    return commands


def _command_schema_version(command: str) -> str | None:
    parts = shlex.split(command)
    for idx, token in enumerate(parts):
        if token == "--schema-version" and idx + 1 < len(parts):
            return str(parts[idx + 1]).strip() or None
        if token.startswith("--schema-version="):
            return token.split("=", 1)[1].strip() or None
    return None
