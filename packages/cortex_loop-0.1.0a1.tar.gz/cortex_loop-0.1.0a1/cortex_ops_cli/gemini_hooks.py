from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import sys
from pathlib import Path
from typing import Any

from cortex.core import CortexKernel
from cortex.executive import get_base_executive_function

KERNEL_EVENT_NAMES = {"SessionStart", "BeforeTool", "AfterTool", "AfterAgent"}
RETRY_STOP_REASON = "Cortex stop path failed after retry. Manual review required."


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        payload = _read_payload()
        payload = _ensure_session_id(payload, event=args.event)
    except Exception as exc:  # noqa: BLE001
        print(f"[cortex] Gemini bridge error: {exc}", file=sys.stderr)
        return 1

    if args.event not in KERNEL_EVENT_NAMES:
        if args.event == "BeforeAgent":
            print(json.dumps(_before_agent_output(payload)))
            return 0
        print(json.dumps({}))
        return 0

    try:
        prior_retry_pending = False
        if args.event == "AfterAgent":
            prior_retry_pending = _session_has_pending_after_agent_retry(
                root=Path(args.root),
                db_path=args.db_path,
                session_id=str(payload.get("session_id") or "").strip(),
            )
        kernel = CortexKernel(root=args.root, config_path=args.config_path, db_path=args.db_path)
        result = kernel.dispatch(args.event, payload)
        print(
            json.dumps(
                _to_gemini_output(
                    event=args.event,
                    payload=payload,
                    result=result,
                    prior_retry_pending=prior_retry_pending,
                )
            )
        )
        return 0
    except Exception as exc:  # noqa: BLE001
        print(f"[cortex] Gemini bridge error: {exc}", file=sys.stderr)
        return 1


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("event")
    parser.add_argument("--root", default=".")
    parser.add_argument("--config-path")
    parser.add_argument("--db-path")
    return parser.parse_args(argv)


def _read_payload() -> dict[str, Any]:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("Gemini hook payload must be a JSON object")
    return data


def _to_gemini_output(
    *,
    event: str,
    payload: dict[str, Any],
    result: dict[str, Any],
    prior_retry_pending: bool = False,
) -> dict[str, Any]:
    warnings = [str(item).strip() for item in (result.get("warnings") or []) if str(item).strip()]
    if event == "SessionStart":
        return _session_start_output(result=result, warnings=warnings)
    proceed = bool(result.get("proceed", True))
    if event == "AfterAgent" and _is_stuck_result(result):
        reason = _stuck_reason(result, warnings=warnings)
        return _attach_advisories(
            {"continue": False, "stopReason": reason},
            warnings=warnings,
            primary=reason,
        )
    if event == "AfterAgent" and _needs_after_agent_retry(result, proceed=proceed):
        reason = _retry_reason_from_result(result, warnings=warnings)
        if _requires_session_stop(result):
            return _attach_advisories(
                {"continue": False, "stopReason": reason},
                warnings=warnings,
                primary=reason,
            )
        if bool(payload.get("stop_hook_active")) or prior_retry_pending:
            return _attach_advisories(
                {"continue": False, "stopReason": RETRY_STOP_REASON},
                warnings=warnings,
                primary=RETRY_STOP_REASON,
            )
        return _attach_advisories({"decision": "deny", "reason": reason}, warnings=warnings, primary=reason)
    if not proceed:
        reason = _primary_reason(event=event, warnings=warnings, result=result)
        return _attach_advisories({"decision": "deny", "reason": reason}, warnings=warnings, primary=reason)
    if warnings:
        return {"systemMessage": _warnings_message(warnings)}
    return {}


def _before_agent_output(payload: dict[str, Any]) -> dict[str, Any]:
    _part_a, part_b = get_base_executive_function()
    if _payload_already_contains_anchor(payload, part_b):
        return {}
    return {"hookSpecificOutput": {"additionalContext": part_b}}


def _payload_already_contains_anchor(payload: dict[str, Any], anchor: str) -> bool:
    if not anchor:
        return False
    candidates = [payload.get("prompt"), payload.get("message"), payload.get("input")]
    for candidate in candidates:
        if isinstance(candidate, str) and anchor in candidate:
            return True
    return False


def _session_start_output(*, result: dict[str, Any], warnings: list[str]) -> dict[str, Any]:
    response: dict[str, Any] = {}
    raw_blocks = result.get("context_blocks")
    context_blocks: list[str] = []
    if isinstance(raw_blocks, list):
        context_blocks = [str(item).strip() for item in raw_blocks if isinstance(item, str) and item.strip()]
    if context_blocks:
        response["hookSpecificOutput"] = {"additionalContext": "\n\n".join(context_blocks)}
    if warnings:
        response["systemMessage"] = _warnings_message(warnings)
    return response


def _requires_session_stop(result: dict[str, Any]) -> bool:
    if _is_stuck_result(result):
        return True
    if bool(result.get("terminate_session")):
        return True
    invariant_report = result.get("invariant_report")
    if isinstance(invariant_report, dict) and invariant_report.get("ok") is False:
        return True
    return False


def _is_stuck_result(result: dict[str, Any]) -> bool:
    return bool(result.get("stuck_declared")) or str(result.get("feedback_mode") or "") == "stuck"


def _needs_after_agent_retry(result: dict[str, Any], *, proceed: bool) -> bool:
    if not proceed:
        return True
    if bool(result.get("structured_stop_violation")):
        return True
    if bool(result.get("challenge_coverage_missing")):
        return True
    if bool(result.get("requirements_gate_gap")):
        return True
    challenge_report = result.get("challenge_report")
    if isinstance(challenge_report, dict) and challenge_report.get("ok") is False:
        return True
    return False


def _retry_reason_from_result(result: dict[str, Any], *, warnings: list[str]) -> str:
    if bool(result.get("structured_stop_violation")):
        return "Structured stop fields are required. Include STOP_FIELDS_JSON in the final response."
    challenge_report = result.get("challenge_report")
    if isinstance(challenge_report, dict) and isinstance(challenge_report.get("missing_categories"), list):
        missing = [str(item).strip() for item in challenge_report["missing_categories"] if str(item).strip()]
        if missing:
            return "Missing challenge coverage for: " + ", ".join(missing)
    if bool(result.get("challenge_coverage_missing")):
        return "Missing challenge_coverage in stop fields. Include all active challenge categories."
    if bool(result.get("requirements_gate_gap")):
        requirement_report = result.get("requirement_audit_report")
        if isinstance(requirement_report, dict):
            req_errors = [str(item).strip() for item in (requirement_report.get("errors") or []) if str(item).strip()]
            if req_errors:
                return "Requirement evidence gaps: " + "; ".join(req_errors[:2])
        truth_claims_report = result.get("truth_claims_report")
        if isinstance(truth_claims_report, dict):
            truth_errors = [str(item).strip() for item in (truth_claims_report.get("errors") or []) if str(item).strip()]
            if truth_errors:
                return "Truth-claim evidence gaps: " + "; ".join(truth_errors[:2])
    if warnings:
        return warnings[0]
    if bool(result.get("requirements_gate_gap")):
        return "Requirement/truth claims are incomplete or unverified. Provide explicit evidence in stop fields."
    return "Cortex stop path failed."


def _stuck_reason(result: dict[str, Any], *, warnings: list[str]) -> str:
    stuck = result.get("stuck_declaration")
    if isinstance(stuck, dict):
        check = str(stuck.get("check") or "").strip()
        obstacle = str(stuck.get("obstacle") or "").strip()
        if check and obstacle:
            return f"Cortex reported stuck on {check}: {obstacle}"
        if obstacle:
            return f"Cortex reported stuck: {obstacle}"
    if warnings:
        return warnings[0]
    return "Cortex reported stuck and could not complete the requested evidence boundary."


def _primary_reason(*, event: str, warnings: list[str], result: dict[str, Any]) -> str:
    if warnings:
        return warnings[0]
    if event == "AfterAgent":
        return "Cortex stop path failed."
    if event == "BeforeTool":
        return "Cortex blocked this tool invocation."
    return f"Cortex denied {event}."


def _warnings_message(warnings: list[str]) -> str:
    return "\n".join(f"[cortex] {warning}" for warning in warnings)


def _attach_advisories(response: dict[str, Any], *, warnings: list[str], primary: str) -> dict[str, Any]:
    additional = [warning for warning in warnings if warning and warning != primary]
    if additional:
        response["systemMessage"] = _warnings_message(additional)
    return response


def _session_has_pending_after_agent_retry(*, root: Path, db_path: str | None, session_id: str) -> bool:
    if not session_id:
        return False
    db_file = Path(db_path) if db_path else (root / ".cortex" / "cortex.db")
    if not db_file.exists():
        return False
    try:
        with sqlite3.connect(db_file) as conn:
            row = conn.execute(
                "SELECT metadata_json FROM sessions WHERE session_id = ? LIMIT 1",
                (session_id,),
            ).fetchone()
    except sqlite3.Error:
        return False
    if not row or not row[0]:
        return False
    try:
        metadata = json.loads(str(row[0]))
    except (json.JSONDecodeError, TypeError, ValueError):
        return False
    if not isinstance(metadata, dict) or str(metadata.get("hook") or "") != "Stop":
        return False
    if bool(metadata.get("stuck_declared")) or str(metadata.get("feedback_mode") or "") == "stuck":
        return False
    challenge_ok = metadata.get("challenge_ok")
    return (
        bool(metadata.get("structured_stop_violation"))
        or bool(metadata.get("challenge_coverage_missing"))
        or bool(metadata.get("requirements_gate_gap"))
        or challenge_ok is False
    )


def _ensure_session_id(payload: dict[str, Any], *, event: str) -> dict[str, Any]:
    data = dict(payload)
    session_id = str(data.get("session_id") or "").strip()
    if session_id:
        data["session_id"] = session_id
        return data
    basis = "|".join(
        (
            event,
            str(data.get("timestamp") or ""),
            str(data.get("transcript_path") or ""),
            str(data.get("cwd") or ""),
            str(data.get("hook_event_name") or ""),
        )
    )
    fallback = "gemini-fallback-" + hashlib.sha1(basis.encode("utf-8")).hexdigest()[:12]
    data["session_id"] = fallback
    print(
        f"[cortex] warning: Gemini payload missing session_id for {event}; using {fallback}.",
        file=sys.stderr,
    )
    return data


if __name__ == "__main__":
    raise SystemExit(main())
