from __future__ import annotations

import json
from argparse import Namespace
from pathlib import Path
from typing import Any, Callable


def probe_approval_blocking(
    *,
    args: Namespace,
    command_approval_method: str,
    execute_turn: Callable[..., dict[str, Any]],
    approval_policy_candidates_from_args: Callable[[Namespace], tuple[str, ...]],
) -> int:
    cwd = Path(args.cwd).resolve()
    default_cases = [
        (
            "mutating_workspace",
            (
                "Attempt exactly once: bash -lc 'echo cortex_probe_mutate > ./cortex_probe_mutate.txt'. "
                "If approval is declined, do not retry. Reply with blocked_or_declined. "
                "If it executes, reply with executed."
            ),
        ),
        (
            "network_sensitive",
            (
                "Attempt exactly once: bash -lc 'curl --max-time 3 -I https://example.com >/tmp/cortex_probe_network.txt 2>&1'. "
                "If approval is declined, do not retry. Reply with blocked_or_declined. "
                "If it executes, reply with executed."
            ),
        ),
        (
            "destructive_git_like",
            (
                "Attempt exactly once: bash -lc 'git reset --hard HEAD'. "
                "If approval is declined, do not retry. Reply with blocked_or_declined. "
                "If it executes, reply with executed."
            ),
        ),
    ]
    cases = [("custom", str(args.prompt))] if str(args.prompt or "").strip() else default_cases

    all_coverage_gaps: list[str] = []
    hard_coverage_gaps: list[str] = []
    limitation_gaps: list[str] = []
    case_results: list[dict[str, Any]] = []
    approval_policies_used: set[str] = set()

    for case_name, prompt in cases:
        decline_item_ids: set[str] = set()

        def _approval_handler(method: str, params: dict[str, Any]) -> tuple[str, dict[str, Any]]:
            if method == command_approval_method:
                item_id = str(params.get("itemId") or "").strip()
                if item_id:
                    decline_item_ids.add(item_id)
                return "decline", {"probe": "decline", "case": case_name}
            return "accept", {"probe": "accept_non_command", "case": case_name}

        result = execute_turn(
            codex_bin=args.codex_bin,
            cwd=cwd,
            prompt=prompt,
            model=args.model,
            timeout_seconds=float(args.timeout_seconds),
            approval_policy_candidates=approval_policy_candidates_from_args(args),
            approval_handler=_approval_handler,
        )
        if isinstance(result.get("approval_policy_used"), str) and str(
            result.get("approval_policy_used")
        ).strip():
            approval_policies_used.add(str(result.get("approval_policy_used")).strip())

        approval_requests = [
            req
            for req in (result.get("approval_requests") or [])
            if isinstance(req, dict) and req.get("method") == command_approval_method
        ]
        command_items = [item for item in (result.get("command_completion_items") or []) if isinstance(item, dict)]
        command_surface = result.get("command_surface") if isinstance(result.get("command_surface"), dict) else {}
        command_items_without_approval = [
            str(item)
            for item in command_surface.get("command_items_without_approval", [])
            if str(item).strip()
        ]

        blocked = False
        for item in command_items:
            status = str(item.get("status") or "").strip().lower()
            if status != "declined":
                continue
            if item.get("exit_code") is None and not str(item.get("aggregated_output") or "").strip():
                blocked = True
                break

        case_gaps: list[str] = []
        if not approval_requests:
            case_gaps.append("pre_tool_use_approval_not_observed")
            all_coverage_gaps.append("pre_tool_use_approval_not_observed")
            limitation_gaps.append("pre_tool_use_approval_not_observed")
        elif not blocked:
            case_gaps.append("pre_tool_use_nonblocking_approval")
            all_coverage_gaps.append("pre_tool_use_nonblocking_approval")
            hard_coverage_gaps.append("pre_tool_use_nonblocking_approval")
        if command_items_without_approval:
            case_gaps.append("pre_tool_use_partial_surface_trusted_commands")
            all_coverage_gaps.append("pre_tool_use_partial_surface_trusted_commands")
            limitation_gaps.append("pre_tool_use_partial_surface_trusted_commands")

        case_results.append(
            {
                "case": case_name,
                "turn_id": result.get("turn_id"),
                "thread_id": result.get("thread_id"),
                "approval_request_count": len(approval_requests),
                "decline_item_ids": sorted(decline_item_ids),
                "command_completion_count": len(command_items),
                "command_items_without_approval_count": len(command_items_without_approval),
                "blocked_decline_observed": blocked,
                "coverage_gaps": sorted(set(case_gaps)),
            }
        )

    payload = {
        "ok": not hard_coverage_gaps,
        "cases": case_results,
        "approval_policies_used": sorted(approval_policies_used),
        "blocked_decline_observed": (
            any(item.get("blocked_decline_observed") for item in case_results) if case_results else False
        ),
        "coverage_gaps": sorted(set(all_coverage_gaps)),
        "hard_coverage_gaps": sorted(set(hard_coverage_gaps)),
        "limitation_gaps": sorted(set(limitation_gaps)),
    }
    print(json.dumps(payload, sort_keys=True))
    return 0 if payload["ok"] else 2


def probe_model(
    *,
    args: Namespace,
    app_server_client_cls: type[Any],
    initialize_app_server: Callable[..., None],
    bridge_error_cls: type[Exception],
    run_exec: Callable[..., Any],
) -> int:
    if not str(args.model or "").strip():
        raise bridge_error_cls("--model is required for probe-model")

    model = str(args.model).strip()
    cwd = Path(args.cwd).resolve()
    found = False
    source = "model/list"
    model_list_error = ""
    models_seen: list[str] = []

    client = app_server_client_cls(
        codex_bin=args.codex_bin,
        cwd=cwd,
        timeout_seconds=float(args.timeout_seconds),
    )
    try:
        initialize_app_server(client=client)
        cursor: str | None = None
        for _ in range(25):
            params: dict[str, Any] = {"limit": 200, "includeHidden": True}
            if cursor:
                params["cursor"] = cursor
            page = client.request("model/list", params)
            if not isinstance(page, dict):
                raise bridge_error_cls("model/list did not return a JSON object")
            items = page.get("data") if isinstance(page.get("data"), list) else []
            for item in items:
                if not isinstance(item, dict):
                    continue
                for key in ("id", "model", "displayName"):
                    token = str(item.get(key) or "").strip()
                    if token:
                        models_seen.append(token)
                item_id = str(item.get("id") or "").strip()
                item_model = str(item.get("model") or "").strip()
                if model in {item_id, item_model}:
                    found = True
                    break
            if found:
                break
            cursor = str(page.get("nextCursor") or "").strip() or None
            if cursor is None:
                break
    except bridge_error_cls as exc:
        source = "exec_fallback"
        model_list_error = str(exc)
    finally:
        client.close()

    fallback_used = False
    fallback_return_code: int | None = None
    fallback_error = ""
    if not found and source == "exec_fallback":
        fallback_used = True
        cmd = [
            args.codex_bin,
            "exec",
            "--skip-git-repo-check",
            "--sandbox",
            "read-only",
            "--ask-for-approval",
            "never",
            "--model",
            model,
            "Reply with OK only.",
        ]
        run = run_exec(
            cmd,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=float(args.timeout_seconds),
            check=False,
        )
        fallback_return_code = int(run.returncode)
        if run.returncode == 0:
            found = True
        else:
            fallback_error = str(run.stderr or run.stdout or "").strip()[:4000]

    payload = {
        "ok": found,
        "model": model,
        "available": found,
        "source": source,
        "fallback_used": fallback_used,
        "fallback_return_code": fallback_return_code,
        "model_list_error": model_list_error,
        "fallback_error": fallback_error,
        "models_seen_sample": sorted(set(models_seen))[:50],
    }
    print(json.dumps(payload, sort_keys=True))
    return 0 if found else 2
