from __future__ import annotations

from pathlib import Path

import pytest

from cortex import core_helpers


def test_session_git_snapshot_skips_git_when_no_repo_marker(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _unexpected_run(*args, **kwargs):  # noqa: ANN002, ANN003
        raise AssertionError("git status should not run without a .git marker")

    monkeypatch.setattr(core_helpers.subprocess, "run", _unexpected_run)

    snapshot = core_helpers.session_git_snapshot(tmp_path)

    assert snapshot == {
        "available": False,
        "changed_files": [],
        "error": "git repository marker not found",
    }


def test_session_git_snapshot_uses_git_when_repo_marker_present(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = tmp_path / "repo"
    root.mkdir()
    (root / ".git").mkdir()
    (root / "src").mkdir()
    (root / "docs").mkdir()
    (root / "src" / "app.py").write_text("print('hi')\n", encoding="utf-8")
    (root / "docs" / "readme.md").write_text("# hi\n", encoding="utf-8")
    calls: list[list[str]] = []

    class _Completed:
        returncode = 0
        stdout = " M src/app.py\nA  docs/readme.md\n"
        stderr = ""

    def _fake_run(cmd, **kwargs):  # noqa: ANN001
        calls.append(list(cmd))
        return _Completed()

    monkeypatch.setattr(core_helpers.subprocess, "run", _fake_run)

    snapshot = core_helpers.session_git_snapshot(root)

    assert calls == [["git", "-C", str(root.resolve()), "status", "--porcelain"]]
    assert snapshot == {
        "available": True,
        "changed_files": ["docs/readme.md", "src/app.py"],
        "error": None,
    }
