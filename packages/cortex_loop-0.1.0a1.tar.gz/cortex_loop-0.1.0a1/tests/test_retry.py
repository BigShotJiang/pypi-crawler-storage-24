"""Tests for cortex.retry — bounded corrective retry semantics.

Covers:
- Failure classification taxonomy (retryable vs terminal)
- Hard-stop policy for non-retryable failure classes
- Kernel integration via on_post_tool_use
"""

from __future__ import annotations

import json

import pytest

from cortex.core import CortexKernel
from cortex.retry import (
    CORRECTIVE_RETRYABLE,
    NON_RETRYABLE_REASONS,
    RetryVerdict,
    TERMINAL_HARD_GATE,
    classify_failure,
    failure_signature,
    objective_delta_hash,
    reason_retry_limit,
)


class TestClassifyFailure:
    def test_non_failure_returns_none(self) -> None:
        assert classify_failure({"status": "ok"}) is None
        assert classify_failure({"status": "success"}) is None
        assert classify_failure({}) is None

    @pytest.mark.parametrize("status", ["error", "failed", "fail", "ERROR", "Failed"])
    def test_retryable_failure_without_non_retryable_reason(self, status: str) -> None:
        verdict = classify_failure({"status": status, "reason": "timeout"})
        assert verdict is not None
        assert verdict.retryable is True
        assert verdict.hard_stop is False

    def test_retryable_failure_with_empty_reason(self) -> None:
        verdict = classify_failure({"status": "error"})
        assert verdict is not None
        assert verdict.retryable is True
        assert verdict.reason == "tool_error"

    @pytest.mark.parametrize("reason", sorted(NON_RETRYABLE_REASONS))
    def test_non_retryable_reasons_are_hard_stop(self, reason: str) -> None:
        verdict = classify_failure({"status": "error", "failure_reason": reason})
        assert verdict is not None
        assert verdict.retryable is False
        assert verdict.hard_stop is True
        assert verdict.reason == reason

    def test_reason_alias_via_reason_key(self) -> None:
        verdict = classify_failure({"status": "error", "reason": "policy_violation"})
        assert verdict is not None
        assert verdict.retryable is False
        assert verdict.hard_stop is True

    def test_failure_reason_takes_precedence_over_reason(self) -> None:
        verdict = classify_failure({
            "status": "error",
            "failure_reason": "invariant_violation",
            "reason": "timeout",
        })
        assert verdict is not None
        assert verdict.retryable is False
        assert verdict.reason == "invariant_violation"

    def test_shape_range_format_aliases_map_to_retryable_classes(self) -> None:
        shape = classify_failure({"status": "error", "reason": "Shape mismatch in output"})
        assert shape is not None
        assert shape.retryable is True
        assert shape.reason == "shape_mismatch"

        fmt = classify_failure({"status": "error", "reason": "format error in json"})
        assert fmt is not None
        assert fmt.retryable is True
        assert fmt.reason == "format_error"

    def test_alias_can_be_inferred_from_error_text_when_reason_missing(self) -> None:
        shape = classify_failure({"status": "error", "error": "Shape mismatch in output"})
        assert shape is not None
        assert shape.retryable is True
        assert shape.reason == "shape_mismatch"

    def test_unknown_explicit_reason_is_terminal(self) -> None:
        verdict = classify_failure({"status": "error", "reason": "disk_full"})
        assert verdict is not None
        assert verdict.retryable is False
        assert verdict.hard_stop is True
        assert verdict.reason == "disk_full"

    @pytest.mark.parametrize("reason", ["information_missing", "rearrange_indexes"])
    def test_substring_false_positive_reasons_remain_terminal(self, reason: str) -> None:
        verdict = classify_failure({"status": "error", "reason": reason})
        assert verdict is not None
        assert verdict.retryable is False
        assert verdict.hard_stop is True
        assert verdict.reason == reason

    def test_reason_retry_limit_is_deterministic(self) -> None:
        assert reason_retry_limit("range_error", default_limit=3) == 1
        assert reason_retry_limit("shape_mismatch", default_limit=3) == 2
        assert reason_retry_limit("timeout", default_limit=2) == 2

    def test_failure_signature_is_stable_for_equivalent_payloads(self) -> None:
        left = failure_signature(
            {
                "status": "error",
                "tool_name": "Edit",
                "error": "  Shape mismatch in output  ",
                "target_files": ["src/app.py", "src/app.py"],
            },
            reason="shape_mismatch",
        )
        right = failure_signature(
            {
                "status": "error",
                "tool_name": "Edit",
                "error": "shape mismatch in output",
                "target_files": ["src/app.py"],
            },
            reason="shape_mismatch",
        )
        assert left == right

    def test_objective_delta_hash_accepts_only_objective_file_lists(self) -> None:
        assert objective_delta_hash({"changed_files": ["src/app.py"]}) != ""
        assert objective_delta_hash({"delta_hint": "updated parser branch"}) == ""
        assert objective_delta_hash({"delta_hint": "   "}) == ""

    def test_objective_delta_hash_is_stable_and_ignores_hint_text(self) -> None:
        left = objective_delta_hash(
            {
                "changed_files": ["src/app.py", "src/app.py"],
                "updated_files": ["src/core.py"],
                "delta_hint": "updated parser branch",
            }
        )
        right = objective_delta_hash(
            {
                "updated_files": ["src/core.py"],
                "changed_files": ["src/app.py"],
            }
        )
        assert left == right
        assert objective_delta_hash({"delta_hint": "only text"}) == ""


class TestKernelRetryIntegration:
    def test_post_tool_use_returns_retry_info_on_retryable_failure(
        self, kernel: CortexKernel
    ) -> None:
        kernel.on_session_start({"session_id": "sess-retry-1", "objective": "Test retry"})
        result = kernel.on_post_tool_use({
            "session_id": "sess-retry-1",
            "tool_name": "Edit",
            "status": "error",
            "error": "Shape mismatch in output",
        })
        assert result["retry"] is not None
        assert result["retry"]["should_retry"] is True
        assert result["retry"]["failure_class"] == CORRECTIVE_RETRYABLE
        assert result["retry"]["budget_remaining"] == 1
        assert result["proceed"] is True

    def test_post_tool_use_hard_stop_sets_proceed_false(
        self, kernel: CortexKernel
    ) -> None:
        kernel.on_session_start({"session_id": "sess-retry-hs", "objective": "Test hard stop"})
        result = kernel.on_post_tool_use({
            "session_id": "sess-retry-hs",
            "tool_name": "Edit",
            "status": "error",
            "failure_reason": "invariant_violation",
        })
        assert result["retry"] is not None
        assert result["retry"]["should_retry"] is False
        assert result["retry"]["hard_stop"] is True
        assert result["retry"]["failure_class"] == TERMINAL_HARD_GATE
        assert result["proceed"] is False
        assert any("Hard stop" in w for w in result["warnings"])

    def test_retry_consume_event_includes_failure_class_for_retryable_path(
        self, kernel: CortexKernel
    ) -> None:
        sid = "sess-retry-event-retryable"
        kernel.on_session_start({"session_id": sid, "objective": "Retry event parity"})
        kernel.on_post_tool_use({
            "session_id": sid,
            "tool_name": "Edit",
            "status": "error",
            "error": "format error in json",
        })

        with kernel.ctx.store.connection() as conn:
            row = conn.execute(
                "SELECT payload_json FROM events WHERE session_id = ? AND hook = ? ORDER BY id DESC LIMIT 1",
                (sid, "RetryConsume"),
            ).fetchone()
        payload = json.loads(row["payload_json"])
        assert payload["failure_class"] == CORRECTIVE_RETRYABLE

    def test_retry_consume_event_includes_failure_class_for_hard_stop(
        self, kernel: CortexKernel
    ) -> None:
        sid = "sess-retry-event-hard-stop"
        kernel.on_session_start({"session_id": sid, "objective": "Retry event parity"})
        kernel.on_post_tool_use({
            "session_id": sid,
            "tool_name": "Edit",
            "status": "error",
            "failure_reason": "policy_violation",
        })

        with kernel.ctx.store.connection() as conn:
            row = conn.execute(
                "SELECT payload_json FROM events WHERE session_id = ? AND hook = ? ORDER BY id DESC LIMIT 1",
                (sid, "RetryConsume"),
            ).fetchone()
        payload = json.loads(row["payload_json"])
        assert payload["failure_class"] == TERMINAL_HARD_GATE

    def test_post_tool_use_budget_exhaustion_across_calls(
        self, kernel: CortexKernel
    ) -> None:
        kernel.ctx.genome.retry.max_retries = 2
        kernel.on_session_start({"session_id": "sess-retry-exhaust", "objective": "Test budget"})

        for i in range(2):
            result = kernel.on_post_tool_use({
                "session_id": "sess-retry-exhaust",
                "tool_name": "Edit",
                "status": "error",
                "error": f"Error {i}",
            })
            assert result["retry"]["should_retry"] is True
            assert result["retry"]["failure_class"] == CORRECTIVE_RETRYABLE

        result = kernel.on_post_tool_use({
            "session_id": "sess-retry-exhaust",
            "tool_name": "Edit",
            "status": "error",
            "error": "Error 2",
        })
        assert result["retry"]["should_retry"] is False
        assert result["retry"]["budget_exhausted"] is True
        assert result["retry"]["failure_class"] == CORRECTIVE_RETRYABLE
        assert any("budget exhausted" in w.lower() for w in result["warnings"])

    def test_reason_specific_ceiling_limits_range_error_retries(self, kernel: CortexKernel) -> None:
        sid = "sess-retry-range-cap"
        kernel.ctx.genome.retry.max_retries = 3
        kernel.on_session_start({"session_id": sid, "objective": "Reason cap"})

        first = kernel.on_post_tool_use(
            {
                "session_id": sid,
                "tool_name": "Edit",
                "status": "error",
                "reason": "range error in payload",
            }
        )
        assert first["retry"]["should_retry"] is True
        assert first["retry"]["reason"] == "range_error"

        second = kernel.on_post_tool_use(
            {
                "session_id": sid,
                "tool_name": "Edit",
                "status": "error",
                "reason": "range error in payload",
            }
        )
        assert second["retry"]["should_retry"] is False
        assert second["retry"]["decision_code"] == "reason_budget_exhausted"
        assert any("reason-specific retry budget exhausted" in w.lower() for w in second["warnings"])

    def test_delta_sensitive_reason_requires_objective_delta_when_signature_repeats(
        self, kernel: CortexKernel
    ) -> None:
        sid = "sess-retry-delta-sensitive"
        kernel.on_session_start({"session_id": sid, "objective": "Delta-sensitive retry"})

        first = kernel.on_post_tool_use(
            {
                "session_id": sid,
                "tool_name": "Edit",
                "status": "error",
                "error": "Shape mismatch in output",
            }
        )
        assert first["retry"]["should_retry"] is True

        second = kernel.on_post_tool_use(
            {
                "session_id": sid,
                "tool_name": "Edit",
                "status": "error",
                "error": "Shape mismatch in output",
            }
        )
        assert second["retry"]["should_retry"] is False
        assert second["retry"]["decision_code"] == "no_delta"
        assert second["retry"]["budget_exhausted"] is False
        assert any("no delta detected" in w.lower() for w in second["warnings"])

        third = kernel.on_post_tool_use(
            {
                "session_id": sid,
                "tool_name": "Edit",
                "status": "error",
                "error": "Shape mismatch in output",
            }
        )
        assert third["retry"]["should_retry"] is False
        assert third["retry"]["decision_code"] == "no_delta"

        interleaved = kernel.on_post_tool_use(
            {
                "session_id": sid,
                "tool_name": "Edit",
                "status": "error",
                "error": "timeout while executing tool",
            }
        )
        assert interleaved["retry"]["should_retry"] is True
        assert interleaved["retry"]["reason"] == "timeout"

        fourth = kernel.on_post_tool_use(
            {
                "session_id": sid,
                "tool_name": "Edit",
                "status": "error",
                "error": "Shape mismatch in output",
            }
        )
        assert fourth["retry"]["should_retry"] is False
        assert fourth["retry"]["decision_code"] == "no_delta"

        fifth = kernel.on_post_tool_use(
            {
                "session_id": sid,
                "tool_name": "Edit",
                "status": "error",
                "error": "Shape mismatch in output",
                "changed_files": ["src/parser.py"],
            }
        )
        assert fifth["retry"]["should_retry"] is True
        assert fifth["retry"]["decision_code"] == "retry_allowed"

    def test_hard_stop_does_not_consume_retry_budget(
        self, kernel: CortexKernel
    ) -> None:
        sid = "sess-retry-budget-hard-stop"
        kernel.on_session_start({"session_id": sid, "objective": "Do not consume budget"})
        result = kernel.on_post_tool_use({
            "session_id": sid,
            "tool_name": "Edit",
            "status": "error",
            "failure_reason": "stop_gate_failure",
        })
        assert result["retry"]["should_retry"] is False
        assert result["retry"]["hard_stop"] is True
        state = kernel.ctx.store.get_retry_attempts(sid, reason="stop_gate_failure")
        assert state["attempts"] == 0

    def test_post_tool_use_no_retry_info_on_success(
        self, kernel: CortexKernel
    ) -> None:
        kernel.on_session_start({"session_id": "sess-retry-ok", "objective": "Test no retry"})
        result = kernel.on_post_tool_use({
            "session_id": "sess-retry-ok",
            "tool_name": "Edit",
            "status": "ok",
        })
        assert result["retry"] is None
        assert result["proceed"] is True

    def test_post_tool_use_retry_disabled_in_config(
        self, kernel: CortexKernel
    ) -> None:
        kernel.ctx.genome.retry.enabled = False
        kernel.on_session_start({"session_id": "sess-retry-disabled", "objective": "Test disabled"})
        result = kernel.on_post_tool_use({
            "session_id": "sess-retry-disabled",
            "tool_name": "Edit",
            "status": "error",
            "error": "Some error",
        })
        assert result["retry"] is None
        assert result["proceed"] is True

    def test_post_tool_use_non_string_tool_name_does_not_crash(
        self, kernel: CortexKernel
    ) -> None:
        kernel.on_session_start({"session_id": "sess-retry-num", "objective": "Test non-string"})
        result = kernel.on_post_tool_use({
            "session_id": "sess-retry-num",
            "tool_name": 123,
            "status": "error",
            "error": "timeout",
        })
        assert result["retry"] is not None
        assert result["retry"]["should_retry"] is True
        assert result["retry"]["failure_class"] == CORRECTIVE_RETRYABLE

    def test_post_tool_use_budgets_are_per_session(
        self, kernel: CortexKernel
    ) -> None:
        kernel.ctx.genome.retry.max_retries = 1
        kernel.on_session_start({"session_id": "sess-retry-a", "objective": "Session A"})
        kernel.on_session_start({"session_id": "sess-retry-b", "objective": "Session B"})

        r1 = kernel.on_post_tool_use({
            "session_id": "sess-retry-a",
            "tool_name": "Edit",
            "status": "error",
        })
        assert r1["retry"]["should_retry"] is True

        r2 = kernel.on_post_tool_use({
            "session_id": "sess-retry-b",
            "tool_name": "Edit",
            "status": "error",
        })
        assert r2["retry"]["should_retry"] is True

    def test_retry_contention_emits_explicit_warning(
        self, kernel: CortexKernel, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def _fake_retry_verdict(**_kwargs) -> RetryVerdict:
            return RetryVerdict(
                should_retry=False,
                hard_stop=False,
                failure_class=CORRECTIVE_RETRYABLE,
                reason="timeout",
                budget_remaining=1,
                budget_exhausted=False,
                decision_code="retry_contention",
                failure_signature="sig",
            )

        monkeypatch.setattr("cortex.core.compute_retry_verdict", _fake_retry_verdict)
        sid = "sess-retry-contention"
        kernel.on_session_start({"session_id": sid, "objective": "contention warning"})
        result = kernel.on_post_tool_use(
            {
                "session_id": sid,
                "tool_name": "Edit",
                "status": "error",
                "error": "timeout",
            }
        )
        assert result["retry"]["decision_code"] == "retry_contention"
        assert any("Retry contention detected" in warning for warning in result["warnings"])

    @pytest.mark.parametrize("reason", [
        "policy_violation",
        "challenge_failure",
        "permission_denied",
        "authentication_failure",
        "stop_gate_failure",
    ])
    def test_all_non_retryable_reasons_produce_hard_stop_in_kernel(
        self, kernel: CortexKernel, reason: str
    ) -> None:
        sid = f"sess-retry-nr-{reason}"
        kernel.on_session_start({"session_id": sid, "objective": "Test non-retryable"})
        result = kernel.on_post_tool_use({
            "session_id": sid,
            "tool_name": "Edit",
            "status": "error",
            "failure_reason": reason,
        })
        assert result["retry"]["should_retry"] is False
        assert result["retry"]["hard_stop"] is True
        assert result["retry"]["failure_class"] == TERMINAL_HARD_GATE
        assert result["proceed"] is False

    def test_post_tool_use_retry_config_loaded_from_genome(
        self, kernel: CortexKernel
    ) -> None:
        assert kernel.ctx.genome.retry.enabled is True
        assert kernel.ctx.genome.retry.max_retries == 3
