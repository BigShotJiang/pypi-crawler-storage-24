from __future__ import annotations

from cortex.stop_signals import build_stop_attempt_signature, stop_attempt_similarity


def test_stop_attempt_similarity_ignores_empty_signal_overlap() -> None:
    previous = build_stop_attempt_signature(
        challenge_coverage=None,
        witness={"commands": [], "tools": []},
        truth_claims_payload=None,
        failed_approach=None,
        observed_modified_files=None,
    )
    current = build_stop_attempt_signature(
        challenge_coverage=None,
        witness={"commands": [], "tools": []},
        truth_claims_payload=None,
        failed_approach=None,
        observed_modified_files=None,
    )

    assert stop_attempt_similarity(previous, current) is None


def test_build_stop_attempt_signature_normalizes_commands_and_files() -> None:
    signature = build_stop_attempt_signature(
        challenge_coverage={
            "boundary_values": True,
            "null_inputs": {"covered": False},
        },
        witness={
            "commands": [" PyTest   -Q ", "pytest -q", "  python -m pytest  "],
            "tools": [],
        },
        truth_claims_payload={"modified_files": ["src/app.py", "src/app.py"]},
        failed_approach={"files": ["src/alt.py", "src/app.py"]},
        observed_modified_files=["src/live.py", "src/alt.py"],
    )

    assert signature == {
        "challenge_shape": ["boundary_values:covered=True", "null_inputs:covered=False"],
        "witnessed_commands": ["pytest -q", "python -m pytest"],
        "file_signal": ["src/alt.py", "src/app.py", "src/live.py"],
    }
