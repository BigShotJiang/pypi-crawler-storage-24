from __future__ import annotations

from pathlib import Path

from cortex.executive import get_base_executive_function, get_identity_preamble


def _expected_sections_from_source() -> tuple[str, str]:
    text = Path("docs/archive/ef/LAYER1_COMPLETE_FINAL.md").read_text(encoding="utf-8")
    part_a_marker = "## Part A: Full Entries"
    part_b_marker = "## Part B: Persistent Anchor"
    part_a_start = text.find(part_a_marker)
    part_b_start = text.find(part_b_marker)
    assert part_a_start != -1 and part_b_start != -1 and part_b_start > part_a_start
    part_a = text[part_a_start + len(part_a_marker):part_b_start].strip()
    part_b_tail = text[part_b_start + len(part_b_marker):]
    next_heading = part_b_tail.find("\n## ")
    part_b = (part_b_tail if next_heading == -1 else part_b_tail[:next_heading]).strip()
    while part_a.endswith("---"):
        part_a = part_a[:-3].rstrip()
    while part_b.endswith("---"):
        part_b = part_b[:-3].rstrip()
    return part_a, part_b


def test_get_base_executive_function_matches_source_sections_exactly() -> None:
    part_a, part_b = get_base_executive_function()
    expected_a, expected_b = _expected_sections_from_source()

    assert part_a == expected_a
    assert part_b == expected_b
    assert "## Implementation Notes" not in part_b
    assert "SOUL.md" not in part_b


def test_layer1_split_assets_match_source_sections_exactly() -> None:
    expected_a, expected_b = _expected_sections_from_source()
    part_a_asset = Path("cortex/data/layer1_part_a.md").read_text(encoding="utf-8").strip()
    part_b_asset = Path("cortex/data/layer1_part_b.md").read_text(encoding="utf-8").strip()
    assert part_a_asset == expected_a
    assert part_b_asset == expected_b


def test_identity_preamble_asset_is_loaded_verbatim() -> None:
    expected = Path("cortex/data/identity_preamble.md").read_text(encoding="utf-8").strip()
    actual = get_identity_preamble()
    assert actual == expected
