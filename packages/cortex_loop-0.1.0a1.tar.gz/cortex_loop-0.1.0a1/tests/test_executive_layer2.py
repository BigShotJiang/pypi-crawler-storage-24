from __future__ import annotations

from cortex.executive import (
    consolidate_event,
    effective_weight,
    get_learned_executive_function,
    record_stop_failure_event,
    run_decay,
)


def _advance_sessions(store, count: int) -> None:
    for _ in range(max(0, count)):
        store.increment_session_counter()


def test_consolidate_event_merges_same_pattern_strength(store) -> None:
    _advance_sessions(store, 1)
    base = {
        "event_type": "metacognitive",
        "trigger_pattern": "human contradicted file content claim",
        "error_pattern": "defended without re reading source file",
        "resolution": "re-open the file and verify before answering",
        "session_id": "sess-1",
    }
    one = consolidate_event(store, **base)
    two = consolidate_event(store, **base)
    three = consolidate_event(store, **base)

    assert one["id"] == two["id"] == three["id"]
    assert three["strength"] == 3
    assert len(store.get_executive_memory()) == 1


def test_consolidate_event_keeps_similar_but_distinct_trigger_separate(store) -> None:
    _advance_sessions(store, 1)
    first = consolidate_event(
        store,
        event_type="metacognitive",
        trigger_pattern="human contradicted file structure claim",
        error_pattern="defended without checking",
        resolution="re-open file before responding",
        session_id="sess-a",
    )
    second = consolidate_event(
        store,
        event_type="metacognitive",
        trigger_pattern="human contradicted test results claim",
        error_pattern="defended without checking",
        resolution="run tests and verify output",
        session_id="sess-b",
    )
    assert first["id"] != second["id"]
    assert len(store.get_executive_memory()) == 2


def test_consolidate_event_merges_inflection_and_punctuation_variants(store) -> None:
    _advance_sessions(store, 1)
    first = consolidate_event(
        store,
        event_type="metacognitive",
        trigger_pattern="Human contradicted module interface claims.",
        error_pattern="Defended, without verifying boundary behavior.",
        resolution="Re-open module and verify behavior with tests.",
        session_id="sess-lex-1",
    )
    second = consolidate_event(
        store,
        event_type="metacognitive",
        trigger_pattern="Human contradiction about module interfaces",
        error_pattern="Defending without verification of boundary behaviors",
        resolution="Re-open module and verify behavior with tests.",
        session_id="sess-lex-2",
    )
    assert first["id"] == second["id"]
    assert second["strength"] == 2
    assert len(store.get_executive_memory()) == 1


def test_effective_weight_and_run_decay_prunes_old_weak_keeps_recent_strong(store) -> None:
    _advance_sessions(store, 1)
    weak = store.record_executive_event(
        "technical",
        "old trigger",
        "old error",
        "old fix",
        "sess-old",
    )
    strong = store.record_executive_event(
        "technical",
        "new trigger",
        "new error",
        "new fix",
        "sess-new",
    )
    store.update_executive_entry(str(strong["id"]), strength=5, last_accessed_at_session=1)
    _advance_sessions(store, 80)
    store.update_executive_entry(str(weak["id"]), last_accessed_at_session=1)
    store.update_executive_entry(str(strong["id"]), last_accessed_at_session=56)

    entries = {item["id"]: item for item in store.get_executive_memory()}
    weak_w = effective_weight(entries[weak["id"]], store.get_session_count(), 30)
    strong_w = effective_weight(entries[strong["id"]], store.get_session_count(), 30)
    assert weak_w < 0.3
    assert strong_w > 0.3

    pruned = run_decay(store, halflife_sessions=30, threshold=0.3, min_hold_sessions=0)
    assert pruned == 1
    remaining = store.get_executive_memory()
    assert len(remaining) == 1
    assert remaining[0]["id"] == strong["id"]


def test_get_learned_executive_function_filters_and_updates_access(store) -> None:
    _advance_sessions(store, 1)
    first = store.record_executive_event(
        "metacognitive",
        "human contradicted source reading",
        "defended from memory",
        "re-open source before reply",
        "sess-1",
    )
    second = store.record_executive_event(
        "technical",
        "changed auth module",
        "assumed tests passed",
        "run targeted auth tests",
        "sess-2",
    )
    store.update_executive_entry(first["id"], strength=5, last_accessed_at_session=1)
    store.update_executive_entry(second["id"], strength=1, last_accessed_at_session=1)
    _advance_sessions(store, 80)

    before = {e["id"]: e for e in store.get_executive_memory()}
    block = get_learned_executive_function(
        store,
        halflife_sessions=30,
        inject_threshold=0.45,
        decay_threshold=0.3,
        max_entries=10,
        max_tokens=4000,
        min_hold_sessions=3,
    )
    assert block.startswith("## Learned patterns from this project")
    assert "re-open source before reply" in block

    after = {e["id"]: e for e in store.get_executive_memory()}
    current = store.get_session_count()
    assert after[first["id"]]["last_accessed_at_session"] == current
    assert after[second["id"]]["last_accessed_at_session"] == before[second["id"]]["last_accessed_at_session"]


def test_record_stop_failure_event_dedupes_same_signature_and_keeps_first_entry(store) -> None:
    _advance_sessions(store, 1)
    first, signature = record_stop_failure_event(
        store,
        session_id="sess-stop",
        structured_stop_violation=True,
        challenge_coverage_missing=False,
        challenge_report=None,
        requirements_gate_gap=False,
        requirement_audit_report=None,
        truth_claims_report=None,
        invariant_report=None,
    )
    second, second_signature = record_stop_failure_event(
        store,
        session_id="sess-stop",
        structured_stop_violation=True,
        challenge_coverage_missing=False,
        challenge_report=None,
        requirements_gate_gap=False,
        requirement_audit_report=None,
        truth_claims_report=None,
        invariant_report=None,
        previous_signature=signature,
    )
    assert first is not None
    assert second is None
    assert signature == second_signature
    assert len(store.get_executive_memory()) == 1


def test_record_stop_failure_event_priority_prefers_requirements_over_challenge(store) -> None:
    _advance_sessions(store, 1)
    recorded, signature = record_stop_failure_event(
        store,
        session_id="sess-priority",
        structured_stop_violation=False,
        challenge_coverage_missing=True,
        challenge_report={"missing_categories": ["boundary_values"]},
        requirements_gate_gap=True,
        requirement_audit_report={"errors": ["missing evidence"]},
        truth_claims_report={"errors": ["command not observed"]},
        invariant_report={"ok": False},
    )
    assert recorded is not None
    assert recorded["type"] == "technical"
    assert "requirement or truth evidence gap" in recorded["trigger_pattern"]
    assert signature is not None and "requirements_gate_gap" in signature
