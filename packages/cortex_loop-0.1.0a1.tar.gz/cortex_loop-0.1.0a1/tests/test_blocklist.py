"""Tests for cortex.blocklist — deterministic tool denylist.

Covers:
- Default blocked tools (interactive editors, REPLs, debuggers, pagers, hangers)
- Explicit allow overrides
- Fail-closed policy
- Config loading from TOML
- Kernel integration via on_pre_tool_use
"""

from __future__ import annotations

import pytest

from cortex.blocklist import (
    DEFAULT_BLOCKED_TOOLS,
    BlockVerdict,
    evaluate_blocklist,
)
from cortex.core import CortexKernel


# --- Unit tests: evaluate_blocklist ------------------------------------------


class TestEvaluateBlocklist:
    def test_disabled_always_allows(self) -> None:
        v = evaluate_blocklist("vim", enabled=False)
        assert v.blocked is False
        assert v.reason == "blocklist_disabled"

    @pytest.mark.parametrize("tool", sorted(DEFAULT_BLOCKED_TOOLS))
    def test_default_blocked_tools_are_denied(self, tool: str) -> None:
        v = evaluate_blocklist(tool)
        assert v.blocked is True
        assert v.reason == "tool_denied"

    def test_safe_tool_is_allowed(self) -> None:
        v = evaluate_blocklist("Edit")
        assert v.blocked is False
        assert v.reason == "not_in_denylist"

    @pytest.mark.parametrize("tool_name", [None, "", "   ", 123])
    def test_unknown_like_tool_name_is_allowed_by_default(self, tool_name: object | None) -> None:
        v = evaluate_blocklist(tool_name)
        assert v.blocked is False
        assert v.reason == "not_in_denylist"

    def test_case_insensitive_match(self) -> None:
        v = evaluate_blocklist("VIM")
        assert v.blocked is True
        v2 = evaluate_blocklist("Vim")
        assert v2.blocked is True

    def test_explicit_allow_overrides_deny(self) -> None:
        v = evaluate_blocklist(
            "vim",
            allowed_tools=frozenset({"vim"}),
        )
        assert v.blocked is False
        assert v.reason == "explicitly_allowed"

    def test_custom_blocked_tool(self) -> None:
        v = evaluate_blocklist(
            "dangerous_tool",
            blocked_tools=frozenset({"dangerous_tool"}),
        )
        assert v.blocked is True
        assert v.reason == "tool_denied"

    def test_fail_closed_blocks_unknown_tool(self) -> None:
        v = evaluate_blocklist(
            "some_unknown_tool",
            blocked_tools=frozenset(),
            allowed_tools=frozenset({"edit", "read"}),
            fail_closed=True,
        )
        assert v.blocked is True
        assert v.reason == "fail_closed"

    def test_fail_closed_allows_explicit_tool(self) -> None:
        v = evaluate_blocklist(
            "edit",
            blocked_tools=frozenset(),
            allowed_tools=frozenset({"edit"}),
            fail_closed=True,
        )
        assert v.blocked is False
        assert v.reason == "explicitly_allowed"

    def test_fail_closed_off_allows_unknown(self) -> None:
        v = evaluate_blocklist(
            "some_unknown_tool",
            blocked_tools=frozenset(),
            allowed_tools=frozenset({"edit"}),
            fail_closed=False,
        )
        assert v.blocked is False
        assert v.reason == "not_in_denylist"

    def test_allow_takes_precedence_over_deny(self) -> None:
        """If a tool is in both allow and deny, allow wins."""
        v = evaluate_blocklist(
            "vim",
            blocked_tools=frozenset({"vim"}),
            allowed_tools=frozenset({"vim"}),
        )
        assert v.blocked is False
        assert v.reason == "explicitly_allowed"

    def test_verdict_dataclass_fields(self) -> None:
        v = BlockVerdict(blocked=True, reason="test")
        assert v.blocked is True
        assert v.reason == "test"


# --- Unit tests: DEFAULT_BLOCKED_TOOLS completeness --------------------------


class TestDefaultBlockedToolsCompleteness:
    """Verify the default set covers key categories."""

    def test_interactive_editors_present(self) -> None:
        for tool in ("vim", "nvim", "nano", "emacs", "vi"):
            assert tool in DEFAULT_BLOCKED_TOOLS, f"Missing editor: {tool}"

    def test_repls_present(self) -> None:
        for tool in ("python_repl", "ipython", "node_repl", "irb"):
            assert tool in DEFAULT_BLOCKED_TOOLS, f"Missing REPL: {tool}"

    def test_debuggers_present(self) -> None:
        for tool in ("gdb", "lldb", "pdb"):
            assert tool in DEFAULT_BLOCKED_TOOLS, f"Missing debugger: {tool}"

    def test_pagers_present(self) -> None:
        for tool in ("less", "more", "man"):
            assert tool in DEFAULT_BLOCKED_TOOLS, f"Missing pager: {tool}"

    def test_hanging_subprocesses_present(self) -> None:
        for tool in ("ssh", "docker_exec_interactive", "kubectl_exec"):
            assert tool in DEFAULT_BLOCKED_TOOLS, f"Missing hanger: {tool}"

    def test_no_hidden_aliases(self) -> None:
        """Every entry is a plain lowercase string — no regex, no wildcards."""
        for tool in DEFAULT_BLOCKED_TOOLS:
            assert tool == tool.strip().lower()
            assert "*" not in tool
            assert "?" not in tool
            assert "[" not in tool


# --- Config loading tests ----------------------------------------------------


class TestBlocklistConfigLoading:
    def test_default_config_from_genome(self, kernel: CortexKernel) -> None:
        cfg = kernel.ctx.genome.blocklist
        assert cfg.enabled is True
        assert cfg.blocked_tools == []
        assert cfg.allowed_tools == []
        assert cfg.fail_closed is False

    def test_config_with_custom_blocked_tools(self, tmp_path) -> None:
        toml_text = """
[project]
name = "test"

[blocklist]
enabled = true
blocked_tools = ["custom_danger", "my_repl"]
allowed_tools = ["safe_tool"]
fail_closed = true
"""
        (tmp_path / "cortex.toml").write_text(toml_text, encoding="utf-8")
        from cortex.genome import load_genome

        genome = load_genome(tmp_path / "cortex.toml")
        assert genome.blocklist.enabled is True
        assert genome.blocklist.blocked_tools == ["custom_danger", "my_repl"]
        assert genome.blocklist.allowed_tools == ["safe_tool"]
        assert genome.blocklist.fail_closed is True

    def test_config_disabled(self, tmp_path) -> None:
        toml_text = """
[project]
name = "test"

[blocklist]
enabled = false
"""
        (tmp_path / "cortex.toml").write_text(toml_text, encoding="utf-8")
        from cortex.genome import load_genome

        genome = load_genome(tmp_path / "cortex.toml")
        assert genome.blocklist.enabled is False

    def test_missing_blocklist_section_uses_defaults(self, tmp_path) -> None:
        toml_text = """
[project]
name = "test"
"""
        (tmp_path / "cortex.toml").write_text(toml_text, encoding="utf-8")
        from cortex.genome import load_genome

        genome = load_genome(tmp_path / "cortex.toml")
        assert genome.blocklist.enabled is True
        assert genome.blocklist.blocked_tools == []
        assert genome.blocklist.fail_closed is False


# --- Kernel integration tests ------------------------------------------------


class TestKernelBlocklistIntegration:
    def test_pre_tool_use_blocks_default_denied_tool(
        self, kernel: CortexKernel
    ) -> None:
        kernel.on_session_start({"session_id": "sess-bl-1", "objective": "Test blocklist"})
        result = kernel.on_pre_tool_use({
            "session_id": "sess-bl-1",
            "tool_name": "vim",
        })
        assert result["proceed"] is False
        assert any("blocked" in w.lower() for w in result["warnings"])
        assert any("vim" in w.lower() for w in result["warnings"])

    def test_pre_tool_use_allows_safe_tool(
        self, kernel: CortexKernel
    ) -> None:
        kernel.on_session_start({"session_id": "sess-bl-2", "objective": "Test allow"})
        result = kernel.on_pre_tool_use({
            "session_id": "sess-bl-2",
            "tool_name": "Edit",
        })
        assert result["proceed"] is True
        assert not any("blocked" in w.lower() for w in result["warnings"])

    def test_pre_tool_use_blocklist_disabled(
        self, kernel: CortexKernel
    ) -> None:
        kernel.ctx.genome.blocklist.enabled = False
        kernel.on_session_start({"session_id": "sess-bl-3", "objective": "Test disabled"})
        result = kernel.on_pre_tool_use({
            "session_id": "sess-bl-3",
            "tool_name": "vim",
        })
        assert result["proceed"] is True

    def test_pre_tool_use_custom_blocked_tool(
        self, kernel: CortexKernel
    ) -> None:
        kernel.ctx.genome.blocklist.blocked_tools = ["my_dangerous_tool"]
        kernel.on_session_start({"session_id": "sess-bl-4", "objective": "Test custom block"})
        result = kernel.on_pre_tool_use({
            "session_id": "sess-bl-4",
            "tool_name": "my_dangerous_tool",
        })
        assert result["proceed"] is False
        assert any("my_dangerous_tool" in w for w in result["warnings"])

    def test_pre_tool_use_allowed_overrides_default_block(
        self, kernel: CortexKernel
    ) -> None:
        kernel.ctx.genome.blocklist.allowed_tools = ["vim"]
        kernel.on_session_start({"session_id": "sess-bl-5", "objective": "Test allow override"})
        result = kernel.on_pre_tool_use({
            "session_id": "sess-bl-5",
            "tool_name": "vim",
        })
        assert result["proceed"] is True

    def test_pre_tool_use_fail_closed_blocks_unknown(
        self, kernel: CortexKernel
    ) -> None:
        kernel.ctx.genome.blocklist.fail_closed = True
        kernel.ctx.genome.blocklist.allowed_tools = ["edit", "read"]
        kernel.on_session_start({"session_id": "sess-bl-6", "objective": "Test fail-closed"})
        result = kernel.on_pre_tool_use({
            "session_id": "sess-bl-6",
            "tool_name": "SomeNewTool",
        })
        assert result["proceed"] is False
        assert any("fail_closed" in w for w in result["warnings"])

    def test_pre_tool_use_fail_closed_allows_explicit(
        self, kernel: CortexKernel
    ) -> None:
        kernel.ctx.genome.blocklist.fail_closed = True
        kernel.ctx.genome.blocklist.allowed_tools = ["edit"]
        kernel.on_session_start({"session_id": "sess-bl-7", "objective": "Test fail-closed allow"})
        result = kernel.on_pre_tool_use({
            "session_id": "sess-bl-7",
            "tool_name": "Edit",
        })
        assert result["proceed"] is True

    def test_pre_tool_use_case_insensitive_block(
        self, kernel: CortexKernel
    ) -> None:
        kernel.on_session_start({"session_id": "sess-bl-ci", "objective": "Test case"})
        result = kernel.on_pre_tool_use({
            "session_id": "sess-bl-ci",
            "tool_name": "VIM",
        })
        assert result["proceed"] is False

    @pytest.mark.parametrize(
        ("session_id", "payload"),
        [
            ("sess-bl-empty", {"tool_name": ""}),
            ("sess-bl-none", {}),
            ("sess-bl-num", {"tool_name": 123}),
        ],
    )
    def test_pre_tool_use_unknown_like_tool_name_not_blocked_by_default(
        self, kernel: CortexKernel, session_id: str, payload: dict[str, object]
    ) -> None:
        kernel.on_session_start({"session_id": session_id, "objective": "Test unknown-like"})
        result = kernel.on_pre_tool_use({"session_id": session_id, **payload})
        assert result["proceed"] is True
