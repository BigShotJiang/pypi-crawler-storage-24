from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def _load_repo_hygiene_module():
    script = ROOT / "scripts" / "repo_workflow.py"
    sys.path.insert(0, str(script.parent))
    spec = importlib.util.spec_from_file_location("repo_workflow", script)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _git(repo: Path, *args: str) -> None:
    subprocess.run(["git", *args], cwd=repo, check=True, capture_output=True, text=True)


def _git_output(repo: Path, *args: str) -> str:
    run = subprocess.run(["git", *args], cwd=repo, check=True, capture_output=True, text=True)
    return run.stdout.strip()


def _prepare_repo(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    repo = tmp_path / "repo"
    repo.mkdir()
    _git(repo, "init", "-b", "main")
    _git(repo, "config", "user.name", "Cortex Test")
    _git(repo, "config", "user.email", "cortex@example.com")
    (repo / "README.md").write_text("base\n", encoding="utf-8")
    _git(repo, "add", "README.md")
    _git(repo, "commit", "-m", "repo: initialize temp repo")

    module = _load_repo_hygiene_module()
    monkeypatch.setenv(module.ROOT_ENV_VAR, str(repo))
    return repo, module


def test_start_session_from_clean_main_creates_managed_branch(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    repo, module = _prepare_repo(tmp_path, monkeypatch)
    monkeypatch.setattr(module, "_session_timestamp", lambda: "20260306-123456")

    module.cmd_start_session("codex", "Testing Session")

    assert _git_output(repo, "branch", "--show-current") == "codex/20260306-123456-testing-session"
    assert capsys.readouterr().out.strip() == "codex/20260306-123456-testing-session"


def test_start_session_refuses_dirty_tree(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo, module = _prepare_repo(tmp_path, monkeypatch)
    (repo / "README.md").write_text("dirty\n", encoding="utf-8")

    with pytest.raises(SystemExit, match="Working tree is not clean"):
        module.cmd_start_session("codex", None)

    assert _git_output(repo, "branch", "--show-current") == "main"


def test_start_session_refuses_unmerged_non_main_branch(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo, module = _prepare_repo(tmp_path, monkeypatch)
    _git(repo, "switch", "-c", "maint/manual-work")
    (repo / "manual.txt").write_text("manual\n", encoding="utf-8")
    _git(repo, "add", "manual.txt")
    _git(repo, "commit", "-m", "docs: record manual work")

    with pytest.raises(SystemExit, match="Finish or reconcile it manually"):
        module.cmd_start_session("codex", "new-session")

    assert _git_output(repo, "branch", "--show-current") == "maint/manual-work"


def test_start_session_replaces_clean_merged_managed_branch(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    repo, module = _prepare_repo(tmp_path, monkeypatch)
    monkeypatch.setattr(module, "_session_timestamp", lambda: "20260306-000001")
    module.cmd_start_session("codex", "old")
    old_branch = _git_output(repo, "branch", "--show-current")
    _git(repo, "switch", "main")
    _git(repo, "switch", old_branch)

    monkeypatch.setattr(module, "_session_timestamp", lambda: "20260306-123456")
    module.cmd_start_session("codex", "new")

    assert _git_output(repo, "branch", "--show-current") == "codex/20260306-123456-new"
    assert _git_output(repo, "branch", "--list", old_branch) == ""


def test_close_session_with_no_changes_returns_to_main_and_deletes_branch(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    repo, module = _prepare_repo(tmp_path, monkeypatch)
    monkeypatch.setattr(module, "_session_timestamp", lambda: "20260306-123456")
    module.cmd_start_session("codex", "noop")
    branch = _git_output(repo, "branch", "--show-current")

    module.cmd_close_session("docs: no-op closeout", None)

    assert _git_output(repo, "branch", "--show-current") == "main"
    assert _git_output(repo, "branch", "--list", branch) == ""
    assert capsys.readouterr().out.strip().endswith("no-op clean tree")


def test_close_session_with_tracked_changes_commits_merges_and_deletes_branch(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    repo, module = _prepare_repo(tmp_path, monkeypatch)
    monkeypatch.setattr(module, "_session_timestamp", lambda: "20260306-123456")
    monkeypatch.setattr(module, "_run_check_phases", lambda _phases: None)
    module.cmd_start_session("codex", "tracked-changes")
    branch = _git_output(repo, "branch", "--show-current")
    (repo / "README.md").write_text("changed\n", encoding="utf-8")

    module.cmd_close_session("docs: tighten session wording", None)

    assert _git_output(repo, "branch", "--show-current") == "main"
    assert _git_output(repo, "branch", "--list", branch) == ""
    assert _git_output(repo, "log", "-1", "--pretty=%s") == "docs: tighten session wording"
    assert (repo / "README.md").read_text(encoding="utf-8") == "changed\n"


def test_close_session_lands_existing_clean_session_commit(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    repo, module = _prepare_repo(tmp_path, monkeypatch)
    monkeypatch.setattr(module, "_session_timestamp", lambda: "20260306-123456")
    module.cmd_start_session("codex", "existing-commit")
    branch = _git_output(repo, "branch", "--show-current")
    (repo / "existing.txt").write_text("existing\n", encoding="utf-8")
    _git(repo, "add", "existing.txt")
    _git(repo, "commit", "-m", "docs: add existing session commit")

    module.cmd_close_session("docs: close existing session commit", None)

    assert _git_output(repo, "branch", "--show-current") == "main"
    assert _git_output(repo, "branch", "--list", branch) == ""
    assert _git_output(repo, "log", "-1", "--pretty=%s") == "docs: add existing session commit"


def test_close_session_aborts_safely_when_main_moves(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    repo, module = _prepare_repo(tmp_path, monkeypatch)
    monkeypatch.setattr(module, "_session_timestamp", lambda: "20260306-123456")
    module.cmd_start_session("codex", "diverged")
    branch = _git_output(repo, "branch", "--show-current")
    (repo / "session.txt").write_text("session-side\n", encoding="utf-8")
    _git(repo, "add", "session.txt")
    _git(repo, "commit", "-m", "docs: session side change")

    _git(repo, "switch", "main")
    (repo / "main.txt").write_text("main-side\n", encoding="utf-8")
    _git(repo, "add", "main.txt")
    _git(repo, "commit", "-m", "docs: main side change")
    main_head = _git_output(repo, "rev-parse", "main")
    _git(repo, "switch", branch)

    with pytest.raises(SystemExit, match="Unable to fast-forward main from session branch"):
        module.cmd_close_session("docs: close diverged session", None)

    assert _git_output(repo, "branch", "--show-current") == branch
    assert branch in _git_output(repo, "branch", "--list", branch)
    assert _git_output(repo, "rev-parse", "main") == main_head
