from __future__ import annotations

from pathlib import Path

from cortex.genome import load_genome


def test_loads_valid_toml(tmp_project: Path) -> None:
    genome = load_genome(tmp_project / "cortex.toml")
    assert genome.parse_error is None
    assert genome.project.name == "test-app"
    assert genome.project.type == "python"
    assert genome.project.trust_profile == "trusted"
    assert genome.invariants.suite_paths == ["tests/invariants/sample_test.py"]
    assert genome.invariants.run_on_stop is False
    assert genome.invariants.execution_mode == "host"
    assert genome.invariants.graduation.target_dir == "tests/invariants/graduated"
    assert genome.challenges.active_categories == [
        "null_inputs",
        "boundary_values",
        "error_handling",
        "graveyard_regression",
    ]
    assert genome.challenges.custom_paths == [".cortex/challenges/custom.toml"]
    assert genome.graveyard.max_matches == 3
    assert genome.graveyard.similarity_threshold == 0.2
    assert genome.graveyard.context_max_matches == 2
    assert genome.graveyard.context_summary_chars == 130
    assert genome.graveyard.context_reason_chars == 180
    assert genome.graveyard.context_max_tokens == 260
    assert genome.foundation.watch_paths == ["src", "pkg"]
    assert genome.foundation.stability_thresholds.warn_churn_count == 2
    assert genome.foundation.stability_thresholds.high_churn_count == 4
    assert genome.foundation.git_timeout_ms == 1500
    assert genome.repomap.enabled is True
    assert genome.repomap.run_on_session_start is True
    assert genome.repomap.prefer_ast_graph is True
    assert genome.repomap.parity_profile is False
    assert genome.repomap.extended_language_profile is False
    assert genome.repomap.watch_paths == ["src", "pkg"]
    assert genome.repomap.max_ranked_files == 12
    assert genome.repomap.max_text_bytes == 4096
    assert genome.repomap.session_start_timeout_ms == 1800
    assert genome.runtime.adapter == "cortex.adapters:GenericAdapter"
    assert genome.executive.enabled is True
    assert genome.executive.inject_identity_preamble is True
    assert genome.executive.part_a_mode == "once_per_project"
    assert genome.executive.halflife_sessions == 40
    assert genome.executive.decay_threshold == 0.25
    assert genome.executive.inject_threshold == 0.5
    assert genome.executive.max_entries == 30
    assert genome.executive.max_tokens == 1500
    assert genome.executive.min_hold_sessions == 2
    assert genome.hooks.mode == "advisory"
    assert genome.hooks.require_requirement_audit is False
    assert genome.hooks.fail_on_requirement_audit_gap is False
    assert genome.hooks.require_evidence_for_passed_requirement is True
    assert genome.hooks.require_structured_stop_payload is False
    assert genome.hooks.allow_message_stop_fallback is False
    assert genome.hooks.minimal_response is False
    assert genome.metrics.track[-1] == "foundation_quality"


def test_returns_defaults_when_file_missing(tmp_path: Path) -> None:
    missing = tmp_path / "missing.toml"
    genome = load_genome(missing)
    assert genome.parse_error is None
    assert genome.source_path == str(missing)
    assert genome.project.name == "unknown-project"
    assert genome.project.trust_profile == "trusted"
    assert genome.foundation.watch_paths == ["src"]
    assert genome.repomap.enabled is False
    assert genome.repomap.prefer_ast_graph is True
    assert genome.repomap.parity_profile is False
    assert genome.repomap.extended_language_profile is False
    assert genome.repomap.artifact_path == ".cortex/artifacts/repomap/latest.json"
    assert genome.runtime.adapter == ""
    assert genome.executive.enabled is True
    assert genome.executive.inject_identity_preamble is True
    assert genome.executive.halflife_sessions == 30
    assert genome.executive.decay_threshold == 0.3
    assert genome.executive.inject_threshold == 0.45
    assert genome.executive.max_entries == 20
    assert genome.executive.max_tokens == 1200
    assert genome.executive.min_hold_sessions == 3
    assert genome.executive.part_a_mode == "once_per_project"
    assert genome.graveyard.context_max_matches == 2
    assert genome.graveyard.context_summary_chars == 140
    assert genome.graveyard.context_reason_chars == 200
    assert genome.graveyard.context_max_tokens == 300


def test_returns_defaults_with_parse_error_on_invalid_toml(tmp_path: Path) -> None:
    bad = tmp_path / "cortex.toml"
    bad.write_text("[project]\nname = 'ok'\ninvalid = [\n", encoding="utf-8")
    genome = load_genome(bad)
    assert genome.project.name == "unknown-project"
    assert genome.parse_error
    assert genome.source_path == str(bad)


def test_section_type_mismatches_fall_back_to_defaults(tmp_path: Path) -> None:
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [project]
        name = "demo"

        [invariants]
        execution_mode = "invalid"

        [foundation]
        watch_paths = "not-a-list"
        churn_window_commits = "bad"

        [graveyard]
        similarity_threshold = "bad"

        [repomap]
        enabled = "not-bool"
        watch_paths = "not-a-list"
        max_ranked_files = "bad"
        max_text_bytes = "bad"
        """,
        encoding="utf-8",
    )
    genome = load_genome(cfg)
    assert genome.project.name == "demo"
    assert genome.project.trust_profile == "trusted"
    assert genome.invariants.execution_mode == "host"
    assert genome.foundation.watch_paths == ["src"]
    assert genome.foundation.churn_window_commits == 200
    assert genome.foundation.git_timeout_ms == 1500
    assert genome.graveyard.similarity_threshold == 0.35
    assert genome.graveyard.context_max_matches == 2
    assert genome.graveyard.context_summary_chars == 140
    assert genome.graveyard.context_reason_chars == 200
    assert genome.graveyard.context_max_tokens == 300
    assert genome.repomap.enabled is False
    assert genome.repomap.prefer_ast_graph is True
    assert genome.repomap.parity_profile is False
    assert genome.repomap.extended_language_profile is False
    assert genome.repomap.watch_paths == ["src"]
    assert genome.repomap.max_ranked_files == 20
    assert genome.repomap.max_text_bytes == 8192


def test_loads_hooks_requirement_audit_fields(tmp_path: Path) -> None:
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [hooks]
        mode = "strict"
        require_requirement_audit = true
        fail_on_requirement_audit_gap = true
        require_evidence_for_passed_requirement = false
        require_structured_stop_payload = true
        allow_message_stop_fallback = false
        minimal_response = true
        """,
        encoding="utf-8",
    )
    genome = load_genome(cfg)
    assert genome.hooks.mode == "strict"
    assert genome.hooks.require_requirement_audit is True
    assert genome.hooks.fail_on_requirement_audit_gap is True
    assert genome.hooks.require_evidence_for_passed_requirement is False
    assert genome.hooks.require_structured_stop_payload is True
    assert genome.hooks.allow_message_stop_fallback is False
    assert genome.hooks.minimal_response is True


def test_loads_runtime_adapter_path(tmp_path: Path) -> None:
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [runtime]
        adapter = "cortex.adapters.claude:ClaudeAdapter"
        """,
        encoding="utf-8",
    )
    genome = load_genome(cfg)
    assert genome.runtime.adapter == "cortex.adapters.claude:ClaudeAdapter"


def test_loads_executive_config_section(tmp_path: Path) -> None:
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [executive]
        enabled = false
        inject_identity_preamble = false
        part_a_mode = "always"
        halflife_sessions = 25
        decay_threshold = 0.2
        inject_threshold = 0.55
        max_entries = 12
        max_tokens = 900
        min_hold_sessions = 1
        """,
        encoding="utf-8",
    )
    genome = load_genome(cfg)
    assert genome.executive.enabled is False
    assert genome.executive.inject_identity_preamble is False
    assert genome.executive.part_a_mode == "always"
    assert genome.executive.halflife_sessions == 25
    assert genome.executive.decay_threshold == 0.2
    assert genome.executive.inject_threshold == 0.55
    assert genome.executive.max_entries == 12
    assert genome.executive.max_tokens == 900
    assert genome.executive.min_hold_sessions == 1


def test_invalid_part_a_mode_falls_back_to_default(tmp_path: Path) -> None:
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [executive]
        part_a_mode = "invalid"
        """,
        encoding="utf-8",
    )
    genome = load_genome(cfg)
    assert genome.executive.part_a_mode == "once_per_project"


def test_loads_repomap_parity_profile_field(tmp_path: Path) -> None:
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [repomap]
        enabled = true
        prefer_ast_graph = true
        parity_profile = true
        extended_language_profile = true
        """,
        encoding="utf-8",
    )
    genome = load_genome(cfg)
    assert genome.repomap.enabled is True
    assert genome.repomap.prefer_ast_graph is True
    assert genome.repomap.parity_profile is True
    assert genome.repomap.extended_language_profile is True


def test_loads_project_trust_profile_preserves_invalid_raw_token(tmp_path: Path) -> None:
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [project]
        trust_profile = "untrusted"
        """,
        encoding="utf-8",
    )
    genome = load_genome(cfg)
    assert genome.project.trust_profile == "untrusted"

    cfg.write_text(
        """
        [project]
        trust_profile = "invalid"
        """,
        encoding="utf-8",
    )
    genome = load_genome(cfg)
    assert genome.project.trust_profile == "invalid"


def test_loads_pack_declarations_into_stop_path_surfaces(tmp_path: Path) -> None:
    (tmp_path / "packs").mkdir(parents=True, exist_ok=True)
    (tmp_path / "packs" / "python_service.toml").write_text(
        "\n".join(
            [
                'schema = "cortex_pack_v1"',
                'pack_id = "python_service"',
                'challenge_categories = ["api_contracts", "input_validation"]',
                'invariant_paths = ["tests/packs/python_service/test_python_service_pack_invariants.py"]',
                'blocked_tools = ["python_repl"]',
                'allowed_tools = ["read"]',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [invariants]
        suite_paths = ["tests/invariants/base.py"]

        [challenges]
        active_categories = ["null_inputs"]

        [blocklist]
        blocked_tools = ["vim"]

        [packs]
        paths = ["packs/python_service.toml"]
        """,
        encoding="utf-8",
    )

    genome = load_genome(cfg)

    assert genome.parse_error is None
    assert genome.load_warnings == []
    assert genome.packs.paths == ["packs/python_service.toml"]
    assert genome.challenges.active_categories == ["null_inputs", "api_contracts", "input_validation"]
    assert genome.invariants.suite_paths == [
        "tests/invariants/base.py",
        "tests/packs/python_service/test_python_service_pack_invariants.py",
    ]
    assert genome.blocklist.blocked_tools == ["vim", "python_repl"]
    assert genome.blocklist.allowed_tools == ["read"]


def test_missing_pack_manifest_is_warning_not_parse_error(tmp_path: Path) -> None:
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [packs]
        paths = ["packs/does_not_exist.toml"]
        """,
        encoding="utf-8",
    )

    genome = load_genome(cfg)

    assert genome.parse_error is None
    assert genome.packs.paths == ["packs/does_not_exist.toml"]
    assert len(genome.load_warnings) == 1
    assert "Pack manifest not found" in genome.load_warnings[0]


def test_pack_with_unsupported_schema_is_skipped_with_warning(tmp_path: Path) -> None:
    (tmp_path / "packs").mkdir(parents=True, exist_ok=True)
    (tmp_path / "packs" / "bad.toml").write_text(
        '\n'.join(['schema = "cortex_pack_v0"', 'challenge_categories = ["api_contracts"]']) + "\n",
        encoding="utf-8",
    )
    cfg = tmp_path / "cortex.toml"
    cfg.write_text(
        """
        [challenges]
        active_categories = ["null_inputs"]

        [packs]
        paths = ["packs/bad.toml"]
        """,
        encoding="utf-8",
    )

    genome = load_genome(cfg)

    assert genome.challenges.active_categories == ["null_inputs"]
    assert len(genome.load_warnings) == 1
    assert "Unsupported pack schema" in genome.load_warnings[0]
