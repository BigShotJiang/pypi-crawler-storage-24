from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONTRACT_PATH = ROOT / "docs" / "ADAPTER_VALIDATION.md"
FIXTURES_DIR = ROOT / "tests" / "fixtures" / "adapter_validation"


def test_adapter_validation_contract_locks_authority_split_and_supporting_proof() -> None:
    text = CONTRACT_PATH.read_text(encoding="utf-8")

    assert "It does not replace [ADAPTERS.md](ADAPTERS.md)" in text
    assert "supporting proof only" in text
    assert "does not populate the readiness table" in text
    assert "This table starts at `Unvalidated` and only changes when live evidence exists." in text


def test_adapter_validation_contract_lists_shared_harness_patch_and_stop_rendering_rules() -> None:
    text = CONTRACT_PATH.read_text(encoding="utf-8")

    for token in (
        '`project.trust_profile = "trusted"`',
        '`invariants.execution_mode = "host"`',
        "`repomap.enabled = true`",
        "`repomap.prefer_ast_graph = false`",
        '`hooks.mode = "strict"`',
        "`hooks.fail_on_missing_challenge_coverage = true`",
        "`hooks.require_requirement_audit = true`",
        "`hooks.fail_on_requirement_audit_gap = true`",
        "`hooks.require_evidence_for_passed_requirement = true`",
        "`hooks.require_structured_stop_payload = true`",
        "`hooks.allow_message_stop_fallback = false`",
        "Claude Stop hooks deliver completion evidence through `last_assistant_message`",
        "Gemini pass and negative lanes may use `STOP_FIELDS_JSON`",
        "OpenAI pass and negative lanes may use `STOP_FIELDS_JSON`",
    ):
        assert token in text


def test_adapter_validation_contract_locks_scenarios_and_evidence_fields() -> None:
    text = CONTRACT_PATH.read_text(encoding="utf-8")

    scenario_tokens = (
        "`install_bootstrap`",
        "`check_wiring`",
        "`pass_minimal`",
        "`structured_gap`",
        "`truth_gap`",
        "`adapter_caveat`",
    )
    for token in scenario_tokens:
        assert token in text

    required_nested_fields = (
        "`runtime.profile`",
        "`runtime.surface`",
        "`runtime.adapter_path`",
        "`environment.execution_mode`",
        "`commands.test`",
        "`observed.hook_sequence`",
        "`observed.session_status`",
        "`observed.challenge_coverage_missing`",
        "`artifacts.session_events`",
        "`artifacts.status_artifact`",
        "`artifacts.prompt_template`",
        "`artifacts.raw_capture_sha256`",
        "`provenance.captured_with.cli`",
        "`provenance.captured_with.model`",
    )
    for token in required_nested_fields:
        assert token in text

    readiness_header = (
        "| Adapter | `install_bootstrap` | `check_wiring` | `pass_minimal` | "
        "`structured_gap` | `truth_gap` | `adapter_caveat` | Classification | "
        "Caveats | Evidence refs | Last validated |"
    )
    assert readiness_header in text


def test_adapter_validation_fixture_layout_exists() -> None:
    expected_paths = (
        FIXTURES_DIR / "project_template" / "README_TASK.md",
        FIXTURES_DIR / "project_template" / "pyproject.toml",
        FIXTURES_DIR / "project_template" / "src" / "normalize_port.py",
        FIXTURES_DIR / "project_template" / "tests" / "test_normalize_port.py",
        FIXTURES_DIR / "project_template" / ".cortex" / "artifacts" / "repomap" / "latest.json",
        FIXTURES_DIR / "prompts" / "pass_minimal.md",
        FIXTURES_DIR / "prompts" / "structured_gap.md",
        FIXTURES_DIR / "prompts" / "truth_gap.md",
        FIXTURES_DIR / "prompts" / "claude_note.md",
        FIXTURES_DIR / "prompts" / "gemini_note.md",
        FIXTURES_DIR / "prompts" / "openai_note.md",
        FIXTURES_DIR / "claude" / "PROVENANCE.json",
        FIXTURES_DIR / "gemini" / "PROVENANCE.json",
        FIXTURES_DIR / "openai" / "PROVENANCE.json",
    )
    for path in expected_paths:
        assert path.exists(), str(path)


def test_adapter_validation_gemini_note_locks_strict_stop_guidance() -> None:
    text = (FIXTURES_DIR / "prompts" / "gemini_note.md").read_text(encoding="utf-8")

    assert "one-line `STOP_FIELDS_JSON` in the final response itself" in text
    assert "shell command" in text
    assert "bare booleans are not enough" in text
    for token in ("`stuck_declaration`", "`truth_claims`", "`requirement_audit`"):
        assert token in text


def test_adapter_validation_openai_note_locks_strict_stop_guidance() -> None:
    text = (FIXTURES_DIR / "prompts" / "openai_note.md").read_text(encoding="utf-8")

    assert "exact literal prefix `STOP_FIELDS_JSON:`" in text
    assert "structured_gap" in text
    assert "follow the scenario prompt" in text
    assert "shell command" in text
    assert "bare booleans are not enough" in text
    assert "repo-relative file refs with line numbers" in text
    assert "Do not use pytest node ids" in text
    assert '`status: "pass"` or' in text
    assert '`status: "fail"`' in text
    for token in ("`stuck_declaration`", "`truth_claims`", "`requirement_audit`"):
        assert token in text
