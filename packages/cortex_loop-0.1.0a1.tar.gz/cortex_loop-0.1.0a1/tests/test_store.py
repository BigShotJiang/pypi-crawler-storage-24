from __future__ import annotations

import json
import sqlite3
import time
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from hashlib import sha256
from pathlib import Path

from cortex.store import SQLiteStore


def _table_names(store: SQLiteStore) -> set[str]:
    with store.connection() as conn:
        rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    return {row["name"] for row in rows}


def _retry_budget_state(*, attempts: int, reason_attempts: int, max_retries: int, reason_limit: int) -> dict[str, int | str]:
    remaining = max(0, int(max_retries) - int(attempts))
    reason_remaining = max(0, int(reason_limit) - int(reason_attempts))
    decision_code = "retry_allowed"
    if remaining <= 0:
        decision_code = "session_budget_exhausted"
    elif reason_remaining <= 0:
        decision_code = "reason_budget_exhausted"
    return {
        "attempts": int(attempts),
        "reason_attempts": int(reason_attempts),
        "remaining": remaining,
        "reason_remaining": reason_remaining,
        "budget_remaining": min(remaining, reason_remaining),
        "decision_code": decision_code,
    }


def _consume_retry_slot_with_reason(
    store: SQLiteStore,
    session_id: str,
    *,
    max_retries: int,
    reason: str,
    reason_limit: int,
    consume: bool = True,
) -> dict[str, int | bool | str]:
    for _ in range(16):
        attempts = store.get_retry_attempts(session_id, reason=reason)
        state = _retry_budget_state(
            attempts=int(attempts["attempts"]),
            reason_attempts=int(attempts["reason_attempts"]),
            max_retries=max_retries,
            reason_limit=reason_limit,
        )
        if state["decision_code"] != "retry_allowed" or not consume:
            return {"consumed": False, **state}
        write = store.try_increment_retry_attempts(
            session_id,
            reason=reason,
            expected_attempts=int(state["attempts"]),
            expected_reason_attempts=int(state["reason_attempts"]),
        )
        if bool(write["consumed"]):
            post = _retry_budget_state(
                attempts=int(write["attempts"]),
                reason_attempts=int(write["reason_attempts"]),
                max_retries=max_retries,
                reason_limit=reason_limit,
            )
            return {"consumed": True, **post}
    final_attempts = store.get_retry_attempts(session_id, reason=reason)
    final_state = _retry_budget_state(
        attempts=int(final_attempts["attempts"]),
        reason_attempts=int(final_attempts["reason_attempts"]),
        max_retries=max_retries,
        reason_limit=reason_limit,
    )
    return {"consumed": False, **final_state}


def test_initialize_creates_tables(store: SQLiteStore) -> None:
    names = _table_names(store)
    assert {
        "sessions",
        "graveyard",
        "invariants",
        "challenge_results",
        "events",
        "cortex_meta",
        "executive_memory",
    } <= names


def test_session_counter_defaults_and_increments(store: SQLiteStore) -> None:
    assert store.get_session_count() == 0
    assert store.increment_session_counter() == 1
    assert store.increment_session_counter() == 2
    assert store.increment_session_counter() == 3
    assert store.get_session_count() == 3


def test_claim_meta_once_returns_true_then_false(store: SQLiteStore) -> None:
    assert store.claim_meta_once("executive.part_a_injected") is True
    assert store.claim_meta_once("executive.part_a_injected") is False


def test_claim_meta_once_is_concurrency_safe(tmp_path) -> None:
    store = _make_stress_store(tmp_path)

    def _claim() -> bool:
        return store.claim_meta_once("executive.part_a_injected")

    with ThreadPoolExecutor(max_workers=10) as pool:
        outcomes = list(pool.map(lambda _: _claim(), range(40)))
    assert sum(1 for item in outcomes if item) == 1


def test_allocate_session_counter_is_idempotent_and_monotonic(store: SQLiteStore) -> None:
    assert store.allocate_session_counter("sess-a") == 1
    assert store.allocate_session_counter("sess-a") == 1
    assert store.allocate_session_counter("sess-b") == 2
    assert store.allocate_session_counter("sess-c") == 3
    assert store.get_session_count() == 3


def test_allocate_session_counter_is_concurrency_safe_for_same_session(tmp_path) -> None:
    store = _make_stress_store(tmp_path)

    def _allocate() -> int:
        return store.allocate_session_counter("sess-race")

    with ThreadPoolExecutor(max_workers=10) as pool:
        values = list(pool.map(lambda _: _allocate(), range(40)))
    assert set(values) == {1}
    assert store.get_session_count() == 1


def test_claim_executive_stop_signature_semantics(store: SQLiteStore) -> None:
    assert store.claim_executive_stop_signature("sess-sig", "sig-a") is True
    assert store.claim_executive_stop_signature("sess-sig", "sig-a") is False
    assert store.claim_executive_stop_signature("sess-sig", "sig-b") is True


def test_claim_executive_stop_signature_is_concurrency_safe(tmp_path) -> None:
    store = _make_stress_store(tmp_path)

    def _claim() -> bool:
        return store.claim_executive_stop_signature("sess-race", "sig-race")

    with ThreadPoolExecutor(max_workers=10) as pool:
        outcomes = list(pool.map(lambda _: _claim(), range(40)))
    assert sum(1 for item in outcomes if item) == 1


def test_close_session_cleans_transient_session_state(store: SQLiteStore) -> None:
    store.upsert_session_start("sess-old", "running", "cortex.toml", {"phase": "start"})
    store.allocate_session_counter("sess-old")
    assert store.claim_executive_stop_signature("sess-old", "sig-old") is True
    store.close_session("sess-old", "pass", {"phase": "stop"})

    store.upsert_session_start("sess-clean", "running", "cortex.toml", {"phase": "start"})
    assert store.allocate_session_counter("sess-clean") == 2
    assert store.claim_executive_stop_signature("sess-clean", "sig-a") is True
    store.close_session("sess-clean", "pass", {"phase": "stop"})
    with store.connection() as conn:
        alloc_old = conn.execute(
            "SELECT counter FROM session_counter_allocations WHERE session_id = ?",
            ("sess-old",),
        ).fetchone()
        alloc_clean = conn.execute(
            "SELECT counter FROM session_counter_allocations WHERE session_id = ?",
            ("sess-clean",),
        ).fetchone()
        sig_old = conn.execute(
            "SELECT signature FROM executive_stop_signatures WHERE session_id = ?",
            ("sess-old",),
        ).fetchone()
        sig_clean = conn.execute(
            "SELECT signature FROM executive_stop_signatures WHERE session_id = ?",
            ("sess-clean",),
        ).fetchone()
    assert alloc_old is None
    assert alloc_clean is None
    assert sig_old is None
    assert sig_clean is not None and sig_clean["signature"] == "sig-a"


def test_initialize_purges_stale_transient_session_state(tmp_path) -> None:
    store = SQLiteStore(tmp_path / ".cortex" / "test.db")
    store.initialize()
    with store.connection() as conn:
        conn.execute(
            """
            INSERT INTO sessions (session_id, started_at, ended_at, status, genome_path, metadata_json)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            ("sess-stale", "2026-03-01T00:00:00+00:00", "2026-03-01T00:10:00+00:00", "pass", "cortex.toml", "{}"),
        )
        conn.execute(
            "INSERT INTO session_counter_allocations (session_id, counter) VALUES (?, ?)",
            ("sess-stale", 11),
        )
        conn.execute(
            "INSERT INTO executive_stop_signatures (session_id, signature, updated_at) VALUES (?, ?, ?)",
            ("sess-stale", "sig-stale", "2026-03-01T00:10:00+00:00"),
        )
    store.initialize()
    with store.connection() as conn:
        alloc = conn.execute(
            "SELECT counter FROM session_counter_allocations WHERE session_id = ?",
            ("sess-stale",),
        ).fetchone()
        sig = conn.execute(
            "SELECT signature FROM executive_stop_signatures WHERE session_id = ?",
            ("sess-stale",),
        ).fetchone()
    assert alloc is None
    assert sig is None


def test_executive_memory_crud_round_trip(store: SQLiteStore) -> None:
    store.increment_session_counter()
    entry = store.record_executive_event(
        "metacognitive",
        "human contradicted file claim",
        "defended without re-read",
        "re-open file and verify claim",
        "sess-exec-1",
    )
    assert entry["created_at_session"] == 1
    assert entry["last_accessed_at_session"] == 1
    items = store.get_executive_memory()
    assert len(items) == 1
    assert items[0]["id"] == entry["id"]
    assert items[0]["strength"] == 1

    store.update_executive_entry(
        entry["id"],
        strength=4,
        last_accessed_at_session=7,
    )
    updated = store.get_executive_memory()
    assert updated[0]["strength"] == 4
    assert updated[0]["last_accessed_at_session"] == 7

    store.delete_executive_entries([entry["id"]])
    assert store.get_executive_memory() == []


def test_session_upsert_and_close_round_trip(store: SQLiteStore) -> None:
    store.upsert_session_start("sess-1", "running", "cortex.toml", {"phase": "start"})
    store.close_session("sess-1", "completed", {"phase": "stop"})

    with store.connection() as conn:
        row = conn.execute("SELECT * FROM sessions WHERE session_id = ?", ("sess-1",)).fetchone()

    assert row["status"] == "completed"
    assert row["genome_path"] == "cortex.toml"
    assert row["started_at"]
    assert row["ended_at"]
    assert json.loads(row["metadata_json"]) == {"phase": "stop"}


def test_store_does_not_compute_session_status_semantics(store: SQLiteStore) -> None:
    store.upsert_session_start("sess-status", "running", "cortex.toml", {"phase": "start"})
    store.close_session("sess-status", "policy_custom_status", {"phase": "stop"})

    with store.connection() as conn:
        row = conn.execute("SELECT status FROM sessions WHERE session_id = ?", ("sess-status",)).fetchone()
    assert row["status"] == "policy_custom_status"


def test_sessions_query_filters_by_status_and_preserves_recent_order(store: SQLiteStore) -> None:
    store.upsert_session_start("sess-old", "running", "cortex.toml", {})
    time.sleep(0.01)
    store.upsert_session_start("sess-new", "running", "cortex.toml", {})
    store.close_session("sess-new", "completed", {})
    with store.connection() as conn:
        rows = conn.execute(
            """
            SELECT session_id
            FROM sessions
            WHERE status = ?
            ORDER BY started_at DESC
            LIMIT ?
            """,
            ("running", 10),
        ).fetchall()
    assert [str(row["session_id"]) for row in rows] == ["sess-old"]


def test_events_query_returns_payload_objects(store: SQLiteStore) -> None:
    store.record_event(
        "sess-events",
        "SessionMarker",
        {"label": "audit_complete", "created_at": "spoofed"},
    )
    store.record_event(
        "sess-events",
        "PostToolUse",
        {"changed_files": ["src/x.py"]},
        tool_name="Edit",
        status="ok",
    )
    with store.connection() as conn:
        rows = conn.execute(
            """
            SELECT hook, payload_json
            FROM events
            WHERE session_id = ? AND hook IN (?, ?)
            ORDER BY created_at ASC, id ASC
            """,
            ("sess-events", "SessionMarker", "PostToolUse"),
        ).fetchall()
    assert [str(row["hook"]) for row in rows] == ["SessionMarker", "PostToolUse"]
    assert json.loads(rows[0]["payload_json"]) == {"label": "audit_complete", "created_at": "spoofed"}
    assert json.loads(rows[1]["payload_json"]) == {"changed_files": ["src/x.py"]}


def test_graveyard_round_trip(store: SQLiteStore) -> None:
    store.insert_graveyard(
        session_id="sess-1",
        summary="Tried eager cache invalidation",
        reason="Race condition under concurrent writes",
        files=["src/cache.py", "src/service.py"],
        keywords=["cache", "invalidation", "race"],
    )
    rows = store.list_graveyard()
    assert len(rows) == 1
    row = rows[0]
    assert row["session_id"] == "sess-1"
    assert row["files"] == ["src/cache.py", "src/service.py"]
    assert row["keywords"] == ["cache", "invalidation", "race"]


def test_record_event_invariant_and_challenge_results(store: SQLiteStore) -> None:
    store.record_event("sess-1", "PreToolUse", {"tool": "Edit", "path": "x.py"}, tool_name="Edit", status="ok")
    store.record_invariant_result("sess-1", "tests/invariants/test_x.py", "pass", 12, "ok", "")
    store.record_challenge_result("sess-1", "null_inputs", True, {"tests": ["test_null"]})

    with store.connection() as conn:
        event = conn.execute("SELECT * FROM events WHERE session_id = ?", ("sess-1",)).fetchone()
        invariant = conn.execute("SELECT * FROM invariants WHERE session_id = ?", ("sess-1",)).fetchone()
        challenge = conn.execute(
            "SELECT * FROM challenge_results WHERE session_id = ?", ("sess-1",)
        ).fetchone()

    assert event["hook"] == "PreToolUse"
    assert event["tool_name"] == "Edit"
    assert json.loads(event["payload_json"])["tool"] == "Edit"
    assert invariant["status"] == "pass"
    assert invariant["duration_ms"] == 12
    assert challenge["category"] == "null_inputs"
    assert challenge["covered"] == 1
    assert json.loads(challenge["evidence_json"]) == {"tests": ["test_null"]}


def test_retry_reason_attempts_are_backed_by_reason_budget(store: SQLiteStore) -> None:
    first = _consume_retry_slot_with_reason(store, 
        "sess-retry-meta",
        max_retries=3,
        reason="timeout",
        reason_limit=2,
    )
    second = _consume_retry_slot_with_reason(store, 
        "sess-retry-meta",
        max_retries=3,
        reason="timeout",
        reason_limit=2,
    )
    third = _consume_retry_slot_with_reason(store, 
        "sess-retry-meta",
        max_retries=3,
        reason="timeout",
        reason_limit=2,
    )

    assert first["consumed"] is True
    assert second["consumed"] is True
    assert third["consumed"] is False
    assert third["decision_code"] == "reason_budget_exhausted"
    state = _consume_retry_slot_with_reason(store, 
        "sess-retry-meta",
        reason="timeout",
        max_retries=3,
        reason_limit=2,
        consume=False,
    )
    assert state["reason_attempts"] == 2
    assert state["attempts"] == 2


def test_retry_delta_hash_round_trip(store: SQLiteStore) -> None:
    sid = "sess-retry-delta"
    reason = "shape_mismatch"
    signature = "sig-shape"

    assert store.get_retry_delta_hash(sid, reason, signature) is None
    store.upsert_retry_delta_hash(
        sid,
        reason=reason,
        failure_signature=signature,
        delta_hash="",
    )
    assert store.get_retry_delta_hash(sid, reason, signature) == ""
    store.upsert_retry_delta_hash(
        sid,
        reason=reason,
        failure_signature=signature,
        delta_hash="abc123",
    )
    assert store.get_retry_delta_hash(sid, reason, signature) == "abc123"


def test_record_event_compacts_large_text_payload(store: SQLiteStore) -> None:
    message = "m" * 2600
    assistant = "a" * 3000
    store.record_event(
        "sess-compact",
        "Stop",
        {
            "message": message,
            "last_assistant_message": assistant,
            "command": "pytest -q",
        },
    )
    with store.connection() as conn:
        row = conn.execute("SELECT payload_json FROM events WHERE session_id = ?", ("sess-compact",)).fetchone()
    payload = json.loads(row["payload_json"])
    assert payload["message"] == message[:2048]
    assert payload["last_assistant_message"] == assistant[:2048]
    assert payload["command"] == "pytest -q"
    assert payload["_payload_compaction"]["message"] == {
        "original_len": len(message),
        "truncated": True,
        "sha256": sha256(message.encode("utf-8")).hexdigest(),
    }


def test_run_write_retries_lock_errors(store: SQLiteStore) -> None:
    attempts = {"count": 0}

    def operation(_conn) -> None:
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise sqlite3.OperationalError("database is locked")

    store._run_write(operation)
    assert attempts["count"] == 2


def test_run_write_does_not_retry_non_lock_errors(store: SQLiteStore) -> None:
    attempts = {"count": 0}

    def operation(_conn) -> None:
        attempts["count"] += 1
        raise sqlite3.OperationalError("no such table: not_here")

    try:
        store._run_write(operation)
        raise AssertionError("expected sqlite3.OperationalError")
    except sqlite3.OperationalError:
        pass
    assert attempts["count"] == 1


def test_concurrent_event_writes_do_not_flake(tmp_path) -> None:
    store = SQLiteStore(
        tmp_path / ".cortex" / "cortex.db",
        lock_retry_attempts=6,
        lock_retry_backoff_ms=2,
        busy_timeout_ms=1500,
    )
    store.initialize()

    def _write_event(idx: int) -> None:
        store.record_event(
            session_id=f"sess-{idx % 4}",
            hook="PostToolUse",
            payload={"idx": idx},
            tool_name="Edit",
            status="ok",
        )

    with ThreadPoolExecutor(max_workers=8) as pool:
        for _ in pool.map(_write_event, range(80)):
            pass

    with store.connection() as conn:
        row = conn.execute("SELECT COUNT(*) AS n FROM events").fetchone()
    assert row["n"] == 80


def _consume_retry_worker(db_path: str, session_id: str, max_retries: int) -> bool:
    store = SQLiteStore(Path(db_path))
    return bool(
        _consume_retry_slot_with_reason(store, 
            session_id,
            max_retries=max_retries,
            reason="timeout",
            reason_limit=max_retries,
        )["consumed"]
    )


def _consume_retry_reason_worker(
    db_path: str, session_id: str, max_retries: int, reason: str, reason_limit: int
) -> bool:
    store = SQLiteStore(Path(db_path))
    return bool(
        _consume_retry_slot_with_reason(store, 
            session_id,
            max_retries=max_retries,
            reason=reason,
            reason_limit=reason_limit,
        )["consumed"]
    )


def test_retry_slot_atomicity_threaded(tmp_path) -> None:
    store = _make_stress_store(tmp_path)
    session_id = "retry-thread"
    max_retries = 3

    with ThreadPoolExecutor(max_workers=12) as pool:
        futures = [
            pool.submit(
                _consume_retry_slot_with_reason,
                store,
                session_id,
                max_retries=max_retries,
                reason="timeout",
                reason_limit=max_retries,
            )
            for _ in range(40)
        ]
        consumed = sum(1 for f in as_completed(futures) if bool(f.result()["consumed"]))

    assert consumed == max_retries
    state = _consume_retry_slot_with_reason(store, 
        session_id,
        reason="timeout",
        max_retries=max_retries,
        reason_limit=max_retries,
        consume=False,
    )
    assert state["attempts"] == max_retries


def test_retry_slot_atomicity_multiprocess(tmp_path) -> None:
    store = _make_stress_store(tmp_path)
    session_id = "retry-proc"
    max_retries = 3

    with ProcessPoolExecutor(max_workers=6) as pool:
        futures = [
            pool.submit(_consume_retry_worker, str(store.db_path), session_id, max_retries)
            for _ in range(24)
        ]
        consumed = sum(1 for f in as_completed(futures) if f.result())

    assert consumed == max_retries
    state = _consume_retry_slot_with_reason(store, 
        session_id,
        reason="timeout",
        max_retries=max_retries,
        reason_limit=max_retries,
        consume=False,
    )
    assert state["attempts"] == max_retries


def test_retry_reason_slot_atomicity_threaded(tmp_path) -> None:
    store = _make_stress_store(tmp_path)
    session_id = "retry-reason-thread"
    reason = "shape_mismatch"
    reason_limit = 3

    with ThreadPoolExecutor(max_workers=12) as pool:
        futures = [
            pool.submit(
                _consume_retry_slot_with_reason,
                store,
                session_id,
                max_retries=30,
                reason=reason,
                reason_limit=reason_limit,
            )
            for _ in range(40)
        ]
        consumed = sum(1 for f in as_completed(futures) if bool(f.result()["consumed"]))

    assert consumed == reason_limit
    state = _consume_retry_slot_with_reason(store, 
        session_id,
        reason=reason,
        max_retries=30,
        reason_limit=reason_limit,
        consume=False,
    )
    assert state["reason_attempts"] == reason_limit
    assert state["attempts"] == reason_limit


def test_retry_reason_slot_atomicity_multiprocess(tmp_path) -> None:
    store = _make_stress_store(tmp_path)
    session_id = "retry-reason-proc"
    reason = "shape_mismatch"
    reason_limit = 3

    with ProcessPoolExecutor(max_workers=6) as pool:
        futures = [
            pool.submit(
                _consume_retry_reason_worker,
                str(store.db_path),
                session_id,
                30,
                reason,
                reason_limit,
            )
            for _ in range(24)
        ]
        consumed = sum(1 for f in as_completed(futures) if f.result())

    assert consumed == reason_limit
    state = _consume_retry_slot_with_reason(store, 
        session_id,
        reason=reason,
        max_retries=30,
        reason_limit=reason_limit,
        consume=False,
    )
    assert state["reason_attempts"] == reason_limit
    assert state["attempts"] == reason_limit


# --- AW-5 stress / latency measurement tests ---


def _make_stress_store(tmp_path, *, retry=6, backoff_ms=2, busy_ms=2000):
    store = SQLiteStore(
        tmp_path / ".cortex" / "stress.db",
        lock_retry_attempts=retry,
        lock_retry_backoff_ms=backoff_ms,
        busy_timeout_ms=busy_ms,
    )
    store.initialize()
    return store


def test_stress_write_latency_p95(tmp_path) -> None:
    """Measure p95 write latency under 8-thread contention (200 writes)."""
    store = _make_stress_store(tmp_path)
    latencies: list[float] = []

    def _timed_write(idx: int) -> float:
        t0 = time.perf_counter()
        store.record_event(
            session_id=f"sess-{idx % 4}",
            hook="PostToolUse",
            payload={"idx": idx},
            tool_name="Edit",
            status="ok",
        )
        return time.perf_counter() - t0

    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(_timed_write, i) for i in range(200)]
        for f in as_completed(futures):
            latencies.append(f.result())

    latencies.sort()
    p95 = latencies[int(len(latencies) * 0.95)]
    p99 = latencies[int(len(latencies) * 0.99)]
    median = latencies[len(latencies) // 2]

    # All 200 writes persisted
    with store.connection() as conn:
        row = conn.execute("SELECT COUNT(*) AS n FROM events").fetchone()
    assert row["n"] == 200

    # p95 must stay under 500ms for sequential/low-parallel envelope
    assert p95 < 0.5, f"p95={p95:.3f}s exceeds 500ms envelope"
    # Median should be well under 100ms
    assert median < 0.1, f"median={median:.3f}s exceeds 100ms"
    # Record values for evidence extraction (visible in pytest -v output)
    print(f"\n  stress_latency: median={median*1000:.1f}ms p95={p95*1000:.1f}ms p99={p99*1000:.1f}ms")


def test_stress_mixed_operations_contention(tmp_path) -> None:
    """Mixed read/write operations under contention: events, graveyard, invariants."""
    store = _make_stress_store(tmp_path)

    def _mixed_op(idx: int) -> float:
        t0 = time.perf_counter()
        op = idx % 3
        sid = f"sess-{idx % 4}"
        if op == 0:
            store.record_event(sid, "PostToolUse", {"idx": idx}, tool_name="Edit", status="ok")
        elif op == 1:
            store.insert_graveyard(sid, f"approach-{idx}", "contention-test", ["f.py"], ["kw"])
        else:
            store.record_invariant_result(sid, f"test_{idx}.py", "pass", idx, "", "")
        return time.perf_counter() - t0

    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(_mixed_op, i) for i in range(150)]
        latencies = sorted(f.result() for f in as_completed(futures))

    p95 = latencies[int(len(latencies) * 0.95)]
    with store.connection() as conn:
        events = conn.execute("SELECT COUNT(*) AS n FROM events").fetchone()["n"]
        graves = conn.execute("SELECT COUNT(*) AS n FROM graveyard").fetchone()["n"]
        invars = conn.execute("SELECT COUNT(*) AS n FROM invariants").fetchone()["n"]

    assert events + graves + invars == 150
    assert p95 < 0.5, f"mixed-op p95={p95:.3f}s exceeds 500ms"
    print(f"\n  mixed_ops: events={events} graves={graves} invariants={invars} p95={p95*1000:.1f}ms")


def test_stress_replay_correctness(tmp_path) -> None:
    """Replay: write a session lifecycle, verify full round-trip data integrity."""
    store = _make_stress_store(tmp_path)
    sid = "replay-sess"
    store.upsert_session_start(sid, "running", "cortex.toml", {"phase": "start"})

    # Simulate 50 tool events
    for i in range(50):
        store.record_event(sid, "PostToolUse", {"step": i, "tool": "Edit"}, tool_name="Edit", status="ok")

    # Graveyard entries
    for i in range(5):
        store.insert_graveyard(sid, f"bad-approach-{i}", "test", [f"f{i}.py"], [f"kw{i}"])

    # Invariant results
    for i in range(10):
        store.record_invariant_result(sid, f"test_{i}.py", "pass" if i % 3 != 0 else "fail", i * 10, "", "")

    # Challenge results
    for cat in ("null_inputs", "boundary", "concurrency"):
        store.record_challenge_result(sid, cat, True, {"test": cat})

    store.close_session(sid, "completed", {"phase": "stop"})

    # Verify counts
    with store.connection() as conn:
        assert conn.execute("SELECT COUNT(*) AS n FROM events WHERE session_id=?", (sid,)).fetchone()["n"] == 50
        assert conn.execute("SELECT COUNT(*) AS n FROM graveyard WHERE session_id=?", (sid,)).fetchone()["n"] == 5
        assert conn.execute("SELECT COUNT(*) AS n FROM invariants WHERE session_id=?", (sid,)).fetchone()["n"] == 10
        assert (
            conn.execute("SELECT COUNT(*) AS n FROM challenge_results WHERE session_id=?", (sid,)).fetchone()["n"] == 3
        )
        sess = conn.execute("SELECT * FROM sessions WHERE session_id=?", (sid,)).fetchone()
        assert sess["status"] == "completed"
        assert sess["ended_at"] is not None

    # Graveyard list is consistent
    graves = store.list_graveyard()
    assert len(graves) == 5
    assert all(g["session_id"] == sid for g in graves)
