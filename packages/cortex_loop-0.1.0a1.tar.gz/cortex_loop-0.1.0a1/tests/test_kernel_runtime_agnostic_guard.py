from __future__ import annotations

from pathlib import Path


def test_kernel_modules_are_runtime_brand_free_except_adapters() -> None:
    root = Path(__file__).resolve().parents[1]
    forbidden = ("claude", "aider", "cortex_stop", "CORTEX_STOP_JSON")
    for path in (root / "cortex").rglob("*.py"):
        if path.name == "adapters.py":
            continue
        text = path.read_text(encoding="utf-8")
        lower = text.lower()
        assert all(token.lower() not in lower for token in forbidden), str(path)


def test_kernel_contract_tests_use_canonical_stop_payload_names() -> None:
    root = Path(__file__).resolve().parents[1]
    this_file = Path(__file__).resolve()
    allow = {
        root / "tests" / "test_adapters.py",
        root / "tests" / "test_cli.py",
        this_file,
    }
    forbidden = ("cortex_stop", "CORTEX_STOP_JSON")
    for path in (root / "tests").rglob("test_*.py"):
        if path in allow:
            continue
        text = path.read_text(encoding="utf-8")
        assert all(token not in text for token in forbidden), str(path)
