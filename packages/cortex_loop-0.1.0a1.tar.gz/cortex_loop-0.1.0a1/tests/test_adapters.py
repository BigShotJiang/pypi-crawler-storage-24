from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

import pytest

from cortex.adapters import ClaudeAdapter, GeminiAdapter, GenericAdapter, NormalizedEvent, OpenAIAdapter, load_adapter
from cortex.core import CortexKernel
from cortex.stop_contract import resolve_stop_contract


def test_generic_adapter_normalizes_event_and_keeps_payload_pass_through() -> None:
    adapter = GenericAdapter()
    event = adapter.normalize("PreToolUse", {"session_id": "sess-1", "tool": "Write"})
    assert event.name == "pre_tool_use"
    assert event.payload == {"session_id": "sess-1", "tool": "Write"}


def test_generic_adapter_normalizes_session_marker_alias() -> None:
    adapter = GenericAdapter()
    event = adapter.normalize("sessionMarker", {"label": "audit_complete"})
    assert event.name == "session_marker"
    assert event.payload == {"label": "audit_complete"}


def test_claude_adapter_maps_legacy_stop_aliases_to_canonical_keys() -> None:
    adapter = ClaudeAdapter()
    event = adapter.normalize(
        "stop",
        {
            "session_id": "sess-1",
            "cortex_stop": {"challenge_coverage": {"null_inputs": True}},
            "last_assistant_message": (
                'CORTEX_STOP_JSON: {"challenge_coverage":{"null_inputs":true}}'
            ),
        },
    )
    assert event.name == "stop"
    assert "stop_fields" in event.payload
    assert event.payload["stop_fields"] == {"challenge_coverage": {"null_inputs": True}}
    assert event.payload["last_assistant_message"] == ""


def test_claude_adapter_promotes_stop_fields_json_trailer_to_payload_stop_fields() -> None:
    adapter = ClaudeAdapter()
    event = adapter.normalize(
        "stop",
        {
            "session_id": "sess-claude-stop",
            "last_assistant_message": (
                "Upper bound bug fixed.\n"
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true,"boundary_values":true,'
                '"error_handling":true,"graveyard_regression":true},'
                '"truth_claims":{"modified_files":["src/normalize_port.py"],'
                '"tests_ran":["python -m pytest -q tests/test_normalize_port.py"]},'
                '"requirement_audit":{"items":[{"id":"BUGFIX","status":"pass",'
                '"evidence":["src/normalize_port.py"]}],"completeness_verdict":"pass"}}'
            ),
        },
    )
    assert event.name == "stop"
    assert event.payload["last_assistant_message"] == "Upper bound bug fixed."
    assert event.payload["stop_fields"] == {
        "challenge_coverage": {
            "null_inputs": True,
            "boundary_values": True,
            "error_handling": True,
            "graveyard_regression": True,
        },
        "truth_claims": {
            "modified_files": ["src/normalize_port.py"],
            "tests_ran": ["python -m pytest -q tests/test_normalize_port.py"],
        },
        "requirement_audit": {
            "items": [{"id": "BUGFIX", "status": "pass", "evidence": ["src/normalize_port.py"]}],
            "completeness_verdict": "pass",
        },
        "summary": "Upper bound bug fixed.",
    }
    contract = resolve_stop_contract(
        event.payload,
        allow_message_fallback=False,
        require_structured_stop_payload=True,
    )
    assert contract.stop_source == "payload.stop_fields"
    assert contract.structured_stop_violation is False


def test_stop_event_normalization_uses_canonical_stop_fields_shape_across_adapters() -> None:
    generic = GenericAdapter().normalize(
        "stop",
        {
            "session_id": "sess-g",
            "stop_fields": {"challenge_coverage": {"null_inputs": True}},
            "last_assistant_message": "Done",
        },
    )
    claude = ClaudeAdapter().normalize(
        "stop",
        {
            "session_id": "sess-c",
            "cortex_stop": {"challenge_coverage": {"null_inputs": True}},
            "last_assistant_message": 'CORTEX_STOP_JSON: {"challenge_coverage":{"null_inputs":true}}',
        },
    )
    gemini = GeminiAdapter().normalize(
        "AfterAgent",
        {
            "session_id": "sess-m",
            "prompt_response": 'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true}}',
        },
    )

    for event in (generic, claude, gemini):
        assert event.name == "stop"
        assert isinstance(event.payload.get("session_id"), str)
        assert isinstance(event.payload.get("stop_fields"), dict)
        assert isinstance(event.payload.get("last_assistant_message"), str)


def test_load_adapter_requires_module_class_format() -> None:
    with pytest.raises(ValueError, match="Expected format 'module.path:ClassName'"):
        load_adapter("badpath")


def test_load_adapter_rejects_missing_adapter_class() -> None:
    with pytest.raises(ValueError, match="not found"):
        load_adapter("cortex.adapters:MissingAdapter")


def test_load_adapter_rejects_non_adapter_class() -> None:
    with pytest.raises(TypeError, match="must define callable normalize"):
        load_adapter("pathlib:Path")


def test_load_adapter_loads_generic_adapter() -> None:
    adapter = load_adapter("cortex.adapters:GenericAdapter")
    event = adapter.normalize("stop", {"session_id": "s1"})
    assert event.name == "stop"
    assert event.payload["session_id"] == "s1"


def test_load_adapter_accepts_runtime_profile_alias_module_path() -> None:
    adapter = load_adapter("cortex.adapters.claude:ClaudeAdapter")
    event = adapter.normalize("stop", {"session_id": "s1", "cortex_stop": {"challenge_coverage": {"null_inputs": True}}})
    assert event.name == "stop"
    assert event.payload["stop_fields"]["challenge_coverage"]["null_inputs"] is True


def test_load_adapter_accepts_gemini_runtime_profile_alias_module_path() -> None:
    adapter = load_adapter("cortex.adapters.gemini:GeminiAdapter")
    event = adapter.normalize("AfterAgent", {"session_id": "s1", "prompt_response": "Done"})
    assert event.name == "stop"
    assert event.payload["last_assistant_message"] == "Done"
    assert event.payload["stop_fields"] == {"summary": "Done"}


def test_load_adapter_accepts_openai_runtime_profile_alias_module_path() -> None:
    adapter = load_adapter("cortex.adapters.openai:OpenAIAdapter")
    event = adapter.normalize("turn/completed", {"session_id": "s1", "final_text": "Done"})
    assert event.name == "stop"
    assert event.payload["last_assistant_message"] == "Done"


def test_openai_adapter_maps_app_server_aliases_to_canonical_events() -> None:
    adapter = OpenAIAdapter()
    pre = adapter.normalize(
        "item/commandExecution/requestApproval",
        {"session_id": "s-pre", "command": "echo hi"},
    )
    post = adapter.normalize(
        "item/commandExecution/completed",
        {"session_id": "s-post", "command": "echo hi", "status": "completed"},
    )
    stop = adapter.normalize("turn/completed", {"session_id": "s-stop", "final_text": "final"})
    assert pre.name == "pre_tool_use"
    assert post.name == "post_tool_use"
    assert stop.name == "stop"
    assert stop.payload["last_assistant_message"] == "final"


def test_gemini_adapter_normalizes_after_tool_error_payload() -> None:
    adapter = GeminiAdapter()
    event = adapter.normalize(
        "AfterTool",
        {
            "session_id": "sess-1",
            "tool_name": "run_shell_command",
            "tool_response": {"error": "exit code 1"},
        },
    )
    assert event.name == "post_tool_use"
    assert event.payload["session_id"] == "sess-1"
    assert event.payload["tool_name"] == "run_shell_command"
    assert event.payload["status"] == "error"


def test_gemini_adapter_maps_after_agent_to_stop_message_payload() -> None:
    adapter = GeminiAdapter()
    event = adapter.normalize(
        "AfterAgent",
        {"session_id": "sess-2", "prompt_response": "STOP_FIELDS_JSON: {\"challenge_coverage\":{\"null_inputs\":true}}"},
    )
    assert event.name == "stop"
    assert event.payload["session_id"] == "sess-2"
    assert event.payload["last_assistant_message"] == ""
    assert event.payload["stop_fields"]["challenge_coverage"]["null_inputs"] is True


def test_gemini_adapter_recovers_partial_marker_content_without_structured_failure() -> None:
    adapter = GeminiAdapter()
    event = adapter.normalize(
        "AfterAgent",
        {
            "session_id": "sess-3",
            "prompt_response": (
                "Work complete.\n"
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true,'
                '"boundary_values":true'
            ),
        },
    )
    assert event.name == "stop"
    assert event.payload["stop_fields"]["challenge_coverage"] == {
        "null_inputs": True,
        "boundary_values": True,
    }
    assert "marker_parse_error" in event.payload["stop_fields"]


def test_gemini_adapter_stop_contract_reports_whitespace_key_normalization() -> None:
    adapter = GeminiAdapter()
    event = adapter.normalize(
        "AfterAgent",
        {
            "session_id": "sess-ws-keys",
            "prompt_response": (
                "Done.\n"
                'STOP_FIELDS_JSON: {" challenge_coverage ":{"graveyard_regression ":true},'
                '"truth_claims":{" modified_files":["src/app.py"]}}'
            ),
        },
    )
    contract = resolve_stop_contract(
        event.payload,
        allow_message_fallback=False,
        require_structured_stop_payload=True,
    )
    assert contract.stop_key_normalization_count == 3
    assert contract.challenge_coverage == {"graveyard_regression": True}
    assert contract.truth_claims == {"modified_files": ["src/app.py"]}


@pytest.mark.parametrize("prompt_response", ["", "   \n\t  "])
def test_gemini_adapter_empty_or_whitespace_prompt_response_uses_fallback_stop_fields(
    prompt_response: str,
) -> None:
    normalized = GeminiAdapter().normalize(
        "AfterAgent",
        {"session_id": "sess-empty", "prompt_response": prompt_response},
    ).payload
    assert normalized["stop_fields"] == {}
    contract = resolve_stop_contract(
        normalized,
        allow_message_fallback=False,
        require_structured_stop_payload=True,
    )
    assert contract.structured_stop_violation is False


def test_gemini_adapter_missing_prompt_response_treated_as_empty_and_structured_valid() -> None:
    normalized = GeminiAdapter().normalize("AfterAgent", {"session_id": "sess-missing"}).payload
    assert normalized["stop_fields"] == {}
    contract = resolve_stop_contract(
        normalized,
        allow_message_fallback=False,
        require_structured_stop_payload=True,
    )
    assert contract.structured_stop_violation is False


def test_gemini_adapter_normalizes_captured_hook_payloads() -> None:
    fixtures_dir = Path(__file__).resolve().parent / "fixtures" / "gemini"
    adapter = GeminiAdapter()

    session_start = json.loads((fixtures_dir / "session_start_real.json").read_text(encoding="utf-8"))
    before_tool = json.loads((fixtures_dir / "before_tool_real.json").read_text(encoding="utf-8"))
    after_tool = json.loads((fixtures_dir / "after_tool_real.json").read_text(encoding="utf-8"))
    after_agent = json.loads((fixtures_dir / "after_agent_real.json").read_text(encoding="utf-8"))

    event_session = adapter.normalize("SessionStart", session_start)
    event_before = adapter.normalize("BeforeTool", before_tool)
    event_after = adapter.normalize("AfterTool", after_tool)
    event_stop = adapter.normalize("AfterAgent", after_agent)

    assert event_session.name == "session_start"
    assert event_before.name == "pre_tool_use"
    assert event_before.payload["tool_name"] == "run_shell_command"
    assert event_after.name == "post_tool_use"
    assert event_after.payload["status"] == "ok"
    assert event_stop.name == "stop"
    assert event_stop.payload["last_assistant_message"].strip() == "Hello! I'm ready to assist you."
    assert event_stop.payload["stop_fields"]["summary"] == "Hello! I'm ready to assist you."


def test_kernel_uses_runtime_adapter_from_config(tmp_project: Path) -> None:
    config = tmp_project / "cortex.toml"
    text = config.read_text(encoding="utf-8")
    config.write_text(
        text.replace(
            'adapter = "cortex.adapters:GenericAdapter"',
            'adapter = "cortex.adapters.claude:ClaudeAdapter"',
        ),
        encoding="utf-8",
    )
    kernel = CortexKernel(
        root=tmp_project,
        config_path=config,
        db_path=tmp_project / ".cortex" / "cortex.db",
    )
    result = kernel.dispatch(
        "stop",
        {
            "session_id": "sess-runtime-adapter",
            "run_invariants": False,
            "cortex_stop": {
                "challenge_coverage": {
                    "null_inputs": True,
                    "boundary_values": True,
                    "error_handling": True,
                    "graveyard_regression": True,
                }
            },
        },
    )
    assert result["hook"] == "Stop"
    assert result["session_id"] == "sess-runtime-adapter"
    assert result["challenge_report"]["ok"] is True


def test_kernel_rejects_legacy_adapter_name_argument(tmp_project: Path) -> None:
    with pytest.raises(ValueError, match="adapter_name is no longer supported"):
        CortexKernel(
            root=tmp_project,
            config_path=tmp_project / "cortex.toml",
            db_path=tmp_project / ".cortex" / "cortex.db",
            adapter_name="legacy",
        )


def test_kernel_dispatch_uses_injected_adapter(tmp_project: Path) -> None:
    @dataclass(slots=True)
    class TestAdapter:
        def normalize(self, event_name: str, payload: dict[str, Any] | None = None) -> NormalizedEvent:
            _ = event_name
            _ = payload
            return NormalizedEvent(
                name="stop",
                payload={
                    "session_id": "sess-adapter",
                    "run_invariants": False,
                    "challenge_coverage": {
                        "null_inputs": True,
                        "boundary_values": True,
                        "error_handling": True,
                        "graveyard_regression": True,
                    },
                },
            )

    kernel = CortexKernel(
        root=tmp_project,
        config_path=tmp_project / "cortex.toml",
        db_path=tmp_project / ".cortex" / "cortex.db",
        adapter=TestAdapter(),
    )
    result = kernel.dispatch("IGNORED")
    assert result["hook"] == "Stop"
    assert result["session_id"] == "sess-adapter"
    assert result["challenge_report"]["ok"] is True
