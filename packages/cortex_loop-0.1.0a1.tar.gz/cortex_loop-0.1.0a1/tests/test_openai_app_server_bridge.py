from __future__ import annotations

import json
from argparse import Namespace
from pathlib import Path

import pytest

import cortex_ops_cli.openai_app_server_bridge as bridge


class _FakeKernel:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict[str, object]]] = []

    def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
        self.calls.append((event, dict(payload)))
        if event == "pre_tool_use":
            return {"proceed": payload.get("tool_name") != "file_change"}
        if event == "stop":
            return {"enforcement_pass": True}
        return {"proceed": True}


def test_kernel_pretool_decision_maps_command_execution_to_pre_tool_use() -> None:
    kernel = _FakeKernel()
    proceed, result = bridge._kernel_pretool_decision(
        kernel=kernel,
        session_id="thread-1",
        method=bridge.COMMAND_APPROVAL_METHOD,
        params={"command": "python3 -c 'print(42)'"},
    )
    assert proceed is True
    assert result["proceed"] is True
    assert kernel.calls[0][0] == "pre_tool_use"
    assert kernel.calls[0][1]["tool_name"] == "command_execution"


def test_probe_approval_blocking_reports_gap_when_decline_is_not_blocking(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "turn_id": "t1",
            "thread_id": "th1",
            "approval_requests": [{"method": bridge.COMMAND_APPROVAL_METHOD}],
            "command_completion_items": [
                {"status": "completed", "exit_code": 0, "aggregated_output": "42"}
            ],
        },
    )
    args = Namespace(
        codex_bin="codex",
        cwd=".",
        prompt="probe",
        model=None,
        timeout_seconds=1.0,
    )
    rc = bridge._probe_approval_blocking(args)
    payload = json.loads(capsys.readouterr().out)
    assert rc == 2
    assert payload["ok"] is False
    assert "pre_tool_use_nonblocking_approval" in payload["coverage_gaps"]
    assert "pre_tool_use_nonblocking_approval" in payload["hard_coverage_gaps"]


def test_probe_approval_blocking_treats_missing_approval_observation_as_limitation(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "turn_id": "t-limit",
            "thread_id": "th-limit",
            "approval_requests": [],
            "command_completion_items": [],
        },
    )
    args = Namespace(
        codex_bin="codex",
        cwd=".",
        prompt="probe",
        model=None,
        timeout_seconds=1.0,
    )
    rc = bridge._probe_approval_blocking(args)
    payload = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert payload["ok"] is True
    assert "pre_tool_use_approval_not_observed" in payload["coverage_gaps"]
    assert payload["hard_coverage_gaps"] == []
    assert "pre_tool_use_approval_not_observed" in payload["limitation_gaps"]


def test_probe_approval_blocking_passes_when_decline_marks_command_declined(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "turn_id": "t2",
            "thread_id": "th2",
            "approval_requests": [{"method": bridge.COMMAND_APPROVAL_METHOD}],
            "command_completion_items": [
                {"status": "declined", "exit_code": None, "aggregated_output": ""}
            ],
        },
    )
    args = Namespace(
        codex_bin="codex",
        cwd=".",
        prompt="probe",
        model=None,
        timeout_seconds=1.0,
    )
    rc = bridge._probe_approval_blocking(args)
    payload = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert payload["ok"] is True
    assert payload["coverage_gaps"] == []


def test_run_mode_calls_stop_once_with_final_turn_text(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    fake_kernel = _FakeKernel()
    monkeypatch.setattr(bridge, "CortexKernel", lambda **_: fake_kernel)
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "thread_id": "thread-xyz",
            "turn_id": "turn-xyz",
            "text": "final answer",
            "coverage_gaps": ["example_gap"],
            "duplicate_turn_completed_count": 2,
            "approval_requests": [{"method": bridge.COMMAND_APPROVAL_METHOD}],
            "command_completion_items": [],
            "elapsed_seconds": 0.5,
        },
    )

    args = Namespace(
        command="run",
        codex_bin="codex",
        cwd=str(tmp_path),
        root=str(tmp_path),
        config_path=None,
        db_path=None,
        model=None,
        prompt="hello",
        timeout_seconds=1.0,
        schema_version=bridge.SCHEMA_VERSION,
    )
    rc = bridge._run_mode(args)
    out = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert out["ok"] is True
    assert out["text"] == "final answer"
    assert out["duplicate_turn_completed_count"] == 2
    assert out["stop_fields_present"] is False
    assert out["stop_fields_parse_error"] == ""
    assert out["stop_fields_source"] == "none"
    stop_calls = [entry for entry in fake_kernel.calls if entry[0] == "stop"]
    assert len(stop_calls) == 1
    assert stop_calls[0][1]["last_assistant_message"] == "final answer"
    assert "stop_fields" not in stop_calls[0][1]


def test_run_mode_parses_stop_fields_trailer_and_passes_to_stop(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    class _StrictKernel(_FakeKernel):
        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            self.calls.append((event, dict(payload)))
            if event == "stop":
                has_stop_fields = isinstance(payload.get("stop_fields"), dict)
                return {"enforcement_pass": has_stop_fields}
            return {"proceed": True}

    fake_kernel = _StrictKernel()
    monkeypatch.setattr(bridge, "CortexKernel", lambda **_: fake_kernel)
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "thread_id": "thread-stop-ok",
            "turn_id": "turn-stop-ok",
            "text": (
                "Done.\n"
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true,"boundary_values":true,'
                '"error_handling":true,"graveyard_regression":true},"truth_claims":{"modified_files":["a.py"],'
                '"tests_ran":["pytest -q"]}}'
            ),
            "coverage_gaps": [],
            "duplicate_turn_completed_count": 0,
            "approval_requests": [],
            "command_completion_items": [],
            "elapsed_seconds": 0.2,
        },
    )
    args = Namespace(
        command="run",
        codex_bin="codex",
        cwd=str(tmp_path),
        root=str(tmp_path),
        config_path=None,
        db_path=None,
        model=None,
        prompt="hello",
        timeout_seconds=1.0,
        schema_version=bridge.SCHEMA_VERSION,
    )
    rc = bridge._run_mode(args)
    out = json.loads(capsys.readouterr().out)
    stop_calls = [entry for entry in fake_kernel.calls if entry[0] == "stop"]

    assert rc == 0
    assert out["enforcement_pass"] is True
    assert out["stop_fields_present"] is True
    assert out["stop_fields_parse_error"] == ""
    assert out["stop_fields_source"] == "payload.stop_fields"
    assert len(stop_calls) == 1
    assert isinstance(stop_calls[0][1].get("stop_fields"), dict)


def test_run_mode_marks_parse_error_when_stop_trailer_is_malformed(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    class _StrictKernel(_FakeKernel):
        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            self.calls.append((event, dict(payload)))
            if event == "stop":
                has_stop_fields = isinstance(payload.get("stop_fields"), dict)
                return {"enforcement_pass": has_stop_fields}
            return {"proceed": True}

    fake_kernel = _StrictKernel()
    monkeypatch.setattr(bridge, "CortexKernel", lambda **_: fake_kernel)
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "thread_id": "thread-stop-bad",
            "turn_id": "turn-stop-bad",
            "text": "Done.\nSTOP_FIELDS_JSON: {not-json",
            "coverage_gaps": [],
            "duplicate_turn_completed_count": 0,
            "approval_requests": [],
            "command_completion_items": [],
            "elapsed_seconds": 0.2,
        },
    )
    args = Namespace(
        command="run",
        codex_bin="codex",
        cwd=str(tmp_path),
        root=str(tmp_path),
        config_path=None,
        db_path=None,
        model=None,
        prompt="hello",
        timeout_seconds=1.0,
        schema_version=bridge.SCHEMA_VERSION,
    )
    rc = bridge._run_mode(args)
    out = json.loads(capsys.readouterr().out)
    stop_calls = [entry for entry in fake_kernel.calls if entry[0] == "stop"]

    assert rc == 0
    assert out["enforcement_pass"] is False
    assert out["stop_fields_present"] is False
    assert out["stop_fields_source"] == "none"
    assert out["stop_fields_parse_error"]
    assert len(stop_calls) == 1
    assert "stop_fields" not in stop_calls[0][1]


def test_run_mode_preserves_stuck_stop_semantics(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    class _KernelWithStuckStop:
        def __init__(self) -> None:
            self.calls: list[tuple[str, dict[str, object]]] = []

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            self.calls.append((event, dict(payload)))
            if event == "stop":
                return {
                    "enforcement_pass": False,
                    "proceed": False,
                    "recommend_revert": False,
                    "feedback_mode": "stuck",
                    "stuck_declared": True,
                    "stuck_declaration": {
                        "check": "truth_claims",
                        "approaches_tried": ["pytest -q", "git diff --name-only"],
                        "obstacle": "repository delta did not match the claimed file",
                    },
                    "warnings": ["Truth claims reported gaps: src/claimed.py was not observed."],
                }
            return {"proceed": True}

    fake_kernel = _KernelWithStuckStop()
    monkeypatch.setattr(bridge, "CortexKernel", lambda **_: fake_kernel)
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "thread_id": "thread-stop-stuck",
            "turn_id": "turn-stop-stuck",
            "text": "I could not verify the change.",
            "coverage_gaps": [],
            "duplicate_turn_completed_count": 0,
            "approval_requests": [],
            "command_completion_items": [],
            "elapsed_seconds": 0.2,
            "command_surface": {},
        },
    )
    args = Namespace(
        command="run",
        codex_bin="codex",
        cwd=str(tmp_path),
        root=str(tmp_path),
        config_path=None,
        db_path=None,
        model=None,
        prompt="hello",
        timeout_seconds=1.0,
        schema_version=bridge.SCHEMA_VERSION,
    )

    rc = bridge._run_mode(args)
    out = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert out["enforcement_pass"] is False
    assert out["proceed"] is False
    assert out["recommend_revert"] is False
    assert out["feedback_mode"] == "stuck"
    assert out["stuck_declared"] is True
    assert out["stuck_declaration"]["check"] == "truth_claims"
    assert out["warnings"] == ["Truth claims reported gaps: src/claimed.py was not observed."]


def test_run_mode_forwards_readiness_ledger_stop_fields(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    class _KernelWithReadinessFields:
        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            if event == "stop":
                return {
                    "enforcement_pass": False,
                    "session_status": "needs_retry",
                    "proceed": False,
                    "challenge_coverage_missing": True,
                    "structured_stop_violation": True,
                    "requirements_gate_gap": True,
                    "warnings": ["Structured stop payload is required."],
                }
            return {"proceed": True}

    monkeypatch.setattr(bridge, "CortexKernel", lambda **_: _KernelWithReadinessFields())
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "thread_id": "thread-readiness",
            "turn_id": "turn-readiness",
            "text": "Done.",
            "coverage_gaps": [],
            "duplicate_turn_completed_count": 0,
            "approval_requests": [],
            "command_completion_items": [],
            "elapsed_seconds": 0.2,
            "command_surface": {},
        },
    )
    args = Namespace(
        command="run",
        codex_bin="codex",
        cwd=str(tmp_path),
        root=str(tmp_path),
        config_path=None,
        db_path=None,
        model=None,
        prompt="hello",
        timeout_seconds=1.0,
        schema_version=bridge.SCHEMA_VERSION,
    )

    rc = bridge._run_mode(args)
    out = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert out["enforcement_pass"] is False
    assert out["session_status"] == "needs_retry"
    assert out["proceed"] is False
    assert out["challenge_coverage_missing"] is True
    assert out["structured_stop_violation"] is True
    assert out["requirements_gate_gap"] is True
    assert out["warnings"] == ["Structured stop payload is required."]


def test_run_mode_preserves_reconsider_approach_feedback(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    class _KernelWithLoopFeedback:
        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            if event == "stop":
                return {
                    "enforcement_pass": False,
                    "proceed": False,
                    "recommend_revert": True,
                    "feedback_mode": "reconsider_approach",
                    "requirement_audit_gap": True,
                    "truth_claims_gap": False,
                    "requirements_gate_gap": True,
                    "warnings": [
                        "Stop attempt is highly similar to the previous failed Stop; reconsider the approach instead of refining the same attempt."
                    ],
                }
            return {"proceed": True}

    monkeypatch.setattr(bridge, "CortexKernel", lambda **_: _KernelWithLoopFeedback())
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "thread_id": "thread-stop-loop",
            "turn_id": "turn-stop-loop",
            "text": "Tried the same fix again.",
            "coverage_gaps": [],
            "duplicate_turn_completed_count": 0,
            "approval_requests": [],
            "command_completion_items": [],
            "elapsed_seconds": 0.2,
            "command_surface": {},
        },
    )
    args = Namespace(
        command="run",
        codex_bin="codex",
        cwd=str(tmp_path),
        root=str(tmp_path),
        config_path=None,
        db_path=None,
        model=None,
        prompt="hello",
        timeout_seconds=1.0,
        schema_version=bridge.SCHEMA_VERSION,
    )

    rc = bridge._run_mode(args)
    out = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert out["enforcement_pass"] is False
    assert out["proceed"] is False
    assert out["recommend_revert"] is True
    assert out["feedback_mode"] == "reconsider_approach"
    assert out["requirement_audit_gap"] is True
    assert out["truth_claims_gap"] is False
    assert out["requirements_gate_gap"] is True
    assert out["warnings"] == [
        "Stop attempt is highly similar to the previous failed Stop; reconsider the approach instead of refining the same attempt."
    ]


def test_execute_turn_records_approval_item_metadata(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class _FakeClient:
        def __init__(self, **_: object) -> None:
            self.messages = [
                {
                    "id": 77,
                    "method": bridge.COMMAND_APPROVAL_METHOD,
                    "params": {
                        "threadId": "thread-1",
                        "itemId": "item-1",
                        "command": "echo ok",
                        "cwd": "/tmp/work",
                    },
                },
                {
                    "method": "item/completed",
                    "params": {
                        "turnId": "turn-1",
                        "item": {
                            "type": "commandExecution",
                            "id": "item-1",
                            "status": "completed",
                            "exitCode": 0,
                            "aggregatedOutput": "ok",
                        },
                    },
                },
                {
                    "method": "item/completed",
                    "params": {
                        "turnId": "turn-1",
                        "item": {"type": "agentMessage", "text": "done"},
                    },
                },
                {
                    "method": "turn/completed",
                    "params": {"turn": {"id": "turn-1"}},
                },
            ]
            self.request_results: list[tuple[object, dict[str, object]]] = []

        def request(self, method: str, params: dict[str, object] | None = None, **_: object) -> dict[str, object]:
            if method == "initialize":
                return {"userAgent": "fake"}
            if method == "thread/start":
                return {"thread": {"id": "thread-1"}}
            if method == "turn/start":
                return {"turn": {"id": "turn-1"}}
            raise AssertionError(f"unexpected request {method}")

        def send_notification(self, method: str, params: dict[str, object] | None = None) -> None:
            return None

        def send_server_request_result(self, request_id: object, result: dict[str, object]) -> None:
            self.request_results.append((request_id, result))

        def next_message(self, *, timeout_seconds: float | None = None) -> dict[str, object]:
            if not self.messages:
                raise bridge.BridgeError("unexpected empty stream")
            return self.messages.pop(0)

        def close(self) -> None:
            return None

    monkeypatch.setattr(bridge, "AppServerClient", _FakeClient)

    result = bridge._execute_turn(
        codex_bin="codex",
        cwd=Path("."),
        prompt="ignored",
        model=None,
        timeout_seconds=5.0,
        approval_handler=lambda _method, _params: ("accept", {"ok": True}),
    )

    assert result["ok"] is True
    assert result["approval_requests"] == [
        {
            "method": bridge.COMMAND_APPROVAL_METHOD,
            "item_id": "item-1",
            "command": "echo ok",
            "cwd": "/tmp/work",
            "decision": "accept",
            "metadata": {"ok": True},
        }
    ]


def test_run_mode_resolves_post_tool_command_from_completion_or_approval(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    class _KernelWithPostTool:
        def __init__(self) -> None:
            self.calls: list[tuple[str, dict[str, object]]] = []

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            self.calls.append((event, dict(payload)))
            if event == "stop":
                return {"enforcement_pass": True}
            return {"proceed": True}

    fake_kernel = _KernelWithPostTool()
    monkeypatch.setattr(bridge, "CortexKernel", lambda **_: fake_kernel)
    monkeypatch.setattr(
        bridge,
        "_execute_turn",
        lambda **_: {
            "thread_id": "thread-link",
            "turn_id": "turn-link",
            "text": "final answer",
            "coverage_gaps": [],
            "duplicate_turn_completed_count": 0,
            "elapsed_seconds": 0.25,
            "approval_requests": [
                {
                    "method": bridge.COMMAND_APPROVAL_METHOD,
                    "item_id": "item-fallback",
                    "command": "/bin/zsh -lc 'pytest -q tests/test_app.py'",
                    "cwd": "/tmp/fallback-cwd",
                },
                {
                    "method": bridge.COMMAND_APPROVAL_METHOD,
                    "item_id": "item-priority",
                    "command": "echo from-approval",
                    "cwd": "/tmp/approval-cwd",
                },
            ],
            "command_completion_items": [
                {
                    "item_id": "item-fallback",
                    "status": "completed",
                    "exit_code": 0,
                    "aggregated_output": "ok",
                    "command": "",
                    "cwd": "",
                },
                {
                    "item_id": "item-priority",
                    "status": "completed",
                    "exit_code": 0,
                    "aggregated_output": "ok",
                    "command": "npm test",
                    "cwd": "/tmp/completion-cwd",
                },
            ],
            "command_surface": {},
        },
    )

    args = Namespace(
        command="run",
        codex_bin="codex",
        cwd=str(tmp_path),
        root=str(tmp_path),
        config_path=None,
        db_path=None,
        model=None,
        prompt="hello",
        timeout_seconds=1.0,
        schema_version=bridge.SCHEMA_VERSION,
    )
    rc = bridge._run_mode(args)
    _ = json.loads(capsys.readouterr().out)

    assert rc == 0
    post_tool_calls = [payload for event, payload in fake_kernel.calls if event == "post_tool_use"]
    assert len(post_tool_calls) == 2
    commands = [str(payload.get("command") or "") for payload in post_tool_calls]
    assert all(command.strip() for command in commands)
    assert "pytest -q tests/test_app.py" in commands
    assert "npm test" in commands
    fallback_call = next(payload for payload in post_tool_calls if payload.get("command") == "pytest -q tests/test_app.py")
    assert fallback_call["cwd"] == "/tmp/fallback-cwd"
    completion_call = next(payload for payload in post_tool_calls if payload.get("command") == "npm test")
    assert completion_call["cwd"] == "/tmp/completion-cwd"


def test_normalize_command_for_witness_unwraps_shell_lc_wrappers() -> None:
    assert bridge._normalize_command_for_witness("/bin/zsh -lc 'pytest -q'") == "pytest -q"
    assert bridge._normalize_command_for_witness("bash -lc \"python -m pytest -q\"") == "python -m pytest -q"
    assert bridge._normalize_command_for_witness("npm test") == "npm test"


def test_app_server_client_request_handles_notification_before_response() -> None:
    client = bridge.AppServerClient.__new__(bridge.AppServerClient)
    client.timeout_seconds = 1.0
    client._next_request_id = 1
    client._pending_messages = [{"method": "thread/status/changed", "params": {"threadId": "t1"}}]

    writes: list[dict[str, object]] = []
    client._write = lambda payload: writes.append(payload)

    queued = [{"id": 1, "result": {"thread": {"id": "t1"}}}]

    def _fake_read_message(timeout_seconds: float, *, allow_pending: bool = True) -> dict[str, object]:
        assert allow_pending is False
        return queued.pop(0)

    client._read_message = _fake_read_message

    result = bridge.AppServerClient.request(client, "thread/start", {"cwd": "/tmp"}, timeout_seconds=0.2)

    assert result == {"thread": {"id": "t1"}}
    assert writes[0]["method"] == "thread/start"
    assert client._pending_messages == [{"method": "thread/status/changed", "params": {"threadId": "t1"}}]


def test_execute_turn_falls_back_to_task_complete_when_turn_completed_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class _FakeClient:
        def __init__(self, **_: object) -> None:
            self.messages = [
                {
                    "method": "item/completed",
                    "params": {
                        "turnId": "turn-1",
                        "item": {"type": "agentMessage", "text": "DONE"},
                    },
                },
                {
                    "method": "codex/event/task_complete",
                    "params": {
                        "id": "turn-1",
                        "msg": {"turn_id": "turn-1", "last_agent_message": "DONE"},
                    },
                },
                {
                    "method": "thread/status/changed",
                    "params": {"threadId": "thread-1", "status": {"type": "idle"}},
                },
            ]

        def request(self, method: str, params: dict[str, object] | None = None, **_: object) -> dict[str, object]:
            if method == "initialize":
                return {"userAgent": "fake"}
            if method == "thread/start":
                return {"thread": {"id": "thread-1"}}
            if method == "turn/start":
                return {"turn": {"id": "turn-1"}}
            raise AssertionError(f"unexpected request {method}")

        def send_notification(self, method: str, params: dict[str, object] | None = None) -> None:
            return None

        def send_server_request_result(self, request_id: object, result: dict[str, object]) -> None:
            return None

        def next_message(self, *, timeout_seconds: float | None = None) -> dict[str, object]:
            if not self.messages:
                raise bridge.BridgeError("unexpected empty stream")
            return self.messages.pop(0)

        def close(self) -> None:
            return None

    monkeypatch.setattr(bridge, "AppServerClient", _FakeClient)

    result = bridge._execute_turn(
        codex_bin="codex",
        cwd=Path("."),
        prompt="ignored",
        model=None,
        timeout_seconds=5.0,
        approval_handler=lambda _method, _params: ("accept", {"ok": True}),
    )

    assert result["ok"] is True
    assert result["thread_id"] == "thread-1"
    assert result["turn_id"] == "turn-1"
    assert result["text"] == "DONE"
    assert "turn_completed_missing_used_task_complete_fallback" in result["coverage_gaps"]


def test_start_thread_with_policy_fallback_uses_next_policy_on_compat_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[str] = []

    class _Client:
        def request(self, method: str, params: dict[str, object] | None = None, **_: object) -> dict[str, object]:
            assert method == "thread/start"
            policy = str((params or {}).get("approvalPolicy") or "")
            calls.append(policy)
            if policy == "untrusted":
                raise bridge.BridgeError("unknown variant `untrusted`")
            return {"thread": {"id": "thread-1"}}

    result, policy = bridge._start_thread_with_policy_fallback(
        client=_Client(),  # type: ignore[arg-type]
        cwd=Path("."),
        model=None,
        approval_policy_candidates=("untrusted", "unlessTrusted"),
    )

    assert result == {"thread": {"id": "thread-1"}}
    assert policy == "unlessTrusted"
    assert calls == ["untrusted", "unlessTrusted"]


def test_probe_model_reports_available_when_model_list_contains_target(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    class _Client:
        def __init__(self, **_: object) -> None:
            self.closed = False

        def request(self, method: str, params: dict[str, object] | None = None, **_: object) -> dict[str, object]:
            if method == "initialize":
                return {"serverInfo": {"name": "fake"}}
            if method == "model/list":
                return {"data": [{"id": "gpt-5.2-codex"}], "nextCursor": None}
            raise AssertionError(f"unexpected request {method}")

        def send_notification(self, method: str, params: dict[str, object] | None = None) -> None:
            assert method == "initialized"

        def close(self) -> None:
            self.closed = True

    monkeypatch.setattr(bridge, "AppServerClient", _Client)
    args = Namespace(
        codex_bin="codex",
        cwd=str(tmp_path),
        model="gpt-5.2-codex",
        timeout_seconds=1.0,
    )
    rc = bridge._probe_model(args)
    payload = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert payload["available"] is True
    assert payload["source"] == "model/list"


def test_probe_model_uses_exec_fallback_when_model_list_unavailable(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    class _Client:
        def __init__(self, **_: object) -> None:
            self.closed = False

        def request(self, method: str, params: dict[str, object] | None = None, **_: object) -> dict[str, object]:
            if method == "initialize":
                return {"serverInfo": {"name": "fake"}}
            if method == "model/list":
                raise bridge.BridgeError("method not found")
            raise AssertionError(f"unexpected request {method}")

        def send_notification(self, method: str, params: dict[str, object] | None = None) -> None:
            assert method == "initialized"

        def close(self) -> None:
            self.closed = True

    monkeypatch.setattr(bridge, "AppServerClient", _Client)

    class _Completed:
        returncode = 0
        stdout = "OK\n"
        stderr = ""

    monkeypatch.setattr(bridge.subprocess, "run", lambda *args, **kwargs: _Completed())
    args = Namespace(
        codex_bin="codex",
        cwd=str(tmp_path),
        model="gpt-5.2-codex",
        timeout_seconds=1.0,
    )
    rc = bridge._probe_model(args)
    payload = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert payload["available"] is True
    assert payload["source"] == "exec_fallback"
    assert payload["fallback_used"] is True
