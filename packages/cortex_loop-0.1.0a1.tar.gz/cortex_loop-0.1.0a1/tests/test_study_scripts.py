from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import pytest

SCRIPTS_DIR = Path(__file__).resolve().parents[1] / "eval" / "study" / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.append(str(SCRIPTS_DIR))

import analyze_all  # type: ignore  # noqa: E402
import build_blind_packet  # type: ignore  # noqa: E402
import preflight_certify  # type: ignore  # noqa: E402
import run_block  # type: ignore  # noqa: E402
import run_study  # type: ignore  # noqa: E402
from common import balanced_capped_schedule, load_tasks  # type: ignore  # noqa: E402


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def test_build_metrics_persists_booleans_only() -> None:
    metrics = run_block._build_metrics(
        condition="B",
        checker_passed=True,
        cortex_metadata={"session_status": "failed_invariants", "session_metadata": {"enforcement_pass": False}},
        model_text="implemented",
    )
    assert set(metrics) == {
        "artifact_pass",
        "enforcement_pass",
        "response_present",
        "composite_pass",
    }
    assert metrics["artifact_pass"] is True
    assert metrics["enforcement_pass"] is False
    assert metrics["response_present"] is True
    assert metrics["composite_pass"] is False


def test_analyze_scopes_b_minus_a_to_ab_block_only(tmp_path: Path) -> None:
    output_dir = tmp_path / "study"
    manifest_path = tmp_path / "manifest.json"
    _write_json(
        manifest_path,
        {
            "schema_version": "cortex_study_manifest_v1",
            "thresholds": {"primary_min_improvement_b_over_a": 0.1},
        },
    )
    _write_json(
        output_dir / "checkpoints" / "ab.json",
        {"completed_slots": {"ab-a": {"final_run_id": "ab-a"}, "ab-b": {"final_run_id": "ab-b"}}},
    )
    _write_json(
        output_dir / "checkpoints" / "bc.json",
        {"completed_slots": {"bc-b": {"final_run_id": "bc-b"}, "bc-c": {"final_run_id": "bc-c"}}},
    )

    def _record(run_id: str, *, block: str, condition: str, composite_pass: bool) -> dict[str, Any]:
        return {
            "run_id": run_id,
            "block": block,
            "condition": condition,
            "model_provider": "claude",
            "status": "ok",
            "metrics": {
                "artifact_pass": composite_pass,
                "enforcement_pass": composite_pass,
                "response_present": True,
                "composite_pass": composite_pass,
            },
        }

    _write_json(output_dir / "raw_local" / "runs" / "ab-a.json", _record("ab-a", block="ab", condition="A", composite_pass=False))
    _write_json(output_dir / "raw_local" / "runs" / "ab-b.json", _record("ab-b", block="ab", condition="B", composite_pass=False))
    _write_json(output_dir / "raw_local" / "runs" / "bc-b.json", _record("bc-b", block="bc", condition="B", composite_pass=True))
    _write_json(output_dir / "raw_local" / "runs" / "bc-c.json", _record("bc-c", block="bc", condition="C", composite_pass=False))

    result = analyze_all.analyze(output_dir, manifest_path, providers=["claude"])
    assert result["comparisons"]["b_minus_a"]["block"] == "ab"
    assert result["comparisons"]["b_minus_a"]["pooled"]["diff"] == 0.0
    assert result["comparisons"]["b_minus_c"]["block"] == "bc"
    assert result["comparisons"]["b_minus_c"]["pooled"]["diff"] == 1.0


def test_analyze_marks_openai_quarantined_when_capability_gap_present(tmp_path: Path) -> None:
    output_dir = tmp_path / "study"
    manifest_path = tmp_path / "manifest.json"
    _write_json(
        manifest_path,
        {
            "schema_version": "cortex_study_manifest_v1",
            "thresholds": {"primary_min_improvement_b_over_a": 0.1},
        },
    )
    _write_json(output_dir / "checkpoints" / "ab.json", {"completed_slots": {}})
    _write_json(output_dir / "checkpoints" / "bc.json", {"completed_slots": {}})

    result = analyze_all.analyze(
        output_dir,
        manifest_path,
        providers=["claude", "openai"],
        provider_capabilities={
            "openai": {
                "promotable": False,
                "quarantine_reason": "pre_tool_use_nonblocking_approval",
                "coverage_gaps": ["pre_tool_use_nonblocking_approval"],
            }
        },
    )
    assert result["provider_roles"]["headline_provider"] == "claude"
    assert result["provider_roles"]["quarantined"]["openai"] == "pre_tool_use_nonblocking_approval"


def test_run_study_default_providers_are_claude_openai() -> None:
    providers = run_study._parse_providers({"models": {"claude": {}, "openai": {}}}, None)
    assert providers == ["claude", "openai"]


def test_frozen_model_map_hard_fails_on_provider_mismatch(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    frozen_path = run_dir / "raw_local" / "model_resolution.json"
    _write_json(
        frozen_path,
        {
            "providers": ["claude", "gemini"],
            "models": {"claude": "sonnet", "gemini": "flash"},
        },
    )
    with pytest.raises(RuntimeError, match="Frozen provider map mismatch"):
        run_study._load_or_create_frozen_model_map(
            run_dir=run_dir,
            manifest={"models": {"claude": {}, "openai": {}}},
            providers=["claude", "openai"],
        )


def test_run_study_returns_failed_precheck_on_mode_mismatch(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest_path = tmp_path / "manifest.json"
    output_dir = tmp_path / "results"
    _write_json(manifest_path, {"schema_version": "cortex_study_manifest_v1", "models": {"claude": {}, "openai": {}}})

    monkeypatch.setattr(
        run_study,
        "run_preflight",
        lambda *_args, **_kwargs: {"ok": False, "failures": ["study_invariants_mode_mismatch"]},
    )
    monkeypatch.setattr(run_study, "execute_block", lambda *_args, **_kwargs: pytest.fail("execute_block should not run"))

    result = run_study.run(manifest_path, output_dir)
    assert result["status"] == "FAILED_PRECHECK"
    assert "study_invariants_mode_mismatch" in result["preflight"]["failures"]


def test_run_study_aborts_on_validity_error_before_bc(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest_path = tmp_path / "manifest.json"
    output_dir = tmp_path / "results"
    _write_json(
        manifest_path,
        {
            "schema_version": "cortex_study_manifest_v1",
            "models": {"claude": {}, "openai": {}},
            "default_providers": ["claude", "openai"],
        },
    )

    monkeypatch.setattr(
        run_study,
        "run_preflight",
        lambda *_args, **_kwargs: {"ok": True, "provider_capabilities": {}, "failures": []},
    )
    monkeypatch.setattr(
        run_study,
        "_load_or_create_frozen_model_map",
        lambda **_kwargs: {"claude": "sonnet", "openai": "gpt-5"},
    )

    call_count = {"n": 0}

    def _execute_block(*_args, **_kwargs):
        call_count["n"] += 1
        raise run_block.StudyValidityError(
            validity_code="study_invariants_mode_mismatch",
            details={"ok": False},
            slot_id="ab-001",
        )

    monkeypatch.setattr(run_study, "execute_block", _execute_block)

    result = run_study.run(manifest_path, output_dir)
    assert result["status"] == "FAILED_VALIDITY"
    assert result["validity"]["validity_code"] == "study_invariants_mode_mismatch"
    assert call_count["n"] == 1


def test_run_study_passes_task_set_to_execute_block(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest_path = tmp_path / "manifest.json"
    output_dir = tmp_path / "results"
    _write_json(
        manifest_path,
        {
            "schema_version": "cortex_study_manifest_v1",
            "models": {"claude": {}, "openai": {}},
            "default_providers": ["claude", "openai"],
        },
    )

    monkeypatch.setattr(
        run_study,
        "run_preflight",
        lambda *_args, **_kwargs: {"ok": True, "provider_capabilities": {}, "failures": []},
    )
    monkeypatch.setattr(
        run_study,
        "_load_or_create_frozen_model_map",
        lambda **_kwargs: {"claude": "sonnet", "openai": "gpt-5.2-codex"},
    )
    monkeypatch.setattr(run_study, "score_block", lambda *_args, **_kwargs: {"quality_flags": []})
    monkeypatch.setattr(run_study, "build_blind_packet", lambda *_args, **_kwargs: {"selected_cases": 0})
    monkeypatch.setattr(run_study, "analyze", lambda *_args, **_kwargs: {"records": 0})
    monkeypatch.setattr(
        run_study,
        "_sanitize_bundle",
        lambda *_args, **_kwargs: {"privacy_issues": [], "record_count": 0},
    )

    task_sets_seen: list[str] = []

    def _execute_block(*_args, **kwargs):
        task_sets_seen.append(str(kwargs.get("task_set")))
        return {"ok": True}

    monkeypatch.setattr(run_study, "execute_block", _execute_block)

    result = run_study.run(manifest_path, output_dir, task_set="smoke")
    assert result["status"] == "DONE"
    assert task_sets_seen == ["smoke", "smoke"]


def test_run_study_model_resolution_failure_returns_failed_precheck(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest_path = tmp_path / "manifest.json"
    output_dir = tmp_path / "results"
    _write_json(
        manifest_path,
        {
            "schema_version": "cortex_study_manifest_v1",
            "models": {"claude": {}, "openai": {}},
            "default_providers": ["claude", "openai"],
        },
    )

    monkeypatch.setattr(
        run_study,
        "run_preflight",
        lambda *_args, **_kwargs: {"ok": True, "provider_capabilities": {}, "failures": []},
    )
    monkeypatch.setattr(
        run_study,
        "_load_or_create_frozen_model_map",
        lambda **_kwargs: (_ for _ in ()).throw(RuntimeError("Model probe failed for: claude")),
    )
    monkeypatch.setattr(run_study, "execute_block", lambda *_args, **_kwargs: pytest.fail("execute_block should not run"))

    result = run_study.run(manifest_path, output_dir)
    assert result["status"] == "FAILED_PRECHECK"
    assert result["failures"] == ["model_resolution_failed:Model probe failed for: claude"]


def test_preflight_profile_check_uses_shared_prepare_helper(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    called: dict[str, Any] = {}

    def _prepare(**kwargs):
        called.update(kwargs)
        return {"ok": True, "study_invariants_mode": {"ok": True}}

    monkeypatch.setattr(preflight_certify, "prepare_study_condition_workspace", _prepare)
    root = tmp_path / "profile-root"
    report = preflight_certify._profile_check(root, "claude", {"strict_overlay": {}})
    assert report["ok"] is True
    assert called["condition"] == "B"
    assert called["provider"] == "claude"
    assert called["workspace"] == root


def test_preflight_openai_probe_errors_quarantine_without_failing_precheck(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest_path = tmp_path / "manifest.json"
    _write_json(
        manifest_path,
        {
            "schema_version": "cortex_study_manifest_v1",
            "models": {"claude": {}, "openai": {}},
            "default_providers": ["claude", "openai"],
        },
    )

    monkeypatch.setattr(preflight_certify, "_required_test_paths", lambda _providers: [])
    monkeypatch.setattr(
        preflight_certify,
        "_profile_check",
        lambda *_args, **_kwargs: {
            "ok": True,
            "errors": [],
            "prep": {"ok": True},
            "study_invariants_mode": {"ok": True},
        },
    )
    monkeypatch.setattr(
        preflight_certify,
        "_probe_claude_hooks",
        lambda _root: {"ok": True, "errors": [], "warnings": []},
    )
    monkeypatch.setattr(
        preflight_certify,
        "_probe_openai_approval_blocking",
        lambda _root, _manifest: {
            "ok": False,
            "errors": ["openai_probe:return_code_124"],
            "warnings": [],
            "capability": {
                "approval_blocking_proven": False,
                "coverage_gaps": [],
                "promotable": False,
                "quarantine_reason": "openai_probe_failed",
            },
        },
    )

    report = preflight_certify.run_preflight(
        manifest_path,
        tmp_path / "preflight-out",
        providers=["claude", "openai"],
    )
    assert report["ok"] is True
    assert report["failures"] == []
    assert "openai:openai_probe:return_code_124" in report["warnings"]
    assert report["provider_capabilities"]["openai"]["promotable"] is False
    assert report["provider_capabilities"]["openai"]["quarantine_reason"] == "openai_probe_failed"


def test_openai_probe_requires_three_consecutive_passes_for_promotable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls = {"probe_attempt": 0}

    def _fake_run_command(cmd: list[str], **kwargs: Any) -> dict[str, Any]:
        if "probe-model" in cmd:
            payload = {"available": True, "source": "model/list"}
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 0,
                "stdout": json.dumps(payload),
                "stderr": "",
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        if "probe-approval-blocking" in cmd:
            calls["probe_attempt"] += 1
            payload = {
                "blocked_decline_observed": True,
                "coverage_gaps": [],
            }
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 0,
                "stdout": json.dumps(payload),
                "stderr": "",
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        raise AssertionError(f"unexpected command: {cmd}")

    monkeypatch.setattr(preflight_certify, "run_command", _fake_run_command)
    manifest = {
        "models": {
            "openai": {
                "cli": "codex",
                "probe_order": ["gpt-5.2-codex"],
                "timeout_seconds": 30,
            }
        }
    }
    report = preflight_certify._probe_openai_approval_blocking(tmp_path, manifest)
    assert calls["probe_attempt"] == 3
    assert report["capability"]["promotable"] is True
    assert report["consecutive_passes"] == 3


def test_openai_probe_marks_non_promotable_when_three_pass_bar_not_met(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls = {"probe_attempt": 0}

    def _fake_run_command(cmd: list[str], **kwargs: Any) -> dict[str, Any]:
        if "probe-model" in cmd:
            payload = {"available": True, "source": "model/list"}
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 0,
                "stdout": json.dumps(payload),
                "stderr": "",
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        if "probe-approval-blocking" in cmd:
            calls["probe_attempt"] += 1
            blocked = calls["probe_attempt"] != 2
            payload = {
                "blocked_decline_observed": blocked,
                "coverage_gaps": [] if blocked else ["pre_tool_use_nonblocking_approval"],
            }
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 0,
                "stdout": json.dumps(payload),
                "stderr": "",
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        raise AssertionError(f"unexpected command: {cmd}")

    monkeypatch.setattr(preflight_certify, "run_command", _fake_run_command)
    manifest = {
        "models": {
            "openai": {
                "cli": "codex",
                "probe_order": ["gpt-5.2-codex"],
                "timeout_seconds": 30,
            }
        }
    }
    report = preflight_certify._probe_openai_approval_blocking(tmp_path, manifest)
    assert calls["probe_attempt"] == 2
    assert report["capability"]["promotable"] is False
    assert report["capability"]["quarantine_reason"] == "pre_tool_use_nonblocking_approval"


def test_build_blind_packet_writes_failure_atlas_for_empty_side(tmp_path: Path) -> None:
    output_dir = tmp_path / "study"
    _write_json(
        output_dir / "checkpoints" / "ab.json",
        {
            "completed_slots": {
                "ab-1": {"final_run_id": "run-a"},
                "ab-2": {"final_run_id": "run-b"},
            }
        },
    )
    _write_json(output_dir / "checkpoints" / "bc.json", {"completed_slots": {}})

    def _record(run_id: str, condition: str, model_text: str) -> dict[str, Any]:
        return {
            "run_id": run_id,
            "block": "ab",
            "task_id": "task_a01",
            "model_provider": "claude",
            "condition": condition,
            "status": "ok",
            "model_text": model_text,
            "stdout": model_text,
            "checker": {"passed": True, "defects": []},
            "metrics": {
                "artifact_pass": True,
                "enforcement_pass": True,
                "response_present": bool(model_text.strip()),
                "composite_pass": bool(model_text.strip()),
            },
        }

    _write_json(output_dir / "raw_local" / "runs" / "run-a.json", _record("run-a", "A", "useful response with enough tokens to pass"))
    _write_json(output_dir / "raw_local" / "runs" / "run-b.json", _record("run-b", "B", ""))

    result = build_blind_packet.build_blind_packet(output_dir, sample_size=12, min_tokens=5, seed=7)
    assert result["selected_cases"] == 0
    assert result["excluded_pairs"] == 1
    atlas = Path(result["failure_atlas"]).read_text(encoding="utf-8")
    assert "empty_output" in atlas


def test_run_model_openai_condition_a_uses_direct_exec(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    captured: dict[str, Any] = {}

    def _fake_run_command(cmd: list[str], **kwargs: Any) -> dict[str, Any]:
        captured["cmd"] = list(cmd)
        captured["cwd"] = kwargs.get("cwd")
        last_message_flag = cmd.index("--output-last-message")
        last_message_path = Path(cmd[last_message_flag + 1])
        last_message_path.write_text("openai direct output\n", encoding="utf-8")
        return {
            "command": cmd,
            "cwd": str(kwargs.get("cwd")),
            "return_code": 0,
            "stdout": "",
            "stderr": "",
            "elapsed_seconds": 0.1,
            "timed_out": False,
        }

    monkeypatch.setattr(run_block, "run_command", _fake_run_command)
    result = run_block._run_model(
        provider="openai",
        condition="A",
        resolved_model="gpt-5.2-codex",
        prompt="solve task",
        workspace=workspace,
        manifest={"models": {"openai": {"cli": "codex", "timeout_seconds": 30}}},
    )
    assert captured["cmd"][0:2] == ["codex", "exec"]
    assert "--output-last-message" in captured["cmd"]
    assert result["execution_path"] == "openai_exec"
    assert result["output_last_message_text"].strip() == "openai direct output"


def test_run_model_openai_condition_b_uses_bridge(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    captured: dict[str, Any] = {}

    def _fake_run_command(cmd: list[str], **kwargs: Any) -> dict[str, Any]:
        captured["cmd"] = list(cmd)
        return {
            "command": cmd,
            "cwd": str(kwargs.get("cwd")),
            "return_code": 0,
            "stdout": "{\"text\":\"bridge output\"}",
            "stderr": "",
            "elapsed_seconds": 0.1,
            "timed_out": False,
        }

    monkeypatch.setattr(run_block, "run_command", _fake_run_command)
    monkeypatch.setattr(run_block, "resolve_python", lambda: "python3")
    result = run_block._run_model(
        provider="openai",
        condition="B",
        resolved_model="gpt-5.2-codex",
        prompt="solve task",
        workspace=workspace,
        manifest={"models": {"openai": {"cli": "codex", "timeout_seconds": 30}}},
    )
    assert captured["cmd"][0:3] == ["python3", "-m", "cortex_ops_cli.openai_app_server_bridge"]
    assert "run" in captured["cmd"]
    assert result["execution_path"] == "openai_bridge"


def test_probe_model_openai_uses_bridge_probe_model(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, Any] = {}

    def _fake_run_command(cmd: list[str], **kwargs: Any) -> dict[str, Any]:
        captured["cmd"] = list(cmd)
        return {
            "command": cmd,
            "cwd": str(kwargs.get("cwd")),
            "return_code": 2,
            "stdout": json.dumps({"available": True, "source": "model/list"}),
            "stderr": "",
            "elapsed_seconds": 0.1,
            "timed_out": False,
        }

    monkeypatch.setattr(run_block, "run_command", _fake_run_command)
    monkeypatch.setattr(run_block, "resolve_python", lambda: "python3")
    probe = run_block._probe_model(
        "openai",
        {"cli": "codex", "timeout_seconds": 30},
        "gpt-5.2-codex",
    )
    assert captured["cmd"][0:3] == ["python3", "-m", "cortex_ops_cli.openai_app_server_bridge"]
    assert "probe-model" in captured["cmd"]
    assert probe["available"] is True


def test_run_model_respects_timeout_override(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    captured: dict[str, Any] = {}

    def _fake_run_command(cmd: list[str], **kwargs: Any) -> dict[str, Any]:
        captured["timeout"] = kwargs.get("timeout")
        last_message_flag = cmd.index("--output-last-message")
        last_message_path = Path(cmd[last_message_flag + 1])
        last_message_path.write_text("ok\n", encoding="utf-8")
        return {
            "command": cmd,
            "cwd": str(kwargs.get("cwd")),
            "return_code": 0,
            "stdout": "",
            "stderr": "",
            "elapsed_seconds": 0.1,
            "timed_out": False,
        }

    monkeypatch.setattr(run_block, "run_command", _fake_run_command)
    run_block._run_model(
        provider="openai",
        condition="A",
        resolved_model="gpt-5.2-codex",
        prompt="solve task",
        workspace=workspace,
        manifest={"models": {"openai": {"cli": "codex", "timeout_seconds": 420}}},
        timeout_override=45,
    )
    assert captured["timeout"] == 45


def test_balanced_capped_schedule_assigns_slots_to_both_providers() -> None:
    schedule = [
        {"slot_id": "s1", "model_provider": "claude"},
        {"slot_id": "s2", "model_provider": "claude"},
        {"slot_id": "s3", "model_provider": "openai"},
        {"slot_id": "s4", "model_provider": "openai"},
    ]
    selected = balanced_capped_schedule(
        schedule=schedule,
        providers=["claude", "openai"],
        max_slots=2,
    )
    providers = [slot["model_provider"] for slot in selected]
    assert providers == ["claude", "openai"]


def test_load_tasks_smoke_task_set_selects_only_target_task(tmp_path: Path) -> None:
    task_dir = tmp_path / "tasks"
    task_dir.mkdir(parents=True, exist_ok=True)
    _write_json(task_dir / "task_a01.json", {"task_id": "task_a01"})
    _write_json(task_dir / "task_a02.json", {"task_id": "task_a02"})
    manifest = {
        "task_files": [
            str((task_dir / "task_a01.json").relative_to(tmp_path)),
            str((task_dir / "task_a02.json").relative_to(tmp_path)),
        ],
        "task_sets": {"smoke": ["task_a01"]},
    }
    tasks = load_tasks(manifest, base=tmp_path, task_set="smoke")
    assert [task["task_id"] for task in tasks] == ["task_a01"]


def test_analyze_hard_quarantines_openai_on_nonblocking_gap(tmp_path: Path) -> None:
    output_dir = tmp_path / "study"
    manifest_path = tmp_path / "manifest.json"
    _write_json(
        manifest_path,
        {
            "schema_version": "cortex_study_manifest_v1",
            "thresholds": {"primary_min_improvement_b_over_a": 0.1},
        },
    )
    _write_json(output_dir / "checkpoints" / "ab.json", {"completed_slots": {}})
    _write_json(output_dir / "checkpoints" / "bc.json", {"completed_slots": {}})
    result = analyze_all.analyze(
        output_dir,
        manifest_path,
        providers=["openai"],
        provider_capabilities={
            "openai": {
                "promotable": True,
                "quarantine_reason": "",
                "coverage_gaps": ["pre_tool_use_nonblocking_approval"],
            }
        },
    )
    assert result["provider_roles"]["quarantined"]["openai"] == "pre_tool_use_nonblocking_approval"
