from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import threading
from types import SimpleNamespace

import pytest

from cortex.repomap import (
    MAX_DISCOVER_FILE_BYTES,
    RepoMapFileAnalysis,
    RepoMapRankingEntry,
    _active_tree_sitter_lang_by_suffix,
    _extract_import_targets,
    _extract_symbol_summaries,
    _build_dependency_edges,
    _discover_files,
    _pagerank_scores_with_backend,
    _rank_files,
    _render_text,
    _tree_sitter_parse_ok,
    run_repomap,
)


def test_run_repomap_writes_valid_artifact_and_applies_ignores(tmp_path: Path) -> None:
    root = tmp_path / "repo"
    (root / "src" / "nested").mkdir(parents=True)
    (root / "node_modules" / "pkg").mkdir(parents=True)
    (root / "dist").mkdir()
    (root / ".cortex").mkdir()

    (root / "src" / "app.py").write_text("def run():\n    return 1\n", encoding="utf-8")
    (root / "src" / "util.ts").write_text("export const x = 1;\n", encoding="utf-8")
    (root / "src" / "nested" / "data.json").write_text('{"ok": true}\n', encoding="utf-8")
    (root / "src" / "bundle.min.js").write_text("minified\n", encoding="utf-8")
    (root / "src" / "bundle.js.map").write_text("{}\n", encoding="utf-8")
    (root / "node_modules" / "pkg" / "index.js").write_text("module.exports={}\n", encoding="utf-8")
    (root / "dist" / "out.js").write_text("console.log(1)\n", encoding="utf-8")
    (root / ".cortex" / "ignore.txt").write_text("ignore me\n", encoding="utf-8")
    (root / "src" / "logo.png").write_bytes(b"\x89PNG\r\n\x1a\n")

    result = run_repomap(
        root=root,
        scope=["src", "node_modules", "dist", ".cortex"],
        focus_files=["src/app.py"],
        max_files=10,
        max_text_bytes=2048,
    )

    assert result.ok is True
    assert result.artifact.schema_version == "repomap_artifact_v1"
    assert result.artifact_path
    artifact_path = Path(result.artifact_path)
    assert artifact_path.exists()
    assert result.artifact.provenance["method"] in {"heuristic_fallback", "ast_pagerank"}
    assert result.artifact.provenance["scope"] == ["src", "node_modules", "dist", ".cortex"]
    assert result.artifact.stats["files_parsed"] == 3
    assert result.artifact.ranking
    assert result.artifact.ranking[0].path == "src/app.py"
    assert "node_modules/pkg/index.js" not in result.artifact.text
    assert "dist/out.js" not in result.artifact.text

    saved = json.loads(artifact_path.read_text(encoding="utf-8"))
    assert saved["schema_version"] == "repomap_artifact_v1"
    assert saved["ok"] is True
    assert "artifact_path" not in saved


def test_run_repomap_empty_scope_emits_valid_empty_artifact(tmp_path: Path) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)

    result = run_repomap(root=root, scope=["src"], max_files=5, max_text_bytes=512)

    assert result.ok is True
    assert result.artifact.stats["files_parsed"] == 0
    assert result.artifact.ranking == []
    assert result.artifact.text == ""
    assert result.artifact_path and Path(result.artifact_path).exists()


def test_run_repomap_auto_falls_back_scope_when_default_scope_missing(tmp_path: Path) -> None:
    root = tmp_path / "repo"
    (root / "cortex").mkdir(parents=True)
    (root / "cortex" / "mod.py").write_text("class Engine:\n    pass\n", encoding="utf-8")

    result = run_repomap(root=root)

    assert result.ok is True
    assert result.artifact.stats["files_parsed"] == 1
    assert result.artifact.ranking[0].path == "cortex/mod.py"
    assert "cortex" in result.artifact.provenance["scope"]


def test_run_repomap_write_failure_returns_failure_envelope(tmp_path: Path) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "a.py").write_text("x = 1\n", encoding="utf-8")
    (root / "bad-output").mkdir()

    result = run_repomap(root=root, scope=["src"], output_path="bad-output")

    assert result.ok is False
    assert result.artifact.error is not None
    assert result.artifact.error["code"] == "write_failed"
    assert result.artifact.error["failed_stage"] == "write"
    assert result.artifact.stats["files_parsed"] == 0


def test_run_repomap_without_timeout_does_not_inherit_config_timeout(tmp_path: Path) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "a.py").write_text("x = 1\n", encoding="utf-8")

    class Config:
        watch_paths = ["src"]
        ignored_dirs: list[str] = []
        artifact_path = ".cortex/artifacts/repomap/latest.json"
        max_ranked_files = 5
        max_text_bytes = 1024
        session_start_timeout_ms = 0

    result = run_repomap(root=root, repomap_config=Config(), timeout_ms=None)

    assert result.ok is True
    assert result.artifact.provenance["timeout_ms"] is None


def test_run_repomap_uses_ast_with_simple_pagerank_when_networkx_missing(
    tmp_path: Path, monkeypatch
) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "app.py").write_text("def run():\n    return 1\n", encoding="utf-8")
    monkeypatch.setattr("cortex.repomap.repomap_missing_dependencies", lambda: ["networkx"])
    monkeypatch.setattr("cortex.repomap._pagerank_scores_networkx", lambda _paths, _edges: {})

    result = run_repomap(root=root, scope=["src"])

    assert result.ok is True
    assert result.artifact.provenance["method"] == "ast_pagerank"
    assert result.artifact.provenance["ast_requested"] is True
    assert result.artifact.provenance["ast_enabled"] is True
    assert result.artifact.provenance["missing_deps"] == ["networkx"]
    assert result.artifact.provenance["pagerank_backend"] == "simple"


def test_run_repomap_uses_ast_pagerank_when_deps_available(tmp_path: Path, monkeypatch) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "main.ts").write_text('import helper from "./helper";\n', encoding="utf-8")
    (root / "src" / "helper.ts").write_text("export default function helper() {}\n", encoding="utf-8")
    monkeypatch.setattr("cortex.repomap.repomap_missing_dependencies", lambda: [])
    monkeypatch.setattr(
        "cortex.repomap._pagerank_scores_networkx",
        lambda paths, edges: {path: (1.0 if path.endswith("helper.ts") else 0.0) for path in paths},
    )

    result = run_repomap(root=root, scope=["src"])

    assert result.ok is True
    assert result.artifact.provenance["method"] == "ast_pagerank"
    assert result.artifact.provenance["ast_enabled"] is True
    assert result.artifact.provenance["missing_deps"] == []
    assert result.artifact.provenance["pagerank_backend"] == "networkx"
    assert result.artifact.stats["graph_edges"] >= 1
    assert result.artifact.ranking[0].path == "src/helper.ts"


def test_run_repomap_parity_profile_fails_when_parser_deps_missing(
    tmp_path: Path, monkeypatch
) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "main.ts").write_text("export function main() {}\n", encoding="utf-8")
    monkeypatch.setattr(
        "cortex.repomap.repomap_missing_parser_dependencies",
        lambda: ["tree-sitter", "tree-sitter-language-pack"],
    )

    result = run_repomap(root=root, scope=["src"], parity_profile=True)

    assert result.ok is False
    assert result.artifact.error is not None
    assert result.artifact.error["code"] == "deps_missing"
    assert result.artifact.provenance["parser_profile"] == "parity"
    assert result.artifact.provenance["parser_deps_missing"] == [
        "tree-sitter",
        "tree-sitter-language-pack",
    ]


def test_run_repomap_parity_profile_fails_when_tree_sitter_not_used(
    tmp_path: Path, monkeypatch
) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "notes.txt").write_text("plain text\n", encoding="utf-8")
    monkeypatch.setattr("cortex.repomap.repomap_missing_parser_dependencies", lambda: [])

    result = run_repomap(root=root, scope=["src"], parity_profile=True)

    assert result.ok is False
    assert result.artifact.error is not None
    assert result.artifact.error["code"] == "parser_not_used"


def test_run_repomap_parity_profile_reports_parser_metadata(tmp_path: Path, monkeypatch) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "main.ts").write_text("export function main() {}\n", encoding="utf-8")
    monkeypatch.setattr("cortex.repomap.repomap_missing_parser_dependencies", lambda: [])
    monkeypatch.setattr(
        "cortex.repomap._tree_sitter_parse_ok",
        lambda *_args, **_kwargs: (True, True),
    )

    result = run_repomap(root=root, scope=["src"], parity_profile=True)

    assert result.ok is True
    provenance = result.artifact.provenance
    assert provenance["parser_profile"] == "parity"
    assert provenance["parser_backend"] == "tree_sitter"
    assert provenance["parser_deps_missing"] == []
    assert provenance["parser_stats"]["tree_sitter_files_parsed"] >= 1


def test_run_repomap_profile_attempt_counts_core_vs_extended(tmp_path: Path, monkeypatch) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "main.ts").write_text("export function main() {}\n", encoding="utf-8")
    (root / "src" / "ext.go").write_text("package main\n", encoding="utf-8")
    monkeypatch.setattr("cortex.repomap.repomap_missing_parser_dependencies", lambda: [])
    monkeypatch.setattr(
        "cortex.repomap._tree_sitter_parse_ok",
        lambda *_args, **_kwargs: (True, True),
    )

    core_cfg = SimpleNamespace(
        watch_paths=["src"],
        ignored_dirs=[],
        artifact_path=".cortex/artifacts/repomap/latest.json",
        max_ranked_files=20,
        max_text_bytes=8192,
        prefer_ast_graph=True,
        parity_profile=False,
        extended_language_profile=False,
    )
    ext_cfg = SimpleNamespace(
        watch_paths=["src"],
        ignored_dirs=[],
        artifact_path=".cortex/artifacts/repomap/latest.json",
        max_ranked_files=20,
        max_text_bytes=8192,
        prefer_ast_graph=True,
        parity_profile=False,
        extended_language_profile=True,
    )

    core_result = run_repomap(root=root, repomap_config=core_cfg, scope=["src"])
    ext_result = run_repomap(root=root, repomap_config=ext_cfg, scope=["src"])

    core_prov = core_result.artifact.provenance
    ext_prov = ext_result.artifact.provenance
    assert core_prov["language_profile"] == "core"
    assert ext_prov["language_profile"] == "extended"
    assert core_prov["parser_stats"]["tree_sitter_files_attempted"] == 1
    assert ext_prov["parser_stats"]["tree_sitter_files_attempted"] == 2


def test_run_repomap_concurrent_mixed_profiles_no_cross_contamination(
    tmp_path: Path, monkeypatch
) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "main.ts").write_text("export function main() {}\n", encoding="utf-8")
    (root / "src" / "ext.go").write_text("package main\n", encoding="utf-8")
    monkeypatch.setattr("cortex.repomap.repomap_missing_parser_dependencies", lambda: [])
    monkeypatch.setattr(
        "cortex.repomap._tree_sitter_parse_ok",
        lambda *_args, **_kwargs: (True, True),
    )

    def _run_one(idx: int, extended: bool) -> tuple[bool, int]:
        cfg = SimpleNamespace(
            watch_paths=["src"],
            ignored_dirs=[],
            artifact_path=".cortex/artifacts/repomap/latest.json",
            max_ranked_files=20,
            max_text_bytes=8192,
            prefer_ast_graph=True,
            parity_profile=False,
            extended_language_profile=extended,
        )
        result = run_repomap(
            root=root,
            repomap_config=cfg,
            scope=["src"],
            output_path=f".cortex/artifacts/repomap/concurrent-{idx}.json",
        )
        attempted = result.artifact.provenance["parser_stats"]["tree_sitter_files_attempted"]
        return extended, int(attempted)

    requests = [(idx, idx % 2 == 0) for idx in range(10)]
    with ThreadPoolExecutor(max_workers=6) as pool:
        results = [future.result() for future in [pool.submit(_run_one, idx, ext) for idx, ext in requests]]

    for extended, attempted in results:
        assert attempted == (2 if extended else 1)


def test_run_repomap_concurrent_runs_do_not_share_parser_cache_state(
    tmp_path: Path, monkeypatch
) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "main.ts").write_text("export function main() {}\n", encoding="utf-8")
    (root / "src" / "ext.go").write_text("package main\n", encoding="utf-8")
    monkeypatch.setattr("cortex.repomap.repomap_missing_parser_dependencies", lambda: [])

    thread_context = threading.local()
    cache_obj_by_run: dict[int, object] = {}

    class _FakeTree:
        root_node = object()

    class _FakeParser:
        def parse(self, _source_bytes: bytes):
            return _FakeTree()

    def _recording_parser(language: str, *, parser_cache=None):
        del language
        assert parser_cache is not None
        run_id = getattr(thread_context, "run_id", None)
        if run_id is not None:
            key = int(run_id)
            existing = cache_obj_by_run.get(key)
            if existing is None:
                cache_obj_by_run[key] = parser_cache
            else:
                assert existing is parser_cache
        return _FakeParser()

    monkeypatch.setattr("cortex.repomap._tree_sitter_parser", _recording_parser)

    def _run_one(idx: int, extended: bool) -> int:
        thread_context.run_id = idx
        try:
            cfg = SimpleNamespace(
                watch_paths=["src"],
                ignored_dirs=[],
                artifact_path=".cortex/artifacts/repomap/latest.json",
                max_ranked_files=20,
                max_text_bytes=8192,
                prefer_ast_graph=True,
                parity_profile=False,
                extended_language_profile=extended,
            )
            result = run_repomap(
                root=root,
                repomap_config=cfg,
                scope=["src"],
                output_path=f".cortex/artifacts/repomap/cache-concurrent-{idx}.json",
            )
            attempted = result.artifact.provenance["parser_stats"]["tree_sitter_files_attempted"]
            return int(attempted)
        finally:
            thread_context.run_id = None

    requests = [(idx, idx % 2 == 0) for idx in range(10)]
    with ThreadPoolExecutor(max_workers=6) as pool:
        attempts = [future.result() for future in [pool.submit(_run_one, idx, ext) for idx, ext in requests]]

    assert len(cache_obj_by_run) == len(requests)
    single_cache_ids = []
    for idx, extended in requests:
        assert attempts[idx] == (2 if extended else 1)
        single_cache_ids.append(id(cache_obj_by_run[idx]))
    assert len(set(single_cache_ids)) == len(requests)


_TREE_SITTER_STRESS_CASES: list[tuple[str, str]] = [
    (
        "src/demo.ts",
        """
import base from "./base";
export {
  alpha,
  beta as gamma,
} from "./shared";
export interface DemoShape {
  id: string;
}
export type DemoState = {
  ready: boolean;
};
export class DemoController {}
export async function runDemo() {}
const helper = () => 1;
        """.strip(),
    ),
    (
        "src/demo.py",
        """
from pkg.deep.module import endpoint

class Demo:
    pass

def run_demo() -> int:
    return 1
        """.strip(),
    ),
    (
        "src/pages/index.astro",
        """
---
import Hero from "./Hero.astro";
export function renderHero() {
  return Hero;
}
---
<main><Hero /></main>
        """.strip(),
    ),
    (
        "cmd/main.go",
        """
package main

import "fmt"

type Server struct {
    Port int
}

type Handler interface {
    ServeHTTP()
}

func (s *Server) Start() error {
    fmt.Println("starting")
    return nil
}

func NewServer(port int) *Server {
    return &Server{Port: port}
}
        """.strip(),
    ),
    (
        "src/config.rs",
        """
use std::collections::HashMap;

pub struct Config {
    pub name: String,
    values: HashMap<String, i64>,
}

pub enum Status {
    Active,
    Inactive(String),
}

pub trait Processor {
    fn process(&self, input: &str) -> Result<String, Box<dyn std::error::Error>>;
}

impl Config {
    pub fn new(name: &str) -> Self {
        Self { name: name.to_string(), values: HashMap::new() }
    }
}
        """.strip(),
    ),
    (
        "app/workers/processor.rb",
        """
require 'json'
require_relative 'helpers'

module Workers
  class Processor
    def initialize(config)
      @config = config
    end

    def call(payload)
      JSON.parse(payload)
    end
  end
end
        """.strip(),
    ),
    (
        "src/main/java/DemoService.java",
        """
package com.example.demo;

import java.util.List;
import java.util.Map;

public class DemoService {
    private final Map<String, Object> config;

    public DemoService(Map<String, Object> config) {
        this.config = config;
    }

    public interface Callback {
        void onComplete(List<String> results);
    }

    public static void main(String[] args) {
        System.out.println("running");
    }
}
        """.strip(),
    ),
    (
        "src/point.c",
        """
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int x;
    int y;
} Point;

void print_point(const Point *p) {
    printf("(%d, %d)\\n", p->x, p->y);
}

int main(int argc, char *argv[]) {
    Point p = {1, 2};
    print_point(&p);
    return 0;
}
        """.strip(),
    ),
    (
        "src/engine.cpp",
        """
#include <string>
#include <vector>

class Engine {
public:
    Engine(const std::string& name) : name_(name) {}
    virtual ~Engine() = default;
    virtual void run() = 0;

protected:
    std::string name_;
};

namespace util {
    template<typename T>
    std::vector<T> make_vec(T first) {
        return {first};
    }
}
        """.strip(),
    ),
    (
        "src/main.kt",
        """
package com.example

data class Config(val name: String, val debug: Boolean = false)

interface Repository<T> {
    fun findAll(): List<T>
}

fun processItems(items: List<String>): Int {
    return items.size
}
        """.strip(),
    ),
    (
        "Sources/App/Engine.swift",
        """
import Foundation

protocol Runnable {
    func run() async throws
}

struct AppConfig {
    let name: String
    let retries: Int
}

class AppEngine: Runnable {
    private let config: AppConfig

    init(config: AppConfig) {
        self.config = config
    }

    func run() async throws {
        print("Running \\(config.name)")
    }
}
        """.strip(),
    ),
    (
        "src/UserController.php",
        """<?php
namespace App\\Controllers;

use App\\Models\\User;

class UserController {
    public function index(): array {
        return User::all();
    }
}
        """.strip(),
    ),
    (
        "scripts/check.sh",
        """#!/usr/bin/env bash
set -euo pipefail

run_checks() {
    local target="$1"
    echo "checking $target"
}

main() {
    for f in src/*.py; do
        run_checks "$f"
    done
}

main "$@"
        """.strip(),
    ),
]


@pytest.mark.parametrize(
    "path,source",
    _TREE_SITTER_STRESS_CASES,
    ids=[path for path, _ in _TREE_SITTER_STRESS_CASES],
)
def test_tree_sitter_syntax_stress_parses(path: str, source: str) -> None:
    pytest.importorskip("tree_sitter_language_pack")
    attempted, parsed = _tree_sitter_parse_ok(
        path,
        source,
        tree_sitter_lang_by_suffix=_active_tree_sitter_lang_by_suffix(
            SimpleNamespace(extended_language_profile=True)
        ),
    )
    assert attempted is True
    assert parsed is True


def test_regex_fallback_misses_multiline_ts_import_but_tree_sitter_parses() -> None:
    pytest.importorskip("tree_sitter_language_pack")
    source = """
    import {
      alpha,
      beta,
    } from "./shared";
    """.strip()

    assert _extract_import_targets(source) == []
    attempted, parsed = _tree_sitter_parse_ok("src/demo.ts", source)
    assert attempted is True
    assert parsed is True


def test_regex_fallback_misses_multiline_python_from_import_but_tree_sitter_parses() -> None:
    pytest.importorskip("tree_sitter_language_pack")
    source = """
    from collections.abc import (
        AsyncIterator,
        Awaitable,
    )
    """.strip()

    assert _extract_import_targets(source) == []
    attempted, parsed = _tree_sitter_parse_ok("src/demo.py", source)
    assert attempted is True
    assert parsed is True


def test_run_repomap_tree_sitter_mode_keeps_python_import_edges(tmp_path: Path, monkeypatch) -> None:
    root = tmp_path / "repo"
    (root / "src" / "pkg").mkdir(parents=True)
    (root / "src" / "pkg" / "main.py").write_text("from . import util\n", encoding="utf-8")
    (root / "src" / "pkg" / "util.py").write_text("def helper():\n    return 1\n", encoding="utf-8")
    monkeypatch.setattr("cortex.repomap.repomap_missing_parser_dependencies", lambda: [])
    monkeypatch.setattr(
        "cortex.repomap._tree_sitter_parse_ok",
        lambda *_args, **_kwargs: (True, True),
    )

    result = run_repomap(root=root, scope=["src"])

    assert result.ok is True
    assert result.artifact.provenance["parser_backend"] == "tree_sitter"
    assert result.artifact.stats["graph_edges"] >= 1


def test_run_repomap_tree_sitter_mode_keeps_require_edges(tmp_path: Path, monkeypatch) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "main.js").write_text('const util = require("./util");\n', encoding="utf-8")
    (root / "src" / "util.js").write_text("module.exports = {};\n", encoding="utf-8")
    monkeypatch.setattr("cortex.repomap.repomap_missing_parser_dependencies", lambda: [])
    monkeypatch.setattr(
        "cortex.repomap._tree_sitter_parse_ok",
        lambda *_args, **_kwargs: (True, True),
    )

    result = run_repomap(root=root, scope=["src"])

    assert result.ok is True
    assert result.artifact.provenance["parser_backend"] == "tree_sitter"
    assert result.artifact.stats["graph_edges"] >= 1


def test_rank_files_uses_deterministic_tie_breaker_by_path() -> None:
    analyses = [
        RepoMapFileAnalysis(path="src/bbb.py", byte_size=10, line_count=10, symbols=[], symbol_count=0),
        RepoMapFileAnalysis(path="src/aaa.py", byte_size=10, line_count=10, symbols=[], symbol_count=0),
    ]

    ranked = _rank_files(analyses, focus_files=[], max_files=10)

    assert [entry.path for entry in ranked] == ["src/aaa.py", "src/bbb.py"]


def test_build_dependency_edges_resolves_python_relative_imports() -> None:
    analyses = [
        RepoMapFileAnalysis(
            path="src/pkg/module.py",
            byte_size=32,
            line_count=2,
            symbols=[],
            symbol_count=0,
            imports=[".helpers"],
        ),
        RepoMapFileAnalysis(
            path="src/pkg/helpers.py",
            byte_size=16,
            line_count=1,
            symbols=[],
            symbol_count=0,
            imports=[],
        ),
    ]

    edges = _build_dependency_edges(analyses)

    assert ("src/pkg/module.py", "src/pkg/helpers.py") in edges


def test_pagerank_scores_prefers_dependency_hub() -> None:
    paths = ["src/main.ts", "src/feature.ts", "src/util.ts"]
    edges = [("src/main.ts", "src/util.ts"), ("src/feature.ts", "src/util.ts")]

    scores, backend = _pagerank_scores_with_backend(paths, edges)

    assert scores["src/util.ts"] > scores["src/main.ts"]
    assert scores["src/util.ts"] > scores["src/feature.ts"]
    assert backend in {"networkx", "simple"}


def test_rank_files_penalizes_lockfiles_and_boosts_astro_components() -> None:
    analyses = [
        RepoMapFileAnalysis(
            path="sample-site/package-lock.json",
            byte_size=100,
            line_count=200,
            symbols=[],
            symbol_count=0,
        ),
        RepoMapFileAnalysis(
            path="sample-site/src/components/GuidedDemo.astro",
            byte_size=100,
            line_count=200,
            symbols=[],
            symbol_count=0,
        ),
    ]

    ranked = _rank_files(analyses, focus_files=[], max_files=10)

    assert ranked[0].path == "sample-site/src/components/GuidedDemo.astro"
    assert ranked[1].path == "sample-site/package-lock.json"


def test_render_text_applies_truncation_note_and_byte_cap() -> None:
    ranking = [
        RepoMapRankingEntry(
            path=f"src/very_long_module_name_{i}.py",
            score=1.234 + i,
            symbols=[f"def symbol_{i}_{j}" for j in range(3)],
        )
        for i in range(20)
    ]

    text = _render_text(ranking, max_text_bytes=256)

    assert "truncated" in text
    assert len(text.encode("utf-8")) <= 256


def test_discover_files_skips_large_binary_and_hidden_files(tmp_path: Path) -> None:
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "good.py").write_text("print('ok')\n", encoding="utf-8")
    (root / "src" / ".secret").write_text("hidden\n", encoding="utf-8")
    (root / "src" / "bin.dat").write_bytes(b"\x00\x01\x02")
    (root / "src" / "big.txt").write_text("x" * (MAX_DISCOVER_FILE_BYTES + 1), encoding="utf-8")

    files = _discover_files(root=root, scope=["src"], ignored_dirs=[], timeout_check=None)

    assert files == ["src/good.py"]


def test_symbol_patterns_detect_go_constructs() -> None:
    source = """
func NewServer(port int) *Server {
    return &Server{Port: port}
}

type Server struct {
    Port int
}

type Handler interface {
    ServeHTTP()
}
    """.strip()

    symbols, count = _extract_symbol_summaries(source, max_symbols=10)

    assert count >= 3
    assert any("func NewServer" in s for s in symbols)
    # Go `type X struct` and `type X interface` are detected via the generic `type` pattern
    assert any("Server" in s for s in symbols)
    assert any("Handler" in s for s in symbols)


def test_symbol_patterns_detect_rust_constructs() -> None:
    source = """
pub struct Config {
    pub name: String,
}

pub enum Status {
    Active,
}

pub trait Processor {
    fn process(&self);
}

pub fn run_main() {
    println!("ok");
}

impl Config {
    pub fn new() -> Self { Self { name: String::new() } }
}
    """.strip()

    symbols, count = _extract_symbol_summaries(source, max_symbols=10)

    assert count >= 4
    assert any("struct Config" in s for s in symbols)
    assert any("enum Status" in s for s in symbols)
    assert any("trait Processor" in s for s in symbols)
    assert any("fn run_main" in s for s in symbols)


def test_import_patterns_detect_go_imports() -> None:
    source = '''
import "fmt"
import "os"
    '''.strip()

    imports = _extract_import_targets(source)

    assert "fmt" in imports
    assert "os" in imports


def test_import_patterns_detect_go_import_block() -> None:
    source = """
import (
    "fmt"
    "os"
)
    """.strip()

    imports = _extract_import_targets(source)

    assert "fmt" in imports
    assert "os" in imports


def test_import_patterns_detect_rust_use() -> None:
    source = """
use std::collections::HashMap;
pub use crate::config::Config;
    """.strip()

    imports = _extract_import_targets(source)

    assert any("std::collections::HashMap" in i for i in imports)
    assert any("crate::config::Config" in i for i in imports)


def test_import_patterns_detect_ruby_require() -> None:
    source = """
require 'json'
require_relative 'helpers/util'
    """.strip()

    imports = _extract_import_targets(source)

    assert "json" in imports
    assert "helpers/util" in imports


def test_import_patterns_detect_java_imports() -> None:
    source = """
import java.util.List;
import static org.junit.Assert.assertEquals;
    """.strip()

    imports = _extract_import_targets(source)

    assert any("java.util.List" in i for i in imports)
    assert any("org.junit.Assert.assertEquals" in i for i in imports)


def test_mixed_language_repomap_parity_packet(tmp_path: Path, monkeypatch) -> None:
    """Mixed-language integration test: Python, TypeScript, Go, Rust files in one repomap run."""
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "main.py").write_text(
        "from . import util\n\ndef run():\n    return 1\n", encoding="utf-8"
    )
    (root / "src" / "util.py").write_text(
        "def helper():\n    return 2\n", encoding="utf-8"
    )
    (root / "src" / "app.ts").write_text(
        'import { run } from "./runner";\nexport function main() {}\n', encoding="utf-8"
    )
    (root / "src" / "runner.ts").write_text(
        "export function run() { return 1; }\n", encoding="utf-8"
    )
    (root / "src" / "server.go").write_text(
        'package main\n\nimport "fmt"\n\nfunc main() {\n    fmt.Println("ok")\n}\n',
        encoding="utf-8",
    )
    (root / "src" / "config.rs").write_text(
        "pub struct Config { pub name: String }\n\nimpl Config {\n    pub fn new() -> Self { Self { name: String::new() } }\n}\n",
        encoding="utf-8",
    )
    monkeypatch.setattr("cortex.repomap.repomap_missing_parser_dependencies", lambda: [])
    monkeypatch.setattr(
        "cortex.repomap._tree_sitter_parse_ok",
        lambda *_args, **_kwargs: (True, True),
    )

    result = run_repomap(root=root, scope=["src"])

    assert result.ok is True
    assert result.artifact.provenance["parser_backend"] == "tree_sitter"
    assert result.artifact.stats["files_parsed"] >= 6
    paths = [e.path for e in result.artifact.ranking]
    assert any(p.endswith(".py") for p in paths)
    assert any(p.endswith(".ts") for p in paths)
    assert any(p.endswith(".go") for p in paths)
    assert any(p.endswith(".rs") for p in paths)
