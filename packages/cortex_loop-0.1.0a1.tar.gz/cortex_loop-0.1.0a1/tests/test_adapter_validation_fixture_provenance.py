from __future__ import annotations

import json
import re
from pathlib import Path


_FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures" / "adapter_validation"
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def test_adapter_validation_provenance_manifests_cover_adapter_artifacts() -> None:
    adapter_dirs = sorted(
        path for path in _FIXTURES_DIR.iterdir() if path.is_dir() and path.name in {"claude", "gemini", "openai"}
    )
    assert adapter_dirs
    for adapter_dir in adapter_dirs:
        manifest_path = adapter_dir / "PROVENANCE.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        assert manifest["schema_version"] == "adapter_validation_fixture_provenance_v1"
        assert manifest["adapter"] == adapter_dir.name
        declared = manifest["artifacts"]
        assert isinstance(declared, dict)

        fixture_files = sorted(
            path.name for path in adapter_dir.glob("*.json") if path.name != "PROVENANCE.json"
        )
        assert sorted(declared.keys()) == fixture_files

        for name, meta in declared.items():
            assert meta["scenario"]
            assert meta["source"] in {"captured", "synthetic"}
            assert _SHA256_RE.fullmatch(str(meta["raw_capture_sha256"]))
            assert isinstance(meta["sanitized_fields"], list)
            captured_with = meta["captured_with"]
            assert isinstance(captured_with.get("cli"), str) and captured_with["cli"].strip()
            assert isinstance(captured_with.get("model"), str) and captured_with["model"].strip()
