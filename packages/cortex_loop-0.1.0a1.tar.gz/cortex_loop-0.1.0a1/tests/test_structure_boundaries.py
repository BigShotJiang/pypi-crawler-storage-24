from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_core_delegates_stop_path_helpers_to_stop_modules() -> None:
    source = (ROOT / "cortex" / "core.py").read_text(encoding="utf-8")

    assert "from .stop_runtime import StopPathRunner" in source
    for token in (
        "class StopPathOutcome",
        "def _run_stop_path(",
        "def _build_stop_attempt_signature(",
        "def _stop_attempt_similarity(",
        "def _signal_jaccard(",
        "def _normalize_stop_command_signal(",
    ):
        assert token not in source


def test_openai_bridge_delegates_transport_and_probe_helpers() -> None:
    source = (ROOT / "cortex_ops_cli" / "openai_app_server_bridge.py").read_text(encoding="utf-8")

    assert "from ._openai_bridge_probe import" in source
    assert "from ._openai_bridge_protocol import" in source
    for token in (
        "class AppServerClient",
        "class BridgeRunResult",
        "def classify_command_surface(",
        "def _bridge_turn_result(",
        "def execute_turn(",
        "def start_thread_with_policy_fallback(",
    ):
        assert token not in source


def test_cli_main_delegates_runtime_profile_helpers() -> None:
    source = (ROOT / "cortex_ops_cli" / "main.py").read_text(encoding="utf-8")

    assert "from cortex_ops_cli._runtime_profiles import (" in source
    for token in (
        "def starter_claude_settings_json(",
        "def starter_gemini_settings_json(",
        "def starter_openai_bridge_profile_json(",
        "def set_runtime_adapter(",
        "def resolve_claude_settings_path(",
        "def resolve_gemini_settings_path(",
        "def resolve_openai_bridge_profile_path(",
        "def validate_claude_settings(",
        "def validate_gemini_settings(",
        "def validate_openai_bridge_profile(",
    ):
        assert token not in source


def test_cli_main_delegates_check_report_helpers() -> None:
    source = (ROOT / "cortex_ops_cli" / "main.py").read_text(encoding="utf-8")

    assert "from cortex_ops_cli._check_report import (" in source
    assert "from cortex_ops_cli._check_report_output import (" in source
    for token in (
        "def _collect_check_report(",
        "def _build_kernel_metrics_payload(",
        "def _pack_temporal_protocol_summary(",
        "def _inspect_db(",
        "def _check_invariant_execution_mode(",
        "def _collect_kernel_metrics(",
        "def _python_module_metrics(",
        "def _print_check_report(",
        "def _print_fleet_report(",
        "def _write_status_artifact(",
        "def _now_iso(",
    ):
        assert token not in source


def test_check_report_delegates_output_helpers() -> None:
    source = (ROOT / "cortex_ops_cli" / "_check_report.py").read_text(encoding="utf-8")

    for token in (
        "def build_kernel_metrics_payload(",
        "def print_check_report(",
        "def print_fleet_report(",
        "def write_status_artifact(",
        "def _collect_kernel_metrics(",
        "def _write_kernel_metrics_baseline(",
        "def _read_kernel_metrics_baseline(",
        "def _diff_kernel_metrics(",
        "def _python_module_metrics(",
        "def _print_check_section(",
    ):
        assert token not in source


def test_runtime_profiles_delegate_template_payloads() -> None:
    source = (ROOT / "cortex_ops_cli" / "_runtime_profiles.py").read_text(encoding="utf-8")

    assert "from ._runtime_profile_templates import (" in source
    for token in (
        "def starter_claude_settings_json(",
        "def starter_gemini_settings_json(",
        "def starter_openai_bridge_profile_json(",
        "def starter_claude_md(",
        "def starter_gemini_md(",
        "def starter_openai_md(",
        "def _load_repo_template(",
    ):
        assert token not in source
