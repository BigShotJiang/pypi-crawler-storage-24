from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from cortex import cli as cortex_cli
from cortex.adapters import GenericAdapter
from cortex.core import CortexKernel
from cortex_ops_cli._adapter_validation import HARNESS_TEST_COMMAND


def _percentile(values_ms: list[float], fraction: float) -> float:
    ordered = sorted(values_ms)
    index = max(0, min(len(ordered) - 1, int(len(ordered) * fraction) - 1))
    return ordered[index]


def _latency_stats(values_ms: list[float]) -> tuple[float, float, float]:
    return _percentile(values_ms, 0.50), _percentile(values_ms, 0.95), _percentile(values_ms, 0.99)


def _print_latency(label: str, values_ms: list[float]) -> tuple[float, float, float]:
    p50, p95, p99 = _latency_stats(values_ms)
    print(f"\n  {label}: p50={p50:.1f}ms p95={p95:.1f}ms p99={p99:.1f}ms")
    return p50, p95, p99


def _measure(samples: int, fn: Any) -> list[float]:
    values_ms: list[float] = []
    for idx in range(samples):
        start = time.perf_counter()
        fn(idx)
        values_ms.append((time.perf_counter() - start) * 1000.0)
    return values_ms


def _init_gemini_runtime(root: Path, capsys: Any) -> None:
    assert cortex_cli.main(["init", "--root", str(root)]) == 0
    _ = capsys.readouterr()
    assert cortex_cli.main(["runtime", "install", "--profile", "gemini", "--root", str(root)]) == 0
    _ = capsys.readouterr()


def _run_bridge(*, root: Path, event: str, payload: dict[str, object]) -> tuple[float, dict[str, object], str]:
    start = time.perf_counter()
    proc = subprocess.run(
        [sys.executable, "-m", "cortex_ops_cli.gemini_hooks", event, "--root", str(root)],
        input=json.dumps(payload),
        text=True,
        capture_output=True,
        check=False,
    )
    elapsed_ms = (time.perf_counter() - start) * 1000.0
    raw_stdout = proc.stdout.strip()
    assert proc.returncode == 0, f"{event} failed: stderr={proc.stderr!r}"
    assert raw_stdout.startswith("{") and raw_stdout.endswith("}")
    parsed = json.loads(raw_stdout)
    assert isinstance(parsed, dict)
    return elapsed_ms, parsed, raw_stdout


def test_kernel_dispatch_latency_envelope_inproc(tmp_path: Path, capsys: Any) -> None:
    root = tmp_path / "kernel-latency-inproc"
    assert cortex_cli.main(["init", "--root", str(root)]) == 0
    _ = capsys.readouterr()
    kernel = CortexKernel(
        root=root,
        config_path=root / "cortex.toml",
        db_path=root / ".cortex" / "cortex.db",
        adapter=GenericAdapter(),
    )

    kernel.dispatch("session_start", {"session_id": "perf-inproc-warmup", "objective": "warmup"})
    kernel.dispatch("pre_tool_use", {"session_id": "perf-inproc", "tool_name": "Read", "tool_input": {"path": "README.md"}})
    kernel.dispatch(
        "post_tool_use",
        {
            "session_id": "perf-inproc",
            "tool_name": "Read",
            "tool_input": {"path": "README.md"},
            "tool_response": {"ok": True},
            "status": "ok",
        },
    )
    kernel.dispatch(
        "stop",
        {
            "session_id": "perf-inproc-stop-warmup",
            "run_invariants": False,
            "stop_fields": {
                "challenge_coverage": {
                    "null_inputs": True,
                    "boundary_values": True,
                    "error_handling": True,
                    "graveyard_regression": True,
                }
            },
        },
    )

    pre_samples = _measure(
        150,
        lambda _: kernel.dispatch(
            "pre_tool_use",
            {"session_id": "perf-inproc", "tool_name": "Read", "tool_input": {"path": "README.md"}},
        ),
    )
    post_samples = _measure(
        150,
        lambda _: kernel.dispatch(
            "post_tool_use",
            {
                "session_id": "perf-inproc",
                "tool_name": "Read",
                "tool_input": {"path": "README.md"},
                "tool_response": {"ok": True},
                "status": "ok",
            },
        ),
    )
    stop_samples = _measure(
        150,
        lambda idx: kernel.dispatch(
            "stop",
            {
                "session_id": f"perf-inproc-stop-{idx}",
                "run_invariants": False,
                "stop_fields": {
                    "challenge_coverage": {
                        "null_inputs": True,
                        "boundary_values": True,
                        "error_handling": True,
                        "graveyard_regression": True,
                    }
                },
            },
        ),
    )

    _p50_pre, p95_pre, _p99_pre = _print_latency("kernel.pre_tool_use", pre_samples)
    _p50_post, p95_post, _p99_post = _print_latency("kernel.post_tool_use", post_samples)
    _p50_stop, p95_stop, _p99_stop = _print_latency("kernel.stop", stop_samples)

    assert p95_pre <= 15.0
    assert p95_post <= 15.0
    assert p95_stop <= 35.0


def test_gemini_bridge_latency_envelope_subprocess(tmp_path: Path, capsys: Any) -> None:
    root = tmp_path / "bridge-latency-subprocess"
    _init_gemini_runtime(root, capsys)

    _run_bridge(
        root=root,
        event="SessionStart",
        payload={
            "session_id": "perf-bridge-warmup",
            "hook_event_name": "SessionStart",
            "cwd": str(root),
            "timestamp": "2026-03-05T00:00:00Z",
        },
    )

    session_start_samples = _measure(
        30,
        lambda idx: _run_bridge(
            root=root,
            event="SessionStart",
            payload={
                "session_id": f"perf-ss-{idx}",
                "hook_event_name": "SessionStart",
                "cwd": str(root),
                "timestamp": "2026-03-05T00:00:00Z",
            },
        ),
    )
    before_tool_samples = _measure(
        30,
        lambda idx: _run_bridge(
            root=root,
            event="BeforeTool",
            payload={
                "session_id": "perf-tools",
                "hook_event_name": "BeforeTool",
                "tool_name": "Bash",
                "tool_input": {"command": HARNESS_TEST_COMMAND, "attempt": idx},
            },
        ),
    )
    after_tool_samples = _measure(
        30,
        lambda idx: _run_bridge(
            root=root,
            event="AfterTool",
            payload={
                "session_id": "perf-tools",
                "hook_event_name": "AfterTool",
                "tool_name": "Bash",
                "tool_input": {"command": HARNESS_TEST_COMMAND, "attempt": idx},
                "tool_response": {"ok": True, "stdout": ".", "stderr": "", "exit_code": 0},
                "status": "ok",
            },
        ),
    )
    before_agent_samples = _measure(
        30,
        lambda idx: _run_bridge(
            root=root,
            event="BeforeAgent",
            payload={
                "session_id": "perf-agent",
                "hook_event_name": "BeforeAgent",
                "prompt": f"turn {idx}",
            },
        ),
    )
    after_agent_samples = _measure(
        30,
        lambda idx: _run_bridge(
            root=root,
            event="AfterAgent",
            payload={
                "session_id": f"perf-stop-pass-{idx}",
                "hook_event_name": "AfterAgent",
                "prompt_response": (
                    "Done.\nSTOP_FIELDS_JSON: "
                    '{"challenge_coverage":{"null_inputs":{"covered":true,"evidence":["tests/invariants/example_invariant_test.py"]},'
                    '"boundary_values":{"covered":true,"evidence":["tests/invariants/example_invariant_test.py"]},'
                    '"error_handling":{"covered":true,"evidence":["tests/invariants/example_invariant_test.py"]},'
                    '"graveyard_regression":{"covered":true,"evidence":["tests/invariants/example_invariant_test.py"]}},'
                    '"requirement_audit":{"items":[{"id":"BUGFIX","status":"pass","evidence":["tests/invariants/example_invariant_test.py"]}],'
                    '"completeness_verdict":"pass"},'
                    '"truth_claims":{"tests_ran":["python -m pytest -q tests/test_normalize_port.py"]}}'
                ),
            },
        ),
    )

    _p50_ss, p95_ss, _p99_ss = _print_latency("bridge.SessionStart", session_start_samples)
    _p50_bt, p95_bt, _p99_bt = _print_latency("bridge.BeforeTool", before_tool_samples)
    _p50_at, p95_at, _p99_at = _print_latency("bridge.AfterTool", after_tool_samples)
    _p50_ba, p95_ba, _p99_ba = _print_latency("bridge.BeforeAgent", before_agent_samples)
    _p50_aa, p95_aa, _p99_aa = _print_latency("bridge.AfterAgent(shared_harness)", after_agent_samples)

    assert p95_ss <= 250.0
    assert p95_bt <= 220.0
    assert p95_at <= 220.0
    assert p95_ba <= 180.0
    # The shared harness stop payload exercises the current heavier completion
    # proof shape; hosted Linux runners currently land in the mid-300ms range.
    assert p95_aa <= 400.0


def test_bridge_stdout_contract_under_latency_sampling(tmp_path: Path, capsys: Any) -> None:
    root = tmp_path / "bridge-stdout-contract"
    _init_gemini_runtime(root, capsys)

    samples = [
        (
            "SessionStart",
            {
                "session_id": "stdout-session",
                "hook_event_name": "SessionStart",
                "cwd": str(root),
                "timestamp": "2026-03-05T00:00:00Z",
            },
        ),
        (
            "BeforeTool",
            {
                "session_id": "stdout-session",
                "hook_event_name": "BeforeTool",
                "tool_name": "Bash",
                "tool_input": {"command": HARNESS_TEST_COMMAND},
            },
        ),
        (
            "AfterTool",
            {
                "session_id": "stdout-session",
                "hook_event_name": "AfterTool",
                "tool_name": "Bash",
                "tool_input": {"command": HARNESS_TEST_COMMAND},
                "tool_response": {"ok": True, "stdout": ".", "stderr": "", "exit_code": 0},
                "status": "ok",
            },
        ),
        (
            "BeforeAgent",
            {
                "session_id": "stdout-session",
                "hook_event_name": "BeforeAgent",
                "prompt": "Continue.",
            },
        ),
        (
            "AfterAgent",
            {
                "session_id": "stdout-session-pass",
                "hook_event_name": "AfterAgent",
                "prompt_response": (
                    "Done.\nSTOP_FIELDS_JSON: "
                    '{"challenge_coverage":{"null_inputs":{"covered":true,"evidence":["tests/invariants/example_invariant_test.py"]},'
                    '"boundary_values":{"covered":true,"evidence":["tests/invariants/example_invariant_test.py"]},'
                    '"error_handling":{"covered":true,"evidence":["tests/invariants/example_invariant_test.py"]},'
                    '"graveyard_regression":{"covered":true,"evidence":["tests/invariants/example_invariant_test.py"]}},'
                    '"truth_claims":{"tests_ran":["python -m pytest -q tests/test_normalize_port.py"]}}'
                ),
            },
        ),
    ]
    for event, payload in samples:
        _elapsed, parsed, raw_stdout = _run_bridge(root=root, event=event, payload=payload)
        assert isinstance(parsed, dict)
        assert "Traceback" not in raw_stdout
        assert raw_stdout.count("{") >= 1
