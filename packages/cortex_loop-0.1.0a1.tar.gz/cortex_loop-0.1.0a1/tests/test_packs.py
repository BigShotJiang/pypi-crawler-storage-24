from __future__ import annotations

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

from cortex.packs import load_pack_overlay


def test_load_pack_overlay_merges_deduplicates_and_preserves_order(tmp_path: Path) -> None:
    (tmp_path / "packs").mkdir(parents=True, exist_ok=True)
    (tmp_path / "packs" / "python_service.toml").write_text(
        "\n".join(
            [
                'schema = "cortex_pack_v1"',
                'pack_id = "python_service"',
                'challenge_categories = ["api_contracts", "api_contracts", "input_validation"]',
                'invariant_paths = ["tests/packs/python_service/test_invariants.py"]',
                'blocked_tools = ["python_repl", "python_repl"]',
                'allowed_tools = ["read", "read"]',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    overlay = load_pack_overlay(root=tmp_path, pack_paths=["packs/python_service.toml"])

    assert overlay.warnings == []
    assert overlay.challenge_categories == ["api_contracts", "input_validation"]
    assert overlay.invariant_paths == ["tests/packs/python_service/test_invariants.py"]
    assert overlay.blocked_tools == ["python_repl"]
    assert overlay.allowed_tools == ["read"]


def test_load_pack_overlay_resolves_invariant_paths_relative_to_manifest_when_needed(tmp_path: Path) -> None:
    (tmp_path / "packs" / "local").mkdir(parents=True, exist_ok=True)
    (tmp_path / "packs" / "local" / "test_invariants.py").write_text("def test_ok():\n    assert True\n", encoding="utf-8")
    (tmp_path / "packs" / "local_pack.toml").write_text(
        "\n".join(
            [
                'schema = "cortex_pack_v1"',
                'pack_id = "local_pack"',
                'invariant_paths = ["local/test_invariants.py"]',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    overlay = load_pack_overlay(root=tmp_path, pack_paths=["packs/local_pack.toml"])

    assert overlay.warnings == []
    assert overlay.invariant_paths == ["packs/local/test_invariants.py"]


def test_load_pack_overlay_missing_or_invalid_pack_is_warning_only(tmp_path: Path) -> None:
    (tmp_path / "packs").mkdir(parents=True, exist_ok=True)
    (tmp_path / "packs" / "bad.toml").write_text(
        "\n".join(
            [
                'schema = "cortex_pack_v0"',
                'pack_id = "bad"',
                'challenge_categories = ["api_contracts"]',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    overlay = load_pack_overlay(
        root=tmp_path,
        pack_paths=["packs/missing.toml", "packs/bad.toml"],
    )

    assert overlay.challenge_categories == []
    assert overlay.invariant_paths == []
    assert overlay.blocked_tools == []
    assert overlay.allowed_tools == []
    assert len(overlay.warnings) == 2
    assert "Pack manifest not found" in overlay.warnings[0]
    assert "Unsupported pack schema" in overlay.warnings[1]


def test_temporal_protocol_invariant_uses_public_session_events_surface() -> None:
    source = (
        Path(__file__).resolve().parents[1]
        / "examples"
        / "packs"
        / "python_library"
        / "test_temporal_protocol.py"
    ).read_text(encoding="utf-8")
    assert "from cortex.store" not in source
    assert "sqlite3" not in source
    assert "CORTEX_PHASE_GATE_PATTERN" not in source
    assert "session-events" in source
    assert "phase_gate_pattern" in source


def test_python_library_pack_points_to_example_invariants() -> None:
    manifest = Path(__file__).resolve().parents[1] / "packs" / "python_library.toml"
    text = manifest.read_text(encoding="utf-8")
    expected = [
        "examples/packs/python_library/test_python_library_pack_invariants.py",
        "examples/packs/python_library/test_temporal_protocol.py",
    ]
    for rel in expected:
        assert rel in text
        source_path = Path(__file__).resolve().parents[1] / rel
        source = source_path.read_text(encoding="utf-8")
        compile(source, str(source_path), "exec")


def test_python_library_temporal_protocol_example_functions_stay_importable() -> None:
    source_path = (
        Path(__file__).resolve().parents[1]
        / "examples"
        / "packs"
        / "python_library"
        / "test_temporal_protocol.py"
    )
    spec = spec_from_file_location("example_temporal_protocol", source_path)
    assert spec is not None
    assert spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    module.test_temporal_protocol_passes_without_markers()
    module.test_temporal_protocol_passes_when_marker_precedes_modification()
