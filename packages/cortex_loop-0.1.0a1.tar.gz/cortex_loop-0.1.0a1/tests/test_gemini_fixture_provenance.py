from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path


_FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures" / "gemini"
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def _parse_utc(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def test_gemini_fixture_provenance_manifest_is_complete_and_consistent() -> None:
    manifest_path = _FIXTURES_DIR / "PROVENANCE.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest["schema_version"] == "gemini_fixture_provenance_v1"

    declared = manifest["fixtures"]
    fixture_files = sorted(
        path.name for path in _FIXTURES_DIR.glob("*.json") if path.name != "PROVENANCE.json"
    )
    assert sorted(declared.keys()) == fixture_files

    for name, meta in declared.items():
        assert meta["source"] in {"captured", "synthetic"}
        assert _SHA256_RE.fullmatch(str(meta["raw_capture_sha256"]))
        assert isinstance(meta["sanitized_fields"], list)
        _parse_utc(str(meta["captured_at_utc"]))
        captured_with = meta["captured_with"]
        assert isinstance(captured_with.get("cli"), str) and captured_with["cli"].strip()
        assert isinstance(captured_with.get("model"), str) and captured_with["model"].strip()

        if name.endswith("_real.json"):
            assert meta["source"] == "captured"

    assert declared["after_agent_structured.json"]["source"] == "captured"

