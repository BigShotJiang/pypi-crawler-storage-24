from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import cortex.core as core_module
import pytest

from cortex.adapters import GeminiAdapter
from cortex.core import CortexKernel
from cortex.core_helpers import session_witness_context
from cortex.executive import consolidate_event, get_identity_preamble
from cortex.invariants import InvariantReport
from cortex.repomap import RepoMapArtifact, RepoMapRunResult


def test_on_session_start_returns_structure_and_records_session(kernel: CortexKernel) -> None:
    result = kernel.on_session_start(
        {"session_id": "sess-core", "objective": "Add validation", "target_files": ["src/api.py"]}
    )
    assert result["ok"] is True
    assert result["hook"] == "SessionStart"
    assert result["session_id"] == "sess-core"
    assert "foundation" in result
    assert "graveyard_matches" in result
    assert "repomap" in result
    assert "executive_context" in result
    assert "identity_preamble" in result["executive_context"]
    assert "part_a" in result["executive_context"]
    assert "You are reading this for the first time." not in result["executive_context"]["part_a"]
    assert result["context_blocks"][0] == result["executive_context"]["identity_preamble"]
    assert result["context_blocks"][1] == result["executive_context"]["part_a"]
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status, genome_path FROM sessions WHERE session_id = ?",
            ("sess-core",),
        ).fetchone()
    assert row["status"] == "running"
    assert row["genome_path"].endswith("cortex.toml")


def test_response_config_paths_are_repo_relative(kernel: CortexKernel) -> None:
    result = kernel.on_session_start({"session_id": "sess-relative-paths", "objective": "Path normalization"})
    assert result["config"]["genome_path"] == "cortex.toml"
    assert result["config"]["db_path"] == ".cortex/cortex.db"


def test_response_paths_allow_external_config_without_crash(tmp_path: Path) -> None:
    root = tmp_path / "repo"
    external_cfg = tmp_path / "repo2" / "cortex.toml"
    external_cfg.parent.mkdir(parents=True, exist_ok=True)
    external_cfg.write_text(
        '[project]\nname = "external"\n\n[runtime]\nadapter = "cortex.adapters:GenericAdapter"\n',
        encoding="utf-8",
    )

    kernel = CortexKernel(
        root=root,
        config_path=external_cfg,
        db_path=root / ".cortex" / "cortex.db",
    )
    result = kernel.on_session_start({"session_id": "sess-external-paths", "objective": "Path normalization"})
    assert result["ok"] is True
    assert result["config"]["genome_path"] == str(external_cfg.resolve())
    assert result["config"]["db_path"] == ".cortex/cortex.db"


def test_minimal_response_mode_omits_config(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.minimal_response = True
    result = kernel.on_pre_tool_use({"session_id": "sess-minimal", "tool_name": "Read"})
    assert result["ok"] is True
    assert "config" not in result


def test_missing_session_id_generates_non_placeholder_ids(kernel: CortexKernel) -> None:
    first = kernel.on_pre_tool_use({"tool_name": "Read"})
    second = kernel.on_pre_tool_use({"tool_name": "Read"})
    assert first["session_id"] != "unknown"
    assert second["session_id"] != "unknown"
    assert first["session_id"] != second["session_id"]


def test_on_session_start_includes_graveyard_explainability_warning(kernel: CortexKernel) -> None:
    kernel.graveyard.record_failure(
        session_id="sess-prev",
        summary="Removed null guard in parser",
        reason="Null payload crashed parser",
        files=["src/parser.py"],
    )

    result = kernel.on_session_start(
        {
            "session_id": "sess-with-graveyard-match",
            "objective": "Fix parser null payload crash",
            "target_files": ["src/parser.py"],
        }
    )

    assert result["graveyard_matches"]
    assert any("Top graveyard match" in warning for warning in result["warnings"])


def test_on_session_start_persists_requirement_contract_ids(kernel: CortexKernel) -> None:
    result = kernel.on_session_start(
        {
            "session_id": "sess-contract",
            "objective": "Validate contract storage",
            "required_requirement_ids": ["R1", "R1", "R2"],
        }
    )
    assert result["required_requirement_ids"] == ["R1", "R2"]
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT metadata_json FROM sessions WHERE session_id = ?",
            ("sess-contract",),
        ).fetchone()
    metadata = json.loads(row["metadata_json"])
    assert metadata["required_requirement_ids"] == ["R1", "R2"]


def test_on_session_start_session_counter_is_idempotent_per_session_id(kernel: CortexKernel) -> None:
    first = kernel.on_session_start({"session_id": "sess-counter", "objective": "Count once"})
    second = kernel.on_session_start({"session_id": "sess-counter", "objective": "Count once again"})
    assert first["session_id"] == "sess-counter"
    assert second["session_id"] == "sess-counter"
    assert kernel.ctx.store.get_session_count() == 1


def test_on_session_start_fresh_project_injects_part_a_only(kernel: CortexKernel) -> None:
    result = kernel.on_session_start({"session_id": "sess-fresh", "objective": "Fresh context"})
    assert result["executive_context"]["identity_preamble"] == get_identity_preamble()
    assert result["executive_context"]["part_a"]
    assert result["executive_context"]["learned"] == ""
    assert result["context_blocks"][0] == result["executive_context"]["identity_preamble"]
    assert result["context_blocks"][1] == result["executive_context"]["part_a"]
    assert len(result["context_blocks"]) == 2


def test_on_session_start_injects_layer2_after_reinforcement(kernel: CortexKernel) -> None:
    kernel.ctx.genome.executive.part_a_mode = "always"
    kernel.on_session_start({"session_id": "sess-layer2-prime", "objective": "Prime"})
    consolidate_event(
        kernel.ctx.store,
        event_type="metacognitive",
        trigger_pattern="human contradicted source claim",
        error_pattern="defended without re-read",
        resolution="re-open source before responding",
        session_id="sess-layer2-prime",
    )
    consolidate_event(
        kernel.ctx.store,
        event_type="metacognitive",
        trigger_pattern="human contradicted source claim",
        error_pattern="defended without re-read",
        resolution="re-open source before responding",
        session_id="sess-layer2-prime",
    )
    consolidate_event(
        kernel.ctx.store,
        event_type="metacognitive",
        trigger_pattern="human contradicted source claim",
        error_pattern="defended without re-read",
        resolution="re-open source before responding",
        session_id="sess-layer2-prime",
    )
    result = kernel.on_session_start({"session_id": "sess-layer2", "objective": "With memory"})
    assert result["executive_context"]["learned"].startswith("## Learned patterns from this project")
    assert result["context_blocks"][2] == result["executive_context"]["learned"]


def test_on_session_start_context_block_order_keeps_graveyard_last(kernel: CortexKernel) -> None:
    kernel.ctx.genome.executive.part_a_mode = "always"
    kernel.graveyard.record_failure(
        session_id="sess-order-old",
        summary="Repeated parser crash",
        reason="Null inputs were unhandled",
        files=["src/parser.py"],
    )
    kernel.on_session_start({"session_id": "sess-order-prime", "objective": "Prime"})
    consolidate_event(
        kernel.ctx.store,
        event_type="metacognitive",
        trigger_pattern="human contradicted source claim",
        error_pattern="defended without re-read",
        resolution="re-open source before responding",
        session_id="sess-order-prime",
    )
    consolidate_event(
        kernel.ctx.store,
        event_type="metacognitive",
        trigger_pattern="human contradicted source claim",
        error_pattern="defended without re-read",
        resolution="re-open source before responding",
        session_id="sess-order-prime",
    )
    result = kernel.on_session_start(
        {
            "session_id": "sess-order",
            "objective": "Fix parser null payload crash",
            "target_files": ["src/parser.py"],
        }
    )
    assert result["context_blocks"][0] == result["executive_context"]["identity_preamble"]
    assert result["context_blocks"][1] == result["executive_context"]["part_a"]
    assert result["context_blocks"][2].startswith("## Learned patterns from this project")
    assert result["context_blocks"][-1].startswith("## Graveyard context")


def test_on_session_start_can_disable_identity_preamble(kernel: CortexKernel) -> None:
    kernel.ctx.genome.executive.inject_identity_preamble = False
    result = kernel.on_session_start({"session_id": "sess-no-preamble", "objective": "No preamble"})
    assert result["executive_context"]["identity_preamble"] == ""
    assert result["context_blocks"][0] == result["executive_context"]["part_a"]


def test_on_session_start_part_a_once_per_project_mode(kernel: CortexKernel) -> None:
    kernel.ctx.genome.executive.part_a_mode = "once_per_project"
    first = kernel.on_session_start({"session_id": "sess-part-a-first", "objective": "First"})
    second = kernel.on_session_start({"session_id": "sess-part-a-second", "objective": "Second"})

    assert first["executive_context"]["part_a"]
    assert first["executive_context"]["part_a"] in first["context_blocks"]
    assert second["executive_context"]["part_a"] == ""
    assert all(block != first["executive_context"]["part_a"] for block in second["context_blocks"])


def test_on_session_start_part_a_is_not_consumed_if_session_start_fails_before_delivery(
    kernel: CortexKernel, monkeypatch: pytest.MonkeyPatch
) -> None:
    kernel.ctx.genome.executive.part_a_mode = "once_per_project"
    original_analyze = kernel.foundation.analyze
    state = {"calls": 0}

    def _analyze_once_then_fail():
        state["calls"] += 1
        if state["calls"] == 1:
            raise RuntimeError("forced pre-delivery failure")
        return original_analyze()

    monkeypatch.setattr(kernel.foundation, "analyze", _analyze_once_then_fail)
    with pytest.raises(RuntimeError, match="forced pre-delivery failure"):
        kernel.on_session_start({"session_id": "sess-part-a-fail-first", "objective": "Trigger failure"})
    with kernel.ctx.store.connection() as conn:
        key = conn.execute(
            "SELECT value_text FROM cortex_meta WHERE key = ? LIMIT 1",
            ("executive.part_a_injected",),
        ).fetchone()
    assert key is None

    result = kernel.on_session_start({"session_id": "sess-part-a-success", "objective": "Successful retry"})
    assert result["executive_context"]["part_a"]


def test_on_session_start_graveyard_context_applies_caps(kernel: CortexKernel) -> None:
    kernel.ctx.genome.graveyard.context_max_matches = 1
    kernel.ctx.genome.graveyard.context_summary_chars = 40
    kernel.ctx.genome.graveyard.context_reason_chars = 50
    kernel.ctx.genome.graveyard.context_max_tokens = 80
    kernel.graveyard.record_failure(
        session_id="sess-gc-old-a",
        summary="Parser null crash with long repeated details " * 3,
        reason="Null payload handling failure repeated across retries " * 3,
        files=["src/parser.py", "src/handler.py"],
    )
    kernel.graveyard.record_failure(
        session_id="sess-gc-old-b",
        summary="Parser null crash secondary pattern should be dropped",
        reason="Secondary reason should not render because max_matches=1",
        files=["src/secondary.py"],
    )
    result = kernel.on_session_start(
        {
            "session_id": "sess-gc",
            "objective": "Fix parser null crash",
            "target_files": ["src/parser.py"],
        }
    )
    graveyard_block = next((b for b in result["context_blocks"] if b.startswith("## Graveyard context")), "")
    assert graveyard_block
    assert "2." not in graveyard_block
    assert "..." in graveyard_block
    assert max(1, len(graveyard_block) // 4) <= kernel.ctx.genome.graveyard.context_max_tokens


def test_on_session_start_layer2_updates_loaded_entries_only(kernel: CortexKernel) -> None:
    kernel.on_session_start({"session_id": "sess-layer2-load", "objective": "Prime"})
    loaded = kernel.ctx.store.record_executive_event(
        "metacognitive",
        "human contradicted source claim",
        "defended without re-read",
        "re-open source before responding",
        "sess-layer2-load",
    )
    hidden = kernel.ctx.store.record_executive_event(
        "technical",
        "legacy module touched",
        "assumed tests pass",
        "run module tests",
        "sess-layer2-load",
    )
    kernel.ctx.store.update_executive_entry(loaded["id"], strength=5, last_accessed_at_session=1)
    kernel.ctx.store.update_executive_entry(hidden["id"], strength=1, last_accessed_at_session=1)
    for _ in range(80):
        kernel.ctx.store.increment_session_counter()

    before = {item["id"]: item for item in kernel.ctx.store.get_executive_memory()}
    kernel.on_session_start({"session_id": "sess-layer2-load-2", "objective": "Load memory"})
    after = {item["id"]: item for item in kernel.ctx.store.get_executive_memory()}
    current = kernel.ctx.store.get_session_count()
    assert after[loaded["id"]]["last_accessed_at_session"] == current
    assert after[hidden["id"]]["last_accessed_at_session"] == before[hidden["id"]]["last_accessed_at_session"]


def test_on_stop_records_single_executive_memory_for_first_failure_then_dedupes(kernel: CortexKernel) -> None:
    session_id = "sess-stop-dedupe"
    kernel.on_session_start({"session_id": session_id, "objective": "Track failure"})
    kernel.on_stop({"session_id": session_id, "stop_fields": {}, "run_invariants": False})
    first = kernel.ctx.store.get_executive_memory()
    assert len(first) == 1
    assert first[0]["strength"] == 1
    assert first[0]["type"] == "technical"

    kernel.on_stop({"session_id": session_id, "stop_fields": {}, "run_invariants": False})
    second = kernel.ctx.store.get_executive_memory()
    assert len(second) == 1
    assert second[0]["id"] == first[0]["id"]
    assert second[0]["strength"] == 1


def test_on_stop_records_distinct_executive_memory_for_different_failure_signatures(kernel: CortexKernel) -> None:
    session_id = "sess-stop-signatures"
    kernel.on_session_start({"session_id": session_id, "objective": "Track signature changes"})
    kernel.ctx.genome.hooks.require_structured_stop_payload = True
    kernel.ctx.genome.hooks.allow_message_stop_fallback = False
    kernel.on_stop({"session_id": session_id, "run_invariants": False})
    kernel.on_stop({"session_id": session_id, "stop_fields": {}, "run_invariants": False})
    entries = kernel.ctx.store.get_executive_memory()
    assert len(entries) == 2
    assert {entry["type"] for entry in entries} == {"metacognitive", "technical"}


def test_on_stop_clean_pass_does_not_record_executive_memory(kernel: CortexKernel) -> None:
    session_id = "sess-stop-clean"
    kernel.on_session_start({"session_id": session_id, "objective": "No failure"})
    kernel.on_stop(
        {
            "session_id": session_id,
            "run_invariants": False,
            "stop_fields": {
                "challenge_coverage": {
                    "null_inputs": True,
                    "boundary_values": True,
                    "error_handling": True,
                    "graveyard_regression": True,
                }
            },
        }
    )
    assert kernel.ctx.store.get_executive_memory() == []


def test_on_session_start_layer2_context_size_under_budget_with_20_entries(kernel: CortexKernel) -> None:
    kernel.on_session_start({"session_id": "sess-budget", "objective": "Prime"})
    for idx in range(20):
        entry = kernel.ctx.store.record_executive_event(
            "metacognitive",
            f"trigger pattern {idx} source contradiction",
            f"error pattern {idx} defended from memory",
            f"resolution pattern {idx} re-open source and verify",
            "sess-budget",
        )
        kernel.ctx.store.update_executive_entry(entry["id"], strength=5, last_accessed_at_session=1)
    result = kernel.on_session_start({"session_id": "sess-budget-2", "objective": "Budget check"})
    merged = "\n\n".join(result["context_blocks"])
    approx_tokens = max(1, len(merged) // 4)
    assert approx_tokens < 3000


def test_on_session_start_includes_repomap_metadata_and_records_event(
    kernel: CortexKernel, tmp_project: Path
) -> None:
    (tmp_project / "src" / "api.py").write_text("class API:\n    pass\n", encoding="utf-8")

    result = kernel.on_session_start(
        {"session_id": "sess-repomap", "objective": "Add validation", "target_files": ["src/api.py"]}
    )

    assert result["ok"] is True
    assert result["hook"] == "SessionStart"
    assert result["repomap"]["ok"] is True
    assert "text" not in result["repomap"]
    assert result["repomap"]["top_ranked_files"]
    assert "src/api.py" in result["repomap"]["top_ranked_files"]
    assert result["repomap"]["artifact_path"]
    assert Path(result["repomap"]["artifact_path"]).exists()

    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status, payload_json FROM events WHERE session_id = ? AND hook = ? ORDER BY id DESC LIMIT 1",
            ("sess-repomap", "RepoMap"),
        ).fetchone()
    assert row["status"] == "ok"
    payload = json.loads(row["payload_json"])
    assert payload["trigger"] == "SessionStart"
    assert payload["ok"] is True
    assert "text" not in payload


def test_on_session_start_repomap_failure_is_non_blocking(
    kernel: CortexKernel, monkeypatch
) -> None:
    import cortex.repomap as repomap_module

    def _fake_run_repomap(**_: object) -> RepoMapRunResult:
        artifact = RepoMapArtifact(
            ok=False,
            generated_at="2026-02-26T00:00:00Z",
            provenance={
                "method": "none",
                "source_root": str(kernel.ctx.root),
                "scope": ["src"],
                "focus_files": [],
                "duration_ms": 1,
                "timeout_ms": 1800,
            },
            stats={"files_parsed": 0, "symbols_found": 0, "graph_edges": 0, "byte_count": 0},
            ranking=[],
            text="",
            error={
                "code": "deps_missing",
                "message": "Missing optional repo-map deps",
                "retryable": True,
                "failed_stage": "dependency_check",
            },
        )
        return RepoMapRunResult(artifact=artifact)

    monkeypatch.setattr(repomap_module, "run_repomap", _fake_run_repomap)

    result = kernel.on_session_start({"session_id": "sess-repomap-fail", "objective": "Start"})

    assert result["ok"] is True
    assert "foundation" in result
    assert "graveyard_matches" in result
    assert result["repomap"]["ok"] is False
    assert result["repomap"]["error"]["code"] == "deps_missing"
    assert "text" not in result["repomap"]
    assert any("Repo-map warning:" in warning for warning in result["warnings"])

    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status, payload_json FROM events WHERE session_id = ? AND hook = ? ORDER BY id DESC LIMIT 1",
            ("sess-repomap-fail", "RepoMap"),
        ).fetchone()
    assert row["status"] == "error"
    payload = json.loads(row["payload_json"])
    assert payload["trigger"] == "SessionStart"
    assert payload["error"]["code"] == "deps_missing"


def test_on_session_start_repomap_timeout_is_non_blocking(
    kernel: CortexKernel, tmp_project: Path
) -> None:
    (tmp_project / "src" / "api.py").write_text("class API:\n    pass\n", encoding="utf-8")
    kernel.ctx.genome.repomap.session_start_timeout_ms = 0

    result = kernel.on_session_start({"session_id": "sess-repomap-timeout", "objective": "Start"})

    assert result["ok"] is True
    assert "foundation" in result
    assert "graveyard_matches" in result
    assert result["repomap"]["ok"] is False
    assert result["repomap"]["error"]["code"] == "timeout"
    assert any("Repo-map warning:" in warning for warning in result["warnings"])


def test_on_stop_records_graveyard_and_challenge_results(kernel: CortexKernel) -> None:
    kernel.on_session_start({"session_id": "sess-stop", "objective": "Handle bad input"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": False,
            },
            "failed_approach": {
                "summary": "Accepted missing body",
                "reason": "Parser crashed on empty payload",
                "files": ["src/api.py"],
            },
        }
    )
    assert stop["hook"] == "Stop"
    assert stop["recommend_revert"] is False
    assert stop["challenge_report"]["ok"] is False
    assert stop["challenge_report"]["missing_categories"] == ["graveyard_regression"]
    with kernel.ctx.store.connection() as conn:
        graveyard_row = conn.execute("SELECT * FROM graveyard WHERE session_id = ?", ("sess-stop",)).fetchone()
        session_row = conn.execute("SELECT * FROM sessions WHERE session_id = ?", ("sess-stop",)).fetchone()
        challenge_rows = conn.execute(
            "SELECT COUNT(*) AS n FROM challenge_results WHERE session_id = ?",
            ("sess-stop",),
        ).fetchone()
    assert graveyard_row["summary"] == "Accepted missing body"
    assert json.loads(graveyard_row["files_json"]) == ["src/api.py"]
    assert session_row["status"] == "failed_challenges"
    assert session_row["ended_at"]
    assert challenge_rows["n"] == 4


def test_gemini_after_agent_structured_fixture_passes_stop_contract_normalization(tmp_project: Path) -> None:
    payload = json.loads(
        (Path(__file__).resolve().parent / "fixtures" / "gemini" / "after_agent_structured.json").read_text(
            encoding="utf-8"
        )
    )
    kernel = CortexKernel(
        root=tmp_project,
        config_path=tmp_project / "cortex.toml",
        db_path=tmp_project / ".cortex" / "cortex.db",
        adapter=GeminiAdapter(),
    )
    result = kernel.dispatch("AfterAgent", payload)
    assert result["hook"] == "Stop"
    assert result["session_id"] == payload["session_id"]
    assert result["stop_source"] == "payload.stop_fields"
    assert result["structured_stop_violation"] is False
    assert result["challenge_coverage_missing"] is False
    assert result["challenge_report"]["ok"] is True


def test_on_stop_exposes_enforcement_and_stop_observability_metadata(kernel: CortexKernel) -> None:
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-observability",
            "run_invariants": False,
            "stop_fields": {
                "challenge_coverage": {
                    "null_inputs": True,
                    "boundary_values": True,
                    "error_handling": True,
                    "graveyard_regression": True,
                }
            },
        }
    )
    assert stop["enforcement_pass"] is True
    assert stop["stop_fields_source"] == "payload.stop_fields"
    assert stop["stop_fields_fallback_used"] is False
    assert stop["stop_key_normalization_count"] == 0
    assert stop["feedback_mode"] == "normal"
    assert stop["loop_detected"] is False
    assert stop["stop_attempt_signature"]["challenge_shape"] == [
        "boundary_values:covered=True",
        "error_handling:covered=True",
        "graveyard_regression:covered=True",
        "null_inputs:covered=True",
    ]
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-observability",),
        ).fetchone()
    metadata = json.loads(row["metadata_json"])
    assert metadata["enforcement_pass"] is True
    assert metadata["stop_fields_source"] == "payload.stop_fields"
    assert metadata["stop_fields_fallback_used"] is False
    assert metadata["stop_key_normalization_count"] == 0
    assert metadata["feedback_mode"] == "normal"


def test_gemini_after_agent_real_fixture_normalizes_to_structured_stop_fields(
    tmp_project: Path,
) -> None:
    payload = json.loads(
        (Path(__file__).resolve().parent / "fixtures" / "gemini" / "after_agent_real.json").read_text(
            encoding="utf-8"
        )
    )
    kernel = CortexKernel(
        root=tmp_project,
        config_path=tmp_project / "cortex.toml",
        db_path=tmp_project / ".cortex" / "cortex.db",
        adapter=GeminiAdapter(),
    )
    result = kernel.dispatch("AfterAgent", payload)
    assert result["hook"] == "Stop"
    assert result["session_id"] == payload["session_id"]
    assert result["stop_source"] == "payload.stop_fields"
    assert result["structured_stop_violation"] is False
    assert result["challenge_coverage_missing"] is True


def test_pre_tool_use_backfills_session_row_when_session_start_missing(kernel: CortexKernel) -> None:
    result = kernel.on_pre_tool_use(
        {
            "session_id": "sess-backfill",
            "tool_name": "Read",
            "target_files": ["src/api.py"],
        }
    )
    assert result["ok"] is True
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status, genome_path, metadata_json FROM sessions WHERE session_id = ?",
            ("sess-backfill",),
        ).fetchone()
        events = conn.execute(
            "SELECT COUNT(*) AS n FROM events WHERE session_id = ? AND hook = ?",
            ("sess-backfill", "PreToolUse"),
        ).fetchone()
    assert row["status"] == "running"
    assert row["genome_path"].endswith("cortex.toml")
    assert json.loads(row["metadata_json"])["auto_started"] is True
    assert events["n"] == 1


def test_pre_tool_use_reuses_session_start_foundation_snapshot(
    kernel: CortexKernel, monkeypatch
) -> None:
    call_count = {"n": 0}
    original_analyze = kernel.foundation.analyze

    def _counting_analyze():
        call_count["n"] += 1
        return original_analyze()

    monkeypatch.setattr(kernel.foundation, "analyze", _counting_analyze)

    kernel.on_session_start({"session_id": "sess-foundation-cache", "objective": "Start"})
    assert call_count["n"] == 1

    result = kernel.on_pre_tool_use(
        {
            "session_id": "sess-foundation-cache",
            "tool_name": "Edit",
            "target_files": ["src/api.py"],
        }
    )
    assert call_count["n"] == 1
    assert any("Git repository not detected" in warning for warning in result["warnings"])


def test_pre_tool_use_without_session_start_uses_live_foundation_analysis(
    kernel: CortexKernel, monkeypatch
) -> None:
    call_count = {"n": 0}
    original_analyze = kernel.foundation.analyze

    def _counting_analyze():
        call_count["n"] += 1
        return original_analyze()

    monkeypatch.setattr(kernel.foundation, "analyze", _counting_analyze)

    kernel.on_pre_tool_use(
        {
            "session_id": "sess-foundation-live",
            "tool_name": "Edit",
            "target_files": ["src/api.py"],
        }
    )
    assert call_count["n"] == 1


def test_on_pre_tool_use_records_canonical_tool_name(kernel: CortexKernel) -> None:
    kernel.on_pre_tool_use(
        {
            "session_id": "sess-tool-alias",
            "tool_name": "Edit",
            "target_files": ["src/api.py"],
        }
    )
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT tool_name, payload_json FROM events WHERE session_id = ? AND hook = ? ORDER BY id DESC LIMIT 1",
            ("sess-tool-alias", "PreToolUse"),
        ).fetchone()
    assert row["tool_name"] == "Edit"
    payload = json.loads(row["payload_json"])
    assert payload["tool_name"] == "Edit"


def test_post_tool_use_includes_graveyard_explainability_warning(kernel: CortexKernel) -> None:
    kernel.graveyard.record_failure(
        session_id="sess-prev",
        summary="Write path update broke parser",
        reason="Unhandled empty payload branch",
        files=["src/parser.py"],
    )
    kernel.on_session_start({"session_id": "sess-post-graveyard", "objective": "Patch parser"})
    result = kernel.on_post_tool_use(
        {
            "session_id": "sess-post-graveyard",
            "tool_name": "Write",
            "status": "error",
            "error": "Unhandled empty payload branch in parser",
            "target_files": ["src/parser.py"],
        }
    )

    assert result["hook"] == "PostToolUse"
    assert any("Top graveyard match" in warning for warning in result["warnings"])


def test_on_stop_without_challenge_coverage_skips_recording_not_false_zeros(kernel: CortexKernel) -> None:
    kernel.on_session_start({"session_id": "sess-stop-missing-coverage", "objective": "Do work"})
    stop = kernel.on_stop({"session_id": "sess-stop-missing-coverage", "run_invariants": False})

    assert stop["hook"] == "Stop"
    assert stop["challenge_report"] is None
    assert stop["challenge_diagnostics"][0]["gap_characterization"] == "comprehension_gap"
    assert stop["challenge_coverage_missing"] is True
    assert any("No challenge_coverage provided" in warning for warning in stop["warnings"])

    with kernel.ctx.store.connection() as conn:
        challenge_rows = conn.execute(
            "SELECT COUNT(*) AS n FROM challenge_results WHERE session_id = ?",
            ("sess-stop-missing-coverage",),
        ).fetchone()
        session_row = conn.execute(
            "SELECT status, metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-missing-coverage",),
        ).fetchone()

    assert challenge_rows["n"] == 0
    assert session_row["status"] == "completed"
    assert json.loads(session_row["metadata_json"])["challenge_coverage_missing"] is True


def test_on_stop_missing_challenge_warning_mentions_trailer_when_fallback_enabled(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.allow_message_stop_fallback = True
    kernel.on_session_start({"session_id": "sess-stop-missing-coverage-fallback", "objective": "Do work"})
    stop = kernel.on_stop({"session_id": "sess-stop-missing-coverage-fallback", "run_invariants": False})

    assert stop["challenge_coverage_missing"] is True
    assert any("STOP_FIELDS_JSON" in warning for warning in stop["warnings"])


def test_on_stop_missing_challenge_warning_omits_trailer_when_fallback_disabled(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.allow_message_stop_fallback = False
    kernel.on_session_start({"session_id": "sess-stop-missing-coverage-structured", "objective": "Do work"})
    stop = kernel.on_stop({"session_id": "sess-stop-missing-coverage-structured", "run_invariants": False})

    assert stop["challenge_coverage_missing"] is True
    assert all("STOP_FIELDS_JSON" not in warning for warning in stop["warnings"])
    assert any("payload.stop_fields" in warning for warning in stop["warnings"])


def test_on_stop_warns_when_builtin_challenge_categories_are_not_active(kernel: CortexKernel) -> None:
    kernel.ctx.genome.challenges.active_categories = ["null_inputs", "error_handling"]
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-builtin-audit",
            "run_invariants": False,
            "challenge_coverage": {"null_inputs": True, "error_handling": True},
        }
    )

    assert stop["hook"] == "Stop"
    assert stop["challenge_report"]["ok"] is True
    assert any("Built-in challenge categories missing" in warning for warning in stop["warnings"])


def test_on_stop_parses_stop_fields_json_from_last_assistant_message(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.allow_message_stop_fallback = True
    kernel.on_session_start({"session_id": "sess-stop-embedded", "objective": "Validate payloads"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-embedded",
            "run_invariants": False,
            "last_assistant_message": (
                "Done.\n"
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true,"boundary_values":true,'
                '"error_handling":true,"graveyard_regression":true},"failed_approach":{"summary":"Tried '
                'single-pass parser","reason":"Missed malformed branch","files":["src/parser.py"]}}'
            ),
        }
    )

    assert stop["hook"] == "Stop"
    assert stop["challenge_coverage_missing"] is False
    assert stop["challenge_report"]["ok"] is True
    assert any("STOP_FIELDS_JSON" in warning for warning in stop["warnings"])

    with kernel.ctx.store.connection() as conn:
        graveyard_row = conn.execute(
            "SELECT summary, reason, files_json FROM graveyard WHERE session_id = ?",
            ("sess-stop-embedded",),
        ).fetchone()
        challenge_rows = conn.execute(
            "SELECT COUNT(*) AS n FROM challenge_results WHERE session_id = ?",
            ("sess-stop-embedded",),
        ).fetchone()

    assert graveyard_row["summary"] == "Tried single-pass parser"
    assert json.loads(graveyard_row["files_json"]) == ["src/parser.py"]
    assert challenge_rows["n"] == 4


def test_on_stop_persists_compacted_message_payload(kernel: CortexKernel) -> None:
    kernel.on_session_start({"session_id": "sess-stop-compact", "objective": "Compact event payload"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-compact",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "last_assistant_message": "x" * 5000,
        }
    )
    assert stop["ok"] is True
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT payload_json FROM events WHERE session_id = ? AND hook = ? ORDER BY id DESC LIMIT 1",
            ("sess-stop-compact", "Stop"),
        ).fetchone()
    payload = json.loads(row["payload_json"])
    assert payload["last_assistant_message"] == ("x" * 2048)
    assert payload["_payload_compaction"]["last_assistant_message"]["original_len"] == 5000


def test_witness_context_commands_survive_payload_compaction(kernel: CortexKernel) -> None:
    kernel.on_pre_tool_use(
        {
            "session_id": "sess-witness-compact",
            "tool_name": "Bash",
            "command": "pytest -q",
            "message": "m" * 5000,
        }
    )
    witness = session_witness_context(kernel.ctx.store, "sess-witness-compact")
    assert "pytest -q" in witness["commands"]


def test_on_stop_trailer_only_blocked_when_structured_stop_required_in_strict_mode(
    kernel: CortexKernel,
) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_missing_challenge_coverage = True
    kernel.ctx.genome.hooks.require_structured_stop_payload = True
    kernel.ctx.genome.hooks.allow_message_stop_fallback = True
    kernel.on_session_start({"session_id": "sess-stop-structured-required", "objective": "Validate contract"})

    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-structured-required",
            "run_invariants": False,
            "last_assistant_message": (
                "Done.\n"
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true,"boundary_values":true,'
                '"error_handling":true,"graveyard_regression":true}}'
            ),
        }
    )

    assert stop["structured_stop_violation"] is True
    assert stop["stop_source"] == "message_fallback"
    assert stop["recommend_revert"] is True
    assert stop["proceed"] is False
    assert any("Structured stop payload is required" in w for w in stop["warnings"])

    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status, metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-structured-required",),
        ).fetchone()
    assert row["status"] == "failed_stop_contract"
    metadata = json.loads(row["metadata_json"])
    assert metadata["structured_stop_violation"] is True


def test_on_stop_ignores_message_fallback_when_disabled(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.allow_message_stop_fallback = False
    kernel.on_session_start({"session_id": "sess-stop-fallback-off", "objective": "Validate fallback policy"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-fallback-off",
            "run_invariants": False,
            "last_assistant_message": (
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true,"boundary_values":true,'
                '"error_handling":true,"graveyard_regression":true}}'
            ),
        }
    )

    assert stop["challenge_report"] is None
    assert stop["stop_source"] == "native"
    assert stop["challenge_coverage_missing"] is True
    assert stop["structured_stop_violation"] is False
    assert not any("Using challenge_coverage parsed from last assistant message" in w for w in stop["warnings"])


def test_on_stop_requires_structured_payload_when_configured(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.require_structured_stop_payload = True
    kernel.on_session_start({"session_id": "sess-stop-structured-missing", "objective": "Contract check"})
    stop = kernel.on_stop({"session_id": "sess-stop-structured-missing", "run_invariants": False})

    assert stop["structured_stop_violation"] is True
    assert stop["stop_source"] == "native"
    assert stop["contract_diagnostic"]["gap_characterization"] == "comprehension_gap"
    assert stop["recommend_revert"] is True
    assert any("Structured stop payload is required" in w for w in stop["warnings"])


def test_on_stop_missing_coverage_without_requirements_or_truth_claims_skips_witness_load(
    kernel: CortexKernel, monkeypatch
) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_missing_challenge_coverage = True
    monkeypatch.setattr(
        core_module,
        "session_git_snapshot",
        lambda _root: {"available": True, "changed_files": [], "error": None},
    )
    call_count = {"n": 0}

    def _witness(_store, _session_id: str) -> dict[str, list[str]]:
        call_count["n"] += 1
        return {"commands": ["pytest -q"], "tools": ["Bash"]}

    monkeypatch.setattr(core_module, "session_witness_context", _witness)
    stop = kernel.on_stop({"session_id": "sess-stop-missing-coverage-no-witness", "run_invariants": False})

    assert stop["challenge_report"] is None
    assert stop["challenge_coverage_missing"] is True
    assert call_count["n"] == 0


def test_on_stop_does_not_mark_contract_only_retries_as_loop_without_signal(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.require_structured_stop_payload = True

    kernel.on_session_start({"session_id": "sess-stop-loop", "objective": "Contract check"})
    first = kernel.on_stop({"session_id": "sess-stop-loop", "run_invariants": False})
    second = kernel.on_stop({"session_id": "sess-stop-loop", "run_invariants": False})

    assert first["loop_detected"] is False
    assert second["stop_attempt_signature"] == {
        "challenge_shape": [],
        "witnessed_commands": [],
        "file_signal": [],
    }
    assert second["loop_detected"] is False
    assert second["loop_similarity"] is None
    assert second["feedback_mode"] == "normal"
    assert not any("reconsider the approach" in warning for warning in second["warnings"])


def test_on_stop_detects_looped_stop_attempts_when_structural_signal_repeats(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_missing_challenge_coverage = True

    kernel.on_session_start({"session_id": "sess-stop-loop-shape", "objective": "Challenge check"})
    stop_payload = {
        "session_id": "sess-stop-loop-shape",
        "run_invariants": False,
        "challenge_coverage": {
            "null_inputs": False,
            "boundary_values": False,
            "error_handling": False,
            "graveyard_regression": False,
        },
    }
    first = kernel.on_stop(stop_payload)
    second = kernel.on_stop(stop_payload)

    assert first["loop_detected"] is False
    assert second["stop_attempt_signature"]["challenge_shape"] == [
        "boundary_values:covered=False",
        "error_handling:covered=False",
        "graveyard_regression:covered=False",
        "null_inputs:covered=False",
    ]
    assert second["loop_detected"] is True
    assert second["feedback_mode"] == "reconsider_approach"
    assert second["loop_similarity"] == 1.0
    assert any("reconsider the approach" in warning for warning in second["warnings"])


def test_on_stop_rejects_message_fallback_in_strict_mode_even_without_structured_requirement(
    kernel: CortexKernel,
) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.require_structured_stop_payload = False
    kernel.ctx.genome.hooks.allow_message_stop_fallback = True
    kernel.on_session_start({"session_id": "sess-stop-fallback-strict", "objective": "Contract check"})

    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-fallback-strict",
            "run_invariants": False,
            "last_assistant_message": (
                "Done.\n"
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true,"boundary_values":true,'
                '"error_handling":true,"graveyard_regression":true}}'
            ),
        }
    )

    assert stop["stop_source"] == "message_fallback"
    assert stop["structured_stop_violation"] is True
    assert stop["recommend_revert"] is True
    assert stop["proceed"] is False
    assert any("Strict mode rejects Stop message-fallback payloads" in w for w in stop["warnings"])

    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status, metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-fallback-strict",),
        ).fetchone()
    assert row["status"] == "failed_stop_contract"
    metadata = json.loads(row["metadata_json"])
    assert metadata["stop_source"] == "message_fallback"
    assert metadata["strict_message_fallback_violation"] is True


def test_on_stop_records_graveyard_from_top_level_failure_fields(kernel: CortexKernel) -> None:
    kernel.on_session_start({"session_id": "sess-stop-top-level-failure", "objective": "Implement parser"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-top-level-failure",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "what_was_tried": "Used single-pass regex parser",
            "why_failed": "Edge cases with nested blocks were skipped",
            "failed_files": ["src/parser.py", "src/tokenizer.py"],
        }
    )

    assert stop["hook"] == "Stop"
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT summary, reason, files_json FROM graveyard WHERE session_id = ?",
            ("sess-stop-top-level-failure",),
        ).fetchone()
    assert row is not None
    assert row["summary"] == "Used single-pass regex parser"
    assert row["reason"] == "Edge cases with nested blocks were skipped"
    assert json.loads(row["files_json"]) == ["src/parser.py", "src/tokenizer.py"]


def test_on_stop_requirement_audit_gap_blocks_in_strict_mode(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    kernel.ctx.genome.hooks.require_evidence_for_passed_requirement = True

    kernel.on_session_start({"session_id": "sess-stop-req-gap", "objective": "Validate contract"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-gap",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "requirement_audit": {
                "items": [{"id": "R1", "status": "pass", "evidence": []}],
                "completeness_verdict": "pass",
            },
        }
    )

    assert stop["hook"] == "Stop"
    assert stop["requirement_audit_gap"] is True
    assert stop["truth_claims_gap"] is False
    assert stop["requirements_gate_gap"] is True
    assert stop["requirement_audit_missing"] is False
    assert stop["requirement_audit_report"]["ok"] is False
    assert any("no evidence" in err for err in stop["requirement_audit_report"]["errors"])
    assert stop["recommend_revert"] is True
    assert stop["proceed"] is False

    with kernel.ctx.store.connection() as conn:
        session_row = conn.execute(
            "SELECT status, metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-req-gap",),
        ).fetchone()
    assert session_row["status"] == "failed_requirements"
    metadata = json.loads(session_row["metadata_json"])
    assert metadata["requirement_audit_ok"] is False
    assert metadata["requirement_audit_gap"] is True
    assert metadata["truth_claims_gap"] is False
    assert metadata["requirements_gate_gap"] is True


def test_on_stop_missing_requirement_audit_blocks_when_required(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.require_requirement_audit = True
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True

    kernel.on_session_start({"session_id": "sess-stop-req-missing", "objective": "Validate contract"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-missing",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
        }
    )

    assert stop["requirement_audit_report"] is None
    assert stop["requirement_audit_missing"] is True
    assert stop["requirement_audit_gap"] is False
    assert stop["truth_claims_gap"] is False
    assert stop["requirements_gate_gap"] is False
    assert stop["recommend_revert"] is True
    assert stop["proceed"] is False
    assert any("No requirement_audit provided" in warning for warning in stop["warnings"])

    with kernel.ctx.store.connection() as conn:
        session_row = conn.execute(
            "SELECT status, metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-req-missing",),
        ).fetchone()
    assert session_row["status"] == "failed_requirements"
    metadata = json.loads(session_row["metadata_json"])
    assert metadata["requirement_audit_ok"] is None
    assert metadata["requirement_audit_missing"] is True
    assert metadata["truth_claims_gap"] is False
    assert metadata["requirements_gate_gap"] is False


def test_on_stop_parses_requirement_audit_from_stop_fields_json(kernel: CortexKernel) -> None:
    (kernel.ctx.root / "src" / "app.py").write_text("print('ok')\n", encoding="utf-8")
    kernel.ctx.genome.hooks.allow_message_stop_fallback = True
    kernel.on_session_start({"session_id": "sess-stop-req-embedded", "objective": "Validate payloads"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-embedded",
            "run_invariants": False,
            "last_assistant_message": (
                "Done.\n"
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true,"boundary_values":true,'
                '"error_handling":true,"graveyard_regression":true},"required_requirement_ids":["R1"],'
                '"requirement_audit":{"items":[{"id":"R1",'
                '"status":"pass","evidence":["src/app.py:10"]}],"completeness_verdict":"pass"}}'
            ),
        }
    )

    assert stop["hook"] == "Stop"
    assert stop["challenge_report"]["ok"] is True
    assert stop["requirement_audit_missing"] is False
    assert stop["requirement_audit_gap"] is False
    assert stop["truth_claims_gap"] is False
    assert stop["requirements_gate_gap"] is False
    assert stop["required_requirement_ids"] == ["R1"]
    assert stop["requirement_audit_report"]["ok"] is True
    assert set(stop["requirement_audit_report"].keys()) == {
        "ok",
        "errors",
        "missing_required_ids",
        "item_count",
        "pass_count",
        "fail_count",
        "diagnostics",
    }
    assert any("requirement_audit parsed from last assistant message" in w for w in stop["warnings"])


def test_on_stop_requirement_audit_enforces_required_ids(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    (kernel.ctx.root / "src" / "api.py").write_text("print('ok')\n", encoding="utf-8")

    kernel.on_session_start(
        {
            "session_id": "sess-stop-req-ids",
            "objective": "Validate contract",
            "required_requirement_ids": ["R1", "R2"],
        }
    )
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-ids",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "requirement_audit": {
                "items": [{"id": "R1", "status": "pass", "evidence": ["src/api.py:1"]}],
                "completeness_verdict": "pass",
            },
        }
    )

    assert stop["requirement_audit_gap"] is True
    assert stop["recommend_revert"] is True
    assert stop["required_requirement_ids"] == ["R1", "R2"]
    assert stop["requirement_audit_report"]["missing_required_ids"] == ["R2"]
    assert any("missing required ids" in err for err in stop["requirement_audit_report"]["errors"])


def test_on_stop_ignores_conflicting_stop_requirement_ids_when_session_contract_exists(
    kernel: CortexKernel,
) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    (kernel.ctx.root / "src" / "api.py").write_text("print('ok')\n", encoding="utf-8")

    kernel.on_session_start(
        {
            "session_id": "sess-stop-req-conflict",
            "objective": "Validate contract",
            "required_requirement_ids": ["R1", "R2"],
        }
    )
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-conflict",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "required_requirement_ids": ["R1"],
            "requirement_audit": {
                "items": [{"id": "R1", "status": "pass", "evidence": ["src/api.py:1"]}],
                "completeness_verdict": "pass",
            },
        }
    )

    assert stop["required_requirement_ids"] == ["R1", "R2"]
    assert stop["requirement_audit_gap"] is True
    assert stop["recommend_revert"] is True
    assert any(
        "Ignoring required_requirement_ids from Stop payload" in warning
        for warning in stop["warnings"]
    )


def test_on_stop_requirement_gap_warns_but_does_not_block_in_advisory_mode(
    kernel: CortexKernel,
) -> None:
    kernel.ctx.genome.hooks.mode = "advisory"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    (kernel.ctx.root / "src" / "api.py").write_text("print('ok')\n", encoding="utf-8")

    kernel.on_session_start(
        {
            "session_id": "sess-stop-req-advisory",
            "objective": "Validate contract",
            "required_requirement_ids": ["R1", "R2"],
        }
    )
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-advisory",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "requirement_audit": {
                "items": [{"id": "R1", "status": "pass", "evidence": ["src/api.py:1"]}],
                "completeness_verdict": "pass",
            },
        }
    )

    assert stop["requirement_audit_gap"] is True
    assert stop["recommend_revert"] is False
    assert stop["proceed"] is True
    assert any("Requirement audit reported gaps:" in warning for warning in stop["warnings"])
    with kernel.ctx.store.connection() as conn:
        session_row = conn.execute(
            "SELECT status FROM sessions WHERE session_id = ?",
            ("sess-stop-req-advisory",),
        ).fetchone()
    assert session_row["status"] == "completed"


def test_on_stop_requirement_audit_validates_evidence_paths(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True

    kernel.on_session_start({"session_id": "sess-stop-req-evidence", "objective": "Validate evidence"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-evidence",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "requirement_audit": {
                "items": [
                    {"id": "R1", "status": "pass", "evidence": ["src/does-not-exist.py:7"]},
                    {"id": "R2", "status": "pass", "evidence": ["npm run build: ok"]},
                ],
                "completeness_verdict": "pass",
            },
        }
    )

    assert stop["requirement_audit_gap"] is True
    assert stop["recommend_revert"] is True
    assert any(
        "path does not exist" in err for err in stop["requirement_audit_report"]["errors"]
    )


def test_on_stop_requirement_audit_accepts_common_path_evidence_formats(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    (kernel.ctx.root / "src").mkdir(parents=True, exist_ok=True)
    (kernel.ctx.root / "src" / "ok.py").write_text("print('ok')\n", encoding="utf-8")

    kernel.on_session_start(
        {"session_id": "sess-stop-req-evidence-fmt", "objective": "Validate evidence formats"}
    )
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-evidence-fmt",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "requirement_audit": {
                "items": [
                    {
                        "id": "R1",
                        "status": "pass",
                        "evidence": [
                            "src/ok.py:1-2",
                            "src/ok.py updated import ordering",
                        ],
                    }
                ],
                "completeness_verdict": "pass",
            },
        }
    )

    assert stop["requirement_audit_gap"] is False
    assert stop["requirement_audit_report"]["ok"] is True


def test_on_stop_requirement_audit_unverified_command_blocks_in_strict_mode(
    kernel: CortexKernel,
) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True

    kernel.on_session_start({"session_id": "sess-stop-req-cmd-strict", "objective": "Validate commands"})
    kernel.on_pre_tool_use(
        {
            "session_id": "sess-stop-req-cmd-strict",
            "tool_name": "Bash",
            "command": "npm run build",
        }
    )
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-cmd-strict",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "requirement_audit": {
                "items": [{"id": "R1", "status": "pass", "evidence": ["cmd:pytest -q"]}],
                "completeness_verdict": "pass",
            },
        }
    )

    assert stop["requirement_audit_gap"] is True
    assert stop["recommend_revert"] is True
    assert any(
        "command not witnessed in session events" in err for err in stop["requirement_audit_report"]["errors"]
    )


def test_on_stop_requirement_audit_uncheckable_command_warns_in_advisory_mode(
    kernel: CortexKernel,
) -> None:
    kernel.ctx.genome.hooks.mode = "advisory"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True

    kernel.on_session_start({"session_id": "sess-stop-req-cmd-advisory", "objective": "Validate commands"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-req-cmd-advisory",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "requirement_audit": {
                "items": [{"id": "R1", "status": "pass", "evidence": ["cmd:pytest -q"]}],
                "completeness_verdict": "pass",
            },
        }
    )

    assert stop["requirement_audit_report"]["ok"] is True
    assert stop["requirement_audit_gap"] is False
    assert stop["recommend_revert"] is False
    assert any("Requirement audit note:" in warning for warning in stop["warnings"])


def test_on_stop_truth_claims_unverified_block_in_strict_mode(
    kernel: CortexKernel, monkeypatch
) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    snapshots = iter(
        [
            {"available": True, "changed_files": [], "error": None},
            {"available": True, "changed_files": ["src/actual.py"], "error": None},
        ]
    )
    monkeypatch.setattr(core_module, "session_git_snapshot", lambda _root: next(snapshots))

    kernel.on_session_start({"session_id": "sess-stop-truth-claims-strict", "objective": "Validate truth claims"})
    kernel.on_pre_tool_use(
        {
            "session_id": "sess-stop-truth-claims-strict",
            "tool_name": "Bash",
            "command": "pytest -q",
        }
    )
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-truth-claims-strict",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "truth_claims": {
                "modified_files": ["src/claimed.py"],
                "tests_ran": ["pytest -q", "npm test"],
            },
        }
    )

    assert stop["requirement_audit_gap"] is False
    assert stop["truth_claims_gap"] is True
    assert stop["requirements_gate_gap"] is True
    assert stop["recommend_revert"] is True
    assert stop["truth_claims_report"]["ok"] is False
    assert stop["truth_claims_report"]["modified_files_unverified"] == ["src/claimed.py"]
    assert stop["truth_claims_report"]["tests_ran_unverified"] == ["npm test"]
    assert any("Truth claims reported gaps:" in warning for warning in stop["warnings"])
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status, metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-truth-claims-strict",),
        ).fetchone()
    assert row["status"] == "failed_requirements"
    metadata = json.loads(row["metadata_json"])
    assert metadata["requirement_audit_gap"] is False
    assert metadata["truth_claims_ok"] is False
    assert metadata["truth_claims_gap"] is True
    assert metadata["requirements_gate_gap"] is True


def test_on_stop_stuck_declaration_becomes_session_verdict(kernel: CortexKernel, monkeypatch) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    snapshots = iter(
        [
            {"available": True, "changed_files": [], "error": None},
            {"available": True, "changed_files": ["src/actual.py"], "error": None},
        ]
    )
    monkeypatch.setattr(core_module, "session_git_snapshot", lambda _root: next(snapshots))

    kernel.on_session_start({"session_id": "sess-stop-stuck", "objective": "Validate truth claims"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-stuck",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "truth_claims": {"modified_files": ["src/claimed.py"]},
            "stuck_declaration": {
                "check": "truth_claims",
                "approaches_tried": ["git status", "re-read stop diagnostics"],
                "obstacle": "session-scoped delta does not show the claimed file",
            },
        }
    )

    assert stop["stuck_declared"] is True
    assert stop["feedback_mode"] == "stuck"
    assert stop["recommend_revert"] is False
    assert stop["proceed"] is False
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status, metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-stuck",),
        ).fetchone()
    assert row["status"] == "stuck"
    metadata = json.loads(row["metadata_json"])
    assert metadata["stuck_declared"] is True
    assert metadata["feedback_mode"] == "stuck"


def test_on_stop_truth_claims_unverified_warn_only_in_advisory_mode(
    kernel: CortexKernel, monkeypatch
) -> None:
    kernel.ctx.genome.hooks.mode = "advisory"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    snapshots = iter(
        [
            {"available": True, "changed_files": [], "error": None},
            {"available": True, "changed_files": ["src/actual.py"], "error": None},
        ]
    )
    monkeypatch.setattr(core_module, "session_git_snapshot", lambda _root: next(snapshots))
    kernel.on_session_start({"session_id": "sess-stop-truth-claims-advisory", "objective": "Validate truth claims"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-truth-claims-advisory",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "truth_claims": {
                "modified_files": ["src/claimed.py"],
            },
        }
    )

    assert stop["requirement_audit_gap"] is False
    assert stop["truth_claims_gap"] is True
    assert stop["requirements_gate_gap"] is True
    assert stop["recommend_revert"] is False
    assert stop["proceed"] is True
    assert stop["truth_claims_report"]["ok"] is False
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status FROM sessions WHERE session_id = ?",
            ("sess-stop-truth-claims-advisory",),
        ).fetchone()
    assert row["status"] == "completed"


def test_on_stop_invariant_failure_blocks_even_in_advisory_mode(
    kernel: CortexKernel, monkeypatch: pytest.MonkeyPatch
) -> None:
    kernel.ctx.genome.hooks.mode = "advisory"
    kernel.ctx.genome.invariants.run_on_stop = True
    call_count = {"n": 0}

    def _fail_invariants(*, session_id: str, extra_pytest_args=None):  # noqa: ANN001
        _ = session_id
        _ = extra_pytest_args
        call_count["n"] += 1
        return InvariantReport(
            configured_paths=["tests/invariants/test_fail.py"],
            diagnostics=[
                {
                    "evidence_found": ["tests/invariants/test_fail.py"],
                    "evidence_expected": ["invariant 'tests/invariants/test_fail.py' to pass"],
                    "gap_description": "Invariant 'tests/invariants/test_fail.py' failed.",
                    "gap_characterization": "execution_gap",
                    "distance_signal": "close",
                }
            ],
            ok=False,
            recommend_revert=True,
        )

    monkeypatch.setattr(kernel.invariants, "run", _fail_invariants)
    kernel.on_session_start({"session_id": "sess-stop-invariant-advisory", "objective": "Validate invariants"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-invariant-advisory",
            "run_invariants": True,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
        }
    )

    assert call_count["n"] == 1
    assert stop["invariant_report"]["ok"] is False
    assert stop["recommend_revert"] is True
    assert stop["proceed"] is False
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status FROM sessions WHERE session_id = ?",
            ("sess-stop-invariant-advisory",),
        ).fetchone()
    assert row["status"] == "failed_invariants"


def test_on_stop_truth_claims_parses_from_message_fallback(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.allow_message_stop_fallback = True
    kernel.on_session_start({"session_id": "sess-stop-truth-claims-fallback", "objective": "Fallback parse"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-truth-claims-fallback",
            "run_invariants": False,
            "last_assistant_message": (
                "Done.\n"
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true,"boundary_values":true,'
                '"error_handling":true,"graveyard_regression":true},'
                '"truth_claims":{"tests_ran":["pytest -q"]}}'
            ),
        }
    )
    assert stop["truth_claims_report"] is not None
    assert stop["truth_claims_report"]["tests_ran_claimed"] == ["pytest -q"]
    assert any("truth_claims parsed from last assistant message" in warning for warning in stop["warnings"])


def test_on_stop_truth_claims_uncheckable_does_not_hard_fail(
    kernel: CortexKernel, monkeypatch
) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    monkeypatch.setattr(
        core_module,
        "session_git_snapshot",
        lambda _root: {"available": False, "changed_files": [], "error": "not a git repository"},
    )

    kernel.on_session_start({"session_id": "sess-stop-truth-claims-uncheckable", "objective": "Non-git repo"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-truth-claims-uncheckable",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "truth_claims": {"modified_files": ["src/claimed.py"]},
        }
    )

    assert stop["truth_claims_report"]["ok"] is True
    assert stop["truth_claims_report"]["modified_files_uncheckable"] == ["src/claimed.py"]
    assert stop["requirement_audit_gap"] is False
    assert stop["truth_claims_gap"] is False
    assert stop["requirements_gate_gap"] is False
    assert stop["recommend_revert"] is False
    assert any("Truth claims note:" in warning for warning in stop["warnings"])


def test_on_stop_without_modified_files_claim_skips_stop_time_git_snapshot(
    kernel: CortexKernel, monkeypatch
) -> None:
    call_count = {"n": 0}

    def _snapshot(_root: Path) -> dict[str, object]:
        call_count["n"] += 1
        return {"available": True, "changed_files": [], "error": None}

    monkeypatch.setattr(core_module, "session_git_snapshot", _snapshot)

    kernel.on_session_start({"session_id": "sess-stop-no-modified-claim", "objective": "No git snapshot on stop"})
    assert call_count["n"] == 1
    kernel.on_pre_tool_use(
        {
            "session_id": "sess-stop-no-modified-claim",
            "tool_name": "Bash",
            "command": "pytest -q",
        }
    )
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-no-modified-claim",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "truth_claims": {"tests_ran": ["pytest -q"]},
        }
    )
    assert call_count["n"] == 1
    assert stop["truth_claims_report"]["ok"] is True


def test_on_stop_auto_started_session_preserves_baseline_for_later_modified_files_claim(
    kernel: CortexKernel, monkeypatch
) -> None:
    call_count = {"n": 0}
    snapshots = iter(
        [
            {"available": True, "changed_files": ["src/preexisting.py"], "error": None},
            {"available": True, "changed_files": ["src/preexisting.py", "src/new.py"], "error": None},
        ]
    )

    def _snapshot(_root: Path) -> dict[str, object]:
        call_count["n"] += 1
        return next(snapshots)

    monkeypatch.setattr(core_module, "session_git_snapshot", _snapshot)

    first = kernel.on_stop(
        {
            "session_id": "sess-stop-auto-start-baseline",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
        }
    )
    second = kernel.on_stop(
        {
            "session_id": "sess-stop-auto-start-baseline",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "truth_claims": {"modified_files": ["src/new.py"]},
        }
    )

    assert first["truth_claims_report"] is None
    assert call_count["n"] == 2
    assert second["truth_claims_report"]["ok"] is True
    assert second["truth_claims_report"]["modified_files_verified"] == ["src/new.py"]
    assert second["truth_claims_report"]["modified_files_uncheckable"] == []
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-auto-start-baseline",),
        ).fetchone()
    metadata = json.loads(row["metadata_json"])
    assert metadata["git_snapshot"]["changed_files"] == ["src/preexisting.py"]


def test_on_stop_with_modified_files_claim_runs_single_stop_time_git_snapshot(
    kernel: CortexKernel, monkeypatch
) -> None:
    call_count = {"n": 0}

    def _snapshot(_root: Path) -> dict[str, object]:
        call_count["n"] += 1
        if call_count["n"] == 1:
            return {"available": True, "changed_files": ["src/preexisting.py"], "error": None}
        return {"available": True, "changed_files": ["src/preexisting.py", "src/new.py"], "error": None}

    monkeypatch.setattr(core_module, "session_git_snapshot", _snapshot)

    kernel.on_session_start({"session_id": "sess-stop-modified-claim", "objective": "One stop git snapshot"})
    assert call_count["n"] == 1
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-modified-claim",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "truth_claims": {"modified_files": ["src/new.py"]},
        }
    )
    assert call_count["n"] == 2
    assert stop["truth_claims_report"]["ok"] is True
    assert stop["truth_claims_report"]["modified_files_verified"] == ["src/new.py"]


def test_on_stop_truth_claims_modified_files_uses_session_scoped_delta(
    kernel: CortexKernel, monkeypatch
) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    snapshots = iter(
        [
            {"available": True, "changed_files": ["src/preexisting.py"], "error": None},
            {"available": True, "changed_files": ["src/preexisting.py"], "error": None},
        ]
    )
    monkeypatch.setattr(core_module, "session_git_snapshot", lambda _root: next(snapshots))

    kernel.on_session_start({"session_id": "sess-stop-truth-claims-session-delta", "objective": "Delta scoping"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-truth-claims-session-delta",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "truth_claims": {"modified_files": ["src/preexisting.py"]},
        }
    )

    assert stop["truth_claims_report"]["ok"] is False
    assert stop["truth_claims_report"]["modified_files_verified"] == []
    assert stop["truth_claims_report"]["modified_files_unverified"] == ["src/preexisting.py"]
    assert stop["truth_claims_gap"] is True
    assert stop["requirements_gate_gap"] is True


def test_on_stop_truth_claims_modified_files_verify_when_changed_after_session_start(
    kernel: CortexKernel, monkeypatch
) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_requirement_audit_gap = True
    snapshots = iter(
        [
            {"available": True, "changed_files": ["src/preexisting.py"], "error": None},
            {"available": True, "changed_files": ["src/preexisting.py", "src/new.py"], "error": None},
        ]
    )
    monkeypatch.setattr(core_module, "session_git_snapshot", lambda _root: next(snapshots))

    kernel.on_session_start({"session_id": "sess-stop-truth-claims-session-verify", "objective": "Delta scoping"})
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-truth-claims-session-verify",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
            "truth_claims": {"modified_files": ["src/new.py"]},
        }
    )

    assert stop["truth_claims_report"]["ok"] is True
    assert stop["truth_claims_report"]["modified_files_verified"] == ["src/new.py"]
    assert stop["truth_claims_gap"] is False
    assert stop["requirements_gate_gap"] is False


def test_on_stop_strict_challenge_coverage_requires_verifiable_evidence(kernel: CortexKernel) -> None:
    kernel.ctx.genome.hooks.mode = "strict"
    kernel.ctx.genome.hooks.fail_on_missing_challenge_coverage = True
    stop = kernel.on_stop(
        {
            "session_id": "sess-stop-challenge-verifiable",
            "run_invariants": False,
            "challenge_coverage": {
                "null_inputs": True,
                "boundary_values": True,
                "error_handling": True,
                "graveyard_regression": True,
            },
        }
    )

    assert stop["challenge_report"]["ok"] is False
    assert sorted(stop["challenge_report"]["unverified_categories"]) == [
        "boundary_values",
        "error_handling",
        "graveyard_regression",
        "null_inputs",
    ]
    assert any("evidence is unverified" in warning for warning in stop["warnings"])
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT status, metadata_json FROM sessions WHERE session_id = ?",
            ("sess-stop-challenge-verifiable",),
        ).fetchone()
    assert row["status"] == "failed_challenges"
    metadata = json.loads(row["metadata_json"])
    assert sorted(metadata["challenge_unverified_categories"]) == [
        "boundary_values",
        "error_handling",
        "graveyard_regression",
        "null_inputs",
    ]


def test_dispatch_normalizes_event_names(kernel: CortexKernel) -> None:
    result = kernel.dispatch("pre-tool-use", {"session_id": "sess-dispatch"})
    assert result["hook"] == "PreToolUse"
    assert result["session_id"] == "sess-dispatch"


def test_dispatch_session_marker_requires_session_id(kernel: CortexKernel) -> None:
    with pytest.raises(ValueError, match="requires session_id"):
        kernel.dispatch("session_marker", {"label": "audit_complete"})


def test_dispatch_session_marker_requires_existing_label(kernel: CortexKernel) -> None:
    kernel.on_session_start({"session_id": "sess-marker-a", "objective": "a"})
    with pytest.raises(ValueError, match="non-empty 'label'"):
        kernel.dispatch("session_marker", {"session_id": "sess-marker-a", "label": ""})


def test_dispatch_session_marker_records_event_for_explicit_session(kernel: CortexKernel) -> None:
    kernel.on_session_start({"session_id": "sess-marker-explicit", "objective": "a"})
    result = kernel.dispatch(
        "session_marker",
        {"session_id": "sess-marker-explicit", "label": "audit_complete", "created_at": "2025-01-01T00:00:00Z"},
    )
    assert result["hook"] == "SessionMarker"
    assert result["session_id"] == "sess-marker-explicit"
    with kernel.ctx.store.connection() as conn:
        row = conn.execute(
            "SELECT payload_json FROM events WHERE session_id = ? AND hook = ? ORDER BY id DESC LIMIT 1",
            ("sess-marker-explicit", "SessionMarker"),
        ).fetchone()
    assert row is not None
    assert json.loads(row["payload_json"]) == {"label": "audit_complete"}


def test_repeated_events_reuse_in_process_session_start_cache(
    kernel: CortexKernel, monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: list[tuple[str, str, str | None, dict[str, Any] | None]] = []

    def _recorded_ensure(
        self, session_id: str, status: str, genome_path: str | None, metadata: dict[str, Any] | None = None  # noqa: ANN001
    ) -> None:
        calls.append((session_id, status, genome_path, metadata))

    monkeypatch.setattr("cortex.store.SQLiteStore.ensure_session_start", _recorded_ensure)
    monkeypatch.setattr(
        "cortex.core.session_git_snapshot",
        lambda _root: {"available": False, "changed_files": [], "error": "test"},
    )

    first = kernel.on_pre_tool_use(
        {"session_id": "sess-cache", "tool_name": "Read", "tool_input": {"path": "README.md"}}
    )
    second = kernel.on_pre_tool_use(
        {"session_id": "sess-cache", "tool_name": "Read", "tool_input": {"path": "README.md"}}
    )

    assert first["session_id"] == "sess-cache"
    assert second["session_id"] == "sess-cache"
    assert len(calls) == 1
    assert calls[0][0] == "sess-cache"


def test_retry_delta_sensitive_sequence_enforces_persistent_no_delta(kernel: CortexKernel) -> None:
    sid = "sess-core-retry-delta"
    kernel.on_session_start({"session_id": sid, "objective": "Retry delta sequence"})

    first = kernel.on_post_tool_use(
        {
            "session_id": sid,
            "tool_name": "Edit",
            "status": "error",
            "error": "Shape mismatch in output",
        }
    )
    second = kernel.on_post_tool_use(
        {
            "session_id": sid,
            "tool_name": "Edit",
            "status": "error",
            "error": "Shape mismatch in output",
        }
    )
    third = kernel.on_post_tool_use(
        {
            "session_id": sid,
            "tool_name": "Edit",
            "status": "error",
            "error": "Shape mismatch in output",
        }
    )
    fourth = kernel.on_post_tool_use(
        {
            "session_id": sid,
            "tool_name": "Edit",
            "status": "error",
            "error": "Shape mismatch in output",
            "changed_files": ["src/parser.py"],
        }
    )

    assert first["retry"]["decision_code"] == "retry_allowed"
    assert second["retry"]["decision_code"] == "no_delta"
    assert third["retry"]["decision_code"] == "no_delta"
    assert fourth["retry"]["decision_code"] == "retry_allowed"
