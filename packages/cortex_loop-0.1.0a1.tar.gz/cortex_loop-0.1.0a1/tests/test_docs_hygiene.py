from __future__ import annotations

import re
import subprocess
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

ACTIVE_DOCS = [
    ROOT / "CHANGELOG.md",
    ROOT / "README.md",
    ROOT / "START_HERE.md",
    ROOT / "ARCHITECTURE.md",
    ROOT / "MISSION.md",
    ROOT / "SOUL.md",
    ROOT / "SOUL_ADDENDUM.md",
    ROOT / "AGENTS.md",
    ROOT / "CONTRIBUTING.md",
    ROOT / "REPO_WORKFLOW.md",
    ROOT / "SECURITY.md",
    ROOT / "SUPPORT.md",
    ROOT / "docs" / "README.md",
    ROOT / "docs" / "ACTIVE_SURFACES.md",
    ROOT / "docs" / "LAUNCH_PLAN.md",
    ROOT / "docs" / "INSTALL.md",
    ROOT / "docs" / "ADAPTERS.md",
    ROOT / "docs" / "ADAPTER_VALIDATION.md",
    ROOT / "docs" / "AGENT_EVENT_SCHEMA.md",
    ROOT / "docs" / "SECURE_DEFAULTS.md",
]

INTERNAL_ENTRY_DOCS = [
    ROOT / "eval" / "README.md",
    ROOT / "eval" / "study" / "README.md",
    ROOT / "eval" / "study" / "mini_openai_ab" / "README.md",
]

ARCHIVE_ENTRYPOINTS = [
    ROOT / "docs" / "archive" / "README.md",
    ROOT / "docs" / "archive" / "plans" / "README.md",
    ROOT / "docs" / "archive" / "reference" / "README.md",
    ROOT / "_governance_archive" / "README.md",
]

ABSOLUTE_PATH_PATTERNS = (
    re.compile(r"/Users/[^\s\"')\]]+"),
    re.compile(r"[A-Za-z]:\\\\[^\s\"')\]]+"),
)

EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@([A-Za-z0-9.-]+\.[A-Za-z]{2,})\b")
ALLOWED_DOC_EMAILS = {
    "conduct@cortex-loop.dev",
}

MARKDOWN_LINK_RE = re.compile(r"\[[^\]]+\]\(([^)]+)\)")
CODE_SPAN_RE = re.compile(r"`([^`\n]+)`")
PATH_PREFIXES = (
    "README.md",
    "START_HERE.md",
    "ARCHITECTURE.md",
    "CONTRIBUTING.md",
    "REPO_WORKFLOW.md",
    "CHANGELOG.md",
    "CODE_OF_CONDUCT.md",
    "MISSION.md",
    "SECURITY.md",
    "SOUL.md",
    "SOUL_ADDENDUM.md",
    "SUPPORT.md",
    "AGENTS.md",
    "cortex.toml",
    "docs/",
    "eval/",
    "research/",
    "packs/",
    "claude/",
    "gemini/",
    "openai/",
    "tests/",
    "scripts/",
    ".github/",
    ".githooks/",
    "examples/",
    "_governance_archive/",
)
GENERATED_PROJECT_PATHS = {
    "tests/invariants/example_invariant_test.py",
}
FORBIDDEN_ACTIVE_AUTHORITY_REFS = (
    "docs/ATLAS_DELTA_LEDGER.md",
    "docs/CONTRIBUTOR_PACK_ONBOARDING.md",
    "docs/GEMINI_2_5_FLASH_TEST_LANE.md",
    "docs/WHY_CORTEX.md",
    "docs/REPOMAP_PARITY_CRITERIA.md",
    "docs/SHARE_STATUS.md",
    "docs/RELEASE_CHECKLIST.md",
    "docs/DEMO.md",
    "docs/CORTEX_CELL_ATLAS.md",
    "docs/TARGET_ARCHITECTURE_ATLAS.md",
)


def _tracked_markdown_scope() -> list[Path]:
    run = subprocess.run(
        ["git", "-C", str(ROOT), "ls-files"],
        check=True,
        capture_output=True,
        text=True,
    )
    out: list[Path] = []
    allowed_archive = {
        "docs/archive/README.md",
        "docs/archive/plans/README.md",
        "docs/archive/reference/README.md",
        "_governance_archive/README.md",
    }
    for raw in run.stdout.splitlines():
        rel = raw.strip()
        if not rel.endswith(".md"):
            continue
        if rel.startswith("docs/archive/") and rel not in allowed_archive:
            continue
        if rel.startswith("_governance_archive/") and rel not in allowed_archive:
            continue
        if (
            rel.startswith(("docs/", "eval/", "research/", "claude/", "gemini/", "openai/"))
            or rel == "packs/README.md"
            or "/" not in rel
        ):
            path = ROOT / rel
            if path.is_file():
                out.append(path)
    return sorted(set(out))


def _scan_matches(path: Path, patterns: tuple[re.Pattern[str], ...]) -> list[str]:
    text = path.read_text(encoding="utf-8")
    matches: list[str] = []
    for pattern in patterns:
        found = pattern.findall(text)
        for token in found:
            normalized = token.strip()
            if normalized:
                matches.append(normalized)
    return sorted(set(matches))


def _doc_paths() -> list[Path]:
    return ACTIVE_DOCS + INTERNAL_ENTRY_DOCS + ARCHIVE_ENTRYPOINTS


def _resolve_link(path: Path, target: str) -> Path | None:
    token = target.split("#", 1)[0].strip()
    if not token or token.startswith(("http://", "https://", "mailto:", "#")):
        return None
    return (path.parent / token).resolve()


def _iter_repo_code_paths(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    out: list[str] = []
    for raw in CODE_SPAN_RE.findall(text):
        token = raw.strip().strip("()[]{}.,;:")
        token = token.split("::", 1)[0]
        if not token or " " in token or "*" in token or "<" in token:
            continue
        if token.startswith(PATH_PREFIXES):
            out.append(token.rstrip("/"))
    return sorted(set(out))


def test_markdown_scope_has_no_absolute_local_paths() -> None:
    offenders: dict[str, list[str]] = {}
    for path in _tracked_markdown_scope():
        matches = _scan_matches(path, ABSOLUTE_PATH_PATTERNS)
        if matches:
            offenders[str(path.relative_to(ROOT))] = matches
    assert offenders == {}


def test_markdown_scope_has_no_unapproved_email_addresses() -> None:
    offenders: dict[str, list[str]] = {}
    for path in _tracked_markdown_scope():
        text = path.read_text(encoding="utf-8")
        matches: list[str] = []
        for match in EMAIL_RE.finditer(text):
            # Ignore SSH remote syntax like git@github.com:org/repo.git.
            if text[match.end() : match.end() + 1] == ":":
                continue
            if match.group(0).lower() in ALLOWED_DOC_EMAILS:
                continue
            matches.append(match.group(0))
        if matches:
            offenders[str(path.relative_to(ROOT))] = sorted(set(matches))
    assert offenders == {}


def test_active_docs_and_archive_entrypoints_have_resolving_markdown_links() -> None:
    offenders: dict[str, list[str]] = {}
    for path in _doc_paths():
        missing: list[str] = []
        text = path.read_text(encoding="utf-8")
        for target in MARKDOWN_LINK_RE.findall(text):
            resolved = _resolve_link(path, target)
            if resolved is None:
                continue
            if not resolved.exists():
                missing.append(target)
        if missing:
            offenders[str(path.relative_to(ROOT))] = sorted(set(missing))
    assert offenders == {}


def test_active_docs_and_archive_entrypoints_have_resolving_code_path_references() -> None:
    offenders: dict[str, list[str]] = {}
    for path in _doc_paths():
        missing: list[str] = []
        for token in _iter_repo_code_paths(path):
            if token in GENERATED_PROJECT_PATHS:
                continue
            if not (ROOT / token).exists():
                missing.append(token)
        if missing:
            offenders[str(path.relative_to(ROOT))] = sorted(set(missing))
    assert offenders == {}


def test_active_docs_do_not_use_archived_files_as_active_authority() -> None:
    offenders: dict[str, list[str]] = {}
    for path in ACTIVE_DOCS:
        text = path.read_text(encoding="utf-8")
        found = [token for token in FORBIDDEN_ACTIVE_AUTHORITY_REFS if token in text]
        if found:
            offenders[str(path.relative_to(ROOT))] = found
    assert offenders == {}


def test_core_doctrine_surfaces_teach_one_cortex() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    mission = (ROOT / "MISSION.md").read_text(encoding="utf-8")
    architecture = (ROOT / "ARCHITECTURE.md").read_text(encoding="utf-8")
    soul = (ROOT / "SOUL.md").read_text(encoding="utf-8")
    soul_addendum = (ROOT / "SOUL_ADDENDUM.md").read_text(encoding="utf-8")
    agents = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    launch_plan = (ROOT / "docs" / "LAUNCH_PLAN.md").read_text(encoding="utf-8")

    assert "runtime-agnostic enforcement layer for AI coding agents" in readme
    assert "The stop path is the product." in readme
    assert "## What Cortex Is Not" in readme
    assert "path of least resistance becomes the path of best practice" in readme
    assert "path of least resistance becomes the path of best practice" in mission
    assert "## Anti-goals" in mission
    assert "The stop path is the product" in soul
    assert '"The stop path is the product" means Cortex is defined by what happens when an agent claims completion.' in architecture
    assert "## Kernel Role Map" in architecture
    assert "externalized executive-function layer at the completion boundary" in mission
    assert "executive function" in soul_addendum
    assert "completion-boundary enforcement mission" in agents
    assert "asked to believe anything the repo cannot support" in launch_plan


def test_reading_path_is_indexed_for_new_humans_and_agents() -> None:
    docs_index = (ROOT / "docs" / "README.md").read_text(encoding="utf-8")

    assert "Recommended Reading Path" in docs_index
    assert "Each active file should have one clear job." in docs_index
    assert "when an agent says it is done, should the system believe it?" in docs_index
    assert "[../README.md](../README.md)" in docs_index
    assert "[../ARCHITECTURE.md](../ARCHITECTURE.md)" in docs_index
    assert "[../MISSION.md](../MISSION.md)" in docs_index
    assert "[../SOUL.md](../SOUL.md)" in docs_index
    assert "[../SOUL_ADDENDUM.md](../SOUL_ADDENDUM.md)" in docs_index
    assert "[../AGENTS.md](../AGENTS.md)" in docs_index
    assert "[../REPO_WORKFLOW.md](../REPO_WORKFLOW.md)" in docs_index


def test_internal_eval_entry_docs_are_explicitly_non_authoritative() -> None:
    agents = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    active_surfaces = (ROOT / "docs" / "ACTIVE_SURFACES.md").read_text(encoding="utf-8")
    eval_index = (ROOT / "eval" / "README.md").read_text(encoding="utf-8")
    study = (ROOT / "eval" / "study" / "README.md").read_text(encoding="utf-8")
    mini = (ROOT / "eval" / "study" / "mini_openai_ab" / "README.md").read_text(encoding="utf-8")

    assert "Do not treat `eval/study/` as product or kernel design authority unless the task explicitly asks for study verification or study recovery." in agents
    assert "not downstream product interfaces and they are not product-design authority unless a task explicitly calls for study verification or study recovery" in active_surfaces
    assert "it is not product or kernel design authority" in eval_index
    assert "not a design authority for kernel or adapter work unless a task explicitly says to perform study verification or study recovery" in study
    assert "should not shape kernel or adapter design unless a task explicitly asks for study verification or study recovery" in mini


def test_primary_runtime_status_labels_match_between_readme_and_adapter_reference() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    adapters = (ROOT / "docs" / "ADAPTERS.md").read_text(encoding="utf-8")

    rows = (
        "| Claude Code | `cortex runtime install --profile claude` | Shipped |",
        "| Gemini CLI | `cortex runtime install --profile gemini` | Shipped with watchlist |",
        "| OpenAI Codex App Server | `cortex runtime install --profile openai` | Experimental |",
    )
    adapter_rows = (
        "| Claude Code | `cortex.adapters.claude:ClaudeAdapter` | `claude` | Shipped |",
        "| Gemini CLI | `cortex.adapters.gemini:GeminiAdapter` | `gemini` | Shipped with watchlist |",
        "| OpenAI Codex App Server | `cortex.adapters.openai:OpenAIAdapter` | `openai` | Experimental |",
    )
    for row in rows:
        assert row in readme
    for row in adapter_rows:
        assert row in adapters


def test_package_metadata_teaches_current_cortex() -> None:
    project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))["project"]

    assert project["description"] == "Runtime-agnostic enforcement layer for AI coding agents"
    assert "quality and judgment layer" not in project["description"].lower()
    assert "enforcement" in project["keywords"]
    assert "verification" in project["keywords"]


def test_build_system_is_minimal_and_local_toolchain_friendly() -> None:
    build_system = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))["build-system"]

    assert build_system["requires"] == ["setuptools>=68"]
    assert build_system["build-backend"] == "setuptools.build_meta"


def test_launch_docs_are_the_active_authority() -> None:
    docs_index = (ROOT / "docs" / "README.md").read_text(encoding="utf-8")
    active_surfaces = (ROOT / "docs" / "ACTIVE_SURFACES.md").read_text(encoding="utf-8")
    launch_plan = (ROOT / "docs" / "LAUNCH_PLAN.md").read_text(encoding="utf-8")
    agents = (ROOT / "AGENTS.md").read_text(encoding="utf-8")

    assert "todos.md" not in docs_index
    assert "todos.md" not in active_surfaces
    assert "todos.md" not in launch_plan
    assert "todos.md" not in agents
    assert "Launch doctrine lives in [LAUNCH_PLAN.md](LAUNCH_PLAN.md)" in docs_index
    assert "Active launch doctrine and launch-status truth live in `docs/LAUNCH_PLAN.md`." in active_surfaces
    assert "active launch and launch-status" in launch_plan
    assert "Active launch/status authority: `docs/LAUNCH_PLAN.md`, `docs/INSTALL.md`, `docs/ADAPTERS.md`, `docs/ADAPTER_VALIDATION.md`" in agents


def test_active_docs_define_distinct_roles() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    mission = (ROOT / "MISSION.md").read_text(encoding="utf-8")
    architecture = (ROOT / "ARCHITECTURE.md").read_text(encoding="utf-8")
    active_surfaces = (ROOT / "docs" / "ACTIVE_SURFACES.md").read_text(encoding="utf-8")
    launch_plan = (ROOT / "docs" / "LAUNCH_PLAN.md").read_text(encoding="utf-8")
    install = (ROOT / "docs" / "INSTALL.md").read_text(encoding="utf-8")
    adapters = (ROOT / "docs" / "ADAPTERS.md").read_text(encoding="utf-8")
    adapter_validation = (ROOT / "docs" / "ADAPTER_VALIDATION.md").read_text(encoding="utf-8")
    docs_index = (ROOT / "docs" / "README.md").read_text(encoding="utf-8")
    security = (ROOT / "SECURITY.md").read_text(encoding="utf-8")

    assert "## What Cortex Is Not" in readme
    assert "## Anti-goals" in mission
    assert "## Kernel Role Map" in architecture
    assert "source-of-truth authority map" in active_surfaces
    assert "launch/status control centered in `docs/LAUNCH_PLAN.md`" in active_surfaces
    assert "[LAUNCH_PLAN.md](LAUNCH_PLAN.md)" in docs_index
    assert "active launch and launch-status" in launch_plan
    assert "INSTALL.md" in active_surfaces
    assert "[INSTALL.md](INSTALL.md)" in docs_index
    assert "active install authority for Cortex" in install
    assert "[../SECURITY.md](../SECURITY.md)" in docs_index
    assert "Repository Release Controls" in security
    assert "[ADAPTER_VALIDATION.md](ADAPTER_VALIDATION.md)" in docs_index
    assert "This file remains the user-facing runtime status and caveat reference." in adapters
    assert "It does not replace [ADAPTERS.md](ADAPTERS.md)" in adapter_validation
    assert "shared `0.1` adapter release contract" in adapter_validation
    assert "supporting proof only" in adapter_validation
    assert "starts at `Unvalidated` and only changes when live evidence exists" in adapter_validation
    assert "## Runtime Summary" not in adapter_validation


def test_active_and_internal_entry_docs_do_not_reference_live_known_blockers_notes() -> None:
    offenders: dict[str, str] = {}
    for path in ACTIVE_DOCS + INTERNAL_ENTRY_DOCS:
        text = path.read_text(encoding="utf-8")
        if "KNOWN_BLOCKERS.md" in text:
            offenders[str(path.relative_to(ROOT))] = "KNOWN_BLOCKERS.md"
    assert offenders == {}


def _assert_install_update_uninstall_triplet(text: str) -> None:
    if "pipx install cortex-loop" in text:
        assert "pipx upgrade cortex-loop" in text
        assert "pipx uninstall cortex-loop" in text
    if "uv tool install cortex-loop" in text:
        assert "uv tool upgrade cortex-loop" in text
        assert "uv tool uninstall cortex-loop" in text


def test_install_authority_teaches_staged_install_truth() -> None:
    docs_index = (ROOT / "docs" / "README.md").read_text(encoding="utf-8")
    install = (ROOT / "docs" / "INSTALL.md").read_text(encoding="utf-8")

    assert "[INSTALL.md](INSTALL.md)" in docs_index
    assert "As of 2026-03-07, `cortex-loop` is not yet published on PyPI." in install
    assert "`python3 -m pip index versions cortex-loop`" in install
    assert "`https://pypi.org/simple/cortex-loop/`" in install
    assert "Local-artifact proof: complete." in install
    assert "Live-index proof: pending." in install
    assert "pipx install cortex-loop" in install
    assert "uv tool install cortex-loop" in install
    assert "pipx ensurepath" in install
    assert "uv tool update-shell" in install
    _assert_install_update_uninstall_triplet(install)


def test_first_contact_install_docs_stay_truthful_before_public_flip() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    start_here = (ROOT / "START_HERE.md").read_text(encoding="utf-8")
    install = (ROOT / "docs" / "INSTALL.md").read_text(encoding="utf-8")

    for text in (readme, start_here, install):
        lowered = text.lower()
        assert "homebrew" not in lowered
        assert "brew install" not in lowered
        _assert_install_update_uninstall_triplet(text)

    assert "pip install cortex-loop" not in readme
    assert "pip install cortex-loop" not in start_here
    assert "not yet published on PyPI" in readme
    assert "not yet live on PyPI" in start_here


def test_release_truth_and_publish_policy_are_explicit() -> None:
    changelog = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    install = (ROOT / "docs" / "INSTALL.md").read_text(encoding="utf-8")
    workflow = (ROOT / "REPO_WORKFLOW.md").read_text(encoding="utf-8")
    security = (ROOT / "SECURITY.md").read_text(encoding="utf-8")

    assert "0.1.0a1` pre-1.0 package line" in changelog
    assert "Historical repository tag `v0.1.0-alpha.1` is archival provenance" in changelog
    assert "the GitHub repo home is final" in install
    assert "GitHub OIDC Trusted Publishing" in install
    assert "If the repository is moving from a personal account into an organization" in workflow
    assert "Public package publication must use GitHub OIDC Trusted Publishing." in workflow
    assert "Do not use or document long-lived PyPI API tokens as the primary path." in workflow
    assert "latest alpha tag" not in security
    assert "latest published package line" in security
