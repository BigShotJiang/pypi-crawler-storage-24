from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
import sys
import sysconfig

import pytest

from cortex import cli as cortex_cli
from cortex.adapters import GenericAdapter
from cortex.core import CortexKernel
from cortex.store import SQLiteStore
from cortex_ops_cli import _adapter_validation as adapter_validation

REPO_ROOT = Path(__file__).resolve().parents[1]
HOST_EXECUTION_WARNING = (
    "invariants.execution_mode='host' runs tests on the host machine; use only for "
    "trusted repositories (switch to execution_mode='container' for stronger isolation)"
)


def _init_kernel_project(root: Path, capsys) -> None:
    assert cortex_cli.main(["init", "--root", str(root)]) == 0
    _ = capsys.readouterr()
    cfg_path = root / "cortex.toml"
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8").replace('container_engine = "docker"', 'container_engine = "python3"', 1),
        encoding="utf-8",
    )


def _bootstrap_runtime_project(root: Path, capsys) -> None:
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "claude", "--root", str(root)]) == 0
    _ = capsys.readouterr()
    cfg_path = root / "cortex.toml"
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8")
        .replace('trust_profile = "untrusted"', 'trust_profile = "trusted"', 1)
        .replace('execution_mode = "container"', 'execution_mode = "host"', 1),
        encoding="utf-8",
    )

def _bootstrap_adapter_validation_project(root: Path, capsys, *, profile: str) -> None:
    adapter_validation.bootstrap_project(
        repo_root=REPO_ROOT,
        root=root,
        profile=profile,
        cli_main=cortex_cli.main,
    )
    _ = capsys.readouterr()


def _mock_check_binaries(monkeypatch: pytest.MonkeyPatch, *, include_codex: bool = False) -> None:
    real_which = cortex_cli.shutil.which
    real_run = subprocess.run

    def _fake_which(token: str) -> str | None:
        if token == "pytest":
            return "/usr/local/bin/pytest"
        if include_codex and token == "codex":
            return "/usr/local/bin/codex"
        return real_which(token)

    monkeypatch.setattr(cortex_cli.shutil, "which", _fake_which)
    if not include_codex:
        return

    class _Completed:
        stdout = "codex 0.111.0\n"
        stderr = ""
        returncode = 0

    def _fake_run(cmd: list[str], *args: object, **kwargs: object) -> object:
        if cmd == ["codex", "--version"]:
            return _Completed()
        return real_run(cmd, *args, **kwargs)

    monkeypatch.setattr(cortex_cli.subprocess, "run", _fake_run)


def test_version_flag_prints_package_version(capsys) -> None:
    with pytest.raises(SystemExit) as exc_info:
        cortex_cli.main(["--version"])
    assert exc_info.value.code == 0
    assert capsys.readouterr().out.strip() == f"cortex {cortex_cli.__version__}"


def test_python_module_cli_entrypoint_executes_version() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "cortex.cli", "--version"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert result.stdout.strip() == f"cortex {cortex_cli.__version__}"


def test_pyproject_declares_cortex_loop_script_alias() -> None:
    pyproject = (Path(__file__).resolve().parents[1] / "pyproject.toml").read_text(
        encoding="utf-8"
    )
    assert 'cortex = "cortex.cli:main"' in pyproject
    assert 'cortex-loop = "cortex.cli:main"' in pyproject


def test_cortex_loop_alias_binary_executes_version() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    script_name = "cortex-loop.exe" if sys.platform.startswith("win") else "cortex-loop"
    script_dirs = [
        Path(sysconfig.get_path("scripts") or ""),
        Path(sys.executable).resolve().parent,
    ]

    def _resolve_binary() -> str:
        for script_dir in script_dirs:
            candidate = script_dir / script_name
            if candidate.exists():
                return str(candidate)
        discovered = shutil.which("cortex-loop")
        return discovered if discovered is not None else ""

    binary = _resolve_binary()
    if not binary:
        install = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-e", str(repo_root)],
            capture_output=True,
            text=True,
            check=False,
        )
        binary = _resolve_binary()
        if not binary:
            pytest.fail(
                "expected installed cortex-loop console script in interpreter scripts path or PATH after `pip install -e .`; "
                f"pip_exit={install.returncode}"
            )
    result = subprocess.run(
        [binary, "--version"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        pytest.fail(
            "cortex-loop --version failed: "
            f"exit={result.returncode} stdout={result.stdout!r} stderr={result.stderr!r}"
        )
    assert result.stdout.strip() == f"cortex {cortex_cli.__version__}"


def test_init_creates_turnkey_files(tmp_path: Path, capsys) -> None:
    root = tmp_path / "new-project"
    rc = cortex_cli.main(["init", "--root", str(root)])
    assert rc == 0

    result = json.loads(capsys.readouterr().out)
    assert result["ok"] is True
    assert result["runtime_profile"] is None
    assert (root / "cortex.toml").exists()
    assert (root / ".cortex" / "cortex.db").exists()
    assert (root / "tests" / "invariants" / "example_invariant_test.py").exists()
    assert not (root / ".claude" / "settings.json").exists()
    assert not (root / ".claude" / "CLAUDE.md").exists()

    starter = (root / "tests" / "invariants" / "example_invariant_test.py").read_text(
        encoding="utf-8"
    )
    assert "external constraints the current agent did not author" in starter
    assert "def test_cortex_config_exists()" in starter
    assert "Example of a real invariant" in starter
    starter_cfg = (root / "cortex.toml").read_text(encoding="utf-8")
    assert "require_requirement_audit = false" in starter_cfg
    assert "fail_on_requirement_audit_gap = false" in starter_cfg
    assert "require_evidence_for_passed_requirement = true" in starter_cfg
    assert "require_structured_stop_payload = true" in starter_cfg
    assert "allow_message_stop_fallback = false" in starter_cfg
    assert 'trust_profile = "untrusted"' in starter_cfg
    assert 'execution_mode = "container"' in starter_cfg
    assert "parity_profile = false" in starter_cfg
    assert "[runtime]" in starter_cfg
    assert 'adapter = ""' in starter_cfg
    assert 'part_a_mode = "once_per_project"' in starter_cfg
    assert "max_entries = 20" in starter_cfg
    assert "max_tokens = 1200" in starter_cfg
    assert "context_max_matches = 2" in starter_cfg
    assert "context_summary_chars = 140" in starter_cfg
    assert "context_reason_chars = 200" in starter_cfg
    assert "context_max_tokens = 300" in starter_cfg


def test_runtime_install_creates_claude_profile_and_updates_adapter(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-profile-project"
    _init_kernel_project(root, capsys)

    rc = cortex_cli.main(["runtime", "install", "--profile", "claude", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    result = json.loads(out)
    assert result["ok"] is True
    assert result["profile"] == "claude"
    assert result["adapter"] == "cortex.adapters.claude:ClaudeAdapter"
    assert result["config_status"] in {"updated", "unchanged"}
    assert (root / ".claude" / "settings.json").exists()
    assert (root / ".claude" / "CLAUDE.md").exists()

    repo_root = Path(__file__).resolve().parents[1]
    generated_settings = json.loads((root / ".claude" / "settings.json").read_text(encoding="utf-8"))
    template_settings = json.loads((repo_root / "claude" / "settings.json").read_text(encoding="utf-8"))
    assert set(generated_settings["hooks"]) == set(template_settings["hooks"])
    for event in ("PreToolUse", "PostToolUse", "Stop"):
        command = generated_settings["hooks"][event][0]["hooks"][0]["command"]
        assert f"--schema-version {cortex_cli.CLAUDE_PINNED_HOOK_SCHEMA}" in command
    assert "cortex.adapters.claude:ClaudeAdapter" in (root / "cortex.toml").read_text(encoding="utf-8")


def test_runtime_install_creates_gemini_profile_and_updates_adapter(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-gemini-project"
    _init_kernel_project(root, capsys)

    rc = cortex_cli.main(["runtime", "install", "--profile", "gemini", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    result = json.loads(out)
    assert result["ok"] is True
    assert result["profile"] == "gemini"
    assert result["adapter"] == "cortex.adapters.gemini:GeminiAdapter"
    assert result["config_status"] in {"updated", "unchanged"}
    assert (root / ".gemini" / "settings.json").exists()
    assert (root / ".gemini" / "GEMINI.md").exists()

    generated_settings = json.loads((root / ".gemini" / "settings.json").read_text(encoding="utf-8"))
    assert generated_settings["hooksConfig"] == {"enabled": True}
    assert generated_settings["model"]["maxSessionTurns"] == 50
    assert generated_settings["model"]["compressionThreshold"] == 0.35
    assert set(generated_settings["hooks"]) == {"SessionStart", "BeforeTool", "AfterTool", "BeforeAgent", "AfterAgent"}
    after_agent_cfg = generated_settings["hooks"]["AfterAgent"][0]["hooks"][0]
    assert after_agent_cfg["type"] == "command"
    assert after_agent_cfg["name"] == "cortex-after-agent"
    assert after_agent_cfg["timeout"] == 60000
    gemini_md = (root / ".gemini" / "GEMINI.md").read_text(encoding="utf-8")
    assert "Do not emit the marker through a shell command" in gemini_md
    assert "Bare booleans are not enough." in gemini_md
    assert "cortex.adapters.gemini:GeminiAdapter" in (root / "cortex.toml").read_text(encoding="utf-8")


def test_runtime_install_creates_openai_profile_and_updates_adapter(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-openai-project"
    _init_kernel_project(root, capsys)

    rc = cortex_cli.main(["runtime", "install", "--profile", "openai", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    result = json.loads(out)
    assert result["ok"] is True
    assert result["profile"] == "openai"
    assert result["adapter"] == "cortex.adapters.openai:OpenAIAdapter"
    assert result["config_status"] in {"updated", "unchanged"}

    profile_path = root / ".codex" / "cortex_openai_bridge.json"
    assert profile_path.exists()
    assert (root / ".codex" / "OPENAI.md").exists()
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    assert profile["schema_version"] == cortex_cli.OPENAI_BRIDGE_SCHEMA_VERSION
    command = profile["bridge"]["command"]
    assert cortex_cli.OPENAI_BRIDGE_COMMAND_PATTERN in command
    assert f"--schema-version {cortex_cli.OPENAI_BRIDGE_SCHEMA_VERSION}" in command
    openai_md = (root / ".codex" / "OPENAI.md").read_text(encoding="utf-8")
    assert "repo-verifiable evidence tokens" in openai_md
    assert "Do not use pytest node ids" in openai_md
    assert "cortex.adapters.openai:OpenAIAdapter" in (root / "cortex.toml").read_text(encoding="utf-8")


def test_check_errors_when_runtime_adapter_is_unset(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-missing-project"
    _init_kernel_project(root, capsys)

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "Missing runtime adapter config" in out


def test_check_with_valid_claude_adapter_and_no_profile_is_warning_only(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-config-only-project"
    _init_kernel_project(root, capsys)

    cfg_path = root / "cortex.toml"
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8").replace(
            'adapter = ""',
            'adapter = "cortex.adapters.claude:ClaudeAdapter"',
            1,
        ),
        encoding="utf-8",
    )

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Runtime adapter loaded: cortex.adapters.claude:ClaudeAdapter" in out
    assert "Claude runtime profile settings not found" in out


def test_check_with_valid_gemini_adapter_and_no_profile_is_error(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-gemini-config-only-project"
    _init_kernel_project(root, capsys)

    cfg_path = root / "cortex.toml"
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8").replace(
            'adapter = ""',
            'adapter = "cortex.adapters.gemini:GeminiAdapter"',
            1,
        ),
        encoding="utf-8",
    )

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "Runtime adapter loaded: cortex.adapters.gemini:GeminiAdapter" in out
    assert "No Gemini settings file found." in out


def test_check_with_valid_openai_adapter_and_no_profile_is_error(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-openai-config-only-project"
    _init_kernel_project(root, capsys)

    cfg_path = root / "cortex.toml"
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8").replace(
            'adapter = ""',
            'adapter = "cortex.adapters.openai:OpenAIAdapter"',
            1,
        ),
        encoding="utf-8",
    )

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "Runtime adapter loaded: cortex.adapters.openai:OpenAIAdapter" in out
    assert "No OpenAI bridge profile found." in out


def test_check_errors_when_claude_hook_schema_version_mismatches_pinned_runtime(
    tmp_path: Path, capsys
) -> None:
    root = tmp_path / "runtime-claude-schema-mismatch-project"
    _bootstrap_runtime_project(root, capsys)

    settings_path = root / ".claude" / "settings.json"
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    settings["hooks"]["Stop"][0]["hooks"][0]["command"] = "python3 -m cortex.hooks.stop --schema-version legacy_json_v0"
    settings_path.write_text(json.dumps(settings, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "does not match pinned runtime schema" in out
    assert "claude_native_v1" in out


def test_check_errors_when_openai_bridge_schema_version_mismatches_pinned_runtime(
    tmp_path: Path, capsys
) -> None:
    root = tmp_path / "runtime-openai-schema-mismatch-project"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "openai", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    profile_path = root / ".codex" / "cortex_openai_bridge.json"
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    profile["schema_version"] = "openai_app_server_v0"
    profile_path.write_text(json.dumps(profile, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "schema_version must be 'openai_app_server_v1'" in out


def test_check_errors_when_openai_codex_bin_missing_from_path(
    tmp_path: Path,
    capsys,
    monkeypatch,
) -> None:
    root = tmp_path / "runtime-openai-codex-missing"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "openai", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    profile_path = root / ".codex" / "cortex_openai_bridge.json"
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    profile["bridge"]["codex_bin"] = "codex-missing"
    profile_path.write_text(json.dumps(profile, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    monkeypatch.setattr(
        cortex_cli.shutil,
        "which",
        lambda token: None if token == "codex-missing" else "/usr/bin/true",
    )

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "bridge.codex_bin 'codex-missing' is not on PATH" in out


def test_check_warns_when_openai_codex_version_below_tested_baseline(
    tmp_path: Path,
    capsys,
    monkeypatch,
) -> None:
    root = tmp_path / "runtime-openai-codex-version-warning"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "openai", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    monkeypatch.setattr(cortex_cli.shutil, "which", lambda _token: "/usr/local/bin/codex")

    class _Completed:
        stdout = "codex 0.107.0\n"
        stderr = ""
        returncode = 0

    monkeypatch.setattr(cortex_cli.subprocess, "run", lambda *args, **kwargs: _Completed())

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "below tested baseline 0.111.0" in out


def test_check_with_runtime_installed_gemini_profile_passes(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-gemini-check-project"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "gemini", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Runtime adapter loaded: cortex.adapters.gemini:GeminiAdapter" in out
    assert "Runtime profile wiring found in" in out
    assert "Missing / Errors:" in out


def test_memory_export_import_list_delete_round_trip(tmp_path: Path, capsys) -> None:
    root_a = tmp_path / "mem-project-a"
    _init_kernel_project(root_a, capsys)
    store_a = SQLiteStore(root_a / ".cortex" / "cortex.db")
    store_a.initialize()
    store_a.increment_session_counter()
    entry = store_a.record_executive_event(
        "metacognitive",
        "human contradicted file content claim",
        "defended without re-read",
        "re-open file and verify",
        "sess-a",
    )
    store_a.update_executive_entry(entry["id"], strength=3, last_accessed_at_session=1)
    export_path = root_a / "memory_export.json"

    assert (
        cortex_cli.main(
            [
                "memory",
                "export",
                "--root",
                str(root_a),
                "--output",
                str(export_path),
            ]
        )
        == 0
    )
    _ = capsys.readouterr()
    exported = json.loads(export_path.read_text(encoding="utf-8"))
    assert exported["entries"]
    assert "effective_weight" in exported["entries"][0]

    root_b = tmp_path / "mem-project-b"
    _init_kernel_project(root_b, capsys)
    assert cortex_cli.main(["memory", "import", str(export_path), "--root", str(root_b)]) == 0
    _ = capsys.readouterr()

    store_b = SQLiteStore(root_b / ".cortex" / "cortex.db")
    store_b.initialize()
    imported_entries = store_b.get_executive_memory()
    assert len(imported_entries) == 1
    assert imported_entries[0]["last_accessed_at_session"] == 0

    kernel_b = CortexKernel(
        root=root_b,
        config_path=root_b / "cortex.toml",
        db_path=root_b / ".cortex" / "cortex.db",
        adapter=GenericAdapter(),
    )
    start_b = kernel_b.on_session_start({"session_id": "sess-imported", "objective": "Use imported memory"})
    assert "re-open file and verify" in start_b["executive_context"]["learned"]

    assert cortex_cli.main(["memory", "import", str(export_path), "--root", str(root_b)]) == 0
    _ = capsys.readouterr()
    strengthened = store_b.get_executive_memory()[0]
    assert strengthened["strength"] == 6

    store_b.update_executive_entry(strengthened["id"], strength=1, last_accessed_at_session=1)
    for _ in range(120):
        store_b.increment_session_counter()

    assert cortex_cli.main(["memory", "list", "--root", str(root_b)]) == 0
    listed_default = json.loads(capsys.readouterr().out)
    assert listed_default["entries"] == []

    assert cortex_cli.main(["memory", "list", "--root", str(root_b), "--include-decayed"]) == 0
    listed_all = json.loads(capsys.readouterr().out)
    assert len(listed_all["entries"]) == 1
    assert listed_all["entries"][0]["id"] == strengthened["id"]

    assert cortex_cli.main(["memory", "delete", strengthened["id"], "--root", str(root_b)]) == 0
    _ = capsys.readouterr()
    assert store_b.get_executive_memory() == []


def test_memory_import_into_active_project_seeds_recency_to_current_session(tmp_path: Path, capsys) -> None:
    root_a = tmp_path / "mem-active-a"
    _init_kernel_project(root_a, capsys)
    store_a = SQLiteStore(root_a / ".cortex" / "cortex.db")
    store_a.initialize()
    store_a.increment_session_counter()
    store_a.record_executive_event(
        "technical",
        "changed auth module",
        "assumed tests pass",
        "run targeted auth tests",
        "sess-a",
    )
    export_path = root_a / "memory_export.json"
    assert cortex_cli.main(["memory", "export", "--root", str(root_a), "--output", str(export_path)]) == 0
    _ = capsys.readouterr()

    root_b = tmp_path / "mem-active-b"
    _init_kernel_project(root_b, capsys)
    store_b = SQLiteStore(root_b / ".cortex" / "cortex.db")
    store_b.initialize()
    for _ in range(120):
        store_b.increment_session_counter()
    assert store_b.get_session_count() == 120

    assert cortex_cli.main(["memory", "import", str(export_path), "--root", str(root_b)]) == 0
    _ = capsys.readouterr()
    imported = store_b.get_executive_memory()
    assert len(imported) == 1
    assert imported[0]["last_accessed_at_session"] == 120

    assert cortex_cli.main(["memory", "list", "--root", str(root_b)]) == 0
    listed = json.loads(capsys.readouterr().out)
    assert len(listed["entries"]) == 1
    assert listed["entries"][0]["id"] == imported[0]["id"]


def test_memory_list_labels_fading_band_as_not_injected(tmp_path: Path, capsys) -> None:
    root = tmp_path / "mem-fading"
    _init_kernel_project(root, capsys)
    store = SQLiteStore(root / ".cortex" / "cortex.db")
    store.initialize()
    for _ in range(100):
        store.increment_session_counter()

    active = store.record_executive_event(
        "technical",
        "active trigger",
        "active error",
        "active resolution",
        "sess-active",
    )
    fading = store.record_executive_event(
        "technical",
        "fading trigger",
        "fading error",
        "fading resolution",
        "sess-fading",
    )
    decayed = store.record_executive_event(
        "technical",
        "decayed trigger",
        "decayed error",
        "decayed resolution",
        "sess-decayed",
    )

    store.update_executive_entry(active["id"], strength=1, last_accessed_at_session=80)   # ~0.60 active
    store.update_executive_entry(fading["id"], strength=1, last_accessed_at_session=55)  # ~0.40 fading
    store.update_executive_entry(decayed["id"], strength=1, last_accessed_at_session=10)  # ~0.25 decayed

    assert cortex_cli.main(["memory", "list", "--root", str(root)]) == 0
    listed_default = json.loads(capsys.readouterr().out)
    states_default = {entry["id"]: entry["injection_state"] for entry in listed_default["entries"]}
    assert states_default[active["id"]] == "active"
    assert states_default[fading["id"]] == "fading_not_injected"
    assert decayed["id"] not in states_default

    assert cortex_cli.main(["memory", "list", "--root", str(root), "--include-decayed"]) == 0
    listed_all = json.loads(capsys.readouterr().out)
    states_all = {entry["id"]: entry["injection_state"] for entry in listed_all["entries"]}
    assert states_all[decayed["id"]] == "decayed"


def test_check_errors_when_gemini_hooks_are_globally_disabled(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-gemini-hooks-disabled-project"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "gemini", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    settings_path = root / ".gemini" / "settings.json"
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    settings["hooksConfig"] = {"enabled": False}
    settings_path.write_text(json.dumps(settings, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "Gemini hooks are globally disabled" in out
    assert "hooksConfig.enabled to true or remove the field (defaults to true)" in out


def test_check_errors_when_gemini_after_agent_hook_missing(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-gemini-after-agent-missing"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "gemini", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    settings_path = root / ".gemini" / "settings.json"
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    settings["hooks"]["AfterAgent"] = []
    settings_path.write_text(json.dumps(settings, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "No AfterAgent hook configured. Cortex stop path cannot fire without this hook." in out


def test_check_warns_when_gemini_before_or_after_tool_hook_missing(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-gemini-tool-hooks-missing"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "gemini", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    settings_path = root / ".gemini" / "settings.json"
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    settings["hooks"]["BeforeTool"] = []
    settings["hooks"]["AfterTool"] = []
    settings_path.write_text(json.dumps(settings, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "No BeforeTool hook. Tool blocklist enforcement will not run." in out
    assert "No AfterTool hook. Post-tool failure detection will not run." in out


def test_check_errors_when_gemini_after_agent_hook_config_invalid(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-gemini-after-agent-invalid"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "gemini", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    settings_path = root / ".gemini" / "settings.json"
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    settings["hooks"]["AfterAgent"][0]["hooks"][0] = {"type": "webhook", "command": ""}
    settings_path.write_text(json.dumps(settings, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "AfterAgent hook configuration is invalid. Each hook config requires type: 'command'" in out


def test_check_warns_when_gemini_hook_command_path_missing(tmp_path: Path, capsys) -> None:
    root = tmp_path / "runtime-gemini-command-path-warning"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "gemini", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    settings_path = root / ".gemini" / "settings.json"
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    settings["hooks"]["BeforeTool"][0]["hooks"][0]["command"] = "./scripts/missing_hook.py --arg"
    settings_path.write_text(json.dumps(settings, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Hook command may reference a missing path: ./scripts/missing_hook.py --arg." in out


def test_runtime_install_is_idempotent_without_force_and_overwrites_with_force(
    tmp_path: Path, capsys
) -> None:
    root = tmp_path / "project"
    _init_kernel_project(root, capsys)
    assert cortex_cli.main(["runtime", "install", "--profile", "claude", "--root", str(root)]) == 0
    _ = capsys.readouterr()

    claude_md = root / ".claude" / "CLAUDE.md"
    claude_md.write_text("modified\n", encoding="utf-8")

    rc = cortex_cli.main(["runtime", "install", "--profile", "claude", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    result = json.loads(out)
    assert str(claude_md) in result["skipped"]
    assert claude_md.read_text(encoding="utf-8") == "modified\n"

    rc = cortex_cli.main(
        ["runtime", "install", "--profile", "claude", "--root", str(root), "--force"]
    )
    out = capsys.readouterr().out
    assert rc == 0
    result = json.loads(out)
    assert str(claude_md) in result["overwritten"]
    assert "Cortex Runtime Instructions (Claude Code)" in claude_md.read_text(encoding="utf-8")


def test_init_and_check_write_only_under_explicit_root(
    tmp_path: Path, capsys, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _tree_paths(base: Path) -> set[str]:
        return {path.relative_to(base).as_posix() for path in base.rglob("*")}

    workspace = tmp_path / "workspace"
    workspace.mkdir()
    root = tmp_path / "target-project"
    before = _tree_paths(tmp_path)
    monkeypatch.chdir(workspace)

    _bootstrap_runtime_project(root, capsys)
    assert cortex_cli.main(["check", "--root", str(root), "--write-status"]) == 0
    _ = capsys.readouterr()
    created = _tree_paths(tmp_path) - before

    for rel in ("cortex.toml", ".cortex/cortex.db", ".cortex/status.json", ".claude/settings.json"):
        assert (root / rel).exists()
    assert created
    assert all((tmp_path / rel).is_relative_to(root) for rel in created)


def test_check_reports_human_readable_summary(tmp_path: Path, capsys) -> None:
    root = tmp_path / "checked-project"
    _bootstrap_runtime_project(root, capsys)

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Cortex Check:" in out
    assert "OK:" in out
    assert "Needs Attention:" in out
    assert "Missing / Errors:" in out
    assert "Config parsed:" in out
    assert "Database ready:" in out
    assert "Runtime profile wiring found" in out
    assert "Repo-map is disabled in cortex.toml" in out


def test_check_warns_when_host_pytest_bin_missing_but_module_fallback_available(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    root = tmp_path / "host-mode-fallback-project"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    text = text.replace('trust_profile = "untrusted"', 'trust_profile = "trusted"', 1)
    text = text.replace('execution_mode = "container"', 'execution_mode = "host"', 1)
    cfg_path.write_text(text, encoding="utf-8")

    monkeypatch.setattr(cortex_cli.shutil, "which", lambda _name: None)
    monkeypatch.setattr(cortex_cli.importlib.util, "find_spec", lambda name: object() if name == "pytest" else None)

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "invariants.pytest_bin='pytest' is unavailable; host mode will fallback to 'python -m pytest'" in out


def test_check_errors_when_host_pytest_is_unavailable(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    root = tmp_path / "host-mode-no-pytest-project"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    text = text.replace('trust_profile = "untrusted"', 'trust_profile = "trusted"', 1)
    text = text.replace('execution_mode = "container"', 'execution_mode = "host"', 1)
    cfg_path.write_text(text, encoding="utf-8")

    monkeypatch.setattr(cortex_cli.shutil, "which", lambda _name: None)
    monkeypatch.setattr(cortex_cli.importlib.util, "find_spec", lambda _name: None)

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "invariants.execution_mode='host' but pytest is unavailable" in out


def test_check_warns_on_db_schema_version_mismatch(tmp_path: Path, capsys) -> None:
    root = tmp_path / "schema-mismatch-project"
    _bootstrap_runtime_project(root, capsys)

    # Simulate older metadata version while tables are still present.
    store = SQLiteStore(root / ".cortex" / "cortex.db")
    with store.connection() as conn:
        conn.execute("PRAGMA user_version = 0")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Database schema version mismatch: found 0, expected 2" in out


def test_check_json_and_status_artifact(tmp_path: Path, capsys) -> None:
    root = tmp_path / "checked-project-json"
    _bootstrap_runtime_project(root, capsys)

    rc = cortex_cli.main(["check", "--root", str(root), "--json", "--write-status"])
    out = capsys.readouterr().out
    assert rc == 0
    report = json.loads(out)
    assert report["status"] == "ok"
    assert report["summary"]["errors"] == 0
    assert report["cortex_version"]
    assert report["config_schema_version"] == "cortex_toml_v1"
    assert report["db"]["expected_schema_version"] == 2
    assert report["hooks"]["valid"] is True
    assert report["packs"]["temporal_protocol"]["phase_gate_patterns"] == []
    assert report["status_artifact"] == str(root / ".cortex" / "status.json")
    status_data = json.loads((root / ".cortex" / "status.json").read_text(encoding="utf-8"))
    assert status_data["root"] == str(root)


@pytest.mark.parametrize("profile", ["claude", "gemini", "openai"])
def test_adapter_validation_harness_bootstrap_supports_strict_check_json(
    tmp_path: Path,
    capsys,
    monkeypatch: pytest.MonkeyPatch,
    profile: str,
) -> None:
    root = tmp_path / f"adapter-validation-{profile}"
    _mock_check_binaries(monkeypatch, include_codex=(profile == "openai"))

    _bootstrap_adapter_validation_project(root, capsys, profile=profile)

    rc = cortex_cli.main(["check", "--root", str(root), "--json", "--write-status"])
    report = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert report["status"] == "ok"
    assert report["summary"]["errors"] == 0
    assert report["runtime"]["profile"] == profile
    assert report["runtime"]["adapter_valid"] is True
    assert report["hooks"]["valid"] is True
    assert report["repomap"]["enabled"] is True
    assert report["repomap"]["prefer_ast_graph"] is False
    assert report["repomap"]["artifact_exists"] is True
    assert report["warnings"] == [HOST_EXECUTION_WARNING]
    assert report["status_artifact"] == str(root / ".cortex" / "status.json")
    assert (root / ".git").exists()

    cfg_text = (root / "cortex.toml").read_text(encoding="utf-8")
    assert 'trust_profile = "trusted"' in cfg_text
    assert 'execution_mode = "host"' in cfg_text
    assert "repomap.enabled" not in cfg_text
    assert "enabled = true" in cfg_text
    assert "prefer_ast_graph = false" in cfg_text
    assert 'mode = "strict"' in cfg_text
    assert "fail_on_missing_challenge_coverage = true" in cfg_text
    assert "require_requirement_audit = true" in cfg_text
    assert "fail_on_requirement_audit_gap = true" in cfg_text


def test_adapter_validation_evidence_helper_writes_sanitized_bundle(
    tmp_path: Path,
    capsys,
) -> None:
    root = tmp_path / "adapter-validation-evidence-project"
    _bootstrap_adapter_validation_project(root, capsys, profile="claude")
    store = SQLiteStore(root / ".cortex" / "cortex.db")
    store.record_event(
        "sess-raw",
        "PreToolUse",
        {
            "path": str(root / "src" / "normalize_port.py"),
            "transcript_path": "/Users/example/.claude/projects/sess-raw.jsonl",
            "listing": f"owner {os.environ.get('USER', 'local-user')}",
        },
        tool_name="Read",
    )
    store.record_event(
        "sess-raw",
        "Stop",
        {"result": "pass", "workspace_root": str(root)},
        status="pass",
    )

    session_events_path = tmp_path / "session-events.json"
    status_path = root / ".cortex" / "status.json"
    metadata_path = tmp_path / "metadata.json"
    output_dir = tmp_path / "adapter-validation-output" / "claude"

    assert cortex_cli.main(
        ["session-events", "--root", str(root), "--session-id", "sess-raw", "--json"]
    ) == 0
    session_events_path.write_text(capsys.readouterr().out, encoding="utf-8")

    assert cortex_cli.main(["check", "--root", str(root), "--json", "--write-status"]) == 0
    _ = json.loads(capsys.readouterr().out)

    metadata = {
        "adapter": "claude",
        "scenario": "pass_minimal",
        "result": "pass",
        "runtime": {
            "profile": "claude",
            "surface": "claude-code-hooks",
            "adapter_path": "cortex.adapters.claude:ClaudeAdapter",
            "runtime_version": "claude-code test",
            "schema_pin": "claude_native_v1",
            "model": "claude-test-model",
        },
        "environment": {
            "os": "darwin",
            "python_version": f"{sys.version_info.major}.{sys.version_info.minor}",
            "cortex_version": cortex_cli.__version__,
            "execution_mode": "host",
            "fresh_venv": True,
            "git_initialized": True,
            "project_label": "project_a",
            "project_root": str(root),
        },
        "commands": {
            "install": ["python -m pip install . pytest"],
            "init": ["cortex init --root project_a"],
            "runtime_install": ["cortex runtime install --profile claude --root project_a"],
            "check": ["cortex check --json --write-status --root project_a"],
            "invoke": ["claude --print"],
            "test": ["python -m pytest -q tests/test_normalize_port.py"],
        },
        "observed": {
            "exit_codes": {"check": 0, "invoke": 0},
            "session_id": "sess-raw",
            "session_id_label": "claude-pass_minimal-session",
            "hook_sequence": [],
            "session_status": "completed",
            "enforcement_pass": True,
            "proceed": True,
            "stop_fields_source": "native",
            "stop_fields_parse_error": "",
            "structured_stop_violation": False,
            "challenge_coverage_missing": False,
            "requirement_audit_gap": False,
            "truth_claims_gap": False,
            "requirements_gate_gap": False,
            "coverage_gaps": [],
            "warnings": [HOST_EXECUTION_WARNING],
        },
        "artifacts": {
            "prompt_template": "tests/fixtures/adapter_validation/prompts/pass_minimal.md",
            "raw_capture_sha256": "a" * 64,
        },
        "provenance": {
            "source": "synthetic",
            "captured_at_utc": "2026-03-06T00:00:00Z",
            "captured_with": {
                "cli": f"cortex {cortex_cli.__version__}",
                "model": "claude-test-model",
            },
            "sanitized_fields": ["session_id", "root", "path"],
            "operator_notes": "synthetic smoke coverage for helper script",
        },
    }
    metadata_path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    run = subprocess.run(
        [
            sys.executable,
            str(REPO_ROOT / "scripts" / "adapter_validation_evidence.py"),
            "--metadata",
            str(metadata_path),
            "--session-events",
            str(session_events_path),
            "--status-artifact",
            str(status_path),
            "--output-dir",
            str(output_dir),
            "--project-root",
            str(root),
        ],
        capture_output=True,
        text=True,
        check=False,
    )

    if run.returncode != 0:
        pytest.fail(f"adapter_validation_evidence.py failed: stdout={run.stdout!r} stderr={run.stderr!r}")

    result = json.loads(run.stdout)
    assert result["ok"] is True
    assert sorted(result["artifacts"]) == [
        "pass_minimal.json",
        "pass_minimal.session_events.json",
        "pass_minimal.status.json",
    ]

    evidence = json.loads((output_dir / "pass_minimal.json").read_text(encoding="utf-8"))
    events = json.loads((output_dir / "pass_minimal.session_events.json").read_text(encoding="utf-8"))
    status_payload = json.loads((output_dir / "pass_minimal.status.json").read_text(encoding="utf-8"))
    provenance = json.loads((output_dir / "PROVENANCE.json").read_text(encoding="utf-8"))

    assert evidence["schema_version"] == "adapter_validation_evidence_v1"
    assert evidence["observed"]["hook_sequence"] == ["PreToolUse", "Stop"]
    assert evidence["artifacts"]["session_events"] == "pass_minimal.session_events.json"
    assert evidence["artifacts"]["status_artifact"] == "pass_minimal.status.json"
    assert events["session_id"] == "claude-pass_minimal-session"
    assert events["events"][0]["payload"]["path"] == "project_a/src/normalize_port.py"
    assert events["events"][0]["payload"]["transcript_path"] == "local_artifact/claude-pass_minimal-session.jsonl"
    assert events["events"][0]["payload"]["listing"] == "owner local_operator"
    assert status_payload["root"] == "project_a"
    assert provenance["schema_version"] == "adapter_validation_fixture_provenance_v1"
    assert set(provenance["artifacts"]) == {
        "pass_minimal.json",
        "pass_minimal.session_events.json",
        "pass_minimal.status.json",
    }


def test_adapter_validation_project_template_contains_real_fail_then_pass_task(tmp_path: Path) -> None:
    root = tmp_path / "adapter-validation-template"
    adapter_validation.copy_project_template(repo_root=REPO_ROOT, root=root)

    failing = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "tests/test_normalize_port.py"],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert failing.returncode != 0
    assert "test_accepts_upper_bound_port" in failing.stdout

    target = root / "src" / "normalize_port.py"
    target.write_text(
        target.read_text(encoding="utf-8").replace("if port >= 65535:", "if port > 65535:", 1),
        encoding="utf-8",
    )

    passing = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "tests/test_normalize_port.py"],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert passing.returncode == 0, passing.stdout + passing.stderr
    assert "2 passed" in passing.stdout


def test_adapter_validation_evidence_helper_rejects_unknown_scenario(tmp_path: Path) -> None:
    metadata = {
        "adapter": "claude",
        "scenario": "unknown_lane",
        "result": "pass",
        "runtime": {
            "profile": "claude",
            "surface": "claude-code-hooks",
            "adapter_path": "cortex.adapters.claude:ClaudeAdapter",
            "runtime_version": "test-runtime",
            "schema_pin": "claude_native_v1",
            "model": "claude-test-model",
        },
        "environment": {
            "os": "darwin",
            "python_version": "3.13",
            "cortex_version": cortex_cli.__version__,
            "execution_mode": "host",
            "fresh_venv": True,
            "git_initialized": True,
            "project_label": "project_a",
        },
        "commands": {
            "install": [],
            "init": [],
            "runtime_install": [],
            "check": [],
            "invoke": [],
            "test": [],
        },
        "observed": {
            "exit_codes": {},
            "session_id_label": "claude-session",
            "session_status": "completed",
            "enforcement_pass": True,
            "proceed": True,
            "stop_fields_source": "native",
            "stop_fields_parse_error": "",
            "structured_stop_violation": False,
            "challenge_coverage_missing": False,
            "requirement_audit_gap": False,
            "truth_claims_gap": False,
            "requirements_gate_gap": False,
            "coverage_gaps": [],
            "warnings": [],
            "hook_sequence": [],
        },
        "artifacts": {
            "prompt_template": str(adapter_validation.prompt_path(REPO_ROOT, "pass_minimal")),
            "raw_capture_sha256": "a" * 64,
        },
        "provenance": {
            "source": "synthetic",
            "captured_at_utc": "2026-03-07T00:00:00Z",
            "captured_with": {"cli": f"cortex {cortex_cli.__version__}", "model": "claude-test-model"},
            "sanitized_fields": [],
            "operator_notes": "negative coverage for scenario validation",
        },
    }
    metadata_path = tmp_path / "metadata.json"
    session_events_path = tmp_path / "session_events.json"
    status_path = tmp_path / "status.json"
    output_dir = tmp_path / "output" / "claude"

    metadata_path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    session_events_path.write_text('{"session_id":"raw","events":[]}\n', encoding="utf-8")
    status_path.write_text('{"root":"project_a"}\n', encoding="utf-8")

    run = subprocess.run(
        [
            sys.executable,
            str(REPO_ROOT / "scripts" / "adapter_validation_evidence.py"),
            "--metadata",
            str(metadata_path),
            "--session-events",
            str(session_events_path),
            "--status-artifact",
            str(status_path),
            "--output-dir",
            str(output_dir),
        ],
        capture_output=True,
        text=True,
        check=False,
    )

    assert run.returncode != 0
    assert "metadata.scenario must be one of" in run.stderr


def test_check_json_reports_pack_temporal_protocol_patterns(tmp_path: Path, capsys) -> None:
    root = tmp_path / "checked-project-pack-temporal"
    _bootstrap_runtime_project(root, capsys)
    pack_dir = root / "packs"
    pack_dir.mkdir(parents=True, exist_ok=True)
    (pack_dir / "temporal.toml").write_text(
        "\n".join(
            [
                'schema = "cortex_pack_v1"',
                'pack_id = "temporal_test"',
                'challenge_categories = ["x"]',
                "[temporal_protocol]",
                'phase_gate_pattern = "^phase_gate$"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    cfg_path = root / "cortex.toml"
    cfg_path.write_text(cfg_path.read_text(encoding="utf-8") + "\n[packs]\npaths = [\"packs/temporal.toml\"]\n", encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root), "--json"])
    report = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert report["packs"]["temporal_protocol"]["phase_gate_patterns"] == ["^phase_gate$"]


def test_show_genome_includes_pack_temporal_protocol_summary(tmp_path: Path, capsys) -> None:
    root = tmp_path / "show-genome-pack-temporal"
    _bootstrap_runtime_project(root, capsys)
    pack_dir = root / "packs"
    pack_dir.mkdir(parents=True, exist_ok=True)
    (pack_dir / "temporal.toml").write_text(
        "\n".join(
            [
                'schema = "cortex_pack_v1"',
                'pack_id = "temporal_test"',
                'challenge_categories = ["x"]',
                "[temporal_protocol]",
                'phase_gate_pattern = "^audit_complete$"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    cfg_path = root / "cortex.toml"
    cfg_path.write_text(cfg_path.read_text(encoding="utf-8") + "\n[packs]\npaths = [\"packs/temporal.toml\"]\n", encoding="utf-8")

    rc = cortex_cli.main(["show-genome", "--root", str(root)])
    payload = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert payload["pack_temporal_protocol"]["phase_gate_patterns"] == ["^audit_complete$"]


def test_check_kernel_metrics_json_is_non_gating(tmp_path: Path, capsys) -> None:
    root = tmp_path / "checked-project-metrics"
    _bootstrap_runtime_project(root, capsys)

    rc = cortex_cli.main(["check", "--root", str(root), "--json", "--kernel-metrics"])
    out = capsys.readouterr().out
    assert rc == 0
    report = json.loads(out)
    assert report["status"] == "ok"
    metrics = report["kernel_metrics"]
    assert metrics["gating"] == "non_blocking"
    current = metrics["current"]
    assert current["scope"] == "stop_path"
    assert current["trend_target"] == "down_or_equal_without_reliability_loss"
    totals = current["totals"]
    assert totals["loc_total"] > 0
    assert totals["functions"] > 0
    assert totals["decision_points"] > 0
    assert "stop_contract" in current["modules"]


def test_check_kernel_metrics_baseline_write_and_compare(tmp_path: Path, capsys) -> None:
    root = tmp_path / "checked-project-metrics-baseline"
    baseline_path = root / ".cortex" / "kernel_metrics_baseline.json"
    _bootstrap_runtime_project(root, capsys)

    rc = cortex_cli.main(
        [
            "check",
            "--root",
            str(root),
            "--json",
            "--kernel-metrics",
            "--write-kernel-metrics-baseline",
            str(baseline_path),
        ]
    )
    out = capsys.readouterr().out
    assert rc == 0
    report = json.loads(out)
    assert report["kernel_metrics"]["baseline_written"] == str(baseline_path.resolve())
    assert baseline_path.exists()

    rc = cortex_cli.main(
        [
            "check",
            "--root",
            str(root),
            "--json",
            "--kernel-metrics",
            "--kernel-metrics-baseline",
            str(baseline_path),
        ]
    )
    out = capsys.readouterr().out
    assert rc == 0
    report = json.loads(out)
    metrics = report["kernel_metrics"]
    assert metrics["gating"] == "non_blocking"
    assert "baseline" in metrics
    assert "diff" in metrics
    assert set(metrics["diff"]["totals"]) == {"loc_total", "loc_code", "functions", "decision_points"}


def test_check_kernel_metrics_baseline_write_blocked_outside_root(tmp_path: Path, capsys) -> None:
    root = tmp_path / "checked-project-metrics-baseline-block"
    baseline_path = tmp_path / "kernel_metrics_baseline.json"
    _bootstrap_runtime_project(root, capsys)

    rc = cortex_cli.main(
        [
            "check",
            "--root",
            str(root),
            "--json",
            "--kernel-metrics",
            "--write-kernel-metrics-baseline",
            str(baseline_path),
        ]
    )
    out = capsys.readouterr().out
    assert rc == 0
    report = json.loads(out)
    assert "baseline_written" not in report["kernel_metrics"]
    assert not baseline_path.exists()
    assert any("path must stay under --root" in warning for warning in report["warnings"])


def test_check_accepts_legacy_claude_settings_location(tmp_path: Path, capsys) -> None:
    root = tmp_path / "legacy-claude-project"
    _bootstrap_runtime_project(root, capsys)

    preferred_dir = root / ".claude"
    legacy_dir = root / "claude"
    legacy_dir.mkdir(parents=True)
    (legacy_dir / "settings.json").write_text(
        (preferred_dir / "settings.json").read_text(encoding="utf-8"), encoding="utf-8"
    )
    (legacy_dir / "CLAUDE.md").write_text(
        (preferred_dir / "CLAUDE.md").read_text(encoding="utf-8"), encoding="utf-8"
    )
    (preferred_dir / "settings.json").unlink()
    (preferred_dir / "CLAUDE.md").unlink()
    preferred_dir.rmdir()

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert f"Runtime profile wiring found in {legacy_dir / 'settings.json'}" in out


def test_check_warns_when_repomap_enabled_missing_deps(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    root = tmp_path / "repomap-check-project"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    before, after = text.split("[repomap]\n", 1)
    after = after.replace("enabled = false", "enabled = true", 1)
    cfg_path.write_text(before + "[repomap]\n" + after, encoding="utf-8")

    monkeypatch.setattr(
        cortex_cli, "_repomap_dependency_status", lambda: ["networkx"]
    )
    monkeypatch.setattr(cortex_cli, "_repomap_parser_dependency_status", lambda: [])

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Repo-map enabled; optional ranking dependencies missing" in out
    assert "AST graph + lightweight fallback remain available" in out
    assert "networkx" in out
    assert "Repo-map artifact missing (warning only): .cortex/artifacts/repomap/latest.json" in out


def test_check_warns_when_repomap_parser_deps_missing(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    root = tmp_path / "repomap-parser-missing-project"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    before, after = text.split("[repomap]\n", 1)
    after = after.replace("enabled = false", "enabled = true", 1)
    cfg_path.write_text(before + "[repomap]\n" + after, encoding="utf-8")

    monkeypatch.setattr(cortex_cli, "_repomap_dependency_status", lambda: [])
    monkeypatch.setattr(
        cortex_cli,
        "_repomap_parser_dependency_status",
        lambda: ["tree-sitter", "tree-sitter-language-pack"],
    )

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Repo-map tree-sitter parser dependencies missing:" in out
    assert "tree-sitter, tree-sitter-language-pack" in out


def test_check_warns_when_parity_profile_enabled_without_parser_deps(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    root = tmp_path / "repomap-parity-warning-project"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    before, after = text.split("[repomap]\n", 1)
    after = after.replace("enabled = false", "enabled = true", 1)
    after = after.replace("parity_profile = false", "parity_profile = true", 1)
    cfg_path.write_text(before + "[repomap]\n" + after, encoding="utf-8")

    monkeypatch.setattr(cortex_cli, "_repomap_dependency_status", lambda: [])
    monkeypatch.setattr(
        cortex_cli,
        "_repomap_parser_dependency_status",
        lambda: ["tree-sitter"],
    )

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Repo-map parity profile is enabled but parser dependencies are missing" in out


def test_check_warns_when_challenge_coverage_gate_is_non_blocking(tmp_path: Path, capsys) -> None:
    root = tmp_path / "advisory-coverage-project"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    text = text.replace("fail_on_missing_challenge_coverage = false", "fail_on_missing_challenge_coverage = true", 1)
    cfg_path.write_text(text, encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "hooks.fail_on_missing_challenge_coverage=true has no blocking effect while hooks.mode='advisory'" in out
    assert "set [hooks].mode='strict' to enforce missing challenge coverage as a real gate" in out


def test_check_warns_when_structured_stop_required_but_message_fallback_enabled(
    tmp_path: Path, capsys
) -> None:
    root = tmp_path / "structured-stop-warning-project"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    text = text.replace("allow_message_stop_fallback = false", "allow_message_stop_fallback = true", 1)
    cfg_path.write_text(text, encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "hooks.require_structured_stop_payload=true while hooks.allow_message_stop_fallback=true" in out


def test_check_warns_when_container_mode_engine_missing(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    root = tmp_path / "container-mode-missing-engine"
    _bootstrap_runtime_project(root, capsys)
    cfg_path = root / "cortex.toml"
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8")
        .replace('trust_profile = "trusted"', 'trust_profile = "untrusted"', 1)
        .replace('execution_mode = "host"', 'execution_mode = "container"', 1),
        encoding="utf-8",
    )
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8").replace('container_engine = "python3"', 'container_engine = "docker"', 1),
        encoding="utf-8",
    )

    monkeypatch.setattr(cortex_cli.shutil, "which", lambda _name: None)

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "invariants.execution_mode='container' but container engine 'docker' is not on PATH" in out
    assert "switch to execution_mode='host'" in out


def test_check_warns_when_trusted_container_mode_engine_missing(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    root = tmp_path / "trusted-container-mode-missing-engine"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8")
        .replace('execution_mode = "host"', 'execution_mode = "container"', 1)
        .replace('container_engine = "python3"', 'container_engine = "docker"', 1),
        encoding="utf-8",
    )

    monkeypatch.setattr(cortex_cli.shutil, "which", lambda _name: None)

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "invariants.execution_mode='container' but container engine 'docker' is not on PATH" in out


def test_check_reports_container_mode_engine_available(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    root = tmp_path / "container-mode-engine-ok"
    _bootstrap_runtime_project(root, capsys)
    cfg_path = root / "cortex.toml"
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8")
        .replace('trust_profile = "trusted"', 'trust_profile = "untrusted"', 1)
        .replace('execution_mode = "host"', 'execution_mode = "container"', 1)
        .replace('container_engine = "python3"', 'container_engine = "docker"', 1),
        encoding="utf-8",
    )

    monkeypatch.setattr(cortex_cli.shutil, "which", lambda _name: "/usr/local/bin/docker")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Invariant container engine available: docker" in out
    assert "container engine 'docker' is not on PATH" not in out


def test_check_errors_when_untrusted_profile_uses_host_execution_mode(
    tmp_path: Path, capsys
) -> None:
    root = tmp_path / "untrusted-host-blocked"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    text = text.replace('trust_profile = "trusted"', 'trust_profile = "untrusted"', 1)
    cfg_path.write_text(text, encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "invariants.execution_mode='host' is blocked when project.trust_profile='untrusted'" in out


def test_check_errors_when_trust_profile_is_invalid(tmp_path: Path, capsys) -> None:
    root = tmp_path / "invalid-trust-profile"
    _bootstrap_runtime_project(root, capsys)

    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    text = text.replace('trust_profile = "trusted"', 'trust_profile = "oops"', 1)
    cfg_path.write_text(text, encoding="utf-8")

    rc = cortex_cli.main(["check", "--root", str(root)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "project.trust_profile must be 'trusted' or 'untrusted'" in out
    assert "invariants.execution_mode='host' is blocked when project.trust_profile='untrusted'" in out


def test_repomap_cli_emits_artifact_json(tmp_path: Path, capsys) -> None:
    root = tmp_path / "repomap-cli-project"
    _bootstrap_runtime_project(root, capsys)

    (root / "src").mkdir()
    (root / "src" / "app.py").write_text("def main():\n    return 1\n", encoding="utf-8")

    rc = cortex_cli.main(
        [
            "repomap",
            "--root",
            str(root),
            "--json",
            "--scope",
            "src",
            "--focus-file",
            "src/app.py",
            "--max-files",
            "7",
            "--max-text-bytes",
            "2048",
        ]
    )
    out = capsys.readouterr().out
    assert rc == 0
    result = json.loads(out)
    assert result["ok"] is True
    assert result["schema_version"] == "repomap_artifact_v1"
    assert "status" not in result
    assert "requested" not in result
    assert "repomap" not in result
    assert "artifact_path" not in result
    assert result["provenance"]["scope"] == ["src"]
    assert result["provenance"]["focus_files"] == ["src/app.py"]
    assert result["provenance"]["timeout_ms"] is None
    assert result["ranking"][0]["path"] == "src/app.py"


def test_repomap_cli_debug_json_emits_wrapper_metadata(tmp_path: Path, capsys) -> None:
    root = tmp_path / "repomap-cli-debug-project"
    _bootstrap_runtime_project(root, capsys)

    (root / "src").mkdir()
    (root / "src" / "app.py").write_text("def main():\n    return 1\n", encoding="utf-8")

    rc = cortex_cli.main(
        [
            "repomap",
            "--root",
            str(root),
            "--debug-json",
            "--scope",
            "src",
            "--focus-file",
            "src/app.py",
            "--max-files",
            "7",
            "--max-text-bytes",
            "2048",
            "--timeout-ms",
            "0",
        ]
    )
    out = capsys.readouterr().out
    assert rc == 1
    result = json.loads(out)
    assert result["ok"] is False
    assert result["status"] == "error"
    assert result["schema_version"] == "repomap_artifact_v1"
    assert result["repomap"]["enabled"] is False
    assert result["requested"]["scope"] == ["src"]
    assert result["requested"]["focus_files"] == ["src/app.py"]
    assert result["requested"]["max_files"] == 7
    assert result["requested"]["max_text_bytes"] == 2048
    assert result["requested"]["timeout_ms"] == 0
    assert result["requested"]["parity_profile"] is False
    assert result["error"]["code"] == "timeout"


def test_repomap_cli_parity_profile_fails_without_parser_deps(
    tmp_path: Path, capsys, monkeypatch
) -> None:
    root = tmp_path / "repomap-cli-parity-project"
    _bootstrap_runtime_project(root, capsys)

    (root / "src").mkdir()
    (root / "src" / "app.ts").write_text("export function app() {}\n", encoding="utf-8")
    monkeypatch.setattr(
        "cortex.repomap.repomap_missing_parser_dependencies",
        lambda: ["tree-sitter", "tree-sitter-language-pack"],
    )

    rc = cortex_cli.main(
        [
            "repomap",
            "--root",
            str(root),
            "--json",
            "--scope",
            "src",
            "--parity-profile",
        ]
    )
    out = capsys.readouterr().out
    assert rc == 1
    result = json.loads(out)
    assert result["ok"] is False
    assert result["error"]["code"] == "deps_missing"
    assert result["provenance"]["parser_profile"] == "parity"
    assert result["provenance"]["parser_deps_missing"] == [
        "tree-sitter",
        "tree-sitter-language-pack",
    ]


def test_graveyard_lists_entries_human_readable(tmp_path: Path, capsys) -> None:
    root = tmp_path / "graveyard-project"
    _bootstrap_runtime_project(root, capsys)

    store = SQLiteStore(root / ".cortex" / "cortex.db")
    store.insert_graveyard(
        session_id="sess-1",
        summary="Tried virtualized list",
        reason="Sticky header regression",
        files=["src/list.py"],
        keywords=["virtualized", "sticky", "header"],
    )

    rc = cortex_cli.main(["graveyard", "--root", str(root), "--limit", "5"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Cortex Graveyard" in out
    assert "Tried virtualized list" in out
    assert "Sticky header regression" in out
    assert "src/list.py" in out


def test_session_events_returns_ordered_json_and_hook_filter(tmp_path: Path, capsys) -> None:
    root = tmp_path / "session-events-project"
    _bootstrap_runtime_project(root, capsys)
    store = SQLiteStore(root / ".cortex" / "cortex.db")
    store.record_event("sess-evt", "SessionStart", {"objective": "x"})
    store.record_event("sess-evt", "SessionMarker", {"label": "audit_complete"})
    store.record_event("sess-evt", "PostToolUse", {"changed_files": ["src/x.py"]}, tool_name="Edit", status="ok")

    rc = cortex_cli.main(
        [
            "session-events",
            "--root",
            str(root),
            "--session-id",
            "sess-evt",
            "--hooks",
            "SessionMarker",
            "PostToolUse",
            "--json",
        ]
    )
    out = capsys.readouterr().out
    assert rc == 0
    payload = json.loads(out)
    assert payload["ok"] is True
    assert payload["session_id"] == "sess-evt"
    assert [event["hook"] for event in payload["events"]] == ["SessionMarker", "PostToolUse"]
    assert payload["events"][0]["payload"] == {"label": "audit_complete"}
    assert payload["events"][1]["payload"] == {"changed_files": ["src/x.py"]}
    assert payload["events"][1]["tool_name"] == "Edit"
    assert payload["events"][1]["status"] == "ok"


def test_session_events_is_session_scoped_under_multiple_sessions(tmp_path: Path, capsys) -> None:
    root = tmp_path / "session-events-concurrency-project"
    _bootstrap_runtime_project(root, capsys)
    store = SQLiteStore(root / ".cortex" / "cortex.db")
    store.record_event("sess-a", "SessionMarker", {"label": "audit_complete"})
    store.record_event("sess-b", "SessionMarker", {"label": "phase_1_delivered"})
    store.record_event("sess-b", "PostToolUse", {"changed_files": ["src/b.py"]}, tool_name="Edit", status="ok")

    rc = cortex_cli.main(
        ["session-events", "--root", str(root), "--session-id", "sess-b", "--hooks", "SessionMarker", "PostToolUse", "--json"]
    )
    payload = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert payload["session_id"] == "sess-b"
    assert len(payload["events"]) == 2
    assert payload["events"][0]["payload"]["label"] == "phase_1_delivered"
    assert payload["events"][1]["payload"]["changed_files"] == ["src/b.py"]


def test_session_events_errors_when_db_missing(tmp_path: Path, capsys) -> None:
    root = tmp_path / "session-events-missing-db"
    root.mkdir(parents=True)
    rc = cortex_cli.main(["session-events", "--root", str(root), "--session-id", "sess-evt", "--json"])
    captured = capsys.readouterr()
    assert rc == 1
    payload = json.loads(captured.err)
    assert payload["ok"] is False
    assert "Missing database file" in payload["error"]


def test_fleet_status_reports_multiple_projects(tmp_path: Path, capsys) -> None:
    ok_root = tmp_path / "fleet-ok"
    err_root = tmp_path / "fleet-err"
    _bootstrap_runtime_project(ok_root, capsys)
    err_root.mkdir(parents=True)

    rc = cortex_cli.main(
        [
            "fleet",
            "status",
            "--roots",
            str(ok_root),
            str(err_root),
            "--json",
        ]
    )
    out = capsys.readouterr().out
    payload = json.loads(out)
    assert rc == 1
    assert payload["summary"]["projects"] == 2
    assert payload["summary"]["error_projects"] == 1
    assert len(payload["projects"]) == 2
    by_root = {item["root"]: item for item in payload["projects"]}
    assert by_root[str(ok_root)]["summary"]["errors"] == 0
    assert by_root[str(err_root)]["summary"]["errors"] > 0
