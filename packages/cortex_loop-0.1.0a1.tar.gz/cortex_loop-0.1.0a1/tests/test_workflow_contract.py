from __future__ import annotations

import importlib.util
import stat
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def _load_repo_hygiene_module():
    script = ROOT / "scripts" / "repo_workflow.py"
    sys.path.insert(0, str(script.parent))
    spec = importlib.util.spec_from_file_location("repo_workflow", script)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_commit_subject_contract_accepts_good_subject() -> None:
    module = _load_repo_hygiene_module()
    assert module.validate_commit_subject("docs: tighten workflow wording") is None


def test_commit_subject_contract_rejects_process_narration() -> None:
    module = _load_repo_hygiene_module()
    assert module.validate_commit_subject("docs: final polish for readme") is not None


def test_branch_contract_accepts_only_allowed_prefixes() -> None:
    module = _load_repo_hygiene_module()
    assert module.validate_branch_name("main") is None
    assert module.validate_branch_name("codex/example-task") is None
    assert module.validate_branch_name("claude/example-task") is None
    assert module.validate_branch_name("maint/example-task") is None
    assert module.validate_branch_name("feature/example-task") is not None


def test_managed_session_branch_contract_is_explicit() -> None:
    module = _load_repo_hygiene_module()
    assert module.is_managed_session_branch("codex/20260306-123456-session") is True
    assert module.is_managed_session_branch("codex/example-task") is False


def test_repo_hygiene_doc_is_indexed_in_workflow_surfaces() -> None:
    assert (ROOT / "REPO_WORKFLOW.md").exists()
    assert "REPO_WORKFLOW.md" in (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    assert "REPO_WORKFLOW.md" in (ROOT / "CONTRIBUTING.md").read_text(encoding="utf-8")
    assert "[../REPO_WORKFLOW.md](../REPO_WORKFLOW.md)" in (ROOT / "docs" / "README.md").read_text(encoding="utf-8")
    assert "REPO_WORKFLOW.md" in (ROOT / ".github" / "PULL_REQUEST_TEMPLATE.md").read_text(encoding="utf-8")


def test_hooks_call_repo_hygiene_script_and_are_executable() -> None:
    hooks = {
        "commit-msg": "lint-commit-msg",
        "pre-push": "check",
    }
    for name, token in hooks.items():
        path = ROOT / ".githooks" / name
        text = path.read_text(encoding="utf-8")
        assert "scripts/repo_workflow.py" in text
        assert token in text
        mode = path.stat().st_mode
        assert mode & stat.S_IXUSR


def test_ci_uses_repo_hygiene_check_phases() -> None:
    workflow = (ROOT / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")
    for phase in ("hygiene", "test-lint", "package"):
        assert f"python scripts/repo_workflow.py check --phase {phase}" in workflow
    assert not (ROOT / ".github" / "workflows" / "package-check.yml").exists()


def test_workflow_surfaces_reference_start_and_close_session() -> None:
    repo_hygiene = (ROOT / "REPO_WORKFLOW.md").read_text(encoding="utf-8")
    agents = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    contributing = (ROOT / "CONTRIBUTING.md").read_text(encoding="utf-8")
    pr_template = (ROOT / ".github" / "PULL_REQUEST_TEMPLATE.md").read_text(encoding="utf-8")
    for text in (repo_hygiene, agents, contributing):
        assert "start-session" in text
        assert "close-session" in text
    assert "close-session" in pr_template


def test_package_phase_uses_local_no_isolation_build() -> None:
    module = _load_repo_hygiene_module()
    assert module._phase_commands("package") == [[sys.executable, "-m", "build", "--no-isolation"]]


def test_workflow_docs_explain_review_branch_finalize_exception() -> None:
    repo_hygiene = (ROOT / "REPO_WORKFLOW.md").read_text(encoding="utf-8")
    agents = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    contributing = (ROOT / "CONTRIBUTING.md").read_text(encoding="utf-8")
    pr_template = (ROOT / ".github" / "PULL_REQUEST_TEMPLATE.md").read_text(encoding="utf-8")

    assert "Intentional review/manual branch workflow" in repo_hygiene
    assert "do not run `start-session` or `close-session`" in repo_hygiene
    assert "use `python scripts/repo_workflow.py finalize" in repo_hygiene
    assert "`finalize` refuses managed session branches" in repo_hygiene
    assert "existing non-session review/manual branch" in agents
    assert "use `python scripts/repo_workflow.py finalize" in agents
    assert "intentional review/manual branch work" in contributing
    assert "manual-branch `finalize` exception" in pr_template
    assert "finalize` is not for managed session branches" in pr_template


def test_finalize_rejects_managed_session_branch(monkeypatch: pytest.MonkeyPatch) -> None:
    module = _load_repo_hygiene_module()
    monkeypatch.setattr(module, "_current_branch", lambda: "codex/20260306-123456-session")

    with pytest.raises(SystemExit) as exc_info:
        module.cmd_finalize("docs: tighten workflow wording", None)

    assert "Use close-session for branches created by start-session" in str(exc_info.value)


def test_finalize_accepts_existing_non_session_branch(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    module = _load_repo_hygiene_module()
    monkeypatch.setattr(module, "_current_branch", lambda: "codex/exec-function-evolution-v2")
    monkeypatch.setattr(module, "_finalize_current_branch", lambda message, body_file: "abc123")

    rc = module.cmd_finalize("docs: tighten workflow wording", None)

    assert rc == 0
    assert capsys.readouterr().out.strip() == "codex/exec-function-evolution-v2 abc123"


def test_tracked_adapter_validation_fixture_ignored_dir_is_not_treated_as_local_artifact(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module = _load_repo_hygiene_module()
    monkeypatch.setattr(module, "_root", lambda: ROOT)
    monkeypatch.setattr(
        module.clean_local_artifacts,
        "_tracked_paths",
        lambda _root: {"tests/fixtures/adapter_validation/project_template/.cortex/artifacts/repomap/latest.json"},
    )
    monkeypatch.setattr(
        module,
        "_ignored_status_lines",
        lambda: ["tests/fixtures/adapter_validation/project_template/.cortex/"],
    )

    assert module._disallowed_ignored_entries() == []


def test_agents_doc_blocks_study_lane_as_design_authority() -> None:
    agents = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    assert "Do not treat `eval/study/` as product or kernel design authority unless the task explicitly asks for study verification or study recovery." in agents


def test_pr_template_requires_meaning_surface_updates_for_doctrine_changes() -> None:
    pr_template = (ROOT / ".github" / "PULL_REQUEST_TEMPLATE.md").read_text(encoding="utf-8")
    assert "MISSION.md" in pr_template
    assert "docs/README.md" in pr_template
    assert "docs/ADAPTERS.md" in pr_template


def test_active_docs_do_not_describe_study_lane_split_as_product_behavior() -> None:
    adapters = (ROOT / "docs" / "ADAPTERS.md").read_text(encoding="utf-8")
    assert "Study-lane split:" not in adapters
    assert "direct `codex exec`" not in adapters
