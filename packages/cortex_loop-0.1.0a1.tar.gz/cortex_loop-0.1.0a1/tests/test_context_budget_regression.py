from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from cortex import cli as cortex_cli
from cortex.core import CortexKernel
from cortex.executive import get_base_executive_function, get_identity_preamble


def _approx_tokens(text: str) -> int:
    return max(1, len(text) // 4)


def _init_gemini_runtime(root: Path, capsys) -> None:
    assert cortex_cli.main(["init", "--root", str(root)]) == 0
    _ = capsys.readouterr()
    assert cortex_cli.main(["runtime", "install", "--profile", "gemini", "--root", str(root)]) == 0
    _ = capsys.readouterr()


def _run_bridge(*, root: Path, event: str, payload: dict[str, object]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "cortex_ops_cli.gemini_hooks", event, "--root", str(root)],
        input=json.dumps(payload),
        text=True,
        capture_output=True,
        check=False,
    )


def _parse_stdout_json(proc: subprocess.CompletedProcess[str]) -> dict[str, object]:
    raw = proc.stdout.strip()
    assert raw, f"Expected JSON output but stdout was empty; stderr={proc.stderr!r}"
    data = json.loads(raw)
    assert isinstance(data, dict)
    return data


def test_session_start_context_budget_baseline(tmp_path: Path, capsys) -> None:
    root = tmp_path / "budget-session-start"
    _init_gemini_runtime(root, capsys)

    proc = _run_bridge(
        root=root,
        event="SessionStart",
        payload={
            "session_id": "budget-session-start",
            "hook_event_name": "SessionStart",
            "cwd": str(root),
            "timestamp": "2026-03-05T00:00:00Z",
        },
    )
    assert proc.returncode == 0
    data = _parse_stdout_json(proc)
    additional_context = (
        data.get("hookSpecificOutput", {}).get("additionalContext", "")
        if isinstance(data.get("hookSpecificOutput"), dict)
        else ""
    )
    assert isinstance(additional_context, str)
    assert _approx_tokens(additional_context) <= 1800


def test_before_agent_anchor_budget(tmp_path: Path, capsys) -> None:
    root = tmp_path / "budget-before-agent"
    _init_gemini_runtime(root, capsys)

    proc = _run_bridge(
        root=root,
        event="BeforeAgent",
        payload={
            "session_id": "budget-before-agent",
            "hook_event_name": "BeforeAgent",
            "prompt": "Implement the requested change.",
        },
    )
    assert proc.returncode == 0
    data = _parse_stdout_json(proc)
    additional_context = (
        data.get("hookSpecificOutput", {}).get("additionalContext", "")
        if isinstance(data.get("hookSpecificOutput"), dict)
        else ""
    )
    assert isinstance(additional_context, str)
    assert _approx_tokens(additional_context) <= 140


def test_before_agent_anchor_exact_source_parity(tmp_path: Path, capsys) -> None:
    root = tmp_path / "anchor-parity"
    _init_gemini_runtime(root, capsys)
    _part_a, part_b = get_base_executive_function()

    proc = _run_bridge(
        root=root,
        event="BeforeAgent",
        payload={
            "session_id": "anchor-parity",
            "hook_event_name": "BeforeAgent",
            "prompt": "Continue.",
        },
    )
    assert proc.returncode == 0
    data = _parse_stdout_json(proc)
    assert data["hookSpecificOutput"]["additionalContext"] == part_b


def test_session_start_blocks_order_and_presence(tmp_path: Path, capsys) -> None:
    root = tmp_path / "session-order"
    _init_gemini_runtime(root, capsys)
    kernel = CortexKernel(root=root, config_path=root / "cortex.toml", db_path=root / ".cortex" / "cortex.db")
    part_a, _part_b = get_base_executive_function()
    identity = get_identity_preamble()

    result = kernel.dispatch(
        "session_start",
        {
            "session_id": "session-order",
            "objective": "context block ordering check",
        },
    )
    context_blocks = [item for item in result.get("context_blocks", []) if isinstance(item, str) and item.strip()]
    executive_context = result.get("executive_context") if isinstance(result.get("executive_context"), dict) else {}
    idx = 0
    if executive_context.get("identity_preamble"):
        assert context_blocks[idx] == identity
        idx += 1
    assert context_blocks[idx] == part_a
    idx += 1
    learned = str(executive_context.get("learned") or "").strip()
    if learned:
        assert context_blocks[idx] == learned
        idx += 1
    if len(context_blocks) > idx:
        assert context_blocks[idx].startswith("## Graveyard context")
        assert all(not block.startswith("## Graveyard context") for block in context_blocks[:idx])


def test_no_runtime_stdout_noise_contract(tmp_path: Path, capsys) -> None:
    root = tmp_path / "stdout-contract"
    _init_gemini_runtime(root, capsys)
    payloads = {
        "SessionStart": {
            "session_id": "stdout-contract",
            "hook_event_name": "SessionStart",
            "cwd": str(root),
            "timestamp": "2026-03-05T00:00:00Z",
        },
        "BeforeTool": {
            "session_id": "stdout-contract",
            "hook_event_name": "BeforeTool",
            "tool_name": "Edit",
        },
        "AfterTool": {
            "session_id": "stdout-contract",
            "hook_event_name": "AfterTool",
            "tool_name": "Edit",
            "status": "ok",
        },
        "BeforeAgent": {
            "session_id": "stdout-contract",
            "hook_event_name": "BeforeAgent",
            "prompt": "Continue with implementation.",
        },
        "AfterAgent": {
            "session_id": "stdout-contract",
            "hook_event_name": "AfterAgent",
            "prompt_response": (
                "Done.\n"
                "STOP_FIELDS_JSON: "
                '{"challenge_coverage":{"null_inputs":true,"boundary_values":true,'
                '"error_handling":true,"graveyard_regression":true}}'
            ),
        },
    }

    for event, payload in payloads.items():
        proc = _run_bridge(root=root, event=event, payload=payload)
        assert proc.returncode == 0, f"{event} failed: stderr={proc.stderr!r}"
        raw = proc.stdout.strip()
        assert raw.startswith("{") and raw.endswith("}")
        parsed = json.loads(raw)
        assert isinstance(parsed, dict)
