from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


_FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures" / "adapter_validation"
_LOCAL_LEAK_PATTERNS = (
    re.compile(r"/Users/", re.IGNORECASE),
    re.compile(r"\\Users\\", re.IGNORECASE),
    re.compile(r"C:\\\\", re.IGNORECASE),
    re.compile(r"/home/", re.IGNORECASE),
    re.compile(r"/private/tmp/", re.IGNORECASE),
    re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", re.IGNORECASE),
    re.compile(r"https://github\.com/[A-Za-z0-9_.-]+/cortex-loop", re.IGNORECASE),
)


def _iter_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        strings: list[str] = []
        for nested in value.values():
            strings.extend(_iter_strings(nested))
        return strings
    if isinstance(value, list):
        strings = []
        for nested in value:
            strings.extend(_iter_strings(nested))
        return strings
    return []


def test_adapter_validation_json_fixtures_have_no_local_path_or_identity_leaks() -> None:
    fixture_paths = sorted(_FIXTURES_DIR.glob("**/*.json"))
    assert fixture_paths, "expected adapter validation fixture files"
    for path in fixture_paths:
        data = json.loads(path.read_text(encoding="utf-8"))
        for text in _iter_strings(data):
            for pattern in _LOCAL_LEAK_PATTERNS:
                assert not pattern.search(text), f"{path.name} contains local leak matching {pattern.pattern}: {text}"
