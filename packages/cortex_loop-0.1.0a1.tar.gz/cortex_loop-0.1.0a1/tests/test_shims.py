from __future__ import annotations

import importlib
import sys
from pathlib import Path

import pytest


def _shim_source(name: str) -> str:
    shim_path = Path(__file__).resolve().parents[1] / "cortex" / f"{name}.py"
    return shim_path.read_text(encoding="utf-8")


def test_cli_shim_is_direct_reexport() -> None:
    source = _shim_source("cli")
    assert "cortex_ops_cli.main" in source
    assert "spec_from_file_location" not in source


def test_repomap_shim_is_direct_reexport() -> None:
    source = _shim_source("repomap")
    assert "cortex_repomap.engine" in source
    assert "spec_from_file_location" not in source


def test_cli_shim_aliases_target_module() -> None:
    import cortex.cli as cli_mod

    assert cli_mod.__name__ == "cortex.cli"
    assert callable(cli_mod.main)
    assert cli_mod.main is importlib.import_module("cortex_ops_cli.main").main


def test_repomap_shim_aliases_target_module() -> None:
    import cortex.repomap as repomap_mod

    assert repomap_mod.__name__ == "cortex.repomap"
    assert callable(repomap_mod.run_repomap)
    assert repomap_mod.run_repomap is importlib.import_module("cortex_repomap.engine").run_repomap


def test_shim_setattr_forwards_to_impl(monkeypatch: pytest.MonkeyPatch) -> None:
    import cortex.repomap as repomap_mod
    import cortex_repomap.engine as repomap_impl

    monkeypatch.setattr(repomap_mod, "MAX_DISCOVER_FILE_BYTES", 123)
    assert repomap_impl.MAX_DISCOVER_FILE_BYTES == 123


def test_shims_raise_if_extracted_package_is_unavailable(monkeypatch: pytest.MonkeyPatch) -> None:
    real_import_module = importlib.import_module

    def _blocked_import(name: str, package: str | None = None) -> object:
        if name in {"cortex_ops_cli.main", "cortex_repomap.engine"}:
            raise ModuleNotFoundError(name)
        return real_import_module(name, package)

    monkeypatch.setattr(importlib, "import_module", _blocked_import)
    for module_name in ("cortex.cli", "cortex.repomap"):
        sys.modules.pop(module_name, None)
        with pytest.raises(ModuleNotFoundError):
            __import__(module_name)
