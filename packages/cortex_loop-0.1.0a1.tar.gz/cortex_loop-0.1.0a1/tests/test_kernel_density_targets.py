from __future__ import annotations

import ast
from pathlib import Path

STOP_PATH_MODULES = {
    "core.py",
    "stop_contract.py",
    "stop_runtime.py",
    "stop_signals.py",
    "challenges.py",
    "requirements.py",
    "invariants.py",
    "graveyard.py",
    "stop_policy.py",
    "store.py",
}


def _module_loc_code(path: Path) -> int:
    lines = path.read_text(encoding="utf-8").splitlines()
    return sum(1 for line in lines if line.strip() and not line.strip().startswith("#"))


def _module_decision_points(path: Path) -> int:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    return sum(
        isinstance(
            node,
            (ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try, ast.BoolOp, ast.IfExp, ast.Match),
        )
        for node in ast.walk(tree)
    )


def test_kernel_density_targets() -> None:
    kernel_root = Path(__file__).resolve().parents[1] / "cortex"
    module_paths = sorted(kernel_root.rglob("*.py"))
    module_names = {str(path.relative_to(kernel_root)) for path in module_paths}
    assert STOP_PATH_MODULES <= module_names
    loc_by_module = {name: _module_loc_code(kernel_root / name) for name in module_names}
    decisions_by_module = {name: _module_decision_points(kernel_root / name) for name in module_names}
    kernel_loc = sum(loc_by_module.values())
    stop_path_loc = sum(loc_by_module[name] for name in STOP_PATH_MODULES)
    kernel_decisions = sum(decisions_by_module.values())
    stop_path_decisions = sum(decisions_by_module[name] for name in STOP_PATH_MODULES)
    stop_path_share = stop_path_loc / kernel_loc if kernel_loc else 0.0
    stop_path_decision_share = stop_path_decisions / kernel_decisions if kernel_decisions else 0.0
    stop_path_decision_density = stop_path_decisions / stop_path_loc if stop_path_loc else 0.0
    stop_path_module_densities = {
        name: decisions_by_module[name] / loc_by_module[name] for name in STOP_PATH_MODULES
    }

    assert stop_path_share > 0.50
    assert stop_path_decision_share > 0.50
    assert stop_path_decision_share >= stop_path_share - 0.055
    assert stop_path_decision_density >= 0.145
    assert min(stop_path_module_densities.values()) >= 0.07
    assert all(decisions_by_module[name] > 0 for name in STOP_PATH_MODULES)
