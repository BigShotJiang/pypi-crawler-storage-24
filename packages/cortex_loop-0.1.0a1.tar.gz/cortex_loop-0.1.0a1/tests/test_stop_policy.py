from __future__ import annotations

from cortex.stop_policy import compute_stop_outcome


def test_compute_stop_outcome_blocks_on_strict_structured_violation() -> None:
    verdict = compute_stop_outcome(
        mode="strict",
        fail_on_missing_challenge_coverage=False,
        fail_on_requirement_audit_gap=False,
        require_requirement_audit=False,
        challenge_ok=True,
        invariant_ok=True,
        invariant_recommend_revert=False,
        missing_challenge_coverage=False,
        requirements_gate_gap=False,
        requirement_audit_missing=False,
        structured_stop_violation=True,
    )
    assert verdict.session_status == "failed_stop_contract"
    assert verdict.recommend_revert is True
    assert verdict.proceed is False
    assert verdict.feedback_mode == "normal"


def test_compute_stop_outcome_respects_advisory_mode_for_structured_violation() -> None:
    verdict = compute_stop_outcome(
        mode="advisory",
        fail_on_missing_challenge_coverage=False,
        fail_on_requirement_audit_gap=False,
        require_requirement_audit=False,
        challenge_ok=True,
        invariant_ok=True,
        invariant_recommend_revert=False,
        missing_challenge_coverage=False,
        requirements_gate_gap=False,
        requirement_audit_missing=False,
        structured_stop_violation=True,
    )
    assert verdict.session_status == "failed_stop_contract"
    assert verdict.recommend_revert is False
    assert verdict.proceed is True
    assert verdict.feedback_mode == "normal"


def test_compute_stop_outcome_is_pure_and_rejects_payload_arguments() -> None:
    try:
        compute_stop_outcome(  # type: ignore[call-arg]
            mode="strict",
            fail_on_missing_challenge_coverage=False,
            fail_on_requirement_audit_gap=False,
            require_requirement_audit=False,
            challenge_ok=True,
            invariant_ok=True,
            invariant_recommend_revert=False,
            missing_challenge_coverage=False,
            requirements_gate_gap=False,
            requirement_audit_missing=False,
            structured_stop_violation=False,
            payload={"challenge_coverage": {"null_inputs": True}},
        )
        raise AssertionError("expected TypeError for unexpected payload argument")
    except TypeError:
        pass


def test_compute_stop_outcome_marks_failed_challenges_without_parsing_payload_shape() -> None:
    verdict = compute_stop_outcome(
        mode="strict",
        fail_on_missing_challenge_coverage=True,
        fail_on_requirement_audit_gap=False,
        require_requirement_audit=False,
        challenge_ok=False,
        invariant_ok=True,
        invariant_recommend_revert=False,
        missing_challenge_coverage=False,
        requirements_gate_gap=False,
        requirement_audit_missing=False,
        structured_stop_violation=False,
    )
    assert verdict.session_status == "failed_challenges"
    assert verdict.recommend_revert is True
    assert verdict.proceed is False
    assert verdict.feedback_mode == "normal"


def test_compute_stop_outcome_marks_loop_feedback_mode_without_changing_policy() -> None:
    verdict = compute_stop_outcome(
        mode="strict",
        fail_on_missing_challenge_coverage=True,
        fail_on_requirement_audit_gap=False,
        require_requirement_audit=False,
        challenge_ok=False,
        invariant_ok=True,
        invariant_recommend_revert=False,
        missing_challenge_coverage=False,
        requirements_gate_gap=False,
        requirement_audit_missing=False,
        structured_stop_violation=False,
        loop_detected=True,
    )
    assert verdict.session_status == "failed_challenges"
    assert verdict.recommend_revert is True
    assert verdict.feedback_mode == "reconsider_approach"


def test_compute_stop_outcome_promotes_stuck_to_session_verdict() -> None:
    verdict = compute_stop_outcome(
        mode="strict",
        fail_on_missing_challenge_coverage=False,
        fail_on_requirement_audit_gap=True,
        require_requirement_audit=True,
        challenge_ok=True,
        invariant_ok=True,
        invariant_recommend_revert=False,
        missing_challenge_coverage=False,
        requirements_gate_gap=True,
        requirement_audit_missing=False,
        structured_stop_violation=False,
        stuck_declared=True,
    )
    assert verdict.session_status == "stuck"
    assert verdict.recommend_revert is False
    assert verdict.proceed is False
    assert verdict.feedback_mode == "stuck"
