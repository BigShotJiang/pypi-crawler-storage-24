from __future__ import annotations

from cortex.stop_payload import extract_stop_fields, parse_stop_fields_json


def test_extract_stop_fields_prefers_structured_payload() -> None:
    fields, source, warnings, normalization_count = extract_stop_fields(
        {
            "stop_fields": {
                "challenge_coverage": {
                    "null_inputs": True,
                }
            },
            "last_assistant_message": 'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":false}}',
        }
    )
    assert source == "payload.stop_fields"
    assert fields is not None
    assert fields["challenge_coverage"]["null_inputs"] is True
    assert warnings == []
    assert normalization_count == 0


def test_extract_stop_fields_can_disable_message_fallback() -> None:
    fields, source, warnings, normalization_count = extract_stop_fields(
        {"last_assistant_message": 'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true}}'},
        allow_message_fallback=False,
    )
    assert fields is None
    assert source is None
    assert warnings == []
    assert normalization_count == 0


def test_extract_stop_fields_canonicalizes_whitespace_keys() -> None:
    fields, source, warnings, normalization_count = extract_stop_fields(
        {
            "stop_fields": {
                " challenge_coverage ": {"graveyard_regression ": True},
                "truth_claims": {" modified_files": ["src/app.py"]},
            }
        }
    )
    assert source == "payload.stop_fields"
    assert warnings == []
    assert normalization_count == 3
    assert fields is not None
    assert fields["challenge_coverage"]["graveyard_regression"] is True
    assert fields["truth_claims"]["modified_files"] == ["src/app.py"]


def test_extract_stop_fields_preserves_stuck_declaration() -> None:
    fields, source, warnings, normalization_count = extract_stop_fields(
        {
            "stop_fields": {
                "stuck_declaration": {
                    "check": "requirements",
                    "approaches_tried": ["pytest -q", "python3 -m pytest tests/test_core.py -q"],
                    "obstacle": "missing fixture coverage",
                }
            }
        }
    )
    assert source == "payload.stop_fields"
    assert warnings == []
    assert normalization_count == 0
    assert fields is not None
    assert fields["stuck_declaration"]["check"] == "requirements"


def test_parse_stop_fields_json_reports_invalid_trailer() -> None:
    parsed, marker_found, error = parse_stop_fields_json('STOP_FIELDS_JSON: {"challenge_coverage":')
    assert parsed is None
    assert marker_found is True
    assert error
