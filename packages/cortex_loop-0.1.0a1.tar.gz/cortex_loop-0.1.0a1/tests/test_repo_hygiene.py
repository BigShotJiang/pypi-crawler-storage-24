from __future__ import annotations

import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

ALLOWED_ROOT_MARKDOWN = {
    "AGENTS.md",
    "ARCHITECTURE.md",
    "CHANGELOG.md",
    "CODE_OF_CONDUCT.md",
    "CONTRIBUTING.md",
    "MISSION.md",
    "README.md",
    "REPO_WORKFLOW.md",
    "SECURITY.md",
    "SOUL.md",
    "SOUL_ADDENDUM.md",
    "START_HERE.md",
    "SUPPORT.md",
}

TRACKED_JUNK_PATTERNS = (
    re.compile(r"(^|/)\.DS_Store$"),
    re.compile(r"(^|/)__pycache__/"),
    re.compile(r"\.pyc$"),
)


def _tracked_files() -> list[str]:
    run = subprocess.run(
        ["git", "-C", str(ROOT), "ls-files"],
        check=True,
        capture_output=True,
        text=True,
    )
    return [
        line.strip()
        for line in run.stdout.splitlines()
        if line.strip() and (ROOT / line.strip()).exists()
    ]


def test_root_markdown_surface_is_curated() -> None:
    tracked_root_md = {
        rel
        for rel in _tracked_files()
        if rel.endswith(".md") and "/" not in rel
    }
    assert tracked_root_md == ALLOWED_ROOT_MARKDOWN


def test_repo_has_no_tracked_junk_artifacts() -> None:
    offenders: list[str] = []
    for rel in _tracked_files():
        if rel == "eval/study/results/.gitignore":
            continue
        if rel == "eval/study/mini_openai_ab/results/.gitignore":
            continue
        if rel.startswith("eval/study/results/"):
            offenders.append(rel)
            continue
        if rel.startswith("eval/study/mini_openai_ab/results/"):
            offenders.append(rel)
            continue
        if rel.startswith(("build/", "dist/", ".pytest_cache/", ".ruff_cache/")):
            offenders.append(rel)
            continue
        if ".egg-info/" in rel:
            offenders.append(rel)
            continue
        if rel.startswith(".cortex/"):
            offenders.append(rel)
            continue
        if any(pattern.search(rel) for pattern in TRACKED_JUNK_PATTERNS):
            offenders.append(rel)
    assert offenders == []


def test_ci_workflow_uses_read_only_default_permissions() -> None:
    ci = (ROOT / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")

    assert "permissions:" in ci
    assert "contents: read" in ci


def test_publish_workflow_uses_trusted_publishing_and_least_privilege() -> None:
    publish = (ROOT / ".github" / "workflows" / "publish.yml").read_text(encoding="utf-8")

    assert "tags:" in publish
    assert '"v*"' in publish
    assert "pypa/gh-action-pypi-publish@release/v1" in publish
    assert "id-token: write" in publish
    assert "contents: read" in publish
    assert "PYPI_API_TOKEN" not in publish
    assert "__token__" not in publish
