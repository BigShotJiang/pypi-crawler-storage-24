from __future__ import annotations

import json
from pathlib import Path

from cortex.adapters import GeminiAdapter
from cortex.stop_contract import resolve_stop_contract


def test_resolve_stop_contract_uses_structured_stop_fields() -> None:
    contract = resolve_stop_contract(
        {
            "stop_fields": {
                "challenge_coverage": {"null_inputs": True},
                "required_requirement_ids": ["R1", "R2"],
            }
        },
        allow_message_fallback=True,
        require_structured_stop_payload=True,
    )
    assert contract.stop_source == "payload.stop_fields"
    assert contract.stop_fields_source == "payload.stop_fields"
    assert contract.stop_fields_fallback_used is False
    assert contract.stop_key_normalization_count == 0
    assert contract.challenge_coverage == {"null_inputs": True}
    assert contract.required_requirement_ids == ["R1", "R2"]
    assert contract.structured_stop_violation is False


def test_resolve_stop_contract_flags_trailer_only_when_structured_required() -> None:
    contract = resolve_stop_contract(
        {
            "last_assistant_message": (
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true}}'
            )
        },
        allow_message_fallback=True,
        require_structured_stop_payload=True,
    )
    assert contract.stop_source == "message_fallback"
    assert contract.stop_fields_source == "last_assistant_message"
    assert contract.stop_fields_fallback_used is True
    assert contract.challenge_coverage == {"null_inputs": True}
    assert contract.structured_stop_violation is True
    assert contract.contract_diagnostic is not None
    assert contract.contract_diagnostic["distance_signal"] == "close"
    assert any("Recovered stop fields from last_assistant_message" in warning for warning in contract.warnings)


def test_resolve_stop_contract_normalizes_failed_approach_aliases() -> None:
    contract = resolve_stop_contract(
        {
            "what_was_tried": "single-pass parser",
            "why_failed": "edge cases skipped",
            "failed_files": ["src/parser.py"],
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stop_source == "native"
    assert contract.failed_approach == {
        "summary": "single-pass parser",
        "reason": "edge cases skipped",
        "files": ["src/parser.py"],
    }


def test_resolve_stop_contract_drops_incomplete_failed_approach() -> None:
    contract = resolve_stop_contract(
        {
            "failed_approach": {"summary": "tried regex parser"},
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stop_source == "native"
    assert contract.failed_approach is None


def test_resolve_stop_contract_reads_failed_approach_aliases_from_stop_fields() -> None:
    contract = resolve_stop_contract(
        {
            "stop_fields": {
                "what_was_tried": "single-pass parser",
                "why_failed": "edge cases skipped",
                "failed_files": ["src/parser.py"],
            }
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stop_source == "payload.stop_fields"
    assert contract.failed_approach == {
        "summary": "single-pass parser",
        "reason": "edge cases skipped",
        "files": ["src/parser.py"],
    }


def test_resolve_stop_contract_reads_failed_approach_aliases_from_message_fallback() -> None:
    contract = resolve_stop_contract(
        {
            "last_assistant_message": (
                'STOP_FIELDS_JSON: {"what_was_tried":"single-pass parser","why_failed":"edge cases skipped",'
                '"failed_files":["src/parser.py"]}'
            )
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stop_source == "message_fallback"
    assert contract.failed_approach == {
        "summary": "single-pass parser",
        "reason": "edge cases skipped",
        "files": ["src/parser.py"],
    }


def test_stop_contract_output_has_no_policy_verdict_fields() -> None:
    contract = resolve_stop_contract(
        {"challenge_coverage": {"null_inputs": True}},
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert not hasattr(contract, "session_status")
    assert not hasattr(contract, "proceed")
    assert not hasattr(contract, "recommend_revert")


def test_resolve_stop_contract_reads_truth_claims_from_structured_payload() -> None:
    contract = resolve_stop_contract(
        {
            "stop_fields": {
                "challenge_coverage": {"null_inputs": True},
                "truth_claims": {
                    "modified_files": ["src/app.py"],
                    "tests_ran": ["pytest -q"],
                },
            }
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stop_source == "payload.stop_fields"
    assert contract.truth_claims == {
        "modified_files": ["src/app.py"],
        "tests_ran": ["pytest -q"],
    }


def test_resolve_stop_contract_tracks_key_normalization_count() -> None:
    contract = resolve_stop_contract(
        {
            "stop_fields": {
                " challenge_coverage ": {"graveyard_regression ": True},
                "truth_claims": {" modified_files": ["src/app.py"]},
            }
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stop_key_normalization_count == 3
    assert contract.challenge_coverage == {"graveyard_regression": True}
    assert contract.truth_claims == {"modified_files": ["src/app.py"]}


def test_resolve_stop_contract_reads_truth_claims_from_message_fallback() -> None:
    contract = resolve_stop_contract(
        {
            "last_assistant_message": (
                "Done.\n"
                'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":true},'
                '"truth_claims":{"modified_files":["src/app.py"],"tests_ran":["pytest -q"]}}'
            )
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stop_source == "message_fallback"
    assert contract.truth_claims == {
        "modified_files": ["src/app.py"],
        "tests_ran": ["pytest -q"],
    }


def test_resolve_stop_contract_does_not_fire_message_fallback_when_structured_fields_are_present() -> None:
    contract = resolve_stop_contract(
        {
            "challenge_coverage": {"null_inputs": True},
            "last_assistant_message": 'STOP_FIELDS_JSON: {"challenge_coverage":{"null_inputs":false}}',
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stop_source == "native"
    assert contract.stop_fields_source == "none"
    assert contract.stop_fields_fallback_used is False
    assert all("Recovered stop fields from last_assistant_message" not in warning for warning in contract.warnings)


def test_resolve_stop_contract_accepts_real_gemini_after_agent_prompt_response() -> None:
    payload = json.loads(
        (Path(__file__).resolve().parent / "fixtures" / "gemini" / "after_agent_real.json").read_text(
            encoding="utf-8"
        )
    )
    normalized = GeminiAdapter().normalize("AfterAgent", payload).payload
    contract = resolve_stop_contract(
        normalized,
        allow_message_fallback=True,
        require_structured_stop_payload=True,
    )
    assert contract.stop_source == "payload.stop_fields"
    assert contract.challenge_coverage is None
    assert contract.structured_stop_violation is False


def test_resolve_stop_contract_accepts_structured_gemini_after_agent_prompt_response() -> None:
    payload = json.loads(
        (Path(__file__).resolve().parent / "fixtures" / "gemini" / "after_agent_structured.json").read_text(
            encoding="utf-8"
        )
    )
    normalized = GeminiAdapter().normalize("AfterAgent", payload).payload
    contract = resolve_stop_contract(
        normalized,
        allow_message_fallback=False,
        require_structured_stop_payload=True,
    )
    assert contract.stop_source == "payload.stop_fields"
    assert contract.challenge_coverage == {
        "null_inputs": True,
        "boundary_values": True,
        "error_handling": True,
        "graveyard_regression": True,
    }


def test_resolve_stop_contract_normalizes_stuck_declaration() -> None:
    contract = resolve_stop_contract(
        {
            "stop_fields": {
                "stuck_declaration": {
                    "check": "requirements",
                    "approaches_tried": ["pytest -q", "python3 -m pytest tests/test_core.py -q"],
                    "obstacle": "session witness is incomplete",
                }
            }
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stuck_declaration == {
        "check": "requirements",
        "approaches_tried": ["pytest -q", "python3 -m pytest tests/test_core.py -q"],
        "obstacle": "session witness is incomplete",
    }


def test_resolve_stop_contract_drops_incomplete_stuck_declaration() -> None:
    contract = resolve_stop_contract(
        {
            "stop_fields": {
                "stuck_declaration": {"check": "requirements"},
            }
        },
        allow_message_fallback=True,
        require_structured_stop_payload=False,
    )
    assert contract.stuck_declaration is None
    assert any("Ignoring incomplete stuck_declaration" in warning for warning in contract.warnings)
