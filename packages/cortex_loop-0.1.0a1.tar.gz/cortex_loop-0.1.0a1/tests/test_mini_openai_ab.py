from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import pytest

MINI_SCRIPTS = Path(__file__).resolve().parents[1] / "eval" / "study" / "mini_openai_ab" / "scripts"
if str(MINI_SCRIPTS) not in sys.path:
    sys.path.append(str(MINI_SCRIPTS))
STUDY_SCRIPTS = Path(__file__).resolve().parents[1] / "eval" / "study" / "scripts"
if str(STUDY_SCRIPTS) not in sys.path:
    sys.path.append(str(STUDY_SCRIPTS))

import analyze_mini_openai_ab  # type: ignore  # noqa: E402
import run_mini_openai_ab  # type: ignore  # noqa: E402
import run_block  # type: ignore  # noqa: E402


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _seed_ab_records(
    *,
    output_dir: Path,
    b_stdout_by_idx: dict[int, str] | None = None,
    b_gaps_by_idx: dict[int, list[str]] | None = None,
    a_response_by_idx: dict[int, bool] | None = None,
    b_response_by_idx: dict[int, bool] | None = None,
    a_artifact_by_idx: dict[int, bool] | None = None,
    b_artifact_by_idx: dict[int, bool] | None = None,
    b_stderr_by_idx: dict[int, str] | None = None,
) -> None:
    completed_slots: dict[str, Any] = {}

    for idx in range(1, 7):
        a_id = f"ab-{idx:03d}-mini_m{idx:02d}-openai-A-a1"
        b_id = f"ab-{idx:03d}-mini_m{idx:02d}-openai-B-a1"
        completed_slots[f"slot-a-{idx}"] = {"final_run_id": a_id, "status": "ok"}
        completed_slots[f"slot-b-{idx}"] = {"final_run_id": b_id, "status": "ok"}

        a_resp = (a_response_by_idx or {}).get(idx, True)
        b_resp = (b_response_by_idx or {}).get(idx, True)
        a_art = (a_artifact_by_idx or {}).get(idx, True)
        b_art = (b_artifact_by_idx or {}).get(idx, True)
        b_gaps = (b_gaps_by_idx or {}).get(idx, [])

        a_record = {
            "run_id": a_id,
            "slot_id": a_id,
            "block": "ab",
            "condition": "A",
            "status": "ok",
            "stdout": "A stdout",
            "metrics": {
                "artifact_pass": a_art,
                "enforcement_pass": True,
                "response_present": a_resp,
                "composite_pass": bool(a_art and a_resp),
            },
        }
        b_payload = {
            "coverage_gaps": b_gaps,
            "approval_request_count": 1,
            "command_completion_count": 1,
            "duplicate_turn_completed_count": 0,
        }
        b_stdout = (b_stdout_by_idx or {}).get(idx, json.dumps(b_payload))
        b_record = {
            "run_id": b_id,
            "slot_id": b_id,
            "block": "ab",
            "condition": "B",
            "status": "ok",
            "stdout": b_stdout,
            "stderr": (b_stderr_by_idx or {}).get(idx, ""),
            "metrics": {
                "artifact_pass": b_art,
                "enforcement_pass": True,
                "response_present": b_resp,
                "composite_pass": bool(b_art and b_resp),
            },
        }

        _write_json(output_dir / "raw_local" / "runs" / f"{a_id}.json", a_record)
        _write_json(output_dir / "raw_local" / "runs" / f"{b_id}.json", b_record)

    _write_json(output_dir / "checkpoints" / "ab.json", {"completed_slots": completed_slots})


def _good_preflight() -> dict[str, Any]:
    return {
        "ok": True,
        "failures": [],
        "provider_capabilities": {
            "openai": {
                "promotable": True,
                "quarantine_reason": "",
                "coverage_gaps": [],
            }
        },
    }


def _good_codex_baseline() -> dict[str, Any]:
    return {
        "codex_bin": "codex",
        "codex_bin_on_path": True,
        "codex_version_parsed": True,
        "codex_version": "0.110.0",
        "codex_version_meets_minimum": True,
        "minimum_version_label": "0.110.0",
    }


def test_analyzer_marks_incomplete_on_bridge_parse_failure(tmp_path: Path) -> None:
    _seed_ab_records(
        output_dir=tmp_path,
        b_stdout_by_idx={1: ""},
        b_artifact_by_idx={1: True, 2: True, 3: True, 4: True, 5: True, 6: True},
    )

    result = analyze_mini_openai_ab.analyze_mini_openai_ab(
        output_dir=tmp_path,
        preflight_report=_good_preflight(),
        codex_baseline=_good_codex_baseline(),
        seed=20260305,
        model_resolved="gpt-5.2-codex",
    )

    assert result["verdict"] == "INCOMPLETE"
    assert "gate_c_b_bridge_parse_ok_count" in result["failed_gates"]
    assert "gate_c_b_hard_coverage_gap_count" in result["failed_gates"]
    assert result["bridge_summary"]["coverage_gap_frequency"]["bridge_output_unparseable"] == 1


def test_analyzer_handles_empty_stdout_with_stderr_diagnostics_without_crashing(tmp_path: Path) -> None:
    _seed_ab_records(
        output_dir=tmp_path,
        b_stdout_by_idx={1: ""},
        b_stderr_by_idx={1: '{"ok": false, "error": "Timed out waiting for codex app-server response"}'},
        b_artifact_by_idx={1: True, 2: True, 3: True, 4: True, 5: True, 6: True},
    )

    result = analyze_mini_openai_ab.analyze_mini_openai_ab(
        output_dir=tmp_path,
        preflight_report=_good_preflight(),
        codex_baseline=_good_codex_baseline(),
        seed=20260305,
        model_resolved="gpt-5.2-codex",
    )

    assert result["verdict"] == "INCOMPLETE"
    assert "gate_c_b_bridge_parse_ok_count" in result["failed_gates"]
    assert result["bridge_summary"]["bridge_parse_fail_count"] == 1


def test_analyzer_ignores_unknown_bridge_keys_without_schema_drift(tmp_path: Path) -> None:
    payload_with_unknown = {
        "coverage_gaps": [],
        "approval_request_count": 1,
        "command_completion_count": 1,
        "duplicate_turn_completed_count": 0,
        "unexpected_new_key": {"nested": True},
    }
    _seed_ab_records(
        output_dir=tmp_path,
        b_stdout_by_idx={1: json.dumps(payload_with_unknown)},
    )

    result = analyze_mini_openai_ab.analyze_mini_openai_ab(
        output_dir=tmp_path,
        preflight_report=_good_preflight(),
        codex_baseline=_good_codex_baseline(),
        seed=20260305,
        model_resolved="gpt-5.2-codex",
    )

    assert result["verdict"] == "COMPLETE"
    first_row = result["bridge_summary"]["rows"][0]
    assert "unexpected_new_key" not in first_row


def test_analyzer_allows_limitation_gap_without_hard_fail(tmp_path: Path) -> None:
    _seed_ab_records(
        output_dir=tmp_path,
        b_gaps_by_idx={1: ["pre_tool_use_partial_surface_trusted_commands"]},
        a_artifact_by_idx={1: True, 2: True, 3: True, 4: True, 5: True, 6: True},
        b_artifact_by_idx={1: True, 2: True, 3: True, 4: True, 5: True, 6: True},
    )

    result = analyze_mini_openai_ab.analyze_mini_openai_ab(
        output_dir=tmp_path,
        preflight_report=_good_preflight(),
        codex_baseline=_good_codex_baseline(),
        seed=20260305,
        model_resolved="gpt-5.2-codex",
    )

    assert result["verdict"] == "COMPLETE"
    assert "pre_tool_use_partial_surface_trusted_commands" in result["limitations"]
    assert result["bridge_summary"]["hard_coverage_gap_count"] == 0


def test_analyzer_uses_count_gate_and_no_redundant_response_comparator(tmp_path: Path) -> None:
    _seed_ab_records(
        output_dir=tmp_path,
        a_artifact_by_idx={1: True, 2: True, 3: True, 4: True, 5: True, 6: True},
        b_artifact_by_idx={1: True, 2: True, 3: True, 4: True, 5: True, 6: False},
    )

    result = analyze_mini_openai_ab.analyze_mini_openai_ab(
        output_dir=tmp_path,
        preflight_report=_good_preflight(),
        codex_baseline=_good_codex_baseline(),
        seed=20260305,
        model_resolved="gpt-5.2-codex",
    )

    assert result["verdict"] == "COMPLETE"
    assert "gate_d_b_artifact_vs_a" in result["gate_results"]
    assert not any("response" in key and "gate_d" in key for key in result["gate_results"])


def test_runner_returns_zero_on_incomplete_by_default(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = {
        "schema_version": "cortex_study_manifest_v1",
        "seed": 20260305,
        "models": {"openai": {"cli": "codex", "timeout_seconds": 180}},
    }

    monkeypatch.setattr(run_mini_openai_ab, "load_manifest", lambda _path: manifest)
    monkeypatch.setattr(run_mini_openai_ab, "_codex_baseline", lambda _bin: _good_codex_baseline())
    monkeypatch.setattr(run_mini_openai_ab, "run_preflight", lambda *args, **kwargs: _good_preflight())
    monkeypatch.setattr(run_mini_openai_ab, "execute_block", lambda *args, **kwargs: {"models": {"openai": "gpt-5.2-codex"}})
    monkeypatch.setattr(run_mini_openai_ab, "score_block", lambda *args, **kwargs: {"block": "ab"})
    monkeypatch.setattr(
        run_mini_openai_ab,
        "analyze_mini_openai_ab",
        lambda **kwargs: {"verdict": "INCOMPLETE", "failed_gates": ["g1"]},
    )

    rc = run_mini_openai_ab.run(["--output-dir", str(tmp_path)])
    assert rc == 0


def test_runner_fail_on_incomplete_flag_returns_one(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = {
        "schema_version": "cortex_study_manifest_v1",
        "seed": 20260305,
        "models": {"openai": {"cli": "codex", "timeout_seconds": 180}},
    }

    monkeypatch.setattr(run_mini_openai_ab, "load_manifest", lambda _path: manifest)
    monkeypatch.setattr(run_mini_openai_ab, "_codex_baseline", lambda _bin: _good_codex_baseline())
    monkeypatch.setattr(run_mini_openai_ab, "run_preflight", lambda *args, **kwargs: _good_preflight())
    monkeypatch.setattr(run_mini_openai_ab, "execute_block", lambda *args, **kwargs: {"models": {"openai": "gpt-5.2-codex"}})
    monkeypatch.setattr(run_mini_openai_ab, "score_block", lambda *args, **kwargs: {"block": "ab"})
    monkeypatch.setattr(
        run_mini_openai_ab,
        "analyze_mini_openai_ab",
        lambda **kwargs: {"verdict": "INCOMPLETE", "failed_gates": ["g1"]},
    )

    rc = run_mini_openai_ab.run(["--output-dir", str(tmp_path), "--fail-on-incomplete"])
    assert rc == 1


def test_runner_returns_nonzero_on_missing_dependency(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = {
        "schema_version": "cortex_study_manifest_v1",
        "seed": 20260305,
        "models": {"openai": {"cli": "codex", "timeout_seconds": 180}},
    }

    monkeypatch.setattr(run_mini_openai_ab, "load_manifest", lambda _path: manifest)
    monkeypatch.setattr(
        run_mini_openai_ab,
        "_codex_baseline",
        lambda _bin: {
            "codex_bin": "codex",
            "codex_bin_on_path": False,
            "codex_version_parsed": False,
            "codex_version": "",
            "codex_version_meets_minimum": False,
            "minimum_version_label": "0.110.0",
        },
    )

    rc = run_mini_openai_ab.run(["--output-dir", str(tmp_path)])
    assert rc == 2


def test_openai_b_prompt_matches_shipped_profile_baseline() -> None:
    prompt = run_block._render_prompt(
        "Solve the task.",
        provider="openai",
        condition="B",
        instruction_file=None,
    )
    assert prompt == (
        "Solve the task.\n\n"
        "Work inside the current project directory. Make required file changes, run local tests, and finish only after verification."
    )


def test_openai_a_prompt_excludes_stop_trailer_contract() -> None:
    prompt = run_block._render_prompt(
        "Solve the task.",
        provider="openai",
        condition="A",
        instruction_file=None,
    )
    assert "STOP_FIELDS_JSON" not in prompt
