from __future__ import annotations

import os
import shutil
import subprocess
import sys
import sysconfig
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def _require_install_surface_lane() -> None:
    if os.environ.get("CORTEX_RUN_INSTALL_SURFACE_TESTS") != "1":
        pytest.skip("install surface tests run only in the dedicated lane")


def _tool_path(name: str) -> Path | None:
    scripts = [Path(sysconfig.get_path("scripts") or ""), Path(sys.executable).resolve().parent]
    for directory in scripts:
        candidate = directory / name
        if candidate.exists():
            return candidate
    discovered = shutil.which(name)
    return Path(discovered) if discovered is not None else None


def _run(
    command: list[str],
    *,
    env: dict[str, str],
    cwd: Path | None = None,
    expected: int = 0,
) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != expected:
        pytest.fail(
            f"command failed: {command}\n"
            f"expected={expected} actual={result.returncode}\n"
            f"stdout={result.stdout}\n"
            f"stderr={result.stderr}"
        )
    return result


def _set_trusted_host_baseline(config_path: Path) -> None:
    text = config_path.read_text(encoding="utf-8")
    updated = (
        text.replace('trust_profile = "untrusted"', 'trust_profile = "trusted"', 1)
        .replace('execution_mode = "container"', 'execution_mode = "host"', 1)
    )
    assert updated != text
    config_path.write_text(updated, encoding="utf-8")


@pytest.fixture(scope="session")
def wheel_path(tmp_path_factory: pytest.TempPathFactory) -> Path:
    dist_dir = tmp_path_factory.mktemp("install-surface-wheel")
    _run(
        [
            sys.executable,
            "-m",
            "build",
            "--wheel",
            "--no-isolation",
            "--outdir",
            str(dist_dir),
        ],
        env=os.environ.copy(),
        cwd=ROOT,
    )
    wheels = sorted(dist_dir.glob("*.whl"))
    assert len(wheels) == 1
    return wheels[0]


def _assert_version_binary(binary: Path, env: dict[str, str]) -> None:
    result = _run([str(binary), "--version"], env=env)
    assert result.stdout.strip().startswith("cortex ")


def _assert_install_flow(bin_dir: Path, env: dict[str, str], tmp_path: Path) -> None:
    suffix = ".exe" if sys.platform.startswith("win") else ""
    cortex = bin_dir / f"cortex{suffix}"
    cortex_loop = bin_dir / f"cortex-loop{suffix}"
    assert cortex.exists()
    assert cortex_loop.exists()

    _assert_version_binary(cortex, env)
    _assert_version_binary(cortex_loop, env)

    project = tmp_path / "project"
    _run([str(cortex), "init", "--root", str(project)], env=env)
    _set_trusted_host_baseline(project / "cortex.toml")
    _run([str(cortex), "runtime", "install", "--profile", "claude", "--root", str(project)], env=env)
    check = _run([str(cortex), "check", "--root", str(project)], env=env)
    assert "Runtime adapter loaded: cortex.adapters.claude:ClaudeAdapter" in check.stdout
    assert "Missing / Errors:\n  (none)" in check.stdout


def test_pipx_install_surface_proves_local_wheel(wheel_path: Path, tmp_path: Path) -> None:
    _require_install_surface_lane()
    pipx = _tool_path("pipx")
    if pipx is None:
        pytest.skip("pipx not installed")

    tool_root = tmp_path / "pipx"
    env = os.environ.copy()
    env.update(
        {
            "PIPX_HOME": str(tool_root / "home"),
            "PIPX_BIN_DIR": str(tool_root / "bin"),
            "PIPX_MAN_DIR": str(tool_root / "man"),
            "PIPX_DEFAULT_PYTHON": sys.executable,
            "PATH": str(tool_root / "bin") + os.pathsep + env.get("PATH", ""),
        }
    )

    _run([str(pipx), "install", str(wheel_path)], env=env)
    _run([str(pipx), "inject", "cortex-loop", "pytest"], env=env)
    _assert_install_flow(tool_root / "bin", env, tmp_path)
    _run([str(pipx), "uninstall", "cortex-loop"], env=env)
    assert not (tool_root / "bin" / "cortex").exists()
    assert not (tool_root / "bin" / "cortex-loop").exists()


def test_uv_tool_install_surface_proves_local_wheel(wheel_path: Path, tmp_path: Path) -> None:
    _require_install_surface_lane()
    uv = _tool_path("uv")
    if uv is None:
        pytest.skip("uv not installed")

    tool_root = tmp_path / "uv"
    env = os.environ.copy()
    env.update(
        {
            "UV_TOOL_DIR": str(tool_root / "tools"),
            "UV_TOOL_BIN_DIR": str(tool_root / "bin"),
            "UV_CACHE_DIR": str(tool_root / "cache"),
            "PATH": str(tool_root / "bin") + os.pathsep + env.get("PATH", ""),
        }
    )

    _run([str(uv), "tool", "install", "--with", "pytest", str(wheel_path)], env=env)
    _assert_install_flow(tool_root / "bin", env, tmp_path)
    _run([str(uv), "tool", "uninstall", "cortex-loop"], env=env)
    assert not (tool_root / "bin" / "cortex").exists()
    assert not (tool_root / "bin" / "cortex-loop").exists()
