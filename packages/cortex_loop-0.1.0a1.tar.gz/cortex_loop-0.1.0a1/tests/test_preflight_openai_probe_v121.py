from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

SCRIPTS_DIR = Path(__file__).resolve().parents[1] / "eval" / "study" / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.append(str(SCRIPTS_DIR))

import preflight_certify  # type: ignore  # noqa: E402


def test_openai_probe_classifies_timeout_diagnostics_from_stderr_without_success(
    tmp_path: Path,
    monkeypatch,
) -> None:
    def _fake_run_command(cmd: list[str], **kwargs: Any) -> dict[str, Any]:
        if "probe-model" in cmd:
            payload = {"available": True, "source": "model/list"}
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 0,
                "stdout": json.dumps(payload),
                "stderr": "",
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        if "probe-approval-blocking" in cmd:
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 1,
                "stdout": "",
                "stderr": json.dumps({"ok": False, "error": "Timed out waiting for codex app-server response"}),
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        raise AssertionError(f"unexpected command: {cmd}")

    monkeypatch.setattr(preflight_certify, "run_command", _fake_run_command)
    manifest = {
        "models": {
            "openai": {
                "cli": "codex",
                "probe_order": ["gpt-5.2-codex"],
                "timeout_seconds": 30,
            }
        }
    }
    report = preflight_certify._probe_openai_approval_blocking(tmp_path, manifest)
    assert report["capability"]["promotable"] is False
    assert "openai_probe:stdout_empty" in report["errors"]
    assert "openai_probe:bridge_error_timeout" in report["errors"]
    assert all("json_parse_error" not in error for error in report["errors"])


def test_openai_probe_finds_three_consecutive_passes_within_bounded_window(
    tmp_path: Path,
    monkeypatch,
) -> None:
    state = {"probe_attempt": 0}

    def _fake_run_command(cmd: list[str], **kwargs: Any) -> dict[str, Any]:
        if "probe-model" in cmd:
            payload = {"available": True, "source": "model/list"}
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 0,
                "stdout": json.dumps(payload),
                "stderr": "",
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        if "probe-approval-blocking" in cmd:
            state["probe_attempt"] += 1
            attempt = state["probe_attempt"]
            if attempt < 3:
                payload = {"blocked_decline_observed": False, "coverage_gaps": []}
            else:
                payload = {"blocked_decline_observed": True, "coverage_gaps": []}
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 0,
                "stdout": json.dumps(payload),
                "stderr": "",
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        raise AssertionError(f"unexpected command: {cmd}")

    monkeypatch.setattr(preflight_certify, "run_command", _fake_run_command)
    manifest = {
        "models": {
            "openai": {
                "cli": "codex",
                "probe_order": ["gpt-5.2-codex"],
                "timeout_seconds": 30,
            }
        }
    }
    report = preflight_certify._probe_openai_approval_blocking(tmp_path, manifest)
    assert report["required_consecutive_passes"] == 3
    assert report["max_attempts"] == 9
    assert len(report["attempts"]) == 5
    assert report["consecutive_passes"] == 3
    assert report["capability"]["promotable"] is True
    assert report["capability"]["quarantine_reason"] == ""


def test_openai_probe_uses_matrix_aware_process_timeout(
    tmp_path: Path,
    monkeypatch,
) -> None:
    calls: list[tuple[list[str], int]] = []

    def _fake_run_command(cmd: list[str], **kwargs: Any) -> dict[str, Any]:
        timeout = int(kwargs.get("timeout", 0))
        calls.append((cmd, timeout))
        if "probe-model" in cmd:
            payload = {"available": True, "source": "model/list"}
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 0,
                "stdout": json.dumps(payload),
                "stderr": "",
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        if "probe-approval-blocking" in cmd:
            payload = {"blocked_decline_observed": True, "coverage_gaps": []}
            return {
                "command": cmd,
                "cwd": str(kwargs.get("cwd")),
                "return_code": 0,
                "stdout": json.dumps(payload),
                "stderr": "",
                "elapsed_seconds": 0.1,
                "timed_out": False,
            }
        raise AssertionError(f"unexpected command: {cmd}")

    monkeypatch.setattr(preflight_certify, "run_command", _fake_run_command)
    manifest = {
        "models": {
            "openai": {
                "cli": "codex",
                "probe_order": ["gpt-5.2-codex"],
                "timeout_seconds": 30,
            }
        }
    }
    preflight_certify._probe_openai_approval_blocking(tmp_path, manifest)
    probe_timeouts = [timeout for cmd, timeout in calls if "probe-approval-blocking" in cmd]
    assert probe_timeouts
    assert all(timeout == 105 for timeout in probe_timeouts)
