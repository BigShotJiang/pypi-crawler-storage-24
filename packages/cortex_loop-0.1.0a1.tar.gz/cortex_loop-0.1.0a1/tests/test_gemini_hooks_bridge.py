from __future__ import annotations

import io
import json
import sqlite3
import sys
from pathlib import Path

import cortex_ops_cli.gemini_hooks as gemini_hooks
from cortex.executive import get_base_executive_function


class _FakeKernel:
    def __init__(self, *, result: dict[str, object]) -> None:
        self._result = result

    def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
        _ = event
        _ = payload
        return dict(self._result)


def test_gemini_bridge_maps_before_tool_policy_denial_to_deny(monkeypatch, capsys, tmp_project: Path) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(result={"proceed": False, "warnings": ["Retry budget exhausted"]}),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-1"})))

    assert gemini_hooks.main(["BeforeTool", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "deny"
    assert payload["reason"] == "Retry budget exhausted"


def test_gemini_bridge_surfaces_non_blocking_warnings_as_system_message(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "proceed": True,
                "warnings": [
                    "Top graveyard match resembles current approach",
                    "Invariant suite reported failures.",
                ],
            }
        ),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-2"})))

    assert gemini_hooks.main(["AfterTool", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert "decision" not in payload
    assert "Top graveyard match resembles current approach" in payload["systemMessage"]
    assert "Invariant suite reported failures." in payload["systemMessage"]


def test_gemini_bridge_session_start_includes_additional_context(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "warnings": ["Session initialized."],
                "context_blocks": ["part-a", "learned", "graveyard"],
            }
        ),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-start"})))

    assert gemini_hooks.main(["SessionStart", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["hookSpecificOutput"]["additionalContext"] == "part-a\n\nlearned\n\ngraveyard"
    assert "Session initialized." in payload["systemMessage"]


def test_gemini_bridge_returns_empty_payload_for_clean_pass(monkeypatch, capsys, tmp_project: Path) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(result={"proceed": True, "warnings": []}),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-3"})))

    assert gemini_hooks.main(["BeforeTool", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload == {}


def test_gemini_bridge_returns_exit_1_when_kernel_raises(monkeypatch, capsys, tmp_project: Path) -> None:
    class _FailKernel:
        def __init__(self, **_: object) -> None:
            pass

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            _ = event
            _ = payload
            raise RuntimeError("boom")

    monkeypatch.setattr(gemini_hooks, "CortexKernel", _FailKernel)
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-4"})))

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 1
    output = capsys.readouterr()
    assert output.out == ""
    assert "Gemini bridge error: boom" in output.err


def test_gemini_bridge_stops_session_when_after_agent_retry_still_fails(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(result={"proceed": False, "warnings": ["Still failing"]}),
    )
    monkeypatch.setattr(
        sys,
        "stdin",
        io.StringIO(json.dumps({"session_id": "sess-4b", "stop_hook_active": True})),
    )

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["continue"] is False
    assert payload["stopReason"] == "Cortex stop path failed after retry. Manual review required."
    assert payload["systemMessage"] == "[cortex] Still failing"


def test_gemini_bridge_denies_after_agent_on_structured_gap_even_when_proceed_true(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "proceed": True,
                "warnings": ["No challenge_coverage provided in Stop payload."],
                "challenge_coverage_missing": True,
            }
        ),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-gap"})))

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "deny"
    assert "challenge_coverage" in payload["reason"]


def test_gemini_bridge_after_agent_structured_stop_violation_has_marker_guidance(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "proceed": True,
                "warnings": ["Structured stop payload is required."],
                "structured_stop_violation": True,
            }
        ),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-structured-violation"})))

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "deny"
    assert "STOP_FIELDS_JSON" in payload["reason"]


def test_gemini_bridge_after_agent_requirements_gap_uses_report_errors(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "proceed": True,
                "warnings": [
                    "Requirement audit reported gaps: requirement 'tests_ran' evidence is unverified: command not observed: pytest -q",
                    "Top graveyard match resembles current approach",
                ],
                "requirements_gate_gap": True,
                "requirement_audit_report": {
                    "ok": False,
                    "errors": ["requirement 'tests_ran' evidence is unverified: command not observed: pytest -q"],
                },
            }
        ),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-req-gap"})))

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "deny"
    assert payload["reason"].startswith("Requirement evidence gaps:")
    assert payload["systemMessage"] == "[cortex] Requirement audit reported gaps: requirement 'tests_ran' evidence is unverified: command not observed: pytest -q\n[cortex] Top graveyard match resembles current approach"


def test_gemini_bridge_after_agent_missing_stop_hook_active_is_treated_as_false(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "proceed": True,
                "warnings": ["No challenge_coverage provided in Stop payload."],
                "challenge_coverage_missing": True,
            }
        ),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-gap-no-flag"})))

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "deny"
    assert "continue" not in payload


def test_gemini_adapter_caveat_lane_halts_when_prior_after_agent_failure_exists_without_stop_hook_flag(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "_session_has_pending_after_agent_retry",
        lambda **_: True,
    )
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "proceed": True,
                "warnings": ["No challenge_coverage provided in Stop payload."],
                "challenge_coverage_missing": True,
            }
        ),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-gap-no-flag"})))

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["continue"] is False
    assert payload["stopReason"] == gemini_hooks.RETRY_STOP_REASON


def test_gemini_bridge_allows_retry_turn_when_stop_hook_active_true_and_stop_passes(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "proceed": True,
                "warnings": ["Using challenge_coverage from payload.stop_fields."],
                "challenge_report": {"ok": True},
                "challenge_coverage_missing": False,
                "requirements_gate_gap": False,
                "structured_stop_violation": False,
            }
        ),
    )
    monkeypatch.setattr(
        sys,
        "stdin",
        io.StringIO(json.dumps({"session_id": "sess-retry-pass", "stop_hook_active": True})),
    )

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload == {"systemMessage": "[cortex] Using challenge_coverage from payload.stop_fields."}


def test_gemini_bridge_stops_session_on_invariant_failure(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "proceed": False,
                "warnings": ["Invariant suite reported failures."],
                "invariant_report": {"ok": False},
            }
        ),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-stop"})))

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload == {
        "continue": False,
        "stopReason": "Invariant suite reported failures.",
    }


def test_gemini_bridge_after_agent_stuck_result_stops_without_retry_prompt(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(
            result={
                "proceed": False,
                "feedback_mode": "stuck",
                "stuck_declared": True,
                "stuck_declaration": {
                    "check": "truth_claims",
                    "approaches_tried": ["git status", "re-read stop diagnostics"],
                    "obstacle": "session-scoped delta does not show the claimed file",
                },
                "requirements_gate_gap": True,
                "warnings": [
                    "Truth claims reported gaps: truth_claims.modified_files not observed in repository changes: src/claimed.py"
                ],
            }
        ),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-stuck"})))

    assert gemini_hooks.main(["AfterAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["continue"] is False
    assert payload["stopReason"] == (
        "Cortex reported stuck on truth_claims: session-scoped delta does not show the claimed file"
    )
    assert payload["systemMessage"] == (
        "[cortex] Truth claims reported gaps: "
        "truth_claims.modified_files not observed in repository changes: src/claimed.py"
    )


def test_gemini_bridge_before_agent_injects_persistent_anchor(monkeypatch, capsys, tmp_project: Path) -> None:
    class _FailIfCalled:
        def __init__(self, **_: object) -> None:
            pass

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            raise AssertionError(f"dispatch should not be called for {event}: {payload}")

    monkeypatch.setattr(gemini_hooks, "CortexKernel", _FailIfCalled)
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-4c"})))

    assert gemini_hooks.main(["BeforeAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert "hookSpecificOutput" in payload
    additional = payload["hookSpecificOutput"]["additionalContext"]
    _part_a, part_b = get_base_executive_function()
    assert additional == part_b
    assert "## Implementation Notes" not in additional
    assert "SOUL.md" not in additional


def test_gemini_bridge_before_agent_skips_duplicate_anchor_if_payload_already_contains_it(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    class _FailIfCalled:
        def __init__(self, **_: object) -> None:
            pass

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            raise AssertionError(f"dispatch should not be called for {event}: {payload}")

    monkeypatch.setattr(gemini_hooks, "CortexKernel", _FailIfCalled)
    _part_a, part_b = get_base_executive_function()
    monkeypatch.setattr(
        sys,
        "stdin",
        io.StringIO(json.dumps({"session_id": "sess-dup", "prompt": f"user prompt\n\n{part_b}"})),
    )

    assert gemini_hooks.main(["BeforeAgent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload == {}


def test_gemini_bridge_before_agent_anchor_output_is_constant_across_turns(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    class _FailIfCalled:
        def __init__(self, **_: object) -> None:
            pass

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            raise AssertionError(f"dispatch should not be called for {event}: {payload}")

    monkeypatch.setattr(gemini_hooks, "CortexKernel", _FailIfCalled)
    _part_a, part_b = get_base_executive_function()
    for idx in range(5):
        monkeypatch.setattr(
            sys,
            "stdin",
            io.StringIO(json.dumps({"session_id": "sess-repeat", "prompt": f"turn-{idx}"})),
        )
        assert gemini_hooks.main(["BeforeAgent", "--root", str(tmp_project)]) == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload == {"hookSpecificOutput": {"additionalContext": part_b}}


def test_session_has_pending_after_agent_retry_reads_latest_stop_event(tmp_path: Path) -> None:
    db_path = tmp_path / "cortex.db"
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE sessions (
                session_id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                metadata_json TEXT NOT NULL
            )
            """
        )
        conn.execute(
            "INSERT INTO sessions (session_id, status, metadata_json) VALUES (?, ?, ?)",
            (
                "sess-1",
                "pass",
                json.dumps({"hook": "Stop", "challenge_coverage_missing": True}),
            ),
        )
        conn.commit()

    assert (
        gemini_hooks._session_has_pending_after_agent_retry(
            root=tmp_path,
            db_path=str(db_path),
            session_id="sess-1",
        )
        is True
    )

    with sqlite3.connect(db_path) as conn:
        conn.execute(
            "UPDATE sessions SET metadata_json = ?, status = ? WHERE session_id = ?",
            (
                json.dumps(
                    {
                        "structured_stop_violation": False,
                        "challenge_coverage_missing": False,
                        "requirements_gate_gap": False,
                        "challenge_ok": True,
                        "hook": "Stop",
                    }
                ),
                "pass",
                "sess-1",
            ),
        )
        conn.commit()

    assert (
        gemini_hooks._session_has_pending_after_agent_retry(
            root=tmp_path,
            db_path=str(db_path),
            session_id="sess-1",
        )
        is False
    )

    with sqlite3.connect(db_path) as conn:
        conn.execute(
            "UPDATE sessions SET metadata_json = ?, status = ? WHERE session_id = ?",
            (
                json.dumps(
                    {
                        "feedback_mode": "stuck",
                        "stuck_declared": True,
                        "requirements_gate_gap": True,
                        "hook": "Stop",
                    }
                ),
                "stuck",
                "sess-1",
            ),
        )
        conn.commit()

    assert (
        gemini_hooks._session_has_pending_after_agent_retry(
            root=tmp_path,
            db_path=str(db_path),
            session_id="sess-1",
        )
        is False
    )


def test_gemini_bridge_ignores_unrecognized_hook_events(monkeypatch, capsys, tmp_project: Path) -> None:
    class _FailIfCalled:
        def __init__(self, **_: object) -> None:
            pass

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            raise AssertionError(f"dispatch should not be called for {event}: {payload}")

    monkeypatch.setattr(gemini_hooks, "CortexKernel", _FailIfCalled)
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-future"})))

    assert gemini_hooks.main(["FutureHookEvent", "--root", str(tmp_project)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload == {}


def test_gemini_bridge_adds_deterministic_session_id_when_missing(
    monkeypatch, capsys, tmp_project: Path
) -> None:
    captured: dict[str, object] = {}

    class _CaptureKernel:
        def __init__(self, **_: object) -> None:
            pass

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            captured["event"] = event
            captured["session_id"] = payload.get("session_id")
            return {"proceed": True, "warnings": []}

    monkeypatch.setattr(gemini_hooks, "CortexKernel", _CaptureKernel)
    monkeypatch.setattr(
        sys,
        "stdin",
        io.StringIO(
            json.dumps(
                {
                    "timestamp": "2026-03-04T00:00:00Z",
                    "transcript_path": "transcripts/sess.json",
                    "cwd": "workspace/project_a",
                }
            )
        ),
    )

    assert gemini_hooks.main(["AfterTool", "--root", str(tmp_project)]) == 0
    output = capsys.readouterr()
    assert json.loads(output.out) == {}
    assert str(captured.get("event")) == "AfterTool"
    assert str(captured.get("session_id", "")).startswith("gemini-fallback-")
    assert "missing session_id" in output.err


def test_gemini_bridge_uses_sys_argv_when_called_as_module(monkeypatch, capsys, tmp_project: Path) -> None:
    monkeypatch.setattr(
        gemini_hooks,
        "CortexKernel",
        lambda **_: _FakeKernel(result={"proceed": True, "warnings": []}),
    )
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-5"})))
    monkeypatch.setattr(
        sys,
        "argv",
        ["gemini_hooks.py", "BeforeTool", "--root", str(tmp_project)],
    )

    assert gemini_hooks.main() == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload == {}
