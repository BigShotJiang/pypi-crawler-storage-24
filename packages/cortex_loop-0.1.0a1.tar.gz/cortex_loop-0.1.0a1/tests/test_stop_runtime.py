from __future__ import annotations

from cortex.challenges import ChallengeCoverage, ChallengeReport
from cortex.invariants import InvariantCaseResult, InvariantReport
from cortex.requirements import RequirementAuditEvaluation, TruthClaimsEvaluation
from cortex.stop_contract import StopContract
from cortex.stop_runtime import StopPathOutcome, StopPathRunner


def _sample_stop_contract() -> StopContract:
    return StopContract(
        warnings=[],
        stop_source="payload.stop_fields",
        stop_fields_source="payload.stop_fields",
        stop_fields_fallback_used=False,
        stop_key_normalization_count=1,
        challenge_coverage={"null_inputs": True},
        requirement_audit={"items": []},
        truth_claims={"modified_files": ["src/app.py"]},
        required_requirement_ids=["REQ-1"],
        failed_approach={
            "summary": "Retried same delta",
            "reason": "tests still failed",
            "files": ["src/app.py"],
        },
        stuck_declaration={
            "check": "truth_claims",
            "approaches_tried": ["pytest -q"],
            "obstacle": "delta mismatch",
        },
        structured_stop_violation=False,
        contract_diagnostic={"gap_description": "structured"},
    )


def _sample_stop_outcome() -> StopPathOutcome:
    challenge_report = ChallengeReport(
        active_categories=["null_inputs"],
        custom_paths=[],
        results=[ChallengeCoverage(category="null_inputs", covered=True, evidence={})],
        missing_categories=[],
        unverified_categories=[],
        uncheckable_categories=[],
        diagnostics=[],
        config_warnings=[],
        ok=True,
    )
    invariant_report = InvariantReport(
        configured_paths=["tests/invariants/test_example.py"],
        results=[
            InvariantCaseResult(
                test_path="tests/invariants/test_example.py",
                status="pass",
                duration_ms=10,
                stdout="",
                stderr="",
            )
        ],
        diagnostics=[],
        ok=True,
        had_errors=False,
        recommend_revert=False,
    )
    return StopPathOutcome(
        warnings=["Requirement audit reported gaps: REQ-1 missing evidence"],
        challenge_report=challenge_report,
        challenge_diagnostics=[{"gap_description": "challenge"}],
        missing_challenge_coverage=False,
        invariant_report=invariant_report,
        requirement_audit=RequirementAuditEvaluation(
            report={"ok": False, "item_count": 1},
            details={"ok": False},
            gap=True,
            missing=False,
            diagnostics=[{"gap_description": "requirement"}],
            warnings=["Requirement audit reported gaps: REQ-1 missing evidence"],
        ),
        truth_claims=TruthClaimsEvaluation(
            report={"ok": False},
            gap=True,
            diagnostics=[{"gap_description": "truth"}],
            warnings=["Truth claims reported gaps: src/app.py was not observed."],
        ),
        required_requirement_ids=["REQ-1"],
        required_requirement_ids_source="session",
        contract_diagnostic={"gap_description": "structured"},
        git_snapshot={"available": True, "changed_files": ["src/baseline.py"], "error": None},
        stuck_declaration={
            "check": "truth_claims",
            "approaches_tried": ["pytest -q"],
            "obstacle": "delta mismatch",
        },
        structured_stop_violation=False,
        strict_message_fallback_violation=False,
        enforcement_pass=False,
        session_status="stuck",
        recommend_revert=False,
        proceed=False,
        feedback_mode="stuck",
        stop_attempt_signature={
            "challenge_shape": ["null_inputs:covered=True"],
            "witnessed_commands": ["pytest -q"],
            "file_signal": ["src/app.py"],
        },
        loop_detected=True,
        loop_similarity=0.91,
    )


def test_close_session_metadata_preserves_stop_runtime_context() -> None:
    metadata = StopPathRunner.close_session_metadata(
        outcome=_sample_stop_outcome(),
        stop_contract=_sample_stop_contract(),
        executive_signature="sig-1",
        executive_record={"id": 7},
    )

    assert metadata["hook"] == "Stop"
    assert metadata["requirement_audit_gap"] is True
    assert metadata["truth_claims_gap"] is True
    assert metadata["requirements_gate_gap"] is True
    assert metadata["stuck_declared"] is True
    assert metadata["feedback_mode"] == "stuck"
    assert metadata["stop_fields_source"] == "payload.stop_fields"
    assert metadata["executive_last_stop_signature"] == "sig-1"
    assert metadata["executive_memory_recorded"] is True
    assert metadata["executive_memory_record_id"] == 7


def test_response_payload_preserves_stop_result_surface() -> None:
    response = StopPathRunner.response_payload(
        outcome=_sample_stop_outcome(),
        stop_contract=_sample_stop_contract(),
    )

    assert response["challenge_report"]["ok"] is True
    assert response["requirement_audit_gap"] is True
    assert response["truth_claims_gap"] is True
    assert response["requirements_gate_gap"] is True
    assert response["stuck_declared"] is True
    assert response["feedback_mode"] == "stuck"
    assert response["loop_detected"] is True
    assert response["loop_similarity"] == 0.91
    assert response["recommend_revert"] is False
    assert response["proceed"] is False
