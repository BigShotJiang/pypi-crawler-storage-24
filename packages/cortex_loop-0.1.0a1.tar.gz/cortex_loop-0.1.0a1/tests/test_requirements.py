from __future__ import annotations

from pathlib import Path

from cortex.requirements import (
    evaluate_requirement_audit_payload,
    evaluate_truth_claims_payload,
    validate_requirement_audit,
)


def test_evaluate_requirement_audit_missing_payload_when_required(tmp_path: Path) -> None:
    result = evaluate_requirement_audit_payload(
        None,
        require_requirement_audit=True,
        require_evidence_for_passed_requirement=True,
        required_requirement_ids=["R1"],
        root=tmp_path,
        witness=None,
    )
    assert result.report is None
    assert result.details is None
    assert result.missing is True
    assert result.gap is False
    assert result.diagnostics[0]["gap_characterization"] == "comprehension_gap"
    assert any("No requirement_audit provided" in w for w in result.warnings)


def test_validate_requirement_audit_ignores_challenge_coverage_fields(tmp_path: Path) -> None:
    (tmp_path / "src").mkdir(parents=True, exist_ok=True)
    (tmp_path / "src" / "app.py").write_text("print('ok')\n", encoding="utf-8")
    payload = {
        "items": [{"id": "R1", "status": "pass", "evidence": ["src/app.py:1"]}],
        "completeness_verdict": "pass",
        "challenge_coverage": {
            "null_inputs": False,
            "boundary_values": False,
            "error_handling": False,
        },
    }
    details = validate_requirement_audit(
        payload,
        require_evidence_for_passed_requirement=True,
        required_requirement_ids=["R1"],
        root=tmp_path,
        witness={"commands": [], "tools": []},
    )
    assert details["ok"] is True
    assert details["errors"] == []


def test_validate_requirement_audit_command_is_unverified_when_not_witnessed(tmp_path: Path) -> None:
    payload = {
        "items": [{"id": "R1", "status": "pass", "evidence": ["cmd:pytest -q"]}],
        "completeness_verdict": "fail",
    }
    details = validate_requirement_audit(
        payload,
        require_evidence_for_passed_requirement=True,
        required_requirement_ids=["R1"],
        root=tmp_path,
        witness={"commands": ["npm test"], "tools": []},
    )
    assert details["ok"] is False
    assert any("command not witnessed in session events" in err for err in details["errors"])
    assert details["diagnostics"][0]["gap_characterization"] == "execution_gap"


def test_validate_requirement_audit_command_is_verified_when_witnessed(tmp_path: Path) -> None:
    payload = {
        "items": [{"id": "R1", "status": "pass", "evidence": ["cmd:pytest -q"]}],
        "completeness_verdict": "pass",
    }
    details = validate_requirement_audit(
        payload,
        require_evidence_for_passed_requirement=True,
        required_requirement_ids=["R1"],
        root=tmp_path,
        witness={"commands": ["pytest -q"], "tools": []},
    )
    assert details["ok"] is True
    assert details["errors"] == []


def test_validate_requirement_audit_command_matches_python_module_wrapper(tmp_path: Path) -> None:
    payload = {
        "items": [{"id": "R1", "status": "pass", "evidence": ["cmd:pytest -q"]}],
        "completeness_verdict": "pass",
    }
    details = validate_requirement_audit(
        payload,
        require_evidence_for_passed_requirement=True,
        required_requirement_ids=["R1"],
        root=tmp_path,
        witness={"commands": ["python -m pytest -q"], "tools": []},
    )
    assert details["ok"] is True
    assert details["errors"] == []


def test_validate_requirement_audit_command_does_not_use_reverse_substring_match(tmp_path: Path) -> None:
    payload = {
        "items": [{"id": "R1", "status": "pass", "evidence": ["cmd:npm test"]}],
        "completeness_verdict": "pass",
    }
    details = validate_requirement_audit(
        payload,
        require_evidence_for_passed_requirement=True,
        required_requirement_ids=["R1"],
        root=tmp_path,
        witness={"commands": ["npm test:unit"], "tools": []},
    )
    assert details["ok"] is False
    assert any("command not witnessed in session events" in err for err in details["errors"])


def test_validate_requirement_audit_reports_missing_required_ids_without_category_logic(tmp_path: Path) -> None:
    payload = {
        "items": [{"id": "R1", "status": "pass", "evidence": ["cmd:pytest -q"]}],
        "completeness_verdict": "fail",
        "challenge_coverage": {"graveyard_regression": False},
    }
    details = validate_requirement_audit(
        payload,
        require_evidence_for_passed_requirement=True,
        required_requirement_ids=["R1", "R2"],
        root=tmp_path,
        witness={"commands": [], "tools": []},
    )
    assert details["ok"] is False
    assert details["missing_required_ids"] == ["R2"]
    assert any("missing required ids" in err for err in details["errors"])


def test_requirement_audit_output_has_no_policy_decision_fields(tmp_path: Path) -> None:
    payload = {
        "items": [{"id": "R1", "status": "fail", "gap": "missing test case"}],
        "completeness_verdict": "fail",
    }
    details = validate_requirement_audit(
        payload,
        require_evidence_for_passed_requirement=True,
        required_requirement_ids=["R1"],
        root=tmp_path,
        witness=None,
    )
    assert "session_status" not in details
    assert "proceed" not in details
    assert "recommend_revert" not in details


def test_truth_claims_modified_files_is_unverified_when_not_in_repo_changes(
    tmp_path: Path,
) -> None:
    report = evaluate_truth_claims_payload(
        {"modified_files": ["src/missing.py"]},
        root=tmp_path,
        witness={"commands": [], "tools": []},
        observed_modified_files=[],
    )
    assert report.report is not None
    assert report.report["ok"] is False
    assert report.gap is True
    assert report.report["modified_files_unverified"] == ["src/missing.py"]
    assert report.diagnostics[0]["gap_characterization"] == "execution_gap"
    assert any("not observed in repository changes" in err for err in report.report["errors"])


def test_truth_claims_modified_files_is_verified_when_in_repo_changes(
    tmp_path: Path,
) -> None:
    report = evaluate_truth_claims_payload(
        {"modified_files": ["src/app.py", "./src/app.py"]},
        root=tmp_path,
        witness={"commands": [], "tools": []},
        observed_modified_files=["src/app.py"],
    )
    assert report.report is not None
    assert report.report["ok"] is True
    assert report.gap is False
    assert report.report["modified_files_verified"] == ["src/app.py"]
    assert report.report["modified_files_unverified"] == []


def test_truth_claims_tests_ran_requires_witnessed_commands(tmp_path: Path) -> None:
    report = evaluate_truth_claims_payload(
        {"tests_ran": ["pytest -q", "npm test"]},
        root=tmp_path,
        witness={"commands": ["pytest -q --maxfail=1"], "tools": []},
    )
    assert report.report is not None
    assert report.report["ok"] is False
    assert report.gap is True
    assert report.report["tests_ran_verified"] == ["pytest -q"]
    assert report.report["tests_ran_unverified"] == ["npm test"]
    assert any("not witnessed in session events" in err for err in report.report["errors"])


def test_truth_claims_modified_files_is_uncheckable_without_git(
    tmp_path: Path,
) -> None:
    report = evaluate_truth_claims_payload(
        {"modified_files": ["src/app.py"]},
        root=tmp_path,
        witness={"commands": [], "tools": []},
        observed_modified_files=None,
        modified_files_error="not a git repository",
    )
    assert report.report is not None
    assert report.report["ok"] is True
    assert report.gap is False
    assert report.report["modified_files_uncheckable"] == ["src/app.py"]
    assert any("uncheckable" in warning for warning in report.warnings)


def test_truth_claims_invalid_shape_reports_gap(tmp_path: Path) -> None:
    report = evaluate_truth_claims_payload(
        ["src/app.py"],
        root=tmp_path,
        witness={"commands": [], "tools": []},
    )
    assert report.report is not None
    assert report.report["ok"] is False
    assert report.diagnostics[0]["gap_characterization"] == "comprehension_gap"
    assert report.gap is True
    assert any("Invalid truth_claims format" in err for err in report.report["errors"])


def test_truth_claims_tests_ran_accepts_python_module_wrapper(tmp_path: Path) -> None:
    report = evaluate_truth_claims_payload(
        {"tests_ran": ["pytest -q"]},
        root=tmp_path,
        witness={"commands": ["python -m pytest -q"], "tools": []},
    )
    assert report.report is not None
    assert report.report["ok"] is True
    assert report.report["tests_ran_verified"] == ["pytest -q"]


def test_truth_claims_tests_ran_accepts_common_run_wrappers(tmp_path: Path) -> None:
    for observed in (
        "uv run pytest -q",
        "poetry run pytest -q",
        "pipenv run pytest -q",
        "bash -lc \"pytest -q\"",
        "bash -lc pytest -q",
        "sh -lc \"pytest -q\"",
        "sh -lc pytest -q",
    ):
        report = evaluate_truth_claims_payload(
            {"tests_ran": ["pytest -q"]},
            root=tmp_path,
            witness={"commands": [observed], "tools": []},
        )
        assert report.report is not None
        assert report.report["ok"] is True
        assert report.report["tests_ran_verified"] == ["pytest -q"]


def test_truth_claims_tests_ran_rejects_reverse_containment_match(tmp_path: Path) -> None:
    report = evaluate_truth_claims_payload(
        {"tests_ran": ["npm test"]},
        root=tmp_path,
        witness={"commands": ["npm test:unit"], "tools": []},
    )
    assert report.report is not None
    assert report.report["ok"] is False
    assert report.report["tests_ran_unverified"] == ["npm test"]


def test_truth_claims_tests_ran_tolerates_trailing_punctuation(tmp_path: Path) -> None:
    report = evaluate_truth_claims_payload(
        {"tests_ran": ["pytest -q."]},
        root=tmp_path,
        witness={"commands": ["pytest -q"], "tools": []},
    )
    assert report.report is not None
    assert report.report["ok"] is True
    assert report.report["tests_ran_verified"] == ["pytest -q"]


def test_validate_requirement_audit_command_accepts_common_run_wrappers(tmp_path: Path) -> None:
    payload = {
        "items": [{"id": "R1", "status": "pass", "evidence": ["cmd:pytest -q"]}],
        "completeness_verdict": "pass",
    }
    for observed in (
        "uv run pytest -q",
        "poetry run pytest -q",
        "pipenv run pytest -q",
        "bash -lc \"pytest -q\"",
        "bash -lc pytest -q",
        "sh -lc \"pytest -q\"",
        "sh -lc pytest -q",
    ):
        details = validate_requirement_audit(
            payload,
            require_evidence_for_passed_requirement=True,
            required_requirement_ids=["R1"],
            root=tmp_path,
            witness={"commands": [observed], "tools": []},
        )
        assert details["ok"] is True
        assert details["errors"] == []
