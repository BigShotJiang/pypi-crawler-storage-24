from __future__ import annotations

import io
import json
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

import cortex
from cortex.hooks import post_tool_use, pre_tool_use, session_start, stop
from cortex.hooks import _shared as shared_hooks


def _enable_strict_stop_contract(root: Path) -> None:
    cfg_path = root / "cortex.toml"
    text = cfg_path.read_text(encoding="utf-8")
    replacements = (
        ('mode = "advisory"', 'mode = "strict"'),
        ("fail_on_missing_challenge_coverage = false", "fail_on_missing_challenge_coverage = true"),
        ("require_requirement_audit = false", "require_requirement_audit = true"),
        ("fail_on_requirement_audit_gap = false", "fail_on_requirement_audit_gap = true"),
    )
    for old, new in replacements:
        assert old in text, old
        text = text.replace(old, new, 1)
    cfg_path.write_text(text, encoding="utf-8")


def _git_init_and_commit(root: Path) -> None:
    subprocess.run(["git", "init"], cwd=root, check=True, capture_output=True, text=True)
    subprocess.run(["git", "add", "."], cwd=root, check=True, capture_output=True, text=True)
    subprocess.run(
        [
            "git",
            "-c",
            "user.name=Cortex Tests",
            "-c",
            "user.email=cortex-tests@example.com",
            "commit",
            "-m",
            "baseline",
        ],
        cwd=root,
        check=True,
        capture_output=True,
        text=True,
    )


@pytest.mark.parametrize(
    ("module", "payload", "expected_hook"),
    [
        (session_start, {"session_id": "sess-hook", "objective": "Start"}, "SessionStart"),
        (pre_tool_use, {"session_id": "sess-hook", "tool_name": "Edit"}, "PreToolUse"),
        (post_tool_use, {"session_id": "sess-hook", "tool_name": "Edit", "status": "ok"}, "PostToolUse"),
        (
            stop,
            {
                "session_id": "sess-hook",
                "run_invariants": False,
                "challenge_coverage": {
                    "null_inputs": True,
                    "boundary_values": True,
                    "error_handling": True,
                    "graveyard_regression": True,
                },
            },
            "Stop",
        ),
    ],
)
def test_hook_main_functions_end_to_end(tmp_project: Path, monkeypatch, capsys, module, payload, expected_hook) -> None:
    monkeypatch.chdir(tmp_project)
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))
    rc = module.main()
    out = capsys.readouterr().out
    data = json.loads(out)
    assert rc == 0
    assert data["ok"] is True
    assert data["hook"] == expected_hook
    assert data["session_id"] == "sess-hook"
    if expected_hook == "SessionStart":
        assert "repomap" in data
        assert isinstance(data["repomap"], dict)
        assert "text" not in data["repomap"]
    if expected_hook == "Stop":
        assert "requirement_audit_report" in data
        assert data["requirement_audit_report"] is None
        assert data["requirement_audit_missing"] is False
        assert data["requirement_audit_gap"] is False


def test_hook_main_supports_root_and_config_args(tmp_project: Path, monkeypatch, capsys) -> None:
    payload = {"session_id": "sess-hook-args", "objective": "Start with args"}
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))

    rc = session_start.main(["--root", str(tmp_project), "--config", str(tmp_project / "cortex.toml")])
    out = capsys.readouterr().out
    data = json.loads(out)

    assert rc == 0
    assert data["ok"] is True
    assert data["hook"] == "SessionStart"
    assert data["session_id"] == "sess-hook-args"


def test_post_tool_use_retry_budget_persists_across_hook_invocations(
    tmp_project: Path, monkeypatch, capsys
) -> None:
    monkeypatch.chdir(tmp_project)
    payload = {"session_id": "sess-hook-retry", "tool_name": "Write", "status": "error", "error": "timeout"}

    for _ in range(3):
        monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))
        rc = post_tool_use.main()
        data = json.loads(capsys.readouterr().out)
        assert rc == 0
        assert data["retry"]["should_retry"] is True
        assert data["retry"]["failure_class"] == "corrective_retryable"

    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))
    rc = post_tool_use.main()
    data = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert data["retry"]["should_retry"] is False
    assert data["retry"]["budget_exhausted"] is True
    assert data["retry"]["failure_class"] == "corrective_retryable"


def test_post_tool_use_hard_gate_failure_is_terminal(
    tmp_project: Path, monkeypatch, capsys
) -> None:
    monkeypatch.chdir(tmp_project)
    payload = {
        "session_id": "sess-hook-hard-stop",
        "tool_name": "Write",
        "status": "error",
        "failure_reason": "stop_gate_failure",
    }
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))
    rc = post_tool_use.main()
    data = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert data["retry"]["should_retry"] is False
    assert data["retry"]["hard_stop"] is True
    assert data["retry"]["failure_class"] == "terminal_hard_gate"
    assert data["proceed"] is False


@pytest.mark.parametrize(
    ("module", "expected_hook"),
    [
        (session_start, "SessionStart"),
        (pre_tool_use, "PreToolUse"),
        (post_tool_use, "PostToolUse"),
        (stop, "Stop"),
    ],
)
def test_hook_main_returns_json_error_on_malformed_payload(
    tmp_project: Path, monkeypatch, capsys, module, expected_hook
) -> None:
    monkeypatch.chdir(tmp_project)
    monkeypatch.setattr(sys, "stdin", io.StringIO("{invalid-json"))

    rc = module.main()
    out = capsys.readouterr().out
    data = json.loads(out)

    assert rc == 1
    assert data["ok"] is False
    assert data["hook"] == expected_hook
    assert "error" in data


def test_hook_main_rejects_legacy_adapter_arg(
    tmp_project: Path, monkeypatch, capsys
) -> None:
    monkeypatch.chdir(tmp_project)
    monkeypatch.setattr(sys, "stdin", io.StringIO("{}"))
    rc = stop.main(["--adapter", "legacy"])
    data = json.loads(capsys.readouterr().out)
    assert rc == 1
    assert data["ok"] is False
    assert data["hook"] == "Stop"
    assert "--adapter is no longer supported" in data["error"]


@pytest.mark.parametrize("schema_version", ["native_hook_v1", "claude_native_v1"])
def test_pre_tool_use_native_schema_aliases_emit_permission_decision(
    tmp_project: Path, monkeypatch, capsys, schema_version: str
) -> None:
    monkeypatch.chdir(tmp_project)
    payload = {"session_id": "sess-native-deny", "tool_name": "vim"}
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))
    rc = pre_tool_use.main(["--schema-version", schema_version])
    data = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert data.get("permissionDecision") == "deny"
    hs = data.get("hookSpecificOutput")
    assert isinstance(hs, dict)
    assert hs.get("hookEventName") == "PreToolUse"
    assert hs.get("permissionDecision") == "deny"
    assert isinstance(hs.get("permissionDecisionReason"), str) and hs["permissionDecisionReason"]


def test_stop_claude_native_schema_blocks_on_stop_contract_violation(
    tmp_project: Path, monkeypatch, capsys
) -> None:
    monkeypatch.chdir(tmp_project)
    cfg_path = tmp_project / "cortex.toml"
    cfg_path.write_text(
        cfg_path.read_text(encoding="utf-8")
        .replace('mode = "advisory"', 'mode = "strict"', 1)
        .replace(
            "require_evidence_for_passed_requirement = true",
            "\n".join(
                [
                    "require_evidence_for_passed_requirement = true",
                    "require_structured_stop_payload = true",
                    "allow_message_stop_fallback = false",
                ]
            ),
            1,
        ),
        encoding="utf-8",
    )
    payload = {"session_id": "sess-native-stop", "run_invariants": False}
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))
    rc = stop.main(["--schema-version", "claude_native_v1"])
    data = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert data.get("decision") == "block"
    assert isinstance(data.get("reason"), str) and data["reason"]


def test_stop_native_schema_surfaces_stuck_reason(
    tmp_project: Path, monkeypatch, capsys
) -> None:
    monkeypatch.chdir(tmp_project)

    class _FakeKernel:
        def __init__(self, **_: object) -> None:
            pass

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            assert event == "stop"
            return {
                "proceed": False,
                "feedback_mode": "stuck",
                "stuck_declared": True,
                "stuck_declaration": {
                    "check": "truth_claims",
                    "approaches_tried": ["git status", "re-read stop diagnostics"],
                    "obstacle": "session-scoped delta does not show the claimed file",
                },
                "warnings": [
                    "Truth claims reported gaps: truth_claims.modified_files not observed in repository changes: src/claimed.py"
                ],
            }

    monkeypatch.setattr(shared_hooks, "CortexKernel", _FakeKernel)
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-native-stuck"})))

    rc = stop.main(["--schema-version", "claude_native_v1"])
    data = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert data == {
        "continue": False,
        "stopReason": "Cortex reported stuck on truth_claims: session-scoped delta does not show the claimed file",
    }


def test_stop_claude_native_non_stuck_block_still_uses_block_decision(
    tmp_project: Path, monkeypatch, capsys
) -> None:
    monkeypatch.chdir(tmp_project)

    class _FakeKernel:
        def __init__(self, **_: object) -> None:
            pass

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            assert event == "stop"
            return {
                "proceed": False,
                "warnings": [
                    "Truth claims reported gaps: truth_claims.modified_files not observed in repository changes: src/claimed.py"
                ],
            }

    monkeypatch.setattr(shared_hooks, "CortexKernel", _FakeKernel)
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-native-block"})))

    rc = stop.main(["--schema-version", "claude_native_v1"])
    data = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert data == {
        "decision": "block",
        "reason": "Truth claims reported gaps: truth_claims.modified_files not observed in repository changes: src/claimed.py",
    }


def test_stop_claude_native_truth_gap_blocks_with_git_backed_session_delta(
    tmp_project: Path,
    monkeypatch,
    capsys,
) -> None:
    monkeypatch.chdir(tmp_project)
    claimed_file = tmp_project / "src" / "claimed.py"
    claimed_file.write_text("VALUE = 1\n", encoding="utf-8")
    _enable_strict_stop_contract(tmp_project)
    _git_init_and_commit(tmp_project)

    monkeypatch.setattr(
        sys,
        "stdin",
        io.StringIO(json.dumps({"session_id": "sess-native-truth", "objective": "truth-gap lane"})),
    )
    assert session_start.main() == 0
    _ = capsys.readouterr()

    payload = {
        "session_id": "sess-native-truth",
        "run_invariants": False,
        "challenge_coverage": {
            category: {"covered": True, "evidence": ["src/claimed.py"]}
            for category in ("null_inputs", "boundary_values", "error_handling", "graveyard_regression")
        },
        "requirement_audit": {
            "items": [{"id": "BUGFIX", "status": "pass", "evidence": ["src/claimed.py"]}],
            "completeness_verdict": "pass",
        },
        "truth_claims": {
            "modified_files": ["src/unmodified.py"],
            "tests_ran": ["python -m pytest -q tests/test_normalize_port.py"],
        },
    }
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))

    rc = stop.main(["--schema-version", "claude_native_v1"])
    data = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert data["decision"] == "block"
    assert "Truth claims reported gaps" in data["reason"]
    assert "src/unmodified.py" in data["reason"]


def test_stop_claude_native_prefers_challenge_gap_reason_over_informational_warning(
    tmp_project: Path,
    monkeypatch,
    capsys,
) -> None:
    monkeypatch.chdir(tmp_project)

    class _FakeKernel:
        def __init__(self, **_: object) -> None:
            pass

        def dispatch(self, event: str, payload: dict[str, object]) -> dict[str, object]:
            assert event == "stop"
            return {
                "proceed": False,
                "structured_stop_violation": False,
                "challenge_coverage_missing": False,
                "challenge_report": {"ok": False},
                "warnings": [
                    "Using challenge_coverage from payload.stop_fields.",
                    "Missing challenge coverage for categories: null_inputs, boundary_values",
                    "Challenge coverage 'null_inputs' marked covered but evidence is unverified: covered=true requires non-empty evidence list",
                ],
            }

    monkeypatch.setattr(shared_hooks, "CortexKernel", _FakeKernel)
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-native-challenge"})))

    rc = stop.main(["--schema-version", "claude_native_v1"])
    data = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert data == {
        "decision": "block",
        "reason": "Missing challenge coverage for categories: null_inputs, boundary_values",
    }


def test_claude_boundary_evidence_survives_missing_session_start(
    tmp_project: Path,
    monkeypatch,
    capsys,
) -> None:
    monkeypatch.chdir(tmp_project)
    pre_payload = {"session_id": "sess-no-start", "tool_name": "Read", "tool_input": {"path": "README.md"}}
    post_payload = {
        "session_id": "sess-no-start",
        "tool_name": "Read",
        "tool_input": {"path": "README.md"},
        "tool_response": {"ok": True},
        "status": "ok",
    }
    stop_payload = {
        "session_id": "sess-no-start",
        "run_invariants": False,
        "challenge_coverage": {
            "null_inputs": True,
            "boundary_values": True,
            "error_handling": True,
            "graveyard_regression": True,
        },
    }

    for module, payload in ((pre_tool_use, pre_payload), (post_tool_use, post_payload), (stop, stop_payload)):
        monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))
        assert module.main() == 0
        _ = json.loads(capsys.readouterr().out)

    with sqlite3.connect(tmp_project / ".cortex" / "cortex.db") as conn:
        rows = conn.execute(
            """
            SELECT hook
            FROM events
            WHERE session_id = ?
            ORDER BY id ASC
            """,
            ("sess-no-start",),
        ).fetchall()

    assert [row[0] for row in rows] == ["PreToolUse", "PostToolUse", "Stop"]


def test_stop_legacy_schema_rolls_back_to_kernel_json_shape(
    tmp_project: Path, monkeypatch, capsys
) -> None:
    monkeypatch.chdir(tmp_project)
    payload = {"session_id": "sess-legacy-stop", "run_invariants": False}
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))
    rc = stop.main(["--schema-version", "legacy_json_v0"])
    data = json.loads(capsys.readouterr().out)
    assert rc == 0
    assert data["hook"] == "Stop"
    assert "warnings" in data


def test_marker_emits_session_marker_with_kernel_timestamp(
    tmp_project: Path, monkeypatch
) -> None:
    monkeypatch.chdir(tmp_project)
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"session_id": "sess-marker", "objective": "Audit"})))
    assert session_start.main() == 0

    result = cortex.marker("audit_complete", session_id="sess-marker")
    assert result["hook"] == "SessionMarker"
    assert result["label"] == "audit_complete"
    assert result["session_id"] == "sess-marker"

    with sqlite3.connect(tmp_project / ".cortex" / "cortex.db") as conn:
        row = conn.execute(
            """
            SELECT session_id, hook, payload_json, created_at
            FROM events
            WHERE session_id = ? AND hook = ?
            ORDER BY id DESC
            LIMIT 1
            """,
            ("sess-marker", "SessionMarker"),
        ).fetchone()
    assert row is not None
    assert row[0] == "sess-marker"
    assert row[1] == "SessionMarker"
    assert json.loads(row[2]) == {"label": "audit_complete"}
    assert isinstance(row[3], str) and row[3]


def test_marker_requires_session_id() -> None:
    with pytest.raises(ValueError, match="requires session_id"):
        cortex.marker("audit_complete", session_id="")
