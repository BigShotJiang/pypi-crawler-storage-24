import copy
import traceback
from dataclasses import asdict, dataclass, fields, is_dataclass
from enum import Enum
from io import StringIO

# IDEA: we can add a logging and json adapter

# NOTE: don't forget to use ExceptionGroups when needed


class ExceptionExtended(Exception):
	# same as raise from
	def caused_by(self, exc: Exception):
		self.__cause__ = exc  # also sets __suppress_context__ implicitly
		return self

	def clone(self):
		return copy.deepcopy(self)

	def traceback_message(self) -> str:
		file = StringIO()
		traceback.print_exception(type(self), value=self, tb=self.__traceback__, file=file)
		return file.read()


@dataclass(frozen=True)
class StructuredException(ExceptionExtended):
	"""
	Base class for structured exceptions.

	Automatically forwards dataclass field values (in order)
	into Exception.__init__ as args.
	"""

	def __post_init__(self):
		values = self._get_fields().values()

		# Initialize Exception with those values
		super().__init__(*values)

	def __str__(self):
		return f"{self.__class__.__name__}({self.message()})"

	def __repr__(self):
		return str(self)

	def _get_fields(self):
		# Extract field values in declared order, also filter field(metadata={"exclude_from_args": True})
		return {
			f.name: getattr(self, f.name)
			for f in fields(self)
			if not f.metadata.get("exclude_from_args", False) and not f.name.startswith("_")
		}

	def message(self):
		parts = [f"{name}={value!r}" for name, value in self._get_fields().items()]
		return ", ".join(parts)

	def as_dict(self):
		return asdict(self)

	def as_tuple(self):
		return self.args

	def with_updates(self, **kwargs):
		# dataclasses.asdict work with recursive deepcopy under the hood
		data = self.as_dict()
		data.update(kwargs)
		return self.from_dict(**data)

	@classmethod
	def from_dict(cls, **data):
		def from_dict_util(typ, data):
			kwargs = {}
			for f in fields(typ):
				value = data[f.name]
				if is_dataclass(f.type):
					value = from_dict_util(f.type, value)
				kwargs[f.name] = value
			return typ(**kwargs)

		return from_dict_util(cls, data)


@dataclass(frozen=True)
class AppError(StructuredException):
	pass


# IDEA: AppEnumError error


# IDEA: alternative name: SimpleError or SingletonError?
@dataclass(frozen=True)
class AppErrorMessage(AppError):
	msg: str

	def message(self):
		return self.msg
