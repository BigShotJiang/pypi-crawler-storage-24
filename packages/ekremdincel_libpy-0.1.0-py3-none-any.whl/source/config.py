import json
from pathlib import Path
from typing import Protocol, TypeVar

from pydantic import BaseModel, ConfigDict, Field, RootModel

# TODO: use pydantic-settings instead of pydantic
# https://docs.pydantic.dev/latest/concepts/pydantic_settings/#usage


# -------------------------
# Custom Base Classes
# -------------------------


class Serializer(Protocol):
	"""
	Duck-typed serializer that works with bytes.
	"""

	def dumps(self, data: dict) -> bytes:
		"""Serialize a dict to bytes"""
		...

	def loads(self, b: bytes) -> dict:
		"""Deserialize bytes into a dict"""
		...


def _json_serializer_default(o):
	if isinstance(o, Path):
		return str(o)
	raise TypeError(f"Object of type {type(o)} is not JSON serializable")


class JsonSerializer:
	def dumps(self, data: dict[str, object]) -> bytes:
		return json.dumps(data, indent=4, ensure_ascii=False, default=_json_serializer_default).encode("utf-8")

	def loads(self, b: bytes) -> dict[str, object]:
		return json.loads(b.decode("utf-8"))  # object_hook can be used to process special types if needed


json_serializer = JsonSerializer()

T = TypeVar("T", bound="ConfigBaseModel")


class ConfigBaseModel(BaseModel):
	"""
	Base class for all config models.
	Provides load/save utilities.
	"""

	# see https://docs.pydantic.dev/1.10/usage/model_config/
	model_config = ConfigDict(
		# json_encoders={Path: str}, # not needed
		validate_assignment=True,
		# arbitrary_types_allowed=True,  # Accept any type for field declarations even if they are not pydantic models or standard types.
		arbitrary_types_allowed=False,
	)

	@classmethod
	def loads(cls: type[T], data: bytes, *, serializer: Serializer = json_serializer) -> T:
		data = serializer.loads(data)
		return cls.model_validate(data)

	def dumps(self, *, serializer: Serializer = json_serializer, exclude: list[str] | None = None) -> bytes:
		return serializer.dumps(self.model_dump(exclude=exclude))

	# https://docs.pydantic.dev/1.10/usage/exporting_models/
	@classmethod
	def load(
		cls: type[T],
		path: str | Path,
		*,
		serializer: Serializer = json_serializer,
		write_default: bool = True,
		default: T | None = None,
		exclude: list[str] | None = None,
	) -> T:
		path = Path(path)

		if not path.exists():
			if write_default:
				cls._ensure_parent_dir(path)
				default_config = default or cls()
				path.write_bytes(default_config.dumps(serializer=serializer))
				return default_config
			raise FileNotFoundError(path)

		b = path.read_bytes()
		model_object = cls.loads(b, serializer=serializer)

		# saving the loaded model ensures that any new default fields are mirrored on config file
		model_object.dump(path, serializer=serializer, exclude=exclude)
		return model_object

	def dump(
		self, path: str | Path, *, serializer: Serializer = json_serializer, exclude: list[str] | None = None
	) -> None:
		path = Path(path)
		self._ensure_parent_dir(path)
		path.write_bytes(self.dumps(serializer=serializer, exclude=exclude))

	@staticmethod
	def _ensure_parent_dir(path: Path) -> None:
		if path.parent.exists() and not path.parent.is_dir():
			raise NotADirectoryError(f"{path.parent} exists but is not a directory")

		path.parent.mkdir(parents=True, exist_ok=True)

	@classmethod
	def from_parent_instance(cls, instance: BaseModel, **kwargs) -> BaseModel:
		"""Create a new instance of the class using the fields of a parent instance."""
		fields = instance.as_dict()
		fields.update(kwargs)
		return cls(**fields)

	def as_dict(self) -> dict:
		"""Convert a pydantic model instance to a dict. Alias for model_dump()."""
		return self.model_dump()


R = TypeVar("R")


class ConfigRootModel(RootModel[R]):
	"""
	Base class for root models (dict-like configs).
	You can extend this later with shared behavior.
	"""

