import hashlib
import os
import sys
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT_DIR = Path(__file__).resolve().parent.parent

TEMP_ENV_1 = "TEMP"
TEMP_ENV_2 = "TMP"
DEFAULT_TEMP_DIR_1 = PROJECT_ROOT_DIR / ".temp"
DEFAULT_TEMP_DIR_2 = Path(PROJECT_ROOT_DIR.drive) / ".temp"

CACHE_ENV = "CACHE_DIR"
DEFAULT_CACHE_DIR = PROJECT_ROOT_DIR / ".cache"


@dataclass
class Cache:
	title: str

	def _hash_key(self, key_string: str | bytes) -> str:
		key_bytes = key_string.encode() if isinstance(key_string, str) else key_string
		return hashlib.sha256(key_bytes).hexdigest()

	def _cache_file(self, key_string: str | bytes) -> Path:
		cache_dir = get_cache_dir()
		hashed = self._hash_key(key_string)
		return cache_dir / f"{self.title}_{hashed}.cache"

	def set(self, key_string: str | bytes, data: bytes) -> Path:
		cache_file = self._cache_file(key_string)
		cache_file.write_bytes(data)
		return cache_file

	def get(self, key_string: str | bytes) -> bytes | None:
		cache_file = self._cache_file(key_string)
		if cache_file.exists() and cache_file.is_file():
			return cache_file.read_bytes()
		return None

