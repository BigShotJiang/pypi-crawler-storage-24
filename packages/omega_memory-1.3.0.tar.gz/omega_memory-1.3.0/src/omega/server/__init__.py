"""OMEGA MCP Server package."""
