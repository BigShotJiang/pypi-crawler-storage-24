"""Context0 — one import, all calls logged."""

from llm_observatory.config import configure
from llm_observatory.client import (
    Anthropic,
    AsyncAnthropic,
    AsyncAzureOpenAI,
    AsyncOpenAI,
    AzureOpenAI,
    OpenAI,
    wrap,
)
from llm_observatory.tracing import (
    emit_completed_span,
    get_current_traceparent,
    observe,
    span,
    trace,
)

__all__ = [
    "Anthropic",
    "AsyncAnthropic",
    "AsyncAzureOpenAI",
    "AsyncOpenAI",
    "AzureOpenAI",
    "OpenAI",
    "configure",
    "wrap",
    "emit_completed_span",
    "get_current_traceparent",
    "observe",
    "span",
    "trace",
]
