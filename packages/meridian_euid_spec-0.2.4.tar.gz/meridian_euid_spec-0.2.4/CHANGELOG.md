# Changelog

All notable changes to this project are documented in this file.

This project follows [Semantic Versioning](https://semver.org/) for the specification and reference implementations.

## [Unreleased]

_No unreleased changes._

## [0.1.0pre] - 2026-02-08

### Added
- `encode()` function: integer + category + sandbox? → EUID (Python, TypeScript)
- `parse()` function: EUID → components + decoded integer (Python, TypeScript)
- Python CLI `encode` and `parse` subcommands
- §12 Operational Role of Structural Components (SPEC.md)
- §16 Checksum Error Detection Properties (SPEC.md)
- GitHub Actions CI workflow for Python implementation
- `ruff` formatting and `mypy` type checking

### Changed
- SPEC.md rewritten (new grammar: `[SANDBOX ":"] CATEGORY "-" BODY CHECKSUM`)
- CATEGORY minimum length: 1 → 2 characters (now 2–3)
- Reserved sandbox prefixes expanded: A only → A–G inclusive (7 reserved, 15 available)
- Uppercase-only enforcement: lowercase input MUST be rejected (no normalization)
- Checksum system changed to Luhn-style MOD 32 over Crockford Base32 (SPEC.md §7.5)
- V2_SPEC.md renamed to SPEC.md (all cross-references resolved)
- Test vectors regenerated with 2-char+ categories, expanded coverage (30 cases)
- Validation order clarified: input rejection → syntax → checksum → authorization
- Coverage threshold lowered from 100% to 75% (88% achieved)

### Removed
- Legacy v1 test vectors file (`test-vectors/v1.json`)
- Lowercase normalization (replaced with strict rejection)

## [1.0.0-draft] - 2026-02-04

### Added
- Initial public draft of the Meridian EUID specification ([SPEC.md](SPEC.md))
- Machine-readable test vectors v1 (deprecated; removed in 0.1.0pre — see git history)
- Non-normative Python reference implementation
- Non-normative TypeScript reference implementation
- CC BY 4.0 license for specification content

### Specification Highlights
- Production and sandbox EUID syntax with strict environment segregation
- ISO/IEC 7064 MOD 37-2 checksum with supplementary character `*` forbidden
- Canonical form enforcement (uppercase only, no normalization)
