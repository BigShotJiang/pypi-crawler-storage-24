# Project-specific Augment instructions (default)

No additional project-specific agent rules are defined for this repository.

Follow the global Augment rules and the repository's documented conventions.
