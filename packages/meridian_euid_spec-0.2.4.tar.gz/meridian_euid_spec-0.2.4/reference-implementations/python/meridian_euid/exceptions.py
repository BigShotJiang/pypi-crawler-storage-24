from __future__ import annotations


class EUIDError(ValueError):
    """Base error for Meridian EUID validation failures."""


class EUIDFormatError(EUIDError):
    """Raised when an EUID fails environment-specific syntax or canonical-form requirements."""


class EUIDChecksumError(EUIDError):
    """Raised when an EUID fails checksum computation or verification."""


class EUIDSandboxPrefixError(EUIDError):
    """Raised when an EUID's sandbox prefix is not allowed for the current context."""
