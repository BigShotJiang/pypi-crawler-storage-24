"""Meridian EUID non-normative reference implementation (Python)."""

from .euid import (
    RESERVED_SANDBOX_PREFIXES,
    VALID_SANDBOX_PREFIXES,
    Environment,
    compute_check_character,
    encode,
    is_valid,
    parse,
    validate,
    validate_category,
    validate_sandbox_token,
)
from .exceptions import (
    EUIDChecksumError,
    EUIDError,
    EUIDFormatError,
    EUIDSandboxPrefixError,
)

from importlib.metadata import PackageNotFoundError, version as _get_version

try:
    __version__ = _get_version("meridian-euid")
except PackageNotFoundError:
    __version__ = "0.0.0.dev0"

__all__ = [
    "__version__",
    "RESERVED_SANDBOX_PREFIXES",
    "VALID_SANDBOX_PREFIXES",
    "Environment",
    "compute_check_character",
    "encode",
    "is_valid",
    "parse",
    "validate",
    "validate_category",
    "validate_sandbox_token",
    "EUIDError",
    "EUIDFormatError",
    "EUIDChecksumError",
    "EUIDSandboxPrefixError",
]
