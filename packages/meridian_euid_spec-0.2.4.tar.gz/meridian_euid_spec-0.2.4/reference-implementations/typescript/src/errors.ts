export class EuidError extends Error {
  constructor(message: string) {
    super(message);
    this.name = this.constructor.name;
  }
}

export class EuidFormatError extends EuidError {}
export class EuidChecksumError extends EuidError {}
export class EuidSandboxPrefixError extends EuidError {}
