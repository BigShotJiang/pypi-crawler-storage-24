# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""ClawTex memory subsystem — MandelDB-backed semantic recall and ingest."""

from .context import MemoryContext
from .mandeldb import MandelDBClient

__all__ = ["MandelDBClient", "MemoryContext"]
