# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""ClawTex channel adapters — Telegram, Slack, Moltbook, and base interface."""

from .base import BaseChannel, InboundMessage, MessageHandler, OutboundMessage
from .telegram import TelegramChannel
from .slack import SlackChannel
from .moltbook import MoltbookChannel

__all__ = [
    "BaseChannel",
    "InboundMessage",
    "OutboundMessage",
    "MessageHandler",
    "TelegramChannel",
    "SlackChannel",
    "MoltbookChannel",
]
