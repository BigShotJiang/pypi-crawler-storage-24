"""
tests/run_tests.py
~~~~~~~~~~~~~~~~~~
Runs all tests without requiring pytest (stdlib only).
"""
import sys, os, threading, time, unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import flakeid
from flakeid import (
    SnowflakeGenerator, make_generator, make_generator_from_env,
    PRESET_TWITTER, PRESET_MINIMAL, PRESET_SINGLE_DC,
    PRESET_LARGE_CLUSTER, PRESET_HIGH_THROUGHPUT,
    ClockBackwardsError, EpochError,
)


def make_twitter(**kw):
    return make_generator(PRESET_TWITTER, **kw)


class TestConstruction(unittest.TestCase):

    def test_valid_twitter_preset(self):
        gen = make_twitter()
        self.assertEqual(gen.timestamp_bits, 41)
        self.assertEqual(gen.datacenter_bits, 5)
        self.assertEqual(gen.machine_bits, 5)
        self.assertEqual(gen.sequence_bits, 12)

    def test_bit_total_must_be_63(self):
        with self.assertRaises(ValueError):
            SnowflakeGenerator(timestamp_bits=41, datacenter_bits=5, machine_bits=5, sequence_bits=11)

    def test_datacenter_id_out_of_range(self):
        with self.assertRaises(ValueError):
            make_twitter(datacenter_id=32)

    def test_machine_id_out_of_range(self):
        with self.assertRaises(ValueError):
            make_twitter(machine_id=32)

    def test_zero_node_bits_ok(self):
        gen = make_generator(PRESET_MINIMAL)
        self.assertEqual(gen.datacenter_bits, 0)
        self.assertEqual(gen.machine_bits, 0)
        self.assertGreater(gen.next_id(), 0)

    def test_repr(self):
        r = repr(make_twitter(datacenter_id=1, machine_id=2))
        self.assertIn("41b", r)


class TestIDGeneration(unittest.TestCase):

    def test_returns_positive_int(self):
        gen = make_twitter()
        self.assertIsInstance(gen.next_id(), int)
        self.assertGreater(gen.next_id(), 0)

    def test_fits_in_64_bits(self):
        gen = make_twitter()
        for _ in range(1000):
            self.assertLess(gen.next_id(), 1 << 63)

    def test_monotonically_increasing(self):
        gen = make_twitter()
        ids = [gen.next_id() for _ in range(500)]
        self.assertEqual(ids, sorted(ids))

    def test_unique_sequential(self):
        gen = make_twitter()
        ids = [gen.next_id() for _ in range(5000)]
        self.assertEqual(len(set(ids)), 5000)

    def test_next_ids_bulk(self):
        gen = make_twitter()
        ids = gen.next_ids(1000)
        self.assertEqual(len(ids), 1000)
        self.assertEqual(len(set(ids)), 1000)

    def test_stream_iterator(self):
        gen = make_twitter()
        collected = []
        for uid in gen.stream():
            collected.append(uid)
            if len(collected) == 200:
                break
        self.assertEqual(len(set(collected)), 200)


class TestThreadSafety(unittest.TestCase):

    def test_unique_across_threads(self):
        gen = make_twitter()
        results = []
        lock = threading.Lock()

        def worker():
            local = gen.next_ids(500)
            with lock:
                results.extend(local)

        threads = [threading.Thread(target=worker) for _ in range(20)]
        for t in threads: t.start()
        for t in threads: t.join()

        self.assertEqual(len(results), 10_000)
        self.assertEqual(len(set(results)), 10_000)


class TestModuleLevelAPI(unittest.TestCase):

    def test_next_id(self):
        uid = flakeid.next_id()
        self.assertIsInstance(uid, int)
        self.assertGreater(uid, 0)

    def test_next_ids(self):
        ids = flakeid.next_ids(50)
        self.assertEqual(len(set(ids)), 50)


class TestDecode(unittest.TestCase):

    def test_round_trip(self):
        gen = make_twitter(datacenter_id=3, machine_id=7)
        uid = gen.next_id()
        dec = gen.decode(uid)
        self.assertEqual(dec.raw, uid)
        self.assertEqual(dec.datacenter_id, 3)
        self.assertEqual(dec.machine_id, 7)

    def test_timestamp_is_recent(self):
        gen = make_twitter()
        uid = gen.next_id()
        dec = gen.decode(uid)
        now_ms = int(time.time() * 1000)
        self.assertLess(abs(dec.timestamp_ms - now_ms), 2000)

    def test_generated_at_iso(self):
        gen = make_twitter()
        iso = gen.decode(gen.next_id()).generated_at
        self.assertTrue(iso.endswith("Z"))
        self.assertIn("T", iso)

    def test_zero_node_bits(self):
        gen = make_generator(PRESET_MINIMAL)
        dec = gen.decode(gen.next_id())
        self.assertEqual(dec.datacenter_id, 0)
        self.assertEqual(dec.machine_id, 0)


class TestCapacity(unittest.TestCase):

    def test_twitter_capacity(self):
        cap = make_twitter().capacity()
        self.assertEqual(cap.max_datacenters, 32)
        self.assertEqual(cap.max_machines_per_dc, 32)
        self.assertEqual(cap.total_nodes, 1024)
        self.assertEqual(cap.ids_per_ms_per_node, 4096)
        self.assertGreater(cap.timestamp_range_years, 60)

    def test_minimal_capacity(self):
        cap = make_generator(PRESET_MINIMAL).capacity()
        self.assertEqual(cap.total_nodes, 1)
        self.assertGreater(cap.timestamp_range_years, 200)


class TestPresets(unittest.TestCase):

    def test_all_presets_produce_ids(self):
        for preset in [PRESET_TWITTER, PRESET_MINIMAL, PRESET_SINGLE_DC,
                       PRESET_LARGE_CLUSTER, PRESET_HIGH_THROUGHPUT]:
            gen = make_generator(preset)
            ids = gen.next_ids(10)
            self.assertEqual(len(set(ids)), 10)

    def test_preset_by_name_twitter(self):
        self.assertEqual(make_generator("twitter").datacenter_bits, 5)

    def test_preset_by_name_invalid(self):
        with self.assertRaises(ValueError):
            make_generator("nonexistent")

    def test_preset_override(self):
        gen = make_generator(PRESET_TWITTER, machine_id=15)
        self.assertEqual(gen.machine_id, 15)


class TestEnvFactory(unittest.TestCase):

    def test_reads_env_vars(self):
        os.environ["FLAKEID_DATACENTER_ID"] = "4"
        os.environ["FLAKEID_MACHINE_ID"] = "9"
        gen = make_generator_from_env(PRESET_TWITTER)
        self.assertEqual(gen.datacenter_id, 4)
        self.assertEqual(gen.machine_id, 9)
        del os.environ["FLAKEID_DATACENTER_ID"]
        del os.environ["FLAKEID_MACHINE_ID"]

    def test_missing_env_vars_use_defaults(self):
        os.environ.pop("FLAKEID_DATACENTER_ID", None)
        os.environ.pop("FLAKEID_MACHINE_ID", None)
        gen = make_generator_from_env(PRESET_TWITTER)
        self.assertEqual(gen.datacenter_id, 0)
        self.assertEqual(gen.machine_id, 0)


class TestErrors(unittest.TestCase):

    def test_clock_backwards_large_raises(self):
        gen = make_twitter()
        gen._last_timestamp_ms = int(time.time() * 1000) + 100_000
        with self.assertRaises(ClockBackwardsError):
            gen.next_id()

    def test_epoch_error_future_epoch(self):
        future_epoch = int(time.time() * 1000) + 9_999_999_999
        gen = SnowflakeGenerator(
            timestamp_bits=41, datacenter_bits=5,
            machine_bits=5, sequence_bits=12,
            epoch_ms=future_epoch,
        )
        with self.assertRaises(EpochError):
            gen.next_id()


if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()
    for cls in [
        TestConstruction, TestIDGeneration, TestThreadSafety,
        TestModuleLevelAPI, TestDecode, TestCapacity,
        TestPresets, TestEnvFactory, TestErrors,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
