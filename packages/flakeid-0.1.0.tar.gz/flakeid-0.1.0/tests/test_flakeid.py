"""
tests/test_flakeid.py
~~~~~~~~~~~~~~~~~~~~~
Full test suite for flakeid.
"""

import threading
import time
import pytest

import flakeid
from flakeid import (
    SnowflakeGenerator,
    make_generator,
    make_generator_from_env,
    PRESET_TWITTER,
    PRESET_MINIMAL,
    PRESET_SINGLE_DC,
    PRESET_LARGE_CLUSTER,
    PRESET_HIGH_THROUGHPUT,
    ClockBackwardsError,
    EpochError,
    TimestampOverflowError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_twitter(**kw) -> SnowflakeGenerator:
    return make_generator(PRESET_TWITTER, **kw)


# ---------------------------------------------------------------------------
# Construction validation
# ---------------------------------------------------------------------------

class TestConstruction:

    def test_valid_twitter_preset(self):
        gen = make_twitter()
        assert gen.timestamp_bits  == 41
        assert gen.datacenter_bits == 5
        assert gen.machine_bits    == 5
        assert gen.sequence_bits   == 12

    def test_bit_total_must_be_63(self):
        with pytest.raises(ValueError, match="63"):
            SnowflakeGenerator(
                timestamp_bits=41, datacenter_bits=5,
                machine_bits=5, sequence_bits=11,  # sums to 62
            )

    def test_negative_bits_rejected(self):
        with pytest.raises(ValueError):
            SnowflakeGenerator(
                timestamp_bits=41, datacenter_bits=-1,
                machine_bits=6, sequence_bits=17,
            )

    def test_zero_sequence_bits_rejected(self):
        with pytest.raises(ValueError):
            SnowflakeGenerator(
                timestamp_bits=62, datacenter_bits=0,
                machine_bits=0, sequence_bits=0,
            )

    def test_datacenter_id_out_of_range(self):
        with pytest.raises(ValueError, match="datacenter_id"):
            make_twitter(datacenter_id=32)   # 5 bits → max 31

    def test_machine_id_out_of_range(self):
        with pytest.raises(ValueError, match="machine_id"):
            make_twitter(machine_id=32)

    def test_zero_node_bits_ok(self):
        gen = make_generator(PRESET_MINIMAL)
        assert gen.datacenter_bits == 0
        assert gen.machine_bits    == 0
        uid = gen.next_id()
        assert uid > 0

    def test_repr(self):
        gen = make_twitter(datacenter_id=1, machine_id=2)
        r = repr(gen)
        assert "41b" in r
        assert "id=1" in r
        assert "id=2" in r


# ---------------------------------------------------------------------------
# ID generation — basic properties
# ---------------------------------------------------------------------------

class TestIDGeneration:

    def test_returns_positive_int(self):
        gen = make_twitter()
        uid = gen.next_id()
        assert isinstance(uid, int)
        assert uid > 0

    def test_fits_in_64_bits(self):
        gen = make_twitter()
        for _ in range(1000):
            uid = gen.next_id()
            assert uid < (1 << 63)

    def test_monotonically_increasing(self):
        gen = make_twitter()
        ids = [gen.next_id() for _ in range(500)]
        assert ids == sorted(ids)

    def test_unique_sequential(self):
        gen = make_twitter()
        ids = [gen.next_id() for _ in range(5000)]
        assert len(set(ids)) == 5000

    def test_next_ids_bulk(self):
        gen = make_twitter()
        ids = gen.next_ids(1000)
        assert len(ids) == 1000
        assert len(set(ids)) == 1000

    def test_next_ids_count_zero_raises(self):
        gen = make_twitter()
        with pytest.raises(ValueError):
            gen.next_ids(0)

    def test_stream_iterator(self):
        gen = make_twitter()
        collected = []
        for uid in gen.stream():
            collected.append(uid)
            if len(collected) == 200:
                break
        assert len(set(collected)) == 200


# ---------------------------------------------------------------------------
# Thread safety
# ---------------------------------------------------------------------------

class TestThreadSafety:

    def test_unique_across_threads(self):
        gen = make_twitter()
        results: list[int] = []
        lock = threading.Lock()

        def worker():
            local = gen.next_ids(500)
            with lock:
                results.extend(local)

        threads = [threading.Thread(target=worker) for _ in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(results) == 10_000
        assert len(set(results)) == 10_000


# ---------------------------------------------------------------------------
# Module-level default generator
# ---------------------------------------------------------------------------

class TestModuleLevelAPI:

    def test_next_id_returns_int(self):
        uid = flakeid.next_id()
        assert isinstance(uid, int)
        assert uid > 0

    def test_next_ids_returns_list(self):
        ids = flakeid.next_ids(50)
        assert len(ids) == 50
        assert len(set(ids)) == 50


# ---------------------------------------------------------------------------
# Decode
# ---------------------------------------------------------------------------

class TestDecode:

    def test_round_trip(self):
        gen  = make_twitter(datacenter_id=3, machine_id=7)
        uid  = gen.next_id()
        dec  = gen.decode(uid)
        assert dec.raw           == uid
        assert dec.datacenter_id == 3
        assert dec.machine_id    == 7
        assert dec.sequence      >= 0

    def test_timestamp_is_recent(self):
        gen = make_twitter()
        uid = gen.next_id()
        dec = gen.decode(uid)
        now_ms = int(time.time() * 1000)
        assert abs(dec.timestamp_ms - now_ms) < 2000   # within 2 seconds

    def test_generated_at_iso_format(self):
        gen = make_twitter()
        uid = gen.next_id()
        iso = gen.decode(uid).generated_at
        assert iso.endswith("Z")
        assert "T" in iso

    def test_decode_with_zero_node_bits(self):
        gen = make_generator(PRESET_MINIMAL)
        uid = gen.next_id()
        dec = gen.decode(uid)
        assert dec.datacenter_id == 0
        assert dec.machine_id    == 0


# ---------------------------------------------------------------------------
# Capacity
# ---------------------------------------------------------------------------

class TestCapacity:

    def test_twitter_capacity(self):
        cap = make_twitter().capacity()
        assert cap.max_datacenters      == 32
        assert cap.max_machines_per_dc  == 32
        assert cap.total_nodes          == 1024
        assert cap.ids_per_ms_per_node  == 4096
        assert cap.ids_per_sec_per_node == 4_096_000
        assert cap.timestamp_range_years > 60

    def test_minimal_capacity(self):
        cap = make_generator(PRESET_MINIMAL).capacity()
        assert cap.max_datacenters == 1
        assert cap.max_machines_per_dc == 1
        assert cap.total_nodes == 1
        assert cap.timestamp_range_years > 200

    def test_repr(self):
        cap = make_twitter().capacity()
        assert "nodes=" in repr(cap)


# ---------------------------------------------------------------------------
# Presets
# ---------------------------------------------------------------------------

class TestPresets:

    @pytest.mark.parametrize("preset", [
        PRESET_TWITTER,
        PRESET_MINIMAL,
        PRESET_SINGLE_DC,
        PRESET_LARGE_CLUSTER,
        PRESET_HIGH_THROUGHPUT,
    ])
    def test_all_presets_produce_ids(self, preset):
        gen = make_generator(preset)
        ids = gen.next_ids(10)
        assert len(set(ids)) == 10

    def test_preset_by_name_twitter(self):
        gen = make_generator("twitter")
        assert gen.datacenter_bits == 5

    def test_preset_by_name_invalid(self):
        with pytest.raises(ValueError, match="Unknown preset"):
            make_generator("nonexistent")

    def test_preset_override(self):
        gen = make_generator(PRESET_TWITTER, machine_id=15)
        assert gen.machine_id == 15


# ---------------------------------------------------------------------------
# Environment variable factory
# ---------------------------------------------------------------------------

class TestEnvFactory:

    def test_reads_env_vars(self, monkeypatch):
        monkeypatch.setenv("FLAKEID_DATACENTER_ID", "4")
        monkeypatch.setenv("FLAKEID_MACHINE_ID",    "9")
        gen = make_generator_from_env(PRESET_TWITTER)
        assert gen.datacenter_id == 4
        assert gen.machine_id    == 9

    def test_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("FLAKEID_MACHINE_ID", "9")
        gen = make_generator_from_env(PRESET_TWITTER, machine_id=3)
        assert gen.machine_id == 3  # explicit wins

    def test_custom_env_var_names(self, monkeypatch):
        monkeypatch.setenv("MY_DC",  "2")
        monkeypatch.setenv("MY_M",   "5")
        gen = make_generator_from_env(
            PRESET_TWITTER,
            datacenter_env="MY_DC",
            machine_env="MY_M",
        )
        assert gen.datacenter_id == 2
        assert gen.machine_id    == 5

    def test_missing_env_vars_use_defaults(self, monkeypatch):
        monkeypatch.delenv("FLAKEID_DATACENTER_ID", raising=False)
        monkeypatch.delenv("FLAKEID_MACHINE_ID",    raising=False)
        gen = make_generator_from_env(PRESET_TWITTER)
        assert gen.datacenter_id == 0
        assert gen.machine_id    == 0


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrors:

    def test_clock_backwards_large_raises(self, monkeypatch):
        """A large backwards drift should raise ClockBackwardsError."""
        gen = make_twitter()
        # prime with a "far future" timestamp
        far_future = int(time.time() * 1000) + 100_000
        gen._last_timestamp_ms = far_future

        with pytest.raises(ClockBackwardsError):
            gen.next_id()

    def test_epoch_error_future_epoch(self):
        future_epoch = int(time.time() * 1000) + 9_999_999_999
        gen = SnowflakeGenerator(
            timestamp_bits=41, datacenter_bits=5,
            machine_bits=5, sequence_bits=12,
            epoch_ms=future_epoch,
        )
        with pytest.raises(EpochError):
            gen.next_id()
