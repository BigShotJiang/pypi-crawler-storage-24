"""
flakeid
~~~~~~~
Flexible 64-bit Snowflake-style unique ID generation for Python.

Quickstart
----------
Zero config::

    import flakeid
    uid = flakeid.next_id()          # one ID
    ids = flakeid.next_ids(100)      # bulk

Twitter-style with explicit node identity::

    from flakeid import make_generator, PRESET_TWITTER
    gen = make_generator(PRESET_TWITTER, datacenter_id=1, machine_id=7)
    uid = gen.next_id()
    print(gen.decode(uid))           # DecodedID(...)
    print(gen.capacity())            # Capacity(...)

Container / cloud deployment::

    from flakeid import make_generator_from_env
    # reads FLAKEID_DATACENTER_ID and FLAKEID_MACHINE_ID at startup
    gen = make_generator_from_env("twitter")
"""

from .exceptions import (
    ClockBackwardsError,
    EpochError,
    FlakeIDError,
    TimestampOverflowError,
)
from .factory import (
    make_generator,
    make_generator_from_env,
    next_id,
    next_ids,
)
from .generator import (
    Capacity,
    DecodedID,
    SnowflakeGenerator,
)
from .presets import (
    ALL_PRESETS,
    PRESET_HIGH_THROUGHPUT,
    PRESET_LARGE_CLUSTER,
    PRESET_MINIMAL,
    PRESET_SINGLE_DC,
    PRESET_TWITTER,
)

__version__ = "0.1.0"
__author__  = "flakeid contributors"
__license__ = "MIT"

__all__ = [
    # Zero-config shortcuts
    "next_id",
    "next_ids",
    # Factory
    "make_generator",
    "make_generator_from_env",
    # Core class
    "SnowflakeGenerator",
    # Data classes
    "DecodedID",
    "Capacity",
    # Presets
    "PRESET_TWITTER",
    "PRESET_MINIMAL",
    "PRESET_SINGLE_DC",
    "PRESET_LARGE_CLUSTER",
    "PRESET_HIGH_THROUGHPUT",
    "ALL_PRESETS",
    # Exceptions
    "FlakeIDError",
    "ClockBackwardsError",
    "TimestampOverflowError",
    "EpochError",
    # Meta
    "__version__",
]
