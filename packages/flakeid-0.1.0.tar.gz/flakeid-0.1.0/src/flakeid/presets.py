"""
flakeid.presets
~~~~~~~~~~~~~~~
Ready-made generator configurations for common deployment scenarios.
"""

from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# Preset dicts — pass directly to SnowflakeGenerator or make_generator()
# ---------------------------------------------------------------------------

#: Classic Twitter / Discord layout.
#: 41-bit ts · 5-bit DC · 5-bit machine · 12-bit seq
#: → 4096 IDs/ms/node, ~69 year range, 1024 nodes
PRESET_TWITTER = dict(
    timestamp_bits=41,
    datacenter_bits=5,
    machine_bits=5,
    sequence_bits=12,
)

#: Minimal — no node identity at all (perfect for solo projects / scripts).
#: 53-bit ts · 10-bit seq
#: → 1024 IDs/ms, ~285 year range
PRESET_MINIMAL = dict(
    timestamp_bits=53,
    datacenter_bits=0,
    machine_bits=0,
    sequence_bits=10,
)

#: Single-machine — one deployment, many workers.
#: 41-bit ts · 10-bit worker · 12-bit seq
#: → 4096 IDs/ms/worker, 1024 workers
PRESET_SINGLE_DC = dict(
    timestamp_bits=41,
    datacenter_bits=0,
    machine_bits=10,
    sequence_bits=12,
)

#: Large cluster — many datacenters, many machines per DC.
#: 41-bit ts · 8-bit DC · 8-bit machine · 6-bit seq
#: → 256 DCs × 256 machines = 65 536 nodes
PRESET_LARGE_CLUSTER = dict(
    timestamp_bits=41,
    datacenter_bits=8,
    machine_bits=8,
    sequence_bits=6,
)

#: High-throughput — maximises IDs per millisecond at the cost of node space.
#: 41-bit ts · 3-bit DC · 3-bit machine · 16-bit seq
#: → 65 536 IDs/ms/node, 64 nodes
PRESET_HIGH_THROUGHPUT = dict(
    timestamp_bits=41,
    datacenter_bits=3,
    machine_bits=3,
    sequence_bits=16,
)

#: All presets by name — useful for introspection or CLI tools.
ALL_PRESETS: dict[str, dict[str, Any]] = {
    "twitter":        PRESET_TWITTER,
    "minimal":        PRESET_MINIMAL,
    "single_dc":      PRESET_SINGLE_DC,
    "large_cluster":  PRESET_LARGE_CLUSTER,
    "high_throughput": PRESET_HIGH_THROUGHPUT,
}
