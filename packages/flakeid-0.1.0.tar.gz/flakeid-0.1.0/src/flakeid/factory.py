"""
flakeid.factory
~~~~~~~~~~~~~~~
Convenience factory functions and the module-level default generator.
"""

from __future__ import annotations

import os
import threading
from typing import Any

from .generator import SnowflakeGenerator
from .presets import PRESET_TWITTER, PRESET_MINIMAL, ALL_PRESETS


# ---------------------------------------------------------------------------
# Factory function
# ---------------------------------------------------------------------------

def make_generator(
    preset: dict[str, Any] | str | None = None,
    **overrides: Any,
) -> SnowflakeGenerator:
    """
    Build a :class:`~flakeid.SnowflakeGenerator` from a preset plus optional
    field overrides.

    Parameters
    ----------
    preset:
        A preset dict (e.g. ``PRESET_TWITTER``) **or** a preset name string
        (``"twitter"``, ``"minimal"``, ``"single_dc"``, ``"large_cluster"``,
        ``"high_throughput"``).  When *None*, the Twitter defaults are used.
    **overrides:
        Any :class:`~flakeid.SnowflakeGenerator` keyword argument — overrides
        values from the preset.

    Examples
    --------
    Zero config::

        gen = make_generator()

    Twitter layout with custom node IDs::

        from flakeid import make_generator, PRESET_TWITTER
        gen = make_generator(PRESET_TWITTER, datacenter_id=2, machine_id=5)

    Completely custom::

        gen = make_generator(
            timestamp_bits=41,
            datacenter_bits=0,
            machine_bits=10,
            sequence_bits=12,
            machine_id=3,
        )

    From an environment-variable-driven deployment::

        gen = make_generator_from_env()
    """
    if isinstance(preset, str):
        if preset not in ALL_PRESETS:
            raise ValueError(
                f"Unknown preset {preset!r}. "
                f"Available: {list(ALL_PRESETS)}"
            )
        cfg = dict(ALL_PRESETS[preset])
    elif isinstance(preset, dict):
        cfg = dict(preset)
    elif preset is None:
        cfg = dict(PRESET_TWITTER)
    else:
        raise TypeError(f"preset must be a dict, str, or None; got {type(preset)}")

    cfg.update(overrides)
    return SnowflakeGenerator(**cfg)


def make_generator_from_env(
    preset: dict[str, Any] | str | None = None,
    *,
    datacenter_env: str = "FLAKEID_DATACENTER_ID",
    machine_env:    str = "FLAKEID_MACHINE_ID",
    epoch_env:      str = "FLAKEID_EPOCH_MS",
    **overrides: Any,
) -> SnowflakeGenerator:
    """
    Build a generator whose node IDs are read from environment variables.

    This is the recommended approach for containerised / cloud deployments
    where the machine identity is injected at runtime.

    Environment variables
    ---------------------
    FLAKEID_DATACENTER_ID   integer datacenter ID (default: 0)
    FLAKEID_MACHINE_ID      integer machine ID (default: 0)
    FLAKEID_EPOCH_MS        custom epoch in Unix milliseconds (optional)

    The variable names can be overridden via *datacenter_env*, *machine_env*,
    and *epoch_env*.

    Examples
    --------
    ::

        # In a Dockerfile / Kubernetes env:
        #   ENV FLAKEID_DATACENTER_ID=3
        #   ENV FLAKEID_MACHINE_ID=12

        from flakeid import make_generator_from_env
        gen = make_generator_from_env("twitter")
    """
    env_overrides: dict[str, Any] = {}

    dc_raw = os.environ.get(datacenter_env)
    if dc_raw is not None:
        env_overrides["datacenter_id"] = int(dc_raw)

    m_raw = os.environ.get(machine_env)
    if m_raw is not None:
        env_overrides["machine_id"] = int(m_raw)

    epoch_raw = os.environ.get(epoch_env)
    if epoch_raw is not None:
        env_overrides["epoch_ms"] = int(epoch_raw)

    merged = {**env_overrides, **overrides}   # explicit overrides win
    return make_generator(preset, **merged)


# ---------------------------------------------------------------------------
# Module-level default generator (zero-config path)
# ---------------------------------------------------------------------------

_default: SnowflakeGenerator | None = None
_default_lock = threading.Lock()


def _get_default() -> SnowflakeGenerator:
    global _default
    if _default is None:
        with _default_lock:
            if _default is None:
                _default = make_generator(PRESET_MINIMAL)
    return _default


def next_id() -> int:
    """
    Return a unique 64-bit integer ID from the module-level default generator.

    The default generator uses :data:`~flakeid.PRESET_MINIMAL` (no node
    identity) and is lazily initialised on first call.  It requires zero
    configuration — just call it.

    ::

        import flakeid
        uid = flakeid.next_id()
    """
    return _get_default().next_id()


def next_ids(count: int) -> list[int]:
    """
    Return *count* unique IDs from the module-level default generator.

    ::

        import flakeid
        ids = flakeid.next_ids(100)
    """
    return _get_default().next_ids(count)
