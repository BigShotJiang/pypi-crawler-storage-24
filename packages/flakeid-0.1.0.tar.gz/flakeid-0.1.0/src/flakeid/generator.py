"""
flakeid.generator
~~~~~~~~~~~~~~~~~
Core 64-bit Snowflake-style ID generation engine.

Bit layout (high → low, 64 bits total):
    [1 sign][timestamp_bits][datacenter_bits][machine_bits][sequence_bits]

All field widths are configurable; the four fields must sum to exactly 63.
The MSB is always 0 so IDs are safe as signed 64-bit integers in any DB.
"""

from __future__ import annotations
# Allows using newer type hint syntax (like dict[str, Any]) on older Python versions.
# Annotations are stored as strings and evaluated lazily, not at import time.

import threading
# Used for threading.Lock() — ensures only one thread generates an ID at a time.
# Without this, two threads could get the same ID simultaneously.

import time
# Used to get the current time in milliseconds via time.time().

from dataclasses import dataclass
# @dataclass auto-generates __init__, __repr__, __eq__ for plain data-holding classes.

from typing import Iterator
# Type hint for the stream() method — tells callers it yields an infinite sequence of ints.

from .exceptions import ClockBackwardsError, EpochError, TimestampOverflowError
# Custom exceptions defined in the exceptions module:
# - ClockBackwardsError: system clock went back in time (NTP issue)
# - EpochError: current time is before the configured epoch
# - TimestampOverflowError: timestamp exceeded the max value for the configured bits


# ---------------------------------------------------------------------------
# Public data classes
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
# @dataclass: auto-generates __init__, __repr__, __eq__ from the fields below.
# frozen=True: makes the instance immutable — fields cannot be changed after creation.
#              Also gives us __hash__ for free, so instances can be used in sets/dicts.
class DecodedID:
    """Human-readable breakdown of a Snowflake ID."""

    raw: int           # The original 64-bit integer ID — the full undecoded number.
    timestamp_ms: int  # Milliseconds since the generator's epoch (not Unix epoch).
    datacenter_id: int # Which datacenter generated this ID.
    machine_id: int    # Which machine/worker inside that datacenter generated it.
    sequence: int      # The per-millisecond counter — distinguishes IDs made in same ms.

    @property
    # @property means this is accessed like an attribute (decoded.generated_at)
    # not called like a method (decoded.generated_at()).
    def generated_at(self) -> str:
        """ISO-8601 UTC timestamp string."""
        import datetime
        # Imported here (inside the method) instead of at the top of the file.
        # This is a lazy import — only loaded when this property is actually accessed,
        # not every time the module is imported. Useful for rarely-used dependencies.

        dt = datetime.datetime.fromtimestamp(
            self.timestamp_ms / 1000,  # Convert ms → seconds, because fromtimestamp expects seconds.
            tz=datetime.timezone.utc   # Make the datetime timezone-aware (UTC).
                                       # Without tz=, Python gives a "naive" datetime
                                       # that has no timezone info — dangerous and deprecated.
        )

        return dt.isoformat(timespec="milliseconds") + "Z"
        # .isoformat() converts to ISO-8601 string format.
        # timespec="milliseconds" → include only up to milliseconds, not microseconds.
        #   e.g. "2024-01-15T10:30:00.123+00:00"  (not "2024-01-15T10:30:00.123456+00:00")
        # + "Z" appends the UTC Zulu indicator — a common ISO-8601 convention.
        # Final output: "2024-01-15T10:30:00.123+00:00Z"

    def __repr__(self) -> str:
        # __repr__ defines what you see when you print() or inspect this object.
        # It overrides the default @dataclass-generated __repr__ to show
        # generated_at (human-readable time) instead of the raw timestamp_ms number.
        return (
            f"DecodedID(raw={self.raw}, "
            f"generated_at='{self.generated_at}', "  # Shows "2024-01-15T10:30:00.123+00:00Z"
            f"datacenter_id={self.datacenter_id}, "
            f"machine_id={self.machine_id}, "
            f"sequence={self.sequence})"
        )


@dataclass(frozen=True)
# Again frozen=True — Capacity is also a read-only snapshot of configuration limits.
class Capacity:
    """Theoretical limits of a given generator configuration."""

    timestamp_range_years: float  # How many years the timestamp bits can represent.
    max_datacenters: int          # Maximum number of datacenters (2^datacenter_bits).
    max_machines_per_dc: int      # Maximum machines per datacenter (2^machine_bits).
    total_nodes: int              # Total unique nodes = max_datacenters × max_machines_per_dc.
    ids_per_ms_per_node: int      # How many IDs one node can generate per millisecond (2^sequence_bits).

    @property
    def ids_per_sec_per_node(self) -> int:
        # Derived value — not stored, just computed on demand.
        # 1 second = 1000 milliseconds, so multiply ids/ms by 1000.
        return self.ids_per_ms_per_node * 1_000
        # 1_000 is the same as 1000 — Python allows underscores in numbers for readability.

    def __repr__(self) -> str:
        return (
            f"Capacity("
            f"years={self.timestamp_range_years}, "
            f"nodes={self.total_nodes}, "
            f"ids_per_sec={self.ids_per_sec_per_node:,})"
            # :, formats the number with commas e.g. 65536 → "65,536" for readability.
        )


# ---------------------------------------------------------------------------
# Core generator
# ---------------------------------------------------------------------------

class SnowflakeGenerator:
    """Thread-safe, configurable 64-bit unique ID generator."""

    DEFAULT_EPOCH_MS: int = 1_577_836_800_000
    # Class-level constant — shared across all instances, not per-instance.
    # 1_577_836_800_000 ms = 2020-01-01 00:00:00 UTC in Unix milliseconds.
    # Using 2020 instead of 1970 (Unix epoch) means the timestamp offset stays
    # smaller for longer — squeezing more life out of fewer timestamp bits.

    def __init__(
        self,
        *,                          # * means ALL following args are keyword-only.
                                    # You MUST write: SnowflakeGenerator(timestamp_bits=41, ...)
                                    # You CANNOT write: SnowflakeGenerator(41, 5, 5, 12)
                                    # This prevents accidentally passing args in wrong order.
        timestamp_bits: int = 41,   # Default: Twitter Snowflake layout.
        datacenter_bits: int = 5,
        machine_bits: int = 5,
        sequence_bits: int = 12,
        datacenter_id: int = 0,
        machine_id: int = 0,
        epoch_ms: int = DEFAULT_EPOCH_MS,
    ) -> None:

        # ── VALIDATION 1: All bits must sum to exactly 63 ──────────────────
        total = timestamp_bits + datacenter_bits + machine_bits + sequence_bits
        if total != 63:
            # The 64th bit (MSB) is always 0 — reserved as sign bit.
            # This keeps IDs positive and safe in signed 64-bit integer columns in databases.
            # So the remaining 63 bits are distributed among these four fields.
            raise ValueError(
                f"timestamp_bits + datacenter_bits + machine_bits + sequence_bits "
                f"must equal 63, got {total}. "
                f"({timestamp_bits} + {datacenter_bits} + {machine_bits} + {sequence_bits})"
            )

        # ── VALIDATION 2: No individual bit value can be negative ──────────
        for name, value in [
            ("timestamp_bits", timestamp_bits),
            ("datacenter_bits", datacenter_bits),
            ("machine_bits", machine_bits),
            ("sequence_bits", sequence_bits),
        ]:
            # Loops over each field name + value pair to check each one.
            if value < 0:
                raise ValueError(f"{name} must be >= 0, got {value}")

        # ── VALIDATION 3: Critical minimums ────────────────────────────────
        if sequence_bits < 1:
            # Need at least 1 sequence bit, otherwise you can only generate 1 ID per ms.
            raise ValueError("sequence_bits must be >= 1")
        if timestamp_bits < 1:
            # Need at least 1 timestamp bit, otherwise all IDs have the same timestamp.
            raise ValueError("timestamp_bits must be >= 1")

        # ── VALIDATION 4: Node IDs must fit inside their allocated bits ─────
        dc_max = (1 << datacenter_bits) - 1 if datacenter_bits else 0
        # (1 << datacenter_bits) = 2^datacenter_bits = total possible values.
        # Subtract 1 because values go from 0 to max (e.g. 5 bits → 0 to 31).
        # If datacenter_bits=0, dc_max=0 (no datacenter field at all).
        # Example: 5 bits → (1 << 5) - 1 = 32 - 1 = 31. Valid range: 0–31.

        m_max = (1 << machine_bits) - 1 if machine_bits else 0
        # Same logic for machine bits.

        if datacenter_id < 0 or datacenter_id > dc_max:
            raise ValueError(
                f"datacenter_id must be in [0, {dc_max}] for {datacenter_bits} bits, got {datacenter_id}"
            )
        if machine_id < 0 or machine_id > m_max:
            raise ValueError(
                f"machine_id must be in [0, {m_max}] for {machine_bits} bits, got {machine_id}"
            )

        # ── Store configuration on the instance ────────────────────────────
        self.timestamp_bits  = timestamp_bits
        self.datacenter_bits = datacenter_bits
        self.machine_bits    = machine_bits
        self.sequence_bits   = sequence_bits
        self.datacenter_id   = datacenter_id
        self.machine_id      = machine_id
        self.epoch_ms        = epoch_ms

        # ── Pre-compute bit masks and shifts (hot path optimisation) ────────
        # These are computed ONCE here in __init__ and reused every time _generate() runs.
        # Avoids repeating the same arithmetic thousands of times per second.

        self._max_sequence = (1 << sequence_bits) - 1
        # The maximum value the sequence counter can reach before wrapping back to 0.
        # Example: 12 bits → (1 << 12) - 1 = 4095. Sequence goes 0, 1, 2, ... 4095, 0, 1, ...
        # Used as a bitmask: (seq + 1) & _max_sequence wraps cleanly back to 0.

        self._machine_shift = sequence_bits
        # To place machine_id in the correct bit position, shift it LEFT by sequence_bits.
        # Example: sequence=12 bits → machine_id sits at bits 12 and above.

        self._datacenter_shift = sequence_bits + machine_bits
        # datacenter_id sits above both sequence and machine fields.
        # Example: sequence=12, machine=5 → datacenter starts at bit 17.

        self._timestamp_shift = sequence_bits + machine_bits + datacenter_bits
        # Timestamp sits at the very top (most significant bits).
        # Example: sequence=12, machine=5, datacenter=5 → timestamp starts at bit 22.

        # ── Mutable state ───────────────────────────────────────────────────
        self._sequence = 0
        # The current sequence counter. Increments within the same millisecond.
        # Resets to 0 when the millisecond changes.

        self._last_timestamp_ms = -1
        # Tracks the timestamp of the last generated ID.
        # -1 means "no ID generated yet".
        # Used to detect clock backwards jumps and to manage the sequence counter.

        self._lock = threading.Lock()
        # A mutual exclusion lock.
        # Only ONE thread can hold this lock at a time.
        # Any other thread calling next_id() will WAIT until the lock is released.
        # This is what makes the generator thread-safe.


    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def next_id(self) -> int:
        """Return a new unique 64-bit integer ID (thread-safe)."""
        with self._lock:
            # "with self._lock" acquires the lock at the start and releases it at the end.
            # If another thread is already inside here, the current thread BLOCKS (waits).
            # This ensures _generate() is never run by two threads simultaneously.
            return self._generate()

    def next_ids(self, count: int) -> list[int]:
        """Return *count* unique IDs in a single lock acquisition."""
        if count < 1:
            raise ValueError(f"count must be >= 1, got {count}")
        with self._lock:
            # Acquires the lock ONCE and generates all IDs inside it.
            # Much more efficient than calling next_id() in a loop,
            # because each next_id() call acquires+releases the lock separately.
            return [self._generate() for _ in range(count)]
            # List comprehension: calls _generate() `count` times, collects results into a list.
            # _ is a throwaway variable — we don't need the loop index, just the count.

    def stream(self) -> Iterator[int]:
        """Infinite iterator of unique IDs."""
        while True:
            # Infinite loop — runs forever until the caller breaks out.
            yield self.next_id()
            # `yield` makes this a generator function.
            # It pauses here and returns one ID to the caller.
            # Resumes from this point when the caller asks for the next value.
            # Memory efficient — doesn't pre-generate a massive list.

    def decode(self, uid: int) -> DecodedID:
        """Decompose a previously generated ID back into its constituent fields."""

        remaining = uid
        # We'll peel off fields from the RIGHT (least significant bits) one by one.

        # ── Extract sequence (rightmost bits) ───────────────────────────────
        seq = remaining & self._max_sequence
        # & is bitwise AND — keeps only the bits that are 1 in _max_sequence.
        # _max_sequence for 12 bits = 0b111111111111 (twelve 1s).
        # This masks off everything except the lowest 12 bits = the sequence value.

        remaining >>= self.sequence_bits
        # >>= shifts remaining RIGHT by sequence_bits positions.
        # This discards the sequence bits we just extracted,
        # moving the machine_id bits down to the rightmost position.

        # ── Extract machine_id ──────────────────────────────────────────────
        if self.machine_bits:
            # Only extract if machine_bits > 0 (some configs omit the machine field).
            m_mask = (1 << self.machine_bits) - 1
            # Create a bitmask for machine_bits wide.
            # Example: 5 bits → 0b11111 = 31
            m_id = remaining & m_mask
            # Mask off everything except the machine_id bits.
        else:
            m_id = 0  # No machine field in this config.
        remaining >>= self.machine_bits
        # Shift away the machine bits, bringing datacenter bits to the right.

        # ── Extract datacenter_id ───────────────────────────────────────────
        if self.datacenter_bits:
            dc_mask = (1 << self.datacenter_bits) - 1
            dc = remaining & dc_mask
        else:
            dc = 0
        remaining >>= self.datacenter_bits
        # Shift away datacenter bits. What remains is purely the timestamp offset.

        # ── What's left is the timestamp ────────────────────────────────────
        ts_offset_ms = remaining
        # After shifting away sequence + machine + datacenter bits,
        # only the timestamp offset (ms since epoch) remains.

        return DecodedID(
            raw=uid,                              # Original unmodified ID.
            timestamp_ms=ts_offset_ms + self.epoch_ms,
            # Add back the epoch to convert offset → actual Unix timestamp in ms.
            # ts_offset_ms is "ms since 2020-01-01", so add epoch_ms to get Unix ms.
            datacenter_id=dc,
            machine_id=m_id,
            sequence=seq,
        )

    def capacity(self) -> Capacity:
        """Report the theoretical limits of this generator's configuration."""

        ts_max_ms = (1 << self.timestamp_bits) - 1
        # Maximum timestamp offset the bits can hold, in milliseconds.
        # Example: 41 bits → 2^41 - 1 = 2,199,023,255,551 ms

        dc_count = (1 << self.datacenter_bits) if self.datacenter_bits else 1
        # Total number of possible datacenter IDs.
        # If datacenter_bits=0, treat as 1 (there's still 1 "virtual" datacenter).

        m_count = (1 << self.machine_bits) if self.machine_bits else 1
        # Total number of possible machine IDs per datacenter.

        seq_count = (1 << self.sequence_bits)
        # Total IDs generatable per millisecond per node.
        # Example: 12 bits → 4096 IDs/ms/node.

        years = ts_max_ms / 1_000 / 60 / 60 / 24 / 365.25
        # Convert ms → seconds → minutes → hours → days → years.
        # 365.25 accounts for leap years (1 leap year every 4 years = 0.25 extra days/year).

        return Capacity(
            timestamp_range_years=round(years, 1),  # Round to 1 decimal place.
            max_datacenters=dc_count,
            max_machines_per_dc=m_count,
            total_nodes=dc_count * m_count,          # Total unique nodes in the cluster.
            ids_per_ms_per_node=seq_count,
        )


    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _generate(self) -> int:
        """Core generation — must be called with self._lock held."""
        # The leading _ signals this is a private method — not part of public API.
        # Callers should use next_id() / next_ids() instead.

        now_ms = self._current_ms()
        # Get current Unix time in milliseconds.

        # ── Handle clock going backwards ────────────────────────────────────
        if now_ms < self._last_timestamp_ms:
            # The system clock jumped backwards (common with NTP corrections).
            # This is dangerous — if we ignore it, we could generate duplicate IDs
            # because we'd reuse a timestamp we've already generated IDs for.

            drift = self._last_timestamp_ms - now_ms
            # How many milliseconds did the clock jump back?

            if drift <= 10:
                # Small drift (≤10ms) — probably just a minor NTP correction.
                # Wait it out silently rather than crashing.
                time.sleep(drift / 1000.0)
                # Convert ms back to seconds for time.sleep().
                now_ms = self._current_ms()
                # Re-read the clock after waiting — it should now be >= last_timestamp_ms.
            else:
                # Large drift (>10ms) — something seriously wrong with the clock.
                # Raise an error so the operator knows to investigate.
                raise ClockBackwardsError(
                    f"System clock moved backwards by {drift} ms. "
                    "Check NTP synchronisation. Last safe timestamp: "
                    f"{self._last_timestamp_ms}"
                )

        # ── Manage the sequence counter ─────────────────────────────────────
        if now_ms == self._last_timestamp_ms:
            # Same millisecond as the last ID — increment the sequence counter.
            self._sequence = (self._sequence + 1) & self._max_sequence
            # & self._max_sequence wraps the counter back to 0 after hitting the max.
            # Example: 12-bit sequence → wraps at 4096 back to 0.

            if self._sequence == 0:
                # We've exhausted all sequence numbers for this millisecond.
                # (Generated 4096 IDs in 1ms with 12 sequence bits.)
                # Must wait for the next millisecond to avoid duplicate IDs.
                now_ms = self._wait_next_ms(self._last_timestamp_ms)
                # Busy-waits (spins) until the clock ticks forward.
        else:
            # New millisecond — reset sequence counter back to 0.
            self._sequence = 0

        self._last_timestamp_ms = now_ms
        # Remember this timestamp for the next call.

        # ── Validate timestamp is within valid range ─────────────────────────
        offset = now_ms - self.epoch_ms
        # Convert absolute Unix ms timestamp → relative offset from our custom epoch.
        # Example: if epoch=2020-01-01 and now=2025-01-01, offset = 5 years in ms.

        if offset < 0:
            # Current time is BEFORE the epoch — misconfigured epoch_ms.
            raise EpochError(
                f"Current time ({now_ms} ms) is before the configured epoch "
                f"({self.epoch_ms} ms). Use a smaller epoch_ms value."
            )

        max_ts = (1 << self.timestamp_bits) - 1
        # Maximum value that fits in timestamp_bits.
        # Example: 41 bits → max_ts = 2,199,023,255,551 ms ≈ 69 years.

        if offset > max_ts:
            # The offset no longer fits in the allocated timestamp bits.
            # The generator has "expired" — can't generate valid IDs anymore.
            raise TimestampOverflowError(
                f"Timestamp offset {offset} ms exceeds the maximum for "
                f"{self.timestamp_bits} bits ({max_ts} ms). "
                "Increase timestamp_bits or update your epoch."
            )

        # ── Assemble the final 64-bit ID ─────────────────────────────────────
        return (
            (offset               << self._timestamp_shift)
            # Shift timestamp to the TOP of the 64-bit integer.
            # Example: timestamp_shift=22 → offset occupies bits 22–62.

            | (self.datacenter_id << self._datacenter_shift)
            # | is bitwise OR — places datacenter_id bits into the correct position.
            # datacenter_shift=17 (for 12+5) → datacenter occupies bits 17–21.

            | (self.machine_id    << self._machine_shift)
            # machine_shift=12 → machine occupies bits 12–16.

            | self._sequence
            # Sequence needs no shift — it already lives in the lowest bits (0–11).
        )
        # Final layout (41+5+5+12 example):
        # Bit 63 (MSB):  always 0 (sign bit, implicit)
        # Bits 62–22:    timestamp offset (41 bits)
        # Bits 21–17:    datacenter_id (5 bits)
        # Bits 16–12:    machine_id (5 bits)
        # Bits 11–0:     sequence (12 bits)

    @staticmethod
    def _current_ms() -> int:
        # @staticmethod: doesn't need `self` — doesn't access any instance data.
        # Just a utility function namespaced inside the class.
        return int(time.time() * 1000)
        # time.time() returns current Unix time as a float in SECONDS (e.g. 1700000000.123).
        # × 1000 converts to milliseconds (e.g. 1700000000123.0).
        # int() truncates the decimal → whole milliseconds (e.g. 1700000000123).

    @staticmethod
    def _wait_next_ms(last_ms: int) -> int:
        # Busy-wait loop — keeps checking the clock until it advances past last_ms.
        # Called only when the sequence counter is exhausted within one millisecond.
        ms = int(time.time() * 1000)
        while ms <= last_ms:
            # Keep looping as long as we're still in the same millisecond (or behind).
            ms = int(time.time() * 1000)
        return ms
        # Returns the new millisecond — guaranteed to be > last_ms.

    def __repr__(self) -> str:
        # Shows a compact summary of this generator's configuration.
        # Useful when debugging: print(gen) → tells you exactly how it's configured.
        return (
            f"SnowflakeGenerator("
            f"ts={self.timestamp_bits}b, "
            # e.g. "ts=41b"
            f"dc={self.datacenter_bits}b[id={self.datacenter_id}], "
            # e.g. "dc=5b[id=2]"
            f"machine={self.machine_bits}b[id={self.machine_id}], "
            # e.g. "machine=5b[id=7]"
            f"seq={self.sequence_bits}b)"
            # e.g. "seq=12b"
        )
        # Full output: "SnowflakeGenerator(ts=41b, dc=5b[id=2], machine=5b[id=7], seq=12b)"



# ## Visual summary of how a final ID is assembled
# ```
# Bit 63        Bit 22        Bit 17      Bit 12     Bit 0
#   |              |             |           |          |
#   0  [timestamp 41b] [datacenter 5b] [machine 5b] [seq 12b]
#   ↑        ↑               ↑               ↑          ↑
# always 0  offset from    which DC      which machine  counter
# (sign)    epoch_ms       (0–31)         (0–31)       (0–4095)