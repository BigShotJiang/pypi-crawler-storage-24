"""
flakeid.exceptions
~~~~~~~~~~~~~~~~~~
All exceptions raised by flakeid, in one place.
"""


class FlakeIDError(Exception):
    """Base class for all flakeid errors."""


class ClockBackwardsError(FlakeIDError):
    """
    Raised when the system clock moves backwards by more than the tolerable
    drift threshold (10 ms by default).

    This should be extremely rare in practice. If it happens regularly,
    check NTP synchronisation on the host.
    """


class TimestampOverflowError(FlakeIDError):
    """
    Raised when the current time exceeds the maximum representable timestamp
    for the configured number of ``timestamp_bits``.

    Fix: increase ``timestamp_bits`` or update ``epoch_ms`` to a more recent
    date (which resets the usable range).
    """


class EpochError(FlakeIDError):
    """
    Raised when the current time is *before* the configured epoch — i.e. the
    timestamp offset would be negative.

    Fix: use a smaller (earlier) ``epoch_ms`` value.
    """
