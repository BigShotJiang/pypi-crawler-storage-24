"""Personas resource — discover published personas."""
from __future__ import annotations
from typing import Union, List

from foilengine._http import HttpClient, AsyncHttpClient
from foilengine.types import Persona


class PersonasResource:
    """List published personas owned by your API key."""

    def __init__(self, http: Union[HttpClient, AsyncHttpClient]):
        self._http = http

    def list(self) -> list[Persona]:
        """List all published personas."""
        data = self._http.get("/api/v1/sdk/personas")
        return [Persona(**p) for p in data]

    async def list_async(self) -> list[Persona]:
        """List all published personas (async)."""
        data = await self._http.get("/api/v1/sdk/personas")
        return [Persona(**p) for p in data]
