"""Machines resource — discover available machines (scenarios) for a persona."""
from __future__ import annotations
from typing import Union

from foilengine._http import HttpClient, AsyncHttpClient
from foilengine.types import MachineInfo


class MachinesResource:
    """List machines available to a player."""

    def __init__(self, http: Union[HttpClient, AsyncHttpClient]):
        self._http = http

    def list(self, persona_id: str, user_session_id: str) -> list[MachineInfo]:
        """List all machines available to a player for a persona."""
        data = self._http.get(
            f"/api/v1/sdk/chat/{persona_id}/machines",
            params={"user_session_id": user_session_id},
        )
        return [MachineInfo(**m) for m in data]

    async def list_async(self, persona_id: str, user_session_id: str) -> list[MachineInfo]:
        """List all machines available to a player for a persona (async)."""
        data = await self._http.get(
            f"/api/v1/sdk/chat/{persona_id}/machines",
            params={"user_session_id": user_session_id},
        )
        return [MachineInfo(**m) for m in data]
