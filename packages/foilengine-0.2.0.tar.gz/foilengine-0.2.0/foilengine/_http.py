"""
Internal HTTP client for the Foil Engine SDK.

Handles authentication, retries with exponential backoff, and error mapping.
"""
import time
from typing import Any, Optional

import httpx

from foilengine.errors import (
    FoilEngineError,
    RateLimitError,
    STATUS_CODE_TO_ERROR,
)

DEFAULT_BASE_URL = "https://api.foilengine.io"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def _build_headers(
    api_key: str,
    llm_api_key: Optional[str] = None,
    llm_model: Optional[str] = None,
    llm_eval_model: Optional[str] = None,
    llm_response_model: Optional[str] = None,
    llm_summarization_model: Optional[str] = None,
) -> dict[str, str]:
    """Build request headers, including optional BYOK LLM headers."""
    headers = {
        "X-API-Key": api_key,
        "Content-Type": "application/json",
    }
    if llm_api_key:
        headers["X-LLM-API-Key"] = llm_api_key
    if llm_model:
        headers["X-LLM-Model"] = llm_model
    if llm_eval_model:
        headers["X-LLM-Eval-Model"] = llm_eval_model
    if llm_response_model:
        headers["X-LLM-Response-Model"] = llm_response_model
    if llm_summarization_model:
        headers["X-LLM-Summarization-Model"] = llm_summarization_model
    return headers


class HttpClient:
    """Synchronous HTTP client with auth, retries, and error mapping."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        llm_api_key: Optional[str] = None,
        llm_model: Optional[str] = None,
        llm_eval_model: Optional[str] = None,
        llm_response_model: Optional[str] = None,
        llm_summarization_model: Optional[str] = None,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._client = httpx.Client(
            base_url=self._base_url,
            headers=_build_headers(
                api_key=api_key,
                llm_api_key=llm_api_key,
                llm_model=llm_model,
                llm_eval_model=llm_eval_model,
                llm_response_model=llm_response_model,
                llm_summarization_model=llm_summarization_model,
            ),
            timeout=self._timeout,
        )

    def request(
        self,
        method: str,
        path: str,
        json: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any] | list[Any]:
        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.request(
                    method=method,
                    url=path,
                    json=json,
                    params=params,
                )

                if response.status_code < 400:
                    return response.json()

                if response.status_code in RETRYABLE_STATUS_CODES and attempt < self._max_retries:
                    retry_after = self._get_retry_after(response)
                    wait = retry_after or (2 ** attempt * 0.5)
                    time.sleep(wait)
                    continue

                self._raise_for_status(response)

            except httpx.TimeoutException as e:
                last_error = e
                if attempt < self._max_retries:
                    time.sleep(2 ** attempt * 0.5)
                    continue
                raise FoilEngineError(f"Request timed out after {self._timeout}s") from e

            except FoilEngineError:
                raise

            except Exception as e:
                last_error = e
                if attempt < self._max_retries:
                    time.sleep(2 ** attempt * 0.5)
                    continue
                raise FoilEngineError(f"Unexpected error: {e}") from e

        raise FoilEngineError("Max retries exceeded") from last_error

    def get(self, path: str, params: Optional[dict[str, Any]] = None) -> dict[str, Any] | list[Any]:
        return self.request("GET", path, params=params)

    def post(self, path: str, json: Optional[dict[str, Any]] = None, params: Optional[dict[str, Any]] = None) -> dict[str, Any] | list[Any]:
        return self.request("POST", path, json=json, params=params)

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    @staticmethod
    def _get_retry_after(response: httpx.Response) -> Optional[float]:
        header = response.headers.get("retry-after")
        if header:
            try:
                return float(header)
            except ValueError:
                return None
        return None

    @staticmethod
    def _raise_for_status(response: httpx.Response):
        try:
            body = response.json()
        except Exception:
            body = {}

        # Backend wraps errors as {"error": {"message": "..."}}
        error_obj = body.get("error", {})
        if isinstance(error_obj, dict):
            message = error_obj.get("message", "")
        else:
            message = body.get("detail", response.text)

        error_class = STATUS_CODE_TO_ERROR.get(response.status_code, FoilEngineError)

        if error_class == RateLimitError:
            retry_after = HttpClient._get_retry_after(response)
            raise RateLimitError(message=message, retry_after=retry_after)

        raise error_class(message=message)


class AsyncHttpClient:
    """Async HTTP client with auth, retries, and error mapping."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        llm_api_key: Optional[str] = None,
        llm_model: Optional[str] = None,
        llm_eval_model: Optional[str] = None,
        llm_response_model: Optional[str] = None,
        llm_summarization_model: Optional[str] = None,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers=_build_headers(
                api_key=api_key,
                llm_api_key=llm_api_key,
                llm_model=llm_model,
                llm_eval_model=llm_eval_model,
                llm_response_model=llm_response_model,
                llm_summarization_model=llm_summarization_model,
            ),
            timeout=self._timeout,
        )

    async def request(
        self,
        method: str,
        path: str,
        json: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any] | list[Any]:
        import asyncio

        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.request(
                    method=method,
                    url=path,
                    json=json,
                    params=params,
                )

                if response.status_code < 400:
                    return response.json()

                if response.status_code in RETRYABLE_STATUS_CODES and attempt < self._max_retries:
                    retry_after = HttpClient._get_retry_after(response)
                    wait = retry_after or (2 ** attempt * 0.5)
                    await asyncio.sleep(wait)
                    continue

                HttpClient._raise_for_status(response)

            except httpx.TimeoutException as e:
                last_error = e
                if attempt < self._max_retries:
                    await asyncio.sleep(2 ** attempt * 0.5)
                    continue
                raise FoilEngineError(f"Request timed out after {self._timeout}s") from e

            except FoilEngineError:
                raise

            except Exception as e:
                last_error = e
                if attempt < self._max_retries:
                    await asyncio.sleep(2 ** attempt * 0.5)
                    continue
                raise FoilEngineError(f"Unexpected error: {e}") from e

        raise FoilEngineError("Max retries exceeded") from last_error

    async def get(self, path: str, params: Optional[dict[str, Any]] = None) -> dict[str, Any] | list[Any]:
        return await self.request("GET", path, params=params)

    async def post(self, path: str, json: Optional[dict[str, Any]] = None, params: Optional[dict[str, Any]] = None) -> dict[str, Any] | list[Any]:
        return await self.request("POST", path, json=json, params=params)

    async def close(self):
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
