"""Specialized subagent library for attack refinement."""

from .base import BaseSubagent, PassthroughSubagent, SubagentResult
from .domain_adaptation import DomainAdaptationSubagent
from .encoding import EncodingSubagent
from .factory import (
    create_subagent,
    list_available_subagents,
    register_subagent,
    spawn_subagent,
    spawn_subagent_pipeline,
)
from .psychological import PsychologicalSubagent
from .stealth import StealthSubagent

__all__ = [
    # Base classes
    "BaseSubagent",
    "SubagentResult",
    "PassthroughSubagent",
    # Specialized subagents
    "EncodingSubagent",
    "PsychologicalSubagent",
    "DomainAdaptationSubagent",
    "StealthSubagent",
    # Factory functions
    "create_subagent",
    "spawn_subagent",
    "spawn_subagent_pipeline",
    "list_available_subagents",
    "register_subagent",
]
