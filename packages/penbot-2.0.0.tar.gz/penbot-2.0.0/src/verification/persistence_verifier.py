"""Replay attacks for critical/high findings to confirm reproducibility.

A finding discovered once could be a fluke. The :class:`PersistenceVerifier`
replays the original attack after resetting the conversation context and
re-runs all detectors. If the same vulnerability is detected again, the
finding is **confirmed**; partial matches are **intermittent**; no detection
means **not_reproduced** and confidence is halved.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

from src.utils.helpers import generate_uuid
from src.utils.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class FindingVerification(BaseModel):
    """Result of verifying a single finding."""

    finding_id: str
    original_severity: str
    original_category: str
    status: str = Field(description="confirmed | intermittent | not_reproduced")
    replay_detected_categories: list[str] = Field(default_factory=list)
    original_confidence: float
    adjusted_confidence: float
    replay_response_snippet: str = ""


class VerificationReport(BaseModel):
    """Aggregated verification results for a test session."""

    total_verified: int = 0
    confirmed: int = 0
    intermittent: int = 0
    not_reproduced: int = 0
    verifications: list[FindingVerification] = Field(default_factory=list)
    verification_timestamp: str = ""


# ---------------------------------------------------------------------------
# PersistenceVerifier
# ---------------------------------------------------------------------------


class PersistenceVerifier:
    """Replay attacks to verify finding persistence."""

    def __init__(self, max_verifications: int = 10):
        self.max_verifications = max_verifications

    def select_findings_to_verify(
        self,
        findings: list[dict[str, Any]],
        attacks: list[dict[str, Any]],
        max_count: int | None = None,
    ) -> list[tuple[dict[str, Any], dict[str, Any]]]:
        """Select critical and high-severity findings for verification.

        Args:
            findings: All security findings from the test.
            attacks: All attack attempts from the test.
            max_count: Override for max verifications.

        Returns:
            List of (finding, matching_attack) tuples sorted by severity.
        """
        limit = max_count or self.max_verifications

        attack_lookup: dict[str, dict[str, Any]] = {}
        for attack in attacks:
            attack_lookup[attack.get("attack_id", "")] = attack

        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        verifiable = []

        for finding in findings:
            severity = finding.get("severity", "info")
            if severity not in ("critical", "high"):
                continue
            attack_id = finding.get("attack_id", "")
            attack = attack_lookup.get(attack_id)
            if attack and attack.get("query"):
                verifiable.append((finding, attack))

        verifiable.sort(key=lambda pair: severity_order.get(pair[0].get("severity", "info"), 99))
        return verifiable[:limit]

    async def verify_finding(
        self,
        finding: dict[str, Any],
        attack: dict[str, Any],
        connector: Any,
        detectors: list[Any],
    ) -> FindingVerification:
        """Replay a single attack and check if the finding reproduces.

        Args:
            finding: The original SecurityFinding.
            attack: The original AttackAttempt.
            connector: Target connector (with reset_conversation support).
            detectors: List of VulnerabilityDetector instances.

        Returns:
            FindingVerification with status and adjusted confidence.
        """
        finding_id = finding.get("finding_id", generate_uuid())
        original_category = finding.get("category", "unknown")
        original_confidence = finding.get("confidence", 0.5)
        original_severity = finding.get("severity", "medium")

        try:
            if hasattr(connector, "reset_conversation"):
                await connector.reset_conversation()

            response = await connector.send_message(
                message=attack["query"],
                context={"conversation_history": []},
            )
            if response is None:
                response = {}
            response_content = response.get("content") or ""

            replay_attack = {
                "attack_id": generate_uuid(),
                "agent_name": "persistence_verifier",
                "attack_type": attack.get("attack_type", "verification"),
                "query": attack["query"],
            }
            replay_response = {
                "response_id": generate_uuid(),
                "attack_id": replay_attack["attack_id"],
                "content": response_content,
            }

            detected_categories: list[str] = []
            for detector in detectors:
                try:
                    detector_findings = await detector.analyze(replay_attack, replay_response, {})
                    for df in detector_findings:
                        cat = (
                            df.get("category", "")
                            if isinstance(df, dict)
                            else getattr(df, "category", "")
                        )
                        if cat:
                            detected_categories.append(cat)
                except Exception as det_exc:
                    logger.debug(
                        "detector_failed_during_verification",
                        detector=type(detector).__name__,
                        error=str(det_exc),
                    )

            if original_category in detected_categories:
                status = "confirmed"
                adjusted_confidence = min(original_confidence * 1.2, 1.0)
            elif detected_categories:
                status = "intermittent"
                adjusted_confidence = original_confidence
            else:
                status = "not_reproduced"
                adjusted_confidence = original_confidence * 0.5

            logger.info(
                "finding_verification_complete",
                finding_id=finding_id,
                original_category=original_category,
                status=status,
                detected_categories=detected_categories,
                original_confidence=original_confidence,
                adjusted_confidence=adjusted_confidence,
            )

            return FindingVerification(
                finding_id=finding_id,
                original_severity=original_severity,
                original_category=original_category,
                status=status,
                replay_detected_categories=detected_categories,
                original_confidence=original_confidence,
                adjusted_confidence=adjusted_confidence,
                replay_response_snippet=response_content[:200],
            )

        except Exception as exc:
            logger.warning(
                "finding_verification_failed",
                finding_id=finding_id,
                error=str(exc),
            )
            return FindingVerification(
                finding_id=finding_id,
                original_severity=original_severity,
                original_category=original_category,
                status="not_reproduced",
                original_confidence=original_confidence,
                adjusted_confidence=original_confidence * 0.5,
                replay_response_snippet=f"Error: {str(exc)[:100]}",
            )

    async def verify_all(
        self,
        findings: list[dict[str, Any]],
        attacks: list[dict[str, Any]],
        connector: Any,
        detectors: list[Any],
    ) -> VerificationReport:
        """Orchestrate verification of selected findings.

        Args:
            findings: All security findings.
            attacks: All attack attempts.
            connector: Target connector.
            detectors: List of detectors.

        Returns:
            VerificationReport with all results.
        """
        pairs = self.select_findings_to_verify(findings, attacks)

        if not pairs:
            logger.info("no_findings_to_verify")
            return VerificationReport(verification_timestamp=datetime.now(UTC).isoformat())

        verifications: list[FindingVerification] = []
        for finding, attack in pairs:
            result = await self.verify_finding(finding, attack, connector, detectors)
            verifications.append(result)

        confirmed = sum(1 for v in verifications if v.status == "confirmed")
        intermittent = sum(1 for v in verifications if v.status == "intermittent")
        not_reproduced = sum(1 for v in verifications if v.status == "not_reproduced")

        report = VerificationReport(
            total_verified=len(verifications),
            confirmed=confirmed,
            intermittent=intermittent,
            not_reproduced=not_reproduced,
            verifications=verifications,
            verification_timestamp=datetime.now(UTC).isoformat(),
        )

        logger.info(
            "verification_report_complete",
            total=report.total_verified,
            confirmed=report.confirmed,
            intermittent=report.intermittent,
            not_reproduced=report.not_reproduced,
        )

        return report
