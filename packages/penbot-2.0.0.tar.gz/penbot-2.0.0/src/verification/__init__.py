"""Persistence verification for security findings."""
