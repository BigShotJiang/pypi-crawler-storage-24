"""SQLAlchemy engine and session factory."""

from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from src.utils.config import settings
from src.utils.logging import get_logger

logger = get_logger(__name__)

_engine = None
_SessionLocal = None


def get_engine():
    """Return the singleton SQLAlchemy engine."""
    global _engine
    if _engine is None:
        url = settings.database_url
        connect_args = {}
        if url.startswith("sqlite"):
            connect_args["check_same_thread"] = False

        _engine = create_engine(
            url,
            connect_args=connect_args,
            pool_pre_ping=True,
        )
        logger.info("database_engine_created", url=url.split("@")[-1])
    return _engine


def get_session() -> Session:
    """Create a new database session."""
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(bind=get_engine())
    return _SessionLocal()


def init_db() -> None:
    """Create all tables if they don't exist."""
    from .models import Base

    engine = get_engine()
    Base.metadata.create_all(bind=engine)
    logger.info("database_tables_created")
