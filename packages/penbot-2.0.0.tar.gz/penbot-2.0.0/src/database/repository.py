"""High-level repository for reading/writing test sessions to the database."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy.orm import Session as SASession

from src.utils.logging import get_logger

from .engine import get_session
from .models import DBAttackAttempt, DBSecurityFinding, DBTargetResponse, DBTestSession

logger = get_logger(__name__)


class SessionRepository:
    """CRUD operations for test sessions and related entities."""

    def __init__(self, db: SASession | None = None):
        self._db = db

    def _get_db(self) -> SASession:
        if self._db is not None:
            return self._db
        return get_session()

    # ------------------------------------------------------------------
    # Session CRUD
    # ------------------------------------------------------------------

    def create_session(self, session_data: dict[str, Any]) -> DBTestSession:
        db = self._get_db()
        extra = session_data.get("extra") or {}
        if session_data.get("verification_report"):
            extra["verification_report"] = session_data["verification_report"]
        if session_data.get("discovered_tool_inventory"):
            extra["discovered_tool_inventory"] = session_data["discovered_tool_inventory"]
        row = DBTestSession(
            id=session_data["test_session_id"],
            target_name=session_data.get("target_name", "Unknown"),
            target_type=session_data.get("target_type", "api"),
            target_config=session_data.get("target_config"),
            attack_group=session_data.get("attack_group"),
            max_attempts=session_data.get("max_attempts", 10),
            current_attempt=session_data.get("current_attempt", 0),
            test_status=session_data.get("test_status", "running"),
            started_at=_parse_dt(session_data.get("started_at")),
            extra=extra or None,
        )
        db.merge(row)
        db.commit()
        logger.debug("db_session_created", session_id=row.id)
        return row

    def update_session_status(
        self,
        session_id: str,
        *,
        status: str | None = None,
        vulnerability_score: float | None = None,
        current_attempt: int | None = None,
        completed_at: datetime | None = None,
    ) -> None:
        db = self._get_db()
        row = db.get(DBTestSession, session_id)
        if row is None:
            return
        if status is not None:
            row.test_status = status
        if vulnerability_score is not None:
            row.vulnerability_score = vulnerability_score
        if current_attempt is not None:
            row.current_attempt = current_attempt
        if completed_at is not None:
            row.completed_at = completed_at
        db.commit()

    def get_session(self, session_id: str) -> DBTestSession | None:
        db = self._get_db()
        return db.get(DBTestSession, session_id)

    def list_sessions(self, limit: int = 50, offset: int = 0) -> list[dict[str, Any]]:
        db = self._get_db()
        rows = (
            db.query(DBTestSession)
            .order_by(DBTestSession.started_at.desc())
            .offset(offset)
            .limit(limit)
            .all()
        )
        return [_session_to_dict(r) for r in rows]

    def delete_session(self, session_id: str) -> bool:
        db = self._get_db()
        row = db.get(DBTestSession, session_id)
        if row is None:
            return False
        db.delete(row)
        db.commit()
        return True

    # ------------------------------------------------------------------
    # Attacks
    # ------------------------------------------------------------------

    def add_attack(self, session_id: str, attack: dict[str, Any]) -> None:
        db = self._get_db()
        row = DBAttackAttempt(
            id=attack["attack_id"],
            session_id=session_id,
            agent_name=attack.get("agent_name", "unknown"),
            attack_type=attack.get("attack_type", "unknown"),
            query=attack.get("query", ""),
            pattern=attack.get("pattern") or attack.get("metadata", {}).get("pattern"),
            parent_attack_id=attack.get("parent_attack_id"),
            metadata_=attack.get("metadata"),
            created_at=_parse_dt(attack.get("timestamp")),
        )
        db.merge(row)
        db.commit()

    # ------------------------------------------------------------------
    # Responses
    # ------------------------------------------------------------------

    def add_response(self, session_id: str, response: dict[str, Any]) -> None:
        db = self._get_db()
        row = DBTargetResponse(
            id=response["response_id"],
            session_id=session_id,
            attack_id=response.get("attack_id", ""),
            content=response.get("content", ""),
            response_time_ms=response.get("metadata", {}).get("response_time_ms"),
            metadata_=response.get("metadata"),
            created_at=_parse_dt(response.get("timestamp")),
        )
        db.merge(row)
        db.commit()

    # ------------------------------------------------------------------
    # Findings
    # ------------------------------------------------------------------

    def add_finding(self, session_id: str, finding: dict[str, Any]) -> None:
        db = self._get_db()
        row = DBSecurityFinding(
            id=finding["finding_id"],
            session_id=session_id,
            attack_id=finding.get("attack_id"),
            severity=finding.get("severity", "info"),
            category=finding.get("category", "unknown"),
            description=finding.get("description", ""),
            evidence=finding.get("evidence"),
            confidence=finding.get("confidence", 0.0),
            owasp_category=finding.get("owasp_category"),
            metadata_=finding.get("metadata"),
            created_at=_parse_dt(finding.get("timestamp")),
        )
        db.merge(row)
        db.commit()

    def get_findings(self, session_id: str) -> list[dict[str, Any]]:
        db = self._get_db()
        rows = (
            db.query(DBSecurityFinding)
            .filter(DBSecurityFinding.session_id == session_id)
            .order_by(DBSecurityFinding.created_at)
            .all()
        )
        return [_finding_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Bulk save (used at end of test or by migration)
    # ------------------------------------------------------------------

    def save_full_session(self, state: dict[str, Any]) -> None:
        """Persist an entire session state dict (attacks, responses, findings)."""
        session_id = state.get("test_session_id", "")
        if not session_id:
            return

        self.create_session(state)

        for attack in state.get("attack_attempts", []):
            self.add_attack(session_id, attack)

        for response in state.get("target_responses", []):
            self.add_response(session_id, response)

        for finding in state.get("security_findings", []):
            self.add_finding(session_id, finding)

        self.update_session_status(
            session_id,
            status=state.get("test_status", "completed"),
            vulnerability_score=state.get("vulnerability_score", 0.0),
            current_attempt=state.get("current_attempt", 0),
            completed_at=_parse_dt(state.get("completed_at")) or datetime.now(UTC),
        )
        logger.info(
            "db_full_session_saved",
            session_id=session_id,
            attacks=len(state.get("attack_attempts", [])),
            findings=len(state.get("security_findings", [])),
        )


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _parse_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    return None


def _session_to_dict(row: DBTestSession) -> dict[str, Any]:
    return {
        "test_session_id": row.id,
        "target_name": row.target_name,
        "target_type": row.target_type,
        "attack_group": row.attack_group,
        "max_attempts": row.max_attempts,
        "current_attempt": row.current_attempt,
        "vulnerability_score": row.vulnerability_score,
        "test_status": row.test_status,
        "started_at": row.started_at.isoformat() if row.started_at else None,
        "completed_at": row.completed_at.isoformat() if row.completed_at else None,
        "attack_count": len(row.attacks),
        "finding_count": len(row.findings),
    }


def _finding_to_dict(row: DBSecurityFinding) -> dict[str, Any]:
    return {
        "finding_id": row.id,
        "session_id": row.session_id,
        "attack_id": row.attack_id,
        "severity": row.severity,
        "category": row.category,
        "description": row.description,
        "evidence": row.evidence,
        "confidence": row.confidence,
        "owasp_category": row.owasp_category,
        "created_at": row.created_at.isoformat() if row.created_at else None,
    }
