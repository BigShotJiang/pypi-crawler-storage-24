"""Distill raw endpoint maps into compact attack surface intelligence for agents.

Transforms the verbose ``endpoint_map`` produced by :class:`EndpointMapper`
into a concise summary that agents can consume to generate targeted attacks.
"""

from __future__ import annotations

from typing import Any

from src.utils.logging import get_logger

logger = get_logger(__name__)


def extract_attack_surface_intel(endpoint_map: dict[str, Any]) -> dict[str, Any]:
    """Distill a raw endpoint map into a compact agent-consumable summary.

    Args:
        endpoint_map: The structured endpoint map from
            :meth:`EndpointMapper.build_endpoint_map`, typically stored at
            ``sandbox_state["endpoint_map"]``.

    Returns:
        A dict with keys:
            - ``unauthenticated_endpoints``: list of paths that returned 200
              without auth
            - ``auth_required_endpoints``: list of paths that returned 401/403
            - ``framework_hints``: detected web framework names
            - ``auth_provider``: detected auth provider name (or ``None``)
            - ``auth_test_mode``: whether auth appears to be in test mode
            - ``admin_debug_paths``: paths that look like admin/debug surfaces
            - ``error_surface_patterns``: error responses that leak info
            - ``methods_allowed``: dict of HTTP methods accepted by the
              target beyond the standard GET/POST
            - ``high_value_targets``: paths most likely to yield findings
    """
    if not endpoint_map:
        return {}

    unauth = list(endpoint_map.get("unauthenticated_endpoints", []))
    auth_required = [
        ep["path"] for ep in endpoint_map.get("discovered", []) if ep.get("auth_required")
    ]

    framework_hints = list(endpoint_map.get("framework_hints", []))

    auth_config = endpoint_map.get("auth_config", {})
    auth_provider = auth_config.get("provider")
    auth_test_mode = auth_config.get("test_mode", False)

    admin_debug_paths = _extract_admin_debug_paths(endpoint_map)
    error_surface = _extract_error_surface(endpoint_map)
    methods_allowed = dict(endpoint_map.get("methods_allowed", {}))
    high_value = _identify_high_value_targets(endpoint_map)

    intel = {
        "unauthenticated_endpoints": unauth,
        "auth_required_endpoints": auth_required,
        "framework_hints": framework_hints,
        "auth_provider": auth_provider,
        "auth_test_mode": auth_test_mode,
        "admin_debug_paths": admin_debug_paths,
        "error_surface_patterns": error_surface,
        "methods_allowed": methods_allowed,
        "high_value_targets": high_value,
    }

    logger.info(
        "attack_surface_intel_extracted",
        unauthenticated=len(unauth),
        auth_required=len(auth_required),
        frameworks=framework_hints,
        admin_debug=len(admin_debug_paths),
        high_value=len(high_value),
    )

    return intel


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ADMIN_DEBUG_KEYWORDS = (
    "admin",
    "debug",
    "actuator",
    "telescope",
    "_debugbar",
    "pprof",
    "server-status",
    "graphiql",
    "swagger",
    "redoc",
    "__debug__",
    "horizon",
)


def _extract_admin_debug_paths(endpoint_map: dict[str, Any]) -> list[str]:
    """Find paths that look like admin or debug surfaces."""
    paths: list[str] = []
    for ep in endpoint_map.get("discovered", []):
        p = ep.get("path", "").lower()
        if any(kw in p for kw in _ADMIN_DEBUG_KEYWORDS):
            paths.append(ep["path"])
    return paths


def _extract_error_surface(endpoint_map: dict[str, Any]) -> list[dict[str, Any]]:
    """Return error patterns that leaked information."""
    patterns: list[dict[str, Any]] = []
    for ep in endpoint_map.get("error_patterns", []):
        patterns.append(
            {
                "label": ep.get("label", ""),
                "status": ep.get("status", 0),
                "preview": ep.get("body_preview", "")[:100],
            }
        )
    return patterns


_HIGH_VALUE_KEYWORDS = (
    "config",
    "env",
    "secret",
    "token",
    "key",
    "auth",
    "admin",
    "debug",
    "internal",
    "graphql",
    "actuator",
    "metrics",
    "info",
    "version",
    "openapi",
    "swagger",
)


def _identify_high_value_targets(endpoint_map: dict[str, Any]) -> list[str]:
    """Identify paths most likely to yield security findings."""
    high_value: list[str] = []

    for ep in endpoint_map.get("discovered", []):
        path = ep.get("path", "").lower()
        status = ep.get("status", 0)
        if status in (0, 404):
            continue
        if any(kw in path for kw in _HIGH_VALUE_KEYWORDS):
            high_value.append(ep["path"])

    for ep in endpoint_map.get("error_patterns", []):
        label = ep.get("label", "")
        if label:
            high_value.append(f"error:{label}")

    return list(dict.fromkeys(high_value))
