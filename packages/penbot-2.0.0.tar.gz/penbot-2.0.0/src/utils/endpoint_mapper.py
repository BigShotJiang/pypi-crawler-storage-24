"""Systematic API endpoint reconnaissance and attack surface mapping.

Inspired by CodeWall's methodology of mapping 200+ endpoints and finding
22 unauthenticated ones. The ``EndpointMapper`` runs a structured enumeration
pass on the first activation, then switches to targeted probing on subsequent
activations based on what was discovered.
"""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlparse

from src.utils.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Default probe lists
# ---------------------------------------------------------------------------

_DEFAULT_COMMON_PATHS: list[str] = [
    "/robots.txt",
    "/sitemap.xml",
    "/.well-known/openid-configuration",
    "/.well-known/security.txt",
    "/api/docs",
    "/api/v1/docs",
    "/swagger.json",
    "/swagger-ui.html",
    "/openapi.json",
    "/openapi.yaml",
    "/graphql",
    "/graphiql",
    "/admin",
    "/admin/",
    "/_admin",
    "/.env",
    "/health",
    "/healthz",
    "/status",
    "/metrics",
    "/debug",
    "/debug/vars",
    "/debug/pprof",
    "/actuator",
    "/actuator/health",
    "/actuator/env",
    "/server-status",
    "/config",
    "/info",
    "/version",
    "/api/version",
]

_AUTH_PROVIDER_PATHS: list[str] = [
    "/.well-known/openid-configuration",
    "/auth/config",
    "/auth/login",
    "/oauth/authorize",
    "/oauth/token",
    "/v1/auth",
    "/.auth/me",
    # Clerk
    "/v1/client",
    "/.clerk/",
    # Auth0
    "/.well-known/jwks.json",
    "/userinfo",
    # Firebase
    "/__/auth/handler",
    "/__/auth/iframe",
    "/__/firebase/init.json",
    # Supabase
    "/auth/v1/settings",
    "/rest/v1/",
]

_FRAMEWORK_SPECIFIC: dict[str, list[str]] = {
    "django": ["/admin/", "/admin/login/", "/__debug__/", "/static/admin/"],
    "express": ["/api-docs/", "/__express_status/"],
    "flask": ["/static/", "/debug/"],
    "rails": ["/rails/info/routes", "/rails/mailers", "/rails/conductor/"],
    "spring": ["/actuator", "/actuator/beans", "/actuator/configprops", "/actuator/mappings"],
    "laravel": ["/telescope", "/_debugbar/", "/horizon"],
    "fastapi": ["/docs", "/redoc", "/openapi.json"],
    "nextjs": ["/_next/data/", "/api/auth/providers"],
}

_ERROR_SURFACE_PAYLOADS: list[dict[str, Any]] = [
    {"label": "malformed_json", "body": "{invalid json}", "content_type": "application/json"},
    {"label": "missing_content_type", "body": "test", "content_type": None},
    {"label": "oversized_payload", "body": "A" * 100_000, "content_type": "application/json"},
    {"label": "empty_body", "body": "", "content_type": "application/json"},
    {
        "label": "xml_injection",
        "body": '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><root>&xxe;</root>',
        "content_type": "application/xml",
    },
]

_METHODS_TO_TEST: list[str] = ["OPTIONS", "HEAD", "TRACE", "PUT", "DELETE", "PATCH"]


# ---------------------------------------------------------------------------
# EndpointMapper
# ---------------------------------------------------------------------------


class EndpointMapper:
    """Build a structured attack surface map via systematic endpoint enumeration."""

    def __init__(
        self,
        base_url: str,
        chat_path: str = "/",
        *,
        extra_paths: list[str] | None = None,
        patterns_file: str | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.chat_path = chat_path
        self.extra_paths = extra_paths or []

        self._common_paths = list(_DEFAULT_COMMON_PATHS)
        self._auth_paths = list(_AUTH_PROVIDER_PATHS)
        self._framework_paths = dict(_FRAMEWORK_SPECIFIC)
        self._error_payloads = list(_ERROR_SURFACE_PAYLOADS)
        self._methods = list(_METHODS_TO_TEST)

        if patterns_file:
            self._load_patterns(patterns_file)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_phase1_probes(self) -> list[dict[str, Any]]:
        """Return the list of probes for phase 1 (first enumeration pass).

        Each probe is a dict with ``method``, ``path``, ``headers``, ``body``,
        ``label``, and ``category``.
        """
        probes: list[dict[str, Any]] = []

        all_paths = self._common_paths + self._auth_paths + self.extra_paths
        seen: set[str] = set()
        for path in all_paths:
            if path in seen:
                continue
            seen.add(path)
            probes.append(
                {
                    "method": "GET",
                    "path": path,
                    "headers": {},
                    "body": None,
                    "label": f"enumerate:{path}",
                    "category": "path_enumeration",
                }
            )

        for payload in self._error_payloads:
            probes.append(
                {
                    "method": "POST",
                    "path": self.chat_path,
                    "headers": (
                        {"Content-Type": payload["content_type"]} if payload["content_type"] else {}
                    ),
                    "body": payload["body"],
                    "label": f"error_surface:{payload['label']}",
                    "category": "error_surface",
                }
            )

        for method in self._methods:
            probes.append(
                {
                    "method": method,
                    "path": self.chat_path,
                    "headers": {},
                    "body": None,
                    "label": f"method_test:{method}",
                    "category": "method_testing",
                }
            )

        return probes

    def get_phase2_probes(self, endpoint_map: dict[str, Any]) -> list[dict[str, Any]]:
        """Return targeted probes based on phase-1 discoveries.

        Args:
            endpoint_map: The ``endpoint_map`` dict built from phase-1 results.
        """
        if not endpoint_map:
            return []

        probes: list[dict[str, Any]] = []

        framework_hints = endpoint_map.get("framework_hints", [])
        for framework in framework_hints:
            for path in self._framework_paths.get(framework, []):
                probes.append(
                    {
                        "method": "GET",
                        "path": path,
                        "headers": {},
                        "body": None,
                        "label": f"framework:{framework}:{path}",
                        "category": "framework_specific",
                    }
                )

        for ep in endpoint_map.get("discovered", []):
            if ep.get("status") == 200 and not ep.get("auth_required"):
                probes.append(
                    {
                        "method": "POST",
                        "path": ep["path"],
                        "headers": {"Content-Type": "application/json"},
                        "body": '{"test": true}',
                        "label": f"deep_probe:{ep['path']}",
                        "category": "unauthenticated_deep_probe",
                    }
                )

        auth_config = endpoint_map.get("auth_config", {})
        if auth_config.get("provider"):
            provider = auth_config["provider"]
            for key in ("issuer", "authorization_endpoint", "token_endpoint"):
                url = auth_config.get(key, "")
                if url and url.startswith("http"):
                    parsed = urlparse(url)
                    probes.append(
                        {
                            "method": "GET",
                            "path": parsed.path,
                            "headers": {},
                            "body": None,
                            "label": f"auth_probe:{provider}:{key}",
                            "category": "auth_deep_probe",
                        }
                    )

        return probes

    @staticmethod
    def build_endpoint_map(probe_results: list[dict[str, Any]]) -> dict[str, Any]:
        """Build a structured endpoint map from probe results.

        Args:
            probe_results: List of ``{"probe": <probe_dict>, "response": <resp_dict>}``
                where ``response`` has ``status``, ``headers``, ``body``.

        Returns:
            Structured endpoint map ready for storage in ``sandbox_state``.
        """
        endpoint_map: dict[str, Any] = {
            "discovered": [],
            "auth_config": {},
            "framework_hints": [],
            "error_patterns": [],
            "unauthenticated_endpoints": [],
            "methods_allowed": {},
        }

        seen_paths: set[str] = set()

        for result in probe_results:
            probe = result.get("probe", {})
            resp = result.get("response", {})
            status = resp.get("status", 0)
            body = resp.get("body", "")
            headers = resp.get("headers", {})
            path = probe.get("path", "")
            category = probe.get("category", "")

            if category == "path_enumeration" and status > 0 and path not in seen_paths:
                seen_paths.add(path)
                auth_required = status in (401, 403)
                entry = {
                    "path": path,
                    "status": status,
                    "auth_required": auth_required,
                    "content_type": headers.get("content-type", ""),
                }
                endpoint_map["discovered"].append(entry)

                if not auth_required and status == 200:
                    endpoint_map["unauthenticated_endpoints"].append(path)

                _detect_auth_config(path, body, endpoint_map)
                _detect_framework(body, headers, endpoint_map)

            elif category == "error_surface":
                label = probe.get("label", "")
                if status >= 500:
                    endpoint_map["error_patterns"].append(
                        {"label": label, "status": status, "body_preview": body[:200]}
                    )
                _detect_framework(body, headers, endpoint_map)

            elif category == "method_testing":
                method = probe.get("method", "")
                if status not in (0, 405):
                    allowed = headers.get("allow", "")
                    endpoint_map["methods_allowed"][method] = (
                        allowed if allowed else f"status_{status}"
                    )

        endpoint_map["framework_hints"] = list(set(endpoint_map["framework_hints"]))
        return endpoint_map

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _load_patterns(self, path: str) -> None:
        """Load additional probe paths from a JSON patterns file."""
        try:
            with open(path) as f:
                data = json.load(f)
            for cat, paths in data.items():
                if cat == "common_paths" and isinstance(paths, list):
                    self._common_paths.extend(paths)
                elif cat == "auth_providers" and isinstance(paths, list):
                    self._auth_paths.extend(paths)
                elif cat == "frameworks" and isinstance(paths, dict):
                    for fw, fw_paths in paths.items():
                        existing = self._framework_paths.setdefault(fw, [])
                        existing.extend(fw_paths)
            logger.info("endpoint_patterns_loaded", path=path)
        except Exception as exc:
            logger.warning("endpoint_patterns_load_failed", path=path, error=str(exc))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _detect_auth_config(path: str, body: str, endpoint_map: dict[str, Any]) -> None:
    """Try to detect auth provider from response body."""
    lower = body.lower() if body else ""

    if "openid-configuration" in path:
        try:
            data = json.loads(body)
            endpoint_map["auth_config"] = {
                "provider": _guess_auth_provider(data),
                "issuer": data.get("issuer", ""),
                "authorization_endpoint": data.get("authorization_endpoint", ""),
                "token_endpoint": data.get("token_endpoint", ""),
                "test_mode": "test" in data.get("issuer", "").lower(),
            }
        except (json.JSONDecodeError, TypeError):
            pass

    if "clerk" in lower:
        endpoint_map["auth_config"].setdefault("provider", "clerk")
    elif "auth0" in lower:
        endpoint_map["auth_config"].setdefault("provider", "auth0")
    elif "firebase" in lower or "identitytoolkit" in lower:
        endpoint_map["auth_config"].setdefault("provider", "firebase")
    elif "supabase" in lower:
        endpoint_map["auth_config"].setdefault("provider", "supabase")


def _guess_auth_provider(oidc_data: dict) -> str:
    """Guess auth provider from OIDC discovery document."""
    issuer = (oidc_data.get("issuer") or "").lower()
    if "clerk" in issuer:
        return "clerk"
    if "auth0" in issuer:
        return "auth0"
    if "accounts.google" in issuer:
        return "google"
    if "login.microsoftonline" in issuer:
        return "azure_ad"
    if "cognito" in issuer:
        return "aws_cognito"
    return "unknown_oidc"


def _detect_framework(body: str, headers: dict[str, str], endpoint_map: dict[str, Any]) -> None:
    """Detect framework hints from response body and headers."""
    lower = body.lower() if body else ""
    server = (headers.get("server") or headers.get("Server") or "").lower()
    powered = (headers.get("x-powered-by") or headers.get("X-Powered-By") or "").lower()

    hints: list[str] = []

    if "django" in lower or "django" in server or "django" in powered:
        hints.append("django")
    if "express" in powered:
        hints.append("express")
    if "flask" in lower or "werkzeug" in server:
        hints.append("flask")
    if "rails" in powered or "rails" in lower:
        hints.append("rails")
    if "spring" in lower or "spring" in server:
        hints.append("spring")
    if "laravel" in lower or "laravel" in powered:
        hints.append("laravel")
    if "fastapi" in lower or "uvicorn" in server:
        hints.append("fastapi")
    if "next" in powered or "nextjs" in lower:
        hints.append("nextjs")
    if "node" in powered or "koa" in powered:
        hints.append("node")

    endpoint_map.setdefault("framework_hints", []).extend(hints)
