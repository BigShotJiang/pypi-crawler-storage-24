"""StrawPot — lightweight CLI for agent orchestration."""

__version__ = "0.1.34"
