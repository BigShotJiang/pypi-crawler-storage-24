"""
Test: Everything

Version: 6.5.0
Date updated: 21/03/2026 (dd/mm/yyyy)
"""

# Library
# ---------------------------------------------------------------------------
import pytest

try:  # [beautiful] feature
    import rich  # type: ignore
except ImportError:
    rich = pytest.importorskip("rich")

try:
    import requests  # type: ignore
    from bs4 import BeautifulSoup
except ImportError:
    bs4 = pytest.importorskip("bs4")
    BeautifulSoup = pytest.importorskip("BeautifulSoup")
    requests = pytest.importorskip("requests")


# --- Loading test --------------------------------------------------------
from absfuyu import __author__, __license__, __title__, __version__
from absfuyu.config import (
    _SPACE_REPLACE,
    ABSFUYU_CONFIG,
    Config,
    ConfigFormat,
    Setting,
    SettingDictFormat,
)
from absfuyu.core import (
    BaseClass,
    CLITextColor,
    GetClassMembersMixin,
    HexColor,
    __package_feature__,
    deprecated,
    tqdm,
    unidecode,
    versionadded,
    versionchanged,
)
from absfuyu.core.baseclass import (
    AutoREPRMixin,
    BaseDataclass,
    ClassMembers,
    ClassMembersResult,
    PositiveInitArgsMeta,
)
from absfuyu.core.baseclass2 import (
    PerformanceTrackingMeta,
    ShowAllMethodsMixinInspectVer,
    positive_class_init_args,
)
from absfuyu.core.decorator import (
    add_subclass_methods_decorator,
    dummy_decorator,
    dummy_decorator_with_args,
)
from absfuyu.core.docstring import (
    _SPHINX_DOCS_TEMPLATE,
    SphinxDocstring,
    SphinxDocstringMode,
    pendingremove,
)
from absfuyu.core.dummy_func import dummy_function
from absfuyu.dxt import (
    DictAnalyzeResult,
    DictBoolFalse,
    DictBoolTrue,
    DictExt,
    IntExt,
    ListExt,
    ListNoDunder,
    ListREPR,
    Text,
    TextAnalyzeDictFormat,
)
from absfuyu.extra import is_loaded
from absfuyu.extra.audio._util import ResultStatus, StatusCode
from absfuyu.extra.audio.convert import DirectoryAudioConvertMixin
from absfuyu.extra.audio.lossless import (  # Has numpy
    AudioInfo,
    DirectoryAudioLosslessCheckMixin,
)
from absfuyu.extra.beautiful import BeautifulOutput  # Has rich
from absfuyu.extra.da.dadf import (  # Has pandas, numpy
    DADF,
    DataAnalystDataFrameCityMixin,
    DataAnalystDataFrameColumnMethodMixin,
    DataAnalystDataFrameDateMixin,
    DataAnalystDataFrameHeaderMixin,
    DataAnalystDataFrameInfoMixin,
    DataAnalystDataFrameNAMixin,
    DataAnalystDataFrameOtherMixin,
    DataAnalystDataFrameRowMethodMixin,
)
from absfuyu.extra.da.dadf_base import (  # Has pandas, numpy
    CityData,
    DataAnalystDataFrameBase,
    SplittedDF,
)
from absfuyu.extra.da.df_func import (  # Has pandas, numpy
    compare_2_list,
    equalize_df,
    rename_with_dict,
)
from absfuyu.extra.da.export import (
    ConditionalRule,
    DataFrameExcelExporter,
    ExcelCellOperator,
    ExcelCellRuleType,
    ExcelDateFormat,
    ExcelDateFormatTemplate,
    ExcelStyleConfig,
    FreezePreset,
    HorizontalAlign,
    SheetConfig,
    SupportDataFrameExporter,
    VerticalAlign,
    build_alignment,
    detect_header_start_row,
)
from absfuyu.extra.da.mplt import MatplotlibFormatString, _PLTFormatString
from absfuyu.extra.gform import FormStateMachine, GoogleFormParser
from absfuyu.extra.gform.models import FormID, GoogleForm, Question, QuestionType
from absfuyu.extra.ggapi.gdrive import DriveFileMeta, GoogleDriveClient, GoogleDriveFile
from absfuyu.extra.ggapi.glicense import GGSheetOnlineLicenseSystem, LicenseEntry
from absfuyu.extra.ggapi.gsheet import GoogleSheet
from absfuyu.extra.img.converter import (  # has PIL, pillow_heif, pillow_jxl
    ConvertMultithreaded,
    ImgConverter,
    SupportConvertEngine,
    SupportedImageFormat,
    SupportImageConverter,
    _image_convert_avif,
    _image_convert_default,
    _image_convert_jpg,
    _image_convert_jxl,
    _image_convert_png,
    _image_convert_webp,
)
from absfuyu.extra.img.dup_check import (  # Has imagehash, PIL
    DirectoryRemoveDuplicateImageMixin,
    DuplicateImgPair,
    HashMode,
    ImageInfo,
)
from absfuyu.extra.rclone import (  # Has rclone
    DirectoryRcloneDEMixin,
    RcloneEncryptDecrypt,
)
from absfuyu.extra.xml import XML2Dict  # Has xmltodict
from absfuyu.fun import happy_new_year, human_year_to_dog_year, zodiac_sign
from absfuyu.fun.rubik import (
    OLL,
    PLL,
    PLL_PIC,
    Cross,
    PLLs,
    Rubik3x3,
    RubikAlgorithm,
    RubikNotation,
    RubikNotations,
)
from absfuyu.fun.tarot import Tarot, TarotCard
from absfuyu.game import GameStats, game_escapeLoop, game_RockPaperScissors
from absfuyu.game.sudoku import Sudoku
from absfuyu.game.tictactoe import GameMode, TicTacToe
from absfuyu.game.wordle import Wordle  # Has requests

# --- Sub-package ---
from absfuyu.general.content import (  # Has unidecode
    Content,
    ContentLoader,
    LoadedContent,
)
from absfuyu.general.human import BloodType, Human, Person
from absfuyu.general.resrel import RelativeResoluton, RelativeResolutonTranslater
from absfuyu.general.resume import (
    CV,
    CVBuilder,
    CVEngine,
    DictExporter,
    Education,
    Experience,
    ExperienceSorter,
    Exporter,
    ExportRegistry,
    JSONExporter,
    LatestFirstSorter,
    MarkdownExporter,
    PersonalInfo,
    Project,
)
from absfuyu.general.shape import (
    Circle,
    Cube,
    Cuboid,
    Cylinder,
    EqualSidesPolygon,
    HemiSphere,
    Hexagon,
    Parallelogram,
    Pentagon,
    Polygon,
    Rectangle,
    Rhombus,
    Shape,
    Sphere,
    Square,
    ThreeDimensionShape,
    Trapezoid,
    Triangle,
)
from absfuyu.general.tax import (
    PersonalIncomeTaxCalculator,
    TaxCalculationResult,
    TaxCalculationResultRaw,
    TaxLevel,
    TaxLevelResult,
)

# from absfuyu.logger import *
from absfuyu.logger import (
    AbsfuyuLogger,
    LoggerMixin,
    LoggingJSONFormatter,
    LogLevel,
    LogLevelUpperFilter,
    compress_for_log,
    logger,
)
from absfuyu.numbers.number_to_word import (
    NumberToWords,
    NumberToWordsBase,
    NumberToWordsEN,
    NumberToWordsVI,
)
from absfuyu.numbers.shorten_number import (
    CommonUnitSuffixesFactory,
    ShortNumber,
    UnitSuffixFactory,
    shorten_number,
)
from absfuyu.numbers.time_duration import Duration, SupportDurationFormatPreset
from absfuyu.pkg_data import BasicLZMAOperation, DataList, DataLoader, Pickler
from absfuyu.pkg_data.logo import AbsfuyuLogo
from absfuyu.sort import binary_search, insertion_sort, linear_search, selection_sort

# from absfuyu.tools import *
from absfuyu.tools.checksum import Checksum, ChecksumMode
from absfuyu.tools.converter import (
    Base64EncodeDecode,
    ChemistryElement,
    Str2Pixel,
    Text2Chemistry,
)
from absfuyu.tools.generator import Charset, Generator
from absfuyu.tools.inspector import Inspector, inspect_all
from absfuyu.tools.keygen import Keygen
from absfuyu.tools.obfuscator import Obfuscator, StrShifter
from absfuyu.tools.passwordlib import TOTP, PasswordGenerator, PasswordHash
from absfuyu.tools.shutdownizer import (
    ShutdownEngine,
    ShutdownEngineLinux,
    ShutdownEngineMac,
    ShutdownEngineWin,
    ShutDownizer,
)
from absfuyu.tools.sw import (
    BasicSoftwareProtection,
    HWIDgen,
    LicenseKey,
    LicenseKeySystem,
    PyinstallerHelper,
    PyinstallerHiddenImportPreset,
    SystemInfo,
    get_pyinstaller_exe_dir,
    get_pyinstaller_resource_path,
    get_system_info,
)
from absfuyu.tools.web import gen_random_commit_msg, soup_link  # Has bs4, requests
from absfuyu.typings import (
    _CALLABLE,
    CT,
    KT,
    VT,
    N,
    P,
    R,
    SupportsShowMethods,
    T,
    T_co,
    T_contra,
    _Number,
)
from absfuyu.util import (
    convert_to_raw_unicode,
    get_end_of_month,
    get_installed_package,
    is_command_available,
    set_min_max,
    stop_after_day,
)
from absfuyu.util.api import APIRequest, ping_windows  # Has requests
from absfuyu.util.json_method import JsonFile
from absfuyu.util.lunar import LunarCalendar
from absfuyu.util.multithread_runner import MultiThreadRunner
from absfuyu.util.package import PackageManager
from absfuyu.util.path import (
    ORGANIZE_TEMPLATE,
    Directory,
    DirectoryArchiverMixin,
    DirectoryBase,
    DirectoryBasicOperationMixin,
    DirectoryInfo,
    DirectoryInfoMixin,
    DirectoryOrganizerMixin,
    DirectorySelectMixin,
    DirectoryTreeMixin,
    DirOpener,
    FileContent,
    FileOrFolderWithModificationTime,
    ProjectDirInit,
    ProjectDirInitTemplate,
    SaveFileAs,
)
from absfuyu.util.performance import (
    Checker,
    function_benchmark,
    function_debug,
    measure_performance,
    retry,
)
from absfuyu.util.text_table import (
    BoxDrawingCharacterBase,
    BoxDrawingCharacterBold,
    BoxDrawingCharacterDashed,
    BoxDrawingCharacterDashed3,
    BoxDrawingCharacterDashed4,
    BoxDrawingCharacterDashedBold,
    BoxDrawingCharacterDashedRound,
    BoxDrawingCharacterDiamond,
    BoxDrawingCharacterDouble,
    BoxDrawingCharacterNormal,
    BoxDrawingCharacterRounded,
    BoxStyle,
    OneColumnTableMaker,
    get_box_drawing_character,
)
from absfuyu.version import (
    Bumper,
    PkgVersion,
    ReleaseLevel,
    ReleaseOption,
    Version,
    VersionDictFormat,
)


# Test
# ---------------------------------------------------------------------------
def test_everything():
    assert True
