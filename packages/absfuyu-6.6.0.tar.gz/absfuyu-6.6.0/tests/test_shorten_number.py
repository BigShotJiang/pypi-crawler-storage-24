"""
Test: Shorten number

Version: 6.5.0
Date updated: 21/03/2026 (dd/mm/yyyy)
"""

import pytest

from absfuyu.numbers.shorten_number import CommonUnitSuffixesFactory, ShortNumber


class TestShortenNumber:
    """absfuyu.util.shorten_number"""

    @pytest.mark.parametrize(["value", "output"], [(1000, 1.0), (1000000, 1.0)])
    def test_number(self, value: int | float, output: float) -> None:
        ins = ShortNumber.number(value)
        assert ins.value == output

    def test_number2(self) -> None:
        fac = CommonUnitSuffixesFactory.NUMBER
        unit = 1
        for i, suffix in enumerate(fac.short_name):
            unit = fac.base**i
            assert ShortNumber.number(unit).suffix == suffix

    def test_data_size(self) -> None:
        fac = CommonUnitSuffixesFactory.DATA_SIZE
        unit = 1
        for i, suffix in enumerate(fac.short_name):
            unit = fac.base**i
            assert ShortNumber.data_size(unit).suffix == suffix
