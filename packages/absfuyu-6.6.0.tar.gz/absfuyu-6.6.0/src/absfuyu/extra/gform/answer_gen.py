"""
Absfuyu: Google form
--------------------
Google form - Answer generator - W.I.P

Version: 6.5.0
Date updated: 19/03/2026 (dd/mm/yyyy)
"""

# Library
# ---------------------------------------------------------------------------
import random
import string
from abc import ABC, abstractmethod
from typing import Any

from absfuyu.extra.gform.models import GoogleForm, Question, QuestionType


# Class
# ---------------------------------------------------------------------------
class AnswerGenerator(ABC):
    """
    Base class for answer generation
    """

    @abstractmethod
    def supports(self, question: Question) -> bool: ...

    @abstractmethod
    def generate(self, question: Question) -> Any: ...


class ShortAnswerGenerator(AnswerGenerator):

    def supports(self, question: Question) -> bool:
        return question.type == QuestionType.SHORT_ANSWER

    def generate(self, question: Question) -> str:
        return "".join(random.choices(string.ascii_lowercase, k=8))


class MultipleChoiceGenerator(AnswerGenerator):

    def supports(self, question: Question) -> bool:
        return question.type in {
            QuestionType.MULTIPLE_CHOICE,
            QuestionType.DROPDOWN,
        }

    def generate(self, question: Question) -> str:
        return random.choice(question.options) if question.options else None


class CheckboxGenerator(AnswerGenerator):

    def supports(self, question: Question) -> bool:
        return question.type == QuestionType.CHECKBOXES

    def generate(self, question: Question):
        if not question.options:
            return None
        k = random.randint(1, len(question.options))
        return random.sample(question.options, k=k)


class AnswerFactory:

    def __init__(self):
        self._generators: list[AnswerGenerator] = []

    def register(self, generator: AnswerGenerator) -> None:
        self._generators.append(generator)

    def generate(self, form: GoogleForm) -> dict[str, str]:
        answers = {}

        for q in form.questions:
            for generator in self._generators:
                if generator.supports(q):
                    answers[q.text] = generator.generate(q)
                    break

        return answers
