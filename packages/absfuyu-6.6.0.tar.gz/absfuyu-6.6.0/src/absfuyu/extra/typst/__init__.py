"""
Absfuyu: Typst
--------------
Typst related

Version: 6.5.0
Date updated: 19/03/2026 (dd/mm/yyyy)
"""
