"""
Absfuyu: Resume
---------------
Resume Function

Version: 6.5.0
Date updated: 19/03/2026 (dd/mm/yyyy)
"""

# Module level
# ---------------------------------------------------------------------------
__all__ = ["ExperienceSorter", "LatestFirstSorter"]


# Library
# ---------------------------------------------------------------------------
from datetime import date
from typing import Protocol

from absfuyu.general.resume.models import Experience


# Typing
# ---------------------------------------------------------------------------
class ExperienceSorter(Protocol):
    """
    Custom experiences sorter
    """

    def sort(self, experiences: list[Experience]) -> list[Experience]:
        """
        Sort experiences

        Parameters
        ----------
        experiences : list[Experience]
            Experiences

        Returns
        -------
        list[Experience]
            Experiences
        """
        ...


# Class
# ---------------------------------------------------------------------------
class LatestFirstSorter:
    """
    Sort experiences by:
    - Ongoing first
    - Latest end_date first
    - Latest start_date first
    """

    def sort(self, experiences: list[Experience]) -> list[Experience]:
        def key(exp: Experience):
            return (
                exp.end_date is None,
                exp.end_date or date.max,
                exp.start_date,
            )

        return sorted(experiences, key=key, reverse=True)
