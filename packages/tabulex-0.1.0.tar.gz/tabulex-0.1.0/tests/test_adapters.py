from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


pandas = pytest.importorskip("pandas")
polars = pytest.importorskip("polars")

from tabulex.adapters import table_to_pandas, table_to_polars
from tabulex.models import Cell, Table


def _make_table() -> Table:
    return Table(
        page_number=1,
        bbox=(0.0, 0.0, 100.0, 100.0),
        n_rows=2,
        n_cols=2,
        cells=[
            Cell(
                row=0,
                col=0,
                bbox=(0.0, 0.0, 50.0, 20.0),
                text="Merged",
                text_lines=["Merged"],
                images_base64=[],
                colspan=2,
            ),
            Cell(
                row=1,
                col=0,
                bbox=(0.0, 20.0, 50.0, 40.0),
                text="Receipt",
                text_lines=["Receipt"],
                images_base64=["QUJDRA=="],
            ),
        ],
    )


def _cell_payload(value):
    if value is None:
        return None
    if isinstance(value, str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    return value


def test_table_to_pandas_serializes_mixed_cells_and_preserves_spans():
    df = table_to_pandas(_make_table())

    assert df.shape == (2, 2)
    assert df.iloc[0, 0] == "Merged"
    assert pandas.isna(df.iloc[0, 1]) or df.iloc[0, 1] is None

    mixed = _cell_payload(df.iloc[1, 0])
    assert isinstance(mixed, dict)
    assert mixed["text"] == "Receipt"
    assert mixed["images_base64"] == ["QUJDRA=="]


def test_table_to_polars_serializes_mixed_cells_and_preserves_spans():
    df = table_to_polars(_make_table())

    assert df.shape == (2, 2)
    assert df.row(0)[0] == "Merged"
    assert df.row(0)[1] is None

    mixed = _cell_payload(df.row(1)[0])
    assert isinstance(mixed, dict)
    assert mixed["text"] == "Receipt"
    assert mixed["images_base64"] == ["QUJDRA=="]

