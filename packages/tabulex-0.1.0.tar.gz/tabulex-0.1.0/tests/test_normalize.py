from __future__ import annotations

import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


from tabulex.models import Cell, Table
from tabulex.normalize import normalize_table


def _make_table() -> Table:
    return Table(
        page_number=1,
        bbox=(0.0, 0.0, 100.0, 100.0),
        n_rows=2,
        n_cols=3,
        cells=[
            Cell(
                row=0,
                col=0,
                bbox=(0.0, 0.0, 60.0, 20.0),
                text="Header",
                text_lines=["Header"],
                images_base64=[],
                colspan=2,
            ),
            Cell(
                row=0,
                col=2,
                bbox=(60.0, 0.0, 100.0, 20.0),
                text=None,
                text_lines=["Line 1", "Line 2"],
                images_base64=[],
            ),
            Cell(
                row=1,
                col=0,
                bbox=(0.0, 20.0, 30.0, 40.0),
                text="A",
                text_lines=["A"],
                images_base64=[],
            ),
            Cell(
                row=1,
                col=2,
                bbox=(60.0, 20.0, 100.0, 40.0),
                text="C",
                text_lines=["C"],
                images_base64=[],
            ),
        ],
    )


def _matrix(result):
    if isinstance(result, list):
        return result
    if hasattr(result, "matrix"):
        return result.matrix
    if hasattr(result, "rows"):
        return result.rows
    raise AssertionError(f"Unsupported normalize_table result type: {type(result)!r}")


def test_normalize_preserves_spans_multiline_and_empty_cells():
    normalized = normalize_table(_make_table())
    matrix = _matrix(normalized)

    assert len(matrix) == 2
    assert len(matrix[0]) == 3
    assert len(matrix[1]) == 3

    assert matrix[0][0] == "Header"
    assert matrix[0][1] is None
    assert matrix[0][2] == "Line 1\nLine 2"

    assert matrix[1][0] == "A"
    assert matrix[1][1] is None
    assert matrix[1][2] == "C"


