from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tabulex.adapters import table_to_json
from tabulex.models import Cell, NormalizeConfig, Table


def _make_table() -> Table:
    return Table(
        page_number=1,
        bbox=(0.0, 0.0, 100.0, 100.0),
        n_rows=2,
        n_cols=2,
        cells=[
            Cell(
                row=0,
                col=0,
                bbox=(0.0, 0.0, 50.0, 20.0),
                text="Merged",
                text_lines=["Merged"],
                images_base64=[],
                colspan=2,
            ),
            Cell(
                row=1,
                col=0,
                bbox=(0.0, 20.0, 50.0, 40.0),
                text="Receipt",
                text_lines=["Receipt"],
                images_base64=["QUJDRA=="],
            ),
        ],
    )


def test_table_to_json_returns_serializable_records():
    payload = table_to_json(_make_table())

    assert payload["page_number"] == 1
    assert payload["shape"] == {"rows": 2, "cols": 2}
    assert payload["columns"] == ["column_0", "column_1"]
    assert payload["data"][0]["column_0"] == "Merged"
    assert payload["data"][0]["column_1"] is None
    assert payload["data"][1]["column_0"]["text"] == "Receipt"
    assert payload["data"][1]["column_0"]["images_base64"] == ["QUJDRA=="]


def test_table_to_json_can_return_a_string_with_headers():
    table = Table(
        page_number=1,
        n_rows=2,
        n_cols=2,
        header_rows=(0,),
        cells=[
            Cell(row=0, col=0, text="Name", text_lines=["Name"]),
            Cell(row=0, col=1, text="Value", text_lines=["Value"]),
            Cell(row=1, col=0, text="Cash", text_lines=["Cash"]),
            Cell(row=1, col=1, text="100", text_lines=["100"]),
        ],
    )

    content = table_to_json(
        table,
        config=NormalizeConfig(header_rows=(0,)),
        drop_header_rows=True,
        as_string=True,
        indent=2,
    )
    payload = json.loads(content)

    assert payload["columns"] == ["Name", "Value"]
    assert payload["data"] == [{"Name": "Cash", "Value": "100"}]

