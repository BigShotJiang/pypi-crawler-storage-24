from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tabulex.models import Cell, Table
from tabulex.normalize import normalize_table


def test_normalize_merges_duplicate_string_cells_instead_of_failing():
    table = Table(
        page_number=1,
        n_rows=1,
        n_cols=1,
        cells=[
            Cell(row=0, col=0, text="Linea 1", text_lines=["Linea 1"]),
            Cell(row=0, col=0, text="Linea 2", text_lines=["Linea 2"]),
        ],
    )

    normalized = normalize_table(table)
    assert normalized.matrix[0][0] == "Linea 1\nLinea 2"


def test_normalize_merges_text_and_images_for_same_logical_cell():
    table = Table(
        page_number=1,
        n_rows=1,
        n_cols=1,
        cells=[
            Cell(row=0, col=0, text="Producto", text_lines=["Producto"]),
            Cell(row=0, col=0, images_base64=["QUJDRA=="]),
        ],
    )

    normalized = normalize_table(table)
    payload = normalized.matrix[0][0]

    assert isinstance(payload, dict)
    assert payload["text"] == "Producto"
    assert payload["images_base64"] == ["QUJDRA=="]

