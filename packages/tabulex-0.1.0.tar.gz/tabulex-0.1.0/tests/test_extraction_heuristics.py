from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tabulex.extraction import _Segment, _VisualLine, _Word, _covered_columns, _segment_words, _should_merge_lines


def _line(*segments: tuple[float, float, float, float, str]) -> _VisualLine:
    words = tuple(_Word(x0, y0, x1, y1, text) for x0, y0, x1, y1, text in segments)
    built_segments = tuple(_Segment(words=(word,), text=word.text, bbox=word.bbox) for word in words)
    bbox = (
        min(word.x0 for word in words),
        min(word.y0 for word in words),
        max(word.x1 for word in words),
        max(word.y1 for word in words),
    )
    return _VisualLine(words=words, segments=built_segments, bbox=bbox)


def test_segment_words_splits_large_intercolumn_gap():
    words = (
        _Word(0.0, 0.0, 10.0, 10.0, "Non-current"),
        _Word(12.0, 0.0, 22.0, 10.0, "assets"),
        _Word(60.0, 0.0, 70.0, 10.0, "345"),
    )

    segments = _segment_words(words, word_gap_tolerance=10.0)

    assert len(segments) == 2
    assert segments[0].text == "Non-current assets"
    assert segments[1].text == "345"


def test_segment_words_splits_numeric_columns_with_medium_gaps():
    words = (
        _Word(0.0, 0.0, 10.0, 10.0, "100"),
        _Word(20.0, 0.0, 30.0, 10.0, "200"),
        _Word(40.0, 0.0, 50.0, 10.0, "300"),
    )

    segments = _segment_words(words, word_gap_tolerance=10.0)

    assert [segment.text for segment in segments] == ["100", "200", "300"]


def test_should_not_merge_two_full_rows_with_same_columns():
    current = _line(
        (0.0, 0.0, 20.0, 10.0, "Assets"),
        (80.0, 0.0, 95.0, 10.0, "100"),
    )
    next_line = _line(
        (0.0, 12.0, 20.0, 22.0, "Liabilities"),
        (80.0, 12.0, 95.0, 22.0, "200"),
    )

    assert _should_merge_lines(current, next_line, [0.0, 50.0, 100.0], config=type("Cfg", (), {"row_merge_tolerance": 4.0})()) is False


def test_should_not_merge_two_single_column_rows():
    current = _line((0.0, 0.0, 20.0, 10.0, "Property"))
    next_line = _line((0.0, 12.0, 24.0, 22.0, "Investment"))

    assert _should_merge_lines(current, next_line, [0.0, 50.0, 100.0], config=type("Cfg", (), {"row_merge_tolerance": 4.0})()) is False


def test_should_merge_continuation_line_when_only_first_column_continues():
    current = _line(
        (0.0, 0.0, 20.0, 10.0, "Trade and other"),
        (80.0, 0.0, 95.0, 10.0, "100"),
    )
    next_line = _line(
        (0.0, 11.0, 18.0, 21.0, "receivables"),
    )

    assert _should_merge_lines(current, next_line, [0.0, 50.0, 100.0], config=type("Cfg", (), {"row_merge_tolerance": 4.0})()) is True


def test_covered_columns_prefers_real_column_over_spanning_everything():
    covered = _covered_columns((0.0, 0.0, 45.0, 10.0), [0.0, 50.0, 100.0])
    assert covered == [0]

