"""Jupyter / IPython magic commands for ide_model_ext.

Load with:
    %load_ext ide_model_ext

Then use:
    %ai Tell me a joke
    %%ai
    Write a detailed explanation of quantum computing.
    %ai_model gemini-pro
    %ai_config
"""

from __future__ import annotations

from ide_model_ext.client import ModelClient
from ide_model_ext.config import get_config

# Module-level client (shared across magic calls in a notebook session)
_client: ModelClient | None = None


def _get_client() -> ModelClient:
    """Get or create the shared ModelClient."""
    global _client
    if _client is None:
        _client = ModelClient()
    return _client


def load_ipython_extension(ipython) -> None:
    """Called by IPython when ``%load_ext ide_model_ext`` is run.

    Registers the magic commands.
    """
    from IPython.core.magic import register_line_magic, register_cell_magic, register_line_cell_magic

    @register_line_cell_magic
    def ai(line, cell=None):
        """Query an AI model.

        Line magic:   %ai Tell me a joke
        Cell magic:   %%ai
                      Multi-line prompt here.
        """
        prompt = cell if cell else line
        if not prompt.strip():
            print("Usage: %ai <prompt> or %%ai followed by a prompt")
            return

        client = _get_client()
        try:
            response = client.chat(prompt.strip())
            # Display in rich format if possible
            try:
                from IPython.display import display, Markdown

                display(Markdown(response.content))
            except ImportError:
                print(response.content)

            # Show metadata
            print(
                f"\n\033[2m⟡ {response.model} ({response.provider}) "
                f"| {response.usage.total_tokens} tokens\033[0m"
            )
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    @register_line_magic
    def ai_model(line):
        """Switch the active model.

        Usage: %ai_model gpt-4o
               %ai_model gemini-pro
               %ai_model claude-3-5-sonnet-20241022
        """
        global _client
        model = line.strip()
        if not model:
            # Show current model
            client = _get_client()
            print(f"Active model: {client.active_model} ({client.active_provider})")
            return

        try:
            client = _get_client()
            client.set_model(model)
            print(
                f"✓ Switched to: {client.active_model} ({client.active_provider})"
            )
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    @register_line_magic
    def ai_config(line):
        """Show the current ide_model_ext configuration.

        Usage: %ai_config
        """
        cfg = get_config()
        info = cfg.to_dict()
        client = _get_client()

        print("┌─ ide_model_ext Configuration ─────────────────┐")
        print(f"│  Active model:      {client.active_model}")
        print(f"│  Active provider:   {client.active_provider}")
        print(f"│  Temperature:       {info['temperature']}")
        print(f"│  Max tokens:        {info['max_tokens']}")
        print(f"│  Provider priority: {', '.join(info['provider_priority'])}")
        print(f"│  Available:         {', '.join(info['available_providers']) or 'none'}")
        print("│")
        print(f"│  OpenAI key:        {info['openai_api_key']}")
        print(f"│  Google key:        {info['google_api_key']}")
        print(f"│  Anthropic key:     {info['anthropic_api_key']}")
        print("└───────────────────────────────────────────────┘")

    @register_line_magic
    def ai_models(line):
        """List all supported and available models.

        Usage: %ai_models
        """
        from ide_model_ext.router import ModelRouter

        router = ModelRouter()
        all_models = router.list_all_models()
        available = get_config().available_providers

        for provider, models in all_models.items():
            status = "✓" if provider in available else "✗"
            print(f"\n{status} {provider.upper()}")
            for m in models:
                print(f"    • {m}")
        print()

    print(
        f"\033[92m✓ ide_model_ext loaded.\033[0m "
        f"Use \033[1m%ai\033[0m, \033[1m%%ai\033[0m, "
        f"\033[1m%ai_model\033[0m, \033[1m%ai_config\033[0m, "
        f"\033[1m%ai_models\033[0m"
    )


def unload_ipython_extension(ipython) -> None:
    """Called when ``%unload_ext ide_model_ext`` is run."""
    global _client
    _client = None
    print("ide_model_ext unloaded.")
