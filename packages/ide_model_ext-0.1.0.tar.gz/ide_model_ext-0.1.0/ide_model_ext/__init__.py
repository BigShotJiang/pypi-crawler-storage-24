"""
ide_model_ext — A universal multi-model AI extension.

Interact with OpenAI, Google Gemini, and Anthropic Claude
through a single, unified interface.

Copyright (c) 2026 Novatechnolab. MIT License.
"""

__version__ = "0.1.0"
__author__ = "Novatechnolab"

from ide_model_ext.client import ModelClient
from ide_model_ext.config import configure, get_config
from ide_model_ext.base import Response
from ide_model_ext.exceptions import (
    IDEModelExtError,
    ProviderError,
    ConfigurationError,
    ModelNotFoundError,
    APIKeyMissingError,
)


def chat(prompt: str, model: str | None = None, **kwargs) -> Response:
    """Quick one-shot chat — the simplest way to use ide_model_ext.

    Args:
        prompt: The user message.
        model: Optional model name (e.g. 'gpt-4o', 'gemini-pro').
               If omitted, auto-selects the best available model.
        **kwargs: Passed through to the provider (temperature, max_tokens, etc.)

    Returns:
        A Response object with .content, .model, .provider, and .usage.
    """
    client = ModelClient(model=model)
    return client.chat(prompt, **kwargs)


def list_models() -> dict[str, list[str]]:
    """List all supported models grouped by provider.

    Returns:
        Dict mapping provider names to lists of model IDs.
    """
    from ide_model_ext.router import ModelRouter

    router = ModelRouter()
    return router.list_all_models()


# Jupyter magic auto-loading
def load_ipython_extension(ipython):
    """Called by IPython when user runs ``%load_ext ide_model_ext``."""
    from ide_model_ext.magic import load_ipython_extension as _load

    _load(ipython)


def unload_ipython_extension(ipython):
    """Called by IPython when user runs ``%unload_ext ide_model_ext``."""
    from ide_model_ext.magic import unload_ipython_extension as _unload

    _unload(ipython)


__all__ = [
    "ModelClient",
    "Response",
    "configure",
    "get_config",
    "chat",
    "list_models",
    "IDEModelExtError",
    "ProviderError",
    "ConfigurationError",
    "ModelNotFoundError",
    "APIKeyMissingError",
    "load_ipython_extension",
    "unload_ipython_extension",
]
