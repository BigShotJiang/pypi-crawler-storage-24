"""Shared utility functions."""

from __future__ import annotations

import time
import functools
from typing import Callable, TypeVar

T = TypeVar("T")


def retry(
    max_retries: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple = (Exception,),
) -> Callable:
    """Decorator that retries a function on failure with exponential backoff.

    Args:
        max_retries: Maximum number of retry attempts.
        delay: Initial delay in seconds between retries.
        backoff: Multiplier applied to delay after each retry.
        exceptions: Tuple of exception types to catch.
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> T:
            current_delay = delay
            last_exception = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    if attempt < max_retries:
                        time.sleep(current_delay)
                        current_delay *= backoff
            raise last_exception  # type: ignore

        return wrapper

    return decorator


def format_messages(prompt: str, system: str | None = None) -> list[dict[str, str]]:
    """Convert a plain prompt string into the messages list format.

    Args:
        prompt: The user message.
        system: Optional system message.

    Returns:
        List of message dicts.
    """
    messages: list[dict[str, str]] = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    return messages


def estimate_tokens(text: str) -> int:
    """Rough token count estimate (~4 chars per token for English).

    This is a fast approximation; use tiktoken for exact counts.
    """
    return max(1, len(text) // 4)
