"""Google Gemini provider adapter."""

from __future__ import annotations

from typing import Iterator

from ide_model_ext.base import BaseProvider, Response, Usage
from ide_model_ext.exceptions import ProviderError, APIKeyMissingError
from ide_model_ext.config import get_config
from ide_model_ext.utils import retry


GEMINI_MODELS = [
    "gemini-2.0-flash",
    "gemini-1.5-pro",
    "gemini-1.5-flash",
    "gemini-1.0-pro",
]


class GeminiProvider(BaseProvider):
    """Provider adapter for Google Gemini models."""

    provider_name = "gemini"

    def __init__(self, api_key: str | None = None):
        cfg = get_config()
        self._api_key = api_key or cfg.google_api_key
        if not self._api_key:
            raise APIKeyMissingError("Gemini", "GOOGLE_API_KEY")
        self._configured = False

    def _ensure_configured(self):
        """Configure the Gemini SDK (once)."""
        if not self._configured:
            import google.generativeai as genai

            genai.configure(api_key=self._api_key)
            self._configured = True

    def _get_model(self, model: str | None = None):
        """Get a GenerativeModel instance."""
        import google.generativeai as genai

        self._ensure_configured()
        model_name = model or self.default_model()
        return genai.GenerativeModel(model_name)

    @staticmethod
    def _convert_messages(messages: list[dict[str, str]]) -> tuple[str | None, list]:
        """Convert OpenAI-style messages to Gemini format.

        Returns:
            Tuple of (system_instruction, contents) where contents
            is a list of dicts with 'role' and 'parts'.
        """
        system = None
        contents = []
        for msg in messages:
            role = msg["role"]
            content = msg["content"]
            if role == "system":
                system = content
            elif role == "assistant":
                contents.append({"role": "model", "parts": [content]})
            else:
                contents.append({"role": "user", "parts": [content]})
        return system, contents

    @retry(max_retries=2, delay=1.0, exceptions=(Exception,))
    def chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Response:
        """Send a chat completion request to Gemini."""
        import google.generativeai as genai

        model_name = model or self.default_model()
        try:
            self._ensure_configured()
            system, contents = self._convert_messages(messages)

            gen_model = genai.GenerativeModel(
                model_name,
                system_instruction=system,
            )

            generation_config = genai.types.GenerationConfig(
                temperature=temperature,
                max_output_tokens=max_tokens,
            )

            response = gen_model.generate_content(
                contents,
                generation_config=generation_config,
            )

            # Extract usage if available
            usage = Usage()
            if hasattr(response, "usage_metadata") and response.usage_metadata:
                meta = response.usage_metadata
                usage = Usage(
                    prompt_tokens=getattr(meta, "prompt_token_count", 0) or 0,
                    completion_tokens=getattr(meta, "candidates_token_count", 0) or 0,
                    total_tokens=getattr(meta, "total_token_count", 0) or 0,
                )

            return Response(
                content=response.text,
                model=model_name,
                provider=self.provider_name,
                usage=usage,
                raw=response,
            )
        except Exception as e:
            raise ProviderError("Gemini", str(e), original=e) from e

    def stream_chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Iterator[str]:
        """Stream a chat completion response from Gemini."""
        import google.generativeai as genai

        model_name = model or self.default_model()
        try:
            self._ensure_configured()
            system, contents = self._convert_messages(messages)

            gen_model = genai.GenerativeModel(
                model_name,
                system_instruction=system,
            )

            generation_config = genai.types.GenerationConfig(
                temperature=temperature,
                max_output_tokens=max_tokens,
            )

            response = gen_model.generate_content(
                contents,
                generation_config=generation_config,
                stream=True,
            )

            for chunk in response:
                if chunk.text:
                    yield chunk.text
        except Exception as e:
            raise ProviderError("Gemini", str(e), original=e) from e

    def list_models(self) -> list[str]:
        """Return supported Gemini model IDs."""
        return GEMINI_MODELS.copy()

    def default_model(self) -> str:
        """Return the default Gemini model."""
        return "gemini-2.0-flash"
