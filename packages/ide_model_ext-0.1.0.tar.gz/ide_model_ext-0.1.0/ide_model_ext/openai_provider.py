"""OpenAI provider adapter."""

from __future__ import annotations

from typing import Iterator

from ide_model_ext.base import BaseProvider, Response, Usage
from ide_model_ext.exceptions import ProviderError, APIKeyMissingError
from ide_model_ext.config import get_config
from ide_model_ext.utils import retry


# Models sorted by capability (best first)
OPENAI_MODELS = [
    "gpt-4o",
    "gpt-4o-mini",
    "gpt-4-turbo",
    "gpt-4",
    "gpt-3.5-turbo",
    "o1-preview",
    "o1-mini",
]


class OpenAIProvider(BaseProvider):
    """Provider adapter for OpenAI models."""

    provider_name = "openai"

    def __init__(self, api_key: str | None = None):
        cfg = get_config()
        self._api_key = api_key or cfg.openai_api_key
        if not self._api_key:
            raise APIKeyMissingError("OpenAI", "OPENAI_API_KEY")
        self._client = None

    def _get_client(self):
        """Lazy-init the OpenAI client."""
        if self._client is None:
            import openai

            self._client = openai.OpenAI(api_key=self._api_key)
        return self._client

    @retry(max_retries=2, delay=1.0, exceptions=(Exception,))
    def chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Response:
        """Send a chat completion request to OpenAI."""
        model = model or self.default_model()
        try:
            client = self._get_client()
            completion = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                **kwargs,
            )
            choice = completion.choices[0]
            usage_data = completion.usage

            return Response(
                content=choice.message.content or "",
                model=completion.model,
                provider=self.provider_name,
                usage=Usage(
                    prompt_tokens=usage_data.prompt_tokens if usage_data else 0,
                    completion_tokens=usage_data.completion_tokens if usage_data else 0,
                    total_tokens=usage_data.total_tokens if usage_data else 0,
                ),
                raw=completion,
            )
        except Exception as e:
            raise ProviderError("OpenAI", str(e), original=e) from e

    def stream_chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Iterator[str]:
        """Stream a chat completion response from OpenAI."""
        model = model or self.default_model()
        try:
            client = self._get_client()
            stream = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
                **kwargs,
            )
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            raise ProviderError("OpenAI", str(e), original=e) from e

    def list_models(self) -> list[str]:
        """Return supported OpenAI model IDs."""
        return OPENAI_MODELS.copy()

    def default_model(self) -> str:
        """Return the default OpenAI model."""
        return "gpt-4o"
