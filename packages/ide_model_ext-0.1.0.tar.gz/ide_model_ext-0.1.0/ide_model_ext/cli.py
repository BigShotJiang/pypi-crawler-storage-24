"""CLI entry point for ide_model_ext."""

from __future__ import annotations

import argparse
import sys
import os


def _print_colored(text: str, color: str = "green") -> None:
    """Print colored text to the terminal."""
    colors = {
        "green": "\033[92m",
        "blue": "\033[94m",
        "cyan": "\033[96m",
        "yellow": "\033[93m",
        "red": "\033[91m",
        "bold": "\033[1m",
        "dim": "\033[2m",
        "reset": "\033[0m",
    }
    c = colors.get(color, "")
    reset = colors["reset"]
    print(f"{c}{text}{reset}")


def _cmd_chat(args: argparse.Namespace) -> None:
    """Handle the 'chat' subcommand."""
    from ide_model_ext.client import ModelClient

    prompt = " ".join(args.prompt)
    if not prompt:
        print("Error: Please provide a prompt.", file=sys.stderr)
        sys.exit(1)

    try:
        client = ModelClient(model=args.model)
        _print_colored(
            f"⟡ Using: {client.active_model} ({client.active_provider})", "dim"
        )

        if args.stream:
            for chunk in client.stream(prompt):
                print(chunk, end="", flush=True)
            print()
        else:
            response = client.chat(prompt)
            print(response.content)
            _print_colored(
                f"\n⟡ Model: {response.model} | Provider: {response.provider} "
                f"| Tokens: {response.usage.total_tokens}",
                "dim",
            )
    except Exception as e:
        _print_colored(f"Error: {e}", "red")
        sys.exit(1)


def _cmd_interactive(args: argparse.Namespace) -> None:
    """Handle the 'interactive' subcommand — REPL-style chat."""
    from ide_model_ext.client import ModelClient

    try:
        client = ModelClient(model=args.model)
    except Exception as e:
        _print_colored(f"Error: {e}", "red")
        sys.exit(1)

    _print_colored("╔══════════════════════════════════════════╗", "cyan")
    _print_colored("║       ide_model_ext — Interactive        ║", "cyan")
    _print_colored("╚══════════════════════════════════════════╝", "cyan")
    _print_colored(
        f"  Model: {client.active_model} ({client.active_provider})", "dim"
    )
    _print_colored("  Type 'quit' to exit, '/model <name>' to switch models.\n", "dim")

    messages: list[dict[str, str]] = []

    while True:
        try:
            user_input = input("\033[92m❯ \033[0m").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "/quit"):
            print("Goodbye!")
            break
        if user_input.startswith("/model "):
            new_model = user_input.split(" ", 1)[1].strip()
            try:
                client.set_model(new_model)
                _print_colored(
                    f"  Switched to: {client.active_model} ({client.active_provider})",
                    "yellow",
                )
            except Exception as e:
                _print_colored(f"  Error: {e}", "red")
            continue
        if user_input == "/models":
            models = client.list_models()
            for provider, model_list in models.items():
                _print_colored(f"\n  {provider}:", "bold")
                for m in model_list:
                    print(f"    • {m}")
            print()
            continue

        messages.append({"role": "user", "content": user_input})

        try:
            response = client.chat_messages(messages)
            messages.append({"role": "assistant", "content": response.content})
            print(f"\n{response.content}")
            _print_colored(
                f"  [{response.model} | {response.usage.total_tokens} tokens]\n",
                "dim",
            )
        except Exception as e:
            _print_colored(f"  Error: {e}", "red")
            messages.pop()  # remove the failed user message


def _cmd_models(args: argparse.Namespace) -> None:
    """Handle the 'models' subcommand."""
    from ide_model_ext.router import ModelRouter

    router = ModelRouter()
    all_models = router.list_all_models()

    from ide_model_ext.config import get_config

    cfg = get_config()
    available = cfg.available_providers

    _print_colored("\n  Supported Models", "bold")
    _print_colored("  ─────────────────", "dim")

    for provider, models in all_models.items():
        status = "✓ configured" if provider in available else "✗ no API key"
        color = "green" if provider in available else "red"
        _print_colored(f"\n  {provider.upper()} ({status})", color)
        for m in models:
            print(f"    • {m}")
    print()


def _cmd_config(args: argparse.Namespace) -> None:
    """Handle the 'config' subcommand."""
    from ide_model_ext.config import get_config

    cfg = get_config()
    info = cfg.to_dict()

    _print_colored("\n  Current Configuration", "bold")
    _print_colored("  ─────────────────────", "dim")
    for key, value in info.items():
        print(f"    {key}: {value}")
    print()


def main(argv: list[str] | None = None) -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="ide-model-ext",
        description="🚀 ide_model_ext — Universal multi-model AI extension",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # ── chat ──
    chat_parser = subparsers.add_parser("chat", help="Send a one-shot chat message")
    chat_parser.add_argument("prompt", nargs="*", help="The prompt to send")
    chat_parser.add_argument(
        "--model", "-m", default=None, help="Model to use (e.g. gpt-4o, gemini-pro)"
    )
    chat_parser.add_argument(
        "--stream", "-s", action="store_true", help="Stream the response"
    )

    # ── interactive ──
    interactive_parser = subparsers.add_parser(
        "interactive", help="Start an interactive chat session"
    )
    interactive_parser.add_argument(
        "--model", "-m", default=None, help="Initial model to use"
    )

    # ── models ──
    subparsers.add_parser("models", help="List all supported models")

    # ── config ──
    subparsers.add_parser("config", help="Show current configuration")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {
        "chat": _cmd_chat,
        "interactive": _cmd_interactive,
        "models": _cmd_models,
        "config": _cmd_config,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
