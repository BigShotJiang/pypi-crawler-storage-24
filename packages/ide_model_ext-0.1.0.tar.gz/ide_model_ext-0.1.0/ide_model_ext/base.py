"""Base provider interface and shared data types."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Iterator


@dataclass
class Usage:
    """Token usage information from a provider response."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass
class Response:
    """Unified response object returned by all providers.

    Attributes:
        content: The generated text content.
        model: The exact model ID that was used (e.g. 'gpt-4o-2024-08-06').
        provider: The provider name ('openai', 'gemini', 'claude').
        usage: Token usage breakdown.
        raw: The original, unmodified response from the provider SDK.
    """

    content: str
    model: str
    provider: str
    usage: Usage = field(default_factory=Usage)
    raw: Any = None

    def __str__(self) -> str:
        return self.content

    def __repr__(self) -> str:
        return (
            f"Response(model='{self.model}', provider='{self.provider}', "
            f"tokens={self.usage.total_tokens}, "
            f"content='{self.content[:80]}...')"
        )


class BaseProvider(ABC):
    """Abstract base class that all model providers must implement.

    Subclass this to add a new provider to ide_model_ext.
    """

    provider_name: str = "base"

    @abstractmethod
    def chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Response:
        """Send a chat completion request.

        Args:
            messages: List of message dicts, e.g.
                      [{"role": "user", "content": "Hello"}]
            model: Model ID to use. If None, use provider default.
            temperature: Sampling temperature.
            max_tokens: Maximum tokens to generate.

        Returns:
            A unified Response object.
        """
        ...

    @abstractmethod
    def stream_chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Iterator[str]:
        """Stream a chat completion response token-by-token.

        Yields:
            String chunks of the generated text.
        """
        ...

    @abstractmethod
    def list_models(self) -> list[str]:
        """Return a list of supported model IDs for this provider."""
        ...

    @abstractmethod
    def default_model(self) -> str:
        """Return the default model ID for this provider."""
        ...
