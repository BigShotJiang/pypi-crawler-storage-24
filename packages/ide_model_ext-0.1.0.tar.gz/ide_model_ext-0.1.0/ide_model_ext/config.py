"""Configuration manager for ide_model_ext."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class Config:
    """Global configuration for ide_model_ext."""

    # API keys — read from env vars by default, overridable programmatically
    openai_api_key: str | None = None
    google_api_key: str | None = None
    anthropic_api_key: str | None = None

    # Defaults
    default_model: str | None = None
    temperature: float = 0.7
    max_tokens: int = 2048

    # Provider priority for dynamic selection (first available wins)
    provider_priority: list[str] = field(
        default_factory=lambda: ["openai", "gemini", "claude"]
    )

    def __post_init__(self):
        """Load API keys from environment if not set programmatically."""
        if self.openai_api_key is None:
            self.openai_api_key = os.environ.get("OPENAI_API_KEY")
        if self.google_api_key is None:
            self.google_api_key = os.environ.get("GOOGLE_API_KEY")
        if self.anthropic_api_key is None:
            self.anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY")

    @property
    def available_providers(self) -> list[str]:
        """Return list of providers that have API keys configured."""
        available = []
        if self.openai_api_key:
            available.append("openai")
        if self.google_api_key:
            available.append("gemini")
        if self.anthropic_api_key:
            available.append("claude")
        return available

    def to_dict(self) -> dict:
        """Return a safe dict representation (keys masked)."""
        def _mask(key: str | None) -> str:
            if not key:
                return "Not set"
            return key[:8] + "..." + key[-4:]

        return {
            "openai_api_key": _mask(self.openai_api_key),
            "google_api_key": _mask(self.google_api_key),
            "anthropic_api_key": _mask(self.anthropic_api_key),
            "default_model": self.default_model or "auto",
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "provider_priority": self.provider_priority,
            "available_providers": self.available_providers,
        }


# ── Global singleton ─────────────────────────────────────────────

_config: Config | None = None


def get_config() -> Config:
    """Get the current global configuration (creates one if needed)."""
    global _config
    if _config is None:
        _config = Config()
    return _config


def configure(
    openai_api_key: str | None = None,
    google_api_key: str | None = None,
    anthropic_api_key: str | None = None,
    default_model: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    provider_priority: list[str] | None = None,
) -> Config:
    """Configure ide_model_ext programmatically.

    Args:
        openai_api_key: OpenAI API key.
        google_api_key: Google (Gemini) API key.
        anthropic_api_key: Anthropic (Claude) API key.
        default_model: Default model to use (e.g. 'gpt-4o').
        temperature: Default temperature (0.0 – 2.0).
        max_tokens: Default max tokens.
        provider_priority: Provider priority order for dynamic selection.

    Returns:
        The updated Config object.
    """
    global _config
    cfg = get_config()

    if openai_api_key is not None:
        cfg.openai_api_key = openai_api_key
    if google_api_key is not None:
        cfg.google_api_key = google_api_key
    if anthropic_api_key is not None:
        cfg.anthropic_api_key = anthropic_api_key
    if default_model is not None:
        cfg.default_model = default_model
    if temperature is not None:
        cfg.temperature = temperature
    if max_tokens is not None:
        cfg.max_tokens = max_tokens
    if provider_priority is not None:
        cfg.provider_priority = provider_priority

    _config = cfg
    return cfg


def reset_config() -> None:
    """Reset configuration to defaults (mainly for testing)."""
    global _config
    _config = None
