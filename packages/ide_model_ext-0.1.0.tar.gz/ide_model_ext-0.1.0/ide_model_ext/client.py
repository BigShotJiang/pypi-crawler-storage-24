"""ModelClient — the primary user-facing interface."""

from __future__ import annotations

from typing import Iterator

from ide_model_ext.base import Response
from ide_model_ext.config import get_config
from ide_model_ext.router import ModelRouter
from ide_model_ext.utils import format_messages


class ModelClient:
    """Universal AI client that routes to OpenAI, Gemini, or Claude.

    Usage:
        client = ModelClient()                    # auto-select model
        client = ModelClient(model="gpt-4o")      # explicit model
        response = client.chat("Hello!")
        print(response.content)
        print(f"Model: {response.model}, Provider: {response.provider}")

    The client always tells you which model and provider was used,
    even when using dynamic selection.
    """

    def __init__(
        self,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        system: str | None = None,
    ):
        """Initialize the client.

        Args:
            model: Model ID (e.g. 'gpt-4o', 'gemini-pro', 'claude-3-5-sonnet-20241022').
                   If None, auto-selects based on available API keys.
            temperature: Sampling temperature (overrides config default).
            max_tokens: Max tokens to generate (overrides config default).
            system: System prompt to prepend to all messages.
        """
        self._config = get_config()
        self._router = ModelRouter()
        self._model = model or self._config.default_model
        self._temperature = temperature or self._config.temperature
        self._max_tokens = max_tokens or self._config.max_tokens
        self._system = system

        # Resolve immediately to validate
        self._provider, self._resolved_model = self._router.resolve(self._model)

    @property
    def active_model(self) -> str:
        """The currently active model ID."""
        return self._resolved_model

    @property
    def active_provider(self) -> str:
        """The currently active provider name."""
        return self._provider.provider_name

    def set_model(self, model: str) -> None:
        """Switch to a different model.

        Args:
            model: New model ID.
        """
        self._model = model
        self._provider, self._resolved_model = self._router.resolve(model)

    def chat(
        self,
        prompt: str,
        temperature: float | None = None,
        max_tokens: int | None = None,
        system: str | None = None,
        **kwargs,
    ) -> Response:
        """Send a chat message and get a response.

        Args:
            prompt: The user message.
            temperature: Override temperature for this call.
            max_tokens: Override max_tokens for this call.
            system: Override system prompt for this call.
            **kwargs: Additional provider-specific arguments.

        Returns:
            A Response object with .content, .model, .provider, .usage.
        """
        sys_prompt = system or self._system
        messages = format_messages(prompt, system=sys_prompt)
        return self._provider.chat(
            messages=messages,
            model=self._resolved_model,
            temperature=temperature or self._temperature,
            max_tokens=max_tokens or self._max_tokens,
            **kwargs,
        )

    def chat_messages(
        self,
        messages: list[dict[str, str]],
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs,
    ) -> Response:
        """Send a full messages list (for multi-turn conversations).

        Args:
            messages: List of message dicts [{"role": "...", "content": "..."}].
            temperature: Override temperature.
            max_tokens: Override max_tokens.

        Returns:
            A Response object.
        """
        return self._provider.chat(
            messages=messages,
            model=self._resolved_model,
            temperature=temperature or self._temperature,
            max_tokens=max_tokens or self._max_tokens,
            **kwargs,
        )

    def stream(
        self,
        prompt: str,
        temperature: float | None = None,
        max_tokens: int | None = None,
        system: str | None = None,
        **kwargs,
    ) -> Iterator[str]:
        """Stream a response token-by-token.

        Args:
            prompt: The user message.
            temperature: Override temperature.
            max_tokens: Override max_tokens.
            system: Override system prompt.

        Yields:
            String chunks of the response.
        """
        sys_prompt = system or self._system
        messages = format_messages(prompt, system=sys_prompt)
        yield from self._provider.stream_chat(
            messages=messages,
            model=self._resolved_model,
            temperature=temperature or self._temperature,
            max_tokens=max_tokens or self._max_tokens,
            **kwargs,
        )

    def list_models(self) -> dict[str, list[str]]:
        """List all available models grouped by provider."""
        return self._router.available_models()

    def __repr__(self) -> str:
        return (
            f"ModelClient(model='{self._resolved_model}', "
            f"provider='{self._provider.provider_name}')"
        )
