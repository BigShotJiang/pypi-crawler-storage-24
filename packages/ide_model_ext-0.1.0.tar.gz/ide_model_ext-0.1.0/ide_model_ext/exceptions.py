"""Custom exceptions for ide_model_ext."""


class IDEModelExtError(Exception):
    """Base exception for all ide_model_ext errors."""
    pass


class ProviderError(IDEModelExtError):
    """Raised when a provider API call fails."""

    def __init__(self, provider: str, message: str, original: Exception | None = None):
        self.provider = provider
        self.original = original
        super().__init__(f"[{provider}] {message}")


class ConfigurationError(IDEModelExtError):
    """Raised for configuration issues."""
    pass


class ModelNotFoundError(IDEModelExtError):
    """Raised when the requested model is not recognized."""

    def __init__(self, model: str):
        self.model = model
        super().__init__(
            f"Model '{model}' not found. Use list_models() to see available models."
        )


class APIKeyMissingError(ConfigurationError):
    """Raised when a required API key is not set."""

    def __init__(self, provider: str, env_var: str):
        self.provider = provider
        self.env_var = env_var
        super().__init__(
            f"API key for {provider} not found. "
            f"Set the '{env_var}' environment variable or call "
            f"configure({provider.lower()}_api_key='...')."
        )
