"""Model router — resolves model names to providers and handles dynamic selection."""

from __future__ import annotations

from ide_model_ext.base import BaseProvider
from ide_model_ext.config import get_config
from ide_model_ext.exceptions import ModelNotFoundError, APIKeyMissingError


# ── Model → Provider mapping ────────────────────────────────────
# Prefixes / exact names that map to each provider

_OPENAI_PREFIXES = ("gpt-", "o1-", "o3-", "davinci", "babbage")
_GEMINI_PREFIXES = ("gemini-",)
_CLAUDE_PREFIXES = ("claude-",)


def _resolve_provider_name(model: str) -> str:
    """Determine which provider owns a given model ID.

    Args:
        model: A model ID string (e.g. 'gpt-4o', 'gemini-pro').

    Returns:
        Provider name: 'openai', 'gemini', or 'claude'.

    Raises:
        ModelNotFoundError: If the model cannot be mapped.
    """
    model_lower = model.lower()
    if any(model_lower.startswith(p) for p in _OPENAI_PREFIXES):
        return "openai"
    if any(model_lower.startswith(p) for p in _GEMINI_PREFIXES):
        return "gemini"
    if any(model_lower.startswith(p) for p in _CLAUDE_PREFIXES):
        return "claude"
    raise ModelNotFoundError(model)


class ModelRouter:
    """Resolves model names to provider instances and handles dynamic selection.

    The router is the orchestration layer between ModelClient and the
    individual provider adapters.
    """

    def __init__(self):
        self._providers: dict[str, BaseProvider] = {}
        self._config = get_config()

    def _get_or_create_provider(self, provider_name: str) -> BaseProvider:
        """Lazy-init and cache a provider instance."""
        if provider_name not in self._providers:
            if provider_name == "openai":
                from ide_model_ext.openai_provider import OpenAIProvider

                self._providers[provider_name] = OpenAIProvider()
            elif provider_name == "gemini":
                from ide_model_ext.gemini_provider import GeminiProvider

                self._providers[provider_name] = GeminiProvider()
            elif provider_name == "claude":
                from ide_model_ext.claude_provider import ClaudeProvider

                self._providers[provider_name] = ClaudeProvider()
            else:
                raise ModelNotFoundError(provider_name)
        return self._providers[provider_name]

    def resolve(self, model: str | None = None) -> tuple[BaseProvider, str]:
        """Resolve a model name to a (provider, model_id) pair.

        If model is None, dynamically selects the best available provider
        based on configured API keys and provider_priority.

        Args:
            model: Optional model ID (e.g. 'gpt-4o'). None for auto-select.

        Returns:
            Tuple of (provider_instance, model_id).

        Raises:
            ModelNotFoundError: Model string not recognized.
            APIKeyMissingError: Required API key not configured.
        """
        if model:
            # Explicit model requested — find its provider
            provider_name = _resolve_provider_name(model)
            provider = self._get_or_create_provider(provider_name)
            return provider, model

        # Dynamic selection: pick first available provider by priority
        cfg = self._config
        available = cfg.available_providers

        if not available:
            raise APIKeyMissingError(
                "any provider",
                "OPENAI_API_KEY / GOOGLE_API_KEY / ANTHROPIC_API_KEY",
            )

        for name in cfg.provider_priority:
            if name in available:
                provider = self._get_or_create_provider(name)
                return provider, provider.default_model()

        # Fallback to first available
        name = available[0]
        provider = self._get_or_create_provider(name)
        return provider, provider.default_model()

    def list_all_models(self) -> dict[str, list[str]]:
        """List all supported models grouped by provider.

        Returns:
            Dict like {'openai': ['gpt-4o', ...], 'gemini': [...], ...}
        """
        from ide_model_ext.openai_provider import OPENAI_MODELS
        from ide_model_ext.gemini_provider import GEMINI_MODELS
        from ide_model_ext.claude_provider import CLAUDE_MODELS

        return {
            "openai": OPENAI_MODELS.copy(),
            "gemini": GEMINI_MODELS.copy(),
            "claude": CLAUDE_MODELS.copy(),
        }

    def available_models(self) -> dict[str, list[str]]:
        """List models only for providers that have API keys configured.

        Returns:
            Filtered dict of provider → model list.
        """
        all_models = self.list_all_models()
        available = self._config.available_providers
        return {k: v for k, v in all_models.items() if k in available}
