"""Anthropic Claude provider adapter."""

from __future__ import annotations

from typing import Iterator

from ide_model_ext.base import BaseProvider, Response, Usage
from ide_model_ext.exceptions import ProviderError, APIKeyMissingError
from ide_model_ext.config import get_config
from ide_model_ext.utils import retry


CLAUDE_MODELS = [
    "claude-3-5-sonnet-20241022",
    "claude-3-5-haiku-20241022",
    "claude-3-opus-20240229",
    "claude-3-sonnet-20240229",
    "claude-3-haiku-20240307",
]


class ClaudeProvider(BaseProvider):
    """Provider adapter for Anthropic Claude models."""

    provider_name = "claude"

    def __init__(self, api_key: str | None = None):
        cfg = get_config()
        self._api_key = api_key or cfg.anthropic_api_key
        if not self._api_key:
            raise APIKeyMissingError("Claude", "ANTHROPIC_API_KEY")
        self._client = None

    def _get_client(self):
        """Lazy-init the Anthropic client."""
        if self._client is None:
            import anthropic

            self._client = anthropic.Anthropic(api_key=self._api_key)
        return self._client

    @staticmethod
    def _extract_system(
        messages: list[dict[str, str]],
    ) -> tuple[str | None, list[dict[str, str]]]:
        """Separate system message from user/assistant messages.

        Anthropic's API takes system as a top-level parameter, not in messages.
        """
        system = None
        filtered = []
        for msg in messages:
            if msg["role"] == "system":
                system = msg["content"]
            else:
                filtered.append(msg)
        return system, filtered

    @retry(max_retries=2, delay=1.0, exceptions=(Exception,))
    def chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Response:
        """Send a chat completion request to Claude."""
        model = model or self.default_model()
        try:
            client = self._get_client()
            system, filtered_messages = self._extract_system(messages)

            create_kwargs = {
                "model": model,
                "messages": filtered_messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                **kwargs,
            }
            if system:
                create_kwargs["system"] = system

            response = client.messages.create(**create_kwargs)

            # Extract text from content blocks
            content = ""
            for block in response.content:
                if hasattr(block, "text"):
                    content += block.text

            return Response(
                content=content,
                model=response.model,
                provider=self.provider_name,
                usage=Usage(
                    prompt_tokens=response.usage.input_tokens,
                    completion_tokens=response.usage.output_tokens,
                    total_tokens=(
                        response.usage.input_tokens + response.usage.output_tokens
                    ),
                ),
                raw=response,
            )
        except Exception as e:
            raise ProviderError("Claude", str(e), original=e) from e

    def stream_chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Iterator[str]:
        """Stream a chat completion response from Claude."""
        model = model or self.default_model()
        try:
            client = self._get_client()
            system, filtered_messages = self._extract_system(messages)

            create_kwargs = {
                "model": model,
                "messages": filtered_messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                **kwargs,
            }
            if system:
                create_kwargs["system"] = system

            with client.messages.stream(**create_kwargs) as stream:
                for text in stream.text_stream:
                    yield text
        except Exception as e:
            raise ProviderError("Claude", str(e), original=e) from e

    def list_models(self) -> list[str]:
        """Return supported Claude model IDs."""
        return CLAUDE_MODELS.copy()

    def default_model(self) -> str:
        """Return the default Claude model."""
        return "claude-3-5-sonnet-20241022"
