# Publishing Guide — ide_model_ext

Step-by-step instructions to publish **ide_model_ext** on PyPI, GitHub, and Dev.to.

---

## 1. Publish to PyPI

### Prerequisites

```bash
pip install build twine
```

### Create a PyPI Account

1. Go to [https://pypi.org/account/register/](https://pypi.org/account/register/) and create an account.
2. Enable 2FA and create an API token at [https://pypi.org/manage/account/](https://pypi.org/manage/account/).
3. Save the token — you'll need it for uploading.

### Build the Package

```bash
cd /path/to/ide_model_ext
python -m build
```

This creates:
- `dist/ide_model_ext-0.1.0.tar.gz` (source distribution)
- `dist/ide_model_ext-0.1.0-py3-none-any.whl` (wheel)

### Test Upload (TestPyPI — Recommended First)

```bash
twine upload --repository testpypi dist/*
```

Verify at: `https://test.pypi.org/project/ide_model_ext/`

Test install:
```bash
pip install --index-url https://test.pypi.org/simple/ ide_model_ext
```

### Production Upload

```bash
twine upload dist/*
```

When prompted:
- Username: `__token__`
- Password: your PyPI API token

Your package will be live at: `https://pypi.org/project/ide_model_ext/`

---

## 2. Publish to GitHub

### Create the Repository

1. Go to [https://github.com/new](https://github.com/new).
2. Name: `ide_model_ext`
3. Description: *"Universal multi-model AI extension — interact with OpenAI, Gemini, and Claude through a single interface."*
4. Set to Public.
5. Don't initialize with README (we already have one).

### Push the Code

```bash
cd /path/to/ide_model_ext
git init
git add .
git commit -m "Initial release: ide_model_ext v0.1.0"
git branch -M main
git remote add origin https://github.com/novatechnolab/ide_model_ext.git
git push -u origin main
```

### Create a Release

1. Go to your repo → **Releases** → **Create a new release**.
2. Tag: `v0.1.0`
3. Title: `v0.1.0 — Initial Release`
4. Description: paste the CHANGELOG content.
5. Publish.

### Enable GitHub Actions for Auto-Publishing

The `.github/workflows/publish.yml` file is already included. To enable it:

1. Go to repo **Settings → Secrets and variables → Actions**.
2. Add secret: `PYPI_API_TOKEN` = your PyPI API token.
3. Now every time you push a tag (`git tag v0.2.0 && git push --tags`), it will auto-publish to PyPI.

---

## 3. Publish to Dev.to

### Create a Dev.to Account

1. Sign up at [https://dev.to/enter](https://dev.to/enter) (can use GitHub login).

### Write the Article

Create a new post with this template:

---

**Title:** *🚀 ide_model_ext — One Extension to Chat with GPT, Gemini, and Claude*

**Tags:** `python`, `ai`, `openai`, `opensource`

**Body:**

```markdown
## The Problem

Working with multiple AI models means installing multiple SDKs, learning
different APIs, and managing different authentication flows. What if you
could use one library for all of them?

## Introducing ide_model_ext

**ide_model_ext** gives you a single, universal interface to interact with
OpenAI (GPT-4o), Google Gemini, and Anthropic Claude — from Python, CLI,
or Jupyter notebooks.

### Install

​```bash
pip install ide_model_ext
​```

### Use in 3 Lines

​```python
from ide_model_ext import ModelClient

client = ModelClient()  # auto-selects best available model
response = client.chat("Explain quantum computing")
print(f"{response.content}\n— {response.model} ({response.provider})")
​```

### Features
- 🔗 Unified API for 3 providers
- 🔀 Dynamic model selection
- 🔍 Transparent routing (always know which model answered)
- 🌊 Streaming support
- 📓 Jupyter magic commands (`%ai`, `%%ai`)
- 💻 CLI tool with interactive REPL

### Links
- **PyPI**: https://pypi.org/project/ide_model_ext/
- **GitHub**: https://github.com/novatechnolab/ide_model_ext
- **User Guide**: https://github.com/novatechnolab/ide_model_ext/blob/main/docs/user_guide.md

### Built by Novatechnolab
MIT Licensed • Contributions welcome!
```

---

## 4. Version Bumps (Future Releases)

1. Update `version` in `pyproject.toml`.
2. Update `CHANGELOG.md`.
3. Commit: `git commit -am "Release v0.2.0"`
4. Tag: `git tag v0.2.0`
5. Push: `git push && git push --tags`
6. GitHub Actions will auto-publish to PyPI.

---

*© 2026 Novatechnolab. MIT License.*
