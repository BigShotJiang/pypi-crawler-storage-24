# ide_model_ext — User Guide

A complete guide to using **ide_model_ext**, the universal multi-model AI extension for Python.

---

## Table of Contents

1. [Installation](#installation)
2. [Quick Setup](#quick-setup)
3. [Python Usage](#python-usage)
4. [CLI Usage](#cli-usage)
5. [Jupyter Notebook Usage](#jupyter-notebook-usage)
6. [Model Selection](#model-selection)
7. [Streaming](#streaming)
8. [Configuration](#configuration)
9. [Multi-Turn Conversations](#multi-turn-conversations)
10. [Error Handling](#error-handling)
11. [Adding Custom Providers](#adding-custom-providers)

---

## Installation

```bash
# Basic install
pip install ide_model_ext

# With Jupyter support
pip install "ide_model_ext[jupyter]"

# For development
pip install "ide_model_ext[dev]"
```

---

## Quick Setup

Set API keys for the providers you want to use. You only need **one** key to get started:

```bash
# OpenAI
export OPENAI_API_KEY="sk-..."

# Google Gemini
export GOOGLE_API_KEY="AIza..."

# Anthropic Claude
export ANTHROPIC_API_KEY="sk-ant-..."
```

Or set keys programmatically:

```python
from ide_model_ext import configure

configure(
    openai_api_key="sk-...",
    google_api_key="AIza...",
    anthropic_api_key="sk-ant-...",
)
```

---

## Python Usage

### Basic Chat

```python
from ide_model_ext import ModelClient

# Auto-selects best available model
client = ModelClient()
response = client.chat("Explain machine learning in one paragraph.")

print(response.content)
print(f"Model: {response.model}")
print(f"Provider: {response.provider}")
print(f"Tokens used: {response.usage.total_tokens}")
```

### One-Liner

```python
from ide_model_ext import chat

response = chat("What is Python?")
print(response)  # prints just the content
```

### Specific Model

```python
client = ModelClient(model="claude-3-5-sonnet-20241022")
response = client.chat("Write a haiku about coding.")
```

### System Prompt

```python
client = ModelClient(system="You are a pirate. Speak like one.")
response = client.chat("Tell me about the weather.")
# → "Arrr, the skies be clear today, matey!"
```

### Switch Models On-the-Fly

```python
client = ModelClient(model="gpt-4o")
response1 = client.chat("Hello from GPT-4o!")

client.set_model("gemini-2.0-flash")
response2 = client.chat("Hello from Gemini!")

print(response1.provider)  # "openai"
print(response2.provider)  # "gemini"
```

---

## CLI Usage

The `ide-model-ext` command-line tool is installed automatically.

### One-Shot Chat

```bash
ide-model-ext chat "What is quantum computing?"
ide-model-ext chat --model gemini-pro "Summarize this concept"
ide-model-ext chat --stream "Tell me a story"
```

### Interactive Mode

```bash
ide-model-ext interactive
ide-model-ext interactive --model claude-3-5-sonnet-20241022
```

In interactive mode:
- Type your messages and press Enter.
- `/model gpt-4o` — switch models.
- `/models` — list available models.
- `quit` or Ctrl+C — exit.

### List Models

```bash
ide-model-ext models
```

### Show Config

```bash
ide-model-ext config
```

---

## Jupyter Notebook Usage

### Load the Extension

```python
%load_ext ide_model_ext
```

### Quick Query (Line Magic)

```python
%ai What is the capital of France?
```

### Multi-Line Query (Cell Magic)

```python
%%ai
Write a Python function that:
1. Takes a list of numbers
2. Returns the median
3. Handles edge cases
```

### Switch Model

```python
%ai_model gemini-2.0-flash
```

### Show Config

```python
%ai_config
```

### List Models

```python
%ai_models
```

---

## Model Selection

### Explicit Selection

Specify the exact model ID:

```python
client = ModelClient(model="gpt-4o")        # OpenAI
client = ModelClient(model="gemini-2.0-flash")  # Gemini
client = ModelClient(model="claude-3-5-sonnet-20241022")  # Claude
```

### Dynamic / Auto Selection

When no model is specified, the router picks the first available provider based on priority:

```python
client = ModelClient()  # auto-selects
print(client.active_model)    # e.g., "gpt-4o"
print(client.active_provider) # e.g., "openai"
```

Default priority: **OpenAI → Gemini → Claude**. Customize with:

```python
from ide_model_ext import configure
configure(provider_priority=["claude", "gemini", "openai"])
```

### Supported Models

| Provider | Models |
|----------|--------|
| OpenAI   | `gpt-4o`, `gpt-4o-mini`, `gpt-4-turbo`, `gpt-4`, `gpt-3.5-turbo`, `o1-preview`, `o1-mini` |
| Gemini   | `gemini-2.0-flash`, `gemini-1.5-pro`, `gemini-1.5-flash`, `gemini-1.0-pro` |
| Claude   | `claude-3-5-sonnet-20241022`, `claude-3-5-haiku-20241022`, `claude-3-opus-20240229`, `claude-3-sonnet-20240229`, `claude-3-haiku-20240307` |

---

## Streaming

All providers support streaming:

### Python

```python
client = ModelClient(model="gpt-4o")
for chunk in client.stream("Tell me a story"):
    print(chunk, end="", flush=True)
```

### CLI

```bash
ide-model-ext chat --stream "Tell me a story"
```

---

## Configuration

### Programmatic

```python
from ide_model_ext import configure

configure(
    default_model="gpt-4o",
    temperature=0.5,
    max_tokens=4096,
    provider_priority=["gemini", "openai", "claude"],
)
```

### Per-Request Override

```python
response = client.chat(
    "Be creative!",
    temperature=1.5,
    max_tokens=500,
)
```

---

## Multi-Turn Conversations

For multi-turn chat, use `chat_messages()`:

```python
client = ModelClient(model="gpt-4o")

messages = [
    {"role": "system", "content": "You are a helpful math tutor."},
    {"role": "user", "content": "What is calculus?"},
]
response1 = client.chat_messages(messages)

messages.append({"role": "assistant", "content": response1.content})
messages.append({"role": "user", "content": "Can you give an example?"})
response2 = client.chat_messages(messages)
```

---

## Error Handling

```python
from ide_model_ext import ModelClient
from ide_model_ext.exceptions import (
    APIKeyMissingError,
    ModelNotFoundError,
    ProviderError,
)

try:
    client = ModelClient(model="gpt-4o")
    response = client.chat("Hello")
except APIKeyMissingError as e:
    print(f"Missing key: {e}")
except ModelNotFoundError as e:
    print(f"Unknown model: {e}")
except ProviderError as e:
    print(f"API error from {e.provider}: {e}")
```

---

## Adding Custom Providers

1. Create a new file `ide_model_ext/my_provider.py`.
2. Subclass `BaseProvider`:

```python
from ide_model_ext.base import BaseProvider, Response

class MyProvider(BaseProvider):
    provider_name = "my_provider"

    def chat(self, messages, model=None, temperature=0.7, max_tokens=2048, **kwargs):
        # Your implementation
        return Response(content="...", model="...", provider=self.provider_name)

    def stream_chat(self, messages, model=None, **kwargs):
        yield "streamed chunk"

    def list_models(self):
        return ["my-model-v1"]

    def default_model(self):
        return "my-model-v1"
```

3. Register in `router.py`'s `_get_or_create_provider()`.

---

## IDE Compatibility

`ide_model_ext` works in:

| IDE / Environment | How |
|---|---|
| **Jupyter Notebook** | `%load_ext ide_model_ext` + magic commands |
| **JupyterLab** | Same as Jupyter Notebook |
| **VS Code** | Python scripts or integrated terminal |
| **PyCharm** | Python scripts or terminal |
| **Google Colab** | `!pip install ide_model_ext` + magic commands |
| **Terminal / Shell** | `ide-model-ext` CLI |
| **Any Python script** | `from ide_model_ext import ModelClient` |

---

*© 2026 Novatechnolab. MIT License.*
