# 🚀 ide_model_ext

[![PyPI version](https://img.shields.io/pypi/v/ide_model_ext.svg)](https://pypi.org/project/ide_model_ext/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)

**One extension. Three AI providers. Zero hassle.**

`ide_model_ext` gives you a **single, universal interface** to interact with **OpenAI**, **Google Gemini**, and **Anthropic Claude** — from Python scripts, the terminal CLI, or Jupyter notebooks. Stop juggling three SDKs and three different APIs.

---

## ✨ Features

- 🔗 **Unified API** — One `ModelClient` for GPT-4o, Gemini Pro, Claude Sonnet, and more.
- 🔀 **Dynamic Model Selection** — Automatically picks the best available model based on your API keys.
- 🔍 **Transparent Routing** — Every response tells you which model and provider was used.
- 🌊 **Streaming Support** — Real-time streamed responses from all providers.
- 📓 **Jupyter Magics** — `%ai` and `%%ai` magic commands for in-notebook AI.
- 💻 **CLI Tool** — Quick chat, interactive REPL, and model listing from your terminal.
- 🔌 **Extensible** — Add new providers by subclassing `BaseProvider`.

---

## 📦 Installation

```bash
pip install ide_model_ext
```

With Jupyter support:
```bash
pip install "ide_model_ext[jupyter]"
```

---

## 🔑 Setup

Set your API keys as environment variables (only for the providers you want to use):

```bash
export OPENAI_API_KEY="sk-..."
export GOOGLE_API_KEY="AIza..."
export ANTHROPIC_API_KEY="sk-ant-..."
```

---

## ⚡ Quick Start

### Python

```python
from ide_model_ext import ModelClient

# Auto-selects the best available model
client = ModelClient()
response = client.chat("Explain quantum computing in simple terms.")
print(response.content)
print(f"Answered by: {response.model} ({response.provider})")

# Or pick a specific model
client = ModelClient(model="gpt-4o")
response = client.chat("Write a haiku about Python.")
```

### CLI

```bash
# One-shot query
ide-model-ext chat "What is machine learning?"

# Pick a model
ide-model-ext chat --model gemini-pro "Summarize this concept"

# Interactive REPL
ide-model-ext interactive

# List available models
ide-model-ext models
```

### Jupyter Notebook

```python
%load_ext ide_model_ext

%ai Tell me a joke about programming

%ai_model claude-3-5-sonnet-20241022

%%ai
Write a Python function that calculates
the Fibonacci sequence recursively.
```

---

## 📖 Documentation

- [User Guide](docs/user_guide.md) — Full usage documentation.
- [Publishing Guide](docs/publishing_guide.md) — How to publish on PyPI, GitHub, Dev.to.
- [Contributing](CONTRIBUTING.md) — How to contribute or add new providers.
- [Changelog](CHANGELOG.md)

---

## 🏗️ Architecture

```
Your Code / CLI / Jupyter
        │
   ModelClient          ← simple user-facing API
        │
   ModelRouter          ← resolves model → provider
      ┌──┼──┐
  OpenAI Gemini Claude  ← provider adapters
      └──┼──┘
   BaseProvider         ← abstract interface
```

---

## 📄 License

MIT License © 2026 [Novatechnolab](https://github.com/novatechnolab)
