# Changelog

All notable changes to **ide_model_ext** will be documented in this file.

## [0.1.0] — 2026-03-21

### Added
- Universal `ModelClient` for OpenAI, Gemini, and Claude.
- Dynamic model selection based on available API keys.
- CLI tool (`ide-model-ext`) with chat, interactive, and models commands.
- Jupyter/IPython magic commands (`%ai`, `%%ai`, `%ai_model`, `%ai_config`).
- Streaming support for all providers.
- Comprehensive user guide and publishing guide.
