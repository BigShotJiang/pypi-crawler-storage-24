"""Tests for the model router."""

import pytest
from unittest.mock import patch, MagicMock
from ide_model_ext.router import ModelRouter, _resolve_provider_name
from ide_model_ext.exceptions import ModelNotFoundError, APIKeyMissingError
from ide_model_ext.config import reset_config, configure


@pytest.fixture(autouse=True)
def clean_config():
    reset_config()
    yield
    reset_config()


class TestResolveProviderName:
    def test_openai_models(self):
        assert _resolve_provider_name("gpt-4o") == "openai"
        assert _resolve_provider_name("gpt-3.5-turbo") == "openai"
        assert _resolve_provider_name("o1-preview") == "openai"

    def test_gemini_models(self):
        assert _resolve_provider_name("gemini-pro") == "gemini"
        assert _resolve_provider_name("gemini-1.5-flash") == "gemini"

    def test_claude_models(self):
        assert _resolve_provider_name("claude-3-5-sonnet-20241022") == "claude"
        assert _resolve_provider_name("claude-3-haiku-20240307") == "claude"

    def test_unknown_model(self):
        with pytest.raises(ModelNotFoundError):
            _resolve_provider_name("unknown-model-xyz")

    def test_case_insensitive(self):
        assert _resolve_provider_name("GPT-4o") == "openai"
        assert _resolve_provider_name("Gemini-Pro") == "gemini"


class TestModelRouter:
    def test_resolve_explicit_model(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        configure(openai_api_key="test-key")
        router = ModelRouter()

        with patch(
            "ide_model_ext.openai_provider.OpenAIProvider.__init__",
            return_value=None,
        ):
            with patch.object(
                router, "_get_or_create_provider"
            ) as mock_get:
                mock_provider = MagicMock()
                mock_provider.provider_name = "openai"
                mock_get.return_value = mock_provider

                provider, model = router.resolve("gpt-4o")
                assert model == "gpt-4o"
                mock_get.assert_called_with("openai")

    def test_resolve_dynamic_selection(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        configure(google_api_key="test-key")
        router = ModelRouter()

        with patch(
            "ide_model_ext.gemini_provider.GeminiProvider.__init__",
            return_value=None,
        ):
            with patch.object(router, "_get_or_create_provider") as mock_get:
                mock_provider = MagicMock()
                mock_provider.provider_name = "gemini"
                mock_provider.default_model.return_value = "gemini-2.0-flash"
                mock_get.return_value = mock_provider

                provider, model = router.resolve(None)
                assert model == "gemini-2.0-flash"

    def test_resolve_no_keys_raises(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        router = ModelRouter()
        with pytest.raises(APIKeyMissingError):
            router.resolve(None)

    def test_list_all_models(self):
        router = ModelRouter()
        models = router.list_all_models()
        assert "openai" in models
        assert "gemini" in models
        assert "claude" in models
        assert "gpt-4o" in models["openai"]
        assert "gemini-2.0-flash" in models["gemini"]
        assert "claude-3-5-sonnet-20241022" in models["claude"]
