"""Tests for ModelClient."""

import pytest
from unittest.mock import patch, MagicMock
from ide_model_ext.client import ModelClient
from ide_model_ext.base import Response, Usage
from ide_model_ext.config import reset_config, configure


@pytest.fixture(autouse=True)
def clean_config():
    reset_config()
    yield
    reset_config()


@pytest.fixture
def mock_response():
    return Response(
        content="Hello from the test!",
        model="gpt-4o",
        provider="openai",
        usage=Usage(prompt_tokens=10, completion_tokens=5, total_tokens=15),
    )


class TestModelClient:
    @patch("ide_model_ext.router.ModelRouter.resolve")
    def test_chat(self, mock_resolve, mock_response, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(openai_api_key="test-key")

        mock_provider = MagicMock()
        mock_provider.provider_name = "openai"
        mock_provider.chat.return_value = mock_response
        mock_resolve.return_value = (mock_provider, "gpt-4o")

        client = ModelClient(model="gpt-4o")
        response = client.chat("Hello!")

        assert response.content == "Hello from the test!"
        assert response.model == "gpt-4o"
        assert response.provider == "openai"
        assert response.usage.total_tokens == 15

    @patch("ide_model_ext.router.ModelRouter.resolve")
    def test_active_model_and_provider(self, mock_resolve, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(openai_api_key="test-key")

        mock_provider = MagicMock()
        mock_provider.provider_name = "openai"
        mock_resolve.return_value = (mock_provider, "gpt-4o")

        client = ModelClient(model="gpt-4o")
        assert client.active_model == "gpt-4o"
        assert client.active_provider == "openai"

    @patch("ide_model_ext.router.ModelRouter.resolve")
    def test_set_model(self, mock_resolve, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(openai_api_key="k1", google_api_key="k2")

        mock_openai = MagicMock()
        mock_openai.provider_name = "openai"
        mock_gemini = MagicMock()
        mock_gemini.provider_name = "gemini"

        mock_resolve.side_effect = [
            (mock_openai, "gpt-4o"),
            (mock_gemini, "gemini-pro"),
        ]

        client = ModelClient(model="gpt-4o")
        assert client.active_provider == "openai"

        client.set_model("gemini-pro")
        assert client.active_model == "gemini-pro"
        assert client.active_provider == "gemini"

    @patch("ide_model_ext.router.ModelRouter.resolve")
    def test_stream(self, mock_resolve, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(openai_api_key="test-key")

        mock_provider = MagicMock()
        mock_provider.provider_name = "openai"
        mock_provider.stream_chat.return_value = iter(["Hello", " ", "World"])
        mock_resolve.return_value = (mock_provider, "gpt-4o")

        client = ModelClient(model="gpt-4o")
        tokens = list(client.stream("Hi"))
        assert tokens == ["Hello", " ", "World"]

    @patch("ide_model_ext.router.ModelRouter.resolve")
    def test_repr(self, mock_resolve, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(openai_api_key="test-key")

        mock_provider = MagicMock()
        mock_provider.provider_name = "openai"
        mock_resolve.return_value = (mock_provider, "gpt-4o")

        client = ModelClient(model="gpt-4o")
        r = repr(client)
        assert "gpt-4o" in r
        assert "openai" in r
