"""Tests for the configuration manager."""

import os
import pytest
from ide_model_ext.config import Config, configure, get_config, reset_config


@pytest.fixture(autouse=True)
def clean_config():
    """Reset config before each test."""
    reset_config()
    yield
    reset_config()


class TestConfig:
    def test_default_values(self):
        cfg = Config(
            openai_api_key="test",
            google_api_key=None,
            anthropic_api_key=None,
        )
        assert cfg.temperature == 0.7
        assert cfg.max_tokens == 2048
        assert cfg.default_model is None

    def test_reads_env_vars(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test-openai")
        monkeypatch.setenv("GOOGLE_API_KEY", "test-google")
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")

        cfg = Config()
        assert cfg.openai_api_key == "sk-test-openai"
        assert cfg.google_api_key == "test-google"
        assert cfg.anthropic_api_key == "sk-ant-test"

    def test_available_providers(self):
        cfg = Config(
            openai_api_key="key1",
            google_api_key=None,
            anthropic_api_key="key3",
        )
        assert cfg.available_providers == ["openai", "claude"]

    def test_available_providers_empty(self):
        cfg = Config(
            openai_api_key=None,
            google_api_key=None,
            anthropic_api_key=None,
        )
        assert cfg.available_providers == []

    def test_to_dict_masks_keys(self):
        cfg = Config(
            openai_api_key="sk-proj-1234567890abcdef",
            google_api_key=None,
            anthropic_api_key=None,
        )
        d = cfg.to_dict()
        assert d["openai_api_key"].startswith("sk-proj-")
        assert d["openai_api_key"].endswith("cdef")
        assert "..." in d["openai_api_key"]
        assert d["google_api_key"] == "Not set"


class TestConfigure:
    def test_configure_sets_values(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        cfg = configure(
            openai_api_key="my-key",
            temperature=0.5,
            default_model="gpt-4o",
        )
        assert cfg.openai_api_key == "my-key"
        assert cfg.temperature == 0.5
        assert cfg.default_model == "gpt-4o"

    def test_configure_partial_update(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        configure(openai_api_key="key1")
        cfg = configure(temperature=0.9)
        assert cfg.openai_api_key == "key1"
        assert cfg.temperature == 0.9

    def test_get_config_returns_same_instance(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        cfg1 = get_config()
        cfg2 = get_config()
        assert cfg1 is cfg2
