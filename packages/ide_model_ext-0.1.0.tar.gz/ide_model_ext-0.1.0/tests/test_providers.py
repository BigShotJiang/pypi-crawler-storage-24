"""Tests for individual provider adapters (with mocked SDKs)."""

import pytest
from unittest.mock import patch, MagicMock
from ide_model_ext.config import reset_config, configure
from ide_model_ext.exceptions import APIKeyMissingError


@pytest.fixture(autouse=True)
def clean_config():
    reset_config()
    yield
    reset_config()


class TestOpenAIProvider:
    def test_missing_api_key_raises(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        from ide_model_ext.openai_provider import OpenAIProvider

        with pytest.raises(APIKeyMissingError):
            OpenAIProvider()

    def test_list_models(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(openai_api_key="test")

        from ide_model_ext.openai_provider import OpenAIProvider

        provider = OpenAIProvider()
        models = provider.list_models()
        assert "gpt-4o" in models

    def test_default_model(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(openai_api_key="test")

        from ide_model_ext.openai_provider import OpenAIProvider

        provider = OpenAIProvider()
        assert provider.default_model() == "gpt-4o"

    @patch("ide_model_ext.openai_provider.OpenAIProvider._get_client")
    def test_chat_response_format(self, mock_get_client, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(openai_api_key="test")

        # Mock the OpenAI SDK response
        mock_choice = MagicMock()
        mock_choice.message.content = "Test response"
        mock_usage = MagicMock()
        mock_usage.prompt_tokens = 10
        mock_usage.completion_tokens = 5
        mock_usage.total_tokens = 15
        mock_completion = MagicMock()
        mock_completion.choices = [mock_choice]
        mock_completion.usage = mock_usage
        mock_completion.model = "gpt-4o-2024-08-06"

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_completion
        mock_get_client.return_value = mock_client

        from ide_model_ext.openai_provider import OpenAIProvider

        provider = OpenAIProvider()
        response = provider.chat([{"role": "user", "content": "Hello"}])

        assert response.content == "Test response"
        assert response.provider == "openai"
        assert response.usage.total_tokens == 15


class TestGeminiProvider:
    def test_missing_api_key_raises(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        from ide_model_ext.gemini_provider import GeminiProvider

        with pytest.raises(APIKeyMissingError):
            GeminiProvider()

    def test_list_models(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(google_api_key="test")

        from ide_model_ext.gemini_provider import GeminiProvider

        provider = GeminiProvider()
        models = provider.list_models()
        assert "gemini-2.0-flash" in models

    def test_convert_messages(self):
        from ide_model_ext.gemini_provider import GeminiProvider

        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
            {"role": "user", "content": "How are you?"},
        ]
        system, contents = GeminiProvider._convert_messages(messages)
        assert system == "You are helpful."
        assert len(contents) == 3
        assert contents[0]["role"] == "user"
        assert contents[1]["role"] == "model"  # assistant → model


class TestClaudeProvider:
    def test_missing_api_key_raises(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        from ide_model_ext.claude_provider import ClaudeProvider

        with pytest.raises(APIKeyMissingError):
            ClaudeProvider()

    def test_list_models(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        configure(anthropic_api_key="test")

        from ide_model_ext.claude_provider import ClaudeProvider

        provider = ClaudeProvider()
        models = provider.list_models()
        assert "claude-3-5-sonnet-20241022" in models

    def test_extract_system_message(self):
        from ide_model_ext.claude_provider import ClaudeProvider

        messages = [
            {"role": "system", "content": "Be concise."},
            {"role": "user", "content": "Hello"},
        ]
        system, filtered = ClaudeProvider._extract_system(messages)
        assert system == "Be concise."
        assert len(filtered) == 1
        assert filtered[0]["role"] == "user"
