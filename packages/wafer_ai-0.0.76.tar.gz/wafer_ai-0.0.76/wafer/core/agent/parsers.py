"""Shared parsers for CLI agent output (wafer, Claude Code, Codex).

Used by cli_agents for trajectory building and text extraction.
"""
from __future__ import annotations

import json
from typing import Any

from wafer.core.dtypes import Message, TextContent, ToolCallContent

from .wire_events import normalize_wire_event


def parse_claude_code_stream_json(output: str) -> list[Message]:
    """Parse Claude Code / JsonFrontend --output-format stream-json into list[Message].
    Claude Code emits NDJSON with event types:
    - {"type": "system", "subtype": "init", ...}
    - {"type": "assistant", "message": {"content": [...]}}
    - {"type": "user", "message": {"content": [{"type": "tool_result", ...}]}}
    - {"type": "result", "subtype": "success", ...}
    JsonFrontend also emits granular tool_result events:
    - {"type": "tool_result", "tool_call_id": ..., "content": ..., "is_error": ...}
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_type = event.get("type")
        if event_type == "assistant":
            content_blocks = _parse_claude_content_blocks(event)
            if content_blocks:
                messages.append(Message(role="assistant", content=content_blocks))
        elif event_type == "user":
            tool_messages = _parse_claude_tool_results(event)
            messages.extend(tool_messages)
        elif event_type == "tool_result":
            content = event.get("content", "")
            if isinstance(content, list):
                content = json.dumps(content)
            messages.append(
                Message(
                    role="tool",
                    content=str(content),
                    tool_call_id=event.get("tool_call_id", ""),
                )
            )
    return messages


def _parse_claude_content_blocks(event: dict[str, Any]) -> list[TextContent | ToolCallContent]:
    """Parse content blocks from Claude Code assistant message."""
    assert "message" in event
    assert "content" in event["message"]
    content_blocks: list[TextContent | ToolCallContent] = []
    raw_content = event["message"]["content"]
    for block in raw_content:
        block_type = block.get("type")
        if block_type == "text":
            content_blocks.append(TextContent(text=block.get("text", "")))
        elif block_type == "tool_use":
            content_blocks.append(
                ToolCallContent(
                    id=block.get("id", ""),
                    name=block.get("name", ""),
                    arguments=block.get("input", {}),
                )
            )
    return content_blocks


def _parse_claude_tool_results(event: dict[str, Any]) -> list[Message]:
    """Parse tool results from Claude Code user message."""
    assert "message" in event
    assert "content" in event["message"]
    messages: list[Message] = []
    raw_content = event["message"]["content"]
    for block in raw_content:
        if block.get("type") == "tool_result":
            messages.append(
                Message(
                    role="tool",
                    content=block.get("content", ""),
                    tool_call_id=block.get("tool_use_id", ""),
                )
            )
    return messages


def parse_wafer_stream_json(output: str) -> list[Message]:
    """Parse wafer agent --output-format stream-json into list[Message].

    Wafer's StreamingChunkFrontend emits NDJSON:
    - {"type": "text_delta", "delta": "..."}
    - {"type": "tool_call_start", "id": "...", "name": "..."}
    - {"type": "tool_call_end", "id": "...", "name": "...", "args": {...}}
    - {"type": "tool_result", "is_error": bool}
    - {"type": "session_complete"}
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    text_parts: list[str] = []
    tool_counter = 0

    def _flush_text() -> None:
        if text_parts:
            messages.append(Message(role="assistant", content="".join(text_parts)))
            text_parts.clear()

    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event = normalize_wire_event(event)
        event_type = event.get("type", "")

        if event_type == "text_delta":
            text_parts.append(event.get("delta", ""))
        elif event_type == "tool_call_end":
            _flush_text()
            tool_id = f"wafer_tool_{tool_counter}"
            tool_counter += 1
            messages.append(Message(
                role="assistant",
                content=[ToolCallContent(
                    id=tool_id,
                    name=event.get("name", ""),
                    arguments=event.get("args", {}),
                )],
            ))
        elif event_type == "tool_result":
            tool_content = event.get("content", "(tool result)")
            messages.append(Message(
                role="tool",
                content=tool_content if tool_content else "(tool result)",
                tool_call_id=f"wafer_tool_{tool_counter - 1}" if tool_counter > 0 else "",
            ))
        elif event_type == "session_complete":
            break

    _flush_text()
    return messages


def parse_cursor_wire_events(output: str) -> list[Message]:
    """Parse translated cursor wire events into list[Message].

    The cloud API translates cursor stream-json events into canonical wire events:
    - {"type": "text_delta", "delta": "..."} — assistant text
    - {"type": "thinking_delta", "delta": "..."} — thinking text
    - {"type": "tool_call_start", "name": "...", "id": "...", "input": {...}}
    - {"type": "tool_call_end", "id": "...", "name": "...", "args": {...}}
    - {"type": "tool_result", "id": "...", "content": "..."}
    - {"type": "turn_end"} — end of one turn (does NOT end parsing)
    - {"type": "session_complete"} — end of session (terminates parsing)
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    text_parts: list[str] = []
    tool_calls_seen: dict[str, ToolCallContent] = {}

    def _flush_text() -> None:
        if text_parts:
            messages.append(Message(role="assistant", content="".join(text_parts)))
            text_parts.clear()

    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event = normalize_wire_event(event)
        etype = event.get("type", "")

        if etype == "text_delta":
            text_parts.append(event.get("delta", ""))
        elif etype == "thinking_delta":
            text_parts.append(event.get("delta", ""))
        elif etype == "tool_call_start":
            _flush_text()
            call_id = event.get("id", "")
            tc = ToolCallContent(
                id=call_id,
                name=event.get("name", ""),
                arguments=event.get("input", {}),
            )
            tool_calls_seen[call_id] = tc
            messages.append(Message(role="assistant", content=[tc]))
        elif etype == "tool_call_end":
            call_id = event.get("id", "")
            if call_id in tool_calls_seen:
                tool_calls_seen[call_id] = ToolCallContent(
                    id=call_id,
                    name=event.get("name", tool_calls_seen[call_id].name),
                    arguments=event.get("args", tool_calls_seen[call_id].arguments),
                )
        elif etype == "tool_result":
            content = event.get("content", "(tool result)")
            messages.append(Message(
                role="tool",
                content=content if content else "(tool result)",
                tool_call_id=event.get("id", ""),
            ))
        elif etype == "session_complete":
            break

    _flush_text()
    return messages


def parse_raw_text_fallback(output: str) -> list[Message]:
    """Fallback parser: treat entire output as single assistant message."""
    assert isinstance(output, str)
    if not output.strip():
        return []
    return [Message(role="assistant", content=output.strip())]
