"""Unified terminal renderer for wire events.

Single rendering implementation for both eval mode (cli_agents.py) and
cloud CLI mode (cmd_agent.py). Consumes normalized wire event dicts
and writes formatted output to stdout/stderr.

Usage:
    from wafer.core.agent.wire_events import normalize_wire_event
    from wafer.core.agent.frontends.terminal_renderer import TerminalRenderer

    renderer = TerminalRenderer(prefix="wafer_0000")
    for line in ndjson_lines:
        event = normalize_wire_event(json.loads(line))
        renderer.render(event)
    renderer.flush()
"""
from __future__ import annotations

import re
import sys
import threading
from typing import Any, Literal

_USE_COLOR = sys.stdout.isatty()
_RESET = "\033[0m"
_DIM = "\033[2m"
_RED = "\033[31m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_BLUE = "\033[34m"
_MAGENTA = "\033[35m"
_CYAN = "\033[36m"

_SUBAGENT_COLORS = [
    "\x1b[33m",  # yellow
    "\x1b[35m",  # magenta
    "\x1b[32m",  # green
    "\x1b[34m",  # blue
    "\x1b[96m",  # bright cyan
    "\x1b[91m",  # bright red
]
_SUBAGENT_SESSION_RE = re.compile(r"\[subagent_session:([0-9a-f-]{36})\]")
_MAX_TEXT_BUFFER = 500
_MAX_CONTENT_PREVIEW = 500
_MAX_ARG_PREVIEW = 200


def _color(code: str, text: str) -> str:
    return f"{code}{text}{_RESET}" if _USE_COLOR and code else text


def _truncate_content(content: str, max_lines: int = 3, max_chars: int = 200) -> str:
    if not content:
        return ""
    lines = content.splitlines()
    if len(lines) <= max_lines and len(content) <= max_chars:
        return content.rstrip() + ("\n" if not content.endswith("\n") else "")
    preview = "\n".join(lines[:max_lines])
    if len(preview) > max_chars:
        preview = preview[:max_chars] + "..."
    suffix = f" ({len(lines)} lines)" if len(lines) > max_lines else ""
    return preview + suffix + "\n"


def _format_tool_args(tool_name: str, args: dict[str, Any]) -> str:
    if not isinstance(args, dict):
        return str(args)[:_MAX_ARG_PREVIEW]
    if tool_name in ("write", "edit"):
        path = args.get("path", "")
        content = args.get("content", "")
        size = len(content) if isinstance(content, str) else 0
        return f"path={path!r}, {size} bytes"
    if tool_name == "bash":
        cmd = str(args.get("command", ""))
        return cmd[:80] + ("..." if len(cmd) > 80 else "")
    if tool_name == "read":
        return f"path={args.get('path', '')!r}"
    if tool_name == "grep":
        parts = []
        if p := args.get("pattern"):
            parts.append(f"pattern={p!r}")
        if path := args.get("path"):
            parts.append(f"path={path!r}")
        return ", ".join(parts) if parts else str(args)[:_MAX_ARG_PREVIEW]
    if tool_name == "glob":
        return f"pattern={args.get('pattern', '')!r}" if args.get("pattern") else str(args)[:_MAX_ARG_PREVIEW]
    formatted = ", ".join(f"{k}={v!r}" for k, v in args.items())
    return formatted[:_MAX_ARG_PREVIEW]


class TerminalRenderer:
    """Renders normalized wire events to the terminal.

    Modes:
    - "eval": Used by cli_agents.py for eval harness output. Buffers text,
      counts turns, writes everything to stdout, supports prefix for concurrency.
    - "cloud": Used by cmd_agent.py for `wafer agent --cloud`. Writes text to
      stdout, chrome to stderr, tracks subagent labels.
    """

    def __init__(
        self,
        *,
        mode: Literal["eval", "cloud"] = "eval",
        prefix: str | None = None,
        stdout_lock: threading.Lock | None = None,
        app_url_fn: Any | None = None,
        quiet: bool = False,
    ) -> None:
        self._mode = mode
        self._prefix = prefix
        self._lock = stdout_lock
        self._app_url_fn = app_url_fn
        self._quiet = quiet

        self._text_buffer: list[str] = []
        self._pending_tool_call: list[str] = []
        self._at_line_start = True
        self._turn_count = 0

        self._subagent_count = 0
        self._subagent_calls: dict[str, tuple[str, str]] = {}
        self._subagent_line_buf: dict[str, str] = {}
        self._subagent_streamed: set[str] = set()

        self._input_tokens = 0
        self._output_tokens = 0
        self._cache_read_tokens = 0
        self._cache_write_tokens = 0
        self._session_id: str | None = None

    @property
    def session_id(self) -> str | None:
        return self._session_id

    @property
    def input_tokens(self) -> int:
        return self._input_tokens

    @property
    def output_tokens(self) -> int:
        return self._output_tokens

    @property
    def cache_read_tokens(self) -> int:
        return self._cache_read_tokens

    @property
    def cache_write_tokens(self) -> int:
        return self._cache_write_tokens

    @property
    def turn_count(self) -> int:
        return self._turn_count

    def flush(self) -> None:
        """Flush any buffered text to output."""
        self._flush_text_buffer()

    def write_raw(self, text: str, color: str = "") -> None:
        """Write a pre-formatted line directly (e.g., non-JSON fallback)."""
        self._write_chrome(text, color)

    def render(self, event: dict[str, Any]) -> None:
        """Render a single normalized wire event."""
        etype = event.get("type", "")
        handler = _HANDLERS.get(etype)
        if handler is not None:
            handler(self, event)
        elif etype not in _SUPPRESSED_TYPES:
            if self._mode == "eval" and self._quiet:
                return
            self._flush_text_buffer()
            self._write_chrome(f"  {event}\n", _DIM)

    def _write_text(self, text: str) -> None:
        """Write agent text to stdout."""
        if not text:
            return
        def _do() -> None:
            if self._prefix and self._at_line_start:
                sys.stdout.write(_color(_CYAN, f"[{self._prefix}] "))
                self._at_line_start = False
            sys.stdout.write(text)
            sys.stdout.flush()
            self._at_line_start = text.endswith("\n")
        if self._lock:
            with self._lock:
                _do()
        else:
            _do()

    def _write_chrome(self, text: str, color: str = "") -> None:
        """Write UI chrome (tool calls, status, etc.)."""
        out = _color(color, text) if color else text
        if self._mode == "cloud":
            def _do() -> None:
                sys.stderr.write(out)
                sys.stderr.flush()
            if self._lock:
                with self._lock:
                    _do()
            else:
                _do()
        else:
            self._write_text(out)

    def _flush_text_buffer(self) -> None:
        if not self._text_buffer:
            return
        text = "".join(self._text_buffer)
        self._text_buffer.clear()
        if self._mode == "eval":
            if len(text) > _MAX_TEXT_BUFFER:
                text = text[:_MAX_TEXT_BUFFER] + "..."
            if text and not text.endswith("\n"):
                text += "\n"
            self._write_text(_color(_BLUE, text))
        else:
            self._write_text(text)

    def _handle_session_started(self, event: dict[str, Any]) -> None:
        sid = event.get("session_id", "")
        self._session_id = sid or self._session_id
        if self._mode == "cloud":
            short_id = sid[:8] if sid else ""
            app_url = self._app_url_fn(sid) if self._app_url_fn and sid else None
            link = f"\x1b]8;;{app_url}\x1b\\{app_url}\x1b]8;;\x1b\\" if app_url else ""
            self._write_chrome(f"{_DIM}Session {short_id} — agent running{_RESET}\n")
            if link:
                self._write_chrome(f"{_DIM}  {link}{_RESET}\n")
        elif self._mode == "eval" and sid:
            if self._quiet:
                return
            app_url = f"http://localhost:3001/agent?session={sid}"
            link = f"\x1b]8;;{app_url}\x1b\\{app_url}\x1b]8;;\x1b\\"
            self._write_chrome(f"  session {sid[:8]}  {_DIM}{link}{_RESET}\n", "")

    def _handle_session_complete(self, _event: dict[str, Any]) -> None:
        if self._mode == "eval" and self._quiet:
            return
        self._flush_text_buffer()
        if self._mode == "cloud":
            sys.stdout.flush()
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._write_chrome(f"{_DIM}Done.{_RESET}\n")

    def _handle_status(self, event: dict[str, Any]) -> None:
        if self._mode == "eval" and self._quiet:
            return
        self._flush_text_buffer()
        msg = event.get("message", "")
        self._write_chrome(f"\n  [{msg}]\n", _DIM)

    def _handle_text_delta(self, event: dict[str, Any]) -> None:
        delta = event.get("delta", "")
        if not delta:
            return
        if self._mode == "eval" and self._quiet:
            return
        if self._mode == "eval":
            self._text_buffer.append(delta)
        else:
            self._write_text(delta)

    def _handle_thinking_delta(self, event: dict[str, Any]) -> None:
        if self._mode == "cloud":
            delta = event.get("delta", "")
            if delta:
                self._write_chrome(f"{_DIM}{delta}{_RESET}")

    def _handle_tool_call_start(self, event: dict[str, Any]) -> None:
        self._flush_text_buffer()
        tool_id = event.get("id", "")
        tool_name = event.get("name", "")
        self._turn_count += 1

        if self._mode == "eval" and self._quiet:
            return

        if self._mode == "cloud" and tool_name == "subagent" and tool_id:
            self._subagent_count += 1
            label = f"[subagent-{self._subagent_count}]"
            color = _SUBAGENT_COLORS[
                (self._subagent_count - 1) % len(_SUBAGENT_COLORS)
            ]
            self._subagent_calls[tool_id] = (label, color)
            sys.stdout.flush()
            self._write_chrome(f"\n{color}> subagent {label}{_RESET}\n")
        elif self._mode == "cloud":
            sys.stdout.flush()
            self._write_chrome(f"\n{_CYAN}> {tool_name}{_RESET}\n")
        else:
            turn_pref = f"[turn {self._turn_count}] " if self._turn_count > 0 else ""
            self._pending_tool_call.append(f"\n  {turn_pref}> {tool_name}(")

    def _handle_tool_call_end(self, event: dict[str, Any]) -> None:
        if self._mode == "eval" and self._quiet:
            return
        tool_id = event.get("id", "")
        tool_name = event.get("name", "")
        args = event.get("args", {})

        if self._mode == "cloud":
            if tool_name == "subagent":
                sa = self._subagent_calls.get(tool_id)
                label_prefix = f"{sa[1]}{sa[0]}{_RESET} " if sa else ""
                for k in ("config", "target_name"):
                    v = args.get(k)
                    if v is not None:
                        self._write_chrome(f"  {label_prefix}{_DIM}{k}: {v}{_RESET}\n")
            elif args:
                for k, v in args.items():
                    val = str(v)[:_MAX_ARG_PREVIEW]
                    self._write_chrome(f"  {_DIM}{k}: {val}{_RESET}\n")
        else:
            args_str = _format_tool_args(tool_name, args)
            if self._pending_tool_call:
                self._write_chrome(
                    self._pending_tool_call.pop() + f"{args_str})\n", _YELLOW,
                )
            else:
                self._write_chrome(f"  {args_str}\n", _YELLOW)

    def _handle_tool_result(self, event: dict[str, Any]) -> None:
        self._flush_text_buffer()
        if self._mode == "eval" and self._quiet:
            return
        tool_call_id = event.get("tool_call_id", "")
        content = event.get("content", "")
        is_err = event.get("is_error", False)

        if self._mode == "cloud":
            sa = self._subagent_calls.get(tool_call_id)
            if sa:
                label, color = sa
                self._flush_subagent_line(tool_call_id, label, color)
            already_streamed = tool_call_id in self._subagent_streamed
            raw_content = content or event.get("error", "")
            raw_content = _SUBAGENT_SESSION_RE.sub("", raw_content).strip()

            if sa and is_err:
                marker = f"{sa[1]}{sa[0]}{_RESET} "
                display = raw_content[:_MAX_CONTENT_PREVIEW]
                self._write_chrome(f"{marker}{_RED}[fail] {display}{_RESET}\n")
            elif sa and already_streamed:
                pass
            elif raw_content:
                marker = f"{sa[1]}{sa[0]}{_RESET} " if sa else "  "
                truncated = len(raw_content) > _MAX_CONTENT_PREVIEW
                display = raw_content[:_MAX_CONTENT_PREVIEW]
                if truncated:
                    display += f"... ({len(raw_content) - _MAX_CONTENT_PREVIEW} chars truncated)"
                if is_err:
                    self._write_chrome(f"{marker}{_RED}[fail] {display}{_RESET}\n")
                else:
                    self._write_chrome(f"{marker}{display}\n")
        else:
            pfx = "  ERR " if is_err else "  => "
            color = _RED if is_err else _GREEN
            if is_err:
                full = content if content.endswith("\n") else content + "\n"
            else:
                full = _truncate_content(content, max_lines=3, max_chars=200)
            self._write_chrome(f"{pfx}{full}", color)

    def _handle_tool_result_delta(self, event: dict[str, Any]) -> None:
        delta = event.get("delta", "")
        if not delta:
            return
        tool_call_id = event.get("tool_call_id", "")
        sa = self._subagent_calls.get(tool_call_id)
        if sa:
            label, color = sa
            self._render_subagent_delta(delta, label, color, tool_call_id)
        else:
            self._write_chrome(f"{_DIM}{delta}{_RESET}")

    def _flush_subagent_line(
        self, tool_id: str, label: str, color: str,
    ) -> None:
        """Flush the buffered partial line for a subagent."""
        text = self._subagent_line_buf.pop(tool_id, "")
        if not text:
            return
        m = _SUBAGENT_SESSION_RE.match(text)
        if m:
            sub_sid = m.group(1)
            app_url = self._app_url_fn(sub_sid) if self._app_url_fn else None
            link = (
                f"\x1b]8;;{app_url}\x1b\\{sub_sid[:8]}\x1b]8;;\x1b\\"
                if app_url else sub_sid[:8]
            )
            self._write_chrome(f"{color}{label}{_RESET} session {link}\n")
        else:
            cleaned = _SUBAGENT_SESSION_RE.sub("", text).strip()
            if cleaned:
                self._write_chrome(f"{color}{label}{_RESET} {cleaned}\n")

    def _render_subagent_delta(
        self, delta: str, label: str, color: str, tool_id: str,
    ) -> None:
        self._subagent_streamed.add(tool_id)
        buf = self._subagent_line_buf.get(tool_id, "")
        buf += delta
        while "\n" in buf:
            line, buf = buf.split("\n", 1)
            stripped = line.rstrip("\r")
            m = _SUBAGENT_SESSION_RE.match(stripped)
            if m:
                sub_sid = m.group(1)
                app_url = self._app_url_fn(sub_sid) if self._app_url_fn else None
                link = (
                    f"\x1b]8;;{app_url}\x1b\\{sub_sid[:8]}\x1b]8;;\x1b\\"
                    if app_url else sub_sid[:8]
                )
                self._write_chrome(f"{color}{label}{_RESET} session {link}\n")
            elif stripped:
                cleaned = _SUBAGENT_SESSION_RE.sub("", stripped).strip()
                if cleaned:
                    self._write_chrome(f"{color}{label}{_RESET} {cleaned}\n")
        self._subagent_line_buf[tool_id] = buf

    def _handle_turn_end(self, event: dict[str, Any]) -> None:
        usage = event.get("usage", {})
        in_tok = max(0, usage.get("input_tokens", 0))
        out_tok = max(0, usage.get("output_tokens", 0))
        cache_r = max(0, usage.get("cache_read_tokens", 0))
        cache_w = max(0, usage.get("cache_write_tokens", 0))
        total_in = in_tok + cache_r
        if total_in > self._input_tokens:
            self._input_tokens = total_in
        if out_tok > self._output_tokens:
            self._output_tokens = out_tok
        if cache_r > self._cache_read_tokens:
            self._cache_read_tokens = cache_r
        if cache_w > self._cache_write_tokens:
            self._cache_write_tokens = cache_w

    def _handle_result(self, event: dict[str, Any]) -> None:
        self._flush_text_buffer()
        subtype = event.get("subtype", "done")
        usage = event.get("usage")
        if usage:
            self._input_tokens = usage.get("input_tokens", 0)
            self._output_tokens = usage.get("output_tokens", 0)
            self._cache_read_tokens = usage.get("cache_read_tokens", 0)
            self._cache_write_tokens = usage.get("cache_write_tokens", 0)
        if self._mode == "eval" and not self._quiet:
            self._write_chrome(f"  Agent completed ({subtype})\n", _MAGENTA)

    def _handle_error(self, event: dict[str, Any]) -> None:
        self._flush_text_buffer()
        if self._mode == "eval" and self._quiet:
            return
        error_msg = event.get("error", "unknown")
        session_id = event.get("session_id", "")
        if self._mode == "cloud":
            parts = [f"{_RED}Error: {error_msg}{_RESET}"]
            if session_id:
                parts.append(f"{_DIM}  session: {session_id}{_RESET}")
            self._write_chrome("\n".join(parts) + "\n")
        else:
            self._write_chrome(f"  Error: {error_msg}\n", _RED)

    def _handle_initializing(self, _event: dict[str, Any]) -> None:
        if self._mode == "eval" and not self._quiet:
            self._write_chrome("  initializing...\n", _DIM)

    def _handle_assistant(self, event: dict[str, Any]) -> None:
        if self._mode != "eval" or self._quiet:
            return
        self._flush_text_buffer()
        msg = event.get("message") or {}
        content = msg.get("content", []) if isinstance(msg, dict) else []
        for block in content[:5]:
            if not isinstance(block, dict):
                continue
            bt = block.get("type", "")
            if bt == "text":
                text = block.get("text", "")
                if text:
                    display = _truncate_content(text, max_lines=3, max_chars=200)
                    self._write_chrome(f"  [assistant] {display}", _BLUE)
            elif bt == "tool_use":
                name = block.get("name", "?")
                inp = block.get("input", {}) or {}
                path = inp.get("path", "")
                args_preview = f"path={path}" if path else ""
                self._write_chrome(f"  > {name}({args_preview})\n", _YELLOW)
            elif bt == "tool_result":
                c = block.get("content", "")
                display = _truncate_content(c, max_lines=3, max_chars=200)
                self._write_chrome(f"  => {display}", _GREEN)

    def _handle_system(self, event: dict[str, Any]) -> None:
        if self._mode != "eval" or self._quiet:
            return
        self._flush_text_buffer()
        subtype = event.get("subtype", "")
        if subtype != "init":
            self._write_chrome(f"  [system: {subtype or 'event'}]\n", _DIM)


_SUPPRESSED_TYPES = frozenset({
    "tool_call_delta",
    "tool_exec_start",
    "content_block_start",
    "content_block_stop",
    "content_block_delta",
    "message_start",
    "message_delta",
    "message_stop",
    "input_json_delta",
    "ping",
    "score",
    "user",
})

_HANDLERS: dict[str, Any] = {
    "session_started": TerminalRenderer._handle_session_started,
    "session_complete": TerminalRenderer._handle_session_complete,
    "status": TerminalRenderer._handle_status,
    "text_delta": TerminalRenderer._handle_text_delta,
    "thinking_delta": TerminalRenderer._handle_thinking_delta,
    "tool_call_start": TerminalRenderer._handle_tool_call_start,
    "tool_call_delta": lambda _self, _event: None,
    "tool_call_end": TerminalRenderer._handle_tool_call_end,
    "tool_result": TerminalRenderer._handle_tool_result,
    "tool_result_delta": TerminalRenderer._handle_tool_result_delta,
    "turn_end": TerminalRenderer._handle_turn_end,
    "result": TerminalRenderer._handle_result,
    "error": TerminalRenderer._handle_error,
    "initializing": TerminalRenderer._handle_initializing,
    "assistant": TerminalRenderer._handle_assistant,
    "system": TerminalRenderer._handle_system,
}
