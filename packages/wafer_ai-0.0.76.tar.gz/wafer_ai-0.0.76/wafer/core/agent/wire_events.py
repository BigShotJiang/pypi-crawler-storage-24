"""Canonical wire event contract for streaming events.

Defines the typed event shapes that flow over NDJSON and SSE between
producers (JsonFrontend, StreamingChunkFrontend) and consumers
(cli_agents._flush_line, cmd_agent._render_sse_event, TS UIs, eval harness).

Usage:
    raw = json.loads(line)
    event = normalize_wire_event(raw)
    match event["type"]:
        case "text_delta": ...
        case "tool_call_start": ...
"""
from __future__ import annotations

from typing import Any

PASSTHROUGH_EVENT_TYPES = frozenset({
    "status",
    "text_delta",
    "thinking_delta",
    "tool_call_start",
    "tool_call_delta",
    "tool_call_end",
    "tool_result",
    "tool_result_delta",
    "turn_end",
    "score",
    "error",
})

_TYPE_ALIASES: dict[str, str] = {
    "session_start": "session_started",
    "session_end": "session_complete",
}


def normalize_wire_event(raw: dict[str, Any]) -> dict[str, Any]:
    """Normalize a raw JSON event dict to canonical wire format.

    Handles legacy field names and event type aliases so consumers
    only need to handle one shape per event type.

    Mutations:
    - type aliases: session_start -> session_started, session_end -> session_complete
    - tool_call_start/end: tool_name -> name
    """
    if not isinstance(raw, dict):
        raise TypeError(f"Expected dict, got {type(raw).__name__}")
    etype = raw.get("type", "")
    canonical_type = _TYPE_ALIASES.get(etype, etype)
    if canonical_type != etype:
        raw = {**raw, "type": canonical_type}

    if canonical_type in ("tool_call_start", "tool_call_end"):
        raw = _normalize_tool_call_fields(raw)

    return raw


def _normalize_tool_call_fields(raw: dict[str, Any]) -> dict[str, Any]:
    """Ensure tool_call_start/end have canonical 'name' field."""
    if "name" not in raw and "tool_name" in raw:
        raw = {**raw, "name": raw["tool_name"]}
    return raw
