"""Bash command allowlists and denylists for agent sandboxing.

Re-exports from wafer.core.config.bash_commands for backward compatibility.
"""
from __future__ import annotations

from wafer.core.config.bash_commands import DANGEROUS_BASH_COMMANDS, SAFE_BASH_COMMANDS

__all__ = ["SAFE_BASH_COMMANDS", "DANGEROUS_BASH_COMMANDS"]
