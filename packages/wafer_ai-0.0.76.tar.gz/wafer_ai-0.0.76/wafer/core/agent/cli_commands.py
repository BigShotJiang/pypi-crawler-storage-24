"""CLI command builder for Cursor agent.

Used by cli_agents for top-level eval and subagent execution.
"""
from __future__ import annotations


def build_cursor_cli_args(
    prompt: str,
    *,
    model: str | None = None,
) -> list[str]:
    """Build Cursor CLI command args.
    Returns list suitable for subprocess: ["agent", "--yolo", "-p", prompt, ...]
    The Cursor CLI binary is called 'agent' (installed via cursor.com/install).
    --yolo grants maximum permissions (no confirmation prompts).
    --output-format stream-json enables NDJSON streaming for trajectory capture.
    """
    cmd = ["agent", "--yolo", "-p", prompt, "--output-format", "stream-json"]
    if model:
        cmd.extend(["--model", model])
    return cmd
