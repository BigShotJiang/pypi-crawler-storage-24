"""Context variable injection for system prompts.

Reserved variables: working_directory_context, targets_context, sandboxes_context,
repository_context, skills_context. Used by prompt builders to inject runtime context.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

from wafer.cli.agent_config import AgentConfig, ContextConfig


def _format_working_dir(working_dir: Path | None) -> str:
    """Format working directory context with directory listing."""
    if working_dir is None:
        return ""
    resolved = working_dir.resolve()
    lines = [
        f"Your working directory is `{resolved}`. "
        "All commands run here automatically — do NOT prefix with `cd`. "
        "Use relative paths for file operations.",
    ]
    if resolved.is_dir():
        entries = sorted(resolved.iterdir())
        if entries:
            listing = []
            for entry in entries:
                if entry.name.startswith("."):
                    continue
                suffix = "/" if entry.is_dir() else ""
                listing.append(f"  {entry.name}{suffix}")
            if listing:
                lines.append("")
                lines.append("Contents:")
                lines.extend(listing)
    return "\n".join(lines)


def _format_targets(targets: list[str] | None, default_target: str | None) -> str:
    """Format targets context. Returns empty string if targets is None or empty."""
    if not targets:
        return ""
    lines = ["## Available targets", ""]
    lines.extend(targets)
    if default_target:
        lines.append("")
        lines.append(f"Default target: `{default_target}`")
    return "\n".join(lines)


def _format_sandboxes(sandbox_lines: list[str] | None) -> str:
    """Format sandboxes context. Returns empty string if sandbox_lines is None or empty."""
    if not sandbox_lines:
        return ""
    return "## Active sandboxes\n\n" + "\n".join(sandbox_lines)


def _parse_remote_url(url: str) -> str:
    """Strip token from URL, remove .git, extract org/repo."""
    # Strip x-access-token:xxx@ or similar auth prefix
    url = re.sub(r"^[^:]*://[^@]+@", r"https://", url, count=1)
    url = re.sub(r"^[^:]*://[^/]*:[^@]+@", r"https://", url, count=1)
    if url.endswith(".git"):
        url = url[:-4]
    # Extract org/repo from path (e.g. https://github.com/org/repo -> org/repo)
    match = re.search(r"github\.com[/:]([^/]+/[^/]+?)(?:/|$)", url)
    if match:
        return match.group(1)
    match = re.search(r"gitlab\.com[/:]([^/]+/[^/]+?)(?:/|$)", url)
    if match:
        return match.group(1)
    # Fallback: take last two path segments
    parts = [p for p in url.replace("://", "/").split("/") if p and p not in ("http", "https")]
    if len(parts) >= 2:
        return "/".join(parts[-2:])
    return url


def _format_repo(working_dir: Path | None) -> str:
    """Format repository context (branch, remote org/repo). Returns empty if not a git repo."""
    cwd = Path(working_dir) if working_dir is not None else Path.cwd()
    lines: list[str] = []

    try:
        subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=cwd,
            capture_output=True,
            check=True,
            text=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return ""

    # Branch
    try:
        branch_result = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=cwd,
            capture_output=True,
            check=True,
            text=True,
        )
        branch = branch_result.stdout.strip()
        if branch:
            lines.append(f"Branch: `{branch}`")
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    # Remote URL / org-repo
    try:
        remote_result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=cwd,
            capture_output=True,
            check=True,
            text=True,
        )
        remote_url = remote_result.stdout.strip()
        if remote_url:
            org_repo = _parse_remote_url(remote_url)
            lines.append(f"Repository: `{org_repo}`")
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    if not lines:
        return ""
    return "## Repository\n\n" + "\n".join(lines)


def _format_skills(config: AgentConfig) -> str:
    """Format skills context if include_skills is True. Returns empty otherwise."""
    if not config.include_skills:
        return ""
    from wafer.core.agent.skills import discover_skills, format_skill_metadata_for_prompt

    skill_metadata = [s for s in discover_skills() if not s.disable_model_invocation]
    if not skill_metadata:
        return ""
    return format_skill_metadata_for_prompt(skill_metadata)


def collect_context_variables(
    config: AgentConfig,
    working_dir: Path | None,
    *,
    targets: list[str] | None = None,
    default_target: str | None = None,
    sandbox_lines: list[str] | None = None,
) -> dict[str, str]:
    """Collect context variables based on config and runtime state.

    Respects ContextConfig (working_dir, targets, sandboxes, repo) and
    config.include_skills for skills. Returns dict mapping variable name to content.
    Empty content is "".
    """
    ctx = config.context
    result: dict[str, str] = {}

    result["working_directory_context"] = (
        _format_working_dir(working_dir) if ctx.working_dir else ""
    )
    result["targets_context"] = (
        _format_targets(targets, default_target) if ctx.targets else ""
    )
    result["sandboxes_context"] = (
        _format_sandboxes(sandbox_lines) if ctx.sandboxes else ""
    )
    result["repository_context"] = (
        _format_repo(working_dir) if ctx.repo else ""
    )
    result["skills_context"] = _format_skills(config)

    return result
