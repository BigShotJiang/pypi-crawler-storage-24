"""Backward-compat re-export. Canonical location: wafer.core.config.agent."""
from wafer.core.config.agent import (  # noqa: F401
    AgentConfig,
    ContextConfig,
    ContextManagementConfig,
    get_bundled_template_path,
    list_bundled_templates,
    load_agent_config,
)

__all__ = [
    "AgentConfig",
    "ContextConfig",
    "ContextManagementConfig",
    "get_bundled_template_path",
    "list_bundled_templates",
    "load_agent_config",
]
