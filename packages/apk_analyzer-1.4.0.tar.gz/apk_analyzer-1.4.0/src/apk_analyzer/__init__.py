"""APK SDK Analyzer — static SDK detection for Android APK files."""
__version__ = "1.4.0"
