# APK SDK Analyzer

Static third-party SDK detection tool for Android APK files.

## Features

- **Zero-dependency on decompilers** — pure Python static analysis
- **5-layer detection engine**: DEX class names · AndroidManifest components · Native `.so` libs · META-INF version files · DEX BuildConfig static fields  
- **Structured output**: JSON + interactive single-file HTML report
- **Extensible signature database**: YAML files in `sdk_signatures/` — update without recompiling
- **Cross-platform exe**: Windows / macOS / Linux via PyInstaller

## Quick Start

```bash
# Install
pip install -r requirements.txt

# Run
python src/main.py target.apk

# Output
# target_report.json  — structured data
# target_report.html  — interactive report (open in browser)
```

## Pre-built Binaries

Download from [Releases](../../releases):

| Platform | File |
|----------|------|
| Windows x64 | `apk-analyzer-windows-x64.exe` |
| macOS ARM64 | `apk-analyzer-macos-arm64` |
| Linux x64 | `apk-analyzer-linux-x64` |

```
apk-analyzer.exe target.apk
apk-analyzer.exe target.apk --signatures-dir ./sdk_signatures
apk-analyzer.exe target.apk --categories push,ads --verbose
```

## Detection Methods

| Layer | Method | Coverage |
|-------|--------|----------|
| L1 | DEX class name prefix matching | ~90% of SDKs |
| L2 | AndroidManifest service/receiver/activity | Confirms presence |
| L3 | Native `.so` library names | Native SDKs |
| L4 | META-INF `.version` files | AndroidX / Google libs |
| L5 | DEX `BuildConfig.VERSION_NAME` static fields | Exact versions |

## SDK Signature Format

```yaml
# sdk_signatures/<category>/<id>.yaml
id: xiaomi_mipush
name: 小米推送 MiPush
category: push
vendor: Xiaomi
description: "小米厂商推送通道"

detection:
  package_prefixes:
    - "com.xiaomi.push"
  native_libs:
    - "libmipush.so"
  manifest_services:
    - "com.xiaomi.push.service.XMPushService"

version_extraction:
  buildconfig:
    class_pattern: "com.xiaomi.push.BuildConfig"
    field: "VERSION_NAME"

risk:
  permissions:
    - "android.permission.RECEIVE_BOOT_COMPLETED"
  data_collection:
    - "设备标识符"
  privacy_risk: low   # low / medium / high
  notes: "..."
```

## Output JSON Structure

```json
{
  "meta": { "tool_version": "1.0.0", "analysis_time": "...", ... },
  "apk_info": { "package_name": "com.example.app", "version_name": "1.2.3", ... },
  "detected_sdks": [
    {
      "id": "xiaomi_mipush",
      "name": "小米推送 MiPush",
      "version": "5.9.6",
      "confidence": "high",
      "detection_evidence": { "matched_packages": ["com.xiaomi.push"], ... },
      "risk": { "privacy_risk": "low", ... }
    }
  ],
  "summary": { "total_detected": 46, "by_category": { "push": 5, ... } }
}
```

## Contributing Signatures

Add a YAML file to the appropriate `sdk_signatures/<category>/` directory. See existing files for the format. No code changes required.

## Build from Source

```bash
pip install pyinstaller
pyinstaller apk_analyzer.spec
# Output: dist/apk-analyzer(.exe)
```

## License

MIT

## Release Pipeline

Automated release pipeline via GitHub Actions:

```
PR merge (feature-* or fix-*)
   ↓ auto-tag.yml
Creates v1.y.z tag
   ↓ publish.yml  
Publishes to PyPI → pip install apk-analyzer
```
