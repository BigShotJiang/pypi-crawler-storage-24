from collections.abc import Callable

import httpx

from zalor.agents._openai.configure import configure_openai


def test_agent(
    agent_name: str,
    api_key: str,
    run_agent: Callable[[str], str],
    dataset: str | None = None,
    endpoint: str = "https://agents.zalor.ai",
) -> None:
    """Run a full test suite against the agent.

    Steps:
      A) Upload agent config to Zalor (captures system prompt + tools via OTel)
      B) Start a run — if dataset is given, use its inputs; otherwise generate 20
      C) Run the agent on each input, exporting traces to Zalor
      D) Print a link to view results
    """
    client = httpx.Client(
        base_url=endpoint,
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=60.0,
    )
    try:
        agent_id = _upload_agent_config(client, api_key, endpoint, agent_name, run_agent)
        run_id, inputs, custom_input_ids = _start_run(client, agent_id, dataset)
        _run_simulations(client, api_key, endpoint, run_id, inputs, run_agent, custom_input_ids)
        print(f"\nView results: {endpoint}/agents/{agent_id}/runs/{run_id}")
    finally:
        client.close()


def _upload_agent_config(
    client: httpx.Client,
    api_key: str,
    endpoint: str,
    agent_name: str,
    run_agent: Callable[[str], str],
) -> str:
    from openinference.instrumentation.openai import OpenAIInstrumentor

    exporter = configure_openai(api_key, endpoint)
    try:
        run_agent(".")
    finally:
        OpenAIInstrumentor().uninstrument()
    resp = client.post(
        "/api/v1/agents/config",
        json={"trace_id": exporter.trace_id, "agent_name": agent_name},
    )
    resp.raise_for_status()
    return resp.json()["agent_id"]


def _start_run(
    client: httpx.Client, agent_id: str, dataset: str | None = None
) -> tuple[str, list[str], list[str] | None]:
    body = {"dataset_name": dataset} if dataset else {}
    resp = client.post(f"/api/v1/agents/{agent_id}/runs", json=body)
    resp.raise_for_status()
    data = resp.json()
    return data["run_id"], data["inputs"], data.get("custom_input_ids")


def _run_simulations(
    client: httpx.Client,
    api_key: str,
    endpoint: str,
    run_id: str,
    inputs: list[str],
    run_agent: Callable[[str], str],
    custom_input_ids: list[str] | None = None,
) -> None:
    total = len(inputs)
    for i, input_text in enumerate(inputs, 1):
        from openinference.instrumentation.openai import OpenAIInstrumentor

        exporter = configure_openai(api_key, endpoint)
        try:
            run_agent(input_text)
        finally:
            OpenAIInstrumentor().uninstrument()
        payload: dict = {"run_id": run_id}
        if custom_input_ids and i - 1 < len(custom_input_ids):
            payload["custom_input_id"] = custom_input_ids[i - 1]
        resp = client.post(
            f"/api/v1/traces/{exporter.trace_id}/ingest",
            json=payload,
        )
        resp.raise_for_status()
        print(f"Simulation {i}/{total} complete")
