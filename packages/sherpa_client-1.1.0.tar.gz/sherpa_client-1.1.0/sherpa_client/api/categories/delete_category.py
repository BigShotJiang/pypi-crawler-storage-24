from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.category_id import CategoryId
from ...types import Response


def _get_kwargs(
    project_name: str,
    category_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/projects/{project_name}/categories/{category_id}".format(
            project_name=project_name,
            category_id=category_id,
        ),
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, CategoryId]]:
    if response.status_code == 200:
        response_200 = CategoryId.from_dict(response.json())

        return response_200
    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, CategoryId]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_name: str,
    category_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Union[Any, CategoryId]]:
    """Delete a document category

    Args:
        project_name (str):
        category_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, CategoryId]]
    """

    kwargs = _get_kwargs(
        project_name=project_name,
        category_id=category_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_name: str,
    category_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[Union[Any, CategoryId]]:
    """Delete a document category

    Args:
        project_name (str):
        category_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, CategoryId]
    """

    return sync_detailed(
        project_name=project_name,
        category_id=category_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    project_name: str,
    category_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Union[Any, CategoryId]]:
    """Delete a document category

    Args:
        project_name (str):
        category_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, CategoryId]]
    """

    kwargs = _get_kwargs(
        project_name=project_name,
        category_id=category_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_name: str,
    category_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[Union[Any, CategoryId]]:
    """Delete a document category

    Args:
        project_name (str):
        category_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, CategoryId]
    """

    return (
        await asyncio_detailed(
            project_name=project_name,
            category_id=category_id,
            client=client,
        )
    ).parsed
