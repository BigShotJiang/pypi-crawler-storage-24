from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.annotate_documents_with_pipeline import AnnotateDocumentsWithPipeline
from ...models.annotated_document import AnnotatedDocument
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: AnnotateDocumentsWithPipeline,
    inline_labels: Union[Unset, bool] = True,
    inline_label_ids: Union[Unset, bool] = True,
    inline_text: Union[Unset, bool] = True,
    debug: Union[Unset, bool] = False,
    parallelize: Union[Unset, bool] = False,
    error_policy: Union[Unset, str] = UNSET,
    project_context: Union[Unset, str] = UNSET,
    output_fields: Union[Unset, str] = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["inlineLabels"] = inline_labels

    params["inlineLabelIds"] = inline_label_ids

    params["inlineText"] = inline_text

    params["debug"] = debug

    params["parallelize"] = parallelize

    params["errorPolicy"] = error_policy

    params["projectContext"] = project_context

    params["outputFields"] = output_fields

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/annotate/_annotate_documents",
        "params": params,
    }

    _body = body.to_dict()

    _kwargs["json"] = _body
    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[list["AnnotatedDocument"]]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for componentsschemas_annotated_document_array_item_data in _response_200:
            componentsschemas_annotated_document_array_item = (
                AnnotatedDocument.from_dict(
                    componentsschemas_annotated_document_array_item_data
                )
            )

            response_200.append(componentsschemas_annotated_document_array_item)

        return response_200
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[list["AnnotatedDocument"]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AnnotateDocumentsWithPipeline,
    inline_labels: Union[Unset, bool] = True,
    inline_label_ids: Union[Unset, bool] = True,
    inline_text: Union[Unset, bool] = True,
    debug: Union[Unset, bool] = False,
    parallelize: Union[Unset, bool] = False,
    error_policy: Union[Unset, str] = UNSET,
    project_context: Union[Unset, str] = UNSET,
    output_fields: Union[Unset, str] = UNSET,
) -> Response[list["AnnotatedDocument"]]:
    """annotate documents with a pipeline

    Args:
        inline_labels (Union[Unset, bool]):  Default: True.
        inline_label_ids (Union[Unset, bool]):  Default: True.
        inline_text (Union[Unset, bool]):  Default: True.
        debug (Union[Unset, bool]):  Default: False.
        parallelize (Union[Unset, bool]):  Default: False.
        error_policy (Union[Unset, str]):
        project_context (Union[Unset, str]):
        output_fields (Union[Unset, str]):
        body (AnnotateDocumentsWithPipeline):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list['AnnotatedDocument']]
    """

    kwargs = _get_kwargs(
        body=body,
        inline_labels=inline_labels,
        inline_label_ids=inline_label_ids,
        inline_text=inline_text,
        debug=debug,
        parallelize=parallelize,
        error_policy=error_policy,
        project_context=project_context,
        output_fields=output_fields,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AnnotateDocumentsWithPipeline,
    inline_labels: Union[Unset, bool] = True,
    inline_label_ids: Union[Unset, bool] = True,
    inline_text: Union[Unset, bool] = True,
    debug: Union[Unset, bool] = False,
    parallelize: Union[Unset, bool] = False,
    error_policy: Union[Unset, str] = UNSET,
    project_context: Union[Unset, str] = UNSET,
    output_fields: Union[Unset, str] = UNSET,
) -> Optional[list["AnnotatedDocument"]]:
    """annotate documents with a pipeline

    Args:
        inline_labels (Union[Unset, bool]):  Default: True.
        inline_label_ids (Union[Unset, bool]):  Default: True.
        inline_text (Union[Unset, bool]):  Default: True.
        debug (Union[Unset, bool]):  Default: False.
        parallelize (Union[Unset, bool]):  Default: False.
        error_policy (Union[Unset, str]):
        project_context (Union[Unset, str]):
        output_fields (Union[Unset, str]):
        body (AnnotateDocumentsWithPipeline):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list['AnnotatedDocument']
    """

    return sync_detailed(
        client=client,
        body=body,
        inline_labels=inline_labels,
        inline_label_ids=inline_label_ids,
        inline_text=inline_text,
        debug=debug,
        parallelize=parallelize,
        error_policy=error_policy,
        project_context=project_context,
        output_fields=output_fields,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AnnotateDocumentsWithPipeline,
    inline_labels: Union[Unset, bool] = True,
    inline_label_ids: Union[Unset, bool] = True,
    inline_text: Union[Unset, bool] = True,
    debug: Union[Unset, bool] = False,
    parallelize: Union[Unset, bool] = False,
    error_policy: Union[Unset, str] = UNSET,
    project_context: Union[Unset, str] = UNSET,
    output_fields: Union[Unset, str] = UNSET,
) -> Response[list["AnnotatedDocument"]]:
    """annotate documents with a pipeline

    Args:
        inline_labels (Union[Unset, bool]):  Default: True.
        inline_label_ids (Union[Unset, bool]):  Default: True.
        inline_text (Union[Unset, bool]):  Default: True.
        debug (Union[Unset, bool]):  Default: False.
        parallelize (Union[Unset, bool]):  Default: False.
        error_policy (Union[Unset, str]):
        project_context (Union[Unset, str]):
        output_fields (Union[Unset, str]):
        body (AnnotateDocumentsWithPipeline):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list['AnnotatedDocument']]
    """

    kwargs = _get_kwargs(
        body=body,
        inline_labels=inline_labels,
        inline_label_ids=inline_label_ids,
        inline_text=inline_text,
        debug=debug,
        parallelize=parallelize,
        error_policy=error_policy,
        project_context=project_context,
        output_fields=output_fields,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AnnotateDocumentsWithPipeline,
    inline_labels: Union[Unset, bool] = True,
    inline_label_ids: Union[Unset, bool] = True,
    inline_text: Union[Unset, bool] = True,
    debug: Union[Unset, bool] = False,
    parallelize: Union[Unset, bool] = False,
    error_policy: Union[Unset, str] = UNSET,
    project_context: Union[Unset, str] = UNSET,
    output_fields: Union[Unset, str] = UNSET,
) -> Optional[list["AnnotatedDocument"]]:
    """annotate documents with a pipeline

    Args:
        inline_labels (Union[Unset, bool]):  Default: True.
        inline_label_ids (Union[Unset, bool]):  Default: True.
        inline_text (Union[Unset, bool]):  Default: True.
        debug (Union[Unset, bool]):  Default: False.
        parallelize (Union[Unset, bool]):  Default: False.
        error_policy (Union[Unset, str]):
        project_context (Union[Unset, str]):
        output_fields (Union[Unset, str]):
        body (AnnotateDocumentsWithPipeline):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list['AnnotatedDocument']
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            inline_labels=inline_labels,
            inline_label_ids=inline_label_ids,
            inline_text=inline_text,
            debug=debug,
            parallelize=parallelize,
            error_policy=error_policy,
            project_context=project_context,
            output_fields=output_fields,
        )
    ).parsed
