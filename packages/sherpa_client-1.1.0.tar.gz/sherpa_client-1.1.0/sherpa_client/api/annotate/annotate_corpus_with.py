from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.sherpa_job_bean import SherpaJobBean
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_name: str,
    annotator: str,
    *,
    annotator_project: Union[Unset, str] = UNSET,
    overwrite: Union[Unset, bool] = True,
    email_notification: Union[Unset, bool] = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["annotatorProject"] = annotator_project

    params["overwrite"] = overwrite

    params["emailNotification"] = email_notification

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/projects/{project_name}/annotators/{annotator}/_annotate_corpus".format(
            project_name=project_name,
            annotator=annotator,
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[SherpaJobBean]:
    if response.status_code == 200:
        response_200 = SherpaJobBean.from_dict(response.json())

        return response_200
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[SherpaJobBean]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_name: str,
    annotator: str,
    *,
    client: Union[AuthenticatedClient, Client],
    annotator_project: Union[Unset, str] = UNSET,
    overwrite: Union[Unset, bool] = True,
    email_notification: Union[Unset, bool] = False,
) -> Response[SherpaJobBean]:
    """Annotate the corpus with the given annotator

    Args:
        project_name (str):
        annotator (str):
        annotator_project (Union[Unset, str]):
        overwrite (Union[Unset, bool]):  Default: True.
        email_notification (Union[Unset, bool]):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SherpaJobBean]
    """

    kwargs = _get_kwargs(
        project_name=project_name,
        annotator=annotator,
        annotator_project=annotator_project,
        overwrite=overwrite,
        email_notification=email_notification,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_name: str,
    annotator: str,
    *,
    client: Union[AuthenticatedClient, Client],
    annotator_project: Union[Unset, str] = UNSET,
    overwrite: Union[Unset, bool] = True,
    email_notification: Union[Unset, bool] = False,
) -> Optional[SherpaJobBean]:
    """Annotate the corpus with the given annotator

    Args:
        project_name (str):
        annotator (str):
        annotator_project (Union[Unset, str]):
        overwrite (Union[Unset, bool]):  Default: True.
        email_notification (Union[Unset, bool]):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SherpaJobBean
    """

    return sync_detailed(
        project_name=project_name,
        annotator=annotator,
        client=client,
        annotator_project=annotator_project,
        overwrite=overwrite,
        email_notification=email_notification,
    ).parsed


async def asyncio_detailed(
    project_name: str,
    annotator: str,
    *,
    client: Union[AuthenticatedClient, Client],
    annotator_project: Union[Unset, str] = UNSET,
    overwrite: Union[Unset, bool] = True,
    email_notification: Union[Unset, bool] = False,
) -> Response[SherpaJobBean]:
    """Annotate the corpus with the given annotator

    Args:
        project_name (str):
        annotator (str):
        annotator_project (Union[Unset, str]):
        overwrite (Union[Unset, bool]):  Default: True.
        email_notification (Union[Unset, bool]):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SherpaJobBean]
    """

    kwargs = _get_kwargs(
        project_name=project_name,
        annotator=annotator,
        annotator_project=annotator_project,
        overwrite=overwrite,
        email_notification=email_notification,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_name: str,
    annotator: str,
    *,
    client: Union[AuthenticatedClient, Client],
    annotator_project: Union[Unset, str] = UNSET,
    overwrite: Union[Unset, bool] = True,
    email_notification: Union[Unset, bool] = False,
) -> Optional[SherpaJobBean]:
    """Annotate the corpus with the given annotator

    Args:
        project_name (str):
        annotator (str):
        annotator_project (Union[Unset, str]):
        overwrite (Union[Unset, bool]):  Default: True.
        email_notification (Union[Unset, bool]):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SherpaJobBean
    """

    return (
        await asyncio_detailed(
            project_name=project_name,
            annotator=annotator,
            client=client,
            annotator_project=annotator_project,
            overwrite=overwrite,
            email_notification=email_notification,
        )
    ).parsed
