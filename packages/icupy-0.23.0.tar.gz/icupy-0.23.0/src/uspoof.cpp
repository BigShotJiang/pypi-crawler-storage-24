#include "main.hpp"
#include "usetptr.hpp"
#include "uspoofptr.hpp"
#include <optional>
#include <pybind11/stl.h>

using namespace icu;

namespace icupy {

//
// struct USpoofChecker
//
USpoofCheckerPtr::USpoofCheckerPtr(USpoofChecker *p) : p_(p) {}

USpoofCheckerPtr::~USpoofCheckerPtr() {}

USpoofChecker *USpoofCheckerPtr::get() const { return p_; }

#if (U_ICU_VERSION_MAJOR_NUM >= 58)
//
// struct USpoofCheckResult
//
USpoofCheckResultPtr::USpoofCheckResultPtr(USpoofCheckResult *p) : p_(p) {}

USpoofCheckResultPtr::~USpoofCheckResultPtr() {}

USpoofCheckResult *USpoofCheckResultPtr::get() const { return p_; }
#endif // (U_ICU_VERSION_MAJOR_NUM >= 58)

} // namespace icupy

void init_uspoof(py::module &m) {
#if (U_ICU_VERSION_MAJOR_NUM >= 51)
  //
  // enum URestrictionLevel
  //
  py::enum_<URestrictionLevel>(m, "URestrictionLevel", py::arithmetic(), R"doc(
Constants from UAX #39 for use in :func:`uspoof_set_restriction_level`, and
for returned identifier restriction levels in check results.

See Also:
    :func:`uspoof_set_restriction_level`
    :func:`uspoof_check`
      )doc")
      .value("USPOOF_ASCII", USPOOF_ASCII, R"doc(
             All characters in the string are in the identifier profile and
             all characters in the string are in the ASCII range.
             )doc")
#if (U_ICU_VERSION_MAJOR_NUM >= 53)
      .value("USPOOF_SINGLE_SCRIPT_RESTRICTIVE",
             USPOOF_SINGLE_SCRIPT_RESTRICTIVE, R"doc(
             The string classifies as ASCII-Only, or all characters in the
             string are in the identifier profile and the string is
             single-script, according to the definition in UTS 39 section 5.1.
             )doc")
#endif // (U_ICU_VERSION_MAJOR_NUM >= 53)
      .value("USPOOF_HIGHLY_RESTRICTIVE", USPOOF_HIGHLY_RESTRICTIVE, R"doc(
             The string classifies as Single Script, or all characters in the
             string are in the identifier profile and the string is covered by
             any of the following sets of scripts, according to the definition
             in UTS 39 section 5.1:

             - Latin + Han + Bopomofo (or equivalently: Latn + Hanb)
             - Latin + Han + Hiragana + Katakana (or equivalently: Latn + Jpan)
             - Latin + Han + Hangul (or equivalently: Latn +Kore)

             This is the default restriction in ICU.
             )doc")
      .value("USPOOF_MODERATELY_RESTRICTIVE", USPOOF_MODERATELY_RESTRICTIVE,
             R"doc(
             The string classifies as Highly Restrictive, or all characters
             in the string are in the identifier profile and the string is
             covered by Latin and any one other Recommended or Aspirational
             script, except Cyrillic, Greek, and Cherokee.
             )doc")
      .value("USPOOF_MINIMALLY_RESTRICTIVE", USPOOF_MINIMALLY_RESTRICTIVE,
             R"doc(
             All characters in the string are in the identifier profile.

             Allow arbitrary mixtures of scripts.
             )doc")
      .value("USPOOF_UNRESTRICTIVE", USPOOF_UNRESTRICTIVE, R"doc(
             Any valid identifiers, including characters outside of the
             Identifier Profile.
             )doc")
#if (U_ICU_VERSION_MAJOR_NUM >= 53)
      .value("USPOOF_RESTRICTION_LEVEL_MASK", USPOOF_RESTRICTION_LEVEL_MASK,
             R"doc(
             Mask for selecting the Restriction Level bits from the return
             value of :func:`uspoof_check`.
             )doc")
#endif // (U_ICU_VERSION_MAJOR_NUM >= 53)
      .export_values();
#endif // (U_ICU_VERSION_MAJOR_NUM >= 51)

  //
  // enum USpoofChecks
  //
  py::enum_<USpoofChecks>(m, "USpoofChecks", py::arithmetic(), R"doc(
Enum for the kinds of checks that :class:`USpoofChecker` can perform.

These enum values are used both to select the set of checks that will
be performed, and to report results from the check function.
      )doc")
      .value("USPOOF_SINGLE_SCRIPT_CONFUSABLE", USPOOF_SINGLE_SCRIPT_CONFUSABLE,
             R"doc(
             When performing the two-string :func:`uspoof_are_confusable` test,
             this flag in the return value indicates that the two strings are
             visually confusable and that they are from the same script,
             according to UTS 39 section 4.
             )doc")
      .value("USPOOF_MIXED_SCRIPT_CONFUSABLE", USPOOF_MIXED_SCRIPT_CONFUSABLE,
             R"doc(
             When performing the two-string :func:`uspoof_are_confusable` test,
             this flag in the return value indicates that the two strings are
             visually confusable and that they are not from the same script,
             according to UTS 39 section 4.
             )doc")
      .value("USPOOF_WHOLE_SCRIPT_CONFUSABLE", USPOOF_WHOLE_SCRIPT_CONFUSABLE,
             R"doc(
             When performing the two-string :func:`uspoof_are_confusable` test,
             this flag in the return value indicates that the two strings are
             visually confusable and that they are not from the same script but
             both of them are single-script strings, according to UTS 39
             section 4.
             )doc")
#if (U_ICU_VERSION_MAJOR_NUM >= 58)
      .value("USPOOF_CONFUSABLE", USPOOF_CONFUSABLE, R"doc(
             Enable this flag in :func:`uspoof_set_checks` to turn on all types
             of confusables.

             You may set the checks to some subset of
             :attr:`USPOOF_SINGLE_SCRIPT_CONFUSABLE`,
             :attr:`USPOOF_MIXED_SCRIPT_CONFUSABLE`, or
             :attr:`USPOOF_WHOLE_SCRIPT_CONFUSABLE` to make
             :func:`uspoof_are_confusable` return only those types of
             confusables.
             )doc")
#endif // (U_ICU_VERSION_MAJOR_NUM >= 58)
      .value("USPOOF_ANY_CASE", USPOOF_ANY_CASE, R"doc(
             Deprecated: ICU 58 Any case confusable mappings were removed from
             UTS 39; the corresponding ICU API was deprecated.
             )doc")
      .value("USPOOF_RESTRICTION_LEVEL", USPOOF_RESTRICTION_LEVEL, R"doc(
             Check that an identifier is no looser than the specified
             RestrictionLevel.

             The default if :func:`uspoof_set_restriction_level` is not called
             is :attr:`URestrictionLevel.USPOOF_HIGHLY_RESTRICTIVE`.

             If :attr:`USPOOF_AUX_INFO` is enabled the actual restriction level
             of the identifier being tested will also be returned by
             :func:`uspoof_check`.
             )doc")
      .value("USPOOF_SINGLE_SCRIPT", USPOOF_SINGLE_SCRIPT, R"doc(
             Deprecated: ICU 51 Use :attr:`USPOOF_RESTRICTION_LEVEL` instead.
             )doc")
      .value("USPOOF_INVISIBLE", USPOOF_INVISIBLE, R"doc(
             Check an identifier for the presence of invisible characters,
             such as zero-width spaces, or character sequences that are likely
             not to display, such as multiple occurrences of the same
             non-spacing mark. This check does not test the input string as a
             whole for conformance to any particular syntax for identifiers.
             )doc")
      .value("USPOOF_CHAR_LIMIT", USPOOF_CHAR_LIMIT, R"doc(
             Check that an identifier contains only characters from a specified
             set of acceptable characters.

             See :func:`uspoof_set_allowed_chars` and
             :func:`uspoof_set_allowed_locales`. Note that a string that fails
             this check will also fail the :attr:`USPOOF_RESTRICTION_LEVEL`
             check.
             )doc")
      .value("USPOOF_MIXED_NUMBERS", USPOOF_MIXED_NUMBERS, R"doc(
             Check that an identifier does not mix numbers from different
             numbering systems.

             For more information, see UTS 39 section 5.3.
             )doc")
#if (U_ICU_VERSION_MAJOR_NUM >= 62)
      .value("USPOOF_HIDDEN_OVERLAY", USPOOF_HIDDEN_OVERLAY, R"doc(
             Check that an identifier does not have a combining character
             following a character in which that combining character would be
             hidden; for example 'i' followed by a U+0307 combining dot.

             More specifically, the following characters are forbidden from
             preceding a U+0307:

             - Those with the Soft_Dotted Unicode property (which includes
               'i' and 'j')
             - Latin lowercase letter 'l'
             - Dotless 'i' and 'j' ('ı' and 'ȷ', U+0131 and U+0237)
             - Any character whose confusable prototype ends with such a
               character (Soft_Dotted, 'l', 'ı', or 'ȷ')

             In addition, combining characters are allowed between the above
             characters and U+0307 except those with combining class 0 or
             combining class "Above" (230, same class as U+0307).

             This list and the number of combing characters considered by this
             check may grow over time.
             )doc")
#endif // (U_ICU_VERSION_MAJOR_NUM >= 62)
      .value("USPOOF_ALL_CHECKS", USPOOF_ALL_CHECKS,
             R"doc(
             Enable all spoof checks.
             )doc")
      .value("USPOOF_AUX_INFO", USPOOF_AUX_INFO, R"doc(
             Enable the return of auxiliary (non-error) information in the
             upper bits of the check results value.

             If this "check" is not enabled, the results of
             :func:`uspoof_check` will be zero when an identifier passes all
             of the enabled checks.

             If this "check" is enabled, (:func:`uspoof_check` &
             :attr:`USPOOF_ALL_CHECKS`) will be zero when an identifier
             passes all checks.
             )doc")
      .export_values();

  //
  // struct USpoofChecker
  //
  py::class_<icupy::USpoofCheckerPtr>(m, "USpoofChecker", R"doc(
    USpoofChecker structure.

    See Also:
        :func:`uspoof_clone`
        :func:`uspoof_close`
        :func:`uspoof_open_from_serialized`
        :func:`uspoof_open_from_source`
        :func:`uspoof_open`
    )doc");

#if (U_ICU_VERSION_MAJOR_NUM >= 58)
  //
  // struct USpoofCheckResult
  //
  py::class_<icupy::USpoofCheckResultPtr>(m, "USpoofCheckResult", R"doc(
    USpoofCheckResult structure.

    See Also:
        :func:`uspoof_open_check_result`
    )doc");
#endif // (U_ICU_VERSION_MAJOR_NUM >= 58)

  //
  // Functions
  //
  m.def(
      "uspoof_are_confusable",
      [](const icupy::USpoofCheckerPtr &sc, const std::u16string &id1,
         int32_t length1, const std::u16string &id2, int32_t length2) {
        ErrorCode error_code;
        auto result = uspoof_areConfusable(sc, id1.data(), length1, id2.data(),
                                           length2, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("id1"), py::arg("length1"), py::arg("id2"),
      py::arg("length2"));

  m.def(
      "uspoof_are_confusable_unicode_string",
      [](const icupy::USpoofCheckerPtr &sc,
         const icupy::UnicodeStringVariant &s1,
         const icupy::UnicodeStringVariant &s2) {
        ErrorCode error_code;
        auto result = uspoof_areConfusableUnicodeString(
            sc, icupy::to_unistr(s1), icupy::to_unistr(s2), error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("s1"), py::arg("s2"));

  m.def(
      "uspoof_are_confusable_utf8",
      [](const icupy::USpoofCheckerPtr &sc, const py::bytes &id1,
         int32_t length1, const py::bytes &id2, int32_t length2) {
        const auto id1_text = id1.cast<std::string>();
        const auto id2_text = id2.cast<std::string>();
        if (length1 == -1) {
          length1 = static_cast<int32_t>(id1_text.size());
        }
        if (length2 == -1) {
          length2 = static_cast<int32_t>(id2_text.size());
        }
        ErrorCode error_code;
        auto result = uspoof_areConfusableUTF8(
            sc, id1_text.data(), length1, id2_text.data(), length2, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("id1"), py::arg("length1"), py::arg("id2"),
      py::arg("length2"));

  m.def(
      "uspoof_check",
      [](const icupy::USpoofCheckerPtr &sc, const std::u16string &id,
         int32_t length) {
        ErrorCode error_code;
        auto result = uspoof_check(sc, id.data(), length, nullptr, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("id"), py::arg("length") = -1);

#if (U_ICU_VERSION_MAJOR_NUM >= 58)
  m.def(
      "uspoof_check2",
      [](const icupy::USpoofCheckerPtr &sc, const std::u16string &id,
         int32_t length,
         std::optional<icupy::USpoofCheckResultPtr> &check_result) {
        ErrorCode error_code;
        auto result = uspoof_check2(sc, id.data(), length,
                                    check_result.value_or(nullptr), error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("id"), py::arg("length") = -1,
      py::arg("check_result") = std::nullopt);

  m.def(
      "uspoof_check2_unicode_string",
      [](const icupy::USpoofCheckerPtr &sc,
         const icupy::UnicodeStringVariant &id,
         std::optional<icupy::USpoofCheckResultPtr> &check_result) {
        ErrorCode error_code;
        auto result = uspoof_check2UnicodeString(sc, icupy::to_unistr(id),
                                                 check_result.value_or(nullptr),
                                                 error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("id"), py::arg("check_result") = std::nullopt);

  m.def(
      "uspoof_check2_utf8",
      [](const icupy::USpoofCheckerPtr &sc, const py::bytes &id, int32_t length,
         std::optional<icupy::USpoofCheckResultPtr> &check_result) {
        const auto id_text = id.cast<std::string>();
        if (length == -1) {
          length = static_cast<int32_t>(id_text.size());
        }
        ErrorCode error_code;
        auto result =
            uspoof_check2UTF8(sc, id_text.data(), length,
                              check_result.value_or(nullptr), error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("id"), py::arg("length") = -1,
      py::arg("check_result") = std::nullopt);
#endif // (U_ICU_VERSION_MAJOR_NUM >= 58)

  m.def(
      "uspoof_check_unicode_string",
      [](const icupy::USpoofCheckerPtr &sc,
         const icupy::UnicodeStringVariant &id) {
        ErrorCode error_code;
        auto result = uspoof_checkUnicodeString(sc, icupy::to_unistr(id),
                                                nullptr, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("id"));

  m.def(
      "uspoof_check_utf8",
      [](const icupy::USpoofCheckerPtr &sc, const py::bytes &id,
         int32_t length) {
        const auto id_text = id.cast<std::string>();
        if (length == -1) {
          length = static_cast<int32_t>(id_text.size());
        }
        ErrorCode error_code;
        auto result =
            uspoof_checkUTF8(sc, id_text.data(), length, nullptr, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("id"), py::arg("length") = -1);

  m.def(
      "uspoof_clone",
      [](const icupy::USpoofCheckerPtr &sc) {
        ErrorCode error_code;
        auto p = uspoof_clone(sc, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return std::make_unique<icupy::USpoofCheckerPtr>(p);
      },
      py::arg("sc"));

  m.def(
      "uspoof_close", [](icupy::USpoofCheckerPtr &sc) { uspoof_close(sc); },
      py::arg("sc"));

#if (U_ICU_VERSION_MAJOR_NUM >= 58)
  m.def(
      "uspoof_close_check_result",
      [](icupy::USpoofCheckResultPtr &check_result) {
        uspoof_closeCheckResult(check_result);
      },
      py::arg("check_result"));
#endif // (U_ICU_VERSION_MAJOR_NUM >= 58)

  m.def(
      "uspoof_get_allowed_chars",
      [](const icupy::USpoofCheckerPtr &sc) {
        ErrorCode error_code;
        auto p = uspoof_getAllowedChars(sc, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return std::make_unique<icupy::ConstUSetPtr>(p);
      },
      py::arg("sc"));

  m.def(
      "uspoof_get_allowed_locales",
      [](const icupy::USpoofCheckerPtr &sc) {
        ErrorCode error_code;
        auto result = uspoof_getAllowedLocales(sc, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"));

  m.def(
      "uspoof_get_allowed_unicode_set",
      [](const icupy::USpoofCheckerPtr &sc) {
        ErrorCode error_code;
        auto result = uspoof_getAllowedUnicodeSet(sc, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::return_value_policy::reference, py::arg("sc"));

#if (U_ICU_VERSION_MAJOR_NUM >= 74)
  m.def(
      "uspoof_are_bidi_confusable",
      [](const icupy::USpoofCheckerPtr &sc, UBiDiDirection direction,
         const std::u16string &id1, int32_t length1, const std::u16string &id2,
         int32_t length2) {
        ErrorCode error_code;
        auto result =
            uspoof_areBidiConfusable(sc, direction, id1.data(), length1,
                                     id2.data(), length2, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("direction"), py::arg("id1"), py::arg("length1"),
      py::arg("id2"), py::arg("length2"));

  m.def(
      "uspoof_are_bidi_confusable_unicode_string",
      [](const icupy::USpoofCheckerPtr &sc, UBiDiDirection direction,
         const icupy::UnicodeStringVariant &s1,
         const icupy::UnicodeStringVariant &s2) {
        ErrorCode error_code;
        auto result = uspoof_areBidiConfusableUnicodeString(
            sc, direction, icupy::to_unistr(s1), icupy::to_unistr(s2),
            error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("direction"), py::arg("s1"), py::arg("s2"));

  m.def(
      "uspoof_are_bidi_confusable_utf8",
      [](const icupy::USpoofCheckerPtr &sc, UBiDiDirection direction,
         const py::bytes &id1, int32_t length1, const py::bytes &id2,
         int32_t length2) {
        const auto id1_text = id1.cast<std::string>();
        const auto id2_text = id2.cast<std::string>();
        if (length1 == -1) {
          length1 = static_cast<int32_t>(id1_text.size());
        }
        if (length2 == -1) {
          length2 = static_cast<int32_t>(id2_text.size());
        }
        ErrorCode error_code;
        auto result = uspoof_areBidiConfusableUTF8(
            sc, direction, id1_text.data(), length1, id2_text.data(), length2,
            error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("direction"), py::arg("id1"), py::arg("length1"),
      py::arg("id2"), py::arg("length2"));

  m.def(
      "uspoof_get_bidi_skeleton",
      [](const icupy::USpoofCheckerPtr &sc, UBiDiDirection direction,
         const std::u16string &id, int32_t length) {
        auto id_data = id.data();
        ErrorCode error_code;
        const auto dest_capacity = uspoof_getBidiSkeleton(
            sc, direction, id_data, length, nullptr, 0, error_code);
        std::u16string dest(dest_capacity, u'\0');
        error_code.reset();
        uspoof_getBidiSkeleton(sc, direction, id_data, length, dest.data(),
                               dest_capacity, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return dest;
      },
      py::arg("sc"), py::arg("direction"), py::arg("id"),
      py::arg("length") = -1);

  m.def(
      "uspoof_get_bidi_skeleton_unicode_string",
      [](const icupy::USpoofCheckerPtr &sc, UBiDiDirection direction,
         const icupy::UnicodeStringVariant &id,
         UnicodeString &dest) -> UnicodeString & {
        ErrorCode error_code;
        auto &result = uspoof_getBidiSkeletonUnicodeString(
            sc, direction, icupy::to_unistr(id), dest, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("direction"), py::arg("id"), py::arg("dest"));

  m.def(
      "uspoof_get_bidi_skeleton_utf8",
      [](const icupy::USpoofCheckerPtr &sc, UBiDiDirection direction,
         const py::bytes &id, int32_t length) {
        const auto id_text = id.cast<std::string>();
        if (length == -1) {
          length = static_cast<int32_t>(id_text.size());
        }
        auto id_data = id_text.data();
        ErrorCode error_code;
        const auto dest_capacity = uspoof_getBidiSkeletonUTF8(
            sc, direction, id_data, length, nullptr, 0, error_code);
        std::string dest(dest_capacity, '\0');
        error_code.reset();
        uspoof_getBidiSkeletonUTF8(sc, direction, id_data, length, dest.data(),
                                   dest_capacity, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return py::bytes(dest);
      },
      py::arg("sc"), py::arg("direction"), py::arg("id"),
      py::arg("length") = -1);
#endif // (U_ICU_VERSION_MAJOR_NUM >= 74)

#if (U_ICU_VERSION_MAJOR_NUM >= 58)
  m.def(
      "uspoof_get_check_result_checks",
      [](const icupy::USpoofCheckResultPtr &check_result) {
        ErrorCode error_code;
        auto result = uspoof_getCheckResultChecks(check_result, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("check_result"));

  m.def(
      "uspoof_get_check_result_numerics",
      [](const icupy::USpoofCheckResultPtr &check_result) {
        ErrorCode error_code;
        auto p = uspoof_getCheckResultNumerics(check_result, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return std::make_unique<icupy::ConstUSetPtr>(p);
      },
      py::arg("check_result"));

  m.def(
      "uspoof_get_check_result_restriction_level",
      [](const icupy::USpoofCheckResultPtr &check_result) {
        ErrorCode error_code;
        auto result =
            uspoof_getCheckResultRestrictionLevel(check_result, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("check_result"));
#endif // (U_ICU_VERSION_MAJOR_NUM >= 58)

  m.def(
      "uspoof_get_checks",
      [](const icupy::USpoofCheckerPtr &sc) {
        ErrorCode error_code;
        auto result = uspoof_getChecks(sc, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"));

#if (U_ICU_VERSION_MAJOR_NUM >= 51)
  m.def("uspoof_get_inclusion_set", []() {
    ErrorCode error_code;
    auto p = uspoof_getInclusionSet(error_code);
    if (error_code.isFailure()) {
      throw icupy::ICUError(error_code);
    }
    return std::make_unique<icupy::ConstUSetPtr>(p);
  });

  m.def(
      "uspoof_get_inclusion_unicode_set",
      []() {
        ErrorCode error_code;
        auto result = uspoof_getInclusionUnicodeSet(error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::return_value_policy::reference);

  m.def("uspoof_get_recommended_set", []() {
    ErrorCode error_code;
    auto p = uspoof_getRecommendedSet(error_code);
    if (error_code.isFailure()) {
      throw icupy::ICUError(error_code);
    }
    return std::make_unique<icupy::ConstUSetPtr>(p);
  });

  m.def(
      "uspoof_get_recommended_unicode_set",
      []() {
        ErrorCode error_code;
        auto result = uspoof_getRecommendedUnicodeSet(error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::return_value_policy::reference);

  m.def(
      "uspoof_get_restriction_level",
      [](const icupy::USpoofCheckerPtr &sc) {
        return uspoof_getRestrictionLevel(sc);
      },
      py::arg("sc"));
#endif // (U_ICU_VERSION_MAJOR_NUM >= 51)

  m.def(
      "uspoof_get_skeleton",
      [](const icupy::USpoofCheckerPtr &sc, uint32_t type,
         const std::u16string &id, int32_t length) {
        auto id_data = id.data();
        ErrorCode error_code;
        const auto dest_capacity = uspoof_getSkeleton(sc, type, id_data, length,
                                                      nullptr, 0, error_code);
        std::u16string result(dest_capacity, u'\0');
        error_code.reset();
        uspoof_getSkeleton(sc, type, id_data, length, result.data(),
                           dest_capacity, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("type"), py::arg("id"), py::arg("length") = -1);

  m.def(
      "uspoof_get_skeleton_unicode_string",
      [](const icupy::USpoofCheckerPtr &sc, uint32_t type,
         const icupy::UnicodeStringVariant &id,
         UnicodeString &dest) -> UnicodeString & {
        ErrorCode error_code;
        auto &result = uspoof_getSkeletonUnicodeString(
            sc, type, icupy::to_unistr(id), dest, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return result;
      },
      py::arg("sc"), py::arg("type"), py::arg("id"), py::arg("dest"));

  m.def(
      "uspoof_get_skeleton_utf8",
      [](const icupy::USpoofCheckerPtr &sc, uint32_t type, const py::bytes &id,
         int32_t length) {
        const auto id_text = id.cast<std::string>();
        if (length == -1) {
          length = static_cast<int32_t>(id_text.size());
        }
        auto id_data = id_text.data();
        ErrorCode error_code;
        const auto dest_capacity = uspoof_getSkeletonUTF8(
            sc, type, id_data, length, nullptr, 0, error_code);
        std::string dest(dest_capacity, '\0');
        error_code.reset();
        uspoof_getSkeletonUTF8(sc, type, id_data, length, dest.data(),
                               dest_capacity, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return py::bytes(dest);
      },
      py::arg("sc"), py::arg("type"), py::arg("id"), py::arg("length") = -1);

  m.def("uspoof_open", []() {
    ErrorCode error_code;
    auto sc = uspoof_open(error_code);
    if (error_code.isFailure()) {
      throw icupy::ICUError(error_code);
    }
    return std::make_unique<icupy::USpoofCheckerPtr>(sc);
  });

  m.def("uspoof_open_check_result", []() {
    ErrorCode error_code;
    auto p = uspoof_openCheckResult(error_code);
    if (error_code.isFailure()) {
      throw icupy::ICUError(error_code);
    }
    return std::make_unique<icupy::USpoofCheckResultPtr>(p);
  });

  m.def(
      "uspoof_open_from_serialized",
      [](const py::buffer &data, int32_t length) {
        auto info = data.request();
        if (length == -1) {
          length = static_cast<int32_t>(info.size);
        }
        ErrorCode error_code;
        auto p =
            uspoof_openFromSerialized(info.ptr, length, nullptr, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return std::make_unique<icupy::USpoofCheckerPtr>(p);
      },
      py::arg("data"), py::arg("length") = -1);

  m.def(
      "uspoof_open_from_source",
      [](const py::bytes &confusables, int32_t confusables_len,
         const std::optional<py::bytes> &confusables_whole_script,
         int32_t confusables_whole_script_len,
         std::optional<UParseError *> &pe) {
        const auto confusables_text = confusables.cast<std::string>();
        const auto confusables_whole_script_text =
            confusables_whole_script
                ? confusables_whole_script->cast<std::string>()
                : std::string();
        if (confusables_len == -1) {
          confusables_len = confusables_text.size();
        }
        if (confusables_whole_script && confusables_whole_script_len == -1) {
          confusables_whole_script_len = confusables_whole_script_text.size();
        }
        int32_t err_type;
        ErrorCode error_code;
        auto p = uspoof_openFromSource(
            confusables_text.data(), confusables_len,
            confusables_whole_script ? confusables_whole_script_text.data()
                                     : nullptr,
            confusables_whole_script_len, &err_type, pe.value_or(nullptr),
            error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        // return py::make_tuple(std::make_unique<_USpoofCheckerPtr>(p),
        // err_type);
        return std::make_unique<icupy::USpoofCheckerPtr>(p);
      },
      py::arg("confusables"), py::arg("confusables_len") = -1,
      py::arg("confusables_whole_script") = std::nullopt,
      py::arg("confusables_whole_script_len") = 0,
      py::arg("pe") = std::nullopt);

  m.def(
      "uspoof_serialize",
      [](icupy::USpoofCheckerPtr &sc) {
        ErrorCode error_code;
        auto dest_size = uspoof_serialize(sc, nullptr, 0, error_code);
        std::string data(dest_size, '\0');
        error_code.reset();
        uspoof_serialize(sc, data.data(), dest_size, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
        return py::bytes(data);
      },
      py::arg("sc"));

  m.def(
       "uspoof_set_allowed_chars",
       [](icupy::USpoofCheckerPtr &sc, icupy::ConstUSetPtr &chars) {
         ErrorCode error_code;
         uspoof_setAllowedChars(sc, chars, error_code);
         if (error_code.isFailure()) {
           throw icupy::ICUError(error_code);
         }
       },
       py::arg("sc"), py::arg("chars"))
      .def(
          "uspoof_set_allowed_chars",
          [](icupy::USpoofCheckerPtr &sc, const icupy::USetPtr &chars) {
            ErrorCode error_code;
            uspoof_setAllowedChars(sc, chars, error_code);
            if (error_code.isFailure()) {
              throw icupy::ICUError(error_code);
            }
          },
          py::arg("sc"), py::arg("chars"));

  m.def(
      "uspoof_set_allowed_locales",
      [](icupy::USpoofCheckerPtr &sc, const std::string &locales_list) {
        ErrorCode error_code;
        uspoof_setAllowedLocales(sc, locales_list.data(), error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
      },
      py::arg("sc"), py::arg("locales_list"));

  m.def(
      "uspoof_set_allowed_unicode_set",
      [](icupy::USpoofCheckerPtr &sc, const UnicodeSet *chars) {
        ErrorCode error_code;
        uspoof_setAllowedUnicodeSet(sc, chars, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
      },
      py::arg("sc"), py::arg("chars").none(false));

  m.def(
      "uspoof_set_checks",
      [](icupy::USpoofCheckerPtr &sc, int32_t checks) {
        ErrorCode error_code;
        uspoof_setChecks(sc, checks, error_code);
        if (error_code.isFailure()) {
          throw icupy::ICUError(error_code);
        }
      },
      py::arg("sc"), py::arg("checks"));

#if (U_ICU_VERSION_MAJOR_NUM >= 51)
  m.def(
      "uspoof_set_restriction_level",
      [](icupy::USpoofCheckerPtr &sc, URestrictionLevel restriction_level) {
        uspoof_setRestrictionLevel(sc, restriction_level);
      },
      py::arg("sc"), py::arg("restriction_level"));
#endif // (U_ICU_VERSION_MAJOR_NUM >= 51)
}
