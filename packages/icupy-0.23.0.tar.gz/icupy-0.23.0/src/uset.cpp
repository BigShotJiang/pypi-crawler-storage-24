#include "main.hpp"
#include "usetptr.hpp"

namespace icupy {

//
// const USet structure
//
ConstUSetPtr::ConstUSetPtr(const USet *p) : p_(p) {}

ConstUSetPtr::~ConstUSetPtr() {}

const USet *ConstUSetPtr::get() const { return p_; }

//
// USet structure
//
USetPtr::USetPtr(USet *p) : p_(p) {}

USetPtr::~USetPtr() {}

USet *USetPtr::get() const { return p_; }

} // namespace icupy

void init_uset(py::module &m) {
  //
  // enum USetSpanCondition
  //
  py::enum_<USetSpanCondition>(m, "USetSpanCondition", py::arithmetic(), R"doc(
Argument values for whether :meth:`UnicodeSet.span` and similar functions
continue while the current character is contained vs. not contained in the set.

The functionality is straightforward for sets with only single code points,
without strings (which is the common case):

- :attr:`USET_SPAN_CONTAINED` and :attr:`USET_SPAN_SIMPLE` work the same.
- :attr:`USET_SPAN_CONTAINED` and :attr:`USET_SPAN_SIMPLE` are inverses of
  :attr:`USET_SPAN_NOT_CONTAINED`.
- :meth:`UnicodeSet.span` and :meth:`UnicodeSet.span_back` partition any
  string the same way when alternating between
  span(USET_SPAN_NOT_CONTAINED) and span(either "contained" condition).
- Using a complemented (inverted) set and the opposite span conditions yields
  the same results.

When a set contains multi-code point strings, then these statements may not be
true, depending on the strings in the set (for example, whether they overlap
with each other) and the string that is processed. For a set with strings:

- The complement of the set contains the opposite set of code points, but the
  same set of strings. Therefore, complementing both the set and the span
  conditions may yield different results.
- When starting spans at different positions in a string (span(s, ...)
  vs. span(s[1:], ...)) the ends of the spans may be different because a set
  string may start before the later position.
- span(USET_SPAN_SIMPLE) may be shorter than span(USET_SPAN_CONTAINED)
  because it will not recursively try all possible paths. For example, with a
  set which contains the three strings "xy", "xya" and "ax",
  span("xyax", USET_SPAN_CONTAINED) will return 4 but span("xyax",
  USET_SPAN_SIMPLE) will return 3.
  span(USET_SPAN_SIMPLE) will never be longer than span(USET_SPAN_CONTAINED).
- With either "contained" condition, :meth:`UnicodeSet.span` and
  :meth:`UnicodeSet.span_back` may partition a string in different ways. For
  example, with a set which contains the two strings "ab" and "ba", and when
  processing the string "aba", :meth:`UnicodeSet.span` will yield
  contained/not-contained boundaries of { 0, 2, 3 } while
  :meth:`UnicodeSet.span_back` will yield boundaries of { 0, 1, 3 }.

.. note::

    If it is important to get the same boundaries whether iterating forward
    or backward through a string, then either only :meth:`UnicodeSet.span`
    should be used and the boundaries cached for backward operation, or an ICU
    :class:`BreakIterator` could be used.

.. note::

    Unpaired surrogates are treated like surrogate code points. Similarly, set
    strings match only on code point boundaries, never in the middle of a
    surrogate pair. Illegal UTF-8 sequences are treated like U+FFFD. When
    processing UTF-8 strings, malformed set strings (strings with unpaired
    surrogates which cannot be converted to UTF-8) are ignored.
      )doc")
      .value("USET_SPAN_NOT_CONTAINED", USET_SPAN_NOT_CONTAINED, R"doc(
             Continues a :meth:`UnicodeSet.span` while there is no set element
             at the current position.

             Increments by one code point at a time. Stops before the first set
             element (character or string). (For code points only).

             When :meth:`UnicodeSet.span` returns, the substring between where
             it started and the position it returned consists only of
             characters that are not in the set, and none of its strings
             overlap with the span.
             )doc")
      .value("USET_SPAN_CONTAINED", USET_SPAN_CONTAINED, R"doc(
             Spans the longest substring that is a concatenation of set
             elements (characters or strings).

             (For characters only).

             When :meth:`UnicodeSet.span` returns, the substring between where
             it started and the position it returned consists only of set
             elements (characters or strings) that are in the set.

             If a set contains strings, then the span will be the longest
             substring for which there exists at least one non-overlapping
             concatenation of set elements (characters or strings). This is
             equivalent to a POSIX regular expression for ``(OR of each set
             element)*``. (Java/ICU/Perl regex stops at the first match of an
             OR.)
             )doc")
      .value("USET_SPAN_SIMPLE", USET_SPAN_SIMPLE, R"doc(
             Continues a :meth:`UnicodeSet.span` while there is a set element
             at the current position.

             Increments by the longest matching element at each position. (For
             characters only).

             When :meth:`UnicodeSet.span` returns, the substring between where
             it started and the position it returned consists only of set
             elements (characters or strings) that are in the set.

             If a set only contains single characters, then this is the same as
             :attr:`USET_SPAN_CONTAINED`.

             If a set contains strings, then the span will be the longest
             substring with a match at each position with the longest single
             set element (character or string).

             Use this span condition together with other longest-match
             algorithms, such as ICU converters (:func:`ucnv_get_unicode_set`).
             )doc")
      .value("USET_SPAN_CONDITION_COUNT", USET_SPAN_CONDITION_COUNT, R"doc(
             Deprecated: ICU 58 The numeric value may change over time,
             see ICU ticket #12420.
             )doc")
      .export_values();

  //
  // const struct USet
  //
  py::class_<icupy::ConstUSetPtr>(m, "ImmutableUSet", R"doc(
    Immutable USet structure.

    See Also:
        :class:`USet`
        :func:`u_get_binary_property_set`
        :func:`uspoof_get_allowed_chars`
        :func:`uspoof_get_check_result_numerics`
        :func:`uspoof_get_inclusion_set`
        :func:`uspoof_get_recommended_set`
        :meth:`UnicodeSet.from_uset`
    )doc");

  //
  // struct USet
  //
  py::class_<icupy::USetPtr>(m, "USet", R"doc(
    USet structure.

    See Also:
        :class:`ImmutableUSet`
        :func:`ucnv_get_unicode_set`
        :func:`ulocdata_get_exemplar_set`
        :meth:`UnicodeSet.from_uset`
        :meth:`UnicodeSet.to_uset`
    )doc");

  //
  // struct USerializedSet
  //
  py::class_<USerializedSet>(m, "USerializedSet").def(py::init<>());

  m.attr("USET_IGNORE_SPACE") = int32_t{USET_IGNORE_SPACE};
  m.attr("USET_CASE_INSENSITIVE") = int32_t{USET_CASE_INSENSITIVE};
  m.attr("USET_ADD_CASE_MAPPINGS") = int32_t{USET_ADD_CASE_MAPPINGS};
#if (U_ICU_VERSION_MAJOR_NUM >= 73)
  m.attr("USET_SIMPLE_CASE_INSENSITIVE") =
      int32_t{USET_SIMPLE_CASE_INSENSITIVE};
#endif // (U_ICU_VERSION_MAJOR_NUM >= 73)

  m.attr("USET_SERIALIZED_STATIC_ARRAY_CAPACITY") =
      int32_t{USET_SERIALIZED_STATIC_ARRAY_CAPACITY};
}
