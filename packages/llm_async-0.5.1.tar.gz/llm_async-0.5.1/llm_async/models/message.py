from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Literal

from llm_async.models.tool_call import ToolCall

Role = Literal["system", "user", "assistant", "tool"]
Content = str | list[dict[str, Any]]
_ALLOWED_ROLES: tuple[Role, ...] = ("system", "user", "assistant", "tool")


@dataclass
class Message:
    """Represents a single chat message.

    The preferred way to build messages for ``acomplete``. Accepts plain dicts
    as well, but using ``Message`` provides role validation and type safety.

    Example::

        from llm_async.models.message import Message

        messages = [
            Message("system", "You are a helpful assistant."),
            Message("user", "Hello, how are you?"),
        ]

    Args:
        role: One of ``"system"``, ``"user"``, ``"assistant"``, ``"tool"``.
        content: Text content or a list of content parts (for multimodal).
        tool_calls: Optional list of tool calls attached to this message.
        original: Raw provider payload, used internally when round-tripping responses.
    """

    role: Role
    content: Content
    tool_calls: list[ToolCall] | None = None
    reasoning: str | None = None
    reasoning_details: list[dict[str, Any] | str] | None = None
    stop_reason: str | None = None
    original: dict[str, Any] | None = field(default=None)


def normalize_messages(messages: Sequence[Message | Mapping[str, Any]]) -> list[Message]:
    normalized: list[Message] = []
    for message in messages:
        if isinstance(message, Message):
            normalized.append(message)
            continue
        if not isinstance(message, Mapping):
            raise TypeError("Message entries must be Message or mapping")
        role = message.get("role")
        if role not in _ALLOWED_ROLES:
            raise ValueError("Invalid role provided in message")
        content: Any
        if "content" in message:
            content = message.get("content")
        elif "parts" in message:
            content = message.get("parts")
        else:
            content = ""
        if content is None:
            content_value = ""
        elif isinstance(content, list):
            if not all(isinstance(part, Mapping) for part in content):
                raise TypeError("List content must contain mapping entries")
            content_value = [dict(part) for part in content]
        elif isinstance(content, str):
            content_value = content
        else:
            raise TypeError("Content must be str or list of mappings")
        tool_calls = _coerce_tool_calls(message.get("tool_calls"))
        reasoning = message.get("reasoning")
        if reasoning is not None and not isinstance(reasoning, str):
            raise TypeError("reasoning must be a string when provided")
        reasoning_details = _coerce_reasoning_details(message.get("reasoning_details"))
        original_payload: dict[str, Any] | None = dict(message)
        inner_original = original_payload.pop("original", None)
        if isinstance(inner_original, Mapping):
            original_payload = dict(inner_original)
        normalized.append(
            Message(
                role=role,
                content=content_value,
                tool_calls=tool_calls,
                reasoning=reasoning,
                reasoning_details=reasoning_details,
                original=original_payload,
            )
        )
    return normalized


def validate_messages(messages: Sequence[Message]) -> None:
    for message in messages:
        if message.role not in _ALLOWED_ROLES:
            raise ValueError("Invalid role on Message instance")
        if not isinstance(message.content, (str, list)):
            raise TypeError("Message content must be str or list")
        if isinstance(message.content, list):
            if not all(isinstance(part, Mapping) for part in message.content):
                raise TypeError("List content entries must be mappings")
        if message.tool_calls is not None and not isinstance(message.tool_calls, list):
            raise TypeError("tool_calls must be a list when provided")
        if message.tool_calls:
            if not all(isinstance(tc, ToolCall) for tc in message.tool_calls):
                raise TypeError("tool_calls entries must be ToolCall instances")
        if message.reasoning is not None and not isinstance(message.reasoning, str):
            raise TypeError("reasoning must be a string when provided")
        if message.reasoning_details is not None:
            if not isinstance(message.reasoning_details, list):
                raise TypeError("reasoning_details must be a list when provided")
            if not all(isinstance(item, (Mapping, str)) for item in message.reasoning_details):
                raise TypeError("reasoning_details entries must be mappings or strings")


def _coerce_reasoning_details(value: Any) -> list[dict[str, Any] | str] | None:
    if value is None:
        return None
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise TypeError("reasoning_details must be a list when provided")
    details: list[dict[str, Any] | str] = []
    for entry in value:
        if isinstance(entry, Mapping):
            details.append(dict(entry))
        elif isinstance(entry, str):
            details.append(entry)
        else:
            raise TypeError("reasoning_details entries must be mappings or strings")
    return details or None


def _coerce_tool_calls(value: Any) -> list[ToolCall] | None:
    if value is None:
        return None
    if isinstance(value, ToolCall):
        return [value]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        calls: list[ToolCall] = []
        for entry in value:
            if isinstance(entry, ToolCall):
                calls.append(entry)
                continue
            if not isinstance(entry, Mapping):
                raise TypeError("tool_calls entries must be mappings or ToolCall")
            calls.append(
                ToolCall(
                    id=str(entry.get("id", "")),
                    type=str(entry.get("type", "")),
                    name=entry.get("name"),
                    input=entry.get("input"),
                    function=entry.get("function"),
                )
            )
        return calls or None
    raise TypeError("tool_calls must be a sequence, ToolCall, or None")


def message_to_dict(message: Message) -> dict[str, Any]:
    if isinstance(message.original, Mapping) and ("content" in message.original or "parts" in message.original):
        payload = dict(message.original)
    else:
        payload = {"role": message.role}
        if isinstance(message.content, list):
            payload["content"] = [dict(part) for part in message.content]
        else:
            payload["content"] = message.content

    if message.tool_calls is not None:
        payload["tool_calls"] = [_tool_call_to_dict(tc) for tc in message.tool_calls]
    else:
        payload.pop("tool_calls", None)
    if message.reasoning is not None:
        payload["reasoning"] = message.reasoning
    if message.reasoning_details is not None:
        payload["reasoning_details"] = [
            dict(item) if isinstance(item, Mapping) else item for item in message.reasoning_details
        ]
    return payload


def _tool_call_to_dict(tool_call: ToolCall) -> dict[str, Any]:
    data: dict[str, Any] = {
        "id": tool_call.id,
        "type": tool_call.type,
    }
    if tool_call.name is not None:
        data["name"] = tool_call.name
    if tool_call.input is not None:
        data["input"] = tool_call.input
    if tool_call.function is not None:
        data["function"] = tool_call.function
    return data
