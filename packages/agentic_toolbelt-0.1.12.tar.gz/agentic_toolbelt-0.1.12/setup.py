from fnmatch import fnmatch
from pathlib import Path
import tomllib

from setuptools import find_packages, setup


PACKAGE_DIR = Path(__file__).parent / "agentic_toolbelt"
PYPROJECT_FILE = Path(__file__).parent / "pyproject.toml"
PAYLOAD_ROOTS = (".agents", ".codex", ".github", "templates", "AGENTS.md")
EXCLUDED_PATTERNS = ("__pycache__/*", "*.pyc", "*.pyo")


def _package_version():
    with PYPROJECT_FILE.open("rb") as fh:
        return tomllib.load(fh)["project"]["version"]


def _data_files():
    files = []
    for root_name in PAYLOAD_ROOTS:
        root_path = PACKAGE_DIR / root_name
        if root_path.is_file():
            rel_path = root_path.relative_to(PACKAGE_DIR)
            files.append(str(rel_path))
            continue

        for path in sorted(root_path.rglob("*")):
            if not path.is_file():
                continue

            rel_path = path.relative_to(PACKAGE_DIR)
            rel_path_str = str(rel_path)
            if any(fnmatch(rel_path_str, pattern) for pattern in EXCLUDED_PATTERNS):
                continue

            files.append(rel_path_str)
    return files


def main():
    setup(
        name="agentic-toolbelt",
        version=_package_version(),
        description="Installs this folder's AGENTS and .codex/.agents content as package data.",
        packages=find_packages(),
        include_package_data=True,
        package_data={"agentic_toolbelt": _data_files()},
        entry_points={
            "console_scripts": [
                "agentic-set=agentic_toolbelt.cli:main",
            ]
        },
    )


if __name__ == "__main__":
    main()
