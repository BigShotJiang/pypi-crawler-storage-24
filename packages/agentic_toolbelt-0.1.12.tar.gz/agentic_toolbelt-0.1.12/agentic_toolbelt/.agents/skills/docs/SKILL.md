---
name: docs
description: Update documentation, examples, changelog, and migration notes so they match the code and user-facing behavior. Use for docs-only tasks or when implementation changes public behavior. Do not use for code-only work with no documentation impact.
---
## Use when
- the task is docs-only
- examples, onboarding, or config docs need updates
- code changed in a way users will notice

## Do not use when
- the change is internal-only and has no documentation impact
- the task is purely code implementation

## Inputs
- user-visible behavior
- changed commands, flags, config, or examples
- repo docs build or validation commands if they exist

## Outputs
- docs updated
- examples aligned with current behavior
- docs validation run or explicitly skipped
- memory record updated with docs scope and outcome

## Success criteria
- docs match the shipped behavior
- examples are runnable or clearly accurate
- the handoff states any docs gaps that remain

## Routing
Calling this skill means execute this agent chain in order:
1. coordinator records the docs scope in memory
2. spawn `docs-writer`
3. pass the result to `reviewer`
4. coordinator records the docs result in memory

Do not emulate this chain in one thread. If either subagent cannot be spawned, stop and report the skill as blocked.
This skill is sequential because the review depends on the documentation diff.
