---
name: plan
description: Create a concise execution plan for non-trivial work and start with read-only discovery. Use when the blast radius is unclear, the task crosses files or layers, or sequencing matters. Do not use for trivial one-file edits or formatting-only changes.
---
## Use when
- the task touches multiple files, packages, or layers
- the blast radius is unclear
- you need explicit invariants, sequencing, or validation planning
- you are working in an unfamiliar part of the repo

## Do not use when
- the task is a trivial one-file fix
- the request is docs-only and low risk
- the implementation is already obvious and self-contained

## Inputs
- user goal
- affected files or subsystems
- repository command surface from CI, manifests, or local docs

## Outputs
- goal
- affected files and contracts
- ordered execution steps
- validation plan
- key risks or blockers
- recommended specialist route
- memory manifest initialized for downstream stages

## Success criteria
- the plan is short, executable, and scoped to the actual request
- invariants and risky boundaries are explicit
- the next write-capable agent can act without rediscovery

## Routing
Calling this skill means execute this agent chain in order:
1. coordinator initializes `.agent-memory/manifest.json`
2. spawn `planner`
3. pass the planner output to `architecture-reviewer`
4. coordinator records the approved plan summary and recommended scopes in memory

Do not emulate this chain in one thread. If either subagent cannot be spawned, stop and report the skill as blocked.
This skill is sequential because the architecture review depends on the planner output.
If the task needs full delivery after planning, hand off from this skill to `implement`.
