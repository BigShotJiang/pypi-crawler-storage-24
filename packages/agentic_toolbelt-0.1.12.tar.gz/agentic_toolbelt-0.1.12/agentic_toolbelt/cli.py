"""CLI entrypoints for installing packaged agentic assets."""

from __future__ import annotations

import shutil
import sys
from importlib import resources
from importlib.resources import as_file
from pathlib import Path
from tempfile import TemporaryDirectory

import agentic_toolbelt

PAYLOAD_DIR_ITEMS = (".agents", ".codex", ".github", "templates")
DEFAULT_AGENTS_TEMPLATE = "AGENTS.md"
TARGET_AGENTS_NAME = "AGENTS.md"


def copy_payload(
    destination: Path,
    force: bool = False,
    agents_template: str = DEFAULT_AGENTS_TEMPLATE,
) -> tuple[list[str], list[str]]:
    """Copy packaged payload items to ``destination``.

    Returns two lists: copied item names and skipped item names.
    """

    copied: list[str] = []
    skipped: list[str] = []

    payload_items = [(item, item) for item in PAYLOAD_DIR_ITEMS]
    payload_items.append((agents_template, TARGET_AGENTS_NAME))

    with TemporaryDirectory(prefix="agentic-set-", dir=destination) as temp_root_str:
        temp_root = Path(temp_root_str)
        with as_file(resources.files(agentic_toolbelt)) as source_root:
            for source_name, destination_name in payload_items:
                source_path = source_root / source_name
                if not source_path.exists():
                    raise FileNotFoundError(f"Missing packaged payload item: {source_name}")

                destination_path = destination / destination_name
                if destination_path.exists():
                    if not force:
                        skipped.append(destination_name)
                        continue

                    if destination_path.is_dir() and not destination_path.is_symlink():
                        shutil.rmtree(destination_path)
                    else:
                        destination_path.unlink()

                if source_path.is_dir():
                    temp_path = temp_root / destination_name
                    if temp_path.exists():
                        shutil.rmtree(temp_path)
                    temp_path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copytree(source_path, temp_path)
                    temp_path.replace(destination_path)
                else:
                    destination_path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source_path, destination_path)

                copied.append(destination_name)

    return copied, skipped


def build_parser(prog: str, description: str) -> "argparse.ArgumentParser":
    import argparse

    parser = argparse.ArgumentParser(
        prog=prog,
        description=description,
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing files/directories if they already exist.",
    )
    return parser


def run_cli(
    argv: list[str] | None,
    *,
    prog: str,
    description: str,
    agents_template: str,
) -> int:
    parser = build_parser(prog=prog, description=description)
    args = parser.parse_args(argv)
    destination = Path.cwd()
    destination.mkdir(parents=True, exist_ok=True)

    try:
        copied, skipped = copy_payload(
            destination,
            force=args.force,
            agents_template=agents_template,
        )
    except Exception as exc:  # pragma: no cover - exercised via CLI behavior
        print(f"{prog}: {exc}", file=sys.stderr)
        return 1

    for item in copied:
        print(f"copied {item} -> {destination / item}")
    for item in skipped:
        print(f"skipped {item} (already exists; use --force to overwrite)")

    return 0


def main(argv: list[str] | None = None) -> int:
    return run_cli(
        argv,
        prog="agentic-set",
        description="Copy packaged .agents/.codex/AGENTS.md into a directory.",
        agents_template=DEFAULT_AGENTS_TEMPLATE,
    )


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
