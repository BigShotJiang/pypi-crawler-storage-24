# Agentic Toolbelt

**Author:** Roberto Del Prete

## Purpose

`agentic-toolbelt` packages reproducible agent-operating defaults and installs them into any project with a CLI.

The installer payload includes:

- `.agents`
- `.codex`
- `AGENTS.md`

The repository exists to standardize how autonomous agents are configured, launched, and governed across different codebases.

## Features

- CLI entrypoints:
  - `agentic-set`: installs the packaged `AGENTS.md` prompt
- Copies packaged payload directly into the directory where the command is launched
- Supports `--force` to overwrite existing `.agents`, `.codex`, and `AGENTS.md`
- Safe copy flow with temporary staging and cleanup

## Installation

From the repository root:

```bash
uv pip install -e . --python /path/to/venv/bin/python
```

This registers the `agentic-set` console script in that virtual environment.

## Usage

From any project directory, install the default baseline:

```bash
agentic-set
```

Force overwrite when files already exist:

```bash
agentic-set --force
```

## Docs Site

A graphical overview page is available at:

- `docs/index.html`

Open it in a browser to view the repo concept, architecture, and CLI workflows.

## Development

- Python package entrypoint is also declared in `setup.py` and `pyproject.toml`.
- Current package version is maintained in both `pyproject.toml` and `setup.py`.
