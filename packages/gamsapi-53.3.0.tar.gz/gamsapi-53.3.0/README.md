<div align="center">
  <img src="https://www.gams.com/img/gams_logo.svg"><br>
</div>

-----------------

# gamsapi: powerful Python toolkit to manage GAMS (i.e., sparse) data and control GAMS solves

## What is it?

**gamsapi** is a Python package that includes submodules to control GAMS, manipulate and
transfer data to/from the GAMS modeling system (through GDX files or in-memory objects).
This functionality is available from a variety of different Python interfaces including
standard Python scripts and Jupyter Notebooks. We strive to make it as **simple** as
possible for users to generate, debug, customize, and ultimately use data to solve
optimization problems -- all while maintaining high performance.


## Main Features
Here are just a few of the things that **gamsapi** does well:

  - Seamlessly integrates GAMS data requirements into standard data pipelines (i.e., Pandas, Numpy)
  - Link and harmonize data sets across different symbols
  - Clean/debug data **before** it enters the modeling environment
  - Customize the look and feel of the data (i.e., labeling conventions)
  - Bring data to GAMS from a variety of different starting points
  - Send model output to a variety of different data endpoints (SQL, CSV, Excel, etc.)
  - Automatic data reshaping and standardization -- will work to translate your data formats into the Pandas DataFrame standard
  - Control GAMS model solves and model specification

## Where to get it
The source code is currently available with any typical [GAMS system](https://www.gams.com/download/).
No license is needed in order to use **gamsapi**.  A license is necessary in order to solve GAMS models.

GAMS has a robust [Academic Program](https://gams.com/academics/) that includes a full-featured [GAMSPy](https://gams.com/sales/gamspy_facts/) License (w/ commercial solvers -- no model size limitations)!

## Dependencies
Installing **gamsapi** will not install any third-party dependencies, as such, it only contains basic functionality.
Users should modify this base installation by choosing **extras** to install -- extras are described in the [documentation](https://www.gams.com/latest/docs/API_PY_GETTING_STARTED.html#PY_PIP_INSTALL_BDIST).

```sh
# from PyPI (with extra "transfer")
pip install gamsapi[transfer]
```

```sh
# from PyPI (with extras "transfer" and "magic")
pip install gamsapi[transfer,magic]
```

```sh
# from PyPI (include all dependencies)
pip install gamsapi[all]
```

## Documentation
The official documentation is hosted on [gams.com](https://www.gams.com/latest/docs/API_PY_GETTING_STARTED.html).

## Getting Help

For usage questions, the best place to go to is [GAMS](https://www.gams.com/latest/docs/API_PY_GETTING_STARTED.html).
General questions and discussions can also take place on the [GAMS World Forum](https://forum.gamsworld.org).

## Discussion and Development
If you have a design request or concern, please write to support@gams.com.