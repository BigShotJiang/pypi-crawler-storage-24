# DBX ELT Utilities

Librería de utilidades para simplificar la creación de iteraciones y flujos **Delta Live Tables (DLT)** en Databricks.

## Instalación

Instala este paquete usando `pip`:

```bash
pip install dbx-elt-utils
```

### Para desarrollo local (VS Code)
Si quieres desarrollar localmente simulando DLT y consumiendo datos desde Databricks Connect:

```bash
pip install dbx-elt-utils[local]
```

## Uso en Pipelines / Notebooks

En tus notebooks en vez de configurar el `sys.path`, simplemente importa el módulo base:

```python
from dbx_elt_utils.notebook_utils import init_notebook

# Esto detectará si estás en Databricks o local automáticamente
notebook = init_notebook()
env = notebook.env
spark = notebook.spark
dlt = notebook.dlt
```

## Módulos Disponibles
- `ingest_utils`: Gestión transparente entre batch/streaming vía `ingesta_hibrida`.
- `notebook_utils`: Setup mágico del entorno de ejecución (Mock para DLT local).
- `clean_utils`: Utilidades puras de pyspark para limpieza de arreglos y strings.
