"""
collab_memory.scripts.ingest — CLI entrypoint for `collab-memory-ingest`.

Ingest conversation exports or adapter-compatible files into the memory graph.

Usage:
    collab-memory-ingest chatgpt export.json
    collab-memory-ingest claude export.json
    collab-memory-ingest linear                        # requires LINEAR_API_KEY
    collab-memory-ingest manus --list                  # requires MANUS_API_KEY
    collab-memory-ingest manus --task-id <id>
    collab-memory-ingest manus --all                   # ingest all completed tasks
    collab-memory-ingest raw session.log               # one turn per line

All sources append to the same graph. Existing nodes are not duplicated.

Environment:
    LOCAL_GRAPH_PATH   — graph JSON path (default ./data/memory.json)
    ANTHROPIC_API_KEY  — enables LLM classification
    OPENAI_API_KEY     — alternative LLM
    MANUS_API_KEY      — required for manus source
    LINEAR_API_KEY     — required for linear source
"""

from __future__ import annotations

import argparse
import os
import sys


def main():
    parser = argparse.ArgumentParser(
        description="collab-memory-ingest — import conversations into your memory graph",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Sources:
  chatgpt <file>       ChatGPT export JSON (conversations.json)
  claude  <file>       Claude export JSON
  linear               Fetch from Linear API (LINEAR_API_KEY required)
  manus                Fetch from Manus API (MANUS_API_KEY required)
  raw     <file>       Plain text file, one turn per line

Examples:
  collab-memory-ingest chatgpt ~/Downloads/conversations.json
  collab-memory-ingest claude export.json --graph ./data/my.json
  collab-memory-ingest linear --team ENG --limit 50
  collab-memory-ingest manus --all
  collab-memory-ingest manus --task-id a5ej4FnVPLP8Vjvb6FoeAu
  collab-memory-ingest raw session.log
        """,
    )
    parser.add_argument(
        "source",
        choices=["chatgpt", "claude", "linear", "manus", "raw"],
        help="Data source to ingest from",
    )
    parser.add_argument(
        "file",
        nargs="?",
        default=None,
        help="Input file (for chatgpt, claude, raw sources)",
    )
    parser.add_argument(
        "--graph",
        default=os.environ.get("LOCAL_GRAPH_PATH", "./data/memory.json"),
        help="Path to graph JSON (default: ./data/memory.json)",
    )
    # Linear options
    parser.add_argument("--team", default=None, help="Linear team key (e.g. ENG)")
    parser.add_argument("--limit", type=int, default=50, help="Max items to fetch")
    # Manus options
    parser.add_argument("--task-id", default=None, help="Manus task ID to ingest")
    parser.add_argument("--all", dest="ingest_all", action="store_true",
                        help="Ingest all completed Manus tasks")
    parser.add_argument("--manus-key", default=os.environ.get("MANUS_API_KEY"),
                        help="Manus API key (or MANUS_API_KEY env var)")
    parser.add_argument("--linear-key", default=os.environ.get("LINEAR_API_KEY"),
                        help="Linear API key (or LINEAR_API_KEY env var)")
    # General
    parser.add_argument("--dry-run", action="store_true",
                        help="Parse and show turns without writing to graph")
    args = parser.parse_args()

    try:
        from collab_memory import CollabMemory
    except ImportError as e:
        print(f"Error importing collab-memory: {e}", file=sys.stderr)
        sys.exit(1)

    memory = CollabMemory(graph_path=args.graph)

    # ── ChatGPT ──────────────────────────────────────────────────────────────
    if args.source == "chatgpt":
        if not args.file:
            parser.error("chatgpt source requires a file argument")
        from collab_memory.adapters.chatgpt import parse_chatgpt_export
        print(f"Parsing {args.file} ...")
        turns = parse_chatgpt_export(args.file)
        _ingest_turns(turns, memory, args.dry_run, "ChatGPT")

    # ── Claude ───────────────────────────────────────────────────────────────
    elif args.source == "claude":
        if not args.file:
            parser.error("claude source requires a file argument")
        from collab_memory.adapters.claude import parse_claude_export
        print(f"Parsing {args.file} ...")
        turns = parse_claude_export(args.file)
        _ingest_turns(turns, memory, args.dry_run, "Claude")

    # ── Linear ───────────────────────────────────────────────────────────────
    elif args.source == "linear":
        if not args.linear_key:
            parser.error("Linear source requires --linear-key or LINEAR_API_KEY env var")
        from collab_memory.adapters.linear import parse_linear_issues
        print(f"Fetching Linear issues (limit={args.limit}) ...")
        turns = parse_linear_issues(
            api_key=args.linear_key,
            team_key=args.team,
            limit=args.limit,
        )
        _ingest_turns(turns, memory, args.dry_run, "Linear")

    # ── Manus ────────────────────────────────────────────────────────────────
    elif args.source == "manus":
        if not args.manus_key:
            parser.error("Manus source requires --manus-key or MANUS_API_KEY env var")
        from collab_memory.adapters.manus import ManusAdapter
        adapter = ManusAdapter(api_key=args.manus_key)

        if args.task_id:
            turns = adapter.get_turns(args.task_id)
            print(f"Task {args.task_id}: {len(turns)} turns")
            _ingest_turns(turns, memory, args.dry_run, f"Manus:{args.task_id}")

        elif args.ingest_all:
            print("Fetching all completed Manus tasks ...")
            if args.dry_run:
                tasks = adapter.list_tasks(limit=50, status="completed")
                for t in tasks:
                    turns = adapter.get_turns(t["id"])
                    title = (t.get("metadata") or {}).get("task_title", t["id"])
                    print(f"  {title[:60]}: {len(turns)} turns [DRY RUN]")
            else:
                results = adapter.ingest_all_tasks(memory=memory, limit=50)
                total = sum(r.get("turns_pushed", 0) for r in results)
                ok = sum(1 for r in results if "error" not in r)
                print(f"\n✓ {ok}/{len(results)} tasks ingested, {total} total turns")
        else:
            # Just list tasks
            tasks = adapter.list_tasks(limit=20, status="completed")
            print(f"\n{len(tasks)} completed Manus tasks:\n")
            for t in tasks:
                title = (t.get("metadata") or {}).get("task_title", "(no title)")
                print(f"  {t['id']}  {title[:60]}")
            print("\nRe-run with --task-id <id> or --all to ingest.")
            return

    # ── Raw ──────────────────────────────────────────────────────────────────
    elif args.source == "raw":
        if not args.file:
            parser.error("raw source requires a file argument")
        from pathlib import Path
        lines = Path(args.file).read_text(encoding="utf-8").splitlines()
        turns = [l.strip() for l in lines if l.strip()]
        _ingest_turns(turns, memory, args.dry_run, f"raw:{args.file}")


def _ingest_turns(turns: list[str], memory, dry_run: bool, source_name: str):
    if dry_run:
        print(f"\n[DRY RUN] {source_name}: {len(turns)} turns would be ingested:\n")
        for t in turns[:10]:
            print(f"  {t[:100]}")
        if len(turns) > 10:
            print(f"  ... ({len(turns) - 10} more)")
        return

    print(f"Ingesting {len(turns)} turns from {source_name} ...")
    for turn in turns:
        memory.push_turn(turn)
    memory.flush()
    memory.save()
    print(f"✓ {len(turns)} turns written to graph.")


if __name__ == "__main__":
    main()
