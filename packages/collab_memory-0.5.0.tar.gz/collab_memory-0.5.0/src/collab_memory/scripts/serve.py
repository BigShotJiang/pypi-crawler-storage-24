"""collab_memory.scripts.serve — CLI entrypoint for collab-memory-serve command."""
import os
import sys

def main():
    import uvicorn
    port = int(os.environ.get("PORT", "8000"))
    host = os.environ.get("HOST", "0.0.0.0")
    uvicorn.run(
        "collab_memory.api.server:app",
        host=host,
        port=port,
        reload=False,
    )

if __name__ == "__main__":
    main()
