"""
collab_memory.scripts.brief — CLI entrypoint for `collab-memory-brief`.

Loads the memory graph and prints the context brief to stdout.
Useful for scripting: pipe into prompts, log files, or agent pre-prompts.

Usage:
    collab-memory-brief
    collab-memory-brief --graph ./data/memory.json
    collab-memory-brief --format json
    collab-memory-brief --format prompt    # ready-to-paste LLM prompt
    collab-memory-brief --format markdown
    collab-memory-brief | pbcopy           # copy to clipboard (macOS)

Environment:
    LOCAL_GRAPH_PATH — path to graph JSON
"""

from __future__ import annotations

import argparse
import json
import os
import sys


def main():
    parser = argparse.ArgumentParser(
        description="collab-memory-brief — print your agent's context brief",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  collab-memory-brief
  collab-memory-brief --graph ./data/memory.json --format prompt
  collab-memory-brief --format json | jq .
  collab-memory-brief | pbcopy
        """,
    )
    parser.add_argument(
        "--graph",
        default=os.environ.get("LOCAL_GRAPH_PATH", "./data/memory.json"),
        help="Path to local graph JSON (default: ./data/memory.json or LOCAL_GRAPH_PATH)",
    )
    parser.add_argument(
        "--format",
        choices=["text", "prompt", "json", "markdown"],
        default="prompt",
        help="Output format: text, prompt (default), json, markdown",
    )
    parser.add_argument(
        "--session-id",
        default=None,
        help="Filter context to a specific session ID",
    )
    args = parser.parse_args()

    try:
        from collab_memory import CollabMemory
    except ImportError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    memory = CollabMemory(graph_path=args.graph)

    if args.format == "json":
        brief = memory.graph.build_context_brief()
        print(json.dumps(brief, indent=2, default=str))
        return

    if args.format in ("prompt", "text"):
        prompt = memory.to_prompt()
        if not prompt.strip():
            print("[collab-memory] No memory context found. Graph may be empty.")
            sys.exit(0)
        print(prompt)
        return

    if args.format == "markdown":
        brief = memory.graph.build_context_brief()
        decisions = brief.get("locked_decisions", [])
        constraints = brief.get("constraints", [])
        prefs = brief.get("preferences", [])

        print("# Cognitive Memory Brief\n")

        if decisions:
            print("## Locked Decisions")
            for d in decisions:
                text = d.get("text", d) if isinstance(d, dict) else str(d)
                conf = d.get("confidence", "") if isinstance(d, dict) else ""
                print(f"- {text}" + (f" *(confidence: {conf:.0%})*" if conf else ""))
            print()

        if constraints:
            print("## Active Constraints")
            for c in constraints:
                text = c.get("text", c) if isinstance(c, dict) else str(c)
                print(f"- {text}")
            print()

        if prefs:
            print("## Preferences")
            for p in prefs:
                text = p.get("text", p) if isinstance(p, dict) else str(p)
                print(f"- {text}")
            print()


if __name__ == "__main__":
    main()
