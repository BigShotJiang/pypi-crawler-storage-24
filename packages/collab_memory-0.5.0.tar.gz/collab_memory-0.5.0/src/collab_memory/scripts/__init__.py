"""collab_memory.scripts.watch — CLI entrypoint for collab-memory-watch command."""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

def main():
    from scripts.watch_session import main as watch_main
    watch_main()

if __name__ == "__main__":
    main()
