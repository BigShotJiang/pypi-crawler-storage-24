"""
api/server.py — FastAPI query interface + cognitive-dash dashboard.

Endpoints:
  GET /                   — cognitive-dash dashboard UI
  GET /memory/context     — context brief for a new session
  GET /memory/stats       — dashboard stats summary
  GET /memory/why         — decision archaeology
  GET /memory/preferences — filtered preference query
  GET /memory/decisions   — list active decisions
  GET /memory/constraints — list active constraints
  POST /memory/ingest     — encode and store a raw exchange
"""

from __future__ import annotations
import os
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

from ..graph.local import LocalGraphBackend
from ..encoder import encode_exchange

# ─── Setup ────────────────────────────────────────────────────────────────────

_HERE = Path(__file__).parent
_TEMPLATES_DIR = _HERE / "templates"
_STATIC_DIR = _HERE / "static"
_TEMPLATES_DIR.mkdir(exist_ok=True)
_STATIC_DIR.mkdir(exist_ok=True)

app = FastAPI(
    title="Cognitive Dreams — collab-memory",
    description="Semantic working memory layer for human+agent collaboration.",
    version="0.3.0",
)

app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))

_BACKEND = os.environ.get("GRAPH_BACKEND", "local").lower()
active_backend = _BACKEND  # exposed to /setup/status endpoint

def _local_fallback(reason: str = ""):
    if reason:
        print(f"[collab-memory] WARNING: {reason}\n  Falling back to local JSON backend.")
    return LocalGraphBackend(
        path=os.environ.get("LOCAL_GRAPH_PATH", "./data/graph.json")
    )

if _BACKEND == "neo4j":
    try:
        from ..graph.neo4j_backend import Neo4jBackend
        graph = Neo4jBackend(
            uri=os.environ.get("NEO4J_URI", "bolt://localhost:7687"),
            user=os.environ.get("NEO4J_USER", "neo4j"),
            password=os.environ.get("NEO4J_PASSWORD", "password"),
            database=os.environ.get("NEO4J_DATABASE", "neo4j"),
        )
        print(f"[collab-memory] Backend: Neo4j ({os.environ.get('NEO4J_URI', 'bolt://localhost:7687')})")
        active_backend = "neo4j"
    except ImportError:
        graph = _local_fallback("GRAPH_BACKEND=neo4j but 'neo4j' package not installed. Run: pip install neo4j")
        active_backend = "local"
    except Exception as e:
        graph = _local_fallback(f"Neo4j connection failed: {e}. Check NEO4J_URI / NEO4J_PASSWORD.")
        active_backend = "local"

elif _BACKEND in ("graphiti", "falkordb"):
    try:
        from ..graph.graphiti_backend import GraphitiBackend
        _neo4j_uri = os.environ.get("NEO4J_URI") if _BACKEND == "graphiti" else None
        _falkordb = os.environ.get("FALKORDB_URL", "redis://localhost:6379")
        graph = GraphitiBackend(
            uri=_falkordb,
            neo4j_uri=_neo4j_uri,
            neo4j_user=os.environ.get("NEO4J_USER", "neo4j"),
            neo4j_password=os.environ.get("NEO4J_PASSWORD", "password"),
        )
        label = "Graphiti+Neo4j" if _neo4j_uri else "Graphiti+FalkorDB"
        print(f"[collab-memory] Backend: {label}")
        active_backend = _BACKEND
    except ImportError:
        graph = _local_fallback("GRAPH_BACKEND=graphiti but graphiti-core not installed. Run: pip install 'collab-memory[graphiti]'")
        active_backend = "local"
    except Exception as e:
        graph = _local_fallback(f"Graphiti/FalkorDB backend failed: {e}. Is FalkorDB running? Try: docker compose up -d")
        active_backend = "local"

else:
    graph = LocalGraphBackend(
        path=os.environ.get("LOCAL_GRAPH_PATH", "./data/graph.json")
    )
    active_backend = "local"
    print(f"[collab-memory] Backend: local JSON ({os.environ.get('LOCAL_GRAPH_PATH', './data/graph.json')})")



# ─── Request/Response Models ──────────────────────────────────────────────────

from ..schema import Skill, SkillSourceType
from ..adapters.claude import parse_claude_export
from ..adapters.chatgpt import parse_chatgpt_export
from ..agents.pipeline import build_pipeline, get_pipeline_status

# Build pipeline once at startup — graph backend injected
_pipeline = build_pipeline(graph=graph)

class IngestRequest(BaseModel):
    raw_text: str
    session_id: str
    turn_start: int
    turn_end: Optional[int] = None
    skip_llm: bool = False


class IngestResponse(BaseModel):
    exchange_record_id: str
    primitive_type: str
    worthiness_score: float
    should_encode: bool
    nodes_generated: list[str]
    flagged_for_review: bool
    classifier_reasoning: str
    pending_confirmation: bool = False   # True if novel+inferred — awaits HITL


class PendingInference(BaseModel):
    """An inferred node awaiting human confirmation before graph write."""
    id: str
    node_type: str          # Decision | Constraint | Preference | Attempt
    description: str
    origin: str = "inferred"
    confidence: float
    session_id: str
    raw_text: str = ""
    created_at: str = ""


class AddSkillRequest(BaseModel):
    name: str
    url: str = ""
    summary: str = ""
    content: str = ""
    tags: list[str] = []
    source_type: str = "custom"
    added_by: str = "user"


class FetchSkillRequest(BaseModel):
    url: str
    name: str = ""
    tags: list[str] = []
    source_type: str = "api_docs"


# ─── Endpoints ────────────────────────────────────────────────────────────────

# ─── Skills ─────────────────────────
@app.get("/skills", summary="List skills in the library")
def list_skills(
    tags: Optional[str] = Query(None, description="Comma-separated tag filter"),
    source_type: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=500),
):
    """List all stored skills, optionally filtered by tags or source type."""
    tag_list = [t.strip() for t in tags.split(",")] if tags else None
    if hasattr(graph, "get_skills"):
        items = graph.get_skills(tags=tag_list, source_type=source_type, limit=limit)
        return {"skills": [s.model_dump() for s in items], "count": len(items)}
    return {"skills": [], "count": 0, "note": "Backend does not support skills"}


@app.get("/skills/search", summary="Search skills by keyword")
def search_skills(
    q: str = Query(..., description="Search query"),
    limit: int = Query(20, ge=1, le=100),
):
    """Full-text search across skill name, summary, content, tags, and URL."""
    if hasattr(graph, "search_skills"):
        items = graph.search_skills(q, limit=limit)
        return {"skills": [s.model_dump() for s in items], "count": len(items), "query": q}
    return {"skills": [], "count": 0, "query": q}


@app.post("/skills", summary="Add a skill to the library")
def add_skill(req: AddSkillRequest):
    """Manually add a skill (API doc, snippet, how-to) to the knowledge library."""
    try:
        src_type = SkillSourceType(req.source_type)
    except ValueError:
        src_type = SkillSourceType.custom
    skill = Skill(
        name=req.name,
        url=req.url,
        summary=req.summary,
        content=req.content,
        tags=req.tags,
        source_type=src_type,
        added_by=req.added_by,
    )
    if hasattr(graph, "save_skill"):
        graph.save_skill(skill)
    return {"skill_id": skill.id, "name": skill.name, "ok": True}


@app.post("/skills/fetch", summary="Fetch and index a URL as a skill")
async def fetch_skill(req: FetchSkillRequest):
    """
    Fetch a URL, extract its text content, and store it as a skill.
    Useful for indexing API docs, README pages, or integration guides.
    """
    import httpx, re as _re
    try:
        async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
            resp = await client.get(req.url, headers={"User-Agent": "collab-memory/0.2"})
            resp.raise_for_status()
            raw = resp.text
        # Strip HTML tags (basic)
        clean = _re.sub(r"<[^>]+>", " ", raw)
        clean = _re.sub(r"\s+", " ", clean).strip()
        content_preview = clean[:8000]
        name = req.name or req.url.split("/")[-1] or req.url
        try:
            src_type = SkillSourceType(req.source_type)
        except ValueError:
            src_type = SkillSourceType.api_docs
        skill = Skill(
            name=name,
            url=req.url,
            summary=f"Auto-fetched from {req.url}",
            content=content_preview,
            tags=req.tags,
            source_type=src_type,
            added_by="agent",
        )
        if hasattr(graph, "save_skill"):
            graph.save_skill(skill)
        return {
            "skill_id": skill.id,
            "name": skill.name,
            "content_length": len(content_preview),
            "ok": True,
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/memory/context", summary="Get session context brief")
def get_context(
    entity: Optional[str] = Query(None, description="Entity ID to scope context to"),
    task_type: Optional[str] = Query(None, description="Type of task for this session"),
):
    """
    Returns a structured brief: active decisions, constraints, inferred
    preferences, recent attempts, and caution flags.
    This is what an agent calls at the start of a new session.
    """
    return graph.build_context_brief(entity_id=entity, task_type=task_type)


@app.get("/memory/context/prompt", summary="Get session context as a system prompt string")
def get_context_prompt(
    entity: Optional[str] = Query(None),
    task_type: Optional[str] = Query(None),
):
    """
    Returns a ready-to-paste system prompt string built from the current graph context.
    No bash or special tooling required — paste directly into any web agent's system prompt.

    Solves the workflow portability gap: any agent (Claude web, Manus, GPT-4) can call this
    URL and use the response as-is, without interpreting structured JSON.
    """
    brief = graph.build_context_brief(entity_id=entity, task_type=task_type)
    lines = ["## Memory Context (collab-memory)\n"]

    decisions = brief.get("active_decisions", [])
    if decisions:
        lines.append("### Standing Decisions — Do Not Re-Litigate")
        for d in decisions:
            conf = d.get("confidence", 0)
            lines.append(f"- {d['description']} ({int(conf*100)}% confidence)")
        lines.append("")

    constraints = brief.get("active_constraints", [])
    if constraints:
        lines.append("### Active Constraints")
        for c in constraints:
            origin = f" [{c.get('origin','explicit')}]" if c.get("origin") == "inferred" else ""
            lines.append(f"- {c['description']}{origin}")
        lines.append("")

    prefs = brief.get("inferred_preferences", [])
    if prefs:
        lines.append("### Inferred Preferences")
        for p in prefs:
            lines.append(f"- [{p.get('type','process')}] {p['description']}")
        lines.append("")

    attempts = brief.get("recent_attempts", [])
    if attempts:
        lines.append("### Don't Revisit These Approaches")
        for a in attempts:
            lines.append(f"- {a['description']}")
        lines.append("")

    pending = brief.get("pending_count", 0)
    if pending:
        lines.append(f"### ⏳ {pending} inference(s) awaiting your review")
        lines.append(f"- Check: GET /memory/pending to confirm or reject")
        lines.append("")

    lines.append(f"*{brief.get('summary', '')}*")

    prompt = "\n".join(lines)
    return {"prompt": prompt, "char_count": len(prompt), "backend": brief.get("backend", "unknown")}


@app.get("/memory/why", summary="Decision archaeology")
def get_decision_chain(
    decision: str = Query(..., description="Decision ID to trace"),
):
    """
    Traces the causal chain for a given decision: what constraints shaped it,
    what attempts preceded it, and the raw exchange text it came from.
    """
    chain = graph.get_decision_chain(decision)
    if "error" in chain:
        raise HTTPException(status_code=404, detail=chain["error"])
    return chain


@app.get("/memory/preferences", summary="Get inferred preferences")
def get_preferences(
    type: Optional[str] = Query(None, description="aesthetic|process|technical|risk|interpersonal"),
    confidence_min: float = Query(0.5, description="Minimum confidence threshold"),
    min_reinforcements: int = Query(1, description="Minimum reinforcement count"),
):
    """
    Returns inferred preferences, filtered by type, confidence, and
    reinforcement count. Preferences with low reinforcement are tentative.
    """
    prefs = graph.get_preferences(
        pref_type=type,
        confidence_min=confidence_min,
        min_reinforcements=min_reinforcements,
    )
    return {
        "preferences": [p.model_dump() for p in prefs],
        "count": len(prefs),
    }


@app.post("/memory/ingest", response_model=IngestResponse, summary="Encode and store an exchange")
def ingest_exchange(req: IngestRequest):
    """
    Classify a raw conversation exchange and store the results.
    Routes through the 6-agent pipeline:
      Intake → Classifier → Security/Drift → Graph Writer
    Returns the ExchangeRecord metadata and any nodes generated.
    """
    from ..agents.pipeline import PipelineState

    state = _pipeline({
        "raw_text": req.raw_text,
        "session_id": req.session_id,
        "turn_start": req.turn_start,
        "turn_end": getattr(req, "turn_end", req.turn_start),
        "skip_llm": req.skip_llm,
    })

    if state.get("error") and not state.get("exchange_record_id"):
        raise HTTPException(status_code=500, detail=state["error"])

    return IngestResponse(
        exchange_record_id=state.get("exchange_record_id", ""),
        primitive_type=state.get("primitive_type", "Exploration"),
        worthiness_score=state.get("final_score", 0.0),
        should_encode=state.get("should_encode", False),
        nodes_generated=state.get("nodes_generated", []),
        flagged_for_review=state.get("flagged", False),
        classifier_reasoning=state.get("classifier_reasoning", ""),
        pending_confirmation=state.get("pending_confirmation", False),
    )



@app.get("/memory/pipeline/status", summary="Pipeline configuration and agent status")
def pipeline_status():
    """
    Returns the current pipeline configuration: which backend (langgraph vs plain),
    LLM provider, active agents, and graph backend type.
    """
    return get_pipeline_status(graph=graph)


# ─── Project Endpoints ────────────────────────────────────────────────────────

from ..schema import Project as ProjectModel, DEFAULT_PROJECT

class ProjectCreateRequest(BaseModel):
    name: str
    description: str = ""
    owner: str = ""
    tags: list[str] = []


@app.get("/projects", summary="List all projects")
def list_projects():
    """Return all Project nodes in the graph."""
    if hasattr(graph, "get_projects"):
        return {"projects": graph.get_projects()}
    return {"projects": [], "note": "Project support requires Neo4j backend"}


@app.post("/projects", summary="Create a new project")
def create_project(req: ProjectCreateRequest):
    """Create a new Project node for cross-project memory isolation."""
    project = ProjectModel(
        name=req.name,
        description=req.description,
        owner=req.owner,
        tags=req.tags,
    )
    if hasattr(graph, "save_project"):
        graph.save_project(project)
    return {"id": project.id, "name": project.name, "created": True}


@app.get("/health")
def health():
    return {"status": "ok", "version": "0.4.1", "backend": type(graph).__name__}


@app.get("/ops/ping", summary="Keepalive ping — prevents Render cold starts")
def ops_ping():
    """
    Lightweight endpoint for UptimeRobot / external cron to ping every 14 minutes.
    Keeps Render free-tier instance warm — eliminates cold-start delays on all other endpoints.
    Configure: https://uptimerobot.com → New Monitor → HTTP(s) → URL → /ops/ping → every 14 min
    """
    return {"pong": True}


class GitSyncRequest(BaseModel):
    message: str = ""   # Optional commit message; auto-generated if blank


@app.post("/ops/git/sync", summary="Commit + push code and docs to Git")
def ops_git_sync(req: GitSyncRequest = GitSyncRequest()):
    """
    Auto-commit and push the working directory to Git.
    Called automatically by the dashboard 💾 Save Session flow so that
    DB ingest + Git backup happen in one action.
    Safe to call when nothing has changed — git handles the no-op cleanly.
    """
    import subprocess
    from datetime import datetime, timezone

    msg = req.message.strip() or f"chore: session auto-backup {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')} UTC"

    try:
        subprocess.run(["git", "add", "-A"], check=True, capture_output=True)
        result = subprocess.run(
            ["git", "commit", "-m", msg],
            capture_output=True, text=True,
        )
        # "nothing to commit" is fine — not an error
        committed = result.returncode == 0
        commit_out = result.stdout.strip()

        push_out = ""
        if committed:
            push = subprocess.run(["git", "push"], capture_output=True, text=True)
            push_out = push.stdout.strip() or push.stderr.strip()

        return {
            "ok": True,
            "committed": committed,
            "message": msg,
            "commit_output": commit_out,
            "push_output": push_out,
        }
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=f"Git error: {e.stderr or str(e)}")


class SessionSaveRequest(BaseModel):
    session_id: str
    lines: list[str]           # One summary item per line
    skip_llm: bool = True      # Default: keyword-only for speed


@app.post("/memory/session/save", summary="Batch-save session summary lines")
def session_save(req: SessionSaveRequest):
    """
    Batch ingest for end-of-session saves.
    Accepts session_id + list of text lines and ingests each one.
    Used by the dashboard 💾 Save Session modal — one HTTP call instead of N.
    Returns per-line status and a count of successfully stored items.
    """
    results = []
    ok = 0
    for i, line in enumerate(req.lines):
        line = line.strip()
        if not line:
            continue
        try:
            state = _pipeline({
                "raw_text": line,
                "session_id": req.session_id,
                "turn_start": i,
                "skip_llm": req.skip_llm,
            })
            results.append({"line": i, "ok": True, "id": state.get("exchange_record_id", "")})
            ok += 1
        except Exception as e:
            results.append({"line": i, "ok": False, "error": str(e)})

    return {
        "session_id": req.session_id,
        "total": len(req.lines),
        "saved": ok,
        "results": results,
    }


@app.post("/memory/import", summary="Import a Claude or ChatGPT conversation export")
async def import_conversation(
    file: UploadFile = File(...),
    session_id: str = Query("imported_session", description="Session ID to tag ingested records"),
    format: str = Query("auto", description="claude | chatgpt | auto"),
    max_turns: int = Query(200, description="Max turns to ingest (most recent)"),
    skip_llm: bool = Query(False, description="Skip LLM classifier for speed"),
):
    """
    Upload a Claude.ai or ChatGPT JSON export and bulk-ingest the conversation into the graph.

    Claude: Settings → Privacy & Data → Export → conversations.json
    ChatGPT: Settings → Data Controls → Export → conversations.json

    auto-detects format from JSON structure. Processes up to max_turns turns.
    """
    import tempfile, json as _json

    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Empty file")

    # Write to temp file (adapters work with file paths)
    suffix = ".json"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(contents)
        tmp_path = tmp.name

    # Auto-detect format
    detected = format
    if detected == "auto":
        try:
            raw = _json.loads(contents)
            sample = raw[0] if isinstance(raw, list) and raw else raw
            if "chat_messages" in sample or "mapping" not in sample:
                detected = "claude"
            else:
                detected = "chatgpt"
        except Exception:
            detected = "claude"  # fallback

    # Parse turns
    try:
        if detected == "claude":
            turns = parse_claude_export(tmp_path, max_turns=max_turns)
        else:
            turns = parse_chatgpt_export(tmp_path, max_turns=max_turns)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Parse error ({detected}): {e}")

    # Ingest each turn
    ok = 0
    errors = []
    for i, turn in enumerate(turns):
        try:
            result = encode_exchange(
                raw_text=turn,
                session_id=session_id,
                turn_start=i,
                skip_llm=skip_llm,
            )
            graph.ingest_result(result)
            ok += 1
        except Exception as e:
            errors.append({"turn": i, "error": str(e)})

    import os
    os.unlink(tmp_path)

    return {
        "format": detected,
        "session_id": session_id,
        "turns_parsed": len(turns),
        "turns_ingested": ok,
        "errors": errors[:10],  # Cap error list
    }

@app.get("/memory/pending", summary="List inferences awaiting confirmation")
def list_pending():
    """
    Returns inferred nodes awaiting human confirmation.
    These were classified as novel+inferred and not yet written to the main graph.
    Call POST /memory/confirm/{id} to accept or /memory/reject/{id} to discard.
    """
    if hasattr(graph, "get_pending"):
        items = graph.get_pending()
    else:
        # Fallback: query PendingInference nodes from Neo4j directly
        try:
            rows = graph._tx_read(
                "MATCH (n:PendingInference) WHERE n.status = 'pending' "
                "RETURN n ORDER BY n.created_at DESC LIMIT 50"
            )
            items = [dict(r["n"]) for r in rows]
        except Exception:
            items = []
    return {"pending": items, "count": len(items)}


@app.post("/memory/confirm/{item_id}", summary="Confirm an inferred item — write to graph")
def confirm_pending(item_id: str):
    """
    Confirms a pending inference and writes it to the main graph.
    The PendingInference node is marked 'confirmed' and the real node is created.
    """
    try:
        rows = graph._tx_read(
            "MATCH (n:PendingInference {id: $id}) RETURN n", id=item_id
        )
        if not rows:
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail=f"Pending item {item_id} not found")
        node = dict(rows[0]["n"])
        node_type = node.get("node_type", "Decision")
        description = node.get("description", "")
        session_id = node.get("session_id", "unknown")
        confidence = node.get("confidence", 0.7)

        # Write the confirmed node to the graph
        now = __import__("datetime").datetime.utcnow().isoformat()
        if node_type == "Decision":
            graph._tx_write(
                "MERGE (n:Decision {id: $id}) SET n.description=$desc, n.made_in=$sid, "
                "n.confidence=$conf, n.origin='inferred', n.status='active', n.made_at=$now",
                id=f"dec_{item_id[-8:]}", desc=description, sid=session_id, conf=confidence, now=now
            )
        elif node_type == "Constraint":
            graph._tx_write(
                "MERGE (n:Constraint {id: $id}) SET n.description=$desc, n.surfaced_in=$sid, "
                "n.origin='inferred', n.still_active=true, n.surfaced_at=$now",
                id=f"con_{item_id[-8:]}", desc=description, sid=session_id, now=now
            )
        elif node_type == "Preference":
            graph._tx_write(
                "MERGE (n:Preference {id: $id}) SET n.description=$desc, n.inferred_in=$sid, "
                "n.type='process', n.confidence=$conf, n.reinforcement_count=1, n.origin='inferred', n.inferred_at=$now",
                id=f"prf_{item_id[-8:]}", desc=description, sid=session_id, conf=confidence, now=now
            )

        # Mark pending node as confirmed
        graph._tx_write(
            "MATCH (n:PendingInference {id: $id}) SET n.status='confirmed'", id=item_id
        )
        return {"ok": True, "confirmed": item_id, "node_type": node_type, "written": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.post("/memory/reject/{item_id}", summary="Reject an inferred item — do not write to graph")
def reject_pending(item_id: str):
    """
    Rejects a pending inference. The PendingInference node is marked 'rejected' and discarded.
    Nothing is written to the main graph.
    """
    try:
        graph._tx_write(
            "MATCH (n:PendingInference {id: $id}) SET n.status='rejected'", id=item_id
        )
        return {"ok": True, "rejected": item_id}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.post("/memory/queue_inference", summary="Queue an inferred item for human review")
def queue_inference(req: dict):
    """
    Directly queue a novel inferred item for human confirmation.
    Used by agents when they infer something new that wasn't explicitly stated.
    Body: {node_type, description, session_id, confidence, raw_text}
    """
    import uuid as _uuid
    now = __import__("datetime").datetime.utcnow().isoformat()
    item_id = f"pnd_{_uuid.uuid4().hex[:8]}"
    try:
        graph._tx_write(
            """
            MERGE (n:PendingInference {id: $id})
            SET n.node_type = $node_type,
                n.description = $description,
                n.session_id = $session_id,
                n.confidence = $confidence,
                n.raw_text = $raw_text,
                n.origin = 'inferred',
                n.status = 'pending',
                n.created_at = $now
            """,
            id=item_id,
            node_type=req.get("node_type", "Decision"),
            description=req.get("description", ""),
            session_id=req.get("session_id", "unknown"),
            confidence=req.get("confidence", 0.7),
            raw_text=req.get("raw_text", ""),
            now=now,
        )
        return {"ok": True, "queued_id": item_id, "status": "pending"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.post("/ops/restart", summary="Trigger a server restart via Render API")
async def ops_restart():
    """
    Triggers a Render redeploy using the RENDER_API_KEY env var.
    If the key is not set, returns instructions to restart manually.
    """
    import httpx
    render_key = os.environ.get("RENDER_API_KEY", "")
    service_id = os.environ.get("RENDER_SERVICE_ID", "srv-d70ch5n5r7bs73f8g04g")
    if not render_key:
        return {
            "ok": False,
            "message": "RENDER_API_KEY not set — go to dashboard.render.com and click Manual Deploy",
            "dashboard": f"https://dashboard.render.com/web/{service_id}",
        }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(
                f"https://api.render.com/v1/services/{service_id}/deploys",
                headers={"authorization": f"Bearer {render_key}", "content-type": "application/json"},
                json={"clearCache": "do_not_clear"},
            )
        data = r.json()
        return {"ok": r.status_code == 201, "deploy_id": data.get("id"), "status": data.get("status")}
    except Exception as e:
        return {"ok": False, "message": str(e)}


@app.get("/ops/status", summary="Full system status check")
async def ops_status():
    """Returns health of all components: API, Neo4j, LLM."""
    neo_ok = False
    neo_counts = {}
    if hasattr(graph, "test_connection"):
        neo_ok = graph.test_connection()
    if neo_ok and hasattr(graph, "_tx_read"):
        try:
            rows = graph._tx_read("MATCH (n) WHERE size(labels(n)) > 0 RETURN labels(n)[0] AS label, count(n) AS cnt")
            neo_counts = {r["label"]: r["cnt"] for r in rows if r.get("label")}
        except Exception:
            pass
    return {
        "api": {"ok": True, "version": "0.3.1"},
        "neo4j": {"ok": neo_ok, "backend": type(graph).__name__, "node_counts": neo_counts},
        "llm": {
            "ok": bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("OPENAI_API_KEY") or os.environ.get("GOOGLE_API_KEY")),
            "provider": os.environ.get("LLM_PROVIDER", "gemini"),
        },
        "links": {
            "render": "https://dashboard.render.com/web/srv-d70ch5n5r7bs73f8g04g",
            "neo4j": "https://console.neo4j.io",
            "github": "https://github.com/OHACO-LABS/collab-memory",
        }
    }


@app.get("/memory/stats", summary="Dashboard stats summary")
def memory_stats():
    """Counts of all stored nodes — for the cognitive-dash dashboard."""
    try:
        brief = graph.build_context_brief()
    except Exception:
        brief = {}
    try:
        decisions = graph.get_decisions()
    except Exception:
        decisions = []
    try:
        constraints = graph.get_constraints(active_only=True)
    except Exception:
        constraints = []
    try:
        prefs = graph.get_preferences()
    except Exception:
        prefs = []
    attempts = brief.get("recent_attempts", [])
    skills_count = 0
    if hasattr(graph, "get_skills"):
        try:
            skills_count = len(graph.get_skills(limit=500))
        except Exception:
            skills_count = 0
    return {
        "decisions": len(decisions),
        "constraints": len(constraints),
        "preferences": len(prefs),
        "attempts": len(attempts),
        "skills": skills_count,
        "backend": type(graph).__name__,
        "llm_active": bool(
            os.environ.get("ANTHROPIC_API_KEY")
            or os.environ.get("OPENAI_API_KEY")
            or os.environ.get("GOOGLE_API_KEY")
        ),
        "graph_path": os.environ.get("LOCAL_GRAPH_PATH", "./data/graph.json"),
    }


@app.get("/memory/decisions", summary="List active decisions")
def list_decisions(limit: int = Query(50, ge=1, le=200)):
    """List active decisions for the dashboard memory panel."""
    decisions = graph.get_decisions()[:limit]
    return {
        "decisions": [d.model_dump() for d in decisions],
        "count": len(decisions),
    }


@app.get("/memory/constraints", summary="List active constraints")
def list_constraints(limit: int = Query(50, ge=1, le=200)):
    """List active constraints for the dashboard memory panel."""
    constraints = graph.get_constraints(active_only=True)[:limit]
    return {
        "constraints": [c.model_dump() for c in constraints],
        "count": len(constraints),
    }


# ─── Dashboard ────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def dashboard(request: Request):
    """Serve the cognitive-dash dashboard."""
    _template_file = _TEMPLATES_DIR / "dashboard.html"
    if not _template_file.exists():
        return HTMLResponse(
            "<h1>cognitive-dash</h1>"
            "<p>Dashboard template not found.</p>"
            "<p><a href='/docs'>API docs →</a></p>",
            status_code=200,
        )
    # Simple string substitution — avoids Jinja2 caching complications
    api_base = str(request.base_url).rstrip("/")
    html = _template_file.read_text(encoding="utf-8")
    html = html.replace("{{ api_base }}", api_base)
    return HTMLResponse(content=html)


# ─── Setup Wizard ─────────────────────────────────────────────────────────────

@app.get("/setup/status", summary="Current backend status")
def setup_status():
    """Return current backend type and connection health."""
    reachable = True
    if hasattr(graph, "test_connection"):
        reachable = graph.test_connection()
    return {
        "backend": active_backend,
        "reachable": reachable,
        "config": {
            "neo4j_uri": os.environ.get("NEO4J_URI", ""),
            "falkordb_url": os.environ.get("FALKORDB_URL", ""),
            "local_graph_path": os.environ.get("LOCAL_GRAPH_PATH", "./data/graph.json"),
        },
    }


class TestConnectionRequest(BaseModel):
    backend: str          # "local" | "neo4j" | "falkordb" | "graphiti"
    neo4j_uri: str = ""
    neo4j_user: str = "neo4j"
    neo4j_password: str = ""
    falkordb_url: str = "redis://localhost:6379"
    local_graph_path: str = "./data/graph.json"


@app.post("/setup/test", summary="Test a backend connection")
def test_connection(req: TestConnectionRequest):
    """
    Test-connect to a graph backend without switching the live server.
    Used by the Setup Wizard before the user commits to a backend change.
    """
    try:
        if req.backend == "local":
            from pathlib import Path as _Path
            p = _Path(req.local_graph_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            return {"ok": True, "backend": "local", "message": f"Path: {req.local_graph_path}"}

        elif req.backend == "neo4j":
            from ..graph.neo4j_backend import Neo4jBackend
            test_graph = Neo4jBackend(
                uri=req.neo4j_uri or "bolt://localhost:7687",
                user=req.neo4j_user,
                password=req.neo4j_password,
            )
            ok = test_graph.test_connection()
            return {"ok": ok, "backend": "neo4j", "message": "Connected to Neo4j" if ok else "Connection failed"}

        elif req.backend in ("falkordb", "graphiti"):
            # Lightweight check: just try to import and parse the URL
            from ..graph.graphiti_backend import GraphitiBackend
            return {"ok": True, "backend": req.backend, "message": f"FalkorDB URL: {req.falkordb_url} (start server to verify)"}

        else:
            return {"ok": False, "backend": req.backend, "message": f"Unknown backend: {req.backend}"}

    except ImportError as e:
        return {"ok": False, "backend": req.backend, "message": f"Missing dependency: {e}"}
    except Exception as e:
        return {"ok": False, "backend": req.backend, "message": str(e)}


@app.get("/setup", response_class=HTMLResponse, include_in_schema=False)
async def setup_wizard(request: Request):
    """Serve the Setup Wizard for first-time configuration."""
    _setup_file = _TEMPLATES_DIR / "setup.html"
    if not _setup_file.exists():
        return HTMLResponse(
            "<h1>Setup Wizard</h1><p>setup.html template not found.</p>",
            status_code=200,
        )
    api_base = str(request.base_url).rstrip("/")
    html = _setup_file.read_text(encoding="utf-8")
    html = html.replace("{{ api_base }}", api_base)
    return HTMLResponse(content=html)
