"""
schema.py — Pydantic models mirroring schema_v1.md.
This file is the code-level source of truth. Any change here
must be reflected in schema_v1.md first.
"""

from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field
import uuid


# ─── Enums ────────────────────────────────────────────────────────────────────

class EntityType(str, Enum):
    project = "project"
    system = "system"
    technology = "technology"
    person = "person"
    concept = "concept"


class DecisionStatus(str, Enum):
    active = "active"
    superseded = "superseded"
    reversed = "reversed"


class ConstraintOrigin(str, Enum):
    explicit = "explicit"
    inferred = "inferred"


class PreferenceType(str, Enum):
    aesthetic = "aesthetic"        # taste in design, visual, writing style
    process = "process"            # how they like to work
    technical = "technical"        # architectural instincts, stack choices
    risk = "risk"                  # speed vs correctness, ship vs polish
    interpersonal = "interpersonal"  # how they interact with the agent


class PrimitiveType(str, Enum):
    # High-signal
    Override = "Override"
    ConstraintSurface = "ConstraintSurface"
    DecisionClose = "DecisionClose"
    PreferenceReveal = "PreferenceReveal"
    AbandonedAttempt = "AbandonedAttempt"
    # Low-signal
    Exploration = "Exploration"
    Execution = "Execution"
    Clarification = "Clarification"
    Confirmation = "Confirmation"


class SkillSourceType(str, Enum):
    api_docs    = "api_docs"      # Official API reference / swagger
    guide       = "guide"         # Integration guide or tutorial
    snippet     = "snippet"       # Reusable code example
    integration = "integration"   # Platform connector how-to
    custom      = "custom"        # Manually entered skill


HIGH_SIGNAL_PRIMITIVES = {
    PrimitiveType.Override,
    PrimitiveType.ConstraintSurface,
    PrimitiveType.DecisionClose,
    PrimitiveType.PreferenceReveal,
    PrimitiveType.AbandonedAttempt,
}

WORTHINESS_THRESHOLD = 0.4
AMBIGUITY_LOWER = 0.3


# ─── Node Models ──────────────────────────────────────────────────────────────

class Session(BaseModel):
    id: str                          # conversation_id
    started_at: datetime
    ended_at: Optional[datetime] = None
    title: str
    primary_project: Optional[str] = None  # Entity.id ref
    project_id: Optional[str] = None       # Project.id scope
    summary: str = ""


# Default project scope (backward-compatible — used when project_id is omitted)
DEFAULT_PROJECT = "default"


class Project(BaseModel):
    """
    A named scope that groups Sessions, Decisions, Constraints, Preferences.
    Enables cross-project isolation — each project gets its own graph partition.
    One collab-memory instance can serve multiple independent projects.
    """
    id: str = Field(default_factory=lambda: f"prj_{uuid.uuid4().hex[:8]}")
    name: str                        # Display name, e.g. "collab-memory", "prompt-native"
    description: str = ""
    created_at: datetime = Field(default_factory=datetime.utcnow)
    owner: str = ""                  # User or team identifier
    tags: list[str] = Field(default_factory=list)


class Entity(BaseModel):
    id: str = Field(default_factory=lambda: f"ent_{uuid.uuid4().hex[:8]}")
    name: str
    type: EntityType
    first_seen: datetime = Field(default_factory=datetime.utcnow)
    last_updated: datetime = Field(default_factory=datetime.utcnow)
    description: str = ""


class Decision(BaseModel):
    id: str = Field(default_factory=lambda: f"dec_{uuid.uuid4().hex[:8]}")
    made_in: str                     # Session.id
    made_at: datetime = Field(default_factory=datetime.utcnow)
    description: str
    rationale: str = ""              # why — extracted or inferred
    status: DecisionStatus = DecisionStatus.active
    confidence: float = 1.0          # how certain the classifier is this is truly closed
    exchange_record_id: str = ""     # provenance
    project_id: Optional[str] = None  # Project scope (None = default)


class Attempt(BaseModel):
    id: str = Field(default_factory=lambda: f"att_{uuid.uuid4().hex[:8]}")
    tried_in: str                    # Session.id
    tried_at: datetime = Field(default_factory=datetime.utcnow)
    description: str
    outcome: str = ""
    abandoned_because: str = ""
    exchange_record_id: str = ""
    project_id: Optional[str] = None  # Project scope


class Constraint(BaseModel):
    id: str = Field(default_factory=lambda: f"con_{uuid.uuid4().hex[:8]}")
    surfaced_in: str                 # Session.id
    surfaced_at: datetime = Field(default_factory=datetime.utcnow)
    description: str
    origin: ConstraintOrigin = ConstraintOrigin.explicit
    scope: str = ""                  # what this constrains
    still_active: bool = True
    exchange_record_id: str = ""
    project_id: Optional[str] = None  # Project scope


class Preference(BaseModel):
    id: str = Field(default_factory=lambda: f"prf_{uuid.uuid4().hex[:8]}")
    inferred_in: str                 # Session.id
    inferred_at: datetime = Field(default_factory=datetime.utcnow)
    description: str
    type: PreferenceType
    domain: str = ""                 # specific area within type
    evidence: str = ""               # quoted or paraphrased from exchange
    confidence: float = 0.7
    last_reinforced: datetime = Field(default_factory=datetime.utcnow)
    reinforcement_count: int = 1
    exchange_record_id: str = ""
    project_id: Optional[str] = None  # Project scope


class Skill(BaseModel):
    """
    A persistent, searchable knowledge reference.
    Skills are API docs, integration guides, code snippets, or how-to notes
    stored in the graph so agents can retrieve them without re-fetching.
    """
    id: str = Field(default_factory=lambda: f"skl_{uuid.uuid4().hex[:8]}")
    name: str                        # Display name, e.g. "Manus API — Quickstart"
    url: str = ""                    # Source URL (empty for custom snippets)
    summary: str = ""                # One-liner for dashboard display
    content: str = ""                # Full indexed text content
    tags: list[str] = Field(default_factory=list)   # e.g. ["manus", "rest", "python"]
    source_type: SkillSourceType = SkillSourceType.custom
    added_at: datetime = Field(default_factory=datetime.utcnow)
    last_updated: datetime = Field(default_factory=datetime.utcnow)
    added_by: str = "user"           # "user" | "agent" | "ingest"



class ExchangeRecord(BaseModel):
    """
    Provenance anchor — every graph node traces back to one of these.
    Created for every classified exchange, including low-signal ones archived
    as Exploration.
    """
    id: str = Field(default_factory=lambda: f"exc_{uuid.uuid4().hex[:8]}")
    session_id: str
    turn_start: int
    turn_end: int
    raw_text: str
    primitive_type: PrimitiveType
    worthiness_score: float
    extracted_at: datetime = Field(default_factory=datetime.utcnow)
    extractor_version: str = "0.1.0"
    nodes_generated: list[str] = Field(default_factory=list)
    flagged_for_review: bool = False  # True if score in ambiguity zone (0.3-0.4)


# ─── Edge Models ──────────────────────────────────────────────────────────────

class Edge(BaseModel):
    """Generic edge between two graph nodes."""
    id: str = Field(default_factory=lambda: f"edg_{uuid.uuid4().hex[:8]}")
    type: str                        # e.g. DECIDED_IN, SUPERSEDES, REVEALS
    source_id: str
    target_id: str
    properties: dict = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ─── Encoder Output ───────────────────────────────────────────────────────────

class ClassificationResult(BaseModel):
    """
    Output of the encoder for a single exchange span.
    May produce zero or multiple graph nodes.
    """
    exchange_record: ExchangeRecord
    nodes: list[Decision | Attempt | Constraint | Preference] = Field(
        default_factory=list
    )
    edges: list[Edge] = Field(default_factory=list)
    should_encode: bool              # False if below threshold or ambiguous
    classifier_reasoning: str = ""  # LLM's explanation for the classification
