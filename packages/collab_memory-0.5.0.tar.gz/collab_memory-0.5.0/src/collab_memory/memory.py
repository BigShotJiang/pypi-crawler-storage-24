"""
memory.py — CollabMemory: unified high-level interface for collab-memory.

This is the primary SDK entrypoint. Handles both read (load context at session
start) and write (push turns during session, flush at session end) in one object.

Compatible with LangChain's BaseMemory interface, and usable standalone.

Usage:
    from collab_memory import CollabMemory

    memory = CollabMemory(graph_path="./memory.json")

    # Session start — get everything the agent needs to know:
    brief = memory.load()                        # structured dict
    system_prompt = memory.to_prompt()           # formatted string for system prompt

    # During session — push each turn:
    memory.push_turn("USER: Let's not use Redis here")
    memory.push_turn("AGENT: Agreed — switching to in-memory queue.")

    # Session end:
    memory.flush()
    memory.save()

LangChain compatibility:
    from collab_memory import CollabMemory
    memory = CollabMemory(graph_path="./memory.json", session_id="proj_001")

    # In a LangChain chain:
    chain = ConversationChain(llm=llm, memory=memory)
"""

from __future__ import annotations

import os
import time
from typing import Any

from .graph.base import GraphBackend
from .graph.local import LocalGraphBackend
from .encoder import encode_exchange
from .schema import WORTHINESS_THRESHOLD


def _get_graph(
        graph_path: str | None = None,
        backend: str | None = None,
        **backend_kwargs,
) -> GraphBackend:
    """Backend factory — defaults to local JSON."""
    resolved_backend = backend or os.environ.get("GRAPH_BACKEND", "local").lower()
    if resolved_backend == "graphiti":
        from .graph.graphiti_backend import GraphitiBackend
        return GraphitiBackend(**backend_kwargs)
    path = graph_path or os.environ.get("LOCAL_GRAPH_PATH", "./data/memory.json")
    return LocalGraphBackend(path=path)


class CollabMemory:
    """
    Unified read+write memory interface for collab-memory.

    OHACO Labs · Cognitive Dreams
    """

    def __init__(
            self,
            graph_path: str | None = None,
            session_id: str | None = None,
            backend: str | None = None,
            skip_llm: bool | None = None,
            verbose: bool = False,
            **backend_kwargs,
    ):
        """
        Args:
            graph_path:   Path to local JSON graph (local backend only).
            session_id:   Session identifier. Auto-generated if not provided.
            backend:      "local" (default) or "graphiti".
            skip_llm:     Skip LLM classification (keyword-only mode).
                          Defaults to True if no API key is set.
            verbose:      Print ingestion events.
            **backend_kwargs: Passed to GraphitiBackend if backend="graphiti".
        """
        self._graph = _get_graph(graph_path, backend, **backend_kwargs)
        self._graph_path = graph_path
        self._session_id = session_id or f"session_{int(time.time())}"
        self._verbose = verbose

        # Auto-detect skip_llm if not specified
        if skip_llm is None:
            has_key = any([
                os.environ.get("ANTHROPIC_API_KEY"),
                os.environ.get("OPENAI_API_KEY"),
                os.environ.get("GOOGLE_API_KEY"),
            ])
            skip_llm = not has_key
        self._skip_llm = skip_llm

        self._turn_buffer: list[str] = []
        self._turn_index = 0
        self._watcher = None  # lazy-loaded

    # ─── Read API ─────────────────────────────────────────────────────────────

    def load(self, entity_id: str | None = None, task_type: str | None = None) -> dict:
        """
        Load context brief for a new session.

        Returns a structured dict with:
          - active_decisions
          - active_constraints
          - inferred_preferences
          - recent_attempts
          - caution_flags
        """
        return self._graph.build_context_brief(
            entity_id=entity_id,
            task_type=task_type,
        )

    def to_prompt(
            self,
            entity_id: str | None = None,
            task_type: str | None = None,
            header: str = "## Session Context (from Cognitive Dreams memory)",
    ) -> str:
        """
        Format context brief as a system prompt string.

        Drop this into your agent's system prompt at session start.
        """
        brief = self.load(entity_id=entity_id, task_type=task_type)
        lines = [header, ""]

        decisions = brief.get("active_decisions", [])
        if decisions:
            lines.append("### Locked Decisions")
            for d in decisions:
                conf = d.get("confidence") or d.get("worthiness_score", 0)
                lines.append(f"- {d['description']} *(confidence: {conf:.2f})*")
            lines.append("")

        constraints = brief.get("active_constraints", [])
        if constraints:
            lines.append("### Active Constraints")
            for c in constraints:
                origin = c.get("origin", "")
                lines.append(f"- {c['description']}" + (f" [{origin}]" if origin else ""))
            lines.append("")

        preferences = brief.get("inferred_preferences", [])
        if preferences:
            lines.append("### User Preferences")
            for p in preferences:
                ptype = p.get("type", "")
                lines.append(f"- [{ptype}] {p['description']}")
            lines.append("")

        attempts = brief.get("recent_attempts", [])
        if attempts:
            lines.append("### Abandoned Approaches (don't revisit unless asked)")
            for a in attempts:
                lines.append(f"- {a['description']}")
            lines.append("")

        cautions = brief.get("caution_flags", [])
        if cautions:
            lines.append("### Caution Flags")
            for c in cautions:
                lines.append(f"- ⚠ {c}")
            lines.append("")

        if not any([decisions, constraints, preferences, attempts, cautions]):
            lines.append("*No prior context — this is a fresh start.*")

        return "\n".join(lines)

    def check(self) -> dict:
        """
        Health check — returns a summary of what the system currently knows.
        Useful for 'check in with memory' agent commands.
        """
        brief = self.load()
        return {
            "status": "ok",
            "session_id": self._session_id,
            "backend": type(self._graph).__name__,
            "skip_llm": self._skip_llm,
            "summary": {
                "decisions": len(brief.get("active_decisions", [])),
                "constraints": len(brief.get("active_constraints", [])),
                "preferences": len(brief.get("inferred_preferences", [])),
                "attempts": len(brief.get("recent_attempts", [])),
            },
            "llm_active": not self._skip_llm,
        }

    # ─── Write API ────────────────────────────────────────────────────────────

    def push_turn(self, text: str) -> None:
        """
        Push a conversation turn for ingestion.

        Fast (< 1ms) — keyword pre-screen runs synchronously,
        LLM classification runs async in a thread pool.
        """
        self._turn_buffer.append(text)
        self._get_watcher().push_turn(text)
        self._turn_index += 1

    def flush(self) -> dict:
        """
        Wait for all pending LLM classification to complete.
        Call at session end before closing.
        Returns stats dict.
        """
        watcher = self._get_watcher()
        stats = watcher.flush()
        return stats.report() if hasattr(stats, "report") else stats

    def save(self) -> None:
        """Explicit save (no-op for local backend which auto-saves; meaningful for future backends)."""
        if hasattr(self._graph, "save"):
            self._graph.save()

    def shutdown(self) -> None:
        """Shutdown background thread pool. Call when done with this memory object."""
        if self._watcher is not None:
            self._watcher.shutdown()
            self._watcher = None

    # ─── LangChain BaseMemory interface ──────────────────────────────────────

    @property
    def memory_variables(self) -> list[str]:
        """LangChain compatibility."""
        return ["collab_memory_context"]

    def load_memory_variables(self, inputs: dict) -> dict:
        """LangChain compatibility — return context as a string variable."""
        return {"collab_memory_context": self.to_prompt()}

    def save_context(self, inputs: dict, outputs: dict) -> None:
        """LangChain compatibility — push human + AI turn to memory."""
        human = inputs.get("input") or inputs.get("human_input") or ""
        ai = outputs.get("output") or outputs.get("response") or ""
        if human:
            self.push_turn(f"USER: {human}")
        if ai:
            self.push_turn(f"AGENT: {ai}")

    def clear(self) -> None:
        """LangChain compatibility — flushes pending writes."""
        self.flush()

    # ─── Context manager support ──────────────────────────────────────────────

    def __enter__(self) -> "CollabMemory":
        return self

    def __exit__(self, *args) -> None:
        self.flush()
        self.shutdown()

    def __repr__(self) -> str:
        brief = self.load()
        d = len(brief.get("active_decisions", []))
        c = len(brief.get("active_constraints", []))
        p = len(brief.get("inferred_preferences", []))
        return (
            f"<CollabMemory session={self._session_id!r} "
            f"decisions={d} constraints={c} preferences={p} "
            f"backend={type(self._graph).__name__}>"
        )

    # ─── Internal ─────────────────────────────────────────────────────────────

    def _get_watcher(self):
        """Lazy-load SessionWatcher to avoid circular imports."""
        if self._watcher is None:
            import sys, os as _os
            _repo_root = _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
            if _repo_root not in sys.path:
                sys.path.insert(0, _repo_root)
            from scripts.watch_session import SessionWatcher
            self._watcher = SessionWatcher(
                session_id=self._session_id,
                graph=self._graph,
                skip_llm=self._skip_llm,
                verbose=self._verbose,
            )
        return self._watcher
