"""
encoder.py — Exchange classifier and worthiness scorer.

Takes a raw conversation span (one or more turns) and produces a
ClassificationResult: primitive type, worthiness score, and extracted
graph nodes ready for storage.

Architecture:
  1. Keyword pre-screen (fast, cheap) → rough worthiness score
  2. LLM classification (Gemini) → primitive type + extracted fields
  3. Merge scores → final worthiness
  4. If above threshold → build graph nodes from extracted fields
"""

from __future__ import annotations

import json
import os
import re
import time
from datetime import datetime
from typing import Optional

from dotenv import load_dotenv

from .schema import (
    AMBIGUITY_LOWER,
    HIGH_SIGNAL_PRIMITIVES,
    WORTHINESS_THRESHOLD,
    Attempt,
    ClassificationResult,
    Constraint,
    ConstraintOrigin,
    Decision,
    DecisionStatus,
    Edge,
    ExchangeRecord,
    Preference,
    PreferenceType,
    PrimitiveType,
)

load_dotenv()

# ─── LLM Provider ─────────────────────────────────────────────────────────────

EXTRACTOR_VERSION = os.environ.get("EXTRACTOR_VERSION", "0.1.0")
LLM_PROVIDER = os.environ.get("LLM_PROVIDER", "gemini").lower()


def _call_llm_gemini(prompt: str) -> dict:
    import google.genai as genai
    from google.genai import types as genai_types
    api_key = os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError("GOOGLE_API_KEY not set")
    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model="gemini-2.0-flash-lite",
        contents=prompt,
        config=genai_types.GenerateContentConfig(
            response_mime_type="application/json",
        ),
    )
    return json.loads(response.text)


def _call_llm_openai(prompt: str) -> dict:
    from openai import OpenAI
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY not set")
    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"},
    )
    return json.loads(response.choices[0].message.content)


def _call_llm_anthropic(prompt: str) -> dict:
    import anthropic
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY not set")
    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model=os.environ.get("ANTHROPIC_MODEL", "claude-haiku-4-5"),
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
        system="You are a JSON-only responder. Always return valid JSON matching the requested structure. No prose.",
    )
    raw = response.content[0].text.strip()
    # Strip markdown fences if present
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-z]*\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw.strip())
    return json.loads(raw)


_PROVIDER_MAP = {
    "gemini": _call_llm_gemini,
    "openai": _call_llm_openai,
    "anthropic": _call_llm_anthropic,
}


# ─── Keyword Pre-Screen ───────────────────────────────────────────────────────

_OVERRIDE_PATTERNS = re.compile(
    r"\b(no[,\s]|let'?s?\s+(?:not|do|use|go|try)|actually[,\s]|instead[,\s]|"
    r"scratch that|wait[,\s]|hold on|change|pivot|different approach|rather)\b",
    re.IGNORECASE,
)
_DECISION_PATTERNS = re.compile(
    r"\b(we'?ll\s+use|we'?re\s+going\s+with|decided|locked in|final(?:ly)?[,\s]|"
    r"that'?s?\s+the\s+one|going\s+with|sticking\s+with|settled\s+on|"
    r"let'?s?\s+(?:go|proceed|build|start|use)|I\s+think\s+we\s+can\s+proceed|"
    r"looks?\s+good[,\s]|good\s+to\s+go|ship\s+it|approved)",
    re.IGNORECASE,
)
_ABANDON_PATTERNS = re.compile(
    r"\b(won'?t\s+work|doesn'?t\s+work|abandon|drop(?:ping)?|"
    r"too\s+complex|overkill|not\s+worth|skip\s+that|forget\s+it|scratch)\b",
    re.IGNORECASE,
)
_CONSTRAINT_PATTERNS = re.compile(
    r"\b(can'?t|cannot|must|always|never|need\s+to|have\s+to|"
    r"required?|blocked|limit(?:ation)?|constraint|no\s+budget|no\s+time)\b",
    re.IGNORECASE,
)
_EXECUTION_PATTERNS = re.compile(
    r"\b(done|completed|implemented|added|created|fixed|updated|wrote)\b",
    re.IGNORECASE,
)


def _keyword_score(text: str) -> float:
    """Fast heuristic pre-screen. Returns 0.0–1.0."""
    score = 0.0
    if _OVERRIDE_PATTERNS.search(text):
        score += 0.4
    if _DECISION_PATTERNS.search(text):
        score += 0.3
    if _ABANDON_PATTERNS.search(text):
        score += 0.3
    if _CONSTRAINT_PATTERNS.search(text):
        score += 0.2
    if _EXECUTION_PATTERNS.search(text) and score == 0.0:
        score -= 0.3
    return max(0.0, min(1.0, score))


# ─── LLM Classification ───────────────────────────────────────────────────────

_CLASSIFICATION_PROMPT = """\
You are classifying a conversation exchange between a human and an AI agent.
Your job is to identify the most significant primitive type and extract structured data.

The conversation is from a real software development collaboration session.

## Primitive Types
HIGH-SIGNAL (generate graph nodes):
- Override: Human redirects the agent mid-task ("no, let's do X instead", "actually...")
- ConstraintSurface: A constraint becomes explicit that was implicit ("we can't use X because...")
- DecisionClose: A path is definitively chosen, alternatives ruled out
- PreferenceReveal: Human pushes back in a way that reveals taste or values
- AbandonedAttempt: Something was tried and explicitly dropped

LOW-SIGNAL (skip or archive only):
- Exploration: Open-ended brainstorming without resolution
- Execution: Routine implementation of a known pattern
- Clarification: Agent asks, human answers, no redirection
- Confirmation: Human confirms agent's plan without modification

## Preference Types (if PreferenceReveal)
- aesthetic: taste in design, visual, writing style
- process: how they like to work, pace, planning depth
- technical: architectural instincts, stack choices, complexity tolerance
- risk: how they weigh speed vs correctness, ship vs polish
- interpersonal: how they interact with the agent

## Exchange Text
{exchange_text}

## Instructions
Respond with ONLY valid JSON in this exact structure:
{{
  "primitive_type": "<one of the types above>",
  "confidence": <0.0 to 1.0 — how certain you are of this classification>,
  "description": "<concise description of what happened in this exchange>",
  "rationale": "<why this path was chosen or abandoned — extract from text>",
  "evidence": "<direct quote or close paraphrase that best reveals the primitive>",
  "preference_type": "<aesthetic|process|technical|risk|interpersonal or null>",
  "preference_domain": "<specific domain e.g. 'API architecture' or null>",
  "constraint_scope": "<what this constrains or null>",
  "constraint_origin": "<explicit|inferred or null>",
  "abandoned_because": "<reason for abandonment or null>",
  "reasoning": "<brief explanation of your classification>"
}}
"""


def _call_llm(exchange_text: str) -> dict:
    """
    Call the configured LLM provider to classify an exchange.
    Provider is set via LLM_PROVIDER env var: gemini | openai | anthropic
    Retries up to 3 times on rate limit errors.
    """
    provider_fn = _PROVIDER_MAP.get(LLM_PROVIDER)
    if not provider_fn:
        raise RuntimeError(f"Unknown LLM_PROVIDER: '{LLM_PROVIDER}'. Choose: gemini, openai, anthropic")

    prompt = _CLASSIFICATION_PROMPT.format(exchange_text=exchange_text)

    for attempt in range(3):
        try:
            return provider_fn(prompt)
        except Exception as e:
            err = str(e)
            is_rate_limit = any(x in err for x in ["429", "RESOURCE_EXHAUSTED", "rate_limit", "RateLimitError", "overloaded"])
            if is_rate_limit and attempt < 2:
                wait = 20 * (attempt + 1)
                print(f"\n[{LLM_PROVIDER} rate limit] waiting {wait}s (retry {attempt + 1}/3)...")
                time.sleep(wait)
            else:
                raise
    raise RuntimeError(f"LLM call failed after 3 retries ({LLM_PROVIDER})")  # unreachable but satisfies type checker


# ─── Node Builder ─────────────────────────────────────────────────────────────

def _build_nodes(
    llm_result: dict,
    exchange_record: ExchangeRecord,
    session_id: str,
) -> tuple[list, list[Edge]]:
    """
    Build graph nodes and edges from LLM classification result.
    Returns (nodes, edges).
    """
    nodes = []
    edges = []
    ptype = exchange_record.primitive_type

    if ptype == PrimitiveType.DecisionClose or ptype == PrimitiveType.Override:
        node = Decision(
            made_in=session_id,
            description=llm_result.get("description", ""),
            rationale=llm_result.get("rationale", ""),
            status=DecisionStatus.active,
            confidence=llm_result.get("confidence", 0.7),
            exchange_record_id=exchange_record.id,
        )
        nodes.append(node)
        edges.append(Edge(
            type="DECIDED_IN",
            source_id=node.id,
            target_id=session_id,
        ))

    if ptype == PrimitiveType.AbandonedAttempt:
        node = Attempt(
            tried_in=session_id,
            description=llm_result.get("description", ""),
            abandoned_because=llm_result.get("abandoned_because", ""),
            exchange_record_id=exchange_record.id,
        )
        nodes.append(node)
        edges.append(Edge(
            type="ATTEMPTED_IN",
            source_id=node.id,
            target_id=session_id,
        ))

    if ptype == PrimitiveType.ConstraintSurface:
        origin_raw = llm_result.get("constraint_origin", "explicit")
        try:
            origin = ConstraintOrigin(origin_raw)
        except ValueError:
            origin = ConstraintOrigin.explicit

        node = Constraint(
            surfaced_in=session_id,
            description=llm_result.get("description", ""),
            origin=origin,
            scope=llm_result.get("constraint_scope", ""),
            exchange_record_id=exchange_record.id,
        )
        nodes.append(node)
        edges.append(Edge(
            type="SURFACED_IN",
            source_id=node.id,
            target_id=session_id,
        ))

    if ptype == PrimitiveType.PreferenceReveal or (
        ptype == PrimitiveType.Override and llm_result.get("preference_type")
    ):
        pref_type_raw = llm_result.get("preference_type") or "technical"
        try:
            pref_type = PreferenceType(pref_type_raw)
        except ValueError:
            pref_type = PreferenceType.technical

        node = Preference(
            inferred_in=session_id,
            description=llm_result.get("description", ""),
            type=pref_type,
            domain=llm_result.get("preference_domain", ""),
            evidence=llm_result.get("evidence", ""),
            confidence=llm_result.get("confidence", 0.6),
            exchange_record_id=exchange_record.id,
        )
        nodes.append(node)
        edges.append(Edge(
            type="REVEALS",
            source_id=exchange_record.id,
            target_id=node.id,
        ))

    return nodes, edges


# ─── Main Encoder ─────────────────────────────────────────────────────────────

def encode_exchange(
    raw_text: str,
    session_id: str,
    turn_start: int,
    turn_end: Optional[int] = None,
    skip_llm: bool = False,
) -> ClassificationResult:
    """
    Classify a conversation exchange and produce graph-ready output.

    Args:
        raw_text: The raw conversation text (one or more turns).
        session_id: The Session.id this exchange belongs to.
        turn_start: Index of the first turn in this exchange.
        turn_end: Index of the last turn (defaults to turn_start).
        skip_llm: If True, use keyword scorer only (for testing).

    Returns:
        ClassificationResult with exchange_record, nodes, edges, and
        a should_encode flag.
    """
    if turn_end is None:
        turn_end = turn_start

    # Step 1: Keyword pre-screen
    keyword_score = _keyword_score(raw_text)

    if skip_llm:
        # Test mode: keyword only, minimal classification
        ptype = PrimitiveType.Exploration
        if keyword_score >= WORTHINESS_THRESHOLD:
            if _OVERRIDE_PATTERNS.search(raw_text):
                ptype = PrimitiveType.Override
            elif _DECISION_PATTERNS.search(raw_text):
                ptype = PrimitiveType.DecisionClose
            elif _ABANDON_PATTERNS.search(raw_text):
                ptype = PrimitiveType.AbandonedAttempt
            elif _CONSTRAINT_PATTERNS.search(raw_text):
                ptype = PrimitiveType.ConstraintSurface

        llm_result = {
            "primitive_type": ptype.value,
            "confidence": keyword_score,
            "description": raw_text[:200],
            "rationale": "",
            "evidence": "",
            "reasoning": "keyword-only mode",
        }
        final_score = keyword_score
    else:
        # Step 2: LLM classification
        llm_result = _call_llm(raw_text)
        llm_confidence = float(llm_result.get("confidence", 0.5))

        # Step 3: Merge keyword + LLM scores (weighted average)
        final_score = (keyword_score * 0.3) + (llm_confidence * 0.7)

        ptype_raw = llm_result.get("primitive_type", "Exploration")
        try:
            ptype = PrimitiveType(ptype_raw)
        except ValueError:
            ptype = PrimitiveType.Exploration

    # Step 4: Threshold logic (>= 0.4 encodes; 0.3-0.4 is ambiguous)
    flagged = AMBIGUITY_LOWER <= final_score < WORTHINESS_THRESHOLD
    should_encode = final_score >= WORTHINESS_THRESHOLD and ptype in HIGH_SIGNAL_PRIMITIVES

    # Step 5: Build ExchangeRecord (always created)
    exchange_record = ExchangeRecord(
        session_id=session_id,
        turn_start=turn_start,
        turn_end=turn_end,
        raw_text=raw_text,
        primitive_type=ptype,
        worthiness_score=round(final_score, 3),
        extractor_version=EXTRACTOR_VERSION,
        flagged_for_review=flagged,
    )

    # Step 6: Build graph nodes if high-signal and above threshold
    nodes: list = []
    graph_edges: list[Edge] = []

    if should_encode:
        nodes, graph_edges = _build_nodes(llm_result, exchange_record, session_id)
        exchange_record.nodes_generated = [n.id for n in nodes]

    return ClassificationResult(
        exchange_record=exchange_record,
        nodes=nodes,
        edges=graph_edges,
        should_encode=should_encode,
        classifier_reasoning=llm_result.get("reasoning", ""),
    )


def encode_session(
    turns: list[str],
    session_id: str,
    skip_llm: bool = False,
) -> list[ClassificationResult]:
    """
    Encode an entire session's turns, applying the multi-turn pending buffer.

    Each turn is evaluated individually. If a high-signal opening is detected
    but not yet resolved, subsequent turns are appended to the buffer up to
    the 6-turn resolution window.

    Args:
        turns: List of raw turn strings (alternating human/agent or flat).
        session_id: The session identifier.
        skip_llm: Bypass LLM for keyword-only testing.

    Returns:
        List of ClassificationResults, one per resolved exchange span.
    """
    results = []
    i = 0
    pending_buffer: list[str] = []
    pending_start: Optional[int] = None
    MAX_WINDOW = 6

    while i < len(turns):
        turn = turns[i]

        if pending_buffer:
            pending_buffer.append(turn)
            span_text = "\n".join(pending_buffer)
            span_len = len(pending_buffer)

            # Check if this turn resolves the pending span
            score = _keyword_score(span_text)
            resolved = score >= WORTHINESS_THRESHOLD or span_len >= MAX_WINDOW

            if resolved:
                result = encode_exchange(
                    raw_text=span_text,
                    session_id=session_id,
                    turn_start=pending_start,
                    turn_end=i,
                    skip_llm=skip_llm,
                )
                results.append(result)
                pending_buffer = []
                pending_start = None
        else:
            score = _keyword_score(turn)
            if score >= WORTHINESS_THRESHOLD:
                # Immediate resolution
                result = encode_exchange(
                    raw_text=turn,
                    session_id=session_id,
                    turn_start=i,
                    turn_end=i,
                    skip_llm=skip_llm,
                )
                results.append(result)
            elif score > 0.15:
                # High-signal opening, start pending buffer
                pending_buffer = [turn]
                pending_start = i
            # else: low signal, skip

        i += 1

    # Flush any remaining pending buffer
    if pending_buffer:
        result = encode_exchange(
            raw_text="\n".join(pending_buffer),
            session_id=session_id,
            turn_start=pending_start,
            turn_end=i - 1,
            skip_llm=skip_llm,
        )
        results.append(result)

    return results
