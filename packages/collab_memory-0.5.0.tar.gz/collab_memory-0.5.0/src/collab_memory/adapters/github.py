"""
adapters/github.py — GitHub adapter for collab-memory.

Pulls decisions, constraints, and preferences from GitHub repositories:
- PR review comments (decision signals)
- Issue discussions (constraint surfaces)
- CONTRIBUTING.md / ADR docs (explicit constraints + decisions)
- Commit messages (decisions and abandoned attempts)

Usage:
    export GITHUB_TOKEN=ghp_...

    from collab_memory.adapters.github import GitHubAdapter
    from collab_memory import CollabMemory

    adapter = GitHubAdapter(token="ghp_...")
    adapter.ingest_repo("OHACO-LABS/collab-memory", memory)
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timezone
from typing import Optional

try:
    import httpx
    _HTTPX_AVAILABLE = True
except ImportError:
    _HTTPX_AVAILABLE = False


# ─── GitHub API Client ───────────────────────────────────────────────────────

class GitHubClient:
    """Light REST client for the GitHub v3 API."""

    BASE = "https://api.github.com"

    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def get(self, path: str, params: dict | None = None) -> dict | list:
        if not _HTTPX_AVAILABLE:
            raise ImportError("httpx is required. Run: pip install httpx")
        url = f"{self.BASE}{path}"
        with httpx.Client(timeout=15.0) as client:
            r = client.get(url, headers=self.headers, params=params or {})
            r.raise_for_status()
            return r.json()

    def paginate(self, path: str, params: dict | None = None, max_pages: int = 5) -> list:
        params = {**(params or {}), "per_page": 100, "page": 1}
        results = []
        for _ in range(max_pages):
            page = self.get(path, params)
            if not page:
                break
            results.extend(page)
            if len(page) < 100:
                break
            params["page"] += 1
        return results


# ─── GitHub Adapter ──────────────────────────────────────────────────────────

class GitHubAdapter:
    """
    Ingests decisions, constraints, and preferences from GitHub repositories.

    Supported sources:
    - Pull request review comments → Decisions / Constraints
    - Issue discussions → Constraint surfaces
    - Commit messages → quick decisions, abandoned attempts
    - Released tags         → milestone decisions
    - CONTRIBUTING.md / docs → explicit constraints
    """

    CONSTRAINT_KEYWORDS = [
        "must", "cannot", "never", "required", "forbidden",
        "breaking change", "do not", "blocked", "restriction",
        "limitation", "not allowed",
    ]

    DECISION_KEYWORDS = [
        "decided to", "we will", "going with", "choosing",
        "merged", "approved", "accepted", "we chose", "adopted",
        "resolved to",
    ]

    def __init__(
        self,
        token: str | None = None,
        verbose: bool = False,
    ):
        self.token = token or os.environ.get("GITHUB_TOKEN", "")
        if not self.token:
            raise ValueError(
                "GitHub token required. Set GITHUB_TOKEN env var or pass token= parameter."
            )
        self.client = GitHubClient(self.token)
        self.verbose = verbose

    # ── Turn converters ──────────────────────────────────────────────────────

    def _log(self, msg: str):
        if self.verbose:
            print(f"[GitHubAdapter] {msg}")

    def _classify_text(self, text: str) -> str:
        """Quick keyword classification: 'decision' | 'constraint' | 'unknown'."""
        lower = text.lower()
        if any(k in lower for k in self.CONSTRAINT_KEYWORDS):
            return "constraint"
        if any(k in lower for k in self.DECISION_KEYWORDS):
            return "decision"
        return "unknown"

    def _github_user_to_role(self, associations: list[str]) -> str:
        """Map GitHub author_association to AGENT/USER roles."""
        if any(a in associations for a in ("OWNER", "MEMBER", "COLLABORATOR")):
            return "AGENT"
        return "USER"

    # ── Fetch methods ────────────────────────────────────────────────────────

    def list_repos(self, org: str) -> list[dict]:
        """List all repos for a GitHub org or user."""
        try:
            return self.client.paginate(f"/orgs/{org}/repos")
        except Exception:
            return self.client.paginate(f"/users/{org}/repos")

    def get_pr_comments(self, repo: str, pr_number: int) -> list[dict]:
        """Get all review comments for a PR."""
        return self.client.paginate(f"/repos/{repo}/pulls/{pr_number}/comments")

    def get_issue_comments(self, repo: str, issue_number: int) -> list[dict]:
        """Get all comments for an issue."""
        return self.client.paginate(f"/repos/{repo}/issues/{issue_number}/comments")

    def get_commits(self, repo: str, limit: int = 50) -> list[dict]:
        """Get recent commit messages from a repo's default branch."""
        return self.client.paginate(f"/repos/{repo}/commits", max_pages=1)[:limit]

    def get_prs(self, repo: str, state: str = "closed", limit: int = 30) -> list[dict]:
        """Get merged/closed PRs."""
        prs = self.client.get(f"/repos/{repo}/pulls", params={"state": state, "per_page": limit})
        return prs if isinstance(prs, list) else []

    def get_file_content(self, repo: str, path: str) -> str:
        """Fetch a file's text content from the repo (e.g. CONTRIBUTING.md)."""
        import base64
        try:
            data = self.client.get(f"/repos/{repo}/contents/{path}")
            if isinstance(data, dict) and data.get("encoding") == "base64":
                return base64.b64decode(data["content"]).decode("utf-8", errors="replace")
        except Exception:
            pass
        return ""

    # ── Ingestion ────────────────────────────────────────────────────────────

    def extract_turns_from_repo(
        self,
        repo: str,
        include_prs: bool = True,
        include_issues: bool = True,
        include_commits: bool = True,
        include_contributing: bool = True,
        pr_limit: int = 20,
        commit_limit: int = 50,
    ) -> list[dict]:
        """
        Extract all signal-worthy content from a GitHub repo as collab-memory turns.
        Returns a list of {"role": str, "content": str, "source": str, "classification": str} dicts.
        """
        turns = []

        # 1. CONTRIBUTING.md / ADR docs → explicit constraints
        if include_contributing:
            for doc_path in ["CONTRIBUTING.md", "ARCHITECTURE.md", "ADR.md", "docs/architecture.md"]:
                content = self.get_file_content(repo, doc_path)
                if content:
                    self._log(f"Indexing {doc_path} from {repo}")
                    turns.append({
                        "role": "USER",
                        "content": f"[{doc_path} from {repo}]\n{content[:4000]}",
                        "source": f"github:{repo}/{doc_path}",
                        "classification": "constraint",
                    })

        # 2. Merged PR descriptions → decisions
        if include_prs:
            prs = self.get_prs(repo, state="closed", limit=pr_limit)
            for pr in prs:
                if pr.get("state") != "closed":
                    continue
                body = pr.get("body") or ""
                title = pr.get("title", "")
                merged = pr.get("merged_at")
                classification = self._classify_text(f"{title} {body}")
                if classification != "unknown" or merged:
                    turns.append({
                        "role": "AGENT",
                        "content": f"[PR #{pr['number']}: {title}]\n{body[:2000]}",
                        "source": f"github:{repo}/pull/{pr['number']}",
                        "classification": "decision" if merged else classification,
                        "created_at": merged or pr.get("closed_at", ""),
                    })
                self._log(f"PR #{pr['number']} → {classification}")

        # 3. Commit messages → decisions, abandoned attempts
        if include_commits:
            commits = self.get_commits(repo, limit=commit_limit)
            for commit in commits:
                message = commit.get("commit", {}).get("message", "")[:800]
                if not message:
                    continue
                classification = self._classify_text(message)
                # Revert commits → abandoned attempts
                if message.lower().startswith("revert"):
                    classification = "attempt"
                if classification != "unknown":
                    turns.append({
                        "role": "AGENT",
                        "content": f"[Commit {commit.get('sha', '')[:7]}] {message}",
                        "source": f"github:{repo}/commit/{commit.get('sha', '')[:7]}",
                        "classification": classification,
                        "created_at": commit.get("commit", {}).get("author", {}).get("date", ""),
                    })

        self._log(f"Extracted {len(turns)} turns from {repo}")
        return turns

    def ingest_repo(
        self,
        repo: str,
        memory,  # CollabMemory instance
        session_id: str | None = None,
        dry_run: bool = False,
        **kwargs,
    ) -> dict:
        """
        Full pipeline: extract turns from a GitHub repo and ingest into CollabMemory.

        Args:
            repo: "owner/repo" e.g. "OHACO-LABS/collab-memory"
            memory: CollabMemory instance
            session_id: optional session ID override
            dry_run: if True, print turns but don't save
        """
        turns = self.extract_turns_from_repo(repo, **kwargs)
        sid = session_id or f"github:{repo.replace('/', '_')}"

        if dry_run:
            print(f"\n[DRY RUN] {len(turns)} turns from {repo}:")
            for t in turns:
                print(f"  [{t['classification'].upper()}] {t['content'][:80]}...")
            return {"repo": repo, "turns": len(turns), "dry_run": True}

        ingested = 0
        for turn in turns:
            try:
                memory.check_in(
                    session_id=sid,
                    human_text="",
                    agent_text=turn["content"],
                )
                ingested += 1
            except Exception as e:
                self._log(f"Failed to ingest turn: {e}")

        return {
            "repo": repo,
            "session_id": sid,
            "turns_extracted": len(turns),
            "turns_ingested": ingested,
        }

    # ── Skill indexing ───────────────────────────────────────────────────────

    def index_as_skill(
        self,
        repo: str,
        path: str = "README.md",
        tags: list[str] | None = None,
    ) -> dict:
        """
        Fetch a file from a GitHub repo and return it as a Skill dict
        ready to POST to /skills.
        """
        content = self.get_file_content(repo, path)
        if not content:
            return {"error": f"Could not fetch {path} from {repo}"}
        return {
            "name": f"{repo} — {path}",
            "url": f"https://github.com/{repo}/blob/main/{path}",
            "summary": f"From {repo}/{path}",
            "content": content[:8000],
            "tags": tags or [repo.split("/")[0].lower(), "github"],
            "source_type": "guide",
        }

    # ── CLI helper ───────────────────────────────────────────────────────────

    def cli_summary(self, repo: str) -> None:
        """Print a summary of what would be ingested from a repo."""
        prs = self.get_prs(repo, limit=5)
        commits = self.get_commits(repo, limit=5)
        print(f"\n📁 {repo}")
        print(f"  PRs (closed):   {len(prs)}")
        print(f"  Recent commits: {len(commits)}")
        for pr in prs[:3]:
            print(f"    PR #{pr['number']}: {pr.get('title', '')[:60]}")
        for c in commits[:3]:
            msg = c.get("commit", {}).get("message", "")[:60]
            sha = c.get("sha", "")[:7]
            print(f"    [{sha}] {msg}")
