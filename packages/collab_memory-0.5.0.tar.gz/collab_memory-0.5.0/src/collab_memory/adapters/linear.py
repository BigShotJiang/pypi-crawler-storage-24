"""
adapters/linear.py — Linear.app conversation adapter.

Fetches issues and comments from Linear via GraphQL and converts them
into the collab-memory turn format ("USER: ..." / "AGENT: ...").

Linear issues + comment threads are where decisions live —
the description is the proposal, comments are the deliberation,
and status changes map cleanly to DecisionClose and AbandonedAttempt.

Requirements:
    pip install requests  (already in standard envs)
    LINEAR_API_KEY=lin_api_...  in your .env

Usage:
    from collab_memory.adapters.linear import parse_linear_issues

    turns = parse_linear_issues(
        api_key="lin_api_...",
        team_key="ENG",          # Linear team identifier
        label="architecture",    # optional label filter
        max_issues=20,
    )
    results = encode_session(turns, session_id="linear_import_001")
"""

from __future__ import annotations

import os
import re
from datetime import datetime
from typing import Any

try:
    import requests as _requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    _REQUESTS_AVAILABLE = False


# ─── GraphQL Queries ──────────────────────────────────────────────────────────

_ISSUES_QUERY = """
query Issues($first: Int!, $after: String, $teamId: ID) {
  issues(
    first: $first
    after: $after
    filter: {
      team: { id: { eq: $teamId } }
    }
    orderBy: updatedAt
  ) {
    pageInfo { hasNextPage endCursor }
    nodes {
      id
      title
      description
      state { name type }
      priority
      createdAt
      updatedAt
      creator { name displayName }
      assignee { name displayName }
      labels { nodes { name } }
      comments(first: 50, orderBy: createdAt) {
        nodes {
          id
          body
          createdAt
          user { name displayName }
        }
      }
    }
  }
}
"""

_ALL_ISSUES_QUERY = """
query AllIssues($first: Int!, $after: String) {
  issues(
    first: $first
    after: $after
    orderBy: updatedAt
  ) {
    pageInfo { hasNextPage endCursor }
    nodes {
      id
      title
      description
      state { name type }
      priority
      createdAt
      updatedAt
      creator { name displayName }
      assignee { name displayName }
      labels { nodes { name } }
      comments(first: 50, orderBy: createdAt) {
        nodes {
          id
          body
          createdAt
          user { name displayName }
        }
      }
    }
  }
}
"""


# ─── Client ───────────────────────────────────────────────────────────────────

class LinearClient:
    """Minimal Linear GraphQL client."""

    ENDPOINT = "https://api.linear.app/graphql"

    def __init__(self, api_key: str):
        if not _REQUESTS_AVAILABLE:
            raise ImportError("requests is required: pip install requests")
        self._api_key = api_key
        self._headers = {
            "Authorization": api_key,
            "Content-Type": "application/json",
        }

    def query(self, query: str, variables: dict | None = None) -> dict:
        """Execute a GraphQL query."""
        import requests
        resp = requests.post(
            self.ENDPOINT,
            json={"query": query, "variables": variables or {}},
            headers=self._headers,
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        if "errors" in data:
            raise ValueError(f"Linear API error: {data['errors']}")
        return data.get("data", {})

    def get_team_id(self, team_key: str) -> str | None:
        """Resolve team key (e.g. 'LOG') to Linear team ID."""
        data = self.query("{ teams { nodes { id key } } }")
        for team in data.get("teams", {}).get("nodes", []):
            if team.get("key", "").upper() == team_key.upper():
                return team["id"]
        return None

    def get_issues(
            self,
            team_key: str | None = None,
            label: str | None = None,
            max_issues: int = 50,
    ) -> list[dict]:
        """Fetch issues with pagination."""
        all_issues = []
        after = None
        per_page = min(max_issues, 50)

        # Resolve team key → ID for filtered query
        team_id = self.get_team_id(team_key) if team_key else None
        query = _ISSUES_QUERY if team_id else _ALL_ISSUES_QUERY

        while len(all_issues) < max_issues:
            variables: dict = {"first": per_page, "after": after}
            if team_id:
                variables["teamId"] = team_id

            data = self.query(query, variables)
            page = data.get("issues", {})
            nodes = page.get("nodes", [])
            all_issues.extend(nodes)

            page_info = page.get("pageInfo", {})
            if not page_info.get("hasNextPage") or len(nodes) == 0:
                break
            after = page_info.get("endCursor")

        # Apply label filter in Python
        if label:
            label_lower = label.lower()
            all_issues = [
                i for i in all_issues
                if any(
                    label_lower in lbl.get("name", "").lower()
                    for lbl in i.get("labels", {}).get("nodes", [])
                )
            ]

        return all_issues[:max_issues]


# ─── Turn Conversion ──────────────────────────────────────────────────────────

def _display_name(user: dict | None) -> str:
    if not user:
        return "Team"
    return user.get("displayName") or user.get("name") or "Team"


def _clean_md(text: str) -> str:
    """Strip markdown to plain text (rough)."""
    text = re.sub(r'!\[.*?\]\(.*?\)', '', text)  # images
    text = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', text)  # links
    text = re.sub(r'#{1,6}\s+', '', text)  # headers
    text = re.sub(r'[*_]{1,2}([^*_]+)[*_]{1,2}', r'\1', text)  # bold/italic
    text = re.sub(r'`{1,3}[^`]*`{1,3}', '', text)  # code
    text = re.sub(r'\n{3,}', '\n\n', text)  # excess newlines
    return text.strip()


def _state_signal(state: dict) -> str | None:
    """Map Linear state type to a collab-memory signal prefix."""
    state_type = (state or {}).get("type", "")
    state_name = (state or {}).get("name", "")
    if state_type == "cancelled":
        return f"[CANCELLED: {state_name}]"
    elif state_type == "completed":
        return f"[COMPLETED: {state_name}]"
    elif state_type in ("started", "inProgress"):
        return f"[IN PROGRESS: {state_name}]"
    return None


def issue_to_turns(issue: dict) -> list[str]:
    """
    Convert a single Linear issue (with comments) to collab-memory turns.

    Mapping:
      - Issue description        → USER: (the proposal / problem statement)
      - Comments                 → AGENT: (discussion, decisions, feedback)
      - Status change signals    → appended as AGENT context
    """
    turns = []
    title = issue.get("title", "Untitled")
    description = _clean_md(issue.get("description") or "")
    creator = _display_name(issue.get("creator"))
    state = issue.get("state") or {}
    labels = [n.get("name", "") for n in issue.get("labels", {}).get("nodes", [])]
    label_str = f" [{', '.join(labels)}]" if labels else ""

    # Lead turn: the issue itself
    user_turn_parts = [f"ISSUE: {title}{label_str}"]
    if description:
        user_turn_parts.append(description[:600])
    state_sig = _state_signal(state)
    if state_sig:
        user_turn_parts.append(state_sig)

    turns.append(f"USER: {chr(10).join(user_turn_parts)}")

    # Comment turns: each comment is an AGENT response
    comments = issue.get("comments", {}).get("nodes", [])
    for comment in comments:
        body = _clean_md(comment.get("body") or "")
        if not body or len(body) < 10:
            continue
        commenter = _display_name(comment.get("user"))
        # Treat the issue creator's comments as USER, others as AGENT
        role = "USER" if commenter == creator else "AGENT"
        turns.append(f"{role}: [{commenter}] {body[:500]}")

    # Status close turn if resolved
    if state.get("type") in ("completed", "cancelled"):
        assignee = _display_name(issue.get("assignee"))
        verb = "closed" if state.get("type") == "completed" else "cancelled"
        turns.append(
            f"AGENT: Issue {verb} by {assignee}. "
            f"Final state: {state.get('name', 'done')}."
        )

    return turns


# ─── Public API ───────────────────────────────────────────────────────────────

def parse_linear_issues(
        api_key: str | None = None,
        team_key: str | None = None,
        label: str | None = None,
        issue_ids: list[str] | None = None,
        max_issues: int = 50,
        max_turns: int | None = None,
) -> list[str]:
    """
    Fetch Linear issues and convert to collab-memory turns.

    Args:
        api_key:     Linear personal API key (defaults to LINEAR_API_KEY env var)
        team_key:    Linear team identifier, e.g. "ENG" or "PROD"
        label:       Filter by label name (case-insensitive substring match)
        issue_ids:   Specific issue IDs to fetch (skips team query if set)
        max_issues:  Max issues to process (default 50)
        max_turns:   Cap total turn output (default: no cap)

    Returns:
        List of "USER: ..." / "AGENT: ..." turn strings suitable for encode_session()
    """
    key = api_key or os.environ.get("LINEAR_API_KEY")
    if not key:
        raise ValueError(
            "No Linear API key provided. "
            "Pass api_key= or set LINEAR_API_KEY in your environment."
        )

    client = LinearClient(api_key=key)

    issues = client.get_issues(
        team_key=team_key,
        label=label,
        max_issues=max_issues,
    )

    all_turns: list[str] = []
    for issue in issues:
        all_turns.extend(issue_to_turns(issue))

    if max_turns:
        all_turns = all_turns[:max_turns]

    return all_turns


def list_teams(api_key: str | None = None) -> list[dict]:
    """List all Linear teams accessible with this API key."""
    key = api_key or os.environ.get("LINEAR_API_KEY")
    if not key:
        raise ValueError("No Linear API key. Set LINEAR_API_KEY.")
    client = LinearClient(api_key=key)
    data = client.query("{ teams { nodes { id key name } } }")
    return data.get("teams", {}).get("nodes", [])


# ─── CLI ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, json

    api_key = os.environ.get("LINEAR_API_KEY")
    if not api_key:
        print("Set LINEAR_API_KEY in your environment.")
        sys.exit(1)

    print("Linear teams:")
    teams = list_teams(api_key)
    for t in teams:
        print(f"  {t['key']}: {t['name']}")

    team_key = sys.argv[1] if len(sys.argv) > 1 else None
    label = sys.argv[2] if len(sys.argv) > 2 else None
    turns = parse_linear_issues(api_key=api_key, team_key=team_key, label=label, max_issues=10)

    print(f"\n{len(turns)} turns from Linear:")
    for t in turns[:20]:
        print(f"  {t[:100]}")
