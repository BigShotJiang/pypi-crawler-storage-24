"""graph/__init__.py — Graph backend exports."""

from .local import LocalGraphBackend
from .base import GraphBackend

__all__ = ["GraphBackend", "LocalGraphBackend"]


def get_backend(backend: str = "local", **kwargs):
    """
    Factory function for graph backends.

    Args:
        backend: "local" (JSON, no dependencies) or "graphiti" (temporal KG)
        **kwargs: passed to the backend constructor
    """
    if backend == "graphiti":
        from .graphiti_backend import GraphitiBackend
        return GraphitiBackend(**kwargs)
    return LocalGraphBackend(**kwargs)
