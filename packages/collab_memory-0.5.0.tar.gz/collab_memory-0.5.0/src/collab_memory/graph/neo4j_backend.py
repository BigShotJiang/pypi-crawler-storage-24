"""
graph/neo4j_backend.py — Direct Neo4j / AuraDB backend for collab-memory.

Uses the official `neo4j` Python driver directly (no graphiti-core required),
making it ideal for Neo4j AuraDB Free tier or any hosted Neo4j instance.

Usage:
    pip install neo4j
    export GRAPH_BACKEND=neo4j
    export NEO4J_URI=neo4j+s://xxxxxxxx.databases.neo4j.io
    export NEO4J_USER=neo4j
    export NEO4J_PASSWORD=your-aura-password

AuraDB Free signup: https://neo4j.com/cloud/platform/aura-graph-database/
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from ..schema import (
    Session, Entity, Decision, Attempt, Constraint, Preference,
    ExchangeRecord, Edge,
    PreferenceType, ConstraintOrigin, WORTHINESS_THRESHOLD,
)
from .base import GraphBackend

_NEO4J_AVAILABLE = False
try:
    from neo4j import GraphDatabase
    _NEO4J_AVAILABLE = True
except ImportError:
    pass


class Neo4jBackend(GraphBackend):
    """
    GraphBackend implementation using the official Neo4j Python driver.

    Compatible with:
    - Neo4j AuraDB Free (neo4j+s://...)
    - Local Neo4j Desktop (bolt://localhost:7687)
    - Neo4j Enterprise

    All data is stored as Cypher nodes/relationships.
    Decision, Constraint, Preference, Attempt nodes are each a label.
    """

    def __init__(
            self,
            uri: str = "bolt://localhost:7687",
            user: str = "neo4j",
            password: str = "password",
            database: str = "neo4j",
    ):
        if not _NEO4J_AVAILABLE:
            raise ImportError(
                "neo4j driver is not installed. Run: pip install neo4j"
            )
        self._driver = GraphDatabase.driver(uri, auth=(user, password))
        self._db = database
        self._ensure_constraints()

    def _ensure_constraints(self):
        """Create uniqueness constraints on first connect."""
        with self._driver.session(database=self._db) as session:
            for label in ("Decision", "Constraint", "Preference", "Attempt", "Session", "Project"):
                try:
                    session.run(
                        f"CREATE CONSTRAINT IF NOT EXISTS FOR (n:{label}) REQUIRE n.id IS UNIQUE"
                    )
                except Exception:
                    pass  # Constraint may already exist

    def _tx_write(self, query: str, **params):
        with self._driver.session(database=self._db) as session:
            session.run(query, **params)

    def _tx_read(self, query: str, **params) -> list[dict]:
        with self._driver.session(database=self._db) as session:
            result = session.run(query, **params)
            return [dict(r) for r in result]

    # ─── Write methods ────────────────────────────────────────────────────────

    def save_session(self, session: Session) -> None:
        self._tx_write(
            """
            MERGE (s:Session {id: $id})
            SET s.title = $title,
                s.started_at = $started_at,
                s.updated_at = $updated_at
            """,
            id=session.id,
            title=session.title or session.id,
            started_at=str(session.started_at or datetime.now(timezone.utc)),
            updated_at=str(datetime.now(timezone.utc)),
        )

    def save_exchange_record(self, record: ExchangeRecord) -> None:
        # Use getattr with fallbacks — field presence varies across schema versions
        ptype = getattr(record, "primitive_type", None)
        ptype_val = ptype.value if hasattr(ptype, "value") else str(ptype or "Exploration")
        self._tx_write(
            """
            MERGE (e:ExchangeRecord {id: $id})
            SET e.session_id = $session_id,
                e.raw_text = $raw_text,
                e.primitive_type = $primitive_type,
                e.worthiness_score = $worthiness_score,
                e.should_encode = $should_encode,
                e.flagged_for_review = $flagged,
                e.created_at = $created_at
            """,
            id=record.id,
            session_id=getattr(record, "session_id", "unknown"),
            raw_text=getattr(record, "raw_text", "") or "",
            primitive_type=ptype_val,
            worthiness_score=getattr(record, "worthiness_score", 0.0),
            should_encode=getattr(record, "should_encode", False),
            flagged=getattr(record, "flagged_for_review", False),
            created_at=str(getattr(record, "created_at", None) or datetime.now(timezone.utc)),
        )

    def save_project(self, project) -> None:
        """Write a Project node to the graph."""
        self._tx_write(
            """
            MERGE (p:Project {id: $id})
            SET p.name = $name,
                p.description = $description,
                p.owner = $owner,
                p.created_at = $created_at,
                p.updated_at = $updated_at
            """,
            id=project.id,
            name=project.name,
            description=getattr(project, "description", "") or "",
            owner=getattr(project, "owner", "") or "",
            created_at=str(getattr(project, "created_at", None) or datetime.now(timezone.utc)),
            updated_at=str(datetime.now(timezone.utc)),
        )

    def get_projects(self) -> list[dict]:
        """Return all Project nodes."""
        rows = self._tx_read("MATCH (p:Project) RETURN p ORDER BY p.name")
        return [dict(r["p"]) for r in rows]

    def save_node(self, node: Decision | Attempt | Constraint | Preference | Entity) -> None:
        label = type(node).__name__
        props = {
            "id": node.id,
            "description": node.description,
            "session_id": getattr(node, "session_id", "unknown"),
            "project_id": getattr(node, "project_id", None) or "default",
            "created_at": str(getattr(node, "created_at", None) or datetime.now(timezone.utc)),
        }

        if isinstance(node, Decision):
            props["confidence"] = node.worthiness_score
            props["is_superseded"] = node.is_superseded
            props["rationale"] = node.rationale or ""
        elif isinstance(node, Constraint):
            props["origin"] = node.origin.value
            props["active"] = node.active
            props["scope"] = node.scope or ""
        elif isinstance(node, Preference):
            props["type"] = node.type.value
            props["confidence"] = node.confidence
            props["reinforcement_count"] = node.reinforcement_count
        elif isinstance(node, Attempt):
            props["abandoned"] = node.abandoned
            props["abandoned_because"] = node.abandoned_because or ""

        assignments = ", ".join(f"n.{k} = ${k}" for k in props if k != "id")
        self._tx_write(
            f"MERGE (n:{label} {{id: $id}}) SET {assignments}",
            **props,
        )

    def save_edge(self, edge: Edge) -> None:
        self._tx_write(
            """
            MATCH (a {id: $source_id}), (b {id: $target_id})
            MERGE (a)-[r:RELATES_TO {id: $id, type: $type}]->(b)
            SET r.rationale = $rationale, r.created_at = $created_at
            """,
            id=edge.id,
            source_id=edge.source_id,
            target_id=edge.target_id,
            type=edge.type.value,
            rationale=edge.rationale or "",
            created_at=str(datetime.now(timezone.utc)),
        )

    # ─── Read methods ──────────────────────────────────────────────────────────

    def get_decisions(self, session_id: str | None = None, project_id: str | None = None) -> list[Decision]:
        # Accept both `is_superseded` (encoder path) and `status` (roadmap migration path)
        base = (
            "MATCH (n:Decision) WHERE "
            "(n.is_superseded = false OR n.is_superseded IS NULL) "
            "AND (n.status IS NULL OR n.status = 'active')"
        )
        params: dict = {}
        if project_id:
            base += " AND (n.project_id = $pid OR n.project_id IS NULL)"
            params["pid"] = project_id
        if session_id:
            base += " AND n.session_id = $sid"
            params["sid"] = session_id
        rows = self._tx_read(base + " RETURN n ORDER BY n.confidence DESC", **params)
        results = []
        for r in rows:
            node = r["n"]
            try:
                results.append(Decision(
                    id=node["id"],
                    description=node["description"],
                    made_in=node.get("made_in", node.get("session_id", "unknown")),
                    rationale=node.get("rationale", ""),
                    confidence=node.get("confidence", WORTHINESS_THRESHOLD),
                    status=node.get("status", "active"),
                ))
            except Exception:
                pass
        return results

    def get_constraints(self, active_only: bool = True, project_id: str | None = None) -> list[Constraint]:
        query = "MATCH (n:Constraint)"
        clauses = []
        params: dict = {}
        if active_only:
            clauses.append("(n.active = true OR n.still_active = true)")
        if project_id:
            clauses.append("(n.project_id = $pid OR n.project_id IS NULL)")
            params["pid"] = project_id
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " RETURN n ORDER BY n.surfaced_at DESC"
        rows = self._tx_read(query, **params)
        results = []
        for r in rows:
            node = r["n"]
            try:
                results.append(Constraint(
                    id=node["id"],
                    description=node["description"],
                    surfaced_in=node.get("surfaced_in", node.get("session_id", "unknown")),
                    origin=ConstraintOrigin(node.get("origin", "explicit")),
                    still_active=node.get("still_active", node.get("active", True)),
                    scope=node.get("scope", ""),
                ))
            except Exception:
                pass
        return results

    def get_preferences(
            self,
            pref_type: str | None = None,
            confidence_min: float = 0.0,
            min_reinforcements: int = 0,
            project_id: str | None = None,
    ) -> list[Preference]:
        query = "MATCH (n:Preference) WHERE n.confidence >= $conf AND n.reinforcement_count >= $min_r"
        params: dict[str, Any] = {"conf": confidence_min, "min_r": min_reinforcements}
        if pref_type:
            query += " AND n.type = $ptype"
            params["ptype"] = pref_type
        if project_id:
            query += " AND (n.project_id = $pid OR n.project_id IS NULL)"
            params["pid"] = project_id
        query += " RETURN n ORDER BY n.confidence DESC"
        rows = self._tx_read(query, **params)
        results = []
        for r in rows:
            node = r["n"]
            try:
                results.append(Preference(
                    id=node["id"],
                    description=node["description"],
                    inferred_in=node.get("inferred_in", node.get("noted_in", node.get("session_id", "unknown"))),
                    type=PreferenceType(node.get("type", "process")),
                    confidence=node.get("confidence", 0.5),
                    reinforcement_count=node.get("reinforcement_count", 1),
                ))
            except Exception:
                pass
        return results

    def get_attempts(self, session_id: str | None = None) -> list[Attempt]:
        if session_id:
            rows = self._tx_read(
                "MATCH (n:Attempt {session_id: $sid}) RETURN n ORDER BY n.created_at DESC",
                sid=session_id,
            )
        else:
            rows = self._tx_read("MATCH (n:Attempt) RETURN n ORDER BY n.created_at DESC")
        return [
            Attempt(
                id=r["n"]["id"],
                description=r["n"]["description"],
                tried_in=r["n"].get("session_id", "unknown"),
                abandoned=r["n"].get("abandoned", True),
                abandoned_because=r["n"].get("abandoned_because", ""),
            )
            for r in rows
        ]

    def get_decision_chain(self, decision_id: str) -> dict:
        rows = self._tx_read(
            """
            MATCH (d:Decision {id: $did})-[r:RELATES_TO*0..3]-(related)
            RETURN d, r, related
            """,
            did=decision_id,
        )
        return {"decision_id": decision_id, "chain": rows, "backend": "neo4j"}

    def get_flagged_records(self) -> list[ExchangeRecord]:
        rows = self._tx_read(
            "MATCH (n:ExchangeRecord) WHERE n.should_encode = false AND n.worthiness_score >= $lo"
            " RETURN n ORDER BY n.worthiness_score DESC LIMIT 20",
            lo=WORTHINESS_THRESHOLD - 0.1,
        )
        return [
            ExchangeRecord(
                id=r["n"]["id"],
                session_id=r["n"].get("session_id", "unknown"),
                raw_text=r["n"].get("raw_text", ""),
                primitive_type=PrimitiveType(r["n"].get("primitive_type", "Exploration")),
                worthiness_score=r["n"].get("worthiness_score", 0.0),
                should_encode=r["n"].get("should_encode", False),
            )
            for r in rows
        ]

    def build_context_brief(
        self,
        entity_id: str | None = None,
        task_type: str | None = None,
        project_id: str | None = None,
    ) -> dict:
        """Build a structured context brief for session bootstrap."""
        try:
            decisions = self.get_decisions(project_id=project_id)
        except Exception:
            decisions = []
        try:
            constraints = self.get_constraints(active_only=True, project_id=project_id)
        except Exception:
            constraints = []
        try:
            preferences = self.get_preferences(project_id=project_id)
        except Exception:
            preferences = []
        try:
            attempts = self.get_attempts()
        except Exception:
            attempts = []

        # Node counts — safe against empty graph
        try:
            counts = self._tx_read(
                """
                MATCH (n)
                WHERE size(labels(n)) > 0
                RETURN labels(n)[0] AS label, count(n) AS cnt
                """
            )
            node_counts = {r["label"]: r["cnt"] for r in counts if r.get("label")}
        except Exception:
            node_counts = {}

        return {
            "active_decisions": [
                {
                    "id": d.id,
                    "description": d.description,
                    "confidence": getattr(d, 'worthiness_score', getattr(d, 'confidence', 0)),
                    "rationale": getattr(d, 'rationale', ''),
                }
                for d in decisions[:10]
            ],
            "active_constraints": [
                {
                    "id": c.id,
                    "description": c.description,
                    "origin": getattr(getattr(c, 'origin', None), 'value', str(getattr(c, 'origin', 'explicit'))),
                }
                for c in constraints[:10]
            ],
            "inferred_preferences": [
                {
                    "id": p.id,
                    "description": p.description,
                    "type": getattr(getattr(p, 'type', None), 'value', str(getattr(p, 'type', 'process'))),
                    "confidence": p.confidence,
                }
                for p in preferences[:10]
            ],
            "recent_attempts": [
                {
                    "id": a.id,
                    "description": a.description,
                    "abandoned": getattr(a, 'abandoned', True),
                }
                for a in attempts[:5]
            ],
            "caution_flags": [],
            "backend": "neo4j",
            "node_counts": node_counts,
            "summary": (
                f"{len(decisions)} active decisions, "
                f"{len(constraints)} constraints, "
                f"{len(preferences)} preferences — backend: Neo4jBackend"
            ),
        }


    # ─── Skills ───────────────────────────────────────────────────────────────

    def save_skill(self, skill) -> None:
        """Persist a Skill node to Neo4j."""
        self._tx_write(
            """
            MERGE (s:Skill {id: $id})
            SET s.name = $name,
                s.url = $url,
                s.summary = $summary,
                s.content = $content,
                s.tags = $tags,
                s.source_type = $source_type,
                s.added_by = $added_by,
                s.created_at = $created_at
            """,
            id=skill.id,
            name=skill.name,
            url=skill.url or "",
            summary=skill.summary or "",
            content=skill.content or "",
            tags=list(skill.tags) if skill.tags else [],
            source_type=skill.source_type.value if hasattr(skill.source_type, "value") else str(skill.source_type),
            added_by=skill.added_by or "user",
            created_at=str(skill.created_at),
        )

    def get_skills(self, tags=None, source_type=None, limit=100):
        """List skills, optionally filtered by tags or source type."""
        from ..schema import Skill, SkillSourceType
        query = "MATCH (s:Skill)"
        params: dict = {"limit": limit}
        filters = []
        if source_type:
            filters.append("s.source_type = $source_type")
            params["source_type"] = source_type
        if filters:
            query += " WHERE " + " AND ".join(filters)
        query += " RETURN s ORDER BY s.created_at DESC LIMIT $limit"
        try:
            rows = self._tx_read(query, **params)
        except Exception:
            return []
        result = []
        for r in rows:
            node = r["s"]
            # tag filter applied in Python (Neo4j list membership in Cypher is complex)
            if tags and not any(t in node.get("tags", []) for t in tags):
                continue
            try:
                result.append(Skill(
                    id=node["id"],
                    name=node["name"],
                    url=node.get("url", ""),
                    summary=node.get("summary", ""),
                    content=node.get("content", ""),
                    tags=node.get("tags", []),
                    source_type=SkillSourceType(node.get("source_type", "custom")),
                    added_by=node.get("added_by", "user"),
                ))
            except Exception:
                pass
        return result

    def search_skills(self, q: str, limit: int = 20):
        """Simple case-insensitive text search across skill name, summary, content, tags."""
        from ..schema import Skill, SkillSourceType
        q_lower = q.lower()
        all_skills = self.get_skills(limit=500)
        results = [
            s for s in all_skills
            if q_lower in s.name.lower()
            or q_lower in (s.summary or "").lower()
            or q_lower in (s.content or "").lower()
            or any(q_lower in t.lower() for t in (s.tags or []))
        ]
        return results[:limit]

    def test_connection(self) -> bool:
        """Verify the Neo4j connection is healthy. Used by the Setup Wizard."""
        try:
            self._tx_read("RETURN 1 AS ok")
            return True
        except Exception:
            return False

    def __del__(self):
        try:
            self._driver.close()
        except Exception:
            pass
