"""
graph/base.py — Abstract graph backend interface.

All graph backends must implement this interface. This allows swapping
the local JSON store for Graphiti without touching any other code.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from ..schema import (
    Session, Entity, Decision, Attempt, Constraint, Preference,
    ExchangeRecord, Edge, ClassificationResult
)


class GraphBackend(ABC):

    @abstractmethod
    def save_session(self, session: Session) -> None: ...

    @abstractmethod
    def save_exchange_record(self, record: ExchangeRecord) -> None: ...

    @abstractmethod
    def save_edge(self, edge: Edge) -> None: ...

    @abstractmethod
    def save_node(self, node: Decision | Attempt | Constraint | Preference | Entity) -> None: ...

    @abstractmethod
    def get_decisions(self, session_id: str | None = None) -> list[Decision]: ...

    @abstractmethod
    def get_constraints(self, active_only: bool = True) -> list[Constraint]: ...

    @abstractmethod
    def get_preferences(
        self,
        pref_type: str | None = None,
        confidence_min: float = 0.0,
        min_reinforcements: int = 0,
    ) -> list[Preference]: ...

    @abstractmethod
    def get_attempts(self, session_id: str | None = None) -> list[Attempt]: ...

    @abstractmethod
    def get_decision_chain(self, decision_id: str) -> dict: ...

    @abstractmethod
    def get_flagged_records(self) -> list[ExchangeRecord]: ...

    def ingest_result(self, result: ClassificationResult) -> None:
        """Store all output from a ClassificationResult."""
        self.save_exchange_record(result.exchange_record)
        for node in result.nodes:
            self.save_node(node)
        for edge in result.edges:
            self.save_edge(edge)
