"""
graph/graphiti_backend.py — Graphiti temporal knowledge graph backend.

Implements GraphBackend using Graphiti (github.com/getzep/graphiti),
enabling temporal edge traversal, cross-session decay, and proper
causal chain queries.

Requirements:
    pip install "collab-memory[graphiti]"
    # and a running FalkorDB or Neo4j instance

Environment:
    GRAPH_BACKEND=graphiti
    FALKORDB_URL=redis://localhost:6379   # or
    NEO4J_URI=bolt://localhost:7687
    NEO4J_USER=neo4j
    NEO4J_PASSWORD=password
"""

from __future__ import annotations

import asyncio
import json
import re
import uuid
from datetime import datetime, timezone
from typing import Any

from ..schema import (
    Session, Entity, Decision, Attempt, Constraint, Preference,
    ExchangeRecord, Edge,
    PrimitiveType, PreferenceType, ConstraintOrigin,
    WORTHINESS_THRESHOLD,
)
from .base import GraphBackend


_GRAPHITI_AVAILABLE = False
try:
    from graphiti_core import Graphiti
    from graphiti_core.nodes import EpisodeType
    _GRAPHITI_AVAILABLE = True
except ImportError:
    pass  # ImportError surfaced when GraphitiBackend() is instantiated


# ─── Episode body builders ────────────────────────────────────────────────────

def _decision_body(node: Decision) -> str:
    parts = [f"DECISION: {node.description}"]
    if node.alternatives_rejected:
        parts.append("Rejected alternatives: " + "; ".join(node.alternatives_rejected))
    if node.rationale:
        parts.append(f"Rationale: {node.rationale}")
    if node.is_superseded:
        parts.append("Status: SUPERSEDED")
    return "\n".join(parts)


def _constraint_body(node: Constraint) -> str:
    parts = [f"CONSTRAINT: {node.description}"]
    parts.append(f"Origin: {node.origin.value}")
    if node.scope:
        parts.append(f"Scope: {node.scope}")
    if not node.active:
        parts.append("Status: INACTIVE")
    return "\n".join(parts)


def _preference_body(node: Preference) -> str:
    parts = [f"PREFERENCE [{node.type.value}]: {node.description}"]
    parts.append(f"Confidence: {node.confidence:.2f} | Reinforcements: {node.reinforcement_count}")
    if node.examples:
        parts.append("Examples: " + "; ".join(node.examples[:3]))
    return "\n".join(parts)


def _attempt_body(node: Attempt) -> str:
    parts = [f"ABANDONED ATTEMPT: {node.description}"]
    if node.abandoned_because:
        parts.append(f"Abandoned because: {node.abandoned_because}")
    if node.replacement_decision_id:
        parts.append(f"Replaced by decision: {node.replacement_decision_id}")
    return "\n".join(parts)


def _exchange_body(record: ExchangeRecord) -> str:
    parts = [
        f"EXCHANGE [{record.primitive_type.value}]: session={record.session_id}",
        f"Worthiness: {record.worthiness_score:.2f} | Should encode: {record.should_encode}",
    ]
    if record.raw_text:
        parts.append(f"Text: {record.raw_text[:400]}")
    return "\n".join(parts)


# ─── Graphiti Backend ─────────────────────────────────────────────────────────

class GraphitiBackend(GraphBackend):
    """
    GraphBackend implementation using Graphiti temporal knowledge graph.

    All Graphiti operations are async; this backend runs them synchronously
    via a dedicated event loop so the existing synchronous API surface is preserved.
    If the calling context is already async, use GraphitiBackendAsync instead.
    """

    def __init__(
            self,
            uri: str = "redis://localhost:6379",  # FalkorDB default
            neo4j_uri: str | None = None,
            neo4j_user: str = "neo4j",
            neo4j_password: str = "password",
            group_id: str = "collab_memory",
    ):
        if not _GRAPHITI_AVAILABLE:
            raise ImportError(
                "graphiti-core is not installed. "
                "Run: pip install 'collab-memory[graphiti]'"
            )

        self.group_id = group_id
        self._loop = asyncio.new_event_loop()

        # Initialize Graphiti with appropriate driver
        if neo4j_uri:
            from graphiti_core.driver.neo4j import Neo4jDriver
            driver = Neo4jDriver(neo4j_uri, neo4j_user, neo4j_password)
        else:
            from graphiti_core.driver.falkordb import FalkorDBDriver
            host, port = self._parse_redis_url(uri)
            driver = FalkorDBDriver(host=host, port=port)

        self._g = self._loop.run_until_complete(
            self._init_graphiti(driver)
        )

    @staticmethod
    def _parse_redis_url(url: str) -> tuple[str, int]:
        url = url.replace("redis://", "")
        parts = url.split(":")
        host = parts[0] or "localhost"
        port = int(parts[1]) if len(parts) > 1 else 6379
        return host, port

    async def _init_graphiti(self, driver: Any) -> "Graphiti":
        g = Graphiti(driver=driver)
        await g.build_indices_and_constraints()
        return g

    def _run(self, coro) -> Any:
        return self._loop.run_until_complete(coro)

    # ─── Write methods ────────────────────────────────────────────────────────

    def save_session(self, session: Session) -> None:
        self._run(self._g.add_episode(
            name=f"session:{session.id}",
            episode_body=f"SESSION: {session.title or session.id}\nStarted: {session.started_at}",
            source_description="collab-memory session metadata",
            reference_time=session.started_at or datetime.now(timezone.utc),
            group_id=self.group_id,
        ))

    def save_exchange_record(self, record: ExchangeRecord) -> None:
        self._run(self._g.add_episode(
            name=f"exchange:{record.id}",
            episode_body=_exchange_body(record),
            source_description=f"exchange from session {record.session_id}",
            reference_time=record.created_at or datetime.now(timezone.utc),
            group_id=self.group_id,
        ))

    def save_node(self, node: Decision | Attempt | Constraint | Preference | Entity) -> None:
        label = type(node).__name__
        ref_time = getattr(node, "created_at", None) or datetime.now(timezone.utc)

        if isinstance(node, Decision):
            body = _decision_body(node)
        elif isinstance(node, Constraint):
            body = _constraint_body(node)
        elif isinstance(node, Preference):
            body = _preference_body(node)
        elif isinstance(node, Attempt):
            body = _attempt_body(node)
        else:
            body = f"{label}: {getattr(node, 'description', str(node))}"

        self._run(self._g.add_episode(
            name=f"{label.lower()}:{node.id}",
            episode_body=body,
            source_description=f"collab-memory {label} node from {getattr(node, 'session_id', 'unknown')}",
            reference_time=ref_time,
            group_id=self.group_id,
        ))

    def save_edge(self, edge: Edge) -> None:
        # Graphiti manages edges internally via its episode parsing.
        # For explicit edge semantics (SUPERSEDES, CLOSED_BY) we add a
        # relational episode that Graphiti's LLM will parse into edges.
        self._run(self._g.add_episode(
            name=f"edge:{edge.id}",
            episode_body=(
                f"RELATIONSHIP [{edge.type.value}]: "
                f"{edge.source_id} → {edge.target_id}"
                + (f"\nReason: {edge.rationale}" if edge.rationale else "")
            ),
            source_description="collab-memory edge",
            reference_time=datetime.now(timezone.utc),
            group_id=self.group_id,
        ))

    # ─── Read methods ─────────────────────────────────────────────────────────

    def _search(self, query: str, limit: int = 50) -> list[dict]:
        results = self._run(self._g.search(
            query=query,
            group_ids=[self.group_id],
            num_results=limit,
        ))
        return [r.fact if hasattr(r, "fact") else str(r) for r in results]

    def _parse_nodes_of_type(self, label: str, raw_facts: list[str]) -> list[str]:
        prefix = f"{label.upper()}:"
        return [f for f in raw_facts if f.strip().startswith(prefix)]

    def get_decisions(self, session_id: str | None = None) -> list[Decision]:
        query = "active decisions and choices made"
        if session_id:
            query += f" in session {session_id}"
        facts = self._search(query)
        out = []
        for fact in facts:
            if not fact.startswith("DECISION:"):
                continue
            node = Decision(
                id=str(uuid.uuid4()),
                description=fact.replace("DECISION:", "").split("\n")[0].strip(),
                session_id=session_id or "unknown",
                worthiness_score=WORTHINESS_THRESHOLD,
            )
            out.append(node)
        return out

    def get_constraints(self, active_only: bool = True) -> list[Constraint]:
        query = "active constraints and limitations"
        facts = self._search(query)
        out = []
        for fact in facts:
            if not fact.startswith("CONSTRAINT:"):
                continue
            # Parse active status
            if active_only and "Status: INACTIVE" in fact:
                continue
            node = Constraint(
                id=str(uuid.uuid4()),
                description=fact.replace("CONSTRAINT:", "").split("\n")[0].strip(),
                session_id="unknown",
                origin=ConstraintOrigin.EXPLICIT,
                active=True,
            )
            out.append(node)
        return out

    def get_preferences(
            self,
            pref_type: str | None = None,
            confidence_min: float = 0.0,
            min_reinforcements: int = 0,
    ) -> list[Preference]:
        query = f"user preferences and working style{' ' + pref_type if pref_type else ''}"
        facts = self._search(query)
        out = []
        for fact in facts:
            if not fact.startswith("PREFERENCE"):
                continue
            # Parse type from bracket notation: PREFERENCE [technical]:
            ptype_match = re.search(r'\[(\w+)\]', fact)
            ptype_str = ptype_match.group(1) if ptype_match else "process"
            try:
                ptype = PreferenceType(ptype_str)
            except ValueError:
                ptype = PreferenceType.PROCESS
            if pref_type and ptype.value != pref_type:
                continue
            node = Preference(
                id=str(uuid.uuid4()),
                description=fact.split(":", 2)[-1].split("\n")[0].strip(),
                session_id="unknown",
                type=ptype,
                confidence=0.7,
            )
            out.append(node)
        return out

    def get_attempts(self, session_id: str | None = None) -> list[Attempt]:
        query = "abandoned attempts and discarded approaches"
        if session_id:
            query += f" in session {session_id}"
        facts = self._search(query)
        out = []
        for fact in facts:
            if not fact.startswith("ABANDONED ATTEMPT:"):
                continue
            node = Attempt(
                id=str(uuid.uuid4()),
                description=fact.replace("ABANDONED ATTEMPT:", "").split("\n")[0].strip(),
                session_id=session_id or "unknown",
                abandoned=True,
            )
            out.append(node)
        return out

    def get_decision_chain(self, decision_id: str) -> dict:
        facts = self._search(f"decision {decision_id} related exchanges and history")
        return {
            "decision_id": decision_id,
            "chain": facts,
            "backend": "graphiti",
        }

    def get_flagged_records(self) -> list[ExchangeRecord]:
        # Graphiti doesn't have a direct "flagged" concept — return empty for now.
        # A production implementation would tag flagged episodes with metadata.
        return []

    def build_context_brief(self) -> dict:
        """Build a context brief using Graphiti's semantic search."""
        decisions = self.get_decisions()
        constraints = self.get_constraints(active_only=True)
        preferences = self.get_preferences()
        attempts = self.get_attempts()

        # Fetch caution flags via targeted search
        caution_facts = self._search("risks warnings and caution flags", limit=10)
        cautions = [f for f in caution_facts if any(
            kw in f.lower() for kw in ("caution", "risk", "warn", "avoid", "not recommended")
        )]

        return {
            "active_decisions": [
                {"description": d.description, "id": d.id, "confidence": d.worthiness_score}
                for d in decisions[:10]
            ],
            "active_constraints": [
                {"description": c.description, "id": c.id, "origin": c.origin.value, "active": c.active}
                for c in constraints[:10]
            ],
            "inferred_preferences": [
                {"description": p.description, "id": p.id, "type": p.type.value, "confidence": p.confidence}
                for p in preferences[:10]
            ],
            "recent_attempts": [
                {"description": a.description, "id": a.id, "abandoned": a.abandoned}
                for a in attempts[:5]
            ],
            "caution_flags": cautions[:5],
            "backend": "graphiti",
        }

    def __del__(self):
        try:
            self._loop.close()
        except Exception:
            pass
