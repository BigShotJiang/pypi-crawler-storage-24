"""
graph/local.py — JSON file store graph backend.

Stores all graph data as a single JSON file. No dependencies.
Sufficient for prototype validation. Swap for Graphiti in production.
"""

from __future__ import annotations
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from .base import GraphBackend
from ..schema import (
    Attempt, Constraint, Decision, DecisionStatus, Edge,
    Entity, ExchangeRecord, Preference, Session, Skill,
)

_STORES = ("sessions", "decisions", "attempts", "constraints",
           "preferences", "exchange_records", "edges", "entities", "skills")


def _default(obj: Any) -> Any:
    if isinstance(obj, datetime):
        return obj.isoformat()
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")


class LocalGraphBackend(GraphBackend):
    """
    Persists everything to a single JSON file at `path`.
    Thread-safety is not a concern for the prototype.
    """

    def __init__(self, path: str = "./data/graph.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data: dict[str, dict[str, Any]] = {s: {} for s in _STORES}
        if self.path.exists():
            self._load()

    # ── Persistence ────────────────────────────────────────────────────────

    def _load(self) -> None:
        with open(self.path) as f:
            raw = json.load(f)
        for store in _STORES:
            self._data[store] = raw.get(store, {})

    def _save(self) -> None:
        with open(self.path, "w") as f:
            json.dump(self._data, f, default=_default, indent=2)

    # ── Write Operations ───────────────────────────────────────────────────

    def save_session(self, session: Session) -> None:
        self._data["sessions"][session.id] = session.model_dump()
        self._save()

    def save_exchange_record(self, record: ExchangeRecord) -> None:
        self._data["exchange_records"][record.id] = record.model_dump()
        self._save()

    def save_edge(self, edge: Edge) -> None:
        self._data["edges"][edge.id] = edge.model_dump()
        self._save()

    def save_node(self, node) -> None:
        if isinstance(node, Decision):
            self._data["decisions"][node.id] = node.model_dump()
        elif isinstance(node, Attempt):
            self._data["attempts"][node.id] = node.model_dump()
        elif isinstance(node, Constraint):
            self._data["constraints"][node.id] = node.model_dump()
        elif isinstance(node, Preference):
            self._data["preferences"][node.id] = node.model_dump()
        elif isinstance(node, Entity):
            self._data["entities"][node.id] = node.model_dump()
        elif isinstance(node, Skill):
            self._data["skills"][node.id] = node.model_dump()
        self._save()

    def save_skill(self, skill: Skill) -> None:
        """Persist a skill/knowledge reference to the graph."""
        self._data.setdefault("skills", {})
        self._data["skills"][skill.id] = skill.model_dump()
        self._save()

    def get_skills(
        self,
        tags: list[str] | None = None,
        source_type: str | None = None,
        limit: int = 100,
    ) -> list[Skill]:
        """Return skills, optionally filtered by tag or source_type."""
        self._data.setdefault("skills", {})
        items = [Skill(**v) for v in self._data["skills"].values()]
        if tags:
            items = [s for s in items if any(t in s.tags for t in tags)]
        if source_type:
            items = [s for s in items if s.source_type.value == source_type]
        return sorted(items, key=lambda s: s.added_at, reverse=True)[:limit]

    def search_skills(self, query: str, limit: int = 20) -> list[Skill]:
        """Full-text keyword search across name, summary, content, tags, and url."""
        self._data.setdefault("skills", {})
        q = query.lower()
        results = []
        for raw in self._data["skills"].values():
            skill = Skill(**raw)
            haystack = " ".join([
                skill.name,
                skill.summary,
                skill.content[:1000],
                " ".join(skill.tags),
                skill.url,
            ]).lower()
            if q in haystack:
                results.append(skill)
        return sorted(results, key=lambda s: s.added_at, reverse=True)[:limit]

    # ── Read Operations ────────────────────────────────────────────────────

    def get_decisions(self, session_id: str | None = None) -> list[Decision]:
        items = [Decision(**v) for v in self._data["decisions"].values()]
        if session_id:
            items = [d for d in items if d.made_in == session_id]
        return sorted(items, key=lambda d: d.made_at)

    def get_constraints(self, active_only: bool = True) -> list[Constraint]:
        items = [Constraint(**v) for v in self._data["constraints"].values()]
        if active_only:
            items = [c for c in items if c.still_active]
        return items

    def get_preferences(
        self,
        pref_type: str | None = None,
        confidence_min: float = 0.0,
        min_reinforcements: int = 0,
    ) -> list[Preference]:
        items = [Preference(**v) for v in self._data["preferences"].values()]
        if pref_type:
            items = [p for p in items if p.type.value == pref_type]
        items = [p for p in items if p.confidence >= confidence_min]
        items = [p for p in items if p.reinforcement_count >= min_reinforcements]
        return sorted(items, key=lambda p: p.confidence, reverse=True)

    def get_attempts(self, session_id: str | None = None) -> list[Attempt]:
        items = [Attempt(**v) for v in self._data["attempts"].values()]
        if session_id:
            items = [a for a in items if a.tried_in == session_id]
        return items

    def get_flagged_records(self) -> list[ExchangeRecord]:
        items = [ExchangeRecord(**v) for v in self._data["exchange_records"].values()]
        return [r for r in items if r.flagged_for_review]

    def get_decision_chain(self, decision_id: str) -> dict:
        """
        Decision archaeology — traces the causal chain for a given decision.
        Returns: the decision, the constraints that shaped it, the attempts
        that preceded it, and the exchange record (with raw text).
        """
        if decision_id not in self._data["decisions"]:
            return {"error": f"Decision {decision_id} not found"}

        decision = Decision(**self._data["decisions"][decision_id])

        # Find exchange record
        exc_record = None
        if decision.exchange_record_id:
            raw = self._data["exchange_records"].get(decision.exchange_record_id)
            if raw:
                exc_record = ExchangeRecord(**raw)

        # Find edges pointing to this decision
        related_edges = [
            Edge(**e) for e in self._data["edges"].values()
            if e.get("target_id") == decision_id or e.get("source_id") == decision_id
        ]

        # Find constraints linked via CONSTRAINED_BY
        constraint_ids = [
            e.target_id for e in related_edges if e.type == "CONSTRAINED_BY"
        ]
        constraints = [
            Constraint(**self._data["constraints"][cid])
            for cid in constraint_ids
            if cid in self._data["constraints"]
        ]

        # Find attempts closed by this decision
        attempt_ids = [
            e.source_id for e in related_edges if e.type == "CLOSED_BY"
        ]
        attempts = [
            Attempt(**self._data["attempts"][aid])
            for aid in attempt_ids
            if aid in self._data["attempts"]
        ]

        return {
            "decision": decision.model_dump(),
            "exchange_record": exc_record.model_dump() if exc_record else None,
            "shaped_by_constraints": [c.model_dump() for c in constraints],
            "preceded_by_attempts": [a.model_dump() for a in attempts],
        }

    # ── Context Brief ──────────────────────────────────────────────────────

    def build_context_brief(
        self,
        entity_id: str | None = None,
        task_type: str | None = None,
    ) -> dict:
        """Build the /memory/context response."""
        active_decisions = [
            d for d in self.get_decisions()
            if d.status == DecisionStatus.active
        ]
        active_constraints = self.get_constraints(active_only=True)
        preferences = self.get_preferences(confidence_min=0.5, min_reinforcements=1)
        recent_attempts = self.get_attempts()[-5:]  # last 5

        # Caution flags
        caution_flags = []
        all_decisions = self.get_decisions()

        # Flag reversed decisions that were re-made
        decision_descs = [d.description.lower()[:60] for d in all_decisions]
        seen = {}
        for d in all_decisions:
            key = d.description.lower()[:60]
            if key in seen:
                caution_flags.append(
                    f"Decision '{d.description[:80]}' has been made more than once — may be unstable"
                )
            seen[key] = True

        # Flag low-reinforcement preferences
        for p in preferences:
            if p.reinforcement_count == 1:
                caution_flags.append(
                    f"Preference '{p.description[:80]}' has low reinforcement count (1) — treat as tentative"
                )

        return {
            "active_decisions": [
                {
                    "id": d.id,
                    "description": d.description,
                    "rationale": d.rationale,
                    "confidence": d.confidence,
                    "made_in": d.made_in,
                }
                for d in active_decisions
            ],
            "active_constraints": [
                {
                    "id": c.id,
                    "description": c.description,
                    "origin": c.origin.value,
                    "scope": c.scope,
                }
                for c in active_constraints
            ],
            "inferred_preferences": [
                {
                    "id": p.id,
                    "type": p.type.value,
                    "domain": p.domain,
                    "description": p.description,
                    "evidence": p.evidence,
                    "confidence": p.confidence,
                    "reinforcement_count": p.reinforcement_count,
                }
                for p in preferences
            ],
            "recent_attempts": [
                {
                    "description": a.description,
                    "abandoned_because": a.abandoned_because,
                }
                for a in recent_attempts
            ],
            "caution_flags": caution_flags,
        }
