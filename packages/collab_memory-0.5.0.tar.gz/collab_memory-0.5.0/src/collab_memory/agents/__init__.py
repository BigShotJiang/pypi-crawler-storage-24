"""
agents/ — LangGraph-based 6-agent pipeline for collab-memory.

Pipeline: Intake → Classifier → Security → Graph Writer
All share a single PipelineState TypedDict.
Use pipeline.py to get the compiled runnable.
"""
from .pipeline import build_pipeline, run_pipeline

__all__ = ["build_pipeline", "run_pipeline"]
