"""
agents/graph_writer.py — Graph Writer agent.

Responsibility: Write confirmed nodes to the graph. Route inferred+novel
or contradiction-flagged nodes to the pending queue for HITL review.

Wraps existing encoder._build_nodes() and graph.ingest_result().

Routing logic:
  node.origin == "inferred"      → save_pending() (HITL required)
  contradiction_detected == True → save_pending() (human reviews conflict)
  else                           → ingest_result() (direct write)
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from ..encoder import _build_nodes
from ..schema import (
    ClassificationResult,
    ConstraintOrigin,
    ExchangeRecord,
    PrimitiveType,
)
from .state import PipelineState


def run_graph_writer(state: PipelineState, graph=None) -> PipelineState:
    """
    Graph Writer agent node.
    Builds nodes from classification result, then writes or queues each one.

    Args:
        state: Current pipeline state (must have llm_result, primitive_type, etc.)
        graph: Graph backend instance (injected by pipeline.py).
    """
    raw_text = state.get("raw_text", "")
    session_id = state.get("session_id", "unknown")
    turn_start = state.get("turn_start", 0)
    turn_end = state.get("turn_end", turn_start)
    llm_result = state.get("llm_result", {})
    primitive_type_str = state.get("primitive_type", "Exploration")
    final_score = state.get("final_score", 0.0)
    should_encode = state.get("should_encode", False)
    flagged = state.get("flagged", False)
    contradiction = state.get("contradiction_detected", False)
    classifier_reasoning = state.get("classifier_reasoning", "")

    try:
        ptype = PrimitiveType(primitive_type_str)
    except ValueError:
        ptype = PrimitiveType.Exploration

    # Always create the ExchangeRecord
    exchange_record = ExchangeRecord(
        session_id=session_id,
        turn_start=turn_start,
        turn_end=turn_end,
        raw_text=raw_text,
        primitive_type=ptype,
        worthiness_score=round(final_score, 3),
        extractor_version="0.5.0",
        flagged_for_review=flagged,
    )

    nodes: list = []
    edges: list = []
    nodes_generated: list[str] = []
    pending_confirmation = False

    if should_encode:
        nodes, edges = _build_nodes(llm_result, exchange_record, session_id)
        exchange_record.nodes_generated = [n.id for n in nodes]

    # Build ClassificationResult for ingest_result()
    result = ClassificationResult(
        exchange_record=exchange_record,
        nodes=nodes,
        edges=edges,
        should_encode=should_encode,
        classifier_reasoning=classifier_reasoning,
    )

    if graph is None:
        return {
            **state,
            "exchange_record_id": exchange_record.id,
            "nodes_generated": [],
            "pending_confirmation": False,
            "error": "graph backend not injected",
        }

    try:
        if nodes:
            for node in nodes:
                origin = getattr(node, "origin", None)
                origin_val = origin.value if hasattr(origin, "value") else str(origin or "")
                is_inferred = origin_val == "inferred"

                if is_inferred or contradiction:
                    # Route to HITL pending queue
                    if hasattr(graph, "save_pending"):
                        graph.save_pending(node)
                    pending_confirmation = True
                    nodes_generated.append(node.id)
                else:
                    # Direct write (explicit + no contradiction)
                    nodes_generated.append(node.id)

            # Write exchange record + confirmed nodes
            non_pending_nodes = [
                n for n in nodes
                if not pending_confirmation or (
                    getattr(getattr(n, "origin", None), "value", "") != "inferred"
                    and not contradiction
                )
            ]
            # Always write the ExchangeRecord and non-pending nodes
            graph.ingest_result(ClassificationResult(
                exchange_record=exchange_record,
                nodes=non_pending_nodes if not contradiction else [],
                edges=edges if not contradiction else [],
                should_encode=should_encode and not contradiction,
                classifier_reasoning=classifier_reasoning,
            ))
        else:
            # No nodes to write — just the ExchangeRecord
            graph.ingest_result(result)

    except Exception as e:
        return {
            **state,
            "exchange_record_id": exchange_record.id,
            "nodes_generated": [],
            "pending_confirmation": False,
            "error": f"Graph write error: {e}",
        }

    return {
        **state,
        "exchange_record_id": exchange_record.id,
        "nodes_generated": nodes_generated,
        "pending_confirmation": pending_confirmation,
        "classifier_reasoning": classifier_reasoning,
    }
