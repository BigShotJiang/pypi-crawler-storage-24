"""
agents/security.py — Security/Drift agent: contradiction detection.

Responsibility: Before writing to the graph, check whether the incoming
node conflicts with existing active nodes.

MVP implementation: keyword-based description overlap. No embeddings yet.
Semantic contradiction detection (Graphiti phase) will replace this.

Detected contradictions:
  - New Decision in same domain as existing active Decision
  - New Constraint that contradicts wording of existing active Constraint

When a contradiction is detected, the Graph Writer routes the new node
to the pending queue even if origin=explicit — requiring human review.
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

from .state import PipelineState

if TYPE_CHECKING:
    pass  # graph backend injected at runtime via _get_graph()

# Similarity threshold: what fraction of key words must overlap to flag
OVERLAP_THRESHOLD = 0.4

# Only run security check on these high-stakes types
CHECKED_TYPES = {"DecisionClose", "Override", "ConstraintSurface"}


def _word_overlap(a: str, b: str) -> float:
    """Simple word-level Jaccard similarity. 0.0–1.0."""
    def words(s: str) -> set[str]:
        return set(re.findall(r"\b\w{4,}\b", s.lower()))
    wa, wb = words(a), words(b)
    if not wa or not wb:
        return 0.0
    return len(wa & wb) / len(wa | wb)


def run_security(state: PipelineState, graph=None) -> PipelineState:
    """
    Security/Drift agent node.
    Queries existing graph nodes for potential contradictions.
    Sets contradiction_detected and contradiction_detail.

    Args:
        state: Current pipeline state.
        graph: Graph backend instance (injected by pipeline.py at build time).
    """
    ptype = state.get("primitive_type", "Exploration")
    llm_result = state.get("llm_result", {})
    incoming_description = llm_result.get("description", "")

    # Only check high-stakes types
    if ptype not in CHECKED_TYPES or not incoming_description or graph is None:
        return {
            **state,
            "contradiction_detected": False,
            "contradiction_detail": "",
        }

    try:
        # Query existing active nodes of the same type
        if ptype in ("DecisionClose", "Override"):
            existing = _fetch_active_decisions(graph)
        else:
            existing = _fetch_active_constraints(graph)

        # Check for keyword overlap
        for node in existing:
            existing_desc = node.get("description", "")
            overlap = _word_overlap(incoming_description, existing_desc)
            if overlap >= OVERLAP_THRESHOLD:
                detail = (
                    f"Possible conflict with existing node (overlap={overlap:.0%}): "
                    f'"{existing_desc[:120]}"'
                )
                return {
                    **state,
                    "contradiction_detected": True,
                    "contradiction_detail": detail,
                }

    except Exception as e:
        # Security failure is non-blocking — log and continue
        return {
            **state,
            "contradiction_detected": False,
            "contradiction_detail": f"Security check skipped (error: {e})",
        }

    return {
        **state,
        "contradiction_detected": False,
        "contradiction_detail": "",
    }


def _fetch_active_decisions(graph) -> list[dict]:
    """Fetch active Decision nodes from graph backend."""
    try:
        rows = graph._tx_read(
            "MATCH (d:Decision) WHERE d.status IN ['active', 'still_active'] "
            "RETURN d.description AS description LIMIT 50"
        )
        return [{"description": r.get("description", "")} for r in rows]
    except Exception:
        return []


def _fetch_active_constraints(graph) -> list[dict]:
    """Fetch active Constraint nodes from graph backend."""
    try:
        rows = graph._tx_read(
            "MATCH (c:Constraint) WHERE c.still_active = true "
            "RETURN c.description AS description LIMIT 50"
        )
        return [{"description": r.get("description", "")} for r in rows]
    except Exception:
        return []
