"""
agents/pipeline.py — LangGraph StateGraph: Intake → Classifier → Security → Graph Writer.

This is the main pipeline runnable. Import build_pipeline() to get a compiled
LangGraph runnable. Call run_pipeline(state, graph) to process an exchange.

Graph topology:
  START → intake → [route_after_intake] → classifier → security → graph_writer → END
                                         ↘ (low-signal drop) → END

Design decision: the graph backend is injected at call time (not at build time)
so the same compiled pipeline can be used with different graph backends
(e.g., test with LocalGraphBackend, production with Neo4jBackend).
"""
from __future__ import annotations

from functools import partial
from typing import Any, Callable

from .state import PipelineState
from .intake import run_intake, route_after_intake
from .classifier import run_classifier
from .security import run_security
from .graph_writer import run_graph_writer

# ─── Fallback: plain-function pipeline ────────────────────────────────────────
# Used when langgraph is unavailable (Render memory limit, etc.)
# Identical semantics, zero overhead.

def _run_plain_pipeline(state: PipelineState, graph=None) -> PipelineState:
    """Fallback: sequential plain-Python pipeline (no LangGraph overhead)."""
    state = run_intake(state)
    if not state.get("should_classify"):
        return state
    state = run_classifier(state)
    state = run_security(state, graph=graph)
    state = run_graph_writer(state, graph=graph)
    return state


# ─── LangGraph Pipeline ───────────────────────────────────────────────────────

def build_pipeline(graph=None):
    """
    Build and return the compiled LangGraph pipeline.

    Returns a callable that accepts PipelineState and returns PipelineState.
    Falls back to plain-function pipeline if langgraph is not installed.

    Args:
        graph: Graph backend instance (injected into Security + Graph Writer nodes).
    """
    try:
        from langgraph.graph import StateGraph, END, START

        # Bind graph backend into nodes that need it
        security_node = partial(run_security, graph=graph)
        writer_node = partial(run_graph_writer, graph=graph)

        workflow = StateGraph(PipelineState)
        workflow.add_node("intake", run_intake)
        workflow.add_node("classifier", run_classifier)
        workflow.add_node("security", security_node)
        workflow.add_node("graph_writer", writer_node)

        workflow.add_edge(START, "intake")
        workflow.add_conditional_edges(
            "intake",
            route_after_intake,
            {
                "classify": "classifier",
                "drop":     END,
            },
        )
        workflow.add_edge("classifier", "security")
        workflow.add_edge("security", "graph_writer")
        workflow.add_edge("graph_writer", END)

        compiled = workflow.compile()
        _BACKEND = "langgraph"

    except ImportError:
        # LangGraph not installed — use plain pipeline
        compiled = None
        _BACKEND = "plain"

    def _invoke(state: PipelineState) -> PipelineState:
        if compiled is not None:
            result = compiled.invoke(state)
            return result
        else:
            return _run_plain_pipeline(state, graph=graph)

    _invoke._backend = _BACKEND  # type: ignore[attr-defined]
    return _invoke


def run_pipeline(
    raw_text: str,
    session_id: str,
    turn_start: int = 0,
    turn_end: int | None = None,
    skip_llm: bool = False,
    graph=None,
) -> PipelineState:
    """
    Convenience wrapper: build pipeline + run in one call.

    Prefer caching the built pipeline (build_pipeline()) and calling
    the returned function directly in hot paths like /memory/ingest.

    Args:
        raw_text:    Raw exchange text to classify.
        session_id:  Session identifier for graph nodes.
        turn_start:  Turn index start.
        turn_end:    Turn index end (defaults to turn_start).
        skip_llm:    If True, use keyword-only classification.
        graph:       Graph backend instance.

    Returns:
        Final PipelineState after all agents have run.
    """
    pipeline = build_pipeline(graph=graph)
    state: PipelineState = {
        "raw_text": raw_text,
        "session_id": session_id,
        "turn_start": turn_start,
        "turn_end": turn_end if turn_end is not None else turn_start,
        "skip_llm": skip_llm,
    }
    return pipeline(state)


def get_pipeline_status(graph=None) -> dict[str, Any]:
    """Return pipeline configuration info for GET /memory/pipeline/status."""
    import os
    try:
        import langgraph
        backend = "langgraph"
        version = getattr(langgraph, "__version__", "unknown")
    except ImportError:
        backend = "plain"
        version = "N/A"

    return {
        "backend": backend,
        "langgraph_version": version,
        "llm_provider": os.environ.get("LLM_PROVIDER", "gemini"),
        "agents": ["intake", "classifier", "security", "graph_writer"],
        "graph_backend": type(graph).__name__ if graph else "none",
    }
