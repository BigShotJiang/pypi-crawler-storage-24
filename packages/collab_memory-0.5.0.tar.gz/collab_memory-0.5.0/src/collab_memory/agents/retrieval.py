"""
agents/retrieval.py — Retrieval agent.

Responsibility: Serve context|decisions|constraints|preferences from the graph.
Used by /memory/context endpoints, not the ingest pipeline.

This is a thin wrapper over graph.build_context_brief() so retrieval
can eventually be swapped for Graphiti semantic retrieval without
touching the API endpoints.
"""
from __future__ import annotations

from .state import PipelineState


def run_retrieval(state: PipelineState, graph=None) -> PipelineState:
    """
    Retrieval agent node. Populates context_brief in state.

    Args:
        state: Must contain optional entity_id, task_type fields.
        graph: Graph backend instance.
    """
    if graph is None:
        return {**state, "context_brief": {}, "error": "graph backend not injected"}

    entity_id = state.get("entity_id")
    task_type = state.get("task_type")

    try:
        brief = graph.build_context_brief(
            entity_id=entity_id,
            task_type=task_type,
        )
        return {**state, "context_brief": brief}
    except Exception as e:
        return {**state, "context_brief": {}, "error": f"Retrieval error: {e}"}


def get_context_brief(graph, entity_id: str | None = None, task_type: str | None = None) -> dict:
    """
    Convenience function — bypasses LangGraph for simple context queries.
    Used directly by /memory/context endpoint.
    """
    state: PipelineState = {
        "raw_text": "",
        "session_id": "",
        "turn_start": 0,
    }
    if entity_id:
        state["entity_id"] = entity_id  # type: ignore[typeddict-unknown-key]
    if task_type:
        state["task_type"] = task_type  # type: ignore[typeddict-unknown-key]

    result = run_retrieval(state, graph=graph)
    return result.get("context_brief", {})
