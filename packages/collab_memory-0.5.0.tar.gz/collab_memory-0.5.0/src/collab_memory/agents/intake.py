"""
agents/intake.py — Intake agent: keyword pre-screen.

Responsibility: fast keyword scoring to drop low-signal text before
hitting the LLM classifier. Cost: zero API calls.

Routing:
  keyword_score < 0.10  → should_classify = False (pipeline drops this exchange)
  keyword_score >= 0.10 → should_classify = True  (continues to Classifier)
"""
from __future__ import annotations

from ..encoder import _keyword_score
from .state import PipelineState

# Drop threshold — below this, not worth classifying.
# 0.10 is deliberately lower than worthiness threshold (0.4) to let
# the LLM have the final say on borderline exchanges.
DROP_THRESHOLD = 0.10


def run_intake(state: PipelineState) -> PipelineState:
    """
    Keyword pre-screen agent node.
    Sets keyword_score and should_classify on the state.
    """
    raw_text = state.get("raw_text", "")

    if not raw_text or not raw_text.strip():
        return {
            **state,
            "keyword_score": 0.0,
            "should_classify": False,
        }

    score = _keyword_score(raw_text)

    return {
        **state,
        "keyword_score": round(score, 3),
        "should_classify": score >= DROP_THRESHOLD,
    }


def route_after_intake(state: PipelineState) -> str:
    """LangGraph conditional edge: classify or drop."""
    if state.get("should_classify"):
        return "classify"
    return "drop"
