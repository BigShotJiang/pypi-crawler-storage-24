"""
tests/test_encoder.py — Encoder tests using real exchange examples
drawn from our actual collaboration sessions.

Run with: pytest tests/ -v
LLM tests are skipped by default (use --run-llm flag to enable).
"""

from __future__ import annotations
import pytest
from datetime import datetime

from src.collab_memory.schema import (
    PrimitiveType, DecisionStatus, PreferenceType, HIGH_SIGNAL_PRIMITIVES
)
from src.collab_memory.encoder import encode_exchange, encode_session, _keyword_score
from src.collab_memory.graph.local import LocalGraphBackend

SESSION_ID = "test_session_001"


# ─── Fixtures: Real exchanges from our sessions ────────────────────────────────
# These are drawn directly from conversations in this project.

FIXTURE_OVERRIDE = """\
USER: I'm fine with that, but it sounds like we should be researching the choke points
AGENT: Yes — exactly right. Let me go research what's actually been tried, what's failed, and where the real friction is before we commit to an approach.
"""

FIXTURE_DECISION_CLOSE = """\
USER: better - I think we can proceed
AGENT: Schema is hardened. Here's what changed from the light version... Session 2 is ready to begin whenever you are.
"""

FIXTURE_CONSTRAINT_SURFACE = """\
USER: I'll follow your lead here - this is your build. Be sure to think about your current challenges with being able to complete a project of this scale, like current limitations with memory and persistence, data integrity
AGENT: The core irony first: I'm an agent with memory problems trying to build a memory system. Between sessions, I start from ~zero. I have KIs and artifacts, but I have to retrieve context, not remember it.
"""

FIXTURE_PREFERENCE_REVEAL = """\
USER: This looks ok, a bit light, but if you feel it's enough, we'll proceed.
AGENT: Honest reaction: you're right that it's light. I defaulted to minimum viable schema to avoid over-engineering before we hit real data.
"""

FIXTURE_ABANDONED_ATTEMPT = """\
USER: Actually let's not use a vector database for this, it's the wrong abstraction
AGENT: Agreed — a vector DB would give us retrieval by similarity but we'd lose the causal structure entirely. The graph approach is correct here. Abandon the vector DB path for now.
"""

FIXTURE_EXECUTION = """\
AGENT: I've updated the schema to include the ExchangeRecord node type.
The file has been saved to schema_v1.md.
"""

FIXTURE_CONFIRMATION = """\
USER: Looks good, continue
AGENT: Great, moving on to the next component.
"""

FIXTURE_AMBIGUOUS = """\
USER: Hmm, I'm not sure about this approach
AGENT: Let me explain the tradeoffs. The main concern is that if we go with option A we get simplicity but lose auditability.
"""


# ─── Keyword Pre-Screen Tests ─────────────────────────────────────────────────

class TestKeywordScorer:

    def test_override_scores_high(self):
        score = _keyword_score(FIXTURE_OVERRIDE)
        assert score >= 0.4, f"Override exchange scored too low: {score}"

    def test_decision_scores_high(self):
        score = _keyword_score(FIXTURE_DECISION_CLOSE)
        assert score >= 0.3, f"Decision exchange scored too low: {score}"

    def test_execution_scores_low(self):
        score = _keyword_score(FIXTURE_EXECUTION)
        assert score < 0.4, f"Execution exchange scored too high: {score}"

    def test_confirmation_scores_low(self):
        score = _keyword_score(FIXTURE_CONFIRMATION)
        assert score < 0.4, f"Confirmation exchange scored too high: {score}"

    def test_abandoned_attempt_scores_high(self):
        score = _keyword_score(FIXTURE_ABANDONED_ATTEMPT)
        assert score >= 0.3, f"Abandoned attempt scored too low: {score}"

    def test_constraint_scores_high(self):
        score = _keyword_score(FIXTURE_CONSTRAINT_SURFACE)
        assert score >= 0.2, f"Constraint exchange scored too low: {score}"


# ─── Encoder Tests (keyword-only / skip_llm=True) ────────────────────────────

class TestEncoderKeywordOnly:

    def test_override_produces_exchange_record(self):
        result = encode_exchange(
            raw_text=FIXTURE_OVERRIDE,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
        )
        assert result.exchange_record is not None
        assert result.exchange_record.session_id == SESSION_ID
        assert result.exchange_record.worthiness_score >= 0.0

    def test_override_should_encode(self):
        result = encode_exchange(
            raw_text=FIXTURE_OVERRIDE,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
        )
        assert result.should_encode is True

    def test_execution_should_not_encode(self):
        result = encode_exchange(
            raw_text=FIXTURE_EXECUTION,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
        )
        assert result.should_encode is False

    def test_confirmation_should_not_encode(self):
        result = encode_exchange(
            raw_text=FIXTURE_CONFIRMATION,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
        )
        assert result.should_encode is False

    def test_ambiguous_is_flagged(self):
        result = encode_exchange(
            raw_text=FIXTURE_AMBIGUOUS,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
        )
        # Either flagged for review or just below threshold — not encoded as fact
        if result.exchange_record.worthiness_score <= 0.4:
            assert result.should_encode is False

    def test_exchange_record_always_created(self):
        """ExchangeRecord is created even for low-signal exchanges."""
        for fixture in [FIXTURE_EXECUTION, FIXTURE_CONFIRMATION, FIXTURE_AMBIGUOUS]:
            result = encode_exchange(
                raw_text=fixture,
                session_id=SESSION_ID,
                turn_start=0,
                skip_llm=True,
            )
            assert result.exchange_record is not None
            assert result.exchange_record.id.startswith("exc_")

    def test_high_signal_produces_nodes(self):
        result = encode_exchange(
            raw_text=FIXTURE_OVERRIDE,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
        )
        if result.should_encode:
            assert len(result.nodes) > 0

    def test_nodes_reference_exchange_record(self):
        result = encode_exchange(
            raw_text=FIXTURE_OVERRIDE,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
        )
        for node in result.nodes:
            assert hasattr(node, "exchange_record_id")
            assert node.exchange_record_id == result.exchange_record.id


# ─── Session Encoder Tests ────────────────────────────────────────────────────

class TestSessionEncoder:

    def test_encode_session_returns_results(self):
        turns = [
            FIXTURE_EXECUTION,
            FIXTURE_OVERRIDE,
            FIXTURE_CONFIRMATION,
            FIXTURE_ABANDONED_ATTEMPT,
        ]
        results = encode_session(turns, SESSION_ID, skip_llm=True)
        assert len(results) > 0

    def test_encode_session_skips_low_signal(self):
        turns = [FIXTURE_EXECUTION, FIXTURE_CONFIRMATION]
        results = encode_session(turns, SESSION_ID, skip_llm=True)
        # Low-signal alone should produce no results or all non-encoded
        for r in results:
            assert r.should_encode is False or r.exchange_record.worthiness_score < 0.4

    def test_encode_session_captures_high_signal(self):
        turns = [FIXTURE_EXECUTION, FIXTURE_OVERRIDE, FIXTURE_DECISION_CLOSE]
        results = encode_session(turns, SESSION_ID, skip_llm=True)
        encoded = [r for r in results if r.should_encode]
        assert len(encoded) >= 1


# ─── Graph Backend Tests ──────────────────────────────────────────────────────

class TestLocalGraphBackend:

    @pytest.fixture
    def graph(self, tmp_path):
        return LocalGraphBackend(path=str(tmp_path / "test_graph.json"))

    def test_ingest_and_retrieve_decision(self, graph):
        result = encode_exchange(
            raw_text=FIXTURE_OVERRIDE,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
        )
        graph.ingest_result(result)
        decisions = graph.get_decisions()
        # May have decisions if worthiness was above threshold
        assert isinstance(decisions, list)

    def test_exchange_record_always_stored(self, graph):
        result = encode_exchange(
            raw_text=FIXTURE_EXECUTION,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
        )
        graph.ingest_result(result)
        flagged = graph.get_flagged_records()
        assert isinstance(flagged, list)

    def test_context_brief_structure(self, graph):
        # Ingest several exchanges
        for i, fixture in enumerate([
            FIXTURE_OVERRIDE,
            FIXTURE_CONSTRAINT_SURFACE,
            FIXTURE_PREFERENCE_REVEAL,
        ]):
            result = encode_exchange(
                raw_text=fixture,
                session_id=SESSION_ID,
                turn_start=i,
                skip_llm=True,
            )
            graph.ingest_result(result)

        brief = graph.build_context_brief()
        assert "active_decisions" in brief
        assert "active_constraints" in brief
        assert "inferred_preferences" in brief
        assert "recent_attempts" in brief
        assert "caution_flags" in brief

    def test_decision_chain_returns_structure(self, graph):
        """Even if no decisions are stored, the response is a valid dict."""
        chain = graph.get_decision_chain("nonexistent_id")
        assert "error" in chain


# ─── LLM Tests (opt-in) ──────────────────────────────────────────────────────

def pytest_addoption(parser):
    parser.addoption("--run-llm", action="store_true", help="Run LLM-dependent tests")


@pytest.fixture
def run_llm(request):
    return request.config.getoption("--run-llm", default=False)


class TestEncoderWithLLM:

    def test_override_classified_correctly(self, run_llm):
        if not run_llm:
            pytest.skip("LLM tests skipped (use --run-llm to enable)")

        result = encode_exchange(
            raw_text=FIXTURE_OVERRIDE,
            session_id=SESSION_ID,
            turn_start=0,
        )
        assert result.exchange_record.primitive_type in HIGH_SIGNAL_PRIMITIVES
        assert result.exchange_record.worthiness_score > 0.4

    def test_constraint_surface_classified_correctly(self, run_llm):
        if not run_llm:
            pytest.skip("LLM tests skipped (use --run-llm to enable)")

        result = encode_exchange(
            raw_text=FIXTURE_CONSTRAINT_SURFACE,
            session_id=SESSION_ID,
            turn_start=0,
        )
        assert result.exchange_record.primitive_type in HIGH_SIGNAL_PRIMITIVES

    def test_preference_reveal_extracts_type(self, run_llm):
        if not run_llm:
            pytest.skip("LLM tests skipped (use --run-llm to enable)")

        result = encode_exchange(
            raw_text=FIXTURE_PREFERENCE_REVEAL,
            session_id=SESSION_ID,
            turn_start=0,
        )
        prefs = [n for n in result.nodes if hasattr(n, "type") and isinstance(n.type, PreferenceType)]
        if prefs:
            assert prefs[0].type is not None

    def test_execution_not_encoded_with_llm(self, run_llm):
        if not run_llm:
            pytest.skip("LLM tests skipped (use --run-llm to enable)")

        result = encode_exchange(
            raw_text=FIXTURE_EXECUTION,
            session_id=SESSION_ID,
            turn_start=0,
        )
        assert result.should_encode is False
