from __future__ import annotations

import re
import unicodedata
from typing import Sequence, TypeVar

ValueT = TypeVar("ValueT")


def normalize_whitespace(value: str) -> str:
    return " ".join(value.split())


def slugify(value: str, separator: str = "-") -> str:
    if not separator:
        raise ValueError("separator must not be empty")

    normalized: str = unicodedata.normalize("NFKD", value)
    ascii_value: str = normalized.encode("ascii", "ignore").decode("ascii")
    collapsed: str = re.sub(r"[^A-Za-z0-9]+", separator, ascii_value).strip(separator)
    slug: str = collapsed.lower()
    return slug or "value"


def chunked(values: Sequence[ValueT], size: int) -> list[list[ValueT]]:
    if size <= 0:
        raise ValueError("size must be greater than zero")

    return [list(values[index:index + size]) for index in range(0, len(values), size)]
