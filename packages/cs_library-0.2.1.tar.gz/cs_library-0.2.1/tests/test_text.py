from __future__ import annotations

import unittest

from cs_lib import chunked, normalize_whitespace, slugify


class TextHelpersTests(unittest.TestCase):
    def test_normalize_whitespace(self) -> None:
        self.assertEqual(normalize_whitespace("  hello   world\n"), "hello world")

    def test_slugify(self) -> None:
        self.assertEqual(slugify("CS Lib Ready"), "cs-lib-ready")

    def test_chunked(self) -> None:
        self.assertEqual(chunked([1, 2, 3, 4, 5], 2), [[1, 2], [3, 4], [5]])


if __name__ == "__main__":
    unittest.main()