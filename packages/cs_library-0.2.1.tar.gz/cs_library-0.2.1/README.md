# cs_library

`cs_library` is a compact Python package with dependency-free helpers for normalizing text, creating slugs, and splitting sequences into chunks.

## Installation

```bash
pip install cs_library
```

## Usage

```python
from cs_library import chunked, normalize_whitespace, slugify

text = "  Fast   and\nclean   utilities  "
print(normalize_whitespace(text))
print(slugify("CS Lib: Ready to Ship"))
print(chunked([1, 2, 3, 4, 5], 2))
```

## API

- `normalize_whitespace(value: str) -> str`
- `slugify(value: str, separator: str = "-") -> str`
- `chunked(values: Sequence[T], size: int) -> list[list[T]]`
