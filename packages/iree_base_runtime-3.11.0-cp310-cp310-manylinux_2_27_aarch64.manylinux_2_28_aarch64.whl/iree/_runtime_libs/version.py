# Auto-generated version info.
PACKAGE_SUFFIX = ""
VERSION = "3.11.0rc20260316"
REVISIONS = {"IREE": "e4a3b0405d7d23554da26403658d0e8c3c5ecf25"}
