from unittest.mock import Mock

from smart_bot_factory.event.decorators import registry
from smart_bot_factory.handlers.processing import event_processing


def test_get_event_handlers_uses_legacy_when_router_manager_empty(monkeypatch):
    legacy_event_handlers = {"legacy_event": {"handler": Mock()}}
    legacy_scheduled_tasks = {"legacy_task": {"handler": Mock()}}
    legacy_global_handlers = {"legacy_global": {"handler": Mock()}}

    monkeypatch.setattr(registry, "_event_handlers", legacy_event_handlers)
    monkeypatch.setattr(registry, "_scheduled_tasks", legacy_scheduled_tasks)
    monkeypatch.setattr(registry, "_global_handlers", legacy_global_handlers)

    empty_router_manager = Mock()
    empty_router_manager.get_event_handlers.return_value = {}
    empty_router_manager.get_scheduled_tasks.return_value = {}
    empty_router_manager.get_global_handlers.return_value = {}
    monkeypatch.setattr(registry, "get_router_manager", lambda: empty_router_manager)

    event_handlers, scheduled_tasks, global_handlers = event_processing._get_event_handlers()

    assert event_handlers == legacy_event_handlers
    assert scheduled_tasks == legacy_scheduled_tasks
    assert global_handlers == legacy_global_handlers
