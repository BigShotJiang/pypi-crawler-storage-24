"""Regression tests for extracted CLI handlers."""

import importlib
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

import click
import pytest
from click.testing import CliRunner

from smart_bot_factory.cli import cli
from smart_bot_factory.cli.commands_heavy import handle_doctor, handle_run, handle_test
from smart_bot_factory.cli.commands_light import handle_config, handle_prompts


def test_run_command_delegates_to_handler():
    runner = CliRunner()
    with patch("smart_bot_factory.cli.main.handle_run") as mock_handle:
        result = runner.invoke(cli, ["run", "demo_bot"])
        assert result.exit_code == 0
        mock_handle.assert_called_once()
        args = mock_handle.call_args[0]
        assert args[0] == "demo_bot"


def test_test_command_delegates_to_handler():
    runner = CliRunner()
    with patch("smart_bot_factory.cli.main.handle_test") as mock_handle:
        result = runner.invoke(cli, ["test", "demo_bot", "--max-concurrent", "3", "--verbose"])
        assert result.exit_code == 0
        mock_handle.assert_called_once()
        args = mock_handle.call_args[0]
        assert args[0] == "demo_bot"
        kwargs = mock_handle.call_args.kwargs
        assert kwargs["max_concurrent"] == 3
        assert kwargs["verbose"] is True


def test_handle_config_fails_when_bot_missing(tmp_path: Path):
    with pytest.raises(SystemExit):
        handle_config("missing", tmp_path, Mock())


def test_handle_prompts_add_creates_file(tmp_path: Path):
    bot_path = tmp_path / "bots" / "demo"
    prompts_path = bot_path / "prompts"
    prompts_path.mkdir(parents=True)

    opened: list[Path] = []

    def _open_in_editor(file_path: Path) -> None:
        opened.append(file_path)

    handle_prompts(
        "demo",
        tmp_path,
        _open_in_editor,
        list_prompts=False,
        edit_prompt=None,
        add_prompt="new_prompt",
    )

    created = prompts_path / "new_prompt.txt"
    assert created.exists()
    assert opened == [created]


def test_path_command_works_with_patched_root(tmp_path: Path):
    runner = CliRunner()
    with patch("smart_bot_factory.cli.main.root", tmp_path):
        result = runner.invoke(cli, ["path"])
        assert result.exit_code == 0
        assert str(tmp_path) in result.output


def test_handle_run_exits_when_builder_missing(tmp_path: Path):
    bot_file = tmp_path / "demo.py"
    bot_file.write_text("# demo", encoding="utf-8")
    with pytest.raises(SystemExit) as exc:
        handle_run(
            "demo",
            tmp_path,
            resolve_bot_id_and_file=lambda _root, _arg: ("demo", bot_file),
            ensure_bot_exists=lambda _root, _bot: tmp_path / "bots" / "demo",
            ensure_env_file=lambda _path, _bot: tmp_path / ".env",
            add_project_root_to_syspath=lambda _root: None,
            load_env_file=lambda _env: None,
            set_runtime_env=lambda _bot, _path: None,
            load_bot_module=lambda *_args, **_kwargs: object(),
            find_builder_by_attrs=lambda *_args, **_kwargs: None,
        )
    assert exc.value.code == 1


def test_handle_test_returns_when_yaml_missing(tmp_path: Path):
    bot_path = tmp_path / "bots" / "demo"
    tests_path = bot_path / "tests"
    tests_path.mkdir(parents=True)
    (tmp_path / "demo.py").write_text("# demo", encoding="utf-8")

    handle_test(
        "demo",
        tmp_path,
        ensure_bot_file_exists=lambda _root, _bot: tmp_path / "demo.py",
        add_project_root_to_syspath=lambda _root: None,
        load_env_file=lambda _env: None,
        set_runtime_env=lambda _bot, _path: None,
        load_bot_module=lambda *_args, **_kwargs: object(),
        find_builder_by_attrs=lambda *_args, **_kwargs: None,
        file=None,
        verbose=False,
        max_concurrent=2,
    )


def test_handle_test_happy_path_runs_builder(tmp_path: Path):
    bot_path = tmp_path / "bots" / "demo"
    tests_path = bot_path / "tests"
    tests_path.mkdir(parents=True)
    (tests_path / "s.yaml").write_text("ok", encoding="utf-8")
    (tmp_path / "demo.py").write_text("# demo", encoding="utf-8")

    builder = SimpleNamespace()
    builder._initialized = True
    builder.start = AsyncMock()
    builder.build = AsyncMock()
    builder.test = AsyncMock(return_value=0)
    module = SimpleNamespace(main=AsyncMock(return_value=None))

    handle_test(
        "demo",
        tmp_path,
        ensure_bot_file_exists=lambda _root, _bot: tmp_path / "demo.py",
        add_project_root_to_syspath=lambda _root: None,
        load_env_file=lambda _env: None,
        set_runtime_env=lambda _bot, _path: None,
        load_bot_module=lambda *_args, **_kwargs: module,
        find_builder_by_attrs=lambda *_args, **_kwargs: builder,
        file=None,
        verbose=False,
        max_concurrent=2,
    )
    builder.test.assert_awaited_once()


def test_handle_doctor_exits_when_env_missing(tmp_path: Path):
    bot_path = tmp_path / "bots" / "demo"
    (bot_path / "prompts").mkdir(parents=True)
    with pytest.raises(SystemExit) as exc:
        handle_doctor(
            "demo",
            tmp_path,
            load_env_file=lambda _env: None,
            set_runtime_env=lambda _bot, _path: None,
            add_project_root_to_syspath=lambda _root: None,
        )
    assert exc.value.code == 1


def test_import_cli_module_does_not_set_runtime_env():
    old_bot_id = os.environ.get("BOT_ID")
    old_prompt_dir = os.environ.get("PROMPT_FILES_DIR")
    had_openai_module = "smart_bot_factory.integrations.openai.langchain_openai" in sys.modules
    had_supabase_module = "smart_bot_factory.integrations.supabase_client" in sys.modules

    import smart_bot_factory.cli as cli_module

    importlib.reload(cli_module)

    assert os.environ.get("BOT_ID") == old_bot_id
    assert os.environ.get("PROMPT_FILES_DIR") == old_prompt_dir
    if not had_openai_module:
        assert "smart_bot_factory.integrations.openai.langchain_openai" not in sys.modules
    if not had_supabase_module:
        assert "smart_bot_factory.integrations.supabase_client" not in sys.modules

