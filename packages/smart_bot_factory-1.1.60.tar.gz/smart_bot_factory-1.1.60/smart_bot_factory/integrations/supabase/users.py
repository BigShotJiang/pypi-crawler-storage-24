"""Users repository (sales_users)."""

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from postgrest.exceptions import APIError
from supabase import Client

from .models import UserRecord

logger = logging.getLogger(__name__)


class UsersRepo:
    def __init__(self, client: Client, bot_id: Optional[str]) -> None:
        self._client = client
        self._bot_id = bot_id

    def _with_bot_id(self, query: Any) -> Any:
        if self._bot_id:
            return query.eq("bot_id", self._bot_id)
        return query

    async def create_or_get_user(self, user_data: Dict[str, Any]) -> int:
        try:
            query = self._with_bot_id(self._client.table("sales_users").select("telegram_id").eq("telegram_id", user_data["telegram_id"]))
            response = query.execute()

            if response.data:
                existing_user_query = self._with_bot_id(
                    self._client.table("sales_users")
                    .select("source", "medium", "campaign", "content", "term", "segments")
                    .eq("telegram_id", user_data["telegram_id"])
                )
                existing_response = existing_user_query.execute()
                existing_utm = existing_response.data[0] if existing_response.data else {}

                update_data = {
                    "username": user_data.get("username"),
                    "first_name": user_data.get("first_name"),
                    "last_name": user_data.get("last_name"),
                    "language_code": user_data.get("language_code"),
                    "updated_at": datetime.now().isoformat(),
                    "is_active": True,
                }

                utm_fields = ["source", "medium", "campaign", "content", "term"]
                for field in utm_fields:
                    new_value = user_data.get(field)
                    if new_value is not None:
                        update_data[field] = new_value
                        if existing_utm.get(field) != new_value:
                            logger.debug("UTM update: %s = %r (was: %r)", field, new_value, existing_utm.get(field))
                    else:
                        update_data[field] = existing_utm.get(field)

                new_segment = user_data.get("segment")
                if new_segment:
                    existing_segments = existing_utm.get("segments", "") or ""
                    if existing_segments:
                        segments_list = [s.strip() for s in existing_segments.split(",") if s.strip()]
                        if new_segment not in segments_list:
                            segments_list.append(new_segment)
                            update_data["segments"] = ", ".join(segments_list)
                            logger.debug("Segment added: %r", new_segment)
                        else:
                            update_data["segments"] = existing_segments
                            logger.debug("Segment %r already exists", new_segment)
                    else:
                        update_data["segments"] = new_segment
                        logger.debug("First segment added: %r", new_segment)
                else:
                    update_data["segments"] = existing_utm.get("segments")

                update_query = self._with_bot_id(self._client.table("sales_users").update(update_data).eq("telegram_id", user_data["telegram_id"]))
                update_query.execute()
                logger.debug("Updated user %s", user_data["telegram_id"])
                return user_data["telegram_id"]
            else:
                user_insert_data = {
                    "telegram_id": user_data["telegram_id"],
                    "username": user_data.get("username"),
                    "first_name": user_data.get("first_name"),
                    "last_name": user_data.get("last_name"),
                    "language_code": user_data.get("language_code"),
                    "is_active": True,
                    "source": user_data.get("source"),
                    "medium": user_data.get("medium"),
                    "campaign": user_data.get("campaign"),
                    "content": user_data.get("content"),
                    "term": user_data.get("term"),
                    "segments": user_data.get("segment"),
                }
                if self._bot_id:
                    user_insert_data["bot_id"] = self._bot_id
                self._client.table("sales_users").insert(user_insert_data).execute()
                logger.debug("Created new user %s", user_data["telegram_id"])
                return user_data["telegram_id"]

        except APIError as e:
            logger.error("Error working with user: %s", e)
            raise

    async def mark_user_blocked(self, user_id: int) -> bool:
        try:
            update_query = (
                self._client.table("sales_users").update({"is_active": False, "updated_at": datetime.now().isoformat()}).eq("telegram_id", user_id)
            )
            update_query = self._with_bot_id(update_query)
            response = update_query.execute()

            if response.data:
                logger.info("User %s marked as blocked (is_active=False)", user_id)
                return True
            logger.warning("User %s not found for block status update", user_id)
            return False

        except APIError as e:
            logger.error("Error updating block status for user %s: %s", user_id, e)
            return False

    async def get_all_segments(self) -> List[str]:
        try:
            query = self._client.table("sales_users").select("segments").neq("segments", "")
            query = self._with_bot_id(query)
            response = query.execute()

            all_segments: set[str] = set()
            for row in response.data or []:
                segments_str = row.get("segments", "")
                if segments_str:
                    segments = [s.strip() for s in segments_str.split(",") if s.strip()]
                    all_segments.update(segments)

            segments_list = sorted(all_segments)
            logger.info("Found %s unique segments", len(segments_list))
            return segments_list

        except Exception as e:
            logger.error("Error getting segments: %s", e)
            return []

    async def get_users_by_segment(self, segment: Optional[str] = None) -> List[UserRecord]:
        try:
            # Keep fields required by admin broadcast filters (bot_id/username)
            query = self._client.table("sales_users").select("telegram_id, segments, bot_id, username, is_active")
            query = self._with_bot_id(query)
            response = query.execute()

            if segment is None:
                rows = response.data or []
                logger.info("Got %s users (all)", len(rows))
                return [UserRecord.model_validate(row) for row in rows]

            users: List[UserRecord] = []
            for row in response.data or []:
                segments_str = row.get("segments", "")
                if segments_str:
                    segments = [s.strip() for s in segments_str.split(",") if s.strip()]
                    if segment in segments:
                        users.append(UserRecord.model_validate(row))
            logger.info("Found %s users with segment %r", len(users), segment)
            return users

        except Exception as e:
            logger.error("Error getting users by segment %r: %s", segment, e)
            return []
