"""Heavy CLI command handlers (run/test/doctor)."""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from typing import Callable, Optional, Sequence

import click


def handle_run(
    bot_id_or_file: str,
    root: Path,
    *,
    resolve_bot_id_and_file: Callable[[Path, str], tuple[str, Path]],
    ensure_bot_exists: Callable[[Path, str], Path],
    ensure_env_file: Callable[[Path, str], Path],
    add_project_root_to_syspath: Callable[[Path], None],
    load_env_file: Callable[[Path], None],
    set_runtime_env: Callable[[str, Path], Optional[Path]],
    load_bot_module: Callable[..., object],
    find_builder_by_attrs: Callable[..., object],
) -> None:
    try:
        bot_id, bot_file = resolve_bot_id_and_file(root, bot_id_or_file)
        if not bot_file.exists():
            raise click.ClickException(f"Файл {bot_file.name} не найден в корневой директории")
        bot_path = ensure_bot_exists(root, bot_id)
        env_file = ensure_env_file(bot_path, bot_id)
        add_project_root_to_syspath(root)
        load_env_file(env_file)
        click.echo(f"📄 Загружен .env файл: {env_file}")
        prompts_dir = set_runtime_env(bot_id, bot_path)
        click.echo(f"🔧 Установлен BOT_ID в переменные окружения: {bot_id}")
        if prompts_dir is not None:
            click.echo(f"📝 Установлен путь к промптам: {prompts_dir}")
        click.echo(f"🚀 Запускаем бота {bot_id}...")
        bot_module = load_bot_module(bot_id, bot_file)
        bot_builder = find_builder_by_attrs(
            bot_module,
            named_candidates=("bot_builder",),
            required_attrs=("start", "build"),
        )
        if not bot_builder:
            raise click.ClickException(f"bot_builder не найден в файле {bot_id}.py")
        asyncio.run(bot_builder.start())
    except KeyboardInterrupt:
        click.echo("\n⏹️ Остановка бота...")
        sys.exit(0)
    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        if "--verbose" in sys.argv or "-v" in sys.argv:
            import traceback

            click.echo(f"Стек ошибки: {traceback.format_exc()}", err=True)
        sys.exit(1)


def handle_test(
    bot_id: str,
    root: Path,
    *,
    ensure_bot_file_exists: Callable[[Path, str], Path],
    add_project_root_to_syspath: Callable[[Path], None],
    load_env_file: Callable[[Path], None],
    set_runtime_env: Callable[[str, Path], Optional[Path]],
    load_bot_module: Callable[..., object],
    find_builder_by_attrs: Callable[..., object],
    file: Optional[str],
    verbose: bool,
    max_concurrent: int,
) -> None:
    try:
        bot_path = root / "bots" / bot_id
        if not bot_path.exists():
            raise click.ClickException(f"Бот {bot_id} не найден в папке {root}/bots/")
        bot_file = ensure_bot_file_exists(root, bot_id)
        tests_dir = bot_path / "tests"
        if not tests_dir.exists():
            click.echo(f"⚠️ Тесты не найдены для бота {bot_id}")
            return
        yaml_files = [str(f.name) for f in tests_dir.glob("*.yaml")]
        if not yaml_files:
            click.echo(f"⚠️ YAML тесты не найдены для бота {bot_id}")
            return
        click.echo(f"🧪 Запускаем тесты для бота {bot_id} через BotBuilder...")
        add_project_root_to_syspath(root)
        env_file = bot_path / ".env"
        if env_file.exists():
            load_env_file(env_file)
            click.echo(f"📄 Загружен .env файл: {env_file}")
        set_runtime_env(bot_id, bot_path)
        import logging

        log_level = logging.INFO if verbose else logging.INFO
        logging.basicConfig(level=log_level, format="%(message)s")
        bot_module = load_bot_module(bot_id, bot_file, attrs={"root": root, "BOT_ID": bot_id})
        bot_builder = find_builder_by_attrs(
            bot_module,
            named_candidates=("bot_builder", "builder"),
            required_attrs=("test", "build"),
        )
        if not bot_builder:
            raise click.ClickException(f"BotBuilder не найден в файле {bot_id}.py")

        async def run_test():
            try:
                if hasattr(bot_module, "main") and callable(bot_module.main):
                    click.echo("🔧 Выполняем main() для регистрации компонентов...")
                    original_start = bot_builder.start

                    async def mock_start():
                        click.echo("✅ Компоненты зарегистрированы, переходим к тестированию")
                        return

                    bot_builder.start = mock_start
                    try:
                        await bot_module.main()
                    except Exception as e:
                        if not bot_builder._initialized:
                            raise e
                        click.echo(f"⚠️ main() завершился с ошибкой, но build() выполнен: {e}")
                    finally:
                        bot_builder.start = original_start
                else:
                    click.echo("⚠️ Функция main() не найдена, собираем бота вручную...")
                    if not bot_builder._initialized:
                        await bot_builder.build()
                return await bot_builder.test(scenario_file=file, max_concurrent=max_concurrent, verbose=verbose)
            except Exception as e:
                click.echo(f"❌ Ошибка при тестировании: {e}")
                import traceback

                if verbose:
                    click.echo(f"Стек ошибки: {traceback.format_exc()}")
                return 1

        exit_code = asyncio.run(run_test())
        if exit_code == 0:
            click.echo("✅ Все тесты пройдены")
        else:
            click.echo("❌ Есть ошибки в тестах")
            sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        if verbose:
            import traceback

            click.echo(f"Стек ошибки: {traceback.format_exc()}", err=True)
        sys.exit(1)


def handle_doctor(
    bot_id: str,
    root: Path,
    *,
    load_env_file: Callable[[Path], None],
    set_runtime_env: Callable[[str, Path], Optional[Path]],
    add_project_root_to_syspath: Callable[[Path], None],
) -> None:
    bot_path = root / "bots" / bot_id
    env_file = bot_path / ".env"
    prompts_dir = bot_path / "prompts"
    failures: Sequence[str] = []

    def _ok(message: str) -> None:
        click.echo(f"✅ {message}")

    def _fail(message: str, error: Exception) -> None:
        nonlocal failures
        failures = [*failures, message]
        click.echo(f"❌ {message}: {error}")

    try:
        if not bot_path.exists():
            raise click.ClickException(f"Бот {bot_id} не найден в папке bots/")
        _ok(f"Найден бот: bots/{bot_id}")
    except Exception as e:
        click.echo(f"❌ bots/{bot_id}: {e}")
        raise SystemExit(1) from e
    try:
        if not env_file.exists():
            raise FileNotFoundError(f".env не найден: {env_file}")
        load_env_file(env_file)
        _ok(f"Загружен .env: {env_file}")
    except Exception as e:
        click.echo(f"❌ .env: {e}")
        raise SystemExit(1) from e
    try:
        set_runtime_env(bot_id, bot_path)
        _ok(f"Установлен BOT_ID: {bot_id}")
    except Exception as e:
        click.echo(f"❌ BOT_ID: {e}")
        raise SystemExit(1) from e
    try:
        if not prompts_dir.exists():
            raise FileNotFoundError(f"Папка промптов не найдена: {prompts_dir}")
        os.environ["PROMPT_FILES_DIR"] = str(prompts_dir)
        _ok(f"Найден каталог промптов: {prompts_dir}")
    except Exception as e:
        click.echo(f"❌ prompts: {e}")
        raise SystemExit(1) from e
    try:
        add_project_root_to_syspath(root)
        from smart_bot_factory.config import Config

        config = Config()
        _ok("Config() создан и провалидирован")
        click.echo(f"   UI_LANGUAGE: {config.UI_LANGUAGE}")
        click.echo(f"   PROMPT_FILES: {len(config.PROMPT_FILES)}")
    except Exception as e:
        _fail("Config() невалиден", e)
        raise SystemExit(1) from e

    async def _run_health_checks() -> None:
        try:
            from smart_bot_factory.integrations.openai.langchain_openai import LangChainOpenAIClient

            openai_client = LangChainOpenAIClient(
                api_key=config.OPENAI_API_KEY,
                model=config.OPENAI_MODEL,
                max_tokens=config.OPENAI_MAX_TOKENS,
                temperature=config.OPENAI_TEMPERATURE,
            )
            ok = await openai_client.check_api_health()
            if not ok:
                raise RuntimeError("OpenAI health check returned False")
            _ok("OpenAI API доступен")
        except Exception as e:
            _fail("OpenAI API недоступен", e)
        try:
            from smart_bot_factory.integrations.supabase_client import SupabaseClient

            supabase_client = SupabaseClient(config.SUPABASE_URL, config.SUPABASE_KEY, config.BOT_ID)
            await supabase_client.check_api_health()
            _ok("Supabase доступен")
        except Exception as e:
            _fail("Supabase недоступен", e)

    asyncio.run(_run_health_checks())
    if failures:
        raise SystemExit(1)
