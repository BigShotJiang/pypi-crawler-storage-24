"""Shared service helpers for CLI commands."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from types import ModuleType
from typing import Iterable, Optional

import click


def resolve_bot_id_and_file(project_root: Path, bot_id_or_file: str) -> tuple[str, Path]:
    if bot_id_or_file.endswith(".py"):
        bot_id = Path(bot_id_or_file).stem
        bot_file = project_root / Path(bot_id_or_file)
        if not bot_file.is_absolute():
            bot_file = project_root / bot_file
        return bot_id, bot_file
    return bot_id_or_file, project_root / Path(f"{bot_id_or_file}.py")


def ensure_bot_exists(project_root: Path, bot_id: str) -> Path:
    bot_path = project_root / Path("bots") / bot_id
    if not bot_path.exists():
        raise click.ClickException(f"Бот {bot_id} не найден в папке bots/")
    return bot_path


def ensure_bot_file_exists(project_root: Path, bot_id: str) -> Path:
    bot_file = project_root / Path(f"{bot_id}.py")
    if not bot_file.exists():
        raise click.ClickException(f"Файл {bot_id}.py не найден в корневой директории")
    return bot_file


def ensure_env_file(bot_path: Path, bot_id: str) -> Path:
    env_file = bot_path / ".env"
    if not env_file.exists():
        raise click.ClickException(f"Файл .env не найден для бота {bot_id}")
    return env_file


def add_project_root_to_syspath(project_root: Path) -> None:
    root_str = str(project_root)
    if root_str not in sys.path:
        sys.path.insert(0, root_str)


def load_env_file(env_file: Path) -> None:
    from dotenv import load_dotenv

    load_dotenv(env_file)


def set_runtime_env(bot_id: str, bot_path: Path) -> Optional[Path]:
    os.environ["BOT_ID"] = bot_id
    prompts_dir = bot_path / "prompts"
    if prompts_dir.exists():
        os.environ["PROMPT_FILES_DIR"] = str(prompts_dir)
        return prompts_dir
    return None


def load_bot_module(bot_id: str, bot_file: Path, attrs: Optional[dict[str, object]] = None) -> ModuleType:
    import importlib.util

    spec = importlib.util.spec_from_file_location(f"{bot_id}_bot", bot_file)
    if spec is None or spec.loader is None:
        raise click.ClickException(f"Не удалось загрузить модуль бота: {bot_file}")
    bot_module = importlib.util.module_from_spec(spec)
    if attrs:
        for key, value in attrs.items():
            setattr(bot_module, key, value)
    spec.loader.exec_module(bot_module)
    return bot_module


def find_builder_by_attrs(
    bot_module: ModuleType,
    *,
    named_candidates: Iterable[str],
    required_attrs: Iterable[str],
):
    for candidate in named_candidates:
        if hasattr(bot_module, candidate):
            obj = getattr(bot_module, candidate)
            if all(hasattr(obj, attr_name) for attr_name in required_attrs):
                return obj
    for attr_name in dir(bot_module):
        attr = getattr(bot_module, attr_name)
        if all(hasattr(attr, req) for req in required_attrs):
            return attr
    return None


def get_editor() -> str:
    return os.environ.get("EDITOR", "notepad" if os.name == "nt" else "nano")


def open_in_editor(target_file: Path) -> None:
    subprocess.run([get_editor(), str(target_file)], check=True)
