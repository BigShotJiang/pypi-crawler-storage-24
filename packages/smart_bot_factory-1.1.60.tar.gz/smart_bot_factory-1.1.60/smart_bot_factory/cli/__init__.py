"""CLI package entrypoint and compatibility exports."""

from .main import cli
from .templates import (
    copy_bot_template,
    copy_from_bot_template,
    copy_from_growthmed_template,
    create_basic_prompts,
    create_bot_template,
    create_env_template,
    create_new_bot_structure,
    list_bots_in_bots_folder,
)

__all__ = [
    "cli",
    "create_new_bot_structure",
    "list_bots_in_bots_folder",
    "create_bot_template",
    "create_env_template",
    "copy_from_growthmed_template",
    "copy_bot_template",
    "copy_from_bot_template",
    "create_basic_prompts",
]
