"""Template and bot scaffolding helpers for CLI."""

from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import List

import click
from project_root_finder import root


def create_bot_template(bot_id: str) -> str:
    return f'''"""
{bot_id.replace("-", " ").title()} Bot - Умный Telegram бот на Smart Bot Factory
"""

from smart_bot_factory.router import EventRouter
from smart_bot_factory.message import send_message_by_human
from smart_bot_factory.creation import BotBuilder

event_router = EventRouter()
bot_builder = BotBuilder()

@event_router.event_handler(once_only=True)
async def collect_contact(user_id: int, contact_data: str):
    """
    Обрабатывает получение контактных данных

    ИИ создает: {{"тип": "collect_contact", "инфо": "+79001234567"}}
    """
    await send_message_by_human(
        user_id=user_id,
        message_text=f"✅ Спасибо! Ваши данные сохранены: {{contact_data}}"
    )
    return {{"status": "success", "contact": contact_data}}

bot_builder.register_routers(event_router)
'''


def create_env_template(bot_id: str) -> str:
    return f"""# Telegram
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here

# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your_supabase_anon_key

# OpenAI
OPENAI_API_KEY=sk-your-openai-api-key
OPENAI_MODEL=gpt-5-mini
OPENAI_MAX_TOKENS=1500
OPENAI_TEMPERATURE=0.7

# Промпты (каталог)
PROMPT_FILES_DIR=prompts

# Hot reload промптов
ENABLE_PROMPT_HOT_RELOAD=false

# Логирование времени выполнения
ENABLE_PERFORMANCE_LOGGING=false
PERFORMANCE_LOG_MIN_MS=50
PERFORMANCE_LOG_LEVEL=basic

# Файл после приветствия с подписью (если он есть - грузим его в папку welcome_file, если нет - ничего не делаем)
WELCOME_FILE_URL=welcome_files/
WELCOME_FILE_MSG=welcome_file_msg.txt

# 🆕 Администраторы (через запятую)
# Укажите Telegram ID админов
ADMIN_TELEGRAM_IDS=123456789,987654321
ADMIN_SESSION_TIMEOUT_MINUTES=30

# 🆕 Режим отладки (показывать JSON пользователям)
DEBUG_MODE=false

# Дополнительные настройки
UI_LANGUAGE=ru
MAX_CONTEXT_MESSAGES=50
LOG_LEVEL=INFO
MESSAGE_PARSE_MODE=Markdown

# Настройки продаж
LEAD_QUALIFICATION_THRESHOLD=7
SESSION_TIMEOUT_HOURS=24

# ⚠️ ВАЖНО: BOT_ID теперь НЕ нужен в .env!
# Bot ID автоматически определяется из имени файла запускалки
# Например: python {bot_id}.py → BOT_ID = {bot_id}
"""


def _strip_legacy_entrypoints(content: str) -> str:
    content = re.sub(r"async def main\(\):.*?(?=\n\n|\n# |\Z)", "", content, flags=re.DOTALL)
    content = re.sub(r'if __name__ == ["\']__main__["\']:.*?(?=\n\n|\Z)', "", content, flags=re.DOTALL)
    return content


def _ensure_bot_subdirs(bot_dir: Path) -> None:
    (bot_dir / "prompts").mkdir(exist_ok=True)
    (bot_dir / "tests").mkdir(exist_ok=True)
    (bot_dir / "reports").mkdir(exist_ok=True)
    (bot_dir / "welcome_files").mkdir(exist_ok=True)
    (bot_dir / "files").mkdir(exist_ok=True)


def list_bots_in_bots_folder() -> List[str]:
    bots_dir = root / Path("bots")
    if not bots_dir.exists():
        return []
    bots: List[str] = []
    for item in bots_dir.iterdir():
        if item.is_dir() and (root / Path(f"{item.name}.py")).exists():
            bots.append(item.name)
    return bots


def create_basic_prompts(prompts_dir: Path) -> None:
    (prompts_dir / "system_prompt.txt").write_text(
        "Ты - помощник. Твоя задача помогать пользователям с их вопросами.\nБудь дружелюбным и полезным.",
        encoding="utf-8",
    )
    (prompts_dir / "welcome_message.txt").write_text("👋 Привет! Я ваш помощник.\n\nЧем могу помочь?", encoding="utf-8")
    (prompts_dir / "final_instructions.txt").write_text(
        """<instruction>
КРИТИЧЕСКИ ВАЖНО: В НАЧАЛЕ КАЖДОГО своего ответа добавляй служебную информацию в формате:

{
  "этап": id,
  "качество": 1-10,
  "события": [
    {
      "тип": тип события,
      "инфо": детали события
    }
  ]
}

ДОСТУПНЫЕ ОБРАБОТЧИКИ СОБЫТИЙ:
- example_event: Пример обработчика события. Используй для демонстрации.
  Пример: {"тип": "example_event", "инфо": {"data": "пример данных"}}

ДОСТУПНЫЕ ЗАПЛАНИРОВАННЫЕ ЗАДАЧИ:
- example_task: Пример запланированной задачи. Используй для демонстрации.
  Пример: {"тип": "example_task", "инфо": "через 1 час: напомнить о чем-то"}

ДОСТУПНЫЕ ГЛОБАЛЬНЫЕ ОБРАБОТЧИКИ:
- global_announcement: Отправляет анонс всем пользователям. Используй для важных объявлений.
  Пример: {"тип": "global_announcement", "инфо": "3600"} - анонс через 1 час
  Формат: "инфо" содержит время в секундах для планирования.

Используй эти обработчики и задачи, когда это уместно в диалоге.
</instruction>""",
        encoding="utf-8",
    )


def copy_from_growthmed_template(bot_dir: Path, bot_id: str) -> None:
    try:
        bot_file = root / Path(f"{bot_id}.py")
        bot_file.write_text(create_bot_template(bot_id), encoding="utf-8")
        env_file = bot_dir / ".env"
        env_file.write_text(create_env_template(bot_id), encoding="utf-8")
        source_prompts = Path(__file__).parent.parent / "configs" / "growthmed-october-24" / "prompts"
        target_prompts = bot_dir / "prompts"
        if source_prompts.exists():
            for prompt_file in source_prompts.glob("*.txt"):
                shutil.copy2(prompt_file, target_prompts / prompt_file.name)
            click.echo("📝 Промпты скопированы из growthmed-october-24")
        else:
            click.echo(f"⚠️ Папка промптов не найдена: {source_prompts}")
            create_basic_prompts(target_prompts)
            click.echo("📝 Созданы базовые промпты")
        source_tests = Path(__file__).parent.parent / "configs" / "growthmed-october-24" / "tests"
        target_tests = bot_dir / "tests"
        if source_tests.exists():
            for test_file in source_tests.glob("*"):
                if test_file.is_file():
                    shutil.copy2(test_file, target_tests / test_file.name)
            click.echo("🧪 Тесты скопированы из growthmed-october-24")
        source_welcome = Path(__file__).parent.parent / "configs" / "growthmed-october-24" / "welcome_file"
        target_welcome = bot_dir / "welcome_files"
        if source_welcome.exists():
            for welcome_file in source_welcome.glob("*"):
                if welcome_file.is_file():
                    shutil.copy2(welcome_file, target_welcome / welcome_file.name)
            click.echo("📁 Welcome файлы скопированы из growthmed-october-24")
        source_files = Path(__file__).parent.parent / "configs" / "growthmed-october-24" / "files"
        target_files = bot_dir / "files"
        if source_files.exists():
            for file_item in source_files.glob("*"):
                if file_item.is_file():
                    shutil.copy2(file_item, target_files / file_item.name)
            click.echo("📎 Файлы скопированы из growthmed-october-24")
    except Exception as e:
        click.echo(f"❌ Ошибка при копировании шаблона: {e}")
        create_basic_prompts(bot_dir / "prompts")


def copy_bot_template(source_bot_id: str, new_bot_id: str) -> None:
    try:
        source_dir = root / "bots" / source_bot_id
        new_dir = root / "bots" / new_bot_id
        new_dir.mkdir(exist_ok=True)
        _ensure_bot_subdirs(new_dir)
        source_bot_file = root / f"{source_bot_id}.py"
        new_bot_file = root / f"{new_bot_id}.py"
        if source_bot_file.exists():
            shutil.copy2(source_bot_file, new_bot_file)
            content = new_bot_file.read_text(encoding="utf-8")
            content = content.replace(f'BotBuilder("{source_bot_id}")', f'BotBuilder("{new_bot_id}")')
            content = content.replace(f'EventRouter("{source_bot_id}")', f'EventRouter("{new_bot_id}")')
            content = content.replace(f'bot_id="{source_bot_id}"', f'bot_id="{new_bot_id}"')
            content = _strip_legacy_entrypoints(content)
            new_bot_file.write_text(content, encoding="utf-8")
            click.echo(f"   📄 Файл запускалки скопирован: {new_bot_id}.py")
        new_env = new_dir / ".env"
        new_env.write_text(create_env_template(new_bot_id), encoding="utf-8")
        click.echo("   ⚙️ Создан шаблон .env файла")
        source_prompts = source_dir / "prompts"
        new_prompts = new_dir / "prompts"
        if source_prompts.exists():
            for prompt_file in source_prompts.glob("*.txt"):
                shutil.copy2(prompt_file, new_prompts / prompt_file.name)
            click.echo("   📝 Промпты скопированы")
        source_tests = source_dir / "tests"
        new_tests = new_dir / "tests"
        if source_tests.exists():
            for test_file in source_tests.glob("*"):
                if test_file.is_file():
                    shutil.copy2(test_file, new_tests / test_file.name)
            click.echo("   🧪 Тесты скопированы")
        source_welcome = source_dir / "welcome_files"
        new_welcome = new_dir / "welcome_files"
        if source_welcome.exists():
            for welcome_file in source_welcome.glob("*"):
                if welcome_file.is_file():
                    shutil.copy2(welcome_file, new_welcome / welcome_file.name)
            click.echo("   📁 Welcome файлы скопированы")
        source_files = source_dir / "files"
        new_files = new_dir / "files"
        if source_files.exists():
            for file_item in source_files.glob("*"):
                if file_item.is_file():
                    shutil.copy2(file_item, new_files / file_item.name)
            click.echo("   📎 Файлы скопированы")
    except Exception as e:
        click.echo(f"❌ Ошибка при копировании бота: {e}")
        raise


def copy_from_bot_template(template: str, bot_dir: Path, bot_id: str) -> None:
    try:
        template_dir = root / Path("bots") / template
        if not template_dir.exists():
            raise click.ClickException(f"Шаблон {template} не найден")
        template_bot_file = root / Path(f"{template}.py")
        if template_bot_file.exists():
            bot_file = root / Path(f"{bot_id}.py")
            shutil.copy2(template_bot_file, bot_file)
            content = bot_file.read_text(encoding="utf-8")
            content = content.replace(f'BotBuilder("{template}")', f'BotBuilder("{bot_id}")')
            content = content.replace(f'EventRouter("{template}")', f'EventRouter("{bot_id}")')
            content = content.replace(f'bot_id="{template}"', f'bot_id="{bot_id}"')
            content = _strip_legacy_entrypoints(content)
            bot_file.write_text(content, encoding="utf-8")
        env_file = bot_dir / ".env"
        env_file.write_text(create_env_template(bot_id), encoding="utf-8")
        template_prompts = template_dir / "prompts"
        target_prompts = bot_dir / "prompts"
        if template_prompts.exists():
            for prompt_file in template_prompts.glob("*.txt"):
                shutil.copy2(prompt_file, target_prompts / prompt_file.name)
        template_tests = template_dir / "tests"
        target_tests = bot_dir / "tests"
        if template_tests.exists():
            for test_file in template_tests.glob("*"):
                if test_file.is_file():
                    shutil.copy2(test_file, target_tests / test_file.name)
        click.echo(f"📋 Шаблон скопирован из {template}")
    except Exception as e:
        click.echo(f"❌ Ошибка при копировании шаблона {template}: {e}")
        raise


def create_new_bot_structure(template: str, bot_id: str) -> bool:
    try:
        bots_dir = root / Path("bots")
        bots_dir.mkdir(exist_ok=True)
        bot_dir = bots_dir / bot_id
        if bot_dir.exists():
            click.echo(f"⚠️ Бот {bot_id} уже существует")
            return False
        bot_dir.mkdir()
        _ensure_bot_subdirs(bot_dir)
        if template == "base":
            copy_from_growthmed_template(bot_dir, bot_id)
        else:
            copy_from_bot_template(template, bot_dir, bot_id)
        click.echo(f"✅ Бот {bot_id} создан в папке bots/{bot_id}/")
        click.echo("📝 Не забудьте настроить .env файл перед запуском")
        return True
    except Exception as e:
        click.echo(f"❌ Ошибка при создании бота: {e}")
        return False
