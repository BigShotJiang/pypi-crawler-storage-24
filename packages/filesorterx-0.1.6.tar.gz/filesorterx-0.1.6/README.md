# FileSorter

FileSorter is a simple and colorful command line tool that groups files by extension.

It uses Rich for styled terminal output.

---

## Features

- Groups files by extension
- Clean, sorted output
- Handles files with no extension
- OS module usage.
- Sorted folder display

### Installation

```bash
pip install FileSorterX
```

#### Usage

- Linux / macOS / Windows

```bash
cd "FOLDERPATH"
filesorterx
```