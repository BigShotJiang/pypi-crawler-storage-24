"""Engine implementations for sageLLM Core.

All legacy engines (EmbeddingEngine, CPUEmbeddingEngine) have been removed.
The unified entry point for all inference — including embedding — is LLMEngine:

    from sagellm_core import LLMEngine, LLMEngineConfig

    # Text generation:
    config = LLMEngineConfig(model_path="Qwen/Qwen2-7B", backend_type="cuda")
    engine = LLMEngine(config)

    # Embedding:
    config = LLMEngineConfig(
        model_path="BAAI/bge-small-zh-v1.5",
        task_type="embedding",
        pooling_strategy="mean",
    )
    engine = LLMEngine(config)
    vectors = await engine.embed(["hello world"])
"""

from __future__ import annotations

__all__: list[str] = []
