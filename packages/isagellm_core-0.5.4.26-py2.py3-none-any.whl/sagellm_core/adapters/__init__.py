"""Engine adapters for the native sageLLM runtime.

This module provides adapters for integrating engines following the Adapter/Provider Pattern.

Key Principle (Adapter Pattern):
    ❌ Prohibit third-party libraries from invading core control flow
    ✅ Must isolate external dependencies through Adapter/Provider

Available Adapters:
    - NativeLLMEngineAdapter: sageLLM's native engine (HIGHEST PRIORITY)

Priority Hierarchy:
    - 200: sageLLM Native (NativeLLMEngineAdapter) - HIGHEST
    - 100-110: Domestic accelerators (Ascend, Cambricon, Kunlun)
    - 0-49: CPU/low-priority engines

Third-party inference engines are not built into ``sagellm-core``.
Use external plugin packages or ``sagellm-benchmark`` clients for comparison.

Example:
    >>> from sagellm_core.adapters import NativeLLMEngineAdapter
    >>> from sagellm_core.engine import EngineInstanceConfig
    >>>
    >>> config = EngineInstanceConfig(
    ...     engine_id="native-001",
    ...     model_path="meta-llama/Llama-2-7b",
    ...     device="auto",  # Auto-selects best backend
    ... )
    >>> adapter = NativeLLMEngineAdapter(config)
    >>> await adapter.start()
    >>> response = await adapter.execute(request)

Auto-Registration:
    All adapters are automatically registered with EngineFactory upon import.
    Use EngineFactory.create(backend_type="auto") to auto-select highest priority.
    Use EngineFactory.create(backend_type="native") for explicit selection.
"""

from __future__ import annotations

# Native sageLLM engine (highest priority)
from sagellm_core.adapters.native_adapter import NativeLLMEngineAdapter

__all__ = [
    # Native sageLLM engine (recommended default)
    "NativeLLMEngineAdapter",
]
