
SECSValue = float