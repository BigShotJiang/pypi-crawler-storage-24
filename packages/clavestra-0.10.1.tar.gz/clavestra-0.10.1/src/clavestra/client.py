"""Clavestra client -- FedimintClient wrapping fedimint-cli subprocess."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from clavestra.config import FedimintConfig
from clavestra.errors import (
    ActionNotAllowedError,
    ClavestError,
    FederationOfflineError,
    classify_error,
)

logger = logging.getLogger("clavestra")

VALID_ACTIONS: frozenset[str] = frozenset({
    "balance", "spend", "receive", "info", "pay_invoice", "create_invoice"
})


class FedimintClient:
    """Async client for Fedimint eCash operations via fedimint-cli subprocess."""

    def __init__(
        self,
        config: FedimintConfig,
        *,
        allowed_actions: list[str] | None = None,
    ) -> None:
        self._config = config
        if allowed_actions is not None:
            invalid = set(allowed_actions) - VALID_ACTIONS
            if invalid:
                raise ValueError(
                    f"Invalid action names: {invalid}. "
                    f"Valid: {sorted(VALID_ACTIONS)}"
                )
            self._allowed_actions: frozenset[str] | None = frozenset(allowed_actions)
        else:
            self._allowed_actions = None

    async def __aenter__(self) -> FedimintClient:
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager (no-op; future-proofs for resource cleanup)."""
        pass

    def _validate_amount(self, amount_msats: int) -> None:
        """Raise ValueError if amount_msats is not positive."""
        if amount_msats <= 0:
            raise ValueError(
                f"amount_msats must be positive, got {amount_msats}"
            )

    def _check_allowed(self, action: str) -> None:
        """Raise ActionNotAllowedError if action is not in the allowlist."""
        if self._allowed_actions is not None and action not in self._allowed_actions:
            raise ActionNotAllowedError(
                f"Action '{action}' is not allowed. "
                f"Allowed: {sorted(self._allowed_actions)}",
                action=action,
                allowed=sorted(self._allowed_actions),
            )

    async def _run_cli(self, *args: str, operation: str) -> dict[str, Any]:
        """Execute fedimint-cli with given args and return parsed JSON."""
        cmd = [
            self._config.cli_path,
            "--data-dir", self._config.data_dir,
            *args,
        ]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=self._config.timeout_seconds,
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise FederationOfflineError(
                f"fedimint-cli timed out after {self._config.timeout_seconds}s",
                operation=operation,
            )

        if proc.returncode != 0:
            raise classify_error(
                stderr.decode().strip(),
                exit_code=proc.returncode,
                operation=operation,
            )

        try:
            return json.loads(stdout.decode())
        except json.JSONDecodeError as exc:
            raise ClavestError(
                f"Malformed CLI output: {exc}",
                operation=operation,
                stderr=stdout.decode()[:200],
            ) from exc

    def _log_extras(self, operation: str, result: dict[str, Any], expected_key: str) -> None:
        """Log unexpected extra fields in CLI result for debugging."""
        for key in result:
            if key != expected_key:
                logger.debug("%s: extra field %s=%s", operation, key, result[key])

    # --- eCash operations ---

    async def balance(self) -> int:
        """Return current eCash balance in millisatoshis."""
        self._check_allowed("balance")
        result = await self._run_cli("info", operation="balance")
        balance_msat = result.get("total_amount_msat", 0)
        self._log_extras("balance", result, "total_amount_msat")
        return int(balance_msat)

    async def spend(self, amount_msats: int) -> str:
        """Spend eCash and return OOB notes as a base64 string."""
        self._validate_amount(amount_msats)
        self._check_allowed("spend")
        result = await self._run_cli("spend", str(amount_msats), operation="spend")
        self._log_extras("spend", result, "notes")
        return result["notes"]

    async def receive(self, notes: str) -> int:
        """Reissue incoming eCash notes and return amount received in msats."""
        self._check_allowed("receive")
        result = await self._run_cli("reissue", notes, operation="receive")
        self._log_extras("receive", result, "amount_msat")
        return int(result["amount_msat"])

    async def info(self) -> dict[str, Any]:
        """Return federation metadata as a full JSON dict."""
        self._check_allowed("info")
        return await self._run_cli("info", operation="info")

    async def pay_invoice(self, bolt11: str) -> str:
        """Pay a Lightning invoice and return the operation ID."""
        self._check_allowed("pay_invoice")
        result = await self._run_cli("ln-pay", bolt11, operation="pay_invoice")
        self._log_extras("pay_invoice", result, "operation_id")
        return result["operation_id"]

    async def create_invoice(self, amount_msats: int, description: str) -> str:
        """Create a Lightning invoice and return the bolt11 string."""
        self._validate_amount(amount_msats)
        self._check_allowed("create_invoice")
        result = await self._run_cli(
            "ln-invoice",
            "--amount", str(amount_msats),
            "--description", description,
            operation="create_invoice",
        )
        self._log_extras("create_invoice", result, "invoice")
        return result["invoice"]

    # --- Sync wrappers ---

    def _sync_wrap(self, coro):
        """Run an async coroutine synchronously with event loop detection."""
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            # No loop running -- safe to use asyncio.run()
            return asyncio.run(coro)
        else:
            # A loop is running -- cannot use asyncio.run()
            name = (
                coro.cr_code.co_qualname.split(".")[-1]
                if hasattr(coro, "cr_code")
                else "this method"
            )
            coro.close()
            raise RuntimeError(
                f"{name}_sync() cannot be called from an async context. "
                f"Use 'await client.{name}()' instead."
            )

    def balance_sync(self) -> int:
        """Synchronous wrapper for balance()."""
        return self._sync_wrap(self.balance())

    def spend_sync(self, amount_msats: int) -> str:
        """Synchronous wrapper for spend()."""
        return self._sync_wrap(self.spend(amount_msats))

    def receive_sync(self, notes: str) -> int:
        """Synchronous wrapper for receive()."""
        return self._sync_wrap(self.receive(notes))

    def info_sync(self) -> dict[str, Any]:
        """Synchronous wrapper for info()."""
        return self._sync_wrap(self.info())

    def pay_invoice_sync(self, bolt11: str) -> str:
        """Synchronous wrapper for pay_invoice()."""
        return self._sync_wrap(self.pay_invoice(bolt11))

    def create_invoice_sync(self, amount_msats: int, description: str) -> str:
        """Synchronous wrapper for create_invoice()."""
        return self._sync_wrap(self.create_invoice(amount_msats, description))
