"""Clavestra SDK -- eCash payments for AI agents."""

from clavestra.client import FedimintClient
from clavestra.config import FedimintConfig
from clavestra.errors import (
    ActionNotAllowedError,
    ClavestError,
    ConfigurationError,
    DoubleSpendError,
    FederationOfflineError,
    GatewayError,
    InsufficientBalanceError,
    InvalidNotesError,
)

__version__ = "0.10.0"
__all__ = [
    "ActionNotAllowedError",
    "ClavestError",
    "ConfigurationError",
    "DoubleSpendError",
    "FederationOfflineError",
    "FedimintClient",
    "FedimintConfig",
    "GatewayError",
    "InsufficientBalanceError",
    "InvalidNotesError",
]
