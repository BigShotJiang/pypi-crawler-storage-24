"""Clavestra MCP server -- Fedimint eCash operations as MCP tools.

Exposes 6 tools via FastMCP 3.x: ecash_spend, ecash_receive, ecash_balance,
ln_pay, ln_create_invoice, federation_info.

Run with: python -m clavestra.mcp

Environment variables:
    FEDIMINT_CLI_PATH:           Path to fedimint-cli binary (default: "fedimint-cli")
    FEDIMINT_DATA_DIR:           Path to fedimint data directory (required)
    FEDIMINT_FEDERATION_ID:      Federation ID (required)
    FEDIMINT_TIMEOUT_SECONDS:    Subprocess timeout (default: 30)
    CLAVESTRA_ALLOWED_ACTIONS:   Comma-separated action allowlist (default: all)
    CLAVESTRA_TRANSPORT:         "stdio" (default) or "http"
    CLAVESTRA_HTTP_PORT:         HTTP port (default: 8000)
    CLAVESTRA_API_TOKEN:         Bearer token for HTTP auth (optional)
"""

from __future__ import annotations

import hmac
import json
import os
import sys
from typing import Any

from fastmcp import FastMCP, Context
from fastmcp.exceptions import ToolError
from fastmcp.server.auth import TokenVerifier, AccessToken
from fastmcp.server.lifespan import Lifespan

from clavestra.client import FedimintClient
from clavestra.config import FedimintConfig
from clavestra.errors import ClavestError


# ---------------------------------------------------------------------------
# Bearer token authentication for HTTP transport
# ---------------------------------------------------------------------------


class BearerTokenVerifier(TokenVerifier):
    """Simple bearer token verifier using CLAVESTRA_API_TOKEN env var."""

    def __init__(self, token: str):
        super().__init__()
        self._token = token

    async def verify_token(self, token: str) -> AccessToken | None:
        """Verify bearer token using constant-time comparison."""
        if hmac.compare_digest(token, self._token):
            return AccessToken(
                token=token, client_id="clavestra", scopes=[], claims={}
            )
        return None


# ---------------------------------------------------------------------------
# Allowed actions parsing
# ---------------------------------------------------------------------------


def _parse_allowed_actions() -> list[str] | None:
    """Parse CLAVESTRA_ALLOWED_ACTIONS env var into a list of action names.

    Returns None if the variable is unset or empty (meaning all actions allowed).
    """
    raw = os.environ.get("CLAVESTRA_ALLOWED_ACTIONS")
    if raw is None or not raw.strip():
        return None
    actions = [a.strip() for a in raw.split(",") if a.strip()]
    return actions if actions else None


# ---------------------------------------------------------------------------
# Lifespan -- create FedimintClient once at server startup
# ---------------------------------------------------------------------------


@Lifespan
async def app_lifespan(server: FastMCP):
    """Initialize FedimintClient from env vars and inject into tool context."""
    config = FedimintConfig()
    allowed = _parse_allowed_actions()
    async with FedimintClient(config, allowed_actions=allowed) as client:
        yield {"client": client}


# ---------------------------------------------------------------------------
# FastMCP server instance (module-level for import by tests)
# ---------------------------------------------------------------------------

_transport = os.environ.get("CLAVESTRA_TRANSPORT", "stdio")
_api_token = os.environ.get("CLAVESTRA_API_TOKEN")
auth = (
    BearerTokenVerifier(_api_token)
    if (_api_token and _transport == "http")
    else None
)

mcp = FastMCP("clavestra", lifespan=app_lifespan, auth=auth)


# ---------------------------------------------------------------------------
# Shared error handler
# ---------------------------------------------------------------------------


async def _call(ctx: Context, coro: Any) -> Any:
    """Execute a client coroutine, converting ClavestError to ToolError.

    Non-ClavestError exceptions propagate to FastMCP's built-in catch-all
    (MCP-06 defense-in-depth).
    """
    try:
        return await coro
    except ClavestError as e:
        raise ToolError(json.dumps({
            "error_type": type(e).__name__,
            "message": str(e),
        })) from e


# ---------------------------------------------------------------------------
# MCP tools -- 6 tools wrapping FedimintClient operations
# ---------------------------------------------------------------------------


@mcp.tool()
async def ecash_spend(amount_msats: int, ctx: Context) -> str:
    """Spend eCash and return notes for transfer. Amount in millisatoshis (1 sat = 1000 msats)."""
    client = ctx.lifespan_context["client"]
    notes = await _call(ctx, client.spend(amount_msats))
    return json.dumps({"notes": notes})


@mcp.tool()
async def ecash_receive(notes: str, ctx: Context) -> str:
    """Receive eCash notes and add to wallet balance. Returns amount received in millisatoshis."""
    client = ctx.lifespan_context["client"]
    amount = await _call(ctx, client.receive(notes))
    return json.dumps({"amount_msats": amount})


@mcp.tool()
async def ecash_balance(ctx: Context) -> str:
    """Get current eCash wallet balance in millisatoshis (1 sat = 1000 msats)."""
    client = ctx.lifespan_context["client"]
    balance = await _call(ctx, client.balance())
    return json.dumps({"balance_msats": balance})


@mcp.tool()
async def ln_pay(bolt11: str, ctx: Context) -> str:
    """Pay a Lightning invoice using eCash balance."""
    client = ctx.lifespan_context["client"]
    op_id = await _call(ctx, client.pay_invoice(bolt11))
    return json.dumps({"operation_id": op_id})


@mcp.tool()
async def ln_create_invoice(amount_msats: int, description: str, ctx: Context) -> str:
    """Create a Lightning invoice to receive payment. Amount in millisatoshis (1 sat = 1000 msats)."""
    client = ctx.lifespan_context["client"]
    invoice = await _call(ctx, client.create_invoice(amount_msats, description))
    return json.dumps({"invoice": invoice})


@mcp.tool()
async def federation_info(ctx: Context) -> str:
    """Get federation metadata including ID, name, and network."""
    client = ctx.lifespan_context["client"]
    info = await _call(ctx, client.info())
    return json.dumps(info)


# ---------------------------------------------------------------------------
# Startup banner
# ---------------------------------------------------------------------------


def _print_banner(
    transport: str, tool_count: int, allowed: list[str] | None, auth_active: bool
) -> None:
    """Print brief server info to stderr."""
    line1 = f"clavestra MCP server | transport={transport} | tools={tool_count}"
    if transport == "http":
        line1 += f" | auth={'on' if auth_active else 'off'}"
    line2 = f"allowed_actions={'all' if allowed is None else ','.join(sorted(allowed))}"
    print(line1, file=sys.stderr)
    print(line2, file=sys.stderr)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    transport = os.environ.get("CLAVESTRA_TRANSPORT", "stdio")
    allowed = _parse_allowed_actions()
    auth_active = bool(os.environ.get("CLAVESTRA_API_TOKEN")) and transport == "http"
    _print_banner(transport, 6, allowed, auth_active)

    if transport == "http":
        port = int(os.environ.get("CLAVESTRA_HTTP_PORT", "8000"))
        mcp.run(transport="http", port=port)
    else:
        mcp.run(transport="stdio")
