"""Configuration for Clavestra SDK."""

from __future__ import annotations

import shutil
from pathlib import Path

from pydantic import ValidationError, model_validator
from pydantic_settings import BaseSettings
from typing_extensions import Self

from clavestra.errors import ConfigurationError


class FedimintConfig(BaseSettings):
    """Configuration for connecting to Fedimint via fedimint-cli.

    Reads from environment variables:
        FEDIMINT_CLI_PATH: Path to fedimint-cli binary (default: "fedimint-cli")
        FEDIMINT_DATA_DIR: Path to fedimint data directory (required)
        FEDIMINT_FEDERATION_ID: Federation ID (required). Stored for identification
            and logging purposes. Not passed to fedimint-cli because the CLI uses
            the active federation already joined in the data directory.
        FEDIMINT_TIMEOUT_SECONDS: Subprocess timeout in seconds (default: 30)
    """

    cli_path: str = "fedimint-cli"
    data_dir: str
    federation_id: str
    timeout_seconds: int = 30

    model_config = {"env_prefix": "FEDIMINT_"}

    @model_validator(mode="after")
    def validate_paths(self) -> Self:
        """Validate that CLI binary and data directory exist."""
        errors: list[str] = []

        # Validate CLI binary
        resolved = shutil.which(self.cli_path)
        if resolved is None:
            errors.append(
                f"fedimint-cli binary not found: '{self.cli_path}' "
                f"is not in PATH and does not exist as a file"
            )
        else:
            self.cli_path = resolved

        # Validate data directory
        data_path = Path(self.data_dir)
        if not data_path.is_dir():
            errors.append(f"Data directory does not exist: {self.data_dir}")

        if errors:
            raise ValueError("; ".join(errors))

        return self

    def __init__(self, **kwargs):
        """Create FedimintConfig, raising ConfigurationError on validation failure.

        Wraps pydantic's ValidationError into ConfigurationError so callers
        only need to catch ClavestError-hierarchy exceptions.
        """
        try:
            super().__init__(**kwargs)
        except ValidationError as e:
            raise ConfigurationError(str(e)) from e
