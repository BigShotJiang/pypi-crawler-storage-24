"""Custom exceptions for Clavestra SDK."""

from __future__ import annotations

import re


class ClavestError(Exception):
    """Base exception for all Clavestra SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        operation: str | None = None,
        exit_code: int | None = None,
        stderr: str | None = None,
    ):
        super().__init__(message)
        self.operation = operation
        self.exit_code = exit_code
        self.stderr = stderr


class ConfigurationError(ClavestError):
    """Raised when SDK configuration is invalid."""

    pass


class InsufficientBalanceError(ClavestError):
    """Raised when the wallet doesn't have enough eCash to spend."""

    def __init__(
        self,
        requested: int = 0,
        available: int = 0,
        *,
        operation: str | None = None,
        exit_code: int | None = None,
        stderr: str | None = None,
    ):
        self.requested = requested
        self.available = available
        super().__init__(
            f"Insufficient balance: requested {requested} msats, available {available} msats",
            operation=operation,
            exit_code=exit_code,
            stderr=stderr,
        )


class FederationOfflineError(ClavestError):
    """Raised when fedimint-cli cannot reach the federation."""

    pass


class InvalidNotesError(ClavestError):
    """Raised when eCash notes fail validation or are malformed."""

    pass


class GatewayError(ClavestError):
    """Raised when a Lightning gateway operation fails."""

    pass


class DoubleSpendError(ClavestError):
    """Raised when eCash notes have already been spent/reissued."""

    pass


class ActionNotAllowedError(ClavestError):
    """Raised when an action is blocked by the client's allowlist."""

    def __init__(
        self,
        message: str,
        *,
        action: str | None = None,
        allowed: list[str] | None = None,
        operation: str | None = None,
        exit_code: int | None = None,
        stderr: str | None = None,
    ):
        super().__init__(message, operation=operation, exit_code=exit_code, stderr=stderr)
        self.action = action
        self.allowed = allowed or []


# ---------------------------------------------------------------------------
# Error classification: maps raw subprocess stderr to typed domain errors
# ---------------------------------------------------------------------------

_AMOUNT_RE = re.compile(r"(\d+)\s*msats?", re.IGNORECASE)

_PATTERNS: list[tuple[re.Pattern[str], type[ClavestError]]] = [
    (re.compile(r"insufficient|not enough", re.IGNORECASE), InsufficientBalanceError),
    (
        re.compile(
            r"connection|timeout|unreachable|offline|timed?\s*out", re.IGNORECASE
        ),
        FederationOfflineError,
    ),
    (
        re.compile(r"invalid.*note|malformed|decode|verification", re.IGNORECASE),
        InvalidNotesError,
    ),
    (re.compile(r"gateway|lightning.*error|ln.*fail", re.IGNORECASE), GatewayError),
    (
        re.compile(r"double.?spend|already.*spent|already.*reissued", re.IGNORECASE),
        DoubleSpendError,
    ),
]


def classify_error(
    stderr: str,
    *,
    exit_code: int = 1,
    operation: str | None = None,
) -> ClavestError:
    """Classify raw subprocess stderr into a typed domain error.

    Args:
        stderr: Raw stderr output from fedimint-cli.
        exit_code: Process exit code.
        operation: The SDK operation that triggered this error.

    Returns:
        A ClavestError subclass instance.
    """
    context = {"operation": operation, "exit_code": exit_code, "stderr": stderr}

    for pattern, error_cls in _PATTERNS:
        if pattern.search(stderr):
            if error_cls is InsufficientBalanceError:
                amounts = _AMOUNT_RE.findall(stderr)
                requested = int(amounts[0]) if len(amounts) >= 1 else 0
                available = int(amounts[1]) if len(amounts) >= 2 else 0
                return InsufficientBalanceError(
                    requested=requested, available=available, **context
                )
            return error_cls(stderr.strip(), **context)

    return ClavestError(
        f"Command failed (exit code {exit_code})",
        **context,
    )
