"""Tests for clavestra.config module."""

from __future__ import annotations

import os

import pytest

from clavestra.config import FedimintConfig
from clavestra.errors import ClavestError, ConfigurationError


class TestConfigEnvVars:
    """Tests for FedimintConfig environment variable reading."""

    def test_config_reads_env_vars(self, monkeypatch, tmp_path):
        """FedimintConfig reads all 4 env vars correctly."""
        monkeypatch.setenv("FEDIMINT_CLI_PATH", "python")
        monkeypatch.setenv("FEDIMINT_DATA_DIR", str(tmp_path))
        monkeypatch.setenv("FEDIMINT_FEDERATION_ID", "fed123")
        monkeypatch.setenv("FEDIMINT_TIMEOUT_SECONDS", "60")
        config = FedimintConfig()
        assert config.federation_id == "fed123"
        assert config.timeout_seconds == 60

    def test_config_cli_path_default(self, monkeypatch, tmp_path):
        """Without FEDIMINT_CLI_PATH set, cli_path defaults to 'fedimint-cli'."""
        monkeypatch.delenv("FEDIMINT_CLI_PATH", raising=False)
        monkeypatch.setenv("FEDIMINT_DATA_DIR", str(tmp_path))
        monkeypatch.setenv("FEDIMINT_FEDERATION_ID", "test-fed")
        # Make shutil.which find a fake binary so validation passes
        monkeypatch.setattr("shutil.which", lambda x: "/usr/bin/fedimint-cli" if x == "fedimint-cli" else None)
        config = FedimintConfig()
        # cli_path is resolved by shutil.which
        assert config.cli_path == "/usr/bin/fedimint-cli"

    def test_config_timeout_default(self, monkeypatch, tmp_path):
        """Without FEDIMINT_TIMEOUT_SECONDS set, timeout_seconds defaults to 30."""
        monkeypatch.delenv("FEDIMINT_TIMEOUT_SECONDS", raising=False)
        monkeypatch.setenv("FEDIMINT_CLI_PATH", "python")
        monkeypatch.setenv("FEDIMINT_DATA_DIR", str(tmp_path))
        monkeypatch.setenv("FEDIMINT_FEDERATION_ID", "test-fed")
        config = FedimintConfig()
        assert config.timeout_seconds == 30


class TestConfigValidation:
    """Tests for FedimintConfig validation logic."""

    def test_config_data_dir_required(self, monkeypatch):
        """Without FEDIMINT_DATA_DIR, FedimintConfig() raises ConfigurationError."""
        monkeypatch.delenv("FEDIMINT_DATA_DIR", raising=False)
        monkeypatch.delenv("FEDIMINT_CLI_PATH", raising=False)
        monkeypatch.setenv("FEDIMINT_FEDERATION_ID", "test-fed")
        with pytest.raises(ConfigurationError):
            FedimintConfig()

    def test_config_federation_id_required(self, monkeypatch):
        """Without FEDIMINT_FEDERATION_ID, FedimintConfig() raises ConfigurationError."""
        monkeypatch.delenv("FEDIMINT_FEDERATION_ID", raising=False)
        monkeypatch.delenv("FEDIMINT_CLI_PATH", raising=False)
        monkeypatch.setenv("FEDIMINT_DATA_DIR", "/tmp")
        with pytest.raises(ConfigurationError):
            FedimintConfig()

    def test_config_validates_binary_not_found(self, monkeypatch, tmp_path):
        """With cli_path pointing to nonexistent binary, raises ConfigurationError."""
        monkeypatch.setenv("FEDIMINT_CLI_PATH", "nonexistent-binary-xyz-12345")
        monkeypatch.setenv("FEDIMINT_DATA_DIR", str(tmp_path))
        monkeypatch.setenv("FEDIMINT_FEDERATION_ID", "test-fed")
        # Ensure shutil.which returns None for the nonexistent binary
        monkeypatch.setattr("shutil.which", lambda x: None)
        with pytest.raises(ConfigurationError, match="not found"):
            FedimintConfig()

    def test_config_validates_data_dir_not_found(self, monkeypatch):
        """With data_dir pointing to nonexistent directory, raises ConfigurationError."""
        monkeypatch.setenv("FEDIMINT_CLI_PATH", "python")
        monkeypatch.setenv("FEDIMINT_DATA_DIR", "/nonexistent/path/abc123")
        monkeypatch.setenv("FEDIMINT_FEDERATION_ID", "test-fed")
        # Mock shutil.which so binary validation passes
        monkeypatch.setattr("shutil.which", lambda x: "/usr/bin/python")
        with pytest.raises(ConfigurationError, match="does not exist"):
            FedimintConfig()

    def test_config_valid_paths(self, monkeypatch, tmp_path):
        """With a real binary and real temp directory, FedimintConfig() succeeds."""
        monkeypatch.setenv("FEDIMINT_DATA_DIR", str(tmp_path))
        monkeypatch.setenv("FEDIMINT_FEDERATION_ID", "test-fed-id")
        # Use "python" as a binary that exists on all systems
        monkeypatch.setenv("FEDIMINT_CLI_PATH", "python")
        config = FedimintConfig()
        assert config.data_dir == str(tmp_path)
        assert config.federation_id == "test-fed-id"
        assert config.timeout_seconds == 30
        # cli_path should be resolved to absolute path
        assert os.path.isabs(config.cli_path)

    def test_config_raises_configuration_error_not_validation_error(self, monkeypatch):
        """Bad config raises ConfigurationError (ClavestError subclass), NOT pydantic.ValidationError."""
        monkeypatch.setenv("FEDIMINT_DATA_DIR", "/nonexistent/path")
        monkeypatch.setenv("FEDIMINT_FEDERATION_ID", "test-fed")
        monkeypatch.setattr("shutil.which", lambda x: None)
        with pytest.raises(ConfigurationError) as exc_info:
            FedimintConfig()
        assert isinstance(exc_info.value, ClavestError)
        # Ensure it is NOT a pydantic ValidationError
        from pydantic import ValidationError

        assert not isinstance(exc_info.value, ValidationError)
