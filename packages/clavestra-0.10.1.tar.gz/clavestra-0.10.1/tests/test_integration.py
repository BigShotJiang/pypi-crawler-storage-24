"""Integration tests for Clavestra SDK against a real Fedimint federation.

These tests require FEDIMINT_DATA_DIR and FEDIMINT_FEDERATION_ID environment
variables to be set.  When the env vars are missing the entire module is
skipped with a clear warning.
"""

from __future__ import annotations

import os

import pytest

from clavestra.client import FedimintClient
from clavestra.config import FedimintConfig

# ---------------------------------------------------------------------------
# Module-level marker -- every test in this file is an integration test
# ---------------------------------------------------------------------------
pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _federation_env_set() -> bool:
    """Return True when the required federation env vars are present."""
    return bool(
        os.environ.get("FEDIMINT_DATA_DIR")
        and os.environ.get("FEDIMINT_FEDERATION_ID")
    )


# ---------------------------------------------------------------------------
# Module-scoped fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def federation_config():
    """Build a FedimintConfig from real env vars or skip the module."""
    if not _federation_env_set():
        pytest.skip("FEDIMINT_* env vars not set -- skipping integration tests")

    try:
        return FedimintConfig()
    except Exception as e:
        pytest.fail(f"FEDIMINT_* set but config invalid: {e}")


@pytest.fixture(scope="module")
async def federation_client(federation_config):
    """Yield a live FedimintClient connected to the real federation."""
    async with FedimintClient(federation_config) as client:
        yield client


# ---------------------------------------------------------------------------
# eCash operations
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestECashOperations:
    """eCash operations against a live federation."""

    async def test_01_balance(self, federation_client):
        result = await federation_client.balance()
        assert isinstance(result, int)
        assert result >= 0

    async def test_02_info(self, federation_client):
        result = await federation_client.info()
        assert isinstance(result, dict)
        assert "total_amount_msat" in result

    async def test_03_spend(self, federation_client):
        notes = await federation_client.spend(1000)
        assert isinstance(notes, str)
        assert len(notes) > 0

    async def test_04_receive(self, federation_client):
        # Spend first to get fresh notes (each test independent of wallet state)
        notes = await federation_client.spend(1000)
        amount = await federation_client.receive(notes)
        assert isinstance(amount, int)
        assert amount > 0


# ---------------------------------------------------------------------------
# Lightning operations
# ---------------------------------------------------------------------------

@pytest.mark.lightning
class TestLightningOperations:
    """Lightning operations against a live federation with gateway."""

    async def test_01_create_invoice(self, federation_client):
        invoice = await federation_client.create_invoice(1000, "integration test")
        assert isinstance(invoice, str)
        assert invoice.startswith("ln")

    async def test_02_pay_invoice(self, federation_client):
        invoice = await federation_client.create_invoice(1000, "self-pay test")
        operation_id = await federation_client.pay_invoice(invoice)
        assert isinstance(operation_id, str)
        assert len(operation_id) > 0
