"""Tests for clavestra.mcp MCP server module.

Validates tool registration (MCP-01), structured error responses (MCP-04),
allowlist enforcement (MCP-05), and unhandled exception safety (MCP-06)
using FastMCP's call_tool() API -- no server process needed.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastmcp.exceptions import ToolError

from clavestra.errors import (
    ActionNotAllowedError,
    InsufficientBalanceError,
)
from clavestra.mcp import mcp


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def mock_client():
    """Return a MagicMock FedimintClient with AsyncMock methods."""
    client = MagicMock()
    client.balance = AsyncMock(return_value=50000)
    client.spend = AsyncMock(return_value="base64notes==")
    client.receive = AsyncMock(return_value=10000)
    client.info = AsyncMock(
        return_value={"federation_id": "abc123", "network": "signet"}
    )
    client.pay_invoice = AsyncMock(return_value="op123")
    client.create_invoice = AsyncMock(return_value="lnbc50u1...")
    return client


@pytest.fixture(autouse=True)
def _inject_mock_client(mock_client):
    """Inject the mock client into the MCP server's lifespan result.

    FastMCP's call_tool() creates a Context whose lifespan_context property
    falls back to server._lifespan_result when no MCP session is active.
    """
    old = mcp._lifespan_result
    mcp._lifespan_result = {"client": mock_client}
    yield
    mcp._lifespan_result = old


# ---------------------------------------------------------------------------
# TestToolRegistration (MCP-01)
# ---------------------------------------------------------------------------


class TestToolRegistration:
    """Verify that all 6 MCP tools are registered with correct names."""

    async def test_exactly_six_tools_registered(self):
        """mcp.list_tools() returns exactly 6 tools."""
        tools = await mcp.list_tools()
        assert len(tools) == 6

    async def test_tool_names_match_expected_set(self):
        """Tool names are the exact set from the spec."""
        tools = await mcp.list_tools()
        names = {t.name for t in tools}
        expected = {
            "ecash_spend",
            "ecash_receive",
            "ecash_balance",
            "ln_pay",
            "ln_create_invoice",
            "federation_info",
        }
        assert names == expected


# ---------------------------------------------------------------------------
# TestToolResponses (MCP-01, MCP-04)
# ---------------------------------------------------------------------------


class TestToolResponses:
    """Verify each tool returns the correct JSON response shape."""

    async def test_ecash_balance_returns_json(self, mock_client):
        """ecash_balance returns {"balance_msats": N}."""
        result = await mcp.call_tool("ecash_balance", {})
        data = json.loads(result.content[0].text)
        assert data == {"balance_msats": 50000}
        mock_client.balance.assert_awaited_once()

    async def test_ecash_spend_returns_json(self, mock_client):
        """ecash_spend returns {"notes": "..."}."""
        result = await mcp.call_tool("ecash_spend", {"amount_msats": 10000})
        data = json.loads(result.content[0].text)
        assert data == {"notes": "base64notes=="}
        mock_client.spend.assert_awaited_once_with(10000)

    async def test_ecash_receive_returns_json(self, mock_client):
        """ecash_receive returns {"amount_msats": N}."""
        result = await mcp.call_tool("ecash_receive", {"notes": "base64notes=="})
        data = json.loads(result.content[0].text)
        assert data == {"amount_msats": 10000}
        mock_client.receive.assert_awaited_once_with("base64notes==")

    async def test_federation_info_returns_json(self, mock_client):
        """federation_info returns the full dict from client.info()."""
        result = await mcp.call_tool("federation_info", {})
        data = json.loads(result.content[0].text)
        assert data == {"federation_id": "abc123", "network": "signet"}
        mock_client.info.assert_awaited_once()

    async def test_ln_pay_returns_json(self, mock_client):
        """ln_pay returns {"operation_id": "..."}."""
        result = await mcp.call_tool("ln_pay", {"bolt11": "lnbc1..."})
        data = json.loads(result.content[0].text)
        assert data == {"operation_id": "op123"}
        mock_client.pay_invoice.assert_awaited_once_with("lnbc1...")

    async def test_ln_create_invoice_returns_json(self, mock_client):
        """ln_create_invoice returns {"invoice": "..."}."""
        result = await mcp.call_tool(
            "ln_create_invoice",
            {"amount_msats": 50000, "description": "test"},
        )
        data = json.loads(result.content[0].text)
        assert data == {"invoice": "lnbc50u1..."}
        mock_client.create_invoice.assert_awaited_once_with(50000, "test")


# ---------------------------------------------------------------------------
# TestErrorHandling (MCP-04)
# ---------------------------------------------------------------------------


class TestErrorHandling:
    """Verify ClavestError subclasses produce structured JSON error responses."""

    async def test_clavest_error_returns_structured_json(self, mock_client):
        """InsufficientBalanceError -> ToolError with JSON containing error_type and message."""
        mock_client.balance = AsyncMock(
            side_effect=InsufficientBalanceError(requested=10000, available=5000)
        )
        with pytest.raises(ToolError) as exc_info:
            await mcp.call_tool("ecash_balance", {})

        data = json.loads(str(exc_info.value))
        assert data["error_type"] == "InsufficientBalanceError"
        assert "message" in data
        assert "10000" in data["message"]
        assert "5000" in data["message"]


# ---------------------------------------------------------------------------
# TestAllowlistEnforcement (MCP-05)
# ---------------------------------------------------------------------------


class TestAllowlistEnforcement:
    """Verify ActionNotAllowedError produces permission error JSON."""

    async def test_action_not_allowed_returns_permission_error(self, mock_client):
        """ActionNotAllowedError -> ToolError with error_type ActionNotAllowedError."""
        mock_client.spend = AsyncMock(
            side_effect=ActionNotAllowedError(
                "Action 'spend' is not allowed",
                action="spend",
                allowed=["balance"],
            )
        )
        with pytest.raises(ToolError) as exc_info:
            await mcp.call_tool("ecash_spend", {"amount_msats": 10000})

        data = json.loads(str(exc_info.value))
        assert data["error_type"] == "ActionNotAllowedError"
        assert "message" in data


# ---------------------------------------------------------------------------
# TestUnhandledException (MCP-06)
# ---------------------------------------------------------------------------


class TestUnhandledException:
    """Verify non-ClavestError exceptions do not crash the server."""

    async def test_non_clavest_error_does_not_crash(self, mock_client):
        """RuntimeError -> ToolError (server stays alive, does not crash)."""
        mock_client.balance = AsyncMock(
            side_effect=RuntimeError("unexpected internal error")
        )
        with pytest.raises(ToolError):
            await mcp.call_tool("ecash_balance", {})
        # The key assertion: we reached this line, so the server did not crash.
        # The exception was wrapped in ToolError by FastMCP's catch-all.
