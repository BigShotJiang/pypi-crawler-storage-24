"""Tests for clavestra.errors module."""

from __future__ import annotations

import pytest

from clavestra.errors import (
    ClavestError,
    ConfigurationError,
    DoubleSpendError,
    FederationOfflineError,
    GatewayError,
    InsufficientBalanceError,
    InvalidNotesError,
    classify_error,
)


# ---------------------------------------------------------------------------
# ClavestError base class tests
# ---------------------------------------------------------------------------


class TestClavestErrorBase:
    """Tests for the ClavestError base exception."""

    def test_clavest_error_base(self):
        """ClavestError stores message and all structured context attributes."""
        e = ClavestError("msg", operation="spend", exit_code=1, stderr="raw")
        assert str(e) == "msg"
        assert e.operation == "spend"
        assert e.exit_code == 1
        assert e.stderr == "raw"

    def test_clavest_error_defaults(self):
        """ClavestError without kwargs has None defaults for all context attrs."""
        e = ClavestError("msg")
        assert e.operation is None
        assert e.exit_code is None
        assert e.stderr is None


# ---------------------------------------------------------------------------
# Subclass hierarchy tests
# ---------------------------------------------------------------------------


class TestErrorSubclasses:
    """Tests for ClavestError subclass hierarchy."""

    def test_configuration_error_is_clavest_error(self):
        """ConfigurationError is a subclass of ClavestError."""
        assert isinstance(ConfigurationError("bad"), ClavestError)

    def test_insufficient_balance_error(self):
        """InsufficientBalanceError stores requested and available amounts."""
        e = InsufficientBalanceError(1000, 500, operation="spend")
        assert e.requested == 1000
        assert e.available == 500
        assert e.operation == "spend"
        assert "1000" in str(e)
        assert "500" in str(e)

    def test_insufficient_balance_error_defaults(self):
        """InsufficientBalanceError with no args defaults to requested=0, available=0."""
        e = InsufficientBalanceError()
        assert e.requested == 0
        assert e.available == 0

    def test_federation_offline_error(self):
        """FederationOfflineError is catchable as itself and ClavestError, but not as other subclasses."""
        e = FederationOfflineError("offline", operation="balance")

        # Catchable as FederationOfflineError
        with pytest.raises(FederationOfflineError):
            raise e

        # Catchable as ClavestError
        with pytest.raises(ClavestError):
            raise e

        # NOT catchable as InsufficientBalanceError
        with pytest.raises(FederationOfflineError):
            try:
                raise e
            except InsufficientBalanceError:
                pytest.fail("Should not catch FederationOfflineError as InsufficientBalanceError")
            except FederationOfflineError:
                raise

    def test_invalid_notes_error(self):
        """InvalidNotesError is a ClavestError but not another subclass."""
        e = InvalidNotesError("bad")
        assert isinstance(e, ClavestError)
        assert not isinstance(e, InsufficientBalanceError)
        assert not isinstance(e, FederationOfflineError)
        assert not isinstance(e, GatewayError)
        assert not isinstance(e, DoubleSpendError)
        assert not isinstance(e, ConfigurationError)

    def test_gateway_error(self):
        """GatewayError is a ClavestError but not another subclass."""
        e = GatewayError("gw fail")
        assert isinstance(e, ClavestError)
        assert not isinstance(e, InsufficientBalanceError)
        assert not isinstance(e, FederationOfflineError)
        assert not isinstance(e, InvalidNotesError)
        assert not isinstance(e, DoubleSpendError)
        assert not isinstance(e, ConfigurationError)

    def test_double_spend_error(self):
        """DoubleSpendError is a ClavestError but not another subclass."""
        e = DoubleSpendError("spent")
        assert isinstance(e, ClavestError)
        assert not isinstance(e, InsufficientBalanceError)
        assert not isinstance(e, FederationOfflineError)
        assert not isinstance(e, InvalidNotesError)
        assert not isinstance(e, GatewayError)
        assert not isinstance(e, ConfigurationError)


# ---------------------------------------------------------------------------
# Independence test (parametrized)
# ---------------------------------------------------------------------------


# All 7 error subclasses that directly extend ClavestError
_ERROR_CLASSES: list[type[ClavestError]] = [
    ConfigurationError,
    InsufficientBalanceError,
    FederationOfflineError,
    InvalidNotesError,
    GatewayError,
    DoubleSpendError,
]


def _make_instance(cls: type[ClavestError]) -> ClavestError:
    """Create a test instance of the given error class."""
    if cls is InsufficientBalanceError:
        return cls(100, 50)
    return cls("test error")


class TestErrorIndependence:
    """Each error subclass is independently catchable without catching unrelated errors."""

    @pytest.mark.parametrize("target_cls", _ERROR_CLASSES, ids=lambda c: c.__name__)
    def test_all_errors_independent(self, target_cls: type[ClavestError]):
        """Catching one specific error does NOT catch any of the other subclasses."""
        target_instance = _make_instance(target_cls)

        # Verify it IS catchable as itself
        assert isinstance(target_instance, target_cls)

        # Verify it IS catchable as ClavestError
        assert isinstance(target_instance, ClavestError)

        # Verify it is NOT catchable as any OTHER subclass
        for other_cls in _ERROR_CLASSES:
            if other_cls is target_cls:
                continue
            assert not isinstance(target_instance, other_cls), (
                f"{target_cls.__name__} instance should not be an instance of {other_cls.__name__}"
            )


# ---------------------------------------------------------------------------
# classify_error() tests
# ---------------------------------------------------------------------------


class TestClassifyError:
    """Tests for the classify_error() function."""

    def test_classify_insufficient_balance(self):
        """classify_error maps 'insufficient balance' stderr to InsufficientBalanceError with parsed amounts."""
        stderr = "insufficient balance 5000 msats requested but only 2000 msats available"
        result = classify_error(stderr, operation="spend")
        assert isinstance(result, InsufficientBalanceError)
        assert result.requested == 5000
        assert result.available == 2000
        assert result.operation == "spend"

    def test_classify_federation_offline(self):
        """classify_error maps 'connection timeout' to FederationOfflineError."""
        result = classify_error("connection timeout", operation="balance")
        assert isinstance(result, FederationOfflineError)
        assert result.operation == "balance"

    def test_classify_invalid_notes(self):
        """classify_error maps 'invalid note format' to InvalidNotesError."""
        result = classify_error("invalid note format: malformed data", operation="receive")
        assert isinstance(result, InvalidNotesError)
        assert result.operation == "receive"

    def test_classify_gateway_error(self):
        """classify_error maps gateway-related stderr to GatewayError."""
        result = classify_error("gateway routing error: no path found", operation="pay_invoice")
        assert isinstance(result, GatewayError)
        assert result.operation == "pay_invoice"

    def test_classify_double_spend(self):
        """classify_error maps 'already spent notes detected' to DoubleSpendError."""
        result = classify_error("already spent notes detected", operation="receive")
        assert isinstance(result, DoubleSpendError)
        assert result.operation == "receive"

    def test_classify_fallback(self):
        """classify_error maps unrecognized stderr to generic ClavestError (not subclass)."""
        result = classify_error("some unknown error xyz", exit_code=42, operation="info")
        assert type(result) is ClavestError  # Exact type, not a subclass
        assert result.exit_code == 42
        assert result.operation == "info"
        assert "unknown error" in result.stderr

    def test_classify_preserves_context(self):
        """Every classify_error result has operation, exit_code, and stderr attributes set."""
        test_cases = [
            "insufficient balance 100 msats",
            "connection timeout",
            "invalid note format: bad",
            "gateway routing error: no path found",
            "already spent notes detected",
            "totally unknown error",
        ]
        for stderr_text in test_cases:
            result = classify_error(stderr_text, exit_code=7, operation="test_op")
            assert result.operation == "test_op", f"Failed for: {stderr_text}"
            assert result.exit_code == 7, f"Failed for: {stderr_text}"
            assert result.stderr == stderr_text, f"Failed for: {stderr_text}"
