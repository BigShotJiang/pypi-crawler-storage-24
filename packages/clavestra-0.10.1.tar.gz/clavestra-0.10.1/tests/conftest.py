"""Shared fixtures for all Clavestra test modules."""
from __future__ import annotations

import pytest
from clavestra.config import FedimintConfig


@pytest.fixture()
def config(monkeypatch, tmp_path):
    """Create a FedimintConfig with mocked binary path for unit tests."""
    monkeypatch.setattr("shutil.which", lambda x: str(tmp_path / "fedimint-cli"))
    (tmp_path / "fedimint-cli").touch()
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    return FedimintConfig(
        cli_path=str(tmp_path / "fedimint-cli"),
        data_dir=str(data_dir),
        federation_id="test-federation-id",
        timeout_seconds=5,
    )
