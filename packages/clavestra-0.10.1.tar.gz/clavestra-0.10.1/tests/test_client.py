"""Tests for clavestra.client module."""

from __future__ import annotations

import asyncio
import json

import pytest

from clavestra.client import FedimintClient, VALID_ACTIONS
from clavestra.errors import (
    ActionNotAllowedError,
    ClavestError,
    DoubleSpendError,
    FederationOfflineError,
    GatewayError,
    InsufficientBalanceError,
    InvalidNotesError,
)


# ---------------------------------------------------------------------------
# TestClientInit (CTRL-01)
# ---------------------------------------------------------------------------


class TestClientInit:
    """Tests for FedimintClient construction and init-time validation."""

    def test_init_accepts_config(self, config):
        """FedimintClient(config) succeeds without error."""
        client = FedimintClient(config)
        assert client is not None

    def test_init_with_allowed_actions(self, config):
        """FedimintClient with allowed_actions stores them as a frozenset."""
        client = FedimintClient(config, allowed_actions=["balance", "spend"])
        assert client._allowed_actions == frozenset({"balance", "spend"})

    def test_init_with_none_allowed_actions(self, config):
        """FedimintClient with allowed_actions=None permits all actions."""
        client = FedimintClient(config, allowed_actions=None)
        assert client._allowed_actions is None

    def test_init_rejects_invalid_action_name(self, config):
        """FedimintClient rejects invalid action names with ValueError."""
        with pytest.raises(ValueError, match="Invalid action names"):
            FedimintClient(config, allowed_actions=["balance", "invalid"])

    def test_valid_actions_constant(self):
        """VALID_ACTIONS contains exactly the 6 defined action names."""
        assert VALID_ACTIONS == frozenset({
            "balance", "spend", "receive", "info", "pay_invoice", "create_invoice"
        })


# ---------------------------------------------------------------------------
# TestAllowlistEnforcement (CTRL-02, CTRL-03)
# ---------------------------------------------------------------------------


class TestAllowlistEnforcement:
    """Tests for allowlist enforcement at the client level."""

    def test_allowed_action_does_not_raise(self, config):
        """_check_allowed does not raise for an allowed action."""
        client = FedimintClient(config, allowed_actions=["balance"])
        client._check_allowed("balance")  # Should not raise

    def test_disallowed_action_raises_before_subprocess(self, config):
        """_check_allowed raises ActionNotAllowedError for a disallowed action."""
        client = FedimintClient(config, allowed_actions=["balance"])
        with pytest.raises(ActionNotAllowedError) as exc_info:
            client._check_allowed("spend")
        assert exc_info.value.action == "spend"
        assert "balance" in exc_info.value.allowed

    def test_none_allowlist_permits_all(self, config):
        """_check_allowed with None allowlist permits all actions."""
        client = FedimintClient(config, allowed_actions=None)
        # None of these should raise
        for action in VALID_ACTIONS:
            client._check_allowed(action)


# ---------------------------------------------------------------------------
# TestAmountValidation -- input validation for monetary amounts
# ---------------------------------------------------------------------------


class TestAmountValidation:
    """Tests that spend() and create_invoice() reject non-positive amounts."""

    async def test_spend_zero_raises_value_error(self, config):
        """spend(0) raises ValueError before subprocess."""
        client = FedimintClient(config)
        with pytest.raises(ValueError, match="amount_msats must be positive"):
            await client.spend(0)

    async def test_spend_negative_raises_value_error(self, config):
        """spend(-100) raises ValueError before subprocess."""
        client = FedimintClient(config)
        with pytest.raises(ValueError, match="amount_msats must be positive"):
            await client.spend(-100)

    async def test_spend_positive_does_not_raise_value_error(self, config, fp):
        """spend(1) does NOT raise ValueError (proceeds to subprocess)."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "spend", "1"],
            stdout=json.dumps({"notes": "base64notes=="}).encode(),
            returncode=0,
        )
        client = FedimintClient(config)
        result = await client.spend(1)
        assert result == "base64notes=="

    async def test_create_invoice_zero_raises_value_error(self, config):
        """create_invoice(0, "desc") raises ValueError before subprocess."""
        client = FedimintClient(config)
        with pytest.raises(ValueError, match="amount_msats must be positive"):
            await client.create_invoice(0, "desc")

    async def test_create_invoice_negative_raises_value_error(self, config):
        """create_invoice(-1, "desc") raises ValueError before subprocess."""
        client = FedimintClient(config)
        with pytest.raises(ValueError, match="amount_msats must be positive"):
            await client.create_invoice(-1, "desc")

    async def test_validation_fires_before_check_allowed(self, config):
        """Validation fires BEFORE _check_allowed -- ValueError, not ActionNotAllowedError."""
        client = FedimintClient(config, allowed_actions=["balance"])
        with pytest.raises(ValueError, match="amount_msats must be positive"):
            await client.spend(0)


# ---------------------------------------------------------------------------
# TestClientOperations (CORE-01 through CORE-05, LN-01, LN-02)
# ---------------------------------------------------------------------------


class TestClientOperations:
    """Tests for FedimintClient async operations using mocked subprocess."""

    async def test_balance_returns_int(self, config, fp):
        """balance() returns total_amount_msat as an int."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            stdout=json.dumps({"total_amount_msat": 50000}).encode(),
            returncode=0,
        )
        client = FedimintClient(config)
        result = await client.balance()
        assert result == 50000
        assert isinstance(result, int)

    async def test_spend_returns_notes_string(self, config, fp):
        """spend() returns the notes field as a str."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "spend", "10000"],
            stdout=json.dumps({"notes": "base64notes=="}).encode(),
            returncode=0,
        )
        client = FedimintClient(config)
        result = await client.spend(10000)
        assert result == "base64notes=="
        assert isinstance(result, str)

    async def test_receive_returns_amount_int(self, config, fp):
        """receive() returns the amount_msat field as an int."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "reissue", "base64notes=="],
            stdout=json.dumps({"amount_msat": 10000}).encode(),
            returncode=0,
        )
        client = FedimintClient(config)
        result = await client.receive("base64notes==")
        assert result == 10000
        assert isinstance(result, int)

    async def test_info_returns_full_dict(self, config, fp):
        """info() returns the full JSON dict from fedimint-cli."""
        expected = {
            "total_amount_msat": 50000,
            "federation_id": "abc123",
            "network": "signet",
        }
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            stdout=json.dumps(expected).encode(),
            returncode=0,
        )
        client = FedimintClient(config)
        result = await client.info()
        assert result == expected
        assert isinstance(result, dict)

    async def test_pay_invoice_returns_operation_id(self, config, fp):
        """pay_invoice() returns the operation_id field as a str."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "ln-pay", "lnbc1..."],
            stdout=json.dumps({"operation_id": "op123"}).encode(),
            returncode=0,
        )
        client = FedimintClient(config)
        result = await client.pay_invoice("lnbc1...")
        assert result == "op123"

    async def test_create_invoice_returns_bolt11(self, config, fp):
        """create_invoice() returns the invoice field as a str."""
        fp.register(
            [
                config.cli_path, "--data-dir", config.data_dir,
                "ln-invoice", "--amount", "50000", "--description", "test payment",
            ],
            stdout=json.dumps({"invoice": "lnbc50u1..."}).encode(),
            returncode=0,
        )
        client = FedimintClient(config)
        result = await client.create_invoice(50000, "test payment")
        assert result == "lnbc50u1..."

    async def test_nonzero_exit_raises_classified_error(self, config, fp):
        """Non-zero exit code raises a ClavestError (via classify_error)."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            stderr=b"some unknown error from cli",
            returncode=1,
        )
        client = FedimintClient(config)
        with pytest.raises(ClavestError):
            await client.balance()


# ---------------------------------------------------------------------------
# TestAsyncContextManager
# ---------------------------------------------------------------------------


class TestAsyncContextManager:
    """Tests for FedimintClient async context manager protocol."""

    async def test_context_manager_returns_client(self, config):
        """async with FedimintClient(config) as client: returns the client."""
        async with FedimintClient(config) as client:
            assert isinstance(client, FedimintClient)


# ---------------------------------------------------------------------------
# TestSyncWrappers (CORE-06)
# ---------------------------------------------------------------------------


class TestSyncWrappers:
    """Tests for synchronous wrapper methods."""

    def test_sync_balance_works_outside_event_loop(self, config, fp):
        """balance_sync() works when no event loop is running."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            stdout=json.dumps({"total_amount_msat": 50000}).encode(),
            returncode=0,
        )
        client = FedimintClient(config)
        result = client.balance_sync()
        assert result == 50000
        assert isinstance(result, int)

    async def test_sync_wrapper_raises_in_async_context(self, config):
        """balance_sync() raises RuntimeError when an event loop is running."""
        client = FedimintClient(config)
        with pytest.raises(RuntimeError, match="cannot be called from an async context"):
            client.balance_sync()


# ---------------------------------------------------------------------------
# TestTimeout (CORE-01 -- subprocess lifecycle / timeout handling)
# ---------------------------------------------------------------------------


class TestTimeout:
    """Tests for subprocess timeout and FederationOfflineError."""

    async def test_timeout_raises_federation_offline_error(self, config, fp, monkeypatch):
        """A subprocess that exceeds timeout raises FederationOfflineError."""
        # Use a very short timeout
        monkeypatch.setattr(config, "timeout_seconds", 0.01)

        # Register a fake process that takes too long by providing a callback
        # that sleeps. pytest-subprocess supports callable for stdout.
        def slow_callback(input):  # noqa: A002
            import time
            time.sleep(1)
            return {"stdout": b"", "stderr": b""}

        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            callback=slow_callback,
        )
        client = FedimintClient(config)
        with pytest.raises(FederationOfflineError, match="timed out"):
            await client.balance()


# ---------------------------------------------------------------------------
# TestErrorClassification (TEST-04 -- error types through _run_cli flow)
# ---------------------------------------------------------------------------


class TestErrorClassification:
    """Tests that each error type is raised when _run_cli receives matching stderr."""

    async def test_insufficient_balance_from_subprocess(self, config, fp):
        """spend() raises InsufficientBalanceError with parsed amounts."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "spend", "999999"],
            stderr=b"insufficient balance 999999 msats requested but only 100 msats available",
            returncode=1,
        )
        client = FedimintClient(config)
        with pytest.raises(InsufficientBalanceError) as exc_info:
            await client.spend(999999)
        assert exc_info.value.requested == 999999
        assert exc_info.value.available == 100

    async def test_federation_offline_from_subprocess(self, config, fp):
        """balance() raises FederationOfflineError on connection timeout stderr."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            stderr=b"connection timeout waiting for federation",
            returncode=1,
        )
        client = FedimintClient(config)
        with pytest.raises(FederationOfflineError):
            await client.balance()

    async def test_invalid_notes_from_subprocess(self, config, fp):
        """receive() raises InvalidNotesError on malformed note data stderr."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "reissue", "bad"],
            stderr=b"invalid note format: malformed data",
            returncode=1,
        )
        client = FedimintClient(config)
        with pytest.raises(InvalidNotesError):
            await client.receive("bad")

    async def test_gateway_error_from_subprocess(self, config, fp):
        """pay_invoice() raises GatewayError on gateway routing failure stderr."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "ln-pay", "lnbc1..."],
            stderr=b"gateway routing error: no path found",
            returncode=1,
        )
        client = FedimintClient(config)
        with pytest.raises(GatewayError):
            await client.pay_invoice("lnbc1...")

    async def test_double_spend_from_subprocess(self, config, fp):
        """receive() raises DoubleSpendError on already-spent notes stderr."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "reissue", "spent_notes"],
            stderr=b"already spent notes detected",
            returncode=1,
        )
        client = FedimintClient(config)
        with pytest.raises(DoubleSpendError):
            await client.receive("spent_notes")


# ---------------------------------------------------------------------------
# TestAllowlistSubprocessProof (TEST-05 -- subprocess never invoked for blocked actions)
# ---------------------------------------------------------------------------


class TestAllowlistSubprocessProof:
    """Tests proving subprocess is never invoked for disallowed actions."""

    async def test_disallowed_spend_never_invokes_subprocess(self, config, fp):
        """Disallowed action raises ActionNotAllowedError without subprocess call."""
        fp.register(
            [config.cli_path, fp.any()],
        )
        client = FedimintClient(config, allowed_actions=["balance"])
        with pytest.raises(ActionNotAllowedError):
            await client.spend(1000)
        assert fp.call_count([config.cli_path, fp.any()]) == 0

    async def test_allowed_action_does_invoke_subprocess(self, config, fp):
        """Allowed action invokes subprocess and returns data."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            stdout=json.dumps({"total_amount_msat": 50000}).encode(),
            returncode=0,
        )
        client = FedimintClient(config, allowed_actions=["balance"])
        result = await client.balance()
        assert result == 50000


# ---------------------------------------------------------------------------
# TestMalformedOutput (TEST-04 -- malformed CLI stdout raises ClavestError)
# ---------------------------------------------------------------------------


class TestMalformedOutput:
    """Tests that malformed CLI output raises ClavestError, not json.JSONDecodeError."""

    async def test_invalid_json_stdout_raises_clavest_error(self, config, fp):
        """Invalid JSON stdout raises ClavestError with 'Malformed CLI output'."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            stdout=b"not valid json {{{",
            returncode=0,
        )
        client = FedimintClient(config)
        with pytest.raises(ClavestError, match="Malformed CLI output"):
            await client.info()

    async def test_empty_stdout_raises_clavest_error(self, config, fp):
        """Empty stdout raises ClavestError with 'Malformed CLI output'."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            stdout=b"",
            returncode=0,
        )
        client = FedimintClient(config)
        with pytest.raises(ClavestError, match="Malformed CLI output"):
            await client.balance()

    async def test_truncated_json_raises_clavest_error(self, config, fp):
        """Truncated JSON stdout raises ClavestError with 'Malformed CLI output'."""
        fp.register(
            [config.cli_path, "--data-dir", config.data_dir, "info"],
            stdout=b'{"total_amount',
            returncode=0,
        )
        client = FedimintClient(config)
        with pytest.raises(ClavestError, match="Malformed CLI output"):
            await client.balance()
