# clavestra

Python SDK for Fedimint eCash operations.

## Install

```bash
pip install clavestra
```

## Usage

```python
from clavestra import FedimintClient, FedimintConfig

client = FedimintClient(config=FedimintConfig(...))

notes = await client.spend(1000)
amount = await client.receive(notes)
balance = await client.balance()
```

## License

MIT
