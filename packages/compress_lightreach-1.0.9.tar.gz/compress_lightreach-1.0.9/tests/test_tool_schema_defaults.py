from api.services.tool_schemas import (
    apply_default_repo_search_tooling,
    default_repo_search_tools,
)
from api.services.complete.agentic_controller_v2 import _augment_tools_with_investigation_meta


def _names(tools):
    out = []
    for t in tools or []:
        try:
            fn = (t or {}).get("function") if isinstance(t, dict) else None
            nm = (fn or {}).get("name") if isinstance(fn, dict) else None
            if isinstance(nm, str) and nm.strip():
                out.append(nm.strip())
        except Exception:
            continue
    return out


def test_default_repo_search_tools_has_expected_primitives():
    names = set(_names(default_repo_search_tools()))
    assert {"Read", "Glob", "Grep", "FindInFile"}.issubset(names)


def test_apply_default_repo_search_tooling_injects_when_missing():
    tools, tool_choice, injected = apply_default_repo_search_tooling(
        enable_tools=True,
        system_integration=None,
        tools=None,
        tool_choice=None,
    )
    assert injected is True
    assert isinstance(tools, list) and len(tools) >= 3
    assert tool_choice == "auto"
    assert {"Read", "Glob", "Grep"}.issubset(set(_names(tools)))


def test_apply_default_repo_search_tooling_does_not_inject_for_cursor():
    tools, tool_choice, injected = apply_default_repo_search_tooling(
        enable_tools=True,
        system_integration="cursor",
        tools=None,
        tool_choice=None,
    )
    assert injected is False
    assert tools is None
    assert tool_choice is None


def test_agentic_augment_tools_ensures_repo_search_primitives():
    out = _augment_tools_with_investigation_meta([])
    names = set(_names(out))
    assert {"Read", "Glob", "Grep", "FindInFile"}.issubset(names)

