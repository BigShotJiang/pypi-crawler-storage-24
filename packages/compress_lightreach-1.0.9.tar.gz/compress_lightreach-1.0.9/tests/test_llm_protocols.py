"""
Ensure provider clients conform to streaming capability protocols.

These tests are cheap and catch regressions where we accidentally change a
method name/signature and the /complete streaming dispatch silently breaks.
"""

from api.llm.anthropic_client import AnthropicClient
from api.llm.google_client import GoogleGeminiClient
from api.llm.openai_client import OpenAIClient
from api.llm.protocols import (
    SupportsAnthropicMessagesStream,
    SupportsGeminiStream,
    SupportsOpenAIChatCompletionsStream,
)


def test_openai_client_supports_openai_stream_protocol():
    assert isinstance(OpenAIClient(), SupportsOpenAIChatCompletionsStream)


def test_anthropic_client_supports_messages_stream_protocol():
    assert isinstance(AnthropicClient(), SupportsAnthropicMessagesStream)


def test_gemini_client_supports_gemini_stream_protocol():
    assert isinstance(GoogleGeminiClient(), SupportsGeminiStream)

