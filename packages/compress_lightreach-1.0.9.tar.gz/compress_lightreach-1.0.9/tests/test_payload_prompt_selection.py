from api.services.complete.payload import _use_full_cursor_enhanced_prompt


def test_cursor_uses_full_enhanced_prompt_for_google():
    assert _use_full_cursor_enhanced_prompt("google") is True
    assert _use_full_cursor_enhanced_prompt("gemini") is True


def test_cursor_uses_reduced_enhanced_prompt_for_openai_family():
    assert _use_full_cursor_enhanced_prompt("openai") is False
    assert _use_full_cursor_enhanced_prompt("anthropic") is False
    assert _use_full_cursor_enhanced_prompt("xai") is False
