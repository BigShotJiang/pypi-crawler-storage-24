from api.services.complete.quality import (
    merge_stream_tool_call_delta,
    normalize_stream_text_delta,
)


def test_normalize_stream_text_delta_strips_cumulative_prefix():
    assert (
        normalize_stream_text_delta(
            "I'll explore this codebase to understand what it does.",
            "I'll explore this codebase",
        )
        == " to understand what it does."
    )


def test_normalize_stream_text_delta_skips_trimmed_duplicate():
    assert normalize_stream_text_delta("Next I will inspect the router.  ", "Next I will inspect the router.") == ""


def test_merge_stream_tool_call_delta_accumulates_partial_arguments():
    acc = {}
    merge_stream_tool_call_delta(
        acc,
        [
            {
                "index": 0,
                "id": "call_1",
                "type": "function",
                "function": {"name": "ReadFile", "arguments": '{"path":"src/'},
            }
        ],
    )
    merge_stream_tool_call_delta(
        acc,
        [
            {
                "index": 0,
                "function": {"arguments": 'app.ts"}'},
            }
        ],
    )

    assert acc[0]["id"] == "call_1"
    assert acc[0]["function"]["name"] == "ReadFile"
    assert acc[0]["function"]["arguments"] == '{"path":"src/app.ts"}'
