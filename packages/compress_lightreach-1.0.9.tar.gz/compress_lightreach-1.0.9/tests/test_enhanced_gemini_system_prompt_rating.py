from api.services.enhanced_gemini_system import EnhancedLLMSystem, EnhancedGeminiSystem


def test_enhanced_prompt_includes_rating_instruction():
    p = EnhancedLLMSystem.build_enhanced_system_prompt(tools_enabled=True)
    assert "If the user asks for a rating" in p


def test_backward_compat_alias():
    """EnhancedGeminiSystem is an alias for EnhancedLLMSystem."""
    assert EnhancedGeminiSystem is EnhancedLLMSystem

