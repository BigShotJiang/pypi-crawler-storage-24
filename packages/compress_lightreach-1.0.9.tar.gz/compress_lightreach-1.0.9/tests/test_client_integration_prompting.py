from api.models import CompleteRequest
from api.services.complete.message_preparation import _effective_compression_config
from api.services.complete.payload import _build_integration_enhanced_prompt


def test_claude_default_compression_preserves_system_prompt():
    cfg = _effective_compression_config(
        complete_request=CompleteRequest(messages=[{"role": "user", "content": "hi"}]),
        system_integration="claude",
        llm_provider="anthropic",
    )

    assert cfg.compress_system is False
    assert cfg.compress_user is True
    assert cfg.compress_assistant is False
    assert cfg.compress_only_last_n_user is None


def test_cursor_default_compression_is_unchanged():
    cfg = _effective_compression_config(
        complete_request=CompleteRequest(messages=[{"role": "user", "content": "hi"}]),
        system_integration="cursor",
        llm_provider="anthropic",
    )

    assert cfg.compress_system is True
    assert cfg.compress_user is True
    assert cfg.compress_assistant is False
    assert cfg.compress_only_last_n_user is None


def test_claude_skips_extra_enhanced_prompt_layer():
    assert _build_integration_enhanced_prompt(system_integration="claude", is_gemini=False) == ""


def test_cursor_keeps_progress_narration_prompt():
    prompt = _build_integration_enhanced_prompt(system_integration="cursor", is_gemini=False)
    assert "LIVE PROGRESS NARRATION" in prompt
