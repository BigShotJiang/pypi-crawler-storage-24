from api.models import CompleteRequest
from api.services.complete.agentic_controller_v2 import maybe_enforce_investigation_protocol
from api.services.complete.proof_policy import (
    is_gemini_provider,
    ledger_info_from_tool_results,
    should_enforce_proof,
)


def _m(role: str, content: str) -> CompleteRequest.Message:
    return CompleteRequest.Message(role=role, content=content)


def test_should_enforce_proof_cursor_gemini_disabled_without_server_tools():
    assert is_gemini_provider("google") is True
    assert is_gemini_provider("gemini") is True
    assert (
        should_enforce_proof(
            llm_provider="google",
            system_integration="cursor",
            enable_tools_execution=False,
        )
        is False
    )


def test_should_enforce_proof_claude_disabled_without_server_tools():
    assert (
        should_enforce_proof(
            llm_provider="anthropic",
            system_integration="claude",
            enable_tools_execution=False,
        )
        is False
    )


def test_should_enforce_proof_cursor_non_gemini_disabled_without_server_tools():
    assert (
        should_enforce_proof(
            llm_provider="openai",
            system_integration="cursor",
            enable_tools_execution=False,
        )
        is False
    )


def test_should_enforce_proof_server_tools_always_enabled():
    assert (
        should_enforce_proof(
            llm_provider="google",
            system_integration="cursor",
            enable_tools_execution=True,
        )
        is True
    )
    assert (
        should_enforce_proof(
            llm_provider="google",
            system_integration=None,
            enable_tools_execution=True,
        )
        is True
    )


def test_ledger_info_from_tool_results_extracts_ids_and_map():
    tool_results = [
        {"ledger_id": "led_aaa", "tool_name": "Read"},
        {"ledger_id": "led_bbb", "tool_name": "Grep"},
        {"ledger_id": "", "tool_name": "Read"},
        "not-a-dict",
    ]
    ids, mp = ledger_info_from_tool_results(tool_results)
    assert ids == ["led_aaa", "led_bbb"]
    assert mp == {"led_aaa": "Read", "led_bbb": "Grep"}


def test_maybe_enforce_investigation_protocol_gates_off_when_tools_disabled():
    msgs = [_m("user", "hi")]
    res = maybe_enforce_investigation_protocol(
        msgs,
        enable_tools=False,
        system_integration="cursor",
        is_simple=False,
        require_hypothesis=False,
    )
    assert res.get("messages") == msgs
    assert res.get("reason") == "tools_disabled"


def test_maybe_enforce_investigation_protocol_idempotent_when_marker_present():
    msgs = [
        _m("user", "hi"),
        _m("system", "INVESTIGATION_GUIDANCE:\n- Current evidence gaps: ..."),
    ]
    res = maybe_enforce_investigation_protocol(
        msgs,
        enable_tools=True,
        system_integration="cursor",
        is_simple=False,
        require_hypothesis=False,
    )
    assert res.get("messages") == msgs
    assert res.get("reason") == "already_enforced"

