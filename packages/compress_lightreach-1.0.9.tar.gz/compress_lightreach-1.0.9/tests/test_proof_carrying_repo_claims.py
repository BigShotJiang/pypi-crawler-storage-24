from api.services.proof_carrying_validator import validate_assistant_proof


def _ctx_manifest():
    # 12 hex chars is accepted by the validator (8-64).
    return {"aaaaaaaaaaaa": "a" * 64}


def test_repo_path_requires_citation() -> None:
    res = validate_assistant_proof(
        assistant_text="Key Components: api/routes/*: API endpoint definitions.",
        context_text="",
        context_manifest=_ctx_manifest(),
        valid_ledger_ids=[],
        ledger_tool_names={},
        ide_context_paths=set(),
    )
    assert res.ok is False
    assert "repo-path" in res.reason.lower() or "repo-path reference" in res.reason.lower()


def test_repo_path_allows_context_citation() -> None:
    res = validate_assistant_proof(
        assistant_text="Key Components: api/routes/*: API endpoint definitions. [context:aaaaaaaaaaaa]",
        context_text="",
        context_manifest=_ctx_manifest(),
        valid_ledger_ids=[],
        ledger_tool_names={},
        ide_context_paths=set(),
    )
    assert res.ok is True


def test_stack_assertion_requires_citation() -> None:
    res = validate_assistant_proof(
        assistant_text="The backend is built using FastAPI.",
        context_text="",
        context_manifest=_ctx_manifest(),
        valid_ledger_ids=[],
        ledger_tool_names={},
        ide_context_paths=set(),
    )
    assert res.ok is False
    assert "tech-stack" in res.reason.lower() or "integration" in res.reason.lower()


def test_stack_assertion_allows_context_citation() -> None:
    res = validate_assistant_proof(
        assistant_text="The backend is built using FastAPI. [context:aaaaaaaaaaaa]",
        context_text="",
        context_manifest=_ctx_manifest(),
        valid_ledger_ids=[],
        ledger_tool_names={},
        ide_context_paths=set(),
    )
    assert res.ok is True


def test_repo_path_advisory_exempt() -> None:
    res = validate_assistant_proof(
        assistant_text="Look at backend/api/routes/ to see what endpoints exist.",
        context_text="",
        context_manifest=_ctx_manifest(),
        valid_ledger_ids=[],
        ledger_tool_names={},
        ide_context_paths=set(),
    )
    assert res.ok is True


def test_toplevel_dir_token_requires_citation() -> None:
    res = validate_assistant_proof(
        assistant_text="services/: This directory includes various background services.",
        context_text="",
        context_manifest=_ctx_manifest(),
        valid_ledger_ids=[],
        ledger_tool_names={},
        ide_context_paths=set(),
    )
    assert res.ok is False
    assert "directory reference" in res.reason.lower()


def test_toplevel_dir_token_allows_context_citation() -> None:
    res = validate_assistant_proof(
        assistant_text="services/: This directory includes various background services. [context:aaaaaaaaaaaa]",
        context_text="",
        context_manifest=_ctx_manifest(),
        valid_ledger_ids=[],
        ledger_tool_names={},
        ide_context_paths=set(),
    )
    assert res.ok is True

