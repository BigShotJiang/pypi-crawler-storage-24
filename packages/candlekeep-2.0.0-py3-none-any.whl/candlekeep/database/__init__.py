"""Database layer for candlekeep."""
