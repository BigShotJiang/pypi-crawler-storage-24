#!/usr/bin/env python3
"""Preflight check for abi-runtime."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

REQUIRED_FILES = [
    "README.md",
    "SECURITY.md",
    "pyproject.toml",
    "src/abi_runtime/__init__.py",
    "src/abi_runtime/sandbox.py",
    "src/abi_runtime/providers.py",
    "src/abi_runtime/context.py",
    "src/abi_runtime/commands.py",
    "src/abi_runtime/cli.py",
]


def check_files() -> list[str]:
    return [f for f in REQUIRED_FILES if not (REPO_ROOT / f).exists()]


def run_lint() -> int:
    print("=== Running ruff ===")
    return subprocess.run(
        [sys.executable, "-m", "ruff", "check", "src/", "tests/"],
        cwd=REPO_ROOT,
    ).returncode


def run_tests() -> int:
    print("=== Running pytest ===")
    return subprocess.run(
        [sys.executable, "-m", "pytest", "tests/", "-v", "--tb=short"],
        cwd=REPO_ROOT,
    ).returncode


def main() -> int:
    print("abi-runtime preflight check")
    print("=" * 40)

    print("\n--- File presence ---")
    missing = check_files()
    for f in missing:
        print(f"  FAIL: Missing {f}")
    if not missing:
        print("  OK: All required files present")

    print()
    lint_rc = run_lint()
    print()
    test_rc = run_tests()

    if missing or lint_rc != 0 or test_rc != 0:
        print("\n PREFLIGHT FAILED")
        return 1
    print("\n PREFLIGHT PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
