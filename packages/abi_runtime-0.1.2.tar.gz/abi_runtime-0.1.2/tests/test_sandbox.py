"""Tests for workspace sandbox."""
import pytest

from abi_runtime.sandbox import SandboxViolation, WorkspaceSandbox


class TestSandboxPathResolution:
    def test_resolve_relative(self, sandbox, workspace):
        path = sandbox.resolve_path("src/main.py")
        assert path == (workspace / "src" / "main.py").resolve()

    def test_block_path_traversal(self, sandbox):
        with pytest.raises(SandboxViolation, match="traversal"):
            sandbox.resolve_path("../../../etc/passwd")

    def test_block_absolute_path(self, sandbox):
        with pytest.raises(SandboxViolation, match="Absolute"):
            sandbox.resolve_path("/etc/passwd")

    def test_block_windows_absolute(self, sandbox):
        with pytest.raises(SandboxViolation, match="Absolute"):
            sandbox.resolve_path("C:\\Windows\\System32")

    def test_block_double_dot_in_middle(self, sandbox):
        with pytest.raises(SandboxViolation, match="traversal"):
            sandbox.resolve_path("src/../../../etc/passwd")

    def test_symlink_within_workspace(self, workspace, sandbox):
        """Symlinks that stay within workspace are OK."""
        target = workspace / "src" / "main.py"
        link = workspace / "link.py"
        try:
            link.symlink_to(target)
        except OSError:
            pytest.skip("Cannot create symlinks on this platform")
        # Should resolve without error
        path = sandbox.resolve_path("link.py")
        assert path.exists()

    def test_symlink_escape_blocked(self, workspace, sandbox, tmp_path):
        """Symlinks that escape workspace are blocked."""
        external = tmp_path / "external.txt"
        external.write_text("secret")
        link = workspace / "escape_link.txt"
        try:
            link.symlink_to(external)
        except OSError:
            pytest.skip("Cannot create symlinks on this platform")
        with pytest.raises(SandboxViolation, match="Path escapes workspace root"):
            sandbox.resolve_path("escape_link.txt")


class TestSandboxAllowlist:
    def test_default_allows_all(self, sandbox):
        assert sandbox.check_allowlist("src/main.py") is True

    def test_denies_env_files(self, sandbox):
        assert sandbox.check_allowlist(".env") is False
        assert sandbox.check_allowlist("config/.env.local") is False

    def test_denies_secrets(self, sandbox):
        assert sandbox.check_allowlist("secrets.json") is False

    def test_denies_git_dir(self, sandbox):
        assert sandbox.check_allowlist(".git/config") is False

    def test_custom_allowlist(self, workspace):
        sandbox = WorkspaceSandbox(workspace, allow_patterns=["*.py"])
        assert sandbox.check_allowlist("main.py") is True
        assert sandbox.check_allowlist("main.js") is False


class TestSandboxFileOps:
    def test_safe_read(self, sandbox):
        content = sandbox.safe_read("src/main.py")
        assert "hello" in content

    def test_safe_write(self, sandbox, workspace):
        sandbox.safe_write("output.txt", "test content")
        assert (workspace / "output.txt").read_text() == "test content"

    def test_safe_write_creates_dirs(self, sandbox, workspace):
        sandbox.safe_write("new/nested/file.txt", "content")
        assert (workspace / "new" / "nested" / "file.txt").exists()

    def test_safe_list(self, sandbox):
        items = sandbox.safe_list("src")
        assert any("main.py" in item for item in items)


class TestTempDir:
    def test_deterministic_for_fixed_run_id(self, sandbox):
        d1 = sandbox.temp_dir("run-00000001")
        d2 = sandbox.temp_dir("run-00000001")
        assert d1 == d2

    def test_different_for_different_run_id(self, sandbox):
        d1 = sandbox.temp_dir("run-00000001")
        d2 = sandbox.temp_dir("run-00000002")
        assert d1 != d2
