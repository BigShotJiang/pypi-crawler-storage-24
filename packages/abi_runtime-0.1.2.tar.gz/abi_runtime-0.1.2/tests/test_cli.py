"""Tests for CLI interface."""
from abi_runtime.cli import main


class TestCLI:
    def test_doctor(self, capsys):
        rc = main(["doctor"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "Python" in out

    def test_demo_sandbox(self, tmp_path, capsys):
        ws = tmp_path / "demo_ws"
        ws.mkdir()
        rc = main(["demo-sandbox", "--workspace", str(ws)])
        assert rc == 0
        out = capsys.readouterr().out
        assert "ALLOWED" in out
        assert "BLOCKED" in out
