"""Phase 2 — Evidence deepening for abi-runtime.

Verifies:
- Execution boundary contracts (no upward dependency violations)
- Runtime context captures complete metadata
- Sandbox enforces boundary contracts
"""

from __future__ import annotations

import sys

import pytest

from abi_runtime.commands import CommandExecutor, DockerExecutor
from abi_runtime.context import capture_context
from abi_runtime.sandbox import SandboxViolation, WorkspaceSandbox


class TestRuntimeContextCompleteness:
    """Runtime context includes all required metadata."""

    def test_context_has_schema_version(self):
        ctx = capture_context()
        assert ctx["schema_version"] == "tier2-runtime-context/1.0"

    def test_context_has_python_version(self):
        ctx = capture_context()
        expected = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        assert ctx["python_version"] == expected

    def test_context_has_platform(self):
        ctx = capture_context()
        assert "platform" in ctx
        assert isinstance(ctx["platform"], str)
        assert len(ctx["platform"]) > 0

    def test_context_dependencies_sorted(self):
        ctx = capture_context()
        deps = ctx["dependencies"]
        names = [d["name"] for d in deps]
        assert names == sorted(names, key=str.lower)

    def test_context_workspace_always_redacted(self):
        ctx = capture_context(workspace_root=None)
        assert ctx["workspace_path"] == "<WORKSPACE>"


class TestExecutionBoundaryContracts:
    """Runtime enforces execution boundaries."""

    def test_command_executor_stubbed_by_default(self):
        """Default executor does NOT execute real commands."""
        exe = CommandExecutor()
        result = exe.execute("dangerous-command --force")
        assert result.stubbed is True
        assert result.exit_code == 0

    def test_docker_executor_stubbed(self):
        """Docker executor never runs real containers by default."""
        docker = DockerExecutor()
        result = docker.run("malicious-image", "rm -rf /")
        assert result.stubbed is True

    def test_sandbox_blocks_upward_escape(self, workspace):
        """Sandbox prevents accessing files outside workspace root."""
        sandbox = WorkspaceSandbox(workspace)
        with pytest.raises(SandboxViolation):
            sandbox.resolve_path("../../etc/passwd")

    def test_sandbox_blocks_absolute_paths(self, workspace):
        sandbox = WorkspaceSandbox(workspace)
        with pytest.raises(SandboxViolation):
            sandbox.resolve_path("/etc/shadow")

    def test_sandbox_blocks_env_files(self, workspace):
        sandbox = WorkspaceSandbox(workspace)
        assert sandbox.check_allowlist(".env") is False
        assert sandbox.check_allowlist("secrets.json") is False


class TestNoUpwardDependencyViolations:
    """abi-runtime must NOT import from orchestrator, policy, evals, or observability."""

    def test_no_orchestrator_import(self):
        """Verify abi_runtime does not import from abi_orchestrator."""
        # Check that none of the forbidden modules are loaded
        forbidden = ["abi_orchestrator", "abi_policy", "abi_evals", "abi_observability"]
        for mod_name, mod in sys.modules.items():
            if mod_name.startswith("abi_runtime"):
                source = getattr(mod, "__file__", "") or ""
                for f in forbidden:
                    assert f not in source, f"abi_runtime imports from {f}"
