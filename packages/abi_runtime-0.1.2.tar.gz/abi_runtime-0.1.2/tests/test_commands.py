"""Tests for command execution."""
from abi_runtime.commands import CommandExecutor, DockerExecutor


class TestCommandExecutor:
    def test_stubbed_by_default(self):
        exe = CommandExecutor()
        result = exe.execute("ls -la")
        assert result.stubbed is True
        assert result.exit_code == 0
        assert "STUB" in result.stdout

    def test_records_invocations(self):
        exe = CommandExecutor()
        exe.execute("cmd1")
        exe.execute("cmd2", cwd="/tmp")
        assert len(exe.invocations) == 2
        assert exe.invocations[1]["cwd"] == "/tmp"


class TestDockerExecutor:
    def test_stubbed(self):
        docker = DockerExecutor()
        result = docker.run("python:3.11", "python -c 'print(1)'")
        assert result.stubbed is True
        assert "DOCKER STUB" in result.stdout

    def test_records_invocations(self):
        docker = DockerExecutor()
        docker.run("image1", "cmd1", volumes={"/host": "/container"})
        assert len(docker.invocations) == 1
        assert docker.invocations[0]["image"] == "image1"
