"""Phase 1 — Determinism hardening tests for abi-runtime.

Verifies:
- Runtime context capture produces identical hash for controlled inputs
- Sandbox temp_dir is hash-stable across invocations
- Provider responses are deterministic for same input
- Context JSON serialization is byte-stable
"""

from __future__ import annotations

import hashlib
import json

from abi_runtime.context import capture_context, redact_context, write_context
from abi_runtime.providers import MockProvider
from abi_runtime.sandbox import WorkspaceSandbox


def _sha256(data: str | bytes) -> str:
    if isinstance(data, str):
        data = data.encode()
    return hashlib.sha256(data).hexdigest()


class TestContextHashStability:
    """Runtime context capture is hash-stable for controlled inputs."""

    def test_context_json_hash_stable(self, tmp_path):
        ctx1 = capture_context(workspace_root=tmp_path, repo_version="1.0.0")
        ctx2 = capture_context(workspace_root=tmp_path, repo_version="1.0.0")
        j1 = json.dumps(ctx1, sort_keys=True)
        j2 = json.dumps(ctx2, sort_keys=True)
        assert _sha256(j1) == _sha256(j2)

    def test_write_context_byte_stable(self, tmp_path):
        ctx = capture_context(workspace_root=tmp_path, repo_version="1.0.0")
        p1 = tmp_path / "c1.json"
        p2 = tmp_path / "c2.json"
        write_context(ctx, p1)
        write_context(ctx, p2)
        assert p1.read_bytes() == p2.read_bytes()

    def test_redaction_stable(self, tmp_path):
        ctx = capture_context(workspace_root=tmp_path, repo_version="1.0.0")
        r1 = redact_context(ctx, workspace_root=str(tmp_path))
        r2 = redact_context(ctx, workspace_root=str(tmp_path))
        assert json.dumps(r1, sort_keys=True) == json.dumps(r2, sort_keys=True)


class TestSandboxDeterminism:
    """Sandbox operations are deterministic."""

    def test_temp_dir_hash_stable(self, workspace):
        sandbox = WorkspaceSandbox(workspace)
        d1 = sandbox.temp_dir("run-fixed-001")
        d2 = sandbox.temp_dir("run-fixed-001")
        assert d1 == d2
        # Verify it's SHA-256 based
        expected_hash = hashlib.sha256(b"run-fixed-001").hexdigest()[:12]
        assert expected_hash in str(d1)

    def test_safe_list_sorted(self, sandbox):
        items = sandbox.safe_list(".")
        assert items == sorted(items)

    def test_path_resolution_cross_platform(self, sandbox, workspace):
        """Forward and backslash paths resolve identically."""
        p1 = sandbox.resolve_path("src/main.py")
        # On any platform, the resolved path should be the same absolute path
        assert p1 == (workspace / "src" / "main.py").resolve()


class TestProviderDeterminism:
    """Mock providers are deterministic."""

    def test_mock_provider_hash_stable(self):
        p = MockProvider(default_response="Deterministic response")
        responses = []
        for _ in range(10):
            r = p.generate("test prompt")
            responses.append(r.text)
        assert all(r == responses[0] for r in responses)

    def test_mock_provider_usage_stable(self):
        p = MockProvider(default_response="response")
        usages = []
        for _ in range(10):
            r = p.generate("fixed prompt")
            usages.append(r.usage)
        assert all(u == usages[0] for u in usages)

    def test_pattern_match_deterministic(self):
        p = MockProvider()
        p.set_response("Discover", "Found it!")
        p.set_response("Analyze", "Analyzed!")
        results = []
        for _ in range(10):
            r = p.generate("Please Discover the code")
            results.append(r.text)
        assert all(r == results[0] for r in results)
