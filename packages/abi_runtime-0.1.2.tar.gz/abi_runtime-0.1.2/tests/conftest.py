"""Shared fixtures for abi-runtime tests."""
from pathlib import Path

import pytest

from abi_runtime.sandbox import WorkspaceSandbox


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    """Create a temporary workspace directory."""
    ws = tmp_path / "workspace"
    ws.mkdir()
    (ws / "src").mkdir()
    (ws / "src" / "main.py").write_text("print('hello')")
    (ws / "docs").mkdir()
    (ws / "docs" / "readme.md").write_text("# README")
    return ws


@pytest.fixture
def sandbox(workspace: Path) -> WorkspaceSandbox:
    """Create a sandbox rooted at the temp workspace."""
    return WorkspaceSandbox(workspace)
