"""Tests for runtime context capture."""
from pathlib import Path

from abi_runtime.context import capture_context, redact_context, redact_value, write_context


class TestContextCapture:
    def test_basic_capture(self):
        ctx = capture_context()
        assert "python_version" in ctx
        assert "platform" in ctx
        assert "architecture" in ctx
        assert ctx["workspace_path"] == "<WORKSPACE>"

    def test_workspace_always_redacted(self):
        ctx = capture_context(workspace_root=Path("/secret/path"))
        assert ctx["workspace_path"] == "<WORKSPACE>"

    def test_repo_version(self):
        ctx = capture_context(repo_version="1.2.3")
        assert ctx["repo_version"] == "1.2.3"

    def test_dependencies_sorted(self):
        ctx = capture_context()
        deps = ctx["dependencies"]
        names = [d["name"] for d in deps]
        assert names == sorted(names, key=str.lower)


class TestRedaction:
    def test_redact_api_key(self):
        assert redact_value("sk-12345", "API_KEY") == "<REDACTED>"

    def test_redact_secret(self):
        assert redact_value("mypassword", "SECRET_TOKEN") == "<REDACTED>"

    def test_no_redaction_for_safe_key(self):
        assert redact_value("hello", "greeting") == "hello"

    def test_redact_workspace_paths(self):
        ctx = {"path": "/home/user/workspace/file.txt", "name": "test"}
        redacted = redact_context(ctx, workspace_root="/home/user/workspace")
        assert "<WORKSPACE>" in redacted["path"]
        assert "/home/user/workspace" not in redacted["path"]

    def test_nested_redaction(self):
        ctx = {"outer": {"GITHUB_TOKEN_value": "secret123"}}
        redacted = redact_context(ctx)
        assert redacted["outer"]["GITHUB_TOKEN_value"] == "<REDACTED>"


class TestWriteContext:
    def test_write_json(self, tmp_path):
        ctx = capture_context()
        path = tmp_path / "context.json"
        write_context(ctx, path)
        assert path.exists()
        import json
        data = json.loads(path.read_text())
        assert "python_version" in data
