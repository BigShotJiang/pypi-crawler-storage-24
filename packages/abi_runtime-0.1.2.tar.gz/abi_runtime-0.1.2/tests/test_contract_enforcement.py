"""Phase 3 — Contract enforcement tightening for abi-runtime.

Validates runtime context output against expected tier2 schema structure.
"""

from __future__ import annotations

import json

from abi_runtime.context import capture_context, redact_context, write_context


class TestTier2RuntimeContextCompliance:
    """Runtime context matches tier2-runtime-context/1.0 structure."""

    def test_has_schema_version(self):
        ctx = capture_context()
        assert ctx["schema_version"] == "tier2-runtime-context/1.0"

    def test_required_fields_present(self):
        ctx = capture_context()
        required = {
            "schema_version",
            "python_version",
            "platform",
            "platform_version",
            "architecture",
            "repo_version",
            "workspace_path",
            "dependencies",
        }
        assert required.issubset(ctx.keys()), f"Missing: {required - ctx.keys()}"

    def test_dependencies_structure(self):
        ctx = capture_context()
        deps = ctx["dependencies"]
        assert isinstance(deps, list)
        for dep in deps:
            assert "name" in dep
            assert "version" in dep
            assert isinstance(dep["name"], str)
            assert isinstance(dep["version"], str)

    def test_json_serialization_valid(self, tmp_path):
        ctx = capture_context(repo_version="0.1.1")
        path = tmp_path / "ctx.json"
        write_context(ctx, path)
        loaded = json.loads(path.read_text())
        assert loaded["schema_version"] == "tier2-runtime-context/1.0"
        assert loaded["repo_version"] == "0.1.1"

    def test_redacted_context_no_secrets(self):
        ctx = {"GITHUB_TOKEN_val": "secret123", "safe_key": "visible"}
        redacted = redact_context(ctx)
        assert redacted["GITHUB_TOKEN_val"] == "<REDACTED>"
        assert redacted["safe_key"] == "visible"
