"""Tests for model provider abstraction."""
from abi_runtime.providers import LocalProviderStub, MockProvider


class TestMockProvider:
    def test_default_response(self):
        p = MockProvider(default_response="Hello!")
        resp = p.generate("any prompt")
        assert resp.text == "Hello!"
        assert resp.model == "mock"

    def test_pattern_match(self):
        p = MockProvider()
        p.set_response("Discover", "Found it!")
        resp = p.generate("Please Discover the code")
        assert resp.text == "Found it!"

    def test_records_invocations(self):
        p = MockProvider()
        p.generate("prompt 1")
        p.generate("prompt 2")
        assert len(p.invocations) == 2
        assert p.invocations[0]["prompt"] == "prompt 1"

    def test_deterministic_for_same_input(self):
        p = MockProvider(default_response="Deterministic")
        r1 = p.generate("same prompt")
        r2 = p.generate("same prompt")
        assert r1.text == r2.text
        assert r1.usage == r2.usage

    def test_name(self):
        assert MockProvider().name == "mock"

    def test_usage_token_counts(self):
        p = MockProvider(default_response="resp")
        resp = p.generate("test")
        assert resp.usage["input_tokens"] == len("test")
        assert resp.usage["output_tokens"] == len("resp")


class TestLocalProviderStub:
    def test_stub_response(self):
        p = LocalProviderStub()
        resp = p.generate("any prompt")
        assert "stub" in resp.text.lower() or resp.metadata.get("stub") is True

    def test_name(self):
        assert LocalProviderStub().name == "local-stub"
