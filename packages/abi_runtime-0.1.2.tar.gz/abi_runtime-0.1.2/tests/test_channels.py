"""Tests for provider channel abstraction."""

from __future__ import annotations

import pytest

from abi_runtime.channels import (
    ChannelCapacity,
    ChannelType,
    DispatchRequest,
    DispatchResponse,
    StubChannelDispatcher,
    check_capacity,
)


class TestChannelTypeEnum:
    def test_channel_type_enum_values(self):
        assert ChannelType.api.value == "api"
        assert ChannelType.subscription.value == "subscription"
        assert ChannelType.local.value == "local"
        assert len(ChannelType) == 3


class TestStubDispatcher:
    def test_stub_dispatcher_returns_response(self):
        dispatcher = StubChannelDispatcher()
        request = DispatchRequest(model_id="test-model", prompt="Hello")
        response = dispatcher.dispatch(request)
        assert isinstance(response, DispatchResponse)
        assert response.text == "[StubChannelDispatcher] Stub response."
        assert response.model_id == "test-model"
        assert response.metadata.get("stub") is True

    def test_stub_dispatcher_tracks_invocations(self):
        dispatcher = StubChannelDispatcher()
        r1 = DispatchRequest(model_id="m1", prompt="prompt 1")
        r2 = DispatchRequest(model_id="m2", prompt="prompt 2")
        dispatcher.dispatch(r1)
        dispatcher.dispatch(r2)
        assert len(dispatcher.invocations) == 2
        assert dispatcher.invocations[0].prompt == "prompt 1"
        assert dispatcher.invocations[1].model_id == "m2"


class TestCapacityCheck:
    def test_capacity_check_within_limit(self):
        cap = ChannelCapacity(
            channel_type=ChannelType.api,
            concurrency_limit=5,
            active_slots=3,
        )
        assert check_capacity(cap) is True

    def test_capacity_check_at_limit(self):
        cap = ChannelCapacity(
            channel_type=ChannelType.api,
            concurrency_limit=5,
            active_slots=5,
        )
        assert check_capacity(cap) is False


class TestFrozenDataclasses:
    def test_dispatch_request_frozen(self):
        request = DispatchRequest(model_id="m", prompt="p")
        with pytest.raises(AttributeError):
            request.model_id = "other"  # type: ignore[misc]

    def test_dispatch_response_frozen(self):
        response = DispatchResponse(text="t")
        with pytest.raises(AttributeError):
            response.text = "other"  # type: ignore[misc]
