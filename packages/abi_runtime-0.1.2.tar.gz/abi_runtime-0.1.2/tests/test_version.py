"""Test version consistency across package metadata."""
import re
from pathlib import Path

import pytest


def test_version_consistency():
    """Verify that __init__.py version matches pyproject.toml version."""
    # Read version from __init__.py
    init_file = Path(__file__).parent.parent / "src" / "abi_runtime" / "__init__.py"
    init_content = init_file.read_text(encoding="utf-8")
    init_match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', init_content)

    assert init_match is not None, "Could not find __version__ in __init__.py"
    init_version = init_match.group(1)

    # Read version from pyproject.toml
    pyproject_file = Path(__file__).parent.parent / "pyproject.toml"
    pyproject_content = pyproject_file.read_text(encoding="utf-8")
    pyproject_match = re.search(r'^version\s*=\s*["\']([^"\']+)["\']', pyproject_content, re.MULTILINE)

    assert pyproject_match is not None, "Could not find version in pyproject.toml"
    pyproject_version = pyproject_match.group(1)

    # Versions must match
    assert init_version == pyproject_version, (
        f"Version mismatch: __init__.py has '{init_version}' "
        f"but pyproject.toml has '{pyproject_version}'. "
        f"pyproject.toml is the source of truth."
    )


def test_version_format():
    """Verify that version follows semantic versioning format."""
    import abi_runtime

    version = abi_runtime.__version__

    # Check semantic versioning format (major.minor.patch)
    semver_pattern = r'^\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?(?:\+[a-zA-Z0-9.]+)?$'
    assert re.match(semver_pattern, version), (
        f"Version '{version}' does not follow semantic versioning format (major.minor.patch)"
    )
