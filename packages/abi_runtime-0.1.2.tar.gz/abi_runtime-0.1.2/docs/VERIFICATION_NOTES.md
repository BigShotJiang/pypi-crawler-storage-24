# Verification Notes — abi-runtime

## Traceability Markers

### Full node ID: determinism

```
tests/test_sandbox.py::TestTempDir::test_deterministic_for_fixed_run_id
```

Verifies that `sandbox.temp_dir("run-00000001")` returns the same
SHA-256-based path on repeated calls with the same run ID.

### Full node ID: timestamp exclusion

N/A — abi-runtime does not produce hashed payloads with timestamp fields.
The stability node below serves as the second traceability anchor.

### Full node ID: stability

```
tests/test_providers.py::TestMockProvider::test_deterministic_for_same_input
```

Asserts that `MockProvider.generate("same prompt")` returns identical
`.text` and `.usage` on repeated calls, confirming deterministic output.

---

## Tranche History

- **Control Plane Tranche** (base HEAD `e368eac`) — determinism hardening, evidence deepening, contract enforcement

### Control Plane Tranche — Capability Advancement

**Determinism hardening** — 9 tests in `tests/test_determinism_hardening.py`

Full node ID:
```
tests/test_determinism_hardening.py::TestDeterminismHardening::test_context_json_hash_stability
```

**Evidence deepening** — 11 tests in `tests/test_evidence_deepening.py`

Full node ID:
```
tests/test_evidence_deepening.py::TestEvidenceDeepening::test_runtime_context_completeness
```

**Contract enforcement** — 5 tests in `tests/test_contract_enforcement.py`

Full node ID:
```
tests/test_contract_enforcement.py::TestContractEnforcement::test_runtime_context_has_valid_structure
```

25 new tests total. All pass. Context hash stability, sandbox determinism,
provider response determinism. Tier-2 runtime-context schema validation.

### Model Governance & Routing Spec v1.0 — Channel Abstraction Tranche

**Base HEAD**: `e368eac`

New module: `src/abi_runtime/channels.py` — `ChannelType` enum (api/subscription/local), `ChannelCapacity`, `DispatchRequest`/`DispatchResponse` frozen dataclasses, `StubChannelDispatcher`, `check_capacity()`.

7 new tests in `tests/test_channels.py`. 72 passed, 2 skipped total.

Full node ID:
```
tests/test_channels.py::TestChannelAbstraction::test_channel_type_values
```

verify.log: EXIT_CODE=0, Results: 3 passed, 0 failed
