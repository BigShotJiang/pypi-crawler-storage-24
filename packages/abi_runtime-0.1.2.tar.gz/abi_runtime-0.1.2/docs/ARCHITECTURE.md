# Architecture

## High-Level Design
Sandboxed tool runtime and provider abstraction for AbilityBI agent execution.

## Components
- src/abi_runtime/ — runtime engine and provider adapters
- tests/ — runtime sandbox and provider tests

## Interfaces
Inputs: Structured data, policy definitions, or API requests depending on module.
Outputs: Processed results, evidence packs, or structured reports.
