# Schema Proposal: runtime-context/1.0

## Rationale

Runtime context metadata is needed to reproduce and audit ABI runs.
Currently using internal format; proposing standardization in abi-core.

## Proposed Schema

```json
{
  "schema_version": "runtime-context/1.0",
  "python_version": "string",
  "platform": "string",
  "platform_version": "string",
  "architecture": "string",
  "repo_version": "string",
  "workspace_path": "<WORKSPACE>",
  "dependencies": [{"name": "string", "version": "string"}]
}
```

## Redaction Rules

- workspace_path: Always "<WORKSPACE>"
- Any key matching SECRET_ENV_PREFIXES: "<REDACTED>"
- Dependency list: Safe (package names and versions only)
