# Roadmap

## Near Term
- Docker sandbox integration
- Provider health monitoring

## Later
- Distributed runtime across multiple hosts
