# abi-runtime Interfaces

## Sandbox API

| Method | Input | Output | Safety |
|--------|-------|--------|--------|
| `resolve_path(rel)` | Relative path | Absolute path within workspace | Blocks traversal, absolute, symlink escape |
| `check_allowlist(rel)` | Relative path | bool | Checks allow/deny patterns |
| `safe_read(rel)` | Relative path | File content (str) | Allowlist + path safety |
| `safe_write(rel, content)` | Path + content | Written path | Allowlist + path safety |
| `safe_list(rel_dir)` | Relative dir | Sorted file list | Path safety |
| `temp_dir(run_id)` | Run ID | Deterministic temp path | Within workspace |

## Provider API

| Method | Input | Output |
|--------|-------|--------|
| `generate(prompt, settings)` | Prompt + ProviderSettings | ProviderResponse |

## Runtime Context

```json
{
  "schema_version": "runtime-context/internal",
  "python_version": "3.11.x",
  "platform": "Linux|Windows|Darwin",
  "architecture": "x86_64|arm64",
  "repo_version": "0.1.0",
  "workspace_path": "<WORKSPACE>",
  "dependencies": [{"name": "...", "version": "..."}]
}
```

## CLI Commands

| Command | Description |
|---------|-------------|
| `doctor` | Print runtime readiness |
| `demo-sandbox --workspace <dir>` | Demonstrate sandbox allow/deny |
