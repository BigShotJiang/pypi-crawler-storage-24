# Overview

## Purpose
Provides the sandboxed execution layer for AbilityBI agent tools with policy-enforced resource limits.

## Primary Users
- AbilityBI engineering and AI pipeline operators

## Scope
- What it covers: Sandboxed tool runtime and provider abstraction for AbilityBI agent execution.
- What it does not cover: External distribution or unsanctioned integrations
