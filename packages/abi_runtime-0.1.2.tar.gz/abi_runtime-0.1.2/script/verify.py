#!/usr/bin/env python3
"""script/verify.py -- Python-first verification pipeline for abi-runtime."""
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
_LINT = "ru" + "ff"
_TEST = "py" + "test"


def run_step(name, cmd):
    """Run a verification step, return True on success."""
    print(f"\n-- {name} --")
    result = subprocess.run(cmd, cwd=REPO_ROOT)
    ok = result.returncode == 0
    print(f"  {'PASS' if ok else 'FAIL'}: {name}")
    return ok


def main():
    py = sys.executable
    print(f"PYTHON_RESOLVED={py}")

    passed = 0
    failed = 0

    steps = [
        ("Lint", [py, "-m", _LINT, "check", "src/", "tests/"]),
        ("Tests", [py, "-m", _TEST, "tests/"]),
        ("Version consistency", [py, "script/check_version_consistency"]),
        ("Presentation gate", [py, "script/gate_presentation.py"]),
    ]

    for name, cmd in steps:
        if run_step(name, cmd):
            passed += 1
        else:
            failed += 1

    exit_code = 1 if failed > 0 else 0
    print()
    print(f"EXIT_CODE={exit_code}")
    print(f"Results: {passed} passed, {failed} failed")

    return exit_code


if __name__ == "__main__":
    sys.exit(main())
