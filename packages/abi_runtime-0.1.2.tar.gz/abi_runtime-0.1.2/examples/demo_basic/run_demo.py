#!/usr/bin/env python3
"""Basic demo of abi-runtime sandbox and providers."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "src"))

from abi_runtime.commands import CommandExecutor
from abi_runtime.context import capture_context
from abi_runtime.providers import MockProvider
from abi_runtime.sandbox import SandboxViolation, WorkspaceSandbox


def main() -> None:
    print("=== abi-runtime Basic Demo ===\n")

    with tempfile.TemporaryDirectory() as tmp:
        workspace = Path(tmp) / "demo_workspace"
        workspace.mkdir()

        # Sandbox demo
        sandbox = WorkspaceSandbox(workspace)

        print("--- Sandbox Operations ---")
        sandbox.safe_write("output/hello.txt", "Hello from sandbox!")
        content = sandbox.safe_read("output/hello.txt")
        print(f"  Write + Read: '{content}'")

        # Path traversal blocked
        try:
            sandbox.resolve_path("../../etc/passwd")
        except SandboxViolation as e:
            print(f"  Path traversal blocked: {e}")

        # Provider demo
        print("\n--- Provider Demo ---")
        provider = MockProvider(default_response="Mock says hello!")
        provider.set_response("analyze", "Analysis complete: all good")

        r1 = provider.generate("Say something")
        print(f"  Default: {r1.text}")

        r2 = provider.generate("Please analyze this code")
        print(f"  Pattern match: {r2.text}")

        # Command executor demo
        print("\n--- Command Executor ---")
        exe = CommandExecutor()
        result = exe.execute("pytest tests/ -v")
        print(f"  Stubbed: {result.stdout}")

        # Context capture
        print("\n--- Runtime Context ---")
        ctx = capture_context(repo_version="0.1.0")
        print(f"  Python: {ctx['python_version']}")
        print(f"  Platform: {ctx['platform']}")
        print(f"  Workspace: {ctx['workspace_path']}")

    print("\nDemo complete.")


if __name__ == "__main__":
    main()
