#!/usr/bin/env python3
"""Cross-repo integration demo for abi-runtime.

Simulates a mock orchestration step:
1. Creates a synthetic PlanGraph
2. Sets up a sandboxed workspace
3. Executes mock tool calls via sandbox + provider
4. Emits policy decisions and observability events (compatible formats)
5. Captures runtime context
6. Outputs a small evidence-pack-like folder

Runs entirely offline. Does not require other abi-* repos to be installed.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "src"))

from abi_runtime.context import capture_context, redact_context, write_context
from abi_runtime.providers import MockProvider
from abi_runtime.sandbox import WorkspaceSandbox

FIXED_TS = "2025-01-01T00:00:00Z"
RUN_ID = "e2e00001"


def make_synthetic_plan_graph() -> dict:
    """Create a small synthetic PlanGraph (plan-graph/1.0 compatible)."""
    return {
        "schema_version": "plan-graph/1.0",
        "run_id": RUN_ID,
        "description": "Demo plan graph for runtime execution",
        "nodes": [
            {
                "node_id": "step-1",
                "name": "Read input file",
                "depends_on": [],
                "status": "pending",
                "agent": "builder",
                "metadata": {"node_type": "TOOL_CALL", "tool": "read_file"},
            },
            {
                "node_id": "step-2",
                "name": "Analyze with model",
                "depends_on": ["step-1"],
                "status": "pending",
                "agent": "builder",
                "metadata": {"node_type": "AGENT_TASK", "model": "claude-sonnet"},
            },
            {
                "node_id": "step-3",
                "name": "Write output file",
                "depends_on": ["step-2"],
                "status": "pending",
                "agent": "builder",
                "metadata": {"node_type": "TOOL_CALL", "tool": "write_file"},
            },
            {
                "node_id": "step-4",
                "name": "Verify results",
                "depends_on": ["step-3"],
                "status": "pending",
                "agent": "validator",
                "metadata": {"node_type": "GATE_CHECK"},
            },
        ],
    }


def main() -> None:
    print("=== abi-runtime Cross-Repo Integration Demo ===\n")

    with tempfile.TemporaryDirectory() as tmp:
        workspace_root = Path(tmp) / "demo_workspace"
        workspace_root.mkdir()

        # 1. Create PlanGraph
        print("--- Step 1: Create PlanGraph ---")
        plan_graph = make_synthetic_plan_graph()
        print(f"  Nodes: {len(plan_graph['nodes'])}")

        # 2. Set up sandbox
        print("\n--- Step 2: Set Up Sandbox ---")
        sandbox = WorkspaceSandbox(workspace_root)
        sandbox.safe_write("src/main.py", "def greet():\n    return 'Hello, World!'\n")
        sandbox.safe_write("data/input.json", json.dumps({"query": "analyze code"}))
        print(f"  Workspace: {workspace_root}")
        print(f"  Files: {sandbox.safe_list('.')}")

        # 3. Execute plan steps via sandbox + provider
        print("\n--- Step 3: Execute Plan Steps ---")
        provider = MockProvider(default_response="Analysis complete: code looks good")
        provider.set_response("analyze", "Analysis: greet() returns a greeting string")
        policy_decisions = []
        events = []
        spans = []
        step_ts = 0

        for node in plan_graph["nodes"]:
            meta = node.get("metadata", {})
            node_type = meta.get("node_type", "AGENT_TASK")
            step_ts += 1
            ts = f"2025-01-01T00:00:{step_ts:02d}Z"

            decision = "allow"
            if node_type == "TOOL_CALL":
                tool = meta.get("tool", "unknown")

                # Simulate policy check
                if tool == "read_file":
                    content = sandbox.safe_read("src/main.py")
                    print(f"  [{node['node_id']}] Read file: {len(content)} chars")
                elif tool == "write_file":
                    sandbox.safe_write("output/result.txt", "Analysis complete")
                    print(f"  [{node['node_id']}] Wrote output file")

            elif node_type == "AGENT_TASK":
                input_data = sandbox.safe_read("data/input.json")
                resp = provider.generate(f"analyze: {input_data}")
                sandbox.safe_write("output/analysis.txt", resp.text)
                print(f"  [{node['node_id']}] Model response: {resp.text[:50]}")

            elif node_type == "GATE_CHECK":
                # Verify output exists
                output = sandbox.safe_read("output/result.txt")
                print(f"  [{node['node_id']}] Gate check: output={len(output)} chars")

            # Record policy decision (tier2-policy-decision/1.0)
            policy_decisions.append({
                "schema_version": "tier2-policy-decision/1.0",
                "run_id": RUN_ID,
                "policy_id": "default",
                "decision": decision,
                "decided_at": ts,
                "reason": f"Step {node['node_id']} allowed",
                "context": {"action": "tool_call", "resource": meta.get("tool", node["name"])},
            })

            # Record event (tier2-event-envelope/1.0)
            events.append({
                "schema_version": "tier2-event-envelope/1.0",
                "event_id": f"evt-{step_ts:03d}",
                "event_type": "TASK_COMPLETED",
                "timestamp": ts,
                "run_id": RUN_ID,
                "payload": {"node_id": node["node_id"], "status": "completed"},
                "metadata": {},
            })

            # Record span (tier2-span-envelope/1.0)
            spans.append({
                "schema_version": "tier2-span-envelope/1.0",
                "span_id": f"span-{step_ts:03d}",
                "trace_id": "trace-001",
                "name": node["name"],
                "start_time": ts,
                "end_time": f"2025-01-01T00:00:{step_ts:02d}.500Z",
                "status": "ok",
                "parent_span_id": "",
                "attributes": {"node_id": node["node_id"]},
                "events": [],
            })

            node["status"] = "completed"

        # 4. Capture runtime context
        print("\n--- Step 4: Runtime Context ---")
        ctx = capture_context(workspace_root=workspace_root, repo_version="0.1.0")
        redacted = redact_context(ctx, workspace_root=str(workspace_root))
        print(f"  Python: {redacted['python_version']}")
        print(f"  Workspace: {redacted['workspace_path']}")

        # 5. Write evidence-pack-like folder
        pack_dir = workspace_root / "evidence_pack"
        pack_dir.mkdir()

        print("\n--- Step 5: Write Evidence Pack ---")

        # plan_graph.json
        with open(pack_dir / "plan_graph.json", "w") as f:
            json.dump(plan_graph, f, indent=2, sort_keys=True)
            f.write("\n")
        print("  plan_graph.json")

        # policy_decisions.ndjson
        with open(pack_dir / "policy_decisions.ndjson", "w") as f:
            for pd in policy_decisions:
                f.write(json.dumps(pd, sort_keys=True) + "\n")
        print(f"  policy_decisions.ndjson ({len(policy_decisions)} decisions)")

        # events.ndjson
        all_events = [
            {"schema_version": "tier2-event-envelope/1.0",
             "event_id": "evt-000", "event_type": "RUN_STARTED", "timestamp": FIXED_TS,
             "run_id": RUN_ID, "payload": {"message": "Runtime demo started"}, "metadata": {}},
            *events,
            {"schema_version": "tier2-event-envelope/1.0",
             "event_id": "evt-999", "event_type": "RUN_COMPLETED",
             "timestamp": f"2025-01-01T00:00:{step_ts + 1:02d}Z",
             "run_id": RUN_ID, "payload": {"status": "success"}, "metadata": {}},
        ]
        with open(pack_dir / "events.ndjson", "w") as f:
            for evt in all_events:
                f.write(json.dumps(evt, sort_keys=True) + "\n")
        print(f"  events.ndjson ({len(all_events)} events)")

        # spans.ndjson
        with open(pack_dir / "spans.ndjson", "w") as f:
            for span in spans:
                f.write(json.dumps(span, sort_keys=True) + "\n")
        print(f"  spans.ndjson ({len(spans)} spans)")

        # runtime_context.json
        write_context(redacted, pack_dir / "runtime_context.json")
        print("  runtime_context.json")

        # eval_results stub (for abi-evals)
        eval_results = {
            "schema_version": "eval-result/1.0",
            "suite_id": "runtime-e2e",
            "run_id": RUN_ID,
            "evaluated_at": FIXED_TS,
            "results": [
                {"case_id": "sandbox-safety", "status": "pass",
                 "actual": True, "message": "All sandbox checks passed", "diff": ""},
                {"case_id": "provider-determinism", "status": "pass",
                 "actual": True, "message": "Provider responses deterministic", "diff": ""},
            ],
            "summary": {"total": 2, "passed": 2, "failed": 0, "errors": 0, "skipped": 0},
        }
        with open(pack_dir / "eval_results.json", "w") as f:
            json.dump(eval_results, f, indent=2, sort_keys=True)
            f.write("\n")
        print("  eval_results.json")

        # manifest.json
        manifest = {
            "schema_version": "tier2-pack-manifest/1.0",
            "run_id": RUN_ID,
            "created_at": FIXED_TS,
            "components": {
                "plan_graph": "plan_graph.json",
                "policy_decisions": "policy_decisions.ndjson",
                "events": "events.ndjson",
                "spans": "spans.ndjson",
                "runtime_context": "runtime_context.json",
                "eval_results": "eval_results.json",
            },
            "summary": {"total_files": 6, "total_artifacts": 0},
        }
        with open(pack_dir / "manifest.json", "w") as f:
            json.dump(manifest, f, indent=2, sort_keys=True)
            f.write("\n")
        print("  manifest.json")

        print("\n--- Evidence Pack Contents ---")
        for item in sorted(pack_dir.iterdir()):
            print(f"  {item.name} ({item.stat().st_size} bytes)")

    print("\nCross-repo integration demo complete.")


if __name__ == "__main__":
    main()
