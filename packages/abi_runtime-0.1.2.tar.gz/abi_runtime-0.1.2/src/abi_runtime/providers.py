"""Model provider abstraction — interface + mock + local stub.

TODO: Propose abi-core schema for provider-response/1.0
(see docs/schema_proposals/runtime_context.md)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass(frozen=True)
class ProviderSettings:
    """Settings for a model invocation."""
    max_tokens: int = 4096
    temperature: float = 0.0
    stop_sequences: list[str] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ProviderResponse:
    """Response from a model provider."""
    text: str
    model: str = ""
    usage: dict[str, int] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


class Provider(Protocol):
    """Interface for model providers."""

    def generate(self, prompt: str, settings: ProviderSettings | None = None) -> ProviderResponse:
        """Generate a response from the model."""
        ...

    @property
    def name(self) -> str:
        """Provider name."""
        ...


class MockProvider:
    """Deterministic mock provider for testing.

    Returns predictable responses based on prompt content.
    Records all invocations for assertion.
    """

    def __init__(self, default_response: str = "Mock response") -> None:
        self._default_response = default_response
        self._responses: dict[str, str] = {}
        self._invocations: list[dict[str, Any]] = []

    @property
    def name(self) -> str:
        return "mock"

    @property
    def invocations(self) -> list[dict[str, Any]]:
        return list(self._invocations)

    def set_response(self, pattern: str, response: str) -> None:
        """Set a response for prompts containing the given pattern."""
        self._responses[pattern] = response

    def generate(self, prompt: str, settings: ProviderSettings | None = None) -> ProviderResponse:
        """Return deterministic mock response."""
        settings = settings or ProviderSettings()
        self._invocations.append({"prompt": prompt, "settings": settings})

        # Check pattern matches (sorted for determinism)
        for pattern in sorted(self._responses.keys()):
            if pattern in prompt:
                return ProviderResponse(
                    text=self._responses[pattern],
                    model="mock",
                    usage={
                        "input_tokens": len(prompt),
                        "output_tokens": len(self._responses[pattern]),
                    },
                )

        return ProviderResponse(
            text=self._default_response,
            model="mock",
            usage={
                "input_tokens": len(prompt),
                "output_tokens": len(self._default_response),
            },
        )


class LocalProviderStub:
    """Local provider stub — no actual model calls.

    Always returns a stub response indicating no local model is available.
    """

    @property
    def name(self) -> str:
        return "local-stub"

    def generate(self, prompt: str, settings: ProviderSettings | None = None) -> ProviderResponse:
        return ProviderResponse(
            text="[LocalProviderStub] No local model available. This is a stub response.",
            model="local-stub",
            usage={"input_tokens": len(prompt), "output_tokens": 0},
            metadata={"stub": True},
        )
