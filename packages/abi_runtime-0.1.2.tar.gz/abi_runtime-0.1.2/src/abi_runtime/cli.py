"""CLI for abi-runtime.

Usage:
    python -m abi_runtime.cli doctor
    python -m abi_runtime.cli demo-sandbox --workspace <dir>
"""
from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path

from abi_runtime.context import capture_context, redact_context, write_context
from abi_runtime.providers import LocalProviderStub, MockProvider, ProviderSettings
from abi_runtime.sandbox import SandboxViolation, WorkspaceSandbox


def cmd_doctor(args: argparse.Namespace) -> int:
    """Print runtime readiness information."""
    print("abi-runtime doctor")
    print("=" * 40)

    context = capture_context()
    redacted = redact_context(context)

    print(f"  Python:       {redacted['python_version']}")
    print(f"  Platform:     {redacted['platform']}")
    print(f"  Architecture: {redacted['architecture']}")
    print(f"  Workspace:    {redacted['workspace_path']}")

    # Check providers
    print("\n--- Providers ---")
    mock = MockProvider()
    resp = mock.generate("test", ProviderSettings())
    print(f"  MockProvider:     OK (response: {len(resp.text)} chars)")

    local = LocalProviderStub()
    resp = local.generate("test")
    print(f"  LocalProviderStub: OK (stub={resp.metadata.get('stub', False)})")

    print("\n--- Sandbox ---")
    with tempfile.TemporaryDirectory() as tmp:
        sandbox = WorkspaceSandbox(Path(tmp))
        try:
            sandbox.resolve_path("test.txt")
            print("  Path resolution:   OK")
        except Exception as e:
            print(f"  Path resolution:   FAIL ({e})")

        try:
            sandbox.resolve_path("../escape")
            print("  Path traversal:    FAIL (should have been blocked)")
        except SandboxViolation:
            print("  Path traversal:    BLOCKED (correct)")

    print("\nRuntime ready.")
    return 0


def cmd_demo_sandbox(args: argparse.Namespace) -> int:
    """Demonstrate sandbox allow/deny behavior."""
    workspace = Path(args.workspace)
    if not workspace.exists():
        workspace.mkdir(parents=True)

    sandbox = WorkspaceSandbox(workspace)

    print(f"abi-runtime sandbox demo (workspace: {workspace})")
    print("=" * 50)

    test_cases = [
        ("src/main.py", True),
        ("docs/readme.md", True),
        ("../../../etc/passwd", False),
        ("/etc/shadow", False),
        (".env", False),
        ("secrets.json", False),
        ("config/settings.yaml", True),
    ]

    for path, _should_allow in test_cases:
        try:
            sandbox.resolve_path(path)
            allowed = sandbox.check_allowlist(path)
            if allowed:
                print(f"  [OK] {path} -> ALLOWED")
            else:
                print(f"  [XX] {path} -> DENIED (not in allowlist)")
        except SandboxViolation as e:
            print(f"  [XX] {path} -> BLOCKED ({e})")

    # Demo safe write/read
    print("\n--- File Operations ---")
    sandbox.safe_write("demo_output.txt", "Hello from sandbox!")
    content = sandbox.safe_read("demo_output.txt")
    print(f"  Write + Read: '{content}'")

    # Demo temp dir
    temp = sandbox.temp_dir("demo0001")
    temp2 = sandbox.temp_dir("demo0001")
    print(f"  Temp dir (run_id=demo0001): {temp}")
    print(f"  Same run_id → same dir: {temp == temp2}")

    # Demo context capture
    print("\n--- Runtime Context ---")
    ctx = capture_context(workspace_root=workspace, repo_version="0.1.0")
    redacted = redact_context(ctx, workspace_root=str(workspace))
    out_path = workspace / "runtime_context.json"
    write_context(redacted, out_path)
    print(f"  Written to: {out_path}")

    print("\nDemo complete.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="abi-runtime",
        description="ABI Runtime — sandboxed tool runtime and provider abstraction",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("doctor", help="Print runtime readiness")

    p_sandbox = sub.add_parser("demo-sandbox", help="Demonstrate sandbox behavior")
    p_sandbox.add_argument("--workspace", required=True, help="Workspace directory")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    commands = {
        "doctor": cmd_doctor,
        "demo-sandbox": cmd_demo_sandbox,
    }

    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
