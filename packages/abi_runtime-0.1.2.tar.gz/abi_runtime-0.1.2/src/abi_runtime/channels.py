"""Provider channel abstraction for model routing.

Channel types:
- api: Metered API access (per-token billing)
- subscription: Seat/capacity constrained (concurrency slots, cooldowns)
- local: Local model (ollama, unlimited capacity)

Does NOT implement provider ToS-violating automation.
Provides dispatch stubs for MCO integration.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol


class ChannelType(Enum):
    """Supported channel types for model routing."""

    api = "api"
    subscription = "subscription"
    local = "local"


@dataclass(frozen=True)
class ChannelCapacity:
    """Snapshot of a channel's capacity state."""

    channel_type: ChannelType
    concurrency_limit: int = 1
    cooldown_seconds: float = 0.0
    rate_limit_rpm: int = 0
    active_slots: int = 0


@dataclass(frozen=True)
class DispatchRequest:
    """Request to dispatch a prompt through a channel."""

    model_id: str
    prompt: str
    settings: dict[str, Any] = field(default_factory=dict)
    channel_id: str = ""
    provider_id: str = ""


@dataclass(frozen=True)
class DispatchResponse:
    """Response from a channel dispatch."""

    text: str
    model_id: str = ""
    channel_id: str = ""
    usage: dict[str, int] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


class ChannelDispatcher(Protocol):
    """Interface for channel-based model dispatch."""

    def dispatch(self, request: DispatchRequest) -> DispatchResponse:
        """Dispatch a request through the channel."""
        ...

    def capacity(self) -> ChannelCapacity:
        """Return current channel capacity snapshot."""
        ...


class StubChannelDispatcher:
    """Stub dispatcher for testing and integration scaffolding.

    Returns a fixed stub response, tracks invocations, and respects
    the configured concurrency limit.
    """

    def __init__(
        self,
        channel_type: ChannelType = ChannelType.api,
        concurrency_limit: int = 5,
    ) -> None:
        self._channel_type = channel_type
        self._concurrency_limit = concurrency_limit
        self._invocations: list[DispatchRequest] = []
        self._active_slots = 0

    @property
    def invocations(self) -> list[DispatchRequest]:
        return list(self._invocations)

    def dispatch(self, request: DispatchRequest) -> DispatchResponse:
        """Return a stub response and record the invocation."""
        cap = self.capacity()
        if not check_capacity(cap):
            return DispatchResponse(
                text="[StubChannelDispatcher] Capacity exceeded.",
                model_id=request.model_id,
                channel_id=request.channel_id,
                usage={},
                metadata={"stub": True, "capacity_exceeded": True},
            )

        self._invocations.append(request)
        return DispatchResponse(
            text="[StubChannelDispatcher] Stub response.",
            model_id=request.model_id,
            channel_id=request.channel_id,
            usage={"input_tokens": len(request.prompt), "output_tokens": 0},
            metadata={"stub": True},
        )

    def capacity(self) -> ChannelCapacity:
        """Return current capacity snapshot."""
        return ChannelCapacity(
            channel_type=self._channel_type,
            concurrency_limit=self._concurrency_limit,
            active_slots=self._active_slots,
        )


def check_capacity(capacity: ChannelCapacity) -> bool:
    """Return True if the channel has available capacity.

    A channel has capacity when its active slots are strictly below
    the concurrency limit.
    """
    return capacity.active_slots < capacity.concurrency_limit
