"""Command execution stub — no real shell by default.

Provides a safe, mockable command execution interface.
By default, all commands are stubbed (no real shell execution).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class CommandResult:
    """Result of a command execution."""
    exit_code: int
    stdout: str
    stderr: str
    command: str
    stubbed: bool = True


class CommandExecutor:
    """Command execution interface (stubbed by default).

    No real shell execution in default mode.
    Use MockCommandExecutor for testing.
    """

    def __init__(self, allow_real: bool = False) -> None:
        self._allow_real = allow_real
        self._invocations: list[dict[str, Any]] = []

    @property
    def invocations(self) -> list[dict[str, Any]]:
        return list(self._invocations)

    def execute(self, command: str, cwd: str | None = None) -> CommandResult:
        """Execute a command (stubbed by default)."""
        self._invocations.append({"command": command, "cwd": cwd})

        if not self._allow_real:
            return CommandResult(
                exit_code=0,
                stdout=f"[STUB] Would execute: {command}",
                stderr="",
                command=command,
                stubbed=True,
            )

        # Real execution would go here (not implemented for safety)
        raise NotImplementedError("Real command execution not implemented")


class DockerExecutor:
    """Docker execution stub — no real Docker calls in default mode."""

    def __init__(self) -> None:
        self._invocations: list[dict[str, Any]] = []

    @property
    def invocations(self) -> list[dict[str, Any]]:
        return list(self._invocations)

    def run(
        self,
        image: str,
        command: str,
        volumes: dict[str, str] | None = None,
    ) -> CommandResult:
        """Run a Docker container (stubbed)."""
        self._invocations.append({
            "image": image,
            "command": command,
            "volumes": volumes or {},
        })

        return CommandResult(
            exit_code=0,
            stdout=f"[DOCKER STUB] Would run {image}: {command}",
            stderr="",
            command=f"docker run {image} {command}",
            stubbed=True,
        )
