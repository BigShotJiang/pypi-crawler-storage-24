import sys

from abi_runtime.cli import main

sys.exit(main())
