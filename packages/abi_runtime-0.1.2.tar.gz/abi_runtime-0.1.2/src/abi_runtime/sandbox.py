"""Workspace sandbox — enforces path safety and workspace root boundaries.

Key security properties:
- WorkspaceRoot enforced (no path escape)
- Symlink escape denied
- Safe file read/write API with allowlist patterns
- All paths resolved relative to workspace root
"""
from __future__ import annotations

import fnmatch
import hashlib
import os
from pathlib import Path, PurePosixPath


class SandboxViolation(Exception):
    """Raised when a sandbox rule is violated."""


class WorkspaceSandbox:
    """Sandboxed file operations within a workspace root.

    All file operations are constrained to the workspace root directory.
    Path traversal, symlink escape, and absolute paths are blocked.
    """

    def __init__(
        self,
        workspace_root: Path,
        allow_patterns: list[str] | None = None,
        deny_patterns: list[str] | None = None,
    ) -> None:
        self.root = workspace_root.resolve()
        self.allow_patterns = allow_patterns or ["*"]
        self.deny_patterns = deny_patterns or [
            "*.env",
            ".env.*",
            "secrets.*",
            ".git/**",
            "**/.git/**",
            "node_modules/**",
            "**/node_modules/**",
        ]

    def resolve_path(self, relative_path: str) -> Path:
        """Resolve a relative path within the workspace root.

        Raises SandboxViolation if the path escapes the workspace.
        """
        # Block absolute paths (including Unix-style on Windows)
        if (
            os.path.isabs(relative_path)
            or (len(relative_path) >= 2 and relative_path[1] == ':')
            or relative_path.startswith("/")
            or relative_path.startswith("\\")
        ):
            raise SandboxViolation(f"Absolute paths not allowed: {relative_path}")

        # Normalize separators
        normalized = relative_path.replace("\\", "/")

        # Block path traversal components
        parts = PurePosixPath(normalized).parts
        if ".." in parts:
            raise SandboxViolation(f"Path traversal not allowed: {relative_path}")

        # Resolve full path
        full_path = (self.root / normalized).resolve()

        # Verify it's within workspace root
        try:
            full_path.relative_to(self.root)
        except ValueError:
            raise SandboxViolation(
                f"Path escapes workspace root: {relative_path} -> {full_path}"
            ) from None

        # Check symlink escape
        if full_path.exists() and full_path.is_symlink():
            real_target = full_path.resolve()
            try:
                real_target.relative_to(self.root)
            except ValueError:
                raise SandboxViolation(
                    f"Symlink escape detected: {relative_path} -> {real_target}"
                ) from None

        return full_path

    def _match_pattern(self, path: str, pattern: str) -> bool:
        """Match a path against a pattern, supporting ** for recursive matching.

        Checks the full path AND the basename against the pattern for
        patterns without path separators. For patterns with **, uses
        PurePosixPath.match which handles recursive globbing.
        """
        # Use PurePosixPath.match which handles ** correctly
        if PurePosixPath(path).match(pattern):
            return True
        # Also check basename for simple patterns (no path separator)
        if "/" not in pattern:
            basename = PurePosixPath(path).name
            if fnmatch.fnmatch(basename, pattern):
                return True
        return False

    def check_allowlist(self, relative_path: str) -> bool:
        """Check if a path matches the allowlist and doesn't match denylist."""
        normalized = relative_path.replace("\\", "/")

        # Check deny patterns first
        for pattern in self.deny_patterns:
            if self._match_pattern(normalized, pattern):
                return False

        # Check allow patterns
        if self.allow_patterns == ["*"]:
            return True
        return any(self._match_pattern(normalized, p) for p in self.allow_patterns)

    def safe_read(self, relative_path: str) -> str:
        """Read a file safely within the sandbox."""
        full_path = self.resolve_path(relative_path)
        if not self.check_allowlist(relative_path):
            raise SandboxViolation(f"Path not in allowlist: {relative_path}")
        if not full_path.exists():
            raise FileNotFoundError(f"File not found: {relative_path}")
        return full_path.read_text(encoding="utf-8")

    def safe_write(self, relative_path: str, content: str) -> Path:
        """Write a file safely within the sandbox."""
        full_path = self.resolve_path(relative_path)
        if not self.check_allowlist(relative_path):
            raise SandboxViolation(f"Path not in allowlist: {relative_path}")
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        return full_path

    def safe_list(self, relative_dir: str = ".") -> list[str]:
        """List files in a directory within the sandbox."""
        full_path = self.resolve_path(relative_dir)
        if not full_path.is_dir():
            raise FileNotFoundError(f"Directory not found: {relative_dir}")
        result = []
        for item in sorted(full_path.iterdir()):
            rel = str(item.relative_to(self.root)).replace("\\", "/")
            result.append(rel)
        return result

    def temp_dir(self, run_id: str) -> Path:
        """Create a deterministic temp directory within workspace.

        Given a fixed run_id, always returns the same directory path.
        """
        # Deterministic hash-based path
        dir_hash = hashlib.sha256(run_id.encode()).hexdigest()[:12]
        temp = self.root / ".abi-tmp" / dir_hash
        temp.mkdir(parents=True, exist_ok=True)
        return temp
