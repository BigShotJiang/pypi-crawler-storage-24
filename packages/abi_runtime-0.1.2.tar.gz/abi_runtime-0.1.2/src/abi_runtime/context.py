"""Runtime context capture — collects environment metadata.

Produces runtime_context.json (internal format).
TODO: Propose abi-core schema runtime-context/1.0

Secrets are redacted by allowlist: only known-safe keys are included.
Workspace paths are redacted to <WORKSPACE>.
"""
from __future__ import annotations

import json
import platform
import sys
from pathlib import Path
from typing import Any

# Keys that are SAFE to include (allowlist approach)
SAFE_CONTEXT_KEYS = {
    "python_version",
    "platform",
    "platform_version",
    "architecture",
    "repo_version",
    "workspace_path",
    "dependencies",
}

# Environment variable prefixes that might contain secrets
SECRET_ENV_PREFIXES = (
    "API_KEY", "SECRET", "TOKEN", "PASSWORD", "CREDENTIAL",
    "AWS_", "AZURE_", "GCP_", "GITHUB_TOKEN", "OPENAI_",
)


def capture_context(
    workspace_root: Path | None = None,
    repo_version: str = "unknown",
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Capture runtime context metadata.

    Returns a dict with safe, redacted environment information.
    """
    context: dict[str, Any] = {
        "schema_version": "tier2-runtime-context/1.0",
        "python_version": (
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        ),
        "platform": platform.system(),
        "platform_version": platform.version(),
        "architecture": platform.machine(),
        "repo_version": repo_version,
        "workspace_path": "<WORKSPACE>",  # Always redacted
        "dependencies": _get_dependencies(),
    }

    if extra:
        # Only include safe keys from extra
        for key, value in extra.items():
            if key in SAFE_CONTEXT_KEYS:
                context[key] = value

    return context


def _get_dependencies() -> list[dict[str, str]]:
    """Get installed package versions (equivalent to pip freeze).

    Returns a deterministic sorted list.
    """
    try:
        from importlib.metadata import distributions
        deps = []
        for dist in distributions():
            deps.append({
                "name": dist.metadata["Name"],
                "version": dist.metadata["Version"],
            })
        return sorted(deps, key=lambda d: d["name"].lower())
    except Exception:
        return []


def redact_value(value: str, key: str = "") -> str:
    """Redact a value if the key suggests it's sensitive."""
    upper_key = key.upper()
    for prefix in SECRET_ENV_PREFIXES:
        if prefix in upper_key:
            return "<REDACTED>"
    return value


def redact_context(context: dict[str, Any], workspace_root: str = "") -> dict[str, Any]:
    """Apply redaction rules to a context dict.

    - Workspace paths replaced with <WORKSPACE>
    - Known secret patterns replaced with <REDACTED>
    """
    redacted = {}
    for key, value in sorted(context.items()):
        if isinstance(value, str):
            # Redact workspace paths
            if workspace_root and workspace_root in value:
                value = value.replace(workspace_root, "<WORKSPACE>")
            value = redact_value(value, key)
        elif isinstance(value, dict):
            value = redact_context(value, workspace_root)
        elif isinstance(value, list):
            value = [
                redact_context(item, workspace_root) if isinstance(item, dict) else item
                for item in value
            ]
        redacted[key] = value
    return redacted


def write_context(context: dict[str, Any], path: Path) -> None:
    """Write runtime context to JSON file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(context, f, indent=2, ensure_ascii=False, sort_keys=True)
        f.write("\n")
