"""SeekAPI worker SDK: get_input, push_data/push_file, run(), success/failure.
Zero dependencies; use in AWS Lambda workers with WORKER_API_BASE_URL and WORKER_INTERNAL_SECRET set."""

import json
import mimetypes
import os
import uuid
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

_LAMBDA_TIMEOUT_SAFETY_MARGIN_SECONDS = 2
_MIN_TIMEOUT_SECONDS = 1


class MissingInputError(ValueError):
    """Raised when event has no input_presigned_url."""


def _safe_timeout(context: object, default_timeout: int) -> int:
    """Compute a network timeout that fits in the Lambda remaining time budget."""
    timeout = max(_MIN_TIMEOUT_SECONDS, int(default_timeout))
    if not context or not hasattr(context, "get_remaining_time_in_millis"):
        return timeout
    try:
        remaining_ms = int(context.get_remaining_time_in_millis())
    except Exception:
        return timeout
    remaining_seconds = max(0, remaining_ms // 1000)
    budget = max(
        _MIN_TIMEOUT_SECONDS,
        remaining_seconds - _LAMBDA_TIMEOUT_SAFETY_MARGIN_SECONDS,
    )
    return max(_MIN_TIMEOUT_SECONDS, min(timeout, budget))


def get_input(event: dict, timeout: int = 10) -> dict:
    """Fetch and parse job input from the presigned URL in the event.
    Returns the JSON body as a dict. Raises MissingInputError if input_presigned_url
    is missing, or ValueError on HTTP/JSON errors (with a clear message)."""
    url = (event.get("input_presigned_url") or "").strip()
    if not url:
        raise MissingInputError("Missing input_presigned_url in event")
    try:
        with urlopen(url, timeout=timeout) as resp:
            if resp.status >= 400:
                raise ValueError(f"Input URL returned HTTP {resp.status}")
            body = resp.read().decode("utf-8")
        return json.loads(body)
    except (HTTPError, URLError) as e:
        raise ValueError(f"Failed to fetch input: {e}") from e
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in input: {e}") from e


def create_context(event: dict) -> dict:
    """Build context from Lambda event for push_data/push_file.
    Returns dict with job_uuid, execution_token, api_base, secret (from env)."""
    job_uuid = (event.get("job_uuid") or "").strip()
    execution_token = (event.get("execution_token") or "").strip()
    api_base = (os.environ.get("WORKER_API_BASE_URL") or "").strip().rstrip("/")
    secret = (os.environ.get("WORKER_INTERNAL_SECRET") or "").strip()
    return {
        "job_uuid": job_uuid,
        "execution_token": execution_token,
        "api_base": api_base,
        "secret": secret,
        "max_job_billing_usd": event.get("max_job_billing_usd"),
        "billing_mode": event.get("billing_mode"),
        "unit_price_usd": event.get("unit_price_usd"),
    }


def register_request_id(job_uuid: str, request_id: str, timeout: int = 3) -> None:
    """Call the API to register this Lambda's request_id so live execution logs can be streamed.
    No-op if WORKER_API_BASE_URL or WORKER_INTERNAL_SECRET is not set."""
    base = (os.environ.get("WORKER_API_BASE_URL") or "").strip().rstrip("/")
    secret = (os.environ.get("WORKER_INTERNAL_SECRET") or "").strip()
    if not base or not secret:
        return
    url = f"{base}/v1/internal/jobs/{job_uuid}/worker-request-id"
    try:
        data = json.dumps({"request_id": request_id}).encode("utf-8")
        req = Request(
            url,
            data=data,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "X-Internal-Secret": secret,
            },
        )
        urlopen(req, timeout=timeout)
    except (HTTPError, URLError, OSError):
        pass


def push_data(
    context: dict,
    data: dict,
    type: str = "json",
    bill: bool = False,
    billing_push_id: str | None = None,
    timeout: int = 8,
) -> None:
    """Push JSON data to the job (overwrites response_json). No-op if api_base/secret not set."""
    api_base = context.get("api_base") or ""
    secret = context.get("secret") or ""
    job_uuid = context.get("job_uuid") or ""
    execution_token = context.get("execution_token") or ""
    if not api_base or not secret or not job_uuid or not execution_token:
        return
    url = f"{api_base}/v1/internal/jobs/{job_uuid}/push"
    try:
        body = json.dumps({
            "execution_token": execution_token,
            "data": data,
            "type": type,
            "bill": bool(bill),
            "billing_push_id": billing_push_id or (uuid.uuid4().hex if bill else None),
        }).encode("utf-8")
        req = Request(
            url,
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "X-Internal-Secret": secret,
            },
        )
        urlopen(req, timeout=timeout)
    except (HTTPError, URLError, OSError):
        raise


def push_file(
    context: dict,
    name: str,
    local_path: str,
    content_type: str | None = None,
    bill: bool = False,
    billing_push_id: str | None = None,
    timeout: int = 15,
) -> None:
    """Push a file from local_path to the job temp_files. No-op if api_base/secret not set."""
    api_base = context.get("api_base") or ""
    secret = context.get("secret") or ""
    job_uuid = context.get("job_uuid") or ""
    execution_token = context.get("execution_token") or ""
    if not api_base or not secret or not job_uuid or not execution_token:
        return
    url = f"{api_base}/v1/internal/jobs/{job_uuid}/push/file"
    ct = content_type
    if not ct:
        ct, _ = mimetypes.guess_type(local_path)
        ct = ct or "application/octet-stream"
    try:
        with open(local_path, "rb") as f:
            body_bytes = f.read()
    except OSError:
        raise

    # multipart/form-data: execution_token, name, file
    boundary = "----WorkerSDKBoundary" + os.urandom(8).hex()
    b = boundary.encode("ascii")
    crlf = b"\r\n"
    body_parts = [
        b"--" + b + crlf,
        b'Content-Disposition: form-data; name="execution_token"' + crlf + crlf,
        execution_token.encode("utf-8"),
        crlf,
        b"--" + b + crlf,
        b'Content-Disposition: form-data; name="name"' + crlf + crlf,
        name.encode("utf-8"),
        crlf,
        b"--" + b + crlf,
        b'Content-Disposition: form-data; name="bill"' + crlf + crlf,
        (b"true" if bill else b"false"),
        crlf,
        b"--" + b + crlf,
        b'Content-Disposition: form-data; name="billing_push_id"' + crlf + crlf,
        (billing_push_id or (uuid.uuid4().hex if bill else "")).encode("utf-8"),
        crlf,
        b"--" + b + crlf,
        b'Content-Disposition: form-data; name="file"; filename="' + name.encode("utf-8") + b'"' + crlf,
        b"Content-Type: " + ct.encode("ascii") + crlf + crlf,
        body_bytes,
        crlf,
        b"--" + b + b"--" + crlf,
    ]
    body = b"".join(body_parts)
    req = Request(
        url,
        data=body,
        method="POST",
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "X-Internal-Secret": secret,
        },
    )
    try:
        urlopen(req, timeout=timeout)
    except (HTTPError, URLError, OSError):
        raise


def success(request_id: str | None = None) -> dict:
    """Return minimal success payload for Lambda. Result is taken from last push_data."""
    out: dict = {"ok": True}
    if request_id:
        out["request_id"] = request_id
    return out


def failure(code: str, message: str, request_id: str | None = None) -> dict:
    """Return minimal failure payload for Lambda."""
    out: dict = {
        "ok": False,
        "error": {"code": code, "message": message},
    }
    if request_id:
        out["request_id"] = request_id
    return out


def run(
    event: dict,
    context: object,
    user_fn: "object",  # Callable[[dict], dict]
) -> dict:
    """Run a worker with input/output handled by the SDK.
    Fetches input via get_input(event), calls user_fn(input_data), pushes the
    result via push_data, and returns success(request_id). On any exception,
    returns failure('WORKER_ERROR', str(e), request_id)."""
    request_id = getattr(context, "aws_request_id", None) if context else None
    job_uuid = (event.get("job_uuid") or "").strip()
    if request_id and job_uuid:
        register_request_id(
            job_uuid,
            request_id,
            timeout=_safe_timeout(context, default_timeout=3),
        )
    ctx = create_context(event)
    try:
        input_data = get_input(event, timeout=_safe_timeout(context, default_timeout=10))
        result = user_fn(input_data)
        push_data(ctx, result, timeout=_safe_timeout(context, default_timeout=8))
        return success(request_id=request_id)
    except Exception as e:
        return failure("WORKER_ERROR", str(e), request_id=request_id)


__all__ = [
    "MissingInputError",
    "get_input",
    "create_context",
    "register_request_id",
    "push_data",
    "push_file",
    "success",
    "failure",
    "run",
]
