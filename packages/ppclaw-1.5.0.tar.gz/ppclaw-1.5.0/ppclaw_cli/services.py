"""Web Terminal (ttyd) and File Manager (gohttpserver) service management."""

import json
import secrets

from .const import FILE_MANAGER_PORT, SERVICES_USERNAME, TTYD_PORT
from .output import ServiceConfigError
from .sandbox import SandboxManager
from .utils import print_info, print_success

SERVICES_CONFIG_PATH = "/home/user/.ppclaw/services.json"

_SERVICE_BINARIES = ["ttyd", "gohttpserver"]

_TTYD_INSTALL_CMD = (
    "curl -sSL -o /usr/local/bin/ttyd"
    " https://github.com/tsl0922/ttyd/releases/latest/download/ttyd.x86_64"
    " && chmod +x /usr/local/bin/ttyd"
)

_GOHTTPSERVER_INSTALL_CMD = (
    "curl -sSL -o-"
    " https://github.com/codeskyblue/gohttpserver/releases/download/1.3.0/"
    "gohttpserver_1.3.0_linux_amd64.tar.gz"
    " | tar -zxf - -C /usr/local/bin/ gohttpserver"
    " && chmod +x /usr/local/bin/gohttpserver"
)


def generate_password(length=16) -> str:
    """Generate a cryptographically secure URL-safe random password."""
    return secrets.token_urlsafe(length)


def configure_services(manager: SandboxManager, password: str = None) -> dict:
    """Configure and start ttyd + gohttpserver with random credentials.

    Returns dict with username and password.
    Raises ServiceConfigError on failure.
    """
    username = SERVICES_USERNAME
    if password is None:
        password = generate_password()

    credentials = {"username": username, "password": password}

    manager.run_command("mkdir -p /home/user/.ppclaw", timeout=10)
    manager.write_file(SERVICES_CONFIG_PATH, json.dumps(credentials, indent=2))
    manager.run_command(
        "chmod 600 {path}".format(path=SERVICES_CONFIG_PATH),
        timeout=10,
    )

    _start_service(
        manager,
        name="Web Terminal",
        binary="ttyd",
        cmd="nohup ttyd -p {port} -W -O -c {user}:{pw} bash > /tmp/ttyd.log 2>&1 &".format(
            port=TTYD_PORT,
            user=username,
            pw=password,
        ),
        port=TTYD_PORT,
    )
    _start_service(
        manager,
        name="File Manager",
        binary="gohttpserver",
        cmd=(
            "nohup gohttpserver --port {port} --upload --delete"
            " --root /home/user --auth-type http --auth-http {user}:{pw}"
            " > /tmp/gohttpserver.log 2>&1 &"
        ).format(port=FILE_MANAGER_PORT, user=username, pw=password),
        port=FILE_MANAGER_PORT,
    )

    return credentials


def _start_service(manager: SandboxManager, name: str, binary: str, cmd: str, port: int):
    """Kill any existing process for *binary*, then launch *cmd*."""
    print_info("Starting {name}...".format(name=name))
    manager.run_command(
        "pkill -9 {bin} 2>/dev/null || true".format(bin=binary),
        timeout=10,
        silent=True,
    )
    result = manager.run_command(cmd, timeout=10)
    if result is None:
        raise ServiceConfigError(
            "Failed to start {name} ({bin}). "
            "The binary may not be installed in this sandbox.".format(name=name, bin=binary)
        )
    print_success("{name} started on port {port}".format(name=name, port=port))


def restart_services(manager: SandboxManager):
    """Restart ttyd and gohttpserver using saved credentials.

    Raises ServiceConfigError if no saved credentials are found.
    """
    credentials = get_service_credentials(manager)
    if not credentials:
        raise ServiceConfigError(
            "No saved service credentials found. Run launch to configure services first."
        )
    configure_services(manager, password=credentials["password"])


def stop_services(manager: SandboxManager):
    """Stop ttyd and gohttpserver."""
    print_info("Stopping services...")
    for binary in _SERVICE_BINARIES:
        manager.run_command(
            "pkill -9 {bin} 2>/dev/null || true".format(bin=binary),
            timeout=10,
            silent=True,
        )
    print_success("Services stopped")


def get_service_credentials(manager: SandboxManager) -> dict:
    """Read saved service credentials from the sandbox.

    Returns {"username": "...", "password": "..."} or empty dict if not found.
    """
    try:
        content = manager.read_file(SERVICES_CONFIG_PATH)
        if content:
            return json.loads(content)
    except Exception:
        pass
    return {}


def install_services(manager: SandboxManager):
    """Install ttyd and gohttpserver binaries into the sandbox.

    Skips binaries that are already installed. Raises ServiceConfigError on failure.
    """
    for binary, cmd in [("ttyd", _TTYD_INSTALL_CMD), ("gohttpserver", _GOHTTPSERVER_INSTALL_CMD)]:
        check = manager.run_command("which {bin}".format(bin=binary), timeout=10, silent=True)
        if check and check.stdout and check.stdout.strip():
            print_info("{bin} already installed, skipping.".format(bin=binary))
            continue
        print_info("Installing {bin}...".format(bin=binary))
        result = manager.run_command(cmd, timeout=120)
        if result is None:
            raise ServiceConfigError("Failed to install {bin}.".format(bin=binary))
        print_success("{bin} installed.".format(bin=binary))


def get_service_urls(manager: SandboxManager) -> dict:
    """Get public URLs for Web Terminal and File Manager."""
    ttyd_host = manager.sandbox.get_host(TTYD_PORT)
    fm_host = manager.sandbox.get_host(FILE_MANAGER_PORT)
    return {
        "terminal": "https://{host}".format(host=ttyd_host),
        "filemanager": "https://{host}".format(host=fm_host),
    }
