"""CLI entry point for OpenClaw Sandbox CLI."""

import atexit
import functools
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request

import click
from dotenv import load_dotenv
from rich.panel import Panel
from rich.table import Table

from .config import load_config
from .const import (
    API_KEY_URL,
    BRAND_NAME,
    CLI_NAME,
    CONFIG_DIR_NAME,
    CONFIG_SECTION,
    ENV_VAR_API_KEY,
    PACKAGE_NAME,
    PROVIDER_NAME,
    TEMPLATE_ID,
)
from .openclaw import (
    OPENCLAW_CONFIG_PATH,
    configure_openclaw,
    get_gateway_token,
    get_public_urls,
    launch_gateway,
    restart_gateway,
    update_openclaw,
    wait_for_gateway,
)
from .output import (
    EXIT_MISSING_API_KEY,
    CLIError,
    DoctorError,
    PairingError,
    UpdateError,
    is_json_mode,
    output_error,
    output_success,
    set_json_mode,
)
from .sandbox import SANDBOX_KEEP_ALIVE, SandboxManager
from .services import (
    configure_services,
    get_service_credentials,
    get_service_urls,
    install_services,
)
from .utils import console, get_console, print_error, print_info, print_success

load_dotenv()

_API_KEY_HELP = ("{provider} API key (recommended: export {env}=<key>). Get yours at {url}").format(
    provider=PROVIDER_NAME, env=ENV_VAR_API_KEY, url=API_KEY_URL
)

# --- Helpers ---


def _print_api_key_guide():
    """Print API key setup guide and exit."""
    if is_json_mode():
        output_error(
            "MISSING_API_KEY",
            "{provider} API key is required. Set via --api-key, {env} env, or config file.".format(
                provider=PROVIDER_NAME,
                env=ENV_VAR_API_KEY,
            ),
            10,
        )
        return  # output_error raises SystemExit, but guard explicitly

    print_error(
        "{provider} API key is required. Configure it using one of these methods:".format(
            provider=PROVIDER_NAME,
        )
    )
    console.print()
    console.print("  1. Pass directly (launch only):")
    console.print("     [cyan]{cli} launch --api-key sk_your_api_key[/cyan]".format(cli=CLI_NAME))
    console.print()
    console.print("  2. Set for current command:")
    console.print(
        "     [cyan]{env}=sk_your_api_key {cli} <command>[/cyan]".format(
            env=ENV_VAR_API_KEY,
            cli=CLI_NAME,
        )
    )
    console.print()
    console.print("  3. Export for current session:")
    console.print("     [cyan]export {env}=sk_your_api_key[/cyan]".format(env=ENV_VAR_API_KEY))
    console.print()
    console.print("  4. Add to shell profile (~/.bashrc or ~/.zshrc):")
    console.print(
        "     [cyan]echo 'export {env}=sk_your_api_key' >> ~/.zshrc[/cyan]".format(
            env=ENV_VAR_API_KEY,
        )
    )
    console.print()
    console.print("  Get your API key at: [link={url}]{url}[/link]".format(url=API_KEY_URL))
    raise SystemExit(EXIT_MISSING_API_KEY)


def _resolve_api_key(kwargs) -> str:
    """Resolve API key from kwargs/env/config or raise."""
    config = load_config()
    key = kwargs.get("api_key") or config[CONFIG_SECTION].get("api_key")
    if not key:
        _print_api_key_guide()
    return key


def require_api_key(f):
    """Decorator that resolves the API key and injects it into kwargs."""

    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        kwargs["api_key"] = _resolve_api_key(kwargs)
        return f(*args, **kwargs)

    return wrapper


def _build_webui_url(urls, gw_token):
    """Append gateway token fragment to WebUI URL for auto-authentication."""
    webui_url = urls["webui"]
    if gw_token:
        webui_url = "{base}#token={token}".format(base=webui_url, token=gw_token)
    return webui_url


def _print_webui_url(webui_url):
    """Print the WebUI URL on a standalone line for easy clicking/copying."""
    console.print(
        "\n  [bold green]\u25b6 Web UI:[/bold green] {webui}\n".format(webui=webui_url),
        highlight=False,
    )


def _print_gateway_info(webui_url, urls, gw_token):
    """Print gateway summary (WebUI URL, WS endpoint, token)."""
    _print_webui_url(webui_url)
    print_info("Gateway WS: {ws}".format(ws=urls["gateway_ws"]))
    if gw_token:
        print_info("Gateway Token: {token}".format(token=gw_token))


def _print_service_info(service_urls: dict, creds: dict):
    """Print service URLs and credentials block."""
    console.print()
    console.print("  [cyan]Web Terminal:[/cyan]    {url}".format(url=service_urls["terminal"]))
    console.print("  [cyan]File Manager:[/cyan]    {url}".format(url=service_urls["filemanager"]))
    console.print("  [cyan]Login User:[/cyan]      {u}".format(u=creds["username"]))
    console.print("  [cyan]Login Password:[/cyan]  {p}".format(p=creds["password"]))
    console.print("  [dim](credentials for Web Terminal & File Manager)[/dim]")
    console.print()


def _service_result(sandbox_id: str, service_urls: dict, creds: dict, **extra) -> dict:
    """Build JSON result dict for service info."""
    result = {
        "sandbox_id": sandbox_id,
        "terminal_url": service_urls["terminal"],
        "filemanager_url": service_urls["filemanager"],
        "services_username": creds["username"],
        "services_password": creds["password"],
    }
    result.update(extra)
    return result


def _print_sandbox_info(
    sandbox_id, gateway_token, urls, keep_alive, service_urls=None, service_creds=None
):
    """Print sandbox launch summary."""
    summary = (
        "[cyan]Sandbox ID:[/cyan]         {sandbox_id}\n"
        "[cyan]Keep Alive:[/cyan]         {keep_alive}s\n"
        "[cyan]Gateway WebSocket:[/cyan]  {gateway_ws}\n"
        "[cyan]Gateway Token:[/cyan]      {gateway_token}"
    ).format(
        sandbox_id=sandbox_id,
        keep_alive=keep_alive,
        gateway_ws=urls["gateway_ws"],
        gateway_token=gateway_token,
    )

    if service_urls:
        summary += (
            "\n[cyan]Web Terminal:[/cyan]       {terminal}"
            "\n[cyan]File Manager:[/cyan]       {filemanager}"
        ).format(
            terminal=service_urls["terminal"],
            filemanager=service_urls["filemanager"],
        )

    if service_creds:
        summary += (
            "\n[cyan]Login User:[/cyan]      {username}"
            "\n[cyan]Login Password:[/cyan]  {password}"
            "\n[dim](credentials for Web Terminal & File Manager)[/dim]"
        ).format(
            username=service_creds["username"],
            password=service_creds["password"],
        )

    console.print(
        Panel(
            summary,
            title="[green]{brand} Sandbox Ready[/green]".format(brand=BRAND_NAME),
            border_style="green",
        )
    )

    _print_webui_url(urls["webui"])


def _fmt_state(sbx) -> str:
    """Format sandbox state as a plain string."""
    return str(sbx.state.value) if hasattr(sbx.state, "value") else str(sbx.state)


def _handle_cli_error(e: CLIError):
    """Handle a CLIError -- JSON output or Rich error + exit."""
    if is_json_mode():
        output_error(e.error_code, str(e), e.exit_code)
    else:
        print_error(str(e))
        raise SystemExit(e.exit_code)


# --- Version check helpers ---


def _parse_version(v: str):
    """Parse a version string into a comparable tuple."""
    return tuple(int(x) for x in v.strip().split("."))


def _fetch_latest_version():
    """Fetch latest version from PyPI. Returns version string or None."""
    try:
        url = "https://pypi.org/pypi/{}/json".format(PACKAGE_NAME)
        resp = urllib.request.urlopen(url, timeout=5)
        data = json.loads(resp.read())
        return data["info"]["version"]
    except Exception:
        return None


def _update_check_path():
    """Path to the update check cache file."""
    return os.path.join(os.path.expanduser("~"), CONFIG_DIR_NAME, "update_check")


def _should_check_update():
    """Return True if we haven't checked in the last 24 hours."""
    path = _update_check_path()
    try:
        mtime = os.path.getmtime(path)
        return (time.time() - mtime) > 86400
    except OSError:
        return True


def _save_check_timestamp():
    """Touch the update check cache file."""
    path = _update_check_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write("")


_update_hint = None


def _background_version_check():
    """Check PyPI for a newer version (runs in a background thread)."""
    global _update_hint
    if not _should_check_update():
        return
    latest = _fetch_latest_version()
    if latest is None:
        return
    _save_check_timestamp()
    from . import __version__

    try:
        if _parse_version(latest) > _parse_version(__version__):
            _update_hint = (
                "\n\u2728 {brand} v{latest} is available (current: v{current}). "
                "Run `{cli} update` to upgrade."
            ).format(brand=BRAND_NAME, latest=latest, current=__version__, cli=CLI_NAME)
    except (ValueError, TypeError):
        pass


def _print_update_hint():
    """Print the update hint at exit if one was found."""
    if _update_hint:
        click.echo(_update_hint, err=True)


# --- CLI ---


@click.group()
@click.version_option(package_name=PACKAGE_NAME)
@click.option(
    "--json",
    "-j",
    "json_output",
    is_flag=True,
    help="Output as JSON (for programmatic use). AI agents should always enable this flag.",
)
@click.pass_context
def cli(ctx, json_output):
    set_json_mode(json_output)
    if not json_output and ctx.invoked_subcommand != "update":
        t = threading.Thread(target=_background_version_check, daemon=True)
        t.start()
        atexit.register(_print_update_hint)


def _json_option(f):
    """Add --json/-j to a subcommand, merging with the group-level flag."""

    @click.option("--json", "-j", "json_output", is_flag=True, hidden=True)
    @functools.wraps(f)
    def wrapper(*args, json_output=False, **kwargs):
        if json_output:
            set_json_mode(True)
        return f(*args, **kwargs)

    return wrapper


cli.help = "{brand} - One-click launch of OpenClaw on {provider} Agent Sandbox.".format(
    brand=BRAND_NAME,
    provider=PROVIDER_NAME,
)


@cli.command()
@click.option("--api-key", default=None, help=_API_KEY_HELP + " (also used for OpenClaw LLM)")
@click.option("--timeout", default=60, help="Sandbox creation timeout in seconds")
@_json_option
@require_api_key
def launch(api_key, timeout):
    """Launch a new OpenClaw sandbox environment."""
    try:
        c = get_console()

        # Step 1: Create sandbox
        with c.status("[bold blue]Creating sandbox..."):
            manager = SandboxManager(TEMPLATE_ID, api_key=api_key)
            sandbox = manager.create(timeout=timeout)

        # Step 2: Extend sandbox lifetime (7 days)
        with c.status("[bold blue]Setting sandbox keep-alive..."):
            sandbox.set_timeout(SANDBOX_KEEP_ALIVE)

        # Step 3: Configure OpenClaw (writes config, stops old gateway)
        with c.status("[bold blue]Configuring OpenClaw..."):
            configure_openclaw(manager, api_key)

        # Step 4: Launch Gateway + services concurrently
        # Gateway is started first (non-blocking nohup), then services are
        # configured while the Gateway is booting.  wait_for_gateway() at the
        # end ensures it is ready before we fetch URLs.
        launch_gateway(manager)
        with c.status("[bold blue]Configuring services (terminal, file manager)..."):
            service_creds = configure_services(manager)
        with c.status("[bold blue]Waiting for OpenClaw Gateway..."):
            wait_for_gateway(manager)

        # Step 5: Get public URLs and token
        with c.status("[bold blue]Fetching public URLs..."):
            urls = get_public_urls(manager)
            gw_token = get_gateway_token(manager)
            service_urls = get_service_urls(manager)

        webui_url = _build_webui_url(urls, gw_token)

        if is_json_mode():
            result = {
                "sandbox_id": sandbox.sandbox_id,
                "keep_alive": SANDBOX_KEEP_ALIVE,
                "webui": webui_url,
                "gateway_ws": urls["gateway_ws"],
                "terminal_url": service_urls["terminal"],
                "filemanager_url": service_urls["filemanager"],
                "services_username": service_creds["username"],
                "services_password": service_creds["password"],
            }
            if gw_token:
                result["gateway_token"] = gw_token
            output_success(result)
        else:
            urls["webui"] = webui_url
            _print_sandbox_info(
                sandbox.sandbox_id,
                gw_token,
                urls,
                SANDBOX_KEEP_ALIVE,
                service_urls=service_urls,
                service_creds=service_creds,
            )

    except CLIError as e:
        _handle_cli_error(e)


@cli.command()
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@click.option("--yes", "-y", "skip_confirm", is_flag=True, help="Skip confirmation prompt")
@_json_option
@require_api_key
def stop(sandbox_id, api_key, skip_confirm):
    """Stop and terminate a sandbox."""
    try:
        if not skip_confirm and not is_json_mode():
            console.print(
                "\n[bold yellow]\u26a0  Warning:[/bold yellow] Stopping sandbox [cyan]{id}[/cyan] "
                "will permanently destroy all data and configurations.\n"
                "   This action [bold red]cannot be undone[/bold red].\n".format(id=sandbox_id)
            )
            if not click.confirm("Are you sure you want to stop this sandbox?"):
                print_info("Operation cancelled.")
                return

        manager = SandboxManager(api_key=api_key)
        manager.connect(sandbox_id)

        c = get_console()
        with c.status("[bold red]Stopping sandbox..."):
            manager.kill()

        if is_json_mode():
            output_success(
                {
                    "sandbox_id": sandbox_id,
                    "message": "Sandbox terminated",
                }
            )

    except CLIError as e:
        _handle_cli_error(e)


@cli.command("list")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@click.option(
    "--quiet",
    "-q",
    is_flag=True,
    help="Only print sandbox IDs, one per line. Useful for scripting, piping, and easy copy-paste.",
)
@_json_option
@require_api_key
def list_sandboxes(api_key, quiet):
    """List all active sandboxes."""
    try:
        c = get_console()
        with c.status("[bold blue]Fetching sandboxes..."):
            sandboxes = SandboxManager.list_app_sandboxes(api_key=api_key)

        if is_json_mode():
            output_success(
                {
                    "sandboxes": [
                        {
                            "sandbox_id": sbx.sandbox_id,
                            "state": _fmt_state(sbx),
                            "cpu": sbx.cpu_count,
                            "memory_mb": sbx.memory_mb,
                            "started_at": sbx.started_at.isoformat(),
                        }
                        for sbx in sandboxes
                    ],
                }
            )
            return

        if not sandboxes:
            if not quiet:
                print_info("No {brand} sandboxes found.".format(brand=BRAND_NAME))
            return

        if quiet:
            for sbx in sandboxes:
                click.echo(sbx.sandbox_id)
            return

        table = Table(title="{brand} Sandboxes".format(brand=BRAND_NAME), expand=False)
        table.add_column("Sandbox ID", style="cyan", no_wrap=True)
        table.add_column("State", style="bold")
        table.add_column("CPU", justify="right")
        table.add_column("Memory (MB)", justify="right")
        table.add_column("Started At", style="yellow")

        for sbx in sandboxes:
            table.add_row(
                sbx.sandbox_id,
                _fmt_state(sbx),
                str(sbx.cpu_count),
                str(sbx.memory_mb),
                sbx.started_at.strftime("%Y-%m-%d %H:%M:%S"),
            )

        console.print(table)

    except CLIError as e:
        _handle_cli_error(e)


@cli.command()
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
def status(sandbox_id, api_key):
    """Check sandbox status and show access URLs."""
    try:
        manager = SandboxManager(api_key=api_key)
        manager.connect(sandbox_id)

        sandbox_status = manager.get_status()
        urls = get_public_urls(manager)
        gw_token = get_gateway_token(manager)
        service_creds = get_service_credentials(manager)
        # Only fetch service URLs when credentials exist (i.e. services were configured).
        # Old sandboxes without ttyd/gohttpserver won't have the credentials file.
        service_urls = get_service_urls(manager) if service_creds else {}

        webui_url = _build_webui_url(urls, gw_token)

        if is_json_mode():
            result = {
                "sandbox_id": sandbox_id,
                "state": sandbox_status,
                "webui": webui_url,
                "gateway_ws": urls["gateway_ws"],
            }
            if gw_token:
                result["gateway_token"] = gw_token
            if service_urls:
                result["terminal_url"] = service_urls["terminal"]
                result["filemanager_url"] = service_urls["filemanager"]
            if service_creds:
                result["services_username"] = service_creds["username"]
                result["services_password"] = service_creds["password"]
            output_success(result)
            return

        summary = (
            "[cyan]Sandbox ID:[/cyan]     {sandbox_id}\n"
            "[cyan]Status:[/cyan]         {status}\n"
            "[cyan]Gateway WS:[/cyan]     {gateway_ws}\n"
            "[cyan]Gateway Token:[/cyan]  {gateway_token}"
        ).format(
            sandbox_id=sandbox_id,
            status=sandbox_status,
            gateway_ws=urls["gateway_ws"],
            gateway_token=gw_token or "(not found)",
        )
        if service_urls:
            summary += (
                "\n[cyan]Web Terminal:[/cyan]   {terminal}"
                "\n[cyan]File Manager:[/cyan]   {filemanager}"
            ).format(
                terminal=service_urls["terminal"],
                filemanager=service_urls["filemanager"],
            )
        if service_creds:
            summary += (
                "\n[cyan]Login User:[/cyan]  {username}\n[cyan]Login Password:[/cyan]  {password}"
                "\n[dim](credentials for Web Terminal & File Manager)[/dim]"
            ).format(
                username=service_creds["username"],
                password=service_creds["password"],
            )
        console.print(Panel(summary, title="Status", border_style="blue"))
        _print_webui_url(webui_url)

    except CLIError as e:
        _handle_cli_error(e)


@cli.command()
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@click.option("--deep", is_flag=True, help="Scan system services for extra gateway installs")
@click.option("--fix", is_flag=True, help="Apply recommended repairs (alias for --repair)")
@click.option(
    "--force",
    is_flag=True,
    help="Apply aggressive repairs (overwrites custom service config)",
)
@click.option(
    "--generate-gateway-token",
    is_flag=True,
    help="Generate and configure a gateway token",
)
@click.option(
    "--no-workspace-suggestions",
    is_flag=True,
    help="Disable workspace memory system suggestions",
)
@click.option("--repair", is_flag=True, help="Apply recommended repairs without prompting")
@click.option("--yes", "yes_flag", is_flag=True, help="Accept defaults without prompting")
@_json_option
@require_api_key
def doctor(
    sandbox_id,
    api_key,
    deep,
    fix,
    force,
    generate_gateway_token,
    no_workspace_suggestions,
    repair,
    yes_flag,
):
    """Run OpenClaw doctor inside a sandbox to diagnose and repair issues.

    Checks configuration integrity, file permissions, gateway health,
    plugin/skill status, and memory search setup. Use --fix or --repair
    to auto-apply recommended fixes; add --force for aggressive repairs.

    Always runs with --non-interactive (sandbox has no TTY).
    See https://docs.openclaw.ai/gateway/doctor for details.
    """
    try:
        manager = SandboxManager(api_key=api_key)
        manager.connect(sandbox_id)

        # Build command — always non-interactive (no TTY in sandbox)
        cmd_parts = [
            "OPENCLAW_CONFIG_PATH={config}".format(config=OPENCLAW_CONFIG_PATH),
            "openclaw",
            "doctor",
            "--non-interactive",
        ]
        flags = {
            "--deep": deep,
            "--fix": fix,
            "--force": force,
            "--generate-gateway-token": generate_gateway_token,
            "--no-workspace-suggestions": no_workspace_suggestions,
            "--repair": repair,
            "--yes": yes_flag,
        }
        cmd_parts.extend(flag for flag, enabled in flags.items() if enabled)

        cmd = " ".join(cmd_parts) + " 2>&1"

        c = get_console()
        with c.status("[bold blue]Running OpenClaw doctor..."):
            result = manager.run_command(cmd, timeout=120)

        if result is None:
            raise DoctorError(
                "Doctor command failed to execute in sandbox. "
                "Check sandbox connectivity and that openclaw is installed."
            )

        output_text = ""
        if result.stdout:
            output_text = result.stdout.strip()

        if is_json_mode():
            output_success(
                {
                    "sandbox_id": sandbox_id,
                    "output": output_text,
                }
            )
            return

        if output_text:
            console.print(output_text, highlight=False)
        else:
            print_info("No output from doctor command.")

    except CLIError as e:
        _handle_cli_error(e)


@cli.group()
def pair():
    """Manage channel pairing (Telegram, Discord, etc.)."""


def _run_pairing_cmd(manager, raw_cmd, spinner_text):
    """Run an openclaw pairing command in the sandbox.

    Wraps the command so it always exits 0 — the SDK throws on non-zero
    exit codes, but we need stdout/stderr even when the pairing code is
    invalid or no requests are pending.
    """
    cmd = "OPENCLAW_CONFIG_PATH={config} {raw}; true".format(
        config=OPENCLAW_CONFIG_PATH,
        raw=raw_cmd,
    )
    c = get_console()
    with c.status(spinner_text):
        result = manager.run_command(cmd, timeout=30)

    if result is None:
        raise PairingError(
            "Pairing command failed to execute. "
            "Check sandbox connectivity and that openclaw is installed."
        )

    return result.stdout.strip() if result.stdout else ""


@pair.command("list")
@click.argument("sandbox_id")
@click.option(
    "--channel",
    required=True,
    help="Channel name (telegram, discord, whatsapp, signal, slack, etc.)",
)
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
def pair_list(sandbox_id, channel, api_key):
    """List pending pairing requests for a channel."""
    try:
        manager = SandboxManager(api_key=api_key)
        manager.connect(sandbox_id)

        output_text = _run_pairing_cmd(
            manager,
            "openclaw pairing list {channel} 2>&1".format(channel=channel),
            "[bold blue]Fetching pairing requests...",
        )

        if is_json_mode():
            output_success(
                {
                    "sandbox_id": sandbox_id,
                    "channel": channel,
                    "output": output_text,
                }
            )
            return

        if output_text:
            console.print(output_text, highlight=False)
        else:
            print_info("No pending pairing requests for {channel}.".format(channel=channel))

    except CLIError as e:
        _handle_cli_error(e)


@pair.command("approve")
@click.argument("sandbox_id")
@click.option(
    "--channel",
    required=True,
    help="Channel name (telegram, discord, whatsapp, signal, slack, etc.)",
)
@click.option("--code", required=True, help="Pairing code to approve")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
def pair_approve(sandbox_id, channel, code, api_key):
    """Approve a pending pairing request for a channel."""
    try:
        manager = SandboxManager(api_key=api_key)
        manager.connect(sandbox_id)

        output_text = _run_pairing_cmd(
            manager,
            "openclaw pairing approve {channel} {code} 2>&1".format(channel=channel, code=code),
            "[bold blue]Approving pairing request...",
        )

        if is_json_mode():
            output_success(
                {
                    "sandbox_id": sandbox_id,
                    "channel": channel,
                    "code": code,
                    "output": output_text,
                }
            )
            return

        if output_text:
            console.print(output_text, highlight=False)
        else:
            print_success("Pairing request approved for {channel}.".format(channel=channel))

    except CLIError as e:
        _handle_cli_error(e)


@cli.group()
def gateway():
    """Manage OpenClaw Gateway (update, restart)."""


@gateway.command("update")
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@click.option("--restart", "do_restart", is_flag=True, help="Restart gateway after update")
@_json_option
@require_api_key
def gateway_update(sandbox_id, api_key, do_restart):
    """Update OpenClaw to the latest version in a sandbox."""
    try:
        manager = SandboxManager(api_key=api_key)
        manager.connect(sandbox_id)

        c = get_console()
        with c.status("[bold blue]Updating OpenClaw..."):
            output_text = update_openclaw(manager)

        urls = get_public_urls(manager)
        gw_token = get_gateway_token(manager)
        webui_url = _build_webui_url(urls, gw_token)

        if is_json_mode():
            result = {
                "sandbox_id": sandbox_id,
                "output": output_text,
                "restarted": True,
                "webui": webui_url,
                "gateway_ws": urls["gateway_ws"],
            }
            if gw_token:
                result["gateway_token"] = gw_token
            output_success(result)
            return

        if output_text:
            console.print(output_text, highlight=False)
        print_success("OpenClaw updated and gateway restarted.")
        _print_gateway_info(webui_url, urls, gw_token)

    except CLIError as e:
        _handle_cli_error(e)


@gateway.command("restart")
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
def gateway_restart(sandbox_id, api_key):
    """Restart the OpenClaw Gateway in a sandbox."""
    try:
        manager = SandboxManager(api_key=api_key)
        manager.connect(sandbox_id)

        c = get_console()
        with c.status("[bold blue]Restarting gateway..."):
            restart_gateway(manager)

        urls = get_public_urls(manager)
        gw_token = get_gateway_token(manager)

        webui_url = _build_webui_url(urls, gw_token)

        if is_json_mode():
            result = {
                "sandbox_id": sandbox_id,
                "message": "Gateway restarted",
                "webui": webui_url,
                "gateway_ws": urls["gateway_ws"],
            }
            if gw_token:
                result["gateway_token"] = gw_token
            output_success(result)
            return

        print_success("Gateway restarted successfully.")
        _print_gateway_info(webui_url, urls, gw_token)

    except CLIError as e:
        _handle_cli_error(e)


# --- Services commands ---


@cli.group()
def services():
    """Manage Web Terminal and File Manager services in a sandbox."""
    pass


@services.command("setup")
@click.argument("sandbox_id")
@click.option("--api-key", default=None, help=_API_KEY_HELP)
@_json_option
@require_api_key
def services_setup(sandbox_id, api_key):
    """Install and start Web Terminal + File Manager on an existing sandbox.

    Use this to add services to older sandboxes that were launched before
    ttyd and gohttpserver were included in the template.
    """
    try:
        manager = SandboxManager(api_key=api_key)
        manager.connect(sandbox_id)

        # If services are already configured, just show existing info
        existing_creds = get_service_credentials(manager)
        if existing_creds:
            service_urls = get_service_urls(manager)
            if is_json_mode():
                output_success(
                    _service_result(
                        sandbox_id, service_urls, existing_creds, already_configured=True
                    )
                )
                return
            print_info("Services already configured on this sandbox.")
            _print_service_info(service_urls, existing_creds)
            return

        c = get_console()
        with c.status("[bold blue]Installing services..."):
            install_services(manager)

        with c.status("[bold blue]Configuring services..."):
            service_creds = configure_services(manager)

        service_urls = get_service_urls(manager)

        if is_json_mode():
            output_success(_service_result(sandbox_id, service_urls, service_creds))
            return

        print_success("Services configured successfully.")
        _print_service_info(service_urls, service_creds)

    except CLIError as e:
        _handle_cli_error(e)


@cli.command()
@_json_option
def update():
    """Check for updates and upgrade to the latest version."""
    try:
        from . import __version__

        current = __version__

        c = get_console()
        with c.status("[bold blue]Checking for updates..."):
            latest = _fetch_latest_version()

        if latest is None:
            raise UpdateError("Failed to check for updates. Please check your network connection.")

        if _parse_version(latest) <= _parse_version(current):
            if is_json_mode():
                output_success(
                    {
                        "current": current,
                        "latest": latest,
                        "updated": False,
                        "message": "Already up to date.",
                    }
                )
            else:
                print_success(
                    "{brand} [cyan]v{ver}[/cyan] is already the latest version.".format(
                        brand=BRAND_NAME,
                        ver=current,
                    ),
                    highlight=False,
                )
            return

        if not is_json_mode():
            print_info(
                "New version available: [cyan]v{current}[/cyan] -> [cyan]v{latest}[/cyan]".format(
                    current=current,
                    latest=latest,
                ),
                highlight=False,
            )

        with c.status("[bold blue]Upgrading {brand}...".format(brand=BRAND_NAME)):
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-U", PACKAGE_NAME],
                capture_output=True,
                text=True,
            )

        if result.returncode != 0:
            raise UpdateError(
                "pip install failed: {err}".format(
                    err=result.stderr.strip() or result.stdout.strip(),
                )
            )

        _save_check_timestamp()

        if is_json_mode():
            output_success(
                {
                    "current": current,
                    "latest": latest,
                    "updated": True,
                    "message": "Updated to v{}.".format(latest),
                }
            )
        else:
            print_success(
                "Updated {brand} from [cyan]v{old}[/cyan] to [cyan]v{new}[/cyan].".format(
                    brand=BRAND_NAME,
                    old=current,
                    new=latest,
                ),
                highlight=False,
            )

    except CLIError as e:
        _handle_cli_error(e)


if __name__ == "__main__":
    cli()
