"""Brand constants for PPClaw CLI (PPIO variant).

This is the ONLY file that differs between brand variants.
All other source files import from here instead of hardcoding brand strings.
"""

import os

# --- Display names ---
BRAND_NAME = "PPClaw"  # Panel titles, table headers
PROVIDER_NAME = "PPIO"  # Help text, error messages
CLI_NAME = "ppclaw"  # CLI command name
PACKAGE_NAME = "PPClaw"  # PyPI distribution name (for version lookup)
CONFIG_DIR_NAME = ".ppclaw-cli"  # ~/.ppclaw-cli/

# --- Environment / config ---
ENV_VAR_API_KEY = "PPIO_API_KEY"  # Environment variable name
CONFIG_SECTION = "ppio"  # YAML config section name
API_KEY_URL = "https://ppio.com/docs/support/api-key"

# --- Sandbox ---
TEMPLATE_ID = os.environ.get("PPCLAW_TEMPLATE_ID", "ppclaw")
SANDBOX_APP_LABEL = "ppclaw"  # metadata.app value
SDK_PACKAGE = "ppio_sandbox"  # SDK package name

# --- OpenClaw config ---
API_KEY_PLACEHOLDER = "PPIO_API_KEY"  # Placeholder in openclaw.example.json
OPENCLAW_CONFIG_URL = (
    "https://raw.githubusercontent.com/PPIO/ppclaw-config/main/openclaw.example.json"
)

# --- Sandbox services ---
TTYD_PORT = 7681  # Web Terminal (ttyd) port
FILE_MANAGER_PORT = 7682  # File Manager (gohttpserver) port
SERVICES_USERNAME = "admin"  # Default username for ttyd & gohttpserver
