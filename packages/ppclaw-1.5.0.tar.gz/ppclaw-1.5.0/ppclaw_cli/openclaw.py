"""OpenClaw configuration and service management."""

import json
import os
import time
import urllib.request

from .const import API_KEY_PLACEHOLDER, OPENCLAW_CONFIG_URL
from .output import GatewayTimeoutError, GatewayUpdateError
from .sandbox import SandboxManager
from .utils import print_error, print_info, print_success

GATEWAY_PORT = 18789
OPENCLAW_CONFIG_PATH = "/home/user/.openclaw/openclaw.json"
# Legacy path — older versions wrote config here; checked as fallback for reads.
_LEGACY_CONFIG_PATH = "/home/user/.openclaw/config.json"


def load_openclaw_config_template() -> dict:
    """Fetch the latest OpenClaw config template from remote, with local fallback."""
    try:
        resp = urllib.request.urlopen(OPENCLAW_CONFIG_URL, timeout=10)
        return json.loads(resp.read())
    except Exception:
        print_info("Could not fetch remote config, using local template.")
        example_path = os.path.join(os.path.dirname(__file__), "openclaw.example.json")
        with open(example_path) as f:
            return json.load(f)


def generate_openclaw_config(api_key: str) -> dict:
    """Generate OpenClaw configuration by injecting API key."""
    config = load_openclaw_config_template()

    # Replace placeholder API key in all providers
    for provider in config.get("models", {}).get("providers", {}).values():
        if provider.get("apiKey") == API_KEY_PLACEHOLDER:
            provider["apiKey"] = api_key

    # Set gateway config for remote sandbox access
    config.setdefault("gateway", {})
    config["gateway"]["mode"] = "local"
    # Allow host-header origin fallback and disable device pairing for remote sandbox access
    config["gateway"]["controlUi"] = {
        "dangerouslyAllowHostHeaderOriginFallback": True,
        "dangerouslyDisableDeviceAuth": True,
    }

    return config


def configure_openclaw(manager: SandboxManager, api_key: str):
    """Write OpenClaw configuration to the sandbox."""
    config = generate_openclaw_config(api_key)
    config_content = json.dumps(config, indent=2)

    # Ensure config directory exists with secure permissions (700 = owner only).
    # The sandbox base image may use umask 0000, so explicit chmod is required
    # to prevent OpenClaw's security audit from flagging world-writable paths
    # and refusing to load channel plugins (Telegram, Discord, etc.).
    manager.run_command(
        "mkdir -p /home/user/.openclaw && chmod 700 /home/user/.openclaw",
        timeout=10,
    )

    print_info("Writing OpenClaw configuration to sandbox...")
    manager.write_file(OPENCLAW_CONFIG_PATH, config_content)
    manager.run_command("chmod 600 {config}".format(config=OPENCLAW_CONFIG_PATH), timeout=10)
    print_success("OpenClaw configuration written")

    # Export OPENCLAW_CONFIG_PATH globally so all openclaw CLI commands
    # (pairing, doctor, status, etc.) find the config without manual flags.
    _export_env = (
        "grep -q OPENCLAW_CONFIG_PATH /home/user/.bashrc 2>/dev/null"
        " || echo 'export OPENCLAW_CONFIG_PATH=\"{config}\"' >> /home/user/.bashrc"
    ).format(config=OPENCLAW_CONFIG_PATH)
    manager.run_command(_export_env, timeout=10)

    _fix_extensions_permissions(manager)

    # Stop any gateway the daemon may have auto-started before we wrote our config
    stop_gateway(manager)


def launch_gateway(manager: SandboxManager):
    """Start the OpenClaw Gateway process in the background (non-blocking).

    The caller must ensure no other gateway is running (via stop_gateway)
    before calling this, and should call wait_for_gateway() afterwards.
    """
    print_info("Starting OpenClaw Gateway...")
    manager.run_command(
        "nohup bash -c 'OPENCLAW_CONFIG_PATH={config} openclaw gateway run"
        " --port {port} --bind lan'"
        " > /tmp/gateway.log 2>&1 &".format(config=OPENCLAW_CONFIG_PATH, port=GATEWAY_PORT),
        timeout=10,
    )


def start_gateway(manager: SandboxManager):
    """Start the OpenClaw Gateway and wait for it to become ready.

    Convenience wrapper around launch_gateway + wait_for_gateway.
    """
    launch_gateway(manager)
    wait_for_gateway(manager)


def wait_for_gateway(manager: SandboxManager, max_checks: int = 120):
    """Poll until the Gateway is listening, or raise GatewayTimeoutError."""
    for i in range(max_checks):
        result = manager.run_command(
            'curl -s --max-time 2 -o /dev/null -w "%{{http_code}}"'
            " http://localhost:{port}/ 2>/dev/null; echo".format(port=GATEWAY_PORT),
            timeout=10,
        )
        if result and result.stdout and result.stdout.strip() == "200":
            print_success("OpenClaw Gateway is listening on port {port}".format(port=GATEWAY_PORT))
            return
        print_info(
            "  Waiting for Gateway to start ({i}/{total})...".format(
                i=i + 1,
                total=max_checks,
            )
        )
        time.sleep(1)

    log_result = manager.run_command("tail -30 /tmp/gateway.log 2>&1 || true", timeout=5)
    log_text = ""
    if log_result and log_result.stdout and log_result.stdout.strip():
        log_text = log_result.stdout.strip()
        print_error("Gateway log:\n{log}".format(log=log_text))
    raise GatewayTimeoutError(
        "Gateway did not start in time. Check sandbox logs." + (f"\n{log_text}" if log_text else "")
    )


def stop_gateway(manager: SandboxManager):
    """Stop the running OpenClaw Gateway and its supervisor daemon.

    1. ``openclaw daemon stop`` — stops the supervisor so it won't respawn.
    2. ``openclaw gateway stop`` — graceful gateway shutdown.
    3. ``pkill -9`` fallback — kills any stragglers that ignore graceful stop.
    """
    print_info("Stopping OpenClaw Gateway...")
    _env = "OPENCLAW_CONFIG_PATH={config}".format(config=OPENCLAW_CONFIG_PATH)
    manager.run_command(
        "{env} openclaw daemon stop 2>/dev/null || true".format(env=_env),
        timeout=15,
        silent=True,
    )
    manager.run_command(
        "{env} openclaw gateway stop 2>/dev/null || true".format(env=_env),
        timeout=15,
        silent=True,
    )
    # Force-kill anything that survived graceful shutdown.
    # Use pkill -f (match full command line) because the kernel truncates
    # process names to 15 chars ("openclaw-gatewa"), breaking -x exact match.
    manager.run_command(
        "pkill -9 -f 'openclaw' 2>/dev/null || true",
        timeout=10,
        silent=True,
    )
    time.sleep(2)
    print_success("OpenClaw Gateway stopped")


def restart_gateway(manager: SandboxManager):
    """Stop and restart the OpenClaw Gateway."""
    stop_gateway(manager)
    start_gateway(manager)


def update_openclaw(manager: SandboxManager) -> str:
    """Update OpenClaw to the latest version and restart the gateway.

    Uses ``openclaw update --yes --no-restart`` which handles package-manager
    detection, version resolution, and post-install hooks automatically.
    We pass ``--no-restart`` because we manage the gateway lifecycle ourselves
    (the sandbox doesn't use launchd/systemd).

    Returns the command output. Raises GatewayUpdateError on failure.
    """
    _env = "OPENCLAW_CONFIG_PATH={config}".format(config=OPENCLAW_CONFIG_PATH)
    print_info("Updating OpenClaw...")
    result = manager.run_command(
        "{env} openclaw update --yes --no-restart 2>&1".format(env=_env),
        timeout=600,
    )
    if result is None:
        raise GatewayUpdateError("Failed to run openclaw update. Check sandbox connectivity.")
    output_text = result.stdout.strip() if result.stdout else ""
    print_success("OpenClaw updated")

    _fix_extensions_permissions(manager)
    restart_gateway(manager)

    return output_text


def _fix_extensions_permissions(manager: SandboxManager):
    """Fix world-writable extensions directory after install/update.

    The sandbox template uses broad write permissions on node_modules so the
    runtime user can run npm install -g.  This leaves extensions/ at mode 777,
    which causes OpenClaw to block plugin loading for security.
    """
    print_info("Fixing OpenClaw extensions permissions...")
    fix_cmd = (
        "EXT=/usr/local/lib/node_modules/openclaw/extensions"
        ' && if [ -d "$EXT" ]; then'
        '   cp -r "$EXT" /tmp/_oc_ext_fix'
        '   && rm -rf "$EXT"'
        '   && mv /tmp/_oc_ext_fix "$EXT"'
        '   && find "$EXT" -type d -exec chmod 755 {} +'
        '   && find "$EXT" -type f -exec chmod 644 {} +'
        "   && echo ok; fi"
    )
    fix_result = manager.run_command(fix_cmd, timeout=30)
    if fix_result and fix_result.stdout and "ok" in fix_result.stdout:
        print_success("OpenClaw extensions permissions fixed")
    else:
        print_info("Extensions directory not found or already fixed")


def _read_config(manager: SandboxManager) -> str:
    """Read OpenClaw config from sandbox, falling back to the legacy path.

    The legacy fallback is only relevant on pre-existing sandboxes that were
    never reconfigured (configure_openclaw deletes the legacy file).
    """
    try:
        content = manager.read_file(OPENCLAW_CONFIG_PATH)
        if content:
            return content
    except Exception:
        pass
    try:
        content = manager.read_file(_LEGACY_CONFIG_PATH)
        if content:
            return content
    except Exception:
        pass
    return ""


def get_gateway_token(manager: SandboxManager) -> str:
    """Read the gateway token from the sandbox's OpenClaw config."""
    content = _read_config(manager)
    if content:
        try:
            config = json.loads(content)
            return config.get("gateway", {}).get("auth", {}).get("token", "")
        except (json.JSONDecodeError, AttributeError):
            pass
    return ""


def get_public_urls(manager: SandboxManager) -> dict:
    """Get public access URLs for Gateway and Web UI."""
    host = manager.sandbox.get_host(GATEWAY_PORT)
    return {
        "gateway_ws": "wss://{host}".format(host=host),
        "webui": "https://{host}".format(host=host),
    }
