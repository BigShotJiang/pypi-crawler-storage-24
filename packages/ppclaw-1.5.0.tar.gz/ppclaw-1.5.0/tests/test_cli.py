"""Tests for cli.py — CLI structure, help output, JSON error paths."""

import json

import pytest
from click.testing import CliRunner

from ppclaw_cli.cli import cli
from ppclaw_cli.output import set_json_mode


@pytest.fixture(autouse=True)
def _clean_json_mode():
    """Reset JSON mode after each test to avoid cross-test pollution."""
    yield
    set_json_mode(False)


@pytest.fixture()
def runner():
    return CliRunner()


@pytest.fixture(autouse=True)
def _no_api_key(monkeypatch):
    """Ensure PPIO_API_KEY is not set during tests."""
    monkeypatch.delenv("PPIO_API_KEY", raising=False)


class TestVersion:
    def test_outputs_version_string(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "version" in result.output.lower()


class TestHelp:
    def test_main_help(self, runner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "PPClaw" in result.output

    def test_json_flag_shown(self, runner):
        result = runner.invoke(cli, ["--help"])
        assert "--json" in result.output

    SUBCOMMANDS = ["launch", "list", "status", "stop", "doctor", "update"]

    @pytest.mark.parametrize("cmd", SUBCOMMANDS)
    def test_subcommand_help(self, runner, cmd):
        result = runner.invoke(cli, [cmd, "--help"])
        assert result.exit_code == 0
        assert "Usage:" in result.output or "usage:" in result.output.lower()

    def test_gateway_group_help(self, runner):
        result = runner.invoke(cli, ["gateway", "--help"])
        assert result.exit_code == 0
        assert "update" in result.output
        assert "restart" in result.output

    def test_pair_group_help(self, runner):
        result = runner.invoke(cli, ["pair", "--help"])
        assert result.exit_code == 0
        assert "list" in result.output
        assert "approve" in result.output


class TestApiKeyGuard:
    """Commands that require API key should return MISSING_API_KEY in JSON mode."""

    GUARDED_COMMANDS = [
        ["--json", "launch"],
        ["--json", "list"],
        ["--json", "status", "fake-id"],
        ["--json", "stop", "fake-id"],
        ["--json", "doctor", "fake-id"],
    ]

    @pytest.mark.parametrize("args", GUARDED_COMMANDS)
    def test_missing_api_key_json(self, runner, args):
        result = runner.invoke(cli, args)
        assert result.exit_code == 10
        data = json.loads(result.output)
        assert data["status"] == "error"
        assert data["error_code"] == "MISSING_API_KEY"
