"""Tests for services.py — password generation pure functions."""

import re

from ppclaw_cli.services import generate_password

URL_SAFE_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")


class TestGeneratePassword:
    def test_returns_string(self):
        assert isinstance(generate_password(), str)

    def test_default_length_at_least_16_chars(self):
        pw = generate_password()
        assert len(pw) >= 16

    def test_url_safe_characters(self):
        for _ in range(20):
            pw = generate_password()
            assert URL_SAFE_PATTERN.match(pw), f"Not URL-safe: {pw}"

    def test_uniqueness(self):
        passwords = {generate_password() for _ in range(50)}
        assert len(passwords) == 50

    def test_custom_length(self):
        short = generate_password(length=8)
        long = generate_password(length=32)
        assert len(short) < len(long)
