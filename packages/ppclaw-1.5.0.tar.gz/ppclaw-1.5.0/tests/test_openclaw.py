"""Tests for openclaw.py — config generation logic (network mocked)."""

from unittest.mock import patch

from ppclaw_cli.openclaw import generate_openclaw_config


def _mock_load_template():
    """Return a minimal config template matching openclaw.example.json structure."""
    return {
        "models": {
            "mode": "replace",
            "providers": {
                "ppio": {
                    "baseUrl": "https://api.ppio.com/anthropic",
                    "apiKey": "PPIO_API_KEY",
                    "api": "anthropic-messages",
                    "models": [],
                },
            },
        },
        "agents": {"defaults": {"model": {"primary": "ppio/test-model"}}},
    }


@patch("ppclaw_cli.openclaw.load_openclaw_config_template", side_effect=_mock_load_template)
class TestGenerateOpenclawConfig:
    def test_replaces_api_key_placeholder(self, _mock):
        config = generate_openclaw_config("sk_real_key_123")
        provider = config["models"]["providers"]["ppio"]
        assert provider["apiKey"] == "sk_real_key_123"

    def test_does_not_replace_non_placeholder_keys(self, _mock):
        template = _mock_load_template()
        template["models"]["providers"]["other"] = {
            "apiKey": "already_set",
        }
        with patch("ppclaw_cli.openclaw.load_openclaw_config_template", return_value=template):
            config = generate_openclaw_config("sk_new")
        assert config["models"]["providers"]["other"]["apiKey"] == "already_set"

    def test_gateway_mode_local(self, _mock):
        config = generate_openclaw_config("sk_test")
        assert config["gateway"]["mode"] == "local"

    def test_control_ui_security_flags(self, _mock):
        config = generate_openclaw_config("sk_test")
        ui = config["gateway"]["controlUi"]
        assert ui["dangerouslyAllowHostHeaderOriginFallback"] is True
        assert ui["dangerouslyDisableDeviceAuth"] is True

    def test_preserves_other_fields(self, _mock):
        config = generate_openclaw_config("sk_test")
        assert config["agents"]["defaults"]["model"]["primary"] == "ppio/test-model"
