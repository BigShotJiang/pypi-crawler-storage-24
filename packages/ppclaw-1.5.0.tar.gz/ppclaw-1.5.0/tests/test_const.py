"""Tests for const.py — brand constants completeness and validity."""

from ppclaw_cli import const


class TestBrandConstants:
    def test_brand_name_nonempty(self):
        assert const.BRAND_NAME

    def test_provider_name_nonempty(self):
        assert const.PROVIDER_NAME

    def test_cli_name_nonempty(self):
        assert const.CLI_NAME

    def test_package_name_nonempty(self):
        assert const.PACKAGE_NAME

    def test_config_dir_name_nonempty(self):
        assert const.CONFIG_DIR_NAME

    def test_env_var_api_key_nonempty(self):
        assert const.ENV_VAR_API_KEY

    def test_template_id_nonempty(self):
        assert const.TEMPLATE_ID


class TestPortConstants:
    def test_ttyd_port_valid(self):
        assert 1024 < const.TTYD_PORT < 65536

    def test_file_manager_port_valid(self):
        assert 1024 < const.FILE_MANAGER_PORT < 65536

    def test_ports_are_different(self):
        assert const.TTYD_PORT != const.FILE_MANAGER_PORT

    def test_services_username_nonempty(self):
        assert const.SERVICES_USERNAME
