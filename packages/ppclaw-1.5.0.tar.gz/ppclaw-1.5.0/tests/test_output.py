"""Tests for output.py — exit codes, CLIError hierarchy, JSON helpers, json_mode state."""

import json

import pytest

from ppclaw_cli.output import (
    EXIT_API_ERROR,
    EXIT_DOCTOR_FAILED,
    EXIT_GATEWAY_FAILED,
    EXIT_GATEWAY_TIMEOUT,
    EXIT_GATEWAY_UPDATE_FAILED,
    EXIT_MISSING_API_KEY,
    EXIT_OK,
    EXIT_PAIRING_FAILED,
    EXIT_SANDBOX_CONNECT,
    EXIT_SANDBOX_CREATE,
    EXIT_SANDBOX_TIMEOUT,
    EXIT_SERVICE_CONFIG_FAILED,
    EXIT_UNKNOWN,
    EXIT_UPDATE_FAILED,
    CLIError,
    DoctorError,
    GatewayError,
    GatewayTimeoutError,
    GatewayUpdateError,
    MissingApiKeyError,
    PairingError,
    SandboxConnectError,
    SandboxCreateError,
    ServiceConfigError,
    UpdateError,
    is_json_mode,
    output_error,
    output_success,
    set_json_mode,
)

ALL_EXIT_CODES = [
    EXIT_OK,
    EXIT_UNKNOWN,
    EXIT_MISSING_API_KEY,
    EXIT_SANDBOX_CREATE,
    EXIT_SANDBOX_CONNECT,
    EXIT_SANDBOX_TIMEOUT,
    EXIT_GATEWAY_TIMEOUT,
    EXIT_GATEWAY_FAILED,
    EXIT_GATEWAY_UPDATE_FAILED,
    EXIT_API_ERROR,
    EXIT_SERVICE_CONFIG_FAILED,
    EXIT_DOCTOR_FAILED,
    EXIT_PAIRING_FAILED,
    EXIT_UPDATE_FAILED,
]


class TestExitCodes:
    def test_all_unique(self):
        assert len(ALL_EXIT_CODES) == len(set(ALL_EXIT_CODES))

    def test_all_non_negative(self):
        for code in ALL_EXIT_CODES:
            assert code >= 0

    def test_success_is_zero(self):
        assert EXIT_OK == 0

    def test_unknown_is_one(self):
        assert EXIT_UNKNOWN == 1


ERROR_CLASSES = [
    (MissingApiKeyError, "MISSING_API_KEY", EXIT_MISSING_API_KEY),
    (SandboxCreateError, "SANDBOX_CREATE_FAILED", EXIT_SANDBOX_CREATE),
    (SandboxConnectError, "SANDBOX_CONNECT_FAILED", EXIT_SANDBOX_CONNECT),
    (GatewayTimeoutError, "GATEWAY_TIMEOUT", EXIT_GATEWAY_TIMEOUT),
    (GatewayError, "GATEWAY_FAILED", EXIT_GATEWAY_FAILED),
    (GatewayUpdateError, "GATEWAY_UPDATE_FAILED", EXIT_GATEWAY_UPDATE_FAILED),
    (DoctorError, "DOCTOR_FAILED", EXIT_DOCTOR_FAILED),
    (PairingError, "PAIRING_FAILED", EXIT_PAIRING_FAILED),
    (ServiceConfigError, "SERVICE_CONFIG_FAILED", EXIT_SERVICE_CONFIG_FAILED),
    (UpdateError, "UPDATE_FAILED", EXIT_UPDATE_FAILED),
]


class TestCLIErrorHierarchy:
    @pytest.mark.parametrize("cls,expected_code,expected_exit", ERROR_CLASSES)
    def test_defaults(self, cls, expected_code, expected_exit):
        err = cls()
        assert isinstance(err, CLIError)
        assert err.error_code == expected_code
        assert err.exit_code == expected_exit
        assert str(err)  # has a non-empty default message

    @pytest.mark.parametrize("cls,expected_code,expected_exit", ERROR_CLASSES)
    def test_custom_message(self, cls, expected_code, expected_exit):
        err = cls("custom msg")
        assert str(err) == "custom msg"
        assert err.error_code == expected_code

    def test_error_codes_are_unique(self):
        codes = [code for _, code, _ in ERROR_CLASSES]
        assert len(codes) == len(set(codes))


class TestJsonMode:
    def setup_method(self):
        set_json_mode(False)

    def teardown_method(self):
        set_json_mode(False)

    def test_default_off(self):
        set_json_mode(False)
        assert is_json_mode() is False

    def test_toggle_on(self):
        set_json_mode(True)
        assert is_json_mode() is True

    def test_toggle_back(self):
        set_json_mode(True)
        set_json_mode(False)
        assert is_json_mode() is False


class TestOutputSuccess:
    def test_format(self, capsys):
        output_success({"sandbox_id": "abc123", "count": 1})
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["status"] == "ok"
        assert data["sandbox_id"] == "abc123"
        assert data["count"] == 1

    def test_empty_data(self, capsys):
        output_success({})
        data = json.loads(capsys.readouterr().out)
        assert data == {"status": "ok"}


class TestOutputError:
    def test_format_and_exit(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            output_error("TEST_ERROR", "something broke", 42)
        assert exc_info.value.code == 42
        data = json.loads(capsys.readouterr().out)
        assert data["status"] == "error"
        assert data["error_code"] == "TEST_ERROR"
        assert data["message"] == "something broke"

    def test_default_exit_code(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            output_error("X", "msg")
        assert exc_info.value.code == 1
