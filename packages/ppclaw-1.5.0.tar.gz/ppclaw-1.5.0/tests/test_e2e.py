"""End-to-end tests: full sandbox lifecycle via CLI (launch → list → status → stop).

Requires live PPIO API credentials. Skipped when PPIO_API_KEY is not set.
Run with: pytest -v -m e2e --timeout=300
"""

import json
import os

import pytest
from click.testing import CliRunner

from ppclaw_cli.cli import cli
from ppclaw_cli.output import set_json_mode

pytestmark = pytest.mark.e2e

_api_key = os.environ.get("PPIO_API_KEY", "")


def _needs_api_key():
    if not _api_key:
        pytest.skip("PPIO_API_KEY not set — skipping live E2E test")


@pytest.fixture(autouse=True)
def _clean_json_mode():
    yield
    set_json_mode(False)


@pytest.fixture(scope="module")
def runner():
    return CliRunner()


@pytest.fixture(scope="module")
def sandbox(runner):
    """Launch a sandbox and yield its info dict; always stop it on teardown."""
    _needs_api_key()

    result = runner.invoke(cli, ["--json", "launch", "--api-key", _api_key, "--timeout", "120"])
    assert result.exit_code == 0, "launch failed: {out}".format(out=result.output)

    data = json.loads(result.output)
    assert data["status"] == "ok", "launch returned error: {d}".format(d=data)
    assert "sandbox_id" in data

    sandbox_id = data["sandbox_id"]

    yield data

    # Teardown: force-stop regardless of test outcome
    stop_result = runner.invoke(cli, ["--json", "stop", "--api-key", _api_key, "-y", sandbox_id])
    if stop_result.exit_code != 0:
        print("WARNING: sandbox cleanup failed: {out}".format(out=stop_result.output))


class TestSandboxLifecycle:
    """Full sandbox lifecycle exercised through JSON CLI commands."""

    # -- launch --

    def test_launch_returns_sandbox_id(self, sandbox):
        assert sandbox["sandbox_id"]

    def test_launch_returns_webui_url(self, sandbox):
        assert sandbox["webui"].startswith("https://")

    def test_launch_returns_gateway_ws(self, sandbox):
        assert "gateway_ws" in sandbox

    def test_launch_returns_terminal_url(self, sandbox):
        assert sandbox["terminal_url"].startswith("https://")

    def test_launch_returns_filemanager_url(self, sandbox):
        assert sandbox["filemanager_url"].startswith("https://")

    def test_launch_returns_service_credentials(self, sandbox):
        assert sandbox["services_username"]
        assert sandbox["services_password"]
        assert len(sandbox["services_password"]) >= 16

    # -- list --

    def test_list_contains_sandbox(self, runner, sandbox):
        result = runner.invoke(cli, ["--json", "list", "--api-key", _api_key])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"

        ids = [s["sandbox_id"] for s in data["sandboxes"]]
        assert sandbox["sandbox_id"] in ids

    # -- status --

    def test_status_shows_running(self, runner, sandbox):
        sid = sandbox["sandbox_id"]
        result = runner.invoke(cli, ["--json", "status", "--api-key", _api_key, sid])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["state"] == "running"

    def test_status_includes_service_urls(self, runner, sandbox):
        sid = sandbox["sandbox_id"]
        result = runner.invoke(cli, ["--json", "status", "--api-key", _api_key, sid])
        data = json.loads(result.output)
        assert data["terminal_url"].startswith("https://")
        assert data["filemanager_url"].startswith("https://")

    def test_status_includes_credentials(self, runner, sandbox):
        sid = sandbox["sandbox_id"]
        result = runner.invoke(cli, ["--json", "status", "--api-key", _api_key, sid])
        data = json.loads(result.output)
        assert data.get("services_username")
        assert data.get("services_password")

    # -- stop --

    def test_stop_terminates_sandbox(self, runner, sandbox):
        sid = sandbox["sandbox_id"]
        result = runner.invoke(cli, ["--json", "stop", "--api-key", _api_key, "-y", sid])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "ok"
        assert data["sandbox_id"] == sid

    def test_sandbox_removed_after_stop(self, runner, sandbox):
        result = runner.invoke(cli, ["--json", "list", "--api-key", _api_key])
        assert result.exit_code == 0
        data = json.loads(result.output)
        ids = [s["sandbox_id"] for s in data["sandboxes"]]
        assert sandbox["sandbox_id"] not in ids
