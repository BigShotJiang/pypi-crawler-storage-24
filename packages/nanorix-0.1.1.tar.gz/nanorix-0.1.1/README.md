# Nanorix Python SDK

Sealed processing with cryptographic destruction proofs.

## Installation

```bash
pip install nanorix
```

## Quick Start

```python
import nanorix

client = nanorix.Client(api_key="nrx_live_...")

# Create a template (one-time setup)
template = client.templates.create(
    name="patient-risk-scorer",
    runtime="python3.11",
    entrypoint="python model.py",
    files=["model.py", "requirements.txt"],
)
client.templates.wait_until_ready(template.id)

# Process data — capsule auto-destroyed after completion
outputs, cdp = client.capsules.run(
    template=template.id,
    inputs={"patient.csv": open("patient.csv", "rb")},
)

# The proof
print(cdp.verify_url)  # https://nanorix.io/verify/cap_...
```

## Workspace Mode

For multi-step workflows with full control:

```python
capsule = client.capsules.start(template="tmpl_...")

capsule.upload("patient.csv", data)
capsule.execute("python preprocess.py")
capsule.execute("python model.py")

prediction = capsule.download("prediction.json")
cdp = capsule.destroy()

# Share the proof with auditors
verification = cdp.verification()
```

## CDP Access

Every destroyed capsule produces a Cryptographic Destruction Proof:

```python
# Full CDP — your private audit trail
full = cdp.full()
print(full.activity)       # Complete event timeline
print(full.destruction)    # 8-step chain verification

# Verification CDP — safe to share
verify = cdp.verification()
print(verify.data_ingested)   # File count and hashes only
print(verify.residency)       # How long data existed
# Zero filenames, commands, or operational details
```

## Error Handling

```python
from nanorix import ExecutionError, TimeoutError

try:
    outputs, cdp = client.capsules.run(template="tmpl_...", inputs=inputs)
except ExecutionError as e:
    print(f"Exit code: {e.exit_code}")
    print(f"CDP still generated: {e.cdp}")  # Destruction happened
except TimeoutError as e:
    print(f"Capsule still alive: {e.capsule.id}")
    # Decide: retry, debug, or destroy
```

## Async Support

```python
import nanorix

async with nanorix.AsyncClient(api_key="nrx_live_...") as client:
    outputs, cdp = await client.capsules.run(
        template="tmpl_...",
        inputs={"data.csv": data},
    )
```

## Configuration

```python
client = nanorix.Client(
    api_key="nrx_live_...",
    base_url="https://api.nanorix.io",  # default
    timeout=30.0,                        # default
    max_retries=3,                       # default
)
```

## Documentation

- [API Reference](https://docs.nanorix.io)
- [Dashboard](https://app.nanorix.io)
- [Verify a CDP](https://nanorix.io/verify)
