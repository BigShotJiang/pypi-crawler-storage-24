# Changelog

All notable changes to the Nanorix Python SDK will be documented in this file.

## 0.1.0 — 2026-03-25

### Initial release

- Sync and async clients (`Client`, `AsyncClient`)
- Template management: create (three-step), list, get, delete, wait_until_ready
- Capsule lifecycle: start, upload, execute, download, destroy
- One-shot processing: `client.capsules.run()` wraps full lifecycle
- Workspace mode: `LiveCapsule` object with step-by-step methods
- CDP access: `CdpAccess` with `.full()`, `.verification()`, `.verify_url`
- Typed exception hierarchy mapping HTTP status codes
- Retry with exponential backoff on 429 and 5xx
- Pydantic v2 models with forward compatibility (`extra="allow"`)
- PEP 561 type stubs (`py.typed`)
- 45 tests with respx mocks
