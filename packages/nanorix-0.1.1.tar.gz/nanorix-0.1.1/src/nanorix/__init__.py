"""
Nanorix Python SDK — Sealed processing with cryptographic destruction proofs.

Usage:
    import nanorix

    client = nanorix.Client(api_key="nrx_live_...")

    # One-shot
    result, cdp = client.capsules.run(
        template="tmpl_...",
        inputs={"patient.csv": data},
    )

    # Workspace
    capsule = client.capsules.start(template="tmpl_...")
    capsule.upload("data.csv", data)
    capsule.execute()
    output = capsule.download("result.json")
    cdp = capsule.destroy()
"""
from nanorix._client import AsyncClient, Client
from nanorix._constants import VERSION
from nanorix._exceptions import (
    AuthenticationError,
    BadRequestError,
    CeilingError,
    ConflictError,
    ExecutionError,
    GoneError,
    NanorixError,
    NotFoundError,
    PayloadTooLargeError,
    QuotaExceededError,
    RateLimitError,
    TimeoutError,
)
from nanorix._models import (
    Capsule,
    CapsuleList,
    CdpAccess,
    CdpDocument,
    ExecutionResult,
    FileInfo,
    Template,
    TemplateFile,
    TemplateList,
    VerificationCdp,
)

__version__ = VERSION
__all__ = [
    "Client",
    "AsyncClient",
    # Exceptions
    "NanorixError",
    "AuthenticationError",
    "NotFoundError",
    "ConflictError",
    "RateLimitError",
    "PayloadTooLargeError",
    "GoneError",
    "QuotaExceededError",
    "BadRequestError",
    "ExecutionError",
    "CeilingError",
    "TimeoutError",
    # Models
    "Template",
    "TemplateFile",
    "TemplateList",
    "Capsule",
    "CapsuleList",
    "ExecutionResult",
    "FileInfo",
    "CdpDocument",
    "VerificationCdp",
    "CdpAccess",
]
