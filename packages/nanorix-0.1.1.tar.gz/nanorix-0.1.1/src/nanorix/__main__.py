"""Entry point for `python -m nanorix`."""
from nanorix._constants import VERSION

print(f"nanorix {VERSION}")
