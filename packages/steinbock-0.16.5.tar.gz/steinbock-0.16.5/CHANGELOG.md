# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [0.16.5] - 2026-03-26

### Changed

  - fixed new docker build distribution, where cellpose does not include deepcell + proper arm64/amd64 build

## [0.16.4] - 2026-03-26

### Changed

  - Updated readimc to 0.9.2
  - Changed Cellpose container and description to v4.0.8, using CellposeSAM, included arm64 build
  - Updated build.yml to run ghcr docker build on ubuntu-latest
  - removed xpra docker build

## [0.16.3] - 2024-05-29

### Changed

  - Updated readimc to 0.7.0

### Added

  - Added the option for lenient parsing of corrupted ROIs

## [0.16.2] - 2023-08-15

### Changed

  - Enhanced error handling for missing ROIs [#184](https://github.com/BodenmillerGroup/steinbock/issues/184)

## [0.16.1] - 2023-05-07

### Fixed

  - Broken external preprocessing for files with OME-suffix [#181](https://github.com/BodenmillerGroup/steinbock/issues/181)

## [0.16.0] - 2023-02-03

### Added

  - New `steinbock view` command (napari) [#27](https://github.com/BodenmillerGroup/steinbock/issues/27)
  - New `steinbock utils expand` command (mask expansion) [#106](https://github.com/BodenmillerGroup/steinbock/issues/106)
  - New `steinbock apps jupyter` and `steinbock apps jupyterlab` commands
  - New steinbock `-cellpose` container flavor (cellpose segmentation) [#118](https://github.com/BodenmillerGroup/steinbock/issues/118)
  - New steinbock `-xpra` container flavor (web-based graphical user interfaces)
  - Preparations for tensorflow-enabled arm64-based linux base images [#98](https://github.com/BodenmillerGroup/steinbock/issues/98)
  - Added $RUN_FIXUID environment variable (prepare for Singularity) [#156](https://github.com/BodenmillerGroup/steinbock/issues/156)

### Changed

  - Dependency upgrades
  - CellProfiler upgrade to 4.2.5
  - Harmonization of `--unzip` defaults (IMC preprocessing)
  - Separate virtual environments for steinbock and CellProfiler
  - Improved development environment (toolchain configuration, test skeletons)
  - Revised steinbock Docker container installation instructions [#160](https://github.com/BodenmillerGroup/steinbock/issues/160)

### Fixed

  - Missing error message in measurement commands [#151](https://github.com/BodenmillerGroup/steinbock/issues/151)

## [0.15.0] - 2022-09-15

  - [#136](https://github.com/BodenmillerGroup/steinbock/issues/136) Fix histoCAT mask export
  - [#146](https://github.com/BodenmillerGroup/steinbock/issues/146) Fix relabeling during stitching
  - Upgrade deepcell 0.12.2 to 0.12.3
  - Upgrade CellProfiler 4.2.1 to 4.2.4
  - Upgrade other dependencies
  - [#109](https://github.com/BodenmillerGroup/steinbock/issues/109) Support 2-6 channel TIFF files
  - [#66](https://github.com/BodenmillerGroup/steinbock/issues/66) Include panel/image metadata in anndata exports
  - [#117](https://github.com/BodenmillerGroup/steinbock/issues/117) Extract and process images from .zip archives file by file
  - [#104](https://github.com/BodenmillerGroup/steinbock/issues/104) [#121](https://github.com/BodenmillerGroup/steinbock/issues/121) Documentation improvements
  - [#139](https://github.com/BodenmillerGroup/steinbock/issues/139) [#140](https://github.com/BodenmillerGroup/steinbock/issues/140) [#141](https://github.com/BodenmillerGroup/steinbock/issues/141) API improvements

## [0.14.2] - 2022-06-29

  - Upgrade DeepCell (to 0.12.2) and other dependencies
  - [#132](https://github.com/BodenmillerGroup/steinbock/issues/132) Write images as ImageJ TIFF for supported data types only
  - [#133](https://github.com/BodenmillerGroup/steinbock/issues/133) Exclude hidden files from processing

## [0.14.1] - 2022-06-08

  - [#127](https://github.com/BodenmillerGroup/steinbock/issues/127) Fix CUDA build
  - [#128](https://github.com/BodenmillerGroup/steinbock/issues/128) Fix steinbock wheel

## [0.14.0] - 2022-06-02

  - [#111](https://github.com/BodenmillerGroup/steinbock/issues/111) Include package data in Python package
  - [#122](https://github.com/BodenmillerGroup/steinbock/issues/122) Use logging instead of `click.echo`
  - [#123](https://github.com/BodenmillerGroup/steinbock/issues/123) Custom exception handling
  - [#124](https://github.com/BodenmillerGroup/steinbock/issues/124) Fix neighbor measurement
  - [#125](https://github.com/BodenmillerGroup/steinbock/issues/125) Upgrade to DeepCell 0.12.0
  - Various minor bugfixes and improvements
  - Upgrade all dependencies

## [0.13.5] - 2022-02-21

  - Fix dependency version pinning

## [0.13.4] - 2022-02-09

  - Fix DeepCell YAML loading

## [0.13.3] - 2022-02-08

  - Fix ambiguous txt file matching (see [#100](https://github.com/BodenmillerGroup/steinbock/issues/100))

## [0.13.2] - 2022-02-04

  - Maintenance release

## [0.13.1] - 2022-01-26

  - Fix GPU support

## [0.13.0] - 2022-01-26

  - Full memory mapping support
  - Fixed zero division error in deepcell normalization
  - Added GPU support (switched to Ubuntu 18.04-based tensorflow base image)
  - Fixed IMC panel preprocessing
  - Upgraded dependencies

## [0.12.0] - 2022-01-08

  - In-memory mosaics
  - Stabilized image/mask IO
  - Standardized command output
  - Minor changes, documentation

## [0.11.0] - 2021-12-28

  - Removed steinbock version check
  - Fix IMC panel preprocessing (channel order)
  - Make CLI usable when using PyPI package install
  - Renamed `--mask` and `--probab` parameters to `--masks` and `--probabs`, respectively
  - Clean histoCAT export file names
  - Required `-o` parameter for data export

## [0.10.7] - 2021-12-27

  - Fix IMC panel preprocessing

## [0.10.6] - 2021-12-27

  - Customizable IMC panel columns

## [0.10.5] - 2021-12-25

  - Fix IMC panel preprocessing

## [0.10.4] - 2021-12-25

  - Fix IMC panel preprocessing

## [0.10.3] - 2021-12-20

  - Fix memory issue with Ilastik image creation

## [0.10.2] - 2021-12-07

  - Fix deepcell incompatibility with scikit-image upgrade


## [0.10.1] - 2021-12-06

  - Fix AnnData export warning
  - Allow duplicated txt/mcd file names
  - Upgrade readimc and other dependencies


## [0.10.0] - 2021-11-05

  - Unified object data (csv, fcs, anndata) export commands
  - Improved anndata export: concatenation, intensities, graphs
  - Improved IMC panel preprocessing: support for different panels
  - Added functionality for importing image data using imageio
  - Clean up and upgrade dependencies, including deepcell 0.11.0
  - Change image file name pattern to make acquisitions sortable
  - Upgrade readimc for faster reading of .txt files
  - Change CellProfiler input image dtype to uint16
  - Change histoCAT mask dtype to uint16
  - Updated documentation on Docker


## [0.9.1] - 2021-10-12

  - Fixed preprocessing of IMC Segmentation Pipeline panels


## [0.9.0] - 2021-10-11

  - Upgraded dependencies
  - Improved documentation
  - Reduced Docker image size
  - Replaced imctools with readimc
  - Added dockerized unit tests (w.i.p.)
  - Restructured package, renamed tools to utils
  - Updated package information, added `all` extra
  - Added histoCAT image export command
  - Added steinbock logo (Nils Eling)


## [0.8.1] - 2021-09-22

  - Added missing deepcell column to IMC panel preprocessing from raw data


## [0.8.0] - 2021-09-21

  - Improved error handling & messages
  - Restructured & improved documentation
  - IMC preprocessing: extract image metadata
  - Fix steinbock versioning in docker container
  - Upgraded dependencies, including deepcell 0.10.0
  - Fix permission issues using fixuid approach


## [0.7.3] - 2021-09-09

  - Make container ready for passwd mounting
  - Fix OME export destination directory name


## [0.7.2] - 2021-09-09

  - Fixed graph export


## [0.7.1] - 2021-09-09

  - Renamed graph measurement to neighbor measurement


## [0.7.0] - 2021-09-01

  - Improved graph construction performance
  - Added new graph construction methods, including pixel expansion
  - Removed distance computation in favor of more performant graph construction
  - Fixed IMC panel preprocessing (unreported bugs)
  - Fixed Ilastik pixel classification (unreported bugs)


## [0.6.2] - 2021-08-21

  - Improved documentation & switched to versioned documentation
  - Improved IMC Segmentation Pipeline panel support ([#38](https://github.com/BodenmillerGroup/steinbock/issues/38))


## [0.6.1] - 2021-08-17

  - Fixed data type conversion upon image loading


## [0.6.0] - 2021-08-17

  - Updated CellProfiler and other dependencies ([#22](https://github.com/BodenmillerGroup/steinbock/issues/22))
  - Switch from Docker Hub to GitHub Container Registry ([#34](https://github.com/BodenmillerGroup/steinbock/issues/34))
  - Various compatibility improvements and bugfixes ([#21](https://github.com/BodenmillerGroup/steinbock/issues/21), [#28](https://github.com/BodenmillerGroup/steinbock/issues/28), [#32](https://github.com/BodenmillerGroup/steinbock/issues/32), [#35](https://github.com/BodenmillerGroup/steinbock/issues/35))


## [0.5.6] - 2021-06-29

  - Switch to bilinear interpolation for Ilastik mean channel
  - Make image/mask data type configurable via environment variables


## [0.5.5] - 2021-06-28

  - Fix steinbock version check
  - Add meanfactor option to Ilastik (compatibility with IMC segmentation pipeline)
  - Save Ilastik images/crops as uint16 (compatibility with IMC segmentation pipeline)


## [0.5.4] - 2021-06-23

  - Speed up Ilastik image creation


## [0.5.3] - 2021-06-22

  - Fix CSV/FCS export


## [0.5.2] - 2021-06-15

  - Fix networkx node attribute export
  - Remove `object_` prefix from default directory names
  - Speed up intensity measurement (use scipy.ndimage for aggregation)


## [0.5.1] - 2021-06-10

  - Version bumps of tifffile, xtiff
  - Preprocessing/postprocessing parameter support for DeepCell


## [0.5.0] - 2021-06-03

  - Module restructuring
  - PyPI package release
  - CLI refactoring, --version option
  - Improved documentation (API documentation is w.i.p.)
  - Export to OME-TIFF, CSV, FCS, AnnData, graph file formats
  - Match related files by name rather than alphabetical order
  - Customizable pixel/channel aggregation strategies
  - [Many more](https://github.com/BodenmillerGroup/steinbock/compare/v0.4.0...v0.5.0) small bug fixes & improvements


## [0.4.0] - 2021-05-27

  - Python API cleanup
  - Added DeepCell segmentation support


## [0.3.7] - 2021-05-20

  - Automatic SCM versioning
  - Steinbock version file checks
  - Renamed steinbock panel columns
  - Improved Docker container Python package setup
  - Combined kNN/distance-thresholded graph generation


## [0.3.6] - 2021-04-29

  - Make panel channel label values optional
  - Rename panel columns metal, name to id, label


## [0.3.5] - 2021-04-29

  - Minor bug fixes and performance improvements
  - Separated IMC panel/image preprocessing to allow for easier channel filtering


## [0.3.4] - 2021-04-27

  - [#6](https://github.com/BodenmillerGroup/steinbock/issues/6) Panel creation from .mcd/.txt files
  - [#9](https://github.com/BodenmillerGroup/steinbock/issues/9) Improved documentation on Ilastik feature selection
  - [#10](https://github.com/BodenmillerGroup/steinbock/issues/10) Fixed Ilastik class label colors
  - [#11](https://github.com/BodenmillerGroup/steinbock/issues/11) Simplified command-line interface


## [0.3.3] - 2021-04-21

New functionality, bug fixes, documentation improvements

Added:

  - ZIP archive support for IMC data (closes [#2](https://github.com/BodenmillerGroup/steinbock/issues/2))
  - Ilastik channel ordering & grouping (closes [#3](https://github.com/BodenmillerGroup/steinbock/issues/3))
  - Run container as non-privileged user (fixes [#4](https://github.com/BodenmillerGroup/steinbock/issues/4))


## [0.3.2] - 2021-04-19

New functionality, bug fixes, documentation improvements

Added:

  - Mask matching
  - IMC panel pass-through
  - Generalized object segmentation
  - Hardened image loading to allow for tiles of size 1 in one dimension


## [0.3.1] - 2021-04-18

Documentation, minor improvements, fix memory leaks & stitching


## [0.3.0] - 2021-04-16

CLI refactoring, mosaic tooling


## [0.2.0] - 2021-04-12

CLI refactoring, removed imctoolkit dependency

Added:

  - Support for "raw" IMC panels
  - Additional user input validation
  - Mean channel in Ilastik images/crops
  - Additional progress bars/indicators
  - Measurements for cell regionprops
  - Measurements for cell distances/graphs


## [0.1.0] - 2021-04-08

Initial release for beta testing


[0.16.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.16.0...v0.16.1
[0.16.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.15.0...v0.16.0
[0.15.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.14.2...v0.15.0
[0.14.2]: https://github.com/BodenmillerGroup/steinbock/compare/v0.14.1...v0.14.2
[0.14.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.14.0...v0.14.1
[0.14.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.13.5...v0.14.0
[0.13.5]: https://github.com/BodenmillerGroup/steinbock/compare/v0.13.4...v0.13.5
[0.13.4]: https://github.com/BodenmillerGroup/steinbock/compare/v0.13.3...v0.13.4
[0.13.3]: https://github.com/BodenmillerGroup/steinbock/compare/v0.13.2...v0.13.3
[0.13.2]: https://github.com/BodenmillerGroup/steinbock/compare/v0.13.1...v0.13.2
[0.13.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.13.0...v0.13.1
[0.13.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.12.0...v0.13.0
[0.12.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.10.7...v0.11.0
[0.10.7]: https://github.com/BodenmillerGroup/steinbock/compare/v0.10.6...v0.10.7
[0.10.6]: https://github.com/BodenmillerGroup/steinbock/compare/v0.10.5...v0.10.6
[0.10.5]: https://github.com/BodenmillerGroup/steinbock/compare/v0.10.4...v0.10.5
[0.10.4]: https://github.com/BodenmillerGroup/steinbock/compare/v0.10.3...v0.10.4
[0.10.3]: https://github.com/BodenmillerGroup/steinbock/compare/v0.10.2...v0.10.3
[0.10.2]: https://github.com/BodenmillerGroup/steinbock/compare/v0.10.1...v0.10.2
[0.10.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.10.0...v0.10.1
[0.10.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.9.1...v0.10.0
[0.9.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.8.1...v0.9.0
[0.8.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.8.0...v0.8.1
[0.8.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.7.3...v0.8.0
[0.7.3]: https://github.com/BodenmillerGroup/steinbock/compare/v0.7.2...v0.7.3
[0.7.2]: https://github.com/BodenmillerGroup/steinbock/compare/v0.7.1...v0.7.2
[0.7.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.7.0...v0.7.1
[0.7.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.6.2...v0.7.0
[0.6.2]: https://github.com/BodenmillerGroup/steinbock/compare/v0.6.1...v0.6.2
[0.6.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.5.6...v0.6.0
[0.5.6]: https://github.com/BodenmillerGroup/steinbock/compare/v0.5.5...v0.5.6
[0.5.5]: https://github.com/BodenmillerGroup/steinbock/compare/v0.5.4...v0.5.5
[0.5.4]: https://github.com/BodenmillerGroup/steinbock/compare/v0.5.3...v0.5.4
[0.5.3]: https://github.com/BodenmillerGroup/steinbock/compare/v0.5.2...v0.5.3
[0.5.2]: https://github.com/BodenmillerGroup/steinbock/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.3.7...v0.4.0
[0.3.7]: https://github.com/BodenmillerGroup/steinbock/compare/v0.3.6...v0.3.7
[0.3.6]: https://github.com/BodenmillerGroup/steinbock/compare/v0.3.5...v0.3.6
[0.3.5]: https://github.com/BodenmillerGroup/steinbock/compare/v0.3.4...v0.3.5
[0.3.4]: https://github.com/BodenmillerGroup/steinbock/compare/v0.3.3...v0.3.4
[0.3.3]: https://github.com/BodenmillerGroup/steinbock/compare/v0.3.2...v0.3.3
[0.3.2]: https://github.com/BodenmillerGroup/steinbock/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/BodenmillerGroup/steinbock/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/BodenmillerGroup/steinbock/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/BodenmillerGroup/steinbock/releases/tag/v0.1.0
