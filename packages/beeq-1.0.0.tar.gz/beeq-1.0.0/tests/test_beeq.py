"""BeeQ Test Suite — Phase 0 · Base propre."""

import pytest
from beeq.governance.hive  import HiveGovernance, RESULT_SUCCESS, RESULT_BLOCKED
from beeq.providers.manager import ProviderManager
from beeq.workers.research  import ResearchWorker
from beeq.workers.code      import CodeWorker
from beeq.workers.writer    import WriterWorker
from beeq.workers.ops       import OpsWorker
from beeq.workers.memory    import MemoryWorker
from beeq.workers.hardware  import HardwareWorker
from aap import AuthorizationLevel


# ── GOVERNANCE ──────────────────────────────────────────────────────────

def test_governance_creates_worker():
    g = HiveGovernance()
    w = g.register_worker("test", ["read:files"])
    assert w.name == "test"
    assert not w.identity.revoked
    assert w.authorization.is_valid()

def test_governance_worker_scope():
    g = HiveGovernance()
    w = g.register_worker("research", ["read:web", "search:*"])
    assert "read:web" in w.identity.scope

def test_physical_world_rule():
    """LEX §3 — Level 4 forbidden for physical workers."""
    from aap import AAPPhysicalWorldViolation
    g = HiveGovernance()
    with pytest.raises(AAPPhysicalWorldViolation):
        g.register_worker("robot", ["move:arm"],
                          level=AuthorizationLevel.AUTONOMOUS, physical=True)

def test_record_action_in_audit_chain():
    g = HiveGovernance()
    g.register_worker("ops", ["read:system"])
    artifact_id = g.record_action("ops", "read:system", RESULT_SUCCESS,
                                   b"check disk", b"disk: 40% used")
    assert artifact_id
    valid, count, broken = g.verify_chain()
    assert valid and count == 1 and broken is None

def test_revoke_worker():
    """LEX §5 — sovereign authority can revoke at any time."""
    g = HiveGovernance()
    g.register_worker("research", ["read:web"])
    g.revoke_worker("research")
    assert not g.workers["research"].authorization.is_valid()

def test_audit_chain_multiple_actions():
    g = HiveGovernance()
    g.register_worker("code", ["read:files", "write:files"])
    for i in range(5):
        g.record_action("code", "read:files", RESULT_SUCCESS,
                        f"task {i}".encode(), f"result {i}".encode())
    valid, count, _ = g.verify_chain()
    assert valid and count == 5

def test_audit_chain_blocked_action():
    g = HiveGovernance()
    g.register_worker("ops", ["read:system"])
    g.record_action("ops", "read:system", RESULT_BLOCKED, b"dangerous", b"blocked by LEX")
    entries = list(g.audit_entries)
    assert entries[-1].result == "blocked"

def test_worker_identity_is_signed():
    g = HiveGovernance()
    w = g.register_worker("write", ["write:doc"])
    assert w.identity.signature.startswith("ed25519:")

def test_worker_unknown_raises():
    g = HiveGovernance()
    with pytest.raises(ValueError, match="Unknown worker"):
        g.record_action("ghost", "do:something", RESULT_SUCCESS)


# ── PROVIDERS ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_provider_manager_no_providers():
    pm = ProviderManager()
    with pytest.raises(RuntimeError, match="No LLM provider"):
        await pm.complete([{"role": "user", "content": "test"}])

@pytest.mark.asyncio
async def test_ollama_health_no_server():
    from beeq.providers.ollama import OllamaProvider
    p = OllamaProvider(host="http://localhost:99999")
    assert await p.health() == False


# ── WORKERS REGISTER ────────────────────────────────────────────────────

def test_worker_registers_with_governance():
    g, pm = HiveGovernance(), ProviderManager()
    w = ResearchWorker(governance=g, providers=pm)
    w.register()
    assert "research" in g.workers
    assert g.workers["research"].identity.id == "aap://beeq/worker/research@1.0.0"

def test_all_workers_register():
    g, pm = HiveGovernance(), ProviderManager()
    for WC in [ResearchWorker, CodeWorker, WriterWorker, OpsWorker, MemoryWorker, HardwareWorker]:
        WC(governance=g, providers=pm).register()
    assert len(g.workers) == 6

def test_worker_scopes_are_minimal():
    """LEX §8 — workers request minimal scope."""
    g, pm = HiveGovernance(), ProviderManager()
    ResearchWorker(governance=g, providers=pm).register()
    assert not g.workers["research"].identity.allows_action("write:files")
    assert not g.workers["research"].identity.allows_action("exec:system")

def test_hardware_worker_supervised_only():
    """LEX §3 + PHY §2 — hardware worker is SUPERVISED, never AUTONOMOUS."""
    from aap import AuthorizationLevel
    g, pm = HiveGovernance(), ProviderManager()
    HardwareWorker(governance=g, providers=pm).register()
    level = g.workers["hardware"].authorization.level
    assert level != AuthorizationLevel.AUTONOMOUS


# ── MEMORY ──────────────────────────────────────────────────────────────

def test_memory_store_and_recall(tmp_path):
    """Memory stores and retrieves correctly."""
    import beeq.workers.memory as mem_mod
    # Override DB path before MemoryWorker instantiation
    orig_dir = mem_mod.MEMORY_DIR
    orig_db  = mem_mod.MEMORY_DB
    mem_mod.MEMORY_DIR = tmp_path
    mem_mod.MEMORY_DB  = tmp_path / "memory.db"
    try:
        g, pm = HiveGovernance(), ProviderManager()
        m = MemoryWorker(governance=g, providers=pm)
        m.register()
        mem_id = m.store("BeeQ is the first AI hive", tags=["beeq", "ai"])
        assert len(mem_id) == 16
        results = m.search("AI hive")
        assert any(r["id"] == mem_id for r in results)
    finally:
        mem_mod.MEMORY_DIR = orig_dir
        mem_mod.MEMORY_DB  = orig_db

def test_memory_session_state(tmp_path):
    """Session state persists."""
    import beeq.workers.memory as mem_mod
    orig_dir = mem_mod.MEMORY_DIR
    orig_db  = mem_mod.MEMORY_DB
    mem_mod.MEMORY_DIR = tmp_path
    mem_mod.MEMORY_DB  = tmp_path / "memory2.db"
    try:
        g, pm = HiveGovernance(), ProviderManager()
        m = MemoryWorker(governance=g, providers=pm)
        m.register()
        m.session_set("current_project", "LABO_Z")
        assert m.session_get("current_project") == "LABO_Z"
        assert m.session_get("nonexistent") is None
    finally:
        mem_mod.MEMORY_DIR = orig_dir
        mem_mod.MEMORY_DB  = orig_db


# ── FULL HIVE ────────────────────────────────────────────────────────────

def test_full_hive_governance():
    g, pm = HiveGovernance(), ProviderManager()
    for WC in [ResearchWorker, CodeWorker, WriterWorker, OpsWorker, MemoryWorker, HardwareWorker]:
        WC(governance=g, providers=pm).register()
    actions = [
        ("research", "search:web"),
        ("code",     "read:files"),
        ("write",    "write:doc"),
        ("ops",      "read:system"),
        ("memory",   "read:memory"),
        ("hardware", "observe:nrp"),
    ]
    for name, action in actions:
        g.record_action(name, action, RESULT_SUCCESS, b"in", b"out")
    valid, count, broken = g.verify_chain()
    assert valid and count == 6 and broken is None
    g.revoke_worker("research")
    assert not g.workers["research"].authorization.is_valid()
    assert g.workers["code"].authorization.is_valid()
