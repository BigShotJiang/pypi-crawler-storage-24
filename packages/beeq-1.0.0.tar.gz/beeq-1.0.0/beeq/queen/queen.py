"""
Queen — the orchestration engine of BeeQ.

The Queen does not execute tasks.
The Queen decomposes missions into subtasks,
delegates each subtask to the right worker,
monitors progress, handles failures,
and reports consolidated results to the human.

The Queen is the role. The LLM is the brain.
Any LLM can play the Queen.

HUMAN (sovereign — gives mission)
  ↓
QUEEN (decomposes, delegates, consolidates)
  ↓
WORKERS (execute within their scope)
  ↓
WORLD (digital + physical)
"""

import json
import asyncio
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..providers.manager import ProviderManager
    from ..governance.hive import HiveGovernance
    from ..workers.base import BaseWorker, WorkerResult


QUEEN_SYSTEM = """You are the Queen of a BeeQ hive.

Your role: receive a mission from the human, decompose it into
concrete subtasks, delegate each to the right worker, and report
a consolidated result.

You have these workers available:
{workers}

For each mission, respond with a JSON plan:
{{
  "understanding": "what you understood",
  "subtasks": [
    {{
      "id": "t1",
      "worker": "research",
      "action": "search:web",
      "instruction": "search for X",
      "depends_on": []
    }}
  ],
  "expected_result": "what the human will receive"
}}

Rules:
- Assign each subtask to the most appropriate worker
- A worker can only do what its scope allows
- Mark dependencies between subtasks (depends_on)
- Keep tasks atomic — one clear action per task
- If unsure, ask the human for clarification
"""


@dataclass
class Mission:
    instruction: str
    context:     dict = field(default_factory=dict)
    results:     list["WorkerResult"] = field(default_factory=list)
    status:      str = "pending"   # pending / running / done / failed


class Queen:
    """
    BeeQ orchestration engine.

    The Queen receives a natural language mission,
    decomposes it into subtasks, delegates to workers,
    and returns a consolidated result to the human.
    """

    def __init__(
        self,
        providers:  "ProviderManager",
        governance: "HiveGovernance",
        workers:    dict[str, "BaseWorker"] | None = None,
    ):
        self.providers  = providers
        self.governance = governance
        self.workers    = workers or {}

    def add_worker(self, worker: "BaseWorker") -> None:
        worker.register()
        self.workers[worker.name] = worker

    async def execute(self, mission: str, context: dict | None = None) -> Mission:
        """
        Receive a mission. Decompose. Delegate. Consolidate. Return.

        This is the main loop:
        1. Queen understands the mission
        2. Queen builds a plan (subtasks + worker assignments)
        3. Execute subtasks respecting dependencies
        4. Consolidate results
        5. Present to human
        """
        m = Mission(instruction=mission, context=context or {})
        m.status = "running"

        # Build worker descriptions for the system prompt
        lines = []
        for name, w in self.workers.items():
            lines.append("- " + name + ": " + w.description + " (scope: " + str(w.default_scope) + ")")
        worker_desc = "\n".join(lines)

        # Step 1: Queen decomposes the mission
        plan = await self._plan(mission, worker_desc)
        if not plan:
            m.status = "failed"
            return m

        # Step 2: Execute subtasks respecting dependencies
        completed: dict[str, "WorkerResult"] = {}
        for subtask in plan.get("subtasks", []):
            # Wait for dependencies
            for dep in subtask.get("depends_on", []):
                if dep not in completed:
                    continue  # skip if dependency failed

            worker_name = subtask.get("worker")
            worker = self.workers.get(worker_name)
            if not worker:
                continue

            result = await worker.execute(
                task=subtask.get("instruction", ""),
                context={"subtask": subtask, "mission": mission},
            )
            completed[subtask["id"]] = result
            m.results.append(result)

        m.status = "done"
        return m

    async def _plan(self, mission: str, worker_desc: str) -> dict | None:
        """Ask the Queen LLM to decompose the mission into a plan."""
        try:
            system = QUEEN_SYSTEM.format(workers=worker_desc)
            response = await self.providers.complete(
                messages=[{"role": "user", "content": mission}],
                system=system,
                max_tokens=2048,
            )
            # Extract JSON from response
            content = response.content.strip()
            # Find JSON block
            start = content.find("{")
            end   = content.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(content[start:end])
        except Exception as e:
            pass
        return None
