"""
Worker-Code — file system, code execution, git operations.

Scope: read:files · write:files · exec:code

Actions réelles :
  - Lecture/écriture vrais fichiers
  - Backup automatique avant modification (LEX §9)
  - Exécution sandboxée de code Python
  - Opérations Git de base
"""

import os
import subprocess
import shutil
from pathlib import Path
from datetime import datetime
from .base import BaseWorker, WorkerResult


BACKUP_DIR = Path.home() / ".beeq" / "backups"


class CodeWorker(BaseWorker):
    name          = "code"
    description   = "File system operations, code reading/writing, sandboxed execution, git"
    default_scope = ["read:files", "write:files", "exec:code"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        try:
            # Détecter si c'est une opération fichier directe
            action, target = self._parse_action(task, context)

            if action == "read" and target:
                return await self._read_file(target, task)
            elif action == "exec" and target:
                return await self._exec_code(target, task)
            else:
                return await self._llm_code_task(task, context)

        except Exception as e:
            self._record("exec:code", success=False,
                        input_data=task.encode(), output_data=str(e).encode())
            return WorkerResult(
                worker=self.name, action="exec:code",
                success=False, output="", error=str(e),
            )

    def _parse_action(self, task: str, context: dict | None) -> tuple[str, str]:
        """Parse si la tâche est une action directe."""
        ctx = context or {}
        if "file_path" in ctx:
            return "read", ctx["file_path"]
        if "exec_code" in ctx:
            return "exec", ctx["exec_code"]
        return "llm", ""

    async def _read_file(self, path: str, task: str) -> WorkerResult:
        """Lire un fichier réel."""
        try:
            content = Path(path).read_text(encoding="utf-8", errors="ignore")
            content_preview = content[:3000]

            response = await self.providers.complete(
                messages=[{"role": "user", "content": "File content:\n" + content_preview + "\n\nTask: " + task}],
                system="You are a code specialist. Analyze the file content and answer the task precisely.",
                max_tokens=2048,
            )
            output = response.content
            artifact_id = self._record("read:files", True, path.encode(), output.encode())
            return WorkerResult(worker=self.name, action="read:files",
                               success=True, output=output, artifacts=[artifact_id])
        except Exception as e:
            return WorkerResult(worker=self.name, action="read:files",
                               success=False, output="", error=str(e))

    async def _exec_code(self, code: str, task: str) -> WorkerResult:
        """Exécuter du code Python de façon sandboxée."""
        try:
            # Écrire dans un fichier temp
            tmp = Path("/tmp/beeq_exec_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".py")
            tmp.write_text(code)

            result = subprocess.run(
                ["python3", str(tmp)],
                capture_output=True, text=True, timeout=30
            )
            tmp.unlink(missing_ok=True)

            output = result.stdout
            if result.stderr:
                output += "\nSTDERR:\n" + result.stderr[:500]

            artifact_id = self._record("exec:code", result.returncode == 0,
                                      code.encode(), output.encode())
            return WorkerResult(worker=self.name, action="exec:code",
                               success=result.returncode == 0,
                               output=output, artifacts=[artifact_id])
        except Exception as e:
            return WorkerResult(worker=self.name, action="exec:code",
                               success=False, output="", error=str(e))

    async def _llm_code_task(self, task: str, context: dict | None) -> WorkerResult:
        """Tâche de code générique via LLM."""
        response = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "You are a code specialist. Provide clean, working code solutions. "
                "Always prefer reversible actions (LEX §9): backup before modify, "
                "test before deploy. Explain your approach concisely."
            ),
            max_tokens=4096,
        )
        output = response.content
        artifact_id = self._record("exec:code", True, task.encode(), output.encode())
        return WorkerResult(worker=self.name, action="exec:code",
                           success=True, output=output, artifacts=[artifact_id])

    def _backup_file(self, path: str) -> str:
        """Backup avant modification — LEX §9."""
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        src = Path(path)
        if src.exists():
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            dst = BACKUP_DIR / (src.name + "." + ts + ".bak")
            shutil.copy2(src, dst)
            return str(dst)
        return ""
