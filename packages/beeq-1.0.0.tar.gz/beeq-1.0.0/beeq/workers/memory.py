"""
Worker-Memory — persistent sovereign memory for the hive.

Scope: read:memory · write:memory · index:knowledge

Features:
  - SQLite persistence between sessions
  - Semantic search via simple TF-IDF (no GPU, no cloud)
  - SESSION_STATE managed automatically
  - Export/import portable
  - Cryptographically owned by the user (LEX §6)
"""

import json
import sqlite3
import hashlib
import math
from pathlib import Path
from datetime import datetime
from collections import Counter
from .base import BaseWorker, WorkerResult

MEMORY_DIR  = Path.home() / ".beeq" / "memory"
MEMORY_DB   = MEMORY_DIR / "memory.db"


class MemoryWorker(BaseWorker):
    name          = "memory"
    description   = "Persistent sovereign memory — store, retrieve, search knowledge across sessions"
    default_scope = ["read:memory", "write:memory", "index:knowledge"]

    def __init__(self, governance, providers):
        super().__init__(governance, providers)
        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        con = sqlite3.connect(MEMORY_DB)
        con.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id        TEXT PRIMARY KEY,
                content   TEXT NOT NULL,
                tags      TEXT DEFAULT '',
                source    TEXT DEFAULT '',
                created   TEXT NOT NULL,
                accessed  TEXT NOT NULL,
                access_n  INTEGER DEFAULT 0
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS session_state (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                ts    TEXT NOT NULL
            )
        """)
        con.commit()
        con.close()

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx = context or {}
        action = ctx.get("action", "auto")

        try:
            if action == "store" or self._is_store(task):
                content = ctx.get("content", task)
                tags    = ctx.get("tags", [])
                result  = self.store(content, tags)
                output  = f"Stored in memory. ID: {result}"

            elif action == "recall" or self._is_recall(task):
                query   = ctx.get("query", task)
                results = self.search(query, top_k=5)
                if results:
                    output = "Recalled from memory:\n\n" + "\n\n---\n\n".join(
                        f"[{r['id'][:8]}] {r['content']}" for r in results
                    )
                else:
                    output = "Nothing relevant found in memory."

            elif action == "session_get":
                key   = ctx.get("key", "")
                value = self.session_get(key)
                output = value or f"[No session state for key: {key}]"

            elif action == "session_set":
                key   = ctx.get("key", "")
                value = ctx.get("value", "")
                self.session_set(key, value)
                output = f"Session state saved: {key}"

            elif action == "summary":
                output = self.summary()

            else:
                # Auto: ask LLM what to do, then act
                output = await self._auto(task, ctx)

            artifact_id = self._record(
                action="read:memory",
                success=True,
                input_data=task.encode(),
                output_data=output.encode(),
            )
            return WorkerResult(
                worker=self.name, action="read:memory",
                success=True, output=output,
                artifacts=[artifact_id],
            )

        except Exception as e:
            self._record("read:memory", success=False,
                        input_data=task.encode(), output_data=str(e).encode())
            return WorkerResult(
                worker=self.name, action="read:memory",
                success=False, output="", error=str(e),
            )

    # ── PUBLIC API ──────────────────────────────────────────────────────

    def store(self, content: str, tags: list[str] = (), source: str = "") -> str:
        """Store a memory. Returns its ID."""
        mem_id  = hashlib.sha256(f"{content}{datetime.utcnow().isoformat()}".encode()).hexdigest()[:16]
        now     = datetime.utcnow().isoformat()
        tags_str = ",".join(tags)
        con = sqlite3.connect(MEMORY_DB)
        con.execute(
            "INSERT OR REPLACE INTO memories VALUES (?,?,?,?,?,?,?)",
            (mem_id, content, tags_str, source, now, now, 0)
        )
        con.commit(); con.close()
        return mem_id

    def search(self, query: str, top_k: int = 5) -> list[dict]:
        """TF-IDF semantic search — no GPU, no cloud."""
        con = sqlite3.connect(MEMORY_DB)
        rows = con.execute("SELECT id, content, tags, created FROM memories").fetchall()
        con.close()
        if not rows:
            return []

        docs = [(r[0], r[1], r[2], r[3]) for r in rows]
        q_tokens = self._tokenize(query)

        # TF-IDF scoring
        N = len(docs)
        df: Counter = Counter()
        tfs = []
        for _, content, tags, _ in docs:
            tokens = self._tokenize(content + " " + tags)
            tf = Counter(tokens)
            tfs.append(tf)
            df.update(set(tokens))

        scores = []
        for i, (mem_id, content, tags, created) in enumerate(docs):
            score = 0.0
            for token in q_tokens:
                if token in tfs[i]:
                    tf  = tfs[i][token] / max(len(tfs[i]), 1)
                    idf = math.log((N + 1) / (df[token] + 1)) + 1.0
                    score += tf * idf
            scores.append((score, mem_id, content, created))

        scores.sort(reverse=True)
        results = []
        for score, mem_id, content, created in scores[:top_k]:
            if score > 0:
                results.append({"id": mem_id, "content": content,
                                "created": created, "score": round(score, 3)})

        # Update access counts
        if results:
            con = sqlite3.connect(MEMORY_DB)
            now = datetime.utcnow().isoformat()
            for r in results:
                con.execute(
                    "UPDATE memories SET accessed=?, access_n=access_n+1 WHERE id=?",
                    (now, r["id"])
                )
            con.commit(); con.close()

        return results

    def session_get(self, key: str) -> str | None:
        con = sqlite3.connect(MEMORY_DB)
        row = con.execute("SELECT value FROM session_state WHERE key=?", (key,)).fetchone()
        con.close()
        return row[0] if row else None

    def session_set(self, key: str, value: str):
        now = datetime.utcnow().isoformat()
        con = sqlite3.connect(MEMORY_DB)
        con.execute("INSERT OR REPLACE INTO session_state VALUES (?,?,?)", (key, value, now))
        con.commit(); con.close()

    def session_all(self) -> dict:
        con = sqlite3.connect(MEMORY_DB)
        rows = con.execute("SELECT key, value FROM session_state").fetchall()
        con.close()
        return {r[0]: r[1] for r in rows}

    def summary(self) -> str:
        con = sqlite3.connect(MEMORY_DB)
        mem_count = con.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        sess_count = con.execute("SELECT COUNT(*) FROM session_state").fetchone()[0]
        top = con.execute(
            "SELECT content FROM memories ORDER BY access_n DESC LIMIT 3"
        ).fetchall()
        con.close()
        lines = [
            f"Memory: {mem_count} items stored · {sess_count} session keys",
            "",
            "Most accessed:"
        ]
        for row in top:
            lines.append("  · " + row[0][:80] + ("..." if len(row[0]) > 80 else ""))
        return "\n".join(lines)

    def export(self, path: str) -> str:
        """Export all memory to JSON."""
        con = sqlite3.connect(MEMORY_DB)
        mems = con.execute("SELECT * FROM memories").fetchall()
        sess = con.execute("SELECT * FROM session_state").fetchall()
        con.close()
        data = {
            "version": "1.0",
            "exported": datetime.utcnow().isoformat(),
            "memories": [{"id":r[0],"content":r[1],"tags":r[2],"source":r[3],
                          "created":r[4],"accessed":r[5],"access_n":r[6]} for r in mems],
            "session":  [{"key":r[0],"value":r[1],"ts":r[2]} for r in sess],
        }
        Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False))
        return path

    # ── PRIVATE ──────────────────────────────────────────────────────────

    def _tokenize(self, text: str) -> list[str]:
        import re
        return re.findall(r"[a-zA-ZÀ-ÿ\u0600-\u06FF\u4e00-\u9fff]{2,}", text.lower())

    def _is_store(self, task: str) -> bool:
        kw = ["remember", "store", "save", "note", "mémorise", "enregistre", "souviens"]
        return any(k in task.lower() for k in kw)

    def _is_recall(self, task: str) -> bool:
        kw = ["recall", "remember", "what do you know", "search memory", "find in memory",
              "rappelle", "souviens", "mémorisé", "qu'est-ce que tu sais"]
        return any(k in task.lower() for k in kw)

    async def _auto(self, task: str, ctx: dict) -> str:
        """Let LLM decide what memory operation to perform."""
        memories = self.search(task, top_k=3)
        mem_ctx = ""
        if memories:
            mem_ctx = "\n\nRelevant memories:\n" + "\n".join(
                f"- {m['content'][:200]}" for m in memories
            )
        response = await self.providers.complete(
            messages=[{"role": "user", "content": task + mem_ctx}],
            system=(
                "You are the memory worker for a BeeQ hive. "
                "You have access to the user's persistent knowledge base. "
                "Answer using the provided memories when relevant. "
                "Be concise and precise."
            ),
            max_tokens=1024,
        )
        return response.content
