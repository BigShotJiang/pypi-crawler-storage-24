"""
Worker-Research — web search, document reading, information gathering.

Scope: read:web · search:* · read:docs

Actions réelles :
  - Recherche web via DuckDuckGo (zéro clé API)
  - Lecture de pages web
  - Cross-référence avec fichiers locaux ARCHE
  - Connexion arxiv pour papers scientifiques
"""

import httpx
import asyncio
from pathlib import Path
from .base import BaseWorker, WorkerResult


class ResearchWorker(BaseWorker):
    name          = "research"
    description   = "Web search, document reading, information gathering, analysis"
    default_scope = ["read:web", "search:*", "read:docs"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        try:
            # Étape 1 — chercher sur le web si la tâche l'implique
            web_results = ""
            search_keywords = self._extract_search_intent(task)
            if search_keywords:
                web_results = await self._search_web(search_keywords)

            # Étape 2 — synthèse LLM avec les résultats
            content = task
            if web_results:
                content = task + "\n\nWeb search results:\n" + web_results

            response = await self.providers.complete(
                messages=[{"role": "user", "content": content}],
                system=(
                    "You are a research specialist. Given a task and optionally web search results, "
                    "provide a clear, concise, factual response. "
                    "Cite sources when available. Be direct and precise. "
                    "If search results are provided, use them as your primary source."
                ),
                max_tokens=2048,
            )

            output = response.content
            artifact_id = self._record(
                action="search:web",
                success=True,
                input_data=task.encode(),
                output_data=output.encode(),
            )

            return WorkerResult(
                worker=self.name,
                action="search:web",
                success=True,
                output=output,
                artifacts=[artifact_id],
            )

        except Exception as e:
            self._record("search:web", success=False,
                        input_data=task.encode(), output_data=str(e).encode())
            return WorkerResult(
                worker=self.name, action="search:web",
                success=False, output="", error=str(e),
            )

    def _extract_search_intent(self, task: str) -> str:
        """Determine if task needs web search and extract keywords."""
        search_triggers = [
            "search", "find", "look up", "what is", "who is", "latest",
            "news", "current", "recent", "today", "cherche", "trouve",
            "qu'est-ce", "actualité", "récent", "nouveau", "dernier"
        ]
        task_lower = task.lower()
        if any(t in task_lower for t in search_triggers):
            # Extract first 8 words as search query
            words = task.split()[:8]
            return " ".join(words)
        return ""

    async def _search_web(self, query: str) -> str:
        """Search DuckDuckGo — zéro clé API requise."""
        try:
            async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
                # DuckDuckGo HTML search
                headers = {
                    "User-Agent": "Mozilla/5.0 (compatible; BeeQ/1.0)"
                }
                r = await client.get(
                    "https://html.duckduckgo.com/html/",
                    params={"q": query},
                    headers=headers,
                )
                if r.status_code != 200:
                    return ""

                # Parse résultats basiques
                text = r.text
                results = []
                # Extraction simple des snippets
                import re
                snippets = re.findall(
                    r'class="result__snippet"[^>]*>(.*?)</a>',
                    text, re.DOTALL
                )
                titles = re.findall(
                    r'class="result__a"[^>]*>(.*?)</a>',
                    text, re.DOTALL
                )

                for i, (title, snippet) in enumerate(zip(titles[:5], snippets[:5])):
                    # Nettoyer le HTML
                    title_clean = re.sub(r'<[^>]+>', '', title).strip()
                    snippet_clean = re.sub(r'<[^>]+>', '', snippet).strip()
                    if title_clean and snippet_clean:
                        results.append(f"{i+1}. {title_clean}\n   {snippet_clean}")

                return "\n\n".join(results) if results else ""

        except Exception as e:
            return f"[Search unavailable: {e}]"

    async def read_file(self, path: str) -> str:
        """Lire un fichier local (ARCHE)."""
        try:
            content = Path(path).read_text(encoding="utf-8", errors="ignore")
            return content[:5000]  # Limiter à 5KB
        except Exception as e:
            return f"[Cannot read {path}: {e}]"
