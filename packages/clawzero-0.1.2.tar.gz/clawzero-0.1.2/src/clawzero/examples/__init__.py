"""Packaged ClawZero example scripts."""
