"""
Output Aggregator for RWA Calculations.

Combines SA, IRB, and Slotting results with:
- Output floor application (Basel 3.1 only)
- Supporting factor tracking (CRR only)
- Summary generation by exposure class and approach

Pipeline position:
    SACalculator/IRBCalculator/SlottingCalculator -> OutputAggregator -> Pipeline output

Key responsibilities:
- Combine SA and IRB results into unified output
- Apply output floor (Basel 3.1: max(IRB RWA, 72.5% × SA RWA))
- Track supporting factor impact (CRR only)
- Generate summary statistics by class and approach

References:
- CRE99.1-8: Output floor (Basel 3.1)
- PS9/24 Ch.12: PRA output floor implementation
- CRR Art. 501: SME supporting factor
- CRR Art. 501a: Infrastructure supporting factor
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import polars as pl

from rwa_calc.contracts.bundles import (
    AggregatedResultBundle,
    ELPortfolioSummary,
    EquityResultBundle,
    IRBResultBundle,
    SAResultBundle,
    SlottingResultBundle,
)

if TYPE_CHECKING:
    from rwa_calc.contracts.config import CalculationConfig


# =============================================================================
# Error Types
# =============================================================================


@dataclass
class AggregationError:
    """Error during result aggregation."""

    error_type: str
    message: str
    exposure_reference: str | None = None


# =============================================================================
# Output Aggregator Implementation
# =============================================================================


class OutputAggregator:
    """
    Aggregate final RWA results from all calculators.

    Implements OutputAggregatorProtocol for:
    - Combining SA, IRB, and Slotting results
    - Applying output floor (Basel 3.1)
    - Tracking supporting factor impact (CRR)
    - Generating summaries by exposure class and approach

    Usage:
        aggregator = OutputAggregator()
        result = aggregator.aggregate_with_audit(
            sa_bundle=sa_results,
            irb_bundle=irb_results,
            slotting_bundle=slotting_results,
            config=config,
        )
    """

    def __init__(self) -> None:
        """Initialize output aggregator."""
        pass

    # =========================================================================
    # Public API
    # =========================================================================

    def aggregate(
        self,
        sa_results: pl.LazyFrame,
        irb_results: pl.LazyFrame,
        config: CalculationConfig,
    ) -> pl.LazyFrame:
        """
        Aggregate SA and IRB results into final output.

        Args:
            sa_results: Standardised Approach calculations
            irb_results: IRB approach calculations
            config: Calculation configuration

        Returns:
            Combined LazyFrame with all calculations
        """
        return self._combine_results(
            sa_results=sa_results,
            irb_results=irb_results,
            slotting_results=None,
            config=config,
        )

    def aggregate_with_audit(
        self,
        sa_bundle: SAResultBundle | None,
        irb_bundle: IRBResultBundle | None,
        slotting_bundle: SlottingResultBundle | None,
        config: CalculationConfig,
        equity_bundle: EquityResultBundle | None = None,
    ) -> AggregatedResultBundle:
        """
        Aggregate with full audit trail.

        Args:
            sa_bundle: SA calculation results bundle
            irb_bundle: IRB calculation results bundle
            slotting_bundle: Slotting calculation results bundle
            config: Calculation configuration
            equity_bundle: Equity calculation results bundle

        Returns:
            AggregatedResultBundle with full audit trail
        """
        errors: list[AggregationError] = []

        # Get result frames from bundles
        sa_results = sa_bundle.results if sa_bundle else None
        irb_results = irb_bundle.results if irb_bundle else None
        slotting_results = slotting_bundle.results if slotting_bundle else None
        equity_results = equity_bundle.results if equity_bundle else None

        # Combine all results
        combined = self._combine_results(
            sa_results=sa_results,
            irb_results=irb_results,
            slotting_results=slotting_results,
            equity_results=equity_results,
            config=config,
        )

        # Apply output floor (Basel 3.1 only)
        floor_impact = None
        if config.output_floor.enabled and irb_results is not None and sa_results is not None:
            combined, floor_impact = self._apply_floor_with_impact(
                combined,
                sa_results,
                config,
            )

        # Generate supporting factor impact (CRR only)
        supporting_factor_impact = None
        if config.supporting_factors.enabled and sa_results is not None:
            supporting_factor_impact = self._generate_supporting_factor_impact(sa_results)

        # Generate pre/post CRM summaries for regulatory reporting
        pre_crm_summary = self._generate_pre_crm_summary(combined)
        post_crm_detailed = self._generate_post_crm_detailed(combined)
        post_crm_summary = self._generate_post_crm_summary(post_crm_detailed)

        # Generate summaries from post-CRM detailed view (split rows for guarantees)
        summary_by_class = self._generate_summary_by_class(post_crm_detailed)
        summary_by_approach = self._generate_summary_by_approach(post_crm_detailed)

        # Compute portfolio-level EL summary with T2 credit cap (IRB only)
        el_summary = self._compute_el_portfolio_summary(irb_results)

        # Collect all errors
        all_errors = list(errors)
        if sa_bundle:
            all_errors.extend(sa_bundle.errors)
        if irb_bundle:
            all_errors.extend(irb_bundle.errors)
        if slotting_bundle:
            all_errors.extend(slotting_bundle.errors)
        if equity_bundle:
            all_errors.extend(equity_bundle.errors)

        return AggregatedResultBundle(
            results=combined,
            sa_results=sa_results,
            irb_results=irb_results,
            slotting_results=slotting_results,
            equity_results=equity_results,
            floor_impact=floor_impact,
            supporting_factor_impact=supporting_factor_impact,
            summary_by_class=summary_by_class,
            summary_by_approach=summary_by_approach,
            pre_crm_summary=pre_crm_summary,
            post_crm_detailed=post_crm_detailed,
            post_crm_summary=post_crm_summary,
            el_summary=el_summary,
            errors=all_errors,
        )

    def apply_output_floor(
        self,
        irb_rwa: pl.LazyFrame,
        sa_equivalent_rwa: pl.LazyFrame,
        config: CalculationConfig,
    ) -> pl.LazyFrame:
        """
        Apply output floor to IRB RWA (Basel 3.1 only).

        Final RWA = max(IRB RWA, SA RWA × floor_percentage)

        Args:
            irb_rwa: IRB RWA before floor
            sa_equivalent_rwa: Equivalent SA RWA for comparison
            config: Calculation configuration

        Returns:
            LazyFrame with floor-adjusted RWA
        """
        if not config.output_floor.enabled:
            return irb_rwa

        # Get floor percentage (supports transitional schedule)
        floor_pct = float(config.output_floor.get_floor_percentage(config.reporting_date))

        # Join IRB and SA results on exposure_reference
        floored = irb_rwa.join(
            sa_equivalent_rwa.select(
                [
                    pl.col("exposure_reference"),
                    pl.col(
                        "rwa_post_factor"
                        if "rwa_post_factor" in sa_equivalent_rwa.collect_schema().names()
                        else "rwa"
                    ).alias("sa_rwa"),
                ]
            ),
            on="exposure_reference",
            how="left",
        )

        # Get IRB RWA column name
        irb_rwa_col = "rwa" if "rwa" in floored.collect_schema().names() else "rwa_post_factor"

        # Apply floor
        floored = floored.with_columns(
            [
                # Floor RWA = SA RWA × floor percentage
                (pl.col("sa_rwa").fill_null(0.0) * floor_pct).alias("floor_rwa"),
                pl.lit(floor_pct).alias("output_floor_pct"),
            ]
        ).with_columns(
            [
                # Is floor binding?
                (pl.col("floor_rwa") > pl.col(irb_rwa_col)).alias("is_floor_binding"),
                # Floor impact (additional RWA)
                pl.max_horizontal(
                    pl.lit(0.0),
                    pl.col("floor_rwa") - pl.col(irb_rwa_col),
                ).alias("floor_impact_rwa"),
                # Final RWA = max(IRB RWA, floor RWA)
                pl.max_horizontal(
                    pl.col(irb_rwa_col),
                    pl.col("floor_rwa"),
                ).alias("rwa_final"),
            ]
        )

        return floored

    # =========================================================================
    # Private Methods - Result Combination
    # =========================================================================

    def _combine_results(
        self,
        sa_results: pl.LazyFrame | None,
        irb_results: pl.LazyFrame | None,
        slotting_results: pl.LazyFrame | None,
        config: CalculationConfig,
        equity_results: pl.LazyFrame | None = None,
    ) -> pl.LazyFrame:
        """
        Combine SA, IRB, Slotting, and Equity results into a unified LazyFrame.

        Adds approach identification and standardizes column names.
        """
        frames = []

        if sa_results is not None:
            sa_prepared = self._prepare_sa_results(sa_results)
            frames.append(sa_prepared)

        if irb_results is not None:
            irb_prepared = self._prepare_irb_results(irb_results)
            frames.append(irb_prepared)

        if slotting_results is not None:
            slotting_prepared = self._prepare_slotting_results(slotting_results)
            frames.append(slotting_prepared)

        if equity_results is not None:
            equity_prepared = self._prepare_equity_results(equity_results)
            frames.append(equity_prepared)

        if not frames:
            # Return empty frame with expected schema
            return self._create_empty_result_frame()

        # Combine all frames
        combined = frames[0] if len(frames) == 1 else pl.concat(frames, how="diagonal_relaxed")

        return combined

    def _prepare_sa_results(self, sa_results: pl.LazyFrame) -> pl.LazyFrame:
        """Prepare SA results with standard columns."""
        schema = sa_results.collect_schema()

        # Determine RWA column
        rwa_col = "rwa_post_factor" if "rwa_post_factor" in schema.names() else "rwa"

        return sa_results.with_columns(
            [
                pl.lit("SA").alias("approach_applied"),
                pl.col(rwa_col).alias("rwa_final"),
            ]
        )

    def _prepare_irb_results(self, irb_results: pl.LazyFrame) -> pl.LazyFrame:
        """Prepare IRB results with standard columns."""
        schema = irb_results.collect_schema()
        cols = schema.names()

        # Determine base approach expression
        base_approach_expr = pl.col("approach") if "approach" in cols else pl.lit("FIRB")

        # Post-CRM approach: fully SA-guaranteed IRB exposures report as "standardised"
        has_guarantee_cols = "guarantor_approach" in cols and "guarantee_ratio" in cols
        if has_guarantee_cols:
            approach_expr = (
                pl.when((pl.col("guarantor_approach") == "sa") & (pl.col("guarantee_ratio") >= 1.0))
                .then(pl.lit("standardised"))
                .otherwise(base_approach_expr)
            )
        else:
            approach_expr = base_approach_expr

        # Determine RWA column
        rwa_col = "rwa" if "rwa" in cols else "rwa_post_factor"

        return irb_results.with_columns(
            [
                approach_expr.alias("approach_applied"),
                pl.col(rwa_col).alias("rwa_final"),
            ]
        )

    def _prepare_slotting_results(self, slotting_results: pl.LazyFrame) -> pl.LazyFrame:
        """Prepare Slotting results with standard columns."""
        schema = slotting_results.collect_schema()

        # Determine RWA column
        rwa_col = "rwa" if "rwa" in schema.names() else "rwa_post_factor"

        return slotting_results.with_columns(
            [
                pl.lit("SLOTTING").alias("approach_applied"),
                pl.col(rwa_col).alias("rwa_final"),
            ]
        )

    def _prepare_equity_results(self, equity_results: pl.LazyFrame) -> pl.LazyFrame:
        """Prepare Equity results with standard columns."""
        schema = equity_results.collect_schema()

        # Determine RWA column
        rwa_col = "rwa" if "rwa" in schema.names() else "rwa_final"

        # Add exposure_class if not present
        result = equity_results
        if "exposure_class" not in schema.names():
            result = result.with_columns(
                [
                    pl.lit("equity").alias("exposure_class"),
                ]
            )

        return result.with_columns(
            [
                pl.lit("EQUITY").alias("approach_applied"),
                pl.col(rwa_col).alias("rwa_final"),
            ]
        )

    def _create_empty_result_frame(self) -> pl.LazyFrame:
        """Create empty result frame with expected schema."""
        return pl.LazyFrame(
            {
                "exposure_reference": pl.Series([], dtype=pl.String),
                "approach_applied": pl.Series([], dtype=pl.String),
                "exposure_class": pl.Series([], dtype=pl.String),
                "ead_final": pl.Series([], dtype=pl.Float64),
                "risk_weight": pl.Series([], dtype=pl.Float64),
                "rwa_final": pl.Series([], dtype=pl.Float64),
            }
        )

    # =========================================================================
    # Private Methods - Output Floor
    # =========================================================================

    def _apply_floor_with_impact(
        self,
        combined: pl.LazyFrame,
        sa_results: pl.LazyFrame,
        config: CalculationConfig,
    ) -> tuple[pl.LazyFrame, pl.LazyFrame]:
        """
        Apply output floor and generate impact analysis.

        Returns:
            Tuple of (floored results, floor impact analysis)
        """
        # Get floor percentage
        floor_pct = float(config.output_floor.get_floor_percentage(config.reporting_date))

        # Ensure combined has rwa_final column
        combined_schema = combined.collect_schema()
        if "rwa_final" not in combined_schema.names():
            if "rwa" in combined_schema.names():
                combined = combined.with_columns([pl.col("rwa").alias("rwa_final")])
            elif "rwa_post_factor" in combined_schema.names():
                combined = combined.with_columns([pl.col("rwa_post_factor").alias("rwa_final")])
            else:
                combined = combined.with_columns([pl.lit(0.0).alias("rwa_final")])

        # Store pre-floor RWA for impact calculation
        combined = combined.with_columns(
            [
                pl.col("rwa_final").alias("rwa_pre_floor"),
            ]
        )

        # Get SA RWA for each exposure. If calculate_unified already stored
        # sa_rwa inline (single-pass path), use it directly. Otherwise join
        # from the separate SA results frame (aggregate_with_audit path).
        combined_schema = combined.collect_schema()
        if "sa_rwa" in combined_schema.names():
            result = combined
        else:
            sa_schema = sa_results.collect_schema()
            if "rwa_post_factor" in sa_schema.names():
                sa_rwa_col = "rwa_post_factor"
            elif "rwa" in sa_schema.names():
                sa_rwa_col = "rwa"
            else:
                return combined, self._create_empty_floor_impact_frame()

            sa_rwa = sa_results.select(
                [
                    pl.col("exposure_reference"),
                    pl.col(sa_rwa_col).alias("sa_rwa"),
                ]
            )
            result = combined.join(
                sa_rwa,
                on="exposure_reference",
                how="left",
                suffix="_sa",
            )

        # IRB approaches: "foundation_irb"/"advanced_irb" from ApproachType enum,
        # "FIRB" from aggregator fallback when 'approach' column is missing
        irb_approaches = ["foundation_irb", "advanced_irb", "FIRB"]

        # Apply floor only to IRB exposures
        result = (
            result.with_columns(
                [
                    # Calculate floor RWA
                    (pl.col("sa_rwa").fill_null(0.0) * floor_pct).alias("floor_rwa"),
                    pl.lit(floor_pct).alias("output_floor_pct"),
                ]
            )
            .with_columns(
                [
                    # Is floor binding? (only for IRB approaches)
                    pl.when(pl.col("approach_applied").is_in(irb_approaches))
                    .then(pl.col("floor_rwa") > pl.col("rwa_pre_floor"))
                    .otherwise(pl.lit(False))
                    .alias("is_floor_binding"),
                    # Apply floor to final RWA for IRB exposures
                    pl.when(pl.col("approach_applied").is_in(irb_approaches))
                    .then(pl.max_horizontal(pl.col("rwa_pre_floor"), pl.col("floor_rwa")))
                    .otherwise(pl.col("rwa_pre_floor"))
                    .alias("rwa_final"),
                ]
            )
            .with_columns(
                [
                    # Floor impact (additional RWA from floor)
                    pl.when(pl.col("is_floor_binding"))
                    .then(pl.col("floor_rwa") - pl.col("rwa_pre_floor"))
                    .otherwise(pl.lit(0.0))
                    .alias("floor_impact_rwa"),
                ]
            )
        )

        # Generate floor impact analysis
        result_schema = result.collect_schema()
        floor_impact = result.select(
            [
                pl.col("exposure_reference"),
                pl.col("approach_applied"),
                pl.col("exposure_class")
                if "exposure_class" in result_schema.names()
                else pl.lit(None).cast(pl.String).alias("exposure_class"),
                pl.col("rwa_pre_floor"),
                pl.col("floor_rwa"),
                pl.col("is_floor_binding"),
                pl.col("floor_impact_rwa"),
                pl.col("rwa_final").alias("rwa_post_floor"),
                pl.col("output_floor_pct"),
            ]
        ).filter(pl.col("approach_applied").is_in(irb_approaches))

        return result, floor_impact

    def _create_empty_floor_impact_frame(self) -> pl.LazyFrame:
        """Create empty floor impact frame with expected schema."""
        return pl.LazyFrame(
            {
                "exposure_reference": pl.Series([], dtype=pl.String),
                "approach_applied": pl.Series([], dtype=pl.String),
                "exposure_class": pl.Series([], dtype=pl.String),
                "rwa_pre_floor": pl.Series([], dtype=pl.Float64),
                "floor_rwa": pl.Series([], dtype=pl.Float64),
                "is_floor_binding": pl.Series([], dtype=pl.Boolean),
                "floor_impact_rwa": pl.Series([], dtype=pl.Float64),
                "rwa_post_floor": pl.Series([], dtype=pl.Float64),
                "output_floor_pct": pl.Series([], dtype=pl.Float64),
            }
        )

    # =========================================================================
    # Private Methods - Supporting Factor Impact
    # =========================================================================

    def _generate_supporting_factor_impact(
        self,
        sa_results: pl.LazyFrame,
    ) -> pl.LazyFrame:
        """
        Generate supporting factor impact analysis.

        Shows the RWA reduction from SME and infrastructure factors.
        """
        schema = sa_results.collect_schema()

        # Check for supporting factor columns
        has_sf = "supporting_factor" in schema.names()
        has_applied = "supporting_factor_applied" in schema.names()
        has_pre = "rwa_pre_factor" in schema.names()
        has_post = "rwa_post_factor" in schema.names()

        if not (has_sf and has_pre and has_post):
            # Return empty impact frame
            return pl.LazyFrame(
                {
                    "exposure_reference": pl.Series([], dtype=pl.String),
                    "supporting_factor": pl.Series([], dtype=pl.Float64),
                    "rwa_pre_factor": pl.Series([], dtype=pl.Float64),
                    "rwa_post_factor": pl.Series([], dtype=pl.Float64),
                    "supporting_factor_impact": pl.Series([], dtype=pl.Float64),
                    "supporting_factor_applied": pl.Series([], dtype=pl.Boolean),
                }
            )

        # Calculate impact
        impact = sa_results.select(
            [
                pl.col("exposure_reference"),
                pl.col("exposure_class")
                if "exposure_class" in schema.names()
                else pl.lit(None).alias("exposure_class"),
                pl.col("is_sme") if "is_sme" in schema.names() else pl.lit(False).alias("is_sme"),
                pl.col("is_infrastructure")
                if "is_infrastructure" in schema.names()
                else pl.lit(False).alias("is_infrastructure"),
                pl.col("ead_final")
                if "ead_final" in schema.names()
                else pl.lit(0.0).alias("ead_final"),
                pl.col("supporting_factor"),
                pl.col("rwa_pre_factor"),
                pl.col("rwa_post_factor"),
                (pl.col("rwa_pre_factor") - pl.col("rwa_post_factor")).alias(
                    "supporting_factor_impact"
                ),
                pl.col("supporting_factor_applied")
                if has_applied
                else (pl.col("supporting_factor") < 1.0).alias("supporting_factor_applied"),
            ]
        ).filter(pl.col("supporting_factor_applied"))

        return impact

    # =========================================================================
    # Private Methods - Summary Generation
    # =========================================================================

    def _generate_summary_by_class(
        self,
        results: pl.LazyFrame,
    ) -> pl.LazyFrame:
        """
        Generate RWA summary by exposure class.

        Uses post-CRM reporting columns when available, so guaranteed
        portions are counted under the guarantor's exposure class.

        Aggregates:
        - Total EAD
        - Total RWA
        - Average risk weight
        - Exposure count
        - Floor binding count (if applicable)
        """
        schema = results.collect_schema()
        cols = schema.names()

        # Use post-CRM reporting columns when available, otherwise fall back
        has_reporting = "reporting_exposure_class" in cols and "reporting_ead" in cols
        ead_col = (
            "reporting_ead" if has_reporting else ("ead_final" if "ead_final" in cols else None)
        )
        rw_col = (
            "reporting_rw"
            if (has_reporting and "reporting_rw" in cols)
            else ("risk_weight" if "risk_weight" in cols else None)
        )
        group_col = (
            "reporting_exposure_class"
            if has_reporting
            else ("exposure_class" if "exposure_class" in cols else None)
        )

        # Build aggregation expressions
        agg_exprs = [
            pl.col(ead_col).sum().alias("total_ead") if ead_col else pl.lit(0.0).alias("total_ead"),
            pl.len().alias("exposure_count"),
        ]

        # RWA: use reporting_ead * reporting_rw for post-CRM, else rwa_final
        if has_reporting and rw_col:
            agg_exprs.append(
                (pl.col(ead_col) * pl.col(rw_col)).sum().alias("total_rwa"),
            )
        elif "rwa_final" in cols:
            agg_exprs.append(pl.col("rwa_final").sum().alias("total_rwa"))
        else:
            agg_exprs.append(pl.lit(0.0).alias("total_rwa"))

        # Add weighted average risk weight if possible
        if ead_col and rw_col:
            agg_exprs.append(
                (pl.col(rw_col) * pl.col(ead_col)).sum().alias("_weighted_rw"),
            )

        # Add floor binding count if applicable
        if "is_floor_binding" in cols:
            agg_exprs.append(
                pl.col("is_floor_binding").sum().cast(pl.UInt32).alias("floor_binding_count"),
            )

        # Group by exposure class
        if group_col:
            summary = results.group_by(group_col).agg(agg_exprs)
            # Normalize column name for downstream consumers
            if group_col != "exposure_class":
                summary = summary.rename({group_col: "exposure_class"})
        else:
            summary = results.select(agg_exprs).with_columns(
                [
                    pl.lit("ALL").alias("exposure_class"),
                ]
            )

        # Calculate average risk weight
        if ead_col and rw_col:
            summary = summary.with_columns(
                [
                    pl.when(pl.col("total_ead") > 0)
                    .then(pl.col("_weighted_rw") / pl.col("total_ead"))
                    .otherwise(pl.lit(0.0))
                    .alias("avg_risk_weight"),
                ]
            ).drop("_weighted_rw")

        return summary

    def _generate_summary_by_approach(
        self,
        results: pl.LazyFrame,
    ) -> pl.LazyFrame:
        """
        Generate RWA summary by calculation approach.

        Uses post-CRM reporting columns when available, so guaranteed
        portions are counted under the guarantor's approach.

        Aggregates:
        - Total EAD
        - Total RWA
        - Exposure count
        - Floor impact (if applicable)
        """
        schema = results.collect_schema()
        cols = schema.names()

        # Use post-CRM reporting columns when available
        has_reporting = "reporting_approach" in cols and "reporting_ead" in cols
        ead_col = (
            "reporting_ead" if has_reporting else ("ead_final" if "ead_final" in cols else None)
        )
        rw_col = "reporting_rw" if (has_reporting and "reporting_rw" in cols) else None
        group_col = (
            "reporting_approach"
            if has_reporting
            else ("approach_applied" if "approach_applied" in cols else None)
        )

        # Build aggregation expressions
        agg_exprs = [
            pl.col(ead_col).sum().alias("total_ead") if ead_col else pl.lit(0.0).alias("total_ead"),
            pl.len().alias("exposure_count"),
        ]

        # RWA: use reporting_ead * reporting_rw for post-CRM, else rwa_final
        if has_reporting and rw_col:
            agg_exprs.append(
                (pl.col(ead_col) * pl.col(rw_col)).sum().alias("total_rwa"),
            )
        elif "rwa_final" in cols:
            agg_exprs.append(pl.col("rwa_final").sum().alias("total_rwa"))
        else:
            agg_exprs.append(pl.lit(0.0).alias("total_rwa"))

        # Add floor impact if applicable
        if "floor_impact_rwa" in cols:
            agg_exprs.append(
                pl.col("floor_impact_rwa").sum().alias("total_floor_impact"),
            )

        # Add expected loss for IRB if available
        if "expected_loss" in cols:
            agg_exprs.append(
                pl.col("expected_loss").sum().alias("total_expected_loss"),
            )

        # Add EL shortfall/excess for IRB if available
        if "el_shortfall" in cols:
            agg_exprs.append(
                pl.col("el_shortfall").sum().alias("total_el_shortfall"),
            )
        if "el_excess" in cols:
            agg_exprs.append(
                pl.col("el_excess").sum().alias("total_el_excess"),
            )

        # Group by approach
        if group_col:
            summary = results.group_by(group_col).agg(agg_exprs)
            # Normalize column name for downstream consumers
            if group_col != "approach_applied":
                summary = summary.rename({group_col: "approach_applied"})
        else:
            summary = results.select(agg_exprs).with_columns(
                [
                    pl.lit("ALL").alias("approach_applied"),
                ]
            )

        return summary

    # =========================================================================
    # Private Methods - EL Portfolio Summary
    # =========================================================================

    # T2 credit cap rate per CRR Art. 62(d): 0.6% of IRB credit-risk RWA.
    _T2_CREDIT_CAP_RATE = 0.006

    def _compute_el_portfolio_summary(
        self,
        irb_results: pl.LazyFrame | None,
    ) -> ELPortfolioSummary | None:
        """
        Compute portfolio-level EL summary with T2 credit cap.

        Aggregates per-exposure EL shortfall/excess across all IRB exposures
        and applies the T2 credit cap per CRR Art. 62(d).

        Args:
            irb_results: IRB results LazyFrame with el_shortfall/el_excess columns

        Returns:
            ELPortfolioSummary if IRB results have EL columns, None otherwise
        """
        if irb_results is None:
            return None

        cols = irb_results.collect_schema().names()
        if "el_shortfall" not in cols or "el_excess" not in cols:
            return None

        # Determine available column names
        rwa_col = "rwa_post_factor" if "rwa_post_factor" in cols else "rwa_final"
        has_el = "expected_loss" in cols
        has_provisions = "provision_allocated" in cols

        # Build aggregation expressions
        agg_exprs = [
            pl.col("el_shortfall").sum().alias("total_el_shortfall"),
            pl.col("el_excess").sum().alias("total_el_excess"),
            pl.col(rwa_col).sum().alias("total_irb_rwa"),
        ]
        if has_el:
            agg_exprs.append(pl.col("expected_loss").sum().alias("total_expected_loss"))
        if has_provisions:
            agg_exprs.append(
                pl.col("provision_allocated").sum().alias("total_provisions_allocated")
            )

        # Single collect for all aggregations
        agg_df = irb_results.select(agg_exprs).collect()

        total_el_shortfall = float(agg_df["total_el_shortfall"][0] or 0.0)
        total_el_excess = float(agg_df["total_el_excess"][0] or 0.0)
        total_irb_rwa = float(agg_df["total_irb_rwa"][0] or 0.0)
        total_expected_loss = float(agg_df["total_expected_loss"][0] or 0.0) if has_el else 0.0
        total_provisions = (
            float(agg_df["total_provisions_allocated"][0] or 0.0) if has_provisions else 0.0
        )

        # T2 credit cap: 0.6% of total IRB RWA (CRR Art. 62(d))
        t2_credit_cap = total_irb_rwa * self._T2_CREDIT_CAP_RATE
        t2_credit = min(total_el_excess, t2_credit_cap)

        # EL shortfall deduction: 50% CET1 + 50% T2 (CRR Art. 159)
        cet1_deduction = total_el_shortfall * 0.5
        t2_deduction = total_el_shortfall * 0.5

        return ELPortfolioSummary(
            total_expected_loss=total_expected_loss,
            total_provisions_allocated=total_provisions,
            total_el_shortfall=total_el_shortfall,
            total_el_excess=total_el_excess,
            total_irb_rwa=total_irb_rwa,
            t2_credit_cap=t2_credit_cap,
            t2_credit=t2_credit,
            cet1_deduction=cet1_deduction,
            t2_deduction=t2_deduction,
        )

    # =========================================================================
    # Private Methods - Pre/Post CRM Reporting
    # =========================================================================

    def _generate_pre_crm_summary(
        self,
        results: pl.LazyFrame,
    ) -> pl.LazyFrame:
        """
        Generate summary grouped by pre-CRM exposure class.

        Shows exposures under their ORIGINAL risk class (before guarantee substitution).
        This is the "gross" regulatory view.

        Args:
            results: Final calculation results

        Returns:
            LazyFrame with pre-CRM summary by original exposure class
        """
        schema = results.collect_schema()
        cols = schema.names()

        # Check if pre-CRM columns exist
        if "pre_crm_exposure_class" not in cols:
            # No pre-CRM data, return empty
            return pl.LazyFrame(
                {
                    "pre_crm_exposure_class": pl.Series([], dtype=pl.String),
                    "total_ead": pl.Series([], dtype=pl.Float64),
                    "total_rwa_blended": pl.Series([], dtype=pl.Float64),
                    "exposure_count": pl.Series([], dtype=pl.UInt32),
                }
            )

        ead_col = "ead_final" if "ead_final" in cols else "ead"
        rwa_col = "rwa_final" if "rwa_final" in cols else "rwa"

        # Build aggregation expressions
        agg_exprs = [
            pl.col(ead_col).sum().alias("total_ead"),
            pl.col(rwa_col).sum().alias("total_rwa_blended"),
            pl.len().alias("exposure_count"),
        ]

        # Add pre-CRM RWA if available (what RWA would be without guarantees)
        if "pre_crm_risk_weight" in cols:
            agg_exprs.append(
                (pl.col(ead_col) * pl.col("pre_crm_risk_weight")).sum().alias("total_rwa_pre_crm"),
            )

        # Add guaranteed exposure counts
        if "is_guaranteed" in cols:
            agg_exprs.append(
                pl.col("is_guaranteed").sum().cast(pl.UInt32).alias("guaranteed_count"),
            )

        return results.group_by("pre_crm_exposure_class").agg(agg_exprs)

    def _generate_post_crm_detailed(
        self,
        results: pl.LazyFrame,
    ) -> pl.LazyFrame:
        """
        Generate detailed view with guaranteed exposures split into two rows.

        For each guaranteed exposure:
          Row 1: Unguaranteed portion -> original counterparty, original exposure class
          Row 2: Guaranteed portion -> guarantor counterparty, guarantor exposure class

        For non-guaranteed exposures:
          Single row -> original counterparty, original exposure class

        Args:
            results: Final calculation results

        Returns:
            LazyFrame with split rows for guaranteed exposures
        """
        schema = results.collect_schema()
        cols = schema.names()

        # Determine column names with fallbacks
        ead_col = "ead_final" if "ead_final" in cols else ("ead" if "ead" in cols else None)
        counterparty_col = "counterparty_reference" if "counterparty_reference" in cols else None
        exposure_class_col = "exposure_class" if "exposure_class" in cols else None
        rw_col = "risk_weight" if "risk_weight" in cols else None

        # Check if minimum required columns exist
        if not ead_col or not exposure_class_col:
            # Cannot generate detailed view without basic columns
            return pl.LazyFrame(
                {
                    "reporting_counterparty": pl.Series([], dtype=pl.String),
                    "reporting_exposure_class": pl.Series([], dtype=pl.String),
                    "reporting_ead": pl.Series([], dtype=pl.Float64),
                    "reporting_rw": pl.Series([], dtype=pl.Float64),
                    "reporting_approach": pl.Series([], dtype=pl.String),
                    "crm_portion_type": pl.Series([], dtype=pl.String),
                }
            )

        # Check if guarantee columns exist
        required_cols = ["is_guaranteed", "guaranteed_portion", "unguaranteed_portion"]
        has_guarantee_data = all(col in cols for col in required_cols)

        if not has_guarantee_data:
            # No guarantee data, return simplified results with reporting columns
            counterparty_expr = (
                pl.col(counterparty_col) if counterparty_col else pl.lit(None).cast(pl.String)
            )
            rw_expr = pl.col(rw_col) if rw_col else pl.lit(1.0)
            approach_expr = (
                pl.col("approach_applied")
                if "approach_applied" in cols
                else pl.lit(None).cast(pl.String)
            )

            return results.with_columns(
                [
                    counterparty_expr.alias("reporting_counterparty"),
                    pl.col(exposure_class_col).alias("reporting_exposure_class"),
                    pl.col(ead_col).alias("reporting_ead"),
                    rw_expr.alias("reporting_rw"),
                    approach_expr.alias("reporting_approach"),
                    pl.lit("original").alias("crm_portion_type"),
                ]
            )

        # Get pre-CRM risk weight column (fallback to risk_weight for non-guaranteed)
        pre_crm_rw_col = (
            "pre_crm_risk_weight" if "pre_crm_risk_weight" in cols else (rw_col if rw_col else None)
        )
        guarantor_rw_col = (
            "guarantor_rw" if "guarantor_rw" in cols else (rw_col if rw_col else None)
        )

        # Build expressions with fallbacks
        counterparty_expr = (
            pl.col(counterparty_col) if counterparty_col else pl.lit(None).cast(pl.String)
        )
        rw_expr = pl.col(rw_col) if rw_col else pl.lit(1.0)
        pre_crm_rw_expr = pl.col(pre_crm_rw_col) if pre_crm_rw_col else pl.lit(1.0)
        guarantor_rw_expr = pl.col(guarantor_rw_col) if guarantor_rw_col else pl.lit(1.0)

        # Approach expression for reporting
        has_approach = "approach_applied" in cols
        approach_expr = pl.col("approach_applied") if has_approach else pl.lit(None).cast(pl.String)
        has_guarantor_approach = "guarantor_approach" in cols

        # For guaranteed portion: use "standardised" when guarantor is SA, else original
        if has_guarantor_approach and has_approach:
            guaranteed_approach_expr = (
                pl.when(pl.col("guarantor_approach") == "sa")
                .then(pl.lit("standardised"))
                .otherwise(pl.col("approach_applied"))
            )
        else:
            guaranteed_approach_expr = approach_expr

        # Non-guaranteed exposures (single row)
        non_guaranteed = results.filter(~pl.col("is_guaranteed")).with_columns(
            [
                counterparty_expr.alias("reporting_counterparty"),
                pl.col(exposure_class_col).alias("reporting_exposure_class"),
                pl.col(ead_col).alias("reporting_ead"),
                rw_expr.alias("reporting_rw"),
                approach_expr.alias("reporting_approach"),
                pl.lit("original").alias("crm_portion_type"),
            ]
        )

        # Guaranteed exposures - unguaranteed portion
        pre_crm_class_col = (
            "pre_crm_exposure_class" if "pre_crm_exposure_class" in cols else exposure_class_col
        )
        guar_unguar_portion = results.filter(pl.col("is_guaranteed")).with_columns(
            [
                counterparty_expr.alias("reporting_counterparty"),
                pl.col(pre_crm_class_col).alias("reporting_exposure_class"),
                pl.col("unguaranteed_portion").alias("reporting_ead"),
                pre_crm_rw_expr.alias("reporting_rw"),
                approach_expr.alias("reporting_approach"),
                pl.lit("unguaranteed").alias("crm_portion_type"),
            ]
        )

        # Guaranteed exposures - guaranteed portion
        guarantor_ref_col = (
            "guarantor_reference" if "guarantor_reference" in cols else counterparty_col
        )
        post_crm_class_col = (
            "post_crm_exposure_class_guaranteed"
            if "post_crm_exposure_class_guaranteed" in cols
            else exposure_class_col
        )

        guarantor_ref_expr = (
            pl.col(guarantor_ref_col) if guarantor_ref_col else pl.lit(None).cast(pl.String)
        )

        guar_guar_portion = results.filter(pl.col("is_guaranteed")).with_columns(
            [
                guarantor_ref_expr.alias("reporting_counterparty"),
                pl.col(post_crm_class_col).alias("reporting_exposure_class"),
                pl.col("guaranteed_portion").alias("reporting_ead"),
                guarantor_rw_expr.alias("reporting_rw"),
                guaranteed_approach_expr.alias("reporting_approach"),
                pl.lit("guaranteed").alias("crm_portion_type"),
            ]
        )

        # Combine all rows
        return pl.concat(
            [non_guaranteed, guar_unguar_portion, guar_guar_portion], how="diagonal_relaxed"
        )

    def _generate_post_crm_summary(
        self,
        detailed: pl.LazyFrame,
    ) -> pl.LazyFrame:
        """
        Aggregate post-CRM detailed view by exposure class.

        Shows RWA under POST-CRM exposure classes where guaranteed portions
        are reported under the guarantor's exposure class.

        Args:
            detailed: Post-CRM detailed LazyFrame from _generate_post_crm_detailed

        Returns:
            LazyFrame with post-CRM summary by effective exposure class
        """
        schema = detailed.collect_schema()
        cols = schema.names()

        # Check if required columns exist
        if "reporting_exposure_class" not in cols:
            return pl.LazyFrame(
                {
                    "reporting_exposure_class": pl.Series([], dtype=pl.String),
                    "total_ead": pl.Series([], dtype=pl.Float64),
                    "total_rwa": pl.Series([], dtype=pl.Float64),
                    "exposure_count": pl.Series([], dtype=pl.UInt32),
                }
            )

        return detailed.group_by("reporting_exposure_class").agg(
            [
                pl.col("reporting_ead").sum().alias("total_ead"),
                (pl.col("reporting_ead") * pl.col("reporting_rw")).sum().alias("total_rwa"),
                pl.len().alias("exposure_count"),
                pl.col("crm_portion_type")
                .filter(pl.col("crm_portion_type") == "guaranteed")
                .len()
                .alias("guaranteed_portions"),
            ]
        )


# =============================================================================
# Factory Function
# =============================================================================


def create_output_aggregator() -> OutputAggregator:
    """
    Create an OutputAggregator instance.

    Returns:
        OutputAggregator ready for use
    """
    return OutputAggregator()
