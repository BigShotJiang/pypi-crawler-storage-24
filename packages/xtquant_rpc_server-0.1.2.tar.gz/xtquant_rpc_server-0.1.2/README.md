# xtquant-rpc-server

Windows gRPC host for `xtquant` capability domains.

Current scope:

- token-protected gRPC server
- `xtdata` domain registration
- explicit whitelist for synchronous read-oriented interfaces

Typical usage:

```bash
xtquant-rpc-server --host 0.0.0.0 --port 50051 --token your-token
```
