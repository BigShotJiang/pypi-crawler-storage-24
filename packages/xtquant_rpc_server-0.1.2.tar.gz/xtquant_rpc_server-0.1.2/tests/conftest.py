from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
CLIENT_SRC = ROOT / "packages" / "xtquant-rpc-client" / "src"
SERVER_SRC = ROOT / "packages" / "xtquant-rpc-server" / "src"

for path in [str(CLIENT_SRC), str(SERVER_SRC)]:
    if path not in sys.path:
        sys.path.insert(0, path)
