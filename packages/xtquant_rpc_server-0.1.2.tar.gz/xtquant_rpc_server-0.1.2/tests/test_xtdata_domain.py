from __future__ import annotations

import pytest

from xtquant_rpc_server.domains_xtdata import XtdataDomainHandler
from xtquant_rpc_server.exceptions import MethodNotSupportedError


class FakeXtdata:
    def __init__(self) -> None:
        self.calls = []

    def connect(self, ip="", port=None):
        self.calls.append(("connect", ip, port))
        return True

    def get_trading_dates(self, market, start_time="", end_time="", count=-1):
        self.calls.append(("get_trading_dates", market, start_time, end_time, count))
        return [20260320, 20260321]


def test_xtdata_handler_calls_allowed_method() -> None:
    backend = FakeXtdata()
    handler = XtdataDomainHandler(xtdata_module=backend, xtdata_ip="127.0.0.1", xtdata_port=58610)

    result = handler.invoke("get_trading_dates", ["SH"], {"count": 2})

    assert result == [20260320, 20260321]
    assert backend.calls[0] == ("connect", "127.0.0.1", 58610)
    assert backend.calls[1] == ("get_trading_dates", "SH", "", "", 2)


def test_xtdata_handler_rejects_unsupported_method() -> None:
    handler = XtdataDomainHandler(xtdata_module=FakeXtdata())

    with pytest.raises(MethodNotSupportedError):
        handler.invoke("subscribe_quote", [], {})
