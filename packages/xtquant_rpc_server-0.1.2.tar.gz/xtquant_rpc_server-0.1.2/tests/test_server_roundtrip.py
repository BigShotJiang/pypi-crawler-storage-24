from __future__ import annotations

import pytest

from xtquant_rpc_client import XtquantRpcClient
from xtquant_rpc_client.exceptions import AuthenticationError, DomainNotSupportedError
from xtquant_rpc_server.domain_registry import DomainRegistry
from xtquant_rpc_server.service import create_grpc_server


class EchoDomain:
    def invoke(self, method, args, kwargs):
        if method == "mirror":
            return {"args": args, "kwargs": kwargs}
        raise RuntimeError("unexpected method")


def test_grpc_roundtrip_and_authentication() -> None:
    registry = DomainRegistry()
    registry.register("echo", EchoDomain())
    server = create_grpc_server(registry, token="secret")
    port = server.add_insecure_port("127.0.0.1:0")
    server.start()

    try:
        client = XtquantRpcClient(host="127.0.0.1", port=port, token="secret", timeout=5.0)
        result = client.invoke("echo", "mirror", 1, 2, key="value")
        assert result == {"args": [1, 2], "kwargs": {"key": "value"}}

        bad_client = XtquantRpcClient(host="127.0.0.1", port=port, token="wrong", timeout=5.0)
        with pytest.raises(AuthenticationError):
            bad_client.invoke("echo", "mirror")
    finally:
        server.stop(grace=None)


def test_unknown_domain_maps_to_client_exception() -> None:
    registry = DomainRegistry()
    server = create_grpc_server(registry, token="secret")
    port = server.add_insecure_port("127.0.0.1:0")
    server.start()

    try:
        client = XtquantRpcClient(host="127.0.0.1", port=port, token="secret", timeout=5.0)
        with pytest.raises(DomainNotSupportedError):
            client.invoke("missing", "mirror")
    finally:
        server.stop(grace=None)
