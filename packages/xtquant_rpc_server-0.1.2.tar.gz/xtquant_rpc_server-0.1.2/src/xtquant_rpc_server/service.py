from __future__ import annotations

import traceback
from concurrent import futures

import grpc

from xtquant_rpc.v1 import service_pb2, service_pb2_grpc

from .domain_registry import DomainRegistry
from .interceptors import AuthenticationInterceptor
from .serialization import from_proto_value, to_proto_value


class RpcService(service_pb2_grpc.XtquantRpcServiceServicer):
    def __init__(self, registry: DomainRegistry) -> None:
        self._registry = registry

    def Invoke(self, request: service_pb2.InvokeRequest, context: grpc.ServicerContext) -> service_pb2.InvokeResponse:
        args = [from_proto_value(item) for item in request.args]
        kwargs = {key: from_proto_value(value) for key, value in request.kwargs.items()}
        try:
            result = self._registry.invoke(request.domain, request.method, args, kwargs)
        except Exception as exc:
            return service_pb2.InvokeResponse(
                ok=False,
                error_type=type(exc).__name__,
                error_message=str(exc),
                traceback=traceback.format_exc(),
            )

        return service_pb2.InvokeResponse(ok=True, result=to_proto_value(result))


def create_grpc_server(registry: DomainRegistry, token: str, max_workers: int = 16) -> grpc.Server:
    server = grpc.server(
        futures.ThreadPoolExecutor(max_workers=max_workers),
        interceptors=[AuthenticationInterceptor(token)],
    )
    service_pb2_grpc.add_XtquantRpcServiceServicer_to_server(RpcService(registry), server)
    return server
