from __future__ import annotations

import argparse

from .domain_registry import DomainRegistry
from .domains_xtdata import XtdataDomainHandler
from .service import create_grpc_server


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the xtquant gRPC server.")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=50051)
    parser.add_argument("--token", required=True)
    parser.add_argument("--xtdata-ip", default="")
    parser.add_argument("--xtdata-port", type=int, default=None)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    registry = DomainRegistry()
    registry.register(
        "xtdata",
        XtdataDomainHandler(
            xtdata_ip=args.xtdata_ip,
            xtdata_port=args.xtdata_port,
        ),
    )

    server = create_grpc_server(registry=registry, token=args.token)
    server.add_insecure_port(f"{args.host}:{args.port}")
    server.start()
    server.wait_for_termination()
