from __future__ import annotations

from typing import Callable

import grpc


class AuthenticationInterceptor(grpc.ServerInterceptor):
    def __init__(self, expected_token: str) -> None:
        self._expected_token = expected_token

    def intercept_service(self, continuation: Callable, handler_call_details: grpc.HandlerCallDetails):
        handler = continuation(handler_call_details)
        if handler is None or handler.unary_unary is None:
            return handler

        def unary_unary(request, context):
            if request.auth_token != self._expected_token:
                context.abort(grpc.StatusCode.UNAUTHENTICATED, "invalid xtquant RPC token")
            return handler.unary_unary(request, context)

        return grpc.unary_unary_rpc_method_handler(
            unary_unary,
            request_deserializer=handler.request_deserializer,
            response_serializer=handler.response_serializer,
        )
