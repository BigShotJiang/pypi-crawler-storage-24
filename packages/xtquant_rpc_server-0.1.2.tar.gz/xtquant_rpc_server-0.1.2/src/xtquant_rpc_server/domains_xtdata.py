from __future__ import annotations

from typing import Any

from .exceptions import MethodNotSupportedError

SUPPORTED_METHODS = {
    "get_data_dir",
    "get_field_list",
    "get_stock_list_in_sector",
    "get_index_weight",
    "get_financial_data",
    "get_financial_data_ori",
    "get_market_data_ori",
    "get_market_data",
    "get_market_data_ex_ori",
    "get_market_data_ex",
    "get_local_data",
    "get_l2_quote",
    "get_l2_order",
    "get_l2_transaction",
    "get_divid_factors",
    "getDividFactors",
    "get_main_contract",
    "get_sec_main_contract",
    "datetime_to_timetag",
    "timetag_to_datetime",
    "timetagToDateTime",
    "get_trading_dates",
    "get_full_tick",
    "get_l2thousand_queue",
    "get_transactioncount",
    "get_fullspeed_orderbook",
    "get_sector_list",
    "get_sector_info",
    "get_instrument_detail",
    "get_instrument_detail_list",
    "download_index_weight",
    "download_history_contracts",
    "download_history_data",
    "download_financial_data",
    "get_instrument_type",
    "download_sector_data",
    "download_holiday_data",
    "get_holidays",
    "get_market_last_trade_date",
    "get_trading_calendar",
    "is_stock_type",
    "download_cb_data",
    "get_cb_info",
    "get_option_detail_data",
    "get_option_undl_data",
    "get_option_list",
    "get_his_option_list",
    "get_his_option_list_batch",
    "get_ipo_info",
    "get_markets",
    "get_wp_market_list",
    "get_his_st_data",
    "get_period_list",
    "get_formulas",
    "get_quote_server_config",
    "get_quote_server_status",
    "get_etf_info",
    "download_etf_info",
    "download_his_st_data",
    "get_hk_broker_dict",
    "get_broker_queue_data",
    "get_full_kline",
    "download_tabular_data",
    "get_trading_contract_list",
    "get_trading_period",
    "get_kline_trading_period",
    "get_all_trading_periods",
    "get_all_kline_trading_periods",
    "get_authorized_market_list",
    "compute_coming_trading_calendar",
    "get_tabular_formula",
    "bnd_get_conversion_price",
    "bnd_get_call_info",
    "bnd_get_put_info",
    "bnd_get_amount_change",
    "get_tabular_data",
    "get_order_rank",
    "get_current_connect_sub_info",
    "get_all_sub_info",
}


class XtdataDomainHandler:
    def __init__(self, xtdata_module: Any | None = None, xtdata_ip: str = "", xtdata_port: int | None = None) -> None:
        self._xtdata = xtdata_module
        self._xtdata_ip = xtdata_ip
        self._xtdata_port = xtdata_port
        self._is_connected = False

    def _load_xtdata(self):
        if self._xtdata is None:
            from xtquant import xtdata

            self._xtdata = xtdata
        if not self._is_connected and (self._xtdata_ip or self._xtdata_port is not None):
            self._xtdata.connect(ip=self._xtdata_ip, port=self._xtdata_port)
            self._is_connected = True
        return self._xtdata

    def invoke(self, method: str, args: list[Any], kwargs: dict[str, Any]) -> Any:
        if method not in SUPPORTED_METHODS:
            raise MethodNotSupportedError(f"Unsupported xtdata method: {method}")
        xtdata = self._load_xtdata()
        target = getattr(xtdata, method)
        return target(*args, **kwargs)
