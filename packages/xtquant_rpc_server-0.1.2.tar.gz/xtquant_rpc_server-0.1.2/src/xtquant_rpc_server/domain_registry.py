from __future__ import annotations

from typing import Any, Protocol

from .exceptions import DomainNotSupportedError


class DomainHandler(Protocol):
    def invoke(self, method: str, args: list[Any], kwargs: dict[str, Any]) -> Any:
        ...


class DomainRegistry:
    def __init__(self) -> None:
        self._handlers: dict[str, DomainHandler] = {}

    def register(self, domain: str, handler: DomainHandler) -> None:
        self._handlers[domain] = handler

    def invoke(self, domain: str, method: str, args: list[Any], kwargs: dict[str, Any]) -> Any:
        handler = self._handlers.get(domain)
        if handler is None:
            raise DomainNotSupportedError(f"Unsupported domain: {domain}")
        return handler.invoke(method, args, kwargs)
