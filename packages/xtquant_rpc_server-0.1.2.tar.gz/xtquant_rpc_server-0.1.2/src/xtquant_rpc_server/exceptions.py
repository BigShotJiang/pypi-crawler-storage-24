class DomainNotSupportedError(Exception):
    """Raised when a requested xtquant domain is not registered."""


class MethodNotSupportedError(Exception):
    """Raised when a requested xtquant method is not allowed."""
