"""v1 protobuf definitions for xtquant RPC."""
