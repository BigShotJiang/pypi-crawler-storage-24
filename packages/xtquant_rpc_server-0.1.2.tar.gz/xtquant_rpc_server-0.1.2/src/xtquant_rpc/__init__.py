"""Generated xtquant RPC protobuf modules."""
