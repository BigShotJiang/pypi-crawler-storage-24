import pandas as pd


def infer_column_types(df):

    inferred_types = {}

    for column in df.columns:

        dtype = str(df[column].dtype)

        if "int" in dtype:
            inferred_types[column] = "integer"

        elif "float" in dtype:
            inferred_types[column] = "float"

        elif "datetime" in dtype:
            inferred_types[column] = "timestamp"

        else:
            inferred_types[column] = "string"

    return inferred_types


def detect_type_drift(actual_types, expected_columns):

    drift = []

    for col in expected_columns:

        name = col["name"]

        expected_type = col.get("type")

        if not expected_type:
            continue

        actual_type = actual_types.get(name)

        if actual_type and actual_type != expected_type:

            drift.append(
                {
                    "column": name,
                    "expected": expected_type,
                    "actual": actual_type
                }
            )

    return drift