def detect_schema_drift(actual_cols, expected_cols):

    expected_names = [c["name"] for c in expected_cols]

    new_columns = []
    missing_columns = []

    for col in actual_cols:
        if col not in expected_names:
            new_columns.append(col)

    for col in expected_names:
        if col not in actual_cols:
            missing_columns.append(col)

    return {
        "new_columns": new_columns,
        "missing_columns": missing_columns
    }