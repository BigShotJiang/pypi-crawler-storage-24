import pandas as pd


def profile_columns(df):

    profiles = {}

    for column in df.columns:

        series = df[column]

        profile = {
            "null_percent": float(series.isnull().mean() * 100),
            "distinct_count": int(series.nunique())
        }

        # Numeric stats
        if pd.api.types.is_numeric_dtype(series):

            profile["min"] = float(series.min())
            profile["max"] = float(series.max())

        profiles[column] = profile

    return profiles