import yaml
import os


def load_config():

    config_file = "schema_guard.yml"

    if not os.path.exists(config_file):
        return {}

    with open(config_file) as f:
        return yaml.safe_load(f)