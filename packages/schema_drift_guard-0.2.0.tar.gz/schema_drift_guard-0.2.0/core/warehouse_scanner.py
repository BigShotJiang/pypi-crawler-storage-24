from rich.console import Console
from rich.table import Table
from connectors.connector_factory import get_connector

console = Console()


def scan_warehouse(source_type, database, schema_name, **kwargs):

    connector = get_connector(source_type, **kwargs)

    if source_type != "snowflake":
        console.print("[red]Warehouse scan only supported for Snowflake currently[/red]")
        return

    tables_query = f"""
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = '{schema_name.upper()}'
    """

    conn = connector.load_data  # placeholder if needed