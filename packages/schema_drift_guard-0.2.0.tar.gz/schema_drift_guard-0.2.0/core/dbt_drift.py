from rich.console import Console
from rich.table import Table
from connectors.connector_factory import get_connector
from core.dbt_scanner import scan_dbt_project

console = Console()


def compare_columns(dbt_cols, warehouse_cols):

    dbt_set = set(dbt_cols)
    wh_set = set(warehouse_cols)

    missing_in_wh = dbt_set - wh_set
    extra_in_wh = wh_set - dbt_set

    return missing_in_wh, extra_in_wh


def dbt_drift_check(project_path, source_type, **kwargs):

    connector = get_connector(source_type, **kwargs)

    models = scan_dbt_project(project_path)

    if not models:
        console.print("[yellow]No dbt models found[/yellow]")
        return

    drift_found = False

    for m in models:

        model_name = m["model"]
        dbt_columns = m["columns"]

        if not dbt_columns:
            continue

        try:

            warehouse_schema = connector.get_table_schema(model_name)

            warehouse_columns = [c["name"] for c in warehouse_schema]

        except Exception:
            continue

        missing, extra = compare_columns(dbt_columns, warehouse_columns)

        if missing or extra:

            drift_found = True

            console.print(f"\n[bold red]Drift detected for {model_name}[/bold red]")

            table = Table()

            table.add_column("Type")
            table.add_column("Column")

            for c in missing:
                table.add_row("Missing in warehouse", c)

            for c in extra:
                table.add_row("Extra in warehouse", c)

            console.print(table)

    if not drift_found:
        console.print("[green]No schema drift detected[/green]")