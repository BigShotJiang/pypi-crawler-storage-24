import yaml

from connectors.connector_factory import get_connector
from detectors.schema_drift import detect_schema_drift
from detectors.type_detector import infer_column_types, detect_type_drift
from generators.yaml_updater import update_schema_yaml
from detectors.column_profiler import profile_columns

from rich.console import Console
from rich.table import Table

console = Console()


def run_schema_check(source_type, source, schema_file, fail_on_drift=False, **kwargs):
    drift_detected = False

    connector = get_connector(source_type, **kwargs)

    df = connector.load_data(source)
    console.print("\n[bold blue]🔍 Column Profiling[/bold blue]")

    profiles = profile_columns(df)

    table = Table(title="Column Profiling")

    table.add_column("Column")
    table.add_column("Null %")
    table.add_column("Distinct")
    table.add_column("Min")
    table.add_column("Max")

    for column, stats in profiles.items():
        table.add_row(
            column,
            str(stats.get("null_percent")),
            str(stats.get("distinct_count")),
            str(stats.get("min", "")),
            str(stats.get("max", ""))
        )

    console.print(table)

    with open(schema_file, "r") as f:
        expected_schema = yaml.safe_load(f)

    expected_columns = expected_schema["columns"]

    actual_columns = list(df.columns)

    drift = detect_schema_drift(actual_columns, expected_columns)

    new_columns = drift["new_columns"]
    missing_columns = drift["missing_columns"]

    if new_columns or missing_columns:
        drift_detected = True

        console.print("[bold yellow]⚠️ Schema drift detected[/bold yellow]")

        if new_columns:
            print("\nNew columns detected:")
            for col in new_columns:
                console.print(f"[green]+ {col}[/green]")

        if missing_columns:
            print("\nMissing columns:")
            for col in missing_columns:
                console.print(f"[red]- {col}[/red]")

        if new_columns:
            print("\nUpdating schema YAML...")
            update_schema_yaml(schema_file, new_columns, profiles)
            print("✅ Schema updated")

    else:
        print("✅ No column drift detected")

    print("\nChecking type drift...")

    actual_types = infer_column_types(df)

    type_drift = detect_type_drift(actual_types, expected_columns)

    if not type_drift:
        print("✅ No type drift detected")
    else:
        drift_detected = True
        print("⚠️ Type drift detected\n")

        for d in type_drift:
            print(
                f"Column: {d['column']} | Expected: {d['expected']} | Actual: {d['actual']}"
            )

    import sys

    if drift_detected and fail_on_drift:
        print("\n❌ Schema drift detected. Failing pipeline.")
        sys.exit(1)