import os
import shutil


def save_schema_version(schema_file):

    schema_name = os.path.basename(schema_file).replace(".yml", "")

    version_folder = f"schema_versions/{schema_name}"

    os.makedirs(version_folder, exist_ok=True)

    existing_versions = [
        f for f in os.listdir(version_folder) if f.endswith(".yml")
    ]

    version_number = len(existing_versions) + 1

    version_file = f"{version_folder}/{schema_name}_v{version_number}.yml"

    shutil.copy(schema_file, version_file)

    print(f"📜 Schema version saved: {version_file}")