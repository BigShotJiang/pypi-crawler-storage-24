import os
import yaml
from rich.console import Console

console = Console()

def find_schema_files(project_path):

    schema_files = []

    IGNORED_DIRS = {
        "dbt_packages",
        "dbt_internal_packages",
        "target",
        ".venv",
        "venv",
        "__pycache__",
        ".git"
    }

    for root, dirs, files in os.walk(project_path):

        # remove ignored directories from traversal
        dirs[:] = [d for d in dirs if d not in IGNORED_DIRS]

        for file in files:
            if file.endswith(".yml") or file.endswith(".yaml"):

                full_path = os.path.join(root, file)

                schema_files.append(full_path)

    return schema_files


def parse_dbt_schema(schema_file):

    models = []

    try:

        with open(schema_file) as f:
            content = yaml.safe_load(f)

    except Exception:
        return models

    if not content:
        return models

    if not isinstance(content, dict):
        return models

    if "models" not in content:
        return models

    for model in content["models"]:

        # handle case where model is just a string
        if isinstance(model, str):
            model_name = model
            columns = []

        elif isinstance(model, dict):

            model_name = model.get("name")

            if not model_name:
                continue

            columns = []

            for col in model.get("columns", []):
                if isinstance(col, dict):
                    col_name = col.get("name")
                    if col_name:
                        columns.append(col_name)

        else:
            continue

        if model_name.startswith("test_"):
            continue

        models.append({
            "model": model_name,
            "columns": columns
        })

    return models

def scan_dbt_project(project_path):

    yaml_files = find_yaml_files(project_path)

    models = []

    for file in yaml_files:

        parsed_models = parse_dbt_schema(file)

        if parsed_models:
            models.extend(parsed_models)

    return models


def find_sql_models(project_path):

    models = []

    IGNORED_DIRS = {
        "dbt_packages",
        "dbt_internal_packages",
        "target",
        ".venv",
        "venv",
        "__pycache__",
        ".git"
    }

    for root, dirs, files in os.walk(project_path):

        dirs[:] = [d for d in dirs if d not in IGNORED_DIRS]

        for file in files:

            if file.endswith(".sql"):

                model_name = file.replace(".sql", "")

                models.append(model_name)

    return models

def find_yaml_files(project_path):

    yaml_files = []

    IGNORED_DIRS = {
        "dbt_packages",
        "dbt_internal_packages",
        "target",
        ".venv",
        "venv",
        "__pycache__",
        ".git"
    }

    for root, dirs, files in os.walk(project_path):

        dirs[:] = [d for d in dirs if d not in IGNORED_DIRS]

        for file in files:

            if file.endswith(".yml") or file.endswith(".yaml"):

                yaml_files.append(os.path.join(root, file))

    return yaml_files