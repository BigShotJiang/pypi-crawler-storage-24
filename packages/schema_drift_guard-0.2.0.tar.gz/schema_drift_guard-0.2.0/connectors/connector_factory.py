from connectors.csv_connector import CSVConnector


def get_connector(source_type, **kwargs):

    if source_type == "csv":
        return CSVConnector()

    if source_type == "snowflake":

        try:
            from connectors.snowflake_connector import SnowflakeConnector
        except ImportError:
            raise ImportError(
                "Snowflake connector not installed. Run: pip install snowflake-connector-python"
            )

        return SnowflakeConnector(
            account=kwargs["account"],
            user=kwargs["user"],
            password=kwargs.get("password"),
            private_key_path=kwargs.get("private_key_path"),
            private_key_passphrase=kwargs.get("private_key_passphrase"),
            warehouse=kwargs["warehouse"],
            database=kwargs["database"],
            schema=kwargs["schema_name"]
        )

    raise ValueError(f"Unsupported source type: {source_type}")