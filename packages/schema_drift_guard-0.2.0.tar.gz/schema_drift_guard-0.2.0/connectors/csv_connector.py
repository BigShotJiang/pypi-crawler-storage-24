import pandas as pd
from connectors.base_connector import BaseConnector


class CSVConnector(BaseConnector):

    def load_data(self, source):
        return pd.read_csv(source)