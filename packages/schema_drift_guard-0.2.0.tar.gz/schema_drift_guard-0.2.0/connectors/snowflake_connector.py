import pandas as pd
import snowflake.connector
from connectors.base_connector import BaseConnector
from cryptography.hazmat.primitives import serialization


class SnowflakeConnector(BaseConnector):

    def __init__(
        self,
        account,
        user,
        warehouse,
        database,
        schema,
        password=None,
        private_key_path=None,
        private_key_passphrase=None
    ):

        self.account = account
        self.user = user
        self.password = password
        self.private_key_path = private_key_path
        self.private_key_passphrase = private_key_passphrase
        self.warehouse = warehouse
        self.database = database
        self.schema = schema

        def _create_connection(self):

            if self.private_key_path:

                with open(self.private_key_path, "rb") as key_file:

                    p_key = serialization.load_pem_private_key(
                        key_file.read(),
                        password=self.private_key_passphrase.encode()
                        if self.private_key_passphrase
                        else None
                    )

                pkb = p_key.private_bytes(
                    encoding=serialization.Encoding.DER,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption()
                )

                conn = self._create_connection()

            else:

                conn = self._create_connection()

            return conn

    def load_data(self, table):

        conn = self._create_connection()

        query = f"SELECT * FROM {table} LIMIT 1000"

        df = pd.read_sql(query, conn)

        conn.close()

        return df
    
    def get_table_schema(self, table):

        conn = self._create_connection()

        query = f"""
        SELECT column_name, data_type
        FROM information_schema.columns
        WHERE table_name = '{table.upper()}'
        ORDER BY ordinal_position
        """

        cursor = conn.cursor()
        cursor.execute(query)

        rows = cursor.fetchall()

        conn.close()

        columns = []

        for name, dtype in rows:
            columns.append({
                "name": name.lower(),
                "type": dtype.lower()
            })

        return columns