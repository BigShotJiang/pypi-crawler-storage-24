class BaseConnector:

    def load_data(self, source):
        """
        Should return a pandas dataframe
        """
        raise NotImplementedError("Connector must implement load_data")