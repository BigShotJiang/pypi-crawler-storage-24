import click
from core.engine import run_schema_check


@click.group()
def cli():
    pass


@cli.command()
@click.option("--source-type", required=True, help="Source type (csv, snowflake, etc)")
@click.option("--source", required=True, help="Source path or table")
@click.option("--schema", required=True, help="Expected schema YAML")
def check(source_type, source, schema):
    run_schema_check(source_type, source, schema)