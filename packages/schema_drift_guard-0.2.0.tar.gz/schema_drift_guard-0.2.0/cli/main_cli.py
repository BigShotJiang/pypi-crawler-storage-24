import click
import os

from rich.console import Console
from rich.table import Table

from core.engine import run_schema_check
from utils.config_loader import load_config
from connectors.connector_factory import get_connector
from core.dbt_scanner import scan_dbt_project
from core.dbt_drift import dbt_drift_check

console = Console()


@click.group()
@click.version_option(version="0.1.0")
def cli():
    """
    Schema Guard CLI

    Detect schema drift and enforce data contracts in data pipelines.
    """
    pass


# ------------------------------------------------------------
# CHECK COMMAND
# ------------------------------------------------------------

@cli.command()
@click.option("--source-type", default=None, help="Source type (csv, snowflake, etc)")
@click.option("--source", required=True, help="Source path or table")
@click.option("--schema", required=True, help="Expected schema YAML")
@click.option("--fail-on-drift", is_flag=True, help="Fail if schema drift detected")

@click.option("--account", default=None, help="Snowflake account")
@click.option("--user", default=None, help="Snowflake user")
@click.option("--password", default=None, help="Snowflake password")

@click.option("--private-key-path", default=None, help="Path to Snowflake private key")
@click.option("--private-key-passphrase", default=None, help="Private key passphrase")

@click.option("--warehouse", default=None, help="Snowflake warehouse")
@click.option("--database", default=None, help="Snowflake database")
@click.option("--schema-name", default=None, help="Snowflake schema")
def check(source_type, source, schema, fail_on_drift,
          account, user, password,
          private_key_path, private_key_passphrase,
          warehouse, database, schema_name):
    """
    Check schema drift for a dataset or warehouse table.
    """

    config = load_config()

    # Source type from config fallback
    if not source_type:
        source_type = config.get("source_type")

    snowflake_cfg = config.get("snowflake", {})

    # Merge CLI args with config
    account = account or snowflake_cfg.get("account")
    user = user or snowflake_cfg.get("user")
    password = password or snowflake_cfg.get("password")

    private_key_path = private_key_path or snowflake_cfg.get("private_key_path")
    private_key_passphrase = private_key_passphrase or snowflake_cfg.get("private_key_passphrase")

    warehouse = warehouse or snowflake_cfg.get("warehouse")
    database = database or snowflake_cfg.get("database")
    schema_name = schema_name or snowflake_cfg.get("schema")

    run_schema_check(
        source_type,
        source,
        schema,
        fail_on_drift,
        account=account,
        user=user,
        password=password,
        private_key_path=private_key_path,
        private_key_passphrase=private_key_passphrase,
        warehouse=warehouse,
        database=database,
        schema_name=schema_name
    )


# ------------------------------------------------------------
# LOCAL DATASET SCANNER
# ------------------------------------------------------------

@cli.command()
@click.argument("path")
def scan(path):
    """
    Scan a directory for datasets (CSV / Parquet files).
    """

    if not os.path.exists(path):
        console.print(f"[bold red]Path does not exist:[/bold red] {path}")
        return

    console.print(f"[bold]Scanning directory:[/bold] {path}")

    found = False

    for root, dirs, files in os.walk(path):
        for file in files:

            full_path = os.path.join(root, file)

            if file.endswith(".csv"):
                console.print(f"[green]CSV dataset found:[/green] {full_path}")
                found = True

            elif file.endswith(".parquet"):
                console.print(f"[green]Parquet dataset found:[/green] {full_path}")
                found = True

    if not found:
        console.print("[yellow]No datasets found.[/yellow]")


# ------------------------------------------------------------
# WAREHOUSE SCANNER
# ------------------------------------------------------------

@cli.command()
@click.option("--source-type", default=None)
@click.option("--database", default=None)
@click.option("--schema-name", default=None)

@click.option("--account")
@click.option("--user")
@click.option("--password")

@click.option("--private-key-path")
@click.option("--private-key-passphrase")

@click.option("--warehouse")
def scan_warehouse(source_type, database, schema_name,
                   account, user, password,
                   private_key_path, private_key_passphrase,
                   warehouse):
    """
    Scan warehouse schema metadata.
    """

    config = load_config()

    if not source_type:
        source_type = config.get("source_type")

    if source_type != "snowflake":
        console.print("[red]Currently only Snowflake is supported[/red]")
        return

    snowflake_cfg = config.get("snowflake", {})

    account = account or snowflake_cfg.get("account")
    user = user or snowflake_cfg.get("user")
    password = password or snowflake_cfg.get("password")

    private_key_path = private_key_path or snowflake_cfg.get("private_key_path")
    private_key_passphrase = private_key_passphrase or snowflake_cfg.get("private_key_passphrase")

    warehouse = warehouse or snowflake_cfg.get("warehouse")
    database = database or snowflake_cfg.get("database")
    schema_name = schema_name or snowflake_cfg.get("schema")

    connector = get_connector(
        source_type,
        account=account,
        user=user,
        password=password,
        private_key_path=private_key_path,
        private_key_passphrase=private_key_passphrase,
        warehouse=warehouse,
        database=database,
        schema_name=schema_name
    )

    rows = connector.get_schema_metadata(schema_name)

    table = Table(title="Warehouse Schema")

    table.add_column("Table")
    table.add_column("Column")
    table.add_column("Type")

    for table_name, column_name, data_type in rows:
        table.add_row(table_name, column_name, data_type)

    console.print(table)


@cli.command()
@click.option("--project-path", default=".")
def dbt_check(project_path):
    """Scan dbt project for models"""

    from rich.console import Console
    from rich.table import Table

    console = Console()

    models = scan_dbt_project(project_path)

    if not models:
        console.print("[red]No dbt models found[/red]")
        return

    table = Table(title="dbt Models")

    table.add_column("Model")
    table.add_column("Columns")

    for m in models:
        table.add_row(m["model"], ", ".join(m["columns"]))

    console.print(table)


@cli.command()
@click.option("--project-path", default=".")
@click.option("--source-type", required=True)
@click.option("--account")
@click.option("--user")
@click.option("--password")
@click.option("--warehouse")
@click.option("--database")
@click.option("--schema-name")
@click.option("--private-key-path")
@click.option("--private-key-passphrase")
def dbt_drift(project_path, source_type,
              account, user, password,
              warehouse, database, schema_name,
              private_key_path, private_key_passphrase):

    """Compare dbt models with warehouse schema"""

    dbt_drift_check(
        project_path,
        source_type,
        account=account,
        user=user,
        password=password,
        warehouse=warehouse,
        database=database,
        schema_name=schema_name,
        private_key_path=private_key_path,
        private_key_passphrase=private_key_passphrase
    )


if __name__ == "__main__":
    cli()


