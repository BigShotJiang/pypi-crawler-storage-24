from setuptools import setup, find_packages

setup(
    name="schema-guard",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "pyyaml",
        "click",
        "rich"
    ],
    entry_points={
        "console_scripts": [
            "schema-guard=cli.main_cli:cli"
        ]
    },
)