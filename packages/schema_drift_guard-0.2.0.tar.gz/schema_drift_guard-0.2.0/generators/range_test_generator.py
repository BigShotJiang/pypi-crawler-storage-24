def generate_range_test(column_name, profile):

    if "min" not in profile or "max" not in profile:
        return None

    return {
        "accepted_range": {
            "min": profile["min"],
            "max": profile["max"]
        }
    }