def suggest_tests(column_name):

    column_name = column_name.lower()

    tests = ["not_null"]

    if "id" in column_name:
        tests.append("unique")

    if "email" in column_name:
        tests.append("email_format")

    if "price" in column_name or "amount" in column_name:
        tests.append("positive_values")

    if "date" in column_name or "created" in column_name:
        tests.append("not_null")

    return list(set(tests))