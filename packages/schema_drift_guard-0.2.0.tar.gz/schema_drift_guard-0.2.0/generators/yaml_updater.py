import yaml
from generators.test_generator import suggest_tests
from core.schema_versioning import save_schema_version
from generators.range_test_generator import generate_range_test


def update_schema_yaml(schema_file, new_columns, profiles=None):

    save_schema_version(schema_file)

    with open(schema_file, "r") as f:
        schema = yaml.safe_load(f)

    if "columns" not in schema:
        schema["columns"] = []

    existing_cols = [c["name"] for c in schema["columns"]]

    for col in new_columns:

        if col not in existing_cols:

            print(f"➕ Adding column to schema: {col}")

            tests = suggest_tests(col)

            column_entry = {
                "name": col,
                "tests": tests
            }

            if profiles and col in profiles:

                range_test = generate_range_test(col, profiles[col])

                if range_test:
                    column_entry["tests"].append(range_test)

            schema["columns"].append(column_entry)

    with open(schema_file, "w") as f:
        yaml.dump(schema, f, sort_keys=False)