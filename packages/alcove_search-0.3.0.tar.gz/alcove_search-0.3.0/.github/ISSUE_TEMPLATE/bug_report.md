---
name: Bug report
about: Something isn't working as expected
labels: bug
---

**What happened?**


**What did you expect?**


**Steps to reproduce**

1.
2.
3.

**Environment**

- OS:
- Python version:
- How you installed (make setup / pip / docker):
