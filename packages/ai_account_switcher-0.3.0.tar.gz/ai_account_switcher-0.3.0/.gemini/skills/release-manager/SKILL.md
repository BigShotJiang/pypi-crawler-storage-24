---
name: release-manager
description: Manages the full release workflow for this repository. Generates release notes in docs/releases/, updates CHANGELOG.md, updates README.md version references and feature list, commits and pushes all docs to the current branch, then creates or updates the GitHub release via gh CLI. Use when cutting a new release or updating release artifacts for an existing tag. Do NOT use for general documentation edits unrelated to a release.
---
# Release Manager

## Overview

Handles the end-to-end release documentation and publishing workflow:
1. Determine the new version and collect changes from git log
2. Write `docs/releases/vX.Y.Z.md` (release notes)
3. Prepend a new entry to `CHANGELOG.md`
4. Update `README.md` version references and feature list
5. Bump version in `pyproject.toml`
6. Commit and push docs to the current branch
7. Create or update the GitHub release via `gh release`

## Step 1 — Determine version and collect changes

1. Run `git describe --tags --abbrev=0` to find the latest tag.
2. Run `git log <last-tag>..HEAD --oneline` to list commits since that tag.
3. Classify commits by Conventional Commits prefix:
   - `feat:` / `feat(*):`  → MINOR bump (new feature)
   - `fix:` / `fix(*):` → PATCH bump (bug fix)
   - `BREAKING CHANGE` in body or `!` suffix → MAJOR bump
   - `docs:`, `chore:`, `test:`, `refactor:` → no version bump on their own
4. Determine new version: apply the highest-priority bump to the current version found in `pyproject.toml`.
5. If the user explicitly specifies a version, use that instead.

## Step 2 — Write release notes

1. Check `docs/releases/` for existing files to understand the established style.
2. Read `assets/release-notes-template.md` for the structural template.
3. Create `docs/releases/vX.Y.Z.md` following that template exactly.
4. Group changes under the correct headings: Bug Fixes, New Features, Improvements, Breaking Changes, Upgrade notes.
5. Only include sections that have content — omit empty sections entirely.
6. Use emoji section headers matching the template (`### 🛡️`, `### 🔧`, etc.).

## Step 3 — Update CHANGELOG.md

1. Read `assets/changelog-entry-template.md` for the entry format.
2. Read the existing `CHANGELOG.md` header and version links block (usually the last N lines).
3. Prepend the new version block immediately after the header (before the previous latest version).
4. Keep an `[Unreleased]` section at the top if the project uses one; if not, do not add one.
5. Append the new version comparison link to the links block at the bottom of the file (see `references/conventions.md`).

## Step 4 — Update README.md

1. Search for the current version string (e.g. `0.2.0`) in `README.md`.
2. Replace all occurrences with the new version.
3. If new user-facing features were added, insert a bullet under the `## Features` section.
4. If commands were added or changed, update the relevant rows in the Command Reference table.
5. Do NOT rewrite sections that haven't changed.

## Step 5 — Bump version in pyproject.toml

1. Open `pyproject.toml` and update `version = "X.Y.Z"` to the new version.
2. Verify the file is valid TOML: `python3 -c "import tomllib; tomllib.loads(open('pyproject.toml').read())"`.

## Step 6 — Commit and push

1. Stage only the docs and pyproject: `git add docs/releases/vX.Y.Z.md CHANGELOG.md README.md pyproject.toml`.
2. Commit with message: `chore(release): prepare vX.Y.Z release artifacts`.
3. Push to the current branch: `git push origin HEAD`.
4. Confirm push succeeded before proceeding.

## Step 7 — Create or update the GitHub release

1. Check if the tag already exists: `gh release view vX.Y.Z 2>&1`.
   - **Tag does not exist:** run `gh release create vX.Y.Z --title "vX.Y.Z — <one-line summary>" --notes-file docs/releases/vX.Y.Z.md --target <current-branch>`.
   - **Tag already exists:** run `gh release edit vX.Y.Z --notes-file docs/releases/vX.Y.Z.md`.
   - To update the title as well: add `--title "vX.Y.Z — <one-line summary>"` to the edit command.
2. Print the release URL returned by `gh`.

## Decision tree — create vs edit

```
gh release view vX.Y.Z
├── exits 0  → release exists → use `gh release edit`
└── exits non-0 → release absent → use `gh release create`
```

## File paths (relative to repo root)

| File | Purpose |
|---|---|
| `docs/releases/vX.Y.Z.md` | Per-release prose notes |
| `CHANGELOG.md` | Cumulative change log |
| `README.md` | Project readme |
| `pyproject.toml` | Version source of truth |

## References

- See `references/conventions.md` for Keep a Changelog format rules and SemVer decision table.
- See `assets/release-notes-template.md` for the release notes file structure.
- See `assets/changelog-entry-template.md` for the CHANGELOG entry format.
