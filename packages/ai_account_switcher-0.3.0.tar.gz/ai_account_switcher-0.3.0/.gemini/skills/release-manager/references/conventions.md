# Release Conventions Reference

## SemVer — Version bump decision table

| Commit type | Version component bumped | Example |
|---|---|---|
| `BREAKING CHANGE` in body, or `!` suffix | **MAJOR** (X.0.0) | `feat!: drop Python 3.9` |
| `feat:` / `feat(*):` | **MINOR** (0.Y.0) | `feat(cli): add alerts command` |
| `fix:` / `fix(*):` | **PATCH** (0.0.Z) | `fix(health): correct request body` |
| `docs:`, `chore:`, `test:`, `refactor:`, `perf:`, `style:` | No bump (docs/infra only) | `docs: update readme` |

**Priority:** MAJOR > MINOR > PATCH. Apply the single highest-priority bump across all commits since the last tag.

## Keep a Changelog 1.1.0 — Section types

| Section | When to use |
|---|---|
| `Added` | New user-visible features |
| `Changed` | Modified existing behaviour (non-breaking) |
| `Fixed` | Bug fixes |
| `Removed` | Features or options no longer available |
| `Deprecated` | Still works but scheduled for removal |
| `Security` | Any vulnerability fix, however minor |

**Rules:**
- Omit sections with no content — never write an empty `### Fixed` block.
- Write bullets for humans, not for CI systems — no commit SHAs, no jargon.
- The `[Unreleased]` section should exist between the header and the latest version if the project tracks upcoming changes. This project does **not** currently use an `[Unreleased]` section — do not add one.
- Date format: **ISO 8601** (`YYYY-MM-DD`). Never use locale-specific formats.
- Latest version block always comes **first**.

## CHANGELOG comparison links (footer block)

Append a new line to the links block at the bottom of CHANGELOG.md:

```markdown
[X.Y.Z]: https://github.com/adityaa-codes/ai-account-switcher/compare/vA.B.C...vX.Y.Z
```

Where `vA.B.C` is the previous version tag and `vX.Y.Z` is the new one.

For the very first version:

```markdown
[0.1.0]: https://github.com/adityaa-codes/ai-account-switcher/releases/tag/v0.1.0
```

## gh CLI — release commands

```bash
# Create a new release (tag does not yet exist)
gh release create vX.Y.Z \
  --title "vX.Y.Z — <one-line summary>" \
  --notes-file docs/releases/vX.Y.Z.md \
  --target <branch>

# Update an existing release's notes
gh release edit vX.Y.Z --notes-file docs/releases/vX.Y.Z.md

# Update an existing release's title and notes
gh release edit vX.Y.Z \
  --title "vX.Y.Z — <updated summary>" \
  --notes-file docs/releases/vX.Y.Z.md

# Check if a release exists (exit 0 = exists, non-0 = absent)
gh release view vX.Y.Z
```
