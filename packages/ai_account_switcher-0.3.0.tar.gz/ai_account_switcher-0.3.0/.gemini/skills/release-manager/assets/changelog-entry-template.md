# CHANGELOG Entry Template

> Prepend this block immediately after the `# Changelog` header, before the previous latest version.
> Follow Keep a Changelog 1.1.0 conventions (see references/conventions.md).

---

## [X.Y.Z] — YYYY-MM-DD

### Added
- <!-- New feature or capability (user-visible). One bullet per item. -->

### Changed
- <!-- Changes in existing functionality (non-breaking). -->

### Fixed
- <!-- Bug fixes. Reference the symptom, not just the commit. -->

### Removed
- <!-- Features or options that no longer exist. -->

### Deprecated
- <!-- Features that still work but will be removed in a future release. -->

### Security
- <!-- Vulnerability fixes. Always include even if minor. -->

---

> **Rules:**
> - Only include sections that have content. Omit empty sections entirely.
> - Write for humans, not machines — no raw commit hashes or internal jargon.
> - Latest version always comes first.
> - Date format: ISO 8601 (YYYY-MM-DD).
> - Each bullet should be a complete sentence ending with a period.
