# Release Notes Template — vX.Y.Z

> Copy this file to `docs/releases/vX.Y.Z.md`. Remove sections with no content.
> Emoji headers are required. Match the wording of existing files in this directory.

---

# vX.Y.Z Release Notes

**Release date:** YYYY-MM-DD

## Highlights

<!-- 2–4 sentence summary: what problem this release solves and why it matters. -->

---

## Bug Fixes

### 🔧 <Short title>

<!-- Describe what was broken, what the symptom was, and what was fixed. -->
<!-- Include the wrong vs. correct behaviour when helpful. -->

---

## New Features

### ✨ <Feature name>

<!-- Describe the feature. Include a usage example or command snippet. -->

```bash
# example command
```

### 🛡️ <Safety or security feature>

<!-- Use 🛡️ for safety/security, 📦 for packaging/pool, 🧠 for AI/memory features,
     📝 for config/docs features, 📊 for metrics/display, 🔔 for notifications/alerts,
     🔍 for search/lookup, 📁 for file/path features, 🔑 for auth/credential features. -->

---

## Improvements

### <Improvement title>

<!-- Describe a non-breaking enhancement to existing behaviour. -->

---

## Breaking Changes

<!-- Omit this section entirely if there are none. -->

### ⚠️ <Breaking change title>

<!-- Describe what changed, what breaks, and how to migrate. -->

---

## Upgrade

```bash
git pull
pip install -e .
# Add any post-upgrade steps (e.g., re-run `switcher install`)
```

---

## What's Next

<!-- Optional: 3–5 bullet points of planned work for the next release. -->
- ...
