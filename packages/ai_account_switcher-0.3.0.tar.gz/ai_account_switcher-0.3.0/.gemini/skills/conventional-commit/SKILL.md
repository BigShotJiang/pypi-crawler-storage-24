---
name: conventional-commit
description: Analyzes staged and unstaged workspace changes, groups them into atomic logical units, and creates Git commits that strictly follow the Conventional Commits 1.0.0 specification. Use when the user wants to commit changes, stage and commit files, or clean up the git working tree. Do NOT use for creating GitHub releases, writing changelogs, or publishing packages — use the release-manager skill for those tasks. Do NOT use for rebasing, cherry-picking, amending history, or resolving merge conflicts.
---
# Conventional Commit

## Overview

Inspect the workspace, group changes into atomic units, write a valid commit message for each unit, validate it with the bundled script, then commit.

## Step 1 — Inspect the workspace

1. Run `git --no-pager status` to list all modified, staged, and untracked files.
2. Run `git --no-pager diff` to see unstaged changes.
3. Run `git --no-pager diff --staged` to see already-staged changes.
4. If the working tree is clean (no output from status), print "Nothing to commit." and stop.

## Step 2 — Identify atomic units

Group files into atomic units — each unit must represent exactly one logical change.

Read `references/atomicity-guide.md` for correct and incorrect grouping examples including edge cases.

Key rules:
- One unit = one `type` + one `scope`.
- Do NOT mix `fix` and `feat` in one commit.
- Do NOT mix source code changes with `docs`-only changes.
- If one file contains changes for two units, use `git add -p <path>` to stage only the relevant hunks.

## Step 3 — Choose type and scope for each unit

Read `references/types-and-scopes.md` for the full type table and project-specific scope list.

Breaking change rule:
- If the change removes or renames a public command, config key, or file path — it is a BREAKING CHANGE.
- Mark it `feat(scope)!:` or `fix(scope)!:` in the subject.
- Add `BREAKING CHANGE: <description>` as a footer line.

## Step 4 — Write the commit message to a temp file

Read `assets/commit-template.txt` for the exact format and filled examples.

1. Write the message to `/tmp/cc_commit_msg.txt`.
2. Subject line rules: imperative mood, lowercase type, no trailing period, ≤72 chars.
3. Leave one blank line between subject and body (if body is included).
4. Leave one blank line between body and footers.

## Step 5 — Validate the message

Run the validation script:

```bash
python3 .gemini/skills/conventional-commit/scripts/validate-message.py /tmp/cc_commit_msg.txt
```

- Exit 0 → message is valid, proceed to Step 6.
- Exit 1 → the script prints the exact error. Fix the message in `/tmp/cc_commit_msg.txt` and re-validate. Do not commit until validation passes.

## Step 6 — Stage and commit

1. Stage files for this unit:
   - Whole files: `git add <path> [<path> ...]`
   - Partial (when one file has mixed concerns): `git add -p <path>`
2. Commit using the validated temp file:
   ```bash
   git commit -F /tmp/cc_commit_msg.txt
   ```
3. Confirm with `git --no-pager log -1 --format="%s%n%n%b"`.
4. Repeat Steps 3–6 for each remaining atomic unit.

## Step 7 — Final verification

1. Run `git --no-pager status` — working tree must be clean (or only intentionally untracked files remain).
2. Run `git --no-pager log --oneline -<n>` where n = number of commits just created.
3. Confirm all subject lines are valid Conventional Commits format.

## Error handling

| Situation | Action |
|---|---|
| Working tree already clean | Print "Nothing to commit." and stop |
| `git add -p` exits without staging any hunks | Inspect with `git diff <path>` and try again, or stage whole file |
| Validation script exits 1 | Fix the error printed, re-run validation — do not skip |
| `git commit` fails (e.g., pre-commit hook) | Show the hook output, fix the issue, then retry `git commit -F /tmp/cc_commit_msg.txt` |
| Merge conflicts present | Stop. Instruct the user to resolve conflicts first — this skill does not handle merges |

## References

- `references/types-and-scopes.md` — full type table and project scope list (read in Step 3)
- `references/atomicity-guide.md` — grouping examples and edge cases (read in Step 2)
- `references/anti-patterns.md` — common mistakes to avoid
- `assets/commit-template.txt` — message format template with filled examples (read in Step 4)
- `scripts/validate-message.py` — deterministic message validator (run in Step 5)
