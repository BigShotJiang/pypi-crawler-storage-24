# Types and Scopes Reference

## Type definitions (Conventional Commits 1.0.0 + Angular convention)

| Type | SemVer impact | When to use |
|---|---|---|
| `feat` | MINOR | Adds a new user-visible feature, command, or option |
| `fix` | PATCH | Corrects a bug in existing behaviour |
| `docs` | none | Changes to documentation files only (README, CHANGELOG, release notes, inline comments) |
| `style` | none | Formatting, whitespace, missing semicolons — zero logic change |
| `refactor` | none | Code restructuring with no behaviour or interface change |
| `perf` | none | Performance improvement with no interface change |
| `test` | none | Adding, fixing, or reorganising tests only |
| `build` | none | Build system, dependency changes (pyproject.toml, pip, npm) |
| `ci` | none | CI/CD workflow configuration (.github/workflows/, scripts) |
| `chore` | none | Maintenance tasks that don't fit above: version bumps, gitignore, config tweaks |
| `revert` | varies | Reverts a previous commit; subject should reference the reverted commit |

**BREAKING CHANGE** is not a type — it is a modifier. Append `!` to any type and add a `BREAKING CHANGE:` footer.

## Scope conventions for this project

Use the most specific applicable scope. If a change spans multiple modules, pick the entry-point scope.

| Scope | Covers |
|---|---|
| `cli` | `switcher/cli.py` — command routing, argument parsing, user-facing output |
| `health` | `switcher/health.py` — health checks, quota fetch, OAuth client discovery |
| `hooks` | `switcher/hooks/` — Gemini before/after agent hook scripts |
| `installer` | `switcher/installer.py` — shell integration, hook registration, env.sh |
| `state` | `switcher/state.py` — active profile state, cache, handoff flags |
| `config` | `switcher/config.py` — TOML config management |
| `profiles` | `switcher/profiles/` — profile lifecycle (add, remove, list, switch) |
| `gemini` | `switcher/profiles/gemini.py` — Gemini-specific profile logic |
| `codex` | `switcher/profiles/codex.py` or `switcher/auth/codex_*.py` — Codex-specific logic |
| `auth` | `switcher/auth/` — credential activation, keyring backend |
| `ui` | `switcher/ui.py`, `switcher/ui_menu.py` — terminal output, TUI menu |
| `utils` | `switcher/utils.py` — XDG paths, logging, file locking, atomic symlinks |
| `errors` | `switcher/errors.py` — exception hierarchy |
| `tests` | `tests/` — test suite changes |
| `skills` | `.gemini/skills/` — agent skill files |
| `release` | Release artifacts (CHANGELOG, release notes, pyproject version) |

Omit scope only for truly cross-cutting changes (e.g., a Python version upgrade touching every file).
