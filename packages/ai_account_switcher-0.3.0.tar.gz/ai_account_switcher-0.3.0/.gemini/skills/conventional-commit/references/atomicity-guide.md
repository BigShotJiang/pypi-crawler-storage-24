# Atomicity Guide — Correct vs Incorrect Groupings

An atomic commit does exactly **one logical thing**. The test: if you had to revert it, would you want everything in the commit reverted together? If yes → atomic. If no → split it.

---

## ✅ Correct — one logical change per commit

### Example A: bug fix and new feature are separate

Changes: `switcher/health.py` (fix wrong request body) + `switcher/cli.py` (new `alerts` command)

```
Commit 1:  fix(health): correct loadCodeAssist request body format
Commit 2:  feat(cli): add alerts command to tail errors.log
```

### Example B: same file, two concerns — use `git add -p`

`switcher/cli.py` has both a refactored `cmd_quota` and a brand-new `cmd_alerts`:

```bash
git add -p switcher/cli.py   # stage only the alerts hunks
git commit -m "feat(cli): add alerts command"
git add switcher/cli.py      # stage remaining quota refactor hunks
git commit -m "refactor(cli): extract quota formatting into helper"
```

### Example C: docs changes always separate from code

```
Commit 1:  fix(installer): make hook install idempotent
Commit 2:  docs(readme): document idempotent install behaviour
```

---

## ❌ Incorrect — mixed concerns in one commit

### Bad: mixing fix and feat
```
# Don't do this:
git commit -m "fix health 400 and add alerts command"
```
Why: if the `alerts` feature introduces a regression, reverting it also reverts the health fix.

### Bad: mixing code and docs
```
# Don't do this:
git commit -m "add codex isolation and update readme"
```
Why: documentation should be independently revertable from code.

### Bad: mixing two different scopes without a reason
```
# Don't do this:
git commit -m "fix(cli): various fixes"
```
Why: vague scope + plural "fixes" signals multiple concerns bundled together.

---

## Edge cases

### Test added alongside the feature it tests → same commit is acceptable
```
feat(auth): add OAuth client cache with 24-hour TTL

Includes tests in tests/test_state.py covering cache read/write/expiry.
```
Rationale: test and feature are tightly coupled — reverting the feature should also revert its tests.

### Dependency bump alone → `build` or `chore`
```
build(deps): upgrade requests to 2.32.0
```

### Multiple files, one concern → still one commit
Refactoring a module that touches 6 files but makes zero behaviour changes is one `refactor` commit.

### Unrelated whitespace-only change found while coding → separate `style` commit or ignore
Do not bundle unrelated style fixes with a `feat` or `fix`. Either make a standalone `style` commit or leave it for a dedicated cleanup pass.
