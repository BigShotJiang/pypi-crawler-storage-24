# Anti-Patterns — What NOT to Do

## Commit message anti-patterns

| Anti-pattern | Why it's wrong |
|---|---|
| `git commit -m "updates"` | No type — impossible to auto-generate CHANGELOG or version bump |
| `git commit -m "Fix stuff and add feature"` | Mixes `fix` and `feat` — can't revert independently |
| `git commit -m "WIP"` | Not a valid type; also breaks CI tools that parse messages |
| `git commit -m "feat(cli): Added new command."` | Past tense + trailing period — both are spec violations |
| `git commit -m "FEAT: add thing"` | Uppercase type — some parsers reject it (use lowercase) |
## Scope anti-patterns

| Anti-pattern | Why it's wrong |
|---|---|
| `fix: typo in cli` — using a description word as scope | Scope must be a module/subsystem noun, not a word from the description |
| `feat(switcher/cli.py): ...` — using a file path as scope | Scope is a logical name, not a filesystem path |
| `fix(everything): ...` — overly broad scope | Signals the commit is not atomic |
| `feat(): ...` — empty scope parentheses | Either provide a scope or omit the parentheses entirely |

## Staging anti-patterns

- Running `git add .` when only some files belong to the current logical unit.
- Committing test files in a separate commit from the feature they test (acceptable exception — see atomicity-guide.md).
- Committing generated files (compiled output, `*.pyc`, lock file noise) alongside source changes.

## Workflow anti-patterns

- Committing broken code (ruff errors, mypy errors, failing tests) — always check before committing if the repo has a test/lint suite.
- Using `git commit --amend` on already-pushed commits — rewrites shared history.
- Squashing all work into one commit at the end — loses the audit trail that Conventional Commits provides.
