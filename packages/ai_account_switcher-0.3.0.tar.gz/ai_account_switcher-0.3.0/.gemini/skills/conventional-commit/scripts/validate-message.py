#!/usr/bin/env python3
"""
validate-message.py — Validates a commit message against Conventional Commits 1.0.0.

Usage:
    python3 scripts/validate-message.py /path/to/commit_msg.txt

Exit codes:
    0  Message is valid
    1  Message is invalid (prints specific error to stdout)
"""

from __future__ import annotations

import re
import sys

VALID_TYPES = {
    "feat",
    "fix",
    "docs",
    "style",
    "refactor",
    "perf",
    "test",
    "build",
    "ci",
    "chore",
    "revert",
}

# Matches: type(scope)!: description  OR  type!: description  OR  type: description
SUBJECT_RE = re.compile(
    r"^(?P<type>[a-z]+)(?:\((?P<scope>[^)]+)\))?(?P<breaking>!)?:\s(?P<desc>.+)$"
)


def validate(path: str) -> tuple[bool, str]:
    try:
        text = open(path).read().strip()
    except OSError as e:
        return False, f"Cannot read file: {e}"

    lines = text.splitlines()
    if not lines:
        return False, "Commit message is empty."

    subject = lines[0]

    # Rule: subject ≤72 chars
    if len(subject) > 72:
        return False, f"Subject line is {len(subject)} chars (max 72): {subject!r}"

    # Rule: no trailing period
    if subject.endswith("."):
        return False, f"Subject line must not end with a period: {subject!r}"

    m = SUBJECT_RE.match(subject)
    if not m:
        return False, (
            f"Subject line does not match '<type>(<scope>): <description>': {subject!r}\n"
            f"Valid types: {', '.join(sorted(VALID_TYPES))}"
        )

    commit_type = m.group("type")
    if commit_type not in VALID_TYPES:
        return False, (
            f"Unknown type {commit_type!r}. "
            f"Valid types: {', '.join(sorted(VALID_TYPES))}"
        )

    desc = m.group("desc")
    if not desc or not desc[0].islower() and not desc[0].isdigit():
        return False, (
            f"Description should start with a lowercase letter or digit: {desc!r}"
        )

    # Rule: blank line between subject and body (if body exists)
    if len(lines) > 1 and lines[1].strip() != "":
        return False, "Missing blank line between subject and body."

    # Rule: BREAKING CHANGE in footer must be uppercase
    body_and_footer = "\n".join(lines[2:]) if len(lines) > 2 else ""
    if re.search(r"\bbreaking.change\b", body_and_footer, re.IGNORECASE):
        if not re.search(r"\bBREAKING.CHANGE\b", body_and_footer):
            return False, "Footer token must be 'BREAKING CHANGE' (uppercase)."

    return True, "OK"


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: validate-message.py <path-to-commit-msg-file>")
        sys.exit(1)

    ok, msg = validate(sys.argv[1])
    print(msg)
    sys.exit(0 if ok else 1)
