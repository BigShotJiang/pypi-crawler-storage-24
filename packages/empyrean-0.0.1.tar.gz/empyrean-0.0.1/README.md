# Empyrean

by [Empyrean Dynamics](https://www.empyrean-dynamics.com)

High-performance astrodynamics in Python, powered by automatic differentiation.

Orbit propagation, ephemeris generation, and orbit determination.

## Architecture

Empyrean is built on a stack of Rust libraries with Python bindings via PyO3.

- **nolan** — K-jet hyperdual numbers for automatic differentiation. Tracks
  arbitrary-order derivatives through physical parameters (position, velocity,
  time) without finite differences or hand-coded partials.

- **villeneuve** — Orbital propagator built on nolan. Two-body and n-body
  dynamics, relativistic force models, coordinate transforms, and covariance
  propagation.

- **scott** — Orbit determination. Differential corrections, initial orbit
  determination, and residual fitting. Uses the same AD pipeline for exact
  partials through the measurement model.

The full Empyrean Dynamics platform also includes:

- **kubrick** — REST API server exposing the propagation and orbit
  determination engines. Available as a hosted service at
  [www.empyrean-dynamics.com](https://www.empyrean-dynamics.com), not included in the
  Python package.

- **spielberg** — Interactive web dashboard for orbit visualization, close
  approach analysis, and impact probability. Available at
  [www.empyrean-dynamics.com](https://www.empyrean-dynamics.com), not included in the
  Python package.

Much more to come. Stay tuned.
