"""High-performance astrodynamics in Python, powered by automatic differentiation."""

__version__ = "0.0.1"
