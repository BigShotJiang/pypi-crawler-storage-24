Command line uploader for linx-server

Examples:

linx file.txt
    -> uploads file.txt with default options (requires LINX_INSTANCE env var)

linx -e 60 file.txt
    -> uploads file.txt with an expiration time of 60 seconds

linx --linx-instance https://linx.example.com file.txt
    -> uploads file.txt to a specific instance

echo "hello there" | linx --linx-instance https://linx.example.com
    -> uploads "hello there"

linx -d https://linx.example.com/3jah3.txt
    -> deletes 3jah3.txt from linx
