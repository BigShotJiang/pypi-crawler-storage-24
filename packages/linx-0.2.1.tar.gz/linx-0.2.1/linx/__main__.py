#!/usr/bin/env python3
###############################################################################
# linx - python uploader for linx-server
#
# author: mutantmonkey <mutantmonkey@mutantmonkey.in>
# author: andreimarcu <andrei@marcu.net>
###############################################################################
"""
Examples:

linx file.txt
    -> uploads file.txt with default options (requires LINX_INSTANCE env var)

linx -e 60 file.txt
    -> uploads file.txt with an expiration time of 60 seconds

linx --linx-instance https://linx.example.com file.txt
    -> uploads file.txt to a specific instance

echo "hello there" | linx --linx-instance https://linx.example.com
    -> uploads "hello there"

linx -d https://linx.example.com/3jah3.txt
    -> deletes 3jah3.txt from linx
"""

from urllib.parse import quote
import argparse
import requests
import os.path
import os
import json
import sys


logdir = os.path.join(os.path.expanduser("~"), ".local", "share")
if not os.path.exists(logdir):
    os.makedirs(logdir)

logpath = os.path.join(logdir, "linx.log")

user_agent = "linx-cli/0.1.5"


def stream_upload(f, total, label="", chunk_size=64*1024, no_progress=False):
    while True:
        data = f.read(chunk_size)
        if not data:
            if not no_progress:
                sys.stdout.write("\r")
                sys.stdout.write(''.join([' ' for x in label]))
                sys.stdout.write("\r")
                sys.stdout.flush()
            break

        yield data

        if not no_progress:
            sys.stdout.write("\r{label:40} {progress:7.2%}".format(
                label=label[-40:],
                progress=f.tell() / total))
            sys.stdout.flush()


def main():
    parser = argparse.ArgumentParser(description="Upload files to a linx-server instance.")
    parser.add_argument('-e', '--expires', type=int, default=0,
                        help="The relative expiration time (in seconds) of the file.")
    parser.add_argument('-d', '--delete', action="store_true", 
                        help="Deletes file from linx")
    parser.add_argument('-s', '--script', action="store_true", 
                        help="stdout will only print urls (no progress)")
    parser.add_argument('--linx-instance', type=str,
                        help="The linx-server instance to use (e.g. https://linx.example.com/). "
                             "Can also be set via LINX_INSTANCE environment variable.")
    parser.add_argument('files', nargs='*', metavar='file')
    args = parser.parse_args()

    # Determine instance URL
    instance_url = args.linx_instance or os.environ.get('LINX_INSTANCE')

    if not instance_url:
        print("Error: No linx-server instance specified. Use --linx-instance or set the LINX_INSTANCE environment variable.", file=sys.stderr)
        sys.exit(1)

    if not instance_url.endswith('/'):
        instance_url += '/'

    upload_path = instance_url + 'upload/'

    try:

        if args.delete:
            delete_keys = {}
            if os.path.exists(logpath):
                with open(logpath) as f:
                    for line in f:
                        line = line.strip().split(':')
                        if len(line) == 2:
                            delete_keys[line[0]] = line[1]

            for url in args.files:
                filename = os.path.basename(url)
                if not filename in delete_keys:
                    raise Exception("File does not exist in log.")

                r = requests.delete(
                    url,
                    verify=True,
                    headers={
                        'Linx-Delete-Key': delete_keys[filename],
                        'User-Agent': user_agent,
                    })

                if r.status_code == 200:
                    print("{filename}:{resp}".format(
                        filename=filename,
                        resp=r.text))
                else:
                    print("{filename}:{errormsg}".format(
                        filename=filename,
                        errormsg=r.status_code))
        else:
            logfile = open(logpath, 'a')

            if args.files:
                for filename in args.files:
                    if not os.path.exists(filename):
                        raise Exception("File {0} not found.".format(filename))

                    basename = os.path.basename(filename)
                    total = os.path.getsize(filename)

                    if total == 0:
                        raise Exception("File {0} is empty".format(filename))

                    with open(filename, 'rb') as f:
                        try:
                            r = requests.put(
                                upload_path + quote(basename),
                                verify=True,
                                headers={
                                    'Accept': "application/json",
                                    'Linx-Expiry': str(args.expires),
                                    'Linx-Randomize': "yes",
                                    'User-Agent': user_agent,
                                },
                                data=stream_upload(f, total, label=basename, no_progress=args.script))
                        except KeyboardInterrupt:
                            raise SystemExit

                        data = r.json()
                        print(data['url'])
                        logfile.write("{filename}:{delete_key}\n".format(**data))
            else:
                if not sys.stdin.isatty():
                    try:
                        data = sys.stdin.read().encode('utf-8')

                        if len(data) == 0:
                            raise Exception("stdin is empty.")

                        r = requests.put(
                            upload_path,
                            verify=True,
                            headers={
                                'Accept': "application/json",
                                'Linx-Expiry': str(args.expires),
                                'User-Agent': user_agent,
                            },
                            data=data)
                    except KeyboardInterrupt:
                        raise SystemExit

                    data = r.json()
                    print(data['url'])
                    logfile.write("{filename}:{delete_key}\n".format(**data))
                
                else:
                    parser.print_help()
                    print(__doc__)

    except Exception as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
