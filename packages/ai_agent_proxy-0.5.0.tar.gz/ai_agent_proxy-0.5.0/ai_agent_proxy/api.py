from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel

from .config import API_HOST, API_PORT, DEFAULT_MODE
from .runtime import ensure_role_ready, restart_role_session, stream_session_turn
from .workspace import manager_workspace_path


END_OF_REPLY = "END_OF_REPLY"


class ResponseRequest(BaseModel):
    model: str = "manager"
    input: Any
    instructions: str | None = None
    stream: bool = False
    metadata: dict[str, Any] | None = None


class ChatMessage(BaseModel):
    role: str
    content: Any


class ChatCompletionsRequest(BaseModel):
    model: str = "manager"
    messages: list[ChatMessage]
    stream: bool = False
    metadata: dict[str, Any] | None = None


def _stringify_input(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, str):
                if item.strip():
                    parts.append(item.strip())
                continue
            if isinstance(item, dict):
                item_type = str(item.get("type", "")).strip()
                if item_type in {"input_text", "text"}:
                    text = str(item.get("text", "")).strip()
                    if text:
                        parts.append(text)
                    continue
                role = str(item.get("role", "user")).strip() or "user"
                content = item.get("content", "")
                if isinstance(content, str):
                    text = content.strip()
                else:
                    text = _stringify_input(content)
                if text:
                    parts.append(f"{role}: {text}")
                continue
            text = str(item).strip()
            if text:
                parts.append(text)
        return "\n\n".join(parts).strip()
    if isinstance(value, dict):
        if "text" in value:
            return str(value.get("text", "")).strip()
        if "content" in value:
            return _stringify_input(value.get("content"))
    return str(value).strip()


def _short_message(text: str, limit: int = 120) -> str:
    compact = " ".join(text.split())
    if len(compact) <= limit:
        return compact
    return compact[: limit - 3] + "..."


def _ts() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _response_object(request: ResponseRequest, output_text: str, *, response_id: str | None = None) -> dict[str, Any]:
    response_id = response_id or f"resp_{uuid.uuid4().hex}"
    created_at = int(time.time())
    return {
        "id": response_id,
        "object": "response",
        "status": "completed",
        "model": request.model,
        "created_at": created_at,
        "error": None,
        "incomplete_details": None,
        "instructions": request.instructions,
        "metadata": request.metadata or {},
        "output": [
            {
                "id": f"msg_{uuid.uuid4().hex}",
                "type": "message",
                "role": "assistant",
                "content": [
                    {
                        "type": "output_text",
                        "text": output_text,
                    }
                ],
            }
        ],
        "output_text": output_text,
        "parallel_tool_calls": False,
        "temperature": None,
        "tool_choice": "none",
        "tools": [],
        "top_p": None,
        "max_output_tokens": None,
        "usage": {
            "input_tokens": None,
            "input_tokens_details": None,
            "output_tokens": None,
            "output_tokens_details": None,
            "total_tokens": None,
        },
    }


def _chat_completions_object(model: str, output_text: str) -> dict[str, Any]:
    created = int(time.time())
    return {
        "id": f"chatcmpl_{uuid.uuid4().hex}",
        "object": "chat.completion",
        "created": created,
        "model": model,
        "system_fingerprint": None,
        "choices": [
            {
                "index": 0,
                "finish_reason": "stop",
                "message": {
                    "role": "assistant",
                    "content": output_text,
                },
            }
        ],
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        },
    }


def _sse(event_type: str, payload: dict[str, Any]) -> str:
    return f"event: {event_type}\ndata: {json.dumps(payload, ensure_ascii=True)}\n\n"


def _sse_data(payload: dict[str, Any] | str) -> str:
    if isinstance(payload, str):
        return f"data: {payload}\n\n"
    return f"data: {json.dumps(payload, ensure_ascii=True)}\n\n"


def _manager_workspace(root: Path) -> Path:
    return manager_workspace_path()


def _session_key(metadata: dict[str, Any] | None) -> str:
    raw = str((metadata or {}).get("session_id") or (metadata or {}).get("conversation_id") or "default").strip()
    cleaned = re.sub(r"[^a-zA-Z0-9._-]+", "-", raw).strip("-._")
    return cleaned or "default"


def _user_label(metadata: dict[str, Any] | None) -> str | None:
    metadata = metadata or {}
    raw = (
        metadata.get("user")
        or metadata.get("user_id")
        or metadata.get("username")
        or metadata.get("user_name")
    )
    if raw is None:
        return None
    text = str(raw).strip()
    return text or None


def _load_json_file(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _session_route(workspace: Path) -> tuple[str, str]:
    xterm = _load_json_file(workspace / "control" / "xterm.json")
    session_name = str(xterm.get("session_name", "")).strip()
    pane_tty = str(xterm.get("pane_tty", "")).strip()
    target = pane_tty or session_name or str(workspace / "control" / "session.sock")
    return DEFAULT_MODE, target


def _iter_agent_paths(root: Path) -> list[Path]:
    paths: list[Path] = []
    seen: set[Path] = set()
    manager_path = manager_workspace_path()
    if manager_path.is_dir():
        paths.append(manager_path)
        seen.add(manager_path.resolve())
    if root.exists():
        for path in sorted(root.iterdir()):
            if not path.is_dir():
                continue
            resolved = path.resolve()
            if resolved in seen:
                continue
            if not (path / "control").is_dir():
                continue
            paths.append(path)
            seen.add(resolved)
    return paths


def _service_status(root: Path, api_key: str | None) -> dict[str, Any]:
    master_pid_file = root / "master.pid"
    master_pid = None
    if master_pid_file.exists():
        try:
            master_pid = int(master_pid_file.read_text(encoding="utf-8").strip())
            os.kill(master_pid, 0)
        except (OSError, ValueError):
            master_pid = None

    agents: list[dict[str, Any]] = []
    for path in _iter_agent_paths(root):
            session_pid_file = path / "control" / "session.pid"
            busy_file = path / "control" / "busy"
            request_busy_file = path / "control" / "request.busy"
            pid = None
            if session_pid_file.exists():
                try:
                    pid = int(session_pid_file.read_text(encoding="utf-8").strip())
                    os.kill(pid, 0)
                except (OSError, ValueError):
                    pid = None
            agents.append(
                {
                    "name": path.name,
                    "healthy": pid is not None,
                    "busy": pid is not None and (busy_file.exists() or request_busy_file.exists()),
                    "pid": pid,
                }
            )

    healthy_agents = sum(1 for agent in agents if agent["healthy"])
    return {
        "service_healthy": master_pid is not None,
        "master_pid": master_pid,
        "agent_count": len(agents),
        "healthy_agent_count": healthy_agents,
        "agents": agents,
        "api_key_required": api_key is not None,
    }


def _api_endpoint(root: Path) -> str:
    data = _load_json_file(root / "api.json")
    host = str(data.get("host", API_HOST))
    port = int(data.get("port", API_PORT))
    return f"http://{host}:{port}"

def _model_ids(root: Path) -> list[str]:
    models = {"manager"}
    for path in _iter_agent_paths(root):
        models.add(path.name)
    return sorted(models)


def _model_object(model_id: str) -> dict[str, Any]:
    return {
        "id": model_id,
        "object": "model",
        "created": 0,
        "owned_by": "ai-agent-proxy",
    }


def _require_api_key(request: Request, configured_key: str | None) -> None:
    if configured_key is None:
        return
    authorization = request.headers.get("Authorization", "")
    prefix = "Bearer "
    if not authorization.startswith(prefix):
        raise HTTPException(status_code=401, detail="missing bearer token")
    token = authorization[len(prefix) :].strip()
    if token != configured_key:
        raise HTTPException(status_code=401, detail="invalid bearer token")


def _working_dir(workspace: Path) -> Path:
    runtime = _load_json_file(workspace / "control" / "runtime.json")
    return Path(str(runtime.get("working_dir", workspace))).expanduser()


def _mailbox_paths(workspace: Path) -> tuple[Path, Path]:
    mailbox_dir = _working_dir(workspace) / ".mailbox"
    mailbox_dir.mkdir(parents=True, exist_ok=True)
    return mailbox_dir / "inbox", mailbox_dir / "outbox"


def _append_mailbox_entry(mailbox_file: Path, prompt: str, session_key: str, user_label: str | None) -> None:
    mailbox_file.write_text("", encoding="utf-8")
    header = [f"#conversation id: {session_key}"]
    if user_label:
        header.append(f"#user: {user_label}")
    instruction_lines = [
        "INSTRUCTION:",
        "Read only the content in .mailbox/inbox.",
        "Write only the final user-facing reply into .mailbox/outbox.",
        f"After the reply content, write {END_OF_REPLY} on its own line.",
        "Do not write protocol markers such as [[reply_to_current]].",
        "Do not write shell logs, status logs, or extra explanation into .mailbox/outbox.",
        "Do not delete or clear .mailbox/inbox or .mailbox/outbox yourself.",
        "FastAPI will remove or clear .mailbox/inbox and .mailbox/outbox after it receives the reply.",
    ]
    mailbox_file.write_text(
        "\n".join(header) + f"\n{prompt.rstrip()}\n\n" + "\n".join(instruction_lines) + "\n",
        encoding="utf-8",
    )


def _clear_file(path: Path) -> None:
    if path.exists():
        path.write_text("", encoding="utf-8")


def _remove_file(path: Path) -> None:
    path.unlink(missing_ok=True)


def _run_manager_turn(root: Path, request: ResponseRequest, request_path: str):
    prompt = _stringify_input(request.input)
    if not prompt:
        raise HTTPException(status_code=400, detail="input is required")
    ready = ensure_role_ready("manager", startup_working_dir=_manager_workspace(root))
    if ready is None:
        manager_workspace = init_role_workspace("manager", base_dir=root)
        restarted_pid = restart_role_session(manager_workspace)
        if restarted_pid is None:
            raise HTTPException(status_code=503, detail="manager not ready")
        ready = (manager_workspace, restarted_pid)
    workspace, _pid = ready
    inbox_file, outbox_file = _mailbox_paths(workspace)
    session_key = _session_key(request.metadata)
    user_label = _user_label(request.metadata)
    _append_mailbox_entry(inbox_file, prompt, session_key, user_label)
    _remove_file(outbox_file)
    reply_file = outbox_file
    reply_offset = 0
    cleanup_files = [inbox_file, outbox_file]
    session_prompt = "check .mailbox/inbox reply to .mailbox/outbox"
    prompt_line = (
        f'fastapi manager prompt path={request_path} model={request.model} '
        f'prompt={json.dumps(session_prompt, ensure_ascii=True)}'
    )
    logging.getLogger("ai_agent_proxy.fastapi").info(prompt_line)
    return workspace, session_prompt, reply_file, reply_offset, cleanup_files


def _chat_messages_to_prompt(messages: list[ChatMessage]) -> str:
    parts: list[str] = []
    for message in messages:
        content = _stringify_input(message.content)
        if content:
            parts.append(f"{message.role}: {content}")
    return "\n\n".join(parts).strip()


def _recover_session(workspace: Path, logger: logging.Logger, reason: str) -> None:
    logger.warning("recovering agent session workspace=%s reason=%s", workspace, reason)
    pid = restart_role_session(workspace)
    if pid is None:
        logger.error("failed to restart agent session workspace=%s", workspace)
    else:
        logger.info("restarted agent session workspace=%s pid=%s cli=%s", workspace, pid, DEFAULT_CLI)


def _start_session_capture(workspace: Path, manager_prompt: str, model: str, path: str) -> dict[str, Any]:
    logger = logging.getLogger("ai_agent_proxy.fastapi")
    state: dict[str, Any] = {"done": False, "error": None}

    def _worker() -> None:
        try:
            for event in stream_session_turn(workspace, manager_prompt):
                if event["event"] == "chunk":
                    chunk_line = f"fastapi raw session chunk path={path} model={model} chunk={json.dumps(event['data'], ensure_ascii=True)}"
                    logger.info(chunk_line)
                elif event["event"] == "error":
                    state["error"] = event["data"]
                    _recover_session(workspace, logger, event["data"])
                    break
        except Exception as exc:
            state["error"] = str(exc)
            _recover_session(workspace, logger, str(exc))
        finally:
            state["done"] = True

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()
    state["thread"] = thread
    return state


def _extract_reply_segment(text: str, offset: int) -> str | None:
    if offset > len(text):
        return None
    new_text = text[offset:]
    if END_OF_REPLY not in new_text:
        return None
    return new_text.split(END_OF_REPLY, 1)[0].rstrip()


def _wait_for_reply_text(
    reply_file: Path,
    state: dict[str, Any],
    start_offset: int,
    timeout_seconds: int = 180,
) -> str:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if reply_file.exists():
            text = reply_file.read_text(encoding="utf-8")
            segment = _extract_reply_segment(text, start_offset)
            if segment is not None:
                return segment
        if state.get("error"):
            raise HTTPException(status_code=503, detail=str(state["error"]))
        time.sleep(0.25)
    raise HTTPException(status_code=504, detail="timed out waiting for reply file")


def _response_events(reply_file: Path, state: dict[str, Any], model: str, start_offset: int):
    response_id = f"resp_{uuid.uuid4().hex}"
    created_at = int(time.time())
    yield _sse(
        "response.created",
        {
            "type": "response.created",
            "response": {
                "id": response_id,
                "object": "response",
                "created_at": created_at,
                "model": model,
                "status": "in_progress",
            },
        },
    )
    sent = 0
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        if reply_file.exists():
            text = reply_file.read_text(encoding="utf-8")
            segment = _extract_reply_segment(text, start_offset)
            content = segment if segment is not None else text[start_offset:]
            if len(content) > sent:
                delta = content[sent:]
                sent = len(content)
                if delta:
                    yield _sse(
                        "response.output_text.delta",
                        {
                            "type": "response.output_text.delta",
                            "response_id": response_id,
                            "delta": delta,
                        },
                    )
            if segment is not None:
                break
        if state.get("error"):
            yield _sse(
                "response.failed",
                {
                    "type": "response.failed",
                    "response_id": response_id,
                    "error": {"message": str(state["error"])},
                },
            )
            return
        time.sleep(0.25)
    else:
        yield _sse(
            "response.failed",
            {
                "type": "response.failed",
                "response_id": response_id,
                "error": {"message": "timed out waiting for reply file"},
            },
        )
        return
    yield _sse(
        "response.completed",
        {
            "type": "response.completed",
            "response": {
                "id": response_id,
                "object": "response",
                "created_at": created_at,
                "model": model,
                "status": "completed",
                "output": [
                    {
                        "id": f"msg_{uuid.uuid4().hex}",
                        "type": "message",
                        "role": "assistant",
                        "content": [
                            {
                                "type": "output_text",
                                "text": content.rstrip(),
                            }
                        ],
                    }
                ],
                "output_text": content.rstrip(),
            },
        },
    )


def _chat_completion_events(
    reply_file: Path, state: dict[str, Any], model: str, start_offset: int
):
    completion_id = f"chatcmpl_{uuid.uuid4().hex}"
    created = int(time.time())
    first_chunk = True
    sent = 0
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        if reply_file.exists():
            text = reply_file.read_text(encoding="utf-8")
            segment = _extract_reply_segment(text, start_offset)
            content = segment if segment is not None else text[start_offset:]
            if len(content) > sent:
                delta_text = content[sent:]
                sent = len(content)
                if delta_text:
                    delta: dict[str, Any] = {"content": delta_text}
                    if first_chunk:
                        delta["role"] = "assistant"
                        first_chunk = False
                    yield _sse_data(
                        {
                            "id": completion_id,
                            "object": "chat.completion.chunk",
                            "created": created,
                            "model": model,
                            "choices": [
                                {
                                    "index": 0,
                                    "delta": delta,
                                    "finish_reason": None,
                                }
                            ],
                        }
                    )
            if segment is not None:
                break
        if state.get("error"):
            yield _sse_data(
                {
                    "id": completion_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": model,
                    "choices": [
                        {
                            "index": 0,
                            "delta": {},
                            "finish_reason": "stop",
                        }
                    ],
                    "error": {"message": str(state["error"])},
                }
            )
            yield _sse_data("[DONE]")
            return
        time.sleep(0.25)
    else:
        yield _sse_data(
            {
                "id": completion_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                "error": {"message": "timed out waiting for reply file"},
            }
        )
        yield _sse_data("[DONE]")
        return
    yield _sse_data(
        {
            "id": completion_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [
                {
                    "index": 0,
                    "delta": {},
                    "finish_reason": "stop",
                }
            ],
        }
    )
    yield _sse_data("[DONE]")


def create_app(base_dir: Path | None = None, api_key: str | None = None) -> FastAPI:
    app = FastAPI(title="ai-agent-proxy")
    root_dir = base_dir or (Path.home() / ".ai_agent_proxy")
    configured_api_key = api_key.strip() or None if api_key else None
    logger = logging.getLogger("ai_agent_proxy.fastapi")
    manager_request_lock = threading.Lock()

    def _request_busy_file() -> Path:
        return _manager_workspace(root_dir) / "control" / "request.busy"

    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        request_line = f"fastapi request method={request.method} path={request.url.path}"
        logger.info(request_line)
        try:
            response = await call_next(request)
        except Exception:
            logger.exception("request failed method=%s path=%s", request.method, request.url.path)
            raise
        response_line = f"{request_line} status={response.status_code}"
        logger.info(response_line)
        return response

    def _web_ui() -> str:
        status = _service_status(root_dir, configured_api_key)
        agent_cards = "\n".join(
            f"""
          <div class="agent-card">
            <div>
              <strong>{agent["name"]}</strong>
              <div class="small">{'pid ' + str(agent['pid']) if agent['pid'] else 'not running'}</div>
            </div>
            <span class="pill {'working' if agent.get('busy') else ('healthy' if agent['healthy'] else 'stopped')}">{'working' if agent.get('busy') else ('healthy' if agent['healthy'] else 'stopped')}</span>
          </div>"""
            for agent in status["agents"]
        ) or '<div class="empty">No agents initialized yet.</div>'
        auth_text = (
            "API access requires `Authorization: Bearer <key>`."
            if status["api_key_required"]
            else "API access is currently open. Set an API key if you want protected access."
        )
        service_state = "healthy" if status["service_healthy"] else "not running"
        return f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ai-agent-proxy</title>
  <style>
    :root {{
      --bg:#0f1115;
      --panel:#171b22;
      --line:#2d3542;
      --ink:#e7ecf3;
      --muted:#96a0b2;
      --accent:#c96f31;
      --accent-soft:#2b1b10;
    }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; font-family:"IBM Plex Sans","Segoe UI",sans-serif; color:var(--ink); background:
      radial-gradient(circle at top left, rgba(201,111,49,0.18), transparent 28%),
      linear-gradient(180deg, #101319 0%, #0c0e13 100%);
      min-height:100vh; }}
    .app {{ min-height:100vh; display:flex; flex-direction:column; }}
    .main {{ display:flex; flex-direction:column; }}
    .header {{ padding:1rem 1.25rem; border-bottom:1px solid var(--line); background:rgba(23,27,34,0.92); }}
    .header h2 {{ margin:0; }}
    .header p {{ margin:0.35rem 0 0; color:var(--muted); }}
    .content {{ max-width:980px; margin:0 auto; padding:1.25rem; display:grid; gap:1rem; }}
    .hero {{ border:1px solid var(--line); background:rgba(23,27,34,0.96); border-radius:16px; padding:1.2rem; }}
    .hero h1 {{ margin:0 0 0.4rem; font-size:1.4rem; }}
    .hero p {{ margin:0.3rem 0; color:var(--muted); }}
    .stats {{ display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:0.85rem; }}
    .stat {{ border:1px solid var(--line); background:var(--panel); border-radius:14px; padding:1rem; }}
    .stat .label {{ color:var(--muted); font-size:0.78rem; text-transform:uppercase; letter-spacing:0.08em; }}
    .stat .value {{ font-size:1.5rem; margin-top:0.35rem; }}
    .panel {{ border:1px solid var(--line); background:var(--panel); border-radius:16px; padding:1rem; }}
    .panel h2 {{ margin:0 0 0.85rem; font-size:1rem; }}
    .agent-grid {{ display:grid; gap:0.75rem; }}
    .agent-card {{ display:flex; align-items:center; justify-content:space-between; gap:1rem; border:1px solid var(--line); border-radius:12px; padding:0.9rem 1rem; background:#131820; }}
    .pill {{ display:inline-flex; align-items:center; padding:0.3rem 0.65rem; border-radius:999px; font-size:0.8rem; text-transform:uppercase; letter-spacing:0.08em; }}
      .pill.healthy {{ background:#173122; color:#7ee2a8; }}
    .pill.working {{ background:#2b2412; color:#f6c66d; }}
    .pill.stopped {{ background:#341b1b; color:#f0a1a1; }}
    .small {{ color:var(--muted); font-size:0.86rem; margin-top:0.2rem; }}
    code.inline {{ background:#10141b; border:1px solid var(--line); border-radius:8px; padding:0.15rem 0.35rem; }}
    .empty {{ color:var(--muted); padding:0.5rem 0; }}
    @media (max-width: 900px) {{
      .content {{ padding:1rem; }}
    }}
  </style>
</head>
<body>
  <div class="app">
    <main class="main">
      <div class="header">
        <h2>AI Agent Proxy</h2>
        <p>Service status dashboard for the manager-first API.</p>
      </div>
      <div class="content">
        <section class="hero">
          <h1>Service is {service_state}</h1>
          <p>Use the API with an API key instead of using this page as a chatbot.</p>
          <p>{auth_text}</p>
          <p>Agents marked <code class="inline">working</code> are actively handling a prompt.</p>
          <p>Supported endpoints: <code class="inline">POST /v1/chat/completions</code> and <code class="inline">POST /v1/responses</code>.</p>
        </section>
        <section class="stats">
          <div class="stat">
            <div class="label">Master PID</div>
            <div class="value">{status["master_pid"] or "offline"}</div>
          </div>
          <div class="stat">
            <div class="label">Agents</div>
            <div class="value">{status["agent_count"]}</div>
          </div>
          <div class="stat">
            <div class="label">Healthy Agents</div>
            <div class="value">{status["healthy_agent_count"]}</div>
          </div>
          <div class="stat">
            <div class="label">API Auth</div>
            <div class="value">{"required" if status["api_key_required"] else "open"}</div>
          </div>
        </section>
        <section class="panel">
          <h2>Agents</h2>
          <div class="agent-grid">
            {agent_cards}
          </div>
        </section>
        <section class="panel">
          <h2>How To Use</h2>
          <p class="small">Send your clients to <code class="inline">POST /v1/chat/completions</code> or <code class="inline">POST /v1/responses</code> with <code class="inline">Authorization: Bearer &lt;api-key&gt;</code> when API auth is enabled.</p>
        </section>
      </div>
    </main>
  </div>
</body>
</html>"""

    @app.get("/", include_in_schema=False, response_class=HTMLResponse)
    def root_status() -> str:
        return _web_ui()

    @app.get("/web", response_class=HTMLResponse)
    def web() -> str:
        return _web_ui()

    @app.get("/health")
    def health(request: Request) -> dict[str, Any]:
        _require_api_key(request, configured_api_key)
        return {"ok": True, "endpoint": f"{_api_endpoint(root_dir)}/v1/responses", "manager": "manager"}

    @app.get("/v1/models")
    def list_models(request: Request) -> dict[str, Any]:
        _require_api_key(request, configured_api_key)
        return {
            "object": "list",
            "data": [_model_object(model_id) for model_id in _model_ids(root_dir)],
        }

    @app.get("/v1/models/{model_id}")
    def get_model(model_id: str, request: Request) -> dict[str, Any]:
        _require_api_key(request, configured_api_key)
        if model_id not in _model_ids(root_dir):
            raise HTTPException(status_code=404, detail="model not found")
        return _model_object(model_id)

    @app.post("/v1/responses")
    def responses(req: ResponseRequest, request: Request):
        _require_api_key(request, configured_api_key)
        body_line = f"fastapi request body path=/v1/responses body={json.dumps(req.model_dump(), ensure_ascii=True)}"
        logger.info(body_line)
        manager_request_lock.acquire()
        busy_file = _request_busy_file()
        busy_file.parent.mkdir(parents=True, exist_ok=True)
        busy_file.write_text("/v1/responses\n", encoding="utf-8")
        cleanup_files: list[Path] = []
        if req.stream:
            try:
                workspace, manager_prompt, reply_file, reply_offset, cleanup_files = _run_manager_turn(
                    root_dir, req, "/v1/responses"
                )
                mode, target = _session_route(workspace)
                started_at = time.monotonic()
                print(
                    f'[{_ts()}] request from "/v1/responses" mode="{mode}" prompt_to="{target}" "{_short_message(_stringify_input(req.input))}"',
                    flush=True,
                )
                state = _start_session_capture(workspace, manager_prompt, req.model, "/v1/responses")

                def _stream():
                    try:
                        yield from _response_events(reply_file, state, req.model, reply_offset)
                    finally:
                        for path in cleanup_files:
                            _remove_file(path)
                        busy_file.unlink(missing_ok=True)
                        manager_request_lock.release()

                return StreamingResponse(
                    _stream(),
                    media_type="text/event-stream",
                    headers={
                        "Cache-Control": "no-cache",
                        "Connection": "keep-alive",
                        "X-Accel-Buffering": "no",
                    },
                )
            except Exception:
                busy_file.unlink(missing_ok=True)
                manager_request_lock.release()
                raise

        try:
            workspace, manager_prompt, reply_file, reply_offset, cleanup_files = _run_manager_turn(
                root_dir, req, "/v1/responses"
            )
            mode, target = _session_route(workspace)
            started_at = time.monotonic()
            print(
                f'[{_ts()}] request from "/v1/responses" mode="{mode}" prompt_to="{target}" "{_short_message(_stringify_input(req.input))}"',
                flush=True,
            )
            state = _start_session_capture(workspace, manager_prompt, req.model, "/v1/responses")
            final_text = _wait_for_reply_text(reply_file, state, reply_offset)
            response_line = f"fastapi response body path=/v1/responses model={req.model} body={json.dumps(final_text, ensure_ascii=True)}"
            logger.info(response_line)
            print(
                f'[{_ts()}] return message "/v1/responses" mode="{mode}" prompt_to="{target}" elapsed="{time.monotonic() - started_at:.2f}s" "{_short_message(final_text)}"',
                flush=True,
            )
            return _response_object(req, final_text)
        finally:
            for path in cleanup_files:
                _remove_file(path)
            busy_file.unlink(missing_ok=True)
            manager_request_lock.release()

    @app.post("/v1/chat/completions")
    def chat_completions(req: ChatCompletionsRequest, request: Request):
        _require_api_key(request, configured_api_key)
        body_line = (
            f"fastapi request body path=/v1/chat/completions body="
            f"{json.dumps(req.model_dump(), ensure_ascii=True)}"
        )
        logger.info(body_line)
        prompt = _chat_messages_to_prompt(req.messages)
        if not prompt:
            raise HTTPException(status_code=400, detail="messages are required")
        response_req = ResponseRequest(
            model=req.model,
            input=prompt,
            stream=req.stream,
            metadata=req.metadata,
        )
        manager_request_lock.acquire()
        busy_file = _request_busy_file()
        busy_file.parent.mkdir(parents=True, exist_ok=True)
        busy_file.write_text("/v1/chat/completions\n", encoding="utf-8")
        cleanup_files: list[Path] = []
        if req.stream:
            try:
                workspace, manager_prompt, reply_file, reply_offset, cleanup_files = _run_manager_turn(
                    root_dir, response_req, "/v1/chat/completions"
                )
                mode, target = _session_route(workspace)
                started_at = time.monotonic()
                print(
                    f'[{_ts()}] request from "/v1/chat/completions" mode="{mode}" prompt_to="{target}" "{_short_message(prompt)}"',
                    flush=True,
                )
                state = _start_session_capture(workspace, manager_prompt, req.model, "/v1/chat/completions")

                def _stream():
                    try:
                        yield from _chat_completion_events(reply_file, state, req.model, reply_offset)
                    finally:
                        for path in cleanup_files:
                            _remove_file(path)
                        busy_file.unlink(missing_ok=True)
                        manager_request_lock.release()

                return StreamingResponse(
                    _stream(),
                    media_type="text/event-stream",
                    headers={
                        "Cache-Control": "no-cache",
                        "Connection": "keep-alive",
                        "X-Accel-Buffering": "no",
                    },
                )
            except Exception:
                busy_file.unlink(missing_ok=True)
                manager_request_lock.release()
                raise

        try:
            workspace, manager_prompt, reply_file, reply_offset, cleanup_files = _run_manager_turn(
                root_dir, response_req, "/v1/chat/completions"
            )
            mode, target = _session_route(workspace)
            started_at = time.monotonic()
            print(
                f'[{_ts()}] request from "/v1/chat/completions" mode="{mode}" prompt_to="{target}" "{_short_message(prompt)}"',
                flush=True,
            )
            state = _start_session_capture(workspace, manager_prompt, req.model, "/v1/chat/completions")
            final_text = _wait_for_reply_text(reply_file, state, reply_offset)
            response_line = (
                f"fastapi response body path=/v1/chat/completions "
                f"model={req.model} body={json.dumps(final_text, ensure_ascii=True)}"
            )
            logger.info(response_line)
            print(
                f'[{_ts()}] return message "/v1/chat/completions" mode="{mode}" prompt_to="{target}" elapsed="{time.monotonic() - started_at:.2f}s" "{_short_message(final_text)}"',
                flush=True,
            )
            return _chat_completions_object(req.model, final_text)
        finally:
            for path in cleanup_files:
                _remove_file(path)
            busy_file.unlink(missing_ok=True)
            manager_request_lock.release()

    return app
