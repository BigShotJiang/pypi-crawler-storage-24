from __future__ import annotations

import re
from datetime import date
from pathlib import Path

from .config import DEFAULT_MANAGER_WORKDIR


_ROLE_PATTERN = re.compile(r"[^a-z0-9_-]+")
_TEMPLATE_ROOT = Path(__file__).resolve().parent / "md" / "roles"


def _normalize_role(role: str) -> str:
    normalized = role.strip().lower().replace(" ", "-")
    normalized = _ROLE_PATTERN.sub("-", normalized)
    normalized = re.sub(r"-{2,}", "-", normalized).strip("-")
    if not normalized:
        raise ValueError("role must contain at least one letter or number")
    return normalized


def compose_agent_id(role: str, name: str | None = None) -> str:
    normalized_role = _normalize_role(role)
    if not name:
        return normalized_role
    normalized_name = _normalize_role(name)
    return f"{normalized_role}_{normalized_name}"


def manager_workspace_path() -> Path:
    return Path(DEFAULT_MANAGER_WORKDIR).expanduser()


def _write_if_missing(path: Path, content: str) -> None:
    if not path.exists():
        path.write_text(content, encoding="utf-8")


def _copy_role_templates(role: str, root: Path) -> None:
    template_dir = _TEMPLATE_ROOT / role
    if not template_dir.exists():
        return
    for src in sorted(template_dir.iterdir()):
        if src.is_file():
            dst = root / src.name
            if not dst.exists():
                dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")


def _manager_workspace_has_local_contract(root: Path) -> bool:
    required_files = ["AGENTS.md", "SOUL.md", "TOOLS.md", "USER.md", "HEARTBEAT.md"]
    return all((root / name).exists() for name in required_files) and (root / "memory").is_dir()


def _soul_template(role: str) -> str:
    title = role.replace("-", " ")
    capability_block = ""
    if role.startswith("manager"):
        capability_block = """

You are allowed to expand your own operating capability when needed:

- read the current working directory's markdown files first when they define project rules, workflow, or product behavior
- if that working-directory markdown exists, do not redundantly re-state your generic workspace markdown guidance in the task prompt
- browse official documentation and relevant websites to learn missing context
- download and install skills for yourself when a suitable skill is available
- learn from websites before answering capability questions when local instructions are incomplete
- when a task needs writable disk access such as cloning a repo or downloading assets, create and use a writable workspace like `~/workspace/`
"""
    return f"""# SOUL

You are the `{role}` role.

Operate with a clear long-term identity for {title}. Preserve durable information instead of letting useful context disappear between tasks.

Required habits:

- Write important long-term messages, facts, and decisions into `memory/memory.md`.
- Write a short task summary into today's note file under `notes/`.
- Review existing memory before starting substantial work.
{capability_block}
"""


def _agents_template(role: str) -> str:
    manager_block = ""
    if role.startswith("manager"):
        manager_block = """

## Capability Rules

- read markdown guidance in the active working directory first and treat it as the primary local contract for that task
- if working-directory markdown exists, do not redundantly include generic default-workspace markdown rules in the task prompt or response
- install a relevant skill for yourself when a missing skill blocks useful work
- browse official docs and relevant websites when local instructions are incomplete
- prefer learning from docs or trusted websites over claiming you cannot do the task
- when work needs a writable location, create and use a personal workspace such as `~/workspace/`
"""
    return f"""# AGENTS.md

## Role

This workspace belongs to the `{role}` role.

## Startup

Before beginning work:

1. Read `SOUL.md`.
2. Review `memory/memory.md`.
3. Open today's note file in `notes/`.

## Memory Rules

- Write lasting facts, decisions, important messages, and stable context into `memory/memory.md`.
- Keep memory concise and update stale entries when better information is available.

## Daily Notes

- Write a short task summary to today's note file in `notes/`.
- Keep entries brief, chronological, and useful for future review.
{manager_block}
"""


def _memory_template(role: str) -> str:
    return f"""# Memory

Long-term memory for the `{role}` role.

Use this file for:

- important messages worth keeping
- stable facts and context
- key decisions and working agreements

Keep entries concise. Update outdated information instead of duplicating it repeatedly.
"""


def _daily_note_template(role: str, today: date) -> str:
    return f"""# Daily Notes - {today.isoformat()}

Role: `{role}`

Add short summaries of tasks completed today. Keep the log brief and chronological.
"""


def ensure_daily_note(role_root: Path, today: date | None = None) -> Path:
    current_day = today or date.today()
    notes_dir = role_root / "notes"
    notes_dir.mkdir(parents=True, exist_ok=True)
    daily_note = notes_dir / f"daily-{current_day.isoformat()}.md"
    role = role_root.name
    _write_if_missing(daily_note, _daily_note_template(role, current_day))
    return daily_note


def init_role_workspace(role: str, name: str | None = None, base_dir: Path | None = None) -> Path:
    normalized_role = _normalize_role(role)
    agent_id = compose_agent_id(role, name)
    if normalized_role == "manager" and name is None:
        root = manager_workspace_path()
    else:
        root = (base_dir or (Path.home() / ".ai_agent_proxy")) / agent_id
    memory_dir = root / "memory"
    notes_dir = root / "notes"
    control_dir = root / "control"

    memory_dir.mkdir(parents=True, exist_ok=True)
    notes_dir.mkdir(parents=True, exist_ok=True)
    control_dir.mkdir(parents=True, exist_ok=True)
    (control_dir / "queue").mkdir(parents=True, exist_ok=True)
    (control_dir / "processed").mkdir(parents=True, exist_ok=True)

    if not (normalized_role == "manager" and name is None and _manager_workspace_has_local_contract(root)):
        _copy_role_templates(normalized_role, root)
    _write_if_missing(root / "SOUL.md", _soul_template(agent_id))
    _write_if_missing(root / "AGENTS.md", _agents_template(agent_id))
    _write_if_missing(memory_dir / "memory.md", _memory_template(agent_id))
    ensure_daily_note(root)

    return root
