from __future__ import annotations

import json
import os
import signal
import socket
import time
from datetime import datetime
from pathlib import Path
from typing import Iterator

from .config import DEFAULT_AGENT_INIT_CLI, DEFAULT_CLI, DEFAULT_MODE
from .workspace import compose_agent_id, init_role_workspace


def queue_request(workspace: Path, request: dict) -> None:
    queue_dir = workspace / "control" / "queue"
    queue_dir.mkdir(parents=True, exist_ok=True)
    request_file = queue_dir / f"{request['timestamp'].replace(':', '-').replace('.', '-')}.json"
    request_file.write_text(json.dumps(request, indent=2), encoding="utf-8")


def read_pid_file(pid_file: Path, cleanup_path: Path | None = None) -> int | None:
    if not pid_file.exists():
        return None
    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
        os.kill(pid, 0)
    except (OSError, ValueError):
        (cleanup_path or pid_file).unlink(missing_ok=True)
        return None
    proc_stat = Path(f"/proc/{pid}/stat")
    if proc_stat.exists():
        try:
            state = proc_stat.read_text(encoding="utf-8").split()[2]
        except Exception:
            return pid
        if state == "Z":
            (cleanup_path or pid_file).unlink(missing_ok=True)
            return None
    return pid


def read_running_pid(workspace: Path) -> int | None:
    return read_pid_file(workspace / "control" / "session.pid", cleanup_path=workspace / "control" / "session.pid")


def wait_for_pid(workspace: Path, timeout_seconds: int) -> int | None:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        pid = read_running_pid(workspace)
        if pid is not None and (workspace / "control" / "session.sock").exists():
            return pid
        time.sleep(0.2)
    return None


def ensure_role_ready(
    role: str,
    name: str | None = None,
    startup_working_dir: Path | None = None,
    cli: str = DEFAULT_CLI,
    init_cli: str = DEFAULT_AGENT_INIT_CLI,
) -> tuple[Path, int] | None:
    workspace = init_role_workspace(role, name=name)
    pid = read_running_pid(workspace)
    if pid is None:
        request = {
            "action": "connect",
            "agent": workspace.name,
            "working_dir": str((startup_working_dir or workspace).expanduser().resolve()),
            "cli": cli,
            "init_cli": init_cli,
            "mode": DEFAULT_MODE,
            "message": f"Now let us work on working dir: {workspace}",
            "timestamp": datetime.utcnow().isoformat(),
        }
        queue_request(workspace, request)
        pid = wait_for_pid(workspace, timeout_seconds=15)
        if pid is None:
            return None
    return workspace, pid


def _socket_path(workspace: Path) -> Path:
    return workspace / "control" / "session.sock"


def stream_session_turn(workspace: Path, prompt: str) -> Iterator[dict[str, str]]:
    sock_path = _socket_path(workspace)
    if not sock_path.exists():
        yield {"event": "error", "data": "agent session not ready"}
        return

    request = {"prompt": prompt}
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.connect(str(sock_path))
            client.sendall((json.dumps(request) + "\n").encode("utf-8"))
            client.shutdown(socket.SHUT_WR)
            with client.makefile("r", encoding="utf-8") as response_file:
                for raw_line in response_file:
                    raw_line = raw_line.rstrip("\n")
                    if not raw_line:
                        continue
                    try:
                        event = json.loads(raw_line)
                    except json.JSONDecodeError:
                        yield {"event": "error", "data": "invalid session response"}
                        return
                    yield {
                        "event": str(event.get("event", "error")),
                        "data": str(event.get("data", "")),
                    }
    except OSError as exc:
        yield {"event": "error", "data": f"failed to talk to session: {exc}"}


def _runtime_file(workspace: Path) -> Path:
    return workspace / "control" / "runtime.json"


def _load_runtime(workspace: Path) -> dict:
    runtime_file = _runtime_file(workspace)
    if not runtime_file.exists():
        return {}
    try:
        return json.loads(runtime_file.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_runtime(workspace: Path, data: dict) -> None:
    _runtime_file(workspace).write_text(json.dumps(data, indent=2), encoding="utf-8")


def _stop_pid(pid: int, timeout_seconds: float = 5.0) -> None:
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.1)
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        return


def restart_role_session(
    workspace: Path,
    cli: str | None = None,
    init_cli: str | None = None,
    timeout_seconds: int = 15,
) -> int | None:
    control_dir = workspace / "control"
    control_dir.mkdir(parents=True, exist_ok=True)
    session_pid = read_running_pid(workspace)
    if session_pid is not None:
        _stop_pid(session_pid)
    codex_pid = read_pid_file(control_dir / "codex.pid", cleanup_path=control_dir / "codex.pid")
    if codex_pid is not None:
        _stop_pid(codex_pid)
    (control_dir / "session.pid").unlink(missing_ok=True)
    (control_dir / "session.sock").unlink(missing_ok=True)
    (control_dir / "codex.pid").unlink(missing_ok=True)
    (control_dir / "busy").unlink(missing_ok=True)

    runtime = _load_runtime(workspace)
    working_dir = Path(runtime.get("working_dir", workspace)).expanduser().resolve()
    effective_cli = str(cli or runtime.get("cli") or DEFAULT_CLI)
    effective_init_cli = str(init_cli or runtime.get("init_cli") or DEFAULT_AGENT_INIT_CLI)
    runtime["autostart"] = True
    runtime["working_dir"] = str(working_dir)
    runtime["cli"] = effective_cli
    runtime["init_cli"] = effective_init_cli
    runtime["mode"] = DEFAULT_MODE
    runtime.pop("next_restart_at", None)
    _save_runtime(workspace, runtime)

    request = {
        "action": "connect",
        "agent": workspace.name,
        "working_dir": str(working_dir),
        "cli": effective_cli,
        "init_cli": effective_init_cli,
        "mode": DEFAULT_MODE,
        "message": f"Restart agent {workspace.name} with default cli after session failure",
        "timestamp": datetime.utcnow().isoformat(),
    }
    queue_request(workspace, request)
    return wait_for_pid(workspace, timeout_seconds=timeout_seconds)


def hire_agent(
    role: str,
    name: str,
    cli: str = DEFAULT_CLI,
    init_cli: str = DEFAULT_AGENT_INIT_CLI,
) -> tuple[str, Path, int] | None:
    agent_id = compose_agent_id(role, name)
    ready = ensure_role_ready(
        role,
        name=name,
        startup_working_dir=Path.home() / ".ai_agent_proxy" / agent_id,
        cli=cli,
        init_cli=init_cli,
    )
    if ready is None:
        return None
    workspace, pid = ready
    return agent_id, workspace, pid
