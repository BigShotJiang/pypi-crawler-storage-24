from __future__ import annotations

import argparse
import json
import logging
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Sequence

from .config import (
    API_HOST,
    API_PORT,
    DEFAULT_AGENT_INIT_CLI,
    DEFAULT_CLI,
    DEFAULT_MANAGER_WORKDIR,
    DEFAULT_MODE,
)
from .daemon import run_daemon
from .runtime import ensure_role_ready, hire_agent, queue_request, read_pid_file, read_running_pid
from .workspace import init_role_workspace, manager_workspace_path


def _cli_logger() -> logging.Logger:
    logs_dir = Path.home() / ".ai_agent_proxy" / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("ai_agent_proxy.cli")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    log_path = logs_dir / "cli.log"
    if not any(
        isinstance(handler, logging.FileHandler) and handler.baseFilename == str(log_path)
        for handler in logger.handlers
    ):
        handler = logging.FileHandler(log_path, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
        logger.addHandler(handler)
    return logger


def _is_agent_workspace(path: Path) -> bool:
    if not path.is_dir():
        return False
    return (
        (path / "SOUL.md").exists()
        and (path / "AGENTS.md").exists()
        and (path / "memory" / "memory.md").exists()
        and (path / "control").is_dir()
    )


def _iter_agent_workspaces(root: Path) -> list[Path]:
    workspaces: list[Path] = []
    seen: set[Path] = set()
    manager_path = manager_workspace_path()
    if _is_agent_workspace(manager_path):
        workspaces.append(manager_path)
        seen.add(manager_path.resolve())
    if root.exists():
        for path in sorted(root.iterdir()):
            if not _is_agent_workspace(path):
                continue
            resolved = path.resolve()
            if resolved in seen:
                continue
            workspaces.append(path)
            seen.add(resolved)
    return workspaces


def _load_config_file(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        parsed = value.strip()
        if len(parsed) >= 2 and parsed[0] == parsed[-1] and parsed[0] in {"'", '"'}:
            parsed = parsed[1:-1]
        data[key.strip().upper()] = parsed
    return data


def _load_json_file(path: Path) -> dict[str, object]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _tmux_default_socket() -> Path:
    return Path(f"/tmp/tmux-{os.getuid()}/default")


def _attach_tmux_session(workspace: Path) -> int:
    xterm_info = _load_json_file(workspace / "control" / "xterm.json")
    session_name = str(xterm_info.get("session_name", "")).strip()
    if not session_name:
        print(f"{workspace.name} tmux session not ready", file=sys.stderr)
        return 1
    socket_path = _tmux_default_socket()
    if not socket_path.exists():
        print(f"tmux socket not found: {socket_path}", file=sys.stderr)
        return 1
    env = os.environ.copy()
    env.pop("TMUX", None)
    return subprocess.run(
        ["tmux", "-S", str(socket_path), "attach-session", "-t", session_name],
        env=env,
        check=False,
    ).returncode


def _validate_config_file(path: Path, config: dict[str, str]) -> None:
    required_keys = ("HOST", "PORT", "API_KEY", "WORKDIR")
    missing = [key for key in required_keys if key not in config]
    if missing:
        raise SystemExit(f'config file "{path}" is missing required keys: {", ".join(missing)}')
    port = config.get("PORT", "").strip()
    try:
        port_value = int(port)
    except ValueError:
        raise SystemExit(f'config file "{path}" has invalid PORT: {port!r}; expected integer') from None
    if port_value <= 0:
        raise SystemExit(f'config file "{path}" has invalid PORT: {port!r}; expected positive integer')


def _config_value(config: dict[str, str], *keys: str, default: str | None = None) -> str | None:
    for key in keys:
        value = config.get(key)
        if value is not None:
            return value
    return default


def _config_defaults(config: dict[str, str] | None) -> dict[str, object]:
    config = config or {}
    base_dir = _config_value(config, "BASE_DIR")
    interval = _config_value(config, "INTERVAL")
    api_host = _config_value(config, "HOST", default=API_HOST)
    api_port = _config_value(config, "PORT")
    api_key = _config_value(config, "API_KEY", default="")
    agent_cli = _config_value(config, "AGENT_CLI")
    agent_init_cli = _config_value(config, "AGENT_INIT_CLI", "AGENT_DEFAULT_CLI")
    cli = _config_value(config, "CLI")
    if cli is None:
        cli = (agent_cli or DEFAULT_CLI).strip()
    workdir = _config_value(config, "WORKDIR", default=DEFAULT_MANAGER_WORKDIR)
    once = _config_value(config, "ONCE", default="")
    defaults: dict[str, object] = {
        "base_dir": Path(base_dir).expanduser() if base_dir else None,
        "interval": int(interval) if interval else 60,
        "api_host": api_host,
        "api_port": int(api_port) if api_port else API_PORT,
        "api_key": api_key,
        "cli": cli,
        "init_cli": (agent_init_cli or DEFAULT_AGENT_INIT_CLI).strip(),
        "workdir": workdir,
        "once": str(once).strip().lower() in {"1", "true", "yes", "on"},
    }
    return defaults


def build_parser(config: dict[str, str] | None = None) -> argparse.ArgumentParser:
    defaults = _config_defaults(config)
    parser = argparse.ArgumentParser(
        prog="ai-agent-proxy",
        description="Run the ai-agent-proxy service or manage agent workspaces.",
    )
    parser.add_argument("-f", "--config", type=Path, help="Load .env-style config file")
    parser.add_argument("--base-dir", type=Path, default=defaults["base_dir"], help="Base workspace directory, default: ~/.ai_agent_proxy")
    parser.add_argument("--interval", type=int, default=defaults["interval"], help="Polling interval in seconds")
    parser.add_argument("--host", dest="api_host", default=defaults["api_host"], help="API bind host")
    parser.add_argument("--port", dest="api_port", type=int, default=defaults["api_port"], help="API bind port")
    parser.add_argument("--api-key", default=defaults["api_key"], help="API key for Authorization: Bearer headers")
    parser.add_argument("--cli", default=defaults["cli"], help="Underlying agent CLI command")
    parser.add_argument("--init-cli", default=defaults["init_cli"], help="Agent init CLI command")
    parser.add_argument("--workdir", default=defaults["workdir"], help="Manager project workdir")
    parser.add_argument("--once", action="store_true", default=bool(defaults["once"]), help="Run one maintenance pass and exit")
    parser.set_defaults(handler=_handle_daemon)

    subparsers = parser.add_subparsers(dest="command", required=False)

    init = subparsers.add_parser("init", help="Initialize a role workspace under ~/.ai_agent_proxy")
    init.add_argument("role", help="Role name, for example researcher")
    init.add_argument("--cli", default=defaults["cli"], help="Underlying agent CLI command")
    init.add_argument("--init-cli", default=defaults["init_cli"], help="Agent init CLI command")
    init.set_defaults(handler=_handle_init)

    hire = subparsers.add_parser("hire", help="Create or reuse a named agent workspace and start it")
    hire.add_argument("role", help="Base role name, for example engineer")
    hire.add_argument("name", help="Agent name, for example alice")
    hire.add_argument("--cli", default=defaults["cli"], help="Underlying agent CLI command")
    hire.add_argument("--init-cli", default=defaults["init_cli"], help="Agent init CLI command")
    hire.set_defaults(handler=_handle_hire)

    list_cmd = subparsers.add_parser("list", help="List initialized agents")
    list_cmd.set_defaults(handler=_handle_list)

    status = subparsers.add_parser("status", help="Show the daemon and managed agent processes")
    status.set_defaults(handler=_handle_status)

    connect = subparsers.add_parser("connect", help="Attach to the live tmux session for an agent")
    connect.add_argument("agent", help="Agent role name")
    connect.add_argument("working_dir", nargs="?", default=".", help="Working directory, default: current directory")
    connect.add_argument("--cli", default=defaults["cli"], help="Underlying agent CLI command")
    connect.add_argument("--init-cli", default=defaults["init_cli"], help="Agent init CLI command")
    connect.set_defaults(handler=_handle_connect)

    stop = subparsers.add_parser("stop", help="Queue a stop request for an agent")
    stop.add_argument("role", help="Agent role name")
    stop.set_defaults(handler=_handle_stop)

    return parser


def _handle_init(args: argparse.Namespace) -> int:
    ready = ensure_role_ready(
        args.role,
        startup_working_dir=Path.home() / ".ai_agent_proxy" / args.role,
        cli=args.cli,
        init_cli=args.init_cli,
    )
    if ready is None:
        print(
            f"timed out waiting for the service master to spawn {args.role}; "
            "make sure `ai-agent-proxy` is running",
            file=sys.stderr,
        )
        return 1
    _workspace, pid = ready
    print(pid)
    return 0


def _handle_hire(args: argparse.Namespace) -> int:
    hired = hire_agent(args.role, args.name, cli=args.cli, init_cli=args.init_cli)
    if hired is None:
        print(
            f"timed out waiting for the service master to hire {args.role}_{args.name}; "
            "make sure `ai-agent-proxy` is running",
            file=sys.stderr,
        )
        return 1
    agent_id, _workspace, pid = hired
    print(f"{agent_id} {pid}")
    return 0


def _handle_daemon(args: argparse.Namespace) -> int:
    return run_daemon(
        base_dir=args.base_dir,
        interval=args.interval,
        once=args.once,
        api_host=args.api_host,
        api_port=args.api_port,
        api_key=args.api_key or None,
        cli=args.cli,
        init_cli=args.init_cli,
        workdir=Path(args.workdir).expanduser(),
    )


def _handle_list(args: argparse.Namespace) -> int:
    root = Path.home() / ".ai_agent_proxy"
    for path in _iter_agent_workspaces(root):
        print(path.name)
    return 0


def _handle_status(args: argparse.Namespace) -> int:
    root = Path.home() / ".ai_agent_proxy"
    master_pid = read_pid_file(root / "master.pid")
    api_host, api_port = _read_api_endpoint(root)
    master_label = "master"
    if master_pid is None:
        print(f"{master_label} (not running)")
    else:
        print(f"{master_label} (pid {master_pid}, endpoint http://{api_host}:{api_port})")

    if not root.exists():
        return 0

    roles = _iter_agent_workspaces(root)
    for index, workspace in enumerate(roles):
        pid = read_running_pid(workspace)
        branch = "└──" if index == len(roles) - 1 else "├──"
        if pid is None:
            print(f"{branch} {workspace.name} (stopped)")
        else:
            print(f"{branch} {workspace.name} (pid {pid})")
    return 0


def _read_api_endpoint(root: Path) -> tuple[str, int]:
    api_file = root / "api.json"
    if not api_file.exists():
        return API_HOST, API_PORT
    try:
        data = __import__("json").loads(api_file.read_text(encoding="utf-8"))
        return str(data.get("host", API_HOST)), int(data.get("port", API_PORT))
    except Exception:
        return API_HOST, API_PORT


def _handle_connect(args: argparse.Namespace) -> int:
    workspace = init_role_workspace(args.agent)
    runtime = _load_json_file(workspace / "control" / "runtime.json")
    runtime_mode = str(runtime.get("mode", "")).strip()
    if runtime_mode == DEFAULT_MODE:
        ready = ensure_role_ready(
            args.agent,
            startup_working_dir=workspace,
            cli=args.cli,
            init_cli=args.init_cli,
        )
        if ready is None:
            print(f"{workspace.name} not ready", file=sys.stderr)
            return 1
        return _attach_tmux_session(workspace)
    print(f"{workspace.name} tmux session not ready", file=sys.stderr)
    return 1


def _handle_stop(args: argparse.Namespace) -> int:
    workspace = init_role_workspace(args.role)
    request = {
        "action": "stop",
        "agent": workspace.name,
        "message": f"Stop agent {workspace.name}",
        "timestamp": datetime.utcnow().isoformat(),
    }
    queue_request(workspace, request)
    print(f"queued stop request for {workspace.name}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    logger = _cli_logger()
    try:
        argv = list(argv or sys.argv[1:])
        pre_parser = argparse.ArgumentParser(add_help=False)
        pre_parser.add_argument("-f", "--config", type=Path)
        pre_args, _ = pre_parser.parse_known_args(argv)
        config = None
        if pre_args.config:
            config_path = pre_args.config.expanduser()
            config = _load_config_file(config_path)
            _validate_config_file(config_path, config)
        parser = build_parser(config)
        args = parser.parse_args(argv)
        return args.handler(args)
    except KeyboardInterrupt:
        logger.info("cli interrupted by user")
        return 130
    except SystemExit:
        raise
    except Exception:
        logger.exception("cli command failed")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
