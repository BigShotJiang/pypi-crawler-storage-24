from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path


def _run_tmux(args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["tmux", *args],
        check=check,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )


def _tmux_has_session(session_name: str) -> bool:
    result = subprocess.run(
        ["tmux", "has-session", "-t", session_name],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        text=True,
    )
    return result.returncode == 0


def _pid_is_live(pid: int | None) -> bool:
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _append_log(log_file: Path, line: str) -> None:
    with log_file.open("a", encoding="utf-8") as handle:
        handle.write(line)


def _print_console(text: str) -> None:
    if not text:
        return
    print(text, end="" if text.endswith("\n") else "\n", flush=True)


def _send_literal_keys(session_name: str, text: str) -> None:
    _run_tmux(["send-keys", "-t", session_name, "-l", text])


def _send_shift_enter(session_name: str) -> None:
    _send_literal_keys(session_name, "\x1b[13;2u")


def _daemon_cli(cli: str) -> str:
    normalized = " ".join(cli.split())
    normalized = normalized.replace("codex exec resume --last", "codex resume --last")
    normalized = normalized.replace("|| codex exec ", "|| codex ")
    return normalized


@dataclass
class TerminalInfo:
    backend: str
    session_name: str
    pane_pid: int
    pane_tty: str


class XtermTmuxBackend:
    def __init__(self, role_dir: Path, working_dir: Path, cli: str, init_cli: str, log_file: Path) -> None:
        self.role_dir = role_dir
        self.working_dir = working_dir
        self.cli = _daemon_cli(cli)
        self.init_cli = init_cli.strip()
        self.log_file = log_file
        self.session_name = f"tmux-manager-{role_dir.name}"
        self.runtime_file = role_dir / "control" / "xterm.json"
        self.restart_notice_file = role_dir / "control" / "restart.required"

    def _shell_command(self) -> str:
        inner = f"cd {shlex.quote(str(self.working_dir))} && {self.cli}"
        return f"/bin/bash -lc {shlex.quote(inner)}"

    def _pane_value(self, fmt: str) -> str | None:
        if not _tmux_has_session(self.session_name):
            return None
        result = _run_tmux(["display-message", "-p", "-t", self.session_name, fmt], check=False)
        if result.returncode != 0:
            return None
        return result.stdout.strip() or None

    def info(self) -> TerminalInfo | None:
        pane_pid_text = self._pane_value("#{pane_pid}")
        pane_tty = self._pane_value("#{pane_tty}")
        if pane_pid_text is None or pane_tty is None:
            return None
        try:
            pane_pid = int(pane_pid_text)
        except ValueError:
            return None
        if not _pid_is_live(pane_pid):
            return None
        return TerminalInfo(backend="tmux", session_name=self.session_name, pane_pid=pane_pid, pane_tty=pane_tty)

    def _start_tmux_session(self) -> bool:
        result = _run_tmux(["new-session", "-d", "-s", self.session_name, self._shell_command()], check=False)
        if result.returncode != 0:
            _append_log(self.log_file, f"tmux launch failed: {result.stderr}\n")
            return False
        _run_tmux(["set-option", "-t", self.session_name, "remain-on-exit", "off"], check=False)
        _run_tmux(
            ["pipe-pane", "-o", "-t", self.session_name, f"cat >> {shlex.quote(str(self.log_file))}"],
            check=False,
        )
        time.sleep(0.4)
        self._bootstrap_interactive_startup()
        return True

    def ensure_started(self) -> TerminalInfo | None:
        if shutil.which("tmux") is None:
            return None
        info = self.info()
        if info is not None:
            self._write_runtime(info)
            return info
        self.stop()
        if not self._start_tmux_session():
            return None
        info = self.info()
        if info is None:
            _append_log(self.log_file, "tmux session started but backend not healthy yet\n")
            return None
        self._send_restart_notice_if_needed()
        self._write_runtime(info)
        return info

    def _write_runtime(self, info: TerminalInfo) -> None:
        self.runtime_file.write_text(
            json.dumps(
                {
                    "backend": info.backend,
                    "session_name": info.session_name,
                    "pane_pid": info.pane_pid,
                    "pane_tty": info.pane_tty,
                    "working_dir": str(self.working_dir),
                    "init_cli": self.init_cli,
                    "cli": self.cli,
                }
            ),
            encoding="utf-8",
        )

    def _bootstrap_interactive_startup(self) -> None:
        for _ in range(3):
            _run_tmux(["send-keys", "-t", self.session_name, "Enter"], check=False)
            time.sleep(0.3)

    def send_prompt(self, prompt: str, prompt_file: Path) -> None:
        prompt_file.write_text(prompt, encoding="utf-8")
        buffer_name = f"prompt-{int(time.time() * 1000)}"
        _run_tmux(["load-buffer", "-b", buffer_name, str(prompt_file)])
        try:
            _run_tmux(["paste-buffer", "-t", self.session_name, "-b", buffer_name])
            time.sleep(0.2)
            _append_log(self.log_file, "submit prompt with Enter, Shift-Enter, Enter\n")
            _run_tmux(["send-keys", "-t", self.session_name, "Enter"])
            time.sleep(0.1)
            _send_shift_enter(self.session_name)
            time.sleep(0.1)
            _run_tmux(["send-keys", "-t", self.session_name, "Enter"])
        finally:
            _run_tmux(["delete-buffer", "-b", buffer_name], check=False)
            prompt_file.unlink(missing_ok=True)

    def _send_restart_notice_if_needed(self) -> None:
        if not self.restart_notice_file.exists():
            return
        restart_prompt_file = self.role_dir / "control" / "restart-prompt.txt"
        restart_prompt = "you restart from a failure, no action need to to do until next prompt"
        _append_log(self.log_file, "send restart recovery prompt\n")
        self.send_prompt(restart_prompt, restart_prompt_file)
        self.restart_notice_file.unlink(missing_ok=True)

    def stop(self) -> None:
        _run_tmux(["kill-session", "-t", self.session_name], check=False)
        self.runtime_file.unlink(missing_ok=True)


TmuxPtyBackend = XtermTmuxBackend


def tmux_backend_ready(role_dir: Path, working_dir: Path, cli: str) -> bool:
    backend = XtermTmuxBackend(
        role_dir=role_dir,
        working_dir=working_dir,
        cli=cli,
        init_cli="",
        log_file=role_dir / "logs" / "tmux-health.log",
    )
    return backend.info() is not None
