from pathlib import Path


API_HOST = "0.0.0.0"
API_PORT = 7011
DEFAULT_MANAGER_WORKDIR = str(Path.home() / ".ai-agent" / "manager" / "workspace")
DEFAULT_MODE = "daemon"
DEFAULT_AGENT_CLI = "codex resume --last"
DEFAULT_AGENT_INIT_CLI = (
    "codex exec --skip-git-repo-check --dangerously-bypass-approvals-and-sandbox "
    "'load all markdown files and build yourself'"
)
DEFAULT_AGENT_DEFAULT_CLI = DEFAULT_AGENT_INIT_CLI
DEFAULT_CLI = DEFAULT_AGENT_CLI
