from __future__ import annotations

import json
import logging
import os
import shutil
import signal
import socket
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path

import uvicorn

from .api import create_app
from .config import API_HOST, API_PORT, DEFAULT_AGENT_INIT_CLI, DEFAULT_CLI, DEFAULT_MANAGER_WORKDIR, DEFAULT_MODE
from .terminal import tmux_backend_ready
from .workspace import ensure_daily_note, init_role_workspace


RESTART_DELAY_SECONDS = 10
STARTUP_ATTEMPTS = 3


def _pick_available_port(host: str, preferred_port: int, attempts: int = 20) -> int:
    for port in range(preferred_port, preferred_port + attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((host, port))
            except OSError:
                continue
        return port
    raise OSError(f"no available port found starting at {preferred_port}")


def _iter_role_dirs(base_dir: Path):
    if not base_dir.exists():
        return
    for path in sorted(base_dir.iterdir()):
        if path.is_dir():
            yield path


def _print_section(title: str) -> None:
    print(f"==== {title} ====", flush=True)


def _run_init_cli_blocking(working_dir: Path, init_cli: str) -> bool:
    print(f'workdir: {working_dir}', flush=True)
    print(f'init_cli: {init_cli}', flush=True)
    proc = subprocess.Popen(
        ["/bin/bash", "-lc", init_cli],
        cwd=str(working_dir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        print(line, end="", flush=True)
    return_code = proc.wait()
    print(f"exit_code: {return_code}", flush=True)
    return return_code == 0


def _pid_is_live(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    proc_stat = Path(f"/proc/{pid}/stat")
    if proc_stat.exists():
        try:
            state = proc_stat.read_text(encoding="utf-8").split()[2]
        except Exception:
            return True
        if state == "Z":
            return False
    return True


def _runtime_file(role_dir: Path) -> Path:
    return role_dir / "control" / "runtime.json"


def _load_runtime(role_dir: Path) -> dict:
    runtime_file = _runtime_file(role_dir)
    if not runtime_file.exists():
        return {}
    try:
        return json.loads(runtime_file.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_runtime(role_dir: Path, data: dict) -> None:
    _runtime_file(role_dir).write_text(json.dumps(data, indent=2), encoding="utf-8")


def _session_pid_file(role_dir: Path) -> Path:
    return role_dir / "control" / "session.pid"


def _session_socket(role_dir: Path) -> Path:
    return role_dir / "control" / "session.sock"


def _load_json_file(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _wait_for_tmux_backend(role_dir: Path, timeout_seconds: float = 10.0) -> dict:
    xterm_file = role_dir / "control" / "xterm.json"
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        info = _load_json_file(xterm_file)
        if info.get("backend") == "tmux" and (info.get("session_name") or info.get("pane_tty")):
            return info
        time.sleep(0.1)
    return {}


def _tmux_backend_alive(role_dir: Path, working_dir: Path, cli: str) -> bool:
    return tmux_backend_ready(role_dir, working_dir, cli)


def _spawn_role(
    role_dir: Path,
    working_dir: Path,
    request_name: str,
    cli: str = DEFAULT_CLI,
    init_cli: str = DEFAULT_AGENT_INIT_CLI,
) -> int | None:
    python = shutil.which("python3") or shutil.which("python")
    if python is None:
        return None
    session_pid_file = _session_pid_file(role_dir)
    if session_pid_file.exists():
        try:
            session_pid = int(session_pid_file.read_text(encoding="utf-8").strip())
        except ValueError:
            session_pid = None
        if (
            session_pid is not None
            and _pid_is_live(session_pid)
            and _session_socket(role_dir).exists()
            and _tmux_backend_alive(role_dir, working_dir, cli)
        ):
            return session_pid
        session_pid_file.unlink(missing_ok=True)
    log_dir = role_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"codex-{request_name}.log"
    proc = subprocess.Popen(
        [
            python,
            "-m",
            "ai_agent_proxy.session",
            "--role-dir",
            str(role_dir),
            "--working-dir",
            str(working_dir),
            "--log-file",
            str(log_file),
            "--cli",
            cli,
            "--init-cli",
            init_cli,
        ],
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    session_pid_file.write_text(str(proc.pid), encoding="utf-8")
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        if session_pid_file.exists() and _session_socket(role_dir).exists():
            try:
                return int(session_pid_file.read_text(encoding="utf-8").strip())
            except ValueError:
                return None
        time.sleep(0.1)
    return None


def _ensure_desired_role_running(role_dir: Path) -> None:
    runtime = _load_runtime(role_dir)
    if not runtime.get("autostart"):
        return
    now = time.time()
    session_pid_file = _session_pid_file(role_dir)
    if session_pid_file.exists():
        try:
            pid = int(session_pid_file.read_text(encoding="utf-8").strip())
        except ValueError:
            pid = None
        mode = str(runtime.get("mode", DEFAULT_MODE))
        working_dir = Path(runtime.get("working_dir", role_dir)).expanduser()
        cli = str(runtime.get("cli", DEFAULT_CLI))
        init_cli = str(runtime.get("init_cli", DEFAULT_AGENT_INIT_CLI))
        if (
            pid is not None
            and _pid_is_live(pid)
            and _session_socket(role_dir).exists()
            and _tmux_backend_alive(role_dir, working_dir, cli)
        ):
            runtime.pop("next_restart_at", None)
            _save_runtime(role_dir, runtime)
            return
        session_pid_file.unlink(missing_ok=True)
    next_restart_at = float(runtime.get("next_restart_at", 0))
    if now < next_restart_at:
        return
    working_dir = Path(runtime.get("working_dir", role_dir)).expanduser()
    cli = str(runtime.get("cli", DEFAULT_CLI))
    init_cli = str(runtime.get("init_cli", DEFAULT_AGENT_INIT_CLI))
    mode = str(runtime.get("mode", DEFAULT_MODE))
    request_name = f"restart-{int(time.time())}"
    (role_dir / "control" / "restart.required").write_text("required\n", encoding="utf-8")
    pid = _spawn_role(role_dir, working_dir, request_name, cli=cli, init_cli=init_cli)
    if pid is not None:
        runtime["last_pid"] = pid
        runtime.pop("next_restart_at", None)
    else:
        (role_dir / "control" / "restart.required").unlink(missing_ok=True)
        runtime["next_restart_at"] = now + RESTART_DELAY_SECONDS
    _save_runtime(role_dir, runtime)


def _handle_connect_requests(role_dir: Path) -> None:
    queue_dir = role_dir / "control" / "queue"
    processed_dir = role_dir / "control" / "processed"
    log_dir = role_dir / "logs"
    queue_dir.mkdir(parents=True, exist_ok=True)
    processed_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)

    for request_file in sorted(queue_dir.glob("*.json")):
        request = json.loads(request_file.read_text(encoding="utf-8"))
        action = request.get("action", "connect")
        session_pid_file = _session_pid_file(role_dir)

        if action == "connect":
            working_dir = Path(request["working_dir"]).expanduser()
            runtime = _load_runtime(role_dir)
            runtime["autostart"] = True
            runtime["working_dir"] = str(working_dir)
            runtime["cli"] = str(request.get("cli") or runtime.get("cli") or DEFAULT_CLI)
            runtime["init_cli"] = str(request.get("init_cli") or runtime.get("init_cli") or DEFAULT_AGENT_INIT_CLI)
            runtime["mode"] = DEFAULT_MODE
            runtime.pop("next_restart_at", None)
            pid = _spawn_role(role_dir, working_dir, request_file.stem, cli=runtime["cli"], init_cli=runtime["init_cli"])
            if pid is not None:
                runtime["last_pid"] = pid
            else:
                runtime["next_restart_at"] = time.time() + RESTART_DELAY_SECONDS
            _save_runtime(role_dir, runtime)
        elif action == "stop":
            runtime = _load_runtime(role_dir)
            runtime["autostart"] = False
            runtime.pop("next_restart_at", None)
            if session_pid_file.exists():
                try:
                    session_pid = int(session_pid_file.read_text(encoding="utf-8").strip())
                except ValueError:
                    session_pid = None
                if session_pid is not None and _pid_is_live(session_pid):
                    try:
                        os.kill(session_pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                session_pid_file.unlink(missing_ok=True)
            (role_dir / "control" / "codex.pid").unlink(missing_ok=True)
            _save_runtime(role_dir, runtime)

        request_file.rename(processed_dir / request_file.name)


def _ensure_manager_started(root: Path, manager_working_dir: Path) -> None:
    manager_dir = init_role_workspace("manager", base_dir=root)
    manager_working_dir.mkdir(parents=True, exist_ok=True)
    runtime = _load_runtime(manager_dir)
    runtime["autostart"] = True
    runtime["working_dir"] = str(manager_working_dir)
    runtime.setdefault("cli", DEFAULT_CLI)
    runtime.setdefault("init_cli", DEFAULT_AGENT_INIT_CLI)
    runtime["mode"] = DEFAULT_MODE
    runtime.pop("next_restart_at", None)
    _save_runtime(manager_dir, runtime)
    _ensure_desired_role_running(manager_dir)


def _api_runtime_file(root: Path) -> Path:
    return root / "api.json"


def _configure_logging(root: Path) -> None:
    logs_dir = root / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")

    def _attach_logger(name: str, path: Path) -> logging.Logger:
        logger = logging.getLogger(name)
        logger.setLevel(logging.INFO)
        logger.propagate = False
        path_str = str(path)
        for handler in logger.handlers:
            if isinstance(handler, logging.FileHandler) and handler.baseFilename == path_str:
                continue
        if not any(
            isinstance(handler, logging.FileHandler) and handler.baseFilename == path_str for handler in logger.handlers
        ):
            handler = logging.FileHandler(path, encoding="utf-8")
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        return logger

    _attach_logger("ai_agent_proxy.daemon", logs_dir / "daemon.log")
    _attach_logger("ai_agent_proxy.fastapi", logs_dir / "fastapi.log")
    _attach_logger("uvicorn.error", logs_dir / "fastapi.log")
    _attach_logger("uvicorn.access", logs_dir / "fastapi.log")


def _stop_role(role_dir: Path) -> None:
    session_pid_file = _session_pid_file(role_dir)
    pid = None
    if session_pid_file.exists():
        try:
            pid = int(session_pid_file.read_text(encoding="utf-8").strip())
        except ValueError:
            pid = None
    if pid is not None and _pid_is_live(pid):
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and _pid_is_live(pid):
            time.sleep(0.1)
        if _pid_is_live(pid):
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    session_pid_file.unlink(missing_ok=True)
    _session_socket(role_dir).unlink(missing_ok=True)
    (role_dir / "control" / "codex.pid").unlink(missing_ok=True)
    (role_dir / "control" / "xterm.json").unlink(missing_ok=True)
    (role_dir / "control" / "pending-prompt.txt").unlink(missing_ok=True)
    (role_dir / "control" / "restart.required").unlink(missing_ok=True)
    (role_dir / "control" / "restart-prompt.txt").unlink(missing_ok=True)
    (role_dir / "control" / "busy").unlink(missing_ok=True)


def _stop_all_roles(root: Path) -> None:
    for role_dir in list(_iter_role_dirs(root) or []):
        _stop_role(role_dir)


def _monitor_loop(root: Path, manager_working_dir: Path, stop_event: threading.Event, interval: int) -> None:
    logger = logging.getLogger("ai_agent_proxy.daemon")
    while not stop_event.is_set():
        try:
            _ensure_manager_started(root, manager_working_dir)
            for role_dir in _iter_role_dirs(root):
                ensure_daily_note(role_dir)
                _ensure_desired_role_running(role_dir)
                _handle_connect_requests(role_dir)
        except Exception:
            logger.exception("background monitor loop failed")
        stop_event.wait(max(interval, 1))


def run_daemon(
    base_dir: Path | None = None,
    interval: int = 60,
    once: bool = False,
    api_host: str = API_HOST,
    api_port: int = API_PORT,
    api_key: str | None = None,
    cli: str = DEFAULT_CLI,
    init_cli: str = DEFAULT_AGENT_INIT_CLI,
    workdir: Path | None = None,
) -> int:
    root = base_dir or (Path.home() / ".ai_agent_proxy")
    root.mkdir(parents=True, exist_ok=True)
    manager_working_dir = (workdir or Path(DEFAULT_MANAGER_WORKDIR)).expanduser()
    _print_section("Parameters")
    print('service: ai-agent-proxy', flush=True)
    print(f'mode: {DEFAULT_MODE}', flush=True)
    print(f'host: {api_host}', flush=True)
    print(f'port: {api_port}', flush=True)
    print(f'workdir: {manager_working_dir}', flush=True)
    print(f'init_cli: {init_cli}', flush=True)
    print(f'agent_cli: {cli}', flush=True)
    _configure_logging(root)
    manager_dir = init_role_workspace("manager", base_dir=root)
    manager_working_dir.mkdir(parents=True, exist_ok=True)
    xterm_info: dict = {}
    for attempt in range(1, STARTUP_ATTEMPTS + 1):
        _print_section("Build Agent Identity")
        print(f"attempt: {attempt}/{STARTUP_ATTEMPTS}", flush=True)
        _stop_role(manager_dir)
        if not _run_init_cli_blocking(manager_working_dir, init_cli):
            continue
        _print_section("Start Backend Agent Process")
        print(f'backend: tmux', flush=True)
        print(f'agent_cli: {cli}', flush=True)
        manager_runtime = _load_runtime(manager_dir)
        manager_runtime["autostart"] = True
        manager_runtime["working_dir"] = str(manager_working_dir)
        manager_runtime["cli"] = cli
        manager_runtime["init_cli"] = init_cli
        manager_runtime["mode"] = DEFAULT_MODE
        manager_runtime.pop("next_restart_at", None)
        _save_runtime(manager_dir, manager_runtime)
        _spawn_role(manager_dir, manager_working_dir, f"startup-{attempt}", cli=cli, init_cli="")
        print("status: waiting for manager xterm backend", flush=True)
        xterm_info = _wait_for_tmux_backend(manager_dir)
        if xterm_info:
            session_name = str(xterm_info.get("session_name", "")).strip()
            pane_tty = str(xterm_info.get("pane_tty", "")).strip()
            print(f"session_name: {session_name}", flush=True)
            print(f"target: {pane_tty or session_name}", flush=True)
            break
    if not xterm_info:
        raise RuntimeError("manager xterm backend did not start; refusing to serve requests")
    manager_pid = None
    session_pid_file = _session_pid_file(manager_dir)
    if session_pid_file.exists():
        try:
            manager_pid = int(session_pid_file.read_text(encoding="utf-8").strip())
        except ValueError:
            manager_pid = None
    master_pid_file = root / "master.pid"
    master_pid_file.write_text(str(os.getpid()), encoding="utf-8")
    actual_port = _pick_available_port(api_host, api_port)
    _api_runtime_file(root).write_text(json.dumps({"host": api_host, "port": actual_port}), encoding="utf-8")
    stop_event = threading.Event()
    monitor_thread = threading.Thread(
        target=_monitor_loop, args=(root, manager_working_dir, stop_event, interval), daemon=True
    )
    monitor_thread.start()

    logging.getLogger("ai_agent_proxy.daemon").info(
        "daemon watching %s and serving http://%s:%s", root, api_host, actual_port
    )
    logging.getLogger("ai_agent_proxy.daemon").info("configured agent init CLI: %s", init_cli)
    logging.getLogger("ai_agent_proxy.daemon").info("configured agent CLI: %s", cli)
    logging.getLogger("ai_agent_proxy.daemon").info("configured session mode: %s", DEFAULT_MODE)
    logging.getLogger("ai_agent_proxy.daemon").info("manager workdir: %s", manager_working_dir)
    _print_section("Start FastAPI")
    print(f'endpoint: http://{api_host}:{actual_port}', flush=True)
    session_name = str(xterm_info.get("session_name", "")).strip()
    pane_tty = str(xterm_info.get("pane_tty", "")).strip()
    backend = str(xterm_info.get("backend", "")).strip() or "tmux"
    if session_name or pane_tty:
        tmux_target = pane_tty or session_name
        print(f'backend: {backend}', flush=True)
        print(f'target: {tmux_target}', flush=True)
    elif manager_pid is None:
        print('backend: starting', flush=True)
    else:
        print(f'backend: {backend}', flush=True)
        print(f'session_pid: {manager_pid}', flush=True)
    print(f'ready: http://{api_host}:{actual_port}', flush=True)
    app = create_app(root, api_key=api_key)
    config = uvicorn.Config(app, host=api_host, port=actual_port, log_level="warning", workers=1)
    server = uvicorn.Server(config)
    if once:
        stop_event.set()
    try:
        server.run()
    finally:
        stop_event.set()
        monitor_thread.join(timeout=5)
    _stop_all_roles(root)
    master_pid_file.unlink(missing_ok=True)
    _api_runtime_file(root).unlink(missing_ok=True)
    return 0
