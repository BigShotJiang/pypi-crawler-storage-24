from __future__ import annotations

import argparse
import json
import os
import signal
import socket
import subprocess
import time
from pathlib import Path

from .config import DEFAULT_AGENT_INIT_CLI, DEFAULT_CLI, DEFAULT_MODE
from .terminal import XtermTmuxBackend


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ai_agent_proxy.session")
    parser.add_argument("--role-dir", required=True)
    parser.add_argument("--working-dir", required=True)
    parser.add_argument("--log-file", required=True)
    parser.add_argument("--cli", default=DEFAULT_CLI)
    parser.add_argument("--init-cli", default=DEFAULT_AGENT_INIT_CLI)
    return parser


def _cleanup(paths: list[Path]) -> None:
    for path in paths:
        path.unlink(missing_ok=True)


def _send_event(conn: socket.socket, event: str, data: str) -> None:
    payload = json.dumps({"event": event, "data": data})
    conn.sendall(payload.encode("utf-8") + b"\n")


def _read_request(conn: socket.socket) -> dict | None:
    data = bytearray()
    while True:
        chunk = conn.recv(4096)
        if not chunk:
            break
        data.extend(chunk)
        if b"\n" in chunk:
            break
    if not data:
        return None
    raw = data.decode("utf-8").splitlines()[0].strip()
    if not raw:
        return None
    return json.loads(raw)


def _append_log(log_file: Path, line: str) -> None:
    with log_file.open("a", encoding="utf-8") as handle:
        handle.write(line)


def _run_tmux_mode(
    conn: socket.socket,
    role_dir: Path,
    working_dir: Path,
    cli: str,
    init_cli: str,
    prompt: str,
    log_file: Path,
    codex_pid_file: Path,
    prompt_file: Path,
    xterm_file: Path,
) -> None:
    backend = XtermTmuxBackend(
        role_dir=role_dir,
        working_dir=working_dir,
        cli=cli,
        init_cli=init_cli,
        log_file=log_file,
    )
    terminal = backend.ensure_started()
    if terminal is None:
        _send_event(conn, "error", f"terminal backend failed to start for CLI: {cli}")
        return
    try:
        codex_pid_file.write_text(str(terminal.pane_pid), encoding="utf-8")
        _send_event(conn, "status", "starting")
        _send_event(conn, "status", f"terminal={terminal.session_name} tty={terminal.pane_tty}")
        backend.send_prompt(prompt, prompt_file)
        _send_event(conn, "done", "")
    except subprocess.CalledProcessError as exc:
        backend.stop()
        xterm_file.unlink(missing_ok=True)
        codex_pid_file.unlink(missing_ok=True)
        _send_event(conn, "error", f"failed to send prompt to terminal backend: {exc}")


def _ensure_tmux_backend_started(
    role_dir: Path,
    working_dir: Path,
    cli: str,
    init_cli: str,
    log_file: Path,
    codex_pid_file: Path,
) -> str | None:
    backend = XtermTmuxBackend(
        role_dir=role_dir,
        working_dir=working_dir,
        cli=cli,
        init_cli=init_cli,
        log_file=log_file,
    )
    terminal = backend.ensure_started()
    if terminal is None:
        return None
    codex_pid_file.write_text(str(terminal.pane_pid), encoding="utf-8")
    return f"tmux backend ready session={terminal.session_name} tty={terminal.pane_tty} pid={terminal.pane_pid}\n"


def main() -> int:
    args = _build_parser().parse_args()
    role_dir = Path(args.role_dir)
    working_dir = Path(args.working_dir).expanduser()
    log_file = Path(args.log_file)
    control_dir = role_dir / "control"
    control_dir.mkdir(parents=True, exist_ok=True)
    sock_path = control_dir / "session.sock"
    codex_pid_file = control_dir / "codex.pid"
    session_pid_file = control_dir / "session.pid"
    busy_file = control_dir / "busy"
    prompt_file = control_dir / "pending-prompt.txt"
    xterm_file = control_dir / "xterm.json"
    _cleanup([sock_path, busy_file, codex_pid_file, prompt_file])
    session_pid_file.write_text(str(os.getpid()), encoding="utf-8")

    should_stop = False

    def _stop(signum, frame):  # type: ignore[no-untyped-def]
        nonlocal should_stop
        should_stop = True

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)

    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(str(sock_path))
    server.listen(5)
    server.settimeout(1.0)

    startup_line = (
        f"session startup role_dir={role_dir} working_dir={working_dir} "
        f"init_cli={args.init_cli} cli={args.cli} mode={DEFAULT_MODE} transport=fastapi->xterm->tmux->codex\n"
    )
    _append_log(log_file, startup_line)
    tmux_line = _ensure_tmux_backend_started(role_dir, working_dir, args.cli, args.init_cli, log_file, codex_pid_file)
    if tmux_line is None:
        _append_log(log_file, "tmux backend failed to start during session bootstrap\n")
    else:
        _append_log(log_file, tmux_line)
    codex_pid_file.unlink(missing_ok=True)

    try:
        while not should_stop:
            try:
                conn, _ = server.accept()
            except socket.timeout:
                continue
            except OSError:
                if should_stop:
                    break
                raise
            with conn:
                try:
                    request = _read_request(conn)
                except json.JSONDecodeError:
                    _send_event(conn, "error", "invalid request payload")
                    continue
                if request is None:
                    _send_event(conn, "error", "empty request payload")
                    continue
                prompt = str(request.get("prompt", "")).strip()
                if not prompt:
                    _send_event(conn, "error", "prompt is required")
                    continue
                busy_file.write_text(prompt[:2000], encoding="utf-8")
                try:
                    _run_tmux_mode(
                        conn,
                        role_dir,
                        working_dir,
                        args.cli,
                        args.init_cli,
                        prompt,
                        log_file,
                        codex_pid_file,
                        prompt_file,
                        xterm_file,
                    )
                finally:
                    codex_pid_file.unlink(missing_ok=True)
                    busy_file.unlink(missing_ok=True)
    finally:
        server.close()
        _cleanup([sock_path, codex_pid_file, session_pid_file, busy_file, prompt_file])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
