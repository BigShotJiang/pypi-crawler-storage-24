#!/usr/bin/env python3
"""
check_deps.py — GluCINDa dependency sync checker.

Scans all Python source files across the four GluCINDa module repos,
extracts all third-party imports, and checks that every imported package
is declared in the packaging repo's pyproject.toml [project.dependencies].

Usage:
    python check_deps.py

Run from the packaging repo root. The four module repos must be cloned
as siblings in the same parent directory.

Exit codes:
    0 — all imports covered by declared dependencies
    1 — undeclared imports found
"""

import ast
import sys
import tomllib
from pathlib import Path


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PACKAGING_REPO = Path(__file__).parent
PARENT_DIR = PACKAGING_REPO.parent

MODULE_REPOS = {
    "generalparser": PARENT_DIR / "generalparser_internal",
    "gui": PARENT_DIR / "GluCINDa_GUI__internal",
    "data_field_adder": PARENT_DIR / "data_field_adder__internal",
    "cgm_extractor": PARENT_DIR / "cgm_extractor__internal",
}

# ---------------------------------------------------------------------------
# Python standard library module names (Python 3.11).
# Imports from these are ignored — they don't need to be declared as deps.
# ---------------------------------------------------------------------------

STDLIB_MODULES = {
    "abc", "aifc", "argparse", "array", "ast", "asynchat", "asyncio",
    "asyncore", "atexit", "audioop", "base64", "bdb", "binascii",
    "binhex", "bisect", "builtins", "bz2", "calendar", "cgi", "cgitb",
    "chunk", "cmath", "cmd", "code", "codecs", "codeop", "collections",
    "colorsys", "compileall", "concurrent", "configparser", "contextlib",
    "contextvars", "copy", "copyreg", "cProfile", "csv", "ctypes",
    "curses", "dataclasses", "datetime", "dbm", "decimal", "difflib",
    "dis", "doctest", "email", "encodings", "enum", "errno",
    "faulthandler", "fcntl", "filecmp", "fileinput", "fnmatch",
    "fractions", "ftplib", "functools", "gc", "getopt", "getpass",
    "gettext", "glob", "grp", "gzip", "hashlib", "heapq", "hmac",
    "html", "http", "idlelib", "imaplib", "imghdr", "imp",
    "importlib", "inspect", "io", "ipaddress", "itertools", "json",
    "keyword", "lib2to3", "linecache", "locale", "logging", "lzma",
    "mailbox", "mailcap", "marshal", "math", "mimetypes", "mmap",
    "modulefinder", "multiprocessing", "netrc", "nis", "nntplib",
    "numbers", "operator", "optparse", "os", "ossaudiodev", "pathlib",
    "pdb", "pickle", "pickletools", "pipes", "pkgutil", "platform",
    "plistlib", "poplib", "posix", "posixpath", "pprint", "profile",
    "pstats", "pty", "pwd", "py_compile", "pyclbr", "pydoc", "queue",
    "quopri", "random", "re", "readline", "reprlib", "resource",
    "rlcompleter", "runpy", "sched", "secrets", "select", "selectors",
    "shelve", "shlex", "shutil", "signal", "site", "smtpd", "smtplib",
    "sndhdr", "socket", "socketserver", "spwd", "sqlite3", "sre_compile",
    "sre_constants", "sre_parse", "ssl", "stat", "statistics", "string",
    "stringprep", "struct", "subprocess", "sunau", "symtable", "sys",
    "sysconfig", "syslog", "tabnanny", "tarfile", "telnetlib", "tempfile",
    "termios", "test", "textwrap", "threading", "time", "timeit",
    "tkinter", "token", "tokenize", "tomllib", "trace", "traceback",
    "tracemalloc", "tty", "turtle", "turtledemo", "types", "typing",
    "unicodedata", "unittest", "urllib", "uu", "uuid", "venv",
    "warnings", "wave", "weakref", "webbrowser", "wsgiref", "xdrlib",
    "xml", "xmlrpc", "zipapp", "zipfile", "zipimport", "zlib",
    "zoneinfo", "_thread", "__future__",
}

# ---------------------------------------------------------------------------
# Mapping from import name to PyPI package name where they differ.
# Add entries here if a new package's import name differs from its PyPI name.
# ---------------------------------------------------------------------------

IMPORT_TO_PACKAGE = {
    "cv2": "opencv-python",
    "PIL": "Pillow",
    "sklearn": "scikit-learn",
    "bs4": "beautifulsoup4",
    "yaml": "PyYAML",
    "dateutil": "python-dateutil",
    "et_xmlfile": "et_xmlfile",
    "PySide6": "PySide6",
    "pybtex": "pybtex",
    "pyarrow": "pyarrow",
    "xlrd": "xlrd",
    "chardet": "chardet",
    "tzdata": "tzdata",
}

# Internal GluCINDa module names — imports from these are not third-party.
# Seeded with known top-level package names; extended dynamically at runtime
# to include every .py file stem and sub-package found inside the repos.
INTERNAL_MODULES = {
    "glucinda",
    "generalparser",
    "data_field_adder",
    "cgm_extractor",
    "gui",
}


def collect_internal_names(repos: dict, skip_dirs: set) -> set:
    """
    Walk every repo and add all .py file stems and sub-package directory names
    to the internal-modules set so cross-script imports are not flagged.
    """
    names = set()
    for repo_path in repos.values():
        if not repo_path.exists():
            continue
        for py_file in repo_path.rglob("*.py"):
            if any(skip in py_file.parts for skip in skip_dirs):
                continue
            if not py_file.stem.startswith("__"):
                names.add(py_file.stem)
        for item in repo_path.rglob("*"):
            if item.is_dir() and (item / "__init__.py").exists():
                if not any(skip in item.parts for skip in skip_dirs):
                    names.add(item.name)
    return names

# Directories to skip when scanning repos.
SKIP_DIRS = {".venv", "venv", "env", "__pycache__", ".git", "dist", "build"}

# ---------------------------------------------------------------------------


def normalise(name: str) -> str:
    """Normalise package name per PEP 503."""
    return name.lower().replace("_", "-").replace(".", "-")


def parse_packaging_deps(toml_path: Path) -> dict[str, str]:
    """Parse [project.dependencies] from packaging pyproject.toml."""
    with open(toml_path, "rb") as f:
        data = tomllib.load(f)
    deps = data.get("project", {}).get("dependencies", [])
    result = {}
    for dep in deps:
        if "==" in dep:
            name, version = dep.split("==", 1)
            result[normalise(name.strip())] = version.strip()
        else:
            result[normalise(dep.strip())] = "unversioned"
    return result


def extract_imports(py_file: Path) -> set[str]:
    """Extract all top-level imported module names from a Python file."""
    try:
        tree = ast.parse(py_file.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        return set()

    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.level == 0:  # absolute imports only
                imports.add(node.module.split(".")[0])
    return imports


def resolve_package_name(import_name: str) -> str:
    """Map an import name to its PyPI package name."""
    return IMPORT_TO_PACKAGE.get(import_name, import_name)


def is_third_party(import_name: str) -> bool:
    """Return True if this import is not stdlib and not internal."""
    return (
        import_name not in STDLIB_MODULES
        and import_name not in INTERNAL_MODULES
        and not import_name.startswith("_")
    )


def scan_repo(repo_path: Path) -> dict[str, set[Path]]:
    """
    Scan all .py files in a repo, skipping venvs and caches.
    Returns {normalised_package_name: {set of files that import it}}.
    """
    findings: dict[str, set[Path]] = {}
    for py_file in sorted(repo_path.rglob("*.py")):
        if any(skip in py_file.parts for skip in SKIP_DIRS):
            continue
        for import_name in extract_imports(py_file):
            if is_third_party(import_name):
                pkg = normalise(resolve_package_name(import_name))
                findings.setdefault(pkg, set()).add(py_file)
    return findings


def main() -> int:
    print("GluCINDa dependency sync checker")
    print("=" * 60)

    packaging_toml = PACKAGING_REPO / "pyproject.toml"
    if not packaging_toml.exists():
        print(f"ERROR: packaging pyproject.toml not found at {packaging_toml}")
        return 1

    INTERNAL_MODULES.update(collect_internal_names(MODULE_REPOS, SKIP_DIRS))

    declared_deps = parse_packaging_deps(packaging_toml)
    print(f"Packaging toml: {len(declared_deps)} runtime dependencies declared.\n")

    all_third_party: dict[str, dict[str, set[Path]]] = {}
    discrepancies_found = False

    for module, repo_path in MODULE_REPOS.items():
        print(f"[{module}]")

        if not repo_path.exists():
            print(f"  WARNING: repo not found at {repo_path}")
            print(f"  Expected:  {repo_path}")
            print(f"  Skipping — clone the repo or update MODULE_REPOS.\n")
            continue

        findings = scan_repo(repo_path)
        all_third_party[module] = findings

        if not findings:
            print("  No third-party imports found.\n")
            continue

        undeclared = {
            pkg: files
            for pkg, files in findings.items()
            if pkg not in declared_deps
        }

        if undeclared:
            print(f"  UNDECLARED IMPORTS ({len(undeclared)} package(s)):")
            for pkg, files in sorted(undeclared.items()):
                print(f"    {pkg}")
                for f in sorted(files):
                    print(f"      ↳ {f.relative_to(repo_path)}")
            discrepancies_found = True
        else:
            print(f"  OK — {len(findings)} third-party package(s) imported, all declared.")
        print()

    # Packages declared in the packaging toml but not found in any import
    print("[packaging toml — unused declarations]")
    all_imported = {
        pkg
        for findings in all_third_party.values()
        for pkg in findings
    }
    unused = {
        pkg: ver for pkg, ver in declared_deps.items()
        if pkg not in all_imported
    }
    if unused:
        print("  Declared but not found in any scanned source file.")
        print("  May be transitive deps, optional features, or safe to remove:\n")
        for pkg, ver in sorted(unused.items()):
            print(f"  UNUSED: {pkg}=={ver}")
    else:
        print("  OK — all declared deps are imported in at least one module repo.")

    print("\n" + "=" * 60)
    if discrepancies_found:
        print("RESULT: Undeclared imports found.")
        print("        Add missing packages to the packaging pyproject.toml and NOTICE.")
        return 1
    else:
        print("RESULT: All third-party imports are declared.")
        return 0


if __name__ == "__main__":
    sys.exit(main())
