#!/usr/bin/env python3
"""
dev_setup.py — GluCINDa development environment setup.

Creates symlinks inside GluCINDa_GUI__internal/ so the other module repos
appear as importable packages when running the app from that directory:

    GluCINDa_GUI__internal/
        generalparser      -> ../generalparser_internal/
        data_field_adder   -> ../data_field_adder__internal/
        cgm_extractor      -> ../cgm_extractor__internal/

Usage:
    python dev_setup.py             # create symlinks
    python dev_setup.py --teardown  # remove symlinks

Run from the Untitled (packaging) repo root.
"""

import argparse
import sys
from pathlib import Path

PACKAGING_REPO = Path(__file__).parent
PARENT_DIR = PACKAGING_REPO.parent
GUI_REPO = PARENT_DIR / "GluCINDa_GUI__internal"

# name-inside-GUI-repo -> actual repo directory
LINKS = {
    "generalparser":    PARENT_DIR / "generalparser_internal",
    "data_field_adder": PARENT_DIR / "data_field_adder__internal",
    "cgm_extractor":    PARENT_DIR / "cgm_extractor__internal",
}


def setup() -> int:
    if not GUI_REPO.exists():
        print(f"ERROR: GUI repo not found at {GUI_REPO}")
        return 1

    ok = True
    for link_name, target in LINKS.items():
        link_path = GUI_REPO / link_name

        if not target.exists():
            print(f"  SKIP    {link_name}  (target not found: {target})")
            continue

        if link_path.is_symlink():
            if link_path.resolve() == target.resolve():
                print(f"  OK      {link_name}  (already linked)")
            else:
                print(f"  WARNING {link_name}  points elsewhere: {link_path.resolve()}")
            continue

        if link_path.exists():
            print(f"  ERROR   {link_name}  already exists as a real file/directory — remove it manually")
            ok = False
            continue

        # Use a relative target so the symlink works even if the whole
        # GluCINDa directory is moved.
        rel_target = Path("..") / target.name
        link_path.symlink_to(rel_target)
        print(f"  LINKED  {link_name}  -> {rel_target}")

    if ok:
        print("\nDone. Run the app from GluCINDa_GUI__internal/:")
        print(f"  cd {GUI_REPO}")
        print("  python glucinda.py")
    return 0 if ok else 1


def teardown() -> int:
    ok = True
    for link_name in LINKS:
        link_path = GUI_REPO / link_name

        if link_path.is_symlink():
            link_path.unlink()
            print(f"  REMOVED {link_name}")
        elif link_path.exists():
            print(f"  SKIP    {link_name}  (not a symlink — not touching it)")
            ok = False
        else:
            print(f"  SKIP    {link_name}  (not present)")

    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Set up or tear down dev symlinks inside GluCINDa_GUI__internal/."
    )
    parser.add_argument(
        "--teardown",
        action="store_true",
        help="Remove the symlinks instead of creating them.",
    )
    args = parser.parse_args()

    print("GluCINDa dev environment setup")
    print("=" * 60)

    if args.teardown:
        print("Removing symlinks ...\n")
        return teardown()
    else:
        print(f"Creating symlinks in {GUI_REPO.name}/\n")
        return setup()


if __name__ == "__main__":
    sys.exit(main())
