import GluCINDa_GUI.glucinda

if __name__ == "__main__":
    GluCINDa_GUI.glucinda.main()