#!/usr/bin/env python3
"""
add_headers.py — GluCINDa license header stamper.

Adds or replaces the EUPL-1.2 license header in every Python source file
across all four GluCINDa module repos. If a file already contains the
header, it is replaced with the current version.

Usage:
    python add_headers.py           # apply headers (dry run first recommended)
    python add_headers.py --dry-run # preview changes without writing

Run from the packaging repo root. The four module repos must be cloned
as siblings in the same parent directory.

Exit codes:
    0 — completed successfully
    1 — one or more files could not be processed
"""

import argparse
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PACKAGING_REPO = Path(__file__).parent
PARENT_DIR = PACKAGING_REPO.parent

MODULE_REPOS = {
    "generalparser": PARENT_DIR / "generalparser_internal",
    "gui": PARENT_DIR / "GluCINDa_GUI__internal",
    "data_field_adder": PARENT_DIR / "data_field_adder__internal",
    "cgm_extractor": PARENT_DIR / "cgm_extractor__internal",
}

SKIP_DIRS = {".venv", "venv", "env", "__pycache__", ".git", "dist", "build"}

# Marker used to detect an existing GluCINDa header so it can be replaced.
HEADER_MARKER = "This file is part of GluCINDa"

# ---------------------------------------------------------------------------
# License header — loaded from the Script_header file next to this script.
# Edit Script_header to change the header applied to all files.
# ---------------------------------------------------------------------------

_HEADER_FILE = PACKAGING_REPO / "Script_header"
if not _HEADER_FILE.exists():
    raise FileNotFoundError(f"Script_header not found at {_HEADER_FILE}")
HEADER = _HEADER_FILE.read_text(encoding="utf-8")

# ---------------------------------------------------------------------------


def strip_existing_header(lines: list[str]) -> list[str]:
    """
    Remove an existing GluCINDa header block from the top of a file.
    Handles optional shebang and encoding declarations before the header.
    Returns the remaining lines after the header.
    """
    i = 0
    # Preserve shebang on line 0 if present
    shebang = None
    if lines and lines[0].startswith("#!"):
        shebang = lines[0]
        i = 1

    # Skip encoding declaration (# -*- coding: ... -*-) if present
    if i < len(lines) and "coding" in lines[i] and lines[i].startswith("#"):
        i += 1

    # Skip blank lines before header
    while i < len(lines) and lines[i].strip() == "":
        i += 1

    # If the header marker is present, skip the entire comment block
    if i < len(lines) and HEADER_MARKER in lines[i]:
        while i < len(lines) and lines[i].startswith("#"):
            i += 1
        # Skip blank line(s) immediately after the header block
        while i < len(lines) and lines[i].strip() == "":
            i += 1

    remaining = lines[i:]
    if shebang:
        return [shebang, "\n"] + remaining
    return remaining


def apply_header(content: str) -> str:
    """Apply the license header to file content, replacing any existing one."""
    lines = content.splitlines(keepends=True)
    cleaned = strip_existing_header(lines)
    return HEADER + "\n" + "".join(cleaned)


def process_file(py_file: Path, dry_run: bool) -> str:
    """
    Process a single Python file.
    Returns a status string: 'added', 'replaced', 'skipped', or 'error'.
    """
    try:
        original = py_file.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        return f"error: {e}"

    already_has_header = HEADER_MARKER in original
    new_content = apply_header(original)

    if new_content == original:
        return "unchanged"

    if not dry_run:
        try:
            py_file.write_text(new_content, encoding="utf-8")
        except OSError as e:
            return f"error: {e}"

    return "replaced" if already_has_header else "added"


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Add or replace GluCINDa license headers in Python source files."
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview changes without writing any files.",
    )
    args = parser.parse_args()

    if args.dry_run:
        print("DRY RUN — no files will be modified.\n")

    print("GluCINDa license header stamper")
    print("=" * 60)

    counts = {"added": 0, "replaced": 0, "unchanged": 0, "error": 0, "skipped": 0}
    errors_found = False

    for module, repo_path in MODULE_REPOS.items():
        print(f"\n[{module}]")

        if not repo_path.exists():
            print(f"  WARNING: repo not found at {repo_path}")
            print(f"  Skipping — clone the repo or update MODULE_REPOS.")
            continue

        py_files = sorted(
            f for f in repo_path.rglob("*.py")
            if not any(skip in f.parts for skip in SKIP_DIRS)
        )

        if not py_files:
            print("  No Python files found.")
            continue

        for py_file in py_files:
            status = process_file(py_file, dry_run=args.dry_run)
            counts[status.split(":")[0]] += 1
            rel = py_file.relative_to(repo_path)

            if status == "unchanged":
                pass  # silent — no change needed
            elif status.startswith("error"):
                print(f"  ERROR   {rel} — {status}")
                errors_found = True
            elif args.dry_run:
                action = "would replace" if status == "replaced" else "would add"
                print(f"  {action:<14} {rel}")
            else:
                print(f"  {status:<14} {rel}")

        repo_added = sum(
            1 for f in py_files
            if process_file(f, dry_run=True) in ("added", "replaced")
        ) if args.dry_run else None

        total = len(py_files)
        print(f"  {total} file(s) scanned.")

    print("\n" + "=" * 60)
    print(f"Summary:")
    print(f"  Added:     {counts['added']}")
    print(f"  Replaced:  {counts['replaced']}")
    print(f"  Unchanged: {counts['unchanged']}")
    if counts['error']:
        print(f"  Errors:    {counts['error']}")

    if args.dry_run:
        print("\nRun without --dry-run to apply changes.")

    return 1 if errors_found else 0


if __name__ == "__main__":
    sys.exit(main())
