#!/usr/bin/env python3
"""
prune_deps.py — GluCINDa unused-dependency analyser.

Finds declared dependencies not imported anywhere in the source repos,
then checks via `pip show` whether each is a transitive dependency of
another installed package or genuinely unused.

Usage:
    python prune_deps.py             # report only (safe default)
    python prune_deps.py --apply     # remove SAFE deps from pyproject.toml

Run from the packaging repo root.

Categories reported:
    SAFE       — not required by any other installed package; safe to remove
    TRANSITIVE — pulled in by another installed package (listed)
    UNKNOWN    — package not found in the active Python environment
"""

import argparse
import ast
import re
import subprocess
import sys
import tomllib
from pathlib import Path


# ---------------------------------------------------------------------------
# Configuration  (mirrors check_deps.py)
# ---------------------------------------------------------------------------

PACKAGING_REPO = Path(__file__).parent
PARENT_DIR = PACKAGING_REPO.parent

MODULE_REPOS = {
    "generalparser": PARENT_DIR / "generalparser_internal",
    "gui": PARENT_DIR / "GluCINDa_GUI__internal",
    "data_field_adder": PARENT_DIR / "data_field_adder__internal",
    "cgm_extractor": PARENT_DIR / "cgm_extractor__internal",
}

SKIP_DIRS = {".venv", "venv", "env", "__pycache__", ".git", "dist", "build"}

STDLIB_MODULES = {
    "abc", "aifc", "argparse", "array", "ast", "asynchat", "asyncio",
    "asyncore", "atexit", "audioop", "base64", "bdb", "binascii",
    "binhex", "bisect", "builtins", "bz2", "calendar", "cgi", "cgitb",
    "chunk", "cmath", "cmd", "code", "codecs", "codeop", "collections",
    "colorsys", "compileall", "concurrent", "configparser", "contextlib",
    "contextvars", "copy", "copyreg", "cProfile", "csv", "ctypes",
    "curses", "dataclasses", "datetime", "dbm", "decimal", "difflib",
    "dis", "doctest", "email", "encodings", "enum", "errno",
    "faulthandler", "fcntl", "filecmp", "fileinput", "fnmatch",
    "fractions", "ftplib", "functools", "gc", "getopt", "getpass",
    "gettext", "glob", "grp", "gzip", "hashlib", "heapq", "hmac",
    "html", "http", "idlelib", "imaplib", "imghdr", "imp",
    "importlib", "inspect", "io", "ipaddress", "itertools", "json",
    "keyword", "lib2to3", "linecache", "locale", "logging", "lzma",
    "mailbox", "mailcap", "marshal", "math", "mimetypes", "mmap",
    "modulefinder", "multiprocessing", "netrc", "nis", "nntplib",
    "numbers", "operator", "optparse", "os", "ossaudiodev", "pathlib",
    "pdb", "pickle", "pickletools", "pipes", "pkgutil", "platform",
    "plistlib", "poplib", "posix", "posixpath", "pprint", "profile",
    "pstats", "pty", "pwd", "py_compile", "pyclbr", "pydoc", "queue",
    "quopri", "random", "re", "readline", "reprlib", "resource",
    "rlcompleter", "runpy", "sched", "secrets", "select", "selectors",
    "shelve", "shlex", "shutil", "signal", "site", "smtpd", "smtplib",
    "sndhdr", "socket", "socketserver", "spwd", "sqlite3", "sre_compile",
    "sre_constants", "sre_parse", "ssl", "stat", "statistics", "string",
    "stringprep", "struct", "subprocess", "sunau", "symtable", "sys",
    "sysconfig", "syslog", "tabnanny", "tarfile", "telnetlib", "tempfile",
    "termios", "test", "textwrap", "threading", "time", "timeit",
    "tkinter", "token", "tokenize", "tomllib", "trace", "traceback",
    "tracemalloc", "tty", "turtle", "turtledemo", "types", "typing",
    "unicodedata", "unittest", "urllib", "uu", "uuid", "venv",
    "warnings", "wave", "weakref", "webbrowser", "wsgiref", "xdrlib",
    "xml", "xmlrpc", "zipapp", "zipfile", "zipimport", "zlib",
    "zoneinfo", "_thread", "__future__",
}

IMPORT_TO_PACKAGE = {
    "cv2": "opencv-python",
    "PIL": "Pillow",
    "sklearn": "scikit-learn",
    "bs4": "beautifulsoup4",
    "yaml": "PyYAML",
    "dateutil": "python-dateutil",
    "et_xmlfile": "et_xmlfile",
    "PySide6": "PySide6",
    "pybtex": "pybtex",
    "pyarrow": "pyarrow",
    "xlrd": "xlrd",
    "chardet": "chardet",
    "tzdata": "tzdata",
}

INTERNAL_MODULES = {
    "glucinda",
    "generalparser",
    "data_field_adder",
    "cgm_extractor",
    "gui",
}

# ---------------------------------------------------------------------------


def normalise(name: str) -> str:
    return name.lower().replace("_", "-").replace(".", "-")


def dep_bare_name(dep_str: str) -> str:
    """Extract the bare package name from a dep string like 'numpy==1.2.3'."""
    return re.split(r"[=<>!~;\[]", dep_str.strip())[0].strip()


def collect_internal_names(repos: dict, skip_dirs: set) -> set:
    names = set()
    for repo_path in repos.values():
        if not repo_path.exists():
            continue
        for py_file in repo_path.rglob("*.py"):
            if any(skip in py_file.parts for skip in skip_dirs):
                continue
            if not py_file.stem.startswith("__"):
                names.add(py_file.stem)
        for item in repo_path.rglob("*"):
            if item.is_dir() and (item / "__init__.py").exists():
                if not any(skip in item.parts for skip in skip_dirs):
                    names.add(item.name)
    return names


def parse_declared_deps(toml_path: Path) -> dict[str, tuple[str, str]]:
    """
    Parse [project.dependencies] from pyproject.toml.
    Returns {normalised_name: (version, original_string)}.
    """
    with open(toml_path, "rb") as f:
        data = tomllib.load(f)
    result = {}
    for dep in data.get("project", {}).get("dependencies", []):
        bare = dep_bare_name(dep)
        version = dep[len(bare):].lstrip("=").strip() or "unversioned"
        result[normalise(bare)] = (version, dep)
    return result


def extract_imports(py_file: Path) -> set[str]:
    try:
        tree = ast.parse(py_file.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        return set()
    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.level == 0:
                imports.add(node.module.split(".")[0])
    return imports


def collect_all_imported_packages(repos: dict, internal: set, skip_dirs: set) -> set[str]:
    imported = set()
    for repo_path in repos.values():
        if not repo_path.exists():
            continue
        for py_file in sorted(repo_path.rglob("*.py")):
            if any(skip in py_file.parts for skip in skip_dirs):
                continue
            for imp in extract_imports(py_file):
                if imp not in STDLIB_MODULES and imp not in internal and not imp.startswith("_"):
                    pkg = normalise(IMPORT_TO_PACKAGE.get(imp, imp))
                    imported.add(pkg)
    return imported


def pip_required_by(pkg_name: str, own_project_name: str) -> list[str] | None:
    """
    Return the list of *other* packages that declare this package as a
    dependency, or None if the package is not installed.

    own_project_name is excluded from the list: every dep in pyproject.toml
    will show 'Required-by: GluCINDa' if the project itself is installed,
    which would falsely classify all unused deps as TRANSITIVE.
    """
    own_normalised = normalise(own_project_name)
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", pkg_name],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            return None
        for line in result.stdout.splitlines():
            if line.startswith("Required-by:"):
                val = line.split(":", 1)[1].strip()
                all_requirers = [x.strip() for x in val.split(",") if x.strip()] if val else []
                # Drop the project itself — it declared the dep, that's circular.
                return [r for r in all_requirers if normalise(r) != own_normalised]
    except Exception:
        return None
    return None


def remove_deps_from_toml(toml_path: Path, to_remove: set[str]) -> int:
    """
    Remove the given normalised package names from [project.dependencies]
    in pyproject.toml. Rewrites the dependencies block; other sections and
    comments outside that block are preserved.
    Returns the number of entries removed.
    """
    with open(toml_path, "rb") as f:
        data = tomllib.load(f)
    all_deps = data.get("project", {}).get("dependencies", [])
    new_deps = [
        d for d in all_deps
        if normalise(dep_bare_name(d)) not in to_remove
    ]
    removed = len(all_deps) - len(new_deps)
    if removed == 0:
        return 0

    # Rebuild the dependencies array string, matching the 2-space indent style.
    deps_block = "[\n" + "".join(f'  "{d}",\n' for d in new_deps) + "]"

    content = toml_path.read_text(encoding="utf-8")
    new_content = re.sub(
        r"(dependencies\s*=\s*)\[.*?\]",
        lambda m: m.group(1) + deps_block,
        content,
        flags=re.DOTALL,
    )
    toml_path.write_text(new_content, encoding="utf-8")
    return removed


# ---------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Analyse and optionally remove unused GluCINDa declared dependencies."
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Remove SAFE dependencies from pyproject.toml (those not required by anything).",
    )
    args = parser.parse_args()

    toml_path = PACKAGING_REPO / "pyproject.toml"
    if not toml_path.exists():
        print(f"ERROR: pyproject.toml not found at {toml_path}")
        return 1

    print("GluCINDa unused-dependency analyser")
    print("=" * 60)

    # Build the full internal-modules set.
    internal = set(INTERNAL_MODULES)
    internal.update(collect_internal_names(MODULE_REPOS, SKIP_DIRS))

    with open(toml_path, "rb") as _f:
        _meta = tomllib.load(_f)
    project_name = _meta.get("project", {}).get("name", "GluCINDa")

    declared = parse_declared_deps(toml_path)
    imported = collect_all_imported_packages(MODULE_REPOS, internal, SKIP_DIRS)

    unused = {pkg: info for pkg, info in declared.items() if pkg not in imported}

    if not unused:
        print("All declared dependencies are imported in at least one source file.")
        return 0

    print(f"\n{len(unused)} declared dep(s) not found in any source import:\n")

    safe: dict[str, tuple] = {}
    transitive: dict[str, tuple] = {}
    unknown: dict[str, tuple] = {}

    for pkg in sorted(unused):
        version, original = unused[pkg]
        bare_name = dep_bare_name(original)
        required_by = pip_required_by(bare_name, project_name)

        if required_by is None:
            unknown[pkg] = (version, original)
        elif required_by:
            transitive[pkg] = (version, original, required_by)
        else:
            safe[pkg] = (version, original)

    # --- SAFE ---
    if safe:
        print("SAFE to remove (not required by any other installed package):")
        for pkg, (version, original) in sorted(safe.items()):
            print(f"  {original}")
        print()

    # --- TRANSITIVE ---
    if transitive:
        print("TRANSITIVE (required by another installed package — keep or review):")
        for pkg, (version, original, required_by) in sorted(transitive.items()):
            print(f"  {original}")
            print(f"    Required-by: {', '.join(required_by)}")
        print()

    # --- UNKNOWN ---
    if unknown:
        print("UNKNOWN (not found in current environment — check manually):")
        for pkg, (version, original) in sorted(unknown.items()):
            print(f"  {original}")
        print()

    print("=" * 60)

    if args.apply:
        if not safe:
            print("Nothing to remove (no SAFE deps found).")
            return 0
        to_remove = set(safe.keys())
        count = remove_deps_from_toml(toml_path, to_remove)
        print(f"Removed {count} dep(s) from pyproject.toml:")
        for _, (_, original) in sorted(safe.items()):
            print(f"  - {original}")
        print("\nReview the file, then re-run check_deps.py to confirm.")
    else:
        if safe:
            print(f"\nRun with --apply to remove the {len(safe)} SAFE dep(s) from pyproject.toml.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
