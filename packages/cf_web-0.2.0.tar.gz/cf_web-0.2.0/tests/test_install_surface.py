from __future__ import annotations

import importlib
from importlib import metadata
from pathlib import Path
import subprocess
import sys

from fastapi.testclient import TestClient

import cf_web


def _script_path(name: str) -> Path:
    python_dir = Path(sys.executable).resolve().parent
    candidate_dirs = (
        python_dir,
        python_dir / "Scripts",
        python_dir.parent / "Scripts",
    )
    candidates = (
        f"{name}.exe",
        f"{name}.cmd",
        f"{name}-script.py",
        name,
    )
    for scripts_dir in candidate_dirs:
        for candidate in candidates:
            path = scripts_dir / candidate
            if path.is_file():
                return path
    raise FileNotFoundError(
        f"{name} console script not found near interpreter {Path(sys.executable).resolve()}"
    )


def test_distribution_metadata_matches_module_version() -> None:
    assert metadata.version("cf-web") == cf_web.__version__


def test_installed_console_script_help_surface() -> None:
    result = subprocess.run(
        [str(_script_path("cogniflow-web")), "--help"],
        check=False,
        capture_output=True,
        text=True,
    )

    combined_output = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined_output
    assert "Start the Cogniflow Web server." in combined_output


def test_create_app_health_and_static_surface(monkeypatch, tmp_path: Path) -> None:
    workspace_dir = tmp_path / "workspace"
    semantics_dir = workspace_dir / "semantics"
    monkeypatch.setenv("CF_WORKSPACE_DIR", str(workspace_dir))
    monkeypatch.setenv("CF_SEMANTICS_DIR", str(semantics_dir))
    monkeypatch.setenv("CF_WEB_RELOAD", "0")
    monkeypatch.setenv("CF_WEB_DEBUG", "0")

    import cf_web.config as config_module
    import cf_web.main as main_module

    config_module = importlib.reload(config_module)
    main_module = importlib.reload(main_module)

    client = TestClient(main_module.create_app())

    health_response = client.get("/api/health")
    assert health_response.status_code == 200
    assert health_response.json() == {"status": "ok"}

    root_response = client.get("/")
    assert root_response.status_code == 200
    assert "text/html" in root_response.headers.get("content-type", "")
    assert "<!doctype html>" in root_response.text.lower()
    assert "CogniFlow Web" in root_response.text
