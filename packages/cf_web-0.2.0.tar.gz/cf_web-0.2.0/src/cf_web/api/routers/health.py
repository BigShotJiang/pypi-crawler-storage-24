"""Health endpoints."""

from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def healthcheck() -> dict[str, str]:
    """Return liveness status for API health probing."""
    return {"status": "ok"}
