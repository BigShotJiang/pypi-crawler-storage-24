"""Resource manager endpoints."""

from __future__ import annotations

import base64
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from cf_web.services.resource_manager_service import (
    InvalidInputError,
    PipExecutionError,
    ProtectedPackageError,
    ResourceManagerService,
)

router = APIRouter()
service = ResourceManagerService()


class InstallSpecRequest(BaseModel):
    """Install request by package spec."""

    spec: str = Field(min_length=1)
    editable: bool = False
    preflight_only: bool = False


class UninstallRequest(BaseModel):
    """Uninstall request."""

    package_name: str = Field(min_length=1)


class InstallUploadRequest(BaseModel):
    """Install request from uploaded artifact content or local path."""

    filename: Optional[str] = None
    file_base64: Optional[str] = None
    local_path: Optional[str] = None
    editable: bool = False
    preflight_only: bool = False


@router.get("/packages")
async def list_discovered_packages() -> dict[str, list[dict[str, Any]]]:
    """List discoverable step packages from cogniflow.steps."""
    return {"packages": service.list_packages()}


@router.get("/runtime")
async def get_runtime_info() -> dict[str, Any]:
    """Return backend Python environment information."""
    return service.runtime_info()


@router.post("/install")
async def install_from_spec(payload: InstallSpecRequest) -> dict[str, Any]:
    """Install package from PyPI spec."""
    try:
        return service.install_from_spec(
            spec=payload.spec,
            editable=payload.editable,
            preflight_only=payload.preflight_only,
        )
    except InvalidInputError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ProtectedPackageError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except PipExecutionError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.post("/install-upload")
async def install_from_upload(payload: InstallUploadRequest) -> dict[str, Any]:
    """Install from uploaded wheel/sdist or local path."""
    content: Optional[bytes] = None
    if payload.file_base64:
        try:
            content = base64.b64decode(payload.file_base64.encode("ascii"))
        except Exception as exc:  # pylint: disable=broad-exception-caught
            raise HTTPException(status_code=422, detail="Invalid file_base64 payload.") from exc
    try:
        return service.install_from_upload(
            uploaded_name=payload.filename,
            uploaded_content=content,
            local_path=payload.local_path,
            editable=payload.editable,
            preflight_only=payload.preflight_only,
        )
    except InvalidInputError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ProtectedPackageError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except PipExecutionError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.post("/uninstall")
async def uninstall_package(payload: UninstallRequest) -> dict[str, Any]:
    """Uninstall package unless protected."""
    try:
        return service.uninstall(package_name=payload.package_name)
    except InvalidInputError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ProtectedPackageError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except PipExecutionError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
