"""Package template endpoints."""

from __future__ import annotations

import base64

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from cf_web.services.package_template_service import (
    PackageTemplateRequest,
    PackageTemplateService,
)

router = APIRouter()
service = PackageTemplateService()


@router.post("/template")
async def create_package_template(payload: PackageTemplateRequest) -> StreamingResponse:
    """Generate a package template archive and return as a download."""
    try:
        result = service.create_template(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    headers = {"Content-Disposition": f'attachment; filename="{result.filename}"'}
    return StreamingResponse(
        iter([result.content]),
        media_type="application/zip",
        headers=headers,
    )


@router.post("/template/build")
async def build_package_template(payload: PackageTemplateRequest) -> dict[str, object]:
    """Generate a package template and return zip payload plus validation report."""
    try:
        result = service.create_template(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return {
        "filename": result.filename,
        "zip_base64": base64.b64encode(result.content).decode("ascii"),
        "validation_report": result.validation_report,
        "generated_files": result.generated_files,
        "generated_at_utc": result.generated_at_utc,
    }
