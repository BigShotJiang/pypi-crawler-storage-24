"""Pipeline endpoints."""

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from cf_web.services.pipeline_service import PipelineService

router = APIRouter()
service = PipelineService()


class SavePipelineRequest(BaseModel):
    """Payload for saving a pipeline revision."""

    pipeline_id: str = Field(min_length=1)
    document: dict[str, Any]
    user: Optional[str] = None
    message: Optional[str] = None


class ValidatePipelineRequest(BaseModel):
    """Payload for validating a pipeline document."""

    document: dict[str, Any]


class ParsePipelineDocumentRequest(BaseModel):
    """Payload for parsing uploaded pipeline documents."""

    document_text: str = Field(min_length=1)


class SerializePipelineDocumentRequest(BaseModel):
    """Payload for serializing pipeline documents to N-Quads."""

    document: dict[str, Any]


@router.get("/")
async def list_pipelines() -> dict[str, list[dict[str, Any]]]:
    """List stored pipelines with current revision metadata."""
    return {"pipelines": service.list_pipelines()}


@router.get("/{pipeline_id}")
async def load_pipeline(pipeline_id: str, rev: Optional[int] = None) -> dict[str, object]:
    """Load a pipeline by id, optionally for a specific revision."""
    try:
        document = service.get_pipeline(pipeline_id, rev=rev)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {"pipeline_id": pipeline_id, "rev": rev, "document": document}


@router.post("/save")
async def save_pipeline(payload: SavePipelineRequest) -> dict[str, object]:
    """Commit a pipeline revision to the pipeline store."""
    try:
        result = service.save_pipeline(
            pipeline_id=payload.pipeline_id,
            document=payload.document,
            user=payload.user,
            message=payload.message,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return result


@router.post("/validate")
async def validate_pipeline(payload: ValidatePipelineRequest) -> dict[str, object]:
    """Validate a pipeline document and return diagnostics."""
    try:
        result = service.validate_pipeline(payload.document)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return result


@router.post("/parse")
async def parse_pipeline_document(payload: ParsePipelineDocumentRequest) -> dict[str, object]:
    """Parse an uploaded pipeline RDF document and return the canonical document form."""
    try:
        document = service.parse_pipeline_document(payload.document_text)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"document": document}


@router.post("/serialize")
async def serialize_pipeline_document(payload: SerializePipelineDocumentRequest) -> dict[str, str]:
    """Serialize a pipeline document to N-Quads for file export."""
    try:
        document_text = service.serialize_pipeline_document(payload.document)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"document_text": document_text}
