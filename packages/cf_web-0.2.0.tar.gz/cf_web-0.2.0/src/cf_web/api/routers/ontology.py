"""Ontology endpoints."""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException

from cf_web.services.pipeline_creator_service import PipelineCreatorService
from cf_web.services.ontology_explorer_service import OntologyExplorerService

router = APIRouter()
pipeline_creator_service = PipelineCreatorService()
ontology_explorer_service = OntologyExplorerService()


@router.get("/graph")
async def get_graph() -> dict[str, object]:
    """Return ontology explorer graph payload."""
    return {"document": ontology_explorer_service.get_graph()}


@router.get("/dataset")
async def get_dataset() -> dict[str, object]:
    """Return ontology dataset payload."""
    return {"document": ontology_explorer_service.get_dataset()}


@router.get("/steps")
async def list_steps() -> dict[str, object]:
    """List processing-step DTOs for pipeline creation."""
    return {"steps": pipeline_creator_service.get_steps()}


@router.get("/steps/{step_id}")
async def get_step(step_id: str) -> dict[str, object]:
    """Return one processing-step DTO by id or alias."""
    step = pipeline_creator_service.get_step(step_id)
    if not step:
        raise HTTPException(status_code=404, detail="Step not found")
    return {"step": step}


@router.get("/step-builder-options")
async def get_step_builder_options() -> dict[str, object]:
    """Return ontology-derived dropdown options for the package creator step builder."""
    return pipeline_creator_service.get_step_builder_options()


@router.get("/dashboard")
async def get_dashboard() -> dict[str, object]:
    """Return ontology dashboard graph data."""
    return {"graphs": ontology_explorer_service.get_dashboard_graphs()}


@router.get("/datatypes")
async def get_datatypes_graph() -> dict[str, object]:
    """Return the virtual datatypes graph payload."""
    return {"graph": ontology_explorer_service.get_datatypes_graph()}


@router.get("/node-quads")
async def get_node_quads(
    node_id: str,
    graph_id: Optional[str] = None,
    aliases: Optional[str] = None,
    limit: int = 200,
) -> dict[str, object]:
    """Return raw quads for one selected node id/alias."""
    alias_items = [item for item in (aliases or "").split(",") if item]
    return {
        "quads": ontology_explorer_service.get_node_quads(
            node_id=node_id,
            graph_id=graph_id,
            aliases=alias_items,
            limit=limit,
        )
    }


@router.get("/diagnostics")
async def get_diagnostics() -> dict[str, object]:
    """Return read-only diagnostics for ontology graph/quads quality checks."""
    return ontology_explorer_service.get_diagnostics_report()


@router.post("/diagnostics/run")
async def run_diagnostics() -> dict[str, object]:
    """Run comprehensive diagnostics across semantics DuckDB quad stores."""
    return ontology_explorer_service.run_comprehensive_diagnostics()
