"""Configuration for Cogniflow Web."""

from __future__ import annotations

import os
from pathlib import Path


class Settings:
    """Application settings."""

    debug: bool = False
    host: str = "127.0.0.1"
    port: int = 8000
    reload: bool = False

    workspace_dir: Path = Path.home() / ".cogniflow" / "workspace"
    semantics_dir: Path = workspace_dir / "semantics"

    def __init__(self) -> None:
        self.debug = os.getenv("CF_WEB_DEBUG", "0").lower() == "1"
        self.port = int(os.getenv("CF_WEB_PORT", str(self.port)))
        self.host = os.getenv("CF_WEB_HOST", self.host)
        self.reload = os.getenv("CF_WEB_RELOAD", "0").lower() == "1"

        self.workspace_dir = Path(
            os.getenv("CF_WORKSPACE_DIR", str(self.workspace_dir))
        ).expanduser()
        self.semantics_dir = Path(
            os.getenv("CF_SEMANTICS_DIR", str(self.semantics_dir))
        ).expanduser()

        self.workspace_dir.mkdir(parents=True, exist_ok=True)
        self.semantics_dir.mkdir(parents=True, exist_ok=True)


settings = Settings()
