"""FastAPI application factory."""

from __future__ import annotations

from contextlib import asynccontextmanager
import logging
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from cf_web import __version__
from cf_web.api.routers import health, ontology, packages, pipelines, resource_manager
from cf_web.config import settings

logger = logging.getLogger("cf_web")


@asynccontextmanager
async def lifespan(_: FastAPI):
    """Run startup and shutdown logging hooks for the FastAPI app lifecycle."""
    logger.info("Cogniflow Web starting up.")
    yield
    logger.info("Cogniflow Web shutting down.")


def create_app() -> FastAPI:
    """Create and configure FastAPI application."""
    app = FastAPI(
        title="Cogniflow Web",
        description="Web-based GUI for Cogniflow",
        version=__version__,
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:5173",
            "http://localhost:3000",
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(health.router, prefix="/api", tags=["health"])
    app.include_router(ontology.router, prefix="/api/ontology", tags=["ontology"])
    app.include_router(pipelines.router, prefix="/api/pipelines", tags=["pipelines"])
    app.include_router(packages.router, prefix="/api/packages", tags=["packages"])
    app.include_router(
        resource_manager.router,
        prefix="/api/resource-manager",
        tags=["resource-manager"],
    )

    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")
    else:

        @app.get("/")
        async def root() -> dict[str, str]:
            return {
                "status": "ok",
                "message": "Frontend build not found. Run the frontend dev server.",
            }

    return app


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "cf_web.main:create_app",
        host=settings.host,
        port=settings.port,
        reload=settings.reload,
        factory=True,
    )
