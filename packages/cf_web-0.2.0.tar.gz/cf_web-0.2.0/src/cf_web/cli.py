"""CLI entry point for cf_web."""

from __future__ import annotations

import argparse
import os
import signal
import threading
import time
import webbrowser
from urllib import request, error

import uvicorn

from cf_web.config import settings

try:
    from cf_cli.registry import register_command as _register_command
except ImportError:
    _register_command = None

def register_cli() -> None:
    """Register web commands into the unified `cf` CLI registry."""
    if _register_command is None:
        return

    def _cmd_web_start(args: argparse.Namespace) -> int:
        argv: list[str] = []
        if bool(getattr(args, "no_browser", False)):
            argv.append("--no-browser")
        return main(argv)

    def _add_web_start_parser(
        subparsers: argparse._SubParsersAction,
    ) -> argparse.ArgumentParser:
        parser = subparsers.add_parser("start", help="Start the Cogniflow Web app.")
        parser.add_argument(
            "--no-browser",
            action="store_true",
            help="Do not open the browser automatically.",
        )
        parser.set_defaults(_cf_handler=_cmd_web_start)
        return parser

    _register_command(
        "web",
        "start",
        _add_web_start_parser,
        group_help="Web app commands",
        command_help="Start Cogniflow Web",
    )


def main(argv: list[str] | None = None) -> int:
    """Start the web server and open browser."""
    start_ts = time.perf_counter()
    green = "\033[92m"
    reset = "\033[0m"
    info_prefix = f"{green}INFO{reset}:     "

    def _log_info(message: str) -> None:
        print(f"{info_prefix}{message}")

    def _log_ok(message: str, *, step_start: float | None = None, timed: bool = True) -> None:
        suffix = ""
        if timed and step_start is not None:
            step_elapsed = time.perf_counter() - step_start
            if step_elapsed >= 1.0:
                suffix = f" ({int(round(step_elapsed))}s)"
        print(f"{info_prefix}{message}{suffix} {green}OK{reset}")

    _log_ok("Starting Cogniflow Web app...")

    # Enable discovery/ingestion of installed step packages by default for web usage.
    os.environ.setdefault("CF_ENABLE_STEP_PACKAGES", "1")
    _log_ok("Environment prepared (CF_ENABLE_STEP_PACKAGES=1 by default).")

    parser = argparse.ArgumentParser(description="Start the Cogniflow Web server.")
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open the browser automatically.",
    )
    args = parser.parse_args(argv)
    _log_ok(f"CLI arguments parsed (no_browser={bool(args.no_browser)}).")

    url = f"http://{settings.host}:{settings.port}"
    _log_ok(f"Preparing server at {url}.")

    config = uvicorn.Config(
        "cf_web.main:create_app",
        host=settings.host,
        port=settings.port,
        reload=settings.reload,
        factory=True,
    )
    server = uvicorn.Server(config)
    stop_event = threading.Event()

    def _handle_shutdown(_signum: int, _frame) -> None:
        _log_info("Shutdown requested. Stopping cogniflow-web...")
        server.should_exit = True
        stop_event.set()

    signal.signal(signal.SIGINT, _handle_shutdown)
    signal.signal(signal.SIGTERM, _handle_shutdown)

    def _run_server() -> None:
        _log_info("Launching Uvicorn server thread...")
        server.run()

    thread = threading.Thread(target=_run_server, daemon=True)
    launch_start = time.perf_counter()
    thread.start()
    _log_ok("Uvicorn server thread launched.", step_start=launch_start)
    _log_info("Waiting for server health endpoint...")

    health_url = f"{url}/api/health"
    deadline = time.time() + 15
    health_wait_start = time.perf_counter()
    announced_ready = False
    while time.time() < deadline:
        try:
            with request.urlopen(health_url, timeout=1) as resp:
                if resp.status == 200:
                    _log_ok("Server is healthy.", step_start=health_wait_start)
                    if not args.no_browser:
                        browser_start = time.perf_counter()
                        _log_info("Opening browser...")
                        webbrowser.open(url)
                        _log_ok("Browser open requested.", step_start=browser_start)
                    else:
                        _log_ok("--no-browser set; skipping browser open.")
                    _log_ok("App startup complete.", step_start=start_ts)
                    announced_ready = True
                    break
        except (error.URLError, TimeoutError):
            time.sleep(0.3)

    if not announced_ready:
        _log_info("Health check timeout reached; server may still be starting.")

    while thread.is_alive():
        if stop_event.is_set():
            break
        time.sleep(0.2)
    thread.join(timeout=5)
    _log_ok("Cogniflow Web process stopped.", timed=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# Register cf_cli commands on module import (same pattern as cf_opcua_server).
register_cli()
