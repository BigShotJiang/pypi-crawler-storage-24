"""Resource manager service for step package discovery and pip operations."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple
import importlib
import importlib.metadata
from importlib import resources
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from urllib.parse import unquote, urlparse

from cf_ontology.package_discovery import discover_step_packages
from cf_ontology.rdf_document import load_rdf_document

from cf_web.services.manager_provider import (
    clear_ontology_manager_cache,
    get_ontology_manager,
)


class ResourceManagerError(RuntimeError):
    """Base resource manager error."""


class InvalidInputError(ResourceManagerError):
    """Input validation error."""


class ProtectedPackageError(ResourceManagerError):
    """Protected package operation conflict."""


class PipExecutionError(ResourceManagerError):
    """Pip operation failure."""


@dataclass(frozen=True)
class PipResult:
    """Structured pip command result."""

    command: List[str]
    returncode: int
    stdout: str
    stderr: str


class ResourceManagerService:
    """Discover, install, uninstall, and validate step packages."""

    _CF_BASE = "https://cogniflow.odea-project.org/cf#"

    _DEFAULT_PROTECTED: Tuple[str, ...] = (
        "cf-web",
        "cogniflow-web",
        "cf-ontology",
        "cogniflow-ontology",
    )
    _STEP_TYPES = {
        "cf:ProcessingStep",
        f"{_CF_BASE}ProcessingStep",
    }
    _PACKAGE_TYPES = {
        "cf:StepPackage",
        f"{_CF_BASE}StepPackage",
    }

    def runtime_info(self) -> Dict[str, Any]:
        """Return Python environment details used by cf_web backend."""
        python_executable = str(Path(sys.executable).resolve())
        in_venv = Path(sys.prefix).resolve() != Path(sys.base_prefix).resolve()
        env_path = os.environ.get("VIRTUAL_ENV")
        if env_path:
            env_root = str(Path(env_path).resolve())
        elif in_venv:
            env_root = str(Path(sys.prefix).resolve())
        else:
            env_root = str(Path(sys.base_prefix).resolve())
        return {
            "environment_name": Path(env_root).name,
            "environment_path": env_root,
            "python_executable": python_executable,
            "python_version": sys.version.split()[0],
            "in_virtual_environment": in_venv,
        }

    def list_packages(self) -> List[Dict[str, Any]]:
        """Return discovered step packages with metadata, steps, dependencies, and docs."""
        descriptors = discover_step_packages()
        packages: List[Dict[str, Any]] = []
        for descriptor in descriptors:
            entry_value = self._entry_point_value(descriptor)
            docs_payload = self._load_step_documents(descriptor)
            if not docs_payload:
                # Keep listing constrained to valid/discoverable step document providers.
                continue
            steps, doc_links_from_steps = self._extract_steps_and_docs(docs_payload)
            dist_meta = self._distribution_metadata(descriptor.package_name)
            links = self._merge_links(doc_links_from_steps, dist_meta["documentation_links"])
            packages.append(
                {
                    "distribution_name": descriptor.package_name,
                    "distribution_version": descriptor.package_version,
                    "entry_point_name": descriptor.entry_point,
                    "entry_point_value": entry_value,
                    "source_module": descriptor.source_module,
                    "detected_steps": steps,
                    "declared_dependencies": dist_meta["requires"],
                    "documentation_links": links,
                    "editable": dist_meta["editable"],
                    "editable_source_path": dist_meta["editable_source_path"],
                    "display_version": (
                        dist_meta["editable_source_path"]
                        if dist_meta["editable"] and dist_meta["editable_source_path"]
                        else descriptor.package_version
                    ),
                }
            )
        packages.sort(key=lambda item: str(item.get("distribution_name", "")).lower())
        return packages

    def install_from_spec(
        self,
        *,
        spec: str,
        editable: bool = False,
        preflight_only: bool = False,
    ) -> Dict[str, Any]:
        """Install from PyPI spec (non-editable) with preflight and postflight checks."""
        value = (spec or "").strip()
        if not value:
            raise InvalidInputError("Package spec is required.")
        if editable:
            raise InvalidInputError(
                "Editable install requires a local path and must use /install-upload."
            )
        preflight = self._run_preflight(args=[value])
        result: Dict[str, Any] = {
            "mode": "spec",
            "target": value,
            "preflight": preflight,
            "installed": False,
        }
        if preflight_only:
            return result

        pip_result = self._run_pip(["install", value])
        result["pip"] = self._pip_result_dict(pip_result)
        if pip_result.returncode != 0:
            raise PipExecutionError(self._pip_failure_message("install", value, pip_result))

        postflight = self._run_postflight_check()
        refresh = self._refresh_step_discovery()
        result["postflight"] = postflight
        result["refresh"] = refresh
        result["installed"] = True
        return result

    def install_from_upload(
        self,
        *,
        uploaded_name: Optional[str],
        uploaded_content: Optional[bytes],
        local_path: Optional[str],
        editable: bool = False,
        preflight_only: bool = False,
    ) -> Dict[str, Any]:
        """Install from uploaded wheel/sdist or local source path."""
        cleaned_local = (local_path or "").strip() or None
        if editable and not cleaned_local:
            raise InvalidInputError("Editable install requires a local path.")
        if uploaded_content and cleaned_local:
            raise InvalidInputError(
                "Provide either an upload file or a local path, not both."
            )
        if not uploaded_content and not cleaned_local:
            raise InvalidInputError("Upload file or local path is required.")

        temp_dir: Optional[str] = None
        pip_target: str
        target_kind: str
        try:
            if uploaded_content is not None:
                safe_name = (uploaded_name or "package").strip() or "package"
                temp_dir = tempfile.mkdtemp(prefix="cf_web_pkg_")
                temp_file = Path(temp_dir) / safe_name
                temp_file.write_bytes(uploaded_content)
                pip_target = str(temp_file)
                target_kind = "upload"
            else:
                assert cleaned_local is not None
                local = Path(cleaned_local).expanduser()
                if not local.exists():
                    raise InvalidInputError(f"Local path does not exist: {cleaned_local}")
                pip_target = str(local.resolve())
                target_kind = "local_path"

            install_args = ["install"]
            if editable:
                install_args.append("-e")
            install_args.append(pip_target)

            preflight = self._run_preflight(args=install_args[1:])
            result: Dict[str, Any] = {
                "mode": target_kind,
                "target": pip_target,
                "editable": bool(editable),
                "preflight": preflight,
                "installed": False,
            }
            if preflight_only:
                return result

            pip_result = self._run_pip(install_args)
            result["pip"] = self._pip_result_dict(pip_result)
            if pip_result.returncode != 0:
                raise PipExecutionError(
                    self._pip_failure_message("install", pip_target, pip_result)
                )

            postflight = self._run_postflight_check()
            refresh = self._refresh_step_discovery()
            result["postflight"] = postflight
            result["refresh"] = refresh
            result["installed"] = True
            return result
        finally:
            if temp_dir:
                shutil.rmtree(temp_dir, ignore_errors=True)

    def uninstall(self, *, package_name: str) -> Dict[str, Any]:
        """Uninstall an installed package unless protected."""
        target = (package_name or "").strip()
        if not target:
            raise InvalidInputError("Package name is required.")
        if self._is_protected(target):
            raise ProtectedPackageError(
                f"Package '{target}' is protected and cannot be uninstalled."
            )

        pip_result = self._run_pip(["uninstall", "-y", target])
        if pip_result.returncode != 0:
            raise PipExecutionError(self._pip_failure_message("uninstall", target, pip_result))
        postflight = self._run_postflight_check()
        refresh = self._refresh_step_discovery()
        return {
            "mode": "uninstall",
            "target": target,
            "pip": self._pip_result_dict(pip_result),
            "postflight": postflight,
            "refresh": refresh,
            "uninstalled": True,
        }

    def _refresh_step_discovery(self) -> Dict[str, Any]:
        clear_ontology_manager_cache()
        manager = get_ontology_manager()
        changed: List[str] = []
        error: Optional[str] = None
        try:
            if manager is not None:
                os.environ.setdefault("CF_ENABLE_STEP_PACKAGES", "1")
                changed = manager.refresh_installed_step_packages(force=True)
        except Exception as exc:  # pylint: disable=broad-exception-caught
            error = str(exc)
        finally:
            clear_ontology_manager_cache()
        payload: Dict[str, Any] = {"changed_graphs": changed}
        if error:
            payload["warning"] = error
        return payload

    def _run_preflight(self, *, args: Sequence[str]) -> Dict[str, Any]:
        preflight: Dict[str, Any] = {
            "supported": False,
            "warnings": [],
            "errors": [],
            "report": None,
        }
        with tempfile.TemporaryDirectory(prefix="cf_web_pip_report_") as temp_dir:
            report_path = Path(temp_dir) / "pip-report.json"
            cmd = ["install", "--dry-run", "--report", str(report_path), *args]
            pip_result = self._run_pip(cmd)
            preflight["raw"] = self._pip_result_dict(pip_result)

            if pip_result.returncode == 0:
                preflight["supported"] = True
                if report_path.exists():
                    try:
                        preflight["report"] = json.loads(report_path.read_text(encoding="utf-8"))
                    except Exception:  # pylint: disable=broad-exception-caught
                        preflight["warnings"].append("Preflight report generated but could not be parsed.")
                return preflight

            stderr = pip_result.stderr.lower()
            stdout = pip_result.stdout.lower()
            if "--dry-run" in stderr or "--dry-run" in stdout:
                preflight["warnings"].append(
                    "pip dry-run/report is unavailable in this environment; falling back to postflight pip check."
                )
                return preflight
            preflight["errors"].append(self._pip_failure_message("preflight", " ".join(args), pip_result))
            return preflight

    def _run_postflight_check(self) -> Dict[str, Any]:
        pip_check = self._run_pip(["check"])
        return {
            "ok": pip_check.returncode == 0,
            "result": self._pip_result_dict(pip_check),
        }

    def _run_pip(self, args: Sequence[str]) -> PipResult:
        cmd = [sys.executable, "-m", "pip", *args]
        completed = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=False,
        )
        return PipResult(
            command=cmd,
            returncode=int(completed.returncode),
            stdout=completed.stdout or "",
            stderr=completed.stderr or "",
        )

    @staticmethod
    def _pip_result_dict(result: PipResult) -> Dict[str, Any]:
        return {
            "command": result.command,
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }

    @staticmethod
    def _pip_failure_message(action: str, target: str, result: PipResult) -> str:
        error_text = (result.stderr or result.stdout or "").strip()
        if error_text:
            return f"pip {action} failed for '{target}': {error_text}"
        return f"pip {action} failed for '{target}' with exit code {result.returncode}."

    @staticmethod
    def _entry_point_value(descriptor: Any) -> str:
        document_paths = getattr(descriptor, "document_paths", None) or []
        if document_paths:
            return f"{descriptor.source_module}:{document_paths[0]}"
        loader = getattr(descriptor, "loader_callable", None)
        if callable(loader):
            module_name = getattr(loader, "__module__", descriptor.source_module)
            qualname = getattr(loader, "__name__", "loader")
            return f"{module_name}:{qualname}"
        return descriptor.source_module

    def _load_step_documents(self, descriptor: Any) -> List[Dict[str, Any]]:
        docs: List[Dict[str, Any]] = []
        document_paths = getattr(descriptor, "document_paths", None) or []
        if document_paths:
            for rel_path in document_paths:
                try:
                    files = resources.files(descriptor.source_module)
                except (ModuleNotFoundError, FileNotFoundError, ImportError):
                    package_root = (
                        descriptor.source_module.rsplit(".", 1)[0]
                        if "." in descriptor.source_module
                        else descriptor.source_module
                    )
                    try:
                        files = resources.files(package_root)
                    except Exception:  # pylint: disable=broad-exception-caught
                        continue
                except Exception:  # pylint: disable=broad-exception-caught
                    continue
                try:
                    candidate = files / rel_path
                    if not candidate.is_file():
                        continue
                    with resources.as_file(candidate) as local_file:
                        docs.append(load_rdf_document(Path(local_file), label="step document"))
                except Exception:  # pylint: disable=broad-exception-caught
                    continue
            return docs

        loader = getattr(descriptor, "loader_callable", None)
        if callable(loader):
            try:
                payload = loader()
                if isinstance(payload, dict):
                    docs.append(payload)
                elif isinstance(payload, str):
                    docs.append(json.loads(payload))
                elif isinstance(payload, Path):
                    docs.append(json.loads(payload.read_text(encoding="utf-8")))
            except Exception:  # pylint: disable=broad-exception-caught
                return []
        return docs

    def _extract_steps_and_docs(
        self, docs: Sequence[Dict[str, Any]]
    ) -> Tuple[List[Dict[str, Any]], List[str]]:
        steps: List[Dict[str, Any]] = []
        links: List[str] = []
        for doc in docs:
            nodes = doc.get("@graph")
            graph_nodes = nodes if isinstance(nodes, list) else [doc]
            for node in graph_nodes:
                if not isinstance(node, dict):
                    continue
                node_types = self._type_values(node.get("@type"))
                node_id = self._as_text(node.get("@id")) or ""
                if node_types.intersection(self._STEP_TYPES):
                    steps.append(
                        {
                            "id": node_id,
                            "label": self._as_text(node.get("rdfs:label")),
                            "description": self._as_text(node.get("cf:description")),
                        }
                    )
                if node_types.intersection(self._PACKAGE_TYPES):
                    links.extend(self._collect_links(node))
        # Deduplicate by id.
        dedup_steps: Dict[str, Dict[str, Any]] = {}
        for item in steps:
            key = str(item.get("id") or "").strip()
            if not key:
                continue
            dedup_steps.setdefault(key, item)
        return list(dedup_steps.values()), self._dedupe_links(links)

    def _distribution_metadata(self, package_name: str) -> Dict[str, Any]:
        requires: List[str] = []
        links: List[str] = []
        editable = False
        editable_source_path: Optional[str] = None
        try:
            dist = importlib.metadata.distribution(package_name)
        except importlib.metadata.PackageNotFoundError:
            return {
                "requires": requires,
                "documentation_links": links,
                "editable": editable,
                "editable_source_path": editable_source_path,
            }

        requires = list(dist.requires or [])
        metadata = dist.metadata
        home_page = metadata.get("Home-page")
        if isinstance(home_page, str) and home_page.strip():
            links.append(home_page.strip())
        project_urls = metadata.get_all("Project-URL") or []
        for project_url in project_urls:
            if not isinstance(project_url, str):
                continue
            if "," in project_url:
                _, value = project_url.split(",", 1)
                value = value.strip()
            else:
                value = project_url.strip()
            if value:
                links.append(value)

        direct_url = None
        try:
            raw = dist.read_text("direct_url.json")
            if raw:
                direct_url = json.loads(raw)
        except Exception:  # pylint: disable=broad-exception-caught
            direct_url = None
        if isinstance(direct_url, dict):
            dir_info = direct_url.get("dir_info")
            editable = isinstance(dir_info, dict) and bool(dir_info.get("editable"))
            if editable:
                raw_url = direct_url.get("url")
                if isinstance(raw_url, str) and raw_url.strip():
                    parsed = urlparse(raw_url)
                    if parsed.scheme == "file":
                        editable_source_path = unquote(parsed.path or "").lstrip("/")
                    else:
                        editable_source_path = raw_url

        return {
            "requires": requires,
            "documentation_links": self._dedupe_links(links),
            "editable": editable,
            "editable_source_path": editable_source_path,
        }

    def _is_protected(self, package_name: str) -> bool:
        protected = set(self._DEFAULT_PROTECTED)
        extra = os.environ.get("CF_WEB_PROTECTED_PACKAGES", "")
        for token in extra.split(","):
            cleaned = token.strip()
            if cleaned:
                protected.add(cleaned)
        normalized_target = self._normalize_name(package_name)
        return normalized_target in {self._normalize_name(item) for item in protected}

    @staticmethod
    def _normalize_name(value: str) -> str:
        return re.sub(r"[-_.]+", "-", (value or "").strip().lower())

    @staticmethod
    def _type_values(raw: Any) -> set[str]:
        if isinstance(raw, str):
            return {raw}
        if isinstance(raw, list):
            values = set()
            for item in raw:
                values.update(ResourceManagerService._type_values(item))
            return values
        if isinstance(raw, dict):
            value = raw.get("@id")
            if isinstance(value, str):
                return {value}
        return set()

    @staticmethod
    def _as_text(value: Any) -> Optional[str]:
        if isinstance(value, str):
            return value
        if isinstance(value, dict):
            v = value.get("@value")
            if isinstance(v, str):
                return v
            i = value.get("@id")
            if isinstance(i, str):
                return i
        return None

    def _collect_links(self, node: Dict[str, Any]) -> List[str]:
        keys = {
            "cf:documentation",
            "schema:url",
            "rdfs:seeAlso",
            "schema:documentation",
            "schema:sameAs",
            "cf:projectUrl",
            "cf:docsUrl",
        }
        links: List[str] = []
        for key, value in node.items():
            if key in keys or "doc" in key.lower() or "url" in key.lower():
                links.extend(self._extract_urls(value))
        return links

    def _extract_urls(self, value: Any) -> List[str]:
        if isinstance(value, str):
            text = value.strip()
            return [text] if text.startswith(("http://", "https://")) else []
        if isinstance(value, dict):
            urls: List[str] = []
            for nested in value.values():
                urls.extend(self._extract_urls(nested))
            return urls
        if isinstance(value, list):
            urls: List[str] = []
            for nested in value:
                urls.extend(self._extract_urls(nested))
            return urls
        return []

    @staticmethod
    def _dedupe_links(values: Sequence[str]) -> List[str]:
        seen: set[str] = set()
        result: List[str] = []
        for item in values:
            text = (item or "").strip()
            if not text:
                continue
            if text in seen:
                continue
            seen.add(text)
            result.append(text)
        return result

    def _merge_links(self, a: Sequence[str], b: Sequence[str]) -> List[str]:
        return self._dedupe_links([*a, *b])
