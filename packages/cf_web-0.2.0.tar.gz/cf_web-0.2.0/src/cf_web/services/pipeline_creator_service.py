"""Step/DTO service for the Pipeline Creator UI."""

from __future__ import annotations

from typing import Any, Dict, List, Optional
import os
import time

from rdflib import Namespace, RDF, URIRef

from cf_web.services.manager_provider import get_ontology_manager


CF_BASE = "https://cogniflow.odea-project.org/cf#"


class PipelineCreatorService:
    """Provides step-centric semantic DTOs consumed by the pipeline editor."""

    def __init__(self, manager: Optional[Any] = None) -> None:
        self._manager = manager if manager is not None else get_ontology_manager()
        self._steps_cache: List[Dict[str, Any]] | None = None
        self._steps_cache_ts: float = 0.0
        self._steps_cache_db_mtime: float | None = None
        self._steps_cache_ttl_s = float(
            os.environ.get("CF_WEB_STEPS_CACHE_TTL_SECONDS", "15")
        )

    def _steps_db_mtime(self) -> float | None:
        if not self._manager:
            return None
        try:
            path = getattr(self._manager, "steps_db_path", None)
            if path is None:
                return None
            return float(path.stat().st_mtime)
        except Exception:  # pylint: disable=broad-exception-caught
            return None

    def _is_steps_cache_valid(self) -> bool:
        if self._steps_cache is None:
            return False
        if self._steps_cache_ttl_s > 0:
            if (time.time() - self._steps_cache_ts) > self._steps_cache_ttl_s:
                return False
        return self._steps_db_mtime() == self._steps_cache_db_mtime

    def _build_steps(self) -> List[Dict[str, Any]]:
        if not self._manager:
            return []
        if getattr(self._manager, "quads_available", None) and self._manager.quads_available():
            return self._manager.get_processing_steps_info_quads_bulk()
        return self._manager.get_processing_steps()

    def get_steps(self) -> List[Dict[str, Any]]:
        """Return cached step DTOs, refreshing from ontology when cache is stale."""
        if self._is_steps_cache_valid():
            return list(self._steps_cache or [])
        steps = self._build_steps()
        self._steps_cache = list(steps)
        self._steps_cache_ts = time.time()
        self._steps_cache_db_mtime = self._steps_db_mtime()
        return steps

    def get_step(self, step_id: str) -> Dict[str, Any] | None:
        """Return a single step DTO resolved by id, canonical id, or alias."""
        steps = self.get_steps()
        for step in steps:
            sid = str(step.get("@id") or "")
            if sid == step_id:
                return step
            if str(step.get("canonical_id") or "") == step_id:
                return step
            aliases = step.get("aliases")
            if isinstance(aliases, list) and any(str(alias) == step_id for alias in aliases):
                return step
        return None

    def get_step_builder_options(self) -> Dict[str, List[str]]:
        """Return ontology-derived options for package creator step builder dropdowns."""
        if not self._manager:
            return {
                "category_options": [],
                "port_type_options": [],
                "parameter_type_options": [],
            }

        graph = self._manager.graph
        cf = Namespace(CF_BASE)
        skos = Namespace("http://www.w3.org/2004/02/skos/core#")

        def _qname(value: URIRef) -> str:
            try:
                return graph.namespace_manager.qname(value)
            except Exception:  # pylint: disable=broad-exception-caught
                return str(value)

        category_options: set[str] = set()
        for concept in graph.subjects(skos.inScheme, cf.step_category_scheme):
            if (concept, RDF.type, skos.Concept) in graph and isinstance(concept, URIRef):
                category_options.add(_qname(concept))

        parameter_type_options: set[str] = set()
        for concept in graph.subjects(skos.inScheme, cf.parameter_type_scheme):
            if (concept, RDF.type, skos.Concept) in graph and isinstance(concept, URIRef):
                parameter_type_options.add(_qname(concept))

        port_type_options: set[str] = set()
        for port_type in graph.objects(None, cf.portType):
            if isinstance(port_type, URIRef):
                port_type_options.add(_qname(port_type))

        return {
            "category_options": sorted(category_options),
            "port_type_options": sorted(port_type_options),
            "parameter_type_options": sorted(parameter_type_options),
        }
