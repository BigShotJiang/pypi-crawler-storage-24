"""Shared OntologyManager provider for cf_web services."""

from __future__ import annotations

from functools import lru_cache
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from cf_ontology.ontology_manager import OntologyManager

try:
    from cf_ontology.ontology_manager import OntologyManager as _OntologyManager
except Exception:  # pylint: disable=broad-exception-caught
    _OntologyManager = None  # type: ignore[assignment]


@lru_cache(maxsize=1)
def get_ontology_manager() -> Optional["OntologyManager"]:
    """
    Return a single OntologyManager instance for the current process.

    Services in cf_web should depend on this provider so semantics state and caches
    are shared across ontology explorer, pipeline creator, and pipeline persistence.
    """
    if _OntologyManager is None:
        return None
    return _OntologyManager()


def clear_ontology_manager_cache() -> None:
    """Clear the cached OntologyManager singleton."""
    get_ontology_manager.cache_clear()
