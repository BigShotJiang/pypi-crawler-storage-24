"""Graph/dashboard service for the Ontology Explorer UI."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
import json
import duckdb

from rdflib import BNode, Dataset, Graph, Literal, Namespace, RDF, RDFS, URIRef

from cf_ontology.semantics_paths import resolve_semantics_db_paths, resolve_semantics_dir
from cf_web.services.manager_provider import get_ontology_manager


_RDF_AUTHORING_FORMAT = "json" + "-ld"


class OntologyExplorerService:
    """Provides graph-shaped payloads for ontology exploration/visualization."""

    _RDF_FIRST = "http://www.w3.org/1999/02/22-rdf-syntax-ns#first"
    _RDF_REST = "http://www.w3.org/1999/02/22-rdf-syntax-ns#rest"
    _RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
    _RDFS_LABEL = "http://www.w3.org/2000/01/rdf-schema#label"
    _RDFS_COMMENT = "http://www.w3.org/2000/01/rdf-schema#comment"
    _RDFS_RANGE = "http://www.w3.org/2000/01/rdf-schema#range"
    _CF_BASE = "https://cogniflow.odea-project.org/cf#"
    _CF_DESCRIPTION = f"{_CF_BASE}description"
    _CF_PORT_TYPE = f"{_CF_BASE}portType"
    _CF_PARAMETER_TYPE = f"{_CF_BASE}parameterType"

    def __init__(self, manager: Optional[Any] = None) -> None:
        """Create explorer service with an injected or shared ontology manager."""
        self._manager = manager if manager is not None else get_ontology_manager()

    def get_graph(self) -> dict[str, Any]:
        """Return merged ontology graph document for explorer rendering."""
        if not self._manager:
            return {}
        return self._manager.get_graph_document()

    def get_dataset(self) -> dict[str, Any]:
        """Return dataset document with named graphs when available."""
        if not self._manager:
            return {}
        return self._manager.get_graph_dataset_document()

    def get_dashboard_graphs(self) -> list[dict[str, Any]]:
        """Return precomputed node/link payloads grouped by named graph id."""
        if not self._manager:
            return []
        doc = self._manager.get_graph_dataset_document()
        if not doc:
            doc = self._manager.get_graph_document()
            graph_data = self._build_graph_data_from_document(doc)
            graph_data["graph_id"] = "combined"
            graph_data["display_name"] = "Combined Ontology"
            graph_data["category"] = "other"
            graph_data["card_color"] = self._card_color("other")
            return [graph_data]

        catalog_by_graph_id = self._get_graph_catalog_map()
        dataset = Dataset()
        dataset.parse(data=json.dumps(doc, ensure_ascii=True), format=_RDF_AUTHORING_FORMAT)
        graphs: list[dict[str, Any]] = []
        for graph in dataset.contexts():
            graph_id = str(graph.identifier) if graph.identifier else "default"
            graph_data = self._build_graph_data_from_graph(graph)
            if not graph_data.get("nodes") and not graph_data.get("links"):
                continue
            graph_data["graph_id"] = graph_id
            catalog = catalog_by_graph_id.get(graph_id)
            graph_kind = str(catalog.get("graph_kind") or "") if catalog else ""
            graph_type = str(catalog.get("graph_type") or "") if catalog else ""
            category = self._graph_category(
                graph_id=graph_id,
                graph_type=graph_type,
                graph_kind=graph_kind,
            )
            graph_data["graph_type"] = graph_type
            graph_data["graph_kind"] = graph_kind
            graph_data["package"] = str(catalog.get("package") or "") if catalog else ""
            graph_data["package_name"] = str(catalog.get("package_name") or "") if catalog else ""
            graph_data["package_version"] = (
                str(catalog.get("package_version") or "") if catalog else ""
            )
            graph_data["canonical_id"] = str(catalog.get("canonical_id") or "") if catalog else ""
            graph_data["compact_id"] = str(catalog.get("compact_id") or "") if catalog else ""
            graph_data["local_id"] = str(catalog.get("local_id") or "") if catalog else ""
            graph_data["aliases"] = list(catalog.get("aliases") or []) if catalog else []
            graph_data["display_name"] = self._graph_display_name(graph_id, category, catalog)
            graph_data["category"] = category
            graph_data["card_color"] = self._card_color(category)
            graphs.append(graph_data)
        if not graphs:
            graph_data = self._build_graph_data_from_document(doc)
            graph_data["graph_id"] = "combined"
            graph_data["display_name"] = "Combined Ontology"
            graph_data["category"] = "other"
            graph_data["card_color"] = self._card_color("other")
            graphs.append(graph_data)
        return graphs

    def get_datatypes_graph(self) -> dict[str, Any]:
        """Build a virtual graph that highlights datatype definitions and usage."""
        usage_rows = self._datatype_usage_rows()
        datatype_ids = sorted({str(row["object"]) for row in usage_rows})
        subject_ids = sorted({str(row["subject"]) for row in usage_rows})

        ctx = (
            self._manager.get_quads_context()
            if self._manager and self._manager.quads_available()
            else {}
        )
        labels = self._subject_labels(subject_ids)
        datatype_labels = self._subject_labels(datatype_ids)
        datatype_comments = self._subject_values(
            datatype_ids,
            [self._RDFS_COMMENT, self._CF_DESCRIPTION],
        )

        nodes: Dict[str, Dict[str, Any]] = {}
        links: List[Dict[str, str]] = []
        usage_map: Dict[str, List[str]] = {}
        for row in usage_rows:
            dtype = str(row["object"])
            usage_map.setdefault(dtype, []).append(str(row["subject"]))

            subject_id = str(row["subject"])
            if subject_id not in nodes:
                label = labels.get(subject_id) or self._compact_iri(subject_id, ctx)
                nodes[subject_id] = {
                    "id": subject_id,
                    "label": label,
                    "uri": subject_id,
                    "types": ["cf:DatatypeUsage"],
                    "meta": {
                        "label": label,
                        "description": (
                            f"Uses datatype via "
                            f"{self._compact_iri(str(row['predicate']), ctx)}"
                        ),
                    },
                }

            if dtype not in nodes:
                dtype_label = datatype_labels.get(dtype) or self._compact_iri(dtype, ctx)
                dtype_comment = datatype_comments.get(dtype)
                nodes[dtype] = {
                    "id": dtype,
                    "label": dtype_label,
                    "uri": dtype,
                    "types": ["rdfs:Datatype"],
                    "meta": {
                        "label": dtype_label,
                        "comment": dtype_comment,
                        "description": dtype_comment,
                        "usedBy": [],
                        "usageCount": 0,
                    },
                }

            links.append(
                {
                    "source": subject_id,
                    "target": dtype,
                    "predicate": self._compact_iri(str(row["predicate"]), ctx),
                    "kind": "datatype_usage",
                }
            )

        for dtype, used_by in usage_map.items():
            node = nodes.get(dtype)
            if not node:
                continue
            used_labels = [labels.get(subject, subject) for subject in sorted(set(used_by))]
            node_meta = node.get("meta") or {}
            node_meta["usedBy"] = used_labels[:25]
            node_meta["usageCount"] = len(set(used_by))
            node["meta"] = node_meta

        return {
            "graph_id": "datatypes",
            "graph_type": "virtual",
            "graph_kind": "virtual",
            "package": "ontology",
            "display_name": "Datatypes",
            "category": "datatypes",
            "card_color": self._card_color("datatypes"),
            "nodes": list(nodes.values()),
            "links": links,
        }

    def get_node_quads(
        self,
        node_id: str,
        *,
        graph_id: Optional[str] = None,
        aliases: Optional[List[str]] = None,
        limit: int = 200,
    ) -> List[Dict[str, Any]]:
        """Return raw quads for a selected node id/alias from DuckDB-backed stores."""
        if not self._manager or not getattr(self._manager, "query_quads", None):
            return []

        candidates: List[str] = []
        for value in [node_id, *(aliases or [])]:
            text = str(value or "").strip()
            if text and text not in candidates:
                candidates.append(text)
        if not candidates:
            return []

        rows: List[Dict[str, Any]] = []
        seen: set[tuple[str, str, str, str, str]] = set()
        per_call_limit = max(1, min(500, int(limit)))
        for candidate in candidates:
            subject_rows = self._manager.query_quads(
                subject=candidate,
                graph_id=graph_id,
                limit=per_call_limit,
            )
            object_rows = self._manager.query_quads(
                obj=candidate,
                graph_id=graph_id,
                limit=per_call_limit,
            )
            for row in [*subject_rows, *object_rows]:
                key = (
                    str(row.get("graph_id") or ""),
                    str(row.get("subject") or ""),
                    str(row.get("predicate") or ""),
                    str(row.get("object") or ""),
                    str(row.get("object_kind") or ""),
                )
                if key in seen:
                    continue
                seen.add(key)
                direction = "subject" if str(row.get("subject")) == candidate else "object"
                payload = dict(row)
                payload["match"] = candidate
                payload["direction"] = direction
                rows.append(payload)
                if len(rows) >= per_call_limit:
                    return rows
        return rows

    def get_diagnostics_report(self) -> Dict[str, Any]:
        """Compute a read-only diagnostics report over graph metadata and quads."""
        catalog_entries = self._manager.list_active_graph_catalog() if self._manager else []
        file_graphs = []
        for entry in catalog_entries:
            graph_id = str(entry.get("graph_id") or "")
            path = str(entry.get("path") or "")
            if graph_id.startswith("file://") or path.startswith("file://"):
                file_graphs.append(graph_id or path)

        quads = (
            self._manager.query_quads(limit=100000)
            if self._manager and getattr(self._manager, "query_quads", None)
            else []
        )
        typed_subjects: set[tuple[str, str]] = set()
        all_subjects: set[tuple[str, str]] = set()
        list_structures: List[str] = []
        suspicious_blank_nodes: List[str] = []
        for row in quads:
            gid = str(row.get("graph_id") or "")
            subject = str(row.get("subject") or "")
            predicate = str(row.get("predicate") or "")
            subject_kind = str(row.get("subject_kind") or "")
            if subject and subject_kind in {"iri", "bnode"}:
                all_subjects.add((gid, subject))
            if predicate == self._RDF_TYPE and subject:
                typed_subjects.add((gid, subject))
            if predicate in {self._RDF_FIRST, self._RDF_REST}:
                list_structures.append(f"{gid}: {subject} {predicate}")
            if subject_kind == "bnode" and subject.startswith("N"):
                suspicious_blank_nodes.append(f"{gid}: {subject}")
        without_type = sorted(f"{gid}: {subj}" for gid, subj in (all_subjects - typed_subjects))

        datatype_rows = self._datatype_usage_rows()
        datatype_ids = sorted({str(row["object"]) for row in datatype_rows})
        datatype_labels = self._subject_labels(datatype_ids)
        datatype_desc = self._subject_values(
            datatype_ids,
            [self._RDFS_COMMENT, self._CF_DESCRIPTION_HTTPS, self._CF_DESCRIPTION_HTTP],
        )
        datatypes_missing_docs = [
            dtype
            for dtype in datatype_ids
            if not datatype_labels.get(dtype) and not datatype_desc.get(dtype)
        ]

        concerns = [
            {
                "id": "file_graph_ids",
                "title": "file:// graph ids or source paths",
                "count": len(file_graphs),
                "samples": file_graphs[:25],
            },
            {
                "id": "nodes_without_type",
                "title": "Nodes without rdf:type",
                "count": len(without_type),
                "samples": without_type[:25],
            },
            {
                "id": "rdf_collections",
                "title": "RDF collection/list structures",
                "count": len(list_structures),
                "samples": list_structures[:25],
            },
            {
                "id": "datatypes_missing_docs",
                "title": "Referenced datatypes missing label/description",
                "count": len(datatypes_missing_docs),
                "samples": datatypes_missing_docs[:25],
            },
            {
                "id": "suspicious_blank_nodes",
                "title": "Suspicious blank-node ids",
                "count": len(suspicious_blank_nodes),
                "samples": suspicious_blank_nodes[:25],
            },
        ]
        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "summary": {
                "concern_count": sum(item["count"] for item in concerns),
                "graph_count": len(catalog_entries),
            },
            "concerns": concerns,
        }

    def run_comprehensive_diagnostics(self) -> Dict[str, Any]:
        """Run a comprehensive diagnostics pass over semantics DuckDB quad stores."""
        semantics_dir = resolve_semantics_dir()
        db_paths = resolve_semantics_db_paths(semantics_dir)
        db_candidates = [
            ("ontology", db_paths.ontology),
            ("steps", db_paths.steps),
            ("pipelines", db_paths.pipelines),
            ("pipeline_states", db_paths.pipeline_states),
        ]

        db_stats: List[Dict[str, Any]] = []
        total_quads = 0
        graph_ids_with_quads: set[str] = set()

        for db_kind, db_path in db_candidates:
            exists = db_path.exists()
            has_quads = False
            quad_count = 0
            distinct_graph_count = 0
            errors: List[str] = []
            graph_ids: set[str] = set()

            if exists:
                try:
                    has_quads = self._duckdb_has_table(db_path, "rdf_quads")
                    if has_quads:
                        quad_count = self._duckdb_scalar_int(
                            db_path, "SELECT COUNT(*) FROM rdf_quads"
                        )
                        distinct_graph_count = self._duckdb_scalar_int(
                            db_path,
                            "SELECT COUNT(DISTINCT g) FROM rdf_quads",
                        )
                        graph_ids = self._duckdb_fetch_graph_ids(db_path)
                except Exception as exc:  # pylint: disable=broad-exception-caught
                    errors.append(str(exc))

            total_quads += int(quad_count)
            graph_ids_with_quads.update(graph_ids)
            db_stats.append(
                {
                    "db_kind": db_kind,
                    "path": str(db_path),
                    "exists": exists,
                    "has_quads_table": has_quads,
                    "quad_count": int(quad_count),
                    "distinct_graph_count": int(distinct_graph_count),
                    "graph_ids": sorted(graph_ids),
                    "errors": errors,
                }
            )

        catalog_entries = self._manager.list_active_graph_catalog() if self._manager else []
        catalog_graph_ids = {
            str(entry.get("graph_id") or "").strip()
            for entry in catalog_entries
            if str(entry.get("graph_id") or "").strip()
        }

        issues = self._run_quad_quality_checks(db_stats=db_stats)
        uncataloged_graphs = sorted(graph_ids_with_quads - catalog_graph_ids)
        catalog_without_quads = sorted(catalog_graph_ids - graph_ids_with_quads)
        if uncataloged_graphs:
            issues.append(
                {
                    "id": "graphs_without_catalog_entry",
                    "title": "Graph ids present in quads but missing in active graph catalog",
                    "count": len(uncataloged_graphs),
                    "samples": uncataloged_graphs[:25],
                }
            )
        if catalog_without_quads:
            issues.append(
                {
                    "id": "catalog_entries_without_quads",
                    "title": "Active graph catalog entries with no quads",
                    "count": len(catalog_without_quads),
                    "samples": catalog_without_quads[:25],
                }
            )

        concern_count = sum(int(item.get("count") or 0) for item in issues)
        report_text = self._render_diagnostics_text_report(
            semantics_dir=semantics_dir,
            db_stats=db_stats,
            issues=issues,
            total_quads=total_quads,
            catalog_graph_count=len(catalog_graph_ids),
        )
        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "semantics_dir": str(semantics_dir),
            "summary": {
                "database_count": len(db_stats),
                "databases_with_quads": sum(1 for row in db_stats if row.get("has_quads_table")),
                "catalog_graph_count": len(catalog_graph_ids),
                "total_quads": int(total_quads),
                "concern_count": int(concern_count),
            },
            "databases": db_stats,
            "concerns": issues,
            "report_text": report_text,
        }

    def _run_quad_quality_checks(self, *, db_stats: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        checks = [
            {
                "id": "rows_missing_subject_or_predicate_or_object",
                "title": "Rows with missing subject/predicate/object",
                "sql": """
                    SELECT COUNT(*) FROM rdf_quads
                    WHERE COALESCE(TRIM(s), '') = ''
                       OR COALESCE(TRIM(p), '') = ''
                       OR (
                         COALESCE(TRIM(o), '') = ''
                         AND COALESCE(TRIM(o_kind), '') <> 'literal'
                       )
                """,
                "findings_sql": """
                    SELECT g, s, p, o, o_kind
                    FROM rdf_quads
                    WHERE COALESCE(TRIM(s), '') = ''
                       OR COALESCE(TRIM(p), '') = ''
                       OR (
                         COALESCE(TRIM(o), '') = ''
                         AND COALESCE(TRIM(o_kind), '') <> 'literal'
                       )
                """,
                "likely_causes": [
                    "Partial/invalid RDF ingest from malformed source docs",
                    "Bad normalization or mapping logic before quad persistence",
                ],
                "correction_steps": [
                    "Re-validate source RDF documents for the affected graph ids",
                    "Backfill/fix malformed rows, then re-ingest affected packages/pipelines",
                ],
            },
            {
                "id": "rows_missing_object_kind",
                "title": "Rows with missing object_kind",
                "sql": "SELECT COUNT(*) FROM rdf_quads WHERE COALESCE(TRIM(o_kind), '') = ''",
                "findings_sql": """
                    SELECT g, s, p, o, o_kind
                    FROM rdf_quads
                    WHERE COALESCE(TRIM(o_kind), '') = ''
                """,
                "likely_causes": [
                    "Legacy rows inserted before object-kind typing was enforced",
                    "Bug in object kind classifier during ingest",
                ],
                "correction_steps": [
                    "Infer o_kind from object lexical form and predicate context",
                    "Patch ingest path to always persist o_kind",
                ],
            },
            {
                "id": "literal_missing_lang_and_datatype",
                "title": "Typed-value literals missing both datatype and language",
                "sql": """
                    SELECT COUNT(*) FROM rdf_quads
                    WHERE o_kind = 'literal'
                      AND p IN (
                                                'https://cogniflow.odea-project.org/cf#defaultValue',
                                                'https://cogniflow.odea-project.org/cf#value',
                                                'https://cogniflow.odea-project.org/cf#minValue',
                                                'https://cogniflow.odea-project.org/cf#maxValue'
                      )
                      AND COALESCE(TRIM(o_datatype), '') = ''
                      AND COALESCE(TRIM(o_lang), '') = ''
                """,
                "findings_sql": """
                    SELECT g, s, p, o, o_kind, o_datatype, o_lang
                    FROM rdf_quads
                    WHERE o_kind = 'literal'
                      AND p IN (
                                                'https://cogniflow.odea-project.org/cf#defaultValue',
                                                'https://cogniflow.odea-project.org/cf#value',
                                                'https://cogniflow.odea-project.org/cf#minValue',
                                                'https://cogniflow.odea-project.org/cf#maxValue'
                      )
                      AND COALESCE(TRIM(o_datatype), '') = ''
                      AND COALESCE(TRIM(o_lang), '') = ''
                """,
                "likely_causes": [
                    "Typed runtime values ingested as plain literals",
                    "Datatype/lang dropped for default/bound/min/max values",
                ],
                "correction_steps": [
                    "Ensure cf:defaultValue/cf:value/cf:minValue/cf:maxValue persist with explicit datatype",
                    "Rebuild affected graphs after fixing datatype propagation",
                ],
            },
            {
                "id": "iri_or_bnode_with_literal_annotations",
                "title": "IRI/BNode rows that still carry datatype/lang annotations",
                "sql": """
                    SELECT COUNT(*) FROM rdf_quads
                    WHERE o_kind IN ('iri', 'bnode')
                      AND (
                        COALESCE(TRIM(o_datatype), '') <> ''
                        OR COALESCE(TRIM(o_lang), '') <> ''
                      )
                """,
                "findings_sql": """
                    SELECT g, s, p, o, o_kind, o_datatype, o_lang
                    FROM rdf_quads
                    WHERE o_kind IN ('iri', 'bnode')
                      AND (
                        COALESCE(TRIM(o_datatype), '') <> ''
                        OR COALESCE(TRIM(o_lang), '') <> ''
                      )
                """,
                "likely_causes": [
                    "Mixed object metadata from prior literal state",
                    "Incomplete cleanup when object_kind is reclassified",
                ],
                "correction_steps": [
                    "Clear datatype/lang columns for iri/bnode objects",
                    "Add integrity guard in ingest/update path",
                ],
            },
            {
                "id": "duplicate_quad_rows",
                "title": "Duplicate quad rows",
                "sql": """
                    SELECT COALESCE(SUM(cnt) - COUNT(*), 0)
                    FROM (
                      SELECT COUNT(*) AS cnt
                      FROM rdf_quads
                      GROUP BY g, s, p, o, o_kind, COALESCE(o_datatype, ''), COALESCE(o_lang, '')
                      HAVING COUNT(*) > 1
                    ) t
                """,
                "findings_sql": """
                    SELECT g, s, p, o, o_kind, COUNT(*) AS dup_count
                    FROM rdf_quads
                    GROUP BY g, s, p, o, o_kind, COALESCE(o_datatype, ''), COALESCE(o_lang, '')
                    HAVING COUNT(*) > 1
                    ORDER BY dup_count DESC
                """,
                "likely_causes": [
                    "Non-idempotent re-ingest behavior",
                    "Missing unique dedupe logic during upsert",
                ],
                "correction_steps": [
                    "Deduplicate affected rows in place",
                    "Enforce idempotent ingest semantics for identical quads",
                ],
            },
            {
                "id": "subjects_without_rdf_type",
                "title": "IRI subjects without rdf:type in same graph (excluding SHACL helper nodes)",
                "sql": f"""
                    WITH all_subjects AS (
                      SELECT DISTINCT g, s
                      FROM rdf_quads
                      WHERE s_kind = 'iri'
                    ),
                    typed_subjects AS (
                      SELECT DISTINCT g, s
                      FROM rdf_quads
                      WHERE p = '{self._RDF_TYPE}'
                    ),
                    shacl_helper_subjects AS (
                      SELECT DISTINCT q.g, q.s
                      FROM rdf_quads q
                      JOIN rdf_quads r
                        ON q.g = r.g
                       AND q.s = r.o
                      WHERE r.p IN (
                        'http://www.w3.org/ns/shacl#property',
                        'http://www.w3.org/ns/shacl#sparql',
                        'http://www.w3.org/ns/shacl#path'
                      )
                    )
                    SELECT COUNT(*)
                    FROM all_subjects a
                    LEFT JOIN typed_subjects t
                      ON a.g = t.g AND a.s = t.s
                    LEFT JOIN shacl_helper_subjects h
                      ON a.g = h.g AND a.s = h.s
                    WHERE t.s IS NULL
                      AND h.s IS NULL
                """,
                "findings_sql": f"""
                    WITH all_subjects AS (
                      SELECT DISTINCT g, s
                      FROM rdf_quads
                      WHERE s_kind = 'iri'
                    ),
                    typed_subjects AS (
                      SELECT DISTINCT g, s
                      FROM rdf_quads
                      WHERE p = '{self._RDF_TYPE}'
                    ),
                    shacl_helper_subjects AS (
                      SELECT DISTINCT q.g, q.s
                      FROM rdf_quads q
                      JOIN rdf_quads r
                        ON q.g = r.g
                       AND q.s = r.o
                      WHERE r.p IN (
                        'http://www.w3.org/ns/shacl#property',
                        'http://www.w3.org/ns/shacl#sparql',
                        'http://www.w3.org/ns/shacl#path'
                      )
                    )
                    SELECT a.g, a.s
                    FROM all_subjects a
                    LEFT JOIN typed_subjects t
                      ON a.g = t.g AND a.s = t.s
                    LEFT JOIN shacl_helper_subjects h
                      ON a.g = h.g AND a.s = h.s
                    WHERE t.s IS NULL
                      AND h.s IS NULL
                """,
                "likely_causes": [
                    "Incomplete entity definitions (missing class assertions)",
                    "Residual subject resources not linked as SHACL helpers",
                ],
                "correction_steps": [
                    "Review whether each reported subject should carry rdf:type",
                    "Add missing type assertions for modeled resources",
                ],
            },
            {
                "id": "conflicting_rdfs_labels",
                "title": "Subjects with multiple distinct rdfs:label values in same graph",
                "sql": f"""
                    SELECT COUNT(*)
                    FROM (
                      SELECT g, s
                      FROM rdf_quads
                      WHERE p = '{self._RDFS_LABEL}' AND o_kind = 'literal'
                      GROUP BY g, s
                      HAVING COUNT(DISTINCT o) > 1
                    ) t
                """,
                "findings_sql": f"""
                    SELECT g, s, string_agg(DISTINCT o, ' | ') AS labels
                    FROM rdf_quads
                    WHERE p = '{self._RDFS_LABEL}' AND o_kind = 'literal'
                    GROUP BY g, s
                    HAVING COUNT(DISTINCT o) > 1
                """,
                "likely_causes": [
                    "Competing label sources across merged graphs",
                    "Alias/localized labels written without language disambiguation",
                ],
                "correction_steps": [
                    "Normalize preferred label policy per subject",
                    "Use language-tagged labels or one canonical display label",
                ],
            },
        ]

        issues: List[Dict[str, Any]] = []
        for check in checks:
            total = 0
            sample_paths: List[str] = []
            db_breakdown: List[Dict[str, Any]] = []
            findings: List[Dict[str, Any]] = []
            for db_row in db_stats:
                if not db_row.get("has_quads_table"):
                    continue
                db_path = Path(str(db_row.get("path") or ""))
                if not db_path.exists():
                    continue
                try:
                    count = self._duckdb_scalar_int(db_path, str(check["sql"]))
                except Exception:  # pylint: disable=broad-exception-caught
                    continue
                if count > 0:
                    sample_paths.append(f"{db_row.get('db_kind')}:{count}")
                    db_breakdown.append(
                        {
                            "db_kind": str(db_row.get("db_kind") or ""),
                            "count": int(count),
                            "path": str(db_row.get("path") or ""),
                        }
                    )
                    try:
                        all_rows = self._duckdb_query_rows(
                            db_path=db_path,
                            sql=str(check.get("findings_sql") or ""),
                        )
                        for row in all_rows:
                            payload = {"db_kind": str(db_row.get("db_kind") or "")}
                            payload.update(row)
                            findings.append(payload)
                    except Exception:  # pylint: disable=broad-exception-caught
                        pass
                total += int(count)
            if total > 0:
                issues.append(
                    {
                        "id": str(check["id"]),
                        "title": str(check["title"]),
                        "count": int(total),
                        "samples": sample_paths[:25],
                        "db_breakdown": db_breakdown,
                        "findings": findings,
                        "likely_causes": list(check.get("likely_causes") or []),
                        "correction_steps": list(check.get("correction_steps") or []),
                    }
                )
        return issues

    def _render_diagnostics_text_report(
        self,
        *,
        semantics_dir: Path,
        db_stats: List[Dict[str, Any]],
        issues: List[Dict[str, Any]],
        total_quads: int,
        catalog_graph_count: int,
    ) -> str:
        lines: List[str] = []
        lines.append("CogniFlow Ontology Diagnostics Report")
        lines.append(f"Generated (UTC): {datetime.now(timezone.utc).isoformat()}")
        lines.append(f"Semantics dir: {semantics_dir}")
        lines.append("")
        lines.append("Database Coverage:")
        for row in db_stats:
            lines.append(
                "- {kind}: exists={exists} quads_table={has_quads} quads={count} graphs={graphs}".format(
                    kind=row.get("db_kind"),
                    exists=row.get("exists"),
                    has_quads=row.get("has_quads_table"),
                    count=row.get("quad_count"),
                    graphs=row.get("distinct_graph_count"),
                )
            )
            for err in row.get("errors") or []:
                lines.append(f"  error: {err}")
        lines.append("")
        lines.append("Summary:")
        lines.append(f"- total_quads: {int(total_quads)}")
        lines.append(f"- catalog_graph_count: {int(catalog_graph_count)}")
        lines.append(f"- concerns: {sum(int(item.get('count') or 0) for item in issues)}")
        lines.append("")
        lines.append("Concerns:")
        if not issues:
            lines.append("- none detected")
        else:
            for issue in issues:
                lines.append(f"- {issue.get('title')}: {issue.get('count')}")
                for sample in (issue.get("samples") or [])[:10]:
                    lines.append(f"  sample: {sample}")
                for finding in (issue.get("findings") or []):
                    lines.append(
                        "  finding[{db}] g={g} s={s} p={p} o={o} o_kind={o_kind}".format(
                            db=finding.get("db_kind", "?"),
                            g=str(finding.get("g", "")),
                            s=str(finding.get("s", "")),
                            p=str(finding.get("p", "")),
                            o=repr(str(finding.get("o", ""))),
                            o_kind=str(finding.get("o_kind", "")),
                        )
                    )
        lines.append("")
        lines.append("AI Remediation Agenda:")
        if not issues:
            lines.append("1. No remediation tasks required.")
        else:
            ranked = sorted(issues, key=lambda item: int(item.get("count") or 0), reverse=True)
            for idx, issue in enumerate(ranked, start=1):
                lines.append(f"{idx}. {issue.get('title')} (count={issue.get('count')})")
                lines.append("   Scope by database:")
                for part in (issue.get("db_breakdown") or [])[:10]:
                    lines.append(
                        f"   - {part.get('db_kind')}: {part.get('count')} ({part.get('path')})"
                    )
                likely_causes = issue.get("likely_causes") or []
                if likely_causes:
                    lines.append("   Likely causes:")
                    for cause in likely_causes[:5]:
                        lines.append(f"   - {cause}")
                correction_steps = issue.get("correction_steps") or []
                if correction_steps:
                    lines.append("   Suggested corrections:")
                    for step in correction_steps[:6]:
                        lines.append(f"   - {step}")
                finding_rows = issue.get("findings") or []
                if finding_rows:
                    lines.append("   All detected findings:")
                    for row in finding_rows:
                        compact = ", ".join(
                            [
                                f"{key}={str(value)}"
                                for key, value in row.items()
                                if key in {"db_kind", "g", "s", "p", "o", "o_kind", "o_datatype", "o_lang", "labels", "dup_count"}
                                and value not in (None, "")
                            ]
                        )
                        if compact:
                            lines.append(f"   - {compact}")
        return "\n".join(lines)

    @staticmethod
    def _duckdb_has_table(db_path: Path, table_name: str) -> bool:
        con = duckdb.connect(str(db_path), read_only=True)
        try:
            result = con.execute(
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = ?",
                [table_name],
            ).fetchone()
            return bool(result and int(result[0] or 0) > 0)
        finally:
            con.close()

    @staticmethod
    def _duckdb_scalar_int(db_path: Path, sql: str) -> int:
        con = duckdb.connect(str(db_path), read_only=True)
        try:
            result = con.execute(sql).fetchone()
            return int(result[0] or 0) if result else 0
        finally:
            con.close()

    @staticmethod
    def _duckdb_fetch_graph_ids(db_path: Path) -> set[str]:
        con = duckdb.connect(str(db_path), read_only=True)
        try:
            rows = con.execute("SELECT DISTINCT g FROM rdf_quads WHERE g IS NOT NULL").fetchall()
            return {str(row[0]).strip() for row in rows if row and str(row[0]).strip()}
        finally:
            con.close()

    @staticmethod
    def _duckdb_query_rows(db_path: Path, sql: str) -> List[Dict[str, Any]]:
        if not sql.strip():
            return []
        con = duckdb.connect(str(db_path), read_only=True)
        try:
            cursor = con.execute(sql)
            col_names = [str(item[0]) for item in (cursor.description or [])]
            out: List[Dict[str, Any]] = []
            for row in cursor.fetchall():
                payload: Dict[str, Any] = {}
                for idx, col_name in enumerate(col_names):
                    payload[col_name] = row[idx] if idx < len(row) else None
                out.append(payload)
            return out
        finally:
            con.close()

    @staticmethod
    def _shrink_uri(uri: URIRef, graph: Graph) -> str:
        try:
            return graph.namespace_manager.qname(uri)
        except Exception:  # pylint: disable=broad-exception-caught
            return str(uri)

    @staticmethod
    def _literal_to_bool(literal: Optional[Literal]) -> Optional[bool]:
        if literal is None:
            return None
        value = str(literal).strip().lower()
        if value in {"true", "1", "yes", "y"}:
            return True
        if value in {"false", "0", "no", "n"}:
            return False
        return None

    @staticmethod
    def _cf_namespace() -> Namespace:
        return Namespace("https://cogniflow.odea-project.org/cf#")

    def _get_graph_catalog_map(self) -> Dict[str, Dict[str, Any]]:
        if not self._manager or not getattr(self._manager, "list_active_graph_catalog", None):
            return {}
        rows = self._manager.list_active_graph_catalog()
        out: Dict[str, Dict[str, Any]] = {}
        for row in rows:
            graph_id = str(row.get("graph_id") or "").strip()
            if not graph_id or graph_id in out:
                continue
            out[graph_id] = row
        return out

    def _graph_category(self, *, graph_id: str, graph_type: str, graph_kind: str) -> str:
        gid = graph_id.strip().lower()
        gtype = graph_type.strip().lower()
        gkind = graph_kind.strip().lower()
        if gid == "core" or gid.endswith("/core"):
            return "core"
        if gid == "shapes" or gid.endswith("/shapes") or gtype == "shapes":
            return "shapes"
        if gkind == "pipeline_rev" or gtype == "pipeline" or gid.startswith("pipe:"):
            return "pipelines"
        if gkind in {"package", "package_step"} or gtype == "step" or gid.startswith("pkg:"):
            return "processing_steps"
        return "other"

    def _graph_display_name(
        self,
        graph_id: str,
        category: str,
        catalog: Optional[Dict[str, Any]],
    ) -> str:
        if category == "core":
            return "core"
        if category == "shapes":
            return "shapes"
        if category == "pipelines":
            clean = graph_id
            if graph_id.startswith("pipe:"):
                clean = graph_id[len("pipe:") :]
            return f"Pipeline: {clean}"
        if category == "processing_steps":
            local_id = str(catalog.get("local_id") or "").strip() if catalog else ""
            compact_id = str(catalog.get("compact_id") or "").strip() if catalog else ""
            package_name = str(catalog.get("package_name") or "").strip() if catalog else ""
            package_version = str(catalog.get("package_version") or "").strip() if catalog else ""
            if local_id:
                return local_id
            if compact_id:
                return compact_id
            if package_name and package_version:
                return f"{package_name}@{package_version}"
            if package_name:
                return package_name
            return graph_id
        return graph_id

    @staticmethod
    def _card_color(category: str) -> str:
        mapping = {
            "core": "var(--ontology-card-core)",
            "shapes": "var(--ontology-card-shapes)",
            "processing_steps": "var(--ontology-card-steps)",
            "pipelines": "var(--ontology-card-pipelines)",
            "datatypes": "var(--ontology-card-datatypes)",
            "other": "var(--ontology-card-other)",
        }
        return mapping.get(category, "var(--ontology-card-other)")

    def _compact_iri(self, iri: str, context: Dict[str, Any]) -> str:
        text = str(iri or "").strip()
        if not text:
            return text
        pairs: List[tuple[str, str]] = []
        for prefix, ns in context.items():
            if isinstance(prefix, str) and isinstance(ns, str) and ns:
                pairs.append((prefix, ns))
        pairs.sort(key=lambda item: len(item[1]), reverse=True)
        for prefix, ns in pairs:
            if text.startswith(ns):
                local = text[len(ns) :]
                if local:
                    return f"{prefix}:{local}"
        return text

    def _subject_values(self, subjects: List[str], predicates: List[str]) -> Dict[str, str]:
        if not subjects:
            return {}
        subject_set = set(subjects)
        out: Dict[str, str] = {}
        for predicate in predicates:
            rows = self._manager.query_quads(predicate=predicate, limit=50000)
            for row in rows:
                subject = str(row.get("subject") or "")
                if subject not in subject_set or subject in out:
                    continue
                if str(row.get("object_kind") or "") != "literal":
                    continue
                out[subject] = str(row.get("object") or "")
        return out

    def _subject_labels(self, subjects: List[str]) -> Dict[str, str]:
        return self._subject_values(
            subjects,
            [
                self._RDFS_LABEL,
                self._CF_DESCRIPTION_HTTPS,
                self._CF_DESCRIPTION_HTTP,
            ],
        )

    def _datatype_usage_rows(self) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        predicates = [
            self._CF_PORT_TYPE_HTTPS,
            self._CF_PORT_TYPE_HTTP,
            self._CF_PARAMETER_TYPE_HTTPS,
            self._CF_PARAMETER_TYPE_HTTP,
            self._RDFS_RANGE,
        ]
        for predicate in predicates:
            for row in self._manager.query_quads(predicate=predicate, limit=50000):
                if str(row.get("object_kind") or "") != "iri":
                    continue
                rows.append(row)
        return rows

    def _parse_ports(
        self,
        graph: Graph,
        step_uri: URIRef,
        predicate: URIRef,
    ) -> List[Dict[str, Any]]:
        ports: List[Dict[str, Any]] = []
        cf = self._cf_namespace()

        def _native(value: Any) -> Any:
            if value is None:
                return None
            if isinstance(value, Literal):
                native = value.toPython()
                if isinstance(native, str):
                    stripped = native.strip()
                    if stripped.startswith("{") or stripped.startswith("["):
                        try:
                            return json.loads(native)
                        except json.JSONDecodeError:
                            return native
                return native
            if isinstance(value, URIRef):
                return self._shrink_uri(value, graph)
            if isinstance(value, BNode):
                payload: Dict[str, Any] = {}
                for pred, obj in graph.predicate_objects(value):
                    key = self._shrink_uri(pred, graph)
                    payload[key] = _native(obj)
                return payload
            return str(value)

        for port in graph.objects(step_uri, predicate):
            port_name = graph.value(port, cf.portName)
            port_type = graph.value(port, cf.portType)
            port_desc = graph.value(port, cf.description)
            optional_literal = graph.value(port, cf.isOptional)
            port_default = graph.value(port, cf.defaultValue)
            min_value = graph.value(port, cf.minValue)
            max_value = graph.value(port, cf.maxValue)
            allowed_values = [_native(v) for v in graph.objects(port, cf.allowedValue)]
            optional = bool(self._literal_to_bool(optional_literal))
            ports.append(
                {
                    "id": str(port),
                    "name": str(port_name) if port_name else None,
                    "type": self._shrink_uri(port_type, graph) if port_type else None,
                    "type_uri": str(port_type) if port_type else None,
                    "description": str(port_desc) if port_desc else None,
                    "optional": optional,
                    "default": _native(port_default),
                    "min": _native(min_value),
                    "max": _native(max_value),
                    "allowed": allowed_values,
                }
            )
        return sorted(ports, key=lambda p: p["name"] or "")

    def _parse_parameters(self, graph: Graph, step_uri: URIRef) -> List[Dict[str, Any]]:
        parameters: List[Dict[str, Any]] = []
        cf = self._cf_namespace()
        required_ids = {str(param) for param in graph.objects(step_uri, cf.requiresParameter)}

        def _native(value: Any) -> Any:
            if value is None:
                return None
            if isinstance(value, Literal):
                native = value.toPython()
                if isinstance(native, str):
                    stripped = native.strip()
                    if stripped.startswith("{") or stripped.startswith("["):
                        try:
                            return json.loads(native)
                        except json.JSONDecodeError:
                            return native
                return native
            if isinstance(value, URIRef):
                return self._shrink_uri(value, graph)
            if isinstance(value, BNode):
                payload: Dict[str, Any] = {}
                for pred, obj in graph.predicate_objects(value):
                    key = self._shrink_uri(pred, graph)
                    payload[key] = _native(obj)
                return payload
            return str(value)

        for param in graph.objects(step_uri, cf.hasParameter):
            param_name = graph.value(param, cf.parameterName)
            if not param_name:
                continue
            ptype = graph.value(param, cf.parameterType)
            pdesc = graph.value(param, cf.description)
            default_value = graph.value(param, cf.defaultValue)
            min_value = graph.value(param, cf.minValue)
            max_value = graph.value(param, cf.maxValue)
            allowed_values = [_native(v) for v in graph.objects(param, cf.allowedValue)]
            required_literal = graph.value(param, cf.isRequired)
            required = self._literal_to_bool(required_literal)
            if required is None:
                required = str(param) in required_ids
            parameters.append(
                {
                    "id": str(param),
                    "name": str(param_name),
                    "type": self._shrink_uri(ptype, graph) if ptype else None,
                    "type_uri": str(ptype) if ptype else None,
                    "description": str(pdesc) if pdesc else None,
                    "default": _native(default_value),
                    "min": _native(min_value),
                    "max": _native(max_value),
                    "allowed": allowed_values,
                    "required": bool(required),
                }
            )
        return sorted(parameters, key=lambda p: p["name"])

    def _build_graph_data_from_document(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        graph = Graph()
        graph.parse(data=json.dumps(doc, ensure_ascii=True), format=_RDF_AUTHORING_FORMAT)
        return self._build_graph_data_from_graph(graph)

    def _build_graph_data_from_graph(self, graph: Graph) -> Dict[str, Any]:
        cf = self._cf_namespace()

        nodes: Dict[str, Dict[str, Any]] = {}
        links: List[Dict[str, str]] = []
        extra_links: List[Dict[str, str]] = []
        extra_link_keys: set[tuple[str, str, str]] = set()

        def _value_to_native(value: Any) -> Any:
            if isinstance(value, Literal):
                native = value.toPython()
                if isinstance(native, str):
                    stripped = native.strip()
                    if stripped.startswith("{") or stripped.startswith("["):
                        try:
                            return json.loads(native)
                        except json.JSONDecodeError:
                            return native
                return native
            if isinstance(value, URIRef):
                return self._shrink_uri(value, graph)
            if isinstance(value, BNode):
                payload: Dict[str, Any] = {}
                for pred, obj in graph.predicate_objects(value):
                    key = self._shrink_uri(pred, graph)
                    val = _value_to_native(obj)
                    if key in payload:
                        existing = payload[key]
                        if not isinstance(existing, list):
                            payload[key] = [existing]
                        payload[key].append(val)
                    else:
                        payload[key] = val
                return payload
            return str(value)

        def _literal_predicates(value: Any) -> Dict[str, Any]:
            if not isinstance(value, (URIRef, BNode)):
                return {}
            payload: Dict[str, Any] = {}
            for pred, obj in graph.predicate_objects(value):
                if not isinstance(obj, Literal):
                    continue
                key = self._shrink_uri(pred, graph)
                val = obj.toPython()
                if key in payload:
                    existing = payload[key]
                    if not isinstance(existing, list):
                        payload[key] = [existing]
                    payload[key].append(val)
                else:
                    payload[key] = val
            return payload

        def _register_node(uri) -> None:
            key = str(uri)
            if key in nodes:
                return
            compact = self._shrink_uri(uri, graph) if isinstance(uri, URIRef) else key
            aliases: List[str] = [key]
            if compact != key:
                aliases.append(compact)
            if isinstance(uri, URIRef):
                uri_text = str(uri)
                local_name = uri_text
                if "#" in uri_text:
                    local_name = uri_text.split("#", 1)[1]
                elif "/" in uri_text:
                    local_name = uri_text.rsplit("/", 1)[-1]
                if local_name and local_name not in aliases:
                    aliases.append(local_name)
            label_literal = graph.value(uri, RDFS.label)
            comment_literal = graph.value(uri, RDFS.comment)
            description_literal = graph.value(uri, cf.description)
            category_literal = graph.value(uri, cf.stepCategory)
            package_literal = graph.value(uri, cf.belongsToStepPackage)
            parameter_name_literal = graph.value(uri, cf.parameterName)
            parameter_type_literal = graph.value(uri, cf.parameterType)
            default_literal = graph.value(uri, cf.defaultValue)
            min_value_literal = graph.value(uri, cf.minValue)
            max_value_literal = graph.value(uri, cf.maxValue)
            allowed_values_literal = [obj for obj in graph.objects(uri, cf.allowedValue)]
            meta: Dict[str, Any] = {}
            if label_literal:
                meta["label"] = str(label_literal)
            if comment_literal:
                meta["comment"] = str(comment_literal)
            if description_literal:
                meta["description"] = str(description_literal)
            if category_literal:
                meta["category"] = str(category_literal)
            if package_literal:
                meta["package"] = str(package_literal)
            if parameter_name_literal:
                meta["parameterName"] = str(parameter_name_literal)
            if parameter_type_literal:
                meta["parameterType"] = _value_to_native(parameter_type_literal)
            if default_literal is not None:
                meta["defaultValue"] = _value_to_native(default_literal)
            if min_value_literal is not None:
                meta["minValue"] = _value_to_native(min_value_literal)
            if max_value_literal is not None:
                meta["maxValue"] = _value_to_native(max_value_literal)
            if allowed_values_literal:
                meta["allowedValue"] = [_value_to_native(v) for v in allowed_values_literal]
            if isinstance(uri, BNode):
                literal_map = _literal_predicates(uri)
                if literal_map:
                    meta["literals"] = literal_map

            if isinstance(uri, URIRef) and (uri, RDF.type, cf.ProcessingStep) in graph:
                meta["inputs"] = self._parse_ports(graph, uri, cf.hasInput)
                meta["outputs"] = self._parse_ports(graph, uri, cf.hasOutput)
                meta["parameters"] = self._parse_parameters(graph, uri)

            nodes[key] = {
                "id": key,
                "canonical_id": key,
                "compact_id": compact,
                "aliases": aliases,
                "label": compact,
                "uri": key,
                "types": set(),
                "meta": meta,
            }

        for subj, pred, obj in graph:
            if isinstance(subj, (URIRef, BNode)):
                _register_node(subj)
            if isinstance(obj, (URIRef, BNode)):
                _register_node(obj)

            if isinstance(subj, (URIRef, BNode)) and pred == RDF.type and isinstance(obj, URIRef):
                nodes[str(subj)]["types"].add(self._shrink_uri(obj, graph))

            if isinstance(subj, (URIRef, BNode)) and isinstance(obj, (URIRef, BNode)):
                links.append(
                    {
                        "source": str(subj),
                        "target": str(obj),
                        "predicate": self._shrink_uri(pred, graph),
                    }
                )

        for node in nodes.values():
            node["types"] = sorted(node["types"])

        for node in nodes.values():
            meta = node.get("meta", {})
            for port in meta.get("inputs", []):
                type_uri = port.get("type_uri") or port.get("type")
                if not type_uri:
                    continue
                try:
                    type_ref = URIRef(str(type_uri))
                except Exception:  # pylint: disable=broad-exception-caught
                    continue
                _register_node(type_ref)
                key = (node["id"], str(type_ref), "inputType")
                if key not in extra_link_keys:
                    extra_link_keys.add(key)
                    extra_links.append(
                        {
                            "source": node["id"],
                            "target": str(type_ref),
                            "predicate": port.get("name") or "input",
                            "kind": "type_hint",
                        }
                    )
            for port in meta.get("outputs", []):
                type_uri = port.get("type_uri") or port.get("type")
                if not type_uri:
                    continue
                try:
                    type_ref = URIRef(str(type_uri))
                except Exception:  # pylint: disable=broad-exception-caught
                    continue
                _register_node(type_ref)
                key = (node["id"], str(type_ref), "outputType")
                if key not in extra_link_keys:
                    extra_link_keys.add(key)
                    extra_links.append(
                        {
                            "source": node["id"],
                            "target": str(type_ref),
                            "predicate": port.get("name") or "output",
                            "kind": "type_hint",
                        }
                    )
            for param in meta.get("parameters", []):
                type_uri = param.get("type_uri") or param.get("type")
                if not type_uri:
                    continue
                try:
                    type_ref = URIRef(str(type_uri))
                except Exception:  # pylint: disable=broad-exception-caught
                    continue
                _register_node(type_ref)
                key = (node["id"], str(type_ref), "paramType")
                if key not in extra_link_keys:
                    extra_link_keys.add(key)
                    extra_links.append(
                        {
                            "source": node["id"],
                            "target": str(type_ref),
                            "predicate": param.get("name") or "param",
                            "kind": "type_hint",
                        }
                    )

        return {
            "nodes": list(nodes.values()),
            "links": links + extra_links,
        }
