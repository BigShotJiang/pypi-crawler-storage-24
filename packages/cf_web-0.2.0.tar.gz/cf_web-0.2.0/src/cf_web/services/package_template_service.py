"""Generate package template zip archives for cf_web."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from importlib import metadata as importlib_metadata
from io import BytesIO
import json
import re
from typing import Any
from zipfile import ZIP_DEFLATED, ZipFile

from pyshacl import validate as shacl_validate
from rdflib import Dataset, Graph
from rdflib.namespace import RDF, SH
from pydantic import BaseModel, Field, field_validator

from cf_ontology.rdf_document import canonical_json
from cf_web.services.manager_provider import get_ontology_manager

_PYPI_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9-]*$")
_CPP_IDENT_PATTERN = re.compile(r"[^a-zA-Z0-9_]+")
_STEP_NAME_PATTERN = re.compile(r"[^a-zA-Z0-9_]+")
_DEFAULT_VERSION = "0.1.0"
_TEMPLATE_MIN_VERSION = "0.0.1"
_RDF_AUTHORING_FORMAT = "json" + "-ld"


def _validate_pypi_name(value: str) -> str:
    trimmed = value.strip()
    if not _PYPI_NAME_PATTERN.match(trimmed):
        raise ValueError(
            "PyPI distribution name must start with a letter and contain only "
            "lowercase letters, digits, and hyphens."
        )
    return trimmed


def _ensure_prefixed_type(value: str) -> str:
    raw = value.strip()
    if not raw:
        return "cf:string"
    if ":" in raw:
        return raw
    return f"cf:{raw}"


def _normalize_category(value: str) -> str:
    raw = value.strip()
    if not raw:
        return "cf:analytical"
    if ":" in raw:
        return raw
    return f"cf:{raw}"


def _literal_contract_type(value: str) -> str:
    normalized = _ensure_prefixed_type(value)
    mapping = {
        "cf:boolean": "xsd:boolean",
        "xsd:boolean": "xsd:boolean",
        "cf:integer": "xsd:integer",
        "xsd:integer": "xsd:integer",
        "cf:double": "xsd:double",
        "cf:float": "xsd:double",
        "cf:number": "xsd:double",
        "xsd:double": "xsd:double",
        "cf:string": "xsd:string",
        "xsd:string": "xsd:string",
        "cf:json": "rdf:JSON",
        "rdf:JSON": "rdf:JSON",
    }
    return mapping.get(normalized, normalized)


def _sanitize_step_name(name: str) -> str:
    value = _STEP_NAME_PATTERN.sub("_", name.strip())
    value = re.sub(r"_+", "_", value).strip("_")
    if not value:
        return "Step"
    if value[0].isdigit():
        value = f"Step_{value}"
    return value


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _coerce_default_for_type(data_type: str, value: Any) -> Any:
    if value is None:
        if data_type == "cf:boolean":
            return False
        if data_type in {"cf:integer", "cf:float", "cf:number"}:
            return 0
        return ""
    if data_type == "cf:boolean":
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        return text in {"true", "1", "yes", "y"}
    if data_type == "cf:integer":
        if isinstance(value, bool):
            return int(value)
        return int(float(value))
    if data_type in {"cf:float", "cf:number"}:
        if isinstance(value, bool):
            return float(int(value))
        return float(value)
    return str(value)


def _coerce_bound_for_type(data_type: str, value: Any, fallback: Any) -> Any:
    if value is None:
        return fallback
    if data_type == "cf:integer":
        return int(float(value))
    if data_type in {"cf:float", "cf:number"}:
        return float(value)
    return value


def _port_key_from_name(name: str) -> str:
    _ = name
    return "cf:data"


def _cpp_identifier(value: str) -> str:
    out = _CPP_IDENT_PATTERN.sub("_", value).strip("_")
    out = re.sub(r"_+", "_", out)
    if not out:
        out = "step"
    if out[0].isdigit():
        out = f"step_{out}"
    return out.lower()


def _id_suffix_from_label(value: str, fallback: str) -> str:
    raw = value.strip() or fallback
    # Split CamelCase so labels like "SpectraHeaders" become "spectra_headers".
    raw = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", raw)
    raw = re.sub(r"[^a-zA-Z0-9]+", "_", raw)
    raw = re.sub(r"_+", "_", raw).strip("_").lower()
    if not raw:
        return fallback
    if raw[0].isdigit():
        raw = f"id_{raw}"
    return raw


class PackagePortSpec(BaseModel):
    """Port definition payload."""

    name: str = Field(default="value", min_length=1)
    data_type: str = Field(default="xsd:double")
    description: str = Field(default="")

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        trimmed = value.strip()
        if not trimmed:
            raise ValueError("Port name must not be empty.")
        return trimmed

    @field_validator("data_type")
    @classmethod
    def validate_data_type(cls, value: str) -> str:
        return _ensure_prefixed_type(value)


class PackageParameterSpec(BaseModel):
    """Step parameter payload."""

    name: str = Field(default="mode", min_length=1)
    data_type: str = Field(default="cf:string")
    description: str = Field(default="")
    default_value: Any = ""
    min_value: Any | None = None
    max_value: Any | None = None
    allowed_values: list[Any] = Field(default_factory=list)
    required: bool = False

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        trimmed = value.strip()
        if not trimmed:
            raise ValueError("Parameter name must not be empty.")
        return trimmed

    @field_validator("data_type")
    @classmethod
    def validate_data_type(cls, value: str) -> str:
        return _ensure_prefixed_type(value)


class PackageStepSpec(BaseModel):
    """Step payload."""

    name: str = Field(default="MyStep", min_length=1)
    label: str = Field(default="My Step")
    description: str = Field(default="")
    category: str = Field(default="cf:analytical")
    inputs: list[PackagePortSpec] = Field(default_factory=list)
    outputs: list[PackagePortSpec] = Field(default_factory=list)
    parameters: list[PackageParameterSpec] = Field(default_factory=list)

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        trimmed = value.strip()
        if not trimmed:
            raise ValueError("Step name must not be empty.")
        return trimmed

    @field_validator("category")
    @classmethod
    def validate_category(cls, value: str) -> str:
        return _normalize_category(value)


class PackageTemplateRequest(BaseModel):
    """Template generation payload."""

    pypi_distribution_name: str = Field(default="cf-step-dev")
    package_version: str = Field(default=_DEFAULT_VERSION)
    package_label: str = Field(default="Generated Step Package")
    package_description: str = Field(
        default="Generated step package scaffold with demo and extensible stubs."
    )
    requires_cogniflow_core: str = Field(default=">=0.5.0")
    steps: list[PackageStepSpec] = Field(default_factory=list)

    @field_validator("pypi_distribution_name")
    @classmethod
    def validate_distribution_name(cls, value: str) -> str:
        return _validate_pypi_name(value)

    @field_validator("package_version")
    @classmethod
    def validate_version(cls, value: str) -> str:
        trimmed = value.strip()
        if not trimmed:
            raise ValueError("package_version must not be empty.")
        return trimmed


@dataclass(slots=True)
class GeneratedTemplate:
    """In-memory template output."""

    filename: str
    content: bytes
    manifest: dict[str, Any]
    validation_report: dict[str, Any]
    generated_files: list[str]
    generated_at_utc: str


class PackageTemplateService:
    """Service for package template generation + SHACL validation."""

    def create_template(self, request: PackageTemplateRequest) -> GeneratedTemplate:
        pypi_name = _validate_pypi_name(request.pypi_distribution_name)
        python_module = pypi_name.replace("-", "_")
        package_id = pypi_name.replace("-", ".")
        namespace = f"https://cogniflow.odea-project.org/cf#generated/{package_id.replace('.', '/')}/"
        package_version = _TEMPLATE_MIN_VERSION
        requires_cogniflow_core = self._resolve_current_core_requirement()

        normalized_steps = self._normalize_steps(request.steps)
        self._ensure_demo_step(normalized_steps)

        manifest = self._build_manifest(
            namespace=namespace,
            package_id=package_id,
            python_module=python_module,
            package_version=package_version,
            requires_cogniflow_core=requires_cogniflow_core,
            request=request,
            steps=normalized_steps,
        )
        validation_report = self._validate_manifest(manifest)

        archive_name = f"{python_module}.zip"
        content, generated_files = self._build_zip(
            archive_name=archive_name,
            pypi_name=pypi_name,
            python_module=python_module,
            package_id=package_id,
            package_version=package_version,
            requires_cogniflow_core=requires_cogniflow_core,
            request=request,
            manifest=manifest,
            steps=normalized_steps,
        )
        return GeneratedTemplate(
            filename=archive_name,
            content=content,
            manifest=manifest,
            validation_report=validation_report,
            generated_files=generated_files,
            generated_at_utc=datetime.now(timezone.utc).isoformat(),
        )

    def _normalize_steps(self, steps: list[PackageStepSpec]) -> list[dict[str, Any]]:
        output: list[dict[str, Any]] = []
        usage: dict[str, int] = {}
        for raw in steps:
            base_name = _sanitize_step_name(raw.name)
            count = usage.get(base_name, 0) + 1
            usage[base_name] = count
            resolved_name = base_name if count == 1 else f"{base_name}_{count}"
            label = raw.label.strip() or resolved_name
            description = raw.description.strip() or f"{label} generated step."
            category = _normalize_category(raw.category)
            inputs = [item.model_dump() for item in raw.inputs]
            outputs = [item.model_dump() for item in raw.outputs]
            parameters = [item.model_dump() for item in raw.parameters]
            output.append(
                {
                    "name": resolved_name,
                    "label": label,
                    "description": description,
                    "category": category,
                    "inputs": inputs,
                    "outputs": outputs,
                    "parameters": parameters,
                }
            )
        return output

    def _ensure_demo_step(self, steps: list[dict[str, Any]]) -> None:
        demo_name = "OperationStepDemo"
        demo_count = sum(1 for step in steps if step["name"] == demo_name)
        if demo_count == 0:
            steps.insert(0, self._default_demo_step())
        elif demo_count > 1:
            seen_demo = 0
            for step in steps:
                if step["name"] != demo_name:
                    continue
                seen_demo += 1
                if seen_demo > 1:
                    step["name"] = f"{demo_name}_{seen_demo}"
        if steps and steps[0]["name"] != demo_name:
            for index, step in enumerate(steps):
                if step["name"] == demo_name:
                    steps.insert(0, steps.pop(index))
                    break

    def _default_demo_step(self) -> dict[str, Any]:
        return {
            "name": "OperationStepDemo",
            "label": "Operation Step Demo",
            "description": (
                "Minimal demo operation over two numeric inputs producing one result."
            ),
            "category": "cf:analytical",
            "inputs": [
                {
                    "name": "a",
                    "data_type": "xsd:double",
                    "description": "First numeric input.",
                },
                {
                    "name": "b",
                    "data_type": "xsd:double",
                    "description": "Second numeric input.",
                },
            ],
            "outputs": [
                {
                    "name": "result",
                    "data_type": "xsd:double",
                    "description": "Computed result.",
                }
            ],
            "parameters": [
                {
                    "name": "operation_type",
                    "data_type": "cf:string",
                    "description": "Operation to execute.",
                    "default_value": "sum",
                    "min_value": None,
                    "max_value": None,
                    "allowed_values": [
                        "sum",
                        "multiplication",
                        "subtraction",
                        "division",
                    ],
                    "required": True,
                }
            ],
        }

    def _build_manifest(
        self,
        *,
        namespace: str,
        package_id: str,
        python_module: str,
        package_version: str,
        requires_cogniflow_core: str,
        request: PackageTemplateRequest,
        steps: list[dict[str, Any]],
    ) -> dict[str, Any]:
        context = {
            "adf": "http://allotrope.org/datamodel#",
            "cf": "https://cogniflow.odea-project.org/cf#",
            "owl": "http://www.w3.org/2002/07/owl#",
            "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
            "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
            "schema": "https://schema.org/",
            "skos": "http://www.w3.org/2004/02/skos/core#",
            "xsd": "http://www.w3.org/2001/XMLSchema#",
            "pkg": namespace,
        }
        graph: list[dict[str, Any]] = []

        package_node_id = "pkg:StepPackage"
        plugin_node_id = "pkg:GeneratedPlugin"

        graph.append(
            {
                "@id": package_node_id,
                "@type": "cf:StepPackage",
                "cf:packageId": package_id,
                "cf:packageVersion": package_version,
                "cf:requiresCogniflowCore": requires_cogniflow_core,
                "cf:pythonModule": python_module,
                "cf:description": request.package_description.strip(),
                "rdfs:label": request.package_label.strip(),
            }
        )

        graph.append(
            {
                "@id": plugin_node_id,
                "@type": ["cf:PluginArtifact", "schema:SoftwareApplication"],
                "schema:name": python_module,
                "schema:programmingLanguage": "C++",
                "cf:pluginName": python_module,
                "cf:pluginVersion": package_version,
                "cf:pluginApiVersion": "1",
                "cf:pluginDataAbi": "Data-v1",
                "cf:artifactPath": "src/" + python_module + "/cpp",
                "cf:pluginListSymbol": "cf_list_steps",
                "cf:pluginResolveSymbol": "cf_resolve_step",
                "cf:description": (
                    "Generated plugin artifact definition for package scaffolding."
                ),
            }
        )

        for step in steps:
            step_id = f"pkg:{step['name']}"
            implementation_id = f"pkg:{step['name']}CppImpl"

            input_nodes, input_contract_nodes = self._build_port_nodes(
                step_name=step["name"],
                ports=step["inputs"],
                node_type="cf:InputPort",
                role="input",
            )
            output_nodes, output_contract_nodes = self._build_port_nodes(
                step_name=step["name"],
                ports=step["outputs"],
                node_type="cf:OutputPort",
                role="output",
            )
            parameter_nodes, parameter_contract_nodes = self._build_parameter_nodes(
                step_name=step["name"],
                parameters=step["parameters"],
            )

            graph.append(
                {
                    "@id": step_id,
                    "@type": "cf:ProcessingStep",
                    "cf:belongsToStepPackage": {"@id": package_node_id},
                    "cf:description": step["description"],
                    "cf:hasImplementation": {"@id": implementation_id},
                    "cf:hasInput": [{"@id": node["@id"]} for node in input_nodes],
                    "cf:hasOutput": [{"@id": node["@id"]} for node in output_nodes],
                    "cf:hasParameter": [
                        {"@id": node["@id"]} for node in parameter_nodes
                    ],
                    "cf:requiresParameter": [
                        {"@id": node["@id"]}
                        for node in parameter_nodes
                        if bool(node.get("cf:isRequired"))
                    ],
                    "cf:stepCategory": {"@id": step["category"]},
                    "rdfs:label": step["label"],
                }
            )
            graph.append(
                {
                    "@id": implementation_id,
                    "@type": "cf:StepImplementation",
                    "cf:description": (
                        f"{step['label']} generated C++ implementation scaffold."
                    ),
                    "cf:implementationArtifact": {"@id": plugin_node_id},
                    "cf:implementationRole": {"@id": "cf:core_implementation"},
                }
            )
            graph.extend(input_nodes)
            graph.extend(input_contract_nodes)
            graph.extend(output_nodes)
            graph.extend(output_contract_nodes)
            graph.extend(parameter_nodes)
            graph.extend(parameter_contract_nodes)

        return {"@context": context, "@graph": graph}

    def _build_port_nodes(
        self,
        *,
        step_name: str,
        ports: list[dict[str, Any]],
        node_type: str,
        role: str,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        result: list[dict[str, Any]] = []
        contracts: list[dict[str, Any]] = []
        used_suffixes: dict[str, int] = {}
        for index, port in enumerate(ports):
            data_type = _ensure_prefixed_type(str(port.get("data_type", "xsd:string")))
            name = str(port.get("name", "")).strip() or f"{role}_{index + 1}"
            description = (
                str(port.get("description", "")).strip()
                or f"{role.capitalize()} port {name} for {step_name}."
            )
            base_suffix = _id_suffix_from_label(name, f"{role}_{index + 1}")
            suffix_count = used_suffixes.get(base_suffix, 0) + 1
            used_suffixes[base_suffix] = suffix_count
            id_suffix = (
                base_suffix if suffix_count == 1 else f"{base_suffix}_{suffix_count}"
            )
            node_id = f"pkg:{step_name}_{role}_{id_suffix}"
            contract_id = f"{node_id}_value_contract"
            result.append(
                {
                    "@id": node_id,
                    "@type": node_type,
                    "cf:description": description,
                    "cf:portKey": {"@id": _port_key_from_name(name)},
                    "cf:portName": name,
                    "cf:valueContract": {"@id": contract_id},
                }
            )
            contracts.append(
                {
                    "@id": contract_id,
                    "@type": "cf:ValueContract",
                    "cf:elementType": {"@id": _literal_contract_type(data_type)},
                    "cf:shapeKind": {"@id": "cf:shape_single"},
                }
            )
        return result, contracts

    def _build_parameter_nodes(
        self,
        *,
        step_name: str,
        parameters: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        result: list[dict[str, Any]] = []
        contracts: list[dict[str, Any]] = []
        used_suffixes: dict[str, int] = {}
        for index, parameter in enumerate(parameters):
            name = str(parameter.get("name", "")).strip() or f"param_{index + 1}"
            data_type = _ensure_prefixed_type(
                str(parameter.get("data_type", "cf:string"))
            )
            description = (
                str(parameter.get("description", "")).strip()
                or f"Parameter {name} for {step_name}."
            )
            default_value = _coerce_default_for_type(
                data_type, parameter.get("default_value")
            )
            base_suffix = _id_suffix_from_label(name, f"param_{index + 1}")
            suffix_count = used_suffixes.get(base_suffix, 0) + 1
            used_suffixes[base_suffix] = suffix_count
            id_suffix = (
                base_suffix if suffix_count == 1 else f"{base_suffix}_{suffix_count}"
            )
            node_id = f"pkg:{step_name}_param_{id_suffix}"
            contract_id = f"{node_id}_value_contract"
            node: dict[str, Any] = {
                "@id": node_id,
                "@type": "cf:Parameter",
                "cf:description": description,
                "cf:parameterName": name,
                "cf:valueContract": {"@id": contract_id},
                "cf:defaultValue": default_value,
                "cf:isRequired": bool(parameter.get("required", False)),
            }
            if data_type == "cf:integer":
                node["cf:minValue"] = _coerce_bound_for_type(
                    data_type, parameter.get("min_value"), 0
                )
                node["cf:maxValue"] = _coerce_bound_for_type(
                    data_type, parameter.get("max_value"), 100
                )
            elif data_type in {"cf:float", "cf:number"}:
                node["cf:minValue"] = _coerce_bound_for_type(
                    data_type, parameter.get("min_value"), 0.0
                )
                node["cf:maxValue"] = _coerce_bound_for_type(
                    data_type, parameter.get("max_value"), 100.0
                )

            allowed_values = _as_list(parameter.get("allowed_values"))
            if allowed_values:
                node["cf:allowedValue"] = [
                    _coerce_default_for_type(data_type, value)
                    for value in allowed_values
                ]
            result.append(node)
            contracts.append(
                {
                    "@id": contract_id,
                    "@type": "cf:ValueContract",
                    "cf:elementType": {"@id": _literal_contract_type(data_type)},
                    "cf:shapeKind": {"@id": "cf:shape_single"},
                }
            )
        return result, contracts

    def _validate_manifest(self, manifest: dict[str, Any]) -> dict[str, Any]:
        manager = get_ontology_manager()
        if manager is None:
            raise RuntimeError("cf_ontology is not available.")

        data_graph = Graph()
        data_graph += manager.graph
        data_graph.parse(data=self._manifest_ntriples(manifest), format="nt")

        conforms, report_graph, report_text = shacl_validate(
            data_graph,
            shacl_graph=manager.shapes,
            inference="rdfs",
            meta_shacl=False,
            advanced=True,
            abort_on_first=False,
        )
        if conforms:
            return {
                "conforms": True,
                "issues": [],
                "message": "steps.nq conforms to SHACL shapes.",
            }

        messages = self._extract_report_messages(report_graph)
        if messages:
            raise ValueError("\n".join(messages))
        raise ValueError(str(report_text).strip() or "SHACL validation failed.")

    def _extract_report_messages(self, report_graph: Graph) -> list[str]:
        issues: list[str] = []
        for result in report_graph.subjects(RDF.type, SH.ValidationResult):
            message = report_graph.value(result, SH.resultMessage)
            focus = report_graph.value(result, SH.focusNode)
            path = report_graph.value(result, SH.resultPath)
            parts = [str(message)] if message else ["SHACL validation issue."]
            if focus:
                parts.append(f"focus={focus}")
            if path:
                parts.append(f"path={path}")
            issues.append(" | ".join(parts))
        # Stable deterministic ordering for repeatable responses.
        return sorted(set(issues))

    def _manifest_nquads(self, manifest: dict[str, Any]) -> str:
        dataset = Dataset()
        dataset.parse(data=canonical_json(manifest), format=_RDF_AUTHORING_FORMAT)
        payload = dataset.serialize(format="nquads")
        if isinstance(payload, bytes):
            return payload.decode("utf-8")
        return str(payload)

    def _manifest_ntriples(self, manifest: dict[str, Any]) -> str:
        dataset = Dataset()
        dataset.parse(data=self._manifest_nquads(manifest), format="nquads")
        payload = dataset.default_graph.serialize(format="nt")
        if isinstance(payload, bytes):
            return payload.decode("utf-8")
        return str(payload)

    def _build_zip(
        self,
        *,
        archive_name: str,
        pypi_name: str,
        python_module: str,
        package_id: str,
        package_version: str,
        requires_cogniflow_core: str,
        request: PackageTemplateRequest,
        manifest: dict[str, Any],
        steps: list[dict[str, Any]],
    ) -> tuple[bytes, list[str]]:
        root = archive_name.removesuffix(".zip")
        buffer = BytesIO()
        generated_files: list[str] = []

        def _write_file(zf: ZipFile, relative_path: str, content: str) -> None:
            generated_files.append(relative_path)
            zf.writestr(relative_path, content)

        with ZipFile(buffer, "w", ZIP_DEFLATED) as zf:
            _write_file(
                zf,
                f"{root}/pyproject.toml",
                self._render_pyproject(
                    pypi_name=pypi_name,
                    package_id=package_id,
                    python_module=python_module,
                    package_version=package_version,
                    package_description=request.package_description.strip(),
                ),
            )
            _write_file(
                zf,
                f"{root}/README.md",
                self._render_readme(
                    pypi_name=pypi_name,
                    package_id=package_id,
                    python_module=python_module,
                ),
            )
            _write_file(
                zf,
                f"{root}/src/{python_module}/__init__.py",
                self._render_init_py(package_id=package_id),
            )
            _write_file(
                zf,
                f"{root}/src/{python_module}/steps.nq",
                self._manifest_nquads(manifest),
            )
            _write_file(
                zf,
                f"{root}/src/{python_module}/cpp/steps.cpp",
                self._render_steps_cpp(steps),
            )
            _write_file(
                zf,
                f"{root}/src/{python_module}/cpp/CMakeLists.txt",
                self._render_cpp_cmakelists(python_module),
            )
            _write_file(
                zf,
                f"{root}/resources/README.md",
                self._render_resources_readme(package_id=package_id),
            )
            _write_file(
                zf,
                f"{root}/resources/operation_step_demo.md",
                self._render_demo_notes(),
            )
            _write_file(
                zf,
                f"{root}/resources/extension_notes.md",
                self._render_extension_notes(steps=steps),
            )
        return buffer.getvalue(), generated_files

    def _render_pyproject(
        self,
        *,
        pypi_name: str,
        package_id: str,
        python_module: str,
        package_version: str,
        package_description: str,
    ) -> str:
        return f"""[build-system]
requires = ["setuptools>=70", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "{pypi_name}"
version = "{package_version}"
description = "{package_description}"
readme = "README.md"
requires-python = ">=3.10"
dependencies = []

[project.entry-points."cogniflow.steps"]
"{package_id}" = "{python_module}:steps.nq"

[tool.setuptools]
package-dir = {{"": "src"}}

[tool.setuptools.packages.find]
where = ["src"]

[tool.setuptools.package-data]
{python_module} = ["steps.nq", "cpp/*.cpp", "cpp/CMakeLists.txt"]
"""

    def _resolve_current_core_requirement(self) -> str:
        package_candidates = [
            "cogniflow-core",
            "cogniflow_core",
            "cf-ontology",
            "cogniflow-ontology",
        ]
        for package_name in package_candidates:
            try:
                version = importlib_metadata.version(package_name)
                if version:
                    return f">={version}"
            except importlib_metadata.PackageNotFoundError:
                continue
            except Exception:  # pylint: disable=broad-exception-caught
                continue
        return ">=0.0.0"

    def _render_readme(self, *, pypi_name: str, package_id: str, python_module: str) -> str:
        return f"""# {pypi_name}

Generated CogniFlow step-package scaffold.

- Package id: `{package_id}`
- Python module: `{python_module}`
- Manifest: `src/{python_module}/steps.nq`
- C++ source: `src/{python_module}/cpp/steps.cpp`

Install locally:

```bash
pip install .
```
"""

    def _render_init_py(self, *, package_id: str) -> str:
        return f"""\"\"\"Generated CogniFlow step package ({package_id}).\"\"\"

__all__ = ["steps"]
"""

    def _render_cpp_cmakelists(self, python_module: str) -> str:
        return f"""cmake_minimum_required(VERSION 3.20)
project({python_module}_steps LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(${{PROJECT_NAME}} SHARED steps.cpp)
"""

    def _render_steps_cpp(self, steps: list[dict[str, Any]]) -> str:
        user_steps = [step for step in steps if step["name"] != "OperationStepDemo"]
        lines = [
            '#include <stdexcept>',
            "#include <string>",
            "#include <unordered_map>",
            "",
            "namespace generated {",
            "",
            "double operation_step_demo(",
            "    double a,",
            "    double b,",
            "    const std::string& operation_type) {",
            '  if (operation_type == "sum") return a + b;',
            '  if (operation_type == "multiplication") return a * b;',
            '  if (operation_type == "subtraction") return a - b;',
            '  if (operation_type == "division") {',
            "    if (b == 0.0) {",
            '      throw std::invalid_argument("division by zero");',
            "    }",
            "    return a / b;",
            "  }",
            '  throw std::invalid_argument("unknown operation_type");',
            "}",
            "",
        ]
        for step in user_steps:
            func = _cpp_identifier(step["name"])
            lines.extend(
                [
                    f"double {func}_stub(",
                    "    const std::unordered_map<std::string, double>& inputs,",
                    "    const std::unordered_map<std::string, std::string>& parameters) {",
                    "  // Add code here.",
                    "  // Example input access:",
                    f'  // const double value = inputs.at("{self._first_port_name(step)}");',
                    "  // Example parameter access:",
                    f'  // const std::string mode = parameters.at("{self._first_param_name(step)}");',
                    "  (void)inputs;",
                    "  (void)parameters;",
                    "  return 0.0;",
                    "}",
                    "",
                ]
            )
        lines.append("}  // namespace generated")
        lines.append("")
        return "\n".join(lines)

    def _first_port_name(self, step: dict[str, Any]) -> str:
        ports = step.get("inputs", [])
        if isinstance(ports, list) and ports:
            first = ports[0]
            if isinstance(first, dict):
                value = str(first.get("name", "")).strip()
                if value:
                    return value
        return "input_1"

    def _first_param_name(self, step: dict[str, Any]) -> str:
        parameters = step.get("parameters", [])
        if isinstance(parameters, list) and parameters:
            first = parameters[0]
            if isinstance(first, dict):
                value = str(first.get("name", "")).strip()
                if value:
                    return value
        return "parameter_1"

    def _render_resources_readme(self, *, package_id: str) -> str:
        return f"""# Resources

This folder contains guidance for extending `{package_id}`.

- `operation_step_demo.md`: explains the built-in demo operation step.
- `extension_notes.md`: where and how to add custom step implementation logic.
"""

    def _render_demo_notes(self) -> str:
        return """# OperationStepDemo Notes

`OperationStepDemo` is intentionally implemented end-to-end in `cpp/steps.cpp`.

- Inputs: `a` and `b` (numeric)
- Output: `result` (numeric)
- Parameter: `operation_type` in `{sum, multiplication, subtraction, division}`

Use this function as the reference implementation style for new steps.
"""

    def _render_extension_notes(self, *, steps: list[dict[str, Any]]) -> str:
        user_steps = [step["name"] for step in steps if step["name"] != "OperationStepDemo"]
        bullet_lines = "\n".join(f"- `{name}` -> `{_cpp_identifier(name)}_stub`" for name in user_steps)
        if not bullet_lines:
            bullet_lines = "- Add new steps in the UI and regenerate to create stubs."
        return f"""# Extension Notes

Generated stub functions:
{bullet_lines}

Workflow:
1. Update step metadata in `src/*/steps.nq`.
2. Implement logic in `src/*/cpp/steps.cpp` at each `Add code here` section.
3. Build/package as needed for your target runtime.
"""
