"""Pipeline persistence service wrapper."""

from __future__ import annotations

import copy
import json
from typing import Any, Dict, List, Optional
import duckdb
from rdflib import Dataset

from cf_ontology.rdf_document import canonical_json, load_rdf_document

from cf_web.services.manager_provider import get_ontology_manager


_RDF_AUTHORING_FORMAT = "json" + "-ld"


class PipelineService:
    """Delegate pipeline persistence operations to cf_ontology when available."""

    def __init__(self, manager: Optional[Any] = None) -> None:
        """Create a pipeline service with injected or shared ontology manager."""
        self._manager = manager if manager is not None else get_ontology_manager()

    @staticmethod
    def _read_id_ref(value: Any) -> Optional[str]:
        if isinstance(value, str):
            return value
        if isinstance(value, dict):
            raw_id = value.get("@id")
            if isinstance(raw_id, str):
                return raw_id
        return None

    @staticmethod
    def _normalize_expected_datatype(value: Any) -> Optional[str]:
        if not isinstance(value, str):
            return None
        text = value.strip()
        if not text:
            return None
        aliases = {
            "http://www.w3.org/2001/XMLSchema#string": "xsd:string",
            "http://www.w3.org/2001/XMLSchema#integer": "xsd:integer",
            "http://www.w3.org/2001/XMLSchema#double": "xsd:double",
            "http://www.w3.org/2001/XMLSchema#boolean": "xsd:boolean",
            "http://www.w3.org/1999/02/22-rdf-syntax-ns#JSON": "rdf:JSON",
        }
        return aliases.get(text, text)

    def _parameter_datatype_aliases(self) -> dict[str, str]:
        if not self._manager:
            return {}
        aliases: dict[str, str] = {}
        try:
            steps = self._manager.get_processing_steps_info_quads_bulk()
        except Exception:  # pylint: disable=broad-exception-caught
            return aliases
        for step in steps:
            if not isinstance(step, dict):
                continue
            params = step.get("cf:hasParameter")
            if not isinstance(params, list):
                continue
            for param in params:
                if not isinstance(param, dict):
                    continue
                expected = self._normalize_expected_datatype(
                    param.get("cf:valueType") or param.get("cf:valueTypeUri")
                )
                if not expected:
                    continue
                raw_aliases = [
                    param.get("@id"),
                    param.get("canonical_id"),
                    param.get("compact_id"),
                ]
                extra_aliases = param.get("aliases")
                if isinstance(extra_aliases, list):
                    raw_aliases.extend(extra_aliases)
                for alias in raw_aliases:
                    if isinstance(alias, str) and alias.strip():
                        aliases[alias] = expected
        return aliases

    def _coerce_binding_value(self, value: Any, expected_datatype: str) -> Any:
        if expected_datatype == "rdf:JSON":
            if isinstance(value, dict) and "@value" in value:
                typed = copy.deepcopy(value)
                typed["@type"] = "rdf:JSON"
                return typed
            if isinstance(value, (dict, list)):
                return {"@type": "rdf:JSON", "@value": json.dumps(value, separators=(",", ":"))}
            if isinstance(value, str):
                text = value.strip()
                if not text:
                    return value
                try:
                    parsed = json.loads(text)
                    return {
                        "@type": "rdf:JSON",
                        "@value": json.dumps(parsed, separators=(",", ":")),
                    }
                except json.JSONDecodeError:
                    return {"@type": "rdf:JSON", "@value": text}
            return {"@type": "rdf:JSON", "@value": json.dumps(value, separators=(",", ":"))}

        if expected_datatype == "xsd:boolean":
            if isinstance(value, bool):
                return value
            if isinstance(value, str):
                text = value.strip().lower()
                if text in {"true", "1"}:
                    return True
                if text in {"false", "0"}:
                    return False
            return value

        if expected_datatype == "xsd:integer":
            if isinstance(value, bool):
                return value
            if isinstance(value, int):
                return value
            if isinstance(value, str):
                text = value.strip()
                try:
                    return int(text, 10)
                except ValueError:
                    return value
            return value

        if expected_datatype == "xsd:double":
            if isinstance(value, bool):
                return value
            if isinstance(value, (int, float)):
                return float(value)
            if isinstance(value, str):
                text = value.strip()
                try:
                    return float(text)
                except ValueError:
                    return value
            return value

        return value

    def _normalize_pipeline_document(self, document: Dict[str, Any]) -> Dict[str, Any]:
        graph = document.get("@graph")
        if not isinstance(graph, list):
            return document

        param_types = self._parameter_datatype_aliases()
        if not param_types:
            return document

        normalized = copy.deepcopy(document)
        normalized_graph = normalized.get("@graph")
        if not isinstance(normalized_graph, list):
            return document

        for entry in normalized_graph:
            if not isinstance(entry, dict):
                continue
            raw_type = entry.get("@type")
            if raw_type != "cf:ParameterBinding" and not (
                isinstance(raw_type, list) and "cf:ParameterBinding" in raw_type
            ):
                continue
            bound_param_id = self._read_id_ref(entry.get("cf:bindsParameter"))
            if not bound_param_id:
                continue
            expected_datatype = param_types.get(bound_param_id)
            if not expected_datatype or "cf:value" not in entry:
                continue
            entry["cf:value"] = self._coerce_binding_value(entry.get("cf:value"), expected_datatype)
        return normalized

    def list_pipelines(self) -> List[Dict[str, Any]]:
        if not self._manager:
            return []
        db_path = self._manager.pipelines_db_path
        if not db_path.exists():
            return []

        con = duckdb.connect(str(db_path), read_only=True)
        try:
            rows = con.execute(
                """
                SELECT
                  p.pipeline_id,
                  p.current_rev,
                  p.updated_at,
                  pr.created_by,
                  pr.message
                FROM pipelines p
                LEFT JOIN pipeline_revisions pr
                  ON pr.pipeline_id = p.pipeline_id
                 AND pr.rev = p.current_rev
                ORDER BY p.pipeline_id
                """
            ).fetchall()
        finally:
            con.close()

        pipelines: List[Dict[str, Any]] = []
        for pipeline_id, current_rev, updated_at, created_by, message in rows:
            pipelines.append(
                {
                    "pipeline_id": str(pipeline_id),
                    "current_rev": int(current_rev or 0),
                    "updated_at": str(updated_at) if updated_at is not None else None,
                    "updated_by": created_by,
                    "message": message,
                }
            )
        return pipelines

    def get_pipeline(self, pipeline_id: str, rev: Optional[int] = None) -> Dict[str, Any]:
        """Load one pipeline document, optionally by explicit revision."""
        if not self._manager:
            raise RuntimeError("cf_ontology is not available")
        return self._manager.get_pipeline_revision(pipeline_id, rev=rev, flatten=True)

    def save_pipeline(
        self,
        pipeline_id: str,
        document: Dict[str, Any],
        *,
        user: Optional[str] = None,
        message: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Validate and commit a pipeline revision, returning commit metadata."""
        if not self._manager:
            raise RuntimeError("cf_ontology is not available")

        document = self._normalize_pipeline_document(document)

        validation = self._manager.validate_pipeline_document(document)
        rev = self._manager.commit_pipeline(
            pipeline_id=pipeline_id,
            document=document,
            user=user,
            message=message,
        )
        return {
            "pipeline_id": pipeline_id,
            "rev": int(rev),
            "conforms": bool(validation.get("conforms", False)),
            "report_text": str(validation.get("report_text", "")),
        }

    def validate_pipeline(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """Run SHACL pipeline validation and return normalized diagnostics."""
        if not self._manager:
            raise RuntimeError("cf_ontology is not available")
        document = self._normalize_pipeline_document(document)
        validation = self._manager.validate_pipeline_document(document)
        return {
            "conforms": bool(validation.get("conforms", False)),
            "report_text": str(validation.get("report_text", "")),
        }

    def parse_pipeline_document(self, document_text: str) -> Dict[str, Any]:
        """Parse a pipeline RDF document string into the canonical document shape."""
        return load_rdf_document(document_text, label="pipeline document")

    def serialize_pipeline_document(self, document: Dict[str, Any]) -> str:
        """Serialize a pipeline document into N-Quads text for file export."""
        dataset = Dataset()
        dataset.parse(data=canonical_json(document), format=_RDF_AUTHORING_FORMAT)
        payload = dataset.serialize(format="nquads")
        if isinstance(payload, bytes):
            return payload.decode("utf-8")
        return str(payload)
