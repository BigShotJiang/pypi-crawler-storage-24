---
name: skill-dominate
created: 2026-03-04 18:37:24
status: DONE
attach-change: .sspec/changes/archive/26-03-04T19-07_skill-dominate/spec.md
tldr: dominate 现已同步写入 skill_install_strategies，并在 spoke 父目录维护 skills ignore。
archived: '2026-03-04T19:28:42'
---
<!-- @RULE: Frontmatter Type
status: OPEN | DOING | DONE | CLOSED;
tldr: One-sentence summary for list views — fill this!
 -->

# Request: skill-dominate

## Problem
<!-- What is not working or missing -->

```powershell

H:\SrcCode\playground\sspec\tmp\test_new                                                                                                         main  👾  (sspec)
❯❯❯ sspec skill dominate .claude
[OK] Linked: .claude\skills -> .sspec\skills
  Link: junction
```

测试之后发现不对：

- .meta.json 没有更新 skill_install_strategies
- .claude 中的 .gitignore 不对
  - 预期应该是：在 .claude 中填充 skills 的 ignore
  - 实际：.claude/skills 中创建了 .gitignore 并填写了和 .sspec/skills 中一样的内容
  - 为什么这是错误的：.claude/skills 仅仅只是 spoke，没有必要加入track，一切以 .sspec 为准

## Initial Direction
<!-- Your rough idea or preferred direction — details are fine but not required.
This becomes the starting point for the change's spec.md Section A/B. -->

## Relational Context
<!-- Constraints, preferences, related filelinks -->
src\sspec\commands\skill.py
src\sspec\services\skill_service.py
src\sspec\services\project_init_service.py
---

## @AGENT
<!-- What should Agent do to implement this request -->
Adhere to the SSPEC protocol specifications and commence development from the current Request file, following the SSPEC/Development Lifecycle.
Next step: Read `sspec-research` SKILL + `sspec-design` SKILLs + `sspec change new --from <this>`.
