# apply_patch --prompt 与 SKILL.md 审查意见

## 修改方案

### 文件 1: `src/sspec/builtin_tools/apply_patch.py` — PATCH_PROMPT

**目标**：精简为纯格式规范 + 核心规则，移除 CLI 教程和最佳实践。

```patch
# src/sspec/builtin_tools/apply_patch.py
<<<<<<< SEARCH
PATCH_PROMPT = """# patch - SEARCH/REPLACE file editing helper

`sspec tool patch` is a helper for editing existing files with structured SEARCH/REPLACE patch blocks.

## Patch Format

### Single Patch Block

- Header: `# <path>` or `# <path>:<range>`
- Range syntax: `L10-L25`, `L10-`, `-L25`
- Paths: relative paths resolve from project root / cwd; absolute paths are also allowed
- Absolute paths outside the current workspace require confirmation, or `--unsafe` to bypass

```patch
# src/utils.py:L10-L25
<<<<<<< SEARCH
return x * 2
=======
return x * 3
>>>>>>> REPLACE
```

Example with an absolute path that contains spaces:

```patch
# C:\\My Project\\docs\\my file.md:L3-
<<<<<<< SEARCH
old text
=======
new text
>>>>>>> REPLACE
```

### Multiple Patch Blocks

- Multiple patch blocks can be combined in one input
- You may insert arbitrary explanation text between patch blocks
- Each patch block only needs to keep its own format valid

## Apply Patch via CLI

### Basic command

```bash
sspec tool patch [OPTIONS]
```

### Input methods

1. `--stdin` - recommended for agents
2. `PATCH_FILE` or `--file PATCH_FILE`
3. `--input` - interactive input

### Safety flag

- `--unsafe` bypasses the outside-workspace absolute path confirmation

### `--stdin` example (bash)

```bash
cat <<'EOF' | sspec tool patch --stdin --yes
# src/utils.py
<<<<<<< SEARCH
return x * 2
=======
return x * 3
>>>>>>> REPLACE
EOF
```

### `--stdin` example (powershell)

```powershell
@'
# src/utils.py
<<<<<<< SEARCH
return x * 2
=======
return x * 3
>>>>>>> REPLACE
'@ | sspec tool patch --stdin --yes
```

## Important Rules

1. SEARCH must match exactly first; loose fallback ignores trailing whitespace and blank-line-only differences
2. If SEARCH matches multiple locations, add a narrower line range
3. Use just-enough context: for a single-line change, usually include about 1-2 surrounding lines; for multi-line changes, include only the extra context needed to make the match unique
4. Avoid SEARCH blocks that are too short to match reliably, or so large that they waste tokens and become brittle
5. Target files must already exist
6. Relative paths must stay under the detected project root / current working directory; absolute paths are allowed
7. If SEARCH is missing but REPLACE exists uniquely in scope, the patch is treated as already applied
8. Failed patch output may contain explanation text outside fenced `patch` blocks; those fenced blocks remain directly reusable as later patch input
9. Absolute paths outside the current workspace require explicit confirmation unless `--unsafe` is provided
"""
=======
PATCH_PROMPT = """# patch — SEARCH/REPLACE Format Specification

## Block Structure

Each patch block consists of three parts:

1. **Header line**: `# <path>` or `# <path>:<range>`
2. **SEARCH section**: content to find (between `<<<<<<< SEARCH` and `=======`)
3. **REPLACE section**: replacement content (between `=======` and `>>>>>>> REPLACE`)

```text
# <path>[:<range>]
<<<<<<< SEARCH
old content
=======
new content
>>>>>>> REPLACE
```

## Header Syntax

**Path**: relative (resolved from project root / cwd) or absolute.

**Line range** (optional, narrows search scope):
- `L10-L25` — lines 10 to 25
- `L10-` — line 10 to end of file
- `-L25` — start of file to line 25

Examples:

```text
# src/utils.py
# src/utils.py:L10-L25
# C:\\My Project\\docs\\my file.md:L3-
```

## Multiple Blocks

Multiple blocks can appear in one input. Arbitrary text between blocks is ignored — each block only needs its own structure to be valid.

## Marker Rules

The three markers must each appear alone on their own line, with no extra characters:
- `<<<<<<< SEARCH`
- `=======`
- `>>>>>>> REPLACE`

## Matching Behavior

1. **Exact match first**: content and whitespace must match perfectly
2. **Loose fallback**: ignores trailing spaces/tabs and blank-line-only differences
3. **Unique match required**: multiple matches → patch fails; add a line range to disambiguate
4. **Already applied**: if SEARCH is absent but REPLACE exists uniquely in scope, status is `already_applied` (not an error)

## Path and Safety Rules

- Target files must already exist
- Relative paths must stay within the project root / cwd
- Absolute paths are allowed; those outside the workspace require confirmation or `--unsafe`
- SEARCH content must not be empty

## CLI Quick Reference

```text
sspec tool patch [PATCH_FILE] [--file PATH] [--stdin] [--input]
                 [--dry-run] [--yes] [--unsafe] [--output-failed PATH]
                 [--prompt] [--help]
```

Use `--help` for full option descriptions.
"""
>>>>>>> REPLACE
```

---

### 文件 2: `src/sspec/templates/skills/write-patch/SKILL.md`

**目标**：移除与 `--prompt` 重复的格式定义和规则列表，聚焦工作流、最佳实践和失败恢复。

```patch
# src/sspec/templates/skills/write-patch/SKILL.md
<<<<<<< SEARCH
---
name: write-patch
description: Use patch files + `sspec tool patch` for code modifications instead of direct file edits. Trigger when user requests patch-based workflow.
metadata:
  author: frostime
  version: 1.0.0
---

# Write-Patch Skill

## Workflow

1. Write one or more SEARCH/REPLACE patch blocks
2. Apply with one of:
   - `sspec tool patch PATCH_FILE`
   - `sspec tool patch --file PATCH_FILE`
   - `sspec tool patch --stdin --yes`
3. Verify output, especially `already_applied`, ambiguity, and failed bundle messages
4. If patch application fails, refine the failed markdown bundle and apply it again

### Example Session

```
Agent: I'll create a patch file for these changes.

# fix-imports.patch.md
# src/utils.py
<<<<<<< SEARCH
from typing import List
=======
from typing import List, Dict
>>>>>>> REPLACE

# src/config.py
<<<<<<< SEARCH
DEBUG = True
=======
DEBUG = False
>>>>>>> REPLACE

Agent: Apply with: `sspec tool patch fix-imports.patch.md`
```

### Example via stdin

```bash
cat <<'EOF' | sspec tool patch --stdin --yes
# src/utils.py
<<<<<<< SEARCH
from typing import List
=======
from typing import List, Dict
>>>>>>> REPLACE
EOF
```

## Patch Format

Each patch block consists of:

1. **File path line** (required, precedes SEARCH marker)
2. **SEARCH/REPLACE block** (markers must be alone on their line)

### Simple Patch (No Line Range)

```text
# path/to/file.py
<<<<<<< SEARCH
old_code_here()
=======
new_code_here()
>>>>>>> REPLACE
```

### With Line Range (Reduce Ambiguity)

```text
# src/utils.py:L10-L25
<<<<<<< SEARCH
old_code_here()
=======
new_code_here()
>>>>>>> REPLACE
```

Preferred line range formats:
- `:L10-L25`
- `:L10-`
- `:-L25`

Legacy `:10-25` is still accepted, but do not use it as the default style.

### Multiple Patch Blocks

Multiple patch blocks can be combined in one file or stdin payload.

You may insert explanation text between patch blocks. Each patch block only needs to keep its own format valid.

```text
Notes for the next patch block.

# server.py:L10-L20
<<<<<<< SEARCH
PORT = 8080
=======
PORT = 3000
>>>>>>> REPLACE

This second patch updates logging.

# server.py:L45-L60
<<<<<<< SEARCH
log.info("Starting")
=======
log.info("Server starting on port %d", PORT)
>>>>>>> REPLACE
```

## Critical Rules

1. **Exact Match Required**: SEARCH content must match file exactly (including indentation)
2. **Unique Match**: If SEARCH matches multiple locations → patch fails (use line range)
3. **Non-Empty SEARCH**: Empty SEARCH blocks are rejected (avoid accidental changes)
4. **Path Resolution**: Relative paths resolve from workspace root; absolute paths are allowed
5. **Outside-Workspace Safety**: Absolute paths outside the current workspace require explicit confirmation, or `--unsafe` for automation
6. **Target Files Must Exist**: `sspec tool patch` edits existing files only
7. **Already Applied Is Not Fatal**: If SEARCH is missing but REPLACE exists uniquely in scope, status becomes `already_applied`
8. **Marker Precision**: Markers `<<<<<<< SEARCH`, `=======`, `>>>>>>> REPLACE` must be alone on their line

## Common Patterns

### Adding Code

```text
# src/app.py
<<<<<<< SEARCH
def main():
    setup()
    return 0
=======
def main():
    setup()
    init_logging()    # Added
    return 0
>>>>>>> REPLACE
```

### Removing Code

```text
# config.py
<<<<<<< SEARCH
DEBUG = True
VERBOSE = True
=======
DEBUG = True
>>>>>>> REPLACE
```

### Multiple Changes in One File

Create separate SEARCH/REPLACE blocks:

```text
# server.py:L10-L20
<<<<<<< SEARCH
PORT = 8080
=======
PORT = 3000
>>>>>>> REPLACE

# server.py:L45-L60
<<<<<<< SEARCH
log.info("Starting")
=======
log.info("Server starting on port %d", PORT)
>>>>>>> REPLACE
```

## Matching Behavior

1. **Exact match** (preferred): Whitespace and content match perfectly
2. **Loose match** (fallback): Ignores trailing spaces/tabs, collapses blank lines
3. **Already applied**: SEARCH missing + REPLACE uniquely present → `already_applied`
4. **If multiple matches found**: Patch fails → add line range

## Best Practices

### Use Just-Enough Context

Write the smallest patch that is still precise and stable.

- For a **single-line replacement**, usually include about 1-2 surrounding context lines before and after
- For a **multi-line replacement**, include the changed block and only the extra context needed to make the match unique
- Avoid overly short SEARCH blocks that mismatch easily
- Avoid overly large SEARCH blocks that waste tokens and become brittle

Goal: precise enough to avoid mismatch, small enough to avoid unnecessary token cost

### Include Context Lines

**Bad** (too short, ambiguous):
```text
<<<<<<< SEARCH
return x
=======
return x * 2
>>>>>>> REPLACE
```

**Good** (sufficient context):
```text
<<<<<<< SEARCH
def compute(x):
    result = validate(x)
    return x
=======
def compute(x):
    result = validate(x)
    return x * 2
>>>>>>> REPLACE
```

### Use Line Ranges for Ambiguous Searches

When the same code pattern appears multiple times:
```text
# utils.py:L42-L50
<<<<<<< SEARCH
if value is None:
    return default
=======
if value is None:
    raise ValueError("Value required")
>>>>>>> REPLACE
```

### Preserve Indentation

Match the file's indentation style exactly:
```text
# main.py
<<<<<<< SEARCH
    def process(self):
        data = self.load()
        return data
=======
    def process(self):
        data = self.load()
        validated = self.validate(data)
        return validated
>>>>>>> REPLACE
```

## Anti-Patterns

❌ **Don't use placeholders or ellipsis**:
```text
# BAD
<<<<<<< SEARCH
def foo():
    ... existing code ...
    return result
=======
```

✅ **Include actual code**:
```text
# GOOD
<<<<<<< SEARCH
def foo():
    x = compute()
    y = transform(x)
    return result
=======
```

❌ **Don't mix line endings** (if file uses `\r\n`, SEARCH should too)

## Failure Recovery

- Failed patches are saved into one markdown bundle
- The bundle may contain explanation text outside fenced `patch` blocks
- Those fenced `patch` blocks remain directly reusable as future patch input
- If a patch reports `already_applied`, usually do not regenerate it unless the target is wrong

## Tool Options

```bash
sspec tool patch [PATCH_FILE] [OPTIONS]

--dry-run              # Preview without applying
--stdin                # Read patch text from stdin
--yes                  # Skip confirmation
--unsafe               # Bypass outside-workspace absolute path confirmation
--output-failed PATH   # Custom markdown file or directory for failed patches
--file, -f PATH        # Read patch text from file (alternative to positional PATCH_FILE)
--input, -i            # Enter patch text interactively
--prompt               # Show format specification
```

## See Also

- `sspec tool patch --prompt` — Full specification
- `sspec tool patch --help` — Command options
=======
---
name: write-patch
description: Use patch files + `sspec tool patch` for code modifications instead of direct file edits. Trigger when user requests patch-based workflow.
metadata:
  author: frostime
  version: 1.1.0
---

# Write-Patch Skill

> Format reference: `sspec tool patch --prompt`

## Workflow

1. Write one or more SEARCH/REPLACE patch blocks
2. Apply with one of:
   - `sspec tool patch PATCH_FILE`
   - `sspec tool patch --file PATCH_FILE`
   - `sspec tool patch --stdin --yes`
3. Verify output — watch for `already_applied`, ambiguity warnings, and failed bundle messages
4. If patch application fails, refine the failed markdown bundle and apply it again

### Example Session

```
Agent: I'll create a patch file for these changes.

# fix-imports.patch.md
# src/utils.py
<<<<<<< SEARCH
from typing import List
=======
from typing import List, Dict
>>>>>>> REPLACE

# src/config.py
<<<<<<< SEARCH
DEBUG = True
=======
DEBUG = False
>>>>>>> REPLACE

Agent: Apply with: `sspec tool patch fix-imports.patch.md`
```

### Example via stdin

```bash
cat <<'EOF' | sspec tool patch --stdin --yes
# src/utils.py
<<<<<<< SEARCH
from typing import List
=======
from typing import List, Dict
>>>>>>> REPLACE
EOF
```

## Quick Format Reference

```text
# <path>[:<range>]
<<<<<<< SEARCH
old content
=======
new content
>>>>>>> REPLACE
```

Line range examples: `:L10-L25`, `:L10-`, `:-L25`. Multiple blocks and interleaved text are allowed.

For full format specification (markers, matching behavior, path rules), run `sspec tool patch --prompt`.

## Common Patterns

### Adding Code

```text
# src/app.py
<<<<<<< SEARCH
def main():
    setup()
    return 0
=======
def main():
    setup()
    init_logging()    # Added
    return 0
>>>>>>> REPLACE
```

### Removing Code

```text
# config.py
<<<<<<< SEARCH
DEBUG = True
VERBOSE = True
=======
DEBUG = True
>>>>>>> REPLACE
```

### Multiple Changes in One File

Use separate blocks with line ranges to avoid ambiguity:

```text
# server.py:L10-L20
<<<<<<< SEARCH
PORT = 8080
=======
PORT = 3000
>>>>>>> REPLACE

# server.py:L45-L60
<<<<<<< SEARCH
log.info("Starting")
=======
log.info("Server starting on port %d", PORT)
>>>>>>> REPLACE
```

## Best Practices

### Size Your SEARCH Block Right

Write the smallest patch that matches uniquely.

- **Single-line change**: include ~1–2 surrounding context lines
- **Multi-line change**: include only the extra context needed for a unique match
- Too short → ambiguous match or false positive
- Too large → wastes tokens and breaks when unrelated lines change

### Include Context Lines

**Bad** (too short, ambiguous):
```text
<<<<<<< SEARCH
return x
=======
return x * 2
>>>>>>> REPLACE
```

**Good** (sufficient context):
```text
<<<<<<< SEARCH
def compute(x):
    result = validate(x)
    return x
=======
def compute(x):
    result = validate(x)
    return x * 2
>>>>>>> REPLACE
```

### Use Line Ranges for Repeated Patterns

When the same code pattern appears multiple times:
```text
# utils.py:L42-L50
<<<<<<< SEARCH
if value is None:
    return default
=======
if value is None:
    raise ValueError("Value required")
>>>>>>> REPLACE
```

### Preserve Indentation Exactly

```text
# main.py
<<<<<<< SEARCH
    def process(self):
        data = self.load()
        return data
=======
    def process(self):
        data = self.load()
        validated = self.validate(data)
        return validated
>>>>>>> REPLACE
```

## Anti-Patterns

❌ **Placeholders or ellipsis** — SEARCH must contain actual file content:
```text
# BAD
<<<<<<< SEARCH
def foo():
    ... existing code ...
    return result
```

❌ **Mixed line endings** — if the file uses `\r\n`, SEARCH content should match

## Failure Recovery

- Failed patches are saved into one markdown bundle
- Fenced `patch` blocks in the bundle are directly reusable as future patch input
- `already_applied` status usually means the change is already in place — do not regenerate unless the target is wrong
>>>>>>> REPLACE
```

---

## 变更摘要

### PATCH_PROMPT（`--prompt`）

| 变更 | 理由 |
|------|------|
| 移除 bash/PowerShell heredoc 示例 | CLI 教程不属于格式规范；`--help` 已覆盖 |
| 移除"Use just-enough context"和"Avoid too short/large"规则 | 最佳实践，归 SKILL.md 管 |
| 移除"Failed patch output…reusable"规则 | 实现行为细节，归 SKILL.md 的 Failure Recovery |
| 合并匹配行为为独立小节 | 原来散落在 Rules 中，集中后更清晰 |
| CLI 选项压缩为一行速查 | 避免维护两份 CLI 文档 |

### SKILL.md

| 变更 | 理由 |
|------|------|
| 删除完整的 Patch Format 节（~40 行） | 与 `--prompt` 完全重复，替换为 Quick Reference + 指向 `--prompt` |
| 删除 Critical Rules 节（8 条） | 与 `--prompt` 的规则列表重复 |
| 删除 Matching Behavior 节（4 条） | 同上 |
| 删除 Tool Options 节 | `--help` 已覆盖 |
| 删除 See Also 节 | 已在 Quick Reference 中引用 `--prompt` |
| 保留并微调 Best Practices、Anti-Patterns、Common Patterns、Failure Recovery | 这些是 SKILL.md 的核心价值 |
| 版本号 1.0.0 → 1.1.0 | 反映结构性变更 |

### 预期效果

- **PATCH_PROMPT**：~900 词 → ~350 词（-60%）
- **SKILL.md**：~700 词 → ~400 词（-43%）
- **合计去重**：~1600 词 → ~750 词，消除了几乎所有重复内容
- 两份文档职责明确：PROMPT = 权威格式规范，SKILL = 工作流与最佳实践
