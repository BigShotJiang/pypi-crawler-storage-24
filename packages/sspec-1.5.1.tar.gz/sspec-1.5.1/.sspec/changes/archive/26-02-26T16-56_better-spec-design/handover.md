# Handover: better-spec-design

**Updated**: 2026-02-26

---

## Background

Upgraded `sspec-design` SKILL to produce spec designs that are graspable, auditable, and implementation-ready. Root cause: the SKILL described *what elements* belong in Section B but not *how* to express them, so models defaulted to prose. Added four Presentation Rules (code blocks, ASCII diagrams, Scope Summary Table, labeled items) and restructured the SKILL to clearly separate Single Change (Step 3) from Root Change (Step 4) guidance. Split `examples.md` into `examples-single.md` and `examples-root.md`.

## This Session

### Accomplished

- Analyzed two real specs from `sy-f-misc` to identify the quality gap (prose vs. code-block + diagram + table)
- Created change `26-02-26T16-56_better-spec-design` from request
- Conducted two `@ask` design alignment rounds, incorporating feedback (generalize Rule 4 beyond bug-fixes, improve Rule 2 example, separate root from single, use sspec-domain examples, split examples.md)
- **SKILL.md** (`src/sspec/templates/skills/sspec-design/SKILL.md`): v3.1.0 → v3.2.0
  - Added Presentation Rules 1–4 subsection in Step 3
  - Renamed Step 3 → "Fill Single Change spec.md"
  - Added Step 4 "Fill Root Change spec.md" with phase-level diagram guidance and Rule adaptations
  - Updated References table to point to split files
- **examples-single.md** (new): Simple + Medium (sspec-domain `change-tags` scenario, all 4 Rules) + Complex + B→tasks boundary
- **examples-root.md** (new): 3-phase linear example + 4-phase branching with dependency table + sub-change B guidance
- **`change/spec.md`**: Strengthened Key Design comment with Rules 1–4
- **`change-root/spec.md`**: Strengthened Phase Overview comment with dependency tree/table guidance
- **`examples.md`**: Deleted (replaced by split files)
- Reinstalled (`uv pip install -e .`); verified split files present in template dir

### Next Steps

1. **Review the changes** — read through the updated SKILL.md (Step 3 + Step 4) and the two new example files to confirm quality
2. If satisfied → mark change DONE and archive: `sspec change archive .sspec/changes/archive/26-02-26T16-56_better-spec-design`
3. If feedback → open a Feedback Tasks section in tasks.md

## Working Memory

### Key Files

- `src/sspec/templates/skills/sspec-design/SKILL.md` — main file changed; Steps 3 + 4 now separate; Rules 1–4 with code examples
- `src/sspec/templates/skills/sspec-design/examples-single.md` — NEW; 4 Presentation Rules demonstrated in Medium Example (change-tags domain scenario)
- `src/sspec/templates/skills/sspec-design/examples-root.md` — NEW; two root examples (3-phase linear and 4-phase branching with dependency table)
- `src/sspec/templates/change/spec.md` — Key Design comment updated
- `src/sspec/templates/change-root/spec.md` — Phase Overview comment updated

### Decisions

- **Rule 4 generalized to any item type (not just fixes)**: User feedback — labeling Feat B / Refactor C is equally useful
- **sspec-domain examples**: User feedback — don't use LLM adapter code; use sspec internals (change-tags scenario chosen for medium example)
- **examples.md split**: User feedback — separate single-change and root-change into two files for clarity
- **AGENTS.md not changed**: Checked — only references SKILL by name, no line-level references to examples that would break

### Notes

- Pre-existing ruff lint errors in `pack_zip.py`, `change_service.py`, `cmd_service.py`, `request_service.py` — unrelated to this change, not introduced here
- Content safety filter triggered during session (false positive on code examples with ❌/✅ symbols) — no action needed, content is fine
- Root change Step 4 in SKILL.md explicitly states what does NOT go in root spec (file-level detail → sub-change)

