# -*- coding: utf-8 -*-
"""
Continuously take an optical density reading (more accurately: a turbidity reading, which is a proxy for OD).

Internally, the ODReader runs a function every `interval` seconds. The function
 1. turns off all non-IR LEDs
 2. turns on the IR LED
 3. calls ADCReader to read channels from the ADC.
 4. Performs any transformations (see below)
 5. Switches back LEDs to previous state from step 1.
 6. Publishes data to MQTT

Dataflow of raw signal to final output:

```mermaid
flowchart LR
    %% Top-level container
    subgraph OD["ODReader"]
        direction LR

        %% ADCReader block
        subgraph ADC["ADCReader"]
            direction LR

            A["Samples from ADC"]
            B["ADC offset removed"]
            C["Sin regression"]

            A --> B --> C
        end

        %% IR LED Reference Tracker
        subgraph IR["IrLedReferenceTracker"]
            direction LR

            D["IR output compensation"]
        end

        %% Calibration Transformer
        subgraph CAL["CalibrationTransformer"]
            direction LR

            E["Transform via calibration curve
(or no-op)"]
        end

        %% Estimator Transformer Protocol
        subgraph EST["EstimatorTransformerProtocol"]
            direction LR

            F["Fuse signals via estimator
(or no-op)"]
        end

        %% Cross-module connections
        C --> D
        D --> E
        D --> F
    end
```


In the ODReader class, we publish the `first_od_obs_time` to MQTT so other jobs can read it and
make decisions. For example, if a bubbler/visible light LED is active, it should time itself
s.t. it is _not_ running when an turbidity measurement is about to occur. See BackgroundJobWithDodging class.

"""
import math
import os
import random
import threading
import types
from collections.abc import Mapping
from time import sleep
from time import time
from typing import Callable
from typing import cast
from typing import Optional
from typing import Protocol

import click
import pioreactor.actions.led_intensity as led_utils
from pioreactor import error_codes
from pioreactor import exc
from pioreactor import hardware
from pioreactor import structs
from pioreactor import types as pt
from pioreactor import whoami
from pioreactor.background_jobs.base import BackgroundJob
from pioreactor.background_jobs.base import LoggerMixin
from pioreactor.config import config
from pioreactor.logging import create_logger
from pioreactor.pubsub import publish
from pioreactor.states import JobState as st
from pioreactor.utils import adcs as madcs
from pioreactor.utils import argextrema
from pioreactor.utils import local_intermittent_storage
from pioreactor.utils import local_persistent_storage
from pioreactor.utils import timing
from pioreactor.utils.math_helpers import mean
from pioreactor.utils.od_fusion import compute_fused_od
from pioreactor.utils.streaming_calculations import ExponentialMovingAverage
from pioreactor.utils.streaming_calculations import ExponentialMovingStd
from pioreactor.utils.timing import catchtime

VALID_PD_ANGLES: list[pt.PdAngle] = ["45", "90", "135", "180"]
PdChannelToVoltage = dict[pt.PdChannel, pt.Voltage]

REF_keyword = "REF"
IR_keyword = "IR"

RawPDReadings = dict[pt.PdChannel, structs.RawPDReading]


def average_over_raw_pd_readings(*multiple_raw_pd_readings: RawPDReadings) -> RawPDReadings:
    summed_pd_channel_to_voltage: PdChannelToVoltage = {}
    counts_by_channel: dict[pt.PdChannel, int] = {}

    for raw_pd_readings in multiple_raw_pd_readings:
        for pd_channel, raw_od_reading in raw_pd_readings.items():
            summed_pd_channel_to_voltage[pd_channel] = (
                summed_pd_channel_to_voltage.get(pd_channel, 0) + raw_od_reading.reading
            )
            counts_by_channel[pd_channel] = counts_by_channel.get(pd_channel, 0) + 1

    return {
        pd_channel: structs.RawPDReading(reading=voltage / counts_by_channel[pd_channel], channel=pd_channel)
        for pd_channel, voltage in summed_pd_channel_to_voltage.items()
    }


def average_over_od_readings(*multiple_od_readings: structs.ODReadings) -> structs.ODReadings:
    if not multiple_od_readings:
        raise ValueError("No OD readings provided.")

    summed_pd_channel_to_od: dict[pt.PdChannel, float] = {}
    counts_by_channel: dict[pt.PdChannel, int] = {}
    reference_reading = multiple_od_readings[0]

    for od_readings in multiple_od_readings:
        for pd_channel, od_reading in od_readings.ods.items():
            summed_pd_channel_to_od[pd_channel] = summed_pd_channel_to_od.get(pd_channel, 0.0) + od_reading.od
            counts_by_channel[pd_channel] = counts_by_channel.get(pd_channel, 0) + 1

    timestamp = timing.current_utc_datetime()
    return structs.ODReadings(
        timestamp=timestamp,
        ods={
            pd_channel: structs.RawODReading(
                timestamp=timestamp,
                angle=reference_reading.ods[pd_channel].angle,
                od=od_value / counts_by_channel[pd_channel],
                channel=pd_channel,
                ir_led_intensity=reference_reading.ods[pd_channel].ir_led_intensity,
            )
            for pd_channel, od_value in summed_pd_channel_to_od.items()
        },
    )


class ADCReader(LoggerMixin):
    """


    Example
    --------

    from pioreactor.background_jobs.od_reading import ADCReader

    adc = ADCReader(["1", "2"], fake_data=False)
    adc.tune_adc_with_ir_on()

    while True:
        print(adc.take_reading())


    """

    _logger_name = "adc_reader"

    def __init__(
        self,
        channels: list[pt.PdChannel],
        fake_data: bool = False,
        dynamic_gain: bool = True,
        penalizer: float = 0.0,  # smoothing parameter between samples
        oversampling_count: int = 40,
    ) -> None:
        super().__init__()
        self.fake_data = fake_data
        self.dynamic_gain = dynamic_gain
        self.channels: list[pt.PdChannel] = channels
        self.adc_offsets: dict[pt.PdChannel, float] = {}
        self.penalizer = penalizer
        self.oversampling_count = oversampling_count
        self.batched_readings: RawPDReadings = {}
        self.max_signal_moving_average = {c: ExponentialMovingAverage(alpha=0.05) for c in self.channels}

        self.adcs = self._get_ADCs()

        if "local_ac_hz" in config["od_reading.config"]:
            self.most_appropriate_AC_hz: Optional[float] = config.getfloat("od_reading.config", "local_ac_hz")
        else:
            self.most_appropriate_AC_hz = None

    def _get_ADCs(self) -> dict[pt.PdChannel, madcs._I2C_ADC]:
        if self.fake_data or whoami.is_testing_env():
            from pioreactor.utils.mock import Mock_ADC

            return {c: Mock_ADC(adc_channel=int(c), i2c_addr=0x00) for c in self.channels}
        else:
            adcs: dict[pt.PdChannel, madcs._I2C_ADC] = {}
            for c in self.channels:
                try:
                    curried = hardware.get_available_pd_channels()[c]
                except KeyError as e:
                    # Configuration is missing an ADC mapping for this channel
                    self.logger.error(f"No ADC configuration found for channel pd{c}.")
                    raise exc.HardwareNotFoundError(f"ADC for pd{c} is not configured.") from e

                try:
                    adcs[c] = curried()
                except (OSError, exc.HardwareError) as e:
                    self.logger.error(
                        f"Failed to initialize ADC for pd{c}. Check device {curried.adc_driver} on i2c channel 0x{curried.i2c_address:02x}."
                    )
                    raise exc.HardwareNotFoundError(
                        f"Failed to initialize ADC for pd{c}. Check device {curried.adc_driver} on i2c channel 0x{curried.i2c_address:02x}."
                    ) from e
                except Exception as e:
                    self.logger.error(f"Unexpected error initializing ADC for pd{c}.")
                    raise exc.HardwareNotFoundError(
                        f"Unexpected error initializing ADC for pd{c}: {type(e).__name__}: {e}"
                    ) from e

            return adcs

    def tune_adc_with_ir_on(self) -> RawPDReadings:
        """
        This configures the ADC for reading, performs an initial read, and sets variables based on that reading.

        This method should be called with the IR LED on for OD workflows, since gain selection depends
        on observed signal level. See ODReader for an example.

        """

        # reset gain
        for adc in self.adcs.values():
            adc.set_ads_gain(1.0)

        SAMPLES = 10

        batched_readings = {}

        # we pre-allocate these arrays to make the for loop faster => more accurate
        aggregated_signals: dict[pt.PdChannel, list[pt.AnalogValue]] = {
            channel: [0.0] * SAMPLES for channel in self.channels
        }
        timestamps: dict[pt.PdChannel, list[float]] = {channel: [0.0] * SAMPLES for channel in self.channels}

        with catchtime() as time_since_start:
            for counter in range(SAMPLES):
                with catchtime() as time_sampling_took_to_run:
                    for pd_channel in self.channels:
                        timestamps[pd_channel][counter] = time_since_start()
                        aggregated_signals[pd_channel][counter] = self.adcs[pd_channel].read_from_channel()

                sleep(
                    max(
                        0,
                        -time_sampling_took_to_run()  # the time_sampling_took_to_run() reduces the variance by accounting for the duration of each sampling.
                        + 0.25
                        / (SAMPLES - 1)
                        * (
                            (counter * 0.618034) % 1
                        ),  # this is to artificially jitter the samples, so that we observe less aliasing. That constant is phi.
                    )
                )

        if os.environ.get("DEBUG") is not None:
            self.logger.debug(f"TUNE STEP: {timestamps=}")
            self.logger.debug(f"TUNE STEP: {aggregated_signals=}")

        for channel in self.channels:
            if self.most_appropriate_AC_hz is None and not self._is_ads1114_channel(channel):
                self.most_appropriate_AC_hz = self.determine_most_appropriate_AC_hz(
                    timestamps, aggregated_signals
                )

            avg_reading_voltage = self.adcs[channel].from_raw_to_voltage(mean(aggregated_signals[channel]))

            self._check_if_over_max(avg_reading_voltage)

            if self.dynamic_gain:
                self.adcs[channel].check_on_gain(avg_reading_voltage)

            batched_readings[channel] = structs.RawPDReading(reading=avg_reading_voltage, channel=channel)

        for channel, adc in self.adcs.items():
            self.logger.debug(
                f"Setting ADC class {adc.__class__.__name__} for pd{channel} with initial gain {adc.gain}."
            )

        return batched_readings

    def set_offsets(self, batched_readings: RawPDReadings) -> None:
        """
        With the IR LED off, determine the dark offsets. These offsets are used later to shift the raw signals such that "dark" is 0.
        """

        if config.getboolean("od_reading.config", "use_dark_offsets", fallback="true"):
            for channel, blank_reading in batched_readings.items():
                self.adc_offsets[channel] = self.adcs[channel].from_voltage_to_raw_precise(
                    blank_reading.reading
                )
        else:
            for channel, _ in batched_readings.items():
                self.adc_offsets[channel] = 0.0

        self.logger.debug(
            f"ADC offsets: {self.adc_offsets}, and in voltage: { {c: self.adcs[c].from_raw_to_voltage(i) for c, i in self.adc_offsets.items()} }"
        )

    def _check_if_over_max(self, value: pt.Voltage) -> None:
        if value > 3.2:
            # TODO: sometimes we use ADC in self-tests or calibrations, and it might not be assigned. This will fail if that's the case.
            unit = whoami.get_unit_name()
            exp = whoami.get_assigned_experiment_name(unit)

            self.logger.error(
                f"An ADC channel is recording a very high voltage, {round(value, 2)}V. We are shutting down components and jobs to keep the ADC safe."
            )

            with local_intermittent_storage("led_locks") as cache:
                for c in led_utils.ALL_LED_CHANNELS:
                    cache.pop(c)

            # turn off all LEDs that might be causing problems
            # however, ODReader may turn on the IR LED again.
            led_utils.led_intensity(
                {c: 0.0 for c in led_utils.ALL_LED_CHANNELS},
                source_of_event="ADCReader",
                unit=unit,
                experiment=exp,
                verbose=True,
            )

            publish(
                f"pioreactor/{unit}/{exp}/monitor/flicker_led_with_error_code",
                error_codes.ADC_INPUT_TOO_HIGH,
            )
            # kill ourselves - this will hopefully kill ODReader.
            # we have to send a signal since this is often called in a thread (timing.RepeatedTimer)
            import os
            import signal

            os.kill(os.getpid(), signal.SIGTERM)
            return

        elif value > 3.0:
            unit = whoami.get_unit_name()
            exp = whoami.get_assigned_experiment_name(unit)

            self.logger.warning(
                f"An ADC channel is recording a very high voltage, {round(value, 2)}V. It's recommended to keep it less than 3.0V. Suggestion: decrease the IR intensity, or change the PD angle to a lower angle."
            )
            publish(
                f"pioreactor/{unit}/{exp}/monitor/flicker_led_with_error_code",
                error_codes.ADC_INPUT_TOO_HIGH,
            )
            return

    def _sin_regression_with_known_freq(
        self,
        x: list[float],
        y: list[pt.Voltage],
        freq: float,
        prior_C: Optional[pt.Voltage] = None,
        penalizer_C: Optional[pt.Voltage] = 0,
    ) -> tuple[tuple[pt.Voltage, Optional[float], Optional[float]], float]:
        r"""
        Assumes a known frequency.
        Formula is

        f(t) = C + A*sin(2*pi*freq*t + phi)

        # TODO: is it implemented as C - A*sin(2*pi*freq*t - phi) ??


        However, estimation occurs as:

        \sum_k (f(t_i) - y_i)^2 + penalizer_C * (C - prior_C)^2

        Parameters
        -----------
        x: iterable
        y: iterable
        freq: the frequency
        prior_C: scalar (optional)
            specify value that will be compared against using ridge regression.
        penalizer_C: scalar (optional)
            penalizer values for the ridge regression

        Returns
        ---------
        (C, A, phi):
            tuple of scalars
        AIC: float
            the AIC of the fit, used for model comparison


        Reference
        ------------
        https://scikit-guess.readthedocs.io/en/latest/appendices/references.html#concept


        Notes
        ------
        This clips the max and min values from the input.

        """
        import numpy as np

        assert len(x) == len(y), "shape mismatch"

        y, removed_indices = self._trim_extrema(y)
        x = [v for i, v in enumerate(x) if i not in removed_indices]

        x_ = np.asarray(x)
        y_ = np.asarray(y)
        n = x_.shape[0]

        tau = 2 * np.pi
        sin_x = np.sin(freq * tau * x_)
        cos_x = np.cos(freq * tau * x_)

        sum_sin = sin_x.sum()
        sum_cos = cos_x.sum()
        sum_sin2 = (sin_x**2).sum()
        sum_cos2 = (cos_x**2).sum()
        sum_cossin = (cos_x * sin_x).sum()

        sum_y = y_.sum()
        sum_ysin = (y_ * sin_x).sum()
        sum_ycos = (y_ * cos_x).sum()

        rhs_penalty_term = 0.0
        lhs_penalty_term = 0.0

        if prior_C and penalizer_C:
            rhs_penalty_term = penalizer_C * prior_C
            lhs_penalty_term = penalizer_C

        M = np.array(
            [
                [n + lhs_penalty_term, sum_sin, sum_cos],
                [sum_sin, sum_sin2, sum_cossin],
                [sum_cos, sum_cossin, sum_cos2],
            ]
        )
        Y = np.array([sum_y + rhs_penalty_term, sum_ysin, sum_ycos])

        try:
            C, b, c = np.linalg.solve(M, Y)
        except np.linalg.LinAlgError as e:
            self.logger.error(f"Error in regression. {e}")
            self.logger.debug(f"{x=}")
            self.logger.debug(f"{y=}")
            return (float(y_.mean()) if y_.size else 0.0, None, None), 1e10

        y_model = C + b * np.sin(freq * tau * x_) + c * np.cos(freq * tau * x_)
        SSE = np.sum((y_ - y_model) ** 2)

        if SSE > 1e-20:
            AIC = n * np.log(SSE / n) + 2 * 3
        else:
            # Perfect (or numerically-perfect) fits should rank best when selecting
            # between candidate AC frequencies.
            AIC = -math.inf

        if np.sqrt(b**2 + c**2) <= 1e-20:
            A = 0
            phi = 0
        else:
            A = np.sqrt(b**2 + c**2)
            phi = np.arcsin(c / np.sqrt(b**2 + c**2))

        return (float(C), float(A), float(phi)), AIC

    def _is_ads1114_channel(self, channel: pt.PdChannel) -> bool:
        return isinstance(self.adcs[channel], madcs.ADS1114_ADC)

    @staticmethod
    def _trim_extrema(values: list[pt.AnalogValue]) -> tuple[list[pt.AnalogValue], set[int]]:
        if len(values) <= 2:
            return values, set()

        argmin_y_, argmax_y_ = argextrema(values)
        removed_indices = {argmin_y_, argmax_y_}
        return [v for i, v in enumerate(values) if i not in removed_indices], removed_indices

    def _simple_trimmed_mean_with_prior(
        self,
        y: list[pt.AnalogValue],
        prior_C: Optional[pt.AnalogValue] = None,
        penalizer_C: Optional[pt.AnalogValue] = 0,
    ) -> pt.AnalogValue:
        y_, _ = self._trim_extrema(y)
        n = len(y_)

        if n == 0:
            return 0.0

        trimmed_mean = mean(y_)
        if prior_C is not None and penalizer_C:
            return (n * trimmed_mean + penalizer_C * prior_C) / (n + penalizer_C)
        return trimmed_mean

    def clear_batched_readings(self) -> None:
        """
        Remove all data from batched_readings. This has the effect of removing hysteresis from the inference.
        """
        self.batched_readings = {}

    @staticmethod
    def _remove_offset_from_signal(
        signals: list[pt.AnalogValue], offset: pt.AnalogValue
    ) -> list[pt.AnalogValue]:
        return [max(x - offset, 0) for x in signals]

    def take_reading(self) -> RawPDReadings:
        """
        Sample from the ADS - likely this has been optimized for use for optical density in the Pioreactor system.
        """

        # we pre-allocate these arrays to make the for loop faster => more accurate
        aggregated_signals: dict[pt.PdChannel, list[pt.AnalogValue]] = {
            channel: [0.0] * self.oversampling_count for channel in self.channels
        }
        timestamps: dict[pt.PdChannel, list[float]] = {
            channel: [0.0] * self.oversampling_count for channel in self.channels
        }

        try:
            with catchtime() as time_since_start:
                for counter in range(self.oversampling_count):
                    with catchtime() as time_sampling_took_to_run:
                        for pd_channel in self.channels:
                            timestamps[pd_channel][counter] = time_since_start()
                            aggregated_signals[pd_channel][counter] = self.adcs[
                                pd_channel
                            ].read_from_channel()

                    sleep(
                        max(
                            0,
                            -time_sampling_took_to_run()  # the time_sampling_took_to_run() reduces the variance by accounting for the duration of each sampling.
                            + 0.85
                            / (self.oversampling_count - 1)  # aim for 0.85s per read
                            * (
                                (counter * 0.618034) % 1
                            ),  # this is to artificially jitter the samples, so that we observe less aliasing. That constant is phi.
                        )
                    )

            batched_estimates_: PdChannelToVoltage = {}

            if os.environ.get("DEBUG") is not None:
                self.logger.debug(f"{timestamps=}")
                self.logger.debug(f"{aggregated_signals=}")

            for channel in self.channels:
                shifted_signals = self._remove_offset_from_signal(
                    aggregated_signals[channel], self.adc_offsets.get(channel, 0.0)
                )

                prior_C = (
                    self.adcs[channel].from_voltage_to_raw_precise(self.batched_readings[channel].reading)
                    if (channel in self.batched_readings)
                    else None
                )
                penalizer_C = self.penalizer * self.oversampling_count

                if self._is_ads1114_channel(channel):
                    best_estimate_of_signal_ = self._simple_trimmed_mean_with_prior(
                        shifted_signals,
                        prior_C=prior_C,
                        penalizer_C=penalizer_C,
                    )
                elif self.most_appropriate_AC_hz is not None:
                    (
                        best_estimate_of_signal_,
                        *_other_param_estimates,
                    ), _ = self._sin_regression_with_known_freq(
                        timestamps[channel],
                        shifted_signals,
                        self.most_appropriate_AC_hz,
                        prior_C=prior_C,
                        penalizer_C=penalizer_C,
                    )

                else:
                    # fallback - just use the mean TODO: doesn't use self.penalizer yet.
                    best_estimate_of_signal_ = mean(shifted_signals)

                # convert to voltage
                best_estimate_of_signal_v = round(
                    self.adcs[channel].from_raw_to_voltage(best_estimate_of_signal_), 10
                )

                # force value to be non-negative. Negative values can still occur due to the IR LED reference
                batched_estimates_[channel] = max(best_estimate_of_signal_v, 0)

                # the max signal should determine the ADS1x15's gain
                m = self.max_signal_moving_average[channel].update(best_estimate_of_signal_v)

                # check if more than 3.x V, and shut down to prevent damage to ADC.
                # we use max_signal to modify the PGA, too
                self._check_if_over_max(m)
                # check if using correct gain
                # this may need to be adjusted for higher rates of data collection
                if self.dynamic_gain:
                    self.adcs[channel].check_on_gain(m)

            self.batched_readings = {
                channel: structs.RawPDReading(reading=batched_estimates_[channel], channel=channel)
                for channel in self.channels
            }

            return self.batched_readings
        except OSError as e:
            self.logger.debug(e, exc_info=True)
            self.logger.error("Detected i2c error - is everything well connected? Check the connections.")
            raise e
        except Exception as e:
            self.logger.debug(e, exc_info=True)
            self.logger.error(e)
            raise e

    def determine_most_appropriate_AC_hz(
        self,
        timestamps: dict[pt.PdChannel, list[float]],
        aggregated_signals: dict[pt.PdChannel, list[pt.AnalogValue]],
    ) -> float:
        def _compute_best_freq(timestamps: list[float], aggregated_signals: list[float]) -> float:
            FREQS_TO_TRY = [60.0, 50.0]
            argmin_freq = FREQS_TO_TRY[0]
            min_AIC = float("inf")

            for freq in FREQS_TO_TRY:
                _, AIC = self._sin_regression_with_known_freq(timestamps, aggregated_signals, freq=freq)
                if AIC < min_AIC:
                    min_AIC = AIC
                    argmin_freq = freq

            return argmin_freq

        channel = self.channels[0]
        argmin_freq1 = _compute_best_freq(timestamps[channel], aggregated_signals[channel])

        self.logger.debug(f"AC hz estimate: {argmin_freq1}")
        return argmin_freq1


class IrLedReferenceTracker(LoggerMixin):
    _logger_name = "ir_led_ref"
    BASELINE_STD_THRESHOLD = 0.025
    BASELINE_INTERVAL_SECONDS = 5.0
    channel: pt.PdChannel

    def __init__(self, interval: float | None = None) -> None:
        super().__init__()
        self.interval = interval

    def update(self, ir_output_reading: pt.Voltage) -> None:
        pass

    def set_interval(self, interval: float | None) -> None:
        self.interval = interval

    def get_std_threshold(self) -> float:
        interval = self.interval if self.interval is not None else self.BASELINE_INTERVAL_SECONDS
        return self.BASELINE_STD_THRESHOLD * math.sqrt(interval / self.BASELINE_INTERVAL_SECONDS)

    def pop_reference_reading(self, raw_readings: RawPDReadings) -> tuple[pt.Voltage, RawPDReadings]:
        ref_reading = raw_readings.pop(self.channel).reading
        return ref_reading, raw_readings

    def transform(self, pd_reading: pt.Voltage) -> pt.OD:
        return pd_reading


class PhotodiodeIrLedReferenceTrackerStaticInit(IrLedReferenceTracker):
    """
    This class contains the logic on how we incorporate the
    direct IR LED output into OD readings.

    Tracking and "normalizing" (see below) the OD signals by the IR LED output is important
    because the OD signal is linearly proportional to the LED output.

    The following are causes of LED output changing:
    - change in temperature of LED, caused by change in ambient temperature, or change in intensity of LED
    - LED dimming over time
    - drop in 3.3V rail -> changes the reference voltage for LED adc_driver -> changes the output

    Unlike other models (see git history), instead of recording the _initial_ led value, we hardcode it to something. Why?
    In PhotodiodeIrLedReferenceTracker (see git history), the transform OD reading is proportional to the initial LED value:

    OD = RAW / (EMA(REF) / initial)
       = initial * ( RAW / EMA(REF) )

    This has problems because as the LED ages, the INITIAL will decrease, and then any calibrations will be start to be off.

    Note: The reason we have INITIAL is so that our transformed OD reading is not some uninterpretable large number (as RAW / REF would be).

    OD = RAW / (EMA(REF) / INITIAL)
       = INITIAL * ( RAW / EMA(REF) )

    Note: INITIAL is just a scale value that makes the data / charts easier to work with. It doesn't (shouldn't) effect anything
    downstream. Note too that as we are normalizing OD readings, the output has arbitrary units.
    """

    INITIAL = 1.0

    def __init__(self, channel: pt.PdChannel, interval: float | None = None) -> None:
        super().__init__(interval=interval)
        self.led_output_ema = ExponentialMovingAverage(
            config.getfloat("od_reading.config", "pd_reference_ema")
        )
        self.led_output_emstd = ExponentialMovingStd(alpha=0.95, ema_alpha=0.8, initial_std_value=0.001)
        self.channel = channel

    def update(self, ir_output_reading: pt.Voltage) -> None:
        # check if funky things are happening by std. banding
        self.led_output_emstd.update(ir_output_reading / self.INITIAL)

        try:
            latest_std = self.led_output_emstd.get_latest()
        except ValueError:
            # can happen if there is only a single data points, and the variance can't be computed.
            latest_std = 0.0

        if latest_std <= self.get_std_threshold():
            # only update if the std looks "okay""
            self.led_output_ema.update(ir_output_reading / self.INITIAL)
        else:
            self.logger.warning(
                f"The reference PD is very noisy, std={latest_std:.2g}. Is the PD in channel {self.channel} positioned correctly? Is the IR LED behaving as expected?"
            )
            self.led_output_emstd.clear()  # reset it for i) reduce warnings, ii) if the user purposely changed the IR intensity, this is an approx of that

    def transform(self, pd_reading: pt.Voltage) -> pt.OD:
        led_output = self.led_output_ema.get_latest()

        if led_output <= 0.0:
            raise ValueError("IR Reference is 0.0. Is it connected correctly? Is the IR LED working?")
        return pd_reading / led_output


class PhotodiodeIrLedReferenceTrackerUnitInit(IrLedReferenceTracker):
    """
    Track the IR LED reference as a relative value near 1.0, anchored to the unit's
    initial REF reading. If REF drops by 20%, f(REF) ~= 0.8, and we normalize by
    SIGNAL / f(REF).
    """

    _PERSISTENT_CACHE_NAME = "ir_led_reference_normalization"

    def __init__(
        self, channel: pt.PdChannel, experiment: pt.Experiment | None = None, interval: float | None = None
    ) -> None:
        super().__init__(interval=interval)
        self.channel = channel
        self.experiment = experiment
        self.initial_ref = self._get_cached_initial_ref()
        self.led_output_ema = ExponentialMovingAverage(
            config.getfloat("od_reading.config", "pd_reference_ema")
        )
        self.led_output_emstd = ExponentialMovingStd(alpha=0.95, ema_alpha=0.8, initial_std_value=0.001)

    def _get_cached_initial_ref(self) -> float | None:
        with local_persistent_storage(self._PERSISTENT_CACHE_NAME) as cache:
            cached = cache.get(self.experiment)

        if cached is None:
            return None
        if isinstance(cached, bytes):
            try:
                cached = float(cached.decode())
            except ValueError:
                return None
        return float(cached)  # type: ignore[arg-type]

    def update(self, ir_output_reading: pt.Voltage) -> None:
        if self.initial_ref is None:
            self.initial_ref = ir_output_reading
            with local_persistent_storage(self._PERSISTENT_CACHE_NAME) as cache:
                cache.set(self.experiment, self.initial_ref)
            self.logger.debug(f"Set {self._PERSISTENT_CACHE_NAME} cache to {self.initial_ref}.")

        relative_ref = ir_output_reading / self.initial_ref

        # check if funky things are happening by std. banding
        self.led_output_emstd.update(relative_ref)

        try:
            latest_std = self.led_output_emstd.get_latest()
        except ValueError:
            # can happen if there is only a single data points, and the variance can't be computed.
            latest_std = 0.0

        if latest_std <= self.get_std_threshold():
            # only update if the std looks "okay""
            self.led_output_ema.update(relative_ref)
        else:
            self.logger.warning(
                f"The reference PD is very noisy, std={latest_std:.2g}. Is the PD in channel {self.channel} positioned correctly? Is the IR LED behaving as expected?"
            )
            self.led_output_emstd.clear()  # reset it for i) reduce warnings, ii) if the user purposely changed the IR intensity, this is an approx of that

    def transform(self, pd_reading: pt.Voltage) -> pt.OD:
        relative_ref = self.led_output_ema.get_latest()

        if relative_ref <= 0.0:
            raise ValueError("IR Reference is 0.0. Is it connected correctly? Is the IR LED working?")
        return pd_reading / relative_ref


class NullIrLedReferenceTracker(IrLedReferenceTracker):
    def __init__(self) -> None:
        super().__init__()

    def pop_reference_reading(self, raw_readings: RawPDReadings) -> tuple[float, RawPDReadings]:
        return 1.0, raw_readings


class HydratedCalibrationModel:
    def __init__(
        self,
        calibration_name: str,
        calibrate_signal: Callable[[pt.Voltage], pt.OD],
        verify_reading: Callable[[structs.ODReading], bool],
    ) -> None:
        self.calibration_name = calibration_name
        self._calibrate_signal = calibrate_signal
        self._verify_reading = verify_reading

    def __call__(self, observed_voltage: pt.Voltage) -> pt.OD:
        return self._calibrate_signal(observed_voltage)

    def verify(self, od_reading: structs.ODReading) -> bool:
        return self._verify_reading(od_reading)


class CalibrationTransformerProtocol(Protocol):
    models: dict[pt.PdChannel, HydratedCalibrationModel]

    def hydate_models(self, calibration_data: structs.ODCalibration | None) -> None: ...

    def __call__(self, batched_readings: structs.ODReadings) -> structs.ODReadings: ...


class EstimatorTransformerProtocol(Protocol):
    estimator: structs.ODFusionEstimator | None

    def hydrate_estimator(self, estimator: structs.ODFusionEstimator | None) -> None: ...

    def __call__(self, raw_od_readings: structs.ODReadings) -> structs.ODFused | None: ...


class NullCalibrationTransformer(LoggerMixin, CalibrationTransformerProtocol):
    _logger_name = "calibration_transformer"

    def __init__(self) -> None:
        super().__init__()
        self.models: dict[pt.PdChannel, HydratedCalibrationModel] = {}

    def hydate_models(self, calibration_data: structs.ODCalibration | None) -> None:
        return

    def __call__(self, batched_readings: structs.ODReadings) -> structs.ODReadings:
        return batched_readings


class CachedCalibrationTransformer(LoggerMixin, CalibrationTransformerProtocol):
    _logger_name = "calibration_transformer"

    def __init__(self) -> None:
        super().__init__()
        self.models: dict[pt.PdChannel, HydratedCalibrationModel] = {}
        self._last_bound_warning_at: float | None = None

    def hydate_models(self, calibration_data: structs.ODCalibration | None) -> None:
        if calibration_data is None:
            self.logger.debug("No calibration available for OD, skipping.")
            return

        channel = calibration_data.pd_channel

        if channel in self.models:
            raise ValueError(f"Calibration model for channel {channel} already hydrated.")

        self.models[channel] = self._hydrate_model(calibration_data)

    def _hydrate_model(self, calibration_data: structs.ODCalibration) -> HydratedCalibrationModel:
        if (
            calibration_data.y != "Voltage"
        ):  # don't check for OD600 - we can allow other non-OD600 calibrations
            self.logger.error(f"Calibration {calibration_data.calibration_name} has wrong type.")
            raise exc.CalibrationError(f"Calibration {calibration_data.calibration_name} has wrong type.")

        if calibration_data.curve_data_.type == "poly":
            coefficients = calibration_data.curve_data_.coefficients
            higher_order_terms = coefficients[:-1]
            if len(higher_order_terms) == 0 or all(c == 0.0 for c in higher_order_terms):
                self.logger.warning(
                    "Calibration curve is y(x)=constant. This is probably wrong. Check the calibration YAML file's curve_data_."
                )

        def _verify(od_reading: structs.ODReading) -> bool:
            """
            Verify that the OD reading is within the expected bounds of the calibration.
            """
            if od_reading.ir_led_intensity != calibration_data.ir_led_intensity:
                raise exc.CalibrationError(
                    f"IR LED intensity {od_reading.ir_led_intensity} does not match calibration {calibration_data.ir_led_intensity} for channel {od_reading.channel}."
                )
            return True

        def _calibrate_signal(observed_voltage: pt.Voltage) -> pt.OD:
            try:
                recorded_ods = calibration_data.recorded_data["x"]
                recorded_voltages = calibration_data.recorded_data["y"]
                min_OD, max_OD = min(recorded_ods), max(recorded_ods)
                voltage_od_pairs = list(zip(recorded_voltages, recorded_ods))
                min_voltage, od_at_min_voltage = min(voltage_od_pairs, key=lambda pair: pair[0])
                max_voltage, od_at_max_voltage = max(voltage_od_pairs, key=lambda pair: pair[0])
            except ValueError:
                # can only really occur if data is missing
                min_OD, max_OD = 0.0, 100_000.0
                min_voltage, max_voltage = 0.0, 100_000.0
                od_at_min_voltage, od_at_max_voltage = min_OD, max_OD

            def clamp_to_recorded_extrema() -> pt.OD:
                if observed_voltage <= min_voltage:
                    return od_at_min_voltage
                elif observed_voltage >= max_voltage:
                    return od_at_max_voltage
                # if the observed voltage lies between the smallest and largest recorded voltages but the polynomial solver still says “out of
                # domain” (e.g., non‑monotonic curve giving no valid root in-bounds), we can’t map it normally. In that unlikely situation we snap the
                # result to whichever recorded voltage end (min or max) is nearest to the observed voltage, rather than picking an arbitrary side
                return (
                    od_at_min_voltage
                    if abs(observed_voltage - min_voltage) < abs(observed_voltage - max_voltage)
                    else od_at_max_voltage
                )

            try:
                return calibration_data.y_to_x(observed_voltage, enforce_bounds=True)
            except exc.NoSolutionsFoundError:
                if self._should_warn_about_bounds():
                    self.logger.warning(
                        f"No solution found for calibrated signal. Trimming signal. Calibrated for OD=[{min_OD:0.3g}, {max_OD:0.3g}], V=[{min_voltage:0.3g}, {max_voltage:0.3g}]. Observed {observed_voltage:0.3f}V, which would map outside the allowed values."
                    )
                return clamp_to_recorded_extrema()
            except exc.SolutionBelowDomainError:
                if self._should_warn_about_bounds():
                    below_or_above = "below" if observed_voltage <= min_voltage else "outside of"
                    self.logger.warning(
                        f"Signal {below_or_above} suggested calibration range. Trimming signal. Calibrated for OD=[{min_OD:0.3g}, {max_OD:0.3g}], V=[{min_voltage:0.3g}, {max_voltage:0.3g}]. Observed {observed_voltage:0.3f}V, which would map outside the allowed values."
                    )
                return clamp_to_recorded_extrema()
            except exc.SolutionAboveDomainError:
                if self._should_warn_about_bounds():
                    above_or_outside = "above" if observed_voltage >= max_voltage else "outside of"
                    self.logger.warning(
                        f"Signal {above_or_outside} suggested calibration range. Trimming signal. Calibrated for OD=[{min_OD:0.3g}, {max_OD:0.3g}], V=[{min_voltage:0.3g}, {max_voltage:0.3g}]. Observed {observed_voltage:0.3f}V, which would map outside the allowed values."
                    )
                return clamp_to_recorded_extrema()

        return HydratedCalibrationModel(
            calibration_name=calibration_data.calibration_name,
            calibrate_signal=_calibrate_signal,
            verify_reading=_verify,
        )

    def _should_warn_about_bounds(self) -> bool:
        now = time()
        if self._last_bound_warning_at is None or (now - self._last_bound_warning_at) > 300:
            self._last_bound_warning_at = now
            return True
        return False

    def __call__(self, od_readings: structs.ODReadings) -> structs.ODReadings:
        calibrated_od_readings = structs.ODReadings(ods={}, timestamp=od_readings.timestamp)
        for channel in od_readings.ods:
            if channel in self.models:  # calibration exists
                raw_od = od_readings.ods[channel]

                # check if everything is okay - blows up if not.
                self.models[channel].verify(raw_od)

                calibrated_od_readings.ods[channel] = structs.CalibratedODReading(
                    channel=raw_od.channel,
                    angle=raw_od.angle,
                    timestamp=raw_od.timestamp,
                    ir_led_intensity=raw_od.ir_led_intensity,
                    od=self.models[channel](raw_od.od),
                    calibration_name=self.models[channel].calibration_name,
                )
            else:
                calibrated_od_readings.ods[channel] = od_readings.ods[channel]

        return calibrated_od_readings


class NullEstimatorTransformer(LoggerMixin, EstimatorTransformerProtocol):
    _logger_name = "estimator_transformer"

    def __init__(self) -> None:
        super().__init__()
        self.estimator: structs.ODFusionEstimator | None = None

    def hydrate_estimator(self, estimator: structs.ODFusionEstimator | None) -> None:
        return

    def __call__(self, raw_od_readings: structs.ODReadings) -> structs.ODFused | None:
        return None


class CachedEstimatorTransformer(LoggerMixin, EstimatorTransformerProtocol):
    _logger_name = "estimator_transformer"

    def __init__(self) -> None:
        super().__init__()
        self.estimator: structs.ODFusionEstimator | None = None
        self._last_bound_warning_at: float | None = None

    def hydrate_estimator(self, estimator: structs.ODFusionEstimator | None) -> None:
        if estimator is None:
            self.logger.debug("No estimator available for OD fusion, skipping.")
            return
        self.estimator = estimator

    def _verify(self, raw_od_readings: structs.ODReadings) -> None:
        if self.estimator is None:
            return

        for od_reading in raw_od_readings.ods.values():
            if od_reading.ir_led_intensity != self.estimator.ir_led_intensity:
                raise exc.EstimatorError(
                    f"IR LED intensity {od_reading.ir_led_intensity} does not match estimator {self.estimator.ir_led_intensity} for channel {od_reading.channel}."
                )

    def __call__(self, raw_od_readings: structs.ODReadings) -> structs.ODFused | None:
        if self.estimator is None:
            return None

        self._verify(raw_od_readings)

        fused_inputs: dict[pt.PdAngle, float] = {
            reading.angle: reading.od for reading in raw_od_readings.ods.values()
        }
        try:
            od_fused_value = compute_fused_od(self.estimator, fused_inputs)
            if self._should_warn_about_bounds(od_fused_value):
                self.logger.warning(
                    "Fused OD estimate hit estimator bounds: estimator=%s min_logc=%s max_logc=%s od_fused=%s",
                    self.estimator.estimator_name,
                    self.estimator.min_logc,
                    self.estimator.max_logc,
                    od_fused_value,
                )
        except Exception as e:
            self.logger.debug(f"Failed to compute fused OD: {e}", exc_info=True)
            return None

        return structs.ODFused(od_fused=od_fused_value, timestamp=raw_od_readings.timestamp)

    def _should_warn_about_bounds(self, od_fused_value: float) -> bool:
        if self.estimator is None:
            return False

        lower_bound = 10**self.estimator.min_logc
        upper_bound = 10**self.estimator.max_logc
        if (od_fused_value <= lower_bound * 1.001) or (od_fused_value >= upper_bound * 0.999):
            now = time()
            if self._last_bound_warning_at is None or (now - self._last_bound_warning_at) > 300:
                self._last_bound_warning_at = now
                return True
        return False


class ODReader(BackgroundJob):
    """
    Produce a stream of OD readings from the sensors.

    Parameters
    -----------
    channel_angle_map: dict
        dict of (channel: angle) pairs, ex: {1: "135", 2: "90"}
    interval: float
        seconds between readings. If None or 0, then don't periodically read.
    adc_reader: ADCReader
    ir_led_reference_tracker: IrLedReferenceTracker
    calibration_transformer:
    estimator_transformer:


    Examples
    ---------

    Initializing this class will start reading in the background, if ``interval`` is not ``None``.

    > od_reader = ODReader({'1': '45'}, 5)
    > # readings will start to be published to MQTT, and the latest reading will be available as od_reader.ods

    It can also be iterated over:

    > od_reader = ODReader({'1': '45'}, 5)
    > for od_reading in od_reader:
    >    # do things...

    If ``interval`` is ``None`` or 0, then users need to call ``record_from_adc`` manually.

    >> od_reading = od_reader.record_from_adc()

    """

    job_name = "od_reading"
    published_settings = {
        "first_od_obs_time": {"datatype": "float", "settable": False},
        "ir_led_intensity": {"datatype": "float", "settable": True, "unit": "%"},
        "interval": {"datatype": "float", "settable": True, "unit": "s"},
        "relative_intensity_of_ir_led": {"datatype": "json", "settable": False},
        "ods": {"datatype": "ODReadings", "settable": False},
        "od1": {"datatype": "ODReading", "settable": False},
        "od2": {"datatype": "ODReading", "settable": False},
        "od3": {"datatype": "ODReading", "settable": False},
        "od4": {"datatype": "ODReading", "settable": False},
        # below are only used if a calibration is used
        "raw_od1": {"datatype": "RawODReading", "settable": False},
        "raw_od2": {"datatype": "RawODReading", "settable": False},
        "raw_od3": {"datatype": "RawODReading", "settable": False},
        "raw_od4": {"datatype": "RawODReading", "settable": False},
        "calibrated_od1": {"datatype": "CalibratedODReading", "settable": False},
        "calibrated_od2": {"datatype": "CalibratedODReading", "settable": False},
        "calibrated_od3": {"datatype": "CalibratedODReading", "settable": False},
        "calibrated_od4": {"datatype": "CalibratedODReading", "settable": False},
        # below are used if a sensor fusion is used
        "od_fused": {"datatype": "ODFused", "settable": False},
    }

    _pre_read: list[Callable] = []
    _post_read: list[Callable] = []
    od1: structs.ODReading | None = None
    od2: structs.ODReading | None = None
    od3: structs.ODReading | None = None
    od4: structs.ODReading | None = None
    ods: structs.ODReadings | None = None
    od_fused: structs.ODFused | None = None
    raw_od1: structs.RawODReading | None = None
    raw_od2: structs.RawODReading | None = None
    raw_od3: structs.RawODReading | None = None
    raw_od4: structs.RawODReading | None = None
    calibrated_od1: structs.CalibratedODReading | None = None
    calibrated_od2: structs.CalibratedODReading | None = None
    calibrated_od3: structs.CalibratedODReading | None = None
    calibrated_od4: structs.CalibratedODReading | None = None
    record_from_adc_timer: timing.RepeatedTimer

    def __init__(
        self,
        channel_angle_map: dict[pt.PdChannel, pt.PdAngle],
        interval: Optional[float],
        adc_reader: ADCReader,
        unit: pt.Unit,
        experiment: pt.Experiment,
        ir_led_reference_tracker: Optional[IrLedReferenceTracker] = None,
        calibration_transformer: Optional[CalibrationTransformerProtocol] = None,
        estimator_transformer: Optional[EstimatorTransformerProtocol] = None,
        ir_led_intensity: float | None = None,
    ) -> None:
        super(ODReader, self).__init__(unit=unit, experiment=experiment)

        if len(channel_angle_map) == 0:
            self.logger.error(
                "Need to supply a signal channel. Check `[od_config.photodiode_channel]` in your config."
            )
            self.clean_up()
            raise ValueError(
                "Need to supply a signal channel. Check `[od_config.photodiode_channel]` in your config."
            )

        self.adc_reader = adc_reader

        if ir_led_reference_tracker is None:
            self.logger.debug("Not tracking IR intensity.")
            self.ir_led_reference_transformer = NullIrLedReferenceTracker()
        else:
            self.ir_led_reference_transformer = ir_led_reference_tracker  # type: ignore

        if calibration_transformer is None:
            self.logger.debug("Not using any calibration.")
            self.calibration_transformer = NullCalibrationTransformer()
        else:
            self.calibration_transformer = calibration_transformer  # type: ignore

        if estimator_transformer is None:
            self.logger.debug("Not using any estimator.")
            self.estimator_transformer = NullEstimatorTransformer()
        else:
            self.estimator_transformer = estimator_transformer  # type: ignore

        self.adc_reader.add_external_logger(self.logger)
        self.calibration_transformer.add_external_logger(self.logger)
        self.ir_led_reference_transformer.add_external_logger(self.logger)
        self.estimator_transformer.add_external_logger(self.logger)

        self.channel_angle_map = channel_angle_map

        calibration_status = "none"
        if isinstance(self.calibration_transformer, CachedCalibrationTransformer):
            configured_channels = sorted(self.channel_angle_map.keys(), key=int)
            used_calibrations: list[str] = []
            for channel in configured_channels:
                model = self.calibration_transformer.models.get(channel)
                if model is None:
                    continue
                used_calibrations.append(
                    f"{model.calibration_name} (pd{channel}@{self.channel_angle_map[channel]})"
                )

            if used_calibrations:
                calibration_status = ", ".join(used_calibrations)

        estimator_status = "none"
        if isinstance(self.estimator_transformer, CachedEstimatorTransformer):
            if self.estimator_transformer.estimator is not None:
                estimator_status = self.estimator_transformer.estimator.estimator_name

        self.logger.debug(f"OD setup: calibrations={calibration_status}; estimator={estimator_status}.")

        self.first_od_obs_time: Optional[float] = None
        self._set_for_iterating = threading.Event()

        self.ir_channel: pt.LedChannel = self._get_ir_led_channel_from_configuration()

        # determine initial IR LED intensity and whether to auto-adjust it later
        should_auto_adjust_ir_led, self.ir_led_intensity = self._determine_initial_ir_led_intensity(
            ir_led_intensity
        )

        self.non_ir_led_channels: list[pt.LedChannel] = [
            ch for ch in led_utils.ALL_LED_CHANNELS if ch != self.ir_channel
        ]

        if not hardware.is_HAT_present():
            self.logger.error("Pioreactor HAT must be present.")
            self.clean_up()
            raise exc.HardwareNotFoundError("Pioreactor HAT must be present.")

        self.pre_read_callbacks = self._prepare_pre_callbacks()
        self.post_read_callbacks = self._prepare_post_callbacks()

        # setup the ADC by turning off all LEDs.
        with led_utils.change_leds_intensities_temporarily(
            {ch: 0.0 for ch in led_utils.ALL_LED_CHANNELS},
            unit=self.unit,
            experiment=self.experiment,
            source_of_event=self.job_name,
            pubsub_client=self.pub_client,
            verbose=False,
        ):
            with led_utils.lock_leds_temporarily(self.non_ir_led_channels):
                blank_reading = self.adc_reader.take_reading()
                self.adc_reader.set_offsets(blank_reading)  # set dark offset

                # IR led is on
                self.start_ir_led()
                sleep(0.125)

                on_reading = self.adc_reader.tune_adc_with_ir_on()  # determine best gain, max-signal, etc.

                # IR led is off so we can set blanks
                self.stop_ir_led()

                # clear the history in adc_reader, so that we don't use blank readings in later inference.
                self.adc_reader.clear_batched_readings()

        if should_auto_adjust_ir_led:
            self.ir_led_intensity = self._determine_best_ir_led_intensity(
                self.channel_angle_map, self.ir_led_intensity, on_reading, blank_reading
            )

        self.set_interval(interval)

        self.logger.debug(
            f"Starting od_reading with PD channels {channel_angle_map}, with IR LED intensity {self.ir_led_intensity}% from channel {self.ir_channel}"
            + (f" every {self.interval} seconds." if self.interval else ".")
        )

    def _determine_initial_ir_led_intensity(self, ir_led_intensity: float | str | None) -> tuple[bool, float]:
        """
        Determine whether to auto adjust IR LED intensity and return initial intensity.
        """
        if ir_led_intensity is None:
            ir_intensity_cfg = config.get("od_reading.config", "ir_led_intensity")
        else:
            ir_intensity_cfg = ir_led_intensity

        if ir_intensity_cfg == "auto":
            return True, 85.0

        intensity_value = float(ir_intensity_cfg)
        if intensity_value > 90:
            self.logger.warning(
                f"The value for the IR LED, {intensity_value}%, is very high. "
                "We suggest a value 90% or less to avoid damaging the LED."
            )
        return False, intensity_value

    @staticmethod
    def _determine_best_ir_led_intensity(
        channel_angle_map: dict[pt.PdChannel, pt.PdAngle],
        initial_ir_intensity: float,
        on_reading: RawPDReadings,
        blank_reading: RawPDReadings,
    ) -> float:
        """
        What do we want for a good value?

         - [REF] is less than 0.256
         - [90] gets lots of light, but less than 3.0, even at a full culture
         - IR intensity always is less than 90%
         - [90] is "far away" from it's blank signal (TODO: how do we quantify this?)

        """
        MAX = 85.0

        if len(channel_angle_map) != 1:
            # multiple signals? noop
            return MAX

        pd_channel = list(channel_angle_map.keys())[0]

        culture_on_signal = on_reading.pop(pd_channel)

        if len(on_reading) == 0:
            # no REF, noop
            return MAX

        _, REF_on_signal = on_reading.popitem()

        def _safe_ratio(numerator: float, denominator: float) -> float:
            # Very small / zero sensor values can occur during startup or hardware faults.
            # Treating the ratio as +inf preserves current behavior (falls back to MAX)
            # while avoiding runtime crashes.
            if denominator <= 0.0:
                return float("inf")
            return numerator / denominator

        ir_intensity_argmax_REF_can_be = _safe_ratio(initial_ir_intensity, REF_on_signal.reading) * 0.250

        # divide by N since the culture is unlikely to Nx.
        ir_intensity_argmax_ANGLE_can_be = (
            _safe_ratio(initial_ir_intensity, culture_on_signal.reading) * 3.0 / 50
        )

        ir_led_intensity = min(
            MAX, ir_intensity_argmax_ANGLE_can_be, ir_intensity_argmax_REF_can_be
        )  # small as possible
        ir_led_intensity = max(ir_led_intensity, 50)  # always more than X
        return round(ir_led_intensity, 2)

    def set_interval(self, interval: Optional[float]) -> None:
        if (interval is not None) and interval <= 0:
            raise ValueError("interval must be positive or None")

        self.interval = interval
        self.ir_led_reference_transformer.set_interval(interval)

        if self.interval is not None:
            if self.interval <= 1.0:
                self.logger.warning(
                    f"Recommended to have the interval between readings be larger than 1.0 sec. Currently {self.interval} sec."
                )

            if hasattr(self, "record_from_adc_timer"):
                # cancel any existing one
                self.record_from_adc_timer.cancel()

            self.record_from_adc_timer = timing.RepeatedTimer(
                self.interval,
                self.record_from_adc,
                job_name=self.job_name,
                run_immediately=True,
                logger=self.logger,
            ).start()

        else:
            if hasattr(self, "record_from_adc_timer"):
                # cancel any existing one
                self.record_from_adc_timer.cancel()

    def _prepare_post_callbacks(self) -> list[Callable]:
        callbacks: list[Callable] = []

        # user created callbacks, this binds the callback to the instance so def cb(self, ... ) makes sense.
        for func in self._post_read:
            setattr(self, func.__name__, types.MethodType(func, self))
            callbacks.append(getattr(self, func.__name__))
        return callbacks

    def _prepare_pre_callbacks(self) -> list[Callable]:
        callbacks: list[Callable] = []

        # user created callbacks, this binds the callback to the instance so def cb(self, ... ) makes sense.
        for func in self._pre_read:
            setattr(self, func.__name__, types.MethodType(func, self))
            callbacks.append(getattr(self, func.__name__))
        return callbacks

    @classmethod
    def add_pre_read_callback(cls, function: Callable) -> None:
        cls._pre_read.append(function)

    @classmethod
    def add_post_read_callback(cls, function: Callable) -> None:
        cls._post_read.append(function)

    @property
    def ir_led_on_and_rest_off_state(self) -> dict[pt.LedChannel, pt.LedIntensityValue]:
        if config.getboolean("od_reading.config", "turn_off_leds_during_reading", fallback="True"):
            return {
                channel: (self.ir_led_intensity if channel == self.ir_channel else 0.0)
                for channel in led_utils.ALL_LED_CHANNELS
            }
        else:
            return {self.ir_channel: self.ir_led_intensity}

    def record_from_adc(self) -> structs.ODReadings | None:
        """
        Take a recording of the current OD of the culture.

        """
        if self.first_od_obs_time is None:
            self.first_od_obs_time = time()

        for pre_function in self.pre_read_callbacks:
            try:
                pre_function()
            except Exception:
                self.logger.debug(f"Error in pre_function={pre_function.__name__}.", exc_info=True)

        # we put a soft lock on the LED channels - it's up to the
        # other jobs to make sure they check the locks.
        with led_utils.change_leds_intensities_temporarily(
            desired_state=self.ir_led_on_and_rest_off_state,
            unit=self.unit,
            experiment=self.experiment,
            source_of_event=self.job_name,
            pubsub_client=self.pub_client,
            verbose=False,
        ):
            with led_utils.lock_leds_temporarily(self.non_ir_led_channels):
                sleep(
                    config.getfloat(
                        "od_reading.config", "duration_between_led_off_and_od_reading", fallback=0.125
                    )
                )
                raw_od_readings = self._read_from_adc()

        try:
            od_readings = self.calibration_transformer(raw_od_readings)
        except (exc.NoSolutionsFoundError, exc.CalibrationError, ValueError) as e:
            # some calibration error occurred
            od_readings = None
            self.ods = None

            # Preserve the fresh raw readings, but clear the calibrated outputs so
            # consumers do not keep observing the previous successful batch.
            for channel, _ in self.channel_angle_map.items():
                setattr(self, f"od{channel}", None)
                setattr(self, f"calibrated_od{channel}", None)
                setattr(self, f"raw_od{channel}", raw_od_readings.ods[channel])

            self.logger.error(f"Error in calibration transformer: {e}")
            raise e
        else:
            # happy path
            assert od_readings is not None
            self.ods = od_readings
            for channel, _ in self.channel_angle_map.items():
                setattr(self, f"od{channel}", od_readings.ods[channel])
                if isinstance(od_readings.ods[channel], structs.CalibratedODReading):
                    setattr(self, f"raw_od{channel}", raw_od_readings.ods[channel])
                    setattr(self, f"calibrated_od{channel}", od_readings.ods[channel])

            try:
                fused_od = self.estimator_transformer(raw_od_readings)
            except (exc.CalibrationError, exc.EstimatorError) as e:
                self.logger.error(f"Error in estimator transformer: {e}")
                self.od_fused = None
            else:
                self.od_fused = fused_od

        finally:
            for post_function in self.post_read_callbacks:
                try:
                    post_function(od_readings)
                except Exception:
                    self.logger.debug(f"Error in post_function={post_function.__name__}.", exc_info=True)

            self._log_relative_intensity_of_ir_led()
            self._unblock_internal_event()

        return od_readings

    def start_ir_led(self) -> None:
        r = led_utils.led_intensity(
            {self.ir_channel: self.ir_led_intensity},
            unit=self.unit,
            experiment=self.experiment,
            source_of_event=self.job_name,
            pubsub_client=self.pub_client,
            verbose=False,
        )
        if not r:
            self.clean_up()
            raise exc.HardwareNotFoundError("IR LED could not be started. Stopping OD reading.")

        return

    def stop_ir_led(self) -> None:
        led_utils.led_intensity(
            {self.ir_channel: 0.0},
            unit=self.unit,
            experiment=self.experiment,
            source_of_event=self.job_name,
            pubsub_client=self.pub_client,
            verbose=False,
        )

    ###########
    # Private
    ############

    def on_sleeping(self) -> None:
        if hasattr(self, "record_from_adc_timer"):
            self.record_from_adc_timer.pause()

    def on_sleeping_to_ready(self) -> None:
        if hasattr(self, "record_from_adc_timer"):
            self.record_from_adc_timer.unpause()

    def on_disconnected(self) -> None:
        try:
            self.record_from_adc_timer.cancel()
        except Exception:
            pass

        # turn off the LED after we have take our last ADC reading..
        try:
            self.stop_ir_led()
        except Exception:
            pass

    def _get_ir_led_channel_from_configuration(self) -> pt.LedChannel:
        try:
            return cast(pt.LedChannel, config.get("leds_reverse", IR_keyword))
        except Exception:
            self.logger.error(
                """`leds` section must contain `IR` value. Ex:
        [leds]
        A=IR
            """
            )
            self.clean_up()
            raise KeyError("`IR` value not found in section.")

    def _read_from_adc(self) -> structs.ODReadings:
        """
        Read from the ADC. This function normalizes by the IR ref.

        Note
        -----
        The IR LED needs to be turned on for this function to report accurate OD signals.
        """
        raw_pd_readings = self.adc_reader.take_reading()

        ref_reading, raw_pd_readings = self.ir_led_reference_transformer.pop_reference_reading(
            raw_pd_readings
        )
        self.ir_led_reference_transformer.update(ref_reading)

        ts = timing.current_utc_datetime()
        raw_od_readings = structs.ODReadings(
            timestamp=ts,
            ods={
                pd: structs.RawODReading(
                    od=self.ir_led_reference_transformer.transform(raw_pd_reading.reading),
                    ir_led_intensity=self.ir_led_intensity,
                    angle=self.channel_angle_map[pd],
                    channel=pd,
                    timestamp=ts,
                )
                for pd, raw_pd_reading in raw_pd_readings.items()
            },
        )

        return raw_od_readings

    def _log_relative_intensity_of_ir_led(self) -> None:
        if random.random() < 0.2:
            self.relative_intensity_of_ir_led = {
                # represents the relative intensity of the LED.
                "relative_intensity_of_ir_led": 1 / self.ir_led_reference_transformer.transform(1.0),
                "timestamp": timing.current_utc_datetime(),
            }

    def _unblock_internal_event(self) -> None:
        if self.state is not st.READY:
            return

        self._set_for_iterating.set()

    def __iter__(self) -> "ODReader":
        return self

    def __next__(self) -> structs.ODReadings:
        while self._set_for_iterating.wait():
            self._set_for_iterating.clear()
            if self.ods is not None:
                return self.ods
        assert False  # we never reach here - this is to silence mypy


def find_ir_led_reference(channels: Mapping[str, str | None]) -> Optional[pt.PdChannel]:
    if sum(v == "REF" for v in channels.values()) > 1:
        raise ValueError('"REF" occurs more than once')

    for channel, angle in channels.items():
        if angle != REF_keyword:
            continue
        elif channel not in hardware.get_available_pd_channels():
            continue

        return cast(pt.PdChannel, channel)
    return None


def create_channel_angle_map(
    channels: Mapping[str, str | None],
) -> dict[pt.PdChannel, pt.PdAngle]:
    channel_angle_map: dict[pt.PdChannel, pt.PdAngle] = {}

    for channel, angle in channels.items():
        if angle is None or angle == REF_keyword or angle == "":
            continue

        if angle not in VALID_PD_ANGLES:
            raise ValueError(f"{angle=} is not a valid angle. Must be one of {VALID_PD_ANGLES}")

        channel_angle_map[cast(pt.PdChannel, channel)] = cast(pt.PdAngle, angle)

    return channel_angle_map


def start_od_reading(
    channels: Mapping[str, str | None],
    interval: float | None = None,
    fake_data: bool = False,
    unit: pt.Unit | None = None,
    experiment: pt.Experiment | None = None,
    calibration: bool | structs.ODCalibration | list[structs.ODCalibration] | None = True,
    estimator: bool | structs.ODFusionEstimator | None = True,
    ir_led_intensity: float | None = None,
    penalizer: float = 0.0,
) -> "ODReader":
    """
    This function prepares ODReader and other necessary transformation objects. It's a higher level API than using ODReader.

    Note on channels
    --------------------------

    Provide a mapping between physical photodiode channels and the desired IR/angle configuration.
    Keys should match whatever channels are declared in `adc.yaml`. For example, if your config looks like:

        [od_config.photodiode_channel]
        1=REF
        2=90

    then the correct syntax is `start_od_reading({"1": "REF", "2": "90"})`.

    """
    if interval is not None and interval <= 0:
        raise ValueError("interval must be positive.")

    if not channels:
        raise ValueError("Need to supply at least one photodiode channel.")

    unit = unit or whoami.get_unit_name()
    experiment = experiment or whoami.get_assigned_experiment_name(unit)

    ir_led_reference_channel = find_ir_led_reference(channels)
    channel_angle_map = create_channel_angle_map(channels)
    if len(channel_angle_map) == 0:
        raise ValueError(
            "Need to supply a signal channel. Check `[od_config.photodiode_channel]` in your config."
        )
    active_pd_channels = list(channel_angle_map.keys())

    # use IR LED reference to normalize?
    ir_led_reference_tracker: IrLedReferenceTracker
    if ir_led_reference_channel is not None:
        active_pd_channels.append(ir_led_reference_channel)

        ref_normalization = config.get("od_reading.config", "ref_normalization", fallback="classic")
        if ref_normalization == "unity":
            ir_led_reference_tracker = PhotodiodeIrLedReferenceTrackerUnitInit(
                ir_led_reference_channel,
                experiment=experiment,
                interval=interval,
            )
        else:
            ir_led_reference_tracker = PhotodiodeIrLedReferenceTrackerStaticInit(
                ir_led_reference_channel,
                interval=interval,
            )

    else:
        ir_led_reference_tracker = NullIrLedReferenceTracker()

    # use an OD calibration?
    calibration_transformer: CalibrationTransformerProtocol
    if calibration is True:
        from pioreactor.calibrations import load_active_calibration

        calibration_transformer = CachedCalibrationTransformer()
        for channel, angle in channel_angle_map.items():
            active_calibration = load_active_calibration(f"od{angle}")  # type: ignore
            if active_calibration is not None:
                calibration_transformer.hydate_models(active_calibration)
    elif isinstance(calibration, list):
        calibration_transformer = CachedCalibrationTransformer()
        for calibration_item in calibration:
            calibration_transformer.hydate_models(calibration_item)
    elif isinstance(calibration, structs.CalibrationBase):
        calibration_transformer = CachedCalibrationTransformer()
        calibration_transformer.hydate_models(calibration)
    else:
        calibration_transformer = NullCalibrationTransformer()

    estimator_transformer: EstimatorTransformerProtocol

    if estimator is True:
        from pioreactor.estimators import load_active_estimator

        maybe_estimator = load_active_estimator(pt.OD_FUSED_DEVICE)
        if isinstance(maybe_estimator, structs.ODFusionEstimator):
            estimator_transformer = CachedEstimatorTransformer()
            estimator_transformer.hydrate_estimator(maybe_estimator)
        else:
            estimator_transformer = NullEstimatorTransformer()
    elif isinstance(
        estimator, structs.ODFusionEstimator
    ):  # TODO: put a intermediate class between the super class and ODFusionEstimator
        estimator_transformer = CachedEstimatorTransformer()
        estimator_transformer.hydrate_estimator(estimator)
    else:
        estimator_transformer = NullEstimatorTransformer()

    if interval is None:
        penalizer = 0.0

    return ODReader(
        channel_angle_map,
        interval=interval,
        unit=unit,
        experiment=experiment,
        adc_reader=ADCReader(
            channels=active_pd_channels, fake_data=fake_data, dynamic_gain=not fake_data, penalizer=penalizer
        ),
        ir_led_reference_tracker=ir_led_reference_tracker,
        calibration_transformer=calibration_transformer,
        estimator_transformer=estimator_transformer,
        ir_led_intensity=ir_led_intensity,
    )


@click.command(name="od_reading")
@click.option("--fake-data", is_flag=True, help="produce fake data (for testing)")
@click.option(
    "--interval",
    type=click.FLOAT,
    default=None,
    show_default=True,
    help="seconds between readings",
)
@click.option(
    "--ir-led-intensity",
    type=click.FLOAT,
    default=None,
    show_default=True,
    help="IR LED intensity (percent)",
)
@click.option("--snapshot", is_flag=True, help="take one reading and exit")
def click_od_reading(
    fake_data: bool,
    interval: float | None,
    ir_led_intensity: float | None,
    snapshot: bool,
) -> None:
    """
    Start the optical density reading job
    """

    # determine interval: override if provided, else use snapshot or config default
    samples_per_second = config.getfloat("od_reading.config", "samples_per_second", fallback=0.2)
    if samples_per_second <= 0:
        create_logger("od_reading").error(
            "Invalid config value for [od_reading.config] samples_per_second=%s. "
            "Expected a value > 0 to compute the default read interval.",
            samples_per_second,
        )
        raise ValueError(
            f"Invalid [od_reading.config] samples_per_second={samples_per_second}. Expected a value > 0."
        )

    default_interval = 1 / samples_per_second
    run_interval = interval if interval is not None else (None if snapshot else default_interval)
    penalizer = (
        config.getfloat("od_reading.config", "smoothing_penalizer", fallback=3.0) / run_interval
        if (run_interval is not None)
        else 0
    )
    with start_od_reading(
        config["od_config.photodiode_channel"],
        fake_data=fake_data or whoami.is_testing_env(),
        interval=run_interval,
        ir_led_intensity=ir_led_intensity,
        penalizer=penalizer,
    ) as od:
        if snapshot:
            od_snapshot = od.record_from_adc()
            # send the reading to stdout so it can be captured / piped elsewhere
            click.echo(str(od_snapshot), err=False)
        else:
            od.block_until_disconnected()
