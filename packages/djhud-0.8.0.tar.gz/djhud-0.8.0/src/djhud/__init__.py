"""DJ HUD — Lightweight screen/webcam region capture and virtual camera tool for DJs."""

__version__ = "0.8.0"
APP_NAME = "DJ HUD Builder"
