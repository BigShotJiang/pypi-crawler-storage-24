"""Basic tests for univfyi."""

from univfyi import __version__


def test_version() -> None:
    assert __version__ == "0.1.0"
