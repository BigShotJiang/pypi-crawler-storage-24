"""Command-line interface for univfyi."""

from __future__ import annotations

import json

import typer

from univfyi.api import UnivFYI

app = typer.Typer(help="UnivFYI — University rankings and programs API client.")


@app.command()
def search(query: str) -> None:
    """Search univfyi.com."""
    with UnivFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
