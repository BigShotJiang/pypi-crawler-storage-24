"""MCP server for univfyi — AI assistant tools for univfyi.com.

Run: uvx --from "univfyi[mcp]" python -m univfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("UnivFYI")


@mcp.tool()
def list_tiers(limit: int = 20, offset: int = 0) -> str:
    """List tiers from univfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from univfyi.api import UnivFYI

    with UnivFYI() as api:
        data = api.list_tiers(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No tiers found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_tier(slug: str) -> str:
    """Get detailed information about a specific tier.

    Args:
        slug: URL slug identifier for the tier.
    """
    from univfyi.api import UnivFYI

    with UnivFYI() as api:
        data = api.get_tier(slug)
        return str(data)


@mcp.tool()
def list_guides(limit: int = 20, offset: int = 0) -> str:
    """List guides from univfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from univfyi.api import UnivFYI

    with UnivFYI() as api:
        data = api.list_guides(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No guides found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_univ(query: str) -> str:
    """Search univfyi.com for university rankings, programs, and admissions.

    Args:
        query: Search query string.
    """
    from univfyi.api import UnivFYI

    with UnivFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
