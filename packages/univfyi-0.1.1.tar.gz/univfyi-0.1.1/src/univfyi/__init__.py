"""Python API client for univfyi.com."""

__version__ = "0.1.0"
