def main():
    print("Hello from titan-assertion!")


if __name__ == "__main__":
    main()
