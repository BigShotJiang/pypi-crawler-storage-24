# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-03-10 00:00:00
@LastEditTime: 2026-03-10 00:00:00
@LastEditors: HuangJianYi
@Description: 京东会员表
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class JdMemberInfoModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False, cache_sub_table=None):
        super(JdMemberInfoModel, self).__init__(JdMemberInfo, sub_table, cache_sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class JdMemberInfo:
    def __init__(self):
        super(JdMemberInfo, self).__init__()
        self.id = 0  # id
        self.jd_one_id = ''  # 京东one_id
        self.business_id = 0  # 商家标识
        self.scheme_id = 0  # 会员体系标识
        self.one_id = ''  # one_id
        self.xid = ''  # xid
        self.member_type = 0  # 会员类型(1- 一方 2-全域 3-仅京东)
        self.bind_status = 0  # 绑定状态(0-只有一方注册 1-只有京东会员通注册 2-已匹配  3- 一方与京东会员通都解绑)
        self.business_type = 0  # 业务类型(0-不计算 1-初始计算 2-增量计算)
        self.create_date = '1970-01-01 00:00:00.000'  # 创建时间
        self.modify_date = '1970-01-01 00:00:00.000'  # 修改时间

    @classmethod
    def get_field_list(self):
        return ['id', 'jd_one_id', 'business_id', 'scheme_id', 'one_id', 'xid', 'member_type', 'bind_status', 'business_type', 'create_date', 'modify_date']

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "jd_member_info_tb"
