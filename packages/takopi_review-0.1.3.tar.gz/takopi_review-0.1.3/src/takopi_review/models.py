from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

ReviewMode = Literal["diff", "pr", "commit"]
FindingStatus = Literal["accepted", "needs-human-triage", "rejected"]


@dataclass(frozen=True, slots=True)
class ReviewerSpec:
    engine: str
    reviewer_id: str
    artifact_name: str


@dataclass(frozen=True, slots=True)
class InstructionSnippet:
    path: str
    content: str


@dataclass(frozen=True, slots=True)
class ReviewTarget:
    mode: ReviewMode
    reference: str
    label: str


@dataclass(frozen=True, slots=True)
class ReviewBundle:
    repo_root: str
    project: str | None
    branch: str | None
    cwd: str
    target: ReviewTarget
    focus_areas: tuple[str, ...]
    changed_files: tuple[str, ...]
    test_surface: tuple[str, ...]
    status_text: str
    diff_text: str
    instructions: tuple[InstructionSnippet, ...]


@dataclass(frozen=True, slots=True)
class ReviewFinding:
    reviewer: str
    title: str
    priority: int
    confidence: float
    file: str
    start_line: int
    end_line: int
    summary: str
    suggested_fix: str


@dataclass(frozen=True, slots=True)
class ReviewerOutput:
    reviewer: str
    raw_text: str
    artifact_name: str
    findings: tuple[ReviewFinding, ...] = ()
    testing_gaps: tuple[str, ...] = ()
    summary: str | None = None
    error: str | None = None


@dataclass(frozen=True, slots=True)
class ConsolidatedFinding:
    id: str
    status: FindingStatus
    reviewer_count: int
    reviewers: tuple[str, ...]
    title: str
    priority: int
    confidence: float
    file: str
    start_line: int
    end_line: int
    summary: str
    suggested_fix: str
    rationale: str
    occurrences: tuple[ReviewFinding, ...] = ()


@dataclass(frozen=True, slots=True)
class ReviewReport:
    run_id: str
    created_at: str
    bundle: ReviewBundle
    reviewers: tuple[str, ...]
    raw_outputs: tuple[ReviewerOutput, ...]
    findings: tuple[ConsolidatedFinding, ...]
    testing_gaps: tuple[str, ...]
    report_path: str
    raw_output_paths: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class VerificationResult:
    command: str | None
    status: Literal["passed", "failed", "skipped"]
    summary: str


@dataclass(frozen=True, slots=True)
class FixReport:
    source_run_id: str
    created_at: str
    engine: str
    finding_ids: tuple[str, ...]
    files_changed: tuple[str, ...]
    verification: tuple[VerificationResult, ...]
    residual_open_findings: tuple[str, ...]
    agent_summary: str
    report_path: str
