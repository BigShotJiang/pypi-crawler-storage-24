from __future__ import annotations

from dataclasses import dataclass

from takopi.api import CommandBackend, CommandContext, CommandResult, ConfigError

from takopi_review.config import ReviewConfig
from takopi_review.orchestrator import (
    ReviewError,
    execute_fix,
    execute_review,
    fix_report_markdown,
    review_report_markdown,
)


@dataclass(frozen=True, slots=True)
class ReviewOptions:
    reference: str
    focus_areas: tuple[str, ...]
    reviewers: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class FixOptions:
    run_id: str | None
    finding_ids: tuple[str, ...]
    engine_override: str | None


def _help_text() -> str:
    return "\n".join(
        (
            "review: orchestrate multi-agent code reviews",
            "",
            "Usage:",
            "  /review diff [--focus <area>]... [--reviewer <engine[:label]>]...",
            "  /review pr <number|url> [--focus <area>]... [--reviewer <engine[:label]>]...",
            "  /review commit <sha> [--focus <area>]... [--reviewer <engine[:label]>]...",
            "  /review fix [--run <run_id>] [--id <finding_id>]... [--engine <engine>]",
            "",
            "Examples:",
            "  /review diff --focus security --focus tests",
            "  /review diff --reviewer claude --reviewer claude --reviewer codex:security",
            "  /review pr 123 --focus performance --reviewer codex",
            "  /review fix --id RF-001",
        )
    )


def _review_started_text(*, target: str, config: ReviewConfig) -> str:
    reviewer_lines = "\n".join(
        f"- `{reviewer.reviewer_id}` ({reviewer.engine})"
        for reviewer in config.reviewers
    )
    count = len(config.reviewers)
    noun = "instance" if count == 1 else "instances"
    return "\n".join(
        (
            f"starting takopi review for {target}.",
            "",
            f"running {count} reviewer {noun} with max parallelism `{config.max_parallel_reviews}`:",
            reviewer_lines or "- (none)",
            "",
            "i'll post the consolidated review report when all reviewer runs finish.",
        )
    )


def _parse_review_options(args: tuple[str, ...], *, require_reference: bool) -> ReviewOptions:
    index = 0
    reference: str | None = None
    focus_areas: list[str] = []
    reviewers: list[str] = []
    while index < len(args):
        token = args[index]
        if token.startswith("--focus="):
            focus_areas.extend(
                value.strip().lower()
                for value in token.split("=", 1)[1].split(",")
                if value.strip()
            )
            index += 1
            continue
        if token == "--focus":
            index += 1
            if index >= len(args):
                raise ConfigError("Missing value for `--focus`.")
            focus_areas.extend(
                value.strip().lower()
                for value in args[index].split(",")
                if value.strip()
            )
            index += 1
            continue
        if token.startswith("--reviewer="):
            reviewers.extend(
                value.strip().lower()
                for value in token.split("=", 1)[1].split(",")
                if value.strip()
            )
            index += 1
            continue
        if token == "--reviewer":
            index += 1
            if index >= len(args):
                raise ConfigError("Missing value for `--reviewer`.")
            reviewers.extend(
                value.strip().lower()
                for value in args[index].split(",")
                if value.strip()
            )
            index += 1
            continue
        if token.startswith("--"):
            raise ConfigError(f"Unknown flag {token!r}.")
        if reference is None and require_reference:
            reference = token
            index += 1
            continue
        raise ConfigError(f"Unexpected argument {token!r}.")

    if require_reference and reference is None:
        raise ConfigError("Missing review reference.")
    if reference is None:
        reference = "HEAD"
    return ReviewOptions(
        reference=reference,
        focus_areas=tuple(dict.fromkeys(focus_areas)),
        reviewers=tuple(reviewers),
    )


def _parse_fix_options(args: tuple[str, ...]) -> FixOptions:
    index = 0
    run_id: str | None = None
    engine_override: str | None = None
    finding_ids: list[str] = []
    while index < len(args):
        token = args[index]
        if token.startswith("--run="):
            run_id = token.split("=", 1)[1].strip() or None
            index += 1
            continue
        if token == "--run":
            index += 1
            if index >= len(args):
                raise ConfigError("Missing value for `--run`.")
            run_id = args[index].strip() or None
            index += 1
            continue
        if token.startswith("--id="):
            finding_id = token.split("=", 1)[1].strip()
            if not finding_id:
                raise ConfigError("Missing value for `--id`.")
            finding_ids.append(finding_id)
            index += 1
            continue
        if token == "--id":
            index += 1
            if index >= len(args):
                raise ConfigError("Missing value for `--id`.")
            finding_ids.append(args[index].strip())
            index += 1
            continue
        if token.startswith("--engine="):
            engine_override = token.split("=", 1)[1].strip() or None
            index += 1
            continue
        if token == "--engine":
            index += 1
            if index >= len(args):
                raise ConfigError("Missing value for `--engine`.")
            engine_override = args[index].strip() or None
            index += 1
            continue
        raise ConfigError(f"Unexpected argument {token!r}.")
    return FixOptions(
        run_id=run_id,
        finding_ids=tuple(dict.fromkeys(finding_ids)),
        engine_override=engine_override.lower() if engine_override else None,
    )


class ReviewCommand:
    id = "review"
    description = "Run multi-agent reviews and apply accepted fixes"

    async def handle(self, ctx: CommandContext) -> CommandResult | None:
        try:
            return await self._handle(ctx)
        except (ConfigError, ReviewError) as exc:
            return CommandResult(text=f"review error: {exc}")

    async def _handle(self, ctx: CommandContext) -> CommandResult:
        if not ctx.args:
            return CommandResult(text=_help_text())

        subcommand = ctx.args[0].lower()
        if subcommand in {"help", "-h", "--help"}:
            return CommandResult(text=_help_text())

        if subcommand == "diff":
            options = _parse_review_options(ctx.args[1:], require_reference=False)
            config = ReviewConfig.from_plugin_config(
                ctx.plugin_config or {},
                reviewer_overrides=options.reviewers or None,
            )
            await ctx.executor.send(
                _review_started_text(target="the working tree diff", config=config),
                reply_to=ctx.message,
                notify=False,
            )
            report = await execute_review(
                ctx,
                mode="diff",
                reference=options.reference,
                focus_areas=options.focus_areas,
                config=config,
            )
            return CommandResult(text=review_report_markdown(report))

        if subcommand == "pr":
            options = _parse_review_options(ctx.args[1:], require_reference=True)
            config = ReviewConfig.from_plugin_config(
                ctx.plugin_config or {},
                reviewer_overrides=options.reviewers or None,
            )
            await ctx.executor.send(
                _review_started_text(
                    target=f"pull request `{options.reference}`",
                    config=config,
                ),
                reply_to=ctx.message,
                notify=False,
            )
            report = await execute_review(
                ctx,
                mode="pr",
                reference=options.reference,
                focus_areas=options.focus_areas,
                config=config,
            )
            return CommandResult(text=review_report_markdown(report))

        if subcommand == "commit":
            options = _parse_review_options(ctx.args[1:], require_reference=True)
            config = ReviewConfig.from_plugin_config(
                ctx.plugin_config or {},
                reviewer_overrides=options.reviewers or None,
            )
            await ctx.executor.send(
                _review_started_text(
                    target=f"commit `{options.reference}`",
                    config=config,
                ),
                reply_to=ctx.message,
                notify=False,
            )
            report = await execute_review(
                ctx,
                mode="commit",
                reference=options.reference,
                focus_areas=options.focus_areas,
                config=config,
            )
            return CommandResult(text=review_report_markdown(report))

        if subcommand == "fix":
            options = _parse_fix_options(ctx.args[1:])
            config = ReviewConfig.from_plugin_config(ctx.plugin_config or {})
            report = await execute_fix(
                ctx,
                config=config,
                run_id=options.run_id,
                finding_ids=options.finding_ids,
                engine_override=options.engine_override,
            )
            return CommandResult(text=fix_report_markdown(report))

        raise ConfigError(f"Unknown subcommand {subcommand!r}.")


BACKEND: CommandBackend = ReviewCommand()
