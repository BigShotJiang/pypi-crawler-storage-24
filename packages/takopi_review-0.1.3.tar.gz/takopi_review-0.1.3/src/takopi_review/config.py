from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import re
from typing import Any

from takopi.api import ConfigError

from takopi_review.models import ReviewerSpec

SUPPORTED_REVIEW_ENGINES = ("claude", "codex")
_LABEL_RE = re.compile(r"[^a-z0-9]+")


def _expect_bool(config: dict[str, Any], key: str, default: bool) -> bool:
    raw = config.get(key, default)
    if isinstance(raw, bool):
        return raw
    raise ConfigError(f"Invalid `plugins.review.{key}`; expected a boolean.")


def _expect_int(config: dict[str, Any], key: str, default: int) -> int:
    raw = config.get(key, default)
    if isinstance(raw, bool) or not isinstance(raw, int):
        raise ConfigError(f"Invalid `plugins.review.{key}`; expected an integer.")
    return raw


def _expect_str(config: dict[str, Any], key: str, default: str) -> str:
    raw = config.get(key, default)
    if isinstance(raw, str) and raw.strip():
        return raw.strip()
    raise ConfigError(f"Invalid `plugins.review.{key}`; expected a non-empty string.")


def _expect_str_list(
    config: dict[str, Any],
    key: str,
    default: tuple[str, ...],
) -> tuple[str, ...]:
    raw = config.get(key)
    if raw is None:
        return default
    if not isinstance(raw, list):
        raise ConfigError(f"Invalid `plugins.review.{key}`; expected a string[].")
    values: list[str] = []
    for item in raw:
        if not isinstance(item, str) or not item.strip():
            raise ConfigError(f"Invalid `plugins.review.{key}`; expected a string[].")
        values.append(item.strip().lower())
    if not values:
        raise ConfigError(f"Invalid `plugins.review.{key}`; expected at least one reviewer.")
    return tuple(values)


def _normalize_label(value: str) -> str:
    normalized = _LABEL_RE.sub("-", value.strip().lower()).strip("-")
    if normalized:
        return normalized
    raise ConfigError(
        "Invalid reviewer label; use letters, numbers, or simple separators."
    )


def _split_reviewer_token(token: str) -> tuple[str, str | None]:
    engine_part, separator, label_part = token.partition(":")
    engine = engine_part.strip().lower()
    if engine not in SUPPORTED_REVIEW_ENGINES:
        available = ", ".join(SUPPORTED_REVIEW_ENGINES)
        raise ConfigError(
            f"Unsupported review engine {engine!r}. Available: {available}."
        )
    if not separator:
        return engine, None
    return engine, _normalize_label(label_part)


def parse_reviewer_specs(tokens: tuple[str, ...]) -> tuple[ReviewerSpec, ...]:
    if not tokens:
        raise ConfigError("At least one review engine must be configured.")

    parsed = [_split_reviewer_token(token) for token in tokens]
    base_ids = [
        f"{engine}:{label}" if label is not None else engine
        for engine, label in parsed
    ]
    counts = Counter(base_ids)
    seen: defaultdict[str, int] = defaultdict(int)
    specs: list[ReviewerSpec] = []

    for (engine, _label), base_id in zip(parsed, base_ids, strict=True):
        if counts[base_id] == 1:
            reviewer_id = base_id
        else:
            seen[base_id] += 1
            reviewer_id = f"{base_id}#{seen[base_id]}"
        specs.append(
            ReviewerSpec(
                engine=engine,
                reviewer_id=reviewer_id,
                artifact_name=reviewer_id.replace(":", "-").replace("#", "-"),
            )
        )
    return tuple(specs)


@dataclass(frozen=True, slots=True)
class ReviewConfig:
    default_fixer: str = "codex"
    reviewers: tuple[ReviewerSpec, ...] = (
        ReviewerSpec(engine="claude", reviewer_id="claude", artifact_name="claude"),
        ReviewerSpec(engine="codex", reviewer_id="codex", artifact_name="codex"),
    )
    timeout_s: int = 900
    max_parallel_reviews: int = 3
    post_github_comments: bool = False
    auto_fix: bool = False
    report_dir: str = ".takopi/review"
    max_diff_chars: int = 120_000
    max_instruction_chars: int = 20_000
    max_untracked_file_chars: int = 12_000

    @classmethod
    def from_plugin_config(
        cls,
        raw_config: dict[str, Any],
        *,
        reviewer_overrides: tuple[str, ...] | None = None,
    ) -> ReviewConfig:
        config = dict(raw_config or {})
        timeout_s = _expect_int(config, "timeout_s", 900)
        if timeout_s <= 0:
            raise ConfigError("Invalid `plugins.review.timeout_s`; expected > 0.")
        max_parallel_reviews = _expect_int(config, "max_parallel_reviews", 3)
        if max_parallel_reviews <= 0:
            raise ConfigError(
                "Invalid `plugins.review.max_parallel_reviews`; expected > 0."
            )
        reviewers = (
            reviewer_overrides
            if reviewer_overrides
            else _expect_str_list(config, "reviewers", ("claude", "codex"))
        )
        return cls(
            default_fixer=_expect_str(config, "default_fixer", "codex").lower(),
            reviewers=parse_reviewer_specs(reviewers),
            timeout_s=timeout_s,
            max_parallel_reviews=max_parallel_reviews,
            post_github_comments=_expect_bool(config, "post_github_comments", False),
            auto_fix=_expect_bool(config, "auto_fix", False),
            report_dir=_expect_str(config, "report_dir", ".takopi/review"),
        )
