from __future__ import annotations

import asyncio
import json
import re
import shutil
import subprocess
import textwrap
import uuid
from dataclasses import asdict, replace
from datetime import UTC, datetime
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

from takopi.api import CommandContext, RunContext, RunRequest

from takopi_review.config import ReviewConfig
from takopi_review.models import (
    ConsolidatedFinding,
    FixReport,
    FindingStatus,
    InstructionSnippet,
    ReviewBundle,
    ReviewFinding,
    ReviewReport,
    ReviewerSpec,
    ReviewerOutput,
    ReviewTarget,
    VerificationResult,
)

_CODE_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)
_WORD_RE = re.compile(r"[a-z0-9]+")
_TEST_FILE_PATTERNS = (
    "test_{stem}.py",
    "{stem}_test.py",
    "{stem}.test.ts",
    "{stem}.test.tsx",
    "{stem}.test.js",
    "{stem}.test.jsx",
    "{stem}.spec.ts",
    "{stem}.spec.tsx",
    "{stem}.spec.js",
    "{stem}.spec.jsx",
)


class ReviewError(RuntimeError):
    pass


def _coerce_chat_id(value: Any) -> int | None:
    if isinstance(value, int):
        return value
    return None


def _utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def _make_run_id() -> str:
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    return f"{stamp}-{uuid.uuid4().hex[:8]}"


def _git(repo_root: Path, *args: str, check: bool = True) -> str:
    proc = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if check and proc.returncode != 0:
        stderr = proc.stderr.strip() or proc.stdout.strip() or "git command failed"
        raise ReviewError(stderr)
    return proc.stdout


def _gh(*args: str, cwd: Path, check: bool = True) -> str:
    if shutil.which("gh") is None:
        raise ReviewError("`gh` is required for `/review pr`, but it is not installed.")
    proc = subprocess.run(
        ["gh", *args],
        cwd=cwd,
        check=False,
        capture_output=True,
        text=True,
    )
    if check and proc.returncode != 0:
        stderr = proc.stderr.strip() or proc.stdout.strip() or "gh command failed"
        raise ReviewError(stderr)
    return proc.stdout


def _relative_path(path: Path, *, repo_root: Path) -> str:
    try:
        return path.relative_to(repo_root).as_posix()
    except ValueError:
        return path.as_posix()


def _trim(text: str, *, limit: int) -> str:
    if len(text) <= limit:
        return text
    omitted = len(text) - limit
    return f"{text[:limit]}\n\n[truncated {omitted} chars]"


def _dedupe(values: list[str]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(values))


def _find_repo_root(path: Path) -> Path:
    proc = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        cwd=path,
        check=False,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        stderr = proc.stderr.strip() or "not inside a git repository"
        raise ReviewError(stderr)
    return Path(proc.stdout.strip())


def _runtime_context(ctx: CommandContext) -> tuple[RunContext | None, Path]:
    ambient: RunContext | None = None
    executor_context = getattr(ctx.executor, "default_context", None)
    if isinstance(executor_context, RunContext):
        ambient = executor_context
    chat_id = _coerce_chat_id(ctx.message.channel_id)
    if ambient is None and hasattr(ctx.runtime, "default_context_for_chat"):
        ambient = ctx.runtime.default_context_for_chat(chat_id)
    context = ambient
    if hasattr(ctx.runtime, "resolve_message"):
        try:
            resolved = ctx.runtime.resolve_message(
                text=ctx.text,
                reply_text=ctx.reply_text,
                ambient_context=ambient,
                chat_id=chat_id,
            )
        except RuntimeError:
            resolved = None
        if resolved is not None and isinstance(resolved.context, RunContext):
            context = resolved.context
    cwd: Path | None = None
    if hasattr(ctx.runtime, "resolve_run_cwd"):
        try:
            cwd = ctx.runtime.resolve_run_cwd(context)
        except RuntimeError:
            cwd = None
    if cwd is None:
        cwd = Path.cwd()
    return context, Path(cwd)


def _collect_status(repo_root: Path) -> tuple[str, tuple[str, ...], tuple[str, ...]]:
    status_text = _git(repo_root, "status", "--short", "--untracked-files=all").strip()
    changed: list[str] = []
    untracked: list[str] = []
    for line in status_text.splitlines():
        if len(line) < 4:
            continue
        raw_path = line[3:]
        path = raw_path.split(" -> ", 1)[-1].strip()
        if not path:
            continue
        changed.append(path)
        if line.startswith("??"):
            untracked.append(path)
    return status_text, _dedupe(changed), _dedupe(untracked)


def _capture_untracked(repo_root: Path, paths: tuple[str, ...], *, max_chars: int) -> str:
    blocks: list[str] = []
    for rel_path in paths:
        file_path = repo_root / rel_path
        if not file_path.is_file():
            continue
        try:
            content = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        excerpt = _trim(content, limit=max_chars)
        blocks.append(
            "\n".join(
                (
                    f"## new file: {rel_path}",
                    "```",
                    excerpt,
                    "```",
                )
            )
        )
    return "\n\n".join(blocks)


def _collect_diff_text(
    repo_root: Path,
    *,
    mode: str,
    reference: str,
    max_chars: int,
    max_untracked_file_chars: int,
) -> tuple[str, tuple[str, ...], str]:
    status_text, changed_files, untracked = _collect_status(repo_root)
    if mode == "diff":
        if not changed_files:
            raise ReviewError("No local changes to review.")
        staged = _git(
            repo_root,
            "diff",
            "--cached",
            "--no-ext-diff",
            "--relative",
            "--unified=3",
            check=False,
        ).strip()
        unstaged = _git(
            repo_root,
            "diff",
            "--no-ext-diff",
            "--relative",
            "--unified=3",
            check=False,
        ).strip()
        diff_blocks: list[str] = []
        if staged:
            diff_blocks.append(f"## staged diff\n\n```diff\n{staged}\n```")
        if unstaged:
            diff_blocks.append(f"## unstaged diff\n\n```diff\n{unstaged}\n```")
        untracked_block = _capture_untracked(
            repo_root,
            untracked,
            max_chars=max_untracked_file_chars,
        )
        if untracked_block:
            diff_blocks.append(untracked_block)
        diff_text = "\n\n".join(diff_blocks).strip()
        if not diff_text:
            diff_text = "No textual diff available; inspect git status for details."
        return _trim(diff_text, limit=max_chars), changed_files, status_text

    if mode == "commit":
        diff_text = _git(
            repo_root,
            "show",
            "--no-ext-diff",
            "--relative",
            "--stat",
            "--format=medium",
            "--unified=3",
            reference,
        ).strip()
        names = _git(repo_root, "show", "--format=", "--name-only", reference).splitlines()
        changed = _dedupe([line.strip() for line in names if line.strip()])
        return _trim(diff_text, limit=max_chars), changed, status_text

    if mode == "pr":
        diff_text = _gh("pr", "diff", reference, "--patch", cwd=repo_root).strip()
        changed: tuple[str, ...]
        try:
            view_payload = json.loads(
                _gh(
                    "pr",
                    "view",
                    reference,
                    "--json",
                    "files,title,url,headRefName,baseRefName",
                    cwd=repo_root,
                )
            )
            changed = tuple(
                dict.fromkeys(
                    file_info["path"]
                    for file_info in view_payload.get("files", [])
                    if isinstance(file_info.get("path"), str)
                )
            )
        except (ReviewError, TypeError, KeyError, json.JSONDecodeError):
            changed = _dedupe(
                [
                    match.group(1)
                    for match in re.finditer(
                        r"^diff --git a/(.*?) b/.*?$",
                        diff_text,
                        flags=re.MULTILINE,
                    )
                ]
            )
        return _trim(diff_text, limit=max_chars), changed, status_text

    raise ReviewError(f"Unsupported review mode {mode!r}.")


def _current_branch(repo_root: Path) -> str | None:
    branch = _git(repo_root, "branch", "--show-current", check=False).strip()
    return branch or None


def _collect_instructions(repo_root: Path, *, max_chars: int) -> tuple[InstructionSnippet, ...]:
    candidates = (
        repo_root / "AGENTS.md",
        repo_root / "CLAUDE.md",
        repo_root / "CONTINUITY.md",
        repo_root / ".github" / "copilot-instructions.md",
        repo_root / "README.md",
    )
    snippets: list[InstructionSnippet] = []
    for candidate in candidates:
        if not candidate.is_file():
            continue
        try:
            content = candidate.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        snippets.append(
            InstructionSnippet(
                path=_relative_path(candidate, repo_root=repo_root),
                content=_trim(content, limit=max_chars),
            )
        )
    return tuple(snippets)


def _is_test_path(path: str) -> bool:
    lowered = path.lower()
    return (
        "/tests/" in lowered
        or lowered.startswith("tests/")
        or lowered.startswith("test_")
        or lowered.endswith("_test.py")
        or ".test." in lowered
        or ".spec." in lowered
    )


def _infer_test_surface(repo_root: Path, changed_files: tuple[str, ...]) -> tuple[str, ...]:
    changed_tests = [path for path in changed_files if _is_test_path(path)]
    if changed_tests:
        return _dedupe(changed_tests)

    candidates: list[str] = []
    for rel_path in changed_files:
        path = Path(rel_path)
        stem = path.stem
        search_roots = (path.parent, repo_root / "tests", repo_root / path.parent / "__tests__")
        for root in search_roots:
            base = root if root.is_absolute() else repo_root / root
            if not base.exists():
                continue
            for pattern in _TEST_FILE_PATTERNS:
                candidate = base / pattern.format(stem=stem)
                if candidate.is_file():
                    candidates.append(_relative_path(candidate, repo_root=repo_root))
    return _dedupe(candidates)


def _target_label(mode: str, reference: str) -> str:
    if mode == "diff":
        return "working tree diff"
    if mode == "pr":
        return f"pull request {reference}"
    return f"commit {reference}"


def _build_bundle(
    ctx: CommandContext,
    *,
    mode: str,
    reference: str,
    focus_areas: tuple[str, ...],
    config: ReviewConfig,
) -> ReviewBundle:
    ambient_context, cwd = _runtime_context(ctx)
    repo_root = _find_repo_root(cwd)
    branch = _current_branch(repo_root)
    diff_text, changed_files, status_text = _collect_diff_text(
        repo_root,
        mode=mode,
        reference=reference,
        max_chars=config.max_diff_chars,
        max_untracked_file_chars=config.max_untracked_file_chars,
    )
    if not changed_files and mode == "diff":
        raise ReviewError("No changed files resolved for the current diff.")

    run_branch = ambient_context.branch if ambient_context is not None else None
    if run_branch is None:
        run_branch = branch
    return ReviewBundle(
        repo_root=repo_root.as_posix(),
        project=ambient_context.project if ambient_context is not None else None,
        branch=run_branch,
        cwd=cwd.as_posix(),
        target=ReviewTarget(mode=mode, reference=reference, label=_target_label(mode, reference)),
        focus_areas=focus_areas,
        changed_files=changed_files,
        test_surface=_infer_test_surface(repo_root, changed_files),
        status_text=status_text,
        diff_text=diff_text,
        instructions=_collect_instructions(
            repo_root,
            max_chars=config.max_instruction_chars,
        ),
    )


def _build_run_context(bundle: ReviewBundle) -> RunContext | None:
    if bundle.project is None and bundle.branch is None:
        return None
    return RunContext(project=bundle.project, branch=bundle.branch)


def _bundle_prompt(bundle: ReviewBundle) -> str:
    instruction_blocks = [
        f"### {snippet.path}\n\n{snippet.content}" for snippet in bundle.instructions
    ]
    instructions = "\n\n".join(instruction_blocks) if instruction_blocks else "(none)"
    changed = "\n".join(f"- {path}" for path in bundle.changed_files) or "- (none)"
    test_surface = "\n".join(f"- {path}" for path in bundle.test_surface) or "- (none inferred)"
    focus = ", ".join(bundle.focus_areas) if bundle.focus_areas else "none"
    return textwrap.dedent(
        f"""\
        Review target: {bundle.target.label}
        Repo root: {bundle.repo_root}
        Branch: {bundle.branch or "(unknown)"}
        Focus areas: {focus}

        Changed files:
        {changed}

        Suggested test surface:
        {test_surface}

        Git status:
        {bundle.status_text or "(clean)"}

        Repo instructions:
        {instructions}

        Diff bundle:
        {bundle.diff_text}
        """
    ).strip()


def _review_prompt(bundle: ReviewBundle, *, reviewer: ReviewerSpec) -> str:
    schema = {
        "summary": "short string",
        "testing_gaps": ["string"],
        "findings": [
            {
                "title": "short finding title",
                "priority": 0,
                "confidence": 0.0,
                "file": "relative/path.py",
                "start_line": 1,
                "end_line": 1,
                "summary": "why this matters",
                "suggested_fix": "concrete fix",
            }
        ],
    }
    return textwrap.dedent(
        f"""\
        You are reviewer instance `{reviewer.reviewer_id}` running on the `{reviewer.engine}` engine in Takopi's multi-review pipeline.
        Review only the supplied bundle. Do not assume unstated files or runtime behavior.
        Return JSON only. No markdown fences. No prose before or after the JSON.

        Rules:
        - Emit at most 12 findings.
        - Use priority 0-3 where 0 is most severe.
        - Use confidence as a float from 0 to 1.
        - Only include findings grounded in the supplied diff or new-file snapshots.
        - File paths must be repo-relative.
        - If there are no issues, return an empty findings list.
        - Put testing gaps that should still be exercised in `testing_gaps`.

        Output schema:
        {json.dumps(schema, indent=2)}

        Review bundle:
        {_bundle_prompt(bundle)}
        """
    ).strip()


def _extract_json_blob(raw_text: str) -> str:
    stripped = raw_text.strip()
    for match in _CODE_FENCE_RE.finditer(stripped):
        candidate = match.group(1).strip()
        if not candidate:
            continue
        try:
            json.loads(candidate)
        except json.JSONDecodeError:
            continue
        return candidate

    for opener, closer in (("{", "}"), ("[", "]")):
        start = stripped.find(opener)
        end = stripped.rfind(closer)
        if start == -1 or end == -1 or end <= start:
            continue
        candidate = stripped[start : end + 1]
        try:
            json.loads(candidate)
        except json.JSONDecodeError:
            continue
        return candidate
    raise ReviewError("Reviewer output was not valid JSON.")


def _coerce_priority(value: Any) -> int:
    try:
        priority = int(value)
    except (TypeError, ValueError):
        return 2
    return min(3, max(0, priority))


def _coerce_confidence(value: Any) -> float:
    try:
        confidence = float(value)
    except (TypeError, ValueError):
        return 0.5
    return min(1.0, max(0.0, confidence))


def _coerce_line(value: Any, *, default: int = 1) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return max(1, number)


def _normalize_file_path(raw_path: Any, *, repo_root: Path) -> str:
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ReviewError("Reviewer finding is missing a file path.")
    raw = raw_path.strip()
    path = Path(raw)
    if path.is_absolute():
        return _relative_path(path, repo_root=repo_root)
    return path.as_posix()


def _parse_reviewer_output(
    *,
    reviewer: str,
    raw_text: str,
    repo_root: Path,
    artifact_name: str,
) -> ReviewerOutput:
    blob = _extract_json_blob(raw_text)
    payload = json.loads(blob)
    if isinstance(payload, list):
        findings_payload = payload
        testing_gaps_payload: list[Any] = []
        summary = None
    elif isinstance(payload, dict):
        findings_payload = payload.get("findings", [])
        testing_gaps_payload = payload.get("testing_gaps", [])
        raw_summary = payload.get("summary")
        summary = raw_summary.strip() if isinstance(raw_summary, str) else None
    else:
        raise ReviewError("Reviewer output must be a JSON object or array.")

    if not isinstance(findings_payload, list):
        raise ReviewError("Reviewer `findings` must be a JSON array.")

    findings: list[ReviewFinding] = []
    for raw_finding in findings_payload:
        if not isinstance(raw_finding, dict):
            continue
        try:
            file_path = _normalize_file_path(raw_finding.get("file"), repo_root=repo_root)
            start_line = _coerce_line(raw_finding.get("start_line"), default=1)
            end_line = _coerce_line(raw_finding.get("end_line"), default=start_line)
            findings.append(
                ReviewFinding(
                    reviewer=reviewer,
                    title=str(raw_finding.get("title", "Untitled finding")).strip()
                    or "Untitled finding",
                    priority=_coerce_priority(raw_finding.get("priority")),
                    confidence=_coerce_confidence(raw_finding.get("confidence")),
                    file=file_path,
                    start_line=start_line,
                    end_line=max(start_line, end_line),
                    summary=str(raw_finding.get("summary", "")).strip(),
                    suggested_fix=str(raw_finding.get("suggested_fix", "")).strip(),
                )
            )
        except ReviewError:
            continue

    testing_gaps = tuple(
        item.strip()
        for item in testing_gaps_payload
        if isinstance(item, str) and item.strip()
    )
    return ReviewerOutput(
        reviewer=reviewer,
        raw_text=raw_text,
        artifact_name=artifact_name,
        findings=tuple(findings),
        testing_gaps=testing_gaps,
        summary=summary,
    )


async def _run_single_review(
    ctx: CommandContext,
    *,
    reviewer: ReviewerSpec,
    bundle: ReviewBundle,
    config: ReviewConfig,
) -> ReviewerOutput:
    request = RunRequest(
        prompt=_review_prompt(bundle, reviewer=reviewer),
        engine=reviewer.engine,
        context=_build_run_context(bundle),
    )
    try:
        result = await asyncio.wait_for(
            ctx.executor.run_one(request, mode="capture"),
            timeout=config.timeout_s,
        )
    except (RuntimeError, TimeoutError) as exc:
        return ReviewerOutput(
            reviewer=reviewer.reviewer_id,
            raw_text="",
            artifact_name=reviewer.artifact_name,
            error=str(exc) or exc.__class__.__name__,
        )
    message = result.message.text if result.message is not None else ""
    try:
        return _parse_reviewer_output(
            reviewer=reviewer.reviewer_id,
            raw_text=message,
            repo_root=Path(bundle.repo_root),
            artifact_name=reviewer.artifact_name,
        )
    except ReviewError as exc:
        return ReviewerOutput(
            reviewer=reviewer.reviewer_id,
            raw_text=message,
            artifact_name=reviewer.artifact_name,
            error=str(exc) or exc.__class__.__name__,
        )


async def _run_reviews(
    ctx: CommandContext,
    *,
    bundle: ReviewBundle,
    config: ReviewConfig,
) -> tuple[ReviewerOutput, ...]:
    semaphore = asyncio.Semaphore(config.max_parallel_reviews)

    async def _guarded(reviewer: ReviewerSpec) -> ReviewerOutput:
        async with semaphore:
            return await _run_single_review(
                ctx,
                reviewer=reviewer,
                bundle=bundle,
                config=config,
            )

    tasks = [asyncio.create_task(_guarded(reviewer)) for reviewer in config.reviewers]
    return tuple(await asyncio.gather(*tasks))


def _normalized_text(value: str) -> str:
    return " ".join(_WORD_RE.findall(value.lower()))


def _semantic_similarity(left: ReviewFinding, right: ReviewFinding) -> float:
    left_text = _normalized_text(f"{left.title} {left.summary}")
    right_text = _normalized_text(f"{right.title} {right.summary}")
    return SequenceMatcher(None, left_text, right_text).ratio()


def _line_overlap(left: ReviewFinding, right: ReviewFinding) -> bool:
    return not (left.end_line < right.start_line - 3 or right.end_line < left.start_line - 3)


def _is_duplicate(left: ReviewFinding, right: ReviewFinding) -> bool:
    if left.file != right.file:
        return False
    return (
        _line_overlap(left, right) and _semantic_similarity(left, right) >= 0.35
    ) or (
        abs(left.start_line - right.start_line) <= 2
        and _semantic_similarity(left, right) >= 0.55
    )


def _cluster_findings(findings: tuple[ReviewFinding, ...]) -> list[list[ReviewFinding]]:
    clusters: list[list[ReviewFinding]] = []
    for finding in findings:
        matches = [index for index, cluster in enumerate(clusters) if any(_is_duplicate(finding, item) for item in cluster)]
        if not matches:
            clusters.append([finding])
            continue
        first = matches[0]
        clusters[first].append(finding)
        for index in reversed(matches[1:]):
            clusters[first].extend(clusters.pop(index))
    return clusters


def _focus_score(finding: ReviewFinding, focus_areas: tuple[str, ...]) -> int:
    if not focus_areas:
        return 0
    haystack = _normalized_text(
        f"{finding.file} {finding.title} {finding.summary} {finding.suggested_fix}"
    )
    return sum(1 for area in focus_areas if area.lower() in haystack)


def _status_for_cluster(
    *,
    reviewers: tuple[str, ...],
    avg_confidence: float,
    min_priority: int,
) -> tuple[FindingStatus, str]:
    reviewer_count = len(reviewers)
    if reviewer_count >= 2 and avg_confidence >= 0.60:
        return (
            "accepted",
            f"reported by {', '.join(reviewers)} with {avg_confidence:.2f} average confidence",
        )
    if reviewer_count == 1 and min_priority <= 1 and avg_confidence >= 0.90:
        return (
            "accepted",
            f"high-severity single-reviewer finding with {avg_confidence:.2f} confidence",
        )
    if avg_confidence < 0.45:
        return (
            "rejected",
            f"average confidence {avg_confidence:.2f} stayed below the rejection threshold",
        )
    return (
        "needs-human-triage",
        f"insufficient reviewer agreement ({reviewer_count}) for automatic acceptance",
    )


def _consolidate_findings(
    *,
    bundle: ReviewBundle,
    outputs: tuple[ReviewerOutput, ...],
) -> tuple[ConsolidatedFinding, ...]:
    all_findings = tuple(
        finding
        for output in outputs
        for finding in output.findings
    )
    clusters = _cluster_findings(all_findings)
    consolidated: list[ConsolidatedFinding] = []

    for cluster in clusters:
        sorted_cluster = sorted(
            cluster,
            key=lambda item: (
                item.priority,
                -item.confidence,
                item.file,
                item.start_line,
            ),
        )
        canonical = sorted_cluster[0]
        cluster_reviewers = tuple(dict.fromkeys(item.reviewer for item in cluster))
        avg_confidence = round(
            sum(item.confidence for item in cluster) / max(1, len(cluster)),
            2,
        )
        min_priority = min(item.priority for item in cluster)
        status, rationale = _status_for_cluster(
            reviewers=cluster_reviewers,
            avg_confidence=avg_confidence,
            min_priority=min_priority,
        )
        consolidated.append(
            ConsolidatedFinding(
                id="",
                status=status,
                reviewer_count=len(cluster_reviewers),
                reviewers=cluster_reviewers,
                title=canonical.title,
                priority=min_priority,
                confidence=avg_confidence,
                file=canonical.file,
                start_line=canonical.start_line,
                end_line=canonical.end_line,
                summary=canonical.summary,
                suggested_fix=canonical.suggested_fix,
                rationale=rationale,
                occurrences=tuple(cluster),
            )
        )

    status_rank = {"accepted": 0, "needs-human-triage": 1, "rejected": 2}
    consolidated.sort(
        key=lambda item: (
            status_rank[item.status],
            item.priority,
            -max(_focus_score(occurrence, bundle.focus_areas) for occurrence in item.occurrences),
            -item.reviewer_count,
            -item.confidence,
            item.file,
            item.start_line,
        )
    )

    finalized: list[ConsolidatedFinding] = []
    for index, finding in enumerate(consolidated, start=1):
        finalized.append(replace(finding, id=f"RF-{index:03d}"))
    return tuple(finalized)


def _testing_gaps(
    bundle: ReviewBundle,
    outputs: tuple[ReviewerOutput, ...],
) -> tuple[str, ...]:
    gaps: list[str] = []
    for output in outputs:
        gaps.extend(output.testing_gaps)

    if bundle.changed_files:
        changed_tests = [path for path in bundle.changed_files if _is_test_path(path)]
        production = [path for path in bundle.changed_files if not _is_test_path(path)]
        if production and not changed_tests:
            gaps.append(
                "Changed production files do not include matching test edits in the diff."
            )
        if bundle.test_surface and not changed_tests:
            gaps.append(
                f"Suggested test surface was inferred but not changed: {', '.join(bundle.test_surface)}."
            )
    return _dedupe(gaps)


def _review_root_for_repo(repo_root: Path, config: ReviewConfig) -> Path:
    report_dir = Path(config.report_dir)
    if report_dir.is_absolute():
        return report_dir
    return repo_root / report_dir


def _audit_root(repo_root: Path, run_id: str, config: ReviewConfig) -> Path:
    return _review_root_for_repo(repo_root, config) / run_id


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _render_review_report(report: ReviewReport) -> str:
    lines: list[str] = [
        "# Takopi Review Report",
        "",
        f"- Run ID: `{report.run_id}`",
        f"- Target: `{report.bundle.target.label}`",
        f"- Branch: `{report.bundle.branch or '(unknown)'}`",
        f"- Changed files: {len(report.bundle.changed_files)}",
        f"- Reviewers: {', '.join(report.reviewers)}",
        f"- Audit dir: `{Path(report.report_path).parent.as_posix()}`",
    ]
    if report.bundle.focus_areas:
        lines.append(f"- Focus areas: {', '.join(report.bundle.focus_areas)}")
    lines.extend(("", "## Consolidated Findings", ""))
    lines.append("| ID | Status | Priority | Agreement | Confidence | Location | Title |")
    lines.append("| --- | --- | --- | --- | --- | --- | --- |")
    if report.findings:
        for finding in report.findings:
            location = f"{finding.file}:{finding.start_line}"
            agreement = ", ".join(finding.reviewers)
            lines.append(
                "| {id} | {status} | P{priority} | {agreement} | {confidence:.2f} | {location} | {title} |".format(
                    id=finding.id,
                    status=finding.status,
                    priority=finding.priority,
                    agreement=agreement,
                    confidence=finding.confidence,
                    location=location,
                    title=finding.title.replace("|", "/"),
                )
            )
    else:
        lines.append("No findings.")

    lines.extend(("", "## Agreement Matrix", ""))
    matrix_reviewers = list(report.reviewers)
    header = "| ID | " + " | ".join(matrix_reviewers) + " |"
    divider = "| --- | " + " | ".join("---" for _ in matrix_reviewers) + " |"
    lines.extend((header, divider))
    if report.findings:
        for finding in report.findings:
            row = ["Y" if reviewer in finding.reviewers else "" for reviewer in matrix_reviewers]
            lines.append(f"| {finding.id} | " + " | ".join(row) + " |")
    else:
        lines.append("| (none) |" + " |" * len(matrix_reviewers))

    lines.extend(("", "## Recommended Fix Order", ""))
    accepted = [finding for finding in report.findings if finding.status == "accepted"]
    triage = [
        finding for finding in report.findings if finding.status == "needs-human-triage"
    ]
    rejected = [finding for finding in report.findings if finding.status == "rejected"]
    ranked = accepted + triage + rejected
    if ranked:
        for index, finding in enumerate(ranked, start=1):
            lines.append(
                f"{index}. `{finding.id}` `{finding.file}:{finding.start_line}` {finding.title} ({finding.status}, {finding.confidence:.2f})"
            )
    else:
        lines.append("No fixes recommended.")

    lines.extend(("", "## Testing Gaps", ""))
    if report.testing_gaps:
        lines.extend(f"- {gap}" for gap in report.testing_gaps)
    else:
        lines.append("- None identified.")

    errors = [output for output in report.raw_outputs if output.error]
    if errors:
        lines.extend(("", "## Reviewer Errors", ""))
        lines.extend(f"- `{output.reviewer}`: {output.error}" for output in errors)

    return "\n".join(lines)


def _persist_review_report(report: ReviewReport, *, config: ReviewConfig) -> ReviewReport:
    repo_root = Path(report.bundle.repo_root)
    audit_root = _audit_root(repo_root, report.run_id, config)
    audit_root.mkdir(parents=True, exist_ok=True)

    raw_paths: list[str] = []
    for output in report.raw_outputs:
        raw_path = audit_root / "raw" / f"{output.artifact_name}.txt"
        raw_path.parent.mkdir(parents=True, exist_ok=True)
        raw_path.write_text(output.raw_text or "", encoding="utf-8")
        raw_paths.append(raw_path.as_posix())

    bundle_path = audit_root / "bundle.json"
    report_path = audit_root / "report.md"
    json_path = audit_root / "report.json"
    persisted_report = replace(
        report,
        report_path=report_path.as_posix(),
        raw_output_paths=tuple(raw_paths),
    )
    _write_json(bundle_path, asdict(report.bundle))
    report_path.write_text(_render_review_report(persisted_report), encoding="utf-8")
    _write_json(json_path, asdict(persisted_report))
    latest_path = _review_root_for_repo(repo_root, config) / "latest.json"
    _write_json(
        latest_path,
        {
            "run_id": report.run_id,
            "report_json": json_path.as_posix(),
            "report_md": report_path.as_posix(),
        },
    )
    return persisted_report


def _load_saved_report(
    repo_root: Path,
    *,
    config: ReviewConfig,
    run_id: str | None,
) -> dict[str, Any]:
    review_root = _review_root_for_repo(repo_root, config)
    if run_id is not None:
        report_path = review_root / run_id / "report.json"
        if not report_path.is_file():
            raise ReviewError(f"Saved review run `{run_id}` was not found.")
        return json.loads(report_path.read_text(encoding="utf-8"))

    latest_path = review_root / "latest.json"
    if not latest_path.is_file():
        raise ReviewError("No saved review run found for this repo.")
    latest_payload = json.loads(latest_path.read_text(encoding="utf-8"))
    report_json = latest_payload.get("report_json")
    if not isinstance(report_json, str) or not report_json:
        raise ReviewError("Saved review metadata is invalid.")
    report_path = Path(report_json)
    if not report_path.is_file():
        raise ReviewError("Saved review JSON is missing.")
    return json.loads(report_path.read_text(encoding="utf-8"))


def _serialize_findings_for_fix(findings: tuple[dict[str, Any], ...]) -> str:
    return json.dumps(findings, indent=2)


def _render_fix_report(report: FixReport) -> str:
    lines = [
        "# Takopi Fix Report",
        "",
        f"- Source review run: `{report.source_run_id}`",
        f"- Fixer engine: `{report.engine}`",
        f"- Findings addressed: {', '.join(report.finding_ids) if report.finding_ids else '(none)'}",
        f"- Report path: `{report.report_path}`",
        "",
        "## Files Changed",
    ]
    if report.files_changed:
        lines.extend(f"- {path}" for path in report.files_changed)
    else:
        lines.append("- No file changes detected.")

    lines.extend(("", "## Verification", ""))
    if report.verification:
        for result in report.verification:
            command = result.command or "(none)"
            lines.append(f"- `{result.status}` `{command}`: {result.summary}")
    else:
        lines.append("- No verification recorded.")

    lines.extend(("", "## Residual Open Findings", ""))
    if report.residual_open_findings:
        lines.extend(f"- {finding_id}" for finding_id in report.residual_open_findings)
    else:
        lines.append("- None.")

    lines.extend(("", "## Agent Summary", "", report.agent_summary or "(no summary)"))
    return "\n".join(lines)


def _persist_fix_report(
    *,
    review_payload: dict[str, Any],
    report: FixReport,
    repo_root: Path,
    config: ReviewConfig,
) -> FixReport:
    run_id = str(review_payload["run_id"])
    audit_root = _audit_root(repo_root, run_id, config)
    audit_root.mkdir(parents=True, exist_ok=True)
    json_path = audit_root / "fix-report.json"
    md_path = audit_root / "fix-report.md"
    persisted_report = replace(report, report_path=md_path.as_posix())
    _write_json(json_path, asdict(persisted_report))
    md_path.write_text(_render_fix_report(persisted_report), encoding="utf-8")
    return persisted_report


def _verification_command(repo_root: Path, *, test_surface: tuple[str, ...]) -> list[str] | None:
    if shutil.which("pytest") is None:
        return None
    if test_surface and all((repo_root / path).exists() for path in test_surface):
        return ["pytest", "-q", *test_surface]
    if (repo_root / "tests").exists() or (repo_root / "pyproject.toml").exists():
        return ["pytest", "-q"]
    return None


def _run_verification(
    repo_root: Path,
    *,
    test_surface: tuple[str, ...],
) -> tuple[VerificationResult, ...]:
    command = _verification_command(repo_root, test_surface=test_surface)
    if command is None:
        return (
            VerificationResult(
                command=None,
                status="skipped",
                summary="No verification strategy available for this repo.",
            ),
        )
    proc = subprocess.run(
        command,
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
    )
    output = proc.stdout.strip() or proc.stderr.strip() or "No output."
    summary = _trim(output, limit=2_000)
    status = "passed" if proc.returncode == 0 else "failed"
    return (
        VerificationResult(
            command=" ".join(command),
            status=status,
            summary=summary,
        ),
    )


async def execute_review(
    ctx: CommandContext,
    *,
    mode: str,
    reference: str,
    focus_areas: tuple[str, ...],
    config: ReviewConfig,
) -> ReviewReport:
    bundle = _build_bundle(
        ctx,
        mode=mode,
        reference=reference,
        focus_areas=focus_areas,
        config=config,
    )
    outputs = await _run_reviews(ctx, bundle=bundle, config=config)
    findings = _consolidate_findings(
        bundle=bundle,
        outputs=outputs,
    )
    report = ReviewReport(
        run_id=_make_run_id(),
        created_at=_utc_now(),
        bundle=bundle,
        reviewers=tuple(reviewer.reviewer_id for reviewer in config.reviewers),
        raw_outputs=outputs,
        findings=findings,
        testing_gaps=_testing_gaps(bundle, outputs),
        report_path="",
    )
    return _persist_review_report(report, config=config)


async def execute_fix(
    ctx: CommandContext,
    *,
    config: ReviewConfig,
    run_id: str | None,
    finding_ids: tuple[str, ...],
    engine_override: str | None,
) -> FixReport:
    ambient_context, cwd = _runtime_context(ctx)
    repo_root = _find_repo_root(cwd)
    review_payload = _load_saved_report(repo_root, config=config, run_id=run_id)

    findings_payload = review_payload.get("findings", [])
    if not isinstance(findings_payload, list):
        raise ReviewError("Saved review findings are invalid.")
    accepted = [
        finding
        for finding in findings_payload
        if finding.get("status") == "accepted"
    ]
    if finding_ids:
        accepted = [finding for finding in accepted if finding.get("id") in finding_ids]
    if not accepted:
        raise ReviewError("No accepted findings matched `/review fix`.")

    bundle_payload = review_payload.get("bundle", {})
    bundle_test_surface = tuple(bundle_payload.get("test_surface", []))
    residual_open = tuple(
        finding["id"]
        for finding in findings_payload
        if finding.get("status") != "accepted"
    )

    fix_engine = (engine_override or config.default_fixer).lower()
    fix_prompt = textwrap.dedent(
        f"""\
        Implement fixes in the active workspace for these accepted Takopi review findings only.
        Do not address rejected or triage findings.
        Keep changes minimal and targeted.
        Run or suggest the most relevant verification you can.
        Return a short summary of what changed and any remaining risks.

        Accepted findings:
        {_serialize_findings_for_fix(tuple(accepted))}
        """
    ).strip()
    run_context = None
    if ambient_context is not None:
        run_context = RunContext(
            project=ambient_context.project,
            branch=ambient_context.branch or bundle_payload.get("branch"),
        )
    result = await ctx.executor.run_one(
        RunRequest(
            prompt=fix_prompt,
            engine=fix_engine,
            context=run_context,
        ),
        mode="capture",
    )
    summary = result.message.text if result.message is not None else ""
    verification = _run_verification(repo_root, test_surface=bundle_test_surface)
    fix_report = FixReport(
        source_run_id=str(review_payload.get("run_id", "")),
        created_at=_utc_now(),
        engine=fix_engine,
        finding_ids=tuple(
            finding["id"] for finding in accepted if isinstance(finding.get("id"), str)
        ),
        files_changed=_collect_status(repo_root)[1],
        verification=verification,
        residual_open_findings=residual_open,
        agent_summary=summary.strip(),
        report_path="",
    )
    return _persist_fix_report(
        review_payload=review_payload,
        report=fix_report,
        repo_root=repo_root,
        config=config,
    )


def review_report_markdown(report: ReviewReport) -> str:
    return _render_review_report(report)


def fix_report_markdown(report: FixReport) -> str:
    return _render_fix_report(report)
