# takopi-review

multi-review orchestration plugin for takopi.

`takopi-review` runs multiple review agents over the same diff bundle, normalizes
their findings into one schema, deduplicates overlap, and produces a single
report you can act on. It keeps raw reviewer output for audit, but everything
downstream uses the same provider-agnostic finding shape.

## shipped now

phase 1 and the initial `/review fix` flow are implemented here:

- `/review diff`
- `/review pr <number|url>`
- `/review commit <sha>`
- normalized provider-agnostic findings
- consolidated markdown reports with audit artifacts
- deterministic meta-review
- `/review fix` for accepted findings

## how it works

the plugin runs in four stages:

1. collect the review target, diff, changed files, inferred test surface, and
   repo instructions
2. run the configured reviewer instances in parallel with the same bundle
3. normalize, deduplicate, rank, and classify findings as `accepted`,
   `needs-human-triage`, or `rejected`
4. optionally hand only accepted findings to a fixer engine and write a fix
   report

## requirements

- python 3.14+
- takopi installed
- `claude` and/or `codex` engines available in your takopi setup
- `gh` installed if you want `/review pr ...`

## install

```sh
uv tool install -U takopi --with takopi-review
```

or install into the same environment as takopi:

```sh
pip install -U takopi-review
```

enable it:

```toml
[plugins]
enabled = ["takopi-review"]
```

## commands

review the working tree diff:

```text
/review diff
/review diff --focus security --focus tests
/review diff --reviewer claude --reviewer claude --reviewer codex:security
```

review a pull request:

```text
/review pr 123
/review pr https://github.com/acme/repo/pull/123 --focus performance
```

review a commit:

```text
/review commit abc1234
```

apply accepted fixes from the latest saved review run, or a specific run:

```text
/review fix
/review fix --id RF-001 --id RF-002
/review fix --run 20260313T161318Z-ff69298e --engine codex
```

`/review fix` loads the latest saved review run for the active repo context and
only applies findings marked `accepted`.

reviewers can be configured or overridden per run as:

- `claude`
- `codex`
- `claude:security`
- `codex:tests`

repeated reviewer entries are allowed. If you configure the same reviewer more
than once, the plugin keeps them as distinct reviewer instances in reports and
audit artifacts, for example `claude#1` and `claude#2`.

## outputs

review artifacts are written under `.takopi/review/` by default:

```text
.takopi/review/
  latest.json
  <run-id>/
    bundle.json
    report.json
    report.md
    raw/
      claude-1.txt
      claude-2.txt
      codex-security.txt
    fix-report.json
    fix-report.md
```

the markdown review report includes:

- a consolidated findings table
- an agreement matrix by reviewer
- recommended fix order
- testing gaps
- reviewer execution errors, if any

## finding schema

all reviewer output is normalized into this shape before consolidation:

```json
{
  "reviewer": "claude",
  "title": "Missing authorization check",
  "priority": 1,
  "confidence": 0.84,
  "file": "src/example.py",
  "start_line": 42,
  "end_line": 45,
  "summary": "Route allows any Slack user to trigger destructive actions.",
  "suggested_fix": "Check allowed_user_ids before dispatch."
}
```

## config

```toml
[plugins.review]
default_fixer = "codex"
reviewers = ["claude", "claude:security", "codex", "codex:tests"]
timeout_s = 900
max_parallel_reviews = 3
post_github_comments = false
auto_fix = false
report_dir = ".takopi/review"
```

reports and raw reviewer outputs are stored under `report_dir` inside the repo.

## development

install the locked dev environment:

```sh
uv sync --frozen --group dev
```

run the same checks as CI:

```sh
uv run --no-sync ruff check
uv run --no-sync pytest -q
```

build the package locally:

```sh
uv build
```

## release

ci runs on pushes to `main` and pull requests. publishing is wired through
github actions on tags matching `v*`.

once PyPI trusted publishing is configured, a release is:

```sh
git tag v0.1.0
git push origin main --tags
```
