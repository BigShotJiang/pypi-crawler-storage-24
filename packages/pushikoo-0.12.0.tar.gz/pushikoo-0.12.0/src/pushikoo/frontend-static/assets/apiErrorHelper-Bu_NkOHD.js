function o(t,i){if(t&&typeof t=="object"){const e=t.body;if(e&&typeof e.detail=="string")return e.detail}return i}export{o as g};
