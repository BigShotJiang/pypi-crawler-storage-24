from uuid import UUID

from fastapi import APIRouter, HTTPException, Response, status

from pushikoo.model.cron import Cron, CronCreate, CronListFilter, CronUpdate
from pushikoo.model.pagination import Page
from pushikoo.service.refresh import CronService
from pushikoo.service.base import (
    ConflictException,
    NotFoundException,
    InvalidInputException,
)


router = APIRouter(prefix="/crons", tags=["crons"])


@router.post("", status_code=status.HTTP_201_CREATED)
def create_cron(payload: CronCreate) -> Cron:
    try:
        return CronService.create(payload)
    except NotFoundException as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ConflictException as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except InvalidInputException as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, detail=str(e)
        )


@router.get("")
def list_crons(
    flow_id: UUID | None = None,
    cron: str | None = None,
    enabled: bool | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> Page[Cron]:
    filter_obj = CronListFilter(
        flow_id=flow_id,
        cron=cron,
        enabled=enabled,
        limit=limit,
        offset=offset,
    )
    return CronService.list(filter_obj)


@router.patch("/{cron_id}")
def update_cron(cron_id: UUID, payload: CronUpdate) -> Cron:
    try:
        return CronService.update(cron_id, payload)
    except NotFoundException as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ConflictException as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except InvalidInputException as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, detail=str(e)
        )


@router.delete(
    "/{cron_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_cron(cron_id: UUID) -> Response:
    try:
        CronService.delete(cron_id)
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    except NotFoundException as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
