# autman-utils

A single-file Python utility module for payment and QingLong environment operations.

## Features

- Generate QR code URLs
- Read runtime config from middleware bucket
- Manage QingLong environment variables
- Create and query MaPay orders
- Safe import fallback when `middleware` is unavailable

## Installation

```bash
pip install autman-utils
```

## Usage

### Import module

```python
import autman_utils
```

or

```python
from autman_utils import MaPayClient, QingLongClient, get_pay_config, generate_qrcode_url
```

### Generate QR code URL

```python
from autman_utils import generate_qrcode_url

url = generate_qrcode_url("https://example.com")
print(url)
```

### Read payment config

```python
from autman_utils import get_pay_config

config = get_pay_config()
print(config)
```

### Use QingLong client

```python
from autman_utils import QingLongClient

client = QingLongClient("JD_COOKIE")
print(client.is_configured())
```

### Use MaPay client

```python
from autman_utils import MaPayClient

client = MaPayClient()
print(client.is_configured())
```

## Notes

- This package depends on `requests`.
- Some configuration features rely on a host-provided `middleware` module.
- If `middleware` is unavailable, the module still imports safely and falls back to default values.

## License

MIT
