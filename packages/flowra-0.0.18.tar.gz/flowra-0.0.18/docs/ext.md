# Package `flowra.ext`

Optional integrations with external services that require extra dependencies.

- **[MLflow tracing](ext/mlflow.md)** — span-hook integration for observability

Provider-specific hook bundles (no extra dependencies) live in `flowra.lib`:

- **[Anthropic extensions](lib/anthropic.md)** — prompt caching and tool search
  via `PrepareLLMRequestEvent`
