# TODO


## OpenTelemetry integration

- Subscribe to span-hooks (`AgentSpan`, `StepSpan`, `LLMCallSpan`, `ToolCallSpan`)
  and map them to OTel spans. Span-hooks provide guaranteed enter/exit with nesting —
  a natural fit for OTel's span model. Same approach as MLflow adapter (`flowra/ext/mlflow.py`),
  but targeting `flowra/ext/otel.py` with `flowra[otel]` optional dependency.
  OTel has native async-safe context propagation — this would also solve the
  distributed tracing propagation problem above.


## Model fallback on tool call failure

When a weak/fast model fails to call a tool correctly (schema validation error),
automatically retry on a more capable model.

**Use case:** cheap model handles 95% of cases, but occasionally produces invalid
tool call JSON. Instead of failing, escalate to a stronger model with feedback.

**Investigation needed:**

- Where exactly is "tool call schema validation failed" detected? Inside
  `ToolCallAgent`? In the provider? Is it visible via `AfterToolCallEvent`?
- Can we intercept before the error result is sent back to the LLM?
- `LLMConfig` is `ConfigValue` (callable) — model can be switched dynamically
  between iterations. But can we switch mid-iteration (after tool call failure,
  before the next LLM call)?
- `AfterToolCallEvent` has `additional_messages` — can we inject feedback there?
- Do we need a new hook point (e.g., `ToolCallValidationFailedEvent`)?
- Alternative: wrap `LLMProvider` with a fallback decorator that retries on a
  different model — simpler but less granular (retries the whole LLM call,
  not just the tool call).

**Building blocks that exist:**
- `ConfigValue[LLMConfig]` — dynamic model selection per iteration
- `AfterToolCallEvent` — post-tool-call hook with `result` and `additional_messages`
- `ToolCallSpan` — observability for tool calls
- `ToolLoopAgentContext` — shared state across iterations


## Capabilities (dynamic modes)

- **Capability packs — dynamically loadable modes.** A `Capability` bundles a system prompt
  fragment, a set of tools, and optionally an LLM config override. Capabilities can be
  activated/deactivated during the agent's tool loop (by the agent itself via a special tool,
  or programmatically via `ToolLoopAgentContext`). On each iteration, `ToolLoopAgent` assembles
  the active set: merges system prompts from all active capabilities, unions their tool sets,
  applies LLM config overrides. Similar to how Claude Code switches between planning/coding/etc.
  Building blocks already exist (`ConfigValue` callables, `allowed_tools`/`denied_tools`,
  `on_start_iteration`, `ToolLoopAgentContext`), but there's no unified abstraction tying
  them together. A capability could also carry hooks (e.g. a "verbose" capability that adds
  logging hooks when activated). Pairs well with composable hooks.


## Documentation benchmark suite

- A series of tasks given to a coding agent that has access only to documentation
  (no source code). Each task is a self-contained challenge: write a race agent
  (two LLMs, first wins via WhenAny + timeout), build a fan-out/fan-in pipeline,
  create a tool with service injection, wire up hooks with ExecutionContext, etc.
  For each task we define: the prompt, the documentation provided, and the expected
  outcome (working code that passes a test or matches a reference implementation).
  Run the suite, compare results against reference, identify where the agent
  struggles — those are doc gaps or API ergonomics issues. Fix docs/API, re-run,
  track improvement.


## Voice

- **Voice demo (streaming pipeline).** Example `voice_chat.py` — STT (microphone) → agent →
  `on_text_delta` → TTS (speaker). Leverages existing streaming infrastructure. Start with
  simple pipeline, explore STT options: Google Cloud Speech-to-Text (available in GCP),
  OpenAI Whisper API, or local `faster-whisper` for free experimentation.

- **Smart voice pipeline with context-aware re-recognition.** For domain-specific scenarios
  (e.g. payments in Anna Money): STT produces multiple hypotheses with confidence scores.
  Agent receives all variants as structured input ("user said via voice, variants: ...").
  Agent uses domain context (frequent recipients, recent transactions) to select the best
  variant. If uncertain — requests re-recognition with hints (e.g. "typical recipients:
  Маша, Петя, Сбербанк"), STT re-processes the same audio with boosted vocabulary.
  Ties into capabilities (recognize topic → load relevant capability with context),
  agent-as-tool (STT as a callable sub-agent), and hooks (`on_user_message` enriches
  voice input with domain context).


---

# Someday


- **Lazy fork / copy-on-write scope.** Currently `RuntimeScope.fork()` copies all scalars
  and append-only lists eagerly. Make it lazy: child reads from parent until first write,
  copies only the specific field on `set()`/`append()`.

- **Frozen list.** Immutable list in state (like Scalar, but for lists). Can be created
  cheaply from `append_only` (slice without copying) or from another frozen list.

- **Guardrails hooks package.** Ready-made hook set for content filtering and PII protection.
  Input guardrail (`UserMessageEvent`) checks/blocks user messages, output guardrail
  (`ResultMessageEvent`) checks/redacts LLM responses. Need integration with a moderation
  backend (Bedrock Guardrails, OpenAI Moderation API, or custom).

- **Local LLM usage guide.** Document how to use `OpenAIProvider` with local LLM servers
  (Ollama, LM Studio, vLLM). Show `base_url` configuration, recommend models for tool calling.

- **A2A (Agent-to-Agent) protocol support.** Thin adapter exposing any Flowra agent as an
  A2A-compatible HTTP server with Agent Card and SSE streaming.

- **Accurate cost estimation with full context.** Context length tiers, per-provider pricing,
  thinking tokens, cache creation TTL tiers. See `docs/research/pricing_complexity.md`.

- **Anna LLM Proxy provider.** Separate private repository (`anna-flowra` or similar)
  with `LLMProxyProvider` for Anna's internal LLM Proxy service.

- **Custom string tags for serialized types.** Allow explicit string tags via decorator
  or class attribute, falling back to `__qualname__` if not set. Decouples persistence
  format from Python naming.
