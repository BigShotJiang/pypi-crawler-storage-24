# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._streaming import Stream, AsyncStream
from ...._base_client import make_request_options
from ....types.agent.v1 import run_list_params, run_watch_params, run_create_params, run_events_params
from ....types.agent.v1.run_exec_response import RunExecResponse
from ....types.agent.v1.run_list_response import RunListResponse
from ....types.agent.v1.run_watch_response import RunWatchResponse
from ....types.agent.v1.run_cancel_response import RunCancelResponse
from ....types.agent.v1.run_create_response import RunCreateResponse
from ....types.agent.v1.run_events_response import RunEventsResponse
from ....types.agent.v1.run_get_status_response import RunGetStatusResponse
from ....types.agent.v1.run_get_details_response import RunGetDetailsResponse

__all__ = ["RunResource", "AsyncRunResource"]


class RunResource(SyncAPIResource):
    """
    Create, manage, and execute AI agents with tool access, sandbox environments, and async run workflows
    """

    @cached_property
    def with_raw_response(self) -> RunResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return RunResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> RunResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return RunResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        agent_id: str,
        prompt: str,
        callback_url: Optional[str] | Omit = omit,
        guidance: Optional[str] | Omit = omit,
        model: Optional[str] | Omit = omit,
        object_ids: Optional[SequenceNotStr[str]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunCreateResponse:
        """Creates a run in queued state.

        Call POST /agent/v1/run/:id/exec to start
        execution.

        Args:
          agent_id: ID of the agent to run

          prompt: Task prompt for the agent

          callback_url: HTTPS callback URL to receive a notification when the run completes. Registered
              atomically with the run — eliminates the race condition of calling /watch after
              /exec. Additional watchers can still be added via POST /run/:id/watch.

          guidance: Additional guidance for this run

          model: Override the agent default model for this run

          object_ids: Scope this run to specific vault object IDs. The agent will only be able to
              access these objects during execution.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/agent/v1/run",
            body=maybe_transform(
                {
                    "agent_id": agent_id,
                    "prompt": prompt,
                    "callback_url": callback_url,
                    "guidance": guidance,
                    "model": model,
                    "object_ids": object_ids,
                },
                run_create_params.RunCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunCreateResponse,
        )

    def list(
        self,
        *,
        agent_id: str | Omit = omit,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        status: Literal["queued", "running", "completed", "failed", "cancelled"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunListResponse:
        """Lists agent runs for the authenticated organization.

        Supports filtering by
        agent, status, and cursor-based pagination.

        Args:
          agent_id: Filter by agent ID

          cursor: Pagination cursor (run ID from previous page). Returns runs created before this
              run.

          limit: Maximum number of runs to return (default 50, max 250)

          status: Filter by run status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/agent/v1/run",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "agent_id": agent_id,
                        "cursor": cursor,
                        "limit": limit,
                        "status": status,
                    },
                    run_list_params.RunListParams,
                ),
            ),
            cast_to=RunListResponse,
        )

    def cancel(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunCancelResponse:
        """Cancels a running or queued run.

        Idempotent — cancelling a finished run returns
        its current status.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/agent/v1/run/{id}/cancel", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunCancelResponse,
        )

    def events(
        self,
        id: str,
        *,
        last_event_id: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Stream[RunEventsResponse]:
        """Streams real-time run events over SSE.

        Supports replay using Last-Event-ID.

        Args:
          last_event_id: Replay events after this sequence number

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        return self._get(
            path_template("/agent/v1/run/{id}/events", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"last_event_id": last_event_id}, run_events_params.RunEventsParams),
            ),
            cast_to=str,
            stream=True,
            stream_cls=Stream[RunEventsResponse],
        )

    def exec(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunExecResponse:
        """Starts execution of a queued run.

        The agent runs in a durable workflow — poll
        /run/:id/status for progress.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/agent/v1/run/{id}/exec", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunExecResponse,
        )

    def get_details(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunGetDetailsResponse:
        """
        Full audit trail for a run including output, steps (tool calls, text), and token
        usage.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/agent/v1/run/{id}/details", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunGetDetailsResponse,
        )

    def get_status(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunGetStatusResponse:
        """Lightweight status poll for a run.

        Use /run/:id/details for the full audit
        trail.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/agent/v1/run/{id}/status", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunGetStatusResponse,
        )

    def watch(
        self,
        id: str,
        *,
        callback_url: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunWatchResponse:
        """Register a callback URL to receive notifications when the run completes.

        URL
        must use https and must not point to a private network.

        Args:
          callback_url: HTTPS URL to receive completion callback

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/agent/v1/run/{id}/watch", id=id),
            body=maybe_transform({"callback_url": callback_url}, run_watch_params.RunWatchParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunWatchResponse,
        )


class AsyncRunResource(AsyncAPIResource):
    """
    Create, manage, and execute AI agents with tool access, sandbox environments, and async run workflows
    """

    @cached_property
    def with_raw_response(self) -> AsyncRunResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return AsyncRunResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncRunResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return AsyncRunResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        agent_id: str,
        prompt: str,
        callback_url: Optional[str] | Omit = omit,
        guidance: Optional[str] | Omit = omit,
        model: Optional[str] | Omit = omit,
        object_ids: Optional[SequenceNotStr[str]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunCreateResponse:
        """Creates a run in queued state.

        Call POST /agent/v1/run/:id/exec to start
        execution.

        Args:
          agent_id: ID of the agent to run

          prompt: Task prompt for the agent

          callback_url: HTTPS callback URL to receive a notification when the run completes. Registered
              atomically with the run — eliminates the race condition of calling /watch after
              /exec. Additional watchers can still be added via POST /run/:id/watch.

          guidance: Additional guidance for this run

          model: Override the agent default model for this run

          object_ids: Scope this run to specific vault object IDs. The agent will only be able to
              access these objects during execution.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/agent/v1/run",
            body=await async_maybe_transform(
                {
                    "agent_id": agent_id,
                    "prompt": prompt,
                    "callback_url": callback_url,
                    "guidance": guidance,
                    "model": model,
                    "object_ids": object_ids,
                },
                run_create_params.RunCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunCreateResponse,
        )

    async def list(
        self,
        *,
        agent_id: str | Omit = omit,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        status: Literal["queued", "running", "completed", "failed", "cancelled"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunListResponse:
        """Lists agent runs for the authenticated organization.

        Supports filtering by
        agent, status, and cursor-based pagination.

        Args:
          agent_id: Filter by agent ID

          cursor: Pagination cursor (run ID from previous page). Returns runs created before this
              run.

          limit: Maximum number of runs to return (default 50, max 250)

          status: Filter by run status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/agent/v1/run",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "agent_id": agent_id,
                        "cursor": cursor,
                        "limit": limit,
                        "status": status,
                    },
                    run_list_params.RunListParams,
                ),
            ),
            cast_to=RunListResponse,
        )

    async def cancel(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunCancelResponse:
        """Cancels a running or queued run.

        Idempotent — cancelling a finished run returns
        its current status.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/agent/v1/run/{id}/cancel", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunCancelResponse,
        )

    async def events(
        self,
        id: str,
        *,
        last_event_id: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[RunEventsResponse]:
        """Streams real-time run events over SSE.

        Supports replay using Last-Event-ID.

        Args:
          last_event_id: Replay events after this sequence number

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "text/event-stream", **(extra_headers or {})}
        return await self._get(
            path_template("/agent/v1/run/{id}/events", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"last_event_id": last_event_id}, run_events_params.RunEventsParams),
            ),
            cast_to=str,
            stream=True,
            stream_cls=AsyncStream[RunEventsResponse],
        )

    async def exec(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunExecResponse:
        """Starts execution of a queued run.

        The agent runs in a durable workflow — poll
        /run/:id/status for progress.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/agent/v1/run/{id}/exec", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunExecResponse,
        )

    async def get_details(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunGetDetailsResponse:
        """
        Full audit trail for a run including output, steps (tool calls, text), and token
        usage.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/agent/v1/run/{id}/details", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunGetDetailsResponse,
        )

    async def get_status(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunGetStatusResponse:
        """Lightweight status poll for a run.

        Use /run/:id/details for the full audit
        trail.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/agent/v1/run/{id}/status", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunGetStatusResponse,
        )

    async def watch(
        self,
        id: str,
        *,
        callback_url: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunWatchResponse:
        """Register a callback URL to receive notifications when the run completes.

        URL
        must use https and must not point to a private network.

        Args:
          callback_url: HTTPS URL to receive completion callback

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/agent/v1/run/{id}/watch", id=id),
            body=await async_maybe_transform({"callback_url": callback_url}, run_watch_params.RunWatchParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunWatchResponse,
        )


class RunResourceWithRawResponse:
    def __init__(self, run: RunResource) -> None:
        self._run = run

        self.create = to_raw_response_wrapper(
            run.create,
        )
        self.list = to_raw_response_wrapper(
            run.list,
        )
        self.cancel = to_raw_response_wrapper(
            run.cancel,
        )
        self.events = to_raw_response_wrapper(
            run.events,
        )
        self.exec = to_raw_response_wrapper(
            run.exec,
        )
        self.get_details = to_raw_response_wrapper(
            run.get_details,
        )
        self.get_status = to_raw_response_wrapper(
            run.get_status,
        )
        self.watch = to_raw_response_wrapper(
            run.watch,
        )


class AsyncRunResourceWithRawResponse:
    def __init__(self, run: AsyncRunResource) -> None:
        self._run = run

        self.create = async_to_raw_response_wrapper(
            run.create,
        )
        self.list = async_to_raw_response_wrapper(
            run.list,
        )
        self.cancel = async_to_raw_response_wrapper(
            run.cancel,
        )
        self.events = async_to_raw_response_wrapper(
            run.events,
        )
        self.exec = async_to_raw_response_wrapper(
            run.exec,
        )
        self.get_details = async_to_raw_response_wrapper(
            run.get_details,
        )
        self.get_status = async_to_raw_response_wrapper(
            run.get_status,
        )
        self.watch = async_to_raw_response_wrapper(
            run.watch,
        )


class RunResourceWithStreamingResponse:
    def __init__(self, run: RunResource) -> None:
        self._run = run

        self.create = to_streamed_response_wrapper(
            run.create,
        )
        self.list = to_streamed_response_wrapper(
            run.list,
        )
        self.cancel = to_streamed_response_wrapper(
            run.cancel,
        )
        self.events = to_streamed_response_wrapper(
            run.events,
        )
        self.exec = to_streamed_response_wrapper(
            run.exec,
        )
        self.get_details = to_streamed_response_wrapper(
            run.get_details,
        )
        self.get_status = to_streamed_response_wrapper(
            run.get_status,
        )
        self.watch = to_streamed_response_wrapper(
            run.watch,
        )


class AsyncRunResourceWithStreamingResponse:
    def __init__(self, run: AsyncRunResource) -> None:
        self._run = run

        self.create = async_to_streamed_response_wrapper(
            run.create,
        )
        self.list = async_to_streamed_response_wrapper(
            run.list,
        )
        self.cancel = async_to_streamed_response_wrapper(
            run.cancel,
        )
        self.events = async_to_streamed_response_wrapper(
            run.events,
        )
        self.exec = async_to_streamed_response_wrapper(
            run.exec,
        )
        self.get_details = async_to_streamed_response_wrapper(
            run.get_details,
        )
        self.get_status = async_to_streamed_response_wrapper(
            run.get_status,
        )
        self.watch = async_to_streamed_response_wrapper(
            run.watch,
        )
