# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from casedev import Casedev, AsyncCasedev
from tests.utils import assert_matches_type
from casedev.types import LlmGetConfigResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestLlm:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_get_config(self, client: Casedev) -> None:
        llm = client.llm.get_config()
        assert_matches_type(LlmGetConfigResponse, llm, path=["response"])

    @parametrize
    def test_raw_response_get_config(self, client: Casedev) -> None:
        response = client.llm.with_raw_response.get_config()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        llm = response.parse()
        assert_matches_type(LlmGetConfigResponse, llm, path=["response"])

    @parametrize
    def test_streaming_response_get_config(self, client: Casedev) -> None:
        with client.llm.with_streaming_response.get_config() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            llm = response.parse()
            assert_matches_type(LlmGetConfigResponse, llm, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncLlm:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_get_config(self, async_client: AsyncCasedev) -> None:
        llm = await async_client.llm.get_config()
        assert_matches_type(LlmGetConfigResponse, llm, path=["response"])

    @parametrize
    async def test_raw_response_get_config(self, async_client: AsyncCasedev) -> None:
        response = await async_client.llm.with_raw_response.get_config()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        llm = await response.parse()
        assert_matches_type(LlmGetConfigResponse, llm, path=["response"])

    @parametrize
    async def test_streaming_response_get_config(self, async_client: AsyncCasedev) -> None:
        async with async_client.llm.with_streaming_response.get_config() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            llm = await response.parse()
            assert_matches_type(LlmGetConfigResponse, llm, path=["response"])

        assert cast(Any, response.is_closed) is True
