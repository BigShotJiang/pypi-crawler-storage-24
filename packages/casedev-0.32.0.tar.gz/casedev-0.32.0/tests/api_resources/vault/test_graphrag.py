# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from casedev import Casedev, AsyncCasedev
from tests.utils import assert_matches_type
from casedev.types.vault import GraphragInitResponse, GraphragGetStatsResponse, GraphragProcessObjectResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestGraphrag:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_get_stats(self, client: Casedev) -> None:
        graphrag = client.vault.graphrag.get_stats(
            "id",
        )
        assert_matches_type(GraphragGetStatsResponse, graphrag, path=["response"])

    @parametrize
    def test_raw_response_get_stats(self, client: Casedev) -> None:
        response = client.vault.graphrag.with_raw_response.get_stats(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        graphrag = response.parse()
        assert_matches_type(GraphragGetStatsResponse, graphrag, path=["response"])

    @parametrize
    def test_streaming_response_get_stats(self, client: Casedev) -> None:
        with client.vault.graphrag.with_streaming_response.get_stats(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            graphrag = response.parse()
            assert_matches_type(GraphragGetStatsResponse, graphrag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_get_stats(self, client: Casedev) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.vault.graphrag.with_raw_response.get_stats(
                "",
            )

    @parametrize
    def test_method_init(self, client: Casedev) -> None:
        graphrag = client.vault.graphrag.init(
            "id",
        )
        assert_matches_type(GraphragInitResponse, graphrag, path=["response"])

    @parametrize
    def test_raw_response_init(self, client: Casedev) -> None:
        response = client.vault.graphrag.with_raw_response.init(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        graphrag = response.parse()
        assert_matches_type(GraphragInitResponse, graphrag, path=["response"])

    @parametrize
    def test_streaming_response_init(self, client: Casedev) -> None:
        with client.vault.graphrag.with_streaming_response.init(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            graphrag = response.parse()
            assert_matches_type(GraphragInitResponse, graphrag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_init(self, client: Casedev) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.vault.graphrag.with_raw_response.init(
                "",
            )

    @parametrize
    def test_method_process_object(self, client: Casedev) -> None:
        graphrag = client.vault.graphrag.process_object(
            object_id="objectId",
            id="id",
        )
        assert_matches_type(GraphragProcessObjectResponse, graphrag, path=["response"])

    @parametrize
    def test_raw_response_process_object(self, client: Casedev) -> None:
        response = client.vault.graphrag.with_raw_response.process_object(
            object_id="objectId",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        graphrag = response.parse()
        assert_matches_type(GraphragProcessObjectResponse, graphrag, path=["response"])

    @parametrize
    def test_streaming_response_process_object(self, client: Casedev) -> None:
        with client.vault.graphrag.with_streaming_response.process_object(
            object_id="objectId",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            graphrag = response.parse()
            assert_matches_type(GraphragProcessObjectResponse, graphrag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_process_object(self, client: Casedev) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.vault.graphrag.with_raw_response.process_object(
                object_id="objectId",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `object_id` but received ''"):
            client.vault.graphrag.with_raw_response.process_object(
                object_id="",
                id="id",
            )


class TestAsyncGraphrag:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_get_stats(self, async_client: AsyncCasedev) -> None:
        graphrag = await async_client.vault.graphrag.get_stats(
            "id",
        )
        assert_matches_type(GraphragGetStatsResponse, graphrag, path=["response"])

    @parametrize
    async def test_raw_response_get_stats(self, async_client: AsyncCasedev) -> None:
        response = await async_client.vault.graphrag.with_raw_response.get_stats(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        graphrag = await response.parse()
        assert_matches_type(GraphragGetStatsResponse, graphrag, path=["response"])

    @parametrize
    async def test_streaming_response_get_stats(self, async_client: AsyncCasedev) -> None:
        async with async_client.vault.graphrag.with_streaming_response.get_stats(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            graphrag = await response.parse()
            assert_matches_type(GraphragGetStatsResponse, graphrag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_get_stats(self, async_client: AsyncCasedev) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.vault.graphrag.with_raw_response.get_stats(
                "",
            )

    @parametrize
    async def test_method_init(self, async_client: AsyncCasedev) -> None:
        graphrag = await async_client.vault.graphrag.init(
            "id",
        )
        assert_matches_type(GraphragInitResponse, graphrag, path=["response"])

    @parametrize
    async def test_raw_response_init(self, async_client: AsyncCasedev) -> None:
        response = await async_client.vault.graphrag.with_raw_response.init(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        graphrag = await response.parse()
        assert_matches_type(GraphragInitResponse, graphrag, path=["response"])

    @parametrize
    async def test_streaming_response_init(self, async_client: AsyncCasedev) -> None:
        async with async_client.vault.graphrag.with_streaming_response.init(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            graphrag = await response.parse()
            assert_matches_type(GraphragInitResponse, graphrag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_init(self, async_client: AsyncCasedev) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.vault.graphrag.with_raw_response.init(
                "",
            )

    @parametrize
    async def test_method_process_object(self, async_client: AsyncCasedev) -> None:
        graphrag = await async_client.vault.graphrag.process_object(
            object_id="objectId",
            id="id",
        )
        assert_matches_type(GraphragProcessObjectResponse, graphrag, path=["response"])

    @parametrize
    async def test_raw_response_process_object(self, async_client: AsyncCasedev) -> None:
        response = await async_client.vault.graphrag.with_raw_response.process_object(
            object_id="objectId",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        graphrag = await response.parse()
        assert_matches_type(GraphragProcessObjectResponse, graphrag, path=["response"])

    @parametrize
    async def test_streaming_response_process_object(self, async_client: AsyncCasedev) -> None:
        async with async_client.vault.graphrag.with_streaming_response.process_object(
            object_id="objectId",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            graphrag = await response.parse()
            assert_matches_type(GraphragProcessObjectResponse, graphrag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_process_object(self, async_client: AsyncCasedev) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.vault.graphrag.with_raw_response.process_object(
                object_id="objectId",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `object_id` but received ''"):
            await async_client.vault.graphrag.with_raw_response.process_object(
                object_id="",
                id="id",
            )
