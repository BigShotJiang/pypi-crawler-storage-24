import threading
import time
import subprocess

import torch
import psutil
from rich.console import Console
from rich.live import Live
from rich.table import Table
from rich.text import Text


class HardwareMonitor:
    """Monitors CPU/GPU usage in a background thread and displays a live dashboard."""

    def __init__(self, interval: float = 0.5):
        self.interval = interval
        self._running = False
        self._thread = None
        self._live = None
        self.samples = []
        self.has_cuda = torch.cuda.is_available()

    def start(self, console: Console):
        self._running = True
        self._console = console
        self._live = Live(self._render(), console=console, refresh_per_second=2)
        self._live.start()
        self._thread = threading.Thread(target=self._poll, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)
        if self._live:
            self._live.stop()

    def _poll(self):
        while self._running:
            sample = self._collect()
            self.samples.append(sample)
            if self._live:
                self._live.update(self._render())
            time.sleep(self.interval)

    def _collect(self) -> dict:
        sample = {
            "time": time.time(),
            "cpu_percent": psutil.cpu_percent(interval=0),
            "ram_used_gb": psutil.virtual_memory().used / 1e9,
            "ram_total_gb": psutil.virtual_memory().total / 1e9,
        }

        if self.has_cuda:
            try:
                result = subprocess.run(
                    [
                        "nvidia-smi",
                        "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw",
                        "--format=csv,noheader,nounits",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=2,
                )
                if result.returncode == 0:
                    parts = result.stdout.strip().split(", ")
                    if len(parts) >= 5:
                        sample["gpu_util"] = float(parts[0])
                        sample["vram_used_mb"] = float(parts[1])
                        sample["vram_total_mb"] = float(parts[2])
                        sample["gpu_temp_c"] = float(parts[3])
                        sample["gpu_power_w"] = float(parts[4])
            except Exception:
                pass

        return sample

    def _bar(self, value: float, max_val: float = 100, width: int = 20) -> Text:
        filled = int(value / max_val * width)
        filled = max(0, min(filled, width))
        empty = width - filled

        if value < 50:
            color = "green"
        elif value < 80:
            color = "yellow"
        else:
            color = "red"

        bar = Text()
        bar.append("█" * filled, style=color)
        bar.append("░" * empty, style="dim")
        bar.append(f" {value:5.1f}%")
        return bar

    def _render(self) -> Table:
        table = Table(
            title="Hardware Monitor",
            show_header=False,
            box=None,
            padding=(0, 1),
            min_width=50,
        )
        table.add_column("Metric", style="bold", width=16)
        table.add_column("Value", width=40)

        if self.samples:
            s = self.samples[-1]

            # CPU
            table.add_row("CPU", self._bar(s["cpu_percent"]))
            ram_pct = s["ram_used_gb"] / s["ram_total_gb"] * 100
            ram_text = self._bar(ram_pct)
            ram_text.append(f"  ({s['ram_used_gb']:.1f}/{s['ram_total_gb']:.1f} GB)")
            table.add_row("RAM", ram_text)

            # GPU
            if "gpu_util" in s:
                table.add_row("GPU Compute", self._bar(s["gpu_util"]))
                vram_pct = s["vram_used_mb"] / s["vram_total_mb"] * 100
                vram_text = self._bar(vram_pct)
                vram_text.append(
                    f"  ({s['vram_used_mb']:.0f}/{s['vram_total_mb']:.0f} MB)"
                )
                table.add_row("VRAM", vram_text)
                table.add_row(
                    "GPU Temp",
                    Text(f"{s.get('gpu_temp_c', 0):.0f}°C"),
                )
                table.add_row(
                    "GPU Power",
                    Text(f"{s.get('gpu_power_w', 0):.0f} W"),
                )
        else:
            table.add_row("", Text("Waiting for data...", style="dim"))

        return table

    def summary(self) -> dict:
        if not self.samples:
            return {}

        result = {
            "cpu_mean": sum(s["cpu_percent"] for s in self.samples) / len(self.samples),
            "cpu_peak": max(s["cpu_percent"] for s in self.samples),
            "ram_peak_gb": max(s["ram_used_gb"] for s in self.samples),
            "duration_s": self.samples[-1]["time"] - self.samples[0]["time"]
            if len(self.samples) > 1
            else 0,
            "n_samples": len(self.samples),
        }

        gpu_samples = [s for s in self.samples if "gpu_util" in s]
        if gpu_samples:
            result["gpu_util_mean"] = (
                sum(s["gpu_util"] for s in gpu_samples) / len(gpu_samples)
            )
            result["gpu_util_peak"] = max(s["gpu_util"] for s in gpu_samples)
            result["vram_peak_mb"] = max(s["vram_used_mb"] for s in gpu_samples)
            result["vram_total_mb"] = gpu_samples[0]["vram_total_mb"]
            result["gpu_temp_peak_c"] = max(s["gpu_temp_c"] for s in gpu_samples)
            result["gpu_power_mean_w"] = (
                sum(s["gpu_power_w"] for s in gpu_samples) / len(gpu_samples)
            )
            result["gpu_power_peak_w"] = max(s["gpu_power_w"] for s in gpu_samples)

        return result

    def print_summary(self, console: Console):
        s = self.summary()
        if not s:
            return

        table = Table(title="Hardware Summary")
        table.add_column("Metric", style="bold")
        table.add_column("Mean", justify="right")
        table.add_column("Peak", justify="right")

        table.add_row("CPU", f"{s['cpu_mean']:.1f}%", f"{s['cpu_peak']:.0f}%")
        table.add_row("RAM", "-", f"{s['ram_peak_gb']:.1f} GB")

        if "gpu_util_mean" in s:
            table.add_row(
                "GPU Compute",
                f"{s['gpu_util_mean']:.1f}%",
                f"{s['gpu_util_peak']:.0f}%",
            )
            table.add_row(
                "VRAM",
                "-",
                f"{s['vram_peak_mb']:.0f}/{s['vram_total_mb']:.0f} MB",
            )
            table.add_row(
                "GPU Temp", "-", f"{s['gpu_temp_peak_c']:.0f}°C"
            )
            table.add_row(
                "GPU Power",
                f"{s['gpu_power_mean_w']:.0f} W",
                f"{s['gpu_power_peak_w']:.0f} W",
            )

        table.add_row("Duration", "-", f"{s['duration_s']:.1f}s")

        console.print()
        console.print(table)
