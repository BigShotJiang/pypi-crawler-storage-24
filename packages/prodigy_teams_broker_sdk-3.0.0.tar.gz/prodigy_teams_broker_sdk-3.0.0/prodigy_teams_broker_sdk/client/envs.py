from typing import cast

from ..models import RecipesMeta
from .base import BaseClient


class Envs(BaseClient):
    def get_recipes_meta(self, package_name: str, package_version: str) -> RecipesMeta:
        res = self.request(
            "GET",
            endpoint=f"{package_name}/{package_version}/meta",
            return_model=RecipesMeta,
        )
        return cast(RecipesMeta, res)

    async def get_recipes_meta_async(
        self, package_name: str, package_version: str
    ) -> RecipesMeta:
        res = await self.request_async(
            "GET",
            endpoint=f"{package_name}/{package_version}/meta",
            return_model=RecipesMeta,
        )
        return cast(RecipesMeta, res)
