"""Concurrent folder downloader built on top of GoogleDriveClient."""

from __future__ import annotations

import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from tqdm import tqdm

from .client import GoogleDriveClient

FOLDER_MIME = "application/vnd.google-apps.folder"
GOOGLE_APPS_PREFIX = "application/vnd.google-apps"


def extract_folder_id(link_or_id: str) -> str:
    """Extract the bare folder ID from a Google Drive share URL, or return as-is."""
    match = re.search(r"folders/([a-zA-Z0-9_-]+)", link_or_id)
    if match:
        return match.group(1)
    # Looks like a raw ID already
    if re.fullmatch(r"[a-zA-Z0-9_-]+", link_or_id):
        return link_or_id
    raise ValueError(
        f"Cannot extract a Drive folder ID from: {link_or_id!r}\n"
        "Expected a URL like https://drive.google.com/drive/folders/<ID> "
        "or a bare folder ID."
    )


class FolderDownloader:
    """Downloads a Drive folder tree concurrently with a tqdm progress bar.

    Parameters
    ----------
    client:
        Authenticated :class:`~rgsuhas_drive_downloader.client.GoogleDriveClient`.
    include_all_drives:
        Whether to include Shared Drive items.
    skip_existing:
        Skip files that already exist locally.
    max_workers:
        Number of parallel download threads (default 5).
    """

    def __init__(
        self,
        client: GoogleDriveClient,
        include_all_drives: bool = False,
        skip_existing: bool = False,
        max_workers: int = 5,
    ) -> None:
        self.client = client
        self.include_all_drives = include_all_drives
        self.skip_existing = skip_existing
        self.max_workers = max_workers

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _collect_tasks(
        self, folder_id: str, dest_dir: str
    ) -> list[tuple[dict, str]]:
        """Recursively walk the folder tree and return a flat list of (file, dest_dir)."""
        tasks: list[tuple[dict, str]] = []
        children = self.client.list_children(folder_id, self.include_all_drives)

        for child in children:
            if child["mimeType"] == FOLDER_MIME:
                sub_dir = os.path.join(dest_dir, child["name"])
                tasks.extend(self._collect_tasks(child["id"], sub_dir))
            else:
                tasks.append((child, dest_dir))

        return tasks

    def _process_task(
        self, file: dict, dest_dir: str, pbar: tqdm
    ) -> str:
        name = file["name"]
        is_google_native = file["mimeType"].startswith(GOOGLE_APPS_PREFIX)

        if is_google_native:
            dest_path = self.client.export_google_file(
                file, dest_dir, self.include_all_drives
            )
            tqdm.write(f"  exported   {name}")
        else:
            dest_path = os.path.join(dest_dir, name)
            if self.skip_existing and Path(dest_path).is_file():
                tqdm.write(f"  skipped    {name}")
                pbar.update(1)
                return dest_path
            tqdm.write(f"  download   {name}")
            self.client.download_file(
                file["id"], dest_path, self.include_all_drives
            )

        pbar.update(1)
        return dest_path

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def download(self, folder_id: str, dest_dir: str) -> None:
        """Download *folder_id* into *dest_dir* using up to *max_workers* threads."""
        tqdm.write("Collecting file list…")
        tasks = self._collect_tasks(folder_id, dest_dir)
        total = len(tasks)
        tqdm.write(f"Found {total} file(s) to process.\n")

        errors: list[tuple[str, Exception]] = []

        with tqdm(total=total, unit="file", desc="Progress", colour="green") as pbar:
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                future_to_name = {
                    executor.submit(self._process_task, f, d, pbar): f["name"]
                    for f, d in tasks
                }
                for future in as_completed(future_to_name):
                    name = future_to_name[future]
                    try:
                        future.result()
                    except Exception as exc:
                        tqdm.write(f"  ERROR      {name}: {exc}")
                        errors.append((name, exc))

        if errors:
            tqdm.write(f"\n{len(errors)} file(s) failed:")
            for name, exc in errors:
                tqdm.write(f"  {name}: {exc}")
