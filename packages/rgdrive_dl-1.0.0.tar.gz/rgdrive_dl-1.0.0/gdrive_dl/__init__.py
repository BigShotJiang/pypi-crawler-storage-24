"""gdrive-dl — concurrent Google Drive folder downloader."""

__version__ = "1.0.0"

from .client import GoogleDriveClient
from .downloader import FolderDownloader, extract_folder_id

__all__ = ["GoogleDriveClient", "FolderDownloader", "extract_folder_id"]
