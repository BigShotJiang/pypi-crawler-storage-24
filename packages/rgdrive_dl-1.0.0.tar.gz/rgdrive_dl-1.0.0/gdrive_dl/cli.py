"""Command-line entry point for rgdrive-dl."""

from __future__ import annotations

import argparse
import sys

from . import __version__
from .client import GoogleDriveClient
from .downloader import FolderDownloader, extract_folder_id


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rgdrive-dl",
        description=(
            "Download a Google Drive folder recursively using a Service Account.\n\n"
            "Authentication: provide a Service Account JSON key file via -c/--credentials\n"
            "or set the GOOGLE_APPLICATION_CREDENTIALS environment variable."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "-V", "--version", action="version", version=f"%(prog)s {__version__}"
    )
    parser.add_argument(
        "-c",
        "--credentials",
        required=True,
        metavar="PATH",
        help="Path to a Service Account JSON key file.",
    )
    parser.add_argument(
        "-f",
        "--folder",
        required=True,
        metavar="ID_OR_URL",
        help="Google Drive folder ID or share URL.",
    )
    parser.add_argument(
        "-d",
        "--dest",
        default=".",
        metavar="PATH",
        help="Local destination directory (default: current directory).",
    )
    parser.add_argument(
        "--all-drives",
        action="store_true",
        help="Include items from Shared Drives (Team Drives).",
    )
    parser.add_argument(
        "--skip-existing",
        action="store_true",
        help="Skip files that already exist at the destination.",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=5,
        metavar="N",
        help="Number of concurrent download threads (default: 5).",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    try:
        folder_id = extract_folder_id(args.folder)
    except ValueError as exc:
        parser.error(str(exc))

    print(f"rgdrive-dl {__version__}")
    print(f"  folder  : {folder_id}")
    print(f"  dest    : {args.dest}")
    print(f"  workers : {args.workers}\n")

    try:
        client = GoogleDriveClient(args.credentials)
    except Exception as exc:
        print(f"Failed to authenticate: {exc}", file=sys.stderr)
        sys.exit(1)

    downloader = FolderDownloader(
        client,
        include_all_drives=args.all_drives,
        skip_existing=args.skip_existing,
        max_workers=args.workers,
    )

    try:
        downloader.download(folder_id, args.dest)
    except KeyboardInterrupt:
        print("\nAborted by user.", file=sys.stderr)
        sys.exit(130)
    except Exception as exc:
        print(f"\nFatal error: {exc}", file=sys.stderr)
        sys.exit(1)

    print("\nAll done.")


if __name__ == "__main__":
    main()
