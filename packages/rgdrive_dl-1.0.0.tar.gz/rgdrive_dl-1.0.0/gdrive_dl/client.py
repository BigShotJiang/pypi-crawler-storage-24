"""Google Drive API client using the official google-api-python-client SDK."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, Optional

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

SCOPES = ["https://www.googleapis.com/auth/drive.readonly"]

# Maps Google-native MIME types to (export_mime, file_extension)
EXPORT_FORMATS: dict[str, tuple[str, str]] = {
    "application/vnd.google-apps.document": ("application/pdf", ".pdf"),
    "application/vnd.google-apps.spreadsheet": (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".xlsx",
    ),
    "application/vnd.google-apps.presentation": ("application/pdf", ".pdf"),
    "application/vnd.google-apps.drawing": ("image/png", ".png"),
}


class GoogleDriveClient:
    """Thin wrapper around the Drive v3 API."""

    def __init__(self, credentials_path: str) -> None:
        creds = service_account.Credentials.from_service_account_file(
            credentials_path, scopes=SCOPES
        )
        self.service = build("drive", "v3", credentials=creds, cache_discovery=False)

    # ------------------------------------------------------------------
    # Listing
    # ------------------------------------------------------------------

    def list_children(
        self, folder_id: str, include_all_drives: bool = False
    ) -> list[dict]:
        """Return all direct children (files + folders) of *folder_id*."""
        query = f"'{folder_id}' in parents and trashed=false"
        results: list[dict] = []
        page_token: Optional[str] = None

        while True:
            kwargs: dict = dict(
                q=query,
                fields="nextPageToken, files(id, name, mimeType, size, md5Checksum)",
                pageSize=1000,
            )
            if include_all_drives:
                kwargs.update(
                    supportsAllDrives=True, includeItemsFromAllDrives=True
                )
            if page_token:
                kwargs["pageToken"] = page_token

            response = self.service.files().list(**kwargs).execute()
            results.extend(response.get("files", []))
            page_token = response.get("nextPageToken")
            if not page_token:
                break

        return results

    # ------------------------------------------------------------------
    # Downloading
    # ------------------------------------------------------------------

    def download_file(
        self,
        file_id: str,
        dest_path: str,
        include_all_drives: bool = False,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> None:
        """Stream *file_id* to *dest_path*, calling *progress_callback(pct, total)* each chunk."""
        Path(dest_path).parent.mkdir(parents=True, exist_ok=True)

        kwargs: dict = {}
        if include_all_drives:
            kwargs["supportsAllDrives"] = True

        request = self.service.files().get_media(fileId=file_id, **kwargs)
        with open(dest_path, "wb") as fh:
            downloader = MediaIoBaseDownload(fh, request, chunksize=8 * 1024 * 1024)
            done = False
            while not done:
                status, done = downloader.next_chunk()
                if progress_callback and status:
                    progress_callback(
                        int(status.progress() * 100),
                        int(status.total_size or 0),
                    )

    def export_google_file(
        self,
        file: dict,
        dest_dir: str,
        include_all_drives: bool = False,
    ) -> str:
        """Export a Google-native file (Docs/Sheets/Slides/Drawing) to a standard format."""
        mime_type, ext = EXPORT_FORMATS.get(
            file["mimeType"], ("application/pdf", ".pdf")
        )

        name = file["name"]
        if not name.lower().endswith(ext.lower()):
            name += ext

        Path(dest_dir).mkdir(parents=True, exist_ok=True)
        dest_path = os.path.join(dest_dir, name)

        request = self.service.files().export_media(
            fileId=file["id"], mimeType=mime_type
        )
        with open(dest_path, "wb") as fh:
            downloader = MediaIoBaseDownload(fh, request, chunksize=8 * 1024 * 1024)
            done = False
            while not done:
                _, done = downloader.next_chunk()

        return dest_path
