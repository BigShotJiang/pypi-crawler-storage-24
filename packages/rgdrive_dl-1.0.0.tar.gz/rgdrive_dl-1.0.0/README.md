# grgdrive-dl

A concurrent Google Drive folder downloader built on the official **google-api-python-client** SDK.
Downloads up to **5 files in parallel**, shows a **tqdm progress bar**, and is installable in one command.

```bash
pip install grgdrive-dl
grgdrive-dl -c credentials.json -f "https://drive.google.com/drive/folders/<ID>" -d ./output
```

---

## Features

- **Official SDK** — uses `google-api-python-client` + `google-auth` (service account auth)
- **Concurrent downloads** — `ThreadPoolExecutor` with configurable worker count (default 5)
- **Progress bar** — live `tqdm` progress across all files
- **Recursive** — walks nested folder trees automatically
- **Google-native export** — Docs → PDF, Sheets → XLSX, Slides → PDF, Drawings → PNG
- **Skip-existing** flag — resume interrupted downloads without re-downloading
- **Shared Drive support** — `--all-drives` flag for Team Drives
- **PyPI package** — `pip install` and use as a CLI or Python library

---

## Installation

```bash
pip install rgsuhas-drive-downloader
```

Requires Python 3.9+.

---

## Authentication

This tool uses a **Google Cloud Service Account**.

1. Go to the [Google Cloud Console](https://console.cloud.google.com/).
2. Create or select a project and enable the **Google Drive API**.
3. Create a **Service Account** under *IAM & Admin → Service Accounts*.
4. Download the **JSON key file** for that service account.
5. Share your Drive folder with the service account's email (found in the JSON as `client_email`).

---

## Usage

### CLI

```bash
rgdrive-dl --credentials path/to/sa-key.json \
         --folder "https://drive.google.com/drive/folders/FOLDER_ID" \
         --dest ./my-downloads
```

| Flag | Short | Default | Description |
|------|-------|---------|-------------|
| `--credentials` | `-c` | required | Path to Service Account JSON key |
| `--folder` | `-f` | required | Drive folder ID or share URL |
| `--dest` | `-d` | `.` | Local destination directory |
| `--workers` | | `5` | Concurrent download threads |
| `--all-drives` | | off | Include Shared Drive items |
| `--skip-existing` | | off | Skip already-downloaded files |

**Example — resume a partial download with 8 threads:**

```bash
rgdrive-dl -c sa-key.json -f 1A2B3C4D5E --dest ./data --skip-existing --workers 8
```

### Python API

```python
from gdrive_dl import GoogleDriveClient, FolderDownloader

client = GoogleDriveClient("path/to/sa-key.json")

downloader = FolderDownloader(
    client,
    include_all_drives=False,
    skip_existing=True,
    max_workers=5,
)

downloader.download(folder_id="1A2B3C4D5E6F", dest_dir="./output")
```

---

## Example Output

```
rgdrive-dl 1.0.0
  folder  : 1A2B3C4D5EFGhijklmno
  dest    : ./output
  workers : 5

Collecting file list…
Found 42 file(s) to process.

  download   report_2024.pdf
  download   dataset.csv
  download   presentation.pptx
  exported   notes (Google Doc) → notes.pdf
Progress: 100%|████████████████████| 42/42 [00:18<00:00,  2.3 file/s]

All done.
```

---

## Publishing to PyPI

```bash
# Install build tools
pip install build twine

# Build the distribution
python -m build

# Upload to PyPI (requires a PyPI account + API token)
twine upload dist/*
```

---

## Development

```bash
git clone https://github.com/rgsuhas/drive-downloader.git
cd drive-downloader
pip install -e ".[dev]"
```

---

## License

MIT © Suhas RG
