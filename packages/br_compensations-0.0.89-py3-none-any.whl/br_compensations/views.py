from allianceauth.services.hooks import get_extension_logger
from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from .permissions import PERMISSION_CAN_MANAGE
from .forms import AddBrForm
from .models.filterentities import FilterEntity
from .models.battlereport import BattleReport
from .models.killmails import KillCompensation
from .models.charmail import CharMailParse
from eveuniverse.models import EveEntity
from allianceauth.framework.api.user import get_main_character_from_user
from django.utils.decorators import method_decorator
from esi.decorators import tokens_required
from django.conf import settings
from django.utils.translation import gettext as _

logger = get_extension_logger(__name__)

@method_decorator(tokens_required(scopes="esi-mail.read_mail.v1 esi-mail.send_mail.v1 esi-ui.open_window.v1"), name="dispatch")
class DashboardView(LoginRequiredMixin, PermissionRequiredMixin,TemplateView): 
    template_name = 'br_compensations/dashboard.html'
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    
    def get_context_data(self, filter=None, **kwargs):
        context = super().get_context_data(**kwargs)

        character = get_main_character_from_user(self.request.user)
        
        data = []
        dbFilters = FilterEntity.objects.all()
            
        for f in dbFilters:
            entry_icon = ""
            match f.entity_type:
                case FilterEntity.ALLIANCE:
                    entry_icon = f"https://images.evetech.net/alliances/{f.entity_id}/logo?size=32"
                case FilterEntity.CORPORATION:
                    entry_icon = f"https://images.evetech.net/corporations/{f.entity_id}/logo?size=32"
                case FilterEntity.CHARACTER:
                    entry_icon = f"https://images.evetech.net/characters/{f.entity_id}/portrait?size=32"
                case _:
                    entry_icon = ''
            
            try:
                entry = EveEntity.objects.get(id=f.entity_id)
                
                data.append({
                    'filter': {
                        'id': f.entity_id,
                        'type': f.entity_type,
                        },
                    'display_name': entry.name,
                    "icon": entry_icon
                })
            except Exception as e:
                logger.error(f"Ошибка при поиске в ESI: {e}")
                try:
                    EveEntity.objects.resolve_name(id=f.entity_id)
                    entry = EveEntity.objects.get(id=f.entity_id)
                
                    data.append({
                        'filter': {
                            'id': f.entity_id,
                            'type': f.entity_type,
                            },
                        'display_name': entry.name,
                        "icon": entry_icon
                    })
                except Exception as e:
                    logger.error(f"Ошибка при поиске в eve universe: {e}")
            
        match filter:
            case 'rejected':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_REJECT).all()
                context['listTitle'] = _('Отмененные компенсации')
            case 'accepted':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_COMPLETE).all()
                context['listTitle'] = _('Выполненные компенсации')
            case 'all':
                kills = KillCompensation.objects.all()
                context['listTitle'] = _('Все компенсации')
            case BattleReport.BATTLEREPORT:
                kills = KillCompensation.objects.filter(source__report_type = BattleReport.BATTLEREPORT, status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Баттл репорты')
            case BattleReport.KILLMAIL:
                kills = KillCompensation.objects.filter(source__report_type = BattleReport.KILLMAIL, status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Киллмэйл')
            case _:
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Текущие компенсации')
        
        context["data"] = sorted(data, key=lambda filter: filter['display_name'])
        context["killmails"] = kills.order_by('status', 'timestamp','-loss_value').all()
        context["mailparser"] = CharMailParse.objects.get(character_id=character.character_id) if character and CharMailParse.objects.filter(character_id = character.character_id).exists() else None
        context["parse_check"] = 'checked' if context['mailparser'] is not None else ''
        context["character_id"] = character.character_id
        context["show_api"] = settings.DEBUG
        
        return context
    
    def post(self, request, *args, **kwargs):
        """
        Обрабатывает POST запросы (например, после выбора персонажа).
        Перенаправляем на GET запрос той же страницы.
        """
        filter_param = kwargs.get('filter', None)
        if filter_param:
            return redirect(f"/br_compensations/dashboard/{filter_param}/")
        return redirect('/br_compensations/dashboard/')


class BattleReportsView(LoginRequiredMixin,PermissionRequiredMixin, TemplateView):
    template_name="br_compensations/reports.html"
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["reports"] = BattleReport.objects.all().order_by('-added_at','-updatedAt')
        # context["form"] = AddBrForm()
        context["show_api"] = False 
        return context
    
    def post(self,request):
        brForm = AddBrForm(request.POST)
        if brForm.is_valid():
            report = BattleReport(link = brForm.cleaned_data['link'], comment = brForm.cleaned_data['comment'])
            report.save()
            return redirect('/br_compensations/reports/')
        return render(request,'/br_compensations/reports.html',{"form":brForm, "reports": BattleReport.objects.all()})

    
dashboard = DashboardView.as_view()
reports = BattleReportsView.as_view()