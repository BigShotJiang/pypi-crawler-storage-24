# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteSecuritySecrecyLevelRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'workspace': 'str',
        'id': 'str'
    }

    attribute_map = {
        'workspace': 'workspace',
        'id': 'id'
    }

    def __init__(self, workspace=None, id=None):
        r"""DeleteSecuritySecrecyLevelRequest

        The model defined in huaweicloud sdk

        :param workspace: DataArts Studio工作空间ID
        :type workspace: str
        :param id: 密级id
        :type id: str
        """
        
        

        self._workspace = None
        self._id = None
        self.discriminator = None

        self.workspace = workspace
        self.id = id

    @property
    def workspace(self):
        r"""Gets the workspace of this DeleteSecuritySecrecyLevelRequest.

        DataArts Studio工作空间ID

        :return: The workspace of this DeleteSecuritySecrecyLevelRequest.
        :rtype: str
        """
        return self._workspace

    @workspace.setter
    def workspace(self, workspace):
        r"""Sets the workspace of this DeleteSecuritySecrecyLevelRequest.

        DataArts Studio工作空间ID

        :param workspace: The workspace of this DeleteSecuritySecrecyLevelRequest.
        :type workspace: str
        """
        self._workspace = workspace

    @property
    def id(self):
        r"""Gets the id of this DeleteSecuritySecrecyLevelRequest.

        密级id

        :return: The id of this DeleteSecuritySecrecyLevelRequest.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this DeleteSecuritySecrecyLevelRequest.

        密级id

        :param id: The id of this DeleteSecuritySecrecyLevelRequest.
        :type id: str
        """
        self._id = id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteSecuritySecrecyLevelRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
