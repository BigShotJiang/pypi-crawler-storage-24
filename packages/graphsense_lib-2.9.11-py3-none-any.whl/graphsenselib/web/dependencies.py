import time
from typing import Any, Optional, Tuple

from graphsenselib.db.asynchronous.services.addresses_service import AddressesService
from graphsenselib.db.asynchronous.services.blocks_service import BlocksService
from graphsenselib.db.asynchronous.services.entities_service import EntitiesService
from graphsenselib.db.asynchronous.services.general_service import GeneralService
from graphsenselib.db.asynchronous.services.rates_service import RatesService
from graphsenselib.db.asynchronous.services.stats_service import StatsService
from graphsenselib.db.asynchronous.services.tags_service import (
    ConceptProtocol,
    TagsService,
)
from graphsenselib.db.asynchronous.services.tokens_service import TokensService
from graphsenselib.db.asynchronous.services.txs_service import TxsService
from graphsenselib.tagstore.db import TagstoreDbAsync
from graphsenselib.tagstore.db.queries import (
    LabelSearchResultPublic,
    TagstoreStatisticsPublic,
    Taxonomies,
    TaxonomiesPublic,
)
from graphsenselib.tagstore.db.queries import TagPublic

from graphsenselib.web.config import GSRestConfig


class MockTagstoreDb:
    """No-op TagStore implementation used when TagStore is unavailable."""

    is_mock = True

    async def get_actor_by_id(
        self, actor_id: str, include_tag_count: bool = True
    ) -> Optional[Any]:
        return None

    async def get_tags_by_actorid(
        self, actor_id: str, offset: int, page_size: Optional[int], groups: list[str]
    ) -> list[Any]:
        return []

    async def get_tags_by_label(
        self, label: str, offset: int, page_size: Optional[int], groups: list[str]
    ) -> list[Any]:
        return []

    async def get_taxonomies(self, include: Optional[set[Taxonomies]] = None) -> Any:
        include = include or set(Taxonomies)
        return TaxonomiesPublic(
            confidence=[] if Taxonomies.CONFIDENCE in include else None,
            country=[] if Taxonomies.COUNTRY in include else None,
            tag_subject=[] if Taxonomies.TAG_SUBJECT in include else None,
            tag_type=[] if Taxonomies.TAG_TYPE in include else None,
            concept=[] if Taxonomies.CONCEPT in include else None,
        )

    async def add_user_reported_tag(self, tag: Any, acl_group: str) -> Optional[str]:
        return None

    async def get_actors_by_subjectid(
        self, subject_id: str, groups: list[str]
    ) -> list[Any]:
        return []

    async def get_tags_by_subjectid(
        self, address: str, offset: int, limit: Optional[int], groups: list[str]
    ) -> list[Any]:
        return []

    async def get_best_cluster_tag(
        self, cluster_id: int, currency: str, groups: list[str]
    ) -> Optional[Any]:
        return None

    async def get_nr_tags_by_clusterid(
        self, cluster_id: int, currency: str, groups: list[str]
    ) -> int:
        return 0

    async def get_actors_by_clusterid(
        self, cluster_id: int, currency: str, groups: list[str]
    ) -> list[Any]:
        return []

    async def get_tags_by_clusterid(
        self,
        cluster_id: int,
        currency: str,
        offset: int,
        page_size: Optional[int],
        groups: list[str],
    ) -> list[Any]:
        return []

    async def get_labels_by_subjectid(
        self, subject_id: str, groups: list[str]
    ) -> list[str]:
        return []

    async def get_labels_by_clusterid(
        self, cluster_id: str, groups: list[str]
    ) -> list[str]:
        return []

    async def get_network_statistics_cached(self) -> TagstoreStatisticsPublic:
        return TagstoreStatisticsPublic(by_network={})

    async def search_labels(
        self,
        expression: str,
        limit: int,
        groups: list[str],
        query_actors: bool,
        query_labels: bool,
    ) -> LabelSearchResultPublic:
        return LabelSearchResultPublic(actor_labels=[], tag_labels=[])


class TagAccessLoggerTagstoreProxy:
    """Adds logging for which tags are accessed from the tagstore
    it intercepts calls to the tagstore DB
    and logs returned tags to redis.
    """

    def __init__(
        self, tagstore_db: TagstoreDbAsync, redis_client: Any, key_prefix: str
    ):
        self.tagstore_db = tagstore_db
        self.redis_client = redis_client
        self.key_prefix = key_prefix

    def __getattr__(self, name):
        """Proxy all method calls to the underlying tagstore_db"""
        attr = getattr(self.tagstore_db, name)

        if callable(attr):

            async def wrapper(*args, **kwargs):
                # Call the original method
                result = await attr(*args, **kwargs)

                # Log tag access if this method returns TagPublic objects
                should_log, is_list = self._should_log_result(result)
                if self.redis_client and should_log:
                    if is_list:
                        for tag in result:
                            await self._log_tag_access(name, tag, *args, **kwargs)
                    else:
                        await self._log_tag_access(name, result, *args, **kwargs)

                return result

            return wrapper
        else:
            return attr

    def _should_log_result(self, result: Any) -> Tuple[bool, bool]:
        """Determine if this result should be logged based on data type"""

        if not result:
            return False, False

        # Check if result is a PublicTag
        if isinstance(result, TagPublic):
            return True, False

        # Check if result is a list of TagPublic objects
        if hasattr(result, "__iter__") and not isinstance(result, str):
            try:
                # Check if all items in the iterable are TagPublic objects
                for item in result:
                    if isinstance(item, TagPublic):
                        return True, True
                    break  # Only check first item for performance
            except (TypeError, StopIteration):
                pass

        return False, False

    async def _log_tag_access(self, method_name: str, tag: TagPublic, *args, **kwargs):
        """Log tag access information to Redis"""

        current_time = time.localtime()
        timestamp = time.strftime("%Y-%m-%d", current_time)
        key = "|".join(
            (self.key_prefix, timestamp, tag.creator, tag.network, tag.identifier)
        )
        await self.redis_client.incr(key)


class ServiceContainer:
    def __init__(
        self,
        config: GSRestConfig,
        db: any,
        tagstore_db: any,
        concepts_cache_service: ConceptProtocol,
        logger: any,
        redis_client: Optional[Any] = None,
        log_tag_access_prefix: Optional[str] = None,
    ):
        tsdb = tagstore_db if tagstore_db is not None else MockTagstoreDb()
        if not hasattr(tsdb, "search_labels"):
            tsdb = TagstoreDbAsync(tsdb)
        self.config = config
        self.db = db
        self.tagstore_db = (
            TagAccessLoggerTagstoreProxy(tsdb, redis_client, log_tag_access_prefix)
            if log_tag_access_prefix
            else tsdb
        )
        self.logger = logger
        self.category_cache_service = concepts_cache_service

        # Initialize services with dependencies
        self._stats_service = StatsService(
            db=db, tagstore=self.tagstore_db, logger=logger
        )
        self._rates_service = RatesService(
            db=db, stats_service=self._stats_service, logger=logger
        )
        self._tokens_service = TokensService(db=db, logger=logger)

        self._tags_service = TagsService(
            db=db,
            tagstore=self.tagstore_db,
            concepts_cache_service=self.category_cache_service,
            logger=logger,
        )
        self._txs_service = TxsService(
            db=db, rates_service=self._rates_service, logger=logger
        )
        self._blocks_service = BlocksService(
            db=db,
            rates_service=self._rates_service,
            config=config,
            logger=logger,
        )
        self._general_service = GeneralService(
            db=db,
            tagstore=self.tagstore_db,
            stats_service=self._stats_service,
            logger=logger,
        )
        self._entities_service = EntitiesService(
            db=db,
            tags_service=self._tags_service,
            blocks_service=self._blocks_service,
            rates_service=self._rates_service,
            logger=logger,
        )

        self._addresses_service = AddressesService(
            db=db,
            tags_service=self._tags_service,
            entities_service=self._entities_service,
            blocks_service=self._blocks_service,
            rates_service=self._rates_service,
            logger=logger,
        )

    @property
    def tags_service(self) -> TagsService:
        return self._tags_service

    @property
    def rates_service(self) -> RatesService:
        return self._rates_service

    @property
    def blocks_service(self) -> BlocksService:
        return self._blocks_service

    @property
    def tokens_service(self) -> TokensService:
        return self._tokens_service

    @property
    def stats_service(self) -> StatsService:
        return self._stats_service

    @property
    def txs_service(self) -> TxsService:
        return self._txs_service

    @property
    def general_service(self) -> GeneralService:
        return self._general_service

    @property
    def addresses_service(self) -> AddressesService:
        return self._addresses_service

    @property
    def entities_service(self) -> EntitiesService:
        return self._entities_service
