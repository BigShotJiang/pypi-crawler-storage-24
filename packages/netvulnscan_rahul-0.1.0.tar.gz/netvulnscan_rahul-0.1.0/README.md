# Network Vulnerability Scanner

A Python-based CLI tool for scanning network ports, detecting service versions via banner grabbing, and querying the NVD API for known CVEs.

## Installation

### Prerequisites

* Python 3.7+
* `pip`

### Install from Source

1. Clone the repository:
   ```bash
   git clone <your-github-repo-url>
   cd "web scanner"
   ```

2. (Optional) Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows, use: venv\Scripts\activate
   ```

3. Install the package and its dependencies:
   ```bash
   pip install -e .
   ```

## Usage

After installation, the tool is available as a global command called `netvulnscan`.

```bash
netvulnscan --target <IP_OR_HOSTNAME> [OPTIONS]
```

### Examples

Scan a target IP for open ports (1-1024) and print a terminal report (default):
```bash
netvulnscan --target 192.168.1.1
```

Scan specific ports with verbose output:
```bash
netvulnscan --target example.com --ports 22,80,443 --verbose
```

Export results to an HTML report:
```bash
netvulnscan --target 10.0.0.5 --ports 1-100 --output html
```

### Options

* `--target` (Required): Target IP or hostname.
* `--ports`: Port range to scan (e.g., `1-1024` or `80`). Default: `1-1024`.
* `--timeout`: Timeout for connections in seconds. Default: `1.0`.
* `--output`: Output format (`terminal`, `json`, `html`). Default: `terminal`.
* `--verbose`: Enable verbose output.

## Disclaimer

**This tool should only be used on systems you own or have permission to test.**
