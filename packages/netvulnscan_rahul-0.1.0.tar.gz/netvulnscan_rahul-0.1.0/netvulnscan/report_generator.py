import json
from rich.console import Console
from rich.table import Table

def calculate_risk_score(cves_data):
    """
    Calculates the overall risk score by finding the maximum CVSS score.
    Returns a float between 0.0 and 10.0.
    """
    max_score = 0.0
    for cves in cves_data.values():
        for cve in cves:
            if cve["score"] > max_score:
                max_score = cve["score"]
    return max_score

def generate_terminal_report(host_info, open_ports, service_versions, cves_data):
    """
    Prints a colored, formatted report to the terminal using the rich library.
    """
    console = Console()
    console.print("\n[bold blue]=== Vulnerability Scan Report ===[/bold blue]")
    console.print(f"[bold]Target IP:[/bold] {host_info['ip']}")
    console.print(f"[bold]Hostname:[/bold] {host_info['hostname']}\n")
    
    risk_score = calculate_risk_score(cves_data)
    color = "green"
    if risk_score > 3.9: color = "yellow"
    if risk_score > 6.9: color = "red"
    if risk_score > 8.9: color = "bold red"
    
    console.print(f"[bold]Overall Risk Score:[/bold] [{color}]{risk_score} / 10.0[/{color}]\n")
    
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Port", justify="right")
    table.add_column("State")
    table.add_column("Service")
    table.add_column("Version/Banner")
    table.add_column("CVEs Found")
    
    for port_info in open_ports:
        port_num = port_info['port']
        state = port_info['state']
        service = port_info['service']
        version = service_versions.get(port_num, "Unknown")
        cves = cves_data.get(port_num, [])
        
        cve_count_str = f"{len(cves)} found"
        if len(cves) > 0:
            cve_count_str = f"[red]{len(cves)} found[/red]"
            
        table.add_row(str(port_num), state, service, version, cve_count_str)
        
    console.print(table)
    
    for port_num, cves in cves_data.items():
        if cves:
            console.print(f"\n[bold red]CVEs for Port {port_num} ({service_versions.get(port_num, 'Unknown')}):[/bold red]")
            for cve in cves:
                console.print(f"  - {cve['id']} (Score: {cve['score']}, Severity: {cve['severity']})")

def generate_json_report(host_info, open_ports, service_versions, cves_data, filepath):
    """
    Outputs the scan results to a JSON file.
    """
    data = {
        "host_info": host_info,
        "risk_score": calculate_risk_score(cves_data),
        "open_ports": open_ports,
        "service_versions": service_versions,
        "cves": cves_data
    }
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=4)
    print(f"\n[+] JSON report saved to {filepath}")

def generate_html_report(host_info, open_ports, service_versions, cves_data, filepath):
    """
    Outputs the scan results to a simple HTML file.
    """
    risk_score = calculate_risk_score(cves_data)
    
    html = f"""
    <html>
    <head><title>Scan Report - {host_info['ip']}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ddd; padding: 10px; text-align: left; }}
        th {{ background-color: #f2f2f2; }}
        .critical {{ color: #8F00FF; font-weight: bold; }}
        .high {{ color: red; font-weight: bold; }}
        .medium {{ color: orange; font-weight: bold; }}
        .low {{ color: green; font-weight: bold; }}
    </style>
    </head>
    <body>
    <h1>Vulnerability Scan Report</h1>
    <p><strong>Target IP:</strong> {host_info['ip']}</p>
    <p><strong>Hostname:</strong> {host_info['hostname']}</p>
    <p><strong>Overall Risk Score:</strong> {risk_score} / 10.0</p>
    
    <h2>Open Ports</h2>
    <table>
        <tr><th>Port</th><th>State</th><th>Service</th><th>Version/Banner</th><th>CVE Count</th></tr>
    """
    
    for port_info in open_ports:
        port_num = port_info['port']
        state = port_info['state']
        service = port_info['service']
        version = service_versions.get(port_num, "Unknown")
        cve_count = len(cves_data.get(port_num, []))
        
        html += f"<tr><td>{port_num}</td><td>{state}</td><td>{service}</td><td>{version}</td><td>{cve_count}</td></tr>\n"
        
    html += "</table>\n<h2>CVE Details</h2>\n"
    
    for port_num, cves in cves_data.items():
        if cves:
            html += f"<h3>Port {port_num} ({service_versions.get(port_num, 'Unknown')})</h3><ul>"
            for cve in cves:
                severity = cve['severity'].lower()
                cls = "low"
                if severity == "critical": cls = "critical"
                elif severity == "high": cls = "high"
                elif severity == "medium": cls = "medium"
                
                html += f"<li><strong>{cve['id']}</strong>: Score <span class='{cls}'>{cve['score']}</span> ({cve['severity']})</li>"
            html += "</ul>"
            
    html += "</body></html>"
    
    with open(filepath, 'w') as f:
        f.write(html)
    print(f"\n[+] HTML report saved to {filepath}")
