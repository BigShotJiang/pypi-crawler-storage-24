import argparse
import socket
import sys
from rich.console import Console

from port_scanner import scan_ports
from service_detector import grab_banner, detect_service_version
from cve_lookup import lookup_cves
from report_generator import generate_terminal_report, generate_json_report, generate_html_report

def main():
    parser = argparse.ArgumentParser(description="Python-based Network Vulnerability Scanner")
    parser.add_argument("--target", required=True, help="Target IP or hostname")
    parser.add_argument("--ports", default="1-1024", help="Port range to scan (e.g., 1-1024 or 80)")
    parser.add_argument("--timeout", type=float, default=1.0, help="Timeout for connections in seconds")
    parser.add_argument("--output", choices=["terminal", "json", "html"], default="terminal", help="Output format (terminal, json, html)")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose output")
    
    args = parser.parse_args()
    console = Console()
    
    console.print("[bold red]DISCLAIMER: This tool should only be used on systems you own or have permission to test.[/bold red]\n")
    
    try:
        target_ip = socket.gethostbyname(args.target)
    except socket.gaierror:
        console.print(f"[bold red][!] Could not resolve hostname: {args.target}[/bold red]")
        sys.exit(1)
        
    try:
        hostname = socket.gethostbyaddr(target_ip)[0]
    except socket.herror:
        hostname = "Unknown"
        
    host_info = {
        "ip": target_ip,
        "hostname": hostname
    }
    
    console.print(f"[*] Starting scan on {target_ip} ({hostname})...")
    console.print(f"[*] Scanning ports: {args.ports}")
    
    open_ports = scan_ports(target_ip, args.ports, args.timeout)
    
    if not open_ports:
        console.print("[-] No open ports found or target unreachable.")
        sys.exit(0)
        
    console.print(f"[+] Found {len(open_ports)} open port(s).")
    if args.verbose:
        for p in open_ports:
            console.print(f"    - Port {p['port']} is open ({p['service']})")
    
    service_versions = {}
    cves_data = {}
    
    console.print("\n[*] Performing banner grabbing and service detection...")
    for port_info in open_ports:
        port = port_info['port']
        banner = grab_banner(target_ip, port, args.timeout)
        version = detect_service_version(banner)
        service_versions[port] = version
        if args.verbose:
            status_text = f"    - Port {port}: Banner Grabbed -> {version}"
            console.print(status_text)
            
    console.print("\n[*] Looking up CVEs (this will take a while due to NVD API delay)...")
    for port, version in service_versions.items():
        if version != "Unknown" and version != "":
            if args.verbose:
                console.print(f"    - Querying NVD for: {version}")
                
            cves = lookup_cves(version)
            cves_data[port] = cves
            
            if args.verbose and cves:
                console.print(f"      [red]\u2717 Found {len(cves)} CVE(s)[/red]")
            elif args.verbose:
                console.print(f"      [green]\u2713 No known CVEs found[/green]")
        else:
            cves_data[port] = []
            
    # Output Report
    if args.output == "terminal":
        generate_terminal_report(host_info, open_ports, service_versions, cves_data)
    elif args.output == "json":
        generate_json_report(host_info, open_ports, service_versions, cves_data, "report.json")
    elif args.output == "html":
        generate_html_report(host_info, open_ports, service_versions, cves_data, "report.html")

if __name__ == "__main__":
    main()
