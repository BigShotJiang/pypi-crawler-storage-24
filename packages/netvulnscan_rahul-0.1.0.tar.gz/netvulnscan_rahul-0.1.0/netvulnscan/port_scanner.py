import socket
import concurrent.futures

def scan_port(target, port, timeout):
    """
    Scans a single port to see if it is open.
    Returns a dictionary with port information if open, else None.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            if s.connect_ex((target, port)) == 0:
                try:
                    service = socket.getservbyport(port)
                except OSError:
                    service = "unknown"
                return {"port": port, "state": "open", "service": service}
    except Exception:
        pass
    return None

def scan_ports(target, ports_range, timeout=1.0, max_workers=100):
    """
    Concurrently scans a range of ports on the target.
    """
    open_ports = []
    
    if "-" in ports_range:
        start_port, end_port = map(int, ports_range.split('-'))
        ports = range(start_port, end_port + 1)
    else:
        ports = [int(ports_range)]
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(scan_port, target, p, timeout): p for p in ports}
        for future in concurrent.futures.as_completed(futures):
            res = future.result()
            if res:
                open_ports.append(res)
    
    return sorted(open_ports, key=lambda x: x["port"])
