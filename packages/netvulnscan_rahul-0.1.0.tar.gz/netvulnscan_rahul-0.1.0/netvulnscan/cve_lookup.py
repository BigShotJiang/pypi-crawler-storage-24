import requests
import time

# To avoid rate limits (5 requests per 30 seconds without an API key),
# we introduce a delay between unauthenticated requests.
RATE_LIMIT_DELAY = 6.0 

def lookup_cves(keywordSearch):
    """
    Queries the NVD API for CVEs based on a keyword search (e.g., "Apache 2.4.41").
    """
    if not keywordSearch or keywordSearch.lower() == "unknown":
        return []
    
    url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    params = {
        "keywordSearch": keywordSearch,
        "resultsPerPage": 5  # Limit results to keep report concise
    }
    
    try:
        time.sleep(RATE_LIMIT_DELAY)
        
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 403:
            print(f"[!] Rate limited by NVD API for query '{keywordSearch}'. Try again later.")
            return []
            
        response.raise_for_status()
        data = response.json()
        
        cves = []
        for vulnerability in data.get("vulnerabilities", []):
            cve = vulnerability.get("cve", {})
            cve_id = cve.get("id")
            
            # Attempt to extract the most modern CVSS metrics available
            metrics = cve.get("metrics", {})
            score = 0.0
            severity = "Unknown"
            
            if "cvssMetricV31" in metrics:
                cvss_data = metrics["cvssMetricV31"][0].get("cvssData", {})
                score = cvss_data.get("baseScore", 0.0)
                severity = cvss_data.get("baseSeverity", "Unknown")
            elif "cvssMetricV30" in metrics:
                cvss_data = metrics["cvssMetricV30"][0].get("cvssData", {})
                score = cvss_data.get("baseScore", 0.0)
                severity = cvss_data.get("baseSeverity", "Unknown")
            elif "cvssMetricV2" in metrics:
                cvss_data = metrics["cvssMetricV2"][0].get("cvssData", {})
                score = cvss_data.get("baseScore", 0.0)
                severity = metrics["cvssMetricV2"][0].get("baseSeverity", "Unknown")
                
            cves.append({
                "id": cve_id,
                "score": float(score),
                "severity": severity
            })
            
        return cves
        
    except requests.exceptions.RequestException as e:
        print(f"[!] API Request Failed for '{keywordSearch}': {e}")
        return []
