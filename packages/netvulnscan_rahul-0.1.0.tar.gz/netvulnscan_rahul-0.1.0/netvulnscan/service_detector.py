import socket
import select
import re

def grab_banner(target, port, timeout=2.0):
    """
    Attempts to connect to a port and retrieve its service banner.
    Sends an HTTP GET probe if the service does not send a banner immediately.
    """
    banner = ""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((target, port))
            
            # Wait to see if server sends an initial greeting (e.g., SSH, FTP)
            ready = select.select([s], [], [], timeout / 2)
            if ready[0]:
                data = s.recv(1024)
                if data:
                    banner = data.decode('utf-8', errors='ignore').strip()
            
            # If no banner received, try sending a basic HTTP request
            if not banner:
                s.sendall(b"HEAD / HTTP/1.0\r\n\r\n")
                ready = select.select([s], [], [], timeout / 2)
                if ready[0]:
                    data = s.recv(1024)
                    if data:
                        banner = data.decode('utf-8', errors='ignore').strip()
    except Exception:
        pass
    return banner

def detect_service_version(banner):
    """
    Attempts to parse a captured banner string to find a recognizable software name and version.
    """
    if not banner:
        return "Unknown"
        
    lines = banner.split('\n')
    
    # 1. Look for 'Server' HTTP headers
    for line in lines:
        if line.lower().startswith('server:'):
            # Example: "Server: Apache/2.4.41 (Ubuntu)"
            parts = line.split(':', 1)
            if len(parts) > 1:
                server_val = parts[1].strip()
                # Remove common OS hints in parentheses to improve CVE lookup
                server_val = re.sub(r'\(.*?\)', '', server_val).strip()
                # Replace '/' with space: "Apache/2.4.41" -> "Apache 2.4.41"
                return server_val.replace('/', ' ')
                
    # 2. Look for typical SSH strings
    for line in lines:
        if line.startswith('SSH-'):
            # Example: "SSH-2.0-OpenSSH_8.2p1 Ubuntu-4ubuntu0.1"
            match = re.search(r'(OpenSSH[_\-][\w\.]+)', line, re.IGNORECASE)
            if match:
                return match.group(1).replace('_', ' ').replace('-', ' ')
            return line[:40].strip()
            
    # 3. Look for typical FTP strings
    for line in lines:
        if '220' in line and (re.search(r'FTP|vsFTPd|ProFTPD', line, re.IGNORECASE)):
            # Example: "220 (vsFTPd 3.0.3)"
            clean = line.replace('220', '').strip()
            # Remove any parentheses
            clean = re.sub(r'[\(\)]', '', clean).strip()
            return clean[:40]
            
    # 4. Fallback: Return a sanitized first line snippet
    for line in lines:
        if line.strip():
            val = line.strip()[:40]
            # Avoid returning bare generic HTTP statuses
            if 'HTTP/1' not in val:
                return val
            
    return "Unknown"
