from pathlib import Path
import sys
from typing import Optional

import paramiko
from paramiko import SSHClient, AutoAddPolicy, SSHException

from .utils import run_local, console
from .rich_console import header, success, error, warning
from .config import settings

import subprocess
import shutil
import time


class GPUServer:
    def __init__(
        self,
        ip: str,
        user: str,
        password: Optional[str] = None,
        key_type: str = "ed25519",
        dry_run: bool = False,
    ):
        self.ip = ip
        self.user = user
        self.password = password
        self.dry_run = dry_run
        self.key_type = key_type
        self.alias = f"gpu-server-{ip.replace('.', '-')}"
        self.key_path = Path.home() / f".ssh/id_{key_type}_gpu"
        self.pub_path = self.key_path.with_suffix(".pub")
        self.config_file = Path.home() / ".ssh/config"

    def generate_key(self) -> None:
        header("Генерация SSH-ключа")
        if self.key_path.exists():
            success("SSH-ключ уже существует")
            return

        if self.dry_run:
            console.print("[dim]DRY-RUN: ssh-keygen[/dim]")
            return

        cmd = (
            ["ssh-keygen", "-t", self.key_type, "-f", str(self.key_path), "-N", "", "-q"]
            if self.key_type == "ed25519"
            else ["ssh-keygen", "-t", "rsa", "-b", "4096", "-f", str(self.key_path), "-N", "", "-q"]
        )
        run_local(cmd)
        success(f"Ключ {self.key_type} создан")

    def copy_pubkey(self) -> None:
        header("Копирование публичного ключа на сервер")
        if self.dry_run:
            console.print("[dim]DRY-RUN: копирование ключа через paramiko[/dim]")
            return

        if not self.password:
            error("Для первого подключения нужен пароль")
            sys.exit(1)

        try:
            client = SSHClient()
            client.set_missing_host_key_policy(AutoAddPolicy())
            client.connect(
                hostname=self.ip,
                username=self.user,
                password=self.password,
                timeout=15,
                look_for_keys=False,
                allow_agent=False,
            )

            pubkey = self.pub_path.read_text().strip()
            cmd = (
                f"mkdir -p ~/.ssh && chmod 700 ~/.ssh && "
                f"echo '{pubkey}' >> ~/.ssh/authorized_keys && "
                f"chmod 600 ~/.ssh/authorized_keys"
            )

            _, stdout, stderr = client.exec_command(cmd)
            stdout.read()
            stderr.read()
            client.close()
            success("Публичный ключ добавлен")
        except SSHException as e:
            error(f"Не удалось скопировать ключ: {e}")
            sys.exit(1)

    def setup_ssh_config(self) -> None:
        header("Настройка ~/.ssh/config")
        if self.dry_run:
            console.print("[dim]DRY-RUN: запись алиаса[/dim]")
            return

        entry = f"""
Host {self.alias}
    HostName {self.ip}
    User {self.user}
    IdentityFile {self.key_path}
    StrictHostKeyChecking no
"""

        self.config_file.parent.mkdir(exist_ok=True)
        self.config_file.touch(exist_ok=True)

        content = self.config_file.read_text()
        if f"Host {self.alias}" not in content:
            with open(self.config_file, "a", encoding="utf-8") as f:
                f.write(entry)
            success(f"Алиас {self.alias} добавлен")
        else:
            success("Алиас уже существует")

    def test_connection(self) -> None:
        header("Тест SSH-подключения по ключу")
        if self.dry_run:
            console.print("[dim]DRY-RUN: тест SSH[/dim]")
            return

        try:
            client = SSHClient()
            client.set_missing_host_key_policy(AutoAddPolicy())
            client.connect(
                hostname=self.ip,
                username=self.user,
                key_filename=str(self.key_path),
                timeout=10,
                look_for_keys=False,
                allow_agent=False,
            )
            client.exec_command("exit")
            client.close()
            success("SSH по ключу работает")
        except Exception as e:
            error(f"Тест SSH провалился: {e}")
            sys.exit(1)

    def install_ollama(self) -> None:
        header("Установка Ollama")
        if self.dry_run:
            console.print("[dim]DRY-RUN: установка Ollama[/dim]")
            return

        client = SSHClient()
        client.set_missing_host_key_policy(AutoAddPolicy())
        client.connect(hostname=self.ip, username=self.user, key_filename=str(self.key_path))

        _, stdout, _ = client.exec_command("command -v ollama")
        if stdout.read().decode().strip():
            success("Ollama уже установлен")
            client.close()
            return

        if not self.password:
            error("Для установки Ollama нужен пароль (sudo)")
            sys.exit(1)

        sudo_client = SSHClient()
        sudo_client.set_missing_host_key_policy(AutoAddPolicy())
        sudo_client.connect(
            hostname=self.ip,
            username=self.user,
            password=self.password,
            timeout=15,
        )

        install_cmd = "bash -c 'curl -fsSL https://ollama.com/install.sh | sh'"
        stdin, stdout, stderr = sudo_client.exec_command(f"sudo -S {install_cmd}", get_pty=True)
        stdin.write(self.password + "\n")
        stdin.flush()
        
        channel = stdout.channel
        while not channel.exit_status_ready():
            if channel.recv_ready():
                print(channel.recv(1024).decode("utf-8", errors="replace"), end="", flush=True)
            if channel.recv_stderr_ready():
                print(channel.recv_stderr(1024).decode("utf-8", errors="replace"), end="", flush=True)
    
        output = stdout.read().decode()
        err_output = stderr.read().decode()
        if err_output:
            console.print(err_output, end="")
            
        console.print("[bold blue]Запускаем Ollama сервис...[/bold blue]")
        start_cmd = "sudo systemctl enable ollama && sudo systemctl start ollama"
        _, stdout, stderr = sudo_client.exec_command(start_cmd)
        
        stdout.read()
        err_output = stderr.read().decode()

        if err_output:
            console.print(err_output, end="")

        success("Ollama сервис запущен")

        sudo_client.close()
        client.close()
        success("Ollama успешно установлен")

    def pull_model(self, model: str) -> None:
        header(f"Скачивание модели {model}")
        if self.dry_run:
            console.print(f"[dim]DRY-RUN: ollama pull {model}[/dim]")
            return

        client = SSHClient()
        client.set_missing_host_key_policy(AutoAddPolicy())
        client.connect(hostname=self.ip, username=self.user, key_filename=str(self.key_path))

        _, stdout, _ = client.exec_command("command -v ollama")
        if not stdout.read().decode().strip():
            error("Ollama не установлен. Добавь --install-ollama")
            sys.exit(1)

        def check_ollama_service():
            _, stdout, stderr = client.exec_command("ollama list")
            exit_code = stdout.channel.recv_exit_status()
            if exit_code != 0:
                err_output = stderr.read().decode()
                if "could not connect to ollama server" in err_output:
                    return False, err_output
            return True, None

        service_ok, err_msg = check_ollama_service()
        if not service_ok:
            warning("Ollama сервис не отвечает. Пытаемся запустить...")

            if self.password:
                sudo_client = SSHClient()
                sudo_client.set_missing_host_key_policy(AutoAddPolicy())
                sudo_client.connect(
                    hostname=self.ip,
                    username=self.user,
                    password=self.password,
                    timeout=15,
                )

                console.print("[dim]Запуск через systemctl...[/dim]")
                stdin, stdout, stderr = sudo_client.exec_command("sudo -S systemctl start ollama")
                stdin.write(self.password + "\n")
                stdin.flush()
                stdout.read()
                stderr.read()
                sudo_client.close()

                console.print("[dim]Даём 5 секунд на запуск...[/dim]")
                time.sleep(5)

                service_ok, err_msg = check_ollama_service()
                if not service_ok:
                    warning(f"systemctl не помог: {err_msg}")
                    console.print("[dim]Пробуем запустить ollama serve в фоне...[/dim]")
                    sudo_client2 = SSHClient()
                    sudo_client2.set_missing_host_key_policy(AutoAddPolicy())
                    sudo_client2.connect(
                        hostname=self.ip,
                        username=self.user,
                        password=self.password,
                        timeout=15,
                    )
                    start_cmd = f"nohup ollama serve > /tmp/ollama.log 2>&1 &"
                    stdin, stdout, stderr = sudo_client2.exec_command(f"sudo -S -u {self.user} bash -c '{start_cmd}'")
                    stdin.write(self.password + "\n")
                    stdin.flush()
                    stdout.read()
                    stderr.read()
                    sudo_client2.close()

                    console.print("[dim]Даём 10 секунд на запуск...[/dim]")
                    time.sleep(10)

                    # Последняя проверка
                    service_ok, err_msg = check_ollama_service()
                    if not service_ok:
                        error(f"Не удалось запустить сервис: {err_msg}")
                        sys.exit(1)
                    else:
                        success("Сервис Ollama успешно запущен (через nohup)")
                else:
                    success("Сервис Ollama успешно запущен (через systemctl)")
            else:
                error("Пароль не задан, невозможно автоматически запустить сервис.")
                console.print("Запустите вручную: ssh {} 'sudo systemctl start ollama' или 'ollama serve'".format(self.alias))
                sys.exit(1)

        _, stdout, _ = client.exec_command(f"ollama list | grep -q '{model}'")
        if stdout.channel.recv_exit_status() == 0:
            success(f"Модель {model} уже есть")
            client.close()
            return

        console.print(f"[bold blue]Скачиваем {model}...[/bold blue]")
        stdin, stdout, stderr = client.exec_command(f"ollama pull {model}", get_pty=True)
        channel = stdout.channel

        while not channel.exit_status_ready():
            if channel.recv_ready():
                print(channel.recv(1024).decode("utf-8", errors="replace"), end="", flush=True)
            if channel.recv_stderr_ready():
                print(channel.recv_stderr(1024).decode("utf-8", errors="replace"), end="", flush=True)

        print(stdout.read().decode(), end="")
        err_out = stderr.read().decode()
        if err_out:
            print(err_out, end="")
        client.close()
        success(f"Модель {model} готова")

    def open_vscode(self) -> None:
        header("Открываем VS Code Remote")
        if self.dry_run:
            console.print(f"[dim]DRY-RUN: code --remote ssh-remote+{self.alias}[/dim]")
            return
        
        if shutil.which("code"):
            subprocess.run(["code", "--remote", f"ssh-remote+{self.alias}"])
            success("VS Code Remote открыт")
        else:
            warning("Команда 'code' не найдена. Установи VS Code CLI")


def get_plan(server: GPUServer, install_ollama: bool, model: Optional[str], no_vscode: bool) -> list:
    plan = [
        ("Генерация ключа", "ed25519 (если нет)"),
        ("Копирование ключа", "на сервер"),
        ("SSH config", f"алиас {server.alias}"),
        ("Тест подключения", "по ключу"),
    ]
    if install_ollama:
        plan.append(("Ollama", "установка"))
    if model:
        plan.append(("Модель", f"ollama pull {model}"))
    if not no_vscode:
        plan.append(("VS Code", "открытие Remote"))
    return plan