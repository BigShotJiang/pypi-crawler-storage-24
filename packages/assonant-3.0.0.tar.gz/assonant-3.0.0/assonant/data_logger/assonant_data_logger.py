from typing import Any, Dict, List, Optional, Union

from assonant.data_classes import AssonantComponentFactory, AssonantDataHandlerFactory
from assonant.data_classes.components import Beamline, Component, Entry
from assonant.data_classes.data_handlers import Axis, DataHandler
from assonant.data_classes.exceptions import AxisInsertionError, FieldInsertionError
from assonant.data_retriever import AssonantDataRetriever
from assonant.file_writer import AssonantFileWriter
from assonant.hierarchizer import Hierarchizer
from assonant.metadata_retriever import AssonantMetadataRetriever
from assonant.naming_standards import AcquisitionType, BeamlineName, ExperimentStage
from assonant.path_builder import BeamlinePathBuilder

# NOTE: AssonantDataLogger can probably be classified as a GodObject at this moment.
#  Some Refactor would be good to enhance the code quality based on SOLID principles.


class AssonantDataLogger:
    """Assonant Data Logger.

    Object responsible to automate data collection, standardization and logging based on
    pré-defined configurations.
    """

    def __init__(
        self,
        beamline_name: BeamlineName,
        data_schema_file_path: Optional[str] = None,
    ):
        """AssonantDataLogger Constructor.

        Args:
            beamline_name (BeamlineName): Beamline name where the experiment is being executed.
            be pre-initiallized during AssonantDataLogger instantiation or not. Defaults to False.
            data_schema_file_path (str): Path to data schema file.
        """

        self.beamline_name = beamline_name

        self.path_builder = BeamlinePathBuilder()
        self.path_builder.set_beamline_name(beamline_name.value.lower())

        if data_schema_file_path is None:
            # No data schema file path passed? - Use path_builder to create it based on beamline name
            self.data_schema_file_path = self.path_builder.build_path_to_data_schema()
        else:
            # Use passed data schema file path
            self.data_schema_file_path = data_schema_file_path

        self.metadata_retriever = AssonantMetadataRetriever(metadata_source_file_path=self.data_schema_file_path)
        self.hierarchizer = Hierarchizer(self.data_schema_file_path, self.metadata_retriever)
        self.pv_names = {}
        self.file_writer = AssonantFileWriter("nexus")

    def _create_data_handler_from_pv_info(self, pv_info: Dict[str, Dict[str, Any]]) -> DataHandler:
        """Create data handler based on passed pv_info Dict.

        Args:
            pv_info (Dict[str, Dict[str, Any]]): Dict containing acquired PV info. The Dict follows must follow
            the structure proposed for the get_pvs_info() call from the IAssonantDataRetriever Interface.

        Returns:
            DataHandler: Specific DataHandler related to the passed info.
        """
        param_names = ["value", "unit", "transformation_type", "timestamps", "timestamps_unit"]
        ignored = ["name"]
        extra_metadata = {}
        params = {}

        # Search into dict which names are parameters for the create method from factory, the rest
        # is considered as extra_metadata
        data_handler_info = pv_info["data_handler_info"]
        for info_name in data_handler_info:
            if info_name not in ignored:
                if info_name not in param_names:
                    extra_metadata[info_name] = data_handler_info[info_name]
                else:
                    params[info_name] = data_handler_info[info_name]

        params["extra_metadata"] = extra_metadata

        return AssonantDataHandlerFactory.create_data_handler(**params)

    def _add_fields_to_component(self, component: Component, fields: Dict[str, DataHandler]):
        """Add fields from dict to passed Component.

        Args:
            component (Component): Component which fields will be inserted to.
            fields (dict[str, DataHandler]): Dict of fields that will be inserted on component.
        """
        for field_name in fields:
            try:
                component.add_field(name=field_name, new_field=fields[field_name])
            except FieldInsertionError:
                # To avoid breaking and not logging other data, errors in insertion are ignored and logged
                # TODO: Put this into a log file instead of printing it
                print(
                    f"{field_name} field was not add to {component.name} due to an Error during its insertion on fields dict"
                )

    def _add_positions_to_component(self, component: Component, positions: Dict[str, Axis]):
        """Add axis from dict to passed Component.

        Args:
            component (Component): Component which axis will be inserted to.
            positions (dict[str, Axis]): Dict of axis that will be inserted on component.
        """
        for axis_name in positions:
            try:
                component.add_position(name=axis_name, new_axis=positions[axis_name])
            except AxisInsertionError:
                # To avoid breaking and not logging other data, errors in insertion are ignored and logged
                # TODO: Put this into a log file instead of printing it
                print(
                    f"{axis_name} Axis was not add to {component.name} due to an Error during its insertion on positions dict"
                )

    def _create_component_from_pv_info(self, pv_info: Dict[str, Dict[str, Any]]) -> Component:
        """Create an Assonant Component based on passed dict with PV data.

        Args:
            pv_info (Dict[str, Dict[str, Any]]): Dict containing Component info retrieved from pv_info dict.
            The passed dict must follow the structure defined on get_pvs_info() method from IAssonantDataRetriever.

        Returns:
            Component: Assonant Component respective to passed PV data.
        """
        component_info = pv_info["component_info"]
        return AssonantComponentFactory.create_component_by_class_name(
            class_name=component_info["class"], component_name=component_info["name"]
        )

    def _build_experiment_entry(
        self, components: List[Component], experiment_stage: ExperimentStage, acquisition_type: AcquisitionType
    ) -> Entry:
        """Wrap passed components into an Entry structure based on ExperimentStage and AcquisitionType."""

        exp_stage_entry = AssonantComponentFactory.create_component_by_class_type(Entry, experiment_stage.value)
        acq_type_entry = AssonantComponentFactory.create_component_by_class_type(Entry, acquisition_type.value)
        beamline = AssonantComponentFactory.create_component_by_class_type(Beamline, self.beamline_name.value)

        for component in components:
            beamline.add_subcomponent(component)

        acq_type_entry.add_subcomponent(beamline)
        exp_stage_entry.add_subcomponent(acq_type_entry)

        return exp_stage_entry

    def log_collected_pv_data(
        self,
        log_file_path: str,
        log_file_name: str,
        experiment_stage: ExperimentStage,
        acquisition_type: AcquisitionType,
        pv_data: Dict[str, Any],
    ):
        """Standardize and log collected PV data represented as {PV_NAME: COLLECTED_VALUE} Dict.

        Args:
            log_file_path (str): Path where log file will be saved.
            log_file_name (str): Name of the log file that will be saved on log_file_path.
            acquisition_type (AcquisitionType): Current AcquisitionType which data was collected.
            pv_data (Dict[str, Any]): Collected PV data. The Dict structure must follow the same data structure
            and representation as the PVCollector acquire_data() method.
        """
        pv_names = [pv_name for pv_name in pv_data.keys()]
        pv_name_and_info_mapping = self.metadata_retriever.get_pvs_info(pv_names=pv_names)
        components = {}

        # Create DataHandlers for each acquired PV
        for pv_name, pv_info in pv_name_and_info_mapping.items():

            # Create DataHandler for PV field
            data_handler = self._create_data_handler_from_pv_info(pv_info)
            # Treat DataHandler value as it is always returned as a list
            data_handler_value = (
                pv_data[pv_name][0]
                if isinstance(pv_data[pv_name], list) and len(pv_data[pv_name]) == 1
                else pv_data[pv_name]
            )
            data_handler.set_value(data_handler_value)
            data_handler_name = pv_info["data_handler_info"]["name"]

            component_name = pv_info["component_info"]["name"]

            # Create Component if doesn't already exist
            if component_name not in components.keys():
                components[component_name] = self._create_component_from_pv_info(pv_info)

            components[component_name].add_data_handler(name=data_handler_name, new_data_handler=data_handler)

        hierarchized_components = self.hierarchizer.hierarchize_components(list(components.values()))

        exp_stage_entry = self._build_experiment_entry(hierarchized_components, experiment_stage, acquisition_type)

        self.file_writer.write_data(log_file_path, log_file_name, exp_stage_entry)

    def log_collected_component_data(
        self,
        log_file_path: str,
        log_file_name: str,
        experiment_stage: ExperimentStage,
        acquisition_type: AcquisitionType,
        components: Union[Component, List[Component]],
    ):
        """Standardize and log collected PV data already wrapped as Assonant Components.

        Args:
            log_file_path (str): Path where log file will be saved.
            log_file_name (str): Name of the log file that will be saved on log_file_path.
            acquisition_type (AcquisitionType): Current AcquisitionType which data was collected.
            components (Union[Component, List[Component]]): List of Assonant Component objects with data to be logged.
        """
        print(
            "WARNING: LOG_COLLECTED_COMPONENT_DATA METHOD IS DISCOURAGED DUE TO THE LACK OF AUTOMATION AND"
            + "LACK OF COMPONENTS HIERARCHY STANDARDIZATION. ONLY USE THIS IF YOU ARE REALLY SURE"
            + "IN WHAT YOU ARE DOING!!!"
        )
        if isinstance(components, Component):
            components = [components]

        exp_stage_entry = self._build_experiment_entry(components, experiment_stage, acquisition_type)

        self.file_writer.write_data(log_file_path, log_file_name, exp_stage_entry)

    def log_bluesky_data_from_json_file(
        self,
        log_file_path: str,
        log_file_name: str,
        experiment_stage: ExperimentStage,
        acquisition_type: AcquisitionType,
        json_file_path: str,
    ):
        """Log bluesky data on json files into a standardize way

        Args:
            log_file_path (str): Path where log file will be saved.
            log_file_name (str): Name of the log file that will be saved on log_file_path.
            experiment_stage (ExperimentStage): Enum related to the ExperimentStage in which the data was collected.
            acquisition_type (AcquisitionType): Enum related to the AcquisitionType that data was collected
            within the ExperimentStage.
            json_file_path (str): Path to the json file containing the bluesky data.
        """

        # TODO: POSSIBLE ENHANCEMENT: FUTURALLY, DEPENDING ON PERFORMANCE REQUIREMENTS, SOME KIND OF CONTROL
        # IF INSTANTIATES A NEW BLUESKY DATA PARSER OR REUSE AN ALREADY EXISTING ONE MAY BE GOOD. THIS
        # WAY IT AVOIDS PROCESSING MULTUIPLE TIMES THE SAME DOCUMMENTS TO FIND THE SAME DATA.
        assonant_data_retriever = AssonantDataRetriever(data_source=json_file_path)

        pv_data = assonant_data_retriever.get_pv_data_by_acquisition_type(acquisition_type)
        self.log_collected_pv_data(log_file_path, log_file_name, experiment_stage, acquisition_type, pv_data)

    def log_bluesky_data_from_documents_list(
        self,
        log_file_path: str,
        log_file_name: str,
        experiment_stage: ExperimentStage,
        acquisition_type: AcquisitionType,
        documents_list: List[List[Union[str, Dict[str, Any]]]],
    ):
        """Log bluesky data passed as a dict of bluesky documments (which are also represented as dicts)

        Args:
            log_file_path (str): Path where log file will be saved.
            log_file_name (str): Name of the log file that will be saved on log_file_path.
            experiment_stage (ExperimentStage): Enum related to the ExperimentStage in which the data was collected.
            acquisition_type (AcquisitionType): Enum related to the AcquisitionType that data was collected
            within the ExperimentStage.
            documents_list (List[List[Union[str, Dict[str, Any]]]]): List of bluesky documents data presented also as
            a list. The list with the document data has 2 positions, the 1st is the bluesky identification for the
            document (start, event, stop, descriptor, ...) and the 2nd position the dict containing the document
            data.
        """

        # TODO: POSSIBLE ENHANCEMENT: FUTURALLY, DEPENDING ON PERFORMANCE REQUIREMENTS, SOME KIND OF CONTROL
        # IF INSTANTIATES A NEW BLUESKY DATA PARSER OR REUSE AN ALREADY EXISTING ONE MAY BE GOOD. THIS
        # WAY IT AVOIDS PROCESSING MULTUIPLE TIMES THE SAME DOCUMMENTS TO FIND THE SAME DATA.
        assonant_data_retriever = AssonantDataRetriever(data_source=documents_list)

        pv_data = assonant_data_retriever.get_pv_data_by_acquisition_type(acquisition_type)

        self.log_collected_pv_data(log_file_path, log_file_name, experiment_stage, acquisition_type, pv_data)
