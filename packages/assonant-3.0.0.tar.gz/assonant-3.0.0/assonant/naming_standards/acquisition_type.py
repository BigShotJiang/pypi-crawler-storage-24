from enum import Enum


class AcquisitionType(Enum):
    """Possible Acquisition Types values."""

    SNAPSHOT_AT_START = "snapshot_at_start"
    SNAPSHOT_AT_END = "snapshot_at_end"
    SCAN = "scan"
