"""Assonant Entry data class."""

from .component import Component


class Entry(Component):
    """Data classes that wraps data into a logical/temporal scope related to the experiment.

    Entries are used to group and represent data in a defined temporal/logical scope of the
    experiment.
    """
