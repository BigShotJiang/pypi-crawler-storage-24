from types import SimpleNamespace

import pytest
import requests

from polarion.v3.errors import AuthError, TransportError
from polarion.v3.transport.soap import SoapTransport


class DummyService:
    def __init__(self, methods=None):
        self.calls = []
        for name, fn in (methods or {}).items():
            setattr(self, name, fn)

    def logIn(self, user, password):
        self.calls.append(("logIn", user, password))
        return True

    def logInWithToken(self, mechanism, user, token):
        self.calls.append(("logInWithToken", mechanism, user, token))
        return True

    def endSession(self):
        self.calls.append(("endSession",))
        return True

    def ping(self, **kwargs):
        self.calls.append(("ping", kwargs))
        return {"ok": True, "kwargs": kwargs}


def test_call_with_password_auth(monkeypatch):
    services = {}

    def fake_client(wsdl, transport, **kwargs):
        svc = DummyService()
        services[wsdl] = svc
        return SimpleNamespace(service=svc, set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)

    t = SoapTransport(url="https://polarion.example.com/polarion", username="u", password="p")
    out = t.call("Tracker", "ping", a=1)

    assert out["ok"] is True
    # SOAP session logIn is called with username/password
    session_wsdl = "https://polarion.example.com/polarion/ws/services/SessionWebService?wsdl"
    assert ("logIn", "u", "p") in services[session_wsdl].calls
    tracker_wsdl = "https://polarion.example.com/polarion/ws/services/TrackerWebService?wsdl"
    assert ("ping", {"a": 1}) in services[tracker_wsdl].calls


def test_call_with_token_auth(monkeypatch):
    services = {}

    def fake_client(wsdl, transport, **kwargs):
        svc = DummyService()
        services[wsdl] = svc
        return SimpleNamespace(service=svc, set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)

    t = SoapTransport(url="https://polarion.example.com/polarion", username="u", token="tok")
    t.call("Tracker", "ping")

    # SOAP session logInWithToken is called with AccessToken mechanism
    session_wsdl = "https://polarion.example.com/polarion/ws/services/SessionWebService?wsdl"
    assert ("logInWithToken", "AccessToken", "", "tok") in services[session_wsdl].calls


def test_method_not_found(monkeypatch):
    def fake_client(wsdl, transport, **kwargs):
        return SimpleNamespace(service=SimpleNamespace(), set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)

    t = SoapTransport(url="https://x/polarion", username="u")
    with pytest.raises(TransportError):
        t.call("Tracker", "nope")


def test_auth_failure_raises_auth_error(monkeypatch):
    """SOAP session auth raises AuthError when logIn fails."""

    class BadSessionService(DummyService):
        def logIn(self, user, password):
            raise requests.RequestException("bad creds")

    def fake_client(wsdl, transport, **kwargs):
        if wsdl.endswith("/SessionWebService?wsdl"):
            return SimpleNamespace(service=BadSessionService())
        return SimpleNamespace(service=DummyService(), set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)

    t = SoapTransport(url="https://x/polarion", username="u", password="bad")
    with pytest.raises(AuthError):
        t.call("Tracker", "ping")


def test_call_retries_on_connection_error(monkeypatch):
    class FlakyService(DummyService):
        def __init__(self):
            super().__init__()
            self.count = 0

        def ping(self, **kwargs):
            self.count += 1
            if self.count < 3:
                raise requests.ConnectionError("temporary")
            return {"ok": True}

    services = {}

    def fake_client(wsdl, transport, **kwargs):
        svc = FlakyService() if wsdl.endswith("/TrackerWebService?wsdl") else DummyService()
        services[wsdl] = svc
        return SimpleNamespace(service=svc, set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)
    monkeypatch.setattr("polarion.v3.transport.soap.time.sleep", lambda *_: None)

    t = SoapTransport(url="https://x/polarion", username="u")
    out = t.call("Tracker", "ping")
    assert out["ok"] is True


def test_call_fails_after_retries(monkeypatch):
    class AlwaysFailService(DummyService):
        def ping(self, **kwargs):
            raise requests.Timeout("timeout")

    def fake_client(wsdl, transport, **kwargs):
        svc = AlwaysFailService() if wsdl.endswith("/TrackerWebService?wsdl") else DummyService()
        return SimpleNamespace(service=svc, set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)
    monkeypatch.setattr("polarion.v3.transport.soap.time.sleep", lambda *_: None)

    t = SoapTransport(url="https://x/polarion", username="u", max_retries=1)
    with pytest.raises(TransportError):
        t.call("Tracker", "ping")


def test_call_with_fallback_uses_second_method(monkeypatch):
    class FallbackService(DummyService):
        def methodA(self, **kwargs):
            raise requests.ConnectionError("nope")

        def methodB(self, **kwargs):
            return {"ok": True}

    def fake_client(wsdl, transport, **kwargs):
        svc = FallbackService() if wsdl.endswith("/TrackerWebService?wsdl") else DummyService()
        return SimpleNamespace(service=svc, set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)
    monkeypatch.setattr("polarion.v3.transport.soap.time.sleep", lambda *_: None)

    t = SoapTransport(url="https://x/polarion", username="u")
    out = t.call_with_fallback("Tracker", ["methodA", "methodB"])
    assert out["ok"] is True


def test_supports_method(monkeypatch):
    def fake_client(wsdl, transport, **kwargs):
        return SimpleNamespace(service=DummyService(), set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)

    t = SoapTransport(url="https://x/polarion", username="u")
    assert t.supports_method("Tracker", "ping") is True
    assert t.supports_method("Tracker", "missing") is False


def test_call_serializes_zeep_compound_values(monkeypatch):
    """Verify that zeep CompoundValue objects are serialized to dicts."""
    from collections import OrderedDict

    from zeep.xsd.valueobjects import CompoundValue

    # Build a minimal CompoundValue that mimics a real zeep SOAP response
    class FakeType:
        _xsd_name = "FakeWorkItem"

        class elements_nested:
            pass

        @staticmethod
        def _element_fields():
            return []

    fake_wi = CompoundValue.__new__(CompoundValue)
    object.__setattr__(fake_wi, "_xsd_type", FakeType)
    # CompoundValue stores data in __values__
    object.__setattr__(
        fake_wi,
        "__values__",
        OrderedDict(
            [
                ("id", "WI-1"),
                ("title", "Test"),
                ("status", OrderedDict([("id", "open")])),
            ]
        ),
    )

    class ZeepService(DummyService):
        def getWorkItemById(self, **kwargs):
            return fake_wi

    def fake_client(wsdl, transport, **kwargs):
        svc = ZeepService() if wsdl.endswith("/TrackerWebService?wsdl") else DummyService()
        return SimpleNamespace(service=svc, set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)

    t = SoapTransport(url="https://x/polarion", username="u")
    result = t.call("Tracker", "getWorkItemById", projectId="P", id="WI-1")

    # Result must be a dict (OrderedDict), not a CompoundValue
    assert isinstance(result, dict)
    assert result["id"] == "WI-1"
    assert result["title"] == "Test"


def test_call_serializes_primitive_passthrough(monkeypatch):
    """Primitives (str, int, bool, None) pass through serialize_object unchanged."""

    class PrimService(DummyService):
        def hasSubject(self, **kwargs):
            return True

    def fake_client(wsdl, transport, **kwargs):
        svc = PrimService() if wsdl.endswith("/SessionWebService?wsdl") else DummyService()
        return SimpleNamespace(service=svc, set_default_soapheaders=lambda _: None)

    monkeypatch.setattr("polarion.v3.transport.soap.Client", fake_client)

    t = SoapTransport(url="https://x/polarion", username="u")
    result = t.call("Session", "hasSubject")
    assert result is True
