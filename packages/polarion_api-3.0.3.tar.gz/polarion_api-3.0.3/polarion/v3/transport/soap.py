"""SOAP transport implementation for v3."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

import requests
from lxml import etree
from zeep import Client
from zeep.exceptions import Error as ZeepError
from zeep.exceptions import Fault as ZeepFault
from zeep.helpers import serialize_object
from zeep.plugins import HistoryPlugin
from zeep.transports import Transport

from ..errors import AuthError, TransportError

_SESSION_ID_NS = "http://ws.polarion.com/session"


@dataclass
class SoapTransport:
    url: str
    username: str
    password: str | None = None
    token: str | None = None
    verify_ssl: bool = True
    timeout: float = 30.0
    _clients: dict[str, Client] = field(default_factory=dict, init=False)
    _session: requests.Session = field(init=False)
    _authenticated: bool = field(default=False, init=False)
    max_retries: int = 2
    retry_backoff_seconds: float = 0.2

    def __post_init__(self) -> None:
        self._session = requests.Session()
        self._session.verify = self.verify_ssl
        self._session_header: etree._Element | None = None

    def _service_wsdl(self, service: str) -> str:
        base = self.url.rstrip("/")
        # Polarion SOAP endpoint convention
        # Some Polarion versions (e.g., 2410) require "WebService" suffix
        service_name = service if service.endswith("WebService") else f"{service}WebService"
        return f"{base}/ws/services/{service_name}?wsdl"

    def _client(self, service: str) -> Client:
        existing = self._clients.get(service)
        if existing is not None:
            return existing

        transport = Transport(session=self._session, timeout=self.timeout)
        try:
            client = Client(wsdl=self._service_wsdl(service), transport=transport)
        except (ZeepError, requests.RequestException, OSError) as e:
            raise TransportError(f"Failed to initialize SOAP client for {service}: {e}") from e

        # Apply session header from SOAP login to all non-Session service clients
        if self._session_header is not None and service != "Session":
            client.set_default_soapheaders([self._session_header])

        self._clients[service] = client
        return client

    def _authenticate(self) -> None:
        if self._authenticated:
            return

        if not self.password and not self.token:
            # Allow anonymous calls for environments configured that way.
            self._authenticated = True
            return

        history = HistoryPlugin()
        transport = Transport(session=self._session, timeout=self.timeout)
        try:
            session_client = Client(wsdl=self._service_wsdl("Session"), transport=transport, plugins=[history])
        except (ZeepError, requests.RequestException, OSError) as e:
            raise TransportError(f"Failed to initialize Session SOAP client: {e}") from e

        self._clients["Session"] = session_client

        try:
            if self.token:
                session_client.service.logInWithToken("AccessToken", "", self.token)
            else:
                session_client.service.logIn(self.username, self.password)
        except (ZeepFault, ZeepError, requests.RequestException, OSError) as e:
            raise AuthError(f"Failed to authenticate SOAP session for user {self.username}: {e}") from e

        # Extract session ID from SOAP response header and store for other services
        try:
            envelope = history.last_received["envelope"].getroottree()
            self._session_header = envelope.find(f".//{{{_SESSION_ID_NS}}}sessionID")
        except Exception:
            # Some Polarion versions may not return a session header;
            # cookies alone may suffice.
            pass

        self._authenticated = True

    def _map_parameters(self, service: str, method: str, kwargs: dict[str, Any]) -> dict[str, Any]:
        """Map parameter names for Polarion 2410 compatibility.

        Polarion 2410 introduced breaking API changes:
        - Parameter names vary by service (inconsistent naming)
        - Some methods removed projectId parameter entirely (rely on query scoping)
        - Some methods require new parameters (e.g., resultsLimit)
        """
        # Make a copy to avoid mutating the original
        mapped = kwargs.copy()

        # Method-specific mappings for Polarion 2410
        # searchTestRuns no longer accepts projectId - query must include project scope
        if service == "TestManagement" and method == "searchTestRuns":
            mapped.pop("projectId", None)
            mapped.pop("projectID", None)

        # searchPlans no longer accepts projectId and requires resultsLimit
        if service == "Planning" and method == "searchPlans":
            mapped.pop("projectId", None)
            mapped.pop("projectID", None)
            # Add resultsLimit if not present (required parameter in 2410)
            if "resultsLimit" not in mapped:
                mapped["resultsLimit"] = 1000  # Default high limit

        # Service-specific parameter name mappings
        # ProjectWebService uses projectID (capital D)
        if service == "Project":
            param_map = {"projectId": "projectID"}
            result = {}
            for key, value in mapped.items():
                mapped_key = param_map.get(key, key)
                result[mapped_key] = value
            return result

        # TrackerWebService and TestManagementWebService use projectId (lowercase d) - no mapping needed
        # Just return as-is
        return mapped

    def call(self, service: str, method: str, **kwargs: Any) -> Any:
        self._authenticate()
        client = self._client(service)
        fn = getattr(client.service, method, None)
        if fn is None:
            raise TransportError(f"SOAP method not found: {service}.{method}")

        kwargs.pop("_timeout", None)  # reserved for future per-call transport override

        # Map parameters for Polarion 2410 compatibility
        mapped_kwargs = self._map_parameters(service, method, kwargs)

        attempts = self.max_retries + 1
        for attempt in range(1, attempts + 1):
            try:
                result = fn(**mapped_kwargs)
                return serialize_object(result)
            except ZeepFault as e:
                # SOAP-level faults are not transient; fail fast.
                raise TransportError(f"SOAP call failed: {service}.{method}: {e}") from e
            except (requests.Timeout, requests.ConnectionError, OSError) as e:
                if attempt >= attempts:
                    raise TransportError(f"SOAP call failed after retries: {service}.{method}: {e}") from e
                time.sleep(self.retry_backoff_seconds * attempt)
            except ZeepError as e:
                # Some Zeep transport/parsing errors are transient-ish in practice.
                if attempt >= attempts:
                    raise TransportError(f"SOAP call failed after retries: {service}.{method}: {e}") from e
                time.sleep(self.retry_backoff_seconds * attempt)

        raise TransportError(f"SOAP call failed: {service}.{method}")

    def call_with_fallback(self, service: str, methods: list[str], **kwargs: Any) -> Any:
        """Try multiple SOAP methods in order and return first successful response."""
        errors: list[str] = []
        for method in methods:
            try:
                return self.call(service, method, **kwargs)
            except TransportError as e:
                errors.append(f"{method}: {e}")

        raise TransportError(f"SOAP call failed for all fallback methods on {service}: " + "; ".join(errors))

    def supports_method(self, service: str, method: str) -> bool:
        """Check whether a SOAP method exists on a service without calling it."""
        client = self._client(service)
        return getattr(client.service, method, None) is not None

    def close(self) -> None:
        try:
            if self._authenticated:
                session_client = self._client("Session")
                end_session = getattr(session_client.service, "endSession", None)
                if end_session is not None:
                    end_session()
        except Exception:
            # Best-effort cleanup only.
            pass
        finally:
            self._session.close()
