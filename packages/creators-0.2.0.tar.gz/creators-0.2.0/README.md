# Amazon Creators API

This is a small wrapper around the official Amazon Creators API Python SDK. It provides a lightweight package entry point while directly exposing the SDK's models and exceptions.

## Install

### pip

```bash
pip install creators
```

### uv

```bash
uv add creators
```

## Usage

```python
from creators import Client, SearchItemsResource, GetItemsResource, ApiException

client = Client(
    credential_id="YOUR_CREDENTIAL_ID",
    credential_secret="YOUR_CREDENTIAL_SECRET",
    version="3.1",
    marketplace="www.amazon.com",
    partner_tag="yourtag-20",
)

try:
    response = client.search_items(
        keywords="wireless earbuds",
        item_count=5,
        resources=[SearchItemsResource.ITEM_INFO_DOT_TITLE],
    )
    print(response.search_result.items)
except ApiException as exc:
    print(f"api error: {exc}")

try:
    response = client.get_items(
        item_ids=["B000123456", "B000987654"],
        resources=[GetItemsResource.ITEM_INFO_DOT_TITLE],
    )
    print(response.items_result.items)
except ApiException as exc:
    print(f"api error: {exc}")
```

## Notes

- Models are re-exported from the official SDK.
- Exceptions are re-exported from the official SDK.
- More examples are available in `examples/`.
- To run tests or the examples, install dev dependencies first with `uv sync --group dev`, then run `pytest` or the scripts in `examples/`.

## References

- [Creators API Docs](https://affiliate-program.amazon.com/creatorsapi/docs/en-us/introduction)
- [Available SDKs](https://affiliate-program.amazon.com/creatorsapi/docs/en-us/get-started/using-sdk)
- License: MIT (see `LICENSE`).
