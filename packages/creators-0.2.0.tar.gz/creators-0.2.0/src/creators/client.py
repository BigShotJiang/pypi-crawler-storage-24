from creatorsapi_python_sdk.api.default_api import DefaultApi
from creatorsapi_python_sdk.api_client import ApiClient

from .models import *


class Client:

    def __init__(
            self,
            credential_id: str,
            credential_secret: str,
            version: str,
            marketplace: str,
            partner_tag: str,
    ):
        self.api = DefaultApi(ApiClient(
            credential_id=credential_id,
            credential_secret=credential_secret,
            version=version,
        ))
        self.marketplace = marketplace
        self.partner_tag = partner_tag

    def search_items(self, **kwargs) -> SearchItemsResponseContent:
        if 'partner_tag' not in kwargs:
            kwargs['partner_tag'] = self.partner_tag

        if 'item_count' not in kwargs:
            kwargs['item_count'] = 10

        if 'resources' not in kwargs:
            kwargs['resources'] = list(SearchItemsResource)

        request = SearchItemsRequestContent(**kwargs)
        return self.api.search_items(
            x_marketplace=self.marketplace,
            search_items_request_content=request,
        )

    def get_items(self, item_ids: list[str], **kwargs) -> GetItemsResponseContent:
        if 'partner_tag' not in kwargs:
            kwargs['partner_tag'] = self.partner_tag

        if 'resources' not in kwargs:
            kwargs['resources'] = list(GetItemsResource)

        request = GetItemsRequestContent(item_ids=item_ids, **kwargs)
        return self.api.get_items(
            x_marketplace=self.marketplace,
            get_items_request_content=request,
        )

    def get_browse_nodes(self, browse_node_ids: list[str], **kwargs) -> GetBrowseNodesResponseContent:
        if 'partner_tag' not in kwargs:
            kwargs['partner_tag'] = self.partner_tag

        if 'resources' not in kwargs:
            kwargs['resources'] = list(GetBrowseNodesResource)

        request = GetBrowseNodesRequestContent(browse_node_ids=browse_node_ids, **kwargs)
        return self.api.get_browse_nodes(
            x_marketplace=self.marketplace,
            get_browse_nodes_request_content=request,
        )

    def get_variations(self, asin: str, **kwargs) -> GetVariationsResponseContent:
        if 'partner_tag' not in kwargs:
            kwargs['partner_tag'] = self.partner_tag

        if 'resources' not in kwargs:
            kwargs['resources'] = list(GetVariationsResource)

        request = GetVariationsRequestContent(asin=asin, **kwargs)
        return self.api.get_variations(
            x_marketplace=self.marketplace,
            get_variations_request_content=request,
        )

    def get_feed(self, feed_name: str, **kwargs) -> GetFeedResponseContent:
        request = GetFeedRequestContent(feed_name=feed_name, **kwargs)
        return self.api.get_feed(
            x_marketplace=self.marketplace,
            get_feed_request_content=request,
        )

    def get_report(self, filename: str, **kwargs) -> GetReportResponseContent:
        request = GetReportRequestContent(filename=filename, **kwargs)
        return self.api.get_report(
            x_marketplace=self.marketplace,
            get_report_request_content=request,
        )

    def list_feeds(self, **kwargs) -> ListFeedsResponseContent:
        return self.api.list_feeds(
            x_marketplace=self.marketplace,
            **kwargs,
        )

    def list_reports(self, **kwargs) -> ListReportsResponseContent:
        return self.api.list_reports(
            x_marketplace=self.marketplace,
            **kwargs,
        )
