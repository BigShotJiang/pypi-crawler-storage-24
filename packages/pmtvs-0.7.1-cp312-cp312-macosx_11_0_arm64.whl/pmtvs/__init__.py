"""pmtvs — all signal analysis primitives in one import."""

__version__ = "0.7.1"

# Re-export everything from sub-packages
from pmtvs_entropy import *
from pmtvs_fractal import *
from pmtvs_statistics import *
from pmtvs_correlation import *
from pmtvs_distance import *
from pmtvs_embedding import *
from pmtvs_coupling import *
# private module, not exported
from pmtvs_dynamics import *
from pmtvs_spectral import *
from pmtvs_matrix import *
from pmtvs_topology import *
from pmtvs_network import *
from pmtvs_information import *
from pmtvs_tests import *
from pmtvs_regression import *
# pmtvs_triangle — private, not exported
from pmtvs_physics import *
# pmtvs_control — private, not exported

# BACKEND: "rust" if any Rust-accelerated sub-package loaded successfully.
# Star-imports above overwrite BACKEND with the last package's value
# (pmtvs_triangle is pure Python → "python"). Set explicitly.
BACKEND = "rust"

# Star-imports overwrite __version__ with sub-package values. Set explicitly.
__version__ = "0.7.1"

# --- Core computation primitives ---
from pmtvs.frequency.psd import (
    power_spectral_density as core_psd,
    dominant_frequency as core_dominant_frequency,
    spectral_features,
)
from pmtvs.statistics.moments import statistical_moments
from pmtvs.statistics.histogram import histogram_analysis
from pmtvs.temporal.trend import trend_analysis
from pmtvs.temporal.envelope import (
    hilbert_envelope,
    instantaneous_phase as core_instantaneous_phase,
    instantaneous_frequency as core_instantaneous_frequency,
)
from pmtvs.frequency.wavelet import wavelet_decomposition

# --- Aliases for backward compatibility ---
# Distance
from pmtvs_distance import dtw_distance as dynamic_time_warping
# Embedding
from pmtvs_embedding import delay_embedding as time_delay_embedding
from pmtvs_embedding import mutual_information_delay as optimal_delay
from pmtvs_embedding import optimal_embedding_dimension as optimal_dimension
from pmtvs_embedding import optimal_embedding_dimension as embedding_dimension
# Dynamics
from pmtvs_dynamics import estimate_embedding_dim_cao as cao_embedding_analysis
from pmtvs_dynamics import entropy_recurrence as entropy_rqa
# Spectral
from pmtvs_spectral import power_spectral_density as psd
# Network
from pmtvs_network import density as network_density
from pmtvs_network import betweenness_centrality as centrality_betweenness
from pmtvs_network import eigenvector_centrality as centrality_eigenvector
# Topology
from pmtvs_topology import persistent_homology_0d as persistence_diagram
