"""Discrete wavelet decomposition."""

import numpy as np


def wavelet_decomposition(
    y: np.ndarray,
    wavelet: str = 'db4',
    levels: int = 4,
) -> dict:
    """
    Discrete wavelet decomposition with energy and entropy per level.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).
    wavelet : str
        Wavelet name (passed to ``pywt.wavedec``).
    levels : int
        Number of decomposition levels.

    Returns
    -------
    dict
        Per-level keys ``level_0`` .. ``level_N`` each containing
        ``coeffs``, ``energy``, ``energy_fraction``, ``entropy``,
        ``n_coeffs``. Top-level keys ``n_levels`` and ``wavelet``.
    """
    y = np.asarray(y, dtype=np.float64).flatten()
    y = y[~np.isnan(y)]

    if len(y) < 4:
        return {'n_levels': 0, 'wavelet': wavelet}

    try:
        import pywt

        coeffs = pywt.wavedec(y, wavelet, level=levels)

        result = {}
        # 1e-10 prevents divide-by-zero for near-silent signals
        total_energy = sum(np.sum(c ** 2) for c in coeffs) + 1e-10

        for i, c in enumerate(coeffs):
            energy = float(np.sum(c ** 2))
            # 1e-10 prevents divide-by-zero for zero-energy levels
            probs = c ** 2 / (np.sum(c ** 2) + 1e-10)
            # 1e-30 prevents log(0) for zero-coefficient bins
            entropy = float(-np.sum(probs * np.log(probs + 1e-30)))

            result[f'level_{i}'] = {
                'coeffs': c,
                'energy': energy,
                'energy_fraction': energy / total_energy,
                'entropy': entropy,
                'n_coeffs': len(c),
            }

        result['n_levels'] = len(coeffs)
        result['wavelet'] = wavelet
        return result

    except ImportError:
        return _wavelet_fft_fallback(y, levels)


def _wavelet_fft_fallback(y: np.ndarray, levels: int = 4) -> dict:
    """
    FFT-based wavelet approximation when pywavelets is not installed.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).
    levels : int
        Number of decomposition levels.

    Returns
    -------
    dict
        Same structure as ``wavelet_decomposition``.
    """
    n = len(y)
    fft_y = np.fft.rfft(y)
    result = {}
    total_energy = 0.0

    level_data = []
    for i in range(levels):
        lo = max(1, n // (2 ** (i + 1)))
        hi = n // (2 ** i)
        if lo >= len(fft_y):
            break

        band = np.zeros_like(fft_y)
        band[lo:min(hi, len(fft_y))] = fft_y[lo:min(hi, len(fft_y))]

        coeffs = np.fft.irfft(band, n=n)
        energy = float(np.sum(coeffs ** 2))
        total_energy += energy
        level_data.append((coeffs, energy))

    # 1e-10 prevents divide-by-zero for near-silent signals
    total_energy = max(total_energy, 1e-10)
    for i, (coeffs, energy) in enumerate(level_data):
        # 1e-10 prevents divide-by-zero for zero-energy bands
        probs = coeffs ** 2 / (np.sum(coeffs ** 2) + 1e-10)
        # 1e-30 prevents log(0) for zero-coefficient bins
        entropy = float(-np.sum(probs * np.log(probs + 1e-30)))
        result[f'level_{i}'] = {
            'coeffs': coeffs,
            'energy': energy,
            'energy_fraction': energy / total_energy,
            'entropy': entropy,
            'n_coeffs': len(coeffs),
        }

    result['n_levels'] = len(level_data)
    result['wavelet'] = 'fft_approx'
    return result
