"""Power spectral density and spectral feature extraction."""

import numpy as np


def power_spectral_density(
    y: np.ndarray,
    dt: float = 1.0,
    window: str = 'hann',
) -> tuple[np.ndarray, np.ndarray]:
    """
    Power spectral density via FFT.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).
    dt : float
        Sampling interval in seconds.
    window : str
        Window function name (passed to ``scipy.signal.get_window``).

    Returns
    -------
    freqs : np.ndarray
        Frequency array in Hz.
    psd : np.ndarray
        Power spectral density.
    """
    from numpy.fft import rfft, rfftfreq
    from scipy.signal import get_window

    y = np.asarray(y, dtype=np.float64).flatten()
    y = y[~np.isnan(y)]
    n = len(y)
    if n < 4:
        return np.array([0.0]), np.array([0.0])

    w = get_window(window, n)
    y_windowed = y * w

    fft_vals = rfft(y_windowed)
    freqs = rfftfreq(n, d=dt)

    psd = (np.abs(fft_vals) ** 2) / (np.sum(w ** 2) * dt)

    return freqs, psd


def dominant_frequency(
    y: np.ndarray,
    dt: float = 1.0,
) -> float:
    """
    Dominant frequency in Hz.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).
    dt : float
        Sampling interval in seconds.

    Returns
    -------
    float
        Frequency of the peak PSD bin (excluding DC).
    """
    freqs, psd = power_spectral_density(y, dt)
    if len(freqs) < 2:
        return 0.0
    idx = np.argmax(psd[1:]) + 1
    return float(freqs[idx])


def spectral_features(
    y: np.ndarray,
    dt: float = 1.0,
) -> dict:
    """
    All spectral features in one call.

    Replaces frequency_bands, fundamental_freq, harmonics, thd engines.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).
    dt : float
        Sampling interval in seconds.

    Returns
    -------
    dict
        Keys: ``dominant_freq``, ``spectral_centroid``, ``spectral_bandwidth``,
        ``spectral_entropy``, ``spectral_flatness``, ``thd_ratio``.
    """
    freqs, psd = power_spectral_density(y, dt)

    total_power = np.sum(psd)
    if total_power == 0:
        return {
            'dominant_freq': 0.0, 'spectral_centroid': np.nan,
            'spectral_bandwidth': np.nan, 'spectral_entropy': np.nan,
            'spectral_flatness': np.nan, 'thd_ratio': np.nan,
        }

    # Centroid
    centroid = float(np.sum(freqs * psd) / total_power)

    # Bandwidth
    bandwidth = float(np.sqrt(
        np.sum(((freqs - centroid) ** 2) * psd) / total_power))

    # Spectral entropy (1e-30 guards log(0) for zero-power bins)
    psd_norm = psd / total_power
    entropy = float(-np.sum(psd_norm * np.log(psd_norm + 1e-30)))

    # Spectral flatness (geometric / arithmetic mean)
    # 1e-30 guards log(0) for zero-power bins
    log_mean = np.exp(np.mean(np.log(psd + 1e-30)))
    arith_mean = np.mean(psd)
    flatness = float(log_mean / arith_mean) if arith_mean > 0 else np.nan

    # THD (total harmonic distortion)
    dom_idx = np.argmax(psd[1:]) + 1
    dom_power = psd[dom_idx]
    harmonic_power = 0.0
    for h in range(2, 6):
        harm_idx = dom_idx * h
        if harm_idx < len(psd):
            harmonic_power += psd[harm_idx]
    thd = float(np.sqrt(harmonic_power) / np.sqrt(dom_power)) if dom_power > 0 else np.nan

    return {
        'dominant_freq': float(freqs[dom_idx]) if dom_idx < len(freqs) else 0.0,
        'spectral_centroid': centroid,
        'spectral_bandwidth': bandwidth,
        'spectral_entropy': entropy,
        'spectral_flatness': flatness,
        'thd_ratio': thd,
    }
