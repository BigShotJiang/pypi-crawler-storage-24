"""Trend analysis via linear regression."""

import numpy as np


def trend_analysis(y: np.ndarray, dt: float = 1.0) -> dict:
    """
    Trend analysis via linear regression.

    Replaces 2 polyfit call sites in trend and phase_coherence engines.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).
    dt : float
        Sampling interval.

    Returns
    -------
    dict
        Keys: ``slope``, ``intercept``, ``r_squared``, ``cusum_range``,
        ``trend_direction``.
    """
    y = np.asarray(y, dtype=np.float64).flatten()
    y = y[~np.isnan(y)]
    n = len(y)

    if n < 3:
        return {
            'slope': np.nan,
            'intercept': np.nan,
            'r_squared': np.nan,
            'cusum_range': np.nan,
            'trend_direction': 0,
        }

    x = np.arange(n, dtype=np.float64) * dt

    x_mean = np.mean(x)
    y_mean = np.mean(y)

    ss_xy = np.sum((x - x_mean) * (y - y_mean))
    ss_xx = np.sum((x - x_mean) ** 2)

    if ss_xx == 0:
        return {
            'slope': np.nan, 'intercept': np.nan, 'r_squared': np.nan,
            'cusum_range': np.nan, 'trend_direction': 0,
        }

    slope = float(ss_xy / ss_xx)
    intercept = float(y_mean - slope * x_mean)

    # R-squared
    y_pred = slope * x + intercept
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - y_mean) ** 2)
    r_sq = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else np.nan

    # CUSUM range
    cusum = np.cumsum(y - y_mean)
    cusum_range = float(np.max(cusum) - np.min(cusum))

    return {
        'slope': slope,
        'intercept': intercept,
        'r_squared': r_sq,
        'cusum_range': cusum_range,
        'trend_direction': int(np.sign(slope)),
    }
