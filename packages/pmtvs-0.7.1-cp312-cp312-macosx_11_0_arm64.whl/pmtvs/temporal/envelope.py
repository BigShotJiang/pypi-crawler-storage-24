"""Hilbert envelope, instantaneous phase, and instantaneous frequency."""

import numpy as np


def hilbert_envelope(y: np.ndarray) -> np.ndarray:
    """
    Analytic signal envelope via Hilbert transform.

    Replaces 2 scipy.signal.hilbert calls in envelope and phase_coherence.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).

    Returns
    -------
    np.ndarray
        Amplitude envelope (non-negative).
    """
    from scipy.signal import hilbert

    y = np.asarray(y, dtype=np.float64).flatten()
    y = y[~np.isnan(y)]

    if len(y) < 4:
        return np.abs(y)

    analytic = hilbert(y)
    return np.abs(analytic)


def instantaneous_phase(y: np.ndarray) -> np.ndarray:
    """
    Instantaneous phase via Hilbert transform, unwrapped for continuity.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).

    Returns
    -------
    np.ndarray
        Unwrapped phase in radians.
    """
    from scipy.signal import hilbert

    y = np.asarray(y, dtype=np.float64).flatten()
    y = y[~np.isnan(y)]

    if len(y) < 4:
        return np.zeros_like(y)

    analytic = hilbert(y)
    phase = np.angle(analytic)
    return np.unwrap(phase)


def instantaneous_frequency(
    y: np.ndarray,
    dt: float = 1.0,
) -> np.ndarray:
    """
    Instantaneous frequency from phase derivative.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).
    dt : float
        Sampling interval in seconds.

    Returns
    -------
    np.ndarray
        Instantaneous frequency in Hz (same length as input).
    """
    phase = instantaneous_phase(y)
    if len(phase) < 2:
        return np.zeros_like(phase)
    freq = np.diff(phase) / (2.0 * np.pi * dt)
    return np.concatenate([[freq[0]], freq])
