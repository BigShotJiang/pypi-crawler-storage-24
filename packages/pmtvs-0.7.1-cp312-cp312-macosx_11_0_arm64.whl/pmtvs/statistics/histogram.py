"""Histogram analysis and derived features."""

import numpy as np


def histogram_analysis(y: np.ndarray, bins: int = 10) -> dict:
    """
    Histogram with derived features.

    Replaces level_count and level_histogram engines.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).
    bins : int
        Number of histogram bins.

    Returns
    -------
    dict
        Keys: ``counts``, ``probs``, ``bin_edges``, ``entropy``,
        ``peak_bin``, ``uniformity``, ``concentration``.
    """
    y = np.asarray(y, dtype=np.float64).flatten()
    y = y[~np.isnan(y)]

    if len(y) < 2:
        return {
            'counts': np.array([0]),
            'probs': np.array([0.0]),
            'bin_edges': np.array([0.0, 0.0]),
            'entropy': np.nan,
            'peak_bin': 0,
            'uniformity': np.nan,
            'concentration': np.nan,
        }

    if len(y) < bins:
        bins = max(2, len(y) // 2)

    counts, edges = np.histogram(y, bins=bins)
    total = counts.sum()
    probs = counts / total

    # Shannon entropy (1e-30 guards log(0) for empty bins)
    entropy = float(-np.sum(probs * np.log(probs + 1e-30)))

    # Peak bin
    peak_bin = int(np.argmax(counts))

    # Uniformity (1 = uniform distribution)
    max_entropy = np.log(bins)
    uniformity = float(entropy / max_entropy)

    # Concentration (maximum probability mass)
    concentration = float(np.max(probs))

    return {
        'counts': counts,
        'probs': probs,
        'bin_edges': edges,
        'entropy': entropy,
        'peak_bin': peak_bin,
        'uniformity': uniformity,
        'concentration': concentration,
    }
