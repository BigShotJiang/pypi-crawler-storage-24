"""Statistical moments in a single pass."""

import numpy as np


def statistical_moments(y: np.ndarray) -> dict:
    """
    All statistical moments in one pass.

    Replaces 3 manual implementations across envelope, level_histogram,
    and statistics engines.

    Parameters
    ----------
    y : np.ndarray
        Signal array (1-D).

    Returns
    -------
    dict
        Keys: ``mean``, ``std``, ``variance``, ``skewness``, ``kurtosis``,
        ``crest_factor``, ``rms``.

    Notes
    -----
    ``crest_factor`` uses the sample peak (``max(abs(y))``), not an
    interpolated peak.  For sinusoidal signals the error relative to
    the analytical value is O(1/N^2), dominated by discrete RMS
    approximation of the continuous integral.  At N=100000 this is
    ~7e-6.  Constant signal returns NaN (RMS = 0, crest undefined).
    Matches Rust ``batch_compute`` to machine epsilon.
    """
    y = np.asarray(y, dtype=np.float64).flatten()
    y = y[~np.isnan(y)]

    if len(y) < 2:
        return {
            'mean': np.nan,
            'std': np.nan,
            'variance': np.nan,
            'skewness': np.nan,
            'kurtosis': np.nan,
            'crest_factor': np.nan,
            'rms': np.nan,
        }

    mean = np.mean(y)

    # Centered moments (single pass over diff)
    diff = y - mean
    diff2 = diff ** 2
    variance = np.mean(diff2)
    std = np.sqrt(variance) if variance > 0 else 0.0

    if std > 0:
        skewness = np.mean(diff * diff2) / (std ** 3)
        kurtosis = np.mean(diff2 ** 2) / (std ** 4)
    else:
        skewness = np.nan
        kurtosis = np.nan

    rms = np.sqrt(np.mean(y ** 2))
    peak = np.max(np.abs(y))
    crest = peak / rms if rms > 0 else np.nan

    return {
        'mean': float(mean),
        'std': float(std),
        'variance': float(variance),
        'skewness': float(skewness),
        'kurtosis': float(kurtosis),
        'crest_factor': float(crest),
        'rms': float(rms),
    }
