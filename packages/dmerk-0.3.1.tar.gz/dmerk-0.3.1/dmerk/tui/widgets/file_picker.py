import logging
from pathlib import Path
from typing import cast

from textual.app import ComposeResult
from textual.events import Resize
from textual.reactive import reactive
from textual.widget import Widget

import dmerk.constants as constants
from dmerk.tui.mixins.filter import FilterMixin
from dmerk.tui.widgets import CompareWidget, DataTable
from dmerk.utils import prefix_symbol_path


class FilePicker(FilterMixin, Widget):

    def __init__(
        self,
        path: Path | None = None,
        *,
        filter_by: str | None = None,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
        disabled: bool = False,
    ):
        super().__init__(name=name, id=id, classes=classes, disabled=disabled)
        if not path:
            path = Path(constants.APP_STATE_PATH)
        if path.is_dir():
            self.path = path
        else:
            raise ValueError(f"path {path} must be a directory")
        if filter_by:
            self.filter_by = filter_by

    path = reactive(Path.home())

    def compose(self) -> ComposeResult:
        files_table: DataTable[None] = DataTable(header_height=3)
        yield files_table

    def on_mount(self) -> None:
        self.query_one(DataTable).enable_tooltips()

    async def _refresh(self) -> None:
        files_table = self.query_one(DataTable)
        files_table.clear(columns=True)
        files_table.add_column("\nName", key="NAME")
        files_table.add_row(*["\n.."], key="..", height=3)
        files_list = [p for p in self.path.iterdir() if p.exists()]
        files_list = list(self.filter(files_list, key=lambda p: p.name))
        files_list = sorted(files_list, key=lambda p: str.casefold(p.name))
        for file in files_list:
            files_table.add_row(
                *["\n" + prefix_symbol_path(file) + file.name],
                key=str(file),
                height=3,
            )

    async def on_resize(self, event: Resize) -> None:
        await self._refresh()

    async def watch_path(self) -> None:
        await self._refresh()

    def _mount_compare_widget(self, path: Path) -> None:
        id_ = self.id.split("-")[-1] if self.id else ""
        id_ = "-".join(["compare", id_])
        cast(Widget, self.parent).mount(
            CompareWidget(path, id=id_, filter_by=self.filter_by), after=self
        )
        self.remove()

    def on_data_table_cell_selected(self, message: DataTable.CellSelected) -> None:
        if message.cell_key.row_key.value is not None:
            new_path: Path = self.path / message.cell_key.row_key.value
            new_path = new_path.resolve()
            if new_path.is_file():
                if isinstance(self.parent, Widget):
                    self._mount_compare_widget(new_path)
                else:
                    raise ValueError(f"{self.parent=} is not a Widget!!!")
            elif new_path.is_dir():
                self.path = new_path

    def path_selected(self, path: Path) -> None:
        self.path = path

    @property
    def highlighted_path(self) -> Path | None:
        files_table = self.query_one(DataTable)
        cell_key = files_table.coordinate_to_cell_key(files_table.cursor_coordinate)
        if cell_key.row_key.value is not None:
            highlighted_path = self.path / cell_key.row_key.value
            return highlighted_path.resolve()
        else:
            return None

    def focus(self, attempt: int = 0) -> "FilePicker":
        MAX_ATTEMPTS = 100
        try:
            self.query_one(DataTable).focus()
        except Exception:
            if attempt < MAX_ATTEMPTS:
                self.call_after_refresh(lambda: self.focus(attempt + 1))
            else:
                logging.error("Failed to focus FilePicker DataTable")
        finally:
            return self
