import shlex
import subprocess

from ralphkit.tmux import (
    LOGS_DIR_SHELL,
    TMUX_LIST_FORMAT,
    build_job_script,
    parse_session_list,
)


def _ssh_run(
    host: str,
    cmd: str,
    *,
    check: bool = True,
    capture: bool = True,
    input: str | None = None,
) -> subprocess.CompletedProcess:
    """Run a command on the remote host via SSH."""
    ssh_args = ["ssh", "-o", "ConnectTimeout=10", host, cmd]
    try:
        return subprocess.run(
            ssh_args,
            capture_output=capture,
            text=True,
            check=check,
            input=input,
        )
    except subprocess.CalledProcessError as e:
        if e.returncode == 255:
            detail = ""
            if e.stderr and e.stderr.strip():
                detail = e.stderr.strip().splitlines()[-1]
            msg = f"SSH connection to '{host}' failed."
            if detail:
                msg += f"\n  {detail}"
            msg += f"\n  Verify with: ssh {host}"
            raise SystemExit(msg)
        raise


def _ralph_cmd(ralph_args: list[str], ralph_version: str | None = None) -> str:
    """Build the uvx ralph command string."""
    pkg = f"ralphkit=={ralph_version}" if ralph_version else "ralphkit"
    return f"uvx --from {shlex.quote(pkg)} ralph run " + shlex.join(ralph_args)


def submit_job(
    host: str,
    job_id: str,
    ralph_args: list[str],
    working_dir: str | None = None,
    ralph_version: str | None = None,
) -> None:
    """Submit a ralph job to a remote host via SSH + tmux."""
    # Pre-flight: tmux available?
    result = _ssh_run(host, "command -v tmux", check=False)
    if result.returncode != 0:
        raise SystemExit(
            f"tmux is not installed on '{host}'.\n"
            f"  Install: ssh {host} 'brew install tmux'"
        )

    # Pre-flight: working dir exists?
    if working_dir:
        result = _ssh_run(host, f"test -d {shlex.quote(working_dir)}", check=False)
        if result.returncode != 0:
            raise SystemExit(
                f"Working directory does not exist on '{host}': {working_dir}"
            )

    # Generate job script
    ralph_cmd = _ralph_cmd(ralph_args, ralph_version)
    script = build_job_script(
        job_id,
        ralph_cmd,
        working_dir=working_dir,
    )

    # Upload script via ssh stdin pipe
    script_path = f"{LOGS_DIR_SHELL}/{job_id}.sh"
    _ssh_run(
        host,
        f"mkdir -p {LOGS_DIR_SHELL} && cat > {script_path} && chmod +x {script_path}",
        input=script,
    )

    # Launch in tmux
    _ssh_run(
        host,
        f"tmux new-session -d -s {job_id} {script_path} \\; set-option -t {job_id} remain-on-exit on",
    )


def list_jobs(host: str) -> list[dict]:
    """List active ralphkit jobs on a remote host."""
    result = _ssh_run(
        host,
        f"tmux list-sessions -F '{TMUX_LIST_FORMAT}' 2>/dev/null || true",
        check=False,
    )
    return parse_session_list(result.stdout or "")


def tail_logs(host: str, job_id: str, follow: bool = False) -> None:
    """Tail a remote job's log file. Streams to stdout."""
    log_file = f"{LOGS_DIR_SHELL}/{job_id}.log"
    flag = "-f" if follow else "-100"
    subprocess.run(
        [
            "ssh",
            "-t",
            "-o",
            "ConnectTimeout=10",
            host,
            f'tail {flag} "{log_file}"',
        ],
    )


def cancel_job(host: str, job_id: str) -> None:
    result = _ssh_run(host, f"tmux kill-session -t {job_id}", check=False)
    if result.returncode != 0:
        raise SystemExit(
            f"No job '{job_id}' found on '{host}'.\n"
            f"  Run 'ralph jobs --host {host}' to list active jobs."
        )


def get_attach_command(host: str, job_id: str) -> list[str]:
    """Return the ssh command to attach to a remote tmux session."""
    return ["ssh", "-t", host, "tmux", "attach", "-t", job_id]
