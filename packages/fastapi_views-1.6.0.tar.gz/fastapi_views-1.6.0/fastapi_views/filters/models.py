from collections.abc import MutableSequence
from typing import Any, ClassVar, Literal

from fastapi import Query
from pydantic import BaseModel, PrivateAttr, field_validator

from fastapi_views.pagination import PageNumber, PageSize, PageToken

from .operations import FilterOperation, LogicalOperation, SortOperation
from .types import AnyFields, SearchQuery, Sort


class BaseFilter(BaseModel):
    special_fields: ClassVar[set[str]] = set()
    _kwargs: dict[str, Any] = PrivateAttr({})

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)

        parent_special_fields: set[str] = set()

        for base in cls.__mro__[1:]:
            special_fields: set[str] = getattr(base, "special_fields", set())
            parent_special_fields |= special_fields

        cls.special_fields |= parent_special_fields

    @property
    def filters(self) -> MutableSequence[FilterOperation | LogicalOperation]:
        return self.get_filters()

    def get_filters(self) -> MutableSequence[FilterOperation | LogicalOperation]:
        return []

    def as_kwargs(self) -> dict[str, Any]:
        return (
            self.model_dump(exclude=self.special_fields, exclude_none=True)
            | self._kwargs
        )

    def with_kwargs(self, **kwargs: Any) -> None:
        self._kwargs.update(kwargs)


class ModelFilter(BaseFilter):
    def _get_operations(
        self, field_name: str, value: Any
    ) -> MutableSequence[FilterOperation | LogicalOperation]:
        if value is None:
            return []

        if isinstance(value, BaseFilter):
            model_filters = value.get_filters()
            for operation in model_filters:
                operation.set_prefix(field_name)
            return model_filters
        if "__" in field_name:
            field_name, _, op = field_name.partition("__")
        else:
            op = "eq"
        return [FilterOperation(field=field_name, operator=op, values=value)]

    @property
    def field_names(self) -> set[str]:
        return set(type(self).model_fields) - self.special_fields

    def get_filters(self) -> MutableSequence[FilterOperation | LogicalOperation]:
        filters = super().get_filters()

        for field_name in self.field_names:
            value = getattr(self, field_name)
            filters.extend(self._get_operations(field_name, value))

        for field_name, value in self._kwargs.items():
            filters.extend(self._get_operations(field_name, value))
        return filters


class BasePaginationFilter(BaseFilter):
    special_fields = {"page_size"}

    page_size: PageSize = 100


class PaginationFilter(BasePaginationFilter):
    special_fields = {"page"}

    page: PageNumber = 1

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size

    @property
    def limit(self) -> int:
        return self.page_size


class TokenPaginationFilter(BasePaginationFilter):
    special_fields = {"page_token"}

    page_token: PageToken | None = None


class OrderingFilter(BaseFilter):
    special_fields = {"sort"}

    ordering_fields: ClassVar[set[str]] = set()

    sort: Sort

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if "sort" in cls.model_fields and cls.ordering_fields:
            cls.model_fields["sort"].default = Query(
                None,
                description=f"List of fields to sort by. \
                Prefix with '-' to sort in descending order. \
                Available values: {', '.join(cls.ordering_fields)}",
            )

    @field_validator("sort", mode="after")
    @classmethod
    def validate_sort(cls, value: Sort) -> Sort:
        if value is None:
            return None
        for field in value:
            if field.lstrip("+-") not in cls.ordering_fields:
                msg = f"Unknown sort value '{field}'. Allowed values: {', '.join(cls.ordering_fields)}"
                raise ValueError(msg)
        return value

    @property
    def order_by(self) -> MutableSequence[SortOperation]:
        return self.get_order_by()

    def get_order_by(self) -> MutableSequence[SortOperation]:
        if self.sort is None:
            return []
        order_by = []
        for field_name in self.sort:
            desc = False
            if field_name.startswith("-"):
                desc = True

            operation = SortOperation(field=field_name.lstrip("+-"), desc=desc)
            order_by.append(operation)
        return order_by


class SearchFilter(BaseFilter):
    special_fields = {"query"}
    search_fields: ClassVar[set[str]] = set()
    query: SearchQuery

    def get_filters(self) -> MutableSequence[FilterOperation | LogicalOperation]:
        filters = super().get_filters()

        if self.query:
            search_fields = []

            for field_name in self.search_fields:
                operation = FilterOperation(
                    field=field_name,
                    operator="ilike",
                    values=self.query,
                )

                search_fields.append(operation)

            filters.append(LogicalOperation(operator="or", values=search_fields))
        return filters


# consider implementing projection at queryset level using new OperationType
# but this will require importing sqlalchemy load_only or leaving abstractmethod
class FieldsFilter(BaseFilter):
    special_fields = {"fields"}
    fields_from: ClassVar[type[BaseModel] | None] = None

    fields: AnyFields

    def __init_subclass__(cls, **kwargs: Any) -> None:
        if cls.fields_from:
            fields = tuple(cls.fields_from.model_fields)
            cls.model_fields["fields"].annotation = set[Literal[fields]]  # type: ignore[valid-type]
        super().__init_subclass__(**kwargs)

    def get_fields(self) -> set[str] | None:
        # consider implementing advanced include/exclude (subfields)
        # using '__ ' syntax later on, for now only top-level fields are supported
        return self.fields


class Filter(
    PaginationFilter,
    OrderingFilter,
    SearchFilter,
    FieldsFilter,
    ModelFilter,
):
    """Main filter class that implements all the functionalities:
    pagination, ordering, search, fields and custom attributes filter
    """
