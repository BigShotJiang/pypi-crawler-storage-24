"""
EWS Scoreboard CLI.

Usage:
    ews-scoreboard init              Çalışma dizinini hazırla
    ews-scoreboard run               Tüm pipeline'ı çalıştır
    ews-scoreboard run --step X      Tek adım çalıştır (ingest/transform/marts/export)
    ews-scoreboard run --test N FILE Hızlı test modu (N firma, statik dosyadan)
    ews-scoreboard status            Durum kontrolü
    ews-scoreboard version           Versiyon bilgisi
"""

import argparse
import random
import sys
import time
from pathlib import Path

import pandas as pd

from ews_scoreboard import __version__
from ews_scoreboard.paths import (
    get_source_dir, get_db_path, get_output_dir, get_work_dir, get_data_readme, get_notebook_path, get_notebooks_dir,
)


EXTERNAL_DATA_SUBDIRS = [
    "kik_data_ham_csv",
    "kredi_db",
    "yis_tahmin_data",
    "eus_tahmin_data",
    "eus_hedef_muta",
    "eus_sql_kapsam_muta",
    "statik_db",
    "yis_train_data",
]


def cmd_init(args):
    """Scaffold the working directory structure."""
    base = get_work_dir(args.dir)
    print(f"EWS Scoreboard v{__version__} — init")
    print(f"Çalışma dizini: {base}\n")

    # Create directories
    dirs = [
        base / "db",
        base / "outputs" / "json",
        base / "outputs" / "html",
        base / "outputs" / "validation",
        base / "ml_models",
        base / "seasons",
    ]
    for subdir in EXTERNAL_DATA_SUBDIRS:
        dirs.append(base / "external_data" / subdir)

    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        print(f"  [OK] {d.relative_to(base)}/")

    # Copy data readme
    readme_src = get_data_readme()
    readme_dst = base / "external_data" / "VERI_KOPYALA.txt"
    readme_dst.write_text(readme_src.read_text(encoding="utf-8"), encoding="utf-8")
    print(f"  [OK] external_data/VERI_KOPYALA.txt")

    # Copy all pipeline notebooks (skip old monolithic nb_01_ingest)
    import shutil
    nb_dir = get_notebooks_dir()
    nb_count = 0
    for nb_file in sorted(nb_dir.glob("*.ipynb")):
        if nb_file.name == "nb_01_ingest.ipynb":
            continue  # replaced by nb_01a..nb_01h
        nb_dst = base / nb_file.name
        shutil.copy2(nb_file, nb_dst)
        print(f"  [OK] {nb_file.name}")
        nb_count += 1
    print(f"  [OK] {nb_count} notebook kopyalandı")

    # Write version marker
    version_file = base / "db" / ".nb_version"
    version_file.write_text(__version__, encoding="utf-8")

    print(f"""
{'='*60}
  KURULUM TAMAM
{'='*60}

  Ham veriyi external_data altına kopyalayın:

    {base / 'external_data'}/
    ├── kik_data_ham_csv/        ← KIK izleme CSV
    ├── kredi_db/                ← Kredi risk parquet
    ├── yis_tahmin_data/         ← YIS tahmin CSV
    ├── eus_tahmin_data/         ← EUS tahmin CSV
    ├── eus_hedef_muta/          ← EUS hedef MUTA
    ├── eus_sql_kapsam_muta/     ← EUS kapsam MUTA
    ├── statik_db/               ← Statik bilgiler TXT
    └── yis_train_data/          ← YIS training parquet

  Veri kopyalandıktan sonra:
    ews-scoreboard run              # CLI ile tüm pipeline
    ews-scoreboard run --from transform  # Sadece transform'dan itibaren

  Veya notebook ile (motor ile otomatik skip/cascade):
    ews_pipeline.ipynb              # Orchestrator (Motor class)
    nb_01a_ingest_ddl.ipynb         # Her ingest kaynağı ayrı
    nb_01b_ingest_kik.ipynb
    ...
    nb_02_transform.ipynb           # Bronze → Silver
    nb_03_marts.ipynb               # Scoreboard + Trending + HTML
    nb_04_ml.ipynb                  # ML train + predict
    nb_05a_backtest_eus.ipynb       # EUS backtest
    nb_05b_backtest_yis.ipynb       # YIS backtest
    nb_05c_backtest_ml.ipynb        # ML backtest
""")


def _sync_notebooks(base: Path):
    """Auto-update notebooks if package version changed since last sync."""
    import shutil
    version_file = base / "db" / ".nb_version"
    version_file.parent.mkdir(parents=True, exist_ok=True)

    current = version_file.read_text(encoding="utf-8").strip() if version_file.exists() else ""
    if current == __version__:
        return

    nb_dir = get_notebooks_dir()
    updated = []
    for nb_file in sorted(nb_dir.glob("*.ipynb")):
        if nb_file.name == "nb_01_ingest.ipynb":
            continue
        nb_dst = base / nb_file.name
        shutil.copy2(nb_file, nb_dst)
        updated.append(nb_file.name)

    version_file.write_text(__version__, encoding="utf-8")

    if current:
        print(f"  [SYNC] Notebook'lar güncellendi: v{current} → v{__version__} ({len(updated)} dosya)")
    else:
        print(f"  [SYNC] Notebook'lar kopyalandı: v{__version__} ({len(updated)} dosya)")


def _load_data_paths(base: Path) -> dict:
    """Load data_paths JSON if present. Tries data_paths_nt.json then data_paths.json."""
    import json as _json
    for name in ["data_paths_nt.json", "data_paths.json"]:
        p = base / name
        if p.exists():
            with open(p, encoding="utf-8") as f:
                paths = _json.load(f)
            print(f"  [CONFIG] {name} yüklendi ({len(paths)} kaynak)")
            for k, v in paths.items():
                print(f"    {k}: {v}")
            return paths
    return {}


def _load_test_mutas(save_path: Path) -> set:
    """Load saved test MUTA list."""
    if not save_path.exists():
        print(f"HATA: Kayıtlı test MUTA listesi bulunamadı: {save_path}")
        print("Kullanım: --test 1000 statik_db/statik_bilgiler_2602.txt (yeni seçim)")
        sys.exit(1)
    mutas = set(save_path.read_text(encoding="utf-8").strip().splitlines())
    mutas = {m.strip() for m in mutas if m.strip()}
    print(f"  [TEST] Kayıtlı MUTA listesi: {save_path} ({len(mutas)} firma)")
    return mutas


def _select_test_mutas(statik_path: Path, n: int, save_path: Path) -> set:
    """Select N random MUTAs from statik file, always overwrites saved list."""
    if not statik_path.exists():
        print(f"HATA: Statik dosya bulunamadı: {statik_path}")
        sys.exit(1)

    df = pd.read_csv(statik_path, sep=";", encoding="cp1254", dtype=str, header=0)
    first_col = df.columns[0]
    all_mutas = df[first_col].astype(str).str.strip()
    all_mutas = pd.to_numeric(all_mutas, errors="coerce").dropna().astype(int).astype(str)
    all_mutas = list(set(all_mutas.tolist()))

    if len(all_mutas) < n:
        print(f"  [WARN] Dosyada {len(all_mutas)} firma var, {n} yerine hepsi seçildi")
        selected = all_mutas
    else:
        selected = random.sample(all_mutas, n)

    save_path.parent.mkdir(parents=True, exist_ok=True)
    save_path.write_text("\n".join(sorted(selected)) + "\n", encoding="utf-8")
    print(f"  [TEST] {len(selected)} firma seçildi → {save_path}")
    return set(selected)


def cmd_run(args):
    """Run the pipeline."""
    from ews_scoreboard.pipeline.ingest import run_ingest
    from ews_scoreboard.pipeline.transform import run_transforms
    from ews_scoreboard.pipeline.marts import run_marts
    from ews_scoreboard.pipeline.export import run_export

    base = get_work_dir(args.dir)
    source_dir = get_source_dir(args.dir)
    output_dir = get_output_dir(args.dir)

    # Auto-sync notebooks on version change
    _sync_notebooks(base)

    # ── Test mode ──
    test_mode = hasattr(args, "test") and args.test is not None
    muta_filter = None
    file_suffix = ""

    if test_mode:
        save_path = base / "db" / "test_muta_list.txt"
        test_args = args.test  # [] (parametresiz) veya [N, FILE]

        if len(test_args) == 0:
            # --test (parametresiz) → kayıtlı listeyi kullan
            muta_filter = _load_test_mutas(save_path)
        elif len(test_args) == 2:
            # --test N FILE → yeni seçim yap
            try:
                n_firms = int(test_args[0])
            except ValueError:
                print(f"HATA: Firma sayısı geçersiz: {test_args[0]}")
                sys.exit(1)
            statik_file = test_args[1]

            # Resolve statik file path
            statik_path = Path(statik_file)
            if not statik_path.is_absolute() and not statik_path.exists():
                alt = source_dir / statik_file
                if alt.exists():
                    statik_path = alt
            statik_path = statik_path.resolve()

            muta_filter = _select_test_mutas(statik_path, n_firms, save_path)
        else:
            print("HATA: --test parametresi ya boş ya da 'N DOSYA' şeklinde olmalı")
            print("  --test                  → kayıtlı MUTA listesiyle çalıştır")
            print("  --test 1000 dosya.txt   → yeni seçim yap ve çalıştır")
            sys.exit(1)

        file_suffix = "_test"
        db_path = base / "db" / "ews_test.duckdb"
        print(f"\n  *** TEST MODU: {len(muta_filter)} firma ***\n")
    else:
        db_path = get_db_path(args.dir)

    db_path.parent.mkdir(parents=True, exist_ok=True)

    # Load data path overrides
    data_paths = _load_data_paths(base)

    # Check: either data_paths or source_dir must exist
    if not data_paths and not source_dir.exists():
        print(f"HATA: Ne data_paths.json ne de {source_dir} bulunamadı.")
        print("Seçenek 1: 'ews-scoreboard init' çalıştırıp veriyi external_data/ altına kopyalayın.")
        print("Seçenek 2: data_paths.json veya data_paths_nt.json ile veri yollarını belirtin.")
        sys.exit(1)

    steps = {
        "ingest": lambda: run_ingest(source_dir, db_path, data_paths,
                                      muta_filter=muta_filter),
        "transform": lambda: run_transforms(db_path,
                                             referans_tarih_list=args.periods),
        "marts": lambda: run_marts(db_path, output_dir / "json",
                                    file_suffix=file_suffix),
        "export": lambda: run_export(db_path, output_dir,
                                      file_suffix=file_suffix),
    }

    all_steps = list(steps.keys())

    if args.step and args.step != "all":
        step_names = [args.step]
    elif args.from_step:
        idx = all_steps.index(args.from_step)
        step_names = all_steps[idx:]
    else:
        step_names = all_steps

    mode_label = "TEST" if test_mode else "pipeline"
    print(f"EWS Scoreboard v{__version__} — {mode_label}")
    print(f"Çalışma dizini: {base}")
    print(f"Kaynak: {source_dir}")
    print(f"DB: {db_path}\n")

    t0 = time.time()
    results = {}

    for name in step_names:
        fn = steps[name]
        t1 = time.time()
        print(f"\n{'='*60}")
        print(f"  STEP: {name}")
        print(f"{'='*60}")
        try:
            fn()
            elapsed = time.time() - t1
            results[name] = f"OK ({elapsed:.1f}s)"
            print(f"\n  [{name}] OK in {elapsed:.1f}s")
        except Exception as e:
            results[name] = f"FAIL: {e}"
            print(f"\n  [{name}] FAIL: {e}")
            try:
                from ews_scoreboard.sanitize import save_error_report
                report_path = get_output_dir(args.dir) / "error_report.txt"
                save_error_report(e, db_path, context=f"step={name}", output_path=report_path)
                print(f"  Hata raporu: {report_path}")
                print(f"  Bu dosyayı güvenle paylaşabilirsiniz (kişisel bilgiler sansürlü).")
            except Exception:
                pass
            raise

    total = time.time() - t0
    print(f"\n{'='*60}")
    print(f"  PIPELINE COMPLETE ({total:.1f}s)")
    print(f"{'='*60}")
    for k, v in results.items():
        print(f"  {k:12s}: {v}")


def cmd_status(args):
    """Check the current state."""
    base = get_work_dir(args.dir)
    source_dir = get_source_dir(args.dir)
    db_path = get_db_path(args.dir)
    output_dir = get_output_dir(args.dir)

    print(f"EWS Scoreboard v{__version__} — status")
    print(f"Çalışma dizini: {base}\n")

    # external_data check
    print("  [external_data]")
    if source_dir.exists():
        for subdir in EXTERNAL_DATA_SUBDIRS:
            p = source_dir / subdir
            if p.exists():
                n_files = len(list(p.iterdir()))
                status = f"{n_files} dosya" if n_files > 0 else "BOŞ"
                print(f"    {subdir}: {status}")
            else:
                print(f"    {subdir}: YOK")
    else:
        print("    BULUNAMADI — 'ews-scoreboard init' çalıştırın")

    # DB check
    print("\n  [db]")
    if db_path.exists():
        size_mb = db_path.stat().st_size / (1024 * 1024)
        print(f"    ews.duckdb: {size_mb:.2f} MB")
        try:
            import duckdb
            con = duckdb.connect(str(db_path), read_only=True)
            tables = con.execute("SHOW TABLES").fetchall()
            for (t,) in tables:
                cnt = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                if cnt > 0:
                    print(f"      {t}: {cnt} rows")
            con.close()
        except Exception as e:
            print(f"      Okuma hatası: {e}")
    else:
        print("    ews.duckdb: YOK — pipeline henüz çalışmamış")

    # Output check
    print("\n  [outputs]")
    for fname in ["json/sample_scoreboard.json", "json/sample_trending_lists.json"]:
        fpath = output_dir / fname
        if fpath.exists():
            print(f"    {fname}: {fpath.stat().st_size / 1024:.1f} KB")
        else:
            print(f"    {fname}: YOK")


def cmd_version(args):
    print(f"ews_scoreboard {__version__}")


def main():
    parser = argparse.ArgumentParser(
        prog="ews-scoreboard",
        description="EWS Early Warning Scoreboard Pipeline",
    )
    parser.add_argument("--dir", type=Path, default=None,
                        help="Çalışma dizini (varsayılan: bulunduğunuz dizin)")

    sub = parser.add_subparsers(dest="command")

    sub.add_parser("init", help="Çalışma dizinini hazırla")
    run_p = sub.add_parser("run", help="Pipeline çalıştır")
    run_p.add_argument("--step", choices=["ingest", "transform", "marts", "export", "all"],
                       default="all")
    run_p.add_argument("--from", dest="from_step",
                       choices=["ingest", "transform", "marts", "export"],
                       default=None,
                       help="Bu adımdan itibaren çalıştır (örn: --from transform → ingest atlanır)")
    run_p.add_argument("--periods", type=lambda s: [int(x) for x in s.split(",")],
                       default=None,
                       help="Dönem filtresi (örn: --periods 2501,2502,2503)")
    run_p.add_argument("--test", nargs="*", metavar="ARG",
                       default=None,
                       help="Test modu: --test (kayıtlı listeyle) veya --test 1000 statik_db/statik_bilgiler_2602.txt (yeni seçim)")
    sub.add_parser("status", help="Durum kontrolü")
    sub.add_parser("version", help="Versiyon bilgisi")

    args = parser.parse_args()

    if args.command == "init":
        cmd_init(args)
    elif args.command == "run":
        cmd_run(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "version":
        cmd_version(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
