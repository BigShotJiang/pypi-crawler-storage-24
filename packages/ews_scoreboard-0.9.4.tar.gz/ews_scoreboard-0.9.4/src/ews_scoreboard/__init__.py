"""EWS Scoreboard Pipeline."""
__version__ = "0.9.4"
