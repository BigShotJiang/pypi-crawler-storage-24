import time
import json
class Log:
    def __init__(self):
        self.logs = dict()
    def log(self, name):
        self.logs[name] = []
    def warning(self, log_name, description):
        self.logs[log_name].append(("W", time.strftime("%H:%M:%S"), description))
    def info(self, log_name, description):
        self.logs[log_name].append(("I", time.strftime("%H:%M:%S"), description))
    def error(self, log_name, description):
        self.logs[log_name].append(("E", time.strftime("%H:%M:%S"),  description))
    def return_log(self, log_name):
        return self.logs[log_name]
    def save_log(self, filename="log.log"):
        with open(filename, "w") as f:
            json.dump(self.logs, f, indent=2)
    def open_log(self, filename="log.log"):
        with open(filename) as f:
            self.logs = json.load(f)
