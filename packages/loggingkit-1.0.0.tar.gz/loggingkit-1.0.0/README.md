# LoggingKit

A simple Python logging utility

## Installation

```bash
pip install loggerkit
```

## Importing

```python
import loggerkit
```

## Usage

Just as an example, we will use this code:

```python
log1 = loggerkit.Log()
```

### create\_log()

The function log() takes one argument: the name of the log. It creates a new log

```python
log1.log("test")
```

### warning()

The function warning() takes two arguments: the name of the log you want the warning in and the warning. It creates the specified warning in the specified log.

```python
log1.warning("test",  "This is a warning")
```

### info()

The function info() takes two arguments: the name of the log you want the info in and the info. It creates the specified info in the specified log.

```python
log1.info("test", "This is an info")
```

### error()

The function error() takes two arguments: the name of the log you want the error in and the error. It creates the specified error in the specified log.

```python
log1.error("test", "This is an error")
```

### return_log()

The function return_log() takes one argument: the name of the log you want it to return. It returns the contents of the specified log.

```python
log1.return_log("test")
```

### save_log()

The function save_log() takes one argument which has a default, log.json: the name of the file you want to export the  logs into. (With the extension!) It exports the set of logs into the specified filename.

```python
log1.save_log() #The default will be used here
```

### open_log()

The function open_log() takes one argument, which has a default, log.json: The name of the file you want to import the logs from. (Also with the extension!) It imports the logs from the specified filename.

```python
log1.open_log() #The default will be used here as well
```

