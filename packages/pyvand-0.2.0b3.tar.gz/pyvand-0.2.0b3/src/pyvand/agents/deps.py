import asyncio
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr

from ..database import Database, UserDocument
from ..storage import Storage
from .events import ThreadStreamEvent


T_Context = TypeVar("T_Context")


class AgentDeps[T_Context](BaseModel):
    """
    Standard agent dependencies for the Pyvand framework.
    Hides internal complexity (DB, Storage) from the developer.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    database: Database
    storage: Storage
    user: UserDocument
    context: T_Context

    # Internal event queue for streaming custom events
    _event_queue: asyncio.Queue = PrivateAttr(default_factory=asyncio.Queue)

    async def stream(self, event: ThreadStreamEvent):
        await self._event_queue.put(event)

    async def stream_events(self):
        while True:
            event = await self._event_queue.get()
            if event is None:
                break
            yield event
