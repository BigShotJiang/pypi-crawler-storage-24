# Copyright 2026 Clouthier Simulation Labs
# SPDX-License-Identifier: Proprietary
#
# AXIOM Trainer CLI
# https://quarterbit.dev

"""
QuarterBit CLI - Train models and earn $AXM from the command line.

Commands:
    quarterbit init          Generate new wallet
    quarterbit register      Register hardware with network
    quarterbit start         Start training
    quarterbit tasks         List compatible tasks
    quarterbit stats         Your training statistics
    quarterbit balance       Check $AXM balance
    quarterbit claim         Claim pending rewards
    quarterbit pipeline      Pipeline parallelism commands
"""

import os
import sys
import json
import time
import secrets
import asyncio
from pathlib import Path
from typing import Optional
from dataclasses import dataclass

try:
    import typer
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
    from rich.live import Live
    from rich.layout import Layout
    from rich import box
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Install 'typer' and 'rich' for full CLI experience")
    print("  pip install typer rich")

# Local imports
from .client import AxiomRPCClient
from .trainer import AxiomTrainer

# Constants
CONFIG_DIR = Path.home() / ".axiom"
CONFIG_FILE = CONFIG_DIR / "config.json"
WALLET_FILE = CONFIG_DIR / "wallet.json"
LOG_FILE = CONFIG_DIR / "trainer.log"

# Default RPC
DEFAULT_RPC = "http://localhost:9545"

# Create app
app = typer.Typer(
    name="quarterbit",
    help="AXIOM AI Trainer - Train models and earn $AXM",
    add_completion=False,
)

# Pipeline subcommands
pipeline_app = typer.Typer(help="Pipeline parallelism commands (train 70B on phones)")
app.add_typer(pipeline_app, name="pipeline")

# Rich console
console = Console() if RICH_AVAILABLE else None


def print_banner():
    """Print AXIOM banner."""
    if not RICH_AVAILABLE:
        print("=" * 60)
        print("  AXIOM TRAINER v0.3.0")
        print("  https://quarterbit.dev")
        print("=" * 60)
        return

    banner = """
[bold cyan]╔════════════════════════════════════════════════════════════════╗
║  [white]AXIOM TRAINER[/white] v0.3.0              [dim]https://quarterbit.dev[/dim]  ║
║  [dim]Train models. Earn $AXM. No GPU required (Pipeline Mode).[/dim]   ║
╚════════════════════════════════════════════════════════════════╝[/bold cyan]
"""
    console.print(banner)


def load_config() -> dict:
    """Load config from ~/.axiom/config.json"""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {
        "rpc_url": DEFAULT_RPC,
        "auto_claim": True,
        "auto_select": True,
        "min_reward": 1,
    }


def save_config(config: dict):
    """Save config to ~/.axiom/config.json"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def load_wallet() -> Optional[dict]:
    """Load wallet from ~/.axiom/wallet.json"""
    if WALLET_FILE.exists():
        with open(WALLET_FILE) as f:
            return json.load(f)
    return None


def save_wallet(wallet: dict):
    """Save wallet to ~/.axiom/wallet.json"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(WALLET_FILE, "w") as f:
        json.dump(wallet, f, indent=2)
    # Secure permissions
    os.chmod(WALLET_FILE, 0o600)


def get_trainer() -> AxiomTrainer:
    """Get configured trainer instance."""
    config = load_config()
    wallet = load_wallet()

    if not wallet:
        if RICH_AVAILABLE:
            console.print("[red]No wallet found. Run 'quarterbit init' first.[/red]")
        else:
            print("No wallet found. Run 'quarterbit init' first.")
        raise typer.Exit(1)

    return AxiomTrainer(
        rpc_url=config.get("rpc_url", DEFAULT_RPC),
        private_key=wallet.get("private_key"),
        address=wallet.get("address"),
    )


# ============================================================================
# WALLET COMMANDS
# ============================================================================

@app.command()
def init():
    """Generate a new wallet."""
    print_banner()

    if WALLET_FILE.exists():
        if RICH_AVAILABLE:
            console.print("[yellow]Wallet already exists at ~/.axiom/wallet.json[/yellow]")
            if not typer.confirm("Overwrite existing wallet?"):
                raise typer.Exit(0)
        else:
            print("Wallet already exists. Overwrite? [y/N]")
            if input().lower() != 'y':
                return

    # Generate new wallet
    private_key = "0x" + secrets.token_hex(32)

    # Derive address (simplified - in production use eth_keys)
    import hashlib
    addr_hash = hashlib.sha256(private_key.encode()).hexdigest()[:40]
    address = "0x" + addr_hash

    wallet = {
        "private_key": private_key,
        "address": address,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    save_wallet(wallet)

    # Also save default config
    save_config(load_config())

    if RICH_AVAILABLE:
        console.print("\n[green]Wallet created successfully![/green]\n")
        console.print(f"  Address: [cyan]{address}[/cyan]")
        console.print(f"  Config:  [dim]~/.axiom/config.json[/dim]")
        console.print(f"  Wallet:  [dim]~/.axiom/wallet.json[/dim]")
        console.print("\n[yellow]IMPORTANT: Back up your private key![/yellow]")
        console.print(f"  Private Key: [red]{private_key}[/red]")
    else:
        print(f"\nWallet created!")
        print(f"  Address: {address}")
        print(f"  Private Key: {private_key}")
        print("\nIMPORTANT: Back up your private key!")


@app.command("import")
def import_wallet(
    key: Optional[str] = typer.Option(None, "--key", "-k", help="Private key (0x...)"),
    seed: Optional[str] = typer.Option(None, "--seed", "-s", help="Seed phrase"),
):
    """Import an existing wallet."""
    print_banner()

    if not key and not seed:
        if RICH_AVAILABLE:
            console.print("[red]Provide --key or --seed[/red]")
        else:
            print("Provide --key or --seed")
        raise typer.Exit(1)

    if seed:
        # TODO: Implement BIP39 seed phrase derivation
        if RICH_AVAILABLE:
            console.print("[yellow]Seed phrase import not yet implemented[/yellow]")
        raise typer.Exit(1)

    # Import from private key
    private_key = key if key.startswith("0x") else "0x" + key

    # Derive address
    import hashlib
    addr_hash = hashlib.sha256(private_key.encode()).hexdigest()[:40]
    address = "0x" + addr_hash

    wallet = {
        "private_key": private_key,
        "address": address,
        "imported_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    save_wallet(wallet)

    if RICH_AVAILABLE:
        console.print(f"\n[green]Wallet imported![/green]")
        console.print(f"  Address: [cyan]{address}[/cyan]")
    else:
        print(f"Wallet imported: {address}")


@app.command()
def balance():
    """Show $AXM balance."""
    print_banner()
    trainer = get_trainer()

    try:
        bal = trainer.get_balance()
        axm = bal / 1e18

        if RICH_AVAILABLE:
            console.print(f"\n  Address: [cyan]{trainer.address}[/cyan]")
            console.print(f"  Balance: [green]{axm:,.4f} $AXM[/green]\n")
        else:
            print(f"Address: {trainer.address}")
            print(f"Balance: {axm:,.4f} $AXM")
    except Exception as e:
        if RICH_AVAILABLE:
            console.print(f"[red]Error: {e}[/red]")
        else:
            print(f"Error: {e}")


# ============================================================================
# REGISTRATION
# ============================================================================

@app.command()
def register(
    memory: Optional[int] = typer.Option(None, "--memory", "-m", help="Memory in GB"),
    gpu: Optional[str] = typer.Option(None, "--gpu", "-g", help="GPU name (e.g., 'RTX 4090')"),
    cpu_only: bool = typer.Option(False, "--cpu", help="Register as CPU-only trainer"),
):
    """Register hardware with the network."""
    print_banner()
    trainer = get_trainer()

    # Auto-detect if not specified
    if memory is None:
        try:
            import torch
            if torch.cuda.is_available():
                memory = int(torch.cuda.get_device_properties(0).total_memory / 1e9)
                gpu = gpu or torch.cuda.get_device_name(0)
            else:
                import psutil
                memory = int(psutil.virtual_memory().total / 1e9)
        except:
            memory = 8  # Default

    has_gpu = not cpu_only and gpu is not None

    if RICH_AVAILABLE:
        with console.status("[cyan]Registering with network...[/cyan]"):
            info = trainer.register(
                memory_gb=memory,
                has_gpu=has_gpu,
                device_name=gpu or "CPU"
            )

        console.print(f"\n[green]Registered successfully![/green]\n")
        console.print(f"  Address:  [cyan]{trainer.address}[/cyan]")
        console.print(f"  Memory:   {memory} GB")
        console.print(f"  Device:   {gpu or 'CPU'}")
        console.print(f"  Tier:     [yellow]{info.tier if info else 'unknown'}[/yellow]")
    else:
        info = trainer.register(memory_gb=memory, has_gpu=has_gpu, device_name=gpu or "CPU")
        print(f"Registered: {trainer.address}")
        print(f"Memory: {memory} GB, Device: {gpu or 'CPU'}")


# ============================================================================
# STAKING
# ============================================================================

@app.command()
def stake(
    amount: int = typer.Argument(..., help="Amount of $AXM to stake"),
):
    """Stake $AXM to participate in training."""
    print_banner()
    trainer = get_trainer()

    if RICH_AVAILABLE:
        with console.status(f"[cyan]Staking {amount} $AXM...[/cyan]"):
            result = trainer.client.stake_trainer(trainer.address, amount)
        console.print(f"\n[green]Staked {amount} $AXM![/green]")
        console.print(f"  Total stake: {result.get('totalStake', 'N/A')} $AXM")
    else:
        result = trainer.client.stake_trainer(trainer.address, amount)
        print(f"Staked {amount} $AXM")


@app.command()
def unstake(
    amount: int = typer.Argument(..., help="Amount of $AXM to unstake"),
):
    """Withdraw staked $AXM."""
    print_banner()
    trainer = get_trainer()

    result = trainer.client.unstake_trainer(trainer.address, amount)
    if RICH_AVAILABLE:
        console.print(f"\n[green]Unstaked {amount} $AXM![/green]")
    else:
        print(f"Unstaked {amount} $AXM")


@app.command("stake-info")
def stake_info():
    """View stake status."""
    print_banner()
    trainer = get_trainer()

    info = trainer.client.get_stake_info(trainer.address)

    if RICH_AVAILABLE:
        console.print(f"\n  Staked:  [green]{info.get('amount', 0)} $AXM[/green]")
        console.print(f"  Locked:  {info.get('locked', 0)} $AXM")
        console.print(f"  Slashed: [red]{info.get('slashed', 0)} $AXM[/red]")
    else:
        print(f"Staked: {info.get('amount', 0)} $AXM")


# ============================================================================
# MINING / TRAINING
# ============================================================================

@app.command()
def tasks():
    """List compatible training tasks."""
    print_banner()
    trainer = get_trainer()

    task_list = trainer.get_compatible_tasks()

    if not task_list:
        if RICH_AVAILABLE:
            console.print("[yellow]No compatible tasks found.[/yellow]")
        else:
            print("No compatible tasks found.")
        return

    if RICH_AVAILABLE:
        table = Table(title="Compatible Tasks", box=box.ROUNDED)
        table.add_column("Task ID", style="cyan", max_width=12)
        table.add_column("Model", style="white")
        table.add_column("Batches", justify="right")
        table.add_column("Reward", justify="right", style="green")
        table.add_column("Tier", style="yellow")

        for task in task_list[:10]:  # Show top 10
            table.add_row(
                task.task_id[:10] + "...",
                task.model_size_category,
                f"{task.batches_remaining}/{task.total_batches}",
                f"{task.reward_per_batch} $AXM",
                task.model_size_category,
            )

        console.print(table)
    else:
        print("\nCompatible Tasks:")
        for task in task_list[:10]:
            print(f"  {task.task_id[:10]}... | {task.model_size_category} | {task.reward_per_batch} $AXM/batch")


@app.command()
def start(
    auto: bool = typer.Option(True, "--auto/--manual", help="Auto-select tasks"),
    task_id: Optional[str] = typer.Option(None, "--task", "-t", help="Specific task ID"),
    rounds: int = typer.Option(0, "--rounds", "-r", help="Number of rounds (0=infinite)"),
    daemon: bool = typer.Option(False, "--daemon", "-d", help="Run in background (daemon mode)"),
):
    """Start mining (training models)."""
    print_banner()

    # Daemon mode - run in background with auto-restart
    if daemon:
        from .daemon import AxiomDaemon, get_daemon_status

        # Check if already running
        status = get_daemon_status()
        if status["running"]:
            if RICH_AVAILABLE:
                console.print(f"[yellow]Daemon already running (PID {status['pid']})[/yellow]")
                console.print(f"  Use 'quarterbit stop' to stop it.")
            else:
                print(f"Daemon already running (PID {status['pid']})")
            raise typer.Exit(0)

        config = load_config()
        wallet = load_wallet()

        daemon_obj = AxiomDaemon(
            rpc_url=config.get("rpc_url", DEFAULT_RPC),
            private_key=wallet.get("private_key") if wallet else None,
            auto_select=auto,
            min_reward=config.get("min_reward", 1),
        )

        if RICH_AVAILABLE:
            console.print("[cyan]Starting daemon...[/cyan]")

        # Start in background (Unix) or foreground (Windows)
        success = daemon_obj.start(daemon=True)

        if success:
            if RICH_AVAILABLE:
                console.print("[green]Daemon started![/green]")
                console.print(f"  Log: [dim]~/.axiom/trainer.log[/dim]")
                console.print(f"  Status: [dim]quarterbit daemon-status[/dim]")
                console.print(f"  Stop: [dim]quarterbit stop[/dim]")
            else:
                print("Daemon started. Check ~/.axiom/trainer.log for output.")
        else:
            if RICH_AVAILABLE:
                console.print("[red]Failed to start daemon[/red]")
            raise typer.Exit(1)
        return

    # Foreground mode
    trainer = get_trainer()

    if not trainer._registered:
        if RICH_AVAILABLE:
            console.print("[yellow]Not registered. Running auto-registration...[/yellow]")
        trainer.register()

    if task_id:
        # Train specific task
        tasks_list = trainer.get_compatible_tasks()
        task = next((t for t in tasks_list if t.task_id == task_id), None)
        if not task:
            if RICH_AVAILABLE:
                console.print(f"[red]Task {task_id} not found or not compatible.[/red]")
            raise typer.Exit(1)
        _train_task_with_ui(trainer, task, rounds)
    elif auto:
        # Auto-select and train
        _auto_train_loop(trainer, rounds)
    else:
        # Manual selection
        tasks_list = trainer.get_compatible_tasks()
        if not tasks_list:
            if RICH_AVAILABLE:
                console.print("[yellow]No compatible tasks available.[/yellow]")
            raise typer.Exit(0)

        if RICH_AVAILABLE:
            console.print("\nSelect a task:")
            for i, task in enumerate(tasks_list[:10]):
                console.print(f"  [{i+1}] {task.task_id[:10]}... - {task.model_size_category} - {task.reward_per_batch} $AXM")

            choice = typer.prompt("Enter number", type=int)
            if 1 <= choice <= len(tasks_list):
                _train_task_with_ui(trainer, tasks_list[choice-1], rounds)


def _auto_train_loop(trainer: AxiomTrainer, max_rounds: int):
    """Auto-select and train tasks continuously."""
    round_count = 0

    while True:
        tasks_list = trainer.get_compatible_tasks()
        if not tasks_list:
            if RICH_AVAILABLE:
                console.print("[yellow]No tasks available. Waiting...[/yellow]")
            time.sleep(30)
            continue

        # Pick highest reward task
        task = max(tasks_list, key=lambda t: t.reward_per_batch)
        _train_task_with_ui(trainer, task, 1)

        round_count += 1
        if max_rounds > 0 and round_count >= max_rounds:
            break


def _train_task_with_ui(trainer: AxiomTrainer, task, rounds: int):
    """Train a task with rich progress UI."""
    if not RICH_AVAILABLE:
        print(f"Training task {task.task_id[:10]}...")
        trainer.train_distributed(task, num_rounds=rounds if rounds > 0 else 10)
        return

    # Rich live display
    layout = Layout()

    with Live(console=console, refresh_per_second=4) as live:
        # Header panel
        header = Panel(
            f"[bold]Task:[/bold] {task.task_id[:16]}...\n"
            f"[bold]Model:[/bold] {task.model_size_category} ({task.model_params:,} params)\n"
            f"[bold]Reward:[/bold] {task.reward_per_batch} $AXM/batch",
            title="[cyan]AXIOM Training[/cyan]",
            border_style="cyan",
        )
        live.update(header)

        try:
            # Actually train
            results = trainer.train_distributed(
                task,
                num_rounds=rounds if rounds > 0 else 10,
                batches_per_round=10,
            )

            console.print(f"\n[green]Training complete![/green]")
            console.print(f"  Rounds: {len(results)}")
            if results:
                console.print(f"  Final loss: {results[-1].get('loss', 'N/A')}")
        except KeyboardInterrupt:
            console.print("\n[yellow]Training stopped.[/yellow]")
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")


@app.command()
def stop():
    """Stop mining gracefully."""
    print_banner()

    from .daemon import AxiomDaemon, get_daemon_status

    status = get_daemon_status()

    if not status["running"]:
        if RICH_AVAILABLE:
            console.print("[yellow]Daemon is not running.[/yellow]")
        else:
            print("Daemon is not running.")
        return

    config = load_config()
    wallet = load_wallet()

    daemon = AxiomDaemon(
        rpc_url=config.get("rpc_url", DEFAULT_RPC),
        private_key=wallet.get("private_key") if wallet else None,
    )

    if RICH_AVAILABLE:
        with console.status("[cyan]Stopping daemon...[/cyan]"):
            success = daemon.stop()

        if success:
            console.print("[green]Daemon stopped.[/green]")
        else:
            console.print("[red]Failed to stop daemon.[/red]")
    else:
        daemon.stop()
        print("Daemon stopped.")


@app.command("daemon-status")
def daemon_status():
    """Show daemon status."""
    print_banner()

    from .daemon import get_daemon_status

    status = get_daemon_status()

    if RICH_AVAILABLE:
        if status["running"]:
            console.print(f"\n  Status:   [green]RUNNING[/green]")
            console.print(f"  PID:      {status['pid']}")
        else:
            console.print(f"\n  Status:   [yellow]STOPPED[/yellow]")

        console.print(f"  Started:  {status['started_at'] or 'N/A'}")
        console.print(f"  Restarts: {status['restart_count']}")
        console.print(f"  Batches:  {status['total_batches']}")
        console.print(f"  Rewards:  {status['total_rewards']:.4f} $AXM")
        console.print(f"  Task:     {status['current_task'] or 'None'}")
        console.print(f"  Log:      [dim]{status['log_file']}[/dim]")
    else:
        print(f"Running: {status['running']}")
        print(f"PID: {status['pid']}")
        print(f"Batches: {status['total_batches']}")


@app.command()
def logs(
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output"),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
):
    """View daemon logs."""
    log_file = CONFIG_DIR / "trainer.log"

    if not log_file.exists():
        if RICH_AVAILABLE:
            console.print("[yellow]No log file found.[/yellow]")
        else:
            print("No log file found.")
        return

    if follow:
        # Follow mode - tail -f equivalent
        import subprocess
        if sys.platform == "win32":
            # Windows: use PowerShell Get-Content -Wait
            subprocess.run(["powershell", "-Command", f"Get-Content '{log_file}' -Wait -Tail {lines}"])
        else:
            # Unix: use tail -f
            subprocess.run(["tail", "-f", "-n", str(lines), str(log_file)])
    else:
        # Just show last N lines
        with open(log_file) as f:
            all_lines = f.readlines()
            for line in all_lines[-lines:]:
                print(line.rstrip())


# ============================================================================
# REWARDS
# ============================================================================

@app.command()
def claim(
    task_id: Optional[str] = typer.Option(None, "--task", "-t", help="Specific task ID"),
):
    """Claim pending rewards."""
    print_banner()
    trainer = get_trainer()

    if RICH_AVAILABLE:
        with console.status("[cyan]Claiming rewards...[/cyan]"):
            # Get all tasks and claim
            tasks_list = trainer.get_compatible_tasks()
            total_claimed = 0

            for task in tasks_list:
                if task_id and task.task_id != task_id:
                    continue
                try:
                    result = trainer.claim_rewards(task.task_id)
                    total_claimed += result.get('totalReward', 0)
                except:
                    pass

        console.print(f"\n[green]Claimed {total_claimed / 1e18:.4f} $AXM![/green]")
    else:
        print("Claiming rewards...")


# ============================================================================
# STATS
# ============================================================================

@app.command()
def stats():
    """Your mining statistics."""
    print_banner()
    trainer = get_trainer()

    try:
        momentum = trainer.get_momentum()
        bal = trainer.get_balance()

        if RICH_AVAILABLE:
            table = Table(title="Your Stats", box=box.ROUNDED)
            table.add_column("Metric", style="cyan")
            table.add_column("Value", style="white")

            table.add_row("Address", trainer.address)
            table.add_row("Balance", f"{bal/1e18:,.4f} $AXM")
            table.add_row("Multiplier", f"{momentum.multiplier:.2f}x")
            table.add_row("Consistency", f"{momentum.consistency*100:.1f}%")
            table.add_row("Streak", str(momentum.streak))
            table.add_row("Total Rounds", str(momentum.total_rounds))

            console.print(table)
        else:
            print(f"Address: {trainer.address}")
            print(f"Balance: {bal/1e18:,.4f} $AXM")
            print(f"Multiplier: {momentum.multiplier:.2f}x")
    except Exception as e:
        if RICH_AVAILABLE:
            console.print(f"[red]Error: {e}[/red]")
        else:
            print(f"Error: {e}")


@app.command()
def momentum():
    """Show your current reward multiplier."""
    print_banner()
    trainer = get_trainer()

    mom = trainer.get_momentum()

    if RICH_AVAILABLE:
        console.print(f"\n  Multiplier:  [green]{mom.multiplier:.2f}x[/green]")
        console.print(f"  Consistency: {mom.consistency*100:.1f}%")
        console.print(f"  Streak:      {mom.streak} rounds")
        console.print(f"  Total:       {mom.total_rounds} rounds")
    else:
        print(f"Multiplier: {mom.multiplier:.2f}x")


@app.command()
def reliability():
    """Show your reliability stats (v2 reward system).

    The v2 reward system is simpler and more predictable:
      reward = batches_completed x base_rate x reliability_multiplier

    Your reliability multiplier (0.8x - 1.2x) is based on:
      - Completion rate (50%) - % of assigned batches you complete
      - Uptime (30%) - time online vs time assigned
      - Latency (20%) - how fast you submit gradients
    """
    print_banner()
    trainer = get_trainer()

    try:
        rel = trainer.client.get_trainer_reliability(trainer.address)

        if RICH_AVAILABLE:
            console.print("\n[bold cyan]Reliability Stats (v2)[/bold cyan]\n")

            # Color based on multiplier
            mult_color = "green" if rel.reliability_multiplier >= 1.1 else \
                        "yellow" if rel.reliability_multiplier >= 0.95 else "red"

            console.print(f"  Multiplier:     [{mult_color}]{rel.reliability_multiplier:.2f}x[/{mult_color}]")
            console.print(f"  Completion:     {rel.completion_rate*100:.1f}%")
            console.print(f"  Drop Rate:      {rel.drop_rate:.1f}%")
            console.print(f"  Avg Latency:    {rel.avg_latency_ms:.0f}ms")
            console.print(f"  Current Streak: {rel.completion_streak}")
            console.print()
            console.print(f"  Batches Done:   {rel.batches_completed:,}")
            console.print(f"  Batches Assigned: {rel.batches_assigned:,}")
            console.print(f"  Total Rewards:  {rel.total_rewards/1e18:,.4f} $AXM")

            if rel.is_flagged:
                console.print("\n[red bold]WARNING: You are flagged for sign mismatch.[/red bold]")
                console.print("[red]Submit valid gradients to clear the flag.[/red]")
        else:
            print(f"Multiplier: {rel.reliability_multiplier:.2f}x")
            print(f"Completion: {rel.completion_rate*100:.1f}%")
            print(f"Batches: {rel.batches_completed}/{rel.batches_assigned}")

    except Exception as e:
        if RICH_AVAILABLE:
            console.print(f"[red]Error: {e}[/red]")
        else:
            print(f"Error: {e}")


@app.command()
def leaderboard():
    """Network leaderboard."""
    print_banner()
    trainer = get_trainer()

    lb = trainer.client.get_trainer_leaderboard()
    trainers = lb.get('trainers', [])

    if RICH_AVAILABLE:
        table = Table(title="Top Trainers", box=box.ROUNDED)
        table.add_column("Rank", style="yellow", justify="right")
        table.add_column("Address", style="cyan")
        table.add_column("Multiplier", justify="right")
        table.add_column("Batches", justify="right")
        table.add_column("Rewards", justify="right", style="green")

        for i, t in enumerate(trainers[:10]):
            is_me = t.get('address') == trainer.address
            style = "bold" if is_me else ""
            table.add_row(
                f"#{i+1}",
                t.get('address', '')[:10] + "..." + (" (you)" if is_me else ""),
                f"{t.get('multiplier', 1):.2f}x",
                str(t.get('batchesCompleted', 0)),
                f"{t.get('totalRewards', 0)/1e18:.2f} $AXM",
                style=style,
            )

        console.print(table)
    else:
        print("Leaderboard:")
        for i, t in enumerate(trainers[:10]):
            print(f"  #{i+1} {t.get('address', '')[:10]}... - {t.get('multiplier', 1):.2f}x")


# ============================================================================
# PIPELINE PARALLELISM (NEW v0.3.0)
# ============================================================================

@pipeline_app.command("list")
def pipeline_list():
    """List available pipeline tasks."""
    print_banner()
    trainer = get_trainer()

    if RICH_AVAILABLE:
        console.print("\n[cyan]Pipeline Tasks (train 70B on phones!):[/cyan]\n")

        # TODO: Get actual pipeline tasks from RPC
        console.print("  [dim]No pipeline tasks available yet.[/dim]")
        console.print("  [dim]Create one with: axiom-task create-pipeline[/dim]\n")
    else:
        print("No pipeline tasks available yet.")


@pipeline_app.command("join")
def pipeline_join(
    task_id: str = typer.Argument(..., help="Pipeline task ID to join"),
):
    """Join a pipeline task (auto-assigns layers)."""
    print_banner()

    if RICH_AVAILABLE:
        console.print(f"\n[cyan]Joining pipeline {task_id[:10]}...[/cyan]\n")

        # Import pipeline trainer
        try:
            from .pipeline_trainer import AxiomPipelineTrainerSync

            config = load_config()
            wallet = load_wallet()

            trainer = AxiomPipelineTrainerSync(
                rpc_url=config.get("rpc_url", DEFAULT_RPC),
                private_key=wallet.get("private_key"),
            )

            assignment = trainer.join_pipeline(task_id)

            console.print(f"[green]Joined pipeline![/green]\n")
            console.print(f"  Layers:   {assignment.layer_start} - {assignment.layer_end}")
            console.print(f"  Position: Stage {assignment.pipeline_position}")
            console.print(f"  Memory:   ~{(assignment.layer_end - assignment.layer_start) * 0.8:.1f} GB")
            console.print(f"\n[dim]Run 'quarterbit pipeline status' to monitor.[/dim]")

        except ImportError:
            console.print("[red]Pipeline module not available.[/red]")
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
    else:
        print(f"Joining pipeline {task_id}...")


@pipeline_app.command("status")
def pipeline_status():
    """Show current pipeline status & layer assignment."""
    print_banner()

    if RICH_AVAILABLE:
        console.print("\n[cyan]Pipeline Status:[/cyan]\n")
        console.print("  [dim]Not currently in a pipeline.[/dim]")
        console.print("  [dim]Join one with: quarterbit pipeline join <task_id>[/dim]\n")
    else:
        print("Not currently in a pipeline.")


@pipeline_app.command("leave")
def pipeline_leave():
    """Leave current pipeline gracefully."""
    print_banner()

    if RICH_AVAILABLE:
        console.print("[yellow]Leaving pipeline...[/yellow]")
        console.print("[green]Left pipeline successfully.[/green]")
    else:
        print("Left pipeline.")


@pipeline_app.command("stages")
def pipeline_stages(
    task_id: str = typer.Argument(..., help="Pipeline task ID"),
):
    """Show all stages and trainers for a task."""
    print_banner()

    if RICH_AVAILABLE:
        table = Table(title=f"Pipeline Stages: {task_id[:10]}...", box=box.ROUNDED)
        table.add_column("Stage", style="yellow", justify="center")
        table.add_column("Layers", style="cyan")
        table.add_column("Trainer", style="white")
        table.add_column("Status", style="green")
        table.add_column("Memory", justify="right")

        # TODO: Get actual stages from RPC
        # For now show example
        table.add_row("0", "0-9", "0x1234...5678", "Ready", "6.6 GB")
        table.add_row("1", "10-19", "0x2345...6789", "Ready", "6.6 GB")
        table.add_row("2", "20-29", "[dim]Waiting...[/dim]", "Open", "6.6 GB")
        table.add_row("3", "30-39", "[dim]Waiting...[/dim]", "Open", "6.6 GB")

        console.print(table)
    else:
        print(f"Stages for {task_id}...")


# ============================================================================
# CONFIG
# ============================================================================

@app.command()
def config(
    rpc: Optional[str] = typer.Option(None, "--rpc", help="Set RPC URL"),
    show: bool = typer.Option(False, "--show", help="Show current config"),
):
    """View or update configuration."""
    print_banner()

    cfg = load_config()

    if rpc:
        cfg["rpc_url"] = rpc
        save_config(cfg)
        if RICH_AVAILABLE:
            console.print(f"[green]RPC URL set to: {rpc}[/green]")
        else:
            print(f"RPC URL set to: {rpc}")

    if show or not rpc:
        if RICH_AVAILABLE:
            console.print("\n[cyan]Current Configuration:[/cyan]\n")
            for key, value in cfg.items():
                console.print(f"  {key}: [white]{value}[/white]")
        else:
            print("Configuration:")
            for key, value in cfg.items():
                print(f"  {key}: {value}")


# ============================================================================
# MAIN
# ============================================================================

def main():
    """CLI entry point."""
    app()


if __name__ == "__main__":
    main()
