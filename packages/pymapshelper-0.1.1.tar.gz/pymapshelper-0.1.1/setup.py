from setuptools import setup, find_packages

setup(
    name="pymapshelper",  # your package name on PyPI
    version="0.1.1",
    author="Zubair Ahmed",
    author_email="ahmedsoomr0x1@gmail.com",
    description="A beginner-friendly Python library for OpenStreetMap geocoding, nearby places, and routing",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Zubair1s/pymapshelper",
    packages=find_packages(),
    install_requires=[
        "requests"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
)