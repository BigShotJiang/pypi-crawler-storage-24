from .geocode import Geocode
from .places import Places
from .routing import Routing


class Maps:

    def __init__(self):

        self.geo = Geocode()
        self.places = Places()
        self.routing = Routing()


    def coordinates(self, address):
        return self.geo.get_coordinates(address)


    def address(self, lat, lon):
        return self.geo.reverse(lat, lon)


    def nearby(self, *args, **kwargs):
        return self.places.nearby(*args, **kwargs)


    def nearest(self, *args, **kwargs):
        return self.places.nearest(*args, **kwargs)


    def distance(self, *args, **kwargs):
        return self.routing.distance(*args, **kwargs)


    def route(self, *args, **kwargs):
        return self.routing.route(*args, **kwargs)


    def time(self, *args, **kwargs):
        return self.routing.travel_time(*args, **kwargs)
    

    def show_map(self, location, markers=None, zoom=13, filename="map.html"):
        return self.places.show_map(location, markers=markers, zoom=zoom, filename=filename)