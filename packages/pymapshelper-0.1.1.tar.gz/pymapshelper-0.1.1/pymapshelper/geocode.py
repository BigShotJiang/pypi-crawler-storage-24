import requests
from .utils import rate_limit

class Geocode:

    def __init__(self):
        self.search_url = "https://nominatim.openstreetmap.org/search"
        self.headers = {"User-Agent": "pymapshelper"}

    def get_coordinates(self, address):
        params = {
            "q": address,
            "format": "json"
        }
        response = requests.get(self.search_url, params=params, headers=self.headers)
        rate_limit()
        data = response.json()
        if not data:
            return None
        return {
            "lat": float(data[0]["lat"]),
            "lon": float(data[0]["lon"])
        }