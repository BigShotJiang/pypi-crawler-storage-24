# Copyright 2026 Valuein Data Engineering
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import importlib.resources as pkg_resources
import io
import os
import warnings

import duckdb
import pandas as pd
import pyarrow.parquet as pq
from dotenv import load_dotenv

from .exceptions import ValueinAuthError, ValueinPlanError
from .transport import Transport

# Production gateway — customers never need to set this
_DEFAULT_GATEWAY = "https://data.valuein.biz"

# Tables available in both buckets.
_TABLES = ["entity", "security", "filing", "fact", "taxonomy_guide", "index_membership"]


class ValueinClient:
    """Client for the Valuein Financial Data Essentials API.

    Authenticates via a Bearer token, creates lazy DuckDB views over
    Parquet files streamed from the Valuein R2 data lake, and provides
    helper methods for common query patterns.

    Credentials can be passed directly or loaded from environment
    variables / a .env file in the working directory.

    Args:
        api_key: Your Valuein API token. Falls back to ``VALUEIN_API_KEY``
            environment variable.
        gateway_url: Override the gateway base URL. Only needed for local
            development. Defaults to ``https://data.valuein.biz``.

    Raises:
        ValueError: If no API key is found.
        ConnectionError: If the gateway is unreachable.
        ValueinAuthError: If the token is invalid or revoked.

    Example:
        >>> from valuein_sdk import ValueinClient
        >>> client = ValueinClient("your_token_here")
        >>> df = client.get("entity")
        >>> client.query("SELECT symbol FROM security WHERE is_active = TRUE LIMIT 5")
    """

    def __init__(self, api_key: str | None = None, gateway_url: str | None = None) -> None:
        load_dotenv()

        self.api_key = api_key or os.getenv("VALUEIN_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Missing API key. Pass it directly:\n"
                "    client = ValueinClient('your_token_here')\n"
                "or set VALUEIN_API_KEY in your environment or .env file."
            )

        self.gateway_url = (
            gateway_url or os.getenv("VALUEIN_GATEWAY_URL") or _DEFAULT_GATEWAY
        ).rstrip("/")

        self._transport = Transport(api_key=self.api_key, gateway_url=self.gateway_url)

        # Resolve plan and snapshot from the gateway manifest
        self._manifest = self._fetch_manifest()
        self._plan: str = "sp500"
        self._me: dict = self._fetch_me()

        # DuckDB connection with HTTP auth pre-configured
        self.con = duckdb.connect()
        self.query_cache: dict[str, str] = {}
        self._setup_duckdb()
        self._create_views()
        self._build_query_map()

    # ── Gateway calls ─────────────────────────────────────────────────────

    def _fetch_manifest(self) -> dict:
        """Fetch /v1/manifest — confirms connectivity and returns snapshot metadata."""
        response = self._transport.get("/v1/manifest")
        return response.json()

    def _fetch_me(self) -> dict:
        """Fetch /v1/me — sets self._plan from the live token record."""
        try:
            response = self._transport.get("/v1/me")
            data: dict = response.json()
            self._plan = data.get("plan", "sp500")
            return data
        except Exception:
            # Non-fatal — plan defaults to sp500 which is the safe default
            self._plan = "sp500"
            return {}

    # ── DuckDB setup ──────────────────────────────────────────────────────

    def _setup_duckdb(self) -> None:
        """Configure DuckDB to inject Bearer auth on all HTTP requests.

        Uses the HTTP Secret API so every read_parquet call is authenticated
        without the caller needing to pass headers manually.
        """
        self.con.execute("INSTALL httpfs; LOAD httpfs;")
        self.con.execute("SET enable_object_cache=true;")
        self.con.execute(f"""
            CREATE OR REPLACE SECRET valuein_auth (
                TYPE                HTTP,
                SCOPE               '{self.gateway_url}',
                EXTRA_HTTP_HEADERS  MAP {{'Authorization': 'Bearer {self.api_key}'}}
            );
        """)

    def _table_url(self, table: str) -> str:
        """Build the gateway URL for a table.

        Args:
            table: Table name (e.g. 'entity', 'fact').

        Returns:
            Full URL string pointing to the Parquet endpoint for this table.
        """
        prefix = "full" if self._plan == "full" else "sp500"
        return f"{self.gateway_url}/v1/{prefix}/{table}"

    def _create_views(self) -> None:
        """Create DuckDB views that lazily point to each table via the gateway.

        No data is downloaded until a query runs against a view.
        """
        for table in _TABLES:
            url = self._table_url(table)
            try:
                self.con.execute(f"""
                    CREATE OR REPLACE VIEW {table} AS
                    SELECT * FROM read_parquet('{url}');
                """)
            except Exception as e:
                warnings.warn(f"Could not create view for '{table}': {e}", stacklevel=2)

    def _build_query_map(self) -> None:
        """Scan the internal queries/ directory for .sql templates."""
        self.query_cache = {}
        try:
            queries_path = pkg_resources.files("valuein_sdk").joinpath("queries")
            for _root, _, files in os.walk(str(queries_path)):
                for filename in files:
                    if filename.endswith(".sql"):
                        key = filename.replace(".sql", "")
                        self.query_cache[key] = os.path.join(_root, filename)
        except Exception as e:
            warnings.warn(f"Could not load SQL templates: {e}", stacklevel=2)

    # ── Public API ────────────────────────────────────────────────────────

    def me(self) -> dict:
        """Return your token details — plan, status, and email.

        Returns:
            A dict with keys: ``plan``, ``status``, ``email``, ``createdAt``.

        Example:
            >>> client.me()
            {'plan': 'full', 'status': 'active', 'email': 'you@example.com'}
        """
        return self._me

    def manifest(self) -> dict:
        """Return the current data snapshot info from the gateway (not cached).

        Returns:
            A dict with keys: ``snapshot``, ``last_updated``, ``tables``
            (mapping of table name → resolved Parquet path).

        Example:
            >>> client.manifest()
            {'snapshot': 'snapshot_20260306', 'last_updated': 'March 06, 2026 ...', 'tables': {...}}
        """
        return self._fetch_manifest()

    def get(self, table: str) -> pd.DataFrame:
        """Download the latest version of a table as a pandas DataFrame.

        The gateway resolves the current snapshot automatically — you always
        get the most recent data without changing your code.

        Args:
            table: One of ``entity``, ``security``, ``filing``, ``fact``,
                ``taxonomy_guide``, ``index_membership``.

        Returns:
            A pandas DataFrame containing the full table.

        Raises:
            ValueError: If ``table`` is not a known table name.
            ValueinPlanError: If the table requires a higher-tier plan.
            ConnectionError: If the download fails due to a network error.

        Example:
            >>> df = client.get("entity")
            >>> df = client.get("fact")
        """
        if table not in _TABLES:
            raise ValueError(f"Unknown table '{table}'. Available tables: {', '.join(_TABLES)}")

        url = f"/v1/{'full' if self._plan == 'full' else 'sp500'}/{table}"
        try:
            response = self._transport.get(url, stream=True)
        except ValueinAuthError:
            raise
        except ValueinPlanError:
            raise
        except Exception as e:
            raise ConnectionError(f"Failed to download '{table}': {e}") from e

        buf = io.BytesIO(response.content)
        return pq.read_table(buf).to_pandas()

    def query(self, sql: str) -> pd.DataFrame:
        """Run a SQL query against available tables using DuckDB.

        Tables are available as views — no data is downloaded unless your
        query actually reads rows. DuckDB Parquet pushdown means filters
        and column selection happen on the server side.

        Args:
            sql: Any valid DuckDB SQL. Available views: ``entity``,
                ``security``, ``filing``, ``fact``, ``taxonomy_guide``,
                ``index_membership``.

        Returns:
            A pandas DataFrame with the query results.

        Example:
            >>> client.query("SELECT symbol FROM security WHERE is_active = TRUE LIMIT 5")
            >>> client.query(\"\"\"
            ...     SELECT f.report_date, fa.standard_concept, fa.numeric_value
            ...     FROM filing f
            ...     JOIN fact fa ON f.accession_id = fa.accession_id
            ...     JOIN security s ON f.entity_id = s.entity_id
            ...     WHERE s.symbol = 'AAPL' AND s.is_active = TRUE
            ...     ORDER BY f.report_date DESC LIMIT 20
            ... \"\"\")
        """
        return self.con.execute(sql).df()

    def run_template(self, name: str, **kwargs: object) -> pd.DataFrame:
        """Execute a pre-built SQL template by name.

        Templates live in ``valuein_sdk/queries/`` as ``.sql`` files and use
        Python ``.format()`` placeholders. List values are automatically
        expanded into SQL ``IN``-list literals.

        Args:
            name: Template name — the filename without the ``.sql`` extension
                (e.g. ``"01_fundamentals_by_ticker"``).
            **kwargs: Variables to inject into the SQL template.
                Lists are formatted as comma-separated quoted values suitable
                for ``IN (...)`` clauses (e.g. ``tickers=["AAPL", "MSFT"]``
                becomes ``'AAPL', 'MSFT'``).

        Returns:
            A pandas DataFrame with the query results.

        Raises:
            FileNotFoundError: If no template with the given name exists.

        Example:
            >>> client.run_template(
            ...     "01_fundamentals_by_ticker",
            ...     ticker="NVDA",
            ...     form_types=["10-K"],
            ...     metrics=["Revenues"],
            ...     start_date="2020-01-01",
            ...     end_date="2026-01-01",
            ... )
        """
        path = self.query_cache.get(name)
        if not path:
            available = list(self.query_cache.keys()) or ["none found"]
            raise FileNotFoundError(
                f"Template '{name}.sql' not found. Available templates: {', '.join(available)}"
            )

        with open(path) as f:
            sql = f.read()

        # Format list args as SQL IN-list values: ['AAPL', 'MSFT'] → 'AAPL', 'MSFT'
        fmt = {
            k: ", ".join(f"'{v}'" for v in val) if isinstance(val, list) else val
            for k, val in kwargs.items()
        }

        return self.con.execute(sql.format(**fmt)).df()

    def tables(self) -> list[str]:
        """Return the list of available table names for your plan.

        Returns:
            A list of table name strings.

        Example:
            >>> client.tables()
            ['entity', 'security', 'filing', 'fact', 'taxonomy_guide', 'index_membership']
        """
        return list(_TABLES)

    def __repr__(self) -> str:
        plan = self._plan or "unknown"
        status = self._me.get("status", "unknown")
        snap = self._manifest.get("snapshot", "unknown")
        return f"ValueinClient(plan={plan!r}, status={status!r}, snapshot={snap!r})"
